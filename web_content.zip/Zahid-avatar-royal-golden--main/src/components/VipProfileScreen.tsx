import { Award, Check, Crown, Gift, Shield, Sparkles, Swords } from 'lucide-react';
import { ROYAL_ASSETS, VIP_PERKS } from '../data/games';
import { FriendMember } from '../types';

interface VipProfileScreenProps {
  xp: number;
  vipInfo: {
    tier: string;
    nextTier: string;
    progress: number;
    minXp: number;
    nextXp: number;
  };
  roundsPlayed: number;
  winsCount: number;
  biggestWin: number;
  friends: FriendMember[];
  onSendGift: (friendId: string, friendName: string) => void;
  onChallengeFriend: (friendName: string) => void;
}

export function VipProfileScreen({
  xp,
  vipInfo,
  roundsPlayed,
  winsCount,
  biggestWin,
  friends,
  onSendGift,
  onChallengeFriend,
}: VipProfileScreenProps) {
  const winRate = roundsPlayed > 0 ? Math.round((winsCount / roundsPlayed) * 100) : 0;

  return (
    <div className="space-y-5 pb-4">
      {/* Member Identity & VIP Progress Card */}
      <section className="obsidian-card rounded-3xl p-4 space-y-4">
        <div className="flex items-center gap-3.5">
          <div className="relative w-16 h-16 rounded-full p-[2px] bg-gradient-to-br from-[#ffe885] via-[#d4af37] to-[#996515] shrink-0 shadow-[0_0_24px_rgba(212,175,55,0.28)]">
            <img
              src={ROYAL_ASSETS.avatar}
              alt="Zahid Avatar Royal Medallion"
              referrerPolicy="no-referrer"
              className="w-full h-full rounded-full object-cover"
            />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.14em] text-[#ffe885]">
              <Crown className="w-3.5 h-3.5 text-[#ffe885]" />
              <span>{vipInfo.tier}</span>
            </div>
            <h2 className="font-royal text-xl font-bold text-[#f7f1e3] truncate mt-0.5">
              Zahid Avatar
            </h2>
            <p className="text-xs text-[#a8997a]">Sovereign High-Roller · Obsidian Guild</p>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#c8bca3] font-medium">VIP Standing Progress</span>
            <span className="font-mono-num font-bold text-[#ffe885]">
              {xp.toLocaleString()} / {vipInfo.nextXp.toLocaleString()} XP
            </span>
          </div>
          <div className="h-2.5 w-full rounded-full bg-[#0b0906] border border-[#d4af37]/20 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#996515] via-[#d4af37] to-[#ffe885] transition-all duration-300"
              style={{ width: `${vipInfo.progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] text-[#a8997a]">
            <span>{vipInfo.progress}% complete</span>
            <span>Next: {vipInfo.nextTier}</span>
          </div>
        </div>

        {/* Player Metrics Strip */}
        <div className="grid grid-cols-3 gap-2 pt-1">
          <div className="rounded-2xl bg-[#110d08] border border-[#d4af37]/15 p-2.5 text-center">
            <p className="font-mono-num text-base font-bold text-[#f7f1e3]">{roundsPlayed}</p>
            <p className="text-[10px] text-[#a8997a] mt-0.5">Rounds Played</p>
          </div>
          <div className="rounded-2xl bg-[#110d08] border border-[#d4af37]/15 p-2.5 text-center">
            <p className="font-mono-num text-base font-bold text-[#ffe885]">{winRate}%</p>
            <p className="text-[10px] text-[#a8997a] mt-0.5">Win Rate</p>
          </div>
          <div className="rounded-2xl bg-[#110d08] border border-[#d4af37]/15 p-2.5 text-center">
            <p className="font-mono-num text-base font-bold text-emerald-400">
              {biggestWin.toLocaleString()}
            </p>
            <p className="text-[10px] text-[#a8997a] mt-0.5">Best Net Win</p>
          </div>
        </div>
      </section>

      {/* Royal Circle / Friends */}
      <section aria-label="Royal Circle Friends" className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-royal text-base font-bold text-[#ffe885]">Royal Circle</h3>
            <p className="text-xs text-[#a8997a]">Send 50 Coin tribute for +25 VIP XP</p>
          </div>
          <span className="text-xs font-mono-num text-[#d4af37]">{friends.length} Allies</span>
        </div>

        <div className="obsidian-card rounded-2xl divide-y divide-[#d4af37]/10 overflow-hidden">
          {friends.map((friend) => (
            <div key={friend.id} className="flex items-center justify-between gap-2.5 px-3.5 py-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-full bg-[#221b11] border border-[#d4af37]/35 flex items-center justify-center font-royal text-xs font-bold text-[#ffe885] shrink-0">
                  {friend.initials}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#f7f1e3] truncate">{friend.name}</p>
                  <p className="text-[10px] text-[#a8997a] truncate">
                    {friend.vipTier} · {friend.status} ({friend.lastGame})
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => onSendGift(friend.id, friend.name)}
                  disabled={friend.giftedToday}
                  className={`px-2.5 py-1.5 rounded-xl text-[11px] font-semibold flex items-center gap-1 transition-colors whitespace-nowrap ${
                    friend.giftedToday
                      ? 'bg-[#1b150e] text-[#7c6f57] border border-[#d4af37]/10'
                      : 'bg-[#221b11] text-[#ffe885] border border-[#d4af37]/35 hover:bg-[#2d2316]'
                  }`}
                >
                  {friend.giftedToday ? <Check className="w-3 h-3" /> : <Gift className="w-3 h-3" />}
                  {friend.giftedToday ? 'Sent' : 'Gift'}
                </button>
                <button
                  type="button"
                  onClick={() => onChallengeFriend(friend.name)}
                  aria-label={`Challenge ${friend.name}`}
                  className="p-2 rounded-xl bg-[#221b11] border border-[#d4af37]/25 text-[#d4af37] hover:text-[#ffe885]"
                >
                  <Swords className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* VIP Perks */}
      <section aria-label="VIP Perks" className="space-y-2.5">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-[#ffe885]" />
          <h3 className="font-royal text-base font-bold text-[#ffe885]">Royal VIP III Privileges</h3>
        </div>

        <div className="space-y-2">
          {VIP_PERKS.map((perk) => (
            <div
              key={perk.title}
              className="obsidian-card rounded-2xl p-3.5 flex items-start gap-3"
            >
              <div className="w-8 h-8 rounded-xl bg-[#221b11] border border-[#d4af37]/30 flex items-center justify-center text-[#ffe885] shrink-0 mt-0.5">
                {perk.title.includes('Obsidian') ? (
                  <Shield className="w-4 h-4" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
              </div>
              <div>
                <p className="text-xs font-bold text-[#f7f1e3]">{perk.title}</p>
                <p className="text-[11px] text-[#a8997a] leading-snug mt-0.5">{perk.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
