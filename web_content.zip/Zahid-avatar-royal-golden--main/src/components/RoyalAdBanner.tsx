import { Coins, Gem, PlayCircle, X } from 'lucide-react';
import { useState } from 'react';

interface RoyalAdBannerProps {
  onWatchAd: () => void;
}

export function RoyalAdBanner({ onWatchAd }: RoyalAdBannerProps) {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="obsidian-card rounded-2xl px-3 py-2.5 flex items-center justify-between gap-2.5 border-[#d4af37]/30">
      <div className="flex items-center gap-2.5 min-w-0">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#2b2011] to-[#130e08] border border-[#d4af37]/40 flex items-center justify-center text-[#ffe885] shrink-0">
          <PlayCircle className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] font-mono-num font-bold px-1 py-0.5 rounded bg-[#d4af37]/20 text-[#ffe885]">
              AD
            </span>
            <p className="text-xs font-bold text-[#f7f1e3] truncate">Royal Sponsor Bonus</p>
          </div>
          <p className="text-[11px] text-[#a8997a] flex items-center gap-2 mt-0.5">
            <span className="flex items-center gap-0.5 text-[#ffe885] font-mono-num">
              <Coins className="w-3 h-3 text-[#d4af37]" /> +150
            </span>
            <span>·</span>
            <span className="flex items-center gap-0.5 text-sky-300 font-mono-num">
              <Gem className="w-3 h-3" /> +2 Gems
            </span>
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          onClick={onWatchAd}
          className="px-3 py-2 rounded-xl gold-gradient-btn text-[11px] font-bold whitespace-nowrap transition-transform active:scale-95"
        >
          Watch Ad
        </button>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          aria-label="Hide banner ad"
          className="p-1.5 text-[#8d7f66] hover:text-[#f7f1e3] rounded-lg"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
