import { Download, Smartphone, WifiOff } from 'lucide-react';
import { useState } from 'react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export function PWAInstallButton({ compact = false }: { compact?: boolean }) {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className={
          compact
            ? 'px-3 py-1.5 rounded-xl gold-gradient-btn text-[11px] font-bold flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'w-full py-3 px-4 rounded-2xl gold-gradient-btn text-xs font-bold flex items-center justify-center gap-2 transition-transform active:scale-[0.98]'
        }
      >
        <Download className="w-3.5 h-3.5" />
        Install App
      </button>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setShowGuide(true)}
        className={
          compact
            ? 'px-3 py-1.5 rounded-xl bg-[#221b11] border border-[#d4af37]/35 text-[#ffe885] text-[11px] font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'w-full py-3 px-4 rounded-2xl bg-[#1d160e] border border-[#d4af37]/30 text-[#ffe885] text-xs font-semibold flex items-center justify-center gap-2 hover:border-[#d4af37]/50 transition-colors'
        }
      >
        <Smartphone className="w-3.5 h-3.5" />
        {isIOS ? 'Install on iPhone' : 'Install Mobile App'}
      </button>

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-[#140f0a] border border-[#d4af37]/40 p-5 shadow-2xl space-y-3">
            <h3 className="font-royal text-base font-bold text-[#ffe885]">
              {isIOS ? 'Install on iPhone / iPad' : 'Install Zahid Avatar App'}
            </h3>
            {isIOS ? (
              <p className="text-xs text-[#c8bca3] leading-relaxed">
                1. Tap the <strong>Share</strong> icon in Safari.<br />
                2. Scroll down and tap <strong>Add to Home Screen</strong>.
              </p>
            ) : (
              <p className="text-xs text-[#c8bca3] leading-relaxed">
                Open this page in <strong>Android Chrome</strong>, tap the browser menu (⋮), and choose{' '}
                <strong>Install app</strong> / <strong>Add to Home screen</strong> to launch Zahid Avatar fullscreen like a native app.
              </p>
            )}
            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full py-2.5 rounded-xl gold-gradient-btn text-xs font-bold"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="mx-3.5 mt-2 px-3 py-1.5 rounded-xl bg-amber-950/80 border border-amber-500/40 flex items-center gap-2 text-[11px] font-medium text-amber-200">
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>Offline Mode — Playing with cached local state.</span>
    </div>
  );
}
