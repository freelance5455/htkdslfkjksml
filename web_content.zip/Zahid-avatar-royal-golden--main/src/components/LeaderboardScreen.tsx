import { Coins, Crown, Medal, Trophy } from 'lucide-react';
import { useState } from 'react';
import { LeaderboardMember } from '../types';
import { type SoundEffectType } from '../utils/sound';

interface LeaderboardScreenProps {
  members: LeaderboardMember[];
  onPlaySound?: (effect: SoundEffectType) => void;
  onPlayNow: () => void;
}

export function LeaderboardScreen({ members, onPlaySound, onPlayNow }: LeaderboardScreenProps) {
  const [sortBy, setSortBy] = useState<'coins' | 'weekly'>('coins');

  const sorted = [...members].sort((a, b) =>
    sortBy === 'coins' ? b.coins - a.coins : b.weeklyWins - a.weeklyWins
  );

  const topThree = sorted.slice(0, 3);
  const userRank = sorted.findIndex((m) => m.isUser) + 1;

  return (
    <div className="space-y-4 pb-4">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="font-royal text-lg font-bold text-[#ffe885]">Imperial Leaderboard</h2>
          <p className="text-xs text-[#a8997a]">
            Your current standing: <span className="text-[#ffe885] font-semibold">Rank #{userRank}</span>
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#18130c] border border-[#d4af37]/25 rounded-xl shrink-0">
          <button
            type="button"
            onClick={() => {
              onPlaySound?.('click');
              setSortBy('coins');
            }}
            className={`px-2.5 py-1.5 text-[11px] font-semibold rounded-lg transition-colors whitespace-nowrap ${
              sortBy === 'coins'
                ? 'gold-gradient-btn'
                : 'text-[#a8997a] hover:text-[#f7f1e3]'
            }`}
          >
            Treasury
          </button>
          <button
            type="button"
            onClick={() => {
              onPlaySound?.('click');
              setSortBy('weekly');
            }}
            className={`px-2.5 py-1.5 text-[11px] font-semibold rounded-lg transition-colors whitespace-nowrap ${
              sortBy === 'weekly'
                ? 'gold-gradient-btn'
                : 'text-[#a8997a] hover:text-[#f7f1e3]'
            }`}
          >
            Weekly Wins
          </button>
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-3 gap-2 items-end pt-2">
        {[topThree[1], topThree[0], topThree[2]].map((member, idx) => {
          if (!member) return null;
          const actualRank = idx === 1 ? 1 : idx === 0 ? 2 : 3;
          const score = sortBy === 'coins' ? member.coins : member.weeklyWins;
          const isFirst = actualRank === 1;

          return (
            <div
              key={member.id}
              className={`obsidian-card rounded-2xl p-2.5 text-center flex flex-col items-center ${
                isFirst
                  ? 'border-[#ffe885]/55 bg-gradient-to-b from-[#2b2011] to-[#130e08] pb-4 -mt-2'
                  : 'border-[#d4af37]/25'
              } ${member.isUser ? 'ring-1 ring-[#ffe885]' : ''}`}
            >
              <div className="mb-1.5">
                {isFirst ? (
                  <Crown className="w-5 h-5 text-[#ffe885] mx-auto" />
                ) : (
                  <Medal className={`w-4 h-4 mx-auto ${actualRank === 2 ? 'text-slate-300' : 'text-amber-600'}`} />
                )}
              </div>

              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-royal font-bold text-sm mb-1.5 ${
                  member.isUser
                    ? 'gold-gradient-btn'
                    : 'bg-[#221b11] border border-[#d4af37]/40 text-[#ffe885]'
                }`}
              >
                {member.initials}
              </div>

              <p className="text-[11px] font-bold text-[#f7f1e3] truncate w-full">
                {member.name}
              </p>
              <p className="text-[9px] text-[#d4af37] tracking-wider mt-0.5 truncate w-full">
                {member.vipTier}
              </p>
              <p className="font-mono-num text-xs font-bold text-[#ffe885] mt-1.5">
                {score.toLocaleString()}
              </p>
            </div>
          );
        })}
      </div>

      {/* Full Rankings List */}
      <div className="obsidian-card rounded-2xl divide-y divide-[#d4af37]/10 overflow-hidden">
        {sorted.map((member, index) => {
          const rank = index + 1;
          const value = sortBy === 'coins' ? member.coins : member.weeklyWins;
          return (
            <div
              key={member.id}
              className={`flex items-center justify-between gap-3 px-3.5 py-3 ${
                member.isUser ? 'bg-[#d4af37]/12' : ''
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span
                  className={`font-mono-num text-xs font-bold w-5 text-center shrink-0 ${
                    rank <= 3 ? 'text-[#ffe885]' : 'text-[#a8997a]'
                  }`}
                >
                  {rank}
                </span>
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-royal text-xs font-bold shrink-0 ${
                    member.isUser
                      ? 'gold-gradient-btn'
                      : 'bg-[#221b11] border border-[#d4af37]/30 text-[#ffe885]'
                  }`}
                >
                  {member.initials}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#f7f1e3] truncate">
                    {member.name} {member.isUser ? '(You)' : ''}
                  </p>
                  <p className="text-[10px] text-[#a8997a] tracking-wide">{member.vipTier}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <Coins className="w-3.5 h-3.5 text-[#d4af37]" aria-hidden="true" />
                <span className="font-mono-num text-xs font-bold text-[#ffe885]">
                  {value.toLocaleString()}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <button
        type="button"
        onClick={onPlayNow}
        className="w-full py-3 px-4 rounded-2xl gold-gradient-btn text-xs font-bold tracking-wide flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
      >
        <Trophy className="w-4 h-4" />
        Climb Ranks in Royal Arena
      </button>
    </div>
  );
}
