import { ArrowUpFromLine, Coins, Gem, Plus, Settings, User } from 'lucide-react';
import { ROYAL_ASSETS } from '../data/games';

interface TopBarProps {
  coins: number;
  gems: number;
  vipTier: string;
  onAddCoins: () => void;
  onWithdrawCoins: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
}

export function TopBar({
  coins,
  gems,
  vipTier,
  onAddCoins,
  onWithdrawCoins,
  onOpenProfile,
  onOpenSettings,
}: TopBarProps) {
  return (
    <header className="shrink-0 z-30 bg-[#0d0a07]/95 backdrop-blur-md border-b border-[#d4af37]/20 px-3 py-2.5">
      <div className="flex items-center justify-between gap-1.5">
        {/* Left: Golden Z Avatar + Zahid Avatar Title + VIP Tier */}
        <button
          type="button"
          onClick={onOpenProfile}
          className="flex items-center gap-2 min-w-0 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885] rounded-xl pr-1"
          title="Open Zahid Avatar VIP Profile"
        >
          <div className="relative w-9 h-9 shrink-0 rounded-full p-[1.5px] bg-gradient-to-br from-[#ffe885] via-[#d4af37] to-[#996515] shadow-[0_0_16px_rgba(212,175,55,0.28)]">
            <div className="w-full h-full rounded-full overflow-hidden bg-[#18130c] flex items-center justify-center relative">
              <img
                src={ROYAL_ASSETS.avatar}
                alt="Zahid Avatar crest"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-35 group-hover:opacity-50 transition-opacity"
              />
              <span className="absolute inset-0 flex items-center justify-center font-royal font-bold text-sm text-[#ffe885] drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                Z
              </span>
            </div>
          </div>

          <div className="min-w-0">
            <h1 className="font-royal text-[13px] font-bold tracking-wide gold-gradient-text truncate leading-tight">
              Zahid Avatar
            </h1>
            <p className="text-[9px] font-semibold tracking-[0.12em] text-[#d4af37]/90 truncate mt-0.5">
              {vipTier}
            </p>
          </div>
        </button>

        {/* Right: Wallet Pill (+ Deposit & Withdraw Icons) + Profile & Settings */}
        <div className="flex items-center gap-1 shrink-0">
          <div className="flex items-center bg-[#18130c] border border-[#d4af37]/30 rounded-full pl-2 pr-1 py-1 gap-1.5 shadow-inner">
            <div className="flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-[#ffe885] shrink-0" aria-hidden="true" />
              <span className="font-mono-num text-[11px] font-semibold text-[#f7f1e3]">
                {coins.toLocaleString()}
              </span>
            </div>
            <span className="text-[#d4af37]/30 text-[10px]" aria-hidden="true">|</span>
            <div className="flex items-center gap-0.5">
              <Gem className="w-3 h-3 text-[#d4af37] shrink-0" aria-hidden="true" />
              <span className="font-mono-num text-[11px] font-semibold text-[#ffe885]">
                {gems}
              </span>
            </div>
            <button
              type="button"
              onClick={onAddCoins}
              aria-label="Add Coins in Shop"
              title="Top Up Coins"
              className="w-6 h-6 rounded-full gold-gradient-btn flex items-center justify-center transition-transform active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885]"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.75]" />
            </button>
            <button
              type="button"
              onClick={onWithdrawCoins}
              aria-label="Withdraw Coins"
              title="Withdraw Coins"
              className="w-6 h-6 rounded-full bg-[#241b10] border border-[#d4af37]/45 text-[#ffe885] hover:bg-[#322515] flex items-center justify-center transition-transform active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885]"
            >
              <ArrowUpFromLine className="w-3 h-3 stroke-[2.5]" />
            </button>
          </div>

          <button
            type="button"
            onClick={onOpenProfile}
            aria-label="VIP Profile"
            className="w-8 h-8 rounded-full bg-[#18130c] border border-[#d4af37]/20 flex items-center justify-center text-[#d4af37] hover:text-[#ffe885] hover:border-[#d4af37]/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885]"
          >
            <User className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="Settings"
            className="w-8 h-8 rounded-full bg-[#18130c] border border-[#d4af37]/20 flex items-center justify-center text-[#d4af37] hover:text-[#ffe885] hover:border-[#d4af37]/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885]"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
