import {
  ArrowDownLeft,
  ArrowUpRight,
  CalendarCheck,
  Coins,
  Crown,
  Dices,
  Disc3,
  Flame,
  Gem,
  Lock,
  Pyramid,
  Spade,
  Sparkles,
  Target,
} from 'lucide-react';
import { GAMES_CATALOG, ROYAL_ASSETS } from '../data/games';
import { GameId, Transaction } from '../types';

interface HomeScreenProps {
  streak: number;
  canClaimDaily: boolean;
  history: Transaction[];
  onClaimDaily: () => void;
  onPlayGame: (gameId: GameId) => void;
  onViewAllGames: () => void;
  onViewLedger: () => void;
}

const GAME_ICON_MAP: Record<GameId, typeof Dices> = {
  'royal-dice': Dices,
  'golden-spin': Disc3,
  'wheel-of-fortune': Sparkles,
  'crown-flip': Crown,
  'vault-lock': Lock,
  'royal-slots': Sparkles,
  'golden-roulette': Target,
  'dragon-cards': Spade,
  'pharaoh-quest': Pyramid,
};

function formatTimeAgo(ts: number): string {
  const diffMin = Math.max(1, Math.floor((Date.now() - ts) / 60000));
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return `${Math.floor(diffHr / 24)}d ago`;
}

export function HomeScreen({
  streak,
  canClaimDaily,
  history,
  onClaimDaily,
  onPlayGame,
  onViewAllGames,
  onViewLedger,
}: HomeScreenProps) {
  const featuredGames = GAMES_CATALOG.slice(0, 6);
  const recentHistory = history.slice(0, 4);

  return (
    <div className="space-y-5 pb-4">
      {/* Daily Bonus Royal Vault Promo Card */}
      <section aria-label="Daily Royal Bonus" className="relative overflow-hidden rounded-3xl border border-[#d4af37]/35 bg-[#16110a] shadow-[0_14px_34px_rgba(0,0,0,0.55)]">
        <div className="absolute inset-0">
          <img
            src={ROYAL_ASSETS.vaultBanner}
            alt="Royal Obsidian Treasury Vault"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0906] via-[#0b0906]/75 to-[#0b0906]/45" />
        </div>

        <div className="relative p-4 space-y-3.5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#ffe885]">
                <Flame className="w-3.5 h-3.5 text-[#ffe885]" aria-hidden="true" />
                <span>Day {streak} of 7 Streak</span>
                <span aria-hidden="true" className="text-[#d4af37]/50">·</span>
                <span className="text-[#d4af37]">VIP III Boost</span>
              </div>
              <h2 className="font-royal text-lg font-bold text-[#f7f1e3] mt-1 leading-snug">
                Royal Daily Vault
              </h2>
              <p className="text-xs text-[#c8bca3] mt-0.5">
                Collect daily sovereign coins & imperial gems.
              </p>
            </div>

            <div className="w-11 h-11 rounded-2xl bg-[#221b11]/90 border border-[#d4af37]/40 flex items-center justify-center shrink-0">
              <CalendarCheck className="w-5 h-5 text-[#ffe885]" />
            </div>
          </div>

          {/* 7-Day Streak Track */}
          <div className="grid grid-cols-7 gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7].map((day) => {
              const completed = day <= streak;
              const isNext = day === Math.min(7, streak + 1) && canClaimDaily;
              return (
                <div
                  key={day}
                  className={`py-1.5 rounded-lg text-center border transition-colors ${
                    completed
                      ? 'bg-[#d4af37]/20 border-[#d4af37]/50 text-[#ffe885]'
                      : isNext
                      ? 'bg-[#2a2013] border-[#ffe885]/70 text-[#ffe885]'
                      : 'bg-[#120e09]/80 border-[#d4af37]/15 text-[#7c6f57]'
                  }`}
                >
                  <div className="text-[9px] font-semibold">D{day}</div>
                  <div className="text-[10px] font-mono-num font-bold mt-0.5">
                    {day === 7 ? '700' : `${350 + day * 50}`}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-3 text-xs font-mono-num text-[#ffe885]">
              <span className="flex items-center gap-1">
                <Coins className="w-3.5 h-3.5 text-[#d4af37]" aria-hidden="true" />
                +{350 + Math.min(7, streak + 1) * 50}
              </span>
              <span className="flex items-center gap-1">
                <Gem className="w-3.5 h-3.5 text-[#d4af37]" aria-hidden="true" />
                +{Math.min(7, streak + 1) >= 5 ? 8 : 5}
              </span>
            </div>

            <button
              type="button"
              onClick={onClaimDaily}
              disabled={!canClaimDaily}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885] ${
                canClaimDaily
                  ? 'gold-gradient-btn shadow-[0_6px_18px_rgba(212,175,55,0.3)] active:scale-95'
                  : 'bg-[#221b11] text-[#8d7f66] border border-[#d4af37]/15 cursor-not-allowed'
              }`}
            >
              {canClaimDaily ? 'Claim Bonus' : 'Claimed Today'}
            </button>
          </div>
        </div>
      </section>

      {/* Featured Mini-Games 2-Column Grid */}
      <section aria-label="Featured Games">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="font-royal text-base font-bold text-[#ffe885]">Royal Arena</h2>
            <p className="text-[11px] text-[#a8997a]">9 playable modes · Instant vault payouts</p>
          </div>
          <button
            type="button"
            onClick={onViewAllGames}
            className="text-xs font-semibold text-[#d4af37] hover:text-[#ffe885] transition-colors py-1.5 px-2 whitespace-nowrap shrink-0"
          >
            All 9 Games
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {featuredGames.map((game) => {
            const Icon = GAME_ICON_MAP[game.id];
            return (
              <div
                key={game.id}
                className="obsidian-card rounded-2xl p-3.5 flex flex-col justify-between gap-3 hover:border-[#d4af37]/45 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <div className="w-9 h-9 rounded-xl bg-[#221b11] border border-[#d4af37]/30 flex items-center justify-center text-[#ffe885]">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-mono-num text-[11px] font-bold text-[#d4af37]">
                      Up to {game.maxMultiplier}
                    </span>
                  </div>
                  <h3 className="font-royal text-[13px] font-bold text-[#f7f1e3] truncate">
                    {game.name}
                  </h3>
                  <p className="text-[11px] text-[#a8997a] leading-snug mt-1 line-clamp-2">
                    {game.tagline}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onPlayGame(game.id)}
                  className="w-full py-2.5 px-3 rounded-xl gold-gradient-btn text-xs font-bold tracking-wide transition-transform active:scale-95 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885]"
                >
                  Play Now
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Recent Activity Feed */}
      <section aria-label="Recent Activity">
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="font-royal text-base font-bold text-[#ffe885]">Recent Activity</h2>
          <button
            type="button"
            onClick={onViewLedger}
            className="text-xs font-semibold text-[#d4af37] hover:text-[#ffe885] transition-colors py-1 px-2 whitespace-nowrap shrink-0"
          >
            Full Ledger
          </button>
        </div>

        <div className="obsidian-card rounded-2xl divide-y divide-[#d4af37]/10 overflow-hidden">
          {recentHistory.map((tx) => {
            const isPositive = tx.amount >= 0;
            return (
              <div key={tx.id} className="flex items-center justify-between gap-3 px-3.5 py-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${
                      isPositive
                        ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-400'
                        : 'bg-rose-950/50 border-rose-500/30 text-rose-400'
                    }`}
                  >
                    {isPositive ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownLeft className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-[#f7f1e3] truncate">{tx.title}</p>
                    <p className="text-[11px] text-[#a8997a] truncate">
                      {tx.detail} · {formatTimeAgo(tx.timestamp)}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span
                    className={`font-mono-num text-xs font-bold ${
                      isPositive ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isPositive ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()}
                  </span>
                  {tx.gemsDelta ? (
                    <p className="font-mono-num text-[10px] text-[#ffe885]">
                      {tx.gemsDelta > 0 ? `+${tx.gemsDelta}` : tx.gemsDelta} Gems
                    </p>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
