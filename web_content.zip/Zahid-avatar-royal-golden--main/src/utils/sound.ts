let audioCtx: AudioContext | null = null;

export type SoundEffectType =
  | 'click'
  | 'spinTick'
  | 'coin'
  | 'win'
  | 'jackpot'
  | 'loss'
  | 'wheelStart'
  | 'wheelTick'
  | 'wheelWin';

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextCtor =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (AudioContextCtor) {
      audioCtx = new AudioContextCtor();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

function playTone(
  freq: number,
  duration: number,
  type: OscillatorType = 'sine',
  volume = 0.08,
  delay = 0
) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const startTime = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, startTime);

  gain.gain.setValueAtTime(0.0001, startTime);
  gain.gain.exponentialRampToValueAtTime(volume, startTime + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(startTime);
  osc.stop(startTime + duration + 0.02);
}

export const soundFX: Record<SoundEffectType, (enabled: boolean) => void> = {
  click(enabled: boolean) {
    if (!enabled) return;
    playTone(580, 0.055, 'triangle', 0.05);
  },
  spinTick(enabled: boolean) {
    if (!enabled) return;
    playTone(720, 0.035, 'sine', 0.04);
  },
  coin(enabled: boolean) {
    if (!enabled) return;
    playTone(987.77, 0.09, 'sine', 0.08, 0);
    playTone(1318.51, 0.16, 'sine', 0.08, 0.07);
  },
  win(enabled: boolean) {
    if (!enabled) return;
    playTone(523.25, 0.12, 'triangle', 0.09, 0);
    playTone(659.25, 0.12, 'triangle', 0.09, 0.09);
    playTone(783.99, 0.18, 'triangle', 0.1, 0.18);
    playTone(1046.5, 0.28, 'sine', 0.1, 0.27);
  },
  jackpot(enabled: boolean) {
    if (!enabled) return;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51];
    notes.forEach((n, idx) => {
      playTone(n, 0.22, 'triangle', 0.1, idx * 0.08);
    });
  },
  loss(enabled: boolean) {
    if (!enabled) return;
    playTone(310, 0.14, 'sawtooth', 0.04, 0);
    playTone(220, 0.2, 'sawtooth', 0.04, 0.12);
  },
  wheelStart(enabled: boolean) {
    if (!enabled) return;
    playTone(440, 0.1, 'triangle', 0.07, 0);
    playTone(587.33, 0.12, 'triangle', 0.07, 0.07);
    playTone(880, 0.16, 'sine', 0.07, 0.14);
  },
  wheelTick(enabled: boolean) {
    if (!enabled) return;
    playTone(820, 0.028, 'triangle', 0.045);
  },
  wheelWin(enabled: boolean) {
    if (!enabled) return;
    const notes = [587.33, 739.99, 880, 1174.66];
    notes.forEach((n, idx) => {
      playTone(n, 0.2, 'triangle', 0.095, idx * 0.075);
    });
  },
};
