export type TabId = 'home' | 'games' | 'leaderboard' | 'shop' | 'vip';

export type GameId =
  | 'royal-dice'
  | 'golden-spin'
  | 'wheel-of-fortune'
  | 'crown-flip'
  | 'vault-lock'
  | 'royal-slots'
  | 'golden-roulette'
  | 'dragon-cards'
  | 'pharaoh-quest';

export type TransactionType = 'win' | 'loss' | 'bonus' | 'topup' | 'gift' | 'withdraw';

export interface Transaction {
  id: string;
  title: string;
  detail: string;
  amount: number; // positive for credit, negative for debit
  gemsDelta?: number;
  type: TransactionType;
  gameId?: GameId;
  timestamp: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  variant: 'gold' | 'win' | 'loss';
}

export interface GameDefinition {
  id: GameId;
  name: string;
  tagline: string;
  maxMultiplier: string;
  category: 'Classic' | 'Wheel' | 'Cards' | 'Vault';
  featured: boolean;
}

export interface LeaderboardMember {
  id: string;
  name: string;
  initials: string;
  vipTier: string;
  coins: number;
  weeklyWins: number;
  isUser?: boolean;
}

export interface FriendMember {
  id: string;
  name: string;
  initials: string;
  vipTier: string;
  status: 'In Arena' | 'Online' | 'Away';
  lastGame: string;
  giftedToday: boolean;
}

export interface PlayerState {
  coins: number;
  gems: number;
  wager: number;
  currentGame: GameId;
  activeTab: TabId;
  roundsPlayed: number;
  winsCount: number;
  totalWagered: number;
  biggestWin: number;
  xp: number;
  streak: number;
  lastClaimDate: string | null; // YYYY-MM-DD
  lastWheelOfFortuneSpinAt: number | null;
  soundEnabled: boolean;
  animationsEnabled: boolean;
  history: Transaction[];
  giftedFriendIds: string[];
}
