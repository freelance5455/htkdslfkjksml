import { FriendMember, GameDefinition, LeaderboardMember } from '../types';

export const ROYAL_ASSETS = {
  avatar: '/src/assets/images/zahid_royal_avatar_1795368070559.jpg',
  vaultBanner: '/src/assets/images/royal_vault_banner_1795368071419.jpg',
  dragonEmblem: '/src/assets/images/dragon_emblem_art_1795368070249.jpg',
};

export const WAGER_OPTIONS = [100, 250, 500, 1000] as const;

export const GAMES_CATALOG: GameDefinition[] = [
  {
    id: 'royal-dice',
    name: 'Royal Dice',
    tagline: 'Call High, Low, or Lucky 7 roll',
    maxMultiplier: '4.5x',
    category: 'Classic',
    featured: true,
  },
  {
    id: 'golden-spin',
    name: 'Golden Spin',
    tagline: '8-wedge fortune wheel of sovereigns',
    maxMultiplier: '10x',
    category: 'Wheel',
    featured: true,
  },
  {
    id: 'wheel-of-fortune',
    name: 'Golden Wheel of Fortune',
    tagline: '4-hour timed spin for multipliers or gems',
    maxMultiplier: '10x / +25 Gems',
    category: 'Wheel',
    featured: true,
  },
  {
    id: 'crown-flip',
    name: 'Crown Flip',
    tagline: 'Heads Crown or Obsidian Shield duel',
    maxMultiplier: '1.95x',
    category: 'Classic',
    featured: true,
  },
  {
    id: 'vault-lock',
    name: 'Vault Lock',
    tagline: 'Crack the royal treasury chamber',
    maxMultiplier: '3.0x',
    category: 'Vault',
    featured: true,
  },
  {
    id: 'royal-slots',
    name: 'Royal Slots',
    tagline: 'Triple-reel imperial crown jackpot',
    maxMultiplier: '12x',
    category: 'Classic',
    featured: true,
  },
  {
    id: 'golden-roulette',
    name: 'Golden Roulette',
    tagline: 'Crimson, Obsidian, or Gold Zero',
    maxMultiplier: '12x',
    category: 'Wheel',
    featured: true,
  },
  {
    id: 'dragon-cards',
    name: 'Dragon Cards',
    tagline: 'Imperial high-card battle & Tie 8x',
    maxMultiplier: '8.0x',
    category: 'Cards',
    featured: false,
  },
  {
    id: 'pharaoh-quest',
    name: 'Pharaoh Quest',
    tagline: 'Uncover golden scarabs, dodge traps',
    maxMultiplier: '15x',
    category: 'Vault',
    featured: false,
  },
];

export const BASE_LEADERBOARD: Omit<LeaderboardMember, 'isUser'>[] = [
  { id: 'lb-1', name: 'Sovereign Tariq', initials: 'ST', vipTier: 'ROYAL VIP V', coins: 42850, weeklyWins: 18400 },
  { id: 'lb-2', name: 'Empress Nadia', initials: 'EN', vipTier: 'ROYAL VIP IV', coins: 31200, weeklyWins: 14100 },
  { id: 'lb-3', name: 'Aurelius Vance', initials: 'AV', vipTier: 'ROYAL VIP IV', coins: 24900, weeklyWins: 9750 },
  { id: 'lb-4', name: 'Khalid Al-Mansoor', initials: 'KA', vipTier: 'ROYAL VIP III', coins: 15600, weeklyWins: 7200 },
  { id: 'lb-5', name: 'Lady Selene', initials: 'LS', vipTier: 'ROYAL VIP III', coins: 11400, weeklyWins: 5100 },
  { id: 'lb-6', name: 'Darius Crown', initials: 'DC', vipTier: 'ROYAL VIP II', coins: 7850, weeklyWins: 3450 },
  { id: 'lb-7', name: 'Mirza Gold', initials: 'MG', vipTier: 'ROYAL VIP II', coins: 4950, weeklyWins: 2100 },
  { id: 'lb-8', name: 'Farah Imperial', initials: 'FI', vipTier: 'ROYAL VIP I', coins: 2800, weeklyWins: 1250 },
];

export const ROYAL_FRIENDS: Omit<FriendMember, 'giftedToday'>[] = [
  {
    id: 'fr-1',
    name: 'Sovereign Tariq',
    initials: 'ST',
    vipTier: 'ROYAL VIP V',
    status: 'In Arena',
    lastGame: 'Royal Slots',
  },
  {
    id: 'fr-2',
    name: 'Empress Nadia',
    initials: 'EN',
    vipTier: 'ROYAL VIP IV',
    status: 'Online',
    lastGame: 'Dragon Cards',
  },
  {
    id: 'fr-3',
    name: 'Khalid Al-Mansoor',
    initials: 'KA',
    vipTier: 'ROYAL VIP III',
    status: 'In Arena',
    lastGame: 'Pharaoh Quest',
  },
  {
    id: 'fr-4',
    name: 'Lady Selene',
    initials: 'LS',
    vipTier: 'ROYAL VIP III',
    status: 'Away',
    lastGame: 'Golden Spin',
  },
];

export const VIP_PERKS = [
  {
    title: '1.5x Daily Vault Bonus',
    detail: 'Royal VIP III members receive +50% bonus sovereign coins on every daily claim.',
  },
  {
    title: 'Zero-Fee Gem Exchange',
    detail: 'Convert Imperial Gems into Gold Coins at peak vault exchange rates.',
  },
  {
    title: 'High-Roller 1,000 Chip Access',
    detail: 'Unlocked maximum wager chip across all 8 royal arena games.',
  },
  {
    title: 'Obsidian & Gold Heraldry',
    detail: 'Exclusive Zahid Avatar gilded medallion crest and priority leaderboard badge.',
  },
];
