import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BASE_LEADERBOARD, ROYAL_FRIENDS } from '../data/games';
import { GameId, LeaderboardMember, PlayerState, TabId, ToastMessage, Transaction } from '../types';
import { type SoundEffectType, soundFX } from '../utils/sound';

const STORAGE_KEY = 'zahid_avatar_royal_state_v1';

function getTodayKey(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getInitialState(): PlayerState {
  const now = Date.now();
  const defaultState: PlayerState = {
    coins: 5000,
    gems: 35,
    wager: 250,
    currentGame: 'royal-dice',
    activeTab: 'home',
    roundsPlayed: 14,
    winsCount: 9,
    totalWagered: 3850,
    biggestWin: 1750,
    xp: 2450,
    streak: 4,
    lastClaimDate: null,
    lastWheelOfFortuneSpinAt: null,
    soundEnabled: true,
    animationsEnabled: true,
    giftedFriendIds: [],
    history: [
      {
        id: 'tx-seed-1',
        title: 'Royal Slots · Triple Crown',
        detail: '500 wager · 3.5x payout',
        amount: 1750,
        type: 'win',
        gameId: 'royal-slots',
        timestamp: now - 1000 * 60 * 18,
      },
      {
        id: 'tx-seed-2',
        title: 'Dragon Cards · Imperial Tie',
        detail: '250 wager · Dragon edged',
        amount: -250,
        type: 'loss',
        gameId: 'dragon-cards',
        timestamp: now - 1000 * 60 * 52,
      },
      {
        id: 'tx-seed-3',
        title: 'Daily Vault Streak (Day 4)',
        detail: 'Royal VIP III Boost Applied',
        amount: 450,
        gemsDelta: 5,
        type: 'bonus',
        timestamp: now - 1000 * 60 * 60 * 25,
      },
    ],
  };

  if (typeof window === 'undefined') return defaultState;

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;
    const parsed = JSON.parse(raw) as Partial<PlayerState>;
    return {
      ...defaultState,
      ...parsed,
      history: Array.isArray(parsed.history) ? parsed.history : defaultState.history,
      giftedFriendIds: Array.isArray(parsed.giftedFriendIds) ? parsed.giftedFriendIds : [],
    };
  } catch {
    return defaultState;
  }
}

export function getVipInfo(xp: number) {
  if (xp >= 10000) return { tier: 'ROYAL VIP V', nextTier: 'MAX SOVEREIGN', progress: 100, minXp: 10000, nextXp: 10000 };
  if (xp >= 5000) {
    return {
      tier: 'ROYAL VIP IV',
      nextTier: 'ROYAL VIP V',
      progress: Math.min(100, Math.round(((xp - 5000) / 5000) * 100)),
      minXp: 5000,
      nextXp: 10000,
    };
  }
  if (xp >= 2000) {
    return {
      tier: 'ROYAL VIP III',
      nextTier: 'ROYAL VIP IV',
      progress: Math.min(100, Math.round(((xp - 2000) / 3000) * 100)),
      minXp: 2000,
      nextXp: 5000,
    };
  }
  return {
    tier: 'ROYAL VIP II',
    nextTier: 'ROYAL VIP III',
    progress: Math.min(100, Math.round((xp / 2000) * 100)),
    minXp: 0,
    nextXp: 2000,
  };
}

export function useGameStore() {
  const [state, setState] = useState<PlayerState>(getInitialState);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const soundEnabledRef = useRef(state.soundEnabled);

  useEffect(() => {
    soundEnabledRef.current = state.soundEnabled;
  }, [state.soundEnabled]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage quota errors
    }
  }, [state]);

  const playSound = useCallback((effect: SoundEffectType) => {
    if (!soundEnabledRef.current) return;
    soundFX[effect](true);
  }, []);

  const soundController = useMemo(
    () => ({
      play: playSound,
      click: () => playSound('click'),
      coin: () => playSound('coin'),
      win: () => playSound('win'),
      jackpot: () => playSound('jackpot'),
      loss: () => playSound('loss'),
      spinTick: () => playSound('spinTick'),
      wheelStart: () => playSound('wheelStart'),
      wheelTick: () => playSound('wheelTick'),
      wheelWin: () => playSound('wheelWin'),
    }),
    [playSound]
  );

  const showToast = useCallback((title: string, message: string, variant: ToastMessage['variant'] = 'gold') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-2), { id, title, message, variant }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const setActiveTab = useCallback(
    (tab: TabId) => {
      playSound('click');
      setState((prev) => ({ ...prev, activeTab: tab }));
    },
    [playSound]
  );

  const openGame = useCallback(
    (gameId: GameId) => {
      playSound('click');
      setState((prev) => ({ ...prev, currentGame: gameId, activeTab: 'games' }));
    },
    [playSound]
  );

  const setWager = useCallback(
    (wager: number) => {
      playSound('click');
      setState((prev) => ({ ...prev, wager }));
    },
    [playSound]
  );

  const canClaimDaily = state.lastClaimDate !== getTodayKey();

  const claimDailyBonus = useCallback(() => {
    const today = getTodayKey();
    if (state.lastClaimDate === today) {
      playSound('click');
      showToast('Already Claimed', 'Your Royal Daily Vault opens again tomorrow.', 'gold');
      return false;
    }

    const nextStreak = Math.min(7, state.streak + 1);
    const coinReward = 350 + nextStreak * 50; // 400-700 coins
    const gemReward = 5 + (nextStreak >= 5 ? 3 : 0);

    const tx: Transaction = {
      id: `tx-${Date.now()}`,
      title: `Daily Vault Bonus (Day ${nextStreak})`,
      detail: `+${coinReward.toLocaleString()} Coins · +${gemReward} Gems`,
      amount: coinReward,
      gemsDelta: gemReward,
      type: 'bonus',
      timestamp: Date.now(),
    };

    playSound('win');
    setState((prev) => ({
      ...prev,
      coins: prev.coins + coinReward,
      gems: prev.gems + gemReward,
      streak: nextStreak,
      xp: prev.xp + 120,
      lastClaimDate: today,
      history: [tx, ...prev.history].slice(0, 60),
    }));

    showToast('Daily Bonus Claimed', `+${coinReward.toLocaleString()} Coins & +${gemReward} Gems credited!`, 'win');
    return true;
  }, [state.lastClaimDate, state.streak, playSound, showToast]);

  const recordGameOutcome = useCallback(
    (params: {
      gameId: GameId;
      gameName: string;
      wagerAmount: number;
      payoutAmount: number; // total returned to player (0 if lost, 2*wager if 2x win)
      detail: string;
    }) => {
      const { gameId, gameName, wagerAmount, payoutAmount, detail } = params;
      const netDelta = payoutAmount - wagerAmount;
      const isWin = netDelta > 0;
      const isPush = netDelta === 0;

      if (payoutAmount >= wagerAmount * 3) {
        playSound('jackpot');
      } else if (isWin) {
        playSound('win');
      } else if (isPush) {
        playSound('coin');
      } else {
        playSound('loss');
      }

      const tx: Transaction = {
        id: `tx-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        title: `${gameName} · ${isWin ? 'Victory' : isPush ? 'Push' : 'House Round'}`,
        detail,
        amount: netDelta,
        type: netDelta >= 0 ? 'win' : 'loss',
        gameId,
        timestamp: Date.now(),
      };

      const xpEarned = isWin ? Math.round(45 + wagerAmount * 0.08) : 20;

      setState((prev) => ({
        ...prev,
        coins: Math.max(0, prev.coins + netDelta),
        roundsPlayed: prev.roundsPlayed + 1,
        winsCount: isWin ? prev.winsCount + 1 : prev.winsCount,
        totalWagered: prev.totalWagered + wagerAmount,
        biggestWin: netDelta > prev.biggestWin ? netDelta : prev.biggestWin,
        xp: prev.xp + xpEarned,
        history: [tx, ...prev.history].slice(0, 60),
      }));

      if (isWin) {
        showToast(`${gameName} Win!`, `+${netDelta.toLocaleString()} Coins net profit (${detail})`, 'win');
      } else if (isPush) {
        showToast(`${gameName} Push`, `Wager returned (${detail})`, 'gold');
      } else {
        showToast(`${gameName}`, `${netDelta.toLocaleString()} Coins (${detail})`, 'loss');
      }
    },
    [playSound, showToast]
  );

  const recordWheelOfFortuneOutcome = useCallback(
    (params: { coinsAwarded: number; gemsAwarded: number; detail: string }) => {
      const { coinsAwarded, gemsAwarded, detail } = params;
      const now = Date.now();
      const cooldownMs = 4 * 60 * 60 * 1000;
      if (state.lastWheelOfFortuneSpinAt && now - state.lastWheelOfFortuneSpinAt < cooldownMs) {
        playSound('click');
        showToast('Cooldown Active', 'Golden Wheel of Fortune can be spun once every 4 hours.', 'gold');
        return;
      }

      if (coinsAwarded >= state.wager * 5 || gemsAwarded >= 20) {
        playSound('jackpot');
      } else {
        playSound('wheelWin');
      }

      const tx: Transaction = {
        id: `tx-${now}-${Math.random().toString(36).slice(2, 5)}`,
        title: 'Golden Wheel of Fortune',
        detail,
        amount: coinsAwarded,
        gemsDelta: gemsAwarded || undefined,
        type: 'bonus',
        gameId: 'wheel-of-fortune',
        timestamp: now,
      };

      setState((prev) => ({
        ...prev,
        coins: prev.coins + coinsAwarded,
        gems: prev.gems + gemsAwarded,
        roundsPlayed: prev.roundsPlayed + 1,
        winsCount: prev.winsCount + 1,
        biggestWin: coinsAwarded > prev.biggestWin ? coinsAwarded : prev.biggestWin,
        xp: prev.xp + 75,
        lastWheelOfFortuneSpinAt: now,
        history: [tx, ...prev.history].slice(0, 60),
      }));

      if (coinsAwarded > 0) {
        showToast('Wheel of Fortune!', `+${coinsAwarded.toLocaleString()} Coins (${detail})`, 'win');
      } else {
        showToast('Wheel of Fortune!', `+${gemsAwarded} Imperial Gems (${detail})`, 'win');
      }
    },
    [state.lastWheelOfFortuneSpinAt, state.wager, playSound, showToast]
  );

  const purchaseCoinPack = useCallback(
    (amount: number, bonusGems = 0, method = 'Royal Treasury', account?: string) => {
      playSound('coin');
      const acctSuffix = account && account.trim() ? ` · ${account.trim()}` : '';
      const tx: Transaction = {
        id: `tx-${Date.now()}`,
        title: `Deposit · ${method}`,
        detail: `+${amount.toLocaleString()} Coins${bonusGems > 0 ? ` · +${bonusGems} Gems` : ''}${acctSuffix}`,
        amount,
        gemsDelta: bonusGems,
        type: 'topup',
        timestamp: Date.now(),
      };

      setState((prev) => ({
        ...prev,
        coins: prev.coins + amount,
        gems: prev.gems + bonusGems,
        xp: prev.xp + Math.round(amount * 0.02),
        history: [tx, ...prev.history].slice(0, 60),
      }));

      showToast(
        `${method} Deposit`,
        `+${amount.toLocaleString()} Coins${bonusGems > 0 ? ` & +${bonusGems} Gems` : ''} credited.`,
        'win'
      );
    },
    [playSound, showToast]
  );

  const claimAdReward = useCallback(() => {
    const coinBonus = 150;
    const gemBonus = 2;
    playSound('win');
    const tx: Transaction = {
      id: `tx-${Date.now()}`,
      title: 'Rewarded Ad Bonus',
      detail: 'Royal Sponsor Video · +150 Coins · +2 Gems',
      amount: coinBonus,
      gemsDelta: gemBonus,
      type: 'bonus',
      timestamp: Date.now(),
    };

    setState((prev) => ({
      ...prev,
      coins: prev.coins + coinBonus,
      gems: prev.gems + gemBonus,
      xp: prev.xp + 35,
      history: [tx, ...prev.history].slice(0, 60),
    }));

    showToast('Ad Reward Claimed', '+150 Coins & +2 Imperial Gems credited!', 'win');
  }, [playSound, showToast]);

  const exchangeGemsForCoins = useCallback(
    (gemCost: number, coinReturn: number) => {
      if (state.gems < gemCost) {
        playSound('loss');
        showToast('Insufficient Gems', `You need ${gemCost} Imperial Gems for this exchange.`, 'loss');
        return;
      }
      playSound('coin');
      const tx: Transaction = {
        id: `tx-${Date.now()}`,
        title: 'Imperial Gem Exchange',
        detail: `Converted ${gemCost} Gems to ${coinReturn.toLocaleString()} Coins`,
        amount: coinReturn,
        gemsDelta: -gemCost,
        type: 'topup',
        timestamp: Date.now(),
      };

      setState((prev) => ({
        ...prev,
        coins: prev.coins + coinReturn,
        gems: prev.gems - gemCost,
        history: [tx, ...prev.history].slice(0, 60),
      }));
      showToast('Exchange Complete', `+${coinReturn.toLocaleString()} Coins credited!`, 'win');
    },
    [state.gems, playSound, showToast]
  );

  const withdrawCoins = useCallback(
    (amount: number, method: string, destination: string) => {
      const cleanAmount = Math.floor(amount);
      if (!Number.isFinite(cleanAmount) || cleanAmount < 100) {
        playSound('loss');
        showToast('Minimum Withdrawal', 'Minimum withdrawal is 100 Coins.', 'loss');
        return false;
      }
      if (cleanAmount > state.coins) {
        playSound('loss');
        showToast('Insufficient Balance', `Available balance is ${state.coins.toLocaleString()} Coins.`, 'loss');
        return false;
      }

      const trimmedDest = destination.trim() || 'Royal Vault Account';
      playSound('coin');
      const tx: Transaction = {
        id: `tx-${Date.now()}`,
        title: `Withdrawal · ${method}`,
        detail: `To ${trimmedDest}`,
        amount: -cleanAmount,
        type: 'withdraw',
        timestamp: Date.now(),
      };

      setState((prev) => ({
        ...prev,
        coins: prev.coins - cleanAmount,
        history: [tx, ...prev.history].slice(0, 60),
      }));

      showToast(
        'Withdrawal Submitted',
        `-${cleanAmount.toLocaleString()} Coins dispatched via ${method}.`,
        'gold'
      );
      return true;
    },
    [state.coins, playSound, showToast]
  );

  const sendFriendGift = useCallback(
    (friendId: string, friendName: string) => {
      if (state.giftedFriendIds.includes(friendId)) {
        playSound('click');
        showToast('Gift Already Sent', `You already sent royal tribute to ${friendName} today.`, 'gold');
        return;
      }
      if (state.coins < 50) {
        playSound('loss');
        showToast('Low Balance', 'Need at least 50 Coins to send a royal gift.', 'loss');
        return;
      }
      playSound('coin');
      const tx: Transaction = {
        id: `tx-${Date.now()}`,
        title: `Royal Gift · ${friendName}`,
        detail: 'Friend tribute (+25 XP earned)',
        amount: -50,
        type: 'gift',
        timestamp: Date.now(),
      };
      setState((prev) => ({
        ...prev,
        coins: prev.coins - 50,
        xp: prev.xp + 25,
        giftedFriendIds: [...prev.giftedFriendIds, friendId],
        history: [tx, ...prev.history].slice(0, 60),
      }));
      showToast('Gift Dispatched', `Sent 50 Coins to ${friendName} (+25 VIP XP).`, 'gold');
    },
    [state.coins, state.giftedFriendIds, playSound, showToast]
  );

  const toggleSound = useCallback(() => {
    setState((prev) => {
      const next = !prev.soundEnabled;
      soundEnabledRef.current = next;
      if (next) soundFX.click(true);
      return { ...prev, soundEnabled: next };
    });
  }, []);

  const toggleAnimations = useCallback(() => {
    playSound('click');
    setState((prev) => ({ ...prev, animationsEnabled: !prev.animationsEnabled }));
  }, [playSound]);

  const resetDemoState = useCallback(() => {
    playSound('click');
    window.localStorage.removeItem(STORAGE_KEY);
    setState(getInitialState());
    showToast('Account Reset', 'Zahid Avatar balance and ledger restored to starting state.', 'gold');
  }, [playSound, showToast]);

  const vipInfo = useMemo(() => getVipInfo(state.xp), [state.xp]);

  const leaderboard = useMemo<LeaderboardMember[]>(() => {
    const userWeeklyWins = state.history
      .filter((tx) => tx.type === 'win' && tx.amount > 0)
      .reduce((acc, tx) => acc + tx.amount, 0);

    const userRow: LeaderboardMember = {
      id: 'user-zahid',
      name: 'Zahid Avatar',
      initials: 'Z',
      vipTier: vipInfo.tier,
      coins: state.coins,
      weeklyWins: Math.max(userWeeklyWins, 1750),
      isUser: true,
    };

    return [...BASE_LEADERBOARD, userRow].sort((a, b) => b.coins - a.coins);
  }, [state.coins, state.history, vipInfo.tier]);

  const friends = useMemo(
    () =>
      ROYAL_FRIENDS.map((f) => ({
        ...f,
        giftedToday: state.giftedFriendIds.includes(f.id),
      })),
    [state.giftedFriendIds]
  );

  return {
    state,
    vipInfo,
    canClaimDaily,
    toasts,
    leaderboard,
    friends,
    playSound,
    soundController,
    dismissToast,
    showToast,
    setActiveTab,
    openGame,
    setWager,
    claimDailyBonus,
    claimAdReward,
    recordGameOutcome,
    recordWheelOfFortuneOutcome,
    purchaseCoinPack,
    exchangeGemsForCoins,
    withdrawCoins,
    sendFriendGift,
    toggleSound,
    toggleAnimations,
    resetDemoState,
  };
}
