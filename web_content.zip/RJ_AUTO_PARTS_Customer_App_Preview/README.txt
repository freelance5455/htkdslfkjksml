RJ AUTO PARTS — CUSTOMER APP PREVIEW (INVOICE QUANTITY FIX)

Invoice ના + અને − બટન સીધા click action વડે quantity બદલે છે.
Quantity બોક્સમાં નંબર લખીને પણ બદલી શકાય છે.
બદલાતાં line total, કુલ quantity, Grand Total અને payment amount ફરી ગણાય છે.

જૂની ZIP કાઢીને આ ZIP extract કરો અને અંદરની index.html નવી રીતે ખોલો.
આ UI demo છે; live payment અને Owner App backend હજી જોડવાના બાકી છે.
