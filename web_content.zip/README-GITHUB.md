# Salman ISP — GitHub سے APK بنانے کا بہترین طریقہ

یہ طریقہ میں نے آپ کے لیے بہترین چنا ہے، کیونکہ اس میں نہ Android Studio انسٹال کرنا پڑتا ہے، نہ کوئی اشتہار والی سائٹ استعمال کرنی پڑتی ہے، اور APK کے اندر ہماری HTML فائل ہی ہوتی ہے، اس لیے ایپ آف لائن بھی چلتی ہے۔ GitHub کا کلاؤڈ کمپیوٹر خود APK بنا کر دیتا ہے۔

## اس zip میں کیا ہے؟

- www/index.html — Salman ISP کی مکمل ایپ (انگلش، نئی تھیم، فوٹو والی ہیڈر)
- www/logo-512.png — APK آئیکن والا لوگو
- package.json اور capacitor.config.json — ایپ کا نام Salman ISP اور ID com.salmanisp.app
- .github/workflows/build-apk.yml — یہ فائل GitHub کو بتاتی ہے کہ APK کیسے بنانی ہے، اسے ہٹانا نہیں ہے

## طریقہ — آسان الفاظ میں

### 1. GitHub اکاؤنٹ بنائیں (مفت)
github.com کھولیں، Sign up کریں، ای میل اور پاسورڈ لگائیں۔

### 2. نئی Repository بنائیں
- اوپر + یا New بٹن دبائیں، پھر New repository چنیں۔
- Repository name لکھیں: salman-isp
- Public چنیں (پہلی بار کے لیے یہی آسان ہے)۔
- Create repository دبائیں۔

### 3. یہ فائلیں GitHub پر ڈالیں
سب سے آسان طریقہ کمپیوٹر سے ہے:
- اس zip کو کمپیوٹر پر Extract کریں، تاکہ www، package.json، capacitor.config.json اور .github والا فولڈر نظر آئے۔
- اگر کمپیوٹر پر git ہے تو اس فولڈر میں یہ کمانڈز لکھیں:
  git init
  git add .
  git commit -m "Salman ISP first build"
  git branch -M main
  git remote add origin https://github.com/APKA-USERNAME/salman-isp.git
  git push -u origin main
  (APKA-USERNAME کی جگہ اپنا GitHub username لکھیں)
- اگر git نہیں ہے تو GitHub کی ویب سائٹ پر repository کھول کر Upload files سے فائلیں ایک ایک کر کے ڈالیں، اور .github/workflows/build-apk.yml کے لیے Add file پھر Create new file چن کر راستہ .github/workflows/build-apk.yml لکھیں اور workflow والی فائل کا مواد پیسٹ کر دیں۔

نوٹ: .github والا فولڈر چھپا ہوا ہوتا ہے، اس لیے صرف zip اپ لوڈ کرنے سے کام نہیں چلے گا، فائلیں اسی ترتیب سے ہونی چاہییں جیسی اس zip میں ہیں۔

### 4. APK بننے کا انتظار کریں
- Repository میں اوپر Actions ٹیب کھولیں۔
- وہاں Build Salman ISP APK والی لائن چلے گی، 5 سے 10 منٹ لگ سکتے ہیں۔
- جب سبز ٹک آ جائے تو اس لائن پر کلک کریں، نیچے Artifacts میں salman-isp-apk نظر آئے گا۔
- اس پر کلک کر کے zip ڈاؤن لوڈ کریں، اس کے اندر app-debug.apk ہوگی۔

### 5. موبائل میں انسٹال کریں
- app-debug.apk کو موبائل میں بھیجیں، کھولیں، Unknown Sources کی اجازت دیں، انسٹال کریں۔
- اب ایپ کھولیں، ایڈمن والی جی میل اور پن سے لاگ ان کریں۔
- ٹیسٹ کے لیے انٹرنیٹ بند کر کے بھی ایپ کھول کر دیکھیں، ایپ کھلنی چاہیے۔ صرف WhatsApp والا بٹن انٹرنیٹ مانگے گا۔

## اگر Build فیل ہو جائے تو کیا کریں؟
- Actions والی لائن کھول کر سرخ والی غلطی دیکھیں، عام طور پر صرف ایک فائل کی جگہ غلط ہوتی ہے۔
- یقین کریں کہ www کے اندر index.html ہے، اور .github/workflows کے اندر build-apk.yml ہے۔
- پھر سے push کریں، GitHub دوبارہ خود ہی build چلا دے گا۔

## اہم احتیاط
- GitHub پر صرف یہ خالی والی ایپ فائل ڈالیں، اس میں کوئی کسٹمر ڈیٹا نہیں ہے۔
- جس بیک اپ فائل میں آپ کے اصلی کسٹمر ہوں، اسے GitHub پر کبھی اپ لوڈ نہ کریں۔
- یہ debug APK ٹیسٹ اور اپنے / ورکر کے فون کے لیے ہے۔ Play Store کے لیے بعد میں release والی signed APK بنانی پڑے گی۔
