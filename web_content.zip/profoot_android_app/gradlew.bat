@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "GRADLE_HOME=%USERPROFILE%\.gradle\profoot-distributions\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Gradle 8.9 is not installed in "%GRADLE_HOME%".
  echo Run this project in GitHub Actions or install Gradle 8.9 first.
  exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
