# NOELZIN1337 SkinLab — Android

Aplicativo demonstrativo de catálogo visual e montagem de combinações cosméticas. Não modifica o Free Fire, não injeta arquivos, não desbloqueia itens pagos e não acessa contas.

## Abrir e gerar APK
1. Extraia o ZIP.
2. Abra a pasta `NOELZIN1337_SkinLab_Android` no Android Studio.
3. Aguarde a sincronização do Gradle. É necessário Android SDK 35 e JDK 17 ou superior.
4. Para instalar no celular: conecte um Android com depuração USB ou use um emulador.
5. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos
- Catálogo demonstrativo por categoria.
- Busca e filtro.
- Favoritos salvos localmente no navegador interno.
- Montador de visual com slots de personagem, roupa, arma e mochila.
- Layout responsivo para celular.
- Funciona offline; não exige login nem permissões especiais.

## Personalização
Os itens demonstrativos estão no array `items` em `app/src/main/assets/index.html`. Substitua os nomes e descrições por conteúdo próprio/licenciado. Não use logotipos ou artes oficiais sem autorização.

## Limitações
- Não é um skin changer conectado ao jogo.
- Os itens e imagens são conceitos ilustrativos, não catálogo oficial.
- Não há integração com servidores, conta ou inventário do Free Fire.
- Este ambiente não possui Android SDK/Gradle instalados; por isso o APK não foi compilado aqui. O projeto está preparado para abrir no Android Studio e gerar o APK.

BY:NOELZIN1337 — © 2026
