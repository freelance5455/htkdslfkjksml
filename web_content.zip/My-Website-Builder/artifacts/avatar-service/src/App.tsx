import { Switch, Route, Router as WouterRouter, useLocation, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NavBar from "@/components/NavBar";
import HomePage from "@/pages/HomePage";
import BookingPage from "@/pages/BookingPage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import ProfilePage from "@/pages/ProfilePage";
import MyBookingsPage from "@/pages/MyBookingsPage";
import OwnerDashboard from "@/pages/OwnerDashboard";
import NotFound from "@/pages/not-found";
import { useAppStore } from "@/lib/store";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user } = useAppStore();
  if (!user) return <Redirect to="/login" />;
  return <Component />;
}

function Router() {
  return (
    <>
      <NavBar />
      <Switch>
        {/* Public routes — accessible without login */}
        <Route path="/login" component={LoginPage} />
        <Route path="/register" component={RegisterPage} />
        <Route path="/owner" component={OwnerDashboard} />

        {/* Protected routes — login required */}
        <Route path="/">
          <ProtectedRoute component={HomePage} />
        </Route>
        <Route path="/booking">
          <ProtectedRoute component={BookingPage} />
        </Route>
        <Route path="/profile">
          <ProtectedRoute component={ProfilePage} />
        </Route>
        <Route path="/my-bookings">
          <ProtectedRoute component={MyBookingsPage} />
        </Route>

        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
