import { useState, useRef } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useAppStore } from "@/lib/store";
import { useOwnerStore } from "@/lib/store";
import { useT } from "@/lib/useT";
import { useVerifyOwnerPassword } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { User, Globe, Phone, Instagram, Facebook, Lock, ChevronRight } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function SettingsDrawer({ open, onClose }: Props) {
  const t = useT();
  const { setLanguage } = useAppStore();
  const { setOwnerSession } = useOwnerStore();
  const [, navigate] = useLocation();

  const [showLangOptions, setShowLangOptions] = useState(false);
  const [showCareNumbers, setShowCareNumbers] = useState(false);
  const [otuClicks, setOtuClicks] = useState(0);
  const [showOtuDialog, setShowOtuDialog] = useState(false);
  const [otuPassword, setOtuPassword] = useState("");
  const [otuError, setOtuError] = useState("");
  const otuTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const verifyMutation = useVerifyOwnerPassword();

  const handleOtuClick = () => {
    const next = otuClicks + 1;
    setOtuClicks(next);
    if (otuTimer.current) clearTimeout(otuTimer.current);
    if (next >= 7) {
      setOtuClicks(0);
      setShowOtuDialog(true);
    } else {
      otuTimer.current = setTimeout(() => setOtuClicks(0), 3000);
    }
  };

  const handleOtuVerify = () => {
    setOtuError("");
    verifyMutation.mutate(
      { data: { password: otuPassword } },
      {
        onSuccess: (session) => {
          setOwnerSession(session);
          setShowOtuDialog(false);
          setOtuPassword("");
          onClose();
          navigate("/owner");
        },
        onError: () => {
          setOtuError("Invalid password. Please try again.");
        },
      }
    );
  };

  const langs = [
    { code: "en" as const, label: "English" },
    { code: "hi" as const, label: "हिन्दी" },
    { code: "or" as const, label: "ଓଡ଼ିଆ" },
  ];

  return (
    <>
      <Sheet open={open} onOpenChange={(v) => !v && onClose()}>
        <SheetContent side="right" className="w-80 p-0 flex flex-col">
          <SheetHeader className="px-6 py-5 border-b bg-gradient-to-r from-primary/10 to-primary/5">
            <SheetTitle className="text-lg font-bold text-foreground">{t("settings.title")}</SheetTitle>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto py-2">
            {/* Profile */}
            <button
              onClick={() => { onClose(); navigate("/profile"); }}
              className="w-full flex items-center gap-3 px-6 py-4 hover:bg-accent/50 transition-colors text-left"
            >
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="w-4 h-4 text-primary" />
              </div>
              <span className="flex-1 font-medium text-sm">{t("settings.profile")}</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>

            {/* Language */}
            <div>
              <button
                onClick={() => setShowLangOptions((v) => !v)}
                className="w-full flex items-center gap-3 px-6 py-4 hover:bg-accent/50 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                  <Globe className="w-4 h-4 text-primary" />
                </div>
                <span className="flex-1 font-medium text-sm">{t("settings.language")}</span>
                <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${showLangOptions ? "rotate-90" : ""}`} />
              </button>
              {showLangOptions && (
                <div className="px-6 pb-2 space-y-1">
                  {langs.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => { setLanguage(l.code); setShowLangOptions(false); }}
                      className="w-full text-left px-4 py-2 rounded-lg text-sm hover:bg-primary/10 hover:text-primary transition-colors font-medium"
                    >
                      {l.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Customer Care */}
            <div>
              <button
                onClick={() => setShowCareNumbers((v) => !v)}
                className="w-full flex items-center gap-3 px-6 py-4 hover:bg-accent/50 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                  <Phone className="w-4 h-4 text-primary" />
                </div>
                <span className="flex-1 font-medium text-sm">{t("settings.customer_care")}</span>
                <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${showCareNumbers ? "rotate-90" : ""}`} />
              </button>
              {showCareNumbers && (
                <div className="px-6 pb-3 space-y-3">
                  {["6370304437", "8457904442"].map((num) => (
                    <div key={num} className="flex items-center justify-between bg-muted/50 rounded-xl px-4 py-3">
                      <span className="text-sm font-semibold text-foreground">{num}</span>
                      <a
                        href={`tel:${num}`}
                        className="text-xs font-bold text-white bg-primary rounded-lg px-3 py-1.5 hover:opacity-90 transition-opacity"
                      >
                        {t("settings.call_now")}
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Instagram */}
            <a
              href="https://www.instagram.com/avtar_e_service?igsh=MWZsOHRoNnRoYmpmOQ=="
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center gap-3 px-6 py-4 hover:bg-accent/50 transition-colors"
            >
              <div className="w-9 h-9 rounded-full bg-pink-100 flex items-center justify-center">
                <Instagram className="w-4 h-4 text-pink-600" />
              </div>
              <span className="flex-1 font-medium text-sm">{t("settings.instagram")}</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </a>

            {/* Facebook */}
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center gap-3 px-6 py-4 hover:bg-accent/50 transition-colors"
            >
              <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center">
                <Facebook className="w-4 h-4 text-blue-600" />
              </div>
              <span className="flex-1 font-medium text-sm">{t("settings.facebook")}</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </a>

            {/* OTU — completely invisible tap zone */}
            <div className="px-6 py-4 border-t mt-2">
              <button
                onClick={handleOtuClick}
                className="w-full h-6 select-none outline-none"
                style={{ background: "transparent", border: "none", cursor: "default" }}
                aria-hidden="true"
                tabIndex={-1}
              />
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <Dialog open={showOtuDialog} onOpenChange={(v) => !v && (setShowOtuDialog(false), setOtuPassword(""), setOtuError(""))}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" /> Owner Access
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <Input
              type="password"
              placeholder="Enter owner password"
              value={otuPassword}
              onChange={(e) => setOtuPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleOtuVerify()}
              autoFocus
            />
            {otuError && <p className="text-sm text-destructive">{otuError}</p>}
            <Button
              className="w-full"
              onClick={handleOtuVerify}
              disabled={verifyMutation.isPending}
            >
              {verifyMutation.isPending ? "Verifying..." : "Verify"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
