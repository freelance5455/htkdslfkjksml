import { useState } from "react";
import { useLocation } from "wouter";
import { useAppStore, useOwnerStore } from "@/lib/store";
import { useT } from "@/lib/useT";
import SettingsDrawer from "./SettingsDrawer";
import { Home, Wrench, ClipboardList, Settings, User } from "lucide-react";

export default function NavBar() {
  const t = useT();
  const [location, navigate] = useLocation();
  const { user } = useAppStore();
  const { ownerSession } = useOwnerStore();
  const [settingsOpen, setSettingsOpen] = useState(false);

  const isActive = (path: string) => location === path;

  return (
    <>
      {/* Top Banner Header */}
      <header
        className="fixed top-0 left-0 right-0 z-50 shadow-lg"
        style={{ background: "var(--navy)" }}
      >
        <div className="max-w-lg mx-auto px-4 h-16 flex items-center justify-between">
          {/* AES Logo Badge */}
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-3"
          >
            <img
              src="/aes-logo.png"
              alt="AES Logo"
              style={{ width: 44, height: 44, borderRadius: "50%", objectFit: "cover" }}
            />

            {/* Title */}
            <div className="flex flex-col leading-tight">
              <span
                className="copper-text font-black text-sm tracking-wide"
                style={{ fontFamily: "Outfit, sans-serif" }}
              >
                AVTAR E SERVICE
              </span>
              <span
                style={{
                  color: "#8aa0cc",
                  fontSize: 9,
                  fontWeight: 600,
                  letterSpacing: 1.5,
                  fontFamily: "Outfit, sans-serif",
                }}
              >
                BOOKING PLATFORM
              </span>
            </div>
          </button>

          {/* Right controls */}
          <div className="flex items-center gap-1">
            {user ? (
              <button
                onClick={() => navigate("/profile")}
                className="p-2 rounded-xl transition-colors"
                style={{ color: "#8aa0cc" }}
              >
                <User className="w-5 h-5" />
              </button>
            ) : null}
            <button
              onClick={() => setSettingsOpen(true)}
              className="p-2 rounded-xl transition-colors"
              style={{ color: "#8aa0cc" }}
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Bottom Nav */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-50 shadow-2xl"
        style={{ background: "var(--navy)", borderTop: "1px solid rgba(168,98,42,0.3)" }}
      >
        <div className="max-w-lg mx-auto flex items-center justify-around h-16 px-2">
          <button
            onClick={() => navigate("/")}
            className="flex flex-col items-center gap-1 py-2 px-5 rounded-xl transition-colors"
          >
            <Home
              className="w-5 h-5"
              style={{ color: isActive("/") ? "var(--copper-light)" : "#6b84b0" }}
            />
            <span
              style={{
                fontSize: 10,
                fontWeight: 600,
                color: isActive("/") ? "var(--copper-light)" : "#6b84b0",
              }}
            >
              {t("nav.home")}
            </span>
          </button>

          <button
            onClick={() => navigate("/booking")}
            className="flex flex-col items-center gap-1 py-2 px-5 rounded-xl transition-colors"
          >
            <Wrench
              className="w-5 h-5"
              style={{ color: isActive("/booking") ? "var(--copper-light)" : "#6b84b0" }}
            />
            <span
              style={{
                fontSize: 10,
                fontWeight: 600,
                color: isActive("/booking") ? "var(--copper-light)" : "#6b84b0",
              }}
            >
              {t("nav.book")}
            </span>
          </button>

          <button
            onClick={() => navigate("/my-bookings")}
            className="flex flex-col items-center gap-1 py-2 px-5 rounded-xl transition-colors"
          >
            <ClipboardList
              className="w-5 h-5"
              style={{ color: isActive("/my-bookings") ? "var(--copper-light)" : "#6b84b0" }}
            />
            <span
              style={{
                fontSize: 10,
                fontWeight: 600,
                color: isActive("/my-bookings") ? "var(--copper-light)" : "#6b84b0",
              }}
            >
              {t("nav.bookings")}
            </span>
          </button>
        </div>
      </nav>

      <SettingsDrawer open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </>
  );
}
