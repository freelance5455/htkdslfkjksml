import { useState } from "react";
import { useLocation } from "wouter";
import { useListBookings, useListBookingPhotos, useLoginUser } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/useT";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ChevronDown, Image, Calendar, MapPin, Wrench, LogIn, Eye, EyeOff } from "lucide-react";

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  confirmed: "bg-blue-100 text-blue-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

function BookingCard({ booking }: { booking: { id: number; serviceName: string; status: string; scheduledTime: string; district: string; state: string; issueDescription?: string | null } }) {
  const [expanded, setExpanded] = useState(false);
  const { data: photos = [] } = useListBookingPhotos(booking.id, { query: { enabled: expanded } });

  const dt = new Date(booking.scheduledTime);
  const dateStr = isNaN(dt.getTime()) ? booking.scheduledTime : dt.toLocaleString("en-IN");

  return (
    <motion.div layout className="bg-white rounded-2xl overflow-hidden shadow-sm" style={{ border: "1.5px solid #dde5f0" }}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Wrench className="w-3.5 h-3.5" style={{ color: "var(--copper)" }} />
              <span className="font-bold text-sm" style={{ color: "var(--navy)" }}>{booking.serviceName}</span>
            </div>
            <span className={`inline-block text-[11px] font-bold px-2.5 py-0.5 rounded-full capitalize ${statusColors[booking.status] ?? "bg-muted text-muted-foreground"}`}>
              {booking.status}
            </span>
          </div>
          <span className="text-[11px] text-gray-300 font-mono">#{booking.id}</span>
        </div>
        <div className="space-y-1.5 text-xs text-gray-500">
          <div className="flex items-center gap-1.5"><Calendar className="w-3 h-3" /><span>{dateStr}</span></div>
          <div className="flex items-center gap-1.5"><MapPin className="w-3 h-3" /><span>{booking.district}, {booking.state}</span></div>
        </div>
        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex items-center gap-1 text-xs font-semibold mt-3 hover:opacity-70 transition-opacity"
          style={{ color: "var(--copper)" }}
        >
          <Image className="w-3 h-3" /> Work Photos
          <ChevronDown className={`w-3 h-3 transition-transform ${expanded ? "rotate-180" : ""}`} />
        </button>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden" style={{ borderTop: "1px solid #eef0f5" }}>
            <div className="p-4">
              {photos.length === 0 ? (
                <p className="text-xs text-gray-400 text-center py-3">No work photos yet</p>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {photos.map((p) => (
                    <a key={p.id} href={p.imageUrl} target="_blank" rel="noopener noreferrer">
                      <img src={p.imageUrl} alt="Work photo" className="w-full h-20 object-cover rounded-xl hover:opacity-80 transition-opacity" style={{ border: "1px solid #eef0f5" }} onError={(e) => { (e.target as HTMLImageElement).src = "https://placehold.co/80x80?text=Photo"; }} />
                    </a>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function QuickLogin() {
  const { setUser } = useAppStore();
  const loginMutation = useLoginUser();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [, navigate] = useLocation();

  const handleLogin = () => {
    if (!identifier.trim() || !password.trim()) { setError("Enter mobile/email and password"); return; }
    setError("");
    loginMutation.mutate(
      { data: { identifier: identifier.trim(), password } },
      {
        onSuccess: (data) => { setUser(data.user); },
        onError: () => setError("Invalid credentials. Try again."),
      }
    );
  };

  const inputStyle: React.CSSProperties = {
    border: "2px solid #dde5f0",
    borderRadius: 12,
    padding: "10px 14px",
    fontSize: 14,
    fontFamily: "Plus Jakarta Sans, sans-serif",
    color: "var(--navy)",
    width: "100%",
    outline: "none",
    background: "white",
  };

  return (
    <div className="min-h-screen pt-16 pb-24 flex items-center justify-center px-5">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: "var(--navy)" }}>
            <LogIn className="w-8 h-8" style={{ color: "var(--copper-light)" }} />
          </div>
          <h2 className="text-2xl font-black" style={{ fontFamily: "Outfit, sans-serif", color: "var(--navy)" }}>My Bookings</h2>
          <p className="text-sm text-gray-500 mt-1">Login to see your bookings</p>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm space-y-3" style={{ border: "2px solid var(--navy)" }}>
          <div>
            <label className="block text-xs font-bold mb-1" style={{ color: "var(--navy)" }}>Mobile Number or Email</label>
            <input style={inputStyle} type="text" placeholder="9876543210 or email@example.com" value={identifier} onChange={(e) => setIdentifier(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs font-bold mb-1" style={{ color: "var(--navy)" }}>Password</label>
            <div className="relative">
              <input style={{ ...inputStyle, paddingRight: 40 }} type={showPw ? "text" : "password"} placeholder="Your password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleLogin()} />
              <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" onClick={() => setShowPw(v => !v)}>
                {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}
          <button
            onClick={handleLogin}
            disabled={loginMutation.isPending}
            className="w-full py-3 rounded-xl font-black text-white text-sm transition-all active:scale-95 disabled:opacity-60"
            style={{ background: "var(--navy)", fontFamily: "Outfit, sans-serif" }}
          >
            {loginMutation.isPending ? "Logging in…" : "Login →"}
          </button>
          <p className="text-center text-xs text-gray-400">
            No account?{" "}
            <button className="font-bold underline" style={{ color: "var(--copper)" }} onClick={() => navigate("/register")}>Register here</button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

export default function MyBookingsPage() {
  const t = useT();
  const [, navigate] = useLocation();
  const { user } = useAppStore();

  const { data: bookings = [], isLoading } = useListBookings(
    { userId: user?.id },
    { query: { enabled: !!user?.id, staleTime: 0, refetchOnMount: "always" } }
  );

  if (!user) return <QuickLogin />;

  return (
    <div className="min-h-screen pt-16 pb-24" style={{ background: "#f0f4fa" }}>
      <div className="sticky top-16 z-40 px-4 py-3 shadow-sm" style={{ background: "var(--navy)" }}>
        <h1 className="font-black text-base copper-text" style={{ fontFamily: "Outfit, sans-serif" }}>{t("nav.bookings")}</h1>
        <p className="text-[11px]" style={{ color: "#8aa0cc" }}>{user.fullName}</p>
      </div>

      <div className="max-w-lg mx-auto px-4 py-5">
        {isLoading ? (
          <div className="space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="bg-white rounded-2xl h-28 animate-pulse" />)}</div>
        ) : bookings.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "#e8eef8" }}>
              <Wrench className="w-8 h-8 text-gray-300" />
            </div>
            <p className="font-medium mb-4 text-gray-400">No bookings yet</p>
            <button onClick={() => navigate("/booking")} className="text-white font-bold rounded-xl px-6 py-3 text-sm" style={{ background: "var(--navy)" }}>
              Book a Service
            </button>
          </div>
        ) : (
          <motion.div className="space-y-3">
            {bookings.map((b, i) => (
              <motion.div key={b.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                <BookingCard booking={b} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}
