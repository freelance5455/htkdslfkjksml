import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useGetUser, useUpdateUser } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { motion } from "framer-motion";
import { LogOut, ArrowLeft, Camera, Upload } from "lucide-react";

export default function ProfilePage() {
  const [, navigate] = useLocation();
  const { user, setUser, logout } = useAppStore();
  const updateMutation = useUpdateUser();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const { data: profile } = useGetUser(user?.id ?? 0, { query: { enabled: !!user?.id } });

  const [form, setForm] = useState({ fullName: "", email: "", fullAddress: "" });
  const [profileImageUrl, setProfileImageUrl] = useState("");
  const [saved, setSaved] = useState(false);
  const [uploadErr, setUploadErr] = useState("");

  useEffect(() => {
    if (profile) {
      setForm({ fullName: profile.fullName ?? "", email: profile.email ?? "", fullAddress: profile.fullAddress ?? "" });
      setProfileImageUrl(profile.profileImageUrl ?? "");
    }
  }, [profile]);

  if (!user) {
    return (
      <div className="min-h-screen pt-16 pb-24 flex items-center justify-center px-5">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Please login to view your profile</p>
          <button onClick={() => navigate("/login")} className="text-white font-bold rounded-xl px-6 py-3 text-sm" style={{ background: "var(--navy)" }}>Login</button>
        </div>
      </div>
    );
  }

  const initials = (user.fullName ?? "?").split(" ").map((w: string) => w[0]).slice(0, 2).join("").toUpperCase();

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadErr("");
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Upload failed");
      const { url } = await res.json() as { url: string };
      setProfileImageUrl(url);
      updateMutation.mutate(
        { userId: user.id, data: { profileImageUrl: url } },
        { onSuccess: (updated) => { setUser(updated); } }
      );
    } catch {
      setUploadErr("Upload failed. Try again.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleSave = () => {
    updateMutation.mutate(
      { userId: user.id, data: { fullName: form.fullName, email: form.email || undefined, fullAddress: form.fullAddress || undefined, profileImageUrl: profileImageUrl || undefined } },
      { onSuccess: (updated) => { setUser(updated); setSaved(true); setTimeout(() => setSaved(false), 2000); } }
    );
  };

  const inputStyle: React.CSSProperties = {
    border: "2px solid #dde5f0",
    borderRadius: 12,
    padding: "10px 14px",
    fontSize: 14,
    fontFamily: "Plus Jakarta Sans, sans-serif",
    color: "var(--navy)",
    width: "100%",
    outline: "none",
    background: "white",
  };

  return (
    <div className="min-h-screen pt-16 pb-24" style={{ background: "#f0f4fa" }}>
      <div className="sticky top-16 z-40 px-4 py-3 shadow-sm" style={{ background: "var(--navy)" }}>
        <button onClick={() => navigate("/")} className="flex items-center gap-2 text-sm mb-0.5" style={{ color: "#8aa0cc" }}>
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
        <h1 className="font-black text-base copper-text" style={{ fontFamily: "Outfit, sans-serif" }}>My Profile</h1>
      </div>

      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Profile photo — clickable to upload */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <button
              onClick={() => fileRef.current?.click()}
              className="relative block rounded-3xl overflow-hidden focus:outline-none"
              style={{ width: 96, height: 96 }}
              title="Tap to change photo"
            >
              {profileImageUrl ? (
                <img src={profileImageUrl} alt="Profile" className="w-24 h-24 object-cover" />
              ) : (
                <div className="w-24 h-24 flex items-center justify-center" style={{ background: "var(--navy)" }}>
                  <span className="text-white text-3xl font-black" style={{ fontFamily: "Outfit, sans-serif" }}>{initials}</span>
                </div>
              )}
              {/* Overlay */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity">
                <Camera className="w-7 h-7 text-white" />
              </div>
            </button>

            {/* Camera badge */}
            <button
              onClick={() => fileRef.current?.click()}
              className="absolute -bottom-1 -right-1 w-8 h-8 rounded-xl flex items-center justify-center shadow-md active:scale-95 transition-all"
              style={{ background: "var(--copper)" }}
            >
              {uploading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Upload className="w-4 h-4 text-white" />
              )}
            </button>

            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
          </div>

          {uploadErr && <p className="text-xs text-red-500 mt-2">{uploadErr}</p>}
          <p className="text-xs text-gray-400 mt-2">Tap photo to change</p>

          <div className="mt-3 text-center">
            <p className="font-black text-lg" style={{ fontFamily: "Outfit, sans-serif", color: "var(--navy)" }}>{user.fullName}</p>
            <p className="text-sm font-semibold" style={{ color: "var(--copper)" }}>📱 {user.mobile}</p>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white rounded-3xl p-5 shadow-sm space-y-4" style={{ border: "2px solid var(--navy)" }}>
          {[
            { label: "Full Name", key: "fullName", type: "text", placeholder: "Your full name" },
            { label: "Email Address", key: "email", type: "email", placeholder: "email@example.com (optional)" },
            { label: "Full Address", key: "fullAddress", type: "text", placeholder: "House no., Street, Area, City" },
          ].map(({ label, key, type, placeholder }) => (
            <div key={key}>
              <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{label}</label>
              <input
                style={inputStyle}
                type={type}
                placeholder={placeholder}
                value={form[key as keyof typeof form]}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
              />
            </div>
          ))}

          {/* Mobile (read-only) */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>Mobile Number</label>
            <input
              style={{ ...inputStyle, background: "#f5f7fa", color: "#94a3b8", cursor: "not-allowed" }}
              type="tel"
              value={user.mobile}
              readOnly
            />
            <p className="text-[10px] text-gray-400 mt-1">Mobile number cannot be changed</p>
          </div>

          <button
            onClick={handleSave}
            disabled={updateMutation.isPending}
            className="w-full py-3 rounded-xl font-black text-white text-sm transition-all active:scale-95 disabled:opacity-60 shadow-md"
            style={{ background: saved ? "#16a34a" : "var(--navy)", fontFamily: "Outfit, sans-serif" }}
          >
            {saved ? "✓ Saved!" : updateMutation.isPending ? "Saving…" : "Save Changes"}
          </button>

          <button
            onClick={() => { logout(); navigate("/"); }}
            className="w-full flex items-center justify-center gap-2 py-3 text-sm font-bold rounded-xl border-2 transition-colors"
            style={{ color: "#dc2626", borderColor: "rgba(220,38,38,0.3)" }}
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </div>
    </div>
  );
}
