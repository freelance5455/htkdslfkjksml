import { useState } from "react";
import { useLocation } from "wouter";
import { useLoginUser } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/useT";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { Eye, EyeOff, ArrowLeft } from "lucide-react";

export default function LoginPage() {
  const t = useT();
  const [, navigate] = useLocation();
  const { setUser } = useAppStore();
  const loginMutation = useLoginUser();

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = () => {
    setError("");
    loginMutation.mutate(
      { data: { identifier, password } },
      {
        onSuccess: (session) => {
          setUser(session.user, session.token);
          navigate("/");
        },
        onError: () => setError("Invalid mobile/email or password"),
      }
    );
  };

  return (
    <div className="min-h-screen pt-14 pb-24 flex items-center justify-center px-5">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <button onClick={() => navigate("/")} className="flex items-center gap-2 text-muted-foreground text-sm mb-6 hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <div className="bg-primary/5 rounded-3xl p-6">
          <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center mb-5 shadow-lg shadow-primary/30">
            <span className="text-white text-xl font-black" style={{ fontFamily: "'Outfit', sans-serif" }}>A</span>
          </div>
          <h1 className="text-2xl font-black text-foreground mb-1" style={{ fontFamily: "'Outfit', sans-serif" }}>
            {t("auth.login_title")}
          </h1>
          <p className="text-muted-foreground text-sm mb-6">{t("auth.login_desc")}</p>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-1.5">{t("auth.mobile_or_email")}</label>
              <Input
                placeholder="Mobile or Email"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5">{t("auth.password")}</label>
              <div className="relative">
                <Input
                  type={showPw ? "text" : "password"}
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
                <button
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button
              className="w-full h-11 font-bold rounded-xl"
              onClick={handleLogin}
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "Logging in..." : t("auth.login_btn")}
            </Button>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-5">
            {t("auth.no_account")}{" "}
            <button onClick={() => navigate("/register")} className="text-primary font-semibold hover:underline">
              {t("auth.register_link")}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
