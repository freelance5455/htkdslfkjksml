import { useLocation } from "wouter";
import { useListServices } from "@workspace/api-client-react";
import { useT } from "@/lib/useT";
import { Shield, Clock, Home, Star } from "lucide-react";
import { motion } from "framer-motion";

export default function HomePage() {
  const t = useT();
  const [, navigate] = useLocation();
  const { data: services = [], isLoading } = useListServices();

  return (
    <div className="min-h-screen pb-24 pt-16">

      {/* Hero Banner */}
      <div
        className="relative overflow-hidden"
        style={{
          background: "linear-gradient(135deg, var(--navy) 0%, var(--navy-light) 60%, #2a3f6a 100%)",
        }}
      >
        {/* Decorative circuit-board style dots */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full"
              style={{
                width: i % 3 === 0 ? 80 : 40,
                height: i % 3 === 0 ? 80 : 40,
                background: "rgba(168,98,42,0.5)",
                top: `${(i * 31) % 100}%`,
                left: `${(i * 47 + 10) % 100}%`,
                filter: "blur(20px)",
              }}
            />
          ))}
        </div>

        <div className="max-w-lg mx-auto px-5 pt-5 pb-6 relative flex items-start gap-4">
          {/* AES Logo large */}
          <img
            src="/aes-logo.png"
            alt="AES Logo"
            className="flex-shrink-0"
            style={{ width: 110, height: 110, borderRadius: "50%", objectFit: "cover" }}
          />

          {/* Title block */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col justify-center"
          >
            <h1
              className="copper-text font-black leading-tight"
              style={{ fontFamily: "Outfit, sans-serif", fontSize: "1.6rem", lineHeight: 1.15 }}
            >
              AVTAR E SERVICE
            </h1>
            <h2
              className="copper-text font-black leading-tight"
              style={{ fontFamily: "Outfit, sans-serif", fontSize: "1.6rem", lineHeight: 1.15 }}
            >
              BOOKING
            </h2>
            <h2
              className="copper-text font-black"
              style={{ fontFamily: "Outfit, sans-serif", fontSize: "1.6rem", lineHeight: 1.15 }}
            >
              PLATFORM
            </h2>
            <div className="flex items-center gap-1 mt-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              ))}
              <span style={{ color: "#8aa0cc", fontSize: 11, marginLeft: 4 }}>Trusted in Odisha</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Booking your service section */}
      <div className="max-w-lg mx-auto px-5 mt-5">
        <h2
          className="text-center font-black text-xl mb-1"
          style={{ fontFamily: "Outfit, sans-serif", color: "var(--navy)" }}
        >
          Booking your service now
        </h2>

        {/* Trust badges */}
        <div className="grid grid-cols-3 gap-3 mt-4 mb-5">
          {[
            {
              Icon: Shield,
              label: "Verified Experts",
              sub: "Certified technicians for your safety",
            },
            {
              Icon: Clock,
              label: "On-time Service",
              sub: "Reliable arrival & efficient completion",
            },
            {
              Icon: Home,
              label: "Doorstep Repair",
              sub: "Full repairs right at your home",
            },
          ].map(({ Icon, label, sub }) => (
            <div
              key={label}
              className="bg-white rounded-2xl p-3 text-center shadow-sm"
              style={{ border: "1px solid #e8d5c0" }}
            >
              <div
                className="feature-icon-circle mx-auto mb-2"
                style={{ width: 40, height: 40 }}
              >
                <Icon className="w-5 h-5" style={{ color: "var(--copper)" }} />
              </div>
              <p
                className="font-bold text-xs leading-tight"
                style={{ color: "var(--navy)", fontFamily: "Outfit, sans-serif" }}
              >
                {label}
              </p>
              <p className="text-[9px] text-gray-500 mt-0.5 leading-tight">{sub}</p>
            </div>
          ))}
        </div>

        {/* Main content: booking form + call panel */}
        <div className="flex gap-3">
          {/* Booking quick-form card */}
          <div
            className="flex-1 bg-white rounded-2xl p-4 shadow-sm"
            style={{ border: "2px solid var(--navy)" }}
          >
            {/* Step 1 */}
            <div className="mb-3">
              <p
                className="text-xs font-bold mb-1.5"
                style={{ color: "var(--copper)" }}
              >
                Step 1: Select Your Service
              </p>
              <select
                className="w-full rounded-lg px-3 py-2 text-sm font-medium bg-white"
                style={{
                  border: "1.5px solid var(--navy)",
                  color: "var(--navy)",
                  fontFamily: "Plus Jakarta Sans, sans-serif",
                }}
                onClick={() => navigate("/booking")}
                onChange={() => navigate("/booking")}
                defaultValue=""
              >
                <option value="" disabled>
                  {isLoading ? "Loading..." : "Choose a service…"}
                </option>
                {services.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Step 2 */}
            <div className="mb-3">
              <p
                className="text-xs font-bold mb-1.5"
                style={{ color: "var(--copper)" }}
              >
                Step 2: Choose a Preferred Date &amp; Time
              </p>
              <p className="text-xs font-semibold mb-1" style={{ color: "var(--navy)" }}>
                Mobile Number:
              </p>
              <input
                type="tel"
                placeholder="Enter your mobile number..."
                className="w-full rounded-lg px-3 py-2 text-sm mb-2"
                style={{
                  border: "1.5px solid #ccd5e0",
                  fontFamily: "Plus Jakarta Sans, sans-serif",
                  color: "var(--navy)",
                }}
                onFocus={() => navigate("/booking")}
              />
              <p className="text-xs font-semibold mb-1" style={{ color: "var(--navy)" }}>
                Select Preferred Time:
              </p>
              <select
                className="w-full rounded-lg px-3 py-2 text-sm bg-white"
                style={{
                  border: "1.5px solid var(--navy)",
                  color: "#aab2c0",
                  fontFamily: "Plus Jakarta Sans, sans-serif",
                }}
                onClick={() => navigate("/booking")}
                onChange={() => navigate("/booking")}
                defaultValue=""
              >
                <option value="" disabled>
                  Select Time
                </option>
                <option>Morning (9am – 12pm)</option>
                <option>Afternoon (12pm – 3pm)</option>
                <option>Evening (3pm – 6pm)</option>
              </select>
            </div>

            {/* Step 3 */}
            <div className="mb-4">
              <p
                className="text-xs font-bold mb-1.5"
                style={{ color: "var(--copper)" }}
              >
                Step 3: Describe the Issue
              </p>
              <textarea
                placeholder="Describe the Issue"
                rows={3}
                className="w-full rounded-lg px-3 py-2 text-sm resize-none"
                style={{
                  border: "1.5px solid #ccd5e0",
                  fontFamily: "Plus Jakarta Sans, sans-serif",
                  color: "var(--navy)",
                }}
                onFocus={() => navigate("/booking")}
              />
            </div>

            <button
              onClick={() => navigate("/booking")}
              className="w-full py-2.5 rounded-xl font-bold text-white text-sm transition-all active:scale-95"
              style={{ background: "var(--navy)", fontFamily: "Outfit, sans-serif" }}
            >
              Book Now →
            </button>
          </div>

          {/* Call panel */}
          <div className="w-28 flex-shrink-0">
            <div
              className="rounded-2xl p-3 text-center text-white mb-3"
              style={{ background: "var(--navy)" }}
            >
              <p
                className="font-black text-xs leading-tight mb-2"
                style={{ color: "var(--copper-light)", fontFamily: "Outfit, sans-serif" }}
              >
                Call Our Experts Directly
              </p>

              {/* Technician photo */}
              <div
                className="w-16 h-16 rounded-full mx-auto mb-2 overflow-hidden"
                style={{ border: "2px solid var(--copper)" }}
              >
                <img src="/electrician.png" alt="Expert" className="w-full h-full object-cover object-top" />
              </div>

              <p
                className="font-bold text-xs mb-0.5"
                style={{ color: "var(--copper-light)" }}
              >
                Need urgent help?
              </p>
              <p className="text-[9px] opacity-70 mb-2">
                (e.g., Short circuit, Power failure)
              </p>

              <a
                href="tel:6370304437"
                className="block w-full py-2 rounded-xl font-black text-xs text-white text-center transition-all active:scale-95"
                style={{
                  background: "var(--copper)",
                  fontFamily: "Outfit, sans-serif",
                }}
              >
                Call Now
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
