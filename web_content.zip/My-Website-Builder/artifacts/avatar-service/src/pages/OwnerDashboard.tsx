import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import {
  useListBookings,
  useGetOwnerStats,
  useUpdateBooking,
  useForwardBooking,
  useAddBookingPhoto,
  useListBookingPhotos,
} from "@workspace/api-client-react";
import { useOwnerStore } from "@/lib/store";
import { motion, AnimatePresence } from "framer-motion";
import {
  LogOut, Search, ChevronDown, Upload, Image, CheckCircle2,
  Package, Users, ClipboardList, Phone, MapPin, Calendar, RefreshCw,
} from "lucide-react";

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 border-yellow-200",
  confirmed: "bg-blue-100 text-blue-700 border-blue-200",
  completed: "bg-green-100 text-green-700 border-green-200",
  cancelled: "bg-red-100 text-red-700 border-red-200",
};

type CustomerUser = {
  id: number;
  fullName: string;
  mobile: string;
  email: string | null;
  fullAddress: string | null;
  createdAt: string;
};

function PhotoUpload({
  bookingId,
  ownerSession,
  onUploaded,
}: {
  bookingId: number;
  ownerSession: { ownerId: number };
  onUploaded: () => void;
}) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const addPhotoMutation = useAddBookingPhoto();

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Upload failed");
      const { url } = await res.json() as { url: string };
      await new Promise<void>((resolve, reject) => {
        addPhotoMutation.mutate(
          { bookingId, data: { uploadedByOwnerId: ownerSession.ownerId, imageUrl: url } },
          { onSuccess: () => { resolve(); onUploaded(); }, onError: reject }
        );
      });
    } catch {
      setError("Upload failed. Try again.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div>
      <label
        className="flex items-center gap-2 cursor-pointer border-2 border-dashed rounded-xl px-3 py-2.5 text-xs font-semibold transition-colors hover:border-primary"
        style={{ borderColor: "#c3cfe0", color: "var(--navy)" }}
      >
        <Upload className="w-4 h-4" style={{ color: "var(--copper)" }} />
        {uploading ? "Uploading…" : "Tap to upload photo"}
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          disabled={uploading}
          onChange={handleFile}
        />
      </label>
      {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
    </div>
  );
}

function BookingRow({
  booking, ownerLevel, ownerSession,
}: {
  booking: {
    id: number; customerName: string; customerMobile: string; serviceName: string;
    status: string; scheduledTime: string; district: string; state: string;
    customerAddress?: string; issueDescription?: string | null;
    assignedOwnerId?: number | null; confirmedByOwnerId?: number | null;
  };
  ownerLevel: number;
  ownerSession: { ownerId: number; ownerLevel: number; ownerName: string };
}) {
  const [expanded, setExpanded] = useState(false);
  const [forwarding, setForwarding] = useState(false);

  const updateMutation = useUpdateBooking();
  const forwardMutation = useForwardBooking();
  const { data: photos = [], refetch: refetchPhotos } = useListBookingPhotos(booking.id, {
    query: { enabled: expanded },
  });

  const isConfirmed = !!booking.confirmedByOwnerId;

  const handleStatus = (status: string) => {
    updateMutation.mutate({
      bookingId: booking.id,
      data: { status: status as "pending" | "confirmed" | "completed" | "cancelled" },
    });
  };

  const handleConfirm = () => {
    if (isConfirmed) return;
    updateMutation.mutate({
      bookingId: booking.id,
      data: { status: "confirmed", confirmedByOwnerId: ownerSession.ownerId },
    });
  };

  const handleForward = (toOwnerId: number) => {
    forwardMutation.mutate({ bookingId: booking.id, data: { toOwnerId } });
    setForwarding(false);
  };

  const dt = new Date(booking.scheduledTime);
  const dateStr = isNaN(dt.getTime()) ? booking.scheduledTime : dt.toLocaleString("en-IN");

  return (
    <motion.div layout className="bg-white rounded-2xl overflow-hidden shadow-sm" style={{ border: "1.5px solid #dde5f0" }}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <p className="font-bold text-sm" style={{ color: "var(--navy)" }}>{booking.customerName}</p>
            <a href={`tel:${booking.customerMobile}`} className="text-xs font-semibold flex items-center gap-1 mt-0.5" style={{ color: "var(--copper)" }}>
              <Phone className="w-3 h-3" />{booking.customerMobile}
            </a>
          </div>
          <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border capitalize ${statusColors[booking.status] ?? "bg-muted text-muted-foreground border-border"}`}>
            {booking.status}
          </span>
        </div>
        <p className="text-xs mb-0.5 font-semibold" style={{ color: "var(--navy)" }}>{booking.serviceName}</p>
        <p className="text-xs text-gray-500 mb-0.5 flex items-center gap-1">
          <MapPin className="w-3 h-3" />{booking.district}, {booking.state}
        </p>
        <p className="text-xs text-gray-500 mb-3 flex items-center gap-1">
          <Calendar className="w-3 h-3" />{dateStr}
        </p>
        {booking.customerAddress && (
          <p className="text-xs text-gray-500 mb-0.5 flex items-start gap-1">
            <MapPin className="w-3 h-3 mt-0.5 shrink-0" />
            <span>{booking.customerAddress}</span>
          </p>
        )}
        {booking.issueDescription && (
          <p className="text-xs text-gray-500 italic mb-3">"{booking.issueDescription}"</p>
        )}

        {/* Sub-owner: confirm only */}
        {ownerLevel > 1 && !isConfirmed && booking.assignedOwnerId === ownerSession.ownerId && (
          <button
            onClick={handleConfirm}
            disabled={updateMutation.isPending}
            className="text-xs font-bold text-white px-3 py-1.5 rounded-lg hover:opacity-90 transition-opacity mb-2"
            style={{ background: "#16a34a" }}
          >
            Accept / Confirm
          </button>
        )}
        {isConfirmed && ownerLevel > 1 && (
          <div className="flex items-center gap-1 text-xs font-semibold mb-2" style={{ color: "#16a34a" }}>
            <CheckCircle2 className="w-3 h-3" /> Confirmed
          </div>
        )}

        {/* Main owner actions */}
        {ownerLevel === 1 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {(["confirmed", "completed", "cancelled"] as const).map((s) =>
              booking.status !== s ? (
                <button
                  key={s}
                  onClick={() => handleStatus(s)}
                  disabled={updateMutation.isPending}
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border capitalize transition-opacity hover:opacity-80 ${statusColors[s]}`}
                >
                  Mark {s}
                </button>
              ) : null
            )}
            <button
              onClick={() => setForwarding((v) => !v)}
              className="text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-colors hover:opacity-80"
              style={{ background: "#eff3fa", color: "var(--navy)", borderColor: "#c3cfe0" }}
            >
              Forward →
            </button>
          </div>
        )}

        {forwarding && ownerLevel === 1 && (
          <div className="flex gap-2 mb-2">
            {[2, 3].map((id) => (
              <button
                key={id}
                onClick={() => handleForward(id)}
                className="text-[11px] font-bold px-3 py-1.5 rounded-lg transition-colors hover:opacity-80"
                style={{ background: "var(--copper-pale)", color: "var(--copper)", border: "1px solid #d4914e" }}
              >
                To Owner {id}
              </button>
            ))}
            <button onClick={() => setForwarding(false)} className="text-[11px] text-gray-400 px-2">Cancel</button>
          </div>
        )}

        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex items-center gap-1 text-xs font-semibold hover:opacity-70 transition-opacity"
          style={{ color: "var(--copper)" }}
        >
          <Image className="w-3 h-3" /> Photos
          <ChevronDown className={`w-3 h-3 transition-transform ${expanded ? "rotate-180" : ""}`} />
        </button>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
            style={{ borderTop: "1px solid #eef0f5" }}
          >
            <div className="p-4 space-y-3">
              <PhotoUpload bookingId={booking.id} ownerSession={ownerSession} onUploaded={refetchPhotos} />
              {photos.length === 0 ? (
                <p className="text-xs text-center text-gray-400 py-2">No photos yet</p>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {photos.map((p) => (
                    <a key={p.id} href={p.imageUrl} target="_blank" rel="noopener noreferrer">
                      <img
                        src={p.imageUrl}
                        alt="Work"
                        className="w-full h-20 object-cover rounded-xl hover:opacity-80 transition-opacity"
                        style={{ border: "1px solid #eef0f5" }}
                        onError={(e) => { (e.target as HTMLImageElement).src = "https://placehold.co/80x80?text=Photo"; }}
                      />
                    </a>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function CustomerList() {
  const [customers, setCustomers] = useState<CustomerUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/users")
      .then((r) => r.json())
      .then((data: CustomerUser[]) => { setCustomers(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = customers.filter((c) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return c.fullName.toLowerCase().includes(q) || c.mobile.includes(q) || (c.email ?? "").toLowerCase().includes(q);
  });

  return (
    <div>
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          className="w-full pl-9 pr-4 py-2.5 text-sm rounded-2xl outline-none transition-colors bg-white"
          style={{ border: "1.5px solid #dde5f0", color: "var(--navy)" }}
          placeholder="Search by name, mobile, email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-2xl h-16 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Users className="w-10 h-10 mx-auto mb-3 text-gray-300" />
          <p className="text-sm text-gray-400">No customers found</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="bg-white rounded-2xl p-4"
              style={{ border: "1.5px solid #dde5f0" }}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate" style={{ color: "var(--navy)" }}>{c.fullName}</p>
                  <a href={`tel:${c.mobile}`} className="flex items-center gap-1 text-xs font-semibold mt-0.5" style={{ color: "var(--copper)" }}>
                    <Phone className="w-3 h-3" />{c.mobile}
                  </a>
                  {c.email && <p className="text-xs text-gray-400 truncate mt-0.5">{c.email}</p>}
                  {c.fullAddress && (
                    <p className="text-xs text-gray-400 mt-0.5 flex items-start gap-1">
                      <MapPin className="w-3 h-3 flex-shrink-0 mt-0.5" />
                      <span className="truncate">{c.fullAddress}</span>
                    </p>
                  )}
                </div>
                <span className="text-[10px] text-gray-300 whitespace-nowrap">#{c.id}</span>
              </div>
            </motion.div>
          ))}
          <p className="text-center text-xs text-gray-400 pt-1">{filtered.length} customer{filtered.length !== 1 ? "s" : ""}</p>
        </div>
      )}
    </div>
  );
}

type Tab = "bookings" | "customers";
type StatusFilter = "all" | "pending" | "confirmed" | "completed" | "cancelled";

export default function OwnerDashboard() {
  const [, navigate] = useLocation();
  const { ownerSession, logoutOwner } = useOwnerStore();
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<Tab>("bookings");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");

  const ownerLevel = ownerSession?.ownerLevel ?? 0;
  const ownerId = ownerSession?.ownerId;

  const queryParams = ownerLevel === 1 ? {} : { ownerId };

  const { data: bookings = [], isLoading, refetch: refetchBookings } = useListBookings(queryParams, { query: { enabled: !!ownerSession, refetchInterval: 30_000 } });
  const { data: stats, refetch: refetchStats } = useGetOwnerStats(
    { ownerId: ownerLevel !== 1 ? ownerId : undefined },
    { query: { enabled: !!ownerSession } }
  );

  if (!ownerSession) {
    return (
      <div className="min-h-screen pt-14 pb-24 flex items-center justify-center px-5">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Owner access required. Use OTU in Settings.</p>
          <button
            onClick={() => navigate("/")}
            className="text-white font-bold rounded-xl px-6 py-3 text-sm"
            style={{ background: "var(--navy)" }}
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  const filtered = bookings.filter((b) => {
    const matchStatus = statusFilter === "all" || b.status === statusFilter;
    if (!matchStatus) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      b.customerName.toLowerCase().includes(q) ||
      b.serviceName.toLowerCase().includes(q) ||
      b.district.toLowerCase().includes(q)
    );
  });

  const statCards = [
    { label: "Total", key: "all" as StatusFilter, value: stats?.total ?? bookings.length, color: "var(--navy)" },
    { label: "Pending", key: "pending" as StatusFilter, value: stats?.pending ?? 0, color: "#ca8a04" },
    { label: "Confirmed", key: "confirmed" as StatusFilter, value: stats?.confirmed ?? 0, color: "#2563eb" },
    { label: "Completed", key: "completed" as StatusFilter, value: stats?.completed ?? 0, color: "#16a34a" },
    { label: "Cancelled", key: "cancelled" as StatusFilter, value: stats?.cancelled ?? 0, color: "#dc2626" },
  ];

  return (
    <div className="min-h-screen pt-16 pb-24" style={{ background: "#f0f4fa" }}>
      {/* Header */}
      <div className="sticky top-16 z-40 px-4 py-3 flex items-center justify-between shadow-sm" style={{ background: "var(--navy)" }}>
        <div>
          <h1 className="font-black text-base copper-text" style={{ fontFamily: "Outfit, sans-serif" }}>
            Owner Dashboard
          </h1>
          <p className="text-[11px]" style={{ color: "#8aa0cc" }}>{ownerSession.ownerName}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { void refetchBookings(); void refetchStats(); }}
            className="flex items-center gap-1 text-xs font-semibold rounded-xl px-3 py-2 border transition-all active:scale-90"
            style={{ color: "var(--copper-light)", borderColor: "rgba(168,98,42,0.35)", background: "rgba(168,98,42,0.12)" }}
            title="Refresh"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => { logoutOwner(); navigate("/"); }}
            className="flex items-center gap-1.5 text-xs font-semibold rounded-xl px-3 py-2 border transition-colors"
            style={{ color: "#f87171", borderColor: "rgba(248,113,113,0.3)", background: "rgba(248,113,113,0.08)" }}
          >
            <LogOut className="w-3.5 h-3.5" /> Logout
          </button>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-5">
        {/* Tabs */}
        <div className="flex gap-2 mb-5">
          {[
            { key: "bookings" as Tab, label: "Bookings", icon: ClipboardList },
            ...(ownerLevel === 1 ? [{ key: "customers" as Tab, label: "Customer Data", icon: Users }] : []),
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex-1 justify-center"
              style={
                tab === key
                  ? { background: "var(--navy)", color: "white" }
                  : { background: "white", color: "var(--navy)", border: "1.5px solid #dde5f0" }
              }
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {tab === "customers" ? (
          <CustomerList />
        ) : (
          <>
            {/* Stat cards (clickable status filter) */}
            {ownerLevel === 1 && stats && (
              <div className="grid grid-cols-5 gap-1.5 mb-4">
                {statCards.map(({ label, key, value, color }) => (
                  <button
                    key={key}
                    onClick={() => setStatusFilter(statusFilter === key ? "all" : key)}
                    className="rounded-2xl p-2.5 text-center transition-all active:scale-95"
                    style={{
                      background: statusFilter === key ? "var(--navy)" : "white",
                      border: statusFilter === key ? "2px solid var(--copper)" : "1.5px solid #dde5f0",
                      boxShadow: statusFilter === key ? "0 2px 8px rgba(15,29,58,0.2)" : undefined,
                    }}
                  >
                    <p
                      className="text-lg font-black leading-none"
                      style={{
                        fontFamily: "Outfit, sans-serif",
                        color: statusFilter === key ? "white" : color,
                      }}
                    >
                      {value}
                    </p>
                    <p
                      className="text-[9px] font-semibold mt-0.5 leading-tight"
                      style={{ color: statusFilter === key ? "#8aa0cc" : "#94a3b8" }}
                    >
                      {label}
                    </p>
                  </button>
                ))}
              </div>
            )}

            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                className="w-full pl-9 pr-4 py-2.5 text-sm rounded-2xl outline-none bg-white transition-colors"
                style={{ border: "1.5px solid #dde5f0", color: "var(--navy)" }}
                placeholder="Search by name, service, area..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            {statusFilter !== "all" && (
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold capitalize" style={{ color: "var(--copper)" }}>
                  Showing: {statusFilter}
                </p>
                <button
                  onClick={() => setStatusFilter("all")}
                  className="text-xs text-gray-400 hover:text-gray-600 underline"
                >
                  Clear filter
                </button>
              </div>
            )}

            {/* Bookings list */}
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl h-28 animate-pulse" />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-12">
                <Package className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                <p className="text-sm text-gray-400">
                  {search ? "No results found" : statusFilter !== "all" ? `No ${statusFilter} bookings` : "No bookings yet"}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map((b, i) => (
                  <motion.div key={b.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                    <BookingRow booking={b} ownerLevel={ownerLevel} ownerSession={ownerSession} />
                  </motion.div>
                ))}
                <p className="text-center text-xs text-gray-400 pt-1">{filtered.length} booking{filtered.length !== 1 ? "s" : ""}</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
