import { useState } from "react";
import { useLocation } from "wouter";
import { useRegisterUser, useLoginUser } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/useT";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";

export default function RegisterPage() {
  const t = useT();
  const [, navigate] = useLocation();
  const { setUser } = useAppStore();
  const registerMutation = useRegisterUser();
  const loginMutation = useLoginUser();

  const [form, setForm] = useState({ fullName: "", mobile: "", email: "", password: "" });
  const [error, setError] = useState("");

  const handleRegister = () => {
    setError("");
    if (!form.fullName || !form.mobile || !form.password) {
      setError("Please fill all required fields");
      return;
    }
    registerMutation.mutate(
      { data: { fullName: form.fullName, mobile: form.mobile, email: form.email || undefined, password: form.password } },
      {
        onSuccess: () => {
          loginMutation.mutate(
            { data: { identifier: form.mobile, password: form.password } },
            {
              onSuccess: (session) => { setUser(session.user, session.token); navigate("/"); },
            }
          );
        },
        onError: () => setError("This mobile or email is already registered"),
      }
    );
  };

  return (
    <div className="min-h-screen pt-14 pb-24 flex items-center justify-center px-5">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <button onClick={() => navigate("/login")} className="flex items-center gap-2 text-muted-foreground text-sm mb-6 hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <div className="bg-primary/5 rounded-3xl p-6">
          <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center mb-5 shadow-lg shadow-primary/30">
            <span className="text-white text-xl font-black">A</span>
          </div>
          <h1 className="text-2xl font-black text-foreground mb-1" style={{ fontFamily: "'Outfit', sans-serif" }}>
            {t("auth.register_title")}
          </h1>
          <p className="text-muted-foreground text-sm mb-6">{t("auth.register_desc")}</p>

          <div className="space-y-4">
            {[
              { label: t("auth.fullname"), key: "fullName", type: "text", required: true },
              { label: t("auth.mobile"), key: "mobile", type: "tel", required: true },
              { label: t("auth.email"), key: "email", type: "email", required: false },
              { label: t("auth.password"), key: "password", type: "password", required: true },
            ].map(({ label, key, type, required }) => (
              <div key={key}>
                <label className="block text-sm font-semibold mb-1.5">
                  {label} {required && <span className="text-destructive">*</span>}
                </label>
                <Input
                  type={type}
                  placeholder={label}
                  value={form[key as keyof typeof form]}
                  onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                />
              </div>
            ))}
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button
              className="w-full h-11 font-bold rounded-xl"
              onClick={handleRegister}
              disabled={registerMutation.isPending || loginMutation.isPending}
            >
              {registerMutation.isPending ? "Creating account..." : t("auth.register_btn")}
            </Button>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-5">
            {t("auth.has_account")}{" "}
            <button onClick={() => navigate("/login")} className="text-primary font-semibold hover:underline">
              {t("auth.login_link")}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
