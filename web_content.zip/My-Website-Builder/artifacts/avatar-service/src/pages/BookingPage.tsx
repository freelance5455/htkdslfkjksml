import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useListServices, useCreateBooking, useUpdateBooking } from "@workspace/api-client-react";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/useT";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { CheckCircle2, ArrowLeft, Phone, Pencil, Lock } from "lucide-react";

function playBookingSound() {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const notes = [523.25, 659.25, 783.99, 1046.50];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.value = freq;
      const start = ctx.currentTime + i * 0.18;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.35, start + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.4);
      osc.start(start);
      osc.stop(start + 0.4);
    });
  } catch { /* ignore if AudioContext unavailable */ }
}

const EDIT_WINDOW_SECS = 120;

export default function BookingPage() {
  const t = useT();
  const [, navigate] = useLocation();
  const { user } = useAppStore();
  const { data: services = [] } = useListServices();
  const createBooking = useCreateBooking();
  const updateBooking = useUpdateBooking();

  const [form, setForm] = useState({
    customerName: user?.fullName ?? "",
    customerMobile: user?.mobile ?? "",
    customerAddress: user?.fullAddress ?? "",
    district: "",
    state: "",
    serviceId: "",
    scheduledTime: "",
    issueDescription: "",
  });

  const [done, setDone] = useState(false);
  const [createdId, setCreatedId] = useState<number | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [editSaved, setEditSaved] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(EDIT_WINDOW_SECS);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!done) return;
    setSecondsLeft(EDIT_WINDOW_SECS);
    timerRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) { clearInterval(timerRef.current!); return 0; }
        return s - 1;
      });
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [done]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.customerName.trim()) e.customerName = "Required";
    if (!form.customerMobile.trim()) {
      e.customerMobile = "Required";
    } else if (!/^\d{10}$/.test(form.customerMobile.trim())) {
      e.customerMobile = "Enter a valid 10-digit mobile number";
    }
    if (!form.customerAddress.trim()) {
      e.customerAddress = "Address is required";
    } else if (form.customerAddress.trim().length < 10) {
      e.customerAddress = "Please enter a complete address (house no., street, area)";
    }
    if (!form.district.trim()) e.district = "Required";
    if (!form.state.trim()) e.state = "Required";
    if (!form.serviceId) e.serviceId = "Please select a service";
    if (!form.scheduledTime) e.scheduledTime = "Please select a date and time";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    createBooking.mutate(
      {
        data: {
          userId: user?.id ?? 0,
          customerName: form.customerName,
          customerMobile: form.customerMobile,
          customerAddress: form.customerAddress,
          district: form.district,
          state: form.state,
          serviceId: Number(form.serviceId),
          scheduledTime: form.scheduledTime,
          issueDescription: form.issueDescription || undefined,
        },
      },
      {
        onSuccess: (booking) => {
          setCreatedId(booking.id);
          setDone(true);
          playBookingSound();
        },
      }
    );
  };

  const handleEditSave = () => {
    if (!createdId || secondsLeft === 0) return;
    updateBooking.mutate(
      {
        bookingId: createdId,
        data: {
          customerAddress: form.customerAddress,
          district: form.district,
          state: form.state,
          scheduledTime: form.scheduledTime,
          issueDescription: form.issueDescription || undefined,
        },
      },
      {
        onSuccess: () => {
          setEditSaved(true);
          setEditMode(false);
          setTimeout(() => setEditSaved(false), 2000);
        },
      }
    );
  };

  const inputClass = (key: string) =>
    `w-full rounded-xl px-3 py-2.5 text-sm font-medium outline-none transition-all ${errors[key] ? "border-2 border-red-400" : "border-2"}`;

  const inputStyle = (key: string): React.CSSProperties => ({
    borderColor: errors[key] ? "#ef4444" : "#ccd5e0",
    color: "var(--navy)",
    fontFamily: "Plus Jakarta Sans, sans-serif",
    background: "white",
  });

  /* ─── Confirmation / edit screen ─── */
  if (done) {
    const canEdit = secondsLeft > 0;
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    const timerStr = `${mins}:${secs.toString().padStart(2, "0")}`;

    /* Edit form */
    if (editMode && canEdit) {
      return (
        <div className="min-h-screen pt-16 pb-24" style={{ background: "#f0f4fa" }}>
          <div className="sticky top-16 z-40 px-4 py-3 shadow-sm flex items-center justify-between" style={{ background: "var(--navy)" }}>
            <div>
              <h1 className="font-black text-base copper-text" style={{ fontFamily: "Outfit, sans-serif" }}>Edit Booking</h1>
              <p className="text-[11px]" style={{ color: "#f87171" }}>⏱ {timerStr} remaining</p>
            </div>
            <button onClick={() => setEditMode(false)} className="text-xs font-semibold px-3 py-1.5 rounded-xl border" style={{ color: "#8aa0cc", borderColor: "rgba(255,255,255,0.15)" }}>
              Cancel
            </button>
          </div>
          <div className="max-w-lg mx-auto px-4 py-5 space-y-4">
            <div className="bg-white rounded-2xl p-4 space-y-4" style={{ border: "2px solid var(--navy)" }}>
              {/* Address */}
              <div>
                <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>Full Address</label>
                <input className={inputClass("customerAddress")} style={inputStyle("customerAddress")} value={form.customerAddress} onChange={(e) => setForm((f) => ({ ...f, customerAddress: e.target.value }))} />
              </div>
              {/* District + State */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>District</label>
                  <input className={inputClass("district")} style={inputStyle("district")} value={form.district} onChange={(e) => setForm((f) => ({ ...f, district: e.target.value }))} />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>State</label>
                  <input className={inputClass("state")} style={inputStyle("state")} value={form.state} onChange={(e) => setForm((f) => ({ ...f, state: e.target.value }))} />
                </div>
              </div>
              {/* Time */}
              <div>
                <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>Scheduled Date & Time</label>
                <input type="datetime-local" className={inputClass("scheduledTime")} style={inputStyle("scheduledTime")} value={form.scheduledTime} onChange={(e) => setForm((f) => ({ ...f, scheduledTime: e.target.value }))} />
              </div>
              {/* Issue */}
              <div>
                <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>Issue Description</label>
                <Textarea value={form.issueDescription} onChange={(e) => setForm((f) => ({ ...f, issueDescription: e.target.value }))} rows={3} style={{ borderColor: "#ccd5e0", borderRadius: 12, color: "var(--navy)" }} />
              </div>
              <button
                onClick={handleEditSave}
                disabled={updateBooking.isPending}
                className="w-full py-3 rounded-xl font-black text-white text-sm active:scale-95 transition-all shadow-md disabled:opacity-60"
                style={{ background: "var(--navy)", fontFamily: "Outfit, sans-serif" }}
              >
                {updateBooking.isPending ? "Saving…" : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      );
    }

    /* Success screen */
    return (
      <div className="min-h-screen pt-16 pb-24 flex items-center justify-center px-5" style={{ background: "#f0f4fa" }}>
        <div className="text-center w-full max-w-sm">
          {/* Burst rings */}
          <div className="relative flex items-center justify-center mb-6" style={{ height: 160 }}>
            {[1, 2, 3].map((i) => (
              <motion.div
                key={i}
                className="absolute rounded-full"
                style={{ background: `rgba(168,98,42,${0.12 - i * 0.03})` }}
                initial={{ width: 80, height: 80, opacity: 0.8 }}
                animate={{ width: 80 + i * 55, height: 80 + i * 55, opacity: 0 }}
                transition={{ duration: 1.2, delay: i * 0.22, repeat: Infinity, repeatDelay: 0.6 }}
              />
            ))}
            <motion.div
              initial={{ scale: 0.3, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 18, delay: 0.1 }}
              className="relative z-10 w-24 h-24 rounded-full flex items-center justify-center shadow-xl"
              style={{ background: "linear-gradient(135deg, var(--copper) 0%, #c87e3e 100%)" }}
            >
              <CheckCircle2 className="w-12 h-12 text-white" />
            </motion.div>
          </div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35, duration: 0.5 }}>
            <h2 className="text-2xl font-black mb-2" style={{ fontFamily: "Outfit, sans-serif", color: "var(--navy)" }}>
              Booking Confirmed! 🎉
            </h2>
            <div className="rounded-2xl px-5 py-3 mx-auto mb-3 inline-block" style={{ background: "var(--navy)" }}>
              <p className="font-black text-sm tracking-wide" style={{ color: "var(--copper-light)", fontFamily: "Outfit, sans-serif" }}>
                Thank you for Avatar e Service Booking
              </p>
            </div>
            <p className="text-sm mb-4" style={{ color: "#6b7a99" }}>
              We'll contact you soon. Our expert will visit at your scheduled time.
            </p>

            {/* 2-minute edit window */}
            <div className="mb-5 rounded-2xl p-3 mx-auto" style={{ background: canEdit ? "#eff8ec" : "#f5f5f5", border: `1.5px solid ${canEdit ? "#86efac" : "#e5e7eb"}` }}>
              {canEdit ? (
                <div className="flex items-center justify-between gap-3">
                  <div className="text-left">
                    <p className="text-xs font-bold text-green-700">✏️ Edit window open</p>
                    <p className="text-[11px] text-green-600">Closes in {timerStr}</p>
                  </div>
                  <button
                    onClick={() => { setEditMode(true); setEditSaved(false); }}
                    className="flex items-center gap-1.5 text-xs font-black px-3 py-2 rounded-xl text-white active:scale-95 transition-all"
                    style={{ background: "#16a34a" }}
                  >
                    <Pencil className="w-3 h-3" /> Edit
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 justify-center text-gray-400">
                  <Lock className="w-3.5 h-3.5" />
                  <p className="text-xs font-semibold">Booking locked — edit window closed</p>
                </div>
              )}
              {editSaved && <p className="text-xs text-green-700 font-semibold mt-1 text-center">✓ Changes saved!</p>}
            </div>

            <div className="flex gap-3 justify-center">
              <button
                onClick={() => navigate("/")}
                className="px-6 py-2.5 rounded-xl font-bold text-sm border-2 transition-all active:scale-95"
                style={{ borderColor: "var(--navy)", color: "var(--navy)" }}
              >
                Go Home
              </button>
              {user && (
                <button
                  onClick={() => navigate("/my-bookings")}
                  className="px-6 py-2.5 rounded-xl font-bold text-sm text-white transition-all active:scale-95 shadow-md"
                  style={{ background: "var(--navy)" }}
                >
                  My Bookings
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  /* ─── Booking form ─── */
  return (
    <div className="min-h-screen pt-16 pb-24">
      {/* Top bar */}
      <div
        className="sticky top-16 z-40 px-4 py-3 flex items-center gap-3 shadow-sm"
        style={{ background: "var(--navy)" }}
      >
        <button onClick={() => navigate("/")} style={{ color: "#8aa0cc" }}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="font-black text-base copper-text" style={{ fontFamily: "Outfit, sans-serif" }}>
          {t("booking.title")}
        </h1>
      </div>

      <div className="max-w-lg mx-auto px-4 py-5">
        <div className="bg-white rounded-3xl p-5 shadow-sm space-y-4" style={{ border: "2px solid var(--navy)" }}>
          {/* Name */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.name")}</label>
            <input className={inputClass("customerName")} style={inputStyle("customerName")} value={form.customerName} onChange={(e) => setForm((f) => ({ ...f, customerName: e.target.value }))} />
            {errors.customerName && <p className="text-xs text-red-500 mt-1">{errors.customerName}</p>}
          </div>

          {/* Mobile */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.mobile")}</label>
            <input type="tel" inputMode="numeric" maxLength={10} className={inputClass("customerMobile")} style={inputStyle("customerMobile")} value={form.customerMobile} onChange={(e) => setForm((f) => ({ ...f, customerMobile: e.target.value.replace(/\D/g, "").slice(0, 10) }))} />
            {errors.customerMobile && <p className="text-xs text-red-500 mt-1">{errors.customerMobile}</p>}
          </div>

          {/* Address */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.address")}</label>
            <input className={inputClass("customerAddress")} style={inputStyle("customerAddress")} placeholder="House no., Street, Area, City" value={form.customerAddress} onChange={(e) => setForm((f) => ({ ...f, customerAddress: e.target.value }))} />
            {errors.customerAddress && <p className="text-xs text-red-500 mt-1">{errors.customerAddress}</p>}
          </div>

          {/* District + State */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.district")}</label>
              <input className={inputClass("district")} style={inputStyle("district")} value={form.district} onChange={(e) => setForm((f) => ({ ...f, district: e.target.value }))} />
              {errors.district && <p className="text-xs text-red-500 mt-1">{errors.district}</p>}
            </div>
            <div>
              <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.state")}</label>
              <input className={inputClass("state")} style={inputStyle("state")} value={form.state} onChange={(e) => setForm((f) => ({ ...f, state: e.target.value }))} />
              {errors.state && <p className="text-xs text-red-500 mt-1">{errors.state}</p>}
            </div>
          </div>

          {/* Service */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.service")}</label>
            <select
              className={inputClass("serviceId")}
              style={{ ...inputStyle("serviceId"), appearance: "none" }}
              value={form.serviceId}
              onChange={(e) => setForm((f) => ({ ...f, serviceId: e.target.value }))}
            >
              <option value="">{t("booking.selectService")}</option>
              {services.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            {errors.serviceId && <p className="text-xs text-red-500 mt-1">{errors.serviceId}</p>}
          </div>

          {/* Date + Time */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.time")}</label>
            <input type="datetime-local" className={inputClass("scheduledTime")} style={inputStyle("scheduledTime")} value={form.scheduledTime} onChange={(e) => setForm((f) => ({ ...f, scheduledTime: e.target.value }))} />
            {errors.scheduledTime && <p className="text-xs text-red-500 mt-1">{errors.scheduledTime}</p>}
          </div>

          {/* Issue */}
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--navy)" }}>{t("booking.issue")}</label>
            <Textarea
              value={form.issueDescription}
              onChange={(e) => setForm((f) => ({ ...f, issueDescription: e.target.value }))}
              rows={3}
              style={{ borderColor: "#ccd5e0", borderRadius: 12, color: "var(--navy)" }}
            />
          </div>

          {/* Expert call strip */}
          <div className="rounded-2xl p-4 flex items-center gap-3" style={{ background: "var(--navy)" }}>
            <Phone className="w-5 h-5 shrink-0" style={{ color: "var(--copper-light)" }} />
            <div className="flex-1">
              <p className="text-xs font-bold text-white">Need help booking?</p>
              <p className="text-[11px]" style={{ color: "#8aa0cc" }}>Call our expert</p>
            </div>
            <a href="tel:+917381636781" className="text-xs font-black px-3 py-1.5 rounded-lg" style={{ background: "var(--copper)", color: "white" }}>Call</a>
          </div>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={createBooking.isPending}
            className="w-full py-3.5 rounded-xl font-black text-white text-sm transition-all active:scale-95 shadow-lg disabled:opacity-60"
            style={{ background: "var(--navy)", fontFamily: "Outfit, sans-serif" }}
          >
            {createBooking.isPending ? "Booking…" : t("booking.submit")}
          </button>
        </div>
      </div>
    </div>
  );
}
