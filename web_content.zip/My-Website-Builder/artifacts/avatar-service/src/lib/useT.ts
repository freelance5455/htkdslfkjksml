import { translations, type TranslationKey } from "./i18n";
import { useAppStore } from "./store";

export function useT() {
  const language = useAppStore((s) => s.language);
  const t = (key: TranslationKey): string => {
    const dict = translations[language] as Record<string, string>;
    const en = translations.en as Record<string, string>;
    return dict[key] ?? en[key] ?? key;
  };
  return t;
}
