import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, OwnerSession } from "@workspace/api-client-react";

export type Language = "en" | "hi" | "or";

interface AppState {
  language: Language;
  setLanguage: (lang: Language) => void;
  
  user: User | null;
  token: string | null;
  setUser: (user: User | null, token?: string | null) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      language: "en",
      setLanguage: (language) => set({ language }),
      
      user: null,
      token: null,
      setUser: (user, token) => set((state) => ({ 
        user, 
        token: token !== undefined ? token : state.token 
      })),
      logout: () => set({ user: null, token: null }),
    }),
    {
      name: "avatar-e-service-storage",
    }
  )
);

interface OwnerState {
  ownerSession: OwnerSession | null;
  setOwnerSession: (session: OwnerSession | null) => void;
  logoutOwner: () => void;
}

export const useOwnerStore = create<OwnerState>()(
  persist(
    (set) => ({
      ownerSession: null,
      setOwnerSession: (ownerSession) => set({ ownerSession }),
      logoutOwner: () => set({ ownerSession: null }),
    }),
    {
      name: "avatar-owner-session",
      storage: {
        getItem: (name) => {
          const str = sessionStorage.getItem(name);
          if (!str) return null;
          return JSON.parse(str);
        },
        setItem: (name, value) => {
          sessionStorage.setItem(name, JSON.stringify(value));
        },
        removeItem: (name) => {
          sessionStorage.removeItem(name);
        },
      },
    }
  )
);
