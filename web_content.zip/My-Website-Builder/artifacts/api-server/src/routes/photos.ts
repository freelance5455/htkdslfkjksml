import { Router } from "express";
import { db, workPhotosTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { AddBookingPhotoBody } from "@workspace/api-zod";

const router = Router();

function toPhotoResponse(p: typeof workPhotosTable.$inferSelect) {
  return { id: p.id, bookingId: p.bookingId, uploadedByOwnerId: p.uploadedByOwnerId, imageUrl: p.imageUrl, createdAt: p.createdAt.toISOString() };
}

router.get("/bookings/:bookingId/photos", async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  if (isNaN(bookingId)) { res.status(400).json({ error: "Invalid booking id" }); return; }
  const photos = await db.select().from(workPhotosTable).where(eq(workPhotosTable.bookingId, bookingId));
  res.json(photos.map(toPhotoResponse));
});

router.post("/bookings/:bookingId/photos", async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  if (isNaN(bookingId)) { res.status(400).json({ error: "Invalid booking id" }); return; }
  const parse = AddBookingPhotoBody.safeParse(req.body);
  if (!parse.success) { res.status(400).json({ error: "Invalid input" }); return; }
  const [photo] = await db
    .insert(workPhotosTable)
    .values({ bookingId, uploadedByOwnerId: parse.data.uploadedByOwnerId, imageUrl: parse.data.imageUrl })
    .returning();
  res.status(201).json(toPhotoResponse(photo));
});

router.delete("/bookings/:bookingId/photos/:photoId", async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  const photoId = parseInt(req.params.photoId);
  if (isNaN(bookingId) || isNaN(photoId)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [photo] = await db
    .select()
    .from(workPhotosTable)
    .where(and(eq(workPhotosTable.id, photoId), eq(workPhotosTable.bookingId, bookingId)))
    .limit(1);

  if (!photo) { res.status(404).json({ error: "Photo not found" }); return; }

  const ageMs = Date.now() - photo.createdAt.getTime();
  if (ageMs > 5 * 60 * 1000) {
    res.status(403).json({ error: "Delete window expired" });
    return;
  }

  await db.delete(workPhotosTable).where(eq(workPhotosTable.id, photoId));
  res.json({ success: true });
});

export default router;
