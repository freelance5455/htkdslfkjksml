import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import servicesRouter from "./services";
import bookingsRouter from "./bookings";
import photosRouter from "./photos";
import ownerRouter from "./owner";
import uploadRouter from "./upload";

const router: IRouter = Router();

router.use(healthRouter);
router.use(uploadRouter);
router.use(usersRouter);
router.use(servicesRouter);
router.use(bookingsRouter);
router.use(photosRouter);
router.use(ownerRouter);

export default router;
