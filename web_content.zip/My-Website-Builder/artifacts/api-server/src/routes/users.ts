import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, or } from "drizzle-orm";
import { RegisterUserBody, LoginUserBody, UpdateUserBody } from "@workspace/api-zod";

const router = Router();

router.post("/users/register", async (req, res) => {
  const parse = RegisterUserBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const { fullName, mobile, email, password } = parse.data;
  const existing = await db
    .select()
    .from(usersTable)
    .where(or(eq(usersTable.mobile, mobile), email ? eq(usersTable.email, email) : eq(usersTable.mobile, mobile)))
    .limit(1);
  if (existing.length > 0) {
    res.status(409).json({ error: "User already exists" });
    return;
  }
  const [user] = await db
    .insert(usersTable)
    .values({ fullName, mobile, email: email ?? null, password })
    .returning();
  res.status(201).json(toUserResponse(user));
});

router.post("/users/login", async (req, res) => {
  const parse = LoginUserBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const { identifier, password } = parse.data;
  const [user] = await db
    .select()
    .from(usersTable)
    .where(or(eq(usersTable.mobile, identifier), eq(usersTable.email, identifier)))
    .limit(1);
  if (!user || user.password !== password) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  res.json({ user: toUserResponse(user), token: `user-${user.id}` });
});

router.get("/users/:userId", async (req, res) => {
  const userId = parseInt(req.params.userId);
  if (isNaN(userId)) {
    res.status(400).json({ error: "Invalid user id" });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json(toUserResponse(user));
});

router.patch("/users/:userId", async (req, res) => {
  const userId = parseInt(req.params.userId);
  if (isNaN(userId)) {
    res.status(400).json({ error: "Invalid user id" });
    return;
  }
  const parse = UpdateUserBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const updates: Record<string, string | null> = {};
  if (parse.data.fullName !== undefined) updates.fullName = parse.data.fullName;
  if (parse.data.email !== undefined) updates.email = parse.data.email;
  if (parse.data.fullAddress !== undefined) updates.fullAddress = parse.data.fullAddress;
  if (parse.data.profileImageUrl !== undefined) updates.profileImageUrl = parse.data.profileImageUrl;
  const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, userId)).returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json(toUserResponse(user));
});

// List all users (owner use only — internal, no auth middleware for now)
router.get("/users", async (_req, res) => {
  const users = await db.select().from(usersTable).orderBy(usersTable.createdAt);
  res.json(users.map(toUserResponse));
});

function toUserResponse(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    fullName: user.fullName,
    mobile: user.mobile,
    email: user.email,
    fullAddress: user.fullAddress,
    profileImageUrl: user.profileImageUrl,
    createdAt: user.createdAt.toISOString(),
  };
}

export default router;
