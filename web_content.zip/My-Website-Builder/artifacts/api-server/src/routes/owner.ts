import { Router } from "express";
import { db, bookingsTable } from "@workspace/db";
import { eq, count, sql } from "drizzle-orm";
import { VerifyOwnerPasswordBody } from "@workspace/api-zod";

const router = Router();

const OWNER_PASSWORDS: Record<string, { ownerId: number; ownerLevel: number; ownerName: string }> = {
  "AVTAR@9692Q": { ownerId: 1, ownerLevel: 1, ownerName: "Main Owner" },
  "RITESH@8457T": { ownerId: 2, ownerLevel: 2, ownerName: "Second Owner" },
  "AVTAR@OWNER_007": { ownerId: 3, ownerLevel: 3, ownerName: "Third Owner" },
};

router.post("/owner/verify", (req, res) => {
  const parse = VerifyOwnerPasswordBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const owner = OWNER_PASSWORDS[parse.data.password];
  if (!owner) {
    res.status(401).json({ error: "Invalid password" });
    return;
  }
  res.json(owner);
});

router.get("/owner/stats", async (req, res) => {
  const ownerIdParam = req.query.ownerId ? Number(req.query.ownerId) : null;

  const allBookings = ownerIdParam
    ? await db.select().from(bookingsTable).where(eq(bookingsTable.assignedOwnerId, ownerIdParam))
    : await db.select().from(bookingsTable);

  const stats = {
    total: allBookings.length,
    pending: allBookings.filter((b) => b.status === "pending").length,
    confirmed: allBookings.filter((b) => b.status === "confirmed").length,
    completed: allBookings.filter((b) => b.status === "completed").length,
    cancelled: allBookings.filter((b) => b.status === "cancelled").length,
  };
  res.json(stats);
});

export default router;
