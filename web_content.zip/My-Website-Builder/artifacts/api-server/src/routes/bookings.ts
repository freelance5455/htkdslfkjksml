import { Router } from "express";
import { db, bookingsTable, servicesTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import {
  CreateBookingBody,
  UpdateBookingBody,
  ForwardBookingBody,
  ListBookingsQueryParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/bookings", async (req, res) => {
  const parse = ListBookingsQueryParams.safeParse(req.query);
  const params = parse.success ? parse.data : {};

  let query = db.select().from(bookingsTable).$dynamic();

  const conditions = [];
  if (params.userId) conditions.push(eq(bookingsTable.userId, Number(params.userId)));
  if (params.ownerId) conditions.push(eq(bookingsTable.assignedOwnerId, Number(params.ownerId)));
  if (params.status) conditions.push(eq(bookingsTable.status, params.status));

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const bookings = await query.orderBy(desc(bookingsTable.createdAt));
  res.json(bookings.map(toBookingResponse));
});

router.post("/bookings", async (req, res) => {
  const parse = CreateBookingBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const data = parse.data;
  const [service] = await db
    .select()
    .from(servicesTable)
    .where(eq(servicesTable.id, data.serviceId))
    .limit(1);
  const serviceName = service?.name ?? "Service";

  const [booking] = await db
    .insert(bookingsTable)
    .values({
      userId: data.userId,
      customerName: data.customerName,
      customerMobile: data.customerMobile,
      customerAddress: data.customerAddress,
      district: data.district,
      state: data.state,
      serviceId: data.serviceId,
      serviceName,
      scheduledTime: data.scheduledTime,
      issueDescription: data.issueDescription ?? null,
      status: "pending",
    })
    .returning();
  res.status(201).json(toBookingResponse(booking));
});

router.get("/bookings/:bookingId", async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  if (isNaN(bookingId)) {
    res.status(400).json({ error: "Invalid booking id" });
    return;
  }
  const [booking] = await db
    .select()
    .from(bookingsTable)
    .where(eq(bookingsTable.id, bookingId))
    .limit(1);
  if (!booking) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }
  res.json(toBookingResponse(booking));
});

router.patch("/bookings/:bookingId", async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  if (isNaN(bookingId)) {
    res.status(400).json({ error: "Invalid booking id" });
    return;
  }
  const parse = UpdateBookingBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const updates: Record<string, unknown> = {};
  if (parse.data.status !== undefined) updates.status = parse.data.status;
  if (parse.data.confirmedByOwnerId !== undefined) {
    updates.confirmedByOwnerId = parse.data.confirmedByOwnerId;
    updates.confirmedAt = new Date();
  }
  if (parse.data.customerAddress !== undefined) updates.customerAddress = parse.data.customerAddress;
  if (parse.data.district !== undefined) updates.district = parse.data.district;
  if (parse.data.state !== undefined) updates.state = parse.data.state;
  if (parse.data.scheduledTime !== undefined) updates.scheduledTime = parse.data.scheduledTime;
  if (parse.data.issueDescription !== undefined) updates.issueDescription = parse.data.issueDescription;
  const [booking] = await db
    .update(bookingsTable)
    .set(updates)
    .where(eq(bookingsTable.id, bookingId))
    .returning();
  if (!booking) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }
  res.json(toBookingResponse(booking));
});

router.post("/bookings/:bookingId/forward", async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  if (isNaN(bookingId)) {
    res.status(400).json({ error: "Invalid booking id" });
    return;
  }
  const parse = ForwardBookingBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [booking] = await db
    .update(bookingsTable)
    .set({ assignedOwnerId: parse.data.toOwnerId })
    .where(eq(bookingsTable.id, bookingId))
    .returning();
  if (!booking) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }
  res.json(toBookingResponse(booking));
});

function toBookingResponse(b: typeof bookingsTable.$inferSelect) {
  return {
    id: b.id,
    userId: b.userId,
    customerName: b.customerName,
    customerMobile: b.customerMobile,
    customerAddress: b.customerAddress,
    district: b.district,
    state: b.state,
    serviceId: b.serviceId,
    serviceName: b.serviceName,
    scheduledTime: b.scheduledTime,
    issueDescription: b.issueDescription,
    status: b.status,
    assignedOwnerId: b.assignedOwnerId,
    confirmedByOwnerId: b.confirmedByOwnerId,
    confirmedAt: b.confirmedAt?.toISOString() ?? null,
    createdAt: b.createdAt.toISOString(),
  };
}

export default router;
