import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const workPhotosTable = pgTable("work_photos", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id").notNull(),
  uploadedByOwnerId: integer("uploaded_by_owner_id").notNull(),
  imageUrl: text("image_url").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertWorkPhotoSchema = createInsertSchema(workPhotosTable).omit({ id: true, createdAt: true });
export type InsertWorkPhoto = z.infer<typeof insertWorkPhotoSchema>;
export type WorkPhoto = typeof workPhotosTable.$inferSelect;
