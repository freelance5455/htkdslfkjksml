# Avatar e Service

A home appliance repair and service booking website for customers in Odisha, India. Customers can book AC, TV, washing machine, and other appliance repairs in their native language (English/Hindi/Odia), track bookings, and view work completion photos.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port from env)
- `pnpm --filter @workspace/avatar-service run dev` — run the frontend (port from env)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Tailwind CSS, wouter, Framer Motion, Zustand
- API: Express 5 (artifacts/api-server)
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth)
- `lib/db/src/schema/` — Drizzle ORM table definitions (users, services, bookings, work_photos)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/avatar-service/src/` — React frontend
  - `pages/` — HomePage, BookingPage, LoginPage, RegisterPage, ProfilePage, MyBookingsPage, OwnerDashboard
  - `components/` — NavBar, SettingsDrawer
  - `lib/store.ts` — Zustand app state (user, language, owner session)
  - `lib/i18n.ts` — Translations for English, Hindi, Odia
  - `lib/useT.ts` — Translation hook

## Architecture decisions

- Language stored in localStorage via Zustand persist; translations keyed by TranslationKey type
- Owner sessions stored in sessionStorage (not localStorage) for security
- OTU system: 7 clicks on the hidden OTU button reveals a password dialog; passwords map to 3 owner roles
- Passwords validated server-side at `POST /api/owner/verify`
- Sub-owners (level 2 & 3) can only see bookings assigned to them and can only Accept/Confirm once (cannot undo)
- Main owner (level 1) sees all bookings, can forward/confirm/cancel/complete any

## Product

- Customers register/login with mobile or email
- Book appliance repair services with name, service, address, district, state, time, issue description
- Track booking status and view work completion photos
- Settings drawer: language switcher, customer care numbers with click-to-call, Instagram/Facebook links
- OTU owner portal: password-protected, role-based booking management

## Owner passwords (keep private)

- Main Owner: AVTAR@9692Q
- Second Owner: RITESH@8457T
- Third Owner: AVTAR@OWNER_007

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always restart the api-server workflow after backend changes (it builds and restarts automatically)
- Google Fonts @import must come BEFORE @import "tailwindcss" in index.css
- After each OpenAPI spec change, re-run codegen before using updated types

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
