# DailyTalk AI

A free, private English speaking coach for learners across India. Practise out loud, get gentle corrections from "Echo", and tap **Explain in my language** under any reply (Kannada, Hindi, Tamil, Malayalam, Telugu, Marathi, Bengali, Gujarati, Punjabi, Odia, Urdu, Assamese).

- **Zero cost:** Google Gemini free tier + your browser's built-in speech tools (Web Speech API).
- **Zero memory:** no database, no cookies, no localStorage. Refresh the page and everything is gone. Your API key also lives in memory only.
- **No build step:** plain HTML, CSS and JavaScript. Tailwind loads from its CDN.

## Files

| File | What it does |
| --- | --- |
| `index.html` | Page layout and sections |
| `styles.css` | Component styles, animations, dark/light theme |
| `config.js` | System prompt, languages, modes, achievements, tips |
| `voice.js` | Text-to-speech (male/female, pitch, speed) and speech-to-text |
| `ai.js` | Gemini calls (chat, hints, translation) and offline demo mode |
| `ui.js` | DOM rendering helpers |
| `main.js` | App logic and event wiring |

## Run it locally

You need no install. Pick one:

```bash
# Option A: Python
python3 -m http.server 8080

# Option B: Node
npx serve .
```

Open `http://localhost:8080`. (Opening `index.html` directly also works, but browsers only keep microphone permission reliably on `localhost` or `https`.)

## Get a free Gemini key

1. Go to <https://aistudio.google.com/apikey> and create a key (free tier, no card).
2. Open the app and paste the key into the first dialog. Click **Save & start**.
3. No key yet? Click **Try demo mode** to explore the interface with scripted replies.

The model field defaults to `gemini-flash-latest`. `gemini-2.0-flash` is scheduled for shutdown, so if a model is unavailable the app automatically tries `gemini-3.8-flash`, `gemini-3.6-flash` and `gemini-2.5-flash`. You can type any other model name in the dialog.

## Deploy in a minute

All three hosts serve over HTTPS, which the microphone needs.

### GitHub Pages

1. Create a new GitHub repo and upload all the files in this folder (keep them at the repo root).
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, and save.
4. Your site appears at `https://<your-username>.github.io/<repo-name>/` in about a minute.

### Netlify

- **Drag and drop:** open <https://app.netlify.com/drop> and drop this folder.
- **Or CLI:** `npm i -g netlify-cli`, then `netlify deploy --prod --dir .`

### Vercel

- **CLI:** `npm i -g vercel`, then run `vercel --prod` in this folder. When asked, accept the defaults (no framework, output directory `.`).
- **Or dashboard:** push to GitHub, then **Add New → Project** at <https://vercel.com/new>, import the repo, and click **Deploy**.

## How it works

- **Echo's brain:** every turn sends the in-memory conversation plus the "Echo" system prompt (short replies, gentle 💡/🎯 corrections, encouragement, persona per mode) to Gemini. The correction lines are parsed into the **Instant feedback** card.
- **Voice out:** `speechSynthesis` with male/female voice choice, pitch and speed sliders. Voice names vary by device, so you can also pick a specific voice from the list.
- **Voice in:** `SpeechRecognition` with a live sound-wave animation and interim transcript. Works in Chrome, Edge and Safari; Firefox has no speech recognition, so type instead.
- **Explain in my language:** one Gemini call translates and explains the reply. The 🔊 button reads it aloud if your device has a voice for that language.
- **Hints:** one Gemini call returns three ready-to-use replies and two vocabulary items.
- **Confidence tools:** rotating comfort tips, praise after every message, a gentle nudge if you go quiet for about 35 seconds, and achievement toasts.

## Privacy notes

- Nothing is saved by the app. There is no server of your own.
- Your messages go straight from your browser to Google's Gemini API. Google's free-tier terms apply to that traffic.
- In Chrome and Edge, speech recognition is performed by the browser vendor's speech service.
- The API key is typed by each user and kept in memory only. **Do not hard-code your own key in these files** for a public site, since anyone could read it. If you want visitors to use your key, put a small serverless proxy in front of Gemini and call that instead.

## Customise

- Add scenarios, modes or tips in `config.js`.
- Edit Echo's personality in `DT.SYSTEM_PROMPT` and `DT.buildSystemPrompt`.
- Add achievements in `DT.ACHIEVEMENTS` and call `unlock('your_id')` from `main.js`.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| "API key was not accepted" | Re-create the key in AI Studio and paste it again |
| "Free-tier limit reached" | Wait about 30 seconds; the free tier has per-minute limits |
| Mic does nothing | Use Chrome, Edge or Safari over `https` or `localhost`, and allow microphone access |
| No Female/Male difference | Your device has few voices; pick a voice manually and use the pitch slider |
| No Kannada/Tamil/etc. voice for 🔊 | Install that language's voice in your device's system language settings |
