/* DailyTalk AI - DOM rendering helpers (no business logic here) */
(function (w) {
  'use strict';
  const DT = (w.DT = w.DT || {});
  const doc = document;

  const $ = (s, r) => (r || doc).querySelector(s);
  const $$ = (s, r) => Array.from((r || doc).querySelectorAll(s));
  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const UI = {
    $,
    $$,
    esc,

    /* ---------------- selectors ---------------- */
    populateLanguages(select, langs, current) {
      select.innerHTML = langs.map((l) => `<option value="${l.code}">${esc(l.name)} · ${esc(l.native)}</option>`).join('');
      select.value = current;
    },

    renderModes(modes, currentId) {
      $('#modeTabs').innerHTML = Object.values(modes)
        .map(
          (m) => `
        <button type="button" class="mode-tab ${m.id === currentId ? 'active' : ''}" data-mode="${m.id}" aria-pressed="${m.id === currentId}">
          <span class="emoji" aria-hidden="true">${m.emoji}</span>
          <span><span class="t block">${esc(m.label)}</span><span class="d block">${esc(m.desc)}</span></span>
        </button>`
        )
        .join('');
    },

    renderScenarios(mode, currentId) {
      $('#scenarioChips').innerHTML = mode.scenarios
        .map((s) => `<button type="button" class="chip ${s.id === currentId ? 'active' : ''}" data-scenario="${s.id}">${esc(s.label)}</button>`)
        .join('');
    },

    setChatHeader(mode, scenario) {
      $('#chatTitle').textContent = mode.emoji + ' ' + mode.label;
      $('#chatSub').textContent = scenario.label.replace(/^\S+\s/, '') + ' · Echo is your practice partner';
    },

    setModePill(demo) {
      const p = $('#modePill');
      p.className = 'pill hidden sm:inline-flex ' + (demo ? 'demo' : 'live');
      p.textContent = demo ? 'Demo mode' : 'Gemini live';
    },

    setHelpLine(text) {
      $('#helpLine').textContent = '🌐 ' + text;
    },

    setComfort(en, native) {
      $('#comfortText').textContent = en;
      $('#comfortNative').textContent = native || '';
    },

    nudge(show, text, native) {
      $('#comfort').classList.toggle('nudge', show);
      $('#nudgeHintBtn').classList.toggle('hidden', !show);
      if (show) this.setComfort(text, native);
    },

    /* ---------------- chat ---------------- */
    scrollChat() {
      const m = $('#messages');
      m.scrollTop = m.scrollHeight;
    },

    clearChat() {
      $('#messages').innerHTML = '';
    },

    addUser(text) {
      const wrap = doc.createElement('div');
      wrap.className = 'msg msg-user';
      wrap.innerHTML = '<div class="msg-body"><div class="bubble bubble-user"></div></div>';
      $('.bubble', wrap).textContent = text;
      $('#messages').appendChild(wrap);
      this.scrollChat();
      return wrap;
    },

    addPill(userNode, text) {
      const p = doc.createElement('span');
      p.className = 'encourage';
      p.textContent = text;
      $('.msg-body', userNode).appendChild(p);
      this.scrollChat();
    },

    addAI(id, text, lang) {
      const wrap = doc.createElement('div');
      wrap.className = 'msg msg-ai';
      wrap.dataset.id = id;
      wrap.innerHTML = `
        <div class="avatar" aria-hidden="true">E</div>
        <div class="msg-body">
          <div class="bubble bubble-ai"></div>
          <div class="msg-actions">
            <button type="button" class="mini" data-act="speak" aria-label="Listen to this reply">🔊 Listen</button>
            <button type="button" class="mini" data-act="explain">🌐 Explain in my language <span class="explain-lang">(${esc(lang.native)})</span></button>
          </div>
          <div class="explain hidden" data-explain></div>
        </div>`;
      $('.bubble', wrap).textContent = text;
      $('#messages').appendChild(wrap);
      this.scrollChat();
      return wrap;
    },

    fillExplain(box, text, lang) {
      box.innerHTML = `<div class="explain-head"><span>🌐 ${esc(lang.name)} · ${esc(lang.native)}</span><button type="button" class="mini" data-act="speak-explain" aria-label="Listen in ${esc(lang.name)}">🔊 Listen</button></div><p class="explain-text"></p>`;
      $('.explain-text', box).textContent = text;
      box.classList.remove('hidden');
      this.scrollChat();
    },

    explainLoading(box) {
      box.innerHTML = '<div class="typing" aria-label="Translating"><i></i><i></i><i></i></div>';
      box.classList.remove('hidden');
      this.scrollChat();
    },

    updateExplainLabels(lang) {
      $$('.explain-lang').forEach((el) => (el.textContent = '(' + lang.native + ')'));
    },

    typing(show) {
      let t = $('#typing');
      if (show && !t) {
        t = doc.createElement('div');
        t.id = 'typing';
        t.className = 'msg msg-ai';
        t.innerHTML = '<div class="avatar" aria-hidden="true">E</div><div class="bubble bubble-ai"><div class="typing" aria-label="Echo is typing"><i></i><i></i><i></i></div></div>';
        $('#messages').appendChild(t);
        this.scrollChat();
      } else if (!show && t) {
        t.remove();
      }
    },

    notice(text) {
      const n = doc.createElement('div');
      n.className = 'notice';
      n.textContent = text;
      $('#messages').appendChild(n);
      this.scrollChat();
      return n;
    },

    /* ---------------- mic ---------------- */
    buildWave() {
      const bars = $('#waveBars');
      bars.innerHTML = '';
      for (let i = 0; i < 28; i++) {
        const s = doc.createElement('span');
        s.style.setProperty('--h', 8 + Math.round(Math.random() * 22) + 'px');
        s.style.animationDelay = (i % 7) * 0.09 + Math.random() * 0.25 + 's';
        s.style.animationDuration = 0.6 + Math.random() * 0.7 + 's';
        bars.appendChild(s);
      }
    },

    setListening(on) {
      $('#micBtn').classList.toggle('listening', on);
      $('#micBtn').setAttribute('aria-label', on ? 'Stop listening' : 'Start speaking');
      $('#waveStrip').classList.toggle('hidden', !on);
    },

    /* ---------------- feedback card ---------------- */
    correction: {
      empty() {
        $('#correctionBody').innerHTML = '<div class="fb-empty"><span aria-hidden="true">🌼</span><p>Feedback appears here after each message. Mistakes are welcome, they are how we learn!</p></div>';
      },
      checking() {
        $('#correctionBody').innerHTML = '<div class="skeleton"></div><div class="skeleton" style="height:2.4rem"></div>';
      },
      perfect() {
        $('#correctionBody').innerHTML = '<div class="fb-row great"><span class="k">✅ Perfect</span><span class="v">Natural and correct. No changes needed. Wonderful! 🎉</span></div>';
      },
      fix(d) {
        let html = `
          <div class="fb-row you"><span class="k">You said</span><span class="v">${esc(d.original)}</span></div>
          <div class="fb-row fix"><span class="k">💡 Gentle correction</span><span class="v">${esc(d.corrected || d.original)}</span></div>`;
        if (d.better) html += `<div class="fb-row better"><span class="k">🎯 Better expression</span><span class="v">${esc(d.better)}</span></div>`;
        html += `<div class="fb-actions">
            <button type="button" class="btn btn-sm" data-act="speak-text" data-text="${esc(d.better || d.corrected)}">🔊 Hear it</button>
            <button type="button" class="btn btn-sm" data-act="got-it">✅ Got it</button>
          </div>`;
        $('#correctionBody').innerHTML = html;
      },
      gotIt() {
        const b = $('#correctionBody [data-act="got-it"]');
        if (b) {
          b.textContent = '🌟 Learned!';
          b.disabled = true;
        }
      },
    },

    /* ---------------- hints ---------------- */
    hints: {
      empty() {
        $('#hintsBody').innerHTML = '<p class="text-sm muted">Not sure what to say? Tap <b>Need a hint?</b> for ready-to-use replies and useful words.</p>';
      },
      loading() {
        $('#hintsBody').innerHTML = '<div class="skeleton"></div><div class="skeleton" style="height:2.4rem"></div>';
      },
      error(msg) {
        $('#hintsBody').innerHTML = `<p class="text-sm">😕 ${esc(msg)}</p>`;
      },
      render(data) {
        let html = '';
        if (data.replies.length) {
          html += '<div class="hint-label">Try saying</div><div class="hint-chips">';
          html += data.replies.map((r) => `<button type="button" class="chip" data-chip="${esc(r)}">“${esc(r)}”</button>`).join('');
          html += '</div>';
        }
        if (data.vocab.length) {
          html += '<div class="hint-label" style="margin-top:.8rem">Vocabulary booster</div>';
          html += data.vocab
            .map(
              (v, i) => `<div class="vocab" data-vocab="${i}">
                <div class="w">${esc(v.word || '')}</div>
                <div>${esc(v.meaning || '')}</div>
                <div class="ex">${esc(v.example || '')}</div>
                <button type="button" class="mini mt-2" data-act="learn" data-word="${esc(v.word || '')}">📚 I learned this</button>
              </div>`
            )
            .join('');
        }
        $('#hintsBody').innerHTML = html || '<p class="text-sm muted">No hints this time. Try again!</p>';
      },
      markLearned(btn) {
        btn.textContent = '✅ Learned';
        btn.disabled = true;
        const card = btn.closest('.vocab');
        if (card) card.classList.add('learned');
      },
    },

    /* ---------------- achievements ---------------- */
    renderAchievements(unlocked, stats) {
      $('#achCount').textContent = unlocked.size + '/' + DT.ACHIEVEMENTS.length;
      $('#statsRow').innerHTML =
        `<div class="stat"><b>${stats.exchanges}</b><span>Exchanges</span></div>` +
        `<div class="stat"><b>${stats.learned}</b><span>Phrases learned</span></div>` +
        `<div class="stat"><b>${stats.clean}</b><span>Clean sentences</span></div>`;
      $('#achGrid').innerHTML = DT.ACHIEVEMENTS.map((a) => {
        const on = unlocked.has(a.id);
        return `<div class="ach ${on ? 'on' : 'locked'}" title="${esc(a.title + ': ' + a.desc)}"><span class="i" aria-hidden="true">${a.icon}</span><span class="n">${esc(a.title)}</span></div>`;
      }).join('');
    },

    /* ---------------- toasts ---------------- */
    toast(kind, title, msg, icon) {
      const wrap = $('#toasts');
      const t = doc.createElement('div');
      t.className = 'toast ' + kind;
      t.setAttribute('role', kind === 'error' ? 'alert' : 'status');
      const ic = icon || (kind === 'achievement' ? '🏆' : kind === 'error' ? '⚠️' : kind === 'success' ? '🌟' : 'ℹ️');
      t.innerHTML = `<span class="ti" aria-hidden="true">${ic}</span><div><div class="tt"></div><div class="tm"></div></div>`;
      $('.tt', t).textContent = title;
      $('.tm', t).textContent = msg || '';
      wrap.appendChild(t);
      const life = kind === 'achievement' ? 5200 : 3800;
      setTimeout(() => {
        t.classList.add('out');
        setTimeout(() => t.remove(), 320);
      }, life);
      t.addEventListener('click', () => t.remove());
    },

    /* ---------------- modal ---------------- */
    modal(show, closable) {
      $('#modal').classList.toggle('hidden', !show);
      $('#closeModalBtn').classList.toggle('hidden', !closable);
      if (show) setTimeout(() => $('#keyInput').focus(), 50);
    },
    keyStatus(text, bad) {
      const s = $('#keyStatus');
      s.textContent = text;
      s.style.color = bad ? 'var(--bad)' : 'var(--muted)';
    },
  };

  DT.UI = UI;
})(window);
