/* DailyTalk AI - Voice: zero-cost TTS + STT via the Web Speech API */
(function (w) {
  'use strict';
  const DT = (w.DT = w.DT || {});

  const synth = w.speechSynthesis || null;
  const SR = w.SpeechRecognition || w.webkitSpeechRecognition || null;

  // Voice names differ per OS/browser, so gender is guessed from the name.
  const FEMALE = /female|zira|samantha|susan|hazel|heera|veena|aria|jenny|karen|moira|tessa|fiona|victoria|kalpana|swara|neerja|priya|lekha|allison|ava|serena|zoe/i;
  const MALE = /\bmale\b|david|mark|george|ravi|alex|daniel|james|fred|rishi|guy|ryan|prabhat|hemant|christopher|eric|tom|aaron/i;

  const Voice = {
    ttsSupported: !!synth,
    sttSupported: !!SR,
    voices: [],
    rec: null,
    speakTimer: null,

    init(onChange) {
      if (!synth) return;
      const load = () => {
        this.voices = synth.getVoices() || [];
        if (onChange) onChange();
      };
      load();
      if (typeof synth.addEventListener === 'function') synth.addEventListener('voiceschanged', load);
      else synth.onvoiceschanged = load;
    },

    refresh() {
      if (synth) this.voices = synth.getVoices() || [];
    },

    genderOf(v) {
      if (FEMALE.test(v.name)) return 'female';
      if (MALE.test(v.name)) return 'male';
      return 'unknown';
    },

    englishVoices() {
      const rank = (v) => (/en[-_]IN/i.test(v.lang) ? 0 : /en[-_]GB/i.test(v.lang) ? 1 : /en[-_]US/i.test(v.lang) ? 2 : 3);
      return this.voices.filter((v) => /^en/i.test(v.lang)).sort((a, b) => rank(a) - rank(b));
    },

    /** Best English voice for the requested gender (or a specific voiceURI). */
    pick(gender, voiceURI) {
      const list = this.englishVoices();
      if (voiceURI) {
        const chosen = list.find((v) => v.voiceURI === voiceURI);
        if (chosen) return chosen;
      }
      return list.find((v) => this.genderOf(v) === gender) || list.find((v) => this.genderOf(v) === 'unknown') || list[0] || null;
    },

    /** A voice that speaks the given locale (for native-language explanations). */
    forLang(bcp) {
      const base = bcp.slice(0, 2).toLowerCase();
      return this.voices.find((v) => v.lang.replace('_', '-').toLowerCase() === bcp.toLowerCase()) || this.voices.find((v) => v.lang.toLowerCase().startsWith(base)) || null;
    },

    hasVoiceFor(bcp) {
      return !!this.forLang(bcp);
    },

    cancel() {
      clearTimeout(this.speakTimer);
      if (synth) synth.cancel();
    },

    /** Speak English text with the chosen gender, pitch and speed. */
    speak(text, opts) {
      if (!synth || !text) return;
      const o = opts || {};
      this.cancel();
      const u = new SpeechSynthesisUtterance(text);
      const voice = this.pick(o.gender || 'female', o.voiceURI);
      if (voice) u.voice = voice;
      u.lang = voice ? voice.lang : 'en-IN';
      u.pitch = o.pitch || 1;
      u.rate = o.rate || 1;
      if (o.onend) u.onend = o.onend;
      // Tiny delay avoids a Chrome bug where speak() right after cancel() is dropped.
      u.onerror = () => {
        if (o.onerror) o.onerror();
      };
      this.speakTimer = setTimeout(() => {
        if (!this.voices.length) this.refresh();
        synth.resume();
        synth.speak(u);
      }, 60);
    },

    /** Speak text in a regional language, if the device has a voice for it. */
    speakLang(text, bcp, opts) {
      if (!synth || !text) return false;
      const o = opts || {};
      const voice = this.forLang(bcp);
      this.cancel();
      const u = new SpeechSynthesisUtterance(text);
      if (voice) u.voice = voice;
      u.lang = voice ? voice.lang : bcp;
      u.rate = o.rate || 0.95;
      u.pitch = o.pitch || 1;
      this.speakTimer = setTimeout(() => synth.speak(u), 60);
      return !!voice;
    },

    /** Start live speech-to-text. Returns false if unsupported or blocked. */
    listen(opts) {
      if (!SR) return false;
      this.stopListening();
      const r = new SR();
      r.lang = opts.lang || 'en-IN';
      r.interimResults = true;
      r.continuous = false;
      r.maxAlternatives = 1;
      let finalText = '';
      r.onresult = (e) => {
        let interim = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const t = e.results[i][0].transcript;
          if (e.results[i].isFinal) finalText += t;
          else interim += t;
        }
        if (opts.onInterim) opts.onInterim((finalText + interim).trim());
      };
      r.onerror = (e) => {
        if (opts.onError) opts.onError(e.error);
      };
      r.onend = () => {
        this.rec = null;
        if (opts.onEnd) opts.onEnd(finalText.trim());
      };
      try {
        r.start();
        this.rec = r;
        return true;
      } catch (err) {
        return false;
      }
    },

    stopListening() {
      if (this.rec) {
        try {
          this.rec.stop();
        } catch (_) {
          /* already stopped */
        }
      }
    },
  };

  DT.Voice = Voice;
})(window);
