/* DailyTalk AI - app logic. All state lives in memory; nothing is written to storage. */
(function (w) {
  'use strict';
  const DT = w.DT;
  const { UI, Voice, AI, Demo } = DT;
  const $ = UI.$;
  const $$ = UI.$$;

  const DEFAULT_PITCH = { female: 1.1, male: 0.8 };
  const DEFAULT_RATE = 0.95;
  const IDLE_MS = 35000;

  const state = {
    lang: 'kn',
    mode: 'daily',
    scenario: 'smalltalk',
    history: [], // [{role:'user'|'model', text}]
    busy: false,
    autoSpeak: true,
    gender: 'female',
    pitch: DEFAULT_PITCH.female,
    rate: DEFAULT_RATE,
    voiceURI: '',
    unlocked: new Set(),
    modesTried: new Set(['daily']),
    stats: { exchanges: 0, learned: 0, clean: 0 },
    hintChips: new Set(),
    idleTimer: null,
    tipIndex: 0,
    listening: false,
    seq: 0,
  };
  const msgStore = new Map(); // id -> { text, explanation }

  const lang = () => DT.LANGUAGES.find((l) => l.code === state.lang);
  const mode = () => DT.MODES[state.mode];
  const scenario = () => mode().scenarios.find((s) => s.id === state.scenario);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const norm = (s) => s.toLowerCase().replace(/[^a-z0-9 ]/g, '').trim();

  /* ---------------------------------------------------------------- */
  /* Voice helpers                                                    */
  /* ---------------------------------------------------------------- */
  function speakAI(text) {
    Voice.speak(text, { gender: state.gender, pitch: state.pitch, rate: state.rate, voiceURI: state.voiceURI });
  }

  function populateVoices() {
    const sel = $('#voiceSelect');
    const list = Voice.englishVoices();
    let html = '<option value="">Auto: best ' + state.gender + ' voice</option>';
    html += list.map((v) => `<option value="${UI.esc(v.voiceURI)}">${UI.esc(v.name)} (${UI.esc(v.lang)})</option>`).join('');
    sel.innerHTML = html;
    sel.value = state.voiceURI;
    if (!Voice.ttsSupported) {
      sel.disabled = true;
      sel.innerHTML = '<option>Voice output not supported in this browser</option>';
    }
  }

  function setGender(g) {
    state.gender = g;
    state.voiceURI = '';
    state.pitch = DEFAULT_PITCH[g];
    $('#pitchRange').value = state.pitch;
    $('#pitchVal').textContent = state.pitch.toFixed(2);
    $$('.seg [data-gender]').forEach((b) => b.classList.toggle('active', b.dataset.gender === g));
    populateVoices();
  }

  /* ---------------------------------------------------------------- */
  /* Achievements & encouragement                                     */
  /* ---------------------------------------------------------------- */
  function unlock(id) {
    if (state.unlocked.has(id)) return;
    const a = DT.ACHIEVEMENTS.find((x) => x.id === id);
    if (!a) return;
    state.unlocked.add(id);
    UI.toast('achievement', 'New Achievement Unlocked! ' + a.title, a.desc, a.icon);
    refreshProgress();
  }

  function refreshProgress() {
    UI.renderAchievements(state.unlocked, state.stats);
  }

  function markLearned() {
    state.stats.learned++;
    if (state.stats.learned >= 3) unlock('phrase_collector');
    refreshProgress();
  }

  /* ---------------------------------------------------------------- */
  /* Comfort banner + idle nudge (lowering the affective filter)      */
  /* ---------------------------------------------------------------- */
  function showTip(step) {
    state.tipIndex = (state.tipIndex + (step ? 1 : 0)) % DT.TIPS.length;
    // Tip 0 is the headline comfort message; it is also shown in the learner's language.
    const native = state.tipIndex === 0 ? DT.I18N[state.lang].tip : '';
    UI.nudge(false);
    UI.setComfort(DT.TIPS[state.tipIndex], native);
  }

  function scheduleIdle() {
    clearIdle();
    state.idleTimer = setTimeout(() => {
      UI.nudge(true, pick(DT.NUDGES), DT.I18N[state.lang].tip);
    }, IDLE_MS);
  }

  function clearIdle() {
    clearTimeout(state.idleTimer);
    if (!$('#nudgeHintBtn').classList.contains('hidden')) showTip(false);
  }

  /* ---------------------------------------------------------------- */
  /* Sessions                                                         */
  /* ---------------------------------------------------------------- */
  function addAIMessage(text) {
    const id = ++state.seq;
    msgStore.set(id, { text, explanation: '' });
    return UI.addAI(id, text, lang());
  }

  function startScenario(speakOpener) {
    clearIdle();
    Voice.cancel();
    const sc = scenario();
    state.history = [];
    state.hintChips.clear();
    UI.clearChat();
    UI.setChatHeader(mode(), sc);
    UI.renderModes(DT.MODES, state.mode);
    UI.renderScenarios(mode(), state.scenario);
    UI.correction.empty();
    UI.hints.empty();
    addAIMessage(sc.opener);
    state.history.push({ role: 'model', text: sc.opener });
    if (speakOpener && state.autoSpeak) speakAI(sc.opener);
    scheduleIdle();
  }

  function resetEverything() {
    Voice.cancel();
    Voice.stopListening();
    state.mode = 'daily';
    state.scenario = 'smalltalk';
    state.unlocked = new Set();
    state.modesTried = new Set(['daily']);
    state.stats = { exchanges: 0, learned: 0, clean: 0 };
    msgStore.clear();
    $('#textInput').value = '';
    refreshProgress();
    startScenario(false);
    UI.toast('success', 'Fresh start', 'Everything was wiped. Nothing was kept. 🫧');
  }

  /* ---------------------------------------------------------------- */
  /* Sending a message                                                */
  /* ---------------------------------------------------------------- */
  function parseReply(raw) {
    let correction = '';
    let better = '';
    const keep = [];
    const clean = (s) => s.replace(/^[\s\-–•*[]+/, '').replace(/[\s\]*]+$/, '').replace(/^["“]|["”]$/g, '').trim();
    raw.split(/\r?\n/).forEach((line) => {
      const c = line.match(/💡\s*(?:\*\*)?\s*Gentle Correction\s*:?\s*(?:\*\*)?\s*(.*)$/i);
      const b = line.match(/🎯\s*(?:\*\*)?\s*Better Expression\s*:?\s*(?:\*\*)?\s*(.*)$/i);
      if (c) correction = clean(c[1]);
      else if (b) better = clean(b[1]);
      else keep.push(line);
    });
    const spoken = keep.join(' ').replace(/[*_`#]/g, '').replace(/\s+/g, ' ').replace(/[-–•]\s*$/, '').trim();
    return { spoken: spoken || 'Nice try! Please go on.', correction, better };
  }

  function friendlyError(err) {
    if (err && err.message) return err.message;
    return 'Something went wrong. Please try again.';
  }

  async function send(text, opts) {
    const o = opts || {};
    text = (text || '').trim();
    if (!text || state.busy) return;
    if (!AI.ready()) {
      UI.modal(true, false);
      return;
    }

    state.busy = true;
    $('#sendBtn').disabled = true;
    clearIdle();
    Voice.cancel();
    $('#textInput').value = '';

    const userNode = UI.addUser(text);
    state.history.push({ role: 'user', text });
    unlock('first_hello');
    if (o.viaMic) unlock('brave_voice');

    // A phrase borrowed from the hints panel counts as learning.
    if (state.hintChips.has(norm(text))) {
      state.hintChips.delete(norm(text));
      markLearned();
      UI.toast('success', 'Phrase learned!', 'You used a hint in a real sentence. 📚');
    }

    UI.typing(true);
    UI.correction.checking();

    let raw;
    try {
      raw = AI.demo
        ? await new Promise((r) => setTimeout(() => r(Demo.reply(text, state.mode)), 600))
        : await AI.chat({ mode: mode(), scenario: scenario(), lang: lang(), history: state.history });
    } catch (err) {
      // Roll back so the learner can simply try again.
      state.history.pop();
      userNode.remove();
      UI.typing(false);
      UI.correction.empty();
      $('#textInput').value = text;
      UI.toast('error', 'Could not reach Echo', friendlyError(err));
      if (err && err.kind === 'key') UI.modal(true, true);
      state.busy = false;
      $('#sendBtn').disabled = false;
      scheduleIdle();
      return;
    }

    UI.typing(false);
    const parsed = parseReply(raw);
    state.history.push({ role: 'model', text: raw });
    addAIMessage(parsed.spoken);

    const words = text.split(/\s+/).filter(Boolean).length;
    if (parsed.correction) {
      UI.correction.fix({ original: text, corrected: parsed.correction, better: parsed.better });
      UI.addPill(userNode, pick(DT.ENCOURAGE.fix));
    } else {
      UI.correction.perfect();
      if (words >= 4) {
        state.stats.clean++;
        unlock('clean_sentence');
      }
      UI.addPill(userNode, words <= 3 ? pick(DT.ENCOURAGE.short) : o.viaMic ? pick(DT.ENCOURAGE.mic) : pick(DT.ENCOURAGE.good));
    }

    state.stats.exchanges++;
    if (state.stats.exchanges >= 5) unlock('chat_champ');
    refreshProgress();

    UI.hints.empty();
    state.hintChips.clear();

    if (state.autoSpeak) speakAI(parsed.spoken);

    state.busy = false;
    $('#sendBtn').disabled = false;
    scheduleIdle();
    const touch = w.matchMedia && w.matchMedia('(pointer: coarse)').matches;
    if (!touch) $('#textInput').focus();
  }

  /* ---------------------------------------------------------------- */
  /* Hints                                                            */
  /* ---------------------------------------------------------------- */
  function lastAIText() {
    for (let i = state.history.length - 1; i >= 0; i--) {
      if (state.history[i].role === 'model') return parseReply(state.history[i].text).spoken;
    }
    return scenario().opener;
  }

  async function loadHints() {
    if (state.busy) return;
    if (!AI.ready()) {
      UI.modal(true, false);
      return;
    }
    clearIdle();
    UI.hints.loading();
    $('#hintBtn').disabled = true;
    try {
      const data = AI.demo
        ? await new Promise((r) => setTimeout(() => r(Demo.hints(state.mode)), 400))
        : await AI.hints({ mode: mode(), scenario: scenario(), lastAI: lastAIText() });
      data.replies.forEach((r) => state.hintChips.add(norm(r)));
      UI.hints.render(data);
    } catch (err) {
      UI.hints.error(friendlyError(err));
    }
    $('#hintBtn').disabled = false;
    scheduleIdle();
  }

  /* ---------------------------------------------------------------- */
  /* Explain in my language                                           */
  /* ---------------------------------------------------------------- */
  async function explain(msgEl, id) {
    const item = msgStore.get(Number(id));
    if (!item) return;
    const box = $('[data-explain]', msgEl);
    const l = lang();
    if (item.explanation && item.explLang === l.code) {
      box.classList.toggle('hidden');
      return;
    }
    if (!AI.ready()) {
      UI.modal(true, false);
      return;
    }
    UI.explainLoading(box);
    try {
      const text = AI.demo ? Demo.translate(l) : await AI.translate(item.text, l);
      item.explanation = text;
      item.explLang = l.code;
      UI.fillExplain(box, text, l);
      unlock('language_bridge');
    } catch (err) {
      box.classList.add('hidden');
      UI.toast('error', 'Could not translate', friendlyError(err));
    }
  }

  /* ---------------------------------------------------------------- */
  /* Microphone                                                       */
  /* ---------------------------------------------------------------- */
  function micError(code) {
    if (code === 'not-allowed' || code === 'service-not-allowed') {
      UI.toast('error', 'Microphone is blocked', 'Allow microphone access in your browser address bar, then try again. You can also type instead.');
    } else if (code === 'no-speech') {
      UI.toast('info', 'No worries!', "I didn't hear anything. Tap the mic whenever you're ready. 💛", '🌼');
    } else if (code === 'audio-capture') {
      UI.toast('error', 'No microphone found', 'Please connect a microphone, or type your message.');
    } else if (code === 'network') {
      UI.toast('error', 'Speech service unreachable', 'Voice typing needs an internet connection. You can type instead.');
    } else if (code !== 'aborted') {
      UI.toast('error', 'Mic problem', 'Something interrupted the microphone. Please try again.');
    }
  }

  function setListening(on) {
    state.listening = on;
    UI.setListening(on);
  }

  function toggleMic() {
    if (state.listening) {
      Voice.stopListening();
      return;
    }
    if (w.location.protocol === 'file:') {
      UI.toast('error', 'Open the app over https or localhost', 'The mic cannot work from a file opened directly. Deploy it (see README) or run a local server.', '🎤');
      return;
    }
    if (!Voice.sttSupported) {
      UI.toast('info', 'Voice typing not supported', 'Please use Chrome, Edge or Safari for the mic, or type your message.', '🎤');
      return;
    }
    if (state.busy) return;
    clearIdle();
    Voice.cancel();
    const ok = Voice.listen({
      lang: 'en-IN',
      onInterim: (t) => {
        $('#textInput').value = t;
      },
      onError: micError,
      onEnd: (finalText) => {
        setListening(false);
        if (finalText) send(finalText, { viaMic: true });
        else scheduleIdle();
      },
    });
    if (ok) setListening(true);
    else UI.toast('error', 'Could not start the mic', 'Please try again, or type your message.');
  }

  /* ---------------------------------------------------------------- */
  /* Settings / API key                                               */
  /* ---------------------------------------------------------------- */
  async function saveKey() {
    const key = $('#keyInput').value.trim();
    const model = $('#modelInput').value.trim() || 'gemini-flash-latest';
    if (!key) {
      UI.keyStatus('Paste your API key, or choose demo mode.', true);
      return;
    }
    const prevKey = AI.key;
    const prevModel = AI.model;
    const prevDemo = AI.demo;
    AI.key = key;
    AI.model = model;
    AI.demo = false;
    $('#saveKeyBtn').disabled = true;
    UI.keyStatus('Checking your key…', false);
    try {
      await AI.ping();
      $('#keyInput').value = ''; // do not leave the key sitting in the DOM
      UI.keyStatus('', false);
      UI.modal(false);
      UI.setModePill(false);
      UI.toast('success', 'Connected!', 'Echo is ready. Say hello! 👋', '🔗');
    } catch (err) {
      AI.key = prevKey;
      AI.model = prevModel;
      AI.demo = prevDemo;
      UI.keyStatus(friendlyError(err), true);
    }
    $('#saveKeyBtn').disabled = false;
  }

  function useDemo() {
    AI.demo = true;
    UI.keyStatus('', false);
    UI.modal(false);
    UI.setModePill(true);
    UI.toast('info', 'Demo mode', 'Scripted replies, no AI. Add a free Gemini key any time via ⚙️.', '🧪');
  }

  /* ---------------------------------------------------------------- */
  /* Theme                                                            */
  /* ---------------------------------------------------------------- */
  function applyTheme(dark) {
    document.documentElement.classList.toggle('dark', dark);
    $('#themeBtn').textContent = dark ? '☀️' : '🌙';
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', dark ? '#0f172a' : '#6366f1');
  }

  /* ---------------------------------------------------------------- */
  /* Language                                                         */
  /* ---------------------------------------------------------------- */
  function applyLanguage() {
    const l = lang();
    UI.setHelpLine(DT.I18N[l.code].help);
    UI.updateExplainLabels(l);
    showTip(false);
  }

  /* ---------------------------------------------------------------- */
  /* Wire up                                                          */
  /* ---------------------------------------------------------------- */
  function bind() {
    $('#langSelect').addEventListener('change', (e) => {
      state.lang = e.target.value;
      applyLanguage();
    });

    $$('.seg [data-gender]').forEach((b) => b.addEventListener('click', () => setGender(b.dataset.gender)));
    $('#voiceSelect').addEventListener('change', (e) => (state.voiceURI = e.target.value));
    $('#pitchRange').addEventListener('input', (e) => {
      state.pitch = parseFloat(e.target.value);
      $('#pitchVal').textContent = state.pitch.toFixed(2);
    });
    $('#rateRange').addEventListener('input', (e) => {
      state.rate = parseFloat(e.target.value);
      $('#rateVal').textContent = state.rate.toFixed(2);
    });
    $('#autoSpeak').addEventListener('change', (e) => {
      state.autoSpeak = e.target.checked;
      if (!state.autoSpeak) Voice.cancel();
    });
    $('#testVoice').addEventListener('click', () => {
      if (!Voice.ttsSupported) return UI.toast('info', 'Not supported', 'This browser has no voice output.', '🔇');
      if (!Voice.voices.length) Voice.refresh();
      speakAI("Hi, I'm Echo! Let's practise English together. There is no pressure at all.");
    });

    $('#modeTabs').addEventListener('click', (e) => {
      const b = e.target.closest('[data-mode]');
      if (!b || b.dataset.mode === state.mode) return;
      state.mode = b.dataset.mode;
      state.scenario = mode().scenarios[0].id;
      state.modesTried.add(state.mode);
      if (state.modesTried.size >= 3) unlock('mode_explorer');
      startScenario(true);
    });
    $('#scenarioChips').addEventListener('click', (e) => {
      const b = e.target.closest('[data-scenario]');
      if (!b || b.dataset.scenario === state.scenario) return;
      state.scenario = b.dataset.scenario;
      startScenario(true);
    });

    $('#tipNext').addEventListener('click', () => showTip(true));
    $('#nudgeHintBtn').addEventListener('click', loadHints);
    $('#hintBtn').addEventListener('click', loadHints);

    $('#composer').addEventListener('submit', (e) => {
      e.preventDefault();
      send($('#textInput').value);
    });
    $('#textInput').addEventListener('input', clearIdle);
    $('#micBtn').addEventListener('click', toggleMic);

    // Message actions (listen / explain)
    $('#messages').addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      const msgEl = b.closest('.msg');
      const id = msgEl && msgEl.dataset.id;
      const item = id ? msgStore.get(Number(id)) : null;
      if (b.dataset.act === 'speak' && item) speakAI(item.text);
      if (b.dataset.act === 'explain') explain(msgEl, id);
      if (b.dataset.act === 'speak-explain' && item && item.explanation) {
        const l = lang();
        const hasVoice = Voice.speakLang(item.explanation, l.bcp, { rate: state.rate });
        if (!hasVoice) UI.toast('info', 'No ' + l.name + ' voice found', 'Your device may not have a ' + l.name + ' voice installed. You can add one in your system language settings.', '🔈');
      }
    });

    // Feedback card actions
    $('#correctionBody').addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      if (b.dataset.act === 'speak-text') speakAI(b.dataset.text);
      if (b.dataset.act === 'got-it') {
        UI.correction.gotIt();
        unlock('comeback');
        markLearned();
        UI.toast('success', 'Beautiful!', 'Noticing a correction is how you improve. 🌱');
      }
    });

    // Hints panel actions
    $('#hintsBody').addEventListener('click', (e) => {
      const chip = e.target.closest('[data-chip]');
      if (chip) {
        const input = $('#textInput');
        input.value = chip.dataset.chip;
        input.focus();
        clearIdle();
        return;
      }
      const learn = e.target.closest('[data-act="learn"]');
      if (learn) {
        UI.hints.markLearned(learn);
        markLearned();
        UI.toast('success', 'Nice!', 'Try using "' + learn.dataset.word + '" in your next sentence. 📚');
      }
    });

    // Header buttons
    $('#themeBtn').addEventListener('click', () => applyTheme(!document.documentElement.classList.contains('dark')));
    $('#settingsBtn').addEventListener('click', () => UI.modal(true, AI.ready()));
    $('#newSessionBtn').addEventListener('click', () => {
      if (w.confirm('Start a fresh session? This clears the conversation and your achievements.')) resetEverything();
    });

    // Modal
    $('#saveKeyBtn').addEventListener('click', saveKey);
    $('#keyInput').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') saveKey();
    });
    $('#demoBtn').addEventListener('click', useDemo);
    $('#closeModalBtn').addEventListener('click', () => UI.modal(false));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && AI.ready()) UI.modal(false);
    });

    // Stop talking if the tab is hidden
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) Voice.cancel();
    });
  }

  function init() {
    applyTheme(w.matchMedia && w.matchMedia('(prefers-color-scheme: dark)').matches);
    UI.populateLanguages($('#langSelect'), DT.LANGUAGES, state.lang);
    UI.buildWave();
    UI.setModePill(false);
    $('#pitchVal').textContent = state.pitch.toFixed(2);
    $('#rateVal').textContent = state.rate.toFixed(2);
    Voice.init(populateVoices);
    populateVoices();
    bind();
    applyLanguage();
    refreshProgress();
    startScenario(false);
    if (!Voice.sttSupported) $('#micBtn').title = 'Voice typing needs Chrome, Edge or Safari';
    UI.modal(true, false); // ask for the free Gemini key (or demo mode) first
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})(window);
