/* DailyTalk AI - static configuration: languages, modes, prompts, achievements, tips */
(function (w) {
  'use strict';
  const DT = (w.DT = w.DT || {});

  /* ------------------------------------------------------------------ */
  /* System prompt sent with every Gemini call                           */
  /* ------------------------------------------------------------------ */
  DT.SYSTEM_PROMPT = `You are 'Echo', a warm, encouraging, and psychological-safe English AI Tutor.
Rules:
1. Short & Interactive: Keep responses concise (1-3 sentences) to maintain dynamic dialogue.
2. Smart Correction Layer: If the user makes a grammar or vocabulary error, politely acknowledge their point first, then show a gentle correction in this exact format:
   - 💡 Gentle Correction: [Corrected sentence]
   - 🎯 Better Expression: [More natural phrasing]
3. Encouragement: Frequently praise their efforts and celebrate small victories.
4. Context Adaptation: Match your personality to the chosen mode (Friendly peer for Daily Life/College; Professional HR Interviewer for Interview Prep).`;

  /** Extra per-session context appended to the system prompt. */
  DT.buildSystemPrompt = function (mode, scenario, lang) {
    return (
      DT.SYSTEM_PROMPT +
      `\n\nSession context:\n` +
      `- Current mode: ${mode.label}. Persona: ${mode.persona}.\n` +
      `- Scenario: ${scenario.label}. ${scenario.role}\n` +
      `- The learner's mother tongue is ${lang.name}. Reply in simple, clear English only, unless the learner explicitly asks for help in their own language.\n` +
      `- Use plain text only: no markdown, no asterisks, no bullet symbols other than the two correction lines.\n` +
      `- Put the two correction lines on their own separate lines AFTER your short reply, and include them ONLY when there is a real grammar or vocabulary mistake. Never invent a mistake.\n` +
      `- Never mock or pressure the learner. Treat hesitation or short answers warmly.\n` +
      `- End your reply with one easy follow-up question that keeps the conversation moving (for the correction case, put the question in your main reply, before the correction lines).`
    );
  };

  /* ------------------------------------------------------------------ */
  /* Languages (UI help + Gemini translation target + TTS locale)        */
  /* ------------------------------------------------------------------ */
  DT.LANGUAGES = [
    { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ', bcp: 'kn-IN' },
    { code: 'hi', name: 'Hindi', native: 'हिन्दी', bcp: 'hi-IN' },
    { code: 'ta', name: 'Tamil', native: 'தமிழ்', bcp: 'ta-IN' },
    { code: 'ml', name: 'Malayalam', native: 'മലയാളം', bcp: 'ml-IN' },
    { code: 'te', name: 'Telugu', native: 'తెలుగు', bcp: 'te-IN' },
    { code: 'mr', name: 'Marathi', native: 'मराठी', bcp: 'mr-IN' },
    { code: 'bn', name: 'Bengali', native: 'বাংলা', bcp: 'bn-IN' },
    { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી', bcp: 'gu-IN' },
    { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ', bcp: 'pa-IN' },
    { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ', bcp: 'or-IN' },
    { code: 'ur', name: 'Urdu', native: 'اردو', bcp: 'ur-IN' },
    { code: 'as', name: 'Assamese', native: 'অসমীয়া', bcp: 'as-IN' },
  ];

  /** Static, always-available UI help text in each language (no API call needed). */
  DT.I18N = {
    kn: {
      help: 'ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಮಾತನಾಡಿ ಅಥವಾ ಟೈಪ್ ಮಾಡಿ. ಸಹಾಯ ಬೇಕಾದರೆ ಯಾವುದೇ ಉತ್ತರದ ಕೆಳಗಿರುವ “ನನ್ನ ಭಾಷೆಯಲ್ಲಿ ವಿವರಿಸಿ” ಒತ್ತಿ.',
      tip: 'ತಪ್ಪು ಮಾಡುವುದು ಸರಿ! ತಪ್ಪುಗಳಿಂದಲೇ ಮೆದುಳು ಅತಿ ವೇಗವಾಗಿ ಕಲಿಯುತ್ತದೆ.',
    },
    hi: {
      help: 'अंग्रेज़ी में बोलिए या टाइप कीजिए। मदद चाहिए तो किसी भी जवाब के नीचे “मेरी भाषा में समझाएँ” दबाइए।',
      tip: 'गलतियाँ करना ठीक है! गलतियों से ही दिमाग सबसे तेज़ सीखता है।',
    },
    ta: {
      help: 'ஆங்கிலத்தில் பேசுங்கள் அல்லது தட்டச்சு செய்யுங்கள். உதவி தேவைப்பட்டால் எந்தப் பதிலுக்கும் கீழுள்ள “என் மொழியில் விளக்கு” என்பதை அழுத்துங்கள்.',
      tip: 'தவறு செய்வது பரவாயில்லை! தவறுகளிலிருந்துதான் மூளை மிக வேகமாகக் கற்கிறது.',
    },
    ml: {
      help: 'ഇംഗ്ലീഷിൽ സംസാരിക്കുക അല്ലെങ്കിൽ ടൈപ്പ് ചെയ്യുക. സഹായം വേണമെങ്കിൽ ഏതൊരു മറുപടിയുടെയും താഴെയുള്ള “എന്റെ ഭാഷയിൽ വിശദീകരിക്കുക” അമർത്തുക.',
      tip: 'തെറ്റുകൾ വരുന്നത് സാരമില്ല! തെറ്റുകളിൽ നിന്നാണ് തലച്ചോർ ഏറ്റവും വേഗത്തിൽ പഠിക്കുന്നത്.',
    },
    te: {
      help: 'ఇంగ్లీష్‌లో మాట్లాడండి లేదా టైప్ చేయండి. సహాయం కావాలంటే ఏ సమాధానం కిందనైనా “నా భాషలో వివరించు” నొక్కండి.',
      tip: 'తప్పులు చేయడం పర్వాలేదు! తప్పుల నుంచే మెదడు అత్యంత వేగంగా నేర్చుకుంటుంది.',
    },
    mr: {
      help: 'इंग्रजीत बोला किंवा टाइप करा. मदत हवी असल्यास कोणत्याही उत्तराखालील “माझ्या भाषेत समजवा” दाबा.',
      tip: 'चुका होणं ठीक आहे! चुकांमधूनच मेंदू सर्वात वेगाने शिकतो.',
    },
    bn: {
      help: 'ইংরেজিতে বলুন বা টাইপ করুন। সাহায্য লাগলে যেকোনো উত্তরের নিচে “আমার ভাষায় বুঝিয়ে দিন” চাপুন।',
      tip: 'ভুল করা ঠিক আছে! ভুল থেকেই মস্তিষ্ক সবচেয়ে দ্রুত শেখে।',
    },
    gu: {
      help: 'અંગ્રેજીમાં બોલો અથવા ટાઇપ કરો. મદદ જોઈએ તો કોઈપણ જવાબની નીચે “મારી ભાષામાં સમજાવો” દબાવો.',
      tip: 'ભૂલ થવી સામાન્ય છે! ભૂલોમાંથી જ મગજ સૌથી ઝડપથી શીખે છે.',
    },
    pa: {
      help: 'ਅੰਗਰੇਜ਼ੀ ਵਿੱਚ ਬੋਲੋ ਜਾਂ ਟਾਈਪ ਕਰੋ। ਮਦਦ ਚਾਹੀਦੀ ਹੋਵੇ ਤਾਂ ਕਿਸੇ ਵੀ ਜਵਾਬ ਹੇਠਾਂ “ਮੇਰੀ ਭਾਸ਼ਾ ਵਿੱਚ ਸਮਝਾਓ” ਦਬਾਓ।',
      tip: 'ਗਲਤੀਆਂ ਹੋਣਾ ਠੀਕ ਹੈ! ਗਲਤੀਆਂ ਤੋਂ ਹੀ ਦਿਮਾਗ ਸਭ ਤੋਂ ਤੇਜ਼ੀ ਨਾਲ ਸਿੱਖਦਾ ਹੈ।',
    },
    or: {
      help: 'ଇଂରାଜୀରେ କୁହନ୍ତୁ କିମ୍ବା ଟାଇପ୍ କରନ୍ତୁ। ସାହାଯ୍ୟ ଦରକାର ହେଲେ ଯେକୌଣସି ଉତ୍ତର ତଳେ “ମୋ ଭାଷାରେ ବୁଝାନ୍ତୁ” ଦବାନ୍ତୁ।',
      tip: 'ଭୁଲ କରିବା ଠିକ୍ ଅଛି! ଭୁଲରୁ ହିଁ ମସ୍ତିଷ୍କ ସବୁଠୁ ଶୀଘ୍ର ଶିଖେ।',
    },
    ur: {
      help: 'انگریزی میں بولیں یا ٹائپ کریں۔ مدد چاہیے ہو تو کسی بھی جواب کے نیچے “میری زبان میں سمجھائیں” دبائیں۔',
      tip: 'غلطیاں ہونا ٹھیک ہے! غلطیوں سے ہی دماغ سب سے تیزی سے سیکھتا ہے۔',
    },
    as: {
      help: 'ইংৰাজীত কওক বা টাইপ কৰক। সহায় লাগিলে যিকোনো উত্তৰৰ তলত থকা “মোৰ ভাষাত বুজাই দিয়ক” টিপক।',
      tip: 'ভুল হোৱাটো ঠিকেই! ভুলৰ পৰাই মগজুৱে আটাইতকৈ দ্ৰুতকৈ শিকে।',
    },
  };

  /* ------------------------------------------------------------------ */
  /* Practice modes and scenarios                                        */
  /* ------------------------------------------------------------------ */
  DT.MODES = {
    daily: {
      id: 'daily',
      emoji: '💬',
      label: 'Daily Conversation',
      desc: 'Small talk, shopping, ordering food',
      persona: 'a friendly, relaxed peer',
      scenarios: [
        { id: 'smalltalk', label: '☕ Small talk', role: 'Chat casually like a friendly peer.', opener: "Hi, I'm Echo! 😊 It's great to meet you. How is your day going so far?" },
        { id: 'shopping', label: '🛍️ Shopping', role: 'Role-play a friendly shopkeeper. The learner is a customer. Stay in role but remain a kind tutor.', opener: "Welcome to our store! 🛍️ I'm the shopkeeper today. What are you looking for?" },
        { id: 'food', label: '🍽️ Ordering food', role: 'Role-play a friendly café waiter. The learner is a customer ordering food. Stay in role but remain a kind tutor.', opener: 'Hello, welcome to our café! 🍽️ Are you ready to order, or would you like a minute with the menu?' },
        { id: 'college', label: '🎒 College chat', role: 'Chat like a friendly classmate about everyday college life.', opener: "Hey! Let's chat about college life. 🎒 What's your favourite part of a day on campus?" },
      ],
    },
    college: {
      id: 'college',
      emoji: '🎓',
      label: 'College & Student Life',
      desc: 'Presentations, projects, lab work',
      persona: 'a supportive, friendly classmate and study partner',
      scenarios: [
        { id: 'presentation', label: '📊 Classroom presentation', role: 'The learner is giving a short classroom presentation. Act as a kind classmate/audience who asks easy questions.', opener: "Hi! Imagine this is your classroom presentation. 📊 Whenever you're ready, introduce your topic to the class." },
        { id: 'project', label: '🧩 Project discussion', role: 'Act as a teammate discussing a group project with the learner.', opener: 'Hey teammate! 🧩 Tell me about our project. What problem are we trying to solve?' },
        { id: 'lab', label: '🧪 Lab work', role: 'Act as a lab partner discussing a practical or experiment.', opener: "Hi lab partner! 🧪 What experiment or practical work are we doing today?" },
      ],
    },
    interview: {
      id: 'interview',
      emoji: '💼',
      label: 'Interview Preparation',
      desc: 'HR, technical, self-introduction',
      persona: 'a professional but kind HR interviewer',
      scenarios: [
        { id: 'hr', label: '🤝 HR interview', role: 'Act as a professional, courteous HR interviewer asking standard HR questions one at a time.', opener: "Good morning, and welcome! I'm your HR interviewer today. Tell me, why are you interested in this role?" },
        { id: 'tech', label: '💻 Technical interview', role: 'Act as a professional technical interviewer asking about projects and fundamentals, one question at a time, at a beginner-friendly level.', opener: "Hello! Let's begin the technical round. Could you walk me through a project you have built and the technologies you used?" },
        { id: 'intro', label: '🙋 Self-introduction', role: 'Act as an interviewer who starts with self-introduction and then asks gentle follow-ups.', opener: 'Good morning! Please make yourself comfortable. To begin, could you introduce yourself in a few sentences?' },
      ],
    },
  };

  /* ------------------------------------------------------------------ */
  /* Achievements                                                        */
  /* ------------------------------------------------------------------ */
  DT.ACHIEVEMENTS = [
    { id: 'first_hello', icon: '👋', title: 'First Hello', desc: 'You sent your first message. Every fluent speaker started here!' },
    { id: 'brave_voice', icon: '🎤', title: 'Brave Voice', desc: 'You spoke a full sentence out loud. That takes courage!' },
    { id: 'clean_sentence', icon: '✨', title: 'Clean Sentence', desc: 'A sentence with no corrections needed. Lovely work!' },
    { id: 'comeback', icon: '💪', title: 'Mistake Master', desc: 'You learned from a correction. That is how brains grow.' },
    { id: 'phrase_collector', icon: '📚', title: 'Phrase Collector', desc: 'You learned 3 new phrases or words.' },
    { id: 'chat_champ', icon: '🏆', title: 'Conversation Champ', desc: 'You completed 5 exchanges in one session.' },
    { id: 'mode_explorer', icon: '🧭', title: 'Mode Explorer', desc: 'You tried all three practice modes.' },
    { id: 'language_bridge', icon: '🌐', title: 'Language Bridge', desc: 'You used "Explain in my language" to understand better.' },
  ];

  /* ------------------------------------------------------------------ */
  /* Positive psychology content                                         */
  /* ------------------------------------------------------------------ */
  DT.TIPS = [
    'It is okay to make mistakes! Making mistakes is how the brain learns fastest.',
    "You don't need perfect English, you need brave English. Every sentence counts.",
    'Feeling nervous is normal. Take one slow breath, then say just one sentence.',
    'Echo never judges, and nothing you say is saved. This is your private practice space.',
    "Progress beats perfection. Yesterday's mistake is today's lesson.",
    'Stuck for words? Tap "Need a hint?". Borrowing a phrase is real learning.',
  ];

  DT.NUDGES = [
    'Take your time, there is no rush. 💛 Even a few words is a great start.',
    'Still thinking? That is perfectly fine. Want a hint to get started?',
    'No pressure at all. A short answer is a good answer. 🌱',
  ];

  DT.ENCOURAGE = {
    good: ['Beautiful sentence! 🌟', 'That sounded natural. Well done! 👏', "You're getting more fluent with every message 💫", 'Clear and confident. Keep going! 🚀'],
    fix: ['Great try! One tiny polish below 💡', 'Love the effort, you were so close! 🌈', 'Mistakes mean you are learning. Nice work! 🌱', 'Good attempt! A small tweak makes it shine ✨'],
    short: ['Short and brave! Add one more detail whenever you like 😊', 'Nice start! Try adding a little more when you feel ready 🌼'],
    mic: ['Speaking out loud is the hardest part, and you did it! 🎤', 'Your voice matters. Great job speaking up! 🌟'],
  };
})(window);
