/* DailyTalk AI - Gemini client (free tier) + offline demo mode. Nothing is persisted. */
(function (w) {
  'use strict';
  const DT = (w.DT = w.DT || {});

  const BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';
  // If the chosen model is retired (HTTP 404), the next one in this list is tried automatically.
  const FALLBACK_CHAIN = ['gemini-flash-latest', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash', 'gemini-2.0-flash'];

  class AIError extends Error {
    constructor(message, kind) {
      super(message);
      this.kind = kind || 'unknown';
    }
  }

  function textOf(data) {
    const parts = data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
    return parts ? parts.map((p) => p.text || '').join('').trim() : '';
  }

  const AI = {
    key: '', // lives in memory only
    model: 'gemini-flash-latest',
    demo: false,
    AIError,

    ready() {
      return this.demo || !!this.key;
    },

    candidates() {
      return [this.model].concat(FALLBACK_CHAIN.filter((m) => m !== this.model));
    },

    async generate(body) {
      if (!this.key) throw new AIError('No API key yet. Add one in settings.', 'nokey');
      let lastErr = null;
      for (const model of this.candidates()) {
        let res;
        try {
          res = await fetch(BASE + model + ':generateContent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-goog-api-key': this.key },
            body: JSON.stringify(body),
          });
        } catch (e) {
          throw new AIError('Network problem. Please check your connection.', 'network');
        }
        if (res.ok) {
          const data = await res.json();
          if (data.promptFeedback && data.promptFeedback.blockReason) {
            throw new AIError('That message could not be processed. Try rephrasing it.', 'blocked');
          }
          this.model = model; // remember the working model
          return textOf(data);
        }
        let msg = '';
        try {
          const j = await res.json();
          msg = (j.error && j.error.message) || '';
        } catch (_) {
          /* no body */
        }
        if (res.status === 404 || (/model/i.test(msg) && /(no longer|not found|not supported|unavailable|not available)/i.test(msg) && !/api key/i.test(msg))) {
          lastErr = new AIError('Model ' + model + ' is not available.', 'model');
          continue;
        }
        if (res.status === 429) throw new AIError('Free-tier limit reached for a moment. Wait about 30 seconds and try again.', 'rate');
        if (res.status === 401 || res.status === 403 || (res.status === 400 && /api key/i.test(msg))) {
          throw new AIError('That API key was not accepted. Please check it in settings.', 'key');
        }
        throw new AIError(msg || 'Request failed (' + res.status + ').', 'http');
      }
      throw lastErr || new AIError('No Gemini model is available for this key.', 'model');
    },

    /** Quick key check. */
    async ping() {
      await this.generate({ contents: [{ role: 'user', parts: [{ text: 'Reply with the single word OK.' }] }] });
      return true;
    },

    /** Main tutoring turn. history = [{role:'user'|'model', text}] starting with Echo's opener. */
    async chat(ctx) {
      const system = DT.buildSystemPrompt(ctx.mode, ctx.scenario, ctx.lang);
      const contents = [{ role: 'user', parts: [{ text: "Let's begin the practice session." }] }].concat(
        ctx.history.map((m) => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] }))
      );
      const out = await this.generate({
        system_instruction: { parts: [{ text: system }] },
        contents,
        generationConfig: { temperature: 0.8, maxOutputTokens: 2048 },
      });
      if (!out) throw new AIError('Echo had nothing to say. Please try again.', 'empty');
      return out;
    },

    /** Instant hints + vocabulary booster as JSON. */
    async hints(ctx) {
      const prompt =
        'You help an English learner who is stuck in a spoken practice conversation.\n' +
        'Mode: ' + ctx.mode.label + '. Scenario: ' + ctx.scenario.label + '.\n' +
        'The tutor just said: "' + ctx.lastAI + '"\n' +
        'Return ONLY JSON in this exact shape: {"replies":["...","...","..."],"vocab":[{"word":"...","meaning":"simple English meaning","example":"short example sentence"},{"word":"...","meaning":"...","example":"..."}]}\n' +
        'Give 3 short, natural, beginner-friendly replies the learner could say next (each under 14 words), and 2 useful words or phrases for this situation.';
      const out = await this.generate({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, responseMimeType: 'application/json' },
      });
      const cleaned = out.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
      let data;
      try {
        data = JSON.parse(cleaned);
      } catch (e) {
        throw new AIError('Could not read the hints. Please try again.', 'parse');
      }
      return {
        replies: Array.isArray(data.replies) ? data.replies.slice(0, 3).map(String) : [],
        vocab: Array.isArray(data.vocab) ? data.vocab.slice(0, 2) : [],
      };
    },

    /** "Explain in my language". */
    async translate(text, lang) {
      const prompt =
        'Translate this English tutor message into ' + lang.name + ' (' + lang.native + '). ' +
        'Then, in ' + lang.name + ', briefly explain any tricky word or phrase. ' +
        'Use simple, friendly ' + lang.name + '. Keep it under 90 words. Plain text only, no markdown.\n\n' +
        'Message: "' + text + '"';
      const out = await this.generate({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.3, maxOutputTokens: 1024 },
      });
      if (!out) throw new AIError('No explanation came back. Please try again.', 'empty');
      return out;
    },
  };

  /* ------------------------------------------------------------------ */
  /* Demo mode: scripted replies so the UI can be tried without a key    */
  /* ------------------------------------------------------------------ */
  const FIXES = [
    [/\b(we|they|you) was\b/i, (m, a) => a + ' were'],
    [/\b(he|she|it) don't\b/i, (m, a) => a + " doesn't"],
    [/\bi (is|are)\b/i, () => 'I am'],
    [/\bi am agree\b/i, () => 'I agree'],
    [/\byesterday i go\b/i, () => 'yesterday I went'],
    [/\bmore better\b/i, () => 'better'],
    [/\bdiscuss about\b/i, () => 'discuss'],
    [/\bme and my friend\b/i, () => 'My friend and I'],
    [/\bi am knowing\b/i, () => 'I know'],
  ];

  const DEMO_FOLLOWUPS = {
    daily: ['That sounds nice! Tell me a little more about it.', 'Interesting! What do you usually do after that?', 'Great! And how do you feel about it?'],
    college: ['Good point! What is the next step you plan to take?', 'I see! Who is helping you with this?', 'Nice! What was the hardest part?'],
    interview: ['Thank you for sharing that. Can you give me one specific example?', 'Good answer. What would you say is your biggest strength?', 'Understood. Where do you see yourself in three years?'],
  };

  const DEMO_HINTS = {
    daily: {
      replies: ["I'm doing well, thank you!", 'Could you say that again, please?', "I'd like to know more about it."],
      vocab: [{ word: 'How about you?', meaning: 'A friendly way to return a question', example: "I'm fine. How about you?" }, { word: 'Sounds good', meaning: 'I agree or I like the idea', example: 'Dinner at eight? Sounds good!' }],
    },
    college: {
      replies: ['Our project is about solving a real problem.', 'I need a little more time to finish it.', 'Could you help me with this part?'],
      vocab: [{ word: 'deadline', meaning: 'The last date to finish something', example: 'Our deadline is on Friday.' }, { word: 'brainstorm', meaning: 'Share ideas freely as a group', example: "Let's brainstorm some topics." }],
    },
    interview: {
      replies: ['I am a hardworking and curious learner.', 'I have built a project using Python.', 'I enjoy working in a team.'],
      vocab: [{ word: 'strength', meaning: 'Something you do very well', example: 'My biggest strength is problem solving.' }, { word: 'passionate about', meaning: 'Very interested in something', example: 'I am passionate about technology.' }],
    },
  };

  let demoTurn = 0;
  DT.Demo = {
    reply(text, modeId) {
      let fixed = text;
      FIXES.forEach(([re, fn]) => {
        fixed = fixed.replace(re, fn);
      });
      if (/(^|\s)i(\s|')/.test(fixed)) fixed = fixed.replace(/(^|\s)i(?=\s|')/g, '$1I');
      const changed = fixed.trim() !== text.trim();
      const list = DEMO_FOLLOWUPS[modeId] || DEMO_FOLLOWUPS.daily;
      let out = 'Thanks for sharing that, great effort! ' + list[demoTurn++ % list.length];
      if (changed) {
        const corrected = fixed.charAt(0).toUpperCase() + fixed.slice(1);
        out += '\n- 💡 Gentle Correction: ' + corrected + '\n- 🎯 Better Expression: ' + corrected.replace(/[.!?]*$/, '') + ', and I would love to add more detail.';
      }
      return out;
    },
    hints(modeId) {
      return DEMO_HINTS[modeId] || DEMO_HINTS.daily;
    },
    translate(lang) {
      return lang.native + ': Demo mode cannot translate. Connect a free Gemini key (⚙️ API key) to unlock "Explain in my language".';
    },
  };

  DT.AI = AI;
})(window);
