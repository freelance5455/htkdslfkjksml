# Fluorite IOS — visual prototype

This package is a local, visual-only UI prototype. Switches and the range control change interface state only; they do not connect to games, services, or external systems.

## Build into an APK on Android
1. Open a trusted HTML-to-APK builder app.
2. Select `index.html` as the local page / start page.
3. Set app name to `Fluorite IOS` and optionally choose an icon.
4. Build the APK.

The project is self-contained: no external assets, APIs, network calls, or libraries.
