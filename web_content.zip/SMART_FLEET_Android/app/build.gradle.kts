plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "it.smartfleet.app"; compileSdk = 35
 defaultConfig { applicationId = "it.smartfleet.app"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" } }
