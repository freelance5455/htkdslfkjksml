package it.smartfleet.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

class FleetDb(context: Context) : SQLiteOpenHelper(context, "smart_fleet.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        for (table in listOf("vehicles", "rentals", "tags")) {
            db.execSQL("CREATE TABLE $table (id TEXT PRIMARY KEY NOT NULL, payload TEXT NOT NULL)")
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun load(): String? {
        val db = readableDatabase
        val result = JSONObject()
        var count = 0
        for (table in listOf("vehicles", "rentals", "tags")) {
            val arr = org.json.JSONArray()
            db.rawQuery("SELECT payload FROM $table ORDER BY rowid", null).use { c ->
                while (c.moveToNext()) { arr.put(JSONObject(c.getString(0))); count++ }
            }
            result.put(table, arr)
        }
        return if (count == 0) null else result.toString()
    }
    fun save(json: String) {
        val source = JSONObject(json)
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (table in listOf("vehicles", "rentals", "tags")) {
                val records = source.optJSONArray(table) ?: org.json.JSONArray()
                db.delete(table, null, null)
                for (i in 0 until records.length()) {
                    val obj = records.getJSONObject(i)
                    val id = obj.getString("id")
                    val values = android.content.ContentValues().apply {
                        put("id", id); put("payload", obj.toString())
                    }
                    db.insertOrThrow(table, null, values)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}
