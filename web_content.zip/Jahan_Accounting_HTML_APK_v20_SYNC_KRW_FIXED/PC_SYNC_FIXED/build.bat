@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Jahan Accounting WWK26 - One Click Full Build
color 0A

set "ROOT=%~dp0"
set "PC=%ROOT%PC\jahan_pc_final"
set "ANDROID=%ROOT%Android\jahan_android_final"
set "OUT=%ROOT%dist"
set "FAILED=0"

if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"

echo ================================================================
echo       JAHAN ACCOUNTING WWK26 - ONE CLICK FULL BUILD
echo ================================================================
echo.
echo [1] Windows Accounting EXE
echo [2] Windows License Manager EXE
echo [3] Android APK
echo.

REM ==================== Python ====================
where py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python launcher ^(py^) was not found in PATH.
    set "FAILED=1"
    goto :summary
)
py -c "import sys; print('Python:', sys.version)"
if errorlevel 1 (
    echo [ERROR] Python could not start.
    set "FAILED=1"
    goto :summary
)

py -m pip show pyinstaller >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing PyInstaller...
    py -m pip install pyinstaller
    if errorlevel 1 (
        echo [ERROR] PyInstaller installation failed.
        set "FAILED=1"
        goto :summary
    )
)

REM ==================== PC Accounting ====================
echo.
echo [1/3] Building Jahan Accounting Windows EXE...
pushd "%PC%"
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "Jahan_Accounting_v18_78.spec" del /q "Jahan_Accounting_v18_78.spec"
py -m PyInstaller --noconfirm --clean --onefile --windowed --name "Jahan_Accounting_v18_78" --icon "jahan_icon.ico" --add-data "logo.png;." --add-data "jahan_icon.ico;." "jahan_accounting.py"
if errorlevel 1 (
    echo [ERROR] Jahan Accounting EXE build failed.
    set "FAILED=1"
) else if not exist "dist\Jahan_Accounting_v18_78.exe" (
    echo [ERROR] Jahan Accounting EXE was not created.
    set "FAILED=1"
) else (
    copy /y "dist\Jahan_Accounting_v18_78.exe" "%OUT%\Jahan_Accounting_v18_78.exe" >nul
    echo [OK] Jahan_Accounting_v18_78.exe
)
popd

REM ==================== License Manager ====================
echo.
echo [2/3] Building License Manager Windows EXE...
pushd "%PC%"
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist license_manager.spec del /q license_manager.spec
py -m PyInstaller --noconfirm --clean --onefile --windowed --name "Jahan_License_Manager" "license_manager.py"
if errorlevel 1 (
    echo [ERROR] License Manager build failed.
    set "FAILED=1"
) else if not exist "dist\Jahan_License_Manager.exe" (
    echo [ERROR] License Manager EXE was not created.
    set "FAILED=1"
) else (
    copy /y "dist\Jahan_License_Manager.exe" "%OUT%\Jahan_License_Manager.exe" >nul
    echo [OK] Jahan_License_Manager.exe
)
popd

REM ==================== Android ====================
echo.
echo [3/3] Building Android APK...
if not defined ANDROID_HOME if defined ANDROID_SDK_ROOT set "ANDROID_HOME=%ANDROID_SDK_ROOT%"
if not defined ANDROID_HOME (
    echo [WARN] Android SDK is not configured.
    echo        Set ANDROID_HOME or ANDROID_SDK_ROOT on Windows.
    echo        PC components remain available.
    goto :summary
)
if not exist "%ANDROID%\gradlew.bat" (
    echo [ERROR] Android Gradle wrapper not found.
    set "FAILED=1"
    goto :summary
)

pushd "%ANDROID%"
call gradlew.bat clean assembleDebug
if errorlevel 1 (
    echo [ERROR] Android APK build failed.
    set "FAILED=1"
) else if not exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo [ERROR] Android build finished but APK was not found.
    set "FAILED=1"
) else (
    copy /y "app\build\outputs\apk\debug\app-debug.apk" "%OUT%\Jahan_Accounting_Android_WWK26_debug.apk" >nul
    echo [OK] Jahan_Accounting_Android_WWK26_debug.apk
)
popd

:summary
echo.
echo ================================================================
echo                         BUILD SUMMARY
echo ================================================================
if exist "%OUT%\Jahan_Accounting_v18_78.exe" echo [OK] Jahan_Accounting_v18_78.exe
if exist "%OUT%\Jahan_License_Manager.exe" echo [OK] Jahan_License_Manager.exe
if exist "%OUT%\Jahan_Accounting_Android_WWK26_debug.apk" echo [OK] Jahan_Accounting_Android_WWK26_debug.apk
if not exist "%OUT%\Jahan_Accounting_v18_78.exe" echo [--] PC EXE not created
if not exist "%OUT%\Jahan_License_Manager.exe" echo [--] License Manager EXE not created
if not exist "%OUT%\Jahan_Accounting_Android_WWK26_debug.apk" echo [--] Android APK not created

echo.
echo Output folder:
echo %OUT%
echo.
if "%FAILED%"=="0" (
    echo BUILD COMPLETED SUCCESSFULLY.
) else (
    echo BUILD FINISHED WITH ERRORS OR UNAVAILABLE COMPONENTS.
)
echo.
pause
if "%FAILED%"=="0" exit /b 0
exit /b 1
