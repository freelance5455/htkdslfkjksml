این فایل jahan_accounting.py نسخه PC برای اتصال Android HTML است.

اصلاحات:
- /api/web-sync برای Sync JSON بین PC و Android
- CORS برای WebView/HTML محلی
- OPTIONS برای preflight
- ادغام مشتریان، عملیات حساب و کتابچه یادداشت
- پشتیبانی PC برای بازکردن KRW ساخته‌شده توسط نسخه HTML و ادغام اطلاعات آن

فایل را در نسخه PC پروژه خود جایگزین کنید و سپس build.bat را اجرا کنید.
