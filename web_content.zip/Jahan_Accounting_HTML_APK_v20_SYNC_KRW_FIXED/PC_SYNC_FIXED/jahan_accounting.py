import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import tkinter.font as tkfont
import sqlite3, csv, os, sys, webbrowser, urllib.parse, hashlib, hmac, base64, json, shutil, threading, urllib.request, urllib.error, platform, uuid, tempfile, re, ast, operator, subprocess, socket, secrets, http.server, socketserver, html, ssl
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_CENTER
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    REPORTLAB_OK = True
except Exception:
    REPORTLAB_OK = False
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    ARABIC_SHAPING_OK = True
except Exception:
    ARABIC_SHAPING_OK = False
from datetime import datetime, date, timedelta
from decimal import Decimal, ROUND_HALF_UP, getcontext
try:
    from PIL import Image, ImageTk
    import pytesseract
    OCR_OK = True
except Exception:
    OCR_OK = False

try:
    import qrcode
    QRCODE_OK = True
except Exception:
    qrcode = None
    QRCODE_OK = False

# Professional Excel export (real .xlsx, RTL/Persian-friendly).
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
    OPENPYXL_OK = True
except Exception:
    OPENPYXL_OK = False


# --- Reliable Persian (Jalali) date formatting ---
def _gregorian_to_jalali(gy, gm, gd):
    # Integer-only conversion based on the well-known 2820-year Jalali cycle.
    g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + 365*gy + (gy2+3)//4 - (gy2+99)//100 + (gy2+399)//400 + gd + g_d_m[gm-1]
    jy = -1595 + 33*(days//12053)
    days %= 12053
    jy += 4*(days//1461)
    days %= 1461
    if days > 365:
        jy += (days-1)//365
        days = (days-1)%365
    if days < 186:
        jm = 1 + days//31
        jd = 1 + days%31
    else:
        jm = 7 + (days-186)//30
        jd = 1 + (days-186)%30
    return jy, jm, jd

JALALI_MONTHS_AF = ("حمل", "ثور", "جوزا", "سرطان", "اسد", "سنبله", "میزان", "عقرب", "قوس", "جدی", "دلو", "حوت")

def jalali_month_name(month):
    try:
        return JALALI_MONTHS_AF[int(month)-1]
    except Exception:
        return str(month)

def _jalali_to_gregorian(jy, jm, jd):
    """Reverse the local Jalali conversion without an external dependency."""
    target=(int(jy), int(jm), int(jd))
    center=date(int(jy)+621, 3, 21)
    lo=center-timedelta(days=370)
    hi=center+timedelta(days=370)
    while lo <= hi:
        mid=lo+(hi-lo)//2
        got=_gregorian_to_jalali(mid.year, mid.month, mid.day)
        if got < target:
            lo=mid+timedelta(days=1)
        elif got > target:
            hi=mid-timedelta(days=1)
        else:
            return mid
    raise ValueError("تاریخ هجری شمسی معتبر نیست")

def current_jalali_parts():
    return _gregorian_to_jalali(date.today().year, date.today().month, date.today().day)

def jalali_date(dt=None):
    dt = dt or datetime.now()
    jy,jm,jd = _gregorian_to_jalali(dt.year, dt.month, dt.day)
    return f"{jy:04d}/{jm:02d}/{jd:02d}"

def dual_datetime(value=None):
    """Show both Jalali and Gregorian dates while retaining stored Gregorian data."""
    try:
        if isinstance(value, datetime): dt=value
        else:
            text=str(value or '').strip().replace('T',' ')
            dt=datetime.strptime(text[:19], '%Y-%m-%d %H:%M:%S') if len(text)>=19 else datetime.strptime(text[:16], '%Y-%m-%d %H:%M')
        return f"{jalali_date(dt)}  {dt:%H:%M:%S} | {dt:%Y/%m/%d}"
    except Exception:
        return str(value or '')

def dual_date_only(value=None):
    try:
        text=str(value or '').strip()
        dt=datetime.strptime(text[:10], '%Y-%m-%d')
        return f"{jalali_date(dt)} | {dt:%Y/%m/%d}"
    except Exception:
        return str(value or '')

APP_NAME = "نرم افزار حسابداری جهان"
APP_VERSION = "20.0.1"

# --- Reliable HTTPS for online exchange rates / APIs ---
def _jahan_ssl_context():
    """Create a verified TLS context even when Windows/Python has no usable CA bundle.

    We NEVER disable certificate verification.  The app first uses certifi's
    maintained Mozilla CA bundle, then a bundled cacert.pem, then the platform
    default trust store.
    """
    try:
        import certifi
        ca = certifi.where()
        if ca and os.path.exists(ca):
            return ssl.create_default_context(cafile=ca)
    except Exception:
        pass
    try:
        bundled = os.path.join(RESOURCE_BASE, 'cacert.pem') if 'RESOURCE_BASE' in globals() else ''
        if bundled and os.path.exists(bundled):
            return ssl.create_default_context(cafile=bundled)
    except Exception:
        pass
    return ssl.create_default_context()

def _jahan_urlopen(request, timeout=15):
    """Verified HTTPS opener used by online rates and API calls."""
    return urllib.request.urlopen(request, timeout=timeout, context=_jahan_ssl_context())


def _set_windows_app_identity(hwnd=None):
    """Make the Tk top-level window a real Windows taskbar application.
    This fixes missing taskbar buttons/icons when a custom borderless title bar is used.
    """
    if os.name != "nt":
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        shell32 = ctypes.windll.shell32
        # Stable AppUserModelID keeps the taskbar identity tied to this app.
        shell32.SetCurrentProcessExplicitAppUserModelID("JahanAccounting.World.16")
        if hwnd is None:
            return
        GWL_EXSTYLE = -20
        WS_EX_APPWINDOW = 0x00040000
        WS_EX_TOOLWINDOW = 0x00000080
        get_long = getattr(user32, "GetWindowLongPtrW", user32.GetWindowLongW)
        set_long = getattr(user32, "SetWindowLongPtrW", user32.SetWindowLongW)
        style = get_long(hwnd, GWL_EXSTYLE)
        style = (style | WS_EX_APPWINDOW) & ~WS_EX_TOOLWINDOW
        set_long(hwnd, GWL_EXSTYLE, style)
        user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0027)
    except Exception:
        pass

def _select_persian_font():
    try:
        families = set(tkfont.families())
        for name in ("B Nazanin", "B Nazanin UI", "BNazanin"):
            if name in families:
                return name
    except Exception:
        pass
    return "Tahoma"

UI_FONT = _select_persian_font()

if getattr(sys, "frozen", False):
    # PyInstaller installs the EXE under Program Files, which is normally not
    # writable by a standard Windows user. Keep bundled/read-only resources
    # beside the EXE, but store the live database and user data in LocalAppData.
    BASE = os.path.dirname(os.path.abspath(sys.executable))
    RESOURCE_BASE = getattr(sys, "_MEIPASS", BASE)
    USER_DATA_BASE = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "JahanAccounting")
    os.makedirs(USER_DATA_BASE, exist_ok=True)
else:
    BASE = os.path.dirname(os.path.abspath(__file__))
    RESOURCE_BASE = BASE
    USER_DATA_BASE = BASE

if OCR_OK:
    try:
        _tess_candidates = [
            os.path.join(BASE, "tesseract", "tesseract.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Tesseract-OCR", "tesseract.exe"),
            os.path.join(os.environ.get("ProgramW6432", ""), "Tesseract-OCR", "tesseract.exe"),
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Tesseract-OCR", "tesseract.exe"),
            shutil.which("tesseract.exe"),
            shutil.which("tesseract"),
        ]
        for _tess_exe in _tess_candidates:
            if _tess_exe and os.path.exists(_tess_exe):
                pytesseract.pytesseract.tesseract_cmd = _tess_exe
                _local_tessdata = os.path.join(BASE, "tessdata")
                if os.path.isdir(_local_tessdata):
                    os.environ["TESSDATA_PREFIX"] = _local_tessdata
                break
    except Exception:
        pass

BACKUP_DIR = os.path.join(USER_DATA_BASE, "backups")
# Automatic KRW data backups live in the user's Documents/KRW folder.
KRW_AUTO_DIR = os.path.join(os.path.expanduser("~"), "Documents", "KRW")
# License v20.0.3: keep the signing material split so the old V11 token is not
# reused for new activations. This is still an offline license, so it is not
# a substitute for a server-side entitlement service.
_LICENSE_PART_A = b"JHN20"
_LICENSE_PART_B = b"7f4c"
_LICENSE_PART_C = b"9B2A"
LICENSE_VERSION = "20.0.3"
LICENSE_PREFIX = "JAHAN20"
LICENSE_SECRET = hashlib.sha256(_LICENSE_PART_A + b"|" + _LICENSE_PART_B + b"|" + _LICENSE_PART_C + b"|" + LICENSE_VERSION.encode()).digest()
LEGACY_LICENSE_SECRET = b"JAHAN_ACCOUNTING_V11_LICENSE_2026"
DB = os.path.join(USER_DATA_BASE, "jahan_accounting.db")
SYNC_PORT = 8765
SYNC_TOKEN_FILE = os.path.join(USER_DATA_BASE, "sync_token.txt")




# --- Persian/Arabic rendering for Tkinter ---
# Keep Persian/Arabic strings in their original logical order. Modern Tk/Windows
# handles shaping and BiDi itself; pre-reversing/reshaping mixed strings breaks
# Persian when Latin text, numbers or symbols are present.
# UI language translation. This is intentionally applied only to widgets,
# never to database values, customer names, notes, receipts or accounting data.
CURRENT_UI_LANGUAGE = "fa"
_UI_WORDS = {
    "ps": {
        "داشبورد":"ډشبورډ","مشتری":"پېرودونکی","مشتریان":"پېرودونکي","معاملات":"معاملې",
        "معامله":"معامله","حساب":"حساب","حساب‌ها":"حسابونه","حسابهای":"حسابونه",
        "رسید":"رسید","رسیدها":"رسیدونه","رسیدهای":"رسیدونه","ثبت":"ثبتول","ذخیره":"ساتل",
        "حذف":"ړنګول","ویرایش":"سمون","ویرایش / حذف":"سمون / ړنګول","مشاهده":"کتل",
        "چاپ":"چاپ","بازگشت":"بېرته","گزارش":"راپور","گزارشات":"راپورونه","تنظیمات":"امستنې",
        "زبان":"ژبه","پشتیبانی":"ملاتړ","جستجو":"لټون","نمایش":"ښودل","افزودن":"زیاتول",
        "توضیحات":"یادښتونه","مبلغ":"مبلغ","ارز":"اسعار","نرخ":"نرخ","تاریخ":"نېټه",
        "زمان":"وخت","نوع":"ډول","مشتری / دکان":"پېرودونکی / دوکان","دریافت از مشتری":"له پېرودونکي ترلاسه کول",
        "پرداخت به مشتری":"پېرودونکي ته ورکول","قرضداری مشتری":"د پېرودونکي پور","بستانکاری مشتری":"د پېرودونکي طلب",
        "معادل AFN":"په افغانیو کې معادل","کل خرید":"ټول پېرود","کل فروش":"ټول پلور","نتیجه معاملات":"د معاملاتو پایله",
        "موفق":"بریالی","خطا":"تېروتنه","هشدار":"خبرداری","همه":"ټول","جدید":"نوی","بازکردن":"پرانیستل",
        "ارسال":"لېږل","واتساپ":"واټساپ","تلگرام":"ټیلیګرام","پشتیبان":"بیک اپ","درباره":"په اړه",
        "فروشگاه":"دوکانونه","مغازه":"دوکان","نرخ AFN":"د افغانیو نرخ","معادل":"معادل",
        "شماره رسید":"د رسید شمېره","شماره حساب":"د حساب شمېره","نوع رسید":"د رسید ډول",
        "با تشکر از اعتماد شما":"ستاسو له باور څخه مننه",
        "تعداد مشتریان":"د پېرودونکو شمېر","تعداد معاملات":"د معاملاتو شمېر","دکان‌ها و میوه‌فروشی‌ها":"د دوکانونو او مېوې پلورنځیو شمېر",
        "مانده حساب":"د حساب پاتې شونی","مانده خالص":"خالص پاتې شونی","آخرین معاملات":"وروستۍ معاملې","نمودار خرید و فروش ماهانه":"د میاشتني پېرود او پلور چارت",
        "مجموع خرید":"ټول پېرود","مجموع فروش":"ټول پلور","قرضداری":"پور","بستانکاری":"طلب","هر ارز جداگانه":"هر اسعار جلا",
        "قرضداری، بستانکاری و گردش مشتریان":"د پېرودونکو پور، طلب او راکړه ورکړه","مانده خالص = قرضداری − بستانکاری":"خالص پاتې شونی = پور − طلب",
        "رسید مشتری":"د پېرودونکي رسید","مرکز رسید مشتری":"د پېرودونکي د رسیدونو مرکز","آخرین رسیدهای مشتری":"د پېرودونکو وروستي رسیدونه",
        "ثبت رسید مشتری":"د پېرودونکي رسید ثبتول","ویرایش رسید مشتری":"د پېرودونکي رسید سمون","رسیدهای ثبت‌شده — چهار ارز":"ثبت شوي رسیدونه — څلور اسعار",
        "مشاهده / چاپ رسید انتخاب‌شده":"ټاکل شوی رسید کتل / چاپول","ویرایش رسید":"رسید سمول","حذف رسید":"رسید ړنګول","ذخیره ویرایش":"سمون ساتل",
        "تاریخ شمسی":"لمریز نېټه","تاریخ میلادی":"میلادي نېټه","شماره رسید":"د رسید شمېره","شماره حساب":"د حساب شمېره","نوع رسید":"د رسید ډول",
        "نرخ به AFN":"د افغانیو نرخ","معادل AFN":"په افغانیو کې معادل","مبلغ باید بیشتر از صفر باشد":"مبلغ باید له صفر څخه زیات وي",
        "مشتری را انتخاب کنید":"پېرودونکی وټاکئ","مبلغ و نرخ باید عددی باشند":"مبلغ او نرخ باید عددي وي",
        "نرم افزار حسابداری جهان":"د جهان محاسبوي سافټویر","سیستم حسابداری حرفه‌ای":"مسلکي محاسبوي سیستم","منوی اصلی":"اصلي مینو",
        "مدیریت مشتریان":"د پېرودونکو مدیریت","برای دیدن حساب کامل مشتری، فقط یک‌بار روی نام او کلیک کنید.":"د پېرودونکي بشپړ حساب لپاره پر نوم یې دوه ځله کلیک وکړئ.",
        "توضیحات":"یادښتونه","شماره تماس":"د اړیکې شمېره","آدرس":"پته","جستجو":"لټون","همه ارزها":"ټول اسعار",
        "در حال حاضر مشتری قرضدار ثبت نشده است.":"اوس مهال کوم پوروړی پېرودونکی نشته.","بدون قرض":"پرته له پور","پایش فعال":"څارنه فعاله ده",
        "موفق":"بریالی","خطا":"تېروتنه","هشدار":"خبرداری","بازگشت":"بېرته","افزودن":"زیاتول","نمایش":"ښودل","چاپ":"چاپول",
        "تغییر زبان":"د ژبې بدلون","زبان":"ژبه","پشتیبانی و تماس":"ملاتړ او اړیکه",
        "شماره":"شمېره","نام":"نوم","تخلص":"تخلص","شماره تماس":"د اړیکې شمېره","آدرس":"پته",
        "دریافت":"ترلاسه کول","پرداخت":"ورکول","خرید":"پېرود","فروش":"پلور","جمع":"ټول",
        "مانده":"پاتې شونی","قیمت":"بیه","قیمت فروش":"د پلور بیه","قیمت خرید":"د پېرود بیه",
        "فروشنده":"پلورونکی","خریدار":"پېرودونکی","کالا":"توکی","کالاها":"توکي","واحد":"واحد",
        "فاکتور":"رسید/فاکتور","فاکتورها":"رسیدونه/فاکتورونه","روزانه":"ورځنی","ماهانه":"میاشتنی","سالانه":"کلنی",
        "کشور":"هیواد","ولایت":"ولایت","استان":"ولایت","فرستنده":"لېږونکی","گیرنده":"ترلاسه کوونکی",
        "وضعیت":"حالت","کمیشن":"کمېشن","یادداشت":"یادښت","کاربر":"کارن","رمز عبور":"پټنوم",
        "حساب کاربری":"د کارن حساب","فعال":"فعال","غیرفعال":"غیرفعال","بازار":"بازار","لیست":"لړلیک",
        "تعداد":"شمېر","مجموع":"ټول","نتیجه":"پایله","جزئیات":"جزیات","انتخاب":"انتخاب",
        "ذخیره اطلاعات":"معلومات ساتل","ثبت اطلاعات":"معلومات ثبتول","تأیید":"تایید","لغو":"لغوه",
        "بله":"هو","خیر":"نه",
        "رمز عبور جدید":"نوی پټنوم","تکرار رمز عبور جدید":"د نوي پټنوم تکرار","ریست رمز عبور / ساخت کاربر":"د پټنوم بیا ټاکل / د کارن جوړول",
        "ریست رمز عبور یا ساخت کاربر جدید":"د پټنوم بیا ټاکل یا د نوي کارن جوړول","فراموشی / ریست رمز عبور":"پټنوم هېر شوی / بیا ټاکل",
        "ذخیره / ساخت کاربر":"ساتل / کارن جوړول","کاربر جدید با موفقیت ساخته شد.":"نوی کارن په بریالیتوب جوړ شو.",
        "رمز عبور کاربر با موفقیت تغییر کرد.":"د کارن پټنوم په بریالیتوب بدل شو.","حساب کاربری":"د کارن حساب","حساب کاربری و رمز عبور":"د کارن حساب او پټنوم",
        "برای امنیت، رمز عبور در دیتابیس به‌صورت هش ذخیره می‌شود.":"د امنیت لپاره پټنوم په ډیټابېس کې د هش په بڼه ساتل کېږي.",
        "ورود به برنامه":"پروګرام ته ننوتل","ورود ناموفق":"ناکامه ننوتل","نام کاربری یا رمز عبور اشتباه است.":"د کارن نوم یا پټنوم ناسم دی.",
        "حساب کاربری":"د کارن حساب","حساب":"حساب","زبان":"ژبه","تغییر زبان":"د ژبې بدلون","نسخه ۱۷.۰  •  سیستم حسابداری جهان":"نسخه ۱۷.۰  •  مسلکي محاسبوي سیستم",
        "منوی اصلی":"اصلي مینو","پشتیبانی و تماس":"ملاتړ او اړیکه","پشتیبانی":"ملاتړ","نرم افزار حسابداری جهان":"د جهان محاسبوي سافټویر",
        "ذخیره اطلاعات":"معلومات ساتل","ثبت اطلاعات":"معلومات ثبتول","لغو":"لغوه","تأیید":"تایید","بله":"هو","خیر":"نه"
    },
    "en": {
        "داشبورد":"Dashboard","مشتری":"Customer","مشتریان":"Customers","معاملات":"Transactions",
        "معامله":"Transaction","حساب":"Account","حساب‌ها":"Accounts","حسابهای":"Accounts",
        "رسید":"Receipt","رسیدها":"Receipts","رسیدهای":"Receipts","ثبت":"Save","ذخیره":"Save",
        "حذف":"Delete","ویرایش":"Edit","ویرایش / حذف":"Edit / Delete","مشاهده":"View",
        "چاپ":"Print","بازگشت":"Back","گزارش":"Report","گزارشات":"Reports","تنظیمات":"Settings",
        "زبان":"Language","پشتیبانی":"Support","جستجو":"Search","نمایش":"Show","افزودن":"Add",
        "توضیحات":"Description","مبلغ":"Amount","ارز":"Currency","نرخ":"Rate","تاریخ":"Date",
        "زمان":"Time","نوع":"Type","مشتری / دکان":"Customer / Shop","دریافت از مشتری":"Received from customer",
        "پرداخت به مشتری":"Paid to customer","قرضداری مشتری":"Customer debt","بستانکاری مشتری":"Customer credit",
        "معادل AFN":"AFN equivalent","کل خرید":"Total purchases","کل فروش":"Total sales","نتیجه معاملات":"Trading result",
        "موفق":"Success","خطا":"Error","هشدار":"Warning","همه":"All","جدید":"New","بازکردن":"Open",
        "ارسال":"Send","واتساپ":"WhatsApp","تلگرام":"Telegram","پشتیبان":"Backup","درباره":"About",
        "فروشگاه":"Shops","مغازه":"Shop","نرخ AFN":"AFN rate","معادل":"Equivalent",
        "شماره رسید":"Receipt No.","شماره حساب":"Account No.","نوع رسید":"Receipt type",
        "با تشکر از اعتماد شما":"Thank you for your trust",
        "تعداد مشتریان":"Customers","تعداد معاملات":"Transactions","دکان‌ها و میوه‌فروشی‌ها":"Shops & Produce",
        "مانده حساب":"Account Balance","مانده خالص":"Net Balance","آخرین معاملات":"Recent Transactions","نمودار خرید و فروش ماهانه":"Monthly Purchase & Sales",
        "مجموع خرید":"Total Purchases","مجموع فروش":"Total Sales","قرضداری":"Debt","بستانکاری":"Credit","هر ارز جداگانه":"Each Currency Separately",
        "قرضداری، بستانکاری و گردش مشتریان":"Customer debt, credit & activity","مانده خالص = قرضداری − بستانکاری":"Net balance = debt − credit",
        "رسید مشتری":"Customer Receipt","مرکز رسید مشتری":"Customer Receipt Center","آخرین رسیدهای مشتری":"Latest Customer Receipts",
        "ثبت رسید مشتری":"Register Customer Receipt","ویرایش رسید مشتری":"Edit Customer Receipt","رسیدهای ثبت‌شده — چهار ارز":"Saved Receipts — Four Currencies",
        "مشاهده / چاپ رسید انتخاب‌شده":"View / Print Selected Receipt","ویرایش رسید":"Edit Receipt","حذف رسید":"Delete Receipt","ذخیره ویرایش":"Save Edit",
        "تاریخ شمسی":"Jalali Date","تاریخ میلادی":"Gregorian Date","شماره رسید":"Receipt No.","شماره حساب":"Account No.","نوع رسید":"Receipt Type",
        "نرخ به AFN":"Rate to AFN","معادل AFN":"AFN Equivalent","مبلغ باید بیشتر از صفر باشد":"Amount must be greater than zero",
        "مشتری را انتخاب کنید":"Select a customer","مبلغ و نرخ باید عددی باشند":"Amount and rate must be numeric",
        "نرم افزار حسابداری جهان":"Jahan Accounting Software","سیستم حسابداری حرفه‌ای":"Professional Accounting System","منوی اصلی":"Main Menu",
        "مدیریت مشتریان":"Customer Management","برای دیدن حساب کامل مشتری، فقط یک‌بار روی نام او کلیک کنید.":"Double-click a customer name to view the full account.",
        "توضیحات":"Description","شماره تماس":"Phone","آدرس":"Address","جستجو":"Search","همه ارزها":"All Currencies",
        "در حال حاضر مشتری قرضدار ثبت نشده است.":"There are currently no customers with debt.","بدون قرض":"No Debt","پایش فعال":"Monitoring Active",
        "موفق":"Success","خطا":"Error","هشدار":"Warning","بازگشت":"Back","افزودن":"Add","نمایش":"Show","چاپ":"Print",
        "تغییر زبان":"Change Language","زبان":"Language","پشتیبانی و تماس":"Support & Contact",
        "شماره":"Number","نام":"Name","تخلص":"Surname","شماره تماس":"Phone","آدرس":"Address",
        "دریافت":"Receive","پرداخت":"Payment","خرید":"Purchase","فروش":"Sale","جمع":"Total",
        "مانده":"Balance","قیمت":"Price","قیمت فروش":"Sale Price","قیمت خرید":"Purchase Price",
        "فروشنده":"Seller","خریدار":"Buyer","کالا":"Item","کالاها":"Items","واحد":"Unit",
        "فاکتور":"Invoice","فاکتورها":"Invoices","روزانه":"Daily","ماهانه":"Monthly","سالانه":"Yearly",
        "کشور":"Country","ولایت":"Province","استان":"Province","فرستنده":"Sender","گیرنده":"Receiver",
        "وضعیت":"Status","کمیشن":"Commission","یادداشت":"Note","کاربر":"User","رمز عبور":"Password",
        "حساب کاربری":"User Account","فعال":"Active","غیرفعال":"Inactive","بازار":"Market","لیست":"List",
        "تعداد":"Count","مجموع":"Total","نتیجه":"Result","جزئیات":"Details","انتخاب":"Select",
        "ذخیره اطلاعات":"Save Information","ثبت اطلاعات":"Register Information","تأیید":"Confirm","لغو":"Cancel",
        "بله":"Yes","خیر":"No",
        "رمز عبور جدید":"New Password","تکرار رمز عبور جدید":"Confirm New Password","ریست رمز عبور / ساخت کاربر":"Reset Password / Create User",
        "ریست رمز عبور یا ساخت کاربر جدید":"Reset Password or Create New User","فراموشی / ریست رمز عبور":"Forgot / Reset Password",
        "ذخیره / ساخت کاربر":"Save / Create User","کاربر جدید با موفقیت ساخته شد.":"New user created successfully.",
        "رمز عبور کاربر با موفقیت تغییر کرد.":"User password changed successfully.","حساب کاربری و رمز عبور":"User Account & Password",
        "برای امنیت، رمز عبور در دیتابیس به‌صورت هش ذخیره می‌شود.":"For security, the password is stored as a hash in the database.",
        "ورود به برنامه":"Sign In","ورود ناموفق":"Sign-in Failed","نام کاربری یا رمز عبور اشتباه است.":"Incorrect username or password.",
        "حساب کاربری":"User Account","زبان":"Language","تغییر زبان":"Change Language","نسخه ۱۷.۰  •  سیستم حسابداری جهان":"Version 17.0  •  Jahan Accounting",
        "منوی اصلی":"Main Menu","پشتیبانی و تماس":"Support & Contact","پشتیبانی":"Support","نرم افزار حسابداری جهان":"Jahan Accounting Software",
        "ذخیره اطلاعات":"Save Information","ثبت اطلاعات":"Register Information","لغو":"Cancel","تأیید":"Confirm","بله":"Yes","خیر":"No"
    }
}
# Keep the desktop UI typographic and product-like: remove colored emoji glyphs from
# visible labels while preserving ordinary punctuation, accounting symbols and text.
def _clean_ui_glyphs(text):
    s = str(text or "")
    out = []
    for ch in s:
        cp = ord(ch)
        # Emoji/pictograph blocks commonly rendered as colorful glyphs on Windows.
        if (0x1F000 <= cp <= 0x1FAFF) or (0x2600 <= cp <= 0x27BF and cp not in (0x2713, 0x2714, 0x2715, 0x2794)):
            continue
        out.append(ch)
    return "".join(out).replace("  ", " ").strip()

def _display_text(text):
    """Return a stable UI translation without chaining/re-translating text.

    Widgets keep their original Persian source text in _jahan_original_text.
    Older code tried to reverse every known translation before translating it
    again; that caused English/Pashto words to leak into Persian and vice versa.
    Translation is therefore exact-first, with a conservative token fallback
    only for strings that contain a known Persian UI phrase.
    """
    s = str(text or "")
    if not s:
        return s
    if CURRENT_UI_LANGUAGE == "fa":
        return s
    words = _UI_WORDS.get(CURRENT_UI_LANGUAGE, {})
    if s in words:
        return words[s]
    # IMPORTANT: never translate by substring. A Persian word such as «حساب»
    # inside «حسابداری» must not be replaced independently; doing so was the
    # main cause of mixed Persian/Pashto/English labels. Composite UI strings
    # must have their own exact translation entry. Unknown text is preserved.
    return words.get(s, s)

# Compatibility helper: never reshape/reverse Persian text before Tkinter renders it.
# Tk/Windows handles Unicode shaping and bidirectional text; manual shaping breaks
# mixed Persian + Latin + numbers and was the source of the corrupted UI.
def _icu_shape_arabic(text):
    return _display_text(text)

def _bidi_safe_numbers(text):
    """Keep numbers strictly LTR and normalize AI key/value lines.

    In the Smart Assistant, mixed Persian + numbers can otherwise make the
    numeric run appear reversed or jump to the RTL side.  Use LTR embedding
    around every number, and when a Persian/Latin label is immediately followed
    by a numeric value, use a clean accounting-style `` = `` separator instead
    of a colon or other bidi-sensitive punctuation.
    """
    s = str(text or "")
    if not s:
        return s
    # The assistant commonly returns lines such as «فروش: 500.000» or
    # «موجودی - 50.000». Make these consistently «فروش = 500.000».
    s = re.sub(r"(?P<label>[^\n:=|]{1,80}?)\s*(?:[:：]|\s[-–—]\s)\s*(?=[0-9۰-۹])",
               lambda m: m.group("label").rstrip() + " = ", s)
    number_pattern = re.compile(r"[0-9۰-۹]+(?:[.,،٬٫][0-9۰-۹]+)*")
    # LRE/PDF is deliberately used rather than RTL markers: it makes the
    # digits themselves render left-to-right while keeping the surrounding
    # Persian paragraph intact.
    return number_pattern.sub(lambda m: "\u202A" + m.group(0) + "\u202C", s)

class RTLLabel(tk.Label):
    def __init__(self, master=None, **kw):
        original = str(kw.get("text", "")) if "text" in kw else ""
        if "text" in kw:
            kw["text"] = _clean_ui_glyphs(_display_text(original))
        kw.setdefault("anchor", "center")
        kw.setdefault("justify", "center")
        super().__init__(master, **kw)
        self._jahan_original_text = original

class RTLButton(tk.Button):
    def __init__(self, master=None, **kw):
        original = str(kw.get("text", "")) if "text" in kw else ""
        if "text" in kw:
            kw["text"] = _clean_ui_glyphs(_display_text(original))
        # Make every desktop button clearly bold and a little larger without
        # changing the surrounding layout. Existing button font sizes are
        # scaled here only for buttons; labels/entries keep their prior size.
        f = kw.get("font")
        if isinstance(f, (tuple, list)) and len(f) >= 2:
            try:
                family = f[0]
                size = int(round(float(f[1]) * 1.24))
                kw["font"] = (family, max(11, size), "bold")
            except Exception:
                kw["font"] = f
        else:
            kw.setdefault("font", (UI_FONT, 11, "bold"))
        kw.setdefault("anchor", "e")
        kw.setdefault("justify", "right")
        super().__init__(master, **kw)
        self._jahan_original_text = original
        # Luxurious default feel for every button in the app: a smooth
        # color transition on hover/press instead of an instant flat swap.
        # Any explicit <Enter>/<Leave> binding added later by the caller
        # simply supersedes this default, so nothing existing is broken.
        try:
            base_bg = kw.get("bg", kw.get("background", "#FFFFFF"))
            base_fg = kw.get("fg", kw.get("foreground", "#1B2733"))
            auto_hover = _lighten(base_bg, 0.16) if _is_dark_color(base_bg) else _darken(base_bg, 0.06)
            hover_bg = kw.get("activebackground") or auto_hover
            hover_fg = kw.get("activeforeground", base_fg)
            bind_smooth_hover(self, base_bg, hover_bg, base_fg, hover_fg)
        except Exception:
            pass

class LocalizedCombobox(ttk.Combobox):
    def __init__(self, master=None, **kw):
        if "values" in kw and isinstance(kw["values"], (list, tuple)):
            kw["values"] = tuple(_display_text(v) if str(v) in _UI_WORDS.get(CURRENT_UI_LANGUAGE,{}) else v for v in kw["values"])
        if "textvariable" in kw:
            # Keep variables in their stored/domain language; only list labels are localized.
            pass
        super().__init__(master, **kw)

# Slightly larger, readable UI typography without changing the layout.
def ui_font(size, weight="bold"):
    try:
        n = max(9, int(round(float(size) * 1.12)))
    except Exception:
        n = 11
    return (UI_FONT, n, weight)

# --- Luxury UI helpers: color math, live gradients and smooth hover/press
# animation. Pure Tkinter (tk.PhotoImage.put), no extra runtime dependency,
# so packaging with PyInstaller stays exactly as it was. ---
def _hex_to_rgb(h):
    h = str(h).lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return (0, 0, 0)

def _rgb_to_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(c)))) for c in rgb)

def _lerp_color(c1, c2, t):
    r1, g1, b1 = _hex_to_rgb(c1)
    r2, g2, b2 = _hex_to_rgb(c2)
    t = max(0.0, min(1.0, t))
    return _rgb_to_hex((r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t))

def _lighten(hexcolor, amount=0.15):
    return _lerp_color(hexcolor, "#ffffff", amount)

def _darken(hexcolor, amount=0.15):
    return _lerp_color(hexcolor, "#000000", amount)

def _is_dark_color(hexcolor):
    try:
        r, g, b = _hex_to_rgb(hexcolor)
    except Exception:
        return True
    return (0.299 * r + 0.587 * g + 0.114 * b) < 140

def _make_gradient_image(width, height, colors, horizontal=False):
    """Native tk.PhotoImage multi-stop gradient (no PIL required)."""
    width = max(1, int(width)); height = max(1, int(height))
    img = tk.PhotoImage(width=width, height=height)
    n = len(colors) - 1
    span = max(1, (width if horizontal else height))
    for i in range(span):
        t = i / max(1, span - 1)
        seg = min(int(t * n), max(n - 1, 0)) if n > 0 else 0
        local_t = (t * n - seg) if n > 0 else 0
        color = _lerp_color(colors[seg], colors[min(seg + 1, n)], local_t)
        if horizontal:
            img.put(color, to=(i, 0, i + 1, height))
        else:
            img.put(color, to=(0, i, width, i + 1))
    return img

def apply_gradient_background(frame, colors, horizontal=False, redraw_delay=40):
    """Paints a live, resize-aware gradient behind a Frame's existing
    pack()/grid()ed children via a place()+lower() Label, so nothing about
    the surrounding layout has to change."""
    bg_label = tk.Label(frame, bd=0, highlightthickness=0)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
    bg_label.lower()
    state = {"job": None}
    def _redraw():
        state["job"] = None
        if not frame.winfo_exists():
            return
        w, h = frame.winfo_width(), frame.winfo_height()
        if w < 2 or h < 2:
            return
        try:
            img = _make_gradient_image(w, h, colors, horizontal)
            bg_label._grad_img = img  # keep a live reference
            bg_label.configure(image=img)
        except Exception:
            pass
    def _on_configure(event=None):
        if state["job"] is not None:
            try: frame.after_cancel(state["job"])
            except Exception: pass
        state["job"] = frame.after(redraw_delay, _redraw)
    frame.bind("<Configure>", _on_configure, add="+")
    # Force Tk to compute the frame's real size right now instead of only
    # relying on a <Configure> event later - on some machines that event can
    # be slow to arrive, leaving the bar blank/mismatched for a moment.
    try:
        frame.update_idletasks()
    except Exception:
        pass
    _redraw()
    frame.after(10, _redraw)
    return bg_label

def animate_widget_colors(widget, pairs, steps=8, duration_ms=140):
    """pairs: list of (option_name, from_color, to_color)."""
    def step(i):
        if not widget.winfo_exists():
            return
        t = i / steps
        cfg = {opt: _lerp_color(c1, c2, t) for opt, c1, c2 in pairs}
        try:
            widget.configure(**cfg)
        except Exception:
            return
        if i < steps:
            widget.after(max(1, duration_ms // steps), lambda: step(i + 1))
    step(0)

def bind_smooth_hover(widget, base_bg, hover_bg, base_fg=None, hover_fg=None, press_bg=None):
    """Modern, luxurious hover/press feedback: a short smooth color
    transition instead of an instant flat color swap."""
    press_bg = press_bg or _darken(hover_bg, 0.14)
    def enter(e):
        pairs = [("bg", str(widget.cget("bg")), hover_bg)]
        if base_fg and hover_fg: pairs.append(("fg", base_fg, hover_fg))
        animate_widget_colors(widget, pairs)
    def leave(e):
        pairs = [("bg", str(widget.cget("bg")), base_bg)]
        if base_fg and hover_fg: pairs.append(("fg", hover_fg, base_fg))
        animate_widget_colors(widget, pairs)
    def press(e):
        try: widget.configure(bg=press_bg)
        except Exception: pass
    def release(e):
        try: widget.configure(bg=hover_bg)
        except Exception: pass
    widget.bind("<Enter>", enter, add="+")
    widget.bind("<Leave>", leave, add="+")
    widget.bind("<ButtonPress-1>", press, add="+")
    widget.bind("<ButtonRelease-1>", release, add="+")

class _LuxuryToplevel(tk.Toplevel):
    """Every dialog window in the app is automatically brought in line with
    the current luxury dark/gold theme once the main shell is ready -
    without having to hand-edit each of the many dialog-building
    functions individually. Only the new dialog itself is recolored, so
    opening it never repaints (or flickers) the rest of the app."""
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        app = master
        try:
            hops = 0
            while app is not None and not hasattr(app, "_retheme_subtree") and hops < 6:
                app = getattr(app, "master", None); hops += 1
            if app is not None and getattr(app, "_shell_ready", False):
                self.after(60, lambda: app._retheme_subtree(self))
        except Exception:
            pass

tk.Toplevel = _LuxuryToplevel

def fmt_num(value, decimals=2):
    """Format monetary numbers with a dot as the thousands separator."""
    try:
        x=float(value or 0)
        s=f"{x:,.{decimals}f}"
        s=s.replace(",","§").replace(".",",").replace("§",".")
        return s.rstrip("0").rstrip(",")
    except (TypeError, ValueError):
        return str(value)

def fmt_fx_rate(value):
    """Display FX rates with enough precision that tiny rates do not appear as 0."""
    try:
        x=float(value or 0)
        if x == 0:
            return "—"
        if abs(x) < 0.01:
            s=f"{x:,.8f}"
            s=s.replace(",","§").replace(".",",").replace("§",".")
            return s.rstrip("0").rstrip(",")
        return fmt_num(x, 4)
    except (TypeError, ValueError):
        return str(value)

# In a one-file EXE, bundled resources are read-only. On first run copy the
# starter database into LocalAppData; on an upgrade, migrate an older database
# that may still be beside the EXE. Never overwrite an existing customer DB.
if getattr(sys, "frozen", False) and not os.path.exists(DB):
    legacy_db = os.path.join(BASE, "jahan_accounting.db")
    bundled_db = os.path.join(RESOURCE_BASE, "jahan_accounting.db")
    source_db = legacy_db if os.path.exists(legacy_db) else bundled_db
    if os.path.exists(source_db):
        try:
            os.makedirs(os.path.dirname(DB), exist_ok=True)
            shutil.copy2(source_db, DB)
        except OSError:
            pass
CURRENCIES = ["AFN - افغانی", "IRR - تومان", "USD - دلار آمریکا", "EUR - یورو", "PKR - کلدار"]

# Accounting arithmetic: use Decimal for exact monetary aggregation.
getcontext().prec = 40

def D(value):
    """Parse user-entered numbers, including Persian digits and 50.000-style grouping."""
    try:
        text=str(value or "").strip()
        trans=str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
        text=text.translate(trans).replace("٬", ",").replace("٫", ".").replace(" ", "")
        # Accept both 50,000 and the app's displayed 50.000.
        if "," in text and "." in text:
            # Last separator is treated as the decimal mark.
            if text.rfind(",") > text.rfind("."):
                text=text.replace(".", "").replace(",", ".")
            else:
                text=text.replace(",", "")
        elif "," in text:
            parts=text.split(",")
            if len(parts[-1]) == 3 and all(part.isdigit() for part in parts):
                text="".join(parts)
            else:
                text=".".join(parts)
        elif "." in text:
            parts=text.split(".")
            if len(parts) > 1 and len(parts[-1]) == 3 and all(part.isdigit() for part in parts):
                text="".join(parts)
        return Decimal(text or "0")
    except Exception:
        return Decimal("0")

def parse_user_number(value):
    """Parse all app-entered monetary/quantity values consistently.
    Accepts 50000000, 50.000.000, 50,000,000 and Persian/Arabic digits.
    The app uses dot as the thousands separator in its displayed numbers.
    """
    return float(D(value))

def fmt_money_exact(value):
    # Preserve meaningful decimals (up to 6 places) in conversion results.
    d=D(value).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
    s=f"{d:,.6f}".replace(",","§").replace(".",",").replace("§",".")
    return s.rstrip("0").rstrip(",")

CURRENCY_CODES = {"USD - دلار آمریکا":"USD", "AFN - افغانی":"AFN", "IRR - تومان":"IRR", "EUR - یورو":"EUR", "PKR - کلدار":"PKR"}
CURRENCY_NAMES = {v:k for k,v in CURRENCY_CODES.items()}
PROVINCES = [
    "کابل","بلخ","هرات","بادغیس","بغلان","فراه","فاریاب","غزنی","غور","کندهار",
    "کنر","لغمان","میدان وردک","ننگرهار","زابل","پروان","لوگر","بدخشان","بامیان","دایکندی",
    "جوزجان","هلمند","کاپیسا","خوست","کندز","نیمروز","نورستان","ارزگان","پکتیا","پکتیکا",
    "پنجشیر","سمنگان","سرپل","تخار"
]
IRAN_PROVINCES = [
    "آذربایجان شرقی","آذربایجان غربی","اردبیل","اصفهان","البرز","ایلام","بوشهر","تهران",
    "چهارمحال و بختیاری","خراسان جنوبی","خراسان رضوی","خراسان شمالی","خوزستان","زنجان",
    "سمنان","سیستان و بلوچستان","فارس","قزوین","قم","کردستان","کرمان","کرمانشاه",
    "کهگیلویه و بویراحمد","گلستان","گیلان","لرستان","مازندران","مرکزی","هرمزگان","همدان","یزد"
]

# --- Complete, plain-Persian in-app guide. Each entry is (title, body). Kept
# as data (not scattered inline strings) so the whole guide is easy to find,
# read and extend in one place. Written to match the app's real menus and
# buttons, not generic advice.
HELP_TOPICS = [
    ("🚀 شروع سریع با برنامه",
     "به نرم‌افزار حسابداری جهان خوش آمدید.\n\n"
     "• سمت راست صفحه، منوی اصلی برنامه است: داشبورد، مشتریان، معاملات، حساب‌ها، "
     "رسیدها، حواله، گزارش‌ها، فاکتور، دکان‌ها، ارز و وب، دستیار حسابداری، پشتیبان‌گیری، "
     "همگام‌سازی، تنظیمات، درباره و همین راهنما.\n"
     "• نوار بالای صفحه: بزرگ‌نمایی با دکمه‌های − و +، کنار آن درصد فعلی (۱۰۰٪)، "
     "دکمه‌ی حالت دارک/روشن، و دکمه‌های بستن/بزرگ‌کردن/کوچک‌کردن پنجره.\n"
     "• هر جای برنامه که گیر کردید، کافی است روی «📖 راهنما» در منو یا علامت ❓ "
     "بالای صفحه بزنید تا همین صفحه باز شود.\n"
     "• یک قانون ساده در همه‌ی برنامه: روی هر ردیف از هر جدول دوبار کلیک کنید تا "
     "جزئیات کامل آن باز شود (مثلاً دوبار کلیک روی مشتری = باز شدن حساب کامل او)."),

    ("📊 داشبورد",
     "داشبورد اولین صفحه‌ای است که بعد از ورود می‌بینید و خلاصه‌ی کل کسب‌وکار را نشان می‌دهد.\n\n"
     "• کارت‌های بالا: تعداد مشتریان، تعداد معاملات، تعداد دکان‌ها، و نتیجه‌ی کلی "
     "معاملات (به تفکیک هر ارز).\n"
     "• «مانده حساب» هر ارز به‌صورت جداگانه نشان داده می‌شود، نه همه با هم قاطی.\n"
     "• باکس «🔝 بیشترین بدهکاران»: پرداخت‌نشده‌ترین مشتری‌ها را نشان می‌دهد؛ روی هرکدام "
     "کلیک کنید تا حساب کاملش باز شود.\n"
     "• باکس «📦 کالاهای رو به اتمام»: وقتی موجودی کالایی در یک دکان کم شود، همین‌جا "
     "هشدار می‌دهد.\n"
     "• جدول «قرضداری، بستانکاری و گردش مشتریان»: خلاصه‌ی هر ارز به‌صورت جداگانه، بدون تبدیل ارزها به یکدیگر.\n"
     "• نمودار پایین صفحه: مقایسه‌ی خرید و فروش در ۶ ماه اخیر.\n"
     "• جدول «آخرین معاملات»: ۱۰ معامله‌ی آخر را نشان می‌دهد."),

    ("👤 مشتریان",
     "این بخش لیست کامل مشتریان شماست.\n\n"
     "• «＋ مشتری جدید» برای افزودن مشتری تازه.\n"
     "• کادر جستجو برای پیدا کردن سریع با نام یا شماره تماس.\n"
     "• «🗑 حذف مشتری» برای حذف مشتری انتخاب‌شده (این کار قابل بازگشت نیست).\n"
     "• «📊 خروجی Excel» یک فایل CSV از کل لیست می‌سازد که در Excel باز می‌شود.\n"
     "• ستون «ارز» نشان می‌دهد حساب هر مشتری با چه ارزی محاسبه شده است.\n"
     "• دوبار کلیک روی هر مشتری، حساب کامل او را باز می‌کند."),

    ("📒 حساب مشتریان",
     "این صفحه برای دیدن و ثبت قرض/بستانکاری هر مشتری است.\n\n"
     "• از لیست کشویی، مشتری مورد نظر را انتخاب و «📒 باز کردن حساب» را بزنید.\n"
     "• «＋ ثبت قرض/بستانکاری» برای ثبت سریع یک تراکنش حساب.\n"
     "• دکمه‌های «📱 واتساپ» و «✈ تلگرام» خلاصه‌ی حساب مشتری را مستقیم برایش می‌فرستند.\n"
     "• «📊 خروجی Excel» از همین لیست هم در دسترس است.\n"
     "• توی صفحه‌ی حساب هر مشتری: اگر مشتری فقط با یک ارز کار کند، اعداد دقیقاً با همان "
     "ارز نشان داده می‌شود؛ اگر با چند ارز کار کند، پایین صفحه جدول تفکیک هر ارز را می‌بینید.\n"
     "• دکمه‌های «＋ ثبت قرضداری» و «＋ ثبت بستانکاری» برای ثبت مستقیم از همان صفحه."),

    ("↔ معاملات (خرید و فروش ارز)",
     "ثبت خرید و فروش ارز در این بخش انجام می‌شود.\n\n"
     "• هنگام ثبت هر معامله، نوع (خرید/فروش)، ارز، مبلغ و نرخ را وارد کنید.\n"
     "• نرخ‌ها را می‌توانید از بخش «ارز و وب» به‌صورت آنلاین به‌روزرسانی کنید یا دستی وارد کنید.\n"
     "• هر معامله در گزارش‌ها، داشبورد و نمودار خرید/فروش هم منعکس می‌شود."),

    ("▤ رسیدها",
     "مرکز صدور و مدیریت رسیدهای رسمی مشتریان است.\n\n"
     "• هر رسید یک شماره‌ی پیگیری و تاریخ شمسی/میلادی مستقل دارد.\n"
     "• رسیدها را می‌توانید چاپ یا به‌صورت PDF ذخیره کنید.\n"
     "• خروجی CSV روزانه از رسیدها هم در همین بخش موجود است."),

    ("↗ حواله",
     "ثبت و پیگیری حواله‌های ارسالی و دریافتی مشتریان در این بخش انجام می‌شود."),

    ("▥ گزارش‌ها",
     "گزارش‌های مالی روزانه، ماهانه و سالانه را اینجا می‌بینید.\n\n"
     "• هر گزارش شامل خرید، فروش، قرضداری، بستانکاری و نتیجه‌ی معاملات است.\n"
     "• برای هر گزارش، دکمه‌ی «خروجی CSV» برای گرفتن فایل Excel وجود دارد."),

    ("◈ فاکتور",
     "برای صدور فاکتور فروش (مثلاً فروش میوه یا کالای دکان) از این بخش استفاده کنید.\n"
     "فاکتور صادرشده قابل چاپ و ذخیره به‌صورت PDF است."),

    ("🏪 دکان‌ها و انبار",
     "مرکز مدیریت همه‌ی دکان‌ها و انبارهای شماست؛ برای ساده ماندن، فقط ۳ دکمه‌ی اصلی جلوی چشم است:\n\n"
     "• «＋ دکان جدید»: ثبت یک دکان تازه.\n"
     "• «↔ خرید یا فروش کالا»: ثبت خرید/فروش کالا برای یک دکان.\n"
     "• «🧾 فروش فاکتوری»: صدور فاکتور فروش.\n\n"
     "کارهای کم‌کاربردتر زیر دو منوی کوچک جمع شده‌اند:\n"
     "• «📚 کاتالوگ کالا ▾»: کاتالوگ داروخانه، میوه‌وسبزی، کفش‌فروشی.\n"
     "• «⋯ ابزار بیشتر ▾»: ورود موجودی، همه‌ی فاکتورها، فاکتورهای دکان انتخاب‌شده، "
     "گزارش دکان انتخاب‌شده، و خروجی Excel.\n\n"
     "دوبار کلیک روی هر دکان در جدول، دفتر کامل همان دکان (موجودی، فروش، خرید، مانده) را باز می‌کند."),

    ("◎ ارز و وب",
     "نرخ آنلاین ارزها (دلار، تومان، کلدار و ...) از همین بخش به‌روزرسانی می‌شود. "
     "این نرخ‌ها به‌صورت خودکار هر چند ساعت هم تازه می‌شوند و در معاملات و حساب‌ها استفاده می‌شوند."),

    ("دستیار حسابداری",
     "دستیار هوشمند داخل برنامه است که می‌توانید سؤال بپرسید و در کارهای روزمره کمک بگیرید."),

    ("▰ پشتیبان‌گیری",
     "همه‌ی اطلاعات شما در یک فایل نگه‌داری می‌شود؛ این بخش راه‌های محافظت از آن است.\n\n"
     "• «💾 Backup دستی»: ذخیره‌ی یک نسخه‌ی رمزگذاری‌شده با رمز دلخواه شما.\n"
     "• «📦 Backup کل نرم‌افزار»: نسخه‌ی کامل برنامه و فایل‌هایش.\n"
     "• «🔄 Restore»: بازگردانی اطلاعات از یک فایل بکاپ.\n"
     "• «📂 Open فایل اطلاعات»: جایگزین کردن فایل اطلاعات فعلی با فایل دیگر.\n"
     "• یک بکاپ خودکار رمزگذاری‌شده هم هر ۱ دقیقه به‌صورت پیش‌فرض ساخته می‌شود."),

    ("🔄 همگام‌سازی Android",
     "از این بخش می‌توانید اطلاعات را با اپلیکیشن اندروید همگام (Sync) کنید."),

    ("⚙ تنظیمات",
     "تنظیمات عمومی برنامه مثل زبان نمایش و کمیشن ایران/افغانستان از همین بخش قابل تغییر است."),

    ("💡 نکات کاربردی",
     "چند نکته‌ی کوچک که استفاده از برنامه را راحت‌تر می‌کند:\n\n"
     "• حالت دارک/روشن: از دکمه‌ی بالای صفحه (کنار بزرگ‌نمایی) قابل تغییر است.\n"
     "• بزرگ‌نمایی صفحه: با دکمه‌های − و + یا Ctrl و علامت مثبت/منفی صفحه‌کلید.\n"
     "• تقریباً هر لیست در برنامه یک کادر جستجوی بالای جدول دارد؛ همان را برای پیدا "
     "کردن سریع استفاده کنید.\n"
     "• دوبار کلیک روی هر ردیف = باز شدن جزئیات کامل آن (مشتری، دکان، رسید و ...).\n"
     "• قبل از هر تغییر بزرگ (مثل Restore)، حتماً یک Backup دستی تازه بگیرید."),
]

class App(tk.Tk):
    # Modern formal accounting palette: graphite, ivory, slate and restrained gold accents.
    PALETTE = {"bg":"#F4F6F8", "panel":"#FFFFFF", "sidebar":"#E9EDF1", "ink":"#1B2733", "muted":"#687582", "line":"#D8DEE4", "accent":"#C9A45C", "accent_dark":"#B58E45", "header":"#1B2733"}

    def __init__(self):
        super().__init__()
        global UI_FONT
        UI_FONT = _select_persian_font()
        self.title(APP_NAME)
        self.geometry("1240x760")
        self.minsize(980, 620)
        self.configure(bg="#F4F6F8")
        # Decorative chrome (title bar, header, sidebar) that paints its own
        # gradient and must never be flattened by the theme-recolor walker.
        self._no_retheme = set()
        # Flips to True once build_ui() has finished; gates the automatic
        # dark/gold re-theming of dialogs opened during normal use, so the
        # pre-login/activation screens keep their own deliberate look.
        self._shell_ready = False
        self.current_language = "fa"
        global CURRENT_UI_LANGUAGE
        CURRENT_UI_LANGUAGE = self.current_language
        self.dark_mode = True
        # UI zoom controls removed; Windows/app layout uses native sizing.
        self.zoom_percent = 100
        self.language_names = {"fa":"فارسی", "ps":"پښتو", "en":"English"}
        self.language_codes = {"فارسی":"fa", "پښتو":"ps", "English":"en"}
        # Keep the main root hidden during activation/login.
        # Do NOT enable the custom borderless title bar yet: on Windows a
        # withdrawn + overrideredirect root can steal the Z-order from auth
        # dialogs and make the application appear to have closed.
        self.withdraw()
        self._auth_phase = True
        self._normal_geometry = "1180x680+40+30"
        self._drag_x = 0
        self._drag_y = 0
        self.db = sqlite3.connect(DB)
        self.db.execute("""CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            phone TEXT, address TEXT, balance REAL DEFAULT 0, notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, kind TEXT,
            currency TEXT, amount REAL, rate REAL, afn_amount REAL,
            customer TEXT, notes TEXT)""")
        tx_cols=[r[1] for r in self.db.execute("PRAGMA table_info(transactions)").fetchall()]
        for col,definition in [("customer_id","INTEGER"),("source_type","TEXT DEFAULT 'manual'"),("source_id","INTEGER")]:
            if col not in tx_cols:
                self.db.execute(f"ALTER TABLE transactions ADD COLUMN {col} {definition}")
        self.db.execute("""CREATE TABLE IF NOT EXISTS account_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            receipt_no INTEGER DEFAULT 0,
            customer_id INTEGER,
            customer TEXT NOT NULL,
            entry_type TEXT NOT NULL,
            amount REAL NOT NULL,
            notes TEXT,
            currency TEXT DEFAULT 'AFN - افغانی',
            rate REAL DEFAULT 1,
            afn_amount REAL DEFAULT 0,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        ae_cols=[r[1] for r in self.db.execute("PRAGMA table_info(account_entries)").fetchall()]
        for col,definition in [("currency","TEXT DEFAULT 'AFN - افغانی'"),("rate","REAL DEFAULT 1"),("afn_amount","REAL DEFAULT 0"),("account_no","INTEGER DEFAULT 0"),("source_type","TEXT DEFAULT 'manual'"),("source_id","INTEGER")]:
            if col not in ae_cols:
                self.db.execute(f"ALTER TABLE account_entries ADD COLUMN {col} {definition}")
        self.db.execute("UPDATE account_entries SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE account_entries SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE account_entries SET afn_amount=amount*rate WHERE afn_amount IS NULL OR afn_amount=0")
        # Receipts are multi-currency too. IMPORTANT: create/migrate the receipts
        # table BEFORE touching any of its columns. Older databases did not have
        # receipt_no, so the previous startup migration could crash here.
        self.db.execute("""CREATE TABLE IF NOT EXISTS receipts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            customer_id INTEGER,
            customer TEXT NOT NULL,
            receipt_type TEXT NOT NULL,
            amount REAL NOT NULL,
            description TEXT,
            edit_count INTEGER DEFAULT 0,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        receipt_cols=[r[1] for r in self.db.execute("PRAGMA table_info(receipts)").fetchall()]
        for col,definition in [("receipt_no","INTEGER DEFAULT 0"),("currency","TEXT DEFAULT 'AFN - افغانی'"),("rate","REAL DEFAULT 1"),("afn_amount","REAL DEFAULT 0"),("edit_count","INTEGER DEFAULT 0"),("commission_base","REAL DEFAULT 1000000"),("commission_rate","REAL DEFAULT 0"),("commission","REAL DEFAULT 0"),("commission_afn","REAL DEFAULT 0"),("commission_currency","TEXT DEFAULT 'AFN - افغانی'"),("route","TEXT DEFAULT ''")]:
            if col not in receipt_cols: self.db.execute(f"ALTER TABLE receipts ADD COLUMN {col} {definition}")
        self.db.execute("UPDATE receipts SET commission_base=1000000 WHERE commission_base IS NULL OR commission_base<=0")
        self.db.execute("UPDATE receipts SET commission=0 WHERE commission IS NULL")
        self.db.execute("UPDATE receipts SET commission_afn=COALESCE(commission,0)*COALESCE(rate,1) WHERE commission_afn IS NULL")
        self.db.execute("UPDATE receipts SET receipt_no=id WHERE receipt_no IS NULL OR receipt_no=0")
        self.db.execute("UPDATE receipts SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE receipts SET commission_currency=COALESCE(NULLIF(commission_currency,''),currency,'AFN - افغانی')")
        self.db.execute("UPDATE receipts SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE receipts SET afn_amount=amount*rate WHERE afn_amount IS NULL OR afn_amount=0")
        # Repair old receipt/customer links. Some older databases stored the
        # customer name but left customer_id empty; those receipts must still
        # participate in the customer's balance calculation.
        self.db.execute("""UPDATE receipts
                           SET customer_id=(SELECT c.id FROM customers c WHERE c.name=receipts.customer LIMIT 1)
                           WHERE (customer_id IS NULL OR customer_id=0)
                             AND customer IS NOT NULL AND TRIM(customer)<>''""")
        self.db.execute("""UPDATE account_entries
                           SET customer_id=(SELECT c.id FROM customers c WHERE c.name=account_entries.customer LIMIT 1)
                           WHERE (customer_id IS NULL OR customer_id=0)
                             AND customer IS NOT NULL AND TRIM(customer)<>''""")
        # Keep customer accounts synchronized with customer-linked currency transactions.
        # Existing shop transactions already have their own ledger entry, so they are excluded.
        tx_rows=self.db.execute("SELECT id,created,kind,currency,amount,rate,afn_amount,customer,notes FROM transactions WHERE customer IS NOT NULL AND TRIM(customer)<>''").fetchall()
        for txid,tcreated,tkind,tcurrency,tamount,trate,tafn,tcustomer,tnotes in tx_rows:
            if tnotes and str(tnotes).startswith('دوکان:'):
                self.db.execute("UPDATE transactions SET source_type='shop' WHERE id=? AND (source_type IS NULL OR source_type='manual')",(txid,))
                continue
            crow=self.db.execute("SELECT id FROM customers WHERE name=? LIMIT 1",(tcustomer,)).fetchone()
            if not crow: continue
            self.db.execute("UPDATE transactions SET customer_id=? WHERE id=?",(crow[0],txid))
            exists=self.db.execute("SELECT 1 FROM account_entries WHERE source_type='transaction' AND source_id=? LIMIT 1",(txid,)).fetchone()
            if not exists:
                etype='قرضداری مشتری' if tkind=='فروش' else ('بستانکاری مشتری' if tkind=='خرید' else None)
                if etype:
                    self.db.execute("INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(tcreated,crow[0],tcustomer,etype,float(tamount or 0),f'معامله #{txid} - {tnotes or ""}'.strip(),tcurrency or 'AFN - افغانی',float(trate or 1),float(tafn or (tamount or 0)*(trate or 1)),'transaction',txid))
                self.db.execute("UPDATE transactions SET source_type='transaction',source_id=? WHERE id=?",(txid,txid))
        self.db.execute("UPDATE account_entries SET account_no=id WHERE account_no IS NULL OR account_no=0")
        self.db.execute("UPDATE account_entries SET source_type='receipt' WHERE source_type='manual' AND notes LIKE 'رسید شماره %'")
        receipt_rows = self.db.execute("""
            SELECT r.id,r.created,r.customer_id,r.customer,r.receipt_type,r.amount,
                   COALESCE(r.description,''),COALESCE(r.currency,'AFN - افغانی'),
                   COALESCE(r.rate,1),COALESCE(r.afn_amount,r.amount*COALESCE(r.rate,1)),
                   COALESCE(r.commission,0),COALESCE(r.commission_afn,0),
                   COALESCE(r.commission_currency,r.currency,'AFN - افغانی'),
                   COALESCE(r.route,'')
            FROM receipts r WHERE r.customer_id IS NOT NULL
        """).fetchall()
        for rr in receipt_rows:
            rid,rcdate,rcid,rcname,rtype,ramount,rdesc,rcur,rrate,rafn,rcomm,rcafn,rcommcur,rroute=rr
            linked=self.db.execute(
                "SELECT 1 FROM account_entries WHERE source_type='receipt' AND source_id=? LIMIT 1",(rid,)).fetchone()
            if not linked:
                etype='بستانکاری مشتری' if rtype=='دریافت از مشتری' else 'قرضداری مشتری'
                rno=self.db.execute("SELECT receipt_no FROM receipts WHERE id=?",(rid,)).fetchone()
                rno=(rno[0] if rno else rid) or rid
                self.db.execute("""
                    INSERT INTO account_entries(
                        created,customer_id,customer,entry_type,amount,notes,currency,rate,
                        afn_amount,commission,commission_afn,commission_currency,route,
                        source_type,source_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,(rcdate,rcid,rcname,etype,float(ramount or 0),
                      f"رسید شماره {rno} - {rdesc}".strip(),rcur,float(rrate or 1),
                      float(rafn or 0),float(rcomm or 0),float(rcafn or 0),rcommcur,
                      rroute,'receipt',rid))

        # Backfill the receipt link for older versions so edit/delete can update
        # exactly the account entry created by that receipt.
        self.db.execute("""UPDATE account_entries
                           SET source_id=(
                               SELECT r.id FROM receipts r
                               WHERE r.receipt_no=CAST(
                                   substr(account_entries.notes, instr(account_entries.notes,'رسید شماره ')+length('رسید شماره '))
                                   AS INTEGER)
                               LIMIT 1)
                           WHERE source_type='receipt' AND (source_id IS NULL OR source_id=0)
                             AND notes LIKE 'رسید شماره %'""")
        # Customer remittance/exchange commission rules (fully configurable).
        self.db.execute("""CREATE TABLE IF NOT EXISTS commission_rules(
            id INTEGER PRIMARY KEY AUTOINCREMENT, route TEXT NOT NULL,
            currency TEXT NOT NULL, base_amount REAL NOT NULL DEFAULT 1000000,
            commission_amount REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
            UNIQUE(route,currency))""")
        for route,currency,base,fee in [
            ('ایران','IRR - تومان',1000000,350000),
            ('افغانستان','IRR - تومان',1000000,350000),
            ('ایران','AFN - افغانی',1000000,0),
            ('افغانستان','AFN - افغانی',1000000,0)]:
            self.db.execute("INSERT OR IGNORE INTO commission_rules(route,currency,base_amount,commission_amount) VALUES(?,?,?,?)",(route,currency,base,fee))
        ae_cols2=[r[1] for r in self.db.execute("PRAGMA table_info(account_entries)").fetchall()]
        for col,definition in [("commission","REAL DEFAULT 0"),("commission_afn","REAL DEFAULT 0"),("commission_currency","TEXT DEFAULT 'AFN - افغانی'"),("route","TEXT DEFAULT ''")]:
            if col not in ae_cols2: self.db.execute(f"ALTER TABLE account_entries ADD COLUMN {col} {definition}")
        self.db.execute("UPDATE account_entries SET commission_currency=COALESCE(NULLIF(commission_currency,''),currency,'AFN - افغانی')")
        # KRW migration: make sure legacy shipment snapshots have stable IDs and
        # preserve the historical AFN values recorded at the time of entry.
        # IMPORTANT: older/new installations may not have a shipments table yet.
        # PRAGMA table_info() returns an empty list for a missing table, but the
        # ALTER TABLE statements below require the table to exist. Create a
        # minimal table first; the migration below then adds the full schema.
        self.db.execute("""CREATE TABLE IF NOT EXISTS shipments(
            id INTEGER PRIMARY KEY AUTOINCREMENT
        )""")
        shipment_cols={r[1] for r in self.db.execute("PRAGMA table_info(shipments)").fetchall()}
        shipment_defaults={
            "shipment_no": "INTEGER", "created": "TEXT",
            "origin_country": "TEXT DEFAULT 'افغانستان'", "origin_province": "TEXT DEFAULT ''",
            "destination_country": "TEXT DEFAULT 'ایران'", "destination_province": "TEXT DEFAULT ''",
            "cargo_type": "TEXT DEFAULT ''", "sender": "TEXT DEFAULT ''", "receiver": "TEXT DEFAULT ''",
            "income": "REAL DEFAULT 0", "income_currency": "TEXT DEFAULT 'AFN - افغانی'",
            "income_rate": "REAL DEFAULT 1", "income_afn": "REAL DEFAULT 0",
            "worker": "REAL DEFAULT 0", "worker_currency": "TEXT DEFAULT 'AFN - افغانی'", "worker_rate": "REAL DEFAULT 1", "worker_afn": "REAL DEFAULT 0",
            "customs_origin": "REAL DEFAULT 0", "customs_origin_currency": "TEXT DEFAULT 'AFN - افغانی'", "customs_origin_rate": "REAL DEFAULT 1", "customs_origin_afn": "REAL DEFAULT 0",
            "customs_destination": "REAL DEFAULT 0", "customs_destination_currency": "TEXT DEFAULT 'AFN - افغانی'", "customs_destination_rate": "REAL DEFAULT 1", "customs_destination_afn": "REAL DEFAULT 0",
            "freight_origin": "REAL DEFAULT 0", "freight_origin_currency": "TEXT DEFAULT 'AFN - افغانی'", "freight_origin_rate": "REAL DEFAULT 1", "freight_origin_afn": "REAL DEFAULT 0",
            "freight_destination": "REAL DEFAULT 0", "freight_destination_currency": "TEXT DEFAULT 'AFN - افغانی'", "freight_destination_rate": "REAL DEFAULT 1", "freight_destination_afn": "REAL DEFAULT 0",
            "other_cost": "REAL DEFAULT 0", "other_cost_currency": "TEXT DEFAULT 'AFN - افغانی'", "other_cost_rate": "REAL DEFAULT 1", "other_cost_afn": "REAL DEFAULT 0",
            "total_cost_afn": "REAL DEFAULT 0", "profit_afn": "REAL DEFAULT 0", "notes": "TEXT DEFAULT ''"
        }
        for col, definition in shipment_defaults.items():
            if col not in shipment_cols:
                self.db.execute(f"ALTER TABLE shipments ADD COLUMN {col} {definition}")
        self.db.execute("UPDATE shipments SET shipment_no=id WHERE shipment_no IS NULL OR shipment_no=0")
        self.db.execute("UPDATE shipments SET income_rate=1 WHERE income_rate IS NULL OR income_rate=0")
        self.db.execute("UPDATE shipments SET income_afn=income*income_rate WHERE income_afn IS NULL OR income_afn=0")
        self.db.execute("UPDATE shipments SET total_cost_afn=COALESCE(worker_afn,0)+COALESCE(customs_origin_afn,0)+COALESCE(customs_destination_afn,0)+COALESCE(freight_origin_afn,0)+COALESCE(freight_destination_afn,0)+COALESCE(other_cost_afn,0) WHERE total_cost_afn IS NULL")
        self.db.execute("UPDATE shipments SET profit_afn=COALESCE(income_afn,0)-COALESCE(total_cost_afn,0) WHERE profit_afn IS NULL")
        self.db.commit()
        self.db.execute("""CREATE TABLE IF NOT EXISTS businesses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            business_type TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS business_transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            business_id INTEGER NOT NULL,
            business_name TEXT NOT NULL,
            business_type TEXT NOT NULL,
            kind TEXT NOT NULL,
            amount REAL NOT NULL,
            notes TEXT,
            FOREIGN KEY(business_id) REFERENCES businesses(id))""")
        # V16.4 unified shop ledger migration: currency, customer and journal links.
        bt_cols=[r[1] for r in self.db.execute("PRAGMA table_info(business_transactions)").fetchall()]
        for col,definition in [("currency","TEXT DEFAULT 'AFN - افغانی'"),("rate","REAL DEFAULT 1"),("afn_amount","REAL DEFAULT 0"),("customer_id","INTEGER"),("source_type","TEXT DEFAULT 'shop'"),("source_id","INTEGER")]:
            if col not in bt_cols: self.db.execute(f"ALTER TABLE business_transactions ADD COLUMN {col} {definition}")
        self.db.execute("UPDATE business_transactions SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE business_transactions SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE business_transactions SET afn_amount=amount*rate WHERE afn_amount IS NULL OR afn_amount=0")
        self.db.execute("""CREATE TRIGGER IF NOT EXISTS trg_receipts_no AFTER INSERT ON receipts
            WHEN NEW.receipt_no IS NULL OR NEW.receipt_no=0
            BEGIN UPDATE receipts SET receipt_no=COALESCE((SELECT MAX(receipt_no) FROM receipts WHERE id<NEW.id),0)+1 WHERE id=NEW.id; END""")
        self.db.execute("""CREATE TRIGGER IF NOT EXISTS trg_account_entries_no AFTER INSERT ON account_entries
            WHEN NEW.account_no IS NULL OR NEW.account_no=0
            BEGIN UPDATE account_entries SET account_no=COALESCE((SELECT MAX(account_no) FROM account_entries WHERE id<NEW.id),0)+1 WHERE id=NEW.id; END""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS whatsapp_receipts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            imported_at TEXT NOT NULL, group_name TEXT, sender_name TEXT, sender_phone TEXT,
            source_file TEXT NOT NULL, source_hash TEXT UNIQUE, receipt_name TEXT, receipt_no TEXT,
            receipt_date TEXT, amount REAL DEFAULT 0, currency TEXT DEFAULT 'AFN', raw_text TEXT,
            customer_id INTEGER, customer_name TEXT, status TEXT NOT NULL DEFAULT 'در انتظار تأیید', notes TEXT,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS whatsapp_settings(
            id INTEGER PRIMARY KEY CHECK(id=1), group_name TEXT, import_folder TEXT,
            auto_watch INTEGER NOT NULL DEFAULT 0, last_scan TEXT,
            official_enabled INTEGER NOT NULL DEFAULT 0, connection_status TEXT DEFAULT 'آماده اتصال رسمی',
            business_phone TEXT DEFAULT '', webhook_url TEXT DEFAULT '')""")
        wa_cols=[r[1] for r in self.db.execute("PRAGMA table_info(whatsapp_settings)").fetchall()]
        for col,definition in [("official_enabled","INTEGER NOT NULL DEFAULT 0"),("connection_status","TEXT DEFAULT 'آماده اتصال رسمی'"),("business_phone","TEXT DEFAULT ''"),("webhook_url","TEXT DEFAULT ''")]:
            if col not in wa_cols: self.db.execute(f"ALTER TABLE whatsapp_settings ADD COLUMN {col} {definition}")

        self.db.execute("""CREATE TABLE IF NOT EXISTS fruit_inventory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fruit_name TEXT NOT NULL,
            quantity_kg REAL NOT NULL DEFAULT 0,
            unit_price REAL NOT NULL DEFAULT 0,
            updated TEXT NOT NULL,
            notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS shop_inventory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            unit TEXT NOT NULL DEFAULT 'عدد',
            quantity REAL NOT NULL DEFAULT 0,
            min_quantity REAL NOT NULL DEFAULT 0,
            cost_price REAL NOT NULL DEFAULT 0,
            sale_price REAL NOT NULL DEFAULT 0,
            currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            updated TEXT NOT NULL,
            notes TEXT,
            UNIQUE(business_id,item_name),
            FOREIGN KEY(business_id) REFERENCES businesses(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS invoices(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL,
            customer_id INTEGER, customer TEXT NOT NULL, phone TEXT, notes TEXT, total REAL NOT NULL DEFAULT 0)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS retail_sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL,
            business_type TEXT NOT NULL, business_name TEXT NOT NULL,
            customer_id INTEGER, customer TEXT NOT NULL, phone TEXT,
            total REAL NOT NULL DEFAULT 0, paid REAL NOT NULL DEFAULT 0,
            debt REAL NOT NULL DEFAULT 0, notes TEXT,
            invoice_no TEXT DEFAULT '', discount REAL NOT NULL DEFAULT 0,
            tax REAL NOT NULL DEFAULT 0, final_total REAL NOT NULL DEFAULT 0)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS retail_sale_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL,
            item_name TEXT NOT NULL, unit TEXT NOT NULL, quantity REAL NOT NULL,
            unit_price REAL NOT NULL, total REAL NOT NULL,
            FOREIGN KEY(sale_id) REFERENCES retail_sales(id))""")
        # V16.4.2: link retail invoices to an actual shop and preserve invoice currency.
        rs_cols=[r[1] for r in self.db.execute("PRAGMA table_info(retail_sales)").fetchall()]
        for col,definition in [("business_id","INTEGER"),("currency","TEXT DEFAULT 'AFN - افغانی'"),("rate","REAL DEFAULT 1")]:
            if col not in rs_cols: self.db.execute(f"ALTER TABLE retail_sales ADD COLUMN {col} {definition}")
        rsi_cols=[r[1] for r in self.db.execute("PRAGMA table_info(retail_sale_items)").fetchall()]
        if "stock_before" not in rsi_cols: self.db.execute("ALTER TABLE retail_sale_items ADD COLUMN stock_before REAL DEFAULT NULL")
        if "stock_after" not in rsi_cols: self.db.execute("ALTER TABLE retail_sale_items ADD COLUMN stock_after REAL DEFAULT NULL")
        self.db.execute("UPDATE retail_sales SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''" )
        self.db.execute("UPDATE retail_sales SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("""CREATE TABLE IF NOT EXISTS retail_prices(
            id INTEGER PRIMARY KEY AUTOINCREMENT, business_type TEXT NOT NULL,
            item_name TEXT NOT NULL, unit_price REAL NOT NULL DEFAULT 0,
            updated TEXT NOT NULL, UNIQUE(business_type,item_name))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS invoice_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, fruit_name TEXT NOT NULL,
            unit TEXT NOT NULL, quantity REAL NOT NULL, quantity_kg REAL NOT NULL, unit_price REAL NOT NULL, total REAL NOT NULL)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
            full_name TEXT, active INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL)""")
        # V16.4.2: real OAuth identities are stored separately from local passwords.
        self.db.execute("""CREATE TABLE IF NOT EXISTS social_accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, subject TEXT NOT NULL,
            user_id INTEGER NOT NULL, email TEXT, created TEXT NOT NULL, last_login TEXT,
            UNIQUE(provider, subject), FOREIGN KEY(user_id) REFERENCES users(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS remittances(
            id INTEGER PRIMARY KEY AUTOINCREMENT, transfer_no TEXT UNIQUE NOT NULL, created TEXT NOT NULL,
            sender_name TEXT NOT NULL, sender_surname TEXT, sender_phone TEXT NOT NULL, sender_province TEXT,
            receiver_name TEXT NOT NULL, receiver_surname TEXT, receiver_phone TEXT NOT NULL, receiver_province TEXT,
            currency TEXT NOT NULL, amount REAL NOT NULL, fee REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'ثبت شده', notes TEXT, destination_country TEXT DEFAULT 'ایران')""")
        # Migration for databases created by v8
        cols=[r[1] for r in self.db.execute("PRAGMA table_info(remittances)").fetchall()]
        if "destination_country" not in cols:
            self.db.execute("ALTER TABLE remittances ADD COLUMN destination_country TEXT DEFAULT 'ایران'")
        # V18.57: professional remittance commission fields.
        rem_cols=[r[1] for r in self.db.execute("PRAGMA table_info(remittances)").fetchall()]
        for col,definition in [("commission","REAL DEFAULT 0"),("commission_base","REAL DEFAULT 1000000"),("commission_rate","REAL DEFAULT 0"),("commission_enabled","INTEGER DEFAULT 0"),("commission_currency","TEXT DEFAULT 'AFN - افغانی'"),("net_amount","REAL DEFAULT 0")]:
            if col not in rem_cols: self.db.execute(f"ALTER TABLE remittances ADD COLUMN {col} {definition}")
        # V18.58: commission column must exist before any migration UPDATE.
        # Keep legacy fee/total semantics intact while initializing the new fields.
        self.db.execute("UPDATE remittances SET commission=COALESCE(commission,0), total=CASE WHEN total IS NULL OR total=0 THEN amount+COALESCE(fee,0) ELSE total END, net_amount=CASE WHEN net_amount IS NULL OR net_amount=0 THEN MAX(amount-COALESCE(commission,0),0) ELSE net_amount END")
        self.db.execute("UPDATE remittances SET commission_currency=COALESCE(NULLIF(commission_currency,''),currency,'AFN - افغانی')")
        # V18.78: بارها / حمل‌ونقل — مستقل، چندارزی و قابل گزارش
        # هر مبلغ نرخ تبدیل ثبت‌شده خودش را نگه می‌دارد تا سود و ضرر تاریخی
        # بارها با تغییر نرخ‌های آنلاین بعدی تغییر نکند.
        self.db.execute("""CREATE TABLE IF NOT EXISTS shipments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shipment_no INTEGER UNIQUE,
            created TEXT NOT NULL,
            origin_country TEXT NOT NULL DEFAULT 'افغانستان',
            origin_province TEXT NOT NULL DEFAULT '',
            destination_country TEXT NOT NULL DEFAULT 'ایران',
            destination_province TEXT NOT NULL DEFAULT '',
            cargo_type TEXT DEFAULT '',
            sender TEXT DEFAULT '',
            receiver TEXT DEFAULT '',
            income REAL NOT NULL DEFAULT 0,
            income_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            income_rate REAL NOT NULL DEFAULT 1,
            income_afn REAL NOT NULL DEFAULT 0,
            worker REAL NOT NULL DEFAULT 0,
            worker_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            worker_rate REAL NOT NULL DEFAULT 1,
            worker_afn REAL NOT NULL DEFAULT 0,
            customs_origin REAL NOT NULL DEFAULT 0,
            customs_origin_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            customs_origin_rate REAL NOT NULL DEFAULT 1,
            customs_origin_afn REAL NOT NULL DEFAULT 0,
            customs_destination REAL NOT NULL DEFAULT 0,
            customs_destination_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            customs_destination_rate REAL NOT NULL DEFAULT 1,
            customs_destination_afn REAL NOT NULL DEFAULT 0,
            freight_origin REAL NOT NULL DEFAULT 0,
            freight_origin_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            freight_origin_rate REAL NOT NULL DEFAULT 1,
            freight_origin_afn REAL NOT NULL DEFAULT 0,
            freight_destination REAL NOT NULL DEFAULT 0,
            freight_destination_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            freight_destination_rate REAL NOT NULL DEFAULT 1,
            freight_destination_afn REAL NOT NULL DEFAULT 0,
            other_cost REAL NOT NULL DEFAULT 0,
            other_cost_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            other_cost_rate REAL NOT NULL DEFAULT 1,
            other_cost_afn REAL NOT NULL DEFAULT 0,
            total_cost_afn REAL NOT NULL DEFAULT 0,
            profit_afn REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT ''
        )""")
        shipment_cols=[r[1] for r in self.db.execute("PRAGMA table_info(shipments)").fetchall()]
        if "shipment_no" in shipment_cols:
            self.db.execute("UPDATE shipments SET shipment_no=id WHERE shipment_no IS NULL OR shipment_no=0")
        self.db.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_shipments_no ON shipments(shipment_no)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS exchange_rates(
            code TEXT PRIMARY KEY, rate_to_afn REAL NOT NULL, updated TEXT NOT NULL, source TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS app_settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        # v20: persistent notebook / دفتر یادداشت
        self.db.execute("""CREATE TABLE IF NOT EXISTS notebook_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL DEFAULT 'یادداشت جدید',
            content TEXT NOT NULL DEFAULT '',
            created TEXT NOT NULL,
            updated TEXT NOT NULL
        )""")
        self.db.commit()
        mode_row=self.db.execute("SELECT value FROM app_settings WHERE key='ui_mode'").fetchone()
        self.ui_mode = (mode_row[0] if mode_row and mode_row[0] in ("simple","pro") else "simple")
        # v20.0.2: persist the selected application theme so Dark/Light mode
        # survives navigation, KRW reopen, and restarting the program.
        theme_row=self.db.execute("SELECT value FROM app_settings WHERE key='ui_theme'").fetchone()
        self.dark_mode = not (theme_row and str(theme_row[0]).strip().lower() in ("light","روشن","0","false"))
        os.makedirs(BACKUP_DIR, exist_ok=True)
        os.makedirs(KRW_AUTO_DIR, exist_ok=True)
        self.after(60000, self.autosave_backup)
        self.after(1800000, self._scheduled_rate_refresh)
        self._online_rates = {}
        self._rates_updated = ""
        self._rates_online_ok = False
        self._rates_source = ""
        self._rate_market_source = "shahzada"
        self._rates_loading = False
        # Do not block application startup with the online FX lookup.
        # Cached/local rates are enough for the first screen; refresh in the
        # background after the main UI is ready.
        self.style()
        self._set_app_icon()
        self._load_ui_icons()
        # Automatically keep every popup/dialog inside the screen. This avoids
        # clipped windows on 1366x768 and similar resolutions.
        self.bind_all("<Map>", self._on_any_window_map, add="+")
        self.ensure_license()
        # IMPORTANT: do not maximize/zoom the hidden root while the login dialog
        # is open. On Windows + overrideredirect this can make the main window
        # appear above the login dialog and hide it. The main window is maximized
        # only after a successful login.
        self.ensure_login()

    def _restore_normal_startup(self):
        """Start in a normal resizable window; never force full-screen/maximized mode."""
        try:
            self.update_idletasks()
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            # Keep the full application usable on common 1366x768 screens.
            # The taskbar/custom title bar consume some vertical space, so leave
            # a safe margin instead of opening a window taller than the screen.
            w = min(1240, max(980, sw - 80))
            h = min(700, max(620, sh - 95))
            x = max(0, (sw - w) // 2)
            y = max(0, (sh - h) // 2)
            try: self.state("normal")
            except Exception: pass
            self.geometry(f"{w}x{h}+{x}+{y}")
            self._normal_geometry = self.geometry()
            try: self.max_btn.config(text="□")
            except Exception: pass
            self.after(120, self._apply_theme)
        except Exception:
            pass

    def _maximize_startup(self):
        """Open the main application at the largest usable screen size.
        The app uses a custom title bar, so a geometry fallback is used when
        Windows does not honor the normal Tk zoomed state for overrideredirect.
        """
        try:
            self.update_idletasks()
            self._normal_geometry = self.geometry()
            try:
                self.state("zoomed")
            except Exception:
                pass
            # With the custom title bar, force a screen-sized window if Tk did
            # not actually maximize it. Keep a small taskbar-safe margin.
            self.update_idletasks()
            if self.winfo_width() < int(self.winfo_screenwidth() * 0.90):
                sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
                self.geometry(f"{sw}x{max(650, sh-48)}+0+0")
            # Leave a usable bottom margin so fixed-height pages never hide
            # their action area behind the taskbar/custom title bar.
            self.update_idletasks()
            if self.winfo_height() > self.winfo_screenheight() - 20:
                self.geometry(f"{self.winfo_width()}x{self.winfo_screenheight()-20}+0+0")
            try:
                self.max_btn.config(text="❐")
            except Exception:
                pass
            self.after(120, self._apply_theme)
        except Exception:
            pass

    def _show_startup_splash(self, duration=1800):
        """Show the Jahan Accounting logo briefly after successful login.

        The main window stays hidden while the dashboard is initialized, so
        the user sees a clean branded transition instead of a blank window.
        """
        try:
            splash = tk.Toplevel(self)
            splash.overrideredirect(True)
            splash.configure(bg="#070B13")
            splash.attributes("-topmost", True)
            w, h = 560, 560
            sw, sh = splash.winfo_screenwidth(), splash.winfo_screenheight()
            splash.geometry(f"{w}x{h}+{max(0,(sw-w)//2)}+{max(0,(sh-h)//2)}")

            outer = tk.Frame(splash, bg="#070B13", highlightbackground="#D6B66A", highlightthickness=2)
            outer.pack(fill="both", expand=True, padx=8, pady=8)

            logo_path = os.path.join(RESOURCE_BASE, "logo.png")
            if not os.path.exists(logo_path):
                logo_path = os.path.join(BASE, "logo.png")
            img = None
            if os.path.exists(logo_path):
                try:
                    img = Image.open(logo_path).convert("RGBA")
                    img.thumbnail((420, 420), Image.LANCZOS)
                    self._splash_photo = ImageTk.PhotoImage(img)
                except Exception:
                    try:
                        self._splash_photo = tk.PhotoImage(file=logo_path)
                    except Exception:
                        self._splash_photo = None
            else:
                self._splash_photo = None

            if self._splash_photo is not None:
                tk.Label(outer, image=self._splash_photo, bg="#070B13", bd=0).pack(pady=(35, 18))

            tk.Label(outer, text="نرم افزار حسابداری جهان", bg="#070B13", fg="#F2D27A",
                     font=(UI_FONT, 20, "bold"), anchor="center").pack(fill="x", pady=(0, 4))
            tk.Label(outer, text=f"نسخه {APP_VERSION}", bg="#070B13", fg="#B7C0CC",
                     font=(UI_FONT, 10), anchor="center").pack(fill="x")
            tk.Label(outer, text="در حال آماده‌سازی برنامه...", bg="#070B13", fg="#8E9AA8",
                     font=(UI_FONT, 9), anchor="center").pack(fill="x", pady=(16, 0))

            splash.update_idletasks()
            splash.after(int(duration), lambda: self._close_startup_splash(splash))
            self._startup_splash = splash
            return splash
        except Exception:
            self._startup_splash = None
            return None

    def _close_startup_splash(self, splash):
        try:
            if splash.winfo_exists():
                splash.destroy()
        except Exception:
            pass
        self._startup_splash = None
        self._splash_photo = None

    def _set_app_icon(self):
        # Set both Tk icon and the native Windows icon/taskbar identity.
        try:
            ico_path = os.path.join(RESOURCE_BASE, "jahan_icon.ico")
            if not os.path.exists(ico_path):
                ico_path = os.path.join(BASE, "jahan_icon.ico")
            if os.path.exists(ico_path):
                try:
                    self.iconbitmap(ico_path)
                except Exception:
                    pass
            logo_path = os.path.join(RESOURCE_BASE, "logo.png")
            if not os.path.exists(logo_path):
                logo_path = os.path.join(BASE, "logo.png")
            if os.path.exists(logo_path):
                self._app_icon_img = tk.PhotoImage(file=logo_path)
                self.iconphoto(True, self._app_icon_img)
            _set_windows_app_identity(self.winfo_id())
        except Exception:
            pass

    def _start_drag(self, event):
        self._drag_x = event.x_root - self.winfo_x()
        self._drag_y = event.y_root - self.winfo_y()

    def _drag_window(self, event):
        if self.state() != "zoomed":
            self.geometry(f"+{event.x_root-self._drag_x}+{event.y_root-self._drag_y}")

    def _toggle_maximize(self):
        if self.state() == "zoomed":
            self.state("normal")
            self.geometry(self._normal_geometry)
            self.max_btn.config(text="□")
        else:
            self._normal_geometry = self.geometry()
            try:
                self.state("zoomed")
            except Exception:
                self.attributes("-zoomed", True)
            self.max_btn.config(text="❐")

    def _minimize(self):
        # Withdraw first because overrideredirect windows do not always honor iconify.
        self.withdraw()
        self.after(100, lambda: self.deiconify())
        try:
            self.iconify()
        except Exception:
            pass

    def _close_app(self):
        try:
            self.db.commit()
            self.db.close()
        except Exception:
            pass
        self.destroy()

    def _toggle_dark_mode(self):
        """Toggle the complete application theme and persist it immediately."""
        self.dark_mode = not bool(getattr(self, "dark_mode", False))
        try:
            self.db.execute(
                "INSERT OR REPLACE INTO app_settings(key,value) VALUES('ui_theme',?)",
                ("dark" if self.dark_mode else "light",)
            )
            self.db.commit()
        except Exception:
            pass
        self._apply_theme()
        try:
            self.update_idletasks()
            self.after_idle(lambda: self._apply_theme_no_schedule())
        except Exception:
            pass

    def _apply_theme(self):
        # Runtime theme pass: recolors the complete visible Tk tree without
        # rebuilding pages, and is re-run after each page navigation (and,
        # now, shortly after any dialog opens once the shell is ready).
        dark = self.dark_mode
        # Richer "dark gold/blue" luxury palette (deep near-black navy,
        # warm ivory-gold text, and a warmer gold accent).
        bg = "#080D14" if dark else "#F4F6F8"
        panel = "#121B29" if dark else "#FFFFFF"
        sidebar = "#0E1622" if dark else "#E9EDF1"
        ink = "#F0C96A" if dark else "#B8862F"
        muted = "#E0B95E" if dark else "#B8862F"
        line = "#26374A" if dark else "#D8DEE4"
        accent = "#E4C077" if dark else "#B58E45"
        hover = "#1C2A3D" if dark else "#F8F1DF"
        border = "#2E4055" if dark else "#C7D0D9"
        header = "#05080D"
        self._apply_ttk_theme(dark, panel, ink, accent, hover, border)
        try:
            self.configure(bg=bg)
            self.tk.call("ttk::style", "configure", "Treeview", "-background", panel, "-foreground", ink, "-fieldbackground", panel)
            self.tk.call("ttk::style", "configure", "Treeview.Heading", "-background", accent, "-foreground", ("#241B0C" if dark else "#FFFFFF"))
            self.tk.call("ttk::style", "map", "Treeview", "-background", "{selected "+hover+"}")
        except Exception:
            pass
        def walk(w):
            # Decorative chrome (gradient title bar / header / sidebar) paints
            # its own colors and must never be flattened by this pass.
            if w in self._no_retheme:
                return
            try:
                cls=w.winfo_class()
                if w is getattr(self, "_titlebar", None):
                    w.configure(bg=header)
                elif cls in ("Frame", "Labelframe", "Toplevel"):
                    w.configure(bg=panel if w is not getattr(self,"main",None) else bg)
                elif cls == "Label":
                    w.configure(bg=panel if w.master is not getattr(self,"main",None) else bg)
                    try:
                        # Preserve gold/blue accents; only convert dark/light neutral text.
                        w.configure(fg=ink)
                    except Exception: pass
                elif cls in ("Button", "Entry", "Text", "Listbox"):
                    w.configure(bg=panel, fg=ink)
                    if cls in ("Entry","Text"):
                        w.configure(insertbackground=ink)
                        try: w.configure(highlightbackground=border, highlightcolor=accent)
                        except Exception: pass
                elif cls == "Canvas":
                    w.configure(bg=panel)
                elif cls == "Scrollbar":
                    w.configure(bg=panel, troughcolor=bg, activebackground=accent,
                                highlightbackground=border, highlightcolor=accent)
            except Exception:
                pass
            for ch in w.winfo_children(): walk(ch)
        walk(self)
        # Keep the custom title bar dark and its own controls independent of the OS caption.
        if hasattr(self,"_titlebar"):
            try: self._titlebar.configure(bg=header)
            except Exception: pass
        for b in getattr(self,"nav_buttons",[]):
            try:
                b.configure(bg=panel, fg=accent, activebackground=hover, activeforeground=ink)
                bind_smooth_hover(b, panel, hover, accent, ink)
            except Exception: pass
        if hasattr(self,"dark_btn"):
            try: self.dark_btn.configure(text=("☀ حالت روشن" if dark else "☾ حالت دارک"), bg=header, fg="#E4C077", activebackground="#1C2A3D")
            except Exception: pass
        try:
            self.after(80, self._apply_theme_deferred)
        except Exception: pass

    def _apply_theme_deferred(self):
        if self.winfo_exists(): self._apply_theme_no_schedule()

    def _apply_theme_no_schedule(self):
        # second pass for widgets created by the current page
        self._retheme_subtree(self)

    def _retheme_subtree(self, root_widget):
        """Recolor one widget and everything under it to the current
        dark/gold theme. Used for the periodic whole-app pass (root_widget=
        self) AND, on its own, for a single freshly-opened dialog - so
        opening a dialog only repaints that dialog, never the whole app."""
        dark=self.dark_mode; panel="#121B29" if dark else "#FFFFFF"; bg="#080D14" if dark else "#F4F6F8"; ink="#F0C96A" if dark else "#B8862F"; muted="#E0B95E" if dark else "#B8862F"
        border="#2E4055" if dark else "#C7D0D9"; accent="#E4C077" if dark else "#B58E45"
        def walk(w):
            if w in self._no_retheme:
                return
            try:
                cls=w.winfo_class()
                if cls in ("Frame","Labelframe","Toplevel"): w.configure(bg=panel if w is not getattr(self,"main",None) else bg)
                elif cls=="Label":
                    w.configure(bg=panel if w.master is not getattr(self,"main",None) else bg)
                    w.configure(fg=ink)
                elif cls in ("Button","Entry","Text","Listbox"):
                    w.configure(bg=panel,fg=ink)
                    if cls in ("Entry","Text"):
                        try: w.configure(highlightbackground=border, highlightcolor=accent)
                        except Exception: pass
                elif cls=="Canvas": w.configure(bg=panel)
                elif cls=="Scrollbar": w.configure(bg=panel, troughcolor=bg, activebackground=accent,
                                                    highlightbackground=border, highlightcolor=accent)
            except Exception: pass
            for ch in w.winfo_children(): walk(ch)
        walk(root_widget)

    def set_zoom(self, percent):
        percent = max(80, min(150, int(percent)))
        self.zoom_percent = percent
        # Tk scaling is applied globally so text, controls and spacing scale together.
        self.tk.call("tk", "scaling", percent / 100.0)
        if hasattr(self, "zoom_label"):
            self.zoom_label.config(text=f"{percent}%")
        try:
            self.update_idletasks()
        except Exception:
            pass

    def _custom_titlebar(self):
        # Native Windows title bar is used; this method is retained for compatibility.
        return None


    def device_id(self):
        # A longer device fingerprint than the old 64-bit value. Keep the
        # hardware fingerprint out of the license token itself.
        parts = [
            platform.system(), platform.release(), platform.machine(),
            platform.node(), str(uuid.getnode()),
            os.environ.get("PROCESSOR_IDENTIFIER", ""),
        ]
        raw = "|".join(parts).encode("utf-8", "ignore")
        return hashlib.sha256(raw).hexdigest()[:32].upper()

    def _legacy_device_id(self):
        raw = f"{platform.system()}|{platform.machine()}|{platform.node()}|{uuid.getnode()}".encode()
        return hashlib.sha256(raw).hexdigest()[:16].upper()

    def _legacy_expected_serial(self):
        digest = hmac.new(LEGACY_LICENSE_SECRET, self._legacy_device_id().encode(), hashlib.sha256).hexdigest().upper()
        return "JAHAN11-" + "-".join(digest[i:i+4] for i in range(0, 16, 4))

    def expected_serial(self):
        # New offline token: version + device-bound HMAC, with 96 bits of the
        # digest exposed. The complete device id is never encoded in the serial.
        payload = f"JAHAN|PC|{LICENSE_VERSION}|{self.device_id()}".encode("utf-8")
        digest = hmac.new(LICENSE_SECRET, payload, hashlib.sha256).hexdigest().upper()[:24]
        return LICENSE_PREFIX + "-" + "-".join(digest[i:i+4] for i in range(0, 24, 4))

    def ensure_license(self):
        row=self.db.execute("SELECT value FROM app_settings WHERE key='license_serial'").fetchone()
        dev_row=self.db.execute("SELECT value FROM app_settings WHERE key='license_device'").fetchone()
        stored = str(row[0]).strip().upper() if row and row[0] else ""
        stored_dev = str(dev_row[0]).strip() if dev_row and dev_row[0] else ""
        current_dev = self.device_id()
        # New licenses are preferred. Existing installations with a valid V11
        # license continue to work so upgrading the app does not lock users out.
        if stored and stored_dev == current_dev and hmac.compare_digest(stored, self.expected_serial()):
            return
        if stored and stored_dev == self._legacy_device_id() and hmac.compare_digest(stored, self._legacy_expected_serial()):
            # Legacy activation remains valid on an existing installation.
            # New activations use the stronger v20 format.
            return
        win=tk.Toplevel(self); win.title("فعال‌سازی نرم افزار حسابداری جهان"); win.geometry("560x520"); win.minsize(500,440); win.resizable(True,True)
        win.configure(bg="#F4F6F8"); win.protocol("WM_DELETE_WINDOW", self.destroy)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        win.lift(); win.focus_force(); win.grab_set()
        RTLLabel(win,text="🔒 فعال‌سازی نرم افزار حسابداری جهان",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(16,"bold")).pack(pady=22)
        RTLLabel(win,text="این سریال نسخه جدید است و فقط روی همین دستگاه قابل استفاده است.",
                 bg="#F4F6F8",fg="#687582",font=ui_font(10)).pack(pady=4)
        RTLLabel(win,text="شناسه دستگاه",bg="#F4F6F8",fg="#687582").pack(anchor="e",padx=35,pady=(18,3))
        did=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3")
        did.pack(fill="x",padx=35,ipady=8); did.insert(0,self.device_id()); did.config(state="readonly")
        RTLLabel(win,text="سریال فعال‌سازی",bg="#F4F6F8",fg="#687582").pack(anchor="e",padx=35,pady=(12,3))
        serial=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="center",font=ui_font(11,"bold"))
        serial.pack(fill="x",padx=35,ipady=8)
        def paste_serial(event=None):
            try:
                value=self.clipboard_get()
                serial.delete(0,"end")
                serial.insert(0,value)
                serial.icursor("end")
            except Exception:
                pass
            return "break"
        serial.bind("<Control-v>", paste_serial)
        serial.bind("<Control-V>", paste_serial)
        serial.bind("<Shift-Insert>", paste_serial)
        def copy_serial(event=None):
            try:
                self.clipboard_clear(); self.clipboard_append(serial.get()); self.update()
            except Exception:
                pass
            return "break"
        serial.bind("<Control-c>", copy_serial)
        serial.bind("<Control-C>", copy_serial)
        serial.bind("<Control-a>", lambda e: (serial.select_range(0,"end"), "break")[1])
        menu=tk.Menu(serial, tearoff=0)
        menu.add_command(label="کپی", command=copy_serial)
        menu.add_command(label="چسباندن", command=paste_serial)
        menu.add_separator(); menu.add_command(label="انتخاب همه", command=lambda: serial.select_range(0,"end"))
        serial.bind("<Button-3>", lambda e: (menu.tk_popup(e.x_root,e.y_root), menu.grab_release()))
        def normalize_serial(value):
            # Accept normal spaces and common dash variants copied from messages.
            return (str(value).strip().upper()
                    .replace(" ","").replace("–","-").replace("—","-").replace("−","-"))
        def activate():
            val=normalize_serial(serial.get())
            expected=normalize_serial(self.expected_serial())
            if not hmac.compare_digest(val,expected):
                messagebox.showerror("فعال‌سازی","سریال برای این دستگاه معتبر نیست.",parent=win); return
            self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('license_serial',?)",(val,))
            self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('license_device',?)",(self.device_id(),))
            self.db.commit(); win.destroy()
        paste_btn=self.button(win,"📋 چسباندن سریال",paste_serial,"#475569")
        paste_btn.pack(pady=(8,2))
        self.button(win,"✓ فعال‌سازی یک‌بارمصرف",activate).pack(side="bottom",pady=12)
        RTLLabel(win,text="شناسه دستگاه را برای دریافت سریال اختصاصی ارسال کنید.",
                 bg="#F4F6F8",fg="#7D8892",font=ui_font(9)).pack()
        self.wait_window(win)

    def autosave_backup(self):
        """Create a small portable KRW data backup every minute.

        Automatic KRW files are intentionally passwordless so the user can
        open them directly from File > Open, just like a normal document.
        The package contains only a consistent SQLite snapshot and manifest.
        """
        try:
            self.db.commit()
            os.makedirs(KRW_AUTO_DIR, exist_ok=True)
            stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
            path=os.path.join(KRW_AUTO_DIR, f"KRW_{stamp}.krw")
            # AUTO is only the internal key for unattended backups; manual KRW
            # files continue to use the password entered by the user.
            self.create_krw_backup(path, "")
            files=sorted([os.path.join(KRW_AUTO_DIR,x) for x in os.listdir(KRW_AUTO_DIR)
                          if x.startswith("KRW_") and x.endswith(".krw")])
            for old in files[:-20]:
                try: os.remove(old)
                except OSError: pass
        except Exception:
            pass
        finally:
            if self.winfo_exists():
                self.after(60000, self.autosave_backup)

    def _crypt(self, data, password, salt):
        key=hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200000, dklen=32)
        out=bytearray()
        counter=0
        while len(out)<len(data):
            block=hmac.new(key, counter.to_bytes(8,"big"), hashlib.sha256).digest()
            out.extend(block); counter+=1
        return bytes(a^b for a,b in zip(data,out))

    def create_full_backup(self, path, password):
        self.db.commit()
        import zipfile as _zipfile
        salt=os.urandom(16); key=hashlib.pbkdf2_hmac("sha256",password.encode("utf-8"),salt,200000,dklen=32)
        fd,tmp=tempfile.mkstemp(suffix=".zip"); os.close(fd)
        try:
            with _zipfile.ZipFile(tmp,"w",_zipfile.ZIP_DEFLATED) as zz:
                for root,dirs,files in os.walk(BASE):
                    dirs[:] = [d for d in dirs if d not in ("backups","__pycache__")]
                    for fn in files:
                        fp=os.path.join(root,fn)
                        if fp==path or fp.endswith(".jba11"): continue
                        try: zz.write(fp,os.path.relpath(fp,BASE))
                        except OSError: pass
            raw=open(tmp,"rb").read(); enc=self._crypt(raw,password,salt)
            tag=hmac.new(key,enc,hashlib.sha256).digest()
            with open(path,"wb") as f: f.write(b"JAF11\x01"+salt+tag+enc)
        finally:
            try: os.remove(tmp)
            except OSError: pass

    def create_encrypted_backup(self, path, password):
        self.db.commit()
        # SQLite backup gives a consistent snapshot even while the app is running.
        fd,tmp=tempfile.mkstemp(suffix=".db"); os.close(fd)
        try:
            dest=sqlite3.connect(tmp)
            self.db.backup(dest); dest.close()
            raw=open(tmp,"rb").read()
            salt=os.urandom(16)
            enc=self._crypt(raw,password,salt)
            tag=hmac.new(hashlib.pbkdf2_hmac("sha256",password.encode(),salt,200000,dklen=32),enc,hashlib.sha256).digest()
            with open(path,"wb") as f:
                f.write(b"JBA11\x01"+salt+tag+enc)
        finally:
            try: os.remove(tmp)
            except OSError: pass

    def restore_encrypted_backup(self, path, password):
        blob=open(path,"rb").read()
        if not blob.startswith(b"JBA11\x01") or len(blob)<54:
            raise ValueError("فایل بکاپ معتبر نیست.")
        salt=blob[6:22]; tag=blob[22:54]; enc=blob[54:]
        key=hashlib.pbkdf2_hmac("sha256",password.encode("utf-8"),salt,200000,dklen=32)
        if not hmac.compare_digest(tag,hmac.new(key,enc,hashlib.sha256).digest()):
            raise ValueError("رمز بکاپ اشتباه است یا فایل آسیب دیده.")
        raw=self._crypt(enc,password,salt)
        fd,tmp=tempfile.mkstemp(suffix=".db"); os.close(fd)
        try:
            with open(tmp,"wb") as f: f.write(raw)
            test=sqlite3.connect(tmp); test.execute("PRAGMA integrity_check").fetchone(); test.close()
            self.db.close()
            shutil.copy2(tmp,DB)
            self.db=sqlite3.connect(DB)
        finally:
            try: os.remove(tmp)
            except OSError: pass

    def hash_password(self, password):
        return hashlib.sha256(password.encode("utf-8")).hexdigest()

    def _normalize_username(self, value):
        # Canonical username matching: tolerate Persian/Arabic keyboard variants,
        # zero-width characters and accidental surrounding whitespace.
        import unicodedata
        s = unicodedata.normalize("NFKC", str(value or ""))
        s = s.replace("\ufeff", "").replace("\u200b", "").replace("\u200c", "").replace("\u200d", "")
        s = s.replace("ي", "ی").replace("ى", "ی").replace("ك", "ک")
        s = s.replace("ۀ", "ه").replace("ة", "ه")
        return "".join(s.split()).casefold()

    def _password_variants(self, value):
        # Do NOT blindly strip spaces from passwords. Instead, compare the exact
        # password plus safe Unicode/keyboard-equivalent variants.
        import unicodedata
        raw = str(value or "")
        vals = [raw]
        n = unicodedata.normalize("NFKC", raw).replace("\ufeff", "").replace("\u200b", "").replace("\u200c", "").replace("\u200d", "")
        vals.append(n)
        trans = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
        vals.append(n.translate(trans))
        # Common Arabic/Persian letter keyboard variants in passwords.
        vals.append(n.translate(str.maketrans("يىك", "ییک")))
        out=[]
        for x in vals:
            if x not in out: out.append(x)
        return out

    def _password_matches(self, stored, entered):
        stored = str(stored or "")
        for candidate in self._password_variants(entered):
            digest = self.hash_password(candidate)
            if hmac.compare_digest(stored.casefold(), digest.casefold()):
                return True, digest
            if stored == candidate:
                return True, digest
            md5 = hashlib.md5(candidate.encode("utf-8")).hexdigest()
            if hmac.compare_digest(stored.casefold(), md5.casefold()):
                return True, digest
        return False, self.hash_password(str(entered or ""))

    def _find_login_user(self, username):
        # SQLite lower() is not reliable for all Persian/Arabic Unicode forms,
        # so perform canonical comparison in Python as a final authoritative
        # fallback. This fixes accounts created with different keyboard forms
        # or invisible Unicode characters without changing the stored username.
        canon = self._normalize_username(username)
        rows = self.db.execute("SELECT id,username,password_hash,full_name FROM users WHERE active=1 ORDER BY id").fetchall()
        for row in rows:
            if self._normalize_username(row[1]) == canon:
                return row
        return None

    def _auth_config(self):
        cfg = load_auth_config(BASE)
        if USER_DATA_BASE != BASE:
            user_cfg = load_auth_config(USER_DATA_BASE)
            for key, value in user_cfg.items():
                if value:
                    cfg[key] = value
        return cfg

    def _social_user(self, profile):
        """Create/reuse a local user for a verified Google/Apple identity."""
        provider = str(profile.get("provider") or "").lower().strip()
        subject = str(profile.get("subject") or "").strip()
        email = str(profile.get("email") or "").strip().lower()
        full_name = str(profile.get("full_name") or "").strip()
        if provider not in ("google", "apple") or not subject:
            raise ValueError("Invalid social identity returned by provider.")
        row = self.db.execute("""SELECT u.id,u.username,u.password_hash,u.full_name
                                FROM social_accounts s JOIN users u ON u.id=s.user_id
                                WHERE s.provider=? AND s.subject=? AND u.active=1""", (provider, subject)).fetchone()
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        if row:
            self.db.execute("UPDATE social_accounts SET email=?,last_login=? WHERE provider=? AND subject=?",
                            (email, now, provider, subject))
            if full_name and not str(row[3] or "").strip():
                self.db.execute("UPDATE users SET full_name=? WHERE id=?", (full_name, row[0]))
            self.db.commit()
            return self.db.execute("SELECT id,username,password_hash,full_name FROM users WHERE id=?", (row[0],)).fetchone()

        # Never use the provider email as a password. The local password is an
        # unusable random value because OAuth is the credential for this identity.
        suffix = subject[-12:] if len(subject) > 12 else subject
        base_username = f"{provider}_{suffix}"
        username = base_username
        i = 2
        while self.db.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            username = f"{base_username}_{i}"; i += 1
        unusable = self.hash_password(secrets.token_urlsafe(48))
        cur = self.db.execute("INSERT INTO users(username,password_hash,full_name,active,created) VALUES(?,?,?,?,?)",
                              (username, unusable, full_name or email or provider.title()+" User", 1, now))
        uid = cur.lastrowid
        self.db.execute("INSERT INTO social_accounts(provider,subject,user_id,email,created,last_login) VALUES(?,?,?,?,?,?)",
                        (provider, subject, uid, email, now, now))
        self.db.commit()
        return self.db.execute("SELECT id,username,password_hash,full_name FROM users WHERE id=?", (uid,)).fetchone()

    def _start_social_login(self, provider, win, on_success):
        cfg = self._auth_config()
        if provider == "google":
            oauth = GoogleOAuth(cfg["google_client_id"])
            if not oauth.configured:
                messagebox.showwarning(
                    self._tr("Google تنظیم نشده", "Google لا دی تنظیم شوی", "Google not configured"),
                    self._tr("GOOGLE_CLIENT_ID را در auth_config.json تنظیم کنید.",
                              "په auth_config.json کې GOOGLE_CLIENT_ID تنظیم کړئ.",
                              "Set GOOGLE_CLIENT_ID in auth_config.json."), parent=win)
                return
        else:
            oauth = AppleOAuth(cfg["apple_client_id"], cfg["apple_callback_bridge_url"])
            if not oauth.configured:
                messagebox.showwarning(
                    self._tr("Apple تنظیم نشده", "Apple لا دی تنظیم شوی", "Apple not configured"),
                    self._tr("APPLE_CLIENT_ID و APPLE_CALLBACK_BRIDGE_URL را تنظیم کنید.",
                              "APPLE_CLIENT_ID او APPLE_CALLBACK_BRIDGE_URL تنظیم کړئ.",
                              "Set APPLE_CLIENT_ID and APPLE_CALLBACK_BRIDGE_URL."), parent=win)
                return

        try:
            win.attributes("-disabled", True)
        except Exception:
            pass
        def worker():
            try:
                profile = oauth.authenticate()
                self.after(0, lambda: self._finish_social_ui(profile, win, on_success))
            except Exception as exc:
                msg = str(exc) or "OAuth sign-in failed."
                self.after(0, lambda msg=msg: self._social_error_ui(msg, win))
        threading.Thread(target=worker, daemon=True).start()

    def _social_error_ui(self, msg, win):
        try: win.attributes("-disabled", False); win.lift()
        except Exception: pass
        messagebox.showerror(self._tr("ورود ناموفق", "ناکامه ننوتل", "Sign-in failed"), msg, parent=win)

    def _finish_social_ui(self, profile, win, on_success):
        try:
            row = self._social_user(profile)
            on_success(row, row[2])
        except Exception as exc:
            try: win.attributes("-disabled", False); win.lift()
            except Exception: pass
            messagebox.showerror(self._tr("خطای حساب", "د حساب تېروتنه", "Account error"), str(exc), parent=win)

    def ensure_login(self):
        users=self.db.execute("SELECT id,username,password_hash,full_name,active FROM users WHERE active=1 ORDER BY id").fetchall()
        if not users:
            self.create_first_user()
        else:
            self.login_window()

    def create_first_user(self):
        win=tk.Toplevel(self); win.title("ساخت حساب مدیر"); win.geometry("430x330"); win.configure(bg="#F4F6F8"); win.grab_set()
        RTLLabel(win,text="ساخت حساب ورود برنامه",bg="#F4F6F8",fg="#35a9ff",font=ui_font(17,"bold")).pack(pady=20)
        fields=[]
        for lab in ["نام کاربر","نام و تخلص","رمز عبور","تکرار رمز عبور"]:
            RTLLabel(win,text=lab,bg="#F4F6F8",fg="#1B2733",font=ui_font(10)).pack(anchor="e",padx=25,pady=(7,2))
            e=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",show="*" if "رمز" in lab else "")
            e.pack(fill="x",padx=25,ipady=6); fields.append(e)
        def save():
            u,n,p1,p2=[x.get().strip() for x in fields]
            if not u or not p1: messagebox.showwarning("حساب مدیر","نام کاربر و رمز عبور الزامی است."); return
            if len(p1) < 4: messagebox.showerror("حساب مدیر","رمز عبور نباید کمتر از ۴ کاراکتر باشد."); return
            if p1!=p2: messagebox.showerror("حساب مدیر","تکرار رمز عبور درست نیست."); return
            self.db.execute("INSERT INTO users(username,password_hash,full_name,created) VALUES(?,?,?,?)",(u,self.hash_password(p1),n,datetime.now().strftime("%Y-%m-%d %H:%M")))
            self.db.commit(); win.destroy()
            # Continue to the normal login screen; otherwise the hidden root
            # would remain invisible after creating the first account.
            self.after(50, self.login_window)
        self.button(win,"✓ ساخت حساب و ورود",save).pack(side="bottom",pady=18)

    def login_window(self):
        """Video-matched luxury login screen.

        The authentication logic remains unchanged, while the pre-login UI is
        rebuilt around the supplied reference video: deep navy gradient,
        floating glass card, husky PNG states, animated focus reaction,
        password eye control, glowing sign-in button and a short success
        animation before the main application is revealed.
        """
        self.withdraw()
        win = tk.Toplevel(self)
        win.title(APP_NAME + " - ورود")
        win.geometry("520x760")
        win.minsize(450, 650)
        win.configure(bg="#070B13")
        win.resizable(True, True)
        try:
            win.update_idletasks()
            sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
            ww, wh = 520, 760
            win.geometry(f"{ww}x{wh}+{max(0,(sw-ww)//2)}+{max(0,(sh-wh)//2)}")
        except Exception:
            pass
        try:
            win.transient(None)
            win.grab_set()
            win.attributes("-topmost", True)
        except Exception:
            pass

        canvas = tk.Canvas(win, bg="#0A111D", bd=0, highlightthickness=0)
        canvas.place(relx=0, rely=0, relwidth=1, relheight=1)
        # Real gradient painted inside the login canvas so the glass card and
        # mascot sit over the same deep navy background as the reference.
        grad_item = canvas.create_image(0, 0, anchor="nw")
        def redraw_login_gradient(_=None):
            try:
                w=max(2,canvas.winfo_width()); h=max(2,canvas.winfo_height())
                img=_make_gradient_image(w,h,["#07101E","#0D1727","#101827","#07101A"],False)
                canvas._login_gradient=img; canvas.itemconfigure(grad_item,image=img)
                canvas.tag_lower(grad_item)
            except Exception: pass
        canvas.bind("<Configure>", redraw_login_gradient, add="+")
        canvas.after(20, redraw_login_gradient)

        # --- geometry helpers -------------------------------------------------
        def rr(x1, y1, x2, y2, r, **kw):
            r = max(1, min(r, (x2-x1)/2, (y2-y1)/2))
            pts = [
                x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
                x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
                x1,y2, x1,y2-r, x1,y1+r, x1,y1
            ]
            return canvas.create_polygon(pts, smooth=True, splinesteps=24, **kw)

        card = {"x": 48, "y": 160, "w": 424, "h": 535}
        card_item = rr(card["x"], card["y"], card["x"]+card["w"], card["y"]+card["h"], 30,
                       fill="#111A29", outline="#42536B", width=1)
        # subtle inner glass highlight
        rr(card["x"]+1, card["y"]+1, card["x"]+card["w"]-1, card["y"]+card["h"]-1, 29,
           fill="", outline="#25364B", width=1)

        # --- husky PNGs extracted from the supplied reference video ----------
        asset_dir = os.path.join(RESOURCE_BASE, "assets", "login")
        husky_images = {}
        try:
            from PIL import ImageTk
            for key in ("normal", "cover", "blink"):
                path = os.path.join(asset_dir, f"husky_{key}.png")
                if os.path.exists(path):
                    im=Image.open(path).convert("RGBA"); im.thumbnail((150, 185), Image.Resampling.LANCZOS); husky_images[key] = ImageTk.PhotoImage(im)
        except Exception:
            for key in ("normal", "cover", "blink"):
                path = os.path.join(asset_dir, f"husky_{key}.png")
                if os.path.exists(path):
                    try: husky_images[key] = tk.PhotoImage(file=path)
                    except Exception: pass

        husky_state = {"name":"normal", "y":0, "phase":0.0, "job":None, "blink_job":None, "walking":False}
        husky_item = None
        if husky_images:
            husky_item = canvas.create_image(260, 210, image=husky_images.get("normal"), anchor="s")

        def set_husky(state, *, animate=True):
            if state not in husky_images or husky_state["walking"]:
                return
            husky_state["name"] = state
            if husky_item is not None:
                canvas.itemconfigure(husky_item, image=husky_images[state])
            if animate:
                base = husky_state["y"]
                for i in range(1, 7):
                    dy = int(round((1-i/6)*4))
                    canvas.after(i*22, lambda dy=dy: move_husky(0, dy))

        def move_husky(dx=0, dy=0):
            if husky_item is None or not canvas.winfo_exists(): return
            canvas.move(husky_item, dx, dy)
            husky_state["y"] += dy

        def idle_bob():
            if not canvas.winfo_exists() or husky_state["walking"]:
                return
            husky_state["phase"] += 0.16
            dy = int(round(__import__('math').sin(husky_state["phase"]) * 1.5))
            move_husky(0, dy)
            husky_state["job"] = canvas.after(70, idle_bob)
        idle_bob()

        def blink_cycle():
            # Natural, short blink: close the eyes briefly, then return smoothly
            # to the normal face. The blink asset itself contains truly closed
            # eyelids, so the eyes cannot remain visibly open during the blink.
            if not canvas.winfo_exists():
                return
            if husky_state["walking"] or husky_state["name"] == "cover":
                husky_state["blink_job"] = canvas.after(900, blink_cycle)
                return

            # Tiny anticipation + closed-eye hold makes the blink feel less
            # like a hard image swap.
            def close_eyes():
                if canvas.winfo_exists() and not husky_state["walking"] and husky_state["name"] != "cover":
                    set_husky("blink", animate=False)
                    canvas.after(115, open_eyes)

            def open_eyes():
                if canvas.winfo_exists() and not husky_state["walking"] and husky_state["name"] != "cover":
                    set_husky("normal", animate=False)
                    # Continue with a relaxed, non-mechanical interval.
                    husky_state["blink_job"] = canvas.after(2450, blink_cycle)

            canvas.after(45, close_eyes)

        husky_state["blink_job"] = canvas.after(2100, blink_cycle)

        # --- header -----------------------------------------------------------
        title = self._tr("نرم افزار حسابداری جهان", "د حسابدارۍ جهان سافټویر", "Jahan Accounting")
        subtitle = self._tr("خوش آمدید. مراقب رمز عبور شما هستم.", "ښه راغلاست. زه ستاسو د پټنوم ساتنه کوم.", "Welcome back. Your husky's keeping watch.")
        canvas.create_text(260, 222, text=title, fill="#79B9FF", font=ui_font(23, "bold"), anchor="center")
        canvas.create_text(260, 260, text=subtitle, fill="#9BA9BC", font=ui_font(11, "normal"), anchor="center")

        # --- field factory ----------------------------------------------------
        entries = {}
        field_items = {}
        field_y = {"user": 305, "pass": 384}
        labels = {
            "user": self._tr("نام کاربری", "د کارن نوم", "Username"),
            "pass": self._tr("رمز عبور", "پټنوم", "Password"),
        }

        def draw_field(kind, focused=False):
            y = field_y[kind]
            outline = "#70AFFF" if focused else "#33445B"
            if kind not in field_items:
                field_items[kind] = {
                    "box": rr(88, y, 432, y+58, 17, fill="#182333", outline=outline, width=2 if focused else 1),
                    "label": canvas.create_text(108, y+16, text=labels[kind], fill="#A7B6CA", font=ui_font(8, "normal"), anchor="w")
                }
            else:
                canvas.itemconfigure(field_items[kind]["box"], outline=outline, width=2 if focused else 1)
            if kind == "user":
                entries[kind].place(x=106, y=y+24, width=286, height=28)
            else:
                entries[kind].place(x=106, y=y+24, width=250, height=28)

        user_var = tk.StringVar()
        pass_var = tk.StringVar()
        u = tk.Entry(canvas, textvariable=user_var, bg="#182333", fg="#F4F7FB", insertbackground="#FFFFFF",
                     relief="flat", bd=0, highlightthickness=0, font=ui_font(11, "normal"), justify="left")
        p = tk.Entry(canvas, textvariable=pass_var, bg="#182333", fg="#F4F7FB", insertbackground="#FFFFFF",
                     relief="flat", bd=0, highlightthickness=0, font=ui_font(11, "normal"), justify="left", show="•")
        entries.update(user=u, pass_=p)
        # aliases used by event code
        entries["pass"] = p
        draw_field("user", False); draw_field("pass", False)

        showpw = tk.BooleanVar(value=False)
        eye_items = []
        def draw_eye():
            for item in eye_items:
                try: canvas.delete(item)
                except Exception: pass
            eye_items.clear()
            x, y = 405, 413
            eye_items.append(canvas.create_oval(x-10,y-6,x+10,y+6, outline="#9BA9BC", width=1))
            if showpw.get():
                eye_items.append(canvas.create_oval(x-3,y-3,x+3,y+3, fill="#9BA9BC", outline=""))
            else:
                eye_items.append(canvas.create_oval(x-2,y-2,x+2,y+2, fill="#9BA9BC", outline=""))
                eye_items.append(canvas.create_line(x-8,y+8,x+8,y-8, fill="#9BA9BC", width=1))
        draw_eye()
        canvas.tag_bind(eye_items[0], "<Button-1>", lambda e: toggle_pw())
        # A transparent hit target is easier to click than the thin eye outline.
        eye_hit = canvas.create_rectangle(386, 392, 425, 429, outline="", fill="")
        canvas.tag_bind(eye_hit, "<Button-1>", lambda e: toggle_pw())

        def toggle_pw():
            showpw.set(not showpw.get())
            p.configure(show="" if showpw.get() else "•")
            draw_eye()

        # redraw the fields on focus without rebuilding widgets
        def focus_user(_=None):
            draw_field("user", True); draw_field("pass", False); set_husky("normal")
        def focus_pass(_=None):
            draw_field("user", False); draw_field("pass", True); set_husky("cover")
        def blur_fields(_=None):
            focus = win.focus_get()
            draw_field("user", focus is u); draw_field("pass", focus is p)

        u.bind("<FocusIn>", focus_user); p.bind("<FocusIn>", focus_pass)
        u.bind("<FocusOut>", blur_fields); p.bind("<FocusOut>", blur_fields)

        # --- helper texts -----------------------------------------------------
        remember_var = tk.BooleanVar(value=False)
        remember = tk.Checkbutton(canvas, text=self._tr("مرا به خاطر بسپار", "ما په یاد وساته", "Remember me"), variable=remember_var,
                                  bg="#111A29", fg="#A7B1C0", activebackground="#111A29", activeforeground="#D6DEEA",
                                  selectcolor="#111A29", relief="flat", bd=0, highlightthickness=0,
                                  font=ui_font(9, "normal"), cursor="hand2")
        remember.place(x=88, y=452, height=32)
        forgot = tk.Label(canvas, text=self._tr("فراموشی رمز عبور؟", "پټنوم هېر شوی؟", "Forgot password?"),
                          bg="#111A29", fg="#A8C8F2", font=ui_font(9, "normal"), cursor="hand2")
        forgot.place(x=330, y=456)

        # --- primary button ---------------------------------------------------
        btn_bg = rr(88, 500, 432, 571, 18, fill="#1F73E8", outline="#6BA8FF", width=1)
        btn_glow = rr(84, 496, 436, 575, 20, fill="", outline="#1E5DBA", width=2)
        btn_text = canvas.create_text(120, 536, text=self._tr("ورود به برنامه", "پروګرام ته ننوتل", "Sign in"),
                                      fill="#FFFFFF", font=ui_font(13, "bold"), anchor="w")
        key_box = rr(377, 515, 419, 557, 10, fill="#BFE0FF", outline="#E4F1FF", width=1)
        key_text = canvas.create_text(398, 536, text="🔑", fill="#FFFFFF", font=("Segoe UI Emoji", 16), anchor="center")
        status = canvas.create_text(260, 594, text=self._tr("یا ادامه با", "یا له دې سره دوام ورکړئ", "or continue with"),
                                    fill="#8C99AA", font=ui_font(8, "normal"), anchor="center")
        canvas.create_line(88, 594, 225, 594, fill="#2A3545")
        canvas.create_line(295, 594, 432, 594, fill="#2A3545")

        # --- account footer ---------------------------------------------------
        # Google/Apple sign-in buttons have been removed completely from the
        # login UI. Local username/password authentication remains unchanged.
        canvas.create_text(260, 642, text=self._tr("کاربر جدید هستید؟ ساخت حساب", "نوی کارن یاست؟ حساب جوړ کړئ", "New to Jahan? Create account"),
                           fill="#9AA7B9", font=ui_font(9, "normal"), anchor="center")

        # --- button hover animation -----------------------------------------
        hover_state = {"on":False, "job":None}
        def glow_step(target_on):
            if not canvas.winfo_exists(): return
            hover_state["on"] = target_on
            target = "#2D82F2" if target_on else "#1F73E8"
            try: canvas.itemconfigure(btn_bg, fill=target)
            except Exception: pass
        for tag in (btn_bg, btn_text, key_box, key_text):
            canvas.tag_bind(tag, "<Enter>", lambda e: glow_step(True))
            canvas.tag_bind(tag, "<Leave>", lambda e: glow_step(False))

        # --- authentication + success animation ----------------------------
        def finish_success(row, new_hash):
            if row[2] != new_hash:
                self.db.execute("UPDATE users SET password_hash=? WHERE id=?", (new_hash, row[0])); self.db.commit()
            self.current_user=row[0]; self.current_username=row[1]
            husky_state["walking"] = True
            set_husky("blink", animate=False)
            canvas.itemconfigure(btn_text, text=self._tr("در حال ورود...", "د ننوتلو په حال کې...", "Signing you in..."))
            canvas.itemconfigure(status, text="")
            p.configure(state="disabled"); u.configure(state="disabled")
            # Tiny key-light pulse and a three-step husky exit, matching the
            # short walk-through cue in the supplied reference animation.
            def pulse(i=0):
                if not canvas.winfo_exists(): return
                shades=["#C8E7FF","#8FC7FF","#EAF6FF","#BFE0FF"]
                canvas.itemconfigure(key_box, fill=shades[i%len(shades)])
                if i<10: canvas.after(55, lambda: pulse(i+1))
            pulse()
            def walk(step=0):
                if not canvas.winfo_exists(): return
                if step < 18:
                    move_husky(0, 3)
                    canvas.after(22, lambda: walk(step+1))
                else:
                    canvas.after(180, reveal_main)
            walk()

        def reveal_main():
            try:
                win.grab_release(); win.destroy()
            except Exception: pass
            self._auth_phase=False
            try:
                self.withdraw(); self.overrideredirect(False); self.update_idletasks(); self.deiconify()
                self.update_idletasks(); _set_windows_app_identity(self.winfo_id()); self._set_app_icon()
            except Exception:
                self.deiconify(); _set_windows_app_identity(self.winfo_id())
            self.lift()
            try:
                self.attributes("-topmost", True); self.after(500, lambda: self.attributes("-topmost", False))
            except Exception: pass
            # Build the dashboard while the branded splash is visible.
            self._show_startup_splash(1800)
            self.build_ui(); self.dashboard(); self.start_sync_server()
            # One-time outgoing document profile: requested once on first successful startup.
            self.after(650, self._ensure_outgoing_profile_once)
            # Defer non-critical network work until after the first frame is
            # visible, so startup/login stays responsive.
            self.after(900, lambda: self.refresh_online_rates(silent=True))
            self.after(120, self._restore_normal_startup)
            self.after(350, lambda: (_set_windows_app_identity(self.winfo_id()), self._set_app_icon()))

        def do_login(event=None):
            username=self._normalize_username(u.get())
            password=p.get()
            row=self._find_login_user(username)
            if not row:
                messagebox.showerror(self._tr("ورود ناموفق","ناکامه ننوتل","Sign-in Failed"),
                                     self._tr("نام کاربری یا رمز عبور اشتباه است.","د کارن نوم یا پټنوم ناسم دی.","Incorrect username or password."), parent=win)
                return
            ok,new_hash=self._password_matches(row[2],password)
            if not ok:
                messagebox.showerror(self._tr("ورود ناموفق","ناکامه ننوتل","Sign-in Failed"),
                                     self._tr("نام کاربری یا رمز عبور اشتباه است.","د کارن نوم یا پټنوم ناسم دی.","Incorrect username or password."), parent=win)
                return
            finish_success(row,new_hash)

        for tag in (btn_bg, btn_text, key_box, key_text):
            canvas.tag_bind(tag, "<Button-1>", do_login)
        p.bind("<Return>", do_login)
        u.bind("<Return>", do_login)

        def reset_password():
            dlg=tk.Toplevel(win); dlg.title(self._tr("ریست رمز عبور / ساخت کاربر","د پټنوم بیا ټاکل / کارن جوړول","Reset password / Create user")); dlg.geometry("480x500"); dlg.minsize(440,470); dlg.configure(bg="#101B29"); dlg.transient(win); dlg.grab_set()
            outer=tk.Frame(dlg,bg="#101B29"); outer.pack(fill="both",expand=True,padx=22,pady=18); outer.grid_columnconfigure(0,weight=1); outer.grid_rowconfigure(1,weight=1)
            RTLLabel(outer,text="ریست رمز عبور یا ساخت کاربر جدید",bg="#101B29",fg="#F4EFE2",font=ui_font(14,"bold")).grid(row=0,column=0,sticky="ew",pady=(0,14))
            form=tk.Frame(outer,bg="#101B29"); form.grid(row=1,column=0,sticky="nsew"); form.grid_columnconfigure(0,weight=1)
            def field(row,label,show=False,initial=""):
                RTLLabel(form,text=label,bg="#101B29",fg="#F4EFE2",font=ui_font(9,"bold")).grid(row=row,column=0,sticky="e",pady=(4,2))
                e=tk.Entry(form,bg="#182437",fg="#F4EFE2",insertbackground="#F4EFE2",relief="solid",bd=1,highlightthickness=1,highlightbackground="#2E4055",highlightcolor="#E4C077",font=ui_font(10),justify="right",show="*" if show else "")
                e.grid(row=row+1,column=0,sticky="ew",ipady=8,pady=(0,5))
                if initial: e.insert(0,initial)
                return e
            ru=field(0,"نام کاربری",False,u.get().strip()); rn=field(2,"نام و تخلص (برای کاربر جدید اختیاری است)"); rp1=field(4,"رمز عبور جدید",True); rp2=field(6,"تکرار رمز عبور جدید",True)
            footer=tk.Frame(outer,bg="#101B29"); footer.grid(row=2,column=0,sticky="ew",pady=(12,0)); footer.grid_columnconfigure(0,weight=1)
            save_btn=self.button(footer,"✓ ذخیره / ساخت کاربر",None); save_btn.grid(row=0,column=0,sticky="ew",ipady=4)
            RTLLabel(footer,text="رمز عبور باید حداقل ۴ کاراکتر باشد.",bg="#101B29",fg="#9FB0C4",font=ui_font(8)).grid(row=1,column=0,pady=(7,0))
            def apply_reset():
                username=ru.get().strip(); full_name=rn.get().strip(); new1=rp1.get(); new2=rp2.get()
                if not username or not new1: messagebox.showwarning("حساب کاربری","نام کاربری و رمز عبور را وارد کنید.",parent=dlg); return
                if len(new1)<4: messagebox.showerror("حساب کاربری","رمز عبور نباید کمتر از ۴ کاراکتر باشد.",parent=dlg); rp1.focus_set(); return
                if new1!=new2: messagebox.showerror("حساب کاربری","تکرار رمز عبور درست نیست.",parent=dlg); rp2.focus_set(); return
                row=self._find_login_user(username)
                if row:
                    self.db.execute("UPDATE users SET password_hash=?, full_name=?, active=1 WHERE id=?",(self.hash_password(new1),full_name,row[0])); msg="رمز عبور کاربر با موفقیت تغییر کرد."
                else:
                    self.db.execute("INSERT INTO users(username,password_hash,full_name,active,created) VALUES(?,?,?,?,?)",(username,self.hash_password(new1),full_name,1,datetime.now().strftime("%Y-%m-%d %H:%M"))); msg="کاربر جدید با موفقیت ساخته شد."
                self.db.commit(); messagebox.showinfo("موفق",msg,parent=dlg); dlg.destroy(); p.focus_set()
            save_btn.configure(command=apply_reset); rp2.bind("<Return>",lambda e: apply_reset())

        forgot.bind("<Button-1>", lambda e: reset_password())
        win.protocol("WM_DELETE_WINDOW", self.destroy)
        win.lift(); win.focus_force()
        u.focus_set()

    def style(self):
        s = ttk.Style(self)
        try: s.theme_use("clam")
        except: pass
        # Base styles are light; _apply_theme() switches these at runtime.
        s.configure("Treeview", background="#FFFFFF", foreground="#1B2733",
                    fieldbackground="#FFFFFF", rowheight=32, borderwidth=0,
                    font=ui_font(10))
        s.configure("Treeview.Heading", background="#B58E45", foreground="#ffffff",
                    font=ui_font(10,"bold"), relief="flat", padding=8)
        s.configure("Jahan.Accounts.Treeview", background="#FFFFFF", foreground="#1B2733",
                    fieldbackground="#FFFFFF", rowheight=44, borderwidth=0,
                    font=ui_font(12,"bold"))
        s.configure("Jahan.Accounts.Treeview.Heading", background="#B58E45", foreground="#ffffff",
                    font=ui_font(12,"bold"), relief="flat", padding=10)
        s.configure("TCombobox", fieldbackground="#FFFFFF", background="#FFFFFF",
                    foreground="#1B2733", arrowcolor="#B58E45")
        s.map("Treeview", background=[("selected","#E9D8AD")],
              foreground=[("selected","#1B2733")])
        s.map("Jahan.Accounts.Treeview", background=[("selected","#E9D8AD")],
              foreground=[("selected","#1B2733")])

    def _apply_ttk_theme(self, dark, panel, ink, accent, hover, border):
        """Apply theme to ttk widgets, which cannot be recolored with tk.configure."""
        try:
            s=ttk.Style(self)
            selected = hover if dark else "#E9D8AD"
            selected_fg = "#FFFFFF" if dark else "#1B2733"
            s.configure("Treeview", background=panel, foreground=ink, fieldbackground=panel,
                        rowheight=32, borderwidth=0)
            s.configure("Treeview.Heading", background=accent,
                        foreground=("#241B0C" if dark else "#FFFFFF"), borderwidth=0)
            s.configure("Jahan.Treeview", background=panel, foreground=ink, fieldbackground=panel)
            s.configure("Jahan.Treeview.Heading", background=accent,
                        foreground=("#241B0C" if dark else "#FFFFFF"))
            s.configure("Jahan.Accounts.Treeview", background=panel, foreground=ink, fieldbackground=panel)
            s.configure("Jahan.Accounts.Treeview.Heading", background=accent,
                        foreground=("#241B0C" if dark else "#FFFFFF"))
            s.configure("TCombobox", fieldbackground=panel, background=panel, foreground=ink,
                        arrowcolor=accent, bordercolor=border, lightcolor=border, darkcolor=border)
            s.map("Treeview", background=[("selected", selected)], foreground=[("selected", selected_fg)])
            s.map("Jahan.Accounts.Treeview", background=[("selected", selected)], foreground=[("selected", selected_fg)])
            s.map("TCombobox", fieldbackground=[("readonly",panel)], foreground=[("readonly",ink)])
        except Exception:
            pass

    def _prepare_toplevel(self, win, min_width=420, min_height=320):
        """Keep dialogs fully inside the usable screen area and resizable."""
        try:
            win.update_idletasks()
            sw=max(800,int(win.winfo_screenwidth())); sh=max(600,int(win.winfo_screenheight()))
            usable_w=max(520,sw-40); usable_h=max(420,sh-90)
            raw=win.geometry().split("+",1)[0]; parts=raw.lower().split("x")
            rw=int(parts[0]) if len(parts)==2 and parts[0].isdigit() else min_width
            rh=int(parts[1]) if len(parts)==2 and parts[1].isdigit() else min_height
            w=max(min_width,min(rw,usable_w)); h=max(min_height,min(rh,usable_h))
            if w>=usable_w and h>=usable_h:
                try: win.state("zoomed")
                except Exception: win.geometry(f"{w}x{h}+20+20")
            else:
                x=max(0,(sw-w)//2); y=max(0,(sh-h)//2)
                win.geometry(f"{w}x{h}+{x}+{y}")
            win.minsize(min(min_width,usable_w),min(min_height,usable_h)); win.resizable(True,True)
            win.bind("<Escape>",lambda e:win.destroy(),add="+")
            win.update_idletasks()
        except Exception:
            pass

    def _fit_toplevel_to_screen(self, win):
        """Clamp every dialog to the usable screen area (important for 1366x768)."""
        try:
            if not win.winfo_exists(): return
            sw=max(800,int(win.winfo_screenwidth())); sh=max(600,int(win.winfo_screenheight()))
            # Reserve space for Windows taskbar and the custom application chrome.
            usable_w=max(520,sw-24); usable_h=max(430,sh-72)
            win.update_idletasks()
            geom=win.geometry().split('+',1)[0].lower().split('x')
            if len(geom)!=2: return
            w=max(360,int(geom[0])); h=max(260,int(geom[1]))
            nw=min(w,usable_w); nh=min(h,usable_h)
            if (nw,nh)!=(w,h):
                x=max(0,(sw-nw)//2); y=max(0,(sh-nh)//2)
                win.geometry(f"{nw}x{nh}+{x}+{y}")
                try: win.minsize(min(int(win.minsize()[0]),nw),min(int(win.minsize()[1]),nh))
                except Exception: pass
            # Keep dialogs centered after a resize.
            win.update_idletasks()
        except Exception:
            pass

    def _on_any_window_map(self,event):
        try:
            if isinstance(event.widget,tk.Toplevel):
                self.after_idle(lambda w=event.widget:self._fit_toplevel_to_screen(w))
        except Exception:
            pass

    def _pack_with_scrollbar(self, widget, **pack_kwargs):
        """Pack a long Treeview/Listbox with a visible vertical scrollbar."""
        try:
            parent=widget.master
            bar=tk.Scrollbar(parent,orient="vertical",command=widget.yview,width=14)
            bar.pack(side="right",fill="y",padx=(0,2),pady=pack_kwargs.get("pady",0) if isinstance(pack_kwargs.get("pady",0),int) else 0)
            widget.configure(yscrollcommand=bar.set)
            widget.pack(**pack_kwargs)
            widget.bind("<MouseWheel>",lambda e,w=widget:w.yview_scroll(int(-e.delta/120) or (-1 if e.delta>0 else 1),"units"),add="+")
            widget.bind("<Button-4>",lambda e,w=widget:w.yview_scroll(-1,"units"),add="+")
            widget.bind("<Button-5>",lambda e,w=widget:w.yview_scroll(1,"units"),add="+")
            return bar
        except Exception:
            widget.pack(**pack_kwargs)
            return None

    def _load_ui_icons(self):
        # Lightweight PNG icons: no extra runtime dependency; kept as PhotoImage references.
        self.ui_icons = {}
        icon_dir = os.path.join(RESOURCE_BASE, "assets", "icons")
        if not os.path.isdir(icon_dir):
            icon_dir = os.path.join(BASE, "assets", "icons")
        for name in ("dashboard","customers","transactions","accounts","receipts","remittance","reports","invoice","shops","web","backup","settings","about","search","add","delete","save","back","print","whatsapp","telegram","refresh","open","convert","update","license","dark","folder","shoe"):
            path = os.path.join(icon_dir, name + ".png")
            if os.path.exists(path):
                try:
                    img = tk.PhotoImage(file=path)
                    # Keep the original graphical icons, but make them compact enough for the sidebar.
                    w, h = img.width(), img.height()
                    if max(w, h) > 20:
                        factor = max(1, int(max(w, h) / 20))
                        img = img.subsample(factor, factor)
                    self.ui_icons[name] = img
                except Exception: pass

    def _icon_for_text(self, text):
        t = str(text)
        rules = [
            (("داشبورد","Dashboard","ډشبورډ"),"dashboard"), (("مشتری","Customers","پیرودونکي"),"customers"),
            (("معامل","Transactions","معاملې"),"transactions"), (("حساب","Accounts","حسابونه"),"accounts"),
            (("رسید","Receipts","رسیدونه"),"receipts"), (("حواله","Remittance"),"remittance"),
            (("گزارش","Reports","راپور"),"reports"), (("فاکتور","Invoice"),"invoice"),
            (("مغازه","فروشگاه","Shops","دوکان","دکان"),"shops"), ( ("کفش","Shoes"),"shoe"), (("کتابچه","یادداشت"),"about"), (("ارز","وب","Rates"),"web"),
            (("پشتیبان","Backup","بیکاپ"),"backup"), (("تنظیمات","Settings","امستنې"),"settings"),
            (("درباره","About","په اړه"),"about"), (("جستجو","نمایش","Search"),"search"),
            (("مشتری جدید","فروش جدید","ثبت","افزودن","ذخیره","Save","فعال‌سازی"),"add"),
            (("حذف","Delete"),"delete"), (("بازگشت","برگشت","Back"),"back"), (("چاپ","Print"),"print"),
            (("واتساپ","WhatsApp"),"whatsapp"), (("تلگرام","Telegram"),"telegram"),
            (("بروزرسانی","Refresh","↻"),"refresh"), (("بازکردن","Open","فایل اطلاعات"),"open"),
            (("تبدیل","Convert"),"convert"), (("آپدیت","Update","دریافت"),"update"),
            (("سریال","License","رمز عبور"),"license"), (("دارک","Dark"),"dark"), (("پوشه","Folder"),"folder")
        ]
        for words, icon in rules:
            if any(w in t for w in words): return self.ui_icons.get(icon)
        return None

    def button(self, parent, text, command, color=None):
        # Professional icon button used across the whole app: a refined
        # surface with a dedicated graphic icon and a smooth gold hover glow.
        display_text = str(text)
        dark = getattr(self, "dark_mode", False)
        base = "#121B29" if dark else "#FFFFFF"
        fg = "#E4C077" if dark else "#B58E45"
        hover = "#1C2A3D" if dark else "#F8F1DF"
        hover_fg = "#FFFFFF" if dark else "#8F6A2E"
        border = "#2E4055" if dark else "#D8DEE4"
        btn=RTLButton(parent, text=display_text, image=self._icon_for_text(text), compound="left", command=command,
                      bg=base, fg=fg, activebackground=hover, activeforeground=hover_fg,
                      relief="flat", bd=0, highlightthickness=1, highlightbackground=border,
                      highlightcolor="#C9A45C", font=ui_font(11,"bold"), padx=10, pady=7,
                      cursor="hand2", anchor="center", justify="center")
        bind_smooth_hover(btn, base, hover, fg, hover_fg)
        return btn

    def _apply_ui_mode(self):
        """Apply a genuinely different navigation mode. Simple hides secondary tools; Pro shows everything."""
        # Keep the everyday workflow short and predictable in Simple mode.
        simple_keywords=("داشبورد","مشتریان","حسابات مشتریان","حسابات و رسیدها","کتابچه","گزارش‌ها","بارها","دکان‌ها","راهنمای برنامه","تنظیمات")
        try:
            for btn in getattr(self,"nav_label_buttons",[]):
                txt=str(btn.cget("text")).replace("\u200f","")
                show=(self.ui_mode=="pro") or any(k in txt for k in simple_keywords)
                if show: btn.pack(fill="x",padx=6,pady=2)
                else: btn.pack_forget()
            if hasattr(self,"shops_button"):
                self.shops_button.pack(fill="x",padx=6,pady=2)
            # In Simple mode keep only the first-level shop button; its sub-items remain hidden.
            if hasattr(self,"shop_submenu"):
                if self.ui_mode=="simple":
                    self.shop_submenu.pack_forget()
                    self.shops_expanded=False
                    if hasattr(self,"shops_button"):
                        self.shops_button.config(text="\u200f▸  دکان‌ها")
                elif getattr(self,"shops_expanded",False):
                    self.shop_submenu.pack(fill="x",before=self._shop_spacer)
            if hasattr(self,"mode_btn"):
                self.mode_btn.config(text=("🔵 رفتن به حالت حرفه‌ای" if self.ui_mode=="simple" else "🟢 رفتن به حالت ساده"))
            if hasattr(self,"nav_title"):
                self.nav_title.config(text=("منوی اصلی • ساده" if self.ui_mode=="simple" else "منوی اصلی • حرفه‌ای"))
            if hasattr(self,"main"):
                self.main.update_idletasks()
            if hasattr(self,"main_canvas"):
                self.main_canvas.yview_moveto(0)
        except Exception:
            pass

    def toggle_ui_mode(self):
        self.ui_mode="pro" if getattr(self,"ui_mode","simple")=="simple" else "simple"
        try:
            self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('ui_mode',?)",(self.ui_mode,))
            self.db.commit()
        except Exception:
            pass
        self._apply_ui_mode()

    def _show_file_menu(self):
        menu=tk.Menu(self,tearoff=0,bg="#121B29",fg="#E4C077",activebackground="#26374A",
                     activeforeground="#FFFFFF",font=ui_font(10),borderwidth=1)
        menu.add_command(label="📂  باز کردن فایل KRW",command=self.open_krw)
        menu.add_command(label="💾  ذخیره فایل KRW",command=self.quick_krw_save)
        menu.add_separator()
        menu.add_command(label="▰  پشتیبان‌گیری و بازیابی",command=self.backup_page)
        try:
            menu.tk_popup(self.file_menu_btn.winfo_rootx(),self.file_menu_btn.winfo_rooty()+self.file_menu_btn.winfo_height())
        finally:
            menu.grab_release()

    def _tr(self, fa, ps=None, en=None):
        texts={"fa":fa, "ps":ps if ps is not None else fa, "en":en if en is not None else fa}
        return texts.get(self.current_language, fa)

    def _set_ui_direction(self, root=None):
        """Apply consistent RTL/LTR alignment to all UI controls."""
        root = root or self
        rtl = self.current_language in ("fa", "ps")
        anchor = "e" if rtl else "w"
        justify = "right" if rtl else "left"
        def walk(w):
            try:
                if isinstance(w, (tk.Label, tk.Button)):
                    w.configure(anchor=anchor, justify=justify)
                elif isinstance(w, tk.Entry):
                    w.configure(justify=justify)
                elif isinstance(w, ttk.Combobox):
                    w.configure(justify=justify)
            except Exception:
                pass
            for child in w.winfo_children():
                walk(child)
        try:
            walk(root)
        except Exception:
            pass

    def _apply_language(self, code):
        global CURRENT_UI_LANGUAGE
        code = code if code in ("fa", "ps", "en") else "fa"
        self.current_language = code
        CURRENT_UI_LANGUAGE = code
        self._refresh_shell_texts()
        self._refresh_all_visible_texts()
        self._set_ui_direction()

    def _refresh_all_visible_texts(self):
        """Translate the current page in-place without touching database values."""
        def walk(w):
            try:
                if isinstance(w, (tk.Label, tk.Button)) and hasattr(w, "_jahan_original_text"):
                    w.config(text=_display_text(w._jahan_original_text))
                elif isinstance(w, ttk.Treeview):
                    headings = getattr(w, "_jahan_original_headings", None)
                    if headings:
                        for col, txt in headings.items():
                            w.heading(col, text=_display_text(txt))
            except Exception:
                pass
            for child in w.winfo_children():
                walk(child)
        try:
            walk(self)
            self._set_ui_direction()
        except Exception:
            pass

    def _refresh_shell_texts(self):
        if hasattr(self, "lang_label"):
            self.lang_label.config(text=self._tr("زبان", "ژبه", "Language"))
        if hasattr(self, "support_label"):
            self.support_label.config(text=self._tr("پشتیبانی و تماس", "ملاتړ او اړیکه", "Support & Contact"))
        if hasattr(self, "version_label"):
            self.version_label.config(text=self._tr("نسخه ۱۷.۰  •  سیستم حسابداری جهان", "نسخه ۱۷.۰  •  مسلکي محاسبوي سیستم", "Version 17.0  •  Jahan Accounting"))
        if hasattr(self, "nav_title"):
            self.nav_title.config(text=self._tr("منوی اصلی", "اصلي مینو", "Main Menu"))
        if hasattr(self, "nav_label_buttons"):
            labels=[
                ("⌂  داشبورد", "⌂  ډشبورډ", "⌂  Dashboard"),
                ("♙  مشتریان", "♙  پیرودونکي", "♙  Customers"),
                ("↔  معاملات", "↔  معاملې", "↔  Transactions"),
                ("▤  حسابات و رسیدها", "▤  حسابونه او رسیدونه", "▤  Accounts & Receipts"),
                ("↗  حواله", "↗  حواله", "↗  Remittance"),
                ("🚚  بارها", "🚚  بارونه", "🚚  Shipments"),
                ("▥  گزارش‌ها", "▥  راپورونه", "▥  Reports"),
                ("◈  فاکتور", "◈  فاکتور", "◈  Invoice"),
                ("◎  ارز و وب", "◎  اسعار او ویب", "◎  Rates & Web"),
                ("🤖  هوش مصنوعی", "🤖  هوښیار", "🤖  AI Assistant"),
                ("▰  پشتیبان‌گیری", "▰  بیکاپ", "▰  Backup"),
                ("🔄  همگام‌سازی Android", "🔄  همغږي Android", "🔄  Android Sync"),
                ("⚙  تنظیمات", "⚙  امستنې", "⚙  Settings"),
                ("ⓘ  درباره", "ⓘ  په اړه", "ⓘ  About")]
            for btn, vals in zip(self.nav_label_buttons, labels):
                label = {"fa":vals[0],"ps":vals[1],"en":vals[2]}.get(self.current_language, vals[0])
                btn.config(text="\u200f" + str(label))
        if hasattr(self, "shops_button"):
            vals=("▦  دکان‌ها", "▦  دوکانونه", "▦  Shops")
            label={"fa":vals[0],"ps":vals[1],"en":vals[2]}.get(self.current_language, vals[0])
            self.shops_button.config(text="\u200f"+label)
        if hasattr(self, "shop_label_buttons"):
            shop_labels=[
                ("🏪  مرکز یکپارچه دوکان‌ها", "🏪  د دوکانونو یوځای مرکز", "🏪  Unified Shop Center"),
                ("🧾  فاکتورهای همه دوکان‌ها", "🧾  د ټولو دوکانونو رسیدونه", "🧾  All Shop Invoices"),
                ("📦  انبار میوه و سبزی", "📦  د مېوو او سبزیو ګدام", "📦  Produce Warehouse")]
            for btn, vals in zip(self.shop_label_buttons, shop_labels):
                label={"fa":vals[0],"ps":vals[1],"en":vals[2]}.get(self.current_language, vals[0])
                btn.config(text="\u200f"+label)
        if hasattr(self, "brand_title"):
            self.brand_title.config(text=self._tr("نرم افزار حسابداری جهان", "د جهان محاسبوي سافټویر", "Jahan Accounting Software"))

    def build_ui(self):
        # Professional V16 shell with a fully custom title bar, visible dual-date strip, and the supplied World Game logo.
        self._load_ui_icons()
        top=tk.Frame(self,bg="#0E1622",height=88,bd=0,highlightthickness=0)
        top.pack(fill="x")
        top.pack_propagate(False)
        top.configure(bg="#0A0F16")
        self._no_retheme.add(top)

        # تاریخ همیشه در یک نوار مستقل و واضح بالای برنامه دیده می‌شود.
        # این نوار عمداً از بخش برند جداست تا در نمایشگرهای کوچک بریده نشود.
        datebar=tk.Frame(self,bg="#0B141F",height=1,bd=0,highlightthickness=0)
        datebar.pack(fill="x", after=top)
        datebar.pack_propagate(False)
        datebar.configure(bg="#0E1622")
        self._no_retheme.add(datebar)

        brand=tk.Frame(top,bg="#0A0F16")
        brand.pack(side="left",fill="y",padx=18)
        try:
            logo_path=os.path.join(RESOURCE_BASE,"logo.png")
            if not os.path.exists(logo_path): logo_path=os.path.join(BASE,"logo.png")
            # Keep the source logo at full resolution, but render a compact header copy.
            # The previous 1254x1254 image was displayed at native size on some Windows
            # setups and could swallow most of the top bar.
            if 'ImageTk' in globals() and ImageTk:
                _im=Image.open(logo_path).convert('RGBA')
                _im.thumbnail((52,52), Image.LANCZOS)
                self.logo_img=ImageTk.PhotoImage(_im)
            else:
                self.logo_img=tk.PhotoImage(file=logo_path)
            RTLLabel(brand,image=self.logo_img,bg="#0A0F16").pack(side="left",padx=(0,10),pady=16)
        except Exception:
            RTLLabel(brand,text="WG",bg="#0A0F16",fg="#35a9ff",font=ui_font(20,"bold")).pack(side="left",padx=8)
        btxt=tk.Frame(brand,bg="#0A0F16")
        btxt.pack(side="left",anchor="center")
        self.brand_title=RTLLabel(btxt,text=APP_NAME,bg="#0A0F16",fg="#E4C077",
                 font=ui_font(17,"bold")); self.brand_title.pack(anchor="w")
        self.version_label=RTLLabel(btxt,text="نسخه ۱۷.۰  •  مدیریت یکپارچه حساب، مشتری، دکان و انبار • تاریخ شمسی/میلادی",bg="#0A0F16",fg="#9FB0C4",
                 font=ui_font(9)); self.version_label.pack(anchor="w",pady=(2,0))

        info=tk.Frame(top,bg="#0E1622")
        info.pack(side="right",fill="y",padx=20)
        self.support_label=RTLLabel(info,text="پشتیبانی و تماس",bg="#0E1622",fg="#9FB0C4",
                 font=ui_font(9)); self.support_label.pack(anchor="e",pady=(6,0))
        RTLLabel(info,text="۰۷۹۶۲۹۷۹۹۶  ☎",bg="#0E1622",fg="#E4C077",
                 font=ui_font(12,"bold")).pack(anchor="e")
        self.jalali_label=RTLLabel(info,bg="#0E1622",fg="#E4C077",font=ui_font(10,"bold"))
        self.jalali_label.pack(anchor="e",pady=(2,0))
        self.clock_label=RTLLabel(info,bg="#0E1622",fg="#9FB0C4",font=ui_font(9))
        self.clock_label.pack(anchor="e",pady=(1,0))
        self.update_clock()

        # Theme toggle sits below the main header; window controls remain native Windows controls.
        themebar=tk.Frame(self,bg="#0E1622",height=38,bd=0,highlightthickness=0)
        themebar.pack(fill="x", before=datebar)
        themebar.pack_propagate(False)
        self._no_retheme.add(themebar)
        self.dark_btn=RTLButton(themebar,text="☾ حالت دارک",command=self._toggle_dark_mode,
                                bg="#0E1622",fg="#E4C077",activebackground="#1C2A3D",
                                activeforeground="#FFFFFF",relief="flat",bd=0,font=ui_font(9,"bold"),
                                cursor="hand2",padx=10)
        self.dark_btn.pack(side="right",padx=14,pady=4)
        bind_smooth_hover(self.dark_btn, "#0E1622", "#1C2A3D", "#E4C077", "#FFFFFF")

        # Professional File menu, similar to desktop office applications.
        self.mode_btn=RTLButton(themebar,text="🟢 حالت ساده",command=self.toggle_ui_mode,
                                bg="#0E1622",fg="#E4C077",activebackground="#1C2A3D",
                                activeforeground="#FFFFFF",relief="flat",bd=0,font=ui_font(9,"bold"),
                                cursor="hand2",padx=10)
        self.mode_btn.pack(side="right",padx=(0,6),pady=4)
        bind_smooth_hover(self.mode_btn,"#0E1622","#1C2A3D","#E4C077","#FFFFFF")

        # دسترسی سریع و همیشه‌قابل‌مشاهده به کتابچه یادداشت
        self.notebook_top_btn=RTLButton(themebar,text="📖  کتابچه",command=self.notebook_page,
                                        bg="#0E1622",fg="#E4C077",activebackground="#1C2A3D",
                                        activeforeground="#FFFFFF",relief="flat",bd=0,font=ui_font(9,"bold"),
                                        cursor="hand2",padx=12)
        self.notebook_top_btn.pack(side="right",padx=(0,6),pady=4)
        bind_smooth_hover(self.notebook_top_btn,"#0E1622","#1C2A3D","#E4C077","#FFFFFF")

        self.file_menu_btn=RTLButton(themebar,text="▣  فایل",command=self._show_file_menu,
                                     bg="#0E1622",fg="#E4C077",activebackground="#1C2A3D",
                                     activeforeground="#FFFFFF",relief="flat",bd=0,font=ui_font(9,"bold"),
                                     cursor="hand2",padx=10)
        self.file_menu_btn.pack(side="right",padx=(0,6),pady=4)
        bind_smooth_hover(self.file_menu_btn,"#0E1622","#1C2A3D","#E4C077","#FFFFFF")
        self.bind_all("<Control-o>", lambda e:self.open_krw())
        self.bind_all("<Control-s>", lambda e:self.quick_krw_save())

        # Scrollable navigation: the full menu, including shop sub-items, remains reachable on smaller screens.
        NAVBG="#0E1622"; NAVCARD="#121B29"; NAVHOVER="#1C2A3D"; NAVGOLD="#E4C077"; NAVGOLDDIM="#B58E45"
        nav_shell=tk.Frame(self,bg=NAVBG,width=205,bd=0,highlightthickness=0)
        nav_shell.pack(side="right",fill="y")
        nav_shell.pack_propagate(False)
        # Slim luxury gradient seam between the sidebar and the workspace.
        divider=tk.Canvas(self,width=4,bd=0,highlightthickness=0)
        divider.pack(side="right",fill="y")
        divider.configure(bg="#26374A")
        self._no_retheme.add(divider)
        nav_canvas=tk.Canvas(nav_shell,bg=NAVBG,highlightthickness=0,bd=0)
        nav_scrollbar=tk.Scrollbar(nav_shell,orient="vertical",command=nav_canvas.yview,width=11,
                                   bg="#26374A",activebackground=NAVGOLDDIM,troughcolor="#0E1622")
        nav_canvas.configure(yscrollcommand=nav_scrollbar.set)
        nav_scrollbar.pack(side="right",fill="y")
        nav_canvas.pack(side="left",fill="both",expand=True)
        nav=tk.Frame(nav_canvas,bg=NAVBG)
        nav_window=nav_canvas.create_window((0,0),window=nav,anchor="nw",width=192)
        nav.bind("<Configure>",lambda e:nav_canvas.configure(scrollregion=nav_canvas.bbox("all")))
        nav_canvas.bind("<Configure>",lambda e:nav_canvas.itemconfigure(nav_window,width=max(1,e.width)))
        nav_canvas.bind("<Enter>",lambda e:self.bind_all("<MouseWheel>",lambda ev:self._nav_wheel(ev,nav_canvas)))
        nav_canvas.bind("<Leave>",lambda e:self.bind_all("<MouseWheel>",self._on_mousewheel))
        self.nav_title=RTLLabel(nav,text="منوی اصلی",bg=NAVBG,fg=NAVGOLD,
                 font=ui_font(10,"bold")); self.nav_title.pack(fill="x",padx=12,pady=(7,4))
        # منوی مرتب و دسته‌بندی‌شده: دکان‌ها یک زیرمنوی واقعیِ جمع‌شونده است.
        self.nav_buttons=[]
        self.nav_label_buttons=[]
        self.shop_label_buttons=[]

        def menu_section(parent, text):
            lbl=RTLLabel(parent,text=text,bg=NAVBG,fg="#7C8CA0",font=ui_font(9,"bold"),anchor="e",justify="right")
            lbl.pack(fill="x",padx=12,pady=(8,3))
            return lbl

        def make_nav_button(parent, text, command, icon_text=None):
            btn=RTLButton(parent,text="\u200f"+text,image=self._icon_for_text(icon_text or text),compound="left",
                          command=command,bg=NAVCARD,fg=NAVGOLD,activebackground=NAVHOVER,activeforeground="#FFFFFF",
                          relief="flat",bd=0,highlightthickness=1,highlightbackground="#26374A",
                          font=ui_font(11,"bold"),padx=8,pady=6,cursor="hand2",anchor="center",justify="center")
            bind_smooth_hover(btn, NAVCARD, NAVHOVER, NAVGOLD, "#FFFFFF")
            btn.pack(fill="x",padx=6,pady=2)
            self.nav_buttons.append(btn)
            return btn

        # عملیات اصلی
        menu_section(nav,"عملیات اصلی")
        main_items=[
            ("⌂  داشبورد",self.dashboard),("♙  مشتریان",self.customers_page),
            ("↔  معاملات",self.transaction_page),("▤  حسابات مشتریان",self.accounts_page),("▤  حسابات و رسیدها",self.customer_finance_center_page),
            ("📖  کتابچه یادداشت",self.notebook_page),
            ("↗  حواله",self.remittances_page),
            ("🚚  بارها",self.bars_page),
            ("▥  گزارش‌ها",self.reports_page)]
        for txt,cmd in main_items:
            self.nav_label_buttons.append(make_nav_button(nav,txt,cmd))

        # دکان‌ها و فروشگاه‌ها
        menu_section(nav,"دکان‌ها و فروشگاه‌ها")
        def toggle_shops():
            expanded=bool(getattr(self,"shops_expanded",False))
            if expanded:
                self.shop_submenu.pack_forget()
                self.shops_expanded=False
                self.shops_button.config(text="\u200f▸  دکان‌ها")
            else:
                self.shop_submenu.pack(fill="x",before=self._shop_spacer)
                self.shops_expanded=True
                self.shops_button.config(text="\u200f▾  دکان‌ها")
            try:
                nav.update_idletasks()
                nav_canvas.configure(scrollregion=nav_canvas.bbox("all"))
            except Exception:
                pass

        self.shops_button=make_nav_button(nav,"▾  دکان‌ها",toggle_shops,"دکان‌ها")
        self.shop_submenu=tk.Frame(nav,bg="#0B1420")
        self._shop_spacer=tk.Frame(nav,bg=NAVBG,height=1)
        shop_items=[
            ("مرکز یکپارچه دکان‌ها",self.businesses_page),
            ("🧾 مرکز کامل فاکتورها",self.shops_invoice_center_page),
            ("انبار میوه و سبزی",self.fruits_page)]
        for txt,cmd in shop_items:
            btn=RTLButton(self.shop_submenu,text="\u200f"+txt,image=self._icon_for_text(txt),compound="left",command=cmd,
                          bg="#0B1420",fg="#9FB0C4",activebackground=NAVHOVER,activeforeground=NAVGOLD,
                          relief="flat",bd=0,font=ui_font(10,"bold"),padx=14,pady=5,cursor="hand2",anchor="center",justify="center")
            bind_smooth_hover(btn, "#0B1420", NAVHOVER, "#9FB0C4", NAVGOLD)
            btn.pack(fill="x",padx=10,pady=1)
            self.shop_label_buttons.append(btn)
            self.nav_buttons.append(btn)
        self._shop_spacer.pack(fill="x",padx=14,pady=6)
        self.shops_expanded=True
        self.shop_submenu.pack(fill="x",before=self._shop_spacer)

        # ابزار و پشتیبان‌گیری
        menu_section(nav,"ابزار و پشتیبان‌گیری")
        tool_items=[
            ("◎  ارز و وب",self.online_page),("⇄  تبدیل ارز آنلاین",self.currency_converter_page),
            ("دستیار حسابداری",self.ai_assistant_page),
            ("▰  پشتیبان‌گیری",self.backup_page),("🔄  همگام‌سازی Android",self.sync_page)]
        for txt,cmd in tool_items:
            self.nav_label_buttons.append(make_nav_button(nav,txt,cmd))

        # سیستم: تنظیمات و درباره همیشه در انتهای منو
        menu_section(nav,"سیستم")
        self.nav_label_buttons.append(make_nav_button(nav,"⚙  تنظیمات",self.settings_page))
        self.nav_label_buttons.append(make_nav_button(nav,"ⓘ  درباره",self.about_page))
        # Keep the help item at the bottom of the navigation.
        self._help_bottom_spacer=tk.Frame(nav,bg=NAVBG,height=10)
        self._help_bottom_spacer.pack(fill="x",expand=True)
        self.nav_label_buttons.append(make_nav_button(nav,"📖  راهنمای برنامه",self.help_page))
        tk.Frame(nav,bg="#26374A",height=1).pack(fill="x",padx=14,pady=12)
        RTLLabel(nav,text="WORLD GAME",bg=NAVBG,fg=NAVGOLD,
                 font=ui_font(10,"bold")).pack(pady=(2,0))
        RTLLabel(nav,text="۰۷۹۶۲۹۷۹۹۶",bg=NAVBG,fg="#7C8CA0",
                 font=ui_font(9)).pack(pady=(2,7))
        # Scrollable main workspace: every page can grow beyond the window height.
        self.main_host=tk.Frame(self,bg="#F4F6F8")
        self.main_host.pack(side="left",fill="both",expand=True)
        self.main_canvas=tk.Canvas(self.main_host,bg="#F4F6F8",highlightthickness=0,bd=0)
        self.main_scrollbar=tk.Scrollbar(self.main_host,orient="vertical",command=self.main_canvas.yview,
                                         bg="#D8DEE4",activebackground="#B58E45",troughcolor="#EEF2F5",width=13)
        self.main_canvas.configure(yscrollcommand=self.main_scrollbar.set)
        self.main_scrollbar.pack(side="right",fill="y")
        self.main_canvas.pack(side="left",fill="both",expand=True)
        self.main=tk.Frame(self.main_canvas,bg="#F4F6F8")
        self._main_window=self.main_canvas.create_window((0,0),window=self.main,anchor="nw")
        self.main.bind("<Configure>",lambda e:self._update_main_scrollregion())
        self.main_canvas.bind("<Configure>",lambda e:self._resize_main_canvas(e))
        self.main_canvas.bind("<Enter>",lambda e:self._bind_mousewheel(self.main_canvas))
        self.main_canvas.bind("<Leave>",lambda e:self._unbind_mousewheel(self.main_canvas))
        self._apply_theme()
        self.after_idle(self._apply_ui_mode)
        # From now on, every new dialog Toplevel automatically picks up the
        # current luxury dark/gold theme a moment after it is built.
        self._shell_ready = True

    def _update_main_scrollregion(self):
        try:
            self.main_canvas.configure(scrollregion=self.main_canvas.bbox("all"))
        except Exception:
            pass

    def _resize_main_canvas(self,event):
        try:
            self.main_canvas.itemconfigure(self._main_window,width=max(1,event.width))
            self._update_main_scrollregion()
        except Exception:
            pass

    def _nav_wheel(self,event,canvas):
        try:
            canvas.yview_scroll(int(-event.delta/120),"units")
        except Exception:
            pass

    def _bind_mousewheel(self, widget):
        try:
            self.unbind_all("<MouseWheel>")
            self.bind_all("<MouseWheel>", self._on_mousewheel)
            self.bind_all("<Button-4>", self._on_mousewheel_linux)
            self.bind_all("<Button-5>", self._on_mousewheel_linux)
        except Exception:
            pass

    def _unbind_mousewheel(self, widget):
        # Keep the wheel available over the application workspace; harmless when the pointer is outside it.
        pass

    def _on_mousewheel(self,event):
        try:
            if self.main_canvas.winfo_exists():
                self.main_canvas.yview_scroll(int(-event.delta/120),"units")
        except Exception:
            pass

    def _on_mousewheel_linux(self,event):
        try:
            self.main_canvas.yview_scroll(-1 if event.num==4 else 1,"units")
        except Exception:
            pass

    def update_clock(self):
        now=datetime.now()
        j=f"تاریخ شمسی: {jalali_date(now)}"
        g=f"تاریخ میلادی: {now:%Y/%m/%d}"
        t=f"ساعت: {now:%H:%M:%S}"
        if hasattr(self,"jalali_label"):
            self.jalali_label.config(text=j)
        if hasattr(self,"clock_label"):
            self.clock_label.config(text=f"{g}  |  {t}")
        if hasattr(self,"header_date_label"):
            self.header_date_label.config(text=f"📅 {j}   •   {g}")
        if hasattr(self,"header_clock_label"):
            self.header_clock_label.config(text=f"⏰ {t}")
        self.after(1000,self.update_clock)

    def clear(self):
        for w in self.main.winfo_children(): w.destroy()
        try:
            self.main_canvas.yview_moveto(0)
            self.after(60, self._apply_theme_no_schedule)
            self.after(80, self._update_main_scrollregion)
        except Exception: pass

    def card(self,parent,title,value,row,col):
        f=tk.Frame(parent,bg="#FFFFFF",highlightbackground="#174e70",highlightthickness=1)
        f.grid(row=row,column=col,padx=7,pady=7,sticky="nsew")
        RTLLabel(f,text=title,bg="#FFFFFF",fg="#B58E45",font=ui_font(9)).pack(anchor="w",padx=12,pady=(9,2))
        RTLLabel(f,text=value,bg="#FFFFFF",fg="#1B2733",font=ui_font(16,"bold"),wraplength=260,justify="left").pack(anchor="w",padx=12,pady=(0,9))

    def dashboard(self):
        self.clear()
        dash_head=tk.Frame(self.main,bg="#F4F6F8")
        dash_head.pack(fill="x",padx=20,pady=(10,6))
        RTLLabel(dash_head,text="داشبورد",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(side="right")
        self.dashboard_date_label=RTLLabel(dash_head,bg="#F4F6F8",fg="#0F766E",font=ui_font(10,"bold"))
        self.dashboard_date_label.pack(side="left",pady=5)
        now=datetime.now()
        self.dashboard_date_label.config(text=f"شمسی: {jalali_date(now)}  |  میلادی: {now:%Y/%m/%d}  |  ساعت: {now:%H:%M:%S}")
        c=self.db.cursor()
        customers=c.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        trades=c.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        businesses=c.execute("SELECT COUNT(*) FROM businesses").fetchone()[0]
        def active_currencies():
            rows=set()
            for table in ("transactions","account_entries","business_transactions"):
                try:
                    rows.update(x[0] for x in c.execute(f"SELECT DISTINCT currency FROM {table} WHERE currency IS NOT NULL AND TRIM(currency)<>''"))
                except Exception: pass
            return sorted(rows,key=lambda x:(0 if str(x).startswith("AFN") else 1,str(x)))
        currencies=active_currencies() or [CURRENCIES[0]]
        grid=tk.Frame(self.main,bg="#F4F6F8"); grid.pack(fill="x",padx=12)
        for i in range(4): grid.columnconfigure(i,weight=1)
        self.card(grid,"تعداد مشتریان",str(customers),0,0)
        self.card(grid,"تعداد معاملات",str(trades),0,1)
        self.card(grid,"تعداد دوکان‌ها",str(businesses),0,2)
        result_parts=[]
        for cur in currencies:
            buy=c.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='خرید' AND currency=?",(cur,)).fetchone()[0] or 0
            sell=c.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='فروش' AND currency=?",(cur,)).fetchone()[0] or 0
            sbuy=c.execute("SELECT COALESCE(SUM(amount),0) FROM business_transactions WHERE kind='خرید' AND currency=?",(cur,)).fetchone()[0] or 0
            ssell=c.execute("SELECT COALESCE(SUM(amount),0) FROM business_transactions WHERE kind='فروش' AND currency=?",(cur,)).fetchone()[0] or 0
            net=D(sell)-D(buy)+D(ssell)-D(sbuy)
            result_parts.append(f"{fmt_money_exact(net)} {cur.split(' - ')[0] if ' - ' in cur else cur}")
        self.card(grid,"نتیجه معاملات"," | ".join(result_parts),0,3)
        bal_grid=tk.Frame(self.main,bg="#F4F6F8"); bal_grid.pack(fill="x",padx=12)
        for i in range(min(max(len(currencies),1),4)): bal_grid.columnconfigure(i,weight=1)
        for idx,cur in enumerate(currencies[:4]):
            net_expr="CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END"
            recv,payv=c.execute(f"SELECT COALESCE(SUM(CASE WHEN entry_type='قرضداری مشتری' THEN {net_expr} ELSE 0 END),0), COALESCE(SUM(CASE WHEN entry_type='بستانکاری مشتری' THEN {net_expr} ELSE 0 END),0) FROM account_entries WHERE currency=?",(cur,)).fetchone()
            net=D(recv)-D(payv); short=cur.split(' - ')[0] if ' - ' in cur else cur
            self.card(bal_grid,f"مانده حساب {short}",f"{fmt_money_exact(net)} {short}",0,idx)

        # ⚠️ دو هشدار سریع که هر روز به کار می‌آیند: کدام مشتری بیشترین بدهی را
        # دارد و کدام کالا دارد تمام می‌شود - بدون نیاز به باز کردن صفحه‌ی دیگر.
        alerts_row=tk.Frame(self.main,bg="#F4F6F8"); alerts_row.pack(fill="x",padx=20,pady=(4,8))
        debt_box=tk.Frame(alerts_row,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        debt_box.pack(side="right",fill="both",expand=True,padx=(6,0))
        RTLLabel(debt_box,text="🔝 بیشترین بدهکاران",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold")).pack(anchor="e",padx=12,pady=7)
        debtor_rows=[]
        for did,dname in c.execute("SELECT id,name FROM customers").fetchall():
            for cur,rf,pf,nf in self.customer_currency_balances(did):
                if D(nf)>0:
                    code=str(cur).split(" - ")[0]
                    debtor_rows.append((D(nf),dname,did,code))
        debtor_rows.sort(key=lambda x:x[0],reverse=True)
        if debtor_rows:
            for dnet,dname,did,code in debtor_rows[:8]:
                r=tk.Frame(debt_box,bg="#FFFFFF"); r.pack(fill="x",padx=12,pady=2)
                l1=RTLLabel(r,text=dname,bg="#FFFFFF",fg="#1B2733",font=ui_font(9,"bold"),cursor="hand2"); l1.pack(side="right")
                l2=RTLLabel(r,text=f"{fmt_num(dnet)} {code}",bg="#FFFFFF",fg="#B45309",font=ui_font(9,"bold"),cursor="hand2"); l2.pack(side="left")
                for w in (r,l1,l2): w.bind("<Button-1>",lambda e,did=did:self.customer_account(did))
            RTLLabel(debt_box,text="مبالغ هر مشتری بر اساس ارز واقعی نمایش داده می‌شود.",bg="#FFFFFF",fg="#9AA6B2",font=ui_font(7)).pack(anchor="e",padx=12,pady=(4,8))
        else:
            RTLLabel(debt_box,text="در حال حاضر مشتری بدهکاری ثبت نشده است.",bg="#FFFFFF",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=12,pady=(0,10))

        stock_box=tk.Frame(alerts_row,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        stock_box.pack(side="left",fill="both",expand=True,padx=(0,6))
        RTLLabel(stock_box,text="📦 کالاهای رو به اتمام",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold")).pack(anchor="e",padx=12,pady=7)
        try:
            low_rows=c.execute("""SELECT si.item_name, b.name, si.quantity, si.unit
                                   FROM shop_inventory si JOIN businesses b ON b.id=si.business_id
                                   WHERE si.quantity<=si.min_quantity ORDER BY si.quantity ASC LIMIT 5""").fetchall()
        except Exception:
            low_rows=[]
        if low_rows:
            for iname,bname,qty,unit in low_rows:
                r=tk.Frame(stock_box,bg="#FFFFFF"); r.pack(fill="x",padx=12,pady=2)
                l1=RTLLabel(r,text=f"{iname}  ({bname})",bg="#FFFFFF",fg="#1B2733",font=ui_font(9,"bold"),cursor="hand2"); l1.pack(side="right")
                l2=RTLLabel(r,text=f"{fmt_num(qty)} {unit}",bg="#FFFFFF",fg="#B91C1C",font=ui_font(9,"bold"),cursor="hand2"); l2.pack(side="left")
                for w in (r,l1,l2): w.bind("<Button-1>",lambda e:self.businesses_page())
            RTLLabel(stock_box,text="برای مدیریت موجودی، روی کالا کلیک کنید.",bg="#FFFFFF",fg="#9AA6B2",font=ui_font(7)).pack(anchor="e",padx=12,pady=(4,8))
        else:
            RTLLabel(stock_box,text="موجودی هیچ کالایی رو به اتمام نیست.",bg="#FFFFFF",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=12,pady=(0,10))

        # خلاصه فشرده قرض/بستانکاری برای ارزهای اصلی
        fx_box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        fx_box.pack(fill="x",padx=20,pady=(4,8))
        RTLLabel(fx_box,text="💱 قرضداری، بستانکاری و گردش مشتریان — هر ارز جداگانه",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold")).pack(anchor="e",padx=12,pady=7)
        cols=["ارز","قرضداری","بستانکاری","جمع کمیشن","مانده خالص"]
        head=tk.Frame(fx_box,bg="#EEF2F6"); head.pack(fill="x",padx=8)
        for i,h in enumerate(cols):
            head.columnconfigure(i,weight=1); RTLLabel(head,text=h,bg="#EEF2F6",fg="#475569",font=ui_font(8,"bold")).grid(row=0,column=i,padx=3,pady=5,sticky="ew")
        for currency in currencies:
            recv,payv,commv=self.db.execute("SELECT COALESCE(SUM(CASE WHEN entry_type='قرضداری مشتری' THEN CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END ELSE 0 END),0),COALESCE(SUM(CASE WHEN entry_type='بستانکاری مشتری' THEN CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END ELSE 0 END),0),COALESCE(SUM(commission),0) FROM account_entries WHERE currency=?",(currency,)).fetchone()
            net=D(recv)-D(payv)
            row=tk.Frame(fx_box,bg="#FFFFFF"); row.pack(fill="x",padx=8)
            vals=[currency.split(" - ")[1] if " - " in currency else currency,fmt_money_exact(recv),fmt_money_exact(payv),fmt_money_exact(commv),fmt_money_exact(net)]
            for i,v in enumerate(vals):
                row.columnconfigure(i,weight=1); RTLLabel(row,text=v,bg="#FFFFFF",fg="#1B2733",font=ui_font(8,"bold")).grid(row=0,column=i,padx=3,pady=4,sticky="ew")
        RTLLabel(fx_box,text="مانده خالص = قرضداری − بستانکاری | هر ارز کاملاً مستقل محاسبه می‌شود.",bg="#FFFFFF",fg="#64748B",font=ui_font(7)).pack(anchor="e",padx=12,pady=(3,7))
        # Live FX panel: shows only rates actually fetched from the online provider.
        # Cached database rates are explicitly labeled as cached; no fabricated values.
        live_fx_box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        live_fx_box.pack(fill="x",padx=20,pady=(4,8))
        fx_head=tk.Frame(live_fx_box,bg="#FFFFFF"); fx_head.pack(fill="x",padx=12,pady=(7,4))
        RTLLabel(fx_head,text="🌐 نرخ آنلاین ارز",bg="#FFFFFF",fg="#E4C077",
                 font=ui_font(12,"bold")).pack(side="right")
        self.dashboard_fx_status=RTLLabel(fx_head,text="در حال دریافت نرخ آنلاین...",
                 bg="#FFFFFF",fg="#64748B",font=ui_font(8,"bold"))
        self.dashboard_fx_status.pack(side="left",padx=8)
        RTLLabel(fx_head,text='منبع:',bg='#FFFFFF',fg='#687582',font=ui_font(8,'bold')).pack(side='left',padx=(10,2))
        market_var=tk.StringVar(value=getattr(self,'_rate_market_source','shahzada'))
        market_map={'shahzada':'کابل — سرای شهزاده','herat':'هرات — خراسان مارکیت','nimroz':'نیمروز — بازار انصاری'}
        market_cb=LocalizedCombobox(fx_head,textvariable=market_var,values=list(market_map.values()),state='readonly',width=23)
        market_cb.pack(side='left',padx=3)
        def select_market(*_):
            rev={v:k for k,v in market_map.items()}; self._rate_market_source=rev.get(market_var.get(),'shahzada'); self.refresh_online_rates(silent=True,market_source=self._rate_market_source)
        market_cb.bind('<<ComboboxSelected>>',select_market)
        self.dashboard_fx_market_var=market_var
        self.dashboard_fx_refresh= self.button(fx_head,"↻ بروزرسانی آنلاین",
                 lambda:self.refresh_online_rates(silent=False,market_source=getattr(self,'_rate_market_source','shahzada')))
        self.dashboard_fx_refresh.pack(side='left',padx=4)
        self.button(fx_head,"⇄ تبدیل ارز",self.currency_converter_page,"#B58E45").pack(side="left",padx=4)
        fx_rates_frame=tk.Frame(live_fx_box,bg="#FFFFFF"); fx_rates_frame.pack(fill="x",padx=8,pady=(0,8))
        # Keep BUY/SELL quotes separate on the dashboard.  Do not collapse
        # them into the midpoint: the converter and the market feed already
        # provide the actual bid/ask pair.
        self.dashboard_fx_labels={}
        for code,label in [("USD","دلار"),("EUR","یورو"),("IRR","تومان"),("PKR","کلدار"),("AFN","افغانی")]:
            cell=tk.Frame(fx_rates_frame,bg="#F8FAFC",highlightbackground="#E2E8F0",highlightthickness=1)
            cell.pack(side="left",fill="x",expand=True,padx=3)
            RTLLabel(cell,text=label,bg="#F8FAFC",fg="#E4C077",font=ui_font(8,"bold")).pack(pady=(4,1))
            buy=RTLLabel(cell,text="خرید: —",bg="#F8FAFC",fg="#15803D",font=ui_font(8,"bold"))
            buy.pack(pady=(0,1))
            sell=RTLLabel(cell,text="فروش: —",bg="#F8FAFC",fg="#B45309",font=ui_font(8,"bold"))
            sell.pack(pady=(0,4))
            self.dashboard_fx_labels[code]={'buy':buy,'sell':sell}
        self._update_dashboard_fx_panel()
        # Dashboard chart: monthly purchases vs sales. It uses Tk Canvas only, so
        # the desktop EXE needs no extra charting package. Existing data is read-only here.
        chart_box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1,height=205)
        chart_box.pack(fill="x",padx=20,pady=(4,8))
        chart_box.pack_propagate(False)
        chart_head=tk.Frame(chart_box,bg="#FFFFFF")
        chart_head.pack(fill="x",padx=15,pady=(8,0))
        RTLLabel(chart_head,text="نمودار خرید و فروش ماهانه",bg="#FFFFFF",fg="#1B2733",
                 font=ui_font(13,"bold")).pack(side="right")
        RTLLabel(chart_head,text="مقایسه مجموع معاملات به افغانی",bg="#FFFFFF",fg="#687582",
                 font=ui_font(9)).pack(side="right",padx=(0,14))
        legend=tk.Frame(chart_head,bg="#FFFFFF"); legend.pack(side="left")
        RTLLabel(legend,text="● خرید",bg="#FFFFFF",fg="#B58E45",font=ui_font(9,"bold")).pack(side="left",padx=7)
        RTLLabel(legend,text="● فروش",bg="#FFFFFF",fg="#2D7FA3",font=ui_font(9,"bold")).pack(side="left",padx=7)

        chart=tk.Canvas(chart_box,bg="#FFFFFF",highlightthickness=0,height=158)
        chart.pack(fill="both",expand=True,padx=12,pady=(2,8))

        rows=c.execute("""
            SELECT substr(created,1,7) AS ym,
                   COALESCE(SUM(CASE WHEN kind='خرید' THEN afn_amount ELSE 0 END),0),
                   COALESCE(SUM(CASE WHEN kind='فروش' THEN afn_amount ELSE 0 END),0)
            FROM transactions
            WHERE created IS NOT NULL AND length(created)>=7
            GROUP BY ym ORDER BY ym DESC LIMIT 6
        """).fetchall()
        rows=list(reversed(rows))
        if not rows:
            now=datetime.now()
            months=[]
            y,m=now.year,now.month
            for _ in range(6):
                months.append((f"{y:04d}-{m:02d}",0,0))
                m-=1
                if m==0: y,m=y-1,12
            rows=list(reversed(months))

        def draw_chart(event=None):
            try:
                if not chart.winfo_exists():
                    return
                chart.delete("all")
            except Exception:
                return
            w=max(chart.winfo_width(),520); h=max(chart.winfo_height(),145)
            left,right,top,bottom=55,18,10,32
            plot_w=max(1,w-left-right); plot_h=max(1,h-top-bottom)
            vals=[max(float(r[1] or 0),float(r[2] or 0)) for r in rows]
            maxv=max(vals+[1.0])
            # Rounded ceiling gives a cleaner scale.
            step=maxv/4.0
            if step>0:
                import math
                mag=10**max(0,int(math.floor(math.log10(step))))
                nice=math.ceil(step/mag)*mag
                maxv=nice*4
            for i in range(5):
                y=top+plot_h-(plot_h*i/4)
                chart.create_line(left,y,w-right,y,fill="#E9EDF1",width=1)
                label=maxv*i/4
                chart.create_text(left-8,y,text=f"{label:,.0f}",anchor="e",fill="#687582",font=ui_font(8))
            group_w=plot_w/max(len(rows),1)
            bar_w=min(22,max(10,group_w*0.22))
            for i,(ym,buy_m,sell_m) in enumerate(rows):
                cx=left+group_w*(i+0.5)
                bh=plot_h*(float(buy_m or 0)/maxv)
                sh=plot_h*(float(sell_m or 0)/maxv)
                chart.create_rectangle(cx-bar_w-3,top+plot_h-bh,cx-3,top+plot_h,fill="#B58E45",outline="")
                chart.create_rectangle(cx+3,top+plot_h-sh,cx+bar_w+3,top+plot_h,fill="#2D7FA3",outline="")
                chart.create_text(cx,h-15,text=str(ym),fill="#687582",font=ui_font(8))
            chart.create_line(left,top,left,top+plot_h,fill="#C9D1D8")
            chart.create_line(left,top+plot_h,w-right,top+plot_h,fill="#C9D1D8")
        chart.bind("<Configure>",draw_chart)
        self.after(50,draw_chart)

        box=tk.Frame(self.main,bg="#FFFFFF"); box.pack(fill="both",expand=True,padx=20,pady=8)
        RTLLabel(box,text="آخرین معاملات",bg="#FFFFFF",fg="#35a9ff",
                 font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=10)
        cols=("id","date","kind","currency","amount","rate","customer")
        tree=ttk.Treeview(box,columns=cols,show="headings", style="Jahan.Treeview")
        heads={"id":"#","date":"تاریخ","kind":"نوع","currency":"ارز","amount":"مبلغ","rate":"نرخ","customer":"مشتری"}
        for x in cols: tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,width=105,anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=10,pady=5)
        for r in c.execute("SELECT id,created,kind,currency,amount,rate,customer FROM transactions ORDER BY id DESC LIMIT 10"):
            tree.insert("", "end", values=r)

    def _dashboard_customer_search(self, tree, query=""):
        q=str(query or "").strip()
        for item in tree.get_children(): tree.delete(item)
        if q:
            like=f"%{q}%"
            rows=self.db.execute("SELECT id,name,phone FROM customers WHERE name LIKE ? OR phone LIKE ? OR address LIKE ? ORDER BY name LIMIT 12",(like,like,like)).fetchall()
        else:
            rows=self.db.execute("SELECT id,name,phone FROM customers ORDER BY id DESC LIMIT 12").fetchall()
        for cid,name,phone in rows:
            rec,pay,net=self.customer_balances(cid)
            status="قرضدار: "+fmt_num(net) if net>0 else ("بستانکار: "+fmt_num(abs(net)) if net<0 else "تسویه")
            tree.insert("","end",values=(cid,name,phone or "-",status))

    def _open_dashboard_customer(self, tree):
        sel=tree.selection()
        if not sel: return
        cid=int(tree.item(sel[0],"values")[0])
        self.customer_account(cid)

    def customers_page(self):
        self.clear()
        RTLLabel(self.main,text="مدیریت مشتریان",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20)
        q=tk.StringVar()
        tk.Entry(bar,textvariable=q,font=ui_font(11),bg="#FFFFFF",fg="#1B2733",
                 insertbackground="white",relief="flat").pack(side="right",fill="x",expand=True,padx=5)
        tree=None
        self.button(bar,"جستجو",lambda:self.load_customers(tree,q.get())).pack(side="right")
        self.button(bar,"＋ مشتری جدید",self.add_customer).pack(side="left")
        self.button(bar,"✏ ویرایش مشخصات",lambda:self.edit_selected_customer(tree),"#2563EB").pack(side="left",padx=5)
        self.button(bar,"🗑 حذف مشتری",lambda:self.delete_selected_customer(tree)).pack(side="left",padx=5)
        self.button(bar,"📊 خروجی Excel",lambda:self.export_tree_csv(tree,"مشتریان.csv"),"#0f766e").pack(side="left",padx=5)
        cols=("id","name","phone","address","receivable","payable","net","currency")
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads={"id":"#","name":"نام مشتری","phone":"شماره تماس","address":"آدرس",
               "receivable":"قرضدار","payable":"بستانکار","net":"مانده خالص","currency":"ارز"}
        for x in cols: tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,anchor="center",width=115 if x!="currency" else 80)
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=12)
        tree.bind("<ButtonRelease-1>",lambda e:self.open_selected_account(tree))
        self.load_customers(tree)
        RTLLabel(self.main,text="برای دیدن حساب کامل مشتری، فقط یک‌بار روی نام او کلیک کنید.",
                 bg="#F4F6F8",fg="#7D8892",font=ui_font(9)).pack(anchor="e",padx=25)

    def customer_commission_summary(self, cid):
        """Return commission totals per currency; never add different currencies together."""
        rows=self.db.execute("SELECT COALESCE(currency,'AFN - افغانی'),COALESCE(SUM(commission),0) FROM account_entries WHERE customer_id=? GROUP BY COALESCE(currency,'AFN - افغانی') ORDER BY currency",(cid,)).fetchall()
        parts=[]
        for cur,total in rows:
            if abs(float(total or 0))>0:
                code=CURRENCY_CODES.get(cur,cur.split(' - ')[0] if cur else cur)
                parts.append(f"{fmt_num(total)} {code}")
        return " | ".join(parts) if parts else "0"

    def customer_balances(self, cid):
        """Return the customer's real balance after applying customer receipts.

        Receipt rows are stored in ``receipts`` and a mirrored ledger row is also
        stored in ``account_entries`` for the journal.  The old implementation
        summed both indirectly in some views and could leave the debt unchanged
        when the receipt/customer link was missing.  Here the source of truth is:

        debt = normal loans + payments made TO customer
        credit = normal credits + receipts received FROM customer

        Receipt mirror rows are explicitly excluded from the base ledger totals,
        then the real receipt table is applied once.  All calculations are kept
        in the receipt's own currency (AFN equivalent is used only for the
        multi-currency fallback).
        """
        base_net = "CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END"
        base_afn = "CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN ({})*COALESCE(rate,1) ELSE CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN MAX(afn_amount-COALESCE(commission_afn,commission*COALESCE(rate,1)),0) ELSE afn_amount END END".format(base_net)
        normal_where = "customer_id=? AND COALESCE(source_type,'manual')<>'receipt'"

        debt = self.db.execute(
            f"SELECT COALESCE(SUM({base_afn}),0) FROM account_entries WHERE {normal_where} AND entry_type='قرضداری مشتری'",
            (cid,)).fetchone()[0] or 0
        credit = self.db.execute(
            f"SELECT COALESCE(SUM({base_afn}),0) FROM account_entries WHERE {normal_where} AND entry_type='بستانکاری مشتری'",
            (cid,)).fetchone()[0] or 0

        # Apply actual customer receipts exactly once.  Receiving money reduces
        # what the customer owes; paying money to the customer increases it.
        received = self.db.execute("""
            SELECT COALESCE(SUM(
                CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency
                     THEN MAX(afn_amount-COALESCE(commission_afn,commission*COALESCE(rate,1)),0)
                     ELSE COALESCE(afn_amount,amount*COALESCE(rate,1)) END),0)
            FROM receipts
            WHERE customer_id=? AND receipt_type='دریافت از مشتری'
        """, (cid,)).fetchone()[0] or 0
        paid = self.db.execute("""
            SELECT COALESCE(SUM(
                CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency
                     THEN MAX(afn_amount-COALESCE(commission_afn,commission*COALESCE(rate,1)),0)
                     ELSE COALESCE(afn_amount,amount*COALESCE(rate,1)) END),0)
            FROM receipts
            WHERE customer_id=? AND receipt_type='پرداخت به مشتری'
        """, (cid,)).fetchone()[0] or 0
        return float(debt + paid), float(credit + received), float(debt + paid - credit - received)

    def customer_account_totals(self, cid):
        """Return gross and commission-adjusted customer totals per currency.

        Each currency is isolated. Gross values use the original transaction
        amounts; net values deduct commission only when the commission is stored
        in the same currency. Customer receipts are applied once.
        """
        currencies=set(r[0] for r in self.db.execute(
            "SELECT DISTINCT currency FROM account_entries WHERE customer_id=? AND currency IS NOT NULL AND TRIM(currency)<>''", (cid,)).fetchall())
        currencies.update(r[0] for r in self.db.execute(
            "SELECT DISTINCT currency FROM receipts WHERE customer_id=? AND currency IS NOT NULL AND TRIM(currency)<>''", (cid,)).fetchall())
        out=[]
        for cur in sorted(currencies):
            normal="customer_id=? AND currency=? AND COALESCE(source_type,'manual')<>'receipt'"
            debt_g=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM account_entries WHERE "+normal+" AND entry_type='قرضداری مشتری'",(cid,cur)).fetchone()[0] or 0
            credit_g=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM account_entries WHERE "+normal+" AND entry_type='بستانکاری مشتری'",(cid,cur)).fetchone()[0] or 0
            debt_n=self.db.execute("SELECT COALESCE(SUM(CASE WHEN COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END),0) FROM account_entries WHERE "+normal+" AND entry_type='قرضداری مشتری'",(cid,cur)).fetchone()[0] or 0
            credit_n=self.db.execute("SELECT COALESCE(SUM(CASE WHEN COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END),0) FROM account_entries WHERE "+normal+" AND entry_type='بستانکاری مشتری'",(cid,cur)).fetchone()[0] or 0
            rg=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM receipts WHERE customer_id=? AND currency=? AND receipt_type='دریافت از مشتری'",(cid,cur)).fetchone()[0] or 0
            pg=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM receipts WHERE customer_id=? AND currency=? AND receipt_type='پرداخت به مشتری'",(cid,cur)).fetchone()[0] or 0
            rn=self.db.execute("SELECT COALESCE(SUM(CASE WHEN COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END),0) FROM receipts WHERE customer_id=? AND currency=? AND receipt_type='دریافت از مشتری'",(cid,cur)).fetchone()[0] or 0
            pn=self.db.execute("SELECT COALESCE(SUM(CASE WHEN COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END),0) FROM receipts WHERE customer_id=? AND currency=? AND receipt_type='پرداخت به مشتری'",(cid,cur)).fetchone()[0] or 0
            # Commission must not be counted twice: receipt rows have a mirror
            # entry in account_entries, so ledger-side commission excludes those
            # mirrors and the real receipts table is added exactly once.
            comm=self.db.execute("SELECT COALESCE(SUM(commission),0) FROM account_entries WHERE customer_id=? AND currency=? AND COALESCE(source_type,'manual')<>'receipt' AND COALESCE(commission_currency,currency)=currency",(cid,cur)).fetchone()[0] or 0
            comm += self.db.execute("SELECT COALESCE(SUM(commission),0) FROM receipts WHERE customer_id=? AND currency=? AND COALESCE(commission_currency,currency)=currency",(cid,cur)).fetchone()[0] or 0
            gross_debt=float(debt_g)+float(pg); gross_credit=float(credit_g)+float(rg)
            net_debt=float(debt_n)+float(pn); net_credit=float(credit_n)+float(rn)
            out.append((cur,gross_debt,gross_credit,gross_debt-gross_credit,net_debt,net_credit,net_debt-net_credit,float(comm)))
        return out

    def customer_display_balance(self, cid):
        """Return customer balance in the customer's own currency when possible."""
        rows=self.customer_currency_balances(cid)
        if len(rows)==1:
            cur,rec,pay,net=rows[0]
            short=cur.split(" - ")[0] if " - " in cur else cur
            return float(rec),float(pay),float(net),short
        rec,pay,net=self.customer_balances(cid)
        return rec,pay,net,("AFN" if rows else "AFN")

    def customer_currency_balances(self, cid):
        """Exact customer balance per currency, with receipts reducing loans.

        Normal account entries are the original loan/credit records. Receipt
        mirror rows are excluded from those totals and the actual ``receipts``
        table is applied once, preventing both missed deductions and double
        counting.
        """
        rows=[]
        currencies=set(r[0] for r in self.db.execute(
            "SELECT DISTINCT currency FROM account_entries WHERE customer_id=? AND currency IS NOT NULL AND TRIM(currency)<>''",
            (cid,)).fetchall())
        currencies.update(r[0] for r in self.db.execute(
            "SELECT DISTINCT currency FROM receipts WHERE customer_id=? AND currency IS NOT NULL AND TRIM(currency)<>''",
            (cid,)).fetchall())

        for currency in sorted(currencies):
            net_expr="CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN MAX(amount-COALESCE(commission,0),0) ELSE amount END"
            debt=self.db.execute(
                f"SELECT COALESCE(SUM({net_expr}),0) FROM account_entries WHERE customer_id=? AND currency=? AND COALESCE(source_type,'manual')<>'receipt' AND entry_type='قرضداری مشتری'",
                (cid,currency)).fetchone()[0] or 0
            credit=self.db.execute(
                f"SELECT COALESCE(SUM({net_expr}),0) FROM account_entries WHERE customer_id=? AND currency=? AND COALESCE(source_type,'manual')<>'receipt' AND entry_type='بستانکاری مشتری'",
                (cid,currency)).fetchone()[0] or 0

            received=self.db.execute("""
                SELECT COALESCE(SUM(
                    CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency
                         THEN MAX(amount-COALESCE(commission,0),0)
                         ELSE amount END),0)
                FROM receipts
                WHERE customer_id=? AND currency=? AND receipt_type='دریافت از مشتری'
            """, (cid,currency)).fetchone()[0] or 0
            paid=self.db.execute("""
                SELECT COALESCE(SUM(
                    CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency
                         THEN MAX(amount-COALESCE(commission,0),0)
                         ELSE amount END),0)
                FROM receipts
                WHERE customer_id=? AND currency=? AND receipt_type='پرداخت به مشتری'
            """, (cid,currency)).fetchone()[0] or 0

            total_debt=float(debt or 0)+float(paid or 0)
            total_credit=float(credit or 0)+float(received or 0)
            rows.append((currency,total_debt,total_credit,total_debt-total_credit))
        return rows

    def _update_dashboard_fx_panel(self):
        """Refresh dashboard FX widgets from the verified online/cache state."""
        labels=getattr(self,'dashboard_fx_labels',{})
        if not labels:
            return
        for code,widgets in labels.items():
            try:
                q=getattr(self,'_market_quotes',{}).get(code) or {}
                if code=='AFN':
                    buy=sell=1.0
                else:
                    buy=float(q.get('buy',0) or 0)
                    sell=float(q.get('sell',0) or 0)
                    # If the online quote is not available yet, do not invent
                    # buy/sell values. The midpoint is only a legacy fallback
                    # for an already cached single-rate source.
                    if not (buy>0 and sell>0):
                        buy=sell=0.0
                if buy>0 and sell>0:
                    widgets['buy'].config(text=f"خرید: {fmt_fx_rate(buy)}", fg="#15803D")
                    widgets['sell'].config(text=f"فروش: {fmt_fx_rate(sell)}", fg="#B45309")
                else:
                    widgets['buy'].config(text="خرید: —")
                    widgets['sell'].config(text="فروش: —")
            except Exception:
                try:
                    widgets['buy'].config(text="خرید: —")
                    widgets['sell'].config(text="فروش: —")
                except Exception: pass
        try:
            if getattr(self,'_rates_updated',""):
                source="آنلاین" if getattr(self,'_rates_online_ok',False) else "ذخیره‌شده"
                color="#15803d" if getattr(self,'_rates_online_ok',False) else "#B45309"
                src = getattr(self,'_rates_source','')
                extra = f" | {src}" if src and getattr(self,'_rates_online_ok',False) else ''
                self.dashboard_fx_status.config(
                    text=f"● {source} | آخرین دریافت: {self._rates_updated}{extra}",fg=color)
            else:
                self.dashboard_fx_status.config(text="● هنوز نرخ آنلاین دریافت نشده است",fg="#B91C1C")
        except Exception:
            pass

    def refresh_online_rates(self, silent=True, on_done=None, market_source=None):
        """Fetch live Afghanistan market rates for the selected city/market.

        market_source:
          shahzada -> کابل، سرای شهزاده
          herat    -> هرات، خراسان مارکیت
          nimroz   -> نیمروز، بازار انصاری (rates published by a Nimroz market feed)
        """
        if getattr(self,'_rates_loading',False):
            return
        selected = market_source or getattr(self,'_rate_market_source','shahzada') or 'shahzada'
        self._rate_market_source = selected
        self._rates_loading=True
        try:
            if hasattr(self,'dashboard_fx_status'):
                self.dashboard_fx_status.config(text='● در حال دریافت نرخ بازار انتخاب‌شده...',fg='#2563EB')
            if hasattr(self,'dashboard_fx_refresh'):
                self.dashboard_fx_refresh.config(state='disabled')
        except Exception:
            pass

        def worker():
            data=None; errors=[]

            def norm_digits(v):
                # ArzCheck uses Persian/Arabic digits and the Arabic decimal
                # separator U+066B (٫) / thousands separator U+066C (٬).
                # Normalize them before parsing market numbers.
                table = str.maketrans(
                    '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩٫٬',
                    '01234567890123456789.,'
                )
                return str(v).translate(table)

            def clean_html(raw):
                x=re.sub(r'(?is)<script.*?</script>|<style.*?</style>', ' ', raw)
                x=html.unescape(re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',x))).strip()
                return norm_digits(x)

            def parse_num(v):
                x=str(v).strip().replace('٫','.')
                # Commas are thousands separators in the market tables.
                x=x.replace(',','')
                return float(x)

            def pair_after(text, label_re, window=420):
                num=r'([0-9]+(?:[.,][0-9]+)?)'
                m=re.search(label_re+r'.{0,'+str(window)+'}?'+num+r'\s*(?:خرید|buy)?\s+'+num, text, re.I|re.S)
                if not m:
                    # Many market pages render rows as: label | buy | sell.
                    # Do not require the words «خرید/فروش» to be present.
                    m=re.search(label_re+r'.{0,'+str(window)+'}?'+num+r'\D{1,80}'+num, text, re.I|re.S)
                if not m:return None
                try:
                    a=parse_num(m.group(1)); b=parse_num(m.group(2))
                    return (a,b) if a>0 and b>0 else None
                except Exception:return None

            def build_market(usd,eur,pkr,toman,source,stamp, pkr_per_1000=False, toman_per_afn=False):
                def mid(x): return (x[0]+x[1])/2.0
                q={'AFN':{'buy':1.0,'sell':1.0,'unit':1}}
                if usd:q['USD']={'buy':usd[0],'sell':usd[1],'unit':1}
                if eur:q['EUR']={'buy':eur[0],'sell':eur[1],'unit':1}
                if pkr:
                    if pkr_per_1000:
                        q['PKR']={'buy':pkr[0]/1000.0,'sell':pkr[1]/1000.0,'unit':1}
                    else:q['PKR']={'buy':pkr[0],'sell':pkr[1],'unit':1}
                if toman:
                    if toman_per_afn:
                        # Source says 1 AFN = N Toman; convert to AFN per 1 Toman.
                        q['IRR']={'buy':1.0/toman[1],'sell':1.0/toman[0],'unit':1}
                    else:
                        q['IRR']={'buy':toman[0]/1000.0,'sell':toman[1]/1000.0,'unit':1}
                rates={'AFN':1.0}
                for c in ('USD','EUR','PKR','IRR'):
                    if c in q: rates[c]=(q[c]['buy']+q[c]['sell'])/2.0
                return {'market_rates':rates,'market_quotes':q,'source':source,'source_date':stamp}

            # 1) Kabul / Sarai Shahzada
            if selected=='shahzada':
                try:
                    url='https://sarafi.af/en/exchange-rates/sarai-shahzada'
                    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 JahanAccounting/18.33','Accept':'text/html,application/xhtml+xml','Cache-Control':'no-cache','Pragma':'no-cache'})
                    with _jahan_urlopen(req,timeout=15) as resp: raw=resp.read().decode('utf-8','ignore')
                    segment=clean_html(raw)
                    def mp(p): return pair_after(segment,p,700)
                    usd=mp(r'USD\s*[-–]\s*(?:US Dollar|دالر آمریکا|دالر)')
                    eur=mp(r'EUR\s*[-–]\s*(?:Euro|یورو اروپا|یورو)')
                    pkr=mp(r'PKR\s*[-–]\s*(?:Pakistani Rupee|روپیه پاکستان|کلدار)')
                    irr=mp(r'IRR\s*[-–]\s*(?:Iranian Rial|تومان ایران|تومان)')
                    if not all((usd,eur,pkr,irr)): raise ValueError('نرخ کامل سرای شهزاده پیدا نشد')
                    data=build_market(usd,eur,pkr,irr,'Sarafi.af | بازار آزاد سرای شهزاده کابل',datetime.now().strftime('%Y-%m-%d %H:%M'),True,False)
                except Exception as e: errors.append(f'کابل/سرای شهزاده: {e}')

            # 2) Herat / Khorasan Market.
            # Use the market page itself, plus a reader proxy only if the direct
            # request is blocked.  Most importantly, parse the Herat rows by their
            # exact currency names; do NOT use the generic word "تومان" because
            # the page also contains a separate "دالر تومان" row.
            elif selected=='herat':
                try:
                    def fetch_market_text(urls, timeout=18):
                        last=None
                        for u in urls:
                            try:
                                req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) JahanAccounting/18.39','Accept':'text/html,application/xhtml+xml,text/plain,*/*','Cache-Control':'no-cache','Pragma':'no-cache'})
                                with _jahan_urlopen(req,timeout=timeout) as resp:
                                    raw=resp.read().decode('utf-8','ignore')
                                if raw and len(raw)>300:
                                    return clean_html(raw), u
                            except Exception as ex:
                                last=ex
                        raise last or RuntimeError('منبع در دسترس نیست')

                    # IMPORTANT: ArzCheck's /nerkh-asar page can render the
                    # market tables dynamically and an ordinary HTTP request may
                    # expose only the Kabul table. The site homepage currently
                    # contains the server-rendered Herat table, so prefer it for
                    # reliable desktop-app retrieval. Add a cache-buster on every
                    # refresh so a previous response is not silently reused.
                    cb=str(int(datetime.now().timestamp()*1000))
                    urls=[
                        f'https://arzcheck.com/?_jahan_refresh={cb}',
                        f'https://www.arzcheck.com/?_jahan_refresh={cb}',
                        f'https://arzcheck.com/nerkh-asar?_jahan_refresh={cb}',
                        f'https://www.arzcheck.com/nerkh-asar?_jahan_refresh={cb}',
                        'https://r.jina.ai/https://arzcheck.com/',
                        'https://r.jina.ai/https://arzcheck.com/nerkh-asar'
                    ]
                    text, used_url=fetch_market_text(urls)

                    # Find the actual Herat section. ArzCheck currently places the
                    # Kabul table first and the Herat table after it. If a header is
                    # found, stop at the next market header; otherwise parse the
                    # complete page using exact labels.
                    hm=re.search(r'(?:بازار\s*هرات\s*[—-]?\s*خراسان\s*مارکیت|خراسان\s*مارکیت\s*هرات)', text, re.I|re.S)
                    if not hm:
                        raise ValueError('بخش «بازار هرات — خراسان مارکیت» در پاسخ ArzCheck پیدا نشد')
                    tail=text[hm.start():]
                    # The Herat table is the final market table on the current
                    # ArzCheck homepage. Stop at a later market header if one is
                    # ever added, otherwise keep the whole remaining Herat block.
                    nxt=re.search(r'(?:بازار\s*(?:کابل|مزار|قندهار)|سرای\s*شهزاده)', tail[20:], re.I|re.S)
                    seg=tail if not nxt else tail[:20+nxt.start()]

                    # Exact labels prevent another currency row from being picked.
                    usd=pair_after(seg,r'(?:دالر\s*آمریکا|USD)')
                    eur=pair_after(seg,r'(?:یورو|EUR)')
                    pkr=pair_after(seg,r'(?:روپیه\s*پاکستان|کلدار\s*پاکستانی|کلدار|PKR)')
                    irr=pair_after(seg,r'(?:ریال\s*ایران|تومان\s*ایرانی|IRR)')

                    if not (usd and irr and pkr):
                        raise ValueError(f'نرخ‌های اصلی هرات پیدا نشد (USD={bool(usd)}, EUR={bool(eur)}, IRR={bool(irr)}, PKR={bool(pkr)})')

                    # Prefer the site's own last-registration timestamp instead of
                    # inventing the local PC time as the source timestamp.
                    stamp_match=re.search(r'(?:هرات\s*خراسان\s*مارکیت)\s*آخرین\s*ثبت\s*:\s*([^|]+?)(?=\s*(?:بازار\s*کابل|بازار\s*هرات|$))', text, re.I|re.S)
                    source_stamp=(stamp_match.group(1).strip() if stamp_match else datetime.now().strftime('%Y-%m-%d %H:%M'))
                    data=build_market(usd,eur,pkr,irr,'ArzCheck | بازار هرات / خراسان مارکیت',source_stamp,True,False)
                    data['source_url']=used_url
                    data['market_source']='herat'
                except Exception as e:
                    errors.append(f'هرات/خراسان مارکیت: {e}')

            # 3) Nimroz / Ansari Market.
            # PRIMARY SOURCE: the user's exact WhatsApp Channel.
            # Channel: https://whatsapp.com/channel/0029Vb6Cf40EwEk4iJ6DAB3f
            # The channel posts use this format:
            #   افغانی به تومان ایران
            #   🔴 3510   -> فروش
            #   🔵 3500   -> خرید
            #   دالر به افغانی
            #   🔴 64.90  -> فروش
            #   🔵 64.80  -> خرید
            # Do not confuse this with «افغانی نقدی» or «کالدار نقدی».
            elif selected=='nimroz':
                try:
                    WA_URL='https://whatsapp.com/channel/0029Vb6Cf40EwEk4iJ6DAB3f'

                    def fetch_nimroz_whatsapp(urls, timeout=20):
                        last=None
                        for u in urls:
                            try:
                                req=urllib.request.Request(
                                    u,
                                    headers={
                                        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36 JahanAccounting/18.40',
                                        'Accept':'text/html,application/xhtml+xml,application/json,text/plain,*/*',
                                        'Accept-Language':'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
                                        'Cache-Control':'no-cache','Pragma':'no-cache'
                                    })
                                with _jahan_urlopen(req,timeout=timeout) as resp:
                                    raw=resp.read().decode('utf-8','ignore')
                                if raw and len(raw)>100:
                                    return clean_html(raw),u
                            except Exception as ex:
                                last=ex
                        raise last or RuntimeError('منبع واتساپ در دسترس نیست')

                    # Try the exact channel first. The proxy URLs are only a transport
                    # fallback for environments where WhatsApp redirects/blocks direct
                    # HTTP requests; they still point to the SAME channel URL.
                    wa_urls=[
                        WA_URL,
                        'https://www.whatsapp.com/channel/0029Vb6Cf40EwEk4iJ6DAB3f',
                        'https://r.jina.ai/'+WA_URL,
                        'https://r.jina.ai/https://www.whatsapp.com/channel/0029Vb6Cf40EwEk4iJ6DAB3f'
                    ]
                    text, used_url=fetch_nimroz_whatsapp(wa_urls)

                    def num_token(x):
                        return r'([0-9]+(?:[.,][0-9]+)?)'

                    def red_blue_pair(block, label_re, window=900):
                        """Return (sell_red, buy_blue) from a WhatsApp rate block."""
                        lm=re.search(label_re,block,re.I|re.S)
                        if not lm:
                            return None
                        seg=block[lm.start():lm.start()+window]
                        # Normalize emoji variants and whitespace but keep order.
                        seg=seg.replace('\u2764\ufe0f','').replace('\ufe0f','')
                        # Preferred exact structure: red/sell first, blue/buy second.
                        red=re.search(r'(?:🔴|🔺|قرمز|فروش)\s*[:：-]?\s*'+num_token(''),seg,re.I|re.S)
                        blue=re.search(r'(?:🔵|🔷|آبی|خرید)\s*[:：-]?\s*'+num_token(''),seg,re.I|re.S)
                        if red and blue:
                            try:
                                sell=parse_num(red.group(1)); buy=parse_num(blue.group(1))
                                if sell>0 and buy>0:return (sell,buy)
                            except Exception: pass
                        # If emoji/text labels were stripped by HTML, use the two
                        # numbers immediately after the exact heading. In this source
                        # the first is always red=sell and second blue=buy.
                        nums=re.findall(num_token(''),seg,re.I|re.S)
                        vals=[]
                        for n in nums[:6]:
                            try:
                                v=parse_num(n)
                                if v>0: vals.append(v)
                            except Exception: pass
                        if len(vals)>=2:
                            return (vals[0],vals[1])
                        return None

                    # WhatsApp may expose the latest post multiple times in HTML/JSON.
                    # Split around the exact post title and inspect newest-looking blocks.
                    candidates=[]
                    for m in re.finditer(r'نرخ\s*اسعار\s*نیمروز',text,re.I):
                        candidates.append(text[m.start():m.start()+5000])
                    # Also support pages where the title is omitted from structured data.
                    candidates += [text[:20000],text[-20000:]]

                    chosen=None
                    for block in candidates:
                        toman=red_blue_pair(block,r'افغانی\s*به\s*تومان(?:\s*ایران)?',1200)
                        usd=red_blue_pair(block,r'دالر\s*به\s*افغانی',900)
                        pkr=red_blue_pair(block,r'(?:کلدار|کالدار)\s*به\s*افغانی',900)
                        if toman and usd:
                            chosen=(toman,usd,pkr,block)
                            break

                    if not chosen:
                        raise ValueError('نرخ نیمروز در کانال واتساپ پیدا نشد')

                    toman_pair,usd_pair,pkr_pair,_=chosen

                    # Red = فروش, Blue = خرید. Keep that semantic order in the
                    # market quote table. The displayed conversion rate uses the
                    # midpoint, so both sides are represented accurately.
                    q={'AFN':{'buy':1.0,'sell':1.0,'unit':1}}
                    q['USD']={'buy':usd_pair[1],'sell':usd_pair[0],'unit':1}
                    if pkr_pair:
                        q['PKR']={'buy':pkr_pair[1]/1000.0,'sell':pkr_pair[0]/1000.0,'unit':1}
                    # Source quote is AFN -> Toman. Store the inverse quote for
                    # the Toman currency itself: blue/buy and red/sell are inverted.
                    q['IRR']={'buy':1.0/toman_pair[0],'sell':1.0/toman_pair[1],'unit':1}
                    rates={'AFN':1.0}
                    for c in ('USD','PKR','IRR'):
                        rates[c]=(q[c]['buy']+q[c]['sell'])/2.0
                    data={
                        'market_rates':rates,
                        'market_quotes':q,
                        'source':'WhatsApp | کانال اسعار نرخ نیمروز افغانستان',
                        'source_url':WA_URL,
                        'source_date':datetime.now().strftime('%Y-%m-%d %H:%M'),
                        'nimroz_sell_buy':{
                            'toman':toman_pair,
                            'usd':usd_pair,
                            'pkr':pkr_pair
                        }
                    }
                except Exception as e:
                    errors.append(f'نیمروز/واتساپ: {e}')

            # IMPORTANT: Never silently replace a selected regional market with Kabul.
            # If the user selected Herat or Nimroz, the displayed source must remain that
            # market; otherwise a failed regional fetch would look like the wrong market
            # was successfully loaded. Kabul is only fetched when Kabul itself is selected.
            if False and data is None and selected!='shahzada':
                try:
                    url='https://sarafi.af/en/exchange-rates/sarai-shahzada'
                    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 JahanAccounting/18.33','Accept':'text/html,application/xhtml+xml','Cache-Control':'no-cache'})
                    with _jahan_urlopen(req,timeout=12) as resp: raw=resp.read().decode('utf-8','ignore')
                    segment=clean_html(raw)
                    def mp2(p): return pair_after(segment,p,700)
                    usd=mp2(r'USD\s*[-–]\s*(?:US Dollar|دالر آمریکا|دالر)'); eur=mp2(r'EUR\s*[-–]\s*(?:Euro|یورو اروپا|یورو)'); pkr=mp2(r'PKR\s*[-–]\s*(?:Pakistani Rupee|روپیه پاکستان|کلدار)'); irr=mp2(r'IRR\s*[-–]\s*(?:Iranian Rial|تومان ایران|تومان)')
                    if all((usd,eur,pkr,irr)):
                        data=build_market(usd,eur,pkr,irr,'پشتیبان کابل | سرای شهزاده (منبع انتخاب‌شده در دسترس نبود)',datetime.now().strftime('%Y-%m-%d %H:%M'),True,False)
                except Exception as e: errors.append(f'پشتیبان کابل: {e}')

            def apply():
                self._rates_loading=False
                try:
                    if hasattr(self,'dashboard_fx_refresh'): self.dashboard_fx_refresh.config(state='normal')
                except Exception: pass
                ok=False
                if data and data.get('market_rates'):
                    normalized=dict(data['market_rates']); self._market_quotes=dict(data.get('market_quotes') or {})
                    if normalized.get('USD',0)>0 and normalized.get('AFN',0)>0:
                        self._online_rates.update(normalized); self._rates_updated=datetime.now().strftime('%Y-%m-%d %H:%M'); self._rates_source=data['source']; self._rates_online_ok=True; ok=True
                        stamp=data.get('source_date') or self._rates_updated
                        for code,r in normalized.items():
                            self.db.execute("INSERT INTO exchange_rates(code,rate_to_afn,updated,source) VALUES(?,?,?,?) ON CONFLICT(code) DO UPDATE SET rate_to_afn=excluded.rate_to_afn,updated=excluded.updated,source=excluded.source",(code,float(r),stamp,data['source']))
                        self.db.commit()
                if not ok:
                    rows=self.db.execute("SELECT code,rate_to_afn,updated,source FROM exchange_rates").fetchall()
                    for code,r,dt,*_ in rows: self._online_rates[code]=float(r)
                    if rows:self._rates_updated=max((r[2] for r in rows),default='')
                    self._rates_online_ok=False
                if hasattr(self,'_rates_status_label'):
                    try:
                        if ok:self._rates_status_label.config(text='● نرخ آنلاین بروزرسانی شد | '+self._rates_source+' | '+self._rates_updated,fg='#15803d')
                        elif self._rates_updated:self._rates_status_label.config(text='● اتصال آنلاین ناموفق؛ نرخ ذخیره‌شده نمایش داده شد',fg='#b45309')
                        else:self._rates_status_label.config(text='● دریافت نرخ آنلاین ناموفق بود',fg='#b91c1c')
                    except Exception: pass
                self._update_dashboard_fx_panel()
                if on_done:
                    try:on_done()
                    except Exception:pass
                if not ok and not silent:
                    detail='\n'.join(errors[-3:]) if errors else 'خطای نامشخص'
                    try: messagebox.showwarning('نرخ ارز','اتصال آنلاین به منبع انتخاب‌شده برقرار نشد.\n\n'+detail+'\n\nدر صورت نیاز، منبع دیگری را انتخاب کنید.')
                    except Exception:pass
                elif ok and not silent:
                    try: messagebox.showinfo('نرخ ارز',f'نرخ بازار انتخاب‌شده از اینترنت دریافت شد.\n\nمنبع: {self._rates_source}\nزمان دریافت: {self._rates_updated}')
                    except Exception:pass
            try:self.after(0,apply)
            except Exception:pass
        threading.Thread(target=worker,daemon=True).start()

    def _converter_rate(self, code):
        """Latest AFN-per-unit rate from the live Afghan market feed."""
        names={'AFN':'AFN - افغانی','IRR':'IRR - تومان','USD':'USD - دلار آمریکا','EUR':'EUR - یورو','PKR':'PKR - کلدار'}
        return self.get_rate_to_afn(names.get(code, code))

    def _converter_currency_label(self, code):
        return {'AFN':'افغانی','IRR':'تومان','USD':'دلار آمریکا','EUR':'یورو','PKR':'کلدار'}.get(code, code)

    def _converter_parse_amount(self, value):
        try:
            # Accept Persian/Arabic digits, commas, dots and common thousands separators.
            trans=str(value).translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
            trans=trans.replace('٬','').replace('،','').replace(',','').strip()
            d=D(trans)
            return d if d>0 else None
        except Exception:
            return None

    def _converter_quote(self, code):
        q=getattr(self,'_market_quotes',{}).get(code)
        if q:
            try:
                return float(q.get('buy',0) or 0), float(q.get('sell',0) or 0)
            except Exception:
                pass
        r=self._converter_rate(code)
        return (float(r),float(r)) if r>0 else (0.0,0.0)

    def currency_converter_page(self):
        """Complete live Afghan-market currency converter."""
        self.clear()
        bg='#F4F6F8'
        RTLLabel(self.main,text='⇄  تبدیل ارز آنلاین',bg=bg,fg='#B58E45',font=ui_font(21,'bold')).pack(anchor='e',padx=22,pady=(16,3))
        RTLLabel(self.main,text='منبع نرخ را انتخاب کنید؛ نرخ همان بازار به‌صورت آنلاین دریافت می‌شود.',bg=bg,fg='#687582',font=ui_font(9)).pack(anchor='e',padx=22,pady=(0,6))

        box=tk.Frame(self.main,bg='#FFFFFF',highlightbackground='#D8DEE4',highlightthickness=1)
        box.pack(fill='x',padx=22,pady=8)
        top=tk.Frame(box,bg='#FFFFFF'); top.pack(fill='x',padx=14,pady=(10,4))
        RTLLabel(top,text='مبدل نرخ زنده بازار افغانستان',bg='#FFFFFF',fg='#B58E45',font=ui_font(13,'bold')).pack(side='right')
        status=RTLLabel(top,text='در حال دریافت نرخ...',bg='#FFFFFF',fg='#64748B',font=ui_font(8,'bold')); status.pack(side='left',padx=8)
        self.converter_status=status

        market_row=tk.Frame(box,bg='#FFFFFF'); market_row.pack(fill='x',padx=18,pady=(4,2))
        RTLLabel(market_row,text='بازار نرخ:',bg='#FFFFFF',fg='#475569',font=ui_font(9,'bold')).pack(side='right',padx=6)
        market_map={'shahzada':'کابل — سرای شهزاده','herat':'هرات — خراسان مارکیت','nimroz':'نیمروز — بازار انصاری'}
        market_values=list(market_map.values()); current_label=market_map.get(getattr(self,'_rate_market_source','shahzada'),'کابل — سرای شهزاده')
        market_var=tk.StringVar(value=current_label)
        market_cb=LocalizedCombobox(market_row,textvariable=market_var,values=market_values,state='readonly',width=28); market_cb.pack(side='right',padx=5)

        amount=tk.StringVar(value='1'); from_var=tk.StringVar(value='AFN'); to_var=tk.StringVar(value='IRR')
        self.converter_amount=amount; self.converter_from=from_var; self.converter_to=to_var
        form=tk.Frame(box,bg='#FFFFFF'); form.pack(fill='x',padx=18,pady=12)
        def field(parent,title,var,values=None):
            f=tk.Frame(parent,bg='#FFFFFF'); f.pack(side='right',fill='x',expand=True,padx=6)
            RTLLabel(f,text=title,bg='#FFFFFF',fg='#475569',font=ui_font(9,'bold')).pack(anchor='e',pady=(0,5))
            if values:
                w=LocalizedCombobox(f,textvariable=var,values=values,state='readonly',justify='right'); w.pack(fill='x',ipady=5)
            else:
                w=tk.Entry(f,textvariable=var,bg='#F8FAFC',fg='#17212B',insertbackground='#17212B',relief='solid',bd=1,highlightthickness=1,highlightbackground='#CBD5E1',highlightcolor='#B58E45',font=ui_font(11),justify='right'); w.pack(fill='x',ipady=7)
            return w
        amount_w=field(form,'مبلغ',amount)
        from_w=field(form,'از ارز',from_var,['AFN','IRR','USD','EUR','PKR'])
        to_w=field(form,'به ارز',to_var,['AFN','IRR','USD','EUR','PKR'])

        result_box=tk.Frame(box,bg='#FFF9ED',highlightbackground='#E8D59A',highlightthickness=1); result_box.pack(fill='x',padx=18,pady=(0,14))
        RTLLabel(result_box,text='نتیجه تبدیل',bg='#FFF9ED',fg='#8A651B',font=ui_font(10,'bold')).pack(anchor='e',padx=14,pady=(8,1))
        result=RTLLabel(result_box,text='—',bg='#FFF9ED',fg='#B58E45',font=ui_font(18,'bold')); result.pack(anchor='e',padx=14,pady=(0,8))
        rate_info=RTLLabel(result_box,text='',bg='#FFF9ED',fg='#7C6A43',font=ui_font(8),justify='right'); rate_info.pack(anchor='e',padx=14,pady=(0,8))

        quote_box=tk.Frame(box,bg='#F8FAFC',highlightbackground='#E2E8F0',highlightthickness=1); quote_box.pack(fill='x',padx=18,pady=(0,12))
        quote_title=RTLLabel(quote_box,text='نرخ زنده فعلی',bg='#F8FAFC',fg='#334155',font=ui_font(10,'bold')); quote_title.pack(anchor='e',padx=12,pady=(7,2))
        quote_label=RTLLabel(quote_box,text='—',bg='#F8FAFC',fg='#475569',font=ui_font(9),justify='right'); quote_label.pack(anchor='e',padx=12,pady=(0,8))

        def convert():
            d=self._converter_parse_amount(amount.get())
            if d is None:
                result.config(text='مبلغ معتبر وارد کنید'); rate_info.config(text=''); return
            a=from_var.get(); b=to_var.get()
            ra=self._converter_rate(a); rb=self._converter_rate(b)
            if a==b:
                out=d; pair_rate=Decimal('1')
            elif ra>0 and rb>0:
                pair_rate=Decimal(str(ra))/Decimal(str(rb)); out=d*pair_rate
            else:
                result.config(text='نرخ زنده بازار در دسترس نیست'); rate_info.config(text='دریافت نرخ زنده را بزنید و دوباره محاسبه کنید.'); return
            # Converter result: keep useful fractional value, but never flood the UI with long decimals.
            # Display up to 2 decimal places, with dot as thousands separator and comma as decimal mark.
            result_value = fmt_num(float(out), 2)
            result.config(text=f'{result_value} {self._converter_currency_label(b)}')
            source_text=getattr(self,'_rates_source','بازار افغانستان')
            rate_info.config(text=f'۱ {self._converter_currency_label(a)} = {fmt_fx_rate(pair_rate)} {self._converter_currency_label(b)}  |  {source_text}  |  {getattr(self,"_rates_updated","")}')
            bu,bs=self._converter_quote(b)
            if b=='IRR':
                quote_label.config(text=f'هر ۱٬۰۰۰ تومان: خرید {fmt_fx_rate(bu*1000)} افغانی | فروش {fmt_fx_rate(bs*1000)} افغانی | میانگین {fmt_fx_rate((bu+bs)*500)} افغانی')
            elif b=='PKR':
                quote_label.config(text=f'هر ۱٬۰۰۰ کلدار: خرید {fmt_fx_rate(bu*1000)} افغانی | فروش {fmt_fx_rate(bs*1000)} افغانی | میانگین {fmt_fx_rate((bu+bs)*500)} افغانی')
            elif b=='AFN':
                quote_label.config(text='هر ۱ افغانی = ۱ افغانی')
            else:
                quote_label.config(text=f'هر ۱ {self._converter_currency_label(b)}: خرید {fmt_fx_rate(bu)} افغانی | فروش {fmt_fx_rate(bs)} افغانی | میانگین {fmt_fx_rate((bu+bs)/2)} افغانی')

        def update_rate_status():
            try:
                if getattr(self,'_rates_online_ok',False):
                    status.config(text=f'● آنلاین بازار افغانستان | {self._rates_updated}',fg='#15803D')
                    convert()
                else:
                    status.config(text='● نرخ بازار افغانستان دریافت نشد',fg='#B91C1C')
                    result.config(text='—'); rate_info.config(text='ابتدا نرخ زنده بازار افغانستان را دریافت کنید.')
            except Exception:
                pass

        def refresh():
            rev={v:k for k,v in market_map.items()}; self._rate_market_source=rev.get(market_var.get(),'shahzada')
            status.config(text='● در حال دریافت نرخ بازار انتخاب‌شده...',fg='#2563EB')
            self.refresh_online_rates(silent=True,on_done=update_rate_status,market_source=self._rate_market_source)

        def market_changed(_=None):
            refresh()

        def swap():
            a=from_var.get(); from_var.set(to_var.get()); to_var.set(a); convert()

        self.button(form,'⇄ جابجایی',swap,'#334155').pack(side='right',padx=5,pady=(22,0),ipadx=7,ipady=5)
        self.button(box,'محاسبه با نرخ فعلی',convert,'#0F766E').pack(side='right',padx=18,pady=(0,12),ipady=5)
        self.button(box,'⟳ دریافت نرخ زنده بازار',refresh,'#B58E45').pack(side='right',padx=5,pady=(0,12),ipady=5)
        market_cb.bind('<<ComboboxSelected>>',market_changed)
        self.converter_convert=convert; self.converter_refresh=refresh
        amount_w.bind('<KeyRelease>',lambda e: convert())
        from_w.bind('<<ComboboxSelected>>',lambda e: convert()); to_w.bind('<<ComboboxSelected>>',lambda e: convert())
        self.after(50,refresh)

    def _scheduled_rate_refresh(self):
        try:
            self.refresh_online_rates()
        finally:
            try:self.after(1800000, self._scheduled_rate_refresh)
            except Exception:pass

    def get_rate_to_afn(self, currency):
        code=CURRENCY_CODES.get(currency,currency.split(' ')[0] if currency else 'AFN')
        if code=='AFN': return 1.0
        r=float(self._online_rates.get(code,0) or 0)
        if r>0:return r
        row=self.db.execute("SELECT rate_to_afn FROM exchange_rates WHERE code=?",(code,)).fetchone()
        return float(row[0]) if row and row[0] else 0.0

    def load_customers(self,tree,q=""):
        for i in tree.get_children(): tree.delete(i)
        rows=self.db.execute("""SELECT id,name,phone,address FROM customers
                                WHERE name LIKE ? OR phone LIKE ? ORDER BY id DESC""",
                             (f"%{q}%",f"%{q}%")).fetchall()
        for r in rows:
            rec,pay,net,label=self.customer_display_balance(r[0])
            tree.insert("", "end", values=(r[0],r[1],r[2],r[3],f"{fmt_num(rec)}",f"{fmt_num(pay)}",f"{fmt_num(net)}",label))

    def edit_customer(self,cid):
        # Open the same editor directly from the unified customer account page.
        # The previous proxy returned None for item(..., "values"), so this
        # button appeared to do nothing.
        class _Proxy:
            def selection(self_inner): return ["selected"]
            def item(self_inner,_iid,_key=None):
                data={"values":[cid]}
                return data if _key is None else data.get(_key)
        self.edit_selected_customer(_Proxy())

    def edit_selected_customer(self,tree):
        """Open the selected customer's complete profile for editing.
        Name/phone/address/notes are updated everywhere the customer is linked,
        while the customer_id remains unchanged so all history stays attached.
        """
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("ویرایش مشتری","ابتدا یک مشتری را انتخاب کنید.")
            return
        try:
            cid=int(tree.item(sel[0],"values")[0])
        except Exception:
            return
        row=self.db.execute("SELECT id,name,phone,address,notes FROM customers WHERE id=?",(cid,)).fetchone()
        if not row:
            return

        win=tk.Toplevel(self); win.title("ویرایش مشخصات مشتری"); win.geometry("560x650"); win.configure(bg="#F4F6F8")
        self._prepare_toplevel(win,520,600)
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=28,pady=22)
        RTLLabel(outer,text="ویرایش مشخصات مشتری",bg="#F4F6F8",fg="#17212B",font=ui_font(19,"bold")).pack(anchor="e",pady=(0,4))
        RTLLabel(outer,text="نام، شماره تماس، آدرس و یادداشت مشتری را ویرایش کنید.",bg="#F4F6F8",fg="#64748B",font=ui_font(9)).pack(anchor="e",pady=(0,18))

        fields=[]
        specs=[
            ("نام مشتری *","نام و نام خانوادگی یا نام شرکت",False,row[1] or ""),
            ("شماره تماس","شماره تلفن مشتری",False,row[2] or ""),
            ("آدرس","آدرس یا محل مشتری",False,row[3] or ""),
            ("یادداشت","توضیحات اضافی درباره مشتری",True,row[4] or ""),
        ]
        for label,placeholder,multi,value in specs:
            cell=tk.Frame(outer,bg="#F4F6F8"); cell.pack(fill="x",pady=(0,13))
            RTLLabel(cell,text=label,bg="#F4F6F8",fg="#17212B",font=ui_font(10,"bold")).pack(anchor="e",pady=(0,5))
            if multi:
                e=tk.Text(cell,height=4,bg="#FFFFFF",fg="#17212B",insertbackground="#17212B",relief="solid",bd=1,highlightthickness=1,highlightbackground="#CBD5E1",highlightcolor="#2D7FA3",font=ui_font(10),wrap="word")
                e.pack(fill="x",ipady=5); e.insert("1.0",value)
            else:
                e=tk.Entry(cell,bg="#FFFFFF",fg="#17212B",insertbackground="#17212B",relief="solid",bd=1,highlightthickness=1,highlightbackground="#CBD5E1",highlightcolor="#2D7FA3",font=ui_font(10),justify="right")
                e.pack(fill="x",ipady=9); e.insert(0,value)
            RTLLabel(cell,text=placeholder,bg="#F4F6F8",fg="#94A3B8",font=ui_font(8)).pack(anchor="e",pady=(3,0))
            fields.append(e)

        btnbar=tk.Frame(outer,bg="#F4F6F8"); btnbar.pack(fill="x",pady=(8,0))
        def getv(e):
            return e.get("1.0","end").strip() if isinstance(e,tk.Text) else e.get().strip()
        def save():
            name,phone,address,notes=[getv(e) for e in fields]
            if not name:
                messagebox.showwarning("ویرایش مشتری","لطفاً نام مشتری را وارد کنید.",parent=win); fields[0].focus_set(); return
            try:
                old_name=row[1]
                self.db.execute("UPDATE customers SET name=?,phone=?,address=?,notes=? WHERE id=?",(name,phone,address,notes,cid))
                # Keep denormalized customer fields synchronized without changing IDs/history.
                for table in ("account_entries","receipts","transactions","invoices","retail_sales"):
                    cols=[r[1] for r in self.db.execute(f"PRAGMA table_info({table})").fetchall()]
                    if "customer_id" in cols and "customer" in cols:
                        self.db.execute(f"UPDATE {table} SET customer=? WHERE customer_id=?",(name,cid))
                    if table in ("invoices","retail_sales") and "phone" in cols:
                        self.db.execute(f"UPDATE {table} SET phone=? WHERE customer_id=?",(phone,cid))
                wa_cols=[r[1] for r in self.db.execute("PRAGMA table_info(whatsapp_receipts)").fetchall()]
                if "customer_id" in wa_cols and "customer_name" in wa_cols:
                    self.db.execute("UPDATE whatsapp_receipts SET customer_name=? WHERE customer_id=?",(name,cid))
                self.db.commit()
            except Exception as exc:
                self.db.rollback()
                messagebox.showerror("خطا در ویرایش مشتری",f"ذخیره مشخصات انجام نشد:\n{exc}",parent=win); return
            win.destroy()
            self.customers_page()

        self.button(btnbar,"✓ ذخیره تغییرات",save,"#0F766E").pack(fill="x",ipady=6)
        self.button(btnbar,"انصراف",win.destroy,"#64748B").pack(fill="x",pady=(8,0),ipady=4)
        win.after(120,lambda: fields[0].focus_set())

    def delete_selected_customer(self,tree):
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("حذف مشتری","ابتدا یک مشتری را انتخاب کنید."); return
        cid=tree.item(sel[0],"values")[0]
        row=self.db.execute("SELECT name FROM customers WHERE id=?",(cid,)).fetchone()
        if not row:return
        if not messagebox.askyesno("تأیید حذف",f"آیا مشتری «{row[0]}» و حساب‌های وابسته او حذف شود؟\nاین عملیات قابل برگشت نیست."):
            return
        self.db.execute("DELETE FROM account_entries WHERE customer_id=?",(cid,))
        self.db.execute("DELETE FROM receipts WHERE customer_id=?",(cid,))
        self.db.execute("DELETE FROM invoice_items WHERE invoice_id IN (SELECT id FROM invoices WHERE customer_id=?)",(cid,))
        self.db.execute("DELETE FROM invoices WHERE customer_id=?",(cid,))
        self.db.execute("DELETE FROM customers WHERE id=?",(cid,))
        self.db.commit(); self.customers_page()

    def add_customer(self):
        # V16.5 repair: labels were previously placed in the exact same grid
        # cell as their Entry widgets, so the Entry covered the label.
        # Use one field frame per item so every label is always visible.
        win=tk.Toplevel(self); win.title("ثبت مشتری جدید"); win.geometry("560x650"); win.configure(bg="#F4F6F8")
        self._prepare_toplevel(win,520,600)
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=28,pady=22)
        outer.columnconfigure(0,weight=1)
        RTLLabel(outer,text="ثبت مشتری جدید",bg="#F4F6F8",fg="#17212B",font=ui_font(19,"bold")).pack(anchor="e",pady=(0,4))
        RTLLabel(outer,text="اطلاعات مشتری را وارد کنید. فیلد «نام مشتری» الزامی است.",bg="#F4F6F8",fg="#64748B",font=ui_font(9)).pack(anchor="e",pady=(0,18))

        fields=[]
        specs=[
            ("نام مشتری *","نام و نام خانوادگی یا نام شرکت",False),
            ("شماره تماس","شماره تلفن مشتری",False),
            ("آدرس","آدرس یا محل مشتری",False),
            ("یادداشت","توضیحات اضافی درباره مشتری",True),
        ]
        for label,placeholder,multi in specs:
            cell=tk.Frame(outer,bg="#F4F6F8"); cell.pack(fill="x",pady=(0,13))
            RTLLabel(cell,text=label,bg="#F4F6F8",fg="#17212B",font=ui_font(10,"bold")).pack(anchor="e",pady=(0,5))
            if multi:
                e=tk.Text(cell,height=4,bg="#FFFFFF",fg="#17212B",insertbackground="#17212B",relief="solid",bd=1,highlightthickness=1,highlightbackground="#CBD5E1",highlightcolor="#2D7FA3",font=ui_font(10),wrap="word")
                e.pack(fill="x",ipady=5)
            else:
                e=tk.Entry(cell,bg="#FFFFFF",fg="#17212B",insertbackground="#17212B",relief="solid",bd=1,highlightthickness=1,highlightbackground="#CBD5E1",highlightcolor="#2D7FA3",font=ui_font(10),justify="right")
                e.pack(fill="x",ipady=9)
            RTLLabel(cell,text=placeholder,bg="#F4F6F8",fg="#94A3B8",font=ui_font(8)).pack(anchor="e",pady=(3,0))
            fields.append(e)

        btnbar=tk.Frame(outer,bg="#F4F6F8"); btnbar.pack(fill="x",pady=(8,0))
        def getv(e):
            return e.get("1.0","end").strip() if isinstance(e,tk.Text) else e.get().strip()
        def save():
            name,phone,address,notes=[getv(e) for e in fields]
            if not name:
                messagebox.showwarning("ثبت مشتری","لطفاً نام مشتری را وارد کنید.",parent=win); fields[0].focus_set(); return
            self.db.execute("INSERT INTO customers(name,phone,address,notes) VALUES(?,?,?,?)",(name,phone,address,notes)); self.db.commit()
            win.destroy(); self.customers_page()
        self.button(btnbar,"✓ ذخیره مشتری",save,"#0F766E").pack(fill="x",ipady=6)
        self.button(btnbar,"انصراف",win.destroy,"#64748B").pack(fill="x",pady=(8,0),ipady=4)
        win.after(120,lambda: fields[0].focus_set())

    def get_customer_list(self):
        return self.db.execute("SELECT id,name FROM customers ORDER BY name").fetchall()

    def open_selected_account(self,tree):
        sel=tree.selection()
        if not sel: return
        cid=int(tree.item(sel[0],"values")[0])
        self.customer_account(cid)

    def customer_finance_center_page(self):
        """مرکز یکپارچه مشتری: یک دکمه برای تمام حسابات مشتری و تمام رسیدها."""
        self.clear()
        self._set_ui_direction()
        now=datetime.now()

        head=tk.Frame(self.main,bg="#F4F6F8")
        head.pack(fill="x",padx=20,pady=(10,4))
        RTLLabel(head,text="📒 حسابات و رسیدهای مشتری",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(21,"bold")).pack(anchor="e")
        RTLLabel(head,text=f"تمام حساب‌های مشتریان و تمام رسیدها در یک مرکز واحد | {jalali_date(now)} | {now:%H:%M:%S}",
                 bg="#F4F6F8",fg="#0F766E",font=ui_font(10,"bold")).pack(anchor="e",pady=(3,8))

        # Right-to-left section switcher: one button opens the whole customer finance center.
        switch=tk.Frame(self.main,bg="#F4F6F8")
        switch.pack(fill="x",padx=20,pady=(0,8))
        panel_holder=tk.Frame(self.main,bg="#F4F6F8")
        panel_holder.pack(fill="both",expand=True,padx=20,pady=(0,12))

        account_panel=tk.Frame(panel_holder,bg="#F4F6F8")
        receipt_panel=tk.Frame(panel_holder,bg="#F4F6F8")
        panels={"accounts":account_panel,"receipts":receipt_panel}

        def show_panel(which):
            for p in panels.values(): p.pack_forget()
            panels[which].pack(fill="both",expand=True)
            for key,btn in tabs.items():
                active=(key==which)
                btn.configure(bg="#0F766E" if active else "#FFFFFF",
                              fg="#FFFFFF" if active else "#334155")
            try: self.main.update_idletasks()
            except Exception: pass

        tabs={}
        tabs["accounts"]=self.button(switch,"📒  تمامی حساب‌های مشتری",lambda:show_panel("accounts"),"#0F766E")
        tabs["accounts"].pack(side="right",padx=(0,6),ipadx=14,ipady=5)
        tabs["receipts"]=self.button(switch,"🧾  تمامی رسیدهای مشتری",lambda:show_panel("receipts"),"#FFFFFF")
        tabs["receipts"].configure(fg="#334155")
        tabs["receipts"].pack(side="right",padx=6,ipadx=14,ipady=5)
        self.button(switch,"＋ ثبت قرض/بستانکاری",self.quick_account_entry,"#2563EB").pack(side="left",padx=4,ipadx=8,ipady=5)
        self.button(switch,"＋ ثبت رسید جدید",self.register_receipt_page,"#7C3AED").pack(side="left",padx=4,ipadx=8,ipady=5)

        # ---------- All customer accounts ----------
        account_top=tk.Frame(account_panel,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        account_top.pack(fill="x",pady=(0,8))
        RTLLabel(account_top,text="📒 دفتر جامع حساب مشتریان",bg="#FFFFFF",fg="#1B2733",font=ui_font(14,"bold")).pack(anchor="e",padx=14,pady=(10,2))
        RTLLabel(account_top,text="در این بخش تمام قرضداری و بستانکاری همه مشتریان دیده می‌شود؛ رسیدها در تب مستقل کنار آن هستند.",bg="#FFFFFF",fg="#64748B",font=ui_font(9)).pack(anchor="e",padx=14,pady=(0,8))
        account_bar=tk.Frame(account_top,bg="#FFFFFF"); account_bar.pack(fill="x",padx=12,pady=(0,10))
        names=self.get_customer_list()
        cb=LocalizedCombobox(account_bar,values=[f"{i} - {n}" for i,n in names],state="readonly",width=35)
        cb.pack(side="right",padx=6)
        RTLLabel(account_bar,text="مشتری:",bg="#FFFFFF",fg="#1B2733",font=ui_font(10,"bold")).pack(side="right")
        self.button(account_bar,"📒 باز کردن حساب",lambda:self.account_from_combo(cb,names)).pack(side="right",padx=4)
        self.button(account_bar,"📱 واتساپ",lambda:self.send_from_combo(cb,names,"wa"),"#128c7e").pack(side="left",padx=3)
        self.button(account_bar,"✈ تلگرام",lambda:self.send_from_combo(cb,names,"tg"),"#229ed9").pack(side="left",padx=3)
        self.button(account_bar,"📊 Excel",lambda:self.export_customer_accounts_xlsx(account_tree),"#0f766e").pack(side="left",padx=3)

        account_box=tk.Frame(account_panel,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        account_box.pack(fill="both",expand=True)
        account_cols=("name","receivable","payable","commission","net","currency")
        account_tree=ttk.Treeview(account_box,columns=account_cols,show="headings",style="Jahan.Treeview")
        for x,h in zip(account_cols,["مشتری","قرضدار مشتری","بستانکاری مشتری","جمع کمیشن","مانده خالص","ارز"]):
            account_tree.heading(x,text=_icu_shape_arabic(h)); account_tree.column(x,anchor="e",width=155 if x!="currency" else 100)
        self._pack_with_scrollbar(account_tree,fill="both",expand=True,padx=10,pady=10)
        for cid,name in names:
            rec,pay,net,label=self.customer_display_balance(cid)
            comm=self.customer_commission_summary(cid)
            account_tree.insert("","end",values=(name,fmt_num(rec),fmt_num(pay),comm,fmt_num(net),label))
        account_tree.bind("<Double-1>",lambda e:self.open_selected_account(account_tree))
        # مدیریت کامل حساب: از اینجا کاربر وارد دفتر جزئیات می‌شود و می‌تواند
        # هر قرضداری یا بستانکاری را جداگانه ویرایش یا حذف کند.
        account_actions=tk.Frame(account_panel,bg="#F4F6F8")
        account_actions.pack(fill="x",pady=(0,8))
        self.button(account_actions,"📒 مدیریت حساب انتخاب‌شده",lambda:self.open_selected_account(account_tree),"#0F766E").pack(side="right",padx=4)
        RTLLabel(account_actions,text="در دفتر جزئیات، ویرایش و حذف تک‌تک قرضداری‌ها و بستانکاری‌ها انجام می‌شود.",
                 bg="#F4F6F8",fg="#64748B",font=ui_font(9)).pack(side="right",padx=8)

        # ---------- All customer receipts ----------
        receipt_top=tk.Frame(receipt_panel,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        receipt_top.pack(fill="x",pady=(0,8))
        RTLLabel(receipt_top,text="🧾 دفتر جامع رسیدهای مشتری",bg="#FFFFFF",fg="#1B2733",font=ui_font(14,"bold")).pack(anchor="e",padx=14,pady=(10,2))
        RTLLabel(receipt_top,text="تمام رسیدهای مشتریان در همین تب قرار دارد؛ ثبت، مشاهده و چاپ رسید از همین مرکز انجام می‌شود.",bg="#FFFFFF",fg="#64748B",font=ui_font(9)).pack(anchor="e",padx=14,pady=(0,8))
        receipt_bar=tk.Frame(receipt_top,bg="#FFFFFF"); receipt_bar.pack(fill="x",padx=12,pady=(0,10))
        self.button(receipt_bar,"＋ ثبت رسید مشتری",self.register_receipt_page,"#0F766E").pack(side="right",padx=4)
        self.button(receipt_bar,"📋 همه رسیدها",self.receipts_list_page,"#2563EB").pack(side="right",padx=4)
        self.button(receipt_bar,"📅 رسیدهای روزانه",self.daily_customer_receipts_page,"#7C3AED").pack(side="right",padx=4)
        receipt_tree_box=tk.Frame(receipt_panel,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        receipt_tree_box.pack(fill="both",expand=True)
        receipt_cols=("no","date","customer","type","amount","currency","commission","commission_currency")
        receipt_tree=ttk.Treeview(receipt_tree_box,columns=receipt_cols,show="headings",style="Jahan.Treeview")
        heads={"no":"شماره رسید","date":"تاریخ","customer":"مشتری","type":"نوع رسید","amount":"مبلغ","currency":"ارز","commission":"کمیشن","commission_currency":"ارز کمیشن"}
        for x in receipt_cols:
            receipt_tree.heading(x,text=_display_text(heads[x])); receipt_tree._jahan_original_headings=heads; receipt_tree.column(x,width=125,anchor="e")
        receipt_tree.column("customer",width=180,anchor="e")
        self._pack_with_scrollbar(receipt_tree,fill="both",expand=True,padx=10,pady=10)
        for r in self.db.execute("SELECT id,receipt_no,created,customer,receipt_type,amount,COALESCE(currency,'AFN - افغانی'),COALESCE(commission,0),COALESCE(commission_currency,currency,'AFN - افغانی') FROM receipts ORDER BY id DESC"):
            receipt_tree.insert("","end",iid=str(r[0]),values=(r[1],dual_datetime(r[2]),r[3],r[4],fmt_money_exact(r[5]),r[6],fmt_money_exact(r[7]),r[8]))
        def selected_receipt_id():
            sel=receipt_tree.selection()
            if not sel:return None
            try:return int(sel[0])
            except Exception:return None
        def open_receipt():
            rid=selected_receipt_id()
            if rid is not None:self.show_receipt_by_id(rid)
        def edit_receipt():
            rid=selected_receipt_id()
            if rid is not None:self.edit_receipt_page(rid)
        def delete_receipt():
            rid=selected_receipt_id()
            if rid is not None:self.delete_receipt(rid)
        receipt_actions=tk.Frame(receipt_panel,bg="#F4F6F8")
        receipt_actions.pack(fill="x",pady=8)
        self.button(receipt_actions,"✏ ویرایش رسید انتخاب‌شده",edit_receipt,"#0F766E").pack(side="right",padx=4)
        self.button(receipt_actions,"🗑 حذف رسید انتخاب‌شده",delete_receipt,"#B42318").pack(side="right",padx=4)
        self.button(receipt_actions,"👁 مشاهده / چاپ رسید",open_receipt,"#2563EB").pack(side="right",padx=4)
        RTLLabel(receipt_actions,text="رسید انتخاب کنید، سپس ویرایش یا حذف را بزنید.",
                 bg="#F4F6F8",fg="#64748B",font=ui_font(9)).pack(side="right",padx=8)
        receipt_tree.bind("<Double-1>",lambda e:open_receipt(),add="+")
        receipt_tree.bind("<Delete>",lambda e:delete_receipt(),add="+")

        show_panel("accounts")

    def accounts_page(self):
        self.clear()
        RTLLabel(self.main,text="حساب مشتریان",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=5)
        RTLLabel(bar,text="مشتری:",bg="#F4F6F8",fg="#1B2733",font=ui_font(10)).pack(side="right")
        names=self.get_customer_list()
        cb=LocalizedCombobox(bar,values=[f"{i} - {n}" for i,n in names],state="readonly",width=35)
        cb.pack(side="right",padx=8)
        self.button(bar,"📒 باز کردن حساب",lambda:self.account_from_combo(cb,names)).pack(side="right")
        def add_selected_account(entry_type):
            if cb.current()<0:
                messagebox.showwarning("ثبت حساب","ابتدا یک مشتری را انتخاب کنید.")
                return
            cid=names[cb.current()][0]
            self.add_account_entry(cid,entry_type)
        self.button(bar,"＋ قرض جدید",lambda:add_selected_account("قرضداری مشتری"),"#B42318").pack(side="left",padx=3)
        self.button(bar,"＋ بستانکاری جدید",lambda:add_selected_account("بستانکاری مشتری"),"#157347").pack(side="left",padx=3)
        self.button(bar,"＋ ثبت قرض/بستانکاری",self.quick_account_entry).pack(side="left",padx=3)
        self.button(bar,"📱 واتساپ",lambda:self.send_from_combo(cb,names,"wa"),"#128c7e").pack(side="left",padx=4)
        self.button(bar,"✈ تلگرام",lambda:self.send_from_combo(cb,names,"tg"),"#229ed9").pack(side="left",padx=4)
        cols=("name","receivable","payable","commission","net","currency")
        tree=ttk.Treeview(self.main,columns=cols,show="headings",style="Jahan.Accounts.Treeview")
        for x,h in zip(cols,["مشتری","قرضدار مشتری","بستانکاری مشتری","جمع کمیشن","مانده خالص","ارز"]):
            tree.heading(x,text=_icu_shape_arabic(h)); tree.column(x,anchor="center",width=170 if x!="currency" else 100)
        self.button(bar,"📊 خروجی Excel",lambda:self.export_customer_accounts_xlsx(tree),"#0f766e").pack(side="left",padx=4)
        self.button(bar,"📄 خروجی PDF حسابات",self.export_customer_accounts_pdf,"#B58E45").pack(side="left",padx=4)
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=15)
        for cid,name in names:
            rec,pay,net,label=self.customer_display_balance(cid)
            comm=self.customer_commission_summary(cid)
            tree.insert("", "end", values=(name,f"{fmt_num(rec)}",f"{fmt_num(pay)}",comm,f"{fmt_num(net)}",label))

    def export_customer_accounts_pdf(self):
        """خروجی PDF حرفه‌ای و یکپارچه برای تمام حسابات مشتریان.
        شامل خلاصه همه مشتریان + مانده‌ها، کمیشن و رسیدهای هر مشتری است.
        """
        if not REPORTLAB_OK:
            messagebox.showerror("PDF", "کتابخانه PDF در این نسخه نصب نیست.")
            return None
        path=filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf")],
            initialfile="حسابات_کامل_مشتریان.pdf"
        )
        if not path:
            return None

        font=self._pdf_font()
        page_size=landscape(A4)
        doc=SimpleDocTemplate(
            path, pagesize=page_size, rightMargin=24, leftMargin=24,
            topMargin=42, bottomMargin=34,
            title="گزارش کامل حسابات مشتریان", author="Jahan Accounting"
        )
        styles=getSampleStyleSheet()
        title_style=ParagraphStyle("JAllTitle", parent=styles["Title"], fontName=font,
            fontSize=18, leading=24, alignment=TA_RIGHT,
            textColor=colors.HexColor("#1B2733"), spaceAfter=4)
        sub_style=ParagraphStyle("JAllSub", parent=styles["Normal"], fontName=font,
            fontSize=10, leading=15, alignment=TA_RIGHT,
            textColor=colors.HexColor("#687582"), spaceAfter=6)
        body_style=ParagraphStyle("JAllBody", parent=styles["Normal"], fontName=font,
            fontSize=9.5, leading=13.5, alignment=TA_RIGHT,
            textColor=colors.HexColor("#1B2733"))
        center_style=ParagraphStyle("JAllCenter", parent=body_style, alignment=TA_CENTER)

        story=[]
        logo_path=os.path.join(RESOURCE_BASE,"logo.png")
        if not os.path.exists(logo_path):
            logo_path=os.path.join(BASE,"logo.png")
        if os.path.exists(logo_path):
            try:
                logo=Image(logo_path,width=52,height=52)
                logo.hAlign="CENTER"
                story += [logo, Spacer(1,3)]
            except Exception:
                pass

        op=self._outgoing_profile_dict()
        if op.get("outgoing_name"):
            story.append(Paragraph(self._pdf_text(op["outgoing_name"]), title_style))
            meta=" | ".join(x for x in (op.get("outgoing_type"), op.get("outgoing_phone"), op.get("outgoing_address")) if x)
            if meta:
                story.append(Paragraph(self._pdf_text(meta), sub_style))
        story.append(Paragraph(self._pdf_text("گزارش کامل حسابات مشتریان"), title_style))
        story.append(Paragraph(self._pdf_text(f"تاریخ تهیه گزارش: {dual_datetime(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}"), sub_style))

        def add_table(headers, rows, font_size=9.5):
            rtl_headers=list(reversed(headers))
            data=[[Paragraph(self._pdf_text(str(h)), center_style) for h in rtl_headers]]
            for rr in rows:
                vals=list(reversed([str(x) for x in rr]))
                data.append([Paragraph(self._pdf_text(x), body_style) for x in vals])
            ncols=len(rtl_headers)
            total_width=page_size[0]-48
            if ncols == 6:
                widths=[80,120,115,115,115,total_width-545]
            elif ncols == 7:
                widths=[55,85,95,85,95,75,total_width-490]
            elif ncols == 8:
                widths=[55,70,95,70,70,75,75,total_width-510]
            else:
                widths=[total_width/max(ncols,1)]*ncols
            if widths:
                widths[-1]+=total_width-sum(widths)
            tt=Table(data, repeatRows=1, colWidths=widths, hAlign="RIGHT")
            cmds=[
                ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17212B")),
                ("TEXTCOLOR",(0,0),(-1,0),colors.white),
                ("GRID",(0,0),(-1,-1),0.45,colors.HexColor("#CBD5E1")),
                ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                ("ALIGN",(0,0),(-1,-1),"RIGHT"),
                ("TOPPADDING",(0,0),(-1,-1),4.5),
                ("BOTTOMPADDING",(0,0),(-1,-1),4.5),
                ("RIGHTPADDING",(0,0),(-1,-1),5),
                ("LEFTPADDING",(0,0),(-1,-1),5),
            ]
            for idx in range(1,len(data)):
                if idx % 2 == 0:
                    cmds.append(("BACKGROUND",(0,idx),(-1,idx),colors.HexColor("#F7F9FB")))
            tt.setStyle(TableStyle(cmds))
            story.extend([tt, Spacer(1,9)])

        customers=self.db.execute("SELECT id,name,phone,address,notes FROM customers ORDER BY name COLLATE NOCASE").fetchall()
        summary=[]
        for cid,name,phone,address,notes in customers:
            rec,pay,net,label=self.customer_display_balance(cid)
            comm=self.customer_commission_summary(cid)
            currencies=self.customer_currency_balances(cid)
            currency_text=", ".join(CURRENCY_CODES.get(c,c.split(" - ")[0] if c else c) for c,_,_,_ in currencies) or "AFN"
            summary.append([name, currency_text, fmt_num(rec), fmt_num(pay), comm, f"{fmt_num(abs(net))} | {label}"])

        story.append(Paragraph(self._pdf_text("خلاصه همه مشتریان"), sub_style))
        add_table(["مشتری","ارز","قرضدار","بستانکاری/رسید","جمع کمیشن","مانده خالص"], summary or [["-","-","0","0","0","0 | تسویه"]])

        for index,(cid,name,phone,address,notes) in enumerate(customers):
            story.append(PageBreak())
            story.append(Paragraph(self._pdf_text(f"حساب کامل مشتری: {name}"), title_style))
            contact=" | ".join(x for x in (f"تماس: {phone or '-'}", f"آدرس: {address or '-'}") if x)
            story.append(Paragraph(self._pdf_text(contact), sub_style))
            if notes:
                story.append(Paragraph(self._pdf_text(f"توضیحات: {notes}"), body_style))
                story.append(Spacer(1,5))

            totals=[]
            for cur,gd,gc,gb,nd,nc,nb,comm in self.customer_account_totals(cid):
                code=CURRENCY_CODES.get(cur,cur.split(" - ")[0] if cur else cur)
                totals.append([code,fmt_num(abs(gb)),fmt_num(abs(nb)),fmt_num(abs(comm)),fmt_num(nb)])
            story.append(Paragraph(self._pdf_text("خلاصه حساب به تفکیک ارز"), sub_style))
            add_table(["ارز","مجموع حساب بدون کمیشن","مجموع حساب با کمیشن","کمیشن","خالص"],
                      totals or [["-","0","0","0","0"]])

        def _page_footer(canvas, doc_obj):
            canvas.saveState()
            canvas.setFont(font, 7.5)
            canvas.setFillColor(colors.HexColor("#64748B"))
            footer_txt=self._pdf_text(f"نرم افزار حسابداری جهان | گزارش کامل حسابات مشتریان | صفحه {doc_obj.page}")
            canvas.drawRightString(page_size[0]-24,17,footer_txt)
            canvas.restoreState()

        try:
            doc.build(story,onFirstPage=_page_footer,onLaterPages=_page_footer)
            self._open_file(path)
            return path
        except Exception as e:
            messagebox.showerror("PDF",f"ساخت گزارش حسابات مشتریان با خطا روبه‌رو شد:\n{e}")
            return None

    def export_customer_accounts_xlsx(self, tree):
        base="حساب_مشتریان.xlsx"
        path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel Workbook","*.xlsx")],initialfile=base)
        if not path: return
        cols=tree["columns"]; headers=[str(tree.heading(c,"text") or c) for c in cols]
        rows=[tree.item(iid,"values") for iid in tree.get_children()]
        try:
            out=self._export_xlsx_rows(path,headers,rows,title="حساب مشتریان",include_outgoing_profile=True)
            messagebox.showinfo("خروجی Excel",f"فایل حساب مشتریان با مشخصات ارسال ذخیره شد:\n{out}")
        except Exception as e:
            messagebox.showerror("خروجی Excel",str(e))

    def send_from_combo(self, cb, names, channel):
        if cb.current()<0:
            messagebox.showwarning("ارسال حساب","یک مشتری انتخاب کنید."); return
        cid=names[cb.current()][0]
        if channel=="wa": self.send_customer_whatsapp(cid)
        else: self.send_customer_telegram(cid)

    def account_from_combo(self,cb,names):
        if cb.current()<0:
            messagebox.showwarning("حساب مشتری","یک مشتری انتخاب کنید."); return
        cid=names[cb.current()][0]; self.customer_account(cid)

    def notebook_page(self):
        """v20.0.1 professional Persian RTL notebook with KRW-safe storage."""
        self.clear()
        self._set_ui_direction()

        # Prefer a Windows Persian-capable UI font for the notebook.  The
        # stored text is never visually reversed: Tk/Windows handles Arabic
        # shaping and bidi while the editor keeps normal logical text for
        # copy/paste, search and KRW persistence.
        try:
            available_fonts=set(tkfont.families())
            notebook_font=next((name for name in (
                "B Nazanin", "B Nazanin UI", "BNazanin",
                "Segoe UI", "Tahoma", "Noto Naskh Arabic", "Noto Sans Arabic",
                "DejaVu Sans"
            ) if name in available_fonts), UI_FONT)
        except Exception:
            notebook_font=UI_FONT

        # Header / quick actions
        head=tk.Frame(self.main,bg="#F4F6F8")
        head.pack(fill="x",padx=20,pady=(12,7))
        title_box=tk.Frame(head,bg="#F4F6F8")
        title_box.pack(side="right",fill="x",expand=True)
        RTLLabel(title_box,text="📖  کتابچه یادداشت",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(23,"bold")).pack(anchor="e")
        RTLLabel(title_box,text="یادداشت‌های کاری، متن‌های مهم، شماره‌ها و مطالب روزانه را مثل یک دفترچه مرتب نگه دارید.",
                 bg="#F4F6F8",fg="#64748B",font=ui_font(10)).pack(anchor="e",pady=(2,0))

        toolbar=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        toolbar.pack(fill="x",padx=20,pady=(0,10))
        search_var=tk.StringVar()
        search=tk.Entry(toolbar,textvariable=search_var,bg="#F8FAFC",fg="#17212B",
                        insertbackground="#17212B",relief="solid",bd=1,font=ui_font(10),justify="right")
        search.pack(side="right",fill="x",expand=True,padx=(10,6),pady=7,ipady=5)

        body=tk.Frame(self.main,bg="#F4F6F8")
        body.pack(fill="both",expand=True,padx=20,pady=(0,12))

        # Notebook index
        list_box=tk.Frame(body,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1,width=285)
        list_box.pack(side="right",fill="y",padx=(8,0))
        list_box.pack_propagate(False)
        top_list=tk.Frame(list_box,bg="#FFFFFF")
        top_list.pack(fill="x",padx=12,pady=(10,6))
        RTLLabel(top_list,text="فهرست کتابچه",bg="#FFFFFF",fg="#1B2733",
                 font=ui_font(12,"bold")).pack(side="right")
        count_label=RTLLabel(top_list,text="۰ صفحه",bg="#FFFFFF",fg="#64748B",font=ui_font(9))
        count_label.pack(side="left")

        list_area=tk.Frame(list_box,bg="#FFFFFF")
        list_area.pack(fill="both",expand=True,padx=8,pady=(0,8))
        items=tk.Listbox(list_area,bg="#FFFFFF",fg="#17212B",selectbackground="#E9D8AD",
                         selectforeground="#17212B",font=(notebook_font, 11),width=30,
                         relief="flat",highlightthickness=0,activestyle="none",
                         justify="right",exportselection=False)
        items.pack(side="left",fill="both",expand=True)
        sb=tk.Scrollbar(list_area,orient="vertical",command=items.yview,width=12)
        sb.pack(side="right",fill="y")
        items.configure(yscrollcommand=sb.set)

        # Editor card
        editor=tk.Frame(body,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        editor.pack(side="left",fill="both",expand=True)
        editor_head=tk.Frame(editor,bg="#FFFFFF")
        editor_head.pack(fill="x",padx=14,pady=(10,5))
        RTLLabel(editor_head,text="صفحه یادداشت",bg="#FFFFFF",fg="#64748B",font=ui_font(9,"bold")).pack(anchor="e")

        title_var=tk.StringVar()
        title_entry=tk.Entry(editor,textvariable=title_var,bg="#FFFFFF",fg="#17212B",
                             insertbackground="#17212B",font=(notebook_font, 16, "bold"),
                             relief="solid",bd=1,justify="right",
                             highlightthickness=1,highlightbackground="#D8DEE4",
                             highlightcolor="#C9A45C")
        title_entry.pack(fill="x",padx=14,pady=(0,9),ipady=7)

        RTLLabel(editor,text="متن یادداشت",bg="#FFFFFF",fg="#1B2733",
                 font=ui_font(11,"bold")).pack(anchor="e",padx=14,pady=(2,4))
        text_frame=tk.Frame(editor,bg="#FFFFFF")
        text_frame.pack(fill="both",expand=True,padx=14,pady=(0,8))
        # Tk/Windows performs the actual Arabic shaping and bidi layout.
        # Do not reverse or reshape the stored string here: that breaks cursor
        # movement and mixed Persian + numbers.  The notebook uses a dedicated
        # Persian font, right justification, generous line spacing and a small
        # paragraph tag so pasted Persian text remains readable and editable.
        note_text=tk.Text(text_frame,bg="#FFFDF8",fg="#17212B",
                          insertbackground="#17212B",font=(notebook_font, 13),
                          wrap="word",undo=True,relief="solid",bd=1,
                          padx=18,pady=16,spacing1=3,spacing2=2,spacing3=6,
                          highlightthickness=1,highlightbackground="#D8DEE4",
                          highlightcolor="#C9A45C",insertwidth=2)
        note_text.configure(takefocus=True)
        note_text.tag_configure("rtl",justify="right",lmargin1=4,lmargin2=4,rmargin=8)
        note_text.tag_configure("paragraph",justify="right",spacing1=3,spacing2=2,spacing3=6)
        note_text.pack(side="left",fill="both",expand=True)
        nts=tk.Scrollbar(text_frame,orient="vertical",command=note_text.yview,width=12)
        nts.pack(side="right",fill="y")
        note_text.configure(yscrollcommand=nts.set)

        status=tk.Label(editor,text="",bg="#FFFFFF",fg="#64748B",font=ui_font(9),anchor="e",justify="right")
        status.pack(fill="x",padx=14,pady=(0,5))
        current_id=[None]
        dirty=[False]

        def mark_dirty(event=None):
            dirty[0]=True
            try:
                note_text.tag_add("rtl", "1.0", "end")
                note_text.tag_add("paragraph", "1.0", "end")
            except Exception:
                pass
            status.config(text="● تغییرات ذخیره‌نشده")

        def load_list(select_id=None):
            items.delete(0,"end")
            q=search_var.get().strip()
            if q:
                rows=self.db.execute("""
                    SELECT id,title FROM notebook_entries
                    WHERE title LIKE ? OR content LIKE ?
                    ORDER BY updated DESC,id DESC
                """,(f"%{q}%",f"%{q}%")).fetchall()
            else:
                rows=self.db.execute("SELECT id,title FROM notebook_entries ORDER BY updated DESC,id DESC").fetchall()
            for nid,title in rows:
                items.insert("end",title or "یادداشت بدون عنوان")
            items._jahan_ids=[r[0] for r in rows]
            count_label.config(text=f"{len(rows):,} صفحه")
            if select_id is not None and select_id in items._jahan_ids:
                pos=items._jahan_ids.index(select_id)
                items.selection_clear(0,"end"); items.selection_set(pos); items.see(pos)

        def clear_editor():
            current_id[0]=None; dirty[0]=False
            title_var.set("")
            note_text.delete("1.0","end")
            note_text.tag_add("rtl", "1.0", "end")
            note_text.tag_add("paragraph", "1.0", "end")
            status.config(text="صفحه جدید • آماده نوشتن")
            items.selection_clear(0,"end")
            title_entry.focus_set()

        def load_selected(event=None):
            sel=items.curselection()
            if not sel:return
            ids=getattr(items,"_jahan_ids",[])
            if not ids or sel[0]>=len(ids):return
            nid=ids[sel[0]]
            row=self.db.execute("SELECT id,title,content,updated FROM notebook_entries WHERE id=?",(nid,)).fetchone()
            if not row:return
            current_id[0]=row[0]; dirty[0]=False
            title_var.set(row[1] or "یادداشت")
            note_text.delete("1.0","end")
            note_text.insert("1.0",row[2] or "")
            note_text.tag_add("rtl", "1.0", "end")
            note_text.tag_add("paragraph", "1.0", "end")
            status.config(text=f"آخرین ذخیره: {dual_datetime(row[3])}")

        def save_note():
            title=title_var.get().strip() or "یادداشت بدون عنوان"
            content=note_text.get("1.0","end-1c")
            now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if current_id[0]:
                self.db.execute("UPDATE notebook_entries SET title=?,content=?,updated=? WHERE id=?",
                                (title,content,now,current_id[0]))
                nid=current_id[0]
            else:
                cur=self.db.execute("INSERT INTO notebook_entries(title,content,created,updated) VALUES(?,?,?,?)",
                                    (title,content,now,now))
                nid=cur.lastrowid; current_id[0]=nid
            self.db.commit(); dirty[0]=False
            status.config(text=f"✓ ذخیره شد • {dual_datetime(now)}")
            load_list(nid)

        def delete_note():
            nid=current_id[0]
            if not nid:return
            if not messagebox.askyesno("حذف صفحه", "این صفحه از کتابچه حذف شود؟", parent=self):return
            self.db.execute("DELETE FROM notebook_entries WHERE id=?",(nid,)); self.db.commit()
            clear_editor(); load_list()

        self.button(toolbar,"＋ یادداشت جدید",clear_editor,"#0F766E").pack(side="right",padx=4,pady=4)
        self.button(toolbar,"💾 ذخیره",save_note,"#2563EB").pack(side="right",padx=4,pady=4)
        self.button(toolbar,"🗑 حذف",delete_note,"#B42318").pack(side="right",padx=4,pady=4)
        self.button(toolbar,"🔎 جستجو",load_list,"#7C3AED").pack(side="left",padx=4,pady=4)
        search.bind("<Return>",lambda e:load_list())
        # Keep every editable notebook control RTL at creation time.  This is
        # deliberately done with Tk's justify option rather than visual string
        # reversal, so Persian, Latin words and numbers remain in their natural
        # logical order while Windows renders Arabic glyph shaping correctly.
        search.configure(justify="right")
        title_entry.configure(justify="right")
        note_text.configure(undo=True)
        title_entry.bind("<KeyRelease>",mark_dirty); note_text.bind("<KeyRelease>",mark_dirty)
        self.bind_all("<Control-Shift-N>",lambda e:(self.notebook_page(),"break")[1])
        self.bind_all("<Control-Shift-S>",lambda e:(save_note(),"break")[1])
        items.bind("<<ListboxSelect>>",load_selected)

        load_list()
        first=self.db.execute("SELECT id FROM notebook_entries ORDER BY updated DESC,id DESC LIMIT 1").fetchone()
        if first:
            pos=items._jahan_ids.index(first[0]) if first[0] in items._jahan_ids else 0
            items.selection_set(pos); load_selected()
        else:
            clear_editor()

    def customer_account(self,cid):
        """Unified customer journal: loans, credits, receipts and transactions."""
        row=self.db.execute("SELECT id,name,phone,address,notes FROM customers WHERE id=?",(cid,)).fetchone()
        if not row:return
        self.clear()
        RTLLabel(self.main,text=f"حساب یکپارچه مشتری: {row[1]}",bg="#F4F6F8",fg="#1B2733",font=ui_font(22,"bold")).pack(anchor="e",padx=20,pady=(12,10))
        profile=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); profile.pack(fill="x",padx=20,pady=(0,10))
        RTLLabel(profile,text=f"مشتری: {row[1]}",bg="#FFFFFF",fg="#17212B",font=ui_font(15,"bold")).pack(anchor="e",padx=16,pady=(11,4))
        RTLLabel(profile,text=f"تماس: {row[2] or '-'}   |   آدرس: {row[3] or '-'}",bg="#FFFFFF",fg="#475569",font=ui_font(11,"bold")).pack(anchor="e",padx=16,pady=(0,11))

        # Compact professional summary: keep all totals, but avoid a long
        # stack of repeated text blocks. One row per currency, with the
        # essential figures visible at a glance.
        balbox=tk.Frame(self.main,bg="#F8FAFC",highlightbackground="#D8DEE4",highlightthickness=1)
        balbox.pack(fill="x",padx=20,pady=7)
        RTLLabel(balbox,text="خلاصه حساب به تفکیک ارز",bg="#F8FAFC",fg="#1B2733",font=ui_font(14,"bold")).pack(anchor="e",padx=16,pady=(10,2))
        RTLLabel(balbox,text="قرض − رسید = خالص؛ کمیشن فقط در خالص با کمیشن اعمال می‌شود.",bg="#F8FAFC",fg="#64748B",font=ui_font(9)).pack(anchor="e",padx=16,pady=(0,8))

        totals_map={x[0]:x for x in self.customer_account_totals(cid)}
        summary=tk.Frame(balbox,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        summary.pack(fill="x",padx=12,pady=(0,12))
        columns=[("ارز",90),("مجموع قرض",150),("مجموع رسید",150),("خالص بدون کمیشن",165),("کمیشن",130),("خالص با کمیشن",165),("وضعیت",100)]
        hdr=tk.Frame(summary,bg="#B58E45"); hdr.pack(fill="x")
        for title,w in columns:
            RTLLabel(hdr,text=title,bg="#B58E45",fg="#FFFFFF",font=ui_font(9,"bold"),width=max(10,w//9)).pack(side="right",fill="y",padx=2,pady=7)
        balance_rows=self.customer_currency_balances(cid) or [("AFN - افغانی",0,0,0)]
        for idx,(currency,debt,credit,net) in enumerate(balance_rows):
            code=CURRENCY_CODES.get(currency,currency.split(' - ')[0] if currency else currency)
            totals=totals_map.get(currency)
            if totals:
                _,gd,gc,gb,nd,nc,nb,comm=totals
                gd=float(gd); gc=float(gc); comm=float(comm)
                net_without=gd-gc
                net_with=net_without-comm
            else:
                gd=float(debt); gc=float(credit); comm=0.0
                net_without=gd-gc; net_with=net_without
            status='بدهکار' if net_with>0 else ('بستانکار' if net_with<0 else 'تسویه')
            bg="#FFFFFF" if idx%2==0 else "#F8FAFC"
            rowf=tk.Frame(summary,bg=bg); rowf.pack(fill="x")
            vals=[code,fmt_num(gd),fmt_num(gc),fmt_num(abs(net_without)),fmt_num(comm),fmt_num(abs(net_with)),status]
            for (title,w),value in zip(columns,vals):
                RTLLabel(rowf,text=value,bg=bg,fg=("#8A6A2B" if title in ("ارز","وضعیت") else "#17212B"),font=ui_font(9,"bold"),width=max(10,w//9)).pack(side="right",fill="y",padx=2,pady=8)

        btn=tk.Frame(self.main,bg="#F4F6F8"); btn.pack(fill="x",padx=20,pady=8)
        self.button(btn,"＋ قرض",lambda:self.add_account_entry(cid,"قرضداری مشتری"),"#B42318").pack(side="right",padx=3)
        self.button(btn,"＋ رسید",self.register_receipt_page,"#2563EB").pack(side="right",padx=3)
        self.button(btn,"📱 ارسال",lambda:self.send_customer_whatsapp(cid),"#128c7e").pack(side="right",padx=3)
        self.button(btn,"📄 PDF",lambda:self.save_customer_pdf(cid),"#B58E45").pack(side="right",padx=3)
        self.button(btn,"✏ مشخصات",lambda:self.edit_customer(cid),"#2563EB").pack(side="right",padx=3)
        self.button(btn,"↩ بازگشت",self.accounts_page,"#64748B").pack(side="left",padx=3)

        RTLLabel(self.main,text="دفتر گردش مشتری",bg="#F4F6F8",fg="#1B2733",font=ui_font(15,"bold")).pack(anchor="e",padx=20,pady=(7,6))
        cols=("id","date","type","source","currency","amount","rate","afn","commission","notes")
        tree=ttk.Treeview(self.main,columns=cols,show="headings",selectmode="browse",style="Jahan.Accounts.Treeview")
        heads={"id":"شماره","date":"تاریخ / ساعت","type":"نوع","source":"منبع","currency":"ارز","amount":"مبلغ","rate":"نرخ","afn":"معادل افغانی","commission":"کمیشن","notes":"شرح"}
        widths={"id":75,"date":170,"type":155,"source":105,"currency":90,"amount":125,"rate":95,"afn":135,"commission":105,"notes":330}
        for x in cols:
            tree.heading(x,text=_display_text(heads[x])); tree.column(x,anchor="center",width=widths[x],stretch=(x=="notes"))
        tree._jahan_original_headings=heads; self._pack_with_scrollbar(tree,fill="both",expand=True,padx=20,pady=(2,5))
        info=tk.Frame(self.main,bg="#F8FAFC",highlightbackground="#D8DEE4",highlightthickness=1); info.pack(fill="x",padx=20,pady=(0,6))
        info_label=RTLLabel(info,bg="#F8FAFC",fg="#1B2733",font=ui_font(9,"bold")); info_label.pack(anchor="e",padx=10,pady=7)

        def load_accounts():
            for iid in tree.get_children():
                tree.delete(iid)

            # v20: build one unified journal from the two real sources.
            # Receipt mirrors in account_entries are excluded, then the
            # original receipt row is inserted with its real description.
            ledger_rows=self.db.execute("""
                SELECT id,account_no,created,entry_type,
                       COALESCE(source_type,'manual'),
                       COALESCE(currency,'AFN - افغانی'),
                       COALESCE(amount,0),COALESCE(rate,1),
                       COALESCE(afn_amount,amount*COALESCE(rate,1)),
                       COALESCE(commission,0),COALESCE(notes,'')
                FROM account_entries
                WHERE customer_id=? AND COALESCE(source_type,'manual')<>'receipt'
                ORDER BY id DESC
            """,(cid,)).fetchall()

            receipt_rows=self.db.execute("""
                SELECT id,receipt_no,created,receipt_type,
                       COALESCE(currency,'AFN - افغانی'),
                       COALESCE(amount,0),COALESCE(rate,1),
                       COALESCE(afn_amount,amount*COALESCE(rate,1)),
                       COALESCE(commission,0),COALESCE(description,'')
                FROM receipts
                WHERE customer_id=?
                ORDER BY id DESC
            """,(cid,)).fetchall()

            combined=[]
            for eid,no,dt,typ,source,cur,amt,rate,afn,comm,note in ledger_rows:
                combined.append((dt,eid,no,typ,source,cur,amt,rate,afn,comm,note))

            for rid,no,dt,rtyp,cur,amt,rate,afn,comm,desc in receipt_rows:
                # A receipt is represented once, directly from receipts.
                entry_type="بستانکاری مشتری" if rtyp=="دریافت از مشتری" else "قرضداری مشتری"
                combined.append((dt,rid,no,entry_type,"receipt",cur,amt,rate,afn,comm,desc))

            combined.sort(key=lambda r: (str(r[0] or ""), int(r[1] or 0)), reverse=True)

            for dt,eid,no,typ,source,cur,amt,rate,afn,comm,note in combined:
                code=CURRENCY_CODES.get(cur,cur.split(' - ')[0] if cur else cur)
                src={"receipt":"رسید","transaction":"معامله","manual":"حساب"}.get(source,source or "حساب")
                tag="credit" if typ=="بستانکاری مشتری" else "debit"
                vals=(no or eid,dual_datetime(dt),typ,src,code,
                      fmt_num(amt),fmt_num(rate),fmt_num(afn),
                      fmt_num(comm),note or '-')
                tree.insert('', 'end', iid=f"{source}-{int(eid)}", values=vals, tags=(tag,source))

            # Exact totals are always calculated by currency. Different
            # currencies are never added together as if they were one unit.
            exact=self.customer_account_totals(cid)
            parts=[]
            total_count=len(combined)
            for cur,gd,gc,gb,nd,nc,nb,comm in exact:
                code=CURRENCY_CODES.get(cur,cur.split(' - ')[0] if cur else cur)
                parts.append(
                    f"{code}: قرض {fmt_num(gd)} | رسید {fmt_num(gc)} | "
                    f"خالص {fmt_num(nb)} | کمیشن {fmt_num(comm)}"
                )
            info_label.config(
                text=f"تعداد گردش: {total_count}   |   " + "   ||   ".join(parts)
                if parts else "تعداد گردش: 0"
            )

        def edit_selected(event=None):
            sel=tree.selection()
            if not sel:return
            key=str(sel[0])
            if key.startswith("receipt-"):
                try: self.edit_receipt_page(int(key.split("-",1)[1]))
                except Exception: pass
                return
            try:eid=int(key.split("-",1)[-1])
            except:return
            source=self.db.execute("SELECT COALESCE(source_type,'manual'),COALESCE(source_id,0) FROM account_entries WHERE id=?",(eid,)).fetchone()
            if not source:return
            st,sid=source
            if st=="receipt" and sid:
                self.edit_receipt_page(int(sid))
            elif st=="manual":
                self.edit_manual_account_entry(eid)
            else:
                messagebox.showinfo("ویرایش گردش", "این گردش از بخش معاملات ثبت شده است؛ برای حفظ صحت حساب، از همان بخش ویرایش کنید.")

        def delete_selected(event=None):
            sel=tree.selection()
            if not sel:return
            key=str(sel[0])
            if key.startswith("receipt-"):
                try: self.delete_receipt_from_customer(int(key.split("-",1)[1]),cid)
                except Exception: pass
                return
            try:eid=int(key.split("-",1)[-1])
            except:return
            source=self.db.execute("SELECT COALESCE(source_type,'manual'),COALESCE(source_id,0) FROM account_entries WHERE id=?",(eid,)).fetchone()
            if not source:return
            st,sid=source
            if st=="receipt" and sid:
                self.delete_receipt_from_customer(int(sid),cid)
            elif st=="manual":
                self.delete_manual_account_entry(eid)
            else:
                messagebox.showinfo("حذف گردش", "این گردش از بخش معاملات ثبت شده است؛ برای حفظ صحت حساب، از همان بخش حذف کنید.")

        actions=tk.Frame(self.main,bg="#F4F6F8"); actions.pack(fill="x",padx=20,pady=(0,8))
        self.button(actions,"✏ ویرایش انتخاب‌شده",edit_selected,"#0F766E").pack(side="right",padx=3)
        self.button(actions,"🗑 حذف انتخاب‌شده",delete_selected,"#B42318").pack(side="right",padx=3)
        self.button(actions,"＋ قرضداری",lambda:self.add_account_entry(cid,"قرضداری مشتری"),"#B42318").pack(side="right",padx=3)
        self.button(actions,"＋ بستانکاری",lambda:self.add_account_entry(cid,"بستانکاری مشتری"),"#157347").pack(side="right",padx=3)
        tree.bind("<Double-1>",edit_selected,add="+"); tree.bind("<Delete>",delete_selected,add="+")
        load_accounts()

    def delete_receipt_from_customer(self,rid,cid):
        row=self.db.execute("SELECT receipt_no,customer,amount,currency FROM receipts WHERE id=?",(rid,)).fetchone()
        if not row:return
        cur=CURRENCY_CODES.get(row[3],row[3] or '')
        if not messagebox.askyesno("حذف رسید",f"رسید شماره {row[0]} برای «{row[1]}» به مبلغ {fmt_num(row[2])} {cur} حذف شود؟\nثبت حساب مرتبط نیز حذف می‌شود و مانده دوباره محاسبه خواهد شد.\nاین عمل قابل بازگشت نیست."):
            return
        self.db.execute("DELETE FROM account_entries WHERE source_type='receipt' AND source_id=?",(rid,))
        self.db.execute("DELETE FROM account_entries WHERE source_type='receipt' AND notes LIKE ?",(f"رسید شماره {row[0]}%",))
        self.db.execute("DELETE FROM receipts WHERE id=?",(rid,))
        self.db.commit()
        messagebox.showinfo("حذف موفق","رسید و ثبت حساب مرتبط حذف شد.")
        self.customer_account(cid)

    def _edit_receipt_from_customer_table(self,tree):
        sel=tree.selection()
        if not sel:return
        vals=tree.item(sel[0],"values")
        if not vals:return
        try: no=int(vals[0])
        except Exception:return
        rr=self.db.execute("SELECT id FROM receipts WHERE receipt_no=? ORDER BY id DESC LIMIT 1",(no,)).fetchone()
        if rr:self.edit_receipt_page(rr[0])

    def edit_account_entry_page(self,entry_id):
        row=self.db.execute("""SELECT id,created,customer_id,customer,entry_type,amount,notes,
                                      COALESCE(currency,'AFN - افغانی'),COALESCE(rate,1),COALESCE(afn_amount,0),
                                      COALESCE(commission,0),COALESCE(commission_afn,0),COALESCE(commission_currency,currency),COALESCE(route,'')
                               FROM account_entries WHERE id=?""",(entry_id,)).fetchone()
        if not row:return
        if self.db.execute("SELECT 1 FROM account_entries WHERE id=? AND COALESCE(source_type,'manual')='receipt'",(entry_id,)).fetchone():
            src=self.db.execute("SELECT source_id FROM account_entries WHERE id=?",(entry_id,)).fetchone()
            if src and src[0]: self.edit_receipt_page(src[0])
            return
        if self.db.execute("SELECT 1 FROM account_entries WHERE id=? AND COALESCE(source_type,'manual')='transaction'",(entry_id,)).fetchone():
            messagebox.showinfo("ویرایش حساب","این ردیف از بخش معاملات آمده است؛ آن را از بخش معاملات ویرایش کنید.")
            return
        names=self.get_customer_list()
        win=tk.Toplevel(self); win.title("ویرایش قرض / بستانکاری مشتری"); win.geometry("520x620"); win.configure(bg="#F4F6F8")
        self._prepare_toplevel(win,500,580)
        RTLLabel(win,text="ویرایش حساب مشتری",bg="#F4F6F8",fg="#1B2733",font=ui_font(16,"bold")).pack(pady=12)
        form=tk.Frame(win,bg="#FFFFFF"); form.pack(fill="both",expand=True,padx=18,pady=8)
        form.columnconfigure(0,weight=1); form.columnconfigure(1,weight=1)
        customer=tk.StringVar(value=f"{row[2]} - {row[3]}" if row[2] else row[3])
        typ=tk.StringVar(value=row[4]); cur=tk.StringVar(value=row[7]); amount=tk.StringVar(value=str(row[5])); rate=tk.StringVar(value=str(row[8] or 1)); notes=tk.StringVar(value=row[6] or '')
        route=tk.StringVar(value=row[13] or 'افغانستان'); commission=tk.StringVar(value=str(row[10] or 0)); commission_base=tk.StringVar(value='1000000'); commission_enabled=tk.BooleanVar(value=(float(row[10] or 0)>0))
        def field(r,c,label,var,values=None):
            cell=tk.Frame(form,bg="#FFFFFF"); cell.grid(row=r,column=c,padx=10,pady=7,sticky="ew")
            RTLLabel(cell,text=label,bg="#FFFFFF",fg="#1B2733").pack(anchor="e")
            if values is not None:
                w=LocalizedCombobox(cell,textvariable=var,values=values,state="readonly")
            else:
                w=tk.Entry(cell,textvariable=var,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1)
            w.pack(fill="x",ipady=6); return w
        customer_w=field(0,0,"مشتری",customer,[f"{i} - {n}" for i,n in names]); field(0,1,"نوع حساب",typ,["قرضداری مشتری","بستانکاری مشتری"]); currency_w=field(1,0,"ارز",cur,CURRENCIES); field(1,1,"مبلغ",amount); field(2,0,"نرخ",rate); field(2,1,"مسیر / حواله",route,["افغانستان","ایران"]); field(3,0,"کمیشن",commission); field(3,1,"توضیحات",notes)
        info=RTLLabel(form,text="",bg="#EAF6F6",fg="#0F766E",font=ui_font(9,"bold")); info.grid(row=4,column=0,columnspan=2,padx=10,pady=8,sticky="ew")
        def calc(*args):
            try:v=float(D(amount.get() or 0)); r=float(D(rate.get() or 1)); c=float(D(commission.get() or 0))
            except:v=r=c=0
            info.config(text=f"مبلغ خالص: {fmt_num(max(v-c,0))} {cur.get()}   |   کمیشن: {fmt_num(c)} {cur.get()}   |   معادل افغانی: {fmt_num(v*r)}")
        for v in (amount,rate,commission):v.trace_add("write",calc)
        cur.trace_add("write",calc); calc()
        def save():
            try:v=float(D(amount.get())); r=float(D(rate.get() or 1)); c=float(D(commission.get() or 0))
            except:messagebox.showerror("خطا","مبلغ، نرخ و کمیشن باید عددی باشند.",parent=win);return
            if v<=0 or r<=0 or c<0:messagebox.showerror("خطا","مقادیر واردشده معتبر نیستند.",parent=win);return
            idx=customer_w.current()
            if idx>=0:cid,cname=names[idx]
            else:cid,cname=row[2],row[3]
            et=typ.get().strip(); cafn=c*r
            self.db.execute("""UPDATE account_entries SET customer_id=?,customer=?,entry_type=?,amount=?,notes=?,currency=?,rate=?,afn_amount=?,commission=?,commission_afn=?,commission_currency=?,route=? WHERE id=?""",(cid,cname,et,v,notes.get().strip(),cur.get(),r,v*r,c,cafn,cur.get(),route.get(),entry_id))
            self.db.commit(); win.destroy(); self.customer_account(cid)
        self.button(win,"✓ ذخیره ویرایش",save,"#0F766E").pack(fill="x",padx=18,pady=12,ipady=5)
        self.button(win,"انصراف",win.destroy,"#64748B").pack(fill="x",padx=18,pady=(0,12),ipady=4)


    def edit_manual_account_entry(self, entry_id):
        row=self.db.execute("""SELECT id,customer_id,customer,entry_type,amount,currency,rate,
                                      commission,commission_currency,route,notes
                               FROM account_entries WHERE id=?""",(entry_id,)).fetchone()
        if not row:return
        eid,cid,cname,etype,amount,currency,rate,commission,commcur,route,notes=row
        if etype not in ("قرضداری مشتری","بستانکاری مشتری"):
            messagebox.showinfo("ویرایش حساب","برای رسید از ویرایش رسید استفاده کنید."); return
        win=tk.Toplevel(self); win.title("ویرایش حساب مشتری"); win.geometry("620x500")
        win.minsize(560,450); win.transient(self); win.grab_set(); win.configure(bg="#F4F6F8")
        RTLLabel(win,text=f"ویرایش {etype}",bg="#F4F6F8",fg="#1B2733",font=ui_font(17,"bold")).pack(anchor="e",padx=22,pady=(18,8))
        body=tk.Frame(win,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); body.pack(fill="both",expand=True,padx=18,pady=8)
        def fld(label,val):
            RTLLabel(body,text=label,bg="#FFFFFF",fg="#334155",font=ui_font(10,"bold")).pack(anchor="e",padx=18,pady=(10,3))
            e=tk.Entry(body,justify="right",font=ui_font(11),relief="solid",bd=1); e.pack(fill="x",padx=18); e.insert(0,"" if val is None else str(val)); return e
        ae=fld("مبلغ",amount)
        # ارز نیز مثل مبلغ/نرخ/کمیشن قابل ویرایش است.
        cur_var=tk.StringVar(value=currency or "AFN - افغانی")
        RTLLabel(body,text="ارز",bg="#FFFFFF",fg="#334155",font=ui_font(10,"bold")).pack(anchor="e",padx=18,pady=(10,3))
        cur_w=LocalizedCombobox(body,textvariable=cur_var,values=CURRENCIES,state="readonly")
        cur_w.pack(fill="x",padx=18,ipady=5)
        re_=fld("نرخ ارز",rate or 1); ce=fld("کمیشن",commission or 0)
        r_e=fld("مسیر / مرجع",route or ""); n_e=fld("توضیحات",notes or "")
        bar=tk.Frame(win,bg="#F4F6F8"); bar.pack(fill="x",padx=18,pady=12)
        def save():
            try:
                a=float(str(ae.get()).replace(",","").strip()); r=float(str(re_.get()).replace(",","").strip() or 1); c=float(str(ce.get()).replace(",","").strip() or 0)
                if a<0 or r<=0 or c<0: raise ValueError
            except Exception:
                messagebox.showerror("خطا","مبلغ، نرخ یا کمیشن معتبر نیست.",parent=win); return
            new_currency=(cur_var.get().strip() or currency or "AFN - افغانی")
            self.db.execute("""UPDATE account_entries SET amount=?,currency=?,rate=?,afn_amount=?,commission=?,commission_afn=?,
                               commission_currency=?,route=?,notes=? WHERE id=?""",
                            (a,new_currency,r,a*r,c,c*r,new_currency,r_e.get().strip(),n_e.get().strip(),eid))
            self.db.commit(); self._refresh_financial_views_after_change(cid); win.destroy(); self.customer_account(cid)
        self.button(bar,"💾 ذخیره تغییرات",save,"#157347").pack(side="right",padx=4)
        self.button(bar,"انصراف",win.destroy,"#64748B").pack(side="right",padx=4)

    def _refresh_financial_views_after_change(self, customer_id=None):
        """Ensure all financial summaries are rebuilt from the live database after an edit/delete."""
        try:
            self.db.commit()
        except Exception:
            pass
        # Pages are query-backed, so no cached totals are kept. Re-opening the page
        # forces dashboard/reports/customer balances to use the edited database rows.
        self._financial_data_revision = getattr(self, '_financial_data_revision', 0) + 1

    def delete_manual_account_entry(self, entry_id):
        row=self.db.execute("SELECT id,customer_id,customer,entry_type,amount,currency FROM account_entries WHERE id=?",(entry_id,)).fetchone()
        if not row:return
        eid,cid,cname,etype,amount,currency=row
        if etype not in ("قرضداری مشتری","بستانکاری مشتری"):
            messagebox.showinfo("حذف حساب","برای رسید از حذف رسید استفاده کنید."); return
        if not messagebox.askyesno("تأیید حذف",f"{etype} مشتری «{cname}» حذف شود؟\nمبلغ: {fmt_num(amount)} {CURRENCY_CODES.get(currency,currency)}\nاین عملیات قابل برگشت نیست."): return
        self.db.execute("DELETE FROM account_entries WHERE id=?",(eid,)); self.db.commit(); self._refresh_financial_views_after_change(cid); self.customer_account(cid)

    def quick_account_entry(self):
        names=self.get_customer_list()
        if not names:
            messagebox.showwarning("حساب مشتری","ابتدا حداقل یک مشتری ثبت کنید."); return
        win=tk.Toplevel(self); win.title("ثبت حساب مشتری"); win.geometry("560x700"); win.minsize(520,650); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="مشتری",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(15,3))
        cb=LocalizedCombobox(win,values=[f"{i} - {n}" for i,n in names],state="readonly"); cb.pack(fill="x",padx=20)
        RTLLabel(win,text="نوع حساب",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(15,3))
        typ=LocalizedCombobox(win,values=["قرضداری مشتری","بستانکاری مشتری"],state="readonly"); typ.pack(fill="x",padx=20); typ.current(0)
        RTLLabel(win,text="ارز",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(15,3))
        cur=tk.StringVar(value=CURRENCIES[2]); currency=LocalizedCombobox(win,textvariable=cur,values=CURRENCIES,state="readonly"); currency.pack(fill="x",padx=20)
        RTLLabel(win,text="مبلغ",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(12,3))
        amount=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); amount.pack(fill="x",padx=20)
        RTLLabel(win,text="نرخ مرجع داخلی",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(12,3))
        rate=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); rate.pack(fill="x",padx=20)
        route=tk.StringVar(value="افغانستان"); commission_enabled=tk.BooleanVar(value=False); no_commission=tk.BooleanVar(value=False); commission_base=tk.StringVar(value="1000000"); commission_per_base=tk.StringVar(value="0"); commission_total=tk.StringVar(value="0"); net_total=tk.StringVar(value="0")
        RTLLabel(win,text="کمیشن — قابل تنظیم برای هر پایه",bg="#F4F6F8",fg="#7C3AED",font=ui_font(10,"bold")).pack(anchor="e",padx=20,pady=(12,3))
        fee_row=tk.Frame(win,bg="#F4F6F8"); fee_row.pack(fill="x",padx=20)
        tk.Checkbutton(fee_row,text="محاسبه خودکار",variable=commission_enabled,bg="#F4F6F8",activebackground="#F4F6F8",command=lambda:(no_commission.set(False),calc_commission())).pack(side="right")
        self.button(fee_row,"بدون کمیشن",lambda:(no_commission.set(True),commission_enabled.set(False),calc_commission()),"#B91C1C").pack(side="left",padx=4)
        LocalizedCombobox(fee_row,textvariable=route,values=["افغانستان","ایران"],state="readonly",width=12).pack(side="right",padx=5)
        tk.Entry(fee_row,textvariable=commission_base,width=12,justify="center").pack(side="right",padx=5)
        tk.Entry(fee_row,textvariable=commission_per_base,width=12,justify="center").pack(side="right",padx=5)
        RTLLabel(win,textvariable=commission_total,bg="#F4F6F8",fg="#0F766E",font=ui_font(9,"bold")).pack(anchor="e",padx=20,pady=2)
        RTLLabel(win,textvariable=net_total,bg="#EAF6F6",fg="#0F766E",font=ui_font(10,"bold"),padx=8,pady=5).pack(fill="x",padx=20,pady=(2,5))
        def calc_commission(*args):
            try: v=float(D(amount.get() or 0)); b=float(D(commission_base.get() or 1000000)); f=float(D(commission_per_base.get() or 0))
            except: v=0; b=1000000; f=0
            total=(v/b*f) if commission_enabled.get() and (not no_commission.get()) and b>0 else 0
            commission_total.set(f"کمیشن: {fmt_num(total)} {cur.get()}")
            net_total.set(f"مانده خالص پس از کمیشن: {fmt_num(max(v-total,0))} {cur.get()}")
        def load_commission_rule(event=None):
            b,f=self._commission_rule(route.get(),cur.get()); commission_base.set(str(b)); commission_per_base.set(str(f)); commission_enabled.set(f>0); no_commission.set(False); calc_commission()
        amount.bind("<KeyRelease>",lambda e:calc_commission()); route.trace_add("write",lambda *a:load_commission_rule()); commission_base.trace_add("write",lambda *a:calc_commission()); commission_per_base.trace_add("write",lambda *a:calc_commission())
        def sync_rate(event=None):
            rate.delete(0,"end")
            rate.insert(0,fmt_num(self.get_rate_to_afn(cur.get()) or 1))
        currency.bind("<<ComboboxSelected>>",sync_rate)
        currency.bind("<<ComboboxSelected>>",load_commission_rule)
        sync_rate(); load_commission_rule()
        RTLLabel(win,text="توضیحات",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(12,3))
        notes=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); notes.pack(fill="x",padx=20)
        def save():
            if cb.current()<0: messagebox.showwarning("خطا","مشتری را انتخاب کنید."); return
            try: val=float(D(amount.get()))
            except: messagebox.showerror("خطا","مبلغ باید عددی باشد."); return
            if val<=0: messagebox.showerror("خطا","مبلغ باید بیشتر از صفر باشد."); return
            cid,name=names[cb.current()]
            try: rv=float(D(rate.get()))
            except: messagebox.showerror("خطا","نرخ باید عددی باشد."); return
            if rv<=0: messagebox.showerror("خطا","نرخ باید بیشتر از صفر باشد."); return
            try: cbase=float(D(commission_base.get() or 1000000)); cfee=float(D(commission_per_base.get() or 0))
            except: cbase=1000000; cfee=0
            comm=(val/cbase*cfee) if commission_enabled.get() and (not no_commission.get()) and cbase>0 else 0; cafn=comm*rv
            self.db.execute("""INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,commission,commission_afn,commission_currency,route)
                               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (datetime.now().strftime("%Y-%m-%d %H:%M"),cid,name,typ.get(),val,notes.get().strip(),cur.get(),rv,val*rv,comm,cafn,cur.get(),route.get()))
            self.db.commit(); win.destroy(); self.accounts_page()
        action=tk.Frame(win,bg="#F4F6F8"); action.pack(fill="x",side="bottom",padx=20,pady=12); self.button(action,"✓ ثبت حساب",save,"#0F766E").pack(fill="x",ipady=7)

    def _commission_rule(self, route, currency):
        row=self.db.execute("SELECT base_amount,commission_amount FROM commission_rules WHERE route=? AND currency=? AND active=1",(route,currency)).fetchone()
        return (float(row[0]),float(row[1])) if row else (1000000.0,0.0)

    def commission_settings(self, currency='IRR - تومان'):
        win=tk.Toplevel(self); win.title("تنظیم کمیشن ایران و افغانستان"); win.geometry("520x430"); win.configure(bg="#F4F6F8"); win.grab_set()
        RTLLabel(win,text="⚙ تنظیم کمیشن تبدیل ارز و حواله",bg="#F4F6F8",fg="#1B2733",font=ui_font(15,"bold")).pack(pady=18)
        vars={}
        for route in ("ایران","افغانستان"):
            box=tk.Frame(win,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); box.pack(fill="x",padx=20,pady=7)
            RTLLabel(box,text=f"مسیر {route}",bg="#FFFFFF",fg="#1B2733",font=ui_font(11,"bold")).pack(anchor="e",padx=12,pady=(8,4))
            base,fee=self._commission_rule(route,currency)
            row=tk.Frame(box,bg="#FFFFFF"); row.pack(fill="x",padx=12,pady=8)
            RTLLabel(row,text="مبلغ پایه",bg="#FFFFFF",fg="#687582").pack(side="right",padx=5)
            b=tk.Entry(row,justify="center",width=14); b.pack(side="right",padx=5); b.insert(0,fmt_num(base))
            RTLLabel(row,text="کمیشن",bg="#FFFFFF",fg="#687582").pack(side="right",padx=5)
            f=tk.Entry(row,justify="center",width=14); f.pack(side="right",padx=5); f.insert(0,fmt_num(fee))
            vars[route]=(b,f)
        RTLLabel(win,text="مثال: اگر پایه ۱٬۰۰۰٬۰۰۰ تومان و کمیشن ۳۵۰٬۰۰۰ باشد،\nبرنامه برای هر مبلغ، کمیشن را به نسبت خودکار محاسبه می‌کند.",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(pady=10)
        def save():
            try:
                for route,(b,f) in vars.items():
                    bv=float(b.get().replace(',','')); fv=float(f.get().replace(',',''))
                    if bv<=0 or fv<0: raise ValueError
                    self.db.execute("INSERT INTO commission_rules(route,currency,base_amount,commission_amount,active) VALUES(?,?,?,?,1) ON CONFLICT(route,currency) DO UPDATE SET base_amount=excluded.base_amount,commission_amount=excluded.commission_amount,active=1",(route,currency,bv,fv))
                self.db.commit(); win.destroy()
            except Exception: messagebox.showerror("خطا","مبلغ پایه و کمیشن باید عددی صحیح و معتبر باشند.",parent=win)
        self.button(win,"✓ ذخیره تنظیمات کمیشن",save).pack(side="bottom",pady=12)

    def add_account_entry(self,cid,entry_type):
        row=self.db.execute("SELECT name FROM customers WHERE id=?",(cid,)).fetchone()
        if not row:return
        win=tk.Toplevel(self); win.title(entry_type); win.geometry("560x700"); win.minsize(520,650); win.configure(bg="#F4F6F8")
        RTLLabel(win,text=f"{entry_type}: {row[0]}",bg="#F4F6F8",fg="#1B2733",font=ui_font(13,"bold")).pack(pady=15)
        _entry_now=datetime.now()
        RTLLabel(win,text=f"زمان ثبت: {jalali_date(_entry_now)} | {_entry_now:%Y/%m/%d} | {_entry_now:%H:%M:%S}",bg="#EAF6F6",fg="#0F766E",font=ui_font(9,"bold")).pack(fill="x",padx=20,pady=(0,8))
        RTLLabel(win,text="ارز",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20)
        cur=tk.StringVar(value=CURRENCIES[2]); currency=LocalizedCombobox(win,textvariable=cur,values=CURRENCIES,state="readonly"); currency.pack(fill="x",padx=20,pady=5)
        RTLLabel(win,text="مبلغ",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20)
        amount=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); amount.pack(fill="x",padx=20,pady=5)
        RTLLabel(win,text="نرخ مرجع داخلی",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20)
        rate=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); rate.pack(fill="x",padx=20,pady=5)
        route=tk.StringVar(value="افغانستان");
        RTLLabel(win,text="مسیر / حواله",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20)
        route_cb=LocalizedCombobox(win,textvariable=route,values=["افغانستان","ایران"],state="readonly"); route_cb.pack(fill="x",padx=20,pady=5)
        commission=tk.StringVar(value="0"); commission_base=tk.StringVar(value="1000000"); commission_enabled=tk.BooleanVar(value=False); no_commission=tk.BooleanVar(value=False); net_total=tk.StringVar(value="0")
        fee_row=tk.Frame(win,bg="#F4F6F8"); fee_row.pack(fill="x",padx=20,pady=5)
        tk.Checkbutton(fee_row,text="محاسبه کمیشن خودکار",variable=commission_enabled,bg="#F4F6F8",fg="#1B2733",activebackground="#F4F6F8",command=lambda:(no_commission.set(False),calc_commission())).pack(side="right")
        self.button(fee_row,"بدون کمیشن",lambda:(no_commission.set(True),commission_enabled.set(False),calc_commission()),"#B91C1C").pack(side="right",padx=4)
        self.button(fee_row,"⚙ تنظیم کمیشن",lambda:self.commission_settings(cur.get()),"#64748B").pack(side="left")
        info=RTLLabel(win,text="",bg="#F4F6F8",fg="#0f766e",font=ui_font(9,"bold")); info.pack(anchor="e",padx=20,pady=2)
        net_info=RTLLabel(win,textvariable=net_total,bg="#EAF6F6",fg="#0F766E",font=ui_font(10,"bold"),padx=8,pady=5); net_info.pack(fill="x",padx=20,pady=4)
        def sync_rate(event=None):
            rate.delete(0,"end"); rate.insert(0,str(self.get_rate_to_afn(cur.get()) or 1)); calc_commission()
        def calc_commission(*args):
            try: val=float(D(amount.get() or 0))
            except: val=0
            base,fee=self._commission_rule(route.get(),cur.get())
            commission_base.set(str(base))
            c=(val/base*fee) if base>0 else 0
            commission.set(str(c))
            info.config(text=(f"کمیشن: {fmt_num(c)} {cur.get()}  |  پایه: {fmt_num(base)} {cur.get()}" if commission_enabled.get() else "کمیشن خاموش است"))
        currency.bind("<<ComboboxSelected>>",sync_rate); route_cb.bind("<<ComboboxSelected>>",lambda e:calc_commission()); amount.bind("<KeyRelease>",calc_commission); rate.bind("<KeyRelease>",calc_commission); commission_enabled.trace_add("write",calc_commission); no_commission.trace_add("write",calc_commission); sync_rate(); commission_enabled.set(self._commission_rule(route.get(),cur.get())[1] > 0)
        RTLLabel(win,text="توضیحات / نوبت پرداخت",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(8,2))
        notes=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); notes.pack(fill="x",padx=20)
        def save():
            try: val=float(D(amount.get())); rv=float(D(rate.get()))
            except: messagebox.showerror("خطا","مبلغ و نرخ باید عددی باشند.",parent=win); return
            if val<=0 or rv<=0: messagebox.showerror("خطا","مبلغ و نرخ باید بیشتر از صفر باشند.",parent=win); return
            comm=float(commission.get() or 0) if commission_enabled.get() else 0
            cafn=comm*rv
            # Commission is stored with the same ledger row, so the customer's notebook shows the exact fee.
            self.db.execute("""INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,commission,commission_afn,commission_currency,route)
                               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(datetime.now().strftime("%Y-%m-%d %H:%M"),cid,row[0],entry_type,val,notes.get().strip(),cur.get(),rv,val*rv,comm,cafn,cur.get(),route.get()))
            self.db.commit(); win.destroy(); self.customer_account(cid)
        action=tk.Frame(win,bg="#F4F6F8"); action.pack(fill="x",side="bottom",padx=20,pady=12); self.button(action,"✓ ثبت در دفترچه مشتری",save,"#0F766E").pack(fill="x",ipady=7)

    def customer_full_report(self,cid):
        """خلاصه حساب برای واتساپ/تلگرام، دقیقاً هم‌منطق جدول PDF و بدون ریز گردش."""
        row=self.db.execute(
            "SELECT id,name,phone,address,notes FROM customers WHERE id=?",(cid,)
        ).fetchone()
        if not row:
            return ""
        lines=self._outgoing_profile_text_lines()+[
            "—",
            "*گزارش خلاصه حساب مشتری*",
            f"مشتری: {row[1]}",
            f"تماس: {row[2] or '-'}",
            f"تاریخ گزارش: {dual_datetime(datetime.now())}",
            "",
            "*خلاصه حساب به تفکیک ارز*"
        ]
        totals=self.customer_account_totals(cid)
        if totals:
            for cur,gd,gc,gb,nd,nc,nb,comm in totals:
                code=CURRENCY_CODES.get(cur,cur.split(" - ")[0] if cur else cur)
                net_without=float(gb)
                net_with=net_without-float(comm)
                status='بدهکار' if net_with>0 else ('بستانکار' if net_with<0 else 'تسویه')
                lines.extend([
                    f"*{code}*",
                    f"مجموع قرض: {fmt_money_exact(abs(float(gd)))} {code}",
                    f"مجموع رسید: {fmt_money_exact(abs(float(gc)))} {code}",
                    f"خالص بدون کمیشن: {fmt_money_exact(abs(net_without))} {code}",
                    f"کمیشن: {fmt_money_exact(abs(float(comm)))} {code}",
                    f"خالص با کمیشن: {fmt_money_exact(abs(net_with))} {code}",
                    f"وضعیت نهایی: {status}",
                    ""
                ])
        else:
            lines.append("حسابی برای این مشتری ثبت نشده است.")
        lines += [
            "فرمول: خالص بدون کمیشن = مجموع قرض − مجموع رسید | خالص با کمیشن = خالص بدون کمیشن − کمیشن",
            "این گزارش خلاصه است و ریز تراکنش‌ها ارسال نمی‌شود.",
            "با احترام"
        ]
        return "\n".join(lines)

    def _get_outgoing_profile(self):
        """Return the one-time company/exchange identity used only on outgoing documents."""
        keys = ("outgoing_name", "outgoing_type", "outgoing_phone", "outgoing_address", "outgoing_notes")
        vals = {}
        for k in keys:
            row = self.db.execute("SELECT value FROM app_settings WHERE key=?", (k,)).fetchone()
            vals[k] = str(row[0] or "").strip() if row else ""
        return vals

    def _save_outgoing_profile(self, vals):
        for k,v in vals.items():
            self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES(?,?)", (k, str(v or "").strip()))
        self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('outgoing_profile_completed','1')")
        self.db.commit()

    def _outgoing_profile_text_lines(self):
        p=self._get_outgoing_profile()
        if not p.get("outgoing_name"):
            return []
        lines=[f"*{p['outgoing_name']}*"]
        if p.get("outgoing_type"): lines.append(p["outgoing_type"])
        if p.get("outgoing_phone"): lines.append(f"تماس: {p['outgoing_phone']}")
        if p.get("outgoing_address"): lines.append(f"آدرس: {p['outgoing_address']}")
        if p.get("outgoing_notes"): lines.append(p["outgoing_notes"])
        return lines

    def _ensure_outgoing_profile_once(self):
        try:
            row=self.db.execute("SELECT value FROM app_settings WHERE key='outgoing_profile_completed'").fetchone()
            if row and str(row[0]).strip()=="1":
                return
        except Exception:
            return
        self._show_outgoing_profile_dialog(first_run=True)

    def _show_outgoing_profile_dialog(self, first_run=False):
        win=tk.Toplevel(self)
        win.title("مشخصات ارسال رسید و حساب")
        win.geometry("620x610")
        win.minsize(580,560)
        win.configure(bg="#F4F6F8")
        win.transient(self)
        win.grab_set()
        RTLLabel(win,text="🏢 مشخصات یک‌بار مصرف برای فایل‌های ارسالی",bg="#F4F6F8",fg="#1B2733",font=ui_font(17,"bold")).pack(anchor="e",padx=24,pady=(22,7))
        if first_run:
            hint="این مشخصات فقط برای رسیدها و حساب‌هایی که برای مشتری ارسال می‌کنید استفاده می‌شود؛ نام «نرم افزار حسابداری جهان» از سایر بخش‌های برنامه حذف نمی‌شود. این پنجره فقط یک‌بار نمایش داده می‌شود."
        else:
            hint="این مشخصات فقط روی رسیدها و حساب‌های ارسالی قرار می‌گیرد و روی نام و ظاهر خود برنامه اثری ندارد."
        RTLLabel(win,text=hint,bg="#F4F6F8",fg="#687582",font=ui_font(9),wraplength=560,justify="right").pack(anchor="e",padx=24,pady=(0,14))
        old=self._get_outgoing_profile()
        vars={k:tk.StringVar(value=old.get(k,"")) for k in ("outgoing_name","outgoing_type","outgoing_phone","outgoing_address")}
        fields=[("نام شرکت / صرافی *","outgoing_name"),("نوع فعالیت","outgoing_type"),("شماره تماس","outgoing_phone"),("آدرس","outgoing_address")]
        for label,key in fields:
            RTLLabel(win,text=label,bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",padx=24,pady=(7,3))
            e=tk.Entry(win,textvariable=vars[key],bg="#FFFFFF",fg="#1B2733",insertbackground="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#CBD5E1",font=ui_font(10),justify="right")
            e.pack(fill="x",padx=24,ipady=8)
        RTLLabel(win,text="مشخصات تکمیلی / جمله پایانی",bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",padx=24,pady=(9,3))
        notes=tk.Text(win,height=4,bg="#FFFFFF",fg="#1B2733",insertbackground="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#CBD5E1",font=ui_font(10),wrap="word")
        notes.pack(fill="x",padx=24,pady=(0,12)); notes.insert("1.0",old.get("outgoing_notes",""))
        def save():
            name=vars["outgoing_name"].get().strip()
            if not name:
                messagebox.showwarning("مشخصات ارسال","نام شرکت یا صرافی را وارد کنید.",parent=win); return
            vals={k:v.get().strip() for k,v in vars.items()}
            vals["outgoing_notes"]=notes.get("1.0","end").strip()
            self._save_outgoing_profile(vals)
            try: win.grab_release(); win.destroy()
            except Exception: pass
        self.button(win,"✓ ذخیره و ادامه",save,"#0F766E").pack(fill="x",padx=24,pady=(8,6),ipady=7)
        if not first_run:
            self.button(win,"انصراف",win.destroy,"#64748B").pack(fill="x",padx=24,pady=(0,12),ipady=5)
        else:
            RTLLabel(win,text="* نام شرکت یا صرافی الزامی است",bg="#F4F6F8",fg="#B42318",font=ui_font(8)).pack(anchor="e",padx=24,pady=(0,12))
        win.protocol("WM_DELETE_WINDOW", (lambda: win.destroy()) if not first_run else (lambda: None))

    def _outgoing_profile_dict(self):
        return self._get_outgoing_profile()

    def normalize_phone(self, phone):
        p=''.join(ch for ch in str(phone or '') if ch.isdigit())
        if p.startswith("00"): p=p[2:]
        if p.startswith("0"): p="93"+p[1:]
        return p

    def save_customer_pdf(self,cid,channel=None):
        row=self.db.execute("SELECT id,name,phone,address,notes FROM customers WHERE id=?",(cid,)).fetchone()
        if not row:return None
        if not REPORTLAB_OK:
            messagebox.showerror('PDF','کتابخانه PDF در این نسخه نصب نیست.')
            return None
        path=filedialog.asksaveasfilename(defaultextension='.pdf',
            filetypes=[('PDF','*.pdf')],initialfile=f'حساب_کامل_{row[0]}.pdf')
        if not path:return None

        font=self._pdf_font()
        page_size=landscape(A4)
        doc=SimpleDocTemplate(path,pagesize=page_size,rightMargin=28,leftMargin=28,topMargin=42,bottomMargin=38,
                              title='گزارش کامل حساب مشتری',author='Jahan Accounting')
        styles=getSampleStyleSheet()
        title_style=ParagraphStyle('JFullTitlePro',parent=styles['Title'],fontName=font,fontSize=20,leading=26,
            alignment=TA_RIGHT,textColor=colors.HexColor('#17212B'),spaceAfter=4)
        sub_style=ParagraphStyle('JFullSubPro',parent=styles['Normal'],fontName=font,fontSize=12,leading=18,
            alignment=TA_RIGHT,textColor=colors.HexColor('#475569'),spaceAfter=7)
        section_style=ParagraphStyle('JFullSectionPro',parent=styles['Heading2'],fontName=font,fontSize=13.5,leading=19,
            alignment=TA_RIGHT,textColor=colors.HexColor('#17212B'),spaceBefore=7,spaceAfter=7)
        body_style=ParagraphStyle('JFullBodyPro',parent=styles['Normal'],fontName=font,fontSize=12.2,leading=18,
            alignment=TA_RIGHT,textColor=colors.HexColor('#1F2937'),wordWrap='RTL')
        header_style=ParagraphStyle('JFullHeaderPro',parent=body_style,fontSize=12.5,leading=18,
            alignment=TA_CENTER,textColor=colors.white)
        center_style=ParagraphStyle('JFullCenterPro',parent=body_style,alignment=TA_CENTER)
        num_style=ParagraphStyle('JFullNumPro',parent=body_style,alignment=TA_RIGHT)
        story=[]

        logo_path=os.path.join(RESOURCE_BASE,'logo.png')
        if not os.path.exists(logo_path): logo_path=os.path.join(BASE,'logo.png')
        if os.path.exists(logo_path):
            try:
                logo=Image(logo_path,width=54,height=54); logo.hAlign='RIGHT'
                story += [logo,Spacer(1,4)]
            except Exception: pass

        op=self._outgoing_profile_dict()
        if op.get("outgoing_name"):
            story.append(Paragraph(self._pdf_text(op["outgoing_name"]),title_style))
            meta=" | ".join(x for x in (op.get("outgoing_type"),op.get("outgoing_phone"),op.get("outgoing_address")) if x)
            if meta: story.append(Paragraph(self._pdf_text(meta),sub_style))
        story += [Paragraph(self._pdf_text('گزارش کامل حساب مشتری'),title_style),
                  Paragraph(self._pdf_text(f"مشتری: {row[1]} | تماس: {row[2] or '-'}"),sub_style)]
        if row[3]: story.append(Paragraph(self._pdf_text(f"آدرس: {row[3]}"),body_style))
        if row[4]: story.append(Paragraph(self._pdf_text(f"توضیحات مشتری: {row[4]}"),body_style))
        story.append(Spacer(1,8))

        def add_table(headers,rows,widths=None):
            # RTL layout: the first logical field is placed on the rightmost side.
            rtl_headers=list(reversed(headers))
            data=[[Paragraph(self._pdf_text(str(h)),header_style) for h in rtl_headers]]
            for rr in rows:
                vals=list(reversed([str(x) for x in rr]))
                data.append([Paragraph(self._pdf_text(x),body_style) for x in vals])
            total_width=page_size[0]-56
            if not widths:
                widths=[total_width/max(len(rtl_headers),1)]*len(rtl_headers)
            scale=total_width/sum(widths) if widths and sum(widths)>0 else 1
            widths=[w*scale for w in widths]
            tt=Table(data,repeatRows=1,colWidths=widths,hAlign='RIGHT')
            cmds=[
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#243447')),
                ('TEXTCOLOR',(0,0),(-1,0),colors.white),
                ('ALIGN',(0,0),(-1,0),'CENTER'),
                ('ALIGN',(0,1),(-1,-1),'RIGHT'),
                ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
                ('GRID',(0,0),(-1,-1),0.55,colors.HexColor('#B8C2CC')),
                ('TOPPADDING',(0,0),(-1,0),10),('BOTTOMPADDING',(0,0),(-1,0),10),
                ('TOPPADDING',(0,1),(-1,-1),9),('BOTTOMPADDING',(0,1),(-1,-1),9),
                ('RIGHTPADDING',(0,0),(-1,-1),7),('LEFTPADDING',(0,0),(-1,-1),7),
            ]
            for idx in range(1,len(data)):
                cmds.append(('BACKGROUND',(0,idx),(-1,idx),colors.HexColor('#F8FAFC') if idx%2==0 else colors.white))
            tt.setStyle(TableStyle(cmds))
            story.extend([tt,Spacer(1,12)])

        total_width=page_size[0]-56
        # خلاصه حرفه‌ای حساب به تفکیک ارز؛ بدون ریز تراکنش‌ها.
        # منطق: خالص بدون کمیشن = مجموع قرض - مجموع رسید؛
        # خالص با کمیشن = خالص بدون کمیشن - کمیشن.
        total_rows=[]
        for cur,gd,gc,gb,nd,nc,nb,comm in self.customer_account_totals(cid):
            code=CURRENCY_CODES.get(cur,cur.split(' - ')[0] if cur else cur)
            net_without=float(gb)
            net_with=net_without-float(comm)
            status='بدهکار' if net_with>0 else ('بستانکار' if net_with<0 else 'تسویه')
            total_rows.append([
                code,
                fmt_num(abs(float(gd))),
                fmt_num(abs(float(gc))),
                fmt_num(abs(net_without)),
                fmt_num(abs(float(comm))),
                fmt_num(abs(net_with)),
                status
            ])
        story.append(Paragraph(self._pdf_text('خلاصه حساب به تفکیک ارز'),section_style))
        add_table(
            ['ارز','مجموع قرض','مجموع رسید','خالص بدون کمیشن','کمیشن','خالص با کمیشن','وضعیت'],
            total_rows or [['-','0','0','0','0','0','تسویه']],
            [70,120,120,135,105,135,total_width-685]
        )
        # یک خط محاسبه روشن، بدون ایجاد جدول دوم و شلوغی اضافه.
        calc_style=ParagraphStyle('JCalcPro',parent=body_style,fontSize=11.5,leading=17,
                                  alignment=TA_RIGHT,textColor=colors.HexColor('#334155'),
                                  backColor=colors.HexColor('#F5F7F9'),borderColor=colors.HexColor('#D8DEE4'),
                                  borderWidth=0.5,borderPadding=8,spaceBefore=2,spaceAfter=8)
        calc_lines=[]
        for cur,gd,gc,gb,nd,nc,nb,comm in self.customer_account_totals(cid):
            code=CURRENCY_CODES.get(cur,cur.split(' - ')[0] if cur else cur)
            nw=float(gb); nf=nw-float(comm)
            calc_lines.append(f'{code}: مجموع قرض {fmt_num(abs(float(gd)))} − مجموع رسید {fmt_num(abs(float(gc)))} = خالص بدون کمیشن {fmt_num(abs(nw))} | کمیشن {fmt_num(abs(float(comm)))} | خالص با کمیشن {fmt_num(abs(nf))}')
        if calc_lines:
            story.append(Paragraph(self._pdf_text('محاسبه نهایی: ' + '  •  '.join(calc_lines)),calc_style))

        footer=" | ".join(x for x in (op.get("outgoing_name"),op.get("outgoing_phone"),op.get("outgoing_address")) if x)
        if footer: story.append(Paragraph(self._pdf_text(footer),body_style))

        def _page_footer(canvas, doc_obj):
            canvas.saveState()
            canvas.setStrokeColor(colors.HexColor('#CBD5E1'))
            canvas.line(28,28,page_size[0]-28,28)
            canvas.setFont(font,8.5)
            canvas.setFillColor(colors.HexColor('#64748B'))
            footer_txt=self._pdf_text(f"نرم افزار حسابداری جهان | گزارش کامل حساب مشتری | صفحه {doc_obj.page}")
            canvas.drawRightString(page_size[0]-28,16,footer_txt)
            canvas.restoreState()
        try:
            doc.build(story,onFirstPage=_page_footer,onLaterPages=_page_footer)
            self._open_file(path)
            if channel:self._share_pdf_menu(path,f'حساب کامل مشتری {row[1]}')
            return path
        except Exception as e:
            messagebox.showerror('PDF',f'ساخت گزارش حساب مشتری با خطا روبه‌رو شد:\n{e}')
            return None

    def send_customer_whatsapp(self, cid):
        row=self.db.execute("SELECT phone FROM customers WHERE id=?",(cid,)).fetchone()
        if not row: return
        if not row[0]:
            messagebox.showwarning("واتساپ","برای این مشتری شماره تماس ثبت نشده است."); return
        msg=self.customer_full_report(cid)
        phone=self.normalize_phone(row[0])
        webbrowser.open("https://wa.me/"+phone+"?text="+urllib.parse.quote(msg))

    def send_customer_telegram(self, cid):
        msg=self.customer_full_report(cid)
        if not msg: return
        # Telegram's official share link opens Telegram and lets the user choose the chat.
        url="https://t.me/share/url?url=&text="+urllib.parse.quote(msg)
        webbrowser.open(url)

    def _safe_calculate(self, expression):
        """محاسبه‌گر امن برای عبارت‌های عددی؛ بدون eval و بدون دسترسی به سیستم."""
        expression = str(expression or '').strip().replace('×','*').replace('÷','/').replace('−','-').replace('٫','.')
        expression = re.sub(r'(?<=\d)[,٬](?=\d)', '', expression)
        if not expression or len(expression) > 120:
            raise ValueError("عبارت نامعتبر است.")
        allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Add, ast.Sub, ast.Mult, ast.Div,
                   ast.FloorDiv, ast.Mod, ast.Pow, ast.USub, ast.UAdd, ast.Load)
        tree = ast.parse(expression, mode='eval')
        for node in ast.walk(tree):
            if not isinstance(node, allowed) or (isinstance(node, ast.Constant) and not isinstance(node.value, (int,float))):
                raise ValueError("فقط عملیات عددی مجاز است.")
            if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
                raise ValueError("توان در این محاسبه مجاز نیست.")
        ops={ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul, ast.Div:operator.truediv,
             ast.FloorDiv:operator.floordiv, ast.Mod:operator.mod}
        def ev(n):
            if isinstance(n, ast.Expression): return ev(n.body)
            if isinstance(n, ast.Constant): return float(n.value)
            if isinstance(n, ast.UnaryOp): return ev(n.operand) if isinstance(n.op, ast.UAdd) else -ev(n.operand)
            if isinstance(n, ast.BinOp):
                b=ev(n.right); a=ev(n.left)
                if isinstance(n.op, ast.Div) and b==0: raise ValueError("تقسیم بر صفر ممکن نیست.")
                if isinstance(n.op, (ast.FloorDiv,ast.Mod)) and b==0: raise ValueError("تقسیم بر صفر ممکن نیست.")
                return ops[type(n.op)](a,b)
            raise ValueError("عبارت نامعتبر است.")
        value=ev(tree)
        if abs(value) > 1e18: raise ValueError("نتیجه بیش از حد بزرگ است.")
        return value

    def _wa_receipt_customer_match(self, receipt_name, sender_name, sender_phone):
        candidates=[str(x or '').strip() for x in (receipt_name,sender_name) if str(x or '').strip()]
        phone_digits=self.normalize_phone(sender_phone) if sender_phone else ''
        rows=self.db.execute("SELECT id,name,phone FROM customers ORDER BY id").fetchall()
        for cid,name,phone in rows:
            if phone_digits and self.normalize_phone(phone)==phone_digits:
                return cid,name
            cn=str(name or '').strip().casefold()
            for cand in candidates:
                cc=cand.casefold()
                if cc==cn or (len(cc)>=3 and cc in cn) or (len(cn)>=3 and cn in cc):
                    return cid,name
        return None,None

    def _wa_extract_receipt(self, text, sender_name='', sender_phone=''):
        raw=str(text or '').strip()
        normalized=raw.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
        def find(patterns):
            for pat in patterns:
                m=re.search(pat, normalized, flags=re.I|re.M)
                if m: return m.group(1).strip()
            return ''
        receipt_name=find([r'(?:نام\s*(?:مشتری|شخص)|مشتری|نام)\s*[:：\-]\s*([^\n|]+)',r'(?:customer|name)\s*[:：\-]\s*([^\n|]+)'])
        receipt_no=find([r'(?:شماره\s*رسید|رسید\s*شماره|رسید|receipt\s*(?:no|number)?)\s*[:#：\-]?\s*([A-Za-z0-9\-/]+)'])
        date_v=find([r'(?:تاریخ|date)\s*[:：\-]\s*([0-9]{4}[\-/][0-9]{1,2}[\-/][0-9]{1,2})',r'([0-9]{1,2}[\-/][0-9]{1,2}[\-/][0-9]{2,4})'])
        amount_s=find([r'(?:مبلغ|جمع|قیمت|amount|total)\s*[:：=\-]?\s*([0-9][0-9,٬\. ]*)',r'([0-9][0-9,٬\. ]*)\s*(?:افغانی|AFN|USD|دالر|دلار|تومان|کلدار)'])
        currency='AFN'; low=normalized.lower()
        if any(x in low for x in ('usd','دالر','دلار')): currency='USD'
        elif 'تومان' in low: currency='IRR'
        elif 'کلدار' in low or 'pkr' in low: currency='PKR'
        try: amount=float(re.sub(r'[,٬ ]','',amount_s)) if amount_s else 0.0
        except: amount=0.0
        cid,cname=self._wa_receipt_customer_match(receipt_name,sender_name,sender_phone)
        return dict(receipt_name=receipt_name or sender_name,receipt_no=receipt_no,receipt_date=date_v,amount=amount,currency=currency,customer_id=cid,customer_name=cname or receipt_name or sender_name,raw_text=raw)

    def _wa_ocr_file(self, path):
        """OCR حرفه‌ای‌تر برای رسیدهای تصویری واتساپ.
        چند حالت پیش‌پردازش و چند PSM اجرا می‌شود و بهترین متن انتخاب می‌گردد.
        """
        if not OCR_OK: return ''
        try:
            img = Image.open(path).convert('RGB')
            # برای رسیدهای کوچک، بزرگ‌نمایی خوانایی OCR را بهتر می‌کند.
            w,h = img.size
            if max(w,h) < 1800:
                scale = min(3.0, 1800.0/max(w,h))
                img = img.resize((int(w*scale), int(h*scale)), Image.Resampling.LANCZOS)
            from PIL import ImageOps, ImageEnhance, ImageFilter
            variants=[img, ImageOps.autocontrast(ImageOps.grayscale(img)),
                      ImageEnhance.Contrast(ImageOps.grayscale(img)).enhance(1.8)]
            texts=[]
            for variant in variants:
                for psm in (6,11):
                    try:
                        txt=pytesseract.image_to_string(variant, lang='fas+ara+eng', config=f'--psm {psm}')
                        if txt and txt.strip(): texts.append(txt.strip())
                    except Exception:
                        pass
            if texts:
                # متنی که بیشترین کاراکتر و بیشترین نشانه عددی دارد معمولاً رسید کامل‌تری است.
                def score(t):
                    return len(t) + 12*len(re.findall(r'[0-9۰-۹]',t)) + 8*len(re.findall(r'(?:مبلغ|جمع|قیمت|رسید|تاریخ|مشتری|نام)',t))
                return max(texts,key=score)
        except Exception:
            pass
        return ''

    def _wa_image_metadata(self, path):
        """نام فایل تصویری واتساپ را هم برای تطبیق مشتری بررسی می‌کند."""
        base=os.path.splitext(os.path.basename(path))[0]
        base=re.sub(r'[_\-]+',' ',base).strip()
        return base

    def _wa_import_receipt_files(self, paths, group_name='', sender_name='', sender_phone=''):
        added=matched=pending=skipped=0
        for path in paths:
            if not os.path.isfile(path): continue
            try:
                raw=open(path,'rb').read(); source_hash=hashlib.sha256(raw).hexdigest()
                if self.db.execute('SELECT 1 FROM whatsapp_receipts WHERE source_hash=?',(source_hash,)).fetchone(): skipped+=1; continue
                ext=os.path.splitext(path)[1].lower(); text=''
                if ext in ('.txt','.text'): text=raw.decode('utf-8','ignore')
                elif ext in ('.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff'): text=self._wa_ocr_file(path)
                # اگر OCR نام مشتری را پیدا نکرد، نام فایل هم به عنوان سرنخ تطبیق استفاده شود.
                image_hint=self._wa_image_metadata(path) if ext in ('.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff') else ''
                effective_sender=sender_name or image_hint
                data=self._wa_extract_receipt(text,effective_sender,sender_phone)
                if not data['receipt_name'] and image_hint:
                    data['receipt_name']=image_hint
                    cid,cname=self._wa_receipt_customer_match(image_hint,sender_name,sender_phone)
                    if cid:
                        data['customer_id'],data['customer_name']=cid,cname
                status='ثبت خودکار' if data['customer_id'] else 'در انتظار تأیید'; now=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                self.db.execute("""INSERT INTO whatsapp_receipts(imported_at,group_name,sender_name,sender_phone,source_file,source_hash,receipt_name,receipt_no,receipt_date,amount,currency,raw_text,customer_id,customer_name,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (now,group_name,sender_name,sender_phone,path,source_hash,data['receipt_name'],data['receipt_no'],data['receipt_date'],data['amount'],data['currency'],data['raw_text'],data['customer_id'],data['customer_name'],status,''))
                rid=self.db.execute('SELECT last_insert_rowid()').fetchone()[0]
                if data['customer_id']:
                    rcurrency=data.get('currency') or 'AFN - افغانی'; rrate=self.get_rate_to_afn(rcurrency) or 1
                    rcur=self.db.execute('INSERT INTO receipts(created,customer_id,customer,receipt_type,amount,description,currency,rate,afn_amount) VALUES(?,?,?,?,?,?,?,?,?)',(now,data['customer_id'],data['customer_name'],'رسید واتساپ',data['amount'],f"گروه: {group_name or '-'} | فرستنده: {sender_name or '-'} | فایل: {os.path.basename(path)}",rcurrency,rrate,float(data['amount'])*float(rrate)))
                    rrid=rcur.lastrowid; rrno=self.db.execute('SELECT receipt_no FROM receipts WHERE id=?',(rrid,)).fetchone()[0] or rrid
                    self.db.execute('INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(now,data['customer_id'],data['customer_name'],'بستانکاری مشتری',data['amount'],f'رسید شماره {rrno} - واتساپ',rcurrency,rrate,float(data['amount'])*float(rrate),'receipt',rrid))
                    matched+=1
                else: pending+=1
                added+=1
            except Exception: continue
        self.db.commit(); return added,matched,pending,skipped

    def _wa_parse_export_chat(self, path):
        try: text=open(path,encoding='utf-8-sig').read()
        except Exception: text=open(path,encoding='utf-8',errors='ignore').read()
        lines=text.splitlines(); blocks=[]; current=[]
        start_re=re.compile(r'^\[?(\d{1,4}[\-/]\d{1,2}[\-/]\d{1,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?)\]?\s*[-–]\s*(.*)$')
        for line in lines:
            if start_re.match(line):
                if current: blocks.append('\n'.join(current))
                current=[line]
            elif current: current.append(line)
        if current: blocks.append('\n'.join(current))
        return blocks

    def _wa_scan_folder(self, folder, group_name=''):
        if not folder or not os.path.isdir(folder): return (0,0,0,0)
        paths=[]
        for name in os.listdir(folder):
            if os.path.splitext(name)[1].lower() in ('.txt','.png','.jpg','.jpeg','.webp','.bmp','.pdf'):
                paths.append(os.path.join(folder,name))
        return self._wa_import_receipt_files(paths,group_name)

    def whatsapp_receipt_center(self):
        self.clear()
        RTLLabel(self.main,text='📱 مرکز هوشمند رسیدهای واتساپ',bg='#F4F6F8',fg='#1B2733',font=('Tahoma',19,'bold')).pack(anchor='e',padx=16,pady=(12,4))
        RTLLabel(self.main,text='رسید متنی، PDF یا تصویر (JPG/PNG/WEBP/TIFF) را دریافت کنید؛ متن تصویر خوانده، مبلغ و نام استخراج و با مشتری تطبیق داده می‌شود.',bg='#F4F6F8',fg='#687582',font=('Tahoma',9)).pack(anchor='e',padx=16)
        # اتصال رسمی واتساپ: این بخش فقط وضعیت و تنظیمات مجاز را نگه می‌دارد.
        # خواندن گروه‌های معمولی با روش‌های غیررسمی یا اسکرپ واتساپ عمداً انجام نمی‌شود.
        official=tk.Frame(self.main,bg='#FFFFFF',highlightbackground='#D8DEE4',highlightthickness=1); official.pack(fill='x',padx=16,pady=(8,4))
        wa_row=self.db.execute('SELECT COALESCE(official_enabled,0),COALESCE(connection_status,\'آماده اتصال رسمی\'),COALESCE(business_phone,\'\'),COALESCE(webhook_url,\'\') FROM whatsapp_settings WHERE id=1').fetchone()
        wa_enabled=tk.BooleanVar(value=bool(wa_row[0]) if wa_row else False)
        RTLLabel(official,text='🤖 دستیار هوشمند واتساپ',bg='#FFFFFF',fg='#1B2733',font=('Tahoma',12,'bold')).pack(anchor='e',padx=14,pady=(10,2))
        RTLLabel(official,text='اتصال فقط از مسیر رسمی و مجاز. پس از اتصال، متن و تصویر رسید برای تشخیص هوشمند آماده می‌شود و ثبت مالی بدون تأیید شما انجام نمی‌گیرد.',bg='#FFFFFF',fg='#687582',font=('Tahoma',9),wraplength=760,justify='right').pack(anchor='e',padx=14,pady=3)
        status_var=tk.StringVar(value=(wa_row[1] if wa_row else 'آماده اتصال رسمی'))
        def toggle_official():
            enabled=1 if wa_enabled.get() else 0
            status='فعال' if enabled else 'خاموش'
            self.db.execute("INSERT INTO whatsapp_settings(id,official_enabled,connection_status) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET official_enabled=excluded.official_enabled,connection_status=excluded.connection_status",(enabled,status)); self.db.commit(); status_var.set(status)
        tk.Checkbutton(official,text='فعال‌سازی دستیار واتساپ',variable=wa_enabled,command=toggle_official,bg='#FFFFFF',fg='#1B2733',selectcolor='#FFFFFF',activebackground='#FFFFFF',font=('Tahoma',10,'bold')).pack(anchor='e',padx=14,pady=5)
        RTLLabel(official,textvariable=status_var,bg='#FFFFFF',fg='#128C7E',font=('Tahoma',9,'bold')).pack(anchor='e',padx=14,pady=(0,8))
        cfg=tk.Frame(self.main,bg='#FFFFFF',highlightbackground='#D8DEE4',highlightthickness=1); cfg.pack(fill='x',padx=16,pady=10)
        RTLLabel(cfg,text='تنظیمات گروه و منبع دریافت',bg='#FFFFFF',fg='#1B2733',font=('Tahoma',11,'bold')).pack(anchor='e',padx=14,pady=8)
        group=tk.StringVar(); sender=tk.StringVar(); phone=tk.StringVar(); folder=tk.StringVar()
        old=self.db.execute('SELECT group_name,import_folder FROM whatsapp_settings WHERE id=1').fetchone()
        if old: group.set(old[0] or ''); folder.set(old[1] or '')
        for label,var in [('نام گروه واتساپ',group),('نام فرستنده (اختیاری)',sender),('شماره فرستنده (اختیاری)',phone)]:
            RTLLabel(cfg,text=label,bg='#FFFFFF',fg='#687582').pack(anchor='e',padx=14,pady=(4,2)); tk.Entry(cfg,textvariable=var,bg='#F8FAFC',fg='#1B2733',relief='flat',justify='right').pack(fill='x',padx=14,pady=3,ipady=6)
        row=tk.Frame(cfg,bg='#FFFFFF'); row.pack(fill='x',padx=14,pady=6)
        tk.Entry(row,textvariable=folder,bg='#F8FAFC',fg='#1B2733',relief='flat').pack(side='right',fill='x',expand=True,ipady=6)
        self.button(row,'📁 پوشه رسیدها',lambda:folder.set(filedialog.askdirectory() or folder.get())).pack(side='left',padx=6)
        def save_cfg():
            self.db.execute('INSERT INTO whatsapp_settings(id,group_name,import_folder,auto_watch,last_scan) VALUES(1,?,?,0,?) ON CONFLICT(id) DO UPDATE SET group_name=excluded.group_name,import_folder=excluded.import_folder,last_scan=excluded.last_scan',(group.get().strip(),folder.get().strip(),datetime.now().isoformat())); self.db.commit(); messagebox.showinfo('واتساپ','تنظیمات دریافت رسید ذخیره شد.')
        self.button(cfg,'✓ ذخیره تنظیمات',save_cfg).pack(anchor='e',padx=14,pady=8)
        action=tk.Frame(self.main,bg='#F4F6F8'); action.pack(fill='x',padx=16,pady=4)
        def refresh():
            for item in tree.get_children(): tree.delete(item)
            for r in self.db.execute('SELECT id,group_name,sender_name,receipt_name,amount,customer_name,status,source_file FROM whatsapp_receipts ORDER BY id DESC LIMIT 100'):
                tree.insert('', 'end', values=(r[0],r[1] or '-',r[2] or '-',r[3] or '-',fmt_num(r[4]),r[5] or 'بدون تطبیق',r[6],os.path.basename(r[7])))
        def import_files():
            paths=filedialog.askopenfilenames(title='انتخاب رسیدها',filetypes=[('رسید، تصویر و PDF','*.txt *.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff *.pdf'),('همه فایل‌ها','*.*')])
            if not paths:return
            a,m,p,s=self._wa_import_receipt_files(paths,group.get(),sender.get(),phone.get()); refresh(); messagebox.showinfo('پردازش رسیدها',f'دریافت‌شده: {a}\nثبت خودکار: {m}\nدر انتظار تطبیق: {p}\nتکراری: {s}')
        def import_chat():
            path=filedialog.askopenfilename(title='فایل Export Chat واتساپ',filetypes=[('Text','*.txt')])
            if not path:return
            blocks=self._wa_parse_export_chat(path); created=0
            for i,b in enumerate(blocks):
                if not any(k in b.lower() for k in ('رسید','مبلغ','جمع','receipt','amount','total')): continue
                local_sender=sender.get().strip()
                first=(b.splitlines() or [''])[0]
                m=re.search(r'[-–]\s*([^:：]+):\s*(.*)$',first)
                if m: local_sender=m.group(1).strip()
                elif ' - ' in first: local_sender=first.split(' - ',1)[1].strip()
                fake=os.path.join(tempfile.gettempdir(),f'wa_chat_{i}.txt'); open(fake,'w',encoding='utf-8').write(b)
                a,_,_,_=self._wa_import_receipt_files([fake],group.get(),local_sender,phone.get()); created+=a
            refresh(); messagebox.showinfo('Export Chat',f'{created} پیام رسیدمانند تحلیل و وارد صف رسیدها شد.')
        self.button(action,'📎 افزودن رسید / تصویر',import_files).pack(side='right',padx=4)
        self.button(action,'💬 تحلیل Export Chat',import_chat,'#475569').pack(side='right',padx=4)
        self.button(action,'↻ تازه‌سازی',refresh,'#0f766e').pack(side='right',padx=4)
        self.button(action,'📥 اسکن پوشه متصل',lambda:(self._wa_scan_folder(folder.get(),group.get()),refresh()),'#7C3AED').pack(side='right',padx=4)
        RTLLabel(self.main,text='نحوه اتصال: ابتدا اتصال رسمی واتساپ Business را پیکربندی کنید؛ سپس منبع مجاز/گروه پشتیبانی‌شده را در همین صفحه ثبت کنید. برای گروه معمولی، برنامه از خواندن مخفی یا اسکرپ واتساپ استفاده نمی‌کند.',bg='#F4F6F8',fg='#687582',font=('Tahoma',9),wraplength=900,justify='right').pack(anchor='e',padx=16,pady=3)
        if not OCR_OK: RTLLabel(self.main,text='برای OCR تصویر، Pillow و Tesseract را روی سیستم نصب کنید.',bg='#F4F6F8',fg='#B45309',font=('Tahoma',9)).pack(anchor='e',padx=16,pady=4)
        box=tk.Frame(self.main,bg='#FFFFFF',highlightbackground='#D8DEE4',highlightthickness=1); box.pack(fill='both',expand=True,padx=16,pady=8)
        cols=('id','group','sender','name','amount','customer','status','source'); tree=ttk.Treeview(box,columns=cols,show='headings')
        heads={'id':'#','group':'گروه','sender':'فرستنده','name':'نام رسید','amount':'مبلغ','customer':'مشتری','status':'وضعیت','source':'منبع'}
        for x in cols: tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,width=110,anchor='center')
        tree.column('source',width=180); tree.pack(fill='both',expand=True,padx=10,pady=10)
        def confirm_selected():
            sel=tree.selection()
            if not sel:return
            rid=int(tree.item(sel[0],'values')[0]); row=self.db.execute('SELECT customer_id,customer_name,receipt_name,sender_name,amount,group_name,source_file FROM whatsapp_receipts WHERE id=?',(rid,)).fetchone()
            customers=self.db.execute('SELECT id,name FROM customers ORDER BY name').fetchall(); win=tk.Toplevel(self); win.title('تطبیق رسید واتساپ'); win.geometry('480x300'); win.configure(bg='#F4F6F8')
            RTLLabel(win,text=f"رسید: {row[2] or row[3] or '-'} | مبلغ: {fmt_num(row[4])}",bg='#F4F6F8',fg='#1B2733',font=('Tahoma',11,'bold')).pack(pady=14)
            cb=LocalizedCombobox(win,values=[f'{i} - {n}' for i,n in customers],state='readonly'); cb.pack(fill='x',padx=25,pady=8)
            def confirm():
                if cb.current()<0:return
                cid,cname=customers[cb.current()]; now=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                self.db.execute('UPDATE whatsapp_receipts SET customer_id=?,customer_name=?,status=? WHERE id=?',(cid,cname,'ثبت و تأیید شد',rid))
                wrow=self.db.execute('SELECT amount,currency FROM whatsapp_receipts WHERE id=?',(rid,)).fetchone()
                wcur=wrow[1] if wrow and wrow[1] else 'AFN - افغانی'; wrate=self.get_rate_to_afn(wcur) or 1; wamount=float(wrow[0] if wrow else row[4] or 0)
                rcur=self.db.execute('INSERT INTO receipts(created,customer_id,customer,receipt_type,amount,description,currency,rate,afn_amount) VALUES(?,?,?,?,?,?,?,?,?)',(now,cid,cname,'رسید واتساپ',wamount,f'گروه: {row[5] or "-"} | فرستنده: {row[3] or "-"} | فایل: {os.path.basename(row[6])}',wcur,wrate,wamount*wrate))
                rrid=rcur.lastrowid; rrno=self.db.execute('SELECT receipt_no FROM receipts WHERE id=?',(rrid,)).fetchone()[0] or rrid
                self.db.execute('INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(now,cid,cname,'بستانکاری مشتری',wamount,f'رسید شماره {rrno} - واتساپ',wcur,wrate,wamount*wrate,'receipt',rrid))
                self.db.commit(); win.destroy(); refresh()
            self.button(win,'✓ ثبت در رسید مشتری',confirm).pack(side="bottom",pady=18)
        self.button(box,'👤 تطبیق و ثبت مشتری انتخاب‌شده',confirm_selected,'#0f766e').pack(pady=6)
        refresh()

    def _extract_ai_response_text(self, data):
        """Pull the plain text answer out of an OpenAI Responses API reply,
        tolerating a few compatible response shapes."""
        parts=[]
        for item in data.get("output",[]) if isinstance(data,dict) else []:
            for content in item.get("content",[]) if isinstance(item,dict) else []:
                if isinstance(content,dict):
                    txt=content.get("text")
                    if isinstance(txt,str) and txt.strip(): parts.append(txt.strip())
        if parts: return "\n\n".join(parts)
        if isinstance(data,dict):
            txt=data.get("output_text")
            if isinstance(txt,str) and txt.strip(): return txt.strip()
            choices=data.get("choices") or []
            if choices and isinstance(choices[0],dict):
                msg=choices[0].get("message",{})
                if isinstance(msg,dict) and isinstance(msg.get("content"),str): return msg["content"].strip()
        return ""

    def _friendly_ai_error(self, code, body):
        """Turn an OpenAI HTTP error into a specific, actionable Persian
        message instead of a generic 'check your internet' guess."""
        low=(body or "").lower()
        if code==401:
            return "کلید API نامعتبر یا اشتباه است. یک کلید تازه از حساب OpenAI بسازید و دوباره وارد کنید."
        if code==403 and any(w in low for w in ("country","region","territory","unsupported")):
            return ("OpenAI از کشور/منطقه‌ای که این درخواست از آن رفته پشتیبانی نمی‌کند. توجه: افغانستان در لیست "
                     "کشورهای پشتیبانی‌شده‌ی OpenAI هست، ولی ایران نیست — اگر اینترنت این کامپیوتر از مسیر ایران یا "
                     "یک VPN/پراکسی خارج از افغانستان رد می‌شود، دقیقاً همین باعث این خطا می‌شود.")
        if code==429:
            if "quota" in low or "billing" in low or "insufficient" in low:
                return "حساب OpenAI شما اعتبار/Billing کافی ندارد. در پنل حساب OpenAI یک روش پرداخت اضافه یا شارژ کنید."
            return "تعداد درخواست‌ها در این لحظه زیاد شده (Rate limit). چند ثانیه صبر کنید و دوباره امتحان کنید."
        if code==400:
            return "درخواست رد شد؛ احتمالاً نام مدل اشتباه یا منسوخ است. مدل را از «تنظیم هوش مصنوعی» عوض کنید.\n\nجزئیات فنی: "+body[:400]
        if code==404:
            return "این مدل روی حساب شما در دسترس نیست. مدل دیگری از لیست انتخاب کنید.\n\nجزئیات فنی: "+body[:300]
        return f"OpenAI خطای HTTP {code} برگرداند.\n\nجزئیات فنی: "+body[:400]

    def _ai_raw_request(self, key, model, input_messages, instructions, max_tokens=300, timeout=25):
        """Low-level, shared call to OpenAI's Responses API used by the chat
        box, the connection-test button, and the Android sync proxy alike.
        Returns (ok, text_or_error_message) - never raises."""
        key = str(key or "").strip().strip('"\'')
        if key.lower().startswith("bearer "):
            key = key[7:].strip()
        model = str(model or "gpt-5.6-luna").strip()
        payload={"model":model,"instructions":instructions,"input":input_messages,"max_output_tokens":max_tokens}
        try:
            req=urllib.request.Request("https://api.openai.com/v1/responses",
                data=json.dumps(payload,ensure_ascii=False).encode("utf-8"),
                headers={"Authorization":"Bearer "+key,"Content-Type":"application/json","User-Agent":"JahanAccounting/16.4"},
                method="POST")
            with _jahan_urlopen(req,timeout=timeout) as resp:
                data=json.loads(resp.read().decode("utf-8","ignore"))
            text=self._extract_ai_response_text(data)
            if not text:
                return False,"پاسخ از OpenAI دریافت شد ولی متنی داخلش نبود (ممکن است مدل یا فرمت درخواست پذیرفته نشده باشد)."
            return True,text
        except urllib.error.HTTPError as e:
            try: body=e.read().decode("utf-8","ignore")
            except Exception: body=""
            return False,self._friendly_ai_error(e.code,body)
        except urllib.error.URLError as e:
            return False,("اتصال به OpenAI برقرار نشد - اینترنت این کامپیوتر قطع است یا این سایت از این شبکه/کشور مسدود است.\n\nجزئیات: "+str(getattr(e,"reason",e)))
        except socket.timeout:
            return False,"درخواست بیش از حد طول کشید (Timeout). اتصال اینترنت را بررسی کنید و دوباره امتحان کنید."
        except Exception as e:
            return False,"خطای غیرمنتظره: "+str(e)[:400]

    def _ai_test_connection(self, key, model):
        ok,result=self._ai_raw_request(key,model,
            [{"role":"user","content":"فقط بنویس: سلام"}],
            "این فقط یک تست اتصال کوتاه است؛ خیلی مختصر جواب بده.",
            max_tokens=20, timeout=20)
        if ok:
            return True,"✅ اتصال موفق بود. مدل «"+model+"» پاسخ داد: "+result[:120]
        return False,"❌ "+result

    def ai_assistant_page(self):
        self.clear()
        RTLLabel(self.main,text="🤖 دستیار هوشمند حسابداری",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=(14,3))
        RTLLabel(self.main,text="پاسخ‌ها با مدل هوش مصنوعی تولید می‌شوند؛ جستجوی خودکار در سایت‌ها انجام نمی‌شود. فقط اگر صریحاً بگویید سایتی را باز کنم، مرورگر باز می‌شود.",
                 bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))

        actions=tk.Frame(self.main,bg="#F4F6F8"); actions.pack(fill="x",padx=20,pady=4)
        self.button(actions,"⚙ تنظیم هوش مصنوعی",lambda:configure_ai(),"#7C3AED").pack(side="right",padx=4)
        self.button(actions,"📱 تحلیل رسید واتساپ",self.whatsapp_receipt_center,"#128c7e").pack(side="right",padx=4)
        self.button(actions,"🧮 ماشین حساب",lambda:self._ai_focus_input()).pack(side="right",padx=4)

        box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        box.pack(fill="x",padx=20,pady=8)
        RTLLabel(box,text="سؤال یا درخواست شما",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold")).pack(anchor="e",padx=16,pady=(12,3))
        q=tk.StringVar()
        ent=tk.Entry(box,textvariable=q,bg="#F8FAFC",fg="#1B2733",insertbackground="#1B2733",
                     relief="flat",font=ui_font(13,"bold"),justify="right")
        ent.pack(fill="x",padx=16,pady=5,ipady=10)
        hint=RTLLabel(box,text="مثال: «سلام، امروز چه کارهایی دارم؟» یا «فرق دارایی و بدهی چیست؟» یا «کمک کن یک گزارش مالی بفهمم». ",bg="#FFFFFF",fg="#7D8892",font=ui_font(8))
        hint.pack(anchor="e",padx=16,pady=(0,5))
        quick=tk.Frame(box,bg="#FFFFFF"); quick.pack(fill="x",padx=12,pady=2)
        result_holder=tk.Frame(box,bg="#FFFFFF"); result_holder.pack(fill="x",padx=16,pady=7)
        # Windows/Tkinter Text has unreliable BiDi behavior when Persian is mixed
        # with numbers, Latin codes and punctuation. In particular, LRM/LRE/RLM
        # controls can make the number jump to the beginning of a visual line.
        # Keep the logical Unicode text untouched and let a simple right-aligned
        # Text paragraph render it naturally. Numeric/Latin runs are NOT wrapped
        # in invisible directional controls.
        result=tk.Text(result_holder,height=11,bg="#F8FAFC",fg="#1B2733",relief="flat",font=ui_font(13,"bold"),wrap="word",
                       padx=18,pady=12,spacing1=4,spacing3=7)
        result.tag_configure("ai_rtl",justify="right",font=ui_font(13,"bold"),lmargin1=8,lmargin2=8)
        result.tag_configure("ai_ltr",justify="left",font=ui_font(13,"bold"),lmargin1=8,lmargin2=8)
        result_scroll=tk.Scrollbar(result_holder,orient="vertical",command=result.yview,width=12); result.configure(yscrollcommand=result_scroll.set)
        result_scroll.pack(side="right",fill="y"); result.pack(side="left",fill="both",expand=True)
        def _ai_display_line(line):
            """Normalize one logical AI line without injecting BiDi control chars.

            The previous implementation inserted LRM/LRE/RLM around numbers.
            On Windows/Tk this was the direct cause of values appearing before
            Persian labels. The UI now preserves the original logical order and
            only normalizes the accounting separator.
            """
            line=_clean_ui_glyphs(str(line or "").strip())
            if not line:
                return ""
            line=re.sub(r"(?P<label>[^\n:=|]{1,100}?)\s*(?:[:：]|\s[-–—]\s)\s*(?=[0-9۰-۹])",
                         lambda m:m.group("label").rstrip()+" = ", line)
            # Remove any directional controls that may have been returned by the
            # model or introduced by an older formatter.
            return re.sub(r"[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]", "", line)

        def _insert_ai_result(widget, text):
            widget.config(state="normal")
            widget.delete("1.0","end")
            text=str(text or "")
            clean_text=_clean_ui_glyphs(text)
            lines=clean_text.splitlines() or [""]
            for idx,plain in enumerate(lines):
                safe_plain=_ai_display_line(plain)
                # Pure numeric/calculation lines are intentionally left aligned;
                # mixed Persian lines remain right aligned as natural RTL text.
                has_persian=bool(re.search(r"[\u0600-\u06ff]", plain))
                tag="ai_rtl" if has_persian else "ai_ltr"
                widget.insert("end",safe_plain,tag)
                if idx < len(lines)-1:
                    widget.insert("end","\n",tag)
            widget.config(state="disabled")
        _insert_ai_result(result,"سلام! من دستیار هوشمند شما هستم. سؤال‌تان را طبیعی و مثل صحبت با یک انسان بنویسید.")
        status=RTLLabel(box,text="● آماده",bg="#FFFFFF",fg="#0F766E",font=ui_font(8,"bold")); status.pack(anchor="e",padx=16,pady=(0,5))

        history=[]
        # Keep the last verified credentials in memory for this page. This avoids
        # a stale/second database connection causing the chat button to think the
        # key is missing even though the connection test just succeeded.
        runtime_ai_key = {"key": "", "model": "gpt-5.6-luna"}

        def _norm_ai_key(value):
            value = str(value or "").strip().strip("\"'")
            if value.lower().startswith("bearer "):
                value = value[7:].strip()
            return value

        def _norm_ai_text(value):
            # Normalize Persian/Arabic variants, punctuation and invisible
            # characters so phrases such as «حساب احمد را نشان بده» match
            # the exact customer name stored in SQLite.
            text=str(value or "").strip().lower()
            text=text.replace("\u200c"," ").replace("\u200d","").replace("\ufeff","")
            text=text.translate(str.maketrans("يىكۀةؤإأٱ","ییکهةؤااا"))
            text=re.sub(r"[\u064B-\u065F\u0670]", "", text)
            text=re.sub(r"[()\[\]{}<>«»،,:;!?؟\"'`|/\\]", " ", text)
            text=re.sub(r"\s+", " ", text)
            return text.strip()

        def get_ai_setting(key, default=""):
            try:
                row=self.db.execute("SELECT value FROM app_settings WHERE key=?",(key,)).fetchone()
                value = str(row[0]) if row and row[0] is not None else str(default or "")
                value = value.strip()
                if key == "ai_api_key":
                    value = value.strip('"\'')
                    if value.lower().startswith("bearer "):
                        value = value[7:].strip()
                return value
            except Exception:
                return str(default or "")

        def set_ai_setting(key, value):
            self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES(?,?)",(key,str(value)))
            self.db.commit()

        runtime_ai_key["key"] = _norm_ai_key(get_ai_setting("ai_api_key", os.environ.get("OPENAI_API_KEY", "")))
        runtime_ai_key["model"] = get_ai_setting("ai_model", "gpt-5.6-luna") or "gpt-5.6-luna"

        def configure_ai():
            win=tk.Toplevel(self); win.title("تنظیم هوش مصنوعی"); win.geometry("580x460"); win.minsize(540,430); win.configure(bg="#F4F6F8"); win.transient(self); win.grab_set()
            RTLLabel(win,text="اتصال دستیار به مدل هوش مصنوعی",bg="#F4F6F8",fg="#1B2733",font=ui_font(15,"bold")).pack(anchor="e",padx=24,pady=(18,6))
            RTLLabel(win,text="برای پاسخ‌های واقعی و طبیعی مثل ChatGPT، یک کلید API از OpenAI وارد کنید. دستیار در حالت عادی هیچ جستجوی وبی انجام نمی‌دهد.",bg="#F4F6F8",fg="#687582",font=ui_font(9),wraplength=520,justify="right").pack(anchor="e",padx=24,pady=4)
            RTLLabel(win,text="کلید API",bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",padx=24,pady=(12,3))
            saved_key = _norm_ai_key(get_ai_setting("ai_api_key", os.environ.get("OPENAI_API_KEY", "")))
            keyvar=tk.StringVar(value=saved_key)
            keyent=tk.Entry(win,textvariable=keyvar,show="•",justify="left",bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10)); keyent.pack(fill="x",padx=24,ipady=8)

            # Reliable clipboard support for the API key field.  Some global
            # Tk bindings can swallow Ctrl+V, so handle paste directly here.
            def paste_api_key(event=None):
                try:
                    value=win.clipboard_get()
                except Exception:
                    try:
                        value=self.clipboard_get()
                    except Exception:
                        return "break"
                value=str(value).replace("\r","").replace("\n","").strip()
                if not value:
                    return "break"
                try:
                    keyent.delete(0,"end")
                    keyent.insert(0,value)
                    keyent.icursor("end")
                    keyvar.set(value)
                except Exception:
                    pass
                return "break"
            keyent.bind("<Control-v>", paste_api_key)
            keyent.bind("<Control-V>", paste_api_key)
            keyent.bind("<Control-Shift-v>", paste_api_key)
            keyent.bind("<Control-Shift-V>", paste_api_key)
            keyent.bind("<Shift-Insert>", paste_api_key)

            # Right-click menu: Paste / Copy / Cut / Select All.
            key_menu=tk.Menu(win,tearoff=0)
            key_menu.add_command(label="چسباندن",command=lambda: paste_api_key())
            key_menu.add_command(label="کپی",command=lambda: keyent.event_generate("<<Copy>>"))
            key_menu.add_command(label="برش",command=lambda: keyent.event_generate("<<Cut>>"))
            key_menu.add_separator()
            key_menu.add_command(label="انتخاب همه",command=lambda: keyent.select_range(0,"end"))
            def show_key_menu(event):
                try: key_menu.tk_popup(event.x_root,event.y_root)
                finally: key_menu.grab_release()
            keyent.bind("<Button-3>", show_key_menu)
            RTLLabel(win,text="مدل پیشنهادی: GPT-5.6 Luna  |  شناسه: gpt-5.6-luna",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=24,pady=8)
            modelvar=tk.StringVar(value=get_ai_setting("ai_model","gpt-5.6-luna") or "gpt-5.6-luna")
            RTLLabel(win,text="مدل (اختیاری)",bg="#F4F6F8",fg="#1B2733",font=ui_font(9,"bold")).pack(anchor="e",padx=24,pady=(2,2))
            LocalizedCombobox(win,textvariable=modelvar,values=("gpt-5.6-luna","gpt-5.6-terra","gpt-5.6-sol","gpt-4.1"),state="readonly",justify="right").pack(fill="x",padx=24)

            test_status=RTLLabel(win,text="بعد از وارد کردن کلید، حتماً «تست اتصال» را بزنید تا مطمئن شوید کار می‌کند.",
                                  bg="#F4F6F8",fg="#687582",font=ui_font(9),wraplength=520,justify="right")
            test_status.pack(anchor="e",padx=24,pady=(14,0),fill="x")
            def run_test():
                key=_norm_ai_key(keyvar.get())
                model=modelvar.get().strip() or "gpt-5.6-luna"
                if not key:
                    test_status.config(text="ابتدا کلید API را وارد کنید.",fg="#B45309"); return
                # Persist the exact key/model before testing. This prevents the
                # assistant page from reading a different/old configuration.
                set_ai_setting("ai_api_key", key)
                set_ai_setting("ai_model", model)
                runtime_ai_key["key"] = key
                runtime_ai_key["model"] = model
                test_status.config(text="● در حال آزمایش اتصال…",fg="#B45309")
                def worker():
                    ok,msg=self._ai_test_connection(key,model)
                    def apply():
                        if win.winfo_exists(): test_status.config(text=msg,fg="#0F766E" if ok else "#B91C1C")
                    try: self.after(0,apply)
                    except Exception: pass
                threading.Thread(target=worker,daemon=True).start()
            testrow=tk.Frame(win,bg="#F4F6F8"); testrow.pack(fill="x",padx=24,pady=(8,0))
            self.button(testrow,"🔌 تست اتصال",run_test,"#2563EB").pack(side="right")

            def save():
                key=_norm_ai_key(keyvar.get())
                model=modelvar.get().strip() or "gpt-5.6-luna"
                if key: set_ai_setting("ai_api_key",key)
                else:
                    self.db.execute("DELETE FROM app_settings WHERE key='ai_api_key'"); self.db.commit()
                set_ai_setting("ai_model",model)
                runtime_ai_key["key"] = key
                runtime_ai_key["model"] = model
                win.destroy(); status.config(text="● تنظیمات ذخیره شد",fg="#0F766E")
            self.button(win,"✓ ذخیره تنظیمات",save,"#0F766E").pack(side="bottom",pady=18)

        def open_requested_site(question):
            t=_norm_ai_text(question)
            open_words=("باز کن","بازش کن","باز شود","باز کردن","برو به","وارد شو")
            if not any(x in t for x in open_words): return None
            sites={
                "ویکیپدیا":"https://fa.wikipedia.org","ویکی پدیا":"https://fa.wikipedia.org","wikipedia":"https://www.wikipedia.org",
                "گوگل":"https://www.google.com","google":"https://www.google.com","یوتیوب":"https://www.youtube.com","youtube":"https://www.youtube.com",
                "واتساپ":"https://web.whatsapp.com","whatsapp":"https://web.whatsapp.com","تلگرام":"https://web.telegram.org","telegram":"https://web.telegram.org",
                "فیس بوک":"https://www.facebook.com","facebook":"https://www.facebook.com","اینستاگرام":"https://www.instagram.com","instagram":"https://www.instagram.com",
            }
            for name,url in sites.items():
                if name in t:
                    webbrowser.open(url); return f"سایت {name} را در مرورگر پیش‌فرض ویندوز باز کردم."
            m=re.search(r"(?:https?://)?(?:www\.)?([a-z0-9-]+\.[a-z]{2,})(?:/[^ ]*)?", t)
            if m:
                url=m.group(0); url=url if url.startswith("http") else "https://"+url; webbrowser.open(url); return "سایت را در مرورگر پیش‌فرض ویندوز باز کردم."
            return None

        def _accounting_context(question=""):
            """Build live, read-only accounting context for the AI."""
            conn=None
            try:
                # This function runs in the AI worker thread.  The main Tkinter
                # database connection is intentionally not shared across threads.
                # Open a short-lived read connection for the AI context instead.
                conn=sqlite3.connect(DB, timeout=10)
                c=conn.cursor()
                qn=_norm_ai_text(question)
                customers=int(c.execute("SELECT COUNT(*) FROM customers").fetchone()[0] or 0)
                transactions=int(c.execute("SELECT COUNT(*) FROM transactions").fetchone()[0] or 0)
                lines=[f"آمار کلی برنامه: {customers} مشتری و {transactions} معامله ثبت شده است."]

                rows=c.execute("SELECT kind, currency, COUNT(*), COALESCE(SUM(amount),0), COALESCE(SUM(afn_amount),0) FROM transactions GROUP BY kind, currency ORDER BY kind, currency").fetchall()
                if rows:
                    lines.append("خلاصه معاملات بر اساس نوع و ارز:")
                    for kind,currency,cnt,total,afn in rows:
                        lines.append(f"- {kind or 'نامشخص'} | {currency or 'نامشخص'} | تعداد {cnt} | مبلغ {fmt_num(total)} | معادل ثبت‌شده AFN {fmt_num(afn)}")

                # Natural-language customer requests are intentionally broad.
                # Persian users commonly write «مشتریا»، «مشتری‌ها»، «مشخصات
                # مشتری‌ها» or «اطلاعات مشتریان»; all of these must trigger a
                # live database lookup instead of letting the model guess that
                # the database is unavailable.
                customer_list_words=(
                    "لیست", "فهرست", "اسامی", "نام", "مشخصات", "اطلاعات",
                    "شماره", "تلفن", "آدرس", "جزئیات", "همه"
                )
                customer_aliases=(
                    "مشتری", "مشتریا", "مشتری ها", "مشتریها", "مشتری هاً",
                    "مشتری‌ها", "مشتریان", "پېرودونکی"
                )
                wants_customer_list = (
                    any(alias in qn for alias in customer_aliases) and
                    any(word in qn for word in customer_list_words)
                ) or any(phrase in qn for phrase in (
                    "لیست مشتریان", "فهرست مشتریان", "اطلاعات مشتریان",
                    "مشخصات مشتریان", "لیست مشتریا", "مشخصات مشتریا",
                    "اطلاعات مشتریا", "نام و شماره مشتری"
                ))
                if wants_customer_list:
                    cr=c.execute("SELECT id,name,phone,address,balance,notes FROM customers ORDER BY name COLLATE NOCASE").fetchall()
                    lines.append("داده زنده پایگاه داده — فهرست و مشخصات مشتریان:")
                    if cr:
                        for cid,name,phone,address,balance,notes in cr[:300]:
                            lines.append(
                                f"- شناسه {cid} | نام: {name or '-'} | تلفن: {phone or '-'} | "
                                f"آدرس: {address or '-'} | مانده ثبت‌شده: {fmt_num(balance or 0)} | "
                                f"یادداشت: {notes or '-'}"
                            )
                        if len(cr)>300:
                            lines.append(f"- تعداد مشتریان بیشتر از ۳۰۰ مورد است؛ ۳۰۰ مورد اول نمایش داده شد. مجموع: {len(cr)}")
                    else:
                        lines.append("- هیچ مشتری در پایگاه داده فعلی ثبت نشده است.")

                tx_words=("معامله","معاملات","وضعیت معاملات","فروش","خرید","تراکنش","تراکنش ها","گزارش معامله","گزارش معاملات")
                if any(w in qn for w in tx_words):
                    tr=c.execute("SELECT id,created,kind,currency,amount,rate,customer,notes FROM transactions ORDER BY id DESC LIMIT 100").fetchall()
                    lines.append("آخرین معاملات ثبت‌شده (حداکثر ۱۰۰ مورد):")
                    if tr:
                        for tid,created,kind,currency,amount,rate,customer,notes in tr:
                            lines.append(f"- #{tid} | {created or '-'} | {kind or '-'} | {currency or '-'} | مبلغ {fmt_num(amount or 0)} | نرخ {fmt_num(rate or 0)} | مشتری {customer or '-'} | توضیح {notes or '-'}")
                    else:
                        lines.append("- هیچ معامله‌ای ثبت نشده است.")

                customer_rows=c.execute("SELECT id,name FROM customers ORDER BY LENGTH(name) DESC").fetchall()
                matched=[]
                for cid,name in customer_rows:
                    nm=_norm_ai_text(name)
                    if nm and len(nm)>=2 and nm in qn:
                        matched.append((cid,name))
                for cid,name in matched[:3]:
                    lines.append(f"اطلاعات مشتری مورد سؤال: {name} (شناسه {cid})")
                    er=c.execute("SELECT created,entry_type,amount,currency,rate,notes,source_type,source_id FROM account_entries WHERE customer_id=? ORDER BY id DESC LIMIT 50",(cid,)).fetchall()
                    if er:
                        for created,etype,amount,currency,rate,notes,source_type,source_id in er:
                            receipt_no = '-'
                            if source_type == 'receipt' and source_id:
                                rr = c.execute("SELECT receipt_no FROM receipts WHERE id=?", (source_id,)).fetchone()
                                if rr and rr[0] is not None:
                                    receipt_no = rr[0]
                            lines.append(f"- دفتر حساب: {created or '-'} | {etype or '-'} | {fmt_num(amount or 0)} {currency or ''} | نرخ {fmt_num(rate or 0)} | رسید {receipt_no} | {notes or ''}")
                    else:
                        lines.append("- برای این مشتری سندی در دفتر حساب پیدا نشد.")

                lines.append("منبع داده: این اطلاعات مستقیماً از پایگاه داده زنده همین نرم‌افزار خوانده شده است؛ بنابراین نگو «به دیتابیس دسترسی ندارم» مگر اینکه همین تابع خطای واقعی پایگاه داده داده باشد.")
                lines.append("دستور مهم: برای سؤال‌های مربوط به مشتریان، معاملات، مانده و وضعیت حساب فقط از داده‌های بالا استفاده کن. اگر داده کافی نیست، دقیقاً بگو کدام داده در پایگاه داده موجود نیست و عدد یا نام ساختگی نساز.")
                return "\n".join(lines)
            except Exception as e:
                return "اطلاعات پایگاه‌داده در دسترس نیست؛ پاسخ را بدون ساختن اطلاعات مالی ارائه کن. خطای داخلی: "+str(e)[:180]
            finally:
                try:
                    if conn is not None: conn.close()
                except Exception:
                    pass

        def _ai_local_database_answer(question):
            """Answer common accounting-data questions directly from the live SQLite DB.
            This deliberately bypasses the LLM for deterministic database lookups so
            the model cannot incorrectly claim it has no database access.
            Returns (handled, answer).
            """
            conn=None
            try:
                # AI requests are executed in a background thread. SQLite connections
                # created by Tkinter's main thread cannot be reused here.
                conn=sqlite3.connect(DB, timeout=10)
                qn=_norm_ai_text(question)
                c=conn.cursor()
                customer_aliases=("مشتری","مشتریا","مشتری ها","مشتریها","مشتری‌ها","مشتریان")
                customer_list_intent=(
                    any(a in qn for a in customer_aliases) and
                    any(w in qn for w in ("لیست","فهرست","اسامی","نام","مشخصات","اطلاعات","شماره","تلفن","آدرس","جزئیات","همه"))
                ) or any(x in qn for x in ("لیست مشتریان","فهرست مشتریان","مشخصات مشتریان","اطلاعات مشتریان","لیست مشتریا","مشخصات مشتریا","اطلاعات مشتریا"))

                if customer_list_intent:
                    rows=c.execute("SELECT id,name,phone,address,balance,notes FROM customers ORDER BY name COLLATE NOCASE").fetchall()
                    if not rows:
                        return True,"در پایگاه داده زنده نرم‌افزار، هیچ مشتری ثبت نشده است."
                    out=[f"فهرست مشتریان — {len(rows)} مشتری ثبت شده است:",""]
                    for i,(cid,name,phone,address,balance,notes) in enumerate(rows,1):
                        out.append(f"{i}. {name or '-'}")
                        out.append(f"   شناسه: {cid} | تلفن: {phone or '-'} | آدرس: {address or '-'}")
                        out.append(f"   مانده ثبت‌شده: {fmt_num(balance or 0)} | یادداشت: {notes or '-'}")
                    out.append("")
                    out.append("این اطلاعات مستقیماً از پایگاه داده زنده همین نرم‌افزار خوانده شد.")
                    return True,"\n".join(out)

                # Daily report requests are handled directly from SQLite so the
                # assistant cannot reduce a financial report to only a customer count.
                # The report includes customers, receipts, customer debt/credit,
                # currency-specific transaction totals, goods activity and profit/loss.
                daily_words=("گزارش روزانه","گزارش امروز","گزارش مالی امروز","گزارش روز","گزارش روزانه امروز")
                if any(x in qn for x in daily_words):
                    today=datetime.now().strftime("%Y-%m-%d")
                    like=today+"%"
                    total_customers=int(c.execute("SELECT COUNT(*) FROM customers").fetchone()[0] or 0)
                    tx_count=int(c.execute("SELECT COUNT(*) FROM transactions WHERE created LIKE ?",(like,)).fetchone()[0] or 0)
                    receipt_count=int(c.execute("SELECT COUNT(*) FROM receipts WHERE created LIKE ?",(like,)).fetchone()[0] or 0)
                    shop_count=int(c.execute("SELECT COUNT(*) FROM business_transactions WHERE created LIKE ?",(like,)).fetchone()[0] or 0)
                    out=[f"گزارش روزانه — {today}","",f"تعداد کل مشتریان ثبت‌شده: {total_customers}",f"تعداد معاملات ارزی امروز: {tx_count}",f"تعداد رسیدهای مشتری امروز: {receipt_count}",f"تعداد معاملات خرید/فروش کالا امروز: {shop_count}",""]

                    receipt_rows=c.execute(
                        "SELECT receipt_type,COALESCE(currency,'AFN - افغانی'),COUNT(*),COALESCE(SUM(amount),0) "
                        "FROM receipts WHERE created LIKE ? GROUP BY receipt_type,currency ORDER BY receipt_type,currency",(like,)
                    ).fetchall()
                    out.append("رسیدهای امروز:")
                    if receipt_rows:
                        for rtype,cur,count,amount in receipt_rows:
                            mapped="بستانکاری مشتری" if rtype=="دریافت از مشتری" else ("قرضداری مشتری" if rtype=="پرداخت به مشتری" else rtype or "-")
                            out.append(f"- {mapped} | رسید: {count} مورد | {cur}: {fmt_num(amount or 0)}")
                    else:
                        out.append("- امروز هیچ رسیدی ثبت نشده است.")

                    entry_rows=c.execute(
                        "SELECT entry_type,COALESCE(currency,'AFN - افغانی'),COUNT(*),COALESCE(SUM(amount),0) "
                        "FROM account_entries WHERE created LIKE ? AND entry_type IN ('قرضداری مشتری','بستانکاری مشتری') "
                        "GROUP BY entry_type,currency ORDER BY entry_type,currency",(like,)
                    ).fetchall()
                    out.extend(["","قرضداری و بستانکاری امروز:"])
                    if entry_rows:
                        for etype,cur,count,amount in entry_rows:
                            out.append(f"- {etype}: {count} مورد | {cur}: {fmt_num(amount or 0)}")
                    else:
                        out.append("- امروز در دفتر حساب مشتریان ثبت قرضداری/بستانکاری وجود ندارد.")

                    tx_rows=c.execute(
                        "SELECT kind,COALESCE(currency,'AFN - افغانی'),COUNT(*),COALESCE(SUM(amount),0) "
                        "FROM transactions WHERE created LIKE ? GROUP BY kind,currency ORDER BY kind,currency",(like,)
                    ).fetchall()
                    out.extend(["","معاملات ارزی امروز:"])
                    if tx_rows:
                        for kind,cur,count,amount in tx_rows:
                            out.append(f"- {kind or '-'} | {cur}: {count} مورد | مجموع {fmt_num(amount or 0)}")
                    else:
                        out.append("- امروز معامله ارزی ثبت نشده است.")

                    shop_rows=c.execute(
                        "SELECT kind,COALESCE(currency,'AFN - افغانی'),COUNT(*),COALESCE(SUM(amount),0) "
                        "FROM business_transactions WHERE created LIKE ? GROUP BY kind,currency ORDER BY kind,currency",(like,)
                    ).fetchall()
                    out.extend(["","خرید و فروش کالا امروز:"])
                    if shop_rows:
                        for kind,cur,count,amount in shop_rows:
                            out.append(f"- {kind or '-'} | {cur}: {count} مورد | مجموع {fmt_num(amount or 0)}")
                    else:
                        out.append("- امروز خرید یا فروش کالا ثبت نشده است.")

                    # Profit/loss from today's shop activity, kept in native currencies.
                    pnl_rows=c.execute(
                        "SELECT COALESCE(currency,'AFN - افغانی'), "
                        "COALESCE(SUM(CASE WHEN kind='فروش' THEN amount ELSE 0 END),0), "
                        "COALESCE(SUM(CASE WHEN kind='خرید' THEN amount ELSE 0 END),0) "
                        "FROM business_transactions WHERE created LIKE ? GROUP BY currency ORDER BY currency",(like,)
                    ).fetchall()
                    out.extend(["","سود/زیان تقریبی فعالیت کالایی امروز (به ارز اصلی):"])
                    if pnl_rows:
                        for cur,sales,purchases in pnl_rows:
                            net=D(sales or 0)-D(purchases or 0)
                            if net>0: out.append(f"- {cur}: سود {fmt_num(net)}")
                            elif net<0: out.append(f"- {cur}: زیان {fmt_num(-net)}")
                            else: out.append(f"- {cur}: سربه‌سر 0")
                    else:
                        out.append("- برای امروز خرید/فروش کالایی برای محاسبه سود/زیان وجود ندارد.")

                    out.extend(["","منبع: این گزارش مستقیماً از پایگاه داده زنده نرم‌افزار و فقط برای امروز ساخته شد."])
                    return True,"\n".join(out)

                tx_intent=any(x in qn for x in ("وضعیت معاملات","وضعیت معامله","معاملات","تراکنش","گزارش معاملات","خرید و فروش","خرید","فروش"))
                if tx_intent:
                    rows=c.execute("SELECT kind,currency,COUNT(*),COALESCE(SUM(amount),0) FROM transactions GROUP BY kind,currency ORDER BY kind,currency").fetchall()
                    total=int(c.execute("SELECT COUNT(*) FROM transactions").fetchone()[0] or 0)
                    recent=c.execute("SELECT created,kind,currency,amount,customer,notes FROM transactions ORDER BY id DESC LIMIT 10").fetchall()
                    out=[f"وضعیت معاملات — مجموع {total} معامله ثبت شده است.",""]
                    if rows:
                        out.append("خلاصه بر اساس نوع و ارز:")
                        for kind,currency,count,amount in rows:
                            out.append(f"- {kind or '-'} | {currency or '-'} | {count} مورد | مجموع {fmt_num(amount or 0)}")
                    else:
                        out.append("هنوز معامله‌ای در پایگاه داده ثبت نشده است.")
                    if recent:
                        out.extend(["","۱۰ معامله آخر:"])
                        for created,kind,currency,amount,customer,notes in recent:
                            out.append(f"- {created or '-'} | {kind or '-'} | {fmt_num(amount or 0)} {currency or ''} | مشتری: {customer or '-'} | {notes or '-'}")
                    return True,"\n".join(out)

                # Specific customer/account lookup.  This is deliberately
                # deterministic: the phrase «حساب <نام مشتری> را نشان بده»
                # must be resolved against SQLite, never left to the LLM.
                account_words=("حساب","دفتر حساب","صورتحساب","صورت حساب","حساب مشتری","مانده حساب","ریز حساب","گردش حساب")
                asks_for_account=any(w in qn for w in account_words)
                customer_rows=c.execute("SELECT id,name,phone,address,balance,notes FROM customers ORDER BY LENGTH(name) DESC").fetchall()
                matches=[]
                for cid,name,phone,address,balance,notes in customer_rows:
                    nm=_norm_ai_text(name)
                    if not nm or len(nm)<2:
                        continue
                    # Exact normalized name anywhere in the request.
                    if nm in qn:
                        matches.append((100+len(nm),cid,name,phone,address,balance,notes))
                        continue
                    # Also support requests where punctuation/extra words split
                    # the customer name. Require every significant name token.
                    tokens=[t for t in nm.split() if len(t)>=2]
                    if tokens and sum(1 for t in tokens if t in qn)==len(tokens):
                        matches.append((80+len(tokens),cid,name,phone,address,balance,notes))

                if matches and (asks_for_account or len(matches)==1):
                    matches.sort(reverse=True, key=lambda x:x[0])
                    _,cid,name,phone,address,balance,notes=matches[0]
                    er=c.execute("SELECT created,entry_type,amount,currency,rate,notes,source_type,source_id FROM account_entries WHERE customer_id=? ORDER BY id DESC LIMIT 50",(cid,)).fetchall()
                    # Include transaction rows too, because some older records
                    # may exist in transactions without an account_entries row.
                    tr=c.execute("SELECT created,kind,amount,currency,rate,notes FROM transactions WHERE customer_id=? OR customer=? ORDER BY id DESC LIMIT 30",(cid,name)).fetchall()

                    # IMPORTANT: customers.balance can be stale/zero in older database
                    # versions. The authoritative customer balance is the live ledger.
                    # Calculate it from account_entries, preserving each native currency
                    # instead of displaying a misleading AFN-equivalent or zero.
                    bal_rows=c.execute("""
                        SELECT COALESCE(currency,'AFN - افغانی'),
                               COALESCE(SUM(CASE WHEN entry_type='قرضداری مشتری' THEN amount ELSE 0 END),0),
                               COALESCE(SUM(CASE WHEN entry_type='بستانکاری مشتری' THEN amount ELSE 0 END),0)
                        FROM account_entries WHERE customer_id=? GROUP BY COALESCE(currency,'AFN - افغانی')
                        ORDER BY currency
                    """,(cid,)).fetchall()
                    out=[f"حساب مشتری = {name or '-'}",f"تلفن = {phone or '-'}",f"آدرس = {address or '-'}"]
                    out.append("مانده حساب:")
                    if bal_rows:
                        for bcur,brec,bpay in bal_rows:
                            bnet=D(brec or 0)-D(bpay or 0)
                            short=bcur.split(' - ')[0] if ' - ' in bcur else bcur
                            status_word='قرضدار' if bnet>0 else ('بستانکار' if bnet<0 else 'تسویه')
                            out.append(f"ارز = {short}")
                            out.append(f"قرضداری = {fmt_num(brec or 0)}")
                            out.append(f"بستانکاری = {fmt_num(bpay or 0)}")
                            out.append(f"مانده = {fmt_num(abs(bnet))} ({status_word})")
                    else:
                        out.append("مانده = 0 (تسویه)")
                    if notes:
                        out.append(f"یادداشت = {notes}")

                    if er:
                        out.extend(["","آخرین اسناد دفتر حساب:"])
                        for idx,(created,etype,amount,currency,rate,enotes,source_type,source_id) in enumerate(er,1):
                            receipt_no = '-'
                            if source_type == 'receipt' and source_id:
                                rr = c.execute("SELECT receipt_no FROM receipts WHERE id=?", (source_id,)).fetchone()
                                if rr and rr[0] is not None:
                                    receipt_no = rr[0]
                            short=currency.split(' - ')[0] if currency and ' - ' in currency else (currency or '-')
                            out.extend([
                                f"سند {idx}",
                                f"تاریخ = {created or '-'}",
                                f"نوع = {etype or '-'}",
                                f"مبلغ = {fmt_num(amount or 0)} {short}",
                                f"نرخ = {fmt_num(rate or 0)}",
                                f"شماره رسید = {receipt_no}",
                                f"توضیح = {enotes or '-'}",
                                ""
                            ])
                    if tr:
                        out.extend(["","آخرین معاملات مرتبط:"])
                        for idx,(created,kind,amount,currency,rate,enotes) in enumerate(tr,1):
                            short=currency.split(' - ')[0] if currency and ' - ' in currency else (currency or '-')
                            out.extend([
                                f"معامله {idx}",
                                f"تاریخ = {created or '-'}",
                                f"نوع = {kind or '-'}",
                                f"مبلغ = {fmt_num(amount or 0)} {short}",
                                f"نرخ = {fmt_num(rate or 0)}",
                                f"توضیح = {enotes or '-'}",
                                ""
                            ])
                    if not er and not tr:
                        out.append("\nبرای این مشتری هنوز سند یا معامله‌ای در پایگاه داده پیدا نشد.")
                    out.append("\nاین اطلاعات مستقیماً از پایگاه داده زنده نرم‌افزار خوانده شد.")
                    return True,"\n".join(out)

                # If the user explicitly asks for an account but the name did
                # not match, return a useful database result instead of letting
                # the model claim it has no database access.
                if asks_for_account:
                    names=[str(r[1]) for r in customer_rows if r[1]]
                    if names:
                        return True,"نام مشتری در درخواست با نام‌های ثبت‌شده تطبیق نشد. مشتریان ثبت‌شده عبارت‌اند از: " + "، ".join(names[:100])
                    return True,"در پایگاه داده زنده هیچ مشتری ثبت‌شده‌ای پیدا نشد."
                return False,""
            except Exception as e:
                return True,"خواندن پایگاه داده برای این درخواست با خطای داخلی مواجه شد: "+str(e)[:300]
            finally:
                try:
                    if conn is not None: conn.close()
                except Exception:
                    pass

        def call_ai_api(question, done_callback):
            local_handled,local_answer=_ai_local_database_answer(question)
            if local_handled:
                self.after(0,lambda text=local_answer:done_callback(text))
                return
            key=_norm_ai_key(runtime_ai_key.get("key") or get_ai_setting("ai_api_key",os.environ.get("OPENAI_API_KEY","")))
            model=runtime_ai_key.get("model") or get_ai_setting("ai_model","gpt-5.6-luna") or "gpt-5.6-luna"
            if not key:
                self.after(0,lambda:done_callback("برای پاسخ واقعی شبیه ChatGPT، ابتدا روی «⚙ تنظیم هوش مصنوعی» بزنید، کلید OpenAI API را وارد کنید و روی «🔌 تست اتصال» بزنید. من عمداً بدون کلید به سایت‌ها جستجو نمی‌کنم.")); return
            system=("تو دستیار هوشمند نرم‌افزار حسابداری جهان هستی. با کاربر فارسی و کاملاً طبیعی، دوستانه و دقیق صحبت کن. "
                    "مثل یک دستیار مکالمه‌ای واقعی پاسخ بده، نه مثل موتور جستجو. خودت پاسخ را تولید کن و برای پاسخ دادن به سؤال‌های عمومی به سایت‌ها سر نزن. "
                    "اگر اطلاعات را نمی‌دانی، صادقانه بگو و حدس قطعی نزن. پاسخ‌ها را واضح و کاربردی بده و اگر سؤال محاسباتی است محاسبه را انجام بده. "
                    "اگر درباره خود نرم‌افزار سؤال شد، بر اساس اطلاعاتی که در متن گفتگو و زمینه برنامه داده شده راهنمایی کن. "
                    "هرگز ادعا نکن که وب را جستجو کرده‌ای یا صفحه‌ای را دیده‌ای، مگر اینکه کاربر صریحاً درخواست باز کردن سایت کرده باشد؛ باز کردن سایت توسط برنامه جدا از پاسخ هوش مصنوعی است.\n\n"+_accounting_context(question))
            messages=[]
            for role,text in history[-8:]:
                # Use plain string message content. This is the most portable
                # Responses API input form and avoids the nested content-type
                # validation error seen on this installation.
                messages.append({"role":role,"content":text})
            messages.append({"role":"user","content":question})
            ok,result=self._ai_raw_request(key,model,messages,system,max_tokens=1200,timeout=25)
            if ok:
                self.after(0,lambda text=result:done_callback(text))
            else:
                self.after(0,lambda msg=result:done_callback("ارتباط با هوش مصنوعی برقرار نشد.\n\n"+msg))

        def answer(text=None):
            text=(text if text is not None else q.get()).strip()
            if not text: return
            site_reply=open_requested_site(text)
            if site_reply:
                _insert_ai_result(result, site_reply); return
            normalized=str(text).translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
            if re.fullmatch(r"[0-9.()+\-*/% ]+", normalized):
                try:
                    reply=f"نتیجه محاسبه: {fmt_num(self._safe_calculate(normalized.replace('%','/100')))}"
                    _insert_ai_result(result, reply); return
                except Exception: pass
            key=_norm_ai_key(runtime_ai_key.get("key") or get_ai_setting("ai_api_key",os.environ.get("OPENAI_API_KEY","")))
            if not key:
                reply="کلید API در این صفحه قابل دسترسی نیست. لطفاً «⚙ تنظیم هوش مصنوعی» را باز کنید، کلید را وارد کنید و «🔌 تست اتصال» را بزنید؛ اگر تست موفق شد، همین صفحه بدون نیاز به بازکردن دوباره تنظیمات آماده پاسخ‌گویی است."
                _insert_ai_result(result, reply); return
            status.config(text="● در حال فکر کردن…",fg="#B45309")
            self.button_state_busy=True
            def done(reply):
                self.button_state_busy=False
                history.append(("user",text)); history.append(("assistant",reply))
                _insert_ai_result(result, reply)
                status.config(text="● آماده",fg="#0F766E")
            threading.Thread(target=call_ai_api,args=(text,done),daemon=True).start()

        for label,text in [("🧭 راهنمای برنامه","چطور با برنامه حسابداری کار کنم؟"),("💡 مفهوم حسابداری","فرق دارایی، بدهی و سرمایه چیست؟"),("📊 وضعیت معاملات","وضعیت معاملات من را توضیح بده"),("➗ محاسبه 13000×2","13000*2")]:
            self.button(quick,label,lambda x=text:(q.set(x),answer(x))).pack(side="right",padx=3,pady=5)
        self.button(box,"🤖 پاسخ هوشمند",answer).pack(anchor="center",pady=(2,12))
        ent.bind("<Return>",answer)
        self._ai_input_widget=ent

        monitor=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        monitor.pack(fill="x",padx=20,pady=8)
        head=tk.Frame(monitor,bg="#FFFFFF"); head.pack(fill="x")
        RTLLabel(head,text="📊 پایش قرض مشتریان",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold")).pack(side="right",padx=16,pady=9)
        debt_status=RTLLabel(head,text="بروزرسانی خودکار هر ۱۰ ثانیه",bg="#FFFFFF",fg="#687582",font=ui_font(8)); debt_status.pack(side="left",padx=16)
        debt_holder=tk.Frame(monitor,bg="#FFFFFF"); debt_holder.pack(fill="x",padx=16,pady=(0,10))
        debt_text=tk.Text(debt_holder,height=5,bg="#F8FAFC",fg="#1B2733",relief="flat",font=ui_font(10),wrap="word")
        debt_scroll=tk.Scrollbar(debt_holder,orient="vertical",command=debt_text.yview,width=12); debt_text.configure(yscrollcommand=debt_scroll.set)
        debt_scroll.pack(side="right",fill="y"); debt_text.pack(side="left",fill="both",expand=True)
        def debt_box_exists(w):
            try:return bool(w.winfo_exists())
            except Exception:return False
        def refresh_ai_debts():
            if not debt_box_exists(monitor): return
            rows=[]
            for cid,name in self.db.execute("SELECT id,name FROM customers ORDER BY name").fetchall():
                rec,pay,net=self.customer_balances(cid)
                if net>0: rows.append((net,name))
            rows.sort(reverse=True); debt_text.config(state="normal"); debt_text.delete("1.0","end")
            if rows:
                total=sum(x[0] for x in rows); lines=[f"تعداد مشتریان قرضدار: {len(rows)}"]+[f"{i}. {name}: {fmt_num(amount)}" for i,(amount,name) in enumerate(rows[:8],1)]
                debt_text.insert("1.0", "\n".join(_ai_display_line(x) for x in lines)); debt_status.config(text="● پایش فعال")
            else:
                debt_text.insert("1.0", _ai_display_line("در حال حاضر مشتری قرضدار ثبت نشده است.")); debt_status.config(text="● بدون قرض")
            debt_text.config(state="disabled")
            try:self.after(10000,refresh_ai_debts)
            except Exception:pass
        refresh_ai_debts()

    def _ai_focus_input(self):
        try:
            self._ai_input_widget.focus_set()
            self._ai_input_widget.select_range(0,"end")
        except Exception:
            pass

    def _ai_rate_rows(self):
        rows=[]
        for currency in CURRENCIES:
            data=self.db.execute("SELECT rate,kind FROM transactions WHERE currency=? AND rate>0 ORDER BY id DESC LIMIT 12",(currency,)).fetchall()
            if not data:
                rows.append((currency,"داده کافی نیست — ابتدا چند معامله با نرخ ثبت کنید.")); continue
            rates=[float(x[0]) for x in data]
            latest=rates[0]; avg=sum(rates)/len(rates)
            if len(rates)>=3:
                if latest < avg*0.995: advice=f"نرخ اخیر {fmt_num(latest)}؛ پایین‌تر از میانگین {fmt_num(avg)} → برای بررسی خرید مناسب‌تر است."
                elif latest > avg*1.005: advice=f"نرخ اخیر {fmt_num(latest)}؛ بالاتر از میانگین {fmt_num(avg)} → برای بررسی فروش مناسب‌تر است."
                else: advice=f"نرخ اخیر {fmt_num(latest)}؛ نزدیک میانگین {fmt_num(avg)} → فعلاً صبر و مقایسه نرخ پیشنهاد می‌شود."
            else:
                advice=f"آخرین نرخ ثبت‌شده {fmt_num(latest)}؛ برای پیشنهاد دقیق‌تر معاملات بیشتری ثبت کنید."
            rows.append((currency,advice))
        return rows

    def _ai_currency_advice(self, action):
        rows=self._ai_rate_rows()
        if action=="خرید":
            candidates=[(c,a) for c,a in rows if "خرید" in a]
            if candidates: return "پیشنهاد خرید بر اساس داده‌های ثبت‌شده:\n"+"\n".join(f"• {c}: {a}" for c,a in candidates)
            return "در داده‌های فعلی نرخ مشخصی که پایین‌تر از میانگین باشد پیدا نشد. قبل از خرید، نرخ امروز را با چند ثبت اخیر مقایسه کنید."
        candidates=[(c,a) for c,a in rows if "فروش" in a]
        if candidates: return "پیشنهاد فروش بر اساس داده‌های ثبت‌شده:\n"+"\n".join(f"• {c}: {a}" for c,a in candidates)
        return "در داده‌های فعلی نرخ مشخصی که بالاتر از میانگین باشد پیدا نشد. قبل از فروش، نرخ امروز را با چند ثبت اخیر مقایسه کنید."

    def transaction_page(self):
        self.clear()
        RTLLabel(self.main,text="ثبت معامله ارزی",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        form=tk.Frame(self.main,bg="#FFFFFF"); form.pack(fill="x",padx=20,pady=10)
        vars={k:tk.StringVar() for k in ["kind","currency","amount","rate","customer","notes"]}
        vars["kind"].set("خرید"); vars["currency"].set(CURRENCIES[0])
        labels=[("نوع معامله","kind"),("نوع ارز","currency"),("مبلغ ارز","amount"),
                ("نرخ","rate"),("مشتری","customer"),("توضیحات","notes")]
        for i,(lab,key) in enumerate(labels):
            r=1+i//2; c=i%2
            cell=tk.Frame(form,bg="#FFFFFF"); cell.grid(row=r,column=c,padx=15,pady=10,sticky="ew")
            form.columnconfigure(c,weight=1)
            RTLLabel(cell,text=lab,bg="#FFFFFF",fg="#C7CFD7",font=ui_font(10)).pack(anchor="e")
            if key=="kind": w=LocalizedCombobox(cell,textvariable=vars[key],values=["خرید","فروش"],state="readonly")
            elif key=="currency": w=LocalizedCombobox(cell,textvariable=vars[key],values=CURRENCIES,state="readonly")
            elif key=="customer":
                w=LocalizedCombobox(cell,textvariable=vars[key],values=[n for _,n in self.get_customer_list()])
            else:
                w=tk.Entry(cell,textvariable=vars[key],bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3")
            w.pack(fill="x",ipady=7)
        # مبلغ فقط با همان ارز انتخاب‌شده نمایش داده می‌شود؛ هیچ معادل AFN در فرم نشان داده نمی‌شود.
        def save():
            try: amount=float(D(vars["amount"].get())); rate=float(D(vars["rate"].get()))
            except: messagebox.showerror("خطا","مبلغ و نرخ باید عددی باشند."); return
            if amount<=0 or rate<=0: messagebox.showerror("خطا","مبلغ و نرخ باید بیشتر از صفر باشند."); return
            afn=amount*rate
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            cname=vars["customer"].get().strip()
            cidrow=self.db.execute("SELECT id FROM customers WHERE name=? LIMIT 1",(cname,)).fetchone() if cname else None
            cur_ins=self.db.execute("""INSERT INTO transactions(created,kind,currency,amount,rate,afn_amount,customer,notes,customer_id,source_type)
                               VALUES(?,?,?,?,?,?,?,?,?,?)""",
                            (now,vars["kind"].get(),vars["currency"].get(),amount,rate,afn,cname,vars["notes"].get(),cidrow[0] if cidrow else None,'transaction'))
            txid=cur_ins.lastrowid
            if cidrow:
                etype='قرضداری مشتری' if vars["kind"].get()=="فروش" else 'بستانکاری مشتری'
                self.db.execute("""INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,source_type,source_id)
                                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                                (now,cidrow[0],cname,etype,amount,f"معامله #{txid} - {vars['notes'].get().strip()}",vars["currency"].get(),rate,afn,'transaction',txid))
            self.db.commit()
            messagebox.showinfo("موفق","معامله با موفقیت ثبت شد.")
            self.receipt_page()
        self.button(form,"✓ ثبت معامله",save).grid(row=4,column=0,columnspan=2,pady=18)


    # ========================= بخش بارها / حمل‌ونقل =========================
    def _shipment_rate(self, currency):
        """Historical rate for a shipment form. Never changes an existing shipment."""
        if not currency or currency == "AFN - افغانی":
            return 1.0
        try:
            r=float(self.get_rate_to_afn(currency) or 0)
            return r if r > 0 else 0.0
        except Exception:
            return 0.0

    def _shipment_amount_afn(self, amount, currency, rate=None):
        try:
            amount=float(D(amount or 0))
        except Exception:
            amount=0.0
        if amount == 0:
            return 0.0
        try:
            rv=float(rate) if rate is not None else self._shipment_rate(currency)
        except Exception:
            rv=0.0
        return amount * rv

    def _shipment_cost_rows(self, row):
        """Return the seven stored monetary components with their historical AFN values."""
        names = [
            ("کارگر", "worker", "worker_currency", "worker_afn"),
            ("گمرک مبدا", "customs_origin", "customs_origin_currency", "customs_origin_afn"),
            ("گمرک مقصد", "customs_destination", "customs_destination_currency", "customs_destination_afn"),
            ("کرایه مبدا", "freight_origin", "freight_origin_currency", "freight_origin_afn"),
            ("کرایه مقصد", "freight_destination", "freight_destination_currency", "freight_destination_afn"),
            ("سایر هزینه", "other_cost", "other_cost_currency", "other_cost_afn"),
        ]
        d=dict(zip([x[1] for x in self.db.execute("PRAGMA table_info(shipments)").fetchall()], row))
        out=[]
        for title,amount_col,cur_col,afn_col in names:
            out.append((title,float(d.get(amount_col) or 0),d.get(cur_col) or "AFN - افغانی",float(d.get(afn_col) or 0)))
        return out

    def _shipment_currency_summary(self, row):
        """Raw income/cost totals by currency for display; profit itself is AFN."""
        cols=[x[1] for x in self.db.execute("PRAGMA table_info(shipments)").fetchall()]
        d=dict(zip(cols,row))
        result={}
        def add(cur, income=0, cost=0):
            cur=cur or "AFN - افغانی"
            if cur not in result: result[cur]=[0.0,0.0]
            result[cur][0]+=float(income or 0)
            result[cur][1]+=float(cost or 0)
        add(d.get("income_currency"), income=d.get("income"))
        for title,amount_col,cur_col,afn_col in [
            ("کارگر","worker","worker_currency","worker_afn"),
            ("گمرک مبدا","customs_origin","customs_origin_currency","customs_origin_afn"),
            ("گمرک مقصد","customs_destination","customs_destination_currency","customs_destination_afn"),
            ("کرایه مبدا","freight_origin","freight_origin_currency","freight_origin_afn"),
            ("کرایه مقصد","freight_destination","freight_destination_currency","freight_destination_afn"),
            ("سایر هزینه","other_cost","other_cost_currency","other_cost_afn")]:
            add(d.get(cur_col), cost=d.get(amount_col))
        return result

    def _shipment_rate_field(self, parent, row, label, currency_var, amount_var, rate_var, r, c, readonly_currency=False):
        cell=tk.Frame(parent,bg="#FFFFFF")
        cell.grid(row=r,column=c,padx=7,pady=5,sticky="ew")
        RTLLabel(cell,text=label,bg="#FFFFFF",fg="#374151",font=ui_font(9,"bold")).pack(anchor="e")
        line=tk.Frame(cell,bg="#FFFFFF"); line.pack(fill="x")
        amount=tk.Entry(line,textvariable=amount_var,bg="#F8FAFC",fg="#1B2733",relief="solid",bd=1,justify="right")
        amount.pack(side="right",fill="x",expand=True,ipady=5)
        cur=LocalizedCombobox(line,textvariable=currency_var,values=CURRENCIES,state="readonly" if readonly_currency else "normal",width=16,justify="right")
        cur.pack(side="left",padx=(5,0),ipady=3)
        rate_line=tk.Frame(cell,bg="#FFFFFF"); rate_line.pack(fill="x",pady=(3,0))
        RTLLabel(rate_line,text="نرخ تبدیل به افغانی برای هر ۱ واحد:",bg="#FFFFFF",fg="#7C8794",font=ui_font(8),justify="right").pack(side="right")
        re_=tk.Entry(rate_line,textvariable=rate_var,width=12,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,justify="right")
        re_.pack(side="left")
        def sync_rate(event=None):
            try:
                if currency_var.get()=="AFN - افغانی":
                    rate_var.set("1")
                else:
                    rv=self._shipment_rate(currency_var.get())
                    if rv>0: rate_var.set(str(rv))
            except Exception: pass
        cur.bind("<<ComboboxSelected>>",sync_rate)
        return amount,cur,re_

    def _shipment_dialog(self, shipment_id=None):
        win=tk.Toplevel(self)
        win.title("ثبت بار" if shipment_id is None else "ویرایش بار")
        win.geometry("940x700")
        win.minsize(850,620)
        win.configure(bg="#F4F6F8")
        win.transient(self)
        try: win.grab_set()
        except Exception: pass

        old=None
        if shipment_id:
            old=self.db.execute("SELECT * FROM shipments WHERE id=?",(shipment_id,)).fetchone()
            if not old:
                win.destroy(); return
        cols=[x[1] for x in self.db.execute("PRAGMA table_info(shipments)").fetchall()]
        od=dict(zip(cols,old)) if old else {}
        def sv(k,default=""): return tk.StringVar(value=str(od.get(k,default) if od.get(k,default) is not None else default))

        RTLLabel(win,text="🚚 مشخصات بار",bg="#F4F6F8",fg="#1B2733",font=ui_font(18,"bold")).pack(anchor="e",padx=20,pady=(14,4))
        RTLLabel(win,text="۱) مسیر بار را وارد کنید  •  ۲) درآمد و هزینه‌ها را وارد کنید  •  ۳) ثبت بار",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))

        top=tk.Frame(win,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); top.pack(fill="x",padx=20,pady=5)
        RTLLabel(top,text="📍 مسیر و مشخصات بار",bg="#FFFFFF",fg="#B58E45",font=ui_font(12,"bold")).grid(row=0,column=0,columnspan=2,padx=10,pady=(8,2),sticky="e")
        vars_={k:sv(k) for k in ["origin_country","origin_province","destination_country","destination_province","cargo_type","sender","receiver","notes"]}
        vars_["origin_country"].set(vars_["origin_country"].get() or "افغانستان")
        vars_["destination_country"].set(vars_["destination_country"].get() or "ایران")
        labels=[("کشور مبدا","origin_country"),("ولایت/شهر مبدا","origin_province"),
                ("کشور مقصد","destination_country"),("ولایت/شهر مقصد","destination_province"),
                ("نوع بار","cargo_type"),("فرستنده","sender"),("گیرنده","receiver")]
        for i,(lab,key) in enumerate(labels):
            r=i//2; c=i%2
            cell=tk.Frame(top,bg="#FFFFFF"); cell.grid(row=r,column=c,padx=10,pady=5,sticky="ew"); top.columnconfigure(c,weight=1)
            RTLLabel(cell,text=lab,bg="#FFFFFF",fg="#374151",font=ui_font(9,"bold")).pack(anchor="e")
            if key in ("origin_country","destination_country"):
                w=LocalizedCombobox(cell,textvariable=vars_[key],values=["افغانستان","ایران","پاکستان","سایر"],state="readonly")
            else:
                w=tk.Entry(cell,textvariable=vars_[key],bg="#F8FAFC",fg="#1B2733",relief="solid",bd=1,justify="right")
            w.pack(fill="x",ipady=5)
        RTLLabel(top,text="توضیحات",bg="#FFFFFF",fg="#374151",font=ui_font(9,"bold")).grid(row=4,column=1,padx=10,pady=(5,2),sticky="e")
        note=tk.Entry(top,textvariable=vars_["notes"],bg="#F8FAFC",fg="#1B2733",relief="solid",bd=1,justify="right")
        note.grid(row=4,column=0,padx=10,pady=(5,8),sticky="ew",columnspan=1)

        money=tk.Frame(win,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); money.pack(fill="both",expand=True,padx=20,pady=7)
        RTLLabel(money,text="💰 بخش مالی بار",bg="#FFFFFF",fg="#B58E45",font=ui_font(13,"bold")).pack(anchor="e",padx=12,pady=(9,3))
        RTLLabel(money,text="مبلغ‌ها را وارد کنید؛ ارز و نرخ تبدیل هر مورد کنار همان مبلغ قرار دارد.",bg="#FFFFFF",fg="#7C8794",font=ui_font(8)).pack(anchor="e",padx=12,pady=(0,6))
        form=tk.Frame(money,bg="#FFFFFF"); form.pack(fill="both",expand=True,padx=10)
        for j in range(2): form.columnconfigure(j,weight=1)

        income=sv("income","0"); income_cur=sv("income_currency","AFN - افغانی"); income_rate=sv("income_rate","1")
        worker=sv("worker","0"); worker_cur=sv("worker_currency","AFN - افغانی"); worker_rate=sv("worker_rate","1")
        co=sv("customs_origin","0"); co_cur=sv("customs_origin_currency","AFN - افغانی"); co_rate=sv("customs_origin_rate","1")
        cd=sv("customs_destination","0"); cd_cur=sv("customs_destination_currency","AFN - افغانی"); cd_rate=sv("customs_destination_rate","1")
        fo=sv("freight_origin","0"); fo_cur=sv("freight_origin_currency","AFN - افغانی"); fo_rate=sv("freight_origin_rate","1")
        fd=sv("freight_destination","0"); fd_cur=sv("freight_destination_currency","AFN - افغانی"); fd_rate=sv("freight_destination_rate","1")
        oc=sv("other_cost","0"); oc_cur=sv("other_cost_currency","AFN - افغانی"); oc_rate=sv("other_cost_rate","1")
        fields=[
            ("💵 درآمد بار",income,income_cur,income_rate),
            ("👷 پول کارگر",worker,worker_cur,worker_rate),
            ("🏛 گمرک مبدا",co,co_cur,co_rate),
            ("🏛 گمرک مقصد",cd,cd_cur,cd_rate),
            ("🚛 کرایه مبدا",fo,fo_cur,fo_rate),
            ("🚛 کرایه مقصد",fd,fd_cur,fd_rate),
            ("➕ سایر هزینه",oc,oc_cur,oc_rate)]
        for i,(lab,av,cv,rv) in enumerate(fields):
            self._shipment_rate_field(form, None, lab, cv,av,rv,i//2,i%2)

        summary=tk.Frame(win,bg="#EAF6F6"); summary.pack(fill="x",padx=20,pady=5)
        summary_var=tk.StringVar()
        RTLLabel(summary,textvariable=summary_var,bg="#EAF6F6",fg="#0F766E",font=ui_font(10,"bold"),justify="right").pack(fill="x",padx=10,pady=8)
        def calc(*args):
            vals=[]
            for av,cv,rv in [(income,income_cur,income_rate),(worker,worker_cur,worker_rate),(co,co_cur,co_rate),(cd,cd_cur,cd_rate),(fo,fo_cur,fo_rate),(fd,fd_cur,fd_rate),(oc,oc_cur,oc_rate)]:
                try: a=float(D(av.get() or 0)); r=float(D(rv.get() or 0))
                except: a=0;r=0
                vals.append(a*r)
            inc=vals[0]; cost=sum(vals[1:]); profit=inc-cost
            summary_var.set(f"درآمد معادل افغانی: {fmt_num(inc)}   |   کل هزینه: {fmt_num(cost)}   |   {'فایده' if profit>=0 else 'ضرر'}: {fmt_num(abs(profit))} افغانی")
        for v in [income,income_cur,income_rate,worker,worker_cur,worker_rate,co,co_cur,co_rate,cd,cd_cur,cd_rate,fo,fo_cur,fo_rate,fd,fd_cur,fd_rate,oc,oc_cur,oc_rate]:
            try:v.trace_add("write",calc)
            except Exception:pass
        calc()

        def save():
            try:
                numeric=[]
                for av,cv,rv in [(income,income_cur,income_rate),(worker,worker_cur,worker_rate),(co,co_cur,co_rate),(cd,cd_cur,cd_rate),(fo,fo_cur,fo_rate),(fd,fd_cur,fd_rate),(oc,oc_cur,oc_rate)]:
                    a=float(D(av.get() or 0)); r=float(D(rv.get() or 0))
                    if a<0 or r<=0: raise ValueError
                    numeric.append((a,cv.get(),r,a*r))
            except Exception:
                messagebox.showerror("خطا","همه مبالغ و نرخ‌های تبدیل باید عددی و نرخ‌ها بیشتر از صفر باشند.",parent=win); return
            if numeric[0][0] <= 0:
                messagebox.showerror("خطا","مبلغ درآمد بار باید بیشتر از صفر باشد.",parent=win); return
            inc,icur,irate,iafn=numeric[0]
            vals=[inc,icur,irate,iafn]
            for a,cur,rate,afn in numeric[1:]:
                vals += [a,cur,rate,afn]
            total=sum(x[3] for x in numeric[1:])
            profit=iafn-total
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            if shipment_id:
                sets="""created=?,origin_country=?,origin_province=?,destination_country=?,destination_province=?,
                        cargo_type=?,sender=?,receiver=?,income=?,income_currency=?,income_rate=?,income_afn=?,
                        worker=?,worker_currency=?,worker_rate=?,worker_afn=?,
                        customs_origin=?,customs_origin_currency=?,customs_origin_rate=?,customs_origin_afn=?,
                        customs_destination=?,customs_destination_currency=?,customs_destination_rate=?,customs_destination_afn=?,
                        freight_origin=?,freight_origin_currency=?,freight_origin_rate=?,freight_origin_afn=?,
                        freight_destination=?,freight_destination_currency=?,freight_destination_rate=?,freight_destination_afn=?,
                        other_cost=?,other_cost_currency=?,other_cost_rate=?,other_cost_afn=?,
                        total_cost_afn=?,profit_afn=?,notes=? WHERE id=?"""
                params=[now,vars_["origin_country"].get(),vars_["origin_province"].get(),vars_["destination_country"].get(),vars_["destination_province"].get(),
                        vars_["cargo_type"].get(),vars_["sender"].get(),vars_["receiver"].get()]+vals+[total,profit,vars_["notes"].get(),shipment_id]
                self.db.execute("UPDATE shipments SET "+sets,params)
            else:
                no=(self.db.execute("SELECT COALESCE(MAX(shipment_no),0)+1 FROM shipments").fetchone()[0] or 1)
                sql="""INSERT INTO shipments(
                    shipment_no,created,origin_country,origin_province,destination_country,destination_province,cargo_type,sender,receiver,
                    income,income_currency,income_rate,income_afn,
                    worker,worker_currency,worker_rate,worker_afn,
                    customs_origin,customs_origin_currency,customs_origin_rate,customs_origin_afn,
                    customs_destination,customs_destination_currency,customs_destination_rate,customs_destination_afn,
                    freight_origin,freight_origin_currency,freight_origin_rate,freight_origin_afn,
                    freight_destination,freight_destination_currency,freight_destination_rate,freight_destination_afn,
                    other_cost,other_cost_currency,other_cost_rate,other_cost_afn,total_cost_afn,profit_afn,notes)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
                params=[no,now,vars_["origin_country"].get(),vars_["origin_province"].get(),vars_["destination_country"].get(),vars_["destination_province"].get(),
                        vars_["cargo_type"].get(),vars_["sender"].get(),vars_["receiver"].get()]+vals+[total,profit,vars_["notes"].get()]
                self.db.execute(sql,params)
            self.db.commit()
            win.destroy()
            self.bars_page()
        self.button(win,"✓ ثبت بار",save).pack(side="bottom",pady=10)

    def bars_page(self):
        self.clear()
        head=tk.Frame(self.main,bg="#F4F6F8"); head.pack(fill="x",padx=20,pady=(12,6))
        RTLLabel(head,text="🚚 بارها و حمل‌ونقل",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(side="right")
        self.button(head,"＋ ثبت بار جدید",lambda:self._shipment_dialog()).pack(side="left")
        RTLLabel(self.main,text="ثبت بار در ۳ بخش ساده: مسیر بار، درآمد و هزینه‌ها. گمرک و کرایه مبدا/مقصد جداگانه ثبت می‌شوند.",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))
        filt=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); filt.pack(fill="x",padx=20,pady=5)
        q=tk.StringVar(); qentry=tk.Entry(filt,textvariable=q,bg="#F8FAFC",fg="#1B2733",relief="solid",bd=1,justify="right")
        qentry.pack(side="right",padx=10,pady=8,fill="x",expand=True,ipady=4)
        RTLLabel(filt,text="جستجو شماره/مبدا/مقصد:",bg="#FFFFFF",fg="#374151").pack(side="right",padx=(10,2))
        box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); box.pack(fill="both",expand=True,padx=20,pady=8)
        cols=("no","date","route","cargo","income","cost","profit")
        tree=ttk.Treeview(box,columns=cols,show="headings",style="Jahan.Treeview")
        heads={"no":"شماره بار","date":"تاریخ","route":"مسیر","cargo":"نوع بار","income":"درآمد معادل AFN","cost":"هزینه معادل AFN","profit":"فایده/ضرر AFN"}
        for c,h in heads.items():
            tree.heading(c,text=_icu_shape_arabic(h)); tree.column(c,width=110,anchor="e")
        tree.column("route",width=250,anchor="e"); tree.column("cargo",width=130,anchor="e")
        self._pack_with_scrollbar(tree,fill="both",expand=True,padx=8,pady=8)
        def load():
            for x in tree.get_children(): tree.delete(x)
            term=q.get().strip()
            rows=self.db.execute("""SELECT id,shipment_no,created,origin_country,origin_province,destination_country,destination_province,cargo_type,
                                           income_afn,total_cost_afn,profit_afn
                                    FROM shipments
                                    WHERE CAST(shipment_no AS TEXT) LIKE ? OR origin_country LIKE ? OR origin_province LIKE ?
                                      OR destination_country LIKE ? OR destination_province LIKE ? OR cargo_type LIKE ?
                                    ORDER BY id DESC""",
                                 tuple([f"%{term}%"]*6)).fetchall()
            for r in rows:
                route=f"{r[3]} - {r[4] or '-'} ← {r[5]} - {r[6] or '-'}"
                label=("فایده " if r[10]>=0 else "ضرر ")+fmt_num(abs(r[10]))
                tree.insert("", "end",iid=str(r[0]),values=(r[1],dual_datetime(r[2]),route,r[7] or "-",fmt_num(r[8]),fmt_num(r[9]),label))
        load()
        q.trace_add("write",lambda *a:load())
        act=tk.Frame(self.main,bg="#F4F6F8"); act.pack(fill="x",padx=20,pady=5)
        def selected_id():
            s=tree.selection()
            return int(s[0]) if s else None
        self.button(act,"✎ ویرایش",lambda:(self._shipment_dialog(selected_id()) if selected_id() else messagebox.showwarning("انتخاب","ابتدا یک بار را انتخاب کنید.")),"#64748B").pack(side="right",padx=3)
        def delete():
            sid=selected_id()
            if not sid: messagebox.showwarning("انتخاب","ابتدا یک بار را انتخاب کنید."); return
            if not messagebox.askyesno("حذف بار","این بار حذف شود؟\nتمام اطلاعات درآمد و هزینه‌های آن نیز حذف می‌شود."): return
            self.db.execute("DELETE FROM shipments WHERE id=?",(sid,)); self.db.commit(); load()
        self.button(act,"🗑 حذف",delete,"#B91C1C").pack(side="right",padx=3)
        self.button(act,"📄 گزارش بار انتخاب‌شده",lambda:self.shipment_detail_report(selected_id()) if selected_id() else messagebox.showwarning("انتخاب","ابتدا یک بار را انتخاب کنید."),"#0F766E").pack(side="right",padx=3)
        self.button(act,"📱 واتساپ بار",lambda:self.send_shipment_whatsapp(selected_id()) if selected_id() else messagebox.showwarning("انتخاب","ابتدا یک بار را انتخاب کنید."),"#128c7e").pack(side="right",padx=3)
        self.button(act,"📊 گزارش سود و ضرر بارها",self.shipment_report_page,"#7C3AED").pack(side="left",padx=3)

    def _shipment_share_text(self, d):
        lines=self._outgoing_profile_text_lines()+["—", "*گزارش کامل بار و حمل‌ونقل*",
            f"شماره بار: {d['shipment_no']}", f"تاریخ: {dual_datetime(d['created'])}",
            f"مسیر: {d['origin_country']} - {d['origin_province'] or '-'} ← {d['destination_country']} - {d['destination_province'] or '-'}",
            f"نوع بار: {d['cargo_type'] or '-'}", f"فرستنده: {d['sender'] or '-'}", f"گیرنده: {d['receiver'] or '-'}", "",
            "*درآمد بار*", f"مبلغ: {fmt_num(d['income'])} {d['income_currency']}", f"نرخ تبدیل ثبت‌شده: {fmt_num(d.get('income_rate',1))}", f"معادل افغانی: {fmt_num(d['income_afn'])}", "",
            "*هزینه‌ها*"]
        for title,a,cur,afn in self._shipment_cost_rows_from_dict(d):
            lines.append(f"• {title}: {fmt_num(a)} {cur} | نرخ {fmt_num(d.get(title+'_rate',1))} | معادل افغانی {fmt_num(afn)}")
        lines += ["", f"کل هزینه معادل افغانی: {fmt_num(d['total_cost_afn'])}",
                  f"{'فایده' if d['profit_afn']>=0 else 'ضرر'} خالص: {fmt_num(abs(d['profit_afn']))} افغانی"]
        if d.get('notes'): lines += ["", f"توضیحات: {d['notes']}"]
        return "\n".join(lines)

    def _shipment_cost_rows_from_dict(self, d):
        return [("کارگر",float(d.get("worker") or 0),d.get("worker_currency") or "AFN - افغانی",float(d.get("worker_afn") or 0)),
                ("گمرک مبدا",float(d.get("customs_origin") or 0),d.get("customs_origin_currency") or "AFN - افغانی",float(d.get("customs_origin_afn") or 0)),
                ("گمرک مقصد",float(d.get("customs_destination") or 0),d.get("customs_destination_currency") or "AFN - افغانی",float(d.get("customs_destination_afn") or 0)),
                ("کرایه مبدا",float(d.get("freight_origin") or 0),d.get("freight_origin_currency") or "AFN - افغانی",float(d.get("freight_origin_afn") or 0)),
                ("کرایه مقصد",float(d.get("freight_destination") or 0),d.get("freight_destination_currency") or "AFN - افغانی",float(d.get("freight_destination_afn") or 0)),
                ("سایر هزینه",float(d.get("other_cost") or 0),d.get("other_cost_currency") or "AFN - افغانی",float(d.get("other_cost_afn") or 0))]

    def _shipment_pdf(self, d, target_path=None):
        rows=[]
        for title,a,cur,afn in self._shipment_cost_rows_from_dict(d):
            rows.append([title, fmt_num(a), cur, fmt_num(afn)])
        fields=[("شماره بار",d['shipment_no']),("تاریخ",dual_datetime(d['created'])),
                ("مسیر",f"{d['origin_country']} - {d['origin_province'] or '-'} ← {d['destination_country']} - {d['destination_province'] or '-'}"),
                ("نوع بار",d['cargo_type'] or '-'),("فرستنده",d['sender'] or '-'),("گیرنده",d['receiver'] or '-'),
                ("درآمد",f"{fmt_num(d['income'])} {d['income_currency']} | معادل افغانی {fmt_num(d['income_afn'])}"),
                ("کل هزینه",f"{fmt_num(d['total_cost_afn'])} افغانی"),
                ("نتیجه",f"{'فایده' if d['profit_afn']>=0 else 'ضرر'} خالص {fmt_num(abs(d['profit_afn']))} افغانی")]
        if d.get('notes'): fields.append(("توضیحات",d['notes']))
        return self._professional_pdf('گزارش کامل بار',f"شماره بار: {d['shipment_no']}",fields,
            ['نوع هزینه','مبلغ','ارز','معادل افغانی'],rows,
            f"درآمد: {fmt_num(d['income_afn'])} افغانی | هزینه: {fmt_num(d['total_cost_afn'])} افغانی | {'فایده' if d['profit_afn']>=0 else 'ضرر'} خالص: {fmt_num(abs(d['profit_afn']))} افغانی",
            f"گزارش_بار_{d['shipment_no']}.pdf",target_path=target_path,include_outgoing_profile=True)

    def save_shipment_pdf(self, shipment_id):
        row=self.db.execute("SELECT * FROM shipments WHERE id=?",(shipment_id,)).fetchone()
        if not row:return
        cols=[x[1] for x in self.db.execute("PRAGMA table_info(shipments)").fetchall()]
        self._shipment_pdf(dict(zip(cols,row)))

    def send_shipment_whatsapp(self, shipment_id):
        row=self.db.execute("SELECT * FROM shipments WHERE id=?",(shipment_id,)).fetchone()
        if not row:return
        cols=[x[1] for x in self.db.execute("PRAGMA table_info(shipments)").fetchall()]
        d=dict(zip(cols,row))
        webbrowser.open("https://web.whatsapp.com/send?text="+urllib.parse.quote(self._shipment_share_text(d)))

    def shipment_detail_report(self, shipment_id):
        row=self.db.execute("SELECT * FROM shipments WHERE id=?",(shipment_id,)).fetchone()
        if not row:return
        cols=[x[1] for x in self.db.execute("PRAGMA table_info(shipments)").fetchall()]
        d=dict(zip(cols,row))
        win=tk.Toplevel(self); win.title(f"گزارش بار #{d['shipment_no']}"); win.geometry("820x700"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text=f"📄 گزارش کامل بار شماره {d['shipment_no']}",bg="#F4F6F8",fg="#1B2733",font=ui_font(18,"bold")).pack(anchor="e",padx=20,pady=12)
        box=tk.Text(win,bg="#FFFFFF",fg="#1B2733",font=ui_font(10),wrap="word",relief="flat")
        box.pack(fill="both",expand=True,padx=18,pady=8); box.tag_configure("rtl",justify="right")
        box.insert("1.0",self._shipment_share_text(d),"rtl"); box.configure(state="disabled")
        bar=tk.Frame(win,bg="#F4F6F8"); bar.pack(fill="x",padx=18,pady=8)
        self.button(bar,"📄 PDF حرفه‌ای",lambda:self.save_shipment_pdf(shipment_id)).pack(side="right",padx=4)
        self.button(bar,"📱 ارسال واتساپ",lambda:self.send_shipment_whatsapp(shipment_id),"#128c7e").pack(side="right",padx=4)

    def shipment_report_page(self):
        self.clear()
        RTLLabel(self.main,text="📊 گزارش کامل بارها و سود و ضرر",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=12)
        filt=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); filt.pack(fill="x",padx=20,pady=7)
        from_var=tk.StringVar(); to_var=tk.StringVar()
        RTLLabel(filt,text="از تاریخ میلادی (YYYY-MM-DD):",bg="#FFFFFF",fg="#374151").pack(side="right",padx=6,pady=7)
        tk.Entry(filt,textvariable=from_var,width=14,justify="right").pack(side="right",padx=4,pady=7)
        RTLLabel(filt,text="تا:",bg="#FFFFFF",fg="#374151").pack(side="right",padx=3)
        tk.Entry(filt,textvariable=to_var,width=14,justify="right").pack(side="right",padx=4,pady=7)
        box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); box.pack(fill="both",expand=True,padx=20,pady=8)
        summary=tk.StringVar(); RTLLabel(box,textvariable=summary,bg="#FFFFFF",fg="#0F766E",font=ui_font(11,"bold")).pack(fill="x",padx=12,pady=9)
        tree=ttk.Treeview(box,columns=("no","date","route","cargo","income","cost","profit"),show="headings",style="Jahan.Treeview")
        for c,h in [("no","شماره بار"),("date","تاریخ"),("route","مسیر"),("cargo","نوع بار"),("income","درآمد AFN"),("cost","هزینه AFN"),("profit","فایده/ضرر AFN")]:
            tree.heading(c,text=_icu_shape_arabic(h)); tree.column(c,width=115,anchor="e")
        tree.column("route",width=260); tree.column("cargo",width=130); self._pack_with_scrollbar(tree,fill="both",expand=True,padx=8,pady=8)
        state={"rows":[]}
        def load():
            for x in tree.get_children():tree.delete(x)
            clauses=[]; params=[]
            if from_var.get().strip(): clauses.append("date(created)>=date(?)"); params.append(from_var.get().strip())
            if to_var.get().strip(): clauses.append("date(created)<=date(?)"); params.append(to_var.get().strip())
            where=(" WHERE "+" AND ".join(clauses)) if clauses else ""
            rows=self.db.execute(f"SELECT shipment_no,created,origin_country,origin_province,destination_country,destination_province,cargo_type,income_afn,total_cost_afn,profit_afn FROM shipments{where} ORDER BY id DESC",params).fetchall()
            state["rows"]=rows; ti=tc=tp=0.0
            for r in rows:
                ti+=r[7] or 0; tc+=r[8] or 0; tp+=r[9] or 0
                route=f"{r[2]} - {r[3] or '-'} ← {r[4]} - {r[5] or '-'}"
                tree.insert("","end",values=(r[0],dual_datetime(r[1]),route,r[6] or "-",fmt_num(r[7]),fmt_num(r[8]),("فایده " if r[9]>=0 else "ضرر ")+fmt_num(abs(r[9]))))
            summary.set(f"تعداد بار: {len(rows)} | درآمد: {fmt_num(ti)} افغانی | هزینه: {fmt_num(tc)} افغانی | {'فایده' if tp>=0 else 'ضرر'} خالص: {fmt_num(abs(tp))} افغانی")
        def all_report_pdf():
            rows=state["rows"]
            table=[[r[0],dual_datetime(r[1]),f"{r[2]} - {r[3] or '-'} ← {r[4]} - {r[5] or '-'}",r[6] or '-',fmt_num(r[7]),fmt_num(r[8]),fmt_num(abs(r[9]))] for r in rows]
            ti=sum((r[7] or 0) for r in rows); tc=sum((r[8] or 0) for r in rows); tp=sum((r[9] or 0) for r in rows)
            self._professional_pdf('گزارش کامل بارها','گزارش سود و ضرر بارها',[("تعداد بار",len(rows)),("درآمد کل",f"{fmt_num(ti)} افغانی"),("هزینه کل",f"{fmt_num(tc)} افغانی"),("نتیجه خالص",f"{'فایده' if tp>=0 else 'ضرر'} {fmt_num(abs(tp))} افغانی")],['شماره','تاریخ','مسیر','نوع بار','درآمد AFN','هزینه AFN','فایده/ضرر AFN'],table,f"تعداد {len(rows)} | درآمد {fmt_num(ti)} | هزینه {fmt_num(tc)} | {'فایده' if tp>=0 else 'ضرر'} خالص {fmt_num(abs(tp))} افغانی",'گزارش_بارها.pdf',include_outgoing_profile=True)
        def all_report_wa():
            rows=state["rows"]; ti=sum((r[7] or 0) for r in rows); tc=sum((r[8] or 0) for r in rows); tp=sum((r[9] or 0) for r in rows)
            lines=self._outgoing_profile_text_lines()+["—","*گزارش کامل بارها*",f"تعداد بار: {len(rows)}",""]
            for r in rows:
                lines.append(f"• بار #{r[0]} | {dual_datetime(r[1])} | {r[2]} - {r[3] or '-'} ← {r[4]} - {r[5] or '-'} | {r[6] or '-'} | درآمد {fmt_num(r[7])} | هزینه {fmt_num(r[8])} | {'فایده' if r[9]>=0 else 'ضرر'} {fmt_num(abs(r[9]))} افغانی")
            lines += ["",f"جمع درآمد: {fmt_num(ti)} افغانی",f"جمع هزینه: {fmt_num(tc)} افغانی",f"{'فایده' if tp>=0 else 'ضرر'} خالص: {fmt_num(abs(tp))} افغانی"]
            webbrowser.open("https://web.whatsapp.com/send?text="+urllib.parse.quote("\n".join(lines)))
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=7)
        self.button(bar,"🔄 نمایش همه",lambda:(from_var.set(""),to_var.set(""),load()),"#64748B").pack(side="left",padx=4)
        self.button(bar,"📄 PDF گزارش بارها",all_report_pdf,"#0F766E").pack(side="right",padx=4)
        self.button(bar,"📱 واتساپ گزارش بارها",all_report_wa,"#128c7e").pack(side="right",padx=4)
        from_var.trace_add("write",lambda *a:load()); to_var.trace_add("write",lambda *a:load()); load()

    def reports_page(self):
        self.clear()
        RTLLabel(self.main,text="مرکز گزارش‌ها",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        RTLLabel(self.main,text="هر زمان خواستید، گزارش روزانه، ماهانه، سالانه یا هر بازه دلخواه را انتخاب کنید.",
                 bg="#F4F6F8",fg="#687582",font=ui_font(10)).pack(anchor="e",padx=20,pady=(0,10))

        actions=tk.Frame(self.main,bg="#F4F6F8"); actions.pack(fill="x",padx=20,pady=8)
        self.button(actions,"📅 گزارش روزانه",self.daily_result_page).pack(side="right",padx=4)
        self.button(actions,"🗓 گزارش ماهانه",self.monthly_report_page).pack(side="right",padx=4)
        self.button(actions,"📊 گزارش سالانه",self.annual_report_page).pack(side="right",padx=4)
        self.button(actions,"🔎 بازه دلخواه",self.custom_range_report_page).pack(side="right",padx=4)
        self.button(actions,"🔢 جمع بر اساس شماره",self.number_range_account_report_page,"#7c3aed").pack(side="right",padx=4)
        self.button(actions,"🚚 گزارش بارها",self.shipment_report_page,"#0F766E").pack(side="right",padx=4)
        self.button(actions,"خروجی CSV",self.export_csv).pack(side="left")

        box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        box.pack(fill="both",expand=True,padx=20,pady=12)
        RTLLabel(box,text="آخرین معاملات",bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=10)
        cols=("id","created","kind","currency","amount","rate","customer")
        tree=ttk.Treeview(box,columns=cols,show="headings", style="Jahan.Treeview",height=15)
        heads=["#","تاریخ","نوع","ارز","مبلغ","نرخ","مشتری"]
        for x,h in zip(cols,heads): tree.heading(x,text=_icu_shape_arabic(h)); tree.column(x,width=110,anchor="center")
        tree.column("customer",width=150)
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=10,pady=(0,12))
        for r in self.db.execute("SELECT id,created,kind,currency,amount,rate,customer FROM transactions ORDER BY id DESC LIMIT 200"):
            tree.insert("", "end", values=(r[0],dual_datetime(r[1]),r[2],r[3],r[4],r[5],r[6]))

    def _report_totals(self, where, params):
        """Legacy-compatible totals, always based on stored AFN equivalents.
        Currency-specific reports must use _period_currency_summary instead of adding raw amounts.
        """
        c=self.db.cursor()
        buy=float(c.execute(f"SELECT COALESCE(SUM(afn_amount),0) FROM transactions WHERE kind='خرید' AND {where}",params).fetchone()[0] or 0)
        sell=float(c.execute(f"SELECT COALESCE(SUM(afn_amount),0) FROM transactions WHERE kind='فروش' AND {where}",params).fetchone()[0] or 0)
        count=int(c.execute(f"SELECT COUNT(*) FROM transactions WHERE {where}",params).fetchone()[0] or 0)
        # Use the exact same net rule as customer ledgers: a commission in the same currency
        # reduces the effective account amount. This keeps daily/monthly/custom reports
        # synchronized with edits/deletions and the customer account screen.
        rec=float(c.execute(f"SELECT SUM((CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END) - CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN COALESCE(commission_afn,commission*COALESCE(rate,1)) ELSE 0 END) FROM account_entries WHERE entry_type='قرضداری مشتری' AND {where}",params).fetchone()[0] or 0)
        pay=float(c.execute(f"SELECT SUM((CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END) - CASE WHEN COALESCE(commission,0)>0 AND COALESCE(commission_currency,currency)=currency THEN COALESCE(commission_afn,commission*COALESCE(rate,1)) ELSE 0 END) FROM account_entries WHERE entry_type='بستانکاری مشتری' AND {where}",params).fetchone()[0] or 0)
        bcount=int(c.execute(f"SELECT COUNT(*) FROM business_transactions WHERE {where}",params).fetchone()[0] or 0)
        bsales=float(c.execute(f"SELECT SUM(CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END) FROM business_transactions WHERE kind='فروش' AND {where}",params).fetchone()[0] or 0)
        bbuys=float(c.execute(f"SELECT SUM(CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END) FROM business_transactions WHERE kind='خرید' AND {where}",params).fetchone()[0] or 0)
        return buy,sell,count,rec,pay,bcount,bsales,bbuys

    def _period_full_currency_summary(self, where, params):
        """Return raw amounts grouped by currency plus AFN equivalents for a report period.
        Raw USD/IRR/PKR/AFN values are never added together.
        """
        c=self.db.cursor()
        trades={}; accounts={}; shops={}
        for cur,kind,amt,afn in c.execute(f"SELECT COALESCE(currency,'AFN - افغانی'),kind,COALESCE(amount,0),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END FROM transactions WHERE {where}",params):
            key=cur or 'AFN - افغانی'; trades.setdefault(key,[D(0),D(0),D(0),D(0)])
            if kind=='خرید': trades[key][0]+=D(amt); trades[key][2]+=D(afn)
            elif kind=='فروش': trades[key][1]+=D(amt); trades[key][3]+=D(afn)
        for cur,kind,amt,afn,comm,commcur in c.execute(f"SELECT COALESCE(currency,'AFN - افغانی'),entry_type,COALESCE(amount,0),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END,COALESCE(commission,0),COALESCE(commission_currency,currency) FROM account_entries WHERE {where}",params):
            key=cur or 'AFN - افغانی'; accounts.setdefault(key,[D(0),D(0),D(0),D(0)])
            # Match customer_account/customer_currency_balances exactly.
            net_amt=D(amt)-D(comm) if D(comm)>0 and (commcur or key)==key else D(amt)
            net_afn=D(afn)-D(comm)*D(afn)/D(amt) if D(comm)>0 and (commcur or key)==key and D(amt)>0 else D(afn)
            if kind=='قرضداری مشتری': accounts[key][0]+=net_amt; accounts[key][2]+=net_afn
            elif kind=='بستانکاری مشتری': accounts[key][1]+=net_amt; accounts[key][3]+=net_afn
        for cur,kind,amt,afn in c.execute(f"SELECT COALESCE(currency,'AFN - افغانی'),kind,COALESCE(amount,0),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END FROM business_transactions WHERE {where}",params):
            key=cur or 'AFN - افغانی'; shops.setdefault(key,[D(0),D(0),D(0),D(0)])
            if kind=='خرید': shops[key][0]+=D(amt); shops[key][2]+=D(afn)
            elif kind=='فروش': shops[key][1]+=D(amt); shops[key][3]+=D(afn)
        return trades,accounts,shops

    def _report_currency_text(self, data, buy_label='خرید', sell_label='فروش'):
        if not data: return '0'
        lines=[]
        for cur,v in sorted(data.items()):
            code=str(cur).split(' - ')[0]
            lines.append(f"{code}: {buy_label} {fmt_money_exact(v[0])} | {sell_label} {fmt_money_exact(v[1])}")
        return '\n'.join(lines)

    def number_range_account_report_page(self):
        self.clear()
        RTLLabel(self.main,text="🔢 گزارش جمع بر اساس شماره حساب",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=14)
        RTLLabel(self.main,text="نوع گزارش و شماره شروع/پایان را انتخاب کنید. جمع‌ها با Decimal محاسبه می‌شوند تا خطای اعشاری ایجاد نشود.",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))
        bar=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); bar.pack(fill="x",padx=20,pady=8)
        kind=tk.StringVar(value="قرضداری")
        kinds=["قرضداری","بستانکاری","رسید","همه حساب‌ها"]
        LocalizedCombobox(bar,textvariable=kind,values=kinds,state="readonly",width=18).pack(side="right",padx=8,pady=10)
        startv=tk.StringVar(value="1"); endv=tk.StringVar(value="1000000")
        RTLLabel(bar,text="از شماره",bg="#FFFFFF",fg="#1B2733").pack(side="right",padx=3); tk.Entry(bar,textvariable=startv,width=10).pack(side="right",padx=4)
        RTLLabel(bar,text="تا شماره",bg="#FFFFFF",fg="#1B2733").pack(side="right",padx=3); tk.Entry(bar,textvariable=endv,width=10).pack(side="right",padx=4)
        currency=tk.StringVar(value="همه ارزها")
        LocalizedCombobox(bar,textvariable=currency,values=["همه ارزها"]+CURRENCIES,state="readonly",width=20).pack(side="right",padx=8)
        result=tk.Frame(self.main,bg="#F4F6F8"); result.pack(fill="both",expand=True,padx=20,pady=8)
        def run():
            try: a=int(startv.get()); b=int(endv.get()); assert a>=1 and b>=a
            except: messagebox.showerror("گزارش شماره","شماره شروع و پایان را درست وارد کنید."); return
            k=kind.get(); cur=currency.get(); rows=[]
            if k in ("قرضداری","بستانکاری","همه حساب‌ها"):
                types=[] if k=="همه حساب‌ها" else (["قرضداری مشتری"] if k=="قرضداری" else ["بستانکاری مشتری"])
                # Receipt-created account entries are excluded here because the original receipt
                # is added separately below. This makes the "رسید" report actually return receipts
                # while "همه حساب‌ها" still avoids double counting.
                q="SELECT account_no,created,customer,entry_type,amount,currency,source_type FROM account_entries WHERE account_no BETWEEN ? AND ? AND COALESCE(source_type,'manual')!='receipt'"
                params=[a,b]
                if types: q+=" AND entry_type=?"; params.append(types[0])
                if cur!="همه ارزها": q+=" AND currency=?"; params.append(cur)
                q+=" ORDER BY account_no"
                rows=[("حساب",)+tuple(r) for r in self.db.execute(q,params).fetchall()]
            if k in ("رسید","همه حساب‌ها"):
                q="SELECT receipt_no,created,customer,receipt_type,amount,COALESCE(currency,'AFN - افغانی'),'receipt' FROM receipts WHERE receipt_no BETWEEN ? AND ?"
                params=[a,b]
                if cur!="همه ارزها":
                    q+=" AND currency=?"; params.append(cur)
                q+=" ORDER BY receipt_no"
                rows += [("رسید",)+tuple(r) for r in self.db.execute(q,params).fetchall()]
            for w in result.winfo_children(): w.destroy()
            totals={}
            for _,no,dt,name,typ,amt,cur0,src in rows:
                key=cur0 or "AFN - افغانی"
                totals.setdefault(key,[D(0),D(0),0])
                if typ in ("قرضداری مشتری",): totals[key][0]+=D(amt)
                elif typ in ("بستانکاری مشتری",): totals[key][1]+=D(amt)
                elif src=="receipt":
                    # receipt itself: دریافت => credit, پرداخت => debt
                    if typ=="دریافت از مشتری": totals[key][1]+=D(amt)
                    else: totals[key][0]+=D(amt)
                totals[key][2]+=1
            # Different currencies are kept separate; no AFN conversion is shown.
            self.card(result,"مانده خالص هر ارز", " | ".join(f"{str(k).split(' - ')[0]}: {fmt_money_exact(v[0]-v[1])}" for k,v in sorted(totals.items())) or "0",0,0)
            self.card(result,"تعداد رکورد",str(len(rows)),0,1)
            self.card(result,"بازه شماره",f"{a} تا {b}",0,2)
            self.card(result,"ارزهای موجود",str(len(totals)),0,3)
            fx=tk.Frame(result,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); fx.grid(row=1,column=0,columnspan=4,sticky="nsew",pady=8)
            for j,h in enumerate(["ارز","قرضداری","بستانکاری","مانده خالص","تعداد"]):
                RTLLabel(fx,text=h,bg="#FFFFFF",fg="#1B2733",font=ui_font(9,"bold")).grid(row=0,column=j,padx=12,pady=7,sticky="e")
            for i,(ck,(debt,credit,count)) in enumerate(sorted(totals.items()),1):
                vals=[ck,fmt_money_exact(debt),fmt_money_exact(credit),fmt_money_exact(debt-credit),str(count)]
                for j,v in enumerate(vals): RTLLabel(fx,text=v,bg="#FFFFFF",fg="#334155",font=ui_font(9,"bold")).grid(row=i,column=j,padx=12,pady=4,sticky="e")
            for j in range(5): fx.columnconfigure(j,weight=1)
            detail=tk.Frame(result,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); detail.grid(row=2,column=0,columnspan=4,sticky="nsew",pady=10)
            result.grid_rowconfigure(2,weight=1)
            cols=("kind","no","date","name","type","amount","currency")
            tree=ttk.Treeview(detail,columns=cols,show="headings", style="Jahan.Treeview")
            heads={"kind":"بخش","no":"شماره","date":"تاریخ","name":"مشتری","type":"نوع","amount":"مبلغ","currency":"ارز"}
            for x in cols: tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,width=105,anchor="center")
            tree.column("name",width=150); tree.pack(fill="both",expand=True,padx=8,pady=8)
            for r in rows: tree.insert("","end",values=(r[0],r[1],r[2],r[3],r[4],fmt_money_exact(r[5]),r[6]))
            RTLLabel(detail,text=f"تعداد رکورد: {len(rows)} | بازه شماره {a} تا {b}",bg="#FFFFFF",fg="#64748B",font=ui_font(8,"bold")).pack(anchor="e",padx=10,pady=(0,7))
        self.button(bar,"🔎 محاسبه دقیق",run,"#157347").pack(side="right",padx=8,pady=6)
        run()

    def annual_report_page(self):
        self.clear()
        jy,jm,jd=current_jalali_parts()
        RTLLabel(self.main,text="گزارش سالانه",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=5)
        year=tk.StringVar(value=str(jy))
        RTLLabel(bar,text="سال:",bg="#F4F6F8",fg="#1B2733").pack(side="right",padx=5)
        tk.Entry(bar,textvariable=year,width=8,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1).pack(side="right",padx=4)
        result=tk.Frame(self.main,bg="#F4F6F8"); result.pack(fill="both",expand=True,padx=12,pady=10)
        def run():
            try:y=int(year.get())
            except:messagebox.showerror("گزارش سالانه","سال را درست وارد کنید.");return
            try:
                start_y=_jalali_to_gregorian(y,1,1); next_y=_jalali_to_gregorian(y+1,1,1)
            except Exception:
                messagebox.showerror("گزارش سالانه","سال هجری شمسی افغانستان را درست وارد کنید.");return
            start_s=start_y.strftime("%Y-%m-%d"); next_s=next_y.strftime("%Y-%m-%d")
            where="created >= ? AND created < ?"; params=(start_s,next_s)
            c=self.db.cursor(); trades,accounts,shops=self._period_full_currency_summary(where,params); pnl=self._period_profit_loss(where,params)
            count=int(c.execute("SELECT COUNT(*) FROM transactions WHERE "+where,params).fetchone()[0] or 0)
            bcount=int(c.execute("SELECT COUNT(*) FROM business_transactions WHERE "+where,params).fetchone()[0] or 0)
            for w in result.winfo_children():w.destroy()
            for i in range(4):result.columnconfigure(i,weight=1)
            profit,loss=self._profit_loss_total_text(pnl)
            cards=[
                ("تعداد معاملات ارزی",str(count)),
                ("خرید — هر ارز جدا",self._report_currency_text(trades,'خرید','فروش')),
                ("فروش — هر ارز جدا",self._report_currency_text({k:(v[1],v[1],v[3],v[3]) for k,v in trades.items()},'فروش','') if trades else "0"),
                ("تعداد خرید/فروش کالا",str(bcount)),
                ("سود / زیان سال",self._profit_loss_text(pnl)),
                ("مجموع سود سال",profit),
                ("مجموع زیان سال",loss),
                ("قرضداری / بستانکاری",self._report_currency_text(accounts,'قرضداری','بستانکاری'))]
            for i,(title,val) in enumerate(cards):self.card(result,title,val,i//4,i%4)
            detail=tk.Frame(result,bg="#FFFFFF"); detail.grid(row=2,column=0,columnspan=4,sticky="nsew",padx=8,pady=12)
            RTLLabel(detail,text=f"خلاصه ماه‌به‌ماه سال {y} — سود و زیان هر ارز",bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=8)
            cols=("month","count","buy","sell","profit","loss")
            tree=ttk.Treeview(detail,columns=cols,show="headings", style="Jahan.Treeview",height=14); heads={"month":"ماه افغانستان","count":"تعداد","buy":"خرید ارزی","sell":"فروش ارزی","profit":"سود","loss":"زیان"}
            for x in cols:tree.heading(x,text=_display_text(heads[x]));tree._jahan_original_headings=heads;tree.column(x,width=170,anchor="center")
            self._pack_with_scrollbar(tree,fill="both",expand=True,padx=10,pady=(0,10))
            for m in range(1,13):
                ms=_jalali_to_gregorian(y,m,1); ns=_jalali_to_gregorian(y+1,1,1) if m==12 else _jalali_to_gregorian(y,m+1,1)
                a,b=ms.strftime("%Y-%m-%d"),ns.strftime("%Y-%m-%d"); wp="created >= ? AND created < ?"; ppms=(a,b)
                mt,ma,msum=self._period_full_currency_summary(wp,ppms); mp=self._period_profit_loss(wp,ppms); mc=int(c.execute("SELECT COUNT(*) FROM transactions WHERE "+wp,ppms).fetchone()[0] or 0); pp,ll=self._profit_loss_total_text(mp)
                tree.insert("","end",values=(jalali_month_name(m),mc,self._report_currency_text(mt,'خرید','فروش'),self._report_currency_text({k:(v[1],v[1],v[3],v[3]) for k,v in mt.items()},'فروش','') if mt else "0",pp,ll))
            result.grid_rowconfigure(2,weight=1)
        self.button(bar,"🔎 نمایش گزارش",run).pack(side="right",padx=8);run()

    def custom_range_report_page(self):
        self.clear()
        RTLLabel(self.main,text="گزارش بازه دلخواه",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        RTLLabel(self.main,text="هر تاریخی را که خواستید وارد کنید؛ مثال: 2026-01-01 تا 2026-09-15",bg="#F4F6F8",fg="#687582",font=ui_font(10)).pack(anchor="e",padx=20,pady=(0,8))
        bar=tk.Frame(self.main,bg="#F4F6F8");bar.pack(fill="x",padx=20,pady=5)
        start=tk.StringVar(value=date.today().replace(day=1).strftime("%Y-%m-%d"));end=tk.StringVar(value=date.today().strftime("%Y-%m-%d"))
        RTLLabel(bar,text="از تاریخ:",bg="#F4F6F8",fg="#1B2733").pack(side="right",padx=5);tk.Entry(bar,textvariable=start,width=13).pack(side="right",padx=5);RTLLabel(bar,text="تا تاریخ:",bg="#F4F6F8",fg="#1B2733").pack(side="right",padx=5);tk.Entry(bar,textvariable=end,width=13).pack(side="right",padx=5)
        result=tk.Frame(self.main,bg="#F4F6F8");result.pack(fill="both",expand=True,padx=12,pady=10)
        def run():
            a=start.get().strip().replace('/','-');b=end.get().strip().replace('/','-')
            try:da=datetime.strptime(a,"%Y-%m-%d").date();db=datetime.strptime(b,"%Y-%m-%d").date();
            except:messagebox.showerror("گزارش بازه","تاریخ‌ها را با فرمت YYYY-MM-DD وارد کنید.");return
            if da>db:messagebox.showerror("گزارش بازه","تاریخ شروع نباید بعد از تاریخ پایان باشد.");return
            next_day=(db+timedelta(days=1)).strftime("%Y-%m-%d");where="created >= ? AND created < ?";params=(a,next_day);trades,accounts,shops=self._period_full_currency_summary(where,params);pnl=self._period_profit_loss(where,params);count=int(self.db.execute("SELECT COUNT(*) FROM transactions WHERE "+where,params).fetchone()[0] or 0);bcount=int(self.db.execute("SELECT COUNT(*) FROM business_transactions WHERE "+where,params).fetchone()[0] or 0)
            for w in result.winfo_children():w.destroy()
            for i in range(4):result.columnconfigure(i,weight=1)
            profit,loss=self._profit_loss_total_text(pnl)
            cards=[("تعداد معاملات ارزی",str(count)),("خرید — هر ارز جدا",self._report_currency_text(trades,'خرید','فروش')), ("فروش — هر ارز جدا",self._report_currency_text({k:(v[1],v[1],v[3],v[3]) for k,v in trades.items()},'فروش','') if trades else "0"),("تعداد خرید/فروش کالا",str(bcount)),("سود / زیان بازه",self._profit_loss_text(pnl)),("مجموع سود",profit),("مجموع زیان",loss),("قرضداری / بستانکاری",self._report_currency_text(accounts,'قرضداری','بستانکاری'))]
            for i,(title,val) in enumerate(cards):self.card(result,title,val,i//4,i%4)
            detail=tk.Frame(result,bg="#FFFFFF");detail.grid(row=2,column=0,columnspan=4,sticky="nsew",padx=8,pady=12);RTLLabel(detail,text=f"جزئیات از {a} تا {b} — ارز و مبلغ اصلی هر ثبت",bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=8)
            cols=("date","category","type","name","currency","amount","notes");tree=ttk.Treeview(detail,columns=cols,show="headings", style="Jahan.Treeview");heads={"date":"تاریخ","category":"بخش","type":"نوع","name":"مشتری / دکان","currency":"ارز","amount":"مبلغ اصلی","notes":"توضیحات"}
            for x in cols:tree.heading(x,text=_display_text(heads[x]));tree._jahan_original_headings=heads;tree.column(x,width=130,anchor="center")
            tree.column("name",width=160);tree.column("notes",width=220);self._pack_with_scrollbar(tree,fill="both",expand=True,padx=10,pady=(0,10))
            queries=[
                ("معامله ارزی","SELECT created,kind,customer,COALESCE(currency,'AFN - افغانی'),amount,notes FROM transactions WHERE "+where+" ORDER BY created DESC"),
                ("حساب مشتری","SELECT created,entry_type,customer,COALESCE(currency,'AFN - افغانی'),amount,notes FROM account_entries WHERE "+where+" ORDER BY created DESC"),
                ("دکان","SELECT created,kind,business_name,COALESCE(currency,'AFN - افغانی'),amount,notes FROM business_transactions WHERE "+where+" ORDER BY created DESC")]
            for cat,q in queries:
                for r in self.db.execute(q,params):tree.insert("","end",values=(dual_datetime(r[0]),cat,r[1],r[2] or "-",r[3],fmt_money_exact(r[4]),r[5] or "-"))
            result.grid_rowconfigure(2,weight=1)
        self.button(bar,"🔎 نمایش گزارش",run).pack(side="right",padx=8);run()

    def _period_currency_summary(self, where, params):
        """Return exact per-currency totals plus separate AFN equivalents.
        Never add USD/IRR/PKR/AFN amounts together as if they were the same unit.
        """
        c=self.db.cursor()
        rows={}
        for cur,amt in c.execute(f"SELECT COALESCE(currency,'AFN - افغانی'),COALESCE(amount,0) FROM transactions WHERE {where}",params):
            key=cur or 'AFN - افغانی'; rows.setdefault(key,[D(0),D(0)])
        for cur,kind,amt in c.execute(f"SELECT COALESCE(currency,'AFN - افغانی'),entry_type,COALESCE(amount,0) FROM account_entries WHERE {where}",params):
            key=cur or 'AFN - افغانی'; rows.setdefault(key,[D(0),D(0)])
            if kind=='قرضداری مشتری': rows[key][0]+=D(amt)
            elif kind=='بستانکاری مشتری': rows[key][1]+=D(amt)
        # Transaction buy/sell totals are kept separately because they have a different semantic meaning.
        trades={}
        for cur,kind,amt in c.execute(f"SELECT COALESCE(currency,'AFN - افغانی'),kind,COALESCE(amount,0) FROM transactions WHERE {where}",params):
            key=cur or 'AFN - افغانی'; trades.setdefault(key,[D(0),D(0)])
            if kind=='خرید': trades[key][0]+=D(amt)
            elif kind=='فروش': trades[key][1]+=D(amt)
        afn_debt=sum((v[0]-v[1])*D(self.get_rate_to_afn(k) or 1) for k,v in rows.items())
        afn_buy=sum(v[0]*D(self.get_rate_to_afn(k) or 1) for k,v in trades.items())
        afn_sell=sum(v[1]*D(self.get_rate_to_afn(k) or 1) for k,v in trades.items())
        return rows,trades,afn_debt,afn_buy,afn_sell

    def _currency_lines(self, data, empty='0'):
        if not data: return empty
        parts=[]
        for cur,(a,b) in sorted(data.items()):
            code=str(cur).split(' - ')[0]
            if isinstance(a,D) and isinstance(b,D):
                parts.append(f"{code}: {fmt_money_exact(a)} | {fmt_money_exact(b)}")
            else:
                parts.append(f"{code}: {fmt_money_exact(a)}")
        return "\n".join(parts)

    def _period_profit_loss(self, where, params):
        """Return profit/loss by currency without converting anything to AFN.
        Profit is calculated from shop/goods activity (sales - purchases) in the
        original currency. Customer receipts and account balances are excluded
        because they are cash/account movements, not revenue or expense.
        """
        c=self.db.cursor()
        data={}
        for cur,kind,amt in c.execute(
            f"SELECT COALESCE(currency,'AFN - افغانی'),kind,COALESCE(amount,0) "
            f"FROM business_transactions WHERE {where}", params):
            key=cur or 'AFN - افغانی'
            rec=data.setdefault(key, [D(0),D(0)])
            if kind=='فروش': rec[0] += D(amt)
            elif kind=='خرید': rec[1] += D(amt)
        result={}
        for cur,(sales,purchases) in data.items():
            net=sales-purchases
            result[cur]={"sales":sales,"purchases":purchases,"net":net,
                         "profit":max(net,D(0)),"loss":max(-net,D(0))}
        return result

    def _profit_loss_text(self, data):
        if not data:
            return "بدون ثبت خرید و فروش کالا"
        lines=[]
        for cur,v in sorted(data.items()):
            code=str(cur).split(' - ')[0]
            net=v['net']
            if net>0:
                lines.append(f"{code}: سود {fmt_money_exact(v['profit'])}")
            elif net<0:
                lines.append(f"{code}: زیان {fmt_money_exact(v['loss'])}")
            else:
                lines.append(f"{code}: سربه‌سر 0")
        return "\n".join(lines)

    def _profit_loss_total_text(self, data):
        profit={}; loss={}
        for cur,v in data.items():
            if v['profit']>0: profit[cur]=v['profit']
            if v['loss']>0: loss[cur]=v['loss']
        p=" | ".join(f"{str(k).split(' - ')[0]}: {fmt_money_exact(v)}" for k,v in sorted(profit.items())) or "0"
        l=" | ".join(f"{str(k).split(' - ')[0]}: {fmt_money_exact(v)}" for k,v in sorted(loss.items())) or "0"
        return p,l

    def daily_result_page(self):
        self.clear()
        today=date.today().strftime("%Y-%m-%d")
        RTLLabel(self.main,text=f"گزارش روزانه — {today}",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        c=self.db.cursor(); where="created LIKE ?"; params=(today+"%",)
        rows,trades,shops=self._period_full_currency_summary(where,params)
        pnl=self._period_profit_loss(where,params)
        count=int(c.execute("SELECT COUNT(*) FROM transactions WHERE created LIKE ?",params).fetchone()[0] or 0)
        bcount=int(c.execute("SELECT COUNT(*) FROM business_transactions WHERE created LIKE ?",params).fetchone()[0] or 0)
        grid=tk.Frame(self.main,bg="#F4F6F8"); grid.pack(fill="x",padx=12)
        for i in range(4): grid.columnconfigure(i,weight=1)
        self.card(grid,"تعداد معاملات ارزی",str(count),0,0)
        self.card(grid,"خرید امروز — هر ارز جدا",self._report_currency_text(trades,'خرید','فروش'),0,1)
        self.card(grid,"فروش امروز — هر ارز جدا",self._report_currency_text({k:(v[1],v[1],v[3],v[3]) for k,v in trades.items()},'فروش','') if trades else "0",0,2)
        self.card(grid,"تعداد خرید/فروش کالا",str(bcount),0,3)
        self.card(grid,"سود / زیان امروز",self._profit_loss_text(pnl),1,0)
        profit,loss=self._profit_loss_total_text(pnl)
        self.card(grid,"مجموع سود امروز",profit,1,1)
        self.card(grid,"مجموع زیان امروز",loss,1,2)
        self.card(grid,"قرضداری / بستانکاری",self._report_currency_text(rows,'قرضداری','بستانکاری'),1,3)

        box=tk.Frame(self.main,bg="#FFFFFF"); box.pack(fill="both",expand=True,padx=20,pady=15)
        RTLLabel(box,text="جزئیات مالی امروز — بر اساس ارز اصلی هر ثبت",bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=10)
        cols=("time","section","type","name","currency","amount","notes")
        tree=ttk.Treeview(box,columns=cols,show="headings", style="Jahan.Treeview")
        heads={"time":"زمان","section":"بخش","type":"نوع","name":"مشتری / دکان","currency":"ارز","amount":"مبلغ","notes":"توضیحات"}
        for x in cols:
            tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings=heads; tree.column(x,width=120,anchor="center")
        tree.column("name",width=170); tree.column("notes",width=220)
        self._pack_with_scrollbar(tree,fill="both",expand=True,padx=10,pady=5)
        queries=[
            ("معامله ارزی","SELECT created,kind,customer,COALESCE(currency,'AFN - افغانی'),amount,notes FROM transactions WHERE created LIKE ? ORDER BY id DESC"),
            ("حساب مشتری","SELECT created,entry_type,customer,COALESCE(currency,'AFN - افغانی'),amount,notes FROM account_entries WHERE created LIKE ? ORDER BY id DESC"),
            ("دکان","SELECT created,kind,business_name,COALESCE(currency,'AFN - افغانی'),amount,notes FROM business_transactions WHERE created LIKE ? ORDER BY id DESC")]
        for section,q in queries:
            for r in c.execute(q,params):
                tree.insert("","end",values=(dual_datetime(r[0]),section,r[1],r[2] or "-",r[3],fmt_money_exact(r[4]),r[5] or "-"))

    def receipt_center_page(self):
        """مرکز واقعی رسید مشتری: ثبت، فهرست و رسیدهای روزانه."""
        self.clear()
        now=datetime.now()
        RTLLabel(self.main,text="🧾 مرکز رسید مشتری",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=(12,4))
        RTLLabel(self.main,text=f"تاریخ شمسی: {jalali_date(now)}  |  میلادی: {now:%Y/%m/%d}  |  ساعت: {now:%H:%M:%S}",bg="#F4F6F8",fg="#0F766E",font=ui_font(10,"bold")).pack(anchor="e",padx=20,pady=(0,12))
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=5)
        self.button(bar,"＋ ثبت رسید مشتری",self.register_receipt_page,"#0F766E").pack(side="right",padx=5)
        self.button(bar,"📋 همه رسیدهای مشتری",self.receipts_list_page,"#2563EB").pack(side="right",padx=5)
        self.button(bar,"📅 رسیدهای روزانه",self.daily_customer_receipts_page,"#7C3AED").pack(side="right",padx=5)
        box=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); box.pack(fill="both",expand=True,padx=20,pady=12)
        RTLLabel(box,text="آخرین رسیدهای مشتری",bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=10)
        cols=("no","date","customer","type","amount","currency","commission","commission_currency")
        tree=ttk.Treeview(box,columns=cols,show="headings", style="Jahan.Treeview")
        heads={"no":"شماره رسید","date":"تاریخ","customer":"مشتری","type":"نوع رسید","amount":"مبلغ","currency":"ارز","commission":"کمیشن","commission_currency":"ارز کمیشن"}
        for x in cols:
            tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,width=125,anchor="center")
        tree.column("customer",width=170)
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=10,pady=(0,12))
        for r in self.db.execute("SELECT receipt_no,created,customer,receipt_type,amount,COALESCE(currency,'AFN - افغانی'),COALESCE(commission,0),COALESCE(commission_currency,currency,'AFN - افغانی') FROM receipts ORDER BY id DESC LIMIT 100"):
            tree.insert("","end",values=(r[0],dual_datetime(r[1]),r[2],r[3],fmt_money_exact(r[4]),r[5],fmt_money_exact(r[6]),r[7]))
        def open_selected():
            sel=tree.selection()
            if not sel:return
            no=tree.item(sel[0],"values")[0]
            row=self.db.execute("SELECT id FROM receipts WHERE receipt_no=? ORDER BY id DESC LIMIT 1",(no,)).fetchone()
            if row:self.show_receipt_by_id(row[0])
        self.button(self.main,"👁 مشاهده / چاپ رسید انتخاب‌شده",open_selected).pack(pady=8)

    def register_receipt_page(self):
        self.clear()
        receipt_now=datetime.now()
        head=tk.Frame(self.main,bg="#F4F6F8")
        head.pack(fill="x",padx=20,pady=(10,4))
        RTLLabel(head,text="ثبت رسید مشتری",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(side="right")
        RTLLabel(head,text=f"زمان ثبت: {jalali_date(receipt_now)} | {receipt_now:%Y/%m/%d} | {receipt_now:%H:%M:%S}",bg="#F4F6F8",fg="#0F766E",font=ui_font(9,"bold")).pack(side="left",pady=6)
        form=tk.Frame(self.main,bg="#FFFFFF"); form.pack(fill="x",padx=20,pady=10)
        names=self.get_customer_list()
        customer=tk.StringVar(); typ=tk.StringVar(value="دریافت از مشتری"); amount=tk.StringVar(); desc=tk.StringVar(); cur=tk.StringVar(value=CURRENCIES[0]); rate=tk.StringVar(value="1")
        route=tk.StringVar(value="افغانستان"); commission_enabled=tk.BooleanVar(value=False); no_commission=tk.BooleanVar(value=False); commission_base=tk.StringVar(value="1000000"); commission_per_base=tk.StringVar(value="0"); commission_total=tk.StringVar(value="0"); commission_net=tk.StringVar(value="0")
        fields=[("مشتری","customer"),("نوع رسید","typ"),("ارز","currency"),("مبلغ","amount"),("توضیحات","desc")]
        widgets={}
        for i,(lab,key) in enumerate(fields):
            cell=tk.Frame(form,bg="#FFFFFF"); cell.grid(row=i//2,column=i%2,padx=15,pady=10,sticky="ew")
            form.columnconfigure(i%2,weight=1)
            RTLLabel(cell,text=lab,bg="#FFFFFF",fg="#C7CFD7").pack(anchor="e")
            if key=="customer": w=LocalizedCombobox(cell,textvariable=customer,values=[f"{i} - {n}" for i,n in names],state="readonly")
            elif key=="typ": w=LocalizedCombobox(cell,textvariable=typ,values=["دریافت از مشتری","پرداخت به مشتری"],state="readonly")
            elif key=="currency": w=LocalizedCombobox(cell,textvariable=cur,values=CURRENCIES,state="readonly")
            else: w=tk.Entry(cell,textvariable=amount if key=="amount" else rate if key=="rate" else desc,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3")
            w.pack(fill="x",ipady=7); widgets[key]=w
        # Commission controls: configurable amount per selected base (default 1,000,000).
        fee_box=tk.Frame(form,bg="#F8FAFC",highlightbackground="#D8DEE4",highlightthickness=1); fee_box.grid(row=3,column=0,columnspan=2,padx=15,pady=8,sticky="ew")
        RTLLabel(fee_box,text="💰 کمیشن رسید — قابل تنظیم برای هر ۱٬۰۰۰٬۰۰۰ واحد ارز",bg="#F8FAFC",fg="#7C3AED",font=ui_font(10,"bold")).grid(row=0,column=0,columnspan=4,padx=10,pady=6,sticky="e")
        fee_box.columnconfigure(1,weight=1); fee_box.columnconfigure(3,weight=1)
        tk.Checkbutton(fee_box,text="محاسبه خودکار",variable=commission_enabled,bg="#F8FAFC",fg="#1B2733",activebackground="#F8FAFC",command=lambda:(no_commission.set(False),calc_receipt_commission())).grid(row=1,column=3,padx=8,pady=4,sticky="e")
        self.button(fee_box,"بدون کمیشن",lambda:(no_commission.set(True),commission_enabled.set(False),calc_receipt_commission()),"#B91C1C").grid(row=1,column=0,padx=8,pady=4,sticky="w")
        RTLLabel(fee_box,text="مسیر",bg="#F8FAFC",fg="#687582").grid(row=1,column=2,padx=5,sticky="e")
        route_cb=LocalizedCombobox(fee_box,textvariable=route,values=["افغانستان","ایران"],state="readonly",width=13); route_cb.grid(row=1,column=1,padx=5,pady=4,sticky="ew")
        RTLLabel(fee_box,text="پایه",bg="#F8FAFC",fg="#687582").grid(row=2,column=3,padx=5,sticky="e")
        base_entry=tk.Entry(fee_box,textvariable=commission_base,justify="center"); base_entry.grid(row=2,column=2,padx=5,pady=4,sticky="ew")
        RTLLabel(fee_box,text="کمیشن / پایه",bg="#F8FAFC",fg="#687582").grid(row=2,column=1,padx=5,sticky="e")
        fee_entry=tk.Entry(fee_box,textvariable=commission_per_base,justify="center"); fee_entry.grid(row=2,column=0,padx=5,pady=4,sticky="ew")
        RTLLabel(fee_box,text="کمیشن این رسید",bg="#F8FAFC",fg="#0F766E",font=ui_font(9,"bold")).grid(row=3,column=3,padx=5,sticky="e")
        total_fee_label=RTLLabel(fee_box,textvariable=commission_total,bg="#E8F7F2",fg="#0F766E",font=ui_font(10,"bold")); total_fee_label.grid(row=3,column=0,columnspan=3,padx=8,pady=5,sticky="ew")
        RTLLabel(fee_box,text="مبلغ خالص بعد از کمیشن",bg="#F8FAFC",fg="#7C3AED",font=ui_font(9,"bold")).grid(row=4,column=3,padx=5,sticky="e")
        RTLLabel(fee_box,textvariable=commission_net,bg="#F3EEFF",fg="#6D28D9",font=ui_font(10,"bold")).grid(row=4,column=0,columnspan=3,padx=8,pady=5,sticky="ew")
        self.button(fee_box,"⚙ تنظیم کمیشن",lambda:self.commission_settings(cur.get()),"#64748B").grid(row=5,column=0,columnspan=4,pady=5)
        RTLLabel(form,text="اصل مبلغ و کمیشن جداگانه ثبت می‌شوند؛ کمیشن در بستانکاری/قرضداری نیز قابل مشاهده و جمع‌بندی است.",bg="#FFFFFF",fg="#687582").grid(row=4,column=0,columnspan=2,pady=5)
        def calc_receipt_commission(*args):
            try: val=float(D(amount.get() or 0))
            except: val=0
            try: base=float(D(commission_base.get() or 1000000)); fee=float(D(commission_per_base.get() or 0))
            except: base=1000000; fee=0
            total=(val/base*fee) if commission_enabled.get() and (not no_commission.get()) and base>0 else 0
            commission_total.set((f"کمیشن: {fmt_num(total)} {cur.get()}" if total>0 else "کمیشن: 0" + (f" {cur.get()}" if cur.get() else "")))
            commission_net.set(f"خالص: {fmt_num(max(val-total,0))} {cur.get()}" if val>0 else f"خالص: 0 {cur.get()}")
            return total
        def load_receipt_rule(event=None):
            base,fee=self._commission_rule(route.get(),cur.get()); commission_base.set(str(base)); commission_per_base.set(str(fee)); no_commission.set(False); commission_enabled.set(fee>0); calc_receipt_commission()
        def sync_receipt_rate(event=None):
            rate.set(str(self.get_rate_to_afn(cur.get()) or 1)); load_receipt_rule()
        widgets["currency"].bind("<<ComboboxSelected>>",sync_receipt_rate)
        route_cb.bind("<<ComboboxSelected>>",load_receipt_rule)
        amount.trace_add("write",calc_receipt_commission); commission_base.trace_add("write",calc_receipt_commission); commission_per_base.trace_add("write",calc_receipt_commission)
        load_receipt_rule(); sync_receipt_rate()
        def save():
            if widgets["customer"].current()<0: messagebox.showwarning("ثبت رسید","لطفاً مشتری را انتخاب کنید."); return
            try: val=float(D(amount.get())); rv=float(D(rate.get()))
            except: messagebox.showerror("خطا","مبلغ و نرخ باید عددی باشند."); return
            if val<=0 or rv<=0: messagebox.showerror("خطا","مبلغ باید بیشتر از صفر باشد."); return
            cid,cname=names[widgets["customer"].current()]; now=datetime.now().strftime("%Y-%m-%d %H:%M")
            try: cbase=float(D(commission_base.get() or 1000000)); cfee=float(D(commission_per_base.get() or 0))
            except: cbase=1000000; cfee=0
            comm=(val/cbase*cfee) if commission_enabled.get() and (not no_commission.get()) and cbase>0 else 0
            cafn=comm*rv
            cur_ins=self.db.execute("""INSERT INTO receipts(created,customer_id,customer,receipt_type,amount,description,currency,rate,afn_amount,commission_base,commission_rate,commission,commission_afn,commission_currency,route) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(now,cid,cname,typ.get(),val,desc.get().strip(),cur.get(),rv,val*rv,cbase,cfee,comm,cafn,cur.get(),route.get()))
            rid=cur_ins.lastrowid
            rno=self.db.execute("SELECT receipt_no FROM receipts WHERE id=?",(rid,)).fetchone()[0] or rid
            entry_type="بستانکاری مشتری" if typ.get()=="دریافت از مشتری" else "قرضداری مشتری"
            self.db.execute("""INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,commission,commission_afn,commission_currency,route,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(now,cid,cname,entry_type,val,f"رسید شماره {rno} - {desc.get().strip()}",cur.get(),rv,val*rv,comm,cafn,cur.get(),route.get(),'receipt',rid))
            self.db.commit(); messagebox.showinfo("موفق",f"رسید شماره {rno} با موفقیت ثبت شد."); self.show_receipt_by_id(rid)
        self.button(form,"✓ ثبت و نمایش رسید",save).grid(row=5,column=0,columnspan=2,pady=18)
        self.button(form,"↩ بازگشت به حسابات مشتریان",self.accounts_page,"#64748B").grid(row=6,column=0,columnspan=2,pady=(0,14))

    def show_receipt_by_id(self,rid):
        row=self.db.execute("SELECT id,created,customer,receipt_type,amount,description,receipt_no,currency,rate,afn_amount,COALESCE(commission,0),COALESCE(commission_base,1000000),COALESCE(commission_rate,0),COALESCE(route,'') FROM receipts WHERE id=?",(rid,)).fetchone()
        if not row:return
        self.clear(); RTLLabel(self.main,text="رسید مشتری",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        box=tk.Frame(self.main,bg="white"); box.pack(padx=100,pady=15,fill="both",expand=True)
        texts=[APP_NAME,"════════════════════════",f"شماره رسید: {row[6]}",f"تاریخ: {dual_datetime(row[1])}",f"مشتری: {row[2]}",f"نوع رسید: {row[3]}",f"مبلغ: {fmt_num(row[4])} {row[7] if len(row)>7 else 'AFN - افغانی'}",f"کمیشن: {fmt_num(row[10])} {row[7] if len(row)>7 else 'AFN - افغانی'}",f"توضیحات: {row[5] or '-'}","════════════════════════","با تشکر از اعتماد شما","خالد رحیمی | ۰۷۹۶۲۹۷۹۹۶"]
        RTLLabel(box,text="\n".join(texts),bg="white",fg="#B8862F",font=ui_font(14,"bold"),justify="right",anchor="e").pack(fill="both",expand=True,padx=35,pady=30)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=8)
        self.button(bar,"✏️ ویرایش رسید",lambda:self.edit_receipt_page(rid)).pack(side="right",padx=5)
        self.button(bar,"🗑 حذف رسید",lambda:self.delete_receipt(rid),"#B42318").pack(side="right",padx=5)
        self.button(bar,"🖨 چاپ / ذخیره رسید",lambda:self.save_customer_receipt(row)).pack(side="right",padx=5)
        self.button(bar,"📄 PDF حرفه‌ای",lambda:self.save_receipt_pdf(row)).pack(side="right",padx=3)
        self.button(bar,"📊 Excel رسید",lambda:self.export_single_receipt_xlsx(row),"#0f766e").pack(side="right",padx=3)
        self.button(bar,"📱 ارسال PDF",lambda:self.send_receipt_pdf(row,share=True)).pack(side="right",padx=3)
        self.button(bar,"📱 واتساپ مشتری",lambda:self.send_receipt_whatsapp(row),"#128c7e").pack(side="right",padx=5)
        self.button(bar,"✈ تلگرام مشتری",lambda:self.send_receipt_telegram(row),"#229ed9").pack(side="right",padx=5)
        self.button(bar,"↩ ثبت رسید جدید",self.register_receipt_page,"#475569").pack(side="left",padx=5)

    def edit_receipt_page(self, rid):
        row=self.db.execute("""SELECT id,created,customer_id,customer,receipt_type,amount,description,
                                     receipt_no,currency,rate,afn_amount,COALESCE(edit_count,0),
                                     COALESCE(commission_base,1000000),COALESCE(commission_rate,0),COALESCE(commission,0),COALESCE(route,'')
                              FROM receipts WHERE id=?""",(rid,)).fetchone()
        if not row: return
        self.clear()
        RTLLabel(self.main,text="ویرایش رسید مشتری",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        form=tk.Frame(self.main,bg="#FFFFFF"); form.pack(fill="x",padx=20,pady=10)
        names=self.get_customer_list()
        customer=tk.StringVar(value=f"{row[2]} - {row[3]}" if row[2] else row[3])
        typ=tk.StringVar(value=row[4]); amount=tk.StringVar(value=str(row[5]))
        desc=tk.StringVar(value=row[6] or ""); cur=tk.StringVar(value=row[8] or CURRENCIES[0])
        rate=tk.StringVar(value=str(row[9] or 1)); commission_base=tk.StringVar(value=str(row[12] or 1000000)); commission_per_base=tk.StringVar(value=str(row[13] or 0)); commission_total=tk.StringVar(value=str(row[14] or 0)); route=tk.StringVar(value=row[15] or "افغانستان")
        fields=[("مشتری","customer"),("نوع رسید","typ"),("ارز","currency"),("مبلغ","amount"),("توضیحات","desc")]
        widgets={}
        for i,(lab,key) in enumerate(fields):
            cell=tk.Frame(form,bg="#FFFFFF"); cell.grid(row=i//2,column=i%2,padx=15,pady=10,sticky="ew")
            form.columnconfigure(i%2,weight=1)
            RTLLabel(cell,text=lab,bg="#FFFFFF",fg="#1B2733").pack(anchor="e")
            if key=="customer":
                w=LocalizedCombobox(cell,textvariable=customer,values=[f"{i} - {n}" for i,n in names],state="readonly")
            elif key=="typ":
                w=LocalizedCombobox(cell,textvariable=typ,values=["دریافت از مشتری","پرداخت به مشتری"],state="readonly")
            elif key=="currency":
                w=LocalizedCombobox(cell,textvariable=cur,values=CURRENCIES,state="readonly")
            else:
                v=amount if key=="amount" else rate if key=="rate" else desc
                w=tk.Entry(cell,textvariable=v,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3")
            w.pack(fill="x",ipady=7); widgets[key]=w
        fee_box=tk.Frame(form,bg="#F8FAFC",highlightbackground="#D8DEE4",highlightthickness=1); fee_box.grid(row=3,column=0,columnspan=2,padx=15,pady=8,sticky="ew")
        RTLLabel(fee_box,text="💰 کمیشن این رسید",bg="#F8FAFC",fg="#7C3AED",font=ui_font(10,"bold")).pack(anchor="e",padx=10,pady=5)
        fee_row=tk.Frame(fee_box,bg="#F8FAFC"); fee_row.pack(fill="x",padx=10,pady=4)
        RTLLabel(fee_row,text="مسیر",bg="#F8FAFC",fg="#687582").pack(side="right",padx=4); route_cb=LocalizedCombobox(fee_row,textvariable=route,values=["افغانستان","ایران"],state="readonly",width=12); route_cb.pack(side="right",padx=4)
        RTLLabel(fee_row,text="پایه",bg="#F8FAFC",fg="#687582").pack(side="right",padx=4); tk.Entry(fee_row,textvariable=commission_base,width=12,justify="center").pack(side="right",padx=4)
        RTLLabel(fee_row,text="کمیشن/پایه",bg="#F8FAFC",fg="#687582").pack(side="right",padx=4); tk.Entry(fee_row,textvariable=commission_per_base,width=12,justify="center").pack(side="right",padx=4)
        RTLLabel(fee_box,textvariable=commission_total,bg="#F8FAFC",fg="#0F766E",font=ui_font(10,"bold")).pack(anchor="e",padx=10,pady=5)
        def calc_edit_commission(*args):
            try: v=float(D(amount.get() or 0)); b=float(D(commission_base.get() or 1000000)); f=float(D(commission_per_base.get() or 0))
            except: v=0; b=1000000; f=0
            commission_total.set(f"کمیشن این رسید: {fmt_num((v/b*f) if b>0 else 0)} {cur.get()}")
        amount.trace_add("write",calc_edit_commission); commission_base.trace_add("write",calc_edit_commission); commission_per_base.trace_add("write",calc_edit_commission); calc_edit_commission()
        RTLLabel(form,text="این رسید فقط یک‌بار قابل ویرایش است. بعد از ذخیره، تغییر دوباره امکان‌پذیر نیست.",
                 bg="#FFFFFF",fg="#B42318").grid(row=4,column=0,columnspan=2,pady=8)
        def save_edit():
            try:
                val=float(D(amount.get())); rv=float(D(rate.get()))
            except:
                messagebox.showerror("خطا","مبلغ و نرخ باید عددی باشند."); return
            if val<=0 or rv<=0:
                messagebox.showerror("خطا","مبلغ و نرخ باید بیشتر از صفر باشند."); return
            try: cbase=float(D(commission_base.get() or 1000000)); cfee=float(D(commission_per_base.get() or 0))
            except: cbase=1000000; cfee=0
            comm=(val/cbase*cfee) if cbase>0 else 0; cafn=comm*rv
            if widgets["customer"].current() >= 0:
                cid,cname=names[widgets["customer"].current()]
            else:
                cid,cname=row[2],row[3]
            old_entry=self.db.execute("SELECT id FROM account_entries WHERE source_type='receipt' AND source_id=? ORDER BY id DESC LIMIT 1",(rid,)).fetchone()
            if not old_entry:
                old_entry=self.db.execute("SELECT id FROM account_entries WHERE source_type='receipt' AND notes LIKE ? ORDER BY id DESC LIMIT 1",(f"رسید شماره {row[7]}%",)).fetchone()
            cur_update=self.db.execute("""UPDATE receipts SET customer_id=?,customer=?,receipt_type=?,amount=?,description=?,
                               currency=?,rate=?,afn_amount=?,commission_base=?,commission_rate=?,commission=?,commission_afn=?,commission_currency=?,route=?,edit_count=COALESCE(edit_count,0)+1 WHERE id=?""",
                            (cid,cname,typ.get(),val,desc.get().strip(),cur.get(),rv,val*rv,cbase,cfee,comm,cafn,cur.get(),route.get(),rid))
            if cur_update.rowcount == 0:
                self.db.rollback()
                messagebox.showwarning("ویرایش رسید","این رسید قبلاً ویرایش شده است."); return
            if old_entry:
                entry_type="بستانکاری مشتری" if typ.get()=="دریافت از مشتری" else "قرضداری مشتری"
                self.db.execute("""UPDATE account_entries SET customer_id=?,customer=?,entry_type=?,amount=?,notes=?,
                                   currency=?,rate=?,afn_amount=?,commission=?,commission_afn=?,commission_currency=?,route=? WHERE id=?""",
                                (cid,cname,entry_type,val,f"رسید شماره {row[7]} - {desc.get().strip()}",
                                 cur.get(),rv,val*rv,comm,cafn,cur.get(),route.get(),old_entry[0]))
            self.db.commit()
            self._refresh_financial_views_after_change(cid)
            messagebox.showinfo("موفق","رسید با موفقیت ویرایش شد.")
            self.show_receipt_by_id(rid)
        self.button(form,"✓ ذخیره ویرایش",save_edit,"#0F766E").grid(row=4,column=0,columnspan=2,pady=18)

    def delete_receipt(self, rid):
        row=self.db.execute("SELECT receipt_no,customer,COALESCE(edit_count,0) FROM receipts WHERE id=?",(rid,)).fetchone()
        if not row:return
        if not messagebox.askyesno("حذف رسید",f"رسید شماره {row[0]} برای «{row[1]}» حذف شود؟\\nاین عمل قابل بازگشت نیست و ثبت حساب مرتبط نیز حذف می‌شود."):
            return
        self.db.execute("DELETE FROM account_entries WHERE source_type='receipt' AND source_id=?",(rid,))
        self.db.execute("DELETE FROM account_entries WHERE source_type='receipt' AND notes LIKE ?",(f"رسید شماره {row[0]}%",))
        self.db.execute("DELETE FROM receipts WHERE id=?",(rid,))
        self.db.commit()
        self._refresh_financial_views_after_change()
        messagebox.showinfo("موفق","رسید و ثبت حساب مرتبط حذف شد.")
        self.receipts_list_page()

    def export_single_receipt_xlsx(self,row):
        path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel Workbook","*.xlsx")],initialfile=f"رسید_{row[6]}.xlsx")
        if not path: return
        cur=row[7] if len(row)>7 and row[7] else "AFN - افغانی"
        rows=[(row[6],dual_datetime(row[1]),row[2],row[3],cur,row[4],row[10] if len(row)>10 else 0,row[5] or "-")]
        try:
            out=self._export_xlsx_rows(path,["شماره رسید","تاریخ","مشتری","نوع رسید","ارز","مبلغ","کمیشن","توضیحات"],rows,title=f"رسید مشتری {row[6]}",include_outgoing_profile=True)
            messagebox.showinfo("خروجی Excel",f"Excel رسید با مشخصات ارسال ذخیره شد:\n{out}")
        except Exception as e:
            messagebox.showerror("خروجی Excel",str(e))

    def save_customer_receipt(self,row):
        path=filedialog.asksaveasfilename(defaultextension=".html",filetypes=[("HTML","*.html")],initialfile="رسید_مشتری_%s.html" % row[6])
        if not path:return
        html="""<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><title>رسید</title><style>body{font-family:"B Nazanin", Tahoma, sans-serif;background:#eee;padding:40px}.r{max-width:650px;margin:auto;background:#fff;padding:35px;border-radius:14px}h1{color:#B8862F;font-weight:800}p{font-size:18px;font-weight:700;color:#B8862F;border-bottom:1px solid #ddd;padding:9px}</style><div class='r'>"""+f"<h1>{APP_NAME}</h1><p>شماره رسید: {row[6]}</p><p>تاریخ: {dual_datetime(row[1])}</p><p>مشتری: {row[2]}</p><p>نوع رسید: {row[3]}</p><p>مبلغ: {fmt_num(row[4])} {row[7] if len(row)>7 and row[7] else "AFN - افغانی"}</p><p>کمیشن: {fmt_num(row[10] if len(row)>10 else 0)} {row[7] if len(row)>7 and row[7] else "AFN - افغانی"}</p><p>توضیحات: {row[5] or '-'}</p><h3>با تشکر از اعتماد شما</h3><p>خالد رحیمی | ۰۷۹۶۲۹۷۹۹۶</p></div>"""
        with open(path,"w",encoding="utf-8") as f:f.write(html)
        webbrowser.open("file://"+os.path.abspath(path))

    def save_receipt_pdf(self,row,share=False):
        path=self._professional_pdf('رسید مشتری',f'شماره رسید: {row[6]}',
            [('شماره رسید',row[0]),('تاریخ',row[1]),('مشتری',row[2]),('نوع رسید',row[3]),('مبلغ',f'{fmt_num(row[4])} {row[7] if len(row)>7 and row[7] else "AFN - افغانی"}'),('کمیشن',f'{fmt_num(row[10] if len(row)>10 else 0)} {row[7] if len(row)>7 and row[7] else "AFN - افغانی"}'),('توضیحات',row[5] or '-')],
            filename=f'رسید_{row[6]}.pdf',include_outgoing_profile=True)
        if path:
            self._open_file(path)
            if share:self._share_pdf_menu(path,f'رسید شماره {row[6]}')
        return path

    def _receipt_share_text(self,row):
        cur=row[7] if len(row)>7 and row[7] else "AFN - افغانی"
        profile=self._outgoing_profile_text_lines()
        prefix=("\n".join(profile)+"\n—\n") if profile else ""
        return (prefix+f"*رسید شماره {row[6]}*\n"
                f"مشتری: {row[2]}\n"
                f"نوع: {row[3]}\n"
                f"مبلغ: {fmt_money_exact(row[4])} {cur}\n"
                f"کمیشن: {fmt_money_exact(row[10] if len(row)>10 else 0)} {cur}\n"
                f"تاریخ: {dual_datetime(row[1])}\n"
                + (f"توضیح: {row[5].strip()}\n" if row[5] and row[5].strip() else "")
                + "با احترام")

    def send_receipt_whatsapp(self,row):
        r=self.db.execute("SELECT phone FROM customers WHERE id=(SELECT customer_id FROM receipts WHERE id=?)",(row[0],)).fetchone()
        if not r or not r[0]: messagebox.showwarning("واتساپ","شماره تلفن مشتری ثبت نشده است."); return
        msg=self._receipt_share_text(row)
        webbrowser.open("https://wa.me/"+self.normalize_phone(r[0])+"?text="+urllib.parse.quote(msg))

    def send_receipt_telegram(self,row):
        msg=self._receipt_share_text(row)
        webbrowser.open("https://t.me/share/url?url=&text="+urllib.parse.quote(msg))

    def receipts_list_page(self):
        self.clear()
        RTLLabel(self.main,text="رسیدهای ثبت‌شده — چهار ارز",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        RTLLabel(self.main,text="هر رسید شماره یکتا دارد و مبلغ فقط با ارز اصلی ثبت‌شده نمایش داده می‌شود.",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))
        cols=("id","no","date","customer","type","amount","currency","commission","desc")
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads={"id":"معرف","no":"شماره رسید","date":"تاریخ","customer":"مشتری","type":"نوع رسید","amount":"مبلغ","currency":"ارز","commission":"کمیشن","desc":"توضیحات"}
        for x in cols:
            tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,anchor="center",width=105)
        tree.column("id",width=60); tree.column("customer",width=140); tree.column("desc",width=220)
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        q="SELECT id,receipt_no,created,customer,receipt_type,amount,COALESCE(currency,'AFN - افغانی'),COALESCE(commission,0),description FROM receipts ORDER BY receipt_no DESC"
        for r in self.db.execute(q):
            tree.insert("","end",values=(r[0],r[1],dual_datetime(r[2]),r[3],r[4],fmt_money_exact(r[5]),r[6],fmt_money_exact(r[7]),r[8] or ""))
        commission_rows=self.db.execute("SELECT COALESCE(currency,'AFN - افغانی'),COALESCE(SUM(commission),0) FROM receipts GROUP BY COALESCE(currency,'AFN - افغانی') ORDER BY currency").fetchall()
        commission_text=" | ".join(f"{fmt_money_exact(v)} {c}" for c,v in commission_rows if abs(float(v or 0))>0) or "0"
        RTLLabel(self.main,text=f"💰 جمع کل کمیشن همه رسیدها (هر ارز جداگانه): {commission_text}",bg="#F4F6F8",fg="#7C3AED",font=ui_font(10,"bold")).pack(anchor="e",padx=20,pady=(0,8))
        def open_selected():
            sel=tree.selection()
            if not sel:return
            self.show_receipt_by_id(int(tree.item(sel[0],"values")[0]))
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=8)
        self.button(bar,"👁 مشاهده / چاپ رسید انتخاب‌شده",open_selected).pack(side="right",padx=5)
        self.button(bar,"✏️ ویرایش رسید",lambda:self._receipt_action_from_tree(tree,"edit")).pack(side="right",padx=5)
        self.button(bar,"🗑 حذف رسید",lambda:self._receipt_action_from_tree(tree,"delete"),"#B42318").pack(side="right",padx=5)
        self.button(bar,"🔢 گزارش جمع بر اساس شماره",self.number_range_account_report_page,"#7c3aed").pack(side="right",padx=5)

    def _receipt_action_from_tree(self, tree, action):
        sel=tree.selection()
        if not sel:return
        rid=int(tree.item(sel[0],"values")[0])
        if action=="edit": self.edit_receipt_page(rid)
        else: self.delete_receipt(rid)

    def daily_customer_receipts_page(self):
        self.clear()
        today=date.today().strftime("%Y-%m-%d")
        RTLLabel(self.main,text="رسیدهای روزانه مشتریان",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)

        top=tk.Frame(self.main,bg="#F4F6F8"); top.pack(fill="x",padx=20)
        RTLLabel(top,text="تاریخ میلادی (YYYY-MM-DD):",bg="#F4F6F8",fg="#1B2733",font=ui_font(10)).pack(side="right",padx=5)
        d=tk.StringVar(value=today)
        tk.Entry(top,textvariable=d,width=14,bg="#FFFFFF",fg="#1B2733",insertbackground="#1B2733",relief="solid",bd=1,font=ui_font(10),justify="right").pack(side="right",padx=5)
        self.button(top,"🔎 نمایش",lambda:load()).pack(side="right",padx=5)
        self.button(top,"💾 خروجی CSV",lambda:export()).pack(side="left")

        summary=tk.Frame(self.main,bg="#F4F6F8"); summary.pack(fill="x",padx=12,pady=8)
        detail=tk.Frame(self.main,bg="#FFFFFF"); detail.pack(fill="both",expand=True,padx=20,pady=8)
        tree=None

        def money_lines(data):
            return self._currency_lines(data) if data else "0"

        def load():
            nonlocal tree
            for w in summary.winfo_children(): w.destroy()
            for w in detail.winfo_children(): w.destroy()
            day=d.get().strip().replace("/","-")
            if len(day)!=10 or day[4]!="-" or day[7]!="-":
                messagebox.showwarning("تاریخ","تاریخ را به شکل YYYY-MM-DD وارد کنید."); return
            d.set(day)
            c=self.db.cursor()
            entries=c.execute("""SELECT created,customer,entry_type,COALESCE(currency,'AFN - افغانی'),amount,
                                      COALESCE(rate,1),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END,COALESCE(commission,0),notes
                               FROM account_entries WHERE created LIKE ? ORDER BY id ASC""",(day+"%",)).fetchall()
            trades=c.execute("""SELECT created,customer,kind,COALESCE(currency,'AFN - افغانی'),amount,
                                      COALESCE(rate,1),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END,notes
                               FROM transactions WHERE created LIKE ? ORDER BY id ASC""",(day+"%",)).fetchall()

            debt={}; credit={}; buy={}; sell={}; customers=set()
            for created,name,typ,cur,amt,rate,afn,comm,notes in entries:
                cur=cur or 'AFN - افغانی'; customers.add(name) if name else None
                if typ=='قرضداری مشتری': debt[cur]=debt.get(cur,D(0))+D(amt)
                elif typ=='بستانکاری مشتری': credit[cur]=credit.get(cur,D(0))+D(amt)
            commission_by_currency={}
            commission_total=D(0)
            for created,name,typ,cur,amt,rate,afn,comm,notes in entries:
                cur=cur or 'AFN - افغانی'; commission_by_currency[cur]=commission_by_currency.get(cur,D(0))+D(comm); commission_total += D(comm)
            for created,name,kind,cur,amt,rate,afn,notes in trades:
                cur=cur or 'AFN - افغانی'; customers.add(name) if name else None
                if kind=='خرید': buy[cur]=buy.get(cur,D(0))+D(amt)
                elif kind=='فروش': sell[cur]=sell.get(cur,D(0))+D(amt)

            all_currencies=sorted(set(debt)|set(credit)|set(buy)|set(sell))
            def afn_total(data):
                return sum(D(v)*D(self.get_rate_to_afn(k) or 1) for k,v in data.items())
            debt_afn=afn_total(debt); credit_afn=afn_total(credit)
            buy_afn=afn_total(buy); sell_afn=afn_total(sell)
            record_count=len(entries)+len(trades)

            for i in range(5): summary.columnconfigure(i,weight=1)
            self.card(summary,"تعداد مشتریان",str(len(customers)),0,0)
            self.card(summary,"تعداد رسید / ثبت",str(record_count),0,1)
            self.card(summary,"قرضداری — ارز اصلی",money_lines(debt),0,2)
            self.card(summary,"بستانکاری — ارز اصلی",money_lines(credit),0,3)
            self.card(summary,"خرید ارزی — ارز اصلی",money_lines(buy),1,0)
            self.card(summary,"فروش ارزی — ارز اصلی",money_lines(sell),1,1)
            self.card(summary,"گردش اصلی روز",money_lines({k:(D(0)+debt.get(k,D(0))+credit.get(k,D(0))+buy.get(k,D(0))+sell.get(k,D(0))) for k in all_currencies}),1,2)
            self.card(summary,"جمع کل کمیشن",money_lines(commission_by_currency),1,3)

            RTLLabel(detail,text=f"جزئیات کامل رسیدهای مشتریان — {day} | مبلغ اصلی هر ارز",
                     bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=8)
            cols=("time","customer","section","type","currency","amount","commission","notes")
            tree=ttk.Treeview(detail,columns=cols,show="headings", style="Jahan.Treeview")
            heads={"time":"زمان","customer":"مشتری","section":"بخش","type":"نوع","currency":"ارز",
                   "amount":"مبلغ اصلی","commission":"کمیشن","notes":"توضیحات"}
            for x in cols:
                tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings=heads; tree.column(x,width=105,anchor="center")
            tree.column("customer",width=150); tree.column("notes",width=200)
            self._pack_with_scrollbar(tree,fill="both",expand=True,padx=10,pady=5)

            combined=[]
            for r in entries: combined.append((r[0],r[1],"حساب مشتری",r[2],r[3],r[4],r[7],r[8] or "-"))
            for r in trades: combined.append((r[0],r[1],"معامله ارزی",r[2],r[3],r[4],D(0),r[7] or "-"))
            combined.sort(key=lambda x:x[0])
            for r in combined:
                tree.insert("","end",values=(dual_datetime(r[0]),r[1],r[2],r[3],r[4],fmt_money_exact(r[5]),fmt_money_exact(r[6]),r[7]))
            if not combined:
                RTLLabel(detail,text="برای این تاریخ رسید یا ثبت حساب مشتری وجود ندارد.",bg="#FFFFFF",fg="#687582",font=ui_font(11)).pack(pady=25)

        def export():
            day=d.get().strip().replace("/","-")
            path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel Workbook","*.xlsx")],initialfile=f"رسیدهای_مشتریان_{day}.xlsx")
            if not path:return
            rows=self.db.execute("""SELECT created,customer,'حساب مشتری',entry_type,COALESCE(currency,'AFN - افغانی'),amount,COALESCE(rate,1),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END,notes
                                   FROM account_entries WHERE created LIKE ?
                                   UNION ALL
                                   SELECT created,customer,'معامله ارزی',kind,COALESCE(currency,'AFN - افغانی'),amount,COALESCE(rate,1),CASE WHEN afn_amount IS NULL OR afn_amount=0 THEN amount*COALESCE(rate,1) ELSE afn_amount END,notes
                                   FROM transactions WHERE created LIKE ? ORDER BY created""",(day+"%",day+"%")).fetchall()
            try:
                out=self._export_xlsx_rows(path,["زمان","مشتری","بخش","نوع","ارز","مبلغ اصلی","توضیحات"],[(r[0],r[1],r[2],r[3],r[4],r[5],r[8]) for r in rows],title=f"رسیدهای مشتریان - {day}",include_outgoing_profile=True)
                messagebox.showinfo("خروجی Excel",f"رسیدهای روزانه با قالب حرفه‌ای ذخیره شد:\n{out}")
            except Exception as e:
                messagebox.showerror("خروجی Excel",str(e))

        load()

    def monthly_report_page(self):
        self.clear()
        jy,jm,jd=current_jalali_parts()
        RTLLabel(self.main,text="گزارش ماهانه",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        bar=tk.Frame(self.main,bg="#F4F6F8");bar.pack(fill="x",padx=20,pady=5)
        month=tk.StringVar(value=str(jm));year=tk.StringVar(value=str(jy))
        RTLLabel(bar,text="ماه:",bg="#F4F6F8",fg="#1B2733").pack(side="right",padx=5)
        month_box=ttk.Combobox(bar,textvariable=month,values=tuple(f"{i} - {name}" for i,name in enumerate(JALALI_MONTHS_AF,1)),state="readonly",width=17,justify="right")
        month_box.pack(side="right",padx=4)
        month_box.set(f"{jm} - {jalali_month_name(jm)}")
        RTLLabel(bar,text="سال هجری شمسی افغانستان:",bg="#F4F6F8",fg="#1B2733").pack(side="right",padx=5)
        tk.Entry(bar,textvariable=year,width=8,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,justify="right").pack(side="right",padx=4)
        box=tk.Frame(self.main,bg="#F4F6F8");box.pack(fill="both",expand=True,padx=12,pady=10)
        def run():
            try:
                y=int(year.get())
                raw=month.get().strip()
                m=int(raw.split("-",1)[0].strip())
                start_j=_jalali_to_gregorian(y,m,1)
                next_j=_jalali_to_gregorian(y+1,1,1) if m==12 else _jalali_to_gregorian(y,m+1,1)
            except Exception:
                messagebox.showerror("گزارش ماهانه","سال و ماه افغانستان را درست انتخاب کنید.");return
            start_s=start_j.strftime("%Y-%m-%d"); next_s=next_j.strftime("%Y-%m-%d")
            where="created >= ? AND created < ?"; params=(start_s,next_s)
            c=self.db.cursor();rows,trades,shops=self._period_full_currency_summary(where,params);pnl=self._period_profit_loss(where,params);count=int(c.execute("SELECT COUNT(*) FROM transactions WHERE "+where,params).fetchone()[0] or 0);bcount=int(c.execute("SELECT COUNT(*) FROM business_transactions WHERE "+where,params).fetchone()[0] or 0)
            for w in box.winfo_children():w.destroy()
            for i in range(4):box.columnconfigure(i,weight=1)
            profit,loss=self._profit_loss_total_text(pnl)
            cards=[("تعداد معاملات ارزی",str(count)),("خرید — هر ارز جدا",self._report_currency_text(trades,'خرید','فروش')), ("فروش — هر ارز جدا",self._report_currency_text({k:(v[1],v[1],v[3],v[3]) for k,v in trades.items()},'فروش','') if trades else "0"),("تعداد خرید/فروش کالا",str(bcount)),("سود / زیان ماه",self._profit_loss_text(pnl)),("مجموع سود ماه",profit),("مجموع زیان ماه",loss),("قرضداری / بستانکاری",self._report_currency_text(rows,'قرضداری','بستانکاری'))]
            for i,(title,val) in enumerate(cards):self.card(box,title,val,i//4,i%4)
            detail=tk.Frame(box,bg="#FFFFFF");detail.grid(row=2,column=0,columnspan=4,sticky="nsew",padx=8,pady=12);RTLLabel(detail,text=f"جزئیات {jalali_month_name(m)} {y} — مبلغ واقعی هر ارز و سود/زیان",bg="#FFFFFF",fg="#35a9ff",font=ui_font(13,"bold")).pack(anchor="e",padx=15,pady=8)
            cols=("date","category","type","name","currency","amount","notes");tree=ttk.Treeview(detail,columns=cols,show="headings", style="Jahan.Treeview");heads={"date":"تاریخ","category":"بخش","type":"نوع","name":"مشتری / مغازه","currency":"ارز","amount":"مبلغ اصلی","notes":"توضیحات"}
            for x in cols:tree.heading(x,text=_display_text(heads[x]));tree._jahan_original_headings=heads;tree.column(x,width=125,anchor="center")
            tree.column("name",width=160);tree.column("notes",width=220);self._pack_with_scrollbar(tree,fill="both",expand=True,padx=10,pady=5)
            queries=[
                ("معامله ارزی","SELECT created,kind,customer,COALESCE(currency,'AFN - افغانی'),amount,notes FROM transactions WHERE created >= ? AND created < ? ORDER BY id DESC"),
                ("حساب مشتری","SELECT created,entry_type,customer,COALESCE(currency,'AFN - افغانی'),amount,notes FROM account_entries WHERE created >= ? AND created < ? ORDER BY id DESC"),
                ("دکان","SELECT created,kind,business_name,COALESCE(currency,'AFN - افغانی'),amount,notes FROM business_transactions WHERE created >= ? AND created < ? ORDER BY id DESC")]
            for cat,q in queries:
                for r in c.execute(q,(start_s,next_s)):tree.insert("","end",values=(dual_datetime(r[0]),cat,r[1],r[2] or "-",r[3],fmt_money_exact(r[4]),r[5] or "-"))
            box.grid_rowconfigure(2,weight=1)
        self.button(bar,"🔎 نمایش گزارش",run).pack(side="right",padx=8);run()

    def fruits_sales_page(self):
        self.clear()
        RTLLabel(self.main,text="فاکتور فروش",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20)
        self.button(bar,"＋ فاکتور فروش جدید",self.add_fruit_sale).pack(side="left")
        self.button(bar,"🧾 فاکتورها",self.invoices_page,"#475569").pack(side="left",padx=8)
        self.button(bar,"🍎 موجودی",self.fruits_page,"#0f766e").pack(side="left",padx=8)
        cols=("id","date","customer","fruit","unit","qty","total")
        action_bar=tk.Frame(self.main,bg="#F4F6F8"); action_bar.pack(fill="x",padx=20,pady=(4,6))
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads={"id":"فاکتور","date":"تاریخ","customer":"مشتری","fruit":"میوه","unit":"واحد","qty":"مقدار","total":"مجموع"}
        for x in cols: tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,width=130,anchor="center")
        tree.column("customer",width=180)
        fruit_holder=tk.Frame(self.main,bg="#F4F6F8"); fruit_holder.pack(fill="both",expand=True,padx=20,pady=10)
        fruit_bar=tk.Scrollbar(fruit_holder,orient="vertical",command=tree.yview,width=14); tree.configure(yscrollcommand=fruit_bar.set)
        tree.pack(side="left",fill="both",expand=True); fruit_bar.pack(side="right",fill="y")
        for r in self.db.execute("SELECT i.id,i.created,i.customer,it.fruit_name,it.unit,it.quantity,it.total FROM invoices i JOIN invoice_items it ON it.invoice_id=i.id ORDER BY i.id DESC"):
            tree.insert("","end",values=(f"{r[0]}",r[1],r[2],r[3],r[4],f"{fmt_num(r[5])}",f"{fmt_num(r[6])}"))
        self.button(action_bar,"🖨 چاپ فاکتور انتخاب‌شده",lambda:self.print_invoice_from_tree(tree)).pack(side="right",padx=4)
        self.button(action_bar,"📋 مرکز کامل فاکتورها",self.shops_invoice_center_page,"#2D7FA3").pack(side="right",padx=4)

    def add_fruit_sale(self):
        fruits=self.db.execute("SELECT id,fruit_name,quantity_kg,unit_price FROM fruit_inventory ORDER BY fruit_name").fetchall()
        customers=self.db.execute("SELECT id,name FROM customers ORDER BY name").fetchall()
        if not fruits: messagebox.showwarning("فروش میوه","ابتدا موجودی میوه را ثبت کنید."); return
        win=tk.Toplevel(self); win.title("فروش میوه / فاکتور"); win.geometry("500x560"); win.configure(bg="#F4F6F8")
        def lab(t): RTLLabel(win,text=t,bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=20,pady=(10,3))
        lab("مشتری (اختیاری)"); cust=LocalizedCombobox(win,values=[f"{i} - {n}" for i,n in customers],state="readonly"); cust.pack(fill="x",padx=20)
        lab("میوه"); fruit=LocalizedCombobox(win,values=[f"{i} - {n} | موجودی {fmt_num(q)} کیلو" for i,n,q,p in fruits],state="readonly"); fruit.pack(fill="x",padx=20)
        lab("واحد فروش"); unit=LocalizedCombobox(win,values=["کیلوگرم","تن"],state="readonly"); unit.pack(fill="x",padx=20); unit.current(0)
        lab("مقدار"); qty=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); qty.pack(fill="x",padx=20)
        lab("قیمت واحد"); price=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); price.pack(fill="x",padx=20)
        RTLLabel(win,text="کیلو: قیمت هر کیلو | تن: قیمت هر تن",bg="#F4F6F8",fg="#687582").pack(anchor="e",padx=20,pady=4)
        lab("توضیحات"); notes=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); notes.pack(fill="x",padx=20)
        total=RTLLabel(win,text="مجموع: 0 افغانی",bg="#F4F6F8",fg="#35a9ff",font=ui_font(13,"bold")); total.pack(pady=10)
        def defaults(*_):
            if fruit.current()>=0:
                pp=fruits[fruit.current()][3]; price.delete(0,"end"); price.insert(0,str(pp*1000 if unit.get()=="تن" else pp))
        fruit.bind("<<ComboboxSelected>>",defaults); unit.bind("<<ComboboxSelected>>",defaults)
        def calc(*_):
            try: total.config(text=f"مجموع: {fmt_num(float(D(qty.get()))*float(D(price.get())))} افغانی")
            except: total.config(text="مجموع: 0 افغانی")
        qty.bind("<KeyRelease>",calc); price.bind("<KeyRelease>",calc)
        def save():
            if fruit.current()<0: messagebox.showwarning("خطا","میوه را انتخاب کنید."); return
            try: q=float(D(qty.get())); p=float(D(price.get()))
            except: messagebox.showerror("خطا","مقدار و قیمت باید عددی باشد."); return
            if q<=0 or p<0: messagebox.showerror("خطا","مقدار نامعتبر است."); return
            fid,fname,stock,dp=fruits[fruit.current()]; qkg=q if unit.get()=="کیلوگرم" else q*1000
            if qkg>stock: messagebox.showerror("موجودی ناکافی",f"موجودی {fname}: {fmt_num(stock)} کیلو است."); return
            totalval=q*p; cid=None; cname="فروش نقدی"; phone=""
            if cust.current()>=0:
                cid,cname=customers[cust.current()]; phone=(self.db.execute("SELECT phone FROM customers WHERE id=?",(cid,)).fetchone() or [""])[0]
            now=datetime.now().strftime("%Y-%m-%d %H:%M"); cur=self.db.cursor()
            cur.execute("INSERT INTO invoices(created,customer_id,customer,phone,notes,total) VALUES(?,?,?,?,?,?)",(now,cid,cname,phone,notes.get().strip(),totalval)); iid=cur.lastrowid
            cur.execute("INSERT INTO invoice_items(invoice_id,fruit_name,unit,quantity,quantity_kg,unit_price,total) VALUES(?,?,?,?,?,?,?)",(iid,fname,unit.get(),q,qkg,p,totalval))
            cur.execute("UPDATE fruit_inventory SET quantity_kg=quantity_kg-?,updated=? WHERE id=?",(qkg,now,fid))
            if cid: cur.execute("INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes) VALUES(?,?,?,?,?,?)",(now,cid,cname,"بستانکاری مشتری",totalval,f"فاکتور میوه #{iid}"))
            self.db.commit(); win.destroy(); self.show_invoice(iid)
        self.button(win,"✓ ثبت فروش و صدور فاکتور",save).pack(side="bottom",pady=15)

    def invoices_page(self):
        return self.shops_invoice_center_page()

    def _legacy_invoices_page(self):
        self.clear(); RTLLabel(self.main,text="فاکتورهای قدیمی میوه",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        action_bar=tk.Frame(self.main,bg="#F4F6F8"); action_bar.pack(fill="x",padx=20,pady=(4,6))
        cols=("id","date","customer","total"); tree=ttk.Treeview(self.main,columns=cols,show="headings")
        for x,h in [("id","شماره"),("date","تاریخ"),("customer","مشتری"),("total","مبلغ کل")]: tree.heading(x,text=_icu_shape_arabic(h)); tree.column(x,width=170,anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        for r in self.db.execute("SELECT id,created,customer,total FROM invoices ORDER BY id DESC"): tree.insert("","end",values=(f"{r[0]}",dual_datetime(r[1]),r[2],f"{fmt_num(r[3])}"))
        def op():
            sel=tree.selection()
            if sel:self.show_invoice(int(tree.item(sel[0],"values")[0]))
        self.button(action_bar,"👁 مشاهده / چاپ",op).pack(side="right",padx=4)
        self.button(action_bar,"↩ بازگشت به دکان‌ها",self.businesses_page,"#475569").pack(side="left",padx=4)

    def print_invoice_from_tree(self,tree):
        sel=tree.selection()
        if sel:self.show_invoice(int(tree.item(sel[0],"values")[0]))
        else: messagebox.showwarning("فاکتور","یک فاکتور را انتخاب کنید.")

    def show_invoice(self,iid):
        row=self.db.execute("SELECT id,created,customer,phone,notes,total FROM invoices WHERE id=?",(iid,)).fetchone(); items=self.db.execute("SELECT fruit_name,unit,quantity,unit_price,total FROM invoice_items WHERE invoice_id=?",(iid,)).fetchall()
        if not row:return
        self.clear(); RTLLabel(self.main,text="فاکتور فروش",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        box=tk.Frame(self.main,bg="white"); box.pack(fill="both",expand=True,padx=70,pady=10)
        text=[APP_NAME,"فاکتور فروش میوه",f"شماره فاکتور: {row[0]}",f"تاریخ شمسی: {dual_datetime(row[1])}",f"مشتری: {row[2]}",f"تماس: {row[3] or '-'}","--------------------------------"]
        text += [f"{f} | {fmt_num(q)} {u} | قیمت: {fmt_num(p)} | جمع: {fmt_num(t)} افغانی" for f,u,q,p,t in items]
        text += ["--------------------------------",f"مبلغ کل: {fmt_num(row[5])} افغانی",f"توضیحات: {row[4] or '-'}","با تشکر از اعتماد شما","خالد رحیمی | ۰۷۹۶۲۹۷۹۹۶"]
        invoice_text=tk.Text(box,bg="white",fg="#17202a",font=ui_font(12),wrap="word",relief="solid",bd=1,highlightthickness=1,highlightbackground="#D8DEE4",padx=20,pady=18)
        invoice_text.insert("1.0","\n".join(text)); invoice_text.configure(state="disabled")
        invoice_text.pack(side="left",fill="both",expand=True,padx=(30,0),pady=25)
        invoice_scroll=tk.Scrollbar(box,orient="vertical",command=invoice_text.yview,width=14); invoice_text.configure(yscrollcommand=invoice_scroll.set)
        invoice_scroll.pack(side="right",fill="y",padx=(0,30),pady=25)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=8)
        self.button(bar,"👁 پیش‌نمایش چاپ",lambda:self._preview_invoice(row,items),"#2D7FA3").pack(side="right",padx=3)
        self.button(bar,"🖨 چاپ مستقیم",lambda:self._print_pdf_file(self._make_invoice_pdf_temp(row,items)),"#B58E45").pack(side="right",padx=3)
        self.button(bar,"📄 PDF حرفه‌ای",lambda:self.save_invoice_pdf(row,items)).pack(side="right",padx=3)
        self.button(bar,"📱 ارسال PDF",lambda:self.send_invoice_pdf(row,items)).pack(side="right",padx=3)
        self.button(bar,"↩ برگشت",self.fruits_sales_page,"#475569").pack(side="left")

    def _pdf_text(self, text):
        text=str(text or '')
        if ARABIC_SHAPING_OK:
            return get_display(arabic_reshaper.reshape(text))
        return text

    def _pdf_font(self):
        candidates=[]
        if getattr(sys,'frozen',False):
            candidates += [os.path.join(RESOURCE_BASE,'assets','fonts','NotoSansArabic-Regular.ttf'), os.path.join(BASE,'assets','fonts','NotoSansArabic-Regular.ttf')]
        candidates += [os.path.join(BASE,'assets','fonts','NotoSansArabic-Regular.ttf'), r'C:\\Windows\\Fonts\\tahoma.ttf', '/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf']
        for path in candidates:
            if os.path.exists(path):
                try:
                    pdfmetrics.registerFont(TTFont('JahanArabic',path))
                    return 'JahanArabic'
                except Exception: pass
        return 'Helvetica'

    def _open_file(self,path):
        try:
            if sys.platform.startswith('win'):
                os.startfile(path)
            elif sys.platform=='darwin':
                subprocess.run(['open',path],check=False)
            else:
                subprocess.run(['xdg-open',path],check=False)
        except Exception:
            webbrowser.open('file://'+os.path.abspath(path))

    def _professional_pdf(self, title, subtitle, fields, table_headers=None, table_rows=None, total_text=None, filename='گزارش.pdf', target_path=None, include_outgoing_profile=False):
        if not REPORTLAB_OK:
            messagebox.showerror('PDF','کتابخانه PDF در این نسخه نصب نیست.\nدر Windows یک‌بار build_exe.bat را اجرا کنید.')
            return None
        path=target_path or filedialog.asksaveasfilename(defaultextension='.pdf',filetypes=[('PDF','*.pdf')],initialfile=filename)
        if not path:return None
        font=self._pdf_font()
        doc=SimpleDocTemplate(path,pagesize=A4,rightMargin=34,leftMargin=34,topMargin=36,bottomMargin=36,title=title,author='Jahan Accounting')
        styles=getSampleStyleSheet()
        title_style=ParagraphStyle('JTitle',parent=styles['Title'],fontName=font,fontSize=20,leading=28,alignment=TA_RIGHT,textColor=colors.HexColor('#1B2733'),spaceAfter=5)
        sub_style=ParagraphStyle('JSub',parent=styles['Normal'],fontName=font,fontSize=11.5,leading=19,alignment=TA_RIGHT,textColor=colors.HexColor('#687582'),spaceAfter=12)
        body_style=ParagraphStyle('JBody',parent=styles['Normal'],fontName=font,fontSize=9,leading=15,alignment=TA_RIGHT,textColor=colors.HexColor('#1B2733'))
        center_style=ParagraphStyle('JCenter',parent=body_style,alignment=TA_CENTER)
        story=[]
        logo_path=os.path.join(RESOURCE_BASE,'logo.png')
        if not os.path.exists(logo_path): logo_path=os.path.join(BASE,'logo.png')
        if os.path.exists(logo_path):
            try:
                logo=Image(logo_path,width=105,height=58)
                logo.hAlign='CENTER'
                story.append(logo)
                story.append(Spacer(1,6))
            except Exception:
                pass
        if include_outgoing_profile:
            op=self._outgoing_profile_dict()
            if op.get("outgoing_name"):
                story.append(Paragraph(self._pdf_text(op["outgoing_name"]),title_style))
                meta=" | ".join(x for x in (op.get("outgoing_type"),op.get("outgoing_phone"),op.get("outgoing_address")) if x)
                if meta: story.append(Paragraph(self._pdf_text(meta),sub_style))
                if op.get("outgoing_notes"): story.append(Paragraph(self._pdf_text(op["outgoing_notes"]),sub_style))
        story += [Paragraph(self._pdf_text(title),title_style),Paragraph(self._pdf_text(subtitle),sub_style)]
        info=[]
        for k,v in fields:
            info.append([Paragraph(self._pdf_text(k),body_style),Paragraph(self._pdf_text(v),body_style)])
        if info:
            t=Table(info,colWidths=[120,370],hAlign='RIGHT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),colors.HexColor('#F5F7F9')),('BOX',(0,0),(-1,-1),0.6,colors.HexColor('#D8DEE4')),('INNERGRID',(0,0),(-1,-1),0.35,colors.HexColor('#E5E7EB')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('RIGHTPADDING',(0,0),(-1,-1),8),('LEFTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
            story += [t,Spacer(1,14)]
        if table_headers:
            data=[[Paragraph(self._pdf_text(h),center_style) for h in table_headers]]
            for r in table_rows or []:
                data.append([Paragraph(self._pdf_text(x),center_style) for x in r])
            tt=Table(data,repeatRows=1,colWidths=None,hAlign='RIGHT')
            tt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#1B2733')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),0.5,colors.HexColor('#CBD5E1')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
            story += [tt,Spacer(1,14)]
        if total_text:
            story.append(Paragraph(self._pdf_text(total_text),ParagraphStyle('Total',parent=body_style,fontSize=14,leading=20,alignment=TA_RIGHT,textColor=colors.HexColor('#B58E45'),spaceBefore=4,spaceAfter=12)))
        story += [Spacer(1,18),Paragraph(self._pdf_text('با تشکر از اعتماد شما'),body_style)]
        if include_outgoing_profile:
            op=self._outgoing_profile_dict()
            footer=" | ".join(x for x in (op.get("outgoing_name"),op.get("outgoing_phone"),op.get("outgoing_address")) if x)
            if footer: story.append(Paragraph(self._pdf_text(footer),body_style))
        else:
            story.append(Paragraph(self._pdf_text('خالد رحیمی | ۰۷۹۶۲۹۷۹۹۶'),body_style))
        doc.build(story)
        return path

    def _make_invoice_pdf_temp(self, row, items):
        fd, path = tempfile.mkstemp(prefix=f"jahan_invoice_{row[0]}_", suffix=".pdf")
        os.close(fd)
        rows=[[f,u,f'{fmt_num(q)}',f'{fmt_num(p)}',f'{fmt_num(t)}'] for f,u,q,p,t in items]
        return self._professional_pdf('فاکتور فروش میوه',f'شماره فاکتور: {row[0]}',
            [('شماره فاکتور',row[0]),('تاریخ',row[1]),('مشتری',row[2]),('تماس',row[3] or '-')],
            ['میوه','واحد','مقدار','قیمت واحد','جمع'],rows,f'مبلغ کل: {fmt_num(row[5])} افغانی',
            f'فاکتور_{row[0]}.pdf',target_path=path)

    def _print_pdf_file(self, path):
        if not path or not os.path.exists(path):
            messagebox.showerror('چاپ','فایل PDF برای چاپ پیدا نشد.')
            return False
        try:
            if sys.platform.startswith('win'):
                os.startfile(os.path.abspath(path), 'print')
            elif shutil.which('lp'):
                subprocess.Popen(['lp', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif shutil.which('lpr'):
                subprocess.Popen(['lpr', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                self._open_file(path)
                messagebox.showinfo('چاپ','PDF باز شد. از گزینه Print در برنامه نمایش‌دهنده PDF چاپ کنید.')
                return False
            return True
        except Exception as exc:
            self._open_file(path)
            messagebox.showwarning('چاپ',f'ارسال مستقیم به چاپگر انجام نشد؛ PDF باز شد.\n{exc}')
            return False

    def _preview_invoice(self, row, items):
        path=self._make_invoice_pdf_temp(row,items)
        if not path:
            return
        win=tk.Toplevel(self); win.title(f'پیش‌نمایش فاکتور شماره {row[0]}'); win.geometry('560x260'); win.configure(bg='#F4F6F8')
        RTLLabel(win,text='پیش‌نمایش چاپ فاکتور',bg='#F4F6F8',fg='#1B2733',font=ui_font(17,'bold')).pack(pady=(18,8))
        RTLLabel(win,text=f'فاکتور شماره {row[0]} آماده چاپ است.\nPDF در برنامه پیش‌فرض سیستم باز می‌شود و می‌توانید قبل از چاپ آن را بررسی کنید.',bg='#F4F6F8',fg='#687582',font=ui_font(11),justify='center').pack(pady=8)
        bar=tk.Frame(win,bg='#F4F6F8'); bar.pack(pady=15)
        self.button(bar,'👁 باز کردن پیش‌نمایش',lambda:self._open_file(path),'#2D7FA3').pack(side='right',padx=5)
        self.button(bar,'🖨 چاپ مستقیم',lambda:self._print_pdf_file(path),'#B58E45').pack(side='right',padx=5)
        self.button(bar,'📁 ذخیره PDF',lambda:self._copy_pdf_to_user(path,row[0],win),'#475569').pack(side='left',padx=5)
        self.button(bar,'بستن',win.destroy,'#687582').pack(side='left',padx=5)
        self.after(150,lambda:self._open_file(path))

    def _copy_pdf_to_user(self, path, invoice_no, win=None):
        dest=filedialog.asksaveasfilename(defaultextension='.pdf',filetypes=[('PDF','*.pdf')],initialfile=f'فاکتور_{invoice_no}.pdf')
        if not dest:return
        try:
            shutil.copy2(path,dest)
            if win: win.destroy()
            self._open_file(dest)
        except Exception as exc:
            messagebox.showerror('ذخیره PDF',f'ذخیره فایل انجام نشد.\n{exc}')

    def save_invoice_pdf(self,row,items,open_after=True):
        rows=[[f,u,f'{fmt_num(q)}',f'{fmt_num(p)}',f'{fmt_num(t)}'] for f,u,q,p,t in items]
        path=self._professional_pdf('فاکتور فروش میوه',f'شماره فاکتور: {row[0]}',
            [('شماره فاکتور',row[0]),('تاریخ',row[1]),('مشتری',row[2]),('تماس',row[3] or '-')],
            ['میوه','واحد','مقدار','قیمت واحد','جمع'],rows,f'مبلغ کل: {fmt_num(row[5])} افغانی',f'فاکتور_{row[0]}.pdf')
        if path and open_after:self._open_file(path)
        return path

    def send_invoice_pdf(self,row,items):
        path=self.save_invoice_pdf(row,items,open_after=True)
        if not path:return
        self._share_pdf_menu(path, f'فاکتور شماره {row[0]}')

    def _share_pdf_menu(self,path,caption):
        win=tk.Toplevel(self); win.title('ارسال PDF'); win.geometry('430x240'); win.configure(bg='#F4F6F8')
        RTLLabel(win,text='PDF حرفه‌ای آماده شد',bg='#F4F6F8',fg='#1B2733',font=('Tahoma',14,'bold')).pack(pady=(22,8))
        RTLLabel(win,text=os.path.basename(path),bg='#F4F6F8',fg='#687582',font=('Tahoma',9),wraplength=380).pack(pady=5)
        RTLLabel(win,text='واتساپ و تلگرام فایل محلی را مستقیماً از لینک وب پیوست نمی‌کنند؛\nپس از باز شدن برنامه، PDF را از همین مسیر Attach/Send کنید.',bg='#F4F6F8',fg='#687582',font=('Tahoma',9),justify='center').pack(pady=8)
        bar=tk.Frame(win,bg='#F4F6F8'); bar.pack(pady=10)
        self.button(bar,'📱 باز کردن واتساپ',lambda:(webbrowser.open('https://web.whatsapp.com/'),win.destroy()),'#128c7e').pack(side='right',padx=4)
        self.button(bar,'✈ باز کردن تلگرام',lambda:(webbrowser.open('https://web.telegram.org/'),win.destroy()),'#229ed9').pack(side='right',padx=4)
        self.button(bar,'📁 باز کردن پوشه',lambda:self._open_file(os.path.dirname(path)),'#475569').pack(side='left',padx=4)

    def save_invoice_html(self,row,items):
        path=filedialog.asksaveasfilename(defaultextension=".html",filetypes=[("HTML","*.html")],initialfile=f"فاکتور_{row[0]}.html")
        if not path:return
        rows="".join(f"<tr><td>{f}</td><td>{fmt_num(q)} {u}</td><td>{fmt_num(p)}</td><td>{fmt_num(t)}</td></tr>" for f,u,q,p,t in items)
        html="""<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>فاکتور %s</title><style>body{font-family:"B Nazanin", Tahoma, sans-serif;background:#eee;padding:30px}.invoice{max-width:850px;margin:auto;background:#fff;padding:35px}table{width:100%%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:12px;text-align:center}.total{font-size:22px;font-weight:bold}</style><div class="invoice"><h1>%s</h1><h2>فاکتور فروش میوه</h2><p>شماره: %s</p><p>تاریخ: %s</p><p>مشتری: %s</p><p>تماس: %s</p><table><tr><th>میوه</th><th>مقدار</th><th>قیمت واحد</th><th>جمع</th></tr>%s</table><p class="total">مبلغ کل: %s افغانی</p><p>توضیحات: %s</p><hr><p>با تشکر از اعتماد شما</p><p>خالد رحیمی | ۰۷۹۶۲۹۷۹۹۶</p></div></html>""" % (row[0],APP_NAME,row[0],row[1],row[2],row[3] or '-',rows,f"{fmt_num(row[5])}",row[4] or '-')
        open(path,"w",encoding="utf-8").write(html); webbrowser.open(path)

    ELECTRONICS_ITEMS = [
        "موبایل","تبلت","لپ‌تاپ","کامپیوتر رومیزی","مانیتور","تلویزیون","گیرنده دیجیتال",
        "مودم","روتر","سوئیچ شبکه","کارت حافظه","فلش مموری","هارد اکسترنال","SSD","کابل USB",
        "شارژر موبایل","کابل شارژ","پاوربانک","باتری","هدفون","هندزفری","اسپیکر","میکروفون",
        "دوربین مداربسته","DVR","NVR","کابل شبکه","کابل HDMI","کابل VGA","تبدیل برق","سه‌راهی برق",
        "لامپ LED","چراغ اضطراری","کنترل تلویزیون","ماوس","کیبورد","وب‌کم","پرینتر","تونر پرینتر",
        "اسکنر","پروژکتور","فلش‌گیر","محافظ برق","آداپتور","منبع تغذیه","فن کامپیوتر","کارت شبکه",
        "بلوتوث دانگل","گیرنده وای‌فای","کنسول بازی","دسته بازی","بازی دیجیتال","ساعت هوشمند","مچ‌بند هوشمند",
        "شارژر فندکی","هولدر موبایل","مبدل OTG","رابط صوتی","کابل AUX","رادیو","پخش‌کننده موسیقی"
    ]
    MEDICINE_ITEMS = [
        "استامینوفن (Acetaminophen)","ایبوپروفن (Ibuprofen)","ناپروکسن (Naproxen)","آسپرین (Aspirin)",
        "آموکسی‌سیلین (Amoxicillin)","آموکسی‌سیلین/کلاوولانیک اسید (Amoxicillin/Clavulanate)","آزیترومایسین (Azithromycin)",
        "سیپروفلوکساسین (Ciprofloxacin)","داکسی‌سایکلین (Doxycycline)","مترونیدازول (Metronidazole)",
        "سفالکسین (Cephalexin)","سفیکسیم (Cefixime)","لوراتادین (Loratadine)","سیتریزین (Cetirizine)",
        "فکسوفنادین (Fexofenadine)","امپرازول (Omeprazole)","پانتوپرازول (Pantoprazole)","فاموتیدین (Famotidine)",
        "متفورمین (Metformin)","گلی‌مپیرید (Glimepiride)","انسولین (Insulin)","آملودیپین (Amlodipine)",
        "لوزارتان (Losartan)","کاپتوپریل (Captopril)","آتورواستاتین (Atorvastatin)","روزوواستاتین (Rosuvastatin)",
        "لووتیروکسین (Levothyroxine)","پردنیزولون (Prednisolone)","هیدروکورتیزون (Hydrocortisone)",
        "دیکلوفناک (Diclofenac)","ملوکسیکام (Meloxicam)","آموکسی‌سیلین سوسپانسیون","ORS محلول خوراکی",
        "شربت سرفه","گایافنزین (Guaifenesin)","دکسترومتورفان (Dextromethorphan)","سالبوتامول (Albuterol)",
        "اسپری بینی اکسیمتازولین (Oxymetazoline)","کرم هیدروکورتیزون","کرم کلوتریمازول (Clotrimazole)",
        "مترونیدازول موضعی","بتادین (Povidone-Iodine)","کلرهگزیدین (Chlorhexidine)","ویتامین C","ویتامین D3",
        "ویتامین B کمپلکس","فولیک اسید","آهن","کلسیم","منیزیم","زینک (Zinc)","مولتی‌ویتامین",
        "کلاریترومایسین (Clarithromycin)","لووفلوکساسین (Levofloxacin)","سفوروکسیم (Cefuroxime)","سفتریاکسون (Ceftriaxone)",
        "کوتریموکسازول (Co-trimoxazole)","فلوکونازول (Fluconazole)","آسیکلوویر (Acyclovir)","کرم تربینافین (Terbinafine)",
        "کرم میکونازول (Miconazole)","کرم فوزیدیک اسید (Fusidic Acid)","پماد زینک اکساید (Zinc Oxide)",
        "کلرفنیرامین (Chlorpheniramine)","دیفن‌هیدرامین (Diphenhydramine)","دسلوراتادین (Desloratadine)","مونته‌لوکاست (Montelukast)",
        "بودزوناید (Budesonide)","فلوتیکازون (Fluticasone)","لوزارتان/هیدروکلروتیازید","والسارتان (Valsartan)","آتنولول (Atenolol)",
        "متوپرولول (Metoprolol)","فوروزماید (Furosemide)","اسپیرونولاکتون (Spironolactone)","پروپرانولول (Propranolol)",
        "سیتالوپرام (Citalopram)","سرترالین (Sertraline)","آمی‌تریپتیلین (Amitriptyline)","گاباپنتین (Gabapentin)",
        "پره‌گابالین (Pregabalin)","کاربامازپین (Carbamazepine)","والپروات سدیم (Sodium Valproate)","لاموتریژین (Lamotrigine)",
        "دیازپام (Diazepam)","فامسیکلوویر (Famciclovir)","لوپرامید (Loperamide)","بیسموت ساب‌سالسیلات (Bismuth)",
        "لاکتولوز (Lactulose)","سنا (Senna)","پسیلیوم (Psyllium)","دی‌سیکلومین (Dicyclomine)","مفنامیک اسید (Mefenamic Acid)",
        "کتورولاک (Ketorolac)","کدئین ترکیبی", "دیکلوفناک ژل", "ایبوپروفن ژل", "منتول موضعی",
        "محلول شست‌وشوی چشم", "اشک مصنوعی", "قطره چشمی آنتی‌بیوتیک", "قطره گوش", "قطره بینی سالین",
        "محلول ضدعفونی‌کننده دست", "گاز استریل", "باند پزشکی", "چسب زخم", "سرنگ یکبارمصرف", "دستکش پزشکی"
    ]

    SHOES_ITEMS = [
        "کفش مردانه رسمی","کفش مردانه اسپرت","کفش مردانه ورزشی","کفش مردانه چرمی","کفش زنانه رسمی",
        "کفش زنانه اسپرت","کفش زنانه ورزشی","کفش زنانه مجلسی","کفش بچگانه","کفش مدرسه‌ای",
        "صندل مردانه","صندل زنانه","صندل بچگانه","دمپایی مردانه","دمپایی زنانه","دمپایی بچگانه",
        "بوت مردانه","بوت زنانه","بوت بچگانه","نیم‌بوت مردانه","نیم‌بوت زنانه","نیم‌بوت بچگانه",
        "کتانی مردانه","کتانی زنانه","کتانی بچگانه","کفش ایمنی","کفش کار","کفش کوهنوردی",
        "کفش فوتسال","کفش فوتبال","کفش دویدن","کفش طبی","کفش راحتی","کفش پیاده‌روی",
        "کفش چرمی دست‌دوز","کفش عروس","کفش مهمانی","کفش ساحلی","کفش تابستانی","کفش زمستانی",
        "کفی کفش","بند کفش","واکس کفش","اسپری کفش","فرچه کفش"
    ]

    SHOE_BRANDS = [
        "Nike","Adidas","Puma","Reebok","New Balance","Skechers","Asics","Under Armour",
        "Converse","Vans","Fila","Jordan","Timberland","Clarks","Dr. Martens","ECCO",
        "Skechers GOwalk","Salomon","Merrell","Hoka","Brooks","Mizuno","Saucony","Diadora",
        "Kappa","Lotto","Umbro","Joma","Bata","Geox","Aldo","Clarks Originals","CAT",
        "Columbia","The North Face","Crocs","Birkenstock","Polo","Lacoste","Tommy Hilfiger"
    ]
    SHOE_SIZES = [str(x) for x in range(35, 49)] + ["35.5","36.5","37.5","38.5","39.5","40.5","41.5","42.5","43.5","44.5","45.5","46.5","47.5"]

    PRODUCE_ITEMS = [
        # میوه‌ها
        "سیب","گلابی","موز","پرتقال","نارنگی","لیموترش","لیمو شیرین","گریپ‌فروت","انگور","انار",
        "هندوانه","خربزه","طالبی","هلو","شلیل","زردآلو","آلو","آلوچه","گیلاس","آلبالو",
        "توت سفید","توت سیاه","توت‌فرنگی","انجیر","خرمالو","به","کیوی","آناناس","انبه","نارگیل",
        "پاپایا","آووکادو","خرما","ازگیل","کنار","لیچی","شاه‌توت","تمشک","بلوبری","کرنبری",
        "نارنج","بالنگ","کامکوات","دارابی","دراگون‌فروت","پشن‌فروت","چیکو","جک‌فروت","زیتون",
        # سبزیجات و صیفی‌جات
        "سیب‌زمینی","پیاز","سیر","هویج","خیار","گوجه‌فرنگی","بادمجان","کدو سبز","کدو حلوایی",
        "فلفل دلمه‌ای","فلفل سبز","فلفل قرمز","کلم سفید","کلم قرمز","گل‌کلم","بروکلی","کاهو",
        "اسفناج","جعفری","گشنیز","شوید","نعناع","ریحان","تره","پیازچه","چغندر","شلغم",
        "تربچه","لوبیا سبز","نخودفرنگی","ذرت","قارچ","بامیه","مارچوبه","کرفس","کنگر",
        "کاهوی رسمی","کاهوی پیچ","کدو سبز","خیار شور","لیمو ترش سبز"
    ]

    def _customer_picker(self, win):
        customers=self.db.execute("SELECT id,name,phone FROM customers ORDER BY name").fetchall()
        cb=LocalizedCombobox(win,values=[f"{i} - {n} | {ph or '-'}" for i,n,ph in customers],state="readonly")
        return cb, customers

    def _retail_price(self, business_type, item_name):
        row=self.db.execute("SELECT unit_price FROM retail_prices WHERE business_type=? AND item_name=?",(business_type,item_name)).fetchone()
        return float(row[0]) if row else 0.0

    def _set_retail_price(self, business_type, item_name, refresh=None):
        win=tk.Toplevel(self); win.title("ثبت قیمت کالا"); win.geometry("430x270"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="ثبت / تغییر قیمت",bg="#F4F6F8",fg="#1B2733",font=ui_font(16,"bold")).pack(pady=14)
        RTLLabel(win,text=item_name,bg="#F4F6F8",fg="#687582",font=ui_font(10)).pack(pady=4)
        e=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(12),justify="right"); e.pack(fill="x",padx=35,pady=12,ipady=8); e.insert(0,fmt_num(self._retail_price(business_type,item_name)))
        def save():
            try: price=float(D(e.get()))
            except: messagebox.showerror("قیمت","قیمت باید عددی باشد.",parent=win); return
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            self.db.execute("INSERT INTO retail_prices(business_type,item_name,unit_price,updated) VALUES(?,?,?,?) ON CONFLICT(business_type,item_name) DO UPDATE SET unit_price=excluded.unit_price,updated=excluded.updated",(business_type,item_name,price,now)); self.db.commit(); win.destroy()
            if refresh: refresh()
        self.button(win,"✓ ثبت قیمت",save).pack(side="bottom",pady=10)

    def _retail_price_map(self,business_type,items):
        rows=self.db.execute("SELECT item_name,unit_price FROM retail_prices WHERE business_type=?",(business_type,)).fetchall()
        return {n:float(v) for n,v in rows}

    def electronics_page(self):
        self.clear(); self._current_list_source=self.ELECTRONICS_ITEMS
        RTLLabel(self.main,text="فروش لوازم الکترونیک",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=12)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=4)
        self.button(bar,"＋ فروش جدید",lambda:self.new_retail_sale("لوازم الکترونیک",self.ELECTRONICS_ITEMS)).pack(side="left")
        self.button(bar,"🧾 فاکتورهای دکان",lambda:self.retail_invoices_page("لوازم الکترونیک"),"#475569").pack(side="left",padx=8)
        self.button(bar,"💰 ثبت قیمت انتخاب‌شده",lambda:self._price_selected(tree,"لوازم الکترونیک"),"#B58E45").pack(side="left",padx=8)
        q=tk.StringVar(); ent=tk.Entry(bar,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10)); ent.pack(side="right",fill="x",expand=True,padx=8,ipady=6)
        self.button(bar,"🔎 جستجو",lambda:self._filter_retail_tree(tree,q.get(),"لوازم الکترونیک",self.ELECTRONICS_ITEMS)).pack(side="right")
        tree=ttk.Treeview(self.main,columns=("name","cat","price"),show="headings")
        for c,h,w in (("name","نام وسیله",380),("cat","دسته",230),("price","قیمت ثبت‌شده",180)):
            tree.heading(c,text=_icu_shape_arabic(h)); tree.column(c,width=w,anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        self._filter_retail_tree(tree,"","لوازم الکترونیک",self.ELECTRONICS_ITEMS)
        tree.bind("<Double-1>",lambda e:self._price_selected(tree,"لوازم الکترونیک"))

    def _price_selected(self,tree,business_type):
        sel=tree.selection()
        if not sel: messagebox.showinfo("قیمت","ابتدا یک کالا را انتخاب کنید."); return
        name=tree.item(sel[0],"values")[0]
        self._set_retail_price(business_type,name,lambda:self._filter_retail_tree(tree,"",business_type,getattr(self,'_current_list_source',[])))

    def _filter_retail_tree(self,tree,q,business_type,source):
        for iid in tree.get_children(): tree.delete(iid)
        q=str(q or '').strip().lower(); prices=self._retail_price_map(business_type,source)
        for x in source:
            if not q or q in x.lower():
                group = "میوه / سبزی" if business_type in ("میوه‌فروشی","میوه فروشی","میوه و سبزیجات") else business_type
                tree.insert("","end",values=(_icu_shape_arabic(x),_icu_shape_arabic(group),fmt_num(prices.get(x,0))))

    def _filter_list(self,tree,q):
        q=str(q or '').strip().lower()
        for iid in tree.get_children(): tree.delete(iid)
        source=getattr(self,'_current_list_source',[])
        for x in source:
            if not q or q in x.lower(): tree.insert("","end",values=(x,"دارو" if source is self.MEDICINE_ITEMS else "لوازم الکترونیک"))

    def shoes_page(self):
        self.clear(); self._current_list_source=self.SHOES_ITEMS
        RTLLabel(self.main,text="کفش‌فروشی حرفه‌ای | کاتالوگ، سایز و مشخصات",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=12)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=4)
        self.button(bar,"＋ فروش جدید",lambda:self.new_retail_sale("کفش‌فروشی",self.SHOES_ITEMS)).pack(side="left")
        self.button(bar,"🧾 فاکتورهای کفش",lambda:self.retail_invoices_page("کفش‌فروشی"),"#475569").pack(side="left",padx=8)
        self.button(bar,"💰 ثبت قیمت انتخاب‌شده",lambda:self._price_selected(tree,"کفش‌فروشی"),"#B58E45").pack(side="left",padx=8)
        q=tk.StringVar(); tk.Entry(bar,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10),justify="right").pack(side="right",fill="x",expand=True,padx=8,ipady=6)
        self.button(bar,"🔎 جستجو",lambda:self._filter_shoes_tree(tree,q.get())).pack(side="right")
        info=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); info.pack(fill="x",padx=20,pady=5)
        RTLLabel(info,text=f"برندهای آماده: {len(self.SHOE_BRANDS)}  |  سایزهای آماده: ۳۵ تا ۴۸  |  مناسب ثبت مدل، برند، سایز و قیمت",bg="#FFFFFF",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=12,pady=8)
        cols=("name","category","brands","sizes","details","price")
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads={"name":"مدل / نوع کفش","category":"دسته","brands":"برندهای پیشنهادی","sizes":"سایز پا","details":"جزئیات","price":"قیمت ثبت‌شده"}
        widths={"name":210,"category":145,"brands":260,"sizes":145,"details":300,"price":150}
        for c in cols:
            tree.heading(c,text=_icu_shape_arabic(heads[c])); tree.column(c,width=widths[c],anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        self._filter_shoes_tree(tree,"")
        tree.bind("<Double-1>",lambda e:self._price_selected(tree,"کفش‌فروشی"))

    def _shoe_category_details(self,name):
        n=name.lower()
        if "مردانه" in n: cat="مردانه"
        elif "زنانه" in n: cat="زنانه"
        elif "بچگانه" in n or "مدرسه" in n: cat="کودک"
        else: cat="عمومی"
        if "فوتبال" in n or "فوتسال" in n: detail="ورزشی | مناسب زمین بازی | بررسی زیره و چسبندگی"
        elif "کوهنوردی" in n: detail="کوهنوردی | زیره مقاوم | مناسب مسیرهای سنگلاخی"
        elif "ایمنی" in n or "کار" in n: detail="کاری | مقاوم | مناسب محیط کار"
        elif "بوت" in n: detail="بوت | مناسب هوای سرد | ساق‌دار"
        elif "صندل" in n or "دمپایی" in n: detail="روزمره | سبک | مناسب استفاده آزاد"
        elif "رسمی" in n or "چرمی" in n or "مجلسی" in n: detail="رسمی | مناسب مهمانی و محل کار | جنس قابل ثبت"
        else: detail="روزمره / اسپرت | مناسب پیاده‌روی و استفاده روزانه"
        return cat,detail

    def _filter_shoes_tree(self,tree,q):
        for iid in tree.get_children(): tree.delete(iid)
        term=str(q or '').strip().lower(); prices=self._retail_price_map("کفش‌فروشی",self.SHOES_ITEMS)
        brands="، ".join(self.SHOE_BRANDS[:8])+" و ..."
        sizes="۳۵–۴۸"
        for name in self.SHOES_ITEMS:
            cat,detail=self._shoe_category_details(name)
            hay=" ".join((name,cat,detail,*self.SHOE_BRANDS)).lower()
            if term and term not in hay: continue
            tree.insert("","end",values=(_icu_shape_arabic(name),_icu_shape_arabic(cat),_icu_shape_arabic(brands),sizes,_icu_shape_arabic(detail),fmt_num(prices.get(name,0))))

    def _attach_vertical_scrollbar(self, parent, widget):
        """Attach a reliable vertical scrollbar to large list/table widgets."""
        holder=tk.Frame(parent,bg=parent.cget("bg") if "bg" in parent.keys() else "#F4F6F8")
        widget.pack_forget()
        widget.configure(yscrollcommand=lambda *args: bar.set(*args))
        widget.pack(side="left",fill="both",expand=True)
        bar=tk.Scrollbar(holder,orient="vertical",command=widget.yview,width=14)
        bar.pack(side="right",fill="y")
        return holder

    def pharmacy_page(self):
        self.clear(); self._current_list_source=self.MEDICINE_ITEMS
        RTLLabel(self.main,text="داروخانه و اطلاعات دارویی",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=12)
        note=tk.Frame(self.main,bg="#FFF8E7",highlightbackground="#E8D7A8",highlightthickness=1); note.pack(fill="x",padx=20,pady=5)
        RTLLabel(note,text="اطلاعات دارویی برای آگاهی عمومی است؛ برای مصرف، دوز و تداخلات به پزشک/داروساز و بروشور رسمی مراجعه کنید.",bg="#FFF8E7",fg="#7A5A12",font=ui_font(9),wraplength=950).pack(anchor="e",padx=12,pady=8)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=4)
        self.button(bar,"＋ فروش دارو",lambda:self.new_retail_sale("داروخانه",self.MEDICINE_ITEMS)).pack(side="left")
        self.button(bar,"🧾 فاکتورهای داروخانه",lambda:self.retail_invoices_page("داروخانه"),"#475569").pack(side="left",padx=8)
        self.button(bar,"💰 ثبت قیمت انتخاب‌شده",lambda:self._price_selected(tree,"داروخانه"),"#B58E45").pack(side="left",padx=8)
        q=tk.StringVar(); ent=tk.Entry(bar,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10)); ent.pack(side="right",fill="x",expand=True,padx=8,ipady=6)
        self.button(bar,"🔎 جستجو",lambda:self._refresh_medicine_tree(tree,q.get())).pack(side="right")
        tree=ttk.Treeview(self.main,columns=("name","category","price","info"),show="headings")
        for c,h,w in (("name","نام دارو",360),("category","دسته دارویی",150),("price","قیمت ثبت‌شده",180),("info","اطلاعات",260)):
            tree.heading(c,text=_icu_shape_arabic(h)); tree.column(c,width=w,anchor="center")
        tree_holder=tk.Frame(self.main,bg="#F4F6F8")
        tree_holder.pack(fill="both",expand=True,padx=20,pady=10)
        vbar=tk.Scrollbar(tree_holder,orient="vertical",command=tree.yview,width=14)
        tree.configure(yscrollcommand=vbar.set)
        tree.pack(side="left",fill="both",expand=True)
        vbar.pack(side="right",fill="y")
        self._refresh_medicine_tree(tree,"")
        tree.bind("<Double-1>",lambda e:self._open_medicine_web(tree))
        self.button(self.main,"🌐 مشاهده اطلاعات فارسی داروی انتخاب‌شده",lambda:self._open_medicine_web(tree),"#2D7FA3").pack(pady=8)

    def _medicine_category(self,name):
        n=str(name).lower()
        if any(x in n for x in ("آموکسی","آزیتر","سفال","سیپروف","کلاری","لووفلو","آنتی")): return "ضد عفونی / آنتی‌بیوتیک"
        if any(x in n for x in ("استامینوفن","ایبوپروفن","ناپروکسن","دیکلوفناک","کتورولاک","مفنامیک")): return "مسکن"
        if any(x in n for x in ("لوراتادین","سیتریزین","فکسوفنادین","کلرفنیرامین","دیفن")): return "ضد حساسیت"
        if any(x in n for x in ("امپرازول","پانتوپرازول","فاموتیدین","لاکتولوز","لوپرامید")): return "گوارشی"
        if any(x in n for x in ("متفورمین","گلی‌مپیرید","انسولین")): return "دیابت"
        if any(x in n for x in ("آملودیپین","لوزارتان","کاپتوپریل","والسارتان","آتنولول","متوپرولول")): return "قلب و فشار خون"
        if any(x in n for x in ("ویتامین","آهن","کلسیم","منیزیم","زینک","فولیک")): return "ویتامین و مکمل"
        if any(x in n for x in ("کرم","پماد","ژل","موضعی")): return "موضعی"
        return "سایر"

    def _refresh_medicine_tree(self,tree,q):
        for iid in tree.get_children(): tree.delete(iid)
        q=str(q or '').strip().lower(); prices=self._retail_price_map("داروخانه",self.MEDICINE_ITEMS)
        for x in self.MEDICINE_ITEMS:
            if not q or q in x.lower(): tree.insert("","end",values=(_icu_shape_arabic(x),_icu_shape_arabic(self._medicine_category(x)),fmt_num(prices.get(x,0)),_icu_shape_arabic("دوبار کلیک: اطلاعات فارسی دارو")))

    def _open_medicine_web(self,tree):
        sel=tree.selection()
        if not sel:
            messagebox.showwarning('دارویاب','ابتدا یک دارو را انتخاب کنید.')
            return
        name=str(tree.item(sel[0],'values')[0]).strip()
        # First try the documented Darooyab search API. If the API is unavailable,
        # fall back to a normal web search restricted to Darooyab.
        def worker():
            try:
                api_url='https://api.majidapi.ir/darooyab/search?search='+urllib.parse.quote(name)
                req=urllib.request.Request(api_url,headers={'User-Agent':'JahanAccounting/11.1'})
                with _jahan_urlopen(req,timeout=8) as resp:
                    raw=resp.read().decode('utf-8','replace')
                data=json.loads(raw)
                candidates=[]
                if isinstance(data,dict):
                    for key in ('data','result','results','items'):
                        if isinstance(data.get(key),list): candidates=data[key]; break
                elif isinstance(data,list):
                    candidates=data
                url=None
                if candidates:
                    first=candidates[0]
                    if isinstance(first,dict):
                        url=first.get('url') or first.get('link') or first.get('href')
                    elif isinstance(first,str): url=first
                if url and str(url).startswith('http'):
                    self.after(0,lambda u=url:self._open_file(u) if False else webbrowser.open(u))
                    return
            except Exception:
                pass
            q=urllib.parse.quote(name)
            fallback='https://www.google.com/search?hl=fa&lr=lang_fa&q='+urllib.parse.quote('site:darooyab.ir '+name+' اطلاعات دارویی')
            self.after(0,lambda:webbrowser.open(fallback))
        threading.Thread(target=worker,daemon=True).start()

    def new_retail_sale(self,business_type,items,business_id=None,business_name=None):
        business_name = business_name or business_type
        win=tk.Toplevel(self); win.title("فروش "+business_name); win.geometry("820x760"); win.minsize(760,650); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="فاکتور فروش دکان",bg="#F4F6F8",fg="#1B2733",font=ui_font(18,"bold")).pack(pady=12)
        top=tk.Frame(win,bg="#F4F6F8"); top.pack(fill="x",padx=20)
        if business_id is None:
            allowed_types = [business_type] if business_type in ("میوه‌فروشی","کفش‌فروشی","داروخانه","لوازم الکترونیک") else None
            if allowed_types:
                shops=self.db.execute("SELECT id,name,business_type FROM businesses WHERE business_type=? ORDER BY name",(business_type,)).fetchall()
            else:
                shops=self.db.execute("SELECT id,name,business_type FROM businesses ORDER BY name").fetchall()
            if not shops:
                messagebox.showwarning("دکان‌ها","ابتدا یک دکان ثبت کنید.",parent=win); win.destroy(); return
            RTLLabel(top,text="دکان / انبار",bg="#F4F6F8",fg="#1B2733").pack(anchor="e")
            shop_cb=LocalizedCombobox(top,values=[f"{i} - {n} ({t})" for i,n,t in shops],state="readonly",justify="right"); shop_cb.pack(fill="x",pady=4); shop_cb.current(0)
            business_id=shops[0][0]; business_name=shops[0][1]
            def sync_shop(_=None):
                nonlocal business_id,business_name
                business_id,business_name,_=shops[shop_cb.current()]
                win.title("فروش "+business_name)
            shop_cb.bind("<<ComboboxSelected>>",sync_shop)
        invoice_meta=tk.Frame(top,bg="#F4F6F8"); invoice_meta.pack(fill="x",pady=(2,5))
        RTLLabel(invoice_meta,text="شماره فاکتور",bg="#F4F6F8",fg="#687582",font=ui_font(9,"bold")).pack(side="right",padx=4)
        invoice_no=tk.Entry(invoice_meta,bg="white",fg="#1B2733",justify="right",relief="solid",bd=1)
        next_no=self.db.execute("SELECT COALESCE(MAX(id),0)+1 FROM retail_sales").fetchone()[0]
        invoice_no.insert(0,str(next_no)); invoice_no.pack(side="right",width=150,ipady=5,padx=4)
        RTLLabel(invoice_meta,text="تاریخ",bg="#F4F6F8",fg="#687582",font=ui_font(9,"bold")).pack(side="right",padx=4)
        invoice_date=tk.Entry(invoice_meta,bg="white",fg="#1B2733",justify="right",relief="solid",bd=1)
        invoice_date.insert(0,datetime.now().strftime("%Y/%m/%d")); invoice_date.pack(side="right",width=150,ipady=5,padx=4)
        RTLLabel(top,text="مشتری",bg="#F4F6F8",fg="#1B2733").pack(anchor="e")
        cb,customers=self._customer_picker(top); cb.pack(fill="x",pady=4)
        RTLLabel(top,text="مورد فروش",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",pady=(8,0))
        item=LocalizedCombobox(top,values=items); item.pack(fill="x",pady=4)
        stock_info=tk.StringVar(value="موجودی انبار: —")
        RTLLabel(top,textvariable=stock_info,bg="#EAF6EE",fg="#176B3A",font=ui_font(10,"bold"),anchor="e").pack(fill="x",pady=(2,5),ipady=5)
        def refresh_stock(*_):
            n=item.get().strip()
            if business_id and n:
                inv=self.db.execute("SELECT quantity,unit,sale_price FROM shop_inventory WHERE business_id=? AND item_name=?",(business_id,n)).fetchone()
                if inv:
                    stock_info.set(f"موجودی انبار: {fmt_num(inv[0])} {inv[1]} | قیمت انبار: {fmt_num(inv[2])}")
                    if float(inv[2])>0:
                        price.delete(0,"end"); price.insert(0,fmt_num(inv[2]))
                else: stock_info.set("موجودی انبار: ۰ — این کالا در انبار ثبت نشده است")
        produce_mode = business_type in ("میوه‌فروشی","میوه فروشی","میوه و سبزیجات")
        unit_var = tk.StringVar(value="عدد")
        unit_cb = None
        if produce_mode:
            RTLLabel(top,text="واحد",bg="#F4F6F8",fg="#1B2733").pack(anchor="e",pady=(4,0))
            unit_cb=LocalizedCombobox(top,values=["کیلوگرم","تن","عدد","بسته"],textvariable=unit_var,state="readonly",justify="right"); unit_cb.pack(fill="x",pady=4); unit_cb.current(0)
        quick=tk.Frame(top,bg="#F4F6F8"); quick.pack(fill="x",pady=(2,6))
        RTLLabel(quick,text="با یک کلیک از فهرست انتخاب کنید:",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(side="right",padx=4)
        quick_list=tk.Listbox(quick,height=6,bg="#FFFFFF",fg="#1B2733",selectbackground="#35a9ff",selectforeground="#FFFFFF",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",font=ui_font(9))
        quick_list.pack(side="right",fill="both",expand=True,padx=(4,0))
        quick_scroll=tk.Scrollbar(quick,orient="vertical",command=quick_list.yview,width=13); quick_list.configure(yscrollcommand=quick_scroll.set)
        quick_scroll.pack(side="right",fill="y",padx=(0,4))
        price_map=self._retail_price_map(business_type,items)
        quick_items=[]
        for _it in items:
            _p=price_map.get(_it,0); quick_items.append((_it,_p)); quick_list.insert("end",_icu_shape_arabic(f"{_it}   |   {_p:,.0f}" if _p else f"{_it}   |   قیمت ثبت نشده"))
        row=tk.Frame(top,bg="#F4F6F8"); row.pack(fill="x",pady=4)
        qty=tk.Entry(row,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); qty.insert(0,"1"); qty.pack(side="right",fill="x",expand=True,padx=4,ipady=6)
        price=tk.Entry(row,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); price.pack(side="right",fill="x",expand=True,padx=4,ipady=6)
        RTLLabel(row,text="قیمت واحد",bg="#F4F6F8",fg="#687582").pack(side="right",padx=4); RTLLabel(row,text="تعداد",bg="#F4F6F8",fg="#687582").pack(side="right",padx=4)
        paid=tk.Entry(top,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); paid.pack(fill="x",pady=4,ipady=6)
        RTLLabel(top,text="مبلغ پرداخت‌شده (اگر قرض برد، صفر یا کمتر از کل)",bg="#F4F6F8",fg="#687582").pack(anchor="e")
        notes=tk.Entry(top,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); notes.pack(fill="x",pady=4,ipady=6)
        action_bar=tk.Frame(win,bg="#F4F6F8"); action_bar.pack(fill="x",padx=20,pady=(2,5))
        tree=ttk.Treeview(win,columns=("item","qty","unit","price","total"),show="headings",height=8)
        for c,h in zip(("item","qty","unit","price","total"),("کالا/دارو","مقدار","واحد","قیمت واحد","جمع")):
            tree.heading(c,text=_icu_shape_arabic(h)); tree.column(c,width=160,anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=6)
        items_buf=[]
        def add():
            try:q=float(D(qty.get() or 1)); p=float(D(price.get() or 0))
            except:messagebox.showerror("خطا","تعداد و قیمت باید عددی باشند.");return
            name=item.get().strip()
            if not name or q<=0 or p<0:return
            unit_name=unit_var.get() if produce_mode else "عدد"
            t=q*p; items_buf.append((name,unit_name,q,p,t)); tree.insert("","end",values=(name,fmt_num(q),unit_name,fmt_num(p),fmt_num(t)))
        def quick_add(event=None):
            sel=quick_list.curselection()
            if not sel:return
            name, saved_price=quick_items[sel[0]]
            item.set(name)
            if saved_price>0: price.delete(0,"end"); price.insert(0,fmt_num(saved_price))
            add()
        quick_list.bind("<<ListboxSelect>>",quick_add)
        def set_default_price(*_):
            name=item.get().strip(); base=price_map.get(name,0)
            if base>0:
                val=base*1000 if produce_mode and unit_var.get()=="تن" else base
                price.delete(0,"end"); price.insert(0,fmt_num(val))
        if produce_mode: unit_cb.bind("<<ComboboxSelected>>",set_default_price)
        item.bind("<<ComboboxSelected>>",set_default_price)
        item.bind("<<ComboboxSelected>>",refresh_stock)
        add_btn=self.button(action_bar,"＋ افزودن به فاکتور",add,"#2D7FA3"); add_btn.pack(side="right",padx=4)
        def save():
            if not items_buf: messagebox.showwarning("فاکتور","حداقل یک مورد اضافه کنید."); return
            try: pv=float(D(paid.get() or 0))
            except: messagebox.showerror("خطا","مبلغ پرداختی نامعتبر است."); return
            total=sum(x[4] for x in items_buf); debt=max(0,total-pv)
            cid=None;cname="مشتری متفرقه";phone=""
            if cb.current()>=0:
                cid,cname,phone=customers[cb.current()]
            elif debt>0:
                messagebox.showwarning("قرض","برای ثبت قرض، مشتری را انتخاب کنید."); return
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            invno=invoice_no.get().strip() or str(self.db.execute("SELECT COALESCE(MAX(id),0)+1 FROM retail_sales").fetchone()[0])
            cur=self.db.execute("INSERT INTO retail_sales(created,business_type,business_name,business_id,customer_id,customer,phone,total,paid,debt,notes,currency,rate,invoice_no,discount,tax,final_total) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                (now,business_type,business_name,business_id,cid,cname,phone,total,pv,debt,notes.get().strip(),"AFN - افغانی",1,invno,0,0,total))
            sid=cur.lastrowid
            for n,u,q,p,t in items_buf:
                stock_before=None; stock_after=None
                if business_id:
                    inv=self.db.execute("SELECT id,quantity,unit FROM shop_inventory WHERE business_id=? AND item_name=?",(business_id,n)).fetchone()
                    if not inv:
                        self.db.rollback(); messagebox.showerror("موجودی",f"کالای «{n}» در انبار این دکان ثبت نشده است. ابتدا آن را وارد انبار کنید.",parent=win); return
                    stock_before=float(inv[1]); stock_after=stock_before-float(q)
                    if stock_after < -1e-9:
                        self.db.rollback(); messagebox.showerror("موجودی",f"موجودی «{n}» کافی نیست. موجودی فعلی: {fmt_num(stock_before)} {inv[2]}",parent=win); return
                    self.db.execute("UPDATE shop_inventory SET quantity=?,updated=? WHERE id=?",(max(0,stock_after),now,inv[0]))
                self.db.execute("INSERT INTO retail_sale_items(sale_id,item_name,unit,quantity,unit_price,total,stock_before,stock_after) VALUES(?,?,?,?,?,?,?,?)",(sid,n,u,q,p,t,stock_before,stock_after))
            if cid and debt>0:self.db.execute("INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes) VALUES(?,?,?,?,?,?)",(now,cid,cname,"قرضداری مشتری",debt,f"فاکتور {business_type} #{invno}"))
            if cid and pv>0:self.db.execute("INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes) VALUES(?,?,?,?,?,?)",(now,cid,cname,"بستانکاری مشتری",pv,f"پرداخت فاکتور {business_type} #{sid}"))
            self.db.commit(); win.destroy(); self.shops_invoice_center_page()
        save_btn=self.button(action_bar,"✓ ثبت فاکتور و چاپ",save,"#0F766E"); save_btn.pack(side="right",padx=4)
        self.button(action_bar,"↩ انصراف",win.destroy,"#64748B").pack(side="left",padx=4)

    def shops_invoice_center_page(self):
        """Unified invoice center under Shops.
        Shows modern shop invoices and legacy fruit invoices in one clear table.
        Legacy invoices remain untouched and open through their original viewer.
        """
        self.clear()
        bg="#F4F6F8"
        head=tk.Frame(self.main,bg=bg); head.pack(fill="x",padx=20,pady=(12,4))
        RTLLabel(head,text="مرکز کامل فاکتورها",bg=bg,fg="#1B2733",font=ui_font(20,"bold")).pack(side="right")
        RTLLabel(head,text="تمام فاکتورهای دکان‌ها در یک محل",bg=bg,fg="#687582",font=ui_font(9)).pack(side="left",pady=8)
        bar=tk.Frame(self.main,bg=bg); bar.pack(fill="x",padx=20,pady=6)
        self.button(bar,"＋ فاکتور جدید",lambda:self.new_retail_sale("دکان",self.ELECTRONICS_ITEMS)).pack(side="right",padx=4)
        self.button(bar,"🏪 دکان‌ها",self.businesses_page,"#475569").pack(side="right",padx=4)
        self.button(bar,"🍎 فاکتورهای میوه",self.fruits_sales_page,"#0F766E").pack(side="right",padx=4)
        q=tk.StringVar()
        ent=tk.Entry(bar,textvariable=q,bg="white",fg="#1B2733",relief="solid",bd=1,font=ui_font(10),justify="right")
        ent.pack(side="left",fill="x",expand=True,padx=(8,0),ipady=7)
        RTLLabel(bar,text="جستجو:",bg=bg,fg="#1B2733",font=ui_font(10,"bold")).pack(side="left",padx=4)
        cols=("id","source","number","date","shop","customer","total","paid","debt")
        tree=ttk.Treeview(self.main,columns=cols,show="headings",style="Jahan.Treeview")
        heads={"id":"شناسه","source":"بخش","number":"شماره فاکتور","date":"تاریخ","shop":"دکان","customer":"مشتری","total":"مبلغ کل","paid":"پرداخت","debt":"مانده"}
        widths={"id":70,"source":110,"number":125,"date":165,"shop":160,"customer":180,"total":130,"paid":120,"debt":120}
        for c in cols:
            tree.heading(c,text=_icu_shape_arabic(heads[c])); tree.column(c,width=widths[c],anchor="center")
        self._pack_with_scrollbar(tree,fill="both",expand=True,padx=20,pady=8)

        def rows():
            out=[]
            for r in self.db.execute("SELECT id,COALESCE(invoice_no,''),created,business_name,customer,total,paid,debt FROM retail_sales ORDER BY id DESC"):
                out.append((int(r[0]),"دکان",r[1] or r[0],dual_datetime(r[2]),r[3] or "-",r[4] or "-",fmt_num(r[5]),fmt_num(r[6]),fmt_num(r[7]),"retail"))
            # Keep legacy fruit invoices visible in the same center, without changing their IDs/data.
            for r in self.db.execute("SELECT id,created,customer,total FROM invoices ORDER BY id DESC"):
                out.append((int(r[0]),"میوه",r[0],dual_datetime(r[1]),"میوه‌فروشی",r[2] or "-",fmt_num(r[3]),"-","-","fruit"))
            return out
        def populate(*_):
            tree.delete(*tree.get_children()); term=q.get().strip().lower()
            data=rows()
            for r in data:
                if term and term not in " ".join(str(x or "") for x in r).lower(): continue
                tree.insert("","end",values=r[:9],tags=(r[9],))
        def open_selected():
            sel=tree.selection()
            if not sel: messagebox.showwarning("فاکتور","یک فاکتور را انتخاب کنید."); return
            vals=tree.item(sel[0],"values")
            source=str(vals[1])
            iid=int(vals[0])
            if source=="میوه": self.show_invoice(iid)
            else: self.print_retail_invoice(tree)
        q.trace_add("write",populate); populate()
        action=tk.Frame(self.main,bg=bg); action.pack(fill="x",padx=20,pady=(2,10))
        self.button(action,"👁 مشاهده / چاپ فاکتور",open_selected,"#2D7FA3").pack(side="right",padx=4)
        self.button(action,"📱 ارسال واتساپ",lambda:self._share_invoice_center_whatsapp(tree),"#128C7E").pack(side="right",padx=4)
        self.button(action,"↩ برگشت به دکان‌ها",self.businesses_page,"#475569").pack(side="left",padx=4)

    def _share_invoice_center_whatsapp(self,tree):
        sel=tree.selection()
        if not sel: return
        vals=tree.item(sel[0],"values"); iid=int(vals[0])
        if str(vals[1])=="میوه":
            row=self.db.execute("SELECT id,created,customer,phone,notes,total FROM invoices WHERE id=?",(iid,)).fetchone()
            if row:
                msg=f"فاکتور فروش میوه\nشماره: {row[0]}\nتاریخ: {dual_datetime(row[1])}\nمشتری: {row[2]}\nمبلغ کل: {fmt_num(row[5])} افغانی\nتوضیحات: {row[4] or '-'}"
                webbrowser.open("https://web.whatsapp.com/send?text="+urllib.parse.quote(msg))
        else:
            self.send_retail_invoice_whatsapp(iid)

    def retail_invoices_page(self,business_type=None):
        self.clear(); title="فاکتورهای دکان"+(" - "+business_type if business_type else "")
        RTLLabel(self.main,text=title,bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        cols=("id","invno","date","type","customer","total","paid","debt")
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads=("شناسه","شماره فاکتور","تاریخ","بخش","مشتری","کل","پرداخت","مانده")
        for c,h in zip(cols,heads):tree.heading(c,text=_icu_shape_arabic(h));tree.column(c,width=115,anchor="center")
        tree.column("customer",width=170)
        invoice_holder=tk.Frame(self.main,bg="#F4F6F8"); invoice_holder.pack(fill="both",expand=True,padx=20,pady=10)
        invoice_bar=tk.Scrollbar(invoice_holder,orient="vertical",command=tree.yview,width=14); tree.configure(yscrollcommand=invoice_bar.set)
        tree.pack(side="left",fill="both",expand=True); invoice_bar.pack(side="right",fill="y")
        sql="SELECT id,COALESCE(invoice_no,''),created,business_type,customer,total,paid,debt FROM retail_sales"
        args=[]
        if business_type:sql+=" WHERE business_type=?";args=[business_type]
        sql+=" ORDER BY id DESC"
        for r in self.db.execute(sql,args):tree.insert("","end",values=(r[0],r[1] or r[0],dual_datetime(r[2]),r[3],r[4],fmt_num(r[5]),fmt_num(r[6]),fmt_num(r[7])))
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=8)
        self.button(bar,"🖨 مشاهده / چاپ فاکتور",lambda:self.print_retail_invoice(tree),"#2D7FA3").pack(side="right",padx=4)
        def wa_selected():
            sel=tree.selection()
            if sel:self.send_retail_invoice_whatsapp(int(tree.item(sel[0],"values")[0]))
        self.button(bar,"📱 ارسال واتساپ",wa_selected,"#128c7e").pack(side="right",padx=4)

    def _retail_invoice_data(self, sid):
        row=self.db.execute("""SELECT r.*, b.phone AS seller_phone, b.address AS seller_address
                               FROM retail_sales r LEFT JOIN businesses b ON b.id=r.business_id
                               WHERE r.id=?""",(sid,)).fetchone()
        if not row:return None
        cols=[x[1] for x in self.db.execute("PRAGMA table_info(retail_sales)").fetchall()]
        d=dict(zip(cols,row[:len(cols)]))
        d["seller_phone"],d["seller_address"]=row[len(cols):len(cols)+2]
        cr=self.db.execute("SELECT phone,address FROM customers WHERE id=?",(d.get("customer_id"),)).fetchone() if d.get("customer_id") else None
        d["customer_phone"]=cr[0] if cr else d.get("phone","")
        d["customer_address"]=cr[1] if cr else ""
        d["items"]=[dict(zip(["item_name","unit","quantity","unit_price","total","stock_before","stock_after"],r))
                    for r in self.db.execute("""SELECT item_name,unit,quantity,unit_price,total,stock_before,stock_after
                                                FROM retail_sale_items WHERE sale_id=? ORDER BY id""",(sid,)).fetchall()]
        return d

    def _retail_invoice_share_text(self, d):
        lines=[
            "*فاکتور فروش*",
            f"شماره فاکتور: {d.get('invoice_no') or d['id']}",
            f"تاریخ: {dual_datetime(d['created'])}",
            f"فروشنده / شرکت: {d['business_name']}",
            f"تماس فروشنده: {d.get('seller_phone') or '—'}",
            f"آدرس فروشنده: {d.get('seller_address') or '—'}",
            f"خریدار: {d['customer']}",
            f"تماس خریدار: {d.get('customer_phone') or '—'}",
            f"آدرس خریدار: {d.get('customer_address') or '—'}",
            "",
            "*جزئیات کالاها*"
        ]
        for i,x in enumerate(d["items"],1):
            lines.append(f"{i}. {x['item_name']} | {fmt_num(x['quantity'])} {x['unit']} | فی {fmt_num(x['unit_price'])} | جمع {fmt_num(x['total'])}")
        final=float(d.get("final_total") or d.get("total") or 0)
        lines += ["",
                  f"مجموع کالاها: {fmt_num(d.get('total',0))} {d.get('currency','')}",
                  f"تخفیف: {fmt_num(d.get('discount',0))} {d.get('currency','')}",
                  f"مالیات: {fmt_num(d.get('tax',0))} {d.get('currency','')}",
                  f"*مبلغ نهایی: {fmt_num(final)} {d.get('currency','')}*",
                  f"پرداخت: {fmt_num(d.get('paid',0))} {d.get('currency','')}",
                  f"مانده: {fmt_num(d.get('debt',0))} {d.get('currency','')}"]
        if d.get("notes"): lines += ["",f"توضیحات: {d['notes']}"]
        return "\n".join(lines)

    def send_retail_invoice_whatsapp(self, sid):
        d=self._retail_invoice_data(sid)
        if not d:return
        msg=self._retail_invoice_share_text(d)
        phone=d.get("customer_phone") or d.get("phone")
        if phone:
            webbrowser.open("https://wa.me/"+self.normalize_phone(phone)+"?text="+urllib.parse.quote(msg))
        else:
            webbrowser.open("https://web.whatsapp.com/send?text="+urllib.parse.quote(msg))

    def _retail_invoice_pdf(self, d, target_path=None):
        if not REPORTLAB_OK:
            messagebox.showerror("PDF","کتابخانه PDF در این نسخه نصب نیست."); return None
        path=target_path or filedialog.asksaveasfilename(defaultextension=".pdf",filetypes=[("PDF","*.pdf")],
                                                        initialfile=f"فاکتور_{d.get('invoice_no') or d['id']}.pdf")
        if not path:return None
        font=self._pdf_font()
        doc=SimpleDocTemplate(path,pagesize=A4,rightMargin=24,leftMargin=24,topMargin=22,bottomMargin=22,
                              title="فاکتور فروش",author="Jahan Accounting")
        styles=getSampleStyleSheet()
        title=ParagraphStyle("InvoiceTitle",fontName=font,fontSize=20,leading=24,alignment=TA_CENTER,textColor=colors.HexColor("#1B2733"))
        body=ParagraphStyle("InvoiceBody",fontName=font,fontSize=8.5,leading=13,alignment=TA_RIGHT,textColor=colors.HexColor("#1B2733"))
        center=ParagraphStyle("InvoiceCenter",parent=body,alignment=TA_CENTER)
        story=[]
        # Header band inspired directly by the supplied invoice layout.
        band=Table([[Paragraph(self._pdf_text("فاکتور فروش"),title)]],colWidths=[547])
        band.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#8E7CC3")),
                                  ("TOPPADDING",(0,0),(-1,-1),9),("BOTTOMPADDING",(0,0),(-1,-1),9)]))
        story += [band,Spacer(1,6)]
        meta=[
            [("شماره فاکتور",d.get("invoice_no") or d["id"]),("تاریخ",dual_datetime(d["created"]))],
            [("ارائه دهنده / شرکت",d["business_name"]),("شماره تماس",d.get("seller_phone") or "—")],
            [("آدرس فروشنده",d.get("seller_address") or "—"),("خریدار",d["customer"])],
            [("شماره تماس خریدار",d.get("customer_phone") or "—"),("آدرس خریدار",d.get("customer_address") or "—")]
        ]
        meta_data=[]
        for a,b in meta:
            meta_data.append([Paragraph(self._pdf_text(a[0]),body),Paragraph(self._pdf_text(a[1]),body),
                              Paragraph(self._pdf_text(b[0]),body),Paragraph(self._pdf_text(b[1]),body)])
        mt=Table(meta_data,colWidths=[95,180,95,177],hAlign="RIGHT")
        mt.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.6,colors.HexColor("#303030")),
                                ("BACKGROUND",(0,0),(0,-1),colors.HexColor("#F4E3A1")),
                                ("BACKGROUND",(2,0),(2,-1),colors.HexColor("#F4E3A1")),
                                ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                                ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
                                ("RIGHTPADDING",(0,0),(-1,-1),5),("LEFTPADDING",(0,0),(-1,-1),5)]))
        story += [mt,Spacer(1,7)]
        headers=["ردیف","شرح کالا","تعداد","واحد","فی","تخفیف","مبلغ کل"]
        data=[[Paragraph(self._pdf_text(h),center) for h in headers]]
        for i,x in enumerate(d["items"],1):
            data.append([Paragraph(self._pdf_text(str(i)),center),
                         Paragraph(self._pdf_text(x["item_name"]),body),
                         Paragraph(self._pdf_text(fmt_num(x["quantity"])),center),
                         Paragraph(self._pdf_text(x["unit"]),center),
                         Paragraph(self._pdf_text(fmt_num(x["unit_price"])),center),
                         Paragraph(self._pdf_text(fmt_num(0)),center),
                         Paragraph(self._pdf_text(fmt_num(x["total"])),center)])
        while len(data)<16:
            data.append([Paragraph("",center) for _ in headers])
        tt=Table(data,colWidths=[34,190,55,55,76,58,79],repeatRows=1,hAlign="RIGHT")
        tt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#F4E3A1")),
                                ("GRID",(0,0),(-1,-1),0.55,colors.HexColor("#303030")),
                                ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                                ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
        story += [tt,Spacer(1,5)]
        cur=d.get("currency") or "AFN - افغانی"
        base=float(d.get("total") or 0); disc=float(d.get("discount") or 0); tax=float(d.get("tax") or 0)
        final=float(d.get("final_total") or base)
        summary=[
            [Paragraph(self._pdf_text("قیمت کل"),body),Paragraph(self._pdf_text(f"{fmt_num(base)} {cur}"),center)],
            [Paragraph(self._pdf_text("تخفیف"),body),Paragraph(self._pdf_text(f"{fmt_num(disc)} {cur}"),center)],
            [Paragraph(self._pdf_text("مالیات"),body),Paragraph(self._pdf_text(f"{fmt_num(tax)} {cur}"),center)],
            [Paragraph(self._pdf_text("مبلغ نهایی"),body),Paragraph(self._pdf_text(f"{fmt_num(final)} {cur}"),center)],
            [Paragraph(self._pdf_text("بیعانه / پرداخت"),body),Paragraph(self._pdf_text(f"{fmt_num(d['paid'])} {cur}"),center)],
            [Paragraph(self._pdf_text("مانده"),body),Paragraph(self._pdf_text(f"{fmt_num(d['debt'])} {cur}"),center)]
        ]
        st=Table(summary,colWidths=[120,180],hAlign="LEFT")
        st.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,colors.HexColor("#303030")),
                                ("BACKGROUND",(0,0),(0,-1),colors.HexColor("#F4F4F4")),
                                ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
        desc=Table([[Paragraph(self._pdf_text("توضیحات:"),body)],[Paragraph(self._pdf_text(d.get("notes") or ""),body)]],
                   colWidths=[230],rowHeights=[22,72],hAlign="RIGHT")
        desc.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,colors.HexColor("#303030")),("VALIGN",(0,0),(-1,-1),"TOP"),
                                  ("RIGHTPADDING",(0,0),(-1,-1),6)]))
        bot=Table([[st,desc]],colWidths=[300,247],hAlign="RIGHT")
        bot.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP")]))
        story += [bot,Spacer(1,8)]
        sig=Table([[Paragraph(self._pdf_text("مهر و امضای فروشنده"),center),
                    Paragraph(self._pdf_text("مهر و امضای خریدار"),center)]],colWidths=[273,274],rowHeights=[55])
        sig.setStyle(TableStyle([("BOX",(0,0),(0,0),0.5,colors.HexColor("#303030")),
                                 ("BOX",(1,0),(1,0),0.5,colors.HexColor("#303030"))]))
        story.append(sig)
        try:
            doc.build(story); return path
        except Exception as e:
            messagebox.showerror("PDF",f"ساخت فاکتور با خطا روبه‌رو شد:\n{e}"); return None

    def print_retail_invoice(self,tree):
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("فاکتور","لطفاً یک فاکتور را انتخاب کنید."); return
        sid=int(tree.item(sel[0],"values")[0]); d=self._retail_invoice_data(sid)
        if not d:
            messagebox.showerror("فاکتور","فاکتور پیدا نشد."); return
        path=self._retail_invoice_pdf(d)
        if not path:return
        win=tk.Toplevel(self); win.title(f"فاکتور {d.get('invoice_no') or sid}"); win.geometry("650x310"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="پیش‌نمایش، چاپ و ارسال فاکتور",bg="#F4F6F8",fg="#1B2733",font=ui_font(18,"bold")).pack(pady=18)
        RTLLabel(win,text=f"فاکتور شماره {d.get('invoice_no') or sid} آماده است.",bg="#F4F6F8",fg="#687582",font=ui_font(10)).pack(pady=4)
        bar=tk.Frame(win,bg="#F4F6F8"); bar.pack(pady=18)
        self.button(bar,"👁 پیش‌نمایش PDF",lambda:self._open_file(path),"#2D7FA3").pack(side="right",padx=4)
        self.button(bar,"🖨 چاپ مستقیم",lambda:self._print_pdf_file(path),"#B58E45").pack(side="right",padx=4)
        self.button(bar,"📱 واتساپ",lambda:self.send_retail_invoice_whatsapp(sid),"#128c7e").pack(side="right",padx=4)
        self.button(bar,"بستن",win.destroy,"#687582").pack(side="left",padx=4)
        self.after(100,lambda:self._open_file(path))

    def _shop_currency_label(self,currency):
        return str(currency).split(" - ")[0] if " - " in str(currency) else str(currency)

    def add_business(self):
        win=tk.Toplevel(self); win.title("ثبت دکان جدید"); win.geometry("520x560"); win.minsize(480,520); win.configure(bg="#F4F6F8")
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=24,pady=20)
        def lab(t): RTLLabel(outer,text=t,bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",pady=(7,2))
        lab("نام دکان"); name=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); name.pack(fill="x",ipady=7)
        lab("نوع دکان"); typ=LocalizedCombobox(outer,values=["دکان عمومی","میوه‌فروشی","کفش‌فروشی","داروخانه","لوازم الکترونیک","سایر"],state="readonly",justify="right"); typ.pack(fill="x",ipady=5); typ.current(0)
        lab("شماره تماس"); phone=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); phone.pack(fill="x",ipady=7)
        lab("آدرس"); address=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); address.pack(fill="x",ipady=7)
        lab("یادداشت"); notes=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); notes.pack(fill="x",ipady=7)
        def save():
            n=name.get().strip()
            if not n: messagebox.showwarning("دکان","نام دکان را وارد کنید.",parent=win); return
            self.db.execute("INSERT INTO businesses(name,business_type,phone,address,notes) VALUES(?,?,?,?,?)",(n,typ.get() or "دکان عمومی",phone.get().strip(),address.get().strip(),notes.get().strip()))
            self.db.commit(); win.destroy(); self.businesses_page()
        self.button(outer,"✓ ثبت دکان",save).pack(fill="x",pady=18,ipady=5)

    def shop_invoices_selected(self,tree):
        sel=tree.selection()
        if not sel:
            messagebox.showinfo("فاکتورها","ابتدا یک دکان را انتخاب کنید."); return
        bid=int(tree.item(sel[0],"values")[0])
        self.retail_invoices_page_for_shop(bid)

    def retail_invoices_page_for_shop(self,business_id):
        row=self.db.execute("SELECT name FROM businesses WHERE id=?",(business_id,)).fetchone()
        if not row: return
        self.clear(); title="فاکتورهای دکان: "+row[0]
        RTLLabel(self.main,text=title,bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        cols=("id","invno","date","customer","total","paid","debt")
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        for c,h,w in (("id","شناسه",75),("invno","شماره فاکتور",110),("date","تاریخ",180),("customer","مشتری",230),("total","کل",140),("paid","پرداخت",140),("debt","مانده",140)):
            tree.heading(c,text=_icu_shape_arabic(h)); tree.column(c,width=w,anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        for r in self.db.execute("SELECT id,COALESCE(invoice_no,''),created,customer,total,paid,debt FROM retail_sales WHERE business_id=? ORDER BY id DESC",(business_id,)):
            tree.insert("","end",values=(r[0],r[1] or r[0],dual_datetime(r[2]),r[3],fmt_num(r[4]),fmt_num(r[5]),fmt_num(r[6])))
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=8)
        self.button(bar,"🖨 مشاهده / چاپ فاکتور",lambda:self.print_retail_invoice(tree),"#2D7FA3").pack(side="right",padx=4)
        def wa_selected():
            sel=tree.selection()
            if sel:self.send_retail_invoice_whatsapp(int(tree.item(sel[0],"values")[0]))
        self.button(bar,"📱 ارسال واتساپ",wa_selected,"#128c7e").pack(side="right",padx=4)
        self.button(self.main,"↩ برگشت به دکان‌ها",self.businesses_page,"#687582").pack(pady=(0,10))

    def shop_catalog_page(self, catalog_type):
        """Professional, unified product catalog for shops.
        Catalogs are operational: search, inspect, set price and add the selected
        item directly to a selected shop inventory. No currency-trading operation
        is exposed here.
        """
        self.clear()
        bg="#F4F6F8"
        configs={
            "داروخانه": ("💊 کاتالوگ کامل داروخانه", self.MEDICINE_ITEMS),
            "میوه‌فروشی": ("🍎 کاتالوگ کامل میوه و سبزیجات", self.PRODUCE_ITEMS),
            "کفش‌فروشی": ("👟 کاتالوگ حرفه‌ای کفش، برند و سایز", self.SHOES_ITEMS),
        }
        title, items = configs[catalog_type]
        self._current_list_source=items
        head=tk.Frame(self.main,bg=bg); head.pack(fill="x",padx=20,pady=(12,5))
        RTLLabel(head,text=title,bg=bg,fg="#1B2733",font=ui_font(20,"bold")).pack(side="right")
        RTLLabel(head,text=f"تعداد اقلام آماده: {len(items)} | جستجو، قیمت‌گذاری و ورود مستقیم به انبار",bg=bg,fg="#687582",font=ui_font(9)).pack(side="left",pady=8)
        bar=tk.Frame(self.main,bg=bg); bar.pack(fill="x",padx=20,pady=5)
        self.button(bar,"↩ برگشت به دکان‌ها",self.businesses_page,"#687582").pack(side="left")
        q=tk.StringVar(); ent=tk.Entry(bar,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10),justify="right")
        ent.pack(side="right",fill="x",expand=True,padx=8,ipady=7)
        if catalog_type=="کفش‌فروشی":
            cols=("name","category","brands","sizes","details","price")
            heads={"name":"مدل / نوع","category":"دسته","brands":"برندها","sizes":"سایز پا","details":"جزئیات","price":"قیمت"}
            widths={"name":210,"category":120,"brands":260,"sizes":120,"details":300,"price":120}
        else:
            cols=("name","category","price","status")
            heads={"name":"نام کالا","category":"دسته","price":"قیمت ثبت‌شده","status":"وضعیت"}
            widths={"name":360,"category":220,"price":180,"status":300}
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        for c in cols:
            tree.heading(c,text=_icu_shape_arabic(heads[c])); tree.column(c,width=widths[c],anchor="center")
        catalog_holder=tk.Frame(self.main,bg=bg)
        catalog_holder.pack(fill="both",expand=True,padx=20,pady=8)
        catalog_bar=tk.Scrollbar(catalog_holder,orient="vertical",command=tree.yview,width=14)
        tree.configure(yscrollcommand=catalog_bar.set)
        tree.pack(side="left",fill="both",expand=True)
        catalog_bar.pack(side="right",fill="y")

        def populate(*_):
            tree.delete(*tree.get_children()); term=q.get().strip().lower()
            prices=self._retail_price_map(catalog_type,items)
            for name in items:
                if catalog_type=="کفش‌فروشی":
                    cat,detail=self._shoe_category_details(name)
                    brands="، ".join(self.SHOE_BRANDS)
                    sizes="۳۵ تا ۴۸ + نیم‌سایز"
                    hay=" ".join((name,cat,detail,brands,sizes)).lower()
                    if term and term not in hay: continue
                    vals=(_icu_shape_arabic(name),_icu_shape_arabic(cat),_icu_shape_arabic(brands),sizes,_icu_shape_arabic(detail),fmt_num(prices.get(name,0)))
                elif catalog_type=="داروخانه":
                    cat=self._medicine_category(name)
                    if term and term not in f"{name} {cat}".lower(): continue
                    vals=(_icu_shape_arabic(name),_icu_shape_arabic(cat),fmt_num(prices.get(name,0)),"آماده برای ثبت در انبار / فروش")
                else:
                    cat="میوه" if name in self.PRODUCE_ITEMS[:50] else "سبزیجات و صیفی‌جات"
                    if term and term not in f"{name} {cat}".lower(): continue
                    vals=(_icu_shape_arabic(name),cat,fmt_num(prices.get(name,0)),"آماده برای ثبت در انبار / فروش")
                tree.insert("","end",values=vals)
        populate(); q.trace_add("write",populate)

        actions=tk.Frame(self.main,bg=bg); actions.pack(fill="x",padx=20,pady=(0,10))
        self.button(actions,"💰 ثبت / تغییر قیمت",lambda:self._price_selected(tree,catalog_type),"#B58E45").pack(side="left",padx=4)
        self.button(actions,"📦 افزودن به انبار دکان",lambda:self._catalog_add_to_inventory(tree,catalog_type),"#0f766e").pack(side="left",padx=4)
        if catalog_type=="داروخانه":
            self.button(actions,"🌐 اطلاعات فارسی دارو",lambda:self._open_medicine_web(tree),"#2D7FA3").pack(side="left",padx=4)
        elif catalog_type=="کفش‌فروشی":
            self.button(actions,"👟 جزئیات برند و سایز",lambda:self._shoe_details_dialog(tree),"#2D7FA3").pack(side="left",padx=4)
        self.button(actions,"🧾 فروش فاکتوری",lambda:self.new_retail_sale(catalog_type,items),"#334155").pack(side="left",padx=4)

    def _catalog_selected_name(self, tree):
        sel=tree.selection()
        if not sel:
            messagebox.showinfo("کاتالوگ","ابتدا یک کالا را انتخاب کنید."); return None
        return str(tree.item(sel[0],"values")[0]).strip()

    def _catalog_add_to_inventory(self,tree,catalog_type):
        name=self._catalog_selected_name(tree)
        if not name:return
        bs=self.db.execute("SELECT id,name,business_type FROM businesses ORDER BY name").fetchall()
        if not bs:
            messagebox.showwarning("انبار","ابتدا یک دکان ثبت کنید."); return
        win=tk.Toplevel(self); win.title("افزودن کالا به انبار"); win.geometry("500x610"); win.minsize(470,570); win.configure(bg="#F4F6F8")
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=24,pady=18)
        def lab(t): RTLLabel(outer,text=t,bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",pady=(7,2))
        lab("دکان"); cb=LocalizedCombobox(outer,values=[f"{i} - {n} ({t})" for i,n,t in bs],state="readonly",justify="right"); cb.pack(fill="x",ipady=5); cb.current(0)
        lab("کالا"); RTLLabel(outer,text=name,bg="#FFFFFF",fg="#1B2733",font=ui_font(11,"bold"),anchor="e").pack(fill="x",ipady=8)
        lab("واحد"); units=["عدد","بسته","جعبه","کیلوگرم","تن"] if catalog_type!="میوه‌فروشی" else ["کیلوگرم","تن","عدد","بسته"]
        unit=LocalizedCombobox(outer,values=units,state="readonly",justify="right"); unit.pack(fill="x",ipady=5); unit.current(0)
        lab("موجودی"); qty=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); qty.pack(fill="x",ipady=7); qty.insert(0,"0")
        lab("حداقل موجودی"); mn=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); mn.pack(fill="x",ipady=7); mn.insert(0,"0")
        lab("قیمت خرید واحد"); cost=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); cost.pack(fill="x",ipady=7); cost.insert(0,"0")
        lab("قیمت فروش واحد"); sale=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); sale.pack(fill="x",ipady=7); sale.insert(0,fmt_num(self._retail_price(catalog_type,name)))
        lab("یادداشت / مشخصات"); notes=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); notes.pack(fill="x",ipady=7)
        if catalog_type=="کفش‌فروشی": notes.insert(0,"برند و سایز هنگام ثبت فروش در توضیحات وارد شود")
        def save():
            try:qv=D(qty.get()); minv=D(mn.get()); cp=D(cost.get() or 0); sp=D(sale.get() or 0)
            except Exception: messagebox.showerror("انبار","مقادیر عددی نامعتبر است.",parent=win); return
            if qv<0 or minv<0 or cp<0 or sp<0: messagebox.showwarning("انبار","مقادیر منفی مجاز نیست.",parent=win); return
            bid=bs[cb.current()][0]; now=datetime.now().strftime("%Y-%m-%d %H:%M")
            self.db.execute("""INSERT INTO shop_inventory(business_id,item_name,unit,quantity,min_quantity,cost_price,sale_price,currency,updated,notes) VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(business_id,item_name) DO UPDATE SET unit=excluded.unit,quantity=excluded.quantity,min_quantity=excluded.min_quantity,cost_price=excluded.cost_price,sale_price=excluded.sale_price,updated=excluded.updated,notes=excluded.notes""",
                (bid,name,unit.get(),float(qv),float(minv),float(cp),float(sp),"AFN - افغانی",now,notes.get().strip()))
            self.db.commit(); win.destroy(); self.shop_catalog_page(catalog_type)
        self.button(outer,"✓ ذخیره در انبار",save).pack(fill="x",pady=16,ipady=6)

    def _shoe_details_dialog(self,tree):
        name=self._catalog_selected_name(tree)
        if not name:return
        cat,detail=self._shoe_category_details(name)
        win=tk.Toplevel(self); win.title("جزئیات کفش"); win.geometry("560x430"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text=name,bg="#F4F6F8",fg="#1B2733",font=ui_font(18,"bold")).pack(pady=(18,8))
        lines=[("دسته",cat),("برندهای قابل ثبت", "، ".join(self.SHOE_BRANDS)),("سایزهای پا","۳۵ تا ۴۸ + نیم‌سایزهای ۳۵.۵ تا ۴۷.۵"),("جزئیات",detail),("نکته ثبت","برای هر برند/سایز می‌توان کالا را با مشخصات دقیق در انبار ثبت کرد.")]
        for k,v in lines:
            f=tk.Frame(win,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); f.pack(fill="x",padx=24,pady=3)
            RTLLabel(f,text=f"{k}: {v}",bg="#FFFFFF",fg="#1B2733",font=ui_font(9),wraplength=500,justify="right").pack(fill="x",padx=10,pady=7)
        self.button(win,"بستن",win.destroy,"#687582").pack(side="bottom",pady=12)

    def businesses_page(self):
        """Unified shop/warehouse control center - a short, simple toolbar
        so a non-technical shop owner can find the one thing they need
        right away, with less-common tools tucked behind two small menus.
        """
        self.clear()
        bg="#F4F6F8"
        head=tk.Frame(self.main,bg=bg); head.pack(fill="x",padx=20,pady=(12,4))
        RTLLabel(head,text="دکان‌ها و انبار",bg=bg,fg="#1B2733",font=ui_font(20,"bold")).pack(side="right")
        RTLLabel(head,text="مدیریت ساده‌ی دکان، کالا و فاکتور",bg=bg,fg="#687582",font=ui_font(9)).pack(side="left",pady=8)

        toolbar=tk.Frame(self.main,bg=bg); toolbar.pack(fill="x",padx=20,pady=6)
        self.button(toolbar,"＋ دکان جدید",self.add_business).pack(side="left")
        self.button(toolbar,"↔ خرید یا فروش کالا",self.add_business_transaction).pack(side="left",padx=5)
        self.button(toolbar,"🧾 فروش فاکتوری",lambda:self.new_retail_sale("دکان",self.ELECTRONICS_ITEMS)).pack(side="left",padx=5)
        self.button(toolbar,"📋 مرکز فاکتورها",self.shops_invoice_center_page,"#2D7FA3").pack(side="left",padx=5)

        def popup_menu(anchor_btn, items):
            # Small, native dropdown so rarely-used tools don't crowd the toolbar.
            menu=tk.Menu(anchor_btn,tearoff=0,font=ui_font(10))
            for text,cmd in items:
                menu.add_command(label=text,command=cmd)
            def show(e=None):
                try: menu.tk_popup(anchor_btn.winfo_rootx(), anchor_btn.winfo_rooty()+anchor_btn.winfo_height()+2)
                finally:
                    try: menu.grab_release()
                    except Exception: pass
            anchor_btn.configure(command=show)

        catalog_btn=self.button(toolbar,"📚 کاتالوگ کالا  ▾",None,"#8B5CF6")
        catalog_btn.pack(side="left",padx=5)
        popup_menu(catalog_btn,[
            ("💊 داروخانه",lambda:self.shop_catalog_page("داروخانه")),
            ("🍎 میوه و سبزی",lambda:self.shop_catalog_page("میوه‌فروشی")),
            ("👟 کفش‌فروشی",lambda:self.shop_catalog_page("کفش‌فروشی")),
        ])

        more_btn=self.button(toolbar,"⋯ ابزار بیشتر  ▾",None,"#475569")
        more_btn.pack(side="left",padx=5)
        popup_menu(more_btn,[
            ("＋ ورود موجودی",self.add_shop_inventory),
            ("🧾 همه فاکتورها",lambda:self.shops_invoice_center_page()),
            ("🧾 فاکتورهای دکان انتخاب‌شده",lambda:self.shop_invoices_selected(tree)),
            ("📊 گزارش دکان انتخاب‌شده",lambda:self.shop_summary_selected(tree)),
            ("📊 خروجی Excel",lambda:self.export_tree_csv(tree,"دکان‌ها.csv")),
        ])

        q=tk.StringVar(); ent=tk.Entry(toolbar,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10),justify="right")
        ent.pack(side="right",fill="x",expand=True,padx=(8,0),ipady=7)

        stats=tk.Frame(self.main,bg=bg); stats.pack(fill="x",padx=20,pady=4)
        total=self.db.execute("SELECT COUNT(*) FROM businesses").fetchone()[0] or 0
        tx=self.db.execute("SELECT COUNT(*) FROM business_transactions").fetchone()[0] or 0
        stock_items=self.db.execute("SELECT COUNT(*) FROM shop_inventory WHERE quantity>0").fetchone()[0] or 0
        low=self.db.execute("SELECT COUNT(*) FROM shop_inventory WHERE quantity<=min_quantity").fetchone()[0] or 0
        for i,(t,v) in enumerate([("دکان‌ها",total),("معاملات",tx),("اقلام انبار",stock_items),("موجودی کم",low)]): self.card(stats,t,str(v),0,i)

        outer=tk.Frame(self.main,bg=bg); outer.pack(fill="both",expand=True,padx=20,pady=8)
        cols=("id","name","type","items","sales","buys","debt","balance")
        tree=ttk.Treeview(outer,columns=cols,show="headings", style="Jahan.Treeview")
        heads={"id":"#","name":"نام دکان","type":"نوع","items":"اقلام انبار","sales":"فروش کالا","buys":"خرید کالا","debt":"قرض مشتریان","balance":"مانده دکان"}
        widths={"id":45,"name":180,"type":125,"items":100,"sales":130,"buys":130,"debt":140,"balance":140}
        for c in cols:
            tree.heading(c,text=_icu_shape_arabic(heads[c])); tree.column(c,width=widths[c],anchor="center")
        vs=tk.Scrollbar(outer,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=vs.set)
        vs.pack(side="right",fill="y"); tree.pack(side="left",fill="both",expand=True)

        def rows():
            out=[]
            for bid,name,btype in self.db.execute("SELECT id,name,business_type FROM businesses ORDER BY name").fetchall():
                items=self.db.execute("SELECT COUNT(*) FROM shop_inventory WHERE business_id=? AND quantity>0",(bid,)).fetchone()[0] or 0
                sales=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM business_transactions WHERE business_id=? AND kind='فروش'",(bid,)).fetchone()[0] or 0
                buys=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM business_transactions WHERE business_id=? AND kind='خرید'",(bid,)).fetchone()[0] or 0
                debt=self.db.execute("SELECT COALESCE(SUM(debt),0) FROM retail_sales WHERE business_name=?",(name,)).fetchone()[0] or 0
                out.append((bid,name,btype,items,D(sales),D(buys),D(debt),D(sales)-D(buys)))
            return out

        def populate(*_):
            term=q.get().strip().lower(); tree.delete(*tree.get_children())
            for r in rows():
                if term and term not in " ".join(str(x or "") for x in r).lower(): continue
                tree.insert("","end",values=(r[0],r[1],r[2],r[3],fmt_money_exact(r[4]),fmt_money_exact(r[5]),fmt_money_exact(r[6]),fmt_money_exact(r[7])))
        populate(); q.trace_add("write",populate)
        tree.bind("<Double-1>",lambda e:self.business_account(tree))
        RTLLabel(self.main,text="دو بار کلیک: دفتر کامل دکان | ستون‌ها برای سنجش موجودی و گردش مالی هستند.",bg=bg,fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))

    def shop_summary_selected(self,tree):
        sel=tree.selection()
        if not sel:
            messagebox.showinfo("گزارش دکان","یک دکان را انتخاب کنید."); return
        bid=int(tree.item(sel[0],"values")[0])
        row=self.db.execute("SELECT name FROM businesses WHERE id=?",(bid,)).fetchone()
        if row: self.business_account(tree)

    def add_shop_inventory(self):
        bs=self.db.execute("SELECT id,name,business_type FROM businesses ORDER BY name").fetchall()
        if not bs:
            messagebox.showwarning("انبار","ابتدا یک دکان ثبت کنید."); return
        win=tk.Toplevel(self); win.title("ورود / اصلاح موجودی انبار"); win.geometry("520x610"); win.minsize(480,560); win.configure(bg="#F4F6F8")
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=24,pady=18)
        def lab(t): RTLLabel(outer,text=t,bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",pady=(7,2))
        lab("دکان"); cb=LocalizedCombobox(outer,values=[f"{i} - {n} ({t})" for i,n,t in bs],state="readonly",justify="right"); cb.pack(fill="x",ipady=5); cb.current(0)
        lab("نام کالا"); item=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); item.pack(fill="x",ipady=7)
        lab("واحد"); unit=LocalizedCombobox(outer,values=["عدد","کیلوگرم","تن","بسته","جعبه","متر","لیتر"],state="readonly",justify="right"); unit.pack(fill="x",ipady=5); unit.current(0)
        lab("مقدار فعلی / مقدار جدید"); qty=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); qty.pack(fill="x",ipady=7)
        lab("حداقل موجودی هشدار"); minq=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); minq.pack(fill="x",ipady=7); minq.insert(0,"0")
        lab("قیمت خرید واحد"); cost=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); cost.pack(fill="x",ipady=7); cost.insert(0,"0")
        lab("قیمت فروش واحد"); sale=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); sale.pack(fill="x",ipady=7); sale.insert(0,"0")
        lab("ارز"); cur=LocalizedCombobox(outer,values=CURRENCIES,state="readonly",justify="right"); cur.pack(fill="x",ipady=5); cur.current(0)
        lab("یادداشت"); notes=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); notes.pack(fill="x",ipady=7)
        def save():
            try:
                name=item.get().strip(); qv=D(qty.get()); mn=D(minq.get() or 0); cp=D(cost.get() or 0); sp=D(sale.get() or 0)
            except Exception:
                messagebox.showerror("انبار","مقادیر عددی نامعتبر است.",parent=win); return
            if not name or qv<0 or mn<0 or cp<0 or sp<0:
                messagebox.showwarning("انبار","نام کالا و مقادیر معتبر را وارد کنید.",parent=win); return
            bid=bs[cb.current()][0]; now=datetime.now().strftime("%Y-%m-%d %H:%M")
            self.db.execute("""INSERT INTO shop_inventory(business_id,item_name,unit,quantity,min_quantity,cost_price,sale_price,currency,updated,notes) VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(business_id,item_name) DO UPDATE SET unit=excluded.unit,quantity=excluded.quantity,min_quantity=excluded.min_quantity,cost_price=excluded.cost_price,sale_price=excluded.sale_price,currency=excluded.currency,updated=excluded.updated,notes=excluded.notes""",(bid,name,unit.get(),float(qv),float(mn),float(cp),float(sp),cur.get(),now,notes.get().strip()))
            self.db.commit(); win.destroy(); self.businesses_page()
        self.button(outer,"✓ ذخیره موجودی",save).pack(fill="x",pady=16,ipady=5)

    def add_business_transaction(self):
        bs=self.db.execute("SELECT id,name,business_type FROM businesses ORDER BY name").fetchall()
        if not bs: messagebox.showwarning("دوکان‌ها","ابتدا یک دوکان ثبت کنید."); return
        win=tk.Toplevel(self); win.title("ثبت خرید / فروش دوکان"); win.geometry("500x560"); win.minsize(470,530); win.configure(bg="#F4F6F8")
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=22,pady=18)
        def lab(t): RTLLabel(outer,text=t,bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",pady=(7,2))
        lab("دوکان"); cb=LocalizedCombobox(outer,values=[f"{i} - {n} ({t})" for i,n,t in bs],state="readonly",justify="right"); cb.pack(fill="x",ipady=4); cb.current(0)
        lab("نوع معامله کالا"); kind=LocalizedCombobox(outer,values=["فروش کالا","خرید کالا"],state="readonly",justify="right"); kind.pack(fill="x",ipady=4); kind.current(0)
        lab("مبلغ معامله (افغانی)"); amount=tk.Entry(outer,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); amount.pack(fill="x",ipady=7)
        lab("مشتری (اختیاری)"); customers=self.db.execute("SELECT id,name,phone FROM customers ORDER BY name").fetchall(); customer=LocalizedCombobox(outer,values=[f"{i} - {n}" for i,n,p in customers],state="readonly",justify="right"); customer.pack(fill="x",ipady=4)
        lab("توضیحات"); notes=tk.Entry(outer,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); notes.pack(fill="x",ipady=7)
        def save():
            try: val=D(amount.get())
            except Exception: messagebox.showerror("خطا","مبلغ معامله باید عددی باشد.",parent=win); return
            if val<=0: messagebox.showerror("خطا","مبلغ معامله باید بیشتر از صفر باشد.",parent=win); return
            bid,name,btype=bs[cb.current()]; cid=None; cname=""
            if customer.current()>=0 and customers: cid,cname,_=customers[customer.current()]
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            normalized_kind="فروش" if kind.get()=="فروش کالا" else "خرید"
            curx=self.db.execute("INSERT INTO business_transactions(created,business_id,business_name,business_type,kind,amount,notes,currency,rate,afn_amount,customer_id,source_type) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(now,bid,name,btype,normalized_kind,float(val),notes.get().strip(),"AFN - افغانی",1.0,float(val),cid,"shop"))
            txid=curx.lastrowid
            self.db.execute("INSERT INTO transactions(created,kind,currency,amount,rate,afn_amount,customer,notes,customer_id,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(now,normalized_kind,"AFN - افغانی",float(val),1.0,float(val),cname,f"دوکان: {name} | ثبت #{txid}",cid,'shop',txid))
            if cid:
                etype="قرضداری مشتری" if normalized_kind=="فروش" else "بستانکاری مشتری"
                self.db.execute("INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(now,cid,cname,etype,float(val),f"دوکان {name} | معامله #{txid}","AFN - افغانی",1.0,float(val),"shop",txid))
            self.db.commit(); win.destroy(); self.businesses_page()
        self.button(outer,"✓ ثبت معامله",save).pack(fill="x",pady=18,ipady=4)

    def add_fruit_inventory(self):
        win=tk.Toplevel(self); win.title("ورود موجودی میوه و سبزی"); win.geometry("500x480"); win.minsize(460,440); win.configure(bg="#F4F6F8")
        outer=tk.Frame(win,bg="#F4F6F8"); outer.pack(fill="both",expand=True,padx=24,pady=18)
        def lab(t): RTLLabel(outer,text=t,bg="#F4F6F8",fg="#1B2733",font=ui_font(10,"bold")).pack(anchor="e",pady=(7,2))
        lab("نام میوه / سبزی"); name=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); name.pack(fill="x",ipady=7)
        lab("موجودی (کیلوگرم)"); qty=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); qty.pack(fill="x",ipady=7)
        lab("قیمت هر کیلو"); price=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); price.pack(fill="x",ipady=7)
        lab("یادداشت"); notes=tk.Entry(outer,bg="white",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right"); notes.pack(fill="x",ipady=7)
        def save():
            try:q=D(qty.get()); p=D(price.get())
            except Exception:messagebox.showerror("انبار","مقدار و قیمت باید عددی باشد.",parent=win);return
            n=name.get().strip()
            if not n or q<0 or p<0:messagebox.showwarning("انبار","نام و مقادیر معتبر را وارد کنید.",parent=win);return
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            row=self.db.execute("SELECT id FROM fruit_inventory WHERE fruit_name=? ORDER BY id LIMIT 1",(n,)).fetchone()
            if row:self.db.execute("UPDATE fruit_inventory SET quantity_kg=?,unit_price=?,updated=?,notes=? WHERE id=?",(float(q),float(p),now,notes.get().strip(),row[0]))
            else:self.db.execute("INSERT INTO fruit_inventory(fruit_name,quantity_kg,unit_price,updated,notes) VALUES(?,?,?,?,?)",(n,float(q),float(p),now,notes.get().strip()))
            self.db.commit();win.destroy();self.fruits_page()
        self.button(outer,"✓ ثبت موجودی",save).pack(fill="x",pady=16,ipady=5)

    def fruits_page(self):
        self.clear()
        RTLLabel(self.main,text="انبار میوه و سبزی",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=(12,6))
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=5)
        self.button(bar,"＋ ورود موجودی",self.add_fruit_inventory).pack(side="left")
        self.button(bar,"🧾 فروش از انبار",lambda:self.new_retail_sale("میوه‌فروشی",self.PRODUCE_ITEMS)).pack(side="left",padx=6)
        self.button(bar,"🧾 فاکتورهای میوه",lambda:self.shops_invoice_center_page(),"#475569").pack(side="left",padx=6)
        q=tk.StringVar(); tk.Entry(bar,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",justify="right").pack(side="right",fill="x",expand=True,padx=(8,0),ipady=7)
        cols=("name","qty","ton","price","value","updated"); tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads={"name":"نام کالا","qty":"موجودی (کیلو)","ton":"تن","price":"قیمت / کیلو","value":"ارزش موجودی","updated":"آخرین بروزرسانی"}
        for c in cols: tree.heading(c,text=_icu_shape_arabic(heads[c])); tree.column(c,width=150 if c!="name" else 220,anchor="center")
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        rows=self.db.execute("SELECT fruit_name,quantity_kg,unit_price,updated FROM fruit_inventory ORDER BY fruit_name").fetchall()
        def fill(*_):
            term=q.get().strip().lower(); tree.delete(*tree.get_children())
            for n,kg,price,updated in rows:
                if term and term not in n.lower(): continue
                tree.insert("","end",values=(n,fmt_num(kg),fmt_num(D(kg)/D(1000)),fmt_num(price),fmt_num(D(kg)*D(price)),updated))
        fill(); q.trace_add("write",fill)

    def business_account(self,tree):
        sel=tree.selection()
        if not sel:return
        bid=int(tree.item(sel[0],"values")[0]); row=self.db.execute("SELECT name,business_type,phone,address,notes FROM businesses WHERE id=?",(bid,)).fetchone()
        if not row:return
        win=tk.Toplevel(self); win.title("دفتر دوکان - "+row[0]); win.geometry("1000x680"); win.minsize(850,560); win.configure(bg="#F4F6F8")
        RTLLabel(win,text=f"دفتر {row[1]}: {row[0]}",bg="#F4F6F8",fg="#1B2733",font=ui_font(18,"bold")).pack(anchor="e",padx=20,pady=12)
        info=tk.Frame(win,bg="#F4F6F8"); info.pack(fill="x",padx=15)
        currencies=[r[0] for r in self.db.execute("SELECT DISTINCT currency FROM business_transactions WHERE business_id=? ORDER BY currency",(bid,)).fetchall()] or [CURRENCIES[0]]
        for i,cur in enumerate(currencies):
            sales=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM business_transactions WHERE business_id=? AND kind='فروش' AND currency=?",(bid,cur)).fetchone()[0] or 0
            buys=self.db.execute("SELECT COALESCE(SUM(amount),0) FROM business_transactions WHERE business_id=? AND kind='خرید' AND currency=?",(bid,cur)).fetchone()[0] or 0
            self.card(info,f"مانده {self._shop_currency_label(cur)}",f"{fmt_money_exact(D(sales)-D(buys))} {self._shop_currency_label(cur)}",0,i)
        cols=("date","kind","currency","amount","customer","notes"); tr=ttk.Treeview(win,columns=cols,show="headings")
        heads={"date":"تاریخ","kind":"نوع","currency":"ارز","amount":"مبلغ","customer":"مشتری","notes":"توضیحات"}
        for x in cols: tr.heading(x,text=_icu_shape_arabic(heads[x])); tr.column(x,width=115,anchor="center")
        tr.pack(fill="both",expand=True,padx=15,pady=10)
        for r in self.db.execute("SELECT bt.created,bt.kind,bt.currency,bt.amount,COALESCE(c.name,''),bt.notes FROM business_transactions bt LEFT JOIN customers c ON c.id=bt.customer_id WHERE bt.business_id=? ORDER BY bt.id DESC",(bid,)):
            tr.insert("","end",values=(r[0],r[1],self._shop_currency_label(r[2]),fmt_num(r[3]),r[4],r[5]))
        self.button(win,"✕ بستن",win.destroy,"#687582").pack(side="bottom",pady=(0,12))

    def _export_xlsx_rows(self, path, headers, rows, title="", include_outgoing_profile=False):
        """Create a polished RTL Persian Excel workbook without converting currencies."""
        if not OPENPYXL_OK:
            raise RuntimeError("کتابخانه openpyxl نصب نیست. لطفاً Build/نصب برنامه را دوباره اجرا کنید.")
        path=os.path.splitext(path)[0] + ".xlsx"
        wb=Workbook()
        ws=wb.active
        ws.title="گزارش"
        ws.sheet_view.rightToLeft=True
        ws.freeze_panes="A4"
        ws.sheet_view.showGridLines=False
        ws.sheet_properties.pageSetUpPr.fitToPage=True
        ws.page_setup.orientation="landscape"
        ws.page_setup.fitToWidth=1
        ws.page_setup.fitToHeight=0
        last_col=max(1,len(headers))
        ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=last_col)
        c=ws.cell(1,1,title or APP_NAME)
        c.font=Font(name="Tahoma",size=16,bold=True,color="FFFFFF")
        c.fill=PatternFill("solid",fgColor="17324D")
        c.alignment=Alignment(horizontal="right",vertical="center")
        ws.row_dimensions[1].height=28
        ws.merge_cells(start_row=2,start_column=1,end_row=2,end_column=last_col)
        if include_outgoing_profile:
            op=self._outgoing_profile_dict()
            profile=" | ".join(x for x in (op.get("outgoing_name"),op.get("outgoing_type"),op.get("outgoing_phone"),op.get("outgoing_address")) if x)
            m=ws.cell(2,1,profile or f"نسخه {APP_VERSION} | تاریخ خروجی: {datetime.now():%Y-%m-%d %H:%M}")
        else:
            m=ws.cell(2,1,f"{APP_NAME} | نسخه {APP_VERSION} | تاریخ خروجی: {datetime.now():%Y-%m-%d %H:%M}")
        m.font=Font(name="Tahoma",size=10,color="666666")
        m.alignment=Alignment(horizontal="right",vertical="center")
        ws.row_dimensions[2].height=20
        thin=Side(style="thin",color="D7DEE7")
        border=Border(left=thin,right=thin,top=thin,bottom=thin)
        header_fill=PatternFill("solid",fgColor="256D85")
        alt_fill=PatternFill("solid",fgColor="F4F8FA")
        for j,h in enumerate(headers,1):
            cell=ws.cell(3,j,str(h))
            cell.font=Font(name="Tahoma",size=11,bold=True,color="FFFFFF")
            cell.fill=header_fill
            cell.alignment=Alignment(horizontal="right",vertical="center",wrap_text=True)
            cell.border=border
        ws.row_dimensions[3].height=25
        for i,row in enumerate(rows,4):
            for j,val in enumerate(row,1):
                cell=ws.cell(i,j,val)
                cell.font=Font(name="Tahoma",size=10,color="222222")
                cell.alignment=Alignment(horizontal="right",vertical="center",wrap_text=True)
                cell.border=border
                if i % 2 == 0:
                    cell.fill=alt_fill
                if isinstance(val,(int,float,Decimal)):
                    cell.number_format='#,##0.##'
        end_row=max(3,3+len(rows))
        if rows and last_col:
            ref=f"A3:{get_column_letter(last_col)}{end_row}"
            tab=Table(displayName="JahanReport",ref=ref)
            tab.tableStyleInfo=TableStyleInfo(name="TableStyleMedium2",showFirstColumn=False,showLastColumn=False,showRowStripes=True,showColumnStripes=False)
            ws.add_table(tab)
            ws.auto_filter.ref=ref
        for j,h in enumerate(headers,1):
            max_len=len(str(h))
            for i in range(4,end_row+1):
                v=ws.cell(i,j).value
                if v is not None:
                    max_len=max(max_len,len(str(v)))
            width=min(max(max_len+3,12),42)
            if any(k in str(h) for k in ("توضیحات","آدرس","نام مشتری","مشتری")):
                width=max(width,22)
            ws.column_dimensions[get_column_letter(j)].width=width
        ws.auto_filter.ref=f"A3:{get_column_letter(last_col)}{end_row}"
        ws.print_title_rows="1:3"
        ws.page_margins.left=0.25; ws.page_margins.right=0.25
        ws.page_margins.top=0.5; ws.page_margins.bottom=0.5
        wb.save(path)
        return path

    def export_tree_csv(self, tree, default_filename):
        """Professional Excel export; legacy method name retained for compatibility."""
        base=os.path.splitext(default_filename)[0] + ".xlsx"
        path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel Workbook","*.xlsx")],initialfile=base)
        if not path: return
        cols=tree["columns"]
        headers=[str(tree.heading(c,"text") or c) for c in cols]
        rows=[tree.item(iid,"values") for iid in tree.get_children()]
        try:
            out=self._export_xlsx_rows(path,headers,rows,title=os.path.splitext(default_filename)[0])
            messagebox.showinfo("خروجی Excel",f"فایل حرفه‌ای Excel ذخیره شد:\n{out}")
        except Exception as e:
            messagebox.showerror("خروجی Excel",str(e))

    def export_csv(self):
        """Export latest transactions as a real styled XLSX workbook."""
        path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel Workbook","*.xlsx")],initialfile="گزارش_معاملات.xlsx")
        if not path:return
        rows=self.db.execute("SELECT id,created,kind,currency,amount,customer,notes FROM transactions ORDER BY id DESC").fetchall()
        try:
            out=self._export_xlsx_rows(path,["شماره","تاریخ و زمان","نوع معامله","ارز","مبلغ اصلی","مشتری","توضیحات"],rows,title="گزارش معاملات")
            messagebox.showinfo("خروجی Excel",f"گزارش Excel ذخیره شد:\n{out}")
        except Exception as e:
            messagebox.showerror("خروجی Excel",str(e))

    def receipt_page(self):
        self.clear()
        RTLLabel(self.main,text="رسید آخرین معامله",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        row=self.db.execute("""SELECT id,created,kind,currency,amount,rate,afn_amount,customer,notes
                               FROM transactions ORDER BY id DESC LIMIT 1""").fetchone()
        box=tk.Frame(self.main,bg="white"); box.pack(padx=100,pady=20,fill="both",expand=True)
        if not row:
            RTLLabel(box,text="هنوز معامله‌ای ثبت نشده است.",bg="white",fg="#222",font=ui_font(14)).pack(pady=60); return
        texts=[APP_NAME,"--------------------------------",f"شماره رسید: {row[0]}",
               f"تاریخ شمسی: {dual_datetime(row[1])}",f"مشتری: {row[7]}",f"نوع معامله: {row[2]}",
               f"ارز: {row[3]}",f"مبلغ: {fmt_num(row[4])} {row[3]}",f"توضیحات: {row[8]}",
               "--------------------------------","با تشکر از اعتماد شما"]
        RTLLabel(box,text="\n".join(texts),bg="white",fg="#111",font=ui_font(13),
                 justify="right",anchor="e").pack(fill="both",expand=True,padx=30,pady=30)
        self.button(self.main,"🖨 چاپ / ذخیره رسید",lambda:self.save_receipt(row)).pack(pady=10)

    def save_receipt(self,row):
        path=filedialog.asksaveasfilename(defaultextension=".html",filetypes=[("HTML","*.html")],
                                          initialfile=f"رسید_{row[0]}.html")
        if not path:return
        html=f"""<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>رسید {row[0]}</title>
        <style>body{{font-family:"B Nazanin", Tahoma, sans-serif;background:#eee;padding:40px}}.r{{max-width:650px;margin:auto;background:#fff;padding:35px;border-radius:14px}}
        h1{{color:#087fe8}}p{{font-size:18px;border-bottom:1px solid #ddd;padding:9px}}</style>
        <div class="r"><h1>{APP_NAME}</h1><p>شماره رسید: {row[0]}</p><p>تاریخ: {dual_datetime(row[1])}</p><p>مشتری: {row[7]}</p>
        <p>نوع معامله: {row[2]}</p><p>ارز: {row[3]}</p><p>مبلغ: {fmt_num(row[4])} {row[3]}</p>
        <p>توضیحات: {row[8]}</p><h3>با تشکر از اعتماد شما</h3></div>"""
        with open(path,"w",encoding="utf-8") as f:f.write(html)
        webbrowser.open("file://"+os.path.abspath(path))

    def remittances_page(self):
        self.clear()
        RTLLabel(self.main,text="💸 مدیریت حواله پول",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=12)
        bar=tk.Frame(self.main,bg="#F4F6F8"); bar.pack(fill="x",padx=20,pady=5)
        q=tk.StringVar()
        qent=tk.Entry(bar,textvariable=q,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10))
        qent.pack(side="right",fill="x",expand=True,padx=5,ipady=7)
        self.button(bar,"🔎 جستجوی حرفه‌ای",lambda:load()).pack(side="right")
        self.button(bar,"＋ حواله جدید",self.add_remittance).pack(side="left")
        cols=("no","date","sender","sphone","receiver","rphone","province","country","currency","amount","fee","status")
        tree=ttk.Treeview(self.main,columns=cols,show="headings")
        heads={"no":"نمبر حواله","date":"تاریخ","sender":"فرستنده","sphone":"تماس فرستنده","receiver":"گیرنده","rphone":"تماس گیرنده","province":"استان/ولایت گیرنده","country":"مقصد","currency":"ارز","amount":"مبلغ","fee":"کمیشن","status":"وضعیت"}
        for x in cols: tree.heading(x,text=_display_text(heads[x])); tree._jahan_original_headings = heads; tree.column(x,width=105,anchor="center")
        tree.column("no",width=125); tree.column("sender",width=150); tree.column("receiver",width=150)
        self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        def load():
            for i in tree.get_children(): tree.delete(i)
            term=q.get().strip()
            like=f"%{term}%"
            rows=self.db.execute("""SELECT transfer_no,created,sender_name||' '||COALESCE(sender_surname,''),sender_phone,
                receiver_name||' '||COALESCE(receiver_surname,''),receiver_phone,receiver_province,destination_country,currency,amount,fee,status FROM remittances
                WHERE transfer_no LIKE ? OR sender_name LIKE ? OR sender_surname LIKE ? OR sender_phone LIKE ? OR receiver_name LIKE ?
                OR receiver_surname LIKE ? OR receiver_phone LIKE ? OR sender_province LIKE ? OR receiver_province LIKE ? OR destination_country LIKE ? OR status LIKE ?
                ORDER BY id DESC""",(like,like,like,like,like,like,like,like,like,like,like)).fetchall()
            for r in rows: tree.insert("","end",values=(r[0],r[1],r[2].strip(),r[3],r[4].strip(),r[5],r[6],r[7],r[8],f"{fmt_num(r[9])}",f"{fmt_num(r[10])}",r[11]))
        qent.bind("<Return>",lambda e:load()); load()
        self.button(self.main,"📋 فهرست ولایت‌های افغانستان و استان‌های ایران",self.provinces_page,"#475569").pack(pady=8)

    def add_remittance(self):
        win=tk.Toplevel(self); win.title("ثبت حواله جدید"); win.geometry("780x720"); win.configure(bg="#F4F6F8")
        labels=["نمبر حواله","کشور مقصد","نام فرستنده","تخلص فرستنده","شماره تماس فرستنده","ولایت/استان فرستنده","نام گیرنده","تخلص گیرنده","شماره تماس گیرنده","ولایت/استان گیرنده","ارز","مبلغ","کمیشن","وضعیت","یادداشت"]
        vars={x:tk.StringVar() for x in labels}; vars["وضعیت"].set("ثبت شده"); vars["ارز"].set(CURRENCIES[0]); vars["کشور مقصد"].set("ایران")
        form=tk.Frame(win,bg="#F4F6F8"); form.pack(fill="both",expand=True,padx=18,pady=10)
        widgets={}
        for i,lab in enumerate(labels):
            r,c=divmod(i,2); cell=tk.Frame(form,bg="#F4F6F8"); cell.grid(row=r,column=c,padx=8,pady=7,sticky="ew"); form.columnconfigure(c,weight=1)
            RTLLabel(cell,text=lab,bg="#F4F6F8",fg="#C7CFD7",font=ui_font(9)).pack(anchor="e")
            if lab=="کشور مقصد": w=LocalizedCombobox(cell,textvariable=vars[lab],values=["ایران","افغانستان"],state="readonly")
            elif lab in ("ولایت/استان فرستنده","ولایت/استان گیرنده"):
                # Always keep the complete official lists available; Nimroz is explicitly present.
                initial=PROVINCES if lab=="ولایت/استان فرستنده" else (IRAN_PROVINCES if vars["کشور مقصد"].get()=="ایران" else PROVINCES)
                w=LocalizedCombobox(cell,textvariable=vars[lab],values=tuple(initial),state="readonly")
                if lab=="ولایت/استان گیرنده":
                    receiver_var=vars[lab]
                    def update_provinces(event=None, combo=w, target_var=receiver_var):
                        vals=IRAN_PROVINCES if vars["کشور مقصد"].get()=="ایران" else PROVINCES
                        combo["values"]=tuple(vals)
                        target_var.set("")
                    # Bind after the country combobox has definitely been created.
                    if "کشور مقصد" in widgets:
                        widgets["کشور مقصد"].bind("<<ComboboxSelected>>", update_provinces)
            elif lab=="ارز": w=LocalizedCombobox(cell,textvariable=vars[lab],values=CURRENCIES,state="readonly")
            elif lab=="وضعیت": w=LocalizedCombobox(cell,textvariable=vars[lab],values=["ثبت شده","در انتظار پرداخت","پرداخت شده","لغو شده"],state="readonly")
            else: w=tk.Entry(cell,textvariable=vars[lab],bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3")
            w.pack(fill="x",ipady=6); widgets[lab]=w
        def save():
            no=vars["نمبر حواله"].get().strip() or ("HW"+datetime.now().strftime("%Y%m%d%H%M%S"))
            required=["نام فرستنده","شماره تماس فرستنده","نام گیرنده","شماره تماس گیرنده","مبلغ"]
            if any(not vars[x].get().strip() for x in required): messagebox.showwarning("حواله","نام و شماره تماس فرستنده/گیرنده و مبلغ الزامی است."); return
            try: amount=float(D(vars["مبلغ"].get())); fee=float(D(vars["کمیشن"].get() or 0))
            except: messagebox.showerror("حواله","مبلغ و کمیشن باید عددی باشند."); return
            if amount<=0 or fee<0: messagebox.showerror("حواله","مبلغ یا کمیشن نامعتبر است."); return
            try:
                self.db.execute("""INSERT INTO remittances(transfer_no,created,sender_name,sender_surname,sender_phone,sender_province,receiver_name,receiver_surname,receiver_phone,receiver_province,currency,amount,fee,total,status,notes,destination_country)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(no,datetime.now().strftime("%Y-%m-%d %H:%M"),vars["نام فرستنده"].get().strip(),vars["تخلص فرستنده"].get().strip(),vars["شماره تماس فرستنده"].get().strip(),vars["ولایت/استان فرستنده"].get(),vars["نام گیرنده"].get().strip(),vars["تخلص گیرنده"].get().strip(),vars["شماره تماس گیرنده"].get().strip(),vars["ولایت/استان گیرنده"].get(),vars["ارز"].get(),amount,fee,amount+fee,vars["وضعیت"].get(),vars["یادداشت"].get().strip(),vars["کشور مقصد"].get()))
                self.db.commit()
            except sqlite3.IntegrityError: messagebox.showerror("حواله","این نمبر حواله قبلاً ثبت شده است."); return
            messagebox.showinfo("حواله",f"حواله {no} با موفقیت ثبت شد."); win.destroy(); self.remittances_page()
        self.button(win,"✓ ثبت حواله",save).pack(side="bottom",pady=14)

    def provinces_page(self):
        win=tk.Toplevel(self); win.title("ولایت‌های افغانستان و استان‌های ایران"); win.geometry("650x620"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="فهرست ۳۴ ولایت افغانستان + ۳۱ استان ایران",bg="#F4F6F8",fg="#35a9ff",font=ui_font(17,"bold")).pack(pady=15)
        q=tk.StringVar(); tk.Entry(win,textvariable=q,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3").pack(fill="x",padx=20,pady=5,ipady=7)
        tree=ttk.Treeview(win,columns=("country","no","province"),show="headings"); tree.heading("country",text="کشور"); tree.heading("no",text="#"); tree.heading("province",text=_icu_shape_arabic("ولایت / استان")); tree.column("country",width=130,anchor="center"); tree.column("no",width=70,anchor="center"); tree.column("province",width=300,anchor="center"); self._pack_with_scrollbar(tree, fill="both",expand=True,padx=20,pady=10)
        def load():
            for i in tree.get_children(): tree.delete(i)
            term=q.get().strip()
            for country,items in (("افغانستان",PROVINCES),("ایران",IRAN_PROVINCES)):
                for i,p in enumerate(items,1):
                    if term in p: tree.insert("","end",values=(country,i,p))
        q.trace_add("write",lambda *a:load()); load()

    def sync_page(self):
        self.start_sync_server()
        info=self.get_sync_connection_info()
        win=tk.Toplevel(self); win.title("همگام‌سازی Android ↔ Desktop"); win.geometry("650x520"); win.minsize(560,440); win.configure(bg="#F4F6F8"); win.transient(self); win.grab_set()
        RTLLabel(win,text="🔄 همگام‌سازی مستقیم با Android",bg="#F4F6F8",fg="#1B2733",font=ui_font(17,"bold")).pack(pady=(18,8))
        ips="\n".join(info["ips"]) or "IP شبکه پیدا نشد"
        txt=("این نسخه بدون سرور ابری کار می‌کند؛ خود کامپیوتر به‌عنوان نقطه اتصال داده‌ها عمل می‌کند.\n\n"
             f"پورت: {info['port']}\nIPهای کامپیوتر:\n{ips}\n\n"
             f"کد اتصال:\n{info['token']}\n\n"
             "در Android QR را اسکن کنید. هر دو دستگاه باید روی یک شبکه باشند. داده‌ها مستقیم بین PC و گوشی منتقل می‌شوند.")
        if QRCODE_OK and info["ips"]:
            try:
                payload=json.dumps({"ip":info["ips"][0],"port":info["port"],"token":info["token"]},ensure_ascii=False,separators=(",",":"))
                qr=qrcode.make(payload).convert("RGB")
                qr.thumbnail((260,260))
                from PIL import ImageTk
                qr_photo=ImageTk.PhotoImage(qr)
                qr_label=tk.Label(win,image=qr_photo,bg="#F4F6F8"); qr_label.image=qr_photo; qr_label.pack(pady=(2,6))
                RTLLabel(win,text="📱 QR اتصال Android",bg="#F4F6F8",fg="#D4AF37",font=ui_font(10,"bold")).pack(pady=(0,4))
            except Exception:
                pass
        text_holder=tk.Frame(win,bg="#FFFFFF"); text_holder.pack(fill="both",expand=True,padx=22,pady=10)
        box=tk.Text(text_holder,height=14,bg="#FFFFFF",fg="#1B2733",relief="flat",font=ui_font(10),wrap="word"); box_scroll=tk.Scrollbar(text_holder,orient="vertical",command=box.yview,width=12); box.configure(yscrollcommand=box_scroll.set)
        box_scroll.pack(side="right",fill="y"); box.pack(side="left",fill="both",expand=True); box.insert("1.0",txt); box.config(state="disabled")
        self.button(win,"🔄 آماده‌سازی اتصال",lambda: messagebox.showinfo("اتصال",f"سرور داخلی فعال است.\nپورت: {info['port']}\nکد: {info['token']}",parent=win)).pack(side="bottom",pady=10)

    def manage_user_page(self):
        win=tk.Toplevel(self); win.title("حساب کاربری من"); win.geometry("450x420"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="حساب کاربری و رمز عبور",bg="#F4F6F8",fg="#1B2733",font=ui_font(16,"bold")).pack(pady=20)
        fields=[]
        for lab,show in [("نام کاربری جدید",False),("رمز فعلی",True),("رمز جدید",True),("تکرار رمز جدید",True)]:
            RTLLabel(win,text=lab,bg="#F4F6F8",fg="#1B2733").pack(anchor="e",padx=25,pady=(7,2)); e=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",show="*" if show else ""); e.pack(fill="x",padx=25,ipady=7); fields.append(e)
        fields[0].insert(0,getattr(self,"current_username",""))
        def save():
            newu=fields[0].get().strip(); old,new1,new2=[x.get() for x in fields[1:]]
            current=getattr(self,"current_username","")
            row=self._find_login_user(current)
            ok,_=self._password_matches(row[2],old) if row else (False,"")
            if not row or not ok: messagebox.showerror("حساب","رمز فعلی نادرست است."); return
            if not newu: messagebox.showerror("حساب","نام کاربری جدید را وارد کنید."); return
            if not new1 or new1!=new2: messagebox.showerror("حساب","رمز جدید خالی است یا تکرار آن درست نیست."); return
            if len(new1) < 4: messagebox.showerror("حساب","رمز عبور نباید کمتر از ۴ کاراکتر باشد."); return
            try:
                self.db.execute("UPDATE users SET username=?, password_hash=? WHERE username=?",(newu,self.hash_password(new1),current)); self.db.commit()
            except sqlite3.IntegrityError:
                messagebox.showerror("حساب","این نام کاربری قبلاً استفاده شده است."); return
            self.current_username=newu; messagebox.showinfo("حساب","نام کاربری و رمز عبور با موفقیت تغییر کرد."); win.destroy()
        self.button(win,"✓ ذخیره نام کاربری و رمز عبور",save).pack(side="bottom",pady=20)

    def _web_snapshot(self):
        """JSON snapshot for the HTML/WebView Android companion.
        This deliberately transfers business data, not the raw SQLite file, so
        a plain HTML APK can sync without bundling a SQLite WASM engine.
        """
        self.db.commit()
        customers=[]
        for r in self.db.execute("SELECT id,name,phone,address,notes FROM customers ORDER BY id").fetchall():
            customers.append({"id":int(r[0]),"name":r[1] or "","phone":r[2] or "","address":r[3] or "","notes":r[4] or ""})
        entries=[]
        q="""SELECT id,created,customer_id,customer,entry_type,amount,notes,currency,rate,
                    COALESCE(commission,0),COALESCE(commission_currency,currency),COALESCE(route,'')
             FROM account_entries ORDER BY id"""
        try: rows=self.db.execute(q).fetchall()
        except Exception:
            rows=self.db.execute("SELECT id,created,customer_id,customer,entry_type,amount,notes,currency,rate,0,currency,'' FROM account_entries ORDER BY id").fetchall()
        for r in rows:
            entries.append({"id":int(r[0]),"created":r[1] or "","customerId":int(r[2]) if r[2] is not None else None,
                            "customer":r[3] or "","type":r[4] or "","amount":float(r[5] or 0),"note":r[6] or "",
                            "currency":r[7] or "","rate":float(r[8] or 1),"commission":float(r[9] or 0),"commissionCurrency":r[10] or r[7] or "","route":r[11] or ""})
        notes=[]
        for r in self.db.execute("SELECT id,title,content,created,updated FROM notebook_entries ORDER BY updated DESC,id DESC").fetchall():
            notes.append({"id":int(r[0]),"title":r[1] or "","text":r[2] or "","created":r[3] or "","updated":r[4] or ""})
        settings={"businessName":"حسابداری جهان","phone":"","details":""}
        try:
            vals={r[0]:r[1] for r in self.db.execute("SELECT key,value FROM app_settings WHERE key IN ('business_name','business_phone','business_details')").fetchall()}
            settings={"businessName":vals.get('business_name') or 'حسابداری جهان',"phone":vals.get('business_phone') or '',"details":vals.get('business_details') or ''}
        except Exception: pass
        return {"format":"JAHAN-WEB-SYNC","version":1,"settings":settings,"customers":customers,"entries":entries,"notes":notes,"invoices":[],"inventory":[]}

    def _web_merge(self, data):
        if not isinstance(data,dict) or data.get("format")!="JAHAN-WEB-SYNC":
            raise ValueError("داده ارسالی مربوط به حسابداری جهان نیست.")
        self.db.execute("CREATE TABLE IF NOT EXISTS web_sync_map(kind TEXT NOT NULL, remote_id TEXT NOT NULL, local_id INTEGER, PRIMARY KEY(kind,remote_id))")
        self.db.commit()
        # Customers: preserve PC IDs when they already exist, otherwise match by name+phone.
        for c in data.get("customers") or []:
            rid=str(c.get("id")); name=str(c.get("name") or "").strip(); phone=str(c.get("phone") or "").strip()
            if not rid or not name: continue
            m=self.db.execute("SELECT local_id FROM web_sync_map WHERE kind='customer' AND remote_id=?",(rid,)).fetchone()
            lid=int(m[0]) if m and m[0] else None
            if not lid:
                row=self.db.execute("SELECT id FROM customers WHERE name=? AND COALESCE(phone,'')=? ORDER BY id LIMIT 1",(name,phone)).fetchone()
                lid=int(row[0]) if row else None
            if lid:
                self.db.execute("UPDATE customers SET name=?,phone=?,address=?,notes=? WHERE id=?",(name,phone,c.get('address') or '',c.get('notes') or '',lid))
            else:
                cur=self.db.execute("INSERT INTO customers(name,phone,address,notes,balance) VALUES(?,?,?,?,0)",(name,phone,c.get('address') or '',c.get('notes') or '')); lid=int(cur.lastrowid)
            self.db.execute("INSERT OR REPLACE INTO web_sync_map(kind,remote_id,local_id) VALUES('customer',?,?)",(rid,lid))
        # Notebook: one-to-one by remote ID.
        for n in data.get("notes") or []:
            rid=str(n.get("id")); title=str(n.get("title") or "بدون عنوان"); content=str(n.get("text") or '')
            if not rid: continue
            m=self.db.execute("SELECT local_id FROM web_sync_map WHERE kind='note' AND remote_id=?",(rid,)).fetchone()
            if m:
                self.db.execute("UPDATE notebook_entries SET title=?,content=?,updated=? WHERE id=?",(title,content,n.get('updated') or datetime.now().strftime('%Y-%m-%d %H:%M:%S'),int(m[0])))
            else:
                cur=self.db.execute("INSERT INTO notebook_entries(title,content,created,updated) VALUES(?,?,?,?)",(title,content,n.get('created') or datetime.now().strftime('%Y-%m-%d %H:%M:%S'),n.get('updated') or datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                self.db.execute("INSERT OR REPLACE INTO web_sync_map(kind,remote_id,local_id) VALUES('note',?,?)",(rid,int(cur.lastrowid)))
        # Ledger entries: append/update only entries originating from the web companion.
        for e in data.get("entries") or []:
            rid=str(e.get("id")); name=str(e.get("customer") or '').strip(); typ=str(e.get("type") or '').strip(); amount=float(e.get('amount') or 0)
            if not rid or not name or not typ: continue
            m=self.db.execute("SELECT local_id FROM web_sync_map WHERE kind='entry' AND remote_id=?",(rid,)).fetchone()
            cid=None
            cr=self.db.execute("SELECT local_id FROM web_sync_map WHERE kind='customer' AND remote_id=?",(str(e.get('customerId')),)).fetchone()
            if cr: cid=int(cr[0])
            if m:
                self.db.execute("UPDATE account_entries SET customer_id=?,customer=?,entry_type=?,amount=?,notes=?,currency=?,rate=?,commission=?,commission_currency=?,route=? WHERE id=?",
                                (cid,name,typ,amount,e.get('note') or '',e.get('currency') or '',float(e.get('rate') or 1),float(e.get('commission') or 0),e.get('commissionCurrency') or e.get('currency') or '',e.get('route') or '',int(m[0])))
            else:
                cur=self.db.execute("INSERT INTO account_entries(created,customer_id,customer,entry_type,amount,notes,currency,rate,afn_amount,commission,commission_afn,commission_currency,route,source_type) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (e.get('created') or datetime.now().strftime('%Y-%m-%d %H:%M'),cid,name,typ,amount,e.get('note') or '',e.get('currency') or '',float(e.get('rate') or 1),amount*float(e.get('rate') or 1),float(e.get('commission') or 0),float(e.get('commission') or 0)*float(e.get('rate') or 1),e.get('commissionCurrency') or e.get('currency') or '',e.get('route') or '','android_web'))
                self.db.execute("INSERT OR REPLACE INTO web_sync_map(kind,remote_id,local_id) VALUES('entry',?,?)",(rid,int(cur.lastrowid)))
        self.db.commit()
        return {"ok":True,"message":"اطلاعات گوشی با موفقیت با کامپیوتر همگام شد."}

    def _get_sync_token(self):
        try:
            if os.path.exists(SYNC_TOKEN_FILE):
                t=open(SYNC_TOKEN_FILE,"r",encoding="utf-8").read().strip()
                if t: return t
            t=secrets.token_urlsafe(24)
            open(SYNC_TOKEN_FILE,"w",encoding="utf-8").write(t)
            return t
        except Exception:
            return "JAHAN-SYNC-LOCAL"

    def _sync_snapshot(self):
        self.db.commit()
        fd,tmp=tempfile.mkstemp(suffix=".db"); os.close(fd)
        try:
            dest=sqlite3.connect(tmp); self.db.backup(dest); dest.close()
            raw=open(tmp,"rb").read()
            return base64.b64encode(raw).decode("ascii")
        finally:
            try: os.remove(tmp)
            except OSError: pass

    def _restore_sync_snapshot(self, encoded):
        raw=base64.b64decode(encoded.encode("ascii"), validate=True)
        if not raw.startswith(b"SQLite format 3"):
            raise ValueError("فایل داده معتبر نیست.")
        fd,tmp=tempfile.mkstemp(suffix=".db"); os.close(fd)
        safety=None
        try:
            open(tmp,"wb").write(raw)
            test=sqlite3.connect(tmp); ok=test.execute("PRAGMA integrity_check").fetchone()[0]; test.close()
            if ok!="ok": raise ValueError("بررسی سلامت پایگاه داده موفق نشد.")
            # Keep a recoverable copy of the current PC database before an Android push.
            os.makedirs(BACKUP_DIR,exist_ok=True)
            safety=os.path.join(BACKUP_DIR,"before_android_sync_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".db")
            self.db.commit()
            if os.path.exists(DB): shutil.copy2(DB,safety)
            self.db.close()
            for sidecar in (DB+"-wal",DB+"-shm"):
                try: os.remove(sidecar)
                except OSError: pass
            shutil.copy2(tmp,DB)
            self.db=sqlite3.connect(DB)
            self.db.execute("PRAGMA foreign_keys=ON")
            self.db.execute("PRAGMA journal_mode=DELETE")
            # Android snapshots contain the same core data but may not have every
            # PC-only table. Recreate missing PC schema additively, never delete data.
            self._ensure_krw_schema()
            self.db.commit()
        except Exception:
            try:
                self.db.close()
            except Exception: pass
            if safety and os.path.exists(safety):
                shutil.copy2(safety,DB)
                self.db=sqlite3.connect(DB)
                self.db.execute("PRAGMA foreign_keys=ON")
            raise
        finally:
            try: os.remove(tmp)
            except OSError: pass

    def _ai_proxy_answer(self, question):
        row=self.db.execute("SELECT value FROM app_settings WHERE key='ai_api_key'").fetchone()
        key=str(row[0]).strip() if row and row[0] else os.environ.get("OPENAI_API_KEY","").strip()
        row=self.db.execute("SELECT value FROM app_settings WHERE key='ai_model'").fetchone()
        model=str(row[0]).strip() if row and row[0] else "gpt-5.6-luna"
        if not key: raise ValueError("کلید OpenAI API در کامپیوتر تنظیم نشده است.")
        instructions=("تو دستیار هوشمند نرم افزار حسابداری جهان هستی. فارسی و دقیق جواب بده. "
                      "برای سؤال‌های مربوط به برنامه راهنمای عملی بده و اگر محاسبه‌ای خواسته شد دقیق انجام بده. "
                      "اگر اطلاعاتی را نمی‌دانی، حدس قطعی نزن.")
        ok,result=self._ai_raw_request(key,model,[{"role":"user","content":question}],instructions,max_tokens=1200,timeout=30)
        if not ok: raise ValueError(result)
        return result

    def start_sync_server(self):
        if getattr(self,"_sync_server",None): return
        app=self
        token=self._get_sync_token()
        class Handler(http.server.BaseHTTPRequestHandler):
            def _auth(self):
                return self.headers.get("X-Jahan-Token","") == token
            def _send(self, code, obj):
                body=json.dumps(obj,ensure_ascii=False).encode("utf-8")
                self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Access-Control-Allow-Origin","*"); self.send_header("Access-Control-Allow-Headers","Content-Type, X-Jahan-Token"); self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
            def do_OPTIONS(self):
                self.send_response(204); self.send_header("Access-Control-Allow-Origin","*"); self.send_header("Access-Control-Allow-Headers","Content-Type, X-Jahan-Token"); self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS"); self.end_headers()
            def do_GET(self):
                if self.path not in ("/api/info","/api/web-sync"): self._send(404,{"ok":False,"error":"not found"}); return
                if not self._auth(): self._send(401,{"ok":False,"error":"unauthorized"}); return
                if self.path=="/api/web-sync": self._send(200,{"ok":True,"data":app._web_snapshot(),"device":socket.gethostname()}); return
                self._send(200,{"ok":True,"app":APP_NAME,"version":APP_VERSION,"updated":datetime.now().isoformat(),"device":socket.gethostname(),"port":SYNC_PORT})
            def do_POST(self):
                if self.path not in ("/api/sync","/api/ai","/api/web-sync"): self._send(404,{"ok":False,"error":"not found"}); return
                if not self._auth(): self._send(401,{"ok":False,"error":"unauthorized"}); return
                try:
                    n=int(self.headers.get("Content-Length","0")); data=json.loads(self.rfile.read(n).decode("utf-8"))
                    if self.path=="/api/web-sync":
                        action=str(data.get("action", ""))
                        if action=="info": self._send(200,{"ok":True,"device":socket.gethostname(),"port":SYNC_PORT}); return
                        if action=="pull": self._send(200,{"ok":True,"data":app._web_snapshot(),"updated":datetime.now().isoformat()}); return
                        if action=="push": self._send(200,app._web_merge(data.get("data") or {})); return
                        self._send(400,{"ok":False,"error":"action نامعتبر است."}); return
                    if self.path=="/api/ai":
                        answer=app._ai_proxy_answer(str(data.get("question","")).strip())
                        self._send(200,{"ok":True,"answer":answer}); return
                    if data.get("action")=="pull": self._send(200,{"ok":True,"snapshot":app._sync_snapshot(),"updated":datetime.now().isoformat()}); return
                    if data.get("action")=="push":
                        app._restore_sync_snapshot(str(data.get("snapshot",""))); self._send(200,{"ok":True,"message":"داده‌ها با موفقیت دریافت شد."}); return
                    self._send(400,{"ok":False,"error":"action"})
                except Exception as e: self._send(400,{"ok":False,"error":str(e)[:500]})
            def log_message(self,*args): return
        class Reuse(socketserver.ThreadingMixIn, http.server.HTTPServer):
            allow_reuse_address=True
            daemon_threads=True
        try:
            self._sync_server=Reuse(("0.0.0.0",SYNC_PORT),Handler)
            self._sync_thread=threading.Thread(target=self._sync_server.serve_forever,daemon=True); self._sync_thread.start()
            self._sync_token=token
        except Exception:
            self._sync_server=None

    def get_sync_connection_info(self):
        self.start_sync_server()
        ips=[]
        try:
            for fam,_,_,_,sa in socket.getaddrinfo(socket.gethostname(),None):
                if fam==socket.AF_INET and sa[0] and not sa[0].startswith("127.") and sa[0] not in ips: ips.append(sa[0])
        except Exception: pass
        return {"port":SYNC_PORT,"token":getattr(self,"_sync_token",self._get_sync_token()),"ips":ips}

    def _validate_krw_database(self, db_path):
        """Validate a KRW snapshot without touching the live database."""
        test = sqlite3.connect(db_path)
        try:
            row = test.execute("PRAGMA integrity_check").fetchone()
            if not row or str(row[0]).lower() != "ok":
                raise ValueError("پایگاه داده داخل فایل KRW سالم نیست.")
            # A real Jahan file must contain the core table.
            exists = test.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='customers'").fetchone()
            if not exists:
                raise ValueError("این فایل، فایل اطلاعات نرم‌افزار حسابداری جهان نیست.")
        finally:
            test.close()

    def _krw_manifest_counts(self, db_path):
        """Return a complete inventory of the SQLite database for KRW integrity checks."""
        con=sqlite3.connect(db_path)
        try:
            tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
            counts={}
            for t in tables:
                safe=t.replace('"','""')
                counts[t]=int(con.execute(f'SELECT COUNT(*) FROM "{safe}"').fetchone()[0] or 0)
            return counts
        finally:
            con.close()

    def create_krw_backup(self, path, password=""):
        """Create a complete, verified KRW snapshot of the live SQLite database.

        Before copying, committed WAL data is checkpointed. The resulting DB is
        validated and its table row counts are stored in the manifest, so a KRW
        file cannot silently lose customer/account/receipt/shop/remittance data.
        """
        import zipfile as _zipfile
        self.db.commit()
        try:
            self.db.execute("PRAGMA wal_checkpoint(FULL)")
        except Exception:
            pass
        salt=os.urandom(16)
        key=hashlib.pbkdf2_hmac("sha256",password.encode("utf-8"),salt,200000,dklen=32)
        workdir=tempfile.mkdtemp(prefix="jahan_krw_save_")
        tmpdb=os.path.join(workdir,"jahan_accounting.db")
        tmpzip=os.path.join(workdir,"payload.zip")
        tmpout=path+".tmp"
        try:
            # SQLite backup API creates a consistent snapshot including all tables.
            dest=sqlite3.connect(tmpdb)
            self.db.backup(dest)
            dest.execute("PRAGMA journal_mode=DELETE")
            dest.commit(); dest.close()
            self._validate_krw_database(tmpdb)
            dbraw=open(tmpdb,"rb").read()
            counts=self._krw_manifest_counts(tmpdb)
            manifest=json.dumps({
                "format":"KRW", "version":5, "app":"Jahan Accounting",
                "data_scope":"customers+accounts+receipts+remittances+businesses+shops+invoices+shipments+settings+notebook",
                "created":datetime.now().isoformat(),
                "database_sha256":hashlib.sha256(dbraw).hexdigest(),
                "database_bytes":len(dbraw),
                "table_counts":counts,
                "password_protected":bool(password)
            },ensure_ascii=False,indent=2).encode("utf-8")
            with _zipfile.ZipFile(tmpzip,"w",_zipfile.ZIP_DEFLATED) as zz:
                zz.writestr("jahan_accounting.db",dbraw)
                zz.writestr("krw_manifest.json",manifest)
            raw=open(tmpzip,"rb").read()
            enc=self._crypt(raw,password,salt)
            tag=hmac.new(key,enc,hashlib.sha256).digest()
            with open(tmpout,"wb") as f:
                f.write(b"KRW12\x01"+salt+tag+enc); f.flush(); os.fsync(f.fileno())
            os.replace(tmpout,path)
            # Final read-back verification catches incomplete disk writes.
            check=self._decode_krw_to_db(path,password)
            os.remove(check)
        finally:
            try: os.remove(tmpout)
            except OSError: pass
            shutil.rmtree(workdir,ignore_errors=True)

    def _decode_krw_to_db(self,path,password):
        import zipfile as _zipfile
        path=os.path.abspath(path)
        blob=open(path,"rb").read()

        if blob[:16]==b"SQLite format 3\x00":
            fd,finaltmp=tempfile.mkstemp(suffix=".db"); os.close(fd)
            try:
                shutil.copy2(path,finaltmp); self._validate_krw_database(finaltmp); return finaltmp
            except Exception:
                try:os.remove(finaltmp)
                except OSError:pass
                raise

        if blob.startswith(b"PK\x03\x04"):
            fd,tmpzip=tempfile.mkstemp(suffix=".zip"); os.close(fd)
            tmpdir=tempfile.mkdtemp(prefix="jahan_krw_")
            try:
                with open(tmpzip,"wb") as f:f.write(blob)
                with _zipfile.ZipFile(tmpzip) as zz:
                    if "jahan_accounting.db" not in zz.namelist(): raise ValueError("فایل KRW فاقد پایگاه داده است.")
                    if zz.getinfo("jahan_accounting.db").file_size>500*1024*1024: raise ValueError("اندازه فایل KRW غیرعادی است.")
                    zz.extract("jahan_accounting.db",tmpdir)
                extracted=os.path.join(tmpdir,"jahan_accounting.db"); self._validate_krw_database(extracted)
                fd,finaltmp=tempfile.mkstemp(suffix=".db"); os.close(fd); shutil.copy2(extracted,finaltmp); return finaltmp
            finally:
                try:os.remove(tmpzip)
                except OSError:pass
                shutil.rmtree(tmpdir,ignore_errors=True)

        if blob.startswith(b"KRW12\x01"): header=6
        elif blob.startswith(b"KRW11\x01"): header=6
        else: raise ValueError("فایل KRW معتبر نیست یا ناقص است.")
        if len(blob)<header+49: raise ValueError("فایل KRW ناقص است.")
        salt=blob[header:header+16]; tag=blob[header+16:header+48]; enc=blob[header+48:]
        key=hashlib.pbkdf2_hmac("sha256",password.encode("utf-8"),salt,200000,dklen=32)
        if not hmac.compare_digest(tag,hmac.new(key,enc,hashlib.sha256).digest()):
            raise ValueError("رمز KRW اشتباه است یا فایل آسیب دیده است.")
        raw=self._crypt(enc,password,salt)
        fd,tmpzip=tempfile.mkstemp(suffix=".zip"); os.close(fd)
        tmpdir=tempfile.mkdtemp(prefix="jahan_krw_")
        try:
            with open(tmpzip,"wb") as f:f.write(raw)
            with _zipfile.ZipFile(tmpzip) as zz:
                if "jahan_accounting.db" not in zz.namelist(): raise ValueError("فایل KRW فاقد پایگاه داده است.")
                if zz.getinfo("jahan_accounting.db").file_size>500*1024*1024: raise ValueError("اندازه فایل KRW غیرعادی است.")
                zz.extract("jahan_accounting.db",tmpdir)
                expected=None
                manifest_obj=None
                if "krw_manifest.json" in zz.namelist():
                    try: manifest_obj=json.loads(zz.read("krw_manifest.json").decode("utf-8"))
                    except Exception: manifest_obj=None
                expected=(manifest_obj or {}).get("database_sha256")
            extracted=os.path.join(tmpdir,"jahan_accounting.db")
            if expected and hashlib.sha256(open(extracted,"rb").read()).hexdigest()!=expected:
                raise ValueError("فایل KRW در هنگام ذخیره/انتقال تغییر کرده یا آسیب دیده است.")
            self._validate_krw_database(extracted)
            expected_counts=(manifest_obj or {}).get("table_counts") or {}
            if expected_counts:
                actual_counts=self._krw_manifest_counts(extracted)
                for tn,expected_count in expected_counts.items():
                    if int(actual_counts.get(tn, -1)) != int(expected_count):
                        raise ValueError(f"فایل KRW ناقص است: اطلاعات جدول «{tn}» کامل ذخیره نشده است.")
            fd,finaltmp=tempfile.mkstemp(suffix=".db"); os.close(fd)
            shutil.copy2(extracted,finaltmp); return finaltmp
        finally:
            try:os.remove(tmpzip)
            except OSError:pass
            shutil.rmtree(tmpdir,ignore_errors=True)

    def _open_web_krw(self, path, password=""):
        """Import the HTML companion KRW JSON package into the desktop DB."""
        import zipfile as _zipfile
        blob=open(path,"rb").read()
        if not blob.startswith(b"KRW12\x01") or len(blob)<54: return False
        salt=blob[6:22]; tag=blob[22:54]; enc=blob[54:]
        key=hashlib.pbkdf2_hmac("sha256",password.encode("utf-8"),salt,200000,dklen=32)
        if not hmac.compare_digest(tag,hmac.new(key,enc,hashlib.sha256).digest()): return False
        raw=self._crypt(enc,password,salt)
        work=tempfile.mkdtemp(prefix="jahan_web_krw_")
        try:
            zpath=os.path.join(work,"payload.zip"); open(zpath,"wb").write(raw)
            with _zipfile.ZipFile(zpath) as zz:
                if "jahan_accounting.json" not in zz.namelist(): return False
                data=json.loads(zz.read("jahan_accounting.json").decode("utf-8"))
            self._web_merge(data); self._reload_after_krw_open(); return True
        finally: shutil.rmtree(work,ignore_errors=True)

    def restore_krw_backup(self,path,password=""):
        newdb=self._decode_krw_to_db(path,password)
        safety=None
        try:
            os.makedirs(BACKUP_DIR,exist_ok=True)
            safety=os.path.join(BACKUP_DIR,"before_open_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".db")
            try:self.db.commit()
            except Exception:pass
            if os.path.exists(DB):shutil.copy2(DB,safety)
            try:self.db.close()
            except Exception:pass
            for sidecar in (DB+"-wal",DB+"-shm"):
                try:
                    if os.path.exists(sidecar):os.remove(sidecar)
                except OSError:pass
            os.replace(newdb,DB); newdb=None
            self.db=sqlite3.connect(DB); self.db.execute("PRAGMA foreign_keys=ON"); self.db.execute("PRAGMA journal_mode=DELETE"); self.db.commit()
            self._ensure_krw_schema()
        except Exception:
            if newdb:
                try:os.remove(newdb)
                except OSError:pass
            if safety and os.path.exists(safety):
                try:
                    try:self.db.close()
                    except Exception:pass
                    shutil.copy2(safety,DB); self.db=sqlite3.connect(DB); self.db.execute("PRAGMA foreign_keys=ON")
                except Exception:pass
            raise


    def _ensure_krw_schema(self):
        """Upgrade an opened KRW database to the current Jahan schema.

        KRW files are portable snapshots, so they may come from an older
        release. Never assume the latest columns/tables exist after opening.
        This migration is intentionally additive: it creates missing tables
        and columns but never removes or overwrites user records.
        """
        # Core/current tables.
        # V18.78+: KRW compatibility for the shipment ledger. Older KRW files
        # may predate the shipment feature, so opening such a file must create
        # the table before any Bar/Report screen queries it.
        self.db.execute("""CREATE TABLE IF NOT EXISTS shipments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shipment_no INTEGER UNIQUE,
            created TEXT NOT NULL,
            origin_country TEXT NOT NULL DEFAULT 'افغانستان',
            origin_province TEXT NOT NULL DEFAULT '',
            destination_country TEXT NOT NULL DEFAULT 'ایران',
            destination_province TEXT NOT NULL DEFAULT '',
            cargo_type TEXT DEFAULT '',
            sender TEXT DEFAULT '',
            receiver TEXT DEFAULT '',
            income REAL NOT NULL DEFAULT 0,
            income_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            income_rate REAL NOT NULL DEFAULT 1,
            income_afn REAL NOT NULL DEFAULT 0,
            worker REAL NOT NULL DEFAULT 0,
            worker_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            worker_rate REAL NOT NULL DEFAULT 1,
            worker_afn REAL NOT NULL DEFAULT 0,
            customs_origin REAL NOT NULL DEFAULT 0,
            customs_origin_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            customs_origin_rate REAL NOT NULL DEFAULT 1,
            customs_origin_afn REAL NOT NULL DEFAULT 0,
            customs_destination REAL NOT NULL DEFAULT 0,
            customs_destination_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            customs_destination_rate REAL NOT NULL DEFAULT 1,
            customs_destination_afn REAL NOT NULL DEFAULT 0,
            freight_origin REAL NOT NULL DEFAULT 0,
            freight_origin_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            freight_origin_rate REAL NOT NULL DEFAULT 1,
            freight_origin_afn REAL NOT NULL DEFAULT 0,
            freight_destination REAL NOT NULL DEFAULT 0,
            freight_destination_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            freight_destination_rate REAL NOT NULL DEFAULT 1,
            freight_destination_afn REAL NOT NULL DEFAULT 0,
            other_cost REAL NOT NULL DEFAULT 0,
            other_cost_currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            other_cost_rate REAL NOT NULL DEFAULT 1,
            other_cost_afn REAL NOT NULL DEFAULT 0,
            total_cost_afn REAL NOT NULL DEFAULT 0,
            profit_afn REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT ''
        )""")
        self.db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_shipments_no ON shipments(shipment_no)")
        self.db.execute("""CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            phone TEXT, address TEXT, balance REAL DEFAULT 0, notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, kind TEXT,
            currency TEXT, amount REAL, rate REAL, afn_amount REAL,
            customer TEXT, notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS account_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            receipt_no INTEGER DEFAULT 0,
            customer_id INTEGER,
            customer TEXT NOT NULL,
            entry_type TEXT NOT NULL,
            amount REAL NOT NULL,
            notes TEXT,
            currency TEXT DEFAULT 'AFN - افغانی',
            rate REAL DEFAULT 1,
            afn_amount REAL DEFAULT 0,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS receipts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            customer_id INTEGER,
            customer TEXT NOT NULL,
            receipt_type TEXT NOT NULL,
            amount REAL NOT NULL,
            description TEXT,
            edit_count INTEGER DEFAULT 0,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS commission_rules(
            id INTEGER PRIMARY KEY AUTOINCREMENT, route TEXT NOT NULL,
            currency TEXT NOT NULL, base_amount REAL NOT NULL DEFAULT 1000000,
            commission_amount REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
            UNIQUE(route,currency))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS businesses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            business_type TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS business_transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT NOT NULL,
            business_id INTEGER NOT NULL,
            business_name TEXT NOT NULL,
            business_type TEXT NOT NULL,
            kind TEXT NOT NULL,
            amount REAL NOT NULL,
            notes TEXT,
            FOREIGN KEY(business_id) REFERENCES businesses(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS whatsapp_receipts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            imported_at TEXT NOT NULL, group_name TEXT, sender_name TEXT, sender_phone TEXT,
            source_file TEXT NOT NULL, source_hash TEXT UNIQUE, receipt_name TEXT, receipt_no TEXT,
            receipt_date TEXT, amount REAL DEFAULT 0, currency TEXT DEFAULT 'AFN', raw_text TEXT,
            customer_id INTEGER, customer_name TEXT, status TEXT NOT NULL DEFAULT 'در انتظار تأیید', notes TEXT,
            FOREIGN KEY(customer_id) REFERENCES customers(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS whatsapp_settings(
            id INTEGER PRIMARY KEY CHECK(id=1), group_name TEXT, import_folder TEXT,
            auto_watch INTEGER NOT NULL DEFAULT 0, last_scan TEXT,
            official_enabled INTEGER NOT NULL DEFAULT 0, connection_status TEXT DEFAULT 'آماده اتصال رسمی',
            business_phone TEXT DEFAULT '', webhook_url TEXT DEFAULT '')""")
        wa_cols=[r[1] for r in self.db.execute("PRAGMA table_info(whatsapp_settings)").fetchall()]
        for col,definition in [("official_enabled","INTEGER NOT NULL DEFAULT 0"),("connection_status","TEXT DEFAULT 'آماده اتصال رسمی'"),("business_phone","TEXT DEFAULT ''"),("webhook_url","TEXT DEFAULT ''")]:
            if col not in wa_cols: self.db.execute(f"ALTER TABLE whatsapp_settings ADD COLUMN {col} {definition}")
        self.db.execute("""CREATE TABLE IF NOT EXISTS fruit_inventory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fruit_name TEXT NOT NULL,
            quantity_kg REAL NOT NULL DEFAULT 0,
            unit_price REAL NOT NULL DEFAULT 0,
            updated TEXT NOT NULL,
            notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS shop_inventory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            unit TEXT NOT NULL DEFAULT 'عدد',
            quantity REAL NOT NULL DEFAULT 0,
            min_quantity REAL NOT NULL DEFAULT 0,
            cost_price REAL NOT NULL DEFAULT 0,
            sale_price REAL NOT NULL DEFAULT 0,
            currency TEXT NOT NULL DEFAULT 'AFN - افغانی',
            updated TEXT NOT NULL,
            notes TEXT,
            UNIQUE(business_id,item_name),
            FOREIGN KEY(business_id) REFERENCES businesses(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS invoices(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL,
            customer_id INTEGER, customer TEXT NOT NULL, phone TEXT, notes TEXT, total REAL NOT NULL DEFAULT 0)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS retail_sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL,
            business_type TEXT NOT NULL, business_name TEXT NOT NULL,
            customer_id INTEGER, customer TEXT NOT NULL, phone TEXT,
            total REAL NOT NULL DEFAULT 0, paid REAL NOT NULL DEFAULT 0,
            debt REAL NOT NULL DEFAULT 0, notes TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS retail_sale_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL,
            item_name TEXT NOT NULL, unit TEXT NOT NULL, quantity REAL NOT NULL,
            unit_price REAL NOT NULL, total REAL NOT NULL,
            FOREIGN KEY(sale_id) REFERENCES retail_sales(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS retail_prices(
            id INTEGER PRIMARY KEY AUTOINCREMENT, business_type TEXT NOT NULL,
            item_name TEXT NOT NULL, unit_price REAL NOT NULL DEFAULT 0,
            updated TEXT NOT NULL, UNIQUE(business_type,item_name))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS invoice_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, fruit_name TEXT NOT NULL,
            unit TEXT NOT NULL, quantity REAL NOT NULL, quantity_kg REAL NOT NULL, unit_price REAL NOT NULL, total REAL NOT NULL)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
            full_name TEXT, active INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS social_accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, subject TEXT NOT NULL,
            user_id INTEGER NOT NULL, email TEXT, created TEXT NOT NULL, last_login TEXT,
            UNIQUE(provider, subject), FOREIGN KEY(user_id) REFERENCES users(id))""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS remittances(
            id INTEGER PRIMARY KEY AUTOINCREMENT, transfer_no TEXT UNIQUE NOT NULL, created TEXT NOT NULL,
            sender_name TEXT NOT NULL, sender_surname TEXT, sender_phone TEXT NOT NULL, sender_province TEXT,
            receiver_name TEXT NOT NULL, receiver_surname TEXT, receiver_phone TEXT NOT NULL, receiver_province TEXT,
            currency TEXT NOT NULL, amount REAL NOT NULL, fee REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'ثبت شده', notes TEXT, destination_country TEXT DEFAULT 'ایران')""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS exchange_rates(
            code TEXT PRIMARY KEY, rate_to_afn REAL NOT NULL, updated TEXT NOT NULL, source TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS app_settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        column_map = {
            "transactions": [
                ("customer_id","INTEGER"),
                ("source_type","TEXT DEFAULT 'manual'"),
                ("source_id","INTEGER"),
            ],
            "account_entries": [
                ("currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("rate","REAL DEFAULT 1"),
                ("afn_amount","REAL DEFAULT 0"),
                ("account_no","INTEGER DEFAULT 0"),
                ("source_type","TEXT DEFAULT 'manual'"),
                ("source_id","INTEGER"),
                ("commission","REAL DEFAULT 0"),
                ("commission_afn","REAL DEFAULT 0"),
                ("commission_currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("route","TEXT DEFAULT ''"),
            ],
            "receipts": [
                ("receipt_no","INTEGER DEFAULT 0"),
                ("currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("rate","REAL DEFAULT 1"),
                ("afn_amount","REAL DEFAULT 0"),
                ("edit_count","INTEGER DEFAULT 0"),
                ("commission_base","REAL DEFAULT 1000000"),
                ("commission_rate","REAL DEFAULT 0"),
                ("commission","REAL DEFAULT 0"),
                ("commission_afn","REAL DEFAULT 0"),
                ("commission_currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("route","TEXT DEFAULT ''"),
            ],
            "business_transactions": [
                ("currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("rate","REAL DEFAULT 1"),
                ("afn_amount","REAL DEFAULT 0"),
                ("customer_id","INTEGER"),
                ("source_type","TEXT DEFAULT 'shop'"),
                ("source_id","INTEGER"),
            ],
            "retail_sales": [
                ("business_id","INTEGER"),
                ("currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("rate","REAL DEFAULT 1"),
                ("invoice_no","TEXT DEFAULT ''"),
                ("discount","REAL DEFAULT 0"),
                ("tax","REAL DEFAULT 0"),
                ("final_total","REAL DEFAULT 0"),
            ],
            "retail_sale_items": [
                ("stock_before","REAL DEFAULT NULL"),
                ("stock_after","REAL DEFAULT NULL"),
            ],
            "remittances": [
                ("destination_country","TEXT DEFAULT 'ایران'"),
                ("commission","REAL DEFAULT 0"),
                ("commission_base","REAL DEFAULT 1000000"),
                ("commission_rate","REAL DEFAULT 0"),
                ("commission_enabled","INTEGER DEFAULT 0"),
                ("commission_currency","TEXT DEFAULT 'AFN - افغانی'"),
                ("net_amount","REAL DEFAULT 0"),
            ],
        }
        for table, columns in column_map.items():
            existing = {r[1] for r in self.db.execute(f"PRAGMA table_info({table})").fetchall()}
            for col, definition in columns:
                if col not in existing:
                    self.db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")

        # Professional invoice defaults/backfills.
        self.db.execute("UPDATE retail_sales SET invoice_no=CAST(id AS TEXT) WHERE invoice_no IS NULL OR invoice_no=''")
        self.db.execute("UPDATE retail_sales SET discount=0 WHERE discount IS NULL")
        self.db.execute("UPDATE retail_sales SET tax=0 WHERE tax IS NULL")
        self.db.execute("UPDATE retail_sales SET final_total=CASE WHEN final_total IS NULL OR final_total=0 THEN total ELSE final_total END")
        # Defaults/backfills used by the current accounting logic.
        self.db.execute("UPDATE account_entries SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE account_entries SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE account_entries SET afn_amount=amount*rate WHERE afn_amount IS NULL OR afn_amount=0")
        self.db.execute("UPDATE account_entries SET account_no=id WHERE account_no IS NULL OR account_no=0")
        self.db.execute("UPDATE account_entries SET commission=0 WHERE commission IS NULL")
        self.db.execute("UPDATE account_entries SET commission_afn=COALESCE(commission,0)*COALESCE(rate,1) WHERE commission_afn IS NULL")
        self.db.execute("UPDATE account_entries SET commission_currency=COALESCE(NULLIF(commission_currency,''),currency,'AFN - افغانی')")
        self.db.execute("UPDATE receipts SET receipt_no=id WHERE receipt_no IS NULL OR receipt_no=0")
        self.db.execute("UPDATE receipts SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE receipts SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE receipts SET afn_amount=amount*rate WHERE afn_amount IS NULL OR afn_amount=0")
        # Repair old receipt/customer links. Some older databases stored the
        # customer name but left customer_id empty; those receipts must still
        # participate in the customer's balance calculation.
        self.db.execute("""UPDATE receipts
                           SET customer_id=(SELECT c.id FROM customers c WHERE c.name=receipts.customer LIMIT 1)
                           WHERE (customer_id IS NULL OR customer_id=0)
                             AND customer IS NOT NULL AND TRIM(customer)<>''""")
        self.db.execute("""UPDATE account_entries
                           SET customer_id=(SELECT c.id FROM customers c WHERE c.name=account_entries.customer LIMIT 1)
                           WHERE (customer_id IS NULL OR customer_id=0)
                             AND customer IS NOT NULL AND TRIM(customer)<>''""")
        self.db.execute("UPDATE receipts SET commission=0 WHERE commission IS NULL")
        self.db.execute("UPDATE receipts SET commission_afn=COALESCE(commission,0)*COALESCE(rate,1) WHERE commission_afn IS NULL")
        self.db.execute("UPDATE receipts SET commission_currency=COALESCE(NULLIF(commission_currency,''),currency,'AFN - افغانی')")
        self.db.execute("UPDATE business_transactions SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE business_transactions SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE business_transactions SET afn_amount=amount*rate WHERE afn_amount IS NULL OR afn_amount=0")
        self.db.execute("UPDATE retail_sales SET currency='AFN - افغانی' WHERE currency IS NULL OR currency=''")
        self.db.execute("UPDATE retail_sales SET rate=1 WHERE rate IS NULL OR rate=0")
        self.db.execute("UPDATE remittances SET commission=COALESCE(commission,0), commission_currency=COALESCE(NULLIF(commission_currency,''),currency,'AFN - افغانی')")
        self.db.execute("UPDATE remittances SET total=CASE WHEN total IS NULL OR total=0 THEN amount+COALESCE(fee,0) ELSE total END")
        self.db.execute("UPDATE remittances SET net_amount=CASE WHEN net_amount IS NULL OR net_amount=0 THEN MAX(amount-COALESCE(commission,0),0) ELSE net_amount END")

        # Make old receipt records compatible with edit/delete and account totals.
        self.db.execute("UPDATE account_entries SET source_type='receipt' WHERE source_type='manual' AND notes LIKE 'رسید شماره %'")
        receipt_rows = self.db.execute("""
            SELECT r.id,r.created,r.customer_id,r.customer,r.receipt_type,r.amount,
                   COALESCE(r.description,''),COALESCE(r.currency,'AFN - افغانی'),
                   COALESCE(r.rate,1),COALESCE(r.afn_amount,r.amount*COALESCE(r.rate,1)),
                   COALESCE(r.commission,0),COALESCE(r.commission_afn,0),
                   COALESCE(r.commission_currency,r.currency,'AFN - افغانی'),
                   COALESCE(r.route,'')
            FROM receipts r WHERE r.customer_id IS NOT NULL
        """).fetchall()
        for rr in receipt_rows:
            rid,rcdate,rcid,rcname,rtype,ramount,rdesc,rcur,rrate,rafn,rcomm,rcafn,rcommcur,rroute = rr
            linked = self.db.execute(
                "SELECT 1 FROM account_entries WHERE source_type='receipt' AND source_id=? LIMIT 1",
                (rid,)).fetchone()
            if not linked:
                etype = 'بستانکاری مشتری' if rtype == 'دریافت از مشتری' else 'قرضداری مشتری'
                rno = self.db.execute("SELECT receipt_no FROM receipts WHERE id=?", (rid,)).fetchone()
                rno = (rno[0] if rno else rid) or rid
                self.db.execute("""
                    INSERT INTO account_entries(
                        created,customer_id,customer,entry_type,amount,notes,currency,rate,
                        afn_amount,commission,commission_afn,commission_currency,route,
                        source_type,source_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    rcdate,rcid,rcname,etype,float(ramount or 0),
                    f"رسید شماره {rno} - {rdesc}".strip(),rcur,float(rrate or 1),
                    float(rafn or 0),float(rcomm or 0),float(rcafn or 0),rcommcur,
                    rroute,'receipt',rid
                ))
        self.db.execute("""UPDATE account_entries
                           SET source_id=(
                               SELECT r.id FROM receipts r
                               WHERE r.receipt_no=CAST(
                                   substr(account_entries.notes, instr(account_entries.notes,'رسید شماره ')+length('رسید شماره '))
                                   AS INTEGER)
                               LIMIT 1)
                           WHERE source_type='receipt' AND (source_id IS NULL OR source_id=0)
                             AND notes LIKE 'رسید شماره %'""")

        # Validate after migration, then commit atomically.
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.commit()
        self._validate_krw_database(DB)

    def _reload_after_krw_open(self):
        """Refresh the existing shell after opening a KRW; never destroy the root window."""
        try:
            self.clear()
        except Exception: pass
        self.dashboard()
        try:
            self.update_idletasks()
        except Exception: pass

    def quick_krw_save(self):
        pw=getattr(self,"_krw_password","" ) or ""
        path=filedialog.asksaveasfilename(
            title="ذخیره فایل اطلاعات جهان",
            defaultextension=".krw",
            filetypes=[("فایل اطلاعات Jahan (*.krw)","*.krw"),("همه فایل‌ها","*.*")],
            initialfile=f"Jahan_{datetime.now().strftime('%Y-%m-%d_%H-%M')}.krw")
        if not path:return
        try:
            self.create_krw_backup(path,pw)
            messagebox.showinfo("ذخیره فایل","فایل اطلاعات با موفقیت ذخیره شد.\n\nهر زمان از File > Open آن را باز کنید.")
        except Exception as e: messagebox.showerror("ذخیره فایل",str(e))

    def open_krw(self):
        path=filedialog.askopenfilename(title="باز کردن فایل اطلاعات جهان",
            filetypes=[("فایل اطلاعات Jahan (*.krw)","*.krw"),("همه فایل‌ها","*.*")])
        if not path:return
        candidates=[]; current=getattr(self,"_krw_password","") or ""
        try:
            if self._open_web_krw(path,current):
                messagebox.showinfo("باز کردن فایل","فایل KRW موبایل با موفقیت با اطلاعات کامپیوتر ادغام شد."); return
        except Exception:
            pass
        if current not in candidates:candidates.append(current)
        if "" not in candidates:candidates.append("")
        errors=[]
        for pw in candidates:
            try:
                tmp=self._decode_krw_to_db(path,pw)
                if not messagebox.askyesno("باز کردن فایل","فایل فعلی با این فایل جایگزین می‌شود.\nیک نسخه پشتیبان از اطلاعات فعلی نیز ساخته می‌شود.\nادامه می‌دهید؟"):
                    try:os.remove(tmp)
                    except OSError:pass
                    return
                try:
                    os.makedirs(BACKUP_DIR,exist_ok=True)
                    safety=os.path.join(BACKUP_DIR,"before_open_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".db")
                    try:self.db.commit()
                    except Exception:pass
                    if os.path.exists(DB):shutil.copy2(DB,safety)
                    try:self.db.close()
                    except Exception:pass
                    for sidecar in (DB+"-wal",DB+"-shm"):
                        try:
                            if os.path.exists(sidecar):os.remove(sidecar)
                        except OSError:pass
                    os.replace(tmp,DB); tmp=None
                    self.db=sqlite3.connect(DB); self.db.execute("PRAGMA foreign_keys=ON"); self.db.execute("PRAGMA journal_mode=DELETE"); self.db.commit()
                    self._ensure_krw_schema()
                    self._krw_password=pw; self._reload_after_krw_open()
                    messagebox.showinfo("باز کردن فایل","فایل اطلاعات با موفقیت باز شد."); return
                finally:
                    if tmp:
                        try:os.remove(tmp)
                        except OSError:pass
            except Exception as e: errors.append(str(e))
        typed=simpledialog.askstring("رمز فایل KRW","این فایل با رمز ذخیره شده است یا رمز فعلی متفاوت است.\nرمز را وارد کنید:",show="*")
        if typed is None:return
        try:
            tmp=self._decode_krw_to_db(path,typed)
            if not messagebox.askyesno("باز کردن فایل","اطلاعات فعلی با فایل انتخاب‌شده جایگزین می‌شود.\nیک نسخه پشتیبان ساخته می‌شود.\nادامه می‌دهید?"):
                try:os.remove(tmp)
                except OSError:pass
                return
            try:
                os.makedirs(BACKUP_DIR,exist_ok=True)
                safety=os.path.join(BACKUP_DIR,"before_open_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".db")
                try:self.db.commit()
                except Exception:pass
                if os.path.exists(DB):shutil.copy2(DB,safety)
                try:self.db.close()
                except Exception:pass
                for sidecar in (DB+"-wal",DB+"-shm"):
                    try:
                        if os.path.exists(sidecar):os.remove(sidecar)
                    except OSError:pass
                os.replace(tmp,DB); tmp=None
                self.db=sqlite3.connect(DB); self.db.execute("PRAGMA foreign_keys=ON"); self.db.execute("PRAGMA journal_mode=DELETE"); self.db.commit()
                self._ensure_krw_schema()
                self._krw_password=typed; self._reload_after_krw_open()
                messagebox.showinfo("باز کردن فایل","فایل اطلاعات با موفقیت باز شد.")
            finally:
                if tmp:
                    try:os.remove(tmp)
                    except OSError:pass
        except Exception as e:
            messagebox.showerror("باز کردن فایل",f"باز کردن فایل KRW انجام نشد:\n{e}")

    def backup_page(self):
        self.clear()
        RTLLabel(self.main,text="💾 فایل اطلاعات و بکاپ",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        f=tk.Frame(self.main,bg="#FFFFFF"); f.pack(fill="x",padx=20,pady=10)
        RTLLabel(f,text="اطلاعات اصلی در فایل SQLite نگهداری می‌شود. هر ۱ دقیقه یک بکاپ رمزگذاری‌شده خودکار ساخته می‌شود.",
                 bg="#FFFFFF",fg="#C7CFD7",font=ui_font(10)).pack(anchor="e",padx=20,pady=15)
        pw=tk.StringVar()
        self._krw_password_var=pw
        RTLLabel(f,text="رمز فایل KRW (اختیاری؛ برای ذخیره بدون رمز خالی بگذارید)",bg="#FFFFFF",fg="#1B2733").pack(anchor="e",padx=20)
        tk.Entry(f,textvariable=pw,show="*",bg="#FFFFFF",fg="#1B2733",insertbackground="white",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3").pack(fill="x",padx=20,pady=6,ipady=7)
        self._krw_password=""
        pw.trace_add("write",lambda *a:setattr(self,"_krw_password",pw.get()))
        row=tk.Frame(f,bg="#FFFFFF"); row.pack(fill="x",padx=20,pady=10)
        def backup():
            if not pw.get(): messagebox.showwarning("بکاپ","رمز بکاپ را وارد کنید."); return
            path=filedialog.asksaveasfilename(defaultextension=".jba11",filetypes=[("Jahan Backup","*.jba11")])
            if not path:return
            try:self.create_encrypted_backup(path,pw.get()); messagebox.showinfo("بکاپ","بکاپ رمزگذاری‌شده با موفقیت ذخیره شد.")
            except Exception as e: messagebox.showerror("بکاپ",str(e))
        def restore():
            if not pw.get(): messagebox.showwarning("Restore","رمز بکاپ را وارد کنید."); return
            path=filedialog.askopenfilename(filetypes=[("Jahan Backup","*.jba11")])
            if not path:return
            if not messagebox.askyesno("تأیید Restore","داده‌های فعلی با این بکاپ جایگزین می‌شود. ادامه می‌دهید؟"): return
            try:
                self.restore_encrypted_backup(path,pw.get()); messagebox.showinfo("Restore","بازیابی انجام شد. برنامه دوباره بارگذاری می‌شود."); self.destroy()
            except Exception as e: messagebox.showerror("Restore",str(e))
        def open_db():
            path=filedialog.askopenfilename(filetypes=[("SQLite database","*.db"),("All files","*.*")])
            if not path:return
            if messagebox.askyesno("Open","فایل انتخاب‌شده جای فایل اطلاعات فعلی قرار بگیرد؟"):
                try:
                    self.db.close(); shutil.copy2(path,DB); self.db=sqlite3.connect(DB); self.dashboard()
                except Exception as e: messagebox.showerror("Open",str(e))
        def full_backup():
            if not pw.get(): messagebox.showwarning("بکاپ کامل","رمز بکاپ را وارد کنید."); return
            path=filedialog.asksaveasfilename(defaultextension=".jaf11",filetypes=[("Jahan Full Backup","*.jaf11")])
            if not path:return
            try:self.create_full_backup(path,pw.get()); messagebox.showinfo("بکاپ کامل","بکاپ کامل نرم افزار و فایل‌های آن ذخیره شد.")
            except Exception as e: messagebox.showerror("بکاپ کامل",str(e))
        self.button(row,"💾 ذخیره سریع KRW",self.quick_krw_save,"#B58E45").pack(side="right",padx=5)
        self.button(row,"📂 بازکردن KRW",self.open_krw,"#2D7FA3").pack(side="right",padx=5)
        self.button(row,"💾 Backup دستی",backup).pack(side="right",padx=5)
        self.button(row,"📦 Backup کل نرم افزار",full_backup).pack(side="right",padx=5)
        self.button(row,"🔄 Restore",restore).pack(side="right",padx=5)
        self.button(row,"📂 Open فایل اطلاعات",open_db).pack(side="right",padx=5)
        self.button(row,"📁 بازکردن پوشه بکاپ",lambda:os.startfile(BACKUP_DIR) if os.name=="nt" else webbrowser.open("file://"+BACKUP_DIR)).pack(side="left")
        RTLLabel(self.main,text=f"مسیر بکاپ خودکار KRW: {KRW_AUTO_DIR}",bg="#F4F6F8",fg="#7D8892").pack(anchor="e",padx=25,pady=10)

    def _bank_sites(self):
        return [
            ("بانک صادرات ایران", "https://www.bsi.ir/", "سپینو / خدمات بانک صادرات"),
            ("بانک ملی ایران", "https://bmi.ir/", "بام و خدمات بانک ملی"),
            ("بانک ایران‌زمین", "https://izbank.ir/", "بانکداری مدرن و فراز"),
            ("بانک ملت", "https://www.bankmellat.ir/", "سایت رسمی بانک ملت"),
            ("بانک تجارت", "https://www.tejaratbank.ir/", "سایت رسمی بانک تجارت"),
            ("بانک پاسارگاد", "https://www.bpi.ir/", "سایت رسمی بانک پاسارگاد"),
            ("بانک پارسیان", "https://www.parsian-bank.ir/", "سایت رسمی بانک پارسیان"),
            ("بانک شهر", "https://www.shahr-bank.ir/", "سایت رسمی بانک شهر"),
            ("بانک رفاه کارگران", "https://www.refah-bank.ir/", "سایت رسمی بانک رفاه"),
            ("پست بانک ایران", "https://www.postbank.ir/", "سایت رسمی پست بانک"),
            ("بانک مسکن", "https://www.bank-maskan.ir/", "سایت رسمی بانک مسکن"),
            ("بانک سامان", "https://www.sb24.com/", "سایت رسمی بانک سامان"),
            ("بانک گردشگری", "https://www.tourismbank.ir/", "سایت رسمی بانک گردشگری"),
            ("بانک دی", "https://www.day24.ir/", "سایت رسمی بانک دی"),
            ("بانک کارآفرین", "https://www.karafarinbank.ir/", "سایت رسمی بانک کارآفرین"),
        ]

    def _open_iran_browser(self, url, new_window=True):
        proxy=self.db.execute("SELECT value FROM app_settings WHERE key='iran_proxy'").fetchone()
        proxy_url=(proxy[0].strip() if proxy and proxy[0] else '')
        # مرورگر خارجی فقط وقتی با پراکسی مشخص اجرا می‌شود که کاربر یک پراکسی/VPN معتبر در اختیار داشته باشد.
        if proxy_url and os.name=='nt':
            candidates=[]
            for exe in ('chrome.exe','msedge.exe','brave.exe'):
                hit=shutil.which(exe)
                if hit: candidates.append(hit)
            if candidates:
                try:
                    subprocess.Popen([candidates[0], f'--proxy-server={proxy_url}', url],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except Exception:
                    pass
        webbrowser.open(url, new=2 if new_window else 0)

    def _iran_proxy_settings(self, parent):
        win=tk.Toplevel(parent); win.title("شبکه ایران / پراکسی"); win.geometry("640x310"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text="🌐 دسترسی پایدار به سایت‌های بانکی ایران",bg="#F4F6F8",fg="#1B2733",font=ui_font(16,"bold")).pack(pady=16)
        RTLLabel(win,text="برای تغییر IP به ایران باید یک VPN یا پراکسی معتبر با خروجی ایران داشته باشید. برنامه خودش پراکسی رایگان یا IP ایران تولید نمی‌کند.",bg="#F4F6F8",fg="#687582",font=ui_font(10),justify="right").pack(fill="x",padx=20,pady=6)
        row=tk.Frame(win,bg="#F4F6F8"); row.pack(fill="x",padx=20,pady=10)
        tk.Label(row,text="HTTP/SOCKS5 Proxy",bg="#F4F6F8",fg="#1B2733",font=ui_font(10)).pack(side="right",padx=5)
        v=tk.StringVar(); old=self.db.execute("SELECT value FROM app_settings WHERE key='iran_proxy'").fetchone(); v.set(old[0] if old else '')
        e=tk.Entry(row,textvariable=v,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); e.pack(side="right",fill="x",expand=True,ipady=8)
        def save():
            self.db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('iran_proxy',?)",(v.get().strip(),)); self.db.commit(); win.destroy()
        self.button(win,"💾 ذخیره تنظیمات",save,"#B58E45").pack(side="bottom",pady=12)
        RTLLabel(win,text="نمونه: http://127.0.0.1:8080 یا socks5://127.0.0.1:1080\nبعد از ذخیره، دکمه‌های بانک در Chrome/Edge/Brave با همان پراکسی باز می‌شوند.",bg="#F4F6F8",fg="#7D8892",font=ui_font(9),justify="center").pack(pady=4)

    def online_page(self):
        self.clear()
        RTLLabel(self.main,text="🌐 مرورگر و بانک‌های ایران",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=(14,3))
        RTLLabel(self.main,text="دسترسی مرتب به سایت‌های بانکی رسمی، آدرس دلخواه و تنظیم Proxy/VPN",bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,8))
        bar=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); bar.pack(fill="x",padx=20,pady=8)
        url=tk.StringVar(value="https://www.bsi.ir/")
        ent=tk.Entry(bar,textvariable=url,bg="#F8FAFC",fg="#1B2733",insertbackground="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(11),justify="right")
        ent.pack(side="right",fill="x",expand=True,padx=10,pady=10,ipady=7)
        self.button(bar,"🌐 بازکردن",lambda:self._open_iran_browser(url.get().strip()),"#2563EB").pack(side="left",padx=5,pady=7)
        self.button(bar,"⚙ شبکه ایران",lambda:self._iran_proxy_settings(self),"#64748B").pack(side="left",padx=5,pady=7)
        notice=tk.Frame(self.main,bg="#FFF8E7",highlightbackground="#E8D59A",highlightthickness=1); notice.pack(fill="x",padx=20,pady=5)
        RTLLabel(notice,text="🔐 فقط دامنه رسمی بانک را بررسی کنید. IP ایران فقط با VPN/Proxy معتبر قابل استفاده است؛ برنامه IP جعلی تولید نمی‌کند.",bg="#FFF8E7",fg="#765B16",font=ui_font(9)).pack(anchor="e",padx=14,pady=8)
        bankbox=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1); bankbox.pack(fill="both",expand=True,padx=20,pady=8)
        top=tk.Frame(bankbox,bg="#FFFFFF"); top.pack(fill="x")
        RTLLabel(top,text="🏦 بانک‌های ایرانی",bg="#FFFFFF",fg="#1B2733",font=ui_font(13,"bold")).pack(side="right",padx=15,pady=10)
        search=tk.StringVar(); tk.Entry(top,textvariable=search,bg="#F8FAFC",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",font=ui_font(10),justify="right").pack(side="left",fill="x",expand=True,padx=15,pady=8,ipady=5)
        grid=tk.Frame(bankbox,bg="#FFFFFF"); grid.pack(fill="both",expand=True,padx=12,pady=4)
        sites=self._bank_sites(); buttons=[]
        for i,(name,link,desc) in enumerate(sites):
            card=tk.Frame(grid,bg="#F8FAFC",highlightbackground="#D8DEE4",highlightthickness=1); card.grid(row=i//3,column=i%3,padx=5,pady=5,sticky="nsew")
            RTLLabel(card,text="🏦 "+name,bg="#F8FAFC",fg="#1B2733",font=ui_font(10,"bold")).pack(fill="x",padx=8,pady=(7,1))
            RTLLabel(card,text=desc,bg="#F8FAFC",fg="#687582",font=ui_font(8),justify="right").pack(fill="x",padx=8)
            b=self.button(card,"بازکردن سایت",lambda l=link,n=name:(url.set(l),self._open_iran_browser(l)),"#334155"); b.pack(anchor="e",padx=8,pady=6)
            buttons.append((name,card))
        for c in range(3): grid.columnconfigure(c,weight=1)
        for r in range((len(sites)+2)//3): grid.rowconfigure(r,weight=1)
        def filter_banks(*_):
            term=search.get().strip().lower()
            for name,card in buttons:
                card.grid() if (not term or term in name.lower()) else card.grid_remove()
        search.trace_add("write",filter_banks)
        quick=tk.Frame(self.main,bg="#F4F6F8"); quick.pack(fill="x",padx=20,pady=5)
        for name,link in [("بانک صادرات","https://www.bsi.ir/"),("بانک ملی","https://bmi.ir/"),("بانک ایران‌زمین","https://izbank.ir/"),("بانک مرکزی","https://www.cbi.ir/")]:
            self.button(quick,name,lambda l=link:(url.set(l),self._open_iran_browser(l)),"#475569").pack(side="right",padx=4)
        ent.bind("<Return>",lambda e:self._open_iran_browser(url.get().strip()))


    def license_info_page(self):
        win=tk.Toplevel(self); win.title("نسخه و سریال"); win.geometry("520x360"); win.configure(bg="#F4F6F8")
        RTLLabel(win,text=f"نسخه {APP_VERSION}",bg="#F4F6F8",fg="#1B2733",font=ui_font(17,"bold")).pack(pady=20)
        RTLLabel(win,text="شناسه دستگاه:",bg="#F4F6F8",fg="#687582").pack(anchor="e",padx=25)
        e=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3"); e.pack(fill="x",padx=25,pady=6,ipady=7); e.insert(0,self.device_id()); e.config(state="readonly")
        row=self.db.execute("SELECT value FROM app_settings WHERE key='license_serial'").fetchone()
        valid = bool(row and hmac.compare_digest(str(row[0]).strip().upper(), self.expected_serial()) and self.db.execute("SELECT value FROM app_settings WHERE key='license_device'").fetchone() and self.db.execute("SELECT value FROM app_settings WHERE key='license_device'").fetchone()[0] == self.device_id())
        RTLLabel(win,text="سریال ثبت‌شده: "+("فعال و معتبر برای این دستگاه" if valid else "فعال نشده یا نامعتبر"),
                 bg="#F4F6F8",fg="#35a9ff",font=ui_font(10,"bold")).pack(pady=15)
        # Android activation uses the same JAHAN11 license secret and serial format,
        # but has its own device identifier. The PC remains the license authority.
        RTLLabel(win,text="تولید سریال نسخه Android",bg="#F4F6F8",fg="#1B2733",font=ui_font(11,"bold")).pack(anchor="e",padx=25,pady=(8,3))
        android_id=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1); android_id.pack(fill="x",padx=25,pady=4,ipady=7)
        android_serial=tk.Entry(win,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,justify="center",font=ui_font(10,"bold")); android_serial.pack(fill="x",padx=25,pady=4,ipady=7)
        def make_android_serial():
            did=android_id.get().strip().upper()
            if not did:
                android_serial.delete(0,"end"); return
            digest=hmac.new(LICENSE_SECRET,did.encode(),hashlib.sha256).hexdigest().upper()
            value="JAHAN11-"+"-".join(digest[i:i+4] for i in range(0,16,4))
            android_serial.delete(0,"end"); android_serial.insert(0,value)
        self.button(win,"🔑 تولید سریال Android",make_android_serial,"#C39A4D").pack(side="bottom",pady=5)
        self.button(win,"🌐 بررسی/دریافت اطلاعات آپدیت",lambda:webbrowser.open("https://github.com/")).pack(side="bottom",pady=8)
        RTLLabel(win,text="برای انتشار آپدیت، فایل نسخه جدید را از لینک رسمی پروژه دریافت و نصب کنید.\nقبل از آپدیت یک Backup بگیرید.",
                 bg="#F4F6F8",fg="#7D8892",font=ui_font(9),justify="center").pack(pady=10)

    def settings_page(self):
        self.clear()
        RTLLabel(self.main,text="تنظیمات",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=15)
        f=tk.Frame(self.main,bg="#FFFFFF"); f.pack(fill="x",padx=20,pady=10)
        RTLLabel(f,text="واتساپ مشتری",bg="#FFFFFF",fg="#1B2733",
                 font=ui_font(12,"bold")).pack(anchor="e",padx=20,pady=15)
        phone=tk.StringVar()
        tk.Entry(f,textvariable=phone,bg="#FFFFFF",fg="#1B2733",
                 insertbackground="white",relief="flat").pack(fill="x",padx=20,pady=5,ipady=8)
        self.button(f,"باز کردن واتساپ",lambda:self.whatsapp(phone.get())).pack(anchor="e",padx=20,pady=15)
        RTLLabel(f,text="ارزهای فعال: دلار، یورو، افغانی، تومان، کلدار",
                 bg="#FFFFFF",fg="#687582",font=ui_font(11)).pack(anchor="e",padx=20,pady=20)
        self.button(self.main,"🏢 مشخصات شرکت / صرافی برای فایل‌های ارسالی",lambda:self._show_outgoing_profile_dialog(first_run=False),"#0F766E").pack(pady=8)
        self.button(self.main,"🔑 حساب کاربری و رمز عبور",self.manage_user_page,"#334155").pack(pady=8)
        self.button(self.main,"🧾 اطلاعات نسخه و سریال",self.license_info_page,"#334155").pack(pady=4)
        RTLLabel(self.main,text=f"نرم افزار حسابداری جهان | نسخه {APP_VERSION}",
                 bg="#F4F6F8",fg="#35a9ff",font=ui_font(14,"bold")).pack(pady=(20,2))
        RTLLabel(self.main,text="خالد رحیمی  |  شماره تماس: ۰۷۹۶۲۹۷۹۹۶",
                 bg="#F4F6F8",fg="#687582",font=ui_font(10)).pack(pady=(0,20))

    def help_page(self):
        """A single, always-available Persian guide to every part of the
        program - a simple two-column help browser: topics on the right,
        the explanation of whichever one is selected on the left."""
        self.clear()
        RTLLabel(self.main,text="📖 راهنمای کامل برنامه",bg="#F4F6F8",fg="#1B2733",
                 font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=(15,2))
        RTLLabel(self.main,text="از لیست زیر موضوع مورد نظرتان را انتخاب کنید تا توضیح کامل آن نمایش داده شود.",
                 bg="#F4F6F8",fg="#687582",font=ui_font(9)).pack(anchor="e",padx=20,pady=(0,10))

        body=tk.Frame(self.main,bg="#F4F6F8"); body.pack(fill="both",expand=True,padx=20,pady=(0,18))

        topics_col=tk.Frame(body,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1,width=250)
        topics_col.pack(side="right",fill="y",padx=(8,0)); topics_col.pack_propagate(False)
        q=tk.StringVar()
        search_entry=tk.Entry(topics_col,textvariable=q,bg="#FFFFFF",fg="#1B2733",relief="solid",bd=1,
                 highlightthickness=1,highlightbackground="#C7D0D9",highlightcolor="#2D7FA3",
                 font=ui_font(10),justify="right")
        search_entry.pack(fill="x",padx=10,pady=10,ipady=6)
        list_canvas=tk.Canvas(topics_col,bg="#FFFFFF",highlightthickness=0,bd=0)
        list_canvas.pack(side="left",fill="both",expand=True)
        list_holder=tk.Frame(list_canvas,bg="#FFFFFF")
        list_window=list_canvas.create_window((0,0),window=list_holder,anchor="nw")
        list_holder.bind("<Configure>",lambda e:list_canvas.configure(scrollregion=list_canvas.bbox("all")))
        list_canvas.bind("<Configure>",lambda e:list_canvas.itemconfigure(list_window,width=max(1,e.width)))

        content_box=tk.Frame(body,bg="#FFFFFF",highlightbackground="#D8DEE4",highlightthickness=1)
        content_box.pack(side="left",fill="both",expand=True)
        content_title=RTLLabel(content_box,text="",bg="#FFFFFF",fg="#B58E45",font=ui_font(15,"bold"))
        content_title.pack(anchor="e",padx=18,pady=(16,6))
        content_wrap=tk.Frame(content_box,bg="#FFFFFF"); content_wrap.pack(fill="both",expand=True,padx=(4,4),pady=(0,14))
        content_scroll=tk.Scrollbar(content_wrap,orient="vertical")
        content_text=tk.Text(content_wrap,bg="#FFFFFF",fg="#1B2733",relief="flat",font=ui_font(11),
                              wrap="word",padx=16,pady=4,state="disabled",cursor="arrow",
                              yscrollcommand=content_scroll.set)
        content_scroll.configure(command=content_text.yview)
        content_scroll.pack(side="right",fill="y")
        content_text.pack(side="left",fill="both",expand=True)
        content_text.tag_configure("rtl", justify="right")

        def show_topic(title, body_text):
            content_title.config(text=title)
            content_text.config(state="normal")
            content_text.delete("1.0","end")
            content_text.insert("1.0", body_text, "rtl")
            content_text.config(state="disabled")
            content_text.yview_moveto(0)

        def render_list(*_a):
            for w in list_holder.winfo_children(): w.destroy()
            needle=q.get().strip().lower()
            shown=[(t,b) for t,b in HELP_TOPICS if (not needle) or needle in t.lower() or needle in b.lower()]
            if not shown:
                RTLLabel(list_holder,text="چیزی پیدا نشد.",bg="#FFFFFF",fg="#9AA6B2",
                         font=ui_font(9)).pack(padx=10,pady=14)
                return
            for title,body_text in shown:
                b=RTLButton(list_holder,text="\u200f"+title,command=lambda t=title,bd=body_text:show_topic(t,bd),
                            bg="#FFFFFF",fg="#1B2733",activebackground="#F8F1DF",activeforeground="#8F6A2E",
                            relief="flat",bd=0,font=ui_font(10,"bold"),anchor="e",justify="right",
                            padx=12,pady=9,cursor="hand2")
                b.pack(fill="x",padx=6,pady=1)
                bind_smooth_hover(b,"#FFFFFF","#F8F1DF","#1B2733","#8F6A2E")

        q.trace_add("write", render_list)
        render_list()
        if HELP_TOPICS:
            show_topic(HELP_TOPICS[0][0], HELP_TOPICS[0][1])

    def about_page(self):
        self.clear()
        RTLLabel(self.main,text="درباره",bg="#F4F6F8",fg="#1B2733",font=ui_font(20,"bold")).pack(anchor="e",padx=20,pady=18)
        card=tk.Frame(self.main,bg="#FFFFFF",highlightbackground="#174e70",highlightthickness=1)
        card.pack(fill="x",padx=20,pady=8)
        RTLLabel(card,text="نرم افزار حسابداری جهان",bg="#FFFFFF",fg="#D6B66A",font=ui_font(18,"bold")).pack(anchor="e",padx=22,pady=(22,8))
        RTLLabel(card,text=f"نسخه {APP_VERSION}",bg="#FFFFFF",fg="#687582",font=ui_font(10)).pack(anchor="e",padx=22,pady=(0,16))
        RTLLabel(card,text="📍 آدرس مغازه: نیمروز، شهر زرنج، مارکت صدیقی",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold"),anchor="e",justify="right").pack(fill="x",padx=22,pady=7)
        RTLLabel(card,text="☎ شماره تماس: ۰۷۹۶۲۹۷۹۹۶",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold"),anchor="e",justify="right").pack(fill="x",padx=22,pady=7)
        RTLLabel(card,text="📱 واتساپ: ۰۷۹۶۲۹۷۹۹۶",bg="#FFFFFF",fg="#1B2733",font=ui_font(12,"bold"),anchor="e",justify="right").pack(fill="x",padx=22,pady=7)
        self.button(card,"📱 باز کردن واتساپ",lambda:self.whatsapp("۰۷۹۶۲۹۷۹۹۶"),"#128c7e").pack(anchor="e",padx=22,pady=(12,8))
        RTLLabel(card,text="برای ارتباط و پشتیبانی می‌توانید از همین شماره با ما تماس بگیرید یا در واتساپ پیام بدهید.",bg="#FFFFFF",fg="#687582",font=ui_font(10),anchor="e",justify="right",wraplength=700).pack(fill="x",padx=22,pady=(4,22))

    def whatsapp(self,phone):
        p=''.join(ch for ch in phone if ch.isdigit())
        if not p: messagebox.showwarning("واتساپ","شماره تماس را وارد کنید."); return
        webbrowser.open("https://wa.me/"+p)

if __name__=="__main__":
    try:
        App().mainloop()
    except Exception as exc:
        # pythonw.exe hides the console, so keep a visible diagnostic trail.
        # Write both beside the EXE (when possible) and in LocalAppData so a
        # Program Files installation can always retain its startup log.
        try:
            import traceback
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            log_paths = []
            for folder in (BASE, USER_DATA_BASE):
                try:
                    os.makedirs(folder, exist_ok=True)
                    path = os.path.join(folder, "startup_error.log")
                    with open(path, "a", encoding="utf-8") as fh:
                        fh.write("\n=== %s ===\n" % stamp)
                        fh.write(details)
                    log_paths.append(path)
                except Exception:
                    pass
            log_hint = log_paths[-1] if log_paths else "startup_error.log"
            short = str(exc).strip() or type(exc).__name__
            msg = "برنامه نتوانست باز شود.\n\nخطا: %s\n\nگزارش کامل:\n%s" % (short, log_hint)
            try:
                messagebox.showerror("خطای اجرای برنامه", msg, parent=None)
            except Exception:
                pass
        except Exception:
            pass
