GEONOV VISUAL — Android project

Что это:
- Ваш HTML помещён внутрь Android-приложения (WebView).
- Netlify и сайт-хостинг не используются.
- Название приложения: GEONOV VISUAL.
- Минимальная версия Android: 6.0 (API 23).

Важно:
HTML загружает Cytoscape.js с cdnjs.cloudflare.com. Поэтому для отображения графа нужен интернет.
Сам HTML встроен в APK, но библиотека графов пока загружается из сети.
Проекты сохраняются локально в хранилище WebView; перед удалением данных приложения экспортируйте JSON как резервную копию.

Как собрать APK в Windows 11:
1. Установите Android Studio с официального сайта developer.android.com/studio.
2. Распакуйте весь архив в обычную папку, например C:\GEONOV_VISUAL_Android.
3. Откройте Android Studio → Open → выберите папку GEONOV_VISUAL_Android (в ней лежат settings.gradle и build.gradle).
4. Дождитесь окончания Gradle Sync. Если Android Studio попросит установить Android SDK 35 или обновить компоненты, согласитесь.
5. В меню Build выберите Build Bundle(s) / APK(s) → Build APK(s).
6. После успешной сборки нажмите locate в уведомлении Android Studio. APK обычно находится в app\build\outputs\apk\debug\app-debug.apk.
7. Перенесите app-debug.apk на Android-телефон и откройте его для установки. Возможно, Android попросит разрешить установку из этого источника.

Если сборка выдаст ошибку:
- Проверьте, что Android Studio завершила Gradle Sync.
- Скопируйте сюда первую красную строку ошибки.

Примечание:
Этот архив — проект для сборки, а не готовый APK. В этой среде Android SDK/Gradle не установлены, поэтому APK здесь не скомпилирован.
