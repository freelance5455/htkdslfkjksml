STEP 21 – Rezeptbank auf über 2.000 Weltrezepte erweitert

Basis: STEP 20 Vorsorge Bestandsabgleich.

Änderung:
- Rezeptbank von 1.291 auf 2.041 Einträge erweitert.
- Zusätzliche Küchen aus Europa, Afrika, Nahost, Asien und Amerika.
- Bestehende Vorrats-Matching-, Geräte-, Such- und Filterlogik bleibt erhalten.
- Keine Supabase-Migration nötig.

Hinweis:
Die zusätzlichen Einträge sind als strukturierte Vorratsrezepte mit Zutaten, Match-Begriffen und kurzer Zubereitung hinterlegt.
