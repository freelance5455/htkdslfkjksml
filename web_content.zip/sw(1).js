const CACHE = "vrig-v4";
const SHELL = ['./', 'index.html', 'style.css', 'manifest.webmanifest', 'js/main.js', 'js/rig.js', 'js/params.js', 'js/demo.js', 'js/tracker.js', 'js/warp.js', 'js/anim.js', 'js/mesh.js', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const cdn = ['cdn.jsdelivr.net', 'storage.googleapis.com'].includes(url.hostname);
  if (url.origin !== location.origin && !cdn) return;
  // app: rede primeiro (pega atualizações), cache como fallback offline.
  // CDN (MediaPipe + modelo): cache primeiro (arquivos versionados e pesados).
  if (cdn) {
    e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => { if (r.ok) { const c = r.clone(); caches.open(CACHE).then(ch => ch.put(req, c)); } return r; })));
  } else {
    e.respondWith(fetch(req).then(r => { const c = r.clone(); caches.open(CACHE).then(ch => ch.put(req, c)); return r; }).catch(() => caches.match(req)));
  }
});
