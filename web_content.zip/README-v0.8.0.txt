blure v0.8.0
Upload the CONTENTS of this ZIP to InfinityFree htdocs.
Changes: pink/white/charcoal theme, rounded corners, glass menus, local multi-file workspace, random and math functions in PHP/JS, updated service worker and docs.
NOTE: Project files are stored in this browser (localStorage). Export project JSON regularly. Running code executes the active .blu file only; cross-file imports are not supported.
Online PHP and offline JavaScript interpreters use separate execution paths. Verify both on your hosting environment.

Rounded styling refresh: blure-rounded.css, polished workspace, new offline cache.
