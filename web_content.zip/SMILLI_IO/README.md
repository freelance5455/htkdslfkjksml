# SMILLI.IO — versão corrigida

## Correções
- Menu **TODAS AS SKINS**, mostrando a coleção, raridade, preço e botões de compra/equipar.
- Menu **ADM / CREDENCIAL**, com campos separados para nick e senha.
- Validação da credencial pelo servidor em `/api/admin/login`.
- Após autenticar, o painel permite ativar/desativar moedas infinitas e liberar todas as skins.
- Arena vermelha mantida.

## Como iniciar
1. Instale Node.js LTS no computador.
2. Extraia o ZIP e abra o terminal dentro da pasta `SMILLI_IO`.
3. Execute `npm install`.
4. Copie `.env.example` para `.env`.
5. Edite `.env` e escolha seu nick e sua própria senha administrativa.
6. Execute `npm start`.
7. Acesse `http://localhost:3000`.

**Importante:** abrir `index.html` diretamente pelo gerenciador de arquivos não permite validar a credencial. O login administrativo precisa do servidor Node.js rodando. Para jogar no celular, publique o servidor com HTTPS e abra o endereço hospedado.

## Segurança
`.env.example` contém somente valores de exemplo. Troque `ADMIN_PASSWORD` antes de usar e não publique nem compartilhe o arquivo `.env`.

## Moedas infinitas
É um modo administrativo de teste. Quando ativado, o saldo aparece como `∞` e as skins podem ser liberadas sem gastar moedas. Ao recarregar a página, será necessário autenticar novamente.

## O que ainda é protótipo
O multiplayer completo, colisões/eliminações, ranking global e contas sincronizadas ainda precisam de desenvolvimento adicional. Os bots são locais.
