require("dotenv").config();
const express=require("express"),http=require("http"),{Server}=require("socket.io"),Database=require("better-sqlite3"),crypto=require("crypto");
const app=express(),server=http.createServer(app),io=new Server(server,{cors:{origin:true}});
const db=new Database("smilli.sqlite");
db.exec(`CREATE TABLE IF NOT EXISTS players(id TEXT PRIMARY KEY,nick TEXT,coins INTEGER DEFAULT 0,best INTEGER DEFAULT 0,skin TEXT DEFAULT 'Verde Clássica');`);
app.use(express.json());app.use(express.static("."));
const rooms=new Map(),adminTokens=new Map();
const hash=s=>crypto.createHash("sha256").update(s).digest("hex");
app.post("/api/admin/login",(req,res)=>{const {nick,password}=req.body||{};if(nick!==(process.env.ADMIN_NICK||"AdmOTA")||!process.env.ADMIN_PASSWORD||hash(password||"")!==hash(process.env.ADMIN_PASSWORD))return res.status(403).json({error:"Credenciais inválidas"});const token=crypto.randomBytes(32).toString("hex");adminTokens.set(token,true);res.json({token,admin:true});});
app.get("/health",(req,res)=>res.json({ok:true,service:"SMILLI.IO"}));
io.on("connection",socket=>{
 socket.on("joinRoom",({room="public",nick="Jogador",skin="Verde Clássica"}={})=>{
  room=String(room).slice(0,20);nick=String(nick).slice(0,18);socket.join(room);
  if(!rooms.has(room))rooms.set(room,new Map());rooms.get(room).set(socket.id,{id:socket.id,nick,skin,x:0,y:0,score:0});
  io.to(room).emit("players",Array.from(rooms.get(room).values()));
 });
 socket.on("state",data=>{for(const room of socket.rooms){if(room===socket.id)continue;const list=rooms.get(room);if(!list)continue;const p=list.get(socket.id);if(!p)return;p.x=Number(data.x)||0;p.y=Number(data.y)||0;p.score=Math.max(0,Math.min(100000,Number(data.score)||0));io.to(room).emit("players",Array.from(list.values()));}});
 socket.on("disconnect",()=>{for(const [room,list] of rooms){list.delete(socket.id);io.to(room).emit("players",Array.from(list.values()));if(!list.size)rooms.delete(room);}});
});
const port=process.env.PORT||3000;server.listen(port,()=>console.log(`SMILLI.IO server on http://localhost:${port}`));
