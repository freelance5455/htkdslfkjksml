const $=id=>document.getElementById(id);
const state={coins:Number(localStorage.coins||0),best:Number(localStorage.best||0),skin:localStorage.skin||"Verde Clássica",unlocked:JSON.parse(localStorage.unlocked||'["Verde Clássica"]'),score:0,playing:false,adminToken:null,infinite:false,rewardedFirst:false};
const skins=[
{name:"Verde Clássica",rarity:"Comum",price:0,color:"#62ff8c"},
{name:"Dragão de Fogo",rarity:"Rara",price:120,color:"#ff562e"},
{name:"Dragão de Gelo",rarity:"Épica",price:280,color:"#71eaff"},
{name:"Dragão Sombrio",rarity:"Lendária",price:650,color:"#8d68ff"},
{name:"Dragão Dourado",rarity:"Mítica",price:1000,color:"#ffd44d"},
{name:"Yin Yang",rarity:"Épica",price:280,color:"#eeeeee"},
{name:"Arco-íris",rarity:"Lendária",price:650,color:"#ff4e8a"},
{name:"Tubarão",rarity:"Rara",price:120,color:"#82c8e8"},
{name:"Dinossauro",rarity:"Épica",price:280,color:"#83b95c"},
{name:"Robô",rarity:"Lendária",price:650,color:"#9eeaff"},
{name:"Fênix",rarity:"Mítica",price:1000,color:"#ff9b32"}
];
function save(){localStorage.coins=state.coins;localStorage.best=state.best;localStorage.skin=state.skin;localStorage.unlocked=JSON.stringify(state.unlocked);$("coins").textContent=state.infinite?"∞":state.coins;$("best").textContent=state.best;$("skinLabel").textContent=state.skin}
save();
const menu=$("menu"),game=$("game"),sub=$("subview");
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>openPanel(b.dataset.view));
$("closeSub").onclick=()=>{sub.classList.add("hidden");menu.classList.remove("hidden")};
function openPanel(which){menu.classList.add("hidden");sub.classList.remove("hidden");const c=$("subContent");
if(which==="shop"){
c.innerHTML='<h2>🐍 Todas as skins</h2><p>Veja a coleção completa. Compre com moedas ou equipe as que já desbloqueou.</p><div id="items" class="skin-grid"></div>';
const box=$("items");
skins.forEach(s=>{
 const own=state.unlocked.includes(s.name), equipped=state.skin===s.name;
 box.insertAdjacentHTML("beforeend",`<div class="skin-card"><div class="skin-preview" style="background:linear-gradient(120deg,${s.color}66,#170909);border:1px solid ${s.color}">🐍</div><b>${s.name}</b><small>${s.rarity} • ${s.price===0?"GRÁTIS":`🪙 ${s.price}`}</small><button data-skin="${s.name}">${equipped?"EQUIPADA":own?"EQUIPAR":state.infinite?"LIBERAR / EQUIPAR":`COMPRAR • ${s.price} 🪙`}</button></div>`);
});
box.querySelectorAll("button").forEach(btn=>btn.onclick=()=>{
 const s=skins.find(x=>x.name===btn.dataset.skin);
 if(state.unlocked.includes(s.name)){state.skin=s.name;save();openPanel("shop");}
 else if(state.infinite||state.coins>=s.price){if(!state.infinite)state.coins-=s.price;state.unlocked.push(s.name);state.skin=s.name;save();openPanel("shop");}
 else alert("Moedas insuficientes! Jogue partidas para ganhar moedas.");
});
}
else if(which==="roulette"){c.innerHTML='<h2>🎡 Roleta</h2><div class="panel"><p>Gire por 30 moedas e tente desbloquear uma skin!</p><h2 id="prize">❔</h2><button id="spin" class="primary">GIRAR — 30 🪙</button><small>Probabilidades: Comum 50%, Rara 25%, Épica 15%, Lendária 8%, Mítica 2%.</small></div>'; $("spin").onclick=()=>{if(state.coins<30)return alert("Moedas insuficientes!");state.coins-=30;const r=Math.random(),rarity=r<.5?"Comum":r<.75?"Rara":r<.9?"Épica":r<.98?"Lendária":"Mítica";const choices=skins.filter(s=>s.rarity===rarity);const win=choices[Math.floor(Math.random()*choices.length)];if(state.unlocked.includes(win.name))state.coins+=({Comum:5,Rara:15,Épica:30,Lendária:60,Mítica:100}[rarity]);else state.unlocked.push(win.name);state.skin=win.name;$("prize").textContent=`🎉 ${win.name} — ${win.rarity}`;save();};}
else if(which==="multiplayer"){c.innerHTML='<h2>🌐 Multiplayer online</h2><div class="panel"><p>O servidor Socket.IO precisa estar iniciado e publicado para seus amigos entrarem pela internet.</p><label>ENDEREÇO DO SERVIDOR</label><input id="serverUrl" placeholder="https://seu-servidor.com"><button id="connect" class="primary">CONECTAR</button><div id="netStatus">Desconectado</div><p>Quando conectado, use o mesmo endereço para todos os jogadores.</p></div>'; $("connect").onclick=()=>{localStorage.serverUrl=$("serverUrl").value;location.reload()};}
else if(which==="missions"){c.innerHTML='<h2>🎯 Missões</h2><div class="panel"><b>Primeira partida</b><p>Jogue uma partida para receber 15 moedas.</p><span class="pill">RECOMPENSA: 15 🪙</span></div><div class="panel"><b>Sobrevivente</b><p>Alcance 500 pontos em uma partida.</p><span class="pill">RECOMPENSA: 30 🪙</span></div>';}
else if(which==="ranking"){c.innerHTML=`<h2>🏆 Ranking local</h2><div class="panel">1º — ${escapeHtml($("nick").value||"Jogador")} — recorde ${state.best}</div><p>O ranking global depende do servidor online.</p>`;}
else if(which==="admin"){
 if(state.adminToken){
  c.innerHTML=`<h2>🔐 Painel administrativo</h2><div class="panel"><div class="admin-status">Credencial validada. Área administrativa liberada.</div><p>Ative o modo de teste para usar moedas infinitas e liberar a coleção de skins neste navegador.</p><div class="admin-actions"><button id="infiniteToggle" class="primary">${state.infinite?"DESATIVAR":"ATIVAR"} MOEDAS INFINITAS</button><button id="unlockAll">LIBERAR TODAS AS SKINS</button></div><p>${state.infinite?"Modo de moedas infinitas ativado.":"Modo de moedas infinitas desativado."}</p><button id="adminLogout">SAIR DO ADMIN</button></div>`;
  $("infiniteToggle").onclick=()=>{state.infinite=!state.infinite;if(state.infinite)state.unlocked=skins.map(s=>s.name);save();openPanel("admin");};
  $("unlockAll").onclick=()=>{state.unlocked=skins.map(s=>s.name);save();openPanel("admin");};
  $("adminLogout").onclick=()=>{state.adminToken=null;state.infinite=false;save();openPanel("admin");};
 }else{
  c.innerHTML='<h2>🔐 Área administrativa</h2><div class="panel"><p>Entre com a credencial configurada no servidor do jogo.</p><label class="field-label" for="adminNick">NICK ADMINISTRADOR</label><input id="adminNick" autocomplete="username" placeholder="Digite o nick administrativo"><label class="field-label" for="adminPassword">SENHA / CREDENCIAL</label><input id="adminPassword" type="password" autocomplete="current-password" placeholder="Digite sua credencial"><button id="adminLogin" class="primary">VALIDAR CREDENCIAL</button><div id="adminMessage" class="admin-status off">Aguardando credencial.</div><small>O servidor Node.js precisa estar rodando para validar a credencial.</small></div>';
  $("adminLogin").onclick=async()=>{
   const nick=$("adminNick").value.trim(),password=$("adminPassword").value,msg=$("adminMessage");
   if(!nick||!password){msg.textContent="Preencha o nick e a credencial.";return;}
   msg.textContent="Verificando...";
   try{
    const response=await fetch("/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({nick,password})});
    const data=await response.json();
    if(!response.ok||!data.token)throw new Error(data.error||"Credencial inválida.");
    state.adminToken=data.token;state.infinite=false;openPanel("admin");
   }catch(err){msg.textContent=err.message==="Failed to fetch"?"Servidor indisponível. Inicie o jogo pelo servidor Node.js.":err.message;}
  };
 }
}
else {c.innerHTML='<h2>⚙️ Configurações</h2><div class="panel"><label>QUALIDADE GRÁFICA</label><select id="quality"><option>Alta</option><option>Média</option><option>Baixa</option></select><p>Idioma: Português (Brasil)</p><p>Controles: toque, mouse ou teclado.</p></div>';}
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

let ctx, W,H, snake, foods, bots, angle=0, boost=false, last=0, raf;
const canvas=$("arena");ctx=canvas.getContext("2d");
function resize(){const dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}addEventListener("resize",resize);
function start(){menu.classList.add("hidden");sub.classList.add("hidden");game.classList.remove("hidden");resize();state.score=0;state.rewardedFirst=false;angle=0;const cx=0,cy=0;snake=Array.from({length:18},(_,i)=>({x:cx-i*9,y:cy}));foods=Array.from({length:100},()=>({x:Math.random()*1600-800,y:Math.random()*1600-800}));bots=Array.from({length:7},(_,i)=>({x:Math.random()*1000-500,y:Math.random()*1000-500,a:Math.random()*6.28,body:[]}));bots.forEach(b=>b.body=Array.from({length:12},(_,i)=>({x:b.x-i*8,y:b.y})));$("score").textContent="0";$("gameBest").textContent=state.best;state.playing=true;cancelAnimationFrame(raf);last=0;raf=requestAnimationFrame(loop);}
$("play").onclick=start;$("back").onclick=()=>{state.playing=false;cancelAnimationFrame(raf);game.classList.add("hidden");menu.classList.remove("hidden");save()};
$("boost").onpointerdown=()=>boost=true;$("boost").onpointerup=$("boost").onpointerleave=()=>boost=false;
let pointer=null;canvas.addEventListener("pointerdown",e=>{pointer={x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId)});canvas.addEventListener("pointermove",e=>{if(pointer){const dx=e.clientX-W/2,dy=e.clientY-H/2;if(Math.hypot(dx,dy)>18)angle=Math.atan2(dy,dx)}});canvas.addEventListener("pointerup",()=>pointer=null);
addEventListener("keydown",e=>{if(e.key==="ArrowUp"||e.key==="w")angle=-Math.PI/2;if(e.key==="ArrowDown"||e.key==="s")angle=Math.PI/2;if(e.key==="ArrowLeft"||e.key==="a")angle=Math.PI;if(e.key==="ArrowRight"||e.key==="d")angle=0;if(e.code==="Space")boost=true});addEventListener("keyup",e=>{if(e.code==="Space")boost=false});
function loop(t){if(!state.playing)return;const dt=Math.min((t-last)/16||1,2);last=t;update(dt);draw();raf=requestAnimationFrame(loop)}
function update(dt){const head=snake[0],speed=(boost?3.5:2.1)*dt;let target={x:head.x+Math.cos(angle)*speed,y:head.y+Math.sin(angle)*speed};snake.unshift(target);let ate=-1;for(let i=0;i<foods.length;i++){if(Math.hypot(target.x-foods[i].x,target.y-foods[i].y)<14){ate=i;break}}if(ate>=0){foods.splice(ate,1);foods.push({x:target.x+(Math.random()-.5)*700,y:target.y+(Math.random()-.5)*700});state.score+=10;if(!state.infinite&&state.score%100===0)state.coins+=5;save();$("score").textContent=state.score;if(state.score>=100&&!state.rewardedFirst){state.rewardedFirst=true;if(!state.infinite)state.coins+=15;save();}if(state.score>state.best){state.best=state.score;$("gameBest").textContent=state.best;$("best").textContent=state.best;localStorage.best=state.best}}else snake.pop();
bots.forEach(b=>{b.a+=((Math.random()-.5)*.08);b.x+=Math.cos(b.a)*1.1*dt;b.y+=Math.sin(b.a)*1.1*dt;b.body.unshift({x:b.x,y:b.y});b.body.pop()});
$("rank").textContent=`1. ${$("nick").value||"Você"} — ${state.score}  •  ${bots.length} bots`;}
function draw(){ctx.fillStyle="#8e1717";ctx.fillRect(0,0,W,H);const head=snake[0],camX=head.x-W/2,camY=head.y-H/2;ctx.save();ctx.translate(-camX,-camY);
ctx.strokeStyle="#b84b4b";ctx.lineWidth=3;ctx.strokeRect(-900,-900,1800,1800);
for(let x=-900;x<=900;x+=60)for(let y=-900;y<=900;y+=60){ctx.fillStyle="#a52a2a";ctx.beginPath();ctx.arc(x,y,2,0,7);ctx.fill()}
foods.forEach(f=>{ctx.shadowBlur=12;ctx.shadowColor="#8cff9f";ctx.fillStyle="#a6ff75";ctx.beginPath();ctx.arc(f.x,f.y,5,0,7);ctx.fill()});ctx.shadowBlur=0;
bots.forEach(b=>drawSnake(b.body,"#f1c85a",b.a,false));
const skin=skins.find(s=>s.name===state.skin)||skins[0];drawSnake(snake,skin.color,angle,true);
ctx.restore();}
function drawSnake(body,color,a,isPlayer){body.forEach((p,i)=>{ctx.fillStyle=color;ctx.beginPath();ctx.arc(p.x,p.y,Math.max(5,11-i*.12),0,7);ctx.fill();ctx.strokeStyle="#ffffff33";ctx.lineWidth=2;ctx.stroke()});const h=body[0];if(!h)return;ctx.save();ctx.translate(h.x,h.y);ctx.rotate(a);ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(0,0,15,12,0,0,7);ctx.fill();ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(5,-5,3,0,7);ctx.arc(5,5,3,0,7);ctx.fill();ctx.fillStyle="#111";ctx.beginPath();ctx.arc(6,-5,1.4,0,7);ctx.arc(6,5,1.4,0,7);ctx.fill();if(isPlayer){ctx.fillStyle="#fff";ctx.font="10px Arial";ctx.textAlign="center";ctx.fillText("YOU",0,-18)}ctx.restore();}
// tenta conectar ao servidor informado; o modo local continua funcionando sem ele.
const serverUrl=localStorage.serverUrl;if(serverUrl&&typeof io==="function"){try{const socket=io(serverUrl,{transports:["websocket","polling"]});socket.on("connect",()=>{const n=$("netStatus");if(n)n.textContent="Conectado ao servidor"});socket.on("connect_error",()=>{const n=$("netStatus");if(n)n.textContent="Não foi possível conectar"});}catch(e){}}
