// ==============================
// Saif Ullah Manager - Data Layer
// ==============================

const STORAGE_KEY = "saif_ullah_manager_v1";

const DEFAULT_DATA = {
  version: 1,
  settings: {
    theme: "light",
    modulesPerRow: 3,
    appName: "Saif Ullah Manager"
  },
  modules: [
    { id: "home", name: "Home", icon: "🏠", color: "#4f46e5", visible: true, order: 1 },
    { id: "factory", name: "Factory", icon: "🏭", color: "#0891b2", visible: true, order: 2 },
    { id: "personal", name: "Personal", icon: "👤", color: "#7c3aed", visible: true, order: 3 },
    { id: "reports", name: "Reports", icon: "📊", color: "#059669", visible: true, order: 4 },
    { id: "settings", name: "Settings", icon: "⚙️", color: "#64748b", visible: true, order: 5 },
    { id: "more", name: "More Tools", icon: "🧰", color: "#d97706", visible: true, order: 6 }
  ],
  overviewCards: [
    {
      id: "loan",
      label: "Loan Payable",
      module: "personal",
      submodule: "loan",
      icon: "💰",
      color: "#ef4444",
      valueKey: "loanAmount",
      visible: true,
      order: 1
    },
    {
      id: "committee",
      label: "Committee",
      module: "personal",
      submodule: "committee",
      icon: "🤝",
      color: "#f59e0b",
      valueKey: "committeeAmount",
      visible: true,
      order: 2
    },
    {
      id: "leave",
      label: "Leave Balance",
      module: "personal",
      submodule: "leave",
      icon: "📅",
      color: "#10b981",
      valueKey: "leaveBalance",
      visible: true,
      order: 3
    },
    {
      id: "factory-stock",
      label: "Factory Stock",
      module: "factory",
      submodule: "stock",
      icon: "📦",
      color: "#0891b2",
      valueKey: "factoryStock",
      visible: true,
      order: 4
    }
  ],
  personal: {
    loanAmount: 75000,
    committeeAmount: 15000,
    leaveBalance: 25,
    loans: [
      { id: "l1", title: "Personal Loan - Bank", amount: 50000, date: "2025-08-12", notes: "Monthly installment" },
      { id: "l2", title: "Friend Loan", amount: 25000, date: "2025-10-01", notes: "" }
    ],
    committees: [
      { id: "c1", title: "Office Committee", amount: 10000, date: "2025-09-15", notes: "Monthly" },
      { id: "c2", title: "Family Committee", amount: 5000, date: "2025-10-20", notes: "" }
    ],
    leaves: [
      { id: "lv1", type: "Casual", days: 10, used: 3 },
      { id: "lv2", type: "Sick", days: 10, used: 2 },
      { id: "lv3", type: "Annual", days: 14, used: 4 }
    ]
  },
  factory: {
    stock: 1280,
    items: [
      { id: "f1", name: "Raw Material A", qty: 450, unit: "kg" },
      { id: "f2", name: "Finished Goods B", qty: 320, unit: "pcs" },
      { id: "f3", name: "Packaging", qty: 510, unit: "pcs" }
    ]
  },
  recentActivities: [
    { id: "a1", text: "Loan payment recorded", time: "2 hours ago", icon: "💰" },
    { id: "a2", text: "Leave requested", time: "Yesterday", icon: "📅" },
    { id: "a3", text: "Factory stock updated", time: "2 days ago", icon: "📦" }
  ]
};

// Load data from localStorage or return defaults
function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveData(DEFAULT_DATA);
      return structuredClone(DEFAULT_DATA);
    }
    const data = JSON.parse(raw);
    // Merge with defaults for any missing keys (forward compatibility)
    return deepMerge(structuredClone(DEFAULT_DATA), data);
  } catch (e) {
    console.error("Failed to load data:", e);
    return structuredClone(DEFAULT_DATA);
  }
}

function saveData(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return true;
  } catch (e) {
    console.error("Failed to save data:", e);
    return false;
  }
}

function deepMerge(target, source) {
  for (const key in source) {
    if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
      if (!target[key]) target[key] = {};
      deepMerge(target[key], source[key]);
    } else if (source[key] !== undefined) {
      target[key] = source[key];
    }
  }
  return target;
}

function generateId(prefix = "id") {
  return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function formatNumber(num) {
  if (num === null || num === undefined) return "—";
  return Number(num).toLocaleString("en-PK");
}

function formatCurrency(num) {
  return "Rs " + formatNumber(num);
}

// Export for app.js
window.AppData = {
  loadData,
  saveData,
  generateId,
  formatNumber,
  formatCurrency,
  DEFAULT_DATA,
  STORAGE_KEY
};
