// ==============================
// Saif Ullah Manager - Main App
// ==============================

const { loadData, saveData, generateId, formatNumber, formatCurrency } = window.AppData;

let state = {
  data: null,
  currentPage: "dashboard",
  settingsTab: "overview"
};

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", () => {
  state.data = loadData();
  applyTheme(state.data.settings.theme);
  setupNavigation();
  setupThemeToggle();
  setupModal();
  renderPage("dashboard");
});

// ---------- Theme ----------
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  state.data.settings.theme = theme;
  saveData(state.data);
}

function setupThemeToggle() {
  document.getElementById("themeToggle").addEventListener("click", () => {
    const next = state.data.settings.theme === "light" ? "dark" : "light";
    applyTheme(next);
    showToast(next === "dark" ? "Dark mode on" : "Light mode on");
  });
}

// ---------- Navigation ----------
function setupNavigation() {
  document.querySelectorAll(".nav-item").forEach(btn => {
    btn.addEventListener("click", () => {
      const page = btn.dataset.page;
      if (page === "more") {
        showToast("More Tools coming soon");
        return;
      }
      setActiveNav(page);
      renderPage(page);
    });
  });
}

function setActiveNav(page) {
  document.querySelectorAll(".nav-item").forEach(b => {
    b.classList.toggle("active", b.dataset.page === page);
  });
  state.currentPage = page;
}

function setPageTitle(title, subtitle = "Saif Ullah Manager") {
  document.getElementById("pageTitle").textContent = title;
  document.querySelector(".subtitle").textContent = subtitle;
}

// ---------- Toast ----------
function showToast(msg, duration = 2200) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.remove("hidden");
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.add("hidden"), duration);
}

// ---------- Modal ----------
function setupModal() {
  document.getElementById("modalClose").addEventListener("click", closeModal);
  document.getElementById("modal").addEventListener("click", (e) => {
    if (e.target.id === "modal") closeModal();
  });
}

function openModal(title, bodyHtml, footerHtml = "") {
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalBody").innerHTML = bodyHtml;
  document.getElementById("modalFooter").innerHTML = footerHtml;
  document.getElementById("modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

// ---------- Page Router ----------
function renderPage(page) {
  const main = document.getElementById("mainContent");
  main.innerHTML = "";

  switch (page) {
    case "dashboard":
      setPageTitle("Dashboard");
      main.innerHTML = renderDashboard();
      break;
    case "personal":
      setPageTitle("Personal");
      main.innerHTML = renderPersonal();
      break;
    case "factory":
      setPageTitle("Factory");
      main.innerHTML = renderFactory();
      break;
    case "reports":
      setPageTitle("Reports");
      main.innerHTML = renderReports();
      break;
    case "settings":
      setPageTitle("Settings");
      main.innerHTML = renderSettings();
      bindSettingsEvents();
      break;
    default:
      main.innerHTML = `<div class="empty-state"><div class="icon">🚧</div><p>Coming soon</p></div>`;
  }
}

// ==============================
// DASHBOARD
// ==============================
function renderDashboard() {
  const cards = state.data.overviewCards
    .filter(c => c.visible)
    .sort((a, b) => a.order - b.order);

  let overviewHtml = cards.map(card => {
    let value = getCardValue(card);
    return `
      <div class="overview-card" style="--card-color: ${card.color}" onclick="handleOverviewClick('${card.id}')">
        <div class="overview-icon">${card.icon}</div>
        <div class="overview-label">${card.label}</div>
        <div class="overview-value">${value}</div>
      </div>
    `;
  }).join("");

  if (!overviewHtml) {
    overviewHtml = `<div class="empty-state" style="grid-column:1/-1"><p>No overview cards. Add from Settings.</p></div>`;
  }

  const modules = state.data.modules
    .filter(m => m.visible && !["home", "settings"].includes(m.id))
    .sort((a, b) => a.order - b.order);

  const perRow = state.data.settings.modulesPerRow || 3;

  let modulesHtml = modules.map(m => `
    <div class="module-item" onclick="navigateTo('${m.id}')">
      <span class="module-icon">${m.icon}</span>
      <span class="module-name">${m.name}</span>
    </div>
  `).join("");

  const activities = state.data.recentActivities.slice(0, 5);

  return `
    <div class="section-title">Quick Overview</div>
    <div class="overview-grid">
      ${overviewHtml}
    </div>

    <div class="section-title">Modules</div>
    <div class="module-grid" style="grid-template-columns: repeat(${perRow}, 1fr)">
      ${modulesHtml}
    </div>

    <div class="section-title">Recent Activities</div>
    <div class="card">
      ${activities.length ? activities.map(a => `
        <div class="list-item">
          <div class="list-item-left">
            <div class="list-icon" style="--item-color: var(--primary)">${a.icon}</div>
            <div class="list-info">
              <h4>${a.text}</h4>
              <p>${a.time}</p>
            </div>
          </div>
        </div>
      `).join("") : `<div class="empty-state"><p>No recent activity</p></div>`}
    </div>

    <div class="section-title">Quick Actions</div>
    <div class="card" style="display:flex; gap:10px; flex-wrap:wrap;">
      <button class="btn btn-outline btn-sm" onclick="navigateTo('personal')">👤 Personal</button>
      <button class="btn btn-outline btn-sm" onclick="navigateTo('factory')">🏭 Factory</button>
      <button class="btn btn-outline btn-sm" onclick="navigateTo('settings')">⚙️ Settings</button>
      <button class="btn btn-outline btn-sm" onclick="exportBackup()">💾 Backup</button>
    </div>
  `;
}

function getCardValue(card) {
  const p = state.data.personal;
  const f = state.data.factory;
  switch (card.valueKey) {
    case "loanAmount": return formatCurrency(p.loanAmount);
    case "committeeAmount": return formatCurrency(p.committeeAmount);
    case "leaveBalance": return p.leaveBalance + " days";
    case "factoryStock": return formatNumber(f.stock) + " units";
    default: return "—";
  }
}

function handleOverviewClick(id) {
  const card = state.data.overviewCards.find(c => c.id === id);
  if (card && card.module) {
    navigateTo(card.module);
  }
}

function navigateTo(page) {
  if (["dashboard", "personal", "factory", "reports", "settings"].includes(page)) {
    setActiveNav(page === "dashboard" ? "dashboard" : page);
    // Map home to dashboard for nav
    if (page === "home") page = "dashboard";
    renderPage(page);
  } else {
    showToast("Module: " + page);
  }
}

// ==============================
// PERSONAL
// ==============================
function renderPersonal() {
  const p = state.data.personal;

  return `
    <div class="overview-grid">
      <div class="overview-card" style="--card-color: #ef4444">
        <div class="overview-icon">💰</div>
        <div class="overview-label">Total Loan</div>
        <div class="overview-value">${formatCurrency(p.loanAmount)}</div>
      </div>
      <div class="overview-card" style="--card-color: #f59e0b">
        <div class="overview-icon">🤝</div>
        <div class="overview-label">Committee</div>
        <div class="overview-value">${formatCurrency(p.committeeAmount)}</div>
      </div>
      <div class="overview-card" style="--card-color: #10b981">
        <div class="overview-icon">📅</div>
        <div class="overview-label">Leave Balance</div>
        <div class="overview-value">${p.leaveBalance} days</div>
      </div>
    </div>

    <div class="section-title flex-between">
      <span>Loans</span>
      <button class="btn btn-primary btn-sm" onclick="openAddLoan()">+ Add</button>
    </div>
    <div class="card">
      ${p.loans.length ? p.loans.map(l => `
        <div class="list-item">
          <div class="list-item-left">
            <div class="list-icon" style="--item-color: #ef4444">💰</div>
            <div class="list-info">
              <h4>${l.title}</h4>
              <p>${l.date}${l.notes ? " · " + l.notes : ""}</p>
            </div>
          </div>
          <div class="list-value" style="color:#ef4444">${formatCurrency(l.amount)}</div>
        </div>
      `).join("") : `<div class="empty-state"><p>No loans recorded</p></div>`}
    </div>

    <div class="section-title flex-between">
      <span>Committees</span>
      <button class="btn btn-primary btn-sm" onclick="openAddCommittee()">+ Add</button>
    </div>
    <div class="card">
      ${p.committees.length ? p.committees.map(c => `
        <div class="list-item">
          <div class="list-item-left">
            <div class="list-icon" style="--item-color: #f59e0b">🤝</div>
            <div class="list-info">
              <h4>${c.title}</h4>
              <p>${c.date}${c.notes ? " · " + c.notes : ""}</p>
            </div>
          </div>
          <div class="list-value" style="color:#f59e0b">${formatCurrency(c.amount)}</div>
        </div>
      `).join("") : `<div class="empty-state"><p>No committees</p></div>`}
    </div>

    <div class="section-title">Leave Summary</div>
    <div class="card">
      ${p.leaves.map(lv => {
        const remaining = lv.days - lv.used;
        return `
          <div class="list-item">
            <div class="list-item-left">
              <div class="list-icon" style="--item-color: #10b981">📅</div>
              <div class="list-info">
                <h4>${lv.type} Leave</h4>
                <p>Used ${lv.used} of ${lv.days} days</p>
              </div>
            </div>
            <div class="list-value">${remaining} left</div>
          </div>
        `;
      }).join("")}
    </div>
  `;
}

function openAddLoan() {
  openModal("Add Loan", `
    <div class="form-group">
      <label>Title</label>
      <input class="form-control" id="loanTitle" placeholder="e.g. Bank Loan" />
    </div>
    <div class="form-group">
      <label>Amount (Rs)</label>
      <input class="form-control" id="loanAmount" type="number" placeholder="0" />
    </div>
    <div class="form-group">
      <label>Date</label>
      <input class="form-control" id="loanDate" type="date" value="${new Date().toISOString().slice(0,10)}" />
    </div>
    <div class="form-group">
      <label>Notes (optional)</label>
      <input class="form-control" id="loanNotes" placeholder="Any notes..." />
    </div>
  `, `
    <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="saveLoan()">Save</button>
  `);
}

function saveLoan() {
  const title = document.getElementById("loanTitle").value.trim();
  const amount = Number(document.getElementById("loanAmount").value) || 0;
  const date = document.getElementById("loanDate").value;
  const notes = document.getElementById("loanNotes").value.trim();

  if (!title || amount <= 0) {
    showToast("Please enter title and valid amount");
    return;
  }

  state.data.personal.loans.unshift({
    id: generateId("loan"),
    title, amount, date, notes
  });
  recalculatePersonalTotals();
  saveData(state.data);
  closeModal();
  renderPage("personal");
  showToast("Loan added");
}

function openAddCommittee() {
  openModal("Add Committee", `
    <div class="form-group">
      <label>Title</label>
      <input class="form-control" id="comTitle" placeholder="e.g. Office Committee" />
    </div>
    <div class="form-group">
      <label>Amount (Rs)</label>
      <input class="form-control" id="comAmount" type="number" placeholder="0" />
    </div>
    <div class="form-group">
      <label>Date</label>
      <input class="form-control" id="comDate" type="date" value="${new Date().toISOString().slice(0,10)}" />
    </div>
    <div class="form-group">
      <label>Notes (optional)</label>
      <input class="form-control" id="comNotes" placeholder="Any notes..." />
    </div>
  `, `
    <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="saveCommittee()">Save</button>
  `);
}

function saveCommittee() {
  const title = document.getElementById("comTitle").value.trim();
  const amount = Number(document.getElementById("comAmount").value) || 0;
  const date = document.getElementById("comDate").value;
  const notes = document.getElementById("comNotes").value.trim();

  if (!title || amount <= 0) {
    showToast("Please enter title and valid amount");
    return;
  }

  state.data.personal.committees.unshift({
    id: generateId("com"),
    title, amount, date, notes
  });
  recalculatePersonalTotals();
  saveData(state.data);
  closeModal();
  renderPage("personal");
  showToast("Committee added");
}

function recalculatePersonalTotals() {
  state.data.personal.loanAmount = state.data.personal.loans.reduce((s, l) => s + (l.amount || 0), 0);
  state.data.personal.committeeAmount = state.data.personal.committees.reduce((s, c) => s + (c.amount || 0), 0);
  const totalLeave = state.data.personal.leaves.reduce((s, lv) => s + (lv.days - lv.used), 0);
  state.data.personal.leaveBalance = totalLeave;
}

// ==============================
// FACTORY
// ==============================
function renderFactory() {
  const f = state.data.factory;

  return `
    <div class="overview-grid">
      <div class="overview-card" style="--card-color: #0891b2">
        <div class="overview-icon">📦</div>
        <div class="overview-label">Total Stock</div>
        <div class="overview-value">${formatNumber(f.stock)}</div>
      </div>
      <div class="overview-card" style="--card-color: #4f46e5">
        <div class="overview-icon">📋</div>
        <div class="overview-label">Items</div>
        <div class="overview-value">${f.items.length}</div>
      </div>
    </div>

    <div class="section-title flex-between">
      <span>Stock Items</span>
      <button class="btn btn-primary btn-sm" onclick="openAddFactoryItem()">+ Add Item</button>
    </div>
    <div class="card">
      ${f.items.length ? f.items.map(item => `
        <div class="list-item">
          <div class="list-item-left">
            <div class="list-icon" style="--item-color: #0891b2">📦</div>
            <div class="list-info">
              <h4>${item.name}</h4>
              <p>${item.unit || "pcs"}</p>
            </div>
          </div>
          <div class="list-value">${formatNumber(item.qty)}</div>
        </div>
      `).join("") : `<div class="empty-state"><p>No items yet</p></div>`}
    </div>
  `;
}

function openAddFactoryItem() {
  openModal("Add Factory Item", `
    <div class="form-group">
      <label>Item Name</label>
      <input class="form-control" id="itemName" placeholder="e.g. Raw Material" />
    </div>
    <div class="form-group">
      <label>Quantity</label>
      <input class="form-control" id="itemQty" type="number" placeholder="0" />
    </div>
    <div class="form-group">
      <label>Unit</label>
      <input class="form-control" id="itemUnit" placeholder="kg / pcs / boxes" value="pcs" />
    </div>
  `, `
    <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="saveFactoryItem()">Save</button>
  `);
}

function saveFactoryItem() {
  const name = document.getElementById("itemName").value.trim();
  const qty = Number(document.getElementById("itemQty").value) || 0;
  const unit = document.getElementById("itemUnit").value.trim() || "pcs";

  if (!name) {
    showToast("Please enter item name");
    return;
  }

  state.data.factory.items.unshift({
    id: generateId("f"),
    name, qty, unit
  });
  state.data.factory.stock = state.data.factory.items.reduce((s, i) => s + (i.qty || 0), 0);
  saveData(state.data);
  closeModal();
  renderPage("factory");
  showToast("Item added");
}

// ==============================
// REPORTS
// ==============================
function renderReports() {
  const p = state.data.personal;
  const f = state.data.factory;

  return `
    <div class="card">
      <div class="card-title">📊 Summary Report</div>
      <div class="list-item">
        <div class="list-info"><h4>Total Loan Payable</h4></div>
        <div class="list-value" style="color:#ef4444">${formatCurrency(p.loanAmount)}</div>
      </div>
      <div class="list-item">
        <div class="list-info"><h4>Total Committee</h4></div>
        <div class="list-value" style="color:#f59e0b">${formatCurrency(p.committeeAmount)}</div>
      </div>
      <div class="list-item">
        <div class="list-info"><h4>Leave Balance</h4></div>
        <div class="list-value">${p.leaveBalance} days</div>
      </div>
      <div class="list-item">
        <div class="list-info"><h4>Factory Stock</h4></div>
        <div class="list-value">${formatNumber(f.stock)} units</div>
      </div>
    </div>

    <div class="section-title">Quick Insights</div>
    <div class="card">
      <p class="text-sm text-muted mb-12">This is a simple summary view. Full charts & export features can be added later.</p>
      <button class="btn btn-outline btn-block" onclick="exportBackup()">📥 Download Backup JSON</button>
    </div>
  `;
}

// ==============================
// SETTINGS
// ==============================
function renderSettings() {
  const tab = state.settingsTab;

  return `
    <div class="settings-tabs">
      <button class="settings-tab ${tab === 'overview' ? 'active' : ''}" data-tab="overview">Quick Overview</button>
      <button class="settings-tab ${tab === 'modules' ? 'active' : ''}" data-tab="modules">Modules</button>
      <button class="settings-tab ${tab === 'general' ? 'active' : ''}" data-tab="general">General</button>
      <button class="settings-tab ${tab === 'data' ? 'active' : ''}" data-tab="data">Data</button>
    </div>

    <div id="settingsContent">
      ${tab === 'overview' ? renderOverviewSettings() : ''}
      ${tab === 'modules' ? renderModulesSettings() : ''}
      ${tab === 'general' ? renderGeneralSettings() : ''}
      ${tab === 'data' ? renderDataSettings() : ''}
    </div>
  `;
}

function bindSettingsEvents() {
  document.querySelectorAll(".settings-tab").forEach(btn => {
    btn.addEventListener("click", () => {
      state.settingsTab = btn.dataset.tab;
      renderPage("settings");
    });
  });
}

function renderOverviewSettings() {
  const cards = state.data.overviewCards.sort((a, b) => a.order - b.order);

  return `
    <div class="section-title flex-between">
      <span>Overview Cards</span>
      <button class="btn btn-primary btn-sm" onclick="openAddOverviewCard()">+ Add Card</button>
    </div>
    <div class="card">
      ${cards.map(c => `
        <div class="settings-item">
          <div class="list-item-left">
            <div class="list-icon" style="--item-color: ${c.color}">${c.icon}</div>
            <div class="list-info">
              <h4>${c.label}</h4>
              <p>${c.module} · order ${c.order}</p>
            </div>
          </div>
          <div class="flex gap-8">
            <div class="toggle ${c.visible ? 'active' : ''}" onclick="toggleOverviewCard('${c.id}')"></div>
            <button class="btn btn-outline btn-sm" onclick="editOverviewCard('${c.id}')">Edit</button>
          </div>
        </div>
      `).join("")}
    </div>
    <p class="text-sm text-muted mt-12">Toggle visibility or edit cards. Changes appear instantly on Dashboard.</p>
  `;
}

function renderModulesSettings() {
  const modules = state.data.modules.sort((a, b) => a.order - b.order);

  return `
    <div class="section-title">Visible Modules</div>
    <div class="card">
      ${modules.map(m => `
        <div class="settings-item">
          <div class="list-item-left">
            <div class="list-icon" style="--item-color: ${m.color}">${m.icon}</div>
            <div class="list-info">
              <h4>${m.name}</h4>
              <p>Order: ${m.order}</p>
            </div>
          </div>
          <div class="toggle ${m.visible ? 'active' : ''}" onclick="toggleModule('${m.id}')"></div>
        </div>
      `).join("")}
    </div>

    <div class="section-title">Modules Per Row (Mobile)</div>
    <div class="card">
      <div class="settings-item">
        <div class="list-info"><h4>Grid Columns</h4><p>How many modules in one row</p></div>
        <select class="form-control" style="width:80px" id="modulesPerRow" onchange="updateModulesPerRow(this.value)">
          <option value="2" ${state.data.settings.modulesPerRow == 2 ? 'selected' : ''}>2</option>
          <option value="3" ${state.data.settings.modulesPerRow == 3 ? 'selected' : ''}>3</option>
          <option value="4" ${state.data.settings.modulesPerRow == 4 ? 'selected' : ''}>4</option>
        </select>
      </div>
    </div>
  `;
}

function renderGeneralSettings() {
  return `
    <div class="card">
      <div class="settings-item">
        <div class="list-info"><h4>Theme</h4><p>Light / Dark mode</p></div>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('themeToggle').click()">Toggle</button>
      </div>
      <div class="settings-item">
        <div class="list-info"><h4>App Name</h4></div>
        <input class="form-control" style="width:160px" value="${state.data.settings.appName}" 
               onchange="updateAppName(this.value)" />
      </div>
    </div>
    <div class="section-title">About</div>
    <div class="card">
      <p class="text-sm text-muted">
        <strong>Saif Ullah – Personal & Professional Manager</strong><br>
        Version 1.0 · Fully offline · Data stored in your browser<br><br>
        Built as a complete working starter. You can expand modules and cards from Settings.
      </p>
    </div>
  `;
}

function renderDataSettings() {
  return `
    <div class="card">
      <button class="btn btn-primary btn-block mb-12" onclick="exportBackup()">📥 Download Backup (JSON)</button>
      <button class="btn btn-outline btn-block mb-12" onclick="document.getElementById('importFile').click()">📤 Import Backup</button>
      <input type="file" id="importFile" accept=".json" class="hidden" onchange="importBackup(event)" />
      <button class="btn btn-danger btn-block" onclick="confirmReset()">🗑️ Reset All Data</button>
    </div>
    <p class="text-sm text-muted mt-12">
      Backup downloads a JSON file of all your data. Keep it safe. Import will overwrite current data.
    </p>
  `;
}

// ---------- Settings actions ----------
function toggleOverviewCard(id) {
  const card = state.data.overviewCards.find(c => c.id === id);
  if (card) {
    card.visible = !card.visible;
    saveData(state.data);
    renderPage("settings");
    showToast(card.visible ? "Card shown" : "Card hidden");
  }
}

function toggleModule(id) {
  const mod = state.data.modules.find(m => m.id === id);
  if (mod) {
    mod.visible = !mod.visible;
    saveData(state.data);
    renderPage("settings");
    showToast(mod.visible ? "Module shown" : "Module hidden");
  }
}

function updateModulesPerRow(val) {
  state.data.settings.modulesPerRow = Number(val);
  saveData(state.data);
  showToast("Modules per row updated");
}

function updateAppName(val) {
  state.data.settings.appName = val || "Saif Ullah Manager";
  saveData(state.data);
  showToast("App name updated");
}

function openAddOverviewCard() {
  openModal("Add Overview Card", `
    <div class="form-group">
      <label>Label</label>
      <input class="form-control" id="cardLabel" placeholder="e.g. Loan Payable" />
    </div>
    <div class="form-group">
      <label>Icon (emoji)</label>
      <input class="form-control" id="cardIcon" placeholder="💰" value="📌" />
    </div>
    <div class="form-group">
      <label>Color</label>
      <div class="color-options" id="colorOptions">
        ${["#4f46e5","#ef4444","#f59e0b","#10b981","#0891b2","#7c3aed","#d97706","#64748b"].map(c => 
          `<div class="color-dot" style="background:${c}" data-color="${c}" onclick="selectColor(this)"></div>`
        ).join("")}
      </div>
      <input type="hidden" id="cardColor" value="#4f46e5" />
    </div>
    <div class="form-group">
      <label>Linked Module</label>
      <select class="form-control" id="cardModule">
        <option value="personal">Personal</option>
        <option value="factory">Factory</option>
        <option value="reports">Reports</option>
      </select>
    </div>
  `, `
    <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="saveNewOverviewCard()">Add Card</button>
  `);
}

function selectColor(el) {
  document.querySelectorAll(".color-dot").forEach(d => d.classList.remove("selected"));
  el.classList.add("selected");
  document.getElementById("cardColor").value = el.dataset.color;
}

function saveNewOverviewCard() {
  const label = document.getElementById("cardLabel").value.trim();
  const icon = document.getElementById("cardIcon").value.trim() || "📌";
  const color = document.getElementById("cardColor").value;
  const module = document.getElementById("cardModule").value;

  if (!label) {
    showToast("Please enter a label");
    return;
  }

  const maxOrder = Math.max(0, ...state.data.overviewCards.map(c => c.order));
  state.data.overviewCards.push({
    id: generateId("ov"),
    label, icon, color, module,
    submodule: "",
    valueKey: "custom",
    visible: true,
    order: maxOrder + 1
  });
  saveData(state.data);
  closeModal();
  renderPage("settings");
  showToast("Card added");
}

function editOverviewCard(id) {
  const card = state.data.overviewCards.find(c => c.id === id);
  if (!card) return;

  openModal("Edit Card", `
    <div class="form-group">
      <label>Label</label>
      <input class="form-control" id="editLabel" value="${card.label}" />
    </div>
    <div class="form-group">
      <label>Icon</label>
      <input class="form-control" id="editIcon" value="${card.icon}" />
    </div>
    <div class="form-group">
      <label>Order</label>
      <input class="form-control" id="editOrder" type="number" value="${card.order}" />
    </div>
  `, `
    <button class="btn btn-danger" onclick="deleteOverviewCard('${id}')">Delete</button>
    <button class="btn btn-primary" onclick="saveEditOverviewCard('${id}')">Save</button>
  `);
}

function saveEditOverviewCard(id) {
  const card = state.data.overviewCards.find(c => c.id === id);
  if (!card) return;
  card.label = document.getElementById("editLabel").value.trim() || card.label;
  card.icon = document.getElementById("editIcon").value.trim() || card.icon;
  card.order = Number(document.getElementById("editOrder").value) || card.order;
  saveData(state.data);
  closeModal();
  renderPage("settings");
  showToast("Card updated");
}

function deleteOverviewCard(id) {
  state.data.overviewCards = state.data.overviewCards.filter(c => c.id !== id);
  saveData(state.data);
  closeModal();
  renderPage("settings");
  showToast("Card deleted");
}

// ---------- Backup / Restore ----------
function exportBackup() {
  const dataStr = JSON.stringify(state.data, null, 2);
  const blob = new Blob([dataStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `saif-ullah-backup-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Backup downloaded");
}

function importBackup(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      state.data = imported;
      saveData(state.data);
      applyTheme(state.data.settings.theme || "light");
      renderPage("settings");
      showToast("Backup imported successfully");
    } catch (err) {
      showToast("Invalid backup file");
    }
  };
  reader.readAsText(file);
  event.target.value = "";
}

function confirmReset() {
  openModal("Reset All Data?", `
    <p>This will delete all your data and restore the default sample data. This cannot be undone.</p>
  `, `
    <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
    <button class="btn btn-danger" onclick="resetAllData()">Yes, Reset</button>
  `);
}

function resetAllData() {
  localStorage.removeItem(window.AppData.STORAGE_KEY);
  state.data = loadData();
  applyTheme("light");
  closeModal();
  renderPage("settings");
  showToast("Data reset to defaults");
}

// Make functions available globally for onclick handlers
window.navigateTo = navigateTo;
window.handleOverviewClick = handleOverviewClick;
window.openAddLoan = openAddLoan;
window.saveLoan = saveLoan;
window.openAddCommittee = openAddCommittee;
window.saveCommittee = saveCommittee;
window.openAddFactoryItem = openAddFactoryItem;
window.saveFactoryItem = saveFactoryItem;
window.exportBackup = exportBackup;
window.importBackup = importBackup;
window.confirmReset = confirmReset;
window.resetAllData = resetAllData;
window.toggleOverviewCard = toggleOverviewCard;
window.toggleModule = toggleModule;
window.updateModulesPerRow = updateModulesPerRow;
window.updateAppName = updateAppName;
window.openAddOverviewCard = openAddOverviewCard;
window.selectColor = selectColor;
window.saveNewOverviewCard = saveNewOverviewCard;
window.editOverviewCard = editOverviewCard;
window.saveEditOverviewCard = saveEditOverviewCard;
window.deleteOverviewCard = deleteOverviewCard;
window.closeModal = closeModal;
