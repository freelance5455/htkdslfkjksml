# Saif Ullah – Personal & Professional Manager

Complete offline-capable mobile-first web app.

## How to use

1. Extract this ZIP
2. Open `index.html` in any modern browser (Chrome / Safari / Edge recommended)
3. For best experience on phone: Add to Home Screen

## Features included

- **Dashboard** with dynamic Quick Overview cards
- **Personal** module: Loans, Committees, Leave Balance
- **Factory** module: Stock items
- **Reports** summary
- **Settings**:
  - Toggle / edit / add Overview cards
  - Show / hide modules
  - Modules per row (2 / 3 / 4)
  - Theme (Light / Dark)
  - Backup & Restore (JSON)
  - Reset data
- Fully offline – all data saved in browser localStorage
- Mobile responsive design
- Clean modern UI

## Default sample data

- Loan Payable: Rs 75,000
- Committee: Rs 15,000
- Leave Balance: 25 days
- Some sample factory items

You can change everything from Settings.

## Notes

- This is a complete working starter version.
- You can expand more modules later (the structure is ready).
- Data never leaves your device.

Built for Saif Ullah.
