const fs=require('fs');
const p='/mnt/data/edit15/index.html';
let s=fs.readFileSync(p,'utf8');
const patch=`
<style id="v15-final-layout">
*,*::before,*::after{box-sizing:border-box}
html,body{width:100%;min-height:100%;margin:0;overflow-x:hidden}
img,video{max-width:100%}
button,input,textarea,select{font:inherit}
.screen{width:100%;max-width:100%;overflow-x:hidden}
.card,.list-item,.dream-card,.film-item{max-width:100%;overflow:hidden}
.gallery{display:flex!important;flex-direction:column!important;gap:14px!important;width:100%!important;margin:10px 0 0!important}
.gallery .gi{width:100%!important;height:auto!important;aspect-ratio:auto!important;overflow:hidden!important;border-radius:18px!important;position:relative!important;background:rgba(255,255,255,.16)}
.gallery .gi>img{display:block!important;width:100%!important;height:auto!important;max-height:none!important;object-fit:contain!important;background:rgba(0,0,0,.06)}
.gallery .cap{position:static!important;background:transparent!important;color:inherit!important;padding:7px 8px 2px!important;white-space:normal!important;overflow:visible!important;text-overflow:clip!important;font-size:11px!important}
.gallery .gallery-actions{position:absolute!important;right:8px!important;top:8px!important;display:flex!important;gap:6px!important;z-index:20!important}
.gallery .gallery-actions button,.gallery .gal-del,.gallery .gal-del-rated,.gallery .gal-comment{width:36px!important;height:36px!important;padding:0!important;border:1px solid rgba(255,255,255,.48)!important;border-radius:50%!important;background:rgba(255,255,255,.20)!important;color:#fff!important;backdrop-filter:blur(14px) saturate(160%)!important;-webkit-backdrop-filter:blur(14px) saturate(160%)!important;box-shadow:0 5px 18px rgba(0,0,0,.20),inset 0 1px 1px rgba(255,255,255,.45)!important;font-size:16px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important}
.gallery-rating{padding:8px 10px 10px!important;display:flex!important;flex-direction:column!important;gap:5px!important;background:rgba(255,255,255,.10)!important;border-top:1px solid rgba(255,255,255,.16)!important}
.gallery-rating-row{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;font-size:12px!important}
.gallery-rating-stars{display:flex!important;gap:2px!important}
.gallery-rating-stars button{border:0!important;background:transparent!important;padding:1px!important;font-size:19px!important;line-height:1!important;opacity:.38!important;cursor:pointer!important}
.gallery-rating-stars button.on{opacity:1!important;filter:drop-shadow(0 2px 4px rgba(0,0,0,.18))}
.gallery-comment-hint{font-size:10px!important;opacity:.65!important;text-align:center!important;margin-top:1px!important}
#lightbox{padding:10px!important;touch-action:none!important}
#lightbox #lb-img{max-width:100%!important;max-height:78vh!important;object-fit:contain!important;transform-origin:center!important;touch-action:none!important;user-select:none!important;-webkit-user-drag:none!important}
#lightbox .lb-cap{max-height:18vh!important;overflow:auto!important}
#lightbox .lb-tools{position:relative!important;z-index:30!important}
#note-gallery-preview img,#dream-photo-prev img{display:block!important;width:auto!important;max-width:100%!important;max-height:220px!important;object-fit:contain!important;border-radius:14px!important}
</style>
<script id="v15-final-fixes">
(function(){
'use strict';
const Q=id=>document.getElementById(id);
const has=()=>typeof db!=='undefined'&&db&&typeof S!=='undefined'&&S.role;
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function buzz(pattern=[55,35,85]){try{if(navigator.vibrate)navigator.vibrate(pattern)}catch(e){}}

/* Fix the real gallery UI: vertical photos, clickable ratings, comments only in lightbox. */
function renderPhotoList(path,rootId,emptyId){
 if(!has())return; const root=Q(rootId),empty=Q(emptyId); if(!root)return;
 const ref=R(path); try{ref.off()}catch(e){}
 ref.on('value',snap=>{
  const d=snap.val()||{}; const arr=Object.keys(d).map(id=>({id,...(d[id]||{})})).filter(x=>x.data).sort((a,b)=>(b.ts||0)-(a.ts||0));
  if(empty)empty.style.display=arr.length?'none':'block';
  root.innerHTML=arr.map(p=>{
   const he=(p.reviews&&p.reviews.he)||{}, sh=(p.reviews&&p.reviews.she)||{};
   const row=(role,r)=>{
    const mine=S.role===role, n=Math.max(0,Math.min(5,Number(r.rating)||0));
    const label=role==='he'?'🐱 Котусик':'🌸 Квіточка';
    return '<div class="gallery-rating-row"><b>'+label+'</b><div class="gallery-rating-stars">'+[1,2,3,4,5].map(i=>'<button type="button" class="gal-star '+(i<=n?'on':'')+'" data-path="'+esc(path)+'" data-id="'+esc(p.id)+'" data-role="'+role+'" data-n="'+i+'" aria-label="'+i+'">'+(i<=n?'★':'☆')+'</button>').join('')+'</div></div>';
   };
   return '<div class="gi" data-id="'+esc(p.id)+'" data-src="'+esc(p.data)+'" data-cap="'+esc(p.caption||'')+'">'+
    '<img src="'+esc(p.data)+'" alt="Фото" loading="lazy">'+
    '<div class="cap">'+esc(p.caption||'')+'</div>'+ 
    '<div class="gallery-actions"><button type="button" class="gal-del" data-path="'+esc(path)+'" data-id="'+esc(p.id)+'" title="Видалити">🗑</button></div>'+ 
    '<div class="gallery-rating">'+row('she',sh)+row('he',he)+'<div class="gallery-comment-hint">Натисніть на фото, щоб переглянути або додати коментарі</div></div>'+
    '</div>';
  }).join('');
  root.querySelectorAll('.gal-star').forEach(b=>b.onclick=async e=>{
   e.stopPropagation(); buzz([35]); if(b.dataset.role!==S.role)return;
   const n=Number(b.dataset.n); try{await R(b.dataset.path+'/'+b.dataset.id+'/reviews/'+S.role+'/rating').set(n); toast('Оцінку збережено ⭐')}catch(err){toast('Не вдалося зберегти оцінку')}
  });
  root.querySelectorAll('.gal-del').forEach(b=>b.onclick=async e=>{e.stopPropagation();buzz([45]);if(!confirm('Видалити це фото?'))return;try{await R(b.dataset.path+'/'+b.dataset.id).remove();toast('Фото видалено')}catch(err){toast('Не вдалося видалити фото')}});
  root.querySelectorAll('.gi').forEach(card=>card.onclick=e=>{if(e.target.closest('.gal-star,.gal-del,.gallery-actions'))return;openLightbox(card.dataset.src,card.dataset.cap,card.dataset.id,path)});
 });
}
if(has()){renderPhotoList('gallery','photo-gallery','gal-empty');renderPhotoList('galleryArt','art-gallery','art-empty')}

/* Fullscreen lightbox with pinch zoom and per-user comments. */
let lbPath='gallery',lbData={},pinchStart=0,lbBase=1;
function openLB(src,cap,id,path){lbPath=path||'gallery';lbData={id:id||null};S.lbZoom=1;Q('lb-img').src=src;Q('lb-img').style.transform='scale(1)';Q('lb-cap').innerHTML=esc(cap||'');Q('lightbox').classList.add('on');loadLBReview();}
window.openLightbox=openLB;
async function loadLBReview(){
 const box=Q('lb-cap'); if(!box||!lbData.id||!has())return;
 try{const snap=await R(lbPath+'/'+lbData.id+'/reviews').once('value');const d=snap.val()||{};const h=d.he||{},s=d.she||{};
  const one=(role,r)=>'<div style="margin-top:7px"><b>'+(role==='he'?'🐱 Котусик':'🌸 Квіточка')+'</b> · '+(r.rating?'⭐'.repeat(Number(r.rating))+' '+r.rating+'/5':'оцінки немає')+'<div style="margin-top:2px">'+(r.comment?esc(r.comment):'<span style="opacity:.65">Коментар ще не доданий</span>')+'</div>'+(S.role===role?'<button type="button" id="lb-edit-'+role+'" style="margin-top:5px">💬 Мій коментар</button>':'')+'</div>';
  box.innerHTML='<div>'+one('she',s)+one('he',h)+'</div>';
  ['he','she'].forEach(role=>{const b=Q('lb-edit-'+role);if(b)b.onclick=async e=>{e.stopPropagation();if(S.role!==role)return;const old=(d[role]||{}).comment||'';const c=prompt('Коментар до фото:',old);if(c===null)return;await R(lbPath+'/'+lbData.id+'/reviews/'+role+'/comment').set(c.trim());buzz([40]);toast('Коментар збережено ❤️');loadLBReview()}});
 }catch(e){}
}
/* Replace old comment button with current user's comment editor. */
if(Q('lb-comment'))Q('lb-comment').onclick=e=>{e.stopPropagation();loadLBReview()};
let touchDist=0;
const img=Q('lb-img');
if(img){img.addEventListener('touchstart',e=>{if(e.touches.length===2)touchDist=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY)},{passive:true});img.addEventListener('touchmove',e=>{if(e.touches.length!==2)return;const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);if(touchDist){S.lbZoom=Math.max(.5,Math.min(4,S.lbZoom*(d/touchDist)));img.style.transform='scale('+S.lbZoom+')';touchDist=d;}},{passive:true});img.addEventListener('dblclick',()=>{S.lbZoom=S.lbZoom>1?1:2;img.style.transform='scale('+S.lbZoom+')';buzz([30])});}

/* Reliable gallery picker for Notes and Dreams. */
async function pickFromAppGallery(){
 if(!has()){toast('Firebase недоступний');return null}
 const items=[];
 for(const path of ['gallery','galleryArt']){const s=await R(path).once('value');const d=s.val()||{};Object.keys(d).forEach(id=>{if(d[id]&&d[id].data)items.push({data:d[id].data,path,id})})}
 if(!items.length){toast('У галереї немає фото');return null}
 return await new Promise(resolve=>{
  let ov=Q('v15-gallery-picker');
  if(!ov){ov=document.createElement('div');ov.id='v15-gallery-picker';ov.style='position:fixed;inset:0;z-index:30000;background:rgba(0,0,0,.78);padding:16px;overflow:auto';document.body.appendChild(ov)}
  ov.innerHTML='<div style="max-width:560px;margin:30px auto;background:rgba(255,255,255,.97);border-radius:22px;padding:14px;color:#111"><div style="display:flex;justify-content:space-between;align-items:center"><b>🖼 Оберіть фото</b><button id="v15-gp-close" type="button">✕</button></div><div id="v15-gp-grid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px"></div></div>';
  Q('v15-gp-grid').innerHTML=items.map((x,i)=>'<button type="button" data-i="'+i+'" style="border:0;background:none;padding:0"><img src="'+esc(x.data)+'" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:12px"></button>').join('');
  ov.style.display='block'; const close=()=>{ov.style.display='none'};Q('v15-gp-close').onclick=()=>{close();resolve(null)};Q('v15-gp-grid').querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{const x=items[Number(b.dataset.i)];close();resolve(x.data)});
 });
}
function ensurePickerButton(id,label,callback){const input=Q(id);if(!input)return;let host=input.parentElement?.parentElement||input.parentElement;if(!host)return;let b=Q('v15-'+id+'-gallery');if(!b){b=document.createElement('button');b.id='v15-'+id+'-gallery';b.type='button';b.className='btn btn-o gallery-source-btn';b.textContent='🖼 '+label+' з галереї';host.appendChild(b)}b.onclick=async e=>{e.preventDefault();e.stopPropagation();buzz([35]);const data=await pickFromAppGallery();if(data)callback(data)};}
function setupAttachments(){
 ensurePickerButton('dream-photo','Додати фото',data=>{window.dreamPhotoData=data;Q('dream-photo-prev').innerHTML='<img src="'+esc(data)+'" alt="Фото">'});
 /* Notes have no file input, so create a dedicated button next to the add button. */
 const add=Q('btn-add-note'); if(add){let b=Q('v15-note-gallery');if(!b){b=document.createElement('button');b.id='v15-note-gallery';b.type='button';b.className='btn btn-o';b.textContent='🖼 Фото з галереї';add.parentElement.appendChild(b)}b.onclick=async()=>{buzz([35]);const data=await pickFromAppGallery();if(!data)return;window.noteGalleryPhoto=data;let p=Q('note-gallery-preview');if(!p){p=document.createElement('div');p.id='note-gallery-preview';p.style.marginTop='8px';add.parentElement.appendChild(p)}p.innerHTML='<img src="'+esc(data)+'" alt="Фото">'}}
 /* Override both save handlers so selected gallery image is definitely persisted. */
 if(add&&Q('note-input'))add.onclick=async e=>{e.preventDefault();e.stopPropagation();const text=Q('note-input').value.trim(),photo=window.noteGalleryPhoto||'';if(!text&&!photo){toast('Додайте текст або фото');return}try{await R('notes').push({text,photo,who:S.role,fromName:myName(),date:new Date().toLocaleString('uk-UA'),ts:Date.now()});Q('note-input').value='';window.noteGalleryPhoto='';Q('note-gallery-preview')?.remove();buzz([35]);toast('Нотатку збережено ❤️')}catch(err){toast('Не вдалося зберегти нотатку')}};
}
setTimeout(setupAttachments,250);setTimeout(setupAttachments,1200);setTimeout(setupAttachments,2500);

/* Vibration for notification controls and every in-app banner appearance. */
document.addEventListener('click',e=>{const el=e.target.closest&&e.target.closest('#btn-enable-notifications,[id^="notif-"],.notification-btn,[data-notification],#btn-near-home,#btn-heart');if(el)buzz([65,35,90])},true);
try{const oldBanner=window.showBanner;if(typeof oldBanner==='function'){window.showBanner=function(title,body){buzz([90,45,130]);return oldBanner.apply(this,arguments)}}}catch(e){}

/* Keep vertical application scrolling and independent chat scrolling. */
const style=document.createElement('style');style.textContent='body{touch-action:pan-y!important}.screen{touch-action:pan-y!important}.chat-area,.messages-container{touch-action:pan-y!important;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain!important;-webkit-overflow-scrolling:touch!important}';document.head.appendChild(style);
})();
</script>
`;
s=s.replace('</body>',patch+'\n</body>');
fs.writeFileSync(p,s);
