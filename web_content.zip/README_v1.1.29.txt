Monee v1.1.29 — Corrected Splash Typography
- In-app/Home fonts are restored to the v1.1.27 baseline (Mali).
- Only the startup Splash typography is changed to match the app font.
- Cute bouncing-dot loading remains.
- No finance/data logic changes.
