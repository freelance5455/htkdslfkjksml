@echo off
chcp 65001 >nul
setlocal
set "REELS_TARGET=C:\AndroidProjects\ReelsCardAndroid"
echo 릴스 편집기 v1.3.0 업데이트
echo 먼저 Android Studio에서 실행과 빌드를 중지하세요.
echo 기본 프로젝트: %REELS_TARGET%
set /p "REELS_CUSTOM=다른 경로라면 입력하세요. 기본 경로는 Enter: "
if defined REELS_CUSTOM set "REELS_TARGET=%REELS_CUSTOM%"
if not exist "%REELS_TARGET%\settings.gradle" (
 echo 프로젝트를 찾지 못했습니다. ReelsCardAndroid 폴더 경로를 확인하세요.
 pause
 exit /b 1
)
set "REELS_BACKUP=%REELS_TARGET%_backup_%RANDOM%"
mkdir "%REELS_BACKUP%"
if errorlevel 1 goto backup_failed
xcopy "%REELS_TARGET%\app\src\main\*" "%REELS_BACKUP%\app\src\main\" /E /I /H /Y >nul
if errorlevel 1 goto backup_failed
copy "%REELS_TARGET%\app\build.gradle" "%REELS_BACKUP%\app\build.gradle" >nul
if errorlevel 1 goto backup_failed
copy "%REELS_TARGET%\gradle.properties" "%REELS_BACKUP%\gradle.properties" >nul
if errorlevel 1 (
 echo 백업에 실패했습니다. 업데이트를 중단합니다.
 pause
 exit /b 1
)
xcopy "%~dp0ReelsCardAndroid\app\src\main\*" "%REELS_TARGET%\app\src\main\" /E /I /Y >nul
if errorlevel 1 goto copy_failed
copy /Y "%~dp0ReelsCardAndroid\app\build.gradle" "%REELS_TARGET%\app\build.gradle" >nul
if errorlevel 1 goto copy_failed
findstr /C:"android.useAndroidX=true" "%REELS_TARGET%\gradle.properties" >nul 2>&1
if errorlevel 1 echo android.useAndroidX=true>>"%REELS_TARGET%\gradle.properties"
echo 완료. 백업: %REELS_BACKUP%
echo Android Studio에서 Sync Project with Gradle Files 후 Run을 누르세요.
echo 앱 상단에 v1.3.0 · MP4 직접 변환 이 표시되어야 합니다.
pause
exit /b 0
:copy_failed
echo 복사 실패. 백업 위치: %REELS_BACKUP%
pause
exit /b 1

:backup_failed
echo 백업에 실패했습니다. 프로젝트 파일을 교체하지 않았습니다.
pause
exit /b 1
