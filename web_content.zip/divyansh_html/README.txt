Divyansh Jeneral Store - HTML APK Forge project

Files: index.html, style.css, script.js, manifest.json

How to use:
1. Upload this ZIP/project to APK Forge as an HTML/WebView project.
2. Enable location permission in APK Forge's wrapper/app permissions; GPS access requires a secure context (HTTPS) or WebView configured for geolocation.
3. Install and open the app. Shopkeeper panel is the gear icon (default PIN 1234).
4. While physically at the shop, open Shopkeeper panel -> save current location. This location is saved locally on that device.
5. Add/update products in Shopkeeper panel. Sample items are demo data and can be reset.
6. Customers add products to cart. Order is blocked if total is below ₹99 or if customer is more than 1 KM from saved shop GPS.
7. WhatsApp order recipient is 8000122796.

Important:
- This demo stores product catalog and shop GPS in localStorage on each device. Admin edits on one device do not sync to customer devices.
- For a customer device to have the same product list as the shopkeeper, a shared database/server would be needed. This HTML-only package does not have one.
- WhatsApp deep link launches WhatsApp with a pre-filled order; the customer still presses Send.
- Default shopkeeper PIN 1234 is not secure; change it before public use.
