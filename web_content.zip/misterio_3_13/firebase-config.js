
export const firebaseConfig = {
  apiKey: "AIzaSyA0ZJFz6BrFaPXbXr97h5HadN9bGad6CRA",
  authDomain: "misterio-313-c27a8.firebaseapp.com",
  databaseURL: "https://misterio-313-c27a8-default-rtdb.firebaseio.com/",
  projectId: "misterio-313-c27a8",
  appId: "1:529667149135:web:330f62e4041dfcb1c3093a"
};

export const isFirebaseConfigured =
  Boolean(firebaseConfig.apiKey) &&
  Boolean(firebaseConfig.projectId) &&
  Boolean(firebaseConfig.appId) &&
  firebaseConfig.databaseURL.startsWith("https://");

