import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import { getDatabase, ref, set, get, update, onValue, push, runTransaction } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-database.js";
import { firebaseConfig, isFirebaseConfigured } from "./firebase-config.js";

const $ = (id) => document.getElementById(id);
const SCENES = [
  {
    title: "La puerta respira",
    story: "Son las 3:13 a. m. La puerta del refugio se hincha y se encoge, como si la casa respirara. Del otro lado, alguien da tres golpecitos. Nadie debería estar allí.",
    clues: { p1: "La cerradura tiene arañazos recientes, pero están hechos desde dentro.", p2: "El timbre suena en el pasillo, aunque los cables están cortados." },
    choices: [
      { id: "A", title: "Abrir apenas la puerta", detail: "Quizá la persona necesita ayuda.", effect: "bravery" },
      { id: "B", title: "Apagar la linterna y guardar silencio", detail: "No dejarás que te encuentre tan fácilmente.", effect: "caution" },
      { id: "C", title: "Preguntar quién está ahí", detail: "Primero necesitas una respuesta.", effect: "teamwork" }
    ],
    outcomes: { AA: "Abren la puerta juntos. El pasillo está vacío, pero las marcas de la cerradura ahora están en el lado del refugio.", BB: "Apagan las luces. Los golpes paran… y se oyen tres desde el techo.", CC: "Preguntan al mismo tiempo. Una voz idéntica a la de ustedes responde: «Ya estoy dentro»." },
    fallback: "La puerta se abre un dedo. No hay nadie en el pasillo. En el suelo aparece una llave húmeda."
  },
  {
    title: "El pasillo infinito",
    story: "El pasillo parece mucho más largo que antes. Al final, un reloj marca las 3:13. Cada vez que parpadean, la puerta de salida está más lejos.",
    clues: { p1: "Hay huellas mojadas que van hacia la escalera, pero ninguna regresa.", p2: "El reloj no tiene agujas; la hora aparece escrita en el vidrio empañado." },
    choices: [
      { id: "A", title: "Seguir las huellas", detail: "Podrían llevar a una salida.", effect: "bravery" },
      { id: "B", title: "Examinar el reloj", detail: "La casa parece obedecer una regla.", effect: "caution" },
      { id: "C", title: "Avanzar juntos contando los pasos", detail: "Si el pasillo cambia, lo notarán.", effect: "teamwork" }
    ],
    outcomes: { AA: "Las huellas terminan delante de ustedes. Las últimas son idénticas a sus zapatos.", BB: "Al tocar el reloj, el vidrio se aclara. Hay dos nombres escritos por dentro: los suyos.", CC: "Cuentan cada paso juntos. Al llegar a trece, aparecen otra vez junto a la puerta." },
    fallback: "Una luz roja se enciende al fondo. Por un segundo, la sombra de ustedes camina en dirección contraria."
  },
  {
    title: "La voz del sótano",
    story: "La trampilla del sótano está abierta. Desde abajo escuchan una voz que pide ayuda usando las palabras exactas que ustedes acaban de decirse por chat.",
    clues: { p1: "La trampilla está cerrada con un candado por fuera: alguien no quiere que eso salga.", p2: "La voz repite todo con dos segundos de retraso, incluso cuando ninguno habla." },
    choices: [
      { id: "A", title: "Bajar y buscar el origen de la voz", detail: "Es la forma más directa de resolverlo.", effect: "bravery" },
      { id: "B", title: "Cerrar la trampilla y bloquearla", detail: "No arriesgarán todo por una voz extraña.", effect: "caution" },
      { id: "C", title: "Dejar una señal y salir juntos", detail: "No se separarán, pase lo que pase.", effect: "teamwork" }
    ],
    outcomes: { AA: "Bajan juntos. Al fondo encuentran un teléfono antiguo transmitiendo su conversación en directo.", BB: "Cierran la trampilla. Algo da tres golpes desde abajo; después, el silencio es absoluto.", CC: "Dejan la señal y corren hacia la salida. Por primera vez, la casa no cambia el pasillo." },
    fallback: "La voz susurra sus dos nombres al mismo tiempo. La luz del pasillo se apaga, pero la puerta de salida aparece."
  }
];

let app, auth, db, currentUser = null, currentRoomCode = null, currentSlot = null, unsubscribeRoom = null, lastRenderedRoom = null, toastTimer;
const lobby = $("lobby"), game = $("game"), setupNote = $("setup-note");

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2400);
}
function showError(message) { const el = $("error-box"); el.textContent = message; el.classList.remove("hidden"); }
function clearError() { $("error-box").classList.add("hidden"); $("error-box").textContent = ""; }
function showButtonBusy(button, busy, label) { button.disabled = busy; if (label) button.textContent = busy ? "Conectando…" : label; }
function cleanName() { return $("player-name").value.trim().replace(/[<>]/g, "").slice(0,18) || "Detective"; }
function randomCode() { const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let out = ""; for (let i=0;i<6;i++) out += alphabet[Math.floor(Math.random()*alphabet.length)]; return out; }
function roomPath(code) { return `rooms/${code}`; }
function statePath(code) { return `rooms/${code}/state`; }
function myChoice(state) { return state?.votes?.[currentSlot] ?? null; }
function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function safeText(node, text) { node.textContent = text ?? ""; }

async function ensureAuth() {
  if (!isFirebaseConfigured) throw new Error("Falta configurar Firebase. Sigue los pasos del archivo LEEME incluido en la descarga.");
  if (!app) { app = initializeApp(firebaseConfig); auth = getAuth(app); db = getDatabase(app); }
  if (auth.currentUser) { currentUser = auth.currentUser; return currentUser; }
  await signInAnonymously(auth);
  return await new Promise((resolve, reject) => {
    const stop = onAuthStateChanged(auth, user => { stop(); if (user) { currentUser = user; resolve(user); } else reject(new Error("No se pudo iniciar la sesión temporal.")); }, reject);
  });
}

function newRoomData(user, name) {
  return {
    createdAt: Date.now(),
    players: { p1: { uid: user.uid, name }, p2: null },
    state: { phase: "waiting", sceneIndex: 0, votes: {p1: null, p2: null}, scores: {bravery:0,caution:0,teamwork:0}, history: [], ending: null, lastResolvedScene: -1 },
    chat: null
  };
}

async function createRoom() {
  const button = $("create-room"); clearError(); showButtonBusy(button,true);
  try {
    const user = await ensureAuth();
    let success = false, code = "";
    for (let i=0;i<8 && !success;i++) {
      code = randomCode();
      try { await set(ref(db, roomPath(code)), newRoomData(user, cleanName())); success = true; }
      catch (e) { if (e?.code !== "PERMISSION_DENIED" && !String(e?.message).toLowerCase().includes("permission")) throw e; }
    }
    if (!success) throw new Error("No se pudo crear una sala. Pulsa otra vez e inténtalo de nuevo.");
    enterGame(code, "p1");
  } catch (e) { showError(e.message || "No se pudo crear la sala."); }
  finally { showButtonBusy(button,false,"Crear sala ↗"); }
}

async function joinRoom() {
  const button = $("join-room"); clearError(); showButtonBusy(button,true);
  const code = $("room-code").value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (code.length !== 6) { showError("El código tiene 6 caracteres. Revisa el que te enviaron."); showButtonBusy(button,false,"Unirme"); return; }
  try {
    const user = await ensureAuth();
    const slotRef = ref(db, `${roomPath(code)}/players/p2`);
    // The database rules only allow claiming an empty p2 slot for an existing room.
    await set(slotRef, { uid: user.uid, name: cleanName() });
    currentRoomCode = code; currentSlot = "p2";
    const stateRef = ref(db, statePath(code));
    const snap = await get(stateRef);
    if (!snap.exists()) throw new Error("Esta sala no está disponible.");
    await update(stateRef, { phase: "playing" });
    enterGame(code, "p2");
  } catch (e) {
    const raw = String(e?.code || "") + " " + String(e?.message || "");
    if (/PERMISSION_DENIED|permission|permission_denied/i.test(raw)) showError("No se pudo entrar. Revisa el código o quizá ya hay dos jugadores en esa sala.");
    else showError(e.message || "No se pudo unir a la sala.");
  } finally { showButtonBusy(button,false,"Unirme"); }
}

function enterGame(code, slot) {
  currentRoomCode = code; currentSlot = slot; lastRenderedRoom = null;
  lobby.classList.add("hidden"); game.classList.remove("hidden");
  $("room-code-label").textContent = code; $("waiting-code").textContent = code;
  $("player-badge").textContent = slot === "p1" ? "JUGADOR 01" : "JUGADOR 02";
  $("waiting-panel").classList.remove("hidden"); $("story-panel").classList.add("hidden"); clearError();
  if (unsubscribeRoom) unsubscribeRoom();
  unsubscribeRoom = onValue(ref(db, roomPath(code)), snapshot => {
    if (!snapshot.exists()) { showError("La sala ya no existe."); return; }
    const data = snapshot.val(); lastRenderedRoom = data; renderRoom(data);
    const state = data.state || {};
    if (state.phase === "playing" && state.votes?.p1 && state.votes?.p2 && state.lastResolvedScene !== state.sceneIndex) resolveIfReady();
  }, error => showError("Se perdió la conexión con la sala. Comprueba internet y vuelve a entrar: " + error.message));
}

function renderRoom(data) {
  const players = data.players || {};
  const other = players[currentSlot === "p1" ? "p2" : "p1"];
  const state = data.state || {};
  const ready = Boolean(players.p1 && players.p2);
  $("waiting-panel").classList.toggle("hidden", ready);
  $("story-panel").classList.toggle("hidden", !ready);
  if (!ready) return;
  renderScene(data, state);
  renderChat(data.chat || {});
  renderHistory(state);
}

function renderScene(data, state) {
  const idx = Number(state.sceneIndex || 0);
  if (state.phase === "ended" || idx >= SCENES.length) {
    $("scene-number").textContent = "CASO CERRADO";
    $("scene-title").textContent = "La casa los recuerda";
    $("scene-story").textContent = "La puerta está abierta. Afuera, el cielo vuelve a aclararse; el reloj de la calle marca las 3:14. Lograron salir juntos… pero en el vidrio del refugio aparecen dos huellas desde el otro lado.";
    $("private-clue").textContent = "El vidrio se empaña desde fuera y escribe: «Nos vemos mañana».";
    $("choices").innerHTML = ""; $("submitted-note").classList.add("hidden"); $("vote-status").textContent = "FINAL DESCUBIERTO";
    if (!$("ending-card")) {
      const ending = document.createElement("div"); ending.id = "ending-card"; ending.className = "ending-card";
      const title = document.createElement("h3"), body = document.createElement("p"); title.textContent = endingTitle(state.scores || {}); body.textContent = endingText(state.scores || {}); ending.append(title,body); $("scene-panel").append(ending);
    }
    return;
  }
  const scene = SCENES[idx];
  const votes = state.votes || {p1:null,p2:null};
  const voted = Boolean(votes[currentSlot]);
  $("chapter-tag").textContent = `CAPÍTULO 0${idx + 1}`;
  $("scene-number").textContent = `ESCENA 0${idx + 1} / 03`;
  safeText($("scene-title"), scene.title); safeText($("scene-story"), scene.story);
  safeText($("private-clue"), scene.clues[currentSlot]);
  $("vote-status").textContent = votes.p1 && votes.p2 ? "Decisión conjunta…" : (votes[currentSlot] ? "Tu voto quedó guardado" : "Falta una decisión");
  $("submitted-note").classList.toggle("hidden", !voted || Boolean(votes.p1 && votes.p2));
  const choices = $("choices"); choices.innerHTML = "";
  if ($("ending-card")) $("ending-card").remove();
  scene.choices.forEach(choice => {
    const btn = document.createElement("button"); btn.className = "choice" + (votes[currentSlot] === choice.id ? " selected" : ""); btn.disabled = voted || state.phase !== "playing";
    const letter = document.createElement("span"); letter.className = "choice-letter"; letter.textContent = choice.id;
    const content = document.createElement("span"); const title = document.createElement("strong"); title.textContent = choice.title; const detail = document.createElement("small"); detail.textContent = choice.detail;
    content.append(title,detail); btn.append(letter,content); btn.addEventListener("click", () => castVote(choice.id)); choices.append(btn);
  });
}

async function castVote(choiceId) {
  if (!currentRoomCode || !currentSlot) return;
  try { await set(ref(db, `${statePath(currentRoomCode)}/votes/${currentSlot}`), choiceId); }
  catch (e) { showError("No se pudo guardar tu decisión. Comprueba la conexión."); }
}

function describeOutcome(sceneIndex, votes) {
  const scene = SCENES[sceneIndex];
  return scene.outcomes[`${votes.p1}${votes.p2}`] || scene.outcomes[`${votes.p2}${votes.p1}`] || scene.fallback;
}
function endingTitle(scores) {
  if ((scores.teamwork || 0) >= 3) return "Final: Salieron juntos";
  if ((scores.caution || 0) >= 3) return "Final: La casa quedó atrás";
  if ((scores.bravery || 0) >= 3) return "Final: La puerta abierta";
  return "Final: La casa los recuerda";
}
function endingText(scores) {
  if ((scores.teamwork || 0) >= 3) return "Confiaron el uno en el otro y lograron salir sin separarse. En el camino prometen no volver a entrar. Al amanecer, encuentran dos llaves idénticas en sus bolsillos.";
  if ((scores.caution || 0) >= 3) return "No siguieron cada ruido. Cerraron la última puerta y escaparon por el patio. Desde entonces, a las 3:13, ambos reciben una notificación sin texto.";
  if ((scores.bravery || 0) >= 3) return "Se enfrentaron al misterio y encontraron la salida. Sin embargo, en la foto que toman afuera aparece una tercera sombra en la ventana.";
  return "La casa los deja ir, aunque nadie entiende cómo. Esa noche, sus relojes se quedan detenidos a las 3:13.";
}

async function resolveIfReady() {
  const stateRef = ref(db, statePath(currentRoomCode));
  try {
    await runTransaction(stateRef, current => {
      if (!current || current.phase !== "playing" || !current.votes?.p1 || !current.votes?.p2 || current.lastResolvedScene === current.sceneIndex) return;
      const idx = Number(current.sceneIndex || 0); if (idx >= SCENES.length) return;
      const votes = {p1:current.votes.p1,p2:current.votes.p2};
      const scores = {...(current.scores || {bravery:0,caution:0,teamwork:0})};
      for (const slot of ["p1","p2"]) {
        const choice = SCENES[idx].choices.find(c => c.id === votes[slot]);
        if (choice) scores[choice.effect] = (scores[choice.effect] || 0) + 1;
      }
      const history = [...(current.history || []), {sceneIndex:idx, votes, outcome:describeOutcome(idx,votes)}];
      const nextIndex = idx + 1;
      return {...current, scores, history, sceneIndex:nextIndex, votes:{p1:null,p2:null}, lastResolvedScene:idx, phase:nextIndex >= SCENES.length ? "ended" : "playing", ending:nextIndex >= SCENES.length ? endingTitle(scores) : null};
    }, { applyLocally: false });
  } catch (e) { console.error("No se pudo resolver la ronda", e); }
}

function renderHistory(state) {
  const history = state.history || []; const panel = $("history-panel");
  panel.classList.toggle("hidden", history.length === 0);
  const list = $("history-list"); list.innerHTML = "";
  history.forEach(item => {
    const scene = SCENES[item.sceneIndex]; const row = document.createElement("div"); row.className = "history-item";
    const h = document.createElement("h4"); h.textContent = scene ? scene.title : "Escena";
    const p = document.createElement("p"); p.textContent = item.outcome || "Los dos tomaron una decisión."; row.append(h,p); list.append(row);
  });
}

function renderChat(chat) {
  const box = $("chat-messages"); const messages = Object.entries(chat || {}).map(([id,item]) => ({id,...item})).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0)).slice(-40);
  box.innerHTML = "";
  if (!messages.length) { const empty = document.createElement("div"); empty.className = "chat-empty"; empty.textContent = "Todavía no hay mensajes. Comparte tu pista secreta."; box.append(empty); return; }
  for (const m of messages) {
    const bubble = document.createElement("div"); bubble.className = "message" + (m.uid === currentUser?.uid ? " mine" : "");
    const name = document.createElement("div"); name.className = "message-name"; name.textContent = m.name || "Detective";
    const body = document.createElement("div"); body.className = "message-text"; body.textContent = m.text || "";
    const time = document.createElement("div"); time.className = "message-time"; time.textContent = m.createdAt ? new Date(m.createdAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}) : "";
    bubble.append(name,body,time); box.append(bubble);
  }
  box.scrollTop = box.scrollHeight;
}

async function sendChat(event) {
  event.preventDefault(); const input = $("chat-input"); const text = input.value.trim().slice(0,240); if (!text || !currentRoomCode) return;
  input.value = "";
  try { await set(push(ref(db, `${roomPath(currentRoomCode)}/chat`)), {uid:currentUser.uid,name:cleanName(),text,createdAt:Date.now()}); }
  catch (e) { showError("No se pudo enviar el mensaje. Comprueba la conexión."); }
}

async function copyCode() {
  if (!currentRoomCode) return;
  try { await navigator.clipboard.writeText(currentRoomCode); toast("Código copiado: " + currentRoomCode); }
  catch { toast("Código de sala: " + currentRoomCode); }
}
async function leaveRoom() {
  if (unsubscribeRoom) { unsubscribeRoom(); unsubscribeRoom = null; }
  currentRoomCode = null; currentSlot = null; lastRenderedRoom = null;
  game.classList.add("hidden"); lobby.classList.remove("hidden"); clearError();
  $("room-code").value = ""; $("chat-messages").innerHTML = "";
}

$("create-room").addEventListener("click", createRoom);
$("join-room").addEventListener("click", joinRoom);
$("room-code").addEventListener("input", e => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0,6); });
$("copy-code").addEventListener("click", copyCode);
$("copy-code-2").addEventListener("click", copyCode);
$("chat-form").addEventListener("submit", sendChat);
$("leave-room").addEventListener("click", leaveRoom);

if (isFirebaseConfigured) {
  setupNoteText("Conexión configurada. Crea una sala y comparte el código con tu amiga.");
} else {
  setupNote.textContent = "Versión preparada. Para activar salas online, conecta tu propio Firebase siguiendo LEEME.txt; no hace falta OpenAI API.";
  $("create-room").title = "Configura Firebase primero"; $("join-room").title = "Configura Firebase primero";
}
function setupNoteText(text) { setupNote.textContent = text; }

// Catch errors from missing module hosting/configuration in a visible message.
window.addEventListener("error", event => {
  if (event?.message) console.error("Error del juego:", event.message);
});
