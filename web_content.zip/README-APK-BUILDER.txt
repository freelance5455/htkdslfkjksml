MALIK MOHSIN STORE - APK BUILDER SOURCE

This package contains index.html with 107 imported Purchase Entry records from the supplied Excel workbook.

LOGIN FEATURES
- Logout button is shown after login.
- Forgot password resets login accounts only after confirmation and typing RESET LOGIN. Store purchase/sale/khata data is retained. You can then create a new Admin account.
- Multi-user login is supported on the same device/browser: an Admin can add Staff or Admin accounts. All users share the same store data on that device.
- This is NOT cloud/multi-device sync. Different phones/computers do not share live data.

IMPORTANT
- This is a source package for an HTML-to-APK / WebView builder, not a compiled APK.
- Open index.html in a browser first and open Purchase Entry to verify the imported rows.
- The imported rows use new lot numbers LOT-20261021-001 through LOT-20261021-107, not the Excel lot IDs.
- App data is stored locally by the browser/WebView. Keep backups before clearing app/browser data.
