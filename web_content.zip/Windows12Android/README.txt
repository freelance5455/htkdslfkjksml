Windows 12 Simulator - Android Studio project

This is an Android WebView wrapper for the Windows 12 Simulator HTML page.
It is NOT a real Windows operating system and does not install/run Windows .exe files.
The Store button opens the official Microsoft Store website in the device's browser.

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder (Windows12Android) as an existing project.
3. Let Gradle sync and install the requested Android SDK (API 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location.

Note: This environment does not have the Android SDK/Gradle build tools, so this is a ready-to-build project, not a compiled APK.
