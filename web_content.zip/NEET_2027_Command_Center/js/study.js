import { loadAppData } from "./storage.js";
import { renderShell } from "./components.js";
import { calculateStudyHours } from "./calculations.js";
import { updateAppData } from "./events.js";
import { DATA_UPDATED_EVENT } from "./data.js";
import { checkProfileAccess } from "./profileGuard.js";

const profileAllowed = checkProfileAccess();

if (profileAllowed) {
  renderShell("study");
}

/* =========================================================
   HELPERS
   ========================================================= */

const $ = (id) => document.getElementById(id);

const todayKey = () => {
  const date = new Date();

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
};

const formatHours = (hours) => {
  const totalMinutes = Math.round(
    (Number(hours) || 0) * 60
  );

  if (totalMinutes <= 0) {
    return "0m";
  }

  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;

  if (h > 0 && m > 0) {
    return `${h}h ${m}m`;
  }

  if (h > 0) {
    return `${h}h`;
  }

  return `${m}m`;
};

const escapeHTML = (value = "") =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

const generateId = (prefix) =>
  `${prefix}_${Date.now()}_${Math.random()
    .toString(36)
    .slice(2, 8)}`;


/* =========================================================
   MODAL HELPERS
   ========================================================= */

function openModal(modal) {
  if (!modal) return;

  modal.hidden = false;
  modal.classList.add("open");
  document.body.classList.add("modal-open");
}

function closeModal(modal) {
  if (!modal) return;

  modal.classList.remove("open");
  modal.hidden = true;

  /*
    Remove body lock only when no modal is open.
  */
  const anyOpenModal =
    document.querySelector(
      ".study-modal-overlay.open, .focus-modal-overlay.open"
    );

  if (!anyOpenModal) {
    document.body.classList.remove("modal-open");
  }
}


/* =========================================================
   SUMMARY
   ========================================================= */

function renderSummary() {
  const today = todayKey();

  const tasks = Array.isArray(appData?.study?.tasks)
    ? appData.study.tasks
    : [];

  const todayTasks = tasks.filter(
    (task) => !task.date || task.date === today
  );

  const completedTasks = todayTasks.filter(
    (task) => task.completed
  );

  const totalTasks = todayTasks.length;
  const completedCount = completedTasks.length;

  const totalHours = calculateStudyHours(
    appData,
    today
  );

  const completionPercent =
    totalTasks > 0
      ? Math.round(
          (completedCount / totalTasks) * 100
        )
      : 0;

  /* Today's Tasks */
  if ($("today-task-count")) {
    $("today-task-count").textContent =
      totalTasks > 0
        ? totalTasks
        : "—";
  }

  if ($("today-task-subtitle")) {
    $("today-task-subtitle").textContent =
      totalTasks > 0
        ? `${totalTasks} task${totalTasks > 1 ? "s" : ""} planned today`
        : "No tasks added yet.";
  }

  /* Completed */
  if ($("completed-task-count")) {
    $("completed-task-count").textContent =
      totalTasks > 0
        ? `${completedCount}/${totalTasks}`
        : "—";
  }

  if ($("completed-task-subtitle")) {
    $("completed-task-subtitle").textContent =
      completedCount > 0
        ? `${completedCount} task${completedCount > 1 ? "s" : ""} completed`
        : "No completed tasks yet.";
  }

  /* Study Hours */
  if ($("study-hours")) {
    $("study-hours").textContent =
      totalHours > 0
        ? formatHours(totalHours)
        : "—";
  }

  /* Completion */
  if ($("study-completion")) {
    $("study-completion").textContent =
      totalTasks > 0
        ? `${completionPercent}%`
        : "—";
  }

  if ($("study-completion-bar")) {
    $("study-completion-bar").style.width =
      `${completionPercent}%`;
  }
}


/* =========================================================
   TODAY'S TASKS
   ========================================================= */

function renderTasks() {
  const container = $("study-task-list");
  const emptyState = $("study-empty");

  if (!container) return;

  const today = todayKey();

  const tasks = (
    Array.isArray(appData?.study?.tasks)
      ? appData.study.tasks
      : []
  ).filter(
    (task) => !task.date || task.date === today
  );

  if (!tasks.length) {
    container.innerHTML = "";

    if (emptyState) {
      emptyState.hidden = false;
      emptyState.style.display = "";
    }

    return;
  }

  if (emptyState) {
    emptyState.hidden = true;
    emptyState.style.display = "none";
  }

  container.innerHTML = tasks
    .map((task) => {
      const focusTime =
        Number(task.focusTime) || 0;

      const duration =
        Number(task.duration) || 0;

      const plannedMinutes =
        Math.round(duration * 60);

      const focusComplete =
        focusTime >= plannedMinutes;

      return `
        <div
          class="study-task ${task.completed ? "completed" : ""}"
          data-task-id="${escapeHTML(task.id)}"
        >

          <div class="study-task-check">
            <input
              type="checkbox"
              class="task-complete-checkbox"
              data-id="${escapeHTML(task.id)}"
              ${task.completed ? "checked" : ""}
            />
          </div>

          <div class="study-task-main">

            <div class="study-task-title">
              ${escapeHTML(task.title)}
            </div>

            <div class="study-task-meta">

              ${
                task.subject
                  ? `
                    <span class="study-task-subject">
                      ${escapeHTML(task.subject)}
                    </span>
                  `
                  : ""
              }

              ${
                task.type
                  ? `
                    <span class="study-task-type">
                      ${escapeHTML(task.type)}
                    </span>
                  `
                  : ""
              }

              <span class="study-task-duration">
                ${formatHours(duration)}
              </span>

              ${
                focusTime > 0
                  ? `
                    <span class="study-task-focus">
                      ${focusTime}m focused
                    </span>
                  `
                  : ""
              }

            </div>

          </div>

          <div class="study-task-actions">

            <button
              type="button"
              class="btn btn-sm focus-task-btn"
              data-id="${escapeHTML(task.id)}"
              ${focusComplete ? "disabled" : ""}
            >
              ${focusComplete ? "Focused" : "Focus"}
            </button>

            <button
              type="button"
              class="btn btn-sm btn-danger delete-task-btn"
              data-id="${escapeHTML(task.id)}"
            >
              Delete
            </button>

          </div>

        </div>
      `;
    })
    .join("");

  bindTaskEvents();
}


/* =========================================================
   TASK EVENTS
   ========================================================= */

function bindTaskEvents() {
  document
    .querySelectorAll(".task-complete-checkbox")
    .forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        const id = checkbox.dataset.id;

        updateAppData(appData, (data) => {
          const task = data.study.tasks.find(
            (item) => item.id === id
          );

          if (!task) return;

          task.completed = checkbox.checked;
        });
      });
    });

  document
    .querySelectorAll(".delete-task-btn")
    .forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.dataset.id;

        if (focusTask?.id === id) {
          stopFocusTimer();

          closeFocusMode(false);
        }

        updateAppData(appData, (data) => {
          data.study.tasks =
            data.study.tasks.filter(
              (task) => task.id !== id
            );
        });
      });
    });

  document
    .querySelectorAll(".focus-task-btn")
    .forEach((button) => {
      button.addEventListener("click", () => {
        const task = appData.study.tasks.find(
          (item) => item.id === button.dataset.id
        );

        if (!task) return;

        openFocusMode(task);
      });
    });
}


/* =========================================================
   ADD TASK
   ========================================================= */

function openTaskModal() {
  const modal = $("task-modal");

  if (!modal) return;

  const form = $("task-form");

  if (form) {
    form.reset();
  }

  openModal(modal);
}

function closeTaskModal() {
  closeModal($("task-modal"));
}

function saveTaskFromForm(event) {
  event.preventDefault();

  const title =
    $("task-title")?.value.trim() || "";

  const subject =
    $("task-subject")?.value || "";

  const duration =
    Number(
      $("task-duration")?.value
    ) || 0;

  const type =
    $("task-type")?.value || "study";

  if (!title) return;

  if (duration <= 0) return;

  const task = {
    id: generateId("study"),
    title,
    subject,
    duration,
    type,
    date: todayKey(),
    completed: false,
    focusTime: 0
  };

  updateAppData(appData, (data) => {
    if (!Array.isArray(data.study.tasks)) {
      data.study.tasks = [];
    }

    data.study.tasks.push(task);
  });

  closeTaskModal();
}


/* =========================================================
   SESSION LIST
   ========================================================= */

function renderSessions() {
  const container =
    $("study-session-list");

  const emptyState =
    $("session-empty");

  if (!container) return;

  const today = todayKey();

  const sessions = (
    Array.isArray(appData?.study?.sessions)
      ? appData.study.sessions
      : []
  ).filter(
    (session) =>
      !session.date ||
      session.date === today
  );

  if (!sessions.length) {
    container.innerHTML = "";

    if (emptyState) {
      emptyState.hidden = false;
      emptyState.style.display = "";
    }

    return;
  }

  if (emptyState) {
    emptyState.hidden = true;
    emptyState.style.display = "none";
  }

  container.innerHTML = sessions
    .map(
      (session) => `
        <div
          class="study-session"
          data-session-id="${escapeHTML(session.id)}"
        >

          <div class="study-session-main">

            <div class="study-session-title">
              ${escapeHTML(
                session.title ||
                "Study Session"
              )}
            </div>

            <div class="study-session-meta">
              ${
                session.subject
                  ? escapeHTML(
                      session.subject
                    )
                  : ""
              }
            </div>

          </div>

          <div class="study-session-duration">
            ${formatHours(session.duration)}
          </div>

          <button
            type="button"
            class="btn btn-sm btn-danger delete-session-btn"
            data-id="${escapeHTML(session.id)}"
          >
            Delete
          </button>

        </div>
      `
    )
    .join("");

  document
    .querySelectorAll(".delete-session-btn")
    .forEach((button) => {
      button.addEventListener(
        "click",
        () => {
          const id =
            button.dataset.id;

          updateAppData(
            appData,
            (data) => {
              data.study.sessions =
                data.study.sessions.filter(
                  (session) =>
                    session.id !== id
                );
            }
          );
        }
      );
    });
}


/* =========================================================
   ADD SESSION
   ========================================================= */

function openSessionModal() {
  const modal =
    $("session-modal");

  if (!modal) return;

  const form =
    $("session-form");

  if (form) {
    form.reset();
  }

  openModal(modal);
}

function closeSessionModal() {
  closeModal(
    $("session-modal")
  );
}

function saveSessionFromForm(event) {
  event.preventDefault();

  const subject =
    $("session-subject")?.value ||
    "";

  const duration =
    Number(
      $("session-duration")?.value
    ) || 0;

  const note =
    $("session-note")?.value.trim() ||
    "Study Session";

  if (duration <= 0) return;

  const session = {
    id: generateId("session"),
    title: note,
    subject,
    duration,
    date: todayKey()
  };

  updateAppData(
    appData,
    (data) => {
      if (
        !Array.isArray(
          data.study.sessions
        )
      ) {
        data.study.sessions = [];
      }

      data.study.sessions.push(
        session
      );
    }
  );

  closeSessionModal();
}


/* =========================================================
   FOCUS MODE
   ========================================================= */

let focusTask = null;
let focusInterval = null;

let focusTotalSeconds = 0;
let focusRemainingSeconds = 0;
let focusElapsedSeconds = 0;

/*
  Whole minutes already persisted
  for the current Focus session.
*/
let focusPersistedMinutes = 0;

const FOCUS_CIRCUMFERENCE =
  2 * Math.PI * 130;


/* =========================================================
   FOCUS DISPLAY
   ========================================================= */

function updateFocusRing() {
  const ring =
    $("focus-ring-progress");

  if (!ring) return;

  const progress =
    focusTotalSeconds > 0
      ? 1 -
        focusRemainingSeconds /
          focusTotalSeconds
      : 0;

  const offset =
    FOCUS_CIRCUMFERENCE *
    (1 - progress);

  ring.style.strokeDasharray =
    `${FOCUS_CIRCUMFERENCE}`;

  ring.style.strokeDashoffset =
    `${offset}`;
}

function updateFocusDisplay() {
  const display =
    $("focus-time-display");

  if (!display) return;

  const totalSeconds =
    Math.max(
      0,
      Math.floor(
        focusRemainingSeconds
      )
    );

  const minutes =
    Math.floor(
      totalSeconds / 60
    );

  const seconds =
    totalSeconds % 60;

  display.textContent =
    `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

  updateFocusRing();

  updateFocusFooter();
}


/* =========================================================
   FOCUS FOOTER
   ========================================================= */

function updateFocusFooter() {
  if (!focusTask) return;

  const task =
    appData.study.tasks.find(
      (item) =>
        item.id === focusTask.id
    );

  if (!task) return;

  const recorded =
    Number(task.focusTime) || 0;

  const planned =
    Number(task.duration) || 0;

  if ($("focus-recorded-time")) {
    $("focus-recorded-time")
      .textContent =
      `${recorded}m`;
  }

  if ($("focus-planned-time")) {
    $("focus-planned-time")
      .textContent =
      formatHours(planned);
  }
}


/* =========================================================
   PERSIST FOCUS TIME
   ========================================================= */

function persistFocusTime() {
  if (!focusTask) return;

  const elapsedMinutes =
    Math.floor(
      focusElapsedSeconds / 60
    );

  const delta =
    elapsedMinutes -
    focusPersistedMinutes;

  if (delta <= 0) return;

  const task =
    appData.study.tasks.find(
      (item) =>
        item.id === focusTask.id
    );

  if (!task) return;

  const plannedMinutes =
    Math.max(
      0,
      Math.round(
        (Number(task.duration) || 0) *
          60
      )
    );

  const existingFocus =
    Math.max(
      0,
      Math.round(
        Number(task.focusTime) || 0
      )
    );

  const remainingAllowed =
    Math.max(
      0,
      plannedMinutes -
        existingFocus
    );

  const safeDelta =
    Math.min(
      delta,
      remainingAllowed
    );

  if (safeDelta <= 0) {
    focusPersistedMinutes =
      elapsedMinutes;

    return;
  }

  updateAppData(
    appData,
    (data) => {
      const currentTask =
        data.study.tasks.find(
          (item) =>
            item.id === focusTask.id
        );

      if (!currentTask) return;

      const planned =
        Math.max(
          0,
          Math.round(
            (Number(
              currentTask.duration
            ) || 0) * 60
          )
        );

      const currentFocus =
        Math.max(
          0,
          Math.round(
            Number(
              currentTask.focusTime
            ) || 0
          )
        );

      currentTask.focusTime =
        Math.min(
          planned,
          currentFocus +
            safeDelta
        );
    }
  );

  focusPersistedMinutes =
    elapsedMinutes;

  updateFocusFooter();
}


/* =========================================================
   SET FOCUS DURATION
   ========================================================= */

function setFocusDuration(minutes) {
  if (!focusTask) return;

  const task =
    appData.study.tasks.find(
      (item) =>
        item.id === focusTask.id
    );

  if (!task) return;

  const plannedMinutes =
    Math.max(
      0,
      Math.round(
        (Number(task.duration) || 0) *
          60
      )
    );

  const focusedMinutes =
    Math.max(
      0,
      Math.round(
        Number(task.focusTime) || 0
      )
    );

  const remainingMinutes =
    Math.max(
      0,
      plannedMinutes -
        focusedMinutes
    );

  if (remainingMinutes <= 0) {
    if ($("focus-status")) {
      $("focus-status")
        .textContent =
        "Task focus limit reached";
    }

    return;
  }

  const value =
    Math.min(
      remainingMinutes,
      Math.max(
        1,
        Math.round(
          Number(minutes) || 0
        )
      )
    );

  stopFocusTimer();

  focusTotalSeconds =
    value * 60;

  focusRemainingSeconds =
    focusTotalSeconds;

  focusElapsedSeconds = 0;
  focusPersistedMinutes = 0;

  document
    .querySelectorAll(
      ".focus-preset"
    )
    .forEach((button) => {
      button.classList.toggle(
        "active",
        Number(
          button.dataset
            .focusMinutes
        ) === value
      );
    });

  if ($("focus-status")) {
    $("focus-status")
      .textContent =
      "Ready";
  }

  updateFocusDisplay();
}


/* =========================================================
   OPEN FOCUS MODE
   ========================================================= */

function openFocusMode(task) {
  stopFocusTimer();

  focusTask = task;

  const modal =
    $("focus-modal");

  if (!modal) return;

  const plannedMinutes =
    Math.max(
      0,
      Math.round(
        (Number(task.duration) || 0) *
          60
      )
    );

  const focusedMinutes =
    Math.max(
      0,
      Math.round(
        Number(task.focusTime) || 0
      )
    );

  const remainingMinutes =
    Math.max(
      0,
      plannedMinutes -
        focusedMinutes
    );

  focusElapsedSeconds = 0;
  focusPersistedMinutes = 0;

  if ($("focus-task-title")) {
    $("focus-task-title")
      .textContent =
      task.title;
  }

  if (remainingMinutes <= 0) {
    focusTotalSeconds = 0;
    focusRemainingSeconds = 0;

    if ($("focus-status")) {
      $("focus-status")
        .textContent =
        "Task focus limit reached";
    }

    openModal(modal);
    updateFocusDisplay();

    return;
  }

  const defaultMinutes =
    Math.min(
      25,
      remainingMinutes
    );

  focusTotalSeconds =
    defaultMinutes * 60;

  focusRemainingSeconds =
    focusTotalSeconds;

  document
    .querySelectorAll(
      ".focus-preset"
    )
    .forEach((button) => {
      button.classList.toggle(
        "active",
        Number(
          button.dataset
            .focusMinutes
        ) === defaultMinutes
      );
    });

  if ($("focus-status")) {
    $("focus-status")
      .textContent =
      "Ready";
  }

  openModal(modal);

  updateFocusDisplay();
  updateFocusFooter();
}


/* =========================================================
   CLOSE FOCUS MODE
   ========================================================= */

function closeFocusMode(
  shouldRender = true
) {
  persistFocusTime();

  stopFocusTimer();

  closeModal(
    $("focus-modal")
  );

  focusTask = null;

  focusTotalSeconds = 0;
  focusRemainingSeconds = 0;
  focusElapsedSeconds = 0;
  focusPersistedMinutes = 0;

  if (shouldRender) {
    renderAll();
  }
}


/* =========================================================
   START FOCUS
   ========================================================= */

function startFocusTimer() {
  if (!focusTask) return;

  const task =
    appData.study.tasks.find(
      (item) =>
        item.id === focusTask.id
    );

  if (!task) return;

  const plannedMinutes =
    Math.max(
      0,
      Math.round(
        (Number(task.duration) || 0) *
          60
      )
    );

  const focusedMinutes =
    Math.max(
      0,
      Math.round(
        Number(task.focusTime) || 0
      )
    );

  const remainingTaskMinutes =
    Math.max(
      0,
      plannedMinutes -
        focusedMinutes
    );

  if (remainingTaskMinutes <= 0) {
    if ($("focus-status")) {
      $("focus-status")
        .textContent =
        "Task focus limit reached";
    }

    stopFocusTimer();

    return;
  }

  /*
    Safety cap:
    timer can NEVER exceed
    remaining task duration.
  */
  const maximumSeconds =
    remainingTaskMinutes * 60;

  focusRemainingSeconds =
    Math.min(
      focusRemainingSeconds,
      maximumSeconds
    );

  if (focusRemainingSeconds <= 0) {
    const restartMinutes =
      Math.min(
        25,
        remainingTaskMinutes
      );

    focusTotalSeconds =
      restartMinutes * 60;

    focusRemainingSeconds =
      focusTotalSeconds;

    focusElapsedSeconds = 0;
    focusPersistedMinutes = 0;
  }

  stopFocusTimer();

  if ($("focus-status")) {
    $("focus-status")
      .textContent =
      "Focusing…";
  }

  focusInterval =
    setInterval(() => {
      if (!focusTask) {
        stopFocusTimer();
        return;
      }

      if (
        focusRemainingSeconds <= 0
      ) {
        finishFocusSession();
        return;
      }

      focusRemainingSeconds -= 1;

      focusElapsedSeconds =
        Math.min(
          focusElapsedSeconds + 1,
          focusTotalSeconds
        );

      updateFocusDisplay();

      /*
        Save every completed minute.
      */
      if (
        focusElapsedSeconds > 0 &&
        focusElapsedSeconds % 60 === 0
      ) {
        persistFocusTime();
      }

      if (
        focusRemainingSeconds <= 0
      ) {
        finishFocusSession();
      }
    }, 1000);
}


/* =========================================================
   FINISH FOCUS SESSION
   ========================================================= */

function finishFocusSession() {
  stopFocusTimer();

  persistFocusTime();

  focusRemainingSeconds = 0;

  updateFocusDisplay();

  if ($("focus-status")) {
    $("focus-status")
      .textContent =
      "Focus session complete";
  }

  renderAll();
}


/* =========================================================
   STOP TIMER
   ========================================================= */

function stopFocusTimer() {
  if (focusInterval !== null) {
    clearInterval(focusInterval);
    focusInterval = null;
  }
}


/* =========================================================
   RESET FOCUS
   ========================================================= */

function resetFocusTimer() {
  /*
    Already completed focus minutes stay saved.
    Only the current timer resets.
  */
  persistFocusTime();

  stopFocusTimer();

  if (!focusTask) return;

  const task =
    appData.study.tasks.find(
      (item) =>
        item.id === focusTask.id
    );

  if (!task) return;

  const plannedMinutes =
    Math.max(
      0,
      Math.round(
        (Number(task.duration) || 0) *
          60
      )
    );

  const focusedMinutes =
    Math.max(
      0,
      Math.round(
        Number(task.focusTime) || 0
      )
    );

  const remainingMinutes =
    Math.max(
      0,
      plannedMinutes -
        focusedMinutes
    );

  focusElapsedSeconds = 0;
  focusPersistedMinutes = 0;

  if (remainingMinutes <= 0) {
    focusTotalSeconds = 0;
    focusRemainingSeconds = 0;

    if ($("focus-status")) {
      $("focus-status")
        .textContent =
        "Task focus limit reached";
    }

    updateFocusDisplay();
    updateFocusFooter();

    return;
  }

  const resetMinutes =
    Math.min(
      25,
      remainingMinutes
    );

  focusTotalSeconds =
    resetMinutes * 60;

  focusRemainingSeconds =
    focusTotalSeconds;

  document
    .querySelectorAll(
      ".focus-preset"
    )
    .forEach((button) => {
      button.classList.toggle(
        "active",
        Number(
          button.dataset
            .focusMinutes
        ) === resetMinutes
      );
    });

  if ($("focus-status")) {
    $("focus-status")
      .textContent =
      "Ready";
  }

  updateFocusDisplay();
  updateFocusFooter();
}


/* =========================================================
   GLOBAL EVENTS
   ========================================================= */

function bindGlobalEvents() {

  /* ADD TASK BUTTONS */

  [
    "open-add-task",
    "add-task-inline",
    "empty-add-task"
  ].forEach((id) => {
    const button = $(id);

    if (button) {
      button.addEventListener(
        "click",
        openTaskModal
      );
    }
  });


  /* TASK MODAL */

  const closeTaskButton =
    $("close-task-modal");

  if (closeTaskButton) {
    closeTaskButton.addEventListener(
      "click",
      closeTaskModal
    );
  }

  const cancelTaskButton =
    $("cancel-task");

  if (cancelTaskButton) {
    cancelTaskButton.addEventListener(
      "click",
      closeTaskModal
    );
  }

  const taskForm =
    $("task-form");

  if (taskForm) {
    taskForm.addEventListener(
      "submit",
      saveTaskFromForm
    );
  }


  /* ADD SESSION BUTTONS */

  [
    "open-add-session",
    "empty-add-session"
  ].forEach((id) => {
    const button = $(id);

    if (button) {
      button.addEventListener(
        "click",
        openSessionModal
      );
    }
  });


  /* SESSION MODAL */

  const closeSessionButton =
    $("close-session-modal");

  if (closeSessionButton) {
    closeSessionButton.addEventListener(
      "click",
      closeSessionModal
    );
  }

  const cancelSessionButton =
    $("cancel-session");

  if (cancelSessionButton) {
    cancelSessionButton.addEventListener(
      "click",
      closeSessionModal
    );
  }

  const sessionForm =
    $("session-form");

  if (sessionForm) {
    sessionForm.addEventListener(
      "submit",
      saveSessionFromForm
    );
  }


  /* FOCUS PRESETS */

  document
    .querySelectorAll(
      ".focus-preset"
    )
    .forEach((button) => {
      button.addEventListener(
        "click",
        () => {
          setFocusDuration(
            Number(
              button.dataset
                .focusMinutes
            )
          );
        }
      );
    });


  /* CUSTOM FOCUS */

  const customFocusButton =
    $("set-focus-custom");

  if (customFocusButton) {
    customFocusButton.addEventListener(
      "click",
      () => {
        const minutes =
          Number(
            $("focus-custom-minutes")
              ?.value
          );

        if (
          !Number.isFinite(minutes) ||
          minutes <= 0
        ) {
          return;
        }

        setFocusDuration(
          minutes
        );
      }
    );
  }


  /* FOCUS START */

  const focusStart =
    $("focus-start");

  if (focusStart) {
    focusStart.addEventListener(
      "click",
      () => {
        /*
          If timer is already running,
          don't create another interval.
        */
        if (focusInterval !== null) {
          return;
        }

        startFocusTimer();
      }
    );
  }


  /* FOCUS RESET */

  const focusReset =
    $("focus-reset");

  if (focusReset) {
    focusReset.addEventListener(
      "click",
      resetFocusTimer
    );
  }


  /* FOCUS CLOSE */

  const focusClose =
    $("close-focus-modal");

  if (focusClose) {
    focusClose.addEventListener(
      "click",
      () => {
        closeFocusMode();
      }
    );
  }


  /* MODAL OUTSIDE CLICK */

  const taskModal =
    $("task-modal");

  if (taskModal) {
    taskModal.addEventListener(
      "click",
      (event) => {
        if (
          event.target ===
          taskModal
        ) {
          closeTaskModal();
        }
      }
    );
  }

  const sessionModal =
    $("session-modal");

  if (sessionModal) {
    sessionModal.addEventListener(
      "click",
      (event) => {
        if (
          event.target ===
          sessionModal
        ) {
          closeSessionModal();
        }
      }
    );
  }

  const focusModal =
    $("focus-modal");

  if (focusModal) {
    focusModal.addEventListener(
      "click",
      (event) => {
        if (
          event.target ===
          focusModal
        ) {
          closeFocusMode();
        }
      }
    );
  }
}


/* =========================================================
   BEFORE UNLOAD
   ========================================================= */

window.addEventListener(
  "beforeunload",
  () => {
    persistFocusTime();
    stopFocusTimer();
  }
);


/* =========================================================
   DATA UPDATED EVENT
   ========================================================= */

window.addEventListener(
  DATA_UPDATED_EVENT,
  (event) => {
    /*
      Always use the latest central appData.
    */
    appData =
      event.detail ||
      loadAppData();

    renderAll();
  }
);


/* =========================================================
   RENDER ALL
   ========================================================= */

function renderAll() {
  renderSummary();
  renderTasks();
  renderSessions();
}


/* =========================================================
   INITIALIZE
   ========================================================= */

if (profileAllowed) {
  bindGlobalEvents();
  renderAll();
}