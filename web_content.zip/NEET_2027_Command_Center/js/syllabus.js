import { loadAppData, saveAppData } from "./storage.js";
import { renderShell } from "./components.js";
import { calculateSyllabusProgress } from "./calculations.js";
import { checkProfileAccess } from "./profileGuard.js";

const appData = loadAppData();
let activeSubject = "physics";

checkProfileAccess();

renderShell("syllabus");

const $ = (id) => document.getElementById(id);

const subjectNames = {
  physics: "Physics",
  chemistry: "Chemistry",
  biology: "Biology"
};

function slugify(value) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function ensureSubject(subject) {
  if (!Array.isArray(appData.syllabus.subjects[subject])) {
    appData.syllabus.subjects[subject] = [];
  }

  return appData.syllabus.subjects[subject];
}

function setProgressText(textId, barId, value) {
  const text = $(textId);
  const bar = $(barId);

  if (value === null || Number.isNaN(value)) {
    text.textContent = "—";
    bar.style.width = "0%";
    return;
  }

  const rounded = Math.round(value);

  text.textContent = `${rounded}%`;
  bar.style.width = `${Math.max(0, Math.min(100, rounded))}%`;
}

function renderStats() {
  const physics = calculateSyllabusProgress(
    ensureSubject("physics")
  );

  const chemistry = calculateSyllabusProgress(
    ensureSubject("chemistry")
  );

  const biology = calculateSyllabusProgress(
    ensureSubject("biology")
  );

  const all = [
    ...ensureSubject("physics"),
    ...ensureSubject("chemistry"),
    ...ensureSubject("biology")
  ];

  const overall = calculateSyllabusProgress(all);

  setProgressText(
    "overall-progress",
    "overall-progress-bar",
    overall
  );

  setProgressText(
    "physics-progress",
    "physics-progress-bar",
    physics
  );

  setProgressText(
    "chemistry-progress",
    "chemistry-progress-bar",
    chemistry
  );

  setProgressText(
    "biology-progress",
    "biology-progress-bar",
    biology
  );
}

function renderRows() {
  const chapters = ensureSubject(activeSubject);

  const tbody = $("chapter-rows");
  const empty = $("syllabus-empty");

  $("subject-title").textContent =
    subjectNames[activeSubject];

  $("subject-subtitle").textContent = chapters.length
    ? `${chapters.length} chapter${
        chapters.length === 1 ? "" : "s"
      }`
    : "No chapters added yet.";

  tbody.innerHTML = "";

  empty.hidden = chapters.length > 0;

  chapters.forEach((chapter) => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>
        <div class="chapter-name">
          ${escapeHtml(chapter.name)}
        </div>
      </td>

      ${checkCell("lecture", chapter)}
      ${checkCell("ncert", chapter)}
      ${checkCell("questions", chapter)}
      ${checkCell("revision", chapter)}

      <td class="row-action">
        <button
          class="delete-btn"
          data-delete="${escapeHtml(chapter.id)}"
          type="button"
          title="Delete chapter"
        >
          Delete
        </button>
      </td>
    `;

    tbody.appendChild(tr);
  });

  tbody
    .querySelectorAll("[data-check]")
    .forEach((input) => {
      input.addEventListener("change", (event) => {
        const chapterId = event.target.dataset.id;
        const field = event.target.dataset.check;

        const item = chapters.find(
          (chapter) => chapter.id === chapterId
        );

        if (!item) return;

        item[field] = event.target.checked;

        saveAppData(appData);

        renderStats();
        renderRows();
      });
    });

  tbody
    .querySelectorAll("[data-delete]")
    .forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.dataset.delete;

        const index = chapters.findIndex(
          (chapter) => chapter.id === id
        );

        if (index === -1) return;

        chapters.splice(index, 1);

        saveAppData(appData);

        renderStats();
        renderRows();
      });
    });
}

function checkCell(field, chapter) {
  const labels = {
    lecture: "Lecture",
    ncert: "NCERT",
    questions: "Questions",
    revision: "Revision"
  };

  return `
    <td class="check-cell">
      <label
        class="check-wrap"
        title="${labels[field]}"
      >
        <input
          type="checkbox"
          data-check="${field}"
          data-id="${escapeHtml(chapter.id)}"
          ${chapter[field] ? "checked" : ""}
        >

        <span class="custom-check"></span>
      </label>
    </td>
  `;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function openModal(subject = activeSubject) {
  $("chapter-subject").value = subject;
  $("chapter-name").value = "";

  $("chapter-modal").hidden = false;

  setTimeout(() => {
    $("chapter-name").focus();
  }, 0);
}

function closeModal() {
  $("chapter-modal").hidden = true;
}


/* ==================================================
   OPEN MODAL
================================================== */

$("open-add-chapter").addEventListener(
  "click",
  () => openModal()
);

$("add-chapter-inline").addEventListener(
  "click",
  () => openModal()
);

$("empty-add-chapter").addEventListener(
  "click",
  () => openModal()
);


/* ==================================================
   CLOSE MODAL
================================================== */

$("close-chapter-modal").addEventListener(
  "click",
  closeModal
);

$("cancel-chapter").addEventListener(
  "click",
  closeModal
);


/* ==================================================
   CLOSE MODAL — OUTSIDE CLICK
================================================== */

$("chapter-modal").addEventListener(
  "click",
  (event) => {
    if (event.target === $("chapter-modal")) {
      closeModal();
    }
  }
);


/* ==================================================
   SUBJECT TABS
================================================== */

document
  .querySelectorAll(".syllabus-tab")
  .forEach((button) => {

    button.addEventListener("click", () => {

      activeSubject = button.dataset.subject;

      document
        .querySelectorAll(".syllabus-tab")
        .forEach((tab) => {
          tab.classList.toggle(
            "active",
            tab === button
          );
        });

      renderRows();
    });
  });


/* ==================================================
   ADD CHAPTER
================================================== */

$("chapter-form").addEventListener(
  "submit",
  (event) => {

    event.preventDefault();

    const subject =
      $("chapter-subject").value;

    const name =
      $("chapter-name").value.trim();

    if (!name) return;

    const chapters =
      ensureSubject(subject);

    const baseId =
      `${subject}_${slugify(name) || Date.now()}`;

    let id = baseId;
    let counter = 2;

    while (
      chapters.some(
        (chapter) => chapter.id === id
      )
    ) {
      id = `${baseId}_${counter++}`;
    }

    chapters.push({
      id,
      subject,
      name,
      lecture: false,
      ncert: false,
      questions: false,
      revision: false
    });

    activeSubject = subject;

    document
      .querySelectorAll(".syllabus-tab")
      .forEach((tab) => {
        tab.classList.toggle(
          "active",
          tab.dataset.subject === activeSubject
        );
      });

    saveAppData(appData);

    closeModal();

    renderStats();
    renderRows();
  }
);


/* ==================================================
   INITIAL RENDER
================================================== */

renderStats();
renderRows();