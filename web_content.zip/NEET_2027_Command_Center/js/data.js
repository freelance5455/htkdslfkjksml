export const DEFAULT_APP_DATA = {
  version: 1,

  profile: {
    completed: false,

    accountCreated: false,
    accountType: "",
    accountIdentifier: "",

    name: "",
    examYear: 2027,
    targetScore: null,
    targetRank: null,
    dreamCollege: "",
    preparationMode: "",
    startDate: null
  },

  syllabus: {
    subjects: {
      physics: [],
      chemistry: [],
      biology: []
    }
  },

  study: {
    tasks: [],
    sessions: []
  },

  tests: {
    records: []
  },

  mistakes: {
    records: []
  },

  calendar: {
    events: []
  },

  settings: {
    theme: "system",
    notifications: true
  }
};

export const STORAGE_KEY = "neet2027_appData_v1";

export const DATA_UPDATED_EVENT = "neet2027:dataUpdated";