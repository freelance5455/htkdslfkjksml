import { loadAppData } from "./storage.js";
import { renderShell } from "./components.js";
import {
  calculateSyllabusProgress,
  calculateStudyHours,
  calculateTestTotal
} from "./calculations.js";
import { DATA_UPDATED_EVENT } from "./data.js";

let appData = loadAppData();

function formatDate(date) {
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(date);
}

function todayKey() {
  const d = new Date();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");

  return `${d.getFullYear()}-${month}-${day}`;
}


/* =========================================================
   STUDY HOURS FORMAT
   ========================================================= */

function formatStudyHours(hours) {
  const totalMinutes = Math.round(
    (Number(hours) || 0) * 60
  );

  if (totalMinutes <= 0) {
    return "0m";
  }

  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;

  if (h > 0 && m > 0) {
    return `${h}h ${m}m`;
  }

  if (h > 0) {
    return `${h}h`;
  }

  return `${m}m`;
}


function setText(id, value) {
  const element = document.getElementById(id);

  if (element) {
    element.textContent = value;
  }
}

function setBar(id, value) {
  const element = document.getElementById(id);

  if (!element) return;

  const safeValue = Number.isFinite(value)
    ? Math.max(0, Math.min(100, value))
    : 0;

  element.style.width = `${safeValue}%`;
}

function percentText(value) {
  return Number.isFinite(value)
    ? `${Math.round(value)}%`
    : "—";
}

function getChapters(subject) {
  return appData.syllabus?.subjects?.[subject] || [];
}

function subjectProgress(subject) {
  const chapters = getChapters(subject);

  return chapters.length
    ? calculateSyllabusProgress(chapters)
    : null;
}


/* =========================================================
   TEST DATA
   ========================================================= */

function getTests() {
  return appData.tests?.records || [];
}

function getLatestTest() {
  const tests = getTests();

  if (!tests.length) return null;

  return [...tests].sort((a, b) => {
    const dateA = String(a.date || "");
    const dateB = String(b.date || "");

    if (dateA !== dateB) {
      return dateB.localeCompare(dateA);
    }

    return String(b.id || "").localeCompare(String(a.id || ""));
  })[0];
}


/* =========================================================
   SYLLABUS
   ========================================================= */

function getOverallSyllabusProgress() {
  const allChapters = [
    ...getChapters("physics"),
    ...getChapters("chemistry"),
    ...getChapters("biology")
  ];

  return allChapters.length
    ? calculateSyllabusProgress(allChapters)
    : null;
}

function getRevisionProgress() {
  const allChapters = [
    ...getChapters("physics"),
    ...getChapters("chemistry"),
    ...getChapters("biology")
  ];

  if (!allChapters.length) return null;

  const revised = allChapters.filter(
    chapter => Boolean(chapter.revision)
  ).length;

  return (revised / allChapters.length) * 100;
}


/* =========================================================
   STUDY DATA
   ========================================================= */

function getTodayTasks() {
  const today = todayKey();

  return (appData.study?.tasks || []).filter(
    task => !task.date || task.date === today
  );
}

function getTodaySessions() {
  const today = todayKey();

  return (appData.study?.sessions || []).filter(
    session => session.date === today
  );
}

function calculateStudyStreak() {
  const sessions = appData.study?.sessions || [];

  const dates = new Set(
    sessions
      .map(session => session.date)
      .filter(Boolean)
  );

  if (!dates.size) return null;

  let streak = 0;

  const current = new Date();

  while (true) {
    const year = current.getFullYear();
    const month = String(current.getMonth() + 1).padStart(2, "0");
    const day = String(current.getDate()).padStart(2, "0");

    const key = `${year}-${month}-${day}`;

    if (!dates.has(key)) {
      break;
    }

    streak += 1;
    current.setDate(current.getDate() - 1);
  }

  return streak;
}


/* =========================================================
   MISTAKE DATA
   ========================================================= */

function getMistakes() {
  return appData.mistakes?.records || [];
}


/* =========================================================
   SCORE JOURNEY
   ========================================================= */

function renderScoreJourney(tests) {
  const journeyEmpty = document.getElementById("journey-empty");
  const journeyList = document.getElementById("journey-list");

  if (!journeyEmpty || !journeyList) return;

  if (!tests.length) {
    journeyEmpty.style.display = "grid";
    journeyList.style.display = "none";
    journeyList.innerHTML = "";
    return;
  }

  journeyEmpty.style.display = "none";
  journeyList.style.display = "grid";

  const sortedTests = [...tests]
    .sort((a, b) => {
      const dateA = String(a.date || "");
      const dateB = String(b.date || "");

      if (dateA !== dateB) {
        return dateA.localeCompare(dateB);
      }

      return String(a.id || "").localeCompare(String(b.id || ""));
    })
    .slice(-5);

  journeyList.innerHTML = sortedTests
    .map(test => {
      const score = calculateTestTotal(test);

      return `
        <div class="journey-item">
          <span>
            ${escapeHtml(test.date || "No date")}
            ·
            ${escapeHtml(test.name || test.title || "Test")}
          </span>

          <strong>${score}/720</strong>
        </div>
      `;
    })
    .join("");
}


/* =========================================================
   HTML SAFETY
   ========================================================= */

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


/* =========================================================
   DASHBOARD
   ========================================================= */

function renderDashboard() {
  const profile = appData.profile || {};

  const tests = getTests();
  const latestTest = getLatestTest();

  const targetScore = Number(profile.targetScore);

  const now = new Date();
  const hour = now.getHours();

  const greeting =
    hour < 12
      ? "Good morning."
      : hour < 18
        ? "Good afternoon."
        : "Good evening.";


  /* ---------------------------------------------------------
     HEADER
     --------------------------------------------------------- */

  setText(
    "greeting",
    profile.name
      ? `${greeting} ${profile.name}!`
      : greeting
  );

  setText("today-date", formatDate(now));


  /* ---------------------------------------------------------
     CURRENT SCORE
     SOURCE: TESTS
     --------------------------------------------------------- */

  if (latestTest) {
    const score = calculateTestTotal(latestTest);

    setText("current-score", score);

    setText(
      "score-note",
      `Latest test: ${
        latestTest.name ||
        latestTest.title ||
        "Untitled test"
      }`
    );

    setBar(
      "score-progress",
      (score / 720) * 100
    );

    if (Number.isFinite(targetScore)) {
      setText("target-score", `${targetScore}+`);

      setText(
        "target-gap",
        Math.max(0, targetScore - score)
      );
    } else {
      setText("target-score", "—");
      setText("target-gap", "—");
    }

  } else {

    setText("current-score", "—");
    setText("score-note", "No tests recorded yet");

    setText(
      "target-score",
      Number.isFinite(targetScore)
        ? `${targetScore}+`
        : "—"
    );

    setText("target-gap", "—");

    setBar("score-progress", 0);
  }


  /* ---------------------------------------------------------
     TEST COUNT
     SOURCE: TESTS
     --------------------------------------------------------- */

  setText(
    "tests-count",
    tests.length || "—"
  );


  /* ---------------------------------------------------------
     SUBJECT SYLLABUS
     SOURCE: SYLLABUS
     --------------------------------------------------------- */

  const physics = subjectProgress("physics");
  const chemistry = subjectProgress("chemistry");
  const biology = subjectProgress("biology");

  setText(
    "physics-progress",
    percentText(physics)
  );

  setText(
    "chemistry-progress",
    percentText(chemistry)
  );

  setText(
    "biology-progress",
    percentText(biology)
  );

  setBar("physics-bar", physics);
  setBar("chemistry-bar", chemistry);
  setBar("biology-bar", biology);


  /* ---------------------------------------------------------
     OVERALL SYLLABUS + REVISION
     SOURCE: SYLLABUS
     --------------------------------------------------------- */

  const overallSyllabus = getOverallSyllabusProgress();
  const revision = getRevisionProgress();

  setText(
    "syllabus-progress",
    percentText(overallSyllabus)
  );

  setText(
    "revision-progress",
    percentText(revision)
  );


  /* ---------------------------------------------------------
     TODAY'S STUDY PLAN
     SOURCE: STUDY
     --------------------------------------------------------- */

  const todayTasks = getTodayTasks();

  const completedTasks = todayTasks.filter(
    task => Boolean(task.completed)
  ).length;

  const taskProgress = todayTasks.length
    ? (completedTasks / todayTasks.length) * 100
    : null;

  setText(
    "today-completed",
    todayTasks.length
      ? `${completedTasks}/${todayTasks.length}`
      : "—"
  );

  setBar(
    "today-progress",
    taskProgress
  );

  setText(
    "today-progress-label",
    todayTasks.length
      ? `${Math.round(taskProgress)}% completed`
      : "No study tasks today"
  );


  /* ---------------------------------------------------------
     TODAY'S STUDY HOURS
     SOURCE: STUDY
     CENTRAL CALCULATION ENGINE
     --------------------------------------------------------- */

  const today = todayKey();

  const todayStudyHours = calculateStudyHours(
    appData,
    today
  );

  setText(
    "today-hours",
    todayStudyHours > 0
      ? formatStudyHours(todayStudyHours)
      : "—"
  );


  /* ---------------------------------------------------------
     STUDY STREAK
     SOURCE: STUDY SESSIONS
     --------------------------------------------------------- */

  const streak = calculateStudyStreak();

  setText(
    "study-streak",
    streak
      ? `${streak} day${streak === 1 ? "" : "s"}`
      : "—"
  );


  /* ---------------------------------------------------------
     MISTAKE BANK
     SOURCE: MISTAKES
     --------------------------------------------------------- */

  const mistakes = getMistakes();

  const revisedMistakes = mistakes.filter(
    mistake => Boolean(mistake.revised)
  ).length;

  const pendingMistakes =
    mistakes.length - revisedMistakes;

  setText(
    "mistake-total",
    mistakes.length || "—"
  );

  setText(
    "mistake-revised",
    mistakes.length
      ? revisedMistakes
      : "—"
  );

  setText(
    "mistake-pending",
    mistakes.length
      ? pendingMistakes
      : "—"
  );

  setText(
    "mistake-empty",
    mistakes.length
      ? "Keep revising pending mistakes from the Mistake Bank."
      : "No mistakes recorded yet."
  );


  /* ---------------------------------------------------------
     SCORE JOURNEY
     SOURCE: TESTS
     --------------------------------------------------------- */

  renderScoreJourney(tests);


  /* ---------------------------------------------------------
     PROFILE / TARGET
     SOURCE: PROFILE
     --------------------------------------------------------- */

  setText(
    "profile-name",
    profile.name
      ? `${profile.name}'s NEET 2027 journey`
      : "Your NEET 2027 journey"
  );

  setText(
    "dream-college",
    profile.dreamCollege || "—"
  );

  setText(
    "target-rank",
    profile.targetRank
      ? `#${profile.targetRank}`
      : "—"
  );

  setText(
    "preparation-mode",
    profile.preparationMode || "—"
  );
}


/* =========================================================
   INITIALIZE
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  renderShell("dashboard");
  renderDashboard();

  window.neet2027 = {
    get appData() {
      return appData;
    }
  };

  window.addEventListener(
    DATA_UPDATED_EVENT,
    event => {
      appData = event.detail;
      renderDashboard();
    }
  );
});