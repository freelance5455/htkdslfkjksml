import { loadAppData, saveAppData } from "./storage.js";
import { renderShell } from "./components.js";
import { checkProfileAccess } from "./profileGuard.js";
import {
  calculateTestTotal,
  calculatePercentage
} from "./calculations.js";

const appData = loadAppData();
checkProfileAccess();

renderShell("tests");

const $ = (id) => document.getElementById(id);


/* =========================================================
   DATA SAFETY
   ========================================================= */

function ensureTestsData() {
  if (!appData.tests || typeof appData.tests !== "object") {
    appData.tests = {
      records: []
    };
  }

  if (!Array.isArray(appData.tests.records)) {
    appData.tests.records = [];
  }
}


/* =========================================================
   ID
   ========================================================= */

function createId() {
  return `test_${Date.now()}_${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}


/* =========================================================
   DATE
   ========================================================= */

function getToday() {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}


function formatDate(dateString) {
  if (!dateString) return "—";

  const date = new Date(`${dateString}T00:00:00`);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}


/* =========================================================
   NUMBER HELPERS
   ========================================================= */

function clampMarks(value, maximum) {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return 0;
  }

  return Math.min(
    maximum,
    Math.max(0, Math.round(number))
  );
}


/* =========================================================
   SORT
   ========================================================= */

function getSortedTests() {
  return [...appData.tests.records].sort((a, b) => {

    const dateA = a.date || "";
    const dateB = b.date || "";

    if (dateA !== dateB) {
      return dateB.localeCompare(dateA);
    }

    return String(b.id || "").localeCompare(
      String(a.id || "")
    );
  });
}


/* =========================================================
   SUMMARY
   ========================================================= */

function renderSummary() {
  ensureTestsData();

  const tests = getSortedTests();

  if (!tests.length) {

    $("latest-score").textContent = "—";
    $("best-score").textContent = "—";
    $("average-score").textContent = "—";
    $("tests-attempted").textContent = "—";

    $("latest-score-subtitle").textContent =
      "No tests recorded yet.";

    $("best-score-subtitle").textContent =
      "No tests recorded yet.";

    $("average-score-subtitle").textContent =
      "No tests recorded yet.";

    $("tests-attempted-subtitle").textContent =
      "No tests recorded yet.";

    return;
  }


  const scoredTests = tests.map((test) => ({
    ...test,
    total: calculateTestTotal(test)
  }));


  const latest = scoredTests[0];

  const best = scoredTests.reduce(
    (bestTest, currentTest) =>
      currentTest.total > bestTest.total
        ? currentTest
        : bestTest
  );


  const average =
    scoredTests.reduce(
      (sum, test) => sum + test.total,
      0
    ) / scoredTests.length;


  $("latest-score").textContent =
    `${latest.total} / 720`;

  $("latest-score-subtitle").textContent =
    latest.name || "Latest recorded test";


  $("best-score").textContent =
    `${best.total} / 720`;

  $("best-score-subtitle").textContent =
    best.name || "Highest recorded score";


  $("average-score").textContent =
    `${Math.round(average)} / 720`;

  $("average-score-subtitle").textContent =
    "Across recorded tests";


  $("tests-attempted").textContent =
    scoredTests.length;

  $("tests-attempted-subtitle").textContent =
    `${scoredTests.length} recorded test${
      scoredTests.length === 1 ? "" : "s"
    }`;
}


/* =========================================================
   TABLE
   ========================================================= */

function renderRows() {
  ensureTestsData();

  const tests = getSortedTests();

  const tbody = $("test-rows");
  const empty = $("tests-empty");

  tbody.innerHTML = "";

  empty.hidden = tests.length > 0;


  $("tests-subtitle").textContent =
    tests.length
      ? `${tests.length} recorded test${
          tests.length === 1 ? "" : "s"
        }`
      : "Your recorded NEET test scores will appear here.";


  tests.forEach((test) => {

    const total = calculateTestTotal(test);
    const percentage = calculatePercentage(total);

    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>
        <div class="test-name">
          ${escapeHtml(test.name || "Untitled Test")}
        </div>
      </td>

      <td>
        <span class="test-date">
          ${escapeHtml(formatDate(test.date))}
        </span>
      </td>

      <td>
        <span class="subject-score physics-score">
          ${Number(test.physics) || 0}
        </span>
      </td>

      <td>
        <span class="subject-score chemistry-score">
          ${Number(test.chemistry) || 0}
        </span>
      </td>

      <td>
        <span class="subject-score biology-score">
          ${Number(test.biology) || 0}
        </span>
      </td>

      <td>
        <strong class="test-total">
          ${total}
        </strong>
        <span class="test-total-max">/ 720</span>
      </td>

      <td>
        <span class="test-percentage">
          ${Math.round(percentage)}%
        </span>
      </td>

      <td>
        <button
          class="tests-delete-btn"
          type="button"
          data-test-delete="${escapeHtml(test.id)}"
        >
          Delete
        </button>
      </td>
    `;

    tbody.appendChild(tr);
  });


  tbody
    .querySelectorAll("[data-test-delete]")
    .forEach((button) => {

      button.addEventListener("click", () => {

        const id = button.dataset.testDelete;

        const index =
          appData.tests.records.findIndex(
            (test) => test.id === id
          );

        if (index === -1) return;


        appData.tests.records.splice(index, 1);

        saveAppData(appData);

        renderSummary();
        renderRows();
      });

    });
}


/* =========================================================
   MODAL
   ========================================================= */

function openTestModal() {

  $("test-name").value = "";
  $("test-date").value = getToday();

  $("test-physics").value = "";
  $("test-chemistry").value = "";
  $("test-biology").value = "";

  updateTotalPreview();

  $("test-modal").hidden = false;

  setTimeout(() => {
    $("test-name").focus();
  }, 0);
}


function closeTestModal() {
  $("test-modal").hidden = true;
}


/* =========================================================
   TOTAL PREVIEW
   ========================================================= */

function updateTotalPreview() {

  const physics = clampMarks(
    $("test-physics").value,
    180
  );

  const chemistry = clampMarks(
    $("test-chemistry").value,
    180
  );

  const biology = clampMarks(
    $("test-biology").value,
    360
  );

  const total =
    physics +
    chemistry +
    biology;

  $("test-total-preview").textContent =
    `${total} / 720`;
}


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


/* =========================================================
   BUTTONS
   ========================================================= */

$("open-add-test").addEventListener(
  "click",
  openTestModal
);

$("add-test-inline").addEventListener(
  "click",
  openTestModal
);

$("empty-add-test").addEventListener(
  "click",
  openTestModal
);


/* =========================================================
   MODAL CLOSE
   ========================================================= */

$("close-test-modal").addEventListener(
  "click",
  closeTestModal
);

$("cancel-test").addEventListener(
  "click",
  closeTestModal
);


$("test-modal").addEventListener(
  "click",
  (event) => {

    if (event.target === $("test-modal")) {
      closeTestModal();
    }

  }
);


/* =========================================================
   LIVE TOTAL
   ========================================================= */

[
  "test-physics",
  "test-chemistry",
  "test-biology"
].forEach((id) => {

  $(id).addEventListener(
    "input",
    updateTotalPreview
  );

});


/* =========================================================
   ADD TEST
   ========================================================= */

$("test-form").addEventListener(
  "submit",
  (event) => {

    event.preventDefault();

    ensureTestsData();


    const name =
      $("test-name").value.trim();

    const date =
      $("test-date").value;

    const physics =
      clampMarks(
        $("test-physics").value,
        180
      );

    const chemistry =
      clampMarks(
        $("test-chemistry").value,
        180
      );

    const biology =
      clampMarks(
        $("test-biology").value,
        360
      );


    if (!name || !date) {
      return;
    }


    appData.tests.records.push({

      id: createId(),

      name,

      date,

      physics,

      chemistry,

      biology

    });


    saveAppData(appData);

    closeTestModal();

    renderSummary();
    renderRows();

  }
);


/* =========================================================
   INITIAL RENDER
   ========================================================= */

ensureTestsData();

renderSummary();
renderRows();