import { DEFAULT_APP_DATA, DATA_UPDATED_EVENT } from "./data.js";
import { loadAppData } from "./storage.js";
import { updateAppData } from "./events.js";


/* =========================================================
   SETTINGS STATE
   ========================================================= */

let appData = loadAppData();


const $ = (id) => document.getElementById(id);


/* =========================================================
   HELPERS
   ========================================================= */

function clone(value) {
  return structuredClone(value);
}


function showStatus(message) {

  const status = $("settings-status");

  if (!status) {
    return;
  }

  status.textContent = message;

  status.classList.add("show");

  window.clearTimeout(showStatus.timer);

  showStatus.timer = window.setTimeout(() => {
    status.classList.remove("show");
  }, 3200);
}


/* =========================================================
   DATA COUNTS
   ========================================================= */

function getSyllabusCount() {

  const subjects = appData.syllabus?.subjects || {};

  return [
    ...(Array.isArray(subjects.physics) ? subjects.physics : []),
    ...(Array.isArray(subjects.chemistry) ? subjects.chemistry : []),
    ...(Array.isArray(subjects.biology) ? subjects.biology : [])
  ].length;
}


/* =========================================================
   RENDER SETTINGS STATE
   ========================================================= */

function renderState() {

  appData = loadAppData();


  /* -------------------------------------------------------
     PROFILE
     ------------------------------------------------------- */

  const profile = appData.profile || {};

  if ($("settings-profile-name")) {

    $("settings-profile-name").textContent =
      profile.name || "No profile name set";

  }


  /* -------------------------------------------------------
     DATA VERSION
     ------------------------------------------------------- */

  if ($("settings-data-version")) {

    $("settings-data-version").textContent =
      `Schema v${appData.version || 1}`;

  }


  /* -------------------------------------------------------
     STUDY
     ------------------------------------------------------- */

  const studyTasks =
    Array.isArray(appData.study?.tasks)
      ? appData.study.tasks.length
      : 0;

  const studySessions =
    Array.isArray(appData.study?.sessions)
      ? appData.study.sessions.length
      : 0;


  if ($("study-count")) {

    $("study-count").textContent =
      `${studyTasks} task${studyTasks === 1 ? "" : "s"} · ` +
      `${studySessions} session${studySessions === 1 ? "" : "s"}`;

  }


  /* -------------------------------------------------------
     TESTS
     ------------------------------------------------------- */

  const tests =
    Array.isArray(appData.tests?.records)
      ? appData.tests.records.length
      : 0;


  if ($("tests-count")) {

    $("tests-count").textContent =
      `${tests} test${tests === 1 ? "" : "s"} recorded`;

  }


  /* -------------------------------------------------------
     MISTAKES
     ------------------------------------------------------- */

  const mistakes =
    Array.isArray(appData.mistakes?.records)
      ? appData.mistakes.records.length
      : 0;


  if ($("mistakes-count")) {

    $("mistakes-count").textContent =
      `${mistakes} mistake${mistakes === 1 ? "" : "s"} recorded`;

  }


  /* -------------------------------------------------------
     SYLLABUS
     ------------------------------------------------------- */

  const syllabus = getSyllabusCount();


  if ($("syllabus-count")) {

    $("syllabus-count").textContent =
      `${syllabus} chapter${syllabus === 1 ? "" : "s"} configured`;

  }


  /* -------------------------------------------------------
     CALENDAR
     ------------------------------------------------------- */

  const events =
    Array.isArray(appData.calendar?.events)
      ? appData.calendar.events.length
      : 0;


  if ($("calendar-count")) {

    $("calendar-count").textContent =
      `${events} event${events === 1 ? "" : "s"} scheduled`;

  }


  /* -------------------------------------------------------
     PREFERENCES
     ------------------------------------------------------- */

  const theme =
    appData.settings?.theme || "system";

  const notifications =
    appData.settings?.notifications !== false;


  if ($("theme-select")) {

    $("theme-select").value = theme;

  }


  if ($("notifications-toggle")) {

    $("notifications-toggle").checked =
      notifications;

  }

}


/* =========================================================
   RESET SECTION
   ========================================================= */

function resetSection(label, mutate) {

  const confirmed = window.confirm(
    `${label} reset will permanently remove the selected ` +
    `data from this device. Continue?`
  );


  if (!confirmed) {
    return;
  }


  updateAppData(appData, mutate);


  renderState();


  showStatus(`${label} reset complete.`);

}


/* =========================================================
   RESET CONTROLS
   ========================================================= */

function bindResetControls() {


  /* -------------------------------------------------------
     STUDY
     ------------------------------------------------------- */

  $("reset-study")?.addEventListener("click", () => {

    resetSection("Study", (data) => {

      data.study =
        clone(DEFAULT_APP_DATA.study);

    });

  });


  /* -------------------------------------------------------
     TESTS
     ------------------------------------------------------- */

  $("reset-tests")?.addEventListener("click", () => {

    resetSection("Tests", (data) => {

      data.tests =
        clone(DEFAULT_APP_DATA.tests);

    });

  });


  /* -------------------------------------------------------
     MISTAKES
     ------------------------------------------------------- */

  $("reset-mistakes")?.addEventListener("click", () => {

    resetSection("Mistakes", (data) => {

      data.mistakes =
        clone(DEFAULT_APP_DATA.mistakes);

    });

  });


  /* -------------------------------------------------------
     SYLLABUS
     ------------------------------------------------------- */

  $("reset-syllabus")?.addEventListener("click", () => {

    resetSection("Syllabus", (data) => {

      data.syllabus =
        clone(DEFAULT_APP_DATA.syllabus);

    });

  });


  /* -------------------------------------------------------
     CALENDAR
     ------------------------------------------------------- */

  $("reset-calendar")?.addEventListener("click", () => {

    resetSection("Calendar", (data) => {

      data.calendar =
        clone(DEFAULT_APP_DATA.calendar);

    });

  });


  /* -------------------------------------------------------
     COMPLETE APP RESET
     ------------------------------------------------------- */

  $("reset-app")?.addEventListener("click", () => {

    const confirmed = window.confirm(
      "Complete app reset will permanently remove your " +
      "profile, syllabus, study data, tests, mistakes, " +
      "calendar events and settings from this device. " +
      "Continue?"
    );


    if (!confirmed) {
      return;
    }


    updateAppData(appData, (data) => {

      const fresh =
        clone(DEFAULT_APP_DATA);


      Object.keys(data).forEach((key) => {
        delete data[key];
      });


      Object.assign(data, fresh);

    });


    renderState();


    showStatus(
      "Complete app reset complete."
    );

  });

}


/* =========================================================
   PREFERENCES
   ========================================================= */

function bindPreferences() {


  /* -------------------------------------------------------
     THEME
     ------------------------------------------------------- */

  $("theme-select")?.addEventListener(
    "change",
    (event) => {

      updateAppData(appData, (data) => {

        if (!data.settings) {
          data.settings = {};
        }

        data.settings.theme =
          event.target.value;

      });


      showStatus(
        "Appearance preference saved."
      );

    }
  );


  /* -------------------------------------------------------
     NOTIFICATIONS
     ------------------------------------------------------- */

  $("notifications-toggle")?.addEventListener(
    "change",
    (event) => {

      updateAppData(appData, (data) => {

        if (!data.settings) {
          data.settings = {};
        }

        data.settings.notifications =
          Boolean(event.target.checked);

      });


      showStatus(
        "Notification preference saved."
      );

    }
  );

}


/* =========================================================
   INITIALIZE
   ========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  () => {

    renderState();

    bindResetControls();

    bindPreferences();


    /* -----------------------------------------------------
       LIVE DATA REFRESH

       Any source page that updates appData emits:
       neet2027:dataUpdated

       Settings refreshes its displayed state automatically.
       ----------------------------------------------------- */

    window.addEventListener(
      DATA_UPDATED_EVENT,
      (event) => {

        appData =
          event.detail || loadAppData();

        renderState();

      }
    );

  }
);