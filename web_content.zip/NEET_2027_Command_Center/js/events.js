import { saveAppData } from "./storage.js";

export function updateAppData(appData, updater) {
  updater(appData);
  saveAppData(appData);
}
