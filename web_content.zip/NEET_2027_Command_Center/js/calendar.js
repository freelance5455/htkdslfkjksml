import { loadAppData, saveAppData } from "./storage.js";
import { renderShell } from "./components.js";
import { checkProfileAccess } from "./profileGuard.js";

checkProfileAccess();

const appData = loadAppData();

renderShell("calendar");

const $ = (id) => document.getElementById(id);


/* =========================================================
   STATE
   ========================================================= */

const now = new Date();

let currentYear = now.getFullYear();
let currentMonth = now.getMonth();

let selectedDate = getDateString(
  now.getFullYear(),
  now.getMonth(),
  now.getDate()
);


/* =========================================================
   DATA SAFETY
   ========================================================= */

function ensureCalendarData() {

  if (
    !appData.calendar ||
    typeof appData.calendar !== "object"
  ) {
    appData.calendar = {
      events: []
    };
  }

  if (!Array.isArray(appData.calendar.events)) {
    appData.calendar.events = [];
  }
}


/* =========================================================
   DATE HELPERS
   ========================================================= */

function getDateString(year, month, day) {

  const monthText = String(month + 1).padStart(2, "0");
  const dayText = String(day).padStart(2, "0");

  return `${year}-${monthText}-${dayText}`;
}


function getToday() {

  const date = new Date();

  return getDateString(
    date.getFullYear(),
    date.getMonth(),
    date.getDate()
  );
}


function formatDate(dateString) {

  if (!dateString) {
    return "—";
  }

  const date = new Date(
    `${dateString}T00:00:00`
  );

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "long",
    year: "numeric"
  });
}


function formatMonth(month, year) {

  const date = new Date(
    year,
    month,
    1
  );

  return date.toLocaleDateString("en-IN", {
    month: "long"
  });
}


/* =========================================================
   ID
   ========================================================= */

function createId() {

  return `event_${Date.now()}_${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}


/* =========================================================
   EVENT TYPE
   ========================================================= */

function getEventTypeLabel(type) {

  const labels = {
    study: "Study",
    test: "Test",
    revision: "Revision"
  };

  return labels[type] || "Event";
}


/* =========================================================
   CALENDAR HEADER
   ========================================================= */

function renderCalendarHeader() {

  $("calendar-month-title").textContent =
    formatMonth(
      currentMonth,
      currentYear
    );

  $("calendar-year-title").textContent =
    currentYear;
}


/* =========================================================
   CALENDAR GRID
   ========================================================= */

function renderCalendar() {

  ensureCalendarData();

  renderCalendarHeader();

  const grid = $("calendar-grid");

  grid.innerHTML = "";


  const firstDay = new Date(
    currentYear,
    currentMonth,
    1
  ).getDay();


  const daysInMonth = new Date(
    currentYear,
    currentMonth + 1,
    0
  ).getDate();


  const previousMonthDays =
    new Date(
      currentYear,
      currentMonth,
      0
    ).getDate();


  /*
   * Previous month cells
   */

  for (
    let index = firstDay - 1;
    index >= 0;
    index--
  ) {

    const day =
      previousMonthDays - index;

    const date = new Date(
      currentYear,
      currentMonth - 1,
      day
    );

    createDayCell(
      grid,
      date,
      true
    );
  }


  /*
   * Current month cells
   */

  for (
    let day = 1;
    day <= daysInMonth;
    day++
  ) {

    const date = new Date(
      currentYear,
      currentMonth,
      day
    );

    createDayCell(
      grid,
      date,
      false
    );
  }


  /*
   * Next month cells
   */

  const totalCells =
    firstDay + daysInMonth;

  const remainingCells =
    totalCells % 7 === 0
      ? 0
      : 7 - (totalCells % 7);


  for (
    let day = 1;
    day <= remainingCells;
    day++
  ) {

    const date = new Date(
      currentYear,
      currentMonth + 1,
      day
    );

    createDayCell(
      grid,
      date,
      true
    );
  }
}


/* =========================================================
   DAY CELL
   ========================================================= */

function createDayCell(
  container,
  date,
  outsideMonth
) {

  const dateString = getDateString(
    date.getFullYear(),
    date.getMonth(),
    date.getDate()
  );


  const cell = document.createElement("button");

  cell.type = "button";

  cell.className =
    "calendar-day";


  if (outsideMonth) {
    cell.classList.add(
      "calendar-day-outside"
    );
  }


  if (dateString === getToday()) {
    cell.classList.add(
      "calendar-day-today"
    );
  }


  if (dateString === selectedDate) {
    cell.classList.add(
      "calendar-day-selected"
    );
  }


  const events =
    appData.calendar.events.filter(
      (event) =>
        event.date === dateString
    );


  cell.innerHTML = `
    <span class="calendar-day-number">
      ${date.getDate()}
    </span>

    ${
      events.length
        ? `
          <span class="calendar-event-count">
            ${events.length}
          </span>
        `
        : ""
    }

    ${
      events.length
        ? `
          <span class="calendar-day-dots">
            ${events
              .slice(0, 3)
              .map(
                (event) => `
                  <span
                    class="calendar-event-dot
                    calendar-event-dot-${escapeHtml(
                      event.type || "study"
                    )}"
                  ></span>
                `
              )
              .join("")}
          </span>
        `
        : ""
    }
  `;


  cell.addEventListener(
    "click",
    () => {

      selectedDate = dateString;

      renderCalendar();
      renderSelectedDay();
    }
  );


  container.appendChild(cell);
}


/* =========================================================
   SELECTED DAY
   ========================================================= */

function renderSelectedDay() {

  ensureCalendarData();

  const events =
    appData.calendar.events.filter(
      (event) =>
        event.date === selectedDate
    );


  $("selected-date-title").textContent =
    formatDate(selectedDate);


  $("selected-date-subtitle").textContent =
    events.length
      ? `${events.length} event${
          events.length === 1
            ? ""
            : "s"
        } scheduled`
      : "No events scheduled for this day.";


  const container =
    $("calendar-event-list");

  const empty =
    $("calendar-empty");


  container.innerHTML = "";

  empty.hidden =
    events.length > 0;


  events.forEach((event) => {

    const item =
      document.createElement("article");


    item.className =
      "calendar-event-item";


    item.innerHTML = `
      <div class="
        calendar-event-type
        calendar-event-type-${escapeHtml(
          event.type || "study"
        )}
      ">
        ${escapeHtml(
          getEventTypeLabel(
            event.type
          )
        )}
      </div>

      <div class="calendar-event-main">

        <strong>
          ${escapeHtml(
            event.title || "Untitled Event"
          )}
        </strong>

        ${
          event.notes
            ? `
              <p>
                ${escapeHtml(
                  event.notes
                )}
              </p>
            `
            : ""
        }

      </div>

      <button
        class="calendar-delete-btn"
        type="button"
        data-event-delete="${escapeHtml(
          event.id
        )}"
      >
        Delete
      </button>
    `;


    container.appendChild(item);
  });


  container
    .querySelectorAll(
      "[data-event-delete]"
    )
    .forEach((button) => {

      button.addEventListener(
        "click",
        () => {

          const id =
            button.dataset.eventDelete;


          const index =
            appData.calendar.events.findIndex(
              (event) =>
                event.id === id
            );


          if (index === -1) {
            return;
          }


          appData.calendar.events.splice(
            index,
            1
          );


          saveAppData(appData);

          renderCalendar();
          renderSelectedDay();
        }
      );
    });
}


/* =========================================================
   MODAL
   ========================================================= */

function openModal(date = selectedDate) {

  $("event-title").value = "";

  $("event-date").value =
    date || getToday();

  $("event-type").value =
    "study";

  $("event-notes").value = "";


  $("event-modal").hidden = false;


  setTimeout(() => {

    $("event-title").focus();

  }, 0);
}


function closeModal() {

  $("event-modal").hidden = true;
}


/* =========================================================
   NAVIGATION
   ========================================================= */

$("previous-month").addEventListener(
  "click",
  () => {

    currentMonth--;

    if (currentMonth < 0) {

      currentMonth = 11;
      currentYear--;
    }

    renderCalendar();
  }
);


$("next-month").addEventListener(
  "click",
  () => {

    currentMonth++;

    if (currentMonth > 11) {

      currentMonth = 0;
      currentYear++;
    }

    renderCalendar();
  }
);


$("calendar-today").addEventListener(
  "click",
  () => {

    const today = new Date();

    currentYear =
      today.getFullYear();

    currentMonth =
      today.getMonth();

    selectedDate =
      getToday();

    renderCalendar();
    renderSelectedDay();
  }
);


/* =========================================================
   OPEN MODALS
   ========================================================= */

$("open-add-event").addEventListener(
  "click",
  () => openModal()
);


$("add-event-for-selected")
  .addEventListener(
    "click",
    () => openModal(
      selectedDate
    )
  );


$("empty-add-event")
  .addEventListener(
    "click",
    () => openModal(
      selectedDate
    )
  );


/* =========================================================
   CLOSE MODAL
   ========================================================= */

$("close-event-modal")
  .addEventListener(
    "click",
    closeModal
  );


$("cancel-event")
  .addEventListener(
    "click",
    closeModal
);


$("event-modal")
  .addEventListener(
    "click",
    (event) => {

      if (
        event.target ===
        $("event-modal")
      ) {

        closeModal();
      }
    }
  );


/* =========================================================
   FORM
   ========================================================= */

$("event-form")
  .addEventListener(
    "submit",
    (event) => {

      event.preventDefault();

      ensureCalendarData();


      const title =
        $("event-title")
          .value
          .trim();


      const date =
        $("event-date").value;


      const type =
        $("event-type").value;


      const notes =
        $("event-notes")
          .value
          .trim();


      if (!title || !date) {
        return;
      }


      appData.calendar.events.push({
        id: createId(),
        title,
        date,
        type,
        notes
      });


      selectedDate = date;


      const selected =
        new Date(
          `${date}T00:00:00`
        );


      if (
        !Number.isNaN(
          selected.getTime()
        )
      ) {

        currentYear =
          selected.getFullYear();

        currentMonth =
          selected.getMonth();
      }


      saveAppData(appData);

      closeModal();

      renderCalendar();
      renderSelectedDay();
    }
  );


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHtml(value) {

  return String(value ?? "")
    .replaceAll(
      "&",
      "&amp;"
    )
    .replaceAll(
      "<",
      "&lt;"
    )
    .replaceAll(
      ">",
      "&gt;"
    )
    .replaceAll(
      '"',
      "&quot;"
    )
    .replaceAll(
      "'",
      "&#039;"
    );
}


/* =========================================================
   INITIAL RENDER
   ========================================================= */

ensureCalendarData();

renderCalendar();

renderSelectedDay();


/* =========================================================
   DATA UPDATE
   ========================================================= */

window.addEventListener(
  "neet2027:dataUpdated",
  () => {
    window.location.reload();
  }
);