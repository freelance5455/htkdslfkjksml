const NAV_ITEMS = [
  { label: "Dashboard", href: "index.html", icon: "⌂", root: true },
  { label: "Study", href: "pages/study.html", icon: "◷" },
  { label: "Syllabus", href: "pages/syllabus.html", icon: "▤" },
  { label: "Tests", href: "pages/tests.html", icon: "✓" },
  { label: "Mistakes", href: "pages/mistakes.html", icon: "!" },
  { label: "Analytics", href: "pages/analytics.html", icon: "◔" },
  { label: "Calendar", href: "pages/calendar.html", icon: "□" },
  { label: "Profile", href: "pages/profile.html", icon: "●" },
  { label: "Settings", href: "pages/settings.html", icon: "⚙" }
];

function isPageDirectory() {
  return window.location.pathname.replaceAll("\\", "/").includes("/pages/");
}

function resolveHref(href) {
  return isPageDirectory() ? `../${href}` : href;
}

function currentPage() {
  const file = window.location.pathname.split("/").pop() || "index.html";
  return file;
}

export function renderShell() {
  const mount = document.getElementById("app-shell");
  if (!mount) return;

  const current = currentPage();

  const nav = NAV_ITEMS.map(item => {
    const target = resolveHref(item.href);
    const active = item.root
      ? current === "index.html"
      : current === item.href.split("/").pop();

    return `
      <a class="nav-link ${active ? "active" : ""}" href="${target}">
        <span class="nav-icon">${item.icon}</span>
        <span>${item.label}</span>
      </a>
    `;
  }).join("");

  mount.innerHTML = `
    <div class="mobile-header">
      <div class="brand">
        <div class="brand-mark">N</div>
        <div>
          <strong>NEET 2027</strong>
          <small>Command Center</small>
        </div>
      </div>
      <button class="menu-button" id="menu-button" aria-label="Open navigation">☰</button>
    </div>

    <div class="mobile-overlay" id="mobile-overlay"></div>

    <aside class="app-sidebar" id="app-sidebar">
      <div class="brand">
        <div class="brand-mark">N</div>
        <div>
          <strong>NEET 2027</strong>
          <small>Personal Preparation</small>
        </div>
      </div>

      <div class="nav-label">Command Center</div>
      <nav class="app-nav" aria-label="Primary navigation">
        ${nav}
      </nav>

      <div class="sidebar-footer">
        <strong>Dream → Prepare → Achieve</strong>
        <span>Your preparation, your journey.</span>
      </div>
    </aside>
  `;

  const button = document.getElementById("menu-button");
  const sidebar = document.getElementById("app-sidebar");
  const overlay = document.getElementById("mobile-overlay");

  const close = () => {
    sidebar?.classList.remove("open");
    overlay?.classList.remove("show");
  };

  button?.addEventListener("click", () => {
    sidebar?.classList.toggle("open");
    overlay?.classList.toggle("show");
  });

  overlay?.addEventListener("click", close);
  sidebar?.querySelectorAll("a").forEach(link => link.addEventListener("click", close));
}