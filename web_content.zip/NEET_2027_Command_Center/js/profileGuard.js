// =========================================================
// PROFILE ACCESS GUARD
// NEET 2027 Command Center
// =========================================================

import { loadAppData } from "./storage.js";

const PROTECTED_PAGES = new Set([
  "index.html",
  "study.html",
  "syllabus.html",
  "tests.html",
  "mistakes.html",
  "analytics.html",
  "calendar.html"
]);

function getCurrentPage() {
  return (
    window.location.pathname.split("/").pop() ||
    "index.html"
  );
}

function isProfileCompleted() {
  const appData = loadAppData();

  return appData?.profile?.completed === true;
}

function getProfileUrl() {
  const isInsidePagesFolder =
    window.location.pathname
      .replaceAll("\\", "/")
      .includes("/pages/");

  return isInsidePagesFolder
    ? "profile.html"
    : "pages/profile.html";
}

function createProfileAccessNotification() {
  // Already present
  if (document.getElementById("profile-access-overlay")) {
    return;
  }

  const overlay = document.createElement("div");

  overlay.id = "profile-access-overlay";

  overlay.innerHTML = `
    <div class="profile-access-modal">

      <div class="profile-access-icon">
        N
      </div>

      <div class="profile-access-eyebrow">
        NEET 2027 • COMMAND CENTER
      </div>

      <h2>
        Your preparation starts here.
      </h2>

      <p>
        Create your preparation profile or login to
        access your personal Command Center data.
      </p>

      <div class="profile-access-actions">

        <button
          type="button"
          class="profile-access-btn primary"
          id="profile-create-btn"
        >
          <span>Create Profile</span>
          <span class="arrow">→</span>
        </button>

        <button
          type="button"
          class="profile-access-btn secondary"
          id="profile-login-btn"
        >
          <span>Login</span>
          <span class="arrow">→</span>
        </button>

      </div>

      <div class="profile-access-note">
        Your study data stays connected to your account.
      </div>

    </div>
  `;

  document.body.appendChild(overlay);

  document.body.classList.add(
    "profile-access-locked"
  );


  // CREATE PROFILE
  document
    .getElementById("profile-create-btn")
    ?.addEventListener("click", () => {

      sessionStorage.setItem(
        "neet2027_profile_mode",
        "create"
      );

      window.location.href =
        getProfileUrl();

    });


  // LOGIN
  document
    .getElementById("profile-login-btn")
    ?.addEventListener("click", () => {

      sessionStorage.setItem(
        "neet2027_profile_mode",
        "login"
      );

      window.location.href =
        getProfileUrl();

    });
}


export function checkProfileAccess() {

  const currentPage =
    getCurrentPage();


  // Profile और Settings तथा
  // बाकी non-protected pages पर कुछ नहीं करना.
  if (
    !PROTECTED_PAGES.has(currentPage)
  ) {
    return true;
  }


  // Logged-in / completed profile
  if (isProfileCompleted()) {
    return true;
  }


  // Account नहीं है → current page पर notification
  createProfileAccessNotification();

  return false;
}