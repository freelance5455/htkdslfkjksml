import {
  loadAppData,
  saveAppData,
  createAccount,
  loginAccount,
  logoutAccount,
  isLoggedIn
} from "./storage.js";

import { renderShell } from "./components.js";


let appData = loadAppData();

const $ = id => document.getElementById(id);

let accountMode = "create";


/* ============================================================
   HELPERS
============================================================ */

function valueOrNull(value) {
  return value === ""
    ? null
    : Number(value);
}


/* ============================================================
   PROFILE FORM
============================================================ */

function fillForm() {
  appData = loadAppData();

  const p = appData.profile || {};

  $("name").value =
    p.name || "";

  $("examYear").value =
    2027;

  $("targetScore").value =
    p.targetScore ?? "";

  $("targetRank").value =
    p.targetRank ?? "";

  $("dreamCollege").value =
    p.dreamCollege || "";

  $("preparationMode").value =
    p.preparationMode || "";

  $("startDate").value =
    p.startDate || "";

  if ($("accountIdentifier")) {
    $("accountIdentifier").value =
      p.accountIdentifier || "";
  }

  renderPreview();
}


/* ============================================================
   PROFILE PREVIEW
============================================================ */

function renderPreview() {
  const p = appData.profile || {};

  const name =
    p.name || "Your Name";

  $("avatar").textContent =
    name.trim().charAt(0).toUpperCase() || "N";

  $("preview-name").textContent =
    name;

  $("preview-mode").textContent =
    p.preparationMode ||
    "Preparation mode not set";

  $("preview-score").textContent =
    p.targetScore != null
      ? `${p.targetScore}+`
      : "—";

  $("preview-rank").textContent =
    p.targetRank != null
      ? `#${p.targetRank}`
      : "—";

  $("preview-college").textContent =
    p.dreamCollege || "—";
}


/* ============================================================
   ACCOUNT STATUS
============================================================ */

function setAccountStatus(
  message,
  type = ""
) {
  const status =
    $("account-status");

  if (!status) return;

  status.textContent =
    message;

  status.className =
    "account-status";

  if (type) {
    status.classList.add(type);
  }
}


/* ============================================================
   ACCOUNT MODE
============================================================ */

function setAccountMode(mode) {
  accountMode = mode;

  const createTab =
    $("create-tab");

  const loginTab =
    $("login-tab");

  const actionButton =
    $("account-action");

  const title =
    $("account-title");

  const passwordField =
    $("password-field");

  if (!createTab || !loginTab) {
    return;
  }

  createTab.classList.toggle(
    "active",
    mode === "create"
  );

  loginTab.classList.toggle(
    "active",
    mode === "login"
  );

  if (mode === "create") {

    title.textContent =
      "Create your preparation account";

    actionButton.textContent =
      "Create Profile";

    passwordField.classList.remove(
      "hidden"
    );

    setAccountStatus("");

  } else {

    title.textContent =
      "Welcome back";

    actionButton.textContent =
      "Login";

    passwordField.classList.remove(
      "hidden"
    );

    setAccountStatus("");
  }
}


/* ============================================================
   ACCOUNT UI STATE
============================================================ */

function renderAccountState() {

  /*
    IMPORTANT:
    We check the SESSION,
    not just profile.accountCreated.
  */

  if (isLoggedIn()) {

    const p =
      appData.profile || {};

    $("account-badge")
      ?.classList.remove("hidden");

    $("account-title").textContent =
      "Your preparation account";

    $("accountIdentifier").value =
      p.accountIdentifier || "";

    $("accountIdentifier").disabled =
      true;

    $("account-action")
      ?.classList.add("hidden");

    $("logout-button")
      ?.classList.remove("hidden");

    $("create-tab")
      ?.classList.add("hidden");

    $("login-tab")
      ?.classList.add("hidden");

    setAccountStatus(
      "Account is active on this browser.",
      "success"
    );

    return;
  }


  /*
    LOGGED OUT STATE
  */

  $("account-badge")
    ?.classList.add("hidden");

  $("accountIdentifier").disabled =
    false;

  $("accountAction")
    ?.classList.remove("hidden");

  $("account-action")
    ?.classList.remove("hidden");

  $("logout-button")
    ?.classList.add("hidden");

  $("create-tab")
    ?.classList.remove("hidden");

  $("login-tab")
    ?.classList.remove("hidden");

  setAccountMode("create");
}


/* ============================================================
   COLLECT PROFILE
============================================================ */

function collectProfileData() {

  return {
    completed: true,

    name:
      $("name").value.trim(),

    examYear:
      2027,

    targetScore:
      valueOrNull(
        $("targetScore").value
      ),

    targetRank:
      valueOrNull(
        $("targetRank").value
      ),

    dreamCollege:
      $("dreamCollege").value.trim(),

    preparationMode:
      $("preparationMode").value,

    startDate:
      $("startDate").value || null
  };
}


/* ============================================================
   CREATE ACCOUNT
============================================================ */

function handleCreateAccount() {

  const identifier =
    $("accountIdentifier")
      .value
      .trim();

  const password =
    $("accountPassword")
      .value;

  if (!identifier) {

    setAccountStatus(
      "Please enter your email or mobile number.",
      "error"
    );

    return;
  }

  if (
    !password ||
    password.length < 6
  ) {

    setAccountStatus(
      "Password must contain at least 6 characters.",
      "error"
    );

    return;
  }


  const profile =
    collectProfileData();


  if (!profile.name) {

    setAccountStatus(
      "Please enter your full name first.",
      "error"
    );

    return;
  }


  const result =
    createAccount({
      identifier,
      password,
      profile
    });


  if (!result.success) {

    if (result.reason === "exists") {

      setAccountStatus(
        "This account already exists. Please login.",
        "error"
      );

      setAccountMode("login");

      return;
    }

    setAccountStatus(
      "Account could not be created.",
      "error"
    );

    return;
  }


  /*
    Account created + automatically logged in
  */

  appData =
    result.data;

  $("accountPassword").value =
    "";

  $("save-status").textContent =
    "Saved ✓";

  $("save-status")
    .classList.add("saved");

  setAccountStatus(
    "Profile created successfully.",
    "success"
  );

  renderPreview();
  renderAccountState();

  setTimeout(() => {
    $("save-status").textContent =
      "Saved";
  }, 1800);
}


/* ============================================================
   LOGIN
============================================================ */

function handleLogin() {

  const identifier =
    $("accountIdentifier")
      .value
      .trim();

  const password =
    $("accountPassword")
      .value;


  if (!identifier) {

    setAccountStatus(
      "Please enter your email or mobile number.",
      "error"
    );

    return;
  }


  if (!password) {

    setAccountStatus(
      "Please enter your password.",
      "error"
    );

    return;
  }


  const result =
    loginAccount({
      identifier,
      password
    });


  if (!result.success) {

    if (result.reason === "not_found") {

      setAccountStatus(
        "No account found. Please create your profile first.",
        "error"
      );

      return;
    }


    if (
      result.reason ===
      "password_unavailable"
    ) {

      setAccountStatus(
        "This old account needs to be created again because its password was not saved.",
        "error"
      );

      return;
    }


    if (
      result.reason ===
      "wrong_password"
    ) {

      setAccountStatus(
        "Incorrect password.",
        "error"
      );

      return;
    }


    setAccountStatus(
      "Login failed.",
      "error"
    );

    return;
  }


  /*
    VERY IMPORTANT:

    Login loads the SAME account data.
  */

  appData =
    result.data;


  $("accountPassword").value =
    "";

  $("save-status").textContent =
    "Logged in ✓";

  $("save-status")
    .classList.add("saved");


  setAccountStatus(
    "Login successful. Your preparation data is back.",
    "success"
  );


  fillForm();
  renderAccountState();


  setTimeout(() => {
    $("save-status").textContent =
      "Saved";
  }, 1800);
}


/* ============================================================
   LOGOUT
============================================================ */

function handleLogout() {

  const confirmed =
    window.confirm(
      "Logout from this preparation account?"
    );

  if (!confirmed) {
    return;
  }


  /*
    ONLY SESSION IS REMOVED.
    USER DATA STAYS SAFE.
  */

  logoutAccount();


  /*
    Now loadAppData() returns empty/default
    data because nobody is logged in.
  */

  appData =
    loadAppData();


  $("accountIdentifier").value =
    "";

  $("accountPassword").value =
    "";


  /*
    Clear visible profile fields
    because user is logged out.
  */

  $("name").value =
    "";

  $("examYear").value =
    "2027";

  $("targetScore").value =
    "";

  $("targetRank").value =
    "";

  $("dreamCollege").value =
    "";

  $("preparationMode").value =
    "";

  $("startDate").value =
    "";


  /*
    Reset preview
  */

  $("avatar").textContent =
    "N";

  $("preview-name").textContent =
    "Your Name";

  $("preview-mode").textContent =
    "Preparation mode not set";

  $("preview-score").textContent =
    "—";

  $("preview-rank").textContent =
    "—";

  $("preview-college").textContent =
    "—";


  $("save-status").textContent =
    "Logged out";


  setAccountStatus(
    "You are logged out. Your account data is saved."
  );


  renderAccountState();
}


/* ============================================================
   SAVE PROFILE
============================================================ */

$("profile-form")
  .addEventListener(
    "submit",
    event => {

      event.preventDefault();


      /*
        Profile cannot be saved without login.
      */

      if (!isLoggedIn()) {

        setAccountStatus(
          "Please create an account or login first.",
          "error"
        );

        return;
      }


      appData =
        loadAppData();


      appData.profile = {
        ...appData.profile,
        ...collectProfileData()
      };


      saveAppData(appData);


      $("save-status").textContent =
        "Saved ✓";

      $("save-status")
        .classList.add("saved");


      renderPreview();


      setTimeout(() => {

        $("save-status").textContent =
          "Saved";

      }, 1800);
    }
  );


/* ============================================================
   PREVIEW LIVE UPDATE
============================================================ */

[
  "name",
  "targetScore",
  "targetRank",
  "dreamCollege",
  "preparationMode",
  "startDate"
].forEach(id => {

  $(id)?.addEventListener(
    "input",
    renderPreview
  );

});


/* ============================================================
   ACCOUNT BUTTONS
============================================================ */

$("create-tab")
  ?.addEventListener(
    "click",
    () => setAccountMode("create")
  );


$("login-tab")
  ?.addEventListener(
    "click",
    () => setAccountMode("login")
  );


$("account-action")
  ?.addEventListener(
    "click",
    () => {

      if (
        accountMode ===
        "create"
      ) {
        handleCreateAccount();
      } else {
        handleLogin();
      }

    }
  );


$("logout-button")
  ?.addEventListener(
    "click",
    handleLogout
  );


/* ============================================================
   INITIALIZE
============================================================ */

document.addEventListener(
  "DOMContentLoaded",
  () => {

    renderShell();

    appData = loadAppData();

    fillForm();

    renderAccountState();

    const requestedMode =
      sessionStorage.getItem(
        "neet2027_profile_mode"
      );

    if (requestedMode === "login") {

      setAccountMode("login");

    } else if (requestedMode === "create") {

      setAccountMode("create");
    }

    sessionStorage.removeItem(
      "neet2027_profile_mode"
    );
  }
);