// SINGLE CALCULATION ENGINE
// All shared formulas belong here. Source pages should not duplicate formulas.

export function calculateTestTotal(test) {
  return (Number(test.physics) || 0)
    + (Number(test.chemistry) || 0)
    + (Number(test.biology) || 0);
}

export function calculatePercentage(score) {
  return ((Number(score) || 0) / 720) * 100;
}

export function calculateSyllabusProgress(chapters = []) {
  if (!chapters.length) return null;

  const totalChecks = chapters.length * 4;
  const completedChecks = chapters.reduce((sum, chapter) => {
    return sum
      + Number(Boolean(chapter.lecture))
      + Number(Boolean(chapter.ncert))
      + Number(Boolean(chapter.questions))
      + Number(Boolean(chapter.revision));
  }, 0);

  return (completedChecks / totalChecks) * 100;
}
export function calculateStudyHours(appData, date = null) {
  const tasks = Array.isArray(appData?.study?.tasks)
    ? appData.study.tasks
    : [];

  const sessions = Array.isArray(appData?.study?.sessions)
    ? appData.study.sessions
    : [];

  const matchesDate = (item) => {
    if (!date) return true;
    return !item.date || item.date === date;
  };

  const taskMinutes = tasks
    .filter((task) => matchesDate(task))
    .reduce((sum, task) => {
      const plannedMinutes =
        (Number(task.duration) || 0) * 60;

      const focusMinutes =
        Number(task.focusTime) || 0;

      if (task.completed) {
        return sum + plannedMinutes;
      }

      return sum + Math.min(focusMinutes, plannedMinutes);
    }, 0);

  const sessionMinutes = sessions
    .filter((session) => matchesDate(session))
    .reduce((sum, session) => {
      return sum + ((Number(session.duration) || 0) * 60);
    }, 0);

  return (taskMinutes + sessionMinutes) / 60;
}