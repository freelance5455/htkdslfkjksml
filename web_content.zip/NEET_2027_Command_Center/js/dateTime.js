// =========================================================
// CENTRAL LIVE DATE + TIME SYSTEM
// INDIA TIME — Asia/Kolkata
// =========================================================

const IST_TIME_ZONE = "Asia/Kolkata";

const istDateTimeFormatter = new Intl.DateTimeFormat("en-IN", {
  timeZone: IST_TIME_ZONE,
  day: "2-digit",
  month: "short",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hour12: true
});

const istPartsFormatter = new Intl.DateTimeFormat("en-IN", {
  timeZone: IST_TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  hour12: false
});


function getParts(date = new Date()) {
  const parts = istPartsFormatter.formatToParts(date);
  const result = {};

  for (const part of parts) {
    if (part.type !== "literal") {
      result[part.type] = part.value;
    }
  }

  return result;
}


/* =========================================================
   IST HOUR
   ========================================================= */

export function getISTHour(date = new Date()) {
  return Number(getParts(date).hour);
}


/* =========================================================
   IST DATE KEY
   ========================================================= */

export function getISTDateKey(date = new Date()) {
  const parts = getParts(date);

  return `${parts.year}-${parts.month}-${parts.day}`;
}


/* =========================================================
   PREVIOUS DATE
   ========================================================= */

export function previousDateKey(dateKey) {
  const date = new Date(`${dateKey}T00:00:00Z`);

  if (Number.isNaN(date.getTime())) {
    return dateKey;
  }

  date.setUTCDate(date.getUTCDate() - 1);

  return [
    date.getUTCFullYear(),
    String(date.getUTCMonth() + 1).padStart(2, "0"),
    String(date.getUTCDate()).padStart(2, "0")
  ].join("-");
}


/* =========================================================
   TIME-BASED ICON
   =========================================================

   12:00 AM → 10:59 AM  ☀️
   11:00 AM → 05:59 PM  🌞
   06:00 PM → 07:59 PM  🌗
   08:00 PM → 11:59 PM  🌙
   ========================================================= */

export function getTimeIcon(date = new Date()) {
  const hour = getISTHour(date);

  if (hour < 11) {
    return "☀️";
  }

  if (hour < 18) {
    return "🌞";
  }

  if (hour < 20) {
    return "🌗";
  }

  return "🌙";
}


/* =========================================================
   FORMAT
   =========================================================

   Example:

   ☀️ 22 SEP 2026 · 10:45:32 AM
   🌞 22 SEP 2026 · 01:18:42 PM
   🌗 22 SEP 2026 · 06:18:42 PM
   🌙 22 SEP 2026 · 09:18:42 PM

   No IST / Kolkata text is displayed.
   ========================================================= */

export function formatLiveDateTime(date = new Date()) {
  const parts = istDateTimeFormatter.formatToParts(date);
  const values = {};

  for (const part of parts) {
    if (part.type !== "literal") {
      values[part.type] = part.value;
    }
  }

  const month = String(values.month || "").toUpperCase();
  const icon = getTimeIcon(date);

  return `${icon} ${values.day} ${month} ${values.year} · ${values.hour}:${values.minute}:${values.second} ${values.dayPeriod}`;
}


/* =========================================================
   START LIVE CLOCK
   ========================================================= */

export function startLiveDateTime() {

  const update = () => {
    const now = new Date();
    const formatted = formatLiveDateTime(now);

    document
      .querySelectorAll("#today-date, .live-date-time")
      .forEach(element => {
        element.textContent = formatted;
      });
  };


  // First render immediately
  update();


  // Align update with the next second
  const delay = 1000 - new Date().getMilliseconds();


  window.setTimeout(() => {

    update();

    window.setInterval(update, 1000);

  }, delay);
}