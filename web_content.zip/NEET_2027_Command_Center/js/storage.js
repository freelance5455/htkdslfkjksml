import {
  DEFAULT_APP_DATA,
  STORAGE_KEY,
  DATA_UPDATED_EVENT
} from "./data.js";

/*
  ============================================================
  NEET 2027 COMMAND CENTER
  Account + Session Storage Layer
  ============================================================

  Structure inside localStorage:

  {
    version: 1,

    session: {
      loggedIn: true,
      userId: "..."
    },

    accounts: {
      "user-id": {
        identifier: "...",
        password: "...",
        data: {
          profile: {},
          syllabus: {},
          study: {},
          tests: {},
          mistakes: {},
          calendar: {},
          settings: {}
        }
      }
    }
  }

  NOTE:
  This is a frontend prototype.
  Passwords are NOT securely encrypted here.
  Real production authentication should use a backend.
*/


/* ============================================================
   HELPERS
============================================================ */

function cloneDefaultData() {
  return structuredClone(DEFAULT_APP_DATA);
}

function createUserId() {
  const random =
    crypto?.randomUUID?.() ||
    `user_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

  return random;
}

function mergeDefaults(defaults, saved) {
  if (!saved || typeof saved !== "object") {
    return defaults;
  }

  for (const key of Object.keys(defaults)) {
    if (saved[key] !== undefined) {

      if (
        defaults[key] &&
        typeof defaults[key] === "object" &&
        !Array.isArray(defaults[key]) &&
        typeof saved[key] === "object" &&
        !Array.isArray(saved[key])
      ) {
        defaults[key] = mergeDefaults(
          defaults[key],
          saved[key]
        );
      } else {
        defaults[key] = saved[key];
      }
    }
  }

  return defaults;
}


/* ============================================================
   STORE
============================================================ */

function readStore() {
  const raw = localStorage.getItem(STORAGE_KEY);

  if (!raw) {
    return {
      version: 1,
      session: {
        loggedIn: false,
        userId: null
      },
      accounts: {}
    };
  }

  try {
    const parsed = JSON.parse(raw);

    /*
      If this is the NEW account-based structure
    */
    if (
      parsed &&
      parsed.session &&
      parsed.accounts
    ) {
      return parsed;
    }

    /*
      OLD VERSION MIGRATION

      Earlier version stored profile directly.

      We keep it as an account instead of immediately
      destroying it.
    */
    const oldData = mergeDefaults(
      cloneDefaultData(),
      parsed
    );

    if (
      oldData.profile?.accountCreated &&
      oldData.profile?.accountIdentifier
    ) {
      const migratedUserId = createUserId();

      return {
        version: 1,

        session: {
          loggedIn: false,
          userId: null
        },

        accounts: {
          [migratedUserId]: {
            identifier: oldData.profile.accountIdentifier,
            password: "",
            data: oldData
          }
        }
      };
    }

    return {
      version: 1,

      session: {
        loggedIn: false,
        userId: null
      },

      accounts: {}
    };

  } catch {
    return {
      version: 1,

      session: {
        loggedIn: false,
        userId: null
      },

      accounts: {}
    };
  }
}


function writeStore(store) {
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(store)
  );
}


/* ============================================================
   CURRENT APP DATA
============================================================ */

export function loadAppData() {
  const store = readStore();

  /*
    No logged-in user
  */
  if (
    !store.session ||
    !store.session.loggedIn ||
    !store.session.userId
  ) {
    return cloneDefaultData();
  }

  const account =
    store.accounts?.[store.session.userId];

  /*
    Session points to missing account
  */
  if (!account) {
    return cloneDefaultData();
  }

  return mergeDefaults(
    cloneDefaultData(),
    account.data
  );
}


/* ============================================================
   SAVE CURRENT USER DATA
============================================================ */

export function saveAppData(appData) {
  const store = readStore();

  /*
    Don't save personal data when nobody is logged in.
  */
  if (
    !store.session ||
    !store.session.loggedIn ||
    !store.session.userId
  ) {
    return false;
  }

  const userId = store.session.userId;

  if (!store.accounts[userId]) {
    return false;
  }

  store.accounts[userId].data = mergeDefaults(
    cloneDefaultData(),
    appData
  );

  writeStore(store);

  window.dispatchEvent(
    new CustomEvent(DATA_UPDATED_EVENT, {
      detail: appData
    })
  );

  return true;
}


/* ============================================================
   CREATE ACCOUNT
============================================================ */

export function createAccount({
  identifier,
  password,
  profile
}) {
  const store = readStore();

  const cleanIdentifier =
    identifier.trim().toLowerCase();

  /*
    Check duplicate account
  */
  const existingEntry =
    Object.entries(store.accounts).find(
      ([, account]) =>
        account.identifier === cleanIdentifier
    );

  if (existingEntry) {
    return {
      success: false,
      reason: "exists"
    };
  }

  const userId = createUserId();

  const accountData = mergeDefaults(
    cloneDefaultData(),
    {
      ...cloneDefaultData(),
      profile: {
        ...cloneDefaultData().profile,
        ...profile,

        completed: true,
        accountCreated: true,
        accountType:
          cleanIdentifier.includes("@")
            ? "email"
            : "mobile",

        accountIdentifier:
          cleanIdentifier
      }
    }
  );

  store.accounts[userId] = {
    identifier: cleanIdentifier,
    password,
    data: accountData
  };

  /*
    Automatically login after account creation
  */
  store.session = {
    loggedIn: true,
    userId
  };

  writeStore(store);

  window.dispatchEvent(
    new CustomEvent(DATA_UPDATED_EVENT, {
      detail: accountData
    })
  );

  return {
    success: true,
    userId,
    data: accountData
  };
}


/* ============================================================
   LOGIN
============================================================ */

export function loginAccount({
  identifier,
  password
}) {
  const store = readStore();

  const cleanIdentifier =
    identifier.trim().toLowerCase();

  const entry =
    Object.entries(store.accounts).find(
      ([, account]) =>
        account.identifier === cleanIdentifier
    );

  if (!entry) {
    return {
      success: false,
      reason: "not_found"
    };
  }

  const [userId, account] = entry;

  /*
    Old migrated accounts may not have a password.
  */
  if (!account.password) {
    return {
      success: false,
      reason: "password_unavailable"
    };
  }

  if (account.password !== password) {
    return {
      success: false,
      reason: "wrong_password"
    };
  }

  store.session = {
    loggedIn: true,
    userId
  };

  writeStore(store);

  const data = mergeDefaults(
    cloneDefaultData(),
    account.data
  );

  window.dispatchEvent(
    new CustomEvent(DATA_UPDATED_EVENT, {
      detail: data
    })
  );

  return {
    success: true,
    userId,
    data
  };
}


/* ============================================================
   LOGOUT
============================================================ */

export function logoutAccount() {
  const store = readStore();

  /*
    IMPORTANT:
    We ONLY remove the session.

    Account data remains untouched.
  */

  store.session = {
    loggedIn: false,
    userId: null
  };

  writeStore(store);

  window.dispatchEvent(
    new CustomEvent(DATA_UPDATED_EVENT, {
      detail: cloneDefaultData()
    })
  );

  return true;
}


/* ============================================================
   SESSION CHECK
============================================================ */

export function isLoggedIn() {
  const store = readStore();

  return Boolean(
    store.session?.loggedIn &&
    store.session?.userId &&
    store.accounts?.[store.session.userId]
  );
}


/* ============================================================
   CURRENT USER ID
============================================================ */

export function getCurrentUserId() {
  const store = readStore();

  if (!isLoggedIn()) {
    return null;
  }

  return store.session.userId;
}


/* ============================================================
   CURRENT ACCOUNT
============================================================ */

export function getCurrentAccount() {
  const store = readStore();

  if (!isLoggedIn()) {
    return null;
  }

  const userId = store.session.userId;

  return store.accounts[userId] || null;
}