import { loadAppData } from "./storage.js";
import { renderShell } from "./components.js";
import {
  calculateTestTotal,
  calculatePercentage,
  calculateSyllabusProgress
} from "./calculations.js";


/* =========================================================
   INITIAL DATA
   ========================================================= */

const appData = loadAppData();

renderShell("analytics");

const $ = (id) => document.getElementById(id);


/* =========================================================
   DATA SAFETY
   ========================================================= */

function ensureData() {

  if (!appData.tests || typeof appData.tests !== "object") {
    appData.tests = { records: [] };
  }

  if (!Array.isArray(appData.tests.records)) {
    appData.tests.records = [];
  }


  if (!appData.study || typeof appData.study !== "object") {
    appData.study = {
      tasks: [],
      sessions: []
    };
  }

  if (!Array.isArray(appData.study.tasks)) {
    appData.study.tasks = [];
  }

  if (!Array.isArray(appData.study.sessions)) {
    appData.study.sessions = [];
  }


  if (!appData.mistakes || typeof appData.mistakes !== "object") {
    appData.mistakes = {
      records: []
    };
  }

  if (!Array.isArray(appData.mistakes.records)) {
    appData.mistakes.records = [];
  }


  if (!appData.syllabus || typeof appData.syllabus !== "object") {
    appData.syllabus = {
      subjects: {
        physics: [],
        chemistry: [],
        biology: []
      }
    };
  }

  if (!appData.syllabus.subjects) {
    appData.syllabus.subjects = {};
  }

  ["physics", "chemistry", "biology"].forEach((subject) => {
    if (!Array.isArray(appData.syllabus.subjects[subject])) {
      appData.syllabus.subjects[subject] = [];
    }
  });


  if (!appData.profile || typeof appData.profile !== "object") {
    appData.profile = {};
  }
}


/* =========================================================
   DATE
   ========================================================= */

function getToday() {

  const now = new Date();

  const year = now.getFullYear();

  const month = String(
    now.getMonth() + 1
  ).padStart(2, "0");

  const day = String(
    now.getDate()
  ).padStart(2, "0");

  return `${year}-${month}-${day}`;
}


function formatDate(dateString) {

  if (!dateString) {
    return "—";
  }

  const date = new Date(`${dateString}T00:00:00`);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}


/* =========================================================
   FORMAT HELPERS
   ========================================================= */

function formatHours(hours) {

  const value = Number(hours) || 0;

  if (value === 0) {
    return "0h";
  }

  return `${Number(value.toFixed(2))}h`;
}


function setText(id, value) {

  const element = $(id);

  if (!element) {
    return;
  }

  element.textContent = value;
}


function setProgress(id, value) {

  const bar = $(id);

  if (!bar) {
    return;
  }

  if (
    value === null ||
    value === undefined ||
    Number.isNaN(Number(value))
  ) {
    bar.style.width = "0%";
    return;
  }

  const safeValue = Math.max(
    0,
    Math.min(100, Number(value))
  );

  bar.style.width = `${safeValue}%`;
}


/* =========================================================
   SORT TESTS
   ========================================================= */

function getSortedTests() {

  return [...appData.tests.records].sort((a, b) => {

    const dateA = a.date || "";
    const dateB = b.date || "";

    if (dateA !== dateB) {
      return dateB.localeCompare(dateA);
    }

    return String(b.id || "").localeCompare(
      String(a.id || "")
    );
  });
}


/* =========================================================
   SCORE ANALYTICS
   ========================================================= */

function renderScoreOverview() {

  const tests = getSortedTests();

  if (!tests.length) {

    setText(
      "analytics-average-score",
      "—"
    );

    setText(
      "analytics-best-score",
      "—"
    );

    setText(
      "analytics-latest-score",
      "—"
    );

    setText(
      "analytics-target-gap",
      "—"
    );

    setText(
      "analytics-average-subtitle",
      "No tests recorded yet."
    );

    setText(
      "analytics-best-subtitle",
      "No tests recorded yet."
    );

    setText(
      "analytics-latest-subtitle",
      "No tests recorded yet."
    );

    setText(
      "analytics-target-subtitle",
      appData.profile?.targetScore
        ? `Target: ${appData.profile.targetScore} / 720`
        : "Set a target score in Profile."
    );

    return;
  }


  const scoredTests = tests.map((test) => ({
    ...test,
    total: calculateTestTotal(test)
  }));


  const totalScore = scoredTests.reduce(
    (sum, test) => sum + test.total,
    0
  );


  const average =
    totalScore / scoredTests.length;


  const best = scoredTests.reduce(
    (bestTest, currentTest) => {
      return currentTest.total > bestTest.total
        ? currentTest
        : bestTest;
    }
  );


  const latest = scoredTests[0];


  setText(
    "analytics-average-score",
    `${Math.round(average)} / 720`
  );

  setText(
    "analytics-best-score",
    `${best.total} / 720`
  );

  setText(
    "analytics-latest-score",
    `${latest.total} / 720`
  );


  setText(
    "analytics-average-subtitle",
    `${scoredTests.length} test${scoredTests.length === 1 ? "" : "s"} recorded`
  );


  setText(
    "analytics-best-subtitle",
    `${formatDate(best.date)}`
  );


  setText(
    "analytics-latest-subtitle",
    `${formatDate(latest.date)}`
  );


  const target = Number(
    appData.profile?.targetScore
  );


  if (
    Number.isFinite(target) &&
    target > 0
  ) {

    const gap = target - latest.total;

    if (gap > 0) {

      setText(
        "analytics-target-gap",
        `${gap}`
      );

      setText(
        "analytics-target-subtitle",
        `Points to target (${target})`
      );

    } else {

      setText(
        "analytics-target-gap",
        "0"
      );

      setText(
        "analytics-target-subtitle",
        `Target ${target} reached`
      );
    }

  } else {

    setText(
      "analytics-target-gap",
      "—"
    );

    setText(
      "analytics-target-subtitle",
      "Set a target score in Profile."
    );
  }
}


/* =========================================================
   SUBJECT ANALYSIS
   ========================================================= */

function renderSubjectAnalysis() {

  const tests = appData.tests.records;

  const subjects = [
    {
      key: "physics",
      max: 180,
      valueId: "physics-average",
      barId: "physics-average-bar",
      subtitleId: "physics-average-subtitle"
    },
    {
      key: "chemistry",
      max: 180,
      valueId: "chemistry-average",
      barId: "chemistry-average-bar",
      subtitleId: "chemistry-average-subtitle"
    },
    {
      key: "biology",
      max: 360,
      valueId: "biology-average",
      barId: "biology-average-bar",
      subtitleId: "biology-average-subtitle"
    }
  ];


  subjects.forEach((subject) => {

    if (!tests.length) {

      setText(
        subject.valueId,
        "—"
      );

      setText(
        subject.subtitleId,
        `No ${capitalize(subject.key)} scores recorded.`
      );

      setProgress(
        subject.barId,
        null
      );

      return;
    }


    const values = tests
      .map((test) => Number(test[subject.key]))
      .filter((value) => Number.isFinite(value));


    if (!values.length) {

      setText(
        subject.valueId,
        "—"
      );

      setText(
        subject.subtitleId,
        `No ${capitalize(subject.key)} scores recorded.`
      );

      setProgress(
        subject.barId,
        null
      );

      return;
    }


    const total = values.reduce(
      (sum, value) => sum + value,
      0
    );


    const average =
      total / values.length;


    const percentage =
      (average / subject.max) * 100;


    setText(
      subject.valueId,
      `${Math.round(average)}`
    );


    setText(
      subject.subtitleId,
      `${values.length} recorded test${values.length === 1 ? "" : "s"}`
    );


    setProgress(
      subject.barId,
      percentage
    );
  });
}


function capitalize(value) {

  if (!value) {
    return "";
  }

  return value.charAt(0).toUpperCase() + value.slice(1);
}


/* =========================================================
   SCORE JOURNEY
   ========================================================= */

function renderScoreJourney() {

  const tests = getSortedTests();

  const container = $("score-journey-list");
  const empty = $("score-journey-empty");

  container.innerHTML = "";

  empty.hidden = tests.length > 0;


  if (!tests.length) {

    setText(
      "score-journey-subtitle",
      "No tests recorded yet."
    );

    return;
  }


  setText(
    "score-journey-subtitle",
    `${tests.length} test${tests.length === 1 ? "" : "s"} recorded`
  );


  tests.forEach((test) => {

    const total = calculateTestTotal(test);
    const percentage = calculatePercentage(total);


    const item = document.createElement("article");

    item.className = "analytics-journey-item";


    item.innerHTML = `
      <div class="analytics-journey-date">
        ${formatDate(test.date)}
      </div>

      <div class="analytics-journey-main">
        <strong>
          ${escapeHtml(test.name || "Untitled Test")}
        </strong>

        <div class="analytics-journey-track">
          <span style="width: ${Math.max(
            0,
            Math.min(100, percentage)
          )}%"></span>
        </div>
      </div>

      <div class="analytics-journey-score">
        <strong>${total}</strong>
        <span>/ 720</span>
      </div>
    `;


    container.appendChild(item);
  });
}


/* =========================================================
   STUDY ANALYSIS
   ========================================================= */

function renderStudyAnalysis() {

  const today = getToday();

  const tasks = appData.study.tasks;

  const sessions = appData.study.sessions;


  const todayTasks = tasks.filter(
    (task) =>
      !task.date ||
      task.date === today
  );


  const completedTasks = todayTasks.filter(
    (task) => Boolean(task.completed)
  );


  const totalHours = sessions.reduce(
    (sum, session) =>
      sum + (Number(session.duration) || 0),
    0
  );


  setText(
    "analytics-session-count",
    sessions.length
      ? sessions.length
      : "—"
  );


  setText(
    "analytics-study-hours",
    sessions.length
      ? formatHours(totalHours)
      : "—"
  );


  setText(
    "analytics-today-tasks",
    todayTasks.length
      ? todayTasks.length
      : "—"
  );


  setText(
    "analytics-completed-tasks",
    todayTasks.length
      ? completedTasks.length
      : "—"
  );
}


/* =========================================================
   MISTAKE ANALYSIS
   ========================================================= */

function renderMistakeAnalysis() {

  const mistakes = appData.mistakes.records;


  if (!mistakes.length) {

    setText(
      "analytics-mistake-count",
      "—"
    );

    setText(
      "analytics-revised-count",
      "—"
    );

    setText(
      "analytics-pending-mistakes",
      "—"
    );

    setText(
      "analytics-revision-rate",
      "—"
    );

    return;
  }


  const revised = mistakes.filter(
    (mistake) => Boolean(mistake.revised)
  ).length;


  const pending =
    mistakes.length - revised;


  const revisionRate =
    (revised / mistakes.length) * 100;


  setText(
    "analytics-mistake-count",
    mistakes.length
  );


  setText(
    "analytics-revised-count",
    revised
  );


  setText(
    "analytics-pending-mistakes",
    pending
  );


  setText(
    "analytics-revision-rate",
    `${Math.round(revisionRate)}%`
  );
}


/* =========================================================
   SYLLABUS ANALYSIS
   ========================================================= */

function renderSyllabusAnalysis() {

  const subjects = [
    {
      key: "physics",
      valueId: "analytics-syllabus-physics",
      barId: "analytics-syllabus-physics-bar"
    },
    {
      key: "chemistry",
      valueId: "analytics-syllabus-chemistry",
      barId: "analytics-syllabus-chemistry-bar"
    },
    {
      key: "biology",
      valueId: "analytics-syllabus-biology",
      barId: "analytics-syllabus-biology-bar"
    }
  ];


  subjects.forEach((subject) => {

    const chapters =
      appData.syllabus.subjects[subject.key] || [];


    const progress =
      calculateSyllabusProgress(chapters);


    if (
      progress === null ||
      progress === undefined
    ) {

      setText(
        subject.valueId,
        "—"
      );

      setProgress(
        subject.barId,
        null
      );

      return;
    }


    const rounded =
      Math.round(progress);


    setText(
      subject.valueId,
      `${rounded}%`
    );


    setProgress(
      subject.barId,
      rounded
    );
  });
}


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHtml(value) {

  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


/* =========================================================
   RENDER
   ========================================================= */

function renderAnalytics() {

  ensureData();

  renderScoreOverview();

  renderSubjectAnalysis();

  renderScoreJourney();

  renderStudyAnalysis();

  renderMistakeAnalysis();

  renderSyllabusAnalysis();
}


renderAnalytics();


/* =========================================================
   LIVE DATA REFRESH
   ========================================================= */

window.addEventListener(
  "neet2027:dataUpdated",
  () => {
    window.location.reload();
  }
);