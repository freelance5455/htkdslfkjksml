import { loadAppData, saveAppData } from "./storage.js";
import { renderShell } from "./components.js";
import { checkProfileAccess } from "./profileGuard.js";
checkProfileAccess();
const appData = loadAppData();

renderShell("mistakes");

const $ = (id) => document.getElementById(id);


/* ==================================================
   CONSTANTS
================================================== */

const subjectNames = {
  physics: "Physics",
  chemistry: "Chemistry",
  biology: "Biology"
};

const priorityNames = {
  low: "Low",
  medium: "Medium",
  high: "High"
};


/* ==================================================
   DATA
================================================== */

function ensureMistakesData() {
  if (!appData.mistakes || typeof appData.mistakes !== "object") {
    appData.mistakes = {
      records: []
    };
  }

  if (!Array.isArray(appData.mistakes.records)) {
    appData.mistakes.records = [];
  }
}


/* ==================================================
   ID
================================================== */

function createId() {
  return `mistake_${Date.now()}_${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}


/* ==================================================
   ESCAPE HTML
================================================== */

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


/* ==================================================
   SUMMARY
================================================== */

function renderSummary() {
  ensureMistakesData();

  const mistakes = appData.mistakes.records;

  const total = mistakes.length;

  const revised = mistakes.filter(
    (mistake) => mistake.revised === true
  ).length;

  const unrevised = total - revised;

  const highPriority = mistakes.filter(
    (mistake) => mistake.priority === "high"
  ).length;


  /* Total */

  $("total-mistakes").textContent =
    total > 0 ? String(total) : "—";

  $("total-mistakes-subtitle").textContent =
    total > 0
      ? `${total} mistake${total === 1 ? "" : "s"} recorded`
      : "No mistakes recorded yet.";


  /* Unrevised */

  $("unrevised-mistakes").textContent =
    total > 0 ? String(unrevised) : "—";

  $("unrevised-mistakes-subtitle").textContent =
    total > 0
      ? unrevised > 0
        ? `${unrevised} pending revision`
        : "All mistakes revised"
      : "No unrevised mistakes yet.";


  /* High priority */

  $("high-priority-mistakes").textContent =
    total > 0 ? String(highPriority) : "—";

  $("high-priority-subtitle").textContent =
    highPriority > 0
      ? `${highPriority} high priority`
      : total > 0
        ? "No high priority mistakes"
        : "No high priority mistakes yet.";


  /* Revised */

  $("revised-mistakes").textContent =
    total > 0 ? String(revised) : "—";

  $("revised-mistakes-subtitle").textContent =
    revised > 0
      ? `${revised} revised`
      : total > 0
        ? "No mistakes revised yet"
        : "No revised mistakes yet.";


  $("mistakes-subtitle").textContent =
    total > 0
      ? `${total} mistake${total === 1 ? "" : "s"} in your mistake bank`
      : "No mistakes recorded yet.";
}


/* ==================================================
   RENDER TABLE
================================================== */

function renderRows() {
  ensureMistakesData();

  const tbody = $("mistake-rows");
  const empty = $("mistakes-empty");

  const mistakes = [...appData.mistakes.records].reverse();

  tbody.innerHTML = "";

  empty.hidden = mistakes.length > 0;


  mistakes.forEach((mistake) => {

    const tr = document.createElement("tr");

    const subject =
      subjectNames[mistake.subject] ||
      mistake.subject ||
      "—";

    const priority =
      mistake.priority || "medium";

    const priorityText =
      priorityNames[priority] || priority;


    tr.innerHTML = `

      <td class="subject-cell">
        <span class="mistake-subject">
          ${escapeHtml(subject)}
        </span>
      </td>


      <td class="chapter-cell">
        <span class="mistake-chapter">
          ${escapeHtml(mistake.chapter || "—")}
        </span>
      </td>


      <td class="topic-cell">
        <span class="mistake-topic">
          ${escapeHtml(mistake.topic || "—")}
        </span>
      </td>


      <td class="reason-cell">
        <span class="mistake-reason">
          ${escapeHtml(mistake.reason || "—")}
        </span>
      </td>


      <td class="priority-cell">

        <span class="mistake-priority priority-${escapeHtml(priority)}">
          ${escapeHtml(priorityText)}
        </span>

      </td>


      <td class="revision-cell">

        <button
          class="revision-toggle ${
            mistake.revised ? "revised" : "pending"
          }"
          type="button"
          data-revision-toggle="${escapeHtml(mistake.id)}"
        >
          ${mistake.revised ? "Revised" : "Pending"}
        </button>

      </td>


      <td class="action-cell">

        <button
          class="mistake-delete-btn"
          type="button"
          data-mistake-delete="${escapeHtml(mistake.id)}"
        >
          Delete
        </button>

      </td>

    `;

    tbody.appendChild(tr);
  });


  /* Revision */

  tbody
    .querySelectorAll("[data-revision-toggle]")
    .forEach((button) => {

      button.addEventListener("click", () => {

        const id = button.dataset.revisionToggle;

        const mistake =
          appData.mistakes.records.find(
            (item) => item.id === id
          );

        if (!mistake) return;

        mistake.revised = !mistake.revised;

        saveAppData(appData);

        renderSummary();
        renderRows();
      });

    });


  /* Delete */

  tbody
    .querySelectorAll("[data-mistake-delete]")
    .forEach((button) => {

      button.addEventListener("click", () => {

        const id = button.dataset.mistakeDelete;

        const index =
          appData.mistakes.records.findIndex(
            (mistake) => mistake.id === id
          );

        if (index === -1) return;

        appData.mistakes.records.splice(index, 1);

        saveAppData(appData);

        renderSummary();
        renderRows();
      });

    });
}


/* ==================================================
   MODAL
================================================== */

function openMistakeModal() {

  $("mistake-subject").value = "physics";
  $("mistake-chapter").value = "";
  $("mistake-topic").value = "";
  $("mistake-reason").value = "";
  $("mistake-priority").value = "medium";
  $("mistake-revised").checked = false;

  $("mistake-modal").hidden = false;

  setTimeout(() => {
    $("mistake-chapter").focus();
  }, 0);
}


function closeMistakeModal() {
  $("mistake-modal").hidden = true;
}


/* ==================================================
   BUTTONS
================================================== */

$("open-add-mistake").addEventListener(
  "click",
  openMistakeModal
);

$("add-mistake-inline").addEventListener(
  "click",
  openMistakeModal
);

$("empty-add-mistake").addEventListener(
  "click",
  openMistakeModal
);


$("close-mistake-modal").addEventListener(
  "click",
  closeMistakeModal
);

$("cancel-mistake").addEventListener(
  "click",
  closeMistakeModal
);


/* ==================================================
   OUTSIDE CLICK
================================================== */

$("mistake-modal").addEventListener(
  "click",
  (event) => {

    if (event.target === $("mistake-modal")) {
      closeMistakeModal();
    }

  }
);


/* ==================================================
   ESCAPE
================================================== */

document.addEventListener(
  "keydown",
  (event) => {

    if (
      event.key === "Escape" &&
      !$("mistake-modal").hidden
    ) {
      closeMistakeModal();
    }

  }
);


/* ==================================================
   FORM
================================================== */

$("mistake-form").addEventListener(
  "submit",
  (event) => {

    event.preventDefault();

    ensureMistakesData();

    const subject =
      $("mistake-subject").value;

    const chapter =
      $("mistake-chapter").value.trim();

    const topic =
      $("mistake-topic").value.trim();

    const reason =
      $("mistake-reason").value.trim();

    const priority =
      $("mistake-priority").value;

    const revised =
      $("mistake-revised").checked;


    if (!subject || !chapter) {
      return;
    }


    const mistake = {
      id: createId(),
      subject,
      chapterId: "",
      chapter,
      topic,
      reason,
      revised,
      priority
    };


    appData.mistakes.records.push(mistake);

    saveAppData(appData);

    closeMistakeModal();

    renderSummary();
    renderRows();
  }
);


/* ==================================================
   INITIAL
================================================== */

ensureMistakesData();

renderSummary();
renderRows();