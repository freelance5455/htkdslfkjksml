# NEET 2027 — Personal Preparation Command Center

## Build Step 01
Global shell foundation is locked.

### Source of truth
- PDF architecture: data ownership, flow, storage and calculations.
- UI reference image: visual direction only.

### Core flow
PROFILE → CENTRAL DATA → SYLLABUS / STUDY / TESTS → MISTAKES / ANALYTICS → DASHBOARD

### Current structure
- index.html — Dashboard entry
- pages/ — source/analysis pages
- css/ — global + shared + page styles
- js/ — data, storage, calculations, events, shell
- assets/ — future icons/images

No fake student performance data is included.
