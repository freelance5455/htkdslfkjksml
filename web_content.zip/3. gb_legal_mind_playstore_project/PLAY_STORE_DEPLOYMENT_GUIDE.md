# GB Legal Mind — Build-Ready Android APK Guide (`in.gblegalmind.app` v2.0.0)

## 1. Project Structure Included in This ZIP
- `index.html` & `www/index.html`: Complete frontend application synced with Capacitor `webDir: "www"` and pre-copied into `android/app/src/main/assets/public/index.html`.
- `capacitor.config.json`, `manifest.json`, `package.json`, `package-lock.json`: Complete Capacitor & Node.js configuration.
- `android/`: Complete, standalone Android Gradle project (`namespace "in.gblegalmind.app"`, `versionCode 2`, `versionName "2.0.0"`, `minSdk 24`, `targetSdk 34`, `MainActivity.java` with full WebView file upload, geolocation, external intent routing, and hardware back-button support).
- `server_api.js`, `backend_schema.sql`, `migrations_v2.sql`, `.env.example`: Backend verification API, database schema, non-destructive v2 migrations + RLS policies, and environment template (no private secrets or keystores exposed).
- `build_apk.bat`, `build_apk.sh`, `.github/workflows/build-android-apk.yml`: One-click local and cloud APK build scripts.

## 2. How to Generate the Installable Android APK (`app-debug.apk`)

### Option A — Zero-Setup Cloud Build via GitHub Actions (No PC / Android Studio Needed)
1. Create a free repository on GitHub and upload the extracted files from this ZIP.
2. Open the **Actions** tab in your GitHub repository and run **Build GB Legal Mind Android APK**.
3. In ~2 minutes, download **`GB-Legal-Mind-v2.0.0-debug-apk`** (`app-debug.apk`) directly to your mobile phone and tap to install.

### Option B — Local Build on Windows / macOS / Linux
1. Ensure **Java JDK 17** and **Android SDK (API 34)** (or Android Studio) are installed.
2. Run `build_apk.bat` (Windows) or `./build_apk.sh` (Linux/macOS), or open the `android/` folder in Android Studio and click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Copy `android/app/build/outputs/apk/debug/app-debug.apk` to your Android phone, enable **Install unknown apps**, and install.
