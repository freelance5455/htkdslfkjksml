-- ============================================================================
-- GB LEGAL MIND — SAFE NON-DESTRUCTIVE MIGRATION (v1 -> v2)
-- Preserves all existing tables and data while adding Common User Profiles,
-- Reminders, Verification Workflows, 1-to-1 Document Links & RLS Policies.
-- ============================================================================

-- 1. Extend users table for Common User Profile (Requirement 2)
ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_photo_url TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS dob DATE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS gender VARCHAR(30);
ALTER TABLE users ADD COLUMN IF NOT EXISTS profession_category VARCHAR(40) DEFAULT 'Client / Citizen';
ALTER TABLE users ADD COLUMN IF NOT EXISTS state VARCHAR(80);
ALTER TABLE users ADD COLUMN IF NOT EXISTS district VARCHAR(80);
ALTER TABLE users ADD COLUMN IF NOT EXISTS city VARCHAR(80);
ALTER TABLE users ADD COLUMN IF NOT EXISTS pin_code VARCHAR(6);
ALTER TABLE users ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_completion_pct INT DEFAULT 40;
ALTER TABLE users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 2. Extend advocates table for District, PIN, Verification Proof & Privacy (Requirement 3)
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS district VARCHAR(80);
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS pin_code VARCHAR(6);
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS preferred_languages TEXT[];
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS bar_proof_doc_url TEXT;
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS supporting_id_doc_url TEXT;
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS verification_status VARCHAR(30) DEFAULT 'Not Submitted'; -- 'Not Submitted', 'Pending', 'Verified', 'Rejected'
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE advocates ADD COLUMN IF NOT EXISTS whatsapp_privacy VARCHAR(40) DEFAULT 'locked_until_authorized';
ALTER TABLE advocates ALTER COLUMN rating SET DEFAULT 0.0;

-- 3. Extend law_students table for DOB, District, PIN, Admission Year & Verification (Requirement 4)
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS dob DATE;
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS district VARCHAR(80);
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS pin_code VARCHAR(6);
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS admission_year INT;
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS verification_status VARCHAR(30) DEFAULT 'Not Submitted';
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE law_students ADD COLUMN IF NOT EXISTS internship_experience TEXT;

-- 4. Create Reminders table (Requirement 6)
CREATE TABLE IF NOT EXISTS reminders (
  id VARCHAR(36) PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  appointment_id VARCHAR(32) REFERENCES appointments(id) ON DELETE SET NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  reminder_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME,
  recurrence VARCHAR(30) DEFAULT 'One-Time', -- 'One-Time', 'Daily', 'Weekly'
  notification_pref VARCHAR(50) DEFAULT 'Both (In-App + Push)',
  status VARCHAR(20) DEFAULT 'Scheduled',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Extend appointments & document_requests for Rejection Reasons, Timezone & Unique Unlocks
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS time_zone VARCHAR(30) DEFAULT 'IST (UTC+05:30)';
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE document_requests ADD COLUMN IF NOT EXISTS rejection_reason TEXT;

-- 6. Extend payments table for Signature Verification & Idempotent Unlocks (Requirement 11)
ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_signature VARCHAR(256);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS signature_verified BOOLEAN DEFAULT FALSE;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS unlock_key VARCHAR(160) UNIQUE;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS env_mode VARCHAR(20) DEFAULT 'test';

-- 7. Enable Row Level Security (RLS) Policies (Requirement 12)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE advocates ENABLE ROW LEVEL SECURITY;
ALTER TABLE law_students ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Users can read/update only their own private user record
CREATE POLICY user_self_select ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY user_self_update ON users FOR UPDATE USING (auth.uid() = id);

-- Public can view Advocate & Student directory profiles; only owner can update basic/professional info; only admin can update verification_status
CREATE POLICY advocate_public_read ON advocates FOR SELECT USING (true);
CREATE POLICY advocate_owner_update ON advocates FOR UPDATE USING (auth.uid() = user_id);

-- Appointments & Document Requests: accessible only to the Client who created it or the assigned Advocate
CREATE POLICY appt_participant_access ON appointments FOR ALL
  USING (auth.uid() = client_user_id OR auth.uid() IN (SELECT user_id FROM advocates WHERE id = appointments.advocate_id));

CREATE POLICY doc_participant_access ON document_requests FOR ALL
  USING (auth.uid() = client_user_id OR auth.uid() IN (SELECT user_id FROM advocates WHERE id = document_requests.advocate_id));

-- Reminders: strictly private to owner
CREATE POLICY reminder_owner_access ON reminders FOR ALL USING (auth.uid() = user_id);
