-- GB Legal Mind — Complete Production Database Schema (PostgreSQL / Supabase)

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name VARCHAR(120) NOT NULL,
  mobile VARCHAR(15) UNIQUE,
  email VARCHAR(160) UNIQUE,
  google_uid VARCHAR(128),
  role VARCHAR(20) DEFAULT 'user', -- 'user', 'student', 'advocate', 'admin'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE advocates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  full_name VARCHAR(120) NOT NULL,
  designation VARCHAR(100) NOT NULL,
  experience_years INT DEFAULT 1,
  bar_council_name VARCHAR(150),
  enrollment_no VARCHAR(80) UNIQUE NOT NULL,
  enrollment_date DATE,
  bar_council_id VARCHAR(80),
  city VARCHAR(80) NOT NULL,
  state VARCHAR(80) NOT NULL,
  chamber_name VARCHAR(160),
  chamber_address TEXT,
  practice_areas TEXT[],
  court_jurisdiction TEXT[],
  offers_internship BOOLEAN DEFAULT TRUE,
  stipend_range VARCHAR(80),
  whatsapp_number VARCHAR(20),
  verified BOOLEAN DEFAULT FALSE,
  rating NUMERIC(2,1) DEFAULT 4.8,
  reviews_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE law_students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  full_name VARCHAR(120) NOT NULL,
  course VARCHAR(60) NOT NULL,
  semester VARCHAR(40) NOT NULL,
  college_name VARCHAR(180) NOT NULL,
  passing_year INT,
  city VARCHAR(80) NOT NULL,
  state VARCHAR(80) NOT NULL,
  skills TEXT[],
  practice_interests TEXT[],
  open_for_internship BOOLEAN DEFAULT TRUE,
  paid_guidance_fee INT DEFAULT 49,
  resume_url TEXT,
  college_id_url TEXT,
  verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE appointments (
  id VARCHAR(32) PRIMARY KEY,
  advocate_id UUID REFERENCES advocates(id),
  client_user_id UUID REFERENCES users(id),
  client_name VARCHAR(120) NOT NULL,
  client_mobile VARCHAR(15) NOT NULL,
  client_email VARCHAR(160),
  subject VARCHAR(100) NOT NULL,
  matter VARCHAR(120) NOT NULL,
  problem_summary TEXT NOT NULL,
  priority VARCHAR(120),
  appointment_date DATE NOT NULL,
  time_slot VARCHAR(40) NOT NULL,
  consultation_mode VARCHAR(60) NOT NULL,
  meet_link TEXT,
  photo_url TEXT,
  pdf_url TEXT,
  status VARCHAR(20) DEFAULT 'Pending', -- 'Pending', 'Confirmed', 'Completed', 'Cancelled'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE document_requests (
  id VARCHAR(32) PRIMARY KEY,
  advocate_id UUID REFERENCES advocates(id),
  client_user_id UUID REFERENCES users(id),
  client_name VARCHAR(120) NOT NULL,
  client_mobile VARCHAR(15) NOT NULL,
  client_email VARCHAR(160),
  doc_category VARCHAR(100) NOT NULL,
  doc_sub_type VARCHAR(120) NOT NULL,
  purpose_short VARCHAR(250) NOT NULL,
  details_full TEXT NOT NULL,
  contact_mode VARCHAR(50),
  photo_url TEXT,
  pdf_url TEXT,
  status VARCHAR(20) DEFAULT 'Pending', -- 'Pending', 'Confirmed', 'Completed', 'Rejected'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE internship_applications (
  id VARCHAR(32) PRIMARY KEY,
  advocate_id UUID REFERENCES advocates(id),
  student_id UUID REFERENCES law_students(id),
  preferred_mode VARCHAR(30),
  resume_url TEXT NOT NULL,
  college_id_url TEXT,
  message TEXT,
  status VARCHAR(20) DEFAULT 'Submitted',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE payments (
  id VARCHAR(40) PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  razorpay_order_id VARCHAR(80),
  razorpay_payment_id VARCHAR(80),
  service_type VARCHAR(60), -- 'student_guidance_49', 'advocate_standard_149', 'advocate_premium_299'
  amount_inr INT NOT NULL,
  status VARCHAR(20) DEFAULT 'Success',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
