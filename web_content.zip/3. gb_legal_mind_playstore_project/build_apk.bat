@echo off
echo === Syncing GB Legal Mind Web Assets to www/ and Android Assets ===
copy /Y index.html www\index.html
copy /Y manifest.json www\manifest.json
copy /Y index.html android\app\src\main\assets\public\index.html
echo === Building Installable Debug APK (in.gblegalmind.app v2.0.0) ===
cd android
if exist gradlew.bat (
  call gradlew.bat assembleDebug
) else (
  gradle assembleDebug
)
echo === APK Ready: android\app\build\outputs\apk\debug\app-debug.apk ===
pause
