#!/usr/bin/env bash
set -e
echo "=== Syncing GB Legal Mind Web Assets to www/ and Android Assets ==="
mkdir -p www android/app/src/main/assets/public
cp index.html www/index.html
cp manifest.json www/manifest.json
cp index.html android/app/src/main/assets/public/index.html
echo "=== Building Installable Debug APK (in.gblegalmind.app v2.0.0) ==="
cd android
if [ -f "./gradlew" ]; then
  ./gradlew assembleDebug
else
  gradle assembleDebug
fi
echo "=== APK Ready: android/app/build/outputs/apk/debug/app-debug.apk ==="
