SIRUMUGAI CENTERING - Updated weekly salary close feature

Files:
- index.html: Updated app web source.

How to use:
1. Import this folder/ZIP into the same HTML-to-APK builder used for the current app.
2. Build a new APK.

New feature:
- Calculate a worker's weekly pay as before.
- After actually paying, press "சம்பளம் கொடுத்து WEEK CLOSE".
- The selected worker's attendance and OT entries in the selected date range are cleared from the active week.
- Their advance balance is reset to zero.
- The old weekly payment details are retained in Salary History.
- Worker name, phone and daily wage remain.

Important:
- Existing app data is stored locally in the app/browser. Back up the current app data before replacing or uninstalling the installed APK.
- A rebuilt APK signed with a different signing key may not install as an in-place update. Do not uninstall the current app until the existing records are backed up.
