-- ANONYMOUX STUDIO 2.3.2 resource centre + dashboard support.
-- Additive and repeatable. Existing user, wallet, job and asset rows are not touched.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS tool_categories (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
 description TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 100,
 is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tutorial_categories (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
 description TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 100,
 is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tools (
 id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NULL, name TEXT NOT NULL,
 slug TEXT NOT NULL UNIQUE, logo_path TEXT NULL, short_description TEXT NOT NULL DEFAULT '',
 full_description TEXT NOT NULL DEFAULT '', official_url TEXT NOT NULL,
 download_page_url TEXT NOT NULL DEFAULT '', windows_download_url TEXT NOT NULL DEFAULT '',
 macos_download_url TEXT NOT NULL DEFAULT '', linux_download_url TEXT NOT NULL DEFAULT '',
 installation_instructions TEXT NOT NULL DEFAULT '', compatibility_info TEXT NOT NULL DEFAULT '',
 system_requirements TEXT NOT NULL DEFAULT '', pricing TEXT NOT NULL DEFAULT 'unknown',
 version TEXT NOT NULL DEFAULT '', is_featured INTEGER NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'draft', source_verified_at TEXT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(category_id) REFERENCES tool_categories(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_tools_category_status ON tools(category_id,status);
CREATE INDEX IF NOT EXISTS idx_tools_featured ON tools(status,is_featured,updated_at);
CREATE TABLE IF NOT EXISTS tutorials (
 id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NULL, title TEXT NOT NULL,
 slug TEXT NOT NULL UNIQUE, thumbnail_path TEXT NULL, short_description TEXT NOT NULL DEFAULT '',
 content_markdown TEXT NOT NULL DEFAULT '', reading_minutes INTEGER NOT NULL DEFAULT 5,
 difficulty TEXT NOT NULL DEFAULT 'beginner', is_featured INTEGER NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'draft', last_updated_at TEXT NOT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(category_id) REFERENCES tutorial_categories(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_tutorials_category_status ON tutorials(category_id,status,updated_at);
CREATE INDEX IF NOT EXISTS idx_tutorials_featured ON tutorials(status,is_featured,updated_at);
CREATE TABLE IF NOT EXISTS tutorial_steps (
 id INTEGER PRIMARY KEY AUTOINCREMENT, tutorial_id INTEGER NOT NULL, step_order INTEGER NOT NULL,
 title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tutorial_steps_order ON tutorial_steps(tutorial_id,step_order);
CREATE TABLE IF NOT EXISTS tutorial_relations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, tutorial_id INTEGER NOT NULL,
 related_type TEXT NOT NULL CHECK(related_type IN ('tool','tutorial')), related_id INTEGER NOT NULL,
 sort_order INTEGER NOT NULL DEFAULT 100, created_at TEXT NOT NULL,
 UNIQUE(tutorial_id,related_type,related_id),
 FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tutorial_relations_lookup ON tutorial_relations(tutorial_id,related_type,sort_order);
CREATE TABLE IF NOT EXISTS tutorial_media (
 id INTEGER PRIMARY KEY AUTOINCREMENT, tutorial_id INTEGER NOT NULL, media_kind TEXT NOT NULL,
 disk_path TEXT NULL, external_url TEXT NULL, mime_type TEXT NOT NULL DEFAULT '',
 alt_text TEXT NOT NULL DEFAULT '', caption TEXT NOT NULL DEFAULT '',
 sort_order INTEGER NOT NULL DEFAULT 100, created_at TEXT NOT NULL,
 FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tutorial_media_order ON tutorial_media(tutorial_id,sort_order);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, event_key TEXT NOT NULL,
 title TEXT NOT NULL, message TEXT NOT NULL DEFAULT '', notification_type TEXT NOT NULL DEFAULT 'activity',
 link_url TEXT NOT NULL DEFAULT '', read_at TEXT NULL, created_at TEXT NOT NULL,
 UNIQUE(user_id,event_key)
);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id,created_at);
CREATE TABLE IF NOT EXISTS dashboard_recent_access (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, workspace TEXT NOT NULL,
 title TEXT NOT NULL, target_url TEXT NOT NULL, accessed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_dashboard_access_user ON dashboard_recent_access(user_id,accessed_at);
