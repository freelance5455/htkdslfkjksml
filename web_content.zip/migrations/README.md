# ANONYMOUX STUDIO 2.3.2 migrations

`002_resources_centre_sqlite.sql` and `002_resources_centre_mysql.sql` are additive, repeatable schema migrations for Tools & Tutorials, related tutorial media/steps, dashboard notifications and recently opened workspaces. They do not drop tables, reset users, change wallet balances or rewrite existing job/asset records.

The PHP application also creates the same tables idempotently in `resources_schema()` when a signed-in page initializes. This allows the current no-shell/shared-host deployment process to apply the migration on first request. Keep the SQL files as the explicit DBA/deployment record and run the matching file manually only if your deployment process manages migrations separately. Do not run the SQLite file against MySQL or vice versa.

Before deploying, take a database and `storage/` backup. The `storage/resources/` folder is created on demand and protected by a deny-all `.htaccess`; uploaded tutorial images are served via `resource-media.php` after publication/role checks.


### 003 — administrator bootstrap and Flutterwave credits

`003_flutterwave_payments_sqlite.sql` and `003_flutterwave_payments_mysql.sql` add the singleton administrator-initialization lock, configurable credit packages, payment orders and lookup indexes. They are additive and do not reset or rewrite existing users, wallet balances, credit transactions, workspaces or media. The application also applies these tables idempotently at runtime through `auth_schema()` and `payments_schema()`; run only the migration matching the configured database driver if you manage migrations manually.


### 005 — Voice Studio charge/refund idempotency

`005_voice_idempotency_sqlite.sql` and `005_voice_idempotency_mysql.sql` add per-user unique request-key and refund-key ledgers. These additive tables prevent concurrent retries from creating duplicate voice debits or duplicate refunds. `app/bootstrap.php` creates the same tables with `CREATE TABLE IF NOT EXISTS` for shared-host deployments. The migration does not rewrite credit history or existing wallet balances. Run only the matching SQL file if migrations are managed manually.

### 006 — credit package display and bonus configuration (2.5.5)

`006_credit_package_options_sqlite.sql` and `006_credit_package_options_mysql.sql` add administrator-controlled display order, optional promotional badge and optional bonus credits. They preserve existing package prices, package credits, active state, orders and wallet records. `payments_schema()` also performs conditional additive column checks for shared-hosting deployments and initializes missing proposed package names without overwriting existing package rows. Run only the matching SQL migration if your deployment process manages schema migrations manually; skip columns already present.

## 007 — Private Fish Audio voice profiles

Creates the additive `voice_profiles` ownership and consent table for user-created private Fish Audio voice models. The application also creates this table idempotently on first use. Apply the SQLite or MySQL script matching the configured database driver when managing migrations manually.
