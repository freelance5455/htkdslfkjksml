-- Student profiles, learning progress, and tutor history.
create table if not exists profiles (
  user_id    text primary key,
  full_name  text not null,
  grade      smallint not null check (grade between 4 and 8),
  role       text not null default 'student' check (role in ('student', 'admin')),
  locale     text not null default 'en' check (locale in ('en', 'am')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists progress (
  id         serial primary key,
  user_id    text not null,
  kind       text not null check (kind in ('lesson', 'quiz', 'exam')),
  item_id    text not null,
  score      integer,
  total      integer,
  completed  boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (user_id, kind, item_id)
);

create index if not exists progress_user_idx on progress (user_id);

create table if not exists tutor_messages (
  id         serial primary key,
  user_id    text not null,
  role       text not null check (role in ('user', 'assistant')),
  content    text not null,
  created_at timestamptz not null default now()
);

create index if not exists tutor_user_idx on tutor_messages (user_id, id);
