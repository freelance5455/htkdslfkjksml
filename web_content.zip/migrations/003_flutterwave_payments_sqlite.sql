-- Additive ANONYMOUX 2.4.0 migration. Does not alter existing users or wallet rows.
CREATE TABLE IF NOT EXISTS admin_bootstrap_lock (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  created_at TEXT NOT NULL
);
INSERT OR IGNORE INTO admin_bootstrap_lock(id, created_at) VALUES (1, CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS credit_packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price_minor INTEGER NOT NULL,
  credits INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'NGN',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS payment_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  package_id INTEGER NOT NULL,
  reference TEXT NOT NULL UNIQUE,
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  credits INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  provider_transaction_id TEXT UNIQUE,
  provider_status TEXT,
  verified_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payment_orders_user ON payment_orders(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_payment_orders_status ON payment_orders(status, created_at);
