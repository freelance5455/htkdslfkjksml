-- Additive private Fish Audio voice-clone ownership table.
CREATE TABLE IF NOT EXISTS voice_profiles (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 provider_voice_id VARCHAR(120) NOT NULL UNIQUE, voice_name VARCHAR(160) NOT NULL, description TEXT NOT NULL,
 provider_state VARCHAR(32) NOT NULL DEFAULT 'created', visibility VARCHAR(20) NOT NULL DEFAULT 'private',
 consent_status TINYINT(1) NOT NULL DEFAULT 0, consent_version VARCHAR(40) NOT NULL DEFAULT 'voice-consent-v1',
 consent_at DATETIME NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 KEY idx_voice_profiles_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS voice_clone_requests (user_id BIGINT UNSIGNED NOT NULL, request_key VARCHAR(100) NOT NULL, status VARCHAR(24) NOT NULL, provider_voice_id VARCHAR(120) NOT NULL DEFAULT '', credits_charged BIGINT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY(user_id,request_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
