-- ANONYMOUX STUDIO 2.3.2 resource centre + dashboard support.
-- Execute with the application database selected. Additive; existing rows are not modified.
CREATE TABLE IF NOT EXISTS tool_categories (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL,
 slug VARCHAR(160) NOT NULL UNIQUE, description TEXT NOT NULL, sort_order INT NOT NULL DEFAULT 100,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tutorial_categories (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL,
 slug VARCHAR(160) NOT NULL UNIQUE, description TEXT NOT NULL, sort_order INT NOT NULL DEFAULT 100,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tools (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, category_id BIGINT UNSIGNED NULL,
 name VARCHAR(160) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE, logo_path VARCHAR(255) NULL,
 short_description VARCHAR(500) NOT NULL DEFAULT '', full_description TEXT NOT NULL,
 official_url VARCHAR(2048) NOT NULL, download_page_url VARCHAR(2048) NOT NULL DEFAULT '',
 windows_download_url VARCHAR(2048) NOT NULL DEFAULT '', macos_download_url VARCHAR(2048) NOT NULL DEFAULT '',
 linux_download_url VARCHAR(2048) NOT NULL DEFAULT '', installation_instructions TEXT NOT NULL,
 compatibility_info TEXT NOT NULL, system_requirements TEXT NOT NULL,
 pricing VARCHAR(20) NOT NULL DEFAULT 'unknown', version VARCHAR(80) NOT NULL DEFAULT '',
 is_featured TINYINT(1) NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'draft',
 source_verified_at DATE NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 KEY idx_tools_category_status(category_id,status), KEY idx_tools_featured(status,is_featured,updated_at),
 CONSTRAINT fk_tools_category FOREIGN KEY(category_id) REFERENCES tool_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tutorials (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, category_id BIGINT UNSIGNED NULL,
 title VARCHAR(180) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE, thumbnail_path VARCHAR(255) NULL,
 short_description VARCHAR(500) NOT NULL DEFAULT '', content_markdown LONGTEXT NOT NULL,
 reading_minutes INT NOT NULL DEFAULT 5, difficulty VARCHAR(20) NOT NULL DEFAULT 'beginner',
 is_featured TINYINT(1) NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'draft',
 last_updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 KEY idx_tutorials_category_status(category_id,status), KEY idx_tutorials_featured(status,is_featured,updated_at),
 CONSTRAINT fk_tutorials_category FOREIGN KEY(category_id) REFERENCES tutorial_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tutorial_steps (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tutorial_id BIGINT UNSIGNED NOT NULL,
 step_order INT NOT NULL, title VARCHAR(180) NOT NULL, body TEXT NOT NULL,
 created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 KEY idx_tutorial_steps_order(tutorial_id,step_order),
 CONSTRAINT fk_tutorial_steps_tutorial FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tutorial_relations (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tutorial_id BIGINT UNSIGNED NOT NULL,
 related_type VARCHAR(20) NOT NULL, related_id BIGINT UNSIGNED NOT NULL,
 sort_order INT NOT NULL DEFAULT 100, created_at DATETIME NOT NULL,
 UNIQUE KEY uq_tutorial_relation(tutorial_id,related_type,related_id),
 KEY idx_tutorial_relations_lookup(tutorial_id,related_type,sort_order),
 CONSTRAINT fk_tutorial_relations_tutorial FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tutorial_media (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tutorial_id BIGINT UNSIGNED NOT NULL,
 media_kind VARCHAR(20) NOT NULL, disk_path VARCHAR(255) NULL, external_url VARCHAR(2048) NULL,
 mime_type VARCHAR(100) NOT NULL DEFAULT '', alt_text VARCHAR(255) NOT NULL DEFAULT '',
 caption VARCHAR(500) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 100,
 created_at DATETIME NOT NULL, KEY idx_tutorial_media_order(tutorial_id,sort_order),
 CONSTRAINT fk_tutorial_media_tutorial FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 event_key VARCHAR(190) NOT NULL, title VARCHAR(180) NOT NULL, message TEXT NOT NULL,
 notification_type VARCHAR(30) NOT NULL DEFAULT 'activity', link_url VARCHAR(500) NOT NULL DEFAULT '',
 read_at DATETIME NULL, created_at DATETIME NOT NULL,
 UNIQUE KEY uq_notifications_user_event(user_id,event_key), KEY idx_notifications_user_created(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS dashboard_recent_access (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 workspace VARCHAR(40) NOT NULL, title VARCHAR(160) NOT NULL, target_url VARCHAR(500) NOT NULL,
 accessed_at DATETIME NOT NULL, KEY idx_dashboard_access_user(user_id,accessed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
