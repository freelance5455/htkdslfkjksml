-- Additive private Fish Audio voice-clone ownership table.
CREATE TABLE IF NOT EXISTS voice_profiles (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, provider_voice_id TEXT NOT NULL UNIQUE,
 voice_name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', provider_state TEXT NOT NULL DEFAULT 'created',
 visibility TEXT NOT NULL DEFAULT 'private', consent_status INTEGER NOT NULL DEFAULT 0,
 consent_version TEXT NOT NULL DEFAULT 'voice-consent-v1', consent_at TEXT NOT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_voice_profiles_user ON voice_profiles(user_id,created_at);

CREATE TABLE IF NOT EXISTS voice_clone_requests (user_id INTEGER NOT NULL, request_key TEXT NOT NULL, status TEXT NOT NULL, provider_voice_id TEXT NOT NULL DEFAULT '', credits_charged INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(user_id,request_key));
