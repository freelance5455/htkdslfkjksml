-- Additive and repeatable: protects voice credit charges and refunds from retries.
CREATE TABLE IF NOT EXISTS voice_request_keys (
    user_id BIGINT UNSIGNED NOT NULL,
    request_key VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, request_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS voice_refunds (
    user_id BIGINT UNSIGNED NOT NULL,
    request_key VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, request_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
