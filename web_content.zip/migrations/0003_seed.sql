-- Demo listings so Browse isn't empty. Owned by a seed identity nobody can sign in as.
insert into rooms (
  id, owner_id, title, location, rent, currency, deposit, available_from,
  phone, whatsapp, description,
  commission_type, commission_value, renter_commission_type, renter_commission_value,
  status, created_at
) values
(
  'room-thamel-sun',
  'seed-owner',
  'Sunny single near Thamel',
  'Thamel, Kathmandu',
  12000, 'NPR', 12000, 'now',
  '+977 980-111-0001', '9779801110001',
  'Bright single room two minutes from the garden. Shared kitchen, reliable wifi, no smoking. First month in advance.',
  'percent', 10, 'percent', 0,
  'available', now() - interval '4 days'
),
(
  'room-patan-court',
  'seed-owner',
  'Courtyard room in Patan',
  'Patan Durbar Square',
  9500, 'NPR', 9500, 'Oct 1',
  '+977 980-222-0002', '9779802220002',
  'Quiet lane behind the square. Attached bath, rooftop for drying clothes, morning sun on the courtyard.',
  'percent', 10, 'percent', 0,
  'available', now() - interval '3 days'
),
(
  'room-baneshwor-share',
  'seed-owner',
  'Room in a working flat',
  'New Baneshwor',
  7500, 'NPR', 7500, 'now',
  '+977 980-333-0003', '',
  'One room in a 3-bed flat with two working professionals. Bus on the Ring Road, grocery downstairs.',
  'percent', 8, 'percent', 0,
  'available', now() - interval '2 days'
),
(
  'room-lazimpat-studio',
  'seed-owner',
  'Self-contained studio, Lazimpat',
  'Lazimpat',
  18000, 'NPR', 18000, 'now',
  '+977 980-444-0004', '9779804440004',
  'Street-facing studio with kitchenette and good light. A finder''s fee applies to the renter as well as the owner commission.',
  'percent', 10, 'percent', 5,
  'available', now() - interval '30 hours'
),
(
  'room-maharajgunj-annex',
  'seed-owner',
  'Garden annex, Maharajgunj',
  'Maharajgunj',
  14000, 'NPR', 14000, 'now',
  '+977 980-555-0005', '9779805550005',
  'Independent annex behind a family house. Small garden, scooter parking, own entrance.',
  'fixed', 2000, 'percent', 0,
  'available', now() - interval '18 hours'
),
(
  'room-pokhara-loft',
  'seed-owner',
  'Lakeside loft, Pokhara',
  'Lakeside, Pokhara',
  15000, 'NPR', 15000, 'now',
  '+977 980-666-0006', '9779806660006',
  'Loft above a cafe street. Mountain view from the window. Already rented — listed so you can see status.',
  'percent', 10, 'percent', 0,
  'rented', now() - interval '8 days'
)
on conflict (id) do nothing;
