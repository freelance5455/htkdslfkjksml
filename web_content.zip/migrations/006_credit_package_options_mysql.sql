-- Additive 2.5.5 package configuration fields. Existing package prices and purchases are preserved.
ALTER TABLE credit_packages ADD COLUMN sort_order INT NOT NULL DEFAULT 100;
ALTER TABLE credit_packages ADD COLUMN promo_badge VARCHAR(80) NOT NULL DEFAULT '';
ALTER TABLE credit_packages ADD COLUMN bonus_credits BIGINT NOT NULL DEFAULT 0;
