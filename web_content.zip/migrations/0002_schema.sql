-- RentDirect listings, referral leads, commissions, and contact-reveal log.
create table if not exists rooms (
  id                       text primary key,
  owner_id                 text not null,
  title                    text not null,
  location                 text not null,
  rent                     numeric not null,
  currency                 text not null default '',
  deposit                  numeric not null default 0,
  available_from           text not null default '',
  phone                    text not null,
  whatsapp                 text not null default '',
  description              text not null default '',
  commission_type          text not null,
  commission_value         numeric not null,
  renter_commission_type   text not null default 'percent',
  renter_commission_value  numeric not null default 0,
  status                   text not null default 'available',
  rented_via               text,
  rented_at                timestamptz,
  created_at               timestamptz not null default now()
);
create index if not exists rooms_created_at_idx on rooms (created_at desc);
create index if not exists rooms_owner_id_idx on rooms (owner_id);
create index if not exists rooms_status_idx on rooms (status);

create table if not exists leads (
  id           serial primary key,
  room_id      text not null,
  referrer_id  text not null,
  viewer_id    text not null,
  created_at   timestamptz not null default now()
);
create index if not exists leads_room_id_idx on leads (room_id);
create unique index if not exists leads_unique_idx on leads (room_id, referrer_id, viewer_id);

create table if not exists commissions (
  id           serial primary key,
  room_id      text not null,
  room_title   text not null,
  referrer_id  text not null,
  amount       numeric not null,
  currency     text not null default '',
  status       text not null default 'pending',
  created_at   timestamptz not null default now()
);
create index if not exists commissions_referrer_id_idx on commissions (referrer_id);
create index if not exists commissions_room_id_idx on commissions (room_id);

create table if not exists contact_reveals (
  id          serial primary key,
  user_id     text not null,
  room_id     text not null,
  created_at  timestamptz not null default now()
);
create index if not exists contact_reveals_user_time_idx on contact_reveals (user_id, created_at);
