-- ديوان تسيير شهادة البكالوريا — مرجع الشعب والمواد، الثانويات، المترشحون، العلامات، النتائج

create table if not exists streams (
  id serial primary key,
  code text not null unique,
  name_ar text not null
);

create table if not exists subjects (
  id serial primary key,
  code text not null unique,
  name_ar text not null
);

create table if not exists stream_subjects (
  stream_id int not null references streams (id) on delete cascade,
  subject_id int not null references subjects (id) on delete cascade,
  coefficient numeric(4,1) not null,
  primary key (stream_id, subject_id)
);

create table if not exists schools (
  id serial primary key,
  name text not null,
  wilaya text not null,
  created_at timestamptz not null default now()
);

create table if not exists exam_sessions (
  id serial primary key,
  year int not null,
  kind text not null,
  label_ar text not null,
  unique (year, kind)
);

create table if not exists students (
  id serial primary key,
  exam_number text not null unique,
  first_name text not null,
  last_name text not null,
  birth_date date not null,
  birth_place text not null,
  gender text not null,
  school_id int not null references schools (id),
  stream_id int not null references streams (id),
  session_id int not null references exam_sessions (id),
  created_at timestamptz not null default now()
);

create table if not exists grades (
  id serial primary key,
  student_id int not null references students (id) on delete cascade,
  subject_id int not null references subjects (id),
  score numeric(4,2) not null check (score >= 0 and score <= 20),
  unique (student_id, subject_id)
);

create table if not exists results (
  student_id int primary key references students (id) on delete cascade,
  average numeric(5,2) not null,
  mention text not null,
  decision text not null,
  certificate_number text unique,
  issued_at timestamptz
);

create index if not exists students_stream_id_idx on students (stream_id);
create index if not exists students_school_id_idx on students (school_id);
create index if not exists students_session_id_idx on students (session_id);
create index if not exists students_last_name_idx on students (last_name);
create index if not exists results_decision_idx on results (decision);
create index if not exists results_mention_idx on results (mention);

insert into streams (code, name_ar) values
  ('SCI', 'علوم تجريبية'),
  ('MATH', 'رياضيات'),
  ('TM', 'تقني رياضي'),
  ('GE', 'تسيير واقتصاد'),
  ('LIT', 'آداب وفلسفة'),
  ('LANG', 'لغات أجنبية');

insert into subjects (code, name_ar) values
  ('MATH', 'الرياضيات'),
  ('PHY', 'الفيزياء والكيمياء'),
  ('SNV', 'علوم الطبيعة والحياة'),
  ('AR', 'اللغة العربية'),
  ('FR', 'اللغة الفرنسية'),
  ('EN', 'اللغة الإنجليزية'),
  ('DE', 'اللغة الألمانية'),
  ('HG', 'التاريخ والجغرافيا'),
  ('ISL', 'العلوم الإسلامية'),
  ('PHIL', 'الفلسفة'),
  ('SPORT', 'التربية البدنية'),
  ('GMF', 'التسيير المحاسبي والمالي'),
  ('ECO', 'الاقتصاد والمناجمنت'),
  ('LAW', 'القانون'),
  ('TECH', 'التكنولوجيا');

insert into stream_subjects (stream_id, subject_id, coefficient)
select s.id, sub.id, v.coef
from (values
  ('SCI', 'MATH', 5.0), ('SCI', 'PHY', 5.0), ('SCI', 'SNV', 6.0), ('SCI', 'AR', 3.0),
  ('SCI', 'FR', 2.0), ('SCI', 'EN', 2.0), ('SCI', 'HG', 2.0), ('SCI', 'ISL', 2.0),
  ('SCI', 'PHIL', 2.0), ('SCI', 'SPORT', 1.0),
  ('MATH', 'MATH', 7.0), ('MATH', 'PHY', 6.0), ('MATH', 'SNV', 2.0), ('MATH', 'AR', 3.0),
  ('MATH', 'FR', 2.0), ('MATH', 'EN', 2.0), ('MATH', 'HG', 2.0), ('MATH', 'ISL', 2.0),
  ('MATH', 'PHIL', 2.0), ('MATH', 'SPORT', 1.0),
  ('TM', 'MATH', 6.0), ('TM', 'PHY', 6.0), ('TM', 'TECH', 7.0), ('TM', 'AR', 2.0),
  ('TM', 'FR', 2.0), ('TM', 'EN', 2.0), ('TM', 'HG', 2.0), ('TM', 'ISL', 2.0),
  ('TM', 'PHIL', 2.0), ('TM', 'SPORT', 1.0),
  ('GE', 'GMF', 6.0), ('GE', 'ECO', 5.0), ('GE', 'MATH', 5.0), ('GE', 'LAW', 2.0),
  ('GE', 'HG', 3.0), ('GE', 'AR', 3.0), ('GE', 'FR', 2.0), ('GE', 'EN', 2.0),
  ('GE', 'ISL', 2.0), ('GE', 'PHIL', 2.0), ('GE', 'SPORT', 1.0),
  ('LIT', 'AR', 6.0), ('LIT', 'PHIL', 6.0), ('LIT', 'HG', 4.0), ('LIT', 'FR', 3.0),
  ('LIT', 'EN', 3.0), ('LIT', 'ISL', 2.0), ('LIT', 'MATH', 2.0), ('LIT', 'SPORT', 1.0),
  ('LANG', 'AR', 3.0), ('LANG', 'FR', 5.0), ('LANG', 'EN', 5.0), ('LANG', 'DE', 4.0),
  ('LANG', 'PHIL', 2.0), ('LANG', 'HG', 2.0), ('LANG', 'ISL', 2.0), ('LANG', 'MATH', 2.0),
  ('LANG', 'SPORT', 1.0)
) as v(stream_code, subject_code, coef)
join streams s on s.code = v.stream_code
join subjects sub on sub.code = v.subject_code;

insert into schools (name, wilaya) values
  ('ثانوية الأمير عبد القادر', 'الجزائر'),
  ('ثانوية ابن خلدون', 'وهران'),
  ('ثانوية الإخوة عباس', 'قسنطينة'),
  ('ثانوية مولود معمري', 'تيزي وزو'),
  ('ثانوية العقيد لطفي', 'وهران'),
  ('ثانوية عائشة أم المؤمنين', 'سطيف');

insert into exam_sessions (year, kind, label_ar) values
  (2025, 'normale', 'الدورة العادية — جوان 2025');

insert into students (
  exam_number, first_name, last_name, birth_date, birth_place, gender,
  school_id, stream_id, session_id
)
select
  v.exam_number, v.first_name, v.last_name, v.birth_date::date, v.birth_place, v.gender,
  sch.id, st.id, ses.id
from (values
  ('2025-100001', 'ياسين', 'بن عمر', '2007-03-12', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'SCI'),
  ('2025-100002', 'أمينة', 'بوزيد', '2007-07-21', 'وهران', 'female', 'ثانوية ابن خلدون', 'SCI'),
  ('2025-100003', 'محمد', 'لخضر', '2006-11-04', 'قسنطينة', 'male', 'ثانوية الإخوة عباس', 'SCI'),
  ('2025-100004', 'سارة', 'مرابط', '2007-01-18', 'تيزي وزو', 'female', 'ثانوية مولود معمري', 'MATH'),
  ('2025-100005', 'كريم', 'حداد', '2007-05-09', 'وهران', 'male', 'ثانوية العقيد لطفي', 'MATH'),
  ('2025-100006', 'ندى', 'بلقاسم', '2006-09-30', 'سطيف', 'female', 'ثانوية عائشة أم المؤمنين', 'MATH'),
  ('2025-100007', 'علي', 'بن صالح', '2007-02-14', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'GE'),
  ('2025-100008', 'ليلى', 'عثماني', '2007-08-02', 'وهران', 'female', 'ثانوية ابن خلدون', 'GE'),
  ('2025-100009', 'حمزة', 'قريشي', '2006-12-19', 'قسنطينة', 'male', 'ثانوية الإخوة عباس', 'GE'),
  ('2025-100010', 'فاطمة الزهراء', 'بن عيسى', '2007-04-25', 'تيزي وزو', 'female', 'ثانوية مولود معمري', 'LIT'),
  ('2025-100011', 'رضا', 'مسعودي', '2007-06-11', 'وهران', 'male', 'ثانوية العقيد لطفي', 'LIT'),
  ('2025-100012', 'إيناس', 'شريف', '2006-10-07', 'سطيف', 'female', 'ثانوية عائشة أم المؤمنين', 'LIT'),
  ('2025-100013', 'يوسف', 'عباسي', '2007-03-03', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'LANG'),
  ('2025-100014', 'مريم', 'تواتي', '2007-09-16', 'وهران', 'female', 'ثانوية ابن خلدون', 'LANG'),
  ('2025-100015', 'عادل', 'بوطالب', '2006-08-28', 'قسنطينة', 'male', 'ثانوية الإخوة عباس', 'TM'),
  ('2025-100016', 'خديجة', 'عماري', '2007-01-05', 'تيزي وزو', 'female', 'ثانوية مولود معمري', 'TM'),
  ('2025-100017', 'إسماعيل', 'زروال', '2007-05-22', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'SCI'),
  ('2025-100018', 'هدى', 'بن عيسى', '2006-07-13', 'سطيف', 'female', 'ثانوية عائشة أم المؤمنين', 'MATH')
) as v(exam_number, first_name, last_name, birth_date, birth_place, gender, school_name, stream_code)
join schools sch on sch.name = v.school_name
join streams st on st.code = v.stream_code
cross join exam_sessions ses;

insert into grades (student_id, subject_id, score)
select
  s.id,
  ss.subject_id,
  round(
    least(20, greatest(2,
      t.target + ((((ss.subject_id * 5) + (s.id * 3)) % 9) - 4) * 0.55
    ))::numeric,
    2
  )
from students s
join stream_subjects ss on ss.stream_id = s.stream_id
join (values
  ('2025-100001', 16.80),
  ('2025-100002', 14.40),
  ('2025-100003', 11.20),
  ('2025-100004', 17.10),
  ('2025-100005', 13.10),
  ('2025-100006', 8.60),
  ('2025-100007', 15.40),
  ('2025-100008', 12.30),
  ('2025-100009', 8.40),
  ('2025-100010', 16.70),
  ('2025-100011', 11.10),
  ('2025-100012', 13.50),
  ('2025-100013', 14.90),
  ('2025-100014', 10.20),
  ('2025-100015', 15.80),
  ('2025-100016', 12.10),
  ('2025-100017', 18.10),
  ('2025-100018', 10.40)
) as t(exam_number, target) on t.exam_number = s.exam_number;

insert into results (student_id, average, mention, decision, certificate_number, issued_at)
select
  s.id,
  a.avg,
  case
    when a.avg >= 16 then 'امتياز'
    when a.avg >= 14 then 'جيد جداً'
    when a.avg >= 12 then 'جيد'
    when a.avg >= 10 then 'قريب من الجيد'
    else 'بدون تقدير'
  end,
  case when a.avg >= 10 then 'ناجح' else 'راسب' end,
  case when a.avg >= 10 then 'BAC/2025/' || lpad(s.id::text, 5, '0') else null end,
  case when a.avg >= 10 then now() else null end
from students s
join (
  select
    g.student_id,
    round(
      (sum(g.score * ss.coefficient) / nullif(sum(ss.coefficient), 0))::numeric,
      2
    ) as avg
  from grades g
  join students st on st.id = g.student_id
  join stream_subjects ss
    on ss.stream_id = st.stream_id and ss.subject_id = g.subject_id
  group by g.student_id
) a on a.student_id = s.id;
