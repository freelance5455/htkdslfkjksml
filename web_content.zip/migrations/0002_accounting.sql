create table if not exists companies (
  user_id text primary key,
  name text not null default 'شرکت خراسانی',
  legal_name text not null default 'MR,KHORASANI',
  fiscal_year_code text not null default '1405',
  sales_shipping text not null default 'income',
  purchase_shipping text not null default 'inventory',
  inventory_method text not null default 'perpetual',
  role text not null default 'admin',
  seeded boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists fiscal_years (
  id text primary key,
  user_id text not null,
  code text not null,
  title text not null,
  start_date date not null,
  end_date date not null,
  status text not null default 'open',
  unique (user_id, code)
);
create index if not exists fiscal_years_user_idx on fiscal_years (user_id);

create table if not exists accounts (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  level int not null,
  parent_id text,
  type text not null,
  nature text not null,
  is_cash boolean not null default false,
  is_bank boolean not null default false,
  is_party boolean not null default false,
  party_kind text,
  is_active boolean not null default true,
  unique (user_id, code)
);
create index if not exists accounts_user_idx on accounts (user_id);

create table if not exists parties (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  trade_name text not null default '',
  phone text not null default '',
  mobile text not null default '',
  address text not null default '',
  national_id text not null default '',
  is_customer boolean not null default false,
  is_supplier boolean not null default false,
  is_employee boolean not null default false,
  is_partner boolean not null default false,
  is_other boolean not null default false,
  is_active boolean not null default true,
  notes text not null default '',
  created_at timestamptz not null default now(),
  unique (user_id, code)
);
create index if not exists parties_user_idx on parties (user_id);

create table if not exists items (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  barcode text not null default '',
  unit text not null default 'عدد',
  category text not null default '',
  subcategory text not null default '',
  purchase_price numeric(18,0) not null default 0,
  sale_price numeric(18,0) not null default 0,
  is_active boolean not null default true,
  notes text not null default '',
  unique (user_id, code)
);
create index if not exists items_user_idx on items (user_id);

create table if not exists financial_sources (
  id text primary key,
  user_id text not null,
  kind text not null,
  name text not null,
  bank_name text not null default '',
  branch text not null default '',
  account_no text not null default '',
  iban text not null default '',
  card_no text not null default '',
  account_id text not null,
  opening_date date,
  is_active boolean not null default true,
  notes text not null default ''
);
create index if not exists financial_sources_user_idx on financial_sources (user_id);

create table if not exists operations (
  id text primary key,
  user_id text not null,
  number text not null,
  type text not null,
  date date not null,
  jalali_date text not null,
  party_id text,
  source_id text,
  dest_source_id text,
  description text not null default '',
  amount numeric(18,0) not null default 0,
  shipping numeric(18,0) not null default 0,
  discount_amount numeric(18,0) not null default 0,
  discount_percent numeric(8,2) not null default 0,
  discount_mode text not null default 'percent',
  gross_amount numeric(18,0) not null default 0,
  net_amount numeric(18,0) not null default 0,
  settlement text not null default 'cash',
  cash_amount numeric(18,0) not null default 0,
  status text not null default 'posted',
  journal_id text,
  fiscal_year_code text not null,
  invoice_no text not null default '',
  related_operation_id text,
  original_journal_id text,
  expense_account_code text,
  income_account_code text,
  check_number text,
  check_due_date date,
  version int not null default 1,
  created_by text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  deleted_at timestamptz,
  deleted_by text,
  delete_reason text,
  unique (user_id, number)
);
create index if not exists operations_user_date_idx on operations (user_id, date);
create index if not exists operations_user_type_idx on operations (user_id, type);

create table if not exists operation_lines (
  id text primary key,
  user_id text not null,
  operation_id text not null,
  item_id text,
  description text not null default '',
  qty numeric(18,3) not null default 1,
  unit_price numeric(18,0) not null default 0,
  line_amount numeric(18,0) not null default 0,
  sort_order int not null default 0
);
create index if not exists operation_lines_op_idx on operation_lines (operation_id);

create table if not exists journals (
  id text primary key,
  user_id text not null,
  number text not null,
  date date not null,
  jalali_date text not null,
  description text not null default '',
  operation_id text,
  operation_type text,
  kind text not null default 'normal',
  original_journal_id text,
  status text not null default 'posted',
  fiscal_year_code text not null,
  day_status text not null default 'open',
  created_by text not null default '',
  created_at timestamptz not null default now(),
  unique (user_id, number)
);
create index if not exists journals_user_date_idx on journals (user_id, date);

create table if not exists journal_lines (
  id text primary key,
  user_id text not null,
  journal_id text not null,
  account_id text not null,
  party_id text,
  source_id text,
  description text not null default '',
  debit numeric(18,0) not null default 0,
  credit numeric(18,0) not null default 0,
  sort_order int not null default 0
);
create index if not exists journal_lines_journal_idx on journal_lines (journal_id);
create index if not exists journal_lines_account_idx on journal_lines (user_id, account_id);
create index if not exists journal_lines_party_idx on journal_lines (user_id, party_id);

create table if not exists checks (
  id text primary key,
  user_id text not null,
  number text not null,
  kind text not null,
  party_id text,
  bank_source_id text,
  amount numeric(18,0) not null,
  issue_date date,
  due_date date,
  status text not null,
  operation_id text,
  jalali_issue text not null default '',
  jalali_due text not null default ''
);
create index if not exists checks_user_idx on checks (user_id);

create table if not exists daily_closings (
  id text primary key,
  user_id text not null,
  date date not null,
  jalali_date text not null,
  status text not null default 'closed',
  closed_by text not null default '',
  closed_at timestamptz not null default now(),
  backup_id text,
  package jsonb,
  unique (user_id, date)
);

create table if not exists reopen_requests (
  id text primary key,
  user_id text not null,
  date date not null,
  reason text not null,
  status text not null default 'pending',
  requested_by text not null default '',
  decided_by text,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id text primary key,
  user_id text not null,
  action text not null,
  entity text not null default '',
  entity_id text not null default '',
  old_value jsonb,
  new_value jsonb,
  reason text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_user_idx on audit_logs (user_id, created_at desc);

create table if not exists backups (
  id text primary key,
  user_id text not null,
  name text not null,
  kind text not null default 'manual',
  payload jsonb not null,
  created_at timestamptz not null default now()
);
create index if not exists backups_user_idx on backups (user_id, created_at desc);
