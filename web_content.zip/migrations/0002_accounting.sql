-- MR,KHORASANI double-entry books. All tenant rows scoped by user_id (text).

create table if not exists company_settings (
  user_id text primary key,
  company_name text not null default 'بازرگانی خراسانی',
  company_name_en text not null default 'MR,KHORASANI',
  currency text not null default 'IRR',
  display_unit text not null default 'rial',
  perpetual_inventory boolean not null default false,
  seeded boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists fiscal_years (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  start_date date not null,
  end_date date not null,
  status text not null default 'open',
  is_current boolean not null default true
);
create index if not exists fiscal_years_user_idx on fiscal_years (user_id);

create table if not exists accounts (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  level int not null,
  parent_id text,
  group_code text not null,
  nature text not null,
  is_postable boolean not null default false,
  is_active boolean not null default true,
  floating_type text not null default 'none'
);
create unique index if not exists accounts_user_code_idx on accounts (user_id, code);
create index if not exists accounts_user_idx on accounts (user_id);

create table if not exists parties (
  id text primary key,
  user_id text not null,
  code text not null,
  name text not null,
  kind text not null,
  phone text,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists parties_user_code_idx on parties (user_id, code);
create index if not exists parties_user_idx on parties (user_id);

create table if not exists cash_accounts (
  id text primary key,
  user_id text not null,
  account_id text not null,
  name text not null,
  kind text not null,
  bank_name text,
  account_number text,
  is_active boolean not null default true
);
create index if not exists cash_accounts_user_idx on cash_accounts (user_id);

create table if not exists fiscal_days (
  id text primary key,
  user_id text not null,
  fiscal_year_id text not null,
  day_date date not null,
  status text not null default 'open',
  unique (user_id, day_date)
);
create index if not exists fiscal_days_user_idx on fiscal_days (user_id, day_date);

create table if not exists sequences (
  user_id text not null,
  fiscal_year_id text not null,
  kind text not null,
  last_value int not null default 0,
  primary key (user_id, fiscal_year_id, kind)
);

create table if not exists operations (
  id text primary key,
  user_id text not null,
  fiscal_year_id text not null,
  day_id text not null,
  number text not null,
  op_type text not null,
  op_date date not null,
  description text,
  party_id text,
  cash_account_id text,
  dest_cash_account_id text,
  amount numeric(18,0) not null,
  status text not null default 'posted',
  journal_id text,
  original_id text,
  extra_json text,
  created_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  deleted_by text,
  delete_reason text,
  version int not null default 1
);
create unique index if not exists operations_user_number_idx on operations (user_id, number);
create index if not exists operations_user_date_idx on operations (user_id, op_date);
create index if not exists operations_user_status_idx on operations (user_id, status);

create table if not exists journals (
  id text primary key,
  user_id text not null,
  fiscal_year_id text not null,
  day_id text not null,
  number text not null,
  journal_date date not null,
  description text,
  journal_type text not null default 'auto',
  operation_id text,
  original_journal_id text,
  status text not null default 'posted',
  created_by text not null,
  created_at timestamptz not null default now()
);
create unique index if not exists journals_user_number_idx on journals (user_id, number);
create index if not exists journals_user_date_idx on journals (user_id, journal_date);
create index if not exists journals_user_status_idx on journals (user_id, status);

create table if not exists journal_lines (
  id text primary key,
  user_id text not null,
  journal_id text not null,
  line_no int not null,
  account_id text not null,
  party_id text,
  cash_account_id text,
  debit numeric(18,0) not null default 0,
  credit numeric(18,0) not null default 0,
  description text
);
create index if not exists journal_lines_journal_idx on journal_lines (journal_id);
create index if not exists journal_lines_user_account_idx on journal_lines (user_id, account_id);
create index if not exists journal_lines_user_party_idx on journal_lines (user_id, party_id);

create table if not exists checks (
  id text primary key,
  user_id text not null,
  number text not null,
  kind text not null,
  party_id text,
  bank_name text,
  amount numeric(18,0) not null,
  issue_date date,
  due_date date,
  status text not null,
  operation_id text
);
create index if not exists checks_user_idx on checks (user_id);

create table if not exists daily_closings (
  id text primary key,
  user_id text not null,
  day_id text not null,
  closed_at timestamptz not null default now(),
  closed_by text not null,
  package_json text not null,
  backup_name text not null
);
create index if not exists daily_closings_user_idx on daily_closings (user_id);

create table if not exists audit_logs (
  id text primary key,
  user_id text not null,
  actor_id text not null,
  actor_name text,
  occurred_at timestamptz not null default now(),
  action text not null,
  entity text not null,
  entity_id text,
  old_value text,
  new_value text,
  reason text
);
create index if not exists audit_logs_user_idx on audit_logs (user_id, occurred_at desc);

create table if not exists sync_queue (
  id text primary key,
  user_id text not null,
  payload_json text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  error text
);
create index if not exists sync_queue_user_idx on sync_queue (user_id, status);
