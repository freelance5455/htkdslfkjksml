-- Additive and repeatable: protects voice credit charges and refunds from retries.
CREATE TABLE IF NOT EXISTS voice_request_keys (
    user_id INTEGER NOT NULL,
    request_key VARCHAR(100) NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, request_key)
);
CREATE TABLE IF NOT EXISTS voice_refunds (
    user_id INTEGER NOT NULL,
    request_key VARCHAR(100) NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, request_key)
);
