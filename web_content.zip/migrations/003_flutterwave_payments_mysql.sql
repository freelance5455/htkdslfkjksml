-- Additive ANONYMOUX 2.4.0 migration. Does not alter existing users or wallet rows.
CREATE TABLE IF NOT EXISTS admin_bootstrap_lock (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB;
INSERT IGNORE INTO admin_bootstrap_lock(id, created_at) VALUES (1, CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS credit_packages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  price_minor BIGINT NOT NULL,
  credits BIGINT NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_packages_active(is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_orders (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  package_id BIGINT UNSIGNED NOT NULL,
  reference VARCHAR(100) NOT NULL UNIQUE,
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  credits BIGINT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  provider_transaction_id VARCHAR(100) NULL UNIQUE,
  provider_status VARCHAR(40) NULL,
  verified_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_payment_orders_user(user_id, created_at),
  KEY idx_payment_orders_status(status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
