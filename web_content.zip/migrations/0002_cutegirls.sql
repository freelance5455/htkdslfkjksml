create table if not exists profiles (
  user_id text primary key,
  username text not null,
  youtube_url text not null,
  bio text not null default '',
  avatar text,
  banner text,
  role text not null,
  created_at timestamptz not null default now(),
  constraint profiles_role_chk check (role in ('listener', 'creator'))
);

create unique index if not exists profiles_username_lower_idx on profiles (lower(username));

create table if not exists follows (
  follower_id text not null,
  following_id text not null,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  constraint follows_not_self check (follower_id <> following_id)
);

create index if not exists follows_following_idx on follows (following_id);

create table if not exists groups (
  slug text primary key,
  name text not null,
  blurb text not null,
  forced boolean not null default false,
  sort int not null default 0
);

create table if not exists group_members (
  group_slug text not null references groups (slug),
  user_id text not null,
  joined_at timestamptz not null default now(),
  primary key (group_slug, user_id)
);

create table if not exists posts (
  id text primary key,
  user_id text not null,
  kind text not null,
  title text not null default '',
  body text not null default '',
  media text,
  link text,
  group_slug text references groups (slug),
  created_at timestamptz not null default now(),
  constraint posts_kind_chk check (kind in ('vent', 'contest', 'info', 'news', 'reel', 'subliminal'))
);

create index if not exists posts_created_idx on posts (created_at desc);
create index if not exists posts_kind_idx on posts (kind, created_at desc);
create index if not exists posts_group_idx on posts (group_slug, created_at desc);
create index if not exists posts_user_idx on posts (user_id, created_at desc);

create table if not exists reactions (
  post_id text not null references posts (id) on delete cascade,
  user_id text not null,
  kind text not null,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists comments (
  id text primary key,
  post_id text not null references posts (id) on delete cascade,
  user_id text not null,
  body text not null default '',
  sticker text,
  created_at timestamptz not null default now()
);

create index if not exists comments_post_idx on comments (post_id, created_at);

insert into groups (slug, name, blurb, forced, sort) values
  ('everyone', 'الجماعة الشاملة', 'مساحة كل من في الصالون. الانضمام تلقائي ولا يمكن مغادرتها.', true, 0),
  ('family', 'العائلة البيولوجية', 'ركن دافئ لمن يختار رابطة العائلة. الدخول فوري بلا موافقة.', false, 1),
  ('yandere', 'الخاطف/يانديري/ملاحق', 'غرفة أدوار خيالية بطابع درامي. الدخول فوري، والكلام يبقى داخل إطار اللعب.', false, 2),
  ('suitor', 'الخاطب', 'لرسائل الإعجاب والخطوبة بأسلوب هادئ. الدخول فوري.', false, 3)
on conflict (slug) do nothing;
