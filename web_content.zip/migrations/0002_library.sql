-- Good Health Reader: profiles, shared shelf, review shorts, and messages.

create table if not exists profiles (
  user_id text primary key,
  public_id text not null unique,
  display_name text not null,
  bio text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists books (
  id text primary key,
  owner_id text not null,
  title text not null,
  writer text not null,
  pdf_data text,
  essay text,
  is_catalog boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists books_owner_idx on books (owner_id);

create table if not exists book_opens (
  id text primary key,
  user_id text not null,
  book_id text not null,
  opened_at timestamptz not null default now()
);

create index if not exists book_opens_user_idx on book_opens (user_id);

create table if not exists shorts (
  id text primary key,
  owner_id text not null,
  title text not null,
  description text not null default '',
  video_embed text,
  video_href text,
  media_data text,
  media_kind text,
  is_catalog boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists shorts_owner_idx on shorts (owner_id);

create table if not exists messages (
  id text primary key,
  sender_id text not null,
  recipient_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create index if not exists messages_sender_idx on messages (sender_id);
create index if not exists messages_recipient_idx on messages (recipient_id);

insert into books (id, owner_id, title, writer, essay, is_catalog) values
(
  'cat-morning',
  'catalog',
  'Morning Light',
  'Good Health Editors',
  $ghr1$This pamphlet is original reading for the Good Health Reader shelf. It is general writing, not medical advice. If you are ill, talk with a clinician you trust.

A day that starts kindly is easier to keep. Before you reach for a screen, let daylight find your eyes. Open a curtain, step onto a balcony, or walk as far as the end of the street. Morning light tells the body what time it is, and that small signal makes the evening easier.

Drink a glass of water before coffee if you can. Not because water is a miracle, but because most of us wake a little dry. Then eat something with substance: fruit and yogurt, eggs and bread, oats, leftover rice with vegetables. A sweet drink on an empty stomach is a fast spike and a faster crash. You do not need a perfect breakfast. You need one that will still be with you at midmorning.

Move for a few minutes before the day claims you. A slow walk counts. So do stairs, stretching beside the bed, or dancing while the kettle boils. The aim is not a performance. The aim is to remind your joints that they have a job.

Protect the first quiet hour if your life allows it. Messages can wait twelve minutes. Use that pocket to read two pages, write one honest sentence, or sit without a task. People who read a little in the morning often find the rest of the day less loud, not because the world improved, but because they arrived already themselves.

Through the afternoon, notice thirst, hunger, and the urge to hunch. Stand up once an hour. Look farther than your screen so your eyes can change focus. If you work seated, put both feet on the floor and let your shoulders drop. These are small repairs. They add up.

Evening is when health is usually lost or kept. Dim the bright overheads. Eat early enough that you are not negotiating with a full stomach at midnight. Leave the phone to charge outside the pillow if you can. Sleep is not a prize for finishing everything. It is the work that lets tomorrow's reading happen.

Keep a tiny log for a week: bedtime, wake time, one walk, one real meal. Do not grade yourself. Patterns are more useful than guilt. When something hurts for more than a few days, or when your mood drops and stays down, ask for help. A shelf of good books is a companion. It is not a doctor.

Return to this pamphlet when the week gets sharp. Open the curtain. Drink the water. Read two pages. That is a morning.$ghr1$,
  true
),
(
  'cat-pulse',
  'catalog',
  'The Quiet Pulse',
  'Good Health Editors',
  $ghr2$This pamphlet is original reading for the Good Health Reader shelf. It is general writing, not medical advice.

Attention is a kind of health. It frays the way a muscle frays, quietly, then all at once. This short guide is about putting a little of it back, without turning your life into a project.

Begin with the breath you already have. Sit with both feet down. Breathe in through the nose for a comfortable count of four, and out for a count of six. Do that five times. You are not trying to become calm on command. You are giving the nervous system a slower rhythm to copy. If your mind leaves, that is not failure. Bring it back the way you bring a finger back to a line of text.

Notice the next time you pick up your phone without deciding to. Pause with the screen still dark. Ask one question: what did I come here for? If you have an answer, do that one thing and leave. If you do not, set the phone down and return to the room you are actually in. This sounds severe. It is only a door you can use.

Reading is practice for this. A page asks you to stay. When you notice you have scanned three paragraphs and retained nothing, stop. Reread the last sentence aloud, softly. Speed is a poor measure of a reader. Staying is the skill.

Bodies keep the score of hurried days in the jaw, the belly, and the space between the eyes. Once in the afternoon, unclench your teeth. Drop your tongue from the roof of your mouth. Let the breath out longer than the breath in. Thirty seconds is enough to change the next conversation you have.

Worry likes an open loop. When a fear arrives, write it in one sentence and the next physical step under it, even if the step is "ask someone who knows." Then close the note. You can return at a set time. You do not have to carry the sentence in your mouth all day.

Company matters. Send one specific message to a person you like: not "we should catch up," but a real detail you remembered. Loneliness is a health risk the way smoke is, slow and ordinary. A library, even a digital one, is a place to be among other readers. Use the chat when you want a human reply. Use the page when you want quiet.

If anxiety or sadness pins you down most days, reading about breathing is not the treatment. Tell a friend and a clinician. Courage here is practical. It is making the appointment.

The quiet pulse is not silence. It is the feeling that you are in your own day, not being dragged behind it. Five breaths. One page. One honest message. Repeat tomorrow.$ghr2$,
  true
),
(
  'cat-neighborhood',
  'catalog',
  'A Neighborhood of Small Habits',
  'Good Health Editors',
  $ghr3$This pamphlet is original reading for the Good Health Reader shelf. It is general writing, not medical advice.

Health is partly private and partly shared. Your sleep is yours. The air in a stairwell, the soap by a sink, and the way a street feels after dark belong to everyone who uses them. This reader is about the small public habits that make a neighborhood kinder to live in.

Wash your hands with soap when you come home, before you cook, and after you have been around someone who is ill. It is an old instruction because it keeps working. Cover a cough with your elbow. Stay home from a crowded room when you are feverish if your work allows it. You protect people you will never meet.

Know where help is before you need it. Save the number of a nearby clinic, a night pharmacy, and a person who would answer if you called at an odd hour. Put a paper copy in a drawer. Phones die. Emergencies do not wait for a signal.

Keep a modest home kit: soap, clean cloth, oral rehydration salts, any medicine you already take, and a list of those medicines written in plain language. Check dates twice a year. Throw out what has expired. A kit is not a hospital. It stops a small problem from becoming a panicked one.

Water and food safety are unglamorous and decisive. If the tap is unsafe, boil or use a method your local health office recommends. Refrigerate cooked food promptly. When you are unsure whether a dish is still good, let it go. Pride is more expensive than a pot of rice.

Streets are health equipment. A walk to buy bread is exercise, sunlight, and a chance to see whether a neighbor's routine has changed. If someone older on your stair has not appeared for a few days, knock once. Offer practical help: a jug of water, a ride, a phone call they have been postponing. Do not take over their choices.

Share books the way you would share a kitchen: only what you have a right to pass on. Upload your own notes, public-domain texts, and files you created or were given permission to share. A social library stays alive when readers are careful with other people's work.

Public health is a chain of ordinary decisions. Soap. Rest when you are infectious. A saved phone number. A walk. A book you actually had the right to place on the shelf. None of these will trend. All of them keep a place livable.

Read this again with someone in your building. Then ask what your stairwell still needs. The answer is usually smaller than you fear, and more useful than a slogan.$ghr3$,
  true
);

insert into shorts (id, owner_id, title, description, is_catalog) values
(
  'cat-note',
  'catalog',
  'How this shelf works',
  'A note from the editors. Read the pamphlets, upload only PDFs you have the right to share, and post a short review when a book stays with you. Your reader ID is how other people find you in chat.',
  true
),
(
  'cat-morning-note',
  'catalog',
  'A margin note on Morning Light',
  'We wrote Morning Light as a one-sitting pamphlet: daylight, water, a real breakfast, and a phone that can wait twelve minutes. It is a companion, not a clinic. If a habit in it does not fit your life, keep the ones that do.',
  true
);
