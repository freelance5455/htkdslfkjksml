create table if not exists projects (
  id text primary key,
  user_id text not null,
  name text not null,
  doc text not null,
  updated_at timestamptz not null default now()
);

create index if not exists projects_user_updated_idx on projects (user_id, updated_at desc);
