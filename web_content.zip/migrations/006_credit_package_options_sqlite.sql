-- Additive 2.5.5 package configuration fields. Existing package prices and purchases are preserved.
ALTER TABLE credit_packages ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 100;
ALTER TABLE credit_packages ADD COLUMN promo_badge TEXT NOT NULL DEFAULT '';
ALTER TABLE credit_packages ADD COLUMN bonus_credits INTEGER NOT NULL DEFAULT 0;
