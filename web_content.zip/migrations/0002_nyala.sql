create table if not exists profiles (
  user_id text primary key,
  display_name text not null,
  bio text not null default '',
  coins integer not null default 800,
  earned integer not null default 0,
  claimed_on date,
  created_at timestamptz not null default now()
);

create table if not exists live_rooms (
  id text primary key,
  host_id text not null,
  host_peer text not null default '',
  title text not null,
  topic text not null,
  mode text not null default 'video',
  status text not null default 'live',
  hearts integer not null default 0,
  gifts_value integer not null default 0,
  pinned text not null default '',
  battle_id text,
  started_at timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
create index if not exists live_rooms_status_seen_idx on live_rooms (status, last_seen desc);

create table if not exists room_presence (
  room_id text not null,
  user_id text not null,
  display_name text not null,
  last_seen timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists room_messages (
  id bigserial primary key,
  room_id text not null,
  user_id text not null,
  display_name text not null,
  kind text not null,
  body text not null,
  gift_id text,
  created_at timestamptz not null default now()
);
create index if not exists room_messages_room_idx on room_messages (room_id, id);

create table if not exists follows (
  follower_id text not null,
  host_id text not null,
  created_at timestamptz not null default now(),
  primary key (follower_id, host_id)
);
create index if not exists follows_host_idx on follows (host_id);

create table if not exists battles (
  id text primary key,
  room_a text not null,
  room_b text,
  host_a text not null,
  host_b text,
  name_a text not null,
  name_b text,
  score_a integer not null default 0,
  score_b integer not null default 0,
  ends_at timestamptz not null,
  created_at timestamptz not null default now()
);
