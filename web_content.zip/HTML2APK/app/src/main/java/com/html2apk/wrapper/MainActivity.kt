package com.html2apk.wrapper

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.html2apk.wrapper.databinding.ActivityMainBinding

/**
 * اکتیویتی اصلی: یک WebView تمام‌صفحه که محتوای HTML/CSS/JS را از
 * assets/www/index.html (یا در صورت تنظیم REMOTE_URL در BuildConfig، از آن
 * آدرس) بارگذاری می‌کند.
 *
 * ویژگی‌های «حس اپ بومی» که عمداً رعایت شده:
 *  - بدون bounce/overscroll لاستیکی (OVER_SCROLL_NEVER) — این همان چیزی است
 *    که معمولاً باعث می‌شود یک WebView حس "صفحهٔ وب" بدهد نه اپ واقعی.
 *  - بدون نوار اسکرول روی صفحه (کنترل از CSS/JS خودِ صفحه، نه مرورگر).
 *  - دکمهٔ Back سیستم اول تاریخچهٔ داخل WebView را برمی‌گرداند، بعد اپ را می‌بندد.
 *  - لینک‌های خارج از دامنه‌های مجاز در مرورگر بیرونی باز می‌شوند، نه داخل اپ.
 *  - اسپلش‌اسکرین استاندارد اندروید هنگام شروع اپ (androidx.core.splashscreen).
 *  - نوار پیشرفت نازک حین بارگذاری + صفحهٔ خطا/آفلاین با دکمهٔ تلاش دوباره.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var startUrl: String = ""

    private val fileChooserLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
            fileChooserCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
            fileChooserCallback = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // باید قبل از super.onCreate() فراخوانی شود (الزام androidx.core.splashscreen)
        installSplashScreen()

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val webView = binding.webView
        webView.overScrollMode = View.OVER_SCROLL_NEVER // بدون افکت لاستیکی هنگام اسکرول به انتها

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false // امنیت: دسترسی دلخواه به فایل‌سیستم نه، فقط assets
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val host = url.host ?: return false

                val isLocalAsset = url.scheme == "file"
                val isAllowedDomain = BuildConfig.ALLOWED_DOMAINS.any { domain ->
                    domain.isNotBlank() && (host == domain || host.endsWith(".$domain"))
                }

                return if (isLocalAsset || isAllowedDomain) {
                    false // داخل همین WebView باز شود
                } else {
                    // لینک خارجی: در مرورگر پیش‌فرض گوشی باز شود، نه داخل اپ
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                showContent() // اگر از حالت خطا دوباره تلاش می‌شود، صفحهٔ خطا را مخفی کن
                binding.progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                binding.progressBar.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                // فقط وقتی خودِ صفحهٔ اصلی لود نشد خطا نشان بده، نه هر زیرمنبع
                // کوچک (مثل یک آیکون یا فونت که لود نشده)
                if (request.isForMainFrame) {
                    showError()
                }
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    showError()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileChooserCallback = filePathCallback
                fileChooserLauncher.launch(fileChooserParams.acceptTypes.firstOrNull { it.isNotBlank() } ?: "*/*")
                return true
            }

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                binding.progressBar.progress = newProgress
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            val request = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mimeType)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType)
                )
            val downloadManager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            downloadManager.enqueue(request)
        }

        binding.retryButton.setOnClickListener {
            showContent()
            webView.loadUrl(startUrl)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        // تشخیص خودکار زبان سیستم گوشی (مثلاً "fa" یا "en") و پاس‌دادنش به
        // صفحهٔ وب از طریق querystring — صفحهٔ وب خودش تصمیم می‌گیرد با این
        // مقدار چه کند (نگاه کنید به web-example/index.html به‌عنوان نمونه).
        // این کار فقط برای محتوای محلی (assets) انجام می‌شود، نه remote_url،
        // چون یک سایت بیرونی ممکن است querystring ناخواسته را نادیده نگیرد.
        val systemLang = resources.configuration.locales[0].language // e.g. "fa", "en", "de"

        startUrl = if (BuildConfig.REMOTE_URL.isNotBlank()) {
            BuildConfig.REMOTE_URL
        } else {
            "file:///android_asset/www/index.html?lang=$systemLang"
        }
        webView.loadUrl(startUrl)
    }

    private fun showError() {
        binding.progressBar.visibility = View.GONE
        binding.webView.visibility = View.GONE
        binding.errorView.visibility = View.VISIBLE
    }

    private fun showContent() {
        binding.errorView.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        binding.webView.apply {
            clearHistory()
            destroy()
        }
        super.onDestroy()
    }
}
