#!/usr/bin/env python3
"""
generate_icons.py — ساخت آیکون‌های راستری (PNG) برای اندروید نسخه‌های قدیمی‌تر
(زیر API 26) که از adaptive icon (XML برداری) پشتیبانی نمی‌کنند.

برای اندروید ۸ به بالا، همان آیکون برداری در mipmap-anydpi-v26/ic_launcher.xml
کافی است و این اسکریپت کاری با آن ندارد. این فقط یک نسخهٔ راستری سازگار با
همان رنگ برند (از config.json) برای mipmap-mdpi تا mipmap-xxxhdpi می‌سازد تا
روی اندروید ۷ و ۷.۱ هم آیکون درست نمایش داده شود، نه آیکون پیش‌فرض اندروید.

استفاده: python3 generate_icons.py <res_dir> <primary_color_hex> <primary_color_dark_hex>
مثال:   python3 generate_icons.py app/src/main/res "#1E88E5" "#1565C0"
"""
import sys
import os
import math

try:
    from PIL import Image, ImageDraw
except ImportError:
    print("⚠️  Pillow نصب نیست؛ از آیکون‌های راستری موجود (یا پیش‌فرض) صرف‌نظر می‌شود.")
    print("   نصب با: pip install Pillow  (یا در ترموکس: pkg install python-pillow)")
    sys.exit(0)  # این یک خطای مرگبار نیست؛ بیلد می‌تواند بدون آن ادامه یابد

DENSITIES = {
    "mdpi": 48,
    "hdpi": 72,
    "xhdpi": 96,
    "xxhdpi": 144,
    "xxxhdpi": 192,
}


def hex_to_rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def draw_glyph(draw, size, color):
    """یک گلیف سادهٔ 'وب/شبکه' (شبیه کرهٔ زمین با نصف‌النهارها) می‌کشد —
    همخوان با طرح آیکون برداری اصلی پروژه."""
    cx, cy = size / 2, size / 2
    r = size * 0.32

    stroke = max(2, round(size * 0.035))

    # دایرهٔ بیرونی (کرهٔ زمین)
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=stroke)

    # خط استوا (افقی)
    draw.line([cx - r, cy, cx + r, cy], fill=color, width=stroke)

    # دو نصف‌النهار بیضی‌شکل (عمودی، باریک‌تر برای حس کروی‌بودن)
    draw.ellipse([cx - r * 0.45, cy - r, cx + r * 0.45, cy + r], outline=color, width=stroke)


def make_icon(size, bg_rgb, fg_rgb=(255, 255, 255)):
    scale = 4  # سوپرسمپل برای لبه‌های صاف‌تر
    big = size * scale
    img = Image.new("RGBA", (big, big), bg_rgb + (255,))
    draw = ImageDraw.Draw(img)
    draw_glyph(draw, big, fg_rgb + (255,))
    img = img.resize((size, size), Image.LANCZOS)
    return img


def main():
    if len(sys.argv) < 4:
        print("استفاده: generate_icons.py <res_dir> <primary_color_hex> <primary_color_dark_hex>")
        sys.exit(1)

    res_dir = sys.argv[1]
    primary = hex_to_rgb(sys.argv[2])

    for density, size in DENSITIES.items():
        out_dir = os.path.join(res_dir, f"mipmap-{density}")
        os.makedirs(out_dir, exist_ok=True)
        icon = make_icon(size, primary)
        icon.save(os.path.join(out_dir, "ic_launcher.png"))
        icon.save(os.path.join(out_dir, "ic_launcher_round.png"))

    print(f"✅ آیکون‌های راستری (API<26) با رنگ {sys.argv[2]} ساخته شدند.")


if __name__ == "__main__":
    main()
