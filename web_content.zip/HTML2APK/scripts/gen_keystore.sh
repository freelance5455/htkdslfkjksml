#!/usr/bin/env bash
# ------------------------------------------------------------------------
# ساخت خودکار یک کی‌استور امضای release، اگر از قبل وجود نداشته باشد.
# این کی‌استور همان چیزی است که برای امضای APK/AAB توزیع‌شده لازم است —
# حتماً آن را (و رمزهایش را) جایی امن و پشتیبان‌گیری‌شده نگه دارید؛ گم‌شدنش
# یعنی دیگر نمی‌توانید همان اپ را آپدیت کنید.
# ------------------------------------------------------------------------
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KEYSTORE_FILE="$PROJECT_ROOT/release.keystore"
PROPS_FILE="$PROJECT_ROOT/keystore.properties"

if [[ -f "$KEYSTORE_FILE" && -f "$PROPS_FILE" ]]; then
    echo "کی‌استور از قبل وجود دارد: $KEYSTORE_FILE — از آن استفاده می‌شود."
    exit 0
fi

echo "هیچ کی‌استوری پیدا نشد؛ یک کی‌استور جدید ساخته می‌شود..."

STORE_PASSWORD="$(openssl rand -hex 16 2>/dev/null || date +%s%N | sha256sum | head -c 32)"
KEY_PASSWORD="$STORE_PASSWORD"
KEY_ALIAS="release"

keytool -genkeypair \
    -v \
    -keystore "$KEYSTORE_FILE" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass "$STORE_PASSWORD" \
    -keypass "$KEY_PASSWORD" \
    -dname "CN=App, OU=Dev, O=Dev, L=Tehran, ST=Tehran, C=IR"

cat > "$PROPS_FILE" << EOF
storeFile=release.keystore
storePassword=$STORE_PASSWORD
keyAlias=$KEY_ALIAS
keyPassword=$KEY_PASSWORD
EOF

echo ""
echo "✅ کی‌استور ساخته شد: $KEYSTORE_FILE"
echo "✅ رمزها در این فایل ذخیره شدند: $PROPS_FILE"
echo ""
echo "⚠️  هشدار مهم: از هر دو فایل بالا یک نسخهٔ پشتیبان جداگانه (مثلاً خارج از"
echo "   این گوشی/دستگاه) بگیرید. اگر این کی‌استور را گم کنید، دیگر هرگز"
echo "   نمی‌توانید نسخهٔ جدید همین اپ را آپدیت کنید — باید با یک شناسهٔ"
echo "   بستهٔ (package id) جدید از نو منتشرش کنید."
