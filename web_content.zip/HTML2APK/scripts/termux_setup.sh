#!/data/data/com.termux/files/usr/bin/bash
# ============================================================================
# termux_setup.sh — نصب خودکار همهٔ چیزهایی که برای بیلد HTML2APK در ترموکس
# لازم است: Java، Gradle 8.13 (نه نسخهٔ ۹.x!)، Android SDK، و تنظیم aapt2.
#
# این اسکریپت را مستقیم در خودِ ترموکس اجرا کنید (نه داخل proot-distro) —
# طبق TERMUX_SETUP.md، لایهٔ proot احتمالاً عامل خطای «AAPT2 Daemon startup
# failed» بود که در جلسهٔ قبل با آن روبه‌رو شدیم.
#
# استفاده:
#   chmod +x termux_setup.sh
#   ./termux_setup.sh
#
# بعد از اجرا موفق، یک ترمینال جدید باز کنید (یا source ~/.bashrc بزنید) و:
#   GRADLE_BIN=$HOME/tools/gradle-8.13/bin/gradle ./scripts/build.sh --debug-only
# ============================================================================
set -euo pipefail

GRADLE_VERSION="8.13"
CMDLINE_TOOLS_VERSION="11076708"
BUILD_TOOLS_VERSION="34.0.0"
PLATFORM_VERSION="android-34"

log()  { echo -e "\n\033[1;34m==> $1\033[0m"; }
ok()   { echo -e "\033[1;32m✅ $1\033[0m"; }
warn() { echo -e "\033[1;33m⚠️  $1\033[0m"; }
fail() { echo -e "\033[1;31m❌ $1\033[0m"; }

# ---------------------------------------------------------------------------
# ۰. اطمینان از این‌که داخل خودِ ترموکس هستیم، نه proot-distro
# ---------------------------------------------------------------------------
if [[ ! -d "/data/data/com.termux/files/usr" ]]; then
    fail "این مسیر دیده نشد: /data/data/com.termux/files/usr"
    echo "   این اسکریپت باید مستقیم در ترموکس اجرا شود، نه داخل proot-distro/Ubuntu."
    echo "   اگر داخل proot هستید، با دستور 'exit' از آن خارج شوید و دوباره اجرا کنید."
    exit 1
fi
ok "محیط ترموکس تأیید شد."

# ---------------------------------------------------------------------------
# ۱. پکیج‌های پایه
# ---------------------------------------------------------------------------
log "به‌روزرسانی فهرست پکیج‌ها..."
pkg update -y

log "نصب Java (OpenJDK 17)، aapt2 بومی، ابزارهای اندروید، wget، unzip، python..."
pkg install -y openjdk-17 aapt2 android-tools wget unzip python

ok "پکیج‌های پایه نصب شدند."

# ---------------------------------------------------------------------------
# ۲. Gradle 8.13 — دستی دانلود می‌شود (نه از pkg، چون ممکن است نسخهٔ خیلی
#    جدیدی نصب کند که با AGP ناسازگار است؛ دقیقاً همان مشکلی که قبلاً دیدیم)
# ---------------------------------------------------------------------------
GRADLE_DIR="$HOME/tools/gradle-$GRADLE_VERSION"
if [[ -x "$GRADLE_DIR/bin/gradle" ]]; then
    ok "Gradle $GRADLE_VERSION از قبل نصب است: $GRADLE_DIR"
else
    log "دانلود Gradle $GRADLE_VERSION ..."
    mkdir -p "$HOME/tools"
    cd "$HOME/tools"
    if wget -q --show-progress -O "gradle-$GRADLE_VERSION-bin.zip" \
        "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"; then
        unzip -q "gradle-$GRADLE_VERSION-bin.zip"
        rm "gradle-$GRADLE_VERSION-bin.zip"
        ok "Gradle $GRADLE_VERSION نصب شد."
    else
        fail "دانلود Gradle از services.gradle.org ناموفق بود (شاید اینترنت/DNS مشکل دارد)."
        echo "   راه‌حل جایگزین: فایل gradle-$GRADLE_VERSION-bin.zip را از یک مرورگر دانلود کنید"
        echo "   و دستی در $GRADLE_DIR استخراج کنید، یا از مسیر GitHub Actions"
        echo "   (TERMUX_SETUP.md، مسیر ۱) استفاده کنید که این مشکل را ندارد."
        exit 1
    fi
fi

# افزودن به PATH (فقط اگر قبلاً اضافه نشده)
if ! grep -q "tools/gradle-$GRADLE_VERSION/bin" "$HOME/.bashrc" 2>/dev/null; then
    echo "export PATH=\$HOME/tools/gradle-$GRADLE_VERSION/bin:\$PATH" >> "$HOME/.bashrc"
    ok "مسیر Gradle به ~/.bashrc اضافه شد."
fi

# ---------------------------------------------------------------------------
# ۳. Android SDK command-line tools
# ---------------------------------------------------------------------------
ANDROID_HOME_DIR="$HOME/android-sdk"
if [[ -x "$ANDROID_HOME_DIR/cmdline-tools/latest/bin/sdkmanager" ]]; then
    ok "Android SDK cmdline-tools از قبل نصب است."
else
    log "دانلود Android SDK command-line tools..."
    mkdir -p "$ANDROID_HOME_DIR/cmdline-tools"
    cd "$ANDROID_HOME_DIR/cmdline-tools"
    if wget -q --show-progress -O cmdline-tools.zip \
        "https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_TOOLS_VERSION}_latest.zip"; then
        unzip -q cmdline-tools.zip
        mv cmdline-tools latest
        rm cmdline-tools.zip
        ok "Android SDK command-line tools نصب شد."
    else
        fail "دانلود Android SDK از dl.google.com ناموفق بود."
        exit 1
    fi
fi

if ! grep -q "ANDROID_HOME=" "$HOME/.bashrc" 2>/dev/null; then
    {
        echo "export ANDROID_HOME=\$HOME/android-sdk"
        echo "export PATH=\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$PATH"
    } >> "$HOME/.bashrc"
    ok "متغیرهای Android SDK به ~/.bashrc اضافه شدند."
fi

export ANDROID_HOME="$ANDROID_HOME_DIR"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

log "پذیرفتن لایسنس‌های Android SDK..."
yes | sdkmanager --licenses > /dev/null 2>&1 || true

log "نصب platform-tools, platforms;$PLATFORM_VERSION, build-tools;$BUILD_TOOLS_VERSION ..."
sdkmanager "platform-tools" "platforms;$PLATFORM_VERSION" "build-tools;$BUILD_TOOLS_VERSION"
ok "اجزای Android SDK نصب شدند."

# ---------------------------------------------------------------------------
# ۴. تنظیم aapt2 — نکتهٔ کلیدی که در جلسهٔ قبل حل مشکل داد: از باینری بومی
#    ترموکس استفاده کن، نه از باینری x86_64 داخل Android SDK رسمی
# ---------------------------------------------------------------------------
log "تنظیم android.aapt2FromMavenOverride روی aapt2 بومی ترموکس..."
NATIVE_AAPT2="$(command -v aapt2 || true)"
if [[ -z "$NATIVE_AAPT2" ]]; then
    fail "aapt2 بومی پیدا نشد (باید با 'pkg install aapt2' نصب شده باشد)."
    exit 1
fi

mkdir -p "$HOME/.gradle"
GRADLE_PROPS="$HOME/.gradle/gradle.properties"
if grep -q "android.aapt2FromMavenOverride" "$GRADLE_PROPS" 2>/dev/null; then
    # اگر از قبل خطی هست، جایگزینش کن
    sed -i "s|^android.aapt2FromMavenOverride=.*|android.aapt2FromMavenOverride=$NATIVE_AAPT2|" "$GRADLE_PROPS"
else
    echo "android.aapt2FromMavenOverride=$NATIVE_AAPT2" >> "$GRADLE_PROPS"
fi
ok "aapt2 تنظیم شد: $NATIVE_AAPT2"

# ---------------------------------------------------------------------------
# خلاصه
# ---------------------------------------------------------------------------
echo ""
echo "============================================================"
ok "نصب تمام شد!"
echo "============================================================"
echo ""
echo "یک ترمینال جدید باز کنید (یا دستور زیر را بزنید) تا PATH به‌روز شود:"
echo "    source ~/.bashrc"
echo ""
echo "سپس برای بیلد پروژهٔ HTML2APK:"
echo "    cd /path/to/HTML2APK"
echo "    chmod +x scripts/*.sh"
echo "    GRADLE_BIN=\$HOME/tools/gradle-$GRADLE_VERSION/bin/gradle ./scripts/build.sh --debug-only"
echo ""
echo "اگر باز هم خطای 'AAPT2 Daemon startup failed' گرفتید، این یعنی مشکل در"
echo "سطح خودِ Termux/دستگاه است (نه نسخه‌ها) — در این صورت از مسیر GitHub"
echo "Actions در TERMUX_SETUP.md استفاده کنید که این مشکل را اصلاً ندارد."
