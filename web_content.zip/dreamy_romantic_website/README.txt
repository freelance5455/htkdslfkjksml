OUR LITTLE WORLD — Dreamy Romantic Website

HOW TO OPEN ON YOUR PHONE
1. Extract the ZIP file using your phone's Files app.
2. Open the extracted folder and tap index.html.
3. Choose Chrome or another browser if prompted.

FEATURES
- Responsive romantic scrapbook layout with bottom navigation
- Add up to 12 photos from your phone; edit captions and remove photos
- Editable home quote, story, scrapbook note, letter and surprise message
- Add and edit relationship timeline memories
- Openable love letter
- Hidden surprise message and floating heart animation
- Choose an audio file from your phone and play it on the page
- Text, photos, and timeline memories save locally in the browser

IMPORTANT NOTES
- This is a self-contained website and works locally without an account or server.
- Browser storage is local to the browser/device. It does not automatically sync to another device.
- Audio selection is for the current visit and may need to be selected again after reopening.
- This local version is not published on the internet and does not have a shared URL.
- For best results, keep photos reasonably small. If browser storage fills up, remove some photos.
- Do not put sensitive private information in a page if you later publish it publicly.
