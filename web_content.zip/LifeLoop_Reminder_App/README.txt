LifeLoop Reminder App — ZIP contents

Open index.html in Chrome or another modern browser. On Android, extract the ZIP using Files, then tap index.html and choose Chrome.

Features:
- Add, edit, complete, delete and filter reminders
- Exam, bills, medicine, government, birthday, travel, farming, routine and other categories
- Date, time, priority, repeat interval and advance-notice setting
- Notes, dashboard counts and local browser storage

Important limitations:
- This is a browser prototype, not an APK.
- Reminder records are stored in this browser on this device using localStorage.
- The advance-notice and repeat fields are saved as reminder settings; this HTML prototype does not send background notifications or automatically trigger repeat alerts.
- For dependable alerts while the app/browser is closed, a native Android app with notification scheduling and Android permissions is required.
