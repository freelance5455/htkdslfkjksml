VETDOSE CALCULATOR BY DS — ANDROID PROJECT

WHAT THIS IS
An offline Android WebView app with an HTML dose calculator. It calculates total dose (mg) from a user-entered verified dose (mg/kg) and weight (kg), and optionally volume (mL) from concentration (mg/mL). It does not contain an authoritative drug-dose database.

BUILD ON AN ANDROID PHONE
1. Download AndroidIDE only from a trusted source listed in its official docs. The project is not maintained, so use caution and avoid unknown APK websites:
   https://docs.androidide.com/user/installation.html
2. Open AndroidIDE and complete its initial build-tools setup. Its documentation recommends at least 1.5–2 GB free RAM, around 4 GB storage, and Wi-Fi for setup.
3. Extract this ZIP using your phone's file manager to a normal folder (for example, Internal storage/Download/VetdoseCalculatorDS). Do not open the ZIP without extracting it.
4. In AndroidIDE, choose “Open existing project” and select the extracted VetdoseCalculatorDS folder (the folder containing settings.gradle and build.gradle).
5. Allow Gradle sync to finish. The first build can take 10–15 minutes or longer depending on device and connection.
6. Choose Quick Run / Run, or open the terminal in the project folder and run the Gradle assembleDebug task if the IDE supports it.
7. The debug APK is normally created at:
   app/build/outputs/apk/debug/app-debug.apk
8. Tap the APK in the file manager to install it. If Android asks, allow AndroidIDE or your file manager to install unknown apps. Only install APKs you built or trust.

NOTES
- Requires internet during initial Android build-tools/Gradle setup; the finished calculator works offline.
- AndroidIDE is currently marked unmaintained in its GitHub repository. If setup/build fails, the error may be due to device compatibility or the build environment.
- This is a debug APK when built this way, not a Play Store release-signed APK.
- Dose results are arithmetic only. Verify every drug dose, route, frequency, maximum dose, contraindication and formulation against current veterinary references and the responsible veterinarian before use.
