My Group D Study V26 — Android SOURCE PROJECT, APK नहीं

जो वास्तव में जोड़ा गया:
1. Vacancy: RRB आधिकारिक पोर्टल के लिंक; ऑटो वैकेंसी push notification नहीं।
2. LIVE classes: पहले के वीडियो और Watch Later फीचर रखे गए; real-time LIVE detection/push notification अभी नहीं।
3. Daily Calendar + Target: स्थानीय तारीख/टारगेट पहले की तरह काम करते हैं।
4. Current Affairs: PIB और Google News ऑनलाइन लिंक; स्वतः अपडेटेड in-app feed नहीं।
5. Application Status/Admit Card: RRB आधिकारिक पोर्टल के लिंक; निजी आवेदन स्थिति स्वतः नहीं पढ़ता।
6. Smart Mock: हर कैलेंडर सप्ताह नया deterministic shuffled 100-question set (मौजूदा 2097 प्रश्न बैंक से), परिणाम और subject-wise accuracy/weak topics. हर महीने भी सप्ताह बदलने से क्रम बदलता है। नए प्रश्न इंटरनेट से नहीं आते; नया प्रश्न बैंक जोड़ना होगा।
7. नया V26 app logo resource जोड़ा गया।
8. Unwanted 7 PM reminder receiver हटा दिया।

सीमाएँ: LIVE होने पर ही नोटिफिकेशन और नई वैकेंसी की verified push notification के लिए verified channel IDs + reliable monitoring backend/API and Android notification integration चाहिए। इस ZIP में वह लागू नहीं। यहाँ APK compile/test नहीं किया गया।

Build: Android Studio से प्रोजेक्ट खोलें; Gradle Sync; Build > Build APK(s).
