package az.taxiaz.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
public class MainActivity extends Activity {
 private WebView web;
 // Replace with your deployed Firebase Hosting HTTPS URL before building.
 private static final String TAXI_WEB_URL = "https://YOUR_PROJECT_ID.web.app";
 @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);
  web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setGeolocationEnabled(true);
  web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){
   @Override public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback){callback.invoke(origin,true,false);}
  });
  if(TAXI_WEB_URL.contains("YOUR_PROJECT_ID")){Toast.makeText(this,"Əvvəl TAXI_WEB_URL ünvanını dəyişin.",Toast.LENGTH_LONG).show();web.loadData("<h3>Taxi AZ</h3><p>AndroidManifest layihəsində deyil, MainActivity.java faylında TAXI_WEB_URL dəyərini Firebase Hosting ünvanı ilə dəyişin.</p>","text/html","UTF-8");}
  else web.loadUrl(TAXI_WEB_URL);
 }
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}