# SignalScout companion server

A small Node.js server providing:
- **Live chat** over WebSocket at `/chat`
- **Feedback intake** over REST at `POST /api/feedback` (stored in `feedback.json` next to the
  server file — swap for a real database before this needs to handle real concurrent traffic)

The web app can't provide these on its own — a static HTML file has no way to relay messages
between different people's browsers or persist anything server-side. This is that missing piece.

## Run it locally

```bash
cd server
npm install
npm start
```

This starts the server on port 8080:
```
SignalScout server listening on port 8080
  REST:      http://localhost:8080/api/feedback
  WebSocket: ws://localhost:8080/chat
```

Then in the web app's Settings tab, set the **server URL** to `ws://localhost:8080`.

## Deploying somewhere reachable from other people's browsers

`localhost` only works on your own machine. To have a shared chat room, deploy this somewhere
public. A few options with free tiers (check current pricing/limits — these change):

- **Render** (render.com) — "New Web Service," point it at this `server/` folder, build command
  `npm install`, start command `npm start`. Free tier sleeps after inactivity, so the first
  message after idle time will be slow to connect.
- **Railway** (railway.app) — similar flow, usage-based free credits.
- **Fly.io** (fly.io) — `fly launch` in this directory.
- **Your own VPS** — run with `pm2` behind Caddy/nginx for automatic HTTPS/WSS, which you'll
  need since browsers require secure WebSocket (`wss://`) from an `https://` page.

Once deployed, use `wss://your-app.example.com` (note **wss**, not ws) as the server URL in the
app's Settings.

## Notes on feedback storage

`feedback.json` is a flat file — fine for getting started, not safe for concurrent writes at
volume. Swap for SQLite (`better-sqlite3`) once usage grows.

## Notes on the chat room

No accounts, no auth, no persistence beyond the last 50 messages kept in memory (lost on
restart). No moderation or rate limiting — add those before pointing this at a public audience.
Single room only; no channel routing.
