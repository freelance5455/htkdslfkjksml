// SignalScout companion server — chat room (WebSocket) + feedback intake (REST).
// Deliberately minimal: in-memory chat history, feedback appended to a local JSON file.
// Swap the feedback storage for a real database before relying on this in production —
// the JSON file is fine for getting started, not for concurrent write safety at scale.

const express = require("express");
const cors = require("cors");
const http = require("http");
const { WebSocketServer } = require("ws");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 8080;
const FEEDBACK_FILE = path.join(__dirname, "feedback.json");
const MAX_CHAT_HISTORY = 50;

const app = express();
app.use(cors());
app.use(express.json());

// ---------- Feedback (REST) ----------
function readFeedback() {
  try {
    return JSON.parse(fs.readFileSync(FEEDBACK_FILE, "utf8"));
  } catch {
    return [];
  }
}

function writeFeedback(list) {
  fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(list, null, 2));
}

app.post("/api/feedback", (req, res) => {
  const { name, message, rating } = req.body || {};

  if (!message || typeof message !== "string" || !message.trim()) {
    return res.status(400).json({ error: "message is required" });
  }

  const entry = {
    id: Date.now(),
    name: typeof name === "string" && name.trim() ? name.trim().slice(0, 80) : "Anonymous",
    message: message.trim().slice(0, 2000),
    rating: Number.isInteger(rating) && rating >= 1 && rating <= 5 ? rating : null,
    receivedAt: new Date().toISOString(),
  };

  const list = readFeedback();
  list.push(entry);
  writeFeedback(list);

  res.status(201).json({ ok: true });
});

// Simple admin view — no auth here; add one before exposing this publicly.
app.get("/api/feedback", (_req, res) => {
  res.json(readFeedback());
});

app.get("/health", (_req, res) => res.json({ ok: true }));

// ---------- Chat (WebSocket) ----------
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/chat" });

let chatHistory = [];

function broadcast(payload) {
  const data = JSON.stringify(payload);
  wss.clients.forEach((client) => {
    if (client.readyState === client.OPEN) client.send(data);
  });
}

wss.on("connection", (ws) => {
  ws.send(JSON.stringify({ type: "history", messages: chatHistory }));

  ws.on("message", (raw) => {
    let parsed;
    try {
      parsed = JSON.parse(raw.toString());
    } catch {
      return; // ignore malformed frames
    }

    if (parsed.type !== "message") return;
    const text = String(parsed.text || "").trim().slice(0, 500);
    const name = String(parsed.name || "Anonymous").trim().slice(0, 40) || "Anonymous";
    if (!text) return;

    const chatMessage = {
      type: "message",
      name,
      text,
      at: new Date().toISOString(),
    };

    chatHistory.push(chatMessage);
    if (chatHistory.length > MAX_CHAT_HISTORY) chatHistory.shift();

    broadcast(chatMessage);
  });
});

server.listen(PORT, () => {
  console.log(`SignalScout server listening on port ${PORT}`);
  console.log(`  REST:      http://localhost:${PORT}/api/feedback`);
  console.log(`  WebSocket: ws://localhost:${PORT}/chat`);
});
