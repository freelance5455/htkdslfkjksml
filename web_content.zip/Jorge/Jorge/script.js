// ============================================================
//  INVENTARIO Y VENTAS - C. G. Geans
//  + Auto-respaldo + respaldo manual (WebView-friendly)
//  + Impresión (recibos, detalle de venta, reporte)
// ============================================================

const STOCK_BAJO = 5;

// ---- AUTO-RESPALDO ----
const AUTO_RESPALDO_CLAVE = 'geansAutoRespaldos';
const AUTO_RESPALDO_MAX = 7;
const AUTO_RESPALDO_INTERVALO_HORAS = 12;
const AUTO_RESPALDO_CAMBIOS = 30;

// ---- ESTADO ----
let clientes = [];
let productos = [];
let ventas = [];
let proveedores = [];
let compras = [];
let nextClienteId = 1;
let nextProductoId = 1;
let nextVentaId = 1;
let nextProveedorId = 1;
let nextCompraId = 1;
let ventaEnEdicionId = null;
let ultimoRecibo = null;
let ventaCarrito = [];
let categoriaActiva = 'todas';
let contadorCambios = 0;

let config = {
    nombreTienda: 'C. G. Geans',
    telefono: '',
    ruc: '',
    direccion: '',
    mensajeRecibo: '¡Gracias por su preferencia!',
    colorPrimario: '#2a6f97'
};
let darkMode = false;

// ---- CARGA / GUARDADO ----
function cargarDatos() {
    try {
        const data = JSON.parse(localStorage.getItem('inventarioData'));
        if (data) {
            clientes = data.clientes || [];
            productos = data.productos || [];
            ventas = data.ventas || [];
            proveedores = data.proveedores || [];
            compras = data.compras || [];
            nextClienteId = data.nextClienteId || 1;
            nextProductoId = data.nextProductoId || 1;
            nextVentaId = data.nextVentaId || 1;
            nextProveedorId = data.nextProveedorId || 1;
            nextCompraId = data.nextCompraId || 1;
            if (data.config) Object.assign(config, data.config);
            darkMode = !!data.darkMode;
        }
    } catch (e) { console.warn('Error al cargar datos', e); }
}

function empaquetarDatos() {
    return {
        app: config.nombreTienda,
        version: '2.0',
        exportado: new Date().toISOString(),
        clientes, productos, ventas, proveedores, compras,
        nextClienteId, nextProductoId, nextVentaId, nextProveedorId, nextCompraId,
        config, darkMode
    };
}

function guardarDatos() {
    const data = empaquetarDatos();
    localStorage.setItem('inventarioData', JSON.stringify(data));
    contadorCambios++;
    verificarAutoRespaldo();
    if (document.getElementById('alertasContainer')) renderAlertas();
}

// ============================================================
//  AUTO-RESPALDO
// ============================================================
function obtenerAutoRespaldos() {
    try {
        const arr = JSON.parse(localStorage.getItem(AUTO_RESPALDO_CLAVE));
        return Array.isArray(arr) ? arr : [];
    } catch { return []; }
}

function guardarAutoRespaldos(arr) {
    try {
        localStorage.setItem(AUTO_RESPALDO_CLAVE, JSON.stringify(arr));
    } catch (e) {
        console.warn('Error guardando auto-respaldo, depurando...', e);
        if (arr.length > 1) {
            arr.shift();
            try { localStorage.setItem(AUTO_RESPALDO_CLAVE, JSON.stringify(arr)); } catch {}
        }
    }
}

function generarAutoRespaldo(motivo = '') {
    const respaldos = obtenerAutoRespaldos();
    const data = empaquetarDatos();
    respaldos.push({
        fecha: new Date().toISOString(),
        motivo,
        resumen: {
            clientes: clientes.length,
            productos: productos.length,
            ventas: ventas.length,
            proveedores: proveedores.length,
            compras: compras.length
        },
        datos: data
    });
    limpiarAutoRespaldosViejos(respaldos);
    guardarAutoRespaldos(respaldos);
    contadorCambios = 0;
}

function limpiarAutoRespaldosViejos(respaldos) {
    while (respaldos.length > AUTO_RESPALDO_MAX) respaldos.shift();
}

function verificarAutoRespaldo() {
    const respaldos = obtenerAutoRespaldos();
    const ultimo = respaldos.length > 0 ? respaldos[respaldos.length - 1] : null;
    const msDesdeUltimo = ultimo ? (Date.now() - new Date(ultimo.fecha).getTime()) : Infinity;
    const horas = msDesdeUltimo / (1000 * 60 * 60);
    const porTiempo = horas >= AUTO_RESPALDO_INTERVALO_HORAS;
    const porCambios = contadorCambios >= AUTO_RESPALDO_CAMBIOS;

    if (porTiempo || porCambios || respaldos.length === 0) {
        const motivo = respaldos.length === 0 ? 'Inicial' :
            porCambios ? `Cada ${AUTO_RESPALDO_CAMBIOS} cambios` :
            `Cada ${AUTO_RESPALDO_INTERVALO_HORAS}h`;
        generarAutoRespaldo(motivo);
    }
}

function abrirModalAutoRespaldos() {
    renderAutoRespaldos();
    abrirModal('modalAutoRespaldos');
}

function renderAutoRespaldos() {
    const cont = document.getElementById('autoRespaldosContenido');
    if (!cont) return;
    const respaldos = obtenerAutoRespaldos().slice().reverse();
    if (respaldos.length === 0) {
        cont.innerHTML = `<div class="auto-respaldo-vacio">Aún no hay auto-respaldos disponibles.</div>`;
        return;
    }
    cont.innerHTML = respaldos.map((r, idx) => {
        const fecha = new Date(r.fecha).toLocaleString('es-PY');
        const r2 = r.resumen || {};
        const detalle = `${r2.clientes || 0} clientes · ${r2.productos || 0} productos · ${r2.ventas || 0} ventas`;
        const idxReal = obtenerAutoRespaldos().length - 1 - idx;
        return `<div class="auto-respaldo-item">
            <div class="info">
                <strong>📅 ${fecha}</strong>
                <small>${detalle}</small>
                <small style="color:var(--primary);font-style:italic;">${r.motivo || ''}</small>
            </div>
            <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
                <button class="btn btn-success" data-auto-accion="restaurar" data-index="${idxReal}" style="padding:0.3rem 0.8rem;font-size:0.8rem;">Restaurar</button>
                <button class="btn btn-danger" data-auto-accion="eliminar" data-index="${idxReal}" style="padding:0.3rem 0.8rem;font-size:0.8rem;">Eliminar</button>
            </div>
        </div>`;
    }).join('');
}

function restaurarAutoRespaldo(index) {
    const respaldos = obtenerAutoRespaldos();
    const r = respaldos[index];
    if (!r) { alert('Auto-respaldo no encontrado.'); return; }
    const fecha = new Date(r.fecha).toLocaleString('es-PY');
    if (!confirm(`¿Restaurar el auto-respaldo del ${fecha}?\n\nSe reemplazarán TODOS los datos actuales.`)) return;
    aplicarRespaldoObjeto(r.datos, true);
}

function eliminarAutoRespaldo(index) {
    const respaldos = obtenerAutoRespaldos();
    if (!respaldos[index]) return;
    if (!confirm('¿Eliminar este auto-respaldo?')) return;
    respaldos.splice(index, 1);
    guardarAutoRespaldos(respaldos);
    renderAutoRespaldos();
}

function aplicarRespaldoObjeto(data, silencioso = false) {
    if (!data || !data.clientes || !data.productos || !data.ventas) {
        alert('Respaldo inválido: no contiene los datos esperados.');
        return false;
    }
    clientes = data.clientes || [];
    productos = data.productos || [];
    ventas = data.ventas || [];
    proveedores = data.proveedores || [];
    compras = data.compras || [];
    nextClienteId = data.nextClienteId || 1;
    nextProductoId = data.nextProductoId || 1;
    nextVentaId = data.nextVentaId || 1;
    nextProveedorId = data.nextProveedorId || 1;
    nextCompraId = data.nextCompraId || 1;
    if (data.config) Object.assign(config, data.config);
    darkMode = !!data.darkMode;

    localStorage.setItem('inventarioData', JSON.stringify(empaquetarDatos()));
    contadorCambios = 0;
    aplicarConfiguracion();
    aplicarModoOscuro();
    if (!silencioso) alert('✅ Respaldo restaurado correctamente.');
    refrescarTodo();
    return true;
}

// ============================================================
//  RESPALDO MANUAL (WebView / APK Android)
// ============================================================
function exportarRespaldo() {
    const data = empaquetarDatos();
    const jsonStr = JSON.stringify(data, null, 2);
    const nombreArchivo = `respaldo-${hoy()}.json`;

    (async () => {
        try {
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const file = new File([blob], nombreArchivo, { type: 'application/json' });
            if (navigator.canShare && navigator.canShare({ files: [file] })) {
                await navigator.share({
                    files: [file],
                    title: 'Respaldo ' + config.nombreTienda,
                    text: 'Respaldo de datos'
                });
                return;
            }
        } catch (err) {
            console.warn('[Respaldo] Web Share con archivo no disponible:', err);
        }
        mostrarModalExportarRespaldo(jsonStr, nombreArchivo);
    })();
}

function mostrarModalExportarRespaldo(jsonStr, nombreArchivo) {
    document.getElementById('modalRespaldoTitle').textContent = '💾 Exportar respaldo';
    document.getElementById('modalRespaldoContenido').innerHTML = `
        <p style="margin-bottom:0.8rem; color:var(--gray); font-size:0.9rem;">
            <strong>Copia</strong> el texto y guárdalo en un archivo <code>.json</code> (Google Drive, Notas, WhatsApp, etc.).
            O usa <strong>Compartir</strong> para enviarlo directo a Drive/WhatsApp.
        </p>
        <textarea id="respaldoTexto" readonly style="width:100%; height:200px; font-family:monospace; font-size:0.72rem; padding:0.6rem; border:1px solid #d0d7de; border-radius:8px; resize:vertical; background:#f8fafc; color:inherit;"></textarea>
        <div style="margin-top:0.8rem; display:flex; gap:0.5rem; flex-wrap:wrap;">
            <button class="btn btn-primary" id="btnCopiarRespaldo">📋 Copiar</button>
            <button class="btn btn-success" id="btnCompartirRespaldo">📱 Compartir</button>
            <button class="btn btn-secondary" id="btnCerrarRespaldo">Cerrar</button>
        </div>
    `;
    const ta = document.getElementById('respaldoTexto');
    ta.value = jsonStr;

    document.getElementById('btnCopiarRespaldo').onclick = async () => {
        try {
            await navigator.clipboard.writeText(jsonStr);
            alert('✅ Copiado al portapapeles.\n\nPégalo en un archivo .json o en una nota.');
        } catch (e) {
            ta.select();
            ta.setSelectionRange(0, jsonStr.length);
            document.execCommand('copy');
            alert('✅ Copiado (método alternativo).');
        }
    };

    document.getElementById('btnCompartirRespaldo').onclick = async () => {
        try {
            if (navigator.share) {
                await navigator.share({ title: 'Respaldo ' + config.nombreTienda, text: jsonStr });
            } else {
                alert('Tu dispositivo no permite compartir texto.\nUsa el botón Copiar.');
            }
        } catch (err) { console.warn(err); }
    };

    document.getElementById('btnCerrarRespaldo').onclick = () => cerrarModal('modalRespaldo');
    abrirModal('modalRespaldo');
}

function importarRespaldo() {
    document.getElementById('modalRespaldoTitle').textContent = '📂 Importar respaldo';
    document.getElementById('modalRespaldoContenido').innerHTML = `
        <p style="margin-bottom:0.8rem; color:var(--gray); font-size:0.9rem;">
            <strong>Pega</strong> aquí el contenido del archivo de respaldo (JSON) o selecciona el archivo si tu dispositivo lo permite.
        </p>
        <div class="form-group">
            <label>Seleccionar archivo (opcional)</label>
            <input type="file" id="archivoRespaldo" accept="application/json,.json,.txt,text/plain" />
        </div>
        <div class="form-group">
            <label>O pega el texto aquí</label>
            <textarea id="respaldoTextoImport" placeholder='{"app":"...","clientes":[...],"productos":[...],"ventas":[...]}'
                style="width:100%; height:180px; font-family:monospace; font-size:0.72rem; padding:0.6rem; border:1px solid #d0d7de; border-radius:8px; resize:vertical; color:inherit;"></textarea>
        </div>
        <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
            <button class="btn btn-success" id="btnAplicarRespaldo">✅ Restaurar datos</button>
            <button class="btn btn-secondary" id="btnCerrarRespaldoImport">Cancelar</button>
        </div>
    `;

    document.getElementById('archivoRespaldo').onchange = function(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = ev => { document.getElementById('respaldoTextoImport').value = ev.target.result; };
        reader.onerror = () => alert('No se pudo leer el archivo.');
        reader.readAsText(file);
    };

    document.getElementById('btnAplicarRespaldo').onclick = () => {
        const texto = document.getElementById('respaldoTextoImport').value.trim();
        if (!texto) return alert('Pega el contenido del respaldo o selecciona un archivo.');
        try {
            const data = JSON.parse(texto);
            if (!data.clientes || !data.productos || !data.ventas) {
                alert('Archivo inválido: no contiene los datos esperados (clientes, productos, ventas).');
                return;
            }
            if (!confirm('⚠️ Se reemplazarán TODOS los datos actuales.\n\n¿Deseas continuar?')) return;
            aplicarRespaldoObjeto(data, true);
            cerrarModal('modalRespaldo');
            alert('✅ Respaldo restaurado correctamente.');
        } catch (err) {
            alert('Error al procesar los datos:\n' + err.message);
        }
    };

    document.getElementById('btnCerrarRespaldoImport').onclick = () => cerrarModal('modalRespaldo');
    abrirModal('modalRespaldo');
}

// ============================================================
//  UTILIDADES
// ============================================================
function generarId() { return Date.now().toString(36) + Math.random().toString(36).substring(2, 6); }
function obtenerCliente(id) { return clientes.find(c => c.id === id); }
function obtenerProducto(id) { return productos.find(p => p.id === id); }
function obtenerVenta(id) { return ventas.find(v => v.id === id); }
function obtenerProveedor(id) { return proveedores.find(p => p.id === id); }

function formatearFecha(fecha) { return new Date(fecha).toLocaleDateString('es-PY', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
function formatearFechaHora(fecha) { return new Date(fecha).toLocaleString('es-PY', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function formatearMoneda(monto) {
    if (monto === undefined || monto === null || isNaN(monto)) return 'Gs. 0';
    const esEntero = Number.isInteger(monto) || Math.round(monto) === monto;
    const decimales = esEntero ? 0 : 2;
    return 'Gs. ' + monto.toLocaleString('es-PY', { minimumFractionDigits: decimales, maximumFractionDigits: decimales });
}
function hoy() { return new Date().toISOString().split('T')[0]; }
function esHoy(fecha) { return fecha.split('T')[0] === hoy(); }

function normalizarTelefono(tel) {
    if (!tel) return '';
    let t = String(tel).replace(/\D/g, '');
    if (t.startsWith('0')) t = t.substring(1);
    if (!t.startsWith('595')) t = '595' + t;
    return t;
}

// ---- COLORES ----
function hexToRgb(hex) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}
function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
}
function aclararOscurecer(hex, pct) {
    const { r, g, b } = hexToRgb(hex);
    if (pct > 0) return rgbToHex(r + (255 - r) * pct, g + (255 - g) * pct, b + (255 - b) * pct);
    return rgbToHex(r * (1 + pct), g * (1 + pct), b * (1 + pct));
}

// ---- CONFIGURACIÓN ----
function aplicarConfiguracion() {
    document.getElementById('navBrand').textContent = '📊 ' + config.nombreTienda;
    document.title = config.nombreTienda + ' - Inventario y Ventas';
    document.documentElement.style.setProperty('--primary', config.colorPrimario);
    document.documentElement.style.setProperty('--primary-light', aclararOscurecer(config.colorPrimario, 0.25));
    document.documentElement.style.setProperty('--primary-dark', aclararOscurecer(config.colorPrimario, -0.3));
}
function aplicarModoOscuro() {
    document.body.classList.toggle('dark-mode', darkMode);
    document.getElementById('btnModoOscuro').textContent = darkMode ? '☀️' : '🌙';
}

// ---- CLIENTES ----
function crearCliente(nombre, telefono, email, direccion) {
    clientes.push({ id: generarId(), nombre, telefono, email, direccion });
    guardarDatos();
}
function editarCliente(id, nombre, telefono, email, direccion) {
    const c = obtenerCliente(id);
    if (c) { Object.assign(c, { nombre, telefono, email, direccion }); guardarDatos(); return true; }
    return false;
}
function eliminarCliente(id) {
    const idx = clientes.findIndex(c => c.id === id);
    if (idx !== -1) { clientes.splice(idx, 1); guardarDatos(); return true; }
    return false;
}

// ---- PRODUCTOS ----
function crearProducto(nombre, categoria, precio, stock) {
    productos.push({ id: generarId(), nombre, categoria, precio: parseFloat(precio), stock: parseInt(stock) });
    guardarDatos();
}
function editarProducto(id, nombre, categoria, precio, stock) {
    const p = obtenerProducto(id);
    if (p) { Object.assign(p, { nombre, categoria, precio: parseFloat(precio), stock: parseInt(stock) }); guardarDatos(); return true; }
    return false;
}
function eliminarProducto(id) {
    const idx = productos.findIndex(p => p.id === id);
    if (idx !== -1) { productos.splice(idx, 1); guardarDatos(); return true; }
    return false;
}

// ---- PROVEEDORES ----
function crearProveedor(nombre, telefono, email, direccion) {
    proveedores.push({ id: generarId(), nombre, telefono, email, direccion });
    guardarDatos();
}
function editarProveedor(id, nombre, telefono, email, direccion) {
    const p = obtenerProveedor(id);
    if (p) { Object.assign(p, { nombre, telefono, email, direccion }); guardarDatos(); return true; }
    return false;
}
function eliminarProveedor(id) {
    const idx = proveedores.findIndex(p => p.id === id);
    if (idx !== -1) { proveedores.splice(idx, 1); guardarDatos(); return true; }
    return false;
}

// ---- COMPRAS ----
function registrarCompra(proveedorId, productoId, cantidad, precioCompra, observaciones) {
    const prod = obtenerProducto(productoId);
    if (!prod) return false;
    const cantidadN = parseInt(cantidad);
    const precioN = parseFloat(precioCompra);
    if (cantidadN <= 0 || precioN < 0) return false;
    const compra = {
        id: generarId(),
        fecha: new Date().toISOString(),
        proveedorId, productoId,
        productoNombre: prod.nombre,
        cantidad: cantidadN,
        precioCompra: precioN,
        total: parseFloat((cantidadN * precioN).toFixed(2)),
        observaciones: observaciones || ''
    };
    compras.push(compra);
    prod.stock += cantidadN;
    guardarDatos();
    return true;
}

// ---- VENTAS ----
function registrarVenta(clienteId, tipo, items, numCuotas = 0) {
    const ventaId = generarId();
    const fecha = new Date().toISOString();
    let total = 0;
    const detalles = items.map(item => {
        const prod = obtenerProducto(item.productoId);
        if (!prod) throw new Error(`Producto ${item.productoId} no existe`);
        const subtotal = prod.precio * item.cantidad;
        total += subtotal;
        return { productoId: prod.id, nombre: prod.nombre, cantidad: item.cantidad, precioUnitario: prod.precio, subtotal };
    });
    items.forEach(item => {
        const prod = obtenerProducto(item.productoId);
        if (prod) { prod.stock -= item.cantidad; if (prod.stock < 0) prod.stock = 0; }
    });
    let cuotas = [], estado = 'pagado', pagos = [], saldoPendiente = 0;
    if (tipo === 'credito') {
        estado = 'pendiente';
        saldoPendiente = parseFloat(total.toFixed(2));
    } else if (tipo === 'cuotas') {
        estado = 'pendiente';
        const num = parseInt(numCuotas) || 2;
        const montoCuota = total / num;
        const h = new Date();
        for (let i = 1; i <= num; i++) {
            const fechaVenc = new Date(h);
            fechaVenc.setDate(fechaVenc.getDate() + i * 30);
            cuotas.push({ numero: i, monto: parseFloat(montoCuota.toFixed(2)), fechaVencimiento: fechaVenc.toISOString(), pagado: false });
        }
        if (cuotas.length > 0) {
            const suma = cuotas.reduce((acc, c) => acc + c.monto, 0);
            const diff = parseFloat((total - suma).toFixed(2));
            if (Math.abs(diff) > 0.001) cuotas[cuotas.length - 1].monto = parseFloat((cuotas[cuotas.length - 1].monto + diff).toFixed(2));
        }
    }
    ventas.push({ id: ventaId, clienteId, fecha, tipo, total: parseFloat(total.toFixed(2)), estado, detalles, cuotas, pagos, saldoPendiente });
    guardarDatos();
    return ventas[ventas.length - 1];
}

function puedeEditarVenta(venta) {
    if (!venta) return false;
    if (venta.estado === 'anulada') return false;
    if (venta.tipo === 'credito') return (venta.pagos || []).length === 0;
    if (venta.tipo === 'cuotas') return venta.cuotas.every(c => !c.pagado);
    return true;
}

function anularVenta(ventaId) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return false;
    if (venta.estado === 'anulada') return false;
    venta.detalles.forEach(d => {
        const prod = obtenerProducto(d.productoId);
        if (prod) prod.stock += d.cantidad;
    });
    venta.estado = 'anulada';
    guardarDatos();
    return true;
}

function actualizarVenta(ventaId, items) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return false;
    if (!puedeEditarVenta(venta)) return false;
    for (const item of items) {
        const prod = obtenerProducto(item.productoId);
        if (!prod) return false;
        const original = venta.detalles.find(d => d.productoId === item.productoId);
        const stockDisponible = prod.stock + (original ? original.cantidad : 0);
        if (stockDisponible < item.cantidad) return false;
    }
    venta.detalles.forEach(d => {
        const prod = obtenerProducto(d.productoId);
        if (prod) prod.stock += d.cantidad;
    });
    let total = 0;
    venta.detalles = items.map(item => {
        const prod = obtenerProducto(item.productoId);
        const subtotal = prod.precio * item.cantidad;
        total += subtotal;
        prod.stock -= item.cantidad;
        if (prod.stock < 0) prod.stock = 0;
        return { productoId: prod.id, nombre: prod.nombre, cantidad: item.cantidad, precioUnitario: prod.precio, subtotal };
    });
    venta.total = parseFloat(total.toFixed(2));
    if (venta.tipo === 'credito') {
        venta.saldoPendiente = venta.total;
        venta.pagos = [];
    } else if (venta.tipo === 'cuotas') {
        const num = venta.cuotas.length || 2;
        const montoCuota = venta.total / num;
        const h = new Date();
        venta.cuotas = [];
        for (let i = 1; i <= num; i++) {
            const fechaVenc = new Date(h);
            fechaVenc.setDate(fechaVenc.getDate() + i * 30);
            venta.cuotas.push({ numero: i, monto: parseFloat(montoCuota.toFixed(2)), fechaVencimiento: fechaVenc.toISOString(), pagado: false });
        }
        if (venta.cuotas.length > 0) {
            const suma = venta.cuotas.reduce((acc, c) => acc + c.monto, 0);
            const diff = parseFloat((venta.total - suma).toFixed(2));
            if (Math.abs(diff) > 0.001) venta.cuotas[venta.cuotas.length - 1].monto = parseFloat((venta.cuotas[venta.cuotas.length - 1].monto + diff).toFixed(2));
        }
    }
    guardarDatos();
    return true;
}

// ---- PAGOS ----
function registrarPagoParcial(ventaId, monto) {
    const venta = obtenerVenta(ventaId);
    if (!venta || venta.tipo !== 'credito' || venta.estado === 'pagado') return false;
    if (monto <= 0) return false;
    const montoR = parseFloat(monto.toFixed(2));
    if (montoR > venta.saldoPendiente) return false;
    venta.pagos.push({ fecha: new Date().toISOString(), monto: montoR });
    let nuevoSaldo = parseFloat((venta.saldoPendiente - montoR).toFixed(2));
    nuevoSaldo = Math.max(0, nuevoSaldo);
    venta.saldoPendiente = nuevoSaldo;
    if (venta.saldoPendiente === 0) venta.estado = 'pagado';
    guardarDatos();
    return true;
}
function registrarPagoCuota(ventaId, numeroCuota) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return false;
    const cuota = venta.cuotas.find(c => c.numero === numeroCuota);
    if (!cuota || cuota.pagado) return false;
    cuota.pagado = true;
    if (venta.cuotas.every(c => c.pagado)) venta.estado = 'pagado';
    guardarDatos();
    return true;
}

// ---- REPORTES ----
function obtenerVentasHoy() { return ventas.filter(v => esHoy(v.fecha) && v.estado !== 'anulada'); }
function obtenerTotalVentasHoy() { return obtenerVentasHoy().reduce((acc, v) => acc + v.total, 0); }

function obtenerClientesConDeuda() {
    const deudas = {};
    ventas.forEach(v => {
        if (v.estado === 'pendiente') {
            const cliente = obtenerCliente(v.clienteId);
            if (cliente) {
                let adeudado = 0;
                if (v.tipo === 'credito') adeudado = v.saldoPendiente || 0;
                else if (v.tipo === 'cuotas') adeudado = v.cuotas.filter(c => !c.pagado).reduce((acc, c) => acc + c.monto, 0);
                if (adeudado > 0.005) deudas[cliente.id] = (deudas[cliente.id] || 0) + adeudado;
            }
        }
    });
    return deudas;
}
function obtenerTotalDeudaPendiente() { return Object.values(obtenerClientesConDeuda()).reduce((a, b) => a + b, 0); }

function obtenerPagosPendientes() {
    const pendientes = [];
    ventas.forEach(v => {
        if (v.estado === 'pendiente' && v.cuotas && v.cuotas.length > 0) {
            v.cuotas.forEach(c => {
                if (!c.pagado) pendientes.push({
                    ventaId: v.id, clienteId: v.clienteId,
                    clienteNombre: obtenerCliente(v.clienteId)?.nombre || 'Desconocido',
                    numeroCuota: c.numero, monto: c.monto, fechaVencimiento: c.fechaVencimiento, ventaTotal: v.total
                });
            });
        }
    });
    return pendientes;
}

// ---- CSV ----
function descargarBlob(blob, nombre) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = nombre;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function csvEscape(valor) {
    if (valor === null || valor === undefined) return '';
    const s = String(valor);
    if (s.includes('"') || s.includes(';') || s.includes(',') || s.includes('\n')) return '"' + s.replace(/"/g, '""') + '"';
    return s;
}
function descargarCSV(filas, nombre) {
    const contenido = '\uFEFF' + filas.map(f => f.map(csvEscape).join(';')).join('\r\n');
    const blob = new Blob([contenido], { type: 'text/csv;charset=utf-8;' });
    try { descargarBlob(blob, nombre); }
    catch { alert('No se pudo descargar el CSV.'); }
}
function exportarVentasCSV() {
    const filas = [['Fecha', 'Cliente', 'Tipo', 'Estado', 'Total', 'Productos', 'Saldo pendiente']];
    [...ventas].sort((a, b) => new Date(b.fecha) - new Date(a.fecha)).forEach(v => {
        const c = obtenerCliente(v.clienteId);
        filas.push([
            formatearFechaHora(v.fecha), c ? c.nombre : 'Eliminado', v.tipo, v.estado, v.total,
            v.detalles.map(d => `${d.nombre} x${d.cantidad}`).join(' | '),
            v.tipo === 'credito' ? (v.saldoPendiente || 0) : (v.tipo === 'cuotas' ? v.cuotas.filter(x => !x.pagado).reduce((a, x) => a + x.monto, 0) : 0)
        ]);
    });
    descargarCSV(filas, `ventas-${hoy()}.csv`);
}
function exportarDeudasCSV() {
    const deudas = obtenerClientesConDeuda();
    const filas = [['Cliente', 'Teléfono', 'Email', 'Saldo adeudado']];
    Object.entries(deudas).forEach(([clienteId, monto]) => {
        const c = obtenerCliente(clienteId);
        filas.push([c ? c.nombre : 'Eliminado', c ? (c.telefono || '') : '', c ? (c.email || '') : '', monto]);
    });
    descargarCSV(filas, `deudas-${hoy()}.csv`);
}
function exportarStockBajoCSV() {
    const filas = [['Producto', 'Categoría', 'Precio', 'Stock', 'Estado']];
    productos.filter(p => p.stock <= STOCK_BAJO).forEach(p => {
        filas.push([p.nombre, p.categoria || '', p.precio, p.stock, p.stock <= 0 ? 'Agotado' : 'Stock bajo']);
    });
    descargarCSV(filas, `stock-bajo-${hoy()}.csv`);
}

// ---- BUSCADOR GLOBAL ----
function buscarGlobal(term) {
    const t = term.toLowerCase().trim();
    if (!t) return { clientes: [], productos: [], proveedores: [], ventas: [] };
    return {
        clientes: clientes.filter(c => c.nombre.toLowerCase().includes(t) || (c.telefono && c.telefono.includes(t))).slice(0, 5),
        productos: productos.filter(p => p.nombre.toLowerCase().includes(t) || (p.categoria && p.categoria.toLowerCase().includes(t))).slice(0, 5),
        proveedores: proveedores.filter(p => p.nombre.toLowerCase().includes(t) || (p.telefono && p.telefono.includes(t))).slice(0, 5),
        ventas: ventas.filter(v => {
            const c = obtenerCliente(v.clienteId);
            const nC = c ? c.nombre.toLowerCase() : '';
            const nP = v.detalles.map(d => d.nombre.toLowerCase()).join(' ');
            return nC.includes(t) || nP.includes(t);
        }).slice(0, 5)
    };
}

function renderResultadosGlobales() {
    const input = document.getElementById('busquedaGlobal');
    const cont = document.getElementById('resultadosGlobales');
    const term = input.value.trim();
    if (!term) { cont.classList.remove('show'); cont.innerHTML = ''; return; }
    const r = buscarGlobal(term);
    const total = r.clientes.length + r.productos.length + r.proveedores.length + r.ventas.length;
    if (total === 0) {
        cont.innerHTML = `<div class="resultado-vacio">Sin resultados para "${term}"</div>`;
        cont.classList.add('show'); return;
    }
    let html = '';
    if (r.clientes.length) {
        html += `<div class="resultado-grupo"><div class="resultado-grupo-titulo">👥 Clientes</div>`;
        r.clientes.forEach(c => html += `<div class="resultado-item" data-tipo="cliente" data-id="${c.id}"><span>${c.nombre}</span><small>${c.telefono || ''}</small></div>`);
        html += `</div>`;
    }
    if (r.productos.length) {
        html += `<div class="resultado-grupo"><div class="resultado-grupo-titulo">📦 Productos</div>`;
        r.productos.forEach(p => html += `<div class="resultado-item" data-tipo="producto" data-id="${p.id}"><span>${p.nombre}</span><small>Stock: ${p.stock}</small></div>`);
        html += `</div>`;
    }
    if (r.proveedores.length) {
        html += `<div class="resultado-grupo"><div class="resultado-grupo-titulo">🚚 Proveedores</div>`;
        r.proveedores.forEach(p => html += `<div class="resultado-item" data-tipo="proveedor" data-id="${p.id}"><span>${p.nombre}</span><small>${p.telefono || ''}</small></div>`);
        html += `</div>`;
    }
    if (r.ventas.length) {
        html += `<div class="resultado-grupo"><div class="resultado-grupo-titulo">🧾 Ventas</div>`;
        r.ventas.forEach(v => {
            const c = obtenerCliente(v.clienteId);
            html += `<div class="resultado-item" data-tipo="venta" data-id="${v.id}"><span>#${v.id.slice(0,6)} - ${c ? c.nombre : 'Eliminado'}</span><small>${formatearMoneda(v.total)}</small></div>`;
        });
        html += `</div>`;
    }
    cont.innerHTML = html;
    cont.classList.add('show');
}

function irASeccion(section) {
    document.querySelectorAll('.nav-menu a').forEach(l => l.classList.remove('active'));
    const link = document.querySelector(`.nav-menu a[data-section="${section}"]`);
    if (link) link.classList.add('active');
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById(`section-${section}`).classList.add('active');
    if (section === 'clientes') renderClientes();
    else if (section === 'productos') renderProductos();
    else if (section === 'proveedores') { renderProveedores(); renderCompras(); }
    else if (section === 'ventas') { renderVentas(); actualizarSelectClientes(); renderCategoriasTabs(); renderVentaProductosGrid(); renderVentaCarrito(); }
    else if (section === 'reportes') renderReportes();
}

// ---- ALERTAS ----
function generarAlertas() {
    const alertas = [];
    const ahora = Date.now();
    const en7dias = ahora + 7 * 24 * 60 * 60 * 1000;

    const agotados = productos.filter(p => p.stock <= 0);
    if (agotados.length > 0) alertas.push({
        tipo: 'peligro', icono: '🚫',
        texto: `${agotados.length} producto(s) agotado(s)`,
        detalle: agotados.slice(0, 5).map(p => p.nombre).join(', ') + (agotados.length > 5 ? ` y ${agotados.length - 5} más...` : '')
    });
    const bajos = productos.filter(p => p.stock > 0 && p.stock <= STOCK_BAJO);
    if (bajos.length > 0) alertas.push({
        tipo: 'advertencia', icono: '⚠️',
        texto: `${bajos.length} producto(s) con stock bajo`,
        detalle: bajos.slice(0, 5).map(p => `${p.nombre} (${p.stock})`).join(', ') + (bajos.length > 5 ? ` y ${bajos.length - 5} más...` : '')
    });
    const vencidas = [], porVencer = [];
    ventas.forEach(v => {
        if (v.estado !== 'pendiente' || !v.cuotas) return;
        const c = obtenerCliente(v.clienteId);
        const nombre = c ? c.nombre : 'Cliente eliminado';
        v.cuotas.forEach(cu => {
            if (cu.pagado) return;
            const venc = new Date(cu.fechaVencimiento).getTime();
            if (venc < ahora) {
                const dias = Math.floor((ahora - venc) / (1000 * 60 * 60 * 24));
                vencidas.push({ cliente: nombre, cuota: cu.numero, monto: cu.monto, dias });
            } else if (venc <= en7dias) {
                const dias = Math.ceil((venc - ahora) / (1000 * 60 * 60 * 24));
                porVencer.push({ cliente: nombre, cuota: cu.numero, monto: cu.monto, dias });
            }
        });
    });
    if (vencidas.length > 0) alertas.push({
        tipo: 'peligro', icono: '⏰',
        texto: `${vencidas.length} cuota(s) vencida(s) sin pagar`,
        detalle: vencidas.slice(0, 5).map(c => `${c.cliente} - Cuota ${c.cuota} (hace ${c.dias}d)`).join(' · ') + (vencidas.length > 5 ? ` y ${vencidas.length - 5} más...` : '')
    });
    if (porVencer.length > 0) alertas.push({
        tipo: 'advertencia', icono: '📅',
        texto: `${porVencer.length} cuota(s) por vencer esta semana`,
        detalle: porVencer.slice(0, 5).map(c => `${c.cliente} - Cuota ${c.cuota} (en ${c.dias}d)`).join(' · ') + (porVencer.length > 5 ? ` y ${porVencer.length - 5} más...` : '')
    });
    const hace30 = ahora - 30 * 24 * 60 * 60 * 1000;
    const antiguas = ventas.filter(v => v.tipo === 'credito' && v.estado === 'pendiente' && v.saldoPendiente > 0 && new Date(v.fecha).getTime() < hace30);
    if (antiguas.length > 0) {
        const total = antiguas.reduce((a, v) => a + v.saldoPendiente, 0);
        alertas.push({
            tipo: 'advertencia', icono: '📌',
            texto: `${antiguas.length} deuda(s) a crédito con más de 30 días (${formatearMoneda(total)})`,
            detalle: antiguas.slice(0, 5).map(v => {
                const c = obtenerCliente(v.clienteId);
                return `${c ? c.nombre : 'Eliminado'} - ${formatearMoneda(v.saldoPendiente)}`;
            }).join(' · ') + (antiguas.length > 5 ? ` y ${antiguas.length - 5} más...` : '')
        });
    }
    return alertas;
}
function renderAlertas() {
    const cont = document.getElementById('alertasContainer');
    if (!cont) return;
    const alertas = generarAlertas();
    if (alertas.length === 0) { cont.innerHTML = ''; cont.style.display = 'none'; return; }
    cont.style.display = 'flex';
    cont.innerHTML = alertas.map(a => `
        <div class="alerta alerta-${a.tipo}">
            <span class="alerta-icono">${a.icono}</span>
            <div class="alerta-contenido"><strong>${a.texto}</strong><small>${a.detalle}</small></div>
        </div>`).join('');
}

// ============================================================
//  IMPRESIÓN
// ============================================================
function abrirVentanaImpresion(htmlContenido, titulo) {
    const ventana = window.open('', '_blank');
    if (!ventana) {
        // Sin popup: usar iframe oculto
        const iframe = document.createElement('iframe');
        iframe.style.position = 'fixed';
        iframe.style.right = '0';
        iframe.style.bottom = '0';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);
        try {
            iframe.contentDocument.open();
            iframe.contentDocument.write(htmlContenido);
            iframe.contentDocument.close();
        } catch (e) {
            alert('Este APK no soporta impresión directa.');
            return;
        }
        setTimeout(() => {
            try { iframe.contentWindow.focus(); iframe.contentWindow.print(); } catch (e) {
                alert('Este APK no soporta impresión directa.\nSe abrirá el recibo en el navegador.');
                const blob = new Blob([htmlContenido], { type: 'text/html' });
                const url = URL.createObjectURL(blob);
                window.open(url, '_blank');
            }
        }, 500);
        setTimeout(() => { try { document.body.removeChild(iframe); } catch {} }, 60000);
        return;
    }
    ventana.document.open();
    ventana.document.write(htmlContenido);
    ventana.document.close();
    setTimeout(() => {
        try { ventana.focus(); ventana.print(); } catch (e) { console.warn('Print error', e); }
    }, 600);
}

function encabezadoImpresion(titulo, subtitulo = '') {
    return `
        <div class="encabezado">
            <h1>${config.nombreTienda || 'C. G. Geans'}</h1>
            ${config.ruc ? `<div class="linea">RUC: ${config.ruc}</div>` : ''}
            ${config.telefono ? `<div class="linea">Tel: ${config.telefono}</div>` : ''}
            ${config.direccion ? `<div class="linea">${config.direccion}</div>` : ''}
            <hr>
            <h2>${titulo}</h2>
            ${subtitulo ? `<div class="subtitulo">${subtitulo}</div>` : ''}
        </div>
    `;
}

function estilosImpresion() {
    return `
        <style>
            @page { size: A4; margin: 1.5cm; }
            @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
            * { box-sizing: border-box; }
            body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a2634; margin: 0; padding: 20px; }
            h1 { color: ${config.colorPrimario}; font-size: 22px; margin: 0 0 4px 0; text-align: center; }
            h2 { color: ${config.colorPrimario}; font-size: 18px; margin: 12px 0 4px 0; text-align: center; }
            .encabezado { text-align: center; margin-bottom: 16px; }
            .encabezado .linea { color: #6c7a8a; font-size: 12px; }
            .subtitulo { color: #6c7a8a; font-size: 12px; font-style: italic; }
            hr { border: none; border-top: 1px dashed #999; margin: 12px 0; }
            table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 13px; }
            th, td { padding: 6px 8px; text-align: left; border-bottom: 1px solid #e2e8f0; }
            th { background: #f4f7fc; color: #4a5a6a; font-weight: 600; font-size: 12px; text-transform: uppercase; }
            .dato { display: flex; justify-content: space-between; padding: 4px 0; font-size: 13px; }
            .dato strong { color: #4a5a6a; }
            .total { display: flex; justify-content: space-between; padding: 10px 0; font-size: 16px; font-weight: 700; color: ${config.colorPrimario}; border-top: 2px solid ${config.colorPrimario}; margin-top: 8px; }
            .footer { text-align: center; color: #888; font-size: 11px; font-style: italic; margin-top: 20px; }
            .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
            .badge-ok { background: #e1f5f0; color: #2a9d8f; }
            .badge-pend { background: #fff3d6; color: #b4831a; }
            .badge-anul { background: #fee9e6; color: #e76f51; }
            h3 { font-size: 14px; color: #4a5a6a; margin-top: 16px; margin-bottom: 6px; }
            @media print { .no-print { display: none !important; } }
        </style>
    `;
}

function imprimirReciboActual() {
    if (!ultimoRecibo || !ultimoRecibo.dataUrl) {
        alert('No hay recibo para imprimir.');
        return;
    }
    const titulo = document.getElementById('modalReciboImagenTitle').textContent || 'Recibo';
    const html = `<!DOCTYPE html>
        <html><head><meta charset="UTF-8"><title>${titulo}</title>${estilosImpresion()}</head>
        <body>
            ${encabezadoImpresion(titulo)}
            <div style="text-align:center;margin:16px 0;">
                <img src="${ultimoRecibo.dataUrl}" style="max-width:100%;height:auto;border-radius:6px;" alt="Recibo" />
            </div>
            <div class="footer">${config.mensajeRecibo || '¡Gracias por su preferencia!'}</div>
        </body></html>`;
    abrirVentanaImpresion(html, titulo);
}

function imprimirDetalleVenta(ventaId) {
    const v = obtenerVenta(ventaId);
    if (!v) return;
    const cliente = obtenerCliente(v.clienteId);
    const estadoBadge = v.estado === 'pagado' ? '<span class="badge badge-ok">✅ Pagado</span>'
        : v.estado === 'pendiente' ? '<span class="badge badge-pend">⏳ Pendiente</span>'
        : '<span class="badge badge-anul">❌ Anulada</span>';

    let productosHtml = `
        <table>
            <thead><tr><th>Producto</th><th style="text-align:center;">Cant.</th><th style="text-align:right;">P. Unit.</th><th style="text-align:right;">Subtotal</th></tr></thead>
            <tbody>
    `;
    v.detalles.forEach(d => {
        productosHtml += `<tr>
            <td>${d.nombre}</td>
            <td style="text-align:center;">${d.cantidad}</td>
            <td style="text-align:right;">${formatearMoneda(d.precioUnitario)}</td>
            <td style="text-align:right;">${formatearMoneda(d.subtotal)}</td>
        </tr>`;
    });
    productosHtml += `</tbody></table>`;

    let extra = '';
    if (v.tipo === 'credito' && v.pagos) {
        extra += `<h3>Abonos realizados</h3>`;
        if (v.pagos.length === 0) extra += `<p style="font-size:13px;color:#888;">Sin abonos aún.</p>`;
        else {
            extra += `<table><thead><tr><th>Fecha</th><th style="text-align:right;">Monto</th></tr></thead><tbody>`;
            v.pagos.forEach(p => { extra += `<tr><td>${formatearFechaHora(p.fecha)}</td><td style="text-align:right;">${formatearMoneda(p.monto)}</td></tr>`; });
            extra += `</tbody></table>`;
        }
        extra += `<div class="dato"><strong>Saldo pendiente:</strong><span>${formatearMoneda(v.saldoPendiente || 0)}</span></div>`;
    }
    if (v.cuotas && v.cuotas.length > 0) {
        extra += `<h3>Cuotas</h3>`;
        extra += `<table><thead><tr><th>Cuota</th><th style="text-align:right;">Monto</th><th>Vencimiento</th><th>Estado</th></tr></thead><tbody>`;
        v.cuotas.forEach(c => {
            extra += `<tr>
                <td>#${c.numero}</td>
                <td style="text-align:right;">${formatearMoneda(c.monto)}</td>
                <td>${formatearFecha(c.fechaVencimiento)}</td>
                <td>${c.pagado ? '✅ Pagada' : '⏳ Pendiente'}</td>
            </tr>`;
        });
        extra += `</tbody></table>`;
    }

    const html = `<!DOCTYPE html>
        <html><head><meta charset="UTF-8"><title>Detalle de Venta</title>${estilosImpresion()}</head>
        <body>
            ${encabezadoImpresion('Detalle de Venta', 'Venta #' + v.id.slice(0, 8))}
            <div class="dato"><strong>Cliente:</strong><span>${cliente ? cliente.nombre : 'Eliminado'}</span></div>
            ${cliente && cliente.telefono ? `<div class="dato"><strong>Teléfono:</strong><span>${cliente.telefono}</span></div>` : ''}
            <div class="dato"><strong>Fecha:</strong><span>${formatearFechaHora(v.fecha)}</span></div>
            <div class="dato"><strong>Tipo:</strong><span>${v.tipo === 'contado' ? 'Contado' : v.tipo === 'credito' ? 'Crédito' : 'Cuotas'}</span></div>
            <div class="dato"><strong>Estado:</strong><span>${estadoBadge}</span></div>
            <hr>
            ${productosHtml}
            <div class="total"><span>TOTAL:</span><span>${formatearMoneda(v.total)}</span></div>
            ${extra}
            <div class="footer">${config.mensajeRecibo || '¡Gracias por su preferencia!'}<br>Impreso: ${formatearFechaHora(new Date().toISOString())}</div>
        </body></html>`;
    abrirVentanaImpresion(html, 'Detalle de Venta');
}

function imprimirReporte() {
    const ventasHoy = obtenerVentasHoy();
    const totalHoy = obtenerTotalVentasHoy();
    const deudas = obtenerClientesConDeuda();
    const totalDeuda = obtenerTotalDeudaPendiente();
    const stockBajo = productos.filter(p => p.stock <= STOCK_BAJO);

    let deudasHtml = `<table><thead><tr><th>Cliente</th><th>Teléfono</th><th style="text-align:right;">Saldo</th></tr></thead><tbody>`;
    if (Object.keys(deudas).length === 0) deudasHtml += `<tr><td colspan="3" style="text-align:center;color:#888;">Sin deudas pendientes</td></tr>`;
    else Object.entries(deudas).forEach(([id, monto]) => {
        const c = obtenerCliente(id);
        deudasHtml += `<tr><td>${c ? c.nombre : 'Eliminado'}</td><td>${c ? (c.telefono || '-') : '-'}</td><td style="text-align:right;">${formatearMoneda(monto)}</td></tr>`;
    });
    deudasHtml += `</tbody></table>`;

    let stockHtml = `<table><thead><tr><th>Producto</th><th>Categoría</th><th style="text-align:center;">Stock</th><th style="text-align:right;">Precio</th></tr></thead><tbody>`;
    if (stockBajo.length === 0) stockHtml += `<tr><td colspan="4" style="text-align:center;color:#888;">Sin productos con stock bajo</td></tr>`;
    else stockBajo.forEach(p => {
        stockHtml += `<tr><td>${p.nombre}</td><td>${p.categoria || '-'}</td><td style="text-align:center;">${p.stock}</td><td style="text-align:right;">${formatearMoneda(p.precio)}</td></tr>`;
    });
    stockHtml += `</tbody></table>`;

    let ventasHtml = `<table><thead><tr><th>Hora</th><th>Cliente</th><th>Tipo</th><th style="text-align:right;">Total</th></tr></thead><tbody>`;
    if (ventasHoy.length === 0) ventasHtml += `<tr><td colspan="4" style="text-align:center;color:#888;">Sin ventas hoy</td></tr>`;
    else ventasHoy.forEach(v => {
        const c = obtenerCliente(v.clienteId);
        ventasHtml += `<tr><td>${new Date(v.fecha).toLocaleTimeString('es-PY', { hour: '2-digit', minute: '2-digit' })}</td><td>${c ? c.nombre : 'Eliminado'}</td><td>${v.tipo}</td><td style="text-align:right;">${formatearMoneda(v.total)}</td></tr>`;
    });
    ventasHtml += `</tbody></table>`;

    const html = `<!DOCTYPE html>
        <html><head><meta charset="UTF-8"><title>Reporte</title>${estilosImpresion()}</head>
        <body>
            ${encabezadoImpresion('Reporte del Día', formatearFecha(new Date().toISOString()))}
            <div class="dato"><strong>Ventas del día:</strong><span>${ventasHoy.length}</span></div>
            <div class="dato"><strong>Total vendido hoy:</strong><span>${formatearMoneda(totalHoy)}</span></div>
            <div class="dato"><strong>Clientes con deuda:</strong><span>${Object.keys(deudas).length}</span></div>
            <div class="dato"><strong>Total deudas pendientes:</strong><span>${formatearMoneda(totalDeuda)}</span></div>
            <div class="dato"><strong>Productos con stock bajo:</strong><span>${stockBajo.length}</span></div>
            <hr>
            <h3>Ventas del día</h3>
            ${ventasHtml}
            <hr>
            <h3>Clientes con deuda</h3>
            ${deudasHtml}
            <hr>
            <h3>Productos con stock bajo</h3>
            ${stockHtml}
            <div class="footer">${config.mensajeRecibo || '¡Gracias por su preferencia!'}<br>Impreso: ${formatearFechaHora(new Date().toISOString())}</div>
        </body></html>`;
    abrirVentanaImpresion(html, 'Reporte del Día');
}

// ---- RECIBOS COMO IMAGEN ----
function dibujarSeparadorCanvas(ctx, x1, y, x2) {
    ctx.strokeStyle = '#cccccc'; ctx.setLineDash([5, 5]);
    ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
    ctx.setLineDash([]);
}
function generarImagenRecibo(titulo, subtitulo, lineas) {
    const escala = 2, width = 480, padding = 30, lineHeight = 26;
    let altura = 150 + padding;
    lineas.forEach(l => {
        if (l.tipo === 'sep') altura += 22;
        else if (l.tipo === 'titulo') altura += lineHeight + 6;
        else if (l.tipo === 'dato') altura += lineHeight;
        else if (l.tipo === 'total') altura += lineHeight + 8;
        else if (l.tipo === 'texto') altura += lineHeight;
        else if (l.tipo === 'small') altura += 20;
        else if (l.tipo === 'espacio') altura += 16;
    });
    altura += 100;
    const canvas = document.createElement('canvas');
    canvas.width = width * escala; canvas.height = altura * escala;
    const ctx = canvas.getContext('2d');
    ctx.scale(escala, escala);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, width, altura);
    ctx.strokeStyle = config.colorPrimario || '#2a6f97'; ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, width - 2, altura - 2);

    let y = padding;
    ctx.fillStyle = config.colorPrimario || '#2a6f97'; ctx.font = 'bold 20px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(config.nombreTienda || 'C. G. Geans', width / 2, y + 20);
    y += 26;
    if (config.ruc || config.telefono || config.direccion) {
        ctx.fillStyle = '#6c7a8a'; ctx.font = '11px "Segoe UI", Arial, sans-serif';
        if (config.ruc) { ctx.fillText('RUC: ' + config.ruc, width / 2, y + 12); y += 16; }
        if (config.telefono) { ctx.fillText('Tel: ' + config.telefono, width / 2, y + 12); y += 16; }
        if (config.direccion) { ctx.fillText(config.direccion, width / 2, y + 12); y += 16; }
    }
    y += 8;
    dibujarSeparadorCanvas(ctx, padding, y, width - padding); y += 20;
    ctx.fillStyle = config.colorPrimario || '#2a6f97'; ctx.font = 'bold 18px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(titulo, width / 2, y + 20); y += 30;
    if (subtitulo) {
        ctx.fillStyle = '#6c7a8a'; ctx.font = '12px "Segoe UI", Arial, sans-serif';
        ctx.fillText(subtitulo, width / 2, y); y += 18;
    }
    dibujarSeparadorCanvas(ctx, padding, y, width - padding); y += 20;
    const maxWidth = width - padding * 2;
    lineas.forEach(l => {
        if (l.tipo === 'sep') { dibujarSeparadorCanvas(ctx, padding, y, width - padding); y += 22; }
        else if (l.tipo === 'titulo') {
            ctx.fillStyle = config.colorPrimario || '#2a6f97'; ctx.font = 'bold 14px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'left';
            ctx.fillText(l.texto, padding, y + 15); y += lineHeight + 5;
        } else if (l.tipo === 'dato') {
            ctx.fillStyle = '#4a5a6a'; ctx.font = 'bold 13px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'left';
            ctx.fillText(l.etiqueta, padding, y + 15);
            ctx.fillStyle = '#1a2634'; ctx.font = '13px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'right';
            ctx.fillText(l.valor, width - padding, y + 15); y += lineHeight;
        } else if (l.tipo === 'total') {
            ctx.fillStyle = config.colorPrimario || '#2a6f97'; ctx.font = 'bold 17px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'left';
            ctx.fillText(l.etiqueta, padding, y + 17);
            ctx.textAlign = 'right'; ctx.fillText(l.valor, width - padding, y + 17); y += lineHeight + 8;
        } else if (l.tipo === 'texto') {
            ctx.fillStyle = '#1a2634'; ctx.font = '13px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'left';
            const palabras = l.texto.split(' ');
            let linea = '';
            palabras.forEach(w => {
                const test = linea ? linea + ' ' + w : w;
                if (ctx.measureText(test).width > maxWidth && linea) { ctx.fillText(linea, padding, y + 15); y += lineHeight; linea = w; }
                else linea = test;
            });
            if (linea) { ctx.fillText(linea, padding, y + 15); y += lineHeight; }
        } else if (l.tipo === 'small') {
            ctx.fillStyle = '#6c7a8a'; ctx.font = 'italic 11px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'left';
            ctx.fillText(l.texto, padding, y + 13); y += 20;
        } else if (l.tipo === 'espacio') { y += 16; }
    });
    y += 4; dibujarSeparadorCanvas(ctx, padding, y, width - padding); y += 24;
    ctx.fillStyle = '#888888'; ctx.font = 'italic 12px "Segoe UI", Arial, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(config.mensajeRecibo || '¡Gracias por su preferencia!', width / 2, y);
    return canvas.toDataURL('image/png');
}
function mostrarModalRecibo(titulo, lineas, nombreArchivo, telefonoCliente) {
    const dataUrl = generarImagenRecibo(titulo, '', lineas);
    ultimoRecibo = { dataUrl, nombreArchivo, telefono: telefonoCliente || '' };
    document.getElementById('modalReciboImagenTitle').textContent = titulo;
    document.getElementById('reciboImagenImg').src = dataUrl;
    document.getElementById('reciboHint').textContent = telefonoCliente
        ? 'Puedes enviarla por WhatsApp o imprimirla.'
        : 'El cliente no tiene teléfono registrado. Puedes imprimir o descargar la imagen.';
    abrirModal('modalReciboImagen');
}
function mostrarReciboVentaImagen(ventaId) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return;
    const cliente = obtenerCliente(venta.clienteId);
    const lineas = [
        { tipo: 'dato', etiqueta: 'Cliente:', valor: cliente ? cliente.nombre : 'Eliminado' },
        { tipo: 'dato', etiqueta: 'Venta ID:', valor: '#' + venta.id.slice(0, 8) },
        { tipo: 'dato', etiqueta: 'Fecha:', valor: formatearFechaHora(venta.fecha) },
        { tipo: 'dato', etiqueta: 'Tipo:', valor: venta.tipo === 'contado' ? 'Contado' : venta.tipo === 'credito' ? 'Crédito' : 'Cuotas' },
        { tipo: 'dato', etiqueta: 'Estado:', valor: venta.estado === 'pagado' ? 'Pagado' : venta.estado === 'pendiente' ? 'Pendiente' : 'Anulada' },
        { tipo: 'sep' }, { tipo: 'titulo', texto: 'Productos:' }
    ];
    venta.detalles.forEach(d => lineas.push({ tipo: 'texto', texto: `${d.nombre} x${d.cantidad} = ${formatearMoneda(d.subtotal)}` }));
    lineas.push({ tipo: 'sep' });
    lineas.push({ tipo: 'total', etiqueta: 'TOTAL:', valor: formatearMoneda(venta.total) });
    if (venta.tipo === 'credito' && venta.saldoPendiente > 0) lineas.push({ tipo: 'dato', etiqueta: 'Saldo pendiente:', valor: formatearMoneda(venta.saldoPendiente) });
    if (venta.tipo === 'cuotas' && venta.cuotas.length > 0) {
        lineas.push({ tipo: 'sep' }); lineas.push({ tipo: 'titulo', texto: 'Cuotas:' });
        venta.cuotas.forEach(c => lineas.push({ tipo: 'texto', texto: `Cuota ${c.numero}: ${formatearMoneda(c.monto)} - ${c.pagado ? 'Pagada' : 'Pendiente'}` }));
    }
    mostrarModalRecibo('Recibo de Venta', lineas, `recibo-venta-${venta.id.slice(0,8)}.png`, cliente?.telefono || '');
}
function mostrarReciboPagoImagen(ventaId, numeroCuota) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return;
    const cuota = venta.cuotas.find(c => c.numero === numeroCuota);
    if (!cuota) return;
    const cliente = obtenerCliente(venta.clienteId);
    const lineas = [
        { tipo: 'small', texto: `Cuota N° ${numeroCuota}` },
        { tipo: 'dato', etiqueta: 'Cliente:', valor: cliente ? cliente.nombre : 'Eliminado' },
        { tipo: 'dato', etiqueta: 'Venta ID:', valor: '#' + venta.id.slice(0, 8) },
        { tipo: 'dato', etiqueta: 'Fecha de pago:', valor: new Date().toLocaleString('es-PY') },
        { tipo: 'sep' },
        { tipo: 'total', etiqueta: 'MONTO PAGADO:', valor: formatearMoneda(cuota.monto) },
        { tipo: 'dato', etiqueta: 'Estado:', valor: 'Pagada' },
        { tipo: 'sep' }, { tipo: 'titulo', texto: 'Detalle de la venta:' }
    ];
    venta.detalles.forEach(d => lineas.push({ tipo: 'texto', texto: `${d.nombre} x${d.cantidad} = ${formatearMoneda(d.subtotal)}` }));
    lineas.push({ tipo: 'sep' });
    lineas.push({ tipo: 'dato', etiqueta: 'Total venta:', valor: formatearMoneda(venta.total) });
    mostrarModalRecibo('Recibo de Pago de Cuota', lineas, `pago-cuota-${venta.id.slice(0,8)}-${numeroCuota}.png`, cliente?.telefono || '');
}
function mostrarReciboAbonoImagen(ventaId, monto, nuevoSaldo) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return;
    const cliente = obtenerCliente(venta.clienteId);
    const lineas = [
        { tipo: 'small', texto: 'Abono a crédito' },
        { tipo: 'dato', etiqueta: 'Cliente:', valor: cliente ? cliente.nombre : 'Eliminado' },
        { tipo: 'dato', etiqueta: 'Venta ID:', valor: '#' + venta.id.slice(0, 8) },
        { tipo: 'dato', etiqueta: 'Fecha de abono:', valor: new Date().toLocaleString('es-PY') },
        { tipo: 'sep' },
        { tipo: 'total', etiqueta: 'MONTO ABONADO:', valor: formatearMoneda(monto) },
        { tipo: 'dato', etiqueta: 'Saldo pendiente:', valor: formatearMoneda(nuevoSaldo) },
        { tipo: 'sep' }, { tipo: 'titulo', texto: 'Detalle de la venta:' }
    ];
    venta.detalles.forEach(d => lineas.push({ tipo: 'texto', texto: `${d.nombre} x${d.cantidad} = ${formatearMoneda(d.subtotal)}` }));
    lineas.push({ tipo: 'sep' });
    lineas.push({ tipo: 'dato', etiqueta: 'Total venta:', valor: formatearMoneda(venta.total) });
    mostrarModalRecibo('Recibo de Abono', lineas, `abono-${venta.id.slice(0,8)}.png`, cliente?.telefono || '');
}
async function enviarReciboImagenWhatsApp() {
    if (!ultimoRecibo || !ultimoRecibo.dataUrl) return;
    const tel = normalizarTelefono(ultimoRecibo.telefono);
    const mensaje = `*${config.nombreTienda}*\nLe enviamos su recibo.`;
    try {
        const res = await fetch(ultimoRecibo.dataUrl);
        const blob = await res.blob();
        const file = new File([blob], ultimoRecibo.nombreArchivo, { type: 'image/png' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({ files: [file], title: 'Recibo ' + config.nombreTienda, text: mensaje });
            return;
        }
    } catch (err) { console.warn('Web Share no disponible:', err); }
    const a = document.createElement('a');
    a.href = ultimoRecibo.dataUrl; a.download = ultimoRecibo.nombreArchivo;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    if (tel) setTimeout(() => window.open(`https://wa.me/${tel}?text=${encodeURIComponent(mensaje + '\n\n(Adjunte la imagen descargada)')}`, '_blank'), 400);
    else alert('Imagen descargada. El cliente no tiene teléfono registrado.');
}
function enviarReciboWhatsApp(ventaId) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return;
    const cliente = obtenerCliente(venta.clienteId);
    if (!cliente || !cliente.telefono) { alert('El cliente no tiene teléfono registrado.'); return; }
    const tel = normalizarTelefono(cliente.telefono);
    let msg = `*${config.nombreTienda} - Recibo de Venta*\n\n`;
    msg += `Cliente: ${cliente.nombre}\nFecha: ${formatearFechaHora(venta.fecha)}\nVenta #${venta.id.slice(0,8)}\n`;
    msg += `Tipo: ${venta.tipo === 'contado' ? 'Contado' : venta.tipo === 'credito' ? 'Crédito' : 'Cuotas'}\n`;
    msg += `Estado: ${venta.estado === 'pagado' ? 'Pagado' : venta.estado === 'pendiente' ? 'Pendiente' : 'Anulada'}\n\n*Productos:*\n`;
    venta.detalles.forEach(d => { msg += `- ${d.nombre} x${d.cantidad} = ${formatearMoneda(d.subtotal)}\n`; });
    msg += `\n*Total: ${formatearMoneda(venta.total)}*\n`;
    if (venta.tipo === 'credito' && venta.saldoPendiente > 0) msg += `Saldo pendiente: ${formatearMoneda(venta.saldoPendiente)}\n`;
    if (venta.tipo === 'cuotas' && venta.cuotas.length > 0) {
        msg += `\n*Cuotas:*\n`;
        venta.cuotas.forEach(c => { msg += `- Cuota ${c.numero}: ${formatearMoneda(c.monto)} - ${c.pagado ? 'Pagada' : 'Pendiente'}\n`; });
    }
    msg += `\n¡Gracias por su compra!`;
    window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msg)}`, '_blank');
}
function enviarRecordatorioCuota(ventaId, numeroCuota) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return;
    const cuota = venta.cuotas.find(c => c.numero === numeroCuota);
    if (!cuota) return;
    const cliente = obtenerCliente(venta.clienteId);
    if (!cliente || !cliente.telefono) { alert('El cliente no tiene teléfono registrado.'); return; }
    const tel = normalizarTelefono(cliente.telefono);
    const venc = new Date(cuota.fechaVencimiento);
    const vencStr = venc.toLocaleDateString('es-PY');
    const ahora = Date.now();
    const diff = venc.getTime() - ahora;
    let estadoTxt;
    if (diff < 0) {
        const dias = Math.floor(-diff / (1000 * 60 * 60 * 24));
        estadoTxt = `venció hace ${dias} día(s) (${vencStr})`;
    } else {
        const dias = Math.ceil(diff / (1000 * 60 * 60 * 24));
        estadoTxt = `vence en ${dias} día(s) (${vencStr})`;
    }
    let msg = `Hola *${cliente.nombre}*, le saludamos de *${config.nombreTienda}*.\n\n`;
    msg += `Le recordamos que tiene pendiente el pago de la *Cuota N° ${numeroCuota}*.\n\n`;
    msg += `💰 *Monto:* ${formatearMoneda(cuota.monto)}\n`;
    msg += `📅 *Vencimiento:* ${estadoTxt}\n`;
    msg += `🧾 *Venta:* #${venta.id.slice(0,8)}\n`;
    if (config.telefono) msg += `\n📞 Para consultas: ${config.telefono}`;
    msg += `\n\n¡Gracias!`;
    window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msg)}`, '_blank');
}

// ---- GALERÍA + CARRITO ----
function obtenerCategorias() {
    const set = new Set();
    productos.forEach(p => { if (p.categoria && p.categoria.trim()) set.add(p.categoria.trim()); });
    return Array.from(set).sort();
}
function renderCategoriasTabs() {
    const cont = document.getElementById('ventaCategoriasTabs');
    if (!cont) return;
    const cats = obtenerCategorias();
    cont.innerHTML = `<button type="button" class="categoria-tab ${categoriaActiva === 'todas' ? 'activa' : ''}" data-categoria="todas">Todas</button>` +
        cats.map(c => `<button type="button" class="categoria-tab ${categoriaActiva === c ? 'activa' : ''}" data-categoria="${c}">${c}</button>`).join('');
}
function colorPorCategoria(categoria) {
    if (!categoria) return '#4a8fbb';
    const colores = ['#4a8fbb', '#2a9d8f', '#e9c46a', '#e76f51', '#9d4edd', '#f4a261', '#118ab2', '#06d6a0', '#ef476f', '#8338ec'];
    let hash = 0;
    for (let i = 0; i < categoria.length; i++) hash = categoria.charCodeAt(i) + ((hash << 5) - hash);
    return colores[Math.abs(hash) % colores.length];
}
function renderVentaProductosGrid(filtro = '') {
    const grid = document.getElementById('ventaProductosGrid');
    if (!grid) return;
    const term = (filtro || document.getElementById('buscarProductoVenta')?.value || '').toLowerCase().trim();
    let list = productos;
    if (categoriaActiva !== 'todas') list = list.filter(p => (p.categoria || '').trim() === categoriaActiva);
    if (term) list = list.filter(p => p.nombre.toLowerCase().includes(term) || (p.categoria && p.categoria.toLowerCase().includes(term)));
    if (list.length === 0) {
        grid.innerHTML = `<p style="grid-column:1/-1; text-align:center; color:var(--gray); padding:1.5rem; font-size:0.85rem; font-style:italic;">No hay productos disponibles</p>`;
        return;
    }
    grid.innerHTML = list.map(p => {
        const sinStock = p.stock <= 0;
        const bajo = p.stock > 0 && p.stock <= STOCK_BAJO;
        const color = colorPorCategoria(p.categoria);
        const maxRef = Math.max(p.stock, STOCK_BAJO * 3, 1);
        const pct = Math.min(100, Math.round((p.stock / maxRef) * 100));
        const stockClass = sinStock ? 'agotado' : bajo ? 'bajo' : '';
        return `<div class="producto-card ${sinStock ? 'sin-stock' : ''}" data-producto-id="${p.id}" style="border-left-color:${color};">
            <button type="button" class="producto-card-add" data-producto-id="${p.id}" title="Agregar al carrito">+</button>
            <div class="producto-card-header"><div class="producto-card-nombre">${p.nombre}</div></div>
            ${p.categoria ? `<span class="producto-card-categoria-badge">${p.categoria}</span>` : ''}
            <div class="producto-card-precio">${formatearMoneda(p.precio)}</div>
            <div class="producto-card-stock-wrap">
                <div class="producto-card-stock-bar"><div class="producto-card-stock-fill ${stockClass}" style="width:${pct}%"></div></div>
                <div class="producto-card-stock-texto ${stockClass}">${p.stock} u.</div>
            </div>
        </div>`;
    }).join('');
}
function agregarAlCarrito(productoId) {
    const prod = obtenerProducto(productoId);
    if (!prod) return;
    if (prod.stock <= 0) { alert(`"${prod.nombre}" no tiene stock disponible.`); return; }
    const item = ventaCarrito.find(i => i.productoId === productoId);
    if (item) {
        if (item.cantidad >= prod.stock) { alert(`Stock máximo alcanzado para "${prod.nombre}" (${prod.stock})`); return; }
        item.cantidad++;
    } else ventaCarrito.push({ productoId, cantidad: 1 });
    renderVentaCarrito();
}
function cambiarCantidadCarrito(productoId, delta) {
    const item = ventaCarrito.find(i => i.productoId === productoId);
    if (!item) return;
    const prod = obtenerProducto(productoId);
    const maxStock = prod ? prod.stock : item.cantidad;
    const nueva = item.cantidad + delta;
    if (nueva <= 0) ventaCarrito = ventaCarrito.filter(i => i.productoId !== productoId);
    else if (nueva > maxStock) { alert(`Stock máximo disponible: ${maxStock}`); return; }
    else item.cantidad = nueva;
    renderVentaCarrito();
}
function eliminarDelCarrito(productoId) {
    ventaCarrito = ventaCarrito.filter(i => i.productoId !== productoId);
    renderVentaCarrito();
}
function renderVentaCarrito() {
    const container = document.getElementById('ventaItemsContainer');
    if (!container) return;
    if (ventaCarrito.length === 0) {
        container.innerHTML = `<p class="carrito-vacio">Haga clic en un producto para agregarlo</p>`;
        actualizarTotalVenta(); return;
    }
    container.innerHTML = ventaCarrito.map(i => {
        const p = obtenerProducto(i.productoId);
        if (!p) return '';
        const subtotal = p.precio * i.cantidad;
        return `<div class="carrito-item">
            <div class="carrito-item-info">
                <div class="carrito-item-nombre">${p.nombre}</div>
                <div class="carrito-item-precio">${formatearMoneda(p.precio)} c/u</div>
                <div class="carrito-item-subtotal">${formatearMoneda(subtotal)}</div>
            </div>
            <div class="carrito-item-cantidad">
                <button type="button" data-carrito-accion="menos" data-producto="${i.productoId}">−</button>
                <span>${i.cantidad}</span>
                <button type="button" data-carrito-accion="mas" data-producto="${i.productoId}">+</button>
            </div>
            <button type="button" class="carrito-item-eliminar" data-carrito-accion="eliminar" data-producto="${i.productoId}">✕</button>
        </div>`;
    }).join('');
    actualizarTotalVenta();
}
function actualizarTotalVenta() {
    let total = 0;
    ventaCarrito.forEach(i => {
        const p = obtenerProducto(i.productoId);
        if (p) total += p.precio * i.cantidad;
    });
    const el = document.getElementById('ventaTotal');
    if (el) el.textContent = formatearMoneda(total);
}

// ---- RENDERIZADO ----
function renderClientes(filtro = '') {
    const tbody = document.getElementById('tbodyClientes');
    const buscar = document.getElementById('buscarCliente');
    const term = (filtro || buscar.value).toLowerCase().trim();
    const list = term ? clientes.filter(c => c.nombre.toLowerCase().includes(term) || (c.telefono && c.telefono.includes(term))) : clientes;
    if (list.length === 0) { tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--gray);padding:2rem;">No hay clientes</td></tr>`; return; }
    tbody.innerHTML = list.map(c => `
        <tr><td><strong>${c.nombre}</strong></td><td>${c.telefono || '-'}</td><td>${c.email || '-'}</td><td>${c.direccion || '-'}</td>
        <td>
            <button class="btn btn-secondary" data-accion="verHistorial" data-id="${c.id}" style="padding:0.2rem 0.7rem;">Historial</button>
            <button class="btn btn-primary" data-accion="editarCliente" data-id="${c.id}" style="padding:0.2rem 0.7rem;">✎</button>
            <button class="btn btn-danger" data-accion="eliminarCliente" data-id="${c.id}" style="padding:0.2rem 0.7rem;">✕</button>
        </td></tr>`).join('');
}
function renderProductos(filtro = '') {
    const tbody = document.getElementById('tbodyProductos');
    const buscar = document.getElementById('buscarProducto');
    const term = (filtro || buscar.value).toLowerCase().trim();
    const list = term ? productos.filter(p => p.nombre.toLowerCase().includes(term) || (p.categoria && p.categoria.toLowerCase().includes(term))) : productos;
    if (list.length === 0) { tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--gray);padding:2rem;">No hay productos</td></tr>`; return; }
    tbody.innerHTML = list.map(p => {
        const stockBajo = p.stock <= STOCK_BAJO;
        return `<tr><td><strong>${p.nombre}</strong></td><td>${p.categoria || '-'}</td><td>${formatearMoneda(p.precio)}</td>
        <td>${p.stock}</td>
        <td>${stockBajo ? '<span class="stock-bajo">⚠️ Stock bajo</span>' : '<span class="stock-normal">✓ Normal</span>'}</td>
        <td>
            <button class="btn btn-primary" data-accion="editarProducto" data-id="${p.id}" style="padding:0.2rem 0.7rem;">✎</button>
            <button class="btn btn-danger" data-accion="eliminarProducto" data-id="${p.id}" style="padding:0.2rem 0.7rem;">✕</button>
        </td></tr>`;
    }).join('');
}
function renderProveedores(filtro = '') {
    const tbody = document.getElementById('tbodyProveedores');
    const buscar = document.getElementById('buscarProveedor');
    const term = (filtro || buscar.value).toLowerCase().trim();
    const list = term ? proveedores.filter(p => p.nombre.toLowerCase().includes(term) || (p.telefono && p.telefono.includes(term))) : proveedores;
    if (list.length === 0) { tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--gray);padding:2rem;">No hay proveedores</td></tr>`; return; }
    tbody.innerHTML = list.map(p => `
        <tr><td><strong>${p.nombre}</strong></td><td>${p.telefono || '-'}</td><td>${p.email || '-'}</td><td>${p.direccion || '-'}</td>
        <td>
            <button class="btn btn-primary" data-accion="editarProveedor" data-id="${p.id}" style="padding:0.2rem 0.7rem;">✎</button>
            <button class="btn btn-danger" data-accion="eliminarProveedor" data-id="${p.id}" style="padding:0.2rem 0.7rem;">✕</button>
        </td></tr>`).join('');
}
function renderCompras(filtro = '') {
    const tbody = document.getElementById('tbodyCompras');
    const buscar = document.getElementById('buscarCompra');
    const term = (filtro || buscar.value).toLowerCase().trim();
    let list = compras;
    if (term) list = list.filter(c => {
        const prov = obtenerProveedor(c.proveedorId);
        const nP = prov ? prov.nombre.toLowerCase() : '';
        return nP.includes(term) || c.productoNombre.toLowerCase().includes(term);
    });
    list = [...list].sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
    if (list.length === 0) { tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--gray);padding:2rem;">No hay compras registradas</td></tr>`; return; }
    tbody.innerHTML = list.map(c => {
        const prov = obtenerProveedor(c.proveedorId);
        return `<tr>
            <td>${formatearFecha(c.fecha)}</td>
            <td>${prov ? prov.nombre : 'Eliminado'}</td>
            <td><strong>${c.productoNombre}</strong></td>
            <td>${c.cantidad}</td>
            <td>${formatearMoneda(c.precioCompra)}</td>
            <td>${formatearMoneda(c.total)}</td>
            <td><button class="btn btn-danger" data-accion="eliminarCompra" data-id="${c.id}" style="padding:0.2rem 0.7rem;">✕</button></td>
        </tr>`;
    }).join('');
}
function renderVentas(filtro = '') {
    const tbody = document.getElementById('tbodyVentas');
    const buscar = document.getElementById('buscarVenta');
    const term = (filtro || buscar.value).toLowerCase().trim();
    const fechaDesde = document.getElementById('filtroFechaDesde')?.value || '';
    const fechaHasta = document.getElementById('filtroFechaHasta')?.value || '';
    const filtroTipo = document.getElementById('filtroTipo')?.value || '';
    const filtroEstado = document.getElementById('filtroEstado')?.value || '';
    let list = ventas;
    if (term) list = list.filter(v => {
        const cliente = obtenerCliente(v.clienteId);
        const nombreCliente = cliente ? cliente.nombre.toLowerCase() : '';
        const productosStr = v.detalles.map(d => d.nombre.toLowerCase()).join(' ');
        return nombreCliente.includes(term) || productosStr.includes(term);
    });
    if (fechaDesde) list = list.filter(v => v.fecha.split('T')[0] >= fechaDesde);
    if (fechaHasta) list = list.filter(v => v.fecha.split('T')[0] <= fechaHasta);
    if (filtroTipo) list = list.filter(v => v.tipo === filtroTipo);
    if (filtroEstado) list = list.filter(v => v.estado === filtroEstado);
    list = [...list].sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
    if (list.length === 0) { tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--gray);padding:2rem;">No hay ventas</td></tr>`; return; }
    tbody.innerHTML = list.map(v => {
        const cliente = obtenerCliente(v.clienteId);
        const nombreCliente = cliente ? cliente.nombre : 'Cliente eliminado';
        let estadoHtml;
        if (v.estado === 'pagado') estadoHtml = '✅ Pagado';
        else if (v.estado === 'pendiente') estadoHtml = '⏳ Pendiente';
        else estadoHtml = '❌ Anulada';
        const puedeEditar = puedeEditarVenta(v);
        const esAnulada = v.estado === 'anulada';
        return `<tr style="${esAnulada ? 'opacity:0.55;' : ''}">
            <td>${formatearFecha(v.fecha)}</td>
            <td>${nombreCliente}</td>
            <td>${v.tipo === 'contado' ? 'Contado' : v.tipo === 'credito' ? 'Crédito' : 'Cuotas'}</td>
            <td>${formatearMoneda(v.total)}</td>
            <td>${estadoHtml}</td>
            <td style="white-space:nowrap;">
                <button class="btn btn-secondary" data-accion="verDetalleVenta" data-id="${v.id}" style="padding:0.2rem 0.5rem;font-size:0.78rem;">Ver</button>
                ${!esAnulada && puedeEditar ? `<button class="btn btn-primary" data-accion="editarVenta" data-id="${v.id}" style="padding:0.2rem 0.5rem;font-size:0.78rem;">✎</button>` : ''}
                ${!esAnulada ? `<button class="btn btn-danger" data-accion="anularVenta" data-id="${v.id}" style="padding:0.2rem 0.5rem;font-size:0.78rem;">Anular</button>` : ''}
                <button class="btn btn-success" data-accion="whatsappVenta" data-id="${v.id}" style="padding:0.2rem 0.5rem;font-size:0.78rem;">📱</button>
            </td></tr>`;
    }).join('');
}
function renderReportes() {
    const ventasHoy = obtenerVentasHoy();
    document.getElementById('reporteVentasHoy').textContent = ventasHoy.length;
    document.getElementById('reporteTotalHoy').textContent = formatearMoneda(obtenerTotalVentasHoy());
    const deudas = obtenerClientesConDeuda();
    const totalDeuda = obtenerTotalDeudaPendiente();
    document.getElementById('reporteClientesDeuda').textContent = Object.keys(deudas).length;
    document.getElementById('reporteTotalDeuda').textContent = formatearMoneda(totalDeuda);
    const bajo = productos.filter(p => p.stock <= STOCK_BAJO).length;
    document.getElementById('reporteStockBajo').textContent = bajo;
    const tbodyDeuda = document.getElementById('tbodyDeudaClientes');
    const entries = Object.entries(deudas);
    if (entries.length === 0) tbodyDeuda.innerHTML = `<tr><td colspan="3" style="text-align:center;color:var(--gray);">No hay deudas pendientes</td></tr>`;
    else tbodyDeuda.innerHTML = entries.map(([clienteId, monto]) => {
        const cliente = obtenerCliente(clienteId);
        const tieneCredito = ventas.some(v => v.clienteId === clienteId && v.tipo === 'credito' && v.estado === 'pendiente' && v.saldoPendiente > 0);
        return `<tr><td>${cliente ? cliente.nombre : 'Cliente eliminado'}</td><td>${formatearMoneda(monto)}</td>
        <td>${tieneCredito ? `<button class="btn btn-success" data-accion="abonarCredito" data-cliente="${clienteId}" style="padding:0.2rem 0.7rem;">Abonar</button>` : '—'}</td></tr>`;
    }).join('');
    const pendientes = obtenerPagosPendientes();
    const tbodyPagos = document.getElementById('tbodyPagosPendientes');
    if (pendientes.length === 0) tbodyPagos.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--gray);">No hay cuotas pendientes</td></tr>`;
    else tbodyPagos.innerHTML = pendientes.map(p => `
        <tr>
            <td>${p.clienteNombre}</td>
            <td>#${p.ventaId.slice(0,6)}</td>
            <td>${p.numeroCuota}</td>
            <td>${formatearMoneda(p.monto)}</td>
            <td>${formatearFecha(p.fechaVencimiento)}</td>
            <td style="white-space:nowrap;">
                <button class="btn btn-success" data-accion="pagarCuota" data-venta="${p.ventaId}" data-cuota="${p.numeroCuota}" style="padding:0.2rem 0.5rem;font-size:0.78rem;">Pagar</button>
                <button class="btn btn-primary" data-accion="recordarCuota" data-venta="${p.ventaId}" data-cuota="${p.numeroCuota}" style="padding:0.2rem 0.5rem;font-size:0.78rem;" title="Recordar por WhatsApp">📱</button>
            </td>
        </tr>`).join('');
}

// ---- SELECTORES ----
function actualizarSelectClientes() {
    document.getElementById('ventaCliente').innerHTML = '<option value="">Seleccione un cliente</option>' + clientes.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
}
function actualizarSelectsCompra() {
    document.getElementById('compraProveedor').innerHTML = '<option value="">Seleccione proveedor</option>' + proveedores.map(p => `<option value="${p.id}">${p.nombre}</option>`).join('');
    document.getElementById('compraProducto').innerHTML = '<option value="">Seleccione producto</option>' + productos.map(p => `<option value="${p.id}">${p.nombre} (Stock: ${p.stock})</option>`).join('');
}

// ---- MODALES ----
function abrirModal(id) { document.getElementById(id).classList.add('show'); }
function cerrarModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', function(e) { if (e.target === this) this.classList.remove('show'); });
});
document.querySelectorAll('.modal-close').forEach(el => {
    el.addEventListener('click', function() { this.closest('.modal').classList.remove('show'); });
});

// ---- EDICIÓN DE VENTA ----
function agregarFilaEditarVenta(productoId = '', cantidad = 1) {
    const container = document.getElementById('editarVentaItemsContainer');
    const row = document.createElement('div');
    row.className = 'venta-item-row';
    row.innerHTML = `<select class="editar-venta-producto-select" style="flex:2;"></select>
        <input type="number" class="editar-venta-cantidad" placeholder="Cantidad" min="1" value="${cantidad}" style="flex:1;width:80px;" />
        <button type="button" class="btn btn-danger btn-eliminar-item-editar" style="padding:0.2rem 0.7rem;">✕</button>`;
    container.appendChild(row);
    const sel = row.querySelector('.editar-venta-producto-select');
    sel.innerHTML = '<option value="">Producto</option>' + productos.map(p => `<option value="${p.id}">${p.nombre} (${formatearMoneda(p.precio)})</option>`).join('');
    if (productoId) sel.value = productoId;
    sel.addEventListener('change', actualizarTotalEditarVenta);
    row.querySelector('.editar-venta-cantidad').addEventListener('input', actualizarTotalEditarVenta);
    row.querySelector('.btn-eliminar-item-editar').addEventListener('click', () => { row.remove(); actualizarTotalEditarVenta(); });
}
function actualizarTotalEditarVenta() {
    let total = 0;
    document.querySelectorAll('#editarVentaItemsContainer .venta-item-row').forEach(row => {
        const s = row.querySelector('.editar-venta-producto-select');
        const c = row.querySelector('.editar-venta-cantidad');
        if (s && c && s.value) { const p = obtenerProducto(s.value); if (p) total += p.precio * (parseInt(c.value) || 0); }
    });
    document.getElementById('editarVentaTotal').textContent = formatearMoneda(total);
}
function abrirEditarVenta(ventaId) {
    const venta = obtenerVenta(ventaId);
    if (!venta) return;
    if (!puedeEditarVenta(venta)) { alert('No se puede editar: la venta ya tiene pagos registrados o está anulada.'); return; }
    ventaEnEdicionId = ventaId;
    const cliente = obtenerCliente(venta.clienteId);
    document.getElementById('editarVentaInfo').innerHTML = `
        <p><strong>Cliente:</strong> ${cliente ? cliente.nombre : 'Eliminado'}</p>
        <p><strong>Venta:</strong> #${venta.id.slice(0,8)} - ${formatearFecha(venta.fecha)}</p>
        <p><strong>Tipo:</strong> ${venta.tipo}</p>`;
    const container = document.getElementById('editarVentaItemsContainer');
    container.innerHTML = '';
    venta.detalles.forEach(d => agregarFilaEditarVenta(d.productoId, d.cantidad));
    actualizarTotalEditarVenta();
    abrirModal('modalEditarVenta');
}

function abrirDetalleVenta(v) {
    const cliente = obtenerCliente(v.clienteId);
    const content = document.getElementById('detalleVentaContent');
    let html = `<p><strong>Cliente:</strong> ${cliente ? cliente.nombre : 'Eliminado'}</p>
        <p><strong>Fecha:</strong> ${formatearFecha(v.fecha)}</p>
        <p><strong>Tipo:</strong> ${v.tipo} | <strong>Total:</strong> ${formatearMoneda(v.total)} | <strong>Estado:</strong> ${v.estado}</p>
        <hr><h4>Productos</h4><ul>`;
    v.detalles.forEach(d => html += `<li>${d.nombre} x${d.cantidad} = ${formatearMoneda(d.subtotal)}</li>`);
    html += '</ul>';
    if (v.tipo === 'credito' && v.pagos) {
        html += `<hr><h4>Abonos realizados</h4><ul>`;
        if (v.pagos.length === 0) html += `<li>Sin abonos aún</li>`;
        else v.pagos.forEach(p => html += `<li>${formatearMoneda(p.monto)} - ${formatearFechaHora(p.fecha)}</li>`);
        html += `</ul><p><strong>Saldo pendiente:</strong> ${formatearMoneda(v.saldoPendiente || 0)}</p>`;
    }
    if (v.cuotas && v.cuotas.length > 0) {
        html += `<hr><h4>Cuotas</h4><ul>`;
        v.cuotas.forEach(c => html += `<li>Cuota ${c.numero}: ${formatearMoneda(c.monto)} - ${c.pagado ? '✅ Pagada' : '⏳ Pendiente'}</li>`);
        html += '</ul>';
    }
    html += `<hr><div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-top:0.5rem;">
        <button class="btn btn-secondary" data-accion="reciboImagenVenta" data-id="${v.id}">🖼 Ver recibo (imagen)</button>
        <button class="btn btn-success" data-accion="whatsappVenta" data-id="${v.id}">📱 WhatsApp</button>
        <button class="btn btn-primary" data-accion="imprimirDetalleVenta" data-id="${v.id}">🖨️ Imprimir</button>
        ${v.estado !== 'anulada' ? `<button class="btn btn-danger" data-accion="anularVenta" data-id="${v.id}">Anular venta</button>` : ''}
    </div>`;
    content.innerHTML = html;
    abrirModal('modalDetalleVenta');
}

function refrescarTodo() {
    renderClientes(); renderProductos(); renderProveedores(); renderCompras();
    renderVentas(); renderReportes();
    actualizarSelectClientes(); actualizarSelectsCompra();
    renderCategoriasTabs(); renderVentaProductosGrid(); renderVentaCarrito();
    renderAlertas();
}

// ============================================================
//  INICIALIZACIÓN
// ============================================================
function init() {
    cargarDatos();
    aplicarConfiguracion();
    aplicarModoOscuro();

    // Navegación
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            irASeccion(this.dataset.section);
        });
    });

    // Modo oscuro
    document.getElementById('btnModoOscuro').addEventListener('click', () => {
        darkMode = !darkMode;
        aplicarModoOscuro();
        guardarDatos();
    });

    // Configuración
    document.getElementById('btnConfiguracion').addEventListener('click', () => {
        document.getElementById('cfgNombre').value = config.nombreTienda;
        document.getElementById('cfgTelefono').value = config.telefono;
        document.getElementById('cfgRuc').value = config.ruc;
        document.getElementById('cfgDireccion').value = config.direccion;
        document.getElementById('cfgMensajeRecibo').value = config.mensajeRecibo;
        document.getElementById('cfgColor').value = config.colorPrimario;
        abrirModal('modalConfiguracion');
    });
    document.getElementById('formConfiguracion').addEventListener('submit', function(e) {
        e.preventDefault();
        config.nombreTienda = document.getElementById('cfgNombre').value.trim() || 'C. G. Geans';
        config.telefono = document.getElementById('cfgTelefono').value.trim();
        config.ruc = document.getElementById('cfgRuc').value.trim();
        config.direccion = document.getElementById('cfgDireccion').value.trim();
        config.mensajeRecibo = document.getElementById('cfgMensajeRecibo').value.trim() || '¡Gracias por su preferencia!';
        config.colorPrimario = document.getElementById('cfgColor').value;
        guardarDatos();
        aplicarConfiguracion();
        cerrarModal('modalConfiguracion');
        alert('✅ Configuración guardada.');
    });
    document.getElementById('btnCancelarConfiguracion').addEventListener('click', () => cerrarModal('modalConfiguracion'));

    // Buscador global
    const inputGlobal = document.getElementById('busquedaGlobal');
    const resGlobal = document.getElementById('resultadosGlobales');
    inputGlobal.addEventListener('input', renderResultadosGlobales);
    inputGlobal.addEventListener('focus', renderResultadosGlobales);
    document.addEventListener('click', (e) => { if (!e.target.closest('.nav-search')) resGlobal.classList.remove('show'); });
    resGlobal.addEventListener('click', (e) => {
        const item = e.target.closest('.resultado-item');
        if (!item) return;
        const tipo = item.dataset.tipo;
        const id = item.dataset.id;
        inputGlobal.value = '';
        resGlobal.classList.remove('show');
        if (tipo === 'cliente') {
            irASeccion('clientes');
            const c = obtenerCliente(id);
            if (c) alert('Cliente: ' + c.nombre + '\nTel: ' + (c.telefono || '-'));
        } else if (tipo === 'producto') {
            irASeccion('productos');
            const p = obtenerProducto(id);
            if (p) alert('Producto: ' + p.nombre + '\nStock: ' + p.stock);
        } else if (tipo === 'proveedor') {
            irASeccion('proveedores');
        } else if (tipo === 'venta') {
            irASeccion('ventas');
            const v = obtenerVenta(id);
            if (v) abrirDetalleVenta(v);
        }
    });

    // Búsquedas locales
    document.getElementById('buscarCliente').addEventListener('input', () => renderClientes());
    document.getElementById('buscarProducto').addEventListener('input', () => renderProductos());
    document.getElementById('buscarVenta').addEventListener('input', () => renderVentas());
    document.getElementById('buscarProveedor').addEventListener('input', () => renderProveedores());
    document.getElementById('buscarCompra').addEventListener('input', () => renderCompras());

    // Filtros ventas
    ['filtroFechaDesde','filtroFechaHasta','filtroTipo','filtroEstado'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', () => renderVentas());
    });
    document.getElementById('btnLimpiarFiltros').addEventListener('click', () => {
        document.getElementById('filtroFechaDesde').value = '';
        document.getElementById('filtroFechaHasta').value = '';
        document.getElementById('filtroTipo').value = '';
        document.getElementById('filtroEstado').value = '';
        document.getElementById('buscarVenta').value = '';
        renderVentas();
    });

    // Tabs internas Proveedores
    document.querySelectorAll('.tab-interna').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.tab-interna').forEach(t => t.classList.remove('activa'));
            document.querySelectorAll('.tab-contenido').forEach(t => t.classList.remove('activa'));
            this.classList.add('activa');
            document.getElementById('tabContenido' + this.dataset.tab.charAt(0).toUpperCase() + this.dataset.tab.slice(1)).classList.add('activa');
        });
    });

    // Galería
    document.getElementById('buscarProductoVenta').addEventListener('input', function() { renderVentaProductosGrid(this.value); });
    document.getElementById('ventaCategoriasTabs').addEventListener('click', function(e) {
        const btn = e.target.closest('.categoria-tab');
        if (!btn) return;
        categoriaActiva = btn.dataset.categoria;
        renderCategoriasTabs(); renderVentaProductosGrid();
    });
    document.getElementById('ventaProductosGrid').addEventListener('click', function(e) {
        const addBtn = e.target.closest('.producto-card-add');
        if (addBtn) { e.stopPropagation(); agregarAlCarrito(addBtn.dataset.productoId); return; }
        const card = e.target.closest('.producto-card');
        if (!card || card.classList.contains('sin-stock')) return;
        agregarAlCarrito(card.dataset.productoId);
    });
    document.getElementById('ventaItemsContainer').addEventListener('click', function(e) {
        const btn = e.target.closest('[data-carrito-accion]');
        if (!btn) return;
        const prodId = btn.dataset.producto;
        const accion = btn.dataset.carritoAccion;
        if (accion === 'mas') cambiarCantidadCarrito(prodId, 1);
        else if (accion === 'menos') cambiarCantidadCarrito(prodId, -1);
        else if (accion === 'eliminar') eliminarDelCarrito(prodId);
    });
    document.getElementById('btnVaciarCarrito').addEventListener('click', () => {
        if (ventaCarrito.length === 0) return;
        if (confirm('¿Vaciar el carrito?')) { ventaCarrito = []; renderVentaCarrito(); }
    });

    // Respaldo manual
    document.getElementById('btnExportarRespaldo').addEventListener('click', exportarRespaldo);
    document.getElementById('btnImportarRespaldo').addEventListener('click', importarRespaldo);

    // Auto-respaldos
    document.getElementById('btnAutoRespaldos').addEventListener('click', abrirModalAutoRespaldos);
    document.getElementById('btnCerrarAutoRespaldos').addEventListener('click', () => cerrarModal('modalAutoRespaldos'));
    document.getElementById('autoRespaldosContenido').addEventListener('click', (e) => {
        const btn = e.target.closest('[data-auto-accion]');
        if (!btn) return;
        const idx = parseInt(btn.dataset.index);
        const accion = btn.dataset.autoAccion;
        if (accion === 'restaurar') restaurarAutoRespaldo(idx);
        else if (accion === 'eliminar') eliminarAutoRespaldo(idx);
    });

    // CSV
    document.getElementById('btnExportarVentasCSV').addEventListener('click', exportarVentasCSV);
    document.getElementById('btnExportarDeudasCSV').addEventListener('click', exportarDeudasCSV);
    document.getElementById('btnExportarStockBajoCSV').addEventListener('click', exportarStockBajoCSV);

    // Impresión
    document.getElementById('btnImprimirRecibo').addEventListener('click', imprimirReciboActual);
    document.getElementById('btnImprimirReporte').addEventListener('click', imprimirReporte);

    // Clientes
    document.getElementById('btnAgregarCliente').addEventListener('click', () => {
        document.getElementById('modalClienteTitle').textContent = 'Nuevo Cliente';
        document.getElementById('clienteId').value = '';
        document.getElementById('formCliente').reset();
        abrirModal('modalCliente');
    });
    document.getElementById('formCliente').addEventListener('submit', function(e) {
        e.preventDefault();
        const id = document.getElementById('clienteId').value;
        const nombre = document.getElementById('clienteNombre').value.trim();
        const telefono = document.getElementById('clienteTelefono').value.trim();
        const email = document.getElementById('clienteEmail').value.trim();
        const direccion = document.getElementById('clienteDireccion').value.trim();
        if (!nombre) return alert('El nombre es obligatorio');
        if (id) editarCliente(id, nombre, telefono, email, direccion);
        else crearCliente(nombre, telefono, email, direccion);
        cerrarModal('modalCliente');
        renderClientes(); actualizarSelectClientes();
    });

    // Productos
    document.getElementById('btnAgregarProducto').addEventListener('click', () => {
        document.getElementById('modalProductoTitle').textContent = 'Nuevo Producto';
        document.getElementById('productoId').value = '';
        document.getElementById('formProducto').reset();
        abrirModal('modalProducto');
    });
    document.getElementById('formProducto').addEventListener('submit', function(e) {
        e.preventDefault();
        const id = document.getElementById('productoId').value;
        const nombre = document.getElementById('productoNombre').value.trim();
        const categoria = document.getElementById('productoCategoria').value.trim();
        const precio = parseFloat(document.getElementById('productoPrecio').value);
        const stock = parseInt(document.getElementById('productoStock').value);
        if (!nombre || isNaN(precio) || isNaN(stock)) return alert('Complete los campos obligatorios');
        if (id) editarProducto(id, nombre, categoria, precio, stock);
        else crearProducto(nombre, categoria, precio, stock);
        cerrarModal('modalProducto');
        renderProductos(); renderCategoriasTabs(); renderVentaProductosGrid();
    });

    // Proveedores
    document.getElementById('btnAgregarProveedor').addEventListener('click', () => {
        document.getElementById('modalProveedorTitle').textContent = 'Nuevo Proveedor';
        document.getElementById('proveedorId').value = '';
        document.getElementById('formProveedor').reset();
        abrirModal('modalProveedor');
    });
    document.getElementById('formProveedor').addEventListener('submit', function(e) {
        e.preventDefault();
        const id = document.getElementById('proveedorId').value;
        const nombre = document.getElementById('proveedorNombre').value.trim();
        const telefono = document.getElementById('proveedorTelefono').value.trim();
        const email = document.getElementById('proveedorEmail').value.trim();
        const direccion = document.getElementById('proveedorDireccion').value.trim();
        if (!nombre) return alert('El nombre es obligatorio');
        if (id) editarProveedor(id, nombre, telefono, email, direccion);
        else crearProveedor(nombre, telefono, email, direccion);
        cerrarModal('modalProveedor');
        renderProveedores(); actualizarSelectsCompra();
    });

    // Compras
    document.getElementById('btnRegistrarCompra').addEventListener('click', () => {
        if (proveedores.length === 0) { alert('Primero registre al menos un proveedor.'); return; }
        if (productos.length === 0) { alert('Primero registre al menos un producto.'); return; }
        actualizarSelectsCompra();
        document.getElementById('formCompra').reset();
        document.getElementById('compraTotalInfo').textContent = '';
        abrirModal('modalCompra');
    });
    document.getElementById('btnCancelarCompra').addEventListener('click', () => cerrarModal('modalCompra'));
    ['compraCantidad', 'compraPrecio'].forEach(id => {
        document.getElementById(id).addEventListener('input', () => {
            const cant = parseInt(document.getElementById('compraCantidad').value) || 0;
            const prec = parseFloat(document.getElementById('compraPrecio').value) || 0;
            document.getElementById('compraTotalInfo').textContent = 'Total: ' + formatearMoneda(cant * prec);
        });
    });
    document.getElementById('formCompra').addEventListener('submit', function(e) {
        e.preventDefault();
        const proveedorId = document.getElementById('compraProveedor').value;
        const productoId = document.getElementById('compraProducto').value;
        const cantidad = parseInt(document.getElementById('compraCantidad').value);
        const precio = parseFloat(document.getElementById('compraPrecio').value);
        const obs = document.getElementById('compraObservaciones').value.trim();
        if (!proveedorId || !productoId || !cantidad || isNaN(precio)) return alert('Complete todos los campos');
        if (registrarCompra(proveedorId, productoId, cantidad, precio, obs)) {
            alert('✅ Compra registrada. Stock actualizado.');
            cerrarModal('modalCompra');
            renderProductos(); renderCompras(); renderAlertas();
            renderVentaProductosGrid(); renderCategoriasTabs();
        } else alert('Error al registrar la compra.');
    });

    // Venta
    document.getElementById('ventaTipo').addEventListener('change', function() {
        document.getElementById('grupoCuotas').style.display = this.value === 'cuotas' ? 'block' : 'none';
    });
    document.querySelector('#formVenta button[type="reset"]').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('formVenta').reset();
        ventaCarrito = [];
        document.getElementById('ventaTotal').textContent = 'Gs. 0';
        document.getElementById('grupoCuotas').style.display = 'none';
        document.getElementById('buscarProductoVenta').value = '';
        categoriaActiva = 'todas';
        renderCategoriasTabs(); renderVentaProductosGrid(); renderVentaCarrito();
    });
    document.getElementById('formVenta').addEventListener('submit', function(e) {
        e.preventDefault();
        const clienteId = document.getElementById('ventaCliente').value;
        const tipo = document.getElementById('ventaTipo').value;
        const numCuotas = parseInt(document.getElementById('ventaNumCuotas').value) || 0;
        if (!clienteId) return alert('Seleccione un cliente');
        if (ventaCarrito.length === 0) return alert('Agregue al menos un producto al carrito');
        const items = ventaCarrito.map(i => ({ productoId: i.productoId, cantidad: i.cantidad }));
        for (let item of items) {
            const prod = obtenerProducto(item.productoId);
            if (!prod || prod.stock < item.cantidad) { alert(`Stock insuficiente para "${prod ? prod.nombre : 'producto'}"`); return; }
        }
        try {
            const venta = registrarVenta(clienteId, tipo, items, numCuotas);
            alert('Venta registrada con éxito');
            mostrarReciboVentaImagen(venta.id);
            renderVentas(); renderReportes();
            document.getElementById('formVenta').reset();
            ventaCarrito = [];
            document.getElementById('ventaTotal').textContent = 'Gs. 0';
            document.getElementById('grupoCuotas').style.display = 'none';
            document.getElementById('buscarProductoVenta').value = '';
            categoriaActiva = 'todas';
            renderCategoriasTabs(); renderVentaProductosGrid(); renderVentaCarrito(); renderProductos();
        } catch (err) { alert('Error: ' + err.message); }
    });

    // Editar venta
    document.getElementById('btnAgregarItemEditar').addEventListener('click', () => agregarFilaEditarVenta());
    document.getElementById('btnCancelarEditarVenta').addEventListener('click', () => { cerrarModal('modalEditarVenta'); ventaEnEdicionId = null; });
    document.getElementById('btnGuardarEditarVenta').addEventListener('click', () => {
        if (!ventaEnEdicionId) return;
        const items = [];
        document.querySelectorAll('#editarVentaItemsContainer .venta-item-row').forEach(row => {
            const prodId = row.querySelector('.editar-venta-producto-select').value;
            const cant = parseInt(row.querySelector('.editar-venta-cantidad').value) || 0;
            if (prodId && cant > 0) items.push({ productoId: prodId, cantidad: cant });
        });
        if (items.length === 0) return alert('Agregue al menos un producto');
        if (actualizarVenta(ventaEnEdicionId, items)) {
            alert('Venta actualizada');
            cerrarModal('modalEditarVenta'); ventaEnEdicionId = null;
            renderVentas(); renderProductos(); renderReportes(); renderVentaProductosGrid();
        } else alert('Error al actualizar. Verifique el stock.');
    });

    // Pago parcial
    document.getElementById('formPagoParcial').addEventListener('submit', function(e) {
        e.preventDefault();
        const ventaId = document.getElementById('pagoVentaSelect').value;
        const monto = parseFloat(document.getElementById('pagoMonto').value);
        if (!ventaId) return alert('Seleccione una venta');
        if (isNaN(monto) || monto <= 0) return alert('Monto inválido');
        const venta = obtenerVenta(ventaId);
        if (!venta) return alert('Venta no encontrada');
        if (monto > venta.saldoPendiente) return alert(`Monto mayor al saldo (${formatearMoneda(venta.saldoPendiente)})`);
        if (registrarPagoParcial(ventaId, monto)) {
            alert('Abono registrado');
            mostrarReciboAbonoImagen(ventaId, monto, venta.saldoPendiente);
            cerrarModal('modalPagoParcial');
            renderReportes(); renderVentas();
        } else alert('Error al registrar abono');
    });
    document.getElementById('btnCancelarPagoParcial').addEventListener('click', () => cerrarModal('modalPagoParcial'));

    // Recibo modal
    document.getElementById('btnEnviarReciboWhatsApp').addEventListener('click', enviarReciboImagenWhatsApp);
    document.getElementById('btnDescargarRecibo').addEventListener('click', function() {
        if (!ultimoRecibo) return;
        const a = document.createElement('a');
        a.href = ultimoRecibo.dataUrl; a.download = ultimoRecibo.nombreArchivo;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
    });
    document.getElementById('btnCerrarRecibo').addEventListener('click', () => cerrarModal('modalReciboImagen'));

    // Cerrar historial
    document.getElementById('btnCerrarHistorial').addEventListener('click', () => {
        document.getElementById('historialCliente').style.display = 'none';
    });

    // Eventos delegados
    document.addEventListener('click', function(e) {
        const target = e.target.closest('[data-accion]');
        if (!target) return;
        const accion = target.dataset.accion;
        const id = target.dataset.id;

        if (accion === 'eliminarCliente') {
            if (confirm('¿Eliminar este cliente?')) { eliminarCliente(id); renderClientes(); actualizarSelectClientes(); }
        } else if (accion === 'editarCliente') {
            const c = obtenerCliente(id);
            if (c) {
                document.getElementById('modalClienteTitle').textContent = 'Editar Cliente';
                document.getElementById('clienteId').value = c.id;
                document.getElementById('clienteNombre').value = c.nombre;
                document.getElementById('clienteTelefono').value = c.telefono || '';
                document.getElementById('clienteEmail').value = c.email || '';
                document.getElementById('clienteDireccion').value = c.direccion || '';
                abrirModal('modalCliente');
            }
        } else if (accion === 'verHistorial') {
            const cliente = obtenerCliente(id);
            if (!cliente) return;
            const comprasC = ventas.filter(v => v.clienteId === id).sort((a,b) => new Date(b.fecha) - new Date(a.fecha));
            const content = document.getElementById('historialContent');
            if (comprasC.length === 0) content.innerHTML = '<p style="color:var(--gray);">Sin compras registradas.</p>';
            else content.innerHTML = comprasC.map(v => {
                let detalle = '';
                if (v.tipo === 'credito' && v.pagos && v.pagos.length > 0)
                    detalle = `<br><small>Abonos: ${v.pagos.map(p => `${formatearMoneda(p.monto)} (${formatearFechaHora(p.fecha)})`).join(', ')}</small>`;
                const estadoTxt = v.estado === 'pagado' ? '✅ Pagado' : v.estado === 'pendiente' ? '⏳ Pendiente' : '❌ Anulada';
                return `<div style="border-bottom:1px solid #eee;padding:0.5rem 0;">
                    <strong>${formatearFecha(v.fecha)}</strong> - ${formatearMoneda(v.total)} (${v.tipo}) - ${estadoTxt}
                    ${detalle}<br><small>${v.detalles.map(d => `${d.nombre} x${d.cantidad}`).join(', ')}</small></div>`;
            }).join('');
            document.getElementById('historialCliente').style.display = 'block';
        } else if (accion === 'eliminarProducto') {
            if (confirm('¿Eliminar este producto?')) { eliminarProducto(id); renderProductos(); renderCategoriasTabs(); renderVentaProductosGrid(); }
        } else if (accion === 'editarProducto') {
            const p = obtenerProducto(id);
            if (p) {
                document.getElementById('modalProductoTitle').textContent = 'Editar Producto';
                document.getElementById('productoId').value = p.id;
                document.getElementById('productoNombre').value = p.nombre;
                document.getElementById('productoCategoria').value = p.categoria || '';
                document.getElementById('productoPrecio').value = p.precio;
                document.getElementById('productoStock').value = p.stock;
                abrirModal('modalProducto');
            }
        } else if (accion === 'eliminarProveedor') {
            if (confirm('¿Eliminar este proveedor?')) { eliminarProveedor(id); renderProveedores(); actualizarSelectsCompra(); }
        } else if (accion === 'editarProveedor') {
            const p = obtenerProveedor(id);
            if (p) {
                document.getElementById('modalProveedorTitle').textContent = 'Editar Proveedor';
                document.getElementById('proveedorId').value = p.id;
                document.getElementById('proveedorNombre').value = p.nombre;
                document.getElementById('proveedorTelefono').value = p.telefono || '';
                document.getElementById('proveedorEmail').value = p.email || '';
                document.getElementById('proveedorDireccion').value = p.direccion || '';
                abrirModal('modalProveedor');
            }
        } else if (accion === 'eliminarCompra') {
            if (confirm('¿Eliminar este registro de compra?\n\nNOTA: NO se revertirá el stock.')) {
                const idx = compras.findIndex(c => c.id === id);
                if (idx !== -1) { compras.splice(idx, 1); guardarDatos(); renderCompras(); }
            }
        } else if (accion === 'verDetalleVenta') {
            const v = obtenerVenta(id);
            if (v) abrirDetalleVenta(v);
        } else if (accion === 'reciboImagenVenta') {
            mostrarReciboVentaImagen(id);
        } else if (accion === 'imprimirDetalleVenta') {
            imprimirDetalleVenta(id);
        } else if (accion === 'editarVenta') {
            abrirEditarVenta(id);
        } else if (accion === 'anularVenta') {
            const v = obtenerVenta(id);
            if (!v) return;
            if (!confirm(`¿Anular la venta #${v.id.slice(0,6)}? Se restaurará el stock.`)) return;
            if (anularVenta(id)) {
                alert('Venta anulada. Stock restaurado.');
                renderVentas(); renderProductos(); renderReportes(); renderVentaProductosGrid();
            } else alert('No se pudo anular la venta.');
        } else if (accion === 'whatsappVenta') {
            enviarReciboWhatsApp(id);
        } else if (accion === 'pagarCuota') {
            const ventaId = target.dataset.venta;
            const cuotaNum = parseInt(target.dataset.cuota);
            if (confirm('¿Registrar pago de esta cuota?')) {
                if (registrarPagoCuota(ventaId, cuotaNum)) {
                    alert('Pago registrado');
                    mostrarReciboPagoImagen(ventaId, cuotaNum);
                    renderVentas(); renderReportes();
                } else alert('Error al registrar pago');
            }
        } else if (accion === 'recordarCuota') {
            const ventaId = target.dataset.venta;
            const cuotaNum = parseInt(target.dataset.cuota);
            enviarRecordatorioCuota(ventaId, cuotaNum);
        } else if (accion === 'abonarCredito') {
            const clienteId = target.dataset.cliente;
            const ventasCredito = ventas.filter(v => v.clienteId === clienteId && v.tipo === 'credito' && v.estado === 'pendiente' && v.saldoPendiente > 0);
            if (ventasCredito.length === 0) { alert('Sin deudas a crédito pendientes.'); return; }
            const select = document.getElementById('pagoVentaSelect');
            select.innerHTML = '';
            ventasCredito.forEach(v => {
                const opt = document.createElement('option');
                opt.value = v.id;
                opt.textContent = `Venta #${v.id.slice(0,6)} - ${formatearFecha(v.fecha)} - Saldo: ${formatearMoneda(v.saldoPendiente)}`;
                select.appendChild(opt);
            });
            const cliente = obtenerCliente(clienteId);
            document.getElementById('pagoParcialInfo').innerHTML = `
                <p><strong>Cliente:</strong> ${cliente ? cliente.nombre : 'Eliminado'}</p>
                <p><strong>Ventas pendientes:</strong> ${ventasCredito.length}</p>`;
            function actualizarSaldoSel() {
                const venta = obtenerVenta(select.value);
                if (venta) {
                    document.getElementById('pagoSaldoInfo').innerHTML = `
                        <p><strong>Saldo actual:</strong> ${formatearMoneda(venta.saldoPendiente)}</p>
                        <p style="font-size:0.9rem;color:#555;">Máximo a abonar: ${formatearMoneda(venta.saldoPendiente)}</p>`;
                    document.getElementById('pagoMonto').max = venta.saldoPendiente;
                }
            }
            select.onchange = actualizarSaldoSel;
            actualizarSaldoSel();
            document.getElementById('pagoMonto').value = '';
            abrirModal('modalPagoParcial');
        }
    });

    // Inicializar UI
    refrescarTodo();
}

document.addEventListener('DOMContentLoaded', init);