// ============================================================
//  Service Worker - C. G. Geans
//  Cachea los archivos principales para funcionar offline
// ============================================================

const CACHE_NAME = 'geans-cache-v2';
const URLS_A_CACHEAR = [
    'index.html',
    'styles.css',
    'script.js',
    'manifest.json',
    'icon-192.png',
    'icon-512.png'
];

// Instalación: guardar archivos en caché
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('[SW] Cacheando archivos...');
                return cache.addAll(URLS_A_CACHEAR).catch(err => {
                    console.warn('[SW] Algunos archivos no se pudieron cachear:', err);
                });
            })
    );
    self.skipWaiting();
});

// Activación: limpiar cachés antiguas
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(nombres =>
            Promise.all(
                nombres
                    .filter(n => n !== CACHE_NAME)
                    .map(n => {
                        console.log('[SW] Borrando caché antigua:', n);
                        return caches.delete(n);
                    })
            )
        )
    );
    self.clients.claim();
});

// Fetch: servir desde caché, si no está, buscar en red
self.addEventListener('fetch', event => {
    // Solo manejamos GET y mismo origen
    if (event.request.method !== 'GET') return;
    const url = new URL(event.request.url);
    if (url.origin !== location.origin) return;

    event.respondWith(
        caches.match(event.request).then(respuestaCache => {
            if (respuestaCache) return respuestaCache;
            return fetch(event.request).then(respuesta => {
                // Guardar copia en caché para futuras visitas
                if (respuesta && respuesta.status === 200) {
                    const clon = respuesta.clone();
                    caches.open(CACHE_NAME).then(c => c.put(event.request, clon));
                }
                return respuesta;
            }).catch(() => {
                // Sin conexión y sin caché
                if (event.request.mode === 'navigate') {
                    return caches.match('index.html');
                }
                return new Response('Sin conexión', { status: 503 });
            });
        })
    );
});