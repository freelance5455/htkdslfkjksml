# CGD — Étape 6.7 : écran 07, Effectif (disposition FM27)

- Le sous-menu « Club » s'ouvre maintenant sur « Effectif » (avant Contrats, Recherche et Éditeur).
- Tableau en lecture seule des damistes du club du joueur : spécialité, âge, niveau, potentiel, forme (Haute / Moyenne / Basse) et moral réel (valeur de relations.playerMorale, 50 par défaut), couleurs vert / orange / rouge.
- La condition physique n'est pas affichée : le jeu ne possède pas cette donnée.
- Correctif de l'écran 09 : le titulaire choisi dans la préparation utilise désormais le mécanisme existant `selectFixtureDamiste` (fixture.damisteSelections), donc il compte pour le classement de la Dame d'Or ; le titulaire déjà choisi dans le calendrier est repris par défaut.
- Le titre du match affiche les noms des clubs au lieu de leurs identifiants.
- Code : `src/squad.js`, branchements dans `src/app.js`, styles dans le bloc `fm27-terrain`, tests dans `tests/squad.test.js` et `tests/match-prep.test.js`.
