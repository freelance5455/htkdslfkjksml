package id.topimerah.app.ui.workspace

import id.topimerah.app.data.api.str
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*

@Composable
fun AgentListScreen(vm: AppViewModel, open: (Int) -> Unit) {
    LaunchedEffect(Unit) { vm.loadAgents() }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("RUANG KERJA 10 AI SPECIALIST", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
        items(vm.agents) { a ->
            Panel(Modifier.clickable { open(a.getInt("id")) }) {
                Text("%02d  %s".format(a.getInt("id"), a.getString("name")), fontWeight = FontWeight.Bold)
                Text(a.getString("description"), style = MaterialTheme.typography.labelSmall, color = Silver)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip(if (a.getBoolean("is_active")) "AKTIF" else "NONAKTIF", if (a.getBoolean("is_active")) Green else Amber)
                    Chip("MESIN: " + a.getString("engine"), Silver)
                }
            }
        }
    }
}

@Composable
fun WorkspaceScreen(vm: AppViewModel, agentId: Int) {
    LaunchedEffect(agentId) { vm.loadAgents(); vm.loadWorkspace(agentId) }
    val agent = vm.agents.firstOrNull { it.getInt("id") == agentId }
    var text by remember { mutableStateOf("") }
    var auth by remember { mutableStateOf("") }
    var asTask by remember { mutableStateOf(false) }
    val redTeam = agent?.getString("code") == "AI_RED_TEAM"
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(agent?.getString("name") ?: "AI #$agentId", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        agent?.let { Text("Mesin: ${it.getString("engine")} | ${if (it.getBoolean("is_active")) "AKTIF" else "NONAKTIF"}", style = MaterialTheme.typography.labelSmall, color = Silver) }
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        vm.info?.let { Text(it, color = Green, style = MaterialTheme.typography.labelSmall) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), reverseLayout = false) {
            items(vm.messages) { m ->
                val mine = m.getString("role") == "user"
                Panel { Text(if (mine) "Anda" else "AI (${m.str("engine")}) - analisis AI, perlu verifikasi", style = MaterialTheme.typography.labelSmall, color = if (mine) Silver else Red); Text(m.getString("content")) }
            }
            if (vm.tasks.isNotEmpty()) item { Text("Riwayat tugas", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
            items(vm.tasks) { t ->
                Panel {
                    Text("#${t.getInt("id")} ${t.getString("instruction").take(120)}", style = MaterialTheme.typography.labelMedium)
                    if (vm.canWrite && t.getInt("forwarded") == 0) OutlinedButton({ vm.forward(t.getInt("id"), agentId) }, enabled = !vm.busy) { Text("Kirim ke AI Commander") }
                    else if (t.getInt("forwarded") == 1) Chip("SUDAH DIKIRIM KE COMMANDER", Green)
                }
            }
        }
        if (vm.canWrite) {
            if (redTeam) OutlinedTextField(auth, { auth = it }, label = { Text("Bukti izin tertulis / kepemilikan target (wajib)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(text, { text = it }, label = { Text("Instruksi untuk AI") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Checkbox(asTask, { asTask = it }); Text("Simpan sbg tugas", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                Button({ vm.send(agentId, text, asTask, auth); text = "" }, enabled = !vm.busy && text.isNotBlank()) { Text(if (vm.busy) "AI bekerja..." else "KIRIM") }
            }
        } else Text("Peran Viewer: hanya dapat melihat.", color = Silver)
    }
}
