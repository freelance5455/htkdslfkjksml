package id.topimerah.app.ui.incident

import id.topimerah.app.data.api.str
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.topimerah.app.data.api.objs
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*

private val CATS = listOf("PHISHING", "RANSOMWARE", "MALWARE", "DATA_BREACH", "DDOS", "VULNERABILITY", "SUSPICIOUS_ACTIVITY", "OTHER")
private val RISKS = listOf("LOW", "MEDIUM", "HIGH", "CRITICAL")

@Composable
fun IncidentListScreen(vm: AppViewModel, open: (Int) -> Unit) {
    LaunchedEffect(Unit) { vm.loadIncidents() }
    var form by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }; var sys by remember { mutableStateOf("") }; var authNote by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(CATS[0]) }; var risk by remember { mutableStateOf(RISKS[1]) }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("INCIDENT RESPONSE CENTER", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (vm.canWrite) Button({ form = !form }) { Text(if (form) "Tutup form" else "Laporan insiden baru") }
            if (form) Panel {
                OutlinedTextField(title, { title = it }, label = { Text("Judul") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(sys, { sys = it }, label = { Text("Sistem terdampak") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(authNote, { authNote = it }, label = { Text("Bukti izin pemilik sistem") }, modifier = Modifier.fillMaxWidth())
                Text("Kategori: $cat  (ketuk untuk ganti)", Modifier.clickable { cat = CATS[(CATS.indexOf(cat) + 1) % CATS.size] }, color = Silver)
                Text("Risiko: $risk  (ketuk untuk ganti)", Modifier.clickable { risk = RISKS[(RISKS.indexOf(risk) + 1) % RISKS.size] }, color = riskColor(risk))
                Button({ vm.createIncident(title, sys, cat, risk, authNote); form = false; title = ""; sys = ""; authNote = "" }, enabled = title.length >= 5 && sys.length >= 2) { Text("Simpan") }
            }
        }
        items(vm.incidents) { i ->
            Panel(Modifier.clickable { open(i.getInt("id")) }) {
                Text("#${i.getInt("id")} ${i.getString("title")}", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Chip(i.getString("status"), Silver); Chip(i.getString("risk"), riskColor(i.getString("risk"))) }
            }
        }
    }
}

@Composable
fun IncidentDetailScreen(vm: AppViewModel, id: Int) {
    LaunchedEffect(id) { vm.report = null; vm.loadIncident(id) }
    var evName by remember { mutableStateOf("") }; var evBody by remember { mutableStateOf("") }; var action by remember { mutableStateOf("") }
    val d = vm.incDetail
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (d == null || d.getJSONObject("incident").getInt("id") != id) { CircularProgressIndicator(); return@Column }
        val i = d.getJSONObject("incident"); val status = i.getString("status")
        Text("#$id ${i.getString("title")}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Chip(status, Silver); Chip(i.getString("risk"), riskColor(i.getString("risk"))) }
        Text("Sistem: ${i.getString("affected_system")} | Izin: ${i.str("authorization_note", "-")}", style = MaterialTheme.typography.labelSmall)
        if (vm.canWrite && status != "CLOSED") Panel {
            Text("Aksi", fontWeight = FontWeight.Bold)
            if (status == "NEW") Button({ vm.setStatus(id, "UNDER_ANALYSIS") }) { Text("Mulai analisis") }
            if (status == "UNDER_ANALYSIS") {
                OutlinedButton({ vm.analyzeIncident(id) }, enabled = !vm.busy) { Text("Analisis AI (Cyber Analyst + Blue Team)") }
                OutlinedTextField(action, { action = it }, label = { Text("Tindakan yang perlu persetujuan Founder") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton({ vm.setStatus(id, "NEEDS_APPROVAL", action) }, enabled = action.length >= 5) { Text("Minta persetujuan") }
                OutlinedButton({ vm.setStatus(id, "RESOLVED") }) { Text("Tandai RESOLVED") }
            }
            if (status == "NEEDS_APPROVAL") Text("Menunggu keputusan Founder.", color = Amber)
            if (status == "IN_PROGRESS") Button({ vm.setStatus(id, "RESOLVED") }) { Text("Tandai RESOLVED") }
            if (status == "RESOLVED" && vm.isFounder) Button({ vm.setStatus(id, "CLOSED") }) { Text("Tutup (CLOSED)") }
            OutlinedTextField(evName, { evName = it }, label = { Text("Nama berkas bukti") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(evBody, { evBody = it }, label = { Text("Isi log/bukti (teks)") }, modifier = Modifier.fillMaxWidth())
            OutlinedButton({ vm.addEvidence(id, evName, evBody); evBody = "" }, enabled = evName.isNotBlank() && evBody.isNotBlank()) { Text("Tambah bukti (SHA-256 otomatis)") }
        }
        Panel { Text("Bukti", fontWeight = FontWeight.Bold); for (e in d.getJSONArray("evidence").objs()) Text("${e.getString("filename")}  ${e.getString("sha256").take(16)}...", style = MaterialTheme.typography.labelSmall) }
        Panel { Text("Kronologi", fontWeight = FontWeight.Bold); for (t in d.getJSONArray("timeline").objs()) Text("${t.getString("at").take(19)} [${t.getString("actor")}] ${t.getString("entry")}", style = MaterialTheme.typography.labelSmall) }
        OutlinedButton({ vm.loadReport(id) }) { Text("Buat laporan") }
        vm.report?.let { Panel { Text(it, style = MaterialTheme.typography.bodySmall) } }
    }
}

@Composable
fun ApprovalScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadApprovals() }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("PERSETUJUAN TINDAKAN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
        items(vm.approvals) { a ->
            Panel {
                Text("#${a.getInt("id")} Insiden #${a.getInt("incident_id")}: ${a.getString("incident_title")}", fontWeight = FontWeight.SemiBold)
                Text(a.getString("requested_action"))
                val dec = a.str("decision", "")
                if (a.isNull("decision")) {
                    if (vm.isFounder) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ vm.decide(a.getInt("id"), "APPROVED") }) { Text("SETUJUI") }
                        OutlinedButton({ vm.decide(a.getInt("id"), "REJECTED") }) { Text("TOLAK") }
                    } else Chip("MENUNGGU FOUNDER", Amber)
                } else Chip(dec, if (dec == "APPROVED") Green else Red)
            }
        }
    }
}
