package id.topimerah.app.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.ui.graphics.ColorFilter
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*

@Composable
fun LoginScreen(vm: AppViewModel) {
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var server by remember { mutableStateOf(vm.session.baseUrl) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(Icons.Filled.Shield, null, Modifier.size(72.dp), colorFilter = ColorFilter.tint(Red))
        Text("CYBER DEFENSE INDONESIA", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text("AI CYBER DEFENSE FORCE", color = Silver, style = MaterialTheme.typography.labelLarge)
        Text("DEFEND THE DIGITAL NATION.", color = Red, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(server, { server = it }, label = { Text("Alamat server") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pw, { pw = it }, label = { Text("Kata sandi") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(12.dp))
        Button({ vm.session.baseUrl = server; vm.login(email.trim(), pw) }, enabled = !vm.busy && email.isNotBlank() && pw.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text(if (vm.busy) "Memproses..." else "MASUK")
        }
        Spacer(Modifier.height(16.dp))
        Text("TOPI MERAH adalah organisasi independen berbasis komunitas dan teknologi, bukan lembaga resmi pemerintah, TNI, Polri, atau BSSN.",
            color = Silver, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
    }
}
