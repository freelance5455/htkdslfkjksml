package id.topimerah.app.ui.settings

import id.topimerah.app.data.api.str
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*

@Composable
fun SettingsScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadAgents() }
    var server by remember { mutableStateOf(vm.session.baseUrl) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("PENGATURAN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        vm.info?.let { Text(it, color = Green) }
        Panel {
            Text("Akun: ${vm.session.name} (${vm.role})")
            OutlinedTextField(server, { server = it }, label = { Text("Alamat server backend") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedButton({ vm.session.baseUrl = server }) { Text("Simpan alamat") }
            Button({ vm.logout() }) { Text("KELUAR") }
        }
        if (vm.isFounder) {
            Panel {
                Text("Mesin AI (hanya Founder)", fontWeight = FontWeight.Bold)
                Text("Kunci API dikelola di server (.env), bukan di aplikasi.", style = MaterialTheme.typography.labelSmall, color = Silver)
                OutlinedButton({ vm.checkEngines() }, enabled = !vm.busy) { Text("Uji koneksi Gemini & OpenAI") }
                for (a in vm.agents) Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("%02d %s".format(a.getInt("id"), a.getString("name")), Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                    val next = if (a.getString("engine") == "GEMINI") "OPENAI" else "GEMINI"
                    OutlinedButton({ vm.setEngine(a.getInt("id"), next) }) { Text(a.getString("engine")) }
                }
            }
        }
        Text("TOPI MERAH bukan lembaga resmi pemerintah, TNI, Polri, atau BSSN.", style = MaterialTheme.typography.labelSmall, color = Silver)
    }
}

@Composable
fun MissionLogScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadLogs() }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            Text("MISSION LOG (AUDIT)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(if (vm.isFounder) "Seluruh aktivitas." else "Aktivitas Anda.", color = Silver, style = MaterialTheme.typography.labelSmall)
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            vm.info?.let { Text(it, color = Green) }
            if (vm.isFounder) OutlinedButton({ vm.verifyAudit() }) { Text("Verifikasi integritas rantai hash") }
        }
        items(vm.logs) { l -> Text("${l.getString("at").take(19)}  ${l.getString("action")}  ${l.str("target", "")}", style = MaterialTheme.typography.labelSmall) }
    }
}
