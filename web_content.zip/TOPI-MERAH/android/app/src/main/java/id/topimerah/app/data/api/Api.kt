package id.topimerah.app.data.api

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val code: String, val status: Int, val body: JSONObject = JSONObject()) : Exception(code)

fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

/** Token disimpan terenkripsi (Android Keystore). Tidak ada API key AI di aplikasi ini. */
class Session(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "cdi_session",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    var baseUrl: String
        get() = sp.getString("base", "http://10.0.2.2:8080") ?: "http://10.0.2.2:8080"
        set(v) { sp.edit().putString("base", v.trim().trimEnd('/')).apply() }
    var access: String?
        get() = sp.getString("a", null)
        set(v) { sp.edit().putString("a", v).apply() }
    var refresh: String?
        get() = sp.getString("r", null)
        set(v) { sp.edit().putString("r", v).apply() }
    var role: String
        get() = sp.getString("role", "VIEWER") ?: "VIEWER"
        set(v) { sp.edit().putString("role", v).apply() }
    var name: String
        get() = sp.getString("name", "") ?: ""
        set(v) { sp.edit().putString("name", v).apply() }
    fun clear() { sp.edit().remove("a").remove("r").remove("role").remove("name").apply() }
}

class ApiClient(private val s: Session) {
    fun call(method: String, path: String, body: JSONObject? = null, auth: Boolean = true): JSONObject {
        try {
            return raw(method, path, body, auth)
        } catch (e: ApiException) {
            if (e.status == 401 && auth && s.refresh != null && refreshTokens()) return raw(method, path, body, auth)
            throw e
        }
    }

    private fun refreshTokens(): Boolean = try {
        val j = raw("POST", "/api/auth/refresh", JSONObject().put("refresh_token", s.refresh), false)
        s.access = j.getString("access_token"); s.refresh = j.getString("refresh_token"); true
    } catch (e: Exception) { false }

    private fun raw(method: String, path: String, body: JSONObject?, auth: Boolean): JSONObject {
        val c = URL(s.baseUrl + path).openConnection() as HttpURLConnection
        // HttpURLConnection Android tidak mendukung PATCH -> pakai override yang didukung backend TOPI MERAH.
        c.requestMethod = if (method == "PATCH") "POST" else method
        if (method == "PATCH") c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        c.connectTimeout = 15000; c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json")
        if (auth) s.access?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toString().toByteArray()) } }
        val code = try { c.responseCode } catch (e: IOException) { throw ApiException("NETWORK_ERROR", 0) }
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
        val j = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
        if (code !in 200..299) throw ApiException(j.optString("error", "HTTP_$code"), code, j)
        return j
    }
}

/** org.json.optString mengembalikan "null" untuk JSON null; helper ini mengembalikan default. */
fun JSONObject.str(key: String, default: String = ""): String = if (isNull(key)) default else optString(key, default)
