package id.topimerah.app.ui.radar

import id.topimerah.app.data.api.str
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*

@Composable
fun RadarScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadRadar() }
    var selected by remember { mutableStateOf<Int?>(null) }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("GLOBAL CYBER DEFENSE RADAR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Peta grid lintang-bujur sederhana (belum memuat geometri negara). Marker = titik pusat negara, BUKAN lokasi pelaku/korban.", style = MaterialTheme.typography.labelSmall, color = Silver)
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            vm.info?.let { Text(it, color = Green, style = MaterialTheme.typography.labelSmall) }
            Canvas(Modifier.fillMaxWidth().aspectRatio(2f).padding(vertical = 8.dp)) {
                drawRect(Navy)
                for (lon in -180..180 step 30) { val x = (lon + 180f) / 360f * size.width; drawLine(NavyLight, Offset(x, 0f), Offset(x, size.height)) }
                for (lat in -90..90 step 30) { val y = (90f - lat) / 180f * size.height; drawLine(NavyLight, Offset(0f, y), Offset(size.width, y)) }
                for (e in vm.events) if (!e.isNull("lat")) {
                    val x = (e.getDouble("lon").toFloat() + 180f) / 360f * size.width
                    val y = (90f - e.getDouble("lat").toFloat()) / 180f * size.height
                    drawCircle(riskColor(e.getString("risk")), 7f, Offset(x, y))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.canWrite) Button({ vm.ingestKev() }, enabled = !vm.busy && vm.role != "ANALYST") { Text("Impor CISA KEV") }
                OutlinedButton({ vm.loadRadar() }) { Text("Muat ulang") }
            }
            Text("Tanpa sumber & waktu tidak ditampilkan. Data global (tanpa lokasi) hanya muncul di daftar.", style = MaterialTheme.typography.labelSmall, color = Silver)
        }
        items(vm.events) { e ->
            val id = e.getInt("id")
            Panel {
                Text(e.getString("title"), fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip(e.getString("category"), Silver); Chip(e.getString("risk"), riskColor(e.getString("risk")))
                    Chip(if (e.getBoolean("verified")) "TERVERIFIKASI" else "BELUM TERVERIFIKASI", if (e.getBoolean("verified")) Green else Amber)
                }
                Text("Sumber: ${e.getString("source_name")}", style = MaterialTheme.typography.labelSmall)
                Text(e.getString("source_url"), style = MaterialTheme.typography.labelSmall, color = Silver)
                Text("Waktu laporan: ${e.getString("reported_at")}  |  Negara: ${e.str("country_code", "global")}", style = MaterialTheme.typography.labelSmall)
                if (!e.isNull("handling_status")) Text("Status: ${e.getString("handling_status")}", style = MaterialTheme.typography.labelSmall)
                if (!e.isNull("ai_summary")) Text("Ringkasan AI (perlu verifikasi manusia):\n" + e.getString("ai_summary"), style = MaterialTheme.typography.bodySmall)
                if (vm.canWrite) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ vm.analyzeEvent(id) }, enabled = !vm.busy) { Text("Analisis AI (5 tahap)") }
                    if (vm.isFounder && !e.getBoolean("verified")) OutlinedButton({ vm.verify(id) }) { Text("Verifikasi") }
                }
            }
        }
    }
}
