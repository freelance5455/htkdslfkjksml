package id.topimerah.app.data.repo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.topimerah.app.data.api.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val session = Session(app)
    private val api = ApiClient(session)

    var loggedIn by mutableStateOf(session.access != null)
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var info by mutableStateOf<String?>(null)
    var dash by mutableStateOf<JSONObject?>(null)
    var agents by mutableStateOf<List<JSONObject>>(emptyList())
    var messages by mutableStateOf<List<JSONObject>>(emptyList())
    var tasks by mutableStateOf<List<JSONObject>>(emptyList())
    var events by mutableStateOf<List<JSONObject>>(emptyList())
    var incidents by mutableStateOf<List<JSONObject>>(emptyList())
    var incDetail by mutableStateOf<JSONObject?>(null)
    var report by mutableStateOf<String?>(null)
    var approvals by mutableStateOf<List<JSONObject>>(emptyList())
    var logs by mutableStateOf<List<JSONObject>>(emptyList())
    var analysis by mutableStateOf<String?>(null)

    val role get() = session.role
    val isFounder get() = session.role == "FOUNDER"
    val canWrite get() = session.role != "VIEWER"

    private fun friendly(e: ApiException) = when (e.code) {
        "NETWORK_ERROR" -> "Tidak dapat terhubung ke server. Periksa alamat server di Pengaturan."
        "AI_UNAVAILABLE" -> "Mesin AI tidak tersedia: " + (e.body.optJSONArray("errors")?.toString() ?: "")
        "AUTHORIZATION_REQUIRED" -> "AI Red Team wajib menyertakan bukti izin tertulis/kepemilikan target."
        "AUTHORIZATION_NOTE_REQUIRED" -> "Isi bukti izin pemilik sistem pada insiden sebelum minta persetujuan."
        "FORBIDDEN" -> "Peran Anda tidak memiliki hak untuk tindakan ini."
        "INVALID_CREDENTIALS" -> "Email atau kata sandi salah."
        "TOO_MANY_ATTEMPTS" -> "Terlalu banyak percobaan. Coba lagi nanti."
        else -> e.code
    }

    private fun <T> io(call: () -> T, done: (T) -> Unit = {}) {
        viewModelScope.launch {
            busy = true; error = null
            try { done(withContext(Dispatchers.IO) { call() }) }
            catch (e: ApiException) {
                error = friendly(e)
                if (e.status == 401 && e.code != "INVALID_CREDENTIALS") { session.clear(); loggedIn = false }
            } catch (e: Exception) { error = e.message ?: "Kesalahan tak dikenal" }
            finally { busy = false }
        }
    }

    fun login(email: String, pw: String) = io({
        api.call("POST", "/api/auth/login", JSONObject().put("email", email).put("password", pw).put("device", "android"), false)
    }) { j ->
        session.access = j.getString("access_token"); session.refresh = j.getString("refresh_token")
        session.role = j.getJSONObject("user").getString("role"); session.name = j.getJSONObject("user").getString("display_name")
        loggedIn = true
    }

    fun logout() {
        io({ try { api.call("POST", "/api/auth/logout", JSONObject()) } catch (e: Exception) { } }) { session.clear(); loggedIn = false; dash = null }
    }

    fun loadDashboard() = io({ api.call("GET", "/api/dashboard") }) { dash = it }
    fun loadAgents() = io({ api.call("GET", "/api/agents").getJSONArray("agents").objs() }) { agents = it }
    fun loadWorkspace(id: Int) = io({
        Pair(api.call("GET", "/api/agents/$id/messages").getJSONArray("messages").objs(), api.call("GET", "/api/agents/$id/tasks").getJSONArray("tasks").objs())
    }) { messages = it.first; tasks = it.second }

    fun send(id: Int, text: String, asTask: Boolean, authorization: String?) {
        val body = JSONObject().put("message", text)
        if (!authorization.isNullOrBlank()) body.put("authorization", authorization)
        io({ api.call("POST", "/api/agents/$id/" + if (asTask) "tasks" else "chat", body) }) { loadWorkspace(id) }
    }
    fun forward(taskId: Int, agentId: Int) = io({ api.call("POST", "/api/tasks/$taskId/forward", JSONObject()) }) { info = "Tugas dikirim ke AI Commander."; loadWorkspace(agentId) }
    fun setEngine(id: Int, engine: String) = io({ api.call("PATCH", "/api/agents/$id", JSONObject().put("engine", engine)) }) { loadAgents() }
    fun checkEngines() = io({ api.call("POST", "/api/status/check", JSONObject()).getJSONArray("results").toString() }) { info = "Hasil uji koneksi: $it"; loadDashboard() }

    fun loadRadar() = io({ api.call("GET", "/api/radar").getJSONArray("events").objs() }) { events = it }
    fun ingestKev() = io({ api.call("POST", "/api/radar/ingest/kev", JSONObject()) }) { info = "KEV: ${it.optInt("added")} baru dari ${it.optInt("fetched")}"; loadRadar() }
    fun verify(id: Int) = io({ api.call("POST", "/api/radar/$id/verify", JSONObject()) }) { loadRadar() }
    fun analyzeEvent(id: Int) = io({ api.call("POST", "/api/radar/$id/analyze", JSONObject()) }) { analysis = it.getJSONObject("event").optString("ai_summary"); loadRadar() }

    fun loadIncidents() = io({ api.call("GET", "/api/incidents").getJSONArray("incidents").objs() }) { incidents = it }
    fun createIncident(title: String, system: String, cat: String, risk: String, authNote: String) = io({
        api.call("POST", "/api/incidents", JSONObject().put("title", title).put("affected_system", system).put("category", cat).put("risk", risk).put("authorization_note", authNote))
    }) { loadIncidents() }
    fun loadIncident(id: Int) = io({ api.call("GET", "/api/incidents/$id") }) { incDetail = it }
    fun addEvidence(id: Int, name: String, content: String) = io({ api.call("POST", "/api/incidents/$id/evidence", JSONObject().put("filename", name).put("content", content)) }) { loadIncident(id) }
    fun analyzeIncident(id: Int) = io({ api.call("POST", "/api/incidents/$id/analyze", JSONObject()) }) { loadIncident(id) }
    fun setStatus(id: Int, status: String, action: String? = null) {
        val b = JSONObject().put("status", status); if (action != null) b.put("requested_action", action)
        io({ api.call("POST", "/api/incidents/$id/status", b) }) { loadIncident(id); loadIncidents() }
    }
    fun loadReport(id: Int) = io({ api.call("GET", "/api/incidents/$id/report").getString("report_markdown") }) { report = it }
    fun loadApprovals() = io({ api.call("GET", "/api/approvals").getJSONArray("approvals").objs() }) { approvals = it }
    fun decide(id: Int, decision: String) = io({ api.call("POST", "/api/approvals/$id/decision", JSONObject().put("decision", decision)) }) { loadApprovals(); loadDashboard() }
    fun loadLogs() = io({ api.call("GET", "/api/audit?limit=200").getJSONArray("logs").objs() }) { logs = it }
    fun verifyAudit() = io({ api.call("GET", "/api/audit/verify") }) { info = if (it.optBoolean("valid")) "Rantai audit log VALID" else "Rantai audit log RUSAK di id ${it.optInt("broken_at")}" }
}
