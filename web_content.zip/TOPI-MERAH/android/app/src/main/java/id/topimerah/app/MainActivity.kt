package id.topimerah.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*
import id.topimerah.app.ui.auth.LoginScreen
import id.topimerah.app.ui.dashboard.DashboardScreen
import id.topimerah.app.ui.incident.*
import id.topimerah.app.ui.radar.RadarScreen
import id.topimerah.app.ui.settings.*
import id.topimerah.app.ui.workspace.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TopiMerahTheme { TopiMerahApp() } }
    }
}

@Composable
fun TopiMerahApp(vm: AppViewModel = viewModel()) {
    if (!vm.loggedIn) { Surface(color = Black) { LoginScreen(vm) }; return }
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(Triple("dash", "Komando", Icons.Filled.Shield), Triple("radar", "Radar", Icons.Filled.Public),
        Triple("ai", "AI", Icons.Filled.SmartToy), Triple("inc", "Insiden", Icons.Filled.Warning), Triple("settings", "Atur", Icons.Filled.Settings))
    Scaffold(containerColor = Black, bottomBar = {
        NavigationBar(containerColor = Navy) {
            for ((r, label, icon) in tabs) NavigationBarItem(selected = route?.startsWith(r) == true, onClick = {
                nav.navigate(r) { popUpTo("dash"); launchSingleTop = true }
            }, icon = { Icon(icon, label) }, label = { Text(label) })
        }
    }) { pad ->
        NavHost(nav, startDestination = "dash", modifier = Modifier.padding(pad)) {
            composable("dash") { DashboardScreen(vm) { nav.navigate(it) } }
            composable("radar") { RadarScreen(vm) }
            composable("ai") { AgentListScreen(vm) { nav.navigate("ws/$it") } }
            composable("ws/{id}", listOf(navArgument("id") { type = NavType.IntType })) { WorkspaceScreen(vm, it.arguments!!.getInt("id")) }
            composable("inc") { IncidentListScreen(vm) { nav.navigate("incd/$it") } }
            composable("incd/{id}", listOf(navArgument("id") { type = NavType.IntType })) { IncidentDetailScreen(vm, it.arguments!!.getInt("id")) }
            composable("approvals") { ApprovalScreen(vm) }
            composable("log") { MissionLogScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
        }
    }
}
