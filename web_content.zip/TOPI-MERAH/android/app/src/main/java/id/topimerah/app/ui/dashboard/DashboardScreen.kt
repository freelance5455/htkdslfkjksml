package id.topimerah.app.ui.dashboard

import id.topimerah.app.data.api.str
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.topimerah.app.data.api.objs
import id.topimerah.app.data.repo.AppViewModel
import id.topimerah.app.ui.*

@Composable
fun DashboardScreen(vm: AppViewModel, go: (String) -> Unit) {
    LaunchedEffect(Unit) { vm.loadDashboard() }
    val d = vm.dash
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PUSAT KOMANDO", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("DEFEND THE DIGITAL NATION.", color = Red, style = MaterialTheme.typography.labelMedium)
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (d == null) { if (vm.busy) CircularProgressIndicator(); return@Column }
        Panel {
            Text(if (vm.isFounder) "Founder & Commander" else "Operator", color = Silver, style = MaterialTheme.typography.labelMedium)
            Text(d.getJSONObject("you").getString("name"), fontWeight = FontWeight.Bold)
            Chip("PERAN: " + d.getJSONObject("you").getString("role"), Silver)
            Text(d.getJSONObject("organization").getString("disclaimer"), style = MaterialTheme.typography.labelSmall, color = Silver)
        }
        Panel {
            Text("AI Specialist: ${d.getJSONObject("agents").getInt("active")} aktif / ${d.getJSONObject("agents").getInt("total")}", fontWeight = FontWeight.SemiBold)
            for (e in d.getJSONArray("engines").objs()) {
                val last = e.getJSONObject("last_call")
                val (txt, col) = when {
                    !e.getBoolean("configured") -> "BELUM DIKONFIGURASI" to Amber
                    last.isNull("ok") -> "TERKONFIGURASI (belum diuji)" to Silver
                    last.getBoolean("ok") -> "TERHUBUNG (panggilan terakhir OK)" to Green
                    else -> "ERROR: " + last.str("error") to Red
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text(e.getString("engine")); Chip(txt, col) }
            }
        }
        Panel {
            val r = d.getJSONObject("radar")
            Text("Global Radar: ${r.getInt("total")} laporan, ${r.getInt("verified")} terverifikasi", fontWeight = FontWeight.SemiBold)
            val i = d.getJSONObject("incidents")
            Text("Insiden: " + listOf("NEW", "UNDER_ANALYSIS", "NEEDS_APPROVAL", "IN_PROGRESS", "RESOLVED", "CLOSED").joinToString("  ") { "$it=${i.optInt(it)}" }, style = MaterialTheme.typography.labelSmall)
            Text("Persetujuan menunggu: ${d.getInt("pending_approvals")}", color = if (d.getInt("pending_approvals") > 0) Amber else Silver)
        }
        for ((label, route) in listOf("Global Cyber Defense Radar" to "radar", "AI Workspaces (10 AI)" to "ai", "Incident Response Center" to "inc",
            "Persetujuan Tindakan" to "approvals", "Mission Log (Audit)" to "log", "Pengaturan" to "settings")) {
            Panel(Modifier.clickable { go(route) }) { Text(label, fontWeight = FontWeight.SemiBold) }
        }
    }
}
