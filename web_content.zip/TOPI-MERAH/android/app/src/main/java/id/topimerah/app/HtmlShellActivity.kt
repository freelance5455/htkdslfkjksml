package id.topimerah.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

/**
 * Halaman awal aplikasi: membungkus index.html (di assets) dalam WebView.
 * HTML dimuat lewat https://appassets.androidx.net/ (WebViewAssetLoader) agar punya asal https yang sah
 * (dibutuhkan untuk tile peta dan panggilan ke backend); tanpa akses file:// langsung.
 */
class HtmlShellActivity : ComponentActivity() {
    private val host = "appassets.androidx.net"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        val web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true      // dibutuhkan dashboard & Leaflet
            domStorageEnabled = true      // localStorage untuk catatan lokal
            allowFileAccess = false
            allowContentAccess = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == host) return false
                if (r.url.scheme == "https" || r.url.scheme == "http") startActivity(Intent(Intent.ACTION_VIEW, r.url))
                return true // tautan luar dibuka di browser, bukan di dalam WebView
            }
        }
        // Jembatan hanya untuk halaman milik sendiri (hanya memuat assets lokal).
        web.addJavascriptInterface(object {
            @JavascriptInterface fun openNative() { startActivity(Intent(this@HtmlShellActivity, MainActivity::class.java)) }
        }, "TopiMerahNative")
        setContentView(web)
        web.loadUrl("https://$host/assets/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
    }
}
