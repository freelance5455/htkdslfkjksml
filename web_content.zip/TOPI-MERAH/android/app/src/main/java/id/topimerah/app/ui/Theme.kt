package id.topimerah.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Black = Color(0xFF05080F)
val Navy = Color(0xFF0B1730)
val NavyLight = Color(0xFF14264A)
val Red = Color(0xFFE03131)
val Silver = Color(0xFFC0C7D1)
val White = Color(0xFFF5F7FA)
val Green = Color(0xFF2FB344)
val Amber = Color(0xFFF59F00)

fun riskColor(r: String) = when (r) { "CRITICAL" -> Red; "HIGH" -> Color(0xFFFF7A45); "MEDIUM" -> Amber; else -> Green }

@Composable
fun TopiMerahTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Red, onPrimary = White, secondary = Silver, background = Black, surface = Navy,
            onBackground = White, onSurface = White, surfaceVariant = NavyLight, onSurfaceVariant = Silver, error = Red),
        content = content
    )
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp), colors = CardDefaults.cardColors(containerColor = Navy),
        border = BorderStroke(1.dp, NavyLight)) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content) }
}

@Composable
fun Chip(text: String, color: Color) {
    Surface(color = color.copy(alpha = 0.18f), shape = RoundedCornerShape(50), border = BorderStroke(1.dp, color)) {
        Text(text, Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = color, style = MaterialTheme.typography.labelSmall)
    }
}
