# Membuka index.html di Android
1. Ekstrak ZIP dengan pengelola berkas (mis. Files by Google → ketuk ZIP → Ekstrak).
2. Buka folder `TOPI-MERAH/`. Pastikan `index.html` **dan** folder `assets/logo/` tetap berdampingan (jangan dipisah, kalau tidak logo tidak muncul).
3. Buka `index.html` dengan aplikasi penyunting HTML (untuk mengedit) atau Chrome (untuk melihat: Buka dengan → Chrome).
4. **Peta butuh internet** (pustaka Leaflet dari cdnjs + tile OpenStreetMap). Tanpa internet, peta menampilkan pesan, bukan gambar pengganti.
5. Catatan: beberapa penyunting/preview HTML memblokir skrip eksternal atau `localStorage`; jika peta kosong, buka di Chrome.
6. Setelah mengedit `index.html` dan ingin dibawa ke APK: jalankan `tools/sync-html.sh` (di Termux) atau salin manual `index.html` ke `android/app/src/main/assets/index.html`.

Tombol "← Kembali ke dashboard" ada di tiap ruang kerja AI. Data bawaan berlabel DEMO / SIMULASI.
