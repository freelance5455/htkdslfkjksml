# TOPI MERAH — AI CYBER DEFENSE FORCE
**DEFEND THE DIGITAL NATION.**
TOPI MERAH adalah organisasi independen berbasis komunitas dan teknologi, bukan lembaga resmi pemerintah, TNI, Polri, atau BSSN.

## Komponen
1. Android App (Kotlin, Jetpack Compose native) - UI saja, tanpa API key.
2. Backend API (Node.js, HTTPS, REST + JWT).
3. AI Orchestration - adapter Gemini & OpenAI, router per agen, fallback, merge oleh AI Commander.
4. PostgreSQL - skema di backend/db/schema.sql.
5. Threat Intelligence Service - ingest feed publik, simpan sumber + waktu.
6. Global Radar Service - normalisasi insiden, verified/unverified, geokode negara.
7. Founder/Admin Controls - RBAC, approval queue, audit log.

## Alur Keamanan
Android --HTTPS+JWT--> Backend --(API key di env server)--> Gemini / OpenAI
- API key hanya di environment backend, tidak pernah di APK.
- Tindakan berdampak pada sistem nyata => NEEDS_APPROVAL => hanya Founder/pemilik sistem berwenang menyetujui.
- Semua aksi ditulis ke audit_logs.
- Agen tidak boleh mengklaim pemindaian/tindakan yang tidak dijalankan tool nyata.

## Radar Pipeline
Sumber publik/laporan user -> Global Radar Analyst -> Cyber Analyst -> Intelligence -> Blue Team -> Commander -> Founder.
Aturan: tanpa tuduhan tanpa bukti; geolokasi IP != lokasi pelaku; tampilkan sumber + waktu; verified vs unverified.

## Fallback AI
Engine utama gagal -> engine kedua (jika diizinkan) -> jika keduanya gagal, tampilkan status error, tanpa jawaban palsu.

## Tahap
1 Struktur (SELESAI) | 2 Dashboard | 3 10 AI + workspace | 4 Backend + Gemini/OpenAI | 5 Radar | 6 Incident + audit | 7 Auth | 8 Build APK + uji

## Pembaruan v0.2
Backend memakai modul bawaan Node (http, crypto, node:sqlite) agar bisa diuji tanpa npm. Skema PostgreSQL tetap dipertahankan sebagai target migrasi.
Android memakai Compose native + HttpURLConnection + org.json; token di EncryptedSharedPreferences.
