# Status fitur (jujur)

## Berfungsi dan TERUJI otomatis (backend)
Login/refresh (rotasi)/logout (pencabutan sesi); RBAC 4 peran; manajemen pengguna Founder (tidak bisa menghapus Founder terakhir);
pembatas login; hash scrypt; JWT HS256; validasi input; batas payload; query terparameter.
10 AI specialist, tiap AI punya riwayat percakapan & tugas sendiri per pengguna; pemilihan mesin per AI (Founder);
Gemini & OpenAI lewat backend (kunci tak pernah keluar server); fallback yang bisa dimatikan; error AI jujur (502);
AI Commander menggabungkan dua mesin; kirim tugas ke Commander; AI Red Team wajib menyertakan bukti izin;
pipeline Radar 5 agen; impor CISA KEV (dedupe, sumber+waktu, verified/unverified); laporan radar pengguna (default belum terverifikasi);
insiden (NEW..CLOSED) dengan transisi tervalidasi, bukti ber-SHA-256, kronologi, laporan akhir markdown, analisis AI;
IN_PROGRESS hanya lewat persetujuan Founder; audit log rantai-hash dengan verifikasi.
(Uji AI memakai server tiruan; lihat TEST_REPORT.md.)

## Ditulis tetapi BELUM dikompilasi/diuji (Android)
Login, Dashboard, Radar (peta grid + daftar), 10 workspace + chat + tugas + kirim ke Commander, Insiden + bukti + persetujuan,
Mission Log, Pengaturan (alamat server, mesin per AI, uji koneksi).

## Belum ada / keterbatasan
- APK: belum pernah dibuat. Lihat docs/BUILD_APK_DARI_HP.md.
- Database: berjalan di SQLite bawaan Node. `backend/db/schema.sql` (PostgreSQL) disimpan sebagai target, tetapi driver/adapter PostgreSQL belum ditulis.
- Peta native Compose (lama) masih berupa grid sederhana. Peta geografis sungguhan ada di `index.html` (Leaflet + OSM). Marker radar backend berada di titik pusat negara.
- Sumber radar nyata baru satu (CISA KEV, tanpa lokasi). Belum ada feed berita/CERT multi-negara.
- Gemini/OpenAI belum diuji terhadap API sungguhan (tanpa kunci/jaringan); format permintaan mengikuti dokumentasi REST publik dan harus diverifikasi dengan kunci Anda.
- Belum ada: unggah berkas biner/pemilih berkas di Android (API menerima lampiran teks; bukti insiden lewat tempel teks), notifikasi push, 2FA, TLS bawaan, rate limit global, antarmuka admin pengguna di Android (API ada).
- Tidak ada alat pemindaian nyata: AI hanya memberi analisis; tidak ada aksi ke sistem nyata yang dieksekusi otomatis.
