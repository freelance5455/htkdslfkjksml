# Laporan upgrade CDI v0.2 → TOPI MERAH v0.3

## Hasil pemeriksaan source v0.2
Struktur: `backend/` (Node, tanpa dependensi npm), `android/` (Compose, 10 berkas Kotlin), `docs/`. Baseline: backend 17/17 tes lulus. Temuan: tidak ada `gradlew`/wrapper jar; Android belum pernah dikompilasi; tidak ada HTML; backend tanpa CORS (HTML/WebView tidak bisa memanggilnya); peta Android hanya grid; AI Red Team ada di backend (dengan syarat bukti izin).
Catatan lampiran: gambar logo asli (JPG 2048×1650) dipakai sebagai sumber logo; hanya di-crop persegi tengah dan diubah ukuran, karakter tidak diubah.

## Berhasil diperbarui (dan cara diuji)
- **Branding** CDI → TOPI MERAH di launcher (`strings.xml`), judul HTML, header, dokumen, teks backend, paket `id.topimerah.app`, tema, nama proyek. Env lama `CDI_FOUNDER_*` tetap diterima. *Teruji:* pencarian teks; backend tes.
- **Logo** dipasang: `assets/logo/*`, ikon launcher Android (semua density) diregenerasi dari gambar asli. *Teruji:* logo termuat di HTML (headless Chromium).
- **`index.html`** satu file: tema hitam-merah, dashboard komando, status sistem, radar SVG, ringkasan, insiden terbaru, panel AI, navigasi, responsif HP. *Teruji:* Chromium headless 390×800 dan 1280×900, tanpa galat JS.
- **Peta geografis** Leaflet + OpenStreetMap (plus CARTO gelap & Esri satelit), zoom/geser, penanda observasi & insiden dari koordinat, popup detail, atribusi. *Hanya kode; tile BELUM teruji* (tanpa internet di lingkungan saya). Tanpa internet halaman menampilkan pesan, bukan peta palsu.
- **Radar & observasi:** filter status & risiko & sumber, detail (waktu, status, prioritas, mitigasi), ubah status & catatan, catat insiden manual (LOKAL). *Teruji* di Chromium.
- **Data nyata (v0.3.1):** default aplikasi menampilkan data NYATA saja; DEMO disembunyikan (bisa dinyalakan di Atur). Tombol "Muat data ancaman nyata" mengambil langsung dari browser: **CISA KEV** (kerentanan yang sudah dieksploitasi; tanpa lokasi, jadi tidak muncul di peta) dan **abuse.ch Feodo Tracker** (daftar server C2 botnet beserta negara; ditandai di pusat negara, bukan lokasi pelaku). Tiap laporan memuat sumber, tautan, dan waktu. Data backend berlabel BACKEND. *Teruji:* parsing dan tampilan dengan respons TIRUAN, dan jalur gagal. **Belum teruji ke server asli:** jika browser memblokir (CORS) atau jaringan gagal, aplikasi menampilkan pesan gagal apa adanya dan menyarankan jalur backend.
- **Batas data nyata:** ini daftar indikator/kerentanan publik, bukan pemantauan serangan langsung terhadap Anda. Serangan real-time ke jaringan Anda hanya bisa terlihat jika Anda menyambungkan log/sensor milik sendiri (belum ada di proyek ini).
- **10 ruang kerja AI** (nama/peran, percakapan, riwayat, input, output, tombol kembali). Tanpa backend: hanya catatan lokal dan panduan statis berlabel "BUKAN hasil AI". Tidak mengaku terhubung Gemini/OpenAI. *Teruji* alur lokal.
- **Backend:** CORS dengan allowlist (`CORS_ORIGINS`), alias env baru. *Teruji:* `npm test` 18/18 (termasuk tes CORS baru).
- **Android:** `HtmlShellActivity` (WebView + WebViewAssetLoader) menjadi halaman awal; konsol Compose lama dipertahankan, dibuka dari Atur. Workflow GitHub Actions untuk build APK. **Belum dikompilasi.**

## Belum selesai / belum teruji
- **APK belum dibangun.** Kode Kotlin baru dan lama belum pernah dikompilasi; galat kecil mungkin muncul.
- Tile peta, Leaflet CDN, perilaku OSM terhadap WebView (kebijakan tile OSM bisa menolak penggunaan berat; lapisan lain tersedia, produksi sebaiknya memakai penyedia tile sendiri) — belum diuji.
- Login HTML → backend, chat AI lewat HTML, muat radar backend: kode ditulis, **belum diuji ke backend nyata** dari HTML (backend sendiri teruji lewat tes otomatis; Gemini/OpenAI/CISA hanya dengan server tiruan).
- **AI Malware Analyst** belum punya agen backend (tidak dipetakan; backend memakai set 10 agen lama, mis. Red Team/Report Officer). Pemetaan 10 AI baru ke agen lama bersifat perkiraan (lihat `AIS` di `index.html`).
- Daftar insiden di HTML belum membaca `/api/incidents` backend (hanya `/api/radar`). Persetujuan, bukti, laporan akhir tetap di aplikasi native/API.
- Leaflet dimuat dari CDN tanpa SRI. Token login hanya di memori; tidak ada 2FA, TLS bawaan, atau PostgreSQL adapter (seperti v0.2).
- Tidak ada fitur menyerang pihak lain; AI hanya memberi analisis.
