# Laporan pengujian

Lingkungan: Node v22.23.5, Java ada; TIDAK ada PostgreSQL, Gradle, Kotlin compiler, Android SDK; jaringan keluar nonaktif.

## Backend: `npm test` → 17 lulus, 0 gagal
Mencakup: auth 401/403, pembuatan pengguna & validasi, 10 agen, chat Gemini/OpenAI (riwayat terpisah), kunci tidak bocor di respons,
fallback & pelarangan fallback, izin AI Red Team, impor KEV + dedupe + verifikasi, pipeline radar, merge Commander (1 mesin gagal),
alur insiden+persetujuan+penutupan+laporan, izin wajib sebelum persetujuan, JSON rusak/SQLi di filter/payload besar, audit log + deteksi manipulasi,
rotasi refresh token/logout/nonaktifkan pengguna/Founder terakhir, throttling login.
Smoke test server sungguhan tanpa kunci AI: /health OK; /api/status configured=false; chat → 502 AI_UNAVAILABLE (NOT_CONFIGURED_KEY); PATCH via override OK.

## Batasan uji (penting)
- Gemini/OpenAI/CISA diuji dengan server TIRUAN lokal. Belum diuji ke layanan sungguhan.
- Tidak diuji: beban, konkurensi tinggi, PostgreSQL.

## Android: TIDAK diuji, APK TIDAK dibuat
Kode ditulis tanpa kompilasi; kemungkinan ada galat kompilasi kecil (impor, versi dependensi) saat sync pertama.
