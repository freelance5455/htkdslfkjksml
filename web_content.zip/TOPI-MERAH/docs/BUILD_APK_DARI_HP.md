# Membuat APK dari HP — kenyataan dan pilihan
**Jujur:** Source Android (Kotlin + Compose + Gradle) normalnya dibangun dengan Android Studio di komputer. Proyek ini belum pernah dikompilasi, dan berkas `gradlew` / `gradle-wrapper.jar` tidak ada di source asli (build memakai Gradle terpasang). APK belum ada.

## Pilihan realistis tanpa komputer
**A. GitHub Actions (disarankan, dari browser HP)**
1. Buat akun GitHub, buat repositori **privat** baru.
2. Unggah isi folder `TOPI-MERAH/` (termasuk folder tersembunyi `.github/`). Unggah web GitHub di HP sulit mempertahankan folder; cara lebih mudah: buka repositori di **github.dev** atau **Codespaces** (editor di browser) lalu unggah ZIP dan ekstrak di terminal Codespaces (`unzip`), `git add -A && git commit && git push`.
3. Tab **Actions → "Build APK debug" → Run workflow**.
4. Setelah hijau, unduh artifact `TOPI-MERAH-debug-apk` (ZIP berisi `app-debug.apk`), ekstrak, pasang (izinkan "pasang dari sumber tidak dikenal").
5. Kemungkinan gagal di build pertama (kode Kotlin belum pernah dikompilasi): baca log, perbaiki galat impor/versi, ulangi. Jangan menganggap sukses sebelum APK terpasang dan terbuka.

**B. Termux + Gradle di HP** — bisa tetapi berat dan rapuh (butuh JDK 17, Android SDK `build-tools`, dan `aapt2` yang cocok arsitektur ARM). Tidak disarankan.

**C. Layanan "HTML ke APK" daring** untuk membungkus `index.html` saja. Hasilnya tidak memakai source Android proyek ini, dan Anda mengunggah kode ke pihak ketiga. Pakai hanya untuk percobaan, tanpa rahasia di dalamnya.

APK debug cocok untuk uji pribadi. Rilis ke publik butuh keystore penandatanganan (jangan commit keystore ke repositori).
## Backend
Jalankan `backend/` di server Anda (Node ≥ 22.5), isi `.env` dari `.env.example` (kunci AI hanya di sana), pasang HTTPS, set `CORS_ORIGINS=https://appassets.androidx.net`. Lalu isi alamat di **Atur** pada aplikasi.
