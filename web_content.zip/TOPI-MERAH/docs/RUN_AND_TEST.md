# Menjalankan dan menguji

## Backend (Node.js >= 22.5, tanpa `npm install`)
```bash
cd backend
cp .env.example .env     # isi JWT_SECRET (>=32 karakter), TOPI_MERAH_FOUNDER_EMAIL, TOPI_MERAH_FOUNDER_PASSWORD (>=12)
# Isi kunci AI di .env SECARA OPSIONAL: GEMINI_API_KEY + GEMINI_MODEL, OPENAI_API_KEY + OPENAI_MODEL
#   (nama model wajib diisi sendiri; periksa nama model terkini di dokumentasi penyedia)
npm start                # http://0.0.0.0:8080
npm test                 # 17 uji integrasi (memakai server upstream TIRUAN, tidak butuh kunci/internet)
```
Akun Founder dibuat otomatis saat database kosong dari variabel `TOPI_MERAH_FOUNDER_*` (nama lama `CDI_FOUNDER_*` masih diterima). Tidak ada kata sandi bawaan.
Pengguna lain dibuat Founder lewat `POST /api/users` (peran: FOUNDER, AI_OPERATOR, ANALYST, VIEWER).

Contoh:
```bash
curl -s -X POST localhost:8080/api/auth/login -H 'Content-Type: application/json' -d '{"email":"...","password":"..."}'
curl -s localhost:8080/api/status -H "Authorization: Bearer <access_token>"
```
Produksi: jalankan di belakang reverse proxy HTTPS (nginx/Caddy). Backend sendiri melayani HTTP.

## Data radar publik
Login sebagai Founder/AI_OPERATOR lalu `POST /api/radar/ingest/kev` (atau tombol "Impor CISA KEV" di aplikasi).
Server harus bisa mengakses internet ke cisa.gov. Entri KEV tidak memiliki lokasi, jadi tampil sebagai "global".

## Android
1. Buka folder `android/` di Android Studio (Koala/2024.1+, JDK 17). Gradle wrapper JAR tidak disertakan; Android Studio memakai Gradle-nya sendiri, atau jalankan `gradle wrapper --gradle-version 8.7`.
2. Sync, lalu Run di emulator. Alamat server bawaan `http://10.0.2.2:8080` (host mesin dari emulator). Ubah di layar login/Pengaturan.
3. Perangkat fisik/produksi: wajib HTTPS (cleartext hanya diizinkan untuk 10.0.2.2 dan localhost).
4. APK debug: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.
