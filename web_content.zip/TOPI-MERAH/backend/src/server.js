'use strict';
const http = require('http');
const { loadConfig } = require('./config');
const { openDb } = require('./db');
const { makeRouter } = require('./router');
const { makeAudit } = require('./services/audit/audit');
const { makeOrchestrator } = require('./ai/orchestrator');
const { authenticate, hashPassword } = require('./middleware/auth');
const { HttpError } = require('./errors');

function createApp(cfg, db) {
  const router = makeRouter(), audit = makeAudit(db), ai = makeOrchestrator(cfg);
  const r = (m, p, o, f) => router.add(m, p, o, f);
  for (const mod of ['auth', 'agents', 'radar', 'incidents']) require('./routes/' + mod)({ r, db, cfg, audit, ai });

  if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) {
    if (!cfg.founderEmail || cfg.founderPassword.length < 12) console.warn('[TOPI MERAH] Belum ada pengguna. Set TOPI_MERAH_FOUNDER_EMAIL dan TOPI_MERAH_FOUNDER_PASSWORD (min 12 karakter).');
    else {
      db.prepare("INSERT INTO users(email,password_hash,display_name,role,is_active,created_at) VALUES(?,?,?,'FOUNDER',1,?)").run(cfg.founderEmail.toLowerCase(), hashPassword(cfg.founderPassword), 'Founder & Commander', new Date().toISOString());
      audit.log({ action: 'FOUNDER_BOOTSTRAP', target: cfg.founderEmail.toLowerCase() });
    }
  }

  const server = http.createServer(async (req, res) => {
    const send = (code, obj) => {
      const b = JSON.stringify(obj);
      res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(b), 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'none'" });
      res.end(b);
    };
    try {
      // CORS dengan allowlist eksplisit (tanpa wildcard). Asal tidak terdaftar tidak mendapat header apa pun.
      const origin = req.headers.origin;
      if (origin && (cfg.corsOrigins || []).includes(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-HTTP-Method-Override');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
        res.setHeader('Access-Control-Max-Age', '600');
      }
      if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'GET' && url.pathname === '/health') return send(200, { status: 'ok', service: 'TOPI MERAH backend' });
      const method = req.method === 'POST' && req.headers['x-http-method-override'] === 'PATCH' ? 'PATCH' : req.method;
      const m = router.match(method, url.pathname);
      if (!m) throw new HttpError(404, 'NOT_FOUND');
      let user = null;
      if (m.route.opts.auth !== false) {
        user = authenticate(req, db, cfg);
        if (!user) throw new HttpError(401, 'UNAUTHENTICATED');
        if (m.route.opts.roles && !m.route.opts.roles.includes(user.role)) {
          audit.log({ user: user.id, action: 'ACCESS_DENIED', target: `${method} ${url.pathname}` });
          throw new HttpError(403, 'FORBIDDEN');
        }
      }
      let body = {};
      if (method === 'POST' || method === 'PATCH') {
        const chunks = []; let size = 0;
        for await (const c of req) { size += c.length; if (size > 1_000_000) throw new HttpError(413, 'PAYLOAD_TOO_LARGE'); chunks.push(c); }
        if (size) { try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new HttpError(400, 'INVALID_JSON'); } }
        if (body === null || typeof body !== 'object' || Array.isArray(body)) throw new HttpError(400, 'INVALID_JSON');
      }
      const out = await m.route.fn({ req, user, params: m.params, query: url.searchParams, body, ip: req.socket.remoteAddress });
      if (out && out.status && out.body) return send(out.status, out.body);
      send(200, out);
    } catch (e) {
      if (e instanceof HttpError) return send(e.status, { error: e.code, ...(e.extra || {}) });
      if (e && /UNIQUE constraint/.test(String(e.message))) return send(409, { error: 'ALREADY_EXISTS' });
      console.error('[TOPI MERAH] error:', e && e.message);
      send(500, { error: 'INTERNAL_ERROR' });
    }
  });
  return { server, audit, ai };
}

if (require.main === module) {
  const cfg = loadConfig();
  const { server } = createApp(cfg, openDb(cfg.dbPath));
  server.listen(cfg.port, cfg.host, () => console.log(`[TOPI MERAH] backend siap di http://${cfg.host}:${cfg.port}  (gunakan HTTPS reverse proxy untuk produksi)`));
}
module.exports = { createApp };
