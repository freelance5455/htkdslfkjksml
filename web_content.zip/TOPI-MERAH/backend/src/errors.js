'use strict';
class HttpError extends Error {
  constructor(status, code, extra) { super(code); this.status = status; this.code = code; this.extra = extra; }
}
const str = (v, name, min, max) => {
  if (typeof v !== 'string') throw new HttpError(400, 'INVALID_' + name.toUpperCase());
  const s = v.trim();
  if (s.length < min || s.length > max) throw new HttpError(400, 'INVALID_' + name.toUpperCase());
  return s;
};
const oneOf = (v, name, list) => {
  if (!list.includes(v)) throw new HttpError(400, 'INVALID_' + name.toUpperCase(), { allowed: list });
  return v;
};
module.exports = { HttpError, str, oneOf };
