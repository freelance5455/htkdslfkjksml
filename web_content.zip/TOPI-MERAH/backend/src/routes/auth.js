'use strict';
const crypto = require('crypto');
const { HttpError, str, oneOf } = require('../errors');
const { sha, hashPassword, checkPassword, signJwt, verifyJwt, throttle } = require('../middleware/auth');
const F = 'FOUNDER', ALL = ['FOUNDER', 'AI_OPERATOR', 'ANALYST', 'VIEWER'];
const ROLES = ALL;

module.exports = ({ r, db, cfg, audit }) => {
  const newSession = (user, device) => {
    const refresh = crypto.randomBytes(32).toString('base64url');
    const exp = new Date(Date.now() + cfg.refreshTtl * 1000).toISOString();
    const sid = Number(db.prepare('INSERT INTO sessions(user_id,refresh_hash,device,created_at,expires_at) VALUES(?,?,?,?,?)').run(user.id, sha(refresh), device || null, new Date().toISOString(), exp).lastInsertRowid);
    return { access_token: signJwt({ sub: user.id, sid, typ: 'access' }, cfg.jwtSecret, cfg.accessTtl), refresh_token: signJwt({ sub: user.id, sid, typ: 'refresh', n: refresh }, cfg.jwtSecret, cfg.refreshTtl), expires_in: cfg.accessTtl };
  };
  const pub = (u) => ({ id: u.id, email: u.email, display_name: u.display_name, role: u.role, is_active: !!u.is_active });

  r('POST', '/api/auth/login', { auth: false }, ({ body, ip }) => {
    const email = str(body.email, 'email', 3, 200).toLowerCase(), pw = str(body.password, 'password', 1, 200);
    const key = email + '|' + ip;
    throttle.check(key);
    const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if (!u || !u.is_active || !checkPassword(pw, u.password_hash)) {
      throttle.fail(key);
      audit.log({ action: 'AUTH_LOGIN_FAILED', target: email });
      throw new HttpError(401, 'INVALID_CREDENTIALS');
    }
    throttle.ok(key);
    audit.log({ user: u.id, action: 'AUTH_LOGIN', target: email });
    return { ...newSession(u, typeof body.device === 'string' ? body.device.slice(0, 80) : null), user: pub(u) };
  });

  r('POST', '/api/auth/refresh', { auth: false }, ({ body }) => {
    const p = verifyJwt(String(body.refresh_token || ''), cfg.jwtSecret);
    if (!p || p.typ !== 'refresh') throw new HttpError(401, 'INVALID_REFRESH');
    const s = db.prepare('SELECT * FROM sessions WHERE id=?').get(p.sid);
    if (!s || s.revoked_at || s.refresh_hash !== sha(p.n) || s.expires_at < new Date().toISOString()) throw new HttpError(401, 'INVALID_REFRESH');
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(p.sub);
    if (!u || !u.is_active) throw new HttpError(401, 'INVALID_REFRESH');
    db.prepare('UPDATE sessions SET revoked_at=? WHERE id=?').run(new Date().toISOString(), s.id); // rotasi token
    return newSession(u, s.device);
  });

  r('POST', '/api/auth/logout', { roles: ALL }, ({ user }) => {
    db.prepare('UPDATE sessions SET revoked_at=? WHERE id=?').run(new Date().toISOString(), user.sid);
    audit.log({ user: user.id, action: 'AUTH_LOGOUT' });
    return { ok: true };
  });
  r('GET', '/api/auth/me', { roles: ALL }, ({ user }) => ({ id: user.id, email: user.email, display_name: user.name, role: user.role }));

  r('POST', '/api/auth/password', { roles: ALL }, ({ user, body }) => {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
    if (!checkPassword(str(body.old_password, 'old_password', 1, 200), u.password_hash)) throw new HttpError(403, 'WRONG_PASSWORD');
    db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hashPassword(str(body.new_password, 'new_password', 12, 200)), user.id);
    db.prepare('UPDATE sessions SET revoked_at=? WHERE user_id=? AND id<>? AND revoked_at IS NULL').run(new Date().toISOString(), user.id, user.sid);
    audit.log({ user: user.id, action: 'AUTH_PASSWORD_CHANGED' });
    return { ok: true };
  });

  // --- Manajemen pengguna & hak akses (Founder) ---
  r('GET', '/api/users', { roles: [F] }, () => ({ users: db.prepare('SELECT id,email,display_name,role,is_active FROM users ORDER BY id').all() }));
  r('POST', '/api/users', { roles: [F] }, ({ user, body }) => {
    const email = str(body.email, 'email', 3, 200).toLowerCase();
    if (!/^[^@\s]+@[^@\s]+$/.test(email)) throw new HttpError(400, 'INVALID_EMAIL');
    const role = oneOf(body.role, 'role', ROLES);
    const id = db.prepare('INSERT INTO users(email,password_hash,display_name,role,is_active,created_at) VALUES(?,?,?,?,1,?)')
      .run(email, hashPassword(str(body.password, 'password', 12, 200)), str(body.display_name, 'display_name', 1, 100), role, new Date().toISOString());
    audit.log({ user: user.id, action: 'USER_CREATED', target: email, detail: { role } });
    return { status: 201, body: { id: Number(id.lastInsertRowid), email, role } };
  });
  r('PATCH', '/api/users/:id', { roles: [F] }, ({ user, params, body }) => {
    const t = db.prepare('SELECT * FROM users WHERE id=?').get(Number(params.id));
    if (!t) throw new HttpError(404, 'NOT_FOUND');
    const role = body.role === undefined ? t.role : oneOf(body.role, 'role', ROLES);
    const active = body.is_active === undefined ? t.is_active : (body.is_active ? 1 : 0);
    if (t.role === F && (role !== F || !active) && db.prepare("SELECT COUNT(*) c FROM users WHERE role='FOUNDER' AND is_active=1").get().c <= 1) throw new HttpError(409, 'LAST_FOUNDER');
    db.prepare('UPDATE users SET role=?, is_active=? WHERE id=?').run(role, active, t.id);
    if (!active || role !== t.role) db.prepare('UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(new Date().toISOString(), t.id);
    audit.log({ user: user.id, action: 'USER_UPDATED', target: t.email, detail: { role, active: !!active } });
    return { ok: true };
  });
};
