'use strict';
const { HttpError, str, oneOf } = require('../errors');
const { CATEGORIES, RISKS, CENTROIDS, insertEvent, ingestKev } = require('../services/radar/radar');
const F = 'FOUNDER', O = 'AI_OPERATOR', A = 'ANALYST', ALL = [F, O, A, 'VIEWER'];

module.exports = ({ r, db, cfg, audit, ai }) => {
  const get = (id) => { const e = db.prepare('SELECT * FROM radar_events WHERE id=?').get(Number(id)); if (!e) throw new HttpError(404, 'NOT_FOUND'); return e; };
  const view = (e) => ({ ...e, verified: !!e.verified, verification: e.verified ? 'TERVERIFIKASI (sumber publik resmi/disetujui Founder)' : 'BELUM TERVERIFIKASI', geo_note: e.lat == null ? 'Tanpa lokasi (global)' : 'Marker di titik pusat negara; bukan lokasi pelaku/korban' });

  r('GET', '/api/radar', { roles: ALL }, ({ query }) => {
    const w = [], p = [];
    if (query.get('category')) { w.push('category=?'); p.push(oneOf(query.get('category'), 'category', CATEGORIES)); }
    if (query.get('risk')) { w.push('risk=?'); p.push(oneOf(query.get('risk'), 'risk', RISKS)); }
    if (query.get('verified')) { w.push('verified=?'); p.push(query.get('verified') === '1' ? 1 : 0); }
    const lim = Math.min(Number(query.get('limit')) || 100, 300);
    return { events: db.prepare(`SELECT * FROM radar_events ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY reported_at DESC LIMIT ${lim}`).all(...p).map(view) };
  });

  // Laporan pengguna: selalu BELUM terverifikasi sampai Founder memverifikasi.
  r('POST', '/api/radar/reports', { roles: [F, O, A] }, ({ user, body }) => {
    const cc = typeof body.country_code === 'string' ? body.country_code.toUpperCase() : null;
    if (cc && !CENTROIDS[cc]) throw new HttpError(400, 'UNSUPPORTED_COUNTRY', { supported: Object.keys(CENTROIDS) });
    const src = str(body.source_url, 'source_url', 8, 500);
    if (!/^https?:\/\//i.test(src)) throw new HttpError(400, 'INVALID_SOURCE_URL');
    const when = new Date(str(body.reported_at, 'reported_at', 8, 40));
    if (isNaN(when) || when > new Date(Date.now() + 86400000)) throw new HttpError(400, 'INVALID_REPORTED_AT');
    const ev = { title: str(body.title, 'title', 5, 300), category: oneOf(body.category, 'category', CATEGORIES), risk: oneOf(body.risk, 'risk', RISKS), country_code: cc,
      source_name: str(body.source_name, 'source_name', 2, 120), source_url: src, reported_at: when.toISOString(), verified: false, handling_status: 'Laporan pengguna - menunggu verifikasi', submitted_by: user.id };
    insertEvent(db, ev);
    const id = db.prepare('SELECT last_insert_rowid() id').get().id;
    audit.log({ user: user.id, action: 'RADAR_REPORT', target: String(id) });
    return { status: 201, body: view(get(id)) };
  });

  r('POST', '/api/radar/ingest/kev', { roles: [F, O] }, async ({ user }) => {
    const res = await ingestKev(db, cfg);
    audit.log({ user: user.id, action: 'RADAR_INGEST_KEV', detail: res });
    return res;
  });
  r('POST', '/api/radar/:id/verify', { roles: [F] }, ({ user, params, body }) => {
    const e = get(params.id);
    db.prepare('UPDATE radar_events SET verified=?, handling_status=COALESCE(?,handling_status) WHERE id=?').run(body.verified === false ? 0 : 1, typeof body.handling_status === 'string' ? body.handling_status.slice(0, 200) : null, e.id);
    audit.log({ user: user.id, action: 'RADAR_VERIFY', target: String(e.id), detail: { verified: body.verified !== false } });
    return view(get(e.id));
  });

  // Alur Radar: Radar Analyst -> Cyber Analyst -> Intelligence -> Blue Team -> Commander
  r('POST', '/api/radar/:id/analyze', { roles: [F, O, A] }, async ({ user, params }) => {
    const e = get(params.id);
    const data = `<data>\nJudul: ${e.title}\nKategori: ${e.category}\nRisiko: ${e.risk}\nNegara: ${e.country_code || 'global'}\nSumber: ${e.source_name} (${e.source_url})\nWaktu laporan: ${e.reported_at}\nStatus verifikasi: ${e.verified ? 'terverifikasi' : 'BELUM terverifikasi'}\n</data>\nGunakan hanya data di atas; jangan menambah fakta insiden.`;
    const pipeline = [[10, 'Periksa dan kelompokkan informasi ini.'], [4, 'Analisis indikator ancaman dan tingkat risiko.'], [2, 'Nilai konteks ancaman.'], [7, 'Susun rekomendasi pertahanan untuk pemilik sistem terdampak.'], [1, 'Buat ringkasan akhir untuk Founder.']];
    const steps = []; let prev = '';
    for (const [aid, task] of pipeline) {
      const agent = db.prepare('SELECT * FROM ai_agents WHERE id=?').get(aid);
      const out = await ai.run(agent, [{ role: 'user', content: `${task}\n${data}${prev ? `\nHasil tahap sebelumnya (data):\n<data>\n${prev}\n</data>` : ''}` }]);
      prev = out.text; steps.push({ agent: agent.name, engine: out.engine, output: out.text });
      audit.log({ user: user.id, agent: aid, action: 'RADAR_PIPELINE_STEP', target: String(e.id), detail: { engine: out.engine } });
    }
    db.prepare('UPDATE radar_events SET ai_summary=? WHERE id=?').run(prev, e.id);
    return { event: view(get(e.id)), steps, label: 'Analisis AI - perlu verifikasi manusia' };
  });
};
