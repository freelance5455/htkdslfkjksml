'use strict';
const { HttpError, str, oneOf } = require('../errors');
const { sha } = require('../middleware/auth');
const { CATEGORIES, RISKS } = require('../services/radar/radar');
const F = 'FOUNDER', O = 'AI_OPERATOR', A = 'ANALYST', ALL = [F, O, A, 'VIEWER'], WRITE = [F, O, A];
const NEXT = { NEW: ['UNDER_ANALYSIS'], UNDER_ANALYSIS: ['NEEDS_APPROVAL', 'RESOLVED'], NEEDS_APPROVAL: [], IN_PROGRESS: ['RESOLVED'], RESOLVED: ['CLOSED', 'UNDER_ANALYSIS'], CLOSED: [] };

module.exports = ({ r, db, audit, ai }) => {
  const inc = (id) => { const i = db.prepare('SELECT * FROM incidents WHERE id=?').get(Number(id)); if (!i) throw new HttpError(404, 'NOT_FOUND'); return i; };
  const tl = (id, actor, entry) => db.prepare('INSERT INTO incident_timeline(incident_id,at,actor,entry) VALUES(?,?,?,?)').run(id, new Date().toISOString(), actor, entry);

  r('GET', '/api/incidents', { roles: ALL }, ({ query }) => {
    const s = query.get('status');
    return { incidents: s ? db.prepare('SELECT * FROM incidents WHERE status=? ORDER BY id DESC').all(oneOf(s, 'status', Object.keys(NEXT))) : db.prepare('SELECT * FROM incidents ORDER BY id DESC LIMIT 200').all() };
  });
  r('POST', '/api/incidents', { roles: WRITE }, ({ user, body }) => {
    const id = Number(db.prepare('INSERT INTO incidents(title,description,affected_system,category,risk,authorization_note,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)').run(
      str(body.title, 'title', 5, 200), typeof body.description === 'string' ? body.description.slice(0, 5000) : null, str(body.affected_system, 'affected_system', 2, 200),
      oneOf(body.category, 'category', CATEGORIES), oneOf(body.risk, 'risk', RISKS), typeof body.authorization_note === 'string' ? body.authorization_note.slice(0, 1000) : null, user.id, new Date().toISOString()).lastInsertRowid);
    tl(id, user.email, 'Insiden dibuat (status NEW)');
    audit.log({ user: user.id, action: 'INCIDENT_CREATED', target: String(id) });
    return { status: 201, body: inc(id) };
  });
  r('GET', '/api/incidents/:id', { roles: ALL }, ({ params }) => {
    const i = inc(params.id);
    return { incident: i, timeline: db.prepare('SELECT at,actor,entry FROM incident_timeline WHERE incident_id=? ORDER BY id').all(i.id),
      evidence: db.prepare('SELECT id,filename,sha256,uploaded_at FROM incident_evidence WHERE incident_id=?').all(i.id), approvals: db.prepare('SELECT * FROM approvals WHERE incident_id=? ORDER BY id').all(i.id) };
  });
  r('POST', '/api/incidents/:id/evidence', { roles: WRITE }, ({ user, params, body }) => {
    const i = inc(params.id);
    if (i.status === 'CLOSED') throw new HttpError(409, 'INCIDENT_CLOSED');
    const content = str(body.content, 'content', 1, 200000), fn = str(body.filename, 'filename', 1, 120);
    const h = sha(content);
    db.prepare('INSERT INTO incident_evidence(incident_id,filename,content,sha256,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?)').run(i.id, fn, content, h, user.id, new Date().toISOString());
    tl(i.id, user.email, `Bukti ditambahkan: ${fn} (SHA-256 ${h.slice(0, 16)}...)`);
    audit.log({ user: user.id, action: 'EVIDENCE_ADDED', target: String(i.id), detail: { filename: fn, sha256: h } });
    return { status: 201, body: { sha256: h } };
  });
  r('POST', '/api/incidents/:id/analyze', { roles: WRITE }, async ({ user, params }) => {
    const i = inc(params.id);
    const ev = db.prepare('SELECT filename,content FROM incident_evidence WHERE incident_id=?').all(i.id).map((e) => `# ${e.filename}\n${e.content.slice(0, 15000)}`).join('\n\n');
    const data = `<data>\nJudul: ${i.title}\nSistem: ${i.affected_system}\nKategori: ${i.category}\nRisiko awal: ${i.risk}\nDeskripsi: ${i.description || '-'}\nBukti:\n${ev || '(belum ada)'}\n</data>`;
    const steps = [];
    for (const [aid, task] of [[4, 'Analisis log/bukti, identifikasi pola dan tentukan tingkat risiko.'], [7, 'Susun rekomendasi mitigasi dan prosedur respons. Tandai langkah yang butuh izin pemilik sistem.']]) {
      const agent = db.prepare('SELECT * FROM ai_agents WHERE id=?').get(aid);
      const out = await ai.run(agent, [{ role: 'user', content: `${task}\n${data}` }]);
      steps.push({ agent: agent.name, engine: out.engine, output: out.text });
      tl(i.id, agent.name, `[Analisis AI via ${out.engine}] ${out.text.slice(0, 1500)}`);
      audit.log({ user: user.id, agent: aid, action: 'INCIDENT_AI_ANALYSIS', target: String(i.id), detail: { engine: out.engine } });
    }
    return { steps, label: 'Analisis AI - perlu verifikasi manusia' };
  });
  r('POST', '/api/incidents/:id/status', { roles: WRITE }, ({ user, params, body }) => {
    const i = inc(params.id), to = oneOf(body.status, 'status', Object.keys(NEXT));
    if (to === 'IN_PROGRESS') throw new HttpError(403, 'APPROVAL_REQUIRED', { hint: 'IN_PROGRESS hanya dicapai lewat persetujuan Founder.' });
    if (!NEXT[i.status].includes(to)) throw new HttpError(409, 'INVALID_TRANSITION', { from: i.status, allowed: NEXT[i.status] });
    if (to === 'CLOSED' && user.role !== F) throw new HttpError(403, 'FOUNDER_ONLY');
    let extra = {};
    if (to === 'NEEDS_APPROVAL') {
      if (!i.authorization_note || i.authorization_note.trim().length < 10) throw new HttpError(400, 'AUTHORIZATION_NOTE_REQUIRED', { hint: 'Isi bukti izin pemilik sistem pada insiden.' });
      const act = str(body.requested_action, 'requested_action', 5, 1000);
      extra = { approval_id: Number(db.prepare('INSERT INTO approvals(incident_id,requested_action,requested_by,requested_at) VALUES(?,?,?,?)').run(i.id, act, user.id, new Date().toISOString()).lastInsertRowid) };
    }
    db.prepare('UPDATE incidents SET status=?, closed_at=? WHERE id=?').run(to, to === 'CLOSED' ? new Date().toISOString() : null, i.id);
    tl(i.id, user.email, `Status ${i.status} -> ${to}`);
    audit.log({ user: user.id, action: 'INCIDENT_STATUS', target: String(i.id), detail: { from: i.status, to } });
    return { ...inc(i.id), ...extra };
  });
  r('GET', '/api/incidents/:id/report', { roles: ALL }, ({ params }) => {
    const i = inc(params.id);
    const t = db.prepare('SELECT at,actor,entry FROM incident_timeline WHERE incident_id=? ORDER BY id').all(i.id);
    const e = db.prepare('SELECT filename,sha256 FROM incident_evidence WHERE incident_id=?').all(i.id);
    const a = db.prepare('SELECT * FROM approvals WHERE incident_id=?').all(i.id);
    const md = [`# Laporan Insiden #${i.id}: ${i.title}`, `TOPI MERAH - DEFEND THE DIGITAL NATION.`, '', `- Status: ${i.status}`, `- Sistem terdampak: ${i.affected_system}`, `- Kategori/Risiko: ${i.category} / ${i.risk}`, `- Dibuat: ${i.created_at}`, `- Izin pemilik sistem: ${i.authorization_note || '(tidak ada)'}`, '', '## Bukti', ...(e.length ? e.map((x) => `- ${x.filename} - SHA-256 ${x.sha256}`) : ['- (tidak ada)']), '', '## Persetujuan', ...(a.length ? a.map((x) => `- #${x.id} "${x.requested_action}" -> ${x.decision || 'MENUNGGU'}${x.note ? ' (' + x.note + ')' : ''}`) : ['- (tidak ada)']), '', '## Kronologi', ...t.map((x) => `- ${x.at} [${x.actor}] ${x.entry}`)].join('\n');
    return { report_markdown: md };
  });

  // --- Persetujuan tindakan (hanya Founder yang memutuskan) ---
  r('GET', '/api/approvals', { roles: ALL }, ({ query }) => ({ approvals: db.prepare(`SELECT a.*, i.title incident_title FROM approvals a JOIN incidents i ON i.id=a.incident_id ${query.get('pending') === '1' ? 'WHERE a.decision IS NULL' : ''} ORDER BY a.id DESC LIMIT 100`).all() }));
  r('POST', '/api/approvals/:id/decision', { roles: [F] }, ({ user, params, body }) => {
    const ap = db.prepare('SELECT * FROM approvals WHERE id=?').get(Number(params.id));
    if (!ap) throw new HttpError(404, 'NOT_FOUND');
    if (ap.decision) throw new HttpError(409, 'ALREADY_DECIDED');
    const d = oneOf(body.decision, 'decision', ['APPROVED', 'REJECTED']);
    db.prepare('UPDATE approvals SET decision=?, decided_by=?, decided_at=?, note=? WHERE id=?').run(d, user.id, new Date().toISOString(), typeof body.note === 'string' ? body.note.slice(0, 500) : null, ap.id);
    const to = d === 'APPROVED' ? 'IN_PROGRESS' : 'UNDER_ANALYSIS';
    db.prepare('UPDATE incidents SET status=? WHERE id=? AND status=?').run(to, ap.incident_id, 'NEEDS_APPROVAL');
    tl(ap.incident_id, user.email, `Persetujuan #${ap.id} ${d}: ${ap.requested_action}`);
    audit.log({ user: user.id, action: 'APPROVAL_' + d, target: String(ap.id), detail: { incident: ap.incident_id } });
    return { ok: true, incident_status: to };
  });

  // --- Audit log ---
  r('GET', '/api/audit', { roles: ALL }, ({ user, query }) => {
    const lim = Math.min(Number(query.get('limit')) || 100, 500);
    const rows = user.role === F ? db.prepare('SELECT id,at,actor_user,actor_agent,action,target,detail FROM audit_logs ORDER BY id DESC LIMIT ?').all(lim)
      : db.prepare('SELECT id,at,actor_user,actor_agent,action,target,detail FROM audit_logs WHERE actor_user=? ORDER BY id DESC LIMIT ?').all(user.id, lim);
    return { logs: rows };
  });
  r('GET', '/api/audit/verify', { roles: [F] }, () => audit.verify());
};
