'use strict';
const routes = [];
const compile = (p) => new RegExp('^' + p.replace(/:([a-z]+)/g, '(?<$1>[^/]+)') + '/?$');
function makeRouter() {
  return {
    add(method, path, opts, fn) { routes.push({ method, re: compile(path), opts, fn }); },
    match(method, pathname) {
      for (const r of routes) { if (r.method !== method) continue; const m = r.re.exec(pathname); if (m) return { route: r, params: m.groups || {} }; }
      return null;
    },
  };
}
module.exports = { makeRouter };
