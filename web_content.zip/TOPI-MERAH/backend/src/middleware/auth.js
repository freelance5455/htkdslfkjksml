'use strict';
const crypto = require('crypto');
const { HttpError } = require('../errors');

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `scrypt$${salt}$${crypto.scryptSync(pw, salt, 64).toString('hex')}`;
}
function checkPassword(pw, stored) {
  const [alg, salt, hash] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const a = crypto.scryptSync(pw, salt, 64), b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function signJwt(payload, secret, ttl) {
  const now = Math.floor(Date.now() / 1000);
  const h = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const b = Buffer.from(JSON.stringify({ ...payload, iat: now, exp: now + ttl })).toString('base64url');
  return `${h}.${b}.${crypto.createHmac('sha256', secret).update(`${h}.${b}`).digest('base64url')}`;
}
function verifyJwt(token, secret) {
  const p = String(token).split('.');
  if (p.length !== 3) return null;
  const want = crypto.createHmac('sha256', secret).update(`${p[0]}.${p[1]}`).digest();
  const got = Buffer.from(p[2], 'base64url');
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  try {
    if (JSON.parse(Buffer.from(p[0], 'base64url')).alg !== 'HS256') return null;
    const pl = JSON.parse(Buffer.from(p[1], 'base64url'));
    return pl.exp > Date.now() / 1000 ? pl : null;
  } catch { return null; }
}

// Pembatas percobaan login: 5 gagal / 15 menit per email+ip
const fails = new Map();
const throttle = {
  check(key) {
    const f = fails.get(key);
    if (f && f.n >= 5 && Date.now() - f.t < 15 * 60 * 1000) throw new HttpError(429, 'TOO_MANY_ATTEMPTS');
  },
  fail(key) { const f = fails.get(key); fails.set(key, { n: (f && Date.now() - f.t < 15 * 60 * 1000 ? f.n : 0) + 1, t: Date.now() }); },
  ok(key) { fails.delete(key); },
};

function authenticate(req, db, cfg) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  if (!m) return null;
  const p = verifyJwt(m[1], cfg.jwtSecret);
  if (!p || p.typ !== 'access') return null;
  const s = db.prepare('SELECT revoked_at, expires_at FROM sessions WHERE id=?').get(p.sid);
  if (!s || s.revoked_at || s.expires_at < new Date().toISOString()) return null;
  const u = db.prepare('SELECT id,email,display_name,role,is_active FROM users WHERE id=?').get(p.sub);
  if (!u || !u.is_active) return null;
  return { id: u.id, email: u.email, name: u.display_name, role: u.role, sid: p.sid };
}
module.exports = { sha, hashPassword, checkPassword, signJwt, verifyJwt, authenticate, throttle };
