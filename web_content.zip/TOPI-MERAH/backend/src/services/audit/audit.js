'use strict';
const { sha } = require('../../middleware/auth');

// Audit log append-only dengan rantai hash: perubahan/penghapusan baris terdeteksi lewat verify().
function makeAudit(db) {
  const last = db.prepare('SELECT hash FROM audit_logs ORDER BY id DESC LIMIT 1');
  const ins = db.prepare('INSERT INTO audit_logs(at,actor_user,actor_agent,action,target,detail,prev_hash,hash) VALUES(?,?,?,?,?,?,?,?)');
  const digest = (prev, at, u, a, act, t, d) => sha([prev, at, u, a, act, t, d].map(String).join('|'));
  return {
    log({ user = null, agent = null, action, target = null, detail = null }) {
      const at = new Date().toISOString();
      const prev = (last.get() || {}).hash || 'GENESIS';
      const d = detail ? JSON.stringify(detail) : null;
      ins.run(at, user, agent, action, target, d, prev, digest(prev, at, user, agent, action, target, d));
    },
    verify() {
      let prev = 'GENESIS';
      for (const r of db.prepare('SELECT * FROM audit_logs ORDER BY id').all()) {
        if (r.prev_hash !== prev || r.hash !== digest(prev, r.at, r.actor_user, r.actor_agent, r.action, r.target, r.detail))
          return { valid: false, broken_at: r.id };
        prev = r.hash;
      }
      return { valid: true };
    },
  };
}
module.exports = { makeAudit };
