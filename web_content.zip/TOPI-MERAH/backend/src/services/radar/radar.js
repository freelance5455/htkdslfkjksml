'use strict';
const { HttpError } = require('../../errors');

const CATEGORIES = ['PHISHING', 'RANSOMWARE', 'MALWARE', 'DATA_BREACH', 'DDOS', 'VULNERABILITY', 'SUSPICIOUS_ACTIVITY', 'OTHER'];
const RISKS = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
// Titik pusat negara (perkiraan) hanya untuk penempatan marker di peta - bukan lokasi pelaku/korban.
const CENTROIDS = { ID: [-2.5, 118], US: [39.8, -98.6], CN: [35.9, 104.2], IN: [20.6, 79], JP: [36.2, 138.3], KR: [36.5, 127.9], SG: [1.35, 103.8],
  MY: [4.2, 102], TH: [15.9, 101], VN: [14.1, 108.3], PH: [12.9, 121.8], AU: [-25.3, 133.8], NZ: [-40.9, 174.9], GB: [54, -2], DE: [51.2, 10.4],
  FR: [46.2, 2.2], IT: [41.9, 12.6], ES: [40.5, -3.7], NL: [52.1, 5.3], UA: [48.4, 31.2], RU: [61.5, 105.3], TR: [38.96, 35.2], IL: [31, 34.9],
  SA: [23.9, 45.1], AE: [23.4, 53.8], EG: [26.8, 30.8], ZA: [-30.6, 22.9], NG: [9.1, 8.7], BR: [-14.2, -51.9], AR: [-38.4, -63.6], MX: [23.6, -102.6],
  CA: [56.1, -106.3], CL: [-35.7, -71.5], CO: [4.6, -74.3], PK: [30.4, 69.3], BD: [23.7, 90.4], KE: [-0.02, 37.9] };

function insertEvent(db, e) {
  const [lat, lon] = e.country_code && CENTROIDS[e.country_code] ? CENTROIDS[e.country_code] : [null, null];
  return db.prepare(`INSERT OR IGNORE INTO radar_events(external_id,title,category,risk,country_code,lat,lon,source_name,source_url,reported_at,verified,handling_status,submitted_by,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(e.external_id || null, e.title, e.category, e.risk, e.country_code || null, lat, lon, e.source_name, e.source_url,
    e.reported_at, e.verified ? 1 : 0, e.handling_status || null, e.submitted_by || null, new Date().toISOString()).changes;
}

// Impor katalog CISA KEV (sumber publik). KEV tidak memuat lokasi -> country_code null ("global").
async function ingestKev(db, cfg) {
  let j;
  try {
    const r = await fetch(cfg.kevUrl, { signal: AbortSignal.timeout(30000) });
    if (!r.ok) throw new Error('http ' + r.status);
    j = await r.json();
  } catch (e) { throw new HttpError(502, 'KEV_FETCH_FAILED', { reason: String(e.message).slice(0, 80) }); }
  const list = Array.isArray(j.vulnerabilities) ? j.vulnerabilities : [];
  const sorted = list.filter((v) => v && v.cveID && v.dateAdded).sort((a, b) => String(a.dateAdded).localeCompare(String(b.dateAdded))).slice(-cfg.kevLimit);
  let added = 0;
  db.exec('BEGIN');
  try {
    for (const v of sorted) {
      added += insertEvent(db, {
        external_id: 'kev:' + v.cveID, title: `${v.cveID}: ${v.vendorProject || ''} ${v.product || ''} - ${v.vulnerabilityName || ''}`.slice(0, 300),
        category: 'VULNERABILITY', risk: v.knownRansomwareCampaignUse === 'Known' ? 'CRITICAL' : 'HIGH', source_name: 'CISA Known Exploited Vulnerabilities',
        source_url: 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog', reported_at: new Date(v.dateAdded + 'T00:00:00Z').toISOString(),
        verified: true, handling_status: v.dueDate ? 'Batas patch (CISA): ' + v.dueDate : 'Dilaporkan',
      });
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return { fetched: sorted.length, added };
}
module.exports = { CATEGORIES, RISKS, CENTROIDS, insertEvent, ingestKev };
