'use strict';
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

// Skema setara dengan backend/db/schema.sql (PostgreSQL), disesuaikan untuk SQLite.
const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('FOUNDER','AI_OPERATOR','ANALYST','VIEWER')),
  is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
  refresh_hash TEXT NOT NULL, device TEXT, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, revoked_at TEXT);
CREATE TABLE IF NOT EXISTS ai_agents (
  id INTEGER PRIMARY KEY CHECK (id BETWEEN 1 AND 10), code TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  description TEXT NOT NULL, system_prompt TEXT NOT NULL, engine TEXT NOT NULL CHECK (engine IN ('GEMINI','OPENAI')),
  fallback_allowed INTEGER NOT NULL DEFAULT 1, is_active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id INTEGER NOT NULL REFERENCES ai_agents(id),
  user_id INTEGER REFERENCES users(id), role TEXT NOT NULL CHECK (role IN ('user','assistant')),
  content TEXT NOT NULL, engine TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_msg_agent ON messages(agent_id, user_id, id);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id INTEGER NOT NULL REFERENCES ai_agents(id),
  created_by INTEGER REFERENCES users(id), instruction TEXT NOT NULL, result TEXT, engine TEXT,
  status TEXT NOT NULL DEFAULT 'DONE', forwarded INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS radar_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, external_id TEXT UNIQUE, title TEXT NOT NULL, category TEXT NOT NULL,
  risk TEXT NOT NULL, country_code TEXT, lat REAL, lon REAL, source_name TEXT NOT NULL, source_url TEXT NOT NULL,
  reported_at TEXT NOT NULL, verified INTEGER NOT NULL DEFAULT 0, handling_status TEXT, ai_summary TEXT,
  submitted_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_radar_time ON radar_events(reported_at DESC);
CREATE TABLE IF NOT EXISTS incidents (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT, affected_system TEXT,
  category TEXT NOT NULL, risk TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'NEW', authorization_note TEXT,
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, closed_at TEXT);
CREATE TABLE IF NOT EXISTS incident_evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL REFERENCES incidents(id),
  filename TEXT NOT NULL, content TEXT NOT NULL, sha256 TEXT NOT NULL, uploaded_by INTEGER, uploaded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS incident_timeline (
  id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL REFERENCES incidents(id),
  at TEXT NOT NULL, actor TEXT NOT NULL, entry TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS approvals (
  id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL REFERENCES incidents(id),
  requested_action TEXT NOT NULL, requested_by INTEGER, requested_at TEXT NOT NULL,
  decision TEXT CHECK (decision IN ('APPROVED','REJECTED')), decided_by INTEGER, decided_at TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, actor_user INTEGER, actor_agent INTEGER,
  action TEXT NOT NULL, target TEXT, detail TEXT, prev_hash TEXT NOT NULL, hash TEXT NOT NULL);
`;

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');
  db.exec(SCHEMA);
  const agents = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'agents', 'agents.json'), 'utf8'));
  const ins = db.prepare('INSERT OR IGNORE INTO ai_agents(id,code,name,description,system_prompt,engine,fallback_allowed,is_active) VALUES(?,?,?,?,?,?,?,1)');
  for (const a of agents) ins.run(a.id, a.code, a.name, a.description, a.system_prompt, a.engine, a.fallback_allowed ? 1 : 0);
  return db;
}
module.exports = { openDb };
