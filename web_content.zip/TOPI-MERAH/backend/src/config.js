'use strict';
const fs = require('fs');
const path = require('path');

function loadDotEnv() {
  const p = path.join(__dirname, '..', '.env');
  if (!fs.existsSync(p)) return;
  for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

function loadConfig() {
  loadDotEnv();
  const e = process.env;
  const cfg = {
    port: Number(e.PORT) || 8080,
    host: e.HOST || '0.0.0.0',
    dbPath: e.DB_PATH || './topimerah.db',
    jwtSecret: e.JWT_SECRET || '',
    founderEmail: e.TOPI_MERAH_FOUNDER_EMAIL || e.CDI_FOUNDER_EMAIL || '',
    founderPassword: e.TOPI_MERAH_FOUNDER_PASSWORD || e.CDI_FOUNDER_PASSWORD || '',
    geminiKey: e.GEMINI_API_KEY || '',
    geminiModel: e.GEMINI_MODEL || '',
    geminiBase: e.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com',
    openaiKey: e.OPENAI_API_KEY || '',
    openaiModel: e.OPENAI_MODEL || '',
    openaiBase: e.OPENAI_BASE_URL || 'https://api.openai.com',
    kevUrl: e.KEV_URL || 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json',
    kevLimit: Number(e.KEV_LIMIT) || 100,
    // Asal (origin) yang boleh memanggil API dari browser/WebView. Kosong = CORS mati. Contoh: https://appassets.androidx.net
    corsOrigins: (e.CORS_ORIGINS || '').split(',').map((x) => x.trim()).filter(Boolean),
    accessTtl: 15 * 60,
    refreshTtl: 14 * 24 * 3600,
  };
  if (cfg.jwtSecret.length < 32) throw new Error('JWT_SECRET wajib diisi, minimal 32 karakter');
  return cfg;
}
module.exports = { loadConfig };
