'use strict';
// Pemanggilan Gemini & OpenAI. Dipanggil HANYA dari backend; kunci tidak pernah dikirim ke klien.
class AiError extends Error { constructor(code) { super(code); this.code = code; } }

async function post(url, headers, body) {
  let res;
  try {
    res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(45000) });
  } catch { throw new AiError('NETWORK_ERROR'); }
  if (!res.ok) throw new AiError('UPSTREAM_HTTP_' + res.status);
  try { return await res.json(); } catch { throw new AiError('BAD_RESPONSE'); }
}

async function gemini(cfg, system, messages) {
  if (!cfg.geminiKey) throw new AiError('NOT_CONFIGURED_KEY');
  if (!cfg.geminiModel) throw new AiError('NOT_CONFIGURED_MODEL');
  const j = await post(`${cfg.geminiBase}/v1beta/models/${encodeURIComponent(cfg.geminiModel)}:generateContent`,
    { 'x-goog-api-key': cfg.geminiKey },
    { systemInstruction: { parts: [{ text: system }] }, contents: messages.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })) });
  const t = (((j.candidates || [])[0] || {}).content || {}).parts;
  const text = Array.isArray(t) ? t.map((p) => p.text || '').join('') : '';
  if (!text) throw new AiError('EMPTY_RESPONSE');
  return text;
}

async function openai(cfg, system, messages) {
  if (!cfg.openaiKey) throw new AiError('NOT_CONFIGURED_KEY');
  if (!cfg.openaiModel) throw new AiError('NOT_CONFIGURED_MODEL');
  const j = await post(`${cfg.openaiBase}/v1/chat/completions`, { Authorization: `Bearer ${cfg.openaiKey}` },
    { model: cfg.openaiModel, messages: [{ role: 'system', content: system }, ...messages.map((m) => ({ role: m.role, content: m.content }))] });
  const text = (((j.choices || [])[0] || {}).message || {}).content;
  if (!text) throw new AiError('EMPTY_RESPONSE');
  return text;
}
module.exports = { gemini, openai, AiError };
