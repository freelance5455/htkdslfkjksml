'use strict';
// Uji integrasi: server TOPI MERAH asli + server UPSTREAM TIRUAN (bukan Gemini/OpenAI/CISA sungguhan).
const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const { createApp } = require('../src/server');
const { openDb } = require('../src/db');

const mock = { geminiFail: false, calls: { gemini: 0, openai: 0 }, lastKeys: [] };
function startMock() {
  return new Promise((res) => {
    const s = http.createServer((req, rs) => {
      let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
        const j = (c, o) => { rs.writeHead(c, { 'Content-Type': 'application/json' }); rs.end(JSON.stringify(o)); };
        if (req.url.startsWith('/v1beta/models/')) {
          mock.calls.gemini++; mock.lastKeys.push(req.headers['x-goog-api-key']);
          if (mock.geminiFail) return j(500, {});
          return j(200, { candidates: [{ content: { parts: [{ text: 'GEMINI-JAWABAN' }] } }] });
        }
        if (req.url === '/v1/chat/completions') { mock.calls.openai++; return j(200, { choices: [{ message: { content: 'OPENAI-JAWABAN' } }] }); }
        if (req.url === '/kev.json') return j(200, { vulnerabilities: [
          { cveID: 'CVE-TEST-0001', vendorProject: 'VendorA', product: 'ProdA', vulnerabilityName: 'Uji A', dateAdded: '2026-01-02', dueDate: '2026-01-23', knownRansomwareCampaignUse: 'Known' },
          { cveID: 'CVE-TEST-0002', vendorProject: 'VendorB', product: 'ProdB', vulnerabilityName: 'Uji B', dateAdded: '2026-01-03', dueDate: '2026-01-24', knownRansomwareCampaignUse: 'Unknown' }] });
        j(404, {});
      });
    }).listen(0, '127.0.0.1', () => res(s));
  });
}

let up, srv, base, db, audit;
const FOUNDER = { email: 'founder@test.id', password: 'Founder-Password-123' };
async function api(method, path, body, token) {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { s: r.status, j: await r.json() };
}
const login = async (c) => (await api('POST', '/api/auth/login', c)).j;

test.before(async () => {
  up = await startMock();
  const u = `http://127.0.0.1:${up.address().port}`;
  const cfg = { port: 0, host: '127.0.0.1', jwtSecret: 'x'.repeat(40), founderEmail: FOUNDER.email, founderPassword: FOUNDER.password, accessTtl: 900, refreshTtl: 86400,
    geminiKey: 'GKEY-SECRET', geminiModel: 'm', geminiBase: u, openaiKey: 'OKEY-SECRET', openaiModel: 'm', openaiBase: u, kevUrl: u + '/kev.json', kevLimit: 100, corsOrigins: ['https://appassets.androidx.net'] };
  db = openDb(':memory:');
  const app = createApp(cfg, db); audit = app.audit;
  srv = app.server; await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${srv.address().port}`;
});
test.after(() => { srv.close(); up.close(); });

let F, O, V;
test('autentikasi: tanpa token 401, login salah 401, login benar OK', async () => {
  assert.equal((await api('GET', '/api/agents')).s, 401);
  assert.equal((await api('POST', '/api/auth/login', { email: FOUNDER.email, password: 'salah-salah-1' })).s, 401);
  F = await login(FOUNDER); assert.ok(F.access_token); assert.equal(F.user.role, 'FOUNDER');
});
test('Founder membuat pengguna; password pendek ditolak; role invalid ditolak', async () => {
  assert.equal((await api('POST', '/api/users', { email: 'x@t.id', password: 'pendek', display_name: 'x', role: 'VIEWER' }, F.access_token)).s, 400);
  assert.equal((await api('POST', '/api/users', { email: 'x@t.id', password: 'Password-Panjang-1', display_name: 'x', role: 'ROOT' }, F.access_token)).s, 400);
  assert.equal((await api('POST', '/api/users', { email: 'op@t.id', password: 'Operator-Pass-123', display_name: 'Op', role: 'AI_OPERATOR' }, F.access_token)).s, 201);
  assert.equal((await api('POST', '/api/users', { email: 'v@t.id', password: 'Viewer-Pass-12345', display_name: 'V', role: 'VIEWER' }, F.access_token)).s, 201);
  O = await login({ email: 'op@t.id', password: 'Operator-Pass-123' }); V = await login({ email: 'v@t.id', password: 'Viewer-Pass-12345' });
  assert.equal((await api('GET', '/api/users', null, O.access_token)).s, 403);
});
test('10 AI specialist tersedia', async () => {
  const { j } = await api('GET', '/api/agents', null, V.access_token);
  assert.equal(j.agents.length, 10);
});
test('chat per-agen: Gemini & OpenAI lewat backend, riwayat terpisah', async () => {
  const a = await api('POST', '/api/agents/1/chat', { message: 'halo commander' }, O.access_token);       // agen 1 = GEMINI
  const b = await api('POST', '/api/agents/2/chat', { message: 'halo intel' }, O.access_token);           // agen 2 = OPENAI
  assert.equal(a.j.engine, 'GEMINI'); assert.equal(a.j.reply, 'GEMINI-JAWABAN');
  assert.equal(b.j.engine, 'OPENAI'); assert.equal(b.j.reply, 'OPENAI-JAWABAN');
  const h1 = (await api('GET', '/api/agents/1/messages', null, O.access_token)).j.messages, h2 = (await api('GET', '/api/agents/2/messages', null, O.access_token)).j.messages;
  assert.equal(h1.length, 2); assert.equal(h2.length, 2); assert.match(h2[0].content, /halo intel/);
  assert.ok(mock.lastKeys.every((k) => k === 'GKEY-SECRET'));
});
test('kunci API tidak pernah muncul di respons', async () => {
  for (const p of ['/api/status', '/api/dashboard', '/api/agents']) assert.ok(!JSON.stringify((await api('GET', p, null, F.access_token)).j).match(/KEY-SECRET/));
});
test('Viewer tidak boleh chat (403)', async () => { assert.equal((await api('POST', '/api/agents/1/chat', { message: 'x' }, V.access_token)).s, 403); });
test('fallback: Gemini gagal -> OpenAI dipakai; fallback dimatikan -> 502 jujur', async () => {
  mock.geminiFail = true;
  const r = await api('POST', '/api/agents/1/chat', { message: 'tes fallback' }, O.access_token);
  assert.equal(r.j.engine, 'OPENAI'); assert.equal(r.j.fallback_used, true);
  await api('PATCH', '/api/agents/1', { fallback_allowed: false }, F.access_token);
  const r2 = await api('POST', '/api/agents/1/chat', { message: 'tanpa fallback' }, O.access_token);
  assert.equal(r2.s, 502); assert.equal(r2.j.error, 'AI_UNAVAILABLE');
  mock.geminiFail = false; await api('PATCH', '/api/agents/1', { fallback_allowed: true }, F.access_token);
});
test('AI Red Team wajib menyertakan izin tertulis', async () => {
  assert.equal((await api('POST', '/api/agents/6/chat', { message: 'uji target' }, O.access_token)).s, 403);
  assert.equal((await api('POST', '/api/agents/6/chat', { message: 'uji lab', authorization: 'Server lab milik sendiri, saya pemilik' }, O.access_token)).s, 200);
});
test('Radar: impor KEV (publik) bersumber+berwaktu, dedupe, laporan user = belum terverifikasi', async () => {
  assert.equal((await api('POST', '/api/radar/ingest/kev', {}, V.access_token)).s, 403);
  const i1 = await api('POST', '/api/radar/ingest/kev', {}, O.access_token); assert.equal(i1.j.added, 2);
  assert.equal((await api('POST', '/api/radar/ingest/kev', {}, O.access_token)).j.added, 0);
  const { j } = await api('GET', '/api/radar?category=VULNERABILITY', null, V.access_token);
  assert.equal(j.events.length, 2);
  for (const e of j.events) { assert.ok(e.source_url.startsWith('https://')); assert.ok(e.reported_at); assert.equal(e.verified, true); }
  assert.equal(j.events.find((e) => e.title.includes('0001')).risk, 'CRITICAL');
  const rep = await api('POST', '/api/radar/reports', { title: 'Phishing bank X', category: 'PHISHING', risk: 'MEDIUM', country_code: 'ID', source_name: 'Blog Uji', source_url: 'https://example.org/a', reported_at: '2026-02-01T00:00:00Z' }, O.access_token);
  assert.equal(rep.s, 201); assert.equal(rep.j.verified, false); assert.ok(rep.j.lat != null);
  assert.equal((await api('POST', `/api/radar/${rep.j.id}/verify`, {}, O.access_token)).s, 403);
  assert.equal((await api('POST', `/api/radar/${rep.j.id}/verify`, {}, F.access_token)).j.verified, true);
});
test('Radar: pipeline 5 agen berjalan & menyimpan ringkasan', async () => {
  const id = (await api('GET', '/api/radar?category=PHISHING', null, F.access_token)).j.events[0].id;
  const r = await api('POST', `/api/radar/${id}/analyze`, {}, F.access_token);
  assert.equal(r.s, 200); assert.equal(r.j.steps.length, 5); assert.ok(r.j.event.ai_summary);
});
test('Commander merge: gabungan dua mesin; jika satu gagal dilaporkan', async () => {
  let r = await api('POST', '/api/commander/merge', { prompt: 'ringkas' }, O.access_token);
  assert.equal(r.j.merged, true); assert.deepEqual(r.j.engines_used.sort(), ['GEMINI', 'OPENAI']);
  mock.geminiFail = true;
  r = await api('POST', '/api/commander/merge', { prompt: 'ringkas' }, O.access_token);
  assert.equal(r.j.merged, false); assert.equal(r.j.errors[0].engine, 'GEMINI'); mock.geminiFail = false;
});
test('Insiden + persetujuan: IN_PROGRESS hanya via Founder', async () => {
  const c = await api('POST', '/api/incidents', { title: 'Ransomware server uji', affected_system: 'srv-lab-01', category: 'RANSOMWARE', risk: 'HIGH', authorization_note: 'Pemilik sistem (PT Uji) menyetujui tertulis' }, O.access_token);
  const id = c.j.id; assert.equal(c.j.status, 'NEW');
  assert.equal((await api('POST', `/api/incidents/${id}/status`, { status: 'IN_PROGRESS' }, F.access_token)).s, 403);
  assert.equal((await api('POST', `/api/incidents/${id}/status`, { status: 'NEEDS_APPROVAL' }, O.access_token)).s, 409);
  await api('POST', `/api/incidents/${id}/status`, { status: 'UNDER_ANALYSIS' }, O.access_token);
  const ev = await api('POST', `/api/incidents/${id}/evidence`, { filename: 'auth.log', content: 'Failed password for root' }, O.access_token);
  assert.equal(ev.j.sha256.length, 64);
  assert.equal((await api('POST', `/api/incidents/${id}/analyze`, {}, O.access_token)).j.steps.length, 2);
  const na = await api('POST', `/api/incidents/${id}/status`, { status: 'NEEDS_APPROVAL', requested_action: 'Isolasi server srv-lab-01 dari jaringan' }, O.access_token);
  assert.ok(na.j.approval_id);
  assert.equal((await api('POST', `/api/approvals/${na.j.approval_id}/decision`, { decision: 'APPROVED' }, O.access_token)).s, 403);
  const d = await api('POST', `/api/approvals/${na.j.approval_id}/decision`, { decision: 'APPROVED' }, F.access_token);
  assert.equal(d.j.incident_status, 'IN_PROGRESS');
  assert.equal((await api('POST', `/api/approvals/${na.j.approval_id}/decision`, { decision: 'REJECTED' }, F.access_token)).s, 409);
  await api('POST', `/api/incidents/${id}/status`, { status: 'RESOLVED' }, O.access_token);
  assert.equal((await api('POST', `/api/incidents/${id}/status`, { status: 'CLOSED' }, O.access_token)).s, 403);
  assert.equal((await api('POST', `/api/incidents/${id}/status`, { status: 'CLOSED' }, F.access_token)).j.status, 'CLOSED');
  const rep = await api('GET', `/api/incidents/${id}/report`, null, V.access_token);
  assert.match(rep.j.report_markdown, /SHA-256/); assert.match(rep.j.report_markdown, /APPROVED/);
});
test('insiden tanpa bukti izin tidak bisa minta persetujuan', async () => {
  const c = await api('POST', '/api/incidents', { title: 'Tanpa izin', affected_system: 'srv-x', category: 'OTHER', risk: 'LOW' }, O.access_token);
  await api('POST', `/api/incidents/${c.j.id}/status`, { status: 'UNDER_ANALYSIS' }, O.access_token);
  const r = await api('POST', `/api/incidents/${c.j.id}/status`, { status: 'NEEDS_APPROVAL', requested_action: 'Blokir IP penyerang' }, O.access_token);
  assert.equal(r.j.error, 'AUTHORIZATION_NOTE_REQUIRED');
});
test('input berbahaya: JSON rusak 400, SQL injection di filter ditolak, payload besar 413', async () => {
  const r = await fetch(base + '/api/auth/login', { method: 'POST', body: '{rusak' }); assert.equal(r.status, 400);
  assert.equal((await api('GET', "/api/radar?category=PHISHING'%20OR%201=1--", null, F.access_token)).s, 400);
  const big = await fetch(base + '/api/auth/login', { method: 'POST', body: JSON.stringify({ x: 'a'.repeat(1_100_000) }) }); assert.equal(big.status, 413);
});
test('audit log: tercatat, rantai hash valid, perubahan terdeteksi', async () => {
  const logs = (await api('GET', '/api/audit?limit=500', null, F.access_token)).j.logs;
  const acts = logs.map((l) => l.action);
  for (const a of ['AUTH_LOGIN', 'USER_CREATED', 'AGENT_CHAT', 'APPROVAL_APPROVED', 'ACCESS_DENIED', 'RADAR_INGEST_KEV']) assert.ok(acts.includes(a), a);
  assert.equal((await api('GET', '/api/audit/verify', null, F.access_token)).j.valid, true);
  assert.equal((await api('GET', '/api/audit', null, V.access_token)).j.logs.every((l) => l.actor_user === 3), true);
  db.prepare("UPDATE audit_logs SET action='HAPUS_JEJAK' WHERE id=2").run();
  assert.equal((await api('GET', '/api/audit/verify', null, F.access_token)).j.valid, false);
});
test('refresh token dirotasi; logout mencabut sesi; nonaktifkan user mencabut akses', async () => {
  const r1 = await api('POST', '/api/auth/refresh', { refresh_token: V.refresh_token }); assert.ok(r1.j.access_token);
  assert.equal((await api('POST', '/api/auth/refresh', { refresh_token: V.refresh_token })).s, 401); // token lama tak bisa dipakai ulang
  assert.equal((await api('POST', '/api/auth/logout', {}, r1.j.access_token)).s, 200);
  assert.equal((await api('GET', '/api/auth/me', null, r1.j.access_token)).s, 401);
  const uid = (await api('GET', '/api/users', null, F.access_token)).j.users.find((u) => u.email === 'op@t.id').id;
  await api('PATCH', `/api/users/${uid}`, { is_active: false }, F.access_token);
  assert.equal((await api('GET', '/api/agents', null, O.access_token)).s, 401);
  assert.equal((await api('PATCH', '/api/users/1', { role: 'VIEWER' }, F.access_token)).j.error, 'LAST_FOUNDER');
});
test('login dibatasi setelah 5 kegagalan', async () => {
  for (let i = 0; i < 5; i++) await api('POST', '/api/auth/login', { email: 'v@t.id', password: 'salah-salah-' + i });
  assert.equal((await api('POST', '/api/auth/login', { email: 'v@t.id', password: 'Viewer-Pass-12345' })).s, 429);
});

test('CORS: hanya asal di allowlist yang mendapat header; preflight OPTIONS 204', async () => {
  const ok = await fetch(base + '/health', { headers: { Origin: 'https://appassets.androidx.net' } });
  assert.equal(ok.headers.get('access-control-allow-origin'), 'https://appassets.androidx.net');
  const bad = await fetch(base + '/health', { headers: { Origin: 'https://evil.example' } });
  assert.equal(bad.headers.get('access-control-allow-origin'), null);
  const pre = await fetch(base + '/api/agents', { method: 'OPTIONS', headers: { Origin: 'https://appassets.androidx.net', 'Access-Control-Request-Method': 'GET' } });
  assert.equal(pre.status, 204);
  assert.match(pre.headers.get('access-control-allow-headers'), /Authorization/);
});
