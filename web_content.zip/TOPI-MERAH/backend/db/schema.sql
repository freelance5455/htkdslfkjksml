CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TYPE user_role AS ENUM ('FOUNDER','AI_OPERATOR','ANALYST','VIEWER');
CREATE TYPE ai_engine AS ENUM ('GEMINI','OPENAI');
CREATE TYPE incident_status AS ENUM ('NEW','UNDER_ANALYSIS','NEEDS_APPROVAL','IN_PROGRESS','RESOLVED','CLOSED');
CREATE TYPE risk_level AS ENUM ('LOW','MEDIUM','HIGH','CRITICAL');
CREATE TYPE threat_category AS ENUM ('PHISHING','RANSOMWARE','MALWARE','DATA_BREACH','DDOS','VULNERABILITY','SUSPICIOUS_ACTIVITY','OTHER');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'VIEWER',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token_hash TEXT NOT NULL, device TEXT,
  created_at TIMESTAMPTZ DEFAULT now(), expires_at TIMESTAMPTZ NOT NULL, revoked_at TIMESTAMPTZ
);
CREATE TABLE ai_agents (
  id SMALLINT PRIMARY KEY CHECK (id BETWEEN 1 AND 10),
  code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL,
  system_prompt TEXT NOT NULL, engine ai_engine NOT NULL DEFAULT 'GEMINI',
  fallback_allowed BOOLEAN NOT NULL DEFAULT TRUE, is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id SMALLINT NOT NULL REFERENCES ai_agents(id),
  user_id UUID NOT NULL REFERENCES users(id),
  title TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE messages (
  id BIGSERIAL PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user','assistant','system','tool')),
  content TEXT NOT NULL, engine ai_engine, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id SMALLINT NOT NULL REFERENCES ai_agents(id),
  created_by UUID REFERENCES users(id),
  instruction TEXT NOT NULL, result TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING', forwarded_to_commander BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE radar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL, category threat_category NOT NULL, risk risk_level NOT NULL,
  country_code CHAR(2), lat DOUBLE PRECISION, lon DOUBLE PRECISION,
  source_name TEXT NOT NULL, source_url TEXT NOT NULL,
  reported_at TIMESTAMPTZ NOT NULL, verified BOOLEAN NOT NULL DEFAULT FALSE,
  handling_status TEXT, ai_summary TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL, description TEXT, affected_system TEXT,
  category threat_category, risk risk_level, status incident_status NOT NULL DEFAULT 'NEW',
  authorization_note TEXT,
  created_by UUID REFERENCES users(id), created_at TIMESTAMPTZ DEFAULT now(), closed_at TIMESTAMPTZ
);
CREATE TABLE incident_evidence (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id UUID REFERENCES incidents(id) ON DELETE CASCADE,
  filename TEXT, sha256 CHAR(64) NOT NULL, storage_path TEXT,
  uploaded_by UUID REFERENCES users(id), uploaded_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE incident_timeline (
  id BIGSERIAL PRIMARY KEY, incident_id UUID REFERENCES incidents(id) ON DELETE CASCADE,
  event_time TIMESTAMPTZ DEFAULT now(), actor TEXT, entry TEXT NOT NULL
);
CREATE TABLE approvals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id UUID REFERENCES incidents(id), requested_action TEXT NOT NULL, requested_by TEXT,
  decided_by UUID REFERENCES users(id),
  decision TEXT CHECK (decision IN ('APPROVED','REJECTED')), decided_at TIMESTAMPTZ
);
CREATE TABLE audit_logs (
  id BIGSERIAL PRIMARY KEY, at TIMESTAMPTZ DEFAULT now(),
  actor_user UUID, actor_agent SMALLINT, action TEXT NOT NULL, target TEXT, detail JSONB
);
CREATE INDEX idx_radar_reported ON radar_events (reported_at DESC);
CREATE INDEX idx_audit_at ON audit_logs (at DESC);
