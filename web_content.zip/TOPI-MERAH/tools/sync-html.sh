#!/bin/sh
# Salin index.html + logo ke assets Android (jalankan setelah mengedit index.html).
set -e
cd "$(dirname "$0")/.."
D=android/app/src/main/assets
mkdir -p "$D/assets/logo"
cp index.html "$D/index.html"
cp assets/logo/* "$D/assets/logo/"
echo "OK: HTML & logo disalin ke $D"
