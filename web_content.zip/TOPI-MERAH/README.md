# TOPI MERAH — AI Cyber Defense Force
**DEFEND THE DIGITAL NATION.**

Dahulu bernama "CDI AI Cyber Defense Force" (v0.2). Hanya untuk pertahanan siber yang sah dan berizin.
Bukan lembaga resmi pemerintah, TNI, Polri, atau BSSN.

## Mulai dari sini
| Lokasi | Isi |
|---|---|
| **`index.html`** | Dashboard lengkap satu file. Buka dengan editor HTML / browser di Android. |
| `assets/logo/` | Logo karakter bertopi merah (jalur relatif dari `index.html`). |
| `android/` | Aplikasi Android: pembungkus WebView (`HtmlShellActivity`) + konsol native Compose lama (`MainActivity`). |
| `backend/` | API Node.js (auth, RBAC, 10 AI Gemini/OpenAI, radar, insiden, audit log). 18/18 tes lulus. |
| `docs/` | Panduan & laporan. Baca `docs/LAPORAN_UPGRADE.md` dulu. |
| `tools/sync-html.sh` | Salin `index.html` + logo ke assets Android setelah Anda mengedit. |
| `.github/workflows/build-apk.yml` | Build APK debug di GitHub (belum pernah dijalankan). |

Data: default menampilkan data nyata dari sumber publik (CISA KEV, abuse.ch Feodo) setelah Anda menekan "Muat data ancaman nyata"; DEMO hanya jika dinyalakan di Atur.

Status jujur: APK **belum dibangun**; Android **belum dikompilasi**; Gemini/OpenAI **belum diuji ke layanan sungguhan**; peta **belum diuji memuat tile** (lingkungan pengembangan tanpa internet). Rincian di `docs/LAPORAN_UPGRADE.md`.
