(() => {
 const $=id=>document.getElementById(id), today=()=>new Date().toLocaleDateString('en-CA');
 const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
 let profile=read('levelUpProfile',null), state=read('levelUpSave',{day:today(),push:0,squat:0,abs:0,xp:0});
 if(state.day!==today()) state={...state,day:today(),push:0,squat:0,abs:0};
 const save=()=>localStorage.setItem('levelUpSave',JSON.stringify(state));
 const levelFor=xp=>Math.floor(xp/250)+1;
 const rankFor=level=>level>=30?'S':level>=20?'A':level>=12?'B':level>=7?'C':level>=3?'D':'E';
 function speak(message){try{if(!('speechSynthesis'in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(message);u.pitch=.58;u.rate=.88;u.volume=1;window.speechSynthesis.speak(u);}catch{}}
 function showRankUp(oldLevel,newLevel){if(newLevel<=oldLevel)return;const toast=$('rankToast');$('rankToastText').textContent=`${rankFor(oldLevel)} → ${rankFor(newLevel)} · LEVEL ${newLevel}`;toast.classList.remove('show');void toast.offsetWidth;toast.classList.add('show');speak(`System alert. Rank up. Congratulations hunter. New rank ${rankFor(newLevel)}. Level ${newLevel}.`);}
 function showLogin(){ $('login').hidden=false;$('dashboard').hidden=true;if(profile){$('nameInput').value=profile.name;$('ageInput').value=profile.age;} }
 function showDashboard(){ $('login').hidden=true;$('dashboard').hidden=false;$('welcome').textContent=`${profile.name.toUpperCase()}`;render(); }
 $('start').addEventListener('click',()=>{const name=$('nameInput').value.trim(),age=Number($('ageInput').value);if(!name){$('loginStatus').textContent='Please enter your name.';return;}if(!Number.isInteger(age)||age<5||age>120){$('loginStatus').textContent='Please enter a valid age.';return;}profile={name,age};localStorage.setItem('levelUpProfile',JSON.stringify(profile));showDashboard();speak(`Welcome ${name}. Hunter system online.`);});
 function render(){const level=levelFor(state.xp),inLevel=state.xp%250,rank=rankFor(level),pct=Math.round(inLevel/250*100);$('level').textContent=`LEVEL ${level}`;$('rank').textContent=`RANK ${rank}`;$('xp').textContent=`${inLevel} / 250 XP · TOTAL ${state.xp} XP`;$('progress').style.width=`${pct}%`;$('heroLevel').textContent=String(level).padStart(2,'0');$('totalXp').textContent=`${state.xp} XP`;$('progressPercent').textContent=`${pct}%`;$('rankSmall').textContent=`RANK ${rank}`;['push','squat','abs'].forEach(k=>$(`${k}Value`).textContent=`${state[k]} reps`);$('quest').textContent=`Today: Push-ups ${state.push} · Squats ${state.squat} · Core ${state.abs}. Complete a comfortable session when ready.`;save();}
 function addRep(key,source='manual'){state[key]++;render();if(source==='camera'){$('cameraStatus').textContent=`Detected ${state[key]} ${key==='push'?'push-ups':key==='squat'?'squats':'abs'} today.`;}}
 document.querySelectorAll('[data-exercise]').forEach(b=>b.addEventListener('click',()=>addRep(b.dataset.exercise)));
 $('complete').addEventListener('click',()=>{const total=state.push+state.squat+state.abs;if(!total){$('status').textContent='Add completed reps first. Rest days are okay too.';return;}const oldLevel=levelFor(state.xp),gained=Math.min(100,20+Math.floor(total/2));state.xp+=gained;render();$('status').textContent=`Session saved! +${gained} XP. Recovery matters too.`;showRankUp(oldLevel,levelFor(state.xp));if(levelFor(state.xp)===oldLevel)speak(`Session complete. ${gained} experience points earned.`);});
 $('reset').addEventListener('click',()=>{state.push=state.squat=state.abs=0;render();$('status').textContent="Today's reps reset.";});
 $('changeProfile').addEventListener('click',()=>{stopCamera();showLogin();});
 // Camera-assisted pose counter powered by MediaPipe Pose Landmarker (downloaded by the browser on first use).
 let stream=null,landmarker=null,raf=0,lastVideoTime=-1,phase='ready',lastCountAt=0,detectBusy=false;
 const video=$('camera'),cameraStatus=$('cameraStatus');
 const angle=(a,b,c)=>{const ab=[a.x-b.x,a.y-b.y],cb=[c.x-b.x,c.y-b.y];const dot=ab[0]*cb[0]+ab[1]*cb[1],m=Math.hypot(...ab)*Math.hypot(...cb);return m?Math.acos(Math.max(-1,Math.min(1,dot/m)))*180/Math.PI:180;};
 function stopCamera(){cancelAnimationFrame(raf);raf=0;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}video.srcObject=null;if(landmarker){try{landmarker.close()}catch{}landmarker=null;}phase='ready';$('cameraStart').disabled=false;$('cameraStop').disabled=true;cameraStatus.textContent='Camera is off.';}
 async function startCamera(){
  if(!navigator.mediaDevices?.getUserMedia){cameraStatus.textContent='Camera access needs a secure HTTPS page and a supported browser.';return;}
  $('cameraStart').disabled=true;cameraStatus.textContent='Loading pose detector…';
  try{
   const vision=await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14');
   const fileset=await vision.FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm');
   landmarker=await vision.PoseLandmarker.createFromOptions(fileset,{baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task',delegate:'GPU'},runningMode:'VIDEO',numPoses:1});
   stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:640},height:{ideal:480}},audio:false});video.srcObject=stream;await video.play();
   phase='ready';lastCountAt=0;$('cameraStop').disabled=false;cameraStatus.textContent='Camera on. Keep shoulders, hips, knees and ankles in frame.';speak('Camera training started. Move slowly and safely.');loop();
  }catch(e){stopCamera();$('cameraStart').disabled=false;cameraStatus.textContent=e?.name==='NotAllowedError'?'Camera permission denied. Allow camera access in your browser settings.':`Could not start camera: ${e.message||'please try again'}.`;
  }
 }
 function loop(){if(!landmarker||!stream)return;if(video.currentTime!==lastVideoTime&&!detectBusy){lastVideoTime=video.currentTime;detectBusy=true;try{const result=landmarker.detectForVideo(video,performance.now());const lm=result.landmarks?.[0];if(lm)processPose(lm);}catch{}finally{detectBusy=false;}}raf=requestAnimationFrame(loop);}
 function processPose(l){const mode=$('exerciseMode').value;const left=[11,13,15,23,25,27],right=[12,14,16,24,26,28];const vis=ids=>ids.every(i=>(l[i]?.visibility??0)>.55);let value=null;
  if(mode==='push'){if(!vis(left)&&!vis(right))return;const ids=vis(left)?[11,13,15]:[12,14,16];value=angle(l[ids[0]],l[ids[1]],l[ids[2]]);}
  else if(mode==='squat'){if(!vis(left)&&!vis(right))return;const ids=vis(left)?[23,25,27]:[24,26,28];value=angle(l[ids[0]],l[ids[1]],l[ids[2]]);}
  else {if(!vis([11,23,25])&&!vis([12,24,26]))return;const ids=vis([11,23,25])?[11,23,25]:[12,24,26];value=angle(l[ids[0]],l[ids[1]],l[ids[2]]);}
  const down=mode==='push'?value<90:mode==='squat'?value<105:value<85;const up=mode==='push'?value>150:mode==='squat'?value>155:value>135;
  if(down&&phase==='ready')phase='down';else if(up&&phase==='down'&&Date.now()-lastCountAt>900){phase='ready';lastCountAt=Date.now();addRep(mode,'camera');}
 }
 $('cameraStart').addEventListener('click',startCamera);$('cameraStop').addEventListener('click',stopCamera);$('exerciseMode').addEventListener('change',()=>{phase='ready';cameraStatus.textContent=stream?'Mode changed. Start from a standing/starting position.':'Camera is off.';});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&stream)stopCamera();});window.addEventListener('pagehide',stopCamera);
 if(profile&&profile.name&&profile.age)showDashboard();else showLogin();
})();
