package com.simon.solosystem

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.speech.tts.TextToSpeech
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("solo_system", MODE_PRIVATE) }
    private var push = 0
    private var squat = 0
    private var abs = 0
    private var xp = 0
    private lateinit var pushValue: TextView
    private lateinit var squatValue: TextView
    private lateinit var absValue: TextView
    private lateinit var status: TextView
    private lateinit var xpText: TextView
    private lateinit var levelText: TextView
    private lateinit var rankText: TextView
    private lateinit var questText: TextView
    private lateinit var bar: ProgressBar
    private var voice: TextToSpeech? = null
    private var lastKnownLevel = 1

    private val bg = Color.rgb(10, 14, 30)
    private val panel = Color.rgb(22, 30, 56)
    private val cyan = Color.rgb(76, 220, 255)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voice = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                voice?.language = Locale.US
                voice?.setPitch(0.62f)
                voice?.setSpeechRate(0.88f)
            }
        }
        val savedName = prefs.getString("profile_name", null)
        val savedAge = prefs.getInt("profile_age", 0)
        if (savedName.isNullOrBlank() || savedAge == 0) {
            buildLoginUi()
        } else {
            loadData()
            buildUi(savedName)
            updateUi()
        }
    }


    private fun buildLoginUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(30))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "LEVEL UP"
            textSize = 34f; setTextColor(cyan); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; letterSpacing = 0.12f
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "WELCOME, HUNTER"
            textSize = 13f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(30))
        }
        root.addView(subtitle)

        val name = EditText(this).apply {
            hint = "Enter your name"
            setSingleLine(true)
            setTextColor(white); setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        root.addView(name, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(14) })

        val age = EditText(this).apply {
            hint = "Enter your age"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setTextColor(white); setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        root.addView(age, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(18) })

        val message = TextView(this).apply {
            text = "Enter your details to begin your journey."
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(message)

        val start = Button(this).apply {
            text = "START YOUR JOURNEY"
            setOnClickListener {
                val enteredName = name.text.toString().trim()
                val enteredAge = age.text.toString().toIntOrNull()
                if (enteredName.isBlank()) {
                    message.text = "Please enter your name."
                } else if (enteredAge == null || enteredAge !in 5..120) {
                    message.text = "Please enter a valid age."
                } else {
                    prefs.edit().putString("profile_name", enteredName)
                        .putInt("profile_age", enteredAge).apply()
                    loadData()
                    buildUi(enteredName)
                    updateUi()
                    speakSystem("Welcome hunter. System online.")
                }
            }
        }
        root.addView(start, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(18) })
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun loadData() {
        xp = prefs.getInt("xp", 0)
        val savedDay = prefs.getString("day", "") ?: ""
        if (savedDay == today()) {
            push = prefs.getInt("push", 0)
            squat = prefs.getInt("squat", 0)
            abs = prefs.getInt("abs", 0)
        } else {
            push = 0; squat = 0; abs = 0
            prefs.edit().putString("day", today()).putInt("push", 0)
                .putInt("squat", 0).putInt("abs", 0).apply()
        }
    }

    private fun saveData() {
        prefs.edit().putInt("xp", xp).putInt("push", push).putInt("squat", squat)
            .putInt("abs", abs).putString("day", today()).apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(userName: String) {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val welcome = TextView(this).apply {
            text = "WELCOME, $userName"
            textSize = 15f; setTextColor(white); gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(welcome)
        val title = TextView(this).apply {
            text = "SOLO SYSTEM"
            textSize = 28f; setTextColor(cyan); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; letterSpacing = 0.16f
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "YOUR TRAINING JOURNEY STARTS HERE"
            textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(18))
        }
        root.addView(subtitle)

        val profile = card(root)
        levelText = text(profile, "LEVEL 1", 25f, cyan, true)
        rankText = text(profile, "RANK E", 15f, white, true)
        xpText = text(profile, "0 / 250 XP", 14f, white, false)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 250; progress = 0
        }
        profile.addView(bar, LinearLayout.LayoutParams(-1, dp(9)).apply { topMargin = dp(10) })

        val quest = card(root)
        text(quest, "DAILY QUEST", 17f, cyan, true)
        questText = text(quest, "Complete a comfortable training session.", 14f, white, false)
        text(quest, "Starter guide: try 5 push-ups, 10 squats and 5 gentle core reps. Adjust to your ability; quality matters more than numbers.", 12f, Color.LTGRAY, false)

        val workout = card(root)
        text(workout, "TRAINING", 18f, cyan, true)
        text(workout, "Add reps as you complete them. Take breaks whenever needed.", 12f, Color.LTGRAY, false)
        pushValue = exerciseRow(workout, "PUSH-UPS", "push")
        squatValue = exerciseRow(workout, "SQUATS", "squat")
        absValue = exerciseRow(workout, "ABS / CORE", "abs")

        val ranks = card(root)
        text(ranks, "HUNTER RANKS", 17f, cyan, true)
        text(ranks, "E · LV 1     D · LV 3     C · LV 7\nB · LV 12    A · LV 20    S · LV 30", 13f, white, true)

        val finish = Button(this).apply {
            text = "COMPLETE SESSION  •  EARN XP"
            setOnClickListener { completeSession() }
        }
        root.addView(finish, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) })

        status = text(root, "Train safely. Rest is part of progress.", 12f, Color.LTGRAY, false)
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(12), 0, dp(4))

        val reset = Button(this).apply {
            text = "RESET TODAY'S REPS"
            setOnClickListener {
                push = 0; squat = 0; abs = 0
                saveData(); updateUi()
                status.text = "Today's rep counters have been reset."
            }
        }
        root.addView(reset)
        text(root, "Safety note: warm up first, use controlled movements, stop if you feel pain or unwell, and allow recovery days. This app is a tracker—not a medical or coaching tool.", 11f, Color.LTGRAY, false)
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            setBackgroundColor(panel)
        }
        parent.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(4) })
        return box
    }

    private fun text(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(3), 0, dp(3))
        }
        parent.addView(t)
        return t
    }

    private fun exerciseRow(parent: LinearLayout, label: String, key: String): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        parent.addView(row)
        val name = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        }
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        val value = TextView(this).apply {
            text = "0 reps"; textSize = 14f; setTextColor(cyan); gravity = Gravity.CENTER
        }
        row.addView(value, LinearLayout.LayoutParams(dp(72), -2))
        val add = Button(this).apply {
            text = "+1"
            minWidth = dp(56)
            setOnClickListener {
                when (key) { "push" -> push++; "squat" -> squat++; else -> abs++ }
                saveData(); updateUi()
            }
        }
        row.addView(add)
        return value
    }

    private fun completeSession() {
        val total = push + squat + abs
        if (total == 0) {
            status.text = "Add some completed reps first. You can also take a rest day."
            return
        }
        val oldLevel = xp / 250 + 1
        val gained = min(100, 20 + total / 2)
        xp += gained
        val newLevel = xp / 250 + 1
        saveData()
        updateUi()
        status.text = "Session saved! +$gained XP. Great job showing up—recovery matters too."
        if (newLevel > oldLevel) {
            val newRank = rankFor(newLevel)
            rankText.animate().cancel()
            rankText.scaleX = 0.7f; rankText.scaleY = 0.7f; rankText.alpha = 0.4f
            rankText.animate().scaleX(1.25f).scaleY(1.25f).alpha(1f).setDuration(350)
                .withEndAction { rankText.animate().scaleX(1f).scaleY(1f).setDuration(180).start() }.start()
            speakSystem("System alert. Rank up. New rank $newRank. Level $newLevel.")
            Toast.makeText(this, "RANK UP!  $newRank", Toast.LENGTH_LONG).show()
        } else speakSystem("Session complete. $gained experience points earned.")
    }

    private fun updateUi() {
        val level = xp / 250 + 1
        val inLevel = xp % 250
        val rank = rankFor(level)
        levelText.text = "LEVEL $level"
        rankText.text = "RANK $rank"
        xpText.text = "$inLevel / 250 XP   •   TOTAL $xp XP"
        bar.progress = inLevel
        pushValue.text = "$push reps"
        squatValue.text = "$squat reps"
        absValue.text = "$abs reps"
        questText.text = "Today: Push-ups $push • Squats $squat • Core $abs\nA quest is complete when you finish a session you can do comfortably."
    }

    private fun rankFor(level: Int) = when {
        level >= 30 -> "S"
        level >= 20 -> "A"
        level >= 12 -> "B"
        level >= 7 -> "C"
        level >= 3 -> "D"
        else -> "E"
    }

    private fun speakSystem(message: String) {
        voice?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "level_up_voice")
    }

    override fun onDestroy() {
        voice?.stop()
        voice?.shutdown()
        voice = null
        super.onDestroy()
    }
}
