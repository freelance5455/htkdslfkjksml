LEVEL UP — Android Studio project

Includes:
- LEVEL UP launcher icon (multiple Android densities)
- Name + age first-run login, stored locally
- Push-up, squat and abs/core manual rep counters
- XP, levels and E-to-S rank progression
- Low-pitch system voice announcements and rank-up animation
- Daily rep reset and locally saved progress

Build the APK:
1. Install Android Studio on a computer.
2. Open this extracted SoloSystemAndroid folder in Android Studio.
3. Let Gradle sync complete (internet may be needed for first sync).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Camera-assisted pose rep detection is included in the web entry point at the ZIP root (index.html), not in this native Android activity. The ZIP is source code, not a compiled APK. Progress is stored locally. XP is a game mechanic, not a measure of health or fitness. Warm up, use comfortable form, take breaks and recovery days, and stop if you feel pain or unwell.
