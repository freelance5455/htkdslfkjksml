# Alcánzame Si Puedes — Mobile v1.1
Juego de carreras HTML5 empaquetado como Android WebView.

Mejoras:
- Pantalla de inicio con identidad del juego.
- Controles táctiles grandes y toque izquierda/derecha sobre la pista.
- Sonido de motor generado localmente y efectos de choque.
- Vibración al chocar.
- Interfaz adaptada a pantallas móviles.
- Ícono vectorial incluido.
- Versionado Android 1.1 / versionCode 2.

Para publicar:
1. Abrir en Android Studio.
2. Generar un Android App Bundle (AAB) firmado.
3. Crear la ficha de Google Play, capturas, clasificación de contenido y política de privacidad según las funciones incorporadas.
