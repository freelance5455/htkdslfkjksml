import os, time
from datetime import datetime, timezone
from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv
import MetaTrader5 as mt5
import pandas as pd

load_dotenv()
app = Flask(__name__)
CORS(app)
SYMBOL = os.getenv("SYMBOL", "XAUUSD")
PORT = int(os.getenv("PORT", "5000"))
ALLOW_LIVE = os.getenv("ALLOW_LIVE_TRADING", "false").lower() == "true"
ALLOW_DEMO = os.getenv("ALLOW_DEMO_ORDERS", "true").lower() == "true"
TF = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
      "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4}

def connect():
    kwargs = {}
    if os.getenv("MT5_PATH"): kwargs["path"] = os.getenv("MT5_PATH")
    login, password, server = os.getenv("MT5_LOGIN"), os.getenv("MT5_PASSWORD"), os.getenv("MT5_SERVER")
    if login and password and server:
        kwargs.update(login=int(login), password=password, server=server)
    if not mt5.initialize(**kwargs):
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")
    if not mt5.symbol_select(SYMBOL, True):
        raise RuntimeError(f"Could not select {SYMBOL}. Check broker's exact gold symbol (e.g. XAUUSD.a).")
    return True

def ensure():
    if mt5.terminal_info() is None: connect()

def get_rates(timeframe="M1", limit=300):
    ensure()
    if timeframe not in TF: raise ValueError("Unsupported timeframe")
    rates = mt5.copy_rates_from_pos(SYMBOL, TF[timeframe], 0, max(60, min(int(limit), 1000)))
    if rates is None or len(rates) < 55: raise RuntimeError(f"No candle data from MT5: {mt5.last_error()}")
    df = pd.DataFrame(rates)
    df["time"] = df["time"].astype(int)
    close = df["close"]
    df["ema9"] = close.ewm(span=9, adjust=False).mean()
    df["ema21"] = close.ewm(span=21, adjust=False).mean()
    df["ema50"] = close.ewm(span=50, adjust=False).mean()
    delta = close.diff()
    gain, loss = delta.clip(lower=0), -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/14, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/14, adjust=False).mean().replace(0, 1e-12)
    rs = avg_gain / avg_loss
    df["rsi"] = 100 - (100 / (1 + rs))
    ema12, ema26 = close.ewm(span=12, adjust=False).mean(), close.ewm(span=26, adjust=False).mean()
    df["macd"] = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
    return df

def analyze(df, tick):
    last, prev = df.iloc[-1], df.iloc[-2]
    body = abs(last.close-last.open)
    lower_wick = min(last.open,last.close)-last.low
    upper_wick = last.high-max(last.open,last.close)
    pattern = "None"
    if last.close > last.open and prev.close < prev.open and last.close >= prev.open and last.open <= prev.close: pattern="Bullish Engulfing"
    elif last.close < last.open and prev.close > prev.open and last.open >= prev.close and last.close <= prev.open: pattern="Bearish Engulfing"
    elif lower_wick > body*2 and upper_wick < max(body,1e-9): pattern="Bullish Pin Bar"
    elif upper_wick > body*2 and lower_wick < max(body,1e-9): pattern="Bearish Pin Bar"
    trend = "BULLISH" if last.ema9 > last.ema21 > last.ema50 else "BEARISH" if last.ema9 < last.ema21 < last.ema50 else "SIDEWAYS"
    buy = [last.ema9 > last.ema21, last.close > last.ema50, last.rsi > 50 and last.rsi < 70,
           last.macd > last.macd_signal, pattern in ("Bullish Engulfing","Bullish Pin Bar")]
    sell = [last.ema9 < last.ema21, last.close < last.ema50, last.rsi < 50 and last.rsi > 30,
            last.macd < last.macd_signal, pattern in ("Bearish Engulfing","Bearish Pin Bar")]
    bs, ss = sum(buy), sum(sell)
    direction = "BUY" if bs >= 4 and bs > ss else "SELL" if ss >= 4 and ss > bs else "WAIT"
    info = mt5.symbol_info(SYMBOL)
    point = info.point if info else 0.01
    entry = float(tick.ask if direction=="BUY" else tick.bid) if direction!="WAIT" else None
    sl = entry - 300*point if direction=="BUY" else entry + 300*point if direction=="SELL" else None
    tp = entry + 450*point if direction=="BUY" else entry - 450*point if direction=="SELL" else None
    reasons = f"Trend {trend}; RSI {last.rsi:.1f}; pattern {pattern}; confirmations {max(bs,ss)}/5."
    return {"direction":direction,"score":max(bs,ss),"entry":round(entry,info.digits) if entry else None,
            "stop_loss":round(sl,info.digits) if sl else None,"take_profit":round(tp,info.digits) if tp else None,
            "reason":reasons,"indicators":{"rsi":round(float(last.rsi),2),"macd":round(float(last.macd),4),
            "ema9":round(float(last.ema9),info.digits),"ema21":round(float(last.ema21),info.digits),
            "trend":trend,"pattern":pattern}}

@app.get("/api/status")
def status():
    try:
        ensure(); ti=mt5.terminal_info(); ai=mt5.account_info(); si=mt5.symbol_info(SYMBOL)
        return jsonify(connected=True,symbol=SYMBOL,digits=si.digits if si else 2,
          server_time=datetime.now(timezone.utc).isoformat(),
          account_login=ai.login if ai else None, account_server=ai.server if ai else None,
          account_trade_mode=str(ai.trade_mode) if ai else None,
          live_orders_allowed=ALLOW_LIVE, demo_orders_allowed=ALLOW_DEMO,
          terminal_connected=bool(ti.connected) if ti else False)
    except Exception as e: return jsonify(connected=False,error=str(e)),503

@app.get("/api/tick")
def tick():
    try:
        ensure(); t=mt5.symbol_info_tick(SYMBOL); si=mt5.symbol_info(SYMBOL)
        if t is None: raise RuntimeError(f"No tick: {mt5.last_error()}")
        return jsonify(bid=t.bid,ask=t.ask,last=t.last or (t.bid+t.ask)/2,
          spread_points=round((t.ask-t.bid)/si.point,1),digits=si.digits,time=t.time)
    except Exception as e: return jsonify(error=str(e)),503

@app.get("/api/candles")
def candles():
    try:
        df=get_rates(request.args.get("timeframe","M1"),request.args.get("limit",300))
        cols=["time","open","high","low","close","ema9","ema21","ema50"]
        return jsonify(symbol=SYMBOL,timeframe=request.args.get("timeframe","M1"),candles=df[cols].to_dict("records"))
    except Exception as e: return jsonify(error=str(e)),503

@app.get("/api/signal")
def signal():
    try:
        df=get_rates(request.args.get("timeframe","M1"),300); t=mt5.symbol_info_tick(SYMBOL)
        return jsonify(signal=analyze(df,t))
    except Exception as e: return jsonify(error=str(e)),503

@app.post("/api/order")
def order():
    try:
        ensure(); data=request.get_json(force=True)
        side=data.get("side"); mode=data.get("mode")
        if side not in ("BUY","SELL"): return jsonify(error="Side must be BUY or SELL"),400
        if mode not in ("demo","live"): return jsonify(error="Invalid execution mode"),400
        ai=mt5.account_info()
        if ai is None: raise RuntimeError("No MT5 account connected")
        # MT5 trade_mode: 0 demo, 1 contest, 2 real (values as exposed by MetaTrader5)
        is_demo = int(ai.trade_mode) == 0
        if mode=="demo" and (not is_demo or not ALLOW_DEMO):
            return jsonify(error="Demo order blocked: connect a demo account and set ALLOW_DEMO_ORDERS=true."),403
        if mode=="live" and (is_demo or not ALLOW_LIVE):
            return jsonify(error="Live order blocked. Real orders are disabled by default; explicitly configure ALLOW_LIVE_TRADING=true after testing."),403
        volume=float(data.get("volume",0.01)); slp=int(data.get("sl_points",300)); tpp=int(data.get("tp_points",450))
        si=mt5.symbol_info(SYMBOL); tick=mt5.symbol_info_tick(SYMBOL)
        if not si or not tick: raise RuntimeError("Symbol quote unavailable")
        if volume < si.volume_min or volume > si.volume_max: return jsonify(error=f"Volume must be between {si.volume_min} and {si.volume_max}"),400
        price=tick.ask if side=="BUY" else tick.bid
        sl=price-slp*si.point if side=="BUY" else price+slp*si.point
        tp=price+tpp*si.point if side=="BUY" else price-tpp*si.point
        req={"action":mt5.TRADE_ACTION_DEAL,"symbol":SYMBOL,"volume":volume,
             "type":mt5.ORDER_TYPE_BUY if side=="BUY" else mt5.ORDER_TYPE_SELL,
             "price":price,"sl":round(sl,si.digits),"tp":round(tp,si.digits),
             "deviation":20,"magic":6202611,"comment":"GOLD_HUNTER","type_time":mt5.ORDER_TIME_GTC,
             "type_filling":si.filling_mode}
        result=mt5.order_send(req)
        if result is None: raise RuntimeError(f"order_send failed: {mt5.last_error()}")
        ok=result.retcode in (mt5.TRADE_RETCODE_DONE,mt5.TRADE_RETCODE_PLACED)
        return jsonify(ok=ok,retcode=result.retcode,order=result.order,deal=result.deal,
                       message="Order accepted by MT5" if ok else f"Broker rejected order: {result.comment}")
    except Exception as e: return jsonify(error=str(e)),500

if __name__ == "__main__":
    try:
        connect()
        print(f"GOLD HUNTER bridge ready for {SYMBOL} on port {PORT}")
    except Exception as exc:
        print("MT5 startup warning:", exc)
        print("Start MetaTrader 5, log in, then restart this bridge.")
    app.run(host="0.0.0.0",port=PORT,debug=False)
