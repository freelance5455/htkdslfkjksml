# VPS / MT5 Bridge

This bridge is the middle layer between the Android app and the MT5 Expert Advisor.

Architecture:
Android APK -> HTTPS -> FastAPI bridge -> MT5 EA -> MT5 terminal -> broker

The included server is intentionally demo-safe: it queues START/STOP/PING/CLOSE_ALL commands but does not itself place broker orders.

## Run

On the VPS:

    python -m venv .venv
    .venv/bin/pip install -r requirements.txt
    .venv/bin/uvicorn main:app --host 0.0.0.0 --port 8080

For production, put the API behind HTTPS (for example Caddy/Nginx) and replace API_TOKEN with a long random secret. Do not put MT5 credentials in the Android app.

## Android settings

Set the Bridge URL to your HTTPS base URL, e.g. `https://your-vps.example.com`, and enter the same API token.
