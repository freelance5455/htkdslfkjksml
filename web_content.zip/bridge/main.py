from datetime import datetime, timezone
from typing import Literal, Optional
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

API_TOKEN = "CHANGE_ME_LONG_RANDOM_TOKEN"
app = FastAPI(title="Exness Gold Bot VPS Bridge", version="1.0.0")

class BotCommand(BaseModel):
    action: Literal["START", "STOP", "CLOSE_ALL", "PING"]
    symbol: str = "XAUUSD"
    risk_percent: float = Field(default=0.25, ge=0, le=5)
    daily_loss_limit: float = Field(default=1.0, ge=0, le=20)
    max_trades_per_day: int = Field(default=3, ge=0, le=50)

class MT5Status(BaseModel):
    connected: bool = False
    account: str = ""
    server: str = ""
    balance: float = 0
    equity: float = 0
    symbol: str = "XAUUSD"
    bot_running: bool = False
    last_update: str = ""

status = MT5Status(last_update=datetime.now(timezone.utc).isoformat())
pending_command: Optional[BotCommand] = None

def auth(token: str | None):
    if token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid API token")

@app.get("/health")
def health():
    return {"ok": True, "service": "mt5-bridge", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/status")
def get_status(x_api_token: str | None = Header(default=None)):
    auth(x_api_token)
    return status

@app.post("/command")
def command(cmd: BotCommand, x_api_token: str | None = Header(default=None)):
    global pending_command
    auth(x_api_token)
    pending_command = cmd
    return {"accepted": True, "action": cmd.action}

@app.get("/command/next")
def next_command(x_api_token: str | None = Header(default=None)):
    global pending_command
    auth(x_api_token)
    cmd = pending_command
    pending_command = None
    return {"command": cmd.model_dump() if cmd else None}

@app.post("/mt5/status")
def update_status(new_status: MT5Status, x_api_token: str | None = Header(default=None)):
    global status
    auth(x_api_token)
    new_status.last_update = datetime.now(timezone.utc).isoformat()
    status = new_status
    return {"ok": True}
