# SAMI TRADER MT5 DEMO BRIDGE
# Windows/VPS: install MetaTrader 5 desktop terminal and log into your EXNESS DEMO account.
# Python: py -m pip install MetaTrader5 fastapi uvicorn
# Run: py -m uvicorn mt5_bridge:app --host 127.0.0.1 --port 8000
import MetaTrader5 as mt5
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

app=FastAPI(title="SAMI TRADER MT5 DEMO BRIDGE")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class Login(BaseModel):
    login:int
    password:str
    server:str

class Order(BaseModel):
    symbol:str
    side:str
    volume:float=0.01
    sl:Optional[float]=None
    tp:Optional[float]=None

def ensure():
    if mt5.terminal_info() is None:
        if not mt5.initialize():
            raise RuntimeError(str(mt5.last_error()))

@app.post("/connect")
def connect(x:Login):
    if not mt5.initialize(login=x.login,password=x.password,server=x.server):
        return {"connected":False,"error":str(mt5.last_error())}
    info=mt5.account_info()
    if info is None:
        return {"connected":False,"error":str(mt5.last_error())}
    return {"connected":True,"login":info.login,"server":x.server,"balance":info.balance,"equity":info.equity}

@app.get("/quote/{symbol}")
def quote(symbol:str):
    ensure()
    if not mt5.symbol_select(symbol,True):
        return {"error":"Symbol unavailable: "+symbol}
    t=mt5.symbol_info_tick(symbol)
    if t is None: return {"error":"No quote"}
    return {"symbol":symbol,"bid":t.bid,"ask":t.ask,"time":t.time}

@app.get("/positions")
def positions():
    ensure()
    ps=mt5.positions_get()
    return {"positions":[p._asdict() for p in ps] if ps else []}

@app.post("/order")
def order(x:Order):
    ensure()
    if x.side not in ("BUY","SELL"): return {"success":False,"error":"Invalid side"}
    info=mt5.symbol_info(x.symbol)
    tick=mt5.symbol_info_tick(x.symbol)
    if info is None or tick is None: return {"success":False,"error":"Symbol unavailable"}
    price=tick.ask if x.side=="BUY" else tick.bid
    typ=mt5.ORDER_TYPE_BUY if x.side=="BUY" else mt5.ORDER_TYPE_SELL
    req={"action":mt5.TRADE_ACTION_DEAL,"symbol":x.symbol,"volume":x.volume,"type":typ,
         "price":price,"deviation":20,"magic":260923,"comment":"SAMI TRADER DEMO",
         "type_time":mt5.ORDER_TIME_GTC,"type_filling":mt5.ORDER_FILLING_IOC}
    if x.sl is not None: req["sl"]=x.sl
    if x.tp is not None: req["tp"]=x.tp
    result=mt5.order_send(req)
    if result is None: return {"success":False,"error":str(mt5.last_error())}
    return {"success":result.retcode==mt5.TRADE_RETCODE_DONE,"retcode":result.retcode,
            "order":result.order,"deal":result.deal,"error":result.comment}

@app.post("/close/{ticket}")
def close(ticket:int):
    ensure()
    ps=mt5.positions_get(ticket=ticket)
    if not ps: return {"success":False,"error":"Position not found"}
    p=ps[0]; tick=mt5.symbol_info_tick(p.symbol)
    typ=mt5.ORDER_TYPE_SELL if p.type==mt5.POSITION_TYPE_BUY else mt5.ORDER_TYPE_BUY
    price=tick.bid if p.type==mt5.POSITION_TYPE_BUY else tick.ask
    req={"action":mt5.TRADE_ACTION_DEAL,"symbol":p.symbol,"volume":p.volume,"type":typ,
         "position":p.ticket,"price":price,"deviation":20,"magic":260923,
         "comment":"SAMI TRADER DEMO CLOSE","type_time":mt5.ORDER_TIME_GTC,"type_filling":mt5.ORDER_FILLING_IOC}
    result=mt5.order_send(req)
    return {"success":bool(result and result.retcode==mt5.TRADE_RETCODE_DONE),
            "retcode":result.retcode if result else None,"error":result.comment if result else str(mt5.last_error())}

@app.get("/health")
def health():
    return {"ok":True,"mt5_terminal":mt5.terminal_info() is not None}
