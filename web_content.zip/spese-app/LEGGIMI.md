# Le mie spese: come installarla sul telefono Android

L'app è una PWA: una pagina web che si installa come app, ha la sua icona e funziona anche senza internet.
I dati restano **solo sul telefono** (non vanno su nessun server).

## Metodo 1: installazione diretta (consigliato, nessun APK)

1. Carica questa cartella su un hosting gratuito con HTTPS, per esempio:
   - **Netlify Drop** (app.netlify.com/drop): trascini la cartella e ottieni un indirizzo web;
   - oppure **GitHub Pages**.
2. Sul telefono apri l'indirizzo con **Chrome**.
3. Menu ⋮ → **Installa app** (o "Aggiungi a schermata Home").
4. Compare l'icona "Spese" tra le tue app. Si apre a schermo intero e funziona offline.

## Metodo 2: file .apk vero e proprio

Serve l'indirizzo web del Metodo 1.

1. Vai su **pwabuilder.com**, incolla l'indirizzo e premi *Start*.
2. Scegli **Android** → *Download package*.
3. Nello zip trovi l'`.apk`: copialo sul telefono e aprilo
   (va abilitata l'installazione da "origini sconosciute").

## Backup dei dati

Impostazioni (⚙) → **Esporta backup (JSON)**: il telefono ti propone dove salvarlo (Drive, File, WhatsApp...).
Per ripristinare o cambiare telefono: **Importa backup**.
**Esporta in CSV** crea un file apribile con Excel.
Un'app installata sul telefono può perdere i dati se cancelli i dati di Chrome o disinstalli l'app: fai un backup ogni tanto.

## Contenuto della cartella

- `index.html`: l'app (tutta la logica e la grafica)
- `manifest.webmanifest`, `sw.js`, `icon*.png/svg`: rendono l'app installabile e utilizzabile offline
