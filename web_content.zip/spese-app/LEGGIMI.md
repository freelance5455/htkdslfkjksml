# Le mie spese: come installarla sul telefono Android

L'app è una PWA: una pagina web che si installa come app, ha la sua icona e funziona anche senza internet.
I dati restano **solo sul telefono** (non vanno su nessun server).

## Metodo 1: installazione diretta (consigliato, nessun APK)

1. Carica questa cartella su un hosting gratuito con HTTPS, per esempio:
   - **Netlify Drop** (app.netlify.com/drop): trascini la cartella e ottieni un indirizzo web;
   - oppure **GitHub Pages**.
2. Sul telefono apri l'indirizzo con **Chrome**.
3. Menu ⋮ → **Installa app** (o "Aggiungi a schermata Home").
4. Compare l'icona "Spese" tra le tue app. Si apre a schermo intero e funziona offline.

## Metodo 2: file .apk vero e proprio

Serve l'indirizzo web del Metodo 1.

1. Vai su **pwabuilder.com**, incolla l'indirizzo e premi *Start*.
2. Scegli **Android** → *Download package*.
3. Nello zip trovi l'`.apk`: copialo sul telefono e aprilo
   (va abilitata l'installazione da "origini sconosciute").

## Backup e trasferimento dei dati (per gli aggiornamenti)

Prima di installare una nuova versione dell'app (o cambiare telefono) apri ⚙ → **Backup e trasferimento dati**.

1. **Esporta:** premi **Copia i dati** (oppure **Salva / condividi file**). Con "Copia i dati" il testo finisce negli appunti: incollalo dove vuoi tenerlo (per esempio una nota o un messaggio a te stesso).
2. Installa la nuova versione.
3. **Importa:** apri di nuovo **Backup e trasferimento dati**, incolla il testo nel riquadro (oppure scegli il file) e premi **Sostituisci tutto**.
   **Unisci ai dati attuali** aggiunge solo i movimenti che mancano, senza duplicati.

Se non fai un backup da più di 30 giorni compare un promemoria in alto.
**Esporta in CSV** (nelle impostazioni) crea un file apribile con Excel.
Un'app installata sul telefono può perdere i dati se disinstalli l'app o cancelli i dati di Chrome: fai un backup ogni tanto.

## Contenuto della cartella

- `index.html`: l'app (tutta la logica e la grafica)
- `manifest.webmanifest`, `sw.js`, `icon*.png/svg`: rendono l'app installabile e utilizzabile offline
