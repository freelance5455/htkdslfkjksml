极简热量记 - Android APK 工程
================================

这个工程把原来的单文件 HTML 完整放进 Android WebView 中运行。
应用离线可用，不需要服务器；HTML 里的 localStorage 会保存在 Android WebView 的应用数据中。

【最简单的 APK 生成方式：Android Studio】
1. 在 Windows 安装最新版 Android Studio。
2. Android Studio -> SDK Manager：确保已安装 Android SDK Platform 35。
3. 选择 Open，打开本文件所在的 calorie_tracker_android 文件夹。
4. 等 Gradle Sync 完成。
5. 菜单 Build -> Build App Bundle(s) / APK(s) -> Build APK(s)。
6. APK 默认在：
   app\build\outputs\apk\debug\app-debug.apk

【一键脚本方式】
如果已经安装 Android Studio / Android SDK：
1. 在工程目录空白处 Shift + 右键 -> 在终端中打开；
2. 执行：
   powershell -ExecutionPolicy Bypass -File .\build_apk_windows.ps1
3. 完成后工程根目录会出现：极简热量记-debug.apk

注意：
- 第一次构建需要联网下载 Gradle 和 Android Gradle Plugin。
- Debug APK 可以直接侧载安装，用于你自己手机使用。
- 如果以后要长期发布/升级，建议在 Android Studio 中创建正式签名的 Release APK。
- 卸载应用或在系统设置里“清除存储/清除数据”会删除 localStorage 中的饮食、体重和自定义食物记录。
