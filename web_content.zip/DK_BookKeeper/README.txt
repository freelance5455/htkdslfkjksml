DK BOOKKEEPER — FINAL SEARCH + VOICE BUILD

- Expense, Income, Contra and Journal voucher entry.
- Independent live account search on both account fields.
- Expense: Paid To / Paid From.
- Income: Received Into / Received From.
- Contra: To Account / From Account.
- Journal: Debit / Credit.
- Search matches account names and account groups. Select an item from the suggestion list; arbitrary text is not accepted.
- Voice command entry retained (English Pakistan, Urdu Pakistan, English US). Review recognized details before saving.
- Excel exports follow the supplied BookKeeper template column layout and date format.
- Local browser storage; back up data regularly.
- Speech recognition and Excel export library may require internet. Native Android WebView speech recognition may require a native Android bridge.
- Import exported vouchers into the correct company and test with a few sample transactions first.
