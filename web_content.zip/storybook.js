(() => {
  const byId = (id) => document.getElementById(id);
  const setup = byId('storySetup');
  const book = byId('storybook');
  const loading = byId('storyLoading');
  const status = byId('storyLoadingText');
  const errorBox = byId('storyError');
  const storageKey = 'scoredeck_ai_server_base';
  let apiBase = localStorage.getItem(storageKey) || (location.protocol === 'file:' ? '' : location.origin);
  let story = null;
  let busy = false;
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);

  const settings = document.createElement('details');
  settings.className = 'card story-panel';
  settings.innerHTML = `<summary style="cursor:pointer;font-weight:750">⚙ Connect your Study AI server</summary><p class="tutor-hint" style="margin:8px 0">Enter your deployed HTTPS server address. Keep the OpenAI API key on that server.</p><div class="story-start-row"><input id="storyServerUrl" class="input" type="url" placeholder="https://your-scoredeck-server.example" style="flex:1;min-width:210px" aria-label="Story server URL"><button type="button" id="storySaveServer">Save server</button></div>`;
  setup.after(settings);
  byId('storyServerUrl').value = apiBase;
  byId('storySaveServer').addEventListener('click', () => {
    const value = byId('storyServerUrl').value.trim().replace(/\/$/, '');
    if (!value) { apiBase = ''; localStorage.removeItem(storageKey); showError('Add your Study AI server URL before starting.'); return; }
    try { const url = new URL(value); if (!['https:', 'http:'].includes(url.protocol)) throw new Error(); }
    catch { showError('Enter a valid http or https server URL.'); return; }
    apiBase = value;
    localStorage.setItem(storageKey, value);
    errorBox.classList.add('story-hide');
    settings.open = false;
  });
  settings.addEventListener('toggle', () => {
    if (settings.open) byId('storyServerUrl').value = localStorage.getItem(storageKey) || apiBase;
  });

  document.querySelectorAll('[data-story-idea]').forEach((button) => button.addEventListener('click', () => {
    const [character, setting] = button.dataset.storyIdea.split('|');
    byId('storyCharacter').value = character;
    byId('storySetting').value = setting;
    byId('storyCharacter').focus();
  }));

  function showError(message) { errorBox.textContent = message; errorBox.classList.remove('story-hide'); }

  async function requestPage(payload) {
    apiBase = localStorage.getItem(storageKey) || (location.protocol === 'file:' ? '' : location.origin);
    if (!apiBase) { settings.open = true; showError('Connect your Study AI server to begin. For Android, enter the HTTPS URL of your deployed server.'); return null; }
    errorBox.classList.add('story-hide');
    loading.classList.remove('story-hide');
    status.textContent = payload.mode === 'start' ? 'Writing and illustrating your first page…' : 'Writing and illustrating what happens next…';
    busy = true;
    document.querySelectorAll('#storyStartForm button, #storybook button').forEach((button) => { button.disabled = true; });
    try {
      const response = await fetch(`${apiBase}/api/study-ai/story`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Story server returned ${response.status}.`);
      return data;
    } catch (error) {
      showError(error instanceof TypeError ? 'Could not reach the Study AI server. Check the saved HTTPS URL and server status.' : error.message);
      return null;
    } finally {
      busy = false;
      loading.classList.add('story-hide');
      document.querySelectorAll('#storyStartForm button, #storybook button').forEach((button) => { button.disabled = false; });
    }
  }

  function renderBook() {
    if (!story) return;
    const pages = story.scenes.map((scene, index) => `<article class="card story-panel"><div class="story-page-no">Page ${index + 1} · ${esc(scene.title)}</div><div class="story-stage"><div class="story-art"><img src="${scene.image}" alt="Illustration for ${esc(scene.title)}" loading="${index === story.scenes.length - 1 ? 'eager' : 'lazy'}"></div><div><h3 class="story-title">${esc(scene.title)}</h3><div class="story-copy">${esc(scene.text)}</div></div></div></article>`).join('');
    const limitReached = story.scenes.length >= 8;
    const latest = story.scenes.at(-1);
    const next = limitReached ? '<p class="tutor-hint">This little book is complete. Start a new adventure whenever you’re ready.</p>'
      : `<div class="story-page-no">What happens next?</div><div class="story-choices">${latest.choices.map((choice, i) => `<button class="story-choice" data-story-choice="${esc(choice)}"><b>${i + 1}</b><span>${esc(choice)}</span></button>`).join('')}</div><div class="story-write"><label for="storyOwnIdea">Or write your own idea</label><textarea id="storyOwnIdea" maxlength="500" placeholder="I want the fox to follow the tiny silver footprints…"></textarea><div class="story-actions"><button class="primary" id="storyOwnIdeaButton">Continue with my idea</button><button id="storyRestartButton">↻ Start a new story</button></div></div>`;
    book.innerHTML = `<div class="tutor-hint" style="margin:5px 2px">${story.scenes.length} illustrated page${story.scenes.length === 1 ? '' : 's'}</div>${pages}<div class="card story-panel">${next}${limitReached ? '<div class="story-actions"><button class="primary" id="storyRestartButton">↻ Start a new story</button></div>' : ''}</div>`;
    book.classList.remove('story-hide');
    book.querySelectorAll('[data-story-choice]').forEach((button) => button.addEventListener('click', () => continueStory(button.dataset.storyChoice)));
    const ownButton = byId('storyOwnIdeaButton');
    if (ownButton) ownButton.addEventListener('click', () => {
      const idea = byId('storyOwnIdea').value.trim();
      if (!idea) { byId('storyOwnIdea').focus(); return; }
      continueStory(idea);
    });
    const restartButton = byId('storyRestartButton');
    if (restartButton) restartButton.addEventListener('click', restartStory);
  }

  async function continueStory(choice) {
    if (busy || !story || story.scenes.length >= 8) return;
    const latest = story.scenes.at(-1);
    latest.choice = choice;
    const data = await requestPage({
      mode: 'continue', character: story.character, setting: story.setting,
      history: story.scenes.map(({ title, text, choice: selected }) => ({ title, text, choice: selected || '' })),
      previousImage: latest.image, choice
    });
    if (!data) { latest.choice = ''; return; }
    story.scenes.push({ ...data.scene, image: `data:image/png;base64,${data.image}` });
    renderBook();
    book.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function startStory(event) {
    event.preventDefault();
    if (busy) return;
    const character = byId('storyCharacter').value.trim();
    const setting = byId('storySetting').value.trim();
    if (!character || !setting) return;
    const data = await requestPage({ mode: 'start', character, setting });
    if (!data) return;
    story = { character, setting, scenes: [{ ...data.scene, image: `data:image/png;base64,${data.image}` }] };
    setup.classList.add('story-hide');
    settings.classList.add('story-hide');
    renderBook();
    book.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function restartStory() {
    story = null;
    book.innerHTML = '';
    book.classList.add('story-hide');
    setup.classList.remove('story-hide');
    settings.classList.remove('story-hide');
    errorBox.classList.add('story-hide');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  byId('storyStartForm').addEventListener('submit', startStory);
})();
