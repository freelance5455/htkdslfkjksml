# FITTRACK MVP

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run `python -m http.server 8000`
4. Open `http://localhost:8000` in your browser.

For Android installation, deploy the folder to an HTTPS host (for example, GitHub Pages or another static host), open the URL in Chrome, then choose **Install app** / **Add to Home screen**. Service workers and PWA installation generally require HTTPS or localhost.

## Included
- Workout logging with exercises, sets and reps
- Push-up and pull-up daily counters
- Daily/weekly progress charts
- Start/pause/reset rest timer
- Offline, rule-based safe workout suggestions
- Exercise tutorial search links
- Workout history, delete and JSON export
- Local profile
- Local storage and service-worker offline shell
- PWA manifest and app icons

## Privacy and limitations
All workout/profile data is stored in this browser's `localStorage`; it is not sent to a server. This is local storage, not encrypted storage. Anyone who can use the same browser profile/device may access it. Clearing browser data can remove it, so use Export my data for a backup.

The suggestions are offline rules, not a connected AI model. Do not put secret API keys in frontend JavaScript. A real AI feature needs a backend that keeps credentials server-side and validates age-appropriate prompts/responses.

This MVP does not include cloud sync, accounts, push notifications, or native Android packaging. It is a responsive installable PWA.
