import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, collection, query, orderBy, limit, getDocs, serverTimestamp, where } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const cfg=window.ECO_FIREBASE_CONFIG||{};
const configured=!!(cfg.apiKey && !String(cfg.apiKey).startsWith("COLOQUE") && cfg.projectId && !String(cfg.projectId).startsWith("SEU_") && cfg.appId && !String(cfg.appId).startsWith("SEU_"));
let auth=null,db=null,user=null;
window.ecoOnline={configured:false,connected:false,saveCloud:async()=>false,syncCloud:async()=>false,loadRanking:async()=>[]};
const el=id=>document.getElementById(id);
function status(text,ok=false){if(el("onlineStatus")){el("onlineStatus").textContent=text;el("onlineStatus").style.color=ok?"#69edaa":"";}if(el("onlineMessage"))el("onlineMessage").textContent=text;}
function safeName(){return (el("onlineName")?.value||localStorage.getItem("ecoOnlineName")||"Jogador Eco").trim().slice(0,18)||"Jogador Eco";}
async function setup(){
 if(!configured){status("CONFIGURAÇÃO PENDENTE");return;}
 try{
  const app=initializeApp(cfg);auth=getAuth(app);db=getFirestore(app);window.ecoOnline.configured=true;
  onAuthStateChanged(auth,async u=>{user=u||null;window.ecoOnline.connected=!!u;if(u){status("ONLINE",true);await loadCloud();await loadRanking();}});
 }catch(e){console.error(e);status("ERRO AO INICIAR ONLINE");}
}
async function connectOnline(){
 if(!configured){status("Configure firebase-config.js primeiro");return;}
 try{localStorage.setItem("ecoOnlineName",safeName());status("Conectando...");await signInAnonymously(auth);}
 catch(e){console.error(e);status("Não foi possível conectar. Verifique Firebase e internet.");}
}
async function saveCloud(){
 if(!user||!db||!window.state)return false;
 try{
  const name=safeName();localStorage.setItem("ecoOnlineName",name);
  const payload={name,score:Number(window.state.score)||0,stars:Number(window.state.stars)||0,coins:Number(window.state.coins)||0,level:Number(window.state.level)||1,wins:Number(window.state.wins)||0,trophies:Number(window.state.trophies)||0,friendCode:window.ensureFriendCode?window.ensureFriendCode():"",friends:Array.isArray(window.state.friends)?window.state.friends:[],updatedAt:serverTimestamp()};
  await setDoc(doc(db,"users",user.uid),{...payload,state:window.state,schemaVersion:2},{merge:true});
  await setDoc(doc(db,"leaderboard",user.uid),payload,{merge:true});
  status("ONLINE • salvo na nuvem",true);return true;
 }catch(e){console.error(e);status("Falha ao salvar online");return false;}
}
async function loadCloud(){
 if(!user||!db)return false;
 try{
  const snap=await getDoc(doc(db,"users",user.uid));if(!snap.exists())return false;
  const data=snap.data();
  if(data.state&&window.replaceStateFromCloud){window.replaceStateFromCloud(data.state);}
  if(data.name&&el("onlineName"))el("onlineName").value=data.name;
  if(data.friendCode&&window.state)window.state.friendCode=String(data.friendCode);
  if(Array.isArray(data.friends)&&window.state){window.state.friends=data.friends;localStorage.setItem("ecoColetaV2",JSON.stringify(window.state));localStorage.setItem("ecoColetaV2_backup",JSON.stringify(window.state));}
  if(window.renderFriends)window.renderFriends();
  status("ONLINE • progresso sincronizado",true);return true;
 }catch(e){console.error(e);status("Falha ao sincronizar");return false;}
}
async function loadRanking(){
 if(!db||!user)return [];
 try{
  const q=query(collection(db,"leaderboard"),orderBy("score","desc"),limit(20));const snap=await getDocs(q);const rows=[];snap.forEach(d=>rows.push({id:d.id,...d.data()}));
  const box=el("leaderboardList");if(box)box.innerHTML=rows.length?rows.map((r,i)=>`<div class="row"><div class="ico">${i<3?["🥇","🥈","🥉"][i]:"🏅"}</div><div style="flex:1"><b>${escapeHtml(r.name||"Jogador Eco")}</b><div class="small">Nível ${Number(r.level)||1} • ${Number(r.wins)||0} vitórias</div></div><b>⭐ ${Number(r.stars)||0}</b></div>`).join(""):"<div class='small'>Ainda não há jogadores no ranking.</div>";
  return rows;
 }catch(e){console.error(e);if(el("leaderboardList"))el("leaderboardList").innerHTML="<div class='small'>Não foi possível carregar o ranking.</div>";return [];}
}

async function addFriendByCode(code){
 if(!user||!db)return false;
 try{
  const q=query(collection(db,"users"),where("friendCode","==",code));const snap=await getDocs(q);
  if(snap.empty)return false;
  const d=snap.docs[0];if(d.id===user.uid)return false;const data=d.data();
  const friend={code,name:String(data.name||"Amigo Eco").slice(0,18),online:false,uid:d.id,addedAt:Date.now()};
  const current=Array.isArray(window.state?.friends)?window.state.friends:[];
  if(current.some(f=>f.code===code))return true;
  current.push(friend);window.state.friends=current;localStorage.setItem("ecoColetaV2",JSON.stringify(window.state));localStorage.setItem("ecoColetaV2_backup",JSON.stringify(window.state));
  await setDoc(doc(db,"users",user.uid),{friends:current,updatedAt:serverTimestamp()},{merge:true});
  if(window.renderFriends)window.renderFriends();
  return true;
 }catch(e){console.error(e);return false;}
}
async function removeFriend(code){
 if(!user||!db)return false;
 try{const current=(Array.isArray(window.state?.friends)?window.state.friends:[]).filter(f=>f.code!==code);window.state.friends=current;await setDoc(doc(db,"users",user.uid),{friends:current,updatedAt:serverTimestamp()},{merge:true});return true;}catch(e){console.error(e);return false;}
}
async function loadFriends(){
 if(!user||!db)return false;
 try{const snap=await getDoc(doc(db,"users",user.uid));if(!snap.exists())return false;const data=snap.data();if(Array.isArray(data.friends)&&window.state){window.state.friends=data.friends;localStorage.setItem("ecoColetaV2",JSON.stringify(window.state));localStorage.setItem("ecoColetaV2_backup",JSON.stringify(window.state));if(window.renderFriends)window.renderFriends();}return true;}catch(e){console.error(e);return false;}
}
function escapeHtml(v){return String(v).replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));}
window.connectOnline=connectOnline;window.syncOnlineNow=async()=>{if(!user)return connectOnline();await saveCloud();await loadRanking();};
window.ecoOnline.saveCloud=saveCloud;window.ecoOnline.syncCloud=async()=>{await loadCloud();await loadFriends();await loadRanking();return true;};window.ecoOnline.loadRanking=loadRanking;window.ecoOnline.addFriendByCode=addFriendByCode;window.ecoOnline.removeFriend=removeFriend;window.ecoOnline.loadFriends=loadFriends;
setup();
