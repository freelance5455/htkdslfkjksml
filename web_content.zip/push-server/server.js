'use strict';
const express = require('express');
const webpush = require('web-push');
const app = express();
app.use(express.json({ limit: '128kb' }));
const PORT = Number(process.env.PORT || 8787);
const PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const SUBJECT = process.env.VAPID_SUBJECT || 'mailto:admin@example.com';
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
if (!PUBLIC_KEY || !PRIVATE_KEY || !ADMIN_TOKEN) {
  console.error('Missing VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, or ADMIN_TOKEN. See README.md.');
  process.exit(1);
}
webpush.setVapidDetails(SUBJECT, PUBLIC_KEY, PRIVATE_KEY);
// Starter storage only: subscriptions are lost when this process restarts. Use a database for production.
const subscriptions = new Map();
app.get('/health', (_req, res) => res.json({ ok: true, service: 'AlarmSimulator Web Push', subscriptions: subscriptions.size }));
app.post('/api/subscribe', (req, res) => {
  const { subscription, locations } = req.body || {};
  if (!subscription?.endpoint || !Array.isArray(locations)) return res.status(400).json({ error: 'subscription and locations are required' });
  subscriptions.set(subscription.endpoint, { subscription, locations: locations.filter(x => x && typeof x.region === 'string').map(x => ({ region: x.region, district: x.district || '' })) });
  res.status(201).json({ ok: true });
});
function matches(target, location) {
  const [region, rawDistrict] = String(target).split(' / ');
  if (region !== location.region) return false;
  if (!rawDistrict) return true;
  const district = rawDistrict.replace(/\s*район$/i, '');
  return !location.district || location.district === district;
}
app.post('/api/send', async (req, res) => {
  if (req.get('authorization') !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({ error: 'unauthorized' });
  const { title, body, regions, tag } = req.body || {};
  if (typeof title !== 'string' || typeof body !== 'string' || !Array.isArray(regions) || !regions.length) return res.status(400).json({ error: 'title, body, and regions[] are required' });
  const payload = JSON.stringify({ title, body, tag: tag || `alarm-${Date.now()}`, url: './index.html' });
  let sent = 0, removed = 0, failed = 0;
  await Promise.all([...subscriptions.entries()].map(async ([endpoint, entry]) => {
    if (!entry.locations.some(loc => regions.some(target => matches(target, loc)))) return;
    try { await webpush.sendNotification(entry.subscription, payload); sent++; }
    catch (e) { if (e.statusCode === 404 || e.statusCode === 410) { subscriptions.delete(endpoint); removed++; } else { failed++; console.error('Push delivery failed:', e.statusCode || e.message); } }
  }));
  res.json({ ok: true, sent, removed, failed });
});
app.listen(PORT, () => console.log(`AlarmSimulator push server listening on ${PORT}`));
