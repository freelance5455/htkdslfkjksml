# KINGLDZ Mavi Toolbox
Web app personal para SPCK Editor.

Incluye:
- Bloc de notas con guardado local.
- Títulos, edición enriquecida, colores, resaltado, tamaños, fuentes, negrita, cursiva, subrayado, tachado, alineación y listas.
- Nueva nota, cargar, eliminar y contador.
- Generador de contraseñas con longitud, minúsculas, mayúsculas, números y símbolos.
- Copiar y regenerar.
- About del creador con iconos locales editables.

Los datos de notas se guardan en localStorage del navegador. No se suben a un servidor.


## v5 — Te amo Rous
