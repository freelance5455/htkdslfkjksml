const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
let notes=JSON.parse(localStorage.getItem("kingldz_notes")||"[]"),current=-1,totalMB=0;

function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderNotes(){
  const box=$("#noteList");
  box.innerHTML=notes.length?notes.map((n,i)=>`<div class="note-item" data-i="${i}" role="button" tabindex="0"><span class="note-name"><svg class="mi" aria-hidden="true"><use href="#i-edit-note"></use></svg><span>${escapeHtml(n.title||"Sin título")}</span></span><small>${new Date(n.updated).toLocaleString()}</small></div>`).join(""):`<div class="empty-notes"><svg class="mi" aria-hidden="true"><use href="#i-edit-note"></use></svg><p>No hay notas guardadas.</p><small>Crea tu primera nota para empezar.</small></div>`;
  $$(".note-item").forEach(x=>{
    const open=()=>loadNote(+x.dataset.i);
    x.onclick=open;
    x.onkeydown=e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}}
  });
}
function saveNotes(){localStorage.setItem("kingldz_notes",JSON.stringify(notes));renderNotes()}
function showNotesList(){
  $("#notesHome").classList.remove("hidden");
  $("#noteEditorScreen").classList.add("hidden");
}
function showNoteEditor(){
  $("#notesHome").classList.add("hidden");
  $("#noteEditorScreen").classList.remove("hidden");
  $("#noteTitle").focus();
}
function loadNote(i){
  current=i;
  $("#noteTitle").value=notes[i].title||"";
  $("#editor").innerHTML=notes[i].html||"";
  updateCount();
  showNoteEditor();
}
function createNote(){
  current=-1;
  $("#noteTitle").value="";
  $("#editor").innerHTML="";
  updateCount();
  showNoteEditor();
  $("#editor").focus();
}
$("#saveNote").onclick=()=>{
  const n={title:$("#noteTitle").value.trim()||"Sin título",html:$("#editor").innerHTML,updated:Date.now()};
  if(current<0){notes.unshift(n);current=0}else notes[current]=n;
  saveNotes();
};
$("#createNote").onclick=createNote;
$("#newNote")?.addEventListener("click",createNote);
$("#backToNotes").onclick=showNotesList;

$("#deleteNote").onclick=()=>{
  if(current>=0) $("#deleteConfirm").classList.remove("hidden");
};
$("#cancelDelete").onclick=()=>$("#deleteConfirm").classList.add("hidden");
$("#deleteConfirm").onclick=e=>{if(e.target.id==="deleteConfirm")$("#deleteConfirm").classList.add("hidden")};
$("#confirmDelete").onclick=()=>{
  if(current<0)return;
  notes.splice(current,1);
  current=-1;
  saveNotes();
  $("#deleteConfirm").classList.add("hidden");
  showNotesList();
};
function updateCount(){let t=$("#editor").innerText||"";$("#count").textContent=`${t.trim()?t.trim().split(/\s+/).length:0} palabras · ${t.length} caracteres`}
$("#editor").oninput=updateCount;
$$(".formatbar [data-cmd]").forEach(b=>b.onclick=()=>{document.execCommand(b.dataset.cmd,false,null);$("#editor").focus()});
$("#fontName").onchange=e=>{document.execCommand("fontName",false,e.target.value);$("#editor").focus()};
$("#fontSize").onchange=e=>{document.execCommand("fontSize",false,e.target.value);$("#editor").focus()};
$("#textColor").oninput=e=>{document.execCommand("foreColor",false,e.target.value);$("#editor").focus()};
$("#highlight").oninput=e=>{document.execCommand("hiliteColor",false,e.target.value);$("#editor").focus()};

function showScreen(id){
  $$(".screen").forEach(s=>s.classList.remove("active"));
  $("#"+id).classList.add("active");
  if(id==="notes") showNotesList();
  window.scrollTo({top:0,behavior:"smooth"});
  history.replaceState(null,"","#"+id)
}
$$("[data-open]").forEach(b=>b.onclick=()=>showScreen(b.dataset.open));
$$("[data-home]").forEach(b=>b.onclick=()=>showScreen("home"));
window.addEventListener("popstate",()=>showScreen(location.hash.slice(1)||"home"));

function secureRandom(max){const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%max}
function generate(){let sets=[];if($("#lower").checked)sets.push("abcdefghijklmnopqrstuvwxyz");if($("#upper").checked)sets.push("ABCDEFGHIJKLMNOPQRSTUVWXYZ");if($("#numbers").checked)sets.push("0123456789");if($("#symbols").checked)sets.push("!@#$%^&*()-_=+[]{};:,.?");if(!sets.length){$("#password").value="Selecciona al menos un tipo";return}let all=sets.join(""),len=+$("#length").value,out=sets.map(s=>s[secureRandom(s.length)]);while(out.length<len)out.push(all[secureRandom(all.length)]);for(let i=out.length-1;i>0;i--){let j=secureRandom(i+1);[out[i],out[j]]=[out[j],out[i]]}$("#password").value=out.join("");$("#strength").textContent=`${len} caracteres · ${sets.length} tipos seleccionados`}
$("#generate").onclick=generate;$("#regen").onclick=generate;$("#length").oninput=e=>{$("#lenValue").textContent=e.target.value;generate()};
$("#copyPass").onclick=async()=>{try{await navigator.clipboard.writeText($("#password").value);$("#copyPass").innerHTML='<span class="mi" aria-hidden="true"><use href="#i-copy"></use></span> Copiado';setTimeout(()=>$("#copyPass").innerHTML='<span class="mi" aria-hidden="true"><use href="#i-copy"></use></span> Copiar',1100)}catch{alert("No se pudo copiar automáticamente.")}};

function clamp(v){return Math.max(0,Math.min(255,Number(v)||0))}
function hexToRgba(h){h=h.trim().replace("#","");if(h.length===3)h=h.split("").map(x=>x+x).join("");if(h.length===6)h="ff"+h;if(h.length!==8||!/^[0-9a-fA-F]{8}$/.test(h))return null;let n=parseInt(h,16);return{a:(n>>>24)&255,r:(n>>>16)&255,g:(n>>>8)&255,b:n&255}}
function hex8(a,r,g,b){return "#"+[a,r,g,b].map(x=>clamp(x).toString(16).padStart(2,"0")).join("")}
function updateHexPreview(){let raw=$("#hexColor").value.trim();let x=hexToRgba(raw);if(x){let color=`rgba(${x.r},${x.g},${x.b},${x.a/255})`;$("#hexPreview").style.background=color;$("#hexPreviewLabel").textContent=raw.startsWith("#")?raw.toUpperCase():"#"+raw.toUpperCase()}else{$("#hexPreview").style.background="transparent";$("#hexPreviewLabel").textContent="HEX inválido"}}
$("#hexColor").oninput=updateHexPreview;
$("#convertHex").onclick=()=>{let x=hexToRgba($("#hexColor").value);if(!x){$("#rgbResult").textContent="HEX inválido";$("#argbResult").textContent="—";return}$("#rgbResult").textContent=`rgb(${x.r}, ${x.g}, ${x.b})`;$("#argbResult").textContent=`argb(${x.a}, ${x.r}, ${x.g}, ${x.b})`};
function updateRgbPreview(){let r=clamp($("#r").value),g=clamp($("#g").value),b=clamp($("#b").value),a=clamp($("#a").value);$("#rgbPreview").style.background=`rgba(${r},${g},${b},${a/255})`;$("#rgbPreviewLabel").textContent=`rgba(${r}, ${g}, ${b}, ${(a/255).toFixed(2)})`}
["#r","#g","#b","#a"].forEach(s=>$(s).oninput=updateRgbPreview);
$("#convertRgb").onclick=()=>{let r=clamp($("#r").value),g=clamp($("#g").value),b=clamp($("#b").value),a=clamp($("#a").value);$("#hexResult").textContent=hex8(255,r,g,b);$("#argbFromRgb").textContent=hex8(a,r,g,b)};
function updateData(){const units={KB:1,MB:1024,GB:1024**2,TB:1024**3},n=Number($("#dataAmount").value)||0,u=$("#dataUnit").value,mb=n*units[u];$("#dataResult").textContent=`${mb.toFixed(3)} MB · ${(mb/1024).toFixed(3)} GB · ${(mb/1024/1024).toFixed(6)} TB`}
$("#dataAmount").oninput=updateData;$("#dataUnit").onchange=updateData;
$("#addData").onclick=()=>{const units={KB:1,MB:1024,GB:1024**2},n=Number($("#fileSize").value)||0,u=$("#fileUnit").value;totalMB+=n*units[u];$("#dataTotal").textContent=`Total: ${totalMB.toFixed(3)} MB (${(totalMB/1024).toFixed(3)} GB)`};
$("#clearData").onclick=()=>{totalMB=0;$("#dataTotal").textContent="Total: 0 MB"};

function addInfo(label,value){return `<div><span>${label}</span><b>${escapeHtml(value??"No disponible")}</b></div>`}
function showDevice(){const nav=navigator,scr=screen;$("#deviceInfo").innerHTML=[addInfo("Navegador",nav.userAgent),addInfo("Plataforma",nav.platform),addInfo("Idioma",nav.language),addInfo("Pantalla",`${scr.width} × ${scr.height}`),addInfo("Pixel ratio",String(devicePixelRatio)),addInfo("CPU lógico",String(nav.hardwareConcurrency||"No disponible")),addInfo("RAM aproximada",nav.deviceMemory?nav.deviceMemory+" GB":"No disponible"),addInfo("Conexión",nav.connection?.effectiveType||"No disponible"),addInfo("Online",nav.onLine?"Sí":"No"),addInfo("Zona horaria",Intl.DateTimeFormat().resolvedOptions().timeZone)].join("")}

function setTheme(t){document.body.classList.toggle("light",t==="light");localStorage.setItem("kingldz_theme",t);document.querySelector('meta[name="theme-color"]').setAttribute("content",t==="light"?"#f3f4f7":"#0b0b10");$$(".theme-card").forEach(b=>b.classList.toggle("active",b.dataset.theme===t))}
$$(".theme-card").forEach(b=>b.onclick=()=>setTheme(b.dataset.theme));
$("#aboutBtn").onclick=()=>$("#about").classList.remove("hidden");$("#closeAbout").onclick=()=>$("#about").classList.add("hidden");$("#about").onclick=e=>{if(e.target.id==="about")$("#about").classList.add("hidden")};

// Evita que el navegador/WebView restaure una posición de desplazamiento antigua al iniciar.
if("scrollRestoration" in history) history.scrollRestoration="manual";
function resetStartupScroll(){window.scrollTo(0,0);document.documentElement.scrollTop=0;document.body.scrollTop=0}

renderNotes();generate();updateData();showDevice();setTheme(localStorage.getItem("kingldz_theme")||"dark");updateHexPreview();updateRgbPreview();
const initial=location.hash.slice(1);if(initial&&$("#"+initial))showScreen(initial);else showScreen("home");
resetStartupScroll();
window.addEventListener("load",resetStartupScroll);
window.addEventListener("pageshow",resetStartupScroll);
setTimeout(resetStartupScroll,50);
