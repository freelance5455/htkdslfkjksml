KITS DE MAVI — proyecto Android

Abrir esta carpeta en Android Studio y ejecutar:
Build > Build APK(s)

La app empaqueta la web original dentro de un WebView. Las notas usan localStorage, por lo que quedan guardadas localmente en el dispositivo.
