XGaming 4.5
- Redesigned profile and downloads toolbar icons only.
- Preserved behavior, layout, and other UI.
- versionCode 45, versionName 4.5.
