Synnova Janasevana Kendhram - Android WebView App

This project packages the supplied synnova_offline_v7.html as an offline Android application.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Generate App Bundles or APKs > Generate APKs.
4. The debug APK will normally be under app/build/outputs/apk/debug/.

The app contains the supplied HTML as app/src/main/assets/index.html and runs locally in WebView.
No internet permission is required.
