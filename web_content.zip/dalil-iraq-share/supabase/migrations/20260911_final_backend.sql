-- Final production hardening and compatibility for دليل العراق.
alter table public.stores add column if not exists claimed_by_name text;
alter table public.stores add column if not exists claimed_by_phone text;
alter table public.stores add column if not exists claimed_at timestamptz;
alter table public.stores add column if not exists owner_user_id uuid;
alter table public.stores add column if not exists owner_name text;
alter table public.stores add column if not exists owner_phone text;
alter table public.stores add column if not exists latitude double precision;
alter table public.stores add column if not exists longitude double precision;
alter table public.stores add column if not exists is_claimed boolean not null default false;
alter table public.stores add column if not exists claim_status text not null default 'unclaimed';
alter table public.stores add column if not exists phone_reliability text not null default 'unverified';
alter table public.stores add column if not exists source text default 'official_directory';
alter table public.stores add column if not exists imported_at timestamptz default now();
alter table public.stores add column if not exists updated_at timestamptz default now();

alter table public.advertisements add column if not exists position text;
alter table public.advertisements add column if not exists subtitle text;
alter table public.advertisements add column if not exists badge text;
alter table public.advertisements add column if not exists link_url text;
alter table public.advertisements add column if not exists is_active boolean not null default true;
alter table public.advertisements add column if not exists expires_at timestamptz;
alter table public.advertisements add column if not exists target_scope text not null default 'district';
alter table public.advertisements add column if not exists target_governorate_id text;
alter table public.advertisements add column if not exists target_district_id text;
alter table public.advertisements add column if not exists category_id text;
alter table public.advertisements add column if not exists category_name text;
alter table public.advertisements add column if not exists governorate_name text;
alter table public.advertisements add column if not exists district_name text;
alter table public.advertisements add column if not exists phone text;
alter table public.advertisements add column if not exists whatsapp text;
alter table public.advertisements add column if not exists duration_days integer;
alter table public.advertisements add column if not exists price numeric;
alter table public.advertisements add column if not exists payment_method text;
alter table public.advertisements add column if not exists reference_number text;

alter table public.news add column if not exists content text;
alter table public.news add column if not exists category text;
alter table public.news add column if not exists author text;
alter table public.news add column if not exists governorate_id text;
alter table public.news add column if not exists district_id text;
alter table public.news add column if not exists published boolean not null default true;
alter table public.news add column if not exists published_at timestamptz;

alter table public.notifications add column if not exists message text;
alter table public.notifications add column if not exists body text;
alter table public.notifications add column if not exists target_type text default 'notification';
alter table public.notifications add column if not exists target_id text;
alter table public.notifications add column if not exists category_id text;
alter table public.notifications add column if not exists image_url text;
alter table public.notifications add column if not exists governorate_id text;
alter table public.notifications add column if not exists district_id text;

alter table public.offers add column if not exists business_name text;
alter table public.offers add column if not exists discount_percentage text;
alter table public.offers add column if not exists coupon_code text;
alter table public.offers add column if not exists governorate_id text;
alter table public.offers add column if not exists district_id text;
alter table public.offers add column if not exists category text;
alter table public.offers add column if not exists image_url text;
alter table public.offers add column if not exists valid_until timestamptz;
alter table public.offers add column if not exists is_active boolean not null default true;

alter table public.otp_verifications add column if not exists otp_hash text;
alter table public.store_claims add column if not exists owner_name text;
alter table public.store_claims add column if not exists owner_phone text;
alter table public.offer_notification_limits add column if not exists last_notified_at timestamptz;

create table if not exists public.admin_wallet (id text primary key default 'main_wallet', balance numeric not null default 0, currency text not null default 'IQD', created_at timestamptz not null default now(), updated_at timestamptz not null default now());
insert into public.admin_wallet(id,balance,currency) values ('main_wallet',0,'IQD') on conflict(id) do nothing;
alter table public.admin_wallet enable row level security;
revoke all on public.admin_wallet from anon, authenticated;
drop policy if exists admin_wallet_no_client_access on public.admin_wallet;
create policy admin_wallet_no_client_access on public.admin_wallet for all to anon, authenticated using (false) with check (false);

-- Public store rows expose only safe columns through PostgreSQL column privileges.
revoke all on public.stores from anon, authenticated;
grant select (id,name,category,sub_category,phone,whatsapp,instagram,facebook,tiktok,website,address,governorate_id,district_id,governorate_name,district_name,rating,reviews_count,is_open,working_hours,image_url,description,featured,tags,is_claimed,claim_status,phone_reliability,source,imported_at,created_at,updated_at,latitude,longitude) on public.stores to anon, authenticated;

drop policy if exists "Authenticated users or Service Role can manage stores" on public.stores;

drop policy if exists "Public Read Ads" on public.advertisements;
drop policy if exists "Public Read Offers" on public.offers;
drop policy if exists "Public Read Notifications" on public.notifications;
drop policy if exists "notifications_select_targeted" on public.notifications;
create policy "final_public_ads_read" on public.advertisements for select to anon, authenticated using (is_active=true and (expires_at is null or expires_at>=now()));
create policy "final_public_offers_read" on public.offers for select to anon, authenticated using (is_active=true and (valid_until is null or valid_until>=now()));
create policy "final_public_notifications_read" on public.notifications for select to anon, authenticated using (true);
create policy "final_public_news_read" on public.news for select to anon, authenticated using (published=true);

revoke all on public.otp_verifications from anon, authenticated;
drop policy if exists otp_no_client_access on public.otp_verifications;
create policy otp_no_client_access on public.otp_verifications for all to anon, authenticated using (false) with check (false);
revoke all on public.offer_notification_limits from anon, authenticated;
drop policy if exists offer_limits_no_client_access on public.offer_notification_limits;
create policy offer_limits_no_client_access on public.offer_notification_limits for all to anon, authenticated using (false) with check (false);

revoke execute on function public.create_offer_notification() from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.is_admin() from public, anon, authenticated;
revoke execute on function public.rls_auto_enable() from public, anon, authenticated;
