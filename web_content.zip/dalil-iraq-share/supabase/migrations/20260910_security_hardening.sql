-- دليل العراق: security hardening
-- This migration is intentionally separate from the 20260909 migration so it
-- still applies when the previous migration has already been executed.

ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Financial data must never be readable by anonymous/authenticated app users.
DROP POLICY IF EXISTS "Public Read Wallets" ON public.wallets;
DROP POLICY IF EXISTS "Public Read Transactions" ON public.transactions;
DROP POLICY IF EXISTS "Public Read Wallets" ON public.wallets;
DROP POLICY IF EXISTS "Public Read Transactions" ON public.transactions;

-- Explicitly revoke table-level reads from client roles. The server uses the
-- Supabase service-role key for protected wallet operations.
REVOKE SELECT ON TABLE public.wallets FROM anon, authenticated;
REVOKE SELECT ON TABLE public.transactions FROM anon, authenticated;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.wallets FROM anon, authenticated;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.transactions FROM anon, authenticated;

-- Ensure only service_role retains unrestricted access through RLS.
DROP POLICY IF EXISTS "Service Role Full Access Wallets" ON public.wallets;
DROP POLICY IF EXISTS "Service Role Full Access Transactions" ON public.transactions;
CREATE POLICY "Service Role Full Access Wallets" ON public.wallets
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "Service Role Full Access Transactions" ON public.transactions
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Never allow the client to create or modify admin credentials.
-- Admin username/password/phone are server environment variables only.
