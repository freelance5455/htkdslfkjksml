-- Compatibility aliases required by the deployed Supabase API function.
alter table public.otp_verifications add column if not exists otp_hash text;
alter table public.store_claims add column if not exists owner_name text;
alter table public.store_claims add column if not exists owner_phone text;
alter table public.stores add column if not exists owner_name text;
alter table public.stores add column if not exists owner_phone text;
alter table public.offer_notification_limits add column if not exists last_notified_at timestamptz;
