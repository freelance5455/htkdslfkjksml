import React, { useState, useMemo } from 'react';
import {
  X,
  Bell,
  CheckCheck,
  Trash2,
  Tag,
  Store,
  Flame,
  ChevronLeft,
  Volume2,
  VolumeX,
  Sparkles,
  Info,
  ExternalLink,
  MapPin,
  Compass,
} from 'lucide-react';
import { useNotification } from '../context/NotificationContext';
import { useLocation } from '../context/LocationContext';
import { NotificationItem } from '../types/directoryModels';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectNotification?: (notif: NotificationItem) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onSelectNotification,
}) => {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    clearAllNotifications,
    deleteNotification,
    soundEnabled,
    setSoundEnabled,
  } = useNotification();
  const { currentLocation } = useLocation();

  const [activeTab, setActiveTab] = useState<'all' | 'offer' | 'store' | 'news'>('all');
  const [locationFilter, setLocationFilter] = useState<'local' | 'all'>('local');

  const filteredNotifications = useMemo(() => {
    return notifications.filter((n) => {
      // 1. Location filter:
      if (locationFilter === 'local') {
        const hasSpecificDistrict = n.districtId && n.districtId !== 'all';
        const hasSpecificGov = n.governorateId && n.governorateId !== 'all';

        if (hasSpecificDistrict) {
          if (n.districtId !== currentLocation.districtId) return false;
        } else if (hasSpecificGov) {
          if (n.governorateId !== currentLocation.governorateId) return false;
        }
      }

      // 2. Tab filter:
      if (activeTab === 'offer') return n.type === 'offer';
      if (activeTab === 'store') return n.type === 'store';
      if (activeTab === 'news') return n.type === 'news' || n.type === 'system';

      return true;
    });
  }, [notifications, activeTab, locationFilter, currentLocation]);

  if (!isOpen) return null;

  const handleNotificationClick = (item: NotificationItem) => {
    markAsRead(item.id);
    if (onSelectNotification && (item.targetId || item.targetType)) {
      onSelectNotification(item);
      onClose();
    }
  };

  const getNotificationIcon = (type?: string) => {
    switch (type) {
      case 'offer':
        return { icon: <Flame className="h-4 w-4 text-red-600" />, bg: 'bg-red-50 border-red-200' };
      case 'store':
        return { icon: <Store className="h-4 w-4 text-sky-600" />, bg: 'bg-sky-50 border-sky-200' };
      case 'news':
      case 'system':
      default:
        return { icon: <Bell className="h-4 w-4 text-amber-600" />, bg: 'bg-amber-50 border-amber-200' };
    }
  };

  const currentAreaName =
    currentLocation.districtName && currentLocation.districtName !== 'كل الأقضية'
      ? currentLocation.districtName
      : currentLocation.governorateName;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl animate-in zoom-in-95 duration-200 max-h-[88vh] flex flex-col border border-slate-200/80"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="border-b border-slate-100 px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white font-bold shadow-xs">
              <Bell className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display text-base font-bold text-white">
                  الإشعارات والتنبيهات
                </h3>
                {unreadCount > 0 && (
                  <span className="rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-bold text-white shadow-xs">
                    {unreadCount} جديد
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                تحديثات العروض والأنشطة التجارية المباشرة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Sound toggle */}
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'كتم صوت الإشعارات' : 'تفعيل صوت الإشعارات'}
              className="flex h-8 w-8 items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              {soundEnabled ? (
                <Volume2 className="h-4 w-4 text-amber-300" />
              ) : (
                <VolumeX className="h-4 w-4 text-slate-400" />
              )}
            </button>

            {/* Close */}
            <button
              type="button"
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Tab Filters */}
        <div className="flex items-center border-b border-slate-200/80 bg-slate-50/90 px-3 py-2 gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'الكل', count: filteredNotifications.length },
            {
              id: 'offer',
              label: 'العروض',
              count: notifications.filter((n) => n.type === 'offer').length,
            },
            {
              id: 'store',
              label: 'المتاجر والأنشطة',
              count: notifications.filter((n) => n.type === 'store').length,
            },
            {
              id: 'news',
              label: 'التنبيهات',
              count: notifications.filter((n) => n.type === 'news' || n.type === 'system').length,
            },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-sky-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 border border-slate-200/70 hover:bg-slate-100/70'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count > 0 && (
                <span
                  className={`rounded-full px-1.5 py-0.2 text-[10px] ${
                    activeTab === tab.id
                      ? 'bg-white/20 text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Geographic Scope Banner & Selector */}
        <div className="flex items-center justify-between px-4 py-2 bg-slate-100/80 border-b border-slate-200 text-xs">
          <div className="flex items-center gap-1.5 text-slate-700">
            <MapPin className="h-3.5 w-3.5 text-sky-600 flex-shrink-0" />
            <span className="font-bold truncate max-w-[170px] sm:max-w-xs">
              {locationFilter === 'local' ? `تنبيهات: ${currentAreaName}` : 'تنبيهات: كل العراق'}
            </span>
          </div>

          <div className="flex items-center bg-white rounded-xl p-0.5 border border-slate-200 text-[10px] font-bold">
            <button
              type="button"
              onClick={() => setLocationFilter('local')}
              className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                locationFilter === 'local'
                  ? 'bg-sky-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {currentAreaName}
            </button>
            <button
              type="button"
              onClick={() => setLocationFilter('all')}
              className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                locationFilter === 'all'
                  ? 'bg-sky-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              كل المحافظات
            </button>
          </div>
        </div>

        {/* Top Control Bar: Mark read / Clear all */}
        {notifications.length > 0 && (
          <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100 bg-white text-xs">
            <span className="text-[11px] text-slate-500 font-medium">
              يتم حفظ الإشعارات محلياً في جهازك
            </span>
            <div className="flex items-center gap-3">
              {unreadCount > 0 && (
                <button
                  type="button"
                  onClick={markAllAsRead}
                  className="flex items-center gap-1 text-[11px] font-bold text-sky-600 hover:text-sky-700 cursor-pointer"
                >
                  <CheckCheck className="h-3.5 w-3.5" />
                  <span>تحديد الكل كمقروء</span>
                </button>
              )}
              <button
                type="button"
                onClick={clearAllNotifications}
                className="flex items-center gap-1 text-[11px] font-bold text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
              >
                <Trash2 className="h-3 w-3" />
                <span>مسح الكل</span>
              </button>
            </div>
          </div>
        )}

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center space-y-3">
              <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-100 text-slate-400 text-2xl">
                🔔
              </div>
              <div>
                <h4 className="font-display text-sm font-bold text-slate-700">
                  لا توجد إشعارات في هذا القسم
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  ستصلك التنبيهات الفورية فور إضافة عروض جديدة أو متاجر في مدينتك.
                </p>
              </div>
            </div>
          ) : (
            filteredNotifications.map((notif) => {
              const iconStyle = getNotificationIcon(notif.type);
              const hasAction = Boolean(notif.targetId || notif.targetType);

              return (
                <div
                  key={notif.id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`group relative rounded-2xl border p-3.5 transition-all text-right ${
                    notif.unread
                      ? 'bg-sky-50/40 border-sky-200/90 shadow-2xs'
                      : 'bg-white border-slate-200/80 hover:bg-slate-50/60'
                  } ${hasAction ? 'cursor-pointer hover:border-sky-300' : ''}`}
                >
                  <div className="flex items-start gap-3">
                    {/* Category Icon */}
                    <div
                      className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl border ${iconStyle.bg}`}
                    >
                      {iconStyle.icon}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {notif.unread && (
                            <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse flex-shrink-0" />
                          )}
                          <h4 className="font-display text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                            {notif.title}
                          </h4>
                          {notif.badge && (
                            <span className="rounded-md bg-slate-100 px-1.5 py-0.2 text-[9px] font-bold text-slate-700">
                              {notif.badge}
                            </span>
                          )}
                        </div>

                        {/* Timestamp & Delete button */}
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-[10px] text-slate-400 font-medium">
                            {notif.time}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteNotification(notif.id);
                            }}
                            title="حذف هذا الإشعار"
                            className="text-slate-300 hover:text-rose-500 transition-colors p-0.5 cursor-pointer opacity-80 group-hover:opacity-100"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>

                      <p className="text-[11px] sm:text-xs text-slate-600 leading-relaxed">
                        {notif.message}
                      </p>

                      {/* Location & Category Badges */}
                      <div className="flex items-center gap-1.5 pt-1.5 flex-wrap text-[10px] font-bold">
                        <span className="flex items-center gap-1 text-sky-700 bg-sky-50 px-2 py-0.5 rounded-lg border border-sky-200/70">
                          <MapPin className="h-3 w-3 text-sky-600" />
                          <span>{notif.districtName || notif.governorateName || 'العراق عام'}</span>
                        </span>
                        {notif.categoryName && (
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-lg border border-slate-200/70">
                            {notif.categoryName}
                          </span>
                        )}
                      </div>

                      {hasAction && (
                        <div className="pt-1.5 flex items-center gap-1 text-[11px] font-bold text-sky-600 group-hover:text-sky-700">
                          <span>عرض التفاصيل المباشرة</span>
                          <ChevronLeft className="h-3 w-3" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-100 bg-slate-50 px-5 py-3 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-500 font-medium">
            دليل العراق • الإشعارات الذكية
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-900 hover:bg-slate-800 text-white px-4 py-1.5 font-bold transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
