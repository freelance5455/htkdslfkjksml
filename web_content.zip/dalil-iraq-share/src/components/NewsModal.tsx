import React, { useState, useEffect } from 'react';
import { X, Calendar, MapPin, Globe, ShieldCheck, Newspaper, Radio, Inbox } from 'lucide-react';
import { CityNews } from '../types/directoryModels';
import { IRAQ_GOVERNORATES } from '../data/iraqLocations';
import { useLocation } from '../context/LocationContext';
import { supabase, getIsSupabaseConfigured } from '../lib/supabase';

interface NewsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewsModal: React.FC<NewsModalProps> = ({ isOpen, onClose }) => {
  const { currentLocation } = useLocation();
  const [selectedGovId, setSelectedGovId] = useState<string>(currentLocation.governorateId || 'dhi-qar');
  const [filterMode, setFilterMode] = useState<'city' | 'all'>('city');
  const [newsList, setNewsList] = useState<CityNews[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Sync selected governorate when user changes location or GPS resolves
  useEffect(() => {
    if (currentLocation.governorateId) {
      setSelectedGovId(currentLocation.governorateId);
    }
  }, [currentLocation.governorateId]);

  // Fetch news directly from Supabase
  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    setIsLoading(true);

    const loadNews = async () => {
      try {
        if (getIsSupabaseConfigured() && supabase) {
          const { data, error } = await supabase
            .from('news')
            .select('*')
            .order('created_at', { ascending: false });

          if (!error && Array.isArray(data) && isMounted) {
            const mapped: CityNews[] = data.map((n: any) => ({
              id: n.id,
              title: n.title,
              summary: n.content || n.summary || '',
              date: n.created_at ? new Date(n.created_at).toLocaleDateString('ar-IQ') : '',
              category: (n.category as any) || 'بلدية',
              source: n.source || 'دليل العراق',
              imageUrl: n.image_url || undefined,
              governorateId: n.governorate_id || undefined,
              readTime: n.read_time || 'دقيقتان',
            }));
            setNewsList(mapped);
            setIsLoading(false);
            return;
          }
        }

      } catch (err) {
        console.warn('News fetch error:', err);
        if (isMounted) setNewsList([]);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    loadNews();

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const currentGov = IRAQ_GOVERNORATES.find((g) => g.id === selectedGovId) || IRAQ_GOVERNORATES[0];

  const filteredNews = newsList.filter((news) => {
    if (filterMode === 'all') return true;
    return news.governorateId === selectedGovId || !news.governorateId;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl overflow-hidden rounded-3xl bg-white shadow-2xl animate-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="border-b border-slate-200 p-4 bg-gradient-to-r from-sky-600 to-blue-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/20 text-white text-xl shadow-xs">
              <Newspaper className="h-5.5 w-5.5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-display text-base sm:text-lg font-extrabold tracking-wide">
                  أخبار المدينة والمحافظة
                </h3>
                <span className="rounded-full bg-amber-400/90 text-amber-950 font-extrabold text-[10px] px-2 py-0.2">
                  مصادر موثوقة 📡
                </span>
              </div>
              <p className="text-xs text-sky-100 font-medium">
                {filterMode === 'city' ? `آخر الأخبار والمصادر المعتمدة في ${currentGov.name}` : 'آخر أخبار المحافظات العراقية'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 hover:bg-white/30 text-white transition-all cursor-pointer active:scale-95"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* City Filter & Selector Tabs */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 space-y-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setFilterMode('city')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterMode === 'city'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <MapPin className="h-3.5 w-3.5" />
              <span>أخبار {currentGov.name}</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterMode === 'all'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Globe className="h-3.5 w-3.5" />
              <span>عموم مدن العراق</span>
            </button>
          </div>

          {/* Governorates quick chip slider if user wants to check another city's news */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <span className="text-[11px] font-bold text-slate-500 whitespace-nowrap pl-1">
              اختر المدينة:
            </span>
            {IRAQ_GOVERNORATES.map((gov) => (
              <button
                key={gov.id}
                type="button"
                onClick={() => {
                  setSelectedGovId(gov.id);
                  setFilterMode('city');
                }}
                className={`flex-shrink-0 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedGovId === gov.id && filterMode === 'city'
                    ? 'bg-sky-100 text-sky-900 border border-sky-300 font-extrabold shadow-2xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {gov.name}
              </button>
            ))}
          </div>
        </div>

        {/* News Feed */}
        <div className="overflow-y-auto p-4 space-y-4 flex-1 min-h-[220px]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-48 text-slate-400 gap-2">
              <div className="h-6 w-6 border-2 border-sky-600 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs">جاري تحميل الأخبار المعتمدة...</span>
            </div>
          ) : filteredNews.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-center p-6 rounded-2xl border border-dashed border-slate-200 bg-slate-50/50">
              <Inbox className="h-10 w-10 text-slate-300 mb-2" />
              <p className="text-sm font-bold text-slate-700">لا توجد أخبار منشورة حالياً</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                لم يتم إدراج أخبار محلية معتمدة لهذه المحافظة في الوقت الحالي. سيتم تحديث الأخبار فور اعتمادها.
              </p>
            </div>
          ) : (
            filteredNews.map((news) => (
              <article
                key={news.id}
                className="group overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-2xs hover:shadow-md transition-all"
              >
                {news.imageUrl && (
                  <div className="aspect-[16/9] w-full overflow-hidden bg-slate-100 relative">
                    <img
                      src={news.imageUrl}
                      alt={news.title}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute top-2.5 right-2.5 flex items-center gap-1 bg-black/60 backdrop-blur-xs text-white px-2.5 py-1 rounded-lg text-[10px] font-bold">
                      <Radio className="h-3 w-3 text-red-400 animate-pulse" />
                      <span>مباشر</span>
                    </div>
                  </div>
                )}

                <div className="p-4 space-y-2.5">
                  <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 flex-wrap">
                    <div className="flex items-center gap-1.5">
                      <span className="rounded-md bg-sky-100 px-2 py-0.5 font-extrabold text-sky-800">
                        {news.category}
                      </span>
                      {news.source && (
                        <span className="flex items-center gap-1 rounded-md bg-emerald-50 border border-emerald-200 px-2 py-0.5 font-bold text-emerald-800 text-[10px]">
                          <ShieldCheck className="h-3 w-3 text-emerald-600" />
                          <span>المصدر: {news.source}</span>
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-slate-400 text-[10px]">
                      <Calendar className="h-3 w-3" />
                      <span>{news.date}</span>
                    </div>
                  </div>

                  <h4 className="font-display text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {news.title}
                  </h4>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {news.summary}
                  </p>
                </div>
              </article>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-100 p-3 bg-slate-50 text-center flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-medium">
            تحديث مباشر على مدار الساعة لكافة مدن ومحافظات العراق 🇮🇶
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-200 px-4 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-300 transition-all cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
