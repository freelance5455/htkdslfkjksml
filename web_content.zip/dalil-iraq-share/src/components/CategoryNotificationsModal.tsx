import React, { useState } from 'react';
import {
  X,
  Bell,
  Sparkles,
  Trash2,
  Phone,
  MessageCircle,
  ArrowLeft,
  Store,
  Tag,
  MapPin,
  Check,
} from 'lucide-react';
import { useNotification } from '../context/NotificationContext';
import { useCategoryAds } from '../context/CategoryAdsContext';
import { NotificationItem } from '../types/directoryModels';

interface CategoryNotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  governorateId: string;
  governorateName: string;
  districtId: string;
  districtName: string;
  categoryId: string;
  categoryName: string;
  categoryIcon: string;
  onSelectNotification?: (notif: NotificationItem) => void;
}

export const CategoryNotificationsModal: React.FC<CategoryNotificationsModalProps> = ({
  isOpen,
  onClose,
  governorateId,
  governorateName,
  districtId,
  districtName,
  categoryId,
  categoryName,
  categoryIcon,
  onSelectNotification,
}) => {
  const {
    getNotificationsForCategory,
    markAsRead,
    markCategoryAsRead,
    deleteNotification,
  } = useNotification();
  const { getAdsForCategory } = useCategoryAds();

  const [activeFilter, setActiveFilter] = useState<'all' | 'offer' | 'store'>('all');

  if (!isOpen) return null;

  const categoryNotifications = getNotificationsForCategory(
    governorateId,
    districtId,
    categoryId
  );

  // Active sponsored category ads for this category & district
  const categoryAds = getAdsForCategory(governorateId, districtId, categoryId);

  const filteredNotifications = categoryNotifications.filter((n) => {
    if (activeFilter === 'offer') return n.type === 'offer';
    if (activeFilter === 'store') return n.type === 'store';
    return true;
  });

  const unreadCount = categoryNotifications.filter((n) => n.unread).length;

  const handleNotificationClick = (notif: NotificationItem) => {
    markAsRead(notif.id);
    if (onSelectNotification) {
      onSelectNotification(notif);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        dir="rtl"
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-sky-600 via-sky-700 to-indigo-700 text-white p-4 sm:p-5">
          {/* Subtle decoration */}
          <div className="absolute top-0 right-0 -mt-6 -mr-6 w-28 h-28 rounded-full bg-white/10 blur-xl pointer-events-none" />

          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md shadow-inner text-2xl border border-white/25">
                {categoryIcon || '🔔'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display text-base sm:text-lg font-black text-white">
                    إشعارات {categoryName}
                  </h3>
                  {unreadCount > 0 && (
                    <span className="rounded-full bg-rose-500 px-2 py-0.5 text-[11px] font-black text-white shadow-xs animate-pulse">
                      {unreadCount} جديد
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 mt-1 text-sky-100 text-xs font-semibold">
                  <MapPin className="h-3.5 w-3.5 text-amber-300" />
                  <span>
                    خاصة بقضاء {districtName} ({governorateName}) فقط
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="rounded-full p-1.5 text-white/80 hover:text-white hover:bg-white/15 transition-all cursor-pointer active:scale-95"
              title="إغلاق"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Subheader info note */}
          <div className="mt-3.5 pt-3 border-t border-white/15 flex items-center justify-between text-xs text-sky-100">
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span className="text-[11px] font-bold">
                تنبيهات جغرافية فورية ومحلية لمدينتك
              </span>
            </div>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={() =>
                  markCategoryAsRead(governorateId, districtId, categoryId)
                }
                className="flex items-center gap-1 text-[11px] font-extrabold text-amber-300 hover:text-white transition-colors cursor-pointer bg-white/10 px-2.5 py-1 rounded-xl"
              >
                <Check className="h-3.5 w-3.5" />
                <span>قراءة الكل</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-50 border-b border-slate-200 text-xs overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeFilter === 'all'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            الكل ({categoryNotifications.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('offer')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
              activeFilter === 'offer'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <Tag className="h-3.5 w-3.5" />
            <span>العروض والخصومات</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('store')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
              activeFilter === 'store'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <Store className="h-3.5 w-3.5" />
            <span>الأنشطة المضافة حديثاً</span>
          </button>
        </div>

        {/* List Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {/* Active Category Ads Highlight Section if any */}
          {categoryAds.length > 0 && activeFilter !== 'store' && (
            <div className="mb-4 space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                <span className="flex items-center gap-1.5 text-amber-700">
                  <Sparkles className="h-4 w-4 text-amber-500" />
                  <span>إعلانات مميزة نشطة في {districtName}</span>
                </span>
                <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-extrabold">
                  مثبتة بالصدارة
                </span>
              </div>

              {categoryAds.map((ad) => (
                <div
                  key={ad.id}
                  className="rounded-2xl border border-amber-300/80 bg-gradient-to-r from-amber-50/90 to-orange-50/50 p-3 shadow-xs hover:border-amber-400 transition-all"
                >
                  <div className="flex gap-3 items-start">
                    {ad.imageUrl && (
                      <img
                        src={ad.imageUrl}
                        alt={ad.businessName}
                        referrerPolicy="no-referrer"
                        className="h-16 w-16 rounded-xl object-cover border border-amber-200 shadow-2xs flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="font-display text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                          {ad.businessName}
                        </h4>
                        {ad.offerBadge && (
                          <span className="rounded-md bg-rose-600 px-2 py-0.5 text-[10px] font-black text-white shadow-2xs whitespace-nowrap">
                            {ad.offerBadge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-700 font-medium mt-1 line-clamp-2 leading-relaxed">
                        {ad.headline} - {ad.description}
                      </p>

                      <div className="flex items-center gap-2 mt-2 pt-2 border-t border-amber-200/60">
                        {ad.phone && (
                          <a
                            href={`tel:${ad.phone}`}
                            className="flex items-center gap-1 text-[11px] font-extrabold text-emerald-700 bg-emerald-100/90 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                          >
                            <Phone className="h-3 w-3" />
                            <span>اتصال</span>
                          </a>
                        )}
                        {ad.whatsapp && (
                          <a
                            href={`https://wa.me/964${ad.whatsapp.replace(/^0+/, '')}`}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center gap-1 text-[11px] font-extrabold text-emerald-800 bg-emerald-100/90 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                          >
                            <MessageCircle className="h-3 w-3" />
                            <span>واتساب</span>
                          </a>
                        )}
                        <span className="text-[10px] font-semibold text-amber-800 mr-auto">
                          📍 {ad.districtName}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Notifications List */}
          {filteredNotifications.length === 0 && categoryAds.length === 0 ? (
            <div className="py-10 text-center px-4 space-y-3">
              <div className="flex h-16 w-16 mx-auto items-center justify-center rounded-3xl bg-sky-50 border border-sky-100 text-sky-600 text-3xl shadow-inner">
                {categoryIcon || '🔔'}
              </div>
              <h4 className="font-display text-sm font-black text-slate-800">
                لا توجد إشعارات أو عروض حالية في قسم {categoryName} بـ {districtName}
              </h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                نظام دليل العراق محلي ومحدد: تظهر لك إشعارات قضاء {districtName} فقط دون أي إزعاج من المحافظات الأخرى. ستصلك التنبيهات هنا فور نشر أي عرض جديد.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredNotifications.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`relative rounded-2xl border p-3 transition-all cursor-pointer active:scale-[0.99] ${
                    notif.unread
                      ? 'bg-sky-50/80 border-sky-300 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex gap-3 items-start">
                    {notif.imageUrl ? (
                      <img
                        src={notif.imageUrl}
                        alt={notif.title}
                        referrerPolicy="no-referrer"
                        className="h-12 w-12 rounded-xl object-cover border border-slate-200 shadow-2xs flex-shrink-0"
                      />
                    ) : (
                      <div
                        className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl text-lg ${
                          notif.type === 'offer'
                            ? 'bg-amber-100 text-amber-700'
                            : notif.type === 'store'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-sky-100 text-sky-700'
                        }`}
                      >
                        {notif.type === 'offer' ? '🏷️' : notif.type === 'store' ? '🏪' : '🔔'}
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1.5">
                        <h4 className="font-display text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                          {notif.title}
                        </h4>
                        {notif.badge && (
                          <span className="rounded-md bg-amber-500/90 px-1.5 py-0.5 text-[9px] font-extrabold text-white">
                            {notif.badge}
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                        {notif.message}
                      </p>

                      <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-100 text-[10px] text-slate-500 font-semibold">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-sky-600" />
                          <span>{notif.districtName || districtName}</span>
                          <span>•</span>
                          <span>{notif.time}</span>
                        </span>

                        <div className="flex items-center gap-2">
                          <span className="text-sky-600 font-bold hover:underline flex items-center gap-0.5">
                            <span>عرض التفاصيل</span>
                            <ArrowLeft className="h-3 w-3" />
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteNotification(notif.id);
                            }}
                            className="text-slate-400 hover:text-rose-600 p-1 rounded-md transition-colors cursor-pointer"
                            title="حذف الإشعار"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
