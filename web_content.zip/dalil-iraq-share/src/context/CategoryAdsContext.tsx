import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { CategoryAd } from '../types/directoryModels';
import { supabase, getIsSupabaseConfigured } from '../lib/supabase';
import { getApiUrl } from '../utils/apiClient';

interface CategoryAdsContextType {
  ads: CategoryAd[];
  isLoading: boolean;
  getAdsForCategory: (governorateId: string, districtId: string, categoryId: string) => CategoryAd[];
  getNationalAds: () => CategoryAd[];
  getGovernorateAds: (governorateId: string) => CategoryAd[];
  addCategoryAd: (
    newAd: Omit<CategoryAd, 'id' | 'createdAt' | 'expiresAt' | 'referenceNumber'>
  ) => CategoryAd;
  deleteCategoryAd: (id: string) => void;
  renewCategoryAd: (id: string, additionalDays: number) => void;
  refreshAds: () => Promise<void>;
}

const CategoryAdsContext = createContext<CategoryAdsContextType | undefined>(undefined);

export const CategoryAdsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [ads, setAds] = useState<CategoryAd[]>(() => {
    // Only used as temporary offline cache
    try {
      const saved = localStorage.getItem('iraq_category_ads');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {}
    return [];
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Fetch real ads from Supabase or server API
  const refreshAds = useCallback(async () => {
    setIsLoading(true);
    try {
      if (getIsSupabaseConfigured() && supabase) {
        const { data, error } = await supabase
          .from('advertisements')
          .select('*')
          .eq('is_active', true)
          .order('created_at', { ascending: false });

        if (!error && Array.isArray(data)) {
          const mappedAds: CategoryAd[] = data.map((d: any) => ({
            id: d.id,
            scope: d.target_scope === 'iraq' ? 'national' : d.target_scope === 'governorate' ? 'governorate' : 'store_area',
            governorateId: d.target_governorate_id || 'all',
            governorateName: d.governorate_name || (d.target_governorate_id === 'all' ? 'عموم العراق' : d.target_governorate_id),
            districtId: d.target_district_id || 'all',
            districtName: d.district_name || 'الكل',
            categoryId: d.category_id || 'other',
            categoryName: d.category_name || 'إعلان ترويجي',
            businessName: d.title,
            headline: d.title,
            description: d.description || '',
            imageUrl: d.image_url,
            phone: d.phone || '',
            whatsapp: d.whatsapp || undefined,
            offerBadge: d.badge || undefined,
            durationDays: d.duration_days || 7,
            price: d.price || 0,
            createdAt: d.created_at ? new Date(d.created_at).getTime() : Date.now(),
            expiresAt: d.expires_at ? new Date(d.expires_at).getTime() : Date.now() + 7 * 24 * 3600 * 1000,
            paymentMethod: d.payment_method || 'زين كاش',
            referenceNumber: d.reference_number || `AD-${d.id.slice(0, 6)}`,
          }));

          setAds(mappedAds);
          try {
            localStorage.setItem('iraq_category_ads', JSON.stringify(mappedAds));
          } catch (e) {}
          setIsLoading(false);
          return;
        }
      }

    } catch (e) {
      console.warn('Failed to load category ads from server:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshAds();
  }, [refreshAds]);

  const getAdsForCategory = (
    governorateId: string,
    districtId: string,
    categoryId: string
  ): CategoryAd[] => {
    const now = Date.now();
    return ads.filter((ad) => {
      if (ad.expiresAt && ad.expiresAt < now) return false;
      if (ad.categoryId !== categoryId && ad.categoryId !== 'all') return false;

      if (governorateId && ad.governorateId && ad.governorateId !== 'all' && ad.governorateId !== governorateId) {
        return false;
      }

      if (districtId && districtId !== 'all') {
        if (ad.districtId && ad.districtId !== 'all' && ad.districtId !== districtId) {
          return false;
        }
      }

      return true;
    });
  };

  const getNationalAds = (): CategoryAd[] => {
    const now = Date.now();
    return ads.filter(
      (ad) =>
        (!ad.expiresAt || ad.expiresAt >= now) &&
        (ad.scope === 'national' || ad.governorateId === 'all')
    );
  };

  const getGovernorateAds = (governorateId: string): CategoryAd[] => {
    const now = Date.now();
    return ads.filter(
      (ad) =>
        (!ad.expiresAt || ad.expiresAt >= now) &&
        (ad.scope === 'governorate' || (!ad.scope && ad.districtId === 'all')) &&
        (ad.governorateId === governorateId || ad.governorateId === 'all')
    );
  };

  const renewCategoryAd = (id: string, additionalDays: number) => {
    setAds((prev) =>
      prev.map((a) => {
        if (a.id !== id) return a;
        const currentExpiry = a.expiresAt > Date.now() ? a.expiresAt : Date.now();
        return {
          ...a,
          expiresAt: currentExpiry + additionalDays * 24 * 3600 * 1000,
          durationDays: (a.durationDays || 0) + additionalDays,
        };
      })
    );
  };

  const addCategoryAd = (
    newAdData: Omit<CategoryAd, 'id' | 'createdAt' | 'expiresAt' | 'referenceNumber'>
  ): CategoryAd => {
    const now = Date.now();
    const durationMs = (newAdData.durationDays || 1) * 24 * 3600 * 1000;
    const refNum = `AD-${(newAdData.districtId || 'IQ').slice(0, 4).toUpperCase()}-${Math.floor(
      1000 + Math.random() * 9000
    )}`;

    const createdAd: CategoryAd = {
      ...newAdData,
      id: `cad-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: now,
      expiresAt: now + durationMs,
      referenceNumber: refNum,
    };

    setAds((prev) => [createdAd, ...prev]);

    // Persist through the Supabase Edge Function.
    if (getIsSupabaseConfigured()) {
      (async () => {
        try {
          await fetch(getApiUrl('/ads'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: createdAd.id, title: createdAd.headline || createdAd.businessName, description: createdAd.description, image_url: createdAd.imageUrl,
              target_scope: createdAd.scope === 'national' ? 'iraq' : createdAd.scope === 'governorate' ? 'governorate' : 'district',
              target_governorate_id: createdAd.governorateId, target_district_id: createdAd.districtId, category_id: createdAd.categoryId,
              is_active: true, starts_at: new Date(now).toISOString(), expires_at: new Date(now + durationMs).toISOString(),
              duration_days: createdAd.durationDays || 30, price: createdAd.price || 0, payment_method: createdAd.paymentMethod, reference_number: createdAd.referenceNumber,
              position: createdAd.scope === 'national' ? 'home_banner' : 'category_banner'
            })
          });
        } catch (err) { console.warn('Failed to save ad in Supabase:', err); }
      })();
    }

    return createdAd;
  };

  const deleteCategoryAd = (id: string) => {
    setAds((prev) => prev.filter((a) => a.id !== id));
    if (getIsSupabaseConfigured()) {
      fetch(`${getApiUrl('/ads')}?id=${encodeURIComponent(id)}`, { method: 'DELETE', headers: typeof window !== 'undefined' && sessionStorage.getItem('iraq_admin_token') ? { Authorization: `Bearer ${sessionStorage.getItem('iraq_admin_token')}` } : {} }).catch(() => {});
    }
  };

  return (
    <CategoryAdsContext.Provider
      value={{
        ads,
        isLoading,
        getAdsForCategory,
        getNationalAds,
        getGovernorateAds,
        addCategoryAd,
        deleteCategoryAd,
        renewCategoryAd,
        refreshAds,
      }}
    >
      {children}
    </CategoryAdsContext.Provider>
  );
};

export const useCategoryAds = () => {
  const context = useContext(CategoryAdsContext);
  if (!context) {
    throw new Error('useCategoryAds must be used within a CategoryAdsProvider');
  }
  return context;
};
