import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { NotificationItem, Offer, DirectoryItem } from '../types/directory';
import { doesCategoryMatch, normalizeCategoryId } from '../utils/categoryMatcher';

export interface IraqMainAnnouncement {
  id: string;
  title: string;
  message: string;
  badge?: string;
  contactNumber?: string;
  updatedAt: number;
  author: string;
}

interface NotificationContextType {
  notifications: NotificationItem[];
  unreadCount: number;
  activeToast: NotificationItem | null;
  mainAnnouncement: IraqMainAnnouncement;
  updateMainAnnouncement: (announcement: Partial<IraqMainAnnouncement>) => void;
  dismissToast: () => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearAllNotifications: () => void;
  deleteNotification: (id: string) => void;
  broadcastNotification: (notif: Omit<NotificationItem, 'id' | 'time' | 'unread'>) => void;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'time' | 'unread'>) => void;
  broadcastNewOfferNotification: (offer: Partial<Offer>) => void;
  broadcastNewStoreNotification: (store: Partial<DirectoryItem>) => void;
  getNotificationsForCategory: (governorateId?: string, districtId?: string, categoryId?: string) => NotificationItem[];
  getUnreadCountForCategory: (governorateId?: string, districtId?: string, categoryId?: string) => number;
  getNotificationsForLocation: (governorateId?: string, districtId?: string) => NotificationItem[];
  markCategoryAsRead: (governorateId?: string, districtId?: string, categoryId?: string) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
}

// Simple Web Audio API synthesizer for native app notification chime
const playNotificationSound = () => {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const now = ctx.currentTime;
    
    // First tone (pleasant high frequency)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
    
    gain1.gain.setValueAtTime(0.18, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);

    osc1.start(now);
    osc1.stop(now + 0.35);

    // Second harmonic chime
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1174.66, now + 0.08); // D6
    gain2.gain.setValueAtTime(0.12, now + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    osc2.start(now + 0.08);
    osc2.stop(now + 0.45);
  } catch (e) {
    // AudioContext autoplay restrictions or disabled audio
  }
};

const getUserSavedLocation = (): { governorateId?: string; districtId?: string } | null => {
  try {
    const saved = localStorage.getItem('iraq_directory_location');
    if (saved) return JSON.parse(saved);
  } catch (e) {
    // ignore
  }
  return null;
};

const INITIAL_NOTIFICATIONS: NotificationItem[] = [];



const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('iraq_notifications_list_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return INITIAL_NOTIFICATIONS;
  });

  const DEFAULT_MAIN_ANNOUNCEMENT: IraqMainAnnouncement = {
    id: 'main-iraq-announcement-1',
    title: '🇮🇶 إشعار العراق العام • تنبيه الإدارة المركزية',
    message: 'مرحباً بكم في منصة دليل العراق الشامل. هذا الإشعار الرسمي العام يصل لجميع مستخدمي التطبيق في كافة محافظات العراق بدون استثناء.',
    badge: 'إشعار العراق ككل 🇮🇶',
    updatedAt: Date.now(),
    author: 'إدارة دليل العراق',
  };

  const [mainAnnouncement, setMainAnnouncement] = useState<IraqMainAnnouncement>(() => {
    try {
      const saved = localStorage.getItem('iraq_main_blue_announcement');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return DEFAULT_MAIN_ANNOUNCEMENT;
  });

  const [activeToast, setActiveToast] = useState<NotificationItem | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('iraq_notif_sound');
    return saved !== null ? saved === 'true' : true;
  });

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('iraq_main_blue_announcement', JSON.stringify(mainAnnouncement));
  }, [mainAnnouncement]);

  const updateMainAnnouncement = useCallback((data: Partial<IraqMainAnnouncement>) => {
    setMainAnnouncement((prev) => {
      const updated: IraqMainAnnouncement = {
        ...prev,
        ...data,
        updatedAt: Date.now(),
      };
      localStorage.setItem('iraq_main_blue_announcement', JSON.stringify(updated));
      return updated;
    });

    // Also trigger chime
    playNotificationSound();
  }, []);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('iraq_notifications_list_v2', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('iraq_notif_sound', soundEnabled.toString());
  }, [soundEnabled]);

  // Location-aware relevance check
  const isNotificationRelevantToUser = useCallback(
    (n: NotificationItem, userLoc: { governorateId?: string; districtId?: string } | null): boolean => {
      // 1. National broadcast
      const scope = n.targetScope || (n.targetDistrictId || (n.districtId && n.districtId !== 'all') ? 'district' : (n.targetGovernorateId || (n.governorateId && n.governorateId !== 'all') ? 'governorate' : 'iraq'));
      if (scope === 'iraq') return true;

      if (!userLoc) return true;

      // 2. Governorate scope
      if (scope === 'governorate') {
        const targetGov = n.targetGovernorateId || n.governorateId;
        return Boolean(targetGov && userLoc.governorateId && targetGov === userLoc.governorateId);
      }

      // 3. District scope
      if (scope === 'district') {
        const targetDist = n.targetDistrictId || n.districtId;
        const targetGov = n.targetGovernorateId || n.governorateId;
        if (userLoc.districtId && userLoc.districtId !== 'all') {
          return targetDist === userLoc.districtId;
        }
        return Boolean(targetGov && userLoc.governorateId && targetGov === userLoc.governorateId);
      }

      return true;
    },
    []
  );

  // Load and subscribe to Supabase notifications. Local storage is cache only.
  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const { data } = await supabase
          .from('notifications')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(200);
        if (!active || !Array.isArray(data)) return;
        const mapped = data.map((n: any) => ({ ...n, message: n.message || n.body || '', targetScope: n.target_scope || 'iraq', targetGovernorateId: n.target_governorate_id || undefined, targetDistrictId: n.target_district_id || undefined, governorateId: n.target_governorate_id || undefined, districtId: n.target_district_id || undefined, categoryId: n.category_id || undefined, storeId: n.store_id || undefined, targetId: n.target_id || undefined, imageUrl: n.image_url || undefined, time: 'مؤخراً', unread: true, timestamp: new Date(n.created_at).getTime(), createdAt: n.created_at }));
        setNotifications(mapped);
      } catch {}
    };
    load();
    const channel = supabase.channel('iraq-notifications-live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, (payload) => {
        const n: any = payload.new;
        const mapped: NotificationItem = { ...n, message: n.message || n.body || '', targetScope: n.target_scope || 'iraq', targetGovernorateId: n.target_governorate_id || undefined, targetDistrictId: n.target_district_id || undefined, governorateId: n.target_governorate_id || undefined, districtId: n.target_district_id || undefined, categoryId: n.category_id || undefined, storeId: n.store_id || undefined, targetId: n.target_id || undefined, imageUrl: n.image_url || undefined, time: 'الآن', unread: true, timestamp: Date.now(), createdAt: n.created_at };
        setNotifications(prev => prev.some(x => x.id === mapped.id) ? prev : [mapped, ...prev]);
      }).subscribe();
    return () => { active = false; supabase.removeChannel(channel); };
  }, []);

  const unreadCount = notifications.filter((n) => {
    if (!n.unread) return false;
    const userLoc = getUserSavedLocation();
    return isNotificationRelevantToUser(n, userLoc);
  }).length;

  const dismissToast = useCallback(() => {
    setActiveToast(null);
  }, []);

  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, unread: false } : n))
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const deleteNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const broadcastNotification = useCallback(
    (item: Omit<NotificationItem, 'id' | 'time' | 'unread'>) => {
      const scope = item.targetScope || (item.targetDistrictId || (item.districtId && item.districtId !== 'all') ? 'district' : (item.targetGovernorateId || (item.governorateId && item.governorateId !== 'all') ? 'governorate' : 'iraq'));

      const newNotif: NotificationItem = {
        ...item,
        id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        time: 'الآن',
        timestamp: Date.now(),
        unread: true,
        targetScope: scope,
        targetGovernorateId: item.targetGovernorateId || item.governorateId,
        targetDistrictId: item.targetDistrictId || item.districtId,
        createdAt: item.createdAt || new Date().toISOString(),
        categoryId: item.categoryId ? normalizeCategoryId(item.categoryId) : undefined,
      };

      // Add to local state
      setNotifications((prev) => [newNotif, ...prev]);


      // GEOGRAPHIC FILTERING FOR USER'S ACTIVE SCREEN:
      const userLoc = getUserSavedLocation();
      const matchesUserLocation = isNotificationRelevantToUser(newNotif, userLoc);

      // Only show banner toast & chime if the user is in the targeted district/area
      if (matchesUserLocation) {
        setActiveToast(newNotif);

        if (soundEnabled) {
          playNotificationSound();
        }

        setTimeout(() => {
          setActiveToast((current) => (current?.id === newNotif.id ? null : current));
        }, 5000);
      }
    },
    [soundEnabled, isNotificationRelevantToUser]
  );

  // Broadcast helper when a new offer is posted (defaults to district scope)
  const broadcastNewOfferNotification = useCallback(
    (offer: Partial<Offer>) => {
      broadcastNotification({
        title: `🔥 عرض وتخفيض جديد: ${offer.businessName || 'نشاط تجاري'}`,
        message: `تم إضافة عرض جديد "${offer.title || 'عرض خاص'}" (${offer.discountPercentage || 'خصم مميز'}) - تصفح العرض الآن واستفد من الخصم!`,
        type: 'offer',
        targetType: 'offer',
        targetId: offer.id,
        imageUrl: offer.imageUrl,
        badge: offer.discountPercentage || 'عرض جديد',
        targetScope: 'district',
        targetGovernorateId: offer.governorateId,
        targetDistrictId: offer.districtId,
        governorateId: offer.governorateId,
        districtId: offer.districtId,
        categoryId: offer.category ? normalizeCategoryId(offer.category) : undefined,
        createdAt: new Date().toISOString(),
      });
    },
    [broadcastNotification]
  );

  // Broadcast helper when a new store / place is added to directory (defaults to district scope)
  const broadcastNewStoreNotification = useCallback(
    (store: Partial<DirectoryItem>) => {
      broadcastNotification({
        title: `🎉 متجر جديد: ${store.name || 'نشاط تجاري جديد'}`,
        message: `تم إضافة ${store.name || 'متجر جديد'} إلى قسم (${store.category || 'المحلات'}) في ${store.address || 'العراق'} - تصفح التفاصيل وتواصل مباشرة.`,
        type: 'store',
        targetType: 'store',
        targetId: store.id,
        storeId: store.id,
        imageUrl: store.imageUrl,
        badge: 'متجر جديد',
        targetScope: 'district',
        targetGovernorateId: store.governorateId,
        targetDistrictId: store.districtId,
        governorateId: store.governorateId,
        governorateName: store.governorateName,
        districtId: store.districtId,
        districtName: store.districtName,
        categoryId: store.category ? normalizeCategoryId(store.category) : undefined,
        createdAt: new Date().toISOString(),
      });
    },
    [broadcastNotification]
  );

  // Retrieve notifications targeted to a specific category and location
  const getNotificationsForCategory = useCallback(
    (govId?: string, distId?: string, catId?: string) => {
      if (!catId || catId === 'all') {
        return notifications.filter((notif) => {
          if (notif.districtId && notif.districtId !== 'all') {
            if (distId && distId !== 'all' && notif.districtId !== distId) {
              return false;
            }
          } else if (notif.governorateId && notif.governorateId !== 'all') {
            if (govId && govId !== 'all' && notif.governorateId !== govId) {
              return false;
            }
          }
          return true;
        });
      }

      const normalizedCat = normalizeCategoryId(catId);

      return notifications.filter((notif) => {
        // Category check
        if (!notif.categoryId || !doesCategoryMatch(normalizedCat, notif.categoryId)) {
          return false;
        }

        // Location check
        if (notif.districtId && notif.districtId !== 'all') {
          if (distId && distId !== 'all' && notif.districtId !== distId) {
            return false;
          }
        } else if (notif.governorateId && notif.governorateId !== 'all') {
          if (govId && govId !== 'all' && notif.governorateId !== govId) {
            return false;
          }
        }

        return true;
      });
    },
    [notifications]
  );

  // Unread count for a specific category in a district
  const getUnreadCountForCategory = useCallback(
    (govId?: string, distId?: string, catId?: string) => {
      return getNotificationsForCategory(govId, distId, catId).filter((n) => n.unread).length;
    },
    [getNotificationsForCategory]
  );

  // Retrieve notifications for a specific district/governorate
  const getNotificationsForLocation = useCallback(
    (govId?: string, distId?: string) => {
      return notifications.filter((notif) => {
        // If not localized, it's a nationwide/system announcement
        if (!notif.districtId && !notif.governorateId) return true;

        if (notif.districtId && notif.districtId !== 'all') {
          if (distId && distId !== 'all' && notif.districtId !== distId) {
            return false;
          }
        } else if (notif.governorateId && notif.governorateId !== 'all') {
          if (govId && govId !== 'all' && notif.governorateId !== govId) {
            return false;
          }
        }

        return true;
      });
    },
    [notifications]
  );

  // Mark all notifications for a specific category in a district as read
  const markCategoryAsRead = useCallback(
    (govId?: string, distId?: string, catId?: string) => {
      if (!catId) return;
      const normalizedCat = normalizeCategoryId(catId);

      setNotifications((prev) =>
        prev.map((n) => {
          if (!n.categoryId || !doesCategoryMatch(normalizedCat, n.categoryId)) {
            return n;
          }
          if (n.districtId && n.districtId !== 'all' && distId && distId !== 'all' && n.districtId !== distId) {
            return n;
          }
          if (n.governorateId && n.governorateId !== 'all' && govId && govId !== 'all' && n.governorateId !== govId) {
            return n;
          }
          return { ...n, unread: false };
        })
      );
    },
    []
  );

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        activeToast,
        mainAnnouncement,
        updateMainAnnouncement,
        dismissToast,
        markAsRead,
        markAllAsRead,
        clearAllNotifications,
        deleteNotification,
        broadcastNotification,
        addNotification: broadcastNotification,
        broadcastNewOfferNotification,
        broadcastNewStoreNotification,
        getNotificationsForCategory,
        getUnreadCountForCategory,
        getNotificationsForLocation,
        markCategoryAsRead,
        soundEnabled,
        setSoundEnabled,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};

