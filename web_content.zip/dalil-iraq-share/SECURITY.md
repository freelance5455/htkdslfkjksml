# دليل العراق — Security Notes

## Admin login
Admin authentication is server-side only. Configure these variables in the server/deployment environment:

- `IRAQ_ADMIN_USERNAME`
- `IRAQ_ADMIN_PASSWORD`
- `IRAQ_ADMIN_PHONE`
- `ADMIN_TOKEN_SECRET`

Do **not** put these values in Vite `VITE_*` variables or browser storage.

## Supabase wallet security
Wallets and transactions are intentionally not publicly readable. The server API reads/writes them with the Supabase service-role key after verifying the admin session. Run the migration `supabase/migrations/20260910_security_hardening.sql`.

## Build
After pulling the project, run `npm install`, then `npm run build`, then `npm run cap:sync` before building Android. This refreshes the bundled Android web assets from `src/`.
