MINHAS COMPRAS — PROJETO ANDROID

Este pacote transforma o aplicativo web original em um app Android nativo simples,
usando WebView local. A interface e as funções do index.html foram preservadas.
Os dados continuam salvos localmente no aparelho por meio do localStorage.

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Abra o Android Studio e escolha "Open".
3. Selecione a pasta MinhasComprasAndroid (a pasta deste projeto).
4. Aguarde a sincronização do Gradle. Se solicitado, instale Android SDK Platform 35
   e JDK 17 pelo próprio Android Studio.
5. Para gerar um APK de teste: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Ao terminar, clique em "locate" na notificação do Android Studio. O APK estará
   normalmente em app/build/outputs/apk/debug/app-debug.apk.
7. Transfira o APK para o Android e instale. Talvez seja necessário autorizar
   a instalação pelo aplicativo usado para abrir o arquivo.

OBSERVAÇÕES
- Este ambiente não possui Android SDK/Gradle configurado, então não foi possível
  compilar e entregar um arquivo .apk pronto aqui.
- O projeto está preparado para abrir no Android Studio e gerar o APK.
- O app funciona offline, pois a página é empacotada dentro do aplicativo.
- Os dados ficam no armazenamento local do app. Desinstalar o app pode apagá-los.
