# Minhas Compras — Android acessível

Projeto Android para abrir no Android Studio e gerar APK.

## Correção de geolocalização
A versão corrigida não usa `file://` para carregar o HTML. O WebView usa `WebViewAssetLoader` com a origem segura:

`https://appassets.androidplatform.net/assets/index.html`

Isso permite que `navigator.geolocation` funcione em conjunto com a permissão nativa Android, respeitando a solicitação feita pelo usuário no aplicativo.

## Acessibilidade
- Compatível com TalkBack/recursos nativos de acessibilidade.
- Texto ampliado no WebView.
- Zoom habilitado.
- Controles grandes no HTML.
- Recursos de voz do aplicativo permanecem disponíveis.

## Compilar
1. Abra a pasta `MinhasComprasAndroid` no Android Studio.
2. Aguarde a sincronização do Gradle e o download da dependência AndroidX WebKit.
3. Use `Build > Generate App Bundles or APKs > Generate APKs`.
4. APK de debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Identificação
- App: Minhas Compras
- Application ID: `br.com.raphael.minhascompras`
- minSdk: 23
- targetSdk: 35
- versão: 1.0 (versionCode 1)
