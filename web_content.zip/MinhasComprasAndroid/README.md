# Minhas Compras — Projeto Android

Projeto Android com WebView contendo a versão corrigida do aplicativo Minhas Compras.

## Recursos
- Lista de compras offline via armazenamento local.
- Geolocalização acionada pelo usuário.
- Permissões Android de localização fina/aproximada.
- Acesso a mercados próximos conforme a lógica do HTML.
- Interface responsiva.

## Gerar APK
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use **Build > Generate App Bundles or APKs > Generate APKs**.
4. O APK normalmente ficará em `app/build/outputs/apk/debug/`.

Este projeto não inclui uma assinatura de produção. Para publicar na Play Store, configure uma chave de assinatura própria.
