# STOA – Android-Projekt

Dies ist ein erster nativer Android-Shell-Prototyp für STOA. Die Oberfläche läuft offline in einer lokalen WebView; Tagebucheinträge und der Tagesfortschritt werden lokal auf dem Gerät gespeichert.

## APK bauen

Voraussetzungen:
- Android Studio (aktuelle stabile Version)
- Android SDK Platform 35
- JDK 17
- Internetverbindung beim ersten Gradle-Sync

1. ZIP entpacken.
2. Android Studio öffnen und den Ordner `STOA-Android` importieren.
3. Gradle-Synchronisierung abwarten.
4. Menü **Build → Build Bundle(s) / APK(s) → Build APK(s)** auswählen.
5. Die Debug-APK liegt anschließend unter `app/build/outputs/apk/debug/app-debug.apk`.

Für eine Veröffentlichung im Play Store muss später eine eigene Release-Signatur eingerichtet werden.

## Aktueller Umfang
- Heute: Tagesimpuls, Erklärung, Übung und Tagesfortschritt
- Wissen: vier Tugenden und drei zentrale Stoiker
- Übungen: praktische stoische Trainings
- Tagebuch: lokale Speicherung auf dem Gerät
- Schwarz-Gold-Design, offline nutzbar

## Hinweise
Dies ist ein Startprojekt, noch keine veröffentlichungsfertige App. Die Impulse rotieren aus einem kleinen lokalen Beispielbestand; für einen echten täglichen Inhaltsdienst, Erinnerungsbenachrichtigungen, Datenschutz-/Exportfunktionen und eine größere redaktionell geprüfte Bibliothek sind weitere Entwicklungsarbeiten nötig.
