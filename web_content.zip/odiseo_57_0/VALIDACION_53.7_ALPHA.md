# Validación Odiseo 53.7-alpha — Núcleo local de razonamiento simbólico

Fecha: 2026-11-05
Base: ODISEO 53.6-alpha independencia GPT. Rama experimental; 53.2 sigue siendo la versión estable global.

## Implementación
- Nuevo `app/src/main/assets/nucleo_razonamiento_local_odiseo.js`, API `OdiseoReasoningCore`.
- Segmentación de enunciados y clasificación heurística: afirmación, hipótesis, negación, causal y condicional.
- Extracción de términos y valores numéricos.
- Mapa de pares con solapamiento léxico, sin presentarlo como similitud semántica.
- Alertas de contradicción candidatas y generación de hipótesis exploratorias con falsadores sugeridos.
- Integración en `index.html` y chat local: `razona local:`, `analiza local:`, `hipotesis local:`, `estado del razonamiento local`.
- Sin GPT, APIs, modelo remoto ni llamadas de red.

## Pruebas reproducidas
- `tests_nucleo_razonamiento_local.js`: 10/10 PASS.
- Regresión completa: 39/39 archivos `tests_*.js` ejecutados individualmente con código de salida cero.
- Sintaxis de los 33 assets JavaScript: PASS.
- CRC del paquete fuente: PASS.

## Límites y pendientes
- Es un motor simbólico determinista, no un LLM ni un sistema de comprensión semántica general.
- Clasificación y extracción son heurísticas; el solapamiento léxico no demuestra relación semántica.
- Las contradicciones son candidatas que requieren comprobar sujeto, tiempo, alcance y contexto.
- Una afirmación causal no prueba causalidad.
- No se ha integrado todavía un modelo neuronal local.
- No se ha compilado, instalado ni probado la APK en Android.
