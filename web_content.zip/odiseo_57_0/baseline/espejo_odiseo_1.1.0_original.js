/* ODISEO 50.1 — Espejo Bidireccional.
 * Motor genérico de información explícita: expansión, retorno, auditoría y memoria de resultados.
 * No presume conocer información ausente ni convierte asociaciones en verdades.
 */
(function (global) {
  'use strict';
  const VERSION = '1.1.0-espejo-bidireccional';
  const MAX_NODES = 5000, MAX_EDGES = 20000, MAX_VISITS = 10000, MAX_TEXT = 4000;
  const RELATIONS = new Set(['supports', 'derives', 'contradicts', 'relates']);
  const OUTCOMES = new Set(['verified', 'refuted', 'inconclusive']);

  function cleanText(value, label) {
    if (typeof value !== 'string' || !value.trim() || value.length > MAX_TEXT) throw new Error((label || 'Texto') + ': debe contener entre 1 y ' + MAX_TEXT + ' caracteres.');
    return value.trim();
  }
  function cloneGraph(input) {
    const g = input && typeof input === 'object' ? input : {};
    const nodes = Array.isArray(g.nodes) ? g.nodes : [];
    const edges = Array.isArray(g.edges) ? g.edges : [];
    const learnings = Array.isArray(g.learnings) ? g.learnings : [];
    if (nodes.length > MAX_NODES || edges.length > MAX_EDGES) throw new Error('El grafo supera los límites de seguridad.');
    const ids = new Set();
    const safeNodes = nodes.map(n => {
      if (!n || typeof n.id !== 'string' || !n.id || ids.has(n.id)) throw new Error('Identificador de nodo inválido o duplicado.');
      ids.add(n.id);
      return { id:n.id, text:cleanText(n.text,'Contenido del nodo'), kind:String(n.kind || 'information'), evidence:String(n.evidence || ''), createdAt:String(n.createdAt || '') };
    });
    const edgeIds = new Set();
    const safeEdges = edges.map(e => {
      if (!e || typeof e.id !== 'string' || !e.id || edgeIds.has(e.id) || !ids.has(e.from) || !ids.has(e.to) || !RELATIONS.has(e.relation)) throw new Error('Relación inválida: comprueba sus nodos y tipo.');
      edgeIds.add(e.id);
      return { id:e.id, from:e.from, to:e.to, relation:e.relation, evidence:String(e.evidence || '') };
    });
    const safeLearnings = learnings.filter(x => x && OUTCOMES.has(x.outcome) && typeof x.strategy === 'string' && typeof x.evidence === 'string').slice(-2000);
    return { schema:'ODISEO_MIRROR_GRAPH_1', nodes:safeNodes, edges:safeEdges, learnings:safeLearnings };
  }
  function makeId(prefix) { return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,9); }
  function addNode(graph, data) {
    const g = cloneGraph(graph);
    if (g.nodes.length >= MAX_NODES) throw new Error('Límite de nodos alcanzado.');
    const text = cleanText(data && data.text, 'Contenido');
    const node = { id:makeId('n'), text, kind:String(data.kind || 'information'), evidence:String(data.evidence || ''), createdAt:new Date().toISOString() };
    g.nodes.push(node); return { graph:g, node };
  }
  function addEdge(graph, data) {
    const g = cloneGraph(graph), from = String(data && data.from || ''), to = String(data && data.to || ''), relation = String(data && data.relation || 'relates');
    if (!g.nodes.some(n => n.id === from) || !g.nodes.some(n => n.id === to)) throw new Error('Selecciona dos nodos existentes.');
    if (!RELATIONS.has(relation)) throw new Error('Tipo de relación no permitido.');
    if (g.edges.length >= MAX_EDGES) throw new Error('Límite de relaciones alcanzado.');
    if (g.edges.some(e => e.from === from && e.to === to && e.relation === relation)) throw new Error('Esa relación ya existe.');
    const edge = { id:makeId('e'), from, to, relation, evidence:String(data.evidence || '') };
    g.edges.push(edge); return { graph:g, edge };
  }
  function traverse(g, seed, direction, budget) {
    const adjacency = new Map(g.nodes.map(n => [n.id, []]));
    for (const e of g.edges) {
      const start = direction === 'forward' ? e.from : e.to;
      const next = direction === 'forward' ? e.to : e.from;
      adjacency.get(start).push({ id:next, edge:e });
    }
    const queue = [seed], seen = new Set([seed]), paths = [], usedEdges = new Set();
    let truncated = false;
    while (queue.length) {
      const current = queue.shift();
      for (const item of adjacency.get(current) || []) {
        usedEdges.add(item.edge.id);
        if (!seen.has(item.id) && seen.size >= budget) { truncated = true; break; }
        paths.push({ from:current, to:item.id, relation:item.edge.relation, edgeId:item.edge.id, evidence:item.edge.evidence });
        if (!seen.has(item.id)) { seen.add(item.id); queue.push(item.id); }
      }
    }
    return { nodeIds:Array.from(seen), paths, truncated:truncated || queue.length > 0, visited:seen.size, edgeIds:Array.from(usedEdges) };
  }
  function analyze(graph, seedId, maxVisits) {
    const g = cloneGraph(graph), budget = Number(maxVisits === undefined ? 500 : maxVisits);
    if (!Number.isSafeInteger(budget) || budget < 1 || budget > MAX_VISITS) throw new Error('El presupuesto debe estar entre 1 y ' + MAX_VISITS + '.');
    if (!g.nodes.some(n => n.id === seedId)) throw new Error('El nodo inicial no existe.');
    // A: expansión desde el origen. B: retorno hacia los antecedentes y búsqueda de contradicciones.
    const forward = traverse(g, seedId, 'forward', budget);
    const backward = traverse(g, seedId, 'backward', budget);
    const contradictions = g.edges.filter(e => e.relation === 'contradicts' && forward.nodeIds.includes(e.from) && forward.nodeIds.includes(e.to));
    // C: integridad de referencias y trazabilidad explícita.
    const nodeMap = new Map(g.nodes.map(n => [n.id,n]));
    const reached = new Set([...forward.nodeIds, ...backward.nodeIds]);
    const noEvidence = Array.from(reached).map(id => nodeMap.get(id)).filter(n => !n.evidence.trim());
    const h = { budget, visitedForward:forward.visited, visitedBackward:backward.visited, truncated:forward.truncated || backward.truncated,
      stopReason:(forward.truncated || backward.truncated) ? 'PRESUPUESTO_CUMPLIDO' : 'RECORRIDO_AGOTADO' };
    return { engine:'ODISEO ESPEJO BIDIRECCIONAL', version:VERSION, seed:nodeMap.get(seedId),
      A:{ role:'Expansión', nodes:forward.nodeIds, paths:forward.paths },
      B:{ role:'Retorno y refutación', nodes:backward.nodeIds, paths:backward.paths, contradictions },
      C:{ role:'Evaluación', reachedNodes:reached.size, contradictions:contradictions.length,
        nodesWithoutEvidence:noEvidence.map(n=>({id:n.id,text:n.text})), integrity:'REFERENCIAS_VALIDAS',
        interpretation:'Las relaciones son información registrada, no hechos demostrados. La ausencia de contradicciones registradas no prueba que una afirmación sea verdadera.' },
      H:h, status:contradictions.length ? 'CONTRADICCIONES_PENDIENTES' : (h.truncated ? 'EXPLORACION_INCOMPLETA' : 'RECORRIDO_COMPLETADO') };
  }
  function recordOutcome(graph, data) {
    const g = cloneGraph(graph), strategy = cleanText(data && data.strategy,'Estrategia'), evidence = cleanText(data && data.evidence,'Evidencia'), outcome = String(data && data.outcome || '');
    if (!OUTCOMES.has(outcome)) throw new Error('El resultado debe ser verified, refuted o inconclusive.');
    g.learnings.push({ id:makeId('l'), strategy, outcome, evidence, recordedAt:new Date().toISOString() });
    return g;
  }
  function learningSummary(graph) {
    const g = cloneGraph(graph), map = {};
    for (const item of g.learnings) {
      const x = map[item.strategy] || (map[item.strategy] = { strategy:item.strategy, verified:0, refuted:0, inconclusive:0, total:0 });
      x[item.outcome]++; x.total++;
    }
    return Object.values(map).sort((a,b)=>b.verified-a.verified || a.refuted-b.refuted || b.total-a.total);
  }
  function recommendStrategy(graph) {
    const ranked = learningSummary(graph);
    if (!ranked.length) return { strategy:null, reason:'Aún no hay experiencias evaluadas; registra una estrategia y su evidencia.' };
    // Prioriza evidencia verificada, evita repetir estrategias refutadas y favorece las menos exploradas en empate.
    ranked.sort((a,b)=>((b.verified+1)/(b.total+2))-((a.verified+1)/(a.total+2)) || a.refuted-b.refuted || a.total-b.total);
    return { strategy:ranked[0].strategy, reason:'Mejor balance histórico disponible: '+ranked[0].verified+' verificadas, '+ranked[0].refuted+' refutadas y '+ranked[0].inconclusive+' inconclusas. Es una recomendación heurística, no una garantía.' };
  }
  const api = Object.freeze({ version:VERSION, empty:()=>({schema:'ODISEO_MIRROR_GRAPH_1',nodes:[],edges:[],learnings:[]}),
    validate:cloneGraph, addNode, addEdge, analyze, recordOutcome, learningSummary, recommendStrategy,
    describe:()=>({name:'Odiseo Espejo Bidireccional',version:VERSION,capabilities:['grafo de información explícita','recorrido 0→∞ conceptual mediante expansión','retorno inverso hacia antecedentes','detección de contradicciones registradas','memoria de resultados evaluados con evidencia','presupuesto de exploración'], limitations:['no contiene toda la información del universo','no verifica automáticamente la verdad externa de los datos','no aprende de forma autónoma sin evaluación registrada','no es conciencia ni inteligencia general']}) });
  global.OdiseoMirror = api;
})(window);
