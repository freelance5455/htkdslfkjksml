'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const store=new Map(),ctx={console,Date,Math,JSON,window:{},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;
vm.runInNewContext(fs.readFileSync('app/src/main/assets/penelope_odiseo.js','utf8'),ctx);
vm.runInNewContext(fs.readFileSync('app/src/main/assets/asistente_local_odiseo.js','utf8'),ctx);
(async()=>{
 const ast={type:'binary',op:'sum',a:{type:'primitive',name:'x'},b:{type:'binary',op:'product',a:{type:'primitive',name:'y'},b:{type:'primitive',name:'z'}}};
 let r=await ctx.OdiseoLocalAssistant.reply('Penélope: '+JSON.stringify({ast,sourceId:'test-penelope'}));
 assert.equal(r.meta.engine,'Penélope');assert.equal(r.meta.status,undefined);assert.ok(r.meta.result.validatedProposals.length>0);assert.ok(r.meta.result.validatedProposals.every(p=>p.verified&&p.reversible));
 r=await ctx.OdiseoLocalAssistant.reply('Penélope: no es JSON');assert.equal(r.meta.status,'NEEDS_INPUT');
 r=await ctx.OdiseoLocalAssistant.reply('Penélope: '+JSON.stringify({ast:{type:'primitive',name:'intruso'}}));assert.equal(r.meta.status,'ERROR');
 console.log('PASS 3/3 — Penélope: AST válido, entrada JSON inválida y AST rechazado');
})().catch(e=>{console.error(e);process.exit(1)});
