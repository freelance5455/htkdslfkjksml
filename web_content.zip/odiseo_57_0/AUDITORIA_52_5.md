# Auditoría Odiseo 52.5 — Ciclo integrado A/B/C/D/E/H

## Objetivo
Conectar funcionalmente Sherlock, Penélope y el Integrador de Evidencias (OIE) en una operación común, con controlador H, presupuestos y parada explícita.

## Implementación
- El orquestador coordina también Judas Tadeo (D) e Integrador E (tareas acotadas) junto a Sherlock, Penélope y OIE.
- `app/src/main/assets/ciclo_integrado_odiseo.js`: orquestador A/B/C/D/E/H.
- `app/src/main/assets/index.html`: carga OIE y orquestador; panel para enviar datos JSON y ejecutar el ciclo; historial local limitado a 100 informes.
- Sherlock produce candidatos exploratorios; no se convierten automáticamente en evidencia.
- Solo los enlaces explícitos del usuario se traducen en relaciones de apoyo dentro de OIE.
- Penélope recibe AST explícitos, ejecuta `unweave` y valida cada propuesta con `validateProposal`.
- OIE evalúa afirmaciones, procedencia declarada, contradicciones y referencias rotas.
- H limita rastros y AST; detiene para revisión ante conflictos o referencias rotas.
- OIE tolera campos `supporting`/`contradicting` malformados sin convertirlos en evidencia y etiqueta las familias como `DECLARED_NOT_VERIFIED`.

## Pruebas específicas
- `tests_odiseo_ciclo_integrado.js`: 17 assertions.
- `tests_odiseo_integrador_evidencias.js`: 10 assertions.

## Límites
- Una pista de Sherlock no es prueba.
- Un enlace explícito no certifica la verdad de su contenido.
- `sourceFamily` declarada no demuestra independencia real.
- Penélope valida estructura de AST y trazabilidad, no equivalencia semántica.
- El ciclo no modifica su propio código ni aprende autónomamente.
- APK no compilada ni instalada.

## Criterio de aceptación
La integración se considera operativa para el contrato JSON documentado si pasan las pruebas específicas y la regresión completa. No se declara razonamiento general ni descubrimiento autónomo.
