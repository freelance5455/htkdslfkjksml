# Odiseo 51.6 Alpha — Prueba de independencia Odiseo/Penélope

Odiseo 50.6 integra A/B/C/H experimental, Espejo Bidireccional, Acelerador Matemático, Motor de Acertijos, Motor de Evolución y Motor de Interacción Finita + Convergencia Autorregulada.

## Hipótesis de interacción
Dos conjuntos iniciales finitos A y B interactúan. Sus operaciones producen resultados nuevos que pueden volver a entrar en los conjuntos. Cada ronda concreta es finita; la sucesión de rondas podría estabilizarse o seguir creciendo. No se afirma que la clausura sea infinita sin una demostración independiente.

## Motor de Interacción Finita + Convergencia Autorregulada
- Entradas: dos conjuntos de hasta 12 enteros cada uno.
- Operaciones cruzadas: suma, producto, diferencia absoluta, MCD y MCM.
- Los resultados nuevos se reinsertan en A o B y alimentan la siguiente ronda.
- Cada evento genera una pregunta, una respuesta aritmética exacta y una nueva pregunta sobre la reinserción del resultado.
- El Espejo conserva la procedencia del experimento y hasta 30 ciclos reflexivos.
- Historial incluido en ODISEO SAVE.
- Límites: 8 rondas, 100 valores únicos, 5000 parejas, 256 bits por entero y 200 eventos almacenados.

## Ejemplo reproducible
Con A={2}, B={3}, cuatro rondas y presupuesto de 50 valores/2000 parejas: 67 parejas examinadas y 50 valores únicos antes de alcanzar el límite de valores. Se observó crecimiento. Este resultado no demuestra infinitud.

## Pruebas
- A/B/C/H: 8.
- Espejo: 9.
- Acelerador: 11.
- Acertijos: 14.
- Evolución: 11.
- Interacción Finita + Convergencia Autorregulada: 12.
- **Total: 65 comprobaciones JavaScript superadas.**
- Preparación del generador APK y hashes de seis módulos: verificada.

## Límites honestos
La suma aislada de dos números finitos es finita. El posible crecimiento procede de iterar reglas y reintroducir resultados. Una ejecución con un número finito de rondas no demuestra que el proceso total sea infinito. El motor no aprende autónomamente, no modifica su código y no demuestra teoremas. La APK no se ha compilado ni probado en Android.

## Continuidad
Consultar `ESTADO_ODISEO.json`, `DIARIO_ODISEO.json` y `METODO_CONTINUIDAD.md`. Mantener los ZIP históricos.


## Odiseo 50.6 — Motor de Convergencia Autorregulada

Para un objetivo `x` con `0 < x < 1`, y un estado inicial `0 <= y0 <= x`, se define `alpha_n = x + (1-x)*y_n` y `y_(n+1) = y_n + alpha_n*(x-y_n)`. El error cumple `e_(n+1)=e_n*(1-alpha_n)`. Como `0 < alpha_n <= 2*x-x^2 < 1`, el estado permanece en `[0,x]`, crece monótonamente y converge a `x`. La contracción asintótica tiende a `(1-x)^2`. Se compara con la tasa fija `alpha=x`; no se afirma optimalidad global.


## Odiseo 50.8 — Motor de Objetivo Evolutivo

Se incorpora `objetivo_evolutivo_odiseo.js`: el objetivo sigue el mapa logístico `x[n+1]=r*x[n]*(1-x[n])` y el perseguidor `y` se adapta mediante una ganancia acotada. El motor informa rangos, error final y una clasificación heurística. Las ventanas finitas no prueban caos, periodicidad asintótica ni estabilidad global. El generador APK valida y calcula SHA-256 del nuevo módulo.

## Odiseo 50.9 — Motor de Sensibilidad

Añade comparación de dos órbitas del mapa logístico con condiciones iniciales cercanas, una estimación finita del exponente de Lyapunov y un barrido de parámetros. La estimación depende de la órbita y de la ventana observada; no demuestra caos ni comportamiento asintótico. El nuevo historial se conserva en ODISEO SAVE. Suite acumulada declarada: 120 comprobaciones JavaScript, pendiente de repetir íntegramente en esta versión antes de empaquetar.

## Odiseo 51.1 — Ciclo de Investigación A/B/C/H

Se incorpora `app/src/main/assets/investigacion_odiseo.js` y su panel Android. El ciclo formula hipótesis operacionales, ejecuta experimentos, busca contraejemplos, repite y verifica resultados por una segunda vía. Actualmente admite dos familias: auditoría Syracuse acelerada y sensibilidad del mapa logístico. El controlador H asigna el presupuesto a partir del Motor de Energía, preserva una reserva y limita la ejecución.

Cada caso conserva pregunta, formulación de hipótesis, afirmación operacional comprobada, parámetros, resultados, contraejemplos, verificación independiente, huella y límites epistemológicos. El historial (máximo 100 casos) se exporta/restaura mediante ODISEO SAVE y se enlaza al Espejo.

**Límite importante:** no interpreta semánticamente preguntas o hipótesis libres; ejecuta únicamente afirmaciones operacionales explícitas en los motores admitidos. La ausencia de contraejemplos en un rango finito no demuestra una afirmación universal. No hay aprendizaje autónomo ni auto-modificación.

Verificación 51.1: 166 pruebas JavaScript en 11 baterías, 0 fallos. Preparación del generador APK comprobada; APK no compilada ni instalada.


## Odiseo 51.2 — Núcleo Creador Autónomo

Esta versión incorpora `app/src/main/assets/creador_autonomo_odiseo.js`, un núcleo local autocontenido que no depende de los otros motores, internet, APIs ni modelos externos. Parte de un conjunto interno de primitivas y una gramática de composición; genera estructuras simbólicas sin recibir una pregunta, valida su árbol sintáctico, conserva procedencia, estima novedad estructural respecto al archivo y deriva preguntas generativas desde sus propias creaciones. El estado se conserva localmente en el dispositivo y puede exportarse/importarse como JSON.

La autonomía está acotada: máximo 100 ciclos por llamada, 8 intentos por ciclo y 500 estructuras archivadas. El motor no comprende semánticamente cualquier dominio, no garantiza utilidad ni verdad, no modifica su código y no es consciente. Requiere el runtime JavaScript, CPU, memoria y energía del dispositivo.


## Odiseo 51.2 — autonomía creadora local

El núcleo `OdiseoCreator` es autocontenido: no importa ni invoca los motores de investigación, el Espejo, red, APIs ni modelos externos. Parte de ocho primitivas y ocho operadores internos; compone árboles sintácticos, valida gramática y límites, conserva padres/generación/procedencia y calcula novedad estructural mediante distancia media entre vectores de rasgos (frecuencias de primitivas, operadores, profundidad y tamaño) respecto al archivo existente. Selecciona padres desde la frontera de mayor novedad. La huella SHA interna detecta alteraciones accidentales del estado exportado.

La ejecución no requiere que el usuario proporcione una pregunta, pero sí requiere iniciar una sesión de creación desde la interfaz o llamar a la API local. No ejecuta ciclos ocultos en segundo plano. Presupuesto: máximo 100 ciclos por llamada, 8 intentos por ciclo, profundidad 12, 127 nodos y archivo máximo 500 estructuras. La gramática actual crea estructuras simbólicas; no interpreta su significado, no garantiza utilidad ni verdad, no reescribe código y no implica conciencia.

## Verificación 51.2

- Núcleo creador: 20 pruebas.
- Batería completa: 186 comprobaciones JavaScript superadas en 12 archivos de prueba, 0 fallos.
- `node --check` del módulo creador y `python -m py_compile`: superados.
- Preparación del generador APK y SHA-256 de los módulos: superadas.
- APK compilada/instalada: no. Gradle/SDK y prueba física pendientes.


## Odiseo 51.3 — Motor Penélope y crecimiento exponencial independiente

Se incorpora `app/src/main/assets/penelope_odiseo.js`: el motor opositor descompone estructuras simbólicas mediante simplificaciones reversibles. Para un operador unario puede retirar el operador y conservar su argumento; para un operador binario puede conservar una rama y deshacer la otra. Cada propuesta conserva el AST original, el candidato, la procedencia, la razón y una huella. Penélope no elimina el original ni declara que la simplificación sea matemáticamente equivalente o semánticamente mejor.

Se incorpora `app/src/main/assets/crecimiento_exponencial_odiseo.js` con capacidades independientes para ambos motores:

`V_(n+1) = V_n * exp(k * p)`

- `V0` de Odiseo y `V0` de Penélope son valores independientes, finitos y estrictamente positivos. Se rechaza cero porque el crecimiento multiplicativo mantendría `V=0` para siempre.
- Cada motor tiene su propia tasa `k`.
- Odiseo recibe progreso `p` a partir de novedad estructural validada.
- Penélope recibe progreso `p` según la proporción de nodos retirados en un desmontaje válido.
- El motor conserva `ln(V)` para evitar desbordamientos; si la capacidad supera el rango de representación numérica, presenta un marcador sin perder el logaritmo.
- La capacidad es una magnitud interna de diseño, no energía física, inteligencia ni potencia de hardware. Las métricas de progreso son estructurales y no prueban utilidad, verdad ni comprensión.

La interfaz Android permite configurar los valores iniciales y las tasas, ejecutar el motor creador, aplicar la oposición de Penélope y conservar/restaurar los estados mediante ODISEO SAVE.

## Verificación 51.3

- 13 baterías JavaScript: **206 comprobaciones superadas, 0 fallos**.
- Penélope y crecimiento exponencial: 21 pruebas nuevas.
- `node --check` de ambos módulos nuevos: superado.
- `python -m py_compile`: superado.
- Generador APK `--solo-preparar`: superado; SHA-256 de ambos módulos incluido en el informe.
- APK compilada/instalada: no. Requiere Gradle/Android SDK y prueba física.

## Odiseo 51.4 — Duelo recíproco Odiseo ↔ Penélope

Se incorpora `app/src/main/assets/duelo_odiseo_penelope.js` y un panel para ejecutar rondas alternadas. El intercambio deja de ser meramente descriptivo:

1. Odiseo crea estructuras AST locales.
2. Penélope examina cada estructura, desmonta ramas y puede volver a tejer restos de ambas ramas con el operador `pair`.
3. La devolución reversible más novedosa que no exista ya en el archivo se incorpora como `penelope-return`, con linaje, validación y huella.
4. La devolución modifica de forma determinista la semilla y el cursor del creador. Además, hasta el 50% de las selecciones de padres puede proceder de las últimas ocho devoluciones Penélope.
5. Odiseo utiliza esos retornos como material posible para nuevas creaciones. Ambos motores registran su propio crecimiento solo cuando existe progreso estructural validado.

El original nunca se borra. El estado del duelo, el archivo creador y las capacidades se exportan/restauran con ODISEO SAVE Android.

**Límites:** hasta 50 rondas por llamada, 200 registros de duelo y 500 estructuras en el archivo creador. La selección de retornos es probabilística y reproducible por semilla. La simplificación/recomposición es estructural: no prueba equivalencia semántica, verdad, utilidad ni inteligencia general. El núcleo sigue necesitando runtime, memoria, CPU y energía locales.

## Verificación 51.4

- 14 baterías JavaScript: **227 comprobaciones superadas, 0 fallos**.
- Duelo recíproco: 21 pruebas nuevas, incluida una prueba de que una devolución Penélope pasa a ser padre de una creación posterior.
- `node --check` de módulos nuevos y modificados: superado.
- `python -m py_compile`: superado.
- Generador APK `--solo-preparar`: superado; informe con SHA-256 del nuevo módulo.
- APK compilada/instalada: no; Gradle/Android SDK y prueba física pendientes.

### Experimento reproducible de realimentación

Con semilla `1`, valores iniciales de capacidad `V0=1` y tasas `k=0.1`, se ejecutaron 3 rondas: 24 creaciones, 24 oposiciones y 16 devoluciones insertadas. En la ronda 2, las 8 creaciones utilizaron al menos un padre devuelto por Penélope; en la ronda 3, 6 de 8. El archivo terminó con 48 estructuras y huella de estado `05cfcd32`. Esto confirma que la influencia estructural se produjo en esa ejecución; no demuestra que las nuevas estructuras sean semánticamente útiles.


## Odiseo 51.5 — Tres pruebas de criterio

Se incorpora `experimento_odiseo_51_5.js`, que ejecuta y conserva el informe `build-output/experimento_51_5.json`. No mezcla una demostración matemática con una búsqueda finita ni con una prueba de robustez del software.

### T1 — Certeza matemática

Afirmación: para todo impar positivo `n`, la Syracuse acelerada `F(n)=(3n+1)/2^v2(3n+1)` es impar y positiva. La demostración es directa: `3n+1` es positivo y par; al dividirlo por su máxima potencia de dos queda, por definición, un entero positivo impar. Odiseo A/B/C/H auditó además los 50.000 impares de 1 a 100.000: cero contraejemplos y 50.000 comprobaciones C sin discrepancias. La demostración general procede del argumento algebraico, no del tamaño del barrido.

### T2 — Hipótesis refutable

Hipótesis: `F(n)<n` para todo impar `n>1`. Queda refutada inmediatamente por `n=3`: `F(3)=(9+1)/2=5`, y `5` no es menor que `3`. El contraejemplo basta para refutar el cuantificador universal.

### T3 — Prueba elegida por el evaluador

Prueba de estrés del duelo Odiseo-Penélope en semillas `1`, `42` y `2026`, cinco rondas cada una. En las tres ejecuciones ambos motores produjeron progreso validado, Penélope insertó devoluciones, los originales permanecieron en el archivo y ambas capacidades internas crecieron. Se repitió además la semilla `77` dos veces: la huella final fue idéntica. Los resultados exactos y huellas están en el informe JSON. Esto verifica invariantes estructurales y reproducibilidad, no calidad semántica ni inteligencia general.

### Verificación 51.5

- Suite de regresión: **227 comprobaciones JavaScript superadas en 14 baterías, 0 fallos**.
- Tres casos experimentales adicionales ejecutados y registrados.
- El informe y el script de reproducción están incluidos.
- La APK no está compilada ni instalada; requiere Gradle/Android SDK y prueba física.

**Límite epistemológico:** la prueba T1 sí contiene una demostración matemática de la propiedad concreta; T2 refuta una hipótesis mediante un contraejemplo; T3 solo valida el comportamiento estructural del software bajo tres semillas y un control de reproducibilidad.


## Odiseo 51.6 — Prueba de independencia

Se añade `independencia_odiseo_penelope.js` y su suite `tests_odiseo_independencia.js`. Odiseo y Penélope reciben copias profundas congeladas del mismo lote de 25 enteros impares positivos generado a partir de una semilla. Cada motor resuelve el lote sin recibir la salida del otro. Antes de abrir la revisión cruzada, el coordinador calcula compromisos SHA-256 de ambas respuestas y del reto. Después, cada motor audita la respuesta del otro con su propia implementación.

### Diferencia de métodos

- Odiseo calcula la valuación 2-ádica mediante operaciones binarias y desplazamientos.
- Penélope calcula el mismo cociente mediante divisiones enteras sucesivas por dos.
- El evaluador externo no repite ninguno de los dos algoritmos: comprueba algebraicamente `sucesor · 2^exponente = 3n+1`, exige que el sucesor sea impar positivo y verifica cobertura de entradas, duplicados y las dos afirmaciones derivadas.

El lote incluye `n=3`, por lo que debe refutar la afirmación universal `F(n)<n` para todo impar `n>1`: `F(3)=5`. También incluye impares divisibles por tres para contrastar la propiedad modular.

### Reproducir

Requiere Node.js 18 o superior (Web Crypto disponible):

```bash
node experimento_independencia_51_6.js 20261104
node tests_odiseo_independencia.js
```

La suite incluye una inyección deliberada de un resultado incorrecto para verificar que el motor contrario y el evaluador externo lo detectan. La prueba normal no presupone que uno de los motores falle; si ambos aciertan, el resultado correcto es concordancia sin errores detectados, no una victoria artificial.

### Límites

La independencia verificada es de entrada, ejecución y algoritmo de cálculo, no de conciencia ni de inteligencia general. Los dos motores se ejecutan en el mismo proceso y comparten el entorno de ejecución; el protocolo impide pasar la respuesta del primero al segundo antes del sellado, pero no constituye aislamiento de seguridad frente a código malicioso. La prueba finita tampoco demuestra la conjetura de Collatz. El módulo se carga en la interfaz Android y dispone de un panel para ejecutar la prueba y conservar un historial local incluido en la copia de seguridad; la APK sigue sin estar compilada ni instalada.

### Resultado ejecutado de 51.6

- Prueba normal: `INDEPENDENCE_PROTOCOL_PASSED`, semilla `20261104`, 25 entradas por motor.
- Odiseo y Penélope entregaron 25 resultados válidos e idénticos; ambos compromisos SHA-256 quedaron registrados antes de la revisión cruzada.
- Contraejemplo mínimo del lote: `F(3)=5`, que refuta `F(n)<n` para todo impar `n>1`. No se encontraron violaciones de la propiedad modular ensayada.
- Inyección de fallo: alteramos deliberadamente una salida de Penélope; Odiseo detectó la discrepancia y el evaluador externo rechazó la respuesta.
- Suite nueva: **17 comprobaciones superadas**. Regresión completa: **244 comprobaciones en 15 baterías, 0 fallos**.
- Informe reproducible: `build-output/experimento_independencia_51_6.json`.

## Odiseo 51.7 — Motor Integrador E

Se incorpora `integrador_odiseo_penelope.js`, un motor E que recibe dos exploraciones realizadas por rutas complementarias, conserva la procedencia, rechaza candidatos inválidos, elimina duplicados y verifica si la unión cubre el espacio completo. El experimento base descompone `n` en parejas no ordenadas de enteros positivos `(a,b)`, con `a+b=n` y `a<=b`: Odiseo recorre valores impares de `a` en orden ascendente; Penélope recorre desde `b` en orden descendente y aporta los valores pares de `a`. Ninguno recibe la salida del otro. E integra ambas ramas.

El informe distingue hallazgos exclusivos de cada motor, coincidencias, rechazos, completitud y contraejemplos. Incluye la demostración de que las soluciones son exactamente `a=1,...,floor(n/2)` y refuta la afirmación «todas las parejas tienen sumandos distintos» cuando `n` es par mediante `(n/2,n/2)`. Es una demostración para esta familia combinatoria, no una prueba de descubrimiento general ni de inteligencia.

### Reproducir 51.7

```bash
node experimento_odiseo_51_7.js 20
node tests_odiseo_integrador.js
```

La batería 51.7 contiene 55 comprobaciones. La regresión completa contiene 299 comprobaciones en 16 baterías, todas superadas. El panel Android permite cambiar `n` y conserva los últimos 100 informes localmente. El generador APK valida la presencia del módulo E y su interfaz. La APK sigue preparada pero no compilada ni instalada en dispositivo.


## Odiseo 51.9 — Judas Tadeo, Laboratorio de Loterías y protocolo Pelayo

Se mantiene íntegro el núcleo 51.7 y se añaden dos módulos independientes:

- `app/src/main/assets/judas_tadeo_odiseo.js`: motor D de diagnóstico de bloqueos y reencuadre. Distingue datos insuficientes, subdeterminación, inconsistencia, representación inadecuada, dificultad computacional, inexistencia demostrada e indecidibilidad relativa a un sistema formal. No etiqueta ideas como pruebas.
- `app/src/main/assets/loterias_odiseo.js`: laboratorio de La Primitiva y Euromillones. Conserva los boletos experimentales originales, valida historiales importados, calibra estadísticas mediante Monte Carlo con selección sin reemplazo, corrige la familia de contrastes con Holm y ejecuta un backtest walk-forward de la regla fría-50 y resume las parejas/tríos observados con sus frecuencias esperadas bajo el modelo nulo (etiquetados solo como descriptivos). La validación de estrellas de Euromillones respeta las matrices históricas 1–9, 1–11 y 1–12. Incluye el protocolo de auditoría física inspirado en el método García-Pelayo; sin trazabilidad de máquina, bolas, mantenimiento y mediciones, devuelve `NO_MECHANISM_DATA`.

### Modelo de trabajo

1. Odiseo descubre patrones y formula hipótesis.
2. Penélope intenta refutarlas y compara con el modelo nulo.
3. Judas Tadeo cambia el marco: auditoría del mecanismo, predicción fuera de muestra, posible reparto del premio o valor esperado neto.
4. Integrador E conserva procedencia, valida cálculos y registra límites.

### Boletos congelados

- La Primitiva: `7, 14, 23, 31, 38, 46`; reintegro `6`.
- Euromillones: `9, 18, 27, 36, 49`; estrellas `4, 11`.

### Datos y límites

El laboratorio no descarga resultados por sí mismo. Se deben importar sorteos oficiales en JSON cronológico: `[{'date':'AAAA-MM-DD','numbers':[...],'extras':[...]}]` (JSON real con comillas dobles). Para La Primitiva `extras` contiene el reintegro 0–9; para Euromillones contiene las dos estrellas, validadas según la matriz vigente en la fecha del sorteo (1–9 hasta 2011-05-06; 1–11 desde 2011-05-10 hasta 2016-09-23; 1–12 desde 2016-09-27). Sin datos, el módulo solo presenta probabilidades teóricas. Una señal estadística requiere replicación temporal independiente. La regla fría-50 no altera las probabilidades de extracción. Estudiar si una combinación reduce el premio compartido exige datos de apuestas elegidas por jugadores, no solo resultados.

### Verificación 51.9

- 42 pruebas del laboratorio y Judas Tadeo, incluidas comprobaciones sobre reglas históricas, asociaciones y ausencia de datos físicos.
- Regresión total prevista: 341 comprobaciones en 17 baterías, 0 fallos.
- `node --check` y preparación del generador APK: superados.
- APK: no compilada ni instalada.
- Historial oficial: todavía no importado; no existe conclusión empírica sobre patrones o predicción.


## Odiseo 52.0 — Sherlock, investigador de rastros mínimos

Se incorpora `app/src/main/assets/sherlock_odiseo.js` y una interfaz local. Sherlock acepta rastros estructurados con identificador, observación, procedencia, fecha, enlaces declarados y confianza opcional. Detecta referencias rotas, fragmentos aislados, fuentes distintas, observaciones repetidas y contradicciones entre rastros que apoyan o cuestionan hipótesis. Ordena por completitud documental, no por verdad ni por supuesta importancia oculta.

API: `window.OdiseoSherlock.analyze({traces, hypotheses, budget})`. La salida conserva rastros aceptados/rechazados, red explícita, hipótesis y límites. No infiere enlaces semánticos ni causalidad. Suite nueva: `node tests_odiseo_sherlock.js` (13 comprobaciones).


## Odiseo 52.1 — Sherlock adaptable y búsqueda por representaciones

Sherlock deja de tratar la ausencia de enlaces explícitos como final de la investigación. `window.OdiseoSherlock.investigate({traces, hypotheses, budget, strategyBudget})` intenta, de forma trazable, cuatro vías: enlaces declarados, coincidencias léxicas, firmas numéricas y proximidad temporal. Devuelve el registro de estrategias, candidatos, próximos pasos y advertencias. Si una vía no encuentra candidatos, propone cambiar la representación, buscar nuevas fuentes, probar transformaciones/desfases y solicitar controles nulos y refutación de Penélope.

Las relaciones sugeridas son pistas, no hechos: coincidencia léxica puede ser casual, valores compartidos no implican dependencia y proximidad temporal no implica causalidad. La salida no declara anomalías estadísticas ni capacidad predictiva. Odiseo puede proponer estrategias adicionales; Penélope debe contrastarlas con controles nulos y datos independientes; Integrador E conserva el estado epistémico.

API anterior `analyze` se conserva por compatibilidad; la interfaz utiliza `investigate`. Suite Sherlock: 14 comprobaciones sintéticas. Regresión: 17 baterías existentes superadas. APK no compilada ni instalada.

## Odiseo 52.2 — Sherlock consciente de la evidencia

Se corrige una debilidad detectada en auditoría: la proximidad temporal ya no crea enlaces por sí sola. Las fechas únicamente anotan candidatos obtenidos por otras vías. La coincidencia léxica prioriza términos relativamente raros; el análisis numérico detecta valores compartidos y patrones de diferencias consecutivas. Se impone un límite explícito de pares para evitar explosión combinatoria. Los candidatos incluyen interpretación y advertencia, no una conclusión causal.

API: `window.OdiseoSherlock.investigate({traces, hypotheses, budget, strategyBudget})`. Suite Sherlock: 15 pruebas sintéticas. Las 18 baterías `tests_*.js` terminan con código cero. Esto no equivale a 18 validaciones científicas ni demuestra significación estadística. Pendiente: modelo nulo apropiado, permutaciones, corrección por multiplicidad, holdout, fuentes independientes e integración ejecutable con Penélope. APK no compilada ni instalada.


## Odiseo 52.4 — Integrador de Evidencias OIE
Nuevo módulo local `app/src/main/assets/integrador_evidencias_odiseo.js`. API: `OdiseoEvidenceIntegrator.ingest({records})` y `evaluate({records,claims})`. Pruebas: `node tests_odiseo_integrador_evidencias.js`. Véase `AUDITORIA_52_4.md`.


## Odiseo 52.5 — Ciclo integrado A/B/C/D/E/H

Se añade `app/src/main/assets/ciclo_integrado_odiseo.js` y un panel de ciclo integrado en `app/src/main/assets/index.html`. API: `OdiseoIntegratedCycle.run({traces, hypotheses, claims, penelopeAsts, maxTraces, maxAsts, strategyBudget})`. Sherlock produce pistas; Penélope examina AST; Judas Tadeo reencuadra; Integrador E verifica tareas combinatorias finitas; OIE evalúa relaciones explícitas y afirmaciones; H impone presupuestos y parada. Las pistas heurísticas nunca se promueven automáticamente a pruebas. Pruebas: `node tests_odiseo_ciclo_integrado.js` y `node tests_odiseo_integrador_evidencias.js`. La APK continúa sin compilar/instalar hasta disponer de Gradle y Android SDK. Véase `AUDITORIA_52_5.md`.

## Odiseo 52.6 — Núcleo unificado

El núcleo `OdiseoUnifiedCore` coordina 22 módulos mediante adaptadores explícitos y pruebas mínimas, conserva los contratos locales y presenta un informe común desde el panel. La ejecución global no sustituye las normas de cada motor ni equivale a certificar todas sus capacidades. No hay auto-modificación ni aprendizaje autónomo.


## Odiseo 52.7 — Biblioteca Activa

La Biblioteca Activa conserva artefactos, hipótesis, resultados, métodos, reglas, propuestas de mejora y experimentos con procedencia y relaciones explícitas. Las propuestas requieren revisión humana, pruebas sin fallos, evidencia y plan de reversión; solo pueden pasar a staging y nunca modifican código automáticamente. El crecimiento es composicional y medible, no una promesa de exponencialidad. Ver `AUDITORIA_52_7.md`.


## Odiseo 52.8 — Patrón adaptativo bidireccional

El módulo `patron_adaptativo_odiseo.js` examina problemas tanto en la pregunta como en la respuesta candidata, clasifica señales, selecciona un modo de trabajo y recomienda rutas hacia los motores especializados. Registra feedback útil/no útil, falsos positivos, problemas omitidos y correcciones. El feedback modifica estadísticas locales, no los criterios ni el código de los motores. Las rutas son recomendaciones, no ejecución automática universal. Véase `AUDITORIA_52_8.md`.


## Odiseo 53.0 — Auditor de comunicación

Se añade `OdiseoCommunicationAuditor`, instrumentación de cinco llamadas del ciclo integrado y de ambos sentidos del duelo Odiseo/Penélope. La auditoría reproducible está en `AUDITORIA_53_0.md`; la prueba integral en `tests_odiseo_auditoria_integral_53_0.js`. Resultado: ciclo 5/5 intercambios sin incidencias; duelo 48/48 sin incidencias en tres rondas; núcleo unificado 23/23 smoke tests; regresión 27/27. La cobertura es parcial: no todos los flujos del sistema están instrumentados. Las huellas FNV-1a no son criptográficas y la APK no se ha compilado ni instalado.


## Odiseo 53.1 — Lenguaje de comunicación ODQ/ODA

Se incorpora `app/src/main/assets/lenguaje_comunicacion_odiseo.js`. ODQ formula preguntas con intención, sujeto, operación, alcance, evidencia, restricciones, formato y condición de parada. ODA enlaza la respuesta con la pregunta y declara estado, afirmación, resultado, evidencia, método, incertidumbre y límites. El evaluador puntúa estructura y trazabilidad declarada; no evalúa verdad ni pertinencia semántica.

- Especificación: `LENGUAJE_COMUNICACION_53_1.md`.
- Pruebas: `node tests_odiseo_lenguaje_comunicacion.js`.
- Regresión: 28/28 archivos `tests_*.js` superados en el cierre 53.1.

## Odiseo 53.2 — Semáforo de integridad

La versión 53.2 incorpora un semáforo fail-closed en la interfaz y auditoría de invocación/respuesta para los 25 módulos del núcleo unificado. El verde exige cobertura observada completa, auditoría limpia, validación ODQ/ODA central y smoke tests coincidentes con el inventario. El verde está limitado a esas rutas y no certifica verdad semántica ni adopción interna de ODQ/ODA en todos los motores. Consulta `AUDITORIA_53_2.md` y `build-output/semaforo_integral_53_2.json`.

## Odiseo 53.2 — TIC 1.1 experimental

Se añade `app/src/main/assets/tic_odiseo.js`, cargado en `index.html`, para estudiar transmisión informativa lateral y bidireccional entre elementos y conjunto. Incluye entropía, información mutua/condicional, transferencia de entropía de primer retardo, conservación/pérdida operacional, redundancia y una brecha exploratoria de sinergia. Cinco controles sintéticos reproducibles cubren independencia, canal ruidoso, XOR, retroalimentación y desconexión del canal descendente.

Ver `TIC_1.1_MODELO_EXPERIMENTAL.md`, `AUDITORIA_TIC_1.1.md` y `build-output/RESULTADOS_TIC_1.1.json`. TIC 1.1 superó 16 aserciones específicas; la regresión completa pasó 31/31 suites. El generador APK detecta el nuevo módulo. **No** está aún conectado a la orquestación semántica de los motores; no se ha compilado ni instalado APK. La brecha sinérgica no es una PID general y la transferencia de entropía no demuestra causalidad por sí sola. Se mantiene como rama experimental de 53.2, no como versión global 53.3.

## Odiseo 53.3-alpha — TIC 1.2 inferencial experimental

Se añade `app/src/main/assets/tic_inferencia_odiseo.js`, cargado tras TIC 1.1. El módulo incorpora PID de dos fuentes Williams–Beer `I_min`, transferencia de entropía condicionada a confusores observados, intervalo percentil mediante moving-block bootstrap y contraste nulo por desplazamiento circular con corrección exploratoria de sesgo. El validador de preparación APK comprueba el módulo y registra su SHA-256.

- Prueba específica: `node tests_odiseo_tic_inferencia.js` (13 aserciones).
- Regresión: 32/32 archivos `tests_*.js` superados; 30/30 módulos JS de assets pasan `node --check`.
- Preparación APK: `PREPARADO`; APK no compilada ni instalada.
- Límites: `I_min` es una definición PID concreta, no universal; el nulo circular requiere estacionariedad; el bootstrap por bloques es aproximado; los confusores no observados y retardos múltiples siguen pendientes. El módulo no está conectado al orquestador semántico ni probado con datos externos.

Estado: **rama 53.3-alpha**, no versión estable global. Véase `TIC_1.2_ALPHA.md` y `AUDITORIA_TIC_1.2_ALPHA.md`.


## Odiseo 53.4-alpha — Detector de inactividad Android

Se añade el detector nativo de 30 minutos: reloj persistente, alarma RTC_WAKEUP con `setAndAllowWhileIdle`, receptores para alarma y reinicio, verificación al reabrir, auditoría local de recuperación y exportación del informe dentro del diario ODISEO SAVE. La auditoría se ejecuta al regresar a la interfaz; no inicia motores en segundo plano. Véase `ODISEO_53.4_INACTIVITY_ANDROID.md`. APK sin compilar/instalar y prueba física pendientes.

## 53.6-alpha — independencia local de GPT

Se añade `app/src/main/assets/herramientas_independencia_odiseo.js`, con procesador lingüístico determinista, memoria local con procedencia y registro de contratos allowlist para seis capacidades locales. El chat admite `Herramientas locales`, `Recuerda local: contenido | fuente: origen` y `Recupera local: consulta`. No incorpora GPT, API remota, red ni un modelo neuronal local. No es un LLM. Ver `INDEPENDENCIA_GPT_53_6_ALPHA.md`.


## Odiseo 53.9-alpha — Respaldo de memoria semántica

El ZIP ODISEO SAVE incorpora ahora `diary.semantic_memory`. La restauración valida esquema, máximo de registros, procedencia obligatoria e IDs únicos antes de confirmar y escribir. La batería nueva pasa 18/18 aserciones; regresión 42/42 suites; sintaxis 34/34 activos JS; Python 3/3; preparación del generador APK superada. La APK no está compilada ni instalada: este entorno carece de Android SDK y Gradle. La memoria continúa siendo BM25 léxica; no es un modelo neuronal ni un LLM.


Consulta `PLAN_54_0_MODELO_NEURONAL_LOCAL.md` para la selección preliminar del runtime Android y los modelos candidatos; no implica que estén integrados.


## Estado de reconstrucción 55.0-alpha (2026-11-12)

Consultar `ODISEO_55.0_ALPHA_AUDITORIA_Y_CAMBIOS.md`. La rama parte del paquete SDK 54.2; 53.2 sigue estable. Primer cambio: detector adaptativo conservador. La APK y la inferencia neuronal en Android siguen pendientes.
