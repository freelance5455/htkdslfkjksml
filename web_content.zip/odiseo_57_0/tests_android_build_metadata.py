#!/usr/bin/env python3
"""Static consistency checks for the Odiseo 57.0 Android build metadata."""
from pathlib import Path
import json
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

class AndroidBuildMetadataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gradle = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
        cls.manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
        cls.state = json.loads((ROOT / "ESTADO_ODISEO.json").read_text(encoding="utf-8"))

    def test_version_code(self):
        self.assertRegex(self.gradle, r"\bversionCode\s+570\b")

    def test_version_name(self):
        self.assertIn("versionName '57.0-alpha-central-brain'", self.gradle)

    def test_litertlm_pin(self):
        self.assertIn("com.google.ai.edge.litertlm:litertlm-android:0.18.0", self.gradle)

    def test_coroutines_align_with_litertlm_018(self):
        self.assertIn("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0", self.gradle)

    def test_min_sdk(self):
        self.assertRegex(self.gradle, r"\bminSdk\s+24\b")

    def test_microphone_permission_declared(self):
        permissions = [x.get(ANDROID_NS + "name") for x in self.manifest.findall("uses-permission")]
        self.assertIn("android.permission.RECORD_AUDIO", permissions)

    def test_internet_permission_declared_for_hybrid_mode(self):
        permissions = [x.get(ANDROID_NS + "name") for x in self.manifest.findall("uses-permission")]
        self.assertIn("android.permission.INTERNET", permissions)
        java = (ROOT / "app/src/main/java/org/odiseo/app/MainActivity.java").read_text(encoding="utf-8")
        self.assertIn("requestHybrid", java)
        self.assertIn("setInstanceFollowRedirects(false)", java)
        self.assertIn('"https".equalsIgnoreCase', java)

    def test_stable_branch_unchanged(self):
        self.assertEqual(self.state.get("software_version"), "53.2")
        self.assertEqual(self.state.get("project_version"), "57.0-alpha-central-brain")

    def test_experimental_branch_recorded(self):
        self.assertIn("57.0-alpha-central-brain", self.state.get("experimental_branches", {}))

    def test_voice_components_present(self):
        java = (ROOT / "app/src/main/java/org/odiseo/app/MainActivity.java").read_text(encoding="utf-8")
        html = (ROOT / "app/src/main/assets/index.html").read_text(encoding="utf-8")
        self.assertIn("SpeechRecognizer", java)
        self.assertIn("TextToSpeech", java)
        self.assertIn('id="odiseoVoiceListen"', html)
        self.assertIn('id="odiseoVoiceToggle"', html)
        self.assertIn("odiseoOnSpeechResult", html)

if __name__ == "__main__":
    unittest.main(verbosity=2)
