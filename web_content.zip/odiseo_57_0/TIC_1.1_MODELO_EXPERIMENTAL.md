# Odiseo TIC 1.1 — Modelo experimental depurado

**Estado:** implementado como módulo experimental local y probado con datos sintéticos. No validado en datos reales ni integrado en la orquestación semántica de motores.

## 1. Propósito y alcance

TIC estudia información entre elementos, entre elementos e interacciones, y entre elementos y el conjunto global. Contempla transmisión lateral, ascendente y descendente, incluida la retroalimentación. El módulo implementado se limita por ahora a variables discretas y series temporales finitas.

## 2. Definiciones operativas

- Entropía: `H(X)` en bits.
- Información mutua: `I(X;Y)`, información compartida, simétrica; no identifica dirección causal.
- Información mutua condicional: `I(X;Y|Z)`.
- Transferencia de entropía de primer retardo: `TE(X→Y)=I(X[t-1];Y[t]|Y[t-1])`. Es direccional y predictiva, pero no prueba causalidad por sí sola.
- Conservación informativa operativa: `I(X;Y)/H(X)`, fracción de entropía de origen compartida con el receptor. No equivale a recuperación perfecta ni a una conservación física.
- Pérdida informativa operativa: `H(X|Y)/H(X)`, complementaria de la conservación bajo esta definición y el mismo par de variables. No se presenta como ley universal.
- Redundancia: `I(R1;R2)` entre receptores. Describe información compartida entre ellos; no es por sí sola una PID de redundancia respecto a una fuente.
- Integración observada: `I((X1,...,Xn);G)` frente a `I(Xi;G)` individuales.
- Brecha de cribado sinérgico: `max(0, I((X1,...,Xn);G)-max_i I(Xi;G))`. Es solo una alarma exploratoria. No es una descomposición de información parcial (PID), no asigna sinergia formal y no demuestra emergencia general.
- Eficiencia informativa: `I(X;Y)/coste`, con coste positivo explícito y unidades declaradas. No comparar valores si los costes usan unidades distintas.

## 3. Escenarios sintéticos

1. **A — Independencia sin canal:** tres secuencias binarias independientes; sirve de control negativo.
2. **B — Canal ruidoso y receptores redundantes:** cada receptor recibe con ruido una copia retardada de la fuente; permite medir transferencia dirigida, conservación/pérdida y dependencia entre receptores.
3. **C — Sinergia XOR conocida:** dos bits independientes no informan individualmente sobre su XOR, mientras que la pareja determina el objetivo. Valida este patrón concreto, no cualquier forma de emergencia.
4. **D — Retroalimentación bidireccional:** el elemento influye en el conjunto y el conjunto influye en el elemento con un retardo.
5. **D-control — Canal descendente desconectado:** se interviene sobre el mecanismo artificial; se comprueba que desaparece la transferencia global→elemento mientras se conserva la ascendente.

## 4. Resultados reproducibles

Ejecución: Node.js, `TIC.runSuite({samples:12000})`, semillas fijas incorporadas en el módulo.

| Escenario | Resultado | Lectura limitada |
|---|---:|---|
| A: TE A→Y | 0.000201 bits | Compatible con independencia en esta muestra. |
| B: TE fuente→receptor 1 | 0.391640 bits | El estimador detecta el canal retardado y ruidoso. |
| B: conservación receptor 1 | 0.391760 | Aproximadamente 39.18% de la entropía de origen compartida. |
| B: pérdida receptor 1 | 0.608240 | Aproximadamente 60.82% no compartida bajo esta definición. |
| B: MI entre receptores | 0.177315 bits | Los receptores comparten información. |
| C: MI fuentes conjuntas→XOR | 0.999997 bits | La pareja casi determina el objetivo. |
| C: mayor MI individual→XOR | 0.000217 bits | Cada fuente aislada aporta prácticamente cero en la muestra. |
| C: brecha de cribado | 0.999780 bits | Detecta el caso XOR construido; no prueba emergencia general. |
| D: TE elemento→global | 0.535820 bits | Flujo predictivo ascendente. |
| D: TE global→elemento | 0.542482 bits | Flujo predictivo descendente. |
| D-control: TE global→elemento | 0.000029 bits | Cae al desconectar el canal descendente. |

## 5. Pruebas

`node tests_odiseo_tic.js`: 16 aserciones superadas. Incluyen controles independientes, canal ruidoso, redundancia entre receptores, XOR, retroalimentación bidireccional, intervención de desconexión, validación de entradas y ejecución de la suite.

## 6. Correcciones respecto a TIC 1.0

- Se sustituyó `I(Xi;Xj)` como indicador direccional por transferencia de entropía condicionada al pasado del receptor.
- Se separó información conjunta de información individual.
- Se rebajó la etiqueta de emergencia a «brecha de cribado sinérgico» hasta implementar PID apropiada.
- Conservación y pérdida tienen definiciones explícitas, complementarias solo en ese marco operacional.
- Causalidad exige intervención; la transferencia de entropía aislada se interpreta como predictiva.
- Se añade coste explícito a la eficiencia.

## 7. Limitaciones y no afirmaciones

- Estimadores plug-in discretos; sesgo de muestra finita y dependencia del tamaño del alfabeto.
- Solo retardo 1; no busca automáticamente retardos ni memoria de orden superior.
- No corrige confusores ocultos, no estima incertidumbre mediante bootstrap y no aplica corrección por búsquedas múltiples.
- El modelo de XOR es un control positivo específico, no una teoría general de emergencia.
- La intervención prueba el mecanismo artificial que se programó; no demuestra causalidad en un sistema físico real.
- El módulo se carga en la aplicación, pero aún no está conectado al ciclo de orquestación de los 25 motores ni tiene interfaz propia.
- No se han ejecutado pruebas en Android ni compilado/instalado APK.

## 8. Siguiente fase

TIC 1.2 debería incorporar: estimación de incertidumbre, corrección de sesgo/muestra, búsqueda preregistrada de retardos, PID explícita con definición de fuentes/objetivo, confusores y pruebas de intervención en datasets externos. La integración con Sherlock, Penélope, Judas Tadeo e Integrador E requiere contratos y trazas específicas antes de declararla operativa.
