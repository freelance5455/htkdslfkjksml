# Auditoría Odiseo 52.7 — Biblioteca Activa

## Objetivo
Crear una biblioteca persistente y gobernada que permita conservar conocimiento depurado, reutilizarlo, enlazarlo y proponer mejoras sin modificar automáticamente los motores.

## Implementación
- Nuevo `app/src/main/assets/biblioteca_activa_odiseo.js` (`OdiseoActiveLibrary`).
- Almacenamiento local versionado en `localStorage` con límites de retención.
- Artefactos tipados: OBSERVATION, HYPOTHESIS, METHOD, RESULT, TEST, RULE y CODE_REFERENCE.
- Un artefacto VALIDATED exige evidencias y limitaciones explícitas.
- Propuestas pasan por PENDING_REVIEW; la revisión exige pruebas superadas, cero fallos, evidencia, plan de reversión y revisión humana. La promoción solo las deja en `STAGED_NOT_APPLIED`; no toca el código.
- Relaciones explícitas: DERIVED_FROM, SUPPORTS, CONTRADICTS y REUSES.
- Experimentos PASSED requieren declarar holdout; la declaración no certifica por sí sola que el holdout sea correcto o independiente.
- Incorporación de resultados del núcleo unificado como RESULT/UNVALIDATED, nunca como conocimiento validado por defecto.
- Panel de biblioteca en la interfaz y comprobación del módulo en el generador APK.

## Verificación
- 23/23 archivos de pruebas `tests_*.js` ejecutados sin fallos.
- Test específico de biblioteca: registro, validación, enlaces, rechazo de revisión incompleta, staging, holdout y políticas.
- `node --check` en todos los assets JavaScript.
- `python -m py_compile` de scripts Python.
- `python probar_generador.py`: preparación APK ejecutada; no equivale a compilar ni instalar APK.

## Límites y garantías
- El crecimiento es composicional: la biblioteca facilita reutilizar artefactos y relaciones, pero no garantiza crecimiento exponencial de capacidad.
- Persistencia en almacenamiento local del navegador/dispositivo; no sincroniza automáticamente entre dispositivos ni ofrece almacenamiento remoto.
- No hay autoedición, autoentrenamiento ni promoción automática de hipótesis.
- La etiqueta VALIDATED representa una decisión documental interna apoyada por evidencias registradas; no garantiza verdad externa.
- Un holdout declarado debe auditarse para comprobar que realmente no se usó durante el desarrollo.
- La APK no se ha compilado ni instalado.
