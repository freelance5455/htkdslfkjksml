# Odiseo 57.0-alpha — Cerebro central neurálgico

Fecha: 2026-11-20
Base: `ODISEO_56.0_ANDROIDIDE_BUILD_READY.zip` (fuente 56.0, 693,492 bytes).

## Decisión arquitectónica

Se adopta un director central único (`OdiseoCentralBrain`) en modo `ALL`. Los motores mantienen su independencia y el director clasifica el objetivo, puntúa las capacidades relevantes, consulta el inventario real, prioriza motores disponibles y coordina el cerebro cognitivo existente.

## Cambios

- Nuevo `app/src/main/assets/cerebro_central_odiseo.js`.
- Carga del director central después de `cerebro_cognitivo_odiseo.js` y antes del asistente local.
- Integración del chat neuronal local: el director central prepara el contexto y consolida la auditoría.
- Política de seguridad: solo se ejecutan contratos allowlisted ya existentes; los motores sin contrato se priorizan/recomiendan pero no se simula su ejecución.
- Registro de límites: selección heurística, sin conciencia, sin entrenamiento de pesos y sin verificación factual externa automática.
- Android `versionCode 570`, `versionName 57.0-alpha-central-brain`.

## Validación

- 52/52 archivos de pruebas Node superados, incluyendo el nuevo test del director central.
- Sintaxis JavaScript de los assets: 37/37 PASS.
- Metadatos Android: 10/10 PASS.
- Sintaxis de scripts Python de construcción/respaldo: 2/2 PASS.
- Preparación del proyecto Android verificada por estructura y metadatos.
- APK no compilada ni instalada en dispositivo en esta ejecución.
- No se ha verificado inferencia real del modelo LiteRT-LM ni servicios HTTPS en un teléfono.

## Cómo compilar

Abrir la carpeta raíz del ZIP (la que contiene `settings.gradle`) en Android Studio o AndroidIDE y ejecutar `:app:assembleDebug`. Requiere JDK 17, Android SDK 35 y acceso a repositorios Gradle para resolver dependencias.

## Próximo paso

Compilar APK en entorno Android real, instalarla, cargar un modelo LiteRT-LM compatible y probar el ciclo de chat completo en dispositivo. Después, ampliar contratos ejecutables de motores de forma individual, con entradas validadas y pruebas por motor.
