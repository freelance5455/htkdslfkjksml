# Odiseo 57.0 — preparación de APK Android

## Estado comprobado en este paquete

- Proyecto fuente: `57.0-alpha-central-brain`, `versionCode 570`.
- `minSdk 24`, `compileSdk 35`, `targetSdk 35`.
- JDK requerido: 17.
- Android SDK requerido: Platform 35 y Build Tools 35.0.0.
- Gradle requerido: 8.13 (AGP 8.13.2).
- Dependencia neuronal declarada: LiteRT-LM Android 0.18.0.
- Pruebas repetidas en el entorno de preparación: 51/51 archivos de pruebas Node ejecutados correctamente.
- **APK aún no compilada ni instalada.**

## Compilar desde AndroidIDE / IDE Android

1. Extrae el ZIP completo.
2. Abre como proyecto la carpeta `odiseo_57_0`, donde están `settings.gradle` y `build.gradle`.
3. Configura JDK 17 y permite la sincronización de Gradle.
4. Comprueba que el SDK Platform 35 y Build Tools 35.0.0 están instalados.
5. Ejecuta la tarea `:app:assembleDebug`.
6. La salida esperada es `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar en GitHub Actions

El paquete incluye `.github/workflows/build-apk.yml`. Si subes el contenido de esta carpeta a un repositorio GitHub propio, puedes abrir **Actions → Build Odiseo Android APK → Run workflow**. Si la compilación termina correctamente, el workflow publica el artefacto `Odiseo-57.0-alpha-debug-apk`, con el APK y su SHA-256.

## Compilar con SDK y Gradle ya instalados

Desde esta carpeta:

```bash
bash CONSTRUIR_CON_ANDROID_SDK.sh
```

El script exige `ANDROID_HOME` o `ANDROID_SDK_ROOT`, Java y Gradle en `PATH`.

## Límites

- Este paquete no contiene un APK precompilado.
- No incluye un modelo neuronal `.litertlm`; hay que importar uno compatible en la aplicación.
- No se ha probado todavía la inferencia LiteRT-LM en un dispositivo físico.
- La generación remota de imágenes necesita configurar un proveedor compatible y sus credenciales.
- La rama 57.0 es experimental; la versión estable histórica indicada por el proyecto sigue siendo 53.2.
