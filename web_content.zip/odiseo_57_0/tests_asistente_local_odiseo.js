'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');
const store=new Map();const ctx={console,Date,Math,JSON,window:{},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;ctx.OdiseoUnifiedCore={run:async()=>({status:'PASS',executed:2,total:2,failed:0})};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/asistente_local_odiseo.js','utf8'),ctx);
(async()=>{
 assert.equal(ctx.OdiseoLocalAssistant.describe().remoteModel,false);
 assert.match((await ctx.OdiseoLocalAssistant.reply('hola')).text,/núcleo conversacional local/i);
 assert.match((await ctx.OdiseoLocalAssistant.reply('que motores tienes')).text,/Sherlock/);
 assert.match((await ctx.OdiseoLocalAssistant.reply('que eres')).text,/No tengo evidencia de conciencia/);
 assert.match((await ctx.OdiseoLocalAssistant.reply('auditar el sistema')).text,/Módulos ejecutados: 2\/2/);
 assert.equal(ctx.OdiseoLocalAssistant.history().filter(x=>x.role==='assistant').length,4);
 ctx.OdiseoLocalAssistant.clear();assert.equal(ctx.OdiseoLocalAssistant.history().length,0);
 console.log('PASS 6/6 — asistente local, inventario, identidad, auditoría async, persistencia y borrado');
})().catch(e=>{console.error(e);process.exit(1)});
