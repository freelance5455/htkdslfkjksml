# Odiseo — índice móvil (checkpoint 55.1-alpha)

**Rama experimental actual:** 55.1-alpha-cognitive-tool-dispatch. **Estable:** 53.2.

El ciclo cognitivo ejecuta capacidades allowlisted para Sherlock, Penélope, Judas Tadeo, ESPEJO y núcleo unificado; las trazas distinguen ejecución real, falta de datos, indisponibilidad y error. TIC y Laboratorio de loterías aún no están integrados al despacho. Android build, APK e inferencia física siguen pendientes. Ver `AUDITORIA_55.1_ALPHA.md` y `VALIDACION_55.1_ALPHA.md`.

---

# ODISEO — ÍNDICE MAESTRO MÓVIL
**Edición:** 5-11-2026  
**Formato:** Markdown ligero, legible en Android  
**Función:** acceso rápido al proyecto; no sustituye los archivos fuente.

## 1. Reanudar el proyecto
En ChatGPT, escribe **«Odiseo»**. La continuidad debe seguir este orden:

1. Leer `ODISEO_CONTINUIDAD_MAESTRA.md` (historial y mapa de artefactos).
2. Contrastar `ESTADO_ODISEO.json` (estado y versiones).
3. Buscar `DIARIO_ODISEO.json`; no darlo por existente si no aparece.
4. Revisar la última auditoría, resultados y ZIP exacto antes de cambiar código.
5. Continuar desde el último punto realmente probado.

## 2. Punto de control documentado
- **Software estable:** 53.2.
- **Ramas experimentales:** 53.3-alpha / TIC 1.2-alpha y 53.4-alpha / Detector Android de inactividad.
- **Android:** 53.4-alpha incorpora el detector nativo de 30 minutos y auditoría local al reanudar. El código está preparado y probado a nivel de fuentes; APK sin compilar/instalar y prueba física pendientes.
- Implementación declarada, preparación, compilación, instalación y prueba real son estados distintos.

Verificar estos datos contra `ESTADO_ODISEO.json` al reanudar.

## 3. Archivos prioritarios de la Biblioteca
Buscar por nombre exacto:

- `ODISEO_CONTINUIDAD_MAESTRA.md` — índice histórico y técnico principal.
- `ESTADO_ODISEO.json` — estado vigente y hoja de ruta.
- `DIARIO_ODISEO.json` — diario operativo; existencia por confirmar.
- `AUDITORIA_TIC_1.2_ALPHA.md` — auditoría de la rama experimental.
- `RESULTADOS_TIC_1.2_ALPHA.json` — resultados estructurados.
- ZIP exacto de la versión que se vaya a modificar.
- Para TIC 1.1: `AUDITORIA_TIC_1.1.md`, `TIC_1.1_MODELO_EXPERIMENTAL.md`, `RESULTADOS_TIC_1.1.json`.

Los nombres son referencias de búsqueda, no garantía de presencia actual.

## 4. Próximos trabajos registrados
1. Auditoría independiente de TIC 1.2-alpha.
2. Controles adversariales: confusor común, autocorrelación, tendencias, rupturas y selección de retardos.
3. Comparación de `I_min` con otra definición PID y, después, datos externos con procedencia y holdout.
4. Instrumentación real de intercambios con Sherlock, Penélope, Judas Tadeo e Integrador E.
5. Compilación, instalación y prueba física de APK Android, como tarea separada.

## 5. Protocolo de cada avance
Registrar hipótesis falsable, datos y procedencia, método, parámetros, semilla, controles, resultados, pruebas ejecutadas, fallos, límites, archivos y SHA-256. Conservar resultados negativos y versiones anteriores.

No declarar «integrado», «validado», «guardado» o «terminado» sin evidencia comprobable.

## 6. Guardar una copia en Android
**Método inmediato y verificable:**

1. Descarga este archivo desde ChatGPT.
2. En Android, abre **Archivos** y entra en `Descargas`.
3. Crea `Odiseo` si no existe.
4. Mueve o copia este archivo a `Descargas/Odiseo/`.
5. Comprueba que aparece y que puedes abrirlo.

**Método de respaldo de la app Odiseo (pendiente de verificación física):** el estado declara exportación ZIP mediante el selector SAF. Antes de confiar en él hay que recuperar el ZIP Android correcto, inspeccionar la implementación, compilar la APK, instalarla y probar exportación/restauración con archivos de prueba. La exportación declarada no incluye automáticamente el código fuente ni la APK y no debe suponerse que incorpora este índice Markdown.

## 7. Cierre de sesión
Antes de cerrar, escribe: **«Odiseo, guarda y prepara el cierre»**. Durante la conversación se deben actualizar los artefactos realmente modificados, crear un checkpoint fechado, verificar CRC/SHA-256 y comprobar la Biblioteca. ChatGPT no puede detectar el cierre de la app ni guardar después de desconectarse.

## 8. Regla de continuidad
Este archivo es el índice de bolsillo. El maestro técnico y los archivos originales prevalecen si hay discrepancias. No empezar de cero, no inventar archivos ausentes y no elevar pruebas finitas a demostraciones universales.

## 9. Detector Android de inactividad 53.4-alpha

- Umbral: **30 minutos** sin interacción.
- `AlarmManager.setAndAllowWhileIdle` registra el disparo; un receptor reconstruye el reloj tras reiniciar Android.
- Al volver a primer plano, Odiseo audita la cadena del diario, el JSON del almacenamiento y la presencia de APIs; guarda un informe con SHA-256 en almacenamiento privado.
- El informe se incluye en el diario del ZIP ODISEO SAVE. Después de la auditoría, pulsa «Guardar copia ZIP verificada» y selecciona `Descargas/Odiseo/`.
- Android puede retrasar la alarma por Doze/ahorro de batería. La auditoría JavaScript se ejecuta al volver a primer plano, no mientras la app está cerrada.
- Privacidad: solo actividad dentro de Odiseo; no monitoriza ChatGPT ni otras apps y no captura el texto escrito.
- Estado: código fuente implementado; 8/8 pruebas de política, 32/32 suites JS y preparación APK superadas; compilación, instalación y prueba física pendientes.
- Referencia: `ODISEO_53.4_INACTIVITY_ANDROID.md`.
