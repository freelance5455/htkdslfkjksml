# Auditoría Odiseo 52.2

## Alcance
Actualización focalizada de Sherlock tras auditoría comparativa de 52.1. No se declara que todo el sistema alcance una puntuación científica objetiva ni que exista autonomía general.

## Cambios
- Se elimina la creación automática de enlaces por mera proximidad temporal.
- La fecha solo añade contexto a un candidato generado por otra estrategia.
- Coincidencias léxicas: se priorizan términos de frecuencia documental relativamente baja.
- Coincidencias numéricas: se conservan como pistas, no como dependencia.
- Nueva estrategia: patrones de diferencias consecutivas compartidas.
- Límite de 20.000 pares por estrategia para evitar crecimiento combinatorio descontrolado.
- Advertencias explícitas: no inferir causalidad, anomalía o predicción sin modelo nulo, multiplicidad y validación fuera de muestra.

## Pruebas
- Sherlock 52.2: 15/15 comprobaciones sintéticas.
- Todas las 18 baterías `tests_*.js` ejecutadas con Node terminaron con código cero.
- `node --check` del módulo Sherlock superado.
- ZIP íntegro y manifiesto SHA-256 regenerado.
- APK no compilada ni instalada.

## Límites pendientes
1. No hay todavía motor formal de permutaciones ni modelo nulo genérico: diseñarlo sin conocer el mecanismo de generación de datos sería engañoso.
2. No se ha demostrado rendimiento en un conjunto de benchmark oculto ni en holdout.
3. La invocación automática y real de Penélope no está integrada en Sherlock.
4. La adaptación sigue eligiendo entre estrategias programadas; no inventa e implementa código nuevo autónomamente.
5. La interfaz Android y los flujos de Integrador E requieren pruebas de integración de extremo a extremo.

## Evaluación
La modificación corrige falsos enlaces temporales y amplía las representaciones numéricas. Es una mejora técnica acotada. No justifica por sí sola elevar el sistema a 8/10; esa nota requiere benchmark ciego, tasa de falsos positivos, replicación y cooperación efectiva entre motores.
