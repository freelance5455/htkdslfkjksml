const fs=require('fs'),vm=require('vm'),path=require('path');
const ctx={window:{}};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'app/src/main/assets/integrador_odiseo_penelope.js'),'utf8'),ctx);
const E=ctx.window.OdiseoIntegrator;let passed=0;function ok(x,m){if(!x)throw Error(m);passed++;}
for(const n of [2,3,4,5,10,20,21,50,101,1000]){const r=E.run({n});ok(r.status==='INTEGRATION_PASSED','integración n='+n);ok(r.joint.uniqueValid===Math.floor(n/2),'conteo n='+n);ok(r.claim.proof.enumerationComplete,'completitud n='+n);ok(r.joint.overlap===0,'rutas complementarias sin duplicados n='+n);ok(r.joint.discoveriesOnlyOdiseo+ r.joint.discoveriesOnlyPenelope===Math.floor(n/2),'descubrimientos complementarios n='+n);}
const task={id:'x',kind:'positive_unordered_partitions',n:8};const a=E.solveAscending(task),b=E.solveDescending(task);a.candidates.push({a:0,b:8});let r=E.integrate(task,a,b);ok(r.rejected.length===1,'rechaza candidato inválido');ok(r.status==='REVIEW_REQUIRED','marca revisión por rechazo');
r=E.run({n:8});ok(r.counterexampleClaim.status==='REFUTED','refuta sumandos siempre distintos');ok(r.counterexampleClaim.counterexample.a===4,'contraejemplo diagonal');
let threw=false;try{E.run({n:1})}catch(e){threw=true}ok(threw,'rechaza dominio inválido');
console.log(JSON.stringify({suite:'51.7-integrador-E',passed,failed:0},null,2));
