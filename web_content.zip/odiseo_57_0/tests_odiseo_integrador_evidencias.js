const assert=require('assert');
const fs=require('fs'),vm=require('vm');const ctx={};vm.createContext(ctx);vm.runInContext(fs.readFileSync('app/src/main/assets/integrador_evidencias_odiseo.js','utf8'),ctx);const E=ctx.OdiseoEvidenceIntegrator;
let r=E.ingest({records:[{id:'a',source:'paper-A',sourceFamily:'lab-A',statement:'x'},{id:'b',source:'paper-B',sourceFamily:'lab-B',statement:'x',supports:['a']},{id:'c',source:'paper-C',sourceFamily:'lab-C',statement:'not x',contradicts:['a']}]});
assert.equal(r.recordCount,3);assert.equal(r.edges.length,2);assert.equal(r.sourceFamilies,3);assert.equal(r.rejected.length,0);
let q=E.evaluate({records:[{id:'a',source:'A',sourceFamily:'A',statement:'x'},{id:'b',source:'B',sourceFamily:'B',statement:'x'},{id:'c',source:'C',sourceFamily:'C',statement:'not x'}],claims:[{id:'supported',statement:'x',supporting:['a','b']},{id:'conflict',statement:'x',supporting:['a'],contradicting:['c']},{id:'single',statement:'x',supporting:['a']},{id:'broken',statement:'x',supporting:['missing']}]});
assert.equal(q.claims[0].status,'MULTI_SOURCE_SUPPORTED_NOT_PROVEN');assert.equal(q.claims[1].status,'CONFLICTING_EVIDENCE');assert.equal(q.claims[2].status,'SINGLE_SOURCE_SUPPORT_ONLY');assert.equal(q.claims[3].status,'BROKEN_REFERENCES');
let d=E.ingest({records:[{id:'a',source:'s',statement:'x'},{id:'a',source:'s2',statement:'y'},{id:'b',statement:'z'}]});assert.equal(d.rejected.length,2);assert.equal(d.rejected[0].reason,'DUPLICATE_ID');
assert.notEqual(E.ingest({records:[{id:'a',source:'s',statement:'x'}]}).fingerprint_fnv1a32,E.ingest({records:[{id:'a',source:'s',statement:'y'}]}).fingerprint_fnv1a32);
console.log('OIE: 10 assertions passed');
