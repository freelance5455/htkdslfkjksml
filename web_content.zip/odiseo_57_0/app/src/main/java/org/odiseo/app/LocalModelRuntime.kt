package org.odiseo.app

import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.concurrent.Executors

/** Local inference owner. All LiteRT-LM lifecycle and generation operations are serialized. */
object LocalModelRuntime {
    interface Listener {
        fun onStatus(status: String, detail: String)
        fun onResult(text: String)
        fun onError(message: String)
    }

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "OdiseoLocalModel") }
    @Volatile private var state: String = "NOT_INSTALLED"
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var activePath: String? = null

    @JvmStatic fun status(): String = state

    @JvmStatic fun initialize(modelPath: String, listener: Listener) {
        executor.execute {
            val file = File(modelPath)
            if (state == "READY" && activePath == file.absolutePath && engine != null && conversation != null) {
                listener.onStatus("READY", "Modelo local cargado")
                return@execute
            }
            try { conversation?.close() } catch (_: Throwable) { }
            conversation = null
            try { engine?.close() } catch (_: Throwable) { }
            engine = null
            activePath = null
            if (!file.isFile || !file.canRead() || file.length() < 1_000_000L) {
                state = "NOT_INSTALLED"
                listener.onStatus(state, "No se encuentra un modelo .litertlm válido")
                return@execute
            }
            state = "LOADING"
            listener.onStatus(state, "Cargando modelo local; puede tardar varios segundos")
            var candidate: Engine? = null
            try {
                runBlocking {
                    candidate = Engine(EngineConfig(modelPath = file.absolutePath))
                    candidate!!.initialize()
                    val chat = candidate!!.createConversation(
                        ConversationConfig(
                            systemInstruction = Contents.of(
                                "Eres Odiseo, un asistente local en español. No afirmes que has consultado " +
                                "internet ni que has ejecutado herramientas si no ocurrió. Distingue hechos, " +
                                "inferencias, hipótesis y desconocidos. Cuando no tengas evidencia, dilo. " +
                                "Tus respuestas son propuestas del modelo y no hechos verificados. " +
                                "No inventes fuentes, pruebas ni resultados."
                            ),
                            samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = 0.7)
                        )
                    )
                    engine = candidate
                    conversation = chat
                    activePath = file.absolutePath
                }
                state = "READY"
                listener.onStatus(state, "Modelo neuronal local preparado")
            } catch (t: Throwable) {
                try { candidate?.close() } catch (_: Throwable) { }
                engine = null
                conversation = null
                activePath = null
                state = "ERROR"
                listener.onError(t.message ?: t.javaClass.simpleName)
            }
        }
    }

    @JvmStatic fun send(prompt: String, listener: Listener) {
        executor.execute {
            val chat = conversation
            if (state != "READY" || chat == null) {
                listener.onError("El modelo local no está cargado. Estado: $state")
                return@execute
            }
            state = "RUNNING"
            listener.onStatus(state, "Generando respuesta sin conexión")
            try {
                val output = StringBuilder()
                runBlocking {
                    chat.sendMessageAsync(prompt).collect { message ->
                        val part = message.text
                        if (!part.isNullOrEmpty()) output.append(part)
                    }
                }
                state = "READY"
                listener.onResult(output.toString().trim())
                listener.onStatus(state, "Respuesta generada localmente; pendiente de verificación")
            } catch (t: Throwable) {
                state = "ERROR"
                listener.onError(t.message ?: t.javaClass.simpleName)
            }
        }
    }

    @JvmStatic fun close() {
        executor.execute {
            try { conversation?.close() } catch (_: Throwable) { }
            conversation = null
            try { engine?.close() } catch (_: Throwable) { }
            engine = null
            activePath = null
            state = "NOT_INSTALLED"
        }
    }
}
