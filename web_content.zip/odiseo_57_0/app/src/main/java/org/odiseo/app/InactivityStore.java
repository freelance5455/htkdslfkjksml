package org.odiseo.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/** Persistent native inactivity clock and recovery marker. */
public final class InactivityStore {
    static final String PREFS = "odiseo_inactivity_v1";
    static final String LAST = "last_activity_ms";
    static final String PENDING = "recovery_pending";
    static final String PENDING_JSON = "recovery_json";
    private static final int REQUEST_CODE = 5304;
    private InactivityStore() {}
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, InactivityReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, REQUEST_CODE, i, flags);
    }
    public static void initializeOrCheck(Context c) {
        SharedPreferences p = prefs(c);
        long now = System.currentTimeMillis();
        long last = p.getLong(LAST, 0L);
        if (last <= 0L) { p.edit().putLong(LAST, now).apply(); schedule(c, now); return; }
        checkAndMark(c, now, last);
        if (!p.getBoolean(PENDING, false)) schedule(c, last);
    }
    public static void registerActivity(Context c) {
        long now = System.currentTimeMillis();
        prefs(c).edit().putLong(LAST, now).apply();
        schedule(c, now);
    }
    static void schedule(Context c, long last) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long when = last + InactivityPolicy.TIMEOUT_MS;
        PendingIntent pi = alarmIntent(c);
        am.cancel(pi);
        if (android.os.Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
    }
    static void checkAndMark(Context c, long now, long last) {
        if (!InactivityPolicy.isInactive(now, last)) return;
        SharedPreferences p = prefs(c);
        if (p.getBoolean(PENDING, false)) return;
        try {
            JSONObject event = new JSONObject();
            event.put("schema", "ODISEO_INACTIVITY_EVENT_1");
            event.put("detected_at_ms", now);
            event.put("last_activity_ms", last);
            event.put("inactive_ms", now - last);
            event.put("threshold_ms", InactivityPolicy.TIMEOUT_MS);
            event.put("trigger", "ANDROID_ALARM_OR_FOREGROUND_CHECK");
            event.put("audit_status", "PENDING_LOCAL_RECOVERY_AUDIT");
            p.edit().putBoolean(PENDING, true).putString(PENDING_JSON, event.toString()).apply();
            appendEvent(c, event.toString());
        } catch (Exception ignored) {
            p.edit().putBoolean(PENDING, true).putString(PENDING_JSON, "{\"audit_status\":\"PENDING_LOCAL_RECOVERY_AUDIT\"}").apply();
        }
    }
    static void appendEvent(Context c, String json) {
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(c.getFilesDir(), "ODISEO_INACTIVITY_EVENTS.jsonl"), true), StandardCharsets.UTF_8))) {
            w.write(json); w.newLine();
        } catch (Exception ignored) {}
    }
    public static String pendingJson(Context c) {
        SharedPreferences p = prefs(c);
        return p.getBoolean(PENDING, false) ? p.getString(PENDING_JSON, "{}") : "null";
    }
    public static String persistAudit(Context c, String report) throws Exception {
        byte[] bytes = report.getBytes(StandardCharsets.UTF_8);
        String hash = sha256(bytes);
        JSONObject envelope = new JSONObject();
        envelope.put("schema", "ODISEO_INACTIVITY_AUDIT_ENVELOPE_1");
        envelope.put("stored_at", System.currentTimeMillis());
        envelope.put("sha256", hash);
        envelope.put("report", new JSONObject(report));
        File target = new File(c.getFilesDir(), "ODISEO_AUDITORIA_INACTIVIDAD.json");
        File temp = new File(c.getFilesDir(), "ODISEO_AUDITORIA_INACTIVIDAD.json.tmp");
        try (FileOutputStream out = new FileOutputStream(temp)) { out.write(envelope.toString(2).getBytes(StandardCharsets.UTF_8)); out.getFD().sync(); }
        if (target.exists() && !target.delete()) throw new Exception("No se pudo sustituir la auditoría anterior");
        if (!temp.renameTo(target)) throw new Exception("No se pudo confirmar el archivo de auditoría");
        SharedPreferences p = prefs(c);
        p.edit().putBoolean(PENDING, false).putString("last_audit_sha256", hash).putLong("last_audit_ms", System.currentTimeMillis()).apply();
        JSONObject event = new JSONObject(); event.put("schema", "ODISEO_INACTIVITY_AUDIT_STORED_1"); event.put("stored_at", System.currentTimeMillis()); event.put("sha256", hash); event.put("file", target.getName());
        appendEvent(c, event.toString());
        return hash;
    }
    static String sha256(byte[] b) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(b); StringBuilder s = new StringBuilder();
        for (byte x : d) s.append(String.format(Locale.US, "%02x", x)); return s.toString();
    }
}
