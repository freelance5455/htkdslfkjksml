package org.odiseo.app;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 8101, OPEN_BACKUP = 8102, OPEN_MODEL = 8103;
    private WebView web;
    private byte[] pendingBackup;
    private static final String MODEL_PREFS = "odiseo_local_model";
    private static final String MODEL_PATH_KEY = "active_path";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageReady = false;
    private boolean auditDispatching = false;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private boolean speechListening = false;
    private static final int REQUEST_AUDIO = 9101;
    private final Runnable foregroundInactivityCheck = new Runnable() {
        @Override public void run() {
            InactivityStore.initializeOrCheck(MainActivity.this);
            dispatchPendingRecovery();
            handler.postDelayed(this, 60_000L);
        }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        InactivityStore.initializeOrCheck(this);
        InactivityStore.registerActivity(this);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                view.evaluateJavascript("(function(){document.addEventListener('pointerdown',window.__odiseoNativeActivity,true);document.addEventListener('touchstart',window.__odiseoNativeActivity,true);document.addEventListener('click',window.__odiseoNativeActivity,true);document.addEventListener('keydown',window.__odiseoNativeActivity,true);document.addEventListener('input',window.__odiseoNativeActivity,true);document.addEventListener('change',window.__odiseoNativeActivity,true);document.addEventListener('submit',window.__odiseoNativeActivity,true);})();", null);
                dispatchPendingRecovery();
                speechStatus(ttsReady ? "VOZ_LISTA" : "INICIALIZANDO_VOZ");
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "OdiseoNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        initializeSpeechOutput();
        String savedModel = getSharedPreferences(MODEL_PREFS, MODE_PRIVATE).getString(MODEL_PATH_KEY, null);
        if (savedModel != null) initializeModel(savedModel);
    }
    @Override protected void onResume() {
        super.onResume();
        InactivityStore.initializeOrCheck(this);
        InactivityStore.registerActivity(this);
        handler.removeCallbacks(foregroundInactivityCheck);
        handler.postDelayed(foregroundInactivityCheck, 60_000L);
        dispatchPendingRecovery();
    }
    @Override protected void onPause() {
        handler.removeCallbacks(foregroundInactivityCheck);
        super.onPause();
    }
    @Override public void onUserInteraction() {
        super.onUserInteraction();
        InactivityStore.registerActivity(this);
        dispatchPendingRecovery();
    }
    private void dispatchPendingRecovery() {
        if (!pageReady || web == null || auditDispatching) return;
        String pending = InactivityStore.pendingJson(this);
        if (pending == null || "null".equals(pending)) return;
        auditDispatching = true;
        web.post(() -> web.evaluateJavascript("window.odiseoHandleNativeInactivity && window.odiseoHandleNativeInactivity(" + JSONObject.quote(pending) + ")", value -> auditDispatching = false));
    }

    private void initializeSpeechOutput() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int language = textToSpeech.setLanguage(new Locale("es", "ES"));
                ttsReady = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED;
                if (ttsReady) {
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.setPitch(1.0f);
                }
                speechStatus(ttsReady ? "VOZ_LISTA" : "IDIOMA_NO_DISPONIBLE");
            } else speechStatus("TTS_NO_DISPONIBLE");
        });
    }
    private void speechStatus(String status) {
        if (web == null) return;
        String js = "window.odiseoOnSpeechStatus && window.odiseoOnSpeechStatus(" + JSONObject.quote(status) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }
    private void deliverSpeechText(String text) {
        if (web == null) return;
        String js = "window.odiseoOnSpeechResult && window.odiseoOnSpeechResult(" + JSONObject.quote(text) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }
    private void startNativeListening() {
        runOnUiThread(() -> {
            if (speechListening) { speechStatus("YA_ESTOY_ESCUCHANDO"); return; }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
                speechStatus("PERMISO_MICROFONO_REQUERIDO"); return;
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this)) { speechStatus("RECONOCIMIENTO_NO_DISPONIBLE"); return; }
            try {
                if (speechRecognizer != null) speechRecognizer.destroy();
                if (android.os.Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                    speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                else speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    public void onReadyForSpeech(Bundle params) { speechListening = true; speechStatus("ESCUCHANDO"); }
                    public void onBeginningOfSpeech() { }
                    public void onRmsChanged(float rmsdB) { }
                    public void onBufferReceived(byte[] buffer) { }
                    public void onEndOfSpeech() { speechStatus("PROCESANDO_VOZ"); }
                    public void onError(int error) {
                        speechListening = false;
                        speechStatus("VOZ_ERROR_" + speechErrorLabel(error));
                    }
                    public void onResults(Bundle results) {
                        speechListening = false;
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty() && matches.get(0) != null && !matches.get(0).trim().isEmpty()) {
                            deliverSpeechText(matches.get(0).trim());
                            speechStatus("VOZ_RECONOCIDA");
                        } else speechStatus("NO_SE_ENTENDIO_EL_AUDIO");
                    }
                    public void onPartialResults(Bundle partialResults) { }
                    public void onEvent(int eventType, Bundle params) { }
                });
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES");
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
                speechRecognizer.startListening(intent);
            } catch (Exception e) { speechListening = false; speechStatus("ERROR_VOZ"); }
        });
    }

    private String speechErrorLabel(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "AUDIO";
            case SpeechRecognizer.ERROR_CLIENT: return "CLIENTE";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "PERMISO";
            case SpeechRecognizer.ERROR_NETWORK: return "RED";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "TIEMPO_DE_RED";
            case SpeechRecognizer.ERROR_NO_MATCH: return "SIN_COINCIDENCIA";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "OCUPADO";
            case SpeechRecognizer.ERROR_SERVER: return "SERVIDOR";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "SIN_VOZ";
            default: return "DESCONOCIDO_" + error;
        }
    }

    private void stopNativeListening() {
        runOnUiThread(() -> {
            if (speechRecognizer != null && speechListening) {
                try { speechRecognizer.cancel(); } catch (Exception ignored) { }
            }
            speechListening = false;
            speechStatus("ESCUCHA_DETENIDA");
        });
    }

    private class Bridge {
        @JavascriptInterface public void requestHybrid(String requestJson) {
            // Solo HTTPS; no se siguen redirecciones para evitar filtrar la clave a otro host.
            new Thread(() -> {
                String requestId = "unknown";
                HttpURLConnection connection = null;
                try {
                    JSONObject request = new JSONObject(requestJson);
                    requestId = request.optString("requestId", "unknown");
                    String target = request.getString("url");
                    String apiKey = request.getString("apiKey");
                    String body = request.getString("body");
                    URL url = new URL(target);
                    if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getUserInfo() != null)
                        throw new Exception("Solo se permiten endpoints HTTPS sin credenciales en la URL.");
                    if (apiKey.trim().isEmpty() || apiKey.length() > 4096) throw new Exception("Clave API vacía o demasiado larga.");
                    if (body.length() > 1_000_000) throw new Exception("Solicitud demasiado grande (límite 1 MB).");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(90000);
                    connection.setInstanceFollowRedirects(false);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setRequestProperty("Accept", "application/json");
                    byte[] payload = body.getBytes("UTF-8");
                    connection.setFixedLengthStreamingMode(payload.length);
                    try (OutputStream output = connection.getOutputStream()) { output.write(payload); }
                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                    if (stream == null) throw new Exception("El proveedor devolvió HTTP " + code + ".");
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    try (InputStream in = stream) {
                        byte[] chunk = new byte[8192]; int n; int total = 0;
                        while ((n = in.read(chunk)) != -1) {
                            total += n;
                            if (total > 12 * 1024 * 1024) throw new Exception("Respuesta superior al límite de 12 MB.");
                            buffer.write(chunk, 0, n);
                        }
                    }
                    String response = new String(buffer.toByteArray(), "UTF-8");
                    if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + response.substring(0, Math.min(1200, response.length())));
                    hybridResult(requestId, response, null);
                } catch (Exception e) {
                    hybridResult(requestId, null, e.getMessage() == null ? "Error de conexión" : e.getMessage());
                } finally { if (connection != null) connection.disconnect(); }
            }, "Odiseo-Hybrid-Request").start();
        }
        private void hybridResult(String requestId, String response, String error) {
            if (web == null) return;
            String js = "window.odiseoOnHybridResult && window.odiseoOnHybridResult(" + JSONObject.quote(requestId) + "," + JSONObject.quote(response == null ? "" : response) + "," + JSONObject.quote(error == null ? "" : error) + ")";
            runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
        }
        @JavascriptInterface public void startListening() { startNativeListening(); }
        @JavascriptInterface public void stopListening() { stopNativeListening(); }
        @JavascriptInterface public void speak(String text) {
            if (text == null) return;
            runOnUiThread(() -> {
                if (!ttsReady || textToSpeech == null) { speechStatus("VOZ_NO_LISTA"); return; }
                String normalized = text.replaceAll("\\s+", " ").trim();
                if (normalized.isEmpty()) return;
                textToSpeech.stop();
                // Android TTS limita el tamaño de cada utterance; fragmentamos sin perder el final.
                boolean first = true;
                int chunkIndex = 0;
                int offset = 0;
                while (offset < normalized.length()) {
                    int end = Math.min(offset + 2800, normalized.length());
                    if (end < normalized.length()) {
                        int boundary = normalized.lastIndexOf(' ', end);
                        if (boundary > offset + 500) end = boundary;
                    }
                    String chunk = normalized.substring(offset, end).trim();
                    if (!chunk.isEmpty()) {
                        textToSpeech.speak(chunk, first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "odiseo_reply_" + (++chunkIndex));
                        first = false;
                    }
                    offset = end;
                    while (offset < normalized.length() && Character.isWhitespace(normalized.charAt(offset))) offset++;
                }
            });
        }
        @JavascriptInterface public void stopSpeaking() { runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); }); }
        @JavascriptInterface public void activity() { runOnUiThread(() -> InactivityStore.registerActivity(MainActivity.this)); }
        @JavascriptInterface public String getInactivityRecovery() { return InactivityStore.pendingJson(MainActivity.this); }
        @JavascriptInterface public String persistInactivityAudit(String reportJson) {
            try { return InactivityStore.persistAudit(MainActivity.this, reportJson); }
            catch(Exception e) { toast("No se pudo guardar la auditoría local: " + e.getMessage()); return "ERROR:" + e.getMessage(); }
        }
        @JavascriptInterface public void saveBackup(String stateJson, String diaryJson) {
            try {
                byte[] state = stateJson.getBytes("UTF-8"), diary = diaryJson.getBytes("UTF-8");
                JSONObject files = new JSONObject(); files.put("ESTADO_ODISEO.json", fileMeta(state)); files.put("DIARIO_ODISEO.json", fileMeta(diary));
                JSONObject manifest = new JSONObject(); manifest.put("format", "ODISEO_SAVE_ANDROID_1"); manifest.put("algorithm", "SHA-256"); manifest.put("files", files);
                ByteArrayOutputStream out = new ByteArrayOutputStream(); ZipOutputStream zip = new ZipOutputStream(out);
                put(zip, "ESTADO_ODISEO.json", state); put(zip, "DIARIO_ODISEO.json", diary); put(zip, "ODISEO_MANIFEST.json", manifest.toString(2).getBytes("UTF-8")); zip.close(); pendingBackup = out.toByteArray();
                runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); i.putExtra(Intent.EXTRA_TITLE, "ODISEO_SAVE_53_5_" + System.currentTimeMillis() + ".zip"); startActivityForResult(i, CREATE_BACKUP); });
            } catch(Exception e) { toast("No se pudo preparar la copia: " + e.getMessage()); }
        }
        @JavascriptInterface public void importBackup() { runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); startActivityForResult(i, OPEN_BACKUP); }); }
        @JavascriptInterface public void selectLocalModel() { runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-binary"}); startActivityForResult(i, OPEN_MODEL); }); }
        @JavascriptInterface public String localModelStatus() { try { JSONObject o = new JSONObject(); String path = getSharedPreferences(MODEL_PREFS, MODE_PRIVATE).getString(MODEL_PATH_KEY, null); o.put("state", LocalModelRuntime.status()); o.put("imported", path != null && new File(path).isFile() && verifyStoredModel(path)); o.put("integrity", path == null ? "NOT_IMPORTED" : (verifyStoredModel(path) ? "SHA256_OK" : "SHA256_MISMATCH")); return o.toString(); } catch(Exception e) { return "{\"state\":\"ERROR\"}"; } }
        @JavascriptInterface public void initializeLocalModel() { String path = getSharedPreferences(MODEL_PREFS, MODE_PRIVATE).getString(MODEL_PATH_KEY, null); if(path == null) { toast("Primero importa un modelo .litertlm"); return; } try { if (!verifyStoredModel(path)) throw new Exception("La huella SHA-256 del modelo no coincide; vuelve a importarlo"); initializeModel(path); } catch(Exception e) { toast("Modelo rechazado: " + e.getMessage()); } }
        @JavascriptInterface public boolean isLocalModelReady() { return "READY".equals(LocalModelRuntime.status()); }
        @JavascriptInterface public void generateLocal(String prompt, String requestId) { LocalModelRuntime.send(prompt, new LocalModelRuntime.Listener() {
            @Override public void onStatus(String state, String detail) { modelStatus(state, detail); }
            @Override public void onResult(String result) { modelResult(requestId, result, null); }
            @Override public void onError(String message) { modelResult(requestId, null, message); }
        }); }
    }

    private void initializeModel(String path) {
        LocalModelRuntime.initialize(path, new LocalModelRuntime.Listener() {
            @Override public void onStatus(String state, String detail) { modelStatus(state, detail); }
            @Override public void onResult(String result) { }
            @Override public void onError(String message) { modelStatus("ERROR", message); }
        });
    }
    private void modelStatus(String state, String detail) {
        if (web == null) return;
        String js = "window.odiseoOnModelStatus && window.odiseoOnModelStatus(" + JSONObject.quote(state) + "," + JSONObject.quote(detail) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }
    private void modelResult(String requestId, String result, String error) {
        if (web == null) return;
        String js = "window.odiseoOnLocalModelResult && window.odiseoOnLocalModelResult(" + JSONObject.quote(requestId) + "," + JSONObject.quote(result == null ? "" : result) + "," + JSONObject.quote(error == null ? "" : error) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }
    private String copyModel(Uri uri) throws Exception {
        File dir = new File(getFilesDir(), "odiseo_models"); if (!dir.exists() && !dir.mkdirs()) throw new Exception("No se pudo crear la carpeta del modelo");
        File temp = new File(dir, "active.litertlm.part"), dest = new File(dir, "active.litertlm");
        MessageDigest digest = MessageDigest.getInstance("SHA-256"); long total = 0; byte[] buf = new byte[1024 * 1024];
        try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(temp)) {
            if (in == null) throw new Exception("No se pudo leer el archivo seleccionado"); int n;
            while ((n = in.read(buf)) > 0) { total += n; if (total > 6L * 1024 * 1024 * 1024) throw new Exception("Modelo superior a 6 GB: límite de seguridad"); out.write(buf, 0, n); digest.update(buf, 0, n); }
            out.flush(); out.getFD().sync();
        } catch (Exception e) { temp.delete(); throw e; }
        if (total < 1_000_000L) { temp.delete(); throw new Exception("El archivo es demasiado pequeño para ser un modelo .litertlm"); }
        StringBuilder hex = new StringBuilder(); for (byte b : digest.digest()) hex.append(String.format(Locale.US, "%02x", b));
        // Transactional replacement: keep the previous working model until the new copy is in place.
        File backup = new File(dir, "active.litertlm.previous");
        if (backup.exists() && !backup.delete()) { temp.delete(); throw new Exception("No se pudo limpiar la copia temporal anterior"); }
        boolean movedOld = false;
        if (dest.exists()) { if (!dest.renameTo(backup)) { temp.delete(); throw new Exception("No se pudo reservar el modelo anterior"); } movedOld = true; }
        if (!temp.renameTo(dest)) {
            if (movedOld) backup.renameTo(dest);
            temp.delete();
            throw new Exception("No se pudo activar el nuevo modelo; se ha conservado el anterior cuando fue posible");
        }
        // Verify the bytes after rename before publishing the path in preferences.
        String actual = sha256File(dest);
        if (!hex.toString().equals(actual) || dest.length() != total) {
            dest.delete(); if (movedOld) backup.renameTo(dest);
            throw new Exception("La verificación posterior a la importación ha fallado");
        }
        if (backup.exists()) backup.delete();
        getSharedPreferences(MODEL_PREFS, MODE_PRIVATE).edit().putString(MODEL_PATH_KEY, dest.getAbsolutePath()).putString("sha256", hex.toString()).putLong("size", total).apply();
        return dest.getAbsolutePath();
    }

    private boolean verifyStoredModel(String path) throws Exception {
        File f = new File(path); if (!f.isFile() || !f.canRead()) return false;
        android.content.SharedPreferences prefs = getSharedPreferences(MODEL_PREFS, MODE_PRIVATE);
        String expected = prefs.getString("sha256", null); long expectedSize = prefs.getLong("size", -1L);
        return expected != null && expectedSize == f.length() && expected.equals(sha256File(f));
    }
    private String sha256File(File file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256"); byte[] buf = new byte[1024 * 1024];
        try (InputStream in = new FileInputStream(file)) { int n; while ((n = in.read(buf)) > 0) md.update(buf, 0, n); }
        StringBuilder out = new StringBuilder(); for (byte b : md.digest()) out.append(String.format(Locale.US, "%02x", b)); return out.toString();
    }

    private JSONObject fileMeta(byte[] b) throws Exception { JSONObject o = new JSONObject(); o.put("size", b.length); o.put("sha256", sha256(b)); return o; }
    private void put(ZipOutputStream z, String name, byte[] data) throws Exception { z.putNextEntry(new ZipEntry(name)); z.write(data); z.closeEntry(); }
    private String sha256(byte[] b) throws Exception { byte[] d = MessageDigest.getInstance("SHA-256").digest(b); StringBuilder s = new StringBuilder(); for(byte x:d) s.append(String.format(java.util.Locale.US,"%02x",x)); return s.toString(); }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this,s,Toast.LENGTH_LONG).show()); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK || data==null) return;
        try {
            Uri uri=data.getData();
            if(requestCode==OPEN_MODEL) { String path = copyModel(uri); toast("Modelo importado, SHA-256 verificado y guardado localmente. Cargando…"); initializeModel(path); }
            else if(requestCode==CREATE_BACKUP && pendingBackup!=null){ try(OutputStream o=getContentResolver().openOutputStream(uri)){ if(o==null) throw new Exception("No se pudo abrir el destino"); o.write(pendingBackup); o.flush(); } pendingBackup=null; toast("Copia ODISEO SAVE guardada."); }
            else if(requestCode==OPEN_BACKUP){
                Map<String,byte[]> entries=new HashMap<>();
                try(InputStream in=getContentResolver().openInputStream(uri); ZipInputStream z=new ZipInputStream(in)){ ZipEntry e; while((e=z.getNextEntry())!=null){ if(e.isDirectory() || e.getName().contains("..") || e.getName().startsWith("/")) throw new Exception("Ruta no permitida en ZIP"); ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=z.read(buf))>0){b.write(buf,0,n); if(b.size()>5_000_000) throw new Exception("Archivo demasiado grande");} if(entries.containsKey(e.getName())) throw new Exception("Entrada ZIP duplicada"); entries.put(e.getName(),b.toByteArray()); }}
                byte[] mb=entries.get("ODISEO_MANIFEST.json"), sb=entries.get("ESTADO_ODISEO.json"), db=entries.get("DIARIO_ODISEO.json"); if(entries.size()!=3 || mb==null||sb==null||db==null) throw new Exception("El ZIP debe contener exactamente los tres archivos ODISEO SAVE"); JSONObject m=new JSONObject(new String(mb,"UTF-8")); if(!"ODISEO_SAVE_ANDROID_1".equals(m.optString("format"))) throw new Exception("Formato de copia no compatible"); JSONObject f=m.getJSONObject("files"); check(f.getJSONObject("ESTADO_ODISEO.json"),sb); check(f.getJSONObject("DIARIO_ODISEO.json"),db);
                String state=new String(sb,"UTF-8"), diary=new String(db,"UTF-8"); JSONObject payload=new JSONObject(); payload.put("state",new JSONObject(state)); payload.put("diary",new JSONObject(diary)); final String js=payload.toString(); web.post(() -> web.evaluateJavascript("window.odiseoImport("+JSONObject.quote(js)+")",null)); toast("Copia verificada. Revisa el estado importado en Odiseo.");
            }
        } catch(Exception e){ toast("Copia rechazada: "+e.getMessage()); }
    }
    private void check(JSONObject meta, byte[] b) throws Exception { if(meta.getLong("size")!=b.length || !meta.getString("sha256").equals(sha256(b))) throw new Exception("SHA-256 no coincide: archivo alterado o dañado"); }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startNativeListening();
            else speechStatus("PERMISO_MICROFONO_DENEGADO");
        }
    }
    @Override protected void onDestroy() {
        speechListening = false;
        if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); speechRecognizer = null; }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        handler.removeCallbacks(foregroundInactivityCheck);
        super.onDestroy();
    }
    @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
