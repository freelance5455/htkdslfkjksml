package org.odiseo.app;

/** Pure policy: kept separate so the 30-minute threshold can be tested without Android. */
public final class InactivityPolicy {
    public static final long TIMEOUT_MS = 30L * 60L * 1000L;
    private InactivityPolicy() {}
    public static boolean isInactive(long nowMs, long lastActivityMs) {
        return lastActivityMs > 0L && nowMs >= lastActivityMs && (nowMs - lastActivityMs) >= TIMEOUT_MS;
    }
    public static long remainingMs(long nowMs, long lastActivityMs) {
        if (lastActivityMs <= 0L) return TIMEOUT_MS;
        long elapsed = Math.max(0L, nowMs - lastActivityMs);
        return Math.max(0L, TIMEOUT_MS - elapsed);
    }
}
