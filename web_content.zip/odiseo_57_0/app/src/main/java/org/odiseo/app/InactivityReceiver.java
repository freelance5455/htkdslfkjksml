package org.odiseo.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class InactivityReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        long now = System.currentTimeMillis();
        long last = InactivityStore.prefs(context).getLong(InactivityStore.LAST, 0L);
        InactivityStore.checkAndMark(context, now, last);
        if (!InactivityStore.prefs(context).getBoolean(InactivityStore.PENDING, false) && last > 0L) InactivityStore.schedule(context, last);
    }
}
