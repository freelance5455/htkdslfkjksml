/* ODISEO CENTRAL BRAIN 57.0-alpha
 * Director central: interpreta, prioriza motores, delega solo contratos allowlisted,
 * conserva procedencia y audita la salida. No afirma conciencia ni aprendizaje de pesos.
 */
(function(g){
 'use strict';
 const VERSION='57.0.0-alpha';
 const MODE='ALL';
 const ENGINE_MAP=[
  {id:'reasoning',name:'Núcleo de razonamiento local',key:'OdiseoReasoningCore',terms:['analiza','razona','hipotesis','demuestra','collatz','syracuse','patron','residuo','logica'],weight:5},
  {id:'sherlock',name:'Sherlock',key:'OdiseoSherlock',terms:['rastros','relaciones','coincidencias','sherlock','observaciones','evidencias'],weight:5},
  {id:'penelope',name:'Penélope',key:'OdiseoPenelope',terms:['estructura','simplifica','ast','penelope','penelope','descomponer'],weight:4},
  {id:'judas',name:'Judas Tadeo',key:'OdiseoJudasTadeo',terms:['alternativa','bloqueo','reencuadra','imposible','judas'],weight:4},
  {id:'mirror',name:'ESPEJO',key:'OdiseoMirror',terms:['espejo','puntos ciegos','preguntas abiertas','grafo'],weight:4},
  {id:'tic',name:'TIC',key:'OdiseoTIC',terms:['informacion','entropia','transferencia','tic'],weight:3},
  {id:'evidence',name:'Integrador de evidencias',key:'OdiseoEvidenceIntegrator',terms:['evidencia','fuentes','procedencia','contrastar'],weight:4},
  {id:'auditor',name:'Auditor de comunicación',key:'OdiseoCommunicationAuditor',terms:['audita','auditoria','verifica','comprueba','revisa'],weight:4},
  {id:'library',name:'Biblioteca activa',key:'OdiseoActiveLibrary',terms:['recuerda','memoria','continuar','aprendizaje','anterior'],weight:3},
  {id:'creative',name:'Creador autónomo',key:'OdiseoCreator',terms:['crea','dibuja','imagen','escribe','inventa','diseña'],weight:3},
  {id:'lottery',name:'Laboratorio de loterías',key:'OdiseoLotteryLab',terms:['loteria','primitiva','euromillones','sorteo'],weight:4},
  {id:'integrator',name:'Integrador E',key:'OdiseoIntegrator',terms:['integra','combina','fusiona','convergencia'],weight:3}
 ];
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const has=(q,t)=>q.includes(norm(t));
 function classify(text){
  const q=norm(text);
  if(/\b(apk|compila|codigo|programa|depura|zip)\b/.test(q))return 'engineering';
  if(/\b(dibuja|imagen|crea|diseña|escribe|redacta)\b/.test(q))return 'creation';
  if(/\b(audita|verifica|comprueba|contrasta|prueba)\b/.test(q))return 'verification';
  if(/\b(investiga|hipotesis|experimento|causalidad|azar|datos)\b/.test(q))return 'research';
  if(/\b(recuerda|memoria|continua|continuar|anterior|donde nos quedamos)\b/.test(q))return 'continuity';
  if(/\b(explica|que es|define|ensena)\b/.test(q))return 'explanation';
  if(/\b(analiza|razona|resuelve|demuestra|calcula)\b/.test(q))return 'analysis';
  return 'general';
 }
 function inventory(){
  const assistant=g.OdiseoLocalAssistant;
  let loaded=[];
  try{loaded=assistant&&typeof assistant.status==='function'?assistant.status().filter(x=>x.available).map(x=>x.name):[];}catch(_){}
  return ENGINE_MAP.map(e=>({id:e.id,name:e.name,available:!!g[e.key]||loaded.includes(e.name),key:e.key}));
 }
 function route(text){
  const q=norm(text),goal=classify(text),inv=inventory();
  const scored=ENGINE_MAP.map(e=>{
   const hits=e.terms.filter(t=>has(q,t));
   let score=hits.length*e.weight;
   if(goal==='verification'&&['sherlock','evidence','auditor'].includes(e.id))score+=3;
   if(goal==='research'&&['reasoning','sherlock','tic','lottery'].includes(e.id))score+=2;
   if(goal==='creation'&&e.id==='creative')score+=4;
   if(goal==='continuity'&&e.id==='library')score+=4;
   if(goal==='engineering'&&e.id==='integrator')score+=1;
   return {...e,score,hits,available:!!inv.find(x=>x.id===e.id)?.available};
  }).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name));
  const selected=scored.filter(x=>x.available);
  const unavailable=scored.filter(x=>!x.available);
  return {goal,mode:MODE,selected,unavailable,inventory:inv,policy:{
   execution:'allowlisted-only',
   rule:'Los motores sin contrato ejecutable se recomiendan pero no se invocan.',
   minimumEvidence:'Las coincidencias y puntuaciones solo priorizan herramientas; no prueban hechos.',
   fallback:'Si no hay motor adecuado, solicitar aclaración o usar el modelo conversacional disponible.'
  }};
 }
 async function begin(text){
  const decision=route(text);
  const cognitive=g.OdiseoCognitiveBrain;
  let session=null;
  if(cognitive&&typeof cognitive.begin==='function')session=await cognitive.begin(text,decision);
  return {version:VERSION,decision,cognitive:session, prompt:session?session.prompt:[
   'ODISEO CORE 57: director central.',
   'Responde en español. Distingue hechos, inferencias, hipótesis y desconocidos.',
   'No afirmes ejecutar motores no invocados. No confundas coincidencia con causalidad.',
   'Objetivo: '+decision.goal,
   'Motores disponibles priorizados: '+(decision.selected.map(x=>x.name).join(', ')||'ninguno'),
   'Motores recomendados pero no disponibles: '+(decision.unavailable.map(x=>x.name).join(', ')||'ninguno'),
   'Mensaje: '+text
  ].join('\n\n')};
 }
 function finish(text,answer,session){
  const cognitive=g.OdiseoCognitiveBrain;
  const completed=cognitive&&session&&session.cognitive&&typeof cognitive.finish==='function'
   ?cognitive.finish(text,answer,session.cognitive.plan):null;
  const flags=[];
  const a=String(answer||'');
  if(/he (?:ejecutado|verificado|compilado|instalado)|queda demostrado|es causal definitivamente/i.test(a))
   flags.push('Revisar afirmaciones de ejecución, verificación o causalidad frente a registros reales.');
  return {version:VERSION,decision:session&&session.decision||route(text),cognitive:completed,
   audit:{status:flags.length?'REVIEW_REQUIRED':'UNVERIFIED',flags,verified:false},
   disclaimer:'Auditoría heurística: no demuestra verdad factual ni sustituye pruebas externas.'};
 }
 function status(){
  const inv=inventory();
  return {version:VERSION,mode:MODE,centralDirector:true,availableEngines:inv.filter(x=>x.available).length,
   knownEngines:inv.length,localModelReady:!!(g.OdiseoNative&&g.OdiseoNative.isLocalModelReady&&g.OdiseoNative.isLocalModelReady()),
   cognitiveBrain:!!g.OdiseoCognitiveBrain,policy:'ALL; delegación allowlisted; no ejecución ficticia',
   limitations:['No es conciencia','No entrena pesos del modelo','No verifica hechos externos por sí mismo','La selección de motores es heurística','Los módulos sin contrato ejecutable no se invocan']};
 }
 g.OdiseoCentralBrain=Object.freeze({version:VERSION,mode:MODE,classify,route,begin,finish,status,inventory});
})(typeof window!=='undefined'?window:globalThis);
