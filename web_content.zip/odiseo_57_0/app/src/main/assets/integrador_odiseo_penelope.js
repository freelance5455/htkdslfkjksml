/* ODISEO 51.7 — Motor integrador E.
 * Compara descubrimientos independientes, conserva procedencia y solo integra
 * candidatos que superan un verificador externo. Caso base: particiones n=a+b,
 * 1<=a<=b; incluye certificado de completitud y refutación de una afirmación.
 */
(function(global){'use strict';
 const VERSION='51.8-integrador-E';
 function fail(m){throw new Error(m)}
 function integer(n,name){if(!Number.isSafeInteger(n)||n<2||n>1000000)fail(name+' debe ser entero entre 2 y 1000000.');}
 function canonical(x){if(Array.isArray(x))return '['+x.map(canonical).join(',')+']';if(x&&typeof x==='object')return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';return JSON.stringify(x)}
 function solveAscending(task){const n=task.n,out=[];for(let a=1;a<=Math.floor(n/2);a+=2)out.push({a,b:n-a});return {engine:'Odiseo',method:'enumeracion_ascendente_a_impar',taskId:task.id,candidates:out,claim:{count:out.length}};}
 function solveDescending(task){const n=task.n,out=[];for(let b=n-1;b>=Math.ceil(n/2);b--){const a=n-b;if(a%2===0)out.push({a,b});}return {engine:'Penelope',method:'enumeracion_descendente_b_con_a_par',taskId:task.id,candidates:out,claim:{count:out.length}};}
 function verifyCandidate(n,p){return !!p&&Number.isSafeInteger(p.a)&&Number.isSafeInteger(p.b)&&p.a>=1&&p.a<=p.b&&p.a+p.b===n;}
 function integrate(task,odiseo,penelope){
  if(!task||task.kind!=='positive_unordered_partitions'||!Array.isArray(odiseo.candidates)||!Array.isArray(penelope.candidates))fail('Contrato de tarea o respuestas inválido.');
  const sources=[['Odiseo',odiseo],['Penelope',penelope]],valid=[],rejected=[],seen=new Map();
  for(const [engine,response] of sources){if(response.taskId!==task.id){rejected.push({engine,reason:'TASK_ID_MISMATCH'});continue;}for(const p of response.candidates){if(!verifyCandidate(task.n,p)){rejected.push({engine,candidate:p,reason:'EXTERNAL_VERIFIER_REJECTED'});continue;}const key=p.a+','+p.b;if(!seen.has(key)){seen.set(key,{a:p.a,b:p.b,sources:[engine]});valid.push(seen.get(key));}else if(!seen.get(key).sources.includes(engine))seen.get(key).sources.push(engine);}}
  valid.sort((x,y)=>x.a-y.a||x.b-y.b);
  const expected=Math.floor(task.n/2),complete=valid.length===expected&&valid.every((p,i)=>p.a===i+1&&p.b===task.n-i-1);
  const overlap=valid.filter(p=>p.sources.length===2).length;
  const claim={statement:'Toda partición no ordenada de n en dos enteros positivos tiene la forma (a,n-a), con 1<=a<=floor(n/2).',status:complete?'VERIFIED_FOR_THIS_TASK_BY_EXHAUSTIVE_BOUND':'INCOMPLETE_OR_DISCREPANT',proof:{argument:'Como a<=b y a+b=n, se tiene 2a<=n; por tanto 1<=a<=floor(n/2). Cada a en ese intervalo produce exactamente una pareja (a,n-a).',bound:expected,enumerationComplete:complete}};
  const counterexampleClaim={statement:'Todas las particiones tienen sumandos distintos.',counterexample:valid.find(p=>p.a===p.b)||null,status:valid.some(p=>p.a===p.b)?'REFUTED':'NOT_REFUTED_BY_THIS_TASK'};
  return {version:VERSION,task:{id:task.id,n:task.n},individual:{odiseo:{count:odiseo.candidates.length,method:odiseo.method},penelope:{count:penelope.candidates.length,method:penelope.method}},joint:{uniqueValid:valid.length,expected,overlap,discoveriesOnlyOdiseo:valid.filter(p=>p.sources.length===1&&p.sources[0]==='Odiseo').length,discoveriesOnlyPenelope:valid.filter(p=>p.sources.length===1&&p.sources[0]==='Penelope').length,solutions:valid},rejected,claim,counterexampleClaim,agreement:canonical(odiseo.candidates)===canonical(penelope.candidates),status:complete&&rejected.length===0?'INTEGRATION_PASSED':'REVIEW_REQUIRED',limits:['Caso combinatorio finito y acotado; no demuestra capacidad general de descubrimiento.','La integración comprueba validez y completitud para esta familia concreta, no verdad semántica de problemas arbitrarios.','Los dos motores se ejecutan en el mismo proceso; no hay aislamiento de seguridad.']};
 }
 function integrateLotteryReport(report){
  if(!report||!report.data||!report.ticket||!report.roles||!report.verdict)fail('Informe de lotería incompleto.');
  const expected=report.game==='La Primitiva'?{numbers:[7,14,23,31,38,46],extras:[6],odds:'1 entre 13983816'}:report.game==='Euromillones'?{numbers:[9,18,27,36,49],extras:[4,11],odds:'1 entre 139838160'}:null;
  if(!expected)fail('Juego no reconocido por Integrador E.');
  const same=(a,b)=>canonical(a)===canonical(b);
  const checks=[
   {name:'frozen_ticket_unchanged',passed:same(report.ticket.numbers,expected.numbers)&&same(report.ticket.extras,expected.extras)},
   {name:'jackpot_odds_consistent',passed:report.ticket.mainJackpotOdds===expected.odds},
   {name:'four_roles_present',passed:['odiseo','penelope','judasTadeo','integratorE'].every(k=>!!report.roles[k])},
   {name:'judas_reframe_present',passed:!!report.judasTadeo&&report.judasTadeo.status==='REFRAME_PROPOSED'},
   {name:'source_not_falsely_certified',passed:report.data.sourceVerified===false},
   {name:'prediction_not_claimed',passed:typeof report.verdict.prediction==='string'&&report.verdict.prediction.includes('No se ha demostrado')},
   {name:'audit_matches_data',passed:report.data.drawCount===0?!report.audit:!!report.audit&&report.audit.multipleTesting&&report.audit.multipleTesting.method==='Holm step-down'&&report.audit.multipleTesting.tests.length>=8}
  ];
  const passed=checks.every(x=>x.passed),theoretical=report.data.drawCount===0;
  return {engine:'Integrador E',version:VERSION,domain:'lottery-research',status:passed?(theoretical?'INTEGRATION_PASSED_THEORETICAL_ONLY':'INTEGRATION_PASSED_SOURCE_UNVERIFIED'):'REVIEW_REQUIRED',checks,passed:checks.filter(x=>x.passed).length,total:checks.length,provenance:{game:report.game,drawCount:report.data.drawCount,source:report.data.source||'not_declared',sourceVerified:report.data.sourceVerified===true,analysisVersion:report.version},verdict:theoretical?'El informe teórico está integrado; Odiseo y Penélope quedan a la espera de datos.': 'Informe integrado estructuralmente; la fuente de los sorteos aún requiere verificación externa.',limits:['E valida estructura, coherencia y procedencia declarada; no certifica que los datos procedan realmente de SELAE.','La integración no valida la justicia del mecanismo ni demuestra poder predictivo.']};
 }
 function run(options){const n=options&&options.n!==undefined?options.n:20;integer(n,'n');const task={id:'partition-'+n,kind:'positive_unordered_partitions',n};const o=solveAscending(task),p=solveDescending(task);return integrate(task,o,p);}
 global.OdiseoIntegrator=Object.freeze({version:VERSION,solveAscending,solveDescending,integrate,integrateLotteryReport,run,verifyCandidate});
})(window);
