/* ODISEO 50.8 — Motor de Objetivo Evolutivo.
 * x evolves by logistic map x[n+1]=r*x[n]*(1-x[n]); y tracks x with bounded adaptive rate.
 * This is an experimental coupled system, not a chaos detector or proof of chaos.
 */
(function(global){'use strict';
 const VERSION='1.0.0-objetivo-evolutivo', MAX_STEPS=20000;
 function finite(v,n){const x=Number(v);if(!Number.isFinite(x))throw Error(n+' debe ser finito.');return x;}
 function run(options){const o=options||{};let x=finite(o.x===undefined?0.2:o.x,'x'),y=finite(o.y===undefined?0.1:o.y,'y'),r=finite(o.r===undefined?3.2:o.r,'r'),gain=finite(o.gain===undefined?0.5:o.gain,'gain'),steps=finite(o.steps===undefined?1000:o.steps,'steps');
  if(!(x>0&&x<1&&y>=0&&y<=1))throw Error('Se requiere 0<x<1 y 0<=y<=1.');
  if(!(r>0&&r<=4))throw Error('r debe pertenecer a (0,4].');
  if(!(gain>=0&&gain<=1))throw Error('gain debe pertenecer a [0,1].');
  if(!Number.isInteger(steps)||steps<1||steps>MAX_STEPS)throw Error('steps debe ser entero entre 1 y '+MAX_STEPS+'.');
  const trace=[], tail=[];let minX=1,maxX=0,minY=1,maxY=0,clamped=false;
  for(let n=0;n<=steps;n++){
   const e=x-y;trace.push({n,x,y,error:e});if(trace.length>500)trace.shift();tail.push(x);if(tail.length>64)tail.shift();
   minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);
   if(n===steps)break;
   const nextX=r*x*(1-x);const alpha=gain*(x+(1-x)*y);let nextY=y+alpha*(x-y);
   if(nextX<0||nextX>1||!Number.isFinite(nextX))throw Error('La dinámica produjo un objetivo fuera de [0,1].');
   if(nextY<0){nextY=0;clamped=true;}if(nextY>1){nextY=1;clamped=true;}x=nextX;y=nextY;
  }
  const spread=maxX-minX, last=tail.slice(-16);let period2=false;
  if(last.length>=8){let d=0;for(let i=2;i<last.length;i++)d=Math.max(d,Math.abs(last[i]-last[i-2]));let odd=0,even=0;for(let i=0;i<last.length;i++){if(i%2)odd+=last[i];else even+=last[i];}period2=d<1e-7&&Math.abs(odd/(last.length/2)-even/(last.length/2))>1e-6;}
  const classification=spread<1e-8?'rango casi fijo':period2?'candidato a periodo 2':spread<1e-4?'rango estrecho / posible convergencia':'dinámica variable no clasificada';
  const payload={version:VERSION,parameters:{x0:o.x===undefined?0.2:Number(o.x),y0:o.y===undefined?0.1:Number(o.y),r,gain,steps},final:{x,y,error:x-y},ranges:{x:[minX,maxX],y:[minY,maxY],xSpread:spread},classification,clamped,trace,epistemicStatus:'Clasificación heurística sobre una ventana finita. No demuestra caos, periodicidad exacta ni comportamiento asintótico.'};
  let h=2166136261,s=JSON.stringify({parameters:payload.parameters,final:payload.final,ranges:payload.ranges});for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}payload.fingerprint=(h>>>0).toString(16).padStart(8,'0');return payload;
 }
 global.OdiseoMovingTarget=Object.freeze({version:VERSION,run});
})(window);
