/* ODISEO 53.2 — Semáforo de integridad y omisiones.
 * Fail-closed: GREEN exige inventario único, cobertura observada, trazas limpias,
 * protocolo ODQ/ODA válido y smoke tests completos. No certifica semántica.
 */
(function(root){'use strict';
 const VERSION='53.2-semaphore-1.1';
 const COLORS=Object.freeze({GREEN:'GREEN',AMBER:'AMBER',RED:'RED'});
 function evaluate(input){
  const x=input||{},rawRequired=Array.isArray(x.requiredEngines)?x.requiredEngines:[],required=rawRequired.map(v=>String(v||'').trim()).filter(Boolean),coveredRaw=Array.isArray(x.coveredEngines)?x.coveredEngines:[],covered=new Set(coveredRaw.map(v=>String(v||'').trim()).filter(Boolean)),issues=[];
  const communication=x.communicationAudit||null,language=x.languageAudit||null,smoke=x.smokeAudit||null;
  if(!required.length)issues.push({code:'REQUIRED_ENGINE_INVENTORY_MISSING',severity:'CRITICAL',detail:'No existe inventario verificable de motores obligatorios.'});
  if(required.length!==rawRequired.length||new Set(required).size!==required.length)issues.push({code:'REQUIRED_ENGINE_INVENTORY_INVALID',severity:'CRITICAL',detail:'El inventario contiene nombres vacíos o duplicados.'});
  const missing=required.filter(n=>!covered.has(n));
  for(const name of missing)issues.push({code:'COMMUNICATION_COVERAGE_OMISSION',severity:'HIGH',engine:name,detail:'No hay evidencia de invocación y respuesta auditadas para este motor.'});
  const unknown=[...covered].filter(n=>!required.includes(n));
  for(const name of unknown)issues.push({code:'UNKNOWN_ENGINE_CLAIMED_AS_COVERED',severity:'HIGH',engine:name,detail:'Se declaró cobertura para un motor fuera del inventario.'});
  if(!communication)issues.push({code:'COMMUNICATION_AUDIT_MISSING',severity:'CRITICAL',detail:'No se aportó auditoría de comunicación.'});
  else {
   const severe=(communication.issues||[]).filter(i=>['CRITICAL','HIGH'].includes(i.severity));
   if(severe.length)issues.push({code:'COMMUNICATION_FAILURE',severity:'CRITICAL',detail:'La auditoría de comunicación contiene incidencias graves.',count:severe.length});
   else if(communication.status!=='COMMUNICATION_TRACE_CLEAN')issues.push({code:'COMMUNICATION_WARNING',severity:'MEDIUM',detail:'La traza contiene advertencias o no está limpia.'});
   const observed=Number(communication.summary&&communication.summary.observedExchanges);
   if(!Number.isFinite(observed)||observed<required.length)issues.push({code:'COMMUNICATION_EXCHANGE_COUNT_INSUFFICIENT',severity:'HIGH',detail:'El número de intercambios observados no cubre el inventario obligatorio.',observed:Number.isFinite(observed)?observed:null,required:required.length});
  }
  if(!language)issues.push({code:'LANGUAGE_AUDIT_MISSING',severity:'HIGH',detail:'No se aportó auditoría ODQ/ODA.'});
  else if(!Number.isFinite(Number(language.failed))||Number(language.failed)>0||language.missing===true)issues.push({code:'LANGUAGE_TEST_FAILURE',severity:'HIGH',detail:'La validación ODQ/ODA está ausente, incompleta o contiene fallos.',count:language.failed});
  if(!smoke)issues.push({code:'SMOKE_AUDIT_MISSING',severity:'HIGH',detail:'No se aportó resultado del examen de módulos.'});
  else {
   if(Number(smoke.failed)>0||Number(smoke.missing)>0)issues.push({code:'MODULE_SMOKE_FAILURE',severity:'HIGH',detail:'Hay módulos ausentes o con errores en pruebas mínimas.',failed:smoke.failed,missing:smoke.missing});
   if(Number(smoke.executed)!==required.length||Number(smoke.total)!==required.length)issues.push({code:'SMOKE_INVENTORY_MISMATCH',severity:'HIGH',detail:'El número de módulos ejecutados no coincide con el inventario auditado.',executed:smoke.executed,total:smoke.total,required:required.length});
  }
  if(x.staleEvidence===true)issues.push({code:'STALE_EVIDENCE',severity:'HIGH',detail:'La evidencia de auditoría está desactualizada.'});
  if(x.unresolvedCritical===true)issues.push({code:'UNRESOLVED_CRITICAL',severity:'CRITICAL',detail:'Se ha declarado un fallo crítico sin resolver.'});
  const critical=issues.some(i=>i.severity==='CRITICAL'),high=issues.some(i=>i.severity==='HIGH'),medium=issues.some(i=>i.severity==='MEDIUM');
  const color=(critical||high)?COLORS.RED:medium?COLORS.AMBER:COLORS.GREEN;
  return {version:VERSION,color,signal:color==='GREEN'?'VERDE':color==='AMBER'?'ÁMBAR':'ROJO',status:color==='GREEN'?'SYSTEM_AUDIT_GREEN':color==='AMBER'?'SYSTEM_REVIEW_WARNING':'SYSTEM_FAILURE_OR_OMISSION',coverage:{required:required.length,covered:required.length-missing.length,missing:missing.length,percent:required.length?Math.round((required.length-missing.length)*1000/required.length)/10:0,missingEngines:missing,unknownEngines:unknown},summary:{issueCount:issues.length,critical:issues.filter(i=>i.severity==='CRITICAL').length,high:issues.filter(i=>i.severity==='HIGH').length,medium:issues.filter(i=>i.severity==='MEDIUM').length},issues,greenCriteria:['Inventario único y completo de motores obligatorios.','Cada motor obligatorio dispone de una invocación real y respuesta registrada.','La auditoría observa al menos un intercambio por motor y no detecta incidencias.','ODQ/ODA y smoke tests vigentes, completos y sin fallos.','No existen omisiones, nombres desconocidos ni evidencia caducada.'],limits:['El verde certifica únicamente el alcance y las rutas registradas.','La traza del núcleo registra el sobre de invocación y resumen de salida, no todos los argumentos internos de cada motor.','No demuestra verdad semántica, independencia estadística, corrección total de cada algoritmo ni integración semántica completa entre motores.','El protocolo ODQ/ODA se valida en el control central; no se afirma que todos los motores lo adopten internamente.']};
 }
 root.OdiseoSemaphore=Object.freeze({version:VERSION,colors:COLORS,evaluate});
})(typeof window!=='undefined'?window:globalThis);
