/* Odiseo 53.7-alpha — Núcleo de razonamiento local estructurado.
 * Motor simbólico determinista. No es un LLM, no llama a red/GPT y no afirma comprensión general.
 * Conserva separación entre observación, hipótesis, inferencia y conclusión.
 */
(function(g){
 'use strict';
 const VERSION='1.0.0-alpha';
 const STOP=new Set(('a al algo ante bajo cada como con contra cual cuando de del desde donde dos el ella ellas ellos en entre era es esa esas ese eso esos esta estaba estas este esto fue ha hacia hasta hay la las le les lo los mas me mi mis mucha mucho muy nada ni no nos o otra otras otro otros para pero por porque que quien se sin sobre su sus te tiene todo todos tras tu un una unas uno unos y ya').split(' '));
 const norm=s=>String(s==null?'':s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9ñáéíóúü\s.,;:!?%+\-]/gi,' ');
 const tokens=s=>(norm(s).match(/[a-z0-9]+/g)||[]).filter(x=>x.length>1&&!STOP.has(x));
 const id=(p,i)=>p+'_'+i;
 function splitStatements(s){return String(s||'').split(/[\n;]+|(?<=[.!?])\s+/).map(x=>x.trim()).filter(Boolean).slice(0,100);}
 function classify(s){const x=norm(s);if(/\b(no|nunca|jamas|tampoco|falso|refuta|contradice)\b/.test(x))return 'negated';if(/\b(creo|quizas|quiza|tal vez|podria|hipotesis|supongo|parece)\b/.test(x))return 'hypothesis';if(/\b(porque|debido a|causa|provoca|produce|genera)\b/.test(x))return 'causal_claim';if(/\b(si|entonces|implica|por tanto|luego)\b/.test(x))return 'conditional';if(/\b(es|son|fue|sera|existe|hay|contiene|tiene|ocurre)\b/.test(x))return 'assertion';return 'unclassified';}
 function extract(s){const nums=(String(s).match(/-?\d+(?:[.,]\d+)?/g)||[]).map(Number).filter(Number.isFinite);return {text:s,type:classify(s),terms:tokens(s),numbers:nums,negated:classify(s)==='negated'};}
 function overlap(a,b){const A=new Set(a),B=new Set(b);if(!A.size||!B.size)return 0;let n=0;A.forEach(x=>{if(B.has(x))n++;});return n/(A.size+B.size-n);}
 function analyze(input,opts){
  const raw=String(input||'').trim();if(!raw)throw new Error('Se necesita una pregunta o conjunto de observaciones.');
  if(raw.length>12000)throw new Error('Entrada demasiado larga: máximo 12000 caracteres.');
  const statements=splitStatements(raw), claims=statements.map(extract);
  const positives=claims.filter(c=>!c.negated&&c.type!=='unclassified'), negatives=claims.filter(c=>c.negated);
  const pairs=[];
  for(let i=0;i<claims.length;i++)for(let j=i+1;j<claims.length;j++){
   const score=overlap(claims[i].terms,claims[j].terms);
   if(score>0)pairs.push({a:id('c',i),b:id('c',j),lexicalOverlap:Number(score.toFixed(4)),sharedTerms:claims[i].terms.filter(t=>claims[j].terms.includes(t))});
  }
  const contradictions=[];
  for(const p of pairs){const a=claims[Number(p.a.slice(2))],b=claims[Number(p.b.slice(2))];if((a.negated&&!b.negated)||(!a.negated&&b.negated))contradictions.push({a:p.a,b:p.b,reason:'Una afirmación contiene negación y la otra no; requiere revisar si hablan del mismo sujeto y contexto.',status:'possible'});}
  const numeric=claims.flatMap((c,i)=>c.numbers.map(n=>({claim:id('c',i),value:n})));
  const hypothesisPool=[];
  if(claims.length>=2){
   const common=[...new Set(claims.flatMap(c=>c.terms))].filter(t=>claims.filter(c=>c.terms.includes(t)).length>=2);
   if(common.length)hypothesisPool.push({id:'h_lexical_common',text:'Las observaciones podrían compartir un tema o variable: '+common.join(', ')+'.',basis:'solapamiento léxico',confidence:'low',falsifier:'Comprobar con textos de control y definiciones independientes.'});
   const sharedNums=[...new Set(numeric.map(x=>x.value))].filter(n=>numeric.filter(x=>x.value===n).length>=2);
   if(sharedNums.length)hypothesisPool.push({id:'h_numeric_overlap',text:'Hay valores numéricos repetidos: '+sharedNums.join(', ')+'.',basis:'coincidencia numérica exacta',confidence:'descriptive_only',falsifier:'Comparar contra una distribución nula y controlar selección posterior.'});
  }
  const limitations=[];
  if(claims.some(c=>c.type==='causal_claim'))limitations.push('Las expresiones causales se han detectado lingüísticamente; no demuestran causalidad.');
  if(pairs.length)limitations.push('El solapamiento léxico mide palabras compartidas, no equivalencia de significado.');
  if(contradictions.length)limitations.push('Las contradicciones son candidatas: hay que verificar sujeto, tiempo, alcance y contexto.');
  limitations.push('El motor no dispone de un modelo general de lenguaje ni de conocimiento externo; solo analiza la entrada suministrada.');
  return {version:VERSION,status:'ANALYZED',method:'symbolic_local_v1',counts:{statements:claims.length,positiveOrUnnegated:positives.length,negated:negatives.length,pairs:pairs.length,possibleContradictions:contradictions.length},claims,pairs,contradictions,numeric,hypotheses:hypothesisPool,conclusion:{text:claims.length===1?'Se ha estructurado una afirmación; no hay base interna suficiente para inferir relaciones.':`Se han estructurado ${claims.length} enunciados y detectado ${pairs.length} pares con términos compartidos.`,certainty:'limited',notEstablished:['verdad factual','causalidad','intención del autor','relación semántica profunda']},limitations};
 }
 function answer(input){const r=analyze(input);const lines=['NÚCLEO LOCAL · INFORME','Enunciados: '+r.counts.statements,'Pares con coincidencia léxica: '+r.counts.pairs,'Contradicciones candidatas: '+r.counts.possibleContradictions,'','Estructura:'];r.claims.forEach((c,i)=>lines.push((i+1)+'. ['+c.type+'] '+c.text));if(r.hypotheses.length){lines.push('','Hipótesis exploratorias:');r.hypotheses.forEach(h=>lines.push('- '+h.text+' Confianza: '+h.confidence+'.'));}if(r.contradictions.length){lines.push('','Revisar posibles contradicciones:');r.contradictions.forEach(c=>lines.push('- '+c.a+' frente a '+c.b));}lines.push('','Límites: '+r.limitations.join(' '));return {text:lines.join('\n'),report:r};}
 g.OdiseoReasoningCore=Object.freeze({version:VERSION,normalize:norm,tokenize:tokens,classify,extract,analyze,answer,describe:()=>({version:VERSION,mode:'local-symbolic',network:false,remoteModel:false,operations:['statement extraction','rule-based classification','lexical relation mapping','numeric recurrence detection','possible contradiction flags','falsifiable exploratory hypotheses'],limitations:['not an LLM','no general semantic understanding','no external fact verification','no causal inference from text overlap']})});
})(typeof window!=='undefined'?window:globalThis);
