/* TIC 1.2 — inferencia exploratoria: PID I_min, confusores y validación temporal.
 * Requiere OdiseoTIC 1.1 cargado antes. No convierte asociación en causalidad.
 */
(function(root){
  'use strict';
  const base= root && root.OdiseoTIC;
  function needBase(){if(!base)throw new Error('Debe cargarse tic_odiseo.js antes de TIC 1.2.');}
  function check(a,n){if(!Array.isArray(a)||a.length<n)throw new Error('Serie inválida o demasiado corta.');}
  function k(v){return JSON.stringify(v);}
  function count(a){const m=new Map();for(const v of a)m.set(k(v),(m.get(k(v))||0)+1);return m;}
  function rng(seed){let x=seed>>>0;return ()=>{x=(1664525*x+1013904223)>>>0;return x/4294967296;};}
  function aligned(source,target,confounders,lag){
    check(source,lag+8);check(target,lag+8);if(source.length!==target.length)throw new Error('Longitudes incompatibles.');
    if(!Array.isArray(confounders))confounders=[];
    for(const c of confounders){check(c,lag+8);if(c.length!==source.length)throw new Error('Confusor de longitud incompatible.');}
    const x=[],y=[],z=[];
    for(let t=lag;t<target.length;t++){x.push(source[t-lag]);y.push(target[t]);z.push([target[t-lag],...confounders.map(c=>c[t-lag])]);}
    return {x,y,z};
  }
  function teFromAligned(a){return base.conditionalMI(a.x,a.y,a.z);}
  function transferEntropyConditioned(source,target,confounders=[],lag=1){needBase();return teFromAligned(aligned(source,target,confounders,lag));}
  function specificInformation(source,target){
    const n=source.length,cs=count(source),ct=count(target),joint=count(source.map((v,i)=>[v,target[i]]));
    const out=new Map();
    for(const [yk,ny] of ct){const y=JSON.parse(yk);let info=0;
      for(const [pair,nxy] of joint){const [x,yy]=JSON.parse(pair);if(k(yy)!==yk)continue;const pxy=nxy/ny,px=cs.get(k(x))/n,py=ny/n;info+=pxy*Math.log2(pxy/px);}
      out.set(yk,Math.max(0,info));
    }
    return out;
  }
  // Williams-Beer I_min PID: una elección explícita, no una PID única ni universal.
  function pidImin(source1,source2,target){needBase();check(source1,1);check(source2,1);check(target,1);if(source1.length!==source2.length||source1.length!==target.length)throw new Error('Longitudes incompatibles.');
    const s1=specificInformation(source1,target),s2=specificInformation(source2,target),ct=count(target),n=target.length;let redundancy=0;
    for(const [yk,ny] of ct)redundancy+=(ny/n)*Math.min(s1.get(yk)||0,s2.get(yk)||0);
    const mi1=base.mutualInformation(source1,target),mi2=base.mutualInformation(source2,target),joint=base.mutualInformation(source1.map((v,i)=>[v,source2[i]]),target);
    const u1=Math.max(0,mi1-redundancy),u2=Math.max(0,mi2-redundancy),synergy=Math.max(0,joint-redundancy-u1-u2);
    return {definition:'Williams-Beer I_min',redundancyBits:redundancy,unique1Bits:u1,unique2Bits:u2,synergyBits:synergy,miSource1Bits:mi1,miSource2Bits:mi2,jointInformationBits:joint,closureResidualBits:joint-(redundancy+u1+u2+synergy),warning:'I_min es una definición PID concreta con limitaciones conocidas; no es una descomposición universal ni demuestra emergencia.'};
  }
  function quantile(a,q){const s=a.slice().sort((x,y)=>x-y);const p=(s.length-1)*q,lo=Math.floor(p),hi=Math.ceil(p);return s[lo]+(s[hi]-s[lo])*(p-lo);}
  function inferTransferEntropy(source,target,options={}){needBase();
    const lag=options.lag||1,confounders=options.confounders||[],permutations=options.permutations||199,bootstraps=options.bootstraps||199,blockLength=options.blockLength||Math.max(2,lag+1),random=rng(options.seed||73129);
    const a=aligned(source,target,confounders,lag),n=a.x.length;if(n<Math.max(20,blockLength*3))throw new Error('Muestra insuficiente para inferencia temporal.');
    const observed=teFromAligned(a),nullValues=[];
    for(let b=0;b<permutations;b++){const min=blockLength,max=n-blockLength;if(max<=min)throw new Error('Bloque demasiado largo para permutación circular.');const shift=min+Math.floor(random()*(max-min+1));const x=a.x.map((_,i)=>a.x[(i+shift)%n]);nullValues.push(teFromAligned({x,y:a.y,z:a.z}));}
    const exceed=nullValues.filter(v=>v>=observed-1e-12).length,p=(exceed+1)/(permutations+1),nullMean=nullValues.reduce((s,v)=>s+v,0)/nullValues.length;
    const boot=[];
    for(let b=0;b<bootstraps;b++){const x=[],y=[],z=[];while(x.length<n){const start=Math.floor(random()*n);for(let j=0;j<blockLength&&x.length<n;j++){const i=(start+j)%n;x.push(a.x[i]);y.push(a.y[i]);z.push(a.z[i]);}}boot.push(teFromAligned({x,y,z}));}
    return {lag,observedBits:observed,nullMeanBits:nullMean,biasAdjustedBits:Math.max(0,observed-nullMean),permutationPValue:p,permutations,bootstrapReplicates:bootstraps,blockLength,confidence95Bits:[quantile(boot,0.025),quantile(boot,0.975)],method:'circular-shift null + moving-block bootstrap on aligned temporal tuples',confoundersCount:confounders.length,limits:['El test circular requiere estacionariedad aproximada y ausencia de tendencias no modeladas.','El bootstrap por bloques aproxima dependencia temporal; el intervalo no corrige confusores omitidos.','La corrección observada menos media nula es exploratoria, no un estimador universal insesgado.','El valor p no prueba causalidad; la interpretación causal exige diseño/intervención.']};
  }
  const api={version:'TIC-1.2-alpha',transferEntropyConditioned,pidImin,inferTransferEntropy};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.OdiseoTICInference=api;
})(typeof window!=='undefined'?window:globalThis);
