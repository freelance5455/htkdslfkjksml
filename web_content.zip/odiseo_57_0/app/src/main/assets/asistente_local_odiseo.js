/* Odiseo Local Conversational Core — no GPT, no remote model, no network calls.
 * Deterministic command routing and engine orchestration; not a general LLM.
 */
(function (g) {
  'use strict';
  const VERSION = '0.3.0-alpha-semantic-memory';
  const STORE = 'odiseo_local_chat_v1';
  const pendingModel = new Map();
  let modelRequestCounter = 0;
  g.odiseoOnLocalModelResult = function(id, text, error) { const p = pendingModel.get(String(id)); if (!p) return; pendingModel.delete(String(id)); if (error) p.reject(new Error(error)); else p.resolve(String(text || '')); };
  g.odiseoOnModelStatus = function(state, detail) { const el = g.document && g.document.getElementById('odiseoChatStatus'); if (el) el.textContent = 'Modelo local · ' + state + ' · ' + detail; };
  function askLocalModel(prompt) { return new Promise((resolve,reject)=>{ const id='local_'+(++modelRequestCounter); pendingModel.set(id,{resolve,reject}); try { g.OdiseoNative.generateLocal(prompt,id); } catch(e) { pendingModel.delete(id); reject(e); } }); }
  // Inventario contrastado con los exports reales de los scripts incluidos en index.html.
  // "available" significa API global cargada, no integración funcional certificada.
  const ENGINE_KEYS = [
    ['Algoritmo A/B/C/H','OdiseoAlgorithm'],['ESPEJO','OdiseoMirror'],['Acelerador','OdiseoAccelerator'],
    ['Acertijos','OdiseoRiddle'],['Evolución','OdiseoEvolution'],['Interacción','OdiseoInteraction'],
    ['Convergencia','OdiseoConvergence'],['Objetivo evolutivo','OdiseoMovingTarget'],['Sensibilidad','OdiseoSensitivity'],
    ['Energía','OdiseoEnergy'],['Investigación','OdiseoResearch'],['Creador autónomo','OdiseoCreator'],
    ['Penélope','OdiseoPenelope'],['Crecimiento','OdiseoGrowth'],['Duelo recíproco','OdiseoDuet'],
    ['Independencia','OdiseoIndependence'],['Integrador E','OdiseoIntegrator'],['Judas Tadeo','OdiseoJudasTadeo'],
    ['Laboratorio de loterías','OdiseoLotteryLab'],['Sherlock','OdiseoSherlock'],
    ['Integrador de evidencias','OdiseoEvidenceIntegrator'],['Auditor de comunicación','OdiseoCommunicationAuditor'],
    ['Lenguaje de comunicación','OdiseoQuestionLanguage'],['Ciclo integrado','OdiseoIntegratedCycle'],
    ['Núcleo unificado','OdiseoUnifiedCore'],['Biblioteca activa','OdiseoActiveLibrary'],
    ['Patrón adaptativo','OdiseoAdaptivePattern'],['Semáforo','OdiseoSemaphore'],
    ['TIC','OdiseoTIC'],['TIC inferencial','OdiseoTICInference']
  ];
  const norm = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  function status(){return ENGINE_KEYS.map(([name,key])=>({name,key,available:!!g[key]}));}
  function history(){try{const x=JSON.parse(g.localStorage.getItem(STORE)||'[]');return Array.isArray(x)?x:[];}catch(_){return [];}}
  function save(msg){const h=history();h.push(msg);g.localStorage.setItem(STORE,JSON.stringify(h.slice(-500)));}
  function response(text,meta={}){const m={id:'m_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),at:new Date().toISOString(),role:'assistant',text,meta};save(m);return m;}
  async function executeAudit(){
    if(!g.OdiseoUnifiedCore||typeof g.OdiseoUnifiedCore.run!=='function') return response('El núcleo unificado no está disponible. No voy a simular una auditoría.',{status:'UNAVAILABLE'});
    try{const r=await g.OdiseoUnifiedCore.run();return response('He ejecutado el núcleo unificado.\n\nEstado: '+(r.status||'sin estado')+'\nMódulos ejecutados: '+(r.executed??'?')+'/'+(r.total??'?')+'\nIncidencias: '+(r.failed??'?')+'\n\nEl informe íntegro queda disponible en el panel de auditoría. Esta ejecución no demuestra verdad semántica ni inteligencia general.',{kind:'audit',report:r});}
    catch(e){return response('La auditoría se detuvo con un error: '+String(e.message||e),{status:'ERROR'});}
  }
  async function reply(input){
    const raw=String(input||'').trim(); if(!raw) return response('Escribe una pregunta o una instrucción.');
    save({id:'u_'+Date.now().toString(36),at:new Date().toISOString(),role:'user',text:raw});
    const q=norm(raw);
    if(/^(hola|buenos dias|buenas|buenas tardes|buenas noches|hey)\b/.test(q)) return response('Estoy aquí. Soy el núcleo conversacional local de Odiseo. Puedo describir el sistema, revisar qué motores están cargados y ejecutar algunas operaciones locales. No soy un modelo lingüístico general y no consulto GPT ni servidores externos.');
    if(/^(razona local|analiza local|hipotesis local)\s*:/i.test(raw)){
      const core=g.OdiseoReasoningCore;if(!core||typeof core.answer!=='function')return response('El núcleo de razonamiento local no está cargado.',{status:'UNAVAILABLE'});
      const payload=raw.replace(/^(razona local|analiza local|hipotesis local)\s*:/i,'').trim();
      try{const result=core.answer(payload);return response(result.text,{kind:'local-reasoning',report:result.report,engine:'OdiseoReasoningCore'});}catch(e){return response('El núcleo rechazó la entrada: '+String(e.message||e),{status:'ERROR',engine:'OdiseoReasoningCore'});}
    }
    if(/(nucleo de razonamiento|estado del razonamiento local)/.test(q)){const core=g.OdiseoReasoningCore;return response(core?'Núcleo de razonamiento local cargado. Versión '+core.version+'. Opera sin red ni modelo remoto mediante clasificación simbólica, extracción de afirmaciones, relaciones léxicas, coincidencias numéricas y alertas de contradicción. No equivale a un LLM.':'El núcleo de razonamiento local no está cargado.',{kind:'reasoning-core-status',available:!!core,description:core&&core.describe()});}
    if(/^(memoria sem[aá]ntica local|registra memoria local)\s*:/i.test(raw)){
      const mem=g.OdiseoSemanticMemory;if(!mem)return response('La memoria semántica no está cargada.',{status:'UNAVAILABLE'});
      const payload=raw.replace(/^(memoria sem[aá]ntica local|registra memoria local)\s*:/i,'').trim(),fields={};
      payload.split(/\s*;\s*/).forEach(part=>{const i=part.indexOf('=');if(i>0)fields[norm(part.slice(0,i).trim())]=part.slice(i+1).trim();});
      if(!fields.texto||!fields.fuente)return response('Faltan texto y fuente. Formato: memoria semántica local: tipo=observation; estado=unverified; fuente=usuario/documento/prueba; confianza=0.6; texto=...; etiquetas=...; contexto=...',{status:'NEEDS_INPUT'});
      try{const item=mem.add({type:fields.tipo||'note',state:fields.estado||'unverified',source:fields.fuente,text:fields.texto,confidence:fields.confianza==null?null:Number(fields.confianza),tags:fields.etiquetas?fields.etiquetas.split(',').map(x=>x.trim()).filter(Boolean):[],context:fields.contexto||''});return response('Registro semántico guardado en este dispositivo.\nID: '+item.id+'\nTipo: '+item.type+'; estado: '+item.state+'; fuente: '+item.source+'\nLa etiqueta de estado no constituye verificación automática.',{kind:'semantic-memory-add',record:item});}catch(e){return response('No se pudo registrar: '+String(e.message||e),{status:'ERROR'});}
    }
    if(/^(busca memoria sem[aá]ntica local|recupera sem[aá]ntica local)\s*:/i.test(raw)){
      const mem=g.OdiseoSemanticMemory;if(!mem)return response('La memoria semántica no está cargada.',{status:'UNAVAILABLE'});
      const query=raw.replace(/^(busca memoria sem[aá]ntica local|recupera sem[aá]ntica local)\s*:/i,'').trim(),hits=mem.search(query,8);
      return response(hits.length?'Recuperación local BM25 (coincidencia léxica, no comprensión semántica):\n'+hits.map((x,i)=>(i+1)+'. ['+x.type+' / '+x.state+'] '+x.text+'\n   ID: '+x.id+'; fuente: '+x.source+'; score: '+x.score).join('\n'):'No hay registros léxicamente relacionados.',{kind:'semantic-memory-search',matches:hits});
    }
    if(/^(estado memoria semantica|audita memoria semantica)$/.test(q)){
      const mem=g.OdiseoSemanticMemory;if(!mem)return response('La memoria semántica no está cargada.',{status:'UNAVAILABLE'});const st=mem.stats(),conf=mem.candidates();
      return response('Estado de memoria semántica local\nRegistros: '+st.records+'\nPor tipo: '+JSON.stringify(st.byType)+'\nPor estado: '+JSON.stringify(st.byState)+'\nConflictos candidatos para revisión: '+conf.length+'\nAlmacenamiento: '+st.storage+'; red: no; modelo remoto: no.\n\nLímites: '+mem.describe().limits.join(' '),{kind:'semantic-memory-status',stats:st,candidates:conf});
    }
    if(/^(exporta memoria semantica local)$/.test(q)){
      const mem=g.OdiseoSemanticMemory;if(!mem)return response('La memoria semántica no está cargada.',{status:'UNAVAILABLE'});const data=mem.exportData();return response('Exportación preparada ('+data.records.length+' registros). El objeto íntegro está adjunto a esta respuesta técnica; todavía no se ha escrito un archivo descargable.',{kind:'semantic-memory-export',data});
    }
    if(/(auditoria|auditar|revisa el sistema|estado global|semaforo)/.test(q)) return await executeAudit();
    if(/(herramientas locales|registro de capacidades|contratos de herramientas)/.test(q)){
      const registry=g.OdiseoCapabilityRegistry;
      if(!registry) return response('El registro de capacidades locales no está cargado.',{status:'UNAVAILABLE'});
      const items=registry.catalog();
      return response('Herramientas locales registradas:\n'+items.map(x=>'• '+x.label+' — '+(x.available?'disponible':'no disponible')+'; entrada: '+x.input).join('\n')+'\n\nLos contratos verifican la forma de entrada y la presencia de la función; no certifican verdad ni calidad semántica.',{kind:'capability-catalog',capabilities:items});
    }
    if(/^recuerda local\s*:/i.test(raw)){
      const tools=g.OdiseoLocalTools, payload=raw.replace(/^recuerda local\s*:/i,'').trim(), parts=payload.split(/\s+\|\s*fuente\s*:\s*/i);
      if(!tools) return response('La memoria local no está disponible.',{status:'UNAVAILABLE'});
      if(parts.length<2||!parts[1].trim()) return response('Indica contenido y procedencia. Formato: recuerda local: hecho o nota | fuente: documento/prueba/usuario',{status:'NEEDS_INPUT'});
      try{const item=tools.remember(parts[0],parts.slice(1).join(' | '));return response('Guardado en la memoria local de este dispositivo. ID: '+item.id+'; procedencia: '+item.source+'. No se ha verificado la verdad del contenido.',{kind:'local-memory',record:item});}
      catch(e){return response('No se pudo guardar: '+String(e.message||e),{status:'ERROR'});}
    }
    if(/^(recupera local|busca en memoria local)\s*:/i.test(raw)){
      const tools=g.OdiseoLocalTools;if(!tools)return response('La memoria local no está disponible.',{status:'UNAVAILABLE'});
      const query=raw.replace(/^(recupera local|busca en memoria local)\s*:/i,'').trim(), matches=tools.recall(query,5);
      return response(matches.length?'Coincidencias locales (similitud léxica, no verificación):\n'+matches.map((x,i)=>(i+1)+'. '+x.text+'\n   Fuente: '+x.source+'; puntuación: '+x.score.toFixed(3)).join('\n'):'No hay coincidencias locales para esa consulta.',{kind:'local-memory-search',matches});
    }
    if(/(motores|modulos|que tienes|que puedes hacer|capacidades|inventario)/.test(q)){
      const s=status(),yes=s.filter(x=>x.available),no=s.filter(x=>!x.available);
      return response('Inventario local de motores:\n'+yes.map(x=>'• '+x.name+' — cargado').join('\n')+'\n'+(no.length?'\nNo localizados en este runtime:\n'+no.map(x=>'• '+x.name).join('\n'):'')+'\n\n“Cargado” solo indica que existe una API JavaScript en esta sesión; no certifica integración funcional entre todos los motores.',{kind:'inventory',available:yes.map(x=>x.name),missing:no.map(x=>x.name)});
    }
    if(/(que eres|eres consciente|conciencia|eres una ia)/.test(q)) return response('Soy un programa local de conversación por reglas e invocación de motores. No tengo evidencia de conciencia, experiencia subjetiva ni voluntad propia. Puedo mantener contexto guardado en este dispositivo y ejecutar funciones explícitas, pero no debo presentarlo como comprensión humana.');
    if(/(sin internet|offline|conectado|gpt|openai|servidor)/.test(q)) return response('Esta edición no contiene conexión a GPT, API remota ni servidor conversacional. El chat y los motores se ejecutan localmente. Por eso la conversación es más limitada que GPT: clasifica intenciones conocidas, responde con información del sistema y deriva tareas a motores concretos.');
    if(/(busca relaciones|rastrea relaciones|analiza estos rastros|sherlock)/.test(q)){
      const api=g.OdiseoSherlock;
      if(!api||typeof api.investigate!=='function') return response('Sherlock no está disponible en este runtime. No he ejecutado el análisis.',{status:'UNAVAILABLE'});
      const payload=raw.replace(/.*?(?:busca relaciones|rastrea relaciones|analiza estos rastros|sherlock)\s*/i,'').trim();
      const observations=payload.split(/\s*;\s*/).filter(Boolean).slice(0,100);
      if(observations.length<2) return response('Para ejecutar Sherlock necesito al menos dos observaciones separadas por punto y coma. Ejemplo: «Sherlock: la muestra A contiene 12 y 18; la muestra B contiene 18 y 24».',{status:'NEEDS_INPUT'});
      try{const traces=observations.map((observation,i)=>({id:'chat-trace-'+(i+1),source:'user_input',observation}));const result=api.investigate({traces,budget:100,strategyBudget:4,hypotheses:[]});return response('Sherlock ha analizado '+result.summary.accepted+' observaciones.\nVeredicto: '+result.verdict+'\nCandidatos exploratorios: '+(result.investigation?.candidates?.length||0)+'\n\n'+JSON.stringify(result.investigation?.candidates||[],null,2)+'\n\nSon coincidencias candidatas, no causalidad ni prueba de relación.',{kind:'engine',engine:'Sherlock',result});}catch(e){return response('Sherlock no pudo completar el análisis: '+String(e.message||e),{status:'ERROR'});}
    }
    if(/^(penelope|penélope)\s*:/i.test(raw)){
      const api=g.OdiseoPenelope;
      if(!api||typeof api.unweave!=='function'||typeof api.validateProposal!=='function') return response('Penélope no está disponible en este runtime. No he ejecutado el análisis.',{status:'UNAVAILABLE'});
      const payload=raw.replace(/^(penelope|penélope)\s*:/i,'').trim();
      let request; try { request=JSON.parse(payload); } catch(e) { return response('Entrada Penélope inválida. Debes proporcionar un AST JSON. Ejemplo: Penélope: {\"type\":\"binary\",\"op\":\"sum\",\"a\":{\"type\":\"primitive\",\"name\":\"x\"},\"b\":{\"type\":\"primitive\",\"name\":\"y\"}}',{status:'NEEDS_INPUT',engine:'Penélope'}); }
      if(!request||typeof request!=='object'||!request.ast) return response('Falta el campo obligatorio «ast». El original no se modifica.',{status:'NEEDS_INPUT',engine:'Penélope'});
      try {
        const result=api.unweave(request.ast,String(request.sourceId||'local-chat-penelope'));
        const valid=[]; const rejected=[];
        for(const proposal of result.proposals||[]){try{api.validateProposal(proposal);valid.push(proposal);}catch(e){rejected.push(String(e.message||e));}}
        return response('Penélope examinó «'+result.originalExpression+'».\nPropuestas válidas: '+valid.length+'; examinadas: '+result.examined+'.\n'+valid.slice(0,8).map((x,i)=>(i+1)+'. '+x.candidateExpression+' (retira '+x.removedNodes+' nodos)').join('\n')+'\n\nEl AST original se conserva. La simplificación estructural no demuestra equivalencia semántica. '+(rejected.length?'Propuestas rechazadas por validador: '+rejected.length+'.':''),{kind:'engine',engine:'Penélope',result:{...result,validatedProposals:valid,rejectedProposals:rejected}});
      } catch(e) { return response('Penélope rechazó la entrada o no pudo completar el análisis: '+String(e.message||e),{status:'ERROR',engine:'Penélope'}); }
    }
    if(/(reencuadra|alternativas|estoy bloqueado|bloqueo|judas tadeo)/.test(q)){
      const api=g.OdiseoJudasTadeo;if(!api||typeof api.reframe!=='function')return response('Judas Tadeo no está disponible.',{status:'UNAVAILABLE'});
      const result=api.reframe({domain:'general',block:'wrong_representation',premises:[raw],attempted:[],constraints:['No inventar datos ni declarar solución sin prueba']});
      return response('Judas Tadeo propone vías alternativas para examinar el problema:\n'+result.routes.map((x,i)=>(i+1)+'. '+x).join('\n')+'\n\nReencuadres: '+result.alternativeFrames.map(x=>x.name+': '+x.question).join('\n')+'\n\nSon propuestas de investigación, no soluciones demostradas.',{kind:'engine',engine:'Judas Tadeo',result});
    }
    if(/(audita el espejo|auditoria del espejo|puntos ciegos del grafo)/.test(q)){
      const api=g.OdiseoMirror;if(!api?.auditSelf)return response('ESPEJO no está disponible.',{status:'UNAVAILABLE'});
      try{const graph=JSON.parse(g.localStorage.getItem('odiseo_mirror_graph_501')||JSON.stringify(api.empty()));const result=api.auditSelf(graph);return response('Auditoría ESPEJO ejecutada. Nodos: '+result.summary.nodes+'; relaciones: '+result.summary.edges+'; hallazgos: '+result.summary.findings+'\n'+JSON.stringify(result.findings,null,2)+'\n\nLa auditoría solo examina el grafo local registrado.',{kind:'engine',engine:'ESPEJO',result});}catch(e){return response('No se pudo auditar ESPEJO: '+String(e.message||e),{status:'ERROR'});}
    }
    if(/(espejo|puntos ciegos|preguntas abiertas)/.test(q)){
      try{const api=g.OdiseoMirror, graph=JSON.parse(g.localStorage.getItem('odiseo_mirror_graph_501')||'{"schema":"ODISEO_MIRROR_GRAPH_1","nodes":[],"edges":[],"learnings":[]}');
        if(api?.proposeQuestions){const r=api.proposeQuestions(graph,{limit:8});return response('ESPEJO ha generado preguntas heurísticas a partir del grafo local.\n'+JSON.stringify(r,null,2),{kind:'engine',engine:'ESPEJO',result:r});}
        return response('ESPEJO está cargado, pero esta versión no expone el generador de preguntas.');
      }catch(e){return response('No he podido ejecutar ESPEJO: '+String(e.message||e));}
    }
    if(/(ayuda|comandos|como funciona)/.test(q)) return response('Puedes pedirme, por ejemplo:\n• «¿Qué motores tienes?»\n• «Herramientas locales»\n• «Razona local: observación A; observación B»\n• «Estado del razonamiento local»\n• «Recuerda local: nota | fuente: documento»\n• «Recupera local: nota»\n• «Memoria semántica local: tipo=observation; estado=unverified; fuente=usuario; texto=... »\n• «Busca memoria semántica local: tema»\n• «Estado memoria semántica»\n• «Audita el sistema»\n• «Ejecuta ESPEJO y genera preguntas»\n• «Audita el espejo»\n• «Sherlock: observación A; observación B»\n• «Reencuadra este bloqueo»\n• «Estado cerebro local»\n• «¿Qué eres?»\n• «¿Funciona sin Internet?»\n\nPara análisis especializados, la siguiente etapa será conectar cada motor mediante contratos explícitos y formularios de entrada validados. No inventaré ejecuciones que no pueda realizar.');
    if (/^(estado cerebro local|estado cerebro cognitivo|audita cerebro local)$/.test(q)) {
      const brain=g.OdiseoCognitiveBrain;
      if(!brain) return response('El orquestador cognitivo no está cargado.',{status:'UNAVAILABLE'});
      const st=brain.status();
      return response('CEREBRO COGNITIVO LOCAL ODISEO\nVersión: '+st.version+'\nModelo neuronal cargado: '+st.localModelReady+'\nMemoria semántica: '+st.semanticMemory+'\nNúcleo de razonamiento: '+st.reasoningCore+'\nMotores detectados: '+st.loadedEngines.length+'\nTrazas locales: '+st.traces+'\nRed: no; GPT remoto: no.\n\nCapacidades: '+st.capabilities.join(', ')+'.\nLímites: '+st.limitations.join('; ')+'.',{kind:'cognitive-brain-status',status:st});
    }
    if (g.OdiseoNative && typeof g.OdiseoNative.isLocalModelReady === 'function' && g.OdiseoNative.isLocalModelReady()) {
      try {
        const central = g.OdiseoCentralBrain;
        const brain = g.OdiseoCognitiveBrain;
        const session = central ? await central.begin(raw) : (brain ? await brain.begin(raw) : null);
        const prompt = session ? session.prompt : ('Responde en español, distingue hechos e hipótesis y no inventes ejecuciones.\n\nMENSAJE DEL USUARIO:\n' + raw);
        const generated = await askLocalModel(prompt);
        if (!generated.trim()) throw new Error('El modelo devolvió una respuesta vacía');
        const completed = central && session ? central.finish(raw, generated, session) : (brain && session ? brain.finish(raw, generated, session.plan) : null);
        const cognitive = completed && completed.cognitive ? completed.cognitive : completed;
        const audit = completed && completed.audit ? completed.audit : (cognitive && cognitive.audit);
        const disclaimer = (completed && completed.disclaimer) || (cognitive && cognitive.disclaimer) || 'Auditoría heurística; no verificación factual automática.';
        const auditText = completed ? '\n\n' + disclaimer + '\nAuditoría: ' + ((audit && audit.status) || 'UNVERIFIED') + ((audit && audit.flags && audit.flags.length) ? '\nAlertas: ' + audit.flags.join(' | ') : '') : '\n\n[Generado por modelo local; no verificado automáticamente.]';
        return response(generated + auditText,{kind:'local-neural-model',verified:false,modelStatus:'READY',brain:completed,centralDecision:session&&session.decision,plan:session&&session.cognitive&&session.cognitive.plan});
      } catch(e) { return response('El modelo local falló: '+String(e.message||e)+'. No voy a inventar una respuesta. El chat determinista sigue disponible.',{status:'LOCAL_MODEL_ERROR'}); }
    }
    return response('He registrado tu mensaje, pero todavía no hay un modelo neuronal local cargado. Puedes usar las órdenes de los motores existentes o importar un archivo .litertlm desde el panel del chat. No voy a fingir que el cerebro neuronal ya está funcionando.',{kind:'fallback',needsCapability:true,modelStatus:'NOT_READY'});
  }
  g.OdiseoLocalAssistant=Object.freeze({version:VERSION,reply,history,clear(){g.localStorage.removeItem(STORE);},status,describe(){return {version:VERSION,mode:'offline-deterministic-router',remoteModel:false,network:false,limitations:['No es un LLM','No genera lenguaje abierto de forma general','Solo ejecuta rutas explícitas implementadas','Los motores deben validarse individualmente'],localTools:!!g.OdiseoLocalTools,semanticMemory:!!g.OdiseoSemanticMemory,capabilityRegistry:!!g.OdiseoCapabilityRegistry};}});
})(window);
