/* ODISEO A/B/C/H v1.0 — motor determinista de auditoría Collatz.
 * A propone invariantes; B busca contraejemplos; C recalcula independientemente;
 * H asigna presupuesto y detiene el ciclo. No es aprendizaje autónomo ni prueba Collatz.
 */
(function (global) {
  'use strict';
  const VERSION = '1.0.0-abch-collatz';
  const MAX_INPUT = 1000000;
  const MAX_TESTS = 200000;

  function asSafeInt(value, fallback, min, max, name) {
    if (value === undefined || value === null || value === '') return fallback;
    const n = Number(value);
    if (!Number.isSafeInteger(n) || n < min || n > max) throw new Error((name || 'Valor') + ' fuera de límites (' + min + '–' + max + ').');
    return n;
  }
  function v2Big(n) {
    let a = 0;
    while ((n & 1n) === 0n) { n >>= 1n; a++; }
    return a;
  }
  function syracuse(n) {
    if (typeof n !== 'bigint' || n <= 0n || (n & 1n) === 0n) throw new Error('La entrada debe ser un entero impar positivo.');
    const t = 3n * n + 1n;
    const a = v2Big(t);
    return { value: t >> BigInt(a), exponent: a };
  }
  // Implementación de referencia separada para la comprobación C.
  function referenceSyracuse(n) {
    let t = 3n * n + 1n, a = 0;
    while (t % 2n === 0n) { t /= 2n; a++; }
    return { value: t, exponent: a };
  }
  function discoverA(start, end) {
    return [
      { id: 'positive_odd', claim: 'F(n) es un entero impar positivo para todo n impar positivo.', kind: 'invariante estructural' },
      { id: 'multiple_of_3', claim: 'Si 3 divide a n, entonces 3 no divide a F(n).', kind: 'invariante modular' },
      { id: 'range', claim: `Explorar impares entre ${start} y ${end} para buscar contraejemplos.`, kind: 'objetivo experimental' }
    ];
  }
  function refuteB(start, end, budget) {
    const counterexamples = { positive_odd: [], multiple_of_3: [] };
    let tested = 0;
    for (let n = start; n <= end && tested < budget; n++) {
      if ((n & 1) === 0) continue;
      tested++;
      const out = syracuse(BigInt(n)).value;
      if (out <= 0n || (out & 1n) === 0n) counterexamples.positive_odd.push({ n, result: out.toString() });
      if (n % 3 === 0 && out % 3n === 0n) counterexamples.multiple_of_3.push({ n, result: out.toString() });
    }
    return { tested, counterexamples };
  }
  function evaluateC(start, end, bResult) {
    let checked = 0, disagreements = 0;
    const mismatches = [];
    for (let n = start; n <= end && checked < bResult.tested; n++) {
      if ((n & 1) === 0) continue;
      const x = BigInt(n), fast = syracuse(x), independent = referenceSyracuse(x);
      checked++;
      if (fast.value !== independent.value || fast.exponent !== independent.exponent) {
        disagreements++;
        if (mismatches.length < 10) mismatches.push(n);
      }
    }
    const modularProof = 'Para n=3k, 3n+1 ≡ 1 (mod 3). Como 2^a es invertible módulo 3 y F(n)·2^a=3n+1, se deduce F(n) ≢ 0 (mod 3).';
    return { checked, disagreements, mismatches, modularArgument: modularProof,
      status: disagreements === 0 ? 'COHERENCIA_INTERNA' : 'DISCREPANCIA_DETECTADA' };
  }
  function runCollatzAudit(options) {
    const start = asSafeInt(options && options.start, 1, 1, MAX_INPUT, 'Inicio');
    const end = asSafeInt(options && options.end, 1000, start, MAX_INPUT, 'Final');
    const requested = asSafeInt(options && options.maxTests, 10000, 1, MAX_TESTS, 'Presupuesto');
    // H: presupuesto explícito y acotado; un ciclo completo A→B→C.
    const oddCount = Math.floor((end + 1) / 2) - Math.floor((start) / 2);
    const budget = Math.min(requested, Math.max(0, oddCount));
    const a = discoverA(start, end);
    const b = refuteB(start, end, budget);
    const c = evaluateC(start, end, b);
    const h = { controller: 'H', cycles: 1, budget, tested: b.tested,
      stopReason: b.tested >= budget ? 'PRESUPUESTO_CUMPLIDO' : 'RANGO_AGOTADO',
      nextAction: c.disagreements ? 'DETENER_Y_REVISAR_IMPLEMENTACIONES' : 'AMPLIAR_RANGO_O_REVISAR_OTRA_CONJETURA' };
    return {
      engine: 'ODISEO A/B/C/H', version: VERSION, task: 'AUDITORIA_SYRACUSE_ACELERADA',
      status: c.disagreements ? 'REQUIERE_REVISION' : 'EXPERIMENTO_COMPLETADO',
      scope: { start, end, oddInputsTested: b.tested, requestedBudget: requested },
      A: { role: 'Descubridor', hypotheses: a },
      B: { role: 'Generador y refutador', counterexamples: b.counterexamples, tested: b.tested },
      C: { role: 'Evaluador/Observador', ...c },
      H: h,
      conclusion: 'La ausencia de contraejemplos en un rango finito no demuestra la conjetura de Collatz. El argumento modular indicado sí demuestra la propiedad específica para múltiplos de 3, bajo la definición de F usada aquí.'
    };
  }
  function solveIndependently(task) {
    if (!task || task.kind !== 'syracuse_batch' || !Array.isArray(task.inputs)) throw new Error('Tarea de independencia no válida.');
    const results = task.inputs.map(raw => {
      const n = BigInt(raw);
      const r = syracuse(n);
      return { n: n.toString(), successor: r.value.toString(), exponent: r.exponent };
    });
    return { engine: 'Odiseo A/B/C/H', method: 'descomposición binaria mediante desplazamientos', taskId: task.id, results,
      claims: { positiveOddOutput: results.every(x => BigInt(x.successor) > 0n && BigInt(x.successor) % 2n === 1n), allSuppliedInputsDecrease: results.every(x => BigInt(x.successor) < BigInt(x.n)) } };
  }
  function reviewPeer(task, peer) {
    const errors = [];
    if (!peer || peer.taskId !== task.id || !Array.isArray(peer.results)) return [{ type: 'INVALID_PEER_RESPONSE', detail: 'Respuesta ajena incompleta o de otra tarea.' }];
    if (peer.results.length !== task.inputs.length) errors.push({ type: 'RESULT_COUNT', expected: task.inputs.length, actual: peer.results.length });
    for (const raw of task.inputs) {
      const n = BigInt(raw), expected = syracuse(n), found = peer.results.find(x => x.n === n.toString());
      if (!found || found.successor !== expected.value.toString() || found.exponent !== expected.exponent) errors.push({ type: 'ARITHMETIC_MISMATCH', input: n.toString(), expectedSuccessor: expected.value.toString(), expectedExponent: expected.exponent, received: found || null });
    }
    return errors;
  }
  const api = {
    version: VERSION,
    status: 'MOTOR_ABCH_OPERATIVO_EXPERIMENTAL',
    describe() { return { name: 'Odiseo A/B/C/H', version: VERSION, status: this.status,
      capabilities: ['proponer invariantes acotadas', 'buscar contraejemplos en Syracuse acelerada', 'recalcular con implementación independiente', 'controlar presupuesto y parada'],
      limitations: ['no demuestra Collatz', 'no aprende ni modifica su código', 'no genera por sí solo APK firmada'] }; },
    run(input) {
      if (!input || input.task !== 'collatz-audit') return { ok: false, status: 'TASK_NOT_SUPPORTED', supported: ['collatz-audit'] };
      try { return { ok: true, result: runCollatzAudit(input) }; }
      catch (e) { return { ok: false, status: 'INVALID_INPUT', message: e.message }; }
    },
    runCollatzAudit,
    solveIndependently,
    reviewPeer
  };
  global.OdiseoAlgorithm = Object.freeze(api);
})(window);
