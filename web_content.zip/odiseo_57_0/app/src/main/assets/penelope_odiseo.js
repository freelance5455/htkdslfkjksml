/* ODISEO 51.3 — Motor Penélope.
 * Oposición constructiva: descompone estructuras y propone simplificaciones reversibles.
 * Nunca borra el original; cada propuesta conserva AST de origen, linaje y huella.
 */
(function(global){'use strict';
 const VERSION='1.0.0-penelope';
 const PRIMITIVES=['x','y','z','Δ','Ω','0','1','2'];
 const OPS=[{id:'sum',symbol:'+',arity:2},{id:'difference',symbol:'−',arity:2},{id:'product',symbol:'×',arity:2},{id:'compose',symbol:'∘',arity:2},{id:'feedback',symbol:'↻',arity:1},{id:'mirror',symbol:'↔',arity:1},{id:'iterate',symbol:'^*',arity:1},{id:'pair',symbol:'⟨·,·⟩',arity:2}];
 function fail(m){throw new Error(m)}
 function clone(x){return JSON.parse(JSON.stringify(x))}
 function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}
 function inspect(n){if(!n||typeof n!=='object')return {ok:false,nodes:0,depth:0};if(n.type==='primitive')return {ok:PRIMITIVES.includes(n.name),nodes:1,depth:1};if(n.type==='unary'){const a=inspect(n.a),o=OPS.find(x=>x.id===n.op&&x.arity===1);return {ok:!!o&&a.ok,nodes:1+a.nodes,depth:1+a.depth};}if(n.type==='binary'){const a=inspect(n.a),b=inspect(n.b),o=OPS.find(x=>x.id===n.op&&x.arity===2);return {ok:!!o&&a.ok&&b.ok,nodes:1+a.nodes+b.nodes,depth:1+Math.max(a.depth,b.depth)};}return {ok:false,nodes:0,depth:0}}
 function render(n){if(!inspect(n).ok)fail('AST inválido.');if(n.type==='primitive')return n.name;if(n.type==='unary')return OPS.find(x=>x.id===n.op).symbol+'('+render(n.a)+')';return '('+render(n.a)+' '+OPS.find(x=>x.id===n.op).symbol+' '+render(n.b)+')'}
 function proposal(original,candidate,sourceId,reason){const a=inspect(original),b=inspect(candidate);if(!a.ok||!b.ok||b.nodes>=a.nodes)return null;const originalExpression=render(original),candidateExpression=render(candidate),body={sourceId:String(sourceId||'unidentified'),originalExpression,candidateExpression,reason,removedNodes:a.nodes-b.nodes};return {id:'penelope_'+hash(JSON.stringify(body)),sourceId:body.sourceId,originalAst:clone(original),candidateAst:clone(candidate),originalExpression,candidateExpression,reason,originalNodes:a.nodes,candidateNodes:b.nodes,removedNodes:a.nodes-b.nodes,reversible:true,verified:true,fingerprint:hash(JSON.stringify(body))}}
 function unweave(ast,sourceId){const root=inspect(ast);if(!root.ok)fail('Penélope solo acepta estructuras válidas.');const found=[],seen=new Set();function add(c,why){if(!c)return;const p=proposal(ast,c,sourceId,why);if(p&&!seen.has(p.candidateExpression)){seen.add(p.candidateExpression);found.push(p)}}
  function subtrees(node){const out=[];function visit(n){if(n.type==='primitive')return;if(n.type==='unary'){out.push(n.a);visit(n.a);return;}out.push(n.a,n.b);visit(n.a);visit(n.b);}visit(node);return out;}
  function walk(node,path){if(node.type==='unary'){add(node.a,'Retirar el operador '+node.op+' en '+path);walk(node.a,path+'.a');return;}if(node.type==='binary'){add(node.a,'Deshacer la rama derecha y conservar la izquierda en '+path);add(node.b,'Deshacer la rama izquierda y conservar la derecha en '+path);const left=subtrees(node.a),right=subtrees(node.b);for(const l of left)add({type:'binary',op:'pair',a:l,b:node.b},'Desmontar parcialmente la rama izquierda y volver a tejer ambas ramas con pareja en '+path);for(const r of right)add({type:'binary',op:'pair',a:node.a,b:r},'Desmontar parcialmente la rama derecha y volver a tejer ambas ramas con pareja en '+path);for(const l of left.slice(0,8))for(const r of right.slice(0,8))add({type:'binary',op:'pair',a:l,b:r},'Deshacer ambas ramas y volver a tejer sus restos en '+path);walk(node.a,path+'.a');walk(node.b,path+'.b');}}
  walk(ast,'raíz');found.sort((a,b)=>b.removedNodes-a.removedNodes||a.candidateExpression.localeCompare(b.candidateExpression));return {version:VERSION,sourceId:String(sourceId||'unidentified'),originalExpression:render(ast),originalNodes:root.nodes,proposals:found.slice(0,32),examined:found.length,stopReason:found.length?'SIMPLIFICATIONS_FOUND':'ATOMIC_STRUCTURE',epistemicLimit:'Penélope desmonta y puede volver a tejer restos de ambas ramas. La simplificación estructural no demuestra equivalencia semántica ni matemática; el original se conserva siempre.'};}
 function solveIndependently(task){
  if(!task||task.kind!=='syracuse_batch'||!Array.isArray(task.inputs))fail('Tarea de independencia no válida.');
  const results=task.inputs.map(raw=>{let n=BigInt(raw);if(n<=0n||n%2n===0n)fail('La entrada debe ser impar positiva.');let value=3n*n+1n,exponent=0;while(value%2n===0n){value=value/2n;exponent++;}return {n:n.toString(),successor:value.toString(),exponent};});
  return {engine:'Penélope',method:'divisiones enteras sucesivas por dos',taskId:task.id,results,
   claims:{positiveOddOutput:results.every(x=>BigInt(x.successor)>0n&&BigInt(x.successor)%2n===1n),allSuppliedInputsDecrease:results.every(x=>BigInt(x.successor)<BigInt(x.n))}};
 }
 function reviewPeer(task,peer){
  const errors=[];if(!peer||peer.taskId!==task.id||!Array.isArray(peer.results))return [{type:'INVALID_PEER_RESPONSE',detail:'Respuesta ajena incompleta o de otra tarea.'}];
  if(peer.results.length!==task.inputs.length)errors.push({type:'RESULT_COUNT',expected:task.inputs.length,actual:peer.results.length});
  for(const raw of task.inputs){const n=BigInt(raw);let expected=3n*n+1n,a=0;while(expected%2n===0n){expected/=2n;a++;}const found=peer.results.find(x=>x.n===n.toString());if(!found||found.successor!==expected.toString()||found.exponent!==a)errors.push({type:'ARITHMETIC_MISMATCH',input:n.toString(),expectedSuccessor:expected.toString(),expectedExponent:a,received:found||null});}
  return errors;
 }
 function validateProposal(p){if(!p||!p.reversible||!p.verified||!p.fingerprint)fail('Propuesta Penélope incompleta.');const a=inspect(p.originalAst),b=inspect(p.candidateAst);if(!a.ok||!b.ok||render(p.originalAst)!==p.originalExpression||render(p.candidateAst)!==p.candidateExpression||b.nodes>=a.nodes||p.removedNodes!==a.nodes-b.nodes)fail('La propuesta no supera la validación estructural.');const body={sourceId:String(p.sourceId||'unidentified'),originalExpression:p.originalExpression,candidateExpression:p.candidateExpression,reason:p.reason,removedNodes:p.removedNodes};if(hash(JSON.stringify(body))!==p.fingerprint)fail('Huella de propuesta incorrecta.');return p;}
 global.OdiseoPenelope=Object.freeze({version:VERSION,unweave,validateProposal,inspect,render,hash,solveIndependently,reviewPeer,independent:true,destructive:false});
})(window);
