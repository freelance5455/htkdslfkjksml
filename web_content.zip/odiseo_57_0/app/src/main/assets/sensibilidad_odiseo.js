/* ODISEO 50.9 — Sensitivity and finite-time stability probe.
 * Compares two logistic-map trajectories with nearby initial conditions.
 * Reports finite-window diagnostics only; never labels chaos as proven.
 */
(function(global){'use strict';
 const VERSION='1.0.0-sensibilidad', MAX_STEPS=20000;
 function num(v,name){const n=Number(v);if(!Number.isFinite(n))throw Error(name+' debe ser finito.');return n;}
 function orbit(x,r,steps){const a=[x];for(let i=0;i<steps;i++){x=r*x*(1-x);if(!Number.isFinite(x)||x<0||x>1)throw Error('Órbita fuera del intervalo [0,1].');a.push(x);}return a;}
 function analyze(o){o=o||{};const x=num(o.x===undefined?0.2:o.x,'x'),r=num(o.r===undefined?3.8:o.r,'r'),delta=num(o.delta===undefined?1e-8:o.delta,'delta'),steps=num(o.steps===undefined?2000:o.steps,'steps'),burn=num(o.burn===undefined?100:o.burn,'burn');
  if(!(x>0&&x<1))throw Error('x debe estar en (0,1).');if(!(r>0&&r<=4))throw Error('r debe estar en (0,4].');if(!(delta>0&&delta<Math.min(x,1-x)))throw Error('delta debe ser positivo y mantener x+delta dentro de (0,1).');if(!Number.isInteger(steps)||steps<1||steps>MAX_STEPS)throw Error('steps debe ser entero entre 1 y '+MAX_STEPS+'.');if(!Number.isInteger(burn)||burn<0||burn>=steps)throw Error('burn debe ser entero entre 0 y steps-1.');
  const a=orbit(x,r,steps),b=orbit(x+delta,r,steps),dist=[],logs=[];let divergence=0,first=null;
  for(let i=0;i<=steps;i++){const d=Math.abs(a[i]-b[i]);dist.push({n:i,distance:d});if(i>=burn&&d>0){logs.push(Math.log(d/delta));if(d>1e-6&&first===null)first=i;}if(d>1e-6)divergence++;}
  let sum=0;for(const z of logs)sum+=z;const meanLog=logs.length?sum/logs.length:null;
  // Analytic derivative along the reference orbit: finite-time Lyapunov estimate.
  let lyap=0,lyapCount=0,zeroDerivative=false;for(let i=burn;i<steps;i++){const d=Math.abs(r*(1-2*a[i]));if(d===0){zeroDerivative=true;continue;}lyap+=Math.log(d);lyapCount++;}
  const lambda=lyapCount?lyap/lyapCount:null;
  const classification=lambda===null?'estimación no disponible':lambda>0.01?'sensibilidad lineal finita positiva':lambda< -0.01?'contracción lineal finita':'cerca de neutralidad en esta ventana';
  const out={version:VERSION,parameters:{x,r,delta,steps,burn},final:{reference:a[steps],perturbed:b[steps],distance:dist[steps].distance},finiteWindow:{meanLogDistanceGrowth:meanLog,lyapunovEstimate:lambda,lyapunovSamples:lyapCount,zeroDerivativeEncountered:zeroDerivative,firstDistanceAbove1eMinus6:first,stepsAbove1eMinus6:divergence},classification,tail:dist.slice(-Math.min(100,dist.length)),epistemicStatus:'Diagnóstico numérico de tiempo finito y órbita concreta. No prueba caos, sensibilidad universal ni comportamiento asintótico.'};
  const s=JSON.stringify({parameters:out.parameters,final:out.final,finiteWindow:out.finiteWindow});let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}out.fingerprint=(h>>>0).toString(16).padStart(8,'0');return out;
 }
 function sweep(o){o=o||{};const x=num(o.x===undefined?0.2:o.x,'x'),delta=num(o.delta===undefined?1e-8:o.delta,'delta'),steps=num(o.steps===undefined?1000:o.steps,'steps'),burn=num(o.burn===undefined?100:o.burn,'burn'),rs=o.rValues||[2.5,3,3.2,3.5,3.8,3.9,4];if(!Array.isArray(rs)||rs.length<1||rs.length>32)throw Error('rValues debe contener entre 1 y 32 valores.');const rows=rs.map(r=>{const z=analyze({x,r,delta,steps,burn});return {r:z.parameters.r,estimate:z.finiteWindow.lyapunovEstimate,classification:z.classification,finalDistance:z.final.distance,fingerprint:z.fingerprint};});return {version:VERSION,rows,epistemicStatus:'Barrido finito de parámetros; no es una clasificación rigurosa de caos.'};}
 global.OdiseoSensitivity=Object.freeze({version:VERSION,analyze,sweep});
})(window);
