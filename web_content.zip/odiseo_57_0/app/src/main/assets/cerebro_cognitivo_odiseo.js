/* ODISEO Cognitive Brain 1.0-alpha
 * Offline orchestration layer: interpret -> recall -> plan -> tools -> generate -> audit -> learn.
 * It does not claim consciousness, autonomous weight-training, or factual verification.
 */
(function (g) {
  'use strict';
  const VERSION = '1.0.0-alpha';
  const TRACE_KEY = 'odiseo_brain_traces_v1';
  const MAX_TRACE = 120;
  const STOP = new Set(['para','como','donde','cuando','porque','pero','desde','hasta','sobre','entre','esto','esta','este','son','ser','una','uno','las','los','del','que','con','por','sin','the','and','are','you']);
  const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const tokens = s => (norm(s).match(/[a-z0-9]{2,}/g) || []).filter(t => !STOP.has(t));
  const uniq = xs => [...new Set(xs)];
  function safeParse(raw, fallback) { try { const x=JSON.parse(raw); return Array.isArray(x)?x:fallback; } catch (_) { return fallback; } }
  function traces() { try { return safeParse(g.localStorage.getItem(TRACE_KEY), []); } catch (_) { return []; } }
  function saveTrace(t) { try { const all=traces(); all.push(t); g.localStorage.setItem(TRACE_KEY,JSON.stringify(all.slice(-MAX_TRACE))); return true; } catch (_) { return false; } }
  function classify(text) {
    const q=norm(text);
    if (/\b(codigo|programa|funcion|script|apk|compilar|depurar)\b/.test(q)) return 'engineering';
    if (/\b(calcula|cuanto|resolver|ecuacion|demuestra|matematic)\b/.test(q)) return 'analysis';
    if (/\b(hipotesis|experimento|datos|causalidad|azar|investiga)\b/.test(q)) return 'research';
    if (/\b(recuerda|memoria|antes|continuar|donde nos quedamos)\b/.test(q)) return 'continuity';
    if (/\b(audita|auditoria|comprueba|verifica|contrasta)\b/.test(q)) return 'verification';
    if (/\b(explica|que es|define|ensena)\b/.test(q)) return 'explanation';
    return 'general';
  }
  function retrieveMemory(query, limit) {
    const mem=g.OdiseoSemanticMemory;
    if (!mem || typeof mem.search!=='function') return [];
    try { return mem.search(query,limit||5).map(x=>({id:x.id,text:x.text,type:x.type,state:x.state,source:x.source,score:x.score})); }
    catch (_) { return []; }
  }
  function inventory() {
    const a=g.OdiseoLocalAssistant;
    try { return a && typeof a.status==='function' ? a.status().filter(x=>x.available).map(x=>x.name) : []; }
    catch (_) { return []; }
  }
  function chooseTools(goal, text) {
    const q=norm(text), found=[];
    const add=(name,reason,capability)=>found.push({name,reason,capability:capability||null,execution:'not-run'});
    if (goal==='analysis' || goal==='research' || /collatz|syracuse|numero|residuo|patron/.test(q)) add('Núcleo de razonamiento local','Estructurar afirmaciones, relaciones y posibles contraejemplos');
    if (goal==='verification' || /sherlock|rastros|relaciones|observaciones/.test(q)) add('Sherlock','Buscar candidatos y evidencias explícitas; no inferir causalidad','sherlock.investigate');
    if (/penelope|penélope|ast|simplifica|estructura/.test(q)) add('Penélope','Examinar un AST aportado explícitamente','penelope.unweave');
    if (/alternativa|bloqueado|reencuadra|judas/.test(q)) add('Judas Tadeo','Proponer marcos alternativos','judas.reframe');
    if (/espejo|puntos ciegos|preguntas abiertas/.test(q)) add('ESPEJO','Examinar el grafo local existente','espejo.questions');
    if (/audita el espejo|auditoria del espejo/.test(q)) { const x=found.find(t=>t.name==='ESPEJO'); if(x)x.capability='espejo.audit'; else add('ESPEJO','Auditar el grafo local existente','espejo.audit'); }
    if (/audita.*nucleo|auditoria.*nucleo/.test(q)) add('Núcleo unificado','Ejecutar auditoría local allowlisted','core.audit');
    if (/tic|informacion|entropia|transferencia/.test(q)) add('TIC','Revisar medidas informacionales y sus supuestos');
    if (/loteria|primitiva|euromillones|sorteo/.test(q)) add('Laboratorio de loterías','Análisis estadístico sin promesa predictiva');
    if (goal==='verification') add('Semáforo y auditor de comunicación','Comprobar límites y claridad de la respuesta');
    return found;
  }
  function plan(text) {
    const goal=classify(text), memories=retrieveMemory(text,5), tools=chooseTools(goal,text), loaded=inventory();
    const usable=tools.map(t=>({...t,available: t.name==='Núcleo de razonamiento local'?!!g.OdiseoReasoningCore:
      t.name==='Sherlock'?!!g.OdiseoSherlock:t.name==='Penélope'?!!g.OdiseoPenelope:
      t.name==='Judas Tadeo'?!!g.OdiseoJudasTadeo:t.name==='TIC'?!!g.OdiseoTIC:
      t.name==='Laboratorio de loterías'?!!g.OdiseoLotteryLab:true}));
    return {goal,memories,tools:usable,loadedEngines:loaded,steps:['interpretar objetivo','recuperar memoria local con procedencia','seleccionar herramientas permitidas','generar respuesta con modelo local','auditar afirmaciones y límites','registrar traza'],network:false};
  }
  function compactMemory(memories) {
    if (!memories.length) return 'No se recuperaron recuerdos pertinentes.';
    return memories.map((m,i)=>`${i+1}. ${m.text} [tipo=${m.type}; estado=${m.state}; fuente=${m.source}; id=${m.id}]`).join('\n');
  }
  function capabilityPayload(id, userText, p) {
    if (id==='sherlock.investigate') {
      // Only real retrieved memory records become traces; never fabricate evidence.
      if (p.memories.length<2) return {needsInput:true,reason:'Sherlock necesita al menos dos registros reales recuperados con procedencia.'};
      return {payload:{traces:p.memories.map(m=>({id:String(m.id),observation:String(m.text),source:String(m.source||'unknown'),kind:String(m.type||'memory')})),budget:Math.min(500,p.memories.length)}};
    }
    if (id==='penelope.unweave') {
      const m=String(userText).match(/(?:penelope|penélope)\s*:\s*(\{[\s\S]*\})/i);
      if (!m) return {needsInput:true,reason:'Falta un AST JSON explícito. No se genera uno artificialmente.'};
      try { const parsed=JSON.parse(m[1]); if(!parsed||!parsed.ast||typeof parsed.ast!=='object') return {needsInput:true,reason:'El JSON debe incluir ast como objeto.'}; return {payload:{ast:parsed.ast,sourceId:parsed.sourceId||'user-input'}}; }
      catch (_) { return {needsInput:true,reason:'El AST no es JSON válido.'}; }
    }
    if (id==='judas.reframe') return {payload:{domain:p.goal==='research'?'research':p.goal,block:'wrong_representation',premises:[],attempted:[],constraints:['Entrada original del usuario: '+String(userText).slice(0,1000),'No inventar datos ni declarar solución sin prueba']}};
    if (id==='espejo.questions' || id==='espejo.audit') {
      try { const api=g.OdiseoMirror; const raw=g.localStorage.getItem('odiseo_mirror_graph_501'); const graph=raw?JSON.parse(raw):(api&&typeof api.empty==='function'?api.empty():null); if(!graph)return {needsInput:true,reason:'No existe un grafo ESPEJO válido cargado.'}; return {payload:{graph,options:{limit:8}}}; }
      catch (_) { return {needsInput:true,reason:'El grafo local ESPEJO no se pudo leer.'}; }
    }
    if (id==='core.audit') return {payload:{}};
    return {needsInput:true,reason:'No hay constructor de entrada autorizado para esta capacidad.'};
  }
  function resultSummary(result) {
    try { return JSON.stringify(result).slice(0,1600); } catch (_) { return String(result).slice(0,1600); }
  }
  async function runSafeTools(userText, p) {
    const runs=[];
    for (const candidate of p.tools) {
      if (candidate.name==='Núcleo de razonamiento local') {
        if (!g.OdiseoReasoningCore || typeof g.OdiseoReasoningCore.analyze!=='function') { runs.push({name:candidate.name,status:'UNAVAILABLE',reason:candidate.reason}); continue; }
        try { const report=await g.OdiseoReasoningCore.analyze(userText); runs.push({name:candidate.name,status:'EXECUTED',method:'OdiseoReasoningCore.analyze',summary:report.conclusion&&report.conclusion.text,counts:report.counts,limitations:report.limitations,report}); }
        catch(e) { runs.push({name:candidate.name,status:'ERROR',error:String(e&&e.message||e)}); }
        continue;
      }
      if (candidate.capability) {
        const registry=g.OdiseoCapabilityRegistry;
        if (!registry || typeof registry.invoke!=='function') { runs.push({name:candidate.name,status:'UNAVAILABLE',capability:candidate.capability,reason:'Registro de capacidades no cargado.'}); continue; }
        const built=capabilityPayload(candidate.capability,userText,p);
        if (built.needsInput) { runs.push({name:candidate.name,status:'NEEDS_INPUT',capability:candidate.capability,reason:built.reason}); continue; }
        const started=Date.now();
        try { const result=await registry.invoke(candidate.capability,built.payload); runs.push({name:candidate.name,status:result.status,capability:candidate.capability,elapsedMs:Date.now()-started,summary:resultSummary(result.result||result),result}); }
        catch(e) { runs.push({name:candidate.name,status:'ERROR',capability:candidate.capability,error:String(e&&e.message||e)}); }
        continue;
      }
      runs.push({name:candidate.name,status:'NOT_INTEGRATED',reason:'La herramienta está detectada, pero aún no tiene contrato ejecutable en este ciclo.'});
    }
    return runs;
  }
  function buildPrompt(userText, p) {
    const toolLines=p.tools.length?p.tools.map(t=>`- ${t.name}: ${t.available?'módulo cargado':'módulo no disponible'}. ${t.reason}.`).join('\n'):'No se identificó una herramienta especializada pertinente.';
    const runLines=(p.toolRuns||[]).length?p.toolRuns.map(t=>`- ${t.name}: ${t.status}${t.summary?' — '+t.summary:''}${t.error?' — '+t.error:''}`).join('\n'):'No se ejecutó ninguna herramienta local.';
    return [
      'IDENTIDAD OPERATIVA: Eres el modelo lingüístico local integrado en Odiseo. No eres consciente ni afirmes emociones.',
      'REGLAS: responde en español; sé directo; distingue HECHOS, INFERENCIAS, HIPÓTESIS y DESCONOCIDOS cuando proceda; nunca inventes ejecuciones, archivos, fuentes, pruebas o recuerdos; una memoria recuperada no es necesariamente verdadera; una coincidencia no demuestra causalidad; si falta información, dilo y pregunta solo lo esencial.',
      'CICLO COGNITIVO ODISEO:',
      `Objetivo clasificado: ${p.goal}.`,
      'Plan: '+p.steps.join(' -> ')+'.',
      'Herramientas candidatas:\n'+toolLines,
      'EJECUCIONES LOCALES OBSERVADAS:\n'+runLines,
      'MEMORIA LOCAL RECUPERADA (contexto falible; conserva fuente y estado):\n'+compactMemory(p.memories),
      'MÓDULOS CARGADOS: '+(p.loadedEngines.join(', ')||'ninguno detectado')+'.',
      'Distingue herramientas candidatas de ejecuciones observadas. Solo las entradas EJECUTADAS con estado EXECUTED se han invocado; NEEDS_INPUT exige datos reales del usuario. AVAILABLE/NOT_INTEGRATED no significa ejecución.',
      'MENSAJE DEL USUARIO:\n'+userText
    ].join('\n\n');
  }
  function auditOutput(answer, planData) {
    const s=String(answer||''), flags=[];
    if (/he ejecutado|he comprobado|he verificado|he buscado en internet|he instalado|he compilado/i.test(s)) flags.push('Afirmación de acción: contrastar con una traza real antes de aceptarla.');
    if (/demuestra que|queda demostrado|es causal|causa definitivamente/i.test(s)) flags.push('Posible exceso de certeza: exigir prueba o diseño causal explícito.');
    if (/100% seguro|sin ninguna duda|garantizado/i.test(s)) flags.push('Lenguaje de certeza absoluta: revisar calibración.');
    if (planData.memories.length) flags.push('Se proporcionó memoria recuperada; su estado y procedencia deben conservarse.');
    return {status:flags.some(x=>x.startsWith('Posible exceso'))?'REVIEW_REQUIRED':'UNVERIFIED',flags,verified:false,checks:['no se ha contrastado con fuentes externas','no se ha demostrado la verdad factual','las herramientas candidatas no equivalen a herramientas ejecutadas']};
  }
  async function begin(userText, centralDecision) {
    const p=plan(userText);
    // The central director can add prioritized engines to this cycle.
    // Only known, allowlisted contracts are executable; other engines remain explicitly NOT_INTEGRATED.
    const routes = centralDecision && Array.isArray(centralDecision.selected) ? centralDecision.selected : [];
    const contractById = {
      reasoning:{name:'Núcleo de razonamiento local',reason:'Prioridad del director central; análisis simbólico local'},
      sherlock:{name:'Sherlock',reason:'Prioridad del director central; rastros con procedencia',capability:'sherlock.investigate'},
      penelope:{name:'Penélope',reason:'Prioridad del director central; requiere AST explícito',capability:'penelope.unweave'},
      judas:{name:'Judas Tadeo',reason:'Prioridad del director central; reencuadre alternativo',capability:'judas.reframe'},
      mirror:{name:'ESPEJO',reason:'Prioridad del director central; grafo local',capability:/audita|auditoria/i.test(userText)?'espejo.audit':'espejo.questions'},
      auditor:{name:'Auditor de comunicación',reason:'Prioridad del director central; revisión heurística'},
      evidence:{name:'Integrador de evidencias',reason:'Prioridad del director central; contrato ejecutable pendiente'},
      tic:{name:'TIC',reason:'Prioridad del director central; contrato ejecutable pendiente'},
      library:{name:'Biblioteca activa',reason:'Prioridad del director central; contrato ejecutable pendiente'},
      creative:{name:'Creador autónomo',reason:'Prioridad del director central; contrato ejecutable pendiente'},
      lottery:{name:'Laboratorio de loterías',reason:'Prioridad del director central; contrato ejecutable pendiente'},
      integrator:{name:'Integrador E',reason:'Prioridad del director central; contrato ejecutable pendiente'}
    };
    for (const route of routes) {
      const spec=contractById[route.id]; if(!spec) continue;
      if(!p.tools.some(t=>t.name===spec.name)) p.tools.push({...spec,available:!!route.available,execution:'not-run'});
    }
    p.centralDecision=centralDecision?{goal:centralDecision.goal,mode:centralDecision.mode,selected:routes.map(x=>x.id),unavailable:(centralDecision.unavailable||[]).map(x=>x.id)}:null;
    p.toolRuns=await runSafeTools(userText,p);
    return {version:VERSION,plan:p,prompt:buildPrompt(userText,p)};
  }
  function finish(userText, answer, planData) {
    const audit=auditOutput(answer,planData), trace={id:'brain_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),at:new Date().toISOString(),goal:planData.goal,toolCandidates:planData.tools.map(x=>x.name),memoryIds:planData.memories.map(x=>x.id),auditStatus:audit.status,verified:false,userText:String(userText).slice(0,1000),answer:String(answer).slice(0,2000)};
    trace.toolRuns=(planData.toolRuns||[]).map(t=>({name:t.name,capability:t.capability||null,status:t.status,elapsedMs:t.elapsedMs??null,summary:String(t.summary||t.reason||t.error||'').slice(0,500)})); trace.executionSummary={executed:trace.toolRuns.filter(x=>x.status==='EXECUTED').length,needsInput:trace.toolRuns.filter(x=>x.status==='NEEDS_INPUT').length,errors:trace.toolRuns.filter(x=>x.status==='ERROR').length}; const persisted=saveTrace(trace);
    return {version:VERSION,audit,traceId:trace.id,tracePersisted:persisted,disclaimer:'Respuesta generada por el modelo local. Auditoría heurística; no verificación factual automática.',text:String(answer)};
  }
  function status() { return {version:VERSION,network:false,remoteGPT:false,localModelReady:!!(g.OdiseoNative&&g.OdiseoNative.isLocalModelReady&&g.OdiseoNative.isLocalModelReady()),semanticMemory:!!g.OdiseoSemanticMemory,reasoningCore:!!g.OdiseoReasoningCore,loadedEngines:inventory(),traces:traces().length,capabilities:['planificación','recuperación BM25 con procedencia','selección de herramientas','preparación de contexto','auditoría heurística de salida','registro local de trazas'],limitations:['No es conciencia','No entrena los pesos del modelo','La memoria no se valida automáticamente','Auditoría no prueba verdad','Solo se ejecutan capacidades allowlisted con entradas válidas','Los contratos no prueban verdad semántica']}; }
  g.OdiseoCognitiveBrain=Object.freeze({version:VERSION,classify,plan,begin,finish,status,traces,clearTraces(){try{g.localStorage.removeItem(TRACE_KEY);return true;}catch(_){return false;}}});
})(typeof window!=='undefined'?window:globalThis);
