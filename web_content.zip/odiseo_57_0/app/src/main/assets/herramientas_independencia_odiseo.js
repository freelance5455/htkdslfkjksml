/* Odiseo 53.6-alpha — local tools and capability contracts.
 * No GPT, remote model, network, eval, dynamic imports or generated-code execution.
 * This is deterministic software, not a general language model.
 */
(function (g) {
  'use strict';
  const VERSION = '1.0.0-alpha';
  const STORE = 'odiseo_local_knowledge_v1';
  const STOP = new Set(('a al algo algunas algunos ante bajo cada como con contra cual cuando de del desde donde dos el ella ellas ellos en entre era es esa esas ese eso esos esta estaba estas este esto estos fue ha hacia hasta hay la las le les lo los mas me mi mis mucha mucho muy nada ni no nos o otra otras otro otros para pero por porque que quien se sin sobre su sus te tiene todo todos tras tu un una unas uno unos y ya').split(' '));
  const norm = value => String(value == null ? '' : value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  function tokenize(value) { return norm(value).match(/[a-z0-9_]+/g) || []; }
  function keywords(value) { return tokenize(value).filter(t => t.length > 1 && !STOP.has(t)); }
  function extractNumbers(value) { return (String(value == null ? '' : value).match(/-?\d+(?:[.,]\d+)?/g) || []).map(x => Number(x.replace(',', '.'))).filter(Number.isFinite); }
  function similarity(a, b) {
    const A = new Set(keywords(a)), B = new Set(keywords(b));
    if (!A.size && !B.size) return 1;
    let common = 0; for (const t of A) if (B.has(t)) common++;
    return common / (A.size + B.size - common || 1);
  }
  function sentences(value) { return String(value == null ? '' : value).replace(/\s+/g, ' ').split(/(?<=[.!?])\s+/).map(x => x.trim()).filter(Boolean); }
  function summarize(value, maxSentences) {
    const list = sentences(value), n = Math.max(1, Math.min(8, Number(maxSentences) || 3));
    if (list.length <= n) return list.join(' ');
    const scored = list.map((s, i) => ({s, i, score: keywords(s).length / Math.sqrt(i + 1)}));
    return scored.sort((a,b) => b.score-a.score).slice(0,n).sort((a,b)=>a.i-b.i).map(x=>x.s).join(' ');
  }
  function fingerprint(value) {
    // Huella no criptográfica: solo detección de cambios accidentales.
    const s = typeof value === 'string' ? value : JSON.stringify(value); let h = 2166136261;
    for (let i=0;i<s.length;i++) { h ^= s.charCodeAt(i); h = Math.imul(h,16777619); }
    return ('00000000'+(h>>>0).toString(16)).slice(-8);
  }
  function readStore() { try { const v = JSON.parse(g.localStorage.getItem(STORE)||'[]'); return Array.isArray(v)?v:[]; } catch (_) { return []; } }
  function remember(text, source) {
    const body=String(text||'').trim(), origin=String(source||'').trim();
    if (!body) throw new Error('El contenido no puede estar vacío');
    if (!origin) throw new Error('La procedencia es obligatoria');
    const records=readStore(), item={id:'k_'+Date.now().toString(36)+'_'+fingerprint(body),text:body,source:origin,createdAt:new Date().toISOString(),fingerprint:fingerprint(body)};
    records.push(item); g.localStorage.setItem(STORE,JSON.stringify(records.slice(-1000))); return item;
  }
  function recall(query, limit) {
    const q=String(query||'').trim(); if (!q) return [];
    const max=Math.max(1,Math.min(20,Number(limit)||5));
    return readStore().map(item=>({...item,score:similarity(q,item.text)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||String(b.createdAt).localeCompare(String(a.createdAt))).slice(0,max);
  }
  function clearKnowledge() { g.localStorage.removeItem(STORE); }

  const CONTRACTS = [
    {id:'sherlock.investigate',label:'Sherlock · rastrear relaciones',engine:'OdiseoSherlock',method:'investigate',input:'traces[] (mínimo 2), budget opcional',validate:x=>!!x&&Array.isArray(x.traces)&&x.traces.length>=2},
    {id:'penelope.unweave',label:'Penélope · desmontaje AST',engine:'OdiseoPenelope',method:'unweave',input:'ast (objeto JSON), sourceId opcional',validate:x=>!!x&&!!x.ast&&typeof x.ast==='object'},
    {id:'judas.reframe',label:'Judas Tadeo · reencuadre',engine:'OdiseoJudasTadeo',method:'reframe',input:'domain, block, premises[]',validate:x=>!!x&&typeof x.domain==='string'&&typeof x.block==='string'&&Array.isArray(x.premises)},
    {id:'espejo.questions',label:'ESPEJO · preguntas heurísticas',engine:'OdiseoMirror',method:'proposeQuestions',input:'graph, options opcionales',validate:x=>!!x&&!!x.graph&&typeof x.graph==='object'},
    {id:'espejo.audit',label:'ESPEJO · auditar grafo',engine:'OdiseoMirror',method:'auditSelf',input:'graph',validate:x=>!!x&&!!x.graph&&typeof x.graph==='object'},
    {id:'core.audit',label:'Núcleo unificado · auditoría smoke',engine:'OdiseoUnifiedCore',method:'run',input:'options opcionales',validate:x=>x==null||typeof x==='object'}
  ];
  function catalog() { return CONTRACTS.map(c=>({id:c.id,label:c.label,available:!!g[c.engine]&&typeof g[c.engine][c.method]==='function',engine:c.engine,method:c.method,input:c.input})); }
  async function invoke(id, payload) {
    const c=CONTRACTS.find(x=>x.id===id); if(!c) return {status:'UNKNOWN_CAPABILITY',id};
    if(!c.validate(payload)) return {status:'INVALID_INPUT',id,expected:c.input};
    const api=g[c.engine]; if(!api||typeof api[c.method]!=='function') return {status:'UNAVAILABLE',id,engine:c.engine};
    try {
      const args = id==='penelope.unweave' ? [payload.ast,String(payload.sourceId||'local-tool')] : id==='sherlock.investigate' ? [payload] : id==='judas.reframe' ? [payload] : id==='espejo.questions' ? [payload.graph,payload.options||{}] : id==='espejo.audit' ? [payload.graph] : [payload||{}];
      const result=await api[c.method](...args);
      return {status:'EXECUTED',id,engine:c.engine,method:c.method,result};
    } catch (e) { return {status:'ERROR',id,error:String(e&&e.message||e)}; }
  }
  g.OdiseoLocalTools=Object.freeze({version:VERSION,normalize:norm,tokenize,keywords,extractNumbers,similarity,sentences,summarize,fingerprint,remember,recall,clearKnowledge,knowledgeCount:()=>readStore().length});
  g.OdiseoCapabilityRegistry=Object.freeze({version:VERSION,catalog,invoke,describe:()=>({version:VERSION,network:false,remoteModel:false,execution:'allowlisted local functions only',contracts:catalog(),limitations:['Los contratos validan forma y disponibilidad, no verdad semántica.','Las llamadas se ejecutan en el mismo runtime; no son una sandbox contra código bloqueante.','Las huellas FNV son no criptográficas.']})});
})(typeof window!=='undefined'?window:globalThis);
