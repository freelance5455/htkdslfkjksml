/* ODISEO 51.8 — Judas Tadeo: diagnóstico deductivo y reencuadre.
 * No fabrica demostraciones. Separa premisas, consecuencias, hipótesis y límites.
 */
(function(g){'use strict';
 const VERSION='51.8-judas-tadeo';
 function reframe(input){
  const x=input||{},domain=String(x.domain||'general'),block=String(x.block||'sin_bloqueo');
  const premises=Array.isArray(x.premises)?x.premises.slice(0,30):[];
  const attempted=Array.isArray(x.attempted)?x.attempted.slice(0,30):[];
  const constraints=Array.isArray(x.constraints)?x.constraints.slice(0,30):[];
  const diagnosis={type:block,meaning:'Diagnóstico provisional; no equivale a demostrar imposibilidad.',evidenceRequired:[]};
  const known={
   insufficient_data:['Obtener más observaciones o reducir el alcance.','No convertir ausencia de evidencia en evidencia de ausencia.'],
   underdetermined:['Identificar qué restricciones faltan.','Caracterizar el conjunto de soluciones en vez de escoger una arbitrariamente.'],
   inconsistent:['Localizar el subconjunto mínimo de premisas incompatibles.','Retirar o revisar una premisa solo con autorización y justificación.'],
   wrong_representation:['Cambiar entre representaciones algebraica, combinatoria, geométrica, lógica o computacional.','Buscar invariantes y equivalencias que sobrevivan al cambio.'],
   computationally_hard:['Buscar cotas, simetrías, reducción, lemas o algoritmos aproximados.','No llamar imposible a lo que solo excede el presupuesto actual.'],
   no_solution_claim:['Exigir certificado de imposibilidad o prueba exhaustiva dentro de un dominio finito.','Separar “no encontrado” de “no existe”.'],
   axiom_relative:['Nombrar explícitamente el sistema axiomático y la formalización.','No afirmar independencia o indecidibilidad sin prueba metamatemática.'],
   shared_assumption:['Identificar premisas tácitas compartidas por los motores.','Repetir el análisis cambiando una sola premisa cada vez.'],
   no_block:['Examinar si la pregunta, el objetivo y las restricciones están definidos operacionalmente.']
  };
  const routes=known[block]||known.no_block;
  const lottery=domain==='lottery';
  const alternativeFrames=lottery?[
   {name:'Auditoría del mecanismo',question:'¿Los resultados observados son compatibles con el sorteo uniforme e independiente?',method:'Simular el mecanismo exacto y comparar estadísticas predefinidas.',requires:'Historial oficial, reglas por periodo y corrección por comparaciones múltiples.'},
   {name:'Predicción fuera de muestra',question:'¿Una regla fijada antes del sorteo mejora a la selección uniforme en sorteos no usados para diseñarla?',method:'Backtest cronológico walk-forward con regla congelada y control aleatorio.',requires:'Datos históricos suficientes, protocolo preregistrado y conjunto temporal reservado.'},
   {name:'Reparto del premio',question:'Si se acierta, ¿qué combinaciones podrían ser menos elegidas por otros jugadores?',method:'Modelar elecciones de jugadores y compartir premios, no frecuencias de bolas.',requires:'Datos reales de apuestas/combinaciones elegidas y estructura de premios.'},
   {name:'Valor esperado',question:'¿El valor esperado neto compensa el coste?',method:'Incluir probabilidades, bote, impuestos, premios compartidos y coste.',requires:'Bote y reglas oficiales vigentes.'}
  ]:[
   {name:'Cambiar la representación',question:'¿Existe una formulación equivalente con estructura más visible?',method:'Transformación reversible y conservación de invariantes.',requires:'Demostrar equivalencia entre formulaciones.'},
   {name:'Razonamiento hacia atrás',question:'¿Qué condiciones necesarias tendría que cumplir una solución?',method:'Derivar condiciones necesarias y buscar contraejemplos mínimos.',requires:'Premisas formalizadas y verificador independiente.'},
   {name:'Relajar y fortalecer',question:'¿Qué ocurre al retirar o añadir una condición?',method:'Resolver casos más débiles y más fuertes para acotar el problema.',requires:'Registrar exactamente qué condición cambia.'}
  ];
  return {version:VERSION,role:'D · Judas Tadeo',status:'REFRAME_PROPOSED',diagnosis,premises,attempted,constraints,routes,alternativeFrames,returnProtocol:{toOdiseo:'Convertir cada reencuadre en una hipótesis concreta y medible.',toPenelope:'Buscar contraejemplos y explicaciones alternativas.',toIntegrator:'Conservar premisas, cambios, procedencia y evidencia; no promover una idea a hecho sin verificación.'},epistemicRules:['Una vía nueva no es una solución demostrada.','Una ejecución finita no prueba una afirmación universal.','Separar “no encontrado” de “no existe”.','No se relajan restricciones esenciales sin declararlo.','Si no hay datos, el resultado es INSUFFICIENT_DATA, no una predicción.']};
 }
 g.OdiseoJudasTadeo=Object.freeze({version:VERSION,reframe});
})(typeof window!=='undefined'?window:globalThis);
