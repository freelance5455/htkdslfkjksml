/* ODISEO 53.0 — Auditor independiente de comunicación entre motores.
 * Observa intercambios explícitos; no evalúa la verdad semántica de sus contenidos.
 * Huellas FNV-1a 32-bit: detección accidental de cambios, NO firma criptográfica.
 */
(function(root){'use strict';
 const VERSION='53.0-communication-auditor-1.0';
 const MAX_EXCHANGES=10000, MAX_DEPTH=20, MAX_STRING=200000;
 const isObj=x=>x!==null&&typeof x==='object';
 function stable(value,depth){
  if(depth>MAX_DEPTH)throw Error('Payload exceeds maximum depth');
  if(value===null||typeof value!=='object')return JSON.stringify(value);
  if(Array.isArray(value))return '['+value.map(v=>stable(v,depth+1)).join(',')+']';
  return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+stable(value[k],depth+1)).join(',')+'}';
 }
 function hash(value){const s=typeof value==='string'?value:stable(value,0);if(s.length>MAX_STRING)throw Error('Payload exceeds maximum serialized size');let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}
 function clone(value){return value===undefined?undefined:JSON.parse(JSON.stringify(value))}
 function hasPath(obj,path){return String(path).split('.').every((part,i,all)=>{if(!isObj(obj)||!Object.prototype.hasOwnProperty.call(obj,part))return false;obj=obj[part];return true})}
 function issue(code,severity,exchangeId,message,details){return {code,severity,exchangeId,message,details:details||null}}
 function createTrace(correlationId,meta){return {version:VERSION,correlationId:String(correlationId||('trace-'+Date.now()+'-'+Math.random().toString(16).slice(2))),meta:clone(meta||{}),exchanges:[],nextSequence:1}}
 function recordExchange(trace,input){
  if(!trace||trace.version!==VERSION||!Array.isArray(trace.exchanges))throw Error('Invalid communication trace');
  if(trace.exchanges.length>=MAX_EXCHANGES)throw Error('Communication trace budget exceeded');
  const x=input||{},id=String(x.exchangeId||trace.correlationId+'-msg-'+trace.nextSequence);
  const rec={exchangeId:id,correlationId:String(x.correlationId||trace.correlationId),sequence:Number.isSafeInteger(x.sequence)?x.sequence:trace.nextSequence,timestamp:String(x.timestamp||new Date().toISOString()),
   from:String(x.from||'unknown'),to:String(x.to||'unknown'),operation:String(x.operation||'invoke'),status:String(x.status||'COMPLETED'),
   requestPayload:clone(x.requestPayload),receivedPayload:clone(x.receivedPayload===undefined?x.requestPayload:x.receivedPayload),
   responsePayload:clone(x.responsePayload),deliveredPayload:clone(x.deliveredPayload===undefined?x.responsePayload:x.deliveredPayload),
   expectedRequestFields:(x.expectedRequestFields||[]).slice(),expectedResponseFields:(x.expectedResponseFields||[]).slice(),
   requestFingerprint:x.requestFingerprint||hash(x.requestPayload===undefined?null:x.requestPayload),
   receivedFingerprint:x.receivedFingerprint||hash(x.receivedPayload===undefined?(x.requestPayload===undefined?null:x.requestPayload):x.receivedPayload),
   responseFingerprint:x.responseFingerprint||hash(x.responsePayload===undefined?null:x.responsePayload),
   deliveredFingerprint:x.deliveredFingerprint||hash(x.deliveredPayload===undefined?(x.responsePayload===undefined?null:x.responsePayload):x.deliveredPayload),
   error:x.error?String(x.error):null,observed:x.observed!==false};
  if(!Number.isSafeInteger(rec.sequence)||rec.sequence<1)throw Error('Invalid exchange sequence');
  trace.exchanges.push(rec);trace.nextSequence=Math.max(trace.nextSequence,rec.sequence+1);return rec;
 }
 function audit(trace){
  const issues=[],xs=trace&&Array.isArray(trace.exchanges)?trace.exchanges:[];
  if(!trace||trace.version!==VERSION)issues.push(issue('INVALID_TRACE','CRITICAL',null,'Trace missing or incompatible'));
  if(xs.length>MAX_EXCHANGES)issues.push(issue('TRACE_BUDGET_EXCEEDED','CRITICAL',null,'Trace exceeds configured budget'));
  const ids=new Set(),seq=new Set();let observed=0,failed=0;
  for(const x of xs){
   if(x.observed)observed++;
   if(ids.has(x.exchangeId))issues.push(issue('DUPLICATE_EXCHANGE_ID','HIGH',x.exchangeId,'Exchange identifier is duplicated'));
   ids.add(x.exchangeId);
   if(seq.has(x.sequence))issues.push(issue('DUPLICATE_SEQUENCE','HIGH',x.exchangeId,'Sequence number is duplicated'));seq.add(x.sequence);
   if(x.correlationId!==trace.correlationId)issues.push(issue('CORRELATION_MISMATCH','HIGH',x.exchangeId,'Correlation ID was not propagated'));
   if(x.requestFingerprint!==x.receivedFingerprint)issues.push(issue('REQUEST_DELIVERY_MISMATCH','HIGH',x.exchangeId,'Request payload changed between sender and receiver'));
   if(x.responseFingerprint!==x.deliveredFingerprint)issues.push(issue('RESPONSE_DELIVERY_MISMATCH','HIGH',x.exchangeId,'Response payload changed between producer and recipient'));
   if(x.status==='SENT_NO_RESPONSE'||x.status==='NO_RESPONSE'){failed++;issues.push(issue('MISSING_RESPONSE','HIGH',x.exchangeId,'Request has no recorded response'))}
   if(x.status==='ERROR'){failed++;issues.push(issue('ENGINE_ERROR','HIGH',x.exchangeId,'Engine invocation reported an error',{error:x.error}))}
   if(x.status!=='COMPLETED'&&x.status!=='SENT_NO_RESPONSE'&&x.status!=='NO_RESPONSE'&&x.status!=='ERROR')issues.push(issue('UNKNOWN_STATUS','MEDIUM',x.exchangeId,'Unknown exchange status',{status:x.status}));
   for(const p of x.expectedRequestFields||[])if(!hasPath(x.receivedPayload,p))issues.push(issue('REQUEST_FIELD_MISSING','HIGH',x.exchangeId,'Receiver did not receive a required request field',{field:p}));
   for(const p of x.expectedResponseFields||[])if(!hasPath(x.deliveredPayload,p))issues.push(issue('RESPONSE_FIELD_MISSING','HIGH',x.exchangeId,'Required response field was not delivered',{field:p}));
   try{
    if(hash(x.requestPayload===undefined?null:x.requestPayload)!==x.requestFingerprint)issues.push(issue('REQUEST_SNAPSHOT_TAMPERED','HIGH',x.exchangeId,'Stored request snapshot no longer matches its fingerprint'));
    if(hash(x.receivedPayload===undefined?null:x.receivedPayload)!==x.receivedFingerprint)issues.push(issue('RECEIVED_PAYLOAD_TAMPERED','HIGH',x.exchangeId,'Received payload no longer matches its fingerprint'));
    if(hash(x.responsePayload===undefined?null:x.responsePayload)!==x.responseFingerprint)issues.push(issue('RESPONSE_SNAPSHOT_TAMPERED','HIGH',x.exchangeId,'Stored response snapshot no longer matches its fingerprint'));
    if(hash(x.deliveredPayload===undefined?null:x.deliveredPayload)!==x.deliveredFingerprint)issues.push(issue('DELIVERED_PAYLOAD_TAMPERED','HIGH',x.exchangeId,'Delivered payload no longer matches its fingerprint'));
   }catch(e){issues.push(issue('FINGERPRINT_ERROR','MEDIUM',x.exchangeId,'Could not fingerprint exchange payload',{error:String(e.message||e)}))}
   if(x.status==='COMPLETED'&&x.responsePayload===undefined)issues.push(issue('COMPLETED_WITHOUT_RESPONSE','HIGH',x.exchangeId,'Exchange claims completion but has no response payload'));
  }
  for(let i=1;i<xs.length;i++)if(xs[i].sequence<=xs[i-1].sequence)issues.push(issue('NON_MONOTONIC_SEQUENCE','MEDIUM',xs[i].exchangeId,'Exchange sequence is not strictly increasing in recorded order'));
  const severity={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};issues.sort((a,b)=>severity[a.severity]-severity[b.severity]);
  const high=issues.filter(x=>x.severity==='HIGH'||x.severity==='CRITICAL').length;
  return {auditor:VERSION,status:issues.some(x=>x.severity==='CRITICAL'||x.severity==='HIGH')?'COMMUNICATION_FAILURES_FOUND':issues.length?'COMMUNICATION_WARNINGS':'COMMUNICATION_TRACE_CLEAN',summary:{exchangeCount:xs.length,observedExchanges:observed,failedExchanges:failed,issueCount:issues.length,highSeverityIssues:high},issues,limits:['Solo detecta lo que ha sido instrumentado y registrado.','La ausencia de un registro no demuestra por sí sola que un mensaje no existiera.','Las huellas FNV-1a de 32 bits detectan cambios accidentales; no son criptográficas ni prueban autenticidad.','La validación de campos es estructural, no semántica.','Una comunicación correcta no demuestra que el contenido sea verdadero ni que los motores sean independientes.']};
 }
 function invoke(trace,from,to,operation,request,fn,contract){
  const c=contract||{},id=trace.correlationId+'-msg-'+trace.nextSequence;
  try{
   const response=fn(request);
   recordExchange(trace,{exchangeId:id,from,to,operation,requestPayload:request,receivedPayload:request,responsePayload:response,deliveredPayload:response,expectedRequestFields:c.request||[],expectedResponseFields:c.response||[],status:'COMPLETED'});
   return response;
  }catch(error){
   recordExchange(trace,{exchangeId:id,from,to,operation,requestPayload:request,receivedPayload:request,expectedRequestFields:c.request||[],expectedResponseFields:c.response||[],status:'ERROR',error:error&&error.message||error});
   const err=error instanceof Error?error:new Error(String(error));
   try{err.odiseoCommunication={trace,audit:audit(trace)};}catch(_){}
   throw err;
  }
 }
 root.OdiseoCommunicationAuditor=Object.freeze({version:VERSION,createTrace,recordExchange,audit,invoke,hash,limits:{maxExchanges:MAX_EXCHANGES}});
})(typeof window!=='undefined'?window:globalThis);
