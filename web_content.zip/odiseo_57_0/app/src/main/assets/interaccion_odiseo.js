/* ODISEO 50.5 — Motor de Interacción Finita.
 * Dos conjuntos iniciales finitos interactúan; cada ronda añade resultados nuevos.
 * El proceso puede crecer sin cota conocida, pero toda ejecución concreta es finita y presupuestada.
 * Incluye ciclo pregunta -> respuesta calculada -> nueva pregunta. No afirma infinito actual ni aprendizaje autónomo.
 */
(function(global){'use strict';
 const VERSION='1.0.0-interaccion-finita';
 const MAX_SEEDS=12,MAX_ROUNDS=8,MAX_VALUES=100,MAX_PAIRS=5000,MAX_BITS=256,MAX_HISTORY=100;
 function intText(v,label){const s=String(v).trim();if(!/^-?\d+$/.test(s))throw Error(label+' debe contener enteros separados por comas.');const n=BigInt(s);if(n.toString(2).replace('-','').length>MAX_BITS)throw Error(label+' supera '+MAX_BITS+' bits.');return n;}
 function parseSet(text,label){if(typeof text!=='string'||!text.trim())throw Error('El conjunto '+label+' no puede estar vacío.');const parts=text.split(',').map(x=>x.trim()).filter(Boolean);if(!parts.length||parts.length>MAX_SEEDS)throw Error(label+' admite entre 1 y '+MAX_SEEDS+' valores.');return [...new Set(parts.map(x=>intText(x,label).toString()))];}
 function gcd(a,b){a=a<0n?-a:a;b=b<0n?-b:b;while(b){const t=a%b;a=b;b=t;}return a;}
 function bits(n){return (n<0n?-n:n).toString(2).length;}
 function validateHistory(h){if(!Array.isArray(h))throw Error('Historial de interacción inválido.');return h.slice(-MAX_HISTORY).map(x=>{if(!x||typeof x.id!=='string'||!Array.isArray(x.rounds)||typeof x.fingerprint!=='string')throw Error('Registro de interacción corrupto.');return x;});}
 function run(aText,bText,options){const A0=parseSet(aText,'A'),B0=parseSet(bText,'B'),o=options||{};const roundLimit=Number(o.rounds===undefined?4:o.rounds),valueLimit=Number(o.maxValues===undefined?50:o.maxValues),pairLimit=Number(o.maxPairs===undefined?2000:o.maxPairs);
  if(!Number.isInteger(roundLimit)||roundLimit<1||roundLimit>MAX_ROUNDS)throw Error('Rondas debe estar entre 1 y '+MAX_ROUNDS+'.');
  if(!Number.isInteger(valueLimit)||valueLimit<2||valueLimit>MAX_VALUES)throw Error('El límite de valores debe estar entre 2 y '+MAX_VALUES+'.');
  if(!Number.isInteger(pairLimit)||pairLimit<1||pairLimit>MAX_PAIRS)throw Error('El límite de parejas debe estar entre 1 y '+MAX_PAIRS+'.');
  let A=new Set(A0),B=new Set(B0),known=new Set([...A,...B]),rounds=[],events=[],totalPairs=0,stopReason='ROUND_LIMIT',truncated=false;
  if(known.size>valueLimit)throw Error('Los valores iniciales superan el límite total de valores.');
  for(let r=1;r<=roundLimit;r++){
   const left=[...A],right=[...B],newA=[],newB=[],seenA=new Set(A),seenB=new Set(B);let pairs=0,created=0,roundEvents=0;
   outer:for(const as of left){for(const bs of right){if(totalPairs>=pairLimit){truncated=true;stopReason='PAIR_BUDGET_REACHED';break outer;}totalPairs++;pairs++;const a=BigInt(as),b=BigInt(bs),d=a-b,abs=d<0n?-d:d,g=gcd(a,b),l=g===0n?0n:(a/g)*b<0n?-(a/g)*b:(a/g)*b;
     const ops=[['suma',a+b,'A'],['producto',a*b,'A'],['diferencia_absoluta',abs,'B'],['MCD',g,'B'],['MCM',l,'B']];
     for(const [op,val,target] of ops){if(bits(val)>MAX_BITS)continue;const s=val.toString(),set=target==='A'?seenA:seenB;if(!set.has(s)&&!known.has(s)){if(known.size>=valueLimit){truncated=true;stopReason='VALUE_BUDGET_REACHED';break outer;}set.add(s);known.add(s);(target==='A'?newA:newB).push(s);created++;}
      if(events.length<200){const q='¿Qué relación conecta '+a.toString()+' y '+b.toString()+' mediante '+op+'?';const answer=a.toString()+' '+(op==='suma'?'+':op==='producto'?'×':op==='diferencia_absoluta'?'− (valor absoluto)':op==='MCD'?'MCD':'MCM')+' '+b.toString()+' = '+s;events.push({round:r,a:as,b:bs,operation:op,result:s,question:q,answer,nextQuestion:'¿Qué ocurre si el resultado '+s+' vuelve a interactuar con los conjuntos A y B?'});roundEvents++;}
     }
    }}
   for(const x of newA)A.add(x);for(const x of newB)B.add(x);
   rounds.push({round:r,aBefore:left.length,bBefore:right.length,pairs,newA,newB,newValues:created,totalA:A.size,totalB:B.size,totalUnique:known.size,questionAnswerCycles:roundEvents});
   if(truncated)break;if(created===0){stopReason='FIXED_POINT_IN_TESTED_DOMAIN';break;}
  }
  const growth=rounds.length>0&&rounds[rounds.length-1].newValues>0;
  const result={engine:'ODISEO · INTERACCIÓN FINITA',version:VERSION,initial:{A:A0,B:B0},final:{A:[...A],B:[...B],uniqueValues:known.size},rounds,totalPairs,events,stopReason,truncated,potentiallyUnbounded:stopReason==='ROUND_LIMIT'&&growth,interpretation:stopReason==='FIXED_POINT_IN_TESTED_DOMAIN'?'Se alcanzó un punto fijo dentro de las operaciones y valores examinados.':stopReason==='ROUND_LIMIT'?'Hubo crecimiento hasta el límite de rondas; esto sugiere expansión, pero no demuestra infinitud.':'La ejecución se detuvo por presupuesto; no permite concluir infinitud.',principle:'A y B empiezan finitos. Su interacción produce resultados que pueden volver a entrar en A y B. Cada ronda es finita; la clausura total podría ser finita o no, según las semillas y operaciones.',epistemicStatus:'RESULTADO COMPUTACIONAL ACOTADO. No se afirma que una suma de dos números finitos sea infinita ni que el proceso completo sea infinito.',limits:{maxSeeds:MAX_SEEDS,maxRounds:MAX_ROUNDS,maxValues:MAX_VALUES,maxPairs:MAX_PAIRS,maxBits:MAX_BITS,maxStoredEvents:200}};
  let h=2166136261;const raw=JSON.stringify({initial:result.initial,rounds:result.rounds,stopReason});for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619);}result.fingerprint=(h>>>0).toString(16).padStart(8,'0');return result;
 }
 global.OdiseoInteraction=Object.freeze({version:VERSION,run,validateHistory,describe:()=>({version:VERSION,process:'A finito × B finito → resultados → reinserción → nueva ronda',claim:'El proceso iterado puede crecer; el infinito no se demuestra con una ejecución finita.'})});
})(window);
