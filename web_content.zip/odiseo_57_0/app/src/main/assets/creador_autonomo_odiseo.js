/* ODISEO 51.2 — Núcleo creador autónomo local con realimentación preferente de Penélope.
 * Independiente de los motores de investigación, red, APIs y modelos externos.
 * Genera y selecciona estructuras simbólicas con una gramática interna,
 * mide novedad estructural frente al archivo y conserva su procedencia.
 * Autonomía operativa acotada; no implica semántica general ni conciencia.
 */
(function(global){'use strict';
 const VERSION='1.1.0-nucleo-creador', MAX_STEPS=100, MAX_ARCHIVE=500, BATCH=8, MAX_DEPTH=12, MAX_NODES=127;
 const PRIMITIVES=['x','y','z','Δ','Ω','0','1','2'];
 const OPS=[
  {id:'sum',symbol:'+',arity:2},{id:'difference',symbol:'−',arity:2},
  {id:'product',symbol:'×',arity:2},{id:'compose',symbol:'∘',arity:2},
  {id:'feedback',symbol:'↻',arity:1},{id:'mirror',symbol:'↔',arity:1},
  {id:'iterate',symbol:'^*',arity:1},{id:'pair',symbol:'⟨·,·⟩',arity:2}
 ];
 function fail(m){throw new Error(m);}
 function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
 function rng(seed){let x=(seed>>>0)||0x0D15E0;return function(){x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
 function primitive(name){return {type:'primitive',name};}
 function unary(op,a){return {type:'unary',op,a};}
 function binary(op,a,b){return {type:'binary',op,a,b};}
 function render(n){if(n.type==='primitive')return n.name;if(n.type==='unary'){const o=OPS.find(x=>x.id===n.op);return o.symbol+'('+render(n.a)+')';}const o=OPS.find(x=>x.id===n.op);return '('+render(n.a)+' '+o.symbol+' '+render(n.b)+')';}
 function inspect(n){if(!n||typeof n!=='object')return {ok:false,nodes:0,depth:0,ops:[],primitives:[]};if(n.type==='primitive')return {ok:PRIMITIVES.includes(n.name),nodes:1,depth:1,ops:[],primitives:[n.name]};if(n.type==='unary'){const a=inspect(n.a),valid=OPS.some(o=>o.id===n.op&&o.arity===1);return {ok:a.ok&&valid,nodes:1+a.nodes,depth:1+a.depth,ops:a.ops.concat(n.op),primitives:a.primitives};}if(n.type==='binary'){const a=inspect(n.a),b=inspect(n.b),valid=OPS.some(o=>o.id===n.op&&o.arity===2);return {ok:a.ok&&b.ok&&valid,nodes:1+a.nodes+b.nodes,depth:1+Math.max(a.depth,b.depth),ops:a.ops.concat(b.ops,n.op),primitives:a.primitives.concat(b.primitives)};}return {ok:false,nodes:0,depth:0,ops:[],primitives:[]};}
 function featureVector(ast){const q=inspect(ast);if(!q.ok)fail('No se puede medir una estructura inválida.');const v=[];for(const p of PRIMITIVES)v.push(q.primitives.filter(x=>x===p).length/q.nodes);for(const op of OPS)v.push(q.ops.filter(x=>x===op.id).length/Math.max(1,q.nodes-1));v.push(Math.min(1,q.depth/MAX_DEPTH));v.push(Math.log2(q.nodes+1)/Math.log2(MAX_NODES+1));return v;}
 function structuralDistance(a,b){const x=featureVector(a),y=featureVector(b);let d=0;for(let i=0;i<x.length;i++)d+=Math.abs(x[i]-y[i]);return d/x.length;}
 function noveltyAgainst(ast,archive){if(!archive.length)return 1;let nearest=Infinity;for(const item of archive){const d=structuralDistance(ast,item.ast);if(d<nearest)nearest=d;}return Number(nearest.toFixed(6));}
 function stateFingerprint(s){return hash(JSON.stringify({seed:s.seed,generation:s.generation,cursor:s.cursor,archive:s.archive.map(x=>x.expression)}));}
 function initial(seed){const s=Number(seed===undefined?0x0D15E0:seed);if(!Number.isSafeInteger(s)||s<0||s>0xffffffff)fail('La semilla debe ser un entero entre 0 y 2^32−1.');const archive=PRIMITIVES.map((p,i)=>{const ast=primitive(p);return {id:'seed_'+i,kind:'primitive',expression:p,ast,parents:[],operation:'origin',generation:0,complexity:1,novelty:0,verified:true};});const state={version:VERSION,seed:s,generation:0,cursor:0,archive,created:0,rejected:0,history:[],goal:'Ampliar diversidad estructural manteniendo gramática válida, procedencia y límites.',fingerprint:''};state.fingerprint=stateFingerprint(state);return state;}
 function validateState(state){if(!state||state.version!==VERSION||!Array.isArray(state.archive)||state.archive.length<PRIMITIVES.length||state.archive.length>MAX_ARCHIVE)fail('Estado creador inválido.');for(const a of state.archive){const q=inspect(a.ast);if(!q.ok||render(a.ast)!==a.expression)fail('Archivo creador corrupto: '+a.id);}if(!Number.isSafeInteger(state.generation)||state.generation<0||!Number.isSafeInteger(state.cursor)||state.cursor<0)fail('Generación o cursor inválido.');if(state.fingerprint!==stateFingerprint(state))fail('La huella del archivo creador no coincide.');return state;}
 function selectParent(archive,random){const pool=archive.slice().sort((a,b)=>(b.novelty||0)-(a.novelty||0)||b.complexity-a.complexity).slice(0,Math.min(32,archive.length));const feedback=archive.filter(x=>x.kind==='penelope-return').slice(-8);if(feedback.length&&random()<0.5)return feedback[Math.floor(random()*feedback.length)];return pool[Math.floor(random()*pool.length)];}
 function create(state,options){validateState(state);const o=options||{},steps=Number(o.steps===undefined?1:o.steps);if(!Number.isSafeInteger(steps)||steps<1||steps>MAX_STEPS)fail('Los ciclos deben estar entre 1 y '+MAX_STEPS+'.');const next=JSON.parse(JSON.stringify(state)),random=rng((next.seed+next.cursor+next.generation*2654435761)>>>0),newItems=[],seen=new Set(next.archive.map(x=>x.expression));let attempted=0;
  for(let cycle=0;cycle<steps;cycle++){
   const before=next.archive.length;for(let j=0;j<BATCH;j++){
    if(next.archive.length>=MAX_ARCHIVE)break;attempted++;const left=selectParent(next.archive,random),op=OPS[Math.floor(random()*OPS.length)];let ast,parents;
    if(op.arity===1){ast=unary(op.id,left.ast);parents=[left.id];}else{const right=selectParent(next.archive,random);ast=binary(op.id,left.ast,right.ast);parents=[left.id,right.id];}
    const check=inspect(ast),expression=render(ast);if(!check.ok||check.depth>MAX_DEPTH||check.nodes>MAX_NODES){next.rejected++;continue;}if(seen.has(expression)){next.rejected++;continue;}
    const complexity=check.nodes+check.depth*2,novelty=noveltyAgainst(ast,next.archive);
    const item={id:'creation_'+(next.created+1),kind:'symbolic-structure',expression,ast,parents,operation:op.id,generation:next.generation+cycle+1,complexity,novelty,verified:true,verification:'AST válido; expresión reproducible; novedad calculada por distancia de rasgos estructurales respecto al archivo previo.'};seen.add(expression);next.archive.push(item);newItems.push(item);next.created++;
   }
   next.generation++;if(next.archive.length===before)break;
  }
  if(next.archive.length>MAX_ARCHIVE)next.archive=next.archive.slice(-MAX_ARCHIVE);
  const frontier=newItems.slice().sort((a,b)=>b.novelty-a.novelty||b.complexity-a.complexity).slice(0,12);
  const questions=frontier.slice(0,5).map(a=>({creationId:a.id,question:'¿Qué estructura distinta puede derivarse de '+a.expression+'?',basis:'Derivada de una creación local '+a.id+'; pregunta generativa, no afirmación semántica.'}));
  const summary={version:VERSION,cycles:next.generation-state.generation,attempted,created:newItems.length,rejected:next.rejected-state.rejected,totalArchive:next.archive.length,frontier,questions,selection:'Padres elegidos desde la frontera de mayor novedad estructural local.',stopReason:next.archive.length>=MAX_ARCHIVE?'ARCHIVE_LIMIT':'BUDGET_OR_GENERATION_COMPLETE'};
  next.cursor+=attempted;next.history=(next.history||[]).concat([{generation:next.generation,created:newItems.length,attempted,fingerprint:hash(newItems.map(x=>x.expression).join('|'))}]).slice(-100);next.fingerprint=stateFingerprint(next);
  return {state:next,summary,created:newItems};
 }
 function exportState(state){validateState(state);return JSON.stringify(state);}
 function importState(raw){let s;try{s=typeof raw==='string'?JSON.parse(raw):raw;}catch(e){fail('No se pudo leer el estado creador.');}return validateState(s);}
 global.OdiseoCreator=Object.freeze({version:VERSION,initial,create,validateState,exportState,importState,render,inspect,featureVector,structuralDistance,noveltyAgainst,selectParent,limits:{maxSteps:MAX_STEPS,maxArchive:MAX_ARCHIVE,batch:BATCH,maxDepth:MAX_DEPTH,maxNodes:MAX_NODES},independent:true,dependencies:[],feedbackSelection:'Hasta un 50% de las selecciones de padres puede proceder de las últimas ocho devoluciones de Penélope.'});
})(window);
