/* ODISEO 51.4 — Acoplamiento recíproco Odiseo/Penélope.
 * Odiseo crea; Penélope desmonta de forma reversible; sus resultados vuelven
 * al archivo creador y pasan a ser padres preferentes en ciclos posteriores.
 * Ejecución local, finita, reproducible y auditable.
 */
(function(global){'use strict';
 const VERSION='1.0.0-duelo-reciproco',MAX_ROUNDS=50,MAX_HISTORY=200;
 function fail(m){throw new Error(m)}
 function clone(x){return JSON.parse(JSON.stringify(x))}
 function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}
 function creatorFingerprint(s){return hash(JSON.stringify({seed:s.seed,generation:s.generation,cursor:s.cursor,archive:s.archive.map(x=>x.expression)}))}
 function sealCreator(s){s.fingerprint=creatorFingerprint(s);return s}
 function fingerprint(s){return hash(JSON.stringify({version:s.version,creator:s.creatorState.fingerprint,growth:s.growthState.fingerprint,history:s.history,rounds:s.rounds}))}
 function initial(Creator,Growth,options){if(!Creator||!Growth)fail('Faltan los motores creadores o de crecimiento.');const o=options||{};const s={version:VERSION,creatorState:o.creatorState?Creator.validateState(clone(o.creatorState)):Creator.initial(o.seed),growthState:o.growthState?Growth.validate(clone(o.growthState)):Growth.initial(o.growth||{}),history:[],rounds:0,fingerprint:''};s.fingerprint=fingerprint(s);return s}
 function validate(s,Creator,Growth){if(!s||s.version!==VERSION||!s.creatorState||!s.growthState||!Array.isArray(s.history)||s.history.length>MAX_HISTORY||!Number.isSafeInteger(s.rounds)||s.rounds<0)fail('Estado del duelo inválido.');Creator.validateState(s.creatorState);Growth.validate(s.growthState);if(s.fingerprint!==fingerprint(s))fail('Huella del duelo alterada.');return s}
 function addReturn(creatorState,proposal,source,Creator){
  const expr=proposal.candidateExpression,seen=creatorState.archive.some(x=>x.expression===expr);
  if(seen||creatorState.archive.length>=Creator.limits.maxArchive)return {state:creatorState,inserted:false,reason:seen?'ALREADY_IN_ARCHIVE':'ARCHIVE_LIMIT'};
  const q=Creator.inspect(proposal.candidateAst);if(!q.ok||Creator.render(proposal.candidateAst)!==expr)fail('La devolución de Penélope no supera la gramática creadora.');
  const novelty=Creator.noveltyAgainst(proposal.candidateAst,creatorState.archive);
  const id='penelope_return_'+hash(proposal.id+'|'+source.id+'|'+expr);
  const item={id,kind:'penelope-return',expression:expr,ast:clone(proposal.candidateAst),parents:[source.id],operation:'penelope-unweave',generation:creatorState.generation,complexity:q.nodes+q.depth*2,novelty,verified:true,verification:'AST válido; propuesta reversible de Penélope; procedencia y huella conservadas.',sourceProposal:proposal.id};
  creatorState.archive.push(item);
  const seedText=creatorState.seed+'|'+proposal.fingerprint+'|'+expr;
  creatorState.seed=parseInt(hash(seedText),16)>>>0;
  creatorState.cursor++;
  sealCreator(creatorState);
  Creator.validateState(creatorState);
  return {state:creatorState,inserted:true,item};
 }
 function run(state,Creator,Penelope,Growth,options){
  validate(state,Creator,Growth);const o=options||{},rounds=Number(o.rounds===undefined?1:o.rounds);
  if(!Number.isSafeInteger(rounds)||rounds<1||rounds>MAX_ROUNDS)fail('Las rondas deben estar entre 1 y '+MAX_ROUNDS+'.');
  let creatorState=clone(state.creatorState),growthState=clone(state.growthState),history=clone(state.history),all=[];
  const communicationTrace=o.communicationTrace||null,communication=communicationTrace?global.OdiseoCommunicationAuditor:null;
  if(communicationTrace&&!communication)fail('Se proporcionó una traza, pero falta el Auditor de Comunicación.');
  function exchange(from,to,operation,request,fn,contract){return communication?communication.invoke(communicationTrace,from,to,operation,request,fn,contract):fn(request);}
  for(let r=0;r<rounds;r++){
   const created=Creator.create(creatorState,{steps:1});creatorState=created.state;
   const round={round:state.rounds+r+1,created:[],oppositions:[],returns:[],feedbackParents:[]};
   for(const item of created.created){
    let creationAwarded=false;if(item.novelty>0){const cAward=Growth.awardCreation(growthState,item,Creator);growthState=cAward.state;creationAwarded=true;}
    const dismantled=exchange('Odiseo','Penelope','unweave',{ast:item.ast,sourceId:item.id},req=>Penelope.unweave(req.ast,req.sourceId),{request:['ast','sourceId'],response:['proposals','examined']});
    if(!dismantled.proposals.length){round.created.push({id:item.id,expression:item.expression,parents:item.parents,creationProgressAwarded:creationAwarded,opposition:'NO_SIMPLIFICATION'});continue;}
    const candidates=dismantled.proposals.map(p=>({proposal:p,novelty:Creator.noveltyAgainst(p.candidateAst,creatorState.archive),exists:creatorState.archive.some(x=>x.expression===p.candidateExpression)})).sort((a,b)=>Number(a.exists)-Number(b.exists)||b.novelty-a.novelty||b.proposal.removedNodes-a.proposal.removedNodes);
    const chosen=candidates[0].proposal;
    const pAward=Growth.awardUnweaving(growthState,chosen,Penelope);growthState=pAward.state;
    const returned=exchange('Penelope','Odiseo','return-proposal',{proposal:chosen,source:item},req=>addReturn(creatorState,req.proposal,req.source,Creator),{request:['proposal','source'],response:['state','inserted']});creatorState=returned.state;
    const opposition={source:item.id,original:item.expression,candidate:chosen.candidateExpression,proposalId:chosen.id,removedNodes:chosen.removedNodes,originalNodes:chosen.originalNodes,progress:chosen.removedNodes/chosen.originalNodes,reversible:chosen.reversible,verified:chosen.verified,insertedIntoCreatorArchive:returned.inserted,returnId:returned.item?returned.item.id:null,returnReason:returned.reason||null,feedback:'Penélope devuelve una estructura al archivo de Odiseo; las devoluciones son elegibles como padres preferentes en la siguiente creación.'};
    round.created.push({id:item.id,expression:item.expression,parents:item.parents,creationProgressAwarded:creationAwarded,opposition:'ANALYZED'});
    round.oppositions.push(opposition);if(returned.inserted)round.returns.push(returned.item.id);
   }
   round.feedbackParents=creatorState.archive.filter(x=>x.kind==='penelope-return').slice(-8).map(x=>x.id);
   round.summary={created:created.created.length,opposed:round.oppositions.length,returned:round.returns.length,archiveSize:creatorState.archive.length,creatorCapacity:Growth.display(growthState.motors.odiseo.logCapacity),penelopeCapacity:Growth.display(growthState.motors.penelope.logCapacity)};
   history.push(round);history=history.slice(-MAX_HISTORY);all.push(round);
   if(created.created.length===0)break;
  }
  const next={version:VERSION,creatorState,growthState,history,rounds:state.rounds+all.length,fingerprint:''};next.fingerprint=fingerprint(next);validate(next,Creator,Growth);
  return {state:next,rounds:all,communication:communication?{trace:communicationTrace,audit:communication.audit(communicationTrace)}:null,summary:{rounds:all.length,created:all.reduce((n,x)=>n+x.summary.created,0),opposed:all.reduce((n,x)=>n+x.summary.opposed,0),returned:all.reduce((n,x)=>n+x.summary.returned,0),archiveSize:creatorState.archive.length,feedbackAvailable:creatorState.archive.filter(x=>x.kind==='penelope-return').length,creatorCapacity:Growth.display(growthState.motors.odiseo.logCapacity),penelopeCapacity:Growth.display(growthState.motors.penelope.logCapacity),stopReason:creatorState.archive.length>=Creator.limits.maxArchive?'ARCHIVE_LIMIT':'ROUND_BUDGET'},epistemicLimit:'La influencia es estructural y reproducible: las simplificaciones de Penélope se insertan como posibles padres de Odiseo. No demuestra equivalencia semántica, verdad ni inteligencia general.'};
 }
 function rebase(state,Creator,Penelope,Growth,creatorState,growthState){validate(state,Creator,Growth);const next=clone(state);next.creatorState=Creator.validateState(clone(creatorState));next.growthState=Growth.validate(clone(growthState));next.fingerprint=fingerprint(next);return validate(next,Creator,Growth)}
 function exportState(s,C,P,G){validate(s,C,G);return JSON.stringify(s)}
 function importState(raw,C,P,G){let s;try{s=typeof raw==='string'?JSON.parse(raw):raw}catch(e){fail('No se pudo leer el estado del duelo.')}return validate(s,C,G)}
 global.OdiseoDuet=Object.freeze({version:VERSION,initial,validate,run,rebase,exportState,importState,limits:{maxRounds:MAX_ROUNDS,maxHistory:MAX_HISTORY},feedback:'Penelope-return structures are injected into the creator archive and selected preferentially in later parent selection.'});
})(window);
