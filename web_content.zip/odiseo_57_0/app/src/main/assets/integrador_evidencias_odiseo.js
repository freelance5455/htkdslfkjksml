/* ODISEO 52.4 — Integrador de Evidencias (OIE)
 * Integración por procedencia, afirmaciones y contradicciones; no por votación.
 * Motor determinista y local. No infiere causalidad ni verifica fuentes externas.
 */
(function(g){'use strict';
 const VERSION='52.4-oie-1.0';
 const clean=x=>String(x==null?'':x).trim();
 const uniq=a=>Array.from(new Set(a));
 function canonical(x){if(Array.isArray(x))return '['+x.map(canonical).join(',')+']';if(x&&typeof x==='object')return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';return JSON.stringify(x)}
 function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return ('00000000'+(h>>>0).toString(16)).slice(-8)}
 function ingest(input){
  const x=input||{}, raw=Array.isArray(x.records)?x.records:[], ids=new Set(), records=[], rejected=[];
  if(raw.length>5000)throw Error('Límite de 5000 registros superado.');
  raw.forEach((r,i)=>{r=r||{};const id=clean(r.id)||'record-'+(i+1),source=clean(r.source),statement=clean(r.statement),kind=clean(r.kind)||'observation';
   if(ids.has(id)){rejected.push({id,reason:'DUPLICATE_ID'});return} ids.add(id);
   if(!source||!statement){rejected.push({id,reason:'SOURCE_OR_STATEMENT_MISSING'});return}
   records.push({id,source,sourceFamily:clean(r.sourceFamily)||source,statement,kind, supports:uniq((Array.isArray(r.supports)?r.supports:[]).map(clean).filter(Boolean)), contradicts:uniq((Array.isArray(r.contradicts)?r.contradicts:[]).map(clean).filter(Boolean)), timestamp:clean(r.timestamp)||null, original: r.original===undefined?null:r.original});
  });
  const known=new Set(records.map(r=>r.id)), edges=[],dangling=[];
  for(const r of records){for(const id of r.supports) (known.has(id)?edges:dangling).push(known.has(id)?{from:r.id,to:id,type:'supports'}:{from:r.id,to:id,type:'supports',reason:'UNRESOLVED_REFERENCE'});for(const id of r.contradicts)(known.has(id)?edges:dangling).push(known.has(id)?{from:r.id,to:id,type:'contradicts'}:{from:r.id,to:id,type:'contradicts',reason:'UNRESOLVED_REFERENCE'});}
  const payload={records,edges,dangling,rejected};
  return Object.assign({engine:'Odiseo Integrador de Evidencias',version:VERSION,recordCount:records.length,sourceFamilies:uniq(records.map(r=>r.sourceFamily)).length,fingerprint_fnv1a32:hash(canonical(payload)),limits:['La huella FNV-1a de 32 bits detecta cambios accidentales; no es una firma criptográfica.','La independencia de fuentes se aproxima mediante sourceFamily declarada; no se verifica externamente.','Una relación explícita no demuestra que su contenido sea verdadero.']},payload);
 }
 function evaluate(input){
  const base=ingest(input), byId=new Map(base.records.map(r=>[r.id,r])), claims=Array.isArray(input&&input.claims)?input.claims:[];
  if(claims.length>500)throw Error('Límite de 500 afirmaciones superado.');
  const results=claims.map((c,i)=>{c=c||{};const id=clean(c.id)||'claim-'+(i+1), statement=clean(c.statement), support=uniq((Array.isArray(c.supporting)?c.supporting:[]).map(clean).filter(Boolean)), against=uniq((Array.isArray(c.contradicting)?c.contradicting:[]).map(clean).filter(Boolean)), missing=[...support,...against].filter(x=>!byId.has(x));
   const sr=support.map(x=>byId.get(x)).filter(Boolean), ar=against.map(x=>byId.get(x)).filter(Boolean);
   const families=uniq(sr.map(r=>r.sourceFamily)), contradictionFamilies=uniq(ar.map(r=>r.sourceFamily));
   const directConflict=sr.some(r=>ar.some(a=>r.id===a.id||r.sourceFamily===a.sourceFamily));
   let status='UNTESTED';
   if(missing.length)status='BROKEN_REFERENCES';
   else if(sr.length&&ar.length)status='CONFLICTING_EVIDENCE';
   else if(sr.length>=2&&families.length>=2)status='MULTI_SOURCE_SUPPORTED_NOT_PROVEN';
   else if(sr.length)status='SINGLE_SOURCE_SUPPORT_ONLY';
   else if(ar.length)status='CHALLENGED_NOT_REFUTED';
   return{id,statement,status,supporting:support,contradicting:against,missingReferences:uniq(missing),supportingSourceFamilies:families,contradictingSourceFamilies:contradictionFamilies,sourceFamilyIndependence:'DECLARED_NOT_VERIFIED',directConflict};
  });
  const contradictions=base.edges.filter(e=>e.type==='contradicts');
  return{engine:base.engine,version:VERSION,status:base.rejected.length||base.dangling.length?'REVIEW_REQUIRED':'ANALYSIS_COMPLETE',integrity:{recordCount:base.recordCount,sourceFamilies:base.sourceFamilies,fingerprint_fnv1a32:base.fingerprint_fnv1a32,rejected:base.rejected.length,danglingReferences:base.dangling.length},claims:results,graph:{edges:base.edges,contradictions,dangling:base.dangling},records:base.records,limits:base.limits.concat(['MULTI_SOURCE_SUPPORTED_NOT_PROVEN significa apoyo desde familias declaradas distintas; sourceFamilyIndependence siempre es DECLARED_NOT_VERIFIED y no prueba independencia real ni verdad.','No se calcula una probabilidad ni una puntuación de confianza sin un modelo estadístico validado.'])};
 }
 g.OdiseoEvidenceIntegrator=Object.freeze({version:VERSION,ingest,evaluate,canonical});
})(typeof window!=='undefined'?window:globalThis);
