/* ODISEO 52.5 — Ciclo integrado A/B/C/D/E/H.
 * A: Sherlock descubre pistas; B: Penélope propone transformaciones estructurales;
 * C: OIE evalúa evidencias explícitas; D: Judas Tadeo reencuadra; E: Integrador E verifica tareas acotadas; H: controla recursos.
 * Las pistas heurísticas nunca se convierten automáticamente en pruebas.
 */
(function(g){'use strict';
 const VERSION='52.5-integrated-cycle-1.0';
 const arr=x=>Array.isArray(x)?x:[];
 function run(input){
  const x=input||{}, traces=arr(x.traces), claims=arr(x.claims), asts=arr(x.penelopeAsts), integratorTasks=arr(x.integratorTasks);
  const maxTraces=Math.max(1,Math.min(5000,Number.isInteger(x.maxTraces)?x.maxTraces:500));
  const maxAsts=Math.max(0,Math.min(100,Number.isInteger(x.maxAsts)?x.maxAsts:20));
  const maxIntegratorTasks=Math.max(0,Math.min(25,Number.isInteger(x.maxIntegratorTasks)?x.maxIntegratorTasks:5));
  if(traces.length>maxTraces)throw Error('H detuvo el ciclo: presupuesto de rastros excedido.');
  if(asts.length>maxAsts)throw Error('H detuvo el ciclo: presupuesto de AST excedido.');
  if(integratorTasks.length>maxIntegratorTasks)throw Error('H detuvo el ciclo: presupuesto de tareas Integrador E excedido.');
  if(!g.OdiseoSherlock||!g.OdiseoPenelope||!g.OdiseoEvidenceIntegrator||!g.OdiseoIntegrator||!g.OdiseoJudasTadeo)throw Error('Falta un motor requerido; ciclo no iniciado.');
  if(!g.OdiseoCommunicationAuditor)throw Error('Falta el Auditor de Comunicación; ciclo no iniciado.');
  const comm=g.OdiseoCommunicationAuditor;
  const trace=comm.createTrace(String(x.correlationId||('cycle-'+Date.now())),{workflow:'integrated-cycle',version:VERSION});
  // A — Sherlock busca candidatos, pero no los declara hechos.
  const sherlock=comm.invoke(trace,'IntegratedCycle','Sherlock','investigate',{traces,hypotheses:arr(x.hypotheses),budget:maxTraces,strategyBudget:x.strategyBudget||8},req=>g.OdiseoSherlock.investigate(req),{request:['traces','hypotheses','budget','strategyBudget'],response:['verdict','investigation','summary']});
  // Convertir solo enlaces explícitos aportados por el usuario en relaciones de evidencia.
  const records=traces.map((t,i)=>({id:String(t.id||'trace-'+(i+1)),source:String(t.source||'source-unspecified'),sourceFamily:String(t.sourceFamily||t.source||'family-unspecified'),statement:String(t.observation||''),kind:t.kind||'observation',supports:arr(t.links),contradicts:arr(t.contradicts),timestamp:t.when||null,original:t.original===undefined?t:null}));
  // C — OIE evalúa afirmaciones y conserva referencias rotas/contradicciones.
  const evidence=comm.invoke(trace,'IntegratedCycle','OIE','evaluate',{records,claims},req=>g.OdiseoEvidenceIntegrator.evaluate(req),{request:['records','claims'],response:['status','claims','integrity','graph']});
  // B — Penélope trabaja solo sobre AST explícitos. Las simplificaciones no se tratan como equivalencias.
  const penelope=[];
  asts.forEach((item,i)=>{const ast=item&&item.ast?item.ast:item;const sourceId=String(item&&item.id||'ast-'+(i+1));const r=comm.invoke(trace,'IntegratedCycle','Penelope','unweave',{ast,sourceId},req=>g.OdiseoPenelope.unweave(req.ast,req.sourceId),{request:['ast','sourceId'],response:['proposals','examined']});const valid=r.proposals.filter(p=>{try{g.OdiseoPenelope.validateProposal(p);return true;}catch(e){return false;}});penelope.push({sourceId,originalExpression:r.originalExpression,examined:r.examined,validProposals:valid,stopReason:r.stopReason});});
  // D — Judas Tadeo propone reencuadres; no los convierte en hechos.
  const judasRequest=x.judas||{domain:'general',block:'no_block',premises:[],attempted:[],constraints:[]};
  const judas=comm.invoke(trace,'IntegratedCycle','JudasTadeo','reframe',judasRequest,req=>g.OdiseoJudasTadeo.reframe(req),{request:['domain','block','premises'],response:['status']});
  // Integrador E — tareas combinatorias acotadas con verificador propio.
  const integratorE=integratorTasks.map((t,i)=>{const n=Number(t&&t.n);try{const result=comm.invoke(trace,'IntegratedCycle','IntegratorE','run',{n},req=>g.OdiseoIntegrator.run(req),{request:['n'],response:['status']});return {taskIndex:i,status:'EXECUTED',result};}catch(e){return {taskIndex:i,status:'REJECTED',reason:String(e.message||e)};}});
  // H — presupuesto y parada transparentes.
  const reviewRequired=evidence.status==='REVIEW_REQUIRED'||evidence.claims.some(c=>c.status==='CONFLICTING_EVIDENCE'||c.status==='BROKEN_REFERENCES')||integratorE.some(t=>!t.result||t.result.status!=='INTEGRATION_PASSED');
  const stopReason=reviewRequired?'HOLD_FOR_EVIDENCE_REVIEW':(sherlock.investigation.candidates.length||penelope.some(p=>p.validProposals.length))?'LEADS_REQUIRE_HUMAN_OR_DOMAIN_VALIDATION':'NO_VALIDATED_NEW_LEADS';
  const communication=comm.audit(trace);
  return {engine:'Odiseo Integrated Research Cycle',version:VERSION,status:reviewRequired||communication.status==='COMMUNICATION_FAILURES_FOUND'?'REVIEW_REQUIRED':'CYCLE_COMPLETED_WITH_LIMITS',communication:{trace,audit:communication},stages:{A:{engine:'Sherlock',status:sherlock.verdict,candidates:sherlock.investigation.candidates,attempts:sherlock.investigation.attempts},B:{engine:'Penelope',items:penelope,validProposalCount:penelope.reduce((n,p)=>n+p.validProposals.length,0)},D:{engine:'Judas Tadeo',status:judas.status,reframe:judas},C:{engine:'OIE',status:evidence.status,claims:evidence.claims,integrity:evidence.integrity,graph:evidence.graph},E:{engine:'Integrador E',tasks:integratorE,passed:integratorE.filter(t=>t.result&&t.result.status==='INTEGRATION_PASSED').length},H:{budgets:{maxTraces,maxAsts,maxIntegratorTasks,strategyBudget:x.strategyBudget||8},stopReason}},evidence,sherlockSummary:sherlock.summary,limits:['Los candidatos heurísticos de Sherlock son pistas, no evidencias de verdad.','Los enlaces explícitos proceden de los datos de entrada y no se verifican externamente.','Penélope valida estructura AST y reversibilidad documental, no equivalencia semántica.','Judas Tadeo genera reencuadres y rutas, no demostraciones.','Integrador E solo certifica la familia de particiones finitas que implementa.','sourceFamily es una declaración de procedencia, no una prueba de independencia.','No hay modificación automática de código ni aprendizaje autónomo.','La auditoría de comunicación solo cubre las llamadas instrumentadas en este ciclo.']};
 }
 g.OdiseoIntegratedCycle=Object.freeze({version:VERSION,run});
})(typeof window!=='undefined'?window:globalThis);
