/* ODISEO 53.1 — Lenguaje estructurado de preguntas y evaluación de respuestas.
 * DSL declarativo, vocabulario controlado y evaluación transparente.
 * Evalúa estructura, cobertura declarada y trazabilidad; NO demuestra verdad ni comprensión semántica.
 */
(function(root){'use strict';
 const VERSION='53.1-question-answer-language-1.0';
 const QUESTION_FIELDS=['id','intent','subject','operation','scope','evidence','constraints','output','stop'];
 const ANSWER_FIELDS=['questionId','status','claim','result','evidence','method','uncertainty','limits'];
 const VOCAB={
  intents:{DEFINE:'definir',EXPLAIN:'explicar',COMPARE:'comparar',PROVE:'demostrar',REFUTE:'refutar',TEST:'probar',FIND:'buscar',DESIGN:'diseñar',SUMMARIZE:'resumir',DECIDE:'decidir',CLASSIFY:'clasificar',PREDICT:'predecir'},
  operations:{DESCRIBE:'describir',CALCULATE:'calcular',TRACE:'trazar',VALIDATE:'validar',CONTRAST:'contrastar',INFER:'inferir',GENERATE:'generar',MEASURE:'medir',AUDIT:'auditar',OPTIMIZE:'optimizar'},
  epistemic:{FACT:'hecho verificado',HYPOTHESIS:'hipótesis',INFERENCE:'inferencia',ASSUMPTION:'supuesto',SPECULATION:'especulación',UNKNOWN:'desconocido'},
  answerStatus:['SUPPORTED','PARTIAL','UNSUPPORTED','CONTRADICTED','UNKNOWN','BLOCKED'],
  evidenceKinds:['SOURCE','DATA','CALCULATION','EXPERIMENT','PROOF','COUNTEREXAMPLE','OBSERVATION','NONE'],
  operators:['=','!=','<','<=','>','>=','IN','CONTAINS','IMPLIES','IFF']
 };
 const aliases={preguntar:'ASK',definir:'DEFINE',explicar:'EXPLAIN',comparar:'COMPARE',demostrar:'PROVE',refutar:'REFUTE',probar:'TEST',buscar:'FIND',diseñar:'DESIGN',resumir:'SUMMARIZE',decidir:'DECIDE',clasificar:'CLASSIFY',predecir:'PREDICT'};
 const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
 function clean(v){return String(v==null?'':v).trim()}
 function parseFields(source){const out={};let token='',quote=null,escape=false,parts=[];for(const ch of source){if(escape){token+=ch;escape=false;continue}if(ch==='\\'){escape=true;continue}if(quote){if(ch===quote)quote=null;else token+=ch;continue}if(ch==='"'||ch==="'"){quote=ch;continue}if(ch===';'){parts.push(token);token=''}else token+=ch}if(quote)throw Error('Cadena entrecomillada sin cerrar');parts.push(token);for(const p of parts){if(!p.trim())continue;const i=p.indexOf('=');if(i<1)throw Error('Campo inválido: '+p);const k=p.slice(0,i).trim(),v=p.slice(i+1).trim();if(own(out,k))throw Error('Campo duplicado: '+k);out[k]=v}return out}
 function parse(source){const s=clean(source),m=s.match(/^(ODQ|ODA)\s*\{([\s\S]*)\}$/i);if(!m)throw Error('Formato esperado: ODQ{...} u ODA{...}');return {kind:m[1].toUpperCase(),fields:parseFields(m[2])}}
 function normalizeQuestion(input){let q;if(typeof input==='string'){const p=parse(input);if(p.kind!=='ODQ')throw Error('Se esperaba ODQ');q=p.fields}else q=Object.assign({},input||{});q.id=clean(q.id)||'Q-'+Date.now().toString(36);q.intent=clean(q.intent).toUpperCase();if(aliases[q.intent.toLowerCase()])q.intent=aliases[q.intent.toLowerCase()];q.subject=clean(q.subject);q.operation=clean(q.operation).toUpperCase();q.scope=clean(q.scope);q.evidence=clean(q.evidence)||'NONE';q.constraints=clean(q.constraints)||'NONE';q.output=clean(q.output)||'TEXT';q.stop=clean(q.stop)||'WHEN_COMPLETE';return q}
 function normalizeAnswer(input){let a;if(typeof input==='string'){const p=parse(input);if(p.kind!=='ODA')throw Error('Se esperaba ODA');a=p.fields}else a=Object.assign({},input||{});return {questionId:clean(a.questionId),status:clean(a.status).toUpperCase(),claim:clean(a.claim),result:clean(a.result),evidence:clean(a.evidence)||'NONE',method:clean(a.method)||'NONE',uncertainty:clean(a.uncertainty)||'UNSPECIFIED',limits:clean(a.limits)||'UNSPECIFIED'}}
 function validateQuestion(input){let q;try{q=normalizeQuestion(input)}catch(e){return {valid:false,errors:[String(e.message||e)]}}const errors=[];if(!q.id)errors.push('Falta id');if(!own(VOCAB.intents,q.intent))errors.push('Intent no reconocido: '+q.intent);if(!q.subject)errors.push('Falta subject');if(!own(VOCAB.operations,q.operation))errors.push('Operation no reconocida: '+q.operation);if(!q.scope)errors.push('Falta scope');if(!q.output)errors.push('Falta output');if(!q.stop)errors.push('Falta stop');return {valid:errors.length===0,errors,question:q,missingFields:QUESTION_FIELDS.filter(k=>!clean(q[k]))}}
 function validateAnswer(input){let a;try{a=normalizeAnswer(input)}catch(e){return {valid:false,errors:[String(e.message||e)]}}const errors=[];if(!a.questionId)errors.push('Falta questionId');if(!VOCAB.answerStatus.includes(a.status))errors.push('Status no reconocido: '+a.status);if(!a.claim)errors.push('Falta claim');if(!a.result)errors.push('Falta result');if(!a.method)errors.push('Falta method');if(!a.uncertainty)errors.push('Falta uncertainty');if(!a.limits)errors.push('Falta limits');return {valid:errors.length===0,errors,answer:a,missingFields:ANSWER_FIELDS.filter(k=>!clean(a[k]))}}
 function evaluate(question,answer){const qv=validateQuestion(question),av=validateAnswer(answer),issues=[];if(!qv.valid)issues.push(...qv.errors.map(x=>({code:'INVALID_QUESTION',severity:'HIGH',detail:x})));if(!av.valid)issues.push(...av.errors.map(x=>({code:'INVALID_ANSWER',severity:'HIGH',detail:x})));if(!qv.question||!av.answer)return {version:VERSION,status:'NOT_EVALUABLE',score:0,issues,dimensions:{}};const q=qv.question,a=av.answer;if(a.questionId!==q.id)issues.push({code:'QUESTION_ID_MISMATCH',severity:'HIGH',detail:'La respuesta no referencia la pregunta evaluada'});
  const dims={};function dim(name,pass,weight,detail){dims[name]={pass,weight,detail};if(!pass)issues.push({code:'MISSING_'+name.toUpperCase(),severity:'MEDIUM',detail})}
  dim('intent_alignment',a.claim.length>0,15,'Hay una afirmación principal que se puede contrastar con la intención');
  dim('result_present',a.result.length>0,15,'Resultado explícito');
  dim('method_traceable',a.method!=='NONE',15,'Método declarado');
  dim('evidence_declared',a.evidence!=='NONE',15,'Evidencia declarada; su calidad no queda validada');
  dim('uncertainty_declared',a.uncertainty!=='UNSPECIFIED',10,'Incertidumbre declarada');
  dim('limits_declared',a.limits!=='UNSPECIFIED',10,'Límites declarados');
  const statusAllowed=VOCAB.answerStatus.includes(a.status);dim('epistemic_status_valid',statusAllowed,10,'Estado epistémico pertenece al vocabulario controlado');
  const scopeExplicit=q.scope!=='*'&&q.scope.toUpperCase()!=='UNBOUNDED';dim('scope_bounded',scopeExplicit,10,'Alcance delimitado en la pregunta');
  const score=Object.values(dims).reduce((s,d)=>s+(d.pass?d.weight:0),0);if(a.status==='SUPPORTED'&&a.evidence==='NONE')issues.push({code:'SUPPORTED_WITHOUT_EVIDENCE',severity:'HIGH',detail:'La respuesta se declara respaldada pero no declara evidencia'});if(a.status==='UNKNOWN'&&a.uncertainty==='NONE')issues.push({code:'UNKNOWN_WITHOUT_UNCERTAINTY',severity:'MEDIUM',detail:'Declara desconocimiento sin explicar incertidumbre'});
  return {version:VERSION,status:issues.some(x=>x.severity==='HIGH')?'REVIEW_REQUIRED':score>=85?'STRUCTURALLY_STRONG':score>=60?'STRUCTURALLY_PARTIAL':'STRUCTURALLY_WEAK',score,dimensions:dims,issues,semanticTruth:'NOT_EVALUATED',limits:['La puntuación mide cumplimiento del formato y trazabilidad declarada, no verdad.','No determina por sí sola si la respuesta contesta semánticamente la pregunta.','La evidencia se declara, pero su autenticidad y fuerza requieren verificadores externos.','Una respuesta breve puede ser correcta; la longitud no se puntúa.']};
 }
 function format(kind,fields){const order=kind==='ODQ'?QUESTION_FIELDS:ANSWER_FIELDS;return kind+'{'+order.filter(k=>own(fields,k)).map(k=>k+'="'+String(fields[k]).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/;/g,'\\;')+'"').join('; ')+'}'}
 root.OdiseoQuestionLanguage=Object.freeze({version:VERSION,vocabulary:VOCAB,questionFields:QUESTION_FIELDS,answerFields:ANSWER_FIELDS,parse,format,normalizeQuestion,normalizeAnswer,validateQuestion,validateAnswer,evaluate});
})(typeof window!=='undefined'?window:globalThis);
