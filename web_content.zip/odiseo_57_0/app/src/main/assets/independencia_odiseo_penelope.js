/* ODISEO 51.6 — Prueba de independencia Odiseo/Penélope.
 * Cada motor recibe una copia congelada del mismo reto; no ve la respuesta ajena
 * hasta que ambas respuestas están comprometidas mediante SHA-256.
 * La prueba mide independencia de ejecución y concordancia aritmética, no inteligencia general.
 */
(function(global){'use strict';
 const VERSION='51.6-independencia';
 function fail(m){throw new Error(m)}
 function clone(x){return JSON.parse(JSON.stringify(x))}
 function freezeDeep(x){if(x&&typeof x==='object'){Object.freeze(x);Object.keys(x).forEach(k=>freezeDeep(x[k]));}return x;}
 function canonical(x){if(Array.isArray(x))return '['+x.map(canonical).join(',')+']';if(x&&typeof x==='object')return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';return JSON.stringify(x)}
 async function sha256(value){if(!global.crypto||!global.crypto.subtle)fail('SHA-256 no está disponible en este entorno.');const bytes=new TextEncoder().encode(typeof value==='string'?value:canonical(value));const digest=await global.crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');}
 function rng(seed){let x=seed>>>0;if(x===0)x=0x9e3779b9;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return x>>>0;};}
 function makeChallenge(seed){if(!Number.isSafeInteger(seed)||seed<0||seed>0xffffffff)fail('La semilla debe ser un entero entre 0 y 2^32−1.');const next=rng(seed),set=new Set(['3']);while(set.size<17){let n=(next()%999999)+1;if(n%2===0)n++;if(n>1000001)n-=2;set.add(String(n));}while(set.size<25){let odd=(next()%333333)+1;if(odd%2===0)odd++;set.add(String(odd*3));}const inputs=Array.from(set,BigInt).sort((a,b)=>a<b?-1:a>b?1:0).map(String);return {id:'syracuse-independent-'+seed,kind:'syracuse_batch',seed,inputs,claims:['Calcular F(n)=(3n+1)/2^v2(3n+1) para cada impar suministrado.','Comprobar si los datos refutan la afirmación F(n)<n para todo impar n>1.','Comprobar en las entradas divisibles por 3 si F(n) también es divisible por 3.']};}
 function verify(task,answer){const errors=[],seen=new Set();if(!answer||answer.taskId!==task.id||!Array.isArray(answer.results))return {valid:false,errors:[{type:'INVALID_RESPONSE'}]};if(answer.results.length!==task.inputs.length)errors.push({type:'RESULT_COUNT',expected:task.inputs.length,actual:answer.results.length});for(const raw of task.inputs){const n=BigInt(raw),t=3n*n+1n;const r=answer.results.find(x=>x&&x.n===raw);if(!r){errors.push({type:'MISSING_INPUT',input:raw});continue;}if(seen.has(r.n))errors.push({type:'DUPLICATE_INPUT',input:raw});seen.add(r.n);let q,a;try{q=BigInt(r.successor);a=r.exponent;}catch(e){errors.push({type:'MALFORMED_VALUE',input:raw});continue;}if(!Number.isSafeInteger(a)||a<1||q<=0n||q%2n===0n||q*(2n**BigInt(a))!==t)errors.push({type:'ALGEBRAIC_IDENTITY_FAILED',input:raw,expectedIdentity:'successor * 2^exponent = 3n+1',received:r});}
  const resultByInput=raw=>answer.results.find(x=>x&&x.n===raw),allOdd=task.inputs.every(raw=>{const r=resultByInput(raw);return !!r&&(()=>{try{const q=BigInt(r.successor);return q>0n&&q%2n===1n;}catch(e){return false;}})();}),allDecrease=task.inputs.every(raw=>{const r=resultByInput(raw);return !!r&&BigInt(r.successor)<BigInt(raw);});
  if(!answer.claims||answer.claims.positiveOddOutput!==allOdd)errors.push({type:'CLAIM_MISMATCH',claim:'positiveOddOutput',derived:allOdd,reported:answer.claims&&answer.claims.positiveOddOutput});
  if(!answer.claims||answer.claims.allSuppliedInputsDecrease!==allDecrease)errors.push({type:'CLAIM_MISMATCH',claim:'allSuppliedInputsDecrease',derived:allDecrease,reported:answer.claims&&answer.claims.allSuppliedInputsDecrease});
  const results=answer.results,firstCounterexample=task.inputs.map(BigInt).filter(n=>n>1n).map(n=>{const r=results.find(x=>x.n===n.toString());return r&&BigInt(r.successor)>=n?{n:n.toString(),successor:r.successor}:null;}).filter(Boolean).sort((a,b)=>BigInt(a.n)<BigInt(b.n)?-1:1)[0]||null;
  const modularViolations=task.inputs.filter(raw=>BigInt(raw)%3n===0n).map(raw=>{const r=results.find(x=>x.n===raw);return r&&BigInt(r.successor)%3n===0n?{n:raw,successor:r.successor}:null;}).filter(Boolean);
  return {valid:errors.length===0,errors,firstCounterexample,modularViolations,checked:task.inputs.length,claimChecks:{positiveOddOutput:allOdd,allSuppliedInputsDecrease:allDecrease}};}
 async function run(options){const o=options||{},seed=o.seed===undefined?20261104:o.seed,Odiseo=o.Odiseo,Penelope=o.Penelope;if(!Odiseo||!Penelope||typeof Odiseo.solveIndependently!=='function'||typeof Penelope.solveIndependently!=='function')fail('Se necesitan los motores Odiseo y Penélope con solveIndependently.');
  const task=makeChallenge(seed),taskForO=freezeDeep(clone(task)),taskForP=freezeDeep(clone(task));
  // Fase sellada: cada llamada recibe únicamente el reto, nunca la salida del otro.
  const rawO=Odiseo.solveIndependently(taskForO),rawP=Penelope.solveIndependently(taskForP);
  const responseO=clone(rawO),responseP=clone(rawP);
  const [commitO,commitP,taskHash]=await Promise.all([sha256(responseO),sha256(responseP),sha256(task)]);
  // Solo después de crear ambos compromisos se habilita la revisión cruzada.
  const reviewO=Odiseo.reviewPeer(task,responseP),reviewP=Penelope.reviewPeer(task,responseO);
  const auditO=verify(task,responseO),auditP=verify(task,responseP);
  const same=canonical(responseO.results)===canonical(responseP.results);
  return {version:VERSION,seed,task:{id:task.id,kind:task.kind,inputs:task.inputs,claims:task.claims,sha256:taskHash},sealedBeforeReview:true,independentInputs:canonical(taskForO)===canonical(taskForP),responses:{odiseo:{engine:responseO.engine,method:responseO.method,sha256:commitO,valid:auditO.valid,errors:auditO.errors,reviewOfPenelope:reviewO},penelope:{engine:responseP.engine,method:responseP.method,sha256:commitP,valid:auditP.valid,errors:auditP.errors,reviewOfOdiseo:reviewP}},comparison:{identicalResults:same,firstCounterexample:auditO.firstCounterexample,modularViolations:auditO.modularViolations,checksPerMotor:task.inputs.length,uniqueDiscoveries:[],errorsCaughtByPeer:reviewO.length+reviewP.length},status:auditO.valid&&auditP.valid&&same&&reviewO.length===0&&reviewP.length===0?'INDEPENDENCE_PROTOCOL_PASSED':'DISCREPANCY_REQUIRES_REVIEW',limits:['La independencia comprobada es de entradas, ejecución y código de cálculo; ambos motores se ejecutan en el mismo proceso y no son agentes conscientes.','La igualdad de resultados no demuestra por sí sola razonamiento independiente; las implementaciones usan algoritmos aritméticos distintos y quedan auditadas por un tercer verificador.','El lote finito no demuestra la conjetura de Collatz. La propiedad de salida impar positiva se deduce de la definición de la función.','La prueba no mide inteligencia general ni aprendizaje autónomo.']};
 }
 global.OdiseoIndependence=Object.freeze({version:VERSION,makeChallenge,verify,run,canonical});
})(window);
