/* TIC 1.1 — Transmisión de Información y Conjunto.
 * Estimadores discretos empíricos. No infiere causalidad sin intervención.
 */
(function(root){
  'use strict';
  function assertArray(a,n){if(!Array.isArray(a)||a.length<n)throw new Error('Serie inválida o demasiado corta.');}
  function key(v){return JSON.stringify(v);}
  function counts(a){const m=new Map();for(const v of a){const k=key(v);m.set(k,(m.get(k)||0)+1);}return m;}
  function entropy(a){assertArray(a,1);const c=counts(a),n=a.length;let h=0;for(const v of c.values()){const p=v/n;h-=p*Math.log2(p);}return h;}
  function mutualInformation(x,y){assertArray(x,1);assertArray(y,1);if(x.length!==y.length)throw new Error('Longitudes incompatibles.');const n=x.length,j=counts(x.map((v,i)=>[v,y[i]])),cx=counts(x),cy=counts(y);let h=0;for(const [k,v] of j){const [a,b]=JSON.parse(k),p=v/n,px=cx.get(key(a))/n,py=cy.get(key(b))/n;h+=p*Math.log2(p/(px*py));}return Math.max(0,h);}
  function conditionalMI(x,y,z){assertArray(x,1);assertArray(y,1);assertArray(z,1);const n=x.length;if(y.length!==n||z.length!==n)throw new Error('Longitudes incompatibles.');const xyz=counts(x.map((v,i)=>[v,y[i],z[i]])),xz=counts(x.map((v,i)=>[v,z[i]])),yz=counts(y.map((v,i)=>[v,z[i]])),cz=counts(z);let out=0;for(const [k,v] of xyz){const [a,b,c]=JSON.parse(k),p=v/n,pxz=xz.get(key([a,c]))/n,pyz=yz.get(key([b,c]))/n,pz=cz.get(key(c))/n;out+=p*Math.log2((p*pz)/(pxz*pyz));}return Math.max(0,out);}
  function transferEntropy(source,target,lag=1){assertArray(source,lag+2);assertArray(target,lag+2);if(source.length!==target.length)throw new Error('Longitudes incompatibles.');const s=[],yf=[],yp=[];for(let t=lag;t<target.length;t++){s.push(source[t-lag]);yf.push(target[t]);yp.push(target[t-lag]);}return conditionalMI(s,yf,yp);}
  function ratio(a,b){return b>1e-12?a/b:0;}
  function pairMetrics(original,received,cost=1){const h=entropy(original),mi=mutualInformation(original,received);
    const cond= Math.max(0,h-mi);return {sourceEntropyBits:h,sharedInformationBits:mi,conservationRatio:Math.min(1,ratio(mi,h)),lossBits:cond,lossRatio:Math.min(1,ratio(cond,h)),efficiencyBitsPerCost:mi/Math.max(Number(cost)||1,1e-12)};}
  function jointStates(columns){if(!Array.isArray(columns)||!columns.length)throw new Error('Se requieren fuentes.');const n=columns[0].length;for(const c of columns)if(c.length!==n)throw new Error('Fuentes de distinta longitud.');return Array.from({length:n},(_,i)=>columns.map(c=>c[i]));}
  function integrationMetrics(sources,target){const joint=mutualInformation(jointStates(sources),target),individual=sources.map(s=>mutualInformation(s,target));return {jointInformationBits:joint,individualInformationBits:individual,largestIndividualBits:Math.max(...individual),synergyScreeningGapBits:Math.max(0,joint-Math.max(...individual)),warning:'La brecha es un indicador exploratorio; no sustituye una descomposición PID y no prueba emergencia general.'};}
  function rng(seed){let x=seed>>>0;return ()=>{x=(1664525*x+1013904223)>>>0;return x/4294967296;};}
  function bit(r){return r()<0.5?0:1;}
  function flip(v,r,p){return r()<p?1-v:v;}
  function simulateIndependent(n=12000,seed=1101){const r=rng(seed),a=[],b=[],y=[];for(let i=0;i<n;i++){a.push(bit(r));b.push(bit(r));y.push(bit(r));}return {scenario:'A_INDEPENDENT_NO_CHANNEL',a,b,y,metrics:{teAtoY:transferEntropy(a,y),miAToY:mutualInformation(a,y),miBToY:mutualInformation(b,y)}};}
  function simulateRedundant(n=12000,seed=2202,noise=0.15){const r=rng(seed),s=[],r1=[bit(r)],r2=[bit(r)];for(let i=0;i<n;i++)s.push(bit(r));for(let i=1;i<n;i++){r1.push(flip(s[i-1],r,noise));r2.push(flip(s[i-1],r,noise));}return {scenario:'B_NOISY_REDUNDANT_CHANNEL',source:s,receiver1:r1,receiver2:r2,metrics:{teSourceToR1:transferEntropy(s,r1),channel1:pairMetrics(s.slice(0,-1),r1.slice(1)),channel2:pairMetrics(s.slice(0,-1),r2.slice(1)),receiverRedundancyBits:mutualInformation(r1,r2)}};}
  function simulateSynergy(n=16000,seed=3303){const r=rng(seed),a=[],b=[],y=[];for(let i=0;i<n;i++){const x=bit(r),z=bit(r);a.push(x);b.push(z);y.push(x^z);}return {scenario:'C_XOR_SYNERGY',a,b,y,metrics:integrationMetrics([a,b],y)};}
  function simulateFeedback(n=12000,seed=4404,noise=0.1,enabled=true){const r=rng(seed),element=[],global=[];let e=bit(r);element.push(e);global.push(flip(e,r,noise));for(let i=1;i<n;i++){e=enabled?flip(global[i-1],r,noise):bit(r);element.push(e);global.push(flip(element[i-1],r,noise));}return {scenario:enabled?'D_BIDIRECTIONAL_FEEDBACK':'D_FEEDBACK_DISABLED',element,global,metrics:{elementToGlobal:transferEntropy(element,global),globalToElement:transferEntropy(global,element)}};}
  function runSuite(options={}){const n=options.samples||12000;const a=simulateIndependent(n,1101),b=simulateRedundant(n,2202,0.15),c=simulateSynergy(n,3303),d=simulateFeedback(n,4404,0.1,true),off=simulateFeedback(n,4404,0.1,false);return {version:'TIC-1.1',samples:n,scenarios:[a,b,c,d,off].map(x=>({scenario:x.scenario,metrics:x.metrics})),limits:['Estimación empírica dependiente del tamaño de muestra y del alfabeto.','La transferencia de entropía detecta información predictiva dirigida, no causalidad por sí sola.','La intervención simulada solo valida el mecanismo artificial conocido.','La brecha sinérgica es un cribado; no una PID general.','No se evalúan canales continuos, retardos múltiples ni confusores no observados.']};}
  const api={version:'TIC-1.1',entropy,mutualInformation,conditionalMI,transferEntropy,pairMetrics,integrationMetrics,simulateIndependent,simulateRedundant,simulateSynergy,simulateFeedback,runSuite};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.OdiseoTIC=api;
})(typeof window!=='undefined'?window:globalThis);
