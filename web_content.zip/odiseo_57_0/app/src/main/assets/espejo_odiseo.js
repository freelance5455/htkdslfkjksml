/* ODISEO 50.1 — Espejo Bidireccional.
 * Motor genérico de información explícita: expansión, retorno, auditoría y memoria de resultados.
 * No presume conocer información ausente ni convierte asociaciones en verdades.
 */
(function (global) {
  'use strict';
  const VERSION = '1.1.0-espejo-bidireccional';
  const MAX_NODES = 5000, MAX_EDGES = 20000, MAX_VISITS = 10000, MAX_TEXT = 4000;
  const RELATIONS = new Set(['supports', 'derives', 'contradicts', 'relates']);
  const OUTCOMES = new Set(['verified', 'refuted', 'inconclusive']);

  function cleanText(value, label) {
    if (typeof value !== 'string' || !value.trim() || value.length > MAX_TEXT) throw new Error((label || 'Texto') + ': debe contener entre 1 y ' + MAX_TEXT + ' caracteres.');
    return value.trim();
  }
  function cloneGraph(input) {
    const g = input && typeof input === 'object' ? input : {};
    const nodes = Array.isArray(g.nodes) ? g.nodes : [];
    const edges = Array.isArray(g.edges) ? g.edges : [];
    const learnings = Array.isArray(g.learnings) ? g.learnings : [];
    if (nodes.length > MAX_NODES || edges.length > MAX_EDGES) throw new Error('El grafo supera los límites de seguridad.');
    const ids = new Set();
    const safeNodes = nodes.map(n => {
      if (!n || typeof n.id !== 'string' || !n.id || ids.has(n.id)) throw new Error('Identificador de nodo inválido o duplicado.');
      ids.add(n.id);
      return { id:n.id, text:cleanText(n.text,'Contenido del nodo'), kind:String(n.kind || 'information'), evidence:String(n.evidence || ''), createdAt:String(n.createdAt || '') };
    });
    const edgeIds = new Set();
    const safeEdges = edges.map(e => {
      if (!e || typeof e.id !== 'string' || !e.id || edgeIds.has(e.id) || !ids.has(e.from) || !ids.has(e.to) || !RELATIONS.has(e.relation)) throw new Error('Relación inválida: comprueba sus nodos y tipo.');
      edgeIds.add(e.id);
      return { id:e.id, from:e.from, to:e.to, relation:e.relation, evidence:String(e.evidence || '') };
    });
    const safeLearnings = learnings.filter(x => x && OUTCOMES.has(x.outcome) && typeof x.strategy === 'string' && typeof x.evidence === 'string').slice(-2000);
    return { schema:'ODISEO_MIRROR_GRAPH_1', nodes:safeNodes, edges:safeEdges, learnings:safeLearnings };
  }
  function makeId(prefix) { return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,9); }
  function addNode(graph, data) {
    const g = cloneGraph(graph);
    if (g.nodes.length >= MAX_NODES) throw new Error('Límite de nodos alcanzado.');
    const text = cleanText(data && data.text, 'Contenido');
    const node = { id:makeId('n'), text, kind:String(data.kind || 'information'), evidence:String(data.evidence || ''), createdAt:new Date().toISOString() };
    g.nodes.push(node); return { graph:g, node };
  }
  function addEdge(graph, data) {
    const g = cloneGraph(graph), from = String(data && data.from || ''), to = String(data && data.to || ''), relation = String(data && data.relation || 'relates');
    if (!g.nodes.some(n => n.id === from) || !g.nodes.some(n => n.id === to)) throw new Error('Selecciona dos nodos existentes.');
    if (!RELATIONS.has(relation)) throw new Error('Tipo de relación no permitido.');
    if (g.edges.length >= MAX_EDGES) throw new Error('Límite de relaciones alcanzado.');
    if (g.edges.some(e => e.from === from && e.to === to && e.relation === relation)) throw new Error('Esa relación ya existe.');
    const edge = { id:makeId('e'), from, to, relation, evidence:String(data.evidence || '') };
    g.edges.push(edge); return { graph:g, edge };
  }
  function traverse(g, seed, direction, budget) {
    const adjacency = new Map(g.nodes.map(n => [n.id, []]));
    for (const e of g.edges) {
      const start = direction === 'forward' ? e.from : e.to;
      const next = direction === 'forward' ? e.to : e.from;
      adjacency.get(start).push({ id:next, edge:e });
    }
    const queue = [seed], seen = new Set([seed]), paths = [], usedEdges = new Set();
    let truncated = false;
    while (queue.length) {
      const current = queue.shift();
      for (const item of adjacency.get(current) || []) {
        usedEdges.add(item.edge.id);
        if (!seen.has(item.id) && seen.size >= budget) { truncated = true; break; }
        paths.push({ from:current, to:item.id, relation:item.edge.relation, edgeId:item.edge.id, evidence:item.edge.evidence });
        if (!seen.has(item.id)) { seen.add(item.id); queue.push(item.id); }
      }
    }
    return { nodeIds:Array.from(seen), paths, truncated:truncated || queue.length > 0, visited:seen.size, edgeIds:Array.from(usedEdges) };
  }
  function analyze(graph, seedId, maxVisits) {
    const g = cloneGraph(graph), budget = Number(maxVisits === undefined ? 500 : maxVisits);
    if (!Number.isSafeInteger(budget) || budget < 1 || budget > MAX_VISITS) throw new Error('El presupuesto debe estar entre 1 y ' + MAX_VISITS + '.');
    if (!g.nodes.some(n => n.id === seedId)) throw new Error('El nodo inicial no existe.');
    // A: expansión desde el origen. B: retorno hacia los antecedentes y búsqueda de contradicciones.
    const forward = traverse(g, seedId, 'forward', budget);
    const backward = traverse(g, seedId, 'backward', budget);
    const contradictions = g.edges.filter(e => e.relation === 'contradicts' && forward.nodeIds.includes(e.from) && forward.nodeIds.includes(e.to));
    // C: integridad de referencias y trazabilidad explícita.
    const nodeMap = new Map(g.nodes.map(n => [n.id,n]));
    const reached = new Set([...forward.nodeIds, ...backward.nodeIds]);
    const noEvidence = Array.from(reached).map(id => nodeMap.get(id)).filter(n => !n.evidence.trim());
    const h = { budget, visitedForward:forward.visited, visitedBackward:backward.visited, truncated:forward.truncated || backward.truncated,
      stopReason:(forward.truncated || backward.truncated) ? 'PRESUPUESTO_CUMPLIDO' : 'RECORRIDO_AGOTADO' };
    return { engine:'ODISEO ESPEJO BIDIRECCIONAL', version:VERSION, seed:nodeMap.get(seedId),
      A:{ role:'Expansión', nodes:forward.nodeIds, paths:forward.paths },
      B:{ role:'Retorno y refutación', nodes:backward.nodeIds, paths:backward.paths, contradictions },
      C:{ role:'Evaluación', reachedNodes:reached.size, contradictions:contradictions.length,
        nodesWithoutEvidence:noEvidence.map(n=>({id:n.id,text:n.text})), integrity:'REFERENCIAS_VALIDAS',
        interpretation:'Las relaciones son información registrada, no hechos demostrados. La ausencia de contradicciones registradas no prueba que una afirmación sea verdadera.' },
      H:h, status:contradictions.length ? 'CONTRADICCIONES_PENDIENTES' : (h.truncated ? 'EXPLORACION_INCOMPLETA' : 'RECORRIDO_COMPLETADO') };
  }
  function recordOutcome(graph, data) {
    const g = cloneGraph(graph), strategy = cleanText(data && data.strategy,'Estrategia'), evidence = cleanText(data && data.evidence,'Evidencia'), outcome = String(data && data.outcome || '');
    if (!OUTCOMES.has(outcome)) throw new Error('El resultado debe ser verified, refuted o inconclusive.');
    g.learnings.push({ id:makeId('l'), strategy, outcome, evidence, recordedAt:new Date().toISOString() });
    return g;
  }
  function learningSummary(graph) {
    const g = cloneGraph(graph), map = {};
    for (const item of g.learnings) {
      const x = map[item.strategy] || (map[item.strategy] = { strategy:item.strategy, verified:0, refuted:0, inconclusive:0, total:0 });
      x[item.outcome]++; x.total++;
    }
    return Object.values(map).sort((a,b)=>b.verified-a.verified || a.refuted-b.refuted || b.total-a.total);
  }
  function recommendStrategy(graph) {
    const ranked = learningSummary(graph);
    if (!ranked.length) return { strategy:null, reason:'Aún no hay experiencias evaluadas; registra una estrategia y su evidencia.' };
    // Prioriza evidencia verificada, evita repetir estrategias refutadas y favorece las menos exploradas en empate.
    ranked.sort((a,b)=>((b.verified+1)/(b.total+2))-((a.verified+1)/(a.total+2)) || a.refuted-b.refuted || a.total-b.total);
    return { strategy:ranked[0].strategy, reason:'Mejor balance histórico disponible: '+ranked[0].verified+' verificadas, '+ranked[0].refuted+' refutadas y '+ranked[0].inconclusive+' inconclusas. Es una recomendación heurística, no una garantía.' };
  }
  // ESPEJO 2.0: exploratory question generator. It proposes questions, never facts.
  const EXPLORATION_AXES = Object.freeze([
    {id:'numeric',label:'numérica',prompt:'¿Qué propiedades numéricas alternativas o invariantes no se han medido?',test:'Definir una propiedad antes de observar el resultado y contrastarla con controles aleatorios.'},
    {id:'dynamic',label:'dinámica',prompt:'¿Qué cambia al invertir la dirección, variar la escala o modificar las condiciones iniciales?',test:'Comparar trayectorias directas e inversas bajo condiciones preregistradas.'},
    {id:'statistical',label:'estadística',prompt:'¿La estructura observada supera un modelo nulo y controles fuera de muestra?',test:'Contrastar contra permutaciones, simulación nula y un conjunto temporal reservado.'},
    {id:'structural',label:'estructural',prompt:'¿Existen simetrías, invariantes, clases de equivalencia o contraejemplos no representados?',test:'Buscar contraejemplos y comprobar invariancia bajo transformaciones explícitas.'},
    {id:'informational',label:'informacional',prompt:'¿Qué información se pierde, aparece o se comparte al pasar de las partes al conjunto?',test:'Medir transferencia, redundancia y sinergia con controles de confusión y retardos.'},
    {id:'causal',label:'causal',prompt:'¿Una variable común, selección o sesgo explica la asociación sin causalidad directa?',test:'Construir un diagrama causal alternativo y probar controles negativos.'},
    {id:'methodological',label:'metodológica',prompt:'¿Qué supuesto del método podría hacer invisible una solución o fabricar un resultado?',test:'Repetir el análisis con una metodología independiente y análisis de sensibilidad.'},
    {id:'domain_shift',label:'cambio de dominio',prompt:'¿La idea sigue siendo válida en otro dominio o solo funciona en el conjunto donde nació?',test:'Transferir la hipótesis a un dominio externo definido previamente.'}
  ]);
  function proposeQuestions(graph, options) {
    const g = cloneGraph(graph), limit = Number(options && options.limit !== undefined ? options.limit : 12);
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 64) throw new Error('El límite de preguntas debe estar entre 1 y 64.');
    const ids = new Set(g.nodes.map(n=>n.id));
    const incoming = new Map(g.nodes.map(n=>[n.id,0])), outgoing = new Map(g.nodes.map(n=>[n.id,0]));
    for (const e of g.edges) { outgoing.set(e.from,(outgoing.get(e.from)||0)+1); incoming.set(e.to,(incoming.get(e.to)||0)+1); }
    const isolated = g.nodes.filter(n=>!incoming.get(n.id)&&!outgoing.get(n.id));
    const unsupported = g.nodes.filter(n=>!n.evidence.trim());
    const claims = g.nodes.filter(n=>/claim|hypothesis|conclusion|afirmaci|hip[oó]tesis|conclusi/i.test(n.kind+' '+n.text));
    const contradicted = new Set(g.edges.filter(e=>e.relation==='contradicts').flatMap(e=>[e.from,e.to]));
    const unchallenged = claims.filter(n=>!contradicted.has(n.id));
    const questions=[];
    const push=(axis,question,basis,rationale,test,priority='normal')=>questions.push({id:makeId('q'),axis,question,basis:basis.filter(x=>ids.has(x)),rationale,test,priority,status:'unexamined',epistemicStatus:'pregunta_generada_no_es_evidencia'});
    if (!g.nodes.length) push('foundations','¿Qué problema, observación y criterio de éxito deberían definirse antes de construir una explicación?',[],'El grafo está vacío; no hay evidencia ni objeto de estudio registrado.','Definir pregunta, variables observables, hipótesis nula y criterio de refutación.','high');
    for (const a of EXPLORATION_AXES) push(a.id,a.prompt,[], 'Exploración abierta: esta pregunta no presupone que exista una relación.',a.test);
    if (isolated.length) push('connectivity','¿Los nodos aislados son realmente independientes o falta registrar una relación comprobable?',isolated.map(n=>n.id),'Hay nodos sin relaciones registradas; eso puede reflejar ausencia de conexión o falta de modelado.','Buscar evidencia independiente de conexión y conservar también el resultado nulo.', 'high');
    if (unsupported.length) push('provenance','¿Qué evidencia primaria permitiría verificar los nodos que carecen de procedencia?',unsupported.slice(0,20).map(n=>n.id),'Hay contenidos sin evidencia adjunta; no deben tratarse como hechos.','Adjuntar fuente, fecha, método, hash y cadena de procedencia o rebajar su estatus.', 'high');
    if (unchallenged.length) push('falsification','¿Qué observación podría refutar las afirmaciones que aún no tienen contradicción registrada?',unchallenged.slice(0,20).map(n=>n.id),'La ausencia de contradicción registrada no demuestra verdad.', 'Diseñar un contraejemplo y una prueba adversarial para cada afirmación.', 'high');
    const untested=g.learnings.filter(x=>x.outcome==='inconclusive');
    if (untested.length) push('replication','¿Qué cambio de método o muestra resolvería los resultados inconclusos sin reutilizar los mismos datos?',[],'Existen resultados inconclusos registrados.','Preregistrar réplica independiente y separar exploración de confirmación.');
    return {engine:'ODISEO ESPEJO EXPLORADOR',version:'2.0.0-alpha',generatedAt:new Date().toISOString(),questions:questions.slice(0,limit),coverage:{nodes:g.nodes.length,edges:g.edges.length,isolated:isolated.length,withoutEvidence:unsupported.length,claimsWithoutRecordedContradiction:unchallenged.length},notice:'Estas son preguntas heurísticas generadas a partir de la estructura disponible. No representan conocimiento nuevo demostrado ni garantizan descubrir hechos desconocidos.'};
  }
  function auditSelf(graph) {
    const g=cloneGraph(graph), findings=[];
    const nodeIds=new Set(g.nodes.map(n=>n.id));
    const incoming=new Set(g.edges.map(e=>e.to)), outgoing=new Set(g.edges.map(e=>e.from));
    for (const n of g.nodes) {
      if (!n.evidence.trim()) findings.push({severity:'high',code:'MISSING_EVIDENCE',nodeId:n.id,message:'Nodo sin evidencia o procedencia registrada.'});
      if (!incoming.has(n.id)&&!outgoing.has(n.id)) findings.push({severity:'info',code:'ISOLATED_NODE',nodeId:n.id,message:'Nodo aislado: no inferir independencia real.'});
    }
    for (const e of g.edges) if (!e.evidence.trim()) findings.push({severity:'medium',code:'RELATION_WITHOUT_EVIDENCE',edgeId:e.id,message:'Relación registrada sin justificación adjunta.'});
    const duplicateLearnings=new Map();
    for (const l of g.learnings) duplicateLearnings.set(l.strategy,(duplicateLearnings.get(l.strategy)||0)+1);
    for (const [strategy,count] of duplicateLearnings) if (count>1) findings.push({severity:'info',code:'REPEATED_STRATEGY',strategy,count,message:'Estrategia repetida; comprobar independencia de las evaluaciones.'});
    return {engine:'ODISEO ESPEJO SELF-AUDIT',version:'2.0.0-alpha',findings,summary:{nodes:g.nodes.length,edges:g.edges.length,findings:findings.length},limitations:['Audita solo la información presente en el grafo.','No consulta fuentes externas ni descubre hechos por sí solo.','No puede certificar verdad ni independencia causal.']};
  }
  const api = Object.freeze({ version:VERSION, empty:()=>({schema:'ODISEO_MIRROR_GRAPH_1',nodes:[],edges:[],learnings:[]}),
    validate:cloneGraph, addNode, addEdge, analyze, recordOutcome, learningSummary, recommendStrategy, proposeQuestions, auditSelf,
    describe:()=>({name:'Odiseo Espejo Bidireccional',version:VERSION,capabilities:['grafo de información explícita','recorrido 0→∞ conceptual mediante expansión','retorno inverso hacia antecedentes','detección de contradicciones registradas','memoria de resultados evaluados con evidencia','presupuesto de exploración','generación heurística de preguntas abiertas','auditoría de puntos ciegos del grafo'], limitations:['no contiene toda la información del universo','no verifica automáticamente la verdad externa de los datos','no aprende de forma autónoma sin evaluación registrada','no es conciencia ni inteligencia general']}) });
  global.OdiseoMirror = api;
})(window);
