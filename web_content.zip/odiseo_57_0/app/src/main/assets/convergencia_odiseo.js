/* ODISEO 50.6 — Motor de Convergencia Autorregulada.
 * Objetivo x en (0,1). La velocidad alpha depende del estado y_n.
 * Regla: alpha_n = x + (1-x)y_n; y_{n+1}=y_n+alpha_n(x-y_n).
 * Prueba: e_{n+1}=e_n(1-alpha_n), 0<alpha_n<1 y e_n>0; por tanto y_n crece y converge a x.
 * La contracción asintótica tiende a (1-x)^2. No se afirma optimalidad global.
 */
(function(global){'use strict';
 const VERSION='1.0.0-convergencia-autorregulada', MAX_STEPS=10000, MAX_HISTORY=100;
 function validX(x){const n=Number(x);if(!Number.isFinite(n)||n<=0||n>=1)throw Error('El objetivo x debe estar estrictamente entre 0 y 1.');return n;}
 function step(x,y){x=validX(x);y=Number(y);if(!Number.isFinite(y)||y<0||y>x+1e-14)throw Error('El estado y debe pertenecer al intervalo [0,x].');const alpha=x+(1-x)*y;const next=y+alpha*(x-y);return {x,y,alpha,next,error:x-next,contraction:1-alpha};}
 function run(xValue,stepsValue,options){const x=validX(xValue),steps=Number(stepsValue===undefined?30:stepsValue),o=options||{};if(!Number.isInteger(steps)||steps<0||steps>MAX_STEPS)throw Error('Las iteraciones deben estar entre 0 y '+MAX_STEPS+'.');let y=Number(o.start===undefined?0:o.start);if(!Number.isFinite(y)||y<0||y>x)throw Error('El inicio debe pertenecer a [0,x].');const initial=y,trace=[{n:0,y,error:x-y,alpha:null}];let monotone=true,inside=true;for(let i=1;i<=steps;i++){const s=step(x,y);if(s.next+Number.EPSILON*Math.max(1,Math.abs(y))<y)monotone=false;if(s.next<-1e-14||s.next>x+1e-14)inside=false;y=s.next;trace.push({n:i,y,error:x-y,alpha:s.alpha,contraction:s.contraction});}
  const fixedFactor=1-x,adaptiveFactor=1-x+(0); // overwritten below with exact asymptotic factor
  const asymptoticFactor=(1-x)*(1-x),fixedY=x-(x-initial)*Math.pow(1-x,steps),adaptiveError=x-y,fixedError=x-fixedY;
  const result={engine:'ODISEO · CONVERGENCIA AUTORREGULADA',version:VERSION,x,initial,iterations:steps,final:y,error:adaptiveError,trace,properties:{insideInterval:inside,monotoneNondecreasing:monotone,convergesToX:true,proof:'e[n+1]=e[n]*(1-alpha[n]); alpha[n]=x+(1-x)y[n]. Como 0<x<1 y 0<=y[n]<x, se cumple 0<alpha[n]<=2x-x^2<1. El error permanece positivo y decrece. Además alpha[n]>=x, así e[n]<=e[0]*(1-x)^n -> 0; por tanto y[n]->x.',asymptoticContractionFactor:asymptoticFactor},comparison:{fixedRate:x,fixedFinal:fixedY,fixedError,adaptiveError,adaptiveBetterAtThisIteration:adaptiveError<fixedError,adaptiveAsymptoticFactor:asymptoticFactor,fixedAsymptoticFactor:fixedFactor},epistemicStatus:'REGLA MATEMÁTICA Y CONVERGENCIA DEMOSTRADA PARA 0<x<1 Y 0<=y0<=x. No se afirma optimalidad global ni infinito computacional.'};
  let h=2166136261,raw=JSON.stringify({x,initial,iterations:steps,final:y});for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619);}result.fingerprint=(h>>>0).toString(16).padStart(8,'0');return result;
 }
 function validateHistory(h){if(!Array.isArray(h))throw Error('Historial de convergencia inválido.');return h.slice(-MAX_HISTORY).map(r=>{if(!r||typeof r.id!=='string'||typeof r.fingerprint!=='string'||!Number.isFinite(r.x)||r.x<=0||r.x>=1)throw Error('Registro de convergencia corrupto.');return r;});}
 global.OdiseoConvergence=Object.freeze({version:VERSION,step,run,validateHistory,describe:()=>({version:VERSION,rule:'alpha[n]=x+(1-x)y[n]; y[n+1]=y[n]+alpha[n](x-y[n])',claim:'Converge a x para 0<x<1 y 0<=y0<=x; la contracción asintótica es (1-x)^2. No es una prueba de optimalidad global.'})});
})(window);
