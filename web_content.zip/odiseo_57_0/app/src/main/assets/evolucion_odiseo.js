/* ODISEO 50.4 — Motor de Evolución de Acertijos.
 * Convierte patrones aritméticos candidatos en nuevas preguntas, nuevas partículas
 * y nuevas colisiones. Recursión acotada, trazabilidad y deduplicación.
 * No atribuye semántica demostrada a las coincidencias numéricas.
 */
(function(global){'use strict';
 const VERSION='1.0.0-evolucion-acertijos';
 const MAX_ROUNDS=3, MAX_GENERATED=8, MAX_PER_ROUND=4, MAX_HISTORY=100;
 function safeInt(v,min,max,label){const n=Number(v);if(!Number.isSafeInteger(n)||n<min||n>max)throw Error(label+' debe estar entre '+min+' y '+max+'.');return n;}
 function fingerprint(value){const s=String(value);let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
 function questionFor(pattern){const raw=String(pattern.value),digits=raw.replace('-','').length;let descriptor;if(digits<=30)descriptor='el valor '+raw;else {const n=BigInt(raw);descriptor='un valor de '+digits+' cifras cuyo residuo módulo 97 es '+((n%97n+97n)%97n).toString();}
  return '¿Qué relación explica que '+descriptor+' aparezca '+pattern.count+' veces en colisiones distintas?';
 }
 function extractPatterns(result){const repeated=(result.collisions&&result.collisions.repeatedValues)||[];return repeated.slice().sort((a,b)=>b.count-a.count||String(a.value).length-String(b.value).length||String(a.value).localeCompare(String(b.value))).slice(0,MAX_PER_ROUND);}
 function validateHistory(history){if(!Array.isArray(history))throw Error('Historial evolutivo inválido.');return history.slice(-MAX_HISTORY).map(x=>{if(!x||typeof x.id!=='string'||typeof x.seed!=='string'||!Array.isArray(x.generations)||!Number.isInteger(x.rounds))throw Error('Registro evolutivo corrupto.');return x;});}
 function evolve(seed,graph,options){if(typeof seed!=='string'||!seed.trim())throw Error('Escribe un acertijo inicial.');if(!global.OdiseoRiddle||!global.OdiseoMirror)throw Error('Falta el Motor de Acertijos o el Espejo.');const opts=options||{},roundLimit=safeInt(opts.rounds===undefined?2:opts.rounds,1,MAX_ROUNDS,'Rondas'),generatedLimit=safeInt(opts.maxGenerated===undefined?6:opts.maxGenerated,1,MAX_GENERATED,'Nuevos acertijos');
  let g=global.OdiseoMirror.validate(graph||global.OdiseoMirror.empty()),initial=global.OdiseoRiddle.solve(seed,g);g=initial.mirror.graph;
  const generations=[{round:0,parent:null,kind:'seed',question:seed,rootId:initial.mirror.rootId,particles:initial.particles.length,collisions:initial.collisions.collisions,patterns:extractPatterns(initial)}];
  const seen=new Set([seed.normalize('NFC').toLocaleLowerCase()]);let frontier=[{rootId:initial.mirror.rootId,result:initial}],created=0,stopped='ROUND_LIMIT';
  for(let round=1;round<=roundLimit&&created<generatedLimit;round++){
   const next=[];
   for(const parent of frontier){if(created>=generatedLimit)break;let patterns=extractPatterns(parent.result);if(!patterns.length){patterns=[{value:'0',count:parent.result.collisions.zeroResults||0}];if(!patterns[0].count)patterns[0]={value:String(parent.result.particles.length),count:1};}
    for(const pattern of patterns){if(created>=generatedLimit)break;const question=questionFor(pattern),key=question.normalize('NFC').toLocaleLowerCase();if(seen.has(key))continue;seen.add(key);
     let child;try{child=global.OdiseoRiddle.solve(question,g);}catch(error){generations.push({round,parent:parent.rootId,kind:'generation_rejected',question,reason:error.message});continue;}
     g=child.mirror.graph;g=global.OdiseoMirror.addEdge(g,{from:parent.rootId,to:child.mirror.rootId,relation:'derives',evidence:'Pregunta generada automáticamente a partir de un patrón de colisión candidato; no constituye una explicación demostrada.'}).graph;
     const item={round,parent:parent.rootId,kind:'derived_question',question,rootId:child.mirror.rootId,particles:child.particles.length,collisions:child.collisions.collisions,pattern:{value:String(pattern.value),count:pattern.count},patterns:extractPatterns(child)};
     generations.push(item);next.push({rootId:child.mirror.rootId,result:child});created++;
    }
   }
   if(!next.length){stopped='NO_NEW_DISTINCT_QUESTIONS';break;}frontier=next;
  }
  if(created>=generatedLimit)stopped='GENERATION_BUDGET_REACHED';
  const allPatterns=generations.filter(x=>x.kind==='derived_question').map(x=>x.pattern);
  const result={engine:'ODISEO · EVOLUCIÓN DEL ESPEJO',version:VERSION,seed,rounds:Math.max(0,...generations.map(x=>x.round)),generatedQuestions:created,generations,graph:g,stopReason:stopped,principle:'Un patrón candidato genera una pregunta; la pregunta genera partículas; las partículas colisionan; los resultados pueden generar nuevas preguntas.',epistemicStatus:'EXPLORACIÓN ACOTADA. Las coincidencias aritméticas son disparadores de preguntas, no significados ni verdades demostradas.',limits:{maxRounds:MAX_ROUNDS,maxGenerated:MAX_GENERATED,maxPerRound:MAX_PER_ROUND},fingerprint:fingerprint(seed+'|'+JSON.stringify(generations.map(x=>({round:x.round,kind:x.kind,question:x.question,pattern:x.pattern,particles:x.particles,collisions:x.collisions,reason:x.reason}))))};
  return result;
 }
 global.OdiseoEvolution=Object.freeze({version:VERSION,evolve,validateHistory,describe:()=>({version:VERSION,process:'patrón → pregunta nueva → partículas positivas → colisiones → siguiente patrón',limits:{maxRounds:MAX_ROUNDS,maxGenerated:MAX_GENERATED,maxPerRound:MAX_PER_ROUND},claim:'Generación recursiva acotada de acertijos desde patrones numéricos candidatos; no es comprensión semántica ni aprendizaje autónomo.'})});
})(window);
