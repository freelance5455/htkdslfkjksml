'use strict';
// Odiseo 55.0 — benchmark etiquetado reproducible del detector adaptativo.
// Corpus sintético de control; no representa lenguaje real ni mide comprensión semántica general.
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const file=path.join(__dirname,'app/src/main/assets/patron_adaptativo_odiseo.js');
function load(storage){const ctx={Date,Math,JSON,Array,Object,String,Number,Error,Set,Map,localStorage:storage};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(file,'utf8'),ctx);return ctx.OdiseoAdaptivePattern;}
const store=new Map(),A=load({getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)});
const cases=[
 {id:'Q01',q:'Demuestra formalmente esta identidad algebraica.',a:'',want:['proof']},
 {id:'Q02',q:'Verifica con una prueba reproducible el resultado.',a:'',want:['proof']},
 {id:'Q03',q:'Audita la evidencia y compara ambas versiones.',a:'',want:['proof']},
 {id:'Q04',q:'Aunque la premisa contradice el resultado, revisa el argumento.',a:'',want:['contradiction']},
 {id:'Q05',q:'La conclusión es inconsistente con el dato anterior; analízalo.',a:'',want:['contradiction']},
 {id:'Q06',q:'No sabemos si esta hipótesis es posible; examínala.',a:'',want:['uncertainty']},
 {id:'Q07',q:'Descompón la arquitectura completa y optimiza todos los módulos.',a:'',want:['complexity']},
 {id:'Q08',q:'Continúa como antes con el proyecto.',a:'',want:['missing_context']},
 {id:'Q09',q:'¿Puedes hacer eso mismo?',a:'',want:['missing_context']},
 {id:'Q10',q:'Protege esta contraseña privada y no la publiques.',a:'',want:['safety']},
 {id:'A01',q:'',a:'Está garantizado que el resultado es correcto.',want:['unsupported_answer']},
 {id:'A02',q:'',a:'Esto siempre funciona y nunca falla.',want:['unsupported_answer']},
 {id:'A03',q:'',a:'No responde a la segunda parte de la solicitud.',want:['incomplete_answer']},
 {id:'A04',q:'',a:'Falta el cálculo solicitado y no se incluye la fuente.',want:['incomplete_answer']},
 {id:'A05',q:'',a:'Por un lado el valor aumenta; por otro lado disminuye.',want:['inconsistency_answer']},
 {id:'N01',q:'Calcula 2 más 2 y responde solo con el número.',a:'4',want:[]},
 {id:'N02',q:'Explica qué es la función de algo en este programa.',a:'La función transforma la entrada en una salida.',want:[]},
 {id:'N03',q:'Compara dos métodos de búsqueda de forma neutral.',a:'El primero recorre una lista; el segundo usa un índice.',want:[]},
 {id:'N04',q:'¿Qué significa la palabra quizá en una frase?',a:'Expresa posibilidad o duda.',want:[]},
 {id:'N05',q:'Describe el sistema y todos sus componentes principales.',a:'El sistema contiene tres componentes descritos a continuación.',want:[]},
 {id:'N06',q:'¿Cómo funciona una contraseña de un solo uso?',a:'Es un código temporal de autenticación.',want:[]},
 {id:'N07',q:'Explica qué significa la expresión “no se ha”.',a:'Es una construcción verbal en español.',want:[]},
 {id:'N08',q:'Enumera las diferencias entre dos versiones.',a:'La versión nueva incorpora un módulo adicional.',want:[]},
 {id:'N09',q:'¿Puedes explicar el método de suma?',a:'Se agregan los valores numéricos.',want:[]},
 {id:'N10',q:'Resume el texto en una frase.',a:'El texto describe un proceso de cálculo.',want:[]},
 {id:'Q11',q:'Necesito algo diferente para este caso concreto.',a:'',want:['ambiguity']},
 {id:'Q12',q:'¿Y eso?',a:'',want:['ambiguity','short_query']},
 {id:'A06',q:'Explica con detalle la razón matemática.',a:'Sí.',want:['possibly_shallow']}
];
const totals={tp:0,fp:0,fn:0,tn:0},per={};const rows=[];
const allIds=[...A.issueTypes,'short_query','possibly_shallow'];
for(const id of allIds)per[id]={tp:0,fp:0,fn:0,tn:0};
for(const c of cases){const r=A.inspect({question:c.q,answer:c.a});const got=[...r.plan.questionIssues,...r.plan.answerIssues].map(x=>x.id);let fp=[],fn=[];for(const id of allIds){const yes=c.want.includes(id),pred=got.includes(id);if(!per[id])per[id]={tp:0,fp:0,fn:0,tn:0};if(yes&&pred){per[id].tp++;totals.tp++;}else if(!yes&&pred){per[id].fp++;totals.fp++;fp.push(id);}else if(yes&&!pred){per[id].fn++;totals.fn++;fn.push(id);}else{per[id].tn++;totals.tn++;}}rows.push({id:c.id,expected:c.want,detected:got,falsePositives:fp,falseNegatives:fn,mode:r.plan.mode});}
const precision=totals.tp+totals.fp?totals.tp/(totals.tp+totals.fp):1;
const recall=totals.tp+totals.fn?totals.tp/(totals.tp+totals.fn):1;
const report={benchmark:'ODISEO_ADAPTIVE_SYNTHETIC_2_CONSERVATIVE',engineVersion:A.version,corpus:{cases:cases.length,positiveLabels:cases.reduce((n,c)=>n+c.want.length,0),negativeControls:cases.filter(c=>!c.want.length).length,scope:'synthetic deterministic smoke benchmark; not semantic/generalization evidence'},micro:{...totals,precision:Number(precision.toFixed(4)),recall:Number(recall.toFixed(4)),f1:Number((precision+recall?2*precision*recall/(precision+recall):0).toFixed(4))},perIssue:per,rows,limitations:['Las etiquetas son juicios manuales sobre casos sintéticos.','Los controles negativos no representan la distribución real de consultas.','Las métricas no prueban comprensión semántica, factualidad ni calidad de rutas.','No ajustar umbrales con este corpus; reservar corpus ciego independiente.']};
assert.strictEqual(rows.length,cases.length);assert(report.micro.precision>=0&&report.micro.precision<=1);assert(report.micro.recall>=0&&report.micro.recall<=1);
const out=path.join(__dirname,'build-output','evaluacion_adaptativa_55_0.json');fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
// Persistencia fallida: el motor debe informar explícitamente que no guardó.
const F=load({getItem:()=>null,setItem:()=>{throw Error('quota exceeded')}});const failed=F.inspect({question:'Demuestra el resultado con evidencia suficiente.'});assert.strictEqual(failed.persistence.persisted,false);assert.match(failed.persistence.reason,/quota exceeded/);
console.log(JSON.stringify({benchmark:report.benchmark,cases:cases.length,micro:report.micro,perIssue:per,report:out,persistenceFailureReported:true},null,2));
