# Auditoría Odiseo 55.1-alpha — despacho del cerebro cognitivo

**Fecha:** 2026-11-12  
**Base:** `55.0-alpha-functional-reconstruction`  
**Versión estable preservada:** `53.2`  
**Rama:** `55.1-alpha-cognitive-tool-dispatch`

## Cambio implementado

El ciclo cognitivo ya no se limita a catalogar candidatos. `OdiseoCognitiveBrain.begin` es asíncrono y espera el resultado de las invocaciones allowlisted mediante `OdiseoCapabilityRegistry.invoke`. Se conectaron: Sherlock (`sherlock.investigate`), Penélope (`penelope.unweave`), Judas Tadeo (`judas.reframe`), ESPEJO (`espejo.questions`, `espejo.audit`) y núcleo unificado (`core.audit`). El núcleo simbólico `OdiseoReasoningCore.analyze` conserva su ruta directa. El asistente espera ahora `await brain.begin(raw)` antes de construir la solicitud al modelo local.

## Controles de entrada y trazabilidad

- Sherlock solo recibe dos o más registros reales recuperados de memoria, conservando ID, texto, tipo y fuente; si faltan, devuelve `NEEDS_INPUT`.
- Penélope solo recibe AST JSON explícito del usuario; no se construye un AST artificial.
- Judas Tadeo recibe la entrada original como descripción del bloqueo y lista vacía de premisas; no se eleva el texto del usuario a hecho verificado.
- ESPEJO usa el grafo persistido; si no existe, consulta el constructor `empty()` de la API, sin inventar nodos ni relaciones.
- La traza almacena capacidades, estados, duración, resumen, y recuentos de `EXECUTED`, `NEEDS_INPUT` y `ERROR`.
- `AVAILABLE`, `NOT_INTEGRATED`, `UNAVAILABLE` y `NEEDS_INPUT` no se confunden con ejecución.

## Resultados reproducidos

- `node --test tests_*.js`: **48/48 suites PASS**.
- Pruebas específicas de despacho: **21/21 PASS**, incluyendo `EXECUTED`, `NEEDS_INPUT`, `UNAVAILABLE` y `ERROR`.
- Integración con módulos reales cargados desde assets de producción en Node VM: **8/8 PASS**.
- Sintaxis de assets JavaScript: **35/35 PASS**.
- JSON: **36/36 PASS**.
- Android build metadata: **8/8 PASS**.
- AndroidManifest XML: **PASS**.

## Límites y pendientes

- Node VM no equivale a Android WebView real.
- TIC y Laboratorio de loterías siguen seleccionándose como candidatos cuando corresponde, pero no se invocan desde este ciclo: quedan `NOT_INTEGRATED`. OIE tampoco tiene todavía un contrato de despacho en este orquestador.
- La auditoría de salida es heurística; no demuestra verdad factual.
- No hay entrenamiento de pesos ni aprendizaje autónomo.
- En este entorno no hay Gradle ni Android SDK. APK no compilada ni instalada; AAR LiteRT-LM real, modelo `.litertlm` e inferencia offline física no probados.

**Dictamen:** 55.1-alpha demuestra despacho local real de cinco capacidades allowlisted y el núcleo simbólico en pruebas Node. Es un avance de integración de código, no una APK operativa certificada ni una IA neuronal general. La versión estable 53.2 permanece intacta.
