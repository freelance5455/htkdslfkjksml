# Auditoría Odiseo 52.9 — Evaluación etiquetada del patrón adaptativo

## Objetivo
Cerrar una carencia declarada en 52.8: medir, antes de tocar umbrales, el comportamiento del detector adaptativo con casos etiquetados y negativos de control. Corregir además la discrepancia de versiones del estado persistente.

## Cambios
- Se añade `tests_odiseo_evaluacion_adaptativa.js`.
- Se incorpora un corpus sintético determinista de 28 casos: 19 etiquetas positivas distribuidas por categorías y 10 controles negativos, más casos de control específicos para ambigüedad, consulta breve y respuesta superficial.
- Se calcula matriz agregada TP/FP/FN/TN, precisión, recall y F1, además de resultados por categoría.
- Se guarda `build-output/evaluacion_adaptativa_52_9.json` para inspección y reproducción.
- Se prueba explícitamente que una excepción de `localStorage` se devuelve como `persistence.persisted=false`; no se presenta el guardado fallido como éxito.
- Se sincronizan `project_version`, `version_actual` y `software_version` en `ESTADO_ODISEO.json`; se registra la entrada 52.9 en `DIARIO_ODISEO.json`.
- No se modifican reglas, umbrales, rutas ni código del motor adaptativo; el feedback sigue sin poder entrenar ni reescribir el sistema.

## Resultado reproducido
Corpus sintético `ODISEO_ADAPTIVE_SYNTHETIC_1`:
- 28 casos; 19 etiquetas positivas.
- TP=19, FP=28, FN=0, TN=289.
- Precisión micro: 0,4043.
- Recall micro: 1,0000.
- F1 micro: 0,5758.
- Falsos positivos destacados: `possibly_shallow` (15), `short_query` (5), `ambiguity` (4), `complexity` (2), `safety` (1), `proof` (1).
- Prueba de persistencia fallida: detectada y comunicada correctamente.

## Interpretación y límites
El recall del 100% solo describe este pequeño corpus sintético y no demuestra generalización. La precisión del 40,43% revela una tasa de falsas alarmas demasiado alta para activar rutas automáticamente. Las heurísticas de respuesta corta y coincidencia léxica requieren revisión. No se ajustan umbrales con los mismos datos que se usan para evaluar: hace falta un corpus ciego separado, más amplio y representativo, con anotación independiente y criterios fijados antes de probar.

El benchmark no mide comprensión semántica, factualidad, calidad de respuesta, seguridad global ni rendimiento en Android. Las rutas siguen siendo recomendaciones, no llamadas automáticas a todos los motores.

## Regresión
- 25/25 baterías `tests_*.js`: superadas.
- `node --check` en todos los módulos JavaScript: superado.
- `py_compile` de generador, guardado y pruebas: superado.
- `python probar_generador.py`: preparación superada.
- APK: no compilada ni instalada.

## Veredicto
52.9 es un hito de instrumentación y evaluación, no una mejora demostrada de precisión del detector. La evidencia actual aconseja mantener los umbrales y no automatizar el enrutamiento hasta reducir falsos positivos en un conjunto de desarrollo y superar después un conjunto ciego independiente.
