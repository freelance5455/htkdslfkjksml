#!/usr/bin/env python3
"""ODISEO APK Builder 1.0 - stage an algorithm module and build the Android APK.
Requires JDK 17, Gradle 8.13 and Android SDK 35 (or use the GitHub Actions workflow).
"""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'app' / 'src' / 'main' / 'assets'
APK = ROOT / 'app' / 'build' / 'outputs' / 'apk' / 'debug' / 'app-debug.apk'

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description='Incorpora un algoritmo JavaScript y genera la APK de Odiseo.')
    p.add_argument('--algoritmo', help='Ruta a algoritmo_odiseo.js (API global OdiseoAlgorithm).')
    p.add_argument('--nombre', default='Odiseo', help='Nombre descriptivo del paquete de salida.')
    p.add_argument('--solo-preparar', action='store_true', help='Prepara y valida el proyecto sin compilar.')
    p.add_argument('--gradle', default='gradle', help='Ejecutable Gradle; por defecto gradle del PATH.')
    args=p.parse_args()
    if args.algoritmo:
        src=Path(args.algoritmo).expanduser().resolve()
        if not src.is_file(): p.error('No existe el archivo de algoritmo: '+str(src))
        code=src.read_text(encoding='utf-8')
        if 'OdiseoAlgorithm' not in code: p.error('El módulo debe exponer window.OdiseoAlgorithm.')
        if len(code.encode('utf-8')) > 2_000_000: p.error('El módulo supera el límite de 2 MB.')
        (ASSETS/'algoritmo_odiseo.js').write_text(code,encoding='utf-8')
    module=ASSETS/'algoritmo_odiseo.js'
    mirror=ASSETS/'espejo_odiseo.js'
    accelerator=ASSETS/'acelerador_odiseo.js'
    riddle=ASSETS/'acertijo_odiseo.js'
    evolution=ASSETS/'evolucion_odiseo.js'
    interaction=ASSETS/'interaccion_odiseo.js'
    convergence=ASSETS/'convergencia_odiseo.js'
    moving=ASSETS/'objetivo_evolutivo_odiseo.js'
    sensitivity=ASSETS/'sensibilidad_odiseo.js'
    energy=ASSETS/'energia_odiseo.js'
    research=ASSETS/'investigacion_odiseo.js'
    creator=ASSETS/'creador_autonomo_odiseo.js'
    penelope=ASSETS/'penelope_odiseo.js'
    growth=ASSETS/'crecimiento_exponencial_odiseo.js'
    duet=ASSETS/'duelo_odiseo_penelope.js'
    independence=ASSETS/'independencia_odiseo_penelope.js'
    integrator=ASSETS/'integrador_odiseo_penelope.js'
    judas=ASSETS/'judas_tadeo_odiseo.js'
    lottery=ASSETS/'loterias_odiseo.js'
    sherlock=ASSETS/'sherlock_odiseo.js'
    evidence=ASSETS/'integrador_evidencias_odiseo.js'
    integrated=ASSETS/'ciclo_integrado_odiseo.js'
    communication=ASSETS/'auditor_comunicacion_odiseo.js'
    unified=ASSETS/'nucleo_unificado_odiseo.js'
    tic=ASSETS/'tic_odiseo.js'
    tic_inference=ASSETS/'tic_inferencia_odiseo.js'
    reasoning=ASSETS/'nucleo_razonamiento_local_odiseo.js'
    semantic_memory=ASSETS/'memoria_semantica_local_odiseo.js'
    local_assistant=ASSETS/'asistente_local_odiseo.js'
    inactivity_sources = {
        'policy': ROOT/'app/src/main/java/org/odiseo/app/InactivityPolicy.java',
        'store': ROOT/'app/src/main/java/org/odiseo/app/InactivityStore.java',
        'receiver': ROOT/'app/src/main/java/org/odiseo/app/InactivityReceiver.java',
        'boot_receiver': ROOT/'app/src/main/java/org/odiseo/app/InactivityBootReceiver.java',
    }
    for key, path in inactivity_sources.items():
        if not path.is_file(): p.error('Falta el componente nativo del detector de inactividad: '+str(path.relative_to(ROOT)))
    manifest_path = ROOT/'app/src/main/AndroidManifest.xml'
    manifest_text = manifest_path.read_text(encoding='utf-8')
    if 'InactivityReceiver' not in manifest_text or 'InactivityBootReceiver' not in manifest_text or 'RECEIVE_BOOT_COMPLETED' not in manifest_text:
        p.error('El AndroidManifest no declara los receptores/permisos del detector de inactividad.')
    inactivity_html = (ASSETS/'index.html').read_text(encoding='utf-8')
    for token in ['ODISEO_INACTIVITY_AUDIT_1', 'odiseoHandleNativeInactivity', 'persistInactivityAudit', 'inactivityRecoveryPanel']:
        if token not in inactivity_html: p.error('Falta la integración de recuperación Android en index.html: '+token)
    if not module.is_file(): p.error('Falta app/src/main/assets/algoritmo_odiseo.js')
    if not mirror.is_file() or 'OdiseoMirror' not in mirror.read_text(encoding='utf-8'): p.error('Falta el motor Espejo Bidireccional (OdiseoMirror).')
    if not accelerator.is_file() or 'OdiseoAccelerator' not in accelerator.read_text(encoding='utf-8'): p.error('Falta el Acelerador Matemático (OdiseoAccelerator).')
    if not riddle.is_file() or 'OdiseoRiddle' not in riddle.read_text(encoding='utf-8'): p.error('Falta el Motor de Acertijos del Espejo (OdiseoRiddle).')
    if not evolution.is_file() or 'OdiseoEvolution' not in evolution.read_text(encoding='utf-8'): p.error('Falta el Motor de Evolución del Espejo (OdiseoEvolution).')
    if not interaction.is_file() or 'OdiseoInteraction' not in interaction.read_text(encoding='utf-8'): p.error('Falta el Motor de Interacción Finita (OdiseoInteraction).')
    if not convergence.is_file() or 'OdiseoConvergence' not in convergence.read_text(encoding='utf-8'): p.error('Falta el Motor de Convergencia Autorregulada (OdiseoConvergence).')
    if not moving.is_file() or 'OdiseoMovingTarget' not in moving.read_text(encoding='utf-8'): p.error('Falta el Motor de Objetivo Evolutivo (OdiseoMovingTarget).')
    if not sensitivity.is_file() or 'OdiseoSensitivity' not in sensitivity.read_text(encoding='utf-8'): p.error('Falta el Motor de Sensibilidad (OdiseoSensitivity).')
    if not energy.is_file() or 'OdiseoEnergy' not in energy.read_text(encoding='utf-8'): p.error('Falta el Motor de Energía (OdiseoEnergy).')
    if not research.is_file() or 'OdiseoResearch' not in research.read_text(encoding='utf-8'): p.error('Falta el Ciclo de Investigación A/B/C/H (OdiseoResearch).')
    if not creator.is_file() or 'OdiseoCreator' not in creator.read_text(encoding='utf-8') or 'dependencies:[]' not in creator.read_text(encoding='utf-8'): p.error('Falta el Núcleo Creador Autónomo independiente.')
    if not penelope.is_file() or 'OdiseoPenelope' not in penelope.read_text(encoding='utf-8'): p.error('Falta el Motor Penélope.')
    if not growth.is_file() or 'OdiseoGrowth' not in growth.read_text(encoding='utf-8'): p.error('Falta el Motor de Crecimiento Exponencial.')
    if not duet.is_file() or 'OdiseoDuet' not in duet.read_text(encoding='utf-8'): p.error('Falta el motor de acoplamiento recíproco Odiseo-Penélope.')
    if not independence.is_file() or 'OdiseoIndependence' not in independence.read_text(encoding='utf-8'): p.error('Falta la prueba de independencia Odiseo-Penélope.')
    if 'runIndependenceTest' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta la interfaz Android de la prueba de independencia.')
    if not integrator.is_file() or 'OdiseoIntegrator' not in integrator.read_text(encoding='utf-8'): p.error('Falta el Motor Integrador E (OdiseoIntegrator).')
    if 'runIntegrator' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta la interfaz Android del Motor Integrador E.')
    if not judas.is_file() or 'OdiseoJudasTadeo' not in judas.read_text(encoding='utf-8'): p.error('Falta el motor D Judas Tadeo.')
    if not lottery.is_file() or 'OdiseoLotteryLab' not in lottery.read_text(encoding='utf-8'): p.error('Falta el Laboratorio de Loterías.')
    if 'runLotteryStudy' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta la interfaz del Laboratorio de Loterías.')
    if not sherlock.is_file() or 'OdiseoSherlock' not in sherlock.read_text(encoding='utf-8'): p.error('Falta el motor Sherlock de rastros mínimos.')
    if 'runSherlock' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta la interfaz Android de Sherlock.')
    if not evidence.is_file() or 'OdiseoEvidenceIntegrator' not in evidence.read_text(encoding='utf-8'): p.error('Falta el Integrador de Evidencias OIE.')
    if not integrated.is_file() or 'OdiseoIntegratedCycle' not in integrated.read_text(encoding='utf-8'): p.error('Falta el orquestador integrado A/B/C/H.')
    if not communication.is_file() or 'OdiseoCommunicationAuditor' not in communication.read_text(encoding='utf-8'): p.error('Falta el Auditor de Comunicación 53.0.')
    if 'auditor_comunicacion_odiseo.js' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta cargar el Auditor de Comunicación en Android.')
    if not unified.is_file() or 'OdiseoUnifiedCore' not in unified.read_text(encoding='utf-8'): p.error('Falta el núcleo unificado 52.6.')
    if not tic.is_file() or 'OdiseoTIC' not in tic.read_text(encoding='utf-8') or 'tic_odiseo.js' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta cargar el módulo TIC 1.1.')
    if not tic_inference.is_file() or 'OdiseoTICInference' not in tic_inference.read_text(encoding='utf-8') or 'tic_inferencia_odiseo.js' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta cargar el módulo inferencial TIC 1.2-alpha.')
    if not reasoning.is_file() or 'OdiseoReasoningCore' not in reasoning.read_text(encoding='utf-8') or 'nucleo_razonamiento_local_odiseo.js' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta cargar el núcleo local de razonamiento.')
    if not semantic_memory.is_file() or 'OdiseoSemanticMemory' not in semantic_memory.read_text(encoding='utf-8') or 'memoria_semantica_local_odiseo.js' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta cargar la memoria semántica local.')
    if not local_assistant.is_file() or 'semanticMemory' not in local_assistant.read_text(encoding='utf-8'): p.error('Falta la integración de memoria semántica en el chat local.')
    creative=ASSETS/'creativestudio_odiseo.js'
    if not creative.is_file() or 'OdiseoCreativeStudio' not in creative.read_text(encoding='utf-8') or 'creativestudio_odiseo.js' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta el Estudio Creativo Odiseo 56.')
    if 'requestHybrid' not in (ROOT/'app/src/main/java/org/odiseo/app/MainActivity.java').read_text(encoding='utf-8') or 'android.permission.INTERNET' not in manifest_text: p.error('Falta el puente híbrido HTTPS Android.')
    if 'semanticMemoryExport' not in (ASSETS/'index.html').read_text(encoding='utf-8') or 'semanticMemoryImport' not in (ASSETS/'index.html').read_text(encoding='utf-8'): p.error('Falta la interfaz local de copia de seguridad de memoria semántica.')
    adaptive=ASSETS/'patron_adaptativo_odiseo.js'
    if not adaptive.is_file() or 'OdiseoAdaptivePattern' not in adaptive.read_text(encoding='utf-8'): p.error('Falta el patrón adaptativo 52.8.')
    library=ASSETS/'biblioteca_activa_odiseo.js'
    if not library.is_file() or 'OdiseoActiveLibrary' not in library.read_text(encoding='utf-8'): p.error('Falta la Biblioteca Activa 52.7.')
    html=(ASSETS/'index.html').read_text(encoding='utf-8')
    if 'runIntegratedCycleUI' not in html or 'ciclo_integrado_odiseo.js' not in html or 'nucleo_unificado_odiseo.js' not in html or 'runUnifiedCoreUI' not in html or 'integrador_evidencias_odiseo.js' not in html or 'biblioteca_activa_odiseo.js' not in html or 'patron_adaptativo_odiseo.js' not in html or 'runAdaptivePatternUI' not in html: p.error('Falta la interfaz o carga de módulos del ciclo integrado 52.5.')
    if 'android.permission.RECORD_AUDIO' not in manifest_text or 'SpeechRecognizer' not in (ROOT/'app/src/main/java/org/odiseo/app/MainActivity.java').read_text(encoding='utf-8') or 'TextToSpeech' not in (ROOT/'app/src/main/java/org/odiseo/app/MainActivity.java').read_text(encoding='utf-8'):
        p.error('Falta la integración nativa de voz (micrófono/TTS).')
    code=module.read_text(encoding='utf-8')
    if 'OdiseoAlgorithm' not in code: p.error('El módulo no declara OdiseoAlgorithm.')
    state_path=ROOT/'ESTADO_ODISEO.json'
    state=json.loads(state_path.read_text(encoding='utf-8'))
    project_version=state.get('project_version')
    if not project_version: p.error('ESTADO_ODISEO.json no declara project_version.')
    report={'builder':'ODISEO APK Builder 1.1','project':'Odiseo','project_version':project_version,'module':str(module.relative_to(ROOT)),'module_sha256':sha256(module),'mirror_module':'app/src/main/assets/espejo_odiseo.js','mirror_sha256':sha256(mirror),'accelerator_module':'app/src/main/assets/acelerador_odiseo.js','accelerator_sha256':sha256(accelerator),'riddle_module':'app/src/main/assets/acertijo_odiseo.js','riddle_sha256':sha256(riddle),'evolution_module':'app/src/main/assets/evolucion_odiseo.js','evolution_sha256':sha256(evolution),'interaction_module':'app/src/main/assets/interaccion_odiseo.js','interaction_sha256':sha256(interaction),'convergence_module':'app/src/main/assets/convergencia_odiseo.js','convergence_sha256':sha256(convergence),'moving_target_module':'app/src/main/assets/objetivo_evolutivo_odiseo.js','moving_target_sha256':sha256(moving),'sensitivity_module':'app/src/main/assets/sensibilidad_odiseo.js','sensitivity_sha256':sha256(sensitivity),'energy_module':'app/src/main/assets/energia_odiseo.js','energy_sha256':sha256(energy),'research_module':'app/src/main/assets/investigacion_odiseo.js','research_sha256':sha256(research),'creator_module':'app/src/main/assets/creador_autonomo_odiseo.js','creator_sha256':sha256(creator),'penelope_module':'app/src/main/assets/penelope_odiseo.js','penelope_sha256':sha256(penelope),'growth_module':'app/src/main/assets/crecimiento_exponencial_odiseo.js','growth_sha256':sha256(growth),'duet_module':'app/src/main/assets/duelo_odiseo_penelope.js','duet_sha256':sha256(duet),'independence_module':'app/src/main/assets/independencia_odiseo_penelope.js','independence_sha256':sha256(independence),'integrator_module':'app/src/main/assets/integrador_odiseo_penelope.js','integrator_sha256':sha256(integrator),'judas_module':'app/src/main/assets/judas_tadeo_odiseo.js','judas_sha256':sha256(judas),'lottery_module':'app/src/main/assets/loterias_odiseo.js','lottery_sha256':sha256(lottery),'sherlock_module':'app/src/main/assets/sherlock_odiseo.js','sherlock_sha256':sha256(sherlock),'evidence_integrator_module':'app/src/main/assets/integrador_evidencias_odiseo.js','evidence_integrator_sha256':sha256(evidence),'integrated_cycle_module':'app/src/main/assets/ciclo_integrado_odiseo.js','integrated_cycle_sha256':sha256(integrated),'communication_auditor_module':'app/src/main/assets/auditor_comunicacion_odiseo.js','communication_auditor_sha256':sha256(communication),'unified_core_module':'app/src/main/assets/nucleo_unificado_odiseo.js','unified_core_sha256':sha256(unified),'active_library_module':'app/src/main/assets/biblioteca_activa_odiseo.js','active_library_sha256':sha256(library),'adaptive_pattern_module':'app/src/main/assets/patron_adaptativo_odiseo.js','adaptive_pattern_sha256':sha256(adaptive),'tic_module':'app/src/main/assets/tic_odiseo.js','tic_sha256':sha256(tic),'tic_inference_module':'app/src/main/assets/tic_inferencia_odiseo.js','tic_inference_sha256':sha256(tic_inference),'inactivity_detector':{'threshold_ms':1800000,'policy_sha256':sha256(inactivity_sources['policy']),'store_sha256':sha256(inactivity_sources['store']),'receiver_sha256':sha256(inactivity_sources['receiver']),'boot_receiver_sha256':sha256(inactivity_sources['boot_receiver']),'manifest_sha256':sha256(manifest_path),'index_sha256':sha256(ASSETS/'index.html')},'reasoning_core_sha256':sha256(reasoning),'semantic_memory_module':'app/src/main/assets/memoria_semantica_local_odiseo.js','semantic_memory_sha256':sha256(semantic_memory),'local_assistant_sha256':sha256(local_assistant),'voice':{'microphone_permission':'android.permission.RECORD_AUDIO','recognition_language':'es-ES','offline_preference':True,'text_to_speech':'es-ES','apk_build_verified':False},'prepared_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'build_status':'PREPARADO'}
    report['creative_studio']={'module':'app/src/main/assets/creativestudio_odiseo.js','sha256':sha256(ASSETS/'creativestudio_odiseo.js'),'local_svg_drawing':True,'local_text_normalization':True,'local_model_route':'OdiseoLocalAssistant.reply','hybrid_api':'OpenAI-compatible HTTPS chat/images endpoints','api_key_persisted':False,'image_model_included':False}
    if args.solo_preparar:
        out=ROOT/'build-output'; out.mkdir(exist_ok=True)
        (out/'ODISEO_BUILD_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
        print(json.dumps(report,indent=2,ensure_ascii=False)); return 0
    cmd=[args.gradle,'--no-daemon','assembleDebug']
    print('Ejecutando:', ' '.join(cmd))
    try: subprocess.run(cmd,cwd=ROOT,check=True)
    except FileNotFoundError: print('ERROR: Gradle no está instalado. Usa GitHub Actions o instala JDK 17, Gradle 8.13 y Android SDK 35.',file=sys.stderr); return 2
    except subprocess.CalledProcessError as e: return e.returncode
    if not APK.is_file(): print('ERROR: Gradle terminó sin producir la APK esperada.',file=sys.stderr); return 3
    out=ROOT/'build-output'; out.mkdir(exist_ok=True)
    dest=out/(args.nombre.replace(' ','_')+'-debug.apk'); shutil.copy2(APK,dest)
    report.update({'build_status':'APK_GENERADA','apk':dest.name,'apk_size':dest.stat().st_size,'apk_sha256':sha256(dest)})
    (out/'ODISEO_BUILD_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False)); return 0
if __name__=='__main__': raise SystemExit(main())
