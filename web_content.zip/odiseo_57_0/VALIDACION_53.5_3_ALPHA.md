# Validación Odiseo 53.5.3-alpha — Penélope local

Fecha: 2026-11-05

## Cambio
Se incorpora una ruta de conversación explícita a Penélope. Sintaxis: `Penélope: {JSON}`; el objeto debe contener `ast` y puede incluir `sourceId`. Se ejecuta `OdiseoPenelope.unweave`; cada propuesta pasa por `validateProposal` antes de mostrarse. Se informa cuántas propuestas fueron rechazadas. El AST original no se altera.

## Pruebas ejecutadas
- `node tests_asistente_penelope.js`: 3/3 PASS.
- `node tests_asistente_local_odiseo.js`: 6/6 PASS.
- `node tests_asistente_rutas_funcionales.js`: 4/4 PASS.
- `node --test tests_*.js`: 36/36 PASS, 0 fallos.
- `node --check` sobre assets JS: 31/31 PASS.
- ZIP CRC: PASS.

## Alcance y límites
- Tests Node con APIs reales de Penélope y almacenamiento simulado; no prueban integración en Android WebView.
- Penélope valida estructura/huellas de sus propuestas, no equivalencia semántica o matemática.
- El asistente continúa siendo un router determinista, no un LLM.
- Sin APK compilada, instalación ni prueba física.
- Versión estable global sigue en 53.2; esta rama no se promociona.

## Siguiente paso
Completar contratos de entrada/salida para motores restantes y preparar comparación técnica de LiteRT-LM frente a llama.cpp para incorporar un modelo lingüístico local pequeño, sin servicios remotos. Medir en el dispositivo real antes de fijar motor/modelo.
