'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const file=path.join(__dirname,'app/src/main/assets/patron_adaptativo_odiseo.js');
const store=new Map(),ctx={Date,Math,JSON,Array,Object,String,Number,Error,Set,Map,localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)}};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(file,'utf8'),ctx);
const A=ctx.OdiseoAdaptivePattern;assert(A);let r=A.inspect({question:'Demuestra y verifica si todos los módulos funcionan aunque hay contradicciones',answer:'Está garantizado y demostrado siempre.'});
assert.strictEqual(r.plan.mode,'VERIFY');assert(r.plan.questionIssues.some(x=>x.id==='proof'));assert(r.plan.questionIssues.some(x=>x.id==='complexity'));assert(r.plan.answerIssues.some(x=>x.id==='unsupported_answer'));assert(r.plan.routes.includes('OIE'));assert.strictEqual(r.plan.autoMutation,false);
let f=A.feedback({issue:'proof',outcome:'HELPFUL',notes:'El contraste ayudó'});assert(f.recorded);assert.strictEqual(A.profile().feedbackCount,1);assert.strictEqual(A.profile().issueProfiles.proof.helpful,1);
r=A.inspect({question:'¿Puedes hacer eso?'});assert(r.plan.questionIssues.some(x=>x.id==='missing_context')||r.plan.questionIssues.some(x=>x.id==='ambiguity')||r.plan.questionIssues.some(x=>x.id==='short_query'));
assert.throws(()=>A.feedback({issue:'x',outcome:'MAGIC'}));assert(r.persistence.persisted);console.log('Patrón adaptativo: detección bidireccional, estrategia, rutas, feedback y persistencia OK.');
