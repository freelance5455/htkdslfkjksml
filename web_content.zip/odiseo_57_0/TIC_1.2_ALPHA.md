# Odiseo TIC 1.2-alpha — Inferencia acotada

**Estado:** prototipo local implementado; sujeto a auditoría independiente. No sustituye TIC 1.1 ni queda conectado a la orquestación semántica de motores.

## Alcance añadido

1. **PID explícita:** implementación Williams–Beer `I_min` para dos fuentes. Devuelve redundancia, información única de cada fuente y sinergia, con residuo de cierre. `I_min` es una definición concreta con limitaciones; no se presenta como PID universal.
2. **Confusores observados:** transferencia de entropía condicionada al pasado del objetivo y a los valores pasados de confusores declarados.
3. **Incertidumbre temporal exploratoria:** intervalo percentil del 95% por moving-block bootstrap sobre tuplas temporales alineadas.
4. **Contraste nulo y corrección de sesgo exploratoria:** distribución por desplazamiento circular de la fuente, valor p con corrección +1 y estimación `max(0, TE observada − media nula)`.

## Pruebas

`node tests_odiseo_tic_inferencia.js` incluye controles sintéticos de copia redundante, XOR, canal retardado con confusor independiente, significación por desplazamiento, intervalo ordenado y rechazo de muestra insuficiente.

## Límites

- El desplazamiento circular requiere estacionariedad aproximada; tendencias, rupturas y estacionalidad pueden invalidar el nulo.
- El bootstrap por bloques es una aproximación y su cobertura depende de la elección del tamaño de bloque.
- La resta de media nula es una corrección exploratoria, no una garantía de insesgadez.
- `I_min` puede asignar redundancia de forma discutible en algunos sistemas; comparar con otras PID es trabajo pendiente.
- Los confusores no observados siguen sin resolverse.
- No hay barrido de retardos ni corrección por multiplicidad.
- No se ha probado en datos externos, en Android ni mediante intervención física.
- El módulo aún no está conectado al orquestador ni instrumenta intercambios reales con Penélope, Sherlock, Judas Tadeo o Integrador E.

## Próximo control obligatorio

Auditoría independiente de fórmulas y sesgos, simulaciones con confusor común que induzca asociación espuria, sensibilidad a tamaños de bloque, falsos positivos bajo autocorrelación y comparación de `I_min` con al menos otra definición PID antes de promover la versión.
