'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const store=new Map();let invoked=[];
const ctx={Date,Math,JSON,Promise,console,localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;
ctx.OdiseoLocalAssistant={status:()=>[]};
ctx.OdiseoSemanticMemory={search:()=>[
 {id:'trace-1',text:'Collatz observation one',type:'observation',state:'unverified',source:'source-A',score:2},
 {id:'trace-2',text:'Collatz observation two',type:'observation',state:'unverified',source:'source-B',score:1}
]};
ctx.OdiseoReasoningCore={analyze:t=>({conclusion:{text:'structured'},counts:{statements:1},limitations:['heuristic']})};
ctx.OdiseoSherlock={investigate:p=>({summary:{accepted:p.traces.length},investigation:{candidates:[]}})};
ctx.OdiseoCapabilityRegistry={invoke:async(id,p)=>{invoked.push({id,p});return {status:'EXECUTED',result:ctx.OdiseoSherlock.investigate(p)};}};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/cerebro_cognitivo_odiseo.js','utf8'),ctx);
vm.runInNewContext(fs.readFileSync('app/src/main/assets/cerebro_central_odiseo.js','utf8'),ctx);
(async()=>{
 const session=await ctx.OdiseoCentralBrain.begin('Investiga los rastros de Collatz');
 const runs=session.cognitive.plan.toolRuns;
 assert.ok(session.decision.selected.some(x=>x.id==='sherlock'));
 assert.ok(runs.some(x=>x.name==='Núcleo de razonamiento local'&&x.status==='EXECUTED'));
 assert.ok(runs.some(x=>x.name==='Sherlock'&&x.status==='EXECUTED'));
 assert.equal(invoked[0].id,'sherlock.investigate');
 assert.equal(invoked[0].p.traces.length,2);
 const out=ctx.OdiseoCentralBrain.finish('Investiga los rastros de Collatz','Candidatos exploratorios.',session);
 assert.equal(out.cognitive.tracePersisted,true);
 console.log('PASS 5/5 — el director central añade y ejecuta motores priorizados mediante contratos allowlisted');
})().catch(e=>{console.error(e);process.exit(1)});
