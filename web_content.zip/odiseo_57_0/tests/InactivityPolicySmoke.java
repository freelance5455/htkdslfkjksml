package org.odiseo.app;
public final class InactivityPolicySmoke {
  private static int checks = 0;
  private static void eq(boolean expected, boolean actual, String name) { checks++; if (expected != actual) throw new AssertionError(name + " expected=" + expected + " actual=" + actual); }
  private static void eq(long expected, long actual, String name) { checks++; if (expected != actual) throw new AssertionError(name + " expected=" + expected + " actual=" + actual); }
  public static void main(String[] args) {
    long t = 1_000_000L;
    eq(false, InactivityPolicy.isInactive(t, 0L), "no previous activity");
    eq(false, InactivityPolicy.isInactive(t + 1_799_999L, t), "29m59s is active");
    eq(true, InactivityPolicy.isInactive(t + 1_800_000L, t), "30m exact threshold");
    eq(true, InactivityPolicy.isInactive(t + 1_860_000L, t), "31m inactive");
    eq(false, InactivityPolicy.isInactive(t - 1L, t), "clock moved backwards");
    eq(1L, InactivityPolicy.remainingMs(t + 1_799_999L, t), "one millisecond remaining");
    eq(0L, InactivityPolicy.remainingMs(t + 1_800_000L, t), "zero remaining at threshold");
    eq(InactivityPolicy.TIMEOUT_MS, InactivityPolicy.remainingMs(t, 0L), "first run default");
    System.out.println("PASS InactivityPolicySmoke: " + checks + "/" + checks + " checks");
  }
}
