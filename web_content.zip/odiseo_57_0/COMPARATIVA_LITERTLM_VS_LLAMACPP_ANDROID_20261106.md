# Comparativa de runtimes locales Android: LiteRT-LM frente a llama.cpp

**Fecha de consulta:** 2026-11-06  
**Dispositivo conocido:** Android con 12 GB de RAM física. Modelo exacto, SoC, GPU/NPU, versión Android, RAM libre y almacenamiento libre: no identificados.  
**Objetivo:** inferencia 100% local, sin API, suscripción ni servidor externo.

## Dictamen provisional

**Mantener LiteRT-LM como runtime principal de la APK 54.1 y usar llama.cpp en Termux como referencia independiente de rendimiento y compatibilidad.** No integrar ambos motores en la APK todavía. Esta elección se basa en la fuente ya existente en 54.1 (Kotlin + puente WebView + `.litertlm`), no en una prueba de rendimiento en el teléfono, que aún no existe.

## 1. Comparación técnica

| Criterio | LiteRT-LM | llama.cpp |
|---|---|---|
| Núcleo | Runtime de Google AI Edge, C++ con API Kotlin para Android | Motor C/C++ multiplataforma |
| Integración con 54.1 | Ya existe `LocalModelRuntime.kt`, puente `OdiseoNative` y selector SAF | Requeriría nueva biblioteca nativa, JNI/binding y gestión GGUF |
| Formato de modelo | Bundle `.litertlm` preparado para LiteRT-LM | `GGUF` |
| Cuantización | Bundles optimizados por modelo; Gemma 4 móvil usa esquema específico 2/4/8-bit | Amplia gama de 1.5, 2, 3, 4, 5, 6 y 8 bits |
| Aceleración | CPU, GPU y NPU según modelo, API y dispositivo | CPU ARM; backends GPU/NPU según build, controlador y SoC |
| Herramientas | API Kotlin documentada para tool/function calling; requiere que el modelo y la aplicación implementen el contrato | Gramáticas y mecanismos de tool calling disponibles en el ecosistema; la aplicación debe implementar y controlar la ejecución |
| Termux | No es su vía principal de despliegue Android | Tiene guía oficial para compilar y ejecutar en Termux sin root |
| Flexibilidad de modelos | Catálogo `.litertlm` y conversión específica | Ecosistema GGUF amplio y más opciones de cuantización |
| Complejidad de APK | Menor para la arquitectura ya escrita | Mayor: CMake/NDK, ABI, `.so`, JNI, backend y ciclo de vida |
| Licencia del runtime | Apache-2.0 | MIT |

Ambos pueden funcionar sin red una vez que el modelo está descargado y almacenado localmente. La descarga inicial sí consume datos y espacio; la inferencia local no necesita pagar por petición.

## 2. Compatibilidad con el código 54.1

El proyecto fija `com.google.ai.edge.litertlm:litertlm-android:0.18.0`, Kotlin 2.4.0 y `minSdk 24`. La guía Android de Google documenta el AAR 0.18.0 con `minSdk 24` y metadatos Kotlin 2.4.0; el código 54.1 usa el patrón Kotlin `Engine` → `initialize` → `createConversation` → `sendMessageAsync`. La metadata de dependencias del AAR 0.18.0 declara `kotlinx-coroutines-android:1.11.0`; la fuente 54.1 tenía 1.10.2, así que esta revisión la alinea a 1.11.0.

Esto es una **coincidencia documental de API**, no una compilación real contra el AAR. La compilación de esta revisión solo usó stubs; el build Android sigue pendiente. LiteRT-LM 0.19.0 ya aparece publicado, pero no se debe cambiar de versión sin compilar y repetir la batería completa. Para una primera build reproducible, conservar 0.18.0 con coroutines 1.11.0; después comparar 0.19.0 en una rama separada.

El código actual no fija explícitamente CPU/GPU/NPU. Por tanto, no se puede afirmar qué backend ejecutaría el teléfono. Primero hay que registrar el backend real y obtener una ejecución CPU correcta; después probar GPU y NPU solo si el dispositivo y el modelo los soportan.

## 3. Modelos candidatos de 2–4B

### A. Gemma 4 E2B — primer candidato

- Hay bundle móvil `.litertlm` oficial para LiteRT-LM.
- El modelo card informa de un archivo de 2,583 MB y memoria móvil aproximada de 1.1 GB (0.84 GB en texto solamente).
- En el benchmark publicado por Google para un Samsung S26 Ultra, con contexto 2,048 y 1,024 tokens de entrada/256 de salida, el decode fue 46.9 tokens/s en CPU y 52.1 en GPU; el tiempo hasta el primer token fue 1.8 s y 0.3 s, respectivamente. La memoria de proceso informada fue 1,733 MB en CPU y 676 MB en GPU.
- Son cifras del dispositivo de Google, no una predicción del teléfono del usuario.

Para llama.cpp existe una variante GGUF QAT Q4_0. La documentación de Gemma 4 estima unos 2.9 GB de memoria estática para los pesos E2B Q4_0; la caché KV, el runtime y Android consumen memoria adicional.

### B. Gemma 4 E4B — segundo candidato

- Bundle móvil `.litertlm` disponible; estimación móvil de 2.5 GB (2.2 GB texto solamente).
- Variante GGUF Q4_0 disponible; estimación de pesos estáticos de 4.5 GB, más caché KV y runtime.
- Puede caber en 12 GB físicos, pero no se debe dar por seguro: Android, servicios residentes, longitud de contexto y acelerador reducen la memoria utilizable. No empezaría por E4B.

### C. Qwen3-4B — alternativa de contraste

El modelo oficial Qwen3-4B declara licencia Apache-2.0. Su repositorio original publica pesos Safetensors de aproximadamente 8.06 GB; para 12 GB físicos sería necesario seleccionar una cuantización GGUF comprobada, no cargar esos pesos originales directamente. No es el primer candidato porque Gemma 4 permite comparar dos runtimes sobre la misma familia y existe una ruta `.litertlm` ya preparada.

## 4. Licencias

- LiteRT-LM: Apache-2.0.
- llama.cpp: MIT.
- Gemma 4: licencia Apache 2.0 en la documentación oficial.
- Qwen3-4B: Apache-2.0 en la ficha oficial del modelo.

Antes de redistribuir cualquier archivo de pesos, conservar la licencia y avisos que acompañen al artefacto exacto descargado. La licencia del runtime y la licencia del modelo son independientes.

## 5. Protocolo de benchmark en el teléfono

No escoger por marketing ni por la RAM nominal. Medir ambos runtimes en el mismo teléfono y con el mismo conjunto de prompts:

1. Identificar modelo exacto, SoC, GPU, NPU, Android/API, ABI, RAM libre tras reinicio y almacenamiento libre.
2. Desactivar temporalmente tareas de fondo; mantener condiciones térmicas y de batería comparables.
3. Descargar una vez los dos formatos de Gemma 4 E2B; verificar SHA-256 y mantener los modelos en almacenamiento local.
4. Probar primero CPU y contexto 2,048; luego contexto 4,096; GPU/NPU solo después de comprobar compatibilidad.
5. Usar prompts fijos en español: conversación, resumen, razonamiento, matemáticas, código y llamada de herramienta. Entrada de 512 y 2,048 tokens; salida máxima de 128 tokens.
6. Hacer 2 calentamientos y 5 repeticiones medidas por caso; no mezclar el tiempo de carga inicial con el tiempo de generación.
7. Registrar: tiempo de carga, TTFT, tokens/s, PSS/RSS máximo, CPU/GPU/NPU, temperatura antes/después, batería, cierres forzados y errores.
8. Evaluar calidad a ciegas con la misma rúbrica y respuestas de referencia; para matemáticas usar casos con resultado verificable. La llamada de herramienta se evalúa por selección correcta, argumentos válidos y ausencia de ejecución no autorizada.
9. Repetir en modo avión después de importar los modelos. Si falla sin red, el objetivo offline no está cumplido.
10. Elegir el runtime por calidad, memoria, estabilidad, temperatura y facilidad de mantenimiento, no solo por tokens/s.

## 6. Datos de hardware aún necesarios

La cifra de 12 GB de RAM no identifica el SoC ni la disponibilidad de aceleradores. La siguiente decisión depende de conocer el modelo exacto del teléfono y su chipset. Sin esos datos no se puede escoger con rigor un backend GPU/NPU ni estimar velocidad real.

## 7. Recomendación operativa

1. **APK:** mantener LiteRT-LM 0.18.0 en la rama 54.1 y comenzar con Gemma 4 E2B `.litertlm`, CPU primero.
2. **Contraste independiente:** preparar llama.cpp en Termux con Gemma 4 E2B QAT Q4_0 GGUF, contexto 2,048–4,096, sin root ni servidor remoto.
3. **No integrar todavía:** solo después de medir ambos en el mismo teléfono decidir si llama.cpp merece una segunda implementación nativa.
4. **No declarar independencia completa:** el runtime local no sustituye la orquestación, la memoria, las auditorías ni la validación de los motores de Odiseo.

## Fuentes técnicas consultadas

- LiteRT-LM Android Kotlin API: https://developers.google.com/edge/litert-lm/android
- Dependencias publicadas de `litertlm-android:0.18.0`: https://mvnrepository.com/artifact/com.google.ai.edge.litertlm/litertlm-android/0.18.0/dependencies
- LiteRT-LM, repositorio y licencia Apache-2.0: https://github.com/google-ai-edge/LiteRT-LM
- Guía Android del AAR 0.18.0, `minSdk 24` y Kotlin metadata: https://developer.android.com/agents/skills/device-ai/litert/litert-lm/skill
- Gemma 4 model overview, tamaños, memoria y benchmarks: https://gemma.ai/models/gemma-4/
- Gemma 4 QAT y formatos GGUF/LiteRT: https://gemma.ai/get-started/qat/
- Bundle Gemma 4 E2B LiteRT-LM: https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm
- llama.cpp Android: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- llama.cpp README y licencia MIT: https://github.com/ggml-org/llama.cpp
- Qwen3-4B y licencia: https://huggingface.co/Qwen/Qwen3-4B
