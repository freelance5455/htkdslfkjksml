const fs=require('fs'),vm=require('vm'),ctx={window:{}};
vm.runInNewContext(fs.readFileSync(__dirname+'/app/src/main/assets/tic_odiseo.js','utf8'),ctx);
vm.runInNewContext(fs.readFileSync(__dirname+'/app/src/main/assets/tic_inferencia_odiseo.js','utf8'),ctx);
const T=ctx.window.OdiseoTIC,I=ctx.window.OdiseoTICInference;let n=0;function ok(v,m){n++;if(!v)throw Error(m)}
function rng(seed){let x=seed>>>0;return()=>{x=(1664525*x+1013904223)>>>0;return x/4294967296}}
function bit(r){return r()<.5?0:1}
const a=[],b=[],c=[];let r=rng(81),prev=0;for(let i=0;i<5000;i++){const x=bit(r);a.push(x);prev=x;b.push(prev);c.push(bit(r));}
const pid=I.pidImin(a,b,a);ok(pid.redundancyBits>.95,'PID I_min detecta redundancia de dos copias');ok(pid.synergyBits<.02,'PID I_min no inventa sinergia en copias');ok(Math.abs(pid.closureResidualBits)<1e-8,'PID cierra la suma informativa');
const xorA=[],xorB=[],xorY=[];r=rng(91);for(let i=0;i<6000;i++){const x=bit(r),y=bit(r);xorA.push(x);xorB.push(y);xorY.push(x^y)}
const px=I.pidImin(xorA,xorB,xorY);ok(px.synergyBits>.95,'PID I_min identifica el control XOR');ok(px.unique1Bits<.02&&px.unique2Bits<.02,'XOR sin información única apreciable');
const driven=[],target=[],conf=[];r=rng(101);for(let i=0;i<5000;i++){const x=bit(r);driven.push(x);target.push(i?driven[i-1]:0);conf.push(bit(r))}
ok(I.transferEntropyConditioned(driven,target,[conf],1)>.95,'TE condicionada detecta canal retardado con confusor independiente');
const inf=I.inferTransferEntropy(driven,target,{lag:1,confounders:[conf],permutations:49,bootstraps:49,blockLength:3,seed:12});ok(inf.permutationPValue<=.1,'Canal conocido significativo frente a desplazamientos');ok(inf.confidence95Bits.length===2&&inf.confidence95Bits[0]<=inf.confidence95Bits[1],'Intervalo bootstrap ordenado');ok(inf.biasAdjustedBits>=0,'Corrección nula no negativa');

const common=[],cx=[],cy=[];r=rng(111);for(let i=0;i<6000;i++){const z=bit(r);common.push(z);cx.push(z^(r()<.12?1:0));cy.push(i?common[i-1]^(r()<.12?1:0):bit(r));}
const unadjusted=I.transferEntropyConditioned(cx,cy,[],1),adjusted=I.transferEntropyConditioned(cx,cy,[common],1);
ok(unadjusted>adjusted+.15,'Confusor común genera asociación predictiva espuria sin ajuste');ok(adjusted<.03,'Condicionar por confusor observado reduce la asociación espuria');
const na=[],ny=[];r=rng(121);for(let i=0;i<5000;i++){na.push(bit(r));ny.push(bit(r))}
const nullInf=I.inferTransferEntropy(na,ny,{lag:1,permutations:49,bootstraps:49,blockLength:3,seed:18});ok(nullInf.permutationPValue>.01,'Control nulo independiente no produce significación extrema');
let bad=false;try{I.inferTransferEntropy([1,2,3],[1,2,3],{permutations:5,bootstraps:5})}catch(e){bad=true}ok(bad,'Rechaza muestra temporal insuficiente');
console.log(`OK: ${n} aserciones TIC 1.2 alpha superadas.`);
