# Plan técnico 54.0-alpha — Modelo neuronal local Android

Fecha de revisión documental: 2026-11-05
Estado: selección preliminar de arquitectura; todavía no integrada ni ejecutada en el teléfono.

## Runtime elegido para evaluación

**Google LiteRT-LM (API Kotlin Android/JVM)**. La documentación oficial lo presenta como API estable para Android/JVM, con backend CPU/GPU y NPU según dispositivo, carga de modelo desde una ruta local y conversaciones con streaming. Dependencia Gradle documentada: `com.google.ai.edge.litertlm:litertlm-android`. La inicialización del motor puede tardar varios segundos y debe ejecutarse fuera del hilo de UI. La API permite registrar herramientas Kotlin para conectar el modelo con los motores Odiseo; se mantendrá un allowlist y confirmación explícita para acciones que escriban o borren datos.

Documentación oficial: https://developers.google.com/edge/litert-lm/android
Visión general/modelos: https://developers.google.com/edge/litert-lm/overview

No se usará MediaPipe LLM Inference como nueva base: la documentación oficial indica que está en modo mantenimiento y recomienda migrar a LiteRT-LM.

## Modelos candidatos

1. **Gemma 4 E2B** como candidato principal de conversación local. La tabla oficial de LiteRT-LM lista un artefacto de 2.583 MB y resultados en hardware Samsung S26 Ultra; esas cifras no se extrapolan al móvil Xiaomi del usuario.
2. **EmbeddingGemma 2 Text (270M)** como candidato de embeddings semánticos. La documentación oficial lista 165 MB. Se evaluará para sustituir o complementar BM25 y habilitar búsqueda por paráfrasis, sin tratar similitud vectorial como prueba de verdad.
3. **Gemma 4 E4B** solo como candidato posterior si la latencia y memoria reales lo permiten; su artefacto oficial listado es 3.654 MB.

Fuentes oficiales: https://developers.google.com/edge/litert-lm/overview y https://gemma.ai/models/

## Diseño de integración

- No incluir pesos de varios GB dentro de la APK. La APK contendrá runtime, interfaz, motores Odiseo y gestor de modelos; el usuario importará o descargará el archivo de modelo una sola vez y lo almacenará en espacio privado.
- Mantener modo determinista actual como fallback completo cuando no haya modelo instalado o haya poca memoria.
- Crear `LocalModelEngine` con estados `NOT_INSTALLED`, `READY`, `LOADING`, `RUNNING`, `ERROR`; carga y generación fuera del hilo UI; cancelación y liberación explícita del motor.
- El LLM propone; los motores Odiseo calculan/verifican. No se aceptarán resultados del modelo como hechos sin validación o procedencia.
- Herramientas expuestas al modelo mediante allowlist, límites de presupuesto y validación de esquema. La escritura/eliminación de memoria requerirá confirmación.
- La memoria semántica conservará BM25 como fallback; el embedding local será una segunda puntuación con pruebas de recall, falsos positivos y conjunto holdout.

## Criterios de aceptación antes de declarar 54.0

- Build reproducible con versión de dependencia fijada (no `latest.release` en la versión final).
- Modelo descargado/importado con hash y licencia registrados; no empaquetar pesos sin verificar licencia.
- Prueba offline después de la primera instalación del modelo.
- Medir RAM pico, tiempo de carga, tokens/s, latencia inicial, temperatura y consumo de batería en el móvil objetivo.
- Comparar respuestas en español, matemáticas y llamadas a herramientas; medir exactitud y tasa de invocación errónea.
- Fallback determinista probado al quitar el modelo, agotar memoria o fallar el runtime.
- Exportación ODISEO SAVE incluye configuración y huella del modelo, pero no copia automáticamente pesos grandes.

## Límites

La documentación de LiteRT-LM y los tamaños publicados no garantizan compatibilidad ni rendimiento en el teléfono del usuario. Es imprescindible una prueba física. La inferencia local evita costes por consulta y envío de mensajes a servidores, pero el modelo debe descargarse, ocupa almacenamiento y consume CPU/GPU, RAM, batería y calor. Las licencias de pesos deben revisarse por modelo antes de redistribuirlos.
