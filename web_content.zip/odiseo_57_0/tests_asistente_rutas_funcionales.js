'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const store=new Map();const ctx={console,Date,Math,JSON,window:{},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;
ctx.OdiseoUnifiedCore={run:async()=>({status:'PASS',executed:2,total:2,failed:0})};
ctx.OdiseoSherlock={investigate:x=>({summary:{accepted:x.traces.length},verdict:'FRAGMENTS_ONLY',investigation:{candidates:[]}})};
ctx.OdiseoJudasTadeo={reframe:x=>({routes:['Cambiar representación','Buscar contraejemplo'],alternativeFrames:[{name:'Formal',question:'¿Qué premisas faltan?'}]})};
ctx.OdiseoMirror={empty:()=>({schema:'ODISEO_MIRROR_GRAPH_1',nodes:[],edges:[],learnings:[]}),auditSelf:g=>({summary:{nodes:g.nodes.length,edges:g.edges.length,findings:0},findings:[]}),proposeQuestions:()=>({questions:[]})};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/asistente_local_odiseo.js','utf8'),ctx);
(async()=>{
 let r=await ctx.OdiseoLocalAssistant.reply('Sherlock: muestra A contiene 12; muestra B contiene 18');assert.equal(r.meta.engine,'Sherlock');assert.equal(r.meta.result.summary.accepted,2);
 r=await ctx.OdiseoLocalAssistant.reply('Reencuadra este bloqueo');assert.equal(r.meta.engine,'Judas Tadeo');assert.match(r.text,/contraejemplo/);
 r=await ctx.OdiseoLocalAssistant.reply('Audita el espejo');assert.equal(r.meta.engine,'ESPEJO');assert.match(r.text,/Auditoría ESPEJO ejecutada/);
 r=await ctx.OdiseoLocalAssistant.reply('Sherlock: solo una');assert.equal(r.meta.status,'NEEDS_INPUT');
 console.log('PASS 4/4 — enrutamiento funcional Sherlock/Judas/ESPEJO, resultado, error de entrada y límite explícito');
})().catch(e=>{console.error(e);process.exit(1)});
