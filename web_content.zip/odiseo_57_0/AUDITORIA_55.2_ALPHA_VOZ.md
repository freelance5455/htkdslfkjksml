# Auditoría Odiseo 55.2-alpha — Voz conversacional

Fecha: 2026-11-18. Rama: `55.2-alpha-voice-chat`. Base: 55.1-alpha. Estable global preservada: 53.2.

## Implementado
- Reconocimiento de voz Android en `es-ES`, permiso de micrófono en tiempo de ejecución y consulta del servicio de reconocimiento.
- Selección del reconocedor on-device cuando Android 13+ informa que está disponible; `EXTRA_PREFER_OFFLINE` como preferencia para los demás servicios.
- Síntesis de voz `TextToSpeech` en español.
- Botón Hablar, botón para activar/desactivar voz, estado de voz, transcripción enviada al chat y lectura de respuestas.
- El chat existente conserva el despacho cognitivo y el uso del modelo LiteRT-LM local cuando el modelo está cargado.
- El generador de build ahora toma la versión del estado del proyecto y ya no etiqueta la preparación como 53.9-alpha.

## Pruebas reproducidas
- `node --test tests_*.js`: 49/49 suites, 55/55 subtests PASS.
- `python -m unittest tests_android_build_metadata.py -v`: 10/10 PASS.
- 37 bloques `<script>` detectados en HTML; los dos bloques inline con código pasan `node --check`.
- AndroidManifest XML: PASS.
- `python crear_apk_odiseo.py --solo-preparar`: PASS; informa `55.2-alpha-voice-chat`.

## No probado / limitaciones
- No se ejecutó `gradle assembleDebug`: el entorno no dispone de Gradle ni Android SDK; solo Java 21, no el JDK 17 requerido.
- No existe APK compilada, no se instaló en teléfono y no se verificó el AAR LiteRT-LM 0.18.0 real.
- Micrófono, reconocimiento, TTS y generación neuronal aún no se han probado físicamente.
- `EXTRA_PREFER_OFFLINE` es una preferencia, no garantía de modo avión. El reconocimiento local depende del servicio y del paquete de idioma instalado; TextToSpeech depende de una voz española disponible.
- Sin un modelo `.litertlm` compatible cargado, el chat conserva las rutas deterministas y no es un LLM general.

**Dictamen:** voz integrada en código fuente y pruebas automáticas superadas; APK aún no cerrada/compilada.
