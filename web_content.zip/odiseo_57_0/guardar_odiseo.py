#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ODISEO SAVE: copias versionadas, manifiesto SHA-256 y restauración segura.
Solo biblioteca estándar de Python 3.10+.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

TOOL_VERSION = "1.0"
EXCLUDED_DIRS = {".git", "__pycache__", ".venv", "venv", "backups", "restauraciones", ".gradle", "build"}
EXCLUDED_NAMES = {".DS_Store", "Thumbs.db", "ODISEO_MANIFEST.json"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_files(root: Path):
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        if any(part in EXCLUDED_DIRS for part in rel.parts) or p.name in EXCLUDED_NAMES:
            continue
        if p.is_file() and not p.is_symlink():
            yield p, rel.as_posix()


def save(project: Path, backup_dir: Path, label: str = "sesion") -> Path:
    project = project.resolve(); backup_dir = backup_dir.resolve()
    if not project.is_dir(): raise ValueError(f"No existe el proyecto: {project}")
    if backup_dir == project or project in backup_dir.parents:
        raise ValueError("La carpeta de copias no puede estar dentro del proyecto; evita copias recursivas")
    state_path = project / "ESTADO_ODISEO.json"
    if not state_path.is_file(): raise ValueError("Falta ESTADO_ODISEO.json; no se crea una copia sin punto de continuidad")
    state = json.loads(state_path.read_text(encoding="utf-8"))
    version = str(state.get("project_version", "sin-version")).replace("/", "-")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_dir.mkdir(parents=True, exist_ok=True)
    out = backup_dir / f"ODISEO_{version}_{stamp}_{label}.zip"
    files = list(safe_files(project))
    manifest = []
    for path, rel in files:
        manifest.append({"path": rel, "size": path.stat().st_size,
                         "sha256": sha256_bytes(path.read_bytes())})
    checkpoint = {
        "format": "ODISEO_SAVE_1", "tool_version": TOOL_VERSION,
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "project_version": version, "next_target": state.get("next_target"),
        "project_state_file": "ESTADO_ODISEO.json", "file_count": len(manifest),
        "principle": "Una fuente de verdad; los cambios solo se aceptan tras revisión y pruebas.",
    }
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path, rel in files: z.write(path, rel)
        z.writestr("ODISEO_MANIFEST.json", json.dumps({"checkpoint": checkpoint, "files": manifest}, ensure_ascii=False, indent=2))
    latest = {"backup": out.name, "sha256": sha256_bytes(out.read_bytes()), "checkpoint": checkpoint}
    tmp = backup_dir / "LATEST.json.tmp"
    tmp.write_text(json.dumps(latest, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, backup_dir / "LATEST.json")
    return out


def verify(archive: Path) -> tuple[bool, list[str]]:
    errors = []
    try:
        with zipfile.ZipFile(archive, "r") as z:
            bad = z.testzip()
            if bad: errors.append(f"CRC incorrecto: {bad}")
            names = z.namelist()
            if "ODISEO_MANIFEST.json" not in names: return False, ["Falta ODISEO_MANIFEST.json"]
            manifest = json.loads(z.read("ODISEO_MANIFEST.json"))
            listed = set()
            for item in manifest.get("files", []):
                name = item["path"]
                pp = PurePosixPath(name)
                if pp.is_absolute() or ".." in pp.parts:
                    errors.append(f"Ruta insegura en manifiesto: {name}"); continue
                listed.add(name)
                if name not in names: errors.append(f"Archivo ausente: {name}"); continue
                data = z.read(name)
                if len(data) != item["size"]: errors.append(f"Tamaño incorrecto: {name}")
                if sha256_bytes(data) != item["sha256"]: errors.append(f"SHA-256 incorrecto: {name}")
            extra = set(names) - listed - {"ODISEO_MANIFEST.json"}
            if extra: errors.append("Archivos no declarados: " + ", ".join(sorted(extra)))
    except (OSError, zipfile.BadZipFile, KeyError, ValueError, json.JSONDecodeError) as e:
        errors.append(f"No se pudo verificar: {e}")
    return not errors, errors


def restore(archive: Path, destination: Path) -> Path:
    ok, errors = verify(archive)
    if not ok: raise ValueError("Copia no válida: " + "; ".join(errors))
    destination = destination.resolve()
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("El destino existe y no está vacío; elige una carpeta nueva")
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "r") as z:
        for name in z.namelist():
            if name == "ODISEO_MANIFEST.json": continue
            pp = PurePosixPath(name)
            if pp.is_absolute() or ".." in pp.parts: raise ValueError(f"Ruta insegura: {name}")
            target = destination.joinpath(*pp.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(name))
    return destination


def main():
    p = argparse.ArgumentParser(description="Guardar, verificar y restaurar Odiseo")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("guardar"); s.add_argument("--proyecto", default="."); s.add_argument("--copias", default="../ODISEO_COPIAS"); s.add_argument("--etiqueta", default="sesion")
    v = sub.add_parser("verificar"); v.add_argument("archivo")
    r = sub.add_parser("restaurar"); r.add_argument("archivo"); r.add_argument("destino")
    args = p.parse_args()
    try:
        if args.cmd == "guardar":
            out = save(Path(args.proyecto), Path(args.copias), args.etiqueta)
            ok, errs = verify(out)
            print(json.dumps({"guardado": str(out), "verificado": ok, "errores": errs}, ensure_ascii=False, indent=2))
            return 0 if ok else 2
        if args.cmd == "verificar":
            ok, errs = verify(Path(args.archivo))
            print(json.dumps({"verificado": ok, "errores": errs}, ensure_ascii=False, indent=2))
            return 0 if ok else 2
        dest = restore(Path(args.archivo), Path(args.destino))
        print(json.dumps({"restaurado_en": str(dest), "verificado_antes_de_restaurar": True}, ensure_ascii=False, indent=2))
        return 0
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
