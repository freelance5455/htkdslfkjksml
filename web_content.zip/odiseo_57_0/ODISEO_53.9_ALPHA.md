# Odiseo 53.9-alpha — Respaldo integral de memoria semántica

Fecha: 2026-11-05
Base: 53.8-alpha (experimental); 53.2 permanece estable.

## Cambio implementado
- El ZIP `ODISEO SAVE` ahora incluye `diary.semantic_memory`, exportado desde `OdiseoSemanticMemory.exportData()`.
- La restauración valida el formato, límites, procedencia obligatoria e IDs únicos de la memoria semántica antes de solicitar confirmación y escribir los datos.
- Tras la validación del paquete y confirmación del usuario, la memoria semántica se restaura en modo `replace`, coherente con la semántica de restauración del resto de la copia.
- La importación semántica expone `validateData()` para prevalidar sin modificar el almacenamiento.
- La versión Android se actualiza a `53.9-alpha-offline-memory` (versionCode 539).

## Pruebas
- Batería nueva `tests_memoria_semantica_respaldo_53_9.js`: 18/18 aserciones.
- Regresión: 42/42 archivos de pruebas JavaScript ejecutados con código de salida cero.
- Sintaxis: todos los activos JavaScript pasan `node --check`.
- Generador APK `--solo-preparar`: pendiente de ejecutar en esta versión.

## Límites conocidos
- La recuperación sigue siendo BM25 léxica; no usa embeddings ni entiende paráfrasis de forma fiable.
- `verified` es una etiqueta declarada, no una verificación de verdad externa.
- La persistencia usa WebView localStorage; si se borran los datos de la app, solo se recupera desde una copia exportada.
- Esta máquina no tiene Android SDK ni Gradle instalados; no se afirma compilación ni instalación de APK.
- No hay todavía un modelo neuronal/LLM local integrado. El núcleo simbólico local no equivale a un modelo neuronal general.
