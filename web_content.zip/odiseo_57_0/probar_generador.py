from pathlib import Path
import json, shutil, subprocess, sys
root=Path(__file__).resolve().parent

# Detector Android de inactividad: componentes nativos y política de 30 minutos.
java_root=root/'app'/'src'/'main'/'java'/'org'/'odiseo'/'app'
for name in ['InactivityPolicy.java','InactivityStore.java','InactivityReceiver.java','InactivityBootReceiver.java']:
    assert (java_root/name).is_file(), f'Falta componente Android: {name}'
manifest=(root/'app'/'src'/'main'/'AndroidManifest.xml').read_text(encoding='utf-8')
assert 'RECEIVE_BOOT_COMPLETED' in manifest and 'InactivityReceiver' in manifest and 'InactivityBootReceiver' in manifest
html=(root/'app'/'src'/'main'/'assets'/'index.html').read_text(encoding='utf-8')
for token in ['ODISEO_INACTIVITY_AUDIT_1','odiseoHandleNativeInactivity','persistInactivityAudit','inactivityRecoveryPanel']:
    assert token in html, f'Falta integración de inactividad: {token}'
javac=shutil.which('javac'); java=shutil.which('java')
if javac and java:
    test_dir=root/'build-output'/'inactivity-policy-test'; test_dir.mkdir(parents=True,exist_ok=True)
    subprocess.run([javac,'-d',str(test_dir),str(java_root/'InactivityPolicy.java'),str(root/'tests'/'InactivityPolicySmoke.java')],check=True)
    subprocess.run([java,'-cp',str(test_dir),'org.odiseo.app.InactivityPolicySmoke'],check=True)
else:
    print('AVISO: JDK no disponible; prueba Java pura omitida.')
module=root/'app'/'src'/'main'/'assets'/'algoritmo_odiseo.js'
code=module.read_text(encoding='utf-8')
for token in ['runCollatzAudit','discoverA','refuteB','evaluateC','controller: \'H\'']:
    assert token in code, f'Falta componente del motor: {token}'
mirror=root/'app'/'src'/'main'/'assets'/'espejo_odiseo.js'
assert mirror.is_file() and 'OdiseoMirror' in mirror.read_text(encoding='utf-8')
accelerator=root/'app'/'src'/'main'/'assets'/'acelerador_odiseo.js'
assert accelerator.is_file() and 'OdiseoAccelerator' in accelerator.read_text(encoding='utf-8')
riddle=root/'app'/'src'/'main'/'assets'/'acertijo_odiseo.js'
assert riddle.is_file() and 'OdiseoRiddle' in riddle.read_text(encoding='utf-8')
evolution=root/'app'/'src'/'main'/'assets'/'evolucion_odiseo.js'
assert evolution.is_file() and 'OdiseoEvolution' in evolution.read_text(encoding='utf-8')
interaction=root/'app'/'src'/'main'/'assets'/'interaccion_odiseo.js'
assert interaction.is_file() and 'OdiseoInteraction' in interaction.read_text(encoding='utf-8')
convergence=root/'app'/'src'/'main'/'assets'/'convergencia_odiseo.js'
assert convergence.is_file() and 'OdiseoConvergence' in convergence.read_text(encoding='utf-8')
moving=root/'app'/'src'/'main'/'assets'/'objetivo_evolutivo_odiseo.js'
assert moving.is_file() and 'OdiseoMovingTarget' in moving.read_text(encoding='utf-8')
creator=root/'app'/'src'/'main'/'assets'/'creador_autonomo_odiseo.js'
assert creator.is_file() and 'OdiseoCreator' in creator.read_text(encoding='utf-8') and 'dependencies:[]' in creator.read_text(encoding='utf-8')
sensitivity=root/'app'/'src'/'main'/'assets'/'sensibilidad_odiseo.js'
assert sensitivity.is_file() and 'OdiseoSensitivity' in sensitivity.read_text(encoding='utf-8')
node=shutil.which('node')
if node:
    subprocess.run([node,str(root/'tests_odiseo_abch.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_espejo.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_acelerador.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_acertijo.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_evolucion.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_interaccion.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_convergencia.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_objetivo_evolutivo.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_sensibilidad.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_energia.js')],cwd=root,check=True)
    subprocess.run([node,str(root/'tests_odiseo_creador.js')],cwd=root,check=True)
else:
    print('AVISO: Node.js no está disponible; pruebas de ejecución JS omitidas.')
r=subprocess.run([sys.executable,str(root/'crear_apk_odiseo.py'),'--solo-preparar'],cwd=root,capture_output=True,text=True)
if r.returncode: print(r.stdout,r.stderr); raise SystemExit(r.returncode)
report=json.loads((root/'build-output'/'ODISEO_BUILD_REPORT.json').read_text())
assert report['build_status']=='PREPARADO'
assert len(report['module_sha256'])==64 and len(report['mirror_sha256'])==64 and len(report['accelerator_sha256'])==64 and len(report['riddle_sha256'])==64 and len(report['evolution_sha256'])==64 and len(report['interaction_sha256'])==64 and len(report['convergence_sha256'])==64 and len(report['moving_target_sha256'])==64 and len(report['sensitivity_sha256'])==64 and len(report['energy_sha256'])==64 and len(report['creator_sha256'])==64
print('OK: generador preparado; detector Android 53.4 de inactividad, motores y SHA-256 comprobados.')
