# Odiseo 55.2-alpha — voz conversacional

- Base: proyecto Android 55.1-alpha; estable global 53.2 sin cambios.
- Integración: `SpeechRecognizer` con idioma es-ES, preferencia offline y selección de reconocimiento on-device cuando Android 13+ lo declara disponible; permiso `RECORD_AUDIO` en tiempo de ejecución.
- Salida: `TextToSpeech` con `Locale("es", "ES")`; botones para iniciar escucha y activar/desactivar voz.
- Flujo: la transcripción entra en el chat existente; el asistente usa su despacho y, si un modelo LiteRT-LM está cargado, el flujo de inferencia local ya presente. La respuesta se pronuncia.
- Limitación: la preferencia offline no garantiza reconocimiento sin red; depende del servicio y paquete de idioma del dispositivo. TTS español también depende de los datos de voz instalados.
- El chat sin modelo neuronal mantiene las capacidades deterministas documentadas; no se presenta como LLM general.
- No se ha ejecutado Gradle ni se ha producido/instalado APK en este entorno. Requiere JDK 17, Gradle 8.13, SDK 35 y validación del AAR LiteRT-LM 0.18.0.
