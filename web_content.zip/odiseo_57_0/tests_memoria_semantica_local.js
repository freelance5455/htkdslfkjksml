const fs=require('fs'),vm=require('vm'),assert=require('assert');
const store=new Map();const ctx={console,Date,Math,JSON,Number,String,Array,Object,Set,Map,RegExp,Error,Intl,localStorage:{getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('app/src/main/assets/memoria_semantica_local_odiseo.js','utf8'),ctx);
const m=ctx.OdiseoSemanticMemory;let passed=0;function t(name,fn){try{fn();passed++;console.log('PASS',name);}catch(e){console.error('FAIL',name,e.message);process.exitCode=1;}}
t('API local cargada',()=>assert(m&&m.version));
t('declara sin red ni modelo remoto',()=>{const d=m.describe();assert(d.limits.length>=4);});
let a,b;
t('añade observación tipada con fuente',()=>{a=m.add({type:'observation',state:'unverified',source:'sensor-A',text:'La temperatura del sensor A fue 21 grados',confidence:.7,tags:['temperatura']});assert.equal(a.type,'observation');});
t('añade hipótesis tipada',()=>{b=m.add({type:'hypothesis',state:'inconclusive',source:'analista',text:'La temperatura podría aumentar por radiación solar',confidence:.4});assert.equal(b.state,'inconclusive');});
t('rechaza registro sin procedencia',()=>assert.throws(()=>m.add({text:'sin fuente'})));
t('rechaza confianza fuera de rango',()=>assert.throws(()=>m.add({text:'x',source:'y',confidence:1.2})));
t('recuperación BM25 encuentra tema pertinente',()=>{const r=m.search('temperatura sensor',5);assert(r.length>=1&&r[0].id===a.id);});
t('revisión conserva ID y aumenta revisión',()=>{const r=m.revise(a.id,{state:'supported',context:'controlado'});assert.equal(r.id,a.id);assert.equal(r.revision,2);});
t('auditoría expone recuentos tipados',()=>{const s=m.stats();assert.equal(s.records,2);assert.equal(s.byType.observation,1);});
t('detección de estados opuestos requiere solapamiento',()=>{m.revise(a.id,{text:'La temperatura del sensor A por radiación solar fue 21 grados'});m.revise(b.id,{type:'result',state:'refuted',text:'La temperatura del sensor A no aumentó por radiación solar'});assert(m.candidates().length>=1);});
t('exportación incluye esquema y registros',()=>{const x=m.exportData();assert.equal(x.schema,'ODISEO_SEMANTIC_MEMORY_1');assert.equal(x.records.length,2);});
t('importación merge no duplica IDs',()=>{const x=m.exportData();const r=m.importData(x,'merge');assert.equal(r.total,2);});
t('eliminación por ID funciona',()=>{assert(m.remove(a.id));assert.equal(m.stats().records,1);});
t('búsqueda vacía no devuelve resultados',()=>assert.equal(m.search('',5).length,0));
console.log(`RESULT ${passed}/14 PASS`);if(passed!==14)process.exitCode=1;
