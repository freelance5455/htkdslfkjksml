# Validación Odiseo 53.5.1-alpha — corrección de inventario

Fecha: 2026-11-05
Rama: experimental, derivada de 53.5-alpha Offline Chat.
Versión estable global preservada: 53.2.

## Cambio real
Se comparó `ENGINE_KEYS` del asistente local con los exports globales reales de los scripts cargados por `index.html`. Se detectó que la lista original omitía APIs y contenía nombres no coincidentes. Se sustituyó por un inventario de 30 exports reales y se incrementó la versión interna del router a `0.1.1-alpha-inventory`.

## Verificación
- Suite previa del chat local: 6/6 PASS.
- Nueva suite de inventario: 4/4 PASS; 30 claves esperadas, todas detectadas en fixture, sin duplicados ni claves incorrectas; ausencias simuladas reflejadas correctamente.
- Batería existente: 34/34 suites PASS.
- Total tras incorporar la nueva suite: 35/35 suites PASS.
- El significado de `available` es estrictamente «API global presente», no integración funcional ni validación semántica.

## Límites
- El inventario es un contrato de nombres/exports basado en los scripts presentes en el HTML; no prueba todas las funciones de cada motor.
- El chat continúa siendo un router determinista, no un LLM.
- No se ha compilado APK, instalado en Android ni probado en WebView real.
- No se afirma que Odiseo funcione en segundo plano ni que tenga autonomía fuera de la ejecución solicitada.
- Versión estable global no modificada: 53.2.

## Próximo trabajo
1. Sustituir el inventario estático por un registro de capacidades con contratos explícitos por motor.
2. Añadir pruebas de presencia, firma de método y ejecución mínima por cada ruta que se exponga al chat.
3. No marcar «integrado» hasta observar llamadas reales y trazas completas.
4. Validar el chat en Chromium y Android WebView; después compilar APK en entorno Android.
