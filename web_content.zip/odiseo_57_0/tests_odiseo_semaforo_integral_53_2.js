'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const dir=path.join(__dirname,'app/src/main/assets'),html=fs.readFileSync(path.join(dir,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script src="([^"]+\.js)"><\/script>/g)].map(m=>m[1]);
const ctx={console,Date,Math,JSON,Set,Map,Array,Object,Number,String,Error,Promise,TextEncoder,crypto:require('crypto').webcrypto};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
for(const f of scripts)vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
(async()=>{
 const core=await ctx.OdiseoUnifiedCore.run();
 assert.equal(core.executed,25);assert.equal(core.failed,0);
 assert.equal(core.communication.audit.status,'COMMUNICATION_TRACE_CLEAN');
 assert.equal(core.communication.audit.summary.exchangeCount,25);
 assert.equal(core.communication.audit.summary.observedExchanges,25);
 assert.equal(core.semaphore.coverage.required,25);assert.equal(core.semaphore.coverage.covered,25);assert.equal(core.semaphore.coverage.missing,0);
 assert.equal(core.semaphore.color,'GREEN');assert.equal(core.semaphore.summary.issueCount,0);
 const names=new Set(core.communication.trace.exchanges.map(x=>x.to));
 assert.equal(names.size,25);for(const e of ctx.OdiseoUnifiedCore.engines)assert(names.has(e.name),`missing ${e.name}`);
 // Negative controls: omissions and corruption must close the semaphore.
 const base={requiredEngines:core.semaphore.coverage.required?ctx.OdiseoUnifiedCore.engines.map(x=>x.name):[],coveredEngines:[...names],communicationAudit:core.communication.audit,languageAudit:core.languageAudit,smokeAudit:{executed:core.executed,total:core.total,failed:0,missing:0}};
 assert.equal(ctx.OdiseoSemaphore.evaluate({...base,coveredEngines:[...names].slice(1)}).color,'RED');
 assert.equal(ctx.OdiseoSemaphore.evaluate({...base,communicationAudit:{status:'COMMUNICATION_FAILURES_FOUND',issues:[{severity:'HIGH'}]}}).color,'RED');
 assert.equal(ctx.OdiseoSemaphore.evaluate({...base,languageAudit:{failed:1}}).color,'RED');
 // Retain independent end-to-end flows already covered by the 53.0 audit.
 const input={traces:[{id:'a',source:'A',sourceFamily:'A',observation:'test A'},{id:'b',source:'B',sourceFamily:'B',observation:'test B',links:['a']}],claims:[],penelopeAsts:[{id:'ast-test',ast:{type:'binary',op:'sum',a:{type:'primitive',name:'x'},b:{type:'primitive',name:'y'}}}],integratorTasks:[{n:20}],judas:{domain:'general',block:'test',premises:['test'],attempted:[],constraints:[]}};
 const cycle=ctx.OdiseoIntegratedCycle.run(input);assert.equal(cycle.communication.audit.status,'COMMUNICATION_TRACE_CLEAN');assert.equal(cycle.communication.audit.summary.exchangeCount,5);
 const A=ctx.OdiseoCommunicationAuditor,T=A.createTrace('semaphore-duet-test'),D=ctx.OdiseoDuet,C=ctx.OdiseoCreator,P=ctx.OdiseoPenelope,G=ctx.OdiseoGrowth;
 const duet=D.run(D.initial(C,G,{seed:20261104}),C,P,G,{rounds:3,communicationTrace:T});assert.equal(duet.communication.audit.status,'COMMUNICATION_TRACE_CLEAN');assert.equal(duet.communication.audit.summary.exchangeCount,48);
 const report={suite:'ODISEO_SEMAPHORE_INTEGRAL_53_2',scriptsLoaded:scripts.length,smoke:{executed:core.executed,failed:core.failed},coreCommunication:{exchanges:core.communication.audit.summary.exchangeCount,observed:core.communication.audit.summary.observedExchanges,issues:core.communication.audit.summary.issueCount},language:core.languageAudit,semaphore:{color:core.semaphore.color,coverage:core.semaphore.coverage,summary:core.semaphore.summary},integratedCycle:cycle.communication.audit.summary,duet:duet.communication.audit.summary,negativeControls:'3/3 correctly force RED',verdict:'GREEN_WITH_EXPLICIT_SCOPE_LIMITS'};
 fs.mkdirSync(path.join(__dirname,'build-output'),{recursive:true});fs.writeFileSync(path.join(__dirname,'build-output','semaforo_integral_53_2.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
