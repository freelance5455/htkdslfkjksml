# Odiseo 53.4-alpha — Detector de inactividad Android

**Base:** ZIP real `ODISEO_53.3_ALPHA_TIC_1.2_20261104.zip`. Rama experimental; no sustituye la versión estable 53.2.

## Alcance de privacidad

El detector registra interacciones únicamente dentro de la aplicación Odiseo. No monitoriza ChatGPT, otras aplicaciones, el teclado del sistema ni la actividad global del teléfono. No registra el contenido escrito; solo actualiza una marca temporal.

## Diseño implementado

- Umbral fijo de 30 minutos (`InactivityPolicy.TIMEOUT_MS = 1,800,000`).
- Registro persistente del último evento de usuario en `SharedPreferences`.
- `AlarmManager.setAndAllowWhileIdle(RTC_WAKEUP, ...)` con `PendingIntent` explícito; no requiere permiso de alarmas exactas.
- `InactivityReceiver` registra un marcador de recuperación y añade un evento a `files/ODISEO_INACTIVITY_EVENTS.jsonl`.
- `InactivityBootReceiver` reconstruye el temporizador tras reiniciar Android.
- Comprobación adicional al abrir/volver a primer plano y cada minuto mientras la Activity permanece visible.
- La WebView comunica pulsaciones, toques, entradas, cambios y envíos al puente nativo.
- Al volver a la interfaz, Odiseo comprueba la cadena de hashes del diario local, la validez JSON del almacenamiento y la presencia de APIs de motores.
- El informe se guarda en almacenamiento privado de la aplicación como `ODISEO_AUDITORIA_INACTIVIDAD.json`, con SHA-256 calculado en Android, y un registro JSONL. También se añade al diario exportado por ODISEO SAVE.
- La pantalla muestra el resultado y ofrece generar el ZIP verificado mediante el selector SAF existente.

## Ciclo operativo

1. Cada interacción renueva el reloj y sustituye la alarma anterior.
2. A los 30 minutos sin interacción, Android marca la sesión para recuperación.
3. La auditoría completa se ejecuta al estar disponible la interfaz; no se ejecutan los motores de investigación en segundo plano.
4. Si el proceso estaba detenido, la alarma o la comprobación al siguiente inicio recuperan el evento pendiente.
5. El usuario puede exportar el estado, diario e informe de auditoría mediante ODISEO SAVE.

## Límites de Android

- `setAndAllowWhileIdle` puede retrasarse por Doze, ahorro de batería, restricciones del fabricante o políticas del sistema. El umbral es 30 minutos como condición mínima, no una garantía de ejecución en el milisegundo exacto.
- Android cancela alarmas al forzar la detención de una aplicación. Al volver a abrirla, la comprobación del timestamp detecta la pausa transcurrida.
- La auditoría de recuperación se ejecuta al volver a primer plano, no en el proceso de alarma, porque el `BroadcastReceiver` no debe intentar levantar una WebView ni una Activity en segundo plano.
- El archivo privado de auditoría no es por sí solo una copia externa: para conservarla fuera del sandbox de la app, se debe exportar el ZIP SAF a `Descargas/Odiseo/`.
- No se ha compilado ni instalado la APK en un teléfono en este entorno.

## Pruebas previstas/ejecutadas en esta entrega

- Prueba pura de política: 29:59 no dispara; 30:00 dispara; 31:00 dispara; reloj hacia atrás no dispara; tiempo restante correcto; primera ejecución inicializa el reloj.
- Preparación del generador comprueba fuentes Java, receptores del manifiesto, UI, persistencia de informe y hashes.
- Regresión JavaScript heredada se ejecuta mediante `probar_generador.py`.
- La compilación Android y la prueba real de alarma, reinicio, ahorro de batería y SAF requieren Android SDK/Gradle y dispositivo físico; no se declaran superadas aquí.
