'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const store = new Map();
const ctx = {
  console, Date, Math, JSON, Promise,
  localStorage: {
    getItem: k => store.get(k) || null,
    setItem: (k,v) => store.set(k,v),
    removeItem: k => store.delete(k)
  }
};
ctx.window = ctx;
ctx.OdiseoNative = {
  isLocalModelReady: () => true,
  generateLocal: (prompt, id) => {
    assert.match(prompt, /MENSAJE DEL USUARIO/);
    ctx.odiseoOnLocalModelResult(id, 'Respuesta neuronal de prueba.', '');
  }
};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/asistente_local_odiseo.js','utf8'), ctx);
(async () => {
  const result = await ctx.OdiseoLocalAssistant.reply('Explícame qué es una hipótesis.');
  assert.equal(result.meta.kind, 'local-neural-model');
  assert.equal(result.meta.verified, false);
  assert.match(result.text, /Respuesta neuronal de prueba/);
  assert.match(result.text, /no verificado automáticamente/);
  console.log('PASS 4/4 — enrutamiento a modelo local, callback, etiqueta de no verificado y retorno');
})().catch(e => { console.error(e); process.exit(1); });
