'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');
const store=new Map();let captured='';
const ctx={console,Date,Math,JSON,Promise,document:{getElementById:()=>null},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;
ctx.OdiseoSemanticMemory={search:()=>[{id:'mem-c1',text:'La hipótesis de Collatz requiere pruebas',type:'hypothesis',state:'unverified',source:'usuario',score:1.5}]};
ctx.OdiseoReasoningCore={};ctx.OdiseoNative={isLocalModelReady:()=>true,generateLocal:(prompt,id)=>{captured=prompt;ctx.odiseoOnLocalModelResult(id,'Podemos formular una hipótesis y buscar contraejemplos.','');}};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/cerebro_cognitivo_odiseo.js','utf8'),ctx);
vm.runInNewContext(fs.readFileSync('app/src/main/assets/asistente_local_odiseo.js','utf8'),ctx);
(async()=>{const r=await ctx.OdiseoLocalAssistant.reply('Investiga una hipótesis sobre Collatz');assert.equal(r.meta.kind,'local-neural-model');assert.match(captured,/mem-c1|La hipótesis de Collatz/);assert.match(captured,/Núcleo de razonamiento local/);assert.equal(r.meta.verified,false);assert.ok(r.meta.brain.tracePersisted);assert.equal(ctx.OdiseoCognitiveBrain.traces().length,1);console.log('PASS 6/6 — cerebro cognitivo conectado al chat y al runtime neuronal simulado');})().catch(e=>{console.error(e);process.exit(1)});
