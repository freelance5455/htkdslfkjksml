# Odiseo 53.1 — Lenguaje común para formular preguntas y evaluar respuestas

## Objetivo
Establecer un vocabulario compartido y un formato explícito para que motores y usuarios puedan formular preguntas precisas, devolver respuestas trazables y evaluar la calidad estructural de esas respuestas.

## 1. Vocabulario controlado

### Intención (`intent`)
- `DEFINE`: definir un concepto.
- `EXPLAIN`: explicar un mecanismo o relación.
- `COMPARE`: comparar alternativas con criterios comunes.
- `PROVE`: demostrar mediante una prueba válida.
- `REFUTE`: refutar mediante contraejemplo o contradicción.
- `TEST`: ejecutar una prueba reproducible.
- `FIND`: localizar información o candidatos.
- `DESIGN`: diseñar un método o sistema.
- `SUMMARIZE`: condensar información sin perder condiciones relevantes.
- `DECIDE`: elegir según criterios explícitos.
- `CLASSIFY`: asignar categorías justificadas.
- `PREDICT`: estimar resultados futuros, declarando incertidumbre.

### Operación (`operation`)
`DESCRIBE`, `CALCULATE`, `TRACE`, `VALIDATE`, `CONTRAST`, `INFER`, `GENERATE`, `MEASURE`, `AUDIT`, `OPTIMIZE`.

### Estados epistémicos para el contenido
- `FACT`: hecho verificado por evidencia suficiente dentro del alcance declarado.
- `HYPOTHESIS`: proposición pendiente de contraste.
- `INFERENCE`: conclusión derivada de premisas declaradas.
- `ASSUMPTION`: premisa adoptada provisionalmente.
- `SPECULATION`: posibilidad exploratoria no demostrada.
- `UNKNOWN`: no se conoce o no se puede determinar.

### Estado de respuesta (`status`)
`SUPPORTED`, `PARTIAL`, `UNSUPPORTED`, `CONTRADICTED`, `UNKNOWN`, `BLOCKED`.

### Tipo de evidencia
`SOURCE`, `DATA`, `CALCULATION`, `EXPERIMENT`, `PROOF`, `COUNTEREXAMPLE`, `OBSERVATION`, `NONE`.

## 2. Sintaxis ODQ / ODA

Los campos se separan por punto y coma. Los valores se escriben entre comillas. Una barra inversa permite escapar comillas, barras y punto y coma.

### ODQ — Odiseo Question

```text
ODQ{id="Q-001"; intent="EXPLAIN"; subject="auditor de comunicación"; operation="AUDIT"; scope="ciclo integrado 53.1"; evidence="trazas y pruebas"; constraints="no modificar motores"; output="informe"; stop="cuando se revisen todos los intercambios"}
```

Campos:
- `id`: identificador único de pregunta.
- `intent`: qué clase de respuesta se busca.
- `subject`: objeto concreto de la pregunta.
- `operation`: operación requerida.
- `scope`: límites temporales, matemáticos, documentales o funcionales.
- `evidence`: evidencia requerida o `NONE`.
- `constraints`: restricciones y condiciones que no deben vulnerarse.
- `output`: formato esperado.
- `stop`: condición explícita de terminación.

### ODA — Odiseo Answer

```text
ODA{questionId="Q-001"; status="PARTIAL"; claim="El auditor revisa intercambios instrumentados"; result="Se detectan incidencias estructurales"; evidence="TRACE-001; TEST-004"; method="validación de contratos"; uncertainty="cobertura incompleta"; limits="no demuestra verdad semántica"}
```

Campos:
- `questionId`: pregunta respondida; debe coincidir con `ODQ.id`.
- `status`: grado de respaldo declarado.
- `claim`: afirmación principal.
- `result`: resultado concreto.
- `evidence`: referencias verificables o `NONE`.
- `method`: procedimiento aplicado.
- `uncertainty`: incertidumbre residual.
- `limits`: límites y condiciones de validez.

## 3. Reglas de comunicación

1. Una pregunta debe tener intención, sujeto, operación y alcance delimitados.
2. Una respuesta debe enlazar con el identificador de la pregunta.
3. No usar `SUPPORTED` si no se declaran evidencias; el auditor emite alerta.
4. Diferenciar `FACT`, `HYPOTHESIS`, `INFERENCE`, `ASSUMPTION`, `SPECULATION` y `UNKNOWN`.
5. Toda cifra debe indicar unidad, población/intervalo y método cuando corresponda.
6. Toda comparación debe declarar criterios comunes.
7. Toda afirmación negativa debe declarar qué se buscó y hasta dónde.
8. Los errores deben devolverse como errores, no como resultados vacíos aparentemente válidos.
9. Una respuesta parcial debe indicar qué parte queda sin resolver.
10. La condición de parada debe evitar ciclos indefinidos.

## 4. Evaluación

El módulo `OdiseoQuestionLanguage` valida campos, códigos controlados, correspondencia de IDs y ocho dimensiones estructurales con ponderación explícita. La puntuación evalúa la completitud y trazabilidad declarada; **no mide la verdad, la pertinencia semántica ni la calidad real de una prueba**. El resultado incluye siempre `semanticTruth: NOT_EVALUATED`.

La escala es orientativa: 85–100 estructuralmente fuerte; 60–84 parcial; menos de 60 débil. Una alerta de severidad alta fuerza `REVIEW_REQUIRED` aunque la puntuación sea alta.

## 5. API JavaScript

- `parse(text)`: analiza ODQ u ODA.
- `format(kind, fields)`: serializa campos de forma estable.
- `normalizeQuestion(input)` / `normalizeAnswer(input)`.
- `validateQuestion(input)` / `validateAnswer(input)`.
- `evaluate(question, answer)`: devuelve puntuación, dimensiones, incidencias y límites.
- `vocabulary`: vocabulario controlado para que otros motores compartan los mismos términos.

## 6. Límites y siguiente paso

El lenguaje es un protocolo declarativo local, no un modelo de lenguaje natural ni un traductor automático de cualquier pregunta libre. Los motores deben adoptar ODQ/ODA mediante adaptadores graduales. La validación de formato no prueba que la respuesta conteste realmente la pregunta; esa comprobación exige evaluación semántica independiente y conjuntos etiquetados. No se cambian automáticamente criterios ni código de otros motores.
