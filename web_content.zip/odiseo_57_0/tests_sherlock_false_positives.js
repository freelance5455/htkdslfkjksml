const assert=require('assert'),fs=require('fs'),vm=require('vm');
vm.runInThisContext(fs.readFileSync(__dirname+'/app/src/main/assets/sherlock_odiseo.js','utf8'));
const S=globalThis.OdiseoSherlock;
const candidates=traces=>S.investigate({traces,strategyBudget:8}).investigation.candidates;
// Positivo conocido: dos secuencias comparten tres diferencias raras.
const positive=[{id:'a',observation:'serie 100 104 109 115 130'},{id:'b',observation:'serie 500 504 509 515 900'},{id:'noise',observation:'ruido 3 88 191'}];
assert(candidates(positive).some(c=>c.from==='a'&&c.to==='b'&&c.method==='numeric-difference-pattern'));
// Negativo: 40 rastros con diferencias ubicuas; no deben enlazarse por ese patrón.
const ubiquitous=Array.from({length:40},(_,i)=>({id:'u'+i,observation:`registro ${i} ${i*100} ${i*100+14} ${i*100+38}`}));
assert(!candidates(ubiquitous).some(c=>c.method==='numeric-difference-pattern'));
// Negativo: valores numéricos aislados compartidos no bastan.
const overlap=Array.from({length:40},(_,i)=>({id:'c'+i,observation:`registro ${i} ${i*101+3} ${i*101+17} ${i*101+41}`}));
assert(candidates(overlap).filter(c=>c.method==='numeric-overlap').length<=2);
console.log('Sherlock false-positive tests: 3/3 passed');
