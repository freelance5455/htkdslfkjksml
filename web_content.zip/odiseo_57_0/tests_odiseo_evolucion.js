const fs=require('fs'),vm=require('vm');const context={window:{}};
for(const f of ['espejo_odiseo.js','acelerador_odiseo.js','acertijo_odiseo.js','evolucion_odiseo.js'])vm.runInNewContext(fs.readFileSync(__dirname+'/app/src/main/assets/'+f,'utf8'),context);
const {OdiseoMirror:m,OdiseoEvolution:e}=context.window;function ok(x,msg){if(!x)throw Error(msg)}
const out=e.evolve('origen retorno infinito',m.empty(),{rounds:2,maxGenerated:6});
ok(out.generations[0].kind==='seed','Debe conservar el acertijo inicial');
ok(out.generatedQuestions>0,'Debe crear preguntas derivadas');
ok(out.generations.slice(1).every(x=>x.kind==='derived_question'||x.kind==='generation_rejected'),'Las generaciones deben tener tipo explícito');
ok(out.generations.filter(x=>x.kind==='derived_question').every(x=>x.particles>0&&x.collisions>0),'Cada acertijo derivado debe generar partículas y colisiones');
ok(out.graph.nodes.length>m.empty().nodes.length,'El Espejo debe recibir información generada');
ok(out.graph.edges.some(x=>x.evidence.includes('Pregunta generada automáticamente')),'Debe conservar procedencia entre acertijos');
ok(out.rounds<=2&&out.generatedQuestions<=6,'Debe respetar el presupuesto de evolución');
ok(out.generations.slice(1).every(x=>x.question.length<=3000),'Preguntas dentro del límite del motor');
let failed=false;try{e.evolve('semilla',m.empty(),{rounds:4,maxGenerated:2})}catch(x){failed=true}ok(failed,'Debe rechazar rondas fuera de límite');
failed=false;try{e.evolve('semilla',m.empty(),{rounds:1,maxGenerated:9})}catch(x){failed=true}ok(failed,'Debe rechazar presupuestos fuera de límite');
const hist=e.validateHistory([{id:'e1',seed:'x',generations:[],rounds:0}]);ok(hist.length===1,'Debe validar historial');
const repeat=e.evolve('origen retorno infinito',m.empty(),{rounds:2,maxGenerated:6});ok(repeat.fingerprint===out.fingerprint,'La evolución debe ser reproducible salvo IDs internos del grafo');
console.log('OK: 11 comprobaciones del Motor de Evolución superadas.');
