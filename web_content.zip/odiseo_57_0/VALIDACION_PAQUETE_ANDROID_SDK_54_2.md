# Validación del paquete Android SDK — Odiseo 54.2 Alpha

- Base de código: `ODISEO_54.2_ALPHA_NEURAL_RUNTIME_HARDENED_20261106.zip`.
- SHA-256 base verificado: `dfec40b966f5e76c1888f3d3ce6404dec346874331a6f07d98a82bf237c476a1`.
- ZIP base: CRC íntegro.
- `app/build.gradle`: versionCode 542 / versionName 54.2-alpha-neural-runtime-hardening.
- compileSdk 35 / minSdk 24 / targetSdk 35.
- Android Gradle Plugin 8.13.2; Gradle esperado 8.13; JDK 17.
- LiteRT-LM Android 0.18.0; coroutines Android 1.11.0.

## No verificado todavía

- No se ejecutó Gradle assembleDebug en este entorno.
- No se compiló contra el AAR real de LiteRT-LM.
- No se generó ni instaló APK.
- No se importó un modelo `.litertlm` ni se probó inferencia offline.

El cambio de versionCode/versionName es metadato del paquete Android para identificar 54.2; no constituye una validación de compilación.


## Derivación 55.0-alpha (2026-11-12)

El paquete 54.2 se conserva como base histórica. La rama 55.0 modifica el detector adaptativo y añade regresiones; no cambia la dependencia LiteRT-LM ni declara build Android. La validación reproducida de 55.0 es: 46/46 suites Node PASS, 8/8 pruebas estáticas Android PASS, sintaxis de todos los assets JS PASS, benchmark sintético 28 casos TP=19/FP=0/FN=0/TN=317, regresiones nuevas 10/10 PASS. `gradle` y Android SDK no están disponibles en este entorno; no se ha generado APK.
