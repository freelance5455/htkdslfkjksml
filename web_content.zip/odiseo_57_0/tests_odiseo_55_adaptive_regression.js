'use strict';
// Odiseo 55.0: regresiones de precisión del detector adaptativo conservador.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const storage=new Map();
const ctx={Date,Math,JSON,Array,Object,String,Number,Error,Set,Map,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)}};
ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'app/src/main/assets/patron_adaptativo_odiseo.js'),'utf8'),ctx);
const A=ctx.OdiseoAdaptivePattern;
assert.match(A.version,/55\.0/);
function ids(question,answer=''){const r=A.inspect({question,answer});return [...r.plan.questionIssues,...r.plan.answerIssues].map(x=>x.id);}
// Negativos difíciles: una palabra mencionada no debe activar por sí sola una alerta.
assert.deepEqual(ids('Explica qué es la función de algo en este programa.','La función transforma la entrada en una salida.'),[]);
assert.deepEqual(ids('¿Qué significa la palabra quizá en una frase?','Expresa posibilidad o duda.'),[]);
assert.deepEqual(ids('Compara dos métodos de búsqueda de forma neutral.','El primero recorre una lista; el segundo usa un índice.'),[]);
assert.deepEqual(ids('Describe el sistema y todos sus componentes principales.','El sistema contiene tres componentes descritos a continuación.'),[]);
assert.deepEqual(ids('¿Cómo funciona una contraseña de un solo uso?','Es un código temporal de autenticación.'),[]);
// Separación correcta de pregunta ausente y respuesta aislada.
assert.deepEqual(ids('','Está garantizado que el resultado es correcto.'),['unsupported_answer']);
// Señales positivas y límites deliberados.
assert.deepEqual(ids('¿Y eso?'),['ambiguity','short_query']);
assert.deepEqual(ids('Puedes hacer eso mismo?'),['missing_context']);
assert.deepEqual(ids('Explica con detalle la razón matemática.','Sí.'),['possibly_shallow']);
assert.deepEqual(ids('Protege esta contraseña privada y no la publiques.'),['safety']);
console.log('ODISEO 55.0 ADAPTIVE REGRESSION: 10/10 PASS');
