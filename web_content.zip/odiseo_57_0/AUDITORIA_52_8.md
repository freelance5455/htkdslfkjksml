# Auditoría Odiseo 52.8 — Patrón adaptativo pregunta/respuesta

## Objetivo
Crear un patrón adaptativo que detecte problemas tanto en la pregunta/solicitud como en la respuesta candidata y recomiende una estrategia de resolución, conservando los criterios y normas de los motores.

## Implementación
- Nuevo módulo `app/src/main/assets/patron_adaptativo_odiseo.js` (`OdiseoAdaptivePattern`).
- Inspección bidireccional: pregunta y respuesta se examinan por separado.
- Señales iniciales: ambigüedad, contexto insuficiente, contradicción, necesidad de prueba, incertidumbre, complejidad, seguridad/restricciones, posible respuesta incompleta, afirmaciones sin respaldo e inconsistencias.
- Selector de modo: `DIRECT`, `CAREFUL`, `CLARIFY_OR_STATE_ASSUMPTIONS`, `VERIFY`, `DECOMPOSE`, `GUARDED`.
- Enrutamiento sugerido hacia Penélope, OIE, Integrador E, Sherlock, Judas Tadeo, núcleo unificado, H, resolvedor de contexto o control de seguridad.
- Registro de feedback (`HELPFUL`, `UNHELPFUL`, `FALSE_POSITIVE`, `MISSED_ISSUE`, `CORRECTED`) con contadores por tipo de problema.
- Integración con la interfaz Android/web local y con `OdiseoUnifiedCore.run({question,answer})`.
- Feedback modifica estadísticas y prioridad de revisión, no los criterios internos ni el código de los motores.

## Principios preservados
- No modifica código automáticamente.
- No promueve hipótesis a hechos.
- No sustituye verificadores de dominio.
- Las señales léxicas son heurísticas; no prueban comprensión semántica ni corrección factual.
- Persistencia local informa explícitamente si `localStorage` confirmó el guardado.

## Pruebas
- `node tests_odiseo_patron_adaptativo.js`: superado.
- Todas las baterías `tests_*.js` del proyecto: superadas.
- `node --check` en todos los módulos JavaScript: superado.
- `py_compile` de generador, guardado y pruebas: superado.
- `python probar_generador.py`: preparación del generador superada.
- APK: no compilada ni instalada.

## Limitaciones y trabajo pendiente
1. El detector actual usa señales léxicas y reglas transparentes; necesita un conjunto de evaluación etiquetado para medir precisión/recall y ajustar umbrales.
2. Las rutas se recomiendan; no todas invocan automáticamente los motores. La orquestación ejecutable de cada ruta debe incorporarse por contratos específicos y pruebas.
3. El feedback se guarda localmente; no se sincroniza entre dispositivos ni constituye entrenamiento de parámetros del modelo.
4. No se afirma adaptación semántica general, aprendizaje autónomo ni crecimiento exponencial.
5. Debe añadirse evaluación ciega de falsos positivos, falsos negativos y regresiones antes de modificar umbrales.

## Resultado
Odiseo 52.8 añade una capa adaptativa explícita para seleccionar estrategias según señales detectadas en preguntas y respuestas. Es un mecanismo de adaptación de flujo y revisión, no una modificación automática de la inteligencia de los motores.
