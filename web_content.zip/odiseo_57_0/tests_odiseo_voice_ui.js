const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const java = fs.readFileSync(path.join(root, 'app/src/main/java/org/odiseo/app/MainActivity.java'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const manifest = fs.readFileSync(path.join(root, 'app/src/main/AndroidManifest.xml'), 'utf8');
test('Android voice conversation wiring', async t => {
  await t.test('declares runtime microphone permission', () => assert.match(manifest, /android\.permission\.RECORD_AUDIO/));
  await t.test('declares Android speech recognition service query', () => assert.match(manifest, /android\.speech\.RecognitionService/));
  await t.test('uses Spanish speech recognition and prefers offline', () => {
    assert.match(java, /RecognizerIntent\.EXTRA_LANGUAGE, "es-ES"/);
    assert.match(java, /RecognizerIntent\.EXTRA_PREFER_OFFLINE, true/);
  });
  await t.test('prefers on-device recognizer when available', () => assert.match(java, /isOnDeviceRecognitionAvailable/));
  await t.test('initializes Spanish text to speech', () => {
    assert.match(java, /new TextToSpeech/);
    assert.match(java, /new Locale\("es", "ES"\)/);
  });
  await t.test('supports stopping recognition and prevents duplicate listening', () => {
    assert.match(java, /@JavascriptInterface public void stopListening\(\)/);
    assert.match(java, /if \(speechListening\)/);
    assert.match(html, /id="odiseoVoiceStop"/);
  });
  await t.test('handles recognition errors and does not silently truncate long speech', () => {
    assert.match(java, /speechErrorLabel\(int error\)/);
    assert.match(java, /while \(offset < normalized\.length\(\)\)/);
    assert.match(java, /TextToSpeech\.QUEUE_ADD/);
  });
  await t.test('voice buttons and bridge callbacks are connected to chat', () => {
    assert.match(html, /id="odiseoVoiceListen"/);
    assert.match(html, /id="odiseoVoiceToggle"/);
    assert.match(html, /odiseoVoiceStop/);
    assert.match(html, /odiseoOnSpeechResult=function\(text\)/);
    assert.match(html, /OdiseoNative\.speak\(r\.text\)/);
  });
});
