# Validación Odiseo 53.8-alpha — Memoria semántica local

Fecha: 2026-11-05. Base: 53.7-alpha. Rama experimental; 53.2 sigue siendo la versión estable global.

## Implementación
- Nuevo `app/src/main/assets/memoria_semantica_local_odiseo.js`, API `OdiseoSemanticMemory`.
- Registros tipados: observation, hypothesis, inference, result, source y note.
- Estados: unverified, supported, refuted, inconclusive y verified.
- Procedencia obligatoria; confianza opcional validada entre 0 y 1; etiquetas y contexto.
- Recuperación BM25 local; revisión versionada; borrado por ID; estadísticas; detección de candidatos de conflicto; exportación/importación JSON merge/replace, con panel de copia de seguridad en la interfaz.
- Integración en `index.html`, `asistente_local_odiseo.js` y comprobación del generador APK.

## Pruebas
- `tests_memoria_semantica_local.js`: 14/14 PASS.
- `tests_asistente_memoria_semantica.js`: 3/3 PASS.
- Regresión: 41/41 suites `tests_*.js`, 0 fallos.
- Sintaxis: 34/34 assets JavaScript.
- `python probar_generador.py`: PASS (8/8 política de inactividad y 8 motores smoke incluidos en la rutina).
- `python crear_apk_odiseo.py --solo-preparar`: PREPARADO; no equivale a compilar la APK.
- Sintaxis de 36/36 bloques JavaScript inline HTML: PASS.
- `py_compile`: PASS.

## Límites
- BM25 es búsqueda léxica, no embeddings ni comprensión semántica general.
- La búsqueda puede fallar con paráfrasis y vocabulario distinto.
- Las etiquetas `verified`/`supported` no se verifican automáticamente.
- Los conflictos detectados son candidatos heurísticos y requieren revisión humana.
- `localStorage` puede borrarse al limpiar datos de la app; no hay sincronización entre dispositivos.
- No se usa GPT ni red.
- APK no compilada, instalada ni probada físicamente.
