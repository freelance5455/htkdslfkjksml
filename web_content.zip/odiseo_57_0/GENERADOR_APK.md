# ODISEO APK Builder 1.0

## Qué hace
- Recibe un módulo `algoritmo_odiseo.js` que expone `window.OdiseoAlgorithm`.
- Lo incorpora a `app/src/main/assets/`.
- Prepara o ejecuta `gradle assembleDebug`.
- Si la compilación termina correctamente, copia la APK a `build-output/` y genera `ODISEO_BUILD_REPORT.json` con SHA-256.

## Preparar en local
Requisitos para compilar: Java 17, Gradle 8.7 y Android SDK configurado.

```bash
python crear_apk_odiseo.py --solo-preparar
python crear_apk_odiseo.py --algoritmo ./mi_algoritmo.js --nombre Odiseo
```

La primera orden valida el módulo y genera el informe de preparación. La segunda incorpora el módulo y compila la APK debug. Si no tienes SDK/Gradle en el teléfono, usa el workflow **Build Odiseo Android APK** en GitHub Actions: sube el proyecto a un repositorio, abre Actions, ejecuta el workflow y descarga el artefacto `odiseo-android-debug`.

## Contrato del módulo
El archivo debe declarar `window.OdiseoAlgorithm` con `describe()` y `run(input)`. La plantilla incluida devuelve `NOT_IMPLEMENTED` intencionadamente. Sustitúyela por lógica real y pruebas antes de usarla como motor.

## Límites honestos
- Este generador construye una aplicación Android desde código fuente; no convierte automáticamente una idea en un algoritmo correcto.
- No implementa por sí solo los motores A/B/C/H ni demuestra Collatz.
- La APK `debug` no está firmada para distribución comercial. Para publicar se necesita configurar firma de release y proteger la clave privada fuera del repositorio.
- No se afirma compilación hasta que Gradle produzca el APK y el artefacto sea verificado.


## Motor A/B/C/H de la versión 50.0
El módulo de algoritmo ya no es una plantilla vacía. Implementa una auditoría acotada de Syracuse acelerada: A propone invariantes, B busca contraejemplos, C contrasta los resultados mediante una segunda implementación y H administra el presupuesto y la parada. La interfaz del WebView permite ejecutar el experimento. Las pruebas se ejecutan con `node tests_odiseo_abch.js` y `python probar_generador.py`. Esto no demuestra Collatz ni constituye aprendizaje autónomo.


## 50.1 Espejo Bidireccional
La aplicación carga también `app/src/main/assets/espejo_odiseo.js`. El generador valida que `OdiseoMirror` exista y registra su SHA-256 en el informe. Ambos módulos se empaquetan como assets Android junto con `index.html`.


## Odiseo 50.2
El generador comprueba ahora tres módulos: A/B/C/H, Espejo Bidireccional y Acelerador Matemático (`acelerador_odiseo.js`). Calcula SHA-256 de los tres. La preparación no equivale a compilar ni instalar una APK.

## Odiseo 50.4
El generador valida también `evolucion_odiseo.js` (API `window.OdiseoEvolution`) y calcula su SHA-256 junto a los otros cuatro módulos. Requiere Java 17, Gradle 8.7 y Android SDK para compilar.


## Odiseo 50.8 — Motor de Objetivo Evolutivo

Se incorpora `objetivo_evolutivo_odiseo.js`: el objetivo sigue el mapa logístico `x[n+1]=r*x[n]*(1-x[n])` y el perseguidor `y` se adapta mediante una ganancia acotada. El motor informa rangos, error final y una clasificación heurística. Las ventanas finitas no prueban caos, periodicidad asintótica ni estabilidad global. El generador APK valida y calcula SHA-256 del nuevo módulo.


La validación 50.9 comprueba también el módulo `sensibilidad_odiseo.js` (`window.OdiseoSensitivity`) y calcula su SHA-256 junto con los motores anteriores. La preparación no compila ni instala la APK.

## Módulos 51.1

El generador valida `energia_odiseo.js` y `investigacion_odiseo.js`, y registra sus SHA-256 en el informe de preparación. El nuevo ciclo A/B/C/H se incluye en assets Android y en el panel. La preparación no equivale a compilación: la APK sigue pendiente hasta ejecutar Gradle con Java 17 y Android SDK.


## Odiseo 51.2 — Núcleo Creador Autónomo

Incluir y verificar `app/src/main/assets/creador_autonomo_odiseo.js`. Este módulo es autocontenido y no debe importar ni invocar otros motores, APIs, red o modelos externos. El builder incorpora su SHA-256 al informe. Ejecutar `tests_odiseo_creador.js` y la batería completa. El núcleo genera estructuras simbólicas desde primitivas internas, con presupuesto y archivo limitados; no equivale a comprensión semántica, conciencia ni autoprogramación.


## Módulos 51.3

El generador valida también `penelope_odiseo.js` y `crecimiento_exponencial_odiseo.js`, y registra sus SHA-256. La preparación no equivale a compilación.

En Odiseo 51.4, el generador también valida `duelo_odiseo_penelope.js` (`window.OdiseoDuet`) y registra su SHA-256 en el informe de preparación. La preparación no equivale a compilar ni instalar una APK.


## Comprobaciones añadidas en 52.5
El preparador comprueba ahora `integrador_evidencias_odiseo.js`, `ciclo_integrado_odiseo.js` y el panel `runIntegratedCycleUI` en `index.html`, e incluye sus SHA-256 en el informe de preparación. Esto solo verifica preparación e inclusión; no significa que Gradle haya compilado o que el APK se haya instalado.
