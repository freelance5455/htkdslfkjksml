# Odiseo 54.1-alpha — Cerebro cognitivo local

Fecha: 2026-11-05. Base: 54.0-alpha (derivada de 53.9-alpha). Versión estable global: 53.2, intacta.

## Objetivo
Integrar los motores locales existentes en un ciclo de trabajo que pueda alimentar un modelo neuronal ejecutado en el propio Android, sin GPT ni llamadas remotas.

## Arquitectura implementada
1. **Interpretación:** clasificación heurística del objetivo (ingeniería, análisis, investigación, continuidad, verificación, explicación o general).
2. **Memoria:** recuperación BM25 de la memoria semántica local; conserva ID, tipo, estado epistémico y fuente. Los recuerdos se consideran contexto falible.
3. **Planificación:** prepara pasos explícitos y candidatos de herramientas según la intención.
4. **Selección y ejecución acotada:** detecta candidatos (Núcleo de razonamiento, Sherlock, Penélope, Judas Tadeo, TIC, laboratorio de loterías, semáforo). Ejecuta únicamente `OdiseoReasoningCore.analyze` cuando está disponible; los demás quedan como candidatos disponibles/no ejecutados hasta tener adaptadores probados.
5. **Generación:** compone un prompt con reglas epistemológicas, contexto recuperado e inventario para el runtime LiteRT-LM de 54.0-alpha.
6. **Auditoría:** detecta heurísticamente lenguaje de certeza excesiva y afirmaciones de acciones; no verifica hechos.
7. **Registro:** conserva hasta 120 trazas locales con objetivo, candidatos, IDs de memoria y estado de auditoría.

## Archivos principales
- `app/src/main/assets/cerebro_cognitivo_odiseo.js`
- `app/src/main/assets/asistente_local_odiseo.js`
- `app/src/main/assets/index.html`
- `tests_cerebro_cognitivo_odiseo.js`
- `ESTADO_ODISEO.json`, `DIARIO_ODISEO.json`, `ODISEO_CONTINUIDAD_MAESTRA.md`

## Pruebas ejecutadas
- Pruebas específicas del cerebro: 12/12 PASS.
- Suites Node del paquete: 45/45 PASS.
- Integración chat-cerebro con runtime simulado: 6/6 PASS.
- Sintaxis de assets JavaScript: 35/35 PASS.
- JSON de estado, diario y manifiesto: validación prevista en empaquetado.

## Límites y pendientes
- Clasificación de intención heurística.
- BM25 es recuperación léxica, no embeddings ni comprensión semántica.
- Seleccionar una herramienta no significa ejecutarla.
- Auditoría heurística no demuestra verdad factual ni causalidad.
- No hay entrenamiento autónomo de pesos ni modificación automática del código.
- El runtime Kotlin LiteRT-LM 0.18.0 procede de 54.0-alpha; su compatibilidad con el AAR real no está verificada mediante build Android.
- No hay APK compilada, instalación ni prueba física en teléfono.
- Se debe importar un modelo `.litertlm` compatible y probar conversación offline, memoria, trazas, consumo y estabilidad.

## Estado
**CEREBRO COGNITIVO LOCAL IMPLEMENTADO EN CÓDIGO Y VALIDADO EN NODE; BUILD ANDROID Y MODELO REAL PENDIENTES.**
