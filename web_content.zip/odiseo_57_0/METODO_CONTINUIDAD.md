# ODISEO SAVE — método único de continuidad

## Objetivo
Que Odiseo pueda cerrarse y retomarse sin depender de recordar una conversación. El proyecto se conserva en archivos; la memoria conversacional sirve de índice, nunca de única copia.

## Regla de simplicidad: 1–1–1–1
- **1 fuente de verdad:** el directorio del proyecto y su `ESTADO_ODISEO.json`.
- **1 diario:** el registro cronológico de decisiones, experimentos, fallos y correcciones. No duplicar el mismo diario en varios formatos editables.
- **1 copia por sesión:** ZIP fechado, con manifiesto SHA-256.
- **1 punto de entrada:** `README.md` explica cómo abrir, probar, guardar y restaurar.

## Separar lo que antes se mezclaba
1. **Núcleo ejecutable:** código que realmente existe y se puede ejecutar.
2. **Investigación:** hipótesis, demostraciones, contraejemplos y resultados reproducibles.
3. **Continuidad:** estado actual, siguiente tarea y decisiones pendientes.
4. **Archivo histórico:** versiones antiguas, PDFs y prototipos; no se mezclan con el núcleo activo.

Las versiones conceptuales y las versiones del software se numeran por separado. Una idea discutida en conversación no pasa a ser código implementado por el hecho de recibir un número de versión.

## Ciclo obligatorio al terminar cada sesión
1. Editar `ESTADO_ODISEO.json`: versión real del software, rama de investigación, qué se hizo, pruebas ejecutadas, fallos y siguiente paso.
2. Guardar el diario con fecha, autor, pregunta, método, resultado y estado (`HECHO`, `HIPOTESIS`, `PENDIENTE`, `REFUTADO`).
3. Ejecutar las pruebas disponibles.
4. Ejecutar `python guardar_odiseo.py guardar --proyecto . --copias ../ODISEO_COPIAS --etiqueta cierre`.
5. Confirmar que la salida dice `verificado: true`.
6. Copiar el ZIP a un segundo lugar independiente (por ejemplo, Biblioteca de ChatGPT y almacenamiento personal). Una copia en el mismo dispositivo no protege frente a pérdida del dispositivo.

## Comandos
Desde la carpeta que contiene `guardar_odiseo.py`:

```bash
# Crear copia completa y verificarla
python guardar_odiseo.py guardar --proyecto . --copias ../ODISEO_COPIAS --etiqueta cierre

# Verificar una copia existente
python guardar_odiseo.py verificar ../ODISEO_COPIAS/ODISEO_....zip

# Restaurar en una carpeta nueva, sin sobrescribir el original
python guardar_odiseo.py restaurar ../ODISEO_COPIAS/ODISEO_....zip ../ODISEO_RESTAURADO
```

## Qué garantiza y qué no
- SHA-256 detecta cambios respecto al manifiesto incluido en el ZIP.
- La verificación comprueba CRC, lista de archivos, tamaños y hashes.
- La restauración rechaza rutas inseguras y no sobrescribe una carpeta no vacía.
- **No es una firma digital:** alguien que pueda modificar el ZIP y recalcular el manifiesto puede fabricar una copia coherente. Para defensa frente a ese atacante, guardar una copia externa de solo lectura o firmar el manifiesto con una clave privada que no se guarde junto al proyecto.
- El sistema no sincroniza por sí solo la nube ni ejecuta tareas en segundo plano. Hay que realizar el ciclo de cierre.

## Norma de versiones
- Incrementar versión solo después de pruebas documentadas.
- No borrar versiones previas; archivarlas.
- Mantener un único `ESTADO_ODISEO.json` vigente.
- Nunca registrar como ejecutado lo que solo se diseñó o discutió.
- Si falta evidencia, escribir `NO VERIFICADO`.

## Recuperación en una conversación nueva
Adjuntar el ZIP más reciente y pedir: «Continúa Odiseo desde `ESTADO_ODISEO.json`; primero verifica la copia y resume el último estado, sin inventar avances».

## Guardado integrado en Android (49.8 alpha)
Desde el centro de control, pulsa **Guardar copia ZIP verificada**. Android abre el selector de documentos para elegir dónde guardar el archivo. El ZIP contiene estado, diario y manifiesto SHA-256. Para recuperar, pulsa **Restaurar copia ZIP**, selecciona el archivo y la aplicación verifica primero los tamaños y hashes; solo después ofrece sustituir el diario local. La restauración requiere confirmación.

Esta función no sincroniza en la nube, no se ejecuta en segundo plano y no sustituye la copia completa del código fuente creada con `guardar_odiseo.py`. La APK necesita compilación e instalación de prueba antes de considerar la integración validada en dispositivo.


## Evolución del Espejo 50.4
Los patrones repetidos son disparadores de preguntas, no significados demostrados. El motor deriva preguntas con plantillas, las vuelve a codificar como partículas positivas y las pasa por el acelerador. Se limita a 3 rondas, 8 preguntas derivadas y 4 patrones por progenitor; elimina duplicados y registra la relación de parentesco. El historial se exporta y restaura.


## Continuidad 50.5 — Motor de Interacción Finita
Partir de ODISEO 50.5. A y B comienzan como conjuntos finitos; operaciones exactas generan resultados que pueden reinsertarse en rondas siguientes. Cada colisión conserva pregunta, respuesta aritmética y nueva pregunta reflexiva. La expansión observada no prueba infinitud. Revisar `interaccion_odiseo.js`, `tests_odiseo_interaccion.js`, el historial `interaction_history` y los límites registrados en `ESTADO_ODISEO.json`. APK pendiente de compilación e instalación física.


## Continuidad 50.6
La versión 50.6 parte íntegramente del ZIP 50.5 y añade `OdiseoConvergence`. Regla adaptativa: `alpha_n=x+(1-x)y_n`; actualización: `y_(n+1)=y_n+alpha_n(x-y_n)`. Para `0<x<1` y `0<=y_0<=x`, se tiene `0<alpha_n<=2x-x^2<1`; así `e_(n+1)=e_n(1-alpha_n)` y `e_n<=e_0(1-x)^n`, luego `y_n -> x`. La tasa asintótica de contracción es `(1-x)^2`. Es una convergencia demostrada, no optimalidad global ni generación de infinitud computacional.


## Odiseo 50.8 — Motor de Objetivo Evolutivo

Se incorpora `objetivo_evolutivo_odiseo.js`: el objetivo sigue el mapa logístico `x[n+1]=r*x[n]*(1-x[n])` y el perseguidor `y` se adapta mediante una ganancia acotada. El motor informa rangos, error final y una clasificación heurística. Las ventanas finitas no prueban caos, periodicidad asintótica ni estabilidad global. El generador APK valida y calcula SHA-256 del nuevo módulo.


## Versión 50.9 — Sensibilidad de trayectorias

La investigación compara el mapa logístico desde x₀ y x₀+δ, con el mismo parámetro r. Se calcula una estimación finita de λ = promedio(log|r(1−2xₙ)|) sobre la órbita de referencia, descartando burn iteraciones iniciales. λ>0 en una ventana es evidencia de separación lineal local para esa órbita y ventana; no prueba por sí solo caos global, ergodicidad ni comportamiento asintótico. El motor permite barridos de hasta 32 valores de r, pero no clasifica caos de forma concluyente.

## Continuidad 51.1 — ciclo de investigación

1. Formular pregunta y elegir una familia de experimento admitida.
2. A presenta una hipótesis operacional y declara el alcance.
3. B ejecuta la búsqueda dentro del presupuesto y busca contraejemplos.
4. C repite y verifica con una segunda vía de cálculo.
5. H asigna recursos usando el Motor de Energía y respeta la reserva.
6. Guardar pregunta, hipótesis, parámetros, resultado, refutaciones, verificación y huella.
7. No convertir resultados finitos en afirmaciones universales ni preguntas libres en hipótesis verificadas.

Familias actuales: `syracuse-audit` y `logistic-sensitivity`.

8. Derivar una pregunta siguiente y un diseño experimental a partir de lo observado; el usuario puede adoptarlo y ejecutarlo. La derivación actual usa reglas explícitas, no comprensión semántica general.


## Odiseo 51.2 — Núcleo Creador Autónomo

Incluir y verificar `app/src/main/assets/creador_autonomo_odiseo.js`. Este módulo es autocontenido y no debe importar ni invocar otros motores, APIs, red o modelos externos. El builder incorpora su SHA-256 al informe. Ejecutar `tests_odiseo_creador.js` y la batería completa. El núcleo genera estructuras simbólicas desde primitivas internas, con presupuesto y archivo limitados; no equivale a comprensión semántica, conciencia ni autoprogramación.


### Autonomía creadora local 51.2

El núcleo creador no depende de otros motores ni de servicios externos. Su objetivo interno es ampliar diversidad estructural bajo límites explícitos. Selecciona padres entre las estructuras con mayor novedad local, compone AST mediante la gramática, valida cada estructura y calcula distancia de rasgos respecto al archivo previo. La huella del estado permite detectar alteraciones accidentales. No se ejecuta por sí solo en segundo plano: la sesión debe iniciarse desde la interfaz o mediante llamada local. No hay semántica general, auto-modificación, conciencia ni independencia del hardware/runtime.


## Continuidad desde 51.3

Retomar desde el ZIP 51.3. Odiseo y Penélope tienen capacidades independientes y crecimiento exponencial `V_next=V*exp(k*p)`. Solo se premia progreso estructural validado. Penélope propone simplificaciones reversibles y nunca destruye el original. V0 debe ser positivo y finito; k es independiente para cada motor. La capacidad no es energía física ni recursos de cómputo. Ejecutar las 13 baterías (206 checks) y comprobar exportación/restauración del estado creador y crecimiento antes de aceptar cambios posteriores.

## Continuidad 51.4 — acoplamiento recíproco

El siguiente paso real fue convertir la oposición de Penélope en realimentación efectiva. `OdiseoDuet` ejecuta rondas finitas y reproducibles: creación → desmontaje/retejido → devolución → selección creadora posterior. Las devoluciones se incorporan al archivo como `penelope-return`; el creador reserva una posibilidad de selección preferente para las últimas ocho devoluciones (hasta 50% de elecciones). El archivo conserva AST, linaje y huellas; no se sustituye el original. El estado completo del duelo se incluye en ODISEO SAVE Android.

No se declara aprendizaje semántico ni equivalencia matemática. La prueba de integración comprueba que una devolución de Penélope se convierte realmente en padre de una creación posterior. Límites: 50 rondas por llamada, 200 entradas de duelo, archivo creador de 500 estructuras.

Experimento de integración repetible: semilla 1, tres rondas, 24 creaciones, 24 oposiciones y 16 retornos añadidos. En la segunda ronda, 8/8 creaciones tuvieron al menos un padre `penelope-return`; en la tercera, 6/8. Huella `05cfcd32`. Esta es evidencia de que la realimentación llega a la selección creadora posterior, no una medida de valor semántico.


## Continuidad 51.8 — Judas Tadeo y Laboratorio de Loterías

Partir de este paquete 51.8 sin rehacer ni reemplazar los módulos de 51.7. Judas Tadeo es motor D de diagnóstico y reencuadre; no es un generador de afirmaciones. El Laboratorio de Loterías usa las reglas de cada juego y exige historiales oficiales aportados/importados. No inventar resultados ni presentar simulaciones como sorteos reales. La regla fría-50 queda fijada en código y solo se evalúa walk-forward; cualquier señal debe replicarse en una ventana temporal reservada. Los boletos originales no se modifican. Mantener separado el objetivo de reducir el reparto del premio, que requiere datos de apuestas de jugadores. Estado 51.8: 334 comprobaciones/17 baterías/0 fallos; APK no compilada ni instalada; historiales oficiales aún no importados.


## Detector de inactividad Android 53.4-alpha

El cliente Android registra el último evento de interacción y arma una alarma nativa de 30 minutos. Al detectar el umbral deja un marcador persistente; la auditoría JavaScript se ejecuta cuando la interfaz vuelve a primer plano. El informe se almacena con SHA-256 en el espacio privado de la app y se incorpora al diario exportado. Android puede retrasar alarmas por Doze; no se declara ejecución exacta ni auditoría completa en segundo plano.
