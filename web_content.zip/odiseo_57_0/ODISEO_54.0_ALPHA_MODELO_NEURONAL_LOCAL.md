# Odiseo 54.0-alpha — integración inicial de modelo neuronal local

Fecha: 2026-11-05. Rama experimental derivada de 53.9-alpha. La estable 53.2 no cambia.

## Implementación de esta iteración
- Añadido runtime Android Kotlin `LocalModelRuntime` basado en LiteRT-LM 0.18.0.
- Ciclo de vida serializado en un único executor: carga, conversación, generación y cierre.
- Importación manual de un archivo `.litertlm` mediante Storage Access Framework; copia a almacenamiento privado, límite de tamaño y SHA-256 local.
- Puente WebView para importar, cargar, consultar estado y generar respuestas locales.
- El chat conserva el enrutamiento determinista de 53.9 y usa el modelo local solo como fallback para preguntas abiertas.
- Se añade al prompt contexto recuperado de memoria semántica, etiquetado como no verificado.
- Las respuestas neuronales se marcan explícitamente como generadas y no verificadas por los motores.
- Pesos fuera de la APK; no se incluye descarga automática ni se envían mensajes a servidores.

## Runtime y modelo
Dependencia fijada: `com.google.ai.edge.litertlm:litertlm-android:0.18.0`. Candidato inicial documentado: Gemma 4 E2B (`.litertlm`, aprox. 2.58 GB). No se presupone rendimiento en el dispositivo objetivo. Alternativa de menor tamaño: Qwen3 0.6B, sujeto a comprobar formato y compatibilidad exacta.

## Verificación ejecutable en este entorno
Pendiente de ejecutar tras esta edición: regresiones JavaScript y verificaciones estáticas.

## No validado / límites
- No se dispone aquí de Gradle/Android SDK ni se ha compilado APK.
- La integración Kotlin/LiteRT-LM no está compilada contra el AAR en este entorno.
- No se ha instalado ni probado en el teléfono.
- No se ha medido RAM, temperatura, batería, latencia ni tokens/s en el dispositivo.
- No se han conectado aún las herramientas Odiseo como llamadas de función automáticas del LLM; los comandos deterministas existentes siguen siendo rutas explícitas.
- No hay aprendizaje de pesos del modelo: la memoria registra información local, pero no reentrena la red neuronal.
- La exactitud del modelo requiere pruebas ciegas en español y tareas matemáticas.

## Criterio de promoción
No declarar 54.0 operativa hasta compilar, importar un modelo real, generar una respuesta sin red, verificar cierre/recarga, probar fallback sin modelo y medir el dispositivo.
