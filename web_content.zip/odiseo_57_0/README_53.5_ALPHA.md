# ODISEO 53.5.3-alpha — Android offline

## Estado
- Versión estable global: 53.2 (sin cambios).
- Rama experimental: 53.5.3-alpha.
- Asistente: router determinista offline, NO es un LLM ni una IA general conversacional.
- Sin GPT, API remota ni llamadas de red desde el chat.
- APK: fuente preparada; NO compilada ni instalada.

## Capacidades conversacionales implementadas
- Auditoría del núcleo unificado.
- Inventario de APIs cargadas (presencia no equivale a integración).
- Sherlock: análisis de al menos dos observaciones separadas por punto y coma.
- Judas Tadeo: reencuadre de bloqueos.
- ESPEJO: auditoría del grafo local.
- Penélope: `Penélope: {JSON}` con AST válido; ejecuta `unweave` y valida cada propuesta.

## Ejemplo Penélope
`Penélope: {"ast":{"type":"binary","op":"sum","a":{"type":"primitive","name":"x"},"b":{"type":"primitive","name":"y"}},"sourceId":"demo"}`

El original se conserva. Simplificación estructural no demuestra equivalencia semántica.

## Compilación
Abrir `tic_work` en Android Studio/AndroidIDE con JDK 17, Android Gradle Plugin 8.7.3 y Android SDK 35. La APK esperada es `app/build/outputs/apk/debug/app-debug.apk`. La compilación no se ha ejecutado aquí.

## Verificación de esta rama
- Regresión: 36/36 archivos de pruebas Node PASS.
- Ruta Penélope: 3/3 PASS (AST válido, JSON mal formado, AST inválido).
- Asistente local: 6/6 PASS.
- Enrutamiento previo Sherlock/Judas/ESPEJO: 4/4 PASS.
- Sintaxis de assets JavaScript: 31/31 PASS.
- No hay prueba E2E de navegador/WebView ni Android físico.

Consultar `VALIDACION_53.5_3_ALPHA.md` para alcance y limitaciones.
