#!/usr/bin/env bash
# Construye Odiseo 56.0 cuando Android SDK, JDK 17 y Gradle 8.13 ya están instalados.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK" || ! -d "$SDK" ]]; then
  echo "ERROR: No encuentro Android SDK. Configura ANDROID_HOME o ANDROID_SDK_ROOT."
  exit 1
fi
command -v java >/dev/null 2>&1 || { echo "ERROR: Falta Java JDK 17."; exit 1; }
command -v gradle >/dev/null 2>&1 || { echo "ERROR: Falta Gradle 8.13 en PATH. En AndroidIDE/Android Studio, sincroniza el proyecto desde la carpeta raíz."; exit 1; }
printf 'sdk.dir=%s\n' "$SDK" > "$ROOT/local.properties"
cd "$ROOT"
java -version
gradle --version
gradle --no-daemon clean assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || { echo "ERROR: Gradle no generó app-debug.apk"; exit 1; }
DEST="$ROOT/ODISEO_56.0_ALPHA_DEBUG.apk"
cp "$APK" "$DEST"
sha256sum "$DEST" | tee "$DEST.sha256"
echo "APK generada: $DEST"
