# Odiseo 55.2-alpha-voice-chat — preparación de APK

Fecha de comprobación: 2026-11-19.

## Resultado verificable
- Proyecto fuente Android extraído y revisado.
- `python3 crear_apk_odiseo.py --solo-preparar`: correcto; genera `build-output/ODISEO_BUILD_REPORT.json` con estado `PREPARADO`.
- `python3 tests_android_build_metadata.py`: 10 pruebas correctas.
- Suite JavaScript: 49 archivos de prueba ejecutados, 49 correctos, 0 fallidos.
- El proyecto declara voz española: `SpeechRecognizer` (`es-ES`), permiso de micrófono y `TextToSpeech` (`es-ES`).
- Workflow `.github/workflows/android.yml` presente para compilar en GitHub Actions.

## Lo que NO se ha podido verificar
- No se ha generado una APK en este entorno: no hay Gradle ni Android SDK instalados.
- No existe una APK precompilada dentro del ZIP original.
- No se ha lanzado GitHub Actions porque no hay un repositorio GitHub accesible conectado.
- Por tanto, no se afirma que la APK esté compilada, instalada ni probada en un teléfono real.

## Cómo obtener la APK
### Opción A — AndroidIDE en el teléfono
1. Extraer todo el ZIP.
2. Abrir/importar la carpeta raíz del proyecto (la que contiene `settings.gradle`).
3. Esperar a que sincronice Gradle y descargue dependencias.
4. Ejecutar la tarea `assembleDebug`.
5. Si termina correctamente, buscar `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos declarados por el proyecto: JDK 17, Android SDK Platform 35, Build Tools 35.0.0 y Gradle 8.13. Se necesita Internet durante la sincronización inicial.

### Opción B — GitHub Actions
1. Crear un repositorio GitHub propio y subir el contenido completo del ZIP.
2. Abrir la pestaña Actions.
3. Ejecutar el workflow `Build Odiseo Android APK`.
4. Descargar el artefacto `odiseo-android-debug` cuando la ejecución termine en verde.

## Voz y límites
La app integra reconocimiento y síntesis de voz en español. La preferencia de reconocimiento offline no garantiza funcionamiento sin red: depende del servicio y del paquete de idioma del dispositivo. La síntesis depende de que haya una voz española instalada. La suite automatizada no sustituye una prueba de micrófono/altavoz en Android físico.
