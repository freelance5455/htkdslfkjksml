# Auditoría Odiseo 52.3 — reducción de falsos positivos Sherlock

## Cambio
- La estrategia `numeric-difference-pattern` calcula frecuencia documental de cada diferencia (cada rastro cuenta una vez).
- Solo propone un par si comparte al menos dos diferencias distintas y cada diferencia aparece en no más de `max(2, ceil(20% del corpus))` rastros.
- `numeric-overlap` conserva compatibilidad con coincidencias numéricas individuales, pero filtra valores ubicuos con el mismo umbral de frecuencia documental.
- Las fechas siguen siendo anotación contextual; no crean enlaces.

## Pruebas reproducibles
- Positivo sintético conocido: dos series comparten diferencias 4, 5 y 6; Sherlock recupera el par.
- Negativo ubicuo: 40 rastros comparten diferencias 14 y 24; cero candidatos de diferencias.
- Negativo de solapamiento numérico: 40 rastros de control; como máximo dos coincidencias numéricas aisladas en este dataset.
- `tests_sherlock_false_positives.js`: 3/3 aserciones superadas.
- Las 18 baterías legacy `tests_*.js` ejecutadas antes de añadir el test nuevo: código cero.
- `node --check` superado.

## Interpretación y límites
La corrección reduce el problema demostrado de diferencias ubicuas. No demuestra una tasa general de falsos positivos baja: el control aún produce dos candidatos de solapamiento numérico aislado. El umbral `max(2, ceil(0.2N))` es una regla heurística, no un p-valor ni un modelo nulo. En corpus pequeños permite frecuencia hasta dos; la evidencia es débil y debe etiquetarse como tal.

No se ha implementado un modelo nulo universal, permutaciones, benchmark ciego, holdout independiente, integración E2E de Penélope ni compilación/instalación APK. No afirmar que Sherlock ya alcanza 8/10.
