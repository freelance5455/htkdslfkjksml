# Odiseo 53.5.1-alpha — conversación local sin GPT

## Estado de esta rama
Rama experimental derivada de `ODISEO_53.4_ALPHA_INACTIVITY_ANDROID_20261105(1).zip`. No modifica la etiqueta estable `53.2`. Se conserva el paquete base y se añaden una interfaz conversacional local y ESPEJO 2.0.0-alpha.

## Cambios de esta iteración
- `app/src/main/assets/asistente_local_odiseo.js`: enrutador conversacional determinista, inventario de APIs cargadas, respuestas de alcance, ejecución asíncrona del núcleo unificado, acceso a preguntas heurísticas de ESPEJO y persistencia local del chat.
- `app/src/main/assets/index.html`: panel de chat integrado en la aplicación; mensajes locales, envío con Enter, historial y borrado.
- `app/src/main/assets/espejo_odiseo.js`: sustituido por el motor ESPEJO Explorador 2.0.0-alpha recuperado del paquete original, conservando el original 1.1.0 en el paquete de referencia.
- `tests_asistente_local_odiseo.js`: pruebas de contrato del chat local.
- `tests_asistente_inventario_exports.cjs`: comprueba que el inventario coincide exactamente con los 30 exports declarados.

## Qué significa «sin GPT»
No hay llamadas a GPT, API de OpenAI, servidores de inferencia ni tráfico de red desde el nuevo asistente. El chat actual es un router de reglas explícitas que llama a capacidades locales. **No es un LLM ni tiene la flexibilidad lingüística de GPT.** Esta limitación es deliberada y visible para el usuario. La siguiente fase puede evaluar un modelo local instalable sin conexión, pero no se incluye ni se afirma que exista todavía.

## Validación ejecutada en esta iteración
- 34/34 suites JavaScript previas: PASS.
- 1/1 suite nueva de inventario: PASS (4/4 aserciones; 30 exports).
- 31/31 assets JavaScript y dos bloques inline HTML: sintaxis PASS.
- JSON y XML Android: parseo PASS.
- Ver informe detallado `VALIDACION_53.5_1_ALPHA.md`.

## No validado
No se compiló APK, no se instaló en Android, no se probó WebView real, no se auditó la seguridad Android completa y no se ha demostrado conversación semántica general. El sistema no se debe presentar como GPT ni como inteligencia general.


## Corrección 53.5.1-alpha
Se corrigió el inventario conversacional: ahora usa los nombres reales de 30 APIs globales exportadas por los scripts incluidos en la interfaz. Antes había etiquetas/claves que no coincidían con algunos exports y faltaban varios motores. El estado `available` solo significa que la API está cargada; no certifica integración funcional.
