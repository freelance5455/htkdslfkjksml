const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.join(__dirname,'app/src/main/assets');
const ctx={window:{}};
for(const f of ['algoritmo_odiseo.js','creador_autonomo_odiseo.js','penelope_odiseo.js','crecimiento_exponencial_odiseo.js','duelo_odiseo_penelope.js']) vm.runInNewContext(fs.readFileSync(path.join(root,f),'utf8'),ctx);
const {OdiseoAlgorithm:A,OdiseoCreator:C,OdiseoPenelope:P,OdiseoGrowth:G,OdiseoDuet:D}=ctx.window;
function assert(v,m){if(!v)throw Error(m)}
function F(n){let t=3n*n+1n;while(t%2n===0n)t/=2n;return t;}
const report={version:'51.5-experimento',createdAt:'2026-11-04',tests:[],limits:[]};
// 1) Certeza matemática: F(n) es impar positivo para todo impar positivo.
const certainty=A.run({task:'collatz-audit',start:1,end:100000,maxTests:50000});
assert(certainty.ok,'El motor A/B/C/H rechazó la auditoría de certeza');
const cr=certainty.result;
assert(cr.B.tested===50000,'No se examinaron los 50.000 impares previstos');
assert(cr.B.counterexamples.positive_odd.length===0,'Apareció contraejemplo en cierre impar positivo');
assert(cr.C.checked===50000&&cr.C.disagreements===0,'La verificación C no coincide');
assert(cr.C.status==='COHERENCIA_INTERNA','Estado C inesperado');
report.tests.push({id:'T1',type:'certeza matemática',claim:'Para todo entero impar positivo n, F(n)=(3n+1)/2^v2(3n+1) es impar positivo.',proof:'3n+1 es positivo y par. Al dividir por la máxima potencia de 2 que lo divide queda un entero positivo impar, por definición de v2.',finiteAudit:{start:1,end:100000,oddInputs:cr.B.tested,counterexamples:cr.B.counterexamples.positive_odd.length,independentChecks:cr.C.checked,disagreements:cr.C.disagreements},status:'DEMOSTRADA_POR_DEFINICION_Y_AUDITADA_EN_RANGO'});
// 2) Hipótesis refutable: F(n)<n para todo impar n>1.
let counter=null, tested=0;
for(let n=3;n<=100000;n+=2){tested++;const out=F(BigInt(n));if(out>=BigInt(n)){counter={n,result:out.toString(),inequality:`${out} >= ${n}`};break;}}
assert(counter&&counter.n===3&&counter.result==='5','No se reprodujo el contraejemplo mínimo esperado');
report.tests.push({id:'T2',type:'hipótesis refutable',claim:'Para todo impar n>1, F(n)<n.',testedBeforeFirstCounterexample:tested,counterexample:counter,calculation:'F(3)=(3·3+1)/2=10/2=5; 5 no es menor que 3.',status:'REFUTADA_POR_CONTRAEJEMPLO'});
// 3) Elección del evaluador: robustez del duelo y realimentación en semillas diversas.
const seeds=[1,42,2026],duelRuns=[];
for(const seed of seeds){
 const initial=D.initial(C,G,{seed,growth:{odiseoInitial:1.25,penelopeInitial:0.75,odiseoK:0.12,penelopeK:0.08}});
 const result=D.run(initial,C,P,G,{rounds:5});
 const valid=D.validate(result.state,C,G);
 const originalIds=new Set(initial.creatorState.archive.map(x=>x.id));
 const retained=[...originalIds].every(id=>valid.creatorState.archive.some(x=>x.id===id));
 const returns=valid.creatorState.archive.filter(x=>x.kind==='penelope-return');
 const od=valid.growthState.motors.odiseo,pe=valid.growthState.motors.penelope;
 assert(result.summary.created>0&&result.summary.opposed>0&&result.summary.returned>0,`Sin cooperación suficiente en semilla ${seed}`);
 assert(retained,'Se perdió una estructura original');
 assert(returns.length===result.summary.feedbackAvailable,'Conteo de devoluciones inconsistente');
 assert(od.growthEvents>0&&pe.growthEvents>0,'Uno de los motores no registró crecimiento');
 assert(od.logCapacity>Math.log(od.initial)&&pe.logCapacity>Math.log(pe.initial),'No aumentaron ambas capacidades internas');
 assert(result.rounds.every(r=>r.oppositions.every(p=>p.verified&&p.reversible)),'Se detectó oposición no reversible o no validada');
 duelRuns.push({seed,rounds:result.summary.rounds,created:result.summary.created,opposed:result.summary.opposed,returnsInserted:result.summary.returned,archiveSize:result.summary.archiveSize,odiseoGrowthEvents:od.growthEvents,penelopeGrowthEvents:pe.growthEvents,odiseoCapacity:G.display(od.logCapacity),penelopeCapacity:G.display(pe.logCapacity),originalsRetained:retained,fingerprint:result.state.fingerprint});
}
// Reproducibilidad: la misma semilla y parámetros deben producir la misma huella.
const s1=D.run(D.initial(C,G,{seed:77}),C,P,G,{rounds:4});
const s2=D.run(D.initial(C,G,{seed:77}),C,P,G,{rounds:4});
assert(s1.state.fingerprint===s2.state.fingerprint,'El duelo no es reproducible con la misma semilla');
report.tests.push({id:'T3',type:'prueba elegida por el evaluador',claim:'El acoplamiento Odiseo-Penélope mantiene procedencia, reversibilidad, conservación del archivo y progreso independiente en varias semillas.',runs:duelRuns,reproducibility:{seed:77,rounds:4,sameFingerprint:true,fingerprint:s1.state.fingerprint},status:'SUPERADA_EN_TRES_SEMILLAS'});
report.overall={passed:3,failed:0,certaintyIsProof:true,hypothesisWasRefuted:true,duelWasStressTested:true};
report.limits=[
 'La prueba T1 demuestra la propiedad matemática por definición de v2; la auditoría informática solo comprueba un rango finito y la concordancia de dos implementaciones.',
 'La prueba T2 refuta la afirmación universal con un solo contraejemplo; no requiere explorar todo el rango.',
 'La prueba T3 verifica propiedades estructurales del software, no comprensión semántica, utilidad general ni conciencia.',
 'Los índices exponenciales son capacidades internas de diseño y no equivalen a energía física ni a más CPU/RAM.'
];
fs.writeFileSync(path.join(__dirname,'build-output','experimento_51_5.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
