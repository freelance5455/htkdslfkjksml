const fs=require('fs'),vm=require('vm'),path=require('path');
const ctx={window:{},Date,Math,Set,Array,Number,String,Object,JSON,Error};
for(const file of ['integrador_odiseo_penelope.js','judas_tadeo_odiseo.js','loterias_odiseo.js'])vm.runInNewContext(fs.readFileSync(path.join(__dirname,'app/src/main/assets',file),'utf8'),ctx);
const L=ctx.window.OdiseoLotteryLab,J=ctx.window.OdiseoJudasTadeo;let passed=0;
function ok(x,m){if(!x)throw Error(m);passed++;}
function throws(fn,m){let t=false;try{fn()}catch(e){t=true}ok(t,m)}
function data(game,n){let s=1,rand=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)/4294967296};const spec=L.games[game],out=[];for(let d=0;d<n;d++){const pick=(pool,k,min=1)=>{const a=new Set();while(a.size<k)a.add(min+Math.floor(rand()*pool));return [...a].sort((x,y)=>x-y)};out.push({date:'2025-'+String(1+Math.floor(d/28)).padStart(2,'0')+'-'+String(1+d%28).padStart(2,'0'),numbers:pick(spec.pool,spec.main),extras:pick(spec.extraPool,spec.extra,spec.extraMin===undefined?1:spec.extraMin)});}return out;}
for(const game of ['primitiva','euromillones']){
 const spec=L.games[game],ticket=L.tickets[game];
 ok(ticket.numbers.length===spec.main,'boleto principal congelado '+game);
 ok(ticket.extras.length===spec.extra,'complementos congelados '+game);
 const p=L.ticketProfile(game,ticket);ok(p.mainJackpotOdds==='1 entre '+spec.jackpotDenominator,'probabilidad premio máximo '+game);
 const empty=L.study({game,draws:[]});ok(empty.verdict.status==='THEORETICAL_ONLY','sin datos no inventa análisis '+game);
 ok(empty.integration.status==='INTEGRATION_PASSED_THEORETICAL_ONLY'&&empty.integration.passed===7,'Integrador E valida informe teórico '+game);
 if(game==='primitiva'){ok(L.validateDraws(game,[{numbers:[1,2,3,4,5,6],extras:[0]}])[0].extras[0]===0,'acepta reintegro cero');throws(()=>L.validateDraws(game,[{numbers:[1,2,3,4,5,6],extras:[10]}]),'rechaza reintegro diez');}
 const draws=data(game,60);const a=L.study({game,draws,replications:199,seed:12345});
 ok(a.integration.status==='INTEGRATION_PASSED_SOURCE_UNVERIFIED'&&a.integration.passed===7,'Integrador E integra informe con fuente no verificada '+game);
 ok(a.audit.multipleTesting.tests.length===9,'nueve contrastes '+game);
 ok(a.predictiveBacktest.status==='COMPLETED'&&a.predictiveBacktest.window===50&&a.predictiveBacktest.forecastRounds===10,'backtest walk-forward frío-50 '+game);
 ok(a.roles.odiseo.status==='EXECUTED'&&a.roles.penelope.status==='EXECUTED'&&a.roles.judasTadeo.status==='EXECUTED'&&a.roles.integratorE.status==='EXECUTED','cuatro funciones integradas '+game);
 ok(a.audit.multipleTesting.tests.every(t=>t.adjustedPValue>=t.pValue&&t.adjustedPValue<=1),'corrección Holm '+game);
 const b=L.study({game,draws,replications:199,seed:12345});
 ok(JSON.stringify(a.audit)===JSON.stringify(b.audit),'simulación reproducible '+game);
 ok(a.ticketBacktest.expectedMainMatchesUnderFairDraws===60*spec.main*spec.main/spec.pool,'esperanza exacta del boleto '+game);
 throws(()=>L.validateDraws(game,[{numbers:[1,1,...Array(spec.main-2).fill(2)],extras:ticket.extras}]),'rechaza duplicados '+game);
}
throws(()=>L.validateDraws('primitiva',[{date:'2025-13-40',numbers:[1,2,3,4,5,6],extras:[1]}]),'rechaza fecha mal formada');
throws(()=>L.validateDraws('primitiva',[{date:'2025-02-02',numbers:[1,2,3,4,5,6],extras:[1]},{date:'2025-02-01',numbers:[1,2,3,4,5,6],extras:[2]}]),'rechaza cronología invertida');
ok(L.study({game:'euromillones',draws:data('euromillones',30),replications:199}).predictiveBacktest.status==='INSUFFICIENT_HISTORY','no ejecuta backtest sin 51 sorteos');
 ok(L.study({game:'euromillones',draws:data('euromillones',60).map(({numbers,extras})=>({numbers,extras})),replications:199}).predictiveBacktest.status==='MISSING_CHRONOLOGY','exige fechas para walk-forward');
const jd=J.reframe({domain:'lottery',block:'shared_assumption',premises:['sorteo justo'],attempted:['frecuencias'],constraints:['boletos congelados']});
ok(jd.status==='REFRAME_PROPOSED','Judas propone reencuadre');
ok(jd.alternativeFrames.length===4,'Judas separa cuatro objetivos');
ok(jd.epistemicRules.some(x=>x.includes('no existe')),'Judas separa no encontrado de inexistencia');

// Reglas históricas de estrellas de Euromillones: 9, 11 y 12.
ok(L.validateDraws('euromillones',[{date:'2008-02-01',numbers:[1,2,3,4,5],extras:[8,9]}])[0].ruleset==='stars_1_9','acepta matriz histórica de 9 estrellas');
throws(()=>L.validateDraws('euromillones',[{date:'2008-02-01',numbers:[1,2,3,4,5],extras:[8,10]}]),'rechaza estrella 10 antes del cambio de 2011');
ok(L.validateDraws('euromillones',[{date:'2014-01-01',numbers:[1,2,3,4,5],extras:[10,11]}])[0].ruleset==='stars_1_11','acepta matriz histórica de 11 estrellas');
throws(()=>L.validateDraws('euromillones',[{date:'2014-01-01',numbers:[1,2,3,4,5],extras:[10,12]}]),'rechaza estrella 12 antes del cambio de 2016');
ok(L.pelayoProtocol().status==='NO_MECHANISM_DATA','no inventa evidencia física Pelayo');

const assoc=L.study({game:'primitiva',draws:[{date:'2025-01-01',numbers:[1,2,3,4,5,6],extras:[0]}],replications:199,seed:7}).audit.main.associations;
ok(assoc.pairs.distinctObserved===15&&assoc.triples.distinctObserved===20,'calcula asociaciones de parejas y tríos observadas');
ok(assoc.classification==='DESCRIPTIVE_ONLY'&&assoc.pairs.expectedOccurrencesPerSpecificPair>0,'etiqueta asociaciones como descriptivas y da referencia nula');
console.log(JSON.stringify({suite:'51.9-lottery-judas-pelayo-rules',passed,failed:0},null,2));
