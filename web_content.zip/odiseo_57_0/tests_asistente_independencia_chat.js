'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const store=new Map();const ctx={console,Date,Math,JSON,window:{},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}};ctx.window=ctx;
for(const file of ['herramientas_independencia_odiseo.js','asistente_local_odiseo.js']) vm.runInNewContext(fs.readFileSync('app/src/main/assets/'+file,'utf8'),ctx);
(async()=>{
 let r=await ctx.OdiseoLocalAssistant.reply('Herramientas locales');assert.equal(r.meta.kind,'capability-catalog');assert.match(r.text,/Sherlock/);
 r=await ctx.OdiseoLocalAssistant.reply('recuerda local: La app no llama a GPT | fuente: prueba local');assert.equal(r.meta.kind,'local-memory');
 r=await ctx.OdiseoLocalAssistant.reply('recupera local: no llama a GPT');assert.equal(r.meta.matches.length,1);assert.match(r.text,/prueba local/);
 r=await ctx.OdiseoLocalAssistant.reply('recuerda local: falta procedencia');assert.equal(r.meta.status,'NEEDS_INPUT');
 console.log('PASS 4/4 — catálogo de herramientas, memoria local, recuperación y exigencia de procedencia');
})().catch(e=>{console.error(e);process.exit(1)});
