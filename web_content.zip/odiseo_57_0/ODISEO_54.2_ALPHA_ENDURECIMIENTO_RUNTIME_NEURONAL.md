# Odiseo 54.2-alpha — endurecimiento del primer runtime neuronal local

Fecha: 2026-11-06. Base: paquete auditado 54.1-alpha. Versión estable global: 53.2, intacta.

## Cambios de esta revisión

1. **Importación transaccional del modelo:** el modelo anterior ya no se borra antes de que el nuevo archivo esté listo. Se conserva temporalmente, se activa el nuevo mediante renombrado y se restaura el anterior si falla la activación.
2. **Integridad SHA-256:** tras copiar, el archivo activado se vuelve a leer y se contrasta su hash y tamaño. La ruta solo se publica en preferencias después de esa comprobación.
3. **Verificación antes de cargar:** Odiseo comprueba tamaño y SHA-256 guardados antes de inicializar el modelo y expone `SHA256_OK` / `SHA256_MISMATCH` en el estado nativo.
4. **Limpieza del runtime:** si falla la inicialización de LiteRT-LM, el Engine candidato se cierra y no queda retenido como runtime activo.
5. Se conserva el flujo de chat: cuando el runtime informa `READY`, el asistente construye el contexto cognitivo local y envía el prompt al modelo neuronal; sin modelo listo, no finge generación neuronal.

## Pruebas reproducidas en este entorno

- `node --test tests_*.js`: 45/45 PASS.
- Inventario CJS: pendiente de reejecución en esta revisión.
- Sintaxis JS: pendiente de reejecución en esta revisión.
- Android Gradle build contra AAR LiteRT-LM real: NO EJECUTADO (no hay Gradle/Android SDK en este entorno).
- APK instalada: NO.
- Modelo Gemma 4 E2B importado: NO.
- Inferencia neuronal offline en teléfono: NO.

## Límites

Esta revisión endurece el camino de importación y ciclo de vida, pero no convierte el orquestador heurístico en una red neuronal ni demuestra que el AAR Kotlin compile. El cerebro neuronal solo estará activado cuando una build Android real cargue un bundle `.litertlm` compatible y genere una respuesta en modo avión. No se incluye ningún peso de modelo en el ZIP.

## Siguiente puerta de validación

Compilar con JDK, Gradle y Android SDK; resolver cualquier incompatibilidad real del AAR; instalar en el Android del usuario; importar el bundle Gemma 4 E2B `.litertlm`; comprobar SHA-256, cargarlo y generar una respuesta sin red. Medir TTFT, tokens/s, memoria, temperatura y batería.
