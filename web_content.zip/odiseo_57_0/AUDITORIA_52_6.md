# Auditoría Odiseo 52.6 — Núcleo unificado

## Objetivo
Integrar funcionalmente los 22 módulos JS existentes en un coordinador común, sin reemplazar sus contratos, criterios ni límites epistemológicos.

## Cambios
- Nuevo `nucleo_unificado_odiseo.js`: registro explícito de los 22 motores, adaptadores de prueba mínima, ejecución asíncrona, resumen común y reporte de fallos.
- Los resultados de los 22 motores se convierten en registros de procedencia y se envían al OIE como libro común de ejecuciones; no se infieren relaciones de apoyo o contradicción no declaradas.
- Panel Android/web en `index.html` para ejecutar el examen global y mostrar el informe.
- La prueba de independencia recibe Odiseo y Penélope explícitamente; no presupone acceso global ni mezcla sus respuestas antes del compromiso criptográfico.
- El generador APK exige el núcleo unificado y registra su SHA-256.
- Añadido `tests_odiseo_nucleo_unificado.js`.

## Verificación
- 22/22 motores ejecutaron una prueba mínima con estado EXECUTED.
- 0 errores en el informe de humo del núcleo.
- Todos los archivos `tests_*.js` preexistentes ejecutados individualmente: pasaron.
- Test específico del núcleo: pasó.
- - Todos los archivos `tests_*.js` (incluido el nuevo test) pasaron tras la integración.
- `node --check` en todos los assets JS: correcto.
- `python -m py_compile` de scripts Python: correcto.
- `python probar_generador.py`: preparación del APK superada; SHA-256 del núcleo unificado incluido en el informe de build.

## Garantías preservadas
- No hay modificación automática del código de los motores.
- No se promueven hipótesis a hechos.
- Las familias de fuentes declaradas no se consideran independencia demostrada.
- Los desacuerdos se conservan; el núcleo no decide por mayoría.
- Cada motor mantiene sus reglas locales y los resultados incluyen su nombre y versión.

## Límites
Una prueba mínima demuestra que la API respondió a una entrada sintética concreta; no certifica todas las rutas, calidad científica, utilidad o robustez de cada motor. El núcleo es un coordinador, no una inteligencia general ni un mecanismo de aprendizaje autónomo. La APK no se ha compilado ni instalado.

## Siguiente paso
52.7: benchmark ciego por dominio, comparando motores individuales y combinación, con holdout, falsos positivos/negativos, precisión, recall, coste y revisión independiente.
