# Odiseo 53.6-alpha — herramientas de independencia de GPT

Fecha: 2026-11-05  
Base: `53.5.3-alpha-penelope-local-route`  
Rama: experimental; versión estable global preservada: `53.2`.

## Objetivo
Añadir capacidades locales reutilizables para que Odiseo pueda procesar texto, conservar conocimiento con procedencia y ejecutar motores mediante contratos explícitos, sin GPT, API remota ni red.

## Implementación
- `app/src/main/assets/herramientas_independencia_odiseo.js`
  - `OdiseoLocalTools`: normalización española, tokenización, palabras clave, extracción numérica, similitud Jaccard, segmentación y resumen extractivo, huella FNV-1a no criptográfica y memoria local con fuente obligatoria.
  - `OdiseoCapabilityRegistry`: catálogo y contratos allowlist para Sherlock, Penélope, Judas Tadeo, ESPEJO y Núcleo Unificado. Valida forma de entrada, disponibilidad y captura errores.
- `asistente_local_odiseo.js`: nuevos comandos `Herramientas locales`, `Recuerda local:` y `Recupera local:`.
- `index.html`: carga el módulo antes del asistente local.
- Pruebas: `tests_herramientas_independencia.js` y `tests_asistente_independencia_chat.js`.

## Pruebas ejecutadas
- Herramientas locales: 13/13 PASS.
- Integración conversacional: 4/4 PASS.
- Regresión completa: 38/38 archivos `tests_*.js` ejecutados con código de salida cero.
- Sintaxis JavaScript de assets: pendiente de recuento final en este informe.
- APK Android: no compilada, no instalada y no probada en dispositivo.

## Límites
- El procesador lingüístico es determinista y léxico; no es un LLM ni comprensión general.
- La similitud Jaccard encuentra solapamientos de palabras; no mide significado.
- El resumen es extractivo, no una síntesis semántica.
- La memoria local conserva texto y procedencia, pero no verifica que el contenido sea verdadero.
- FNV-1a es una huella de detección de cambios accidentales, no criptografía.
- El registro solo valida contratos de entrada y disponibilidad. Las llamadas se ejecutan en el mismo runtime, sin sandbox contra funciones bloqueantes.
- Los contratos cubren seis rutas iniciales; faltan adaptadores funcionales para el resto de motores.
- Esta versión no incluye todavía un modelo lingüístico neuronal local. La comparación e integración de LiteRT-LM y llama.cpp queda como fase posterior, condicionada a pruebas en el teléfono Android objetivo.

## Siguiente fase
1. Completar contratos de entrada/salida para todos los motores y pruebas por ruta real.
2. Crear recuperación semántica local (índice vectorial/embeddings ejecutados en el dispositivo) sin servicio remoto.
3. Comparar LiteRT-LM y llama.cpp en Android: tamaño, RAM, latencia, consumo, licencia y compatibilidad ABI.
4. Incorporar un modelo pequeño solo tras benchmark en el teléfono; permitir descarga/instalación opcional del modelo, manteniendo el núcleo determinista operativo sin él.
5. Compilar APK, instalar y verificar Android WebView y persistencia.
