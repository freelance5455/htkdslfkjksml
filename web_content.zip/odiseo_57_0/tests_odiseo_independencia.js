const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert'),{webcrypto}=require('crypto');
const root=path.join(__dirname,'app/src/main/assets'),ctx={window:{crypto:webcrypto,TextEncoder},crypto:webcrypto,TextEncoder,BigInt};
for(const f of ['algoritmo_odiseo.js','penelope_odiseo.js','independencia_odiseo_penelope.js'])vm.runInNewContext(fs.readFileSync(path.join(root,f),'utf8'),ctx);
const A=ctx.window.OdiseoAlgorithm,P=ctx.window.OdiseoPenelope,I=ctx.window.OdiseoIndependence;
(async()=>{
 let count=0;function ok(v,m){assert.ok(v,m);count++;}
 const task=I.makeChallenge(20261104);ok(task.inputs.length===25,'25 entradas independientes');ok(task.inputs.every(x=>BigInt(x)>0n&&BigInt(x)%2n===1n),'todas las entradas son impares positivas');ok(task.inputs.includes('3'),'incluye el caso de refutación F(3)=5');
 const oa=A.solveIndependently(task),pa=P.solveIndependently(task);ok(oa.results.length===25&&pa.results.length===25,'ambos motores resuelven el lote completo');ok(I.verify(task,oa).valid&&I.verify(task,pa).valid,'verificador externo acepta ambas respuestas');ok(I.canonical(oa.results)===I.canonical(pa.results),'resultados coincidentes');
 const out=await I.run({seed:20261104,Odiseo:A,Penelope:P});ok(out.status==='INDEPENDENCE_PROTOCOL_PASSED','protocolo normal superado');ok(out.sealedBeforeReview&&out.independentInputs,'compromisos antes de revisión y entradas aisladas');ok(out.comparison.firstCounterexample.n==='3'&&out.comparison.firstCounterexample.successor==='5','contraejemplo universal detectado');ok(out.comparison.modularViolations.length===0,'sin violaciones modulares en el lote');ok(out.responses.odiseo.sha256.length===64&&out.responses.penelope.sha256.length===64,'compromisos SHA-256');
 const repeat=await I.run({seed:20261104,Odiseo:A,Penelope:P});ok(out.task.sha256===repeat.task.sha256&&out.responses.odiseo.sha256===repeat.responses.odiseo.sha256&&out.responses.penelope.sha256===repeat.responses.penelope.sha256,'reproducibilidad de reto y respuestas');
 const faulty=Object.assign({},P,{solveIndependently(t){const r=P.solveIndependently(t);r.results[0].successor=(BigInt(r.results[0].successor)+2n).toString();return r;}});
 const faultRun=await I.run({seed:20261104,Odiseo:A,Penelope:faulty});ok(faultRun.status==='DISCREPANCY_REQUIRES_REVIEW','inyección de fallo cambia el estado');ok(faultRun.responses.odiseo.reviewOfPenelope.length>0,'Odiseo detecta respuesta alterada de Penélope');ok(!faultRun.responses.penelope.valid,'auditor externo detecta la respuesta alterada');
 const bad=JSON.parse(JSON.stringify(oa));bad.results[0].exponent+=1;ok(!I.verify(task,bad).valid,'verificador detecta exponente incorrecto');
 let rejected=false;try{I.makeChallenge(-1)}catch(e){rejected=true;}ok(rejected,'rechaza semilla inválida');
 console.log('OK: '+count+' comprobaciones de independencia superadas.');
 const report={version:'51.6',suite:'tests_odiseo_independencia.js',checks:count,status:'PASSED',normalRun:out,faultInjection:{status:faultRun.status,odiseoCaughtPenelopeErrors:faultRun.responses.odiseo.reviewOfPenelope.length,externalPenelopeValid:faultRun.responses.penelope.valid}};
 fs.mkdirSync(path.join(__dirname,'build-output'),{recursive:true});fs.writeFileSync(path.join(__dirname,'build-output','experimento_independencia_51_6.json'),JSON.stringify(report,null,2)+'\n');
})().catch(e=>{console.error(e.stack||e);process.exit(1)});
