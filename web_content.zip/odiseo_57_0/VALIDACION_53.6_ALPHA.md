# Validación Odiseo 53.6-alpha — herramientas locales de independencia

Fecha: 2026-11-05  
Base: 53.5.3-alpha Penélope local. Rama experimental; 53.2 sigue siendo la versión estable global.

## Cambios
- Nuevo procesador local determinista y utilidades lingüísticas.
- Memoria local persistente con procedencia obligatoria.
- Registro allowlist de seis capacidades con contratos de entrada.
- Integración con el chat local y carga desde `index.html`.

## Resultados reproducidos
- `tests_herramientas_independencia.js`: 13/13 PASS.
- `tests_asistente_independencia_chat.js`: 4/4 PASS.
- Regresión: 38/38 archivos `tests_*.js` ejecutados individualmente; 0 fallos.
- Sintaxis assets JavaScript: 32/32 PASS.
- Bloques JavaScript inline de HTML: 2/2 PASS.
- JSON raíz: parseo correcto.
- `py_compile`: scripts de preparación/guardado correctos.
- ZIP de base: CRC correcto antes de cambios.

## Límites y pendientes
- No es un LLM, no realiza comprensión semántica general y no reemplaza GPT en conversación abierta.
- La memoria conserva texto y procedencia; no verifica hechos.
- El registro cubre seis rutas iniciales, no todos los motores.
- Las llamadas comparten runtime; no existe aislamiento frente a código bloqueante.
- FNV-1a es no criptográfico.
- No se compiló APK: Gradle/Android SDK no se ejecutaron aquí.
- No hay instalación ni prueba WebView en teléfono.
- No se incorpora aún LiteRT-LM, llama.cpp ni pesos de modelo local.
