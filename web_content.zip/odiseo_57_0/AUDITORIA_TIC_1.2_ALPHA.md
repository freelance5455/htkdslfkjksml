# Auditoría TIC 1.2-alpha — Odiseo 53.3-alpha

**Base:** Odiseo 53.2 + rama experimental TIC 1.2-alpha. **Resultado:** `PASS_WITH_EXPLICIT_SCOPE_LIMITS` para las pruebas sintéticas implementadas y la preparación del proyecto. **Versión estable global:** permanece 53.2; 53.3-alpha no se declara versión final.

## Cambios

- Nuevo `app/src/main/assets/tic_inferencia_odiseo.js`, cargado después de `tic_odiseo.js`.
- PID de dos fuentes mediante Williams–Beer `I_min`, con redundancia, dos términos únicos, sinergia y residuo de cierre.
- Transferencia de entropía condicionada a confusores observados en el pasado.
- Intervalo percentil 95% por moving-block bootstrap sobre tuplas temporales alineadas.
- Contraste nulo por desplazamiento circular, valor p con corrección +1 y corrección exploratoria observada menos media nula.
- Validador APK ampliado para exigir el módulo y calcular su SHA-256.

## Verificación ejecutada

- `node tests_odiseo_tic_inferencia.js`: 13/13 aserciones superadas, incluidos control de confusor común y control nulo independiente.
- Regresión: 32/32 archivos `tests_*.js` terminaron con código cero.
- Sintaxis: `node --check` superado para 30/30 módulos JavaScript de assets.
- `python -m py_compile crear_apk_odiseo.py`: superado.
- `python crear_apk_odiseo.py --solo-preparar`: `PREPARADO`; el informe incluye SHA-256 del módulo TIC 1.2-alpha.
- No se compiló ni instaló APK.

## Límites y cuestiones abiertas

1. `I_min` es una PID explícita, pero una elección entre varias definiciones y tiene limitaciones conocidas; falta comparar con otras PID y auditar casos de redundancia/sinergia más complejos.
2. El desplazamiento circular requiere estacionariedad aproximada; puede fallar con tendencia, estacionalidad o cambios de régimen.
3. El bootstrap por bloques depende del tamaño de bloque y no garantiza cobertura correcta en cualquier serie.
4. Restar la media del nulo es una corrección exploratoria, no una garantía universal de insesgadez.
5. Los confusores no observados siguen sin controlarse.
6. No hay exploración preregistrada de retardos múltiples ni corrección por multiplicidad.
7. Las pruebas son sintéticas y no validan datos reales ni causalidad física.
8. TIC sigue sin instrumentar intercambios reales con Penélope, Sherlock, Judas Tadeo e Integrador E; la carga en HTML no equivale a integración semántica con el orquestador.
9. No se ha probado Android físico ni se ha compilado/instalado APK.

## Veredicto

TIC 1.2-alpha amplía TIC 1.1 con una PID `I_min`, confusores observados y cuantificación inferencial temporal preliminar. Las pruebas disponibles validan el comportamiento en controles sintéticos concretos, no la validez general de los estimadores. Se conserva como rama experimental. Para cerrar 53.3 se exige auditoría independiente, controles de confusión/autocorrelación adversariales, comparación de PID, integración instrumentada y, por separado, compilación y prueba Android.
