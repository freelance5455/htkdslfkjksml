'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto').webcrypto;
const dir=path.join(__dirname,'app/src/main/assets'),html=fs.readFileSync(path.join(dir,'index.html'),'utf8');
const context={console,BigInt,Date,Math,JSON,Number,String,Array,Object,Map,Set,RegExp,Error,Promise,Uint8Array,TextEncoder,crypto,window:null,globalThis:null};context.window=context;context.globalThis=context;vm.createContext(context);
for(const [,file] of html.matchAll(/<script src="([^"]+)"/g))vm.runInContext(fs.readFileSync(path.join(dir,file),'utf8'),context,{filename:file});
(async()=>{const r=await context.OdiseoUnifiedCore.run();assert.strictEqual(r.total,25);assert.strictEqual(r.executed,25);assert.strictEqual(r.failed,0);assert.strictEqual(r.status,'ALL_MODULE_SMOKE_TESTS_PASSED');assert.strictEqual(r.governance.noAutomaticCodeMutation,true);assert.strictEqual(r.governance.noHypothesisPromotion,true);console.log('Odiseo 53.2 unified core: 25/25 modules; governance invariants OK.');})().catch(e=>{console.error(e);process.exit(1)});
