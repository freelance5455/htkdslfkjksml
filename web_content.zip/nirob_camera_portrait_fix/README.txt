NIROB SCANNER - IMPORT & STRAIGHTEN PATCH

This ZIP contains the updated HTML prototype, not an installable APK.

Changes in this patch:
- Made the image file input accessible to Android WebView file chooser implementations (off-screen instead of display:none), and reset the input before each import.
- Improved file import error messages.
- Added offline automatic small-angle deskew estimation and correction.
- Added Rotate 90 degrees left/right controls for photos/pages that are sideways.
- Added an Auto straighten button to re-run the skew correction on the source image.

How to use:
1. Extract the ZIP.
2. Open web/index.html in a browser that supports camera and file chooser permissions, or package it in a WebView that grants camera and file chooser access.
3. Tap Import and select a JPG/PNG image.
4. Use Auto straighten for small slants. Use Rotate 90 degrees left/right if the whole page is sideways.
5. Check the preview before exporting PDF/JPG.

Limitations:
- This prototype performs small-angle image deskew and 90-degree rotation; it does not do full perspective correction / document-corner detection.
- Camera and file picker support depend on the browser or Android WebView wrapper. A wrapper must implement WebChromeClient.onShowFileChooser for file import and grant camera permissions for camera access.
- It is not an APK and does not include offline Bengali/English OCR.
