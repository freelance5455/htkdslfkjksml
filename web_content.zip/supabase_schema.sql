-- Run this in Supabase Dashboard > SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'AERORE member',
  created_at timestamptz not null default now()
);
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  channel_name text not null default 'general',
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 4000),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.messages enable row level security;
create policy "profiles readable by signed in users" on public.profiles
 for select to authenticated using (true);
create policy "users insert own profile" on public.profiles
 for insert to authenticated with check (auth.uid() = id);
create policy "users update own profile" on public.profiles
 for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "signed in users read chat" on public.messages
 for select to authenticated using (true);
create policy "users send as themselves" on public.messages
 for insert to authenticated with check (auth.uid() = user_id);
-- Keep display names in sync when a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
 insert into public.profiles(id, display_name)
 values(new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)))
 on conflict (id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
 for each row execute procedure public.handle_new_user();
-- Enable Realtime for messages. If this errors because it is already included, ignore.
alter publication supabase_realtime add table public.messages;
