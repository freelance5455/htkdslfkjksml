-- V Cloud V3 - Supabase SQL
-- Run this whole file in Supabase SQL Editor.
-- IMPORTANT: create a PUBLIC Storage bucket named "videos" in Storage first.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  avatar_url text,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text not null,
  video_url text not null,
  caption text default '',
  visibility text not null default 'public' check (visibility in ('public','private')),
  likes_count integer not null default 0,
  comments_count integer not null default 0,
  reposts_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,video_id)
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check(follower_id <> following_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table if not exists public.reposts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,video_id)
);

create table if not exists public.saves (
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,video_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.comments enable row level security;
alter table public.reposts enable row level security;
alter table public.saves enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profiles readable" on public.profiles;
create policy "profiles readable" on public.profiles for select using (true);
drop policy if exists "own profile insert" on public.profiles;
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
drop policy if exists "own profile update" on public.profiles;
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

drop policy if exists "public videos readable" on public.videos;
create policy "public videos readable" on public.videos for select using (visibility='public' or auth.uid()=user_id);
drop policy if exists "own videos insert" on public.videos;
create policy "own videos insert" on public.videos for insert with check (auth.uid()=user_id);
drop policy if exists "own videos update" on public.videos;
create policy "own videos update" on public.videos for update using (auth.uid()=user_id);
drop policy if exists "own videos delete" on public.videos;
create policy "own videos delete" on public.videos for delete using (auth.uid()=user_id);

drop policy if exists "likes readable" on public.likes;
create policy "likes readable" on public.likes for select using (true);
drop policy if exists "own likes insert" on public.likes;
create policy "own likes insert" on public.likes for insert with check (auth.uid()=user_id);
drop policy if exists "own likes delete" on public.likes;
create policy "own likes delete" on public.likes for delete using (auth.uid()=user_id);

drop policy if exists "follows readable" on public.follows;
create policy "follows readable" on public.follows for select using (true);
drop policy if exists "own follows insert" on public.follows;
create policy "own follows insert" on public.follows for insert with check (auth.uid()=follower_id);
drop policy if exists "own follows delete" on public.follows;
create policy "own follows delete" on public.follows for delete using (auth.uid()=follower_id);

drop policy if exists "comments readable" on public.comments;
create policy "comments readable" on public.comments for select using (true);
drop policy if exists "own comments insert" on public.comments;
create policy "own comments insert" on public.comments for insert with check (auth.uid()=user_id);
drop policy if exists "own comments delete" on public.comments;
create policy "own comments delete" on public.comments for delete using (auth.uid()=user_id);

drop policy if exists "reposts readable" on public.reposts;
create policy "reposts readable" on public.reposts for select using (true);
drop policy if exists "own repost insert" on public.reposts;
create policy "own repost insert" on public.reposts for insert with check (auth.uid()=user_id);

drop policy if exists "saves own" on public.saves;
create policy "saves own" on public.saves for select using (auth.uid()=user_id);
drop policy if exists "saves insert" on public.saves;
create policy "saves insert" on public.saves for insert with check (auth.uid()=user_id);
drop policy if exists "saves delete" on public.saves;
create policy "saves delete" on public.saves for delete using (auth.uid()=user_id);

drop policy if exists "messages participants read" on public.messages;
create policy "messages participants read" on public.messages for select using (auth.uid()=sender_id or auth.uid()=receiver_id);
drop policy if exists "messages own insert" on public.messages;
create policy "messages own insert" on public.messages for insert with check (auth.uid()=sender_id);

-- Storage policies for a PUBLIC bucket named videos.
-- File paths are stored as: user-id/random-file.ext
drop policy if exists "videos bucket public read" on storage.objects;
create policy "videos bucket public read" on storage.objects for select using (bucket_id='videos');

drop policy if exists "videos own upload" on storage.objects;
create policy "videos own upload" on storage.objects for insert to authenticated
with check (bucket_id='videos' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "videos own delete" on storage.objects;
create policy "videos own delete" on storage.objects for delete to authenticated
using (bucket_id='videos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Counter triggers: keep the visible counts in sync.
create or replace function public.v_update_video_counts() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if tg_table_name='likes' then
    if tg_op='INSERT' then update videos set likes_count=likes_count+1 where id=new.video_id;
    elsif tg_op='DELETE' then update videos set likes_count=greatest(likes_count-1,0) where id=old.video_id; end if;
  elsif tg_table_name='comments' then
    if tg_op='INSERT' then update videos set comments_count=comments_count+1 where id=new.video_id;
    elsif tg_op='DELETE' then update videos set comments_count=greatest(comments_count-1,0) where id=old.video_id; end if;
  elsif tg_table_name='reposts' then
    if tg_op='INSERT' then update videos set reposts_count=reposts_count+1 where id=new.video_id;
    elsif tg_op='DELETE' then update videos set reposts_count=greatest(reposts_count-1,0) where id=old.video_id; end if;
  end if;
  return coalesce(new,old);
end $$;

drop trigger if exists likes_count_trigger on public.likes;
create trigger likes_count_trigger after insert or delete on public.likes for each row execute function public.v_update_video_counts();
drop trigger if exists comments_count_trigger on public.comments;
create trigger comments_count_trigger after insert or delete on public.comments for each row execute function public.v_update_video_counts();
drop trigger if exists reposts_count_trigger on public.reposts;
create trigger reposts_count_trigger after insert or delete on public.reposts for each row execute function public.v_update_video_counts();

-- Auto-create a profile after email signup.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,username,display_name)
  values(new.id,coalesce(new.raw_user_meta_data->>'username','user_'||substr(new.id::text,1,6)),coalesce(new.raw_user_meta_data->>'username','V'))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Enable Realtime for chat/messages and optionally comments.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;
