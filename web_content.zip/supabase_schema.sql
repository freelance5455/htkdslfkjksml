-- Khajura School Management System v6
-- Run this entire file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'teacher' check (role in ('admin','teacher','staff')),
  created_at timestamptz not null default now()
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  name_bn text not null,
  name_en text not null default '',
  birth_reg_no text not null default '',
  roll text not null default '',
  class_name text not null default '',
  section text not null default '',
  session text not null default '',
  guardian_name text not null default '',
  father text not null default '',
  father_name text not null default '',
  mother text not null default '',
  mother_name text not null default '',
  religion text not null default '',
  guardian_mobile text not null default '',
  dob date,
  address text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.staff (
  id uuid primary key default gen_random_uuid(),
  name_bn text not null,
  name_en text not null default '',
  birth_reg_no text not null default '',
  post text not null default '',
  pds_id text not null default '',
  index_no text not null default '',
  nid text not null default '',
  mobile text not null default '',
  joining_date date,
  mpo_date date,
  bank_account text not null default '',
  dob date,
  salary_scale text not null default '',
  pay_code text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  class_name text not null,
  subject_name text not null,
  full_marks numeric not null default 100,
  pass_marks numeric not null default 33,
  created_at timestamptz not null default now()
);

-- v8.15: Idempotent subject repair.
-- Drop any previous constraint/index, remove duplicates, then recreate uniqueness.
alter table public.subjects drop constraint if exists subjects_class_subject_unique;
drop index if exists public.subjects_class_subject_unique;

-- Keep the oldest row for each class+subject pair.
delete from public.subjects s
using (
  select id, row_number() over (
    partition by class_name, subject_name
    order by created_at asc nulls last, id asc
  ) as rn
  from public.subjects
) d
where s.id = d.id and d.rn > 1;

create unique index if not exists subjects_class_subject_unique
  on public.subjects(class_name, subject_name);

create table if not exists public.results (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  exam_name text not null,
  session text not null default '',
  class_name text not null default '',
  subject_name text not null,
  full_marks numeric not null default 100,
  obtained_marks numeric not null default 0,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(student_id, exam_name, session, subject_name)
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  attendance_date date not null,
  status text not null check (status in ('present','absent','late')),
  created_by uuid references auth.users(id),
  unique(student_id, attendance_date)
);

create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  notice_date date not null default current_date,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.staff enable row level security;
alter table public.subjects enable row level security;
alter table public.results enable row level security;
alter table public.attendance enable row level security;
alter table public.notices enable row level security;

-- Helper functions
create or replace function public.my_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Profiles
drop policy if exists "profiles read own" on public.profiles;
create policy "profiles read own" on public.profiles
for select using (id = auth.uid() or public.my_role() = 'admin');

drop policy if exists "admin update profiles" on public.profiles;
create policy "admin update profiles" on public.profiles
for update using (public.my_role() = 'admin');

-- Admin/teacher/staff can read school data
drop policy if exists "school users read students" on public.students;
create policy "school users read students" on public.students for select
using (auth.uid() is not null);

drop policy if exists "school users insert students" on public.students;
create policy "school users insert students" on public.students for insert
with check (public.my_role() in ('admin','teacher'));

drop policy if exists "school users update students" on public.students;
create policy "school users update students" on public.students for update
using (public.my_role() in ('admin','teacher'));

drop policy if exists "admin delete students" on public.students;
create policy "admin delete students" on public.students for delete
using (public.my_role() = 'admin');

drop policy if exists "school users read staff" on public.staff;
create policy "school users read staff" on public.staff for select
using (auth.uid() is not null);

drop policy if exists "admin manage staff" on public.staff;
create policy "admin manage staff" on public.staff for all
using (public.my_role() = 'admin')
with check (public.my_role() = 'admin');

drop policy if exists "school users read subjects" on public.subjects;
create policy "school users read subjects" on public.subjects for select
using (auth.uid() is not null);

drop policy if exists "admin manage subjects" on public.subjects;
create policy "admin manage subjects" on public.subjects for all
using (public.my_role() = 'admin')
with check (public.my_role() = 'admin');

drop policy if exists "school users read results" on public.results;
create policy "school users read results" on public.results for select
using (auth.uid() is not null);

drop policy if exists "teachers write results" on public.results;
create policy "teachers write results" on public.results for insert
with check (public.my_role() in ('admin','teacher'));

drop policy if exists "teachers update results" on public.results;
create policy "teachers update results" on public.results for update
using (public.my_role() in ('admin','teacher'));

drop policy if exists "admin delete results" on public.results;
create policy "admin delete results" on public.results for delete
using (public.my_role() = 'admin');

drop policy if exists "school users read attendance" on public.attendance;
create policy "school users read attendance" on public.attendance for select
using (auth.uid() is not null);

drop policy if exists "teachers write attendance" on public.attendance;
create policy "teachers write attendance" on public.attendance for insert
with check (public.my_role() in ('admin','teacher'));

drop policy if exists "teachers update attendance" on public.attendance;
create policy "teachers update attendance" on public.attendance for update
using (public.my_role() in ('admin','teacher'));

drop policy if exists "admin delete attendance" on public.attendance;
create policy "admin delete attendance" on public.attendance for delete
using (public.my_role() = 'admin');

drop policy if exists "school users read notices" on public.notices;
create policy "school users read notices" on public.notices for select
using (auth.uid() is not null);

drop policy if exists "admin manage notices" on public.notices;
create policy "admin manage notices" on public.notices for all
using (public.my_role() = 'admin')
with check (public.my_role() = 'admin');

-- Default subjects for classes 6-10.
insert into public.subjects(class_name,subject_name,full_marks,pass_marks)
select c,s,100,33
from (values ('৬ষ্ঠ'),('৭ম'),('৮ম'),('৯ম'),('১০ম')) C(class_name)
cross join (values
('বাংলা'),('ইংরেজি'),('গণিত'),('বিজ্ঞান'),('বাংলাদেশ ও বিশ্বপরিচয়')
) S(subject_name)
on conflict (class_name,subject_name) do nothing;

-- Automatically create profile after signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles(id,full_name,role)
  values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'teacher')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- v8.6: ensure component-mark columns exist and refresh PostgREST schema cache
-- Run this SQL once in Supabase SQL Editor after deploying v8.6.

-- v7.3 migration: subject-wise component marks
alter table public.subjects add column if not exists creative_full numeric not null default 100;
alter table public.subjects add column if not exists short_full numeric not null default 0;
alter table public.subjects add column if not exists mcq_full numeric not null default 0;
alter table public.subjects add column if not exists practical_full numeric not null default 0;
alter table public.results add column if not exists creative_marks numeric not null default 0;
alter table public.results add column if not exists short_marks numeric not null default 0;
alter table public.results add column if not exists mcq_marks numeric not null default 0;
alter table public.results add column if not exists practical_marks numeric not null default 0;

-- Keep existing subjects usable: by default the old full marks are treated as creative marks.
update public.subjects
set creative_full = full_marks,
    mcq_full = 0,
    practical_full = 0
where coalesce(creative_full,0)=0 and coalesce(mcq_full,0)=0 and coalesce(practical_full,0)=0;

-- Existing result marks remain available as the creative component until edited.
update public.results
set creative_marks = obtained_marks,
    mcq_marks = 0,
    practical_marks = 0
where coalesce(creative_marks,0)=0 and coalesce(mcq_marks,0)=0 and coalesce(practical_marks,0)=0 and obtained_marks<>0;


-- v7.4 PHOTO STORAGE
alter table public.students add column if not exists photo_url text not null default '';
-- v8.9 STUDENT PARENT / RELIGION FIELDS (legacy and current app names)
alter table public.students add column if not exists father text not null default '';
alter table public.students add column if not exists father_name text not null default '';
alter table public.students add column if not exists mother text not null default '';
alter table public.students add column if not exists mother_name text not null default '';
alter table public.students add column if not exists religion text not null default '';

create or replace function public.sync_student_parent_columns()
returns trigger language plpgsql as $$
begin
  if TG_OP = 'INSERT' then
    NEW.father_name := COALESCE(NULLIF(NEW.father_name, ''), NEW.father, '');
    NEW.father := COALESCE(NULLIF(NEW.father, ''), NEW.father_name, '');
    NEW.mother_name := COALESCE(NULLIF(NEW.mother_name, ''), NEW.mother, '');
    NEW.mother := COALESCE(NULLIF(NEW.mother, ''), NEW.mother_name, '');
  else
    if NEW.father_name is distinct from OLD.father_name then NEW.father := NEW.father_name;
    elsif NEW.father is distinct from OLD.father then NEW.father_name := NEW.father; end if;
    if NEW.mother_name is distinct from OLD.mother_name then NEW.mother := NEW.mother_name;
    elsif NEW.mother is distinct from OLD.mother then NEW.mother_name := NEW.mother; end if;
  end if;
  return NEW;
end;
$$;
drop trigger if exists sync_student_parent_columns_trigger on public.students;
create trigger sync_student_parent_columns_trigger before insert or update on public.students
for each row execute function public.sync_student_parent_columns();
update public.students set father_name=COALESCE(NULLIF(father_name,''),father,''), father=COALESCE(NULLIF(father,''),father_name,''), mother_name=COALESCE(NULLIF(mother_name,''),mother,''), mother=COALESCE(NULLIF(mother,''),mother_name,'');

alter table public.staff add column if not exists photo_url text not null default '';

-- Public school photo bucket. Files are still uploaded only by authenticated users.
insert into storage.buckets (id, name, public)
values ('school-photos', 'school-photos', true)
on conflict (id) do update set public = true;

drop policy if exists "school photos public read" on storage.objects;
create policy "school photos public read" on storage.objects
for select using (bucket_id = 'school-photos');

drop policy if exists "school photos authenticated upload" on storage.objects;
create policy "school photos authenticated upload" on storage.objects
for insert to authenticated with check (bucket_id = 'school-photos');

drop policy if exists "school photos authenticated update" on storage.objects;
create policy "school photos authenticated update" on storage.objects
for update to authenticated using (bucket_id = 'school-photos') with check (bucket_id = 'school-photos');

drop policy if exists "school photos authenticated delete" on storage.objects;
create policy "school photos authenticated delete" on storage.objects
for delete to authenticated using (bucket_id = 'school-photos');


-- Remove generic placeholder subjects; the detailed exam subjects below are used instead.
delete from public.subjects
where class_name in ('৬ষ্ঠ','৭ম','৮ম','৯ম','১০ম')
  and subject_name in ('বাংলা','ইংরেজি');

-- v8.0: Complete 2026 subject bank for classes 6-10.
-- Component order: creative, short-answer, MCQ, practical.
insert into public.subjects(class_name,subject_name,full_marks,pass_marks,creative_full,short_full,mcq_full,practical_full)
values
('৬ষ্ঠ','বাংলা ১ম পত্র',100,33,70,0,30,0),('৬ষ্ঠ','বাংলা ২য় পত্র',50,17,30,0,20,0),('৬ষ্ঠ','ইংরেজি ১ম পত্র',100,33,70,0,30,0),('৬ষ্ঠ','ইংরেজি ২য় পত্র',50,17,30,0,20,0),('৬ষ্ঠ','গণিত',100,33,70,0,30,0),('৬ষ্ঠ','বিজ্ঞান',100,33,70,0,30,0),('৬ষ্ঠ','বাংলাদেশ ও বিশ্বপরিচয়',100,33,70,0,30,0),('৬ষ্ঠ','তথ্য ও যোগাযোগ প্রযুক্তি',50,17,25,0,25,0),('৬ষ্ঠ','শারীরিক শিক্ষা ও স্বাস্থ্য',50,17,50,0,0,0),('৬ষ্ঠ','কর্ম ও জীবনমুখী শিক্ষা',50,17,50,0,0,0),('৬ষ্ঠ','কৃষিশিক্ষা',100,33,70,0,30,0),('৬ষ্ঠ','গার্হস্থ্য বিজ্ঞান',100,33,70,0,30,0),('৬ষ্ঠ','চারু ও কারুকলা',50,17,50,0,0,0),
('৭ম','বাংলা ১ম পত্র',100,33,70,0,30,0),('৭ম','বাংলা ২য় পত্র',50,17,30,0,20,0),('৭ম','ইংরেজি ১ম পত্র',100,33,70,0,30,0),('৭ম','ইংরেজি ২য় পত্র',50,17,30,0,20,0),('৭ম','গণিত',100,33,70,0,30,0),('৭ম','বিজ্ঞান',100,33,70,0,30,0),('৭ম','বাংলাদেশ ও বিশ্বপরিচয়',100,33,70,0,30,0),('৭ম','তথ্য ও যোগাযোগ প্রযুক্তি',50,17,25,0,25,0),('৭ম','শারীরিক শিক্ষা ও স্বাস্থ্য',50,17,50,0,0,0),('৭ম','কর্ম ও জীবনমুখী শিক্ষা',50,17,50,0,0,0),('৭ম','কৃষিশিক্ষা',100,33,70,0,30,0),('৭ম','গার্হস্থ্য বিজ্ঞান',100,33,70,0,30,0),('৭ম','চারু ও কারুকলা',50,17,50,0,0,0),
('৮ম','বাংলা ১ম পত্র',100,33,70,0,30,0),('৮ম','বাংলা ২য় পত্র',50,17,30,0,20,0),('৮ম','ইংরেজি ১ম পত্র',100,33,70,0,30,0),('৮ম','ইংরেজি ২য় পত্র',50,17,30,0,20,0),('৮ম','গণিত',100,33,70,0,30,0),('৮ম','বিজ্ঞান',100,33,70,0,30,0),('৮ম','বাংলাদেশ ও বিশ্বপরিচয়',100,33,70,0,30,0),('৮ম','তথ্য ও যোগাযোগ প্রযুক্তি',50,17,25,0,25,0),('৮ম','শারীরিক শিক্ষা ও স্বাস্থ্য',50,17,50,0,0,0),('৮ম','কর্ম ও জীবনমুখী শিক্ষা',50,17,50,0,0,0),('৮ম','কৃষিশিক্ষা',100,33,70,0,30,0),('৮ম','গার্হস্থ্য বিজ্ঞান',100,33,70,0,30,0),('৮ম','চারু ও কারুকলা',50,17,50,0,0,0),
('৯ম','বাংলা ১ম পত্র',100,33,70,0,30,0),('৯ম','বাংলা ২য় পত্র',100,33,70,0,30,0),('৯ম','ইংরেজি ১ম পত্র',100,33,100,0,0,0),('৯ম','ইংরেজি ২য় পত্র',100,33,100,0,0,0),('৯ম','গণিত',100,33,70,0,30,0),('৯ম','তথ্য ও যোগাযোগ প্রযুক্তি',50,17,25,0,0,25),('৯ম','ক্যারিয়ার শিক্ষা',50,17,50,0,0,0),('৯ম','শারীরিক শিক্ষা, স্বাস্থ্যবিজ্ঞান ও খেলাধুলা',50,17,25,0,0,25),('৯ম','বিজ্ঞান',100,33,70,0,30,0),('৯ম','বাংলাদেশ ও বিশ্বপরিচয়',100,33,70,0,30,0),('৯ম','ইসলাম শিক্ষা',100,33,70,0,30,0),('৯ম','হিন্দুধর্ম শিক্ষা',100,33,70,0,30,0),('৯ম','বৌদ্ধধর্ম শিক্ষা',100,33,70,0,30,0),('৯ম','খ্রিষ্টধর্ম শিক্ষা',100,33,70,0,30,0),('৯ম','পদার্থবিজ্ঞান',100,33,50,0,25,25),('৯ম','রসায়ন',100,33,50,0,25,25),('৯ম','জীববিজ্ঞান',100,33,50,0,25,25),('৯ম','উচ্চতর গণিত',100,33,70,0,30,0),('৯ম','বাংলাদেশের ইতিহাস ও বিশ্বসভ্যতা',100,33,70,0,30,0),('৯ম','ভূগোল ও পরিবেশ',100,33,70,0,30,0),('৯ম','অর্থনীতি',100,33,70,0,30,0),('৯ম','পৌরনীতি ও নাগরিকতা',100,33,70,0,30,0),('৯ম','হিসাববিজ্ঞান',100,33,70,0,30,0),('৯ম','ব্যবসায় উদ্যোগ',100,33,70,0,30,0),('৯ম','ফিন্যান্স ও ব্যাংকিং',100,33,70,0,30,0),('৯ম','কৃষিশিক্ষা',100,33,50,0,25,25),('৯ম','গার্হস্থ্যবিজ্ঞান',100,33,50,0,25,25),('৯ম','চারু ও কারুকলা',100,33,70,0,30,0),('৯ম','সংগীত',100,33,70,0,30,0),
('১০ম','বাংলা ১ম পত্র',100,33,70,0,30,0),('১০ম','বাংলা ২য় পত্র',100,33,70,0,30,0),('১০ম','ইংরেজি ১ম পত্র',100,33,100,0,0,0),('১০ম','ইংরেজি ২য় পত্র',100,33,100,0,0,0),('১০ম','গণিত',100,33,70,0,30,0),('১০ম','তথ্য ও যোগাযোগ প্রযুক্তি',50,17,25,0,0,25),('১০ম','ক্যারিয়ার শিক্ষা',50,17,50,0,0,0),('১০ম','শারীরিক শিক্ষা, স্বাস্থ্যবিজ্ঞান ও খেলাধুলা',50,17,25,0,0,25),('১০ম','বিজ্ঞান',100,33,70,0,30,0),('১০ম','বাংলাদেশ ও বিশ্বপরিচয়',100,33,70,0,30,0),('১০ম','ইসলাম শিক্ষা',100,33,70,0,30,0),('১০ম','হিন্দুধর্ম শিক্ষা',100,33,70,0,30,0),('১০ম','বৌদ্ধধর্ম শিক্ষা',100,33,70,0,30,0),('১০ম','খ্রিষ্টধর্ম শিক্ষা',100,33,70,0,30,0),('১০ম','পদার্থবিজ্ঞান',100,33,50,0,25,25),('১০ম','রসায়ন',100,33,50,0,25,25),('১০ম','জীববিজ্ঞান',100,33,50,0,25,25),('১০ম','উচ্চতর গণিত',100,33,70,0,30,0),('১০ম','বাংলাদেশের ইতিহাস ও বিশ্বসভ্যতা',100,33,70,0,30,0),('১০ম','ভূগোল ও পরিবেশ',100,33,70,0,30,0),('১০ম','অর্থনীতি',100,33,70,0,30,0),('১০ম','পৌরনীতি ও নাগরিকতা',100,33,70,0,30,0),('১০ম','হিসাববিজ্ঞান',100,33,70,0,30,0),('১০ম','ব্যবসায় উদ্যোগ',100,33,70,0,30,0),('১০ম','ফিন্যান্স ও ব্যাংকিং',100,33,70,0,30,0),('১০ম','কৃষিশিক্ষা',100,33,50,0,25,25),('১০ম','গার্হস্থ্যবিজ্ঞান',100,33,50,0,25,25),('১০ম','চারু ও কারুকলা',100,33,70,0,30,0),('১০ম','সংগীত',100,33,70,0,30,0)
on conflict (class_name,subject_name) do update set full_marks=excluded.full_marks,pass_marks=excluded.pass_marks,creative_full=excluded.creative_full,short_full=excluded.short_full,mcq_full=excluded.mcq_full,practical_full=excluded.practical_full;


-- v8.9: compatibility fix for father/mother column naming across app versions
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS father text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS father_name text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS mother text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS mother_name text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS religion text NOT NULL DEFAULT '';

-- Keep legacy and current field names populated for compatibility.
UPDATE public.students
SET father = CASE WHEN COALESCE(father, '') = '' THEN COALESCE(father_name, '') ELSE father END,
    father_name = CASE WHEN COALESCE(father_name, '') = '' THEN COALESCE(father, '') ELSE father_name END,
    mother = CASE WHEN COALESCE(mother, '') = '' THEN COALESCE(mother_name, '') ELSE mother END,
    mother_name = CASE WHEN COALESCE(mother_name, '') = '' THEN COALESCE(mother, '') ELSE mother_name END;

-- Refresh Supabase/PostgREST schema cache after adding the columns.
NOTIFY pgrst, 'reload schema';


-- v8.9: refresh Data API schema cache after migrations
NOTIFY pgrst, 'reload schema';


-- v8.11: School income and expense ledger
create table if not exists public.income_expenses (
  id uuid primary key default gen_random_uuid(),
  transaction_date date not null default current_date,
  type text not null check (type in ('income','expense')),
  category text not null default 'অন্যান্য',
  description text not null default '',
  amount numeric(14,2) not null check (amount > 0),
  payment_method text not null default '',
  voucher_no text not null default '',
  notes text not null default '',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.income_expenses enable row level security;
drop policy if exists "school users read income expenses" on public.income_expenses;
create policy "school users read income expenses" on public.income_expenses for select using (auth.uid() is not null);
drop policy if exists "admin manage income expenses" on public.income_expenses;
create policy "admin manage income expenses" on public.income_expenses for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create index if not exists income_expenses_date_idx on public.income_expenses(transaction_date desc);
create index if not exists income_expenses_type_idx on public.income_expenses(type);

-- Ensure both religion subjects exist for all classes; the app shows only the subject matching each student's religion.
insert into public.subjects(class_name,subject_name,full_marks,pass_marks,creative_full,short_full,mcq_full,practical_full)
select c.class_name, r.subject_name, 100,33,70,0,30,0
from (values ('৬ষ্ঠ'),('৭ম'),('৮ম'),('৯ম'),('১০ম')) c(class_name)
cross join (values ('ইসলাম শিক্ষা'),('হিন্দুধর্ম শিক্ষা')) r(subject_name)
on conflict (class_name, subject_name) do nothing;
NOTIFY pgrst, 'reload schema';

-- v8.12: Keep only subjects used for examinations in this school system.
-- 6th-8th: core written subjects + ICT + Agriculture + religion (one per student).
-- 9th-10th: core subjects + religion + science/humanities/business/agriculture exam subjects.
delete from public.subjects
where subject_name in (
  'শারীরিক শিক্ষা ও স্বাস্থ্য',
  'শারীরিক শিক্ষা, স্বাস্থ্যবিজ্ঞান ও খেলাধুলা',
  'কর্ম ও জীবনমুখী শিক্ষা',
  'ক্যারিয়ার শিক্ষা',
  'চারু ও কারুকলা',
  'সংগীত',
  'গার্হস্থ্য বিজ্ঞান',
  'গার্হস্থ্যবিজ্ঞান',
  'বৌদ্ধধর্ম শিক্ষা',
  'খ্রিষ্টধর্ম শিক্ষা'
);

-- English is stored without a separate MCQ component in this system.
update public.subjects
set mcq_full=0,
    creative_full=full_marks,
    short_full=0
where subject_name in ('ইংরেজি ১ম পত্র','ইংরেজি ২য় পত্র');

notify pgrst, 'reload schema';
