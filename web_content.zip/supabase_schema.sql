-- MiiPlaner Online: Supabase starter schema
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default '',
  avatar_url text,
  bio text,
  created_at timestamptz not null default now()
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  friend_id uuid not null references public.profiles(id) on delete cascade,
  status text not null check (status in ('pending','accepted')),
  created_at timestamptz not null default now(),
  unique(user_id, friend_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text not null default 'Приватний чат',
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(conversation_id,user_id)
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.friendships enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;

drop policy if exists "profiles_select_authenticated" on public.profiles;
create policy "profiles_select_authenticated" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles_insert_self" on public.profiles;
create policy "profiles_insert_self" on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists "profiles_update_self" on public.profiles;
create policy "profiles_update_self" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "friendships_select_participants" on public.friendships;
create policy "friendships_select_participants" on public.friendships for select to authenticated
using (user_id = auth.uid() or friend_id = auth.uid());
drop policy if exists "friendships_insert_self" on public.friendships;
create policy "friendships_insert_self" on public.friendships for insert to authenticated
with check (user_id = auth.uid());
drop policy if exists "friendships_update_recipient" on public.friendships;
create policy "friendships_update_recipient" on public.friendships for update to authenticated
using (friend_id = auth.uid()) with check (friend_id = auth.uid());
drop policy if exists "friendships_delete_participant" on public.friendships;
create policy "friendships_delete_participant" on public.friendships for delete to authenticated
using (user_id = auth.uid() or friend_id = auth.uid());

drop policy if exists "conversations_member_select" on public.conversations;
create policy "conversations_member_select" on public.conversations for select to authenticated
using (exists(select 1 from public.conversation_members m where m.conversation_id=id and m.user_id=auth.uid()));
drop policy if exists "conversations_insert_authenticated" on public.conversations;
create policy "conversations_insert_authenticated" on public.conversations for insert to authenticated with check (true);

drop policy if exists "members_select_own_conversations" on public.conversation_members;
create policy "members_select_own_conversations" on public.conversation_members for select to authenticated
using (exists(select 1 from public.conversation_members me where me.conversation_id=conversation_id and me.user_id=auth.uid()));
drop policy if exists "members_insert_authenticated" on public.conversation_members;
create policy "members_insert_authenticated" on public.conversation_members for insert to authenticated with check (user_id=auth.uid() or exists(select 1 from public.conversation_members me where me.conversation_id=conversation_id and me.user_id=auth.uid()));

drop policy if exists "messages_select_members" on public.messages;
create policy "messages_select_members" on public.messages for select to authenticated
using (exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid()));
drop policy if exists "messages_insert_members" on public.messages;
create policy "messages_insert_members" on public.messages for insert to authenticated
with check (sender_id=auth.uid() and exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid()));

drop policy if exists "notifications_select_self" on public.notifications;
create policy "notifications_select_self" on public.notifications for select to authenticated using (user_id=auth.uid());
drop policy if exists "notifications_insert_authenticated" on public.notifications;
create policy "notifications_insert_authenticated" on public.notifications for insert to authenticated with check (true);

-- Enable database changes for real-time chat/notifications.
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;
