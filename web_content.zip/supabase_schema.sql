-- K2 PULSE / Supabase starter schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default '',
  phone text,
  discoverable_by_phone boolean not null default false,
  role text default '',
  status text default '',
  call_sign text default '',
  bio text default '',
  avatar_url text,
  cover_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text not null default 'Приватний чат',
  is_group boolean not null default false,
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(conversation_id,user_id)
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  body text not null,
  priority text not null default 'Звичайний',
  status text not null default 'Надіслано',
  created_at timestamptz not null default now()
);

create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  note_type text not null default 'Особиста нотатка',
  remind_at timestamptz,
  done boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.training_progress (
  user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id text not null,
  score integer not null default 0,
  completed_at timestamptz not null default now(),
  primary key(user_id,lesson_id)
);

create table if not exists public.notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.requests enable row level security;
alter table public.notes enable row level security;
alter table public.training_progress enable row level security;
alter table public.notifications enable row level security;

-- Basic self/participant policies. For production, review with a Supabase security specialist.
create policy "profiles own or discoverable" on public.profiles
for select to authenticated using (id=auth.uid() or discoverable_by_phone=true);
create policy "profiles insert own" on public.profiles
for insert to authenticated with check(id=auth.uid());
create policy "profiles update own" on public.profiles
for update to authenticated using(id=auth.uid()) with check(id=auth.uid());

create policy "conversation members can read conversations" on public.conversations
for select to authenticated using (
  exists(select 1 from public.conversation_members m where m.conversation_id=id and m.user_id=auth.uid())
);
create policy "create conversation" on public.conversations
for insert to authenticated with check(created_by=auth.uid());

create policy "members read membership" on public.conversation_members
for select to authenticated using (
  exists(select 1 from public.conversation_members x where x.conversation_id=conversation_id and x.user_id=auth.uid())
);
create policy "add self or creator can add" on public.conversation_members
for insert to authenticated with check (
  user_id=auth.uid() or exists(select 1 from public.conversations c where c.id=conversation_id and c.created_by=auth.uid())
);

create policy "messages read by members" on public.messages
for select to authenticated using (
  exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid())
);
create policy "messages send as self" on public.messages
for insert to authenticated with check (
  sender_id=auth.uid() and exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid())
);

create policy "own requests" on public.requests
for select to authenticated using(sender_id=auth.uid());
create policy "send requests" on public.requests
for insert to authenticated with check(sender_id=auth.uid());

create policy "own notes" on public.notes
for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

create policy "own training" on public.training_progress
for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

create policy "own notifications" on public.notifications
for select to authenticated using(user_id=auth.uid());

alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;
