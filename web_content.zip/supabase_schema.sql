-- PrivateVault production schema outline (Supabase/PostgreSQL)
-- Run only after creating your Supabase project; review policies before production.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz default now()
);

create table if not exists public.vault_files (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  mime_type text,
  size_bytes bigint not null default 0,
  created_at timestamptz default now()
);

-- Production RLS policies must be added carefully.
-- Admin access should be enforced server-side, not by a secret in the APK.
