package com.lennix.x7.settings

import android.content.Context

/** Preferencias locales de LENNIX X7. */
object AppSettings {
    private fun p(ctx: Context) =
        ctx.getSharedPreferences("lennix_settings", Context.MODE_PRIVATE)

    fun autoOpen(ctx: Context): Boolean = p(ctx).getBoolean("auto_open", true)
    fun setAutoOpen(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("auto_open", v).apply() }

    fun autoProfile(ctx: Context): Boolean = p(ctx).getBoolean("auto_profile", false)
    fun setAutoProfile(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("auto_profile", v).apply() }

    fun haptic(ctx: Context): Boolean = p(ctx).getBoolean("haptic", true)
    fun setHaptic(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("haptic", v).apply() }

    fun skipSplash(ctx: Context): Boolean = p(ctx).getBoolean("skip_splash", false)
    fun setSkipSplash(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("skip_splash", v).apply() }

    fun panelY(ctx: Context): Int = p(ctx).getInt("panel_y", -1)
    fun setPanelY(ctx: Context, y: Int) { p(ctx).edit().putInt("panel_y", y).apply() }
}
