package com.lennix.x7.profile

import android.content.Context
import com.lennix.x7.controls.SystemControls

/**
 * Perfiles con efecto real y reversible. No toca CPU, GPU ni limites termicos.
 *  - Equilibrado: restaura los ajustes originales.
 *  - Bateria: brillo al 30 % (requiere permiso de ajustes).
 *  - Rendimiento: No molestar en modo prioridad (requiere acceso a No molestar).
 */
object ProfileEngine {
    fun apply(ctx: Context, p: Profile): String {
        SystemControls.restoreAll(ctx)
        val note = when (p) {
            Profile.BALANCED -> "ajustes originales"
            Profile.BATTERY ->
                if (SystemControls.setBrightness(ctx, 30)) "brillo al 30 %"
                else "falta el permiso de brillo"
            Profile.PERFORMANCE ->
                if (SystemControls.enableDnd(ctx)) "No molestar (prioridad)"
                else "falta el permiso de No molestar"
        }
        ProfileStore.set(ctx, p)
        return "${p.label}: $note"
    }
}
