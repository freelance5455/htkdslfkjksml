package com.lennix.x7.safety

enum class Operation {
    READ_DEVICE_INFO,
    OPEN_EDGE_PANEL,
    CLEAN_THUMBNAILS,
    CHANGE_REFRESH_RATE,
    CHANGE_SYSTEM_SETTINGS,
    FORCE_STOP_APP,
    CHANGE_THERMAL_SETTINGS,
    CHANGE_CPU_GOVERNOR,
    MODIFY_DOZE
}

data class SafetyDecision(val allowed: Boolean, val reason: String)

object SafetyEngine {
    fun check(operation: Operation): SafetyDecision = when (operation) {
        Operation.READ_DEVICE_INFO -> SafetyDecision(true, "Lectura permitida")
        Operation.OPEN_EDGE_PANEL -> SafetyDecision(true, "Requiere permiso de superposición")
        Operation.CLEAN_THUMBNAILS -> SafetyDecision(true, "Solo rutas fijas de miniaturas, con registro")
        else -> SafetyDecision(false, "Operación desactivada en la versión segura")
    }
}
