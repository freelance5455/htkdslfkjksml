package com.lennix.x7

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.lennix.x7.device.DeviceProbe
import com.lennix.x7.edge.EdgeService
import com.lennix.x7.controls.SystemControls
import com.lennix.x7.games.GameRepository
import com.lennix.x7.monitor.Monitor
import com.lennix.x7.profile.ProfileEngine
import com.lennix.x7.profile.ProfileStore
import com.lennix.x7.sessions.SessionStore
import com.lennix.x7.settings.AppSettings
import com.lennix.x7.storage.JunkCleaner
import com.lennix.x7.watcher.GameWatcherService

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun toast(s: String) =
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 14)
        window.navigationBarColor = Color.rgb(12, 12, 14)
        window.decorView.setBackgroundColor(Color.rgb(12, 12, 14))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }

        fun label(value: String, size: Float, color: Int) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, dp(8), 0, dp(8))
            }

        fun action(value: String, callback: () -> Unit) =
            Button(this).apply {
                text = value
                isAllCaps = false
                setOnClickListener { callback() }
            }

        fun toggleAction(title: String, initial: Boolean, onChange: (Boolean) -> Unit): Button {
            var state = initial
            val b = Button(this)
            b.isAllCaps = false
            b.text = "$title: ${if (state) "Sí" else "No"}"
            b.setOnClickListener {
                state = !state
                onChange(state)
                b.text = "$title: ${if (state) "Sí" else "No"}"
            }
            return b
        }

        root.addView(label("LENNIX X7", 30f, Color.RED).apply {
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        root.addView(label("UNIVERSAL GAME BOOSTER", 13f, Color.LTGRAY)
            .apply { gravity = Gravity.CENTER })

        root.addView(label("ESTADO DEL DISPOSITIVO", 18f, Color.WHITE))
        status = label("", 14f, Color.LTGRAY)
        root.addView(status)
        root.addView(action("Actualizar diagnóstico") { refreshStatus() })

        root.addView(label("PANEL EDGE", 18f, Color.WHITE))
        root.addView(action("Activar panel Edge") { enableEdge() })
        root.addView(action("Cerrar panel Edge") {
            stopService(Intent(this, EdgeService::class.java))
            toast("Panel cerrado")
        })

        root.addView(label("DETECCIÓN AUTOMÁTICA DE JUEGOS", 18f, Color.WHITE))
        root.addView(action("1. Permiso de acceso de uso") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(action("2. Elegir juegos") { pickGames() })
        root.addView(action("3. Activar detección automática") { startWatcher() })
        root.addView(action("Detener detección") {
            stopService(Intent(this, GameWatcherService::class.java))
            toast("Detección detenida")
        })

        root.addView(label("BIBLIOTECA Y AUTOMATIZACIÓN", 18f, Color.WHITE))
        root.addView(action("Mis juegos (abrir)") { showLibrary() })
        root.addView(toggleAction("Apertura automática del panel", AppSettings.autoOpen(this)) {
            AppSettings.setAutoOpen(this, it)
        })
        root.addView(toggleAction("Perfil automático al detectar juego", AppSettings.autoProfile(this)) {
            AppSettings.setAutoProfile(this, it)
        })

        root.addView(label("ACCESOS RÁPIDOS", 18f, Color.WHITE))
        root.addView(action("Ajustes de pantalla") { openSettings(Settings.ACTION_DISPLAY_SETTINGS) })
        root.addView(action("Ajustes de batería") { openSettings(Intent.ACTION_POWER_USAGE_SUMMARY) })

        root.addView(label("PERFILES", 18f, Color.WHITE))
        root.addView(action("Cambiar perfil") { cycleProfile() })
        root.addView(action("Permiso: modificar brillo") {
            startActivity(Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:$packageName")
            ))
        })
        root.addView(action("Permiso: No molestar") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        root.addView(action("Restaurar ajustes originales") {
            SystemControls.restoreAll(this)
            toast("Ajustes restaurados")
            refreshStatus()
        })

        root.addView(label("HISTORIAL DE SESIONES", 18f, Color.WHITE))
        root.addView(action("Ver historial") { showHistory() })
        root.addView(action("Borrar historial") {
            SessionStore.clear(this)
            toast("Historial borrado")
        })

        root.addView(label("LIMPIEZA", 18f, Color.WHITE))
        root.addView(action("Borrar miniaturas basura") { cleanThumbnails() })
        root.addView(action("Limpiar caché de apps (Ajustes)") { openStorage() })

        root.addView(label("MODO DE SEGURIDAD", 18f, Color.RED))
        root.addView(label(
            "Sin root, sin cambios de kernel y sin cierre forzado de aplicaciones. " +
                "La limpieza solo toca miniaturas y la caché propia, con registro.",
            14f, Color.LTGRAY
        ))

        val content = ScrollView(this).apply { addView(root) }
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val safe = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(dp(20) + safe.left, dp(24) + safe.top,
                    dp(20) + safe.right, dp(20) + safe.bottom)
                insets
            }
        }
        setContentView(content)
        refreshStatus()

        when (intent.getStringExtra("open")) {
            "history" -> showHistory()
            "library" -> showLibrary()
        }
    }

    private fun refreshStatus() {
        val d = DeviceProbe.read()
        val overlay = Settings.canDrawOverlays(this)
        val usage = GameWatcherService.hasUsageAccess(this)
        status.text = """
            Fabricante: ${d.manufacturer}
            Modelo: ${d.model}
            Android: ${d.androidVersion} (API ${d.sdk})
            Arquitectura: ${d.abi}
            Panel Edge: ${if (overlay) "Autorizado" else "Sin permiso"}
            Acceso de uso: ${if (usage) "Autorizado" else "Sin permiso"}
            Brillo (permiso): ${if (SystemControls.canWriteSettings(this)) "Autorizado" else "Sin permiso"}
            No molestar (permiso): ${if (SystemControls.dndGranted(this)) "Autorizado" else "Sin permiso"}
            Perfil: ${ProfileStore.get(this).label}
            Temp. bateria: ${Monitor.batteryTempC(this)?.let { String.format("%.1f C", it) } ?: "n/d"}
        """.trimIndent()
    }

    private fun enableEdge() {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Mostrar sobre otras apps")
                .setMessage(
                    "El panel Edge necesita este permiso para aparecer sobre tus juegos. " +
                        "Se activa en Ajustes y puedes quitarlo cuando quieras. " +
                        "Sin el, el resto de la app sigue funcionando."
                )
                .setPositiveButton("Abrir ajustes") { _, _ ->
                    startActivity(Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    ))
                }
                .setNegativeButton("Ahora no", null)
                .show()
            return
        }
        try {
            startService(Intent(this, EdgeService::class.java))
        } catch (e: Exception) {
            toast("No se pudo abrir el panel. Vuelve a intentarlo.")
        }
    }

    private fun startWatcher() {
        if (!GameWatcherService.hasUsageAccess(this)) {
            toast("Falta el acceso de uso")
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) { enableEdge(); return }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val i = Intent(this, GameWatcherService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        toast("Detección activada")
    }

    private fun pickGames() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val saved = GameRepository.manual(this)
        val checked = BooleanArray(apps.size) { apps[it].first in saved }

        AlertDialog.Builder(this)
            .setTitle("Juegos con panel automático")
            .setMultiChoiceItems(
                apps.map { it.second }.toTypedArray(), checked
            ) { _, i, on -> checked[i] = on }
            .setPositiveButton("Guardar") { _, _ ->
                GameRepository.setManual(
                    this,
                    apps.indices.filter { checked[it] }.map { apps[it].first }.toSet()
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun cleanThumbnails() {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Requiere Android 11 o superior"); return
        }
        if (!Environment.isExternalStorageManager()) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")
            ))
            return
        }
        Thread {
            val bytes = JunkCleaner.scanBytes(this)
            runOnUiThread {
                if (bytes == 0L) {
                    toast("No hay nada que borrar")
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Borrar miniaturas")
                        .setMessage(
                            "Se borrarán %.1f MB de miniaturas y caché propia. ".format(bytes / 1048576.0) +
                                "Tus fotos no se tocan; Galería regenera las miniaturas."
                        )
                        .setPositiveButton("Borrar") { _, _ ->
                            Thread {
                                val freed = JunkCleaner.clean(this)
                                runOnUiThread {
                                    toast("Liberados %.1f MB".format(freed / 1048576.0))
                                }
                            }.start()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            }
        }.start()
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (_: Exception) {
            toast("No disponible en este dispositivo")
        }
    }

    private fun showLibrary() {
        val pm = packageManager
        val items = GameRepository.manual(this).mapNotNull { pkg ->
            try {
                Triple(
                    pkg,
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(),
                    pm.getApplicationIcon(pkg)
                )
            } catch (_: Exception) {
                null
            }
        }.sortedBy { it.second.lowercase() }

        if (items.isEmpty()) {
            toast("Aún no elegiste juegos. Usa 'Elegir juegos'.")
            return
        }

        val list = ListView(this)
        list.adapter = object : BaseAdapter() {
            override fun getCount(): Int = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(16), dp(10), dp(16), dp(10))
                val icon = ImageView(this@MainActivity)
                icon.setImageDrawable(items[position].third)
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                val name = TextView(this@MainActivity)
                name.text = items[position].second
                name.textSize = 16f
                name.setPadding(dp(14), 0, 0, 0)
                row.addView(name)
                return row
            }
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Mis juegos")
            .setView(list)
            .setNegativeButton("Cerrar", null)
            .create()
        list.setOnItemClickListener { _, _, position, _ ->
            val launch = pm.getLaunchIntentForPackage(items[position].first)
            if (launch != null) {
                dialog.dismiss()
                startActivity(launch)
            } else {
                toast("No se puede abrir este juego")
            }
        }
        dialog.show()
    }

    private fun cycleProfile() {
        val next = ProfileStore.next(ProfileStore.get(this))
        toast(ProfileEngine.apply(this, next))
        refreshStatus()
    }

    private fun showHistory() {
        val list = SessionStore.readAll(this).takeLast(20).reversed()
        if (list.isEmpty()) {
            toast("Sin sesiones registradas")
            return
        }
        val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault())
        val pm = packageManager
        val lines = list.map { s ->
            val name = try {
                pm.getApplicationLabel(pm.getApplicationInfo(s.pkg, 0)).toString()
            } catch (_: Exception) {
                s.pkg
            }
            val mins = ((s.endMs - s.startMs) / 60000L).coerceAtLeast(0L)
            val perfil = if (s.profile.isNotEmpty()) " - ${s.profile}" else ""
            "$name - ${fmt.format(java.util.Date(s.startMs))} - $mins min$perfil"
        }
        AlertDialog.Builder(this)
            .setTitle("Ultimas sesiones")
            .setItems(lines.toTypedArray(), null)
            .setPositiveButton("Cerrar", null)
            .show()
    }

    private fun openStorage() {
        try {
            startActivity(Intent(StorageManager.ACTION_MANAGE_STORAGE))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }
}
