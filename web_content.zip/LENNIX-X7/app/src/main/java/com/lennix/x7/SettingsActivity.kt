package com.lennix.x7

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.lennix.x7.settings.AppSettings
import com.lennix.x7.ui.Haptics

/** Ajustes con interruptores que hacen algo real. */
class SettingsActivity : Activity() {

    private val muted = 0xFFA8A8B0.toInt()
    private val red = 0xFFF02D37.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(color)
        t.textSize = sp
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun addRow(parent: LinearLayout, title: String, sub: String): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(56)
        row.setPadding(0, dp(12), 0, dp(12))
        val textCol = LinearLayout(this)
        textCol.orientation = LinearLayout.VERTICAL
        textCol.addView(label(title, 16f, Color.WHITE, true))
        textCol.addView(label(sub, 12f, muted))
        row.addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        parent.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        val line = View(this)
        line.setBackgroundColor(0xFF2A2A30.toInt())
        parent.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        return row
    }

    private fun addSwitch(
        parent: LinearLayout, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit
    ) {
        val row = addRow(parent, title, sub)
        val s = Switch(this)
        s.isChecked = checked
        s.setOnCheckedChangeListener { v, on ->
            onChange(on)
            Haptics.tap(this, v)
        }
        row.addView(s)
        row.setOnClickListener { s.toggle() }
    }

    private fun addNav(parent: LinearLayout, title: String, sub: String, onClick: () -> Unit) {
        val row = addRow(parent, title, sub)
        row.addView(label("\u203A", 22f, muted))
        row.setOnClickListener {
            Haptics.tap(this, it)
            onClick()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 14)
        window.navigationBarColor = Color.rgb(12, 12, 14)
        window.decorView.setBackgroundColor(Color.rgb(12, 12, 14))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(20))

        col.addView(label("Ajustes", 28f, red, true))
        col.addView(label("Solo cambia lo que la app puede hacer sin root.", 13f, muted))
        col.addView(View(this), LinearLayout.LayoutParams(1, dp(16)))

        addSwitch(col, "Respuesta táctil", "Vibración corta al pulsar botones", AppSettings.haptic(this)) {
            AppSettings.setHaptic(this, it)
        }
        addSwitch(col, "Saltar animación de inicio", "Abre la app directamente en el inicio",
            AppSettings.skipSplash(this)) {
            AppSettings.setSkipSplash(this, it)
        }
        addSwitch(col, "Abrir el panel al detectar un juego", "Muestra la pestaña lateral sobre el juego",
            AppSettings.autoOpen(this)) {
            AppSettings.setAutoOpen(this, it)
        }
        addSwitch(col, "Aplicar el perfil al detectar un juego", "Brillo o No molestar según el perfil activo",
            AppSettings.autoProfile(this)) {
            AppSettings.setAutoProfile(this, it)
        }
        addNav(col, "Administración de juegos", "Elige qué apps cuentan como juegos") {
            startActivity(Intent(this, AdminActivity::class.java))
        }
        addNav(col, "Herramientas y permisos", "Limpieza, perfiles, historial y permisos") {
            startActivity(Intent(this, MainActivity::class.java))
        }

        if (Build.VERSION.SDK_INT >= 35) {
            col.setOnApplyWindowInsetsListener { view, insets ->
                val safe = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(dp(20) + safe.left, dp(24) + safe.top,
                    dp(20) + safe.right, dp(20) + safe.bottom)
                insets
            }
        }

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
