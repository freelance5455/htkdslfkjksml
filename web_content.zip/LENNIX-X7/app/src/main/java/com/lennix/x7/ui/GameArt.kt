package com.lennix.x7.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

private val ART_RED = 0xFFF02D37.toInt()

/** Emblema circular con un mando, dibujado en codigo (sin imagenes). */
class LogoView(ctx: Context) : View(ctx) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = ART_RED
    }
    private val pad = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = ART_RED
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ART_RED
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val sw = s * 0.07f
        ring.strokeWidth = sw
        pad.strokeWidth = sw * 0.8f
        ring.setShadowLayer(s * 0.08f, 0f, 0f, ART_RED)
        val r = s / 2f - sw * 1.6f

        canvas.drawCircle(cx, cy, r, ring)

        val body = RectF(cx - r * 0.62f, cy - r * 0.22f, cx + r * 0.62f, cy + r * 0.38f)
        canvas.drawRoundRect(body, r * 0.25f, r * 0.25f, pad)

        val dx = cx - r * 0.32f
        val dy = cy + r * 0.08f
        val l = r * 0.14f
        canvas.drawLine(dx - l, dy, dx + l, dy, pad)
        canvas.drawLine(dx, dy - l, dx, dy + l, pad)

        canvas.drawCircle(cx + r * 0.28f, cy + r * 0.02f, r * 0.05f, fill)
        canvas.drawCircle(cx + r * 0.40f, cy + r * 0.14f, r * 0.05f, fill)
    }
}

/** Rombos concentricos de fondo para la pantalla de inicio. */
class DiamondView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = ART_RED
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width * 0.62f
        val cy = height * 0.50f
        val base = minOf(width, height) * 0.30f
        for (i in 0..2) {
            val d = base - i * base * 0.28f
            val path = Path()
            path.moveTo(cx, cy - d)
            path.lineTo(cx + d, cy)
            path.lineTo(cx, cy + d)
            path.lineTo(cx - d, cy)
            path.close()
            p.strokeWidth = base * (0.06f - i * 0.012f)
            p.alpha = 90 - i * 20
            canvas.drawPath(path, p)
        }
    }
}
