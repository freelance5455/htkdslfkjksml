package com.lennix.x7

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.lennix.x7.games.GameRepository
import com.lennix.x7.ui.Haptics

/** Lista real de las apps con icono de inicio; marca cuales son juegos. */
class AdminActivity : Activity() {

    private val muted = 0xFFA8A8B0.toInt()
    private val red = 0xFFF02D37.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(color)
        t.textSize = sp
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 14)
        window.navigationBarColor = Color.rgb(12, 12, 14)
        window.decorView.setBackgroundColor(Color.rgb(12, 12, 14))

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val chosen = GameRepository.manual(this).toMutableSet()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(20))

        col.addView(label("Administración", 28f, red, true))
        col.addView(label("Marca tus juegos: el panel y Comenzar los usan.", 13f, muted))
        val counter = label("", 13f, Color.WHITE, true)
        counter.setPadding(0, dp(12), 0, dp(8))
        col.addView(counter)

        fun refreshCounter() {
            val added = apps.count { it.first in chosen }
            counter.text = "$added agregados · ${apps.size - added} sin agregar"
        }
        refreshCounter()

        for ((pkg, name) in apps) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = dp(52)
            row.setPadding(0, dp(8), 0, dp(8))
            val title = label(name, 16f, Color.WHITE)
            row.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val s = Switch(this)
            s.isChecked = pkg in chosen
            s.setOnCheckedChangeListener { v, on ->
                if (on) chosen.add(pkg) else chosen.remove(pkg)
                GameRepository.setManual(this, chosen)
                refreshCounter()
                Haptics.tap(this, v)
            }
            row.addView(s)
            row.setOnClickListener { s.toggle() }
            col.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            val line = View(this)
            line.setBackgroundColor(0xFF2A2A30.toInt())
            col.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        }

        if (Build.VERSION.SDK_INT >= 35) {
            col.setOnApplyWindowInsetsListener { view, insets ->
                val safe = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(dp(20) + safe.left, dp(24) + safe.top,
                    dp(20) + safe.right, dp(20) + safe.bottom)
                insets
            }
        }

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
