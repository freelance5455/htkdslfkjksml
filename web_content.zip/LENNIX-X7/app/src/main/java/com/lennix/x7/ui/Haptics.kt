package com.lennix.x7.ui

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.View
import com.lennix.x7.settings.AppSettings

/** Vibracion corta al pulsar. No necesita permisos y respeta el interruptor y el ajuste del sistema. */
object Haptics {
    fun tap(ctx: Context, v: View) {
        if (AppSettings.haptic(ctx)) {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }
}
