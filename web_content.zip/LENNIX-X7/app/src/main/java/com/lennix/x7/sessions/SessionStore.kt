package com.lennix.x7.sessions

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class SessionRecord(
    val pkg: String,
    val startMs: Long,
    val endMs: Long,
    val profile: String = ""
)

/** Historial local de sesiones de juego. No sale del telefono. */
object SessionStore {
    private const val PREFS = "lennix_session"
    private const val FILE = "sessions.json"
    private const val MAX = 200
    private const val MIN_MS = 10_000L
    private var lastBeat = 0L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun activePackage(ctx: Context): String? = prefs(ctx).getString("pkg", null)

    /** Cierra una sesion que quedo abierta si el proceso murio de forma inesperada. */
    fun recover(ctx: Context) {
        val p = prefs(ctx)
        val pkg = p.getString("pkg", null) ?: return
        val start = p.getLong("start", 0L)
        val seen = p.getLong("seen", start)
        val profile = p.getString("profile", "") ?: ""
        append(ctx, SessionRecord(pkg, start, maxOf(seen, start), profile))
        p.edit().clear().apply()
    }

    fun begin(ctx: Context, pkg: String, profile: String = "") {
        val p = prefs(ctx)
        val cur = p.getString("pkg", null)
        if (cur == pkg) return
        if (cur != null) end(ctx)
        val now = System.currentTimeMillis()
        p.edit()
            .putString("pkg", pkg)
            .putString("profile", profile)
            .putLong("start", now)
            .putLong("seen", now)
            .apply()
        lastBeat = now
    }

    /** Marca que la sesion sigue viva (como maximo cada 30 s). */
    fun touch(ctx: Context) {
        val now = System.currentTimeMillis()
        if (now - lastBeat < 30_000L) return
        val p = prefs(ctx)
        if (p.getString("pkg", null) == null) return
        p.edit().putLong("seen", now).apply()
        lastBeat = now
    }

    fun end(ctx: Context) {
        val p = prefs(ctx)
        val pkg = p.getString("pkg", null) ?: return
        val start = p.getLong("start", 0L)
        val profile = p.getString("profile", "") ?: ""
        append(ctx, SessionRecord(pkg, start, System.currentTimeMillis(), profile))
        p.edit().clear().apply()
    }

    @Synchronized
    private fun append(ctx: Context, r: SessionRecord) {
        if (r.endMs - r.startMs < MIN_MS) return
        val all = readAll(ctx).toMutableList()
        all.add(r)
        val arr = JSONArray()
        for (s in all.takeLast(MAX)) {
            arr.put(
                JSONObject()
                    .put("p", s.pkg)
                    .put("s", s.startMs)
                    .put("e", s.endMs)
                    .put("f", s.profile)
            )
        }
        writeAtomic(File(ctx.filesDir, FILE), arr.toString())
    }

    /** Escribe en un temporal, fuerza el sync a disco y renombra: un corte no corrompe el historial. */
    private fun writeAtomic(target: File, text: String): Boolean {
        val tmp = File(target.parentFile, target.name + ".tmp")
        return try {
            FileOutputStream(tmp).use { fos ->
                fos.write(text.toByteArray(Charsets.UTF_8))
                fos.flush()
                fos.fd.sync()
            }
            if (tmp.renameTo(target)) {
                true
            } else {
                target.delete()
                tmp.renameTo(target)
            }
        } catch (_: Exception) {
            tmp.delete()
            false
        }
    }

    @Synchronized
    fun readAll(ctx: Context): List<SessionRecord> {
        return try {
            val f = File(ctx.filesDir, FILE)
            if (!f.exists()) {
                emptyList<SessionRecord>()
            } else {
                val arr = JSONArray(f.readText())
                (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    SessionRecord(
                        o.getString("p"), o.getLong("s"), o.getLong("e"), o.optString("f", "")
                    )
                }
            }
        } catch (_: Exception) {
            emptyList<SessionRecord>()
        }
    }

    @Synchronized
    fun clear(ctx: Context) {
        try { File(ctx.filesDir, FILE).delete() } catch (_: Exception) {}
    }
}
