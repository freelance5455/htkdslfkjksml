package com.lennix.x7.edge

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.lennix.x7.controls.SystemControls
import com.lennix.x7.monitor.Monitor
import com.lennix.x7.sessions.SessionStore
import com.lennix.x7.settings.AppSettings
import com.lennix.x7.profile.ProfileEngine
import com.lennix.x7.profile.ProfileStore
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class EdgeService : Service() {

    private lateinit var wm: WindowManager
    private var container: LinearLayout? = null
    private var panelView: ScrollView? = null
    private var lp: LayoutParams? = null
    private var executor: ScheduledExecutorService? = null
    private val main = Handler(Looper.getMainLooper())
    private var expanded = false

    private var batteryView: TextView? = null
    private var ramView: TextView? = null
    private var cpuView: TextView? = null
    private var screenView: TextView? = null
    private var networkView: TextView? = null
    private var pingView: TextView? = null
    private var tempView: TextView? = null
    private var thermalView: TextView? = null
    private var warnView: TextView? = null
    private var gameView: TextView? = null

    private var timerView: TextView? = null
    private var timerButton: Button? = null
    private var timerStart = 0L
    private var timerAcc = 0L
    private var timerRunning = false

    private val C_CARD = 0xFF17171B.toInt()
    private val C_CARD_DEEP = 0xFF0F0F12.toInt()
    private val C_LINE = 0xFF2A2A30.toInt()
    private val C_RED = 0xFFF02D37.toInt()
    private val C_TXT = 0xFFFFFFFF.toInt()
    private val C_MUT = 0xFFA8A8B0.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // Altura del panel: nunca mayor que la pantalla (los juegos suelen ir en horizontal).
    private fun panelHeight(): Int =
        minOf(dp(480), resources.displayMetrics.heightPixels - dp(24)).coerceAtLeast(dp(200))

    private fun maxY(): Int {
        val used = if (expanded) panelHeight() else dp(90)
        return (resources.displayMetrics.heightPixels - used).coerceAtLeast(0)
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build()
    }

    private fun roundedBg(fill: Int, stroke: Int? = null, strokeW: Int = 0, radius: Int = 10) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null && strokeW > 0) setStroke(dp(strokeW), stroke)
        }

    private fun makeHandle() = TextView(this).apply {
        text = "X7"
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        val r = dp(14).toFloat()
        background = GradientDrawable().apply {
            setColor(C_RED)
            cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        }
    }

    private fun labelText(txt: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = txt
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

    private fun fullWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    @SuppressLint("ClickableViewAccessibility")
    private fun build() {
        if (container != null) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Falta el permiso de superposición", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        val handle = makeHandle()
        val panel = ScrollView(this).apply {
            addView(buildContent())
            background = roundedBg(C_CARD, C_RED, 2, 16)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
                }
            }
            visibility = View.GONE
        }
        panelView = panel

        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(handle, LinearLayout.LayoutParams(dp(26), dp(72)))
        root.addView(panel, LinearLayout.LayoutParams(dp(280), panelHeight()))
        container = root

        val type = if (Build.VERSION.SDK_INT >= 26) {
            LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            LayoutParams.TYPE_PHONE
        }
        val p = LayoutParams(
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, type,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.TOP
            val saved = AppSettings.panelY(this@EdgeService)
            val start = if (saved >= 0) saved else (resources.displayMetrics.heightPixels * 0.30f).toInt()
            y = start.coerceAtMost(maxY())
        }
        lp = p

        var downY = 0f
        var startY = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; startY = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (abs(dy) > dp(6)) moved = true
                    if (moved) {
                        p.y = (startY + dy).toInt().coerceIn(0, maxY())
                        try { wm.updateViewLayout(root, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggle() else AppSettings.setPanelY(this@EdgeService, p.y)
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(root, p)
        } catch (_: Exception) {
            container = null
            stopSelf()
        }
    }

    private fun buildContent(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }

        root.addView(labelText("LENNIX X7", 22f, C_RED, bold = true).apply {
            letterSpacing = 0.15f
        })
        root.addView(labelText("UNIVERSAL GAME BOOSTER", 9f, C_MUT).apply {
            letterSpacing = 0.25f
            setPadding(0, dp(2), 0, dp(10))
        })
        gameView = labelText("Sin sesion activa", 11f, C_MUT).apply {
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(gameView)

        batteryView = labelText("--", 16f, C_TXT, bold = true)
        ramView = labelText("--", 16f, C_TXT, bold = true)
        cpuView = labelText("--", 16f, C_TXT, bold = true)
        screenView = labelText("--", 16f, C_TXT, bold = true)
        networkView = labelText("--", 16f, C_TXT, bold = true)
        pingView = labelText("--", 16f, C_TXT, bold = true)
        tempView = labelText("--", 16f, C_TXT, bold = true)
        thermalView = labelText("--", 16f, C_TXT, bold = true)

        fun card(title: String, value: TextView) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = roundedBg(C_CARD_DEEP, C_LINE, 1, 10)
            addView(labelText(title, 9f, C_MUT).apply { letterSpacing = 0.15f })
            addView(value, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4) })
        }

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun row(a: View, b: View) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(a, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginEnd = dp(5) })
            r.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(5) })
            grid.addView(r, fullWidth().apply { bottomMargin = dp(10) })
        }
        row(card("BATERIA", batteryView!!), card("RAM (APROX.)", ramView!!))
        row(card("NUCLEOS CPU", cpuView!!), card("PANTALLA", screenView!!))
        row(card("RED", networkView!!), card("LATENCIA", pingView!!))
        row(card("TEMP. BATERIA", tempView!!), card("ESTADO TERMICO", thermalView!!))
        root.addView(grid)

        warnView = labelText("Dispositivo caliente: considera pausar el juego", 11f, C_RED, bold = true).apply {
            visibility = View.GONE
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(warnView, fullWidth())

        root.addView(Button(this).apply {
            text = "Medir latencia"
            isAllCaps = false
            setTextColor(C_TXT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = roundedBg(0x00000000, C_LINE, 1, 10)
            minHeight = 0
            minimumHeight = 0
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { measurePing() }
        }, fullWidth())

        root.addView(Button(this).apply {
            isAllCaps = false
            setTextColor(C_TXT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            text = "Perfil: ${ProfileStore.get(context).label}"
            background = roundedBg(0x00000000, C_LINE, 1, 10)
            minHeight = 0
            minimumHeight = 0
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener {
                val next = ProfileStore.next(ProfileStore.get(context))
                text = "Perfil: ${next.label}"
                Toast.makeText(context, ProfileEngine.apply(context, next), Toast.LENGTH_LONG).show()
            }
        }, fullWidth().apply { topMargin = dp(8) })

        root.addView(labelText("CRONOMETRO DE SESION", 9f, C_MUT).apply {
            letterSpacing = 0.2f
            gravity = Gravity.START
            setPadding(0, dp(16), 0, dp(6))
        })

        val timerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = roundedBg(C_CARD_DEEP, C_LINE, 1, 10)
        }
        timerView = TextView(this).apply {
            text = "00:00:00"
            setTextColor(C_TXT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.create("monospace", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(8))
        }
        timerCard.addView(timerView, fullWidth())

        timerButton = Button(this).apply {
            text = "Iniciar"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = roundedBg(C_RED)
            minHeight = 0
            minimumHeight = 0
            setPadding(0, dp(11), 0, dp(11))
            setOnClickListener { toggleTimer() }
        }
        timerCard.addView(timerButton, fullWidth().apply { bottomMargin = dp(6) })

        timerCard.addView(Button(this).apply {
            text = "Reiniciar"
            isAllCaps = false
            setTextColor(C_TXT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = roundedBg(0x00000000, C_LINE, 1, 10)
            minHeight = 0
            minimumHeight = 0
            setPadding(0, dp(11), 0, dp(11))
            setOnClickListener { resetTimer() }
        }, fullWidth())

        root.addView(timerCard, fullWidth())

        root.addView(labelText(
            "MODO SEGURO · Solo lectura. Sin cambios de CPU ni GPU.", 9f, C_MUT
        ).apply { setPadding(0, dp(14), 0, dp(8)) })

        root.addView(Button(this).apply {
            text = "Finalizar sesion"
            isAllCaps = false
            setTextColor(C_TXT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = roundedBg(0x00000000, C_LINE, 1, 10)
            minHeight = 0
            minimumHeight = 0
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener {
                SessionStore.end(context)
                SystemControls.restoreAll(context)
                updateGameLabel()
                Toast.makeText(context, "Sesion finalizada", Toast.LENGTH_SHORT).show()
            }
        }, fullWidth().apply { bottomMargin = dp(8) })

        root.addView(Button(this).apply {
            text = "Cerrar panel"
            isAllCaps = false
            setTextColor(C_RED)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            background = roundedBg(0x00000000, C_RED, 1, 10)
            minHeight = 0
            minimumHeight = 0
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { stopSelf() }
        }, fullWidth())

        return root
    }

    private fun toggle() {
        val p = lp ?: return
        val c = container ?: return
        val panel = panelView ?: return
        expanded = !expanded
        if (expanded) {
            (panel.layoutParams as LinearLayout.LayoutParams).height = panelHeight()
            panel.visibility = View.VISIBLE
            p.y = p.y.coerceAtMost(maxY())
            updateTimerDisplay()
            updateGameLabel()
            startMonitor()
            measurePing()
        } else {
            panel.visibility = View.GONE
            stopMonitor()
            // El cronómetro sigue corriendo con el panel cerrado.
        }
        try { wm.updateViewLayout(c, p) } catch (_: Exception) {}
    }

    private fun updateGameLabel() {
        val pkg = SessionStore.activePackage(this)
        val name = if (pkg == null) null else try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg
        }
        gameView?.text = if (name != null) "Juego: $name" else "Sin sesion activa"
    }

    private fun startMonitor() {
        cpuView?.text = Runtime.getRuntime().availableProcessors().toString()
        val dm = resources.displayMetrics
        screenView?.text = "${dm.widthPixels}x${dm.heightPixels}"

        if (executor != null) return
        val ex = Executors.newSingleThreadScheduledExecutor()
        executor = ex
        ex.scheduleWithFixedDelay({
            val (bat, chg) = Monitor.battery(this)
            val ram = Monitor.ramPercent(this)
            val net = Monitor.networkType(this)
            val temp = Monitor.batteryTempC(this)
            val thermal = Monitor.thermalLevel(this)
            main.post {
                batteryView?.text = when {
                    bat < 0 -> "--"
                    chg -> "$bat% (carga)"
                    else -> "$bat%"
                }
                ramView?.text = if (ram < 0) "--" else "$ram%"
                networkView?.text = net
                tempView?.text = if (temp != null) String.format("%.1f C", temp) else "n/d"
                thermalView?.text = Monitor.thermalName(thermal)
                warnView?.visibility =
                    if (thermal != null && thermal >= 3) View.VISIBLE else View.GONE
            }
        }, 0, 5, TimeUnit.SECONDS)
    }

    private fun stopMonitor() {
        executor?.shutdownNow()
        executor = null
    }

    private fun measurePing() {
        pingView?.text = "..."
        Thread {
            val ms = Monitor.pingMs()
            main.post { pingView?.text = ms?.let { "$it ms" } ?: "--" }
        }.start()
    }

    private val timerTick = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            if (expanded) updateTimerDisplay()
            main.postDelayed(this, 1000)
        }
    }

    private fun toggleTimer() {
        if (timerRunning) {
            stopTimerTick()
            timerButton?.text = "Continuar"
        } else {
            timerStart = System.currentTimeMillis()
            timerRunning = true
            main.post(timerTick)
            timerButton?.text = "Pausar"
        }
        updateTimerDisplay()
    }

    private fun stopTimerTick() {
        if (timerRunning) {
            timerAcc += System.currentTimeMillis() - timerStart
            timerRunning = false
        }
        main.removeCallbacks(timerTick)
    }

    private fun resetTimer() {
        stopTimerTick()
        timerAcc = 0
        timerButton?.text = "Iniciar"
        updateTimerDisplay()
    }

    private fun updateTimerDisplay() {
        val running = if (timerRunning) System.currentTimeMillis() - timerStart else 0L
        val total = (timerAcc + running) / 1000L
        timerView?.text = String.format("%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    override fun onDestroy() {
        stopMonitor()
        stopTimerTick()
        container?.let {
            try { if (it.isAttachedToWindow) wm.removeView(it) } catch (_: Exception) {}
        }
        container = null
        panelView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
