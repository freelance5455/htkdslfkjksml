package com.lennix.x7.games

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build

object GameRepository {
    private const val PREFS = "lennix_games"
    private const val KEY = "manual"

    fun manual(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY, emptySet()) ?: emptySet()

    fun setManual(ctx: Context, pkgs: Set<String>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY, HashSet(pkgs)).apply()
    }

    @Suppress("DEPRECATION")
    fun isGame(ctx: Context, pkg: String): Boolean {
        if (pkg in manual(ctx)) return true
        return try {
            val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
            if (Build.VERSION.SDK_INT >= 26) {
                ai.category == ApplicationInfo.CATEGORY_GAME
            } else {
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }
        } catch (_: Exception) {
            false
        }
    }
}
