package com.lennix.x7.watcher

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import com.lennix.x7.edge.EdgeService
import com.lennix.x7.controls.SystemControls
import com.lennix.x7.games.GameRepository
import com.lennix.x7.profile.ProfileEngine
import com.lennix.x7.profile.ProfileStore
import com.lennix.x7.sessions.SessionStore
import com.lennix.x7.settings.AppSettings

class GameWatcherService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            check()
            handler.postDelayed(this, 5000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (!running) {
            running = true
            // Si Android reinicio el proceso, cierra la sesion anterior y restaura
            // cualquier ajuste temporal que hubiera quedado aplicado.
            val hadInterruptedSession = SessionStore.activePackage(this) != null
            SessionStore.recover(this)
            if (hadInterruptedSession) SystemControls.restoreAll(this)
            handler.post(tick)
        }
        return START_STICKY
    }

    // Cierra la sesion registrada y devuelve brillo y No molestar a su valor original.
    private fun endSession() {
        if (SessionStore.activePackage(this) != null) {
            SessionStore.end(this)
            SystemControls.restoreAll(this)
        }
    }

    private fun closeEdge() {
        stopService(Intent(this, EdgeService::class.java))
        endSession()
        current = null
    }

    private fun check() {
        val power = getSystemService(POWER_SERVICE) as PowerManager
        if (!power.isInteractive) { closeEdge(); return }
        if (!hasUsageAccess(this)) { closeEdge(); return }
        SessionStore.touch(this)

        val pkg = foregroundPackage() ?: return
        if (pkg == current) return
        if (pkg.startsWith("com.android.systemui")) return
        current = pkg

        if (pkg != packageName && GameRepository.isGame(this, pkg)) {
            val isNew = SessionStore.activePackage(this) != pkg
            SessionStore.begin(this, pkg, ProfileStore.get(this).label)
            if (isNew && AppSettings.autoProfile(this)) {
                ProfileEngine.apply(this, ProfileStore.get(this))
            }
            if (AppSettings.autoOpen(this)) {
                try { startService(Intent(this, EdgeService::class.java)) } catch (_: Exception) { current = null }
            }
        } else {
            stopService(Intent(this, EdgeService::class.java))
            endSession()
        }
    }

    @Suppress("DEPRECATION")
    private fun lastForeground(from: Long, to: Long): String? {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(from, to)
        val e = UsageEvents.Event()
        val foregroundEvent = if (Build.VERSION.SDK_INT >= 29) {
            UsageEvents.Event.ACTIVITY_RESUMED
        } else {
            UsageEvents.Event.MOVE_TO_FOREGROUND
        }
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == foregroundEvent &&
                !e.packageName.startsWith("com.android.systemui")
            ) {
                last = e.packageName
            }
        }
        return last
    }

    private fun foregroundPackage(): String? {
        val now = System.currentTimeMillis()
        // Consulta corta en cada ciclo: barata.
        lastForeground(now - 2 * 60_000, now)?.let { return it }
        // Sesión larga con estado ya conocido: no cambiar nada.
        if (current != null) return null
        // Estado desconocido (servicio reiniciado o pantalla encendida): buscar hacia atrás.
        return lastForeground(now - 6 * 3_600_000, now)
    }

    @Suppress("DEPRECATION")
    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("watcher", "Detección de juegos", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, "watcher")
        } else {
            builder = Notification.Builder(this)
        }
        val n = builder
            .setContentTitle("LENNIX X7")
            .setContentText("Detectando juegos")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        endSession()
        stopService(Intent(this, EdgeService::class.java))
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Suppress("DEPRECATION")
        fun hasUsageAccess(ctx: Context): Boolean {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
                )
            } else {
                ops.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
                )
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }
}
