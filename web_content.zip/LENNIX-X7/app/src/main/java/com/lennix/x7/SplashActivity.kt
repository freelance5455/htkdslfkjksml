package com.lennix.x7

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.lennix.x7.ui.LogoView

class SplashActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val red = 0xFFF02D37.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun neon(txt: String) = TextView(this).apply {
        text = txt
        setTextColor(red)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 38f)
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.12f
        setShadowLayer(dp(10).toFloat(), 0f, 0f, red)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF050507.toInt())

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.alpha = 0f
        row.addView(neon("LENNIX"))
        val lp = LinearLayout.LayoutParams(dp(72), dp(72))
        lp.setMargins(dp(18), 0, dp(18), 0)
        row.addView(LogoView(this), lp)
        row.addView(neon("X7"))

        root.addView(
            row,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        setContentView(root)
        row.animate().alpha(1f).setDuration(700).start()

        handler.postDelayed({
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }, 1600)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
