package com.lennix.x7.controls

import android.app.NotificationManager
import android.content.Context
import android.provider.Settings

/**
 * Brillo y No molestar con permisos explicitos del usuario.
 * Cada cambio guarda el valor original para poder restaurarlo.
 */
object SystemControls {
    private const val PREFS = "lennix_controls"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun canWriteSettings(ctx: Context): Boolean = Settings.System.canWrite(ctx)

    fun dndGranted(ctx: Context): Boolean = nm(ctx).isNotificationPolicyAccessGranted

    fun setBrightness(ctx: Context, percent: Int): Boolean {
        if (!canWriteSettings(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            val p = prefs(ctx)
            if (!p.contains("orig_brightness")) {
                p.edit()
                    .putInt("orig_brightness",
                        Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                    .putInt("orig_mode",
                        Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL))
                    .apply()
            }
            val value = percent.coerceIn(5, 100) * 255 / 100
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, value)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun restoreBrightness(ctx: Context) {
        val p = prefs(ctx)
        if (!p.contains("orig_brightness") || !canWriteSettings(ctx)) return
        try {
            val cr = ctx.contentResolver
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS,
                p.getInt("orig_brightness", 128))
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                p.getInt("orig_mode", Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL))
            p.edit().remove("orig_brightness").remove("orig_mode").apply()
        } catch (_: Exception) {
        }
    }

    /** Activa No molestar en modo prioridad (respeta tus excepciones). */
    fun enableDnd(ctx: Context): Boolean {
        if (!dndGranted(ctx)) return false
        return try {
            val n = nm(ctx)
            val p = prefs(ctx)
            if (!p.contains("orig_filter")) {
                val cur = n.currentInterruptionFilter
                val orig = if (cur == NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
                    NotificationManager.INTERRUPTION_FILTER_ALL else cur
                p.edit().putInt("orig_filter", orig).apply()
            }
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun restoreDnd(ctx: Context) {
        val p = prefs(ctx)
        if (!p.contains("orig_filter") || !dndGranted(ctx)) return
        try {
            nm(ctx).setInterruptionFilter(
                p.getInt("orig_filter", NotificationManager.INTERRUPTION_FILTER_ALL))
            p.edit().remove("orig_filter").apply()
        } catch (_: Exception) {
        }
    }

    fun restoreAll(ctx: Context) {
        restoreBrightness(ctx)
        restoreDnd(ctx)
    }
}
