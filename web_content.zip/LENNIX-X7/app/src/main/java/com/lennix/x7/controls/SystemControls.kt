package com.lennix.x7.controls

import android.app.NotificationManager
import android.content.Context
import android.provider.Settings

/**
 * Brillo y No molestar con permisos explicitos del usuario.
 * Cada cambio guarda el valor original y el valor aplicado. Al restaurar,
 * si el usuario cambio el ajuste a mano mientras tanto, no se pisa su decision.
 */
object SystemControls {
    private const val PREFS = "lennix_controls"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun canWriteSettings(ctx: Context): Boolean = Settings.System.canWrite(ctx)

    fun dndGranted(ctx: Context): Boolean = nm(ctx).isNotificationPolicyAccessGranted

    fun setBrightness(ctx: Context, percent: Int): Boolean {
        if (!canWriteSettings(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            val p = prefs(ctx)
            if (!p.contains("orig_brightness")) {
                p.edit()
                    .putInt("orig_brightness",
                        Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                    .putInt("orig_mode",
                        Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL))
                    .commit()
            }
            val value = percent.coerceIn(5, 100) * 255 / 100
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, value)
            p.edit().putInt("applied_brightness", value).commit()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun restoreBrightness(ctx: Context) {
        val p = prefs(ctx)
        if (!p.contains("orig_brightness") || !canWriteSettings(ctx)) return
        try {
            val cr = ctx.contentResolver
            val applied = p.getInt("applied_brightness", -1)
            val current = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1)
            // Solo restaura si el brillo sigue como lo dejamos nosotros.
            if (applied == -1 || current == applied) {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS,
                    p.getInt("orig_brightness", 128))
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    p.getInt("orig_mode", Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL))
            }
            p.edit().remove("orig_brightness").remove("orig_mode")
                .remove("applied_brightness").apply()
        } catch (_: Exception) {
        }
    }

    /** Activa No molestar en modo prioridad (respeta tus excepciones). */
    fun enableDnd(ctx: Context): Boolean {
        if (!dndGranted(ctx)) return false
        return try {
            val n = nm(ctx)
            val p = prefs(ctx)
            if (!p.contains("orig_filter")) {
                val cur = n.currentInterruptionFilter
                val orig = if (cur == NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
                    NotificationManager.INTERRUPTION_FILTER_ALL else cur
                p.edit().putInt("orig_filter", orig).commit()
            }
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            p.edit().putInt("applied_filter", NotificationManager.INTERRUPTION_FILTER_PRIORITY).commit()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun restoreDnd(ctx: Context) {
        val p = prefs(ctx)
        if (!p.contains("orig_filter") || !dndGranted(ctx)) return
        try {
            val n = nm(ctx)
            val applied = p.getInt("applied_filter", -1)
            // Solo restaura si No molestar sigue como lo dejamos nosotros.
            if (applied == -1 || n.currentInterruptionFilter == applied) {
                n.setInterruptionFilter(
                    p.getInt("orig_filter", NotificationManager.INTERRUPTION_FILTER_ALL))
            }
            p.edit().remove("orig_filter").remove("applied_filter").apply()
        } catch (_: Exception) {
        }
    }

    fun restoreAll(ctx: Context) {
        restoreBrightness(ctx)
        restoreDnd(ctx)
    }
}
