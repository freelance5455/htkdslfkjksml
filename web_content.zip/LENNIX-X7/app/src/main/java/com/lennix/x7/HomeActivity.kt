package com.lennix.x7

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.lennix.x7.games.GameRepository
import com.lennix.x7.monitor.Monitor
import com.lennix.x7.profile.ProfileEngine
import com.lennix.x7.profile.ProfileStore
import com.lennix.x7.sessions.SessionStore
import com.lennix.x7.ui.DiamondView
import com.lennix.x7.ui.LogoView
import com.lennix.x7.watcher.GameWatcherService

/** Pantalla de inicio estilo launcher de juegos. */
class HomeActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val red = 0xFFF02D37.toInt()
    private val muted = 0xFFA8A8B0.toInt()

    private lateinit var batView: TextView
    private lateinit var ramView: TextView
    private lateinit var tempView: TextView
    private lateinit var pingView: TextView
    private lateinit var iconView: ImageView
    private lateinit var nameView: TextView
    private lateinit var subView: TextView
    private lateinit var profileTab: TextView
    private var currentPkg: String? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun rounded(fill: Int, stroke: Int?, strokeW: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(strokeW), stroke)
        }

    private fun styled(label: String, value: String): CharSequence {
        val sb = SpannableStringBuilder("$label $value")
        sb.setSpan(ForegroundColorSpan(muted), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(red), label.length + 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun stat(label: String): TextView {
        val t = TextView(this)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(dp(14), 0, 0, 0)
        t.text = styled(label, "--")
        return t
    }

    private fun topButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.minimumHeight = dp(40)
        t.setPadding(dp(16), dp(8), dp(16), dp(8))
        t.background = rounded(0xFF17171B.toInt(), 0xFF2A2A30.toInt(), 1, 10)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun tab(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.minimumHeight = dp(44)
        t.setPadding(dp(28), dp(10), dp(28), dp(10))
        t.setOnClickListener { onClick() }
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF0C0C0E.toInt(), 0xFF1A0508.toInt(), 0xFF2A0A0E.toInt())
        )
        root.addView(DiamondView(this), FrameLayout.LayoutParams(match, match))

        // Barra superior
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(20), dp(12), dp(20), dp(12))
        top.addView(LogoView(this), LinearLayout.LayoutParams(dp(30), dp(30)))
        val brand = TextView(this)
        brand.text = "LENNIX X7"
        brand.setTextColor(red)
        brand.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        brand.typeface = Typeface.DEFAULT_BOLD
        brand.letterSpacing = 0.12f
        brand.setPadding(dp(10), 0, dp(6), 0)
        top.addView(brand)
        batView = stat("BAT")
        ramView = stat("RAM")
        tempView = stat("T.BAT")
        pingView = stat("PING")
        top.addView(batView)
        top.addView(ramView)
        top.addView(tempView)
        top.addView(pingView)
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(topButton("Juegos") { openMain("library") })
        val settingsBtn = topButton("Ajustes") { openMain(null) }
        val sp = LinearLayout.LayoutParams(wrap, wrap)
        sp.marginStart = dp(8)
        top.addView(settingsBtn, sp)
        root.addView(top, FrameLayout.LayoutParams(match, wrap, Gravity.TOP))

        // Tarjeta del juego
        iconView = ImageView(this)
        iconView.scaleType = ImageView.ScaleType.FIT_CENTER
        val iconBox = FrameLayout(this)
        iconBox.setPadding(dp(6), dp(6), dp(6), dp(6))
        iconBox.background = rounded(0xFF0F0F12.toInt(), red, 2, 18)
        iconBox.addView(iconView, FrameLayout.LayoutParams(dp(72), dp(72)))

        nameView = TextView(this)
        nameView.setTextColor(Color.WHITE)
        nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        nameView.typeface = Typeface.DEFAULT_BOLD
        subView = TextView(this)
        subView.setTextColor(muted)
        subView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(18), 0, 0, 0)
        texts.addView(nameView)
        texts.addView(subView)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(24), dp(16), dp(24), dp(16))
        card.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xCC2A0A0E.toInt(), 0x00000000)
        )
        card.addView(iconBox, LinearLayout.LayoutParams(wrap, wrap))
        card.addView(texts)
        card.setOnClickListener { openMain("library") }
        root.addView(
            card,
            FrameLayout.LayoutParams(dp(440), wrap, Gravity.CENTER_VERTICAL or Gravity.START)
        )

        // Boton Comenzar
        val start = TextView(this)
        start.text = "Comenzar"
        start.setTextColor(Color.WHITE)
        start.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        start.typeface = Typeface.DEFAULT_BOLD
        start.gravity = Gravity.CENTER
        start.setPadding(dp(56), dp(16), dp(56), dp(16))
        start.background = rounded(red, null, 0, 16)
        start.setOnClickListener { startGame() }
        val startLp = FrameLayout.LayoutParams(wrap, wrap, Gravity.BOTTOM or Gravity.END)
        startLp.setMargins(0, 0, dp(32), dp(56))
        root.addView(start, startLp)

        // Pestanas inferiores
        profileTab = tab("Perfil") { cycleProfile() }
        val divider = View(this)
        divider.setBackgroundColor(0xFF2A2A30.toInt())
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER
        tabs.background = rounded(0xCC17171B.toInt(), 0xFF2A2A30.toInt(), 1, 14)
        tabs.addView(tab("Registros") { openMain("history") })
        tabs.addView(divider, LinearLayout.LayoutParams(dp(1), dp(24)))
        tabs.addView(profileTab)
        val tabsLp = FrameLayout.LayoutParams(wrap, wrap, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        tabsLp.bottomMargin = dp(8)
        root.addView(tabs, tabsLp)

        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val safe = insets.getInsets(
                    WindowInsets.Type.navigationBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(safe.left, 0, safe.right, safe.bottom)
                insets
            }
        }
        setContentView(root)
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getApplicationInfo(pkg, 0)
        true
    } catch (_: Exception) {
        false
    }

    private fun refreshGame() {
        val last = SessionStore.readAll(this).lastOrNull()?.pkg
        val played = last != null && isInstalled(last)
        val pkg: String? =
            if (played) last else GameRepository.manual(this).firstOrNull { isInstalled(it) }
        currentPkg = pkg
        if (pkg == null) {
            iconView.setImageDrawable(null)
            nameView.text = "Sin juegos"
            subView.text = "Elige tus juegos en Ajustes"
            return
        }
        try {
            val pm = packageManager
            iconView.setImageDrawable(pm.getApplicationIcon(pkg))
            nameView.text = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            subView.text = if (played) "Acaba de jugar." else "Listo para jugar"
        } catch (_: Exception) {
            nameView.text = pkg
        }
    }

    private fun updateProfileTab() {
        profileTab.text = "Perfil: ${ProfileStore.get(this).label}"
    }

    private fun cycleProfile() {
        val next = ProfileStore.next(ProfileStore.get(this))
        toast(ProfileEngine.apply(this, next))
        updateProfileTab()
    }

    private fun openMain(extra: String?) {
        val i = Intent(this, MainActivity::class.java)
        if (extra != null) i.putExtra("open", extra)
        startActivity(i)
    }

    private fun startGame() {
        val pkg = currentPkg
        if (pkg == null) {
            openMain(null)
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            toast("No se puede abrir este juego")
            return
        }
        // El juego elegido pasa a tu lista para que el panel aparezca al entrar.
        val manual = GameRepository.manual(this)
        if (pkg !in manual) {
            GameRepository.setManual(this, manual + pkg)
            toast("Agregado a tus juegos para el panel automatico")
        }
        if (GameWatcherService.hasUsageAccess(this) && Settings.canDrawOverlays(this)) {
            val i = Intent(this, GameWatcherService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } else {
            toast("Activa acceso de uso y superposicion en Ajustes para el panel automatico")
        }
        startActivity(launch)
    }

    private fun refreshStats() {
        val bat = Monitor.battery(this).first
        val ram = Monitor.ramPercent(this)
        val temp = Monitor.batteryTempC(this)
        batView.text = styled("BAT", if (bat < 0) "--" else "$bat%")
        ramView.text = styled("RAM", if (ram < 0) "--" else "$ram%")
        tempView.text = styled("T.BAT", if (temp != null) String.format("%.0f C", temp) else "--")
        Thread {
            val ms = Monitor.pingMs()
            runOnUiThread { pingView.text = styled("PING", ms?.toString() ?: "--") }
        }.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshStats()
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshGame()
        updateProfileTab()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
