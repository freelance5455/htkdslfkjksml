package com.lennix.x7.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import java.net.InetSocketAddress
import java.net.Socket

object Monitor {

    fun battery(ctx: Context): Pair<Int, Boolean> {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return pct to charging
    }

    fun ramPercent(ctx: Context): Int {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        if (mi.totalMem <= 0) return -1
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    fun networkType(ctx: Context): String = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = if (n != null) cm.getNetworkCapabilities(n) else null
        when {
            caps == null -> "Sin red"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Movil"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "BT"
            else -> "Otra"
        }
    } catch (_: Exception) {
        "n/d"
    }

    /** Temperatura de la bateria en C (no es la de CPU/GPU). null si no se informa. */
    fun batteryTempC(ctx: Context): Float? {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else t / 10f
    }

    /** Estado termico del sistema (0 normal ... 6 apagado). null en Android 9 o menor. */
    fun thermalLevel(ctx: Context): Int? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.currentThermalStatus
        } catch (_: Exception) {
            null
        }
    }

    fun thermalName(level: Int?): String = when (level) {
        null -> "n/d"
        0 -> "Normal"
        1 -> "Leve"
        2 -> "Moderado"
        3 -> "Alto"
        4 -> "Critico"
        else -> "Extremo"
    }

    fun pingMs(host: String = "1.1.1.1", port: Int = 443): Int? = try {
        val t = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress(host, port), 1500) }
        ((System.nanoTime() - t) / 1_000_000).toInt()
    } catch (_: Exception) {
        null
    }
}
