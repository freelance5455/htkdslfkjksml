package com.lennix.x7.storage

import android.content.Context
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class JunkItem(val file: File, val bytes: Long, val reason: String)

/**
 * Limpieza conservadora.
 *  - scanSafe: basura que se regenera sola o es claramente abandonada.
 *  - scanReview: ocultos de la raiz que NO se reconocen; solo se borran si los marcas tu.
 *  - deleteItems: unico punto que borra; valida rutas, evita enlaces simbolicos y deja registro.
 */
object JunkCleaner {
    private const val DAY = 24L * 60L * 60L * 1000L
    private val THUMB_DIRS = listOf("DCIM/.thumbnails", "Pictures/.thumbnails", ".thumbnails")
    private val SCAN_DIRS = listOf("", "DCIM", "Pictures", "Download")

    // Nunca se borran, aunque aparezcan en una lista.
    private val PROTECTED = setOf(
        ".nomedia", ".android_secure", ".git", ".gitignore", ".ssh",
        ".config", ".local", ".bashrc", ".profile"
    )

    private fun root(): File = Environment.getExternalStorageDirectory()

    private fun size(f: File): Long =
        if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun isUnder(child: File, parent: File): Boolean = try {
        child.canonicalPath.startsWith(parent.canonicalPath + File.separator)
    } catch (_: Exception) {
        false
    }

    private fun isSymlink(f: File): Boolean = try {
        val parent = f.absoluteFile.parentFile
        parent != null && File(parent.canonicalPath, f.name).path != f.canonicalPath
    } catch (_: Exception) {
        true
    }

    /** Basura segura: se muestra siempre antes de borrar. */
    fun scanSafe(ctx: Context): List<JunkItem> {
        val out = ArrayList<JunkItem>()
        val r = root()

        for (rel in THUMB_DIRS) {
            val d = File(r, rel)
            if (d.isDirectory) out.add(JunkItem(d, size(d), "Miniaturas del sistema (se regeneran)"))
        }
        File(r, "DCIM").listFiles { f -> f.isFile && f.name.startsWith(".thumbdata") }
            ?.forEach { out.add(JunkItem(it, it.length(), "Indice de miniaturas (se regenera)")) }

        val now = System.currentTimeMillis()
        for (rel in SCAN_DIRS) {
            val dir = if (rel.isEmpty()) r else File(r, rel)
            val files = dir.listFiles() ?: continue
            for (f in files) {
                if (!f.isFile) continue
                val n = f.name.lowercase()
                val age = now - f.lastModified()
                if (n.startsWith(".") && (n.endsWith(".tmp") || n.endsWith(".temp")) && age > 30 * DAY) {
                    out.add(JunkItem(f, f.length(), "Temporal oculto de mas de 30 dias"))
                } else if (rel == "Download" && (n.endsWith(".crdownload") || n.endsWith(".part")) && age > 7 * DAY) {
                    out.add(JunkItem(f, f.length(), "Descarga incompleta de mas de 7 dias"))
                }
            }
        }

        for (c in listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)) {
            c.listFiles()?.forEach { out.add(JunkItem(it, size(it), "Cache de LENNIX X7")) }
        }
        return out
    }

    /** Ocultos de la raiz sin identificar. Nunca se borran solos. */
    fun scanReview(): List<JunkItem> {
        val entries = root().listFiles()?.toList() ?: emptyList<File>()
        return entries
            .filter {
                it.name.startsWith(".") &&
                    it.name !in PROTECTED &&
                    it.name != ".thumbnails" &&
                    !it.name.startsWith(".trashed")
            }
            .map {
                JunkItem(
                    it, size(it),
                    if (it.isDirectory) "Carpeta oculta sin identificar" else "Archivo oculto sin identificar"
                )
            }
            .sortedByDescending { it.bytes }
    }

    fun scanBytes(ctx: Context): Long = scanSafe(ctx).sumOf { it.bytes }

    fun clean(ctx: Context): Long = deleteItems(ctx, scanSafe(ctx))

    fun deleteItems(ctx: Context, items: List<JunkItem>): Long {
        val r = root()
        val own = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
        val log = File(ctx.filesDir, "clean.log")
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        var freed = 0L

        for (item in items) {
            val f = item.file
            if (f.name in PROTECTED) continue
            val allowed = isUnder(f, r) || own.any { isUnder(f, it) }
            if (!allowed || isSymlink(f)) continue

            val s = size(f)
            val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
            if (ok) {
                freed += s
                try {
                    log.appendText("$stamp  [${item.reason}]  ${f.absolutePath}  ${s / 1024} KB\n")
                } catch (_: Exception) {
                }
            }
        }
        try {
            if (log.length() > 200_000) {
                log.writeText(log.readLines().takeLast(500).joinToString("\n") + "\n")
            }
        } catch (_: Exception) {
        }
        return freed
    }
}
