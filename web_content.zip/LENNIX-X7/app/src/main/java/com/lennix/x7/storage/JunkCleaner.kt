package com.lennix.x7.storage

import android.content.Context
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object JunkCleaner {
    private val DIRS = listOf("DCIM/.thumbnails", "Pictures/.thumbnails", ".thumbnails")

    private fun root() = Environment.getExternalStorageDirectory()

    private fun thumbTargets(): List<File> {
        val r = root()
        val dirs = DIRS.map { File(r, it) }.filter { it.isDirectory }
        val data = File(r, "DCIM")
            .listFiles { f -> f.isFile && f.name.startsWith(".thumbdata") }
            ?.toList() ?: emptyList()
        return dirs + data
    }

    private fun ownTargets(ctx: Context): List<File> =
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
            .flatMap { it.listFiles()?.toList() ?: emptyList() }

    private fun size(f: File): Long =
        if (f.isFile) f.length()
        else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun scanBytes(ctx: Context): Long =
        (thumbTargets() + ownTargets(ctx)).sumOf { size(it) }

    fun clean(ctx: Context): Long {
        val rootPath = root().canonicalFile.toPath()
        val ownPaths = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).map { it.canonicalFile.toPath() }
        val log = File(ctx.filesDir, "clean.log")
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        var freed = 0L

        for (t in thumbTargets() + ownTargets(ctx)) {
            val p = t.canonicalFile.toPath()
            val inShared = p.startsWith(rootPath)
            val inOwn = ownPaths.any { p.startsWith(it) }
            if (!inShared && !inOwn) continue

            val s = size(t)
            val ok = if (t.isDirectory) t.deleteRecursively() else t.delete()
            if (ok) {
                freed += s
                log.appendText("$stamp  ${t.absolutePath}  ${s / 1024} KB\n")
            }
        }
        if (log.length() > 200_000) {
            log.writeText(log.readLines().takeLast(500).joinToString("\n") + "\n")
        }
        return freed
    }
}
