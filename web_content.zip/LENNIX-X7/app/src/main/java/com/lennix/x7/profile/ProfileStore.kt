package com.lennix.x7.profile

import android.content.Context

enum class Profile(val label: String) {
    BALANCED("Equilibrado"),
    BATTERY("Bateria"),
    PERFORMANCE("Rendimiento")
}

object ProfileStore {
    private const val PREFS = "lennix_profile"
    private const val KEY = "active"

    fun get(ctx: Context): Profile {
        val name = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, Profile.BALANCED.name)
        return Profile.values().firstOrNull { it.name == name } ?: Profile.BALANCED
    }

    fun set(ctx: Context, p: Profile) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, p.name).apply()
    }

    fun next(p: Profile): Profile {
        val all = Profile.values()
        return all[(p.ordinal + 1) % all.size]
    }
}
