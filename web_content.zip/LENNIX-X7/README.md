# LENNIX X7

Universal game booster para Android. Panel flotante con estadisticas, deteccion
automatica de juegos y limpieza segura de miniaturas.

## Que hace

- Panel Edge: pestana lateral que se arrastra y se expande. Muestra bateria, RAM,
  nucleos CPU, resolucion, tipo de red y latencia TCP, mas un cronometro de sesion.
- Deteccion automatica: al abrir un juego marcado, aparece la pestana; al salir, se cierra.
- Limpieza de miniaturas y cache propia, con registro en filesDir/clean.log.
- Biblioteca "Mis juegos" con iconos para abrir tus juegos, apertura automatica del panel
  y perfil automatico (ambos opcionales), posicion del panel recordada y boton Finalizar sesion.
- Historial de sesiones local (juego, hora y duracion), consultable y borrable.
- Temperatura de la bateria y estado termico del sistema, con aviso si es alto.
- Perfiles Equilibrado, Bateria y Rendimiento con efecto real y reversible:
  brillo al 30 % o No molestar (prioridad), con permisos explicitos.
  Al terminar la sesion de juego se restauran los valores originales.
- Version web en docs/index.html (solo lectura, sin instalar nada).

## Modo seguro

- Sin root, sin cambios de kernel, CPU ni GPU, sin cierre forzado de apps.
- La limpieza solo toca .thumbnails, .thumbdata* y la cache propia.

## Requisitos

- Android 6.0+ (API 23)
- Permiso de superposicion (panel) y acceso de uso (deteccion de juegos)
- Android 11+ y acceso a todos los archivos para la limpieza de miniaturas

## Compilar

GitHub Actions compila el APK en cada push a main (JDK 17, Gradle 8.9, SDK 35).
El APK sale en Actions > Artifacts > lennix-x7-debug.

## Version web

docs/index.html se publica con GitHub Pages solo si el repositorio es publico
y Pages esta activado (Settings > Pages > Source: GitHub Actions).
