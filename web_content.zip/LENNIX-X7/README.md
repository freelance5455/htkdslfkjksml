# LENNIX X7

Version 1.5.0 (versionCode 14).

Universal game booster para Android. Panel flotante con estadisticas, deteccion
automatica de juegos y limpieza segura de miniaturas.

## Que hace

- Panel Edge: pestana lateral que se arrastra y se expande. Muestra bateria, RAM,
  nucleos CPU, resolucion, tipo de red y latencia TCP, mas un cronometro de sesion.
- Deteccion automatica: al abrir un juego marcado, aparece la pestana; al salir, se cierra. La consulta de uso se realiza cada 5 segundos para reducir actividad en segundo plano.
- Limpieza de miniaturas y cache propia, con registro en filesDir/clean.log.
- Pantalla de inicio estilo launcher (splash, tarjeta del juego, boton Comenzar, Registros y Perfil).
- Biblioteca "Mis juegos" con iconos para abrir tus juegos, apertura automatica del panel
  y perfil automatico (ambos opcionales), posicion del panel recordada y boton Finalizar sesion.
- Historial de sesiones local (juego, hora y duracion), consultable y borrable.
- Temperatura de la bateria y estado termico del sistema, con aviso si es alto.
- Perfiles Equilibrado, Bateria y Rendimiento con efecto real y reversible:
  brillo al 30 % o No molestar (prioridad), con permisos explicitos.
  Al terminar la sesion de juego se restauran los valores originales.
- Version web en docs/index.html (solo lectura, sin instalar nada).

Consulta `AUDITORIA.md` para los hallazgos, cambios de 1.4.0, límites y validaciones pendientes. `design/design-reference.html` conserva el prototipo visual entregado como referencia; no forma parte del APK nativo ni se publica con GitHub Pages.

## Modo seguro

- Sin root, sin cambios de kernel, CPU ni GPU, sin cierre forzado de apps.
- La limpieza solo toca .thumbnails, .thumbdata* y la cache propia.

## Requisitos

- Android 6.0+ (API 23)
- Permiso de superposicion (panel) y acceso de uso (deteccion de juegos)
- Android 11+ y acceso a todos los archivos para la limpieza de miniaturas

## Compilar

GitHub Actions compila el APK en cada push a main (JDK 17, Gradle 8.9, SDK 35). La compilacion local no se incluye en este paquete; el entorno necesita Android SDK 35.
El APK sale en Actions > Artifacts > lennix-x7-debug.

## Version web

docs/index.html se publica con GitHub Pages solo si el repositorio es publico
y Pages esta activado (Settings > Pages > Source: GitHub Actions).

## Cambios 1.4.1

- GameArt.kt: el color base pasa de `const val` a `val` para evitar un posible error de compilacion.
- Comenzar avisa con un mensaje cuando agrega el juego a tu lista automaticamente.
- El prototipo visual (1,3 MB) pasa de `docs/` a `design/`, para que no se publique con la version web.

## Cambios 1.4.3

- La app es horizontal (`sensorLandscape`), como Game Space: Splash e Inicio usan el diseno horizontal de 1.4.1.
- Se descarta la variante vertical de 1.4.2.
- No hay WebView en el proyecto: la pantalla "Pagina web no disponible" solo aparece en APK convertidos desde HTML.

## Cambios 1.4.4

- Historial: se guarda con escritura atomica (archivo temporal, sync y renombrado) para que un corte no lo corrompa.
- Brillo y No molestar: al restaurar, si cambiaste el ajuste a mano durante la sesion, no se pisa tu decision.
- Servicio de deteccion: si Android niega iniciarlo en primer plano, se detiene sin cerrar la app.
- Icono propio de la app (vector) en lugar del icono por defecto.
- GitHub Actions: logs completos y, si el build falla, se sube el artefacto build-reports con los informes.

## Que borra la limpieza (v1.4.4)

Se borra, con confirmacion: miniaturas del sistema (.thumbnails, .thumbdata*), temporales ocultos
(.tmp/.temp de mas de 30 dias en raiz, DCIM, Pictures y Download), descargas incompletas
(.crdownload/.part de mas de 7 dias en Download) y la cache propia.
Solo si lo marcas tu: ocultos de la raiz sin identificar.
Nunca se borra: fotos, videos, documentos, descargas completas, datos de otras apps (WhatsApp, Telegram,
juegos, Android/data, Android/obb), .nomedia, .git, .ssh, .config, enlaces simbolicos ni la papelera (.trashed).
Todo se registra en clean.log. La app tambien lo explica en el boton "Que borra la limpieza".

## Cambios 1.5.0

- Pantalla de Ajustes (engranaje del inicio) con interruptores reales: respuesta tactil, saltar la animacion de inicio, abrir el panel al detectar un juego y aplicar el perfil al detectar un juego.
- Administracion de juegos: lista de las apps instaladas con interruptor y contador (agregados / sin agregar).
- Respuesta tactil: vibracion corta al pulsar los botones (sin permisos extra; respeta el interruptor).
- "Herramientas y permisos" (limpieza, perfiles, historial) sigue disponible desde Ajustes.
- No se incluyen limpieza de RAM, lista de confianza ni bloqueo de gestos: requieren privilegios de sistema.
