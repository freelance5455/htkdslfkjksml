# LENNIX X7

Version 1.4.3 (versionCode 12).

Universal game booster para Android. Panel flotante con estadisticas, deteccion
automatica de juegos y limpieza segura de miniaturas.

## Que hace

- Panel Edge: pestana lateral que se arrastra y se expande. Muestra bateria, RAM,
  nucleos CPU, resolucion, tipo de red y latencia TCP, mas un cronometro de sesion.
- Deteccion automatica: al abrir un juego marcado, aparece la pestana; al salir, se cierra. La consulta de uso se realiza cada 5 segundos para reducir actividad en segundo plano.
- Limpieza de miniaturas y cache propia, con registro en filesDir/clean.log.
- Pantalla de inicio estilo launcher (splash, tarjeta del juego, boton Comenzar, Registros y Perfil).
- Biblioteca "Mis juegos" con iconos para abrir tus juegos, apertura automatica del panel
  y perfil automatico (ambos opcionales), posicion del panel recordada y boton Finalizar sesion.
- Historial de sesiones local (juego, hora y duracion), consultable y borrable.
- Temperatura de la bateria y estado termico del sistema, con aviso si es alto.
- Perfiles Equilibrado, Bateria y Rendimiento con efecto real y reversible:
  brillo al 30 % o No molestar (prioridad), con permisos explicitos.
  Al terminar la sesion de juego se restauran los valores originales.
- Version web en docs/index.html (solo lectura, sin instalar nada).

Consulta `AUDITORIA.md` para los hallazgos, cambios de 1.4.0, límites y validaciones pendientes. `design/design-reference.html` conserva el prototipo visual entregado como referencia; no forma parte del APK nativo ni se publica con GitHub Pages.

## Modo seguro

- Sin root, sin cambios de kernel, CPU ni GPU, sin cierre forzado de apps.
- La limpieza solo toca .thumbnails, .thumbdata* y la cache propia.

## Requisitos

- Android 6.0+ (API 23)
- Permiso de superposicion (panel) y acceso de uso (deteccion de juegos)
- Android 11+ y acceso a todos los archivos para la limpieza de miniaturas

## Compilar

GitHub Actions compila el APK en cada push a main (JDK 17, Gradle 8.9, SDK 35). La compilacion local no se incluye en este paquete; el entorno necesita Android SDK 35.
El APK sale en Actions > Artifacts > lennix-x7-debug.

## Version web

docs/index.html se publica con GitHub Pages solo si el repositorio es publico
y Pages esta activado (Settings > Pages > Source: GitHub Actions).

## Cambios 1.4.1

- GameArt.kt: el color base pasa de `const val` a `val` para evitar un posible error de compilacion.
- Comenzar avisa con un mensaje cuando agrega el juego a tu lista automaticamente.
- El prototipo visual (1,3 MB) pasa de `docs/` a `design/`, para que no se publique con la version web.

## Cambios 1.4.3

- La app es horizontal (`sensorLandscape`), como Game Space: Splash e Inicio usan el diseno horizontal de 1.4.1.
- Se descarta la variante vertical de 1.4.2.
- No hay WebView en el proyecto: la pantalla "Pagina web no disponible" solo aparece en APK convertidos desde HTML.
