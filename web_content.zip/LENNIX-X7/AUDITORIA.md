# Auditoría técnica — LENNIX X7 1.4.0

## Base revisada

Se reconstruyó el proyecto desde `LENNIX-X7-codigo-completo.txt` (25 bloques de archivos). El ZIP entregado no representaba esa misma versión: contenía código 1.2.0, omitía `HomeActivity.kt`, `SplashActivity.kt` y `ui/GameArt.kt`, y su manifiesto seguía iniciando directamente `MainActivity`. Para evitar compilar un paquete incompleto, esta entrega usa como base el código completo más reciente y lo sincroniza con el ZIP.

## Cambios incluidos en 1.4.0

- Incremento de `versionCode` a 9 y `versionName` a 1.4.0.
- Detección automática: intervalo de comprobación aumentado de 2 a 5 segundos para reducir consultas y actividad periódica en segundo plano.
- Android 10 o superior: lectura del evento `ACTIVITY_RESUMED`; Android 6–9 conserva `MOVE_TO_FOREGROUND`.
- Recuperación tras reinicio inesperado del proceso: se cierra la sesión interrumpida y se intenta restaurar brillo/No molestar guardados por LENNIX.
- Cierre de detección: siempre detiene el panel Edge y trata de cerrar la sesión/restaurar ajustes, incluso si el estado interno del paquete actual quedó vacío.
- Descripción del subtipo `specialUse` más explicativa en el manifiesto.
- Protección de las pantallas de Ajustes e Inicio frente a las barras del sistema y recortes en Android 15 (target 35), aplicando insets en tiempo de ejecución.

## Arquitectura y límites comprobados en el código

- Android nativo con Kotlin; `minSdk 23`, `targetSdk 35`, `compileSdk 35`.
- Panel Edge mediante `SYSTEM_ALERT_WINDOW`; la detección usa `UsageStatsManager` y requiere acceso de uso concedido por el usuario.
- El servicio de detección usa un foreground service `specialUse`; Android 14+ requiere el tipo y permiso declarados.
- Perfiles: Equilibrado restaura; Batería modifica brillo; Rendimiento activa No molestar en prioridad. No cambian CPU, GPU, kernel ni límites térmicos.
- La temperatura mostrada como T.BAT procede del sensor de batería; el estado térmico procede de `PowerManager`. No son una lectura de temperatura de CPU/GPU.
- La latencia es una conexión TCP a `1.1.1.1:443`, no el ping del servidor del juego.
- La RAM es una estimación global del sistema; el indicador CPU muestra el número de procesadores disponibles, no el uso porcentual de CPU.
- La limpieza se limita a rutas fijas de miniaturas y caché propia. En la interfaz está restringida a Android 11+ y requiere acceso a todos los archivos.
- No hay limpieza de RAM, cierre forzado de aplicaciones, overclock, undervolt ni promesa de aumento de FPS.

## Riesgos y decisiones de distribución

- `MANAGE_EXTERNAL_STORAGE` es un permiso amplio y sujeto a políticas de Google Play. La función de limpieza depende de él en Android 11+; para publicar en Play Store se debe justificar su necesidad y cumplir la política vigente. Para distribución directa APK también se debe explicar claramente al usuario por qué se solicita.
- `specialUse` es un tipo de foreground service sujeto a revisión y restricciones de Android/Google Play. La descripción del caso de uso debe coincidir con la función real y con la declaración de distribución.
- El panel requiere permiso de superposición y la detección requiere acceso de uso. Sin esos permisos, el resto de la aplicación puede abrirse, pero las funciones dependientes no funcionarán.
- La interfaz de inicio está configurada en orientación horizontal (`sensorLandscape`).
- Android 15 aplica edge-to-edge a las apps con target 35; se añadieron insets a Inicio y Ajustes. Debe comprobarse visualmente en dispositivos con barra de navegación lateral y recortes.

## Validación ejecutada

- Inventario de los 25 archivos descritos en el TXT y reconstrucción del árbol completo.
- Comprobación de presencia de las tres clases que faltaban en el ZIP anterior.
- Revisión estática de manifiesto, Gradle, servicios, almacenamiento, perfiles, historial y monitores.
- Comprobación XML del manifiesto, integridad del ZIP y sincronización ZIP/TXT en esta entrega.

## Validación pendiente

No se generó ni se afirma que exista un APK compilado en este entorno: aquí no están instalados Gradle ni Android SDK (incluido `android.jar`). La compilación real debe ejecutarse en GitHub Actions con JDK 17, Gradle 8.9 y Android SDK 35. El artefacto esperado es `app/build/outputs/apk/debug/app-debug.apk`, publicado como `lennix-x7-debug` en Actions > Artifacts. Después se debe probar en dispositivos API 23–35, especialmente permisos, orientación, detección, retorno de ajustes y limpieza.

## Correcciones 1.4.1

- `ui/GameArt.kt`: `ART_RED` ya no es `const val` (la conversion `.toInt()` de un literal grande puede rechazarse segun la version del compilador).
- `HomeActivity`: al pulsar Comenzar, si el juego no estaba en tu lista se muestra un aviso en vez de agregarlo en silencio.
- `docs/design-reference.html` se movio a `design/` para que GitHub Pages solo publique `docs/index.html`.
- Comprobacion estatica: llaves y parentesis balanceados en los 16 archivos Kotlin; manifiesto XML valido. Compilacion real pendiente en GitHub Actions.
