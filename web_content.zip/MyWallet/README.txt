MY WALLET - Android project
===========================

BUILD THE APK
1. Install Android Studio (https://developer.android.com/studio).
2. Unzip this folder. In Android Studio: File > Open > select the "MyWallet" folder.
3. Wait for "Gradle sync" to finish (needs internet the first time).
   If it offers to upgrade Gradle / Android Gradle Plugin, you can accept or skip.
4. Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup: app-debug.apk is in app/build/outputs/apk/debug/
6. Copy it to your phone and tap it to install (allow "install unknown apps").

CHANGE THE ICON
Right-click app/src/main/res > New > Image Asset, pick your image, Finish.

UPDATE THE APP
The whole app is one file: app/src/main/assets/index.html. Replace it and rebuild.

NOTES
- Data is stored inside the app on the phone (it does not copy from the website version).
- Export to Excel saves a .csv file into your Downloads folder.
- Uninstalling the app erases its data.
