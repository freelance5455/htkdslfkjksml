# NYALAxx — Live Studio

NYALAxx adalah prototipe web studio live berbahasa Indonesia, responsif untuk HP dan laptop.

## Menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser modern. Untuk akses kamera/mikrofon, browser biasanya mensyaratkan HTTPS atau `localhost`; membuka file langsung mungkin membatasi izin.
3. Aktifkan kamera/mikrofon dan buka tab Pro Voice untuk menguji level audio.
4. Masukkan URL RTMP dan stream key milik server kamu pada tab Konfigurasi RTMP.

## Fitur yang berfungsi
- Antarmuka responsif untuk desktop dan mobile.
- Pratinjau kamera lokal melalui `getUserMedia`.
- Pemilihan input mikrofon dan meter level audio.
- Opsi noise suppression, echo cancellation, auto gain, serta target sample rate melalui constraints browser.
- Preferensi disimpan di localStorage.
- Ekspor pengaturan ke JSON.

## Penting tentang RTMP
Browser web biasa tidak mengirim RTMP langsung dari halaman ini. Untuk siaran publik, kamu memerlukan backend/bridge yang menerima media dari browser (misalnya WebRTC/WHIP atau WebSocket dengan implementasi yang sesuai) dan meneruskannya ke RTMP menggunakan media server atau FFmpeg. Endpoint bridge yang diisi pada UI hanya diuji keterjangkauannya; aplikasi ini **belum** mengirim stream atau menyatakan LIVE tanpa integrasi backend nyata.

Jangan mengirim stream key ke pihak yang tidak dipercaya. Untuk produksi, simpan kredensial di backend, gunakan HTTPS, autentikasi, validasi input, dan kebijakan CORS yang tepat.

## Batasan voice
Noise suppression, echo cancellation, auto gain, dan sample rate adalah permintaan konfigurasi kepada browser/perangkat; dukungan aktual bervariasi. Volume slider memengaruhi meter aplikasi, bukan selalu gain hardware. Preset Clean/Warm/Bright/Deep adalah pilihan UI; efek timbre DSP lanjutan belum diimplementasikan.

## Isi proyek
- `index.html` — struktur aplikasi
- `style.css` — desain responsif
- `app.js` — interaksi kamera, audio, preferensi, dan konfigurasi
