LADLA PARTY HTML APP

Open index.html in Chrome to preview the mobile-friendly prototype. Keep the assets folder beside index.html so the logo loads.

This is a front-end demo only. Login, real-time voice, shared online accounts, payments, push notifications and a production backend are not connected. Buttons that require those services show demo notices.
