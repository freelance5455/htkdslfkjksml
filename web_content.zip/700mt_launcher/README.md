# Motorcycle Launcher — Android project scaffold

This is the first native Android source milestone for the agreed landscape launcher.

## Included
- Landscape, fullscreen launcher activity with HOME intent category.
- 80% swipeable content region and fixed 20% bottom dock.
- Horizontal swipe between main dashboard and mileage page.
- Day/night palette that follows local time (day 07:00–18:59; night otherwise).
- Waze and YouTube Music launch buttons (opens installed apps; does not embed their live UI).
- Trip GO / RESUME, PAUSE and STOP/SAVE controls.
- GPS-based trip-distance accumulation after location permission is granted.
- Odometer displayed as unavailable until a verified CFMOTO data integration is supplied; there is no manual odometer override.
- Best-effort Cardo/Packtalk Bluetooth ACL connection detection and launcher start attempt.

## Important integration limits
- No public/verified CFMOTO RIDE API or authorised data feed has been connected. The real odometer field therefore intentionally displays `— — —`; it is not fabricated or manually keyed in.
- Trip distance is GPS-derived in this first milestone. A production build should persist trip sessions robustly and ideally use the motorcycle's wheel/ECU distance signal if an authorised interface is available.
- Waze and YouTube Music are launched as separate Android apps. This project does not embed their live interfaces inside a split-screen surface. Actual multi-app embedding requires device/OS support and potentially Android Auto-compatible app integrations.
- Android 10+ can restrict activity launches from the background. The Cardo receiver attempts to open the launcher when a paired Cardo/Packtalk ACL connection event arrives, but the device manufacturer may require the user to enable its Auto-start/background-launch permission. This is not guaranteed across all Android displays.
- The microphone button invokes the Android system assistant. Direct ChatGPT voice needs an OpenAI API integration, user API credentials, network access, and a native audio session implementation; it is not connected in this scaffold.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then run the `app` configuration on an Android 8.0+ device. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01 and compile SDK 35. Android Studio may prompt to install SDK 35 and download Gradle dependencies.

To use it as the Home launcher, press Home on the device and select **Motorcycle Launcher**. On some vendor builds you may also need to enable its auto-start/background launch permission.
