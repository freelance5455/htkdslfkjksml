package com.example.motorcyclelauncher

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalTime
import kotlin.math.roundToInt

private val Blue = Color(0xFF1598E5)
private val Dark = Color(0xFF080D13)
private val Panel = Color(0xFF172331)
private val Muted = Color(0xFF9AAABD)

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
        if (!hasLocationPermission() || ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.BLUETOOTH_CONNECT))
        }
        setContent { LauncherApp() }
    }
    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun LauncherApp() {
    val context = LocalContext.current
    val isDay = remember { mutableStateOf(LocalTime.now().hour in 7..18) }
    val bg = if (isDay.value) Color(0xFFF1F4F7) else Dark
    val panel = if (isDay.value) Color(0xFFFFFFFF) else Panel
    val fg = if (isDay.value) Color(0xFF111923) else Color.White
    var page by remember { mutableIntStateOf(0) }
    var tripState by remember { mutableStateOf("READY") }
    var tripKm by remember { mutableDoubleStateOf(0.0) }
    var lastLocation by remember { mutableStateOf<Location?>(null) }
    var gpsListener by remember { mutableStateOf<LocationListener?>(null) }
    var locationNote by remember { mutableStateOf("GPS permission required for trip distance") }
    var showStopConfirm by remember { mutableStateOf(false) }
    var tripStartMillis by remember { mutableLongStateOf(0L) }
    var elapsedMillis by remember { mutableLongStateOf(0L) }

    // Refresh the day/night palette when the screen recomposes; the app follows local clock hours.
    LaunchedEffect(Unit) {
        while (true) {
            isDay.value = LocalTime.now().hour in 7..18
            kotlinx.coroutines.delay(60_000)
        }
    }

    fun stopGps() {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = gpsListener ?: return
        try { lm.removeUpdates(listener) } catch (_: SecurityException) { }
        gpsListener = null
    }

    fun startGps() {
        stopGps()
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val permitted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!permitted) { locationNote = "Enable location permission to record GPS trip distance"; return }
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (tripState == "RECORDING") {
                        val prev = lastLocation
                        if (prev != null && location.accuracy <= 35f && prev.accuracy <= 35f) {
                            val delta = prev.distanceTo(location).toDouble() / 1000.0
                            if (delta in 0.003..0.5) tripKm += delta
                        }
                        lastLocation = location
                    }
                }
            }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, listener)
            gpsListener = listener
            locationNote = "GPS trip tracking active while recording"
        } catch (_: SecurityException) {
            locationNote = "Location permission not granted"
        } catch (_: Exception) {
            locationNote = "GPS provider unavailable on this device"
        }
    }

    MaterialTheme(colorScheme = if (isDay.value) lightColorScheme(primary = Blue) else darkColorScheme(primary = Blue)) {
        Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 10.dp, vertical = 8.dp)) {
            // Main 80% content area; swipe left/right to change pages.
            Box(
                Modifier.weight(0.8f).fillMaxWidth()
                    .pointerInput(page) {
                        var drag = 0f
                        detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                            if (drag < -45) page = 1
                            if (drag > 45) page = 0
                            drag = 0f
                        })
                    }
            ) {
                if (page == 0) MainDashboard(panel, fg, context)
                else MileageDashboard(panel, fg, tripKm, tripState, locationNote,
                    onGo = {
                        if (tripState == "READY" || tripState == "STOPPED") { tripKm = 0.0; lastLocation = null; tripStartMillis = System.currentTimeMillis() }
                        tripState = "RECORDING"; startGps()
                    },
                    onPause = { if (tripState == "RECORDING") { tripState = "PAUSED"; stopGps(); locationNote = "Trip paused" } else if (tripState == "PAUSED") showStopConfirm = true },
                    onResume = { tripState = "RECORDING"; startGps() },
                    onStop = { showStopConfirm = true }
                )
            }
            Row(Modifier.fillMaxWidth().weight(0.20f).padding(top = 5.dp).background(panel, RoundedCornerShape(20.dp)).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                DockItem("Home", Icons.Default.Home, fg) { page = 0 }
                DockItem("Waze", Icons.Default.Map, fg) { openPackage(context, "com.waze") }
                DockItem("Music", Icons.Default.MusicNote, fg) { openPackage(context, "com.google.android.apps.youtube.music") }
                DockItem("Phone", Icons.Default.Phone, fg) { context.startActivity(Intent(Intent.ACTION_DIAL)) }
                Surface(shape = CircleShape, color = Blue, modifier = Modifier.size(68.dp)) {
                    IconButton(onClick = { context.startActivity(Intent(Intent.ACTION_ASSIST)) }) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice assistant", tint = Color.White, modifier = Modifier.size(37.dp))
                    }
                }
            }
        }
    }
    if (showStopConfirm) {
        AlertDialog(onDismissRequest = { showStopConfirm = false }, title = { Text("Stop this trip?") }, text = { Text("Save this trip distance and finish recording?") }, confirmButton = { TextButton(onClick = { tripState = "STOPPED"; stopGps(); showStopConfirm = false; val prefs = context.getSharedPreferences("ride_trips", Context.MODE_PRIVATE); val key = "trip_" + System.currentTimeMillis(); prefs.edit().putFloat(key, tripKm.toFloat()).apply(); locationNote = "Trip saved on this device: %.1f km".format(tripKm) }) { Text("Save trip") } }, dismissButton = { TextButton(onClick = { showStopConfirm = false }) { Text("Cancel") } })
    }
}

@Composable
private fun MainDashboard(panel: Color, fg: Color, context: Context) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Card(Modifier.weight(0.70f).fillMaxHeight(), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Navigation", color = fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Swipe left for mileage →", color = Muted, fontSize = 12.sp)
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp).background(if (fg == Color.White) Color(0xFF20384A) else Color(0xFFE1EAF0), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Map, null, tint = Blue, modifier = Modifier.size(48.dp))
                        Text("Waze navigation", color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Launch the installed Waze app", color = Muted, fontSize = 13.sp)
                    }
                }
                Button(onClick = { openPackage(context, "com.waze") }, modifier = Modifier.fillMaxWidth()) { Text("Open Waze") }
            }
        }
        Card(Modifier.weight(0.30f).fillMaxHeight(), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.MusicNote, null, tint = Blue, modifier = Modifier.size(35.dp))
                Text("YouTube Music", color = fg, fontWeight = FontWeight.SemiBold)
                Text("Open your music player", color = Muted, fontSize = 12.sp)
                Button(onClick = { openPackage(context, "com.google.android.apps.youtube.music") }) { Text("Open Music") }
            }
        }
    }
}

@Composable
private fun MileageDashboard(panel: Color, fg: Color, tripKm: Double, state: String, note: String, onGo: () -> Unit, onPause: () -> Unit, onResume: () -> Unit, onStop: () -> Unit) {
    Card(Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Vehicle mileage", color = fg, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Swipe right for dashboard", color = Muted, fontSize = 12.sp)
            }
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                MetricCard("TOTAL ODOMETER", "— — —", "Live CFMOTO data not connected", Modifier.weight(1f), panel, fg)
                MetricCard("TRIP DISTANCE", "%.1f km".format(tripKm), state, Modifier.weight(1f), panel, fg)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = if (state == "PAUSED") onResume else onGo, modifier = Modifier.weight(1f).height(58.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168C4B))) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(if (state == "PAUSED") "RESUME" else if (state == "RECORDING") "RECORDING" else "GO")
                }
                Button(onClick = if (state == "RECORDING") onPause else onStop, modifier = Modifier.weight(1f).height(58.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB52A36))) {
                    Icon(if (state == "RECORDING") Icons.Default.Pause else Icons.Default.Stop, null); Spacer(Modifier.width(6.dp)); Text(if (state == "RECORDING") "PAUSE" else "STOP / SAVE")
                }
            }
            Text(note, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, detail: String, modifier: Modifier, panel: Color, fg: Color) {
    Card(modifier.height(116.dp), colors = CardDefaults.cardColors(containerColor = if (fg == Color.White) Color(0xFF0E1924) else Color(0xFFF4F7F9)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceEvenly) {
            Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun DockItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(27.dp))
            Text(label, color = tint, fontSize = 11.sp)
        }
    }
}

private fun openPackage(context: Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) context.startActivity(intent)
    else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
}

class CardoConnectReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
        val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
        val name = try { device.name.orEmpty() } catch (_: SecurityException) { "" }
        if (name.contains("cardo", ignoreCase = true) || name.contains("packtalk", ignoreCase = true)) {
            val launch = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            try { context.startActivity(launch) } catch (_: Exception) { /* Android background-launch policy may block this; user must enable device autostart or launch manually. */ }
        }
    }
}
