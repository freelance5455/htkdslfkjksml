Duty & OT Calculator — Android Studio project

এই ZIP হলো Android Studio project; সরাসরি APK নয়।

APK বানাতে:
1) কম্পিউটারে Android Studio ইনস্টল করুন।
2) ZIP extract করুন।
3) Android Studio > Open > DutyOTAndroid ফোল্ডারটি নির্বাচন করুন।
4) Gradle sync শেষ হলে Build > Build APK(s) নির্বাচন করুন।
5) APK path: app/build/outputs/apk/debug/app-debug.apk

অ্যাপের HTML ফাইল app/src/main/assets/index.html এ রাখা আছে।
নোট: WebView-তে PDF print ও Excel blob-download এর আচরণ ফোন/Android সংস্করণভেদে পরীক্ষা করে নিতে হবে।
