
import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-5.5";

app.disable("x-powered-by");
app.use(express.json({ limit: "30kb" }));

// Frontend NEXORA AI
app.use(express.static("public", { index: "index.html" }));

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const instructions = `
Kamu adalah NEXORA AI, asisten AI yang ramah, jelas, dan membantu.
Jawab dalam bahasa yang digunakan pengguna.
Kamu ahli membantu coding, HTML, CSS, JavaScript, debugging,
belajar, menulis, dan mengembangkan ide proyek.
Untuk permintaan kode, berikan kode yang relevan dan dapat digunakan.
Jangan mengaku sudah menjalankan atau menguji kode jika belum.
Jika ada batasan teknis, jelaskan dengan jujur.
`;

// Pemeriksaan server
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "NEXORA AI",
    configured: Boolean(openai)
  });
});

// Chat AI
app.post("/api/chat", async (req, res) => {
  try {
    if (!openai) {
      return res.status(503).json({
        error: "API key belum dipasang di environment server."
      });
    }

    const message =
      typeof req.body?.message === "string"
        ? req.body.message.trim()
        : "";

    if (!message) {
      return res.status(400).json({
        error: "Pesan tidak boleh kosong."
      });
    }

    if (message.length > 12000) {
      return res.status(413).json({
        error: "Pesan terlalu panjang. Maksimal 12.000 karakter."
      });
    }

    // Batasi riwayat dan hanya terima pesan teks user/assistant.
    const rawHistory = Array.isArray(req.body?.history)
      ? req.body.history.slice(-12)
      : [];

    const history = rawHistory
      .filter(item =>
        item &&
        ["user", "assistant"].includes(item.role) &&
        typeof item.content === "string"
      )
      .map(item => ({
        role: item.role,
        content: item.content.slice(0, 6000)
      }));

    const response = await openai.responses.create({
      model: MODEL,
      instructions,
      input: [
        ...history,
        { role: "user", content: message }
      ],
      max_output_tokens: 3000
    });

    const reply = response.output_text?.trim();

    if (!reply) {
      return res.status(502).json({
        error: "AI tidak mengembalikan teks. Coba lagi."
      });
    }

    return res.json({ reply });
  } catch (error) {
    console.error("OpenAI error:", error.status || error.name);

    if (error.status === 401) {
      return res.status(502).json({
        error: "API key ditolak. Periksa key di environment server."
      });
    }

    if (error.status === 429) {
      return res.status(429).json({
        error: "Batas penggunaan API tercapai atau kuota tidak tersedia."
      });
    }

    if (error.status === 400) {
      return res.status(502).json({
        error: "Permintaan AI ditolak. Periksa model dan konfigurasi API."
      });
    }

    return res.status(502).json({
      error: "Gagal menghubungi OpenAI. Coba beberapa saat lagi."
    });
  }
});

// Secret command: /donloder
app.post("/api/tiktok", async (req, res) => {
  try {
    const input =
      typeof req.body?.url === "string"
        ? req.body.url.trim()
        : "";

    if (!input || input.length > 2000) {
      return res.status(400).json({
        error: "Masukkan URL TikTok yang valid."
      });
    }

    let parsed;
    try {
      parsed = new URL(input);
    } catch {
      return res.status(400).json({
        error: "Format URL tidak valid."
      });
    }

    const allowedHosts = new Set([
      "tiktok.com",
      "www.tiktok.com",
      "m.tiktok.com",
      "vm.tiktok.com",
      "vt.tiktok.com"
    ]);

    const hostname = parsed.hostname.toLowerCase();

    if (
      parsed.protocol !== "https:" ||
      !allowedHosts.has(hostname)
    ) {
      return res.status(400).json({
        error: "Gunakan URL HTTPS dari domain TikTok yang didukung."
      });
    }

    const endpoint =
      "https://www.tikwm.com/api/?url=" +
      encodeURIComponent(parsed.href);

    const upstream = await fetch(endpoint, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(15000)
    });

    if (!upstream.ok) {
      return res.status(502).json({
        error: "Layanan metadata TikTok sedang tidak tersedia."
      });
    }

    const result = await upstream.json();

    if (result.code !== 0 || !result.data) {
      return res.status(502).json({
        error: result.msg || "Metadata video tidak berhasil diambil."
      });
    }

    const d = result.data;
    const author = d.author || {};

    // Kirim hanya field yang diperlukan frontend.
    return res.json({
      data: {
        title: d.title || d.desc || "",
        duration: d.duration ?? null,
        cover: d.cover || d.origin_cover || "",
        author: {
          nickname: author.nickname || "",
          unique_id: author.unique_id || author.uniqueId || ""
        },
        stats: {
          play_count: d.play_count ?? null,
          digg_count: d.digg_count ?? null,
          comment_count: d.comment_count ?? null,
          share_count: d.share_count ?? null
        },
        video_url: d.play || ""
      }
    });
  } catch (error) {
    console.error("TikTok metadata error:", error.name);

    return res.status(502).json({
      error: error.name === "TimeoutError"
        ? "Layanan metadata terlalu lama merespons."
        : "Tidak bisa mengambil metadata. Coba lagi nanti."
    });
  }
});

// Error untuk JSON yang rusak atau terlalu besar.
app.use((err, _req, res, _next) => {
  if (err.type === "entity.too.large") {
    return res.status(413).json({ error: "Request terlalu besar." });
  }

  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({ error: "Format JSON tidak valid." });
  }

  console.error("Server error:", err.message);
  return res.status(500).json({ error: "Terjadi kesalahan server." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`NEXORA AI berjalan di port ${PORT}`);
  console.log(`Model: ${MODEL}`);
  console.log(`API key tersedia: ${Boolean(openai)}`);
});
