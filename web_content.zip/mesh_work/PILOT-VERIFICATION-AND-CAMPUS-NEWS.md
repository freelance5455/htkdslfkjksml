# MESH pilot access, verification, and Campus News upgrade

## Added to this ZIP
- Invite-code field on registration; code is checked before Firebase account creation and consumed in a Firestore transaction.
- Newly registered pilot accounts begin with `verificationStatus: pending` and are routed to a verification gate.
- Private verification request form with student identifier, proof type, optional image/PDF upload (max 5 MB), and notes.
- Admin workspace pages for one-time invite-code generation/disable and a Super Admin-only verification review queue.
- A dedicated Campus News screen with category filters, bulletin images, source/date labels, and official announcement styling.
- Campus News content editor fields for HTTPS bulletin image URL, source/issuing office, category, and official label metadata.
- A moderation reports page for reviewing student-submitted post reports.
- Firestore and Storage rules for invite codes, verification requests, and proof files.

## Required Firebase setup before testing
1. Back up current Firestore and Storage rules.
2. Confirm Firebase Authentication Email/Password is enabled.
3. Publish the included `firestore.rules` and `storage.rules` to project `mesh-9a4f1` only after reviewing them against the live project and testing in a staging project or Emulator Suite.
4. Verify the Firebase Storage bucket is actually initialized and supported by the project's current plan. Firebase Storage availability on Spark must not be assumed. If proof upload fails, the private review workflow needs a storage option confirmed to work without unexpected billing before inviting real students; do not loosen proof-file rules.
5. Ensure an active `admins/{uid}` record with `role: super_admin` exists for the account that will manage invites and review students.
6. In Admin → Pilot invite codes, generate codes and share them privately. Codes are single-use.
7. Test the entire flow with a separate test student: invalid code, valid code, duplicate code, submit proof, student cannot browse/post while pending, admin approval, student access after approval, rejection and resubmission, and access denied to a non-admin account.

## Privacy and operational notes
- Verification requests include a student ID/matric number and may include proof documents. Restrict reviewer access, do not share files, and define a retention/deletion schedule before inviting real students.
- Proof uploads are placed at `verificationProofs/{uid}/...`. Super Admins and the owning user can access them under Storage rules; this is still an operationally sensitive document store.
- The current browser-based client cannot provide the same abuse resistance as a trusted server. For a production public launch, move invite-code consumption and review/audit operations into trusted backend code (for example, Firebase Cloud Functions or another server), and add rate limits and an audit trail.
- Campus News currently accepts a hosted HTTPS image URL; this is intentional while free-tier Storage availability is confirmed. Use only images the university/MESH is authorized to publish, cite source and date, and verify the source before applying `official: true`.
- Do not use real student documents in test accounts. Delete test proof after the test.

## Testing status
Static JavaScript syntax checks and archive integrity checks are performed during packaging. No live Firebase deployment, Android-device test, or end-to-end security test is claimed by this ZIP.

## Campus News image hosting
The admin editor currently accepts an HTTPS image URL rather than uploading bulletin images directly. This avoids exposing an image-hosting secret in browser code and avoids assuming Firebase Storage is available on Spark. A secure signed-upload backend or an image host with a safe upload-authentication flow is still needed for direct uploads.
