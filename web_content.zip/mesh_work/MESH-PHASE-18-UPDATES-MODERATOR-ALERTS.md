# MESH Phase 18 — Updates, Moderator Assignment & Unique Alerts

## Changes
- Student Updates and Home announcement queries explicitly constrain `active == true` and `status == published`, allowing Firestore Rules to prove the result set is visible to members. Composite indexes are included for the audience queries.
- Admin Content now displays a **Fix visibility** action for older active announcements with incomplete publication metadata.
- Moderator assignment now accepts the registered student's email, a university dropdown, and an audience choice: entire university, faculty, department, or level/class. Target choices are loaded from the academic catalog. The callable resolves the email through Firebase Authentication and validates the MESH profile server-side.
- Announcement alerts use a distinct summary (“New official announcement”) and route students to the matching announcement in Updates, rather than repeating the announcement body in Alerts. Shared university/global alert reads are scoped in Firestore Rules.
- Existing bottom navigation remains Home, Updates, Alerts, Profile.

## Verification
- JavaScript syntax checks and the static regression suite passed.
- Firestore index JSON parses successfully.
- Firebase Emulator and live-project tests have not run in this environment; deploy updated Functions, Rules, and indexes only after staging verification.
