# MESH admin code tracking and CSV export fix

## Changes
- Pilot-code table now includes redeemer name, redeemer email, and redemption date for used codes; unused codes display `Not yet used`.
- New app and admin code redemptions record `usedByEmail` and `usedByName` alongside the redeemer UID and timestamp.
- Historical rows attempt to resolve missing name/email from the Firestore `users` or `admins` document. Historical email/date cannot be reconstructed if the relevant records never stored them.
- CSV tools now attach to every data table on each admin page, rather than only the first table.
- CSV download filename includes the page and table identity; export includes all currently loaded table rows, not just rows visible on the current pagination page.
- CSV values are quoted and formula-like cells are escaped to reduce spreadsheet formula injection risk.

## Deployment notes
- Publish the included `firestore.rules` before testing new code redemptions, because `inviteCodes` update rules now permit the authenticated redeemer's email/name fields and validate the email against the Firebase Auth token.
- No Firebase deployment was performed. No live Firebase account or Android browser test was available in this code-level check.
- CSV export includes rows currently loaded into the page. If a page intentionally fetches only a limited number of Firestore documents, the export cannot include records the page never loaded.
