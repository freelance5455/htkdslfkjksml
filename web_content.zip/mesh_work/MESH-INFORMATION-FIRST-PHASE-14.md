# MESH Information-First — Phase 14

## Scope
This pass strengthens the existing announcement discussion flow without changing the bottom navigation.

## Changes
- Announcement discussion loading now re-reads the parent announcement and hides the form if `commentsEnabled` is not true. Firestore rules remain the authoritative enforcement.
- Replies authored by the announcement's assigned/publishing moderator are shown with a `Moderator` label, derived from the announcement's trusted `publisherRole` and `publisherUid` fields rather than a client-supplied role.
- Comment names continue to prefer the member's MESH username.
- Added Phase 14 static integration checks and wired them into `npm run test:static`.
- Existing Home, Updates, Alerts and Profile navigation labels remain unchanged. Faculty, department and class announcement views remain within Home/Updates.

## Validation
Run `npm run test:static` for source-level checks. These checks do not prove live Firebase behavior. Firebase Emulator tests, staging tests for admin publishing/notifications, and Android/PWA smoke tests must still be run before production release. No deployment was performed.
