# MESH Admin — Coordinated Upgrade

## Included
- Existing dashboard, content publishing, academic catalog, users, community posts, support, theme manager, CSV table tools and diagnostics preserved.
- Super Admin-only System Health panel, Audit Timeline and Feature Switchboard in the UI. Restricted routes are also guarded in the navigation handler.
- Quick action palette: click **Search actions** or press **Ctrl+K** (on Android keyboards, use the button). Press Escape to close.
- Audit timeline reads the latest 100 documents from `adminAuditLogs`; it is intentionally append-only under Firestore rules. Coverage is limited to events that the admin UI actually records.
- Feature switches save to `appSettings/featureFlags`. They are admin-side rollout metadata until the relevant student-app modules are explicitly wired to read them; they do not magically turn features on in the student app.

## Deployment
1. Back up the currently hosted MESH project and Firestore rules.
2. Extract this ZIP and deploy the contents of the `MESH/` directory to the same static host/root path as the existing app. Keep the `admin/`, `js/`, `css/`, and `assets/` relative paths unchanged.
3. In Firebase Console → Firestore Database → Rules, review and publish `firestore.rules`. This enables Super Admin read/write for `appSettings/featureFlags`; the existing `adminAuditLogs` rule remains Super Admin-only and append-only. Do not deploy rules without comparing them against any project-specific custom rules.
4. Confirm the Super Admin document is `admins/{Firebase Auth UID}`, with `active: true` and `role: "super_admin"`. Do not create admin records with client-side code; use the trusted Firebase Console or your existing secure admin-provisioning process.
5. Sign in as Super Admin, open System Health, then test Audit Timeline and Feature Switchboard. Save a test switch and verify `appSettings/featureFlags` in Firestore.
6. Sign in as a regular university admin in a separate session. Confirm System Health, Audit Timeline, Feature Switchboard, Academic Data, Admins, Requests and Settings are not exposed in the sidebar and restricted navigation is blocked. Verify assigned-university content and community moderation still work.
7. Test CSV export on a table with rows, on desktop and mobile browser if available.

## Test results from this build
- **Passed:** `node --check` for every JavaScript file in the project.
- **Passed:** all 15 local script references in `admin/index.html` resolve to existing files.
- **Passed:** ZIP archive integrity (`unzip -t`, no compressed-data errors).
- **Passed (static review):** System Health panel is hidden for non-Super Admin profiles; restricted routes are guarded in the navigation handler; audit and feature-switchboard pages are only exposed in the Super Admin sidebar/command palette.
- **Not performed here:** live Firebase sign-in, deployed Firestore Rules Simulator tests, browser/device interaction tests, student-app feature-flag consumption, or production deployment. These require the project owner’s Firebase/hosting environment.

## Safety notes
- Hiding controls is not a substitute for Firestore Security Rules. Rules must be published for server-side authorization.
- `adminAuditLogs` records are not a complete Firebase audit log and cannot be edited/deleted through client rules.
- Do not expose service-account keys or admin credentials in this static project.

## Follow-up: analytics, CSV and global theme
See `ADMIN-ANALYTICS-CSV-THEME-FIX.md` for details on the timestamp-based activity chart, CSV export behavior, global member-app theme coverage, deployment checklist, and test limitations.
