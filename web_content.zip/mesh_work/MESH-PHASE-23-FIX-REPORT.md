# MESH Phase 23 — Fix report

## Included
- Aligned username validation across signup/profile saving and Firestore username-claim rules so usernames with dots are handled consistently. Avoided attempting to update an already-existing username claim owned by the same account.
- Improved visual contrast and interaction states for university/faculty/department audience cards and announcement discussion surfaces.
- Updated discussion rendering so moderator-authored replies display **Moderator** rather than a personal username, while student questions continue to display the selected username.
- Updated the announcement comments rule to accept a moderator-role field only when the signed-in account is an authorized admin role.

## Important deployment note
The included `firestore.rules` must be deployed to Firebase for the permission fix and moderator reply permissions to take effect. Test with a new username and an existing account. Firestore rules cannot be deployed from this ZIP alone.

## Validation
JavaScript syntax checks and ZIP integrity checks should be run before release; this is a code update, not a live Firebase deployment.
