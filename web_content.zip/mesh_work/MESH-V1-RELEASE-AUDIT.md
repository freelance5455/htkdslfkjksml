# MESH V1 Release Audit — 11 October 2026

## Result: NOT YET CLEARED FOR PUBLIC LAUNCH

This audit is a static source/rules review of the latest MESH V1 Home/Profile redesign package. It is not a live Firebase test or an Android-device test. Findings below should be addressed and verified before inviting the public.

## Checks that passed

- 34 JavaScript files passed `node --check`.
- Member entry point: 21 local script/style references checked; no missing local references.
- Admin entry point: 18 local script/style references checked; no missing local references.
- No duplicate HTML IDs found in `index.html` or `admin/index.html`.
- ZIP archive integrity was checked after packaging.
- Fixed one confirmed dead control: the Home header notification button used `data-action="notifications"`, but the navigation action handler did not implement that action. It now uses `data-nav="notifications"` so it follows the normal screen navigation path.

## Launch blockers / high-priority findings

### P1 — Storage rules allow an active admin to write to another university's resource path

In `storage.rules`, writes under `resources/{universityId}/{fileName}` require only that the requester is an active admin. The rule does not verify that the admin is authorized for the `universityId` in the storage path. A university admin could potentially overwrite files under another university's resource folder.

**Required fix:** enforce `canManageUniversity(universityId)` based on the active admin's assigned university, with Super Admin handling explicitly, and validate file type/size on both create and overwrite. Test with two university admins and a Super Admin in Firebase Emulator or a safe test project.

### P1 — Support tickets are not scoped to a university in Firestore rules

`supportTickets` permits any active `university_admin` or `admin` to read, update, or delete the collection without checking the ticket's university or assigned scope. The app creates tickets with a user UID and message, but the rules do not require a university boundary for admin access.

**Required fix:** add and validate a `universityId` / assignment model for tickets, and restrict university admins to their own university. If the support workflow is intentionally central-only, restrict ticket access to Super Admin or a specifically authorized support role. Test cross-university denial.

### P1 — User-owned profile updates are unrestricted by field

The `/users/{uid}` rule lets a user update their own document without restricting changed fields. This permits a client to alter any field in its profile document, including system-managed fields such as university/onboarding metadata. It does not directly grant an admin role because admin privileges are read from `/admins/{uid}`, but it weakens profile/data integrity.

**Required fix:** use `diff().affectedKeys().hasOnly([...])` for student-editable fields and validate field types/lengths. Keep system-managed onboarding/university fields in a separately validated update path. Test that a student cannot modify protected fields.

### P2 — Community engagement counters can be changed directly by any signed-in user

The `/communityPosts/{postId}` update rule permits any signed-in user to set `likeCount` or `commentCount` to any non-negative integer as long as only that counter field changes. This allows manipulation of engagement numbers.

**Required fix:** move counters to trusted backend/Cloud Functions or derive them from likes/comments; alternatively validate updates using a trusted transaction pattern. Do not rely on client-provided counts for analytics.

### P2 / conditional — Notification collection reads are broad

All signed-in users can read every document in `/notifications`. If this collection is only public university announcements, that may be intentional; if it contains per-user delivery, targeting, or private metadata, this rule exposes it across accounts/universities.

**Required fix:** decide whether this collection is public broadcast content or per-user delivery records. Separate the two models if necessary and test the intended access boundaries.

## Functional limitations observed in source

- Saved items and notification read status use browser-local storage, so they do not synchronize across devices and may disappear when browser data is cleared.
- The member community tab says “Your communities” but the current member interaction layer shows a placeholder until a verified membership model is implemented. Community creation is intentionally not implemented as a working member action.
- Notification rendering loads the shared `notifications` collection and filters university relevance in the client. Client filtering is not a security boundary; Firestore rules and query design must enforce the intended audience.
- Some features can only be marked passed after live verification: real authentication and recovery, Firestore reads/writes, Storage uploads, admin-to-member publishing, theme propagation, CSV export on Android, and role/university isolation.

## Required live smoke tests before public launch

1. Student signup/sign-in/sign-out/account recovery and onboarding.
2. Super Admin, university admin, and student permission boundaries.
3. Cross-university denial for support tickets, files, user records, and admin operations.
4. Publish an announcement/event/opportunity in admin and verify the intended students receive it.
5. Like/comment/report flows, with counter integrity and moderation.
6. Profile image upload and account/profile edits.
7. Home, Discover, Community, Alerts, Me, settings, and every visible action on a real Android device.
8. Global theme changes across all member screens.
9. CSV export in the actual Android browser and spreadsheet app.
10. Backup and rollback rehearsal; confirm Firebase quotas and production configuration.

## Deployment caution

Do not blindly publish the current `firestore.rules` or `storage.rules` to production. Review and test proposed security-rule changes using Firebase Emulator or a separate test project first. This audit package intentionally records the findings instead of silently replacing security rules without validating the app's exact data model.

## Audit status

Static checks: **PASS** for the checks listed above.  
Security review: **BLOCKED** pending the P1 findings.  
Live Firebase / Android behavior: **NOT VERIFIED**.
