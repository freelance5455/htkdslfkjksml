# MESH Information-First Redesign — Phase 1

## Included in this package
- Replaced the Home social-post composer/feed with an information-first campus dashboard.
- Added clear entry points for university notices, academic updates, department/class notices, and Alerts.
- Updated document metadata and added a web app manifest.
- Added a service worker with a small static-shell cache and network-first navigation fallback. Firebase/auth/API requests are not cached by the service worker.
- Added service-worker registration and a small install-prompt API in `js/pwa.js`.
- Stopped loading `js/social-feed.js` from the member page. The source file and Firestore post data/rules remain in the archive for compatibility; this phase does not delete legacy data.

## Deliberately not claimed as complete
- Moderator publishing is not enabled yet. Current Firestore announcement rules still require an active admin. Do not assign departmental publishing rights until the scoped moderator model and rules are implemented and tested.
- Push notifications are not implemented by this phase; PWA installation/offline shell support is separate from push delivery.
- Existing announcements, comments and notification flows still require runtime integration testing against the configured Firebase project.

## Validation
- Check all JavaScript files with `node --check`.
- Parse `manifest.json` as JSON.
- Inspect ZIP contents and ensure `index.html`, `manifest.json`, `service-worker.js`, and `js/pwa.js` are present.
- Before production, serve over HTTPS (or localhost for development), test installability on target Android browsers, and test offline fallback.
