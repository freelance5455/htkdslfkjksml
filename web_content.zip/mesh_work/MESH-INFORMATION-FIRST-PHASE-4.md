# MESH Information-First — Phase 4

## Purpose

Security hardening and pre-deployment validation for the information-first MESH pilot. This phase starts from Phase 3 and preserves the existing HTML/vanilla JavaScript + Firebase architecture.

## Changes

- Tightened `canReadAnnouncement` so a blank/missing university ID is treated as legacy-global only for university-wide records. A targeted faculty/department/class announcement cannot bypass scope checks by using a blank university ID.
- Tightened announcement-comment updates. Authors can edit only the comment body and optional update timestamp, cannot transfer authorship, and cannot exceed the 1,000-character limit. Deletion remains available to the author or Super Admin.
- Tightened notification reads so a signed-in student can read their own UID-targeted notifications. University admins may read legacy untargeted notices for a university they manage; Super Admins retain administrative visibility.
- Added this test checklist for staging/emulator validation before release.

## Required staging tests

1. A student in the assigned department can read a department announcement.
2. A student in another department cannot read that announcement, even if the document has a blank/missing university ID.
3. A student in the same university but another faculty cannot read a faculty-scoped announcement.
4. A class/level announcement is visible only to matching level IDs.
5. A moderator can publish only after an active assignment and only within the assignment's scope.
6. A revoked moderator cannot publish after revocation.
7. A normal student cannot assign/revoke moderators or write directly to `announcements`.
8. A user can create a comment only when `commentsEnabled == true` and they can read the parent announcement.
9. A comment author cannot change `authorUid`, `status`, or arbitrary fields; a valid body edit succeeds.
10. A student cannot read another user's UID-targeted notification.
11. The correct recipients receive in-app notification records after a successful scoped announcement publish.
12. Test legacy university-wide announcements and existing notification documents to check backward compatibility.

## Validation performed in this package

Static checks only: JavaScript syntax checks, JSON validation, HTML parsing, and ZIP integrity. Firebase Rules Emulator tests and live Firebase integration tests have **not** been run here.

## Deployment caution

Do not deploy these rules to production without testing the current schema in the Firebase Emulator Suite. Firestore rules evaluate queries as a whole, so the client query shape must also satisfy the rule constraints. Keep Phase 3 and the original project ZIP as backups. Deploy functions and rules to a staging Firebase project first, then test with separate Super Admin, moderator, and student accounts.
