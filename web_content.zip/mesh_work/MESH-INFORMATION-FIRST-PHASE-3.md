# MESH Information-First Phase 3

## Included
- Super Admin-only moderator assignment/revocation UI in `admin/index.html` and `admin/js/moderators.js`; assignment changes call the existing `assignMeshModerator` and `revokeMeshModerator` callable functions. This grants announcement publishing only, not admin-dashboard access.
- Announcement discussion UI in the member app. It appears only on `announcements` records with `commentsEnabled: true`; posts are written to `announcements/{id}/comments`.
- `publishScopedAnnouncement` now creates in-app notification documents for matching users in the same university, filtering department/class/faculty audiences and chunking writes into batches.
- Discussion and moderator management styles in `css/announcement-discussion.css`.

## Checks and limitations
- Static syntax and archive checks are expected to be run on this ZIP.
- No Firebase deployment, Emulator Suite test, live Firestore test, push-notification/FCM delivery, or browser/device runtime test has been performed. The notification feature is in-app Firestore notifications, not push notifications.
- Before production, verify the real `users` schema uses `universityId`, `facultyId`, `departmentId`, and `levelId` (or `level`) consistently, and verify all existing announcement documents use the expected fields.
- Discussion security rules currently restrict comments to same-university members and require `commentsEnabled == true`; stricter department/class visibility and abuse-reporting/moderation workflows should be tested and refined before rollout.
- Moderator assignment requires the user profile already match the chosen university and scope IDs exactly.
- Deploy Functions and Firestore rules together only after reviewing them in a staging Firebase project. Do not deploy untested rule changes directly to production.
