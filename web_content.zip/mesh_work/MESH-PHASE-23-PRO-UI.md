# MESH Phase 23 — Professional UI upgrade (light + dark in sync)

- Added `css/mesh-pro-ui.css`, loaded last. It reads the live theme variables (Super Admin palette, light/dark), so both themes and any published palette stay in sync. No JavaScript or Firebase logic was changed.
- Cleaner headers (icon buttons no longer wrap under titles), consistent cards, chips, Updates audience cards, announcement cards, alerts (unread state), profile, settings, onboarding and verification screens.
- Floating glass bottom navigation with a clear active pill; moderator Publish button restyled.
- Glassmorphic buttons for Sign in, Sign out and Continue with Google in light and dark (`.btn-glass` is also available for other buttons).
- Fixed: Home hero text contrast, leftover green tints in dark mode and onboarding, avatar colour.
- Logo: new blue network mark everywhere (`mesh-logo-mask.png`, `icon.svg`, `logo.svg`), new app icons (192, 512, maskable, Apple touch, favicon), updated manifest, logo tiles on Home, sign-in and verification screens.
- Service worker cache bumped to v2 so devices pick up the new look.
- No new animation (motion policy respected); `prefers-reduced-transparency` falls back to solid glass.

Checked: static tests pass; screens reviewed in headless Chromium at 390x844 in both themes. Not tested on a real device or against live Firebase data.
