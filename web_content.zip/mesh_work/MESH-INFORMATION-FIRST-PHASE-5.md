# MESH Information-First — Phase 5

## Focus

Integration review and a small compatibility repair, starting from Phase 4. This phase preserves the HTML/vanilla JavaScript + Firebase architecture.

## Repair

- The legacy blank-university announcement query in `js/campus-news.js` now explicitly filters `scopeType == 'university'`. Without that constraint, a Firestore rules query could be rejected because the result set could theoretically contain a blank-university faculty/department/class announcement, which the rules correctly do not expose as global.

## Added repeatable checks

Run from the project root:

```sh
node tests/phase5-static-checks.cjs
node --check js/campus-news.js
node --check js/moderator-publishing.js
node --check js/notifications.js
node --check functions/index.js
```

The static assertions verify that the expected callable functions, scope checks, comment rules, notification targeting, discussion wiring, and safer global-announcement query remain present.

## What was actually tested in this environment

- JavaScript syntax checks.
- Static source assertions.
- `firebase.json` and `functions/package.json` JSON parsing.
- HTML parsing and ZIP integrity.

## Not tested

- Firebase Emulator Suite rules tests (Firebase CLI/emulators were not available in this environment).
- Live Firebase Auth/Firestore/Functions integration.
- Real user role/scope data and any required Firestore composite indexes.
- FCM device push notifications.

## Required next action before production

Install/use Firebase CLI in a controlled staging environment, start the Auth and Firestore emulators, and run authenticated tests with separate Super Admin, assigned moderator, revoked moderator, same-scope student, and out-of-scope student identities. Do not deploy these rules to production until those tests pass and existing legacy records have been checked.
