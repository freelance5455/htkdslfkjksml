# MESH Admin diagnostics

## What changed
- The dashboard now has **System connection health** with checks for Firebase initialization, sign-in, the exact `admins/{current-auth-uid}` document, university reads, and student reads.
- The dashboard reports the permission error and likely next check instead of only showing `!`.
- Fixed mobile navigation: the sidebar was being set to `display:none` at phone widths with no `.mobile-open` display rule, so tapping the menu could not reveal it.
- No user documents or existing Firestore data are deleted or rewritten by these changes.

## When university publishing is denied
1. Open Firebase Console → Authentication → Users and copy the UID for the account currently used to sign into the admin panel.
2. Open Firestore Database → `admins` and verify there is a document whose **document ID** is exactly that UID (not merely a `uid` field inside a differently named document).
3. Verify `active` is a Boolean `true`, not the text string `"true"`, and `role` is exactly `super_admin`.
4. Verify Firestore Rules are published to the same Firebase project shown in `admin/js/admin-auth.js` (`mesh-9a4f1`).
5. Reload the admin page and run **System connection health → Run checks again**.

If the admin document check passes but student reads still fail, review the deployed `users` rule in `firestore.rules` and ensure it contains the Super Admin read branch. The health panel intentionally does not attempt a real write as a test, so it cannot create unwanted test records.

## Important
A browser-side diagnostic cannot publish Firestore Rules or grant permissions. If the current admin UID/role is wrong, correct that specific admin document in the Firebase Console first. Do not replace rules with unrestricted `allow read, write: if true`.
