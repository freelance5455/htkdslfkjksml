/* MESH PWA service worker. Do not cache Firebase API/auth responses. */
'use strict';
const CACHE_NAME = 'mesh-shell-v2';
const APP_SHELL = [
  './', './index.html', './manifest.json',
  './css/main.css', './css/components.css', './css/auth.css',
  './css/responsive.css', './css/mesh-redesign.css', './css/theme-runtime.css',
  './css/entry-motion.css', './css/brand-system.css', './css/mesh-pro-ui.css',
  './js/app.js', './js/home.js', './js/navigation.js', './js/auth.js',
  './js/onboarding.js', './js/firebase.js', './js/theme-runtime.js',
  './js/content.js', './js/search.js', './js/notifications.js',
  './js/community.js', './js/profile.js', './js/discover.js',
  './js/extras.js', './js/member-experience.js', './js/entry-motion.js',
  './js/campus-news.js', './js/pilot-access.js', './js/pwa.js',
  './assets/mesh-app-icon-original.png', './assets/icon-192.png', './assets/icon-512.png', './assets/icon-maskable-512.png', './assets/apple-touch-icon-180.png', './assets/favicon-32.png', './assets/mesh-logo-mask.png', './assets/icon.svg', './assets/logo.svg'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      if (response && response.ok) caches.open(CACHE_NAME).then(cache => cache.put('./index.html', response.clone()));
      return response;
    }).catch(() => caches.match(request).then(cached => cached || caches.match('./index.html'))));
    return;
  }
  event.respondWith(caches.match(request).then(cached => {
    const network = fetch(request).then(response => {
      if (response && response.ok && response.type === 'basic') caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
      return response;
    }).catch(() => cached);
    return cached || network;
  }));
});
