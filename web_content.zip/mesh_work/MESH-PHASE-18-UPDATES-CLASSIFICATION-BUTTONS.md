# MESH Phase 18 — Updates Classification, Moderator Scopes, and Alerts

## Changes

- Removed the audience shortcut cards and source-trust note from the Home screen below “Latest announcement”.
- Added those audience shortcuts to the Updates screen under “Browse by audience”.
- Updated Updates topic filters to cover Academic, Registration, Exams, Timetable, Deadlines, Events, and General. Legacy category values such as `academic-calendar`, `events`, `opportunities`, and `other` are normalized for filtering.
- Audience shortcut cards now select the corresponding audience filter, show the selected state, and refresh the Updates feed.
- Moderator publishing UI now recognizes active assignments for university, faculty, department, and level/class scopes. Admin assignment remains email-based and uses university and audience dropdowns.
- Alerts are deduplicated by their linked content, so a shared notification and a per-user notification for the same announcement are not rendered twice. Announcement alerts direct students to Updates rather than repeating the full announcement body.
- The admin “Fix visibility” action preserves the announcement's existing faculty/department/class audience instead of silently converting it to university-wide.

## Verification

- JavaScript syntax checks passed for the modified member/admin files and Cloud Functions source.
- `npm run test:static` passed (Phases 5–14, 16–18).
- Static checks do not execute Firebase Security Rules, deployed callable functions, or live UI interactions. Run Firebase Emulator and staging tests before production deployment.
- No live Firebase deployment was performed.
