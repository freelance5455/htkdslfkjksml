# MESH Information-First Redesign — Phase 2

## Included
- Callable Cloud Functions `assignMeshModerator`, `revokeMeshModerator`, and `publishScopedAnnouncement` in `functions/index.js` (region `europe-west1`).
- Super Admin-only moderator assignment/revocation; user profile must match assigned university and department/level.
- Callable-only moderator publishing; every publish rechecks the live assignment and user profile.
- Moderator assignment reads are restricted to the assigned user and Super Admin; direct client writes are denied.
- Member PWA has a hidden-by-default Publish navigation action that appears only when a current active assignment is read successfully.
- Announcement composer for title, category, message, and comment toggle.
- Announcement-scoped comments with university matching, author attribution, content limits, and commentsEnabled enforcement.

## Important deployment notes
1. Deploy Firestore rules and Cloud Functions together: `firebase deploy --only firestore:rules,functions`.
2. Assignment/revocation callable functions are Super Admin-only but this phase does not yet add a moderator-management screen to the admin UI. A Super Admin tooling interface is the next step.
3. The assignment model currently supports one active assignment document per user. Scope types are `department` or `class`; department uses `users.departmentId`, class uses `users.levelId` or `users.level`. Confirm your actual ID conventions before production rollout.
4. Callable publication writes an `announcements` document with `status: published`, `active: true`, scope and publisher metadata. Existing Campus News UI/query compatibility should be tested against real Firestore data. This function does not yet fan out push notifications; notification fan-out is a later phase.
5. This code has not been deployed to Firebase. Do not assume deployed behavior until emulator/security-rule tests and a pilot deployment pass.
