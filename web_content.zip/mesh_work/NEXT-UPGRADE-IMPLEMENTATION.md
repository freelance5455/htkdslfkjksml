# MESH Next Upgrade — implementation notes (2026-10-12)

## Included in this package
- Home now includes a student social composer and feed.
- Text posts support Global MESH and My University Only audiences, author edit/delete, author-controlled comments, multiple reactions, in-app reshare, copy-link, and reporting.
- Added Firestore rules for the new `posts` collection, its reactions/comments subcollections, and `contentReports`.
- Feed reads use separate global and university-scoped queries; do not rely on client-side filtering for access control.
- Animation policy remains: no animations/transitions after Home appears.

## Important: do not publish rules blindly
The new social rules require `users/{uid}.verificationStatus == 'approved'`. Existing test accounts without that field will be blocked from social posting. Update a test account through a trusted admin process before testing. Do not allow users to set this field themselves. The existing `/users/{uid}` update rule in this project is broad and needs a separate schema-aware hardening pass before this verification gate can be considered secure.

## Photos / ImageKit status
Album UI and uploads are not enabled in this package. This is intentional: a public ImageKit upload URL is not audience-private, and a browser must never contain an ImageKit private key. For university-only photo posts, choose a secure signed upload/delivery design first (trusted backend or a supported private-storage option), then implement up to 10 photos per post. Official announcement images need the same storage review.

## Not yet implemented end-to-end
- Invite-code registration enforcement and admin invite management.
- Private proof submission, restricted applicant routing, verification review UI, and document retention/deletion.
- Dedicated Campus News improvements, Connect student discovery, expanded notifications, full admin moderation queue, and end-to-end admin integration.
- Real Firebase emulator rules tests and Android device tests.

## Required checks
1. Use Firebase Emulator Suite or a separate test project before publishing rules.
2. Test global visibility, same-university visibility, cross-university denial, unauthenticated denial, unverified denial, author-only edits/deletes, comments disabled, reaction ownership, and reports visible only to authorized moderators.
3. Confirm the user profile's university ID field and verification status schema.
4. Keep a backup of the previous ZIP and do not overwrite live files until checks pass.

## Pilot access, verification, Campus News, and moderation (2026-10-12)
- Registration now requires a one-time pilot invite code. The client validates the code and consumes it with the new pending user profile in a Firestore transaction.
- New invitees are routed to a restricted private verification screen. Authorized Super Admins can review the queue, access submitted proof files through restricted Storage paths, and approve/reject requests.
- Admin workspace now includes Pilot invite codes, Student verification, and Moderation reports pages.
- Campus News has a dedicated student screen with categories, source/date labels, and bulletin-image rendering. Admin content editor accepts HTTPS image URLs, source/issuing office, category, and publish/draft status.
- Firestore and Storage rules were updated for these collections and paths. Review and test these rules in Firebase Emulator/staging before publishing to the live project.
- This upgrade uses image URLs for public Campus News images; direct signed image-host uploads are not yet implemented. Firebase Storage for private proof uploads must be confirmed available on the project's current plan.
