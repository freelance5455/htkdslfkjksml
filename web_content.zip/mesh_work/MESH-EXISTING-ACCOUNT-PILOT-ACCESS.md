# Existing account pilot access and UX updates

- Existing student accounts without `inviteCodeUsed` are prompted for a pilot code after sign-in. The existing Firebase Auth account is preserved.
- Existing admin accounts are also prompted from the admin workspace; redemption only records pilot access and preserves the admin's assigned role. A pilot code does not grant Super Admin privileges.
- Pilot codes are normalized and checked against the generated `XXXXX-XXXXX` alphabet (`A-HJ-NP-Z2-9`) before the Firestore transaction. Database checks still decide whether a code is active, unused, and unexpired.
- Sign-in messaging now explains that an unregistered email should sign up; Firebase may intentionally return a generic invalid-credential error, so the UI does not claim it can always distinguish an unknown email from a wrong password.
- Profile includes optional initials/emoji avatar style choice; no gender is collected.
- Non-Super Admin dashboard hides the Students by University section and dashboard.js does not query that distribution for non-Super Admins.

## Deployment caution
Publish `firestore.rules` for student/admin code redemption and the `avatarStyle` profile field before testing. The code changes are not deployed to Firebase and have not been tested against live project permissions.

- Verification no longer uploads the original proof to Firebase Storage. Tesseract.js reads supported images locally in the browser; Firestore receives the matric number, OCR text/confidence, and the review request only. Without a stored document, server-side OCR cannot automatically approve; cases remain for admin review based on available evidence and may need a separately arranged secure document check.
