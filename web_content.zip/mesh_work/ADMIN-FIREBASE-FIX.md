# MESH Admin Panel Fix — Safe rollout

This update changes the **admin panel and Firestore security rules only**. It does not delete or migrate user documents automatically. Existing students, authentication accounts, and content are preserved.

## What changed
- Dashboard totals now report failed reads separately instead of turning every card into `!` because one query failed.
- Students-by-university includes existing university names found in user profiles, including legacy records whose university catalogue entry is missing.
- Academic dialogs have a fixed Nigeria country field for universities, publish-state feedback, parent selectors, and actionable Firebase errors.
- A **Recover universities from existing accounts** action can recreate missing catalogue entries from existing user profile data. It asks for confirmation first and does not edit user accounts. It tries to preserve a user's existing `universityId` as the catalogue document ID.
- Content publishing, university requests, community publishing, support tickets, user loading, and admin assignment show the Firebase error rather than failing silently.
- Admin assignment no longer asks for a full-name field; it resolves an existing MESH account by email.
- Mobile sidebar closes when the outside/backdrop area is tapped.

## Publish the updated Firestore Rules
1. Back up your current rules text somewhere safe.
2. Open Firebase Console and select the existing `mesh-9a4f1` project.
3. Open **Firestore Database → Rules**.
4. Replace the rules editor content with the `firestore.rules` file from this ZIP, then tap **Publish**.
5. Do not paste `storage.rules` into the Firestore editor. Storage rules belong to a separate Firebase Storage rules page and are not needed to fix these admin database permissions.

## Confirm Super Admin access
In **Authentication → Users**, open the account you use for the admin panel and copy its UID. In **Firestore Database → Data**, open the `admins` collection and make sure a document exists whose document ID is exactly that UID, with:
- `uid` — string, same UID
- `email` — string, your sign-in email
- `role` — string, `super_admin`
- `active` — boolean, `true`

Do not create a different admin document ID or delete existing users. The rules intentionally do not let ordinary signed-in students read or modify the whole user database.

## Recover the missing university catalogue
1. Sign in to the admin panel as Super Admin.
2. Open **Academic data**.
3. Tap **Recover universities from existing accounts** and confirm.
4. Review the resulting university list before adding faculties/departments.
5. If the existing user records contain neither `universityId` nor `university`/`universityName`, the recovery tool cannot infer a university name; add that university manually and assign it to the relevant records later.

## Important
The source files passed JavaScript syntax checks and the ZIP passed archive integrity checks. The changes have not been live-tested against your Firebase project, so after publishing rules, test one action at a time. If an operation still fails, the panel now shows the Firebase error code/message to help identify whether it is a rules, account-role, or data-shape issue.
