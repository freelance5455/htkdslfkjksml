# MESH Information-First — Phase 12

## Scope

Phase 12 hardens community interaction permissions and moves community aggregate counters out of client-writable fields.

## Changes

- `communityPosts.likeCount` and `communityPosts.commentCount` are no longer writable by ordinary signed-in users.
- Added Cloud Functions `updateCommunityLikeCount` and `updateCommunityCommentCount`. They process create/delete events for community likes and comments, update counts in a transaction, and use an event marker to avoid applying the same event twice.
- Added stricter `communityPosts/{postId}/likes/{uid}` and `comments/{commentId}` rules for owner identity, allowed fields, content length, timestamps, and parent post visibility.
- Member community feed now queries global posts and the signed-in user's university posts separately so Firestore rules can authorize the query rather than relying on client-side filtering.
- University-admin community list queries are scoped to the assigned university; Super Admin retains the all-post view.
- Added `tests/phase12-community-security-checks.cjs` to the static test suite.
- Added publish request IDs to the moderator UI and callable. Retrying the same request reuses the same announcement document ID. Notification IDs are deterministic per announcement and recipient, and existing notices are not reset to unread on retry. The publish audit record also uses a deterministic ID.
- Added composite Firestore indexes for the scoped community feed and university-admin list queries.

## Validation

Run `npm run test:static` for source-level checks. Run `npm run test:rules` with Firebase CLI and dependencies installed to validate actual Firestore rule behavior in the Emulator Suite.

## Important limitations

- Cloud Functions must be deployed before backend counters update in Firebase. Counter updates are asynchronous, so the UI may show a brief delay after a like/comment.
- Existing legacy community posts may have counters that need a one-time reconciliation against their likes/comments subcollections.
- This phase does not deploy Firebase or prove live behavior. Do not deploy rules/functions to production until emulator and staging tests pass.
- Notification fan-out is now idempotent for the same request ID, but recipients are still re-evaluated on each retry and deployment/staging tests are required.
