# MESH pilot repair pass — 14 October 2026

Baseline: `MESH-PILOT.zip` supplied in this conversation.

## Implemented in this working copy
- De-duplicated active university/faculty/department/level/interest options in onboarding by normalized ID/name, while retaining existing records.
- Made profile saving wait for Firebase success before changing the displayed local profile, and added explicit error handling.
- Kept university/faculty/department/level/onboarding/access fields out of profile-edit updates; tightened the Firebase client API to an explicit profile-field allowlist.
- Added basic username format validation in the profile-update API (3–24 lowercase letters, numbers, underscores).
- Hardened the global modal open/close functions against missing modal markup and guarded the Help & Support form binding; the support feedback is now an accessible status region.
- Added a username column to the admin users data rendering (the existing Users table already has a Username header) while retaining full name and other columns.
- Removed the persistent always-on admin alert banner; the helper now removes any existing injected banner.
- Added audit events for successful CSV exports and admin table pagination actions.
- Added optimistic UI updates and rollback handling for post reactions and comment counts.
- Changed new feed posts/comments to use a chosen username when present and fall back to a member display name rather than the generic `meshstudent` label.
- Preserved the existing no-Storage / static HTML-CSS-JS architecture and did not deploy services or alter Firebase project state.

## Verification performed
- The source ZIP passed `ZipFile.testzip()` before editing.
- All JavaScript files in the working copy passed `node --check` (43 files).
- Final ZIP integrity check is run after packaging.

## Not completed / needs additional implementation or live verification
This pass does **not** claim all 18 approved items are complete. In particular:
- Secure, race-safe global username uniqueness and a one-time username lock still require coordinated Firestore claim documents and rules; the client-side format check is not a uniqueness/security guarantee.
- The existing-account username prompt and a full public student profile route/view still need implementation.
- Moderation still needs server-enforced review of new post content; the existing Cloud Function source does not become active unless deployed, and its current prohibited-language coverage is limited.
- Per-user notification read state needs a Firestore schema/rules change; the current shared notification `read` fields can affect other users.
- A complete admin notification-list UI and comprehensive audit coverage for every CRUD/admin-management action remain unfinished. Audit writes depend on matching deployed Firestore rules.
- The exact Help & Support failure could not be reproduced against live Firebase; modal null guards are a defensive fix, not proof the permission/schema issue is solved.
- Android CSV behavior must be tested on the target browser/device. The code keeps a visible download link fallback.
- Profile author links, all post department scoping/notification flows, and dashboard sync of every existing post need further end-to-end checks.
- Firestore rules were not changed or deployed, and Cloud Functions were not deployed. No Firebase Emulator/live Firebase/Android test was run.

Before deployment, review and test these remaining items against a staging Firebase project and the actual Android browser.


## Continuation pass — personal notification read state
- Notification read markers are now stored per signed-in user at `users/{uid}/notificationReads/{notificationId}` rather than writing the shared notification document's `read` fields.
- Added Firestore rules for a user to read/write only their own notification-read markers, with an allowlist of `read` and `readAt`.
- Notification rendering reads personal markers and uses them to display unread styling.
- This is a source-level change only. It requires publishing the updated Firestore rules before the per-user read-state feature can work in the live project. Existing shared `read` fields remain a compatibility fallback only for notifications addressed directly to the signed-in user.

\n## Next continuation pass — student profile preview from feed
- Feed author names now open a lightweight profile dialog using the post author UID.
- The dialog displays only name, username, department, level, university and optional bio; it does not render email or phone fields.
- Source-level UI only: Firestore rules still govern whether profile data can be read. This is not yet a dedicated shareable profile URL or profile post history.

## Consolidated final repair pass — 14 October 2026
### Implemented in this pass
- Username saves now use a Firestore transaction to reserve normalized names in `usernameClaims/{username}` and reject names claimed by another UID.
- Username changes are limited to one change through `usernameChanged` and `usernameChangeCount`; the first username assignment for legacy accounts is supported.
- Firestore rules now include owner-bound, immutable username claims and the fields/conditions needed for the one-time username lock.
- Profile loading prompts accounts without a username (including legacy `MESH Students`) to choose one, and displays actionable validation/save errors.
- The existing student profile preview, per-user notification-read markers, feed author links, prior CSV/admin changes, and prior repairs are retained.
- `firestore.rules` in this ZIP is updated alongside the client code.
### Checks performed
- `node --check` passed for all 43 JavaScript files in the packaged project.
- Archive integrity checked after packaging.
- Rule logic was reviewed for matching username-claim paths, but Firebase CLI/emulator validation and live Firestore permission tests were not available in this run.
### Not represented as complete / deployment-dependent
- Cloud-side content moderation and administrator alerting must be deployed and exercised in the real Firebase environment before it can be called server-enforced.
- The admin notification icon/list and comprehensive audit coverage still require full page-level integration testing.
- Firebase rules must be published from this ZIP; no deployment was performed.
- Android CSV download behavior, public profile data visibility, live username concurrency, support submission, and the complete end-to-end app flow still require device/project testing.
