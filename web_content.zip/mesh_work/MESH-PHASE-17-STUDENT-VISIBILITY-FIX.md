# MESH Phase 17 — Student Visibility Fix

## Root cause
The admin content form previously wrote `active: true` and `universityId`, but omitted `scopeType`. Student Home and Updates query the `announcements` collection using `scopeType == 'university'`, so the announcement could appear Published in admin while being excluded from those queries.

## Fix
When the admin publishes or edits an `announcements` record, it now writes `scopeType: 'university'`, `scope: 'university'`, empty `scopeId`, matching audience fields, a `published`/`draft` status, and `publishedAt` for active posts. This aligns admin-created university-wide announcements with the existing student queries and Firestore visibility rules.

## Existing content
Previously published announcement records are not silently bulk-mutated. Open each affected item in the admin Content list and save it again so the corrected schema is written. Confirm the app and admin panel use the same Firebase project, then refresh the app (and update its cached files if installed as a PWA/APK).

## Verification
Run `npm run test:static`. These checks validate source structure only. Firebase emulator tests and a real student-account publish/read test are still required before claiming live end-to-end success. No deployment was performed.
