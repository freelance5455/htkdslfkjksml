# MESH — Connected Multi-University Build

This is an update to the existing MESH project and existing Firebase project `mesh-9a4f1`. Keep your previous ZIP as a backup; this package does not ask you to create a new Firebase project.

## What was updated
- Firestore-driven dashboard totals and a global Students-by-University table; university admins see their assigned school's count.
- Admin assignment includes a role and assigned university; non-super-admin navigation is restricted to university workspace controls.
- Academic data forms include university acronym/state; onboarding continues to load active universities, faculties, departments, levels and interests from Firestore.
- Student university-request dialog and Admin → University Requests review/approve/reject page.
- Resource records support title, description, university, and HTTPS file/link URL; Discover has a full-page Firebase content listing.
- General community feed with admin publishing, live Firestore likes and comments.
- Notification navigation, profile-name greeting, local-time greeting, theme choice, profile-picture upload, change-password flow, help/support ticket submission and admin support-ticket review.
- Visible sign-out control and improved Discover/content cards.
- Firestore and Storage rules files plus setup checklist.

## Firebase Console steps
Follow `FIREBASE-SETUP.md` exactly. In particular, publish both `firestore.rules` and `storage.rules`, then verify the Super Admin document uses the Firebase UID as its document ID and `active` is a Boolean `true`.

## Safe rollout
1. Keep the existing project ZIP as a backup.
2. Extract this ZIP and upload the contents of `MESH/` to the same hosting location, preserving the `css/`, `js/`, and `admin/` paths.
3. Do not delete existing Firestore documents or collections.
4. Publish rules only after reviewing them and testing with a separate student and a university-admin account.
5. Test: student signup → onboarding university list → university request → admin request approval → admin content publish → student Discover → community like/comment → profile photo/theme/password/support.

## Important limitation
The source has been syntax-checked, but I cannot authenticate against your live Firebase project from this workspace. So treat this as a connected code update requiring the Firebase Console setup and real-device smoke tests above, not a claim that every live Firebase permission has already been verified. In particular, Firebase rules are security-critical: test role boundaries with a separate university-admin account before inviting actual university administrators.


## V1 launch audit
Read `MESH-V1-RELEASE-AUDIT.md` before public launch. It lists static check results, security-rule risks, and required live tests. Do not publish security rules without testing.


## Next upgrade notes
See `NEXT-UPGRADE-IMPLEMENTATION.md` for the new social feed scope, photo-storage safety limitation, and required security tests.

## Public webpage link import (added 2026-10-14)
See `URL-IMPORT-FEATURE-2026-10-14.md` for the admin URL-preview workflow, deployment command, security behavior, and limitations. The import callable must be deployed before the new admin control can fetch previews.

## URL importer reliability update (2026-10-14)
The URL importer now tries direct Open Graph/Twitter metadata first and a no-key public reader fallback second. This improves coverage for some JavaScript-heavy or bot-resistant public pages. It cannot guarantee extraction from eBay or WhatsApp, whose access controls and page design may prevent external preview. See `URL-IMPORT-FEATURE-2026-10-14.md` for deployment, privacy and limitations. Deploy both the callable function and hosting files; no external eBay/WhatsApp API key is required for the generic importer.


## URL preview availability patch (2026-10-14)
When the Firebase URL-import callable is unavailable, the admin UI now tries the no-key public reader from the browser as a fallback. It preserves the active-admin check for authentication/permission errors. Browser fallback success depends on network/CORS and the public source page; WhatsApp content may remain inaccessible. See `URL-IMPORT-FEATURE-2026-10-14.md`.

## 2026-10-14 — notifications, delete controls, graphical health and member polish

See `MESH-ADMIN-NOTIFICATIONS-HEALTH-MEMBER-POLISH-2026-10-14.md` for the exact changes, security notes, verification performed, and live-testing limitations. The Super Admin dashboard now includes a confirmed global notification-clear action, official content rows include a permanent Delete action with related-notification cleanup, System Health uses graphical status cards, and member notification lists refresh live while open. Firestore rules were intentionally left unchanged because the existing rules already authorize active Super Admins to perform these operations.

## Information-first phases 5–10 release notes
The latest staged package includes the Phase 5–10 information-first work. Read `MESH-INFORMATION-FIRST-PHASE-10.md` before staging: resource Storage writes are now university-scoped in the rules source, but the project remains **not cleared for public launch** until emulator-backed Firestore/Storage rules tests and live staging smoke tests pass. Static checks are not a substitute for those tests.


## Information-first Phase 11
See `MESH-INFORMATION-FIRST-PHASE-11.md`. Support ticket access has been hardened to match the current central Super Admin review workflow. This is a static-source update only; emulator and live staging tests remain mandatory. Community counter integrity and notification fan-out reliability remain release blockers.
