# MESH Admin: Import Content from a Public URL

## What was added
- The Admin > Campus News & Content form now includes **Import from a public webpage**.
- An active MESH admin can paste a public HTTPS webpage URL and request a metadata preview.
- The backend callable reads page title, description, site name, and Open Graph/Twitter preview image where provided.
- Imported details fill the existing content form. Admins can edit everything and must submit the existing publish form; fetching a URL never publishes content automatically.
- The callable requires Firebase Authentication plus an active admin document and rejects non-HTTPS URLs, IP-literal/localhost/private DNS destinations, non-HTML responses, oversized pages, and excessive redirects.
- The existing Firestore content publishing rules remain the enforcement point for saving/publishing; this feature does not add a client-side bypass.

## Deploy
From the project root, with Firebase CLI authenticated and the correct Firebase project selected:

```sh
firebase deploy --only functions:importMeshContentFromUrl
```

The Firebase project must have Cloud Functions enabled and the plan/billing configuration required by Firebase for deploying callable functions. Deploy the hosting/static files too if the admin app is hosted through Firebase Hosting:

```sh
firebase deploy --only hosting
```

Deploy Firestore rules only if you have separately changed them; this feature does not require a new Firestore rule because the preview is server-side and publishing uses the existing rules.

## Limitations
- This fetches public webpage metadata, not the full article body.
- Some social networks, WhatsApp channel links, login-gated sites, and anti-bot protected pages will not provide usable metadata. Use the manual fields for those sources or a platform-approved API/integration.
- A preview image is only shown when the source webpage exposes a usable HTTPS metadata image. MESH links to the image; it does not copy/rehost it.
- Review accuracy, attribution, permission to reuse images, and source credibility before publishing.

## Checks performed in this package
- `node --check functions/index.js`
- `node --check admin/js/content.js`
- ZIP archive integrity test

A live Firebase deployment, callable invocation, and Android-device test have not been performed from this package build environment.

## Fallback reader and API-key clarification (2026-10-14)
- The importer first tries the original public HTTPS webpage, then tries a no-key public reader fallback when metadata is missing or blocked. The fallback reader is a third-party service, can be rate-limited, and receives the URL being previewed. Do not submit private, signed, or sensitive URLs.
- No eBay API key or WhatsApp API key is required for the generic importer. This does **not** bypass a website's access restrictions. eBay may still block automated readers, and WhatsApp channel/post pages often do not expose post text/images to external readers.
- When a preview cannot be retrieved, the admin UI now gives clearer Firebase setup errors and directs the admin to manual title/body/source/image fields instead of implying that every source needs an API key.
- Deploy the updated function and admin hosting files after extracting this release. If the error mentions Cloud Functions API, enable Cloud Functions in the Google Cloud/Firebase project and complete the billing/plan setup Firebase requires, then deploy the function.


## Browser fallback reliability patch (2026-10-14)
- If the Firebase callable is temporarily unavailable or not deployed, the admin UI now attempts the public reader directly from the browser. This can make public webpage previews work before Cloud Functions is restored, provided the browser can reach the reader and the reader permits cross-origin access.
- Authentication and admin-permission errors do not trigger the fallback; sign in with an active admin account instead.
- If the browser fallback reports a network/CORS error, deploy/repair the Firebase callable or use the manual fields. The fallback does not defeat source-site restrictions and cannot guarantee WhatsApp channel post extraction or eBay images.
- The public URL is sent to the third-party reader. Do not submit private, signed, or sensitive URLs. Preview results must still be reviewed before publishing.
