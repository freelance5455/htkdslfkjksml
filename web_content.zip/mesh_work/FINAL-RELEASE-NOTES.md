# MESH consolidated repair release

This archive consolidates the available repair passes and includes the updated `firestore.rules`.

## Apply
1. Back up the current project and Firestore rules.
2. Review the changes in `js/firebase.js`, `js/profile.js`, `js/social-feed.js`, notification files, admin files, and `firestore.rules`.
3. Test rules with the Firebase Emulator Suite against representative student/admin accounts before publishing.
4. Publish rules only after confirming existing admin role documents and collection schemas match the rules.
5. Test the Android web app with at least two student accounts, two username claims, and an admin account.

## Username behavior
Usernames are normalized to lowercase and must be 3–24 characters using letters, numbers, and underscores. Claim documents are stored at `usernameClaims/{username}` and are not transferable/deletable by clients. The first assignment for a legacy account is permitted; a later change is locked. Existing user data is not automatically backfilled into claim documents, so legacy username collisions should be reviewed before launch.

## Validation performed
All JavaScript files pass `node --check`; ZIP integrity passes. This is not equivalent to Firebase emulator tests, live deployment, or Android device testing.

See `MESH-REPAIR-STATUS.md` for known limitations and the status of the requested fixes.
