# MESH motion policy — 12 October 2026

- Removed general-purpose UI motion from the runtime after the first Home screen is shown.
- Only the initial Splash/Welcome → Sign In or Registration → first Home journey may use subtle entry animation.
- Welcome/auth reveal is short and restrained; first Home reveal is limited to 420ms.
- After Home first appears, `mesh-motion-locked` disables CSS animations, transitions, and smooth scrolling throughout member and admin UI.
- The initial journey respects `prefers-reduced-motion`.
- This change is limited to motion behavior. It does not mean all other features in the broader MESH master plan have been implemented or fully tested.
