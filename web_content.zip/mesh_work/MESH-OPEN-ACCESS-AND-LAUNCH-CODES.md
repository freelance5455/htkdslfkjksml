# MESH open-access pilot and university launch codes

## Included changes
- Keeps the existing authentication screen and email/password sign-in.
- Signup still requires a code. Existing accounts can redeem a code in the in-app pop-up without recreating their account.
- Private pilot codes remain one-time, admin-issued codes.
- Reusable launch codes are university-bound (example: `ABU-MESH`) and track redemptions in `inviteCodes/{code}/redemptions/{uid}` with a usage counter on the code document.
- Onboarding rejects a university selection that does not match the launch code's assigned university.
- Student verification and OCR are removed from the critical onboarding/posting path. The verification screen now explains that university-backed verification is a future feature.
- Registered users can post without student-verification approval, while sign-in, account records, university audience boundaries, and admin roles remain in place.
- Existing optional avatar style choices are preserved.
- Existing admin CSV export and code/email tracking work is retained.

## Required deployment step
Publish `firestore.rules` in Firebase Console → Firestore Database → Rules before testing. These rules have not been deployed from this package.

## Important behavior
The launch code controls which university can be selected during onboarding; it does not independently prove that the user is enrolled at that university. University-backed verification can be added later when an authorized school verification source is available.

## Validation performed
JavaScript syntax checks, HTML parsing, and ZIP integrity checks only. No live Firebase transactions, Firestore Rules emulator tests, or Android end-to-end tests were performed.
