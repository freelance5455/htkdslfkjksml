# MESH incident repair — 2026-10-14

## Changes in this build
- Super Admin roles (`super_admin`, `super-admin`, `superadmin`) bypass the admin pilot-code gate entirely. Other admin accounts retain the pilot-code flow.
- Global and university feed queries explicitly filter `status == active`, matching Firestore read rules so eligible posts can load.
- Student verification is not used as the social-feed eligibility gate; registered users with profiles can post and interact.
- The Change password menu item now reaches its dialog instead of being swallowed by the generic profile-menu handler. Password-auth accounts reauthenticate with their current password before changing it.
- Theme runtime now applies dark background/surface/text/border tokens instead of leaving inline light-theme values overriding dark mode.
- CSV exports retain a visible manual download link for Android/mobile browsers if the automatic Blob download is blocked.

## Before production use
Publish `firestore.rules` in Firebase Console. No rules were deployed by this package. Validate code redemption, global and university post visibility, and admin role permissions with the Firebase Rules Simulator and real test accounts. If an operation still returns `permission-denied`, inspect the browser console for the exact collection/path and operation; Firestore rules are path-specific.
