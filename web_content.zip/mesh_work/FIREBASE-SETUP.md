# MESH — Firebase setup for this connected build

Project configured in the code: `mesh-9a4f1`.

## Important before publishing
1. Keep a backup of the current project and Firestore data.
2. Firebase Console → Authentication → Sign-in method: enable Email/Password and Google if you intend to use both.
3. Firebase Console → Firestore Database → Rules: paste `firestore.rules` and click **Publish**.
4. Firebase Console → Storage → Rules: paste `storage.rules` and click **Publish**. Storage must be initialized in the Firebase project.
5. Firebase Console → Authentication → Users: create your own MESH account through the app first and copy its UID.
6. Firestore → `admins` → create a document whose **document ID is exactly that UID**. Add fields:
   - `uid` (string): same UID
   - `email` (string): same account email
   - `name` (string): your name
   - `role` (string): `super_admin`
   - `active` (boolean): `true`
   - `universityId` (string or null): `null`
7. Sign into `/admin/` using that account. Use Academic Data to add universities. University records need `name`, `code` (acronym), `state`, and `active: true` (Boolean). Existing document IDs are preserved; do not delete old records just to change labels.
8. Add faculties with the matching `universityId`; add departments with matching `universityId` and `facultyId`. Add levels and interests.
9. To assign a university admin, the person must first register a normal MESH account. In Admins → Assign admin, enter their exact account email, resolve it, choose **University Admin**, and select their university. The resulting `admins/{uid}` document should include `role: university_admin`, `universityId: <university document ID>`, and `active: true`.
10. Test with a separate test student and test university admin before giving access to a real admin.

## Data collections used
`users`, `admins`, `universities`, `faculties`, `departments`, `levels`, `interests`, `universityRequests`, `announcements`, `events`, `opportunities`, `resources`, `news`, `communities`, `notifications`, `communityPosts` (with `likes` and `comments` subcollections), and `supportTickets`.

## Resource publishing
In Admin → Content, choose **Resources**, select a university, enter title/description and a direct HTTPS URL to the resource. This version stores a resource link; a full file upload UI can use Firebase Storage once your file-size/type policy is finalized. The Storage rules already provide a `resources/{universityId}/...` path.

## University isolation / permissions
Super Admin can manage the global workspace. University admins must be assigned a `universityId`. This build includes role-aware admin navigation and rules for university-scoped writes. Test access with a non-super-admin account because Firebase Rules are authoritative. Do not give `super_admin` to university administrators.

## Profile picture
Storage rules allow signed-in users to upload image files up to 5 MB under `profilePictures/{uid}/...`. Profile image URL is saved to the user's `users/{uid}` document.

## Notes
- Firebase client configuration is not a server secret; never put a service-account key in this ZIP.
- Do not enable public read/write rules in production.
- Existing Firestore documents are not deleted by these changes. The starter catalogue button uses merge writes, so it updates the starter records without wiping other university records.
- If rules are changed, publish them in the same Firebase project ID configured in the files.


## MESH update notes — scoped posts and notifications

This build adds role-scoped community posts and creates a matching notification whenever an admin publishes content or a community post. **Publish the included `firestore.rules` in Firebase Console → Firestore Database → Rules** after backing up your current rules. The updated rule allows Super Admins to publish global community posts and allows an active University Admin to publish only to their assigned university. Do not replace this with open read/write rules.

### Password reset emails

The app calls Firebase Authentication's `sendPasswordResetEmail`. If the app confirms that Firebase accepted the request but no email arrives, check Spam/Promotions, verify the email belongs to an account, and open Firebase Console → Authentication → Templates → Password reset to confirm the template is enabled and its sender details are configured. Also check Authentication → Settings → Authorized domains for the domain where MESH is hosted. Firebase may suppress account-existence details when email-enumeration protection is enabled.

### What changed in this build

- Bottom navigation remains fixed while the content area scrolls independently.
- Home shortcuts and Discover category cards open Discover with the relevant content filter.
- The Community feed has a more consistent card design and filters university-specific posts.
- Super Admin can publish global community posts or target a single university; University Admin is restricted to their assigned university in the UI and Firestore rules.
- Publishing community posts and active content writes a notification in the same Firestore batch.
- The admin Content page's Add content button is now wired to its editor.
- Profile → Settings opens a dedicated settings page with Light, Dark, and System appearance options.
