# MESH Information-First — Phase 11: Support Ticket Security Hardening

## Implemented

- Support ticket creation is restricted to the signed-in ticket owner and a strict set of fields. Topic, message length, status, email type, and server timestamp are validated in Firestore Rules.
- Ticket owners can read only their own tickets. Review access is limited to active Super Admins, matching the current admin support UI and avoiding cross-university access to private support messages.
- Only Super Admins can resolve or delete tickets. A resolution update may change only `status` and `resolvedAt`, and the resolution timestamp must be a server timestamp.
- Added `tests/phase11-security-checks.cjs` to the static test suite.

## Deliberately not changed

- Community engagement counters remain a release risk. The existing client updates `likeCount` and `commentCount` directly; removing that permission without first migrating the client to trusted Cloud Functions or deriving counts from subcollections would break current interactions. Do not rely on these counters for analytics until the data model is hardened.
- Announcement notification fan-out still needs durable retry/idempotency handling.
- Resource Storage MIME-type policy and Firestore/Storage rule behavior still need emulator-backed tests.

## Validation

Run `npm install`, then `npm run test:static` and `npm run test:rules`. Static checks validate source contracts only. Firebase Emulator and live Firebase tests were not run in this workspace; this phase is not production approval.

## Release status: NOT CLEARED FOR PUBLIC LAUNCH

Before deployment, verify that the deployed admin UI uses the expected Super Admin support workflow, then run Firestore and Storage Rules tests with student, university-admin, and Super Admin fixtures. Keep the previous ZIP as a rollback copy.
