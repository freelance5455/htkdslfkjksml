# MESH Information-First — Phase 6: Staging test harness

## What this phase adds

- Firebase Emulator Suite configuration for Auth, Firestore, Functions, and the Emulator UI.
- A root `package.json` with repeatable static and Firestore rules test commands.
- `tests/firestore.rules.test.cjs`, a rules-unit-testing suite that checks department audience isolation, comment permission/author identity, notification ownership, and moderator-assignment reads.
- `tests/phase6-static-checks.cjs`, a configuration/source assertion check.

## Run locally

Requirements: Node.js 20 and Java compatible with the Firebase Emulator Suite.

```sh
npm install
npm run test:static
npm run test:rules
```

The rules command starts the Auth and Firestore emulators temporarily and runs the tests. It does not deploy anything to the configured production project. Use test project ID `mesh-rules-staging-test` only for emulator tests.

## What has been verified in this packaged environment

- Phase 5 static assertions pass.
- Phase 6 configuration assertions pass.
- JavaScript syntax checks pass for the modified application scripts, Cloud Functions source, and test files.
- `firebase.json` and root/function package JSON parse correctly.
- HTML parser and ZIP integrity checks pass.

## Limitations

The Emulator Suite could not be started in the packaging environment, so `tests/firestore.rules.test.cjs` is included but has **not** been executed here. This phase is a test harness, not a claim of live Firebase verification. The callable Cloud Functions (assignment, revocation, publishing) still need authenticated integration tests against the Functions emulator. Validate actual profile schema and required composite indexes in staging. Do not deploy the rules until emulator tests pass.
