# MESH Information-First — Phase 8

## Purpose
Address two release-blocking risks found during the Phase 7 source review: member access to unpublished announcements, and Home querying announcements too broadly for Firestore Security Rules to authorize safely.

## Changes
- `firestore.rules`: ordinary member announcement reads now require a record not to be explicitly disabled (`active == false`) and not to be explicitly unpublished (`status` must be `published` or `active` when a status field exists). Legacy records without these fields remain compatible, subject to audience scope.
- `js/home.js`: replaced the broad university-wide announcement query with separate audience-constrained queries for university, faculty, department, class/level, and legacy university-wide records. Each query is handled independently so one unavailable scope does not suppress opportunities or other announcements.
- `tests/firestore.rules.test.cjs`: added emulator cases ensuring a student cannot read draft or disabled announcements even when the academic scope matches.
- `tests/phase8-static-checks.cjs`: added static assertions for the security and query changes and included them in `npm run test:static`.

## Static validation performed
- `node --check js/home.js`: PASS
- `node --check functions/index.js`: PASS
- `node --check tests/firestore.rules.test.cjs`: PASS
- `node --check tests/phase8-static-checks.cjs`: PASS
- `npm run test:static`: PASS

## Not yet verified
The Firebase Emulator Suite was not run here. This package does not prove that Firestore compiles the rules or that the scoped queries succeed against the real database. Run on a development machine with Node.js, Java and network access:

```bash
npm install
npm run test:static
npm run test:rules
```

Before production deployment, test real ABU profile field names, the required composite indexes, legacy announcement records, moderator revocation, and notification fan-out with separate accounts. Do not deploy these rules until emulator tests pass.
