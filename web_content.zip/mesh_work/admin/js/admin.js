(function(){
  "use strict";
  function $(s){return document.querySelector(s)}
  function msg(t,error){var el=$("#loginMessage");el.className=error?"error":"notice";el.textContent=t}
  function showApp(p){
    adminLocked=false;try{localStorage.removeItem('meshAdminLocked')}catch(e){}
    window.ADMIN_STATE={user:ADMIN_FB.auth.currentUser,profile:p,selectedUniversityId:(window.ADMIN_STATE&&window.ADMIN_STATE.selectedUniversityId)||""};
    $("#login").style.display="none";
    $("#adminApp").classList.add("visible");
    $("#adminEmailText").textContent=p.email||"";
    $("#adminAvatar").textContent=(p.name||p.email||"A").charAt(0).toUpperCase();
    if(window.MESH_ADMIN) window.MESH_ADMIN.refresh("dashboard");
    installAdminAlertBar();
    var isSuper=["super_admin","super-admin","superadmin"].includes(String(p.role||"").toLowerCase());
    var pilotModal=document.getElementById("admin-pilot-code-modal");
    if(isSuper){if(pilotModal)pilotModal.hidden=true;}else{setupExistingAdminPilotGate(p);}
    var distributionCard=document.getElementById("studentsByUniversityCard");if(distributionCard)distributionCard.style.display=isSuper?"":"none";
    // System diagnostics expose role and permission details; show them only to Super Admins.
    var healthPanel=document.querySelector('#page-dashboard .system-health');
    if(healthPanel){healthPanel.hidden=!isSuper;healthPanel.style.display=isSuper?'':'none';}
    var scopeSelect=document.querySelector('#activeUniversitySelect');if(scopeSelect){scopeSelect.style.display=isSuper?'':'none';scopeSelect.innerHTML='<option value="">All universities</option>';if(isSuper){ADMIN_FB.db.collection('universities').where('active','==',true).get().then(function(s){s.docs.forEach(function(d){var o=document.createElement('option');o.value=d.id;o.textContent=d.data().name||d.id;scopeSelect.appendChild(o)});scopeSelect.onchange=function(){window.ADMIN_STATE.selectedUniversityId=this.value||'';if(window.MESH_ADMIN){window.MESH_ADMIN.refresh('users');window.MESH_ADMIN.refresh('content')}}})}}
    document.querySelectorAll('.admin-nav [data-page="academic"],.admin-nav [data-page="admins"],.admin-nav [data-page="requests"],.admin-nav [data-page="settings"],.admin-nav [data-page="audit"],.admin-nav [data-page="features"],.admin-nav [data-page="invites"],.admin-nav [data-page="verification"]').forEach(function(el){el.style.display=isSuper?"":"none";});
    document.querySelectorAll('.control-card[data-page="academic"],.control-card[data-page="admins"]').forEach(function(el){el.style.display=isSuper?'':'none';});
    var commandTrigger=document.querySelector('#commandSearch');if(commandTrigger)commandTrigger.style.display='';
    if(!isSuper){var title=document.querySelector('#pageTitle');if(title)title.textContent=(p.universityName||'University')+' workspace';}
  }
  function nav(){
    document.querySelectorAll("[data-page]").forEach(function(b){
      b.addEventListener("click",function(){
        var page=b.dataset.page;
        var role=String(window.ADMIN_STATE&&window.ADMIN_STATE.profile&&window.ADMIN_STATE.profile.role||'').toLowerCase();var isSuper=['super_admin','super-admin','superadmin'].includes(role);var restricted=['academic','admins','requests','settings','audit','features','invites','verification'];if(restricted.includes(page)&&!isSuper){var notice=document.querySelector('#loginMessage');if(notice){notice.className='error';notice.textContent='This workspace action is available to Super Admins only.';}return;}
        document.querySelectorAll(".page").forEach(function(x){x.classList.remove("active")});
        var target=document.querySelector("#page-"+page); if(target)target.classList.add("active");
        document.querySelectorAll(".admin-nav [data-page]").forEach(function(x){x.classList.toggle("active",x.dataset.page===page)});
        $("#pageTitle").textContent=page.charAt(0).toUpperCase()+page.slice(1);
        if(window.MESH_ADMIN) window.MESH_ADMIN.refresh(page);
        document.querySelector(".sidebar")?.classList.remove("mobile-open");document.querySelector("#sidebarBackdrop")?.classList.remove("visible");
        if(b.dataset.quickAcademic){setTimeout(function(){if(window.ADMIN_ACADEMIC)window.ADMIN_ACADEMIC.open(b.dataset.quickAcademic)},60)}
      });
    });
  }
  function setupExistingAdminPilotGate(profile){
    var modal=document.getElementById('admin-pilot-code-modal'),form=document.getElementById('adminPilotCodeForm'),input=document.getElementById('adminPilotCodeInput'),hint=document.getElementById('adminPilotCodeHint'),btn=form&&form.querySelector('button[type="submit"]');
    if(!modal||!form||!input||!profile||profile.inviteCodeUsed)return;
    if(["super_admin","super-admin","superadmin"].includes(String(profile.role||"").toLowerCase())){modal.hidden=true;return;}
    modal.hidden=false;
    // The Super Admin must be able to open the invite-code generator to create a code.
    // Allow a setup-only skip for this role to avoid locking the person who administers the pilot out.
    if(['super_admin','super-admin','superadmin'].includes(String(profile.role||'').toLowerCase())){var skip=document.createElement('button');skip.type='button';skip.className='secondary';skip.textContent='Continue to dashboard setup';skip.style.marginTop='8px';skip.addEventListener('click',function(){modal.hidden=true;msg('You can redeem a pilot code later from the dashboard. Your Super Admin role is unchanged.',false)});form.appendChild(skip);}
    input.addEventListener('input',function(){var raw=input.value.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g,'').slice(0,10);input.value=raw.length>5?raw.slice(0,5)+'-'+raw.slice(5):raw;if(!input.value){hint.textContent='Format: XXXXX-XXXXX';hint.style.color='';return;}if(input.value.length===11&&/^[A-HJ-NP-Z2-9]{5}-[A-HJ-NP-Z2-9]{5}$/.test(input.value)){hint.textContent='✓ Format looks correct. We will check the code.';hint.style.color='#168653';}else{hint.textContent='Keep typing: XXXXX-XXXXX';hint.style.color='';}});
    form.addEventListener('submit',async function(e){e.preventDefault();var code=input.value.trim().toUpperCase();if(!/^[A-HJ-NP-Z2-9]{5}-[A-HJ-NP-Z2-9]{5}$/.test(code)){hint.textContent='Incorrect format. Use XXXXX-XXXXX.';hint.style.color='#c62f43';return;}btn.disabled=true;btn.textContent='Checking…';try{var db=ADMIN_FB.db,user=ADMIN_FB.auth.currentUser,inviteRef=db.collection('inviteCodes').doc(code),adminRef=db.collection('admins').doc(user.uid);await db.runTransaction(async function(tx){var invite=await tx.get(inviteRef);if(!invite.exists)throw new Error('This pilot code was not found.');var d=invite.data()||{};if(d.active!==true)throw new Error('This pilot code is disabled.');if(d.used===true)throw new Error('This pilot code has already been redeemed.');if(d.expiresAt&&d.expiresAt.toDate&&d.expiresAt.toDate()<new Date())throw new Error('This pilot code has expired.');tx.update(inviteRef,{used:true,usedBy:user.uid,usedByEmail:user.email||'',usedByName:user.displayName||profile.name||profile.fullName||'',usedAt:firebase.firestore.FieldValue.serverTimestamp()});tx.update(adminRef,{inviteCodeUsed:code,pilotAccessGranted:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});});modal.hidden=true;profile.inviteCodeUsed=code;profile.pilotAccessGranted=true;msg('Pilot code accepted. Your existing admin role and account have been preserved.',false);}catch(err){console.error('Admin pilot-code redemption failed',err);hint.textContent=err.message||'Could not redeem this code. Please try again.';hint.style.color='#c62f43';}finally{btn.disabled=false;btn.textContent='Redeem code';}});
  }

  var adminLocked=false, lockTimer=null;
  function lockAdminSession(){var app=document.getElementById('adminApp'),login=document.getElementById('login');if(!app||!app.classList.contains('visible')||adminLocked)return;adminLocked=true;try{localStorage.setItem('meshAdminLocked','1')}catch(e){}app.classList.remove('visible');if(login){login.style.display='';var msgEl=document.getElementById('loginMessage');if(msgEl){msgEl.className='notice';msgEl.textContent='Admin workspace locked because the app went to the background. Sign in again to continue.';}var email=document.getElementById('adminEmail');if(email&&window.ADMIN_STATE&&window.ADMIN_STATE.profile)email.value=window.ADMIN_STATE.profile.email||'';} }
  document.addEventListener('visibilitychange',function(){if(document.hidden){lockTimer=window.setTimeout(lockAdminSession,900);}else if(lockTimer){window.clearTimeout(lockTimer);lockTimer=null;}});
  window.addEventListener('pagehide',lockAdminSession);
  function installAdminAlertBar(){var old=document.getElementById("mesh-admin-alert-bar");if(old)old.remove();}
  document.addEventListener("DOMContentLoaded",function(){
    nav();
    $("#loginForm").addEventListener("submit",async function(e){
      e.preventDefault();var btn=e.submitter;btn.disabled=true;btn.textContent="Signing in...";
      try{var p=await ADMIN_AUTH.login($("#adminEmail").value.trim(),$("#adminPassword").value);showApp(p)}
      catch(err){console.error(err);msg(err.message||"Unable to sign in.",true)}
      finally{btn.disabled=false;btn.textContent="Sign in to dashboard"}
    });
    $("#resetPassword").addEventListener("click",async function(){
      var email=$("#adminEmail").value.trim();if(!email)return msg("Enter your email first.",true);
      try{await ADMIN_FB.auth.sendPasswordResetEmail(email);msg("Password reset email sent. Check your inbox.")}
      catch(e){msg(e.message,true)}
    });
    $("#googleAdmin").addEventListener("click",async function(){
      try{var provider=new firebase.auth.GoogleAuthProvider();var r=await ADMIN_FB.auth.signInWithPopup(provider);var p=await ADMIN_AUTH.ensureBootstrap(r.user);if(!p||p.active===false){await ADMIN_FB.auth.signOut();throw new Error("You are not assigned to the MESH admin workspace.")}showApp(p)}catch(e){msg(e.message||"Google sign-in failed.",true)}
    });
    $("#logout").addEventListener("click",function(){ADMIN_AUTH.logout().then(function(){location.reload()})});
    $("#closeModal").onclick=function(){$("#modal").classList.remove("open")};
    $("#modal").addEventListener("click",function(e){if(e.target.id==="modal")e.currentTarget.classList.remove("open")});
    var addContentButton=document.querySelector("[data-add-content]");if(addContentButton)addContentButton.addEventListener("click",function(){if(window.ADMIN_CONTENT)window.ADMIN_CONTENT.open();else alert("Content module did not load. Refresh the admin panel and check the browser console.")});
    var quickPublish=document.querySelector('.control-card[data-page="content"]');if(quickPublish)quickPublish.addEventListener("click",function(){setTimeout(function(){if(window.ADMIN_CONTENT)window.ADMIN_CONTENT.open()},80)});
    $("[data-add-admin]").onclick=function(){ADMIN_ADMINS.add()};
    $("[data-seed]").onclick=async function(){
      var btn=$("[data-seed]");btn.disabled=true;btn.textContent="Initializing...";
      var universities=[
        ["unilag","University of Lagos","UNILAG"],["ui","University of Ibadan","UI"],["oau","Obafemi Awolowo University","OAU"],["unn","University of Nigeria, Nsukka","UNN"],["uniben","University of Benin","UNIBEN"],["unilorin","University of Ilorin","UNILORIN"],["uniport","University of Port Harcourt","UNIPORT"],["lasu","Lagos State University","LASU"],["buk","Bayero University Kano","BUK"],["unical","University of Calabar","UNICAL"]
      ];
      var levels=[["100","100 Level",1],["200","200 Level",2],["300","300 Level",3],["400","400 Level",4],["500","500 Level",5],["600","600 Level",6]];
      var interests=[["technology","Technology","ri-code-s-slash-line"],["business","Business","ri-briefcase-line"],["design","Design","ri-palette-line"],["entrepreneurship","Entrepreneurship","ri-lightbulb-line"],["sports","Sports","ri-football-line"],["music","Music","ri-music-2-line"],["career","Career","ri-rocket-line"],["academics","Academics","ri-book-open-line"]];
      try{
        for(var i=0;i<universities.length;i++)await ADMIN_FB.db.collection("universities").doc(universities[i][0]).set({name:universities[i][1],code:universities[i][2],active:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
        for(var j=0;j<levels.length;j++)await ADMIN_FB.db.collection("levels").doc(levels[j][0]).set({name:levels[j][1],order:levels[j][2],active:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
        for(var k=0;k<interests.length;k++)await ADMIN_FB.db.collection("interests").doc(interests[k][0]).set({name:interests[k][1],icon:interests[k][2],active:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
        alert("Starter catalog initialized. Add faculties and departments from Academic Data.");
        if(window.MESH_ADMIN)window.MESH_ADMIN.refresh("academic");
      }catch(e){alert(e.message||"Starter catalog failed.")}finally{btn.disabled=false;btn.textContent="Initialize starter catalog"}
    };
    function closeMobileSidebar(){var sb=document.querySelector(".sidebar"),bd=document.querySelector("#sidebarBackdrop");if(sb)sb.classList.remove("mobile-open");if(bd)bd.classList.remove("visible");var trigger=document.querySelector("#mobileMenu");if(trigger)trigger.setAttribute("aria-expanded","false");}
    function toggleMobileSidebar(){var sb=document.querySelector(".sidebar"),bd=document.querySelector("#sidebarBackdrop");if(!sb)return;var opening=!sb.classList.contains("mobile-open");sb.classList.toggle("mobile-open",opening);if(bd)bd.classList.toggle("visible",opening);var trigger=document.querySelector("#mobileMenu");if(trigger)trigger.setAttribute("aria-expanded",String(opening));}
    var menuButton=document.querySelector("#mobileMenu");if(menuButton){menuButton.setAttribute("aria-label","Open navigation menu");menuButton.setAttribute("aria-expanded","false");menuButton.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();toggleMobileSidebar();});}
    var backdrop=document.querySelector("#sidebarBackdrop");if(backdrop)backdrop.addEventListener("click",closeMobileSidebar);
    document.addEventListener("click",function(e){var sb=document.querySelector(".sidebar"),trigger=document.querySelector("#mobileMenu");if(sb&&sb.classList.contains("mobile-open")&&!sb.contains(e.target)&&trigger&&!trigger.contains(e.target)&&e.target!==backdrop)closeMobileSidebar();});
    ADMIN_FB.auth.onAuthStateChanged(async function(user){
      if(!user)return;
      try{var locked=false;try{locked=localStorage.getItem('meshAdminLocked')==='1'}catch(e){}if(locked){var login=document.getElementById('login'),app=document.getElementById('adminApp'),msgEl=document.getElementById('loginMessage');if(login)login.style.display='';if(app)app.classList.remove('visible');if(msgEl){msgEl.className='notice';msgEl.textContent='Admin workspace locked. Sign in again to continue.';}var email=document.getElementById('adminEmail');if(email)email.value=user.email||'';return;}var p=await ADMIN_AUTH.ensureBootstrap(user);if(p&&p.active!==false)showApp(p)}catch(e){console.error(e)}
    });
  });
  window.MESH_ADMIN={refresh:async function(page){
    page=page||"dashboard";
    try{
      if(page==="dashboard")await ADMIN_DASHBOARD.refresh();
      if(page==="academic")await ADMIN_ACADEMIC.render();
      if(page==="content")await ADMIN_CONTENT.render();
      if(page==="users")await ADMIN_USERS.render();
      if(page==="admins")await ADMIN_ADMINS.render();
      if(page==="requests")await ADMIN_REQUESTS.render();
      if(page==="community")await ADMIN_COMMUNITY.render();
      if(page==="support")await ADMIN_SUPPORT.render();
      if(page==="audit"&&window.MESH_ADMIN_COMMANDS)await window.MESH_ADMIN_COMMANDS.loadAudit();
      if(page==="features"&&window.MESH_ADMIN_COMMANDS)await window.MESH_ADMIN_COMMANDS.loadFeatures();
      if(page==="invites"&&window.MESH_PILOT_ADMIN)await window.MESH_PILOT_ADMIN.renderInvites();
      if(page==="verification"&&window.MESH_PILOT_ADMIN)await window.MESH_PILOT_ADMIN.renderVerification();
      if(page==="reports"&&window.MESH_PILOT_ADMIN)await window.MESH_PILOT_ADMIN.renderReports();
    }catch(e){console.error(e)}
  }};
})();
