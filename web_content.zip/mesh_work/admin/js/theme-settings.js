/* Super-admin global theme editor. Uses appSettings/globalTheme in Firestore. */
(function () {
  "use strict";
  var DEFAULTS = { primary: "#2457D6", secondary: "#3B82F6", brandDark: "#102A56", background: "#F4F7FF", surface: "#FFFFFF", text: "#14213D", mutedText: "#64748B", border: "#D9E2F2" };
  var LABELS = { primary: "Primary brand color", secondary: "Secondary accent", brandDark: "Dark brand / headings", background: "Page background", surface: "Cards and surfaces", text: "Primary text", mutedText: "Muted text", border: "Borders and dividers" };
  var PRESETS = {
    mesh: DEFAULTS,
    ocean: { primary: "#1677D2", secondary: "#28A6D8", brandDark: "#10385C", background: "#F2F8FD", surface: "#FFFFFF", text: "#17344C", mutedText: "#62788A", border: "#D7E5F0" },
    violet: { primary: "#7654D6", secondary: "#9A7BED", brandDark: "#35215F", background: "#F7F5FC", surface: "#FFFFFF", text: "#302644", mutedText: "#777087", border: "#E5DFF1" },
    sunset: { primary: "#E45D4F", secondary: "#F18B65", brandDark: "#6D2F2B", background: "#FFF7F3", surface: "#FFFFFF", text: "#472D2A", mutedText: "#8A706B", border: "#F0DDD7" },
    midnight: { primary: "#5B8CFF", secondary: "#67C7D4", brandDark: "#111827", background: "#EDF1F8", surface: "#FFFFFF", text: "#1F2937", mutedText: "#64748B", border: "#D5DCE8" },
    forest: { primary: "#287A52", secondary: "#68A77B", brandDark: "#183F2C", background: "#F3F8F3", surface: "#FFFFFF", text: "#203B2A", mutedText: "#667B6B", border: "#D8E5D9" }
  };
  var current = Object.assign({}, DEFAULTS), db, initialized = false;
  function $(selector) { return document.querySelector(selector); }
  function validHex(value) { return /^#[0-9a-fA-F]{6}$/.test(String(value || "")); }
  function escapeHtml(value) { return String(value).replace(/[&<>"']/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]; }); }
  function setStatus(message, type) { var el = $("#themeStatus"); if (el) { el.textContent = message; el.className = "theme-status" + (type ? " " + type : ""); } }
  function fields() {
    var host = $("#themeColorFields"); if (!host) return;
    host.innerHTML = Object.keys(LABELS).map(function (key) { return '<div class="theme-color-field"><label for="theme-' + key + '">' + LABELS[key] + '</label><div class="theme-color-inputs"><input type="color" id="theme-' + key + '" data-theme-key="' + key + '" value="' + current[key] + '" aria-label="Choose ' + LABELS[key] + '"><input type="text" data-theme-hex="' + key + '" value="' + current[key] + '" maxlength="7" spellcheck="false" aria-label="HEX value for ' + LABELS[key] + '" pattern="^#[0-9a-fA-F]{6}$"></div></div>'; }).join("");
    host.querySelectorAll("[data-theme-key]").forEach(function (input) { input.addEventListener("input", function () { var key = input.dataset.themeKey, hex = host.querySelector('[data-theme-hex="' + key + '"]'); if (hex) hex.value = input.value.toUpperCase(); current[key] = input.value.toUpperCase(); preview(); }); });
    host.querySelectorAll("[data-theme-hex]").forEach(function (input) { input.addEventListener("input", function () { var key = input.dataset.themeHex, value = input.value.trim(); if (!validHex(value)) { input.classList.add("invalid"); return; } input.classList.remove("invalid"); current[key] = value.toUpperCase(); var picker = host.querySelector('[data-theme-key="' + key + '"]'); if (picker) picker.value = current[key]; preview(); }); });
  }
  function preview() {
    var el = $("#themePreviewApp"); if (!el) return;
    el.style.setProperty("--preview-primary", current.primary); el.style.setProperty("--preview-secondary", current.secondary); el.style.setProperty("--preview-dark", current.brandDark); el.style.setProperty("--preview-bg", current.background); el.style.setProperty("--preview-surface", current.surface); el.style.setProperty("--preview-text", current.text); el.style.setProperty("--preview-muted", current.mutedText); el.style.setProperty("--preview-border", current.border);
  }
  function loadColors(colors) { current = Object.assign({}, DEFAULTS, colors || {}); Object.keys(current).forEach(function (k) { if (!validHex(current[k])) current[k] = DEFAULTS[k]; }); var preset = $("#themePreset"); if (preset) preset.value = Object.keys(PRESETS).find(function (name) { return Object.keys(DEFAULTS).every(function (k) { return PRESETS[name][k].toLowerCase() === current[k].toLowerCase(); }); }) || "custom"; fields(); preview(); }
  async function load() {
    if (!window.ADMIN_FB || !ADMIN_FB.db) { setStatus("Firebase is not ready. Refresh the admin dashboard.", "error"); return; }
    db = ADMIN_FB.db;
    try { var snap = await db.collection("appSettings").doc("globalTheme").get(); var saved = snap.exists && snap.data().colors ? snap.data().colors : null; var legacy = saved && ["#079B65", "#10B981", "#19E68C"].indexOf(String(saved.primary || "").toUpperCase()) >= 0 && ["#064E3B", "#0B0D0E"].indexOf(String(saved.brandDark || "").toUpperCase()) >= 0; loadColors(legacy ? DEFAULTS : (saved || DEFAULTS)); initialized = true; setStatus(legacy ? "The previous emerald default was retired. Royal Blue is loaded as a preview; save to publish it globally." : (snap.exists ? "Loaded the currently published global theme." : "No saved theme yet. The default MESH Royal Blue palette is active.")); }
    catch (e) { console.error("Theme load failed", e); setStatus("Could not load saved theme. Check Firestore rules and your admin access.", "error"); }
  }
  async function save() {
    if (!initialized || !db) { setStatus("Theme settings are not ready yet. Try again in a moment.", "error"); return; }
    var profile = window.ADMIN_STATE && window.ADMIN_STATE.profile;
    if (!profile || !["super_admin", "super-admin", "superadmin"].includes(profile.role)) { setStatus("Only a Super Admin can publish global theme changes.", "error"); return; }
    var invalid = Array.from(document.querySelectorAll("[data-theme-hex]")).find(function (input) { return !validHex(input.value.trim()); });
    if (invalid) { invalid.focus(); setStatus("Enter valid 6-digit HEX colors, such as #079B65.", "error"); return; }
    var btn = $("#themeSave"); if (btn) { btn.disabled = true; btn.textContent = "Saving…"; }
    try {
      await db.collection("appSettings").doc("globalTheme").set({ colors: current, updatedAt: firebase.firestore.FieldValue.serverTimestamp(), updatedBy: (profile.email || (window.ADMIN_STATE.user && window.ADMIN_STATE.user.uid) || "admin"), version: 1 }, { merge: true });
      try { localStorage.setItem("meshGlobalThemeCache", JSON.stringify(current)); } catch (e) {}
      setStatus("Global theme saved. Members and admins will receive the new colors from Firebase.", "success");
    } catch (e) { console.error("Theme save failed", e); setStatus(e.code === "permission-denied" ? "Firebase denied this change. Confirm you are a Super Admin and publish the updated Firestore rules." : (e.message || "Could not save theme."), "error"); }
    finally { if (btn) { btn.disabled = false; btn.textContent = "Save global theme"; } }
  }
  function bind() {
    var preset = $("#themePreset"); if (preset) preset.addEventListener("change", function () { if (PRESETS[preset.value]) loadColors(PRESETS[preset.value]); });
    var saveBtn = $("#themeSave"); if (saveBtn) saveBtn.addEventListener("click", save);
    var resetBtn = $("#themeReset"); if (resetBtn) resetBtn.addEventListener("click", function () { loadColors(DEFAULTS); setStatus("Default MESH palette loaded as a preview. Save to publish it."); });
    document.querySelectorAll('.admin-nav [data-page="settings"]').forEach(function (button) { button.addEventListener("click", function () { if (!initialized) load(); }); });
    document.addEventListener("mesh:theme-changed", function (event) { if (event.detail) { /* runtime event is intentionally safe to ignore in admin editor */ } });
  }
  document.addEventListener("DOMContentLoaded", function () { bind(); load(); });
  window.MESH_THEME_ADMIN = { load: load, save: save };
})();
