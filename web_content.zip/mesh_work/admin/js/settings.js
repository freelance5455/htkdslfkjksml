(function(){
  "use strict";
  function esc(v){return String(v||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;")}

  async function render(){
    var b=document.querySelector("#adminRows");
    if(!b)return;
    try{
      var s=await ADMIN_FB.db.collection("admins").limit(100).get();
      b.innerHTML=s.docs.map(function(x){
        var d=x.data();
        return '<tr><td>'+esc(d.email||x.id)+'</td><td>'+esc(d.name||"—")+'</td><td>'+esc(d.role||"admin")+'</td><td><span class="badge '+(d.active===false?"off":"")+'">'+(d.active===false?"Disabled":"Active")+'</span></td><td><button class="icon-btn" data-toggle-admin="'+x.id+'" title="Toggle access"><i class="ri-toggle-line"></i></button></td></tr>';
      }).join("")||'<tr><td colspan="5"><div class="empty">No admins assigned.</div></td></tr>';
      b.querySelectorAll("[data-toggle-admin]").forEach(function(btn){
        btn.onclick=function(){toggleAdmin(btn.dataset.toggleAdmin)};
      });
    }catch(e){
      console.error(e);
      b.innerHTML='<tr><td colspan="5"><div class="empty">Unable to load admin accounts.</div></td></tr>';
    }
  }

  async function toggleAdmin(uid){
    try{
      var ref=ADMIN_FB.db.collection("admins").doc(uid),snap=await ref.get();
      if(!snap.exists)return;
      var d=snap.data();
      if(window.ADMIN_STATE&&uid===ADMIN_STATE.user.uid&&d.active!==false){
        alert("You cannot disable your own active admin account.");
        return;
      }
      await ref.update({active:d.active===false,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
      await render();
    }catch(e){alert(e.message||"Unable to update admin access.")}
  }

  async function addAdmin(){
    var m=document.querySelector("#modal"),b=document.querySelector("#modalBody");
    document.querySelector("#modalTitle").textContent="Assign admin";
    b.innerHTML='<form id="adminForm" novalidate><div class="field"><label>MESH account email</label><input name="email" type="email" required placeholder="person@example.com"><small class="field-hint">The person must already have a normal MESH account.</small></div><div class="field"><label>Role</label><select name="role"><option value="university_admin">University Admin</option><option value="content_manager">Content Manager</option><option value="moderator">Community Moderator</option><option value="super_admin">Super Admin</option></select></div><div class="field"><label>Assigned university (required except Super Admin)</label><select name="universityId"><option value="">Select university</option></select></div><p class="error" id="adminFormError" role="alert" style="display:none;padding:10px;border-radius:10px"></p><button class="secondary" type="button" id="findAdminAccount">Find MESH account</button> <button class="primary" type="submit">Assign access</button></form>';
    var form=b.querySelector("form"),emailInput=form.querySelector('[name="email"]'),uniSelect=form.querySelector('[name="universityId"]'),error=form.querySelector('#adminFormError');
    try{var unis=await ADMIN_FB.db.collection("universities").limit(500).get();unis.docs.filter(d=>d.data().active!==false).forEach(function(d){var o=document.createElement("option");o.value=d.id;o.textContent=d.data().name||d.id;uniSelect.appendChild(o);});}catch(e){showError(e.message)}
    form.querySelector('[name="role"]').addEventListener('change',function(){uniSelect.required=this.value!=="super_admin";});uniSelect.required=true;
    async function resolve(){var email=emailInput.value.trim().toLowerCase();if(!email)throw new Error('Enter the account email first.');var snap=await ADMIN_FB.db.collection('users').where('email','==',email).limit(2).get();if(snap.empty)throw new Error('No MESH user record matches this email. The person must sign in to the main app first.');form.dataset.uid=snap.docs[0].id;form.dataset.email=email;return snap.docs[0].id;}
    function showError(message){error.textContent=message;error.style.display='block'}
    form.querySelector('#findAdminAccount').addEventListener('click',async function(){error.style.display='none';try{var uid=await resolve();showError('Account found. UID: '+uid+'. Choose the role and university, then tap Assign access.');error.className='notice'}catch(e){error.className='error';showError(e.code==='permission-denied'?'Firebase denied the user lookup. Publish the updated Firestore Rules and confirm this account is an active Super Admin. Details: '+e.message:e.message)}});
    form.addEventListener('submit',async function(e){e.preventDefault();var btn=form.querySelector('[type="submit"]');btn.disabled=true;error.style.display='none';try{var uid=form.dataset.uid;if(!uid||form.dataset.email!==emailInput.value.trim().toLowerCase())uid=await resolve();var fd=new FormData(form),role=String(fd.get('role')),universityId=String(fd.get('universityId')||'');if(role!=='super_admin'&&!universityId)throw new Error('Select the university this admin will manage.');var universityName=role==='super_admin'?'':(uniSelect.options[uniSelect.selectedIndex]?uniSelect.options[uniSelect.selectedIndex].text:'');await ADMIN_FB.db.collection('admins').doc(uid).set({uid:uid,email:emailInput.value.trim().toLowerCase(),role:role,universityId:role==='super_admin'?null:universityId,universityName:universityName,active:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});m.classList.remove('open');await render();}catch(e){console.error('Assign admin failed',e);error.className='error';showError(e.code==='permission-denied'?'Firebase denied admin assignment. Check Super Admin role and Firestore Rules. Details: '+e.message:e.message||'Unable to assign admin access.')}finally{btn.disabled=false;}});
    m.classList.add("open");
  }

  window.ADMIN_ADMINS={render:render,add:addAdmin,toggle:toggleAdmin};
})();
