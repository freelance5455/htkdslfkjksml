# MESH Information-First — Phase 10: Release Preparation & Final Audit

## Changes in this phase

- Tightened `storage.rules` for `/resources/{universityId}/{fileName}`: create, overwrite, and delete now require an active Super Admin or an active admin role assigned to the same university encoded in the object path. A university admin cannot write into another university's resource folder merely because they have an admin record.
- Kept profile-picture writes limited to the authenticated owner's path and image content types, with a 5 MiB limit.
- Kept verification-proof writes limited to the authenticated owner's path, image/PDF content types, and a 5 MiB limit; Super Admin role aliases are recognized for review/deletion.
- Added `tests/phase10-release-checks.cjs` and included it in `npm run test:static` to guard Storage scoping, existing profile/notification checks, and Firebase configuration.
- Preserved the existing Firebase project configuration and did not deploy rules or functions.

## Validation performed in this workspace

- JavaScript syntax checks for the touched/related source and test files.
- All Phase 5–10 static checks.
- Firebase configuration/package JSON parsing.
- ZIP integrity after packaging.

Static checks inspect source text and configuration. They do **not** prove Firebase Rules compile or behave correctly at runtime. Firebase CLI/emulator execution and live Firebase access were not available in this workspace; therefore no emulator or production test is claimed.

## Release status: NOT CLEARED FOR PUBLIC LAUNCH

The package is prepared for staging, not certified for production. The existing V1 audit still contains unresolved risks requiring explicit product/data-model decisions and runtime tests:

1. **Support tickets:** the current document schema does not include a dependable university assignment, while admin UI behavior appears Super-Admin-oriented. Decide whether tickets are central-only or university-scoped, then enforce and test that model.
2. **Community counters:** legacy `/communityPosts` rules allow signed-in users to set `likeCount` / `commentCount`. Move counter updates to trusted code or redesign the data model before relying on those counters for analytics.
3. **Legacy/shared notifications:** preserve intended legacy broadcast behavior while verifying query and rule combinations in the Emulator. Per-user notifications must remain private to their recipient.
4. **Publishing reliability:** announcement creation precedes notification fan-out. A fan-out failure can leave a published announcement even if the callable returns an error. Add durable retry/idempotency before treating delivery as production-reliable.
5. **Runtime security tests:** run Firestore and Storage Rules Unit Testing with emulator-backed fixtures for Super Admin, university admin, student, and cross-university access.
6. **Full regression:** verify authentication/recovery, pilot-code redemption, moderator assignment/revocation, scoped publishing, comments, notifications, admin CSV exports, theme changes, resource uploads, and the member app on Android.

## Suggested staging sequence

```sh
npm install
npm run test:static
npm run test:rules
```

Then run Storage Rules tests in an Emulator Suite or a separate staging Firebase project, inspect every failed case, and deploy only after review. Do not deploy this ZIP directly to production without that stage.
