# MESH update — 14 October 2026

## Included source changes
- Member Firebase Auth persistence is set to LOCAL, so members remain signed in until they sign out.
- Google sign-in uses Firebase redirect flow, which is more compatible with Android WebViews than popup auth.
- Signup now asks for a username and explains that the username/posts are visible to MESH members. Student feed post/comment author labels use usernames.
- Onboarding writes academic selections to the existing profile; the profile updater no longer permits university changes from the edit-profile path, and Firestore rules allow initial university assignment but reject changing it after assignment.
- Password-reset emails use an explicit return URL; email delivery still depends on Firebase Authentication templates, authorized domains, the account's sign-in provider, and the recipient's mail filtering.
- Help/support form guards missing DOM elements and shows actionable send errors.
- Feed reaction/comment counts are derived from the corresponding subcollections while loading the feed.
- Notifications support per-user read state, department scoping, expansion, and navigation to the related post.
- Added terms/community rules content and a Nigerian state/FCT dropdown for university requests.
- Admin workspace locks after the app is backgrounded/page hidden; explicit reauthentication is required to reopen it. Added an always-visible admin alert strip, audit events for page/button actions, and an all-member-post review page with post removal and author notification.
- Student verification page includes a pilot/university code redemption history table.
- Added client-side blocked-content warning/alert and a server-side Cloud Function trigger for additional blocking and department-scoped post notifications.

## Important deployment requirements and limits
- Replace the hosted static app with these files and publish `firestore.rules` in Firebase Console.
- The `processMeshPost` Cloud Function is source code only. Department notifications and the server-side moderation backstop will not run until Cloud Functions are deployed. Cloud Functions deployment may require a billing-enabled Firebase/Google Cloud project. Do not deploy without reviewing the project's plan and costs.
- Browser-side keyword filtering is only a first-pass safeguard, not a complete moderation system. It can miss coded/obfuscated content and can flag contextually legitimate text. A proper review workflow is still needed.
- Google redirect sign-in supports existing Google-linked accounts. First-time Google registration still needs a complete invite-code/username onboarding path before it should be treated as production-ready.
- Firebase password reset can report that a request was accepted without guaranteeing delivery. Check Authentication > Templates, authorized domains, sender configuration, and spam folders if no message arrives.
- CSV export provides a normal fallback download link for browsers/WebViews that block programmatic downloads; the host browser controls the actual save location.
- Admin audit events are client-originated operational records, not tamper-proof forensic audit logs. Trusted server-side audit triggers are recommended for production.
- Firebase rules have not been compiled by the Firebase CLI/rules simulator, and this bundle has not been deployed or tested against live Firebase. Run emulator/simulator tests before publishing the rules.
