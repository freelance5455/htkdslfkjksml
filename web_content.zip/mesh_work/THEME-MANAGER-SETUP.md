# MESH Global Theme Manager

## What changed
- Added **Settings → Theme & brand colors** to the admin dashboard.
- Includes six starter palettes, eight editable color tokens, native color pickers, HEX inputs, live preview, reset-to-default, and Save global theme.
- Theme is stored in Firestore at `appSettings/globalTheme` and watched by the student app in real time.
- The theme runtime maps saved colors to the shared MESH CSS variables so components using the shared design tokens update together.
- Firestore rules allow signed-in users to read only the `globalTheme` settings document; only an active Super Admin can write it.

## Required deployment step
Publish the updated `firestore.rules` to the Firebase project. Until these rules are published, saving the theme can fail with `permission-denied`. The app safely falls back to the default MESH palette if the theme document is absent or cannot be read.

## Notes
- Theme colors are global across members and admins on devices where the app is running and signed in. The student app uses a Firestore snapshot listener, so published changes update without a manual CSS edit.
- The admin editor intentionally restricts publishing to `super_admin`, `super-admin`, or `superadmin` profiles. Existing admin roles and other project behavior are left in place.
- Existing CSS that hardcodes a literal color instead of using shared variables will not automatically inherit theme colors; migrate those isolated styles to the shared CSS variables as needed for complete coverage.
