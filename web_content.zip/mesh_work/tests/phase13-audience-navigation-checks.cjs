'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const html = read('index.html');
const campus = read('js/campus-news.js');
const nav = [...html.matchAll(/<nav class="bottom-nav" aria-label="Main navigation">([\s\S]*?)<\/nav>/g)].map(m => m[1]);
assert.ok(nav.length >= 4, 'existing bottom navigation is retained across screens');
for (const n of nav) {
  assert.match(n, /data-nav="home"[^>]*>[\s\S]*?<span>Home<\/span>/);
  assert.match(n, /data-nav="campus-news"[^>]*>[\s\S]*?<span>Updates<\/span>/);
  assert.match(n, /data-nav="notifications"[^>]*>[\s\S]*?<span>Alerts<\/span>/);
  assert.match(n, /data-nav="profile"[^>]*>[\s\S]*?<span>Profile<\/span>/);
}
const updates = html.slice(html.indexOf('id="campus-news"'), html.indexOf('id="discover"'));
assert.match(updates, /data-campus-scope="university"/, 'University-wide announcement shortcut is available');
assert.match(updates, /data-campus-scope="faculty"/, 'Faculty announcement shortcut is available');
assert.match(updates, /data-campus-scope="department"/, 'Department announcement shortcut is available');
assert.match(updates, /data-campus-scope="class"/, 'Level/class announcement shortcut is available');
assert.doesNotMatch(updates, /data-campus-scope-filter=/, 'Updates no longer shows a second audience filter row');
assert.match(updates, /data-campus-category="academic"/);
assert.match(updates, /data-campus-category="timetable"/);
assert.match(campus, /normalizeCategory\(x.category\)===category/);
console.log('Phase 13 audience/navigation checks: PASS');
console.log('Four primary navigation destinations remain; Updates has separate audience cards, clean topic categories, and a filtered feed.');
