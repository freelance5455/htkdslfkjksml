'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const storage = read('storage.rules');
const firestore = read('firestore.rules');
const config = JSON.parse(read('firebase.json'));
const pkg = JSON.parse(read('package.json'));
const functionsPkg = JSON.parse(read('functions/package.json'));
const phase9 = read('MESH-INFORMATION-FIRST-PHASE-9.md');

// Resource Storage writes must be constrained by the university encoded in the path.
assert.match(storage, /function canManageUniversity\(universityId\)/);
assert.match(storage, /match \/resources\/{universityId}\/{fileName}/);
assert.match(storage, /allow create, update: if canManageUniversity\(universityId\)/);
assert.match(storage, /allow delete: if canManageUniversity\(universityId\)/);
assert.match(storage, /request\.resource\.size < 25 \* 1024 \* 1024/);
assert.match(storage, /request\.resource\.contentType\.matches\('image\/\.\*'\)/);
assert.match(storage, /request\.resource\.contentType == 'application\/pdf'/);

// Existing profile/notification protections and project deployment config remain present.
assert.match(firestore, /affectedKeys\(\)\.hasOnly\(\['fullName','username'/);
assert.match(firestore, /resource\.data\.uid == request\.auth\.uid/);
assert.equal(config.firestore.rules, 'firestore.rules');
assert.equal(config.storage.rules, 'storage.rules');
assert.equal(config.functions[0].runtime, 'nodejs20');
assert.ok(pkg.scripts['test:rules'].includes('tests/firestore.rules.test.cjs'));
assert.ok(functionsPkg.dependencies['firebase-admin']);
assert.ok(functionsPkg.dependencies['firebase-functions']);
assert.match(phase9, /Known release gate/);
console.log('Phase 10 release/configuration checks: PASS');
console.log('Storage cross-university authorization is statically constrained; deploy only after Storage Emulator or staging verification.');
