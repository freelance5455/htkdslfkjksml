'use strict';
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');
const { initializeTestEnvironment, assertSucceeds, assertFails } = require('@firebase/rules-unit-testing');
const { doc, getDoc, setDoc, collection, addDoc, serverTimestamp } = require('firebase/firestore');

const projectId = 'mesh-rules-staging-test';
let env;
const profile = (uid, overrides = {}) => ({ uid, fullName: uid, universityId: 'abu', facultyId: 'science', departmentId: 'computer-science', levelId: '200', ...overrides });

 test('MESH Firestore security rules', async t => {
  env = await initializeTestEnvironment({
    projectId,
    firestore: { rules: fs.readFileSync(path.join(__dirname, '..', 'firestore.rules'), 'utf8') }
  });
  try {
    await env.withSecurityRulesDisabled(async ctx => {
      const db = ctx.firestore();
      await setDoc(doc(db, 'users/student-a'), profile('student-a'));
      await setDoc(doc(db, 'users/student-b'), profile('student-b', { departmentId: 'electrical-engineering' }));
      await setDoc(doc(db, 'users/student-c'), profile('student-c', { universityId: 'other-university' }));
      await setDoc(doc(db, 'users/super-a'), profile('super-a'));
      await setDoc(doc(db, 'admins/super-a'), { active: true, role: 'super_admin' });
      await setDoc(doc(db, 'announcements/department-a'), { title: 'CS notice', message: 'Notice', universityId: 'abu', scopeType: 'department', scopeId: 'computer-science', commentsEnabled: true, active: true, status: 'published' });
      await setDoc(doc(db, 'announcements/department-closed'), { title: 'Private notice', message: 'Notice', universityId: 'abu', scopeType: 'department', scopeId: 'computer-science', commentsEnabled: false, active: true, status: 'published' });
      await setDoc(doc(db, 'announcements/department-draft'), { title: 'Draft notice', message: 'Not published', universityId: 'abu', scopeType: 'department', scopeId: 'computer-science', commentsEnabled: true, active: true, status: 'draft' });
      await setDoc(doc(db, 'announcements/department-disabled'), { title: 'Disabled notice', message: 'Disabled', universityId: 'abu', scopeType: 'department', scopeId: 'computer-science', commentsEnabled: true, active: false, status: 'published' });
      await setDoc(doc(db, 'notifications/notice-a'), { uid: 'student-a', universityId: 'abu', title: 'For A', active: true });
      await setDoc(doc(db, 'notifications/notice-b'), { uid: 'student-b', universityId: 'abu', title: 'For B', active: true });
      await setDoc(doc(db, 'communityPosts/global-a'), { title: 'Global', body: 'All MESH students', scope: 'global', published: true, likeCount: 0, commentCount: 0 });
      await setDoc(doc(db, 'communityPosts/abu-a'), { title: 'ABU only', body: 'ABU students', scope: 'university', universityId: 'abu', published: true, likeCount: 0, commentCount: 0 });
      await setDoc(doc(db, 'communityPosts/other-uni'), { title: 'Other uni', body: 'Private to another uni', scope: 'university', universityId: 'other-university', published: true, likeCount: 0, commentCount: 0 });
    });

    await t.test('student can read an announcement for their department', async () => {
      const db = env.authenticatedContext('student-a').firestore();
      await assertSucceeds(getDoc(doc(db, 'announcements/department-a')));
    });
    await t.test('student cannot read another department or another university announcement', async () => {
      const db = env.authenticatedContext('student-b').firestore();
      await assertFails(getDoc(doc(db, 'announcements/department-a')));
      const other = env.authenticatedContext('student-c').firestore();
      await assertFails(getDoc(doc(other, 'announcements/department-a')));
    });
    await t.test('students cannot read draft or disabled announcements even inside their scope', async () => {
      const db = env.authenticatedContext('student-a').firestore();
      await assertFails(getDoc(doc(db, 'announcements/department-draft')));
      await assertFails(getDoc(doc(db, 'announcements/department-disabled')));
    });
    await t.test('student can comment only when comments are enabled and cannot spoof author UID', async () => {
      const db = env.authenticatedContext('student-a').firestore();
      await assertSucceeds(addDoc(collection(db, 'announcements/department-a/comments'), {
        authorUid: 'student-a', authorName: 'Student A', body: 'When is this effective?', status: 'active', createdAt: serverTimestamp()
      }));
      await assertFails(addDoc(collection(db, 'announcements/department-a/comments'), {
        authorUid: 'student-b', authorName: 'Student B', body: 'Spoofed', status: 'active', createdAt: serverTimestamp()
      }));
      await assertFails(addDoc(collection(db, 'announcements/department-closed/comments'), {
        authorUid: 'student-a', authorName: 'Student A', body: 'Should be blocked', status: 'active', createdAt: serverTimestamp()
      }));
    });
    await t.test('notification is private to its intended user', async () => {
      const a = env.authenticatedContext('student-a').firestore();
      const b = env.authenticatedContext('student-b').firestore();
      await assertSucceeds(getDoc(doc(a, 'notifications/notice-a')));
      await assertFails(getDoc(doc(a, 'notifications/notice-b')));
      await assertSucceeds(getDoc(doc(b, 'notifications/notice-b')));
    });
    await t.test('community reactions and comments are scoped and clients cannot edit aggregate counters', async () => {
      const db = env.authenticatedContext('student-a').firestore();
      await assertSucceeds(getDoc(doc(db, 'communityPosts/global-a')));
      await assertSucceeds(getDoc(doc(db, 'communityPosts/abu-a')));
      await assertFails(getDoc(doc(db, 'communityPosts/other-uni')));
      await assertFails(setDoc(doc(db, 'communityPosts/abu-a'), { likeCount: 999 }, { merge: true }));
      await assertSucceeds(setDoc(doc(db, 'communityPosts/abu-a/likes/student-a'), { uid: 'student-a', createdAt: serverTimestamp() }));
      await assertFails(setDoc(doc(db, 'communityPosts/abu-a/likes/student-b'), { uid: 'student-b', createdAt: serverTimestamp() }));
      await assertSucceeds(setDoc(doc(db, 'communityPosts/abu-a/comments/question-a'), { uid: 'student-a', name: 'Student A', body: 'When is this?', active: true, createdAt: serverTimestamp() }));
      await assertFails(setDoc(doc(db, 'communityPosts/abu-a/comments/spoofed'), { uid: 'student-b', name: 'Student B', body: 'Spoofed author', active: true, createdAt: serverTimestamp() }));
    });
    await t.test('university community queries cannot read another university post', async () => {
      const db = env.authenticatedContext('student-c').firestore();
      await assertSucceeds(getDoc(doc(db, 'communityPosts/other-uni')));
      await assertFails(getDoc(doc(db, 'communityPosts/abu-a')));
    });
    await t.test('moderator assignment is visible only to its owner and Super Admin', async () => {
      await env.withSecurityRulesDisabled(async ctx => {
        await setDoc(doc(ctx.firestore(), 'moderatorAssignments/student-a'), { uid: 'student-a', active: true, role: 'moderator', scopeType: 'department', scopeId: 'computer-science', universityId: 'abu' });
      });
      const student = env.authenticatedContext('student-b').firestore();
      const owner = env.authenticatedContext('student-a').firestore();
      const superAdmin = env.authenticatedContext('super-a').firestore();
      await assertFails(getDoc(doc(student, 'moderatorAssignments/student-a')));
      await assertSucceeds(getDoc(doc(owner, 'moderatorAssignments/student-a')));
      await assertSucceeds(getDoc(doc(superAdmin, 'moderatorAssignments/student-a')));
    });
    await t.test('unauthenticated users cannot read scoped announcements or comments', async () => {
      const db = env.unauthenticatedContext().firestore();
      await assertFails(getDoc(doc(db, 'announcements/department-a')));
      await assertFails(getDoc(doc(db, 'announcements/department-a/comments/example-comment')));
    });
    await t.test('students cannot directly publish announcements or modify moderator assignments', async () => {
      const db = env.authenticatedContext('student-a').firestore();
      await assertFails(setDoc(doc(db, 'announcements/client-forged'), {
        title: 'Forged announcement', message: 'Must be rejected', universityId: 'abu',
        scopeType: 'department', scopeId: 'computer-science', active: true, status: 'published'
      }));
      await assertFails(setDoc(doc(db, 'moderatorAssignments/student-a'), {
        uid: 'student-a', active: true, role: 'moderator', scopeType: 'university', scopeId: 'abu', universityId: 'abu'
      }));
    });
    await t.test('Super Admin can create a valid moderator assignment directly in Firestore on Spark plan', async () => {
      const db = env.authenticatedContext('super-a').firestore();
      await assertSucceeds(setDoc(doc(db, 'moderatorAssignments/student-a'), {
        uid: 'student-a', email: 'student-a@example.com', active: true, role: 'moderator',
        scopeType: 'university', scopeId: 'abu', universityId: 'abu', assignedBy: 'super-a',
        createdAt: serverTimestamp(), updatedAt: serverTimestamp()
      }));
    });
    await t.test('comment access follows the parent announcement audience', async () => {
      await env.withSecurityRulesDisabled(async ctx => {
        await setDoc(doc(ctx.firestore(), 'announcements/other-department'), {
          title: 'Other department', message: 'Private', universityId: 'abu',
          scopeType: 'department', scopeId: 'electrical-engineering', commentsEnabled: true,
          active: true, status: 'published'
        });
        await setDoc(doc(ctx.firestore(), 'announcements/other-department/comments/private-comment'), {
          authorUid: 'student-b', authorName: 'Student B', body: 'Private question', status: 'active'
        });
      });
      const db = env.authenticatedContext('student-a').firestore();
      await assertFails(getDoc(doc(db, 'announcements/other-department/comments/private-comment')));
    });
  } finally {
    await env.cleanup();
  }
});
