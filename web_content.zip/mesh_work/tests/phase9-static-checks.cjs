'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const functions = read('functions/index.js');
const rules = read('firestore.rules');
const moderatorUI = read('js/moderator-publishing.js');
const home = read('js/home.js');
const campusNews = read('js/campus-news.js');
const notifications = read('js/notifications.js');
const discussion = read('js/campus-news.js');
const tests = read('tests/firestore.rules.test.cjs');

// Trusted publishing workflow: role, assignment, and academic scope are checked server-side.
assert.match(functions, /exports\.assignMeshModerator\s*=\s*onCall/);
assert.match(functions, /exports\.revokeMeshModerator\s*=\s*onCall/);
assert.match(functions, /exports\.publishScopedAnnouncement\s*=\s*onCall/);
assert.match(functions, /isSuperAdminData\(adminSnap\.data\(\)\)/);
assert.match(functions, /assignment\.active === true && assignment\.role === 'moderator'/);
assert.match(functions, /Your profile no longer matches the assigned university/);
assert.match(functions, /Your academic profile no longer matches your moderator assignment/);
assert.match(functions, /for \(let i = 0; i < recipients\.length; i \+= 450\)/);
assert.match(functions, /announcementId: ref\.id/);

// Firestore remains the enforcement boundary; only active Super Admins can assign or revoke moderators.
assert.match(rules, /match \/moderatorAssignments\/{uid}/);
assert.match(rules, /allow create: if superAdmin\(\) && validAssignment\(\)/);
assert.match(rules, /allow update: if superAdmin\(\) && validAssignment\(\)/);
assert.match(rules, /request\.resource\.data\.authorUid == request\.auth\.uid/);
assert.match(rules, /data\.commentsEnabled == true/);
assert.match(tests, /students cannot directly publish announcements or modify moderator assignments/);
assert.match(tests, /notification is private to its intended user/);

// Moderator publishing UI uses callable functions, and newly published items refresh visible feeds.
assert.match(moderatorUI, /\.httpsCallable\(["']publishScopedAnnouncement["']\)/);
assert.match(moderatorUI, /mesh:announcement-published/);
assert.match(home, /mesh:announcement-published/);
assert.match(campusNews, /mesh:announcement-published/);
assert.match(home, /\['universityId','==',uni\]/);
assert.match(home, /\['scopeId','==',String\(p\.departmentId\)\]/);
assert.match(home, /a\.active===false/);
assert.match(home, /\['published','active'\]\.indexOf\(a\.status\)<0/);
assert.match(notifications, /where\('uid','==',user\.uid\)/);
assert.match(discussion, /\.collection\('comments'\)\.orderBy\('createdAt','asc'\)/);
assert.match(discussion, /authorUid:user\.uid/);

// Login/auth events and release scripts should remain present in the actual app entry point.
const html = read('index.html');
assert.match(html, /js\/auth\.js/);
assert.match(html, /js\/home\.js/);
assert.match(html, /js\/campus-news\.js/);
assert.match(html, /js\/moderator-publishing\.js/);
console.log('Phase 9 integration/regression static checks: PASS');
console.log('Reminder: these checks inspect source contracts; they do not run Firebase Emulator or live callable functions.');
