'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const rules = fs.readFileSync('firestore.rules', 'utf8');
const tests = fs.readFileSync('tests/firestore.rules.test.cjs', 'utf8');
const functions = fs.readFileSync('functions/index.js', 'utf8');
assert.match(rules, /match \/moderatorAssignments\/\{uid\}[\s\S]*?allow create: if superAdmin\(\) && validAssignment\(\)/);
assert.match(rules, /allow update: if superAdmin\(\) && validAssignment\(\)/);
assert.match(rules, /match \/announcements\/\{id\}[\s\S]*?allow create: if activeAdmin\(\)/);
assert.match(rules, /function canReadAnnouncement\(d\)/);
assert.match(rules, /match \/notifications\/\{id\}[\s\S]*?resource\.data\.uid == request\.auth\.uid/);
assert.match(functions, /exports\.publishScopedAnnouncement/);
assert.match(functions, /exports\.assignMeshModerator/);
assert.match(functions, /exports\.revokeMeshModerator/);
for (const phrase of [
  'unauthenticated users cannot read scoped announcements or comments',
  'students cannot directly publish announcements or modify moderator assignments',
  'comment access follows the parent announcement audience',
  'student cannot read another department or another university announcement'
]) assert.ok(tests.includes(phrase), `Missing emulator test: ${phrase}`);
console.log('Phase 7 static release assertions: PASS');
console.log('Reminder: run test:rules with installed dependencies to execute emulator-backed security tests.');
