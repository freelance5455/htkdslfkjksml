'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const html = read('index.html');
const home = read('js/home.js');
const campus = read('js/campus-news.js');
const publisher = read('js/moderator-publishing.js');
const rules = read('firestore.rules');
const navs = [...html.matchAll(/<nav class="bottom-nav" aria-label="Main navigation">([\s\S]*?)<\/nav>/g)].map(m => m[1]);
assert.ok(navs.length >= 4, 'existing bottom navigation remains in place');
for (const nav of navs) {
  assert.match(nav, /data-nav="home"[^>]*>\s*<i[^>]*><\/i><span>Home<\/span>/);
  assert.match(nav, /data-nav="campus-news"[^>]*>\s*<i[^>]*><\/i><span>Updates<\/span>/);
  assert.match(nav, /data-nav="notifications"[^>]*>\s*<i[^>]*><\/i><span>Alerts<\/span>/);
  assert.match(nav, /data-nav="profile"[^>]*>\s*<i[^>]*><\/i><span>Profile<\/span>/);
}
assert.match(home, /\['scopeType','==','faculty'\]/, 'Home loads faculty-targeted announcements');
assert.match(home, /\['scopeType','==','department'\]/, 'Home loads department-targeted announcements');
assert.match(home, /\['scopeType','==','class'\]/, 'Home loads class-targeted announcements');
assert.match(campus, /announcement\.commentsEnabled!==true/, 'closed discussions cannot accept UI submissions');
assert.match(campus, /announcement\.publisherRole==='moderator'&&c\.authorUid===announcement\.publisherUid/, 'moderator label is derived from trusted announcement publisher fields');
assert.match(campus, /profile\.username\|\|profile\.fullName/, 'comment display prefers MESH username');
assert.match(rules, /get\(\/databases\/\$\(database\)\/documents\/announcements\/\$\(id\)\)\.data\.commentsEnabled == true/, 'Firestore rules enforce commentsEnabled');
assert.match(publisher, /commentsEnabled=!!\(form\.elements\.commentsEnabled&&form\.elements\.commentsEnabled\.checked\)/, 'moderator chooses comment availability before publishing');
console.log('Phase 14 integration source checks: PASS');
console.log('Navigation unchanged; audience queries, moderator labels, and discussion gating are present. Firebase runtime tests still required.');
