# MESH V1 — Home and Profile layout redesign

## What changed
- Replaced the member Home layout with a distinct editorial campus-briefing experience: brand masthead, personalized greeting, campus context, high-impact hero, quick discovery rows, campus noticeboard, opportunities, and community callout.
- Replaced the Profile/Me layout with a personal account hub: identity card, photo control, saved items, communities, profile editing, preferences, sign-in/security, help and feedback, and sign-out.
- Preserved key selectors and data hooks used by existing modules, including `data-home-university`, `data-home-academic`, `data-home-announcement`, `data-content="opportunities"`, profile identity hooks, photo upload, `data-nav`, and sign-out action.
- Updated greeting rendering to target the new home markup and show the student's first name.
- Connected the redesigned profile shortcuts to the existing saved-items, communities, edit-profile, password and support handlers.
- Added responsive styles and used the existing MESH theme variables so theme overrides can continue to apply.

## Multi-university approach
This pass preserves the current university-aware profile/content approach. It does not introduce a new database schema or claim that every existing Firebase query is fully multi-university-safe. Before launch, review each collection's query and Firestore rules for `universityId` scoping and verify access using separate test accounts from different universities.

## Verification
Run the project locally and test with real Firebase accounts. Automated syntax and package checks are not substitutes for a live browser test. Verify Home content loading, profile editing, saved items, communities navigation, support ticket submission, photo upload, password update, sign-out, and theme changes on Android.
