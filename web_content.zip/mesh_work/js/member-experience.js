/* MESH Member Experience — shared interaction layer.
   Uses existing Firebase-facing modules; local-only conveniences are labelled as device-local. */
(function () {
  'use strict';
  var q = function (s, root) { return (root || document).querySelector(s); };
  var qa = function (s, root) { return Array.prototype.slice.call((root || document).querySelectorAll(s)); };
  var esc = function (v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]); }); };
  var store = {
    get: function (key, fallback) { try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (_) { return fallback; } },
    set: function (key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (_) { return false; } }
  };
  function uid() { return window.MESH_FIREBASE && window.MESH_FIREBASE.auth && window.MESH_FIREBASE.auth.currentUser ? window.MESH_FIREBASE.auth.currentUser.uid : 'guest'; }
  function savedKey() { return 'mesh-saved-v1-' + uid(); }
  function readKey() { return 'mesh-read-notifications-v1-' + uid(); }
  function openModal(title, body) {
    var modal = q('#meshGlobalModal'), target = q('#meshGlobalModalBody');
    if (!modal || !target) return;
    target.innerHTML = '<h2>' + esc(title) + '</h2>' + body;
    modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false');
  }
  function closeModal() { var m=q('#meshGlobalModal'); if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true');} }
  function getSaved() { return store.get(savedKey(), []); }
  function saveItem(item, button) {
    var list = getSaved();
    var key = String(item.id || item.title || '');
    var index = list.findIndex(function (x) { return String(x.id || x.title || '') === key && x.type === item.type; });
    if (index >= 0) list.splice(index, 1); else list.unshift({id:key,type:item.type||'campus',title:item.title||'Saved item',description:item.description||'',url:item.url||'',savedAt:Date.now()});
    if (!store.set(savedKey(), list)) { openModal('Could not save item', '<p>Your device could not store this item. Check available storage and try again.</p>'); return; }
    if (button) {
      var isSaved = index < 0;
      button.classList.toggle('is-saved', isSaved);
      button.setAttribute('aria-pressed', String(isSaved));
      var icon=q('i',button); if(icon) icon.className=isSaved?'ri-bookmark-fill':'ri-bookmark-line';
      button.setAttribute('aria-label', (isSaved?'Remove saved item ':'Save ')+(item.title||'item'));
    }
    document.dispatchEvent(new CustomEvent('mesh:saved-items-changed'));
  }
  function showSaved() {
    var list=getSaved();
    var body=list.length?'<p class="mesh-modal-note">Saved on this device for your account on this browser.</p><div class="mesh-saved-list">'+list.map(function(x,i){return '<article class="community-directory-card"><span class="community-directory-icon"><i class="ri-bookmark-fill"></i></span><div class="community-directory-copy"><strong>'+esc(x.title)+'</strong><span>'+esc(x.type)+' · '+esc(x.description||'Saved for later')+'</span></div><button type="button" data-remove-saved="'+i+'">Remove</button>'+(x.url?'<a class="discover-story-link" href="'+esc(x.url)+'" target="_blank" rel="noopener">Open</a>':'')+'</article>';}).join('')+'</div>':'<div class="home-empty"><i class="ri-bookmark-line"></i><strong>Nothing saved yet</strong><span>Save a campus story or opportunity and it will appear here.</span></div>';
    openModal('Saved items',body);
  }
  function renderNotificationReadState() {
    var ids=store.get(readKey(),[]);
    qa('#notifications .notification-item').forEach(function (el) {
      var id=el.getAttribute('data-notification-id');
      if(id && ids.indexOf(id)>=0) el.classList.remove('unread');
    });
  }
  function markNotificationsRead() {
    var ids=store.get(readKey(),[]);
    qa('#notifications .notification-item').forEach(function (el) { var id=el.getAttribute('data-notification-id'); if(id && ids.indexOf(id)<0) ids.push(id); el.classList.remove('unread'); });
    store.set(readKey(),ids);
    var b=q('[data-mark-notifications-read]'); if(b){b.textContent='All caught up';b.disabled=true;setTimeout(function(){b.textContent='Mark all read';b.disabled=false;},1600);}
  }
  function renderCommunities(mode) {
    var root=q('[data-community-list]'); if(!root)return;
    var state=window.MESH_CONTENT&&window.MESH_CONTENT.state;
    var items=state&&Array.isArray(state.communities)?state.communities:[];
    var tabs=qa('#community .community-tabs button');
    tabs.forEach(function(b){var active=(mode==='discover'?/discover/i.test(b.textContent):!/discover/i.test(b.textContent));b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
    if(mode!=='discover'){
      root.innerHTML='<div class="home-empty"><i class="ri-group-line"></i><strong>Your communities</strong><span>Communities you join will be listed here when membership is available for your account.</span><button type="button" data-community-directory>Browse communities</button></div>';
      return;
    }
    if(!items.length){root.innerHTML='<div class="home-empty"><i class="ri-compass-3-line"></i><strong>No communities published yet</strong><span>University communities will appear here when they are added to MESH.</span></div>';return;}
    root.innerHTML=items.filter(function(x){return x.active!==false;}).map(function(x){var id=x.id||x.docId||x.name||x.title;return '<article class="community-directory-card"><span class="community-directory-icon"><i class="ri-group-line"></i></span><div class="community-directory-copy"><strong>'+esc(x.name||x.title||'Student community')+'</strong><span>'+esc(x.description||x.category||x.universityName||'A community on MESH')+'</span></div><button type="button" data-community-view="'+esc(id)+'">Details</button></article>';}).join('');
  }
  async function refreshCommunityDirectory() {
    if(window.MESH_CONTENT&&window.MESH_CONTENT.load) { try { await window.MESH_CONTENT.load(); } catch (_) {} }
    renderCommunities('discover');
  }
  document.addEventListener('click', function (event) {
    var save=event.target.closest('[data-save-item], [data-action="save"]');
    if(save){event.preventDefault();event.stopPropagation();var article=save.closest('[data-content-type],.opportunity-card,.discover-story-card');var title=save.getAttribute('data-item-title')||(article&&q('h3,h4',article)&&q('h3,h4',article).textContent)||'Campus item';var type=save.getAttribute('data-item-type')||(article&&article.getAttribute('data-content-type'))||'opportunities';var id=save.getAttribute('data-item-id')||(article&&article.getAttribute('data-story-id'))||title;var description=save.getAttribute('data-item-description')||(article&&q('p',article)&&q('p',article).textContent)||'';var url=save.getAttribute('data-item-url')||'';saveItem({id:id,type:type,title:title,description:description,url:url},save);return;}
    var saved=event.target.closest('[data-remove-saved]');if(saved){var list=getSaved();list.splice(Number(saved.getAttribute('data-remove-saved')),1);store.set(savedKey(),list);showSaved();return;}
    if(event.target.closest('[data-mark-notifications-read]')){markNotificationsRead();return;}
    var profileMenu=event.target.closest('#profile .profile-menu-item');
    if(profileMenu){var label=(profileMenu.innerText||'').toLowerCase();if(label.indexOf('saved')>=0){event.preventDefault();showSaved();return;}if(label.indexOf('communities')>=0){event.preventDefault();if(window.MESH_NAV)window.MESH_NAV.go('community');setTimeout(function(){renderCommunities('discover');},80);return;} }
    if(event.target.closest('[data-community-create-info]')){openModal('Create a community','<p>Community creation is not connected to a verified member-facing workflow in the current MESH backend. To avoid creating a request that could be lost or rejected by Firestore rules, contact MESH support and ask an administrator to publish the community.</p><button type="button" class="btn btn-primary btn-block" data-open-support>Contact support</button>');return;}
    if(event.target.closest('[data-community-directory]')){refreshCommunityDirectory();return;}
    var communityTab=event.target.closest('#community .community-tabs button');if(communityTab){event.preventDefault();if(/discover/i.test(communityTab.textContent))refreshCommunityDirectory();else renderCommunities('mine');return;}
    var communityView=event.target.closest('[data-community-view]');if(communityView){var st=window.MESH_CONTENT&&window.MESH_CONTENT.state,arr=st&&st.communities||[],it=arr.find(function(x){return String(x.id||x.docId||x.name||x.title)===communityView.getAttribute('data-community-view');});if(it)openModal(it.name||it.title||'Community','<p>'+esc(it.description||'More information about this community will be available here.')+'</p>'+(it.universityName?'<p><strong>University:</strong> '+esc(it.universityName)+'</p>':'')+(it.category?'<p><strong>Category:</strong> '+esc(it.category)+'</p>':''));return;}
    var homeFilter=event.target.closest('[data-home-filter]');if(homeFilter){var filter=homeFilter.getAttribute('data-home-filter')||'all';setTimeout(function(){if(window.MESH_CONTENT&&window.MESH_CONTENT.setFilter)window.MESH_CONTENT.setFilter(filter);},80);}
  });
  document.addEventListener('mesh:screen-change',function(e){if(e.detail&&e.detail.screen==='notifications')setTimeout(renderNotificationReadState,180);if(e.detail&&e.detail.screen==='community')setTimeout(function(){renderCommunities('mine');},180);});
  document.addEventListener('mesh:auth-state',function(){setTimeout(renderNotificationReadState,250);});
  document.addEventListener('mesh:saved-items-changed',function(){qa('[data-save-item]').forEach(function(b){var list=getSaved(),id=b.getAttribute('data-item-id'),type=b.getAttribute('data-item-type');var yes=list.some(function(x){return String(x.id)===String(id)&&x.type===type;});b.classList.toggle('is-saved',yes);b.setAttribute('aria-pressed',String(yes));var i=q('i',b);if(i)i.className=yes?'ri-bookmark-fill':'ri-bookmark-line';});});
  window.MESH_MEMBER_EXPERIENCE={showSaved:showSaved,markNotificationsRead:markNotificationsRead,refreshCommunities:refreshCommunityDirectory};
})();
