(function() {
  
  "use strict";
  
  var currentScreen = "welcome";
  var historyStack = [];
  
  function getScreens() {
    return document.querySelectorAll(".screen[data-screen]");
  }
  
  function showScreen(screenId, addHistory) {
    
    var target = document.querySelector(
      '.screen[data-screen="' + screenId + '"]'
    );
    
    if (!target) {
      console.warn("MESH: Screen not found:", screenId);
      return false;
    }
    
    var previous = currentScreen;
    
    getScreens().forEach(function(screen) {
      screen.classList.remove("active");
      screen.setAttribute("aria-hidden", "true");
    });
    
    target.classList.add("active");
    target.setAttribute("aria-hidden", "false");
    
    if (addHistory && previous !== screenId) {
      historyStack.push(previous);
    }
    
    currentScreen = screenId;
    
    window.scrollTo({
      top: 0,
      behavior: "auto"
    });
    
    updateBottomNavigation();
    
    document.dispatchEvent(
      new CustomEvent("mesh:screen-change", {
        detail: {
          screen: screenId,
          previous: previous
        }
      })
    );
    
    return true;
  }
  
  function go(screenId) {
    return showScreen(screenId, true);
  }
  
  function replace(screenId) {
    historyStack = [];
    return showScreen(screenId, false);
  }
  
  function back() {
    
    if (historyStack.length > 0) {
      var previous = historyStack.pop();
      return showScreen(previous, false);
    }
    
    return showScreen("welcome", false);
  }
  
  function updateBottomNavigation() {
    
    var bottomLinks = document.querySelectorAll(
      "[data-nav]"
    );
    
    bottomLinks.forEach(function(item) {
      
      var target = item.getAttribute("data-nav");
      
      if (target === currentScreen) {
        item.classList.add("active");
        item.setAttribute("aria-current", "page");
      } else {
        item.classList.remove("active");
        item.removeAttribute("aria-current");
      }
      
    });
  }
  
  function openAuth(mode) {
    
    showScreen("auth", true);
    
    document.dispatchEvent(
      new CustomEvent("mesh:open-auth", {
        detail: {
          mode: mode || "signin"
        }
      })
    );
  }
  
  function handleAction(action) {
    
    if (action === "get-started") {
      openAuth("signup");
      return;
    }
    
    if (action === "sign-in") {
      openAuth("signin");
      return;
    }
    
    if (action === "back") {
      back();
      return;
    }
    
    if (action === "sign-out") {
      document.dispatchEvent(
        new CustomEvent("mesh:sign-out-request")
      );
      return;
    }
    
    if (action === "forgot-password") {
      document.dispatchEvent(
        new CustomEvent("mesh:forgot-password-request")
      );
      return;
    }
    
    if (action === "google-signin") {
      document.dispatchEvent(
        new CustomEvent("mesh:google-signin-request")
      );
      return;
    }
    
    if (action === "request-university") {
      document.dispatchEvent(
        new CustomEvent("mesh:request-university")
      );
      return;
    }
    
  }
  
  document.addEventListener("click", function(event) {
    
    var actionElement = event.target.closest(
      "[data-action]"
    );
    
    if (actionElement) {
      
      var action = actionElement.getAttribute(
        "data-action"
      );
      
      handleAction(action);
      return;
    }
    
    var navElement = event.target.closest(
      "[data-nav]"
    );
    
    if (navElement) {
      
      var target = navElement.getAttribute(
        "data-nav"
      );
      
      if (target) {
        go(target);
      }
      
      return;
    }
    
    var screenLink = event.target.closest(
      "[data-screen-link]"
    );
    
    if (screenLink) {
      
      var screen = screenLink.getAttribute(
        "data-screen-link"
      );
      
      if (screen) {
        go(screen);
      }
      
    }
    
  });
  
  document.addEventListener("click", function(event) {
    
    var continueButton = event.target.closest(
      "[data-continue]"
    );
    
    if (!continueButton) {
      return;
    }
    
    var target = continueButton.getAttribute(
      "data-continue"
    );
    
    if (!target) {
      return;
    }
    
    document.dispatchEvent(
      new CustomEvent("mesh:continue", {
        detail: {
          target: target,
          button: continueButton
        }
      })
    );
    
  });
  
  document.addEventListener("mesh:auth-complete", function(event) {
    
    var detail = event.detail || {};
    
    if (detail.screen) {
      replace(detail.screen);
    }
    
  });
  
  window.MESH_NAV = {
    
    go: go,
    
    back: back,
    
    replace: replace,
    
    current: function() {
      return currentScreen;
    },
    
    openAuth: openAuth
    
  };
  
  document.addEventListener("DOMContentLoaded", function() {
    replace("welcome");
  });
  
  if (document.readyState !== "loading") {
    replace("welcome");
  }
  
})();