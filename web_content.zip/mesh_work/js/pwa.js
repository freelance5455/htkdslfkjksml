(function () {
  'use strict';
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./service-worker.js', { scope: './' })
      .then(function (registration) { console.info('MESH PWA: service worker registered', registration.scope); })
      .catch(function (error) { console.warn('MESH PWA: service worker registration failed', error); });
  });
  var installPrompt = null;
  window.addEventListener('beforeinstallprompt', function (event) {
    event.preventDefault();
    installPrompt = event;
    document.dispatchEvent(new CustomEvent('mesh:pwa-install-available'));
  });
  window.MESH_PWA = {
    canPromptInstall: function () { return !!installPrompt; },
    promptInstall: async function () {
      if (!installPrompt) return { outcome: 'unavailable' };
      var prompt = installPrompt;
      installPrompt = null;
      await prompt.prompt();
      var choice = await prompt.userChoice;
      return { outcome: choice && choice.outcome ? choice.outcome : 'unknown' };
    }
  };
})();
