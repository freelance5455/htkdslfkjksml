/* MESH global theme runtime: reads the published theme from Firestore. */
(function () {
  "use strict";
  var DEFAULTS = { primary: "#2457D6", secondary: "#3B82F6", brandDark: "#102A56", background: "#F4F7FF", surface: "#FFFFFF", text: "#14213D", mutedText: "#64748B", border: "#D9E2F2" };
  var KEYS = { primary: ["--mesh-green", "--green", "--color-primary"], secondary: ["--mesh-green-dark", "--color-secondary"], brandDark: ["--mesh-black", "--mesh-black-2", "--mesh-black-3", "--black", "--black2", "--color-brand-dark", "--brand-dark"], background: ["--surface-soft", "--surface-muted", "--bg", "--background", "--color-background"], surface: ["--white", "--surface", "--card", "--color-surface"], text: ["--text", "--color-text"], mutedText: ["--text-soft", "--text-muted", "--muted", "--color-text-muted"], border: ["--border", "--color-border"] };
  function validHex(value) { return /^#[0-9a-fA-F]{6}$/.test(String(value || "")); }
  function applyTheme(theme) {
    var incoming = theme || {};
    // Migrate the former default emerald palette instead of resurrecting it on startup.
    if (incoming.primary && ["#079B65", "#10B981", "#19E68C"].indexOf(String(incoming.primary).toUpperCase()) >= 0 && ["#064E3B", "#0B0D0E"].indexOf(String(incoming.brandDark || "").toUpperCase()) >= 0) incoming = DEFAULTS;
    var merged = Object.assign({}, DEFAULTS, incoming), root = document.documentElement;
    Object.keys(KEYS).forEach(function (key) { if (!validHex(merged[key])) merged[key] = DEFAULTS[key]; });
    var visual = Object.assign({}, merged);
    if (root.dataset.theme === "dark") {
      visual.background = "#0B1020"; visual.surface = "#121A2B"; visual.text = "#EEF3FF";
      visual.mutedText = "#A8B4CC"; visual.border = "#293650";
    }
    Object.keys(KEYS).forEach(function (key) {
      KEYS[key].forEach(function (variable) { root.style.setProperty(variable, visual[key]); });
    });
    var primary = merged.primary;
    root.style.setProperty("--mesh-green-soft", hexToRgba(primary, 0.10));
    root.style.setProperty("--mesh-green-glow", hexToRgba(primary, 0.22));
    root.style.setProperty("--green-soft", hexToRgba(primary, 0.10));
    root.style.setProperty("--theme-primary", primary);
    root.style.setProperty("--primary", primary);
    root.style.setProperty("--accent", primary);
    root.style.setProperty("--green", primary);
    root.style.setProperty("--brand-dark", visual.brandDark);
    root.style.setProperty("--background", visual.background);
    root.style.setProperty("--muted", visual.mutedText);
    root.style.setProperty("--color-accent", primary);
    root.style.setProperty("--surface-muted", hexToRgba(merged.primary, 0.07));
    root.style.setProperty("--mesh-theme-secondary", merged.secondary);
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", primary);
    try { localStorage.setItem("meshGlobalThemeCache", JSON.stringify(merged)); } catch (e) {}
    document.dispatchEvent(new CustomEvent("mesh:theme-changed", { detail: merged }));
  }
  function hexToRgba(hex, alpha) { var n = parseInt(hex.slice(1), 16); return "rgba(" + (n >> 16) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + alpha + ")"; }
  window.MESH_THEME = { defaults: DEFAULTS, apply: applyTheme };
  applyTheme(DEFAULTS);
  function connect() {
    if (!window.firebase || !firebase.apps || !firebase.apps.length || !firebase.firestore) return;
    try {
      var db = firebase.firestore();
      db.collection("appSettings").doc("globalTheme").onSnapshot(function (snap) { if (snap.exists && snap.data().colors) applyTheme(snap.data().colors); }, function (err) { console.warn("MESH theme sync unavailable; using defaults.", err && err.code); });
    } catch (e) { console.warn("MESH theme could not initialize.", e); }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", connect); else connect();
})();
