(function () {

  "use strict";

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function $$(selector, root) {
    return Array.prototype.slice.call(
      (root || document).querySelectorAll(selector)
    );
  }

  function toast(message, type) {

    var existing = document.querySelector(
      ".mesh-toast"
    );

    if (existing) {
      existing.remove();
    }

    var toastEl = document.createElement("div");

    toastEl.className =
      "mesh-toast " +
      (type || "info");

    toastEl.textContent = message;

    Object.assign(toastEl.style, {
      position: "fixed",
      left: "50%",
      bottom: "24px",
      transform: "translateX(-50%)",
      zIndex: "99999",
      padding: "13px 18px",
      borderRadius: "12px",
      background: "#111315",
      color: "#fff",
      fontSize: "14px",
      fontWeight: "600",
      boxShadow: "0 10px 30px rgba(0,0,0,.25)",
      maxWidth: "90%",
      textAlign: "center"
    });

    document.body.appendChild(toastEl);

    setTimeout(function () {

      if (toastEl.parentNode) {
        toastEl.remove();
      }

    }, 3500);
  }

  function setLoading(form, loading) {

    if (!form) return;

    var button = form.querySelector(
      'button[type="submit"]'
    );

    if (!button) return;

    if (!button.dataset.originalText) {
      button.dataset.originalText =
        button.textContent.trim();
    }

    button.disabled = loading;

    button.textContent = loading
      ? "Please wait..."
      : button.dataset.originalText;
  }

  function switchAuthTab(mode) {

    var isSignup = mode === "signup";

    $$("[data-auth-tab]").forEach(function (tab) {

      var tabMode = tab.getAttribute(
        "data-auth-tab"
      );

      tab.classList.toggle(
        "active",
        tabMode === mode
      );

    });

    $$("[data-auth-form]").forEach(function (form) {

      var formMode = form.getAttribute(
        "data-auth-form"
      );

      form.classList.toggle(
        "hidden",
        formMode !== mode
      );

    });
  }

  function validateSignup(form) {

    var name = $("#signup-name");
    var email = $("#signup-email");
    var password = $("#signup-password");
    var confirm = $("#signup-confirm-password");
    var username = $("#signup-username");

    if (!name || !email || !password || !confirm || !username) {
      return false;
    }

    var inviteCode = $("#signup-invite-code");
    if (!inviteCode || !inviteCode.value.trim()) {
      toast("Enter your MESH pilot invite code.", "error");
      if (inviteCode) inviteCode.focus();
      return false;
    }

    if (!/^[A-Za-z0-9_.]{3,24}$/.test(username.value.trim())) {
      toast("Username must be 3–24 characters using letters, numbers, dots or underscores.", "error");
      username.focus(); return false;
    }

    if (!name.value.trim()) {
      toast("Please enter your full name.", "error");
      name.focus();
      return false;
    }

    if (!email.value.trim()) {
      toast("Please enter your email.", "error");
      email.focus();
      return false;
    }

    if (password.value.length < 6) {
      toast(
        "Password must be at least 6 characters.",
        "error"
      );
      password.focus();
      return false;
    }

    if (password.value !== confirm.value) {
      toast(
        "Passwords do not match.",
        "error"
      );
      confirm.focus();
      return false;
    }

    return true;
  }

  function validateSignin(form) {

    var email = $("#signin-email");
    var password = $("#signin-password");

    if (!email || !password) {
      return false;
    }

    if (!email.value.trim()) {
      toast("Please enter your email.", "error");
      email.focus();
      return false;
    }

    if (!password.value) {
      toast("Please enter your password.", "error");
      password.focus();
      return false;
    }

    return true;
  }

  function handleAuthSuccess(event) {

    var detail = event.detail || {};
    var user = detail.user;

    if (!user) {
      console.warn(
        "MESH: Auth success received without user."
      );
      return;
    }

    /*
     * BRAND NEW ACCOUNT
     *
     * Always begin onboarding.
     */
    if (detail.isNewUser === true) {
      if (window.MESH_ONBOARDING && typeof window.MESH_ONBOARDING.reset === "function") window.MESH_ONBOARDING.reset();
      if (window.MESH_NAV) window.MESH_NAV.replace("setup-university");
      toast("Account created. Welcome to MESH!", "success");
      return;

      if (window.MESH_ONBOARDING &&
          typeof window.MESH_ONBOARDING.reset === "function") {

        window.MESH_ONBOARDING.reset();
      }

      if (window.MESH_NAV) {
        window.MESH_NAV.replace(
          "setup-university"
        );
      }

      toast(
        "Account created. Let's build your MESH.",
        "success"
      );

      return;
    }

    /*
     * EXISTING ACCOUNT
     *
     * Check whether onboarding is complete.
     */
    if (
      window.MESH_FIREBASE &&
      typeof window.MESH_FIREBASE.getUserProfile === "function"
    ) {

      window.MESH_FIREBASE
        .getUserProfile(user.uid)
        .then(function (profile) {

          if ((!profile || !profile.inviteCodeUsed) && window.MESH_PILOT_ACCESS && typeof window.MESH_PILOT_ACCESS.requireCode === "function") {
            window.MESH_PILOT_ACCESS.requireCode(user, profile, function () {
              if (profile && profile.onboardingCompleted === true) window.MESH_NAV.replace("home");
              else window.MESH_NAV.replace("setup-university");
            });
            return;
          }

          if (profile && profile.onboardingCompleted === true) {

            window.MESH_NAV.replace("home");

          } else {

            if (
              window.MESH_ONBOARDING &&
              typeof window.MESH_ONBOARDING.reset === "function"
            ) {
              window.MESH_ONBOARDING.reset();
            }

            window.MESH_NAV.replace(
              "setup-university"
            );
          }

        })
        .catch(function (error) {

          console.error(
            "MESH: Profile lookup failed:",
            error
          );

          window.MESH_NAV.replace(
            "setup-university"
          );

        });

      return;
    }

    window.MESH_NAV.replace("home");
  }

  function setupForms() {

    var signinForm = $(
      "[data-auth-form='signin']"
    );

    var signupForm = $(
      "[data-auth-form='signup']"
    );

    /*
     * SIGN IN
     */
    if (signinForm) {

      signinForm.addEventListener(
        "submit",
        function (event) {

          event.preventDefault();
          event.stopPropagation();

          if (!validateSignin(signinForm)) {
            return;
          }

          setLoading(signinForm, true);

          document.dispatchEvent(
            new CustomEvent(
              "mesh:signin-request",
              {
                detail: {
                  email: $("#signin-email").value.trim(),
                  password: $("#signin-password").value
                }
              }
            )
          );

        }
      );

    }

    /*
     * SIGN UP
     */
    if (signupForm) {

      signupForm.addEventListener(
        "submit",
        function (event) {

          event.preventDefault();
          event.stopPropagation();

          if (!validateSignup(signupForm)) {
            return;
          }

          setLoading(signupForm, true);

          document.dispatchEvent(
            new CustomEvent(
              "mesh:signup-request",
              {
                detail: {
                  name: $("#signup-name").value.trim(),
                  username: $("#signup-username").value.trim().toLowerCase(),
                  email: $("#signup-email").value.trim(),
                  password: $("#signup-password").value,
                  inviteCode: $("#signup-invite-code").value.trim()
                }
              }
            )
          );

        }
      );

    }

  }

  function setupTabs() {

    $$("[data-auth-tab]").forEach(
      function (tab) {

        tab.addEventListener(
          "click",
          function () {

            switchAuthTab(
              tab.getAttribute(
                "data-auth-tab"
              )
            );

          }
        );

      }
    );

  }

  function setupPasswordToggles() {

    $$("[data-password-toggle]").forEach(
      function (button) {

        button.addEventListener(
          "click",
          function () {

            var targetSelector =
              button.getAttribute(
                "data-password-toggle"
              );

            var input = $(
              targetSelector
            );

            if (!input) return;

            var showing =
              input.type === "text";

            input.type = showing
              ? "password"
              : "text";

          }
        );

      }
    );

  }

  function setupAuthEvents() {

    document.addEventListener(
      "mesh:open-auth",
      function (event) {

        var mode =
          event.detail &&
          event.detail.mode
            ? event.detail.mode
            : "signin";

        switchAuthTab(mode);

      }
    );

    document.addEventListener(
      "mesh:auth-success",
      function (event) {

        handleAuthSuccess(event);

        var signinForm = $(
          "[data-auth-form='signin']"
        );

        var signupForm = $(
          "[data-auth-form='signup']"
        );

        setLoading(signinForm, false);
        setLoading(signupForm, false);

      }
    );

    document.addEventListener(
      "mesh:auth-error",
      function (event) {

        var detail = event.detail || {};

        var signinForm = $(
          "[data-auth-form='signin']"
        );

        var signupForm = $(
          "[data-auth-form='signup']"
        );

        setLoading(signinForm, false);
        setLoading(signupForm, false);

        toast(
          detail.message ||
          "Authentication failed. Please try again.",
          "error"
        );

        console.error(
          "MESH AUTH ERROR:",
          detail.error || detail.message
        );

      }
    );

    document.addEventListener(
      "mesh:password-reset-sent",
      function () {

        toast(
          "If the address belongs to a password-based MESH account, check Inbox, Spam and Promotions. If nothing arrives after a few minutes, confirm the email address and ask the MESH administrator to check Firebase Authentication email templates, sender settings and authorized domains. Google-only accounts do not have a MESH password to reset.",
          "success"
        );

      }
    );

    document.addEventListener(
      "mesh:logout-success",
      function () {

        if (window.MESH_NAV) {
          window.MESH_NAV.replace("welcome");
        }

      }
    );

    document.addEventListener(
      "mesh:signin-request",
      function (event) {

        if (
          window.MESH_FIREBASE &&
          typeof window.MESH_FIREBASE.signIn === "function"
        ) {

          window.MESH_FIREBASE.signIn(
            event.detail.email,
            event.detail.password
          );

        }

      }
    );

    document.addEventListener(
      "mesh:signup-request",
      function (event) {

        if (
          window.MESH_FIREBASE &&
          typeof window.MESH_FIREBASE.signUp === "function"
        ) {

          window.MESH_FIREBASE.signUp(
            event.detail.name,
            event.detail.email,
            event.detail.password,
            event.detail.inviteCode,
            event.detail.username
          );

        }

      }
    );

    document.addEventListener(
      "mesh:google-signin-request",
      function () {

        if (
          window.MESH_FIREBASE &&
          typeof window.MESH_FIREBASE.signInWithGoogle === "function"
        ) {

          window.MESH_FIREBASE.signInWithGoogle();

        }

      }
    );

    document.addEventListener(
      "mesh:forgot-password-request",
      function () {

        var emailInput = $(
          "#signin-email"
        );

        var email =
          emailInput
            ? emailInput.value.trim()
            : "";

        if (!email) {

          toast(
            "Enter your email first.",
            "error"
          );

          if (emailInput) {
            emailInput.focus();
          }

          return;
        }

        if (
          window.MESH_FIREBASE &&
          typeof window.MESH_FIREBASE.resetPassword === "function"
        ) {

          window.MESH_FIREBASE.resetPassword(
            email
          );

        }

      }
    );

    document.addEventListener(
      "mesh:sign-out-request",
      function () {

        if (
          window.MESH_FIREBASE &&
          typeof window.MESH_FIREBASE.signOut === "function"
        ) {

          window.MESH_FIREBASE.signOut();

        }

      }
    );

  }

  setupForms();
  setupTabs();
  setupPasswordToggles();
  setupAuthEvents();

  /*
   * Default state.
   */
  switchAuthTab("signin");

})();