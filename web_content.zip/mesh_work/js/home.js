(function(){
  "use strict";
  function q(s){return document.querySelector(s)}
  function esc(v){return String(v||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
  function profile(){return window.MESH_PROFILE&&window.MESH_PROFILE.getProfile?window.MESH_PROFILE.getProfile():{};}
  function renderProfile(){var p=profile();var name=p.fullName||p.name||"Student";var uni=p.university||"Your University";var acad=[p.department,p.level].filter(Boolean).join(" · ")||"Your academic profile";var h=q("#home .app-header h2");var first=q("[data-home-firstname]");var g=q("#home .header-greeting");if(h)h.textContent="Welcome, "+name.split(" ")[0];if(first)first.textContent=name.split(" ")[0];if(g)g.textContent=(new Date().getHours()<12?"GOOD MORNING":new Date().getHours()<18?"GOOD AFTERNOON":"GOOD EVENING");var u=q("[data-home-university]");var a=q("[data-home-academic]");if(u)u.textContent=uni;if(a)a.textContent=acad;var campus=q("[data-profile-campus]");if(campus)campus.textContent=[p.university,p.faculty,p.department,p.level].filter(Boolean).join(" · ")||"Add your campus details to personalize MESH.";}
  function renderAnnouncement(a){var el=q("[data-home-announcement]");if(!el)return;if(!a){el.innerHTML='<div class="announcement-top"><div class="announcement-icon"><i class="ri-megaphone-line"></i></div><div class="announcement-content"><h4 class="announcement-title">No announcements yet</h4><p class="announcement-message">Your university updates will appear here.</p></div></div>';return;}el.innerHTML='<div class="announcement-top"><div class="announcement-icon"><i class="ri-megaphone-line"></i></div><div class="announcement-content"><h4 class="announcement-title">'+esc(a.title)+'</h4><p class="announcement-message">'+esc(a.message||a.content)+'</p></div></div><span class="announcement-time">'+esc(a.priority==="high"?"Important":"Latest")+'</span>';}
  function renderOpportunities(items){var el=q('[data-content="opportunities"]');if(!el)return;if(!items.length){el.innerHTML='<div class="home-empty"><i class="ri-briefcase-4-line"></i><strong>No opportunities yet</strong><span>Opportunities published for your university will appear here.</span></div>';return;}el.innerHTML=items.slice(0,3).map(function(o){return '<article class="mesh-card opportunity-card"><div class="opportunity-top"><div><span class="mesh-tag green">OPPORTUNITY</span><h4 class="opportunity-title">'+esc(o.title)+'</h4><p class="opportunity-organization">'+esc(o.organization||"")+'</p></div><button class="save-button" type="button" data-save-item data-item-type="opportunities" data-item-id="'+esc(o.id||o.docId||o.title)+'" data-item-title="'+esc(o.title)+'" data-item-description="'+esc(o.description||o.content||"")+'" aria-label="Save '+esc(o.title)+'"><i class="ri-bookmark-line"></i></button></div><div class="opportunity-deadline"><strong>Deadline:</strong> '+esc(o.deadline||"Open")+'</div></article>';}).join("");}
  async function load(){
    renderProfile();
    var fb=window.MESH_FIREBASE;
    if(!fb||!fb.getCollection)return;
    var p=profile(),uni=String(p.universityId||''),queries=[];
    // Firestore rules are not filters: each query must prove every returned
    // announcement is visible to this profile. Never query all university posts.
    if(uni){
      queries.push([['universityId','==',uni],['scopeType','==','university'],['active','==',true],['status','==','published']]);
      if(p.facultyId)queries.push([['universityId','==',uni],['scopeType','==','faculty'],['scopeId','==',String(p.facultyId)],['active','==',true],['status','==','published']]);
      if(p.departmentId)queries.push([['universityId','==',uni],['scopeType','==','department'],['scopeId','==',String(p.departmentId)],['active','==',true],['status','==','published']]);
      var level=String(p.levelId||p.level||'');
      if(level)queries.push([['universityId','==',uni],['scopeType','==','class'],['scopeId','==',level],['active','==',true],['status','==','published']]);
    }
    // Legacy blank-university records are only queried as university-wide notices.
    queries.push([['universityId','==',''],['scopeType','==','university'],['active','==',true],['status','==','published']]);
    queries.push([['universityId','==',''],['scope','==','university'],['active','==',true],['status','==','published']]);
    var announcementTask=Promise.all(queries.map(async function(where){try{return await fb.getCollection('announcements',{where:where,limit:30});}catch(e){console.warn('Scoped home announcement query unavailable',e);return [];}})).then(function(groups){var seen={};return [].concat.apply([],groups).filter(function(a){var id=String(a.id||a.docId||'');if(!id||seen[id]||a.active===false||(a.status&&['published','active'].indexOf(a.status)<0))return false;seen[id]=true;return true;}).sort(function(a,b){var av=a.publishedAt&&a.publishedAt.toDate?a.publishedAt.toDate():a.createdAt&&a.createdAt.toDate?a.createdAt.toDate():new Date(a.publishedAt||a.createdAt||0);var bv=b.publishedAt&&b.publishedAt.toDate?b.publishedAt.toDate():b.createdAt&&b.createdAt.toDate?b.createdAt.toDate():new Date(b.publishedAt||b.createdAt||0);return bv-av;});});
    var opportunityTask=fb.getCollection('opportunities',uni?{where:[['universityId','==',uni]],limit:30}:{where:[['universityId','==','']],limit:30}).then(function(items){return items.filter(function(x){return x.active!==false;});}).catch(function(e){console.warn('MESH home opportunities unavailable',e);return [];});
    var results=await Promise.all([announcementTask,opportunityTask]);
    renderAnnouncement(results[0][0]||null);
    renderOpportunities(results[1]);
  }
  document.addEventListener("mesh:auth-success",load);document.addEventListener("mesh:auth-state",function(e){if(e.detail&&e.detail.user)setTimeout(load,100)});document.addEventListener("mesh:onboarding-complete",function(e){setTimeout(load,100)});document.addEventListener("mesh:screen-change",function(e){if(e.detail.screen==="home")load()});document.addEventListener("mesh:announcement-published",function(){var screen=q("#home");if(screen&&screen.classList.contains("active"))load();});
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",load);else load();
})();
