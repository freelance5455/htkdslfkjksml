(function () {
  "use strict";

  var state = { universityId:"", university:"", facultyId:"", faculty:"", departmentId:"", department:"", level:"", interests:[] };

  function cards(option){
    var selector = option === "level" ? '.level-card[data-option="level"]' : option === "interest" ? '.interest-chip[data-option="interest"]' : '.selection-card[data-option="'+option+'"]';
    return Array.prototype.slice.call(document.querySelectorAll(selector));
  }
  function value(card){ return card.getAttribute("data-value") || ""; }
  function label(card){ var el=card.querySelector("strong") || card.querySelector("span"); return el ? el.textContent.trim() : card.textContent.trim(); }
  function clear(option){ cards(option).forEach(function(c){c.classList.remove("selected");c.setAttribute("aria-selected","false");}); }
  function selectSingle(option,v){ clear(option); cards(option).forEach(function(c){if(value(c)===v){c.classList.add("selected");c.setAttribute("aria-selected","true");}}); }
  function setLoading(container,text){ var el=document.querySelector(container); if(el) el.innerHTML='<div class="setup-empty"><i class="ri-loader-4-line"></i><strong>'+text+'</strong><span>Please wait...</span></div>'; }
  function empty(container,text){ var el=document.querySelector(container); if(el) el.innerHTML='<div class="setup-empty"><i class="ri-inbox-line"></i><strong>No options available</strong><span>'+text+'</span></div>'; }

  async function getAll(collection){
    if(!window.MESH_FIREBASE || !window.MESH_FIREBASE.getCollection) return [];
    return window.MESH_FIREBASE.getCollection(collection,{limit:100});
  }
  async function getBy(collection,field,val){
    if(!window.MESH_FIREBASE || !window.MESH_FIREBASE.getCollectionByField) return [];
    return window.MESH_FIREBASE.getCollectionByField(collection,field,val,100);
  }
  function uniqueActive(items){
    var seen=Object.create(null);
    return (items||[]).filter(function(item){
      if(!item||item.active===false)return false;
      var key=String(item.id||item.name||item.title||"").trim().toLowerCase().replace(/\\s+/g," ");
      if(!key||seen[key])return false;seen[key]=true;return true;
    });
  }
  function renderList(container,items,option,icon){
    items=uniqueActive(items);
    var el=document.querySelector(container); if(!el) return;
    el.innerHTML="";
    uniqueActive(items).forEach(function(item){
      var b=document.createElement("button"); b.type="button"; b.className="selection-card"; b.setAttribute("data-option",option); b.setAttribute("data-value",item.id);
      b.innerHTML='<div class="selection-icon"><i class="'+icon+'"></i></div><div class="selection-info"><strong>'+escapeHTML(item.name||item.title||"")+'</strong><span>'+escapeHTML(item.code||item.shortName||item.description||"")+'</span></div><i class="ri-arrow-right-s-line"></i>';
      el.appendChild(b);
    });
    if(!el.children.length) empty(container,"Your university has not published any options yet.");
  }
  function renderLevels(items){
    var el=document.querySelector("#setup-level .level-grid"); if(!el)return; el.innerHTML="";
    uniqueActive(items).sort(function(a,b){return (a.order||0)-(b.order||0);}).forEach(function(item){var b=document.createElement("button");b.type="button";b.className="level-card";b.setAttribute("data-option","level");b.setAttribute("data-value",item.id);b.textContent=item.name||item.id;el.appendChild(b);});
    if(!el.children.length) empty("#setup-level .level-grid","Levels are currently unavailable.");
  }
  function renderInterests(items){
    var el=document.querySelector("#setup-interests .interest-grid"); if(!el)return; el.innerHTML="";
    uniqueActive(items).forEach(function(item){var b=document.createElement("button");b.type="button";b.className="interest-chip";b.setAttribute("data-option","interest");b.setAttribute("data-value",item.id);b.innerHTML='<i class="'+escapeHTML(item.icon||"ri-sparkling-line")+'"></i>'+escapeHTML(item.name||"");el.appendChild(b);});
    if(!el.children.length) empty("#setup-interests .interest-grid","Interests are currently unavailable.");
  }
  function escapeHTML(v){return String(v||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");}

  async function loadUniversities(){
    var c="#setup-university .selection-list"; setLoading(c,"Loading universities");
    try{renderList(c,await getAll("universities"),"university","ri-building-4-line");}catch(e){console.error(e);empty(c,"We could not load universities. Check your connection.");}
  }
  async function loadFaculties(){
    var c="#setup-faculty .selection-list"; setLoading(c,"Loading faculties");
    try{renderList(c,await getBy("faculties","universityId",state.universityId),"faculty","ri-building-line");}catch(e){console.error(e);empty(c,"We could not load faculties.");}
  }
  async function loadDepartments(){
    var c="#setup-department .selection-list"; setLoading(c,"Loading departments");
    try{renderList(c,await getBy("departments","facultyId",state.facultyId),"department","ri-book-open-line");}catch(e){console.error(e);empty(c,"We could not load departments.");}
  }
  async function loadLevels(){setLoading("#setup-level .level-grid","Loading levels");try{renderLevels(await getAll("levels"));}catch(e){empty("#setup-level .level-grid","We could not load levels.");}}
  async function loadInterests(){setLoading("#setup-interests .interest-grid","Loading interests");try{renderInterests(await getAll("interests"));}catch(e){empty("#setup-interests .interest-grid","We could not load interests.");}}

  function handleSelection(card){
    var option=card.getAttribute("data-option"), v=value(card); if(!option||!v)return;
    if(option==="university"){state.universityId=v;state.university=label(card);state.facultyId=state.faculty=state.departmentId=state.department=state.level="";state.interests=[];selectSingle(option,v);return;}
    if(option==="faculty"){state.facultyId=v;state.faculty=label(card);state.departmentId=state.department=state.level="";state.interests=[];selectSingle(option,v);return;}
    if(option==="department"){state.departmentId=v;state.department=label(card);state.level="";state.interests=[];selectSingle(option,v);return;}
    if(option==="level"){state.level=label(card);state.levelId=v;selectSingle(option,v);return;}
    if(option==="interest"){var i=state.interests.indexOf(v);if(i>=0){state.interests.splice(i,1);card.classList.remove("selected");}else{state.interests.push(v);card.classList.add("selected");}}
  }
  function validate(target){
    if(target==="setup-faculty"&&!state.universityId)return alert("Please select your university first."),false;
    if(target==="setup-department"&&!state.facultyId)return alert("Please select your faculty first."),false;
    if(target==="setup-level"&&!state.departmentId)return alert("Please select your department first."),false;
    if(target==="setup-interests"&&!state.level)return alert("Please select your level first."),false;
    if(target==="home"&&(!state.universityId||!state.facultyId||!state.departmentId||!state.level||!state.interests.length))return alert("Please complete your selections first."),false;
    return true;
  }
  async function continueTo(target){
    if(!validate(target))return;
    if(target==="setup-faculty") await loadFaculties();
    if(target==="setup-department") await loadDepartments();
    if(target==="setup-level") await loadLevels();
    if(target==="setup-interests") await loadInterests();
    if(target==="home"){
      try {
        var currentUser = window.MESH_FIREBASE && window.MESH_FIREBASE.getCurrentUser && window.MESH_FIREBASE.getCurrentUser();
        var currentProfile = currentUser && window.MESH_FIREBASE.getUserProfile ? await window.MESH_FIREBASE.getUserProfile(currentUser.uid) : null;
        if (currentProfile && currentProfile.launchCodeUniversityId && currentProfile.launchCodeUniversityId !== state.universityId) {
          alert("This launch code is only valid for "+(currentProfile.launchCodeUniversityName||"its assigned university")+". Please select that university to continue.");
          if(window.MESH_NAV) window.MESH_NAV.replace("setup-university");
          return;
        }
      } catch (codeCheckError) { console.error("MESH launch-code university check failed", codeCheckError); alert("We could not validate your university against the launch code. Please try again."); return; }
      var btn=document.querySelector('[data-continue="home"]');if(btn){btn.disabled=true;btn.dataset.old=btn.textContent;btn.textContent="Building your MESH...";}
      try{await window.MESH_FIREBASE.saveOnboardingProfile({universityId:state.universityId,university:state.university,facultyId:state.facultyId,faculty:state.faculty,departmentId:state.departmentId,department:state.department,level:state.level,levelId:state.levelId||"",interests:state.interests.slice()});document.dispatchEvent(new CustomEvent("mesh:onboarding-complete",{detail:state}));if(window.MESH_NAV)window.MESH_NAV.replace("home");}
      catch(e){console.error(e);alert("We couldn't save your MESH profile. Please check your connection and try again.");}
      finally{if(btn){btn.disabled=false;btn.textContent=btn.dataset.old||"Build My MESH";}}
      return;
    }
    if(window.MESH_NAV)window.MESH_NAV.go(target);
  }
  function reset(){Object.keys(state).forEach(function(k){state[k]=Array.isArray(state[k])?[]:"";});document.querySelectorAll(".selected").forEach(function(x){x.classList.remove("selected")});}
  document.addEventListener("click",function(e){var card=e.target.closest(".selection-card[data-option],.level-card[data-option],.interest-chip[data-option]");if(card){e.preventDefault();handleSelection(card);}});
  document.addEventListener("mesh:continue",function(e){if(e.detail&&e.detail.target)continueTo(e.detail.target);});
  document.addEventListener("mesh:screen-change",function(e){if(e.detail.screen==="setup-university")loadUniversities();});
  window.MESH_ONBOARDING={reset:reset,getData:function(){return Object.assign({},state,{interests:state.interests.slice()});}};
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",function(){loadUniversities();});else loadUniversities();
})();
