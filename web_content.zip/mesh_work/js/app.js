/* =========================================================
   MESH — MAIN APP CONTROLLER
   FILE: MESH/js/app.js

   PURPOSE:
   - Start the MESH application
   - Coordinate independent modules
   - Handle global UI helpers
   - Handle global loading state
   - Handle global toast messages
   - Listen for major application events

   IMPORTANT:
   This file should remain SMALL.

   Individual responsibilities belong to:
   - navigation.js
   - auth.js
   - onboarding.js
   - firebase.js
   - content.js
   - search.js
   - notifications.js
   - profile.js
   ========================================================= */

(function () {

  "use strict";


  /* =========================================================
     1. APP STATE
     ========================================================= */

  var state = {

    ready: false,

    initialized: false

  };


  /* =========================================================
     2. GLOBAL LOADER
     ========================================================= */

  function showLoader(
    message
  ) {

    var loader =
      document.querySelector(
        "#global-loader"
      );


    if (!loader) {
      return;
    }


    loader.classList.remove(
      "hidden"
    );


    var text =
      loader.querySelector(
        "[data-loader-text]"
      );


    if (text && message) {

      text.textContent =
        message;

    }

  }


  function hideLoader() {

    var loader =
      document.querySelector(
        "#global-loader"
      );


    if (!loader) {
      return;
    }


    loader.classList.add(
      "hidden"
    );

  }


  /* =========================================================
     3. GLOBAL TOAST
     ========================================================= */

  function toast(
    message,
    type
  ) {

    if (!message) {
      return;
    }


    var existing =
      document.querySelector(
        ".mesh-toast"
      );


    if (existing) {

      existing.remove();

    }


    var element =
      document.createElement(
        "div"
      );


    element.className =
      "mesh-toast";


    if (type) {

      element.classList.add(
        "toast-" + type
      );

    }


    element.innerHTML = `

      <span class="mesh-toast-icon">

        <i class="${
          getToastIcon(type)
        }"></i>

      </span>

      <span class="mesh-toast-message">
        ${escapeHTML(message)}
      </span>

    `;


    document.body.appendChild(
      element
    );


    requestAnimationFrame(
      function () {

        element.classList.add(
          "show"
        );

      }
    );


    setTimeout(
      function () {

        element.classList.remove(
          "show"
        );


        setTimeout(
          function () {

            if (element.parentNode) {

              element.parentNode.removeChild(
                element
              );

            }

          },
          250
        );

      },
      2800
    );

  }


  function getToastIcon(
    type
  ) {

    var icons = {

      success:
        "ri-checkbox-circle-line",

      error:
        "ri-error-warning-line",

      warning:
        "ri-alert-line",

      info:
        "ri-information-line"

    };


    return (
      icons[type] ||
      "ri-information-line"
    );

  }


  function escapeHTML(
    value
  ) {

    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  }


  /* =========================================================
     4. GLOBAL ERROR HANDLER
     ========================================================= */

  function setupErrorHandling() {

    window.addEventListener(
      "error",
      function (event) {

        console.error(
          "MESH Error:",
          event.error ||
          event.message
        );

      }
    );


    window.addEventListener(
      "unhandledrejection",
      function (event) {

        console.error(
          "MESH Promise Error:",
          event.reason
        );

      }
    );

  }


  /* =========================================================
     5. APPLICATION EVENTS
     ========================================================= */

  function setupAppEvents() {


    /* -------------------------------------------------------
       Firebase ready
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:firebase-ready",
      function () {

        console.log(
          "MESH: Firebase ready."
        );

      }
    );


    /* -------------------------------------------------------
       Authentication success
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:auth-success",
      function (event) {

        console.log(
          "MESH: User authenticated.",
          event.detail || {}
        );

        hideLoader();

      }
    );


    /* -------------------------------------------------------
       Authentication logout
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:auth-logout",
      function () {

        console.log(
          "MESH: User signed out."
        );

      }
    );


    /* -------------------------------------------------------
       Onboarding completed
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:onboarding-complete",
      function (event) {

        console.log(
          "MESH: Onboarding completed.",
          event.detail || {}
        );

      }
    );


    /* -------------------------------------------------------
       Content ready
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:content-ready",
      function () {

        console.log(
          "MESH: Content ready."
        );

      }
    );


    /* -------------------------------------------------------
       New notification
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:new-notification",
      function () {

        /*
          This is intentionally lightweight.

          Later this can trigger:
          - push notification
          - sound
          - badge animation
        */

      }
    );


    /* -------------------------------------------------------
       Profile updated
       ------------------------------------------------------- */

    document.addEventListener(
      "mesh:profile-updated",
      function () {

        console.log(
          "MESH: Profile updated."
        );

      }
    );

  }


  /* =========================================================
     6. GLOBAL ACTIONS
     ========================================================= */

  function setupGlobalActions() {

    document.addEventListener(
      "click",
      function (event) {

        var button =
          event.target.closest(
            "[data-action]"
          );


        if (!button) {
          return;
        }


        var action =
          button.getAttribute(
            "data-action"
          );


        /*
          Individual modules already handle
          their own specific actions.

          This section is only for actions
          that truly belong globally.
        */

        if (
          action ===
          "show-loader"
        ) {

          showLoader(
            button.getAttribute(
              "data-loader-message"
            ) ||
            "Loading..."
          );

        }


        if (
          action ===
          "hide-loader"
        ) {

          hideLoader();

        }

      }
    );

  }


  /* =========================================================
     7. PREVENT DOUBLE SUBMISSION
     ========================================================= */

  function setupFormProtection() {

    document.addEventListener(
      "submit",
      function (event) {

        var form =
          event.target;


        if (!form ||
            !form.matches("form")) {

          return;

        }


        /*
          Auth module handles its own
          loading state, so don't interfere
          with auth forms.
        */

        if (
          form.closest(
            "#auth-screen"
          )
        ) {

          return;

        }


        if (
          form.dataset.submitting ===
          "true"
        ) {

          event.preventDefault();

          return;

        }


        form.dataset.submitting =
          "true";


        setTimeout(
          function () {

            form.dataset.submitting =
              "false";

          },
          1000
        );

      }
    );

  }


  /* =========================================================
     8. CONNECTION STATUS
     ========================================================= */

  function setupConnectionStatus() {

    function updateConnection() {

      document.body.classList.toggle(
        "offline",
        !navigator.onLine
      );


      document.body.classList.toggle(
        "online",
        navigator.onLine
      );

    }


    window.addEventListener(
      "online",
      function () {

        updateConnection();

        toast(
          "You're back online.",
          "success"
        );

      }
    );


    window.addEventListener(
      "offline",
      function () {

        updateConnection();

        toast(
          "You're offline. Some features may be unavailable.",
          "warning"
        );

      }
    );


    updateConnection();

  }


  /* =========================================================
     9. APP READY
     ========================================================= */

  function markReady() {

    state.ready =
      true;


    state.initialized =
      true;


    document.body.classList.add(
      "mesh-ready"
    );


    document.dispatchEvent(
      new CustomEvent(
        "mesh:ready"
      )
    );


    console.log(
      "MESH application ready."
    );

  }


  /* =========================================================
     10. INITIALIZATION
     ========================================================= */

  function initApp() {

    if (
      state.initialized
    ) {

      return;

    }


    console.log(
      "MESH application starting..."
    );


    setupErrorHandling();

    setupAppEvents();

    setupGlobalActions();

    setupFormProtection();

    setupConnectionStatus();

    markReady();

  }


  /* =========================================================
     11. PUBLIC API
     ========================================================= */

  window.MESH_APP = {

    state: state,

    toast: toast,

    showLoader:
      showLoader,

    hideLoader:
      hideLoader,

    ready:
      function () {
        return state.ready;
      }

  };


  /* =========================================================
     12. START
     ========================================================= */

  if (
    document.readyState ===
    "loading"
  ) {

    document.addEventListener(
      "DOMContentLoaded",
      initApp
    );

  } else {

    initApp();

  }


})();