/* MESH: allow subtle motion only during initial entry, through first Home display. */
(function () {
  'use strict';

  var finished = false;
  var homeTimer = null;

  function lockMotion() {
    if (finished) return;
    finished = true;
    document.body.classList.remove('mesh-entry-motion', 'mesh-home-entry');
    document.body.classList.add('mesh-motion-locked');
  }

  function onScreenChange(event) {
    if (finished || !event || !event.detail) return;
    var screen = event.detail.screen;
    if (screen !== 'home') return;

    document.body.classList.remove('mesh-entry-motion');
    document.body.classList.add('mesh-motion-locked', 'mesh-home-entry');
    if (homeTimer) window.clearTimeout(homeTimer);
    homeTimer = window.setTimeout(function () {
      document.body.classList.remove('mesh-home-entry');
      finished = true;
    }, 480);
  }

  function init() {
    var home = document.querySelector('#home[data-screen="home"]');
    if (!home) {
      document.body.classList.add('mesh-motion-locked');
      finished = true;
      return;
    }
    document.body.classList.add('mesh-entry-motion');
    document.addEventListener('mesh:screen-change', onScreenChange);

    /* If this page is restored directly into Home, don't animate the app. */
    if (home.classList.contains('active')) lockMotion();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
