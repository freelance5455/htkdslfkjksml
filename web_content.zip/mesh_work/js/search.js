/* =========================================================
   MESH — SEARCH & DISCOVER
   FILE: MESH/js/search.js

   PURPOSE:
   - Global search
   - Discover category filtering
   - Search MESH content
   - Render search results
   - Open selected content
   - Works with MESH_CONTENT
   ========================================================= */

(function () {

  "use strict";

  /* =========================================================
     1. STATE
     ========================================================= */

  var state = {
    query: "",
    category: "all",
    results: [],
    isSearching: false
  };


  /* =========================================================
     2. HELPERS
     ========================================================= */

  function getContentState() {

    if (
      window.MESH_CONTENT &&
      window.MESH_CONTENT.state
    ) {
      return window.MESH_CONTENT.state;
    }

    return {
      news: [],
      announcements: [],
      events: [],
      opportunities: [],
      resources: []
    };
  }


  function normalize(value) {

    return String(value || "")
      .toLowerCase()
      .trim();

  }


  function escapeHTML(value) {

    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  }


  function getSearchText(item) {

    return [
      item.title,
      item.name,
      item.description,
      item.content,
      item.message,
      item.category,
      item.organization,
      item.organizer,
      item.type,
      item.code,
      item.course,
      item.department
    ]
      .filter(Boolean)
      .join(" ");

  }


  /* =========================================================
     3. CONTENT COLLECTION
     ========================================================= */

  function buildContentList() {

    var content = getContentState();

    var groups = [
      {
        type: "news",
        label: "News",
        items: content.news || []
      },
      {
        type: "announcements",
        label: "Announcements",
        items: content.announcements || []
      },
      {
        type: "events",
        label: "Events",
        items: content.events || []
      },
      {
        type: "opportunities",
        label: "Opportunities",
        items: content.opportunities || []
      },
      {
        type: "resources",
        label: "Resources",
        items: content.resources || []
      }
    ];

    var output = [];

    groups.forEach(function (group) {

      group.items.forEach(function (item) {

        output.push({
          data: item,
          type: group.type,
          label: group.label
        });

      });

    });

    return output;

  }


  /* =========================================================
     4. SEARCH
     ========================================================= */

  function performSearch(query, category) {

    query = normalize(query);
    category = category || "all";

    state.query = query;
    state.category = category;
    state.isSearching = true;

    var content = buildContentList();

    var filtered = content.filter(function (entry) {

      /* Category filter */
      if (
        category !== "all" &&
        entry.type !== category
      ) {
        return false;
      }

      /* No query = show category */
      if (!query) {
        return true;
      }

      var searchableText = normalize(
        getSearchText(entry.data)
      );

      return searchableText.indexOf(query) !== -1;

    });

    state.results = filtered;

    renderResults();

    return filtered;

  }


  /* =========================================================
     5. RESULT RENDERING
     ========================================================= */

  function renderResults() {

    var containers = document.querySelectorAll(
      "[data-search-results], .search-results"
    );

    if (!containers.length) {
      return;
    }

    containers.forEach(function (container) {

      container.innerHTML = "";

      if (!state.results.length) {

        container.innerHTML = `
          <div class="empty-content">
            <div class="empty-icon">
              <i class="ri-search-line"></i>
            </div>

            <h3>No results found</h3>

            <p>
              Try another search or choose a different category.
            </p>
          </div>
        `;

        return;
      }


      state.results.forEach(function (entry) {

        var item = entry.data;

        var title =
          item.title ||
          item.name ||
          "Untitled";

        var description =
          item.description ||
          item.content ||
          item.message ||
          "";

        var category =
          item.category ||
          entry.label;


        var result = document.createElement("article");

        result.className = "search-result";

        result.setAttribute(
          "data-search-result",
          "true"
        );

        result.innerHTML = `

          <div class="search-result-icon">
            <i class="${getTypeIcon(entry.type)}"></i>
          </div>

          <div class="search-result-content">

            <span class="search-result-type">
              ${escapeHTML(category)}
            </span>

            <h3>
              ${escapeHTML(title)}
            </h3>

            ${
              description
                ? `
                  <p>
                    ${escapeHTML(
                      truncate(description, 120)
                    )}
                  </p>
                `
                : ""
            }

          </div>

          <div class="search-result-arrow">
            <i class="ri-arrow-right-s-line"></i>
          </div>

        `;

        result.addEventListener(
          "click",
          function () {

            openResult(entry);

          }
        );

        container.appendChild(result);

      });

    });

  }


  /* =========================================================
     6. RESULT ICONS
     ========================================================= */

  function getTypeIcon(type) {

    var icons = {

      news:
        "ri-newspaper-line",

      announcements:
        "ri-megaphone-line",

      events:
        "ri-calendar-event-line",

      opportunities:
        "ri-briefcase-4-line",

      resources:
        "ri-book-open-line",

      communities:
        "ri-group-line"

    };

    return icons[type] || "ri-search-line";

  }


  /* =========================================================
     7. TEXT TRUNCATION
     ========================================================= */

  function truncate(text, limit) {

    text = String(text || "");

    if (text.length <= limit) {
      return text;
    }

    return text.substring(0, limit).trim() + "...";

  }


  /* =========================================================
     8. OPEN SEARCH RESULT
     ========================================================= */

  function openResult(entry) {

    var item = entry.data;

    /* Use MESH_CONTENT if available */

    if (
      window.MESH_CONTENT &&
      typeof window.MESH_CONTENT.openContent === "function"
    ) {

      window.MESH_CONTENT.openContent(
        item,
        entry.type
      );

      return;
    }


    /* Fallback event */

    document.dispatchEvent(
      new CustomEvent(
        "mesh:content-open",
        {
          detail: {
            item: item,
            type: entry.type
          }
        }
      )
    );

  }


  /* =========================================================
     9. SEARCH INPUT
     ========================================================= */

  function setupSearchInput() {

    var inputs = document.querySelectorAll(
      "[data-search], .global-search input"
    );

    inputs.forEach(function (input) {

      input.addEventListener(
        "input",
        function () {

          performSearch(
            input.value,
            state.category
          );

        }
      );


      input.addEventListener(
        "keydown",
        function (event) {

          if (event.key === "Enter") {

            event.preventDefault();

            performSearch(
              input.value,
              state.category
            );

          }

        }
      );

    });

  }


  /* =========================================================
     10. SEARCH BUTTON
     ========================================================= */

  function setupSearchButtons() {

    var buttons = document.querySelectorAll(
      "[data-action='search']"
    );

    buttons.forEach(function (button) {

      button.addEventListener(
        "click",
        function () {

          var input =
            document.querySelector(
              "[data-search], .global-search input"
            );

          if (!input) {
            return;
          }

          performSearch(
            input.value,
            state.category
          );

          input.focus();

        }
      );

    });

  }


  /* =========================================================
     11. CATEGORY FILTERS
     ========================================================= */

  function setupCategoryFilters() {

    var filters = document.querySelectorAll(
      "[data-search-category], [data-category-filter]"
    );

    filters.forEach(function (filter) {

      filter.addEventListener(
        "click",
        function () {

          var category =
            filter.getAttribute(
              "data-search-category"
            ) ||
            filter.getAttribute(
              "data-category-filter"
            ) ||
            "all";


          state.category = category;


          /* Active state */

          filters.forEach(function (item) {

            item.classList.remove("active");
            item.classList.remove("selected");

          });

          filter.classList.add("active");
          filter.classList.add("selected");


          /* Search */

          var input =
            document.querySelector(
              "[data-search], .global-search input"
            );

          performSearch(
            input ? input.value : "",
            category
          );

        }
      );

    });

  }


  /* =========================================================
     12. DISCOVER CATEGORY CARDS
     ========================================================= */

  function setupDiscoverCards() {

    var cards = document.querySelectorAll(
      "[data-discover-category]"
    );

    cards.forEach(function (card) {

      card.addEventListener(
        "click",
        function () {

          var category =
            card.getAttribute(
              "data-discover-category"
            );

          if (!category) {
            return;
          }


          state.category = category;


          var input =
            document.querySelector(
              "[data-search], .global-search input"
            );

          if (input) {
            input.value = "";
          }


          performSearch(
            "",
            category
          );


          /* Optional navigation */

          document.dispatchEvent(
            new CustomEvent(
              "mesh:discover-category",
              {
                detail: {
                  category: category
                }
              }
            )
          );

        }
      );

    });

  }


  /* =========================================================
     13. CLEAR SEARCH
     ========================================================= */

  function setupClearSearch() {

    var buttons = document.querySelectorAll(
      "[data-action='clear-search']"
    );

    buttons.forEach(function (button) {

      button.addEventListener(
        "click",
        function () {

          var input =
            document.querySelector(
              "[data-search], .global-search input"
            );

          if (input) {
            input.value = "";
            input.focus();
          }

          state.query = "";

          performSearch(
            "",
            state.category
          );

        }
      );

    });

  }


  /* =========================================================
     14. SEARCH WHEN CONTENT UPDATES
     ========================================================= */

  function setupContentRefresh() {

    document.addEventListener(
      "mesh:content-ready",
      function () {

        if (
          state.query ||
          state.category !== "all"
        ) {

          performSearch(
            state.query,
            state.category
          );

        }

      }
    );


    document.addEventListener(
      "mesh:firebase-ready",
      function () {

        if (
          state.query ||
          state.category !== "all"
        ) {

          performSearch(
            state.query,
            state.category
          );

        }

      }
    );

  }


  /* =========================================================
     15. PUBLIC SEARCH API
     ========================================================= */

  function search(query, category) {

    return performSearch(
      query || "",
      category || "all"
    );

  }


  function clear() {

    state.query = "";
    state.category = "all";
    state.results = [];

    var input =
      document.querySelector(
        "[data-search], .global-search input"
      );

    if (input) {
      input.value = "";
    }

    renderResults();

  }


  function getState() {

    return {
      query: state.query,
      category: state.category,
      results: state.results
    };

  }


  /* =========================================================
     16. INITIALIZATION
     ========================================================= */

  function initSearch() {

    setupSearchInput();
    setupSearchButtons();
    setupCategoryFilters();
    setupDiscoverCards();
    setupClearSearch();
    setupContentRefresh();

  }


  /* =========================================================
     17. PUBLIC API
     ========================================================= */

  window.MESH_SEARCH = {

    search: search,
    clear: clear,
    state: getState,
    refresh: function () {
      performSearch(
        state.query,
        state.category
      );
    }

  };


  /* =========================================================
     18. START
     ========================================================= */

  if (
    document.readyState === "loading"
  ) {

    document.addEventListener(
      "DOMContentLoaded",
      initSearch
    );

  } else {

    initSearch();

  }


})();