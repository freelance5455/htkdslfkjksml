# MESH Admin analytics, CSV and theme follow-up

## Changes
- Dashboard adds a responsive SVG line chart for dated member, announcement and opportunity records, alongside the existing current-total collection chart.
- The chart reads only collections allowed for the signed-in admin, caps each query at 1,500 documents, recognizes common timestamp field names, and clearly reports when timestamps or read permissions are missing. It does not fabricate historical data from current totals.
- Table CSV export now includes all currently loaded rows, not only rows visible on the current pagination page or matching the search text. It also supports the legacy `msSaveOrOpenBlob` browser API and keeps the generated object URL alive longer for slower mobile downloads.
- Global theme runtime now updates additional semantic CSS variables and adds member-app/auth overrides for common surfaces, text, buttons, inputs, navigation, category tiles, cards, and the hero accent.

## Deploy
1. Back up the currently hosted MESH folder.
2. Upload the contents of the included `MESH` folder, keeping its existing paths.
3. Do not replace Firestore rules blindly. Review `firestore.rules` against the current deployed rules, then publish the rules only after confirming your Super Admin and regular-admin access model.
4. Sign in as Super Admin; test dashboard trend chart, export CSV on each data table, and publish a theme preset.
5. Open the member app in a fresh tab or reload it, verify home/discover/community/profile/auth screens and a form input, then repeat after changing to a second palette.
6. Sign in as a regular admin and verify its assigned pages still work, CSV download works, and System Health remains hidden/inaccessible.

## Test limitations
Local syntax, reference, and archive checks are performed before packaging. Live Firebase queries, deployed Firestore security rules, Android browser download behavior, and visual theme coverage require testing against the actual hosted project and device. Trend charts only become meaningful where records contain recognized timestamps; records without dates are not backfilled or guessed.
