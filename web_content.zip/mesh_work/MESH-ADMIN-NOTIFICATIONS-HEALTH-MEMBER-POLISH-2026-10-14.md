# MESH upgrade — notifications, deletion, System Health and member UI

## Implemented in this release

### Super Admin notification clearing
- Added **Clear all notifications** to the existing Super Admin System Health panel.
- Requires explicit confirmation, deletes notification documents in Firestore batches of 400, reports the number removed, and attempts to append an admin audit event.
- Restricted in the UI to an active Super Admin. Existing Firestore rules already allow an active Super Admin to delete all notification documents, so no rules were loosened or changed for this action.
- New notifications continue to be created normally after the clear operation.

### Official content deletion and cleanup
- Added a permanent Delete action next to Edit in the official Content table.
- Requires confirmation and checks a non-Super Admin's assigned university before touching linked records.
- Deletes linked notification documents by `contentId` and cleans up legacy notification records by matching content type, title, and university.
- New official-content notifications now include `contentId` and `contentCollection` to make future cleanup deterministic.
- Disabling existing official content also attempts to remove related notifications so stale notices do not remain visible.
- Editing an already-published post no longer automatically creates another notification; a new notification is created for a new post or a post re-enabled from disabled/draft state.
- Successful permanent deletions are written to `adminAuditLogs` where the current rules permit the write.

### Member notifications
- Added a Firestore real-time listener for the notification screen. If notifications are cleared or removed while the member is viewing that screen, it reloads the list. The screen also reloads when opened normally.
- Personal `users/{uid}/notificationReads` documents are read-state markers, not notification content; clearing the global `notifications` collection does not need to delete those markers.

### Graphical System Health
- Preserved the existing System Health panel and its existing checks, but upgraded it to graphical status cards with service icons, state pills, an at-a-glance summary, counts, and last-checked time.
- Checks cover Firebase initialization/project ID, current authentication, Super Admin authorization, university reads, student-record reads, notification reads, official content reads, and admin identity.
- Cloud Functions deployment/billing and Storage bucket access are explicitly shown as requiring review because the project has no dedicated safe health endpoint for those checks. They are not falsely reported as healthy.

### Member UI polish
- Added responsive, theme-aware refinements to the existing member brand stylesheet: card hierarchy, section spacing, typography wrapping, safe-area bottom navigation, image containment, and narrow-screen layout guards.
- These changes target the member app styles only; the admin workspace's existing visual design is preserved except for the requested buttons and System Health presentation.

## Firestore rules

No Firestore rule changes were made. The existing rules already allow active Super Admins to delete notification records and to delete official content they are authorized to manage. Keeping the rules unchanged avoids unnecessary security risk. If the live project's published rules differ from this ZIP, deploy/verify the intended rules before using destructive actions.

## Verification performed

- JavaScript syntax checks (`node --check`) for the modified content manager, diagnostics and member notification scripts.
- ZIP integrity check.
- Static review of notification rules and official content collection rules.

## Live-environment limitations

This release has not been tested against the user's live Firebase project or real member sessions. The clear/delete actions must be verified in a controlled test with current Firestore rules. Browser-only checks cannot confirm deployed Cloud Functions status, billing, Storage bucket permissions, actual app hosting, or production behaviour. A successful syntax check is not a substitute for live integration testing.
