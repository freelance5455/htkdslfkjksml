# MESH pilot OCR automation

## What this upgrade does
- Registration still starts with the pilot invitation code (the existing sign-up step).
- The private verification form is grouped into clear student-details and review sections.
- Image documents are scanned locally for an early text-match hint; PDF/unclear documents are sent for manual review.
- The trusted Firebase Cloud Function re-reads the uploaded image and performs OCR server-side. A readable supported image with the submitted matric number detected at confidence >= 75 is automatically approved and updates both `verificationRequests/{uid}` and `users/{uid}`. Other cases remain pending for the Super Admin queue.
- The Super Admin dashboard displays OCR results and prioritises text-match cases in the review queue.
- The bottom navigation is Home, News, Alerts, Profile. Discover remains reachable from Home and is not a bottom-navigation item.

## Required deployment step — not performed by packaging this ZIP
Firebase Cloud Functions deployment generally requires the Firebase Blaze (pay-as-you-go) plan. Check current Firebase pricing and enable billing only if you approve it. The function has not been deployed from this ZIP and cannot run until deployed.

From the project root:

```bash
cd functions
npm install
cd ..
firebase deploy --only functions:processPilotVerification
```

Ensure Firebase CLI is authenticated to project `mesh-9a4f1` before deploying. Review expected billing and Tesseract runtime size first. Do not deploy to a production project without testing with non-sensitive sample documents.

## Security and limitations
- The browser-provided OCR fields are untrusted; the Cloud Function performs its own OCR before deciding.
- OCR matching confirms text presence only, not that ABU issued the document or that the uploader is its owner. A borrowed or edited document can pass. Manual review remains the fallback for PDFs, unsupported formats, low-confidence results and processing errors.
- The function intentionally handles images only. Admission-letter PDFs remain manual-review cases until a PDF rasterization/OCR path is added and tested.
- Store verification documents privately and define a retention/deletion policy. Do not expose proof URLs publicly.
- The current Firestore/Storage rules must be deployed alongside the app if changed. Test rules in the Firebase Emulator Suite before production.
