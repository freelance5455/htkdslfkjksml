# MESH Brand and Theme Consistency Fix

- Restored the supplied transparent MESH network symbol as a theme-tinted image mask.
- Set Royal Blue as the initial palette before styles paint to prevent legacy green flash.
- Added a local theme cache so the last approved palette paints immediately, then Firestore remains the source of truth.
- Migrated the former default emerald palette to Royal Blue rather than re-applying it.
- Added final member and admin brand-system styles so Home, auth, Opportunities, cards, controls, and dark mode use shared theme variables.
- Reworked the Home campus banner and its CTA to use the royal-blue branded treatment.
- Changed the Super Admin theme editor default/preset label to MESH Royal Blue.

Before deployment: preview on Android, confirm Firestore `appSettings/globalTheme` rules and publish the new Royal Blue palette from the Super Admin theme settings.
