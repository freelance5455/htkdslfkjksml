# MESH Member Experience Upgrade

This update continues from the existing MESH project and preserves the current HTML/CSS/JavaScript architecture and Firebase integration.

## Included in this pass

- Coordinated mobile-first visual refresh for Home, Discover, Community, Notifications, Profile and Settings.
- Improved typography, spacing, card hierarchy, navigation, focus visibility, touch interactions, and safe-area handling.
- Added functional Discover story save controls and Home opportunity save controls.
- Added a Saved items view from Profile. Saves are stored locally per signed-in UID in the current browser/device; this pass does not add a new Firestore collection for bookmarks.
- Added a working Mark all read control for notifications. Read state is local to the current browser/device and does not change shared notification documents in Firestore.
- Community tabs now switch between a community directory sourced from the existing `communities` collection and the My Communities empty state. Joining/membership writes were intentionally not invented because the current project does not expose a verified membership schema.
- Home quick links and See all actions apply the appropriate Discover filter.
- Existing auth, onboarding, profile, content, theme runtime, and Firebase modules remain in place.

## Validation performed

- `node --check` passed for all JavaScript files in `js/` and `admin/js/`.
- All 21 local script/stylesheet references from `index.html` resolve.
- No duplicate IDs were detected in `index.html`.
- ZIP integrity check passed.

## Requires live/device testing

This environment does not have the user's authenticated Firebase session or Android browser, so these checks are not claimed as passed:

- Sign-in/sign-up and onboarding with the real Firebase project.
- Firestore read/write permissions and content visibility by university.
- Profile picture upload and password changes.
- Actual appearance across all Android screen sizes and theme colors.
- External links and file/resource opening on-device.

## Deploy

1. Back up the current hosted project.
2. Extract the ZIP and upload the contents of `MESH/` while preserving folder structure.
3. Keep the existing Firebase project/configuration; do not replace it with another project.
4. Test sign-in, onboarding, Home, Discover filters/search, save/remove saved items, Community, Notifications, profile editing, settings/theme, sign-out, and reload.
5. Review any Firestore/Storage rule changes separately before deploying; this UI upgrade does not require new Firestore collections for local saved items/read state.
