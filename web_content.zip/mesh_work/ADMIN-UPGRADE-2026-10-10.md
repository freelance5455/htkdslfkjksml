# MESH Admin coordinated upgrade — 2026-10-10

## Based on
`MESH-ADMIN-WORKSPACE-POLISHED.zip`, extracted and inspected before edits.
The project is a static HTML/CSS/JavaScript app using Firebase Auth and Firestore project `mesh-9a4f1`.

## Implemented in this pass
- Added reusable search controls, result counts, client-side pagination, and CSV export to admin data tables.
- Added dashboard collection overview bars based on current Firestore-backed count cards. The UI explicitly avoids presenting current totals as historical growth data.
- Added a member detail view that displays existing table fields read-only.
- Added breadcrumb-like workspace navigation and responsive styles for new admin controls.
- Added a best-effort audit event helper for opening selected admin actions, plus append-only `adminAuditLogs` rules for active Super Admins.
- Fixed Super Admin role normalization (`super-admin` / `superadmin` now normalize to `super_admin`) and fixed the sign-out method call.
- Preserved existing pages, collection names, module entry points, and the global theme manager.

## Important scope limits
This is a safe coordinated improvement, not proof that all 67 requested capabilities are fully implemented. Several requested functions require backend/schema decisions and must not be faked:
- Historical trend charts need reliable timestamp fields and aggregation strategy; the current charts show current totals only.
- Suspension/reactivation needs a defined account-status field and rules plus decisions about Firebase Authentication account disabling (which cannot be safely performed from a static client without a trusted server/admin SDK).
- Secure bulk user actions and role changes need a trusted backend or carefully constrained rules. Existing role management is retained; this pass does not add insecure client-side privilege escalation.
- CSV import, scheduled publishing, delivery receipts, reports based on historical events, maintenance mode, and full moderation audit integration need their own schema/workflow wiring where absent.
- Search and pagination are client-side for the currently loaded result set; larger datasets should move to Firestore query pagination and indexes.
- Audit event creation is best-effort and only permitted to Super Admins by the added rules. Publishing rules and verifying role boundaries is required before relying on logs.

## Deployment
1. Keep the prior ZIP as a rollback copy.
2. Upload the contents of `MESH/` to the same host while preserving relative paths.
3. Review and publish `firestore.rules` to Firebase project `mesh-9a4f1`.
4. Test sign-in, sign-out, each admin role, student read paths, theme publish/read, table search/pagination/export, and permissions using separate test accounts.
5. Never use broad rules such as `allow read, write: if true`.

## Validation performed in this workspace
- JavaScript syntax checks were run with Node.js for all admin JS files.
- ZIP archive integrity was checked after packaging.
- Live Firebase authentication, Firestore permissions, deployment, and real-device interactions were not available here and are not claimed as tested.


## Follow-up fixes: CSV export and System Health visibility

- CSV export now exports the table header and all rows matching the current search query, not only rows visible on the current pagination page. It retains quoted CSV cells, UTF-8 BOM for spreadsheet compatibility, spreadsheet-formula safety for text cells, and delays object-URL cleanup to allow mobile downloads to start. Export errors are surfaced beside the button.
- System connection health is hidden from non-Super-Admin workspaces and the diagnostics runner refuses to run for other roles. This is UI/diagnostic visibility control, not a replacement for Firestore Security Rules; backend rules must continue to enforce actual data access.
- Validation performed for this follow-up: JavaScript syntax checks and archive integrity checks. A real Android browser download and live Firebase role test still need to be performed in the deployed app.
