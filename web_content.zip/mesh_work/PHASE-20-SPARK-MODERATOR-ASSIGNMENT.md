# MESH Phase 20 — Spark-compatible moderator assignment

## What changed
- The Admin > Announcement moderators form now finds a registered MESH profile by email and writes the assignment directly to Firestore.
- Revoke uses a direct Firestore update.
- Assignment and audit event are written in one batch.
- `firestore.rules` allows only active Super Admins to create/update/revoke valid moderator assignment documents. Ordinary admins and students remain denied.
- Existing Cloud Functions source is retained for projects that use Blaze; the assignment UI no longer calls those functions.

## Required setup
1. Back up the currently deployed Firestore rules.
2. Publish the included `firestore.rules` to the `mesh-9a4f1` Firebase project's Firestore Rules (Firebase Console > Firestore Database > Rules), or deploy the rules file using the Firebase CLI. This rules update is required; replacing the website files alone is not enough.
3. Publish the updated admin site files.
4. Sign in as an active Super Admin, assign a registered user's email, select university and scope, then test revoke.
5. Confirm a student account cannot create or change `moderatorAssignments`.

## Plan limitation
This change removes the Cloud Functions dependency for moderator assignment/revocation only. Scoped moderator announcement publishing still uses `publishScopedAnnouncement` in Cloud Functions. On the Spark plan, that publishing workflow needs a separate Firestore-only implementation or a Firebase plan that supports Cloud Functions deployment. No live deployment was performed as part of this archive.

## Verification
- `node --check admin/js/moderators.js` passed.
- `npm run test:static` passed through Phase 20.
- Firebase Emulator rules tests were not run in this environment; run `npm run test:rules` after installing dependencies and Firebase CLI.
