'use strict';
const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const logger = require('firebase-functions/logger');
const admin = require('firebase-admin');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs/promises');
const { createWorker } = require('tesseract.js');
if (!admin.apps.length) admin.initializeApp();
const db = admin.firestore();

// Scoped moderator publishing. Client UI is never the authority: every request
// re-reads the active assignment and user profile from Firestore.
function isCentralAdminData(data) {
  return !!data && data.active === true && ['super_admin','super-admin','superadmin','university_admin','admin','content_manager'].includes(data.role);
}
function isSuperAdminData(data) {
  return !!data && data.active === true && ['super_admin','super-admin','superadmin'].includes(data.role);
}
function cleanText(value, max, field) {
  const out = String(value || '').trim();
  if (!out || out.length > max) throw new HttpsError('invalid-argument', `${field} is required and must be ${max} characters or fewer.`);
  return out;
}
function audienceField(scope) {
  if (!['university','faculty','department','class'].includes(scope)) throw new HttpsError('invalid-argument', 'Choose university, faculty, department, or level scope.');
  return scope;
}
exports.assignMeshModerator = onCall({ region: 'europe-west1', maxInstances: 5 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please sign in.');
  const adminSnap = await db.collection('admins').doc(request.auth.uid).get();
  if (!adminSnap.exists || !isSuperAdminData(adminSnap.data())) throw new HttpsError('permission-denied', 'Only an active Super Admin can assign moderators.');
  const email = cleanText(request.data && request.data.email, 254, 'User email').toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpsError('invalid-argument', 'Enter a valid account email address.');
  const scopeType = audienceField(String(request.data && request.data.scopeType || ''));
  const universityId = cleanText(request.data && request.data.universityId, 128, 'University');
  let scopeId = scopeType === 'university' ? universityId : cleanText(request.data && request.data.scopeId, 128, 'Assigned faculty/department/level');
  let authUser;
  try { authUser = await admin.auth().getUserByEmail(email); } catch (e) { throw new HttpsError('not-found', 'No Firebase Authentication account exists for that email. Ask the user to register first.'); }
  const uid = authUser.uid;
  const userSnap = await db.collection('users').doc(uid).get();
  if (!userSnap.exists) throw new HttpsError('not-found', 'That email has no MESH student profile yet.');
  const user = userSnap.data() || {};
  if (String(user.email || authUser.email || '').toLowerCase() !== email) throw new HttpsError('failed-precondition', 'The email does not match the MESH profile.');
  // Older MESH profiles store academic values as university/faculty/department/level
  // strings, while newer records may use *Id fields. Accept either the document ID
  // or the corresponding catalog name/code, but never assign across universities.
  const norm = value => String(value == null ? '' : value).trim().toLowerCase();
  async function catalogMatches(collection, id, profileValues) {
    const snap = await db.collection(collection).doc(id).get();
    const data = snap.exists ? snap.data() || {} : {};
    const allowed = [id, data.name, data.title, data.code, data.shortName].map(norm).filter(Boolean);
    return profileValues.map(norm).filter(Boolean).some(value => allowed.includes(value));
  }
  const universityValues = [user.universityId, user.universityID, user.university];
  let universityMatches = universityValues.map(norm).includes(norm(universityId));
  if (!universityMatches) universityMatches = await catalogMatches('universities', universityId, universityValues);
  if (!universityMatches) throw new HttpsError('failed-precondition', 'The moderator profile university does not match the selected university. Check the student profile and university selection.');
  const scopeCollection = scopeType === 'faculty' ? 'faculties' : scopeType === 'department' ? 'departments' : scopeType === 'class' ? 'levels' : '';
  if (scopeType !== 'university') {
    const profileValues = scopeType === 'faculty'
      ? [user.facultyId, user.facultyID, user.faculty]
      : scopeType === 'department'
        ? [user.departmentId, user.departmentID, user.department]
        : [user.levelId, user.levelID, user.level, user.class];
    let scopeMatches = profileValues.map(norm).includes(norm(scopeId));
    if (!scopeMatches) scopeMatches = await catalogMatches(scopeCollection, scopeId, profileValues);
    if (!scopeMatches) throw new HttpsError('failed-precondition', `The user's profile does not match the selected ${scopeType === 'class' ? 'level' : scopeType}. Check their academic profile and try again.`);
  }
  const assignment = { uid, email, role: 'moderator', active: true, scopeType, scopeId, universityId, assignedBy: request.auth.uid, updatedAt: admin.firestore.FieldValue.serverTimestamp(), createdAt: admin.firestore.FieldValue.serverTimestamp() };
  await db.collection('moderatorAssignments').doc(uid).set(assignment, { merge: true });
  // Audit logging must not make a successful assignment look like a failed one.
  try {
    await db.collection('adminAuditLogs').add({ actorUid: request.auth.uid, action: 'assign_mesh_moderator', targetUid: uid, targetEmail: email, scopeType, scopeId, universityId, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  } catch (auditError) {
    logger.error('Moderator assignment saved but audit log write failed', { uid, code: auditError && auditError.code });
  }
  return { ok: true, uid, scopeType, scopeId, universityId };
});

exports.revokeMeshModerator = onCall({ region: 'europe-west1', maxInstances: 5 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please sign in.');
  const adminSnap = await db.collection('admins').doc(request.auth.uid).get();
  if (!adminSnap.exists || !isSuperAdminData(adminSnap.data())) throw new HttpsError('permission-denied', 'Only an active Super Admin can revoke moderator access.');
  const uid = cleanText(request.data && request.data.uid, 128, 'User ID');
  await db.collection('moderatorAssignments').doc(uid).set({ active: false, revokedBy: request.auth.uid, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  await db.collection('adminAuditLogs').add({ actorUid: request.auth.uid, action: 'revoke_mesh_moderator', targetUid: uid, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  return { ok: true, uid, active: false };
});

exports.publishScopedAnnouncement = onCall({ region: 'europe-west1', maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please sign in.');
  const uid = request.auth.uid;
  const title = cleanText(request.data && request.data.title, 160, 'Title');
  const message = cleanText(request.data && request.data.message, 5000, 'Message');
  const category = cleanText(request.data && request.data.category || 'general', 40, 'Category');
  const requestId = String(request.data && request.data.requestId || '').trim();
  if (!/^[A-Za-z0-9_-]{12,100}$/.test(requestId)) throw new HttpsError('invalid-argument', 'A valid requestId is required. Retry the same request with the same ID.');
  const userSnap = await db.collection('users').doc(uid).get();
  if (!userSnap.exists) throw new HttpsError('failed-precondition', 'Complete your MESH student profile first.');
  const user = userSnap.data() || {};
  const adminSnap = await db.collection('admins').doc(uid).get();
  const adminData = adminSnap.exists ? adminSnap.data() || {} : {};
  const assignmentSnap = await db.collection('moderatorAssignments').doc(uid).get();
  const assignment = assignmentSnap.exists ? assignmentSnap.data() || {} : {};
  const centralAdmin = isCentralAdminData(adminData);
  const isModerator = assignment.active === true && assignment.role === 'moderator';
  if (!centralAdmin && !isModerator) throw new HttpsError('permission-denied', 'Your account does not have active announcement publishing permission.');
  let scopeType, scopeId, universityId;
  if (isModerator) {
    scopeType = audienceField(assignment.scopeType);
    scopeId = cleanText(assignment.scopeId, 128, 'Assigned scope');
    universityId = cleanText(assignment.universityId, 128, 'Assigned university');
    if (String(user.universityId || '') !== universityId) throw new HttpsError('permission-denied', 'Your profile no longer matches the assigned university. Contact the MESH administrator.');
    const profileScope = scopeType === 'university' ? String(user.universityId || '') : scopeType === 'faculty' ? String(user.facultyId || '') : scopeType === 'department' ? String(user.departmentId || '') : String(user.levelId || user.level || '');
    if (profileScope !== scopeId) throw new HttpsError('permission-denied', 'Your academic profile no longer matches your moderator assignment.');
  } else {
    scopeType = String(request.data && request.data.scopeType || 'university');
    if (!['university','faculty','department','class'].includes(scopeType)) throw new HttpsError('invalid-argument', 'Unsupported announcement scope.');
    universityId = cleanText(request.data && request.data.universityId || adminData.universityId || user.universityId, 128, 'University');
    const adminRole = String(adminData.role || '');
    const isSuper = isSuperAdminData(adminData);
    if (!isSuper && String(adminData.universityId || '') !== universityId) throw new HttpsError('permission-denied', 'You cannot publish for this university.');
    if (!isSuper && scopeType === 'university' && !['university_admin','admin'].includes(adminRole)) throw new HttpsError('permission-denied', 'Your admin role cannot publish university-wide notices.');
    scopeId = scopeType === 'university' ? universityId : cleanText(request.data && request.data.scopeId, 128, 'Audience scope');
  }
  const ref = db.collection('announcements').doc(`${uid}_${requestId}`);
  const now = admin.firestore.FieldValue.serverTimestamp();
  const announcementData = { title, message, content: message, category, universityId, scope: scopeType, scopeType, scopeId, audienceType: scopeType, audienceId: scopeId, publisherUid: uid, publisherName: String(user.fullName || user.name || request.auth.token.name || 'MESH moderator').slice(0,120), publisherRole: isModerator ? 'moderator' : String(adminData.role || 'admin'), status: 'published', active: true, priority: request.data && request.data.priority === 'high' && centralAdmin ? 'high' : 'normal', commentsEnabled: request.data && request.data.commentsEnabled !== false, createdAt: now, publishedAt: now, updatedAt: now };
  const existingAnnouncement = await ref.get();
  if (existingAnnouncement.exists) {
    const existing = existingAnnouncement.data() || {};
    if (existing.publisherUid !== uid || existing.title !== title || existing.message !== message || existing.universityId !== universityId || existing.scopeType !== scopeType || existing.scopeId !== scopeId) {
      throw new HttpsError('already-exists', 'This request ID has already been used for a different announcement. Start a new publish attempt.');
    }
  } else {
    await ref.create(announcementData);
  }
  // Create in-app alerts only for members matching the announcement audience.
  // Notification writes are chunked below Firestore's 500-write batch limit.
  const membersSnap = await db.collection('users').where('universityId', '==', universityId).get();
  const recipients = membersSnap.docs.filter(memberDoc => {
    const member = memberDoc.data() || {};
    if (memberDoc.id === uid) return false;
    if (scopeType === 'faculty') return String(member.facultyId || '') === scopeId;
    if (scopeType === 'department') return String(member.departmentId || '') === scopeId;
    if (scopeType === 'class') return String(member.levelId || member.level || '') === scopeId;
    return true;
  });
  for (let i = 0; i < recipients.length; i += 450) {
    const chunk = recipients.slice(i, i + 450);
    const noticeRefs = chunk.map(memberDoc => db.collection('notifications').doc(`${ref.id}_${memberDoc.id}`));
    const existingNotices = noticeRefs.length ? await db.getAll(...noticeRefs) : [];
    const batch = db.batch();
    let pendingWrites = 0;
    chunk.forEach((memberDoc, index) => {
      if (existingNotices[index] && existingNotices[index].exists) return;
      const member = memberDoc.data() || {};
      batch.create(noticeRefs[index], {
        uid: memberDoc.id, universityId,
        ...(scopeType === 'department' ? { departmentId: scopeId } : {}),
        ...(scopeType === 'class' ? { levelId: scopeId } : {}),
        title: 'New official announcement', message: 'A new official announcement is available in Updates.', description: 'Open Updates to read the latest campus announcement.',
        type: 'announcement', announcementId: ref.id, contentId: ref.id, contentCollection: 'announcements', audience: 'user', scopeType, scopeId,
        active: true, read: false, unread: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      pendingWrites++;
    });
    if (pendingWrites) await batch.commit();
  }
  await db.collection('adminAuditLogs').doc(`${ref.id}_publish`).set({ actorUid: uid, action: 'publish_scoped_announcement', announcementId: ref.id, scopeType, scopeId, universityId, notificationRecipients: recipients.length, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  return { ok: true, announcementId: ref.id, scopeType, scopeId, universityId, notificationRecipients: recipients.length };
});



// Admin-only link importer. It returns a safe metadata preview; it never publishes automatically.
const dns = require('node:dns/promises');
const net = require('node:net');
const { isIP } = net;
function isPublicAddress(address) {
  if (isIP(address) === 4) {
    const p = address.split('.').map(Number);
    return !(p[0] === 0 || p[0] === 10 || p[0] === 127 || p[0] >= 224 ||
      (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 192 && p[1] === 168) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
      (p[0] === 198 && (p[1] === 18 || p[1] === 19)));
  }
  if (isIP(address) === 6) {
    const a = address.toLowerCase();
    return !(a === '::' || a === '::1' || a.startsWith('fc') || a.startsWith('fd') ||
      /^fe[89ab]/.test(a) || a.startsWith('ff') || a.startsWith('::ffff:127.') || a.startsWith('::ffff:10.'));
  }
  return false;
}
async function validateImportUrl(value) {
  let url;
  try { url = new URL(String(value || '')); } catch (_) { throw new HttpsError('invalid-argument', 'Enter a valid public HTTPS URL.'); }
  if (url.protocol !== 'https:' || url.username || url.password || !url.hostname || url.port && url.port !== '443') {
    throw new HttpsError('invalid-argument', 'Only public HTTPS links on the standard port are supported.');
  }
  const host = url.hostname.toLowerCase().replace(/\.$/, '');
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || isIP(host)) {
    throw new HttpsError('invalid-argument', 'Private or IP-address URLs are not supported. Paste a public website link.');
  }
  let addresses;
  try { addresses = await dns.lookup(host, { all: true, verbatim: true }); }
  catch (_) { throw new HttpsError('invalid-argument', 'The website hostname could not be resolved.'); }
  if (!addresses.length || addresses.some(x => !isPublicAddress(x.address))) {
    throw new HttpsError('invalid-argument', 'This link does not resolve exclusively to public internet addresses.');
  }
  return url;
}
function decodeHtml(value) {
  return String(value || '').replace(/&amp;/gi, '&').replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Math.min(0x10ffff, Number(n))))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(Math.min(0x10ffff, parseInt(n, 16))));
}
function stripHtml(value) {
  return decodeHtml(String(value || '').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ').trim()).slice(0, 5000);
}
function readMeta(html, key) {
  const tags = html.match(/<meta\b[^>]*>/gi) || [];
  for (const tag of tags) {
    const attrs = {};
    tag.replace(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g, (_, k, a, b, c) => { attrs[k.toLowerCase()] = a ?? b ?? c ?? ''; return ''; });
    if ([attrs.property, attrs.name, attrs.itemprop].some(v => String(v || '').toLowerCase() === key.toLowerCase())) return decodeHtml(attrs.content || '').trim();
  }
  return '';
}
async function fetchDirectPage(url) {
  const response = await fetch(url, { method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(9000), headers: {
    'user-agent': 'Mozilla/5.0 (compatible; MESHLinkPreview/1.1; +https://mesh-9a4f1.web.app)',
    'accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.1',
    'accept-language': 'en-US,en;q=0.8'
  }});
  if ([301,302,303,307,308].includes(response.status)) {
    const location = response.headers.get('location');
    if (!location) throw new Error('redirect-without-location');
    return { redirect: location, status: response.status };
  }
  if (!response.ok) throw new Error(`http-${response.status}`);
  const type = String(response.headers.get('content-type') || '').toLowerCase();
  if (!type.includes('text/html') && !type.includes('application/xhtml+xml')) throw new Error('not-html');
  const reader = response.body && response.body.getReader();
  if (!reader) throw new Error('empty-body');
  let html = '', bytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      bytes += value.byteLength;
      if (bytes > 1024 * 1024) { await reader.cancel(); throw new Error('page-too-large'); }
      html += new TextDecoder().decode(value, { stream: true });
    }
  } finally { try { reader.releaseLock(); } catch (_) {} }
  return { html, finalUrl: url.toString() };
}
function imageFromMarkdown(text) {
  const m = String(text || '').match(/!\[[^\]]*\]\((https?:\/\/[^\s)]+)(?:\s+[^)]*)?\)/i);
  if (!m) return '';
  try { const u = new URL(m[1]); return u.protocol === 'https:' ? u.toString() : ''; } catch (_) { return ''; }
}
function markdownDescription(text) {
  return String(text || '').replace(/^\s{0,3}#{1,6}\s+.*$/gm, ' ').replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[[^\]]*\]\((https?:\/\/[^)]+)\)/g, '$1').replace(/```[\s\S]*?```/g, ' ')
    .replace(/[`*_>#]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 3000);
}
async function fetchReaderFallback(url) {
  // No API key is required. A public reader proxy is used only after the source rejects
  // a direct metadata fetch. It receives the public URL and may be rate-limited.
  const readerUrl = 'https://r.jina.ai/' + url.toString();
  const response = await fetch(readerUrl, { method: 'GET', redirect: 'error', signal: AbortSignal.timeout(12000),
    headers: { 'accept': 'text/plain', 'user-agent': 'MESH-Link-Preview/1.1' } });
  if (!response.ok) throw new Error(`reader-http-${response.status}`);
  const text = await response.text();
  if (!text || text.length < 20) throw new Error('reader-empty');
  if (text.length > 1024 * 1024) throw new Error('reader-too-large');
  const titleMatch = text.match(/^Title:\s*(.+)$/im) || text.match(/^\s{0,3}#\s+(.+)$/m);
  const image = imageFromMarkdown(text);
  const descMatch = text.match(/^Description:\s*(.+)$/im);
  const title = stripHtml(titleMatch && titleMatch[1] || url.hostname).slice(0, 180);
  const description = stripHtml(descMatch && descMatch[1] || markdownDescription(text)).slice(0, 3000);
  return { title, description, imageURL: image, source: url.hostname.replace(/^www\./, ''), url: url.toString(), method: 'reader-fallback' };
}
exports.importMeshContentFromUrl = onCall({ region: 'europe-west1', timeoutSeconds: 45, memory: '256MiB', maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please sign in to the MESH admin dashboard, then try again.');
  const adminSnap = await db.collection('admins').doc(request.auth.uid).get();
  const profile = adminSnap.exists ? adminSnap.data() || {} : {};
  if (!adminSnap.exists || profile.active !== true || !['super_admin','super-admin','superadmin','university_admin','admin','content_manager','moderator'].includes(profile.role)) {
    throw new HttpsError('permission-denied', 'Your signed-in account is not an active MESH admin. Ask the Super Admin to check your admins document and active status.');
  }
  let url = await validateImportUrl(request.data && request.data.url);
  let directError = null;
  for (let redirects = 0; redirects <= 3; redirects++) {
    try {
      const result = await fetchDirectPage(url);
      if (result.redirect) {
        if (redirects === 3) throw new Error('too-many-redirects');
        url = await validateImportUrl(new URL(result.redirect, url).toString());
        continue;
      }
      const html = result.html;
      const titleMatch = html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i);
      const title = stripHtml(readMeta(html, 'og:title') || readMeta(html, 'twitter:title') || (titleMatch && titleMatch[1]) || '').slice(0, 180);
      const description = stripHtml(readMeta(html, 'og:description') || readMeta(html, 'description') || readMeta(html, 'twitter:description')).slice(0, 3000);
      let image = readMeta(html, 'og:image') || readMeta(html, 'twitter:image') || readMeta(html, 'twitter:image:src') || readMeta(html, 'image');
      try { image = image ? new URL(image, url).toString() : ''; } catch (_) { image = ''; }
      if (image) { try { const imgUrl = new URL(image); if (imgUrl.protocol !== 'https:' || imgUrl.username || imgUrl.password) image = ''; } catch (_) { image = ''; } }
      // Use the reader when a page is a JS shell or hides all useful Open Graph metadata.
      if (title && (description || image)) return { title, description, imageURL: image, source: stripHtml(readMeta(html, 'og:site_name') || url.hostname).slice(0, 180), url: url.toString(), method: 'direct' };
      directError = new Error('no-useful-metadata');
      break;
    } catch (error) {
      directError = error;
      if (String(error.message || '').startsWith('page-too-large')) throw new HttpsError('resource-exhausted', 'This webpage is too large to preview.');
      if (String(error.message || '').startsWith('too-many-redirects')) break;
      break;
    }
  }
  try {
    const fallback = await fetchReaderFallback(url);
    if (!fallback.title && !fallback.description && !fallback.imageURL) throw new Error('no-reader-metadata');
    fallback.note = 'Fallback preview. Verify all details before publishing; some sites do not expose images or post text.';
    return fallback;
  } catch (fallbackError) {
    logger.warn('MESH link import direct and fallback failed', { host: url.hostname, direct: String(directError && directError.message || 'unknown'), fallback: String(fallbackError && fallbackError.message || 'unknown') });
    const host = url.hostname.toLowerCase();
    if (host.includes('whatsapp.com') || host.includes('wa.me')) {
      throw new HttpsError('failed-precondition', 'WhatsApp did not expose this channel/post to the preview reader. WhatsApp often requires its app or an approved integration. Paste the post text and use its public image URL in the fields below; MESH will still publish it normally.');
    }
    if (host.includes('ebay.')) {
      throw new HttpsError('failed-precondition', 'eBay blocked or hid its listing preview. This importer needs no API key, but eBay may restrict automated access. Paste the listing title/description and an image URL manually, then publish the source link.');
    }
    throw new HttpsError('unavailable', 'This site did not return preview data, even through the fallback reader. No external API key is required by MESH, but some websites block automated previews. You can still fill the title, description, image URL and source manually.');
  }
});
function normalise(v) { return String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function hasMatricMatch(studentId, text) {
  const target = normalise(studentId);
  const source = String(text || '').toUpperCase();
  if (!target || target.length < 4) return false;
  if (normalise(source).includes(target)) return true;
  const tokens = source.split(/[^A-Z0-9]+/).filter(Boolean);
  const confusions = { O: '0', Q: '0', I: '1', L: '1', S: '5', B: '8', Z: '2' };
  return tokens.some((token) => {
    const candidate = normalise(token);
    if (candidate === target) return true;
    if (candidate.length !== target.length) return false;
    let differences = 0;
    for (let i = 0; i < candidate.length; i++) {
      if (candidate[i] !== target[i] && confusions[candidate[i]] !== target[i] && confusions[target[i]] !== candidate[i]) differences++;
      if (differences > 1) return false;
    }
    return differences <= 1;
  });
}

// Runs in a trusted server environment. The browser's OCR result is only a hint and is never trusted for approval.
exports.processPilotVerification = onDocumentWritten({
  document: 'verificationRequests/{uid}',
  region: 'europe-west1',
  timeoutSeconds: 300,
  memory: '1GiB'
}, async (event) => {
  const uid = event.params.uid;
  const after = event.data && event.data.after;
  if (!after || !after.exists) return;
  const ref = after.ref;
  const request = after.data() || {};
  if (request.status !== 'pending' || request.ocrProcessedAt) return;
  const proofPath = String(request.proofPath || '');
  const studentId = normalise(request.studentId);
  if (!proofPath) {
    await ref.set({ ocrState: request.ocrMatch ? 'browser-match-manual-review' : 'manual-review', autoApproved: false, autoDecision: 'manual-review', autoDecisionReason: 'Original document is not stored; browser OCR is advisory only and requires admin review', ocrProcessedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    return;
  }
  if (!proofPath.startsWith(`verificationProofs/${uid}/`) || !studentId || request.proofType === 'admission-letter' && !proofPath) {
    await ref.set({ ocrState: 'manual-review', autoDecision: 'manual-review', autoDecisionReason: 'Missing or unsupported proof file', ocrProcessedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    return;
  }
  if (!/\.(png|jpe?g|webp|bmp|tiff?)$/i.test(proofPath)) {
    await ref.set({ ocrState: 'manual-review', autoDecision: 'manual-review', autoDecisionReason: 'PDF or unsupported image type requires manual review', ocrProcessedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    return;
  }
  const tempPath = path.join(os.tmpdir(), `${uid}-${Date.now()}${path.extname(proofPath)}`);
  let worker;
  try {
    await admin.storage().bucket().file(proofPath).download({ destination: tempPath });
    worker = await createWorker('eng');
    const result = await worker.recognize(tempPath);
    const text = String(result.data && result.data.text || '').slice(0, 3000);
    const confidence = Math.round(Number(result.data && result.data.confidence) || 0);
    const match = hasMatricMatch(studentId, text);
    const now = admin.firestore.FieldValue.serverTimestamp();
    if (match && confidence >= 50) {
      // Policy requested by the pilot owner: matching matric number plus a readable supported image is auto-approved.
      // This is not university authentication; edited or borrowed documents can still pass and may need later review.
      const batch = db.batch();
      batch.set(ref, { status: 'approved', ocrState: 'match', ocrMatch: true, ocrConfidence: confidence, ocrText: text, autoApproved: true, autoDecision: 'approved', autoDecisionReason: 'Matric number found in readable uploaded document', autoReviewedAt: now, ocrProcessedAt: now, updatedAt: now, reviewerNote: 'Automatically approved by MESH OCR. This confirms a text match only, not university-issued authenticity.' }, { merge: true });
      batch.set(db.collection('users').doc(uid), { verificationStatus: 'approved', verificationRequestStatus: 'approved', verificationAutoApproved: true, verificationReviewedAt: now, updatedAt: now }, { merge: true });
      await batch.commit();
      logger.info('Pilot applicant automatically approved after OCR text match', { uid, confidence });
    } else {
      await ref.set({ ocrState: 'manual-review', ocrMatch: match, ocrConfidence: confidence, ocrText: text, autoApproved: false, autoDecision: 'manual-review', autoDecisionReason: match ? 'OCR confidence below the automatic-approval threshold' : 'Matric number not found in document text', ocrProcessedAt: now, updatedAt: now }, { merge: true });
      logger.info('Pilot applicant routed to manual review', { uid, confidence, match });
    }
  } catch (error) {
    logger.error('Pilot OCR processing failed; keeping application pending for manual review', { uid, error: String(error) });
    await ref.set({ ocrState: 'manual-review', autoApproved: false, autoDecision: 'manual-review', autoDecisionReason: 'OCR processing failed; manual review required', ocrProcessedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  } finally {
    if (worker) await worker.terminate().catch(() => {});
    await fs.unlink(tempPath).catch(() => {});
  }
});

// Department-scoped post alerts and server-side prohibited-content protection.
// Deploying this trigger requires Firebase Cloud Functions availability on the project.
const { onDocumentCreated: onPostCreated } = require('firebase-functions/v2/firestore');
const PROHIBITED_MESH_CONTENT = /\b(?:porn(?:ography)?|xxx|nude[s]?|explicit sex|child sexual|rape threats|kill yourself|motherfucker|nigger|retard)\b/i;
exports.processMeshPost = onPostCreated({
  document: 'posts/{postId}',
  region: 'europe-west1',
  timeoutSeconds: 60,
  memory: '256MiB'
}, async (event) => {
  const snap = event.data;
  if (!snap || !snap.exists) return;
  const post = snap.data() || {};
  if (post.status !== 'active' || typeof post.body !== 'string') return;
  const now = admin.firestore.FieldValue.serverTimestamp();
  const authorUid = String(post.authorUid || '');
  const username = String(post.authorUsername || post.authorName || 'A MESH member');
  if (PROHIBITED_MESH_CONTENT.test(post.body)) {
    await snap.ref.set({ status: 'removed', moderationStatus: 'blocked', moderationReason: 'Potentially prohibited content', moderatedAt: now, updatedAt: now }, { merge: true });
    const batch = db.batch();
    if (authorUid) batch.set(db.collection('notifications').doc(), { uid: authorUid, title: 'Your post was blocked', message: 'Your post was not shown to MESH members because it may violate the MESH Community Rules. Please review the rules before posting again.', postId: snap.id, universityId: post.universityId || '', departmentId: post.departmentId || '', type: 'moderation_warning', active: true, read: false, unread: true, createdAt: now });
    batch.set(db.collection('contentModerationAlerts').doc(), { uid: authorUid, username, universityId: post.universityId || '', departmentId: post.departmentId || '', postId: snap.id, reason: 'blocked_prohibited_language', excerpt: post.body.slice(0, 180), status: 'open', createdAt: now });
    await batch.commit();
    logger.warn('MESH post blocked by server-side content filter', { postId: snap.id, authorUid });
    return;
  }
  // Only notify students in the same department and university; never broadcast every student post globally.
  if (!post.departmentId || !post.universityId) return;
  const members = await db.collection('users').where('universityId', '==', post.universityId).where('departmentId', '==', post.departmentId).limit(450).get();
  const batch = db.batch();
  let count = 0;
  members.docs.forEach((member) => {
    if (member.id === authorUid) return;
    const ref = db.collection('notifications').doc();
    batch.set(ref, { uid: member.id, title: `${username} made a post`, message: 'Tap to open the post in your department feed.', postId: snap.id, universityId: post.universityId, departmentId: post.departmentId, type: 'department_post', active: true, read: false, unread: true, createdAt: now });
    count++;
  });
  if (count) await batch.commit();
  logger.info('MESH department post notifications created', { postId: snap.id, recipients: count });
});


// Trusted, idempotent community counters. Clients may create/delete their own
// like/comment records, but cannot directly edit aggregate counts on the post.
async function applyCommunityCounter(event, collectionName, counterField) {
  const change = event.data;
  if (!change) return;
  const beforeExists = !!(change.before && change.before.exists);
  const afterExists = !!(change.after && change.after.exists);
  if (beforeExists === afterExists) return; // Ignore updates; only count create/delete.
  const delta = afterExists ? 1 : -1;
  const postId = String(event.params.postId || '');
  const eventId = String(event.id || '');
  if (!postId || !eventId) return;
  const postRef = db.collection('communityPosts').doc(postId);
  const markerRef = db.collection('communityCounterEvents').doc(eventId);
  await db.runTransaction(async (tx) => {
    const marker = await tx.get(markerRef);
    if (marker.exists) return;
    const postSnap = await tx.get(postRef);
    if (!postSnap.exists) {
      tx.create(markerRef, { postId, collectionName, counterField, delta, ignored: true, createdAt: admin.firestore.FieldValue.serverTimestamp() });
      return;
    }
    const current = Number(postSnap.get(counterField) || 0);
    tx.update(postRef, { [counterField]: Math.max(0, current + delta), countersUpdatedAt: admin.firestore.FieldValue.serverTimestamp() });
    tx.create(markerRef, { postId, collectionName, counterField, delta, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  });
}

exports.updateCommunityLikeCount = onDocumentWritten({
  document: 'communityPosts/{postId}/likes/{uid}', region: 'europe-west1', maxInstances: 10
}, (event) => applyCommunityCounter(event, 'likes', 'likeCount'));

exports.updateCommunityCommentCount = onDocumentWritten({
  document: 'communityPosts/{postId}/comments/{commentId}', region: 'europe-west1', maxInstances: 10
}, (event) => applyCommunityCounter(event, 'comments', 'commentCount'));
