# MESH Information-First — Phase 9

## Integration/regression work

- Added a post-publish refresh event to the Home and Campus News screens. The moderator publisher already emits `mesh:announcement-published`; the visible feed now reloads when that screen is active, avoiding a stale feed after a successful publish.
- Added Phase 9 static regression checks for server-side moderator authorization, academic-scope validation, callable publishing, chunked notification fan-out, assignment write restrictions, comment authorship/comment toggles, notification privacy, feed refresh wiring, scoped Home queries, and required script inclusion.
- Added the Phase 9 check to `npm run test:static` without removing earlier phase checks.

## Validation

The static checks are designed to catch integration regressions in the source. They are not substitutes for Firestore Rules Unit Testing, browser interaction tests, or live Firebase callable tests.

The Firebase Emulator Suite has not been executed in this environment because the Firebase CLI/dependencies are not installed in the workspace. No Firebase deployment was performed. Before release, install the project's dependencies and run:

```sh
npm install
npm run test:static
npm run test:rules
```

Then manually verify with a staging Firebase project: Super Admin assignment and revocation; moderator publishing only to their assigned ABU department/class; profile-scope mismatch rejection; student question/comment permissions; notification delivery and privacy; sign-in/sign-out; Home and Campus News refresh; and existing admin/pilot-code flows.

## Known release gate

`publishScopedAnnouncement` writes the announcement before notification fan-out. If notification delivery fails after the announcement write, a callable can report an error even though the announcement exists. This phase adds regression coverage around the current flow but does not redesign delivery into a durable retry/outbox pipeline. Treat notification-failure recovery and emulator/live staging validation as release gates, not as passed tests.
