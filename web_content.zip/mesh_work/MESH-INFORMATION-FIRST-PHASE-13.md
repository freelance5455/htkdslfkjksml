# MESH Information-First Phase 13 — Existing Navigation, Activated Audience Views

## User direction

The existing bottom navigation must not be redesigned or replaced. This phase preserves the current Home, Updates, Alerts, and Profile navigation, including the conditional Publish item for authorized moderators.

## Changes

- Activated Home audience cards for University, My Faculty, My Department, and My Class.
- Added audience filters inside the existing Updates/Campus News screen: All relevant, University, My faculty, My department, and My class.
- Kept topic filters (academic calendar, registration, exams, events) separate from audience filters.
- Reused the existing scope-specific announcement queries and profile fields; no new bottom-navigation destinations were added.
- Added static regression checks confirming the existing navigation labels remain unchanged and audience views are wired.

## Validation

- `node --check js/campus-news.js`: passed.
- `node --check js/home.js`: passed.
- `npm run test:static`: passed for Phases 5–13.
- Archive integrity checked after packaging.

## Important limitation

These are source/static checks. Firebase Emulator tests and live ABU account verification have not been run. Confirm that the student profile contains the expected `universityId`, `facultyId`, `departmentId`, and `levelId` (or `level`) values, and test each audience with real staging accounts before production use.
