# MESH Information-First — Phase 7

## Purpose
Strengthen the staging security-test suite before attempting a production release.

## Changes
- Expanded `tests/firestore.rules.test.cjs` with emulator tests for unauthenticated reads, client-side forged announcement creation, client-side moderator-assignment writes, and comment privacy based on the parent announcement scope.
- Added `tests/phase7-static-checks.cjs` and wired it into `npm run test:static`.
- Preserved the existing Firebase project structure and Phase 6 source as the base.

## Checks actually run in this environment
- Phase 5 static integration assertions: PASS.
- Phase 6 staging configuration assertions: PASS.
- Phase 7 static release assertions: run again with `npm run test:static` after extracting the archive.
- ZIP integrity: validated when packaging.

## Emulator execution limitation
`npm run test:rules` was attempted but could not start because the Firebase CLI was not installed (`firebase: not found`). An attempt to install npm dependencies timed out in this environment. Therefore, **the Firestore Emulator tests have not been executed** and no claim is made that live Firebase permissions pass.

## Run locally
Requirements: Node.js 20, Java compatible with the Firebase Emulator Suite, and network access to install dependencies.

```bash
npm install
npm run test:static
npm run test:rules
```

The rules tests run against the local emulator and use a staging-only project ID (`mesh-rules-staging-test`). They do not deploy rules or functions to the production Firebase project.

## Release gate
Do not deploy until emulator tests pass and the callable functions are tested with separate Super Admin, assigned moderator, revoked moderator, in-scope student, out-of-scope student, and unauthenticated contexts. Also confirm the real ABU profile field names and query/index needs. Static checks are not end-to-end verification.
