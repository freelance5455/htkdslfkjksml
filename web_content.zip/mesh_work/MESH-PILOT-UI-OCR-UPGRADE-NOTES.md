# MESH pilot verification and UI upgrade notes — 2026-10-12

## Changes in this package
- Redesigned the private pilot verification gate into a responsive, card-based form using the MESH blue brand, clear steps, accessible status messages, file preview, and privacy notice.
- The university picker loads active records from Firestore `universities` (up to 500 records); no university is hardcoded. Admins can add universities to the catalogue and the form reads them without a code change.
- Registration/matric number is converted to uppercase as the student types. OCR matching ignores spaces/punctuation and tolerates common OCR character confusions.
- Local OCR failure or an uncertain match no longer blocks manual submission. Upload progress and useful failure messages are displayed; the button always resets after a failed/successful attempt.
- Verification evidence is uploaded to private Firebase Storage under `verificationProofs/{uid}/...` and the storage path is recorded on the private Firestore request. It is not a public profile image. Reviewers can inspect it using the existing admin queue.
- The Firestore request allowlist now includes `universityId` and `proofContentType` for the updated form.
- The server OCR function uses a more tolerant number match and a 50% overall OCR-confidence threshold for its automatic decision. This is a text consistency check, not official university authentication. Ambiguous results remain in manual review.
- Four bottom-nav items now share equal-width columns. Discover remains available from Home and is not a bottom-nav item.
- Profile summary no longer repeats the university when the dedicated university field is present; the profile card has improved spacing and avatar treatment.

## Important setup and test limits
- The Cloud Function source is included but is not deployed by this ZIP. Automatic server approval requires deployment and may require Firebase Blaze billing. Do not deploy until the current Firebase pricing and project settings have been checked.
- Publish `firestore.rules` and `storage.rules` to the correct Firebase project before testing the full flow.
- OCR depends on loading Tesseract.js from jsDelivr in the browser and downloads language data; the first scan may take time and requires a network connection. If unavailable, manual submission should still work.
- PDF documents are currently routed to manual review; local browser OCR is for images.
- This package has not been tested against the live Firebase project or real student documents. Run the end-to-end checklist below before production use.

## End-to-end test checklist
1. Sign in as a pilot student and confirm the university list is populated from `universities`.
2. Add a new active university in the admin catalogue and refresh the form; confirm it appears without code changes.
3. Upload a clear image with a known matric number, enter the same number in lowercase and with spaces, and confirm uppercase normalization and OCR scan.
4. Upload a poor-quality image or PDF; confirm manual submission is still possible and the button never remains stuck on “Submitting”.
5. Check Firebase Storage for a private `verificationProofs/{uid}/...` object and the corresponding `verificationRequests/{uid}` record.
6. As Super Admin, confirm the request appears in Student verification, open proof, and approve/reject it.
7. After deploying the function in a test project, verify high-confidence matches become `approved` and uncertain cases remain pending for manual review.
8. Verify unauthorized users cannot read other students' verification documents or records.
9. Check all four bottom navigation items are evenly spaced on narrow Android screens.
10. Check profile details in both light and dark themes.
