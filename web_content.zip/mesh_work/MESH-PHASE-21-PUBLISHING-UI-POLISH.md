# MESH Phase 21 — Publishing reliability and UI polish

- Added a rules-protected Firestore fallback for scoped moderator publishing so the publish flow does not depend solely on a callable Cloud Function being available. The existing callable remains preferred when it works, preserving its notification fan-out path.
- Added Firestore rule validation for moderator assignment, current profile scope, announcement scope, publisher identity, and server timestamps.
- Restored the four-destination bottom navigation layout (Home, Updates, Alerts, Profile) and moved the moderator Publish action into a centered floating action button that does not consume a navigation column.
- Removed the audience shortcut cards and audience-filter row from Updates; retained the topic categories and announcement list. Topic chips continue to filter the feed.
- Added dark-mode styles for the floating action and Updates intro.

## Verification notes
Static checks and syntax checks are included. Live Firebase emulator/security-rule tests and a real-device visual check still need to be run in a configured environment before production release. No Firebase deployment was performed.
