# MESH Phase 15 — Staging Validation & Release Gate

## Purpose
This phase does not introduce new product features. It packages a clear validation gate for the current Phase 14 candidate so that static checks are not mistaken for proof of live Firebase behavior.

## Checks completed in this environment
- `npm run test:static` — PASS (Phase 5 through Phase 14 source-level checks).
- Phase 14 discussion/audience integration check — PASS.
- JavaScript syntax sweep across `js/`, `functions/`, `admin/js/`, and `tests/` — PASS.
- ZIP integrity — verified for the Phase 14 source archive.
- Firebase Emulator/rules tests — NOT RUN: Firebase CLI and dependencies were unavailable; dependency installation timed out.
- Deployed callable, real notification delivery, and Android/PWA smoke tests — NOT RUN.
- Live Firebase deployment — NOT performed.

## Required staging checks before release
1. Use a non-production Firebase project and install dependencies from `package.json`.
2. Run `npm run test:static`.
3. Run `npm run test:rules` with Firebase CLI available; resolve every failing rule test.
4. Sign in as Super Admin and assign an existing ABU user as a department or class moderator through the trusted assignment workflow.
5. Confirm a non-admin cannot assign/revoke moderators or publish an announcement by calling the callable directly.
6. Publish one university-wide announcement as an authorized admin and one department/class announcement as its assigned moderator.
7. Confirm only the intended audience can read each announcement and its comments.
8. Confirm disabled comments reject new comment writes even if a client bypasses the UI.
9. Confirm notifications are created for matching recipients only, are not duplicated on retry with the same `requestId`, and are private to their recipient.
10. Revoke the moderator and verify publishing is rejected immediately afterward.
11. Smoke-test Home, Updates, Alerts, Profile, onboarding, logout/login, and narrow Android screen layouts.
12. Export/backup the staging Firestore data and rules before any production change.

## Release decision
**Not production-approved yet.** Static checks passing is useful but insufficient. Production release requires emulator-backed Firestore rules tests and a successful staging walkthrough of moderator assignment, scoped publishing, comments, notification fan-out/idempotency, and revocation.

## Safety
Do not deploy with `firebase deploy` until the project owner explicitly approves deployment and confirms the target Firebase project. The configured project must be checked carefully to avoid accidentally changing production.
