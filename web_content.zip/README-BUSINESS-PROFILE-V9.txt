BOOK UP — BUSINESS PROFILE & MEMBERSHIP UPDATE (V9)

CHANGES
- Removed the previous Catalogue / Your Catalogue and What You Do editor panels.
- Replaced the service repeater with one multiline Services input: one service per line. Each line is shown as a clean, theme-coloured pill on the profile.
- Removed obsolete duplicate V8 catalogue form panels from the editor.
- Added a subtle light-shaded landing-page accent and oversized, bold, low-opacity business initials.
- Removed left/right page borders and made the generated profile use the full available width.
- Fixed shared HTML export: the exported profile root is explicitly made visible (the app's hidden-page classes are removed), and reveal sections are forced visible so the standalone HTML opens as a webpage rather than a blank page.
- Added a tentative Membership ID label to the generated profile, booking form, quotation PDF, invoice, Find People / Find Jobs form and member cards. The ID is saved locally for this app installation.

MEMBERSHIP ID NOTE
- Current display format: BU-TMP-XXXXXX (example only; generated locally on first run).
- This is a temporary display ID, not a verified server-issued membership number. To guarantee one permanent ID across multiple devices/accounts, connect it to the website's login/authentication database and issue the ID server-side.

INSTALLATION — WEB
1. Back up the current website.
2. Extract the ZIP and replace the complete hosted www folder with the included www folder.
3. Keep profile-stability.js beside index.html.
4. Clear the website/PWA cache or close and reopen the app. The service-worker cache version has been updated.
5. Open Business Profile, enter services one per line, save, and regenerate/share the profile.

INSTALLATION — ANDROID / CAPACITOR
1. Replace the project's www folder with the included www folder.
2. Run npm install.
3. Run npm run android:sync.
4. Run npm run android:open.
5. Build and sign a fresh APK/AAB in Android Studio.

IMPORTANT
- Previously downloaded/shared HTML profile files do not update automatically. Generate a fresh HTML profile after installing this version.
- Membership IDs currently remain local to the installation and are placeholders pending server-side account integration.
- WhatsApp actions open a prefilled message; the user must press Send in WhatsApp.
- Validation performed: inline and external JavaScript syntax checks and ZIP integrity checks. Live browser interaction and Android-device testing were not completed in this environment.
