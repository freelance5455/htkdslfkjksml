GBudget — projet Android

Le HTML corrigé fourni a été intégré dans une application Android WebView.
L'image fournie a été ajoutée comme icône de lancement et comme favicon.

Important : ce dossier est un projet source Android, pas un APK compilé.
La compilation doit être faite avec Android Studio / Android SDK (compileSdk 35) et Gradle 8.9 ou compatible.
Ouvrir le dossier GBudgetAndroid dans Android Studio, attendre la synchronisation Gradle, puis choisir Build > Build APK(s).
L'APK de débogage apparaît normalement dans app/build/outputs/apk/debug/app-debug.apk.

Les données utilisent localStorage du WebView. Pour éviter toute perte, utiliser régulièrement « Exporter mes données ».
