package com.example.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R

/**
 * Home-screen countdown widget. Shows the nearest upcoming event with days / hours / minutes left.
 * Refreshes whenever the app saves data and every 15 minutes through an inexact repeating alarm.
 */
class CountdownWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) manager.updateAppWidget(id, buildViews(context))
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleRefresh(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(refreshIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) refreshAll(context)
    }

    companion object {
        const val ACTION_REFRESH = "com.example.widget.ACTION_REFRESH"
        private const val INTERVAL_MS = 15 * 60 * 1000L

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, CountdownWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val views = buildViews(context)
            for (id in ids) mgr.updateAppWidget(id, views)
        }

        private fun refreshIntent(context: Context): PendingIntent {
            val i = Intent(context, CountdownWidgetProvider::class.java).setAction(ACTION_REFRESH)
            return PendingIntent.getBroadcast(context, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun scheduleRefresh(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + INTERVAL_MS,
                INTERVAL_MS,
                refreshIntent(context)
            )
        }

        private fun buildViews(context: Context): RemoteViews {
            val snap = WidgetData.load(context)
            val views = RemoteViews(context.packageName, R.layout.widget_countdown)

            val open = PendingIntent.getActivity(
                context, 1, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)

            if (!snap.hasEvent) {
                views.setTextViewText(R.id.widget_icon, "⏳")
                views.setTextViewText(R.id.widget_title, snap.labelEmpty)
                for (id in intArrayOf(R.id.widget_d, R.id.widget_h, R.id.widget_m)) views.setTextViewText(id, "–")
                views.setTextViewText(R.id.widget_d_l, snap.labelDays)
                views.setTextViewText(R.id.widget_h_l, snap.labelHours)
                views.setTextViewText(R.id.widget_m_l, snap.labelMinutes)
                return views
            }

            val remaining = (snap.targetMillis - System.currentTimeMillis()).coerceAtLeast(0L)
            val totalMinutes = remaining / 60_000L
            val days = totalMinutes / (60 * 24)
            val hours = (totalMinutes / 60) % 24
            val minutes = totalMinutes % 60

            views.setTextViewText(R.id.widget_icon, snap.icon)
            views.setTextViewText(R.id.widget_title, snap.title)
            views.setTextViewText(R.id.widget_d, WidgetData.digits(days, snap.lang))
            views.setTextViewText(R.id.widget_h, WidgetData.digits(hours, snap.lang))
            views.setTextViewText(R.id.widget_m, WidgetData.digits(minutes, snap.lang))
            views.setTextViewText(R.id.widget_d_l, snap.labelDays)
            views.setTextViewText(R.id.widget_h_l, snap.labelHours)
            views.setTextViewText(R.id.widget_m_l, snap.labelMinutes)
            return views
        }
    }
}
