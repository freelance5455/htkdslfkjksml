package com.example.widget

import android.content.Context
import org.json.JSONObject

/** Reads the event list the web app pushed through [AmarNative.syncEvents]. */
object WidgetData {
    private const val PREFS = "amar_widget"
    private const val KEY_JSON = "payload"

    fun save(context: Context, json: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_JSON, json).apply()
    }

    data class Snapshot(
        val title: String,
        val icon: String,
        val targetMillis: Long,
        val lang: String,
        val dark: Boolean,
        val labelDays: String,
        val labelHours: String,
        val labelMinutes: String,
        val labelLeft: String,
        val labelDone: String,
        val labelEmpty: String,
        val hasEvent: Boolean
    )

    fun load(context: Context, now: Long = System.currentTimeMillis()): Snapshot {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, null)
        var lang = "bn"
        var dark = false
        var labels: JSONObject? = null
        var title = ""
        var icon = "⏳"
        var target = 0L
        var has = false
        if (raw != null) {
            try {
                val root = JSONObject(raw)
                lang = root.optString("lang", "bn")
                dark = root.optString("theme", "light") == "dark"
                labels = root.optJSONObject("labels")
                val arr = root.optJSONArray("events")
                if (arr != null) {
                    // nearest upcoming event (same rule the app uses for its hero card)
                    for (i in 0 until arr.length()) {
                        val e = arr.getJSONObject(i)
                        val ts = e.optLong("timestamp", 0L)
                        if (ts > now && (!has || ts < target)) {
                            has = true
                            target = ts
                            title = e.optString("title", "")
                            icon = e.optString("icon", "⏳")
                        }
                    }
                }
            } catch (e: Exception) {
                has = false
            }
        }
        return Snapshot(
            title = title, icon = icon, targetMillis = target, lang = lang, dark = dark,
            labelDays = labels?.optString("days", "দিন") ?: "দিন",
            labelHours = labels?.optString("hours", "ঘণ্টা") ?: "ঘণ্টা",
            labelMinutes = labels?.optString("minutes", "মিনিট") ?: "মিনিট",
            labelLeft = labels?.optString("left", "বাকি") ?: "বাকি",
            labelDone = labels?.optString("done", "সম্পন্ন!") ?: "সম্পন্ন!",
            labelEmpty = labels?.optString("empty", "কোনো ইভেন্ট নেই — অ্যাপ খুলে যোগ করুন")
                ?: "কোনো ইভেন্ট নেই — অ্যাপ খুলে যোগ করুন",
            hasEvent = has
        )
    }

    /** Converts ASCII digits to the digits of the app language. */
    fun digits(value: Long, lang: String): String {
        val base = when (lang) {
            "bn" -> '০'
            "hi" -> '०'
            "ar" -> '٠'
            else -> '0'
        }
        return value.toString().map { if (it in '0'..'9') base + (it - '0') else it }.joinToString("")
    }
}
