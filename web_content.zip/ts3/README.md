# Target Shooter 3D – APK project
1. Create a free GitHub account and a new repository (Private is fine).
2. Upload ALL files of this folder (keep the .github/workflows folder).
3. Open the repo > Actions tab > "Build Android APK" > Run workflow (it also runs on every upload).
4. After ~5-8 minutes open the finished run > Artifacts > download "target-shooter-3d-apk" (contains app-debug.apk).
5. Copy the APK to your phone, allow "install unknown apps" and install.
index.html is the whole game (three.js is bundled into the APK by the workflow).
