# Google Play AAB build

This project now includes `.github/workflows/build-aab.yml` for building a signed release Android App Bundle (`.aab`).

Before running the workflow, create these GitHub repository secrets:
- ANDROID_KEYSTORE_B64
- ANDROID_KEYSTORE_PASSWORD
- ANDROID_KEY_ALIAS
- ANDROID_KEY_PASSWORD

The workflow expects the keystore to be base64-encoded.
