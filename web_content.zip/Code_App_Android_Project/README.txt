CODE APP — ANDROID PROJECT

This is an Android WebView wrapper around the Code App prototype. It is project source, not a compiled APK.

Build it using GitHub Actions:
1. On GitHub, create a new repository named Code-App.
2. Upload the CONTENTS of this folder to the repository (including the .github folder). Use the repository's web upload feature or GitHub mobile app if available.
3. Open the repository's Actions tab and select “Build Code App APK”.
4. Tap “Run workflow” (or let the workflow run after a push).
5. When complete, open the workflow run and download the “Code-App-debug-APK” artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk, then install it on Android. Android may ask you to allow installs from that source.

The workflow builds a debug APK for personal testing. It is not Play Store-signed.

Limitations:
- run.fly works only in the built-in Fly Demo. This app cannot inject commands or add flying to arbitrary Roblox games.
- Project saves use WebView local storage and may be cleared if app data is cleared.
