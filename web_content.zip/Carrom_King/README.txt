CARROM KING

1. Extract this ZIP file.
2. Open index.html in Chrome on your Android phone.
3. Drag the striker backwards with your finger and release to shoot.
4. Use RESTART GAME to start again.

This is an offline two-player HTML game. It does not include online multiplayer.
