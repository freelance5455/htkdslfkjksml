
 // ==========================================================================
 // FASOTOK 🇧🇫 — CONFIGURATION SUPABASE
 // ==========================================================================

const SUPABASE_URL = "https://vloshskfgaqcdxaktdvy.supabase.co";
const SUPABASE_KEY = "sb_publishable_I5sAXEonuAJ2TvRNuvUNPA_o5wIONOm";

let supabase = null;

document.addEventListener("DOMContentLoaded", async () => {
  // 1. Vérifier le chargement de Supabase

  if (!window.supabase) {
    console.error("Supabase n'a pas pu être chargé.");
    alert("Supabase ne se charge pas. Les fonctions en ligne seront indisponibles.");
  } else {
    supabase = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    }
  }
);
  }

  const bottomButtons = document.querySelectorAll(
    ".bottom-nav .nav-item"
  );
  const videoFeed = document.getElementById("video-feed");
  const fileInput = document.getElementById("fasotok-selecteur");
  const publishBtn = document.getElementById("publish-btn");
  const authOverlay = document.getElementById("auth-overlay");

  let currentUser = null;
  let isMutedGlobal = true;

  // 2. Mettre à jour le pseudo dans le profil
  function mettreAJourProfilVisuel(pseudo = "Utilisateur") {
    const nom = pseudo || "Utilisateur";
    const txt = nom.startsWith("@") ? nom : "@" + nom;

    document
      .querySelectorAll(".profile-username, .profile-header h2")
      .forEach(el => {
        el.textContent = txt;
      });
  }

  // 3. Observer les vidéos pour la lecture automatique
  const videoObserver = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        const video = entry.target.querySelector("video");
        if (!video) return;

        if (entry.isIntersecting) {
          video.muted = isMutedGlobal;
          video.play().catch(() => {});
        } else {
          video.pause();
          video.currentTime = 0;
        }
      });
    },
    {
      root: videoFeed || null,
      threshold: 0.6
    }
  );

  // 4. Charger les vidéos du serveur
  async function chargerVideosDuServeur() {
    if (!videoFeed) return;

    if (!supabase) {
      videoFeed.innerHTML =
        '<div class="placeholder-view"><h2>FasoTok 🇧🇫</h2><p>Supabase n’est pas connecté.</p></div>';
      return;
    }

    try {
      const { data: videosList, error } = await supabase
        .from("videos")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Erreur de chargement des vidéos :", error.message);
        videoFeed.innerHTML =
          '<div class="placeholder-view"><h2>FasoTok 🇧🇫</h2><p>Impossible de charger les vidéos. Vérifie la configuration du serveur.</p></div>';
        return;
      }

      videoFeed.innerHTML = "";

      if (!videosList || videosList.length === 0) {
        videoFeed.innerHTML =
          '<div class="placeholder-view"><h2>Bienvenue sur FasoTok 🇧🇫</h2><p>Aucune publication disponible. Soyez le premier à publier !</p></div>';
        return;
      }

      videosList.forEach(data => {
        const card = document.createElement("section");
        card.className = "video-card";

        const video = document.createElement("video");
        video.src = data.video_url;
        video.loop = true;
        video.muted = isMutedGlobal;
        video.playsInline = true;
        video.setAttribute("playsinline", "");
        video.setAttribute("webkit-playsinline", "");

        const sidebar = document.createElement("aside");
        sidebar.className = "interaction-sidebar";
        sidebar.innerHTML = `
          <div class="icon-group">
            <button class="action-btn profile-icon" type="button">👤</button>
            <span class="sidebar-label"></span>
          </div>
          <div class="icon-group">
            <button class="action-btn like-btn" type="button">❤️</button>
            <span class="like-count sidebar-label">0</span>
          </div>
          <div class="icon-group">
            <button class="action-btn comment-btn" type="button">💬</button>
            <span class="sidebar-label">Commenter</span>
          </div>
        `;

        sidebar.querySelector(".profile-icon + .sidebar-label").textContent =
          data.username || "@Utilisateur";

        const footer = document.createElement("div");
        footer.className = "video-footer";

        const username = document.createElement("h3");
        username.textContent = data.username || "@Utilisateur";

        const caption = document.createElement("p");
        caption.textContent =
          data.caption || "Vidéo partagée sur FasoTok !";

        footer.append(username, caption);
        card.append(video, sidebar, footer);
        videoFeed.appendChild(card);
        videoObserver.observe(card);
      });
    } catch (erreur) {
      console.error("Erreur réseau lors du chargement des vidéos :", erreur);
      videoFeed.innerHTML =
        '<div class="placeholder-view"><h2>FasoTok 🇧🇫</h2><p>Erreur réseau. Vérifie Internet et réessaie.</p></div>';
    }
  }

  // 5. Restaurer la session si l'utilisateur est déjà connecté
  if (supabase) {
    try {
      const {
        data: { session },
        error
      } = await supabase.auth.getSession();

      if (error) throw error;

      if (session) {
        currentUser = session.user;

        if (authOverlay) authOverlay.style.display = "none";

        mettreAJourProfilVisuel(
          currentUser.user_metadata?.username || currentUser.email
        );

        await chargerVideosDuServeur();
      }
    } catch (erreur) {
      console.error("Erreur de session :", erreur.message);
    }
  }

  // 6. Basculer entre connexion et inscription
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const switchToRegister = document.getElementById("switch-to-register");
  const switchToLogin = document.getElementById("switch-to-login");

  if (switchToRegister && loginForm && registerForm) {
    switchToRegister.addEventListener("click", event => {
      event.preventDefault();
      loginForm.hidden = true;
      registerForm.hidden = false;
    });
  }

  if (switchToLogin && loginForm && registerForm) {
    switchToLogin.addEventListener("click", event => {
      event.preventDefault();
      registerForm.hidden = true;
      loginForm.hidden = false;
    });
  }

  // 7. Connexion
  if (loginForm) {
    loginForm.addEventListener("submit", async event => {
      event.preventDefault();

      const username =
        document.getElementById("login-username")?.value.trim();
      const password =
        document.getElementById("login-password")?.value;

      if (!username || !password) {
        alert("Entre ton pseudo et ton code secret.");
        return;
      }

      if (!supabase) {
        alert("FasoTok n'est pas connecté à Supabase. Vérifie la configuration.");
        return;
      }

      try {
        const email = `${username.toLowerCase()}@fasotok.local`;

        
currentUser = data.user;

if (authOverlay) authOverlay.style.display = "none";

mettreAJourProfilVisuel(
  currentUser.user_metadata?.username || currentUser.email
);

chargerVideosDuServeur();

      } catch (erreur) {
        console.error("Erreur FasoTok :", erreur);
        alert("La connexion a échoué. Vérifie Internet et réessaie.");
      }
    });
  }

  // 8. Inscription
  if (registerForm) {
    registerForm.addEventListener("submit", async event => {
      event.preventDefault();

      const username =
        document.getElementById("register-username")?.value.trim();
      const password =
        document.getElementById("register-password")?.value;
      const confirmPassword =
        document.getElementById("register-confirm-password")?.value;

      if (!username || !password || !confirmPassword) {
        alert("Remplis tous les champs d'inscription.");
        return;
      }

      if (!supabase) {
        alert("Supabase n'est pas connecté. Vérifie son chargement.");
        return;
      }

      if (password !== confirmPassword) {
        alert("Les deux codes secrets ne correspondent pas.");
        return;
      }

      const email = `${username.toLowerCase()}@fasotok.local`;

      alert("FasoTok essaie de créer le compte...");
      console.log("Début de l'inscription");

      let resultatInscription;

      try {
        resultatInscription = await Promise.race([
          supabase.auth.signUp({
            email,
            password,
            options: {
              data: { username }
            }
          }),
          new Promise((_, reject) =>
            setTimeout(
              () => reject(
                new Error(
                  "Délai dépassé : vérifie Internet et la connexion à Supabase."
                )
              ),
              15000
            )
          )
        ]);
      } catch (erreur) {
        console.error("Échec de l'inscription :", erreur);
        alert("Inscription impossible : " + erreur.message);
        return;
      }

      const { data, error } = resultatInscription;
      console.log("Résultat inscription :", data, error);

      if (error) {
        alert("Erreur d'inscription : " + error.message);
        return;
      }

      if (data.session && data.user) {
        currentUser = data.user;

        if (authOverlay) authOverlay.style.display = "none";

        mettreAJourProfilVisuel(username);
        await chargerVideosDuServeur();
      } else {
        alert(
          "Compte créé ! Vérifie tes e-mails si Supabase demande une confirmation avant la connexion."
        );
      }
    });
  }

  // 9. Lecture vidéo et son
  if (videoFeed) {
    videoFeed.addEventListener("click", event => {
      if (event.target.tagName !== "VIDEO") return;

      const video = event.target;

      if (video.muted) {
        isMutedGlobal = false;

        document.querySelectorAll(".video-card video").forEach(item => {
          item.muted = false;
        });

        video.play().catch(() => {});
      } else if (video.paused) {
        video.play().catch(() => {});
      } else {
        video.pause();
      }
    });
  }

  // 10. Publier une vidéo
  if (publishBtn && fileInput) {
    publishBtn.addEventListener("click", event => {
      event.preventDefault();

      if (!currentUser) {
        alert("Connecte-toi pour publier une vidéo.");
        return;
      }

      fileInput.click();
    });

    fileInput.addEventListener("change", async event => {
      const file = event.target.files?.[0];
      if (!file) return;

      if (!currentUser) {
        alert("Connecte-toi pour publier.");
        fileInput.value = "";
        return;
      }

      if (!supabase) {
        alert("Supabase n'est pas connecté.");
        fileInput.value = "";
        return;
      }

      const legende =
        prompt("Écris une légende pour ta publication :") || "";

      const fileName =
        `${currentUser.id}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;

      alert("Envoi de la vidéo en cours…");

      try {
        const { error: uploadError } = await supabase.storage
          .from("videos")
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from("videos")
          .getPublicUrl(fileName);

        const pseudo =
          currentUser.user_metadata?.username ||
          currentUser.email ||
          "Utilisateur";

        const { error: dbError } = await supabase
          .from("videos")
          .insert({
            user_id: currentUser.id,
            username: pseudo.startsWith("@") ? pseudo : "@" + pseudo,
            video_url: urlData.publicUrl,
            caption: legende
          });

        if (dbError) throw dbError;

        alert("Vidéo publiée avec succès ! 🇧🇫");
        await chargerVideosDuServeur();
      } catch (erreur) {
        console.error("Erreur de publication :", erreur);
        alert("Erreur de publication : " + erreur.message);
      } finally {
        fileInput.value = "";
      }
    });
  }

  // 11. Navigation du menu inférieur
  bottomButtons.forEach(button => {
    button.addEventListener("click", () => {
      const pageId = button.getAttribute("data-page");
      if (!pageId) return;

      bottomButtons.forEach(btn => btn.classList.remove("active-nav"));
      button.classList.add("active-nav");

      document
        .querySelectorAll(".page-section, #parametres-page")
        .forEach(page => {
          page.hidden = true;
        });

      const targetPage =
        pageId === "profile"
          ? document.getElementById("profile-page")
          : document.getElementById(pageId + "-page");

      if (targetPage) {
        targetPage.hidden = false;
      } else {
        console.warn("Page introuvable :", pageId);
      }

      if (pageId !== "home") {
        document.querySelectorAll(".video-card video").forEach(video => {
          video.pause();
        });
      } else {
        document.querySelectorAll(".video-card").forEach(card => {
          videoObserver.observe(card);
        });
      }
    });
  });

  // 12. Likes et commentaires
  document.addEventListener("click", event => {
    const likeButton = event.target.closest(".like-btn");

    if (likeButton) {
      const label =
        likeButton.parentElement.querySelector(".like-count");

      if (label) {
        const liked = likeButton.classList.toggle("liked");
        const count = parseInt(label.textContent, 10) || 0;

        label.textContent = Math.max(0, count + (liked ? 1 : -1));
        likeButton.style.background = liked
          ? "#fe2c55"
          : "rgba(40, 40, 40, 0.65)";
      }

      return;
    }

    if (event.target.closest(".comment-btn")) {
      const comment = prompt("Ajouter un commentaire :");

      if (comment && comment.trim()) {
        alert(
          "Commentaire saisi. La sauvegarde en ligne des commentaires reste à configurer."
        );
      }
    }
  });

  // 13. Bouton pour ouvrir les paramètres
  const openSettings = document.getElementById("open-settings-btn");
  const backHome = document.getElementById("back-home-btn");

  if (openSettings) {
    openSettings.addEventListener("click", () => {
      const profilePage = document.getElementById("profile-page");
      const settingsPage = document.getElementById("parametres-page");

      if (profilePage) profilePage.hidden = true;
      if (settingsPage) settingsPage.hidden = false;
    });
  }

  if (backHome) {
    backHome.addEventListener("click", () => {
      document
        .querySelectorAll(".page-section, #parametres-page")
        .forEach(page => {
          page.hidden = true;
        });

      const homePage = document.getElementById("home-page");
      if (homePage) homePage.hidden = false;

      bottomButtons.forEach(btn => {
        btn.classList.toggle(
          "active-nav",
          btn.getAttribute("data-page") === "home"
        );
      });
    });
  }

  // 14. Assistant IA FasoTok
  const assistantForm = document.getElementById("assistant-form");
  const assistantQuestion = document.getElementById("assistant-question");
  const assistantReponses = document.getElementById("assistant-reponses");
  const assistantEnvoyer = document.getElementById("assistant-envoyer");

  if (assistantForm) {
    assistantForm.addEventListener("submit", async event => {
      event.preventDefault();

      const question = assistantQuestion?.value.trim();

      if (!question) return;

      if (!supabase) {
        assistantReponses.textContent =
          "FasoTok n'est pas connecté à Supabase.";
        return;
      }

      const { data: sessionData } = await supabase.auth.getSession();

      if (!sessionData.session) {
        assistantReponses.textContent =
          "Connecte-toi à FasoTok pour utiliser l'assistant IA.";
        return;
      }

      assistantReponses.textContent = "L'assistant réfléchit…";

      if (assistantEnvoyer) assistantEnvoyer.disabled = true;

      try {
        const { data, error } = await supabase.functions.invoke(
          "index",
          {
            body: { message: question }
          }
        );

        if (error) throw error;

        if (data?.error) throw new Error(data.error);

        assistantReponses.textContent =
          data?.reply || "Aucune réponse reçue. Réessaie.";

        assistantQuestion.value = "";
      } catch (erreur) {
        console.error("Erreur assistant IA :", erreur);
        assistantReponses.textContent =
          "Impossible de joindre l'assistant. Vérifie la fonction Supabase et réessaie.";
      } finally {
        if (assistantEnvoyer) assistantEnvoyer.disabled = false;
      }
    });
  }

  // 15. Préférences des paramètres FasoTok
  const langueSelect = document.getElementById("fasotok-langue");
  const langueMessage = document.getElementById("langue-message");
  const notificationsToggle = document.getElementById("notifications-fasotok");
  const sonToggle = document.getElementById("son-videos-fasotok");

  const languesFasoTok = {
    fr: "Français",
    en: "English",
    ar: "العربية",
    es: "Español",
    pt: "Português",
    zh: "中文",
    hi: "हिन्दी",
    ru: "Русский",
    de: "Deutsch",
    it: "Italiano",
    tr: "Türkçe",
    mos: "Mooré",
    dyu: "Dioula"
  };

  if (langueSelect) {
    langueSelect.value = localStorage.getItem("fasotok-langue") || "fr";

    if (langueMessage) {
      langueMessage.textContent =
        "Langue sélectionnée : " +
        (languesFasoTok[langueSelect.value] || "Français");
    }

    langueSelect.addEventListener("change", () => {
      localStorage.setItem("fasotok-langue", langueSelect.value);

      if (langueMessage) {
        langueMessage.textContent =
          "Langue sélectionnée : " +
          languesFasoTok[langueSelect.value];
      }
    });
  }

  if (notificationsToggle) {
    notificationsToggle.checked =
      localStorage.getItem("fasotok-notifications") !== "false";

    notificationsToggle.addEventListener("change", () => {
      localStorage.setItem(
        "fasotok-notifications",
        String(notificationsToggle.checked)
      );
    });
  }

  if (sonToggle) {
    sonToggle.checked =
      localStorage.getItem("fasotok-son") === "true";

    sonToggle.addEventListener("change", () => {
      localStorage.setItem("fasotok-son", String(sonToggle.checked));
    });
  }

});
