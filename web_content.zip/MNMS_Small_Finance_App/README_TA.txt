MNMS SMALL FINANCE PRIVATE LTD - APP SOURCE

இந்த ZIP-ல் உள்ள index.html தான் MNMS Demo App.

நீங்கள் Android app உருவாக்க:
1. ZIP-ஐ extract செய்யவும்.
2. index.html கோப்பை உங்கள் Android WebView project-ல் assets/www (அல்லது app/src/main/assets) folder-ல் வைக்கவும்.
3. WebView-ல் JavaScript மற்றும் DOM Storage (localStorage) enable செய்யவும்.
4. index.html-ஐ WebView-ல் load செய்யவும்.

குறிப்பு:
- இது browser/local storage demo மட்டும்.
- Cloud database, staff login, secure KYC storage, backup, production security ஆகியவை இதில் இல்லை.
- உண்மையான Aadhaar/PAN தகவல்களை demo-வில் சேமிக்க வேண்டாம்.
