MODARA ALL V6.2.1 – Android Studio Project

This project is based on the user's MODARA ALL V6.1.2 source. The existing localStorage key (modara_all_v6) and existing module data collections are retained to preserve on-device records across compatible updates.

Modules retained: Water & Electricity, Petty Cash, Certificate Register, Security Officer Attendance, Asset Management, Staff OT, Other Payment / IO, and Settings. All app screens, buttons, labels, reports, and alerts are in English.

Water & Electricity pages: 1 Dashboard; 2 Meter Reading; 3 Monthly Report; 4 History; 5 PDF / Print; 6 Annual Report, separated into 6.1 Water Annual Report and 6.2 Electricity Annual Report. Dashboard values use the device's local date/month.

Staff OT pages: 1 Dashboard (21st–20th OT period); 2 Staff Management; 3 Attendance; 4 Leave Management; 5 PDF / Print; 6 History (current saved records only); 7 OT Limit Management. Maximum OT is 57 hours per employee per period. The 57 hours are allocated proportionally to eligible duty days in four calendar weeks. Excess in a week reduces remaining weekly limits proportionally to their duty days.

OT rules: Monday–Friday OT windows are 07:00–08:30 and 16:30–18:00. Saturday OT windows are 07:00–08:30 and 12:30–14:00. Sundays have no OT. Poya, Mercantile, and Public Holidays have no OT. Special Holidays are excluded from duty-day allocation; OT is not automatically blocked on a Special Holiday unless a leave/no-OT record applies. Leave records block OT for the selected employee on that date.

Build: open the android/ folder in Android Studio, sync Gradle, then Build > Build APK(s). This archive contains source code, not a compiled APK. No Gradle wrapper is included.

Important: make a Full App Backup before installing an updated build. Device-local records are not uploaded to a server.
