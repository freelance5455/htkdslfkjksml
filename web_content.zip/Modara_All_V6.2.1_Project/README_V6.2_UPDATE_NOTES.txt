MODARA ALL V6.2.1 REPAIR NOTES

This repair was made after reviewing the V6.1.2 source and the previously generated V6.2 files.

1. Rebuilt Staff OT navigation to the agreed seven pages: Dashboard, Staff Management, Attendance, Leave Management, PDF / Print, History, and OT Limit Management.
2. Staff Management supports add, edit (including EPF changes), and delete. EPF selectors and reports refresh when the staff list changes. Existing attendance and leave records remain saved when a staff member is deleted.
3. Leave Management has the six agreed leave types: Duty Leave, Company Leave, Poya Day, Mercantile Holiday, Public Holiday, and Special Holiday. Leave blocks OT for the selected employee/date.
4. OT period is selected automatically from the local device date: 21st through the following 20th. It resets on the 21st.
5. Four calendar weeks are 21–27, 28–3, 4–10, and 11–20. Sundays, Poya, Mercantile, Public, and Special Holidays are excluded from duty-day counts. The 57-hour maximum is distributed by each week's eligible duty days, not as equal 14.25-hour shares.
6. Weekly excess is carried forward and reduces the remaining weeks in proportion to their eligible duty days. The Page 7 screen displays only the current week's cards for all employees; exceeded OT is highlighted red.
7. OT windows: Monday–Friday 07:00–08:30 and 16:30–18:00; Saturday 07:00–08:30 and 12:30–14:00. Quarter-hour blocks are counted in 0.25-hour units without rounding up. Sundays and Poya/Mercantile/Public holidays have no OT. Special Holidays are excluded from allocation but are not automatically blocked from OT unless the employee has a leave/no-OT record.
8. Water & Electricity pages are ordered Dashboard, Meter Reading, Monthly Report, History, PDF / Print, Annual Report. Annual Report has separate 6.1 Water and 6.2 Electricity Jan–Dec charts for the device's local current year.
9. Removed Sinhala text from the app UI; app UI is English-only. The device-local storage key is unchanged.
10. OT module backup/restore includes staff records.
11. Petty Cash default first bill line is non-removable; only additional item rows show Remove. The prior-quarter date range now uses local calendar dates to avoid a one-day UTC offset.

Checks performed: JavaScript syntax check; duplicate function and duplicate HTML ID scan; direct DOM-ID reference scan; English-only UI scan; calculation tests for OT period boundaries, four-week date partitions, 57-hour allocation sum, weekday/Saturday OT windows, Sunday/holiday/leave handling, current-week selection, and proportional carry-forward reduction.

Not completed: Android Gradle APK build and physical-device testing. This is a repaired source package, not a verified compiled APK.
