V6.1.2 correction notes:
- Category dropdown option placeholder corrected; category list remains seven items only.
- Petty Cash History shows saved bill rows only, not audit-log DELETE entries.
- H/O Outstanding uses previous calendar quarter bills minus H.O. received total, floored at zero.
- Cash balance formula remains opening float + all received - all expenses.

Build/testing: source-level modifications only; APKForge build not tested.
