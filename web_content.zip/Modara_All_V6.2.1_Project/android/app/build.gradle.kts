plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.modara.all"; compileSdk = 35; defaultConfig { applicationId = "com.modara.all"; minSdk = 24; targetSdk = 35; versionCode = 8; versionName = "6.2.1" } }
dependencies { implementation("androidx.activity:activity:1.9.3") }
