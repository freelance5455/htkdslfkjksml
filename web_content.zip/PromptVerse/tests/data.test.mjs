// Data & translation integrity tests. Run: npm test
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const www = (...p) => path.join(ROOT, 'www', ...p);
const readJson = (...p) => JSON.parse(fs.readFileSync(www(...p), 'utf8'));
const LANGS = ['fa', 'en', 'ar', 'tr', 'fr', 'de', 'es', 'ru', 'zh', 'hi'];
const ICON_NAMES = new Set([...fs.readFileSync(www('js/icons.js'), 'utf8').matchAll(/^\s{2}(\w+):\s*'/gm)].map((m) => m[1]));

test('translations: all 10 files exist, valid JSON, same keys as en.json, none empty', () => {
  const en = readJson('translations', 'en.json');
  for (const code of LANGS) {
    const d = readJson('translations', `${code}.json`);
    assert.deepEqual(Object.keys(d).sort(), Object.keys(en).sort(), `${code}: key mismatch`);
    for (const [k, v] of Object.entries(d)) assert.ok(typeof v === 'string' && v.trim(), `${code}.${k} is empty`);
  }
});

test('translations: placeholders ({n}, {v}, {lang}) are preserved in every language', () => {
  const en = readJson('translations', 'en.json');
  const ph = (s) => (s.match(/\{\w+\}/g) || []).sort().join();
  for (const code of LANGS) {
    const d = readJson('translations', `${code}.json`);
    for (const k of Object.keys(en)) assert.equal(ph(d[k]), ph(en[k]), `${code}.${k}`);
  }
});

test('categories: unique ids, names in all 10 languages, valid icon & colours', () => {
  const { categories } = readJson('data', 'categories.json');
  assert.ok(categories.length >= 28);
  const ids = new Set();
  for (const c of categories) {
    assert.ok(!ids.has(c.id), `duplicate category ${c.id}`); ids.add(c.id);
    assert.match(c.id, /^[a-z0-9-]+$/);
    for (const l of LANGS) assert.ok(c.names?.[l]?.trim(), `${c.id} missing name ${l}`);
    assert.ok(ICON_NAMES.has(c.icon), `${c.id}: unknown icon ${c.icon}`);
    assert.equal(c.colors.length, 2);
    for (const col of c.colors) assert.match(col, /^#[0-9a-f]{6}$/i);
  }
});

test('prompts: required fields, unique ids, valid category, images exist inside the app', () => {
  const { categories } = readJson('data', 'categories.json');
  const { prompts } = readJson('data', 'prompts.json');
  const catIds = new Set(categories.map((c) => c.id));
  const ids = new Set();
  assert.ok(prompts.length >= 1);
  for (const p of prompts) {
    for (const f of ['id', 'title', 'description', 'prompt', 'categoryId', 'image', 'promptLang', 'tags', 'status', 'order', 'createdAt'])
      assert.ok(p[f] !== undefined && p[f] !== '', `${p.id}: missing ${f}`);
    assert.ok(!ids.has(p.id), `duplicate prompt id ${p.id}`); ids.add(p.id);
    assert.ok(catIds.has(p.categoryId), `${p.id}: unknown category ${p.categoryId}`);
    assert.ok(Array.isArray(p.tags));
    assert.ok(['published', 'draft', 'hidden'].includes(p.status));
    assert.match(p.createdAt, /^\d{4}-\d{2}-\d{2}/);
    for (const f of ['image', 'thumb'].filter((k) => p[k])) {
      assert.ok(!/^https?:/i.test(p[f]), `${p.id}.${f} must be a bundled path, not a URL`);
      assert.ok(fs.existsSync(www(p[f])), `${p.id}.${f} file not found: ${p[f]}`);
    }
  }
});

test('sample prompt text is stored byte-for-byte as specified', () => {
  const expected = fs.readFileSync(path.join(ROOT, 'tests/fixtures/sample-prompt.txt'), 'utf8');
  const p = readJson('data', 'prompts.json').prompts.find((x) => x.id === 'cinematic-street-portrait');
  assert.ok(p, 'sample prompt missing');
  assert.equal(p.prompt, expected);
  assert.equal(p.title, 'پرتره خیابانی سینمایی');
  assert.equal(p.description, 'تبدیل عکس شخصی به یک پرتره خیابانی سینمایی با حفظ هویت واقعی فرد.');
  assert.equal(p.categoryId, 'personal-photo-editing');
});

test('offline: no http(s) URLs or external hosts in source files', () => {
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  for (const f of walk(www()).filter((x) => /\.(js|css|html|json)$/.test(x))) {
    const txt = fs.readFileSync(f, 'utf8');
    const urls = [...txt.matchAll(/https?:\/\/[^\s"')]+/g)].map((m) => m[0]).filter((u) => !/localhost/.test(u));
    assert.deepEqual(urls, [], `${path.relative(ROOT, f)} references external URLs`);
  }
});

test('no ads / payments / analytics SDK in dependencies', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const all = Object.keys({ ...pkg.dependencies, ...pkg.devDependencies }).join(' ');
  assert.doesNotMatch(all, /admob|firebase|analytics|billing|purchase|sentry|facebook/i);
});

test('bundled fonts referenced by CSS exist', () => {
  const css = fs.readFileSync(www('css/app.css'), 'utf8');
  for (const m of css.matchAll(/url\(\.\.\/(assets\/fonts\/[^)]+)\)/g)) assert.ok(fs.existsSync(www(m[1])), m[1]);
});
