// Unit tests for the pure search / sort / language logic. Run: npm test
import test from 'node:test';
import assert from 'node:assert/strict';
import { normalize, buildIndex, searchPrompts, similarPrompts, sortPrompts, filterCategories, pickLanguage } from '../www/js/lib/search.js';

const cats = new Map([
  ['a', { id: 'a', names: { en: 'Street photography', fa: 'عکاسی خیابانی' } }],
  ['b', { id: 'b', names: { en: 'Logo design', fa: 'طراحی لوگو' } }],
]);
const mk = (o) => ({ description: '', tags: [], popularity: 0, order: 0, createdAt: '2026-01-01', prompt: '', ...o });
const data = buildIndex([
  mk({ id: '1', title: 'پرتره خیابانی سینمایی', categoryId: 'a', tags: ['پرتره', 'sunset'], popularity: 5, createdAt: '2026-03-01', prompt: 'متن یک' }),
  mk({ id: '2', title: 'Minimal Café Logo', categoryId: 'b', tags: ['logo', 'coffee'], popularity: 9, createdAt: '2026-02-01' }),
  mk({ id: '3', title: 'Neon Alley', categoryId: 'a', tags: ['sunset', 'neon'], popularity: 1, createdAt: '2026-01-15' }),
], cats);

test('normalize: case, accents, Arabic/Persian letter + digit variants, ZWNJ', () => {
  assert.equal(normalize('CAFÉ'), 'cafe');
  assert.equal(normalize('كتاب'), normalize('کتاب'));
  assert.equal(normalize('عربي'), normalize('عربی'));
  assert.equal(normalize('۱۲۳ ٤٥٦'), '123 456');
  assert.equal(normalize('می‌خواهم'), normalize('میخواهم'));
});

test('search by title (Persian), by tag, by accent-insensitive Latin, multi-token AND', () => {
  assert.deepEqual(searchPrompts(data, { query: 'سینمایی' }).map((p) => p.id), ['1']); // title only
  assert.deepEqual(searchPrompts(data, { query: 'خیابانی' }).map((p) => p.id), ['1', '3']); // title of 1 + category name of 3
  assert.deepEqual(searchPrompts(data, { query: 'پرتره' }).map((p) => p.id), ['1']);
  assert.deepEqual(searchPrompts(data, { query: 'cafe' }).map((p) => p.id), ['2']);
  assert.deepEqual(searchPrompts(data, { query: 'sunset' }).map((p) => p.id).sort(), ['1', '3']);
  assert.deepEqual(searchPrompts(data, { query: 'sunset neon' }).map((p) => p.id), ['3']);
  assert.deepEqual(searchPrompts(data, { query: 'zzzz' }), []);
  assert.equal(searchPrompts(data, { query: '  ' }).length, 3);
});

test('search also matches category names in any language', () => {
  assert.deepEqual(searchPrompts(data, { query: 'logo design' }).map((p) => p.id), ['2']);
  assert.deepEqual(searchPrompts(data, { query: 'عکاسی' }).map((p) => p.id).sort(), ['1', '3']);
});

test('category filter + sort modes', () => {
  assert.deepEqual(searchPrompts(data, { categoryId: 'a', sort: 'newest' }).map((p) => p.id), ['1', '3']);
  assert.deepEqual(sortPrompts(data, 'popular').map((p) => p.id), ['2', '1', '3']);
  assert.deepEqual(sortPrompts(data, 'oldest').map((p) => p.id), ['3', '2', '1']);
  assert.deepEqual(sortPrompts(data, 'title').map((p) => p.id).length, 3);
});

test('similar prompts: same category and shared tags, never itself', () => {
  const s = similarPrompts(data[0], data, 8).map((p) => p.id);
  assert.deepEqual(s, ['3']); // same category (3) + shared tag "sunset" (1)
  assert.ok(!s.includes('1'));
  assert.deepEqual(similarPrompts(data[1], data, 8), []); // nothing in common → no padding
});

test('category filter by localized or any-language name', () => {
  const list = [...cats.values()];
  assert.deepEqual(filterCategories(list, 'logo', (c) => c.names.en).map((c) => c.id), ['b']);
  assert.deepEqual(filterCategories(list, 'لوگو', (c) => c.names.en).map((c) => c.id), ['b']);
  assert.equal(filterCategories(list, '', (c) => c.names.en).length, 2);
});

test('first-run language detection from the OS language list', () => {
  const S = ['fa', 'en', 'ar', 'tr', 'fr', 'de', 'es', 'ru', 'zh', 'hi'];
  assert.equal(pickLanguage(['fa-IR'], S), 'fa');
  assert.equal(pickLanguage(['ar-SA', 'en'], S), 'ar');
  assert.equal(pickLanguage(['tr_TR'], S), 'tr');
  assert.equal(pickLanguage(['zh-CN'], S), 'zh');
  assert.equal(pickLanguage(['zh-Hans-SG'], S), 'zh');
  assert.equal(pickLanguage(['hi-IN'], S), 'hi');
  assert.equal(pickLanguage(['ja-JP'], S), 'en');           // unsupported → English
  assert.equal(pickLanguage(['ja-JP', 'de-DE'], S), 'de');  // first supported in the list
  assert.equal(pickLanguage(['zh-TW'], S), 'en');           // Traditional Chinese is not bundled
  assert.equal(pickLanguage([], S), 'en');
});
