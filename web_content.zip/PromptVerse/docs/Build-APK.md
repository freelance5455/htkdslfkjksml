# ساخت APK

پیش‌نیاز: Node ≥ ۲۰، JDK (برای Capacitor 7 نسخهٔ ۲۱)، Android Studio + Android SDK، و اینترنت برای دانلود اولیه.

```bash
npm install
npx cap add android          # فقط بار اول؛ پوشهٔ android/ ساخته می‌شود
npm run android:setup        # آیکون + اسپلش + نام برنامه (اختیاری: --strip-internet)
npx cap sync android         # هر بار که محتوای www تغییر کرد
```

## روش ۱ — Android Studio
`npm run android:open` ← صبر تا Gradle Sync تمام شود ← منوی **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.

## روش ۲ — خط فرمان
- Linux/macOS: `cd android && ./gradlew assembleDebug`
- Windows: `cd android` سپس `gradlew.bat assembleDebug`

فایل خروجی: `android/app/build/outputs/apk/debug/app-debug.apk` (قابل نصب مستقیم روی گوشی).

## نسخهٔ انتشار (Release)
در Android Studio: **Build ▸ Generate Signed Bundle / APK** و ساخت یک keystore شخصی. keystore را در جای امن نگه دارید.

## تغییر نسخه
`versionCode` و `versionName` در `android/app/build.gradle`؛ و `APP.version` در `www/js/config.js`.
