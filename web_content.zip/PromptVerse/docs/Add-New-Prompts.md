# افزودن پرامپت و تصویر جدید

۱. تصویر را در `www/assets/images/` بگذارید (مثلاً `neon-alley.jpg`).
۲. (پیشنهادی) thumbnail بسازید: `python3 tools/make-thumbs.py` ← فایل `neon-alley.thumb.jpg` ساخته می‌شود.
۳. یک رکورد به آرایهٔ `prompts` در `www/data/prompts.json` اضافه کنید (بین رکوردها ویرگول بگذارید).
۴. برنامه اطلاعات جدید را نمایش می‌دهد: در مرورگر با رفرش؛ در اندروید بعد از `npx cap sync android` و ساخت دوبارهٔ APK.

## رکورد نمونه با توضیح فیلدها
```json
{
  "id": "neon-alley-portrait",
  "title": "پرتره کوچه نئونی",
  "description": "توضیح کوتاه دربارهٔ کاربرد.",
  "prompt": "متن کامل پرامپت.\nخط جدید و علائم نگارشی دقیقاً حفظ می‌شوند.",
  "categoryId": "cinematic",
  "image": "assets/images/neon-alley.jpg",
  "thumb": "assets/images/neon-alley.thumb.jpg",
  "promptLang": "fa",
  "tags": ["نئون", "شب", "neon", "night"],
  "status": "published",
  "featured": false,
  "popularity": 40,
  "createdAt": "2026-11-01",
  "order": 2
}
```
| فیلد | توضیح |
|---|---|
| `id` | شناسهٔ یکتا؛ فقط حروف لاتین کوچک، عدد و `-` |
| `title`, `description` | عنوان و توضیح (به زبان اصلی پرامپت یا هر زبان دلخواه) |
| `prompt` | متن کامل؛ **دقیقاً همین رشته نمایش و کپی می‌شود** |
| `categoryId` | یکی از `id`های `categories.json` |
| `image` | مسیر نسبت به `www/` — تصویر بزرگ برای صفحهٔ جزئیات و تمام‌صفحه |
| `thumb` | اختیاری؛ تصویر کوچک برای کارت‌ها (اگر نباشد از `image` استفاده می‌شود) |
| `promptLang` | زبان متن پرامپت (`fa`, `en`, `ar`…) — جهت نمایش متن را تعیین می‌کند |
| `tags` | برچسب‌ها برای جست‌وجو و «مشابه» |
| `status` | `published` نمایش داده می‌شود؛ `draft` یا `hidden` مخفی است |
| `featured` | `true` ⇒ در بخش «منتخب» |
| `popularity` | عدد؛ برای «محبوب‌ترین» و مرتب‌سازی |
| `createdAt` | تاریخ `YYYY-MM-DD`؛ برای «جدیدترین» |
| `order` | ترتیب ثانویه |

نکتهٔ JSON: داخل متن، نقل‌قول `"` را به‌صورت `\"` و خط جدید را `\n` بنویسید. بعد از ویرایش `npm test` را اجرا کنید تا اعتبار فایل، وجود تصاویر و صحت دسته‌ها بررسی شود.
