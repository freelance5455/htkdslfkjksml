// Reusable UI components: cards, toast, sheets, dialogs, full-screen image viewer.
import { h, svg, lazyImg } from './lib/dom.js';
import { t, catName, promptTitle, currentLang, fmt } from './i18n.js';
import { LANGS } from './config.js';
import { content, isFav, toggleFav, categoryCover } from './store.js';
import { buzz } from './native.js';

export const go = (path, { replace = false } = {}) => {
  if (replace) location.replace('#' + path); else location.hash = path;
};

// ---------------------------------------------------------------- toast
let toastTimer;
export function toast(message, kind = 'ok') {
  const host = document.getElementById('toasts');
  host.replaceChildren();
  clearTimeout(toastTimer);
  const el = h('div', { class: `toast ${kind}`, role: 'status' },
    h('span', { class: 'tdot' }, svg(kind === 'ok' ? 'check' : 'close')),
    h('span', {}, message));
  host.append(el);
  toastTimer = setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 300);
  }, 2400);
}

// ---------------------------------------------------------------- favourite heart
export function favButton(p, cls = 'card-fav') {
  const b = h('button', { class: cls, type: 'button', 'aria-pressed': String(isFav(p.id)), 'aria-label': t('detail.fav') });
  const paint = () => {
    const on = isFav(p.id);
    b.classList.toggle('is-on', on);
    b.setAttribute('aria-pressed', String(on));
    b.replaceChildren(svg('heart', { fill: on }));
  };
  paint();
  b.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    const on = toggleFav(p.id);
    paint(); buzz(10);
    b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
    toast(t(on ? 'toast.favAdded' : 'toast.favRemoved'));
  });
  return b;
}

// ---------------------------------------------------------------- prompt card
export function promptCard(p, { variant = '', rank = 0 } = {}) {
  const cat = content.catById.get(p.categoryId);
  const el = h('a', { class: `card ${variant}`, href: `#/prompt/${encodeURIComponent(p.id)}`, 'aria-label': promptTitle(p) },
    h('div', { class: 'ph' }),
    lazyImg(p.thumb, ''),
    rank ? h('span', { class: 'rank-no', 'aria-hidden': 'true' }, fmt(rank)) : null,
    favButton(p),
    h('div', { class: 'card-body' },
      cat ? h('span', { class: 'card-tag' }, catName(cat)) : null,
      h('div', { class: 'card-title' }, promptTitle(p))));
  return el;
}

// ---------------------------------------------------------------- category card
export function categoryCard(c, i = 0) {
  const n = content.counts.get(c.id) || 0;
  const cover = categoryCover(c);
  const el = h('a', { class: `cat-card h${(i % 3) + 1}${cover ? ' has-cover' : ''}`, href: `#/category/${encodeURIComponent(c.id)}`,
    style: { '--c1': c.colors?.[0] || '#8b5cf6', '--c2': c.colors?.[1] || '#ff5e8a', '--i': Math.min(i, 14) } },
    cover ? h('div', { class: 'cover' }, lazyImg(cover, '')) : null,
    h('div', { class: 'bg-icon' }, svg(c.icon)),
    h('div', { class: 'ci' }, svg(c.icon)),
    h('div', {}, h('h3', {}, catName(c)), h('small', {}, t('count.prompts', { n }))));
  return el;
}

export function emptyState(iconName, title, hint) {
  return h('div', { class: 'empty' }, h('div', { class: 'orb' }, svg(iconName)), h('b', {}, title), hint ? h('span', {}, hint) : null);
}

export function sectionHead(titleText, iconName, linkText, href) {
  return h('div', { class: 'section-head' },
    h('h2', {}, iconName ? svg(iconName) : null, titleText),
    linkText ? h('a', { href }, linkText, svg('chevron', { cls: 'dir-icon' })) : null);
}

// ---------------------------------------------------------------- sheets & dialogs
function openSheet(build, onDismiss) {
  const prevFocus = document.activeElement;
  const back = h('div', { class: 'backdrop' });
  const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' }, h('div', { class: 'grab' }));
  const close = () => new Promise((res) => {
    back.classList.add('out'); sheet.classList.add('out');
    setTimeout(() => { back.remove(); sheet.remove(); prevFocus?.focus?.(); res(); }, 240);
  });
  back.addEventListener('click', () => close().then(() => onDismiss?.()));
  sheet.append(build(close));
  document.body.append(back, sheet);
  return close;
}

export function languageSheet(onPick) {
  openSheet((close) => h('div', {},
    h('h3', {}, t('settings.language')),
    languageList((code) => { close(); onPick(code); }),
    h('p', { class: 'hint', style: { color: 'var(--muted)', fontSize: '12.5px', marginTop: '12px' } }, t('settings.languageHint'))));
}

export function languageList(onPick, cls = 'lang-list') {
  const cur = currentLang();
  return h('div', { class: cls }, LANGS.map((l) => h('button', {
    class: `lang-item${l.code === cur ? ' is-active' : ''}`, type: 'button', lang: l.code, dir: l.dir, onclick: () => onPick(l.code),
  }, h('span', {}, l.native), l.code === cur ? h('span', { class: 'tick' }, svg('check')) : null)));
}

export function confirmDialog(message) {
  return new Promise((resolve) => {
    const done = (v, close) => close().then(() => resolve(v));
    openSheet((close) => h('div', {},
      h('h3', {}, message),
      h('div', { class: 'dialog-actions' },
        h('button', { class: 'btn', type: 'button', onclick: () => done(false, close) }, t('common.cancel')),
        h('button', { class: 'btn btn-primary', type: 'button', onclick: () => done(true, close) }, t('common.confirm')))),
    () => resolve(false)); // tapping the backdrop = cancel
  });
}

// ---------------------------------------------------------------- full-screen image viewer (pinch / pan / double-tap)
export function openViewer(src, alt = '') {
  const img = h('img', { src, alt, draggable: 'false' });
  const hint = h('div', { class: 'vhint' }, t('viewer.hint'));
  const closeBtn = h('button', { class: 'glass-btn', type: 'button', 'aria-label': t('common.close') }, svg('close'));
  const root = h('div', { class: 'viewer', role: 'dialog', 'aria-modal': 'true' }, img, closeBtn, hint);
  let scale = 1, tx = 0, ty = 0, closed = false;
  const pts = new Map();
  let startDist = 0, startScale = 1, lastTap = 0, last = null;
  const clamp = () => {
    const w = root.clientWidth, hh = root.clientHeight;
    const maxX = (w * scale - w) / 2, maxY = (hh * scale - hh) / 2;
    // image is centred via transform-origin 0 0 + translate offset of half the extra size
    tx = Math.min(maxX, Math.max(-maxX, tx)); ty = Math.min(maxY, Math.max(-maxY, ty));
  };
  // keep the scaled image centred: origin top-left, so offset by -(scale-1)*size/2
  const render = () => {
    const w = root.clientWidth, hh = root.clientHeight;
    img.style.transform = `translate(${tx - (scale - 1) * w / 2}px,${ty - (scale - 1) * hh / 2}px) scale(${scale})`;
  };
  const zoomTo = (s, cx, cy) => {
    const w = root.clientWidth, hh = root.clientHeight;
    const k = s / scale;
    // zoom around the touch point
    tx = (tx - (cx - w / 2)) * k + (cx - w / 2);
    ty = (ty - (cy - hh / 2)) * k + (cy - hh / 2);
    scale = s; clamp(); render();
  };
  root.addEventListener('pointerdown', (e) => {
    if (e.target === closeBtn || closeBtn.contains(e.target)) return;
    root.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 2) { const [a, b] = [...pts.values()]; startDist = Math.hypot(a.x - b.x, a.y - b.y); startScale = scale; }
    last = { x: e.clientX, y: e.clientY };
    const now = Date.now();
    if (pts.size === 1 && now - lastTap < 280) { scale > 1.05 ? (scale = 1, tx = ty = 0, render()) : zoomTo(2.6, e.clientX, e.clientY); lastTap = 0; }
    else lastTap = now;
    hint.style.opacity = '0';
  });
  root.addEventListener('pointermove', (e) => {
    if (!pts.has(e.pointerId)) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 2) {
      const [a, b] = [...pts.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      zoomTo(Math.min(6, Math.max(1, startScale * d / startDist)), (a.x + b.x) / 2, (a.y + b.y) / 2);
    } else if (pts.size === 1 && scale > 1) {
      tx += e.clientX - last.x; ty += e.clientY - last.y; clamp(); render();
    }
    last = { x: e.clientX, y: e.clientY };
  });
  const up = (e) => { pts.delete(e.pointerId); if (scale < 1.02) { scale = 1; tx = ty = 0; render(); } };
  root.addEventListener('pointerup', up); root.addEventListener('pointercancel', up);
  root.addEventListener('wheel', (e) => { e.preventDefault(); zoomTo(Math.min(6, Math.max(1, scale * (e.deltaY < 0 ? 1.15 : 0.87))), e.clientX, e.clientY); if (scale === 1) { tx = ty = 0; render(); } }, { passive: false });

  const finish = (fromPop) => {
    if (closed) return; closed = true;
    window.removeEventListener('popstate', onPop);
    document.removeEventListener('keydown', onKey);
    root.classList.add('out');
    setTimeout(() => root.remove(), 200);
    if (!fromPop && history.state?.viewer) history.back();
  };
  const onPop = () => finish(true);
  const onKey = (e) => e.key === 'Escape' && finish(false);
  closeBtn.addEventListener('click', () => finish(false));
  history.pushState({ viewer: true }, '');
  window.addEventListener('popstate', onPop);
  document.addEventListener('keydown', onKey);
  document.body.append(root);
  setTimeout(() => { hint.style.opacity = '0'; }, 3200);
}
