import { APP, LANGS } from './config.js';
import { storage } from './lib/dom.js';
import { pickLanguage } from './lib/search.js';

const state = { code: APP.fallbackLang, dict: {}, fallback: {}, nf: new Intl.NumberFormat('en') };
const cache = new Map();

export const supported = () => LANGS.map((l) => l.code);
export const currentLang = () => state.code;
export const langInfo = (code = state.code) => LANGS.find((l) => l.code === code) || LANGS[1];

async function load(code) {
  if (cache.has(code)) return cache.get(code);
  const res = await fetch(`${APP.translationsDir}${code}.json`);
  if (!res.ok) throw new Error(`translation ${code}: ${res.status}`);
  const json = await res.json();
  cache.set(code, json);
  return json;
}

/** Detect on first run only; a manual choice (stored) always wins afterwards. */
export function detectLanguage() {
  const manual = storage.get('lang');
  if (manual && supported().includes(manual)) return manual;
  const list = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language]);
  return pickLanguage(list, supported(), APP.fallbackLang);
}

export async function setLanguage(code, { persist = false } = {}) {
  if (!supported().includes(code)) code = APP.fallbackLang;
  if (!Object.keys(state.fallback).length) state.fallback = await load(APP.fallbackLang);
  state.dict = code === APP.fallbackLang ? state.fallback : await load(code);
  state.code = code;
  if (persist) storage.set('lang', code);
  try { state.nf = new Intl.NumberFormat(code); } catch { state.nf = new Intl.NumberFormat('en'); }
  const info = langInfo(code);
  const root = document.documentElement;
  root.lang = code;
  root.dir = info.dir;
  document.title = APP.name;
}

export const isRtl = () => langInfo().dir === 'rtl';
export const fmt = (n) => state.nf.format(n);

/** t('key', {n: 3}) — falls back to English, then to the key itself. {n} is localised. */
export function t(key, vars) {
  let s = state.dict[key] ?? state.fallback[key] ?? key;
  if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? (typeof vars[k] === 'number' ? fmt(vars[k]) : vars[k]) : m));
  return s;
}

// ----- content localisation helpers (UI chrome only — never the prompt text itself) -----
export const catName = (c) => c?.names?.[state.code] || c?.names?.[APP.fallbackLang] || c?.id || '';
export const promptTitle = (p) => p.i18n?.[state.code]?.title || p.title;
export const promptDesc = (p) => p.i18n?.[state.code]?.description || p.description;
export const langLabel = (code) => LANGS.find((l) => l.code === code)?.native || code;
