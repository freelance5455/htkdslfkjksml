import { APP } from './config.js';
import { storage } from './lib/dom.js';
import { buildIndex } from './lib/search.js';

export const content = { categories: [], prompts: [], catById: new Map(), byId: new Map(), counts: new Map() };
const listeners = new Set();
export const subscribe = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = (what) => listeners.forEach((fn) => fn(what));

/** Loads data/categories.json + data/prompts.json (both bundled in the app → works offline). */
export async function loadContent() {
  const [cj, pj] = await Promise.all([APP.categoriesUrl, APP.dataUrl].map(async (u) => {
    const r = await fetch(u);
    if (!r.ok) throw new Error(`${u}: ${r.status}`);
    return r.json();
  }));
  const published = (x) => (x.status ?? 'published') === 'published';
  content.categories = (cj.categories || []).filter(published).sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
  content.catById = new Map(content.categories.map((c) => [c.id, c]));
  const seen = new Set();
  content.prompts = (pj.prompts || []).filter(published).filter((p) => {
    const ok = p && p.id && p.title && typeof p.prompt === 'string' && !seen.has(p.id);
    if (!ok) console.warn('[PromptVerse] skipped invalid or duplicate prompt', p && p.id);
    else seen.add(p.id);
    return ok;
  }).map((p) => ({
    tags: [], popularity: 0, order: 0, featured: false, createdAt: '', promptLang: 'en', thumb: p.image, ...p,
  }));
  for (const p of content.prompts) if (!content.catById.has(p.categoryId)) console.warn('[PromptVerse] unknown categoryId', p.id, p.categoryId);
  buildIndex(content.prompts, content.catById);
  content.byId = new Map(content.prompts.map((p) => [p.id, p]));
  content.counts = new Map();
  for (const p of content.prompts) content.counts.set(p.categoryId, (content.counts.get(p.categoryId) || 0) + 1);
}

/** Cover for a category card: explicit `cover` field, else the newest prompt's thumbnail, else none (gradient only). */
export function categoryCover(cat) {
  if (cat.cover) return cat.cover;
  let best = null;
  for (const p of content.prompts) if (p.categoryId === cat.id && (!best || (p.createdAt || '') > (best.createdAt || ''))) best = p;
  return best ? best.thumb : null;
}

// ---------------- favourites (persisted) ----------------
const favIds = () => storage.get('fav', []).filter((id) => content.byId.has(id));
export const favorites = () => favIds().map((id) => content.byId.get(id));
export const isFav = (id) => storage.get('fav', []).includes(id);
export function toggleFav(id) {
  const cur = storage.get('fav', []);
  const on = !cur.includes(id);
  storage.set('fav', on ? [id, ...cur] : cur.filter((x) => x !== id));
  emit({ type: 'fav', id, on });
  return on;
}
export function clearFavorites() { storage.set('fav', []); emit({ type: 'fav' }); }

// ---------------- history (persisted) ----------------
export const history = () => storage.get('hist', []).filter((h) => content.byId.has(h.id)).map((h) => content.byId.get(h.id));
export function addHistory(id) {
  const cur = storage.get('hist', []).filter((h) => h.id !== id);
  cur.unshift({ id, t: Date.now() });
  storage.set('hist', cur.slice(0, APP.historyLimit));
}
export function clearHistory() { storage.set('hist', []); emit({ type: 'hist' }); }

// ---------------- theme ----------------
export const getTheme = () => storage.get('theme', 'dark');
export function applyTheme(mode = getTheme()) {
  const dark = mode === 'dark' || (mode === 'system' && !(window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches));
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.content = dark ? '#0b0a14' : '#faf6ef';
}
export function setTheme(mode) { storage.set('theme', mode); applyTheme(mode); }
