// Clipboard + share. Uses the Capacitor plugins when running inside the Android shell and
// falls back to standard web APIs, so the same code also works in a normal browser.
const cap = () => window.Capacitor;
const plugin = (name) => { try { return cap()?.Plugins?.[name]; } catch { return undefined; } };
export const isNative = () => !!cap()?.isNativePlatform?.();

/** Copies the EXACT string (no additions, no trimming, newlines preserved). Resolves true/false. */
export async function copyText(text) {
  try { const P = plugin('Clipboard'); if (P?.write) { await P.write({ string: text }); return true; } } catch { /* try next */ }
  try { if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); return true; } } catch { /* try next */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;inset-inline-start:0;opacity:0;pointer-events:none';
    document.body.append(ta);
    ta.focus({ preventScroll: true });
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch { return false; }
}

/** Shares only the prompt text (plus a title). Returns 'shared' | 'cancelled' | 'unsupported' | 'error'. */
export async function shareText({ title, text }) {
  try {
    const P = plugin('Share');
    if (P?.share) { await P.share({ title, text, dialogTitle: title }); return 'shared'; }
    if (navigator.share) { await navigator.share({ title, text }); return 'shared'; }
    return 'unsupported';
  } catch (e) {
    return /cancel|abort/i.test(String(e?.name || e?.message || e)) ? 'cancelled' : 'error';
  }
}

export const buzz = (ms = 12) => { try { navigator.vibrate?.(ms); } catch { /* ignore */ } };
