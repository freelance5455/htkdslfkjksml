import { h } from '../lib/dom.js';
import { t, promptTitle, catName } from '../i18n.js';
import { content, favorites, history, clearHistory } from '../store.js';
import { promptCard, emptyState, sectionHead, confirmDialog, toast } from '../ui.js';

export function renderFavorites({ rerender }) {
  const page = h('div', { class: 'page' });
  const favs = favorites();
  page.append(h('header', { class: 'topbar' }, h('div', {}, h('h1', { class: 'page-title' }, t('nav.favorites')),
    favs.length ? h('div', { class: 'page-sub' }, t('count.prompts', { n: favs.length })) : null)));

  page.append(favs.length
    ? h('div', { class: 'masonry' }, favs.map((p) => promptCard(p)))
    : emptyState('heart', t('favorites.empty'), t('favorites.emptyHint')));

  const hist = history();
  const head = sectionHead(t('history.title'), 'clock');
  if (hist.length) {
    head.append(h('button', { type: 'button', onclick: async () => { if (await confirmDialog(t('confirm.clearHistory'))) { clearHistory(); toast(t('toast.cleared')); rerender(); } } }, t('settings.clearHistory')));
  }
  page.append(h('section', { class: 'section' }, head,
    hist.length
      ? h('div', { class: 'stack' }, hist.slice(0, 12).map((p) => {
        const cat = content.catById.get(p.categoryId);
        return h('a', { class: 'row', href: `#/prompt/${encodeURIComponent(p.id)}` },
          h('div', { class: 'thumb' }, h('img', { src: p.thumb, alt: '', loading: 'lazy', decoding: 'async' })),
          h('div', { class: 'meta' }, h('b', {}, promptTitle(p)), h('span', {}, cat ? catName(cat) : '')));
      }))
      : h('p', { class: 'pad', style: { color: 'var(--muted)', fontSize: '13.5px' } }, t('history.empty'))));
  return page;
}
