import { h, svg } from '../lib/dom.js';
import { t, catName, fmt } from '../i18n.js';
import { content } from '../store.js';
import { filterCategories, sortPrompts } from '../lib/search.js';
import { categoryCard, promptCard, emptyState, go } from '../ui.js';
import { storage } from '../lib/dom.js';

export function renderCategories() {
  const page = h('div', { class: 'page' });
  const grid = h('div', { class: 'cat-masonry' });
  const draw = (q = '') => {
    const list = filterCategories(content.categories, q, catName);
    grid.replaceChildren(...list.map((c, i) => categoryCard(c, i)));
    if (!list.length) grid.replaceChildren(emptyState('search', t('categories.empty')));
  };
  const input = h('input', { type: 'search', placeholder: t('categories.search'), autocomplete: 'off', 'aria-label': t('categories.search'),
    oninput: (e) => draw(e.target.value) });
  page.append(
    h('header', { class: 'topbar' }, h('div', {}, h('h1', { class: 'page-title' }, t('nav.categories')),
      h('div', { class: 'page-sub' }, t('count.prompts', { n: content.prompts.length }) + ' · ' + fmt(content.categories.length) + ' ' + t('nav.categories')))),
    h('div', { class: 'pad', style: { marginBottom: '16px' } }, h('label', { class: 'searchbar solid' }, svg('search'), input)),
    grid);
  draw();
  return page;
}

export function renderCategory({ params }) {
  const cat = content.catById.get(params.id);
  const page = h('div', { class: 'page' });
  const back = h('button', { class: 'icon-btn', type: 'button', 'aria-label': t('common.back'), onclick: () => history.length > 1 ? history.back() : go('/categories', { replace: true }) }, svg('back', { cls: 'dir-icon' }));
  if (!cat) { page.append(h('header', { class: 'topbar' }, back), emptyState('search', t('categories.empty'))); return page; }
  let sort = storage.get('catsort', 'newest');
  const items = content.prompts.filter((p) => p.categoryId === cat.id);
  const grid = h('div', { class: 'masonry' });
  const draw = () => grid.replaceChildren(...sortPrompts(items, sort).map((p) => promptCard(p)));
  const sel = h('select', { 'aria-label': t('sort.label'), onchange: (e) => { sort = e.target.value; storage.set('catsort', sort); draw(); } },
    ['newest', 'popular', 'title', 'oldest'].map((k) => h('option', { value: k, selected: k === sort }, t(`sort.${k}`))));
  page.append(
    h('header', { class: 'topbar' }, back,
      h('div', { style: { flex: '1', minWidth: '0' } }, h('h1', { class: 'page-title', style: { fontSize: '22px' } }, catName(cat)),
        h('div', { class: 'page-sub' }, t('count.prompts', { n: items.length })))),
    h('div', { class: 'pad', style: { marginTop: '4px' } },
      h('div', { style: { display: 'flex', alignItems: 'center', gap: '12px', padding: '16px', borderRadius: 'var(--r-lg)', color: '#fff',
        background: `linear-gradient(135deg,${cat.colors[0]},${cat.colors[1]})` } },
        h('span', { class: 'ci', style: { width: '44px', height: '44px', borderRadius: '15px', background: 'rgba(255,255,255,.22)', display: 'grid', placeItems: 'center' } }, svg(cat.icon)),
        h('b', {}, catName(cat)))),
    items.length ? h('div', { class: 'filters' }, h('label', { class: 'select' }, sel, svg('chevron'))) : null,
    h('div', { style: { height: '14px' } }),
    items.length ? grid : emptyState(cat.icon, t('category.noPrompts')));
  draw();
  return page;
}
