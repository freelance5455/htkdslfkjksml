import { h, svg, lazyImg, storage } from '../lib/dom.js';
import { APP } from '../config.js';
import { t, catName } from '../i18n.js';
import { content, favorites, history } from '../store.js';
import { sortPrompts } from '../lib/search.js';
import { promptCard, categoryCard, sectionHead, emptyState, languageSheet, go } from '../ui.js';
import { setLanguage } from '../i18n.js';
import { currentLang } from '../i18n.js';

const sameSet = (a, b) => a.length === b.length && a.every((p) => b.includes(p));

export function renderHome({ rerender }) {
  const all = content.prompts;
  const page = h('div', { class: 'page' });

  // ---- header
  page.append(h('header', { class: 'topbar' },
    h('div', { class: 'brand' },
      h('div', { class: 'brand-mark' }, svg('prism')),
      h('div', {}, h('span', { class: 'brand-name' }, APP.name), h('span', { class: 'brand-tag' }, t('app.tagline')))),
    h('button', { class: 'lang-btn', type: 'button', 'aria-label': t('settings.language'),
      onclick: () => languageSheet(async (code) => { await setLanguage(code, { persist: true }); rerender(); })
    }, svg('globe'), currentLang())));

  if (!all.length) { page.append(emptyState('sparkles', t('home.empty'))); return page; }

  // ---- hero + search
  const newest = sortPrompts(all, 'newest');
  const featured = all.filter((p) => p.featured);
  const heroPrompt = (featured.length ? sortPrompts(featured, 'popular') : newest)[0];
  const input = h('input', { type: 'search', enterkeyhint: 'search', placeholder: t('home.searchPlaceholder'), 'aria-label': t('nav.search'), autocomplete: 'off' });
  const form = h('form', { class: 'searchbar', onsubmit: (e) => { e.preventDefault(); storage.set('q', input.value.trim()); go('/search', { replace: true }); } },
    svg('search'), input);
  page.append(h('section', { class: 'hero' },
    h('div', { class: 'hero-bg' }, heroPrompt ? lazyImg(heroPrompt.image, '', { eager: true }) : null),
    h('h1', {}, t('home.heroTitle')), h('p', {}, t('home.heroSub')), form));

  // ---- category quick access
  const strip = h('div', { class: 'rail cat-strip', role: 'list' }, content.categories.map((c) =>
    h('a', { class: 'chip', role: 'listitem', href: `#/category/${encodeURIComponent(c.id)}` },
      h('span', { class: 'dot', style: { background: `linear-gradient(135deg,${c.colors[0]},${c.colors[1]})` } }, svg(c.icon)), catName(c))));
  page.append(h('section', { class: 'section' }, sectionHead(t('home.browse'), null, t('home.seeAll'), '#/categories'), strip));

  // ---- curated sections (dropped if they would just repeat an earlier one)
  const sections = [
    { id: 'new', icon: 'sparkles', items: newest.slice(0, 10), variant: 'card--rail' },
    { id: 'popular', icon: 'flame', items: sortPrompts(all, 'popular').slice(0, 10), variant: 'card--rank', rank: true },
    { id: 'featured', icon: 'star', items: sortPrompts(featured, 'popular').slice(0, 10), variant: 'card--wide' },
  ];
  const shown = [];
  for (const s of sections) {
    if (!s.items.length || shown.some((o) => sameSet(o, s.items))) continue;
    shown.push(s.items);
    // The first section is shown as big cards so that a small library still feels rich.
    const variant = shown.length === 1 ? 'card--wide' : s.variant;
    page.append(h('section', { class: 'section' },
      sectionHead(t(`home.${s.id}`), s.icon),
      h('div', { class: 'rail' }, s.items.map((p, i) => promptCard(p, { variant, rank: s.rank ? i + 1 : 0 })))));
  }

  // ---- personal sections
  const favs = favorites();
  if (favs.length) page.append(h('section', { class: 'section' },
    sectionHead(t('home.favorites'), 'heart', t('home.seeAll'), '#/favorites'),
    h('div', { class: 'rail' }, favs.slice(0, 10).map((p) => promptCard(p, { variant: 'card--rail' })))));
  const recent = history();
  if (recent.length) page.append(h('section', { class: 'section' },
    sectionHead(t('home.recent'), 'clock'),
    h('div', { class: 'rail' }, recent.slice(0, 10).map((p) => promptCard(p, { variant: 'card--rail' })))));

  return page;
}
