import { h, svg } from '../lib/dom.js';
import { APP } from '../config.js';
import { t, setLanguage } from '../i18n.js';
import { getTheme, setTheme, clearFavorites, clearHistory } from '../store.js';
import { languageList, confirmDialog, toast } from '../ui.js';

export function renderSettings({ rerender }) {
  const page = h('div', { class: 'page' });
  page.append(h('header', { class: 'topbar' }, h('h1', { class: 'page-title' }, t('nav.settings'))));

  // language
  page.append(h('section', { class: 'group' }, h('h2', {}, t('settings.language')),
    h('div', { class: 'group-card' }, languageList(async (code) => {
      await setLanguage(code, { persist: true });
      rerender();
      toast(t('toast.langChanged'));
    }, 'lang-grid')),
    h('p', { class: 'hint' }, t('settings.languageHint'))));

  // appearance
  const cur = getTheme();
  const seg = h('div', { class: 'seg' }, [['system', 'system'], ['dark', 'moon'], ['light', 'sun']].map(([k, ic]) =>
    h('button', { type: 'button', class: k === cur ? 'is-active' : '', onclick: () => { setTheme(k); rerender(); } }, svg(ic), t(`theme.${k}`))));
  page.append(h('section', { class: 'group' }, h('h2', {}, t('settings.theme')), h('div', { class: 'group-card' }, seg)));

  // data
  page.append(h('section', { class: 'group' }, h('h2', {}, t('settings.data')), h('div', { class: 'group-card' },
    h('button', { class: 'list-btn', type: 'button', onclick: async () => { if (await confirmDialog(t('confirm.clearHistory'))) { clearHistory(); toast(t('toast.cleared')); } } }, svg('clock'), t('settings.clearHistory')),
    h('button', { class: 'list-btn danger', type: 'button', onclick: async () => { if (await confirmDialog(t('confirm.clearFavorites'))) { clearFavorites(); toast(t('toast.cleared')); } } }, svg('heart'), t('settings.clearFavorites')))));

  // about
  page.append(h('section', { class: 'group' }, h('h2', {}, t('settings.about')), h('div', { class: 'group-card about' },
    h('div', { class: 'brand-mark', style: { width: '54px', height: '54px', borderRadius: '18px', flex: 'none' } }, svg('prism')),
    h('div', {}, h('p', {}, t('settings.aboutText')), h('b', {}, `${APP.name} · ${t('settings.version', { v: APP.version })}`)))));
  return page;
}
