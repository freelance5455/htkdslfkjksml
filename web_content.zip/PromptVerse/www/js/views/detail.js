import { h, svg, lazyImg, storage } from '../lib/dom.js';
import { APP } from '../config.js';
import { t, catName, promptTitle, promptDesc, langLabel } from '../i18n.js';
import { content, isFav, toggleFav, addHistory } from '../store.js';
import { similarPrompts } from '../lib/search.js';
import { copyText, shareText, buzz } from '../native.js';
import { toast, promptCard, sectionHead, openViewer, emptyState, go } from '../ui.js';

const RTL_LANGS = ['fa', 'ar', 'he', 'ur', 'ps', 'ckb'];
const back = () => (history.length > 1 ? history.back() : go('/home', { replace: true }));

export function renderDetail({ params }) {
  const p = content.byId.get(params.id);
  const page = h('div', { class: 'page is-detail' });
  const backBtn = (cls = 'glass-btn') => h('button', { class: cls, type: 'button', 'aria-label': t('common.back'), onclick: back }, svg('back', { cls: 'dir-icon' }));
  if (!p) {
    page.append(h('header', { class: 'topbar' }, backBtn('icon-btn')), emptyState('search', t('detail.notFound')));
    return { el: page, detail: true };
  }
  addHistory(p.id);
  const cat = content.catById.get(p.categoryId);

  // ---- hero image (tap → full screen)
  const open = () => openViewer(p.image, promptTitle(p));
  const hero = h('div', { class: 'detail-hero', role: 'button', tabindex: '0', 'aria-label': t('detail.imageHint'), onclick: open,
    onkeydown: (e) => (e.key === 'Enter' || e.key === ' ') && open() },
    lazyImg(p.image, promptTitle(p), { eager: true }),
    h('div', { class: 'detail-bar' }, backBtn(),
      h('button', { class: 'glass-btn', type: 'button', 'aria-label': t('detail.imageHint'), onclick: (e) => { e.stopPropagation(); open(); } }, svg('expand'))),
    h('div', { class: 'zoom-hint' }, svg('expand'), t('detail.imageHint')));

  // ---- prompt text box: rendered with textContent so it is shown exactly as stored
  const rtl = RTL_LANGS.includes(p.promptLang);
  const text = h('div', { class: 'prompt-text', lang: p.promptLang, dir: rtl ? 'rtl' : 'ltr', tabindex: '0' });
  text.textContent = p.prompt;

  const similar = similarPrompts(p, content.prompts, APP.similarLimit);
  const body = h('div', { class: 'sheet-body' },
    cat ? h('a', { class: 'cat-link', href: `#/category/${encodeURIComponent(cat.id)}`, style: { '--c1': cat.colors[0], '--c2': cat.colors[1] } }, svg(cat.icon), catName(cat)) : null,
    h('h1', { class: 'detail-title' }, promptTitle(p)),
    promptDesc(p) ? h('p', { class: 'detail-desc' }, promptDesc(p)) : null,
    h('section', { class: 'block' }, h('h2', {}, svg('text'), t('detail.promptText')),
      h('div', { class: 'prompt-box' }, text,
        h('div', { class: 'prompt-meta' }, svg('globe'), t('detail.original', { lang: langLabel(p.promptLang) })))),
    p.tags.length ? h('section', { class: 'block' }, h('h2', {}, t('detail.tags')),
      h('div', { class: 'tags' }, p.tags.map((x) => h('a', { class: 'tag', href: '#/search', onclick: (e) => {
        e.preventDefault(); storage.set('q', x); go('/search'); // tag → search pre-filled
      } }, '#' + x)))) : null);

  page.append(hero, body);
  if (similar.length) page.append(h('section', { class: 'section' }, sectionHead(t('detail.similar'), 'sparkles'),
    h('div', { class: 'rail' }, similar.map((s) => promptCard(s, { variant: 'card--rail' })))));

  // ---- sticky action bar: copy (primary) · favourite · share
  const copyBtn = h('button', { class: 'btn btn-primary btn-copy', type: 'button' },
    h('span', { class: 'swap' }, svg('copy'), t('detail.copy')));
  let resetTimer;
  copyBtn.addEventListener('click', async () => {
    const ok = await copyText(p.prompt); // exact stored text, nothing added
    if (!ok) {
      const r = document.createRange(); r.selectNodeContents(text);
      const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
      toast(t('toast.copyFailed'), 'error');
      return;
    }
    buzz(18);
    copyBtn.classList.remove('is-done'); void copyBtn.offsetWidth; copyBtn.classList.add('is-done');
    copyBtn.replaceChildren(h('span', { class: 'swap' }, svg('check'), t('detail.copied')));
    toast(t('toast.copied'));
    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => {
      copyBtn.classList.remove('is-done');
      copyBtn.replaceChildren(h('span', { class: 'swap' }, svg('copy'), t('detail.copy')));
    }, 2200);
  });

  const favBtn = h('button', { class: 'sq', type: 'button' });
  const paintFav = () => {
    const on = isFav(p.id);
    favBtn.classList.toggle('is-on', on);
    favBtn.setAttribute('aria-pressed', String(on));
    favBtn.setAttribute('aria-label', t(on ? 'detail.unfav' : 'detail.fav'));
    favBtn.replaceChildren(svg('heart', { fill: on }));
  };
  paintFav();
  favBtn.addEventListener('click', () => {
    const on = toggleFav(p.id); paintFav(); buzz(10);
    favBtn.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.25)' }, { transform: 'scale(1)' }], { duration: 380, easing: 'cubic-bezier(.2,.8,.2,1)' });
    toast(t(on ? 'toast.favAdded' : 'toast.favRemoved'));
  });

  const shareBtn = h('button', { class: 'sq', type: 'button', 'aria-label': t('detail.share'), onclick: async () => {
    const r = await shareText({ title: promptTitle(p), text: p.prompt });
    if (r === 'unsupported') { // no share sheet available → copy instead
      (await copyText(p.prompt)) ? toast(t('toast.copied')) : toast(t('toast.shareFailed'), 'error');
    } else if (r === 'error') toast(t('toast.shareFailed'), 'error');
  } }, svg('share'));

  const bar = h('div', { class: 'actionbar' }, copyBtn, favBtn, shareBtn);
  return { el: page, detail: true, extra: bar };
}
