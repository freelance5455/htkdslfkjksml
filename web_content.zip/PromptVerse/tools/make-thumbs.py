"""Creates small card thumbnails (540 px wide, "<name>.thumb.jpg") for every image in
www/assets/images that does not have one yet.   python3 tools/make-thumbs.py   (needs: pip install pillow)
Thumbnails keep the home/search grids fast and light on memory when you have hundreds of prompts."""
import os, sys
from PIL import Image
D = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "www/assets/images")
made = 0
for root, _, files in os.walk(D):
    for f in files:
        base, ext = os.path.splitext(f)
        if ext.lower() not in (".jpg", ".jpeg", ".png", ".webp") or base.endswith(".thumb"):
            continue
        out = os.path.join(root, base + ".thumb.jpg")
        if os.path.exists(out):
            continue
        im = Image.open(os.path.join(root, f)).convert("RGB")
        im.thumbnail((540, 900), Image.LANCZOS)
        im.save(out, quality=82, optimize=True)
        print("created", os.path.relpath(out, D)); made += 1
print(f"{made} thumbnail(s) created.")
