"""Builds the small bundled web fonts from locally installed open-licence fonts.
Needs: pip install fonttools  (and the source fonts listed below).
Re-run after adding Chinese text if you want the bundled Chinese subset to cover new characters
(on Android, missing glyphs fall back to the system Chinese font anyway)."""
import json, os, glob
from fontTools import subset
from fontTools.ttLib import TTCollection
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "www/assets/fonts"); os.makedirs(OUT, exist_ok=True)
LATIN = list(range(0x20, 0x7F)) + list(range(0xA0, 0x180)) + list(range(0x400, 0x460)) + \
        [0x2013, 0x2014, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2026, 0x20AC, 0x2192, 0x2190, 0x200C, 0x200D, 0x200E, 0x200F, 0x2212]
ARABIC = list(range(0x20, 0x7F)) + list(range(0x600, 0x700)) + list(range(0x750, 0x780)) + \
         list(range(0xFB50, 0xFE00)) + list(range(0xFE70, 0xFF00)) + [0xAB, 0xBB, 0x200C, 0x200D, 0x200E, 0x200F, 0x2013, 0x2014, 0x2026, 0x2022]
DEVA = list(range(0x20, 0x7F)) + list(range(0x900, 0x980)) + [0x200C, 0x200D, 0x2013, 0x2014, 0x2026, 0x25CC]

def sub(src, dst, unicodes, font_number=0, layout=True, rename=None):
    opt = subset.Options(); opt.flavor = "woff"; opt.layout_features = ["*"] if layout else []
    opt.notdef_outline = True; opt.name_IDs = ["*"]; opt.hinting = False; opt.desubroutinize = True
    opt.font_number = font_number
    f = subset.load_font(src, opt)
    s = subset.Subsetter(opt); s.populate(unicodes=unicodes); s.subset(f)
    if rename:  # modified (subset) fonts must not keep a Reserved Font Name / upstream name
        for rec in list(f["name"].names):
            if rec.nameID in (1, 4, 16):
                rec.string = rename
            elif rec.nameID == 6:
                rec.string = rename.replace(" ", "-")
            elif rec.nameID in (3,):
                rec.string = rename + " subset"
    subset.save_font(f, os.path.join(OUT, dst), opt)
    print(dst, os.path.getsize(os.path.join(OUT, dst)) // 1024, "KB")

I = "/usr/share/fonts/opentype/inter/Inter-"
for w, n in (("Regular", 400), ("Medium", 500), ("SemiBold", 600), ("Bold", 700)):
    sub(f"{I}{w}.otf", f"inter-{n}.woff", LATIN)
sub("/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf", "lora-var.woff", list(range(0x20, 0x7F)), rename="PV Display")
sub("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "arabic-400.woff", ARABIC, rename="PV Arabic")
sub("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "arabic-700.woff", ARABIC, rename="PV Arabic")
sub("/usr/share/fonts/truetype/freefont/FreeSans.ttf", "deva-400.woff", DEVA)
sub("/usr/share/fonts/truetype/freefont/FreeSansBold.ttf", "deva-700.woff", DEVA)

chars = set()
for p in (glob.glob(os.path.join(ROOT, "www/translations/zh.json"))):
    chars |= set("".join(json.load(open(p, encoding="utf-8")).values()))
cats = json.load(open(os.path.join(ROOT, "www/data/categories.json"), encoding="utf-8"))["categories"]
for c in cats: chars |= set(c["names"].get("zh", ""))
chars |= set("，。、；：？！（）【】《》“”‘’…—·0123456789")
uni = sorted({ord(c) for c in chars if ord(c) > 0x7F} | set(range(0x20, 0x7F)))
for kind, dst in (("Regular", "hans-400.woff"), ("Bold", "hans-700.woff")):
    ttc = TTCollection(f"/usr/share/fonts/opentype/noto/NotoSansCJK-{kind}.ttc")
    idx = next(i for i, f in enumerate(ttc.fonts) if "SC" in f["name"].getDebugName(1))
    sub(f"/usr/share/fonts/opentype/noto/NotoSansCJK-{kind}.ttc", dst, uni, font_number=idx)
