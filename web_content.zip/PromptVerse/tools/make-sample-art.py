"""Generates the bundled sample image (original procedural illustration) and the app icon.
Run:  python3 tools/make-sample-art.py   (needs pillow, numpy, opencv-python)"""
import numpy as np, cv2, os, math
from PIL import Image, ImageDraw, ImageFilter
rng = np.random.default_rng(7)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
W, H = 1080, 1350

def lerp(a, b, t): return a + (b - a) * t
def grad(stops, n):
    ys = np.linspace(0, 1, n)
    out = np.zeros((n, 3))
    pos = [s[0] for s in stops]
    for c in range(3):
        out[:, c] = np.interp(ys, pos, [s[1][c] for s in stops])
    return out

def street():
    hor = int(H * 0.52)
    img = np.zeros((H, W, 3), np.float32)
    sky = grad([(0, (18, 14, 52)), (.45, (92, 40, 110)), (.8, (238, 112, 74)), (1, (255, 196, 110))], hor)
    img[:hor] = sky[:, None, :]
    # sun glow
    yy, xx = np.mgrid[0:H, 0:W]
    d = np.hypot((xx - W * .5) / W, (yy - hor) / H * 1.4)
    glow = np.exp(-d * d * 22)[..., None] * np.array([255, 190, 110])
    img += glow.astype(np.float32) * .75
    # buildings (3 layers)
    layer = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    dr = ImageDraw.Draw(layer, "RGBA")
    for li, (col, hmin, hmax, wmin, wmax) in enumerate([
        ((120, 64, 112, 255), 160, 380, 70, 140),
        ((74, 38, 84, 255), 220, 520, 80, 170),
        ((34, 20, 52, 255), 280, 640, 90, 200)]):
        x = -40
        while x < W:
            bw = int(rng.integers(wmin, wmax)); bh = int(rng.integers(hmin, hmax))
            dr.rectangle([x, hor - bh, x + bw, hor + 8], fill=col)
            if li >= 1:
                for wy in range(hor - bh + 24, hor - 14, 26):
                    for wx in range(x + 12, x + bw - 14, 22):
                        if rng.random() < .33:
                            dr.rectangle([wx, wy, wx + 8, wy + 12], fill=(255, 206, 120, int(rng.integers(120, 235))))
            x += bw + int(rng.integers(0, 14))
    img = np.asarray(layer).astype(np.float32)
    # wet street with perspective + reflections
    vx = W * .5
    road = np.zeros((H - hor, W, 3), np.float32)
    ry = np.linspace(0, 1, H - hor)
    base = grad([(0, (120, 70, 70)), (.25, (60, 34, 50)), (1, (14, 10, 24))], H - hor)
    road[:] = base[:, None, :]
    img[hor:] = road
    # reflect buildings/sky into street
    refl = img[:hor][::-1][: H - hor]
    refl = cv2.resize(refl, (W, H - hor))
    refl = cv2.GaussianBlur(refl, (0, 0), 14)
    wob = (np.sin(np.linspace(0, 60, H - hor))[:, None, None] * 6)
    img[hor:] = img[hor:] * .45 + refl * (.55 * (1 - ry[:, None, None] * .7))
    # light streaks on road
    streak = np.zeros((H - hor, W), np.float32)
    for _ in range(46):
        x0 = rng.uniform(0, W); w = rng.uniform(3, 16); a = rng.uniform(.25, .9)
        col = x0 + (x0 - vx) * ry * 1.2
        streak += a * np.exp(-((np.arange(W)[None, :] - col[:, None]) / (w * (.4 + ry[:, None] * 2.2))) ** 2) * (1 - ry[:, None] * .6)
    img[hor:] += streak[..., None] * np.array([255, 170, 90], np.float32) * .55
    # lane perspective lines
    L = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)); d2 = ImageDraw.Draw(L, "RGBA")
    for off in (-1500, -520, 520, 1500):
        d2.line([(vx + off * .02, hor + 4), (vx + off, H)], fill=(255, 200, 140, 38), width=3)
    img = np.asarray(L).astype(np.float32)
    # bokeh
    bok = np.zeros((H, W, 3), np.float32)
    for _ in range(95):
        cx = rng.uniform(0, W); cy = rng.uniform(hor - 330, hor + 260); r = rng.uniform(10, 46)
        hue = [(255, 176, 90), (255, 120, 90), (110, 200, 255), (255, 220, 160)][int(rng.integers(0, 4))]
        cv2.circle(bok, (int(cx), int(cy)), int(r), tuple(float(c) * rng.uniform(.25, .7) for c in hue), -1, cv2.LINE_AA)
    bok = cv2.GaussianBlur(bok, (0, 0), 3.2)
    img += bok
    # depth of field on background
    img = cv2.GaussianBlur(img, (0, 0), 4.2)
    return np.clip(img, 0, 255), hor

def person(img, hor):
    S = 3
    layer = Image.new("RGBA", (W * S // 2, H * S // 2), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    cx = int(W * .5 * S / 2) + 30; base = int(H * .93 * S / 2)
    sc = S / 2
    coat = (22, 18, 34, 255)
    # legs mid-stride
    d.polygon([(cx - 36 * sc, base - 300 * sc), (cx - 4 * sc, base - 300 * sc), (cx - 62 * sc, base), (cx - 100 * sc, base)], fill=(16, 14, 26, 255))
    d.polygon([(cx + 4 * sc, base - 300 * sc), (cx + 40 * sc, base - 300 * sc), (cx + 86 * sc, base - 20 * sc), (cx + 46 * sc, base - 14 * sc)], fill=(20, 16, 30, 255))
    d.ellipse([cx - 112 * sc, base - 14 * sc, cx - 40 * sc, base + 12 * sc], fill=(10, 8, 16, 255))
    d.ellipse([cx + 30 * sc, base - 22 * sc, cx + 104 * sc, base + 4 * sc], fill=(10, 8, 16, 255))
    # long coat
    d.polygon([(cx - 78 * sc, base - 640 * sc), (cx + 78 * sc, base - 640 * sc), (cx + 104 * sc, base - 250 * sc), (cx + 70 * sc, base - 150 * sc), (cx - 74 * sc, base - 150 * sc), (cx - 100 * sc, base - 260 * sc)], fill=coat)
    # arms
    d.polygon([(cx - 80 * sc, base - 628 * sc), (cx - 118 * sc, base - 600 * sc), (cx - 128 * sc, base - 340 * sc), (cx - 92 * sc, base - 330 * sc), (cx - 70 * sc, base - 520 * sc)], fill=(28, 22, 42, 255))
    d.polygon([(cx + 80 * sc, base - 628 * sc), (cx + 116 * sc, base - 596 * sc), (cx + 120 * sc, base - 360 * sc), (cx + 84 * sc, base - 352 * sc), (cx + 66 * sc, base - 520 * sc)], fill=(26, 20, 38, 255))
    # neck, head, hair
    d.rectangle([cx - 16 * sc, base - 690 * sc, cx + 16 * sc, base - 636 * sc], fill=(120, 78, 66, 255))
    d.ellipse([cx - 44 * sc, base - 784 * sc, cx + 44 * sc, base - 676 * sc], fill=(150, 98, 82, 255))
    d.pieslice([cx - 50 * sc, base - 800 * sc, cx + 50 * sc, base - 700 * sc], 180, 360, fill=(26, 18, 22, 255))
    layer = layer.resize((W, H), Image.LANCZOS)
    a = np.asarray(layer).astype(np.float32); alpha = a[..., 3:4] / 255
    rgb = a[..., :3]
    # warm rim light from the sunset (right/back side)
    mask = (alpha[..., 0] * 255).astype(np.uint8)
    edge = cv2.GaussianBlur(mask, (0, 0), 5).astype(np.float32) / 255
    edge = np.clip(alpha[..., 0] - edge, 0, 1)
    shift = np.roll(alpha[..., 0], -7, axis=1)
    rim = np.clip(alpha[..., 0] - shift, 0, 1)[..., None] * np.array([255, 170, 90]) * .9
    lit = rgb + rim
    # contact shadow / reflection on wet road
    refl = lit[::-1]; ralpha = alpha[::-1]
    sh = np.zeros((H, W, 1), np.float32)
    off = int(H * .93)
    ref_img = np.zeros_like(img); ref_a = np.zeros((H, W, 1), np.float32)
    top = H - off
    n = min(off - 0, H - off)
    seg = lit[:off][::-1][:n]; sega = alpha[:off][::-1][:n]
    ref_img[off:off + n] = cv2.GaussianBlur(seg, (0, 0), 9)
    ref_a[off:off + n] = cv2.GaussianBlur(sega[..., 0], (0, 0), 9)[..., None] * np.linspace(.42, 0, n)[:, None, None]
    img = img * (1 - ref_a) + ref_img * ref_a
    img = img * (1 - alpha) + lit * alpha
    return img

def finish(img):
    yy, xx = np.mgrid[0:H, 0:W]
    v = 1 - .55 * (((xx - W / 2) / (W / 1.1)) ** 2 + ((yy - H / 2) / (H / 1.05)) ** 2)
    img = img * np.clip(v, 0, 1)[..., None]
    img = (img / 255) ** 1.04
    img = img + rng.normal(0, .014, img.shape)  # film grain
    # teal shadows / warm highlights grade
    lum = img.mean(axis=2, keepdims=True)
    img = img + (1 - lum) * np.array([-.02, .015, .05]) + lum * np.array([.03, .005, -.03])
    return np.clip(img * 255, 0, 255).astype(np.uint8)

img, hor = street()
img = person(img, hor)
out = Image.fromarray(finish(img))
d = os.path.join(ROOT, "www/assets/images")
out.save(os.path.join(d, "sunset-street-portrait.jpg"), quality=86, optimize=True, progressive=True)
out.resize((540, 675), Image.LANCZOS).save(os.path.join(d, "sunset-street-portrait.thumb.jpg"), quality=82, optimize=True)

# ---------------- app icon ----------------
N = 1024; SS = 2
def icon_layer(size, with_bg):
    s = size * SS
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    if with_bg:
        arr = np.zeros((s, s, 3), np.float32)
        yy, xx = np.mgrid[0:s, 0:s]
        t = (xx + yy) / (2 * s)
        arr[..., 0] = lerp(24, 52, t); arr[..., 1] = lerp(16, 22, t); arr[..., 2] = lerp(60, 92, t)
        im = Image.fromarray(arr.astype(np.uint8)).convert("RGBA")
    # prism / diamond mark in safe zone (central 60%)
    m = Image.new("RGBA", (s, s), (0, 0, 0, 0)); md = ImageDraw.Draw(m)
    c = s / 2; r = s * .27
    pts = [(c, c - r * 1.15), (c + r, c), (c, c + r * 1.15), (c - r, c)]
    md.polygon(pts, fill=(255, 255, 255, 255))
    gm = np.zeros((s, s, 3), np.float32)
    yy, xx = np.mgrid[0:s, 0:s]; t = np.clip((xx / s + (1 - yy / s)) / 2 + .1, 0, 1)
    gm[..., 0] = lerp(255, 255, t); gm[..., 1] = lerp(214, 96, t); gm[..., 2] = lerp(110, 150, t)
    gimg = Image.fromarray(gm.astype(np.uint8)).convert("RGBA"); gimg.putalpha(m.split()[3])
    im = Image.alpha_composite(im, gimg)
    # facet split
    f = Image.new("RGBA", (s, s), (0, 0, 0, 0)); fd = ImageDraw.Draw(f)
    fd.polygon([(c, c - r * 1.15), (c + r, c), (c, c)], fill=(255, 255, 255, 70))
    fd.polygon([(c, c), (c - r, c), (c, c + r * 1.15)], fill=(40, 10, 60, 60))
    fd.line([(c, c - r * 1.15), (c, c + r * 1.15)], fill=(40, 10, 60, 80), width=max(2, s // 220))
    im = Image.alpha_composite(im, f)
    # spark
    sp = Image.new("RGBA", (s, s), (0, 0, 0, 0)); sd = ImageDraw.Draw(sp)
    sx, sy, sr = c + r * 1.05, c - r * 1.0, s * .07
    sd.polygon([(sx, sy - sr), (sx + sr * .22, sy - sr * .22), (sx + sr, sy), (sx + sr * .22, sy + sr * .22), (sx, sy + sr), (sx - sr * .22, sy + sr * .22), (sx - sr, sy), (sx - sr * .22, sy - sr * .22)], fill=(255, 240, 200, 255))
    im = Image.alpha_composite(im, sp)
    return im.resize((size, size), Image.LANCZOS)

base = icon_layer(N, True)
fg = icon_layer(N, False)
base.save(os.path.join(ROOT, "resources/icon.png"))
fg.save(os.path.join(ROOT, "resources/icon-foreground.png"))
def circ(im):
    s = im.size[0]; mk = Image.new("L", (s, s), 0); ImageDraw.Draw(mk).ellipse([0, 0, s - 1, s - 1], fill=255)
    o = im.copy(); o.putalpha(mk); return o
def rounded(im):
    s = im.size[0]; mk = Image.new("L", (s, s), 0); ImageDraw.Draw(mk).rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * .22), fill=255)
    o = im.copy(); o.putalpha(mk); return o
dens = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
for k, m_ in dens.items():
    dd = os.path.join(ROOT, f"resources/android/mipmap-{k}"); os.makedirs(dd, exist_ok=True)
    l = int(48 * m_); a = int(108 * m_)
    rounded(base).resize((l, l), Image.LANCZOS).save(os.path.join(dd, "ic_launcher.png"))
    circ(base).resize((l, l), Image.LANCZOS).save(os.path.join(dd, "ic_launcher_round.png"))
    fg.resize((a, a), Image.LANCZOS).save(os.path.join(dd, "ic_launcher_foreground.png"))
# web icon + favicon
base.resize((512, 512), Image.LANCZOS).save(os.path.join(ROOT, "www/assets/icons/app-icon-512.png"))
base.resize((192, 192), Image.LANCZOS).save(os.path.join(ROOT, "www/assets/icons/app-icon-192.png"))
print("done")

# ---------------- launch splash (replaces the default Capacitor splash image) ----------------
sp = Image.new("RGB", (1080, 1920), (11, 10, 20))
mark = fg.resize((560, 560), Image.LANCZOS)
sp.paste(mark, ((1080 - 560) // 2, (1920 - 560) // 2), mark)
sp.save(os.path.join(ROOT, "resources/android/splash.png"), optimize=True)
print("splash done")
