// Run AFTER `npx cap add android`:   npm run android:setup
// Copies the app icon + splash into the generated Android project and syncs the app name.
//   --strip-internet   also removes the INTERNET permission (the app works fully offline without it)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const RES = path.join(ROOT, 'android/app/src/main/res');
const SRC = path.join(ROOT, 'resources/android');
if (!fs.existsSync(RES)) {
  console.error('android/ folder not found. Run "npx cap add android" first (see docs/Build-APK.md).');
  process.exit(1);
}
const copy = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); };

// 1) launcher icons (legacy square + round + adaptive foreground)
for (const dir of fs.readdirSync(SRC).filter((d) => d.startsWith('mipmap-'))) {
  for (const f of fs.readdirSync(path.join(SRC, dir))) copy(path.join(SRC, dir, f), path.join(RES, dir, f));
}
// 2) adaptive-icon background colour (works for both the colour-resource and drawable styles of the template)
const BG = '#1B1033';
fs.mkdirSync(path.join(RES, 'values'), { recursive: true });
fs.writeFileSync(path.join(RES, 'values/ic_launcher_background.xml'),
  `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${BG}</color>\n</resources>\n`);
const bgDrawable = path.join(RES, 'drawable/ic_launcher_background.xml');
if (fs.existsSync(bgDrawable)) {
  fs.writeFileSync(bgDrawable,
    `<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">\n    <solid android:color="${BG}"/>\n</shape>\n`);
}
// 3) splash image used by the launch theme
let splashes = 0;
for (const dir of fs.readdirSync(RES).filter((d) => d.startsWith('drawable'))) {
  const f = path.join(RES, dir, 'splash.png');
  if (fs.existsSync(f)) { copy(path.join(SRC, 'splash.png'), f); splashes++; }
}
// 4) app name from capacitor.config.json
const { appName } = JSON.parse(fs.readFileSync(path.join(ROOT, 'capacitor.config.json'), 'utf8'));
const strings = path.join(RES, 'values/strings.xml');
if (fs.existsSync(strings)) {
  const esc = appName.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  let x = fs.readFileSync(strings, 'utf8');
  x = x.replace(/(<string name="app_name">)[^<]*(<\/string>)/, `$1${esc}$2`).replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, `$1${esc}$2`);
  fs.writeFileSync(strings, x);
}
// 5) optional: drop INTERNET permission
if (process.argv.includes('--strip-internet')) {
  const mf = path.join(ROOT, 'android/app/src/main/AndroidManifest.xml');
  const x = fs.readFileSync(mf, 'utf8').replace(/\s*<uses-permission android:name="android.permission.INTERNET"\s*\/>/g, '');
  fs.writeFileSync(mf, x);
  console.log('INTERNET permission removed.');
}
console.log(`Done: icons copied, ${splashes} splash image(s) replaced, app name set to "${appName}".`);
