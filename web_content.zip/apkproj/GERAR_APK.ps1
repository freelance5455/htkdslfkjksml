﻿# ULTIMO SINAL V28 - gera o APK de forma automatica (instala Node, JDK 17 e Android SDK se faltarem)
# Uso (PowerShell):  powershell -ExecutionPolicy Bypass -File .\GERAR_APK.ps1
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location $PSScriptRoot

function Etapa($m) { Write-Host "`n>> $m" -ForegroundColor Cyan }
function Falha($m) { Write-Host "`nERRO: $m" -ForegroundColor Red; Read-Host "Pressione ENTER para sair"; exit 1 }
function AtualizaPath {
  $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
}
function Tem($cmd) { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function JavaMajor {
  if (-not (Tem 'java')) { return 0 }
  $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
  $v = (& java -version 2>&1 | Out-String); $ErrorActionPreference = $old
  if ($v -match 'version "(\d+)(?:\.(\d+))?') { if ($Matches[1] -eq '1') { return [int]$Matches[2] } else { return [int]$Matches[1] } }
  return 0
}

if (-not (Test-Path (Join-Path $PSScriptRoot 'ULTIMO_SINAL_V28_PROTOCOLO_OMEGA.html'))) { Falha 'O arquivo ULTIMO_SINAL_V28_PROTOCOLO_OMEGA.html precisa estar nesta pasta.' }

# 1) Node.js
Etapa 'Verificando Node.js'
$nodeOk = $false
if (Tem 'node') { $nm = [int](& node -p "process.versions.node.split('.')[0]"); $nodeOk = ($nm -ge 18) }
if (-not $nodeOk) {
  if (-not (Tem 'winget')) { Falha 'winget nao encontrado. Instale o Node.js 18+ manualmente em https://nodejs.org e rode de novo.' }
  Etapa 'Instalando Node.js LTS'
  winget install -e --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
  AtualizaPath
  if (-not (Tem 'node')) { Falha 'Node instalado, mas nao reconhecido. Feche e reabra o PowerShell e rode de novo.' }
}
Write-Host ('Node ' + (& node -v)) -ForegroundColor Green

# 2) JDK 17
Etapa 'Verificando JDK 17'
if ((JavaMajor) -lt 17) {
  if (-not (Tem 'winget')) { Falha 'winget nao encontrado. Instale o JDK 17 manualmente (Temurin 17) e rode de novo.' }
  Etapa 'Instalando JDK 17 (Temurin)'
  winget install -e --id EclipseAdoptium.Temurin.17.JDK --silent --accept-package-agreements --accept-source-agreements
  AtualizaPath
  $jdk = Get-ChildItem 'C:\Program Files\Eclipse Adoptium' -Directory -Filter 'jdk-17*' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
  if ($jdk) { $env:JAVA_HOME = $jdk.FullName; $env:Path = "$($jdk.FullName)\bin;$env:Path" }
  if ((JavaMajor) -lt 17) { Falha 'JDK 17 nao foi reconhecido. Feche e reabra o PowerShell e rode de novo.' }
}
Write-Host ('Java ' + (JavaMajor)) -ForegroundColor Green

# 3) Android SDK
Etapa 'Verificando Android SDK'
$sdk = $env:ANDROID_HOME
if (-not $sdk -or -not (Test-Path $sdk)) { $sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
New-Item -ItemType Directory -Force -Path $sdk | Out-Null
$sdkm = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
if (-not (Test-Path $sdkm)) {
  Etapa 'Baixando Android command-line tools'
  $zip = Join-Path $env:TEMP 'cmdline-tools.zip'
  # Reutiliza o download BITS ja concluido, se existir; evita baixar o mesmo arquivo duas vezes.
  if (-not (Test-Path $zip) -or (Get-Item $zip).Length -lt 50000000) {
    if (Test-Path $zip) { Remove-Item $zip -Force }
    Etapa 'Baixando Android command-line tools (aprox. 150 MB)'
    Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/commandlinetools-win-14742923_latest.zip' -OutFile $zip
  } else {
    Write-Host 'Usando cmdline-tools.zip ja baixado.' -ForegroundColor Green
  }
  $tmp = Join-Path $env:TEMP 'cmdline-tools-x'
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive $zip -DestinationPath $tmp -Force
  New-Item -ItemType Directory -Force -Path (Join-Path $sdk 'cmdline-tools') | Out-Null
  Move-Item (Join-Path $tmp 'cmdline-tools') (Join-Path $sdk 'cmdline-tools\latest') -Force
}
if (-not (Test-Path $sdkm)) { Falha 'sdkmanager nao encontrado apos a extracao.' }
$env:ANDROID_HOME = $sdk; $env:ANDROID_SDK_ROOT = $sdk
[Environment]::SetEnvironmentVariable('ANDROID_HOME', $sdk, 'User')
if (-not (Test-Path (Join-Path $sdk 'platforms\android-34')) -or -not (Test-Path (Join-Path $sdk 'build-tools\34.0.0'))) {
  Etapa 'Aceitando licencas e instalando plataforma Android 34 (pode demorar)'
  $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
  1..60 | ForEach-Object { 'y' } | & $sdkm "--sdk_root=$sdk" --licenses | Out-Null
  & $sdkm "--sdk_root=$sdk" 'platform-tools' 'platforms;android-34' 'build-tools;34.0.0'
  $ErrorActionPreference = $old
}
if (-not (Test-Path (Join-Path $sdk 'platforms\android-34'))) { Falha 'Plataforma Android 34 nao foi instalada. Verifique a internet e rode de novo.' }
Write-Host "Android SDK: $sdk" -ForegroundColor Green

# 4) Build
Etapa 'Gerando o APK (a 1a vez baixa Capacitor e Gradle: aguarde varios minutos)'
& node build-apk.js
if ($LASTEXITCODE -ne 0) { Falha 'O build falhou. Copie a mensagem acima que comeca com X/ERRO e me envie.' }

$apk = Join-Path $PSScriptRoot 'ULTIMO_SINAL_V28.apk'
if (Test-Path $apk) {
  Write-Host "`nPRONTO! APK gerado em: $apk" -ForegroundColor Green
  Start-Process explorer.exe "/select,`"$apk`""
} else { Falha 'O build terminou mas o APK nao foi encontrado.' }
Read-Host 'Pressione ENTER para fechar'
