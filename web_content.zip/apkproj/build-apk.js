#!/usr/bin/env node
/* Gera o APK (debug) do Último Sinal V28 usando Capacitor + Gradle.
   Uso:  node build-apk.js          -> build completo
         node build-apk.js --dry    -> só verifica requisitos e prepara www/ */
const fs = require('fs'), path = require('path'), { spawnSync } = require('child_process');
const DRY = process.argv.includes('--dry');
const ROOT = __dirname, WIN = process.platform === 'win32';
const HTML = 'ULTIMO_SINAL_V28_PROTOCOLO_OMEGA.html';
const log = (m) => console.log('\n▶ ' + m);
const fail = (m) => { console.error('\n✖ ' + m); process.exit(1); };
function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { cwd: opts.cwd || ROOT, stdio: 'inherit', shell: true, env: process.env });
  if (r.status !== 0) fail(`Falhou: ${cmd} ${args.join(' ')}`);
}
function out(cmd, args) {
  const r = spawnSync(cmd, args, { encoding: 'utf8', shell: true });
  return ((r.stdout || '') + (r.stderr || '')).trim();
}

/* 1. Requisitos */
log('Verificando requisitos');
const nodeMajor = +process.versions.node.split('.')[0];
if (nodeMajor < 18) fail('Node 18 ou superior é necessário (você tem ' + process.versions.node + ').');
console.log('Node', process.versions.node, 'OK');
const javaOut = out('java', ['-version']);
const jm = javaOut.match(/version "(\d+)(?:\.(\d+))?/);
if (!jm) fail('Java (JDK 17) não encontrado. Instale o JDK 17 e reabra o terminal.');
const javaMajor = jm[1] === '1' ? +jm[2] : +jm[1];
if (javaMajor < 17) fail('JDK 17 ou superior é necessário (encontrado ' + javaMajor + ').');
console.log('Java', javaMajor, 'OK');
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
if (!sdk || !fs.existsSync(sdk)) {
  if (!DRY) fail('Defina ANDROID_HOME (ou ANDROID_SDK_ROOT) apontando para o Android SDK.\n  Windows (padrão): %LOCALAPPDATA%\\Android\\Sdk\n  Instale o SDK pelo Android Studio (SDK Platform 34 + Build-Tools).');
  console.log('⚠ ANDROID_HOME não definido (necessário no build completo).');
} else console.log('Android SDK:', sdk);

/* 2. Prepara www/ */
log('Preparando www/index.html');
const src = path.join(ROOT, HTML);
if (!fs.existsSync(src)) fail(HTML + ' precisa estar na mesma pasta deste script.');
fs.mkdirSync(path.join(ROOT, 'www'), { recursive: true });
fs.copyFileSync(src, path.join(ROOT, 'www', 'index.html'));
console.log('Copiado:', (fs.statSync(src).size / 1024).toFixed(0), 'KB');
if (DRY) { console.log('\n✔ Verificação concluída. Rode "npm run apk" para gerar o APK.'); process.exit(0); }

/* 3. Capacitor */
if (!fs.existsSync(path.join(ROOT, 'node_modules', '@capacitor', 'cli'))) { log('Instalando dependências (npm install)'); run('npm', ['install']); }
if (!fs.existsSync(path.join(ROOT, 'android'))) { log('Criando projeto Android'); run('npx', ['cap', 'add', 'android']); }
log('Sincronizando arquivos web com o Android'); run('npx', ['cap', 'sync', 'android']);
fs.writeFileSync(path.join(ROOT, 'android', 'local.properties'), 'sdk.dir=' + sdk.replace(/\\/g, '\\\\') + '\n');

/* 4. Gradle */
log('Compilando APK (a 1ª vez baixa o Gradle e pode demorar vários minutos)');
const gradle = WIN ? 'gradlew.bat' : './gradlew';
if (!WIN) try { fs.chmodSync(path.join(ROOT, 'android', 'gradlew'), 0o755); } catch (e) {}
run(gradle, ['assembleDebug'], { cwd: path.join(ROOT, 'android') });

/* 5. Resultado */
const apk = path.join(ROOT, 'android', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
if (!fs.existsSync(apk)) fail('O Gradle terminou, mas o APK não foi encontrado em ' + apk);
const dest = path.join(ROOT, 'ULTIMO_SINAL_V28.apk');
fs.copyFileSync(apk, dest);
console.log('\n✔ APK gerado:', dest, '(' + (fs.statSync(dest).size / 1048576).toFixed(1) + ' MB)');
console.log('Copie para o celular e instale (permita "fontes desconhecidas").');
