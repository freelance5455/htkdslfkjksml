WINAMP XP – ANDROID NATÍV PROJEKT (JAVÍTOTT FÁJLVÁLASZTÓVAL)

A javítás az Android saját dokumentum-/fájlkezelőjét nyitja meg az ADD gombbal.
Több hangfájl egyszerre is kiválasztható. Az alkalmazás offline működik.

A lejátszó kezelőszervei:
PLAY / PAUSE / STOP – lejátszás vezérlése
PREV / NEXT – előző és következő szám
SHUFFLE / REPEAT – véletlen sorrend és ismétlés
VOL – hangerő, csúszka – pozíció
EQ ON / RESET / PRESET és a 10 EQ csúszka – hangszínszabályzó
ADD – zenék kiválasztása a telefon fájlkezelőjéből
REM – kijelölt (vagy aktuális) szám törlése
CLR – teljes lista ürítése
▲ / ▼ – kijelölt szám mozgatása a listában

APK készítése:
A projekt Android Studio-val vagy a mellékelt GitHub Actions munkafolyamattal építhető.
A GitHub Actions a sikeres build után letölthető APK-artifactot készít.
A korábban készített APK-t frissíteni kell erre a javított buildre; a már telepített
régi APK önmagától nem javul meg.
