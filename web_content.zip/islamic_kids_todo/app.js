const defaults = [
  ["Помолиться вместе с семьёй (если пришло время)","Намаз"],
  ["Прочитать или послушать немного Корана","Коран"],
  ["Выучить или повторить одну дуа","Знания"],
  ["Помочь родителям или близким","Добро"],
  ["Сказать кому-нибудь доброе слово","Добро"],
  ["Навести порядок в своей комнате","Порядок"],
  ["Поблагодарить Аллаха за три вещи","Благодарность"],
  ["Почитать полезную книгу или повторить уроки","Учёба"]
];
const todayKey = new Date().toLocaleDateString('sv-SE');
let data = JSON.parse(localStorage.getItem('islamicTodo') || '{}');
if(data.date !== todayKey){ data = {date:todayKey, tasks:defaults.map((x,i)=>({id:i,text:x[0],cat:x[1],done:false,custom:false}))}; save(); }
function save(){localStorage.setItem('islamicTodo',JSON.stringify(data));}
const tasksEl=document.getElementById('tasks');
function render(){
 tasksEl.innerHTML='';
 data.tasks.forEach(t=>{
  const el=document.createElement('div');el.className='task'+(t.done?' done':'');
  const b=document.createElement('button');b.className='check';b.type='button';b.textContent=t.done?'✓':'';
  b.setAttribute('aria-label',t.done?'Отметить невыполненным':'Отметить выполненным');
  b.onclick=()=>{t.done=!t.done;save();render()};
  const txt=document.createElement('div');txt.className='task-text';txt.textContent=t.text;
  const cat=document.createElement('span');cat.className='category';cat.textContent=t.cat||'Моё дело';
  el.append(b,txt,cat);tasksEl.append(el);
 });
 const total=data.tasks.length, done=data.tasks.filter(t=>t.done).length;
 const pct=total?Math.round(done/total*100):0;
 document.getElementById('points').textContent=done*10;
 document.getElementById('done').textContent=`${done}/${total}`;
 document.getElementById('percent').textContent=pct+'%';
 document.getElementById('progress').style.width=pct+'%';
 document.getElementById('streak').textContent=done>0?'1':'0';
}
document.getElementById('today').textContent=new Date().toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long'});
document.getElementById('addForm').addEventListener('submit',e=>{
 e.preventDefault();const input=document.getElementById('newTask');const value=input.value.trim();
 if(!value)return;data.tasks.push({id:Date.now(),text:value,cat:'Моё дело',done:false,custom:true});input.value='';save();render();
});
document.getElementById('reset').onclick=()=>{
 if(confirm('Снять все отметки за сегодня?')){data.tasks.forEach(t=>t.done=false);save();render();}
};
render();
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
