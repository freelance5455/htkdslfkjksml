# 1.0.0
- Première base GM Pay
- Authentification Firebase
- Portefeuille CDF
- Historique
- Règles Firestore empêchant les modifications de solde depuis le client
- Fonction serveur pour transfert interne
- Structure Capacitor Android
