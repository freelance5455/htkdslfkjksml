import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, collection, addDoc, query, orderBy, limit, onSnapshot, serverTimestamp, runTransaction } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

const cfg = window.GM_PAY_FIREBASE_CONFIG;
const authView = document.querySelector('#authView'), mainView=document.querySelector('#mainView');
const authForm=document.querySelector('#authForm'), authSubmit=document.querySelector('#authSubmit'), authMsg=document.querySelector('#authMsg');
const loginTab=document.querySelector('#loginTab'), registerTab=document.querySelector('#registerTab');
let register=false, currentUser=null, operation=null, unsubscribe=null;

function requireConfig(){
  if(!cfg || cfg.apiKey==="REMPLACE_MOI") throw new Error("Firebase n'est pas configuré. Renseigne www/firebase-config.js.");
}
requireConfig();
const app=initializeApp(cfg), auth=getAuth(app), db=getFirestore(app);

loginTab.onclick=()=>{register=false;loginTab.classList.add('active');registerTab.classList.remove('active');authSubmit.textContent='Se connecter'};
registerTab.onclick=()=>{register=true;registerTab.classList.add('active');loginTab.classList.remove('active');authSubmit.textContent='Créer mon compte'};

authForm.onsubmit=async e=>{
  e.preventDefault(); authMsg.textContent='';
  const email=document.querySelector('#email').value.trim(), password=document.querySelector('#password').value;
  try{
    if(register){
      const cred=await createUserWithEmailAndPassword(auth,email,password);
      await setDoc(doc(db,'users',cred.user.uid),{email, balance:0, currency:'CDF', createdAt:serverTimestamp()});
    }else await signInWithEmailAndPassword(auth,email,password);
  }catch(err){authMsg.textContent=humanError(err)}
};

onAuthStateChanged(auth, async user=>{
  currentUser=user;
  if(unsubscribe) unsubscribe();
  if(!user){authView.classList.remove('hidden');mainView.classList.add('hidden');return}
  authView.classList.add('hidden');mainView.classList.remove('hidden');
  document.querySelector('#userEmail').textContent=user.email||'Utilisateur';
  document.querySelector('#profileEmail').textContent=user.email||'—';
  document.querySelector('#profileUid').textContent=user.uid;
  const ref=doc(db,'users',user.uid);
  const snap=await getDoc(ref);
  if(!snap.exists()) await setDoc(ref,{email:user.email,balance:0,currency:'CDF',createdAt:serverTimestamp()},{merge:true});
  unsubscribe=onSnapshot(query(collection(db,'users',user.uid,'transactions'),orderBy('createdAt','desc'),limit(30)), snap=>{
    const el=document.querySelector('#transactions'); el.innerHTML='';
    if(snap.empty){el.innerHTML='<div class="empty">Aucune transaction.</div>';return}
    snap.forEach(d=>{const t=d.data(); const row=document.createElement('div');row.className='tx';
      row.innerHTML=`<div><b>${esc(t.label||'Transaction')}</b><small>${t.createdAt?.toDate?t.createdAt.toDate().toLocaleString('fr-FR'):'En cours'}</small></div><strong class="${t.type==='credit'?'credit':'debit'}">${t.type==='credit'?'+':'-'} ${Number(t.amount||0).toLocaleString('fr-FR')} FC</strong>`;el.appendChild(row)});
  });
  onSnapshot(ref,s=>{document.querySelector('#balance').textContent=(Number(s.data()?.balance||0)).toLocaleString('fr-FR')+' FC'});
});

document.querySelector('#logoutBtn').onclick=()=>signOut(auth);
document.querySelector('#refreshBtn').onclick=()=>location.reload();
document.querySelector('#profileBtn').onclick=()=>document.querySelector('#profileModal').classList.remove('hidden');
document.querySelector('#closeProfile').onclick=()=>document.querySelector('#profileModal').classList.add('hidden');
document.querySelector('#closeModal').onclick=()=>document.querySelector('#modal').classList.add('hidden');

document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{
  operation=b.dataset.action;
  document.querySelector('#modalTitle').textContent={deposit:'Dépôt',withdraw:'Retrait',send:'Envoyer de l’argent'}[operation];
  document.querySelector('#recipientWrap').classList.toggle('hidden',operation!=='send');
  document.querySelector('#operationMsg').textContent='';
  document.querySelector('#amount').value='';
  document.querySelector('#modal').classList.remove('hidden');
});

document.querySelector('#operationForm').onsubmit=async e=>{
  e.preventDefault();
  const amount=Number(document.querySelector('#amount').value), recipient=document.querySelector('#recipient').value.trim();
  const msg=document.querySelector('#operationMsg'); msg.textContent='';
  if(!amount || amount<=0){msg.textContent='Montant invalide.';return}
  if(operation==='send' && !recipient){msg.textContent='Destinataire obligatoire.';return}
  if(operation==='deposit'){
    msg.textContent='Le dépôt réel doit être confirmé par le serveur du fournisseur de paiement. Aucun faux crédit n’est effectué.';
    return;
  }
  if(operation==='withdraw'){
    msg.textContent='Le retrait réel doit être traité par le serveur du fournisseur de paiement. Aucun faux débit n’est effectué.';
    return;
  }
  if(operation==='send'){
    try{
      // Le transfert interne réel doit être sécurisé côté serveur/Cloud Function.
      msg.textContent='Le transfert doit passer par une fonction serveur sécurisée. Cette version refuse volontairement de modifier directement le solde depuis le téléphone.';
    }catch(err){msg.textContent=humanError(err)}
  }
};

function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function humanError(e){return ({'auth/invalid-credential':'Email ou mot de passe incorrect.','auth/email-already-in-use':'Cet email est déjà utilisé.','auth/weak-password':'Mot de passe trop faible.','auth/invalid-email':'Email invalide.'}[e.code]||e.message||'Une erreur est survenue.')}
