// CONFIGURATION LOCALE : renseigne les valeurs de TON projet Firebase.
// Ne mets aucune clé secrète de fournisseur de paiement dans ce fichier.
window.GM_PAY_FIREBASE_CONFIG = {
  apiKey: "REMPLACE_MOI",
  authDomain: "TON_PROJET.firebaseapp.com",
  projectId: "TON_PROJET",
  storageBucket: "TON_PROJET.firebasestorage.app",
  messagingSenderId: "REMPLACE_MOI",
  appId: "REMPLACE_MOI"
};