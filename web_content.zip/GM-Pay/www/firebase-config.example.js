// RENOMME ce fichier en firebase-config.js puis renseigne TON projet Firebase.
// Ces valeurs sont publiques côté application. Ne mets JAMAIS de clé secrète ici.
window.GM_PAY_FIREBASE_CONFIG = {
  apiKey: "REMPLACE_MOI",
  authDomain: "TON_PROJET.firebaseapp.com",
  projectId: "TON_PROJET",
  storageBucket: "TON_PROJET.firebasestorage.app",
  messagingSenderId: "REMPLACE_MOI",
  appId: "REMPLACE_MOI"
};