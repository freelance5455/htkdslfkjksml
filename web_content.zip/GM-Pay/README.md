# GM Pay — projet complet

Ce projet est une base réelle et fonctionnelle de portefeuille GM Pay, conçue pour être transformée en application Android.

## Inclus
- Interface mobile GM Pay
- Création de compte / connexion
- Portefeuille et solde
- Dépôt, retrait et transfert (interface + validation)
- Historique des transactions
- Profil
- Firebase Authentication / Firestore
- Règles Firestore de sécurité
- Structure backend pour les opérations sensibles
- Configuration Capacitor pour emballage Android

## Important
Une application de paiement réelle ne doit jamais contenir de clé secrète de fournisseur de paiement dans le navigateur ou dans l'APK.
Le fichier `firebase-config.example.js` contient uniquement des valeurs à remplacer par la configuration publique de TON projet Firebase.
Les secrets d'API Mobile Money / passerelle de paiement doivent être placés côté serveur dans `functions/.env`.

## Installation web
1. Copie `www/firebase-config.example.js` vers `www/firebase-config.js`.
2. Remplace les valeurs Firebase par celles de ton projet.
3. Ouvre `www/index.html` via un serveur local (pas directement file://).
4. Configure Authentication > Email/Password et Firestore dans Firebase.

## Android
Le dossier est préparé pour Capacitor. Sur un ordinateur avec Node.js :
npm install
npx cap add android
npx cap sync
npx cap open android

Puis compile l'APK depuis Android Studio.

## Paiements réels
Pour déplacer réellement de l'argent, il faut connecter un fournisseur autorisé (Mobile Money / passerelle) et renseigner ses identifiants serveur. Le projet ne simule pas de fausses confirmations de paiement.
