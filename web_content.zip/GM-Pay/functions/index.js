const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {setGlobalOptions} = require("firebase-functions/v2");
const admin = require("firebase-admin");
admin.initializeApp();
setGlobalOptions({region:"europe-west1", maxInstances:10});
const db=admin.firestore();

exports.createInternalTransfer = onCall(async request=>{
  if(!request.auth) throw new HttpsError("unauthenticated","Connexion requise.");
  const fromUid=request.auth.uid, toEmail=String(request.data?.toEmail||"").trim().toLowerCase();
  const amount=Number(request.data?.amount);
  if(!toEmail || !Number.isInteger(amount) || amount<=0) throw new HttpsError("invalid-argument","Destinataire ou montant invalide.");

  const users=await db.collection("users").where("email","==",toEmail).limit(1).get();
  if(users.empty) throw new HttpsError("not-found","Destinataire introuvable.");
  const toUid=users.docs[0].id;
  if(toUid===fromUid) throw new HttpsError("failed-precondition","Impossible de vous envoyer de l'argent à vous-même.");

  const fromRef=db.doc(`users/${fromUid}`), toRef=db.doc(`users/${toUid}`);
  const txId=db.collection("_tx").doc().id;

  await db.runTransaction(async tx=>{
    const [fromSnap,toSnap]=await Promise.all([tx.get(fromRef),tx.get(toRef)]);
    const fromBal=Number(fromSnap.data()?.balance||0);
    if(fromBal<amount) throw new HttpsError("failed-precondition","Solde insuffisant.");
    tx.update(fromRef,{balance:fromBal-amount});
    tx.update(toRef,{balance:Number(toSnap.data()?.balance||0)+amount});
    const now=admin.firestore.FieldValue.serverTimestamp();
    tx.set(db.doc(`users/${fromUid}/transactions/${txId}`),{type:"debit",amount,label:`Transfert vers ${toEmail}`,createdAt:now});
    tx.set(db.doc(`users/${toUid}/transactions/${txId}`),{type:"credit",amount,label:`Transfert reçu de ${request.auth.token.email||fromUid}`,createdAt:now});
  });
  return {ok:true, transactionId:txId};
});

// Les endpoints de dépôt/retrait doivent être ajoutés ici avec le fournisseur de paiement choisi.
// Les secrets doivent rester dans Secret Manager / variables d'environnement.
