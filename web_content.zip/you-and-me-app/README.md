# You & Me — Just You & Me ❤️

## ১) Supabase সেটআপ
1. `supabase/setup.sql` আপনার Supabase SQL Editor-এ চালান।
2. Authentication → Users এ স্বামী ও স্ত্রীর দুটি ইউজার বানান, Sign-ups বন্ধ রাখুন।
3. ফাইলের শেষের কমেন্টের `insert into members ...` লাইনটি তাদের UUID দিয়ে চালান।
4. `www/config.js` এ `SUPABASE_URL` ও `SUPABASE_ANON_KEY` বসান।

## ২) দ্রুত চালু (APK ছাড়া)
`www` ফোল্ডারটি Netlify / Vercel / Cloudflare Pages এ আপলোড করুন। ফোনের Chrome এ খুলে "Add to Home Screen" দিলেই অ্যাপ হয়ে যাবে।

## ৩) Android APK বানানো (Capacitor)
Node.js ও Android Studio লাগবে।
```
npm install
npx cap add android
npx cap sync
npx cap open android
```
`android/app/src/main/AndroidManifest.xml` এ `<application>` এর আগে যোগ করুন:
```
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
```
এরপর Android Studio তে Build → Build APK(s)।

## ডিজাইন বদলাতে
`www/style.css` (রঙ, ফন্ট), `www/index.html` (লেআউট), `www/app.js` (লজিক)।
