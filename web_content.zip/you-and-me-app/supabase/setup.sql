-- You & Me: Supabase SQL Editor-এ একবার চালান
create table if not exists members(user_id uuid primary key references auth.users on delete cascade, role text check(role in('husband','wife')) unique);
create table if not exists messages(
  id bigint generated always as identity primary key,
  sender_id uuid not null default auth.uid() references auth.users,
  type text not null check(type in('text','image','video','voice')),
  body text, media_path text, duration int,
  created_at timestamptz not null default now());
alter table members enable row level security;
alter table messages enable row level security;
create policy "members read" on members for select using (exists(select 1 from members m where m.user_id=auth.uid()));
create policy "couple read" on messages for select using (exists(select 1 from members m where m.user_id=auth.uid()));
create policy "couple send" on messages for insert with check (sender_id=auth.uid() and exists(select 1 from members m where m.user_id=auth.uid()));
alter publication supabase_realtime add table messages;
insert into storage.buckets(id,name,public) values('media','media',false) on conflict do nothing;
create policy "couple files read" on storage.objects for select using (bucket_id='media' and exists(select 1 from members m where m.user_id=auth.uid()));
create policy "couple files upload" on storage.objects for insert with check (bucket_id='media' and exists(select 1 from members m where m.user_id=auth.uid()));
-- তারপর Authentication > Users এ স্বামী ও স্ত্রীর অ্যাকাউন্ট বানিয়ে (Sign-ups বন্ধ রাখুন) চালান:
-- insert into members values('<husband-uuid>','husband'),('<wife-uuid>','wife');
