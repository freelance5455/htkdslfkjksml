// ===== আপনার Supabase তথ্য এখানে বসান =====
window.SUPABASE_URL='';
window.SUPABASE_ANON_KEY='';
// ==========================================
