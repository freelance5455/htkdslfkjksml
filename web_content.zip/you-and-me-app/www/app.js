const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
const sb=window.SUPABASE_URL?supabase.createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY):null;
let me=null,role='',msgs=[],seen=new Set(),tab='image',rec=null,chunks=[],t0=0,want='';
const toast=t=>{const e=$('#to');e.textContent=t;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>e.style.display='none',3500)};
function go(id){$$('.s').forEach(s=>s.classList.toggle('on',s.id===id));$('#nv').classList.toggle('on',['ls','md','pr'].includes(id));
$$('nav button').forEach(b=>b.classList.toggle('a',b.dataset.g===id));if(id==='md')gallery();if(id==='ch')scr()}
document.addEventListener('click',e=>{const g=e.target.closest('[data-g]');if(g)go(g.dataset.g);const r=e.target.closest('[data-r]');
if(r){want=r.dataset.r;$('#rl').textContent=want==='husband'?'স্বামী':'স্ত্রী';go('lg')}});
const scr=()=>{const m=$('#ms');m.scrollTop=m.scrollHeight};
const tm=d=>new Date(d).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
const urls={};
async function url(p){if(!urls[p]){const{data}=await sb.storage.from('media').createSignedUrl(p,3600);urls[p]=data&&data.signedUrl}return urls[p]}
async function media(m){const t=m.type==='image'?'img':m.type==='video'?'video':'audio';const e=document.createElement(t);
if(t!=='img')e.controls=true;e.preload='metadata';e.src=await url(m.media_path)||'';return e}
async function bubble(m){const d=document.createElement('div');d.className='b '+(m.sender_id===me.id?'me':'yu');
if(m.type==='text'){const s=document.createElement('span');s.textContent=m.body;d.append(s)}else d.append(await media(m));
const i=document.createElement('i');i.textContent=tm(m.created_at);d.append(i);return d}
async function add(m){if(seen.has(m.id))return;seen.add(m.id);msgs.push(m);$('#ms').append(await bubble(m));scr();
$('#lp').textContent=m.type==='text'?m.body:{image:'📷 ছবি',video:'🎬 ভিডিও',voice:'🎙️ ভয়েস মেসেজ'}[m.type]}
async function boot(){const{data:mem}=await sb.from('members').select('role').eq('user_id',me.id).maybeSingle();
if(!mem){await sb.auth.signOut();return toast('এই অ্যাপ শুধু স্বামী ও স্ত্রীর জন্য')}
role=mem.role;$('#pe').textContent=me.email;$('#pro').textContent=role==='husband'?'স্বামী':'স্ত্রী';
const{data}=await sb.from('messages').select('*').order('created_at');$('#ms').innerHTML='';seen.clear();msgs=[];
for(const m of data||[])await add(m);
sb.channel('m').on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'},p=>add(p.new)).subscribe();go('ls')}
$('#li').onclick=async()=>{if(!sb)return toast('Supabase URL ও Key বসান (ফাইলের শুরুতে)');
const{data,error}=await sb.auth.signInWithPassword({email:$('#em').value.trim(),password:$('#pw').value});
if(error)return toast('ইমেইল বা পাসওয়ার্ড ভুল');me=data.user;boot()};
$('#lo').onclick=async()=>{await sb.auth.signOut();sb.removeAllChannels();me=null;go('w')};
async function send(row){const{error}=await sb.from('messages').insert(row);if(error)toast('পাঠানো যায়নি: '+error.message)}
async function upload(file,type,dur){const ext=(file.name||'v.webm').split('.').pop(),p=`${me.id}/${Date.now()}.${ext}`;
toast('আপলোড হচ্ছে…');const{error}=await sb.storage.from('media').upload(p,file,{contentType:file.type});
if(error)return toast('আপলোড ব্যর্থ: '+error.message);await send({type,media_path:p,duration:dur})}
const text=()=>{const v=$('#ti').value.trim();if(!v)return;$('#ti').value='';send({type:'text',body:v})};
$('#sd').onclick=text;$('#ti').onkeydown=e=>{if(e.key==='Enter')text()};
$('#at').onclick=()=>$('#fi').click();
$('#fi').onchange=e=>{const f=e.target.files[0];if(f)upload(f,f.type.startsWith('video')?'video':'image');e.target.value=''};
$('#mc').onclick=async()=>{const b=$('#mc');
if(rec){rec.stop();return}
try{const st=await navigator.mediaDevices.getUserMedia({audio:true});rec=new MediaRecorder(st);chunks=[];t0=Date.now();
rec.ondataavailable=e=>chunks.push(e.data);
rec.onstop=()=>{st.getTracks().forEach(t=>t.stop());const type=rec.mimeType||'audio/webm',ext=type.includes('mp4')?'m4a':'webm';
const f=new File(chunks,'voice.'+ext,{type});upload(f,'voice',Math.round((Date.now()-t0)/1000));rec=null;b.classList.remove('rec')};
rec.start();b.classList.add('rec')}catch(_){toast('মাইক্রোফোনের অনুমতি দিন')}};
$('#tb').onclick=e=>{const b=e.target.closest('[data-t]');if(b){tab=b.dataset.t;$$('#tb button').forEach(x=>x.classList.toggle('a',x===b));gallery()}};
async function gallery(){const g=$('#gr');g.innerHTML='';for(const m of msgs.filter(m=>m.type===tab))g.append(await media(m));
if(!g.children.length)g.innerHTML='<p style="grid-column:1/-1;text-align:center;color:var(--mu);padding:40px">এখনো কিছু নেই ❤️</p>'}
(async()=>{if(!sb)return;const{data}=await sb.auth.getSession();if(data.session){me=data.session.user;boot()}})();

if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
