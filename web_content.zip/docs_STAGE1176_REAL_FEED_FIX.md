# CryptoPulse Stage 1176 — Real Feed / Blank Chart Fix

## What changed
- Removed the Stage 1174/1175 SVG overlay from the visible chart path. Canvas is now the single visible chart renderer, eliminating duplicate grid/price/live text seen on the Trade screenshot.
- Futures browser fallback now runs even when the Android native bridge exists. Previously `nativeReady=true` prevented the official public futures endpoint from ever being attempted if the native feed failed.
- Futures reference-history loading no longer requires a futures price first. It can load real LBank spot history and then sync to the futures price when available.
- Added a browser-side bulk LBank `/v2/ticker/24hr.do?symbol=all` fallback for Home. This updates visible Home rows directly from the official LBank market feed when the native per-symbol path misses rows.
- Existing native LBank paths remain primary; no fake prices/candles are generated.

## Validation
- app.js JavaScript syntax check: PASS
- spot.html script syntax: PASS
- futures.html script syntax: PASS
