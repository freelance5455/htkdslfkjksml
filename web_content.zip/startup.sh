#!/bin/sh
# Restart contract: serve RubAI 4.0 on 0.0.0.0:8080 if it is not already healthy.
set -eu
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/api/health; then
  exit 0
fi
node /workspace/RubAI_4.0/server.js > /tmp/rubai-server.log 2>&1 &
i=0
while [ "$i" -lt 40 ]; do
  if curl -sf -o /dev/null --max-time 1 http://127.0.0.1:8080/api/health; then
    exit 0
  fi
  i=$((i + 1))
  sleep 0.25
done
echo "RubAI 4.0 failed to start" >&2
tail -n 50 /tmp/rubai-server.log >&2 || true
exit 1
