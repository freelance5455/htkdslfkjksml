package com.recoveryimage.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_CHOOSER = 1;
    private WebView web;
    private ValueCallback<Uri[]> chooserCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Saver(), "AndroidSave");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = cb;
                try {
                    Intent i = params.createIntent();
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_CHOOSER);
                } catch (Exception e) {
                    chooserCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_CHOOSER && chooserCallback != null) {
            chooserCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooserCallback = null;
        } else super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    /** Saves files into the public Downloads folder. */
    private class Saver {
        private final Map<Integer, OutputStream> streams = new HashMap<>();
        private int next = 1;

        @JavascriptInterface
        public synchronized int begin(String name, String mime) {
            try {
                if (mime == null || mime.isEmpty()) {
                    String ext = MimeTypeMap.getFileExtensionFromUrl(name.replace(" ", "_"));
                    mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext == null ? "" : ext.toLowerCase());
                    if (mime == null) mime = "application/octet-stream";
                }
                ContentResolver cr = getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/RecoveryImage");
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return -1;
                OutputStream os = cr.openOutputStream(uri);
                if (os == null) return -1;
                int id = next++;
                streams.put(id, os);
                return id;
            } catch (Exception e) {
                return -1;
            }
        }

        @JavascriptInterface
        public synchronized void write(int id, String b64) {
            try {
                OutputStream os = streams.get(id);
                if (os != null) os.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public synchronized void end(int id) {
            try {
                OutputStream os = streams.remove(id);
                if (os != null) { os.flush(); os.close(); }
            } catch (Exception ignored) { }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Downloads/RecoveryImage", Toast.LENGTH_SHORT).show());
        }
    }
}
