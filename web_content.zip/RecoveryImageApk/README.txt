Recovery Image 11 - Android project

Option A: GitHub (no Android Studio needed)
  1. Create a new GitHub repository and upload everything in this folder (keep the .github folder).
  2. Open the Actions tab, run "Build APK", then download "RecoveryImage-apk" -> app-debug.apk.
  3. Copy app-debug.apk to your phone and install it (allow "install unknown apps").

Option B: Android Studio
  File > Open this folder, wait for Gradle sync, then Build > Build APK(s).

Using the app
  - Tap "Select files", pick the photos/videos on the SD card (use the file picker's SD card location, select all).
  - Downloaded files are saved in Downloads/RecoveryImage.
  - The folder picker and "Save to folder" buttons do not work inside an Android WebView; use "Select files" and the download buttons.
