(function () {
  const root = document.getElementById('nexuraAuth');
  const content = document.getElementById('authContent');
  const appBar = document.getElementById('nexuraCloudBar');
  let client = null;
  let currentUser = null;
  let saveTimer = null;
  let pendingPayload = null;
  let resolveReady;
  window.NEXURA_AUTH_READY = new Promise(resolve => { resolveReady = resolve; });

  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const localConfig = (() => { try { return JSON.parse(localStorage.getItem('nexura_supabase_config') || '{}'); } catch (_) { return {}; } })();
  const config = window.NEXURA_CONFIG || {};
  const url = (config.SUPABASE_URL || localConfig.url || '').trim();
  const key = (config.SUPABASE_ANON_KEY || localConfig.key || '').trim();

  function showSetup(message = '') {
    root.style.display = 'grid';
    content.innerHTML = `
      <div class="auth-note">Cloud connection needs your Supabase project details. Create a free project, run the included <b>supabase/schema.sql</b>, then enter its Project URL and publishable/anon key here. These are public client credentials protected by the database's owner-only security rules.</div>
      <div class="auth-field"><label for="sbUrl">Supabase Project URL</label><input id="sbUrl" type="url" placeholder="https://your-project.supabase.co" autocomplete="url"></div>
      <div class="auth-field"><label for="sbKey">Publishable / anon key</label><input id="sbKey" type="password" placeholder="sb_publishable_… or legacy anon key" autocomplete="off"></div>
      <button class="auth-btn" id="saveSbConfig">Save connection details</button>
      <div class="auth-msg ${message ? 'error' : ''}">${escapeHtml(message || 'You only need to configure this once in the deployed app.')}</div>`;
    document.getElementById('saveSbConfig').onclick = () => {
      const u = document.getElementById('sbUrl').value.trim();
      const k = document.getElementById('sbKey').value.trim();
      if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(u) || k.length < 20) {
        showSetup('Please enter a valid Supabase URL and publishable/anon key.'); return;
      }
      localStorage.setItem('nexura_supabase_config', JSON.stringify({url:u,key:k}));
      location.reload();
    };
  }

  function showAuth(mode = 'login', message = '', isError = false) {
    root.style.display = 'grid';
    const signup = mode === 'signup';
    content.innerHTML = `
      <div class="auth-field"><label for="authEmail">Owner email</label><input id="authEmail" type="email" placeholder="you@example.com" autocomplete="email" required></div>
      <div class="auth-field"><label for="authPassword">Password</label><input id="authPassword" type="password" placeholder="At least 8 characters" autocomplete="${signup ? 'new-password' : 'current-password'}" required></div>
      ${signup ? '<div class="auth-field"><label for="authConfirm">Confirm password</label><input id="authConfirm" type="password" placeholder="Repeat password" autocomplete="new-password" required></div>' : ''}
      <button class="auth-btn" id="authSubmit">${signup ? 'CREATE OWNER ACCOUNT' : 'LOGIN TO MY DASHBOARD'}</button>
      <div style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-top:8px">${signup ? '<button class="auth-link" id="switchLogin">Already have an account? Login</button>' : '<button class="auth-link" id="switchSignup">First time? Create owner account</button><button class="auth-link" id="forgotPassword">Forgot password?</button>'}</div>
      <div class="auth-msg ${isError ? 'error' : message ? 'success' : ''}" id="authMessage">${escapeHtml(message)}</div>
      <div class="auth-note">This is your private owner account. No employee accounts are required. After creating your account, disable new user signups in Supabase Authentication settings.</div>`;
    if (signup) document.getElementById('switchLogin').onclick = () => showAuth('login');
    else {
      document.getElementById('switchSignup').onclick = () => showAuth('signup');
      document.getElementById('forgotPassword').onclick = resetPassword;
    }
    document.getElementById('authSubmit').onclick = () => submitAuth(signup);
    ['authEmail','authPassword'].forEach(id => document.getElementById(id).addEventListener('keydown', e => { if (e.key === 'Enter') submitAuth(signup); }));
  }

  async function submitAuth(signup) {
    const email = document.getElementById('authEmail').value.trim();
    const password = document.getElementById('authPassword').value;
    const message = document.getElementById('authMessage');
    const button = document.getElementById('authSubmit');
    if (!email || password.length < 8) { message.textContent = 'Enter a valid email and a password with at least 8 characters.'; message.className = 'auth-msg error'; return; }
    if (signup && password !== document.getElementById('authConfirm').value) { message.textContent = 'Passwords do not match.'; message.className = 'auth-msg error'; return; }
    button.disabled = true; button.textContent = 'PLEASE WAIT…';
    try {
      if (signup) {
        const { data, error } = await client.auth.signUp({ email, password });
        if (error) throw error;
        if (data.session) await enterWorkspace(data.session.user);
        else showAuth('login', 'Account created. Check your email for the confirmation link, then log in.', false);
      } else {
        const { data, error } = await client.auth.signInWithPassword({ email, password });
        if (error) throw error;
        await enterWorkspace(data.user);
      }
    } catch (err) {
      message.textContent = err.message || 'Could not complete authentication.';
      message.className = 'auth-msg error';
      button.disabled = false; button.textContent = signup ? 'CREATE OWNER ACCOUNT' : 'LOGIN TO MY DASHBOARD';
    }
  }

  async function resetPassword() {
    const email = document.getElementById('authEmail').value.trim();
    const message = document.getElementById('authMessage');
    if (!email) { message.textContent = 'Enter your email address first, then choose Forgot password.'; message.className = 'auth-msg error'; return; }
    const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
    message.textContent = error ? error.message : 'Password reset email sent. Check your inbox.';
    message.className = error ? 'auth-msg error' : 'auth-msg success';
  }

  async function enterWorkspace(user) {
    currentUser = user;
    let { data, error } = await client.from('nexura_workspace').select('records, company_logo').eq('user_id', user.id).maybeSingle();
    if (error) throw new Error('Cloud database is not ready. Run supabase/schema.sql in Supabase SQL Editor. Details: ' + error.message);
    if (!data) {
      // Import records already saved in this browser on first cloud login.
      let localRecords = [], localLogo = '';
      try { localRecords = JSON.parse(localStorage.getItem('nexura_salary_records') || '[]'); } catch (_) {}
      localLogo = localStorage.getItem('nexura_company_logo') || '';
      const initial = { user_id: user.id, records: localRecords, company_logo: localLogo, updated_at: new Date().toISOString() };
      const inserted = await client.from('nexura_workspace').upsert(initial, { onConflict: 'user_id' });
      if (inserted.error) throw new Error('Could not create your private cloud workspace: ' + inserted.error.message);
      data = { records: localRecords, company_logo: localLogo };
    }
    localStorage.setItem('nexura_salary_records', JSON.stringify(Array.isArray(data.records) ? data.records : []));
    if (data.company_logo) localStorage.setItem('nexura_company_logo', data.company_logo); else localStorage.removeItem('nexura_company_logo');
    window.NEXURA_CLOUD_SAVE = queueCloudSave;
    root.style.display = 'none';
    document.body.classList.add('nexura-authenticated');
    appBar.style.display = 'flex';
    document.getElementById('cloudUser').textContent = user.email || 'Owner account';
    setSyncStatus('Cloud synced', false);
    resolveReady();
  }

  function setSyncStatus(label, bad) {
    const el = document.getElementById('cloudSyncStatus');
    if (el) { el.textContent = label; el.style.color = bad ? '#ff9aad' : '#68e4ff'; el.style.borderColor = bad ? '#693346' : '#245176'; }
  }

  function queueCloudSave(records, logo) {
    pendingPayload = { user_id: currentUser.id, records, company_logo: logo || '', updated_at: new Date().toISOString() };
    setSyncStatus('Saving to cloud…', false);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      const payload = pendingPayload;
      const { error } = await client.from('nexura_workspace').upsert(payload, { onConflict: 'user_id' });
      if (error) setSyncStatus('Sync failed — local copy kept', true);
      else setSyncStatus('All changes saved', false);
    }, 550);
  }

  document.addEventListener('DOMContentLoaded', () => {
    const signOut = document.getElementById('cloudSignOut');
    if (signOut) signOut.addEventListener('click', async () => { await client.auth.signOut(); location.reload(); });
  });

  if (!url || !key || !window.supabase?.createClient) {
    showSetup(!window.supabase?.createClient ? 'Could not load the Supabase client library. Check your internet connection.' : '');
    return;
  }
  client = window.supabase.createClient(url, key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
  client.auth.getSession().then(async ({ data, error }) => {
    if (error) { showAuth('login', error.message, true); return; }
    if (data.session?.user) {
      try { await enterWorkspace(data.session.user); }
      catch (err) { showAuth('login', err.message, true); }
    } else showAuth('login');
  }).catch(err => showAuth('login', err.message, true));

  client.auth.onAuthStateChange((event) => {
    if (event === 'SIGNED_OUT') { document.body.classList.remove('nexura-authenticated'); root.style.display = 'grid'; }
  });
})();
