-- Nexura Tech: private single-owner workspace
-- Run this entire file in Supabase Dashboard > SQL Editor > New query.

create table if not exists public.nexura_workspace (
  user_id uuid primary key references auth.users(id) on delete cascade,
  records jsonb not null default '[]'::jsonb,
  company_logo text not null default '',
  updated_at timestamptz not null default now()
);

alter table public.nexura_workspace enable row level security;

-- Each signed-in account can access only its own workspace row.
drop policy if exists "Owner can read own Nexura workspace" on public.nexura_workspace;
create policy "Owner can read own Nexura workspace"
  on public.nexura_workspace for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Owner can create own Nexura workspace" on public.nexura_workspace;
create policy "Owner can create own Nexura workspace"
  on public.nexura_workspace for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Owner can update own Nexura workspace" on public.nexura_workspace;
create policy "Owner can update own Nexura workspace"
  on public.nexura_workspace for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Owner can delete own Nexura workspace" on public.nexura_workspace;
create policy "Owner can delete own Nexura workspace"
  on public.nexura_workspace for delete
  to authenticated
  using (auth.uid() = user_id);

grant select, insert, update, delete on public.nexura_workspace to authenticated;
