/* Supabase browser credentials. The publishable key is designed for client-side use.
   Never place a secret/service_role key or database password in this file. */
window.NEXURA_CONFIG = {
  SUPABASE_URL: "https://qtjdnbvbrnejhouokein.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_1UVzfD0kzD5My0SI4xb38A_3K4yrWIe"
};
