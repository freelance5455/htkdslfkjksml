NEXURA TECH — SINGLE OWNER CLOUD APP
===================================

This package adds one private owner login and cloud sync to the existing Nexura salary app.
Employees do not get accounts. Salary records and the company logo are saved in a private
Supabase workspace and are loaded when the owner logs in from another device.

IMPORTANT: This package has already been configured with the Supabase Project URL and
publishable key you supplied. Your database schema was successfully run in Supabase.

STEP 1 — Create your private database
-------------------------------------
1. Go to https://supabase.com/ and create an account/project.
2. In your project, open SQL Editor > New query.
3. Open supabase/schema.sql from this package, copy all its contents, and run it.
4. Open Project Settings > API (or API Keys).
5. Copy the Project URL and the publishable key. A legacy anon key also works.

NEVER copy/share the service_role key, secret API key, or database password.

STEP 2 — Connect the app
------------------------
Option A (recommended for every device):
1. The supplied Project URL and publishable key are already saved in config.js.
2. Upload the extracted package folder contents to your static host (for Netlify Drop,
   extract the ZIP first and upload the folder contents).

Option B (quick test on one device):
Not needed for this configured package. The connection details are already included in config.js.

STEP 3 — Create your owner account
----------------------------------
1. Open the deployed app over HTTPS.
2. Choose “First time? Create owner account”.
3. Enter your own email and a strong password.
4. If email confirmation is enabled, confirm the email, then log in.
5. After your owner account is created, open Supabase Authentication settings and turn OFF
   new user signups / public signups. Keep email/password sign-in enabled.

The app's database policies also isolate each account to its own row, but disabling public
signups ensures nobody else can create a separate account for this app.

STEP 4 — Verify your records
----------------------------
- On the first login from a browser with existing Nexura local records, those records are
  imported into your new cloud workspace if no cloud workspace exists yet.
- Later saves update the cloud workspace automatically.
- Log in on another device using the same owner email/password to load the same records.
- Watch the cloud status at the top of the app. It should say “All changes saved”.

DATA NOTES
----------
- The app keeps a local browser copy as a convenience, but Supabase is the shared cloud copy.
- A sync failure is shown in the status bar; check your internet/database connection before
  closing the page if it says sync failed.
- This version syncs saved salary records and the payslip company logo. The current invoice
  screen is a print-ready invoice builder and does not yet maintain invoice history.
- Keep access to your Supabase account and enable its available backups. For extra safety,
  periodically export your records from Supabase.


SECURITY REMINDER
-----------------
The publishable key is intended for browser use. Never add a Supabase secret/service_role key
or database password to the app. After creating your own owner account and confirming your
email (if required), disable public signups in Supabase Authentication settings. This keeps
this as a single-owner portal. Do not disable email/password sign-in.
