# Verónica → APK real

Ya tienes la app preparada como **PWA completa** (iconos, manifest, service worker).

## Método más fácil (recomendado) — PWABuilder

### Paso 1: Publicar la carpeta `www` en internet (gratis)

Opciones rápidas:

**A) Netlify Drop (más fácil)**
1. Ve a https://app.netlify.com/drop
2. Arrastra la carpeta `www` completa
3. Copia la URL que te da (ejemplo: `https://random-name.netlify.app`)

**B) GitHub Pages**
1. Crea un repositorio nuevo
2. Sube el contenido de la carpeta `www`
3. Activa GitHub Pages en Settings → Pages

### Paso 2: Generar la APK
1. Ve a https://www.pwabuilder.com
2. Pega la URL de tu Verónica
3. Pulsa **Start**
4. Cuando termine el análisis, ve a la pestaña **Package**
5. Elige **Android** → **Generate**
6. Descarga el archivo `.apk` (o el paquete AAB)

Listo. Ya puedes instalarlo en cualquier Android.

---

## Alternativa: Capacitor (más control)

Si más adelante quieres firmar la APK o publicar en Play Store:

```bash
npm create @capacitor/app
# Copia el contenido de www/ a la carpeta web de Capacitor
npx cap add android
npx cap sync
npx cap open android   # abre Android Studio y genera la APK
```

---

## Icono

Se generó un icono de zorrito naranja sobre fondo oscuro en todos los tamaños necesarios (48 → 512 px + maskable).

---

## Notas importantes

- La primera vez que abras la APK Android puede avisar de “origen desconocido”. Hay que permitir la instalación.
- Las notificaciones y el micrófono funcionan mejor si la app está instalada (PWA o APK).
- Todas las claves de API siguen dentro del HTML (igual que antes). No es lo más seguro para distribución masiva, pero está bien para uso personal.
