const canvas = document.getElementById('caliperCanvas');
const ctx = canvas.getContext('2d');

const precisionSelect = document.getElementById('precision-select');
const newPieceBtn = document.getElementById('new-piece-btn');
const zoomInBtn = document.getElementById('zoom-in-btn');
const zoomOutBtn = document.getElementById('zoom-out-btn');
const resetViewBtn = document.getElementById('reset-view-btn');
const userAnswerInput = document.getElementById('user-answer');
const checkBtn = document.getElementById('check-btn');
const feedbackBox = document.getElementById('feedback-box');
const scoreCorrectEl = document.getElementById('score-correct');
const scoreWrongEl = document.getElementById('score-wrong');

// Measurement & State variables
let precision = 0.02; // 0.02 or 0.05
let targetMeasurement = 0; // in mm (strictly <= 90 mm)
let pieceShape = 'cylinder';
let correctCount = 0;
let wrongCount = 0;
let solvedCurrent = false;
let highlightAlignment = false;

// Interactive Camera (Zoom & Pan) state
let zoomLevel = 1.0;
const MIN_ZOOM = 1.0;
const MAX_ZOOM = 4.5;
let panX = 0;
let panY = 0;
let isDragging = false;
let dragStartX = 0;
let dragStartY = 0;

// Geometry constants (scaled so up to 90mm piece + 49mm vernier fits cleanly on the 140mm main scale)
const pxPerMm = 5.6;
const originX = 85;
const beamY = 125;
const beamHeight = 62;
const MAIN_SCALE_MAX_MM = 140; // Enough room for a 90mm piece + 49mm vernier plate
const MAX_PIECE_MM = 90;       // Workpieces will never exceed 90 mm

function drawRoundedRect(context, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    context.beginPath();
    context.moveTo(x + r, y);
    context.arcTo(x + width, y, x + width, y + height, r);
    context.arcTo(x + width, y + height, x, y + height, r);
    context.arcTo(x, y + height, x, y, r);
    context.arcTo(x, y, x + width, y, r);
    context.closePath();
}

function clampPan() {
    const maxOffsetX = (canvas.width * zoomLevel) * 0.65;
    const maxOffsetY = (canvas.height * zoomLevel) * 0.65;
    panX = Math.max(-maxOffsetX, Math.min(maxOffsetX, panX));
    panY = Math.max(-maxOffsetY, Math.min(maxOffsetY, panY));
}

function resetView() {
    zoomLevel = 1.0;
    panX = 0;
    panY = 0;
    drawCaliper();
}

function zoomAtCenter(factor) {
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoomLevel * factor));
    if (newZoom === zoomLevel) return;

    if (zoomLevel === 1.0 && newZoom > 1.0) {
        const jawOffsetPx = targetMeasurement * pxPerMm;
        const focusWorldX = originX + jawOffsetPx + 20 * pxPerMm;
        const focusWorldY = beamY + beamHeight;
        panX = canvas.width / 2 - focusWorldX * newZoom;
        panY = canvas.height / 2 - focusWorldY * newZoom;
    } else {
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        panX = centerX - (centerX - panX) * (newZoom / zoomLevel);
        panY = centerY - (centerY - panY) * (newZoom / zoomLevel);
    }

    zoomLevel = newZoom;
    if (zoomLevel === 1.0) {
        panX = 0;
        panY = 0;
    } else {
        clampPan();
    }
    drawCaliper();
}

// Generate random measurement strictly <= 90.00 mm
function generateNewPiece() {
    precision = parseFloat(precisionSelect.value);

    const minSteps = Math.round(5 / precision);
    const maxSteps = Math.floor(MAX_PIECE_MM / precision);
    const randomSteps = Math.floor(Math.random() * (maxSteps - minSteps + 1)) + minSteps;

    targetMeasurement = Math.min(MAX_PIECE_MM, parseFloat((randomSteps * precision).toFixed(2)));

    const shapes = ['cylinder', 'block', 'hex'];
    pieceShape = shapes[Math.floor(Math.random() * shapes.length)];

    solvedCurrent = false;
    highlightAlignment = false;
    userAnswerInput.value = '';
    feedbackBox.className = 'feedback hidden';
    feedbackBox.innerHTML = '';
    userAnswerInput.focus();

    drawCaliper();
}

function getAlignmentDetails() {
    const mainMm = Math.floor(targetMeasurement + 0.0001);
    const decimalPart = parseFloat((targetMeasurement - mainMm).toFixed(2));
    const vernierTickIndex = Math.round(decimalPart / precision);
    const stepMm = precision === 0.02 ? 0.98 : 1.95;
    const alignedMainScaleMm = Math.round(targetMeasurement + vernierTickIndex * stepMm);

    const vernierLabelValue = precision === 0.02
        ? (vernierTickIndex / 5)
        : (vernierTickIndex / 2);

    return {
        mainMm,
        decimalPart,
        vernierTickIndex,
        alignedMainScaleMm,
        vernierLabelValue
    };
}

function drawCaliper() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();

    ctx.translate(panX, panY);
    ctx.scale(zoomLevel, zoomLevel);

    const jawOffsetPx = targetMeasurement * pxPerMm;

    // 1. Draw Steel Workpiece between jaws (max 90 mm)
    drawWorkpiece(originX, beamY + beamHeight + 35, jawOffsetPx);

    // 2. Draw Fixed Main Beam & Fixed Jaw
    drawMainBeam();

    // 3. Draw Sliding Vernier Carriage & Movable Jaw
    drawVernierSlider(originX + jawOffsetPx);

    ctx.restore();

    // Draw HUD badge for zoom level & drag hint
    ctx.fillStyle = 'rgba(33, 37, 41, 0.82)';
    drawRoundedRect(ctx, 14, 12, 235, 32, 6);
    ctx.fill();
    ctx.fillStyle = zoomLevel > 1.0 ? '#fcc419' : '#f8f9fa';
    ctx.font = 'bold 13px Tahoma, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(`التكبير: ${zoomLevel.toFixed(1)}x | اسحب للتحريك ✋`, 236, 33);
}

function drawWorkpiece(startX, topY, widthPx) {
    const pieceHeight = 85;

    const steelGrad = ctx.createLinearGradient(startX, topY, startX + widthPx, topY + pieceHeight);
    steelGrad.addColorStop(0, '#5c6773');
    steelGrad.addColorStop(0.3, '#9aa5b1');
    steelGrad.addColorStop(0.5, '#cbd2d9');
    steelGrad.addColorStop(0.75, '#7b8794');
    steelGrad.addColorStop(1, '#3e4c59');

    ctx.fillStyle = steelGrad;
    ctx.strokeStyle = '#1f2933';
    ctx.lineWidth = 1.5;

    ctx.beginPath();
    if (pieceShape === 'cylinder') {
        const chamfer = Math.min(5, widthPx * 0.1);
        ctx.moveTo(startX + chamfer, topY);
        ctx.lineTo(startX + widthPx - chamfer, topY);
        ctx.lineTo(startX + widthPx, topY + chamfer);
        ctx.lineTo(startX + widthPx, topY + pieceHeight - chamfer);
        ctx.lineTo(startX + widthPx - chamfer, topY + pieceHeight);
        ctx.lineTo(startX + chamfer, topY + pieceHeight);
        ctx.lineTo(startX, topY + pieceHeight - chamfer);
        ctx.lineTo(startX, topY + chamfer);
        ctx.closePath();
    } else if (pieceShape === 'hex') {
        ctx.rect(startX, topY + 5, widthPx, pieceHeight - 10);
    } else {
        ctx.rect(startX, topY, widthPx, pieceHeight);
    }
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
    ctx.lineWidth = 1;
    for (let y = topY + 14; y < topY + pieceHeight - 10; y += 14) {
        ctx.beginPath();
        ctx.moveTo(startX + 2, y);
        ctx.lineTo(startX + widthPx - 2, y);
        ctx.stroke();
    }

    if (widthPx > 65) {
        ctx.fillStyle = '#102a43';
        ctx.font = 'bold 13px Tahoma, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('قطعة حديدية', startX + widthPx / 2, topY + pieceHeight / 2 + 5);
    }
}

function drawMainBeam() {
    const beamStartX = 35;
    const beamEndX = originX + (MAIN_SCALE_MAX_MM + 8) * pxPerMm;

    const metalGrad = ctx.createLinearGradient(0, beamY, 0, beamY + beamHeight);
    metalGrad.addColorStop(0, '#ced4da');
    metalGrad.addColorStop(0.5, '#f1f3f5');
    metalGrad.addColorStop(1, '#adb5bd');

    ctx.fillStyle = metalGrad;
    ctx.strokeStyle = '#343a40';
    ctx.lineWidth = 1.8;

    ctx.beginPath();
    ctx.moveTo(beamStartX, beamY);
    ctx.lineTo(originX - 18, beamY);
    ctx.lineTo(originX - 18, beamY - 55);
    ctx.lineTo(originX, beamY - 35);
    ctx.lineTo(originX, beamY);
    ctx.lineTo(beamEndX, beamY);
    ctx.lineTo(beamEndX, beamY + beamHeight);
    ctx.lineTo(originX, beamY + beamHeight);
    ctx.lineTo(originX, beamY + beamHeight + 145);
    ctx.lineTo(originX - 16, beamY + beamHeight + 130);
    ctx.lineTo(beamStartX, beamY + beamHeight + 65);
    ctx.closePath();

    ctx.fill();
    ctx.stroke();

    drawMainTicks(beamStartX, beamEndX);
}

function drawMainTicks(minX, maxX) {
    const details = getAlignmentDetails();
    ctx.textAlign = 'center';

    for (let mm = 0; mm <= MAIN_SCALE_MAX_MM; mm++) {
        const x = originX + mm * pxPerMm;
        if (x < minX - 10 || x > maxX + 10) continue;

        let tickLen = 11;
        ctx.lineWidth = 0.95;
        ctx.strokeStyle = '#111';
        ctx.fillStyle = '#111';

        if (mm % 10 === 0) {
            tickLen = 22;
            ctx.lineWidth = 1.5;
            ctx.font = 'bold 11px Arial, sans-serif';
            ctx.fillText(mm.toString(), x, beamY + beamHeight - 26);
        } else if (mm % 5 === 0) {
            tickLen = 16;
            ctx.lineWidth = 1.25;
        }

        if (highlightAlignment && mm === details.alignedMainScaleMm) {
            ctx.strokeStyle = '#2b8a3e';
            ctx.lineWidth = 2.2;
            tickLen = 26;
        }

        ctx.beginPath();
        ctx.moveTo(x, beamY + beamHeight);
        ctx.lineTo(x, beamY + beamHeight - tickLen);
        ctx.stroke();
    }

    ctx.font = 'bold 11px Arial, sans-serif';
    ctx.fillStyle = '#212529';
    ctx.fillText('mm', originX + (MAIN_SCALE_MAX_MM + 3.5) * pxPerMm, beamY + beamHeight - 26);
}

function drawVernierSlider(vernierZeroX) {
    const divisions = precision === 0.02 ? 50 : 20;
    const vernierSpanMm = precision === 0.02 ? 49 : 39;
    const stepMm = vernierSpanMm / divisions;

    const sliderWidth = (vernierSpanMm + 11) * pxPerMm;
    const sliderTop = beamY - 6;
    const sliderHeight = beamHeight + 48;

    const sliderGrad = ctx.createLinearGradient(0, sliderTop, 0, sliderTop + sliderHeight);
    sliderGrad.addColorStop(0, '#dee2e6');
    sliderGrad.addColorStop(0.45, '#f8f9fa');
    sliderGrad.addColorStop(1, '#adb5bd');

    ctx.fillStyle = sliderGrad;
    ctx.strokeStyle = '#212529';
    ctx.lineWidth = 1.8;

    ctx.beginPath();
    ctx.moveTo(vernierZeroX, beamY);
    ctx.lineTo(vernierZeroX, beamY - 35);
    ctx.lineTo(vernierZeroX + 18, beamY - 55);
    ctx.lineTo(vernierZeroX + 18, sliderTop);
    ctx.lineTo(vernierZeroX + sliderWidth, sliderTop);
    ctx.lineTo(vernierZeroX + sliderWidth, beamY + beamHeight + 42);
    ctx.lineTo(vernierZeroX + 24, beamY + beamHeight + 42);
    ctx.lineTo(vernierZeroX + 24, beamY + beamHeight + 130);
    ctx.lineTo(vernierZeroX, beamY + beamHeight + 145);
    ctx.closePath();

    ctx.fill();
    ctx.stroke();

    // Window cutout revealing main scale
    const windowLeft = vernierZeroX - 5;
    const windowWidth = sliderWidth + 1;
    const windowTop = beamY + 12;
    const windowHeight = beamHeight - 12;

    ctx.save();
    ctx.beginPath();
    ctx.rect(windowLeft, windowTop, windowWidth, windowHeight);
    ctx.clip();

    const winGrad = ctx.createLinearGradient(0, beamY, 0, beamY + beamHeight);
    winGrad.addColorStop(0, '#ced4da');
    winGrad.addColorStop(0.5, '#f1f3f5');
    winGrad.addColorStop(1, '#adb5bd');
    ctx.fillStyle = winGrad;
    ctx.fillRect(windowLeft, windowTop, windowWidth, windowHeight);

    drawMainTicks(windowLeft, windowLeft + windowWidth);
    ctx.restore();

    ctx.strokeStyle = '#495057';
    ctx.lineWidth = 1.3;
    ctx.strokeRect(windowLeft, windowTop, windowWidth, windowHeight);

    // Draw Vernier Scale Ticks
    const vernierBaseY = beamY + beamHeight;
    const details = getAlignmentDetails();
    ctx.textAlign = 'center';

    for (let i = 0; i <= divisions; i++) {
        const x = vernierZeroX + i * stepMm * pxPerMm;
        let tickLen = 11;
        ctx.lineWidth = 0.95;

        if (i === 0) {
            ctx.strokeStyle = '#c92a2a';
            ctx.fillStyle = '#c92a2a';
        } else {
            ctx.strokeStyle = '#111';
            ctx.fillStyle = '#111';
        }

        if (precision === 0.02) {
            if (i % 5 === 0) {
                tickLen = 19;
                ctx.lineWidth = 1.4;
                ctx.font = 'bold 10px Arial, sans-serif';
                const labelNum = i === 50 ? '10' : (i / 5).toString();
                ctx.fillText(labelNum, x, vernierBaseY + 31);
            }
        } else {
            if (i % 2 === 0) {
                tickLen = 19;
                ctx.lineWidth = 1.4;
                ctx.font = 'bold 10px Arial, sans-serif';
                const labelNum = i === 20 ? '10' : (i / 2).toString();
                ctx.fillText(labelNum, x, vernierBaseY + 31);
            }
        }

        if (highlightAlignment && i === details.vernierTickIndex) {
            ctx.strokeStyle = '#2b8a3e';
            ctx.lineWidth = 2.2;
            tickLen = 24;
        }

        ctx.beginPath();
        ctx.moveTo(x, vernierBaseY);
        ctx.lineTo(x, vernierBaseY + tickLen);
        ctx.stroke();
    }

    if (highlightAlignment) {
        const alignX = vernierZeroX + details.vernierTickIndex * stepMm * pxPerMm;
        ctx.fillStyle = '#2b8a3e';
        ctx.beginPath();
        ctx.moveTo(alignX, vernierBaseY + 26);
        ctx.lineTo(alignX - 4, vernierBaseY + 35);
        ctx.lineTo(alignX + 4, vernierBaseY + 35);
        ctx.closePath();
        ctx.fill();
    }

    // Precision stamp
    ctx.fillStyle = '#212529';
    ctx.font = 'bold 9.5px Arial, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`${precision.toFixed(2)} mm`, vernierZeroX + sliderWidth - 46, vernierBaseY + 34);

    // Locking screw
    ctx.fillStyle = '#868e96';
    ctx.strokeStyle = '#212529';
    ctx.lineWidth = 1.4;
    ctx.fillRect(vernierZeroX + sliderWidth * 0.45, sliderTop - 9, 12, 9);
    ctx.strokeRect(vernierZeroX + sliderWidth * 0.45, sliderTop - 9, 12, 9);
    ctx.fillRect(vernierZeroX + sliderWidth * 0.45 - 4, sliderTop - 14, 20, 5);
    ctx.strokeRect(vernierZeroX + sliderWidth * 0.45 - 4, sliderTop - 14, 20, 5);
}

function checkAnswer() {
    const rawVal = userAnswerInput.value.trim();
    if (rawVal === '') {
        feedbackBox.className = 'feedback wrong';
        feedbackBox.innerHTML = 'يرجى كتابة رقم القياس أولاً!';
        return;
    }

    const userVal = parseFloat(rawVal);
    if (isNaN(userVal)) {
        feedbackBox.className = 'feedback wrong';
        feedbackBox.innerHTML = 'خطأ: يرجى إدخال رقم صحيح.';
        return;
    }

    const isCorrect = Math.abs(userVal - targetMeasurement) < 0.001;

    if (isCorrect) {
        highlightAlignment = false;
        drawCaliper();
        feedbackBox.className = 'feedback correct';
        feedbackBox.innerHTML = `صح! ✔ قراءة ممتازة (<span class="highlight-num">${targetMeasurement.toFixed(2)} mm</span>)`;
        if (!solvedCurrent) {
            correctCount++;
            scoreCorrectEl.textContent = correctCount;
            solvedCurrent = true;
        }
    } else {
        highlightAlignment = true;
        drawCaliper();

        const details = getAlignmentDetails();
        const divisionsTotal = precision === 0.02 ? 50 : 20;

        let vernierPositionDesc = '';
        if (details.vernierTickIndex === 0) {
            vernierPositionDesc = `شرطة <span class="highlight-num">0</span> في الورنية منطبقة تماماً على شرطة <span class="highlight-num">${details.alignedMainScaleMm} mm</span> في التدريج الرئيسي (بدون كسور).`;
        } else {
            const labelInfo = Number.isInteger(details.vernierLabelValue)
                ? `وهي الشرطة المكتوب تحتها رقم <span class="highlight-num">${details.vernierLabelValue}</span>`
                : `وهي تقع بعد رقم <span class="highlight-num">${Math.floor(details.vernierLabelValue)}</span> بـ <span class="highlight-num">${Math.round((details.vernierLabelValue % 1) * (precision === 0.02 ? 5 : 2))}</span> شرطة صغيرة`;

            vernierPositionDesc = `الشرطة رقم <span class="highlight-num">${details.vernierTickIndex}</span> من أصل ${divisionsTotal} في الورنية (${labelInfo}) منطبقة تماماً في وجه شرطة <span class="highlight-num">${details.alignedMainScaleMm} mm</span> في التدريج الرئيسي (مظللة باللون الأخضر على الرسم).`;
        }

        feedbackBox.className = 'feedback wrong';
        feedbackBox.innerHTML = `
            <div class="explain-title">خطأ ✖ — إليك شرح مكان تطابق الشرط:</div>
            <ul>
                <li><strong>1. قراءة التدريج الرئيسي (الثابت):</strong> صفر الورنية (الشرطة الحمراء) تجاوز شرطة <span class="highlight-num">${details.mainMm} mm</span> بقليل.</li>
                <li><strong>2. مكان تطابق شرطة الورنية:</strong> ${vernierPositionDesc}</li>
                <li><strong>3. حساب الكسر العشري:</strong> <span class="highlight-num">${details.vernierTickIndex} × ${precision.toFixed(2)} = ${details.decimalPart.toFixed(2)} mm</span>.</li>
                <li><strong>القراءة الصحيحة الكاملة:</strong> <span class="highlight-num">${details.mainMm} + ${details.decimalPart.toFixed(2)} = ${targetMeasurement.toFixed(2)} mm</span>.</li>
            </ul>
        `;

        if (!solvedCurrent) {
            wrongCount++;
            scoreWrongEl.textContent = wrongCount;
        }
    }
}

// Mouse & Touch Dragging (Panning)
function getCanvasCoords(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
        x: (clientX - rect.left) * scaleX,
        y: (clientY - rect.top) * scaleY
    };
}

canvas.addEventListener('mousedown', (e) => {
    isDragging = true;
    const coords = getCanvasCoords(e.clientX, e.clientY);
    dragStartX = coords.x - panX;
    dragStartY = coords.y - panY;
});

window.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const coords = getCanvasCoords(e.clientX, e.clientY);
    panX = coords.x - dragStartX;
    panY = coords.y - dragStartY;
    clampPan();
    drawCaliper();
});

window.addEventListener('mouseup', () => {
    isDragging = false;
});

canvas.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
        isDragging = true;
        const coords = getCanvasCoords(e.touches[0].clientX, e.touches[0].clientY);
        dragStartX = coords.x - panX;
        dragStartY = coords.y - panY;
    }
}, { passive: true });

canvas.addEventListener('touchmove', (e) => {
    if (!isDragging || e.touches.length !== 1) return;
    e.preventDefault();
    const coords = getCanvasCoords(e.touches[0].clientX, e.touches[0].clientY);
    panX = coords.x - dragStartX;
    panY = coords.y - dragStartY;
    clampPan();
    drawCaliper();
}, { passive: false });

canvas.addEventListener('touchend', () => {
    isDragging = false;
});

canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const coords = getCanvasCoords(e.clientX, e.clientY);
    const zoomFactor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoomLevel * zoomFactor));
    if (newZoom === zoomLevel) return;

    panX = coords.x - (coords.x - panX) * (newZoom / zoomLevel);
    panY = coords.y - (coords.y - panY) * (newZoom / zoomLevel);
    zoomLevel = newZoom;

    if (zoomLevel === 1.0) {
        panX = 0;
        panY = 0;
    } else {
        clampPan();
    }
    drawCaliper();
}, { passive: false });

precisionSelect.addEventListener('change', generateNewPiece);
newPieceBtn.addEventListener('click', generateNewPiece);
zoomInBtn.addEventListener('click', () => zoomAtCenter(1.35));
zoomOutBtn.addEventListener('click', () => zoomAtCenter(1 / 1.35));
resetViewBtn.addEventListener('click', resetView);
checkBtn.addEventListener('click', checkAnswer);

userAnswerInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        checkAnswer();
    }
});

window.addEventListener('load', generateNewPiece);
