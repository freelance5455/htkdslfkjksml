# Vedic Math Brain Quest Pro

Single-file offline HTML learning game.

## Major features
- 50 progressive puzzle levels
- Detailed Vedic Math Academy
- Step-by-step worked examples
- Addition, subtraction, multiplication, division
- Squares and square roots
- Multiplication by 11
- Near-100 multiplication
- Complements to 10/100/1000
- Mental number patterns
- Mental Speed Lab
- Wrong-answer teaching: step-by-step solution and method
- Practice mode
- Daily Challenge
- Coins and stars
- Achievement badges
- LocalStorage progress
- Responsive mobile UI
- Offline operation

## Preview
Open `index.html` in a modern mobile browser.

## APK
The HTML can later be wrapped in a WebView/Capacitor/Cordova-style Android project.
