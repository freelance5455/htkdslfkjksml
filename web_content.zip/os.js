'use strict';
const $=(s,p=document)=>p.querySelector(s), $$=(s,p=document)=>[...p.querySelectorAll(s)];
const root=$('#root'),os=$('#os'),desk=$('#desk'),iconsEl=$('#icons'),winsEl=$('#wins'),fx=$('#fx'),taskbar=$('#taskbar'),tasksEl=$('#tasks'),startEl=$('#startmenu'),ctxEl=$('#ctx'),cursorEl=$('#cursor'),kbEl=$('#kb'),loginEl=$('#login'),msgEl=$('#msgscr');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
let STATE='boot',token=0,shell=true;

/* ---------- forced landscape ---------- */
let ROT=false;
function layout(){const w=innerWidth,h=innerHeight;ROT=h>w;
 if(ROT){root.style.width=h+'px';root.style.height=w+'px';root.style.transform='rotate(90deg) translateY(-100%)'}
 else{root.style.width=w+'px';root.style.height=h+'px';root.style.transform='none'}}
addEventListener('resize',layout);layout();
const toLocal=e=>ROT?{x:e.clientY,y:innerWidth-e.clientX}:{x:e.clientX,y:e.clientY};
const RW=()=>root.clientWidth,RH=()=>root.clientHeight;
function localRect(el){let x=0,y=0,e=el;while(e&&e!==root){x+=e.offsetLeft;y+=e.offsetTop;e=e.offsetParent}return{x,y,w:el.offsetWidth,h:el.offsetHeight}}

/* ---------- sound ---------- */
let AC=null;
function tone(f,d,t0=0,type='sine',v=.05){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime+t0;o.type=type;o.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g).connect(AC.destination);o.start(t);o.stop(t+d)}catch(e){}}
const ding=()=>{tone(880,.25);tone(660,.35,.08)};
const chime=()=>[[311,0],[466,.18],[415,.36],[311,.6],[466,.8],[622,1]].forEach(([f,t])=>tone(f,1.2,t,'triangle',.04));

/* ---------- dates ---------- */
const OLD=new Date(2001,7,23,12,0);
function fmt(d){let h=d.getHours(),m=String(d.getMinutes()).padStart(2,'0'),ap=h>=12?'PM':'AM';h=h%12||12;return `${d.getMonth()+1}/${d.getDate()}/${d.getFullYear()} ${h}:${m} ${ap}`}

/* ---------- file system ---------- */
let FS,C,DOCS;const RECYCLE={name:'Recycle Bin',type:'recycle',children:[]};
const CONTAINERS=['root','drive','cd','folder','recycle'];
function mk(name,type,extra={}){return Object.assign({name,type,date:OLD,children:CONTAINERS.includes(type)?[]:undefined},extra)}
function add(p,...kids){kids.forEach(k=>{k.parent=p;p.children.push(k)});return p}
const makeMemz=d=>mk('MEMZ.exe','memz',{date:d,size:'16 KB',icon:'memz'});
function buildFS(){
 FS=mk('My Computer','root');
 C=mk('Local Disk (C:)','drive',{letter:'C',icon:'driveC'});
 const D=mk('CD Drive (D:)','cd',{letter:'D'});add(FS,C,D);
 const das=mk('Documents and Settings','folder'),user=mk('User','folder');DOCS=mk('My Documents','folder',{icon:'docs'});
 add(DOCS,mk('My Music','folder'),mk('My Pictures','folder'),mk('readme.txt','txt',{size:'1 KB',content:'Welcome to Windows XP!\r\n\r\nTips:\r\n- Double-tap the empty desktop to show/hide the on-screen keyboard.\r\n- Long-press an item = right-click.\r\n- Win + L locks the computer.\r\n- Ctrl + Alt + Del opens Task Manager.'}));
 add(user,mk('Desktop','folder'),DOCS,mk('Favorites','folder'));add(das,mk('All Users','folder'),user);
 const pf=mk('Program Files','folder');add(pf,mk('Internet Explorer','folder'),mk('Windows Media Player','folder'),mk('Common Files','folder'));
 const win=mk('WINDOWS','folder',{critical:true,icon:'winfolder'}),s32=mk('system32','folder',{critical:true});
 add(s32,mk('cmd.exe','exe',{app:'cmd',icon:'cmd',size:'382 KB'}),mk('calc.exe','exe',{app:'calc',icon:'calc',size:'112 KB'}),mk('mspaint.exe','exe',{app:'mspaint',icon:'paint',size:'335 KB'}),mk('taskmgr.exe','exe',{app:'taskmgr',icon:'taskmgr',size:'137 KB'}),mk('winmine.exe','exe',{app:'winmine',icon:'mine',size:'117 KB'}),mk('hal.dll','sys',{size:'131 KB'}),mk('ntoskrnl.exe','sys',{size:'2,124 KB'}));
 add(win,s32,mk('Fonts','folder'),mk('Web','folder'),mk('explorer.exe','exe',{app:'explorer',size:'1,004 KB'}),mk('notepad.exe','exe',{app:'notepad',icon:'notepad',size:'68 KB'}),mk('win.ini','txt',{size:'1 KB',content:'; for 16-bit app support\r\n[fonts]\r\n[extensions]\r\n[mci extensions]\r\n[files]\r\n[Mail]\r\nMAPI=1'}));
 add(C,das,pf,win,makeMemz(new Date()),mk('boot.ini','txt',{size:'1 KB',content:'[boot loader]\r\ntimeout=30\r\ndefault=multi(0)disk(0)rdisk(0)partition(1)\\WINDOWS\r\n[operating systems]\r\nmulti(0)disk(0)rdisk(0)partition(1)\\WINDOWS="Microsoft Windows XP Professional" /fastdetect'}));
 RECYCLE.children=[];
}
function isAlive(n){while(n){if(n===FS)return true;n=n.parent}return false}
function detach(n){const a=n.parent.children,i=a.indexOf(n);if(i>=0)a.splice(i,1)}
function pathOf(n){if(!n)return '';if(n.type==='root')return 'My Computer';if(n.type==='recycle')return 'Recycle Bin';if(n.letter)return n.letter+':\\';const pp=pathOf(n.parent===RECYCLE?n.origParent:n.parent);return pp.endsWith('\\')?pp+n.name:pp+'\\'+n.name}
const TYPE={folder:'File Folder',txt:'Text Document',exe:'Application',memz:'Application',sys:'System file',drive:'Local Disk',cd:'CD Drive',root:'System Folder',recycle:'Recycle Bin'};
function nodeIcon(n){if(n.type==='recycle')return RECYCLE.children.length?'binF':'binE';return n.icon||({root:'pc',drive:'drive',cd:'cdrive',folder:'folder',txt:'txt',exe:'exe',sys:'sysfile',memz:'memz'})[n.type]||'exe'}
function uniqueName(p,base,ext=''){let n=base+ext,i=2;while(p.children.some(k=>k.name.toLowerCase()===n.toLowerCase()))n=`${base} (${i++})${ext}`;return n}
const findMemz=()=>C&&C.children.find(k=>k.type==='memz');

/* ---------- cursor + pointer ---------- */
let lp=null,suppress=false,lastPT='mouse',jit={x:0,y:0},cur={x:-40,y:-40};
cursorEl.innerHTML=CUR_ARROW;
function setCursor(p){cur=p;cursorEl.style.transform=`translate(${p.x+jit.x}px,${p.y+jit.y}px)`}
const busy=b=>cursorEl.innerHTML=b?CUR_BUSY:CUR_ARROW;
root.addEventListener('pointerdown',e=>{
 lastPT=e.pointerType;suppress=false;const p=toLocal(e);setCursor(p);
 if(!e.target.closest('#ctx'))hideMenu();
 if(!startEl.classList.contains('hidden')&&!e.target.closest('#startmenu,#startbtn,#kb'))toggleStart(false);
 if(e.pointerType!=='mouse'&&!e.target.closest('#kb')){if(lp)clearTimeout(lp.t);lp={x:p.x,y:p.y,t:setTimeout(()=>{lp=null;suppress=true;fireCtx(e.target,p.x,p.y)},550)}}
},true);
root.addEventListener('pointermove',e=>{const p=toLocal(e);setCursor(p);if(lp&&Math.hypot(p.x-lp.x,p.y-lp.y)>10){clearTimeout(lp.t);lp=null}},true);
['pointerup','pointercancel'].forEach(t=>root.addEventListener(t,()=>{if(lp){clearTimeout(lp.t);lp=null}},true));
root.addEventListener('click',e=>{if(suppress){suppress=false;e.stopPropagation();e.preventDefault()}},true);
root.addEventListener('contextmenu',e=>{e.preventDefault();if(lastPT==='mouse'){const p=toLocal(e);fireCtx(e.target,p.x,p.y)}});
function fireCtx(t,x,y){if(STATE!=='desktop')return;let el=t;while(el&&el!==root&&!el._ctx)el=el.parentElement;if(el&&el._ctx){const items=el._ctx();if(items&&items.length)showMenu(items,x,y)}}
function onDbl(el,fn,onlySelf){let t=0;el.addEventListener('click',e=>{if(onlySelf&&!onlySelf(e))return;const n=Date.now();if(n-t<450){t=0;fn(e)}else t=n})}

/* ---------- context menu ---------- */
function showMenu(items,x,y){
 ctxEl.innerHTML='';
 items.forEach(it=>{if(it==='-'){ctxEl.appendChild(document.createElement('hr'));return}
  const d=document.createElement('div');d.className='ci'+(it.bold?' b':'')+(it.disabled?' dis':'');d.textContent=it.label;
  d.onclick=e=>{e.stopPropagation();hideMenu();it.action&&it.action()};ctxEl.appendChild(d)});
 ctxEl.classList.remove('hidden');const w=ctxEl.offsetWidth,h=ctxEl.offsetHeight;
 ctxEl.style.left=clamp(x,0,RW()-w)+'px';ctxEl.style.top=(y+h>RH()?Math.max(0,y-h):y)+'px';
}
const hideMenu=()=>ctxEl.classList.add('hidden');
function menuAt(el,items){const r=localRect(el);showMenu(items,r.x,r.y+r.h)}

/* ---------- window manager ---------- */
let Z=100,activeWin=null;const WINS=[];
function createWindow(o){
 const el=document.createElement('div');el.className='win'+(o.h==='auto'?' auto':'');
 const rw=RW(),rh=RH()-30,W=Math.min(o.w||460,rw-8),H=o.h==='auto'?null:Math.min(o.h||320,rh-4),n=WINS.length%6;
 el.style.left=(o.x!=null?o.x:Math.max(0,Math.round((rw-W)/2-50+n*22)))+'px';
 el.style.top=(o.y!=null?o.y:Math.max(0,Math.round((rh-(H||170))/2-30+n*20)))+'px';
 el.style.width=W+'px';if(H)el.style.height=H+'px';
 el.innerHTML=`<div class="tb"><span class="ic"></span><span class="tt"></span>${o.noMin?'':`<button class="tbtn b-min" aria-label="Minimize">${S_MIN}</button>`}${o.noMax?'':`<button class="tbtn b-max" aria-label="Maximize">${S_MAX}</button>`}<button class="tbtn x b-x" aria-label="Close">${S_X}</button></div><div class="wbody"></div>${o.noResize||o.h==='auto'?'':'<div class="rz"></div>'}`;
 const win={el,o,body:el.querySelector('.wbody'),tb:el.querySelector('.tb'),proc:o.proc||null,minimized:false,onClose:o.onClose};
 if(!o.noTask){const t=document.createElement('div');t.className='task';t.innerHTML='<span class="ic"></span><span class="t"></span>';
  t.onclick=()=>{if(activeWin===win&&!win.minimized)win.minimize();else win.restore()};
  t._ctx=()=>[{label:'Restore',action:()=>win.restore()},{label:'Minimize',action:()=>win.minimize()},{label:'Maximize',disabled:!!o.noMax,action:()=>{win.restore();win.el.classList.add('max')}},'-',{label:'Close',bold:1,action:()=>win.close()}];
  tasksEl.appendChild(t);win.task=t}
 win.setTitle=t=>{win.title=t;el.querySelector('.tt').textContent=t;if(win.task)win.task.querySelector('.t').textContent=t};
 win.setIcon=i=>{win.icon=i;el.querySelector('.tb .ic').innerHTML=svg(i);if(win.task)win.task.querySelector('.ic').innerHTML=svg(i)};
 win.setTitle(o.title);win.setIcon(o.icon||'exe');
 const bm=el.querySelector('.b-min');if(bm)bm.onclick=e=>{e.stopPropagation();win.minimize()};
 const bx=el.querySelector('.b-max');if(bx){bx.onclick=e=>{e.stopPropagation();win.toggleMax()};onDbl(win.tb,()=>win.toggleMax(),e=>!e.target.closest('.tbtn'))}
 el.querySelector('.b-x').onclick=e=>{e.stopPropagation();win.close()};
 win.tb.addEventListener('pointerdown',e=>{if(e.target.closest('.tbtn')||el.classList.contains('max'))return;
  const p=toLocal(e),ox=p.x-el.offsetLeft,oy=p.y-el.offsetTop;win.tb.setPointerCapture(e.pointerId);
  const mv=ev=>{const q=toLocal(ev);el.style.left=clamp(q.x-ox,-el.offsetWidth+60,RW()-60)+'px';el.style.top=clamp(q.y-oy,0,RH()-58)+'px'};
  const up=()=>{win.tb.removeEventListener('pointermove',mv);win.tb.removeEventListener('pointerup',up);win.tb.removeEventListener('pointercancel',up)};
  win.tb.addEventListener('pointermove',mv);win.tb.addEventListener('pointerup',up);win.tb.addEventListener('pointercancel',up)});
 const rz=el.querySelector('.rz');if(rz)rz.addEventListener('pointerdown',e=>{e.stopPropagation();const p=toLocal(e),w0=el.offsetWidth,h0=el.offsetHeight;rz.setPointerCapture(e.pointerId);
  const mv=ev=>{const q=toLocal(ev);el.style.width=Math.max(200,w0+q.x-p.x)+'px';el.style.height=Math.max(120,h0+q.y-p.y)+'px';win.onResize&&win.onResize()};
  const up=()=>{rz.removeEventListener('pointermove',mv);rz.removeEventListener('pointerup',up)};rz.addEventListener('pointermove',mv);rz.addEventListener('pointerup',up)});
 el.addEventListener('pointerdown',()=>focusWin(win),true);
 win.minimize=()=>{win.minimized=true;el.classList.add('min');if(activeWin===win){activeWin=null;focusTop()}updTasks()};
 win.restore=()=>{win.minimized=false;el.classList.remove('min');focusWin(win)};
 win.toggleMax=()=>{el.classList.toggle('max');win.onResize&&setTimeout(win.onResize,0)};
 win.close=()=>{if(win.closed)return;win.closed=true;try{win.onClose&&win.onClose()}catch(e){}el.remove();win.task&&win.task.remove();WINS.splice(WINS.indexOf(win),1);if(activeWin===win){activeWin=null;focusTop()}updTasks();if(o.resolve)o.resolve(null)};
 winsEl.appendChild(el);WINS.push(win);focusWin(win);if(o.max)el.classList.add('max');
 if(memz.running&&memz.reversed)win.setTitle([...o.title].reverse().join(''));
 return win;
}
function focusWin(w){activeWin=w;if(w.el.style.zIndex!=Z)w.el.style.zIndex=++Z;WINS.forEach(x=>x.el.classList.toggle('inactive',x!==w));updTasks()}
function focusTop(){const v=WINS.filter(w=>!w.minimized).sort((a,b)=>b.el.style.zIndex-a.el.style.zIndex);if(v[0])focusWin(v[0]);else{WINS.forEach(x=>x.el.classList.add('inactive'));updTasks()}}
function updTasks(){WINS.forEach(w=>w.task&&w.task.classList.toggle('active',w===activeWin&&!w.minimized))}
function closeAll(){[...WINS].forEach(w=>w.close())}
function showDesktop(){WINS.forEach(w=>w.minimize())}

/* ---------- dialogs ---------- */
function msgBox(title,text,icon='info',buttons=['OK']){
 return new Promise(res=>{
  const w=createWindow({title,icon:icon==='question'?'info':icon,w:Math.min(440,Math.max(290,text.length*2.4+150)),h:'auto',noMin:1,noMax:1,noResize:1,resolve:res});
  w.body.innerHTML=`<div class="dlg"><div class="dlg-row">${ic(icon,32)}<div class="dlg-msg"></div></div><div class="dlg-btns"></div></div>`;
  w.body.querySelector('.dlg-msg').textContent=text;
  const bb=w.body.querySelector('.dlg-btns');
  buttons.forEach(b=>{const btn=document.createElement('button');btn.className='xbtn';btn.textContent=b;btn.onclick=()=>{w.o.resolve=null;w.close();res(b)};bb.appendChild(btn)});
  if(icon==='error'||icon==='warn')ding();
 });
}
const confirmBox=(text,title='Confirm File Delete',icon='binF')=>msgBox(title,text,icon,['Yes','No']).then(r=>r==='Yes');

/* ---------- explorer ---------- */
const EXPLORERS=new Set();
function upOf(n){return n.type==='root'||n.type==='recycle'?null:n.parent}
function openExplorer(node){
 if(!node||(node!==RECYCLE&&!isAlive(node))){msgBox('Error',"Windows cannot find the folder. It may have been moved or deleted.",'error');return}
 const win=createWindow({title:node.name,icon:nodeIcon(node),w:620,h:400});
 win.body.innerHTML=`<div class="menubar"><span>File</span><span>Edit</span><span>View</span><span>Favorites</span><span>Tools</span><span>Help</span></div>
 <div class="toolbar"><button class="tbb b-back">${ic('back',22)}<span>Back</span></button><button class="tbb b-fwd" aria-label="Forward">${ic('fwd',22)}</button><button class="tbb b-up" aria-label="Up">${ic('up',22)}</button><i class="tsep"></i><button class="tbb b-search">${ic('search',22)}<span>Search</span></button><button class="tbb b-folders">${ic('folder',22)}<span>Folders</span></button></div>
 <div class="addr"><span>Address</span><div class="addrbox"><span class="ic a-ic"></span><span class="a-t"></span></div><button class="gobtn">${ic('go',18)}Go</button></div>
 <div class="exmain"><div class="side"></div><div class="files"></div></div><div class="status"></div>`;
 const q=s=>win.body.querySelector(s),files=q('.files'),side=q('.side');
 const st={win,node,back:[],fwd:[],sel:null};
 st.go=n=>{if(n!==st.node){st.back.push(st.node);st.fwd=[]}st.node=n;st.sel=null;st.render()};
 st.markSel=()=>$$('.fitem',files).forEach(el=>el.classList.toggle('sel',el._node===st.sel));
 q('.b-back').onclick=()=>{if(st.back.length){st.fwd.push(st.node);st.node=st.back.pop();st.render()}};
 q('.b-fwd').onclick=()=>{if(st.fwd.length){st.back.push(st.node);st.node=st.fwd.pop();st.render()}};
 q('.b-up').onclick=()=>{const p=upOf(st.node);if(p)st.go(p)};
 q('.b-search').onclick=()=>msgBox('Search Companion','Search is not available right now.','info');
 files.addEventListener('click',e=>{if(e.target===files){st.sel=null;st.markSel()}});
 files._ctx=()=>{const n=st.node;if(n.type==='recycle')return[{label:'Empty Recycle Bin',disabled:!RECYCLE.children.length,action:emptyBin},{label:'Restore all items',disabled:!RECYCLE.children.length,action:restoreAll},'-',{label:'Refresh',action:st.render}];
  return[{label:'Refresh',action:st.render},'-',{label:'New Folder',disabled:n.type==='root'||n.type==='cd',action:()=>newFolder(n)},'-',{label:'Properties',action:()=>propsNode(n)}]};
 st.render=()=>{
  const n=st.node;win.setTitle(n.name);win.setIcon(nodeIcon(n));
  q('.a-ic').innerHTML=svg(nodeIcon(n));q('.a-t').textContent=pathOf(n);
  q('.b-back').disabled=!st.back.length;q('.b-fwd').disabled=!st.fwd.length;q('.b-up').disabled=!upOf(n);
  buildSide(st,side);files.innerHTML='';
  const kids=n.type==='recycle'?RECYCLE.children:n.children;
  const grp=t=>{const g=document.createElement('div');g.className='grp';g.textContent=t;files.appendChild(g)};
  if(n.type==='root'){grp('Files Stored on This Computer');if(isAlive(DOCS))files.appendChild(fileItem(DOCS,st,"User's Documents"));grp('Hard Disk Drives');kids.filter(k=>k.type==='drive').forEach(k=>files.appendChild(fileItem(k,st)));grp('Devices with Removable Storage');kids.filter(k=>k.type==='cd').forEach(k=>files.appendChild(fileItem(k,st)))}
  else if(!kids.length)files.innerHTML=n.type==='cd'?'<div class="empty">Please insert a disk into drive D:.</div>':'<div class="empty">This folder is empty.</div>';
  else [...kids].sort((a,b)=>(CONTAINERS.includes(b.type)-CONTAINERS.includes(a.type))||a.name.localeCompare(b.name)).forEach(k=>files.appendChild(fileItem(k,st)));
  q('.status').textContent=`${kids.length} object(s)`+(n.type==='drive'?'   Free Space: 14.6 GB':'');
 };
 win.onClose=()=>EXPLORERS.delete(st);EXPLORERS.add(st);st.render();return st;
}
function fileItem(k,st,label){
 const el=document.createElement('div');el.className='fitem';el._node=k;
 el.innerHTML=`${ic(nodeIcon(k),40)}<div class="meta"><div class="fn"></div><small class="s1"></small><small class="s2"></small></div>`;
 el.querySelector('.fn').textContent=label||k.name;
 let s1='',s2='';
 if(k.parent===RECYCLE){s1='From: '+pathOf(k.origParent);s2='Deleted: '+fmt(k.deletedAt)}
 else if(k.type==='drive'){s1='Local Disk';s2='14.6 GB free of 19.9 GB'}
 else if(k.type==='cd'){s1='CD Drive'}
 else if(k.type==='folder'){s1='File Folder'}
 else{s1=TYPE[k.type]+(k.size?' · '+k.size:'');s2='Modified: '+fmt(k.date)}
 el.querySelector('.s1').textContent=s1;el.querySelector('.s2').textContent=s2;
 el.addEventListener('click',()=>{st.sel=k;st.markSel()});
 onDbl(el,()=>openNode(k,st));
 el._ctx=()=>{st.sel=k;st.markSel();return nodeMenu(k,st)};
 return el;
}
function sbox(title,links){const b=document.createElement('div');b.className='sbox';b.innerHTML=`<h4></h4><div></div>`;b.firstChild.textContent=title;
 links.forEach(l=>{if(typeof l==='string'){const p=document.createElement('p');p.textContent=l;b.lastChild.appendChild(p);return}
  const a=document.createElement('a');a.innerHTML=ic(l[0],16)+'<span></span>';a.lastChild.textContent=l[1];a.onclick=l[2];b.lastChild.appendChild(a)});return b}
function buildSide(st,side){
 const n=st.node;side.innerHTML='';
 if(n.type==='root')side.appendChild(sbox('System Tasks',[['info','View system information',()=>launch('sysprops')],['addrem','Add or remove programs',()=>openAddRemove()],['control','Change a setting',()=>launch('control')]]));
 else if(n.type==='recycle')side.appendChild(sbox('Recycle Bin Tasks',[['binE','Empty the Recycle Bin',emptyBin],['back','Restore all items',restoreAll]]));
 else side.appendChild(sbox('File and Folder Tasks',[['folder','Make a new folder',()=>newFolder(n)],['binF','Delete selected item',()=>st.sel&&deleteNode(st.sel)]]));
 const other=[];if(n.type!=='root')other.push(['pc','My Computer',()=>st.go(FS)]);if(n!==DOCS&&isAlive(DOCS))other.push(['docs','My Documents',()=>st.go(DOCS)]);if(n.type!=='recycle')other.push(['binE','Recycle Bin',()=>st.go(RECYCLE)]);other.push(['control','Control Panel',()=>launch('control')]);
 side.appendChild(sbox('Other Places',other));
 side.appendChild(sbox('Details',[n.name,TYPE[n.type]||'']));
}
function nodeMenu(n,st){
 if(n.parent===RECYCLE)return[{label:'Restore',bold:1,action:()=>restoreNode(n)},'-',{label:'Delete',action:()=>deleteNode(n)},'-',{label:'Properties',action:()=>propsNode(n)}];
 const canDel=!['drive','cd','root'].includes(n.type);
 return[{label:`Open "${n.name}"`,bold:1,action:()=>openNode(n,st)},{label:'Delete',disabled:!canDel,action:()=>deleteNode(n)},'-',{label:'Properties',action:()=>propsNode(n)}];
}
function openNode(n,st){
 if(n.parent===RECYCLE){propsNode(n);return}
 if(CONTAINERS.includes(n.type)){if(n.type==='cd'&&!st){msgBox('D:\\','Please insert a disk into drive D:.','info');return}return st?st.go(n):openExplorer(n)}
 if(n.type==='memz')return runMemzPrompt();
 if(n.type==='txt')return openNotepad(n);
 if(n.type==='exe'&&n.app)return launch(n.app);
 msgBox(n.name,`Windows cannot open this file:\n\nFile: ${n.name}\n\nThis is a protected system file.`,'warn');
}
function newFolder(p){if(!p.children||p.type==='root')return;add(p,mk(uniqueName(p,'New Folder'),'folder',{date:new Date()}));refreshAll()}
async function deleteNode(n,opts={}){
 if(n.parent===RECYCLE){if(await confirmBox(`Are you sure you want to permanently delete '${n.name}'?`)){detach(n);refreshAll()}return}
 if(n.type==='memz'&&memz.running){msgBox('Error Deleting File or Folder',`Cannot delete ${n.name}: It is being used by another person or program.\n\nClose any programs that might be using the file and try again.`,'error');return}
 if(!opts.noConfirm&&!await confirmBox(`Are you sure you want to send '${n.name}' to the Recycle Bin?`))return;
 if(n.critical||(n.children&&hasCritical(n))){deleteSystem(n);return}
 const p=n.parent;detach(n);if(opts.permanent){refreshAll();return}
 n.origParent=p;n.parent=RECYCLE;n.deletedAt=new Date();RECYCLE.children.push(n);refreshAll();
}
const hasCritical=n=>(n.children||[]).some(k=>k.critical||hasCritical(k));
function deleteSystem(n){
 const w=createWindow({title:'Deleting...',icon:'binF',w:360,h:'auto',noMin:1,noMax:1,noResize:1});
 w.body.innerHTML=`<div class="dlg"><div class="del-anim">${ic('winfolder',32)}<span class="paper">${svg('txt')}</span>${ic('binF',32)}</div><div class="del-f"></div><div class="pbar"><i></i></div></div>`;
 const files=['ntoskrnl.exe','hal.dll','winlogon.exe','csrss.exe','explorer.exe','kernel32.dll','user32.dll','smss.exe'];let i=0;
 const iv=setInterval(()=>{w.body.querySelector('.del-f').textContent=`${files[i%files.length]}\nFrom '${n.name}' to 'Recycle Bin'`;w.body.querySelector('.pbar i').style.width=Math.min(100,i*7)+'%';if(++i>14){clearInterval(iv);bsod('CRITICAL_PROCESS_DIED',ntldr)}},140);
}
function restoreNode(n){const t=isAlive(n.origParent)?n.origParent:C;const dup=t.children.find(k=>k.name===n.name);if(dup)detach(dup);detach(n);n.parent=t;t.children.push(n);delete n.origParent;refreshAll()}
async function emptyBin(){const c=RECYCLE.children.length;if(!c)return;if(await confirmBox(c===1?`Are you sure you want to delete '${RECYCLE.children[0].name}'?`:`Are you sure you want to delete these ${c} items?`,'Confirm Multiple File Delete')){RECYCLE.children=[];refreshAll()}}
function restoreAll(){[...RECYCLE.children].forEach(restoreNode)}
function refreshAll(){EXPLORERS.forEach(s=>{if(s.node!==RECYCLE&&!isAlive(s.node)){s.node=FS;s.back=[];s.fwd=[]}s.render()});renderDesktop()}
function propsNode(n){
 const w=createWindow({title:n.name+' Properties',icon:nodeIcon(n),w:330,h:'auto',noMin:1,noMax:1,noResize:1});
 const isDrive=n.type==='drive';
 const rows=[['Type:',TYPE[n.type]||'File'],['Location:',n.parent===RECYCLE?pathOf(n.origParent):pathOf(n.parent||n)],['Size:',n.size||(n.children?n.children.length+' item(s)':'0 bytes')],['Modified:',fmt(n.date||OLD)]];
 w.body.innerHTML=`<div class="dlg"><div class="dlg-row">${ic(nodeIcon(n),32)}<b class="pn"></b></div><div class="field"></div>${isDrive?'<div class="pie" style="background:conic-gradient(#2a5bc0 0 27%,#d648c8 27% 100%)"></div><div style="text-align:center">Used: 5.3 GB · Free: 14.6 GB</div>':''}<div class="dlg-btns"><button class="xbtn">OK</button></div></div>`;
 w.body.querySelector('.pn').textContent=n.name;
 const f=w.body.querySelector('.field');rows.forEach(([a,b])=>{const x=document.createElement('span');x.textContent=a;const y=document.createElement('span');y.textContent=b;f.append(x,y)});
 w.body.querySelector('.xbtn').onclick=()=>w.close();
}

/* ---------- desktop ---------- */
const DESK_ITEMS=[
 {name:'My Documents',icon:()=>'docs',app:'mydocs'},
 {name:'My Computer',icon:()=>'pc',app:'mycomputer',props:'sysprops'},
 {name:'Recycle Bin',icon:()=>RECYCLE.children.length?'binF':'binE',app:'recycle',bin:1},
 {name:'Internet Explorer',icon:()=>'ie',app:'iexplore'},
 {name:'Minesweeper',icon:()=>'mine',app:'winmine'},
 {name:'Download',icon:()=>'download',app:'download'}
];
function renderDesktop(){
 iconsEl.innerHTML='';
 DESK_ITEMS.forEach(d=>{const el=document.createElement('div');el.className='dicon';el.innerHTML=`${ic(d.icon(),34)}<span class="l"></span>`;el.querySelector('.l').textContent=d.name;
  el.addEventListener('click',()=>{$$('.dicon',iconsEl).forEach(x=>x.classList.remove('sel'));el.classList.add('sel')});
  onDbl(el,()=>launch(d.app));
  el._ctx=()=>{el.click();const m=[{label:'Open',bold:1,action:()=>launch(d.app)}];if(d.bin)m.push({label:'Empty Recycle Bin',disabled:!RECYCLE.children.length,action:emptyBin});m.push('-',{label:'Properties',action:()=>d.props?launch(d.props):d.bin?propsNode(RECYCLE):msgBox(d.name+' Properties',`${d.name}\nType: Shortcut`,'info')});return m};
  iconsEl.appendChild(el)});
}
iconsEl.addEventListener('click',e=>{if(e.target===iconsEl)$$('.dicon',iconsEl).forEach(x=>x.classList.remove('sel'))});
iconsEl._ctx=()=>[{label:'Arrange Icons By',disabled:1},{label:'Refresh',action:renderDesktop},'-',{label:'Paste',disabled:1},'-',{label:'Properties',action:()=>launch('display')}];
taskbar._ctx=()=>[{label:'Task Manager',action:()=>launch('taskmgr')},{label:'Show the Desktop',action:showDesktop},'-',{label:'Lock the Computer (Win+L)',action:lock}];
[iconsEl,desk,tasksEl].forEach(el=>onDbl(el,()=>toggleKb(),e=>e.target===el));
onDbl(loginEl,()=>toggleKb(),e=>!e.target.closest('.user-tile,.lg-off'));
function killShell(){shell=false;taskbar.classList.add('hidden');iconsEl.classList.add('hidden');toggleStart(false);[...EXPLORERS].forEach(s=>s.win.close())}
function restoreShell(){shell=true;killed.delete('explorer.exe');taskbar.classList.remove('hidden');iconsEl.classList.remove('hidden')}
function setWallpaper(c){desk.className='screen '+c;wallpaper=c}
let wallpaper='wp-bliss';

/* ---------- start menu ---------- */
const SM_LEFT=[['ie','Internet','Internet Explorer','iexplore'],['download','Download','memz.exe download','download'],'-',['notepad','Notepad','','notepad'],['calc','Calculator','','calc'],['paint','Paint','','mspaint'],['cmd','Command Prompt','','cmd'],['mine','Minesweeper','','winmine']];
const SM_RIGHT=[['docs','My Documents','mydocs'],['pc','My Computer','mycomputer'],['binE','Recycle Bin','recycle'],'-',['control','Control Panel','control'],['taskmgr','Task Manager','taskmgr'],'-',['help','Help and Support','help'],['run','Run...','run']];
const SM_ALL=[['ie','Internet Explorer','iexplore'],['download','Download','download'],['calc','Calculator','calc'],['cmd','Command Prompt','cmd'],['notepad','Notepad','notepad'],['paint','Paint','mspaint'],['mine','Minesweeper','winmine'],['taskmgr','Task Manager','taskmgr'],['control','Control Panel','control'],['pc','Windows Explorer','mycomputer'],['run','Run...','run']];
function smItem(icon,label,sub,app){const d=document.createElement('div');d.className='smi';d.innerHTML=`${ic(icon,24)}<span><b></b>${sub?'<small></small>':''}</span>`;d.querySelector('b').textContent=label;if(sub)d.querySelector('small').textContent=sub;d.onclick=()=>{toggleStart(false);launch(app)};return d}
function sep(){const s=document.createElement('div');s.className='sm-sep';return s}
function buildStart(){
 startEl.innerHTML=`<div class="sm-top"><span class="sm-av">${svg('user')}</span><b>User</b></div><div class="sm-mid"><div class="sm-left"></div><div class="sm-right"></div></div><div class="sm-bot"><button class="sb-log">${ic('logoff',22)}Log Off</button><button class="sb-off">${ic('power',22)}Turn Off Computer</button></div>`;
 const R=$('.sm-right',startEl);SM_RIGHT.forEach(i=>{if(i==='-')return R.appendChild(sep());const d=smItem(i[0],i[1],'',i[2]);d.querySelector('.ic').style.cssText='width:20px;height:20px';R.appendChild(d)});
 $('.sb-log',startEl).onclick=()=>{toggleStart(false);logOffDialog()};
 $('.sb-off',startEl).onclick=()=>{toggleStart(false);showShutdown()};
}
function renderLeft(all){
 const L=$('.sm-left',startEl);L.innerHTML='';
 if(all){const b=smItem('back','Back','',null);b.onclick=e=>{e.stopPropagation();renderLeft(false)};L.appendChild(b);L.appendChild(sep());SM_ALL.forEach(i=>L.appendChild(smItem(i[0],i[1],'',i[2])));return}
 SM_LEFT.forEach(i=>{if(i==='-')return L.appendChild(sep());L.appendChild(smItem(...i))});
 L.appendChild(sep());const a=document.createElement('div');a.className='smi sm-all';a.innerHTML=`All Programs ${ic('fwd',18)}`;a.onclick=e=>{e.stopPropagation();renderLeft(true)};L.appendChild(a);
}
function toggleStart(force){
 const open=force!==undefined?force:startEl.classList.contains('hidden');
 if(open&&(STATE!=='desktop'||!shell))return;
 startEl.classList.toggle('hidden',!open);$('#startbtn').classList.toggle('on',open);if(open)renderLeft(false);
}
$('#startbtn').onclick=()=>toggleStart();
$('#startbtn').innerHTML=`${ic('flag',20)}start`;
$('#tray').innerHTML=`<span class="ic t-kb" title="Keyboard">${svg('kbd')}</span><span class="ic">${svg('net')}</span><span class="ic">${svg('volume')}</span><span id="clock"></span>`;
$('.t-kb').onclick=()=>toggleKb();
function tickClock(){const d=new Date();let h=d.getHours();const ap=h>=12?'PM':'AM';h=h%12||12;$('#clock').textContent=`${h}:${String(d.getMinutes()).padStart(2,'0')} ${ap}`}
setInterval(tickClock,5000);tickClock();

/* ---------- keyboard (virtual + physical) ---------- */
const KB_ROWS=[['Esc','1','2','3','4','5','6','7','8','9','0','-','=','Bksp'],['Tab','q','w','e','r','t','y','u','i','o','p','[',']','\\'],['Caps','a','s','d','f','g','h','j','k','l',';',"'",'Enter'],['Shift','z','x','c','v','b','n','m',',','.','/','Up','Del'],['Ctrl','Win','Alt','Space','Left','Down','Right','F4','Hide']];
const SHIFTMAP={'1':'!','2':'@','3':'#','4':'$','5':'%','6':'^','7':'&','8':'*','9':'(','0':')','-':'_','=':'+','[':'{',']':'}','\\':'|',';':':',"'":'"',',':'<','.':'>','/':'?'};
const LABEL={Bksp:'⌫',Up:'↑',Down:'↓',Left:'←',Right:'→',Space:' ',Win:'⊞ Win',Enter:'Enter ↵'};
const WIDE={Space:5,Enter:1.8,Shift:1.6,Bksp:1.5,Caps:1.6,Tab:1.3,Ctrl:1.3,Win:1.4,Alt:1.2,Hide:1.3};
const mods={Shift:false,Ctrl:false,Alt:false,Win:false};let caps=false,lastEditable=null;
KB_ROWS.forEach(r=>{const row=document.createElement('div');row.className='kr';r.forEach(k=>{const b=document.createElement('div');b.className='k';b.dataset.k=k;b.style.flex=WIDE[k]||1;b.textContent=LABEL[k]||k;
 b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();b.classList.add('pr');setTimeout(()=>b.classList.remove('pr'),120);vkPress(k)});row.appendChild(b)});kbEl.appendChild(row)});
function refreshKb(){$$('.k',kbEl).forEach(b=>{const k=b.dataset.k;if(mods[k]!==undefined)b.classList.toggle('on',mods[k]);if(k==='Caps')b.classList.toggle('on',caps);if(k.length===1&&/[a-z]/.test(k))b.textContent=(caps!==mods.Shift)?k.toUpperCase():k})}
function toggleKb(force){const show=force!==undefined?force:kbEl.classList.contains('hidden');kbEl.classList.toggle('hidden',!show)}
const editable=el=>el&&(el.tagName==='TEXTAREA'||(el.tagName==='INPUT'&&!el.readOnly));
document.addEventListener('focusin',e=>{if(editable(e.target)){lastEditable=e.target;if(lastPT!=='mouse')toggleKb(true)}});
function target(){const a=document.activeElement;if(editable(a))return a;if(lastEditable&&lastEditable.isConnected){lastEditable.focus({preventScroll:true});return lastEditable}return null}
function insert(el,ch){const s=el.selectionStart??el.value.length,e=el.selectionEnd??s;el.setRangeText(ch,s,e,'end');el.dispatchEvent(new Event('input',{bubbles:true}))}
function vkPress(k){
 if(k==='Hide')return toggleKb(false);
 if(k==='Win'){if(mods.Win){mods.Win=false;toggleStart(false)}else{mods.Win=true;toggleStart(true)}return refreshKb()}
 if(mods[k]!==undefined){mods[k]=!mods[k];return refreshKb()}
 if(k==='Caps'){caps=!caps;return refreshKb()}
 const name=k.length===1?k:({Bksp:'Backspace',Del:'Delete',Esc:'Escape',Up:'ArrowUp',Down:'ArrowDown',Left:'ArrowLeft',Right:'ArrowRight',Space:' '})[k]||k;
 if(mods.Win||mods.Ctrl||mods.Alt){if(mods.Win)toggleStart(false);const done=handleCombo({win:mods.Win,ctrl:mods.Ctrl,alt:mods.Alt,shift:mods.Shift},name);clearMods();if(done)return}
 if(name==='Escape'){hideMenu();toggleStart(false);clearMods();return}
 const el=target();
 if(el){
  if(name==='Backspace'){const s=el.selectionStart,e=el.selectionEnd;if(s===e&&s>0)el.setRangeText('',s-1,s,'end');else el.setRangeText('',s,e,'end');el.dispatchEvent(new Event('input',{bubbles:true}))}
  else if(name==='Delete'){const s=el.selectionStart,e=el.selectionEnd;el.setRangeText('',s,s===e?s+1:e,'end')}
  else if(name==='Enter'){if(el.tagName==='TEXTAREA')insert(el,'\n');else el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}))}
  else if(name==='Tab'){if(el.tagName==='TEXTAREA')insert(el,'\t')}
  else if(name==='ArrowLeft'||name==='ArrowRight'){const p=clamp(el.selectionStart+(name==='ArrowLeft'?-1:1),0,el.value.length);el.setSelectionRange(p,p)}
  else if(name==='ArrowUp'||name==='ArrowDown'){el.dispatchEvent(new KeyboardEvent('keydown',{key:name,bubbles:true}))}
  else if(name==='F4'){}
  else{let ch=name;if(mods.Shift&&SHIFTMAP[ch])ch=SHIFTMAP[ch];else if(/[a-z]/.test(ch)&&(caps!==mods.Shift))ch=ch.toUpperCase();insert(el,ch)}
 }
 clearMods();
}
function clearMods(){mods.Shift=mods.Ctrl=mods.Alt=mods.Win=false;refreshKb()}
function handleCombo(m,k){
 if(STATE!=='desktop')return false;k=k.toLowerCase();
 if(m.win){if(k==='l'){lock();return true}if(k==='e'){launch('mycomputer');return true}if(k==='r'){launch('run');return true}if(k==='d'||k==='m'){showDesktop();return true}}
 if(m.ctrl&&m.alt&&(k==='delete'||k==='del')){launch('taskmgr');return true}
 if(m.ctrl&&m.alt&&k==='l'){lock();return true}
 if(m.ctrl&&m.shift&&k==='escape'){launch('taskmgr');return true}
 if(m.alt&&k==='f4'){if(activeWin)activeWin.close();else showShutdown();return true}
 return false;
}
let metaCombo=false;
addEventListener('keydown',e=>{
 if(e.key==='Meta'||e.key==='OS'){metaCombo=false;return}
 const k=e.key;
 if(e.metaKey){metaCombo=true;if(handleCombo({win:1},k))e.preventDefault();return}
 if((e.ctrlKey&&e.altKey)||(e.ctrlKey&&e.shiftKey&&k==='Escape')||(e.altKey&&k==='F4')){if(handleCombo({ctrl:e.ctrlKey,alt:e.altKey,shift:e.shiftKey},k))e.preventDefault();return}
 if(k==='Escape'){hideMenu();toggleStart(false)}
});
addEventListener('keyup',e=>{if((e.key==='Meta'||e.key==='OS')&&!metaCombo)toggleStart()});

/* ---------- screens: boot / login / lock / shutdown ---------- */
function hideScreens(){['#boot','#bsod','#shutdlg'].forEach(s=>$(s).classList.add('hidden'));msgEl.classList.add('hidden');msgEl.innerHTML='';loginEl.classList.add('hidden');os.classList.remove('gray')}
function screen(html){msgEl.onclick=null;msgEl.innerHTML=html;msgEl.classList.remove('hidden');return msgEl}
function boot(){
 const tk=++token;stopMemz();hideScreens();closeAll();toggleStart(false);hideMenu();
 if(memz.infected)return nyan();
 STATE='boot';killed.clear();restoreShell();$('#boot').classList.remove('hidden');busy(true);
 setTimeout(()=>{if(tk!==token)return;$('#boot').classList.add('hidden');busy(false);showLogin(true)},3800);
}
function showLogin(fresh){STATE='login';loginEl.classList.remove('hidden','welcome');loginEl._fresh=fresh}
$('.user-tile',loginEl).onclick=()=>{
 if(STATE!=='login')return;const tk=++token;loginEl.classList.add('welcome');busy(true);if(loginEl._fresh)chime();
 setTimeout(()=>{if(tk!==token)return;busy(false);loginEl.classList.add('hidden');os.classList.remove('hidden');STATE='desktop';renderDesktop()},1300);
};
$('.lg-off',loginEl).onclick=()=>showShutdown();
function lock(){if(STATE!=='desktop')return;toggleStart(false);hideMenu();showLogin(false)}
function showShutdown(){if(!['desktop','login'].includes(STATE))return;toggleStart(false);os.classList.add('gray');$('#shutdlg').classList.remove('hidden');STATE='shutdlg-'+STATE}
function hideShutdown(){os.classList.remove('gray');$('#shutdlg').classList.add('hidden');STATE=STATE.replace('shutdlg-','')}
$('.sd-cancel').onclick=hideShutdown;
$('.sd-stand').onclick=()=>{hideShutdown();toggleKb(false);STATE='standby';screen(`<div class="blk"></div>`).onclick=()=>{msgEl.classList.add('hidden');msgEl.onclick=null;showLogin(false)}};
$('.sd-off').onclick=()=>shutdown(false);
$('.sd-restart').onclick=()=>shutdown(true);
function shutdown(restart){
 hideShutdown();const tk=++token;STATE='shutting';stopMemz();toggleStart(false);busy(true);
 screen(`<div class="shut">${restart?'Windows is restarting...':'Windows is shutting down...'}</div>`);
 setTimeout(()=>{if(tk!==token)return;closeAll();busy(false);loginEl.classList.add('hidden');os.classList.add('hidden');if(restart)boot();else powerOff()},2200);
}
function powerOff(){STATE='off';toggleKb(false);const s=screen(`<div class="blk">${ic('power',56)}<div>Press to turn on the computer</div></div>`);s.onclick=()=>{s.onclick=null;boot()}}
function logOffDialog(){msgBox('Log Off Windows','Are you sure you want to log off?','logoff',['Switch User','Log Off','Cancel']).then(r=>{if(r==='Switch User')lock();if(r==='Log Off'){closeAll();busy(true);STATE='busy';screen('<div class="shut">Logging off...</div>');setTimeout(()=>{busy(false);msgEl.classList.add('hidden');os.classList.add('hidden');showLogin(false)},1500)}})}

/* ---------- BSOD / NTLDR / setup ---------- */
(function(){let q='';for(let i=0;i<441;i++){const x=i%21,y=(i/21)|0,finder=(x<7&&y<7)||(x>13&&y<7)||(x<7&&y>13);let on;if(finder){const fx=x>13?x-14:x,fy=y>13?y-14:y;on=fx===0||fy===0||fx===6||fy===6||(fx>1&&fx<5&&fy>1&&fy<5)}else on=Math.random()<.5;q+=`<i class="${on?'on':''}"></i>`}$('.bs-qr').innerHTML=q})();
function bsod(code,after){
 stopMemz();const tk=++token;STATE='bsod';toggleStart(false);hideMenu();hideScreens();toggleKb(false);
 const b=$('#bsod');b.classList.remove('hidden');$('.code',b).textContent=code;const pc=$('.pct',b);let p=0;pc.textContent='0% complete';cursorEl.classList.add('hidden');
 const iv=setInterval(()=>{if(tk!==token)return clearInterval(iv);p=Math.min(100,p+1+Math.floor(Math.random()*11));pc.textContent=p+'% complete';
  if(p>=100){clearInterval(iv);setTimeout(()=>{if(tk!==token)return;b.classList.add('hidden');cursorEl.classList.remove('hidden');closeAll();os.classList.add('hidden');(after||boot)()},900)}},380);
}
function ntldr(){STATE='ntldr';const s=screen(`<div class="blk" style="align-items:flex-start;justify-content:flex-start;text-align:left"><div>NTLDR is missing<br>Press Ctrl+Alt+Del to restart</div><br><button class="xbtn" style="color:#000">Reinstall Windows XP</button></div>`);$('button',s).onclick=setup}
function setup(){
 const tk=++token;STATE='setup';busy(true);
 const s=screen(`<div class="setup"><header>Windows XP Professional Setup</header><main><div>Please wait while Setup copies files<br>to the Windows installation folders.<br>This might take several minutes to complete.</div><div class="sb"><i></i></div><div class="pc">0%</div></main><footer class="cf">Copying: ntoskrnl.exe</footer></div>`);
 const files=['ntoskrnl.exe','hal.dll','explorer.exe','notepad.exe','winlogon.exe','calc.exe','mspaint.exe','cmd.exe','winmine.exe','bliss.bmp','MEMZ.exe'];let p=0;
 const iv=setInterval(()=>{if(tk!==token)return clearInterval(iv);p=Math.min(100,p+3);$('.sb i',s).style.width=p+'%';$('.pc',s).textContent=p+'%';$('.cf',s).textContent='Copying: '+files[Math.floor(p/10)%files.length];
  if(p>=100){clearInterval(iv);memz.infected=false;buildFS();busy(false);boot()}},90);
}

/* ---------- MEMZ ---------- */
const memz={running:false,infected:false,timers:[],t0:0,reversed:false};
async function runMemzPrompt(){
 if(memz.running)return;
 if(await msgBox('MEMZ',"The software you just executed is considered malware.\nThis malware will harm your computer and makes it unusable.\nIf you are seeing this message without knowing what you just executed, simply press No and nothing will happen.\nIf you know what this malware does and are using a safe environment to test, press Yes to start it.\n\nDO YOU WANT TO EXECUTE THIS MALWARE, RESULTING IN AN UNUSABLE MACHINE?",'warn',['Yes','No'])!=='Yes')return;
 if(await msgBox('MEMZ',"THIS IS THE LAST WARNING!\n\nTHE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGE MADE USING THIS MALWARE!\nSTILL EXECUTE IT?",'warn',['Yes','No'])!=='Yes')return;
 startMemz();
}
function startMemz(){
 memz.running=true;memz.infected=true;memz.t0=Date.now();memz.reversed=false;
 openNotepad(null,"YOUR COMPUTER HAS BEEN TRASHED BY THE MEMZ TROJAN.\n\nYour computer won't boot up again,\nso use it as long as you can!\n\n:D\n\nTrying to kill MEMZ will cause your system to be\ndestroyed instantly, so don't try it :D",'note.txt');
 const icons=['error','warn','info','question'];let stills=0;
 memz.timers.push(setInterval(()=>{
  if(!memz.running||STATE!=='desktop')return;const t=(Date.now()-memz.t0)/1000;
  if(t>4){const d=document.createElement('div');d.className='fxi';d.innerHTML=svg(icons[Math.random()*4|0]);d.style.left=cur.x+'px';d.style.top=cur.y+'px';fx.appendChild(d);if(fx.children.length>250)fx.firstChild.remove()}
  if(t>9&&Math.random()<.16&&stills<14){stills++;const w=createWindow({title:'lol',icon:'question',w:220,h:'auto',noMin:1,noMax:1,noResize:1,noTask:1,x:Math.random()*(RW()-220),y:Math.random()*(RH()-140)});w.body.innerHTML=`<div class="dlg"><div class="dlg-row">${ic('question',32)}<div class="dlg-msg">Still using this computer?</div></div><div class="dlg-btns"><button class="xbtn">OK</button></div></div>`;$('.xbtn',w.body).onclick=()=>{stills--;w.close()};ding()}
  if(t>15&&Math.random()<.1)os.classList.toggle('inv');
  if(t>21)jit={x:(Math.random()-.5)*14,y:(Math.random()-.5)*14},setCursor(cur);
  if(t>26&&!memz.reversed){memz.reversed=true;WINS.forEach(w=>w.setTitle([...w.title].reverse().join('')))}
  if(t>30)winsEl.classList.add('shake');
  if(t>36){os.classList.add('tunnel');if(Math.random()<.3)tone(200+Math.random()*900,.12,0,'square',.025)}
  if(t>65)memzFinal();
 },350));
}
function stopMemz(){memz.timers.forEach(clearInterval);memz.timers=[];memz.running=false;fx.innerHTML='';os.classList.remove('inv','tunnel');winsEl.classList.remove('shake');jit={x:0,y:0}}
function memzFinal(){stopMemz();closeAll();os.classList.add('hidden');nyan()}
function nyan(){
 const tk=++token;STATE='nyan';hideScreens();busy(false);toggleKb(false);
 let stars='';for(let i=0;i<18;i++)stars+=`<i class="star" style="left:${Math.random()*100}%;top:${Math.random()*100}%;animation-delay:-${Math.random()*1.2}s;animation-duration:${1+Math.random()}s"></i>`;
 const cols=['#ff0000','#ff9900','#ffff00','#33ff00','#0099ff','#6633ff'].map(c=>`<i style="--c:${c}"></i>`).join('');
 const s=screen(`<div class="nyan-scr">${stars}<div class="nyan"><div class="rb">${cols}</div><div class="cat"></div><div class="head"></div></div><p>Your computer has been trashed by the MEMZ trojan.<br>Now enjoy the Nyan Cat...</p><button class="xbtn" style="color:#000">Reinstall Windows XP</button></div>`);
 const notes=[659,740,554,587,554,523,494,523,554,587,659,740,587,659,554,494];let n=0;
 const iv=setInterval(()=>{if(tk!==token||STATE!=='nyan')return clearInterval(iv);tone(notes[n++%notes.length],.16,0,'square',.02)},190);
 $('button',s).onclick=()=>{clearInterval(iv);setup()};
}
