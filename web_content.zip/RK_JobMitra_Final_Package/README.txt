RK JOBMITRA – FINAL SOURCE PACKAGE

source/index.html
  New RK JobMitra mobile design + existing Firebase functionality.

original/RK_JOB_MITRA_Firebase_Updated.html
  Original Firebase-based source kept as backup.

Important:
  The APK wrapper/build/signing step is separate. This package contains the web source and Firebase functionality; it is not itself an installable APK.
