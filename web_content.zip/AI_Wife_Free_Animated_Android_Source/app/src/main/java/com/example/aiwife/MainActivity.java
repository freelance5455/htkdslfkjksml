package com.example.aiwife;
import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;
public class MainActivity extends Activity {
 WebView web; TextToSpeech tts; static final int REQ=42;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setAllowFileAccess(true); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"Android"); tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("ml","IN"));}); web.loadUrl("file:///android_asset/index.html");}
 class Bridge { @JavascriptInterface public void speak(String s){runOnUiThread(()->{if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"reply");});} @JavascriptInterface public void listen(){runOnUiThread(()->{if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},1);return;} try {Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ml-IN");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);startActivityForResult(i,REQ);}catch(Exception e){web.evaluateJavascript("showError('Speech recognition app unavailable')",null);}});}}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==REQ && result==RESULT_OK && data!=null){ArrayList<String> r=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(r!=null && !r.isEmpty()){String s=org.json.JSONObject.quote(r.get(0));web.evaluateJavascript("heard("+s+")",null);}}}
 @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}web.destroy();super.onDestroy();}
}
