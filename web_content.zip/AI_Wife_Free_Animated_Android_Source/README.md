# AI Wife Free — Android source (prototype)

This is an honest **2D animated demo**, not a realistic live-video avatar, not a video call, and not a generative AI chatbot. The ten uploaded photographs appear only in a selectable reference gallery; the animated character is a generic drawn figure, not a recreation of any pictured person.

## Features
- 10 reference-photo choices
- Simple full-body 2D motions: wave, walk-in-place, dance, idle
- Android TextToSpeech (Malayalam depends on installed voices)
- Android speech recognition (depends on device / recognition service and may use internet)
- Offline scripted Malayalam replies; no paid API keys

## Build
Open this directory in Android Studio (Android Gradle Plugin 8.5.2, JDK 17, Android SDK 35). Build > Build APK(s), or run `gradle assembleDebug` with the Android SDK and Gradle installed. APK output: `app/build/outputs/apk/debug/app-debug.apk`. A compatible build environment and initial dependency downloads are required. This ZIP does NOT contain a compiled APK.

Android phone only: A compatible Android IDE or remote CI builder is needed; Chrome alone cannot compile Android projects. Grant microphone permission for speech recognition.

## Limitations
- Does not offer live video calling, realistic 3D, full-body photo reconstruction, lip sync, or unconstrained AI responses.
- For a realistic interactive video avatar, a licensed real-time rendering/streaming system, rigged avatar, AI dialogue, speech synthesis, and consent for likeness use are required. Those are not included.
