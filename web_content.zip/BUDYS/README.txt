BUDYS — Polished Budy Designs

1. Extract this ZIP on your Android phone.
2. Open the BUDYS folder.
3. Tap BUDYS.html and choose Chrome if asked.

This is a browser-playable HTML game, not an APK. Keep the HTML file in the folder when playing.
