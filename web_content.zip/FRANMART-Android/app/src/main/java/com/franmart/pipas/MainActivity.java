package com.franmart.pipas;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.app.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 100;
    private static final int REQ_CREATE_BACKUP = 101;
    private static final int REQ_OPEN_BACKUP = 102;
    private static final int REQ_BLUETOOTH = 103;
    private String pendingTicketText;
    private WebView webView;
    private String pendingBackup;
    private String pendingSharedLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new FranmartBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (pendingSharedLocation != null) {
                    String value = pendingSharedLocation;
                    pendingSharedLocation = null;
                    view.evaluateJavascript("window.receiveSharedLocation && window.receiveSharedLocation(" + JSONObject.quote(value) + ");", null);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                callback.invoke(origin, granted, false);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        handleSharedIntent(getIntent());

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        }
    }

    private class FranmartBridge {
        @JavascriptInterface
        public void openMaps(String url) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent.setPackage("com.google.android.apps.maps");
                    try { startActivity(intent); }
                    catch (Exception noMaps) {
                        Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(browser);
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir Maps.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openMapPicker(String address) {
            runOnUiThread(() -> {
                try {
                    Uri geo = Uri.parse("geo:0,0?q=" + Uri.encode(address));
                    Intent maps = new Intent(Intent.ACTION_VIEW, geo);
                    maps.setPackage("com.google.android.apps.maps");
                    startActivity(maps);
                } catch (Exception e) {
                    try {
                        Intent fallback = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(address)));
                        startActivity(fallback);
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this, "No se pudo abrir Google Maps.", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(send, "Compartir ubicación del cliente"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir el menú para compartir.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveBackup(String json) {
            runOnUiThread(() -> {
                pendingBackup = json;
                String stamp = new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "FRANMART-respaldo-" + stamp + ".json");
                startActivityForResult(intent, REQ_CREATE_BACKUP);
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, REQ_OPEN_BACKUP);
            });
        }

        @JavascriptInterface
        public void printTicket(String ticketText) {
            runOnUiThread(() -> chooseBluetoothPrinter(ticketText));
        }
    }

    private void chooseBluetoothPrinter(String ticketText) {
        pendingTicketText = ticketText == null ? "" : ticketText;
        if (android.os.Build.VERSION.SDK_INT >= 31
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BLUETOOTH);
            Toast.makeText(this, "Permite Bluetooth para buscar tu impresora vinculada y vuelve a tocar Imprimir.", Toast.LENGTH_LONG).show();
            return;
        }
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            Toast.makeText(this, "Este teléfono no tiene Bluetooth disponible.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!adapter.isEnabled()) {
            Intent enable = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enable);
            Toast.makeText(this, "Activa Bluetooth y vuelve a tocar Imprimir.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Set<BluetoothDevice> paired = adapter.getBondedDevices();
            if (paired == null || paired.isEmpty()) {
                Toast.makeText(this, "Primero vincula tu impresora térmica en Ajustes > Bluetooth del teléfono.", Toast.LENGTH_LONG).show();
                return;
            }
            ArrayList<BluetoothDevice> devices = new ArrayList<>(paired);
            String[] names = new String[devices.size()];
            for (int i = 0; i < devices.size(); i++) {
                BluetoothDevice d = devices.get(i);
                names[i] = (d.getName() == null ? "Impresora Bluetooth" : d.getName()) + "\n" + d.getAddress();
            }
            new AlertDialog.Builder(this).setTitle("Selecciona tu impresora Bluetooth")
                    .setItems(names, (dialog, which) -> sendTicketBluetooth(devices.get(which)))
                    .setNegativeButton("Cancelar", null).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "No hay permiso para acceder a Bluetooth. Revisa los permisos de FRANMART.", Toast.LENGTH_LONG).show();
        }
    }

    private void sendTicketBluetooth(BluetoothDevice device) {
        final String content = pendingTicketText;
        Toast.makeText(this, "Conectando con " + (device.getName() == null ? "impresora" : device.getName()) + "...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                UUID spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
                socket = device.createRfcommSocketToServiceRecord(spp);
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40}); // ESC/POS initialize
                out.write(new byte[]{0x1B, 0x61, 0x01}); // center
                out.write(new byte[]{0x1B, 0x45, 0x01});
                out.write("   _________\n  /  FRAN  /|\n /_______/ |\n |  💧   | /\n |______|/\n".getBytes("UTF-8"));
                out.write("FRANMART\n".getBytes("UTF-8"));
                out.write(new byte[]{0x1B, 0x45, 0x00});
                out.write("PIPAS DE AGUA POTABLE\n".getBytes("UTF-8"));
                out.write("------------------------------------------\n".getBytes("UTF-8"));
                out.write(new byte[]{0x1B, 0x61, 0x00}); // left
                String printable = content.replaceAll("(?i)ABRIR UBICACI[ÓO]N EN MAPS", "")
                        .replaceAll("[\\p{So}\\p{Cn}]", "")
                        .replaceAll("[ \t]+\n", "\n").trim();
                out.write(printable.getBytes("UTF-8"));
                out.write("\n\nGracias por confiar en FRANMART\n\n\n".getBytes("UTF-8"));
                out.write(new byte[]{0x1D, 0x56, 0x00}); // cut where supported
                out.flush();
                runOnUiThread(() -> Toast.makeText(this, "Ticket enviado a la impresora.", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                String msg = e instanceof IOException ? "No se pudo conectar. Verifica que la impresora esté encendida, vinculada y sea compatible con ESC/POS." : "Error al imprimir: " + e.getMessage();
                runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
            } finally {
                if (socket != null) try { socket.close(); } catch (IOException ignored) {}
            }
        }).start();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleSharedIntent(intent);
    }

    private void handleSharedIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        if (!"text/plain".equals(intent.getType())) return;
        String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (shared == null || shared.trim().isEmpty()) return;
        pendingSharedLocation = shared.trim();
        webView.post(() -> {
            if (pendingSharedLocation != null) {
                String value = pendingSharedLocation;
                pendingSharedLocation = null;
                webView.evaluateJavascript("window.receiveSharedLocation && window.receiveSharedLocation(" + JSONObject.quote(value) + ");", null);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BLUETOOTH) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permiso Bluetooth concedido. Toca de nuevo Imprimir para elegir la impresora.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Sin permiso Bluetooth no es posible imprimir directamente.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_CREATE_BACKUP && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                }
                pendingBackup = null;
                Toast.makeText(this, "Respaldo FRANMART guardado.", Toast.LENGTH_LONG).show();
            } else if (requestCode == REQ_OPEN_BACKUP) {
                StringBuilder text = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    byte[] buffer = new byte[4096];
                    int n;
                    while ((n = in.read(buffer)) > 0) text.append(new String(buffer, 0, n, StandardCharsets.UTF_8));
                }
                String js = "window.receiveBackup(" + JSONObject.quote(text.toString()) + ");";
                webView.evaluateJavascript(js, null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo procesar el archivo: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("(function(){if(!document.getElementById('home').classList.contains('hidden')){return;}['home','formPanel','settings','ticketPanel'].forEach(function(id){document.getElementById(id).classList.toggle('hidden',id!=='home');});})()", null);
    }
}
