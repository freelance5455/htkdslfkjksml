ZOMBIE SURVIVAL 3D

Files:
- index.html
- style.css
- script.js

This build is mobile-friendly and uses Three.js r160 from the jsDelivr CDN.
For a truly offline APK, bundle three.min.js locally and change the script tag in index.html to:
<script src="three.min.js"></script>

The supplied game files are ready to upload as a ZIP to an HTML-to-APK builder for testing.
