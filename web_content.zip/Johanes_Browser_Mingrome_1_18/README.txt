JOHANES BROWSER — MINGROME 1.18
=================================

Isi paket:
- index.html            Aplikasi web utama
- mingrome-icon.svg     Ikon khas Johanes Browser
- manifest.webmanifest  Metadata instalasi PWA

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka index.html dengan Chrome atau browser Android.
3. Gunakan kolom pencarian untuk mencari kata kunci atau membuka alamat situs.

Fitur:
- Beranda dan akses cepat
- Pencarian web
- Tautan layanan berita
- Pencarian video YouTube
- Kolom unduh tautan file
- Panel buka situs (iframe; sebagian situs akan menolak ditampilkan)
- Riwayat sesi sederhana yang hanya tersimpan selama halaman terbuka

Batasan penting:
- Ini adalah prototipe browser berbasis HTML, bukan mesin browser seperti Chromium.
- Pencarian, berita, dan video memakai situs web pihak ketiga dan memerlukan internet.
- Situs seperti YouTube, Google, dan banyak situs lain mungkin tidak bisa ditampilkan dalam panel iframe; buka di tab baru.
- Unduhan bergantung pada izin browser, server, dan perangkat. HTML saja tidak dapat menjamin unduhan semua file.
- Manifest PWA biasanya memerlukan hosting HTTPS untuk pemasangan seperti aplikasi. Untuk APK Android native, proyek perlu dibungkus dengan Android WebView atau dibangun memakai Android Studio; ZIP ini bukan APK/APKS.
