# Security and production checklist

- [ ] Use a unique JWT secret with 32+ random bytes.
- [ ] Production HTTPS; set `COOKIE_SECURE=true`.
- [ ] Restrict PostgreSQL to the application network; use a least-privilege database role.
- [ ] Set exact `CLIENT_ORIGIN`; do not use wildcard credentialed CORS.
- [ ] Add CSRF protection appropriate to your deployment. SameSite=Lax helps but is not a complete CSRF strategy.
- [ ] Add email verification and password-reset tokens with short expiry and one-time use.
- [ ] Add audit logs for admin and payment actions.
- [ ] Add pagination, query timeouts, monitoring, backup and restore tests.
- [ ] Keep private file storage outside the web root; scan uploads; enforce MIME/size limits.
- [ ] Never trust client-side role fields; public signup is always STUDENT.
- [ ] Use a real payment provider and verify callbacks server-to-server before marking a payment paid.
- [ ] Review JWT role-change invalidation. For high-security deployments, use opaque sessions or check role from the database on each request.
- [ ] Consider MFA for administrators and a separate admin domain/account policy.
