const areas=[
["🦴","Anatomia","Ossos, músculos, órgãos e sistemas.","anatomyPage"],
["💪","Fisiologia","Como funciona o corpo humano.","contentPage"],
["🫀","Cardiologia","Coração, circulação e ECG.","contentPage"],
["🧠","Neurologia","Cérebro, nervos e exame neurológico.","contentPage"],
["🫁","Pneumologia","Pulmões e respiração.","contentPage"],
["🦠","Microbiologia","Bactérias, vírus, fungos e parasitas.","contentPage"],
["💊","Farmacologia","Medicamentos e uso seguro.","contentPage"],
["🧪","Bioquímica","Moléculas e metabolismo.","contentPage"],
["🩺","Medicina interna","Avaliação clínica e diagnóstico.","contentPage"],
["🧒","Pediatria","Saúde e desenvolvimento infantil.","contentPage"],
["🤰","Obstetrícia e ginecologia","Saúde reprodutiva e materna.","contentPage"],
["🔬","Patologia","Mecanismos e alterações das doenças.","contentPage"],
["🥗","Nutrição","Nutrientes e alimentação.","contentPage"],
["🚑","Urgências","Reconhecer gravidade e primeiros socorros.","contentPage"],
["🩻","Radiologia","Imagem médica e seus princípios.","contentPage"],
["🌍","Saúde pública","Prevenção e epidemiologia.","contentPage"],
["⚖️","Ética médica","Consentimento e confidencialidade.","contentPage"],
["📚","História da Medicina","Da antiguidade à medicina moderna.","historyPage"],
["🎬","Vídeos práticos","Aulas e demonstrações no YouTube.","videosPage"],
["📝","Questionários","Treine com perguntas fáceis e difíceis.","quizPage"]
];
const notes=[
["Anatomia","Planos anatómicos","A posição anatómica de referência facilita descrever estruturas. Os planos principais são sagital, frontal e transversal."],
["Anatomia","Fémur","O fémur é o osso da coxa. A cabeça articula-se com o acetábulo; o corpo transmite cargas e os côndilos participam na articulação do joelho."],
["Fisiologia","Homeostase","É a manutenção dinâmica do meio interno, regulada por mecanismos como feedback negativo."],
["Cardiologia","Ciclo cardíaco","O ciclo cardíaco inclui sístole e diástole. ECG, pressão arterial e auscultação avaliam aspetos diferentes da função cardiovascular."],
["Pneumologia","Trocas gasosas","O oxigénio e o dióxido de carbono difundem-se através da membrana alveolocapilar de acordo com gradientes de pressão parcial."],
["Microbiologia","Prevenção de infeções","Higiene das mãos, vacinação indicada, técnica assética e equipamento de proteção ajudam a reduzir a transmissão."],
["Farmacologia","Segurança dos medicamentos","A utilização segura considera indicação, dose prescrita, alergias, contraindicações e interações. Não altere tratamentos sem orientação profissional."],
["Nutrição","Macronutrientes","Hidratos de carbono, proteínas e lípidos desempenham funções energéticas e estruturais. As necessidades variam de pessoa para pessoa."],
["Saúde pública","Incidência e prevalência","Incidência descreve casos novos num período; prevalência descreve casos existentes numa população num momento ou período."],
["Ética médica","Consentimento informado","A pessoa deve receber informação compreensível sobre opções, riscos, benefícios e alternativas, e decidir voluntariamente."]
];
const history=[
["Antiguidade","Egito, Mesopotâmia, Índia e China","Diferentes civilizações desenvolveram práticas de cura, observações e registos médicos próprios."],
["Séculos V–IV a.C.","Tradição hipocrática","A observação clínica e explicações naturais para as doenças ganharam importância na medicina grega."],
["Séculos II–III","Galeno","Os seus escritos influenciaram a medicina por muitos séculos, embora algumas ideias anatómicas tenham sido corrigidas depois."],
["Séculos VIII–XIII","Centros de estudo do mundo islâmico","Traduções, hospitais e estudiosos como Al-Razi e Ibn Sina preservaram e expandiram conhecimentos médicos."],
["1543","Andreas Vesalius","A obra De humani corporis fabrica marcou uma etapa importante da anatomia baseada em observação."],
["1796","Vacinação contra a varíola","O trabalho de Edward Jenner foi um marco no desenvolvimento da vacinação."],
["Século XIX","Anestesia, higiene e teoria microbiana","Esses avanços transformaram a cirurgia e a prevenção de infeções."],
["Século XX","Antibióticos, vacinas e imagem médica","A medicina ganhou novas ferramentas de prevenção, diagnóstico e tratamento."],
["Século XXI","Genómica, telemedicina e inteligência artificial","Novas tecnologias oferecem oportunidades e exigem validação, privacidade e supervisão humana."]
];
const qs=[
{d:"easy",q:"Qual é o maior osso do corpo humano?",a:["Tíbia","Fémur","Úmero","Rádio"],c:1,e:"O fémur, localizado na coxa, é o maior osso do corpo."},
{d:"easy",q:"Qual órgão bombeia o sangue?",a:["Pulmão","Coração","Rim","Fígado"],c:1,e:"O coração impulsiona o sangue nas circulações pulmonar e sistémica."},
{d:"easy",q:"Qual é a unidade funcional do rim?",a:["Alvéolo","Néfron","Neurónio","Hepatócito"],c:1,e:"O néfron participa na filtração e na formação da urina."},
{d:"easy",q:"Qual célula transporta a maior parte do oxigénio?",a:["Plaqueta","Eritrócito","Linfócito","Monócito"],c:1,e:"A hemoglobina dos eritrócitos transporta a maior parte do oxigénio no sangue."},
{d:"easy",q:"Qual é o principal músculo da inspiração tranquila?",a:["Diafragma","Bíceps","Trapézio","Masséter"],c:0,e:"A contração do diafragma aumenta o volume torácico."},
{d:"easy",q:"Qual exame regista a atividade elétrica cardíaca?",a:["ECG","Endoscopia","Espirometria","Audiometria"],c:0,e:"O eletrocardiograma regista diferenças de potencial relacionadas com a atividade elétrica cardíaca."},
{d:"easy",q:"A incidência epidemiológica refere-se a:",a:["Casos novos num período","Todos os casos antigos","Número de hospitais","Taxa de cura"],c:0,e:"A incidência mede novos casos numa população em risco durante um período."},
{d:"easy",q:"Qual estrutura liga a faringe ao estômago?",a:["Traqueia","Esófago","Uréter","Brônquio"],c:1,e:"O esófago conduz o alimento até ao estômago."},
{d:"hard",q:"pH 7,28, PaCO₂ 60 mmHg e HCO₃⁻ 26 mmol/L sugerem principalmente:",a:["Alcalose respiratória","Acidose respiratória","Acidose metabólica","Alcalose metabólica"],c:1,e:"Há acidemia e PaCO₂ elevada, padrão compatível com acidose respiratória; correlacione com o quadro clínico."},
{d:"hard",q:"A pré-carga ventricular relaciona-se sobretudo com:",a:["Resistência arterial após ejeção","Enchimento e estiramento no fim da diástole","Frequência respiratória","Saturação periférica"],c:1,e:"A pré-carga está relacionada com o enchimento ventricular e o estiramento das fibras no fim da diástole."},
{d:"hard",q:"Qual imunoglobulina atravessa a placenta em quantidade clinicamente relevante?",a:["IgA","IgE","IgG","IgM"],c:2,e:"A IgG materna atravessa a placenta e fornece imunidade passiva ao recém-nascido."},
{d:"hard",q:"Qual princípio ético significa evitar dano desnecessário?",a:["Autonomia","Não maleficência","Publicidade","Competição"],c:1,e:"A não maleficência orienta a evitar dano e ponderar riscos e benefícios."}
];
function openScreen(id){document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===id));document.querySelectorAll(".navitem").forEach(b=>b.classList.toggle("selected",b.dataset.open===id));if(id==="contentPage")renderNotes();window.scrollTo(0,0)}
document.querySelectorAll("[data-open]").forEach(b=>b.addEventListener("click",()=>openScreen(b.dataset.open)));
document.querySelector("#backBtn").onclick=()=>openScreen("homePage");
function renderAreas(filter=""){let grid=document.querySelector("#areaGrid");grid.innerHTML="";areas.filter(a=>a.slice(1,3).join(" ").toLowerCase().includes(filter.toLowerCase())).forEach(a=>{let b=document.createElement("button");b.className="area-card";b.innerHTML=`<span>${a[0]}</span><b>${a[1]}</b><small>${a[2]}</small>`;b.onclick=()=>{if(a[3]==="contentPage"){document.querySelector("#contentHeading").textContent=a[1];renderNotes(a[1]);openScreen("contentPage")}else openScreen(a[3])};grid.appendChild(b)})}
document.querySelector("#categoryStrip").innerHTML=[["🦴","Ossos","anatomyPage"],["💪","Músculos","anatomyPage"],["⚙","Articulações","anatomyPage"],["🧠","Sistema Nervoso","contentPage"],["胃","Sistema Digestivo","contentPage"]].map((a,i)=>`<button class="category ${i===0?"active":""}" data-target="${a[2]}"><span>${a[0]}</span>${a[1]}</button>`).join("");
document.querySelectorAll(".category").forEach(b=>b.onclick=()=>{document.querySelectorAll(".category").forEach(c=>c.classList.remove("active"));b.classList.add("active");openScreen(b.dataset.target)});
function renderNotes(filter=""){const box=document.querySelector("#contentCards");box.innerHTML="";let list=notes.filter(n=>(!filter||n[0].toLowerCase()===filter.toLowerCase()||n.join(" ").toLowerCase().includes(filter.toLowerCase())));if(!list.length)list=notes;list.forEach(n=>box.innerHTML+=`<article class="lesson-card"><h3>${n[1]}</h3><p>${n[2]}</p><small>${n[0]}</small></article>`)}
document.querySelector("#searchBtn").onclick=()=>renderAreas(document.querySelector("#searchInput").value);document.querySelector("#searchInput").addEventListener("keydown",e=>{if(e.key==="Enter")renderAreas(e.target.value)});
document.querySelector("#historyTimeline").innerHTML=history.map(h=>`<article class="era"><h3>${h[0]} — ${h[1]}</h3><p>${h[2]}</p></article>`).join("");
let cards=[["Qual é o maior osso do corpo humano?","O fémur, na coxa."],["Com que osso a cabeça do fémur se articula?","Com o acetábulo do osso da anca."],["Quais são os planos anatómicos principais?","Sagital, frontal e transversal."],["Qual é a unidade funcional do rim?","O néfron."]],ci=0,revealed=false;
function showCard(){document.querySelector("#flashcard").innerHTML=revealed?cards[ci][1]+"<small>Toque para ver a pergunta</small>":cards[ci][0]+"<small>Toque para revelar</small>"}document.querySelector("#flashcard").onclick=()=>{revealed=!revealed;showCard()};document.querySelector("#nextCard").onclick=()=>{ci=(ci+1)%cards.length;revealed=false;showCard()};document.querySelector("#prevCard").onclick=()=>{ci=(ci+cards.length-1)%cards.length;revealed=false;showCard()};
document.querySelector("#videoTopics").innerHTML=["Exame físico","Auscultação cardíaca","ECG","Anatomia humana","Sutura em simulador","RCP e primeiros socorros","Exame neurológico","Ecografia","História da medicina"].map(t=>`<button class="topic">${t}</button>`).join("");
function videos(q){q=q||"aulas práticas de medicina";document.querySelector("#videoOutput").innerHTML=`<article class="video-result"><b>Resultados para: ${q.replace(/[&<>]/g,"")}</b><p>Veja aulas e demonstrações relacionadas no YouTube.</p><a target="_blank" rel="noopener" href="https://www.youtube.com/results?search_query=${encodeURIComponent(q)}">Abrir vídeos no YouTube ↗</a></article>`}
document.querySelector("#videoBtn").onclick=()=>videos(document.querySelector("#videoInput").value);document.querySelector("#videoTopics").querySelectorAll("button").forEach(b=>b.onclick=()=>{document.querySelector("#videoInput").value=b.textContent;videos(b.textContent)});videos("");
let quiz=[],qi=0,score=0,done=false;
document.querySelector("#beginQuiz").onclick=()=>{let level=document.querySelector("#level").value;quiz=qs.filter(q=>level==="all"||q.d===level).sort(()=>Math.random()-.5);qi=0;score=0;showQuestion()};
function showQuestion(){let box=document.querySelector("#quizBox");done=false;if(qi>=quiz.length){box.innerHTML=`<h3>Questionário concluído!</h3><p>Resultado: ${score} de ${quiz.length}</p><button class="primary" onclick="document.querySelector('#beginQuiz').click()">Tentar novamente</button>`;return}let q=quiz[qi];box.innerHTML=`<small>Pergunta ${qi+1}/${quiz.length} • ${q.d==="hard"?"Difícil":"Fácil"}</small><h3>${q.q}</h3>${q.a.map((a,i)=>`<button class="answer" data-i="${i}">${String.fromCharCode(65+i)}. ${a}</button>`).join("")}<div id="explain"></div>`;box.querySelectorAll(".answer").forEach(b=>b.onclick=()=>{if(done)return;done=true;let i=+b.dataset.i;box.querySelectorAll(".answer").forEach((x,j)=>{x.disabled=true;if(j===q.c)x.classList.add("correct");if(j===i&&i!==q.c)x.classList.add("wrong")});if(i===q.c)score++;document.querySelector("#explain").innerHTML=`<p><b>${i===q.c?"Correto!":"Resposta incorreta."}</b> ${q.e}</p><button class="primary" id="nextQ">${qi===quiz.length-1?"Ver resultado":"Próxima pergunta"}</button>`;document.querySelector("#nextQ").onclick=()=>{qi++;showQuestion()}})}
document.querySelector("#saveBtn").onclick=()=>alert("A área de favoritos será adicionada numa versão futura.");
renderAreas();renderNotes();showCard();