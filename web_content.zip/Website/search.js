let searchHistory = JSON.parse(localStorage.getItem("writerNovelHistory")) || [];

function openSearchFocus() {
    document.getElementById("overlay").style.display = "block";
    showHistory();
}

function closeSearchFocus() {
    document.getElementById("overlay").style.display = "none";
    document.getElementById("historyBox").style.display = "none";
}

function showHistory() {
    const historyBox = document.getElementById("historyBox");
    const historyList = document.getElementById("historyList");
    historyList.innerHTML = "";

    if (searchHistory.length === 0) {
        historyBox.style.display = "none";
        return;
    }

    searchHistory.forEach(oldWord => {
        const div = document.createElement("div");
        div.className = "history-item";
        div.textContent = oldWord;
        div.onclick = function () {
            document.getElementById("searchInput").value = oldWord;
            runSearch();
        };
        historyList.appendChild(div);
    });

    historyBox.style.display = "block";
}
function clearHistory() {
    searchHistory = []
    localStorage.removeItem("writerNovelHistory");
    document.getElementById("historyList").innerHTML = "";
    document.getElementById("historyBox").style.display = "none";
}

function runSearch() {
    const query = document.getElementById("searchInput").value.trim();
    const cards = document.querySelectorAll(".search-card");
    const notFoundMsg = document.getElementById("notFoundMsg");

    closeSearchFocus();

    if (query === "") {
        cards.forEach(card => card.style.display = "flex");
        notFoundMsg.style.display = "none";
        return;
    }

    if (!searchHistory.includes(query)) {
        searchHistory.unshift(query);
        if (searchHistory.length > 5) searchHistory.pop();
        localStorage.setItem("writerNovelHistory", JSON.stringify(searchHistory));
    }

    const lowerQuery = query.toLowerCase();
    let foundCount = 0;

    cards.forEach(card => {
        const keywords = card.getAttribute("data-keywords").toLowerCase();
        if (keywords.includes(lowerQuery)) {
            card.style.display = "flex";
            foundCount++;
        } else {
            card.style.display = "none";
        }
    });

    if (foundCount === 0) {
        notFoundMsg.style.display = "block";
    } else {
        notFoundMsg.style.display = "none";
    }
}

document.getElementById("searchInput").addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
        runSearch();
    }
});