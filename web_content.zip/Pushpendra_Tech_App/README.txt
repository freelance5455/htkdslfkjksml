PUSHPENDRA TECH APP — Android-friendly PWA demo

WHAT'S INCLUDED
- Mobile-responsive Pushpendra Tech App
- Software Engineering course topics
- Notes and calculator
- PWA manifest, icons, and offline cache support

IMPORTANT
This ZIP is a web app, not an installable Android APK.

OPTION A — QUICK TEST ON YOUR PHONE
1. Extract the ZIP on a computer, or upload the files to a web host.
2. Open index.html in a browser to test the layout and buttons.
   Note: service-worker/offline installation requires HTTPS or localhost.

OPTION B — INSTALL ON ANDROID HOME SCREEN
1. Publish the contents of the Pushpendra_Tech_App folder to an HTTPS website.
2. Open that website in Google Chrome on Android.
3. Tap Chrome's three-dot menu, then “Install app” or “Add to Home screen”.
4. Follow the on-screen prompt.

An APK requires a separate Android build step (for example, Android Studio or a trusted web-to-app wrapper). This ZIP does not contain an APK.

Edit contact information in index.html before publishing publicly.
