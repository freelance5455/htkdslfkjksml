from flask import Flask, render_template, request, jsonify
import random
import string

app = Flask(__name__)

# Simulated Database for this session
user_wallet_address = ""
current_balance = 1.0000

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/send_money', methods=['POST'])
def send_money():
    global current_balance
    
    # Get data from frontend
    data = request.json
    wallet_address = data.get('wallet_address', '')
    amount = float(data.get('amount', 0))
    
    if not wallet_address:
        return jsonify({"status": "error", "message": "Please insert your wallet address."}), 400
        
    if amount <= 0:
        return jsonify({"status": "error", "message": "Invalid amount."}), 400

    # Simulate Blockchain Processing
    # In a real scenario, you might check a blockchain API here.
    # Here we simulate success with a delay or instant processing.
    
    new_tx_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
    current_balance += amount
    
    # Return success response
    return jsonify({
        "status": "success",
        "tx_id": new_tx_id,
        "new_balance": f"{current_balance:.4f} btc",
        "message": f"Successfully added {amount} BTC to {wallet_address[:8]}..."
    })

if __name__ == '__main__':
    # Run on 0.0.0.0 so your Android device can access it via your local IP
    app.run(host='0.0.0.0', port=5000, debug=True)