# Tic Tac Toe Pro — Android source project

यह एक original, offline-friendly Tic Tac Toe game है: 2-player mode, computer mode (Easy/Medium/Hard), Minimax hard mode, score tracking, native Android banner ad और rewarded-interstitial ad bridge.

## Build APK (मोबाइल से)
1. इस ZIP को GitHub पर एक नए repository में upload करें और सभी folders/files की directory structure वैसी ही रखें।
2. GitHub repository में **Actions** खोलें। अगर workflow पहली बार है तो workflow enable करें।
3. **Build APK** workflow चुनकर **Run workflow** दबाएँ, या `main` branch में push करें।
4. सफल build के बाद workflow run के नीचे **Artifacts → TicTacToePro-debug-apk** डाउनलोड करें।
5. ZIP artifact को extract करें; `app-debug.apk` Android फोन पर खोलकर install करें। Android पूछे तो केवल अपनी बनाई हुई APK के लिए “Install unknown apps” अनुमति दें।

## AdMob IDs — पहले टेस्ट करें
- Project अभी Google के official **test App ID** और **test ad unit IDs** उपयोग करता है।
- `app/src/main/java/com/example/tictactoepro/MainActivity.kt` में test banner/rewarded IDs हैं।
- अपना वास्तविक App ID `app/build.gradle` के `manifestPlaceholders.admobAppId` में डालें।
- अपना वास्तविक Banner Ad Unit ID `bannerAdUnitId` में और Rewarded Interstitial Ad Unit ID `rewardedInterstitialAdUnitId` में रखें।
- App ID और Ad Unit ID अलग चीजें हैं। App ID का format `ca-app-pub-...~...`; ad unit ID का format `ca-app-pub-.../...` होता है।
- पहले test ads से testing करें। अपने live ads पर खुद क्लिक न करें; invalid traffic से AdMob account पर कार्रवाई हो सकती है।
- आपके बताए Ad Unit IDs को लगाने से पहले अपने AdMob dashboard में पुष्टि करें कि दूसरा ID वास्तव में **Rewarded Interstitial** format/type का है। Code अभी Rewarded Interstitial API इस्तेमाल करता है।

## Important
- Package/application ID: `com.example.tictactoepro` — Play Store पर publish करने से पहले अपना unique package name तय करें; प्रकाशित ऐप का package name बदलना सीधे update के लिए संभव नहीं होता।
- यह debug APK है, signed release APK/AAB नहीं। Play Store submission के लिए release signing, privacy policy, Data safety, ads disclosure/consent requirements और store listing अलग से पूरे करने होंगे।
- Build workflow Gradle 8.7 + JDK 17 + Android Gradle Plugin 8.5.2 के साथ सेट है।


## Banner ID update
The Kotlin Banner Ad Unit ID has been set to:
`ca-app-pub-1496380656721365/7222808419`

**Before expecting live ads:** the project still uses Google's official test App ID in `app/build.gradle` because a complete real AdMob App ID was not supplied. Replace `manifestPlaceholders.admobAppId` with the full App ID from your AdMob console (format `ca-app-pub-...~...`). Keep test IDs during development and use live IDs only after the app and ad units are correctly configured.
