# मेरा AI चैट — मोबाइल से फ्री शुरुआत

## क्या चाहिए?
- Google AI Studio में Gemini API key (free tier और quota उपलब्धता खाते/मॉडल पर निर्भर)
- GitHub account
- Render account

## फाइलें
- `server.js`: API key सर्वर पर रखता है; HTML में key नहीं है।
- `public/index.html`: ChatGPT जैसी साधारण चैट स्क्रीन।
- `package.json`: Node.js dependencies और start command।

## Render पर सर्वर चलाने के कदम
1. GitHub पर नया repository बनाएँ और इस ZIP की सभी फाइलें अपलोड करें। `public/index.html` को `public` फ़ोल्डर के अंदर ही रखें।
2. Render में New > Web Service चुनें और GitHub repository जोड़ें।
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Environment Variables में `GEMINI_API_KEY` नाम से AI Studio की API key जोड़ें।
6. चाहें तो `GEMINI_MODEL` variable में अपने AI Studio account में उपलब्ध model ID डालें। Default `gemini-3.8-flash` है; यदि उपलब्ध न हो तो AI Studio में दिखने वाला free-tier model ID इस्तेमाल करें।
7. Free instance चुनकर deploy करें। Render free services idle रहने पर sleep कर सकती हैं; अगली request धीमी हो सकती है।
8. Render की बनी हुई `https://....onrender.com` URL खोलकर चैट जाँचें।
9. उसी live URL को HTML-to-APK builder में Website URL विकल्प से डालकर APK बनाएँ: https://www.htmltoapp.dev/
10. APK डाउनलोड करके अपने Android फोन में इंस्टॉल करें।

## सुरक्षा और सीमाएँ
- API key केवल Render Environment Variables में रखें। कभी HTML या GitHub repository में न डालें।
- Gemini API free tier के model/rate limits बदल सकते हैं; usage और terms AI Studio में जाँचें।
- Render का free hosting hobby/testing के लिए है और sleep/usage limits हैं।
- APK builder का free tier APK देता है; Google Play publishing के लिए AAB/signing जैसी अलग शर्तें हो सकती हैं।
- यह स्वतंत्र AI चैट ऐप है, OpenAI/ChatGPT का आधिकारिक ऐप नहीं।
