# Hisab Khata Android project

यह सही local WebView project है: HTML को APK के अंदर `assets/index.html` से खोला जाता है, किसी `local.file` URL से नहीं।

**यह ZIP source project है, APK नहीं।** इसे Android Studio/संगत Android build environment में खोलकर `Build > Build APK(s)` करना होगा। इस चैट वातावरण में Android SDK/Gradle build उपलब्ध न होने के कारण मैं सीधे signed APK compile नहीं कर सकता।

App features: Hindi/Marathi, customers, credit/payment entries, balance, search, JSON backup/import, CSV export. Data is stored locally on device/browser storage; no cloud sync or account system. Back up data regularly.
