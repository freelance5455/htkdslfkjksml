# Growth Saller — APKForge Source ZIP

यह ZIP Growth Saller की mobile-friendly web app और Firebase backend source रखती है। ऐप में login/register, services, quantity-based price estimate, order creation, customer order history, admin status updates, UPI QR और payment reference submission के लिए code शामिल है।

## APKForge में क्या चल सकता है
- HTML/CSS/JavaScript app को WebView/website app के रूप में package करना।
- Internet connection के साथ Firebase web SDK इस्तेमाल करना, जब Firebase project/config और backend deploy हो चुके हों।
- ऐप में owner photo और UPI QR दिखाना।

## जो APKForge अकेले नहीं कर सकता
APKForge केवल app package बनाने का tool है; यह अपने-आप cloud database, secure admin account, email delivery या bank payment verification setup नहीं करता। इन features के लिए नीचे का Firebase setup/deployment जरूरी है।

## Firebase setup जरूरी है
1. Firebase Console में project बनाकर Web App जोड़ें।
2. Authentication में Email/Password चालू करें और Firestore database बनाएँ।
3. `public/public-config.js` में Firebase config भरें। इसमें अपना वास्तविक `upiId` और `payeeName` भी डालें।
4. Firestore rules deploy करें: `firebase deploy --only firestore:rules`
5. `functions` folder में dependencies install करें और Cloud Functions deploy करें। Cloud Functions deploy करने के लिए Firebase project में billing/Blaze plan की जरूरत हो सकती है।
6. पहला admin account बनाकर `functions/set-admin.js` को सुरक्षित environment से चलाएँ। Admin SDK/service account key कभी APK या public folder में न रखें।
7. Firestore `services` collection में services बनाएं। Fields: `platform`, `name`, `description`, `pricePer1000`, `minQty`, `maxQty`, `active`। Sample data इस README के अंत में है।
8. Hosting पर `public` folder deploy करें, फिर APKForge में Hosting URL/WebView project use करें।

## Service documents के उदाहरण
- `ig-promo`: `{ "platform":"Instagram", "name":"Instagram Content Promotion", "description":"Content promotion", "pricePer1000":50, "minQty":100, "maxQty":100000, "active":true }`
- `fb-promo`: `{ "platform":"Facebook", "name":"Facebook Content Promotion", "description":"Content promotion", "pricePer1000":60, "minQty":100, "maxQty":100000, "active":true }`
- `yt-promo`: `{ "platform":"YouTube", "name":"YouTube Content Promotion", "description":"Content promotion", "pricePer1000":100, "minQty":100, "maxQty":100000, "active":true }`
- `tt-promo`: `{ "platform":"TikTok", "name":"TikTok Content Promotion", "description":"Where available", "pricePer1000":70, "minQty":100, "maxQty":100000, "active":true }`

Prices above are placeholders. Set your actual prices; current Famegrow.in prices have not been verified. Only offer lawful services that comply with each platform's rules.

## Owner email
- Owner email configured for notification setup: `ranveerjaiswal282@gmail.com`.
- **Email alerts are not active yet.** A trusted email provider/server secret must be configured and deployed before new orders can email the owner. Never put email API keys or Gmail passwords in `public/` or inside the APK.

## Payments, emails and wallet
- The app shows the provided UPI QR and lets a customer submit an order ID + UTR/reference.
- A customer-submitted reference is not proof of payment. Admin must independently check the bank/UPI account before marking an order paid.
- Automatic payment confirmation and automatic wallet credit require a payment provider with verified server-side webhook/API integration; this ZIP does not implement automatic wallet credit.
- Email alerts to `ranveerjaiswal282@gmail.com` are not enabled until a trusted email provider/server function is configured and deployed.
- Do not store customer passwords or ask users for their social media passwords.

## Assets
- `public/owner.png`: owner portrait
- `public/upi-qr.png`: supplied UPI QR image
- `public/index.html`, `public/styles.css`, `public/app.js`, `public/public-config.js`: frontend
- `functions/`: trusted backend functions
- `firestore.rules`: database security rules

This is source code, not a compiled APK. Firebase setup, deployment and device testing are required before real public use.
