# RADHE RADHE — GitHub se APK banane ki hidayat (sirf phone se)

Is project me sab kuch tayyar hai. Aapko bas ise GitHub par rakhkar "Run" dabana hai.
APK banne me lagbhag 10-15 minute lagte hain.

## Kya-kya milega
- Aapki poori app (`index.html`)
- Android ke hisse: Share, folder me backup, contact chunna, aawaz sunana (TTS), mic (voice), fingerprint
- Fixed signing key (`keystore.b64`) — isse naya APK purane ke upar install ho jata hai

## Kadam (phone ke browser me, "Desktop site" chalu karna aasaan rehta hai)
1. github.com par free account banayein aur login karein.
2. **New repository** banayein. Naam: `radhe-radhe`. **Private** chunein (kyunki signing key andar hai).
3. Repository me **Add file > Upload files** dabayein aur in sab files ko chunkar upload karein:
   `index.html`, `android-bridge.js`, `package.json`, `capacitor.config.json`,
   `patch-android.js`, `icon.b64`, `keystore.b64`
   (zip ko pehle phone ki Files app me "Extract" kar lein.)
4. Ab **Add file > Create new file** dabayein. Naam ki jagah likhein:
   `.github/workflows/build.yml`
   (slash likhte hi folder ban jate hain). Neeche box me `.github/workflows/build.yml` file ka poora text paste karein, phir **Commit changes**.
5. Upar **Actions** tab kholein. "Build APK" chunein > **Run workflow** > Run.
6. Hari tick aane par us run ko kholein. Neeche **Artifacts** me `RADHE-RADHE-apk` hoga. Use download karein, zip kholein, `app-debug.apk` install karein.

## Purane app ka data
Naya APK alag app ki tarah banega. Purane app se pehle **JSON Backup aur Photos ka alag Backup** le lein,
phir naye app me Backup Manager se Restore karein.

## Agar kuch galat ho
- Actions me laal (red) cross aaye to us step ka naam aur error ki aakhri 10-15 line copy karke mujhe bhej dein.
- Plugins ke version naye ho sakte hain; aise me mujhe error batayein, main version theek kar dunga.

## Dhyan rakhne ki baatein (imandari se)
- Ye project maine yahan chalakar test nahi kiya (mere paas Android build ke tools nahi hain). Bridge ka JavaScript maine nakli plugins ke saath jaancha hai, par asli phone par pehli baar me kuch cheez theek karni pad sakti hai.
- `Documents/VyaparBackup/` me file likhna kuch phones (Android 11+) par nahi chalta; tab app Share kholta hai, jahan se Drive/Files me save kar sakte hain.
- `keystore.b64` ko kisi ko na dein aur har baar wahi rakhein, warna update purane ke upar install nahi hoga.
