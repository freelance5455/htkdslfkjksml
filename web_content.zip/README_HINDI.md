# Snake Game Pro Max — AdMob Android project

Package/application ID: `com.rktechhub.snakegamepromax`

## Configuration
- Debug APK: Google sample App ID + Google test Banner ID + Google test Rewarded Interstitial ID.
- Release APK/AAB: your supplied production IDs are compiled in. Do not install/test production ads by clicking them; use debug test ads for development.
- App ID is configured only through the manifest placeholder. Ad Unit IDs are separate `BuildConfig` constants.
- SDK dependency: `com.google.android.gms:play-services-ads:25.4.0` (Legacy API chosen because this project uses `AdView` and `RewardedInterstitialAd`). Google currently also documents a Next-Gen SDK; migration is a separate API change.

## Your exact production IDs
- App ID: `ca-app-pub-1496380656721365~3229477100`
- Banner: `ca-app-pub-1496380656721365/7222808419`
- Rewarded Interstitial: `ca-app-pub-1496380656721365/9058634267`

## Build on Android phone using GitHub Actions
1. Create a GitHub repository and upload all files/folders in this project (including `.github/workflows/build-apk.yml`, if present).
2. Open **Actions** → workflow **Build Snake Game Pro Max APK** → **Run workflow**.
3. For testing, run the workflow's default `debug` build (it must build `assembleDebug`). Download its artifact and install `app-debug.apk`.
4. For production, build `assembleRelease` only after privacy/consent and policy checks. Release is unsigned unless you configure signing; do not publish an unsigned APK.
5. Keep keystore and passwords out of source code/repository. Use GitHub Actions secrets if configuring cloud signing.

## Android Studio
Open the project root, allow Gradle sync, then choose Build → Build APK(s). Debug variant always uses test IDs. A release build uses production IDs.

## Notes
- The HTML file bundled in the supplied APK has been preserved as `app/src/main/assets/index.html`.
- Reward is passed to the HTML only after the SDK's `OnUserEarnedRewardListener` fires. The JS bridge cannot directly award coins.
- The provided APK contains this project embedded under its assets; the APK itself has not been rebuilt or device-tested here. This source project ZIP is not an APK.
- Before release, complete Google's consent/privacy requirements for your audience and regions, update the privacy policy and Google Play Data safety disclosures, and verify the current Play target API requirement.
