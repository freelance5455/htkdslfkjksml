import React,{useEffect,useState} from 'react';
import {SafeAreaView,View,Text,TextInput,ScrollView,Pressable,StyleSheet,ActivityIndicator} from 'react-native';
import {StatusBar} from 'expo-status-bar';

// Set this to the computer/server LAN IP when testing on a real phone.
const API_URL='http://10.0.2.2:4000';
export default function App(){
 const [tracks,setTracks]=useState([]),[loading,setLoading]=useState(true),[query,setQuery]=useState(''),[current,setCurrent]=useState(null),[error,setError]=useState('');
 useEffect(()=>{fetch(`${API_URL}/api/tracks`).then(r=>r.json()).then(d=>setTracks(d.tracks||[])).catch(()=>setError('API haipatikani. Anzisha backend na hakikisha API_URL ni sahihi.')).finally(()=>setLoading(false));},[]);
 const visible=tracks.filter(t=>(t.title+' '+t.artist+' '+t.genre).toLowerCase().includes(query.toLowerCase()));
 return <SafeAreaView style={s.safe}><StatusBar style="light"/><ScrollView contentContainerStyle={s.page}>
  <View style={s.brandRow}><View style={s.logo}><Text style={s.logoText}>GS</Text></View><View><Text style={s.brand}>GLOBAL SOUND</Text><Text style={s.tag}>THE FUTURE OF SOUND</Text></View></View>
  <View style={s.hero}><Text style={s.eyebrow}>YOUR SOUND. YOUR UNIVERSE.</Text><Text style={s.head}>Music has no <Text style={s.gradient}>limits.</Text></Text><Text style={s.sub}>Gundua muziki, wasanii na sauti mpya duniani kote.</Text></View>
  <TextInput value={query} onChangeText={setQuery} placeholder="Tafuta nyimbo au wasanii..." placeholderTextColor="#8888aa" style={s.search}/>
  <Text style={s.section}>Trending in your universe</Text>
  {loading?<ActivityIndicator color="#29e7ff"/>:error?<Text style={s.sub}>{error}</Text>:visible.length===0?<Text style={s.sub}>Hakuna nyimbo zilizoidhinishwa bado. Ongeza kupitia Artist Studio API.</Text>:visible.map(t=><Pressable key={t.id} style={s.track} onPress={()=>setCurrent(t)}><View style={s.cover}><Text style={{fontSize:23}}>♫</Text></View><View style={{flex:1}}><Text style={s.trackTitle}>{t.title}</Text><Text style={s.sub}>{t.artist} · {t.genre}</Text></View><Text style={s.play}>▶</Text></Pressable>)}
  <View style={s.notice}><Text style={s.noticeTitle}>Music player</Text><Text style={s.sub}>{current?`Umechagua: ${current.title}.`: 'Chagua wimbo ulioidhinishwa.'}</Text><Text style={s.sub}>Audio streaming ya Android itaunganishwa hapa katika hatua inayofuata.</Text></View>
  <Text style={s.footer}>GLOBAL SOUND · THE FUTURE OF SOUND</Text>
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#070711'},page:{padding:20,paddingBottom:40},
 brandRow:{flexDirection:'row',alignItems:'center',gap:12,marginBottom:28},logo:{width:45,height:45,borderRadius:14,backgroundColor:'#783cff',alignItems:'center',justifyContent:'center'},logoText:{color:'#fff',fontWeight:'900',fontSize:17},brand:{color:'#fff',fontWeight:'900',letterSpacing:2},tag:{color:'#29e7ff',fontSize:9,letterSpacing:2,marginTop:4},
 hero:{padding:22,borderRadius:22,borderWidth:1,borderColor:'#41346f',backgroundColor:'#14132c',marginBottom:22},eyebrow:{color:'#29e7ff',fontSize:10,letterSpacing:2,fontWeight:'800'},head:{fontSize:38,fontWeight:'900',color:'#fff',marginTop:10},gradient:{color:'#c15cff'},sub:{color:'#a6a6c7',fontSize:12,marginTop:5,lineHeight:19},search:{borderWidth:1,borderColor:'#303052',backgroundColor:'#111126',borderRadius:13,padding:14,color:'#fff',marginBottom:24},section:{color:'#fff',fontSize:20,fontWeight:'800',marginBottom:14},track:{flexDirection:'row',alignItems:'center',gap:12,padding:10,backgroundColor:'#111124',borderRadius:14,marginBottom:10,borderWidth:1,borderColor:'#242441'},cover:{width:48,height:48,borderRadius:10,backgroundColor:'#403078',alignItems:'center',justifyContent:'center'},trackTitle:{color:'#fff',fontWeight:'700'},play:{color:'#29e7ff',fontSize:18,paddingHorizontal:8},notice:{marginTop:22,padding:17,borderRadius:16,backgroundColor:'#15142d',borderWidth:1,borderColor:'#38305f'},noticeTitle:{color:'#fff',fontWeight:'800',fontSize:16},footer:{textAlign:'center',color:'#65658a',fontSize:10,letterSpacing:2,marginTop:28}
});
