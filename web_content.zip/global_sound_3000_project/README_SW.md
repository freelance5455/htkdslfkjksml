# GLOBAL SOUND 3000+ — Mradi wa Android-first

Mradi huu umeboreshwa kuwa MVP ya kuunganisha backend, website na Android. **Bado hauko live wala haujathibitishwa kwa production.** Ujenzi wa APK na huduma za nje zinahitaji akaunti/hosting ya mmiliki; hakuna siri za akaunti zilizowekwa ndani ya mradi.

## Kilichopo sasa
- Backend Express + SQLite: health, usajili, login, JWT, `/api/me`.
- Password huhifadhiwa kama bcrypt hash; nenosiri la chini ni herufi 10.
- Orodha ya nyimbo zilizoidhinishwa, streaming ya audio yenye HTTP Range, likes na mapendekezo ya msingi.
- Upload ya msanii yenye uthibitisho wa haki za muziki na idhini ya admin.
- Ombi la kuwa msanii na endpoints za admin kuidhinisha/kukataa maombi.
- Android Expo: register/login, token salama kwa `expo-secure-store`, orodha ya nyimbo, search, likes, na audio player kwa nyimbo zilizopo kwenye backend.
- Website: kusoma nyimbo kutoka API, kujaribu register/login, na kucheza audio halisi ikipatikana `streamUrl`; demo bado ni fallback.
- App icon ya GLOBAL SOUND imewekwa kwenye Android config.
- Dockerfile ya backend kwa deployment.

## Hatua A — Backend
Mahitaji: Node.js 20+ na npm.

```bash
cd backend
cp .env.example .env
```
Hariri `.env`: tengeneza JWT_SECRET ya kipekee yenye angalau herufi 32; weka `WEB_ORIGIN` kuwa origin ya website yako. Ili kuunda admin wa kwanza, weka `ADMIN_EMAIL`, `ADMIN_PASSWORD` yenye angalau herufi 16, na `ADMIN_NAME`. Bootstrap huunda admin tu kama email hiyo haipo tayari; usishiriki `.env`.

Kisha:
```bash
npm install
npm start
```
Fungua `http://localhost:4000/api/health`. Jibu linalotarajiwa lina `ok:true` na `database:"connected"`.
Katika terminal nyingine:
```bash
npm test
```
Majaribio yanahitaji server iendelee kuwaka. Mazingira ya sasa hayakuruhusu kuthibitisha `npm install` kwa sababu ilizidi muda wa jaribio; tafadhali endesha hatua hizi kwenye host yenye npm na mtandao.

## Hatua B — Hosting ya backend
Unaweza ku-deploy folda `backend` kwa host inayounga mkono Docker/Node. Weka environment variables `PORT` (host huweka yenyewe), `JWT_SECRET`, `WEB_ORIGIN`, `MAX_UPLOAD_MB`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`.

**Tahadhari muhimu:** SQLite na `backend/uploads` zinahitaji persistent disk/volume. Bila persistent storage data na audio zinaweza kupotea redeploy ikifanyika. Kwa uzinduzi mkubwa, badilisha SQLite kwenda managed PostgreSQL na audio kwenda object storage/CDN. Weka HTTPS, backups, rate limiting, email verification, password reset, logging, privacy/terms na security tests kabla ya uzinduzi wa umma.

## Hatua C — Website
1. Host `web/global_sound_v1.html` kwenye static hosting ya HTTPS.
2. Fungua website, kisha browser console weka:
```js
localStorage.setItem('GLOBAL_SOUND_API_URL','https://API-YAKO');
location.reload();
```
3. Kitufe `Account / Ingia` kina register/login kupitia API. Huu ni UI wa msingi; kwa bidhaa kamili, badilisha prompts kuwa form/modal na tumia CSP/CSRF policy inayolingana na hosting.
4. Nyimbo zitaonekana baada ya artist ku-upload audio yenye leseni na admin kuidhinisha.

## Hatua D — Android (simu pekee inawezekana kwa kuhariri, build hutegemea huduma ya build)
1. Weka `android/app.json` → `expo.extra.apiUrl` kwenye HTTPS API URL halisi, kisha save.
2. Kwa Android app ya kweli, `localhost` si backend ya mtandaoni. URL lazima iwe host inayofikika na simu.
3. Build kupitia Expo EAS (inahitajika akaunti ya Expo na credentials zake):
```bash
cd android
npm install
npx eas-cli login
npx eas-cli build --platform android --profile preview
```
Preview profile imewekwa kutoa APK ya majaribio. Production profile imewekwa kwa Android App Bundle. APK iliyojengwa bado lazima ipimwe kwenye simu halisi.

## API muhimu
- `GET /api/health`
- `POST /api/auth/register` `{ "name":"Jina", "email":"mtu@example.com", "password":"NenosiriImara123" }`
- `POST /api/auth/login` `{ "email":"mtu@example.com", "password":"NenosiriImara123" }`
- `GET /api/me` (Bearer token)
- `GET /api/tracks`, `GET /api/tracks/:id/stream`
- `POST /api/tracks/:id/like` (Bearer token)
- `POST /api/artist/activate` (Bearer token)
- `POST /api/artist/tracks` multipart `audio`, `title`, `genre`, `licenseConfirmed=true` (artist/admin)
- `GET /api/artist/tracks`, `GET /api/admin/pending-tracks`
- `POST /api/admin/tracks/:id/approve` au `/reject`
- `GET /api/admin/artist-requests`, `POST /api/admin/artist-requests/:id/approve` au `/reject`
- `GET /api/recommendations`, `GET /api/live-sessions`, `GET /api/premium/plans`

## Ambapo bado panahitaji kazi/credentials
- Hakuna live audio/video provider aliyeunganishwa; live sessions ni ratiba tu.
- Hakuna payment gateway wala malipo yanayokusanywa.
- Recommendation ni baseline kwa genre/plays, si AI/ML ya kiwango cha production.
- Artist upload na admin moderation zipo kwenye API lakini bado zinahitaji dashboard kamili ya UI.
- Website auth UI ni ya msingi; likes za website hazijaunganishwa kikamilifu na token.
- Streaming inahitaji audio halisi ambayo uploader ana haki ya kusambaza; nyimbo za demo hazina audio halisi.
- Hakuna backend iliyodeployiwa na hakuna APK iliyojengwa ndani ya mradi huu.

**Hali ya ukaguzi uliofanyika hapa:** `node --check` imepita kwa backend na JavaScript ya website. Jaribio la `npm install` lilizidi muda wa mazingira haya; kwa hiyo smoke tests za API, build ya Expo na majaribio kwenye kifaa halisi bado hazijathibitishwa. Usichukulie mradi huu kuwa tayari kwa uzinduzi wa umma kabla ya majaribio hayo kupita.

## Hatua E — Hosting ya mtandaoni (Railway)
Faili `backend/railway.json` na `backend/Dockerfile` zimeandaliwa kwa deployment ya Railway.

1. Fungua Railway kupitia akaunti yako na unda project mpya.
2. Weka source ya mradi kwenye GitHub repository yako binafsi (usiweke `.env`, password au token ndani ya repository). Chagua repository hiyo kwenye Railway.
3. Weka **Root Directory** ya service kuwa `/backend` ikiwa repository ina folda kuu za `backend/`, `android/`, na `web/`. Railway itatumia `backend/railway.json` na Dockerfile.
4. Ongeza persistent volume kwenye service, mount path `/app/data` na `/app/uploads`. Hii ni muhimu kwa SQLite database na nyimbo zilizopakiwa; bila volume, data inaweza kupotea wakati wa redeploy.
5. Weka variables kwenye Railway service: `JWT_SECRET` (secret ya kipekee yenye angalau herufi 32), `WEB_ORIGIN` (origin halisi ya website au `*` kwa API ya Android pekee kwa muda; tumia origin maalum ukisha host website), `MAX_UPLOAD_MB=50`, `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` (nenosiri la admin la kipekee lenye herufi 16+). Usitumie mfano wa JWT secret.
6. Deploy. Fungua public domain ya service + `/api/health`; jibu linalotarajiwa: `ok: true`, `database: "connected"`.
7. Tengeneza akaunti ya mtumiaji wa kawaida na ujaribu login. Tumia admin email iliyowekwa kwa bootstrap ya admin; hakikisha credentials zinahifadhiwa salama.
8. Usifute volume. Weka backup za database na faili za audio. Kwa uzinduzi mkubwa, hamia PostgreSQL iliyosimamiwa na object storage/CDN.

**Usalama:** Railway project na credentials ni mali ya mmiliki wa akaunti. Usitume nenosiri, token, `.env`, au recovery codes kwenye chat. Deployment ya umma bado inahitaji majaribio ya usalama, privacy/terms, haki za muziki na backups.


## Hatua F — Orodha ya ukamilishaji kabla ya uzinduzi

Hii ndiyo checklist ya mwisho ya kufanya GLOBAL SOUND iwe huduma ya kweli, si demo. Kazi zinazohitaji akaunti yako haziwezi kukamilika bila wewe kuunganisha hosting/build service.

- [ ] Deploy backend kwenye Railway na pata public HTTPS domain.
- [ ] Weka persistent volume kwenye `/app/data` na `/app/uploads`; hakikisha faili hazipotei baada ya redeploy.
- [ ] Weka secrets kwa Railway Variables; usiweke siri ndani ya GitHub.
- [ ] Pima `GET /api/health`, register, login, `/api/me`, duplicate email na nenosiri lisilo sahihi.
- [ ] Tengeneza website kwenye static HTTPS hosting na weka `GLOBAL_SOUND_API_URL` kwa domain ya API.
- [ ] Weka API URL ileile kwenye `android/app.json` → `expo.extra.apiUrl`.
- [ ] Jenga APK kwa Expo EAS, isakinishe kwenye Android, na ujaribu akaunti, search, audio streaming na likes.
- [ ] Pima upload ya audio yenye haki, idhini ya admin na playback ya nyimbo zilizoidhinishwa.
- [ ] Ongeza email verification, password reset, rate limiting, logs, privacy policy, terms, takedown/copyright workflow na backups.
- [ ] Kabla ya watumiaji wengi: hamia managed PostgreSQL na object storage/CDN badala ya SQLite/local uploads; hakiki recovery ya backup.
- [ ] Live sessions na payments: chagua provider, weka credentials kwa secrets, pima sandbox, thibitisha leseni na mahitaji ya kisheria kabla ya kukusanya malipo au kutangaza live.

### Kile kinachohitajika kutoka kwako sasa

1. Fungua Railway na uunganishe huduma ya Railway ndani ya ChatGPT ikiwa unataka deployment kusaidiwa moja kwa moja.
2. Hakikisha repository ya mradi ipo kwenye GitHub yako binafsi. Usipakie `.env`, token, password au keys.
3. Baada ya ku-deploy, toa **public API URL pekee** (mfano `https://...up.railway.app`); usitume password, JWT secret au admin credentials kwenye chat.
4. APK inahitaji Expo EAS account/build. Akaunti na build credentials ni zako; hazijawekwa ndani ya ZIP.
