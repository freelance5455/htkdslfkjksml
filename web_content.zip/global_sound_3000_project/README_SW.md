# GLOBAL SOUND 3000+ — Starter Project

Huu ni **mradi wa kuanzia unaoweza kuendeshwa na developer**, si huduma iliyokwishawekwa mtandaoni. Unajumuisha:
- V1: website ya demo ya HTML.
- V2: API, SQLite database, usajili/login na JWT.
- V3: upload ya nyimbo za wasanii walioidhinishwa, approval ya admin na streaming ya faili zilizoidhinishwa.
- V4: mwanzo wa Android app kwa Expo/React Native.
- V5: endpoints za artist studio na admin.
- V6: mapendekezo rahisi ya nyimbo (si AI model ya nje bado).
- V7: live sessions na premium plans kama msingi wa API; **live streaming na malipo halisi bado vinahitaji provider, credentials na majaribio ya usalama**.

## Mahitaji
- Node.js 20+ na npm
- Kwa Android starter: Node.js na Expo Go au Android Studio
- Weka faili `web/global_sound_v1.html` (limewekwa ndani ya zip) kwenye browser ili ujaribu UI ya V1.

## Anzisha backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
API itaanza kwa `http://localhost:4000`. Akaunti ya admin haijaundwa kwa default. Unda akaunti ya kawaida kupitia `/api/auth/register`, kisha mabadiliko ya role kuwa admin yafanywe moja kwa moja kwenye database na msimamizi wa deployment (maelezo chini).

### Kuunda admin wa kwanza kwa usalama
1. Sajili akaunti kupitia UI/API.
2. Simamisha server.
3. Fungua `backend/data/global_sound.db` kwa SQLite browser.
4. Badilisha `role` ya akaunti hiyo kuwa `admin`.
5. Anzisha server tena na tumia akaunti hiyo. **Usiweke endpoint ya public ya kujipa admin.**

## API muhimu
- `POST /api/auth/register` `{ "name":"...", "email":"...", "password":"..." }`
- `POST /api/auth/login` `{ "email":"...", "password":"..." }`
- `GET /api/tracks` nyimbo zilizoidhinishwa pekee
- `GET /api/tracks/:id/stream` streaming ya audio iliyokubaliwa
- `POST /api/artist/tracks` (artist role; multipart form: `audio`, `title`, `genre`)
- `GET /api/artist/tracks` nyimbo za msanii aliyeingia
- `GET /api/admin/pending-tracks` (admin)
- `POST /api/admin/tracks/:id/approve` au `/reject`
- `GET /api/recommendations`
- `GET /api/live-sessions`
- `POST /api/live-sessions` (artist/admin)
- `GET /api/premium/plans`

## Kuanzisha Android starter
```bash
cd android
npm install
npx expo start
```
Badilisha `API_URL` kwenye `App.js` kwa IP ya kompyuta/server yako. `localhost` kwenye simu ni simu yenyewe, si kompyuta.

## Kabla ya launch ya umma
- Weka HTTPS, secrets imara na CORS domain maalum.
- Tumia managed PostgreSQL badala ya SQLite kwa production.
- Tumia object storage + CDN badala ya kuhifadhi audio kwenye server.
- Pata na uhakiki leseni za kila wimbo na haki za streaming katika maeneo unayohudumia.
- Unganisha payment provider kwa subscriptions; usikusanye taarifa za kadi mwenyewe.
- Live sessions zinahitaji WebRTC/live provider, moderation na credentials.
- Ongeza email verification, password reset, rate limiting, audit logs, backups, malware scanning na privacy/terms.
