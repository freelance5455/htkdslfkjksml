require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32 || JWT_SECRET.includes('replace_with')) {
  console.error('Set a strong JWT_SECRET (32+ chars) in .env before starting.');
  process.exit(1);
}
const root = __dirname;
const dataDir = path.join(root, 'data');
const uploadDir = path.join(root, 'uploads');
fs.mkdirSync(dataDir, {recursive:true});
fs.mkdirSync(uploadDir, {recursive:true});
const db = new Database(path.join(dataDir, 'global_sound.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'listener' CHECK(role IN ('listener','artist','admin')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tracks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, artist_name TEXT NOT NULL,
 genre TEXT DEFAULT 'Other', file_name TEXT NOT NULL, mime_type TEXT NOT NULL,
 uploader_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 license_confirmed INTEGER NOT NULL DEFAULT 0, plays INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(uploader_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS likes (
 user_id INTEGER NOT NULL, track_id INTEGER NOT NULL,
 PRIMARY KEY(user_id,track_id), FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(track_id) REFERENCES tracks(id)
);
CREATE TABLE IF NOT EXISTS live_sessions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
 host_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled',
 starts_at TEXT, provider_room_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(host_id) REFERENCES users(id)
);
`);
app.use(cors({origin: process.env.WEB_ORIGIN || 'http://localhost:8080'}));
app.use(express.json({limit:'1mb'}));
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');next();});

function tokenFor(user){return jwt.sign({sub:user.id,role:user.role},JWT_SECRET,{expiresIn:'7d'});}
function auth(req,res,next){
 const h=req.headers.authorization||'';
 if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Ingia kwanza.'});
 try { const p=jwt.verify(h.slice(7),JWT_SECRET); const user=db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(p.sub); if(!user)return res.status(401).json({error:'Akaunti haipo.'}); req.user=user; next(); }
 catch { return res.status(401).json({error:'Token si sahihi au imeisha muda.'}); }
}
function roles(...allowed){return (req,res,next)=>{if(!allowed.includes(req.user.role))return res.status(403).json({error:'Huna ruhusa ya kufanya kitendo hiki.'});next();};}
function publicTrack(t){return {id:t.id,title:t.title,artist:t.artist_name,genre:t.genre,plays:t.plays,createdAt:t.created_at,streamUrl:`/api/tracks/${t.id}/stream`};}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'GLOBAL SOUND API',version:'0.1.0'}));
app.post('/api/auth/register', async (req,res)=>{
 const {name,email,password}=req.body||{};
 if(typeof name!=='string'||name.trim().length<2||name.length>80) return res.status(400).json({error:'Jina liwe na herufi 2–80.'});
 if(typeof email!=='string'||!/^\\S+@\\S+\\.\\S+$/.test(email)) return res.status(400).json({error:'Barua pepe si sahihi.'});
 if(typeof password!=='string'||password.length<10) return res.status(400).json({error:'Nenosiri liwe na angalau herufi 10.'});
 try { const hash=await bcrypt.hash(password,12); const info=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name.trim(),email.toLowerCase(),hash); const user={id:Number(info.lastInsertRowid),name:name.trim(),email:email.toLowerCase(),role:'listener'};res.status(201).json({user,token:tokenFor(user)}); }
 catch(e){if(String(e).includes('UNIQUE'))return res.status(409).json({error:'Barua pepe imesajiliwa tayari.'});res.status(500).json({error:'Imeshindikana kusajili akaunti.'});}
});
app.post('/api/auth/login',async(req,res)=>{
 const {email,password}=req.body||{};const user=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').toLowerCase());
 if(!user||!await bcrypt.compare(String(password||''),user.password_hash))return res.status(401).json({error:'Barua pepe au nenosiri si sahihi.'});
 const safe={id:user.id,name:user.name,email:user.email,role:user.role};res.json({user:safe,token:tokenFor(safe)});
});
app.get('/api/me',auth,(req,res)=>res.json({user:req.user}));
app.post('/api/artist/activate',auth,(req,res)=>{
 if(req.user.role==='admin'||req.user.role==='artist')return res.json({user:req.user});
 // Request activation is not self-granting: record instructions only.
 res.status(202).json({message:'Ombi la kuwa msanii linahitaji idhini ya admin. Role yako haijabadilishwa.'});
});

const maxMB=Math.max(1,Math.min(100,Number(process.env.MAX_UPLOAD_MB||50)));
const storage=multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>cb(null,crypto.randomBytes(16).toString('hex')+path.extname(file.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:maxMB*1024*1024},fileFilter:(req,file,cb)=>{
 const allowed=new Set(['audio/mpeg','audio/mp4','audio/aac','audio/wav','audio/x-wav','audio/ogg','audio/flac','audio/webm']);
 if(!allowed.has(file.mimetype))return cb(new Error('Aina ya faili haikubaliki. Tumia audio format inayoruhusiwa.'));
 cb(null,true);
}});
app.get('/api/tracks',(req,res)=>{const rows=db.prepare("SELECT * FROM tracks WHERE status='approved' ORDER BY created_at DESC LIMIT 200").all();res.json({tracks:rows.map(publicTrack)});});
app.get('/api/tracks/:id/stream',(req,res)=>{
 const t=db.prepare("SELECT * FROM tracks WHERE id=? AND status='approved'").get(Number(req.params.id));
 if(!t)return res.status(404).json({error:'Wimbo haupatikani au haujaidhinishwa.'});
 const file=path.join(uploadDir,path.basename(t.file_name));if(!fs.existsSync(file))return res.status(404).json({error:'Faili la audio halipo.'});
 db.prepare('UPDATE tracks SET plays=plays+1 WHERE id=?').run(t.id);
 res.setHeader('Content-Type',t.mime_type);res.setHeader('Accept-Ranges','bytes');
 const stat=fs.statSync(file),range=req.headers.range;
 if(range){const m=/bytes=(\\d*)-(\\d*)/.exec(range);if(!m)return res.status(416).end();const start=m[1]?Number(m[1]):0;const end=m[2]?Math.min(Number(m[2]),stat.size-1):stat.size-1;if(start>end||start>=stat.size)return res.status(416).end();res.status(206).set({'Content-Range':`bytes ${start}-${end}/${stat.size}`,'Content-Length':end-start+1});fs.createReadStream(file,{start,end}).pipe(res);}
 else {res.setHeader('Content-Length',stat.size);fs.createReadStream(file).pipe(res);}
});
app.post('/api/artist/tracks',auth,roles('artist','admin'),(req,res)=>{
 upload.single('audio')(req,res,err=>{
  if(err)return res.status(400).json({error:err.message||'Upload imeshindikana.'});
  const {title,genre,licenseConfirmed}=req.body||{};
  if(!req.file)return res.status(400).json({error:'Weka faili la audio.'});
  if(typeof title!=='string'||title.trim().length<1){fs.unlinkSync(req.file.path);return res.status(400).json({error:'Weka jina la wimbo.'});}
  if(licenseConfirmed!=='true'){fs.unlinkSync(req.file.path);return res.status(400).json({error:'Thibitisha kuwa una haki/ruhusa ya kusambaza wimbo.'});}
  const info=db.prepare("INSERT INTO tracks(title,artist_name,genre,file_name,mime_type,uploader_id,license_confirmed,status) VALUES(?,?,?,?,?,?,1,'pending')").run(title.trim(),req.user.name,String(genre||'Other').slice(0,50),req.file.filename,req.file.mimetype,req.user.id);
  res.status(201).json({message:'Wimbo umetumwa kwa ukaguzi wa admin; bado haupatikani kwa umma.',trackId:Number(info.lastInsertRowid)});
 });
});
app.get('/api/artist/tracks',auth,roles('artist','admin'),(req,res)=>{const rows=db.prepare('SELECT id,title,artist_name,genre,status,plays,created_at FROM tracks WHERE uploader_id=? ORDER BY created_at DESC').all(req.user.id);res.json({tracks:rows});});
app.get('/api/admin/pending-tracks',auth,roles('admin'),(req,res)=>res.json({tracks:db.prepare("SELECT t.id,t.title,t.artist_name,t.genre,t.created_at,u.email AS uploader_email FROM tracks t JOIN users u ON u.id=t.uploader_id WHERE t.status='pending' ORDER BY t.created_at").all()}));
app.post('/api/admin/tracks/:id/approve',auth,roles('admin'),(req,res)=>{const r=db.prepare("UPDATE tracks SET status='approved' WHERE id=? AND status='pending'").run(Number(req.params.id));if(!r.changes)return res.status(404).json({error:'Wimbo pending haukupatikana.'});res.json({ok:true,message:'Wimbo umeidhinishwa.'});});
app.post('/api/admin/tracks/:id/reject',auth,roles('admin'),(req,res)=>{const t=db.prepare("SELECT * FROM tracks WHERE id=? AND status='pending'").get(Number(req.params.id));if(!t)return res.status(404).json({error:'Wimbo pending haukupatikana.'});db.prepare("UPDATE tracks SET status='rejected' WHERE id=?").run(t.id);res.json({ok:true,message:'Wimbo umekataliwa; faili limehifadhiwa kwa ukaguzi/audit.'});});
app.get('/api/recommendations',auth,(req,res)=>{
 // Baseline recommender: genre preference from likes; production can replace with ML service.
 const liked=db.prepare('SELECT t.genre,COUNT(*) n FROM likes l JOIN tracks t ON t.id=l.track_id WHERE l.user_id=? GROUP BY t.genre ORDER BY n DESC LIMIT 1').get(req.user.id);
 const rows=liked?db.prepare("SELECT * FROM tracks WHERE status='approved' AND genre=? ORDER BY plays DESC LIMIT 20").all(liked.genre):db.prepare("SELECT * FROM tracks WHERE status='approved' ORDER BY plays DESC LIMIT 20").all();
 res.json({basedOn:liked?liked.genre:'popular tracks',tracks:rows.map(publicTrack)});
});
app.post('/api/tracks/:id/like',auth,(req,res)=>{
 const id=Number(req.params.id);const t=db.prepare("SELECT id FROM tracks WHERE id=? AND status='approved'").get(id);if(!t)return res.status(404).json({error:'Wimbo haupatikani.'});
 const existing=db.prepare('SELECT 1 FROM likes WHERE user_id=? AND track_id=?').get(req.user.id,id);
 if(existing){db.prepare('DELETE FROM likes WHERE user_id=? AND track_id=?').run(req.user.id,id);return res.json({liked:false});}
 db.prepare('INSERT INTO likes(user_id,track_id) VALUES(?,?)').run(req.user.id,id);res.json({liked:true});
});
app.get('/api/live-sessions',(req,res)=>res.json({sessions:db.prepare("SELECT l.id,l.title,l.description,l.status,l.starts_at,u.name AS host FROM live_sessions l JOIN users u ON u.id=l.host_id WHERE l.status IN ('scheduled','live') ORDER BY l.starts_at LIMIT 100").all(),note:'Hii ni orodha tu; live audio/video provider bado hajaunganishwa.'}));
app.post('/api/live-sessions',auth,roles('artist','admin'),(req,res)=>{
 const {title,description,startsAt}=req.body||{};if(typeof title!=='string'||title.trim().length<3)return res.status(400).json({error:'Kichwa kiwe na angalau herufi 3.'});
 const info=db.prepare("INSERT INTO live_sessions(title,description,host_id,starts_at) VALUES(?,?,?,?)").run(title.trim(),String(description||'').slice(0,500),req.user.id,startsAt||null);
 res.status(201).json({id:Number(info.lastInsertRowid),message:'Live session imepangwa. Live provider bado hajaunganishwa.'});
});
app.get('/api/premium/plans',(req,res)=>res.json({currency:'TZS',plans:[{id:'free',name:'Free',price:0,features:['Kusikiliza nyimbo zilizoidhinishwa','Kufollow discovery']},{id:'premium',name:'Premium',price:null,features:['Mipango ya ubora wa juu kulingana na leseni','Offline listening ikiwa leseni inaruhusu','Vipengele vya ziada']}],note:'Bei, billing na subscriptions hazijawezeshwa hadi payment provider na sera ziidhinishwe.'}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Hitilafu ya server.'});});
app.listen(PORT,()=>console.log(`GLOBAL SOUND API running at http://localhost:${PORT}`));
