// Integration smoke test: start the API first, then run `npm test`.
import assert from 'node:assert/strict';
const base = process.env.API_URL || 'http://127.0.0.1:4000';
const stamp = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const email = `smoke-${stamp}@example.com`;
const password = 'SmokeTest!Pass2026';
async function request(path, options = {}) {
  const response = await fetch(`${base}${path}`, options);
  let body = {};
  try { body = await response.json(); } catch {}
  return { response, body };
}
const health = await request('/api/health');
assert.equal(health.response.status, 200, 'health endpoint should return 200');
assert.equal(health.body.database, 'connected', 'database should be connected');
const registered = await request('/api/auth/register', {
  method: 'POST', headers: {'content-type':'application/json'},
  body: JSON.stringify({name:'Smoke Tester', email, password})
});
assert.equal(registered.response.status, 201, 'registration should return 201');
assert.ok(registered.body.token, 'registration should return a JWT');
assert.equal(registered.body.user.email, email, 'email should be normalized');
const duplicate = await request('/api/auth/register', {
  method: 'POST', headers: {'content-type':'application/json'},
  body: JSON.stringify({name:'Smoke Tester', email:email.toUpperCase(), password})
});
assert.equal(duplicate.response.status, 409, 'duplicate email should be rejected');
const login = await request('/api/auth/login', {
  method: 'POST', headers: {'content-type':'application/json'},
  body: JSON.stringify({email, password})
});
assert.equal(login.response.status, 200, 'login should succeed');
assert.ok(login.body.token, 'login should return a JWT');
const me = await request('/api/me', {headers:{authorization:`Bearer ${login.body.token}`}});
assert.equal(me.response.status, 200, 'valid token should access /api/me');
assert.equal(me.body.user.email, email);
const wrongPassword = await request('/api/auth/login', {
  method: 'POST', headers: {'content-type':'application/json'},
  body: JSON.stringify({email, password:'WrongPassword!2026'})
});
assert.equal(wrongPassword.response.status, 401, 'wrong password should be rejected');
console.log('PASS: health/database, register, duplicate-email protection, login, JWT /api/me, wrong-password rejection');
