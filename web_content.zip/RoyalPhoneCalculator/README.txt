# حاسبة أقساط الهاتف الملكي — مشروع Android

هذا مشروع Android Studio يغلّف حاسبة الأقساط بواجهة WebView محلية، ويعمل دون إنترنت.
لا يحتوي على الفواتير أو الوصولات.

## إنشاء APK
1. افتح مجلد RoyalPhoneCalculator في Android Studio.
2. انتظر مزامنة Gradle وتنزيل أدوات Android المطلوبة.
3. من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4. ستجد APK داخل app/build/outputs/apk/debug/.

اللون الأساسي: ذهبي #D4AF37، والخلفية سوداء/بيضاء.
