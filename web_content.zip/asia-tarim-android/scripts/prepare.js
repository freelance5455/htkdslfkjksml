const fs = require('fs');
fs.mkdirSync('www/vendor', { recursive: true });
fs.copyFileSync('src/index.html', 'www/index.html');
fs.copyFileSync('node_modules/html2canvas/dist/html2canvas.min.js', 'www/vendor/html2canvas.min.js');
fs.copyFileSync('node_modules/jspdf/dist/jspdf.umd.min.js', 'www/vendor/jspdf.umd.min.js');
console.log('www ready');
