# Asia Tarim Accounting – Android (Capacitor)

## Option A: build the APK in the cloud (no Android Studio)
1. Create a new GitHub repository and upload everything in this folder (keep .github/workflows).
2. Open the Actions tab -> "Build Android APK" -> wait for it to finish.
3. Download the artifact "asia-tarim-apk" (app-debug.apk), copy it to the phone and install it
   (allow "install unknown apps").

## Option B: build locally (Node 18+, JDK 17, Android Studio)
npm install
npm run prepare:web
npx cap add android
npx cap sync android
npx cap open android     # then Build > Build APK(s)

## Notes
- Data is stored inside the app on the phone (localStorage). Do not clear the app data.
- PDF export saves the file and opens the Android share sheet (Files, Drive, WhatsApp...).
- To change the app: edit src/index.html, then run npm run sync.
