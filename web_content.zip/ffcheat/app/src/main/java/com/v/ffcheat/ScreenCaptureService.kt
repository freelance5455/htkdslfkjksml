package com.v.ffcheat
import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
class ScreenCaptureService : Service() {
    companion object {
        const val CH = "ffcap"
        @Volatile var grantResult: Int = 0
        @Volatile var grantData: Intent? = null
        @Volatile var latest: Bitmap? = null
    }
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    override fun onCreate() { super.onCreate(); startForeground(1002, Notification.Builder(this, CH).setContentTitle("Captura").build()) }
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val data = grantData; if (data == null || proj != null) return START_STICKY
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = m.getMediaProjection(grantResult, data)
        val dm = DisplayMetrics(); (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]; val buf = plane.buffer
                val bmp = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buf); latest = bmp
            } catch (_: Throwable) {} finally { img.close() }
        }, Handler(Looper.getMainLooper()))
        vd = proj!!.createVirtualDisplay("ffcap", dm.widthPixels, dm.heightPixels, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        return START_STICKY
    }
    override fun onDestroy() { vd?.release(); reader?.close(); proj?.stop(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}