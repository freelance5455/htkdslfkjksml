package com.v.ffcheat
import android.content.Context
import android.os.Handler
import android.os.Looper
class AimController {
    companion object {
        private val h = Handler(Looper.getMainLooper())
        @Volatile private var run = false
        private var det: Detector? = null
        private var ctx: Context? = null
        fun start(c: Context) {
            ctx = c.applicationContext; if (run) return; run = true
            det = Detector(c.applicationContext); det!!.load(); h.post(loop)
        }
        fun stop() { run = false; h.removeCallbacksAndMessages(null); det?.close(); det = null }
        private val loop = object : Runnable {
            override fun run() {
                if (!run) return
                val c = ctx ?: return
                val frame = ScreenCaptureService.latest
                val aim = Config.bool(c,"aimbot")
                val a11y = FfAccessibility.instance
                if (aim && frame != null && a11y != null) {
                    val t = det?.detect(frame, 260f, 0.4f)
                    if (t != null) {
                        val fx = frame.width/2f; val fy = frame.height/2f
                        val dx = (t.centerX() - fx) / 4
                        val dy = (t.top + t.height()/6f - fy) / 4
                        a11y.swipe(fx, fy, fx + dx, fy + dy, 18L)
                    }
                }
                h.postDelayed(this, 80)
            }
        }
    }
}