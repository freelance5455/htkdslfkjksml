package com.v.ffcheat
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuProvider
class MainActivity : AppCompatActivity() {
    private val REQ_PROJ = 5001; private val REQ_SHZ = 5002
    private val shz = Shizuku.OnRequestPermissionResultListener { c, r ->
        if (c == REQ_SHZ) Toast.makeText(this, if (r == 0) "Shizuku OK" else "Shizuku negado", Toast.LENGTH_SHORT).show()
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); ShizukuProvider.enableMultiProcessSupport(false)
        Shizuku.addRequestPermissionResultListener(shz)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(60,120,60,60) }
        fun add(t: String, f: () -> Unit) { root.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }
        add("1. Overlay") { if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else Toast.makeText(this,"ja concedido",Toast.LENGTH_SHORT).show() }
        add("2. Acessibilidade") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        add("3. Shizuku") { if (!Shizuku.pingBinder()) Toast.makeText(this,"Inicie o Shizuku",Toast.LENGTH_LONG).show() else if (Shizuku.checkSelfPermission()==0) Toast.makeText(this,"ja autorizado",Toast.LENGTH_SHORT).show() else Shizuku.requestPermission(REQ_SHZ) }
        add("4. Captura") { val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(m.createScreenCaptureIntent(), REQ_PROJ) }
        add("5. Abrir painel") { ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java)); finish() }
        add("Parar overlay") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(root)
    }
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == REQ_PROJ && rc == RESULT_OK && d != null) {
            ScreenCaptureService.grantResult = rc; ScreenCaptureService.grantData = d
            ContextCompat.startForegroundService(this, Intent(this, ScreenCaptureService::class.java))
            Toast.makeText(this,"Captura iniciada",Toast.LENGTH_SHORT).show()
        }
    }
    override fun onDestroy() { Shizuku.removeRequestPermissionResultListener(shz); super.onDestroy() }
}