import { count, desc, eq } from "drizzle-orm";
import {
  Router,
  type IRouter,
  type Request,
  type Response,
} from "express";
import {
  GetAgentRunParams,
  GetAgentRunResponse,
  ListAgentRunsQueryParams,
  ListAgentRunsResponse,
  ListAgentsResponse,
  RunAllAvailableAgentsBody,
  RunAllAvailableAgentsResponse,
  RunMarketDataAgentBody,
  RunMarketDataAgentResponse,
  type ErrorResponse,
} from "@workspace/api-zod";
import { agentRunsTable, db, type AgentRunRecord } from "@workspace/db";
import { AGENT_CATALOG } from "../agents/catalog";
import { agentEngine } from "../agents";
import type {
  AgentExecutionOutcome,
  HistoricalMarketDataInput,
} from "../agents/types";

const router: IRouter = Router();

function toApiRun(row: AgentRunRecord) {
  return {
    id: row.id,
    agentId: row.agentId,
    status: row.status,
    mode: row.mode,
    startedAt: row.startedAt.toISOString(),
    completedAt: row.completedAt?.toISOString() ?? null,
    durationMs: row.durationMs,
    inputSummary: row.inputSummary,
    output: row.output,
    error: row.error,
  };
}

function summarizeInput(input: HistoricalMarketDataInput) {
  const dates = input.candles.map((candle) => candle.date).sort();
  return {
    symbol: input.symbol.trim().toUpperCase(),
    mode: "historical" as const,
    source: input.source,
    recordCount: input.candles.length,
    startDate: dates[0] ?? null,
    endDate: dates.at(-1) ?? null,
    movingAverageWindow: input.movingAverageWindow ?? 20,
  };
}

function toHistoricalInput(input: {
  symbol: string;
  mode: "historical";
  source: "csv_upload" | "demo_fixture";
  movingAverageWindow?: number;
  candles: {
    date: Date;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }[];
}): HistoricalMarketDataInput {
  return {
    ...input,
    candles: input.candles.map((candle) => ({
      ...candle,
      date: candle.date.toISOString().slice(0, 10),
    })),
  };
}

function errorResponse(message: string): ErrorResponse {
  return { error: message };
}

async function createRunningRecords(
  modules: ReturnType<typeof agentEngine.getExecutionPlan>,
  input: HistoricalMarketDataInput,
): Promise<Map<string, string>> {
  const inputSummary = summarizeInput(input);
  const inserted = await Promise.all(
    modules.map(async (module) => {
      const [row] = await db
        .insert(agentRunsTable)
        .values({
          agentId: module.id,
          status: "running",
          mode: "historical",
          startedAt: new Date(),
          completedAt: null,
          durationMs: null,
          inputSummary,
          output: null,
          error: null,
        })
        .returning({ id: agentRunsTable.id });
      return [module.id, row.id] as const;
    }),
  );
  return new Map(inserted);
}

async function saveOutcomes(
  outcomes: AgentExecutionOutcome[],
  runIds: Map<string, string>,
  req: Request,
): Promise<Map<string, ReturnType<typeof toApiRun>>> {
  const saved = await Promise.all(
    outcomes.map(async (outcome) => {
      const runId = runIds.get(outcome.agentId);
      if (!runId) {
        throw new Error(`Missing persisted run record for ${outcome.agentId}.`);
      }

      const output =
        outcome.output &&
        typeof outcome.output === "object" &&
        !Array.isArray(outcome.output)
          ? (outcome.output as Record<string, unknown>)
          : null;
      const [row] = await db
        .update(agentRunsTable)
        .set({
          status: outcome.status,
          startedAt: new Date(outcome.startedAt),
          completedAt: new Date(outcome.completedAt),
          durationMs: outcome.durationMs,
          output,
          error: outcome.error
            ? {
                code: outcome.error.code,
                message: outcome.error.message,
                issues: [...outcome.error.issues],
              }
            : null,
        })
        .where(eq(agentRunsTable.id, runId))
        .returning();

      if (outcome.error) {
        req.log.warn(
          { agentId: outcome.agentId, runId, error: outcome.error },
          "Agent execution failed",
        );
      }
      return [outcome.agentId, toApiRun(row)] as const;
    }),
  );
  return new Map(saved);
}

function respondWithValidationError(
  res: Response,
  message: string,
): void {
  res.status(400).json(errorResponse(message));
}

router.get("/agents", async (req, res): Promise<void> => {
  const rows = await db
    .select({
      agentId: agentRunsTable.agentId,
      status: agentRunsTable.status,
      startedAt: agentRunsTable.startedAt,
      durationMs: agentRunsTable.durationMs,
    })
    .from(agentRunsTable)
    .orderBy(desc(agentRunsTable.startedAt));

  const summaries = new Map<
    string,
    {
      totalRuns: number;
      successfulRuns: number;
      failedRuns: number;
      durationTotal: number;
      durationCount: number;
      latest?: (typeof rows)[number];
    }
  >();

  for (const row of rows) {
    const summary = summaries.get(row.agentId) ?? {
      totalRuns: 0,
      successfulRuns: 0,
      failedRuns: 0,
      durationTotal: 0,
      durationCount: 0,
    };
    summary.totalRuns += 1;
    if (row.status === "completed") summary.successfulRuns += 1;
    if (row.status === "failed") summary.failedRuns += 1;
    if (row.durationMs !== null) {
      summary.durationTotal += row.durationMs;
      summary.durationCount += 1;
    }
    summary.latest ??= row;
    summaries.set(row.agentId, summary);
  }

  const runnableIds = new Set(
    agentEngine.getRunnableModules().map((module) => module.id),
  );
  const agents = AGENT_CATALOG.map((agent) => {
    const summary = summaries.get(agent.id);
    const latest = summary?.latest;
    const readiness = runnableIds.has(agent.id) ? "ready" : "planned";
    return {
      id: agent.id,
      name: agent.name,
      responsibility: agent.responsibility,
      readiness,
      status:
        readiness === "planned" ? "planned" : (latest?.status ?? "idle"),
      lastExecutionAt: latest?.startedAt.toISOString() ?? null,
      lastDurationMs: latest?.durationMs ?? null,
      performance: {
        totalRuns: summary?.totalRuns ?? 0,
        successfulRuns: summary?.successfulRuns ?? 0,
        failedRuns: summary?.failedRuns ?? 0,
        averageDurationMs:
          summary && summary.durationCount > 0
            ? Math.round(summary.durationTotal / summary.durationCount)
            : null,
      },
    };
  });

  res.json(ListAgentsResponse.parse(agents));
});

router.get("/agents/runs", async (req, res): Promise<void> => {
  const parsed = ListAgentRunsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    respondWithValidationError(res, parsed.error.message);
    return;
  }
  const { agentId, limit, offset } = parsed.data;
  const where = agentId ? eq(agentRunsTable.agentId, agentId) : undefined;
  const [rows, totalRows] = await Promise.all([
    db
      .select()
      .from(agentRunsTable)
      .where(where)
      .orderBy(desc(agentRunsTable.startedAt))
      .limit(limit)
      .offset(offset),
    db.select({ value: count() }).from(agentRunsTable).where(where),
  ]);
  const response = {
    items: rows.map(toApiRun),
    total: totalRows[0]?.value ?? 0,
    limit,
    offset,
  };
  res.json(ListAgentRunsResponse.parse(response));
});

router.get("/agents/runs/:runId", async (req, res): Promise<void> => {
  const parsed = GetAgentRunParams.safeParse(req.params);
  if (!parsed.success) {
    respondWithValidationError(res, parsed.error.message);
    return;
  }
  const [row] = await db
    .select()
    .from(agentRunsTable)
    .where(eq(agentRunsTable.id, parsed.data.runId))
    .limit(1);
  if (!row) {
    res.status(404).json(errorResponse("Agent run not found."));
    return;
  }
  res.json(GetAgentRunResponse.parse(toApiRun(row)));
});

async function executeAndPersist(
  req: Request,
  input: HistoricalMarketDataInput,
  targetIds: string[],
): Promise<Map<string, ReturnType<typeof toApiRun>>> {
  const plan = agentEngine.getExecutionPlan(targetIds);
  const runIds = await createRunningRecords(plan, input);
  const outcomes =
    targetIds.length === 1
      ? await agentEngine.runOne(targetIds[0], input)
      : await agentEngine.runAll(input);
  return saveOutcomes(outcomes, runIds, req);
}

router.post("/agents/market-data/runs", async (req, res): Promise<void> => {
  const parsed = RunMarketDataAgentBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn(
      { errors: parsed.error.message },
      "Rejected invalid Market Data Agent request",
    );
    respondWithValidationError(res, parsed.error.message);
    return;
  }

  const saved = await executeAndPersist(
    req,
    toHistoricalInput(parsed.data),
    ["market-data"],
  );
  const run = saved.get("market-data");
  if (!run) throw new Error("Market Data Agent did not return a run record.");
  res.status(201).json(RunMarketDataAgentResponse.parse(run));
});

router.post("/agents/runs/all", async (req, res): Promise<void> => {
  const parsed = RunAllAvailableAgentsBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn(
      { errors: parsed.error.message },
      "Rejected invalid Run All Agents request",
    );
    respondWithValidationError(res, parsed.error.message);
    return;
  }

  const targetIds = agentEngine.getRunnableModules().map((module) => module.id);
  if (targetIds.length === 0) {
    res.status(503).json(
      errorResponse("No agents are currently ready to run."),
    );
    return;
  }

  const saved = await executeAndPersist(
    req,
    toHistoricalInput(parsed.data),
    targetIds,
  );
  const items = targetIds
    .map((agentId) => saved.get(agentId))
    .filter((run): run is NonNullable<typeof run> => run !== undefined);
  res
    .status(201)
    .json(RunAllAvailableAgentsResponse.parse({ items, total: items.length, limit: items.length, offset: 0 }));
});

export default router;
