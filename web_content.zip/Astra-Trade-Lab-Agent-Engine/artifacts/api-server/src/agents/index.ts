import { AgentEngine } from "./engine";
import { marketDataAgent } from "./market-data/agent";

export const agentEngine = new AgentEngine([marketDataAgent]);
