import { AGENT_CATALOG } from "./catalog.ts";
import { AgentInputValidationError } from "./market-data/agent.ts";
import type {
  AgentContext,
  AgentExecutionOutcome,
  AgentModule,
  AgentRunError,
  HistoricalMarketDataInput,
} from "./types";

export class AgentEngineConfigurationError extends Error {
  readonly code: string;

  constructor(
    code: string,
    message: string,
  ) {
    super(message);
    this.name = "AgentEngineConfigurationError";
    this.code = code;
  }
}

function toRunError(error: unknown): AgentRunError {
  if (error instanceof AgentInputValidationError) {
    return {
      code: error.code,
      message: error.message,
      issues: error.issues,
    };
  }
  if (error instanceof AgentEngineConfigurationError) {
    return {
      code: error.code,
      message: error.message,
      issues: [],
    };
  }
  return {
    code: "AGENT_EXECUTION_FAILED",
    message: error instanceof Error ? error.message : "Agent execution failed.",
    issues: [],
  };
}

export class AgentEngine {
  private readonly modules: Map<string, AgentModule>;

  constructor(modules: readonly AgentModule[]) {
    this.modules = new Map();
    for (const module of modules) {
      if (this.modules.has(module.id)) {
        throw new AgentEngineConfigurationError(
          "DUPLICATE_AGENT",
          `Agent ${module.id} is registered more than once.`,
        );
      }
      this.modules.set(module.id, module);
    }
  }

  getRunnableModules(): AgentModule[] {
    return [...this.modules.values()].filter(
      (module) => module.readiness === "ready",
    );
  }

  getExecutionPlan(agentIds: readonly string[]): AgentModule[] {
    const ordered: AgentModule[] = [];
    const visited = new Set<string>();
    const visiting = new Set<string>();

    const visit = (agentId: string): void => {
      if (visited.has(agentId)) return;
      if (visiting.has(agentId)) {
        throw new AgentEngineConfigurationError(
          "DEPENDENCY_CYCLE",
          `Agent dependency cycle detected at ${agentId}.`,
        );
      }
      const module = this.modules.get(agentId);
      if (!module) {
        throw new AgentEngineConfigurationError(
          "AGENT_NOT_FOUND",
          `Agent ${agentId} is not registered as executable.`,
        );
      }
      if (module.readiness !== "ready") {
        throw new AgentEngineConfigurationError(
          "AGENT_NOT_READY",
          `Agent ${agentId} is not ready to execute.`,
        );
      }

      visiting.add(agentId);
      for (const dependencyId of module.dependsOn) visit(dependencyId);
      visiting.delete(agentId);
      visited.add(agentId);
      ordered.push(module);
    };

    for (const agentId of agentIds) visit(agentId);
    return ordered;
  }

  async runOne(
    agentId: string,
    input: HistoricalMarketDataInput,
  ): Promise<AgentExecutionOutcome[]> {
    return this.runPlan(input, this.getExecutionPlan([agentId]));
  }

  async runAll(
    input: HistoricalMarketDataInput,
  ): Promise<AgentExecutionOutcome[]> {
    return this.runPlan(
      input,
      this.getExecutionPlan(this.getRunnableModules().map((module) => module.id)),
    );
  }

  private async runPlan(
    input: HistoricalMarketDataInput,
    plan: AgentModule[],
  ): Promise<AgentExecutionOutcome[]> {
    const pending = new Map(plan.map((module) => [module.id, module]));
    const outcomes = new Map<string, AgentExecutionOutcome>();

    while (pending.size > 0) {
      const ready = [...pending.values()].filter((module) =>
        module.dependsOn.every((dependencyId) => outcomes.has(dependencyId)),
      );
      if (ready.length === 0) {
        throw new AgentEngineConfigurationError(
          "DEPENDENCY_GRAPH_BLOCKED",
          "No remaining agent can run because its dependencies are unresolved.",
        );
      }

      const wave = await Promise.all(
        ready.map(async (module): Promise<AgentExecutionOutcome> => {
          const failedDependency = module.dependsOn.find(
            (dependencyId) => outcomes.get(dependencyId)?.status === "failed",
          );
          if (failedDependency) {
            const timestamp = new Date().toISOString();
            return {
              agentId: module.id,
              status: "failed",
              startedAt: timestamp,
              completedAt: timestamp,
              durationMs: 0,
              output: null,
              error: {
                code: "DEPENDENCY_FAILED",
                message: `Required agent ${failedDependency} did not complete.`,
                issues: [],
              },
            };
          }

          const startedAt = new Date();
          const startClock = performance.now();
          const dependencies: Record<string, unknown> = {};
          for (const dependencyId of module.dependsOn) {
            dependencies[dependencyId] = outcomes.get(dependencyId)?.output;
          }
          const context: AgentContext = { input, dependencies };
          try {
            const output = await module.run(context);
            const completedAt = new Date();
            return {
              agentId: module.id,
              status: "completed",
              startedAt: startedAt.toISOString(),
              completedAt: completedAt.toISOString(),
              durationMs: Math.max(
                0,
                Math.round(performance.now() - startClock),
              ),
              output,
              error: null,
            };
          } catch (error) {
            const completedAt = new Date();
            return {
              agentId: module.id,
              status: "failed",
              startedAt: startedAt.toISOString(),
              completedAt: completedAt.toISOString(),
              durationMs: Math.max(
                0,
                Math.round(performance.now() - startClock),
              ),
              output: null,
              error: toRunError(error),
            };
          }
        }),
      );

      for (const outcome of wave) {
        outcomes.set(outcome.agentId, outcome);
        pending.delete(outcome.agentId);
      }
    }

    return plan.map((module) => outcomes.get(module.id)!);
  }
}

export function createAgentEngine(modules: readonly AgentModule[]): AgentEngine {
  return new AgentEngine(modules);
}

export function getAgentCatalog() {
  return AGENT_CATALOG;
}
