import type {
  AgentModule,
  HistoricalMarketDataInput,
  MarketDataAnalysis,
  MarketDataCandle,
} from "../types";

export class AgentInputValidationError extends Error {
  readonly code = "INVALID_HISTORICAL_DATA";
  readonly issues: string[];

  constructor(issues: string[]) {
    super("Historical OHLCV data failed validation.");
    this.name = "AgentInputValidationError";
    this.issues = issues;
  }
}

function isCalendarDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function round(value: number): number {
  return Number(value.toFixed(8));
}

function validateInput(input: HistoricalMarketDataInput): string[] {
  const candles = input.candles;
  const issues: string[] = [];
  const dates = new Set<string>();

  if (!/^[A-Za-z0-9&._-]{1,20}$/.test(input.symbol.trim())) {
    issues.push("Symbol must contain 1–20 letters, numbers, dots, dashes, or underscores.");
  }
  if (!Array.isArray(candles) || candles.length < 2 || candles.length > 10_000) {
    issues.push("Provide between 2 and 10,000 historical candles.");
    return issues;
  }
  const window = input.movingAverageWindow ?? 20;
  if (!Number.isInteger(window) || window < 2 || window > 250) {
    issues.push("Moving average window must be an integer from 2 to 250.");
  }

  candles.forEach((candle, index) => {
    const row = index + 1;
    if (!isCalendarDate(candle.date)) {
      issues.push(`Row ${row}: date must be a real YYYY-MM-DD calendar date.`);
    }
    if (dates.has(candle.date)) {
      issues.push(`Row ${row}: duplicate date ${candle.date}.`);
    }
    dates.add(candle.date);

    const prices = [candle.open, candle.high, candle.low, candle.close];
    if (prices.some((price) => !Number.isFinite(price) || price <= 0)) {
      issues.push(`Row ${row}: OHLC prices must be finite positive numbers.`);
    } else {
      if (candle.high < candle.low) {
        issues.push(`Row ${row}: high must be greater than or equal to low.`);
      }
      if (candle.high < Math.max(candle.open, candle.close)) {
        issues.push(`Row ${row}: high must be at least the open and close.`);
      }
      if (candle.low > Math.min(candle.open, candle.close)) {
        issues.push(`Row ${row}: low must be no greater than the open and close.`);
      }
    }
    if (!Number.isFinite(candle.volume) || candle.volume < 0) {
      issues.push(`Row ${row}: volume must be a finite non-negative number.`);
    }
  });

  return issues;
}

export function analyzeHistoricalMarketData(
  input: HistoricalMarketDataInput,
): MarketDataAnalysis {
  const issues = validateInput(input);
  if (issues.length > 0) throw new AgentInputValidationError(issues);

  const candles = [...input.candles].sort((left, right) =>
    left.date.localeCompare(right.date),
  );
  const window = input.movingAverageWindow ?? 20;
  const warnings: string[] = [];

  if (candles.some((candle, index) => candle.date !== input.candles[index]?.date)) {
    warnings.push("Input rows were out of date order and were sorted for analysis.");
  }

  const latestWindow =
    candles.length >= window ? candles.slice(candles.length - window) : null;
  if (!latestWindow) {
    warnings.push(
      `Only ${candles.length} observations were supplied; a ${window}-period moving average is unavailable.`,
    );
  }

  const first = candles[0];
  const last = candles[candles.length - 1];
  const averageVolume =
    candles.reduce((total, candle) => total + candle.volume, 0) / candles.length;
  const latestMovingAverage = latestWindow
    ? latestWindow.reduce((total, candle) => total + candle.close, 0) / window
    : null;

  return {
    symbol: input.symbol.trim().toUpperCase(),
    recordCount: candles.length,
    startDate: first.date,
    endDate: last.date,
    firstClose: first.close,
    lastClose: last.close,
    priceChangePct: round(((last.close - first.close) / first.close) * 100),
    highestHigh: Math.max(...candles.map((candle) => candle.high)),
    lowestLow: Math.min(...candles.map((candle) => candle.low)),
    averageVolume: round(averageVolume),
    movingAverageWindow: window,
    latestMovingAverage:
      latestMovingAverage === null ? null : round(latestMovingAverage),
    warnings,
  };
}

export const marketDataAgent: AgentModule = {
  id: "market-data",
  readiness: "ready",
  dependsOn: [],
  run: ({ input }) => analyzeHistoricalMarketData(input),
};
