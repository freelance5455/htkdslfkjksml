export type HistoricalSource = "csv_upload" | "demo_fixture";

export interface MarketDataCandle {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface HistoricalMarketDataInput {
  symbol: string;
  mode: "historical";
  source: HistoricalSource;
  movingAverageWindow?: number;
  candles: MarketDataCandle[];
}

export interface MarketDataAnalysis {
  symbol: string;
  recordCount: number;
  startDate: string;
  endDate: string;
  firstClose: number;
  lastClose: number;
  priceChangePct: number;
  highestHigh: number;
  lowestLow: number;
  averageVolume: number;
  movingAverageWindow: number;
  latestMovingAverage: number | null;
  warnings: string[];
}

export interface AgentContext {
  input: HistoricalMarketDataInput;
  dependencies: Readonly<Record<string, unknown>>;
}

export interface AgentModule {
  id: string;
  readiness: "ready" | "planned";
  dependsOn: readonly string[];
  run(context: AgentContext): unknown | Promise<unknown>;
}

export interface AgentRunError {
  code: string;
  message: string;
  issues: string[];
}

export interface AgentExecutionOutcome {
  agentId: string;
  status: "completed" | "failed";
  startedAt: string;
  completedAt: string;
  durationMs: number;
  output: unknown | null;
  error: AgentRunError | null;
}

export interface AgentCatalogEntry {
  id: string;
  name: string;
  responsibility: string;
}
