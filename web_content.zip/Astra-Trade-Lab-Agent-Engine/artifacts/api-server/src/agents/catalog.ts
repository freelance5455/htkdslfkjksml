import type { AgentCatalogEntry } from "./types";

export const AGENT_CATALOG: readonly AgentCatalogEntry[] = [
  {
    id: "market-data",
    name: "Market Data Agent",
    responsibility:
      "Validate, normalize, and summarize uploaded historical OHLCV data.",
  },
  {
    id: "technical-analysis",
    name: "Technical Analysis Agent",
    responsibility:
      "Calculate technical indicators from validated historical price data.",
  },
  {
    id: "fundamental-analysis",
    name: "Fundamental Analysis Agent",
    responsibility:
      "Review sourced company fundamentals and report data limitations.",
  },
  {
    id: "news-macro",
    name: "News & Macro Agent",
    responsibility:
      "Summarize sourced historical news and macroeconomic context.",
  },
  {
    id: "market-sentiment",
    name: "Market Sentiment Agent",
    responsibility:
      "Assess sentiment only from explicitly supplied, attributable inputs.",
  },
  {
    id: "risk-management",
    name: "Risk Management Agent",
    responsibility:
      "Evaluate historical exposure and clearly stated risk assumptions.",
  },
  {
    id: "strategy-backtesting",
    name: "Strategy & Backtesting Agent",
    responsibility:
      "Evaluate rule-based strategies against historical data only.",
  },
  {
    id: "portfolio-analysis",
    name: "Portfolio Analysis Agent",
    responsibility:
      "Summarize a supplied portfolio against historical market inputs.",
  },
  {
    id: "chief-research-orchestrator",
    name: "Chief Research / Orchestrator Agent",
    responsibility:
      "Coordinate completed agent outputs and surface conflicts without filling missing results.",
  },
];
