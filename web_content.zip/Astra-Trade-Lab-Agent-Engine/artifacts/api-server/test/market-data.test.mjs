import assert from "node:assert/strict";
import test from "node:test";
import {
  AgentInputValidationError,
  analyzeHistoricalMarketData,
  marketDataAgent,
} from "../src/agents/market-data/agent.ts";
import { AgentEngine } from "../src/agents/engine.ts";

const validInput = {
  symbol: "DEMO",
  mode: "historical",
  source: "csv_upload",
  movingAverageWindow: 2,
  candles: [
    {
      date: "2024-01-02",
      open: 105,
      high: 112,
      low: 103,
      close: 110,
      volume: 1200,
    },
    {
      date: "2024-01-01",
      open: 99,
      high: 106,
      low: 98,
      close: 100,
      volume: 800,
    },
  ],
};

test("normalizes chronological order and calculates descriptive OHLCV metrics", () => {
  const result = analyzeHistoricalMarketData(validInput);

  assert.equal(result.symbol, "DEMO");
  assert.equal(result.startDate, "2024-01-01");
  assert.equal(result.endDate, "2024-01-02");
  assert.equal(result.recordCount, 2);
  assert.equal(result.firstClose, 100);
  assert.equal(result.lastClose, 110);
  assert.equal(result.priceChangePct, 10);
  assert.equal(result.averageVolume, 1000);
  assert.equal(result.latestMovingAverage, 105);
  assert.match(result.warnings[0], /sorted/i);
});

test("rejects duplicate dates with a field-level validation issue", () => {
  const duplicateInput = {
    ...validInput,
    candles: [validInput.candles[0], validInput.candles[0]],
  };

  assert.throws(
    () => analyzeHistoricalMarketData(duplicateInput),
    (error) =>
      error instanceof AgentInputValidationError &&
      error.issues.some((issue) => /duplicate date/i.test(issue)),
  );
});

test("rejects impossible OHLC ranges instead of returning fabricated analysis", () => {
  const invalidInput = {
    ...validInput,
    candles: [
      { ...validInput.candles[0], high: 104 },
      validInput.candles[1],
    ],
  };

  assert.throws(
    () => analyzeHistoricalMarketData(invalidInput),
    (error) =>
      error instanceof AgentInputValidationError &&
      error.issues.some((issue) => /high must/i.test(issue)),
  );
});

test("reports an unavailable moving average when there is not enough history", () => {
  const result = analyzeHistoricalMarketData({
    ...validInput,
    movingAverageWindow: 5,
  });

  assert.equal(result.latestMovingAverage, null);
  assert.match(result.warnings.join(" "), /moving average is unavailable/i);
});

test("runs the ready Market Data Agent through the engine", async () => {
  const engine = new AgentEngine([marketDataAgent]);
  const [result] = await engine.runAll(validInput);

  assert.equal(result.agentId, "market-data");
  assert.equal(result.status, "completed");
  assert.equal(result.error, null);
  assert.equal(result.output.priceChangePct, 10);
});

test("runs independent agents in parallel", async () => {
  let started = 0;
  let release;
  let timeoutId;
  const barrier = new Promise((resolve) => {
    release = resolve;
  });
  const runner = async () => {
    started += 1;
    if (started === 2) release();
    await barrier;
    return { completed: true };
  };
  const engine = new AgentEngine([
    { id: "first", readiness: "ready", dependsOn: [], run: runner },
    { id: "second", readiness: "ready", dependsOn: [], run: runner },
  ]);
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(
      () => reject(new Error("Independent agents were not dispatched together.")),
      1000,
    );
  });

  try {
    const outcomes = await Promise.race([engine.runAll(validInput), timeout]);
    assert.equal(started, 2);
    assert.deepEqual(
      outcomes.map((outcome) => outcome.status),
      ["completed", "completed"],
    );
  } finally {
    clearTimeout(timeoutId);
  }
});

test("passes completed dependency output and isolates failed agents", async () => {
  const engine = new AgentEngine([
    {
      id: "source",
      readiness: "ready",
      dependsOn: [],
      run: () => ({ evidence: "validated" }),
    },
    {
      id: "dependent",
      readiness: "ready",
      dependsOn: ["source"],
      run: ({ dependencies }) => ({ source: dependencies.source }),
    },
    {
      id: "independent-failure",
      readiness: "ready",
      dependsOn: [],
      run: () => {
        throw new Error("expected test failure");
      },
    },
    {
      id: "blocked",
      readiness: "ready",
      dependsOn: ["independent-failure"],
      run: () => {
        throw new Error("a failed dependency must not be run");
      },
    },
    {
      id: "future-agent",
      readiness: "planned",
      dependsOn: [],
      run: () => ({ shouldNotRun: true }),
    },
  ]);

  const outcomes = await engine.runAll(validInput);
  const byId = new Map(outcomes.map((outcome) => [outcome.agentId, outcome]));

  assert.deepEqual(byId.get("dependent").output, {
    source: { evidence: "validated" },
  });
  assert.equal(byId.get("independent-failure").status, "failed");
  assert.equal(byId.get("blocked").error.code, "DEPENDENCY_FAILED");
  assert.equal(byId.has("future-agent"), false);
});
