import { useMemo, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  ArrowLeft,
  BarChart3,
  Check,
  Clock3,
  Database,
  FileSpreadsheet,
  LoaderCircle,
  RefreshCw,
  ShieldAlert,
  Upload,
} from 'lucide-react';
import {
  getGetAgentRunQueryKey,
  getHealthCheckQueryKey,
  getListAgentsQueryKey,
  getListAgentRunsQueryKey,
  useGetAgentRun,
  useHealthCheck,
  useListAgents,
  useListAgentRuns,
  useRunAllAvailableAgents,
  useRunMarketDataAgent,
  type AgentRun,
  type MarketDataCandle,
  type MarketDataRunInput,
} from '@workspace/api-client-react';

type ParsedFile = {
  candles: MarketDataCandle[];
  errors: string[];
  fileName: string;
};

const EXPECTED_HEADERS = ['date', 'open', 'high', 'low', 'close', 'volume'];

function parseCsvRows(text: string) {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (char === '"' && text[i + 1] === '"' && quoted) {
      cell += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === ',' && !quoted) {
      row.push(cell.trim());
      cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && text[i + 1] === '\n') i += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}

async function readCsv(file: File): Promise<ParsedFile> {
  const errors: string[] = [];
  const rows = parseCsvRows(await file.text());
  if (!rows.length) return { candles: [], errors: ['The selected CSV is empty.'], fileName: file.name };
  const headers = rows[0].map((value) => value.toLowerCase());
  if (EXPECTED_HEADERS.some((header, index) => headers[index] !== header) || headers.length !== EXPECTED_HEADERS.length) {
    return {
      candles: [],
      errors: ['CSV header must be exactly: date,open,high,low,close,volume.'],
      fileName: file.name,
    };
  }
  const candles: MarketDataCandle[] = [];
  rows.slice(1).forEach((cells, index) => {
    const line = index + 2;
    if (cells.length !== EXPECTED_HEADERS.length) {
      errors.push(`Row ${line}: expected 6 comma-separated values.`);
      return;
    }
    const [date, openRaw, highRaw, lowRaw, closeRaw, volumeRaw] = cells;
    const dateValue = new Date(date);
    const values = [openRaw, highRaw, lowRaw, closeRaw, volumeRaw].map(Number);
    if (!date || Number.isNaN(dateValue.getTime())) errors.push(`Row ${line}: date is not a valid date.`);
    if (values.some((value) => !Number.isFinite(value))) errors.push(`Row ${line}: OHLCV values must be numeric.`);
    if (values.slice(0, 4).some((value) => value <= 0) || values[4] < 0) errors.push(`Row ${line}: prices must be above zero and volume cannot be negative.`);
    if (values[1] < Math.max(values[0], values[2], values[3]) || values[2] > Math.min(values[0], values[1], values[3])) errors.push(`Row ${line}: high/low values do not contain the open and close prices.`);
    if (errors.some((error) => error.startsWith(`Row ${line}:`))) return;
    candles.push({
      date: /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : dateValue.toISOString().slice(0, 10),
      open: values[0],
      high: values[1],
      low: values[2],
      close: values[3],
      volume: values[4],
    });
  });
  if (candles.length < 2) errors.push('At least two valid historical candles are required.');
  if (candles.length > 10000) errors.push('A maximum of 10,000 candles can be analyzed at a time.');
  return { candles, errors: errors.slice(0, 8), fileName: file.name };
}

function formatDate(value?: string | null) {
  if (!value) return 'Not yet';
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function formatDuration(value?: number | null) {
  if (value == null) return '—';
  return value < 1000 ? `${value} ms` : `${(value / 1000).toFixed(2)} s`;
}

function number(value?: number | null, digits = 2) {
  if (value == null || !Number.isFinite(value)) return '—';
  return new Intl.NumberFormat('en-IN', { maximumFractionDigits: digits }).format(value);
}

function ErrorMessage({ error }: { error: unknown }) {
  const message = error instanceof Error ? error.message : 'The request could not be completed.';
  return <div className="validation-box" role="alert" data-testid="status-api-error"><strong>Could not load data</strong>{message}</div>;
}

export default function AgentsPage({ onClose }: { onClose?: () => void } = {}) {
  const queryClient = useQueryClient();
  const fileInput = useRef<HTMLInputElement>(null);
  const [symbol, setSymbol] = useState('');
  const [windowSize, setWindowSize] = useState('20');
  const [parsed, setParsed] = useState<ParsedFile | null>(null);
  const [dragging, setDragging] = useState(false);
  const [localError, setLocalError] = useState('');
  const [selectedRunId, setSelectedRunId] = useState('');
  const agentsQuery = useListAgents({ query: { queryKey: getListAgentsQueryKey() } });
  const runsQuery = useListAgentRuns({ limit: 8 }, { query: { queryKey: getListAgentRunsQueryKey({ limit: 8 }) } });
  const healthQuery = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), retry: 1 } });
  const detailQuery = useGetAgentRun(selectedRunId, { query: { enabled: Boolean(selectedRunId), queryKey: getGetAgentRunQueryKey(selectedRunId || 'none') } });
  const runMarket = useRunMarketDataAgent();
  const runAll = useRunAllAvailableAgents();

  const agentList = agentsQuery.data ?? [];
  const marketAgent = agentList.find((agent) => agent.id === 'market_data') ?? agentList.find((agent) => agent.name.toLowerCase().includes('market data'));
  const availableAgents = agentList.filter((agent) => agent.readiness === 'ready');
  const runs = runsQuery.data?.items ?? [];
  const currentRun = detailQuery.data ?? null;
  const currentRunPending = runMarket.isPending || runAll.isPending;
  const previewRows = useMemo(() => parsed?.candles.slice(0, 5) ?? [], [parsed]);

  const acceptFile = async (file?: File) => {
    if (!file) return;
    setLocalError('');
    setSelectedRunId('');
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setParsed({ candles: [], errors: ['Choose a .csv file containing historical OHLCV candles.'], fileName: file.name });
      return;
    }
    try {
      setParsed(await readCsv(file));
    } catch {
      setParsed({ candles: [], errors: ['This file could not be read as text.'], fileName: file.name });
    }
  };

  const createInput = (): MarketDataRunInput | null => {
    if (!parsed || parsed.errors.length || parsed.candles.length < 2) {
      setLocalError('Upload a valid CSV with at least two historical OHLCV records before running an agent.');
      return null;
    }
    const cleanSymbol = symbol.trim();
    if (!/^[A-Za-z0-9&._-]{1,20}$/.test(cleanSymbol)) {
      setLocalError('Enter a symbol using 1–20 letters, numbers, &, ., _, or -.');
      return null;
    }
    const movingAverageWindow = Number(windowSize);
    if (!Number.isInteger(movingAverageWindow) || movingAverageWindow < 2 || movingAverageWindow > 250) {
      setLocalError('Moving average window must be a whole number from 2 to 250.');
      return null;
    }
    setLocalError('');
    return { symbol: cleanSymbol.toUpperCase(), mode: 'historical', source: 'csv_upload', movingAverageWindow, candles: parsed.candles };
  };

  const afterRun = (run: AgentRun) => {
    setSelectedRunId(run.id);
    void queryClient.invalidateQueries({ queryKey: getListAgentRunsQueryKey({ limit: 8 }) });
    void queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
  };

  const executeMarket = () => {
    const input = createInput();
    if (input) runMarket.mutate({ data: input }, { onSuccess: afterRun });
  };

  const executeAll = () => {
    const input = createInput();
    if (!input) return;
    runAll.mutate({ data: input }, {
      onSuccess: (result) => {
        const firstRun = result.items?.[0];
        if (firstRun) afterRun(firstRun);
        else {
          void queryClient.invalidateQueries({ queryKey: getListAgentRunsQueryKey({ limit: 8 }) });
          void queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
        }
      },
    });
  };

  const retryQueries = () => {
    void queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getListAgentRunsQueryKey({ limit: 8 }) });
    void queryClient.invalidateQueries({ queryKey: getHealthCheckQueryKey() });
  };

  const selectedRun = currentRun ?? (selectedRunId ? runs.find((run) => run.id === selectedRunId) ?? null : null);
  const runError = runMarket.error ?? runAll.error;
  const healthOkay = healthQuery.data?.status?.toLowerCase() === 'ok' || healthQuery.data?.status?.toLowerCase() === 'healthy';

  return (
    <main className="agents-page">
      <header className="agents-topbar">
        <div className="brand-lockup" data-testid="text-brand">
          <div className="brand-glyph" aria-hidden="true">A</div>
          <div>Astra Trade Lab<div className="brand-sub">Research systems</div></div>
        </div>
        <button type="button" className="back-link" onClick={onClose ?? (() => window.location.assign('/'))} data-testid="link-return-dashboard"><ArrowLeft size={14} /> Return to dashboard</button>
      </header>

      <div className="agents-content">
        <div className="eyebrow">Research operations / Agents</div>
        <div className="hero-row">
          <div>
            <h1>AI Agents Control Center</h1>
            <p>Run deterministic analysis on your own historical OHLCV data. Review execution history, validation and outputs in one place.</p>
          </div>
          <div className="health-pill" data-testid="status-api-health">
            <span className={`status-dot ${healthQuery.isError ? 'is-down' : ''}`} />
            {healthQuery.isLoading ? 'Checking services' : healthQuery.isError ? 'Service unavailable' : healthOkay ? 'API operational' : `API ${healthQuery.data?.status ?? 'connected'}`}
          </div>
        </div>

        <div className="warning-strip" data-testid="text-scope-notice">
          <ShieldAlert size={17} />
          <div><strong>Historical research only</strong>Uses uploaded historical candles only. No live price feeds, real-time signals, or order execution.</div>
        </div>

        {(agentsQuery.isError || runsQuery.isError || healthQuery.isError) && (
          <div className="panel agent-body" role="alert">
            <ErrorMessage error={agentsQuery.error ?? runsQuery.error ?? healthQuery.error} />
            <button className="button secondary" onClick={retryQueries} data-testid="button-retry-queries"><RefreshCw size={13} /> Retry loading</button>
          </div>
        )}

        <section className="overview-grid">
          <article className="panel">
            <div className="panel-head">
              <div><h2>Agent readiness</h2><p>Only agents marked ready can execute.</p></div>
              <span className="section-kicker">{agentList.length ? `${availableAgents.length} ready` : 'Inventory'}</span>
            </div>
            {agentsQuery.isLoading ? (
              <div className="loading-skeleton" data-testid="loading-agent-inventory"><div className="skeleton" /><div className="skeleton" /><div className="skeleton" /></div>
            ) : agentsQuery.isError ? (
              <div className="empty-history"><Activity size={22} /><strong>Agent inventory unavailable</strong><span>Use retry to check the service again.</span></div>
            ) : agentList.length === 0 ? (
              <div className="empty-history" data-testid="empty-agent-inventory"><Activity size={22} /><strong>No agents configured</strong><span>The service returned an empty agent inventory.</span></div>
            ) : (
              <div className="agent-body">
                {agentList.map((agent) => {
                  const ready = agent.readiness === 'ready';
                  const isMarket = agent === marketAgent;
                  const displayedStatus = isMarket && currentRunPending ? 'running' : agent.status;
                  const statusLabel = displayedStatus.charAt(0).toUpperCase() + displayedStatus.slice(1);
                  return (
                    <div className="agent-entry" key={agent.id} data-testid={`card-agent-${agent.id}`}>
                      <div className="agent-title-line">
                        <div className="agent-icon">{isMarket ? <Database size={17} /> : <Activity size={17} />}</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <h3 data-testid={`text-agent-name-${agent.id}`}>{agent.name}</h3>
                          <p>{agent.responsibility}</p>
                        </div>
                        <span className={`agent-status ${displayedStatus}`} data-testid={`status-agent-${agent.id}`}>
                          <span className="status-dot" />{statusLabel}
                        </span>
                      </div>
                      <p className="agent-summary">
                        {isMarket ? 'Analyzes historical OHLCV uploads: validates candles and produces a compact market-data summary.' : 'Planned capability. This agent is not executable and has no execution results.'}
                      </p>
                      <div className="metric-grid">
                        <div className="metric"><div className="metric-label">Total runs</div><div className="metric-value">{agent.performance.totalRuns}</div></div>
                        <div className="metric"><div className="metric-label">Success / failed</div><div className="metric-value">{agent.performance.successfulRuns} / {agent.performance.failedRuns}</div></div>
                        <div className="metric"><div className="metric-label">Avg duration</div><div className="metric-value">{formatDuration(agent.performance.averageDurationMs)}</div></div>
                      </div>
                      <div className="input-help" style={{ marginTop: 13 }}>
                        <span>Last execution</span>
                        <span data-testid={`text-agent-last-execution-${agent.id}`}>{formatDate(agent.lastExecutionAt)} · {formatDuration(agent.lastDurationMs)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </article>

          <article className="panel history-panel">
            <div className="panel-head">
              <div><h2>Execution history</h2><p>Recent agent runs</p></div>
              <button className="text-button" onClick={retryQueries} data-testid="button-refresh-history"><RefreshCw size={12} /> Refresh</button>
            </div>
            {runsQuery.isLoading ? (
              <div className="loading-skeleton" data-testid="loading-execution-history"><div className="skeleton" /><div className="skeleton" /><div className="skeleton" /></div>
            ) : runsQuery.isError ? (
              <div className="empty-history" data-testid="error-execution-history"><Activity size={22} /><strong>History could not load</strong><span>Retry to reload recent executions.</span></div>
            ) : runs.length === 0 ? (
              <div className="empty-history" data-testid="empty-execution-history"><Clock3 size={22} /><strong>No executions yet</strong><span>Upload a historical CSV to create the first analysis run.</span></div>
            ) : (
              <div className="history-list">
                {runs.map((run) => (
                  <div className="history-row" key={run.id} data-testid={`row-agent-run-${run.id}`}>
                    <div className="history-main">
                      <span className={`run-badge ${run.status}`}><span className="status-dot" style={run.status === 'failed' ? { background: '#d87c75', boxShadow: 'none' } : undefined} />{run.status}</span>
                      <div className="history-name"><strong>{run.inputSummary.symbol}</strong><span>{formatDate(run.startedAt)} · {run.mode}</span></div>
                    </div>
                    <div className="history-meta">{formatDuration(run.durationMs)}<br /><button className="text-button" onClick={() => setSelectedRunId(run.id)} data-testid={`button-view-run-${run.id}`}>View run</button></div>
                  </div>
                ))}
              </div>
            )}
          </article>
        </section>

        <section className="workspace-grid">
          <article className="panel">
            <div className="panel-head">
              <div><h2>Historical data input</h2><p>CSV · Daily or intraday OHLCV candles</p></div>
              <span className="section-kicker">CSV upload</span>
            </div>
            <div className="upload-inner">
              <div className="input-row">
                <div><label className="field-label" htmlFor="symbol-field">Instrument symbol</label><input id="symbol-field" className="field-control" value={symbol} onChange={(event) => setSymbol(event.target.value)} placeholder="e.g. RELIANCE" maxLength={20} data-testid="input-symbol" /></div>
                <div><label className="field-label" htmlFor="ma-window">MA window</label><input id="ma-window" className="field-control" type="number" min="2" max="250" value={windowSize} onChange={(event) => setWindowSize(event.target.value)} data-testid="input-ma-window" /></div>
              </div>
              <label
                className={`drop-zone ${dragging ? 'is-dragging' : ''}`}
                onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                onDragLeave={() => setDragging(false)}
                onDrop={(event) => { event.preventDefault(); setDragging(false); void acceptFile(event.dataTransfer.files[0]); }}
                data-testid="upload-csv-zone"
              >
                <input ref={fileInput} type="file" accept=".csv,text/csv" onChange={(event) => void acceptFile(event.target.files?.[0])} data-testid="input-csv-file" />
                <div><Upload size={19} className="drop-icon" /><strong>{parsed?.fileName ?? 'Drop a CSV here, or choose a file'}</strong><span>{parsed ? `${parsed.candles.length} valid records parsed` : 'date,open,high,low,close,volume · up to 10,000 rows'}</span></div>
              </label>
              <div className="input-help"><span>Historical data only</span><span>Maximum 10,000 candles</span></div>

              {parsed?.errors.length ? <div className="validation-box" role="alert" data-testid="status-csv-validation"><strong>CSV validation needs attention</strong><ul>{parsed.errors.map((error, index) => <li key={`${error}-${index}`}>{error}</li>)}</ul></div> : null}
              {localError && <div className="validation-box" role="alert" data-testid="status-input-validation"><strong>Check the run inputs</strong>{localError}</div>}
              {parsed && parsed.candles.length > 0 && !parsed.errors.length && (
                <div className="preview-wrap" data-testid="table-csv-preview">
                  <div className="preview-head"><span><FileSpreadsheet size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />CSV preview</span><span>{parsed.candles.length} candles · first 5 shown</span></div>
                  <div className="preview-scroll"><table className="preview-table"><thead><tr>{EXPECTED_HEADERS.map((header) => <th key={header}>{header}</th>)}</tr></thead><tbody>{previewRows.map((candle, index) => <tr key={`${candle.date}-${index}`}><td>{candle.date}</td><td>{number(candle.open)}</td><td>{number(candle.high)}</td><td>{number(candle.low)}</td><td>{number(candle.close)}</td><td>{number(candle.volume, 0)}</td></tr>)}</tbody></table></div>
                </div>
              )}
              <div className="agent-toolbar">
                <button className="button" onClick={executeMarket} disabled={currentRunPending || agentsQuery.isLoading || !marketAgent || marketAgent.readiness !== 'ready'} data-testid="button-run-market-data">
                  {runMarket.isPending ? <LoaderCircle size={14} className="spin" /> : <BarChart3 size={14} />}Run Market Data
                </button>
                <button className="button secondary" onClick={executeAll} disabled={currentRunPending || availableAgents.length === 0} data-testid="button-run-all-agents">
                  {runAll.isPending ? <LoaderCircle size={14} className="spin" /> : <Activity size={14} />}Run All Agents
                </button>
              </div>
              <div className="input-help" style={{ marginTop: 9 }}><span>Run All uses the same CSV and only dispatches agents currently marked ready.</span></div>
              {runError && <div className="validation-box" role="alert" data-testid="status-run-error"><strong>Run failed to start</strong>{runError instanceof Error ? runError.message : 'The agent service returned an error.'}</div>}
            </div>
          </article>

          <article className="panel">
            <div className="panel-head">
              <div><h2>Run detail</h2><p>{selectedRun ? `Execution ${selectedRun.id}` : 'Output and validation details'}</p></div>
              {selectedRun && <span className={`run-badge ${selectedRun.status}`} data-testid="status-selected-run">{selectedRun.status}</span>}
            </div>
            {currentRunPending ? (
              <div className="loading-skeleton" data-testid="loading-run-detail"><div className="skeleton" /><div className="skeleton" /><div className="skeleton" /></div>
            ) : selectedRun ? (
              <RunDetail run={selectedRun} />
            ) : (
              <div className="result-content">
                {detailQuery.isError && <ErrorMessage error={detailQuery.error} />}
                <div className="result-empty" data-testid="empty-run-detail"><div><BarChart3 size={23} /><strong>Analysis appears here</strong><span>Choose a previous execution or run the Market Data Agent on an uploaded CSV. Results are calculated from that historical file only.</span></div></div>
              </div>
            )}
          </article>
        </section>

        <footer className="page-foot"><span><strong>ASTRA / RESEARCH SYSTEMS</strong> · Historical analysis workspace</span><span>Market data agent · deterministic processing</span></footer>
      </div>
    </main>
  );
}

function RunDetail({ run }: { run: AgentRun }) {
  if (run.status === 'running') {
    return (
      <div className="result-content" data-testid="panel-run-running">
        <div className="running-state">
          <LoaderCircle size={20} className="spin" />
          <div><strong>Agent is running</strong><span>Historical input is being validated and analyzed.</span></div>
        </div>
        <div className="input-help" style={{ marginTop: 14 }}>
          <span>Input · {run.inputSummary.symbol} · {run.inputSummary.recordCount} candles</span>
          <span>Started {formatDate(run.startedAt)}</span>
        </div>
      </div>
    );
  }
  if (run.status === 'failed' || run.error) {
    return (
      <div className="result-content fade-in" data-testid="panel-run-failed">
        <div className="result-error"><h3>Execution failed · {run.error?.code ?? 'UNKNOWN'}</h3><p>{run.error?.message ?? 'The execution failed without a detailed message.'}</p>
          {run.error?.issues.length ? <ul>{run.error.issues.map((issue, index) => <li key={`${issue}-${index}`}>{issue}</li>)}</ul> : null}
        </div>
        <div className="input-help" style={{ marginTop: 14 }}><span>Input · {run.inputSummary.symbol} · {run.inputSummary.recordCount} candles · {run.inputSummary.source}</span><span>{formatDuration(run.durationMs)}</span></div>
      </div>
    );
  }
  const output = run.output;
  if (!output) {
    return <div className="result-content"><div className="result-empty" data-testid="empty-run-output"><div><Activity size={22} /><strong>No output was returned</strong><span>The completed record does not contain an analysis payload.</span></div></div></div>;
  }
  return (
    <div className="result-content fade-in" data-testid="panel-run-completed">
      <div className="result-top">
        <div><div className="result-symbol" data-testid="text-result-symbol">{output.symbol}</div><div className="result-date">{output.startDate} → {output.endDate}</div></div>
        <div><div className={`change-value ${output.priceChangePct < 0 ? 'negative' : ''}`} data-testid="text-price-change">{output.priceChangePct > 0 ? '+' : ''}{number(output.priceChangePct)}%</div><div className="change-caption">period change</div></div>
      </div>
      <div className="input-help" style={{ marginBottom: 13 }}><span>Historical CSV · {run.inputSummary.recordCount} records · MA {run.inputSummary.movingAverageWindow}</span><span>{formatDuration(run.durationMs)}</span></div>
      <div className="result-metrics">
        <div className="result-metric"><span>First close</span><strong>{number(output.firstClose)}</strong></div>
        <div className="result-metric"><span>Latest close</span><strong>{number(output.lastClose)}</strong></div>
        <div className="result-metric"><span>Highest high</span><strong>{number(output.highestHigh)}</strong></div>
        <div className="result-metric"><span>Lowest low</span><strong>{number(output.lowestLow)}</strong></div>
        <div className="result-metric"><span>Average volume</span><strong>{number(output.averageVolume, 0)}</strong></div>
        <div className="result-metric"><span>Latest moving average</span><strong>{number(output.latestMovingAverage)}</strong></div>
      </div>
      <div className="input-help" style={{ marginTop: 13 }}><span>Started {formatDate(run.startedAt)}</span><span>Completed {formatDate(run.completedAt)}</span></div>
      {output.warnings.length > 0 && <div className="result-warnings" data-testid="status-run-warnings"><strong>Analysis notes</strong><ul>{output.warnings.map((warning, index) => <li key={`${warning}-${index}`}>{warning}</li>)}</ul></div>}
      <div className="run-badge completed" style={{ marginTop: 13 }}><Check size={11} /> Historical summary ready</div>
    </div>
  );
}
