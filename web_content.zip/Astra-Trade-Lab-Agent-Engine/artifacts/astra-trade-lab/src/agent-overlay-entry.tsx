import { useState } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import AgentsPage from "./pages/agents";
import "./index.css";

const queryClient = new QueryClient();
const mount = document.createElement("div");
mount.id = "astra-agent-overlay-root";
document.body.appendChild(mount);

function AgentOverlay() {
  const [isOpen, setIsOpen] = useState(
    () => window.location.pathname === "/agents",
  );
  const directRoute = window.location.pathname === "/agents";

  const close = () => {
    if (directRoute) {
      window.location.assign("/");
      return;
    }
    setIsOpen(false);
  };

  return (
    <>
      {!isOpen && (
        <button
          type="button"
          className="legacy-agents-link"
          onClick={() => setIsOpen(true)}
          data-testid="link-agents-control-center"
        >
          <span className="brand-glyph" aria-hidden="true">
            A
          </span>
          AI Agents
        </button>
      )}
      {isOpen && <AgentsPage onClose={close} />}
    </>
  );
}

createRoot(mount).render(
  <QueryClientProvider client={queryClient}>
    <AgentOverlay />
  </QueryClientProvider>,
);
