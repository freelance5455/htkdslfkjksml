import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import {
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const agentRunsTable = pgTable(
  "agent_runs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    agentId: text("agent_id").notNull(),
    status: text("status").notNull(),
    mode: text("mode").notNull().default("historical"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    durationMs: integer("duration_ms"),
    inputSummary: jsonb("input_summary")
      .$type<Record<string, unknown>>()
      .notNull(),
    output: jsonb("output").$type<Record<string, unknown> | null>(),
    error: jsonb("error").$type<Record<string, unknown> | null>(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("agent_runs_agent_started_idx").on(table.agentId, table.startedAt),
    index("agent_runs_started_idx").on(table.startedAt),
  ],
);

export const insertAgentRunSchema = createInsertSchema(agentRunsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertAgentRun = z.infer<typeof insertAgentRunSchema>;
export type AgentRunRecord = typeof agentRunsTable.$inferSelect;
