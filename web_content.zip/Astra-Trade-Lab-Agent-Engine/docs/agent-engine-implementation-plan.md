# Astra Trade Lab agent-engine plan

## Audit findings

- The supplied ZIP is a compiled React interface, not an editable source repository.
- The dashboard is preserved under `artifacts/astra-trade-lab/public/legacy/` and remains available from the app's home route.
- The project already has a shared Express API server, an OpenAPI/codegen pipeline, and a PostgreSQL/Drizzle package.
- The ZIP contains no agent engine, server endpoints, persisted execution history, test suite, or APK build configuration.

## Stage 1: Agent Engine foundation and Market Data Agent

1. Keep the uploaded dashboard unchanged and add a small entry into the Agent Control Center.
2. Register all nine requested agent responsibilities. Only Market Data Agent is executable in this stage; the other eight stay explicitly marked Planned.
3. Add a modular engine that runs ready agents, honors declared dependencies, runs independent agents concurrently, and records failures without inventing outputs.
4. Implement Market Data Agent for historical OHLCV input only: validate dates and price ranges, normalize chronological order, calculate a small descriptive summary, and report limitations.
5. Accept historical CSV data from the interface. Do not connect to a live quote feed, issue live trading signals, or place orders.
6. Persist run status, timing, input summary, result, and structured error details in `agent_runs`. Do not persist the full uploaded candle payload.
7. Cover OHLCV validation, chronological normalization, summary calculations, dependency handling, parallel dispatch, and failure isolation with reproducible tests.

## Initial API surface

- `GET /api/agents` — registry, readiness, latest status, and performance counts.
- `GET /api/agents/runs` — paged execution history.
- `GET /api/agents/runs/{runId}` — one run's input summary, output, and error details.
- `POST /api/agents/market-data/runs` — run the Market Data Agent on supplied historical OHLCV candles.
- `POST /api/agents/runs/all` — dispatch to agents currently marked ready; initially this runs only Market Data Agent.

## Later stages

Implement the remaining eight agents individually with their own input/output schemas, logic, configurable parameters, tests, and evidence. Add conflict analysis and final research-report generation only after multiple real agent outputs exist. Do not label a planned agent complete because its card is visible.

## Data limitation

The uploaded dashboard's built-in market values are fictional UI fixtures, not historical exchange data. Stage 1 therefore accepts user-supplied historical CSV data and labels any demonstration/test fixtures as non-market data. A free, licensed historical dataset can be added when its source and terms are verified.
