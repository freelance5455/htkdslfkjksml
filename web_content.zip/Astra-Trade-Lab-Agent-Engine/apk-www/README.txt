APK ke liye ready web folder (sab paths relative, hash routing -> file:// aur WebView me chalta hai).
- index.html isko web root banao.
- Capacitor: npx cap init Astra com.astra.tradelab --web-dir=apk-www && npx cap add android && npx cap sync && npx cap open android
- PWABuilder / WebIntoApp: is folder ko zip karke ya hosted URL se use karo.
Note: AI Agents screen ko backend (artifacts/api-server) chahiye; dashboard backend ke bina chalta hai.
