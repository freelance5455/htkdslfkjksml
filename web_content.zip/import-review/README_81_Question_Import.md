# Air-Conditioning & Refrigeration — 81-question import package

## Files
- `Aircon_Refrigeration_81_Questions_Import.json`: app bulk-import JSON.
- `Aircon_Refrigeration_81_Questions_Review.csv`: human-review spreadsheet.
- `Aircon_Refrigeration_Problems_Extracted(1).pdf`: supplied reference PDF, with the original Blue Book problem number and source page noted in every record.

## App import
1. Back up your current Engineering Review Quiz data.
2. Use the v2.9.44 build included with this package (or a build with the extended JSON importer) so `boardCategory`, original problem numbers, and source metadata are retained.
3. Open Tools & Backup → Question Bank Management → Bulk Import.
4. Select the JSON and inspect the preview before importing.
5. Import and then export a new backup.

## Classification
- Board category: PIPE
- Subject: Air Conditioning / Refrigeration (topic-specific subjects preserved per item)
- Source: Blue-Book-With-Solution-VIP.pdf; source PDF page is in `sourcePage`; page in the uploaded 87-page extraction is in `sourceExtractedPdfPage`.

## Verification status
81 distinct problems are included, retaining original problem numbers. 65 records are enabled for scoring based on a readable source result or a clearly stated independent calculation; 16 are marked `answerVerified: false` because of source/scan inconsistencies or incomplete work. These will remain practice-only in the app.

Flagged source items: 8, 22, 151, 152, 214, 220, 226, 229, 289, 291, 300, 302, 340, 347, 354, 460.

The source solution image OCR is retained in `sourceSolutionTranscript` for traceability, but OCR mathematical symbols can be imperfect. Use the clean `formula`, `substitution`, `calculation`, `finalAnswer`, `concept`, and `shortcut` fields for studying; always compare flagged items with the PDF before scoring.

## Data-fidelity note
Question wording and choices are taken from the supplied extraction. Source results are preserved when available. Where the source wording or arithmetic disagrees with the worked solution, the record is marked unverified, with the discrepancy called out; no such item should be treated as a confirmed answer key until reconciled.
