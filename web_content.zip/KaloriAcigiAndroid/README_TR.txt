# Kalori Açığı — Android uygulama projesi

Bu proje, HTML kalori hesaplayıcısını Android WebView içinde açan basit bir Android uygulamasıdır.

## APK oluşturma
1. Bilgisayarına Android Studio'yu kur.
2. Android Studio'da **Open** seçeneğiyle bu klasörü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle (Android SDK Platform 35 kurulu olmalı).
4. Menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
5. APK, `app/build/outputs/apk/debug/app-debug.apk` yolunda oluşturulur.

## Not
Bu çalışma ortamında Android SDK/Gradle derleme araçları bulunmadığı için derlenmiş `.apk` dosyasını doğrudan üretemedim. Bu ZIP, Android Studio'da APK'ya dönüştürülebilecek kaynak projedir.
