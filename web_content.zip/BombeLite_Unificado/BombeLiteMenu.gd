extends Control

const BG := Color("#070b12")
const PANEL := Color("#111925")
const PANEL_HOVER := Color("#19283a")
const BLUE := Color("#087cff")
const CYAN := Color("#00d5ff")
const MUTED := Color("#9aabc0")

const APPS := [
	{"name": "WhatsApp", "category": "APPS", "symbol": "WA", "package": "com.whatsapp", "uri": "whatsapp://"},
	{"name": "YouTube", "category": "APPS", "symbol": "YT", "package": "com.google.android.youtube", "uri": "youtube://"},
	{"name": "Play Store", "category": "APPS", "symbol": "▶", "package": "com.android.vending", "uri": "market://"},
	{"name": "Google", "category": "APPS", "symbol": "G", "package": "com.google.android.googlequicksearchbox", "uri": "googleapp://"},
	{"name": "Minecraft", "category": "JOGOS", "symbol": "MC", "package": "com.mojang.minecraftpe", "uri": "minecraft://"},
	{"name": "Roblox", "category": "JOGOS", "symbol": "R", "package": "com.roblox.client", "uri": "roblox://"},
	{"name": "Free Fire", "category": "JOGOS", "symbol": "FF", "package": "com.dts.freefireth", "uri": "freefireth://"},
	{"name": "Stumble Guys", "category": "JOGOS", "symbol": "SG", "package": "com.kitkagames.fallbuddies", "uri": "stumbleguys://"},
	{"name": "Navegador", "category": "NAVEGADOR", "symbol": "WEB", "uri": "https://www.google.com"},
	{"name": "Configurações", "category": "UTILITÁRIOS", "symbol": "CFG", "uri": "android.settings://"},
	{"name": "Bluetooth", "category": "UTILITÁRIOS", "symbol": "ᛒ", "scene": "res://cenas/Bluetooth.tscn"},
	{"name": "Configurações", "category": "UTILITÁRIOS", "symbol": "⚙", "scene": "res://cenas/Configuracoes.tscn"},
	{"name": "Wi-Fi", "category": "INTERNET", "symbol": "◉", "scene": "res://cenas/Wifi.tscn"},
	{"name": "Ver redes", "category": "INTERNET", "symbol": "⌕", "scene": "res://cenas/Wifi.tscn"},
	{"name": "Minecraft", "category": "LOJA", "symbol": "🟩", "package": "com.mojang.minecraftpe", "store_item": true},
	{"name": "Roblox", "category": "LOJA", "symbol": "◇", "package": "com.roblox.client", "store_item": true},
	{"name": "Free Fire", "category": "LOJA", "symbol": "🔥", "package": "com.dts.freefireth", "store_item": true},
	{"name": "GTA: San Andreas", "category": "LOJA", "symbol": "GTA", "package": "com.rockstargames.gtasa", "store_item": true},
	{"name": "Among Us", "category": "LOJA", "symbol": "🚀", "package": "com.innersloth.spacemafia", "store_item": true},
	{"name": "Stumble Guys", "category": "LOJA", "symbol": "🤸", "package": "com.kitkagames.fallbuddies", "store_item": true},
	{"name": "Brawl Stars", "category": "LOJA", "symbol": "⭐", "package": "com.supercell.brawlstars", "store_item": true},
	{"name": "Clash Royale", "category": "LOJA", "symbol": "👑", "package": "com.supercell.clashroyale", "store_item": true},
	{"name": "Subway Surfers", "category": "LOJA", "symbol": "🛹", "package": "com.kiloo.subwaysurf", "store_item": true},
	{"name": "WhatsApp", "category": "LOJA", "symbol": "WA", "package": "com.whatsapp", "store_item": true},
	{"name": "TikTok", "category": "LOJA", "symbol": "♪", "package": "com.zhiliaoapp.musically", "store_item": true},
	{"name": "YouTube", "category": "LOJA", "symbol": "YT", "package": "com.google.android.youtube", "store_item": true},
	{"name": "Google Chrome", "category": "LOJA", "symbol": "🌐", "package": "com.android.chrome", "store_item": true},
	{"name": "Spotify", "category": "LOJA", "symbol": "♫", "package": "com.spotify.music", "store_item": true},
]

const NAV_ITEMS := ["INÍCIO", "INTERNET", "LOJA", "APPS", "JOGOS", "EMULADORES", "NAVEGADOR", "MÍDIA", "UTILITÁRIOS", "SOBRE"]

var _selected_category := "TODOS"
var _search_text := ""
var _grid: GridContainer
var _search: LineEdit
var _page_title: Label
var _status: Label

func _ready() -> void:
	_build_interface()
	_render_apps()

func _build_interface() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var root := HBoxContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 0)
	add_child(root)

	var sidebar := PanelContainer.new()
	sidebar.custom_minimum_size = Vector2(172, 0)
	sidebar.add_theme_stylebox_override("panel", _panel_style(Color("#0b111b"), Color("#1d2b3b")))
	root.add_child(sidebar)

	var side_content := VBoxContainer.new()
	side_content.add_theme_constant_override("separation", 10)
	sidebar.add_child(side_content)

	var brand := Label.new()
	brand.text = "BOMBA\nLEITE"
	brand.custom_minimum_size = Vector2(0, 82)
	brand.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	brand.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	brand.add_theme_color_override("font_color", Color.WHITE)
	brand.add_theme_font_size_override("font_size", 25)
	side_content.add_child(brand)

	var brand_line := ColorRect.new()
	brand_line.color = CYAN
	brand_line.custom_minimum_size = Vector2(0, 3)
	side_content.add_child(brand_line)

	for item in NAV_ITEMS:
		var nav_button := Button.new()
		nav_button.text = item
		nav_button.custom_minimum_size = Vector2(0, 42)
		nav_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nav_button.add_theme_font_size_override("font_size", 14)
		_style_button(nav_button, item == "INÍCIO")
		nav_button.pressed.connect(_on_nav_pressed.bind(item))
		side_content.add_child(nav_button)

	var side_spacer := Control.new()
	side_spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	side_content.add_child(side_spacer)

	var version := Label.new()
	version.text = "SEU MUNDO\nEM UM SÓ LUGAR"
	version.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	version.add_theme_color_override("font_color", MUTED)
	version.add_theme_font_size_override("font_size", 12)
	side_content.add_child(version)

	var main_column := VBoxContainer.new()
	main_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_column.add_theme_constant_override("separation", 0)
	root.add_child(main_column)

	var header := PanelContainer.new()
	header.custom_minimum_size = Vector2(0, 82)
	header.add_theme_stylebox_override("panel", _panel_style(Color("#0e1520"), Color("#1d2b3b")))
	main_column.add_child(header)

	var header_row := HBoxContainer.new()
	header_row.add_theme_constant_override("separation", 16)
	header.add_child(header_row)

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_box.add_theme_constant_override("separation", 0)
	header_row.add_child(title_box)

	var header_title := Label.new()
	header_title.text = "BOMBA LEITE"
	header_title.add_theme_color_override("font_color", Color.WHITE)
	header_title.add_theme_font_size_override("font_size", 23)
	title_box.add_child(header_title)

	var tagline := Label.new()
	tagline.text = "JOGUE  •  ASSISTA  •  CONECTE-SE"
	tagline.add_theme_color_override("font_color", CYAN)
	tagline.add_theme_font_size_override("font_size", 11)
	title_box.add_child(tagline)

	_search = LineEdit.new()
	_search.placeholder_text = "Pesquisar apps..."
	_search.custom_minimum_size = Vector2(250, 42)
	_search.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_search.text_changed.connect(_on_search_changed)
	header_row.add_child(_search)

	var scroll := ScrollContainer.new()
	scroll.set_script(preload("res://cenas/RolagemToque.gd"))
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_column.add_child(scroll)

	var page := VBoxContainer.new()
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_theme_constant_override("separation", 16)
	scroll.add_child(page)

	var welcome := PanelContainer.new()
	welcome.custom_minimum_size = Vector2(0, 105)
	welcome.add_theme_stylebox_override("panel", _panel_style(Color("#10223a"), BLUE))
	page.add_child(welcome)

	var welcome_box := VBoxContainer.new()
	welcome_box.add_theme_constant_override("separation", 4)
	welcome.add_child(welcome_box)

	var welcome_title := Label.new()
	welcome_title.text = "SEU MUNDO EM UM SÓ LUGAR"
	welcome_title.add_theme_color_override("font_color", Color.WHITE)
	welcome_title.add_theme_font_size_override("font_size", 24)
	welcome_box.add_child(welcome_title)

	var welcome_subtitle := Label.new()
	welcome_subtitle.text = "Acesse seus aplicativos e jogos favoritos."
	welcome_subtitle.add_theme_color_override("font_color", MUTED)
	welcome_subtitle.add_theme_font_size_override("font_size", 14)
	welcome_box.add_child(welcome_subtitle)

	_page_title = Label.new()
	_page_title.text = "APLICATIVOS"
	_page_title.add_theme_color_override("font_color", CYAN)
	_page_title.add_theme_font_size_override("font_size", 18)
	page.add_child(_page_title)

	_grid = GridContainer.new()
	_grid.columns = 4
	_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_grid.add_theme_constant_override("h_separation", 12)
	_grid.add_theme_constant_override("v_separation", 12)
	page.add_child(_grid)

	_status = Label.new()
	_status.text = ""
	_status.add_theme_color_override("font_color", MUTED)
	_status.add_theme_font_size_override("font_size", 13)
	page.add_child(_status)

func _render_apps() -> void:
	if _grid == null:
		return
	for child in _grid.get_children():
		_grid.remove_child(child)
		child.queue_free()

	var shown := 0
	for app in APPS:
		var category: String = app.get("category", "")
		if _selected_category != "TODOS" and category != _selected_category:
			continue
		var app_name: String = app.get("name", "")
		if not _search_text.is_empty() and not app_name.to_lower().contains(_search_text.to_lower()):
			continue
		_grid.add_child(_make_app_button(app))
		shown += 1

	if shown == 0:
		_status.text = "Nenhum item encontrado nesta categoria."
	else:
		_status.text = "%d itens" % shown

func _make_app_button(app: Dictionary) -> Button:
	var button := Button.new()
	button.custom_minimum_size = Vector2(165, 112)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var action_label := "TOQUE PARA INSTALAR" if app.get("store_item", false) else app.get("category", "")
	button.text = "%s\n%s\n%s" % [app.get("symbol", "APP"), app.get("name", "App"), action_label]
	button.alignment = HORIZONTAL_ALIGNMENT_CENTER
	button.add_theme_font_size_override("font_size", 16)
	button.add_theme_color_override("font_color", Color.WHITE)
	_style_button(button, false)
	button.pressed.connect(_on_app_pressed.bind(app))
	return button

func _style_button(button: Button, selected: bool) -> void:
	var normal := _panel_style(BLUE if selected else PANEL, BLUE if selected else Color("#26374a"))
	var hover := _panel_style(PANEL_HOVER, CYAN)
	var pressed := _panel_style(Color("#0c3861"), CYAN)
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)

func _panel_style(fill: Color, border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(14)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style

func _on_nav_pressed(item: String) -> void:
	if item == "INÍCIO":
		_selected_category = "TODOS"
	elif item == "SOBRE":
		_selected_category = "TODOS"
		_status.text = "Bombe Lite — menu demonstrativo em paisagem."
	else:
		_selected_category = item
	_page_title.text = "APLICATIVOS" if _selected_category == "TODOS" else _selected_category
	_render_apps()

func _on_search_changed(value: String) -> void:
	_search_text = value.strip_edges()
	_render_apps()

func _on_app_pressed(app: Dictionary) -> void:
	var app_name: String = app.get("name", "")
	if app.get("store_item", false):
		_on_store_item_pressed(app)
		return
	var wifi_action: String = app.get("wifi_action", "")
	if wifi_action == "wifi":
		_on_wifi_pressed()
		return
	if wifi_action == "networks":
		_on_ver_redes_pressed()
		return
	if app_name == "WhatsApp":
		_on_whatsapp_pressed()
		return
	if app_name == "Minecraft":
		_on_minecraft_pressed()
		return
	if app_name == "Roblox":
		_on_roblox_pressed()
		return

	var scene_path: String = app.get("scene", "")
	if not scene_path.is_empty():
		var scene_error := get_tree().change_scene_to_file(scene_path)
		if scene_error != OK:
			_status.text = "Não foi possível abrir a tela %s." % app.get("name", "selecionada")
		return
	var uri: String = app.get("uri", "")
	if uri.is_empty():
		_status.text = "Nenhum endereço foi definido para %s." % app.get("name", "este app")
		return
	var error := OS.shell_open(uri)
	if error != OK:
		_status.text = "Não foi possível abrir %s. No Android, a abertura por pacote exige um plugin nativo." % app.get("name", "o item")
	else:
		_status.text = "Solicitação enviada para %s." % app.get("name", "o item")

func _on_wifi_pressed() -> void:
	_abrir_configuracao_wifi("Wi-Fi")

func _on_ver_redes_pressed() -> void:
	_abrir_configuracao_wifi("redes Wi-Fi")

func _abrir_configuracao_wifi(rotulo: String) -> void:
	var error := OS.shell_open("intent:#Intent;action=android.settings.WIFI_SETTINGS;end")
	if error != OK:
		error = OS.shell_open("intent:#Intent;action=android.settings.WIRELESS_SETTINGS;end")
	_status.text = "Não foi possível abrir as configurações de Wi-Fi." if error != OK else "Abrindo %s..." % rotulo

func _on_store_item_pressed(app: Dictionary) -> void:
	var package_id: String = app.get("package", "")
	if package_id.is_empty():
		_status.text = "Não há link de instalação para %s." % app.get("name", "este item")
		return
	var url := "https://play.google.com/store/apps/details?id=" + package_id
	var error := OS.shell_open(url)
	_status.text = "Não foi possível abrir a Play Store." if error != OK else "Abrindo %s na Play Store..." % app.get("name", "o item")

func _on_minecraft_pressed() -> void:
	var error := OS.shell_open("minecraft://")
	if error != OK:
		error = OS.shell_open("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe")
	_status.text = "Não foi possível abrir Minecraft." if error != OK else "Abrindo Minecraft..."

func _on_roblox_pressed() -> void:
	var error := OS.shell_open("roblox://")
	if error != OK:
		error = OS.shell_open("https://play.google.com/store/apps/details?id=com.roblox.client")
	_status.text = "Não foi possível abrir Roblox." if error != OK else "Abrindo Roblox..."

func _on_whatsapp_pressed() -> void:
	var error := OS.shell_open("https://wa.me/5511999999999")
	if error != OK:
		error = OS.shell_open("whatsapp://")
	_status.text = "Não foi possível abrir o WhatsApp." if error != OK else "Abrindo conversa no WhatsApp..."

func _on_voltar_pressed() -> void:
	var error := get_tree().change_scene_to_file("res://cenas/Menu.tscn")
	if error != OK and _status != null:
		_status.text = "Não foi possível voltar ao menu."

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		get_viewport().set_input_as_handled()
		_selected_category = "TODOS"
		_search_text = ""
		if _search:
			_search.clear()
		_page_title.text = "APLICATIVOS"
		_render_apps()
