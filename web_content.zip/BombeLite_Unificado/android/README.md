# Bombe Lite para Android Studio

Projeto Android nativo com uma interface HTML local dentro de um WebView, em orientação paisagem. O menu foi adaptado da imagem de referência enviada e usa o emblema Bombe Lite recortado dela.

## Abrir e executar
1. Abra a pasta `android/` no Android Studio.
2. Aguarde a sincronização do Gradle; use JDK 17 e Android SDK 35.
3. Conecte um Android ou inicie um emulador e pressione **Run**.

O HTML e o emblema carregados pelo app ficam em `app/src/main/assets/`. A cópia independente está em `../index.html` com `../bombe-logo.png`.

## Atalhos Android
Os botões chamam os intents nativos do Android, implementados em `MainActivity.kt`: Minecraft (`com.mojang.minecraftpe`), WhatsApp (`com.whatsapp`), Roblox (`com.roblox.client`), Free Fire (`com.dts.freefireth`), YouTube, Chrome, Google e Play Store. WhatsApp, Roblox, YouTube e Chrome tentam abrir o app instalado; se não estiver disponível, abrem o site correspondente. Minecraft, Roblox e Free Fire levam à página oficial do jogo na Play Store quando não estão instalados. Na categoria **Jogos**, **Baixar mais jogos** abre uma busca na loja. Se a Play Store não estiver disponível, o app tenta abrir a versão web.

A instalação sempre é confirmada pelo usuário na Play Store; o Bombe Lite não baixa nem instala jogos silenciosamente. Os demais apps mantêm seus atalhos existentes. Quando YouTube, Google, Gmail ou Play Store não está instalado, abre o site oficial. **Sites** e **Navegador** abrem Google no navegador padrão. **Configurações** abre as configurações do aparelho; **Conexões** abre a tela de conexões sem fio do Android (`ACTION_WIRELESS_SETTINGS`). **Bluetooth** abre uma tela própria, inicia descoberta após a permissão, mostra dispositivos encontrados e pareados e permite filtrar por fones, caixas de som e outros. Ao parear, o Android apresenta sua confirmação. **Desconectar** abre o painel do sistema, pois não há uma API pública Android genérica para desconectar qualquer perfil Bluetooth. O mini jogo Bombe Lite roda dentro do próprio app.

## Internet e Wi-Fi
A tela **INTERNET / WI-FI** apresenta `MinhaInternet` e quatro nomes como exemplos visuais, sem afirmar que sejam as redes atuais do aparelho. Os botões **Procurar redes** e **Configurações de Wi-Fi** chamam as configurações do Android; a consulta das redes reais e a conexão/senha são feitas pelo sistema.

## Bluetooth e preferências visuais
A tela Bluetooth solicita a permissão **Dispositivos próximos** (Android 12+), inicia e permite interromper a busca, mostra quando ela termina e permite filtrar fones, caixas de som e outros aparelhos. Os eventos de dispositivo encontrado e conexão/desconexão atualizam o estado da tela. Selecione um dispositivo e toque em **Parear** para abrir a confirmação do Android. Android 11 e anteriores podem pedir localização para a busca. A tela **Configurações do Bombe Lite** implementa os controles de notificações visuais, modo de exibição, transparência, reversão de cor e pesquisa. Eles alteram apenas a prévia dentro do Bombe Lite, não as configurações globais do Android. **Desconectar** encaminha para as configurações Bluetooth do Android, já que o Android não oferece uma API pública genérica para desconectar qualquer perfil.


## Usar como tela inicial
O Bombe Lite pode ser escolhido como tela inicial padrão do Android. Na tela **Configurações do Bombe Lite**, toque em **Definir tela inicial** e selecione o Bombe Lite na tela do sistema. A disponibilidade e o nome dessa opção podem variar conforme o fabricante.
