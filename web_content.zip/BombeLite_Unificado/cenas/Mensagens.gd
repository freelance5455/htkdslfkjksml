extends Control

const BG := Color("#050a12")
const PANEL := Color("#101a28")
const KEY_COLOR := Color("#252c38")
const BLUE := Color("#1687ff")
const GREEN := Color("#20c66b")
const MUTED := Color("#afbdd0")
const DEFAULT_MESSAGE := "Olá! Esta mensagem foi enviada pelo meu aplicativo."
const DEFAULT_SERVER_URL := "https://SEU-SERVIDOR.com/enviar"
const LETTER_ROWS := ["1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]
const SYMBOL_ROWS := ["!@#$%&-+()", "*\"':;!?/_=", "[]{}\\|~`<>"]
const DEMO_CONVERSATIONS := [
	{"name":"João Silva", "platform":"WhatsApp", "preview":"Tá chegando aí? 🚀", "time":"12:34", "icon":"🟢", "messages":["Tá chegando aí? 🚀", "Sim, já tô saindo agora!", "Beleza! Te espero 😊"]},
	{"name":"Maria Souza", "platform":"Messenger", "preview":"Beleza! Te vejo depois então. 😊", "time":"11:58", "icon":"🔵", "messages":["Vamos marcar para amanhã?", "Beleza! Te vejo depois então. 😊"]},
	{"name":"Lucas Gamer", "platform":"Discord", "preview":"Bora jogar mais tarde?", "time":"11:20", "icon":"🎮", "messages":["Bora jogar mais tarde?", "Fechado, te chamo!"]},
	{"name":"Ana Clara", "platform":"Instagram", "preview":"Amei a foto 😍", "time":"10:45", "icon":"📸", "messages":["Amei a foto 😍", "Obrigada!! 💜"]},
	{"name":"Grupo da Família", "platform":"WhatsApp", "preview":"Vovó: Já almoçaram?", "time":"09:32", "icon":"🟢", "messages":["Vovó: Já almoçaram?", "Sim, vó! 😄"]},
	{"name":"Trabalho", "platform":"Telegram", "preview":"Reunião às 15h, ok?", "time":"08:17", "icon":"✈️", "messages":["Reunião às 15h, ok?", "Ok, confirmado."]},
	{"name":"Sistema", "platform":"SMS", "preview":"Nova mensagem de exemplo", "time":"Ontem", "icon":"✉️", "messages":["Nova mensagem SMS de demonstração."]}
]

var _hub_screen: VBoxContainer
var _composer_scroll: ScrollContainer
var _conversation_list: VBoxContainer
var _preview: Label
var _preview_title: Label
var _preview_icon: Label
var _hub_search: LineEdit
var _hub_notice: Label
var _active_filter := "Todos"
@onready var http: HTTPRequest = $HTTPRequest
var _numero: LineEdit
var _endpoint: LineEdit
var _mensagem: TextEdit
var _status: Label
var _server_send_button: Button
var _server_pending_text := ""
var _letter_buttons: Array[Button] = []
var _letters_box: VBoxContainer
var _symbols_box: VBoxContainer
var _maiusculo := true
var _symbols_mode := false
var _english := false
var _language_button: Button

func _ready() -> void:
	http.request_completed.connect(_on_server_response)
	_build_interface()
	_render_demo_conversations("Todos")

func _build_hub() -> void:
	var header := HBoxContainer.new()
	_hub_screen.add_child(header)
	var back := Button.new()
	back.text = "←"
	_style_button(back)
	back.pressed.connect(_on_voltar_pressed)
	header.add_child(back)
	var logo := Label.new()
	logo.text = "▣"
	logo.add_theme_color_override("font_color", BLUE)
	logo.add_theme_font_size_override("font_size", 30)
	header.add_child(logo)
	var brand := VBoxContainer.new()
	brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(brand)
	var title := Label.new()
	title.text = "Mensagens"
	title.add_theme_color_override("font_color", Color.WHITE)
	title.add_theme_font_size_override("font_size", 21)
	brand.add_child(title)
	var tagline := Label.new()
	tagline.text = "Conecte-se com todos em um só lugar"
	tagline.add_theme_color_override("font_color", MUTED)
	brand.add_child(tagline)
	_hub_search = LineEdit.new()
	_hub_search.placeholder_text = "Pesquisar conversas"
	_hub_search.custom_minimum_size = Vector2(210, 42)
	_hub_search.text_changed.connect(_on_hub_search_changed)
	header.add_child(_hub_search)
	var new_message := Button.new()
	new_message.text = "✎ Nova mensagem"
	_style_button(new_message, true)
	new_message.pressed.connect(_on_new_message_pressed)
	header.add_child(new_message)

	var layout := HBoxContainer.new()
	layout.size_flags_vertical = Control.SIZE_EXPAND_FILL
	layout.add_theme_constant_override("separation", 10)
	_hub_screen.add_child(layout)

	var sidebar := VBoxContainer.new()
	sidebar.custom_minimum_size = Vector2(170, 0)
	sidebar.add_theme_constant_override("separation", 5)
	layout.add_child(sidebar)
	for platform in ["Todos", "WhatsApp", "Messenger", "Instagram", "Telegram", "Discord", "Snapchat", "SMS", "Configurações"]:
		var filter_button := Button.new()
		filter_button.text = "💬 " + platform if platform == "Todos" else platform
		filter_button.custom_minimum_size = Vector2(0, 42)
		filter_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_style_button(filter_button, platform == "Todos")
		filter_button.pressed.connect(_on_filter_selected.bind(platform))
		sidebar.add_child(filter_button)

	var main := VBoxContainer.new()
	main.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main.add_theme_constant_override("separation", 7)
	layout.add_child(main)

	var title_row := HBoxContainer.new()
	main.add_child(title_row)
	var conversations_title := Label.new()
	conversations_title.text = "Conversas  ·  exemplos de interface"
	conversations_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	conversations_title.add_theme_color_override("font_color", Color.WHITE)
	conversations_title.add_theme_font_size_override("font_size", 18)
	title_row.add_child(conversations_title)

	var panes := HBoxContainer.new()
	panes.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panes.add_theme_constant_override("separation", 8)
	main.add_child(panes)

	var list_panel := PanelContainer.new()
	list_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	list_panel.add_theme_stylebox_override("panel", _hub_panel_style())
	panes.add_child(list_panel)
	var list_scroll := ScrollContainer.new()
	list_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	list_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	list_panel.add_child(list_scroll)
	_conversation_list = VBoxContainer.new()
	_conversation_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_conversation_list.add_theme_constant_override("separation", 4)
	list_scroll.add_child(_conversation_list)

	var preview_panel := PanelContainer.new()
	preview_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	preview_panel.add_theme_stylebox_override("panel", _hub_panel_style())
	panes.add_child(preview_panel)
	var preview_box := VBoxContainer.new()
	preview_box.add_theme_constant_override("separation", 9)
	preview_panel.add_child(preview_box)
	var preview_header := HBoxContainer.new()
	preview_box.add_child(preview_header)
	_preview_icon = Label.new()
	_preview_icon.text = "🟢"
	_preview_icon.add_theme_font_size_override("font_size", 24)
	preview_header.add_child(_preview_icon)
	_preview_title = Label.new()
	_preview_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_preview_title.add_theme_color_override("font_color", Color.WHITE)
	_preview_title.add_theme_font_size_override("font_size", 15)
	preview_header.add_child(_preview_title)
	var demo_label := Label.new()
	demo_label.text = "PRÉVIA DEMONSTRATIVA"
	demo_label.add_theme_color_override("font_color", CYAN)
	demo_label.add_theme_font_size_override("font_size", 11)
	preview_box.add_child(demo_label)
	_preview = Label.new()
	_preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_preview.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_preview.add_theme_color_override("font_color", MUTED)
	preview_box.add_child(_preview)

	_hub_notice = Label.new()
	_hub_notice.text = "Conversas e mensagens são exemplos visuais, não acessam contas reais. O envio preparado está disponível pelo WhatsApp."
	_hub_notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hub_notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hub_notice.add_theme_color_override("font_color", MUTED)
	_hub_screen.add_child(_hub_notice)

func _hub_panel_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = PANEL
	style.border_color = Color("#27384e")
	style.set_border_width_all(1)
	style.set_corner_radius_all(12)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func _on_filter_selected(platform: String) -> void:
	if platform == "Configurações":
		_hub_notice.text = "O hub é demonstrativo; a composição e o envio de mensagem estão disponíveis pelo WhatsApp."
		return
	_active_filter = platform
	_render_demo_conversations(platform)

func _on_hub_search_changed(_value: String) -> void:
	_render_demo_conversations(_active_filter)

func _render_demo_conversations(platform: String) -> void:
	if _conversation_list == null:
		return
	for child in _conversation_list.get_children():
		child.queue_free()
	var query := _hub_search.text.strip_edges().to_lower() if _hub_search != null else ""
	var shown := 0
	var first_item: Dictionary = {}
	for item in DEMO_CONVERSATIONS:
		if platform != "Todos" and item.platform != platform:
			continue
		if not query.is_empty() and not (item.name + " " + item.preview).to_lower().contains(query):
			continue
		if shown == 0:
			first_item = item
		var row := Button.new()
		row.text = "%s  %s (%s)\n%s  ·  %s" % [item.icon, item.name, item.platform, item.preview, item.time]
		row.custom_minimum_size = Vector2(0, 63)
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.alignment = HORIZONTAL_ALIGNMENT_LEFT
		row.add_theme_font_size_override("font_size", 12)
		_style_button(row)
		row.pressed.connect(_show_demo_preview.bind(item))
		_conversation_list.add_child(row)
		shown += 1
	if shown == 0:
		var empty := Label.new()
		empty.text = "Nenhum exemplo nesta categoria."
		empty.add_theme_color_override("font_color", MUTED)
		_conversation_list.add_child(empty)
	else:
		_show_demo_preview(first_item)

func _show_demo_preview(item: Dictionary) -> void:
	_preview_icon.text = str(item.icon)
	_preview_title.text = "%s (%s)  ·  %s" % [item.name, item.platform, item.time]
	var preview_text := "PRÉVIA DE DEMONSTRAÇÃO — não é uma conversa real."
	var messages: Array = item.messages
	for index in range(messages.size()):
		var prefix := "Você: " if index % 2 == 1 else str(item.name) + ": "
		preview_text += "\n\n" + prefix + str(messages[index])
	_preview.text = preview_text

func _on_new_message_pressed() -> void:
	_hub_screen.visible = false
	_composer_scroll.visible = true
	_numero.grab_focus()

func _on_compose_back_pressed() -> void:
	_composer_scroll.visible = false
	_hub_screen.visible = true

func _build_interface() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	_hub_screen = VBoxContainer.new()
	_hub_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_hub_screen.offset_left = 12
	_hub_screen.offset_top = 10
	_hub_screen.offset_right = -12
	_hub_screen.offset_bottom = -10
	_hub_screen.add_theme_constant_override("separation", 8)
	add_child(_hub_screen)
	_build_hub()

	var scroll := ScrollContainer.new()
	_composer_scroll = scroll
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 18
	scroll.offset_top = 12
	scroll.offset_right = -18
	scroll.offset_bottom = -12
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	scroll.visible = false

	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	scroll.add_child(content)

	var header := HBoxContainer.new()
	content.add_child(header)
	var back := Button.new()
	back.text = "← Voltar"
	_style_button(back)
	back.pressed.connect(_on_compose_back_pressed)
	header.add_child(back)
	var title := Label.new()
	title.text = "NOVA MENSAGEM PELO WHATSAPP"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", Color.WHITE)
	title.add_theme_font_size_override("font_size", 20)
	header.add_child(title)

	var info := Label.new()
	info.text = "Digite o telefone com DDI e DDD. Para envio pelo servidor, configure seu endpoint HTTPS; mantenha tokens e credenciais no servidor, nunca no app."
	info.add_theme_color_override("font_color", MUTED)
	content.add_child(info)

	_numero = LineEdit.new()
	_numero.name = "Numero"
	_numero.placeholder_text = "Telefone (ex.: 5511999999999)"
	_numero.custom_minimum_size = Vector2(0, 43)
	content.add_child(_numero)

	_endpoint = LineEdit.new()
	_endpoint.name = "Servidor"
	_endpoint.placeholder_text = DEFAULT_SERVER_URL + " (configure no seu servidor)"
	_endpoint.custom_minimum_size = Vector2(0, 40)
	content.add_child(_endpoint)

	_mensagem = TextEdit.new()
	_mensagem.name = "Mensagem"
	_mensagem.text = DEFAULT_MESSAGE
	_mensagem.custom_minimum_size = Vector2(0, 76)
	_mensagem.virtual_keyboard_enabled = false
	content.add_child(_mensagem)

	_build_keyboard(content)

	var send := Button.new()
	send.text = "➤  ENVIAR PELO WHATSAPP"
	send.custom_minimum_size = Vector2(0, 48)
	_style_button(send, true)
	send.pressed.connect(_on_whatsapp_pressed)
	content.add_child(send)

	_server_send_button = Button.new()
	_server_send_button.text = "Enviar pelo servidor (WhatsApp Business)"
	_server_send_button.custom_minimum_size = Vector2(0, 44)
	_style_button(_server_send_button)
	_server_send_button.pressed.connect(_on_send_via_server_pressed)
	content.add_child(_server_send_button)

	_status = Label.new()
	_status.text = "O WhatsApp abrirá com a mensagem preparada; você confirma o envio lá."
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.add_theme_color_override("font_color", MUTED)
	content.add_child(_status)

func _build_keyboard(parent: VBoxContainer) -> void:
	var keyboard_panel := PanelContainer.new()
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color("#151a23")
	panel_style.border_color = Color("#303946")
	panel_style.set_border_width_all(1)
	panel_style.set_corner_radius_all(15)
	panel_style.content_margin_left = 9
	panel_style.content_margin_right = 9
	panel_style.content_margin_top = 8
	panel_style.content_margin_bottom = 8
	keyboard_panel.add_theme_stylebox_override("panel", panel_style)
	parent.add_child(keyboard_panel)

	var keyboard := VBoxContainer.new()
	keyboard.add_theme_constant_override("separation", 5)
	keyboard_panel.add_child(keyboard)

	_letters_box = VBoxContainer.new()
	_letters_box.add_theme_constant_override("separation", 5)
	keyboard.add_child(_letters_box)
	for row_index in range(LETTER_ROWS.size()):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 5)
		_letters_box.add_child(row)
		var key_row: String = LETTER_ROWS[row_index]
		if row_index == 3:
			var shift := _make_key("⇧", row)
			shift.custom_minimum_size.x = 66
		for character in key_row:
			var key := _make_key(character, row, row_index > 0)
			if row_index > 0:
				_letter_buttons.append(key)
		if row_index == 3:
			var backspace := _make_key("⌫", row)
			backspace.custom_minimum_size.x = 66

	_symbols_box = VBoxContainer.new()
	_symbols_box.add_theme_constant_override("separation", 5)
	_symbols_box.visible = false
	keyboard.add_child(_symbols_box)
	for row_text in SYMBOL_ROWS:
		var symbol_row := HBoxContainer.new()
		symbol_row.add_theme_constant_override("separation", 5)
		_symbols_box.add_child(symbol_row)
		for character in row_text:
			_make_key(character, symbol_row)

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 5)
	keyboard.add_child(bottom)
	var symbol_button := _make_key("!#1", bottom)
	symbol_button.custom_minimum_size.x = 64
	_language_button = _make_key("Idioma: Português (BR)", bottom)
	_language_button.custom_minimum_size.x = 135
	_make_key(",", bottom)
	var space := _make_key("ESPAÇO", bottom)
	space.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_make_key(".", bottom)
	var enter := _make_key("↵", bottom)
	enter.custom_minimum_size.x = 64

func _make_key(label: String, parent: Container, is_letter: bool = false) -> Button:
	var button := Button.new()
	button.text = label
	button.custom_minimum_size = Vector2(0, 43)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_to_group("teclas")
	button.set_meta("letter", is_letter)
	button.set_meta("base_key", label)
	_style_button(button)
	button.pressed.connect(_tecla_pressionada.bind(button))
	parent.add_child(button)
	return button

func _style_button(button: Button, primary: bool = false) -> void:
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_font_size_override("font_size", 14 if button.text.length() > 5 else 18)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#087943") if primary else KEY_COLOR
	style.border_color = GREEN if primary else Color("#303946")
	style.set_border_width_all(1)
	style.set_corner_radius_all(9)
	style.content_margin_left = 5
	style.content_margin_right = 5
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	button.add_theme_stylebox_override("normal", style)
	button.add_theme_stylebox_override("hover", style)
	button.add_theme_stylebox_override("pressed", style)

func _tecla_pressionada(botao: Button) -> void:
	var tecla: String = botao.text
	if tecla == "⌫":
		apagar_caractere()
		return
	if tecla == "ESPAÇO":
		_mensagem.insert_text_at_caret(" ")
		return
	if tecla == "↵":
		_mensagem.insert_text_at_caret("\n")
		return
	if tecla == "⇧":
		_maiusculo = not _maiusculo
		_atualizar_teclas()
		return
	if tecla == "!#1" or tecla == "ABC":
		_symbols_mode = not _symbols_mode
		_letters_box.visible = not _symbols_mode
		_symbols_box.visible = _symbols_mode
		botao.text = "ABC" if _symbols_mode else "!#1"
		return
	if tecla.begins_with("Idioma:"):
		_english = not _english
		botao.text = "Idioma: English" if _english else "Idioma: Português (BR)"
		return
	if tecla == "," or tecla == ".":
		_mensagem.insert_text_at_caret(tecla)
		return
	var texto := tecla
	if botao.get_meta("letter", false):
		texto = tecla.to_upper() if _maiusculo else tecla.to_lower()
	_mensagem.insert_text_at_caret(texto)

func _atualizar_teclas() -> void:
	for button in _letter_buttons:
		var base_key: String = button.get_meta("base_key", "")
		button.text = base_key.to_upper() if _maiusculo else base_key.to_lower()

func apagar_caractere() -> void:
	if _mensagem.has_selection():
		_mensagem.delete_selection()
		return
	var posicao := _mensagem.get_caret_column()
	var linha := _mensagem.get_caret_line()
	if posicao > 0:
		_mensagem.remove_text(linha, posicao - 1, linha, posicao)
		_mensagem.set_caret_column(posicao - 1)
	elif linha > 0:
		var coluna_anterior := _mensagem.get_line(linha - 1).length()
		_mensagem.remove_text(linha - 1, coluna_anterior, linha, 0)
		_mensagem.set_caret_line(linha - 1)
		_mensagem.set_caret_column(coluna_anterior)

func _on_send_via_server_pressed() -> void:
	var telefone := ""
	for caractere in _numero.text.strip_edges():
		if caractere.is_valid_int():
			telefone += caractere
	var texto := _mensagem.text.strip_edges()
	var endpoint := _endpoint.text.strip_edges()
	if telefone.is_empty() or texto.is_empty():
		_status.text = "Preencha telefone e mensagem antes de enviar."
		return
	if not endpoint.begins_with("https://") or endpoint.to_lower().contains("seu-servidor.com"):
		_status.text = "Configure o endereço HTTPS do seu servidor /enviar primeiro."
		return
	var payload := JSON.stringify({"numero": telefone, "mensagem": texto})
	var headers := PackedStringArray(["Content-Type: application/json"])
	var error := http.request(endpoint, headers, HTTPClient.METHOD_POST, payload)
	if error != OK:
		_status.text = "Não foi possível iniciar a solicitação ao servidor."
		return
	_server_pending_text = texto
	_server_send_button.disabled = true
	_status.text = "Enviando solicitação ao servidor seguro..."

func _on_server_response(result: int, response_code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void:
	_server_send_button.disabled = false
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		_status.text = "O servidor não confirmou o envio. Verifique a URL e a resposta do WhatsApp Business."
		return
	if _mensagem.text.strip_edges() == _server_pending_text:
		_mensagem.text = ""
	_status.text = "O servidor aceitou a solicitação. A entrega final depende da resposta do WhatsApp Business."

func _on_whatsapp_pressed() -> void:
	var telefone := ""
	for caractere in _numero.text.strip_edges():
		if caractere.is_valid_int():
			telefone += caractere
	var texto := _mensagem.text.strip_edges()
	if telefone.is_empty() or texto.is_empty():
		_status.text = "Preencha o telefone com DDI e DDD e escreva a mensagem."
		return
	var url := "https://wa.me/" + telefone + "?text=" + texto.uri_encode()
	var erro := OS.shell_open(url)
	_status.text = "Não foi possível abrir o WhatsApp." if erro != OK else "Conversa aberta. Revise e toque em Enviar dentro do WhatsApp."

func _on_voltar_pressed() -> void:
	get_tree().change_scene_to_file("res://cenas/Menu.tscn")
