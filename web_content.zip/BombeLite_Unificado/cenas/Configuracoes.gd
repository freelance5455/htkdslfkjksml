extends Control

const BG := Color("#050a13")
const PANEL := Color("#08182a")
const BLUE := Color("#087cff")
const CYAN := Color("#00d5ff")
const MUTED := Color("#b5c6dc")

var _status: Label
var _configuracao: Label
var _preview: TextureRect
var _texto: Label
var _campo_pesquisa: LineEdit
var _notificacoes_ativadas := true
var _somente_icone := true
var _reverter_cor := false

func _ready() -> void:
	_build_interface()

func _build_interface() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 18)
	add_child(margin)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)
	scroll.add_child(column)

	var header := HBoxContainer.new()
	column.add_child(header)
	var back := _button("←  Voltar")
	back.pressed.connect(_on_voltar_pressed)
	header.add_child(back)
	var title := Label.new()
	title.text = "CONFIGURAÇÕES DE NOTIFICAÇÕES"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", Color.WHITE)
	title.add_theme_font_size_override("font_size", 22)
	header.add_child(title)
	var search_button := _button("⌕  Pesquisar")
	search_button.pressed.connect(_on_pesquisa_pressed)
	header.add_child(search_button)

	_campo_pesquisa = LineEdit.new()
	_campo_pesquisa.name = "CampoPesquisa"
	_campo_pesquisa.placeholder_text = "Pesquisar configurações..."
	_campo_pesquisa.visible = false
	column.add_child(_campo_pesquisa)

	_status = Label.new()
	_status.name = "Status"
	_status.text = "Notificações ativadas"
	_status.add_theme_color_override("font_color", CYAN)
	_status.add_theme_font_size_override("font_size", 17)
	column.add_child(_status)

	var content := HBoxContainer.new()
	content.add_theme_constant_override("separation", 22)
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(content)

	var controls := VBoxContainer.new()
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	controls.add_theme_constant_override("separation", 10)
	content.add_child(controls)

	var notifications := CheckButton.new()
	notifications.text = "Ativar notificações"
	notifications.button_pressed = true
	notifications.toggled.connect(_on_notificacoes_toggled)
	controls.add_child(notifications)

	_configuracao = Label.new()
	_configuracao.name = "Configuracao"
	_configuracao.text = "Só ícone"
	_configuracao.add_theme_color_override("font_color", Color.WHITE)
	_configuracao.add_theme_font_size_override("font_size", 17)
	controls.add_child(_configuracao)

	var mode_row := HBoxContainer.new()
	mode_row.add_theme_constant_override("separation", 10)
	controls.add_child(mode_row)
	var icon_button := _button("Só ícone")
	icon_button.pressed.connect(_on_so_icone_pressed)
	mode_row.add_child(icon_button)
	var details_button := _button("Detalhes")
	details_button.pressed.connect(_on_detalhes_pressed)
	mode_row.add_child(details_button)

	var opacity_label := Label.new()
	opacity_label.text = "Transparência da prévia"
	opacity_label.add_theme_color_override("font_color", MUTED)
	controls.add_child(opacity_label)
	var transparency := HSlider.new()
	transparency.name = "Transparencia"
	transparency.min_value = 0
	transparency.max_value = 100
	transparency.value = 75
	transparency.value_changed.connect(_on_transparencia_value_changed)
	controls.add_child(transparency)

	var inversion := CheckButton.new()
	inversion.text = "Reversão automática da cor do texto"
	inversion.toggled.connect(_on_reversao_cor_toggled)
	controls.add_child(inversion)
	var preview_card := PanelContainer.new()
	preview_card.add_theme_stylebox_override("panel", _panel_style(Color.WHITE, BLUE))
	controls.add_child(preview_card)
	_texto = Label.new()
	_texto.name = "Texto"
	_texto.text = "Prévia de notificação — Olá!"
	_texto.add_theme_font_size_override("font_size", 18)
	_texto.modulate = Color.BLACK
	preview_card.add_child(_texto)

	var image_panel := PanelContainer.new()
	image_panel.custom_minimum_size = Vector2(0, 250)
	image_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	image_panel.add_theme_stylebox_override("panel", _panel_style(PANEL, BLUE))
	content.add_child(image_panel)
	_preview = TextureRect.new()
	_preview.name = "Preview"
	_preview.texture = load("res://referencia_configuracoes_enviada.jpg")
	_preview.custom_minimum_size = Vector2(260, 250)
	_preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image_panel.add_child(_preview)

	var note := Label.new()
	note.text = "Imagem enviada como referência visual. As opções de notificações do Android podem variar por aparelho."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.add_theme_color_override("font_color", MUTED)
	column.add_child(note)

	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation", 12)
	column.add_child(footer)
	var home := _button("⌂  Início")
	home.pressed.connect(_go_home)
	footer.add_child(home)
	var bluetooth := _button("ᛒ  Bluetooth")
	bluetooth.pressed.connect(_open_bluetooth)
	footer.add_child(bluetooth)

func _button(text: String) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(0, 44)
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_stylebox_override("normal", _panel_style(PANEL, BLUE))
	button.add_theme_stylebox_override("hover", _panel_style(Color("#12304f"), CYAN))
	button.add_theme_stylebox_override("pressed", _panel_style(Color("#0b3763"), CYAN))
	return button

func _panel_style(fill: Color, border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(14)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func _on_notificacoes_toggled(ativado: bool) -> void:
	_notificacoes_ativadas = ativado
	_status.text = "Notificações ativadas" if ativado else "Notificações desativadas"

func _on_so_icone_pressed() -> void:
	_somente_icone = true
	_configuracao.text = "Só ícone"

func _on_detalhes_pressed() -> void:
	_somente_icone = false
	_configuracao.text = "Detalhes"

func _on_transparencia_value_changed(valor: float) -> void:
	if is_instance_valid(_preview):
		_preview.modulate.a = valor / 100.0

func _on_reversao_cor_toggled(ativado: bool) -> void:
	_reverter_cor = ativado
	_texto.modulate = Color.WHITE if ativado else Color.BLACK

func _on_voltar_pressed() -> void:
	_go_home()

func _on_pesquisa_pressed() -> void:
	_campo_pesquisa.visible = true
	_campo_pesquisa.grab_focus()

func _open_bluetooth() -> void:
	get_tree().change_scene_to_file("res://cenas/Bluetooth.tscn")

func _go_home() -> void:
	get_tree().change_scene_to_file("res://cenas/Menu.tscn")

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		get_viewport().set_input_as_handled()
		_go_home()
