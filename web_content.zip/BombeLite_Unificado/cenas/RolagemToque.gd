extends ScrollContainer

const LIMITE_ARRASTO := 10.0

var tocando := false
var arrastando := false
var indice_toque := -1
var inicio_toque := Vector2.ZERO
var ultima_posicao := Vector2.ZERO

func _ready() -> void:
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var posicao_local: Vector2 = get_global_transform_with_canvas().affine_inverse() * event.position
		if event.pressed:
			if get_rect().has_point(posicao_local):
				tocando = true
				arrastando = false
				indice_toque = event.index
				inicio_toque = event.position
				ultima_posicao = event.position
		elif tocando and event.index == indice_toque:
			if arrastando:
				get_viewport().set_input_as_handled()
			tocando = false
			arrastando = false
			indice_toque = -1
		return

	if event is InputEventScreenDrag and tocando and event.index == indice_toque:
		var movimento: Vector2 = event.position - ultima_posicao
		ultima_posicao = event.position
		if not arrastando and event.position.distance_to(inicio_toque) >= LIMITE_ARRASTO:
			arrastando = true
		if arrastando:
			scroll_horizontal -= int(round(movimento.x))
			scroll_vertical -= int(round(movimento.y))
			get_viewport().set_input_as_handled()
