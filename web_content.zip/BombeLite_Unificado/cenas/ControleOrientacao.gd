extends Node

func _ready() -> void:
	# Deixa o Android girar a tela conforme o sensor do aparelho.
	if OS.get_name() == "Android":
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR)

func tela_vertical() -> void:
	_aplicar_orientacao(DisplayServer.SCREEN_PORTRAIT)

func tela_horizontal() -> void:
	_aplicar_orientacao(DisplayServer.SCREEN_LANDSCAPE)

func tela_horizontal_invertida() -> void:
	_aplicar_orientacao(DisplayServer.SCREEN_REVERSE_LANDSCAPE)

func tela_vertical_invertida() -> void:
	_aplicar_orientacao(DisplayServer.SCREEN_REVERSE_PORTRAIT)

func rotacao_automatica() -> void:
	_aplicar_orientacao(DisplayServer.SCREEN_SENSOR)

func _aplicar_orientacao(orientacao: int) -> void:
	if OS.get_name() == "Android":
		DisplayServer.screen_set_orientation(orientacao)
