extends Control

const IMAGEM_WIFI := preload("res://referencia_wifi_enviada.jpg")
const ACTION_WIFI := "android.settings.WIFI_SETTINGS"
const ACTION_BLUETOOTH := "android.settings.BLUETOOTH_SETTINGS"
const ACTION_INTERNET := "android.settings.WIRELESS_SETTINGS"
const ACTION_SETTINGS := "android.settings.SETTINGS"

func _ready() -> void:
	var imagem := TextureRect.new()
	imagem.name = "TelaWifi"
	imagem.texture = IMAGEM_WIFI
	imagem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	imagem.stretch_mode = TextureRect.STRETCH_SCALE
	imagem.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(imagem)

	# Áreas clicáveis alinhadas aos controles da imagem de referência.
	_add_hotspot("Voltar", Rect2(0.015, 0.01, 0.12, 0.075), "menu", "Voltar ao menu")
	_add_hotspot("Atualizar", Rect2(0.75, 0.01, 0.12, 0.075), ACTION_WIFI, "Abrir Wi-Fi para atualizar redes")
	_add_hotspot("ConfiguracoesTopo", Rect2(0.88, 0.01, 0.115, 0.075), ACTION_SETTINGS, "Abrir configurações do Android")
	_add_hotspot("AtivarWifi", Rect2(0.80, 0.105, 0.17, 0.085), ACTION_WIFI, "Abrir configurações de Wi-Fi")
	_add_hotspot("RedeAtual", Rect2(0.04, 0.24, 0.92, 0.12), ACTION_WIFI, "Abrir redes Wi-Fi do Android")
	_add_hotspot("AtualizarRedes", Rect2(0.74, 0.37, 0.23, 0.055), ACTION_WIFI, "Atualizar redes Wi-Fi")
	_add_hotspot("ListaRedes", Rect2(0.04, 0.43, 0.92, 0.34), ACTION_WIFI, "Ver redes Wi-Fi disponíveis")
	_add_hotspot("AdicionarRede", Rect2(0.03, 0.81, 0.94, 0.085), ACTION_WIFI, "Adicionar uma rede Wi-Fi")

	# Barra inferior: Wi-Fi, Bluetooth, Internet e Configurações.
	_add_hotspot("AbaWifi", Rect2(0.00, 0.91, 0.25, 0.09), ACTION_WIFI, "Abrir configurações de Wi-Fi")
	_add_hotspot("AbaBluetooth", Rect2(0.25, 0.91, 0.25, 0.09), ACTION_BLUETOOTH, "Abrir configurações de Bluetooth")
	_add_hotspot("AbaInternet", Rect2(0.50, 0.91, 0.25, 0.09), ACTION_INTERNET, "Abrir configurações de Internet")
	_add_hotspot("AbaConfiguracoes", Rect2(0.75, 0.91, 0.25, 0.09), ACTION_SETTINGS, "Abrir configurações do Android")

func _add_hotspot(nome: String, area: Rect2, acao: String, descricao: String) -> void:
	var botao := Button.new()
	botao.name = nome
	botao.tooltip_text = descricao
	botao.flat = true
	botao.focus_mode = Control.FOCUS_NONE
	botao.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	botao.anchor_left = area.position.x
	botao.anchor_top = area.position.y
	botao.anchor_right = area.position.x + area.size.x
	botao.anchor_bottom = area.position.y + area.size.y
	botao.offset_left = 0
	botao.offset_top = 0
	botao.offset_right = 0
	botao.offset_bottom = 0
	var vazio := StyleBoxEmpty.new()
	botao.add_theme_stylebox_override("normal", vazio)
	botao.add_theme_stylebox_override("hover", vazio)
	botao.add_theme_stylebox_override("pressed", vazio)
	botao.add_theme_stylebox_override("focus", vazio)
	add_child(botao)
	if acao == "menu":
		botao.pressed.connect(_on_voltar_pressed)
	else:
		botao.pressed.connect(abrir_configuracao_android.bind(acao))

func _on_wifi_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_atualizar_wifi_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_adicionar_rede_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_bluetooth_pressed() -> void:
	abrir_configuracao_android(ACTION_BLUETOOTH)

func _on_internet_pressed() -> void:
	abrir_configuracao_android(ACTION_INTERNET)

func _on_configuracoes_pressed() -> void:
	abrir_configuracao_android(ACTION_SETTINGS)

func _on_voltar_pressed() -> void:
	get_tree().change_scene_to_file("res://cenas/Menu.tscn")

func abrir_configuracao_android(acao: String) -> void:
	if OS.get_name() != "Android":
		print("Esta função funciona no Android. Ação solicitada: ", acao)
		return

	var erro := OS.shell_open("intent:#Intent;action=%s;end" % acao)
	if erro != OK:
		if acao == ACTION_WIFI:
			erro = OS.shell_open("intent:#Intent;action=%s;end" % ACTION_INTERNET)
		if erro != OK:
			erro = OS.shell_open("intent:#Intent;action=%s;end" % ACTION_SETTINGS)
	if erro != OK:
		push_warning("Não foi possível abrir as configurações do Android: %s" % acao)
