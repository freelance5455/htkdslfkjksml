extends Control

const ACTION_WIFI := "android.settings.WIFI_SETTINGS"
const ACTION_INTERNET := "android.settings.WIRELESS_SETTINGS"
const ACTION_SETTINGS := "android.settings.SETTINGS"
const BG := Color("#060b13")
const PANEL := Color("#0d1928")
const BLUE := Color("#1687ff")
const CYAN := Color("#19d4fb")
const MUTED := Color("#aebbd0")
const SAMPLE_NETWORKS := ["WiFi_Casa", "WiFi_123", "Rede_Publica", "Outro_WiFi"]

var _status: Label

func _ready() -> void:
	_build_interface()

func _build_interface() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var content := VBoxContainer.new()
	content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	content.offset_left = 32
	content.offset_top = 20
	content.offset_right = -32
	content.offset_bottom = -20
	content.add_theme_constant_override("separation", 14)
	add_child(content)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 14)
	content.add_child(header)

	var back := Button.new()
	back.text = "← Voltar"
	_style_button(back)
	back.pressed.connect(_on_voltar_pressed)
	header.add_child(back)

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title_box)

	var title := Label.new()
	title.text = "INTERNET / WI-FI"
	title.add_theme_color_override("font_color", Color.WHITE)
	title.add_theme_font_size_override("font_size", 27)
	title_box.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "Conexão e redes sem fio"
	subtitle.add_theme_color_override("font_color", MUTED)
	title_box.add_child(subtitle)

	var settings_top := Button.new()
	settings_top.text = "⚙ Configurações"
	_style_button(settings_top)
	settings_top.pressed.connect(_on_configuracoes_pressed)
	header.add_child(settings_top)

	var connected_card := _make_card()
	content.add_child(connected_card)
	var connected_box := VBoxContainer.new()
	connected_box.add_theme_constant_override("separation", 5)
	connected_card.add_child(connected_box)
	var connected_label := Label.new()
	connected_label.text = "🟢  Conectado (exemplo visual)"
	connected_label.add_theme_color_override("font_color", Color("#4ce38a"))
	connected_label.add_theme_font_size_override("font_size", 17)
	connected_box.add_child(connected_label)
	var current_network := Label.new()
	current_network.text = "MinhaInternet"
	current_network.add_theme_color_override("font_color", Color.WHITE)
	current_network.add_theme_font_size_override("font_size", 24)
	connected_box.add_child(current_network)

	var section_title := Label.new()
	section_title.text = "Redes disponíveis (exemplos)"
	section_title.add_theme_color_override("font_color", CYAN)
	section_title.add_theme_font_size_override("font_size", 18)
	content.add_child(section_title)

	var networks := GridContainer.new()
	networks.columns = 2
	networks.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	networks.add_theme_constant_override("h_separation", 10)
	networks.add_theme_constant_override("v_separation", 10)
	content.add_child(networks)

	for network_name in SAMPLE_NETWORKS:
		var network_button := Button.new()
		network_button.text = "📶  " + network_name
		network_button.custom_minimum_size = Vector2(0, 58)
		network_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_style_button(network_button)
		network_button.pressed.connect(_on_wifi_pressed)
		networks.add_child(network_button)

	var note := Label.new()
	note.text = "Esta tela é uma prévia. Para ver redes reais e conectar, abra as configurações de Wi-Fi do Android."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.add_theme_color_override("font_color", MUTED)
	content.add_child(note)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(spacer)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 12)
	content.add_child(actions)

	var search_button := Button.new()
	search_button.text = "🔄 Procurar redes"
	search_button.custom_minimum_size = Vector2(0, 56)
	search_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_style_button(search_button, true)
	search_button.pressed.connect(_on_atualizar_wifi_pressed)
	actions.add_child(search_button)

	var settings_button := Button.new()
	settings_button.text = "⚙ Configurações de Wi-Fi"
	settings_button.custom_minimum_size = Vector2(0, 56)
	settings_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_style_button(settings_button)
	settings_button.pressed.connect(_on_configuracoes_pressed)
	actions.add_child(settings_button)

	_status = Label.new()
	_status.text = "Toque em Procurar redes para abrir a tela real do Android."
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.add_theme_color_override("font_color", MUTED)
	content.add_child(_status)

func _make_card() -> PanelContainer:
	var card := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = PANEL
	style.border_color = BLUE
	style.set_border_width_all(1)
	style.set_corner_radius_all(16)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 15
	style.content_margin_bottom = 15
	card.add_theme_stylebox_override("panel", style)
	return card

func _style_button(button: Button, primary: bool = false) -> void:
	button.add_theme_font_size_override("font_size", 15)
	button.add_theme_color_override("font_color", Color.WHITE)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#075eaa") if primary else PANEL
	style.border_color = CYAN if primary else BLUE
	style.set_border_width_all(1)
	style.set_corner_radius_all(12)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	button.add_theme_stylebox_override("normal", style)
	button.add_theme_stylebox_override("hover", style)
	button.add_theme_stylebox_override("pressed", style)

func _on_wifi_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_atualizar_wifi_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_adicionar_rede_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_configuracoes_pressed() -> void:
	abrir_configuracao_android(ACTION_WIFI)

func _on_internet_pressed() -> void:
	abrir_configuracao_android(ACTION_INTERNET)

func _on_voltar_pressed() -> void:
	get_tree().change_scene_to_file("res://cenas/Menu.tscn")

func abrir_configuracao_android(acao: String) -> void:
	if OS.get_name() != "Android":
		if _status != null:
			_status.text = "Abra esta tela no Android para consultar redes reais."
		return

	var erro := OS.shell_open("intent:#Intent;action=%s;end" % acao)
	if erro != OK and acao == ACTION_WIFI:
		erro = OS.shell_open("intent:#Intent;action=%s;end" % ACTION_INTERNET)
	if erro != OK:
		erro = OS.shell_open("intent:#Intent;action=%s;end" % ACTION_SETTINGS)
	if _status != null:
		_status.text = "Não foi possível abrir as configurações." if erro != OK else "Abrindo as configurações de Wi-Fi do Android..."
