# Bombe Lite — menu horizontal e jogo

O pacote contém a versão **Android Studio (HTML/WebView)** e a versão **Godot**. O menu segue a referência Bombe Lite enviada, com orientação paisagem.

## Tela inicial do Android

A versão Android pode ser selecionada como app de tela inicial. No Bombe Lite, abra **Configurações do Bombe Lite → Definir tela inicial**; o Android mostrará a tela do sistema para escolher o app padrão.

## Android Studio
Abra a pasta `android/`, aguarde o Gradle sincronizar e rode em um aparelho Android. O HTML inicial fica em `android/app/src/main/assets/index.html`. A versão independente está em `index.html`.

Os atalhos do menu chamam a camada nativa Kotlin para abrir Minecraft, WhatsApp, Roblox, Free Fire, YouTube, Google, Play Store, Gmail, Configurações, Bluetooth ou uma página no navegador. O atalho do WhatsApp abre a conversa do número configurado em `wa.me` (5511999999999); no Godot, Minecraft e Roblox tentam primeiro os esquemas `minecraft://` e `roblox://` e, se falharem, abrem suas páginas oficiais na Play Store. O botão Bluetooth abre uma tela própria inspirada na imagem enviada, permite filtrar fones/caixas/outros, procurar aparelhos, selecionar e solicitar pareamento; o Android mostra a confirmação do sistema. A opção Desconectar encaminha ao painel Bluetooth do Android, pois a API pública não permite desconectar genericamente qualquer perfil. Apps sem fallback web precisam estar instalados; o próprio Bombe Lite mostra um aviso se não encontrar o pacote. O botão Bombe Lite abre o minijogo embutido.

Para usar o HTML independente, mantenha `index.html` junto com `bombe-logo.png`.

## Godot
Abra `project.godot` com Godot 4.3 ou superior. A cena inicial está definida no projeto (`cenas/Menu.tscn`); os atalhos Bluetooth e Configurações abrem suas cenas. O GDScript procura o singleton `BluetoothManager` (ou o antigo `BluetoothPlugin`) para ativar, procurar, parear por nome e desconectar. Sem esse plugin Android nativo, informa que o plugin não está instalado e oferece as configurações Bluetooth do sistema como alternativa.

Os atalhos de WhatsApp, Roblox, YouTube e Chrome agora tentam abrir o pacote Android pelo singleton `AndroidRuntime` e `JavaClassWrapper`, com site oficial como alternativa se o app não estiver instalado ou o runtime não existir. Para abrir apps nativamente na compilação Godot para Android, é necessário exportar com um plugin que forneça `AndroidRuntime`; esse singleton não é incluído pelo projeto Godot por si só. A versão Android Studio/WebView do pacote já usa a integração nativa Kotlin e abre esses apps sem depender desse plugin Godot. O endereço `https://appassets.androidplatform.net/web/whatsapp` só funciona quando um WebView está configurado com `WebViewAssetLoader`; por isso, o fallback usado aqui é o site oficial do WhatsApp.

## Orientação da tela
O singleton global `Orientacao` inicia o app Android em rotação automática pelo sensor. De qualquer script, use `Orientacao.tela_vertical()`, `Orientacao.tela_horizontal()`, `Orientacao.tela_vertical_invertida()`, `Orientacao.tela_horizontal_invertida()` ou `Orientacao.rotacao_automatica()` para mudar a orientação. No Godot Editor/desktop, esses métodos não alteram a orientação.

## Internet e Wi-Fi
A categoria **Internet** inclui **Wi-Fi** e **Ver redes**. A tela mostra a rede conectada e quatro nomes como **exemplos visuais**; ela não lê a rede atual nem faz varredura real. Os botões **Procurar redes** e **Configurações de Wi-Fi** abrem as configurações oficiais do Android, onde aparecem as redes reais, a conexão e a senha. A tela Godot está em `res://cenas/Wifi.tscn`; a versão Android/WebView tem a mesma prévia. A grade de apps usa `cenas/RolagemToque.gd` para permitir rolagem vertical e horizontal por toque.

## Ícones
O emblema foi recortado da imagem de referência enviada. Os ícones individuais dos apps foram representados com símbolos; os pacotes Android e ações nativas ficam mapeados em `android/app/src/main/java/com/bombelite/app/MainActivity.kt`.


## Loja Bombe Lite
No menu principal, toque em **Loja** para abrir a loja visual inspirada na referência enviada. Na versão Android/WebView, a loja tem busca e filtros por jogos, apps e destaques. Na versão Godot, abra a categoria **LOJA**. O catálogo reúne Minecraft, Roblox, Free Fire, GTA: San Andreas, Among Us e outros jogos, além de WhatsApp, TikTok, YouTube, Chrome e Spotify. **Instalar** abre a página oficial do item na Play Store, onde você confirma a instalação. GTA: San Andreas aparece no catálogo no lugar de GTA V, que não é um lançamento Android oficial da Play Store.

## Baixar jogos
Minecraft, Roblox e Free Fire abrem o app se estiver instalado; caso contrário, levam à página do jogo na Play Store. Na categoria Jogos, toque em **Baixar mais jogos** para pesquisar outros títulos. A instalação é concluída pelo usuário na Play Store.


## Imagens enviadas
As imagens enviadas ficam nos assets Android e na raiz do projeto. Abra **Todos os apps → Sobre** para consultar as referências de Bluetooth e configurações; as imagens são ilustrativas.

## Bluetooth e configurações adicionados
As duas imagens enviadas nesta conversa foram incluídas na raiz do projeto e nos assets Android como `referencia_bluetooth_enviada.jpg` e `referencia_configuracoes_enviada.jpg`. No Android, elas podem ser abertas em **Todos os apps → Sobre**; a imagem de configurações também aparece na tela **Configurações do Bombe Lite**. A tela Bluetooth agora tem filtros por tipo, seleção do dispositivo e os botões **Parear** e **Desconectar**.

A tela Configurações do Bombe Lite inclui ativação/desativação de notificações (estado visual), seleção entre **Só ícone** e **Detalhes**, controle de transparência da prévia, reversão de cor do texto e campo de pesquisa. Essas opções alteram a prévia do Bombe Lite; não mudam as notificações globais do Android.

No app Android Studio, **Procurar dispositivos** pede a permissão necessária e inicia a descoberta Bluetooth; **Parar busca** interrompe a descoberta, e a tela acompanha os eventos de dispositivo encontrado, conclusão da busca e conexão/desconexão. Tocar em um dispositivo encontrado solicita o pareamento ao Android. O sistema exibe a confirmação de pareamento. Em aparelhos Android 11 ou anteriores, a permissão de localização pode ser necessária para a descoberta Bluetooth. Na tela Godot, os resultados de `device_found` são exibidos como botões na VBox `ListaBluetooth`, com nome e endereço; tocar em um botão solicita a conexão/pareamento pelo singleton `BluetoothManager` (ou `BluetoothPlugin`). Endereços de exemplo não são inseridos como se fossem aparelhos reais: a lista mostra os dispositivos recebidos durante a busca. Sem o plugin Godot, abre as configurações Bluetooth do Android como alternativa segura.
