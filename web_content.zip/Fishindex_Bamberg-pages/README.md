Diese App ist ein Handbuch für alle bestehenden und angehenden Angler.

Ein Handbuch / Enzyklopädie über alle Fischarten, vorkommend im Donaueinzugsgebiet und den Flussregionen Bayerns, inklusive Fangbestimmungen zu Schonzeit und Schonmaß, regionale Bestimmungen für Oberfranken, sowie lokale Bestimmungen für die Stadt Bamberg, Gewässerstrecke Regnitz.

Die App ist in einem Karteikarten Stiel aufgebaut und besitzt ausklappbare Informationen zu den jeweiligen Fischarten, wie Systematik und Merkmale, sowie einige, bei der Angelprüfung häufig vorkommende, typische Prüfungsfragen.

Zusätzlich gibt es weiterführende Link-Buttons zu Wikipedia Seiten, Lernmaterial für die amtliche Angelprüfung in Bayern, einen Button zum herunterladen des kompletten , offiziellen Prüfungsfragenkatalogs (2026) und die Möglichkeit eine Angelprüfung zu simulieren, real mit 60 Fragen aus 5 Kategorien, randomisiert aus dem offiziellen Prüfungsfragenkatalog  (2026), 
aus den Bereichen:
•Fischkunde 
•Gewässerkunde 
•Schutz und Pflege 
•Fanggeräte und Rechtsvorschriften.

Auszüge und Links zu den Fischereiverordnungen und den geltenden Rechten zum Bayerischen Fischereigesetz (BayFiG), dem Landesfischereiverband Bayern e.V., der Verordnung zur Ausführung des Bayerischen Fischereigesetzes (AVBayFiG), zur Bezirksfischereiverordnung für den Bezirk Oberfranken, sowie zu regioalen Bestimmungen und Vorschriften der Unteren Schiffer- und Fischerzunft Bamberg (exklusiv Fluss Regnitz / linker Regnitzarm)