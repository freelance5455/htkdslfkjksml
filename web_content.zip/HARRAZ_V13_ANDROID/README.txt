HARRAZ V13 FINAL - Android Studio Project

HTML sumber: app/src/main/assets/web/index.html

Cara build:
1. Buka folder HARRAZ_V13_ANDROID di Android Studio.
2. Tunggu Gradle sync selesai.
3. Jika Android Studio meminta SDK 35, install Android SDK Platform 35.
4. Build > Build APK(s).
5. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk

Fitur native yang disiapkan:
- WebView + JavaScript + DOM Storage/localStorage
- Kamera barcode melalui getUserMedia
- Bluetooth printer thermal ESC/POS melalui AndroidBluetooth bridge
- Penyimpanan file Backup/Excel melalui AndroidFileSaver bridge
- Permission Bluetooth Android 12+ dan kamera

Catatan printer:
Printer thermal Bluetooth klasik harus dipasangkan terlebih dahulu di Pengaturan Bluetooth Android. Tombol HARRAZ kemudian menampilkan daftar perangkat yang sudah dipasangkan dan menghubungkannya melalui SPP.
