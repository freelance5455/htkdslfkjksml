package com.harraz.app;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.util.Base64;
import android.view.*;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
import android.widget.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView web;
    private WebViewAssetLoader assetLoader;
    private BluetoothSocket btSocket;
    private BluetoothDevice btDevice;
    private static final int REQ_CAMERA = 501;
    private static final int REQ_CREATE_FILE = 601;
    private byte[] pendingFileBytes;
    private String pendingFileMime = "application/octet-stream";
    private String pendingFileName = "HARRAZ-backup.bin";
    private final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(21,21,21));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(21,21,21));
        setupWebView();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
    }

    private void setupWebView() {
        web = new WebView(this);
        setContentView(web);
        assetLoader = new WebViewAssetLoader.Builder(this).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        web.addJavascriptInterface(new AndroidBluetoothBridge(), "AndroidBluetooth");
        web.addJavascriptInterface(new AndroidFileSaverBridge(), "AndroidFileSaver");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean cam = false;
                    for (String r : request.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
                    if (cam && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                        request.deny();
                    } else request.grant(request.getResources());
                });
            }
            @Override public boolean onConsoleMessage(ConsoleMessage cm) { return true; }
        });
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html");
    }

    private boolean hasBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return true;
    }
    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, 777);
    }

    private class AndroidBluetoothBridge {
        @JavascriptInterface public String connect() {
            if (!hasBtPermissions()) { runOnUiThread(() -> requestBtPermissions()); return "ERROR:Izin Bluetooth belum diberikan. Klik lagi setelah izin diberikan."; }
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) return "ERROR:Perangkat ini tidak mendukung Bluetooth.";
            if (!adapter.isEnabled()) {
                try { runOnUiThread(() -> startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))); } catch(Exception ignored) {}
                return "ERROR:Aktifkan Bluetooth lalu klik Hubungkan lagi.";
            }
            final Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded == null || bonded.isEmpty()) {
                runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this).setTitle("Printer Bluetooth")
                    .setMessage("Belum ada printer yang dipasangkan. Pasangkan printer thermal terlebih dahulu di Pengaturan Bluetooth Android, lalu kembali ke HARRAZ.")
                    .setPositiveButton("Pengaturan Bluetooth", (d,w)->startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)))
                    .setNegativeButton("Tutup", null).show());
                return "ERROR:Printer belum dipasangkan di Bluetooth Android.";
            }
            final CountDownLatch latch = new CountDownLatch(1);
            final BluetoothDevice[] chosen = new BluetoothDevice[1];
            final String[] names = new String[bonded.size()];
            final ArrayList<BluetoothDevice> list = new ArrayList<>(bonded);
            for (int i=0;i<list.size();i++) names[i] = safeName(list.get(i));
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this).setTitle("Pilih Printer Thermal")
                .setItems(names, (d,which)->{ chosen[0]=list.get(which); latch.countDown(); })
                .setNegativeButton("Batal", (d,w)->latch.countDown()).setOnCancelListener(d->latch.countDown()).show());
            try { if (!latch.await(60, TimeUnit.SECONDS)) return "ERROR:Waktu pemilihan printer habis."; } catch(InterruptedException e) { Thread.currentThread().interrupt(); return "ERROR:Proses dibatalkan."; }
            if (chosen[0] == null) return "ERROR:Pemilihan printer dibatalkan.";
            try {
                closeSocket();
                BluetoothSocket sock = chosen[0].createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                sock.connect();
                btSocket = sock; btDevice = chosen[0];
                return "OK:" + safeName(chosen[0]);
            } catch(Exception e) { closeSocket(); return "ERROR:Gagal terhubung: " + e.getMessage(); }
        }
        @JavascriptInterface public String print(String base64) {
            try {
                if (btSocket == null || !btSocket.isConnected()) return "ERROR:Printer belum terhubung.";
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                OutputStream out = btSocket.getOutputStream();
                int chunk=180; for(int i=0;i<data.length;i+=chunk){ int n=Math.min(chunk,data.length-i); out.write(data,i,n); out.flush(); SystemClock.sleep(12); }
                return "OK";
            } catch(Exception e) { return "ERROR:"+e.getMessage(); }
        }
        @JavascriptInterface public String disconnect() { closeSocket(); return "OK"; }
        private String safeName(BluetoothDevice d) { try { String n=d.getName(); return n==null||n.trim().isEmpty()?d.getAddress():n; } catch(Exception e){return "Printer";} }
    }

    private void closeSocket() { try { if(btSocket!=null) btSocket.close(); } catch(Exception ignored) {} btSocket=null; btDevice=null; }

    private class AndroidFileSaverBridge {
        @JavascriptInterface public String saveFile(String base64, String name, String mime) {
            try {
                pendingFileBytes = Base64.decode(base64, Base64.DEFAULT);
                pendingFileName = (name==null||name.isEmpty()) ? "HARRAZ-backup.bin" : name;
                pendingFileMime = (mime==null||mime.isEmpty()) ? "application/octet-stream" : mime;
                runOnUiThread(() -> {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(pendingFileMime);
                    i.putExtra(Intent.EXTRA_TITLE, pendingFileName);
                    startActivityForResult(i, REQ_CREATE_FILE);
                });
                return "OK";
            } catch(Exception e) { return "ERROR:"+e.getMessage(); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==REQ_CREATE_FILE && resultCode==RESULT_OK && data!=null && pendingFileBytes!=null) {
            try (OutputStream out=getContentResolver().openOutputStream(data.getData())) { out.write(pendingFileBytes); Toast.makeText(this,"File berhasil disimpan",Toast.LENGTH_SHORT).show(); }
            catch(Exception e){ Toast.makeText(this,"Gagal menyimpan: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        }
        if(requestCode==REQ_CREATE_FILE){ pendingFileBytes=null; }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==777 && Build.VERSION.SDK_INT>=31 && (results.length==0 || results[0]!=PackageManager.PERMISSION_GRANTED)) Toast.makeText(this,"Izin Bluetooth diperlukan untuk printer thermal",Toast.LENGTH_LONG).show();
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ closeSocket(); if(web!=null) web.destroy(); super.onDestroy(); }
}
