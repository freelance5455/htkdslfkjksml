Farid Plumber Pro — Complete App Source Code

How to run locally:
1. Install Node.js 22+.
2. Extract this ZIP file and open a terminal inside the folder.
3. Run: npm install
4. (Optional for AI Assistant) Copy .env.example to .env and add your GEMINI_API_KEY.
5. Start dev server: npm run dev
   Or build for production: npm run build && npm start
6. Open http://localhost:3000 in Google Chrome.
