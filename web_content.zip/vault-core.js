/* =========================================================================
   نواة الخزنة لتطبيق الجوال — تنسيق v3 (تشفير عميق).

   سلسلة المفاتيح:
     كلمة المرور ──scrypt(32 MiB)──► K_root ──AEAD──► K_vault (عشوائي 256-bit)
     K_vault ──HKDF-SHA256──► K_meta            (الإعدادات + سجل الأمان)
     K_vault ──HKDF-SHA256──► K_entry:<id>      (مفتاح مستقل لكل مدخل + AAD)

   لماذا: scrypt ذاكرة-صعبة (32 MiB لكل تخمين) بدل PBKDF2 الذي يمكن
   تسريعه على GPU؛ ومفتاح مستقل لكل مدخل يمنع تسريب مدخل ببقية الخزنة،
   وربط AAD بالمعرّف يمنع تبديل المدخلات.
   ========================================================================= */
'use strict';

const PV = (() => {
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  /** معاملات KDF الافتراضية — مطابقة تمامًا لأداة الكمبيوتر. */
  const KDF = Object.freeze({
    algo: 'scrypt',
    N: 32768, // 32768 × 128 × 8 = 32 MiB
    r: 8,
    p: 1,
    keyLen: 32,
    saltBytes: 32,
  });

  /** معاملات التقوية القصوى (64 MiB) — أبطأ وأقوى. */
  const STRONG_KDF = Object.freeze({
    algo: 'scrypt',
    N: 65536,
    r: 8,
    p: 1,
    keyLen: 32,
    saltBytes: 32,
  });

  /** معاملات PBKDF2 — للقراءة فقط (خزائن v2 القديمة). */
  const PBKDF2_KDF = Object.freeze({
    algo: 'pbkdf2',
    hash: 'sha256',
    iterations: 310000,
    keyLen: 32,
    saltBytes: 16,
  });

  const HASH_NAMES = { sha1: 'SHA-1', sha256: 'SHA-256', sha384: 'SHA-384', sha512: 'SHA-512' };

  const AAD_WRAP = 'passvault:v3:wrap';
  const AAD_META = 'passvault:v3:meta';

  const PHRASE_WORDS = 12;
  const LOG_GENESIS = '0'.repeat(64);
  const LOG_LIMIT = 500;

  // ---------------------------------------------------------- ترميز base64

  function b64(bytes) {
    const arr = new Uint8Array(bytes);
    let bin = '';
    for (let i = 0; i < arr.length; i += 1) bin += String.fromCharCode(arr[i]);
    return btoa(bin);
  }

  function unb64(value) {
    const bin = atob(String(value));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
    return out;
  }

  // --------------------------------------------------------- قائمة الكلمات

  let wordlistPromise = null;

  function wordlist() {
    if (!wordlistPromise) {
      wordlistPromise = fetch('wordlist.json')
        .then((r) => (r.ok ? r.json() : []))
        .catch(() => []);
    }
    return wordlistPromise;
  }

  /** توحيد صيغة العبارة: أحرف صغيرة وفواصل موحّدة. */
  function normalizePhrase(phrase) {
    return String(phrase || '')
      .toLowerCase()
      .trim()
      .split(/[\s,،\-–—_/]+/)
      .filter(Boolean)
      .join(' ');
  }

  /** توليد عبارة استرجاع عشوائية (12 كلمة ≈ 120 بت). */
  async function generatePhrase(count = PHRASE_WORDS) {
    const wl = await wordlist();
    if (wl && wl.length) {
      const words = [];
      for (let i = 0; i < count; i += 1) {
        words.push(wl[crypto.getRandomValues(new Uint32Array(1))[0] % wl.length]);
      }
      return words.join(' ');
    }
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const groups = [];
    for (let g = 0; g < 6; g += 1) {
      let part = '';
      for (let i = 0; i < 4; i += 1) {
        part += alphabet[crypto.getRandomValues(new Uint32Array(1))[0] % alphabet.length];
      }
      groups.push(part);
    }
    return groups.join('-');
  }

  /** عرض العبارة مقسّمة بشرطات. */
  function formatPhrase(phrase) {
    return normalizePhrase(phrase).split(' ').join('-');
  }

  // -------------------------------------------------------------- التشفير

  /** اشتقاق مفتاح خام (32 بايت) — scrypt أو PBKDF2 للقراءة القديمة. */
  async function deriveKeyBytes(secret, salt, params = {}) {
    const p = { ...KDF, ...params };
    if (p.algo === 'pbkdf2') {
      const base = await crypto.subtle.importKey(
        'raw', enc.encode(String(secret)), 'PBKDF2', false, ['deriveBits'],
      );
      const bits = await crypto.subtle.deriveBits(
        {
          name: 'PBKDF2',
          salt,
          iterations: p.iterations,
          hash: HASH_NAMES[String(p.hash || 'sha256').toLowerCase()] || 'SHA-256',
        },
        base,
        p.keyLen * 8,
      );
      return new Uint8Array(bits);
    }
    return SCRYPT.scrypt(String(secret), salt, p.N, p.r, p.p, p.keyLen);
  }

  /** HKDF-SHA256 — مطابق لتنفيذ Node (crypto.hkdfSync). */
  async function hkdf(ikm, salt, info, length = 32) {
    const base = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'HKDF', hash: 'SHA-256', salt, info }, base, length * 8,
    );
    return new Uint8Array(bits);
  }

  /** استيراد مفتاح خام إلى مفتاح AES قابل للاستخدام (غير قابل للاستخراج). */
  async function aesKeyFromBytes(bytes) {
    return crypto.subtle.importKey(
      'raw', bytes, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt'],
    );
  }

  async function encryptBytes(keyBytes, bytes, aad) {
    const key = await aesKeyFromBytes(keyBytes);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const params = { name: 'AES-GCM', iv };
    if (aad !== undefined && aad !== null) {
      params.additionalData = typeof aad === 'string' ? enc.encode(aad) : aad;
    }
    const ct = new Uint8Array(
      await crypto.subtle.encrypt(params, key, bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)),
    );
    return {
      algo: 'aes-256-gcm',
      iv: b64(iv),
      tag: b64(ct.slice(ct.length - 16)),
      data: b64(ct.slice(0, ct.length - 16)),
    };
  }

  async function decryptBytes(keyBytes, env, aad) {
    const key = await aesKeyFromBytes(keyBytes);
    const iv = unb64(env.iv);
    const tag = unb64(env.tag);
    const data = unb64(env.data);
    const ct = new Uint8Array(data.length + tag.length);
    ct.set(data, 0);
    ct.set(tag, data.length);
    const params = { name: 'AES-GCM', iv };
    if (aad !== undefined && aad !== null) {
      params.additionalData = typeof aad === 'string' ? enc.encode(aad) : aad;
    }
    const plain = new Uint8Array(await crypto.subtle.decrypt(params, key, ct));
    return plain;
  }

  async function encryptJson(keyBytes, obj, aad) {
    return encryptBytes(keyBytes, enc.encode(JSON.stringify(obj)), aad);
  }

  async function decryptJson(keyBytes, env, aad) {
    const plain = await decryptBytes(keyBytes, env, aad);
    return JSON.parse(dec.decode(plain));
  }

  /** SHA-256 ست عشري — لسلسلة سجل الأمان. */
  async function sha256Hex(text) {
    const digest = await crypto.subtle.digest('SHA-256', enc.encode(text));
    return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  // ---------------------------------------------------- سجل الأمان (سلسلة)

  function logHashHex(prev, record) {
    const payload = `${prev}\n${record.ts}\n${record.action}\n${record.target || ''}`;
    return sha256Hex(payload);
  }

  /** إعادة ربط السلسلة من أول سجل (بعد قصّ السجل القديم). */
  async function rechain(log) {
    const out = [];
    let prev = LOG_GENESIS;
    for (const record of log) {
      const next = { ts: record.ts, action: record.action, target: record.target || '' };
      const hash = await logHashHex(prev, next);
      out.push({ ...next, prev, hash });
      prev = hash;
    }
    return out;
  }

  /** إضافة حدث إلى سجل الأمان (بحد أقصى 500 سجل). */
  async function appendLog(payload, action, target = '') {
    if (!Array.isArray(payload.log)) payload.log = [];
    const prev = payload.log.length ? payload.log[payload.log.length - 1].hash : LOG_GENESIS;
    const record = { ts: new Date().toISOString(), action: String(action), target: String(target || ''), prev };
    record.hash = await logHashHex(prev, record);
    payload.log.push(record);
    if (payload.log.length > LOG_LIMIT) {
      payload.log = await rechain(payload.log.slice(payload.log.length - LOG_LIMIT));
    }
    return record;
  }

  /** التحقق من سلامة السلسلة — يكشف أي حذف أو تعديل. */
  async function verifyLog(log) {
    const list = Array.isArray(log) ? log : [];
    let prev = LOG_GENESIS;
    for (let i = 0; i < list.length; i += 1) {
      const r = list[i];
      if (!r || r.prev !== prev) {
        return { ok: false, count: list.length, brokenAt: i, reason: 'انقطاع السلسلة (سجل محذوف أو معاد ترتيبه)' };
      }
      const expected = await logHashHex(prev, { ts: r.ts, action: r.action, target: r.target || '' });
      if (r.hash !== expected) {
        return { ok: false, count: list.length, brokenAt: i, reason: 'محتوى السجل معدَّل' };
      }
      prev = r.hash;
    }
    return { ok: true, count: list.length };
  }

  // -------------------------------------------------------------- الخزنة

  function defaultPayload() {
    const now = new Date().toISOString();
    return {
      version: 3,
      entries: [],
      tags: [],
      log: [],
      settings: {
        vaultName: 'خزنة المفاتيح',
        autoLockMinutes: 5,
        clipboardClearSeconds: 15,
      },
      createdAt: now,
      updatedAt: now,
    };
  }

  /** مفتاح فرعي من K_vault عبر HKDF. */
  async function subKey(dataKeyBytes, hkdfSalt, info) {
    return hkdf(dataKeyBytes, hkdfSalt, enc.encode(info), 32);
  }

  /** البيانات الوصفية (تُشفَّر بـ K_meta). */
  function buildMetaPayload(payload) {
    return {
      ids: (payload.entries || []).map((e) => e.id),
      tags: payload.tags || [],
      settings: payload.settings || {},
      log: payload.log || [],
      createdAt: payload.createdAt,
      updatedAt: payload.updatedAt,
    };
  }

  /**
   * تشفير كل مدخل بمفتاح مستقل وبيانات مرتبطة بمعرّفه.
   * تُخزَّن كخريطة (المفتاح = المعرّف) — نفس صيغة أداة الكمبيوتر،
   * وبهذا لا يمكن نقل شيفرة مدخل إلى خانة مدخل آخر.
   */
  async function sealEntries(dataKeyBytes, hkdfSalt, payload) {
    const out = {};
    for (const entry of payload.entries || []) {
      const key = await subKey(dataKeyBytes, hkdfSalt, `passvault:v3:entry:${entry.id}`);
      out[entry.id] = await encryptBytes(key, enc.encode(JSON.stringify(entry)), entry.id);
    }
    return out;
  }

  /** فك تشفير المدخلات — AAD = المعرّف يمنع نقلها بين الخانات. */
  async function openEntries(dataKeyBytes, hkdfSalt, sealed, order) {
    const out = [];
    const ids = Array.isArray(order) && order.length ? order : Object.keys(sealed || {});
    for (const id of ids) {
      const item = sealed && sealed[id];
      if (!item) continue;
      const key = await subKey(dataKeyBytes, hkdfSalt, `passvault:v3:entry:${id}`);
      const plain = await decryptBytes(key, item, id);
      out.push(JSON.parse(dec.decode(plain)));
    }
    return out;
  }

  /** بناء غلاف الاسترجاع: K_vault ملفوف بمفتاح مشتق من العبارة. */
  async function buildRecovery(phrase, dataKeyBytes, kdf = KDF) {
    const salt = crypto.getRandomValues(new Uint8Array(kdf.saltBytes || 32));
    const key = await deriveKeyBytes(normalizePhrase(phrase), salt, kdf);
    return {
      enabled: true,
      algo: kdf.algo,
      N: kdf.N,
      r: kdf.r,
      p: kdf.p,
      keyLen: kdf.keyLen,
      salt: b64(salt),
      wrap: await encryptBytes(key, dataKeyBytes, AAD_WRAP),
    };
  }

  /**
   * إنشاء خزنة جديدة.
   * @returns {Promise<{envelope, dataKeyBytes, payload, recoveryPhrase?}>}
   */
  async function createEnvelope(masterPassword, payload, options = {}) {
    const salt = crypto.getRandomValues(new Uint8Array(KDF.saltBytes));
    const rootKey = await deriveKeyBytes(masterPassword, salt, KDF);
    const dataKeyBytes = crypto.getRandomValues(new Uint8Array(32));
    const hkdfSalt = crypto.getRandomValues(new Uint8Array(16));

    const envelope = {
      format: 'passvault',
      version: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      kdf: { ...KDF, salt: b64(salt) },
      hkdfSalt: b64(hkdfSalt),
      vault: await encryptBytes(rootKey, dataKeyBytes, AAD_WRAP),
      meta: await encryptJson(
        await subKey(dataKeyBytes, hkdfSalt, AAD_META),
        buildMetaPayload(payload),
        AAD_META,
      ),
      entries: [],
    };

    let recoveryPhrase = null;
    if (options.recovery) {
      recoveryPhrase = await generatePhrase();
      envelope.recovery = await buildRecovery(recoveryPhrase, dataKeyBytes, KDF);
    }
    return { envelope, dataKeyBytes, payload, recoveryPhrase };
  }

  /**
   * فتح خزنة — بكلمة المرور الرئيسية أو بكلمة الاسترجاع.
   * @returns {Promise<{dataKeyBytes, payload, usedRecovery, legacy?}>}
   */
  async function openEnvelope(envelope, secret) {
    const version = envelope.version || 1;

    if (version >= 3) {
      const rootKey = await deriveKeyBytes(secret, unb64(envelope.kdf.salt), envelope.kdf);
      let dataKeyBytes = null;
      let usedRecovery = false;

      try {
        dataKeyBytes = await decryptBytes(rootKey, envelope.vault, AAD_WRAP);
      } catch {
        if (envelope.recovery && envelope.recovery.enabled) {
          const rKey = await deriveKeyBytes(
            normalizePhrase(secret),
            unb64(envelope.recovery.salt),
            envelope.recovery,
          );
          try {
            dataKeyBytes = await decryptBytes(rKey, envelope.recovery.wrap, AAD_WRAP);
          } catch {
            // غلاف قديم (v2) بلا بيانات مرتبطة
            dataKeyBytes = await decryptBytes(rKey, envelope.recovery.wrap);
          }
          usedRecovery = true;
        } else {
          throw new Error('AUTH_FAILED');
        }
      }

      const hkdfSalt = unb64(envelope.hkdfSalt);
      const meta = await decryptJson(
        await subKey(dataKeyBytes, hkdfSalt, AAD_META), envelope.meta, AAD_META,
      );
      const entries = await openEntries(dataKeyBytes, hkdfSalt, envelope.entries, meta.ids);
      const payload = {
        version: 3,
        entries,
        tags: meta.tags || [],
        log: meta.log || [],
        settings: meta.settings || {},
        createdAt: meta.createdAt || envelope.createdAt,
        updatedAt: meta.updatedAt || envelope.updatedAt,
      };
      return { dataKeyBytes, payload, usedRecovery };
    }

    // ── v2: K_data ملفوف مرتين ──
    if (version === 2) {
      const rootKey = await deriveKeyBytes(secret, unb64(envelope.kdf.salt), envelope.kdf);
      let dataKeyBytes = null;
      let usedRecovery = false;
      try {
        dataKeyBytes = await decryptBytes(rootKey, envelope.cipher);
      } catch {
        if (envelope.recovery && envelope.recovery.enabled) {
          const rKey = await deriveKeyBytes(
            normalizePhrase(secret),
            unb64(envelope.recovery.salt),
            envelope.recovery,
          );
          dataKeyBytes = await decryptBytes(rKey, envelope.recovery.wrap);
          usedRecovery = true;
        } else {
          throw new Error('AUTH_FAILED');
        }
      }
      const payload = await decryptJson(dataKeyBytes, envelope.payload);
      const upgraded = await upgradeToV3(envelope, secret, payload, dataKeyBytes);
      return { dataKeyBytes: upgraded.dataKeyBytes, payload: upgraded.payload, usedRecovery, upgraded: true };
    }

    // ── v1 (قديم) ──
    const legacyKey = await deriveKeyBytes(secret, unb64(envelope.kdf.salt), envelope.kdf);
    const payload = await decryptJson(legacyKey, envelope.cipher);
    const upgraded = await upgradeToV3(envelope, secret, payload, null);
    return { dataKeyBytes: upgraded.dataKeyBytes, payload: upgraded.payload, usedRecovery: false, upgraded: true };
  }

  /**
   * ترقية خزنة قديمة (v1/v2) إلى v3 — نفس كلمة المرور، بلا فقد بيانات.
   */
  async function upgradeToV3(envelope, secret, payload, existingDataKey) {
    const salt = crypto.getRandomValues(new Uint8Array(KDF.saltBytes));
    const rootKey = await deriveKeyBytes(secret, salt, KDF);
    const dataKeyBytes = existingDataKey || crypto.getRandomValues(new Uint8Array(32));
    const hkdfSalt = crypto.getRandomValues(new Uint8Array(16));

    payload.version = 3;
    if (!Array.isArray(payload.log)) payload.log = [];
    await appendLog(payload, 'upgrade', `من الصيغة v${envelope.version || 1}`);

    envelope.version = 3;
    envelope.kdf = { ...KDF, salt: b64(salt) };
    envelope.hkdfSalt = b64(hkdfSalt);
    envelope.vault = await encryptBytes(rootKey, dataKeyBytes, AAD_WRAP);
    envelope.meta = await encryptJson(
      await subKey(dataKeyBytes, hkdfSalt, AAD_META), buildMetaPayload(payload), AAD_META,
    );
    envelope.entries = await sealEntries(dataKeyBytes, hkdfSalt, payload);
    delete envelope.cipher;
    delete envelope.payload;
    envelope.updatedAt = new Date().toISOString();
    return { dataKeyBytes, payload };
  }

  /** إعادة تشفير المحتوى وحفظه (K_vault ثابت فلا تتأثر نسختا الفتح). */
  async function saveEnvelope(envelope, dataKeyBytes, payload) {
    const hkdfSalt = unb64(envelope.hkdfSalt);
    envelope.meta = await encryptJson(
      await subKey(dataKeyBytes, hkdfSalt, AAD_META), buildMetaPayload(payload), AAD_META,
    );
    envelope.entries = await sealEntries(dataKeyBytes, hkdfSalt, payload);
    envelope.updatedAt = new Date().toISOString();
    return envelope;
  }

  /** تغيير كلمة المرور الرئيسية: إعادة تغليف K_vault فقط. */
  async function changeMasterPassword(envelope, dataKeyBytes, newPassword, kdf = null) {
    // بدون معاملات صريحة نحافظ على مستوى التقوية الحالي (لا نخفضه)
    const params = kdf
      ? { ...KDF, ...kdf }
      : { ...KDF, N: (envelope.kdf && envelope.kdf.N) || KDF.N };
    const salt = crypto.getRandomValues(new Uint8Array(params.saltBytes));
    const rootKey = await deriveKeyBytes(newPassword, salt, params);
    envelope.kdf = { ...params, salt: b64(salt) };
    envelope.vault = await encryptBytes(rootKey, dataKeyBytes, AAD_WRAP);
    envelope.updatedAt = new Date().toISOString();
    return envelope;
  }

  /** تفعيل الاسترجاع بعبارة (تُولَّد إن لم تُحدَّد). */
  async function enableRecovery(envelope, dataKeyBytes, phrase, kdf = KDF) {
    const p = phrase || (await generatePhrase());
    envelope.recovery = await buildRecovery(p, dataKeyBytes, kdf);
    envelope.updatedAt = new Date().toISOString();
    return p;
  }

  function disableRecovery(envelope) {
    delete envelope.recovery;
    envelope.updatedAt = new Date().toISOString();
    return envelope;
  }

  function hasRecovery(envelope) {
    return Boolean(envelope && envelope.recovery && envelope.recovery.enabled);
  }

  return {
    AAD_META,
    AAD_WRAP,
    KDF,
    LOG_GENESIS,
    LOG_LIMIT,
    PHRASE_WORDS,
    PBKDF2_KDF,
    STRONG_KDF,
    aesKeyFromBytes,
    appendLog,
    b64,
    buildRecovery,
    changeMasterPassword,
    createEnvelope,
    decryptBytes,
    decryptJson,
    defaultPayload,
    deriveKeyBytes,
    disableRecovery,
    enableRecovery,
    encryptBytes,
    encryptJson,
    formatPhrase,
    generatePhrase,
    hasRecovery,
    hkdf,
    normalizePhrase,
    openEnvelope,
    rechain,
    saveEnvelope,
    sha256Hex,
    unb64,
    verifyLog,
    wordlist,
  };
})();

window.PV = PV;
