package it.dagennaro.express;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.net.URLEncoder;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this);
    setContentView(web);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    web.setWebChromeClient(new WebChromeClient());
    web.addJavascriptInterface(new NativeActions(), "AndroidBridge");
    web.setWebViewClient(new WebViewClient());
    web.loadUrl("file:///android_asset/index.html");
  }
  public class NativeActions {
    @JavascriptInterface public void openWhatsApp(String phone, String message) {
      runOnUiThread(() -> {
        try {
          String url = "https://wa.me/" + phone + "?text=" + Uri.encode(message);
          Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
          i.setPackage("com.whatsapp");
          startActivity(i);
        } catch (Exception e) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(message)))); }
          catch (Exception ex) { Toast.makeText(MainActivity.this, "Impossibile aprire WhatsApp. Verifica che sia installato.", Toast.LENGTH_LONG).show(); }
        }
      });
    }
    @JavascriptInterface public void openMaps(String address) {
      runOnUiThread(() -> {
        try {
          Uri uri = Uri.parse("geo:0,0?q=" + Uri.encode(address));
          Intent i = new Intent(Intent.ACTION_VIEW, uri);
          startActivity(i);
        } catch (Exception e) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(address)))); }
          catch (Exception ex) { Toast.makeText(MainActivity.this, "Impossibile aprire Maps.", Toast.LENGTH_LONG).show(); }
        }
      });
    }
  }
  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
