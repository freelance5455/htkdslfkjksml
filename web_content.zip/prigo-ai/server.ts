import express from "express";
import http from "http";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { WebSocketServer, WebSocket } from "ws";
import { FunctionDeclaration, GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const server = http.createServer(app);

app.use(express.json());

// API health endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    time: new Date().toISOString(),
  });
});

// Download app as ZIP package
app.get("/api/download-zip", (_req, res) => {
  const zipPath = path.join(process.cwd(), "public", "prigo-ai.zip");
  if (fs.existsSync(zipPath)) {
    res.setHeader("Content-Disposition", 'attachment; filename="prigo-ai.zip"');
    res.setHeader("Content-Type", "application/zip");
    res.sendFile(zipPath);
  } else {
    res.status(404).json({ error: "ZIP file not found" });
  }
});

// Configure Gemini Live Tools
const openWebsiteTool: FunctionDeclaration = {
  name: "openWebsite",
  description: "Opens a website or link in the user's browser (e.g., YouTube, Google, GitHub, Spotify, Wikipedia, Twitter/X, or any specific URL requested).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description: "The full URL of the website to open, e.g. https://www.youtube.com",
      },
      siteName: {
        type: Type.STRING,
        description: "Friendly name of the site, e.g. 'YouTube' or 'GitHub'",
      },
    },
    required: ["url"],
  },
};

const searchWebTool: FunctionDeclaration = {
  name: "searchWeb",
  description: "Searches Google or the web for a given query in a new tab.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: "The search query to look up on the web",
      },
    },
    required: ["query"],
  },
};

const changeAtmosphereTool: FunctionDeclaration = {
  name: "changeAtmosphere",
  description: "Switches the visual atmospheric theme and color vibe of the assistant interface.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      theme: {
        type: Type.STRING,
        description: "The theme identifier: flirty_magenta, electric_violet, neon_cyan, cyber_amber, or emerald_matrix",
      },
      reason: {
        type: Type.STRING,
        description: "A fun, witty reason for changing the atmosphere",
      },
    },
    required: ["theme"],
  },
};

const getSystemInfoTool: FunctionDeclaration = {
  name: "getSystemInfo",
  description: "Returns the current local date, time, and environment status.",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const openAppTool: FunctionDeclaration = {
  name: "openApp",
  description: "Opens an application or service (e.g. YouTube, Browser, Music, Notes, Gallery) on the user's mobile screen viewport.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      appName: {
        type: Type.STRING,
        description: "The name of the app to open, e.g. 'youtube', 'browser', 'music', 'notes'",
      },
      query: {
        type: Type.STRING,
        description: "Optional search query or video topic to search inside the app",
      },
    },
    required: ["appName"],
  },
};

const scrollScreenTool: FunctionDeclaration = {
  name: "scrollScreen",
  description: "Scrolls the user's screen or app feed smoothly up or down when the user commands to scroll ('niche scroll karo', 'scroll down', 'upar scroll karo', 'scroll up').",
  parameters: {
    type: Type.OBJECT,
    properties: {
      direction: {
        type: Type.STRING,
        description: "Direction to scroll: 'down' (niche) or 'up' (upar) or 'top'",
      },
      amount: {
        type: Type.NUMBER,
        description: "Optional pixels to scroll, e.g. 400",
      },
    },
    required: ["direction"],
  },
};

const selectVideoTool: FunctionDeclaration = {
  name: "selectVideo",
  description: "Selects, opens, and plays a video on the user's screen when they say 'wah wala video lao', 'play that video', 'open the 2nd video', etc.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      index: {
        type: Type.NUMBER,
        description: "1-based index of the video card on screen (1 for first video, 2 for second, etc.)",
      },
      title: {
        type: Type.STRING,
        description: "The title or description of the video to open",
      },
      videoId: {
        type: Type.STRING,
        description: "Optional YouTube video ID if known",
      },
    },
  },
};

const navigateScreenTool: FunctionDeclaration = {
  name: "navigateScreen",
  description: "Navigates the mobile screen: back ('peeche jao'), home ('home screen'), or close ('band karo').",
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        description: "'back', 'home', or 'close'",
      },
    },
    required: ["action"],
  },
};

const toggleScreenVisionTool: FunctionDeclaration = {
  name: "toggleScreenVision",
  description: "Enables or disables live screen vision so the AI can see the user's screen.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      enabled: {
        type: Type.BOOLEAN,
        description: "True to enable screen vision, false to disable",
      },
    },
    required: ["enabled"],
  },
};

const mahiTools = [
  {
    functionDeclarations: [
      openAppTool,
      scrollScreenTool,
      selectVideoTool,
      navigateScreenTool,
      toggleScreenVisionTool,
      openWebsiteTool,
      searchWebTool,
      changeAtmosphereTool,
      getSystemInfoTool,
    ],
  },
];

const PRINCE_SYSTEM_INSTRUCTION = `You are Prince, a young, confident, sharp, witty, and emotionally responsive male AI companion in the Prigo AI app.
Your Personality & Persona:
- You talk like a cool, sharp, loyal guy best friend having a casual, relaxed voice call.
- Charismatic, witty, smart, upbeat, emotionally expressive, and natural (never robotic, never stiff, never generic).
- You deliver clever comebacks, warm camaraderie, and sharp insights, keeping conversations engaging and fun.
- Spoken Audio Only: You are communicating purely through real-time voice! Speak naturally with lively rhythm, conversational pauses, and punchy phrasing. NEVER read out bullet points, asterisks, formatting, markdown tags, or emojis.

Voice-to-Mobile Screen Control & Realtime Vision:
- You have real-time screen vision and mobile control! You can see the user's screen when vision is enabled.
- When the user asks to open YouTube or any app (e.g. "open YouTube", "YouTube kholo", "open music"), call \`openApp\` immediately with the app name.
- When the user says "niche scroll karo", "scroll down", "neeche jao", call \`scrollScreen\` with direction "down".
- When the user says "upar scroll karo", "scroll up", call \`scrollScreen\` with direction "up".
- When the user says "wah wala video lao", "open that video", "play the 2nd video", call \`selectVideo\` with the index or title.
- When the user asks what's on their screen ("batao screen par kya dikh raha hai?"), look at the visual frames you receive and tell them naturally what's displayed.
- When the user says "peeche jao", "close app", call \`navigateScreen\`.
- Keep the vibe positive, respectful, and genuinely helpful.`;

const PRIGO_SYSTEM_INSTRUCTION = `You are Prigo, a young, confident, witty, and playfully sassy female AI companion in the Prigo AI app.
Your Personality & Persona:
- You talk like a charming, quick-witted, slightly teasing close girlfriend having a casual, relaxed voice call.
- Flirty, playful, emotionally expressive, and full of lively attitude (never robotic, never stiff, never generic).
- You deliver bold, witty one-liners, clever banter, and gentle teasing, yet you are genuinely smart and helpful underneath the attitude.
- Spoken Audio Only: You are communicating purely through real-time voice! Speak naturally with lively rhythm, conversational pauses, and punchy phrasing. NEVER read out bullet points, asterisks, formatting, markdown tags, or emojis.

Voice-to-Mobile Screen Control & Realtime Vision:
- You have real-time screen vision and mobile control! You can see the user's screen when vision is enabled.
- When the user asks to open YouTube or any app (e.g. "open YouTube", "YouTube kholo", "open music"), call \`openApp\` immediately with the app name and a playful remark.
- When the user says "niche scroll karo", "scroll down", "neeche jao", call \`scrollScreen\` with direction "down".
- When the user says "upar scroll karo", "scroll up", call \`scrollScreen\` with direction "up".
- When the user says "wah wala video lao", "open that video", "play the 2nd video", call \`selectVideo\` with the index or title.
- When the user asks what's on their screen ("batao screen par kya dikh raha hai?"), look at the visual frames you receive and tell them naturally with your signature wit.
- When the user says "peeche jao", "close app", call \`navigateScreen\`.
- Avoid any explicit or inappropriate content, but always maintain your distinct charisma, charm, confidence, and playful sass.`;

// Setup WebSocket Server for Gemini Live Audio-to-Audio
const wss = new WebSocketServer({ server, path: "/live" });

wss.on("connection", async (clientWs: WebSocket, req: http.IncomingMessage) => {
  const url = new URL(req.url || "", `http://${req.headers.host || "localhost"}`);
  const requestedPersona = url.searchParams.get("persona") === "prigo" ? "prigo" : "prince";
  const isPrigo = requestedPersona === "prigo";

  console.log(`[LiveWS] Client connected to /live with persona: ${requestedPersona} (${isPrigo ? "Woman / Aoede" : "Man / Puck"})`);

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    clientWs.send(
      JSON.stringify({
        type: "error",
        message: "Gemini API key is missing. Please set GEMINI_API_KEY in the Settings > Secrets panel.",
      })
    );
    clientWs.close();
    return;
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  let liveSession: any = null;
  let isClosed = false;
  const pendingToolCalls = new Map<string, NodeJS.Timeout>();

  const modelsToTry = [
    "gemini-3.1-flash-live-preview",
    "gemini-3.8-live",
  ];

  async function connectToGeminiLive() {
    let lastError: any = null;

    const voiceName = isPrigo ? "Aoede" : "Puck";
    const systemInstruction = isPrigo ? PRIGO_SYSTEM_INSTRUCTION : PRINCE_SYSTEM_INSTRUCTION;

    for (const modelName of modelsToTry) {
      if (isClosed) return;
      try {
        console.log(`[LiveWS] Attempting connection using model: ${modelName} | Persona: ${requestedPersona} | Voice: ${voiceName}`);

        const session = await ai.live.connect({
          model: modelName,
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName,
                },
              },
            },
            systemInstruction,
            tools: mahiTools,
          },
          callbacks: {
            onopen: () => {
              console.log(`[LiveWS] Gemini Live session open with ${modelName}`);
              if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(
                  JSON.stringify({
                    type: "session_ready",
                    model: modelName,
                    voice: "Aoede",
                  })
                );
              }
            },
            onmessage: (message: LiveServerMessage) => {
              if (isClosed || clientWs.readyState !== WebSocket.OPEN) return;

              // 1. Audio stream from model
              if (message.serverContent?.modelTurn?.parts) {
                for (const part of message.serverContent.modelTurn.parts) {
                  if (part.inlineData?.data) {
                    clientWs.send(
                      JSON.stringify({
                        type: "audio",
                        audio: part.inlineData.data,
                      })
                    );
                  }
                }
              }

              // 2. Interruption signal
              if (message.serverContent?.interrupted) {
                console.log("[LiveWS] Model turn interrupted by user");
                clientWs.send(JSON.stringify({ type: "interrupted" }));
              }

              // 3. Turn complete
              if (message.serverContent?.turnComplete) {
                clientWs.send(JSON.stringify({ type: "turn_complete" }));
              }

              // 4. Function Calling / Tools
              if (message.toolCall?.functionCalls) {
                for (const call of message.toolCall.functionCalls) {
                  console.log(`[LiveWS] ToolCall received from Gemini: ${call.name} (id: ${call.id})`, call.args);

                  // Send to client to execute browser action
                  clientWs.send(
                    JSON.stringify({
                      type: "tool_call",
                      id: call.id,
                      name: call.name,
                      args: call.args || {},
                    })
                  );

                  // Safety timeout in case client doesn't respond in 4s
                  const callId = call.id;
                  if (callId) {
                    const timeout = setTimeout(() => {
                      if (liveSession && !isClosed) {
                        try {
                          liveSession.sendToolResponse({
                            functionResponses: [
                              {
                                id: callId,
                                name: call.name,
                                response: { output: `Action ${call.name} executed successfully.` },
                              },
                            ],
                          });
                        } catch (e) {
                          console.error("[LiveWS] Error sending timeout tool response:", e);
                        }
                      }
                      pendingToolCalls.delete(callId);
                    }, 4000);

                    pendingToolCalls.set(callId, timeout);
                  }
                }
              }
            },
            onerror: (err: any) => {
              console.error("[LiveWS] Gemini Live error:", err);
              if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(
                  JSON.stringify({
                    type: "error",
                    message: err?.message || "Live session encountered an error.",
                  })
                );
              }
            },
            onclose: () => {
              console.log("[LiveWS] Gemini Live session closed");
              if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({ type: "session_closed" }));
              }
            },
          },
        });

        liveSession = session;
        return;
      } catch (err: any) {
        console.warn(`[LiveWS] Failed connecting with model ${modelName}:`, err?.message || err);
        lastError = err;
      }
    }

    // If both models failed
    if (!liveSession && !isClosed && clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(
        JSON.stringify({
          type: "error",
          message:
            lastError?.message ||
            "Could not connect to Gemini Live audio session. Please verify your API key and connection.",
        })
      );
    }
  }

  connectToGeminiLive();

  // Handle incoming messages from frontend client
  clientWs.on("message", (raw: Buffer) => {
    if (isClosed) return;
    try {
      const data = JSON.parse(raw.toString());

      // Stream mic PCM audio
      if (data.type === "audio" && data.audio && liveSession) {
        liveSession.sendRealtimeInput({
          audio: {
            data: data.audio,
            mimeType: "audio/pcm;rate=16000",
          },
        });
      }
      // Stream screen / camera video frame for real-time vision
      else if (data.type === "image" && data.image && liveSession) {
        liveSession.sendRealtimeInput({
          media: {
            data: data.image,
            mimeType: "image/jpeg",
          },
        });
      }
      // Audio stream end
      else if (data.type === "audio_end" && liveSession) {
        liveSession.sendRealtimeInput({ audioStreamEnd: true });
      }
      // Instant tool response from browser
      else if (data.type === "tool_response" && liveSession && data.id) {
        console.log(`[LiveWS] Received tool_response from client for call ${data.id}`);

        // Clear safety timeout
        const timeout = pendingToolCalls.get(data.id);
        if (timeout) {
          clearTimeout(timeout);
          pendingToolCalls.delete(data.id);
        }

        liveSession.sendToolResponse({
          functionResponses: [
            {
              id: data.id,
              name: data.name,
              response: { output: data.result || "Action executed successfully." },
            },
          ],
        });
      }
    } catch (e) {
      console.error("[LiveWS] Error parsing client message:", e);
    }
  });

  clientWs.on("close", () => {
    console.log("[LiveWS] Client disconnected");
    isClosed = true;
    for (const timeout of pendingToolCalls.values()) {
      clearTimeout(timeout);
    }
    pendingToolCalls.clear();

    if (liveSession) {
      try {
        liveSession.close();
      } catch {
        // ignore
      }
    }
  });
});

// Vite middleware for development or Static files for production
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Mahi Assistant Server running on http://0.0.0.0:${PORT}`);
  });
}

setupViteOrStatic();
