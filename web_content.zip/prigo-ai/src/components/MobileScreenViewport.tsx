import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Smartphone,
  X,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Search,
  Play,
  Pause,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  ExternalLink,
  Sparkles,
  Tv,
  Compass,
  Music,
  Globe,
  Share2,
  ThumbsUp,
  Volume2,
  ScreenShare,
} from 'lucide-react';
import { ActiveApp, VideoItem } from '../types';
import { DEFAULT_VIDEOS } from '../lib/videoCatalog';

interface MobileScreenViewportProps {
  isOpen: boolean;
  activeApp: ActiveApp;
  searchQuery?: string;
  selectedVideo?: VideoItem | null;
  onClose: () => void;
  onSelectApp: (app: ActiveApp) => void;
  onSelectVideo: (video: VideoItem) => void;
  onBack: () => void;
  onSendImageFrame: (base64Jpeg: string) => void;
  lastScrollDirection?: 'down' | 'up' | null;
  isSessionActive: boolean;
  personaName: string;
}

export const MobileScreenViewport: React.FC<MobileScreenViewportProps> = ({
  isOpen,
  activeApp,
  searchQuery = '',
  selectedVideo,
  onClose,
  onSelectApp,
  onSelectVideo,
  onBack,
  onSendImageFrame,
  lastScrollDirection,
  isSessionActive,
  personaName,
}) => {
  const [isVisionEnabled, setIsVisionEnabled] = useState(true);
  const [isSharingDeviceScreen, setIsSharingDeviceScreen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isPlaying, setIsPlaying] = useState(true);
  const [scrollIndicator, setScrollIndicator] = useState<string | null>(null);

  const feedRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoStreamRef = useRef<HTMLVideoElement | null>(null);

  // Filter videos based on category and search query
  const filteredVideos = DEFAULT_VIDEOS.filter((v) => {
    const matchesCategory = selectedCategory === 'all' || v.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.channel.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Handle external voice scroll commands
  useEffect(() => {
    if (!lastScrollDirection || !feedRef.current) return;

    if (lastScrollDirection === 'down') {
      feedRef.current.scrollBy({ top: 380, behavior: 'smooth' });
      setScrollIndicator('Scrolling Down ↓');
    } else if (lastScrollDirection === 'up') {
      feedRef.current.scrollBy({ top: -380, behavior: 'smooth' });
      setScrollIndicator('Scrolling Up ↑');
    }

    const timer = setTimeout(() => setScrollIndicator(null), 1800);
    return () => clearTimeout(timer);
  }, [lastScrollDirection]);

  // Real-time Screen Vision Frame Capture to Gemini Live
  useEffect(() => {
    if (!isOpen || !isVisionEnabled || !isSessionActive) return;

    const interval = setInterval(() => {
      try {
        // If sharing device screen via mediaDevices
        if (isSharingDeviceScreen && videoStreamRef.current && canvasRef.current) {
          const video = videoStreamRef.current;
          const canvas = canvasRef.current;
          if (video.videoWidth && video.videoHeight) {
            canvas.width = 480;
            canvas.height = Math.round((480 * video.videoHeight) / video.videoWidth);
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
              const base64 = dataUrl.split(',')[1];
              if (base64) {
                onSendImageFrame(base64);
              }
            }
          }
          return;
        }

        // Simulated screen snapshot capture
        if (canvasRef.current && viewportRef.current) {
          const canvas = canvasRef.current;
          canvas.width = 360;
          canvas.height = 640;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            // Draw simulated phone frame for Gemini Live to perceive
            ctx.fillStyle = '#0f0f12';
            ctx.fillRect(0, 0, 360, 640);

            // Draw Header
            ctx.fillStyle = '#ff0033';
            ctx.fillRect(16, 20, 28, 20);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 16px sans-serif';
            ctx.fillText(activeApp.toUpperCase(), 52, 36);

            // Draw active state info
            ctx.fillStyle = '#aaaaaa';
            ctx.font = '12px sans-serif';
            ctx.fillText(`Category: ${selectedCategory}`, 16, 68);

            if (selectedVideo) {
              ctx.fillStyle = '#1e1e24';
              ctx.fillRect(16, 85, 328, 180);
              ctx.fillStyle = '#ffffff';
              ctx.font = 'bold 14px sans-serif';
              ctx.fillText(`PLAYING: ${selectedVideo.title.slice(0, 32)}...`, 16, 285);
              ctx.fillStyle = '#888888';
              ctx.font = '12px sans-serif';
              ctx.fillText(`${selectedVideo.channel} • ${selectedVideo.views}`, 16, 305);
            } else {
              // Draw top 3 visible items
              filteredVideos.slice(0, 4).forEach((item, idx) => {
                const y = 85 + idx * 130;
                ctx.fillStyle = '#1c1b22';
                ctx.fillRect(16, y, 328, 70);
                ctx.fillStyle = '#3b82f6';
                ctx.fillRect(20, y + 4, 30, 20);
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 12px sans-serif';
                ctx.fillText(`#${idx + 1}`, 26, y + 18);
                ctx.fillText(item.title.slice(0, 34), 60, y + 20);
                ctx.fillStyle = '#888888';
                ctx.font = '11px sans-serif';
                ctx.fillText(`${item.channel} • ${item.views}`, 60, y + 42);
              });
            }

            const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
            const base64 = dataUrl.split(',')[1];
            if (base64) {
              onSendImageFrame(base64);
            }
          }
        }
      } catch (e) {
        console.error('[VisionCapture] Error capturing screen frame:', e);
      }
    }, 1800);

    return () => clearInterval(interval);
  }, [isOpen, isVisionEnabled, isSessionActive, isSharingDeviceScreen, activeApp, selectedVideo, selectedCategory, filteredVideos, onSendImageFrame]);

  // Handle device screen share
  const handleToggleDeviceScreenShare = async () => {
    if (isSharingDeviceScreen) {
      if (videoStreamRef.current && videoStreamRef.current.srcObject) {
        const stream = videoStreamRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((t) => t.stop());
        videoStreamRef.current.srcObject = null;
      }
      setIsSharingDeviceScreen(false);
      return;
    }

    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        alert('Screen sharing is not supported in this browser environment.');
        return;
      }
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { max: 5 } },
        audio: false,
      });

      if (!videoStreamRef.current) {
        videoStreamRef.current = document.createElement('video');
        videoStreamRef.current.autoplay = true;
        videoStreamRef.current.muted = true;
        videoStreamRef.current.playsInline = true;
      }
      videoStreamRef.current.srcObject = stream;
      setIsSharingDeviceScreen(true);

      stream.getVideoTracks()[0].onended = () => {
        setIsSharingDeviceScreen(false);
      };
    } catch (err) {
      console.warn('Screen share canceled or denied:', err);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 30 }}
        className="fixed inset-x-3 sm:inset-x-auto sm:right-6 bottom-20 sm:bottom-24 z-40 w-auto sm:w-[410px] max-h-[82vh] h-[660px] rounded-3xl bg-zinc-950/95 border-2 border-white/20 shadow-2xl backdrop-blur-2xl flex flex-col overflow-hidden text-white font-sans"
        ref={viewportRef}
      >
        {/* Hidden Canvas for Vision Sampling */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Top Screen Status Bar & AI Vision Header */}
        <div className="px-4 py-2.5 bg-zinc-900/90 border-b border-white/10 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-bold tracking-wide flex items-center gap-1.5 text-white">
              <Smartphone className="w-3.5 h-3.5 text-blue-400" />
              <span>Mobile Screen</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Screen Vision Badge */}
            <button
              type="button"
              onClick={() => setIsVisionEnabled(!isVisionEnabled)}
              className={`px-2 py-0.5 rounded-full text-[10px] font-medium flex items-center gap-1 border transition-all ${
                isVisionEnabled
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-white/5 border-white/10 text-white/50'
              }`}
              title="Toggle AI Screen Vision"
            >
              {isVisionEnabled ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
              <span>{isVisionEnabled ? `${personaName} Seeing` : 'Vision Off'}</span>
            </button>

            {/* Real Screen Share Button */}
            <button
              type="button"
              onClick={handleToggleDeviceScreenShare}
              className={`p-1.5 rounded-lg border text-[10px] transition-all ${
                isSharingDeviceScreen
                  ? 'bg-blue-600 border-blue-400 text-white'
                  : 'bg-white/5 hover:bg-white/10 border-white/10 text-white/70'
              }`}
              title={isSharingDeviceScreen ? 'Stop Sharing Device Screen' : 'Share Real Phone / PC Screen'}
            >
              <ScreenShare className="w-3.5 h-3.5" />
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-white/10 text-white/70 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scroll Action Floating Indicator */}
        <AnimatePresence>
          {scrollIndicator && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-14 left-1/2 -translate-x-1/2 z-50 px-3 py-1 rounded-full bg-blue-600/90 border border-blue-400 text-white text-xs font-semibold shadow-lg backdrop-blur-md flex items-center gap-1.5 pointer-events-none"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{scrollIndicator}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* App Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden bg-[#0a0a0c]">
          {activeApp === 'youtube' ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* YouTube App Top Bar */}
              <div className="px-3.5 py-2.5 bg-[#0f0f12] border-b border-white/10 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-4 bg-[#ff0033] rounded flex items-center justify-center shadow-sm">
                    <Play className="w-2.5 h-2.5 fill-white text-white ml-0.5" />
                  </div>
                  <span className="font-bold text-sm tracking-tight text-white">YouTube</span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <input
                      type="text"
                      readOnly
                      value={searchQuery || ''}
                      placeholder="Say 'Open YouTube...' "
                      className="w-36 sm:w-44 px-2.5 py-1 text-xs rounded-full bg-white/10 border border-white/15 text-white placeholder-white/40 focus:outline-none"
                    />
                    <Search className="w-3 h-3 text-white/50 absolute right-2.5 top-2" />
                  </div>
                </div>
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1.5 px-3 py-2 overflow-x-auto no-scrollbar bg-[#0f0f12]/60 border-b border-white/5 shrink-0">
                {['all', 'tech', 'music', 'comedy', 'food'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium capitalize whitespace-nowrap transition-all ${
                      selectedCategory === cat
                        ? 'bg-white text-black font-semibold'
                        : 'bg-white/10 text-white/70 hover:bg-white/15'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Main Content Area: Playing Video or Video Feed */}
              <div ref={feedRef} className="flex-1 overflow-y-auto p-3 space-y-3 scroll-smooth">
                {selectedVideo ? (
                  /* Active Playing Video View */
                  <div className="space-y-3">
                    <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-white/20 shadow-2xl group">
                      {selectedVideo.videoId ? (
                        <iframe
                          className="w-full h-full"
                          src={`https://www.youtube.com/embed/${selectedVideo.videoId}?autoplay=1`}
                          title={selectedVideo.title}
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      ) : (
                        <div className="relative w-full h-full flex items-center justify-center">
                          <img
                            src={selectedVideo.thumbnailUrl}
                            alt={selectedVideo.title}
                            className="w-full h-full object-cover opacity-80"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                            <button
                              type="button"
                              onClick={() => setIsPlaying(!isPlaying)}
                              className="w-14 h-14 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow-2xl hover:scale-105 transition-transform"
                            >
                              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 fill-white ml-1" />}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Video Info Header */}
                    <div className="space-y-1.5 px-1">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-sm font-bold text-white leading-snug">
                          {selectedVideo.title}
                        </h3>
                        <button
                          type="button"
                          onClick={() => onBack()}
                          className="px-2 py-1 rounded-md bg-white/10 text-[10px] text-white/80 hover:text-white shrink-0"
                        >
                          Back to Feed
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-xs text-white/50 pt-1">
                        <span>{selectedVideo.channel}</span>
                        <span>{selectedVideo.views} • {selectedVideo.timeAgo}</span>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <span className="px-3 py-1 rounded-full bg-white/10 text-xs flex items-center gap-1.5 text-white/80">
                          <ThumbsUp className="w-3.5 h-3.5 text-rose-400" />
                          <span>Like</span>
                        </span>
                        <span className="px-3 py-1 rounded-full bg-white/10 text-xs flex items-center gap-1.5 text-white/80">
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Share</span>
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/10 text-xs font-semibold text-white/70">
                      Up Next:
                    </div>

                    {/* Up Next List */}
                    <div className="space-y-2">
                      {filteredVideos
                        .filter((v) => v.id !== selectedVideo.id)
                        .slice(0, 4)
                        .map((video, idx) => (
                          <div
                            key={video.id}
                            onClick={() => onSelectVideo(video)}
                            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 flex gap-2.5 cursor-pointer transition-all"
                          >
                            <div className="relative w-24 h-14 rounded-lg overflow-hidden shrink-0 bg-zinc-900">
                              <img
                                src={video.thumbnailUrl}
                                alt={video.title}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <span className="absolute bottom-1 right-1 text-[9px] bg-black/80 px-1 rounded text-white font-mono">
                                {video.duration}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-xs font-semibold text-white line-clamp-2 leading-tight">
                                {video.title}
                              </div>
                              <div className="text-[10px] text-white/50 mt-1">
                                {video.channel}
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                ) : (
                  /* Video Feed Cards */
                  filteredVideos.map((video, index) => (
                    <div
                      key={video.id}
                      id={`video-card-${index + 1}`}
                      onClick={() => onSelectVideo(video)}
                      className="group rounded-2xl bg-zinc-900/60 border border-white/10 hover:border-white/30 overflow-hidden cursor-pointer transition-all hover:shadow-xl active:scale-[0.98]"
                    >
                      {/* Thumbnail with duration stamp and index tag */}
                      <div className="relative aspect-video w-full bg-zinc-900 overflow-hidden">
                        <img
                          src={video.thumbnailUrl}
                          alt={video.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/80 border border-white/20 text-[11px] font-bold text-white shadow">
                          #{index + 1}
                        </div>
                        <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[10px] text-white font-mono font-medium">
                          {video.duration}
                        </span>
                      </div>

                      {/* Video Meta Info */}
                      <div className="p-3">
                        <h4 className="text-xs sm:text-sm font-semibold text-white group-hover:text-rose-300 transition-colors line-clamp-2 leading-snug">
                          {video.title}
                        </h4>
                        <div className="flex items-center justify-between text-[11px] text-white/50 mt-1.5">
                          <span className="font-medium text-white/70">{video.channel}</span>
                          <span>{video.views} • {video.timeAgo}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : activeApp === 'browser' ? (
            /* Browser App Mode */
            <div className="flex-1 flex flex-col p-4 text-center justify-center items-center">
              <Globe className="w-12 h-12 text-cyan-400 mb-3" />
              <h3 className="text-base font-bold text-white">Web Browser Active</h3>
              <p className="text-xs text-white/60 max-w-xs mt-1">
                Say &ldquo;Open YouTube&rdquo; or &ldquo;Search Google for latest news&rdquo; to browse content.
              </p>
              <button
                type="button"
                onClick={() => onSelectApp('youtube')}
                className="mt-4 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white shadow-lg transition-all"
              >
                Switch to YouTube
              </button>
            </div>
          ) : (
            /* General Home Screen / App Launcher */
            <div className="flex-1 flex flex-col p-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-white/50 mb-3">
                Apps on Device
              </div>
              <div className="grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => onSelectApp('youtube')}
                  className="p-3 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/10 flex flex-col items-center gap-2 transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#ff0033] flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-white" />
                  </div>
                  <span className="text-xs font-medium text-white">YouTube</span>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectApp('browser')}
                  className="p-3 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/10 flex flex-col items-center gap-2 transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-cyan-600 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                    <Globe className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-medium text-white">Browser</span>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectApp('music')}
                  className="p-3 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/10 flex flex-col items-center gap-2 transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                    <Music className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-medium text-white">Music</span>
                </button>
              </div>

              <div className="mt-6 p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white/70 space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Voice Controls Available:</span>
                </div>
                <p>&bull; &ldquo;Open YouTube&rdquo;</p>
                <p>&bull; &ldquo;Niche scroll karo&rdquo; (Scroll down)</p>
                <p>&bull; &ldquo;Upar scroll karo&rdquo; (Scroll up)</p>
                <p>&bull; &ldquo;Wah wala video lao&rdquo; / &ldquo;Play 2nd video&rdquo;</p>
                <p>&bull; &ldquo;Screen par kya dikh raha hai?&rdquo;</p>
              </div>
            </div>
          )}
        </div>

        {/* Mobile Bottom Navigation Bar (Back, Home, Scroll Controls) */}
        <div className="px-4 py-2.5 bg-zinc-900/95 border-t border-white/10 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onBack}
            className="p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-all flex items-center gap-1 text-xs"
            title="Back / Peeche jao"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden xs:inline">Back</span>
          </button>

          {/* Quick Voice Scroll Buttons */}
          <div className="flex items-center gap-1 bg-white/5 p-1 rounded-full border border-white/10">
            <button
              type="button"
              onClick={() => {
                feedRef.current?.scrollBy({ top: -380, behavior: 'smooth' });
                setScrollIndicator('Scrolling Up ↑');
                setTimeout(() => setScrollIndicator(null), 1200);
              }}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white"
              title="Scroll Up"
            >
              <ChevronUp className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] px-1 text-white/50 font-mono">SCROLL</span>
            <button
              type="button"
              onClick={() => {
                feedRef.current?.scrollBy({ top: 380, behavior: 'smooth' });
                setScrollIndicator('Scrolling Down ↓');
                setTimeout(() => setScrollIndicator(null), 1200);
              }}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white"
              title="Scroll Down"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            type="button"
            onClick={() => onSelectApp('none')}
            className="p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-all flex items-center gap-1 text-xs"
            title="Home"
          >
            <span>Home</span>
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
