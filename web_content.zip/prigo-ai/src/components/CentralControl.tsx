import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Power, Sparkles, Loader2, Square } from 'lucide-react';
import { AtmosphereConfig, PersonaConfig, SessionState } from '../types';

interface CentralControlProps {
  state: SessionState;
  currentPersona: PersonaConfig;
  theme: AtmosphereConfig;
  isMuted: boolean;
  onToggleConnect: () => void;
  onToggleMute: () => void;
  onInterrupt: () => void;
  micLevel: number;
  outputLevel: number;
}

export const CentralControl: React.FC<CentralControlProps> = ({
  state,
  currentPersona,
  theme,
  isMuted,
  onToggleConnect,
  onToggleMute,
  onInterrupt,
  micLevel,
  outputLevel,
}) => {
  const isConnected = state === 'listening' || state === 'speaking';
  const isConnecting = state === 'connecting';
  const isSpeaking = state === 'speaking';
  const isPrince = currentPersona.id === 'prince';

  const handleClick = () => {
    if (isSpeaking) {
      // Tap to interrupt while AI is speaking
      onInterrupt();
    } else if (state === 'disconnected' || state === 'error') {
      onToggleConnect();
    } else if (isConnected) {
      onInterrupt();
    }
  };

  return (
    <div className="relative z-20 flex flex-col items-center justify-center">
      {/* Central Interactive Orb Button */}
      <div className="relative flex items-center justify-center">
        {/* Animated Ripple Waves on Speech */}
        {isConnected && (
          <motion.div
            animate={{
              scale: isSpeaking ? [1, 1.35 + outputLevel * 0.4, 1] : [1, 1.18 + micLevel * 0.3, 1],
              opacity: [0.6, 0.1, 0.6],
            }}
            transition={{
              repeat: Infinity,
              duration: isSpeaking ? 1.2 : 2.0,
              ease: 'easeOut',
            }}
            className="absolute w-44 h-44 sm:w-56 sm:h-56 rounded-full border border-white/20 pointer-events-none"
            style={{
              borderColor: isPrince ? '#3b82f6' : theme.primaryColor,
              boxShadow: `0 0 35px ${isPrince ? 'rgba(59, 130, 246, 0.45)' : theme.glowColor}`,
            }}
          />
        )}

        {/* Outer Glowing Ring */}
        <div
          className={`relative p-2.5 sm:p-3 rounded-full transition-all duration-500 ${
            isConnected
              ? 'bg-gradient-to-b from-white/15 to-white/5 shadow-2xl backdrop-blur-md'
              : 'bg-white/5 border border-white/10 hover:border-white/20'
          }`}
          style={{
            boxShadow: isConnected
              ? `0 0 50px ${isPrince ? 'rgba(59, 130, 246, 0.4)' : theme.glowColor}, inset 0 0 20px ${
                  isPrince ? 'rgba(59, 130, 246, 0.3)' : theme.glowColor
                }`
              : 'none',
          }}
        >
          {/* Main Button */}
          <button
            id="central-voice-button"
            type="button"
            onClick={handleClick}
            disabled={isConnecting}
            className={`group relative w-28 h-28 sm:w-36 sm:h-36 rounded-full flex flex-col items-center justify-center transition-all duration-300 transform active:scale-95 focus:outline-none ${
              state === 'disconnected'
                ? 'bg-gradient-to-br from-zinc-800 via-zinc-900 to-black hover:from-zinc-750 border border-white/15 hover:border-white/30 text-white shadow-xl'
                : state === 'connecting'
                ? 'bg-zinc-900/90 border border-white/20 text-white/70 cursor-wait'
                : isSpeaking
                ? isPrince
                  ? 'bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white shadow-2xl hover:brightness-110'
                  : 'bg-gradient-to-tr from-rose-600 via-fuchsia-600 to-pink-500 text-white shadow-2xl hover:brightness-110'
                : 'bg-gradient-to-tr from-zinc-900 to-zinc-800 border-2 border-white/30 text-white'
            }`}
          >
            <AnimatePresence mode="wait">
              {state === 'disconnected' && (
                <motion.div
                  key="disconnected"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex flex-col items-center justify-center"
                >
                  <Power className="w-8 h-8 sm:w-10 sm:h-10 text-white/90 group-hover:text-white mb-1.5 transition-colors" />
                  <span className="text-[11px] sm:text-xs font-medium tracking-wider uppercase text-white/70">
                    Wake {currentPersona.name}
                  </span>
                </motion.div>
              )}

              {state === 'connecting' && (
                <motion.div
                  key="connecting"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex flex-col items-center justify-center"
                >
                  <Loader2 className={`w-8 h-8 sm:w-10 sm:h-10 animate-spin mb-1.5 ${isPrince ? 'text-blue-400' : 'text-rose-400'}`} />
                  <span className={`text-[10px] sm:text-xs font-medium tracking-wider uppercase ${isPrince ? 'text-blue-300' : 'text-rose-300'}`}>
                    Connecting
                  </span>
                </motion.div>
              )}

              {state === 'listening' && (
                <motion.div
                  key="listening"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex flex-col items-center justify-center"
                >
                  <div className="relative">
                    <Mic className="w-8 h-8 sm:w-10 sm:h-10 text-white mb-1" />
                    {micLevel > 0.05 && (
                      <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
                    )}
                  </div>
                  <span className="text-[10px] sm:text-xs font-semibold tracking-wider uppercase text-white/90">
                    Listening
                  </span>
                </motion.div>
              )}

              {state === 'speaking' && (
                <motion.div
                  key="speaking"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex flex-col items-center justify-center text-center px-1"
                >
                  {/* Waveform Sound Bars */}
                  <div className="flex items-center gap-1 mb-1.5 h-7">
                    {[0, 1, 2, 3, 4].map((i) => (
                      <motion.span
                        key={i}
                        animate={{
                          height: [6, 18 + outputLevel * 24, 8],
                        }}
                        transition={{
                          repeat: Infinity,
                          duration: 0.4 + i * 0.1,
                          ease: 'easeInOut',
                        }}
                        className="w-1 bg-white rounded-full"
                      />
                    ))}
                  </div>
                  <span className="text-[10px] sm:text-[11px] font-bold tracking-wider uppercase text-white drop-shadow">
                    {currentPersona.name} Speaking
                  </span>
                  <span className="text-[9px] text-white/80 mt-0.5">Tap to cut in</span>
                </motion.div>
              )}

              {state === 'error' && (
                <motion.div
                  key="error"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex flex-col items-center justify-center"
                >
                  <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-rose-400 mb-1" />
                  <span className="text-[10px] sm:text-xs font-medium tracking-wider uppercase text-rose-300">
                    Retry
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          </button>
        </div>
      </div>

      {/* Floating Control Badges (Mute, Cut in, Disconnect) */}
      <div className="mt-8 flex items-center gap-3">
        {isConnected ? (
          <>
            {/* Mute / Unmute Mic Button */}
            <button
              id="mute-mic-button"
              type="button"
              onClick={onToggleMute}
              className={`px-4 py-2 rounded-full text-xs font-medium flex items-center gap-2 border transition-all ${
                isMuted
                  ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
                  : 'bg-white/5 hover:bg-white/10 border-white/15 text-white/80'
              }`}
            >
              {isMuted ? <MicOff className="w-3.5 h-3.5 text-rose-400" /> : <Mic className="w-3.5 h-3.5 text-white/70" />}
              <span>{isMuted ? 'Mic Muted' : 'Mute Mic'}</span>
            </button>

            {/* Interrupt Response Button */}
            {isSpeaking && (
              <button
                id="interrupt-button"
                type="button"
                onClick={onInterrupt}
                className="px-4 py-2 rounded-full text-xs font-medium flex items-center gap-1.5 bg-amber-500/20 border border-amber-500/40 text-amber-200 hover:bg-amber-500/30 transition-all"
              >
                <Square className="w-3 h-3 fill-amber-300" />
                <span>Cut In</span>
              </button>
            )}

            {/* End Call / Power Off Button */}
            <button
              id="disconnect-call-button"
              type="button"
              onClick={onToggleConnect}
              className="px-4 py-2 rounded-full text-xs font-medium flex items-center gap-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 transition-all"
            >
              <Power className="w-3.5 h-3.5 text-red-400" />
              <span>End Call</span>
            </button>
          </>
        ) : (
          <div className="text-center">
            <p className="text-xs sm:text-sm text-white/60 max-w-xs font-light tracking-wide">
              {state === 'connecting'
                ? `Connecting with ${currentPersona.name}...`
                : `Tap the orb to start talking with ${currentPersona.name} in real time.`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
