import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PersonaConfig, PersonaType, SessionState } from '../types';
import { PERSONAS } from '../lib/personas';
import { Check, Sparkles, User, Heart, Mic } from 'lucide-react';

interface StealthPersonaDotProps {
  currentPersona: PersonaConfig;
  onSelectPersona: (persona: PersonaType) => void;
  sessionState: SessionState;
}

export const StealthPersonaDot: React.FC<StealthPersonaDotProps> = ({
  currentPersona,
  onSelectPersona,
  sessionState,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleSelect = (id: PersonaType) => {
    onSelectPersona(id);
    setIsOpen(false);
  };

  return (
    <div ref={containerRef} className="relative z-50 flex items-center justify-center">
      {/* 
        Stealth Black Dot (Bindu) on the right corner:
        Discreet, low visual footprint, black color, easy to tap when you know where it is.
      */}
      <button
        id="stealth-persona-dot"
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Persona switch"
        className="relative w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-[#050507] hover:bg-black border border-white/10 hover:border-white/30 transition-all cursor-pointer focus:outline-none active:scale-90"
        title="Mode"
      >
        <span className="block w-1.5 h-1.5 rounded-full bg-zinc-800/80 mx-auto" />
      </button>

      {/* Secret Persona Switcher Popup Modal / Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 8, transition: { duration: 0.15 } }}
            className="absolute right-0 top-7 w-72 sm:w-80 rounded-2xl bg-zinc-950/95 border border-white/15 p-4 shadow-2xl backdrop-blur-xl text-left"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-white/60" />
                <h4 className="text-xs font-semibold text-white tracking-wide uppercase">
                  Select AI Companion
                </h4>
              </div>
              <span className="text-[10px] text-white/40 font-mono">
                {currentPersona.name} Active
              </span>
            </div>

            <p className="text-[11px] text-white/60 my-2.5 leading-relaxed">
              Default mode is <strong>Prince</strong> (Man). Tap below to switch to <strong>Prigo</strong> (Girl) with full emotional female voice.
            </p>

            {/* Persona Options */}
            <div className="space-y-2 mt-1">
              {/* 1. Prince (Default Man) */}
              <button
                id="select-persona-prince"
                type="button"
                onClick={() => handleSelect('prince')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  currentPersona.id === 'prince'
                    ? 'bg-gradient-to-r from-blue-950/50 to-indigo-950/40 border-blue-500/50 shadow-lg'
                    : 'bg-white/5 hover:bg-white/10 border-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">Prince</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 border border-blue-400/20 font-mono">
                        Man Voice
                      </span>
                    </div>
                    <div className="text-[10px] text-white/50 mt-0.5">
                      Confident, witty & chill guy companion
                    </div>
                  </div>
                </div>
                {currentPersona.id === 'prince' && (
                  <Check className="w-4 h-4 text-blue-400 shrink-0" />
                )}
              </button>

              {/* 2. Prigo (Girl / Sassy Girlfriend) */}
              <button
                id="select-persona-prigo"
                type="button"
                onClick={() => handleSelect('prigo')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  currentPersona.id === 'prigo'
                    ? 'bg-gradient-to-r from-rose-950/50 to-fuchsia-950/40 border-rose-500/50 shadow-lg'
                    : 'bg-white/5 hover:bg-white/10 border-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-400/30 flex items-center justify-center text-rose-300">
                    <Heart className="w-4 h-4 fill-rose-400/30" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">Prigo</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-400/20 font-mono">
                        Girl Voice
                      </span>
                    </div>
                    <div className="text-[10px] text-white/50 mt-0.5">
                      Playful, sassy & charming girlfriend vibe
                    </div>
                  </div>
                </div>
                {currentPersona.id === 'prigo' && (
                  <Check className="w-4 h-4 text-rose-400 shrink-0" />
                )}
              </button>
            </div>

            {sessionState !== 'disconnected' && (
              <div className="mt-3 pt-2 border-t border-white/10 text-[10px] text-amber-300/80 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Switching will instantly update the live voice.</span>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
