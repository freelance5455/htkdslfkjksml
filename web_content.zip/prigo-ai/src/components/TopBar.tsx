import React, { useState } from 'react';
import { Palette, Info, X, Radio, Zap, Shield, User, Heart, Smartphone, Download } from 'lucide-react';
import { AtmosphereConfig, AtmosphereTheme, PersonaConfig, PersonaType, SessionState } from '../types';
import { ATMOSPHERES } from '../lib/themes';
import { StealthPersonaDot } from './StealthPersonaDot';

interface TopBarProps {
  state: SessionState;
  currentPersona: PersonaConfig;
  currentTheme: AtmosphereConfig;
  onSelectTheme: (theme: AtmosphereTheme) => void;
  onSelectPersona: (persona: PersonaType) => void;
  onToggleMobileScreen?: () => void;
  isMobileScreenOpen?: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  state,
  currentPersona,
  currentTheme,
  onSelectTheme,
  onSelectPersona,
  onToggleMobileScreen,
  isMobileScreenOpen,
}) => {
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);

  const isPrince = currentPersona.id === 'prince';

  const getStatusBadge = () => {
    switch (state) {
      case 'listening':
        return {
          label: `${currentPersona.name} Listening`,
          dotClass: 'bg-emerald-400 animate-pulse',
          borderClass: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
        };
      case 'speaking':
        return {
          label: `${currentPersona.name} Speaking`,
          dotClass: isPrince ? 'bg-blue-400 animate-ping' : 'bg-rose-400 animate-ping',
          borderClass: isPrince
            ? 'border-blue-500/40 bg-blue-500/15 text-blue-300'
            : 'border-rose-500/40 bg-rose-500/15 text-rose-300',
        };
      case 'connecting':
        return {
          label: 'Connecting...',
          dotClass: 'bg-amber-400 animate-spin',
          borderClass: 'border-amber-500/30 bg-amber-500/10 text-amber-300',
        };
      case 'error':
        return {
          label: 'Connection Error',
          dotClass: 'bg-red-400',
          borderClass: 'border-red-500/30 bg-red-500/10 text-red-300',
        };
      default:
        return {
          label: `${currentPersona.name} (Standby)`,
          dotClass: 'bg-zinc-500',
          borderClass: 'border-white/10 bg-white/5 text-zinc-400',
        };
    }
  };

  const badge = getStatusBadge();

  return (
    <header className="relative z-30 w-full px-3 sm:px-6 py-3 sm:py-4 flex items-center justify-between border-b border-white/5 backdrop-blur-md bg-black/20">
      {/* Brand & Persona Identifier */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        <div
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center font-bold text-xs sm:text-sm tracking-wider shadow-lg transition-all duration-500"
          style={{
            background: isPrince
              ? `linear-gradient(135deg, #3b82f6, #09090b)`
              : `linear-gradient(135deg, ${currentTheme.primaryColor}, #09090b)`,
            boxShadow: `0 0 15px ${isPrince ? 'rgba(59, 130, 246, 0.4)' : currentTheme.glowColor}`,
          }}
        >
          <span className="text-white font-mono font-bold">P</span>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm sm:text-base font-extrabold tracking-tight text-white flex items-center gap-1.5">
              <span>prigo</span>
              <span className="text-xs px-1.5 py-0.5 rounded bg-gradient-to-r from-blue-500 to-indigo-500 text-white font-mono font-semibold uppercase tracking-wider shadow-sm">
                ai
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-white/70 font-mono font-normal">
                {currentPersona.name}
              </span>
            </h1>
          </div>
          <p className="text-[10px] sm:text-[11px] text-white/50 hidden xs:block">
            {currentPersona.tagline}
          </p>
        </div>
      </div>

      {/* Center Live Status Indicator */}
      <div className="flex items-center gap-2">
        <div
          className={`px-2.5 sm:px-3 py-1 rounded-full text-[10px] sm:text-xs font-medium border flex items-center gap-1.5 sm:gap-2 transition-all ${badge.borderClass}`}
        >
          <span className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full ${badge.dotClass}`} />
          <span>{badge.label}</span>
        </div>
      </div>

      {/* Right Controls: Screen View, Theme, Info & Discreet Corner Dot */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Interactive Mobile Screen & YouTube Viewport Button */}
        {onToggleMobileScreen && (
          <button
            id="toggle-mobile-screen"
            type="button"
            onClick={onToggleMobileScreen}
            className={`p-1.5 sm:p-2 rounded-full border transition-all flex items-center gap-1.5 ${
              isMobileScreenOpen
                ? 'bg-blue-600/30 border-blue-400 text-blue-300 shadow-md shadow-blue-500/20'
                : 'bg-white/5 hover:bg-white/10 border-white/10 text-white/80 hover:text-white'
            }`}
            title="Mobile Screen & YouTube Control"
          >
            <Smartphone className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="text-[10px] hidden md:inline font-mono">Screen</span>
          </button>
        )}

        {/* Theme Picker */}
        <button
          id="open-theme-picker"
          type="button"
          onClick={() => setShowThemeModal(true)}
          className="p-1.5 sm:p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 hover:text-white transition-all"
          title="Change Atmosphere"
        >
          <Palette className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>

        {/* Info Modal */}
        <button
          id="open-persona-info"
          type="button"
          onClick={() => setShowInfoModal(true)}
          className="p-1.5 sm:p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 hover:text-white transition-all"
          title="About Prigo AI"
        >
          <Info className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>

        {/* Download App ZIP */}
        <a
          id="download-app-zip-btn"
          href="/api/download-zip"
          download="prigo-ai.zip"
          className="p-1.5 sm:p-2 rounded-full bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 hover:text-emerald-200 transition-all flex items-center gap-1"
          title="Download App Source (ZIP)"
        >
          <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="text-[10px] hidden sm:inline font-mono font-medium">ZIP</span>
        </a>

        {/* 
          Discreet Black Dot (Bindu) on the right corner:
          Low visibility black dot. Tapping opens girl (Prigo) / man (Prince) persona switch.
        */}
        <StealthPersonaDot
          currentPersona={currentPersona}
          onSelectPersona={onSelectPersona}
          sessionState={state}
        />
      </div>

      {/* Atmosphere Picker Modal */}
      {showThemeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-sm rounded-2xl border border-white/15 bg-zinc-900/95 p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">Atmospheric Vibe</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowThemeModal(false)}
                className="p-1 rounded-lg text-white/60 hover:text-white hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-white/60 my-3">
              Switch atmospheres manually or ask {currentPersona.name} in voice:
            </p>

            <div className="space-y-2 mt-2">
              {Object.values(ATMOSPHERES).map((theme) => {
                const isSelected = theme.id === currentTheme.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => {
                      onSelectTheme(theme.id);
                      setShowThemeModal(false);
                    }}
                    className={`w-full p-3 rounded-xl flex items-center justify-between border transition-all text-left ${
                      isSelected
                        ? 'bg-white/10 border-white/40 shadow-md'
                        : 'bg-white/5 hover:bg-white/10 border-white/5 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className="w-4 h-4 rounded-full shadow"
                        style={{ background: theme.primaryColor }}
                      />
                      <div>
                        <div className="text-xs font-semibold text-white">{theme.name}</div>
                        <div className="text-[10px] text-white/50">{theme.tagline}</div>
                      </div>
                    </div>
                    {isSelected && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 text-white font-mono">
                        Active
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Info & Persona Modal */}
      {showInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md rounded-2xl border border-white/15 bg-zinc-900/95 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-white">About Prigo AI</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowInfoModal(false)}
                className="p-1 rounded-lg text-white/60 hover:text-white hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs text-white/80 leading-relaxed">
              {/* Prince Persona Details */}
              <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-500/20">
                <div className="font-semibold text-blue-300 text-sm mb-1 flex items-center gap-1.5">
                  <User className="w-4 h-4" />
                  <span>Prince (Default Man Companion)</span>
                </div>
                <p className="text-white/70">
                  By default, Prigo AI launches with <strong>Prince</strong> — a confident, sharp, witty, and emotionally responsive male voice companion. Speaks like a loyal, smart, and cool guy best friend.
                </p>
              </div>

              {/* Prigo Persona Details */}
              <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-500/20">
                <div className="font-semibold text-rose-300 text-sm mb-1 flex items-center gap-1.5">
                  <Heart className="w-4 h-4" />
                  <span>Prigo (Girl Voice & Persona)</span>
                </div>
                <p className="text-white/70">
                  Tap the discreet black dot on the top-right corner to activate <strong>Prigo</strong> — an emotionally rich, playful, and sassy girlfriend persona with lively charm and wit.
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white flex items-center gap-1.5 text-xs">
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Audio-to-Audio Live Pipeline</span>
                </div>
                <p className="text-white/60">
                  Zero text chat delays. Raw 16kHz PCM audio flows directly from your microphone to Gemini Live, returning 24kHz studio-quality Web Audio in sub-second latency.
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-white flex items-center gap-1.5 text-xs">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Voice Browser Actions</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-white/70">
                  <li><em>&ldquo;Open YouTube for me&rdquo;</em></li>
                  <li><em>&ldquo;Search Google for latest tech news&rdquo;</em></li>
                  <li><em>&ldquo;Change atmosphere to electric violet&rdquo;</em></li>
                  <li><em>&ldquo;What is the current time?&rdquo;</em></li>
                </ul>
              </div>

              {/* Download App ZIP */}
              <div className="pt-2 border-t border-white/10">
                <a
                  href="/api/download-zip"
                  download="prigo-ai.zip"
                  className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium flex items-center justify-center gap-2 shadow-lg transition-all text-xs"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Complete App (prigo-ai.zip)</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
