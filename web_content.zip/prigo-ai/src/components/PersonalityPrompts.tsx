import React from 'react';
import { Sparkles } from 'lucide-react';
import { AtmosphereConfig, PersonaConfig, SessionState } from '../types';

interface PersonalityPromptsProps {
  state: SessionState;
  currentPersona: PersonaConfig;
  theme: AtmosphereConfig;
}

export const PersonalityPrompts: React.FC<PersonalityPromptsProps> = ({
  state,
  currentPersona,
  theme,
}) => {
  const isPrince = currentPersona.id === 'prince';

  return (
    <div className="relative z-20 w-full max-w-xl mx-auto px-4 mt-auto mb-6 text-center">
      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] text-white/60 mb-3">
        <Sparkles className={`w-3 h-3 ${isPrince ? 'text-blue-400' : 'text-rose-400'}`} />
        <span>Spoken Voice Call • Say anything out loud to {currentPersona.name}</span>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2">
        {currentPersona.prompts.map((prompt, idx) => (
          <div
            key={idx}
            className="px-3 py-1.5 rounded-full text-xs text-white/70 bg-white/5 hover:bg-white/10 border border-white/10 backdrop-blur-sm transition-all select-none"
          >
            &ldquo;{prompt}&rdquo;
          </div>
        ))}
      </div>
    </div>
  );
};
