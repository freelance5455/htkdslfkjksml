import React from 'react';
import { motion } from 'motion/react';
import { AtmosphereConfig, SessionState } from '../types';

interface AuraVisualizerProps {
  state: SessionState;
  theme: AtmosphereConfig;
  micLevel: number;
  outputLevel: number;
}

export const AuraVisualizer: React.FC<AuraVisualizerProps> = ({
  state,
  theme,
  micLevel,
  outputLevel,
}) => {
  // Compute dynamic scale & glow based on levels
  const activeLevel = state === 'speaking' ? outputLevel : state === 'listening' ? micLevel : 0;
  const pulseScale = 1 + activeLevel * 0.45;
  const glowOpacity = Math.min(1, 0.35 + activeLevel * 0.65);

  return (
    <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-hidden">
      {/* 1. Large Ambient Background Radial Field */}
      <motion.div
        animate={{
          scale: state === 'speaking' ? [1, 1.12, 1] : state === 'listening' ? [1, 1.05, 1] : 1,
          opacity: state === 'disconnected' ? 0.25 : glowOpacity,
        }}
        transition={{
          repeat: Infinity,
          duration: state === 'speaking' ? 2.2 : 3.5,
          ease: 'easeInOut',
        }}
        className="absolute w-[580px] h-[580px] sm:w-[750px] sm:h-[750px] rounded-full blur-[110px]"
        style={{
          background: `radial-gradient(circle, ${theme.primaryColor} 0%, rgba(15,12,25,0) 70%)`,
        }}
      />

      {/* 2. Secondary Floating Atmosphere Bloom */}
      <div
        className="absolute w-[360px] h-[360px] sm:w-[480px] sm:h-[480px] rounded-full blur-[70px] transition-all duration-700"
        style={{
          background: `radial-gradient(circle, ${theme.glowColor} 0%, transparent 65%)`,
          transform: `scale(${pulseScale})`,
          opacity: state === 'disconnected' ? 0.2 : 0.8,
        }}
      />

      {/* 3. Orbiting Holographic Rings for 'connecting' or 'speaking' */}
      <div className="relative flex items-center justify-center w-[320px] h-[320px] sm:w-[420px] sm:h-[420px]">
        {/* Outermost Thin Ring with Pulse */}
        <motion.div
          animate={{
            rotate: state === 'connecting' ? 360 : state === 'speaking' ? 180 : 0,
            scale: state === 'speaking' ? [1, 1.06, 0.98, 1] : 1,
          }}
          transition={{
            rotate: { repeat: Infinity, duration: state === 'connecting' ? 6 : 24, ease: 'linear' },
            scale: { repeat: Infinity, duration: 1.8, ease: 'easeInOut' },
          }}
          className={`absolute inset-0 rounded-full border border-dashed ${theme.ringColor} opacity-40`}
        />

        {/* Mid Concentric Wave Ring with audio-reactive border */}
        <div
          className="absolute inset-[15%] rounded-full border border-white/10 transition-all duration-100 ease-out"
          style={{
            transform: `scale(${1 + activeLevel * 0.28})`,
            borderColor: activeLevel > 0.1 ? theme.primaryColor : 'rgba(255, 255, 255, 0.1)',
            boxShadow: activeLevel > 0.1 ? `0 0 24px ${theme.glowColor}` : 'none',
          }}
        />

        {/* Audio Reactive Equalizer Petals when Mahi is speaking */}
        {state === 'speaking' && (
          <div className="absolute inset-0 flex items-center justify-center">
            {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
              <motion.div
                key={deg}
                animate={{
                  height: [20 + outputLevel * 40, 35 + outputLevel * 80, 20 + outputLevel * 30],
                  opacity: [0.4, 0.9, 0.4],
                }}
                transition={{
                  repeat: Infinity,
                  duration: 0.8 + (deg % 3) * 0.2,
                  ease: 'easeInOut',
                }}
                className="absolute w-1 rounded-full origin-bottom"
                style={{
                  transform: `rotate(${deg}deg) translateY(-145px)`,
                  background: `linear-gradient(to top, ${theme.primaryColor}, transparent)`,
                }}
              />
            ))}
          </div>
        )}

        {/* Audio Reactive Waveform Circles when User is speaking */}
        {state === 'listening' && activeLevel > 0.05 && (
          <div className="absolute inset-[25%] rounded-full border-2 border-dashed border-cyan-400/60 animate-ping opacity-30" />
        )}

        {/* Inner Luminous Core Halo */}
        <motion.div
          animate={{
            scale: state === 'disconnected' ? [0.95, 1.02, 0.95] : [1, 1.08 + activeLevel * 0.3, 1],
            opacity: state === 'disconnected' ? 0.3 : 0.7 + activeLevel * 0.3,
          }}
          transition={{
            repeat: Infinity,
            duration: state === 'disconnected' ? 4 : 1.4,
            ease: 'easeInOut',
          }}
          className="absolute inset-[30%] rounded-full"
          style={{
            background: `radial-gradient(circle, ${theme.primaryColor} 0%, transparent 80%)`,
            filter: 'blur(20px)',
          }}
        />
      </div>
    </div>
  );
};
