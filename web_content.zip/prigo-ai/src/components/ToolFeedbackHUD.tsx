import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Search, Palette, Clock, CheckCircle2, X } from 'lucide-react';
import { ToolAction } from '../types';

interface ToolFeedbackHUDProps {
  actions: ToolAction[];
  personaName?: string;
  onDismiss: (id: string) => void;
}

export const ToolFeedbackHUD: React.FC<ToolFeedbackHUDProps> = ({
  actions,
  personaName = 'AI',
  onDismiss,
}) => {
  if (actions.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-4 sm:right-6 z-40 flex flex-col gap-2 max-w-sm w-full pointer-events-auto">
      <AnimatePresence>
        {actions.slice(-3).map((action) => {
          const isWeb = action.name === 'openWebsite';
          const isSearch = action.name === 'searchWeb';
          const isTheme = action.name === 'changeAtmosphere';

          return (
            <motion.div
              key={action.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
              className="relative rounded-xl border border-white/20 bg-zinc-900/90 backdrop-blur-xl p-3.5 shadow-2xl overflow-hidden"
            >
              {/* Top Accent Line */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 via-fuchsia-500 to-cyan-400" />

              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-white/10 text-white">
                    {isWeb && <ExternalLink className="w-4 h-4 text-cyan-300" />}
                    {isSearch && <Search className="w-4 h-4 text-amber-300" />}
                    {isTheme && <Palette className="w-4 h-4 text-rose-300" />}
                    {!isWeb && !isSearch && !isTheme && <CheckCircle2 className="w-4 h-4 text-emerald-300" />}
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-white/70">
                      {personaName} Action Triggered
                    </div>
                    <div className="text-xs font-medium text-white/90 line-clamp-1">
                      {action.actionLabel || action.resultMessage || action.name}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onDismiss(action.id)}
                  className="p-1 text-white/40 hover:text-white rounded"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {action.actionUrl && (
                <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-white/10">
                  <span className="text-[10px] text-white/50">Popup blocked or need link?</span>
                  <a
                    href={action.actionUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors"
                  >
                    <span>Open Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
