export type SessionState = 'disconnected' | 'connecting' | 'listening' | 'speaking' | 'error';

export type PersonaType = 'prince' | 'prigo';

export interface PersonaConfig {
  id: PersonaType;
  name: string;
  roleTitle: string;
  gender: 'man' | 'woman';
  voiceName: string;
  tagline: string;
  defaultTheme: AtmosphereTheme;
  prompts: string[];
}

export type AtmosphereTheme = 
  | 'flirty_magenta' 
  | 'electric_violet' 
  | 'neon_cyan' 
  | 'cyber_amber' 
  | 'emerald_matrix';

export interface AtmosphereConfig {
  id: AtmosphereTheme;
  name: string;
  tagline: string;
  primaryColor: string; // Tailwind color class or hex
  glowColor: string;
  accentGradient: string;
  ringColor: string;
  cardBg: string;
}

export interface ToolAction {
  id: string;
  name: string;
  args: Record<string, any>;
  timestamp: number;
  status: 'executing' | 'completed' | 'failed';
  resultMessage?: string;
  actionUrl?: string;
  actionLabel?: string;
}

export type ActiveApp = 'none' | 'youtube' | 'browser' | 'music' | 'notes';

export interface VideoItem {
  id: string;
  title: string;
  channel: string;
  views: string;
  timeAgo: string;
  duration: string;
  thumbnailUrl: string;
  videoId?: string;
  category: string;
}

export interface AudioVisualizerData {
  micVolume: number; // 0 to 1
  outputVolume: number; // 0 to 1
  frequencies: Uint8Array;
}
