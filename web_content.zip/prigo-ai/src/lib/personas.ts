import { PersonaConfig, PersonaType } from '../types';

export const PERSONAS: Record<PersonaType, PersonaConfig> = {
  prince: {
    id: 'prince',
    name: 'Prince',
    roleTitle: 'Male AI Voice',
    gender: 'man',
    voiceName: 'Puck',
    tagline: 'Confident, sharp, witty & emotionally responsive guy companion',
    defaultTheme: 'electric_violet',
    prompts: [
      "Open YouTube for me bro",
      "Niche scroll karo (Scroll down)",
      "Wah wala video lao (Play 2nd video)",
      "Batao screen par kya dikh raha hai?",
      "Search the web for latest tech news",
      "Upar scroll karo",
    ],
  },
  prigo: {
    id: 'prigo',
    name: 'Prigo',
    roleTitle: 'Female AI Voice',
    gender: 'woman',
    voiceName: 'Aoede',
    tagline: 'Young, confident, witty & playfully sassy girlfriend persona',
    defaultTheme: 'flirty_magenta',
    prompts: [
      "Open YouTube for me babe",
      "Niche scroll karo",
      "Wah wala video lao na",
      "Screen par kya chal raha hai dekho",
      "Give me your sassiest witty comeback",
      "Change vibe to electric violet",
    ],
  },
};
