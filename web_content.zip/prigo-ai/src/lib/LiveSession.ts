import { AudioStreamer } from './AudioStreamer';
import { AtmosphereTheme, PersonaType, SessionState, ToolAction } from '../types';

export interface LiveSessionCallbacks {
  onStateChange: (state: SessionState) => void;
  onToolAction: (action: ToolAction) => void;
  onThemeChange?: (theme: AtmosphereTheme, reason?: string) => void;
  onError: (errorMessage: string) => void;
  onLevelsUpdate: (micLevel: number, outputLevel: number) => void;
  onOpenApp?: (appName: string, query?: string) => void;
  onScrollScreen?: (direction: 'down' | 'up' | 'top' | 'bottom', amount?: number) => void;
  onSelectVideo?: (index?: number, title?: string, videoId?: string) => void;
  onNavigateScreen?: (action: 'back' | 'home' | 'close') => void;
  onToggleScreenVision?: (enabled: boolean) => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private audioStreamer: AudioStreamer | null = null;
  private state: SessionState = 'disconnected';
  private callbacks: LiveSessionCallbacks;
  private isManuallyStopped: boolean = false;
  private currentPersona: PersonaType = 'prince';

  constructor(callbacks: LiveSessionCallbacks) {
    this.callbacks = callbacks;
  }

  getState(): SessionState {
    return this.state;
  }

  private setState(newState: SessionState) {
    if (this.state !== newState) {
      this.state = newState;
      this.callbacks.onStateChange(newState);
    }
  }

  async connect(persona: PersonaType = 'prince'): Promise<void> {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking') {
      return;
    }

    this.currentPersona = persona;
    this.isManuallyStopped = false;
    this.setState('connecting');

    try {
      // 1. Initialize AudioStreamer (mic capture & 24kHz playback)
      this.audioStreamer = new AudioStreamer({
        onAudioChunk: (base64) => {
          if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'audio', audio: base64 }));
          }
        },
        onSpeakingStateChange: (isSpeaking) => {
          if (this.state !== 'disconnected' && this.state !== 'connecting' && this.state !== 'error') {
            this.setState(isSpeaking ? 'speaking' : 'listening');
          }
        },
        onLevelsUpdate: (mic, out) => {
          this.callbacks.onLevelsUpdate(mic, out);
        },
      });

      await this.audioStreamer.start();

      // 2. Connect WebSocket to local Express /live bridge with persona parameter
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live?persona=${encodeURIComponent(persona)}`;
      console.log(`[LiveSession] Connecting to WebSocket at ${wsUrl} (Persona: ${persona})`);

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[LiveSession] WebSocket connection established');
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          // Ready confirmation from Gemini Live session
          if (msg.type === 'session_ready') {
            console.log('[LiveSession] Gemini Live session is ready! Model:', msg.model);
            this.setState('listening');
          }
          // Response audio chunk from Gemini
          else if (msg.type === 'audio' && msg.audio) {
            this.audioStreamer?.playChunk(msg.audio);
          }
          // User interrupted model while speaking
          else if (msg.type === 'interrupted') {
            console.log('[LiveSession] Model speech interrupted');
            this.audioStreamer?.interrupt();
            this.setState('listening');
          }
          // Turn complete
          else if (msg.type === 'turn_complete') {
            console.log('[LiveSession] Model turn complete');
          }
          // Tool Call execution
          else if (msg.type === 'tool_call') {
            this.handleToolCall(msg.id, msg.name, msg.args);
          }
          // Error notification
          else if (msg.type === 'error') {
            console.error('[LiveSession] Server error message:', msg.message);
            this.callbacks.onError(msg.message || 'An error occurred with Gemini Live session.');
            this.setState('error');
          }
          // Session closed
          else if (msg.type === 'session_closed') {
            if (!this.isManuallyStopped) {
              this.disconnect();
            }
          }
        } catch (e) {
          console.error('[LiveSession] Error handling WebSocket message:', e);
        }
      };

      this.ws.onerror = (e) => {
        console.error('[LiveSession] WebSocket error:', e);
        this.callbacks.onError('Connection error to voice server.');
        this.setState('error');
      };

      this.ws.onclose = () => {
        console.log('[LiveSession] WebSocket closed');
        if (!this.isManuallyStopped) {
          this.setState('disconnected');
        }
      };
    } catch (err: any) {
      console.error('[LiveSession] Start failed:', err);
      const isMicError = err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
      const msg = isMicError
        ? 'Microphone permission was denied. Please allow microphone access to chat with Mahi.'
        : err?.message || 'Could not start audio session.';
      this.callbacks.onError(msg);
      this.disconnect();
      this.setState('error');
    }
  }

  /**
   * Execute incoming Gemini tool calls in the browser and instantly send toolResponse back.
   */
  private handleToolCall(id: string, name: string, args: Record<string, any>) {
    console.log(`[LiveSession] Executing tool: ${name}`, args);

    let resultMsg = 'Action completed';
    let actionUrl: string | undefined;
    let actionLabel: string | undefined;

    try {
      if (name === 'openWebsite') {
        let targetUrl = (args.url || '').trim();
        if (targetUrl && !/^https?:\/\//i.test(targetUrl)) {
          targetUrl = `https://${targetUrl}`;
        }
        actionUrl = targetUrl;
        actionLabel = args.siteName || targetUrl;

        // Attempt opening in new tab
        const win = window.open(targetUrl, '_blank');
        if (!win || win.closed || typeof win.closed === 'undefined') {
          resultMsg = `Prepared link for ${targetUrl} (popup blocked by browser). User can click the prompt.`;
        } else {
          resultMsg = `Successfully opened ${targetUrl} in new tab.`;
        }
      } else if (name === 'searchWeb') {
        const query = (args.query || '').trim();
        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        actionUrl = searchUrl;
        actionLabel = `Search: "${query}"`;
        window.open(searchUrl, '_blank');
        resultMsg = `Executed Google search for "${query}".`;
      } else if (name === 'openApp') {
        const appName = (args.appName || 'youtube').toLowerCase();
        if (this.callbacks.onOpenApp) {
          this.callbacks.onOpenApp(appName, args.query);
        }
        resultMsg = `Opened ${appName} on user's mobile screen${args.query ? ` with search '${args.query}'` : ''}.`;
        actionLabel = `Open ${appName.toUpperCase()}`;
      } else if (name === 'scrollScreen') {
        const direction = (args.direction || 'down').toLowerCase() as 'down' | 'up' | 'top' | 'bottom';
        const amount = typeof args.amount === 'number' ? args.amount : 400;
        if (this.callbacks.onScrollScreen) {
          this.callbacks.onScrollScreen(direction, amount);
        }
        resultMsg = `Scrolled screen ${direction} smoothly.`;
        actionLabel = `Scroll ${direction.toUpperCase()}`;
      } else if (name === 'selectVideo') {
        if (this.callbacks.onSelectVideo) {
          this.callbacks.onSelectVideo(args.index, args.title, args.videoId);
        }
        resultMsg = `Opened video ${args.title || `number ${args.index || 1}`} for playback.`;
        actionLabel = `Play Video: ${args.title || `Item #${args.index || 1}`}`;
      } else if (name === 'navigateScreen') {
        const action = (args.action || 'home').toLowerCase() as 'back' | 'home' | 'close';
        if (this.callbacks.onNavigateScreen) {
          this.callbacks.onNavigateScreen(action);
        }
        resultMsg = `Navigated screen: ${action}.`;
        actionLabel = `Screen: ${action.toUpperCase()}`;
      } else if (name === 'toggleScreenVision') {
        const enabled = Boolean(args.enabled);
        if (this.callbacks.onToggleScreenVision) {
          this.callbacks.onToggleScreenVision(enabled);
        }
        resultMsg = `Live screen vision is now ${enabled ? 'active' : 'inactive'}.`;
        actionLabel = `Screen Vision: ${enabled ? 'ON' : 'OFF'}`;
      } else if (name === 'changeAtmosphere') {
        const theme = args.theme as AtmosphereTheme;
        if (this.callbacks.onThemeChange) {
          this.callbacks.onThemeChange(theme, args.reason);
        }
        resultMsg = `Atmosphere aesthetic updated to ${theme}.`;
      } else if (name === 'getSystemInfo') {
        const now = new Date();
        resultMsg = JSON.stringify({
          time: now.toLocaleTimeString(),
          date: now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        });
      }

      // Notify UI
      const toolAction: ToolAction = {
        id,
        name,
        args,
        timestamp: Date.now(),
        status: 'completed',
        resultMessage: resultMsg,
        actionUrl,
        actionLabel,
      };
      this.callbacks.onToolAction(toolAction);

      // Instantly send toolResponse back to Gemini Live
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'tool_response',
            id,
            name,
            result: resultMsg,
          })
        );
      }
    } catch (err: any) {
      console.error('[LiveSession] Error executing tool:', err);
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'tool_response',
            id,
            name,
            result: `Error executing action: ${err?.message || 'unknown error'}`,
          })
        );
      }
    }
  }

  /**
   * Interrupts current speaking response
   */
  interrupt(): void {
    this.audioStreamer?.interrupt();
    this.setState('listening');
  }

  /**
   * Toggles mute on microphone input
   */
  toggleMute(): boolean {
    if (!this.audioStreamer) return false;
    const current = this.audioStreamer.getMuted();
    this.audioStreamer.setMute(!current);
    return !current;
  }

  isMuted(): boolean {
    return this.audioStreamer ? this.audioStreamer.getMuted() : false;
  }

  /**
   * Sends real-time video/screen frame to Gemini Live
   */
  sendImageFrame(base64Jpeg: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'image',
          image: base64Jpeg,
        })
      );
    }
  }

  /**
   * Disconnects the session cleanly
   */
  disconnect(): void {
    this.isManuallyStopped = true;

    if (this.audioStreamer) {
      this.audioStreamer.stop();
      this.audioStreamer = null;
    }

    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }

    this.setState('disconnected');
  }
}
