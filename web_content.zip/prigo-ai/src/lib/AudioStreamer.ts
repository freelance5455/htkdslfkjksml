/**
 * AudioStreamer manages mic capture (PCM16 16kHz) and response playback (24kHz Web Audio API)
 * with gapless scheduling, interruption cancellation, and volume analysis for visualizers.
 */

export interface AudioStreamerCallbacks {
  onAudioChunk: (base64PCM: string) => void;
  onSpeakingStateChange: (isSpeaking: boolean) => void;
  onLevelsUpdate: (micLevel: number, outputLevel: number) => void;
}

export class AudioStreamer {
  private inputCtx: AudioContext | null = null;
  private outputCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private micSourceNode: MediaStreamAudioSourceNode | null = null;
  private micAnalyser: AnalyserNode | null = null;

  private outputGainNode: GainNode | null = null;
  private outputAnalyser: AnalyserNode | null = null;
  private nextStartTime: number = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();

  private isSpeaking: boolean = false;
  private isMuted: boolean = false;
  private animationFrameId: number | null = null;
  private callbacks: AudioStreamerCallbacks;

  constructor(callbacks: AudioStreamerCallbacks) {
    this.callbacks = callbacks;
  }

  /**
   * Initializes both input (16kHz) and output (24kHz) AudioContexts.
   * Prompts user for microphone permission.
   */
  async start(): Promise<void> {
    // 1. Setup Output AudioContext (24kHz for Gemini Live audio)
    const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
    this.outputCtx = new AudioCtxClass({ sampleRate: 24000 });
    if (this.outputCtx.state === 'suspended') {
      await this.outputCtx.resume();
    }

    this.outputGainNode = this.outputCtx.createGain();
    this.outputAnalyser = this.outputCtx.createAnalyser();
    this.outputAnalyser.fftSize = 256;
    this.outputAnalyser.smoothingTimeConstant = 0.8;

    this.outputGainNode.connect(this.outputAnalyser);
    this.outputAnalyser.connect(this.outputCtx.destination);
    this.nextStartTime = this.outputCtx.currentTime;

    // 2. Setup Input AudioContext (16kHz for Gemini Live mic input)
    try {
      this.inputCtx = new AudioCtxClass({ sampleRate: 16000 });
    } catch {
      this.inputCtx = new AudioCtxClass();
    }
    if (this.inputCtx.state === 'suspended') {
      await this.inputCtx.resume();
    }

    // 3. Request User Microphone
    this.micStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    this.micSourceNode = this.inputCtx.createMediaStreamSource(this.micStream);
    this.micAnalyser = this.inputCtx.createAnalyser();
    this.micAnalyser.fftSize = 256;
    this.micAnalyser.smoothingTimeConstant = 0.5;

    // ScriptProcessor for real-time PCM16 chunk extraction (bufferSize 2048 or 4096)
    const bufferSize = 2048;
    this.processorNode = this.inputCtx.createScriptProcessor(bufferSize, 1, 1);

    this.micSourceNode.connect(this.micAnalyser);
    this.micSourceNode.connect(this.processorNode);
    // Connect to destination to keep audio processing active (silenced by dummy node or 0-gain)
    const dummyGain = this.inputCtx.createGain();
    dummyGain.gain.value = 0;
    this.processorNode.connect(dummyGain);
    dummyGain.connect(this.inputCtx.destination);

    const inputActualSampleRate = this.inputCtx.sampleRate;

    this.processorNode.onaudioprocess = (e) => {
      if (this.isMuted) return;

      const inputChannelData = e.inputBuffer.getChannelData(0);

      // Resample to 16000Hz if the browser AudioContext runs at 44.1kHz or 48kHz
      let pcm16Data: Int16Array;
      if (inputActualSampleRate === 16000) {
        pcm16Data = this.floatTo16BitPCM(inputChannelData);
      } else {
        const resampled = this.resampleBuffer(inputChannelData, inputActualSampleRate, 16000);
        pcm16Data = this.floatTo16BitPCM(resampled);
      }

      if (pcm16Data.length > 0) {
        const base64 = this.int16ToBase64(pcm16Data);
        this.callbacks.onAudioChunk(base64);
      }
    };

    // Start volume / frequency visualization loop
    this.startLevelMonitor();
  }

  /**
   * Resamples float audio buffer from one sample rate to target sample rate via linear interpolation
   */
  private resampleBuffer(buffer: Float32Array, fromSampleRate: number, toSampleRate: number): Float32Array {
    if (fromSampleRate === toSampleRate) return buffer;
    const ratio = fromSampleRate / toSampleRate;
    const newLength = Math.round(buffer.length / ratio);
    const result = new Float32Array(newLength);
    for (let i = 0; i < newLength; i++) {
      const originIndex = i * ratio;
      const indexFloor = Math.floor(originIndex);
      const indexCeil = Math.min(buffer.length - 1, indexFloor + 1);
      const fraction = originIndex - indexFloor;
      result[i] = buffer[indexFloor] * (1 - fraction) + buffer[indexCeil] * fraction;
    }
    return result;
  }

  /**
   * Converts Float32 audio samples [-1.0, 1.0] to 16-bit linear PCM Int16Array
   */
  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  /**
   * Converts Int16Array to Base64
   */
  private int16ToBase64(int16Arr: Int16Array): string {
    const uint8Arr = new Uint8Array(int16Arr.buffer, int16Arr.byteOffset, int16Arr.byteLength);
    let binary = '';
    const chunk = 8192;
    for (let i = 0; i < uint8Arr.length; i += chunk) {
      const sub = uint8Arr.subarray(i, i + chunk);
      binary += String.fromCharCode.apply(null, sub as unknown as number[]);
    }
    return window.btoa(binary);
  }

  /**
   * Decodes base64 16-bit PCM little-endian audio at 24kHz and schedules gapless playback.
   */
  playChunk(base64PCM: string): void {
    if (!this.outputCtx || !this.outputGainNode) return;

    try {
      // Decode base64 to binary
      const binaryString = window.atob(base64PCM);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // 16-bit PCM -> Int16Array
      const int16Array = new Int16Array(bytes.buffer);
      const float32Array = new Float32Array(int16Array.length);

      // Normalize to [-1.0, 1.0]
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }

      // Create 24kHz AudioBuffer
      const audioBuffer = this.outputCtx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.copyToChannel(float32Array, 0);

      // Gapless scheduling
      const currentTime = this.outputCtx.currentTime;
      if (this.nextStartTime < currentTime) {
        // slight jitter lead-in
        this.nextStartTime = currentTime + 0.02;
      }

      const source = this.outputCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.outputGainNode);

      source.start(this.nextStartTime);
      this.nextStartTime += audioBuffer.duration;

      this.activeSources.add(source);
      this.setSpeaking(true);

      source.onended = () => {
        this.activeSources.delete(source);
        if (this.activeSources.size === 0) {
          // Check if scheduled time has passed
          if (this.outputCtx && this.outputCtx.currentTime >= this.nextStartTime - 0.05) {
            this.setSpeaking(false);
          }
        }
      };
    } catch (e) {
      console.error("[AudioStreamer] Error playing chunk:", e);
    }
  }

  /**
   * Immediately stops all currently playing and queued audio responses (Interruption).
   */
  interrupt(): void {
    for (const source of this.activeSources) {
      try {
        source.stop();
        source.disconnect();
      } catch {
        // ignore already stopped
      }
    }
    this.activeSources.clear();

    if (this.outputCtx) {
      this.nextStartTime = this.outputCtx.currentTime;
    }
    this.setSpeaking(false);
  }

  private setSpeaking(speaking: boolean): void {
    if (this.isSpeaking !== speaking) {
      this.isSpeaking = speaking;
      this.callbacks.onSpeakingStateChange(speaking);
    }
  }

  setMute(mute: boolean): void {
    this.isMuted = mute;
  }

  getMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Monitor mic and output RMS volume levels for responsive animations
   */
  private startLevelMonitor(): void {
    const micData = new Uint8Array(128);
    const outData = new Uint8Array(128);

    const check = () => {
      let micVol = 0;
      let outVol = 0;

      if (this.micAnalyser && !this.isMuted) {
        this.micAnalyser.getByteFrequencyData(micData);
        let sum = 0;
        for (let i = 0; i < micData.length; i++) {
          sum += micData[i];
        }
        micVol = Math.min(1, (sum / micData.length) / 100);
      }

      if (this.outputAnalyser && this.isSpeaking) {
        this.outputAnalyser.getByteFrequencyData(outData);
        let sum = 0;
        for (let i = 0; i < outData.length; i++) {
          sum += outData[i];
        }
        outVol = Math.min(1, (sum / outData.length) / 90);
      }

      this.callbacks.onLevelsUpdate(micVol, outVol);
      this.animationFrameId = requestAnimationFrame(check);
    };

    this.animationFrameId = requestAnimationFrame(check);
  }

  stop(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }

    this.interrupt();

    if (this.processorNode) {
      this.processorNode.disconnect();
      this.processorNode = null;
    }
    if (this.micSourceNode) {
      this.micSourceNode.disconnect();
      this.micSourceNode = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((t) => t.stop());
      this.micStream = null;
    }
    if (this.inputCtx) {
      this.inputCtx.close();
      this.inputCtx = null;
    }
    if (this.outputCtx) {
      this.outputCtx.close();
      this.outputCtx = null;
    }
  }
}
