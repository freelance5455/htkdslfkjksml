/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { LiveSession } from './lib/LiveSession';
import { ATMOSPHERES } from './lib/themes';
import { PERSONAS } from './lib/personas';
import { DEFAULT_VIDEOS } from './lib/videoCatalog';
import {
  ActiveApp,
  AtmosphereConfig,
  AtmosphereTheme,
  PersonaConfig,
  PersonaType,
  SessionState,
  ToolAction,
  VideoItem,
} from './types';
import { AuraVisualizer } from './components/AuraVisualizer';
import { CentralControl } from './components/CentralControl';
import { TopBar } from './components/TopBar';
import { ToolFeedbackHUD } from './components/ToolFeedbackHUD';
import { PersonalityPrompts } from './components/PersonalityPrompts';
import { MobileScreenViewport } from './components/MobileScreenViewport';
import { AlertCircle, X } from 'lucide-react';

export default function App() {
  const [sessionState, setSessionState] = useState<SessionState>('disconnected');
  // Default is Prince (Man) as requested by user
  const [currentPersona, setCurrentPersona] = useState<PersonaConfig>(PERSONAS.prince);
  const [currentTheme, setCurrentTheme] = useState<AtmosphereConfig>(ATMOSPHERES.electric_violet);
  const [micLevel, setMicLevel] = useState<number>(0);
  const [outputLevel, setOutputLevel] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [toolActions, setToolActions] = useState<ToolAction[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Mobile Screen Viewport & YouTube control states
  const [isMobileScreenOpen, setIsMobileScreenOpen] = useState<boolean>(false);
  const [activeApp, setActiveApp] = useState<ActiveApp>('youtube');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);
  const [lastScrollDirection, setLastScrollDirection] = useState<'down' | 'up' | null>(null);

  const sessionRef = useRef<LiveSession | null>(null);

  // Initialize LiveSession instance with full voice-to-screen controls
  useEffect(() => {
    const session = new LiveSession({
      onStateChange: (newState) => {
        console.log('[App] Session state changed:', newState);
        setSessionState(newState);
        if (newState === 'listening' || newState === 'speaking') {
          setErrorMessage(null);
        }
      },
      onToolAction: (action) => {
        setToolActions((prev) => [...prev, action]);
      },
      onThemeChange: (themeId) => {
        if (ATMOSPHERES[themeId]) {
          setCurrentTheme(ATMOSPHERES[themeId]);
        }
      },
      onError: (msg) => {
        setErrorMessage(msg);
      },
      onLevelsUpdate: (mic, out) => {
        setMicLevel(mic);
        setOutputLevel(out);
      },
      // Voice Tool: "Open YouTube", "Open app..."
      onOpenApp: (appName, query) => {
        setIsMobileScreenOpen(true);
        if (appName.includes('youtube') || appName.includes('video')) {
          setActiveApp('youtube');
          if (query) setSearchQuery(query);
          setSelectedVideo(null);
        } else if (appName.includes('browser') || appName.includes('google')) {
          setActiveApp('browser');
        } else if (appName.includes('music')) {
          setActiveApp('music');
        } else {
          setActiveApp('youtube');
          if (query) setSearchQuery(query);
        }
      },
      // Voice Tool: "Niche scroll karo", "Scroll down", "Upar scroll karo"
      onScrollScreen: (direction) => {
        setIsMobileScreenOpen(true);
        setLastScrollDirection(direction === 'up' ? 'up' : 'down');
        // Reset scroll direction trigger
        setTimeout(() => setLastScrollDirection(null), 1000);
      },
      // Voice Tool: "Wah wala video lao", "Play 2nd video"
      onSelectVideo: (index, title, videoId) => {
        setIsMobileScreenOpen(true);
        setActiveApp('youtube');

        let target: VideoItem | undefined;
        if (typeof index === 'number' && index >= 1 && index <= DEFAULT_VIDEOS.length) {
          target = DEFAULT_VIDEOS[index - 1];
        } else if (videoId) {
          target = DEFAULT_VIDEOS.find((v) => v.videoId === videoId);
        } else if (title) {
          const lower = title.toLowerCase();
          target = DEFAULT_VIDEOS.find(
            (v) => v.title.toLowerCase().includes(lower) || v.channel.toLowerCase().includes(lower)
          );
        }

        // Fallback to first video or second video
        if (!target) {
          target = DEFAULT_VIDEOS[1] || DEFAULT_VIDEOS[0];
        }

        setSelectedVideo(target);
      },
      // Voice Tool: "Peeche jao", "Close app", "Home screen"
      onNavigateScreen: (action) => {
        if (action === 'close') {
          setIsMobileScreenOpen(false);
        } else if (action === 'home') {
          setActiveApp('none');
          setSelectedVideo(null);
        } else if (action === 'back') {
          if (selectedVideo) {
            setSelectedVideo(null);
          } else {
            setActiveApp('none');
          }
        }
      },
      // Voice Tool: Screen Vision toggle
      onToggleScreenVision: (enabled) => {
        if (enabled) {
          setIsMobileScreenOpen(true);
        }
      },
    });

    sessionRef.current = session;

    return () => {
      session.disconnect();
    };
  }, []);

  const handleToggleConnect = useCallback(() => {
    if (!sessionRef.current) return;

    if (sessionState === 'disconnected' || sessionState === 'error') {
      setErrorMessage(null);
      sessionRef.current.connect(currentPersona.id);
    } else {
      sessionRef.current.disconnect();
    }
  }, [sessionState, currentPersona.id]);

  const handleSelectPersona = useCallback((personaId: PersonaType) => {
    if (personaId === currentPersona.id) return;

    const newPersona = PERSONAS[personaId];
    setCurrentPersona(newPersona);
    setCurrentTheme(ATMOSPHERES[newPersona.defaultTheme]);

    // If currently active in a call, seamlessly reconnect with new persona voice
    if (sessionRef.current) {
      const currentState = sessionRef.current.getState();
      if (currentState === 'listening' || currentState === 'speaking' || currentState === 'connecting') {
        sessionRef.current.disconnect();
        setTimeout(() => {
          sessionRef.current?.connect(personaId);
        }, 150);
      }
    }
  }, [currentPersona.id]);

  const handleToggleMute = useCallback(() => {
    if (!sessionRef.current) return;
    const muted = sessionRef.current.toggleMute();
    setIsMuted(muted);
  }, []);

  const handleInterrupt = useCallback(() => {
    if (!sessionRef.current) return;
    sessionRef.current.interrupt();
  }, []);

  const handleSelectTheme = useCallback((themeId: AtmosphereTheme) => {
    if (ATMOSPHERES[themeId]) {
      setCurrentTheme(ATMOSPHERES[themeId]);
    }
  }, []);

  const handleDismissToolAction = useCallback((id: string) => {
    setToolActions((prev) => prev.filter((a) => a.id !== id));
  }, []);

  // Frame sender for Gemini Live real-time multimodal vision
  const handleSendImageFrame = useCallback((base64Jpeg: string) => {
    sessionRef.current?.sendImageFrame(base64Jpeg);
  }, []);

  return (
    <div
      className="relative w-screen h-screen min-h-[100dvh] flex flex-col justify-between overflow-hidden bg-[#07050d] text-white font-sans select-none"
      style={{
        backgroundImage: `radial-gradient(ellipse at 50% 40%, rgba(18, 14, 32, 0.95) 0%, #050408 100%)`,
      }}
    >
      {/* Background Subtle Cyber Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.035]"
        style={{
          backgroundImage: `linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)`,
          backgroundSize: '48px 48px',
        }}
      />

      {/* Top Header Bar with Prigo AI branding, mobile screen button & discreet right-corner Bindu dot */}
      <TopBar
        state={sessionState}
        currentPersona={currentPersona}
        currentTheme={currentTheme}
        onSelectTheme={handleSelectTheme}
        onSelectPersona={handleSelectPersona}
        onToggleMobileScreen={() => setIsMobileScreenOpen(!isMobileScreenOpen)}
        isMobileScreenOpen={isMobileScreenOpen}
      />

      {/* Error Alert Banner */}
      {errorMessage && (
        <div className="relative z-40 px-4 pt-2">
          <div className="max-w-md mx-auto p-3 rounded-xl bg-red-950/80 border border-red-500/50 backdrop-blur-md flex items-center justify-between text-xs text-red-200 shadow-xl">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="p-1 text-red-400 hover:text-white rounded"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Centerpiece Visualizer & Voice Orb Control */}
      <main className="relative flex-1 flex flex-col items-center justify-center px-4 w-full">
        {/* Fullscreen Fluid Aura Visualizer */}
        <AuraVisualizer
          state={sessionState}
          theme={currentTheme}
          micLevel={micLevel}
          outputLevel={outputLevel}
        />

        {/* Central Orb Mic/Power Control Button */}
        <CentralControl
          state={sessionState}
          currentPersona={currentPersona}
          theme={currentTheme}
          isMuted={isMuted}
          onToggleConnect={handleToggleConnect}
          onToggleMute={handleToggleMute}
          onInterrupt={handleInterrupt}
          micLevel={micLevel}
          outputLevel={outputLevel}
        />
      </main>

      {/* Bottom Personality Prompts (Prince / Prigo) */}
      <PersonalityPrompts
        state={sessionState}
        currentPersona={currentPersona}
        theme={currentTheme}
      />

      {/* Interactive Mobile Screen & YouTube Viewport with Realtime Screen Vision */}
      <MobileScreenViewport
        isOpen={isMobileScreenOpen}
        activeApp={activeApp}
        searchQuery={searchQuery}
        selectedVideo={selectedVideo}
        onClose={() => setIsMobileScreenOpen(false)}
        onSelectApp={(app) => {
          setActiveApp(app);
          setSelectedVideo(null);
        }}
        onSelectVideo={(video) => setSelectedVideo(video)}
        onBack={() => {
          if (selectedVideo) {
            setSelectedVideo(null);
          } else {
            setActiveApp('none');
          }
        }}
        onSendImageFrame={handleSendImageFrame}
        lastScrollDirection={lastScrollDirection}
        isSessionActive={sessionState === 'listening' || sessionState === 'speaking'}
        personaName={currentPersona.name}
      />

      {/* Floating Real-Time Tool Action HUD */}
      <ToolFeedbackHUD
        actions={toolActions}
        personaName={currentPersona.name}
        onDismiss={handleDismissToolAction}
      />
    </div>
  );
}
