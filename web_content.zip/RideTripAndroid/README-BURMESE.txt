Ride Trip Thailand — Android WebView Project

ဒီ ZIP က Android Studio / AndroidIDE နဲ့ APK build လုပ်နိုင်ရန် project source ဖြစ်ပြီး APK ဖိုင်ကိုယ်တိုင် မဟုတ်ပါ။

ဖုန်းနဲ့ ဆက်လုပ်ရန် (AndroidIDE ရရှိနိုင်ပါက):
1. ZIP ကို Extract လုပ်ပါ။
2. AndroidIDE ထဲက Open Project နဲ့ RideTripAndroid folder ကိုဖွင့်ပါ။
3. Gradle sync ပြီးအောင်စောင့်ပါ (အင်တာနက်လိုနိုင်သည်)။
4. Build > Assemble Debug APK ကိုရွေးပါ။
5. APK ထွက်လာပါက app/build/outputs/apk/debug/app-debug.apk ထဲမှာ ရှိပါမယ်။

သတိပြုရန်:
- Google Maps/Social links ကို external browser/app ထဲဖွင့်ရန် စီစဉ်ထားသည်။
- GPS permission prompt ကို ထည့်ထားသည်။
- JSON import file picker ကို ထည့်ထားသည်။
- WebView ထဲက Blob URL download ကို Android WebView က အလိုအလျောက် download မလုပ်နိုင်နိုင်သဖြင့် Backup Export ကို APK ထဲတွင် သီးခြားစမ်းသပ်ရန်လိုသည်။
- ဒီ project ကို ဒီနေရာမှာ Android SDK နဲ့ compile မလုပ်ထားသေးပါ။ APK အဖြစ် build အောင်မြင်ကြောင်း မအာမခံပါ။
