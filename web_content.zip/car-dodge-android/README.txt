CAR DODGE - ANDROID PROJECT
===========================
A tiny native Android app (one Activity + one WebView) that runs the game from
app/src/main/assets/www. Package: com.cardodge.game  |  Output: app-debug.apk

OPTION A - build the APK in the cloud (no PC needed)
 1. Make a free GitHub account, create a new repository.
 2. Upload everything from this folder (keep the .github/workflows/build-apk.yml path).
 3. Open the repo's "Actions" tab -> "Build APK" -> wait ~3-5 minutes.
 4. Open the finished run -> Artifacts -> car-dodge-apk -> download, unzip, install app-debug.apk.
    (Allow "install unknown apps" for your browser/files app when Android asks.)

OPTION B - Android Studio (PC)
 File > Open > pick this folder > Build > Build APK(s).
 APK lands in app/build/outputs/apk/debug/.

Editing the game: change files inside app/src/main/assets/www, then rebuild.
Google Play needs a signed release build (Build > Generate Signed Bundle/APK).
