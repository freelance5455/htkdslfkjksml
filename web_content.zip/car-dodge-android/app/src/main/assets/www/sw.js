// Offline cache so the game also works without internet once installed.
// Change CACHE (v1 -> v2) whenever you edit the game so players get the update.
const CACHE = 'car-dodge-v1';
const FILES = ['./', 'index.html', 'style.css', 'game.js', 'manifest.webmanifest', 'assets/icon-192.png', 'assets/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => { e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))); });
