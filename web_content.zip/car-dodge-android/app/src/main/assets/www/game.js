'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = a => a[(Math.random() * a.length) | 0];

/* ================= DATA ================= */
const TIER = {
  1: { name: 'TIER 1 · BEST',  color: '#ffcf4a' },
  2: { name: 'TIER 2 · GREAT', color: '#b57cff' },
  3: { name: 'TIER 3 · GOOD',  color: '#4aa3ff' },
  4: { name: 'TIER 4 · BAD',   color: '#8a9099' }
};
// grip = steering, nitro = boost multiplier, coin = wallet multiplier
const CARS = [
  { id: 'hatch',   name: 'City Hatch',            tier: 4, price: 0,     body: 'hatch', color: '#8c9199', grip: .16, nitro: 1.30, coin: 1.0 },
  { id: 'oldsed',  name: 'Old Sedan',             tier: 4, price: 80,    body: 'sedan', color: '#7a6a55', grip: .17, nitro: 1.30, coin: 1.0 },
  { id: 'retro',   name: 'Retro Hatch',           tier: 4, price: 150,   body: 'hatch', color: '#b08d57', grip: .18, nitro: 1.32, coin: 1.0 },
  { id: 'mustang', name: 'Mustang GT',            tier: 3, price: 300,   body: 'sport', color: '#7b1e2d', accent: '#e8e8ea', grip: .20, nitro: 1.38, coin: 1.1 },
  { id: 'm3',      name: 'BMW M3',                tier: 3, price: 500,   body: 'sedan', color: '#1f4e79', grip: .21, nitro: 1.40, coin: 1.15 },
  { id: 'wrx',     name: 'Subaru WRX',            tier: 3, price: 700,   body: 'sedan', color: '#1d3a8a', accent: '#f2b705', grip: .22, nitro: 1.42, coin: 1.2 },
  { id: 'gt3',     name: 'Porsche 911 GT3',       tier: 2, price: 1200,  body: 'sport', color: '#c8102e', accent: '#0b0c0e', grip: .25, nitro: 1.52, coin: 1.3 },
  { id: 'gtr',     name: 'Nissan GT-R',           tier: 2, price: 2000,  body: 'sport', color: '#c9ccd2', accent: '#1a1d23', grip: .26, nitro: 1.56, coin: 1.4 },
  { id: '720s',    name: 'McLaren 720S',          tier: 2, price: 3200,  body: 'super', color: '#e8651a', grip: .27, nitro: 1.60, coin: 1.5 },
  { id: 'lambo',   name: 'Lamborghini Aventador', tier: 1, price: 5000,  body: 'super', color: '#e8b400', grip: .30, nitro: 1.70, coin: 1.7 },
  { id: 'pagani',  name: 'Pagani Huayra',         tier: 1, price: 8000,  body: 'hyper', color: '#2b2f36', accent: '#d4af37', grip: .32, nitro: 1.76, coin: 1.85 },
  { id: 'bugatti', name: 'Bugatti Chiron',        tier: 1, price: 12000, body: 'hyper', color: '#17348a', accent: '#0b0c0e', grip: .34, nitro: 1.85, coin: 2.0 }
];
const BODY = {   // nose pinch + cabin range (fraction of car height)
  hatch: { nose: .85, cab: [-.26, .30] }, sedan: { nose: .62, cab: [-.20, .34] }, suv: { nose: .62, cab: [-.22, .40] },
  sport: { nose: .50, cab: [-.12, .28] }, super: { nose: .30, cab: [0, .36] },     hyper: { nose: .42, cab: [-.04, .34] }
};
const TRAFFIC = [   // [weight, body, width, height]
  [.45, 'sedan', 1, 1.95], [.25, 'suv', 1.06, 2.0], [.15, 'sport', 1, 1.85], [.15, 'truck', 1.1, 3.1]
];
const PAINT = ['#1a1d23', '#d7dae0', '#7b1e2d', '#34505f', '#8c9199', '#2f4638', '#b08d57', '#4a4d55'];
const CARGO = ['#d8dbe0', '#b9bfc7', '#9aa3ad'];
const LANE_SPEED = [2.4, 3.2, 2.8];

/* ================= SAVE ================= */
const Store = {
  data: { wallet: 0, owned: ['hatch'], sel: 'hatch' }, best: 0,
  load() {
    try { Object.assign(this.data, JSON.parse(localStorage.getItem('cd_save') || '{}')); this.best = +localStorage.getItem('cd_best') || 0; } catch (e) {}
  },
  save() {
    try { localStorage.setItem('cd_save', JSON.stringify(this.data)); localStorage.setItem('cd_best', this.best); } catch (e) {}
  },
  get car() { return CARS.find(c => c.id === this.data.sel) || CARS[0]; }
};
Store.load();

/* ================= LAYOUT + CANVAS ================= */
const cv = $('#game'), ctx = cv.getContext('2d', { alpha: false });
const L = { w: 0, h: 0, dpr: 1, rx: 0, rw: 0, lane: 0 };
const A = { cars: {}, trees: {} };   // baked assets

function mk(w, h, d = L.dpr) {
  const c = document.createElement('canvas');
  c.width = Math.ceil(w * d); c.height = Math.ceil(h * d);
  const g = c.getContext('2d'); g.scale(d, d);
  return [c, g];
}
function rrPath(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function shade(hex, f) {
  const n = parseInt(hex.slice(1), 16), t = f < 0 ? 0 : 255, p = Math.abs(f);
  const ch = s => Math.round(((n >> s) & 255) * (1 - p) + t * p);
  return `rgb(${ch(16)},${ch(8)},${ch(0)})`;
}
function glow(size, rgb, a) {
  const [c, g] = mk(size, size, 1);
  const q = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  q.addColorStop(0, `rgba(${rgb},${a})`); q.addColorStop(1, `rgba(${rgb},0)`);
  g.fillStyle = q; g.fillRect(0, 0, size, size);
  return c;
}

/* ================= CAR PAINTER (origin = car centre, nose up) ================= */
function bodyPath(g, w, h, n) {
  const a = w / 2, b = h / 2;
  g.beginPath(); g.moveTo(0, -b);
  g.bezierCurveTo(a * n, -b, a, -b * .82, a, -b * .55); g.lineTo(a, b * .62);
  g.bezierCurveTo(a, b * .9, a * .7, b, a * .4, b); g.lineTo(-a * .4, b);
  g.bezierCurveTo(-a * .7, b, -a, b * .9, -a, b * .62); g.lineTo(-a, -b * .55);
  g.bezierCurveTo(-a, -b * .82, -a * n, -b, 0, -b); g.closePath();
}
function hGrad(g, a, stops) {
  const q = g.createLinearGradient(-a, 0, a, 0);
  stops.forEach(([o, c]) => q.addColorStop(o, c));
  return q;
}
function stripes(g, v, w, y, len) {
  if (!v.accent) return;
  g.fillStyle = v.accent;
  if (v.body === 'hyper') g.fillRect(-w * .07, y, w * .14, len);
  else { g.fillRect(-w * .15, y, w * .1, len); g.fillRect(w * .05, y, w * .1, len); }
}
function paintTruck(g, v, w, h) {
  const a = w / 2, b = h / 2, cabH = h * .25, top = -b + h * .27;
  g.fillStyle = '#08090b';
  for (const y of [-.74, .45, .72]) for (const s of [-1, 1]) { rrPath(g, s * a * .98 - w * .085, y * b - h * .045, w * .17, h * .09, 3); g.fill(); }
  rrPath(g, -a, top, w, b - top, 5);
  g.fillStyle = hGrad(g, a, [[0, shade(v.cargo, -.4)], [.5, shade(v.cargo, .12)], [1, shade(v.cargo, -.45)]]); g.fill();
  g.strokeStyle = 'rgba(0,0,0,.14)'; g.lineWidth = 1;
  for (let y = top + h * .07; y < b - 4; y += h * .07) { g.beginPath(); g.moveTo(-a + 3, y); g.lineTo(a - 3, y); g.stroke(); }
  rrPath(g, -a, top, w, b - top, 5); g.strokeStyle = 'rgba(0,0,0,.5)'; g.stroke();
  rrPath(g, -a * .88, -b, w * .88, cabH, 8);
  g.fillStyle = hGrad(g, a, [[0, shade(v.color, -.45)], [.5, shade(v.color, .28)], [1, shade(v.color, -.5)]]); g.fill(); g.stroke();
  rrPath(g, -a * .7, -b + cabH * .4, w * .7, cabH * .35, 3); g.fillStyle = '#0d141b'; g.fill();
  g.fillStyle = '#fff3d0';
  for (const s of [-1, 1]) { rrPath(g, s * a * .55 - a * .14, -b + 1, a * .28, 3.5, 1.5); g.fill(); }
  g.fillStyle = '#c1121f';
  for (const s of [-1, 1]) { rrPath(g, s * a * .65 - a * .15, b - 5, a * .3, 4, 1.5); g.fill(); }
}
function paintVehicle(g, v, w, h) {
  const a = w / 2, b = h / 2;
  g.save();
  g.fillStyle = 'rgba(0,0,0,.42)'; g.beginPath(); g.ellipse(w * .05, h * .03, a * 1.12, b * 1.05, 0, 0, TAU); g.fill();
  if (v.body === 'truck') { paintTruck(g, v, w, h); g.restore(); return; }
  const B = BODY[v.body], c = v.color;

  g.fillStyle = '#08090b';
  for (const y of [-.58, .56]) for (const s of [-1, 1]) { rrPath(g, s * a * .97 - w * .09, y * b - h * .1, w * .18, h * .2, 3); g.fill(); }

  bodyPath(g, w, h, B.nose);
  g.fillStyle = hGrad(g, a, [[0, shade(c, -.45)], [.3, shade(c, .05)], [.5, shade(c, .3)], [.7, shade(c, .02)], [1, shade(c, -.5)]]); g.fill();
  g.save(); bodyPath(g, w, h, B.nose); g.clip();
  const vg = g.createLinearGradient(0, -b, 0, b);
  vg.addColorStop(0, 'rgba(255,255,255,.14)'); vg.addColorStop(.5, 'rgba(255,255,255,0)'); vg.addColorStop(1, 'rgba(0,0,0,.3)');
  g.fillStyle = vg; g.fillRect(-a, -b, w, h);
  stripes(g, v, w, -b, h);
  g.strokeStyle = 'rgba(0,0,0,.2)'; g.lineWidth = 1.2;
  for (const s of [-1, 1]) { g.beginPath(); g.moveTo(s * a * .5, -b * .92); g.lineTo(s * a * .45, -b * .3); g.stroke(); }
  g.restore();
  bodyPath(g, w, h, B.nose); g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 1.2; g.stroke();

  const y0 = B.cab[0] * h, y1 = B.cab[1] * h, yA = y0 + (y1 - y0) * .3, yB = y0 + (y1 - y0) * .72;
  g.beginPath(); g.moveTo(-a * .66, y0); g.lineTo(a * .66, y0); g.lineTo(a * .8, yA); g.lineTo(a * .8, yB);
  g.lineTo(a * .62, y1); g.lineTo(-a * .62, y1); g.lineTo(-a * .8, yB); g.lineTo(-a * .8, yA); g.closePath();
  const gl = g.createLinearGradient(0, y0, 0, y1);
  gl.addColorStop(0, '#1d2b38'); gl.addColorStop(.5, '#0a0f14'); gl.addColorStop(1, '#16212b');
  g.fillStyle = gl; g.fill(); g.lineJoin = 'round'; g.strokeStyle = 'rgba(0,0,0,.7)'; g.lineWidth = 1.5; g.stroke();
  g.fillStyle = 'rgba(255,255,255,.15)'; g.beginPath();
  g.moveTo(-a * .55, y0 + 1); g.lineTo(-a * .12, y0 + 1); g.lineTo(-a * .42, yA); g.lineTo(-a * .7, yA); g.closePath(); g.fill();
  rrPath(g, -a * .7, yA, a * 1.4, yB - yA, 5);
  g.fillStyle = hGrad(g, a, [[0, shade(c, -.35)], [.5, shade(c, .25)], [1, shade(c, -.4)]]); g.fill();
  if (v.accent) { g.save(); rrPath(g, -a * .7, yA, a * 1.4, yB - yA, 5); g.clip(); stripes(g, v, w, yA, yB - yA); g.restore(); }

  g.fillStyle = shade(c, -.55);
  for (const s of [-1, 1]) { g.beginPath(); g.ellipse(s * a * 1.04, y0 + (y1 - y0) * .08, a * .13, h * .026, 0, 0, TAU); g.fill(); }

  g.fillStyle = '#0b0c0e';
  if (v.body === 'sport') {
    rrPath(g, -a * .82, b * .78, a * 1.64, h * .05, 3); g.fill();
    rrPath(g, -a * .7, -b, a * 1.4, 4, 2); g.fill();
  } else if (v.body === 'super' || v.body === 'hyper') {
    rrPath(g, -a * 1.08, b * .8, a * 2.16, h * .055, 3); g.fill();
    rrPath(g, -a * .72, -b, a * 1.44, 4, 2); g.fill();
    if (v.body === 'super') {
      for (const s of [-1, 1]) { rrPath(g, s * a * .8 - a * .12, h * .08, a * .24, h * .1, 3); g.fill(); }
      g.fillStyle = 'rgba(0,0,0,.5)'; rrPath(g, -a * .5, y1, a, b * .74 - y1, 4); g.fill();
      g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1;
      for (let y = y1 + h * .04; y < b * .72; y += h * .045) { g.beginPath(); g.moveTo(-a * .42, y); g.lineTo(a * .42, y); g.stroke(); }
    } else {
      g.beginPath(); g.ellipse(0, -b * .9, a * .28, h * .03, 0, 0, TAU); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 1.5;
      for (const s of [-1, 1]) { g.beginPath(); g.moveTo(s * a * .3, y1); g.lineTo(s * a * .3, b * .76); g.stroke(); }
    }
  }
  g.fillStyle = '#fff6d8';
  for (const s of [-1, 1]) { g.beginPath(); g.ellipse(s * a * .62, -b * .86, a * .2, h * .02, s * .45, 0, TAU); g.fill(); }
  g.fillStyle = '#e1202c';
  for (const s of [-1, 1]) { rrPath(g, s * a * .68 - a * .22, b * .9, a * .44, h * .028, 2); g.fill(); }
  g.restore();
}
function spriteOf(v, w, h) {
  const k = v.body + v.color + (v.accent || '') + (v.cargo || '') + Math.round(w) + 'x' + Math.round(h);
  if (A.cars[k]) return A.cars[k];
  const cw = w * 1.5, ch = h * 1.2, [c, g] = mk(cw, ch);
  g.translate(cw / 2, ch / 2); paintVehicle(g, v, w, h);
  return (A.cars[k] = { c, cw, ch });
}
function treeOf(r) {
  if (A.trees[r]) return A.trees[r];
  const s = Math.ceil(r * 2.6), [c, g] = mk(s, s), x = s / 2;
  g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(x + r * .25, x + r * .25, r, 0, TAU); g.fill();
  const q = g.createRadialGradient(x - r * .3, x - r * .3, r * .1, x, x, r);
  q.addColorStop(0, '#3f7d4a'); q.addColorStop(1, '#16341f');
  g.fillStyle = q; g.beginPath(); g.arc(x, x, r, 0, TAU); g.fill();
  g.fillStyle = 'rgba(255,255,255,.06)'; g.beginPath(); g.arc(x - r * .3, x - r * .3, r * .45, 0, TAU); g.fill();
  return (A.trees[r] = { c, s });
}
function paintPreview(cn, car, s) {      // horizontal car for menu + garage cards
  const d = Math.min(devicePixelRatio || 1, 2);
  cn.width = Math.ceil(246 * s * d); cn.height = Math.ceil(150 * s * d);
  cn.style.width = 246 * s + 'px'; cn.style.height = 150 * s + 'px';
  const g = cn.getContext('2d'); g.scale(s * d, s * d);
  g.translate(123, 75); g.rotate(Math.PI / 2); paintVehicle(g, car, 100, 205);
}

/* ================= BAKED WORLD ASSETS ================= */
const noiseCv = document.createElement('canvas'); noiseCv.width = noiseCv.height = 120;
(() => {
  const g = noiseCv.getContext('2d'), id = g.createImageData(120, 120);
  for (let i = 0; i < id.data.length; i += 4) {
    id.data[i] = id.data[i + 1] = id.data[i + 2] = Math.random() < .5 ? 255 : 0;
    id.data[i + 3] = Math.random() * 26;
  }
  g.putImageData(id, 0, 0);
})();
A.noise = ctx.createPattern(noiseCv, 'repeat');

function buildAssets() {
  const { w, h, rx, rw, lane } = L;
  A.cars = {}; A.trees = {};
  { // scrolling road tile (360px loops cleanly: lane dashes 90, curbs 72, noise 120)
    const [c, g] = mk(w, 360);
    g.fillStyle = '#0d1511'; g.fillRect(0, 0, w, 360);
    g.globalAlpha = .7; g.fillStyle = A.noise; g.fillRect(0, 0, w, 360); g.globalAlpha = 1;
    const q = g.createLinearGradient(rx, 0, rx + rw, 0);
    q.addColorStop(0, '#20232a'); q.addColorStop(.5, '#2c2f37'); q.addColorStop(1, '#20232a');
    g.fillStyle = q; g.fillRect(rx, 0, rw, 360);
    g.fillStyle = A.noise; g.fillRect(rx, 0, rw, 360);
    g.fillStyle = 'rgba(235,235,240,.8)';
    for (let l = 1; l < 3; l++) for (let y = 0; y < 360; y += 90) { rrPath(g, rx + l * lane - 2.5, y, 5, 46, 2.5); g.fill(); }
    g.fillStyle = 'rgba(235,235,240,.7)'; g.fillRect(rx + 10, 0, 3, 360); g.fillRect(rx + rw - 13, 0, 3, 360);
    for (let y = 0; y < 360; y += 72) {
      g.fillStyle = '#b3202a'; g.fillRect(rx - 8, y, 8, 36); g.fillRect(rx + rw, y, 8, 36);
      g.fillStyle = '#e8e8ea'; g.fillRect(rx - 8, y + 36, 8, 36); g.fillRect(rx + rw, y + 36, 8, 36);
    }
    A.tile = c;
  }
  { // night tint + vignette in one layer
    const [c, g] = mk(w, h);
    g.fillStyle = 'rgba(4,7,18,.42)'; g.fillRect(0, 0, w, h);
    const q = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * .35, w / 2, h / 2, Math.max(w, h) * .78);
    q.addColorStop(0, 'rgba(0,0,0,0)'); q.addColorStop(1, 'rgba(0,0,0,.55)');
    g.fillStyle = q; g.fillRect(0, 0, w, h);
    A.shade = c;
  }
  A.red = glow(64, '255,30,30', .32);   A.blue = glow(128, '60,140,255', .24);
  A.warm = glow(128, '255,196,120', .3); A.bulb = glow(36, '255,230,170', .9); A.gold = glow(64, '255,200,60', .4);
  { // coin
    const [c, g] = mk(40, 40, 2);
    const q = g.createRadialGradient(15, 14, 2, 20, 20, 19);
    q.addColorStop(0, '#fff3b0'); q.addColorStop(.5, '#f2b705'); q.addColorStop(1, '#a86e00');
    g.fillStyle = q; g.beginPath(); g.arc(20, 20, 18, 0, TAU); g.fill();
    g.strokeStyle = '#7a4d00'; g.lineWidth = 2; g.stroke();
    g.strokeStyle = 'rgba(255,255,255,.55)'; g.beginPath(); g.arc(20, 20, 12, 0, TAU); g.stroke();
    g.fillStyle = '#8a5a00'; g.font = '800 16px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('$', 20, 21);
    A.coin = c;
  }
  { // nitro flame
    const [c, g] = mk(32, 128, 1);
    const q = g.createLinearGradient(0, 0, 0, 128);
    q.addColorStop(0, 'rgba(255,255,255,.95)'); q.addColorStop(.2, 'rgba(120,200,255,.85)');
    q.addColorStop(.55, 'rgba(255,140,40,.55)'); q.addColorStop(1, 'rgba(255,60,0,0)');
    g.fillStyle = q; g.beginPath(); g.moveTo(4, 0); g.quadraticCurveTo(0, 60, 16, 128); g.quadraticCurveTo(32, 60, 28, 0); g.fill();
    A.flame = c;
  }
  { // headlight beam
    const pw = lane * .52; A.bw = pw * 3 + lane * .6; A.bh = lane * 3.2;
    const [c, g] = mk(A.bw, A.bh);
    const q = g.createLinearGradient(0, A.bh, 0, 0);
    q.addColorStop(0, 'rgba(255,238,200,.34)'); q.addColorStop(1, 'rgba(255,238,200,0)');
    g.fillStyle = q; g.beginPath();
    g.moveTo(A.bw / 2 - pw * .5, A.bh); g.lineTo(0, 0); g.lineTo(A.bw, 0); g.lineTo(A.bw / 2 + pw * .5, A.bh); g.fill();
    A.beam = c;
  }
  // pre-bake every sprite so the first frames never hitch
  const base = lane * .5, pw = lane * .52;
  for (const [, body, bw, bh] of TRAFFIC)
    for (const col of PAINT) for (const cg of (body === 'truck' ? CARGO : [undefined]))
      spriteOf({ body, color: col, cargo: cg }, base * bw, base * bh);
  for (const car of CARS) spriteOf(car, pw, pw * 2.05);
}
function relayout() {
  const w = cv.clientWidth, h = cv.clientHeight;
  if (w === L.w && h === L.h) return;
  L.dpr = Math.min(devicePixelRatio || 1, 1.5); L.w = w; L.h = h;
  cv.width = Math.ceil(w * L.dpr); cv.height = Math.ceil(h * L.dpr);
  ctx.setTransform(L.dpr, 0, 0, L.dpr, 0, 0);
  L.rw = Math.min(w * .84, 560); L.rx = (w - L.rw) / 2; L.lane = L.rw / 3;
  buildAssets();
}

/* ================= RUN STATE ================= */
const G = { mode: 'menu', run: null };
function addDeco(r, y) {
  const n = r.decoN++;
  if (n % 3 === 0) r.deco.push({ k: 'lamp', side: -1, y }, { k: 'lamp', side: 1, y });
  else for (const side of [-1, 1]) r.deco.push({ k: 'tree', side, y: y + rnd(0, 40), r: Math.round(rnd(14, 26)), j: Math.random() });
}
function newRun() {
  const r = { x: 1, tx: 1, speed: 6.5, boost: 1, nitro: false, charge: 0, coins: 0, dist: 0, scroll: 0,
    cars: [], gold: [], deco: [], fx: [], spawnT: 45, coinT: 250, decoT: 130, decoN: 0,
    shake: 0, dead: false, deadT: 0, spin: 0, newBest: false, shown: false };
  for (let y = L.h; y > -60; y -= 130) addDeco(r, y);
  return r;
}
const me = () => { const w = L.lane * .52; return { w, h: w * 2.05, x: L.rx + (G.run.x + .5) * L.lane, y: L.h - L.lane * 1.15 }; };
const score = r => Math.floor(r.dist / 20);

function advance(r, mv) {      // scroll road + roadside
  r.scroll += mv; r.decoT -= mv;
  if (r.decoT <= 0) { addDeco(r, -60); r.decoT = 130; }
  for (const d of r.deco) d.y += mv;
  if (r.deco.length && r.deco[0].y > L.h + 80) r.deco = r.deco.filter(d => d.y < L.h + 80);
}
function spawnRow(r) {         // exactly one car per row
  const lane = (Math.random() * 3) | 0;
  r.spawnT = Math.max(24, 46 - (r.speed - 6.5) * 1.9) + rnd(0, 16);
  if (r.cars.some(c => c.lane === lane && c.y < c.h * 1.6)) return;
  let roll = Math.random(), t = TRAFFIC[0];
  for (const e of TRAFFIC) { if ((roll -= e[0]) <= 0) { t = e; break; } }
  const base = L.lane * .5;
  r.cars.push({ lane, body: t[1], color: pick(PAINT), cargo: pick(CARGO), w: base * t[2], h: base * t[3], y: -base * t[3] });
}
function spawnGold(r) {
  const lane = (Math.random() * 3) | 0;
  r.coinT = rnd(350, 750);
  if (r.cars.some(c => c.lane === lane && c.y < 320)) return;
  const n = 4 + ((Math.random() * 3) | 0);
  for (let i = 0; i < n; i++) r.gold.push({ lane, y: -30 - i * 64, ph: Math.random() * 6 });
}
function burst(r, x, y, n, speed, kind) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * TAU, v = rnd(1, speed);
    r.fx.push(kind === 'smoke'
      ? { smoke: 1, x: x + rnd(-15, 15), y: y + rnd(-15, 15), vx: rnd(-.6, .6), vy: -rnd(0, 1.2), r: rnd(8, 16), life: 1, decay: .008 }
      : { x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 1, decay: rnd(.03, .07) });
  }
}
function crash(r, car) {
  const p = me(), cx = (L.rx + (car.lane + .5) * L.lane + p.x) / 2, cy = (car.y + p.y) / 2;
  r.dead = true; r.nitro = false; r.shake = 20; r.spin = (Math.random() < .5 ? -1 : 1) * rnd(.35, .65);
  if (score(r) > Store.best) { Store.best = score(r); r.newBest = true; }
  Store.save();
  burst(r, cx, cy, 26, 8); burst(r, cx, cy, 10, 0, 'smoke');
}
function toggleNitro() {
  const r = G.run;
  if (G.mode !== 'play' || r.dead) return;
  if (r.nitro) r.nitro = false; else if (r.charge >= .999) r.nitro = true;
}

function step(dt) {
  const r = G.run;
  if (G.mode === 'menu') { advance(r, 3 * dt); return; }
  for (const f of r.fx) { f.x += f.vx * dt; f.y += f.vy * dt; f.life -= f.decay * dt; if (f.smoke) f.r += .35 * dt; else f.vy += .08 * dt; }
  if (r.fx.length) r.fx = r.fx.filter(f => f.life > 0);
  r.shake = Math.max(0, r.shake - .8 * dt);
  if (r.dead) {
    r.deadT += dt;
    if (r.deadT < 200 && r.fx.length < 30 && Math.random() < .3 * dt) { const p = me(); burst(r, p.x, p.y - p.h * .3, 1, 0, 'smoke'); }
    if (r.deadT > 20 && !r.shown) showOver(r);
    return;
  }
  const car = Store.car;
  r.x += (r.tx - r.x) * Math.min(1, car.grip * dt);
  r.speed = Math.min(16, r.speed + .0026 * dt);
  if (r.nitro) { r.charge -= dt / 420; r.shake = Math.max(r.shake, 2); if (r.charge <= 0) { r.charge = 0; r.nitro = false; } }
  r.boost += ((r.nitro ? car.nitro : 1) - r.boost) * Math.min(1, .08 * dt);
  const v = r.speed * r.boost, mv = v * dt;
  r.dist += mv; advance(r, mv);
  if ((r.spawnT -= dt) <= 0) spawnRow(r);
  if ((r.coinT -= mv) <= 0) spawnGold(r);

  const p = me();
  for (let i = r.gold.length - 1; i >= 0; i--) {
    const c = r.gold[i]; c.y += mv;
    const cx = L.rx + (c.lane + .5) * L.lane;
    if (Math.abs(cx - p.x) < L.lane * .36 && Math.abs(c.y - p.y) < p.h * .5 + 10) {
      r.gold.splice(i, 1); r.coins++; Store.data.wallet += car.coin;
      if (!r.nitro) r.charge = Math.min(1, r.charge + 1 / 70);
      if (r.coins % 10 === 0) Store.save();
      burst(r, cx, c.y, 6, 4);
    } else if (c.y > L.h + 40) r.gold.splice(i, 1);
  }
  for (const c of r.cars) {
    c.y += (v - LANE_SPEED[c.lane]) * dt;
    const cx = L.rx + (c.lane + .5) * L.lane;
    if (Math.abs(cx - p.x) < (c.w + p.w) / 2 * .9 && Math.abs(c.y - p.y) < (c.h + p.h) / 2 * .92) { crash(r, c); break; }
  }
  if (r.cars.length && r.cars[0].y > L.h + r.cars[0].h) r.cars = r.cars.filter(c => c.y < L.h + c.h);
}

/* ================= RENDER ================= */
const FONT = 'system-ui,-apple-system,"Segoe UI",sans-serif';
function render() {
  const r = G.run, { w, h, rx, rw, lane } = L, p = me(), g = ctx, play = G.mode === 'play';
  g.save();
  if (r.shake > .1) g.translate(rnd(-.5, .5) * r.shake, rnd(-.5, .5) * r.shake);
  for (let y = (r.scroll % 360) - 360; y < h; y += 360) g.drawImage(A.tile, 0, Math.round(y), w, 361);

  for (const c of r.cars) { const s = spriteOf(c, c.w, c.h); g.drawImage(s.c, rx + (c.lane + .5) * lane - s.cw / 2, c.y - s.ch / 2, s.cw, s.ch); }
  const cr = lane * .17;
  for (const c of r.gold) {
    const sx = Math.max(.15, Math.abs(Math.cos(c.ph + r.scroll * .05)));
    g.drawImage(A.coin, rx + (c.lane + .5) * lane - cr * sx, c.y - cr, cr * 2 * sx, cr * 2);
  }
  for (const d of r.deco) {
    if (d.k === 'tree') {
      const t = treeOf(d.r), m = rx * .5, x = d.side < 0 ? m + (d.j - .5) * rx * .3 : rx + rw + m + (d.j - .5) * rx * .3;
      g.drawImage(t.c, x - t.s / 2, d.y - t.s / 2, t.s, t.s);
    } else { g.fillStyle = '#2a2d31'; g.beginPath(); g.arc(d.side < 0 ? rx - 18 : rx + rw + 18, d.y, 4, 0, TAU); g.fill(); }
  }
  const ev = r.speed * r.boost;
  if (ev > 8) {
    g.fillStyle = `rgba(255,255,255,${Math.min(.3, (ev - 8) * .025)})`;
    for (let i = 0; i < 12; i++) g.fillRect(rx + ((i * 97 + 13) % 100) / 100 * rw, ((r.scroll * 1.8 + i * 173) % (h + 200)) - 100, 1.5, 60 + i * 6);
  }
  g.drawImage(A.shade, 0, 0, w, h);

  g.globalCompositeOperation = 'lighter';   // all light sources
  for (const c of r.gold) g.drawImage(A.gold, rx + (c.lane + .5) * lane - lane * .3, c.y - lane * .3, lane * .6, lane * .6);
  for (const d of r.deco) if (d.k === 'lamp') {
    const bx = d.side < 0 ? rx - 18 : rx + rw + 18, px = d.side < 0 ? rx + lane * .15 : rx + rw - lane * .15;
    g.drawImage(A.warm, px - lane * 1.3, d.y - lane * 1.3, lane * 2.6, lane * 2.6);
    g.drawImage(A.bulb, bx - 18, d.y - 18, 36, 36);
  }
  for (const c of r.cars) {
    const cx = rx + (c.lane + .5) * lane, rad = c.w * .8, ty = c.y + c.h / 2;
    g.drawImage(A.red, cx - c.w * .3 - rad, ty - rad, rad * 2, rad * 2);
    g.drawImage(A.red, cx + c.w * .3 - rad, ty - rad, rad * 2, rad * 2);
  }
  if (play) {
    if (!r.dead) g.drawImage(A.beam, p.x - A.bw / 2, p.y - p.h / 2 - A.bh, A.bw, A.bh);
    if (!r.dead && r.boost > 1.05) {
      const k = Math.min(1, (r.boost - 1) / (Store.car.nitro - 1)), fh = p.h * rnd(.55, 1.05) * k, fw = p.w * .3;
      for (const s of [-1, 1]) g.drawImage(A.flame, p.x + s * p.w * .26 - fw / 2, p.y + p.h * .46, fw, fh);
    }
    g.drawImage(A.blue, p.x - p.h, p.y - p.h, p.h * 2, p.h * 2);
  }
  g.globalCompositeOperation = 'source-over';

  if (play) {
    const sp = spriteOf(Store.car, p.w, p.h), ang = r.dead ? r.spin : clamp((r.tx - r.x) * .25, -.3, .3);
    g.save(); g.translate(p.x, p.y); g.rotate(ang); g.drawImage(sp.c, -sp.cw / 2, -sp.ch / 2, sp.cw, sp.ch); g.restore();
  }
  if (r.fx.length) {
    g.globalCompositeOperation = 'lighter'; g.lineWidth = 2;
    for (const f of r.fx) if (!f.smoke) {
      g.strokeStyle = `rgba(255,190,80,${f.life})`; g.beginPath(); g.moveTo(f.x, f.y); g.lineTo(f.x - f.vx * 2, f.y - f.vy * 2); g.stroke();
    }
    g.globalCompositeOperation = 'source-over';
    for (const f of r.fx) if (f.smoke) { g.fillStyle = `rgba(70,70,76,${f.life * .45})`; g.beginPath(); g.arc(f.x, f.y, f.r, 0, TAU); g.fill(); }
  }
  g.restore();
  if (play) hud(r);
}
function hud(r) {
  const g = ctx, { w } = L, s = score(r);
  g.textAlign = 'center'; g.font = 'italic 800 44px ' + FONT; g.lineWidth = 5; g.lineJoin = 'round';
  g.strokeStyle = 'rgba(0,0,0,.55)'; g.strokeText(s, w / 2, 56); g.fillStyle = '#fff'; g.fillText(s, w / 2, 56);
  g.font = '600 14px ' + FONT; g.fillStyle = 'rgba(255,255,255,.85)';
  g.textAlign = 'left'; g.fillText(Math.round(r.speed * r.boost * 18) + ' km/h', 16, 30);
  g.textAlign = 'right'; g.fillText('BEST ' + Store.best, w - 16, 30);
  g.drawImage(A.coin, w / 2 - 40, 62, 22, 22);
  g.textAlign = 'left'; g.font = '700 18px ' + FONT; g.fillStyle = '#ffd24a'; g.fillText(r.coins, w / 2 - 14, 79);
}

/* ================= UI ================= */
const nitroBtn = $('#nitro');
function show(id) { $$('.screen').forEach(s => s.classList.toggle('on', s.id === id)); }
function refreshWallet() { $$('[data-wallet]').forEach(e => e.textContent = Math.floor(Store.data.wallet)); }
function refreshMenu() {
  const car = Store.car;
  refreshWallet();
  $('#pname').textContent = car.name;
  $('#ptier').textContent = TIER[car.tier].name; $('#ptier').style.color = TIER[car.tier].color;
  paintPreview($('#preview'), car, .8);
}
function bars(c) {
  const n = (v, lo, hi) => Math.round(clamp((v - lo) / (hi - lo), 0, 1) * 100);
  const row = (t, p) => `<div class="st"><span>${t}</span><i><u style="width:${p}%"></u></i></div>`;
  return row('HANDLING', n(c.grip, .14, .36)) + row('NITRO', n(c.nitro, 1.25, 1.85)) + row('COINS', n(c.coin, 1, 2));
}
function renderGarage() {
  const list = $('#glist'), top = list.scrollTop, D = Store.data;
  let html = '';
  for (const t of [1, 2, 3, 4]) {
    html += `<div class="tier" style="color:${TIER[t].color}">${TIER[t].name}</div>`;
    for (const c of CARS.filter(c => c.tier === t)) {
      const own = D.owned.includes(c.id), sel = D.sel === c.id, price = c.price.toLocaleString();
      const act = sel ? '<button class="buy on" disabled>SELECTED</button>'
        : own ? `<button class="buy" data-act="use" data-id="${c.id}">SELECT</button>`
        : D.wallet >= c.price ? `<button class="buy" data-act="buy" data-id="${c.id}"><i class="coin"></i>${price}</button>`
        : `<button class="buy lock" disabled><i class="coin"></i>${price}</button>`;
      html += `<div class="card${sel ? ' sel' : ''}"><canvas data-car="${c.id}"></canvas><div><div class="nm">${c.name}</div>${bars(c)}</div>${act}</div>`;
    }
  }
  list.innerHTML = html;
  $$('canvas[data-car]', list).forEach(cn => paintPreview(cn, CARS.find(c => c.id === cn.dataset.car), .5));
  list.scrollTop = top; refreshWallet();
}
function showOver(r) {
  r.shown = true; nitroBtn.style.display = 'none';
  $('#oScore').textContent = score(r);
  $('#oBest').textContent = r.newBest ? 'NEW BEST' : 'BEST ' + Store.best;
  $('#oCoins').textContent = 'COINS ' + r.coins;
  show('over');
}
function startRun() { G.run = newRun(); G.mode = 'play'; show(null); nitroBtn.style.display = 'flex'; }
function toMenu() { G.run = newRun(); G.mode = 'menu'; nitroBtn.style.display = 'none'; refreshMenu(); show('menu'); }
const ACT = {
  play: startRun, respawn: startRun, menu: toMenu,
  garage() { renderGarage(); show('garage'); },
  back() { refreshMenu(); show('menu'); },
  use(d) { Store.data.sel = d.id; Store.save(); renderGarage(); },
  buy(d) {
    const c = CARS.find(k => k.id === d.id);
    if (Store.data.wallet < c.price) return;
    Store.data.wallet -= c.price; Store.data.owned.push(c.id); Store.data.sel = c.id; Store.save(); renderGarage();
  }
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]');
  if (b && !b.disabled && ACT[b.dataset.act]) ACT[b.dataset.act](b.dataset);
});
nitroBtn.addEventListener('pointerdown', e => { e.preventDefault(); toggleNitro(); });
cv.addEventListener('pointerdown', e => {
  const r = G.run;
  if (G.mode !== 'play' || r.dead) return;
  r.tx = clamp(r.tx + (e.clientX < L.w / 2 ? -1 : 1), 0, 2);
});
addEventListener('keydown', e => {
  const r = G.run;
  if (G.mode !== 'play') return;
  if (r.dead) { if (e.key === 'Enter' || e.key === ' ') startRun(); return; }
  if (e.key === 'ArrowLeft') r.tx = clamp(r.tx - 1, 0, 2);
  if (e.key === 'ArrowRight') r.tx = clamp(r.tx + 1, 0, 2);
  if (e.key === 'ArrowUp' || e.key === 'Shift') toggleNitro();
});
addEventListener('resize', relayout);
addEventListener('pagehide', () => Store.save());
document.addEventListener('visibilitychange', () => { if (document.hidden) Store.save(); });

/* ================= LOOP ================= */
let nitroKey = '';
function syncNitroButton() {
  const r = G.run;
  if (G.mode !== 'play') return;
  const pct = Math.round(r.charge * 100), ready = r.charge >= .999;
  const key = pct + '|' + r.nitro + '|' + ready;
  if (key === nitroKey) return;
  nitroKey = key;
  nitroBtn.style.setProperty('--p', pct);
  nitroBtn.classList.toggle('on', r.nitro);
  nitroBtn.classList.toggle('ready', ready && !r.nitro);
  nitroBtn.lastChild.textContent = r.nitro ? Math.ceil(r.charge * 7) + 's' : Math.round(r.charge * 70) + '/70';
}
relayout();
G.run = newRun();
refreshMenu();
let last = performance.now();
(function loop(now) {
  const dt = Math.min(2.5, (now - last) / 16.667); last = now;
  step(dt); render(); syncNitroButton();
  requestAnimationFrame(loop);
})(last);
