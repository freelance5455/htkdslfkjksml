// Navigation to Apps
document.getElementById("hideApps").onclick = function () {
    window.location.href = "hideApps.html";
};

document.getElementById("photos").onclick = function () {
    window.location.href = "photos.html";
};

document.getElementById("videos").onclick = function () {
    window.location.href = "videos.html";
};

document.getElementById("files").onclick = function () {
    window.location.href = "files.html";
};

document.getElementById("settings").onclick = function () {
    window.location.href = "settings.html";
};

document.getElementById("changePin").onclick = function () {
    window.location.href = "changePin.html";
};

document.getElementById("recoveryBtn").onclick = function () {
    window.location.href = "recovery.html";
};

document.getElementById("restoreBtn").onclick = function () {
    window.location.href = "restore.html";
};

document.getElementById("exit").onclick = function () {
    window.location.href = "index.html";
};
document.getElementById("recycleBtn").onclick = function(){

    window.location.href = "recycle.html";

};