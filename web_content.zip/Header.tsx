import { jsxDEV } from "react/jsx-dev-runtime";
function Header({ lang, setLang, light, setLight, t }) {
  return /* @__PURE__ */ jsxDEV("header", { className: "topbar", dir: lang === "fa" ? "rtl" : "ltr", children: [
    /* @__PURE__ */ jsxDEV("a", { className: "brand", href: "#top", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "brand-icon", children: "\u25CF\u2501\u2501\u25CF" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 303
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "brand-name", children: "IRON ATLAS" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 349
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "brand-tag", children: t.tagline }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 395
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 343
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 1,
      columnNumber: 270
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "nav-links", children: [
      /* @__PURE__ */ jsxDEV("a", { className: "nav-link active", href: "#top", children: t.navHome }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 479
      }, this),
      /* @__PURE__ */ jsxDEV("a", { className: "nav-link", href: "#programs", children: t.navPrograms }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 537
      }, this),
      /* @__PURE__ */ jsxDEV("a", { className: "nav-link", href: "#finder", children: t.navFinder }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 597
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 1,
      columnNumber: 452
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "header-actions", children: [
      /* @__PURE__ */ jsxDEV("button", { className: "lang-toggle", "aria-label": "Change language", onClick: () => setLang(lang === "en" ? "fa" : "en"), children: [
        /* @__PURE__ */ jsxDEV("span", { className: lang === "en" ? "active" : "", children: "EN" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 797
        }, this),
        " | ",
        /* @__PURE__ */ jsxDEV("span", { className: lang === "fa" ? "active" : "", children: "FA" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 851
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 691
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "theme-btn", "aria-label": light ? t.dark : t.light, onClick: () => setLight(!light), children: light ? "\u263E" : "\u263C" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 911
      }, this),
      /* @__PURE__ */ jsxDEV("a", { className: "join-btn", href: "#finder", children: t.join }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 1030
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 1,
      columnNumber: 659
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 1,
    columnNumber: 213
  }, this);
}
export {
  Header as default
};
