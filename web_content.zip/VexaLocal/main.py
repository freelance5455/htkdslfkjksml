"""Servidor local: fila de tarefas (uma de cada vez na GPU) + histórico + interface web."""
import io, json, os, queue, socket, threading, time, traceback, uuid
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, ImageOps

import pipelines as P

ROOT = Path(__file__).parent
DATA, UP, OUT = ROOT / "data", ROOT / "data" / "uploads", ROOT / "data" / "outputs"
for d in (UP, OUT):
    d.mkdir(parents=True, exist_ok=True)
HIST = DATA / "history.json"
PORT = int(os.environ.get("PORT", "8000"))

jobs: dict = {}
lock = threading.Lock()
q: "queue.Queue[str]" = queue.Queue()
KINDS = {"i2v", "t2v", "enhance", "hair", "template"}
NEEDS_IMAGE = {"i2v", "enhance", "hair", "template"}


def save_history():
    with lock:
        HIST.write_text(json.dumps(list(jobs.values()), ensure_ascii=False, indent=1), encoding="utf-8")


def load_history():
    if not HIST.exists():
        return
    try:
        for j in json.loads(HIST.read_text(encoding="utf-8")):
            if j["status"] in ("queued", "running"):
                j["status"], j["error"] = "error", "Interrompido (servidor reiniciado)"
            jobs[j["id"]] = j
    except Exception:
        traceback.print_exc()


def worker():
    while True:
        jid = q.get()
        job = jobs.get(jid)
        if not job or job["status"] != "queued":
            continue
        job["status"], job["started"] = "running", time.time()

        def progress(p, msg=""):
            job["progress"], job["message"] = round(float(p), 3), msg

        try:
            name = P.run(job, UP, OUT, progress)
            job["result"] = name
            job["media"] = "video" if name.endswith(".mp4") else "image"
            job["status"] = "done"
        except Exception as e:
            traceback.print_exc()
            job["status"], job["error"] = "error", f"{type(e).__name__}: {e}"
            P.cleanup()
        job["finished"] = time.time()
        save_history()


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "IP-DO-PC"


@asynccontextmanager
async def lifespan(app):
    load_history()
    threading.Thread(target=worker, daemon=True).start()
    ip = lan_ip()
    print("\n  No PC:       http://localhost:%d" % PORT)
    print("  No Android:  http://%s:%d  (mesma rede Wi-Fi)\n" % (ip, PORT))
    yield


app = FastAPI(lifespan=lifespan)
app.mount("/files", StaticFiles(directory=OUT), name="files")


@app.get("/")
def index():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/api/meta")
def meta():
    import torch
    gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "Sem GPU CUDA"
    return {
        "gpu": gpu,
        "models": [{"id": k, "label": v["label"]} for k, v in P.VIDEO.items()],
        "hair": [{"id": a, "label": b} for a, b, _ in P.HAIRSTYLES],
        "colors": [{"id": a, "label": b} for a, b, _ in P.HAIR_COLORS],
        "templates": [{"id": a, "label": b} for a, b, _ in P.TEMPLATES],
    }


@app.get("/api/jobs")
def list_jobs():
    items = sorted(jobs.values(), key=lambda j: j["created"], reverse=True)
    waiting = sorted([j for j in jobs.values() if j["status"] == "queued"], key=lambda j: j["created"])
    pos = {j["id"]: i + 1 for i, j in enumerate(waiting)}
    return [dict(j, position=pos.get(j["id"])) for j in items]


def to_int(v, default):
    try:
        return int(str(v).strip())
    except Exception:
        return default


@app.post("/api/jobs")
async def create_job(
    kind: str = Form(...), model: str = Form("ltx"), prompt: str = Form(""), negative: str = Form(""),
    steps: str = Form(""), seed: str = Form("-1"), ratio: str = Form("16:9"), style: str = Form(""),
    color: str = Form("natural"), template: str = Form(""), scale: str = Form("2"), extra: str = Form(""),
    image: UploadFile = File(None),
):
    if kind not in KINDS:
        raise HTTPException(400, "Tipo inválido")
    has_img = image is not None and bool(image.filename)
    if kind in NEEDS_IMAGE and not has_img:
        raise HTTPException(400, "Escolhe uma imagem primeiro.")
    if kind == "t2v" and not prompt.strip():
        raise HTTPException(400, "Escreve uma descrição do vídeo.")
    if kind in ("i2v", "t2v") and model not in P.VIDEO:
        raise HTTPException(400, "Modelo inválido")
    if kind == "t2v" and ratio not in ("16:9", "9:16", "1:1"):
        ratio = "16:9"
    if kind == "hair" and style not in [h[0] for h in P.HAIRSTYLES]:
        raise HTTPException(400, "Escolhe um penteado.")
    if kind == "template" and template not in [t[0] for t in P.TEMPLATES]:
        raise HTTPException(400, "Escolhe um template.")
    if kind == "enhance" and scale not in ("2", "4"):
        scale = "2"
    if kind == "i2v" and not prompt.strip():
        prompt = "smooth natural motion, high quality, cinematic"

    jid = uuid.uuid4().hex[:12]
    input_name = None
    if has_img:
        try:
            im = ImageOps.exif_transpose(Image.open(io.BytesIO(await image.read()))).convert("RGB")
        except Exception:
            raise HTTPException(400, "Imagem inválida.")
        im.thumbnail((1536 if kind == "enhance" else 2048,) * 2, Image.LANCZOS)
        input_name = f"{jid}.png"
        im.save(UP / input_name)

    job = {
        "id": jid, "kind": kind, "status": "queued", "progress": 0.0, "message": "", "created": time.time(),
        "input": input_name, "result": None, "media": None, "error": None,
        "params": {
            "model": model, "prompt": prompt.strip(), "negative": negative.strip(),
            "steps": to_int(steps, 0) or None, "seed": to_int(seed, -1), "ratio": ratio,
            "style": style, "color": color, "template": template, "scale": scale, "extra": extra.strip(),
        },
    }
    jobs[jid] = job
    save_history()
    q.put(jid)
    return job


@app.delete("/api/jobs/{jid}")
def delete_job(jid: str):
    job = jobs.get(jid)
    if not job:
        raise HTTPException(404, "Não existe")
    if job["status"] == "running":
        raise HTTPException(409, "A tarefa está a correr; espera que termine.")
    jobs.pop(jid, None)
    for f in (OUT / (job["result"] or "_"), UP / (job["input"] or "_")):
        try:
            f.unlink()
        except Exception:
            pass
    save_history()
    return {"ok": True}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")
