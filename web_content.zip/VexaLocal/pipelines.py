"""Modelos de IA: vídeo (LTX, Wan 2.1, CogVideoX), melhoria (Real-ESRGAN) e edição de foto (FLUX Kontext).
Só um modelo grande fica na GPU de cada vez; ao mudar, o anterior é descarregado."""
import gc, os, random, urllib.request
from pathlib import Path

import numpy as np
import torch
from PIL import Image

MODELS_DIR = Path(__file__).parent / "data" / "models"
MODELS_DIR.mkdir(parents=True, exist_ok=True)

WAN_T2V = os.environ.get("WAN_T2V_MODEL", "Wan-AI/Wan2.1-T2V-1.3B-Diffusers")
WAN_I2V = os.environ.get("WAN_I2V_MODEL", "Wan-AI/Wan2.1-I2V-14B-480P-Diffusers")

# ---------------------------------------------------------------- catálogo
VIDEO = {
    "ltx": dict(label="LTX-Video (rápido)", steps=40, fps=24, frames=97, guidance=3.0,
                neg="worst quality, inconsistent motion, blurry, jittery, distorted",
                mod=32, area=704 * 480,
                sizes={"16:9": (704, 480), "9:16": (480, 704), "1:1": (576, 576)}),
    "wan": dict(label="Wan 2.1 (melhor qualidade, mais lento)", steps=30, fps=16, frames=81, guidance=5.0,
                neg="blurry, low quality, static, distorted, extra limbs, deformed, watermark, text",
                mod=16, area=480 * 832,
                sizes={"16:9": (832, 480), "9:16": (480, 832), "1:1": (640, 640)}),
    "cogx": dict(label="CogVideoX 5B", steps=50, fps=8, frames=49, guidance=6.0,
                 neg="", mod=16, area=720 * 480,
                 sizes={"16:9": (720, 480), "9:16": (720, 480), "1:1": (720, 480)}),
}

HAIRSTYLES = [
    ("curto", "Curto clássico", "a short classic haircut"),
    ("pixie", "Pixie", "a pixie cut"),
    ("bob", "Bob", "a chin-length bob cut"),
    ("longo-liso", "Longo liso", "long straight hair"),
    ("longo-ondulado", "Longo ondulado", "long wavy hair"),
    ("cachos", "Cachos", "voluminous curly hair"),
    ("afro", "Afro", "a natural afro"),
    ("tranças", "Tranças", "long braids"),
    ("rabo", "Rabo-de-cavalo", "a high ponytail"),
    ("coque", "Coque", "a neat bun"),
    ("undercut", "Undercut", "an undercut with longer hair on top"),
    ("degrade", "Degradê (fade)", "a skin fade haircut"),
    ("moicano", "Moicano", "a mohawk"),
    ("careca", "Careca", "a completely shaved bald head"),
    ("franja", "Franja", "long hair with straight bangs"),
    ("slick", "Penteado para trás", "slicked-back hair"),
    ("dreads", "Dreadlocks", "dreadlocks"),
    ("crew", "Crew cut", "a military crew cut"),
]
HAIR_COLORS = [
    ("natural", "Manter cor natural", ""), ("preto", "Preto", "jet black"),
    ("castanho-escuro", "Castanho escuro", "dark brown"), ("castanho-claro", "Castanho claro", "light brown"),
    ("loiro", "Loiro", "blonde"), ("platinado", "Platinado", "platinum blonde"),
    ("ruivo", "Ruivo", "copper red"), ("cinzento", "Cinzento", "silver gray"),
    ("branco", "Branco", "white"), ("azul", "Azul", "blue"), ("rosa", "Rosa", "pink"),
    ("roxo", "Roxo", "purple"), ("verde", "Verde", "green"),
]
KEEP = "Keep the person's face, identity, skin tone, expression, clothes and background exactly the same."
TEMPLATES = [
    ("headshot", "Retrato profissional (LinkedIn)", "Transform this photo into a professional corporate headshot: smart business attire, soft studio lighting, clean neutral gray background, sharp focus."),
    ("documento", "Foto de documento", "Turn this into an ID photo: plain white background, face centered looking straight at the camera, neutral expression, even lighting, shoulders visible."),
    ("cinema", "Poster de cinema", "Turn this into a dramatic cinematic movie poster scene with moody teal and orange lighting and film grain."),
    ("vintage", "Foto vintage anos 70", "Make this look like a faded 1970s film photograph with warm tones, grain and soft vignette."),
    ("pb", "Preto e branco de estúdio", "Convert this to an elegant classic black and white studio portrait with dramatic lighting."),
    ("anime", "Anime", "Redraw this as a high quality anime illustration with clean line art and vibrant colors."),
    ("revista", "Capa de revista", "Place this person on a glossy fashion magazine cover shoot with professional studio lighting and a stylish background."),
    ("cyberpunk", "Cyberpunk neon", "Place this person in a rainy cyberpunk city at night with neon signs and glowing reflections."),
    ("praia", "Praia ao pôr do sol", "Place this person on a beautiful beach at golden-hour sunset with warm natural light."),
    ("oleo", "Pintura a óleo", "Repaint this as a classical oil painting with visible brush strokes and rich colors."),
    ("natal", "Cartão de Natal", "Turn this into a festive Christmas card portrait with warm lights, a decorated tree and snow outside."),
    ("fantasia", "Retrato de fantasia", "Transform this person into a heroic fantasy portrait wearing detailed medieval armor in an epic landscape."),
]


def build_prompt(kind, p):
    extra = (p.get("extra") or "").strip()
    if kind == "hair":
        style = next((x[2] for x in HAIRSTYLES if x[0] == p["style"]), None)
        color = next((x[2] for x in HAIR_COLORS if x[0] == p["color"]), "")
        t = f"Change the person's hairstyle to {style}"
        if color:
            t += f", hair color {color}"
        t += f". {KEEP}"
    else:  # template
        base = next(x[2] for x in TEMPLATES if x[0] == p["template"])
        t = f"{base} {KEEP}"
    return f"{t} {extra}".strip()


# ---------------------------------------------------------------- gestão de memória
_cur = {"key": None, "pipe": None}
_esr = {"model": None}


def unload():
    _cur["pipe"] = None
    _cur["key"] = None
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def cleanup():
    unload()
    _esr["model"] = None
    gc.collect()


def get_pipe(key, loader):
    if _cur["key"] == key:
        return _cur["pipe"]
    unload()
    _cur["pipe"] = loader()
    _cur["key"] = key
    return _cur["pipe"]


def step_cb(progress, total, base=0.1, span=0.85):
    def f(pipe, step, t, kwargs):
        progress(base + span * (step + 1) / total, f"passo {step + 1}/{total}")
        return kwargs
    return f


def fit(img, area, mod):
    ar = img.height / img.width
    h = max(mod, int((area * ar) ** 0.5) // mod * mod)
    w = max(mod, int((area / ar) ** 0.5) // mod * mod)
    return img.resize((w, h), Image.LANCZOS), w, h


def fit_long(img, longest=1024, mod=16):
    s = min(1.0, longest / max(img.size))
    w = max(mod, int(img.width * s) // mod * mod)
    h = max(mod, int(img.height * s) // mod * mod)
    return img.resize((w, h), Image.LANCZOS)


# ---------------------------------------------------------------- carregadores
def load_ltx(kind):
    from diffusers import LTXPipeline, LTXImageToVideoPipeline
    cls = LTXPipeline if kind == "t2v" else LTXImageToVideoPipeline
    pipe = cls.from_pretrained("Lightricks/LTX-Video", torch_dtype=torch.bfloat16)
    pipe.enable_model_cpu_offload()
    pipe.vae.enable_tiling()
    return pipe


def load_wan(kind):
    from diffusers import AutoencoderKLWan, WanPipeline, WanImageToVideoPipeline
    if kind == "t2v":
        vae = AutoencoderKLWan.from_pretrained(WAN_T2V, subfolder="vae", torch_dtype=torch.float32)
        pipe = WanPipeline.from_pretrained(WAN_T2V, vae=vae, torch_dtype=torch.bfloat16)
    else:
        from transformers import CLIPVisionModel
        enc = CLIPVisionModel.from_pretrained(WAN_I2V, subfolder="image_encoder", torch_dtype=torch.float32)
        vae = AutoencoderKLWan.from_pretrained(WAN_I2V, subfolder="vae", torch_dtype=torch.float32)
        pipe = WanImageToVideoPipeline.from_pretrained(WAN_I2V, vae=vae, image_encoder=enc, torch_dtype=torch.bfloat16)
    pipe.enable_model_cpu_offload()
    return pipe


def load_cogx(kind):
    from diffusers import CogVideoXPipeline, CogVideoXImageToVideoPipeline
    if kind == "t2v":
        pipe = CogVideoXPipeline.from_pretrained("THUDM/CogVideoX-5b", torch_dtype=torch.bfloat16)
    else:
        pipe = CogVideoXImageToVideoPipeline.from_pretrained("THUDM/CogVideoX-5b-I2V", torch_dtype=torch.bfloat16)
    pipe.enable_model_cpu_offload()
    pipe.vae.enable_tiling()
    pipe.vae.enable_slicing()
    return pipe


def load_kontext():
    from diffusers import FluxKontextPipeline
    pipe = FluxKontextPipeline.from_pretrained("black-forest-labs/FLUX.1-Kontext-dev", torch_dtype=torch.bfloat16)
    pipe.enable_model_cpu_offload()
    return pipe


LOADERS = {"ltx": load_ltx, "wan": load_wan, "cogx": load_cogx}


# ---------------------------------------------------------------- tarefas
def gen_video(kind, p, img, seed, progress):
    m = p["model"]
    d = VIDEO[m]
    steps = p["steps"] or d["steps"]
    gen = torch.Generator("cpu").manual_seed(seed)
    progress(0.02, "a carregar modelo (a primeira vez demora: descarrega vários GB)")
    pipe = get_pipe((m, kind), lambda: LOADERS[m](kind))
    progress(0.1, "a gerar")
    cb = step_cb(progress, steps)
    prompt = p["prompt"]
    neg = p["negative"] or d["neg"]
    common = dict(prompt=prompt, num_inference_steps=steps, generator=gen, callback_on_step_end=cb)

    if kind == "t2v":
        w, h = d["sizes"][p["ratio"]]
        extra = {}
    else:
        if m == "cogx":
            from PIL import ImageOps
            img = ImageOps.fit(img, (720, 480), Image.LANCZOS)
            w, h = 720, 480
        else:
            img, w, h = fit(img, d["area"], d["mod"])
        extra = {"image": img}

    if m == "ltx":
        out = pipe(**common, **extra, negative_prompt=neg, width=w, height=h, num_frames=d["frames"])
    elif m == "wan":
        out = pipe(**common, **extra, negative_prompt=neg, width=w, height=h,
                   num_frames=d["frames"], guidance_scale=d["guidance"])
    else:
        out = pipe(**common, **extra, num_videos_per_prompt=1, num_frames=d["frames"],
                   guidance_scale=d["guidance"])
    return out.frames[0], d["fps"]


def _esr_model():
    if _esr["model"] is None:
        from spandrel import ModelLoader
        path = MODELS_DIR / "RealESRGAN_x4plus.pth"
        if not path.exists():
            url = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth"
            urllib.request.urlretrieve(url, path)
        m = ModelLoader().load_from_file(str(path)).cuda().eval().half()
        _esr["model"] = m
    return _esr["model"]


def enhance(img, scale, progress):
    progress(0.05, "a carregar Real-ESRGAN")
    model = _esr_model()
    s = model.scale
    t = torch.from_numpy(np.array(img)).float().div(255).permute(2, 0, 1)[None]
    _, _, H, W = t.shape
    out = torch.zeros(1, 3, H * s, W * s)
    tile, pad = 256, 16
    ys, xs = list(range(0, H, tile)), list(range(0, W, tile))
    total, n = len(ys) * len(xs), 0
    for y in ys:
        for x in xs:
            y0, y1 = max(y - pad, 0), min(y + tile + pad, H)
            x0, x1 = max(x - pad, 0), min(x + tile + pad, W)
            patch = t[:, :, y0:y1, x0:x1].cuda().half()
            with torch.no_grad():
                o = model(patch).float().cpu()
            h, w = min(tile, H - y), min(tile, W - x)
            cy, cx = (y - y0) * s, (x - x0) * s
            out[:, :, y * s:(y + h) * s, x * s:(x + w) * s] = o[:, :, cy:cy + h * s, cx:cx + w * s]
            n += 1
            progress(0.1 + 0.85 * n / total, f"bloco {n}/{total}")
    arr = (out[0].clamp(0, 1).permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
    res = Image.fromarray(arr)
    if scale != s:
        res = res.resize((img.width * scale, img.height * scale), Image.LANCZOS)
    return res


def kontext(prompt, img, seed, steps, progress):
    progress(0.02, "a carregar FLUX Kontext (a primeira vez demora)")
    pipe = get_pipe(("kontext",), load_kontext)
    steps = steps or 28
    progress(0.1, "a editar")
    res = pipe(image=fit_long(img), prompt=prompt, guidance_scale=2.5, num_inference_steps=steps,
               generator=torch.Generator("cpu").manual_seed(seed),
               callback_on_step_end=step_cb(progress, steps))
    return res.images[0]


def run(job, UP, OUT, progress):
    from diffusers.utils import export_to_video
    p, kind = job["params"], job["kind"]
    seed = p["seed"] if p["seed"] >= 0 else random.randint(0, 2**31 - 1)
    p["seed_used"] = seed
    img = Image.open(UP / job["input"]).convert("RGB") if job.get("input") else None

    if kind in ("i2v", "t2v"):
        frames, fps = gen_video(kind, p, img, seed, progress)
        out = OUT / f"{job['id']}.mp4"
        progress(0.97, "a gravar vídeo")
        export_to_video(frames, str(out), fps=fps)
    else:
        if kind == "enhance":
            res = enhance(img, int(p["scale"]), progress)
        else:
            res = kontext(build_prompt(kind, p), img, seed, p["steps"], progress)
        out = OUT / f"{job['id']}.png"
        res.save(out)
    progress(1.0, "")
    return out.name
