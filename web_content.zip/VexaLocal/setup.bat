@echo off
chcp 65001 >nul
title Vexa Local - Instalacao
cd /d "%~dp0"
echo.
echo === Instalacao (RTX 5080 / CUDA 12.8) ===
where python >nul 2>nul || (echo Python nao encontrado. Instala o Python 3.10-3.12 de python.org e marca "Add to PATH". & pause & exit /b 1)
if not exist venv (
  python -m venv venv || (echo Falhou a criar o ambiente. & pause & exit /b 1)
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
echo.
echo [1/2] PyTorch com CUDA 12.8 (necessario para a RTX 5080)...
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128 || (echo Falhou o PyTorch. & pause & exit /b 1)
echo.
echo [2/2] Restantes bibliotecas...
pip install -r requirements.txt || (echo Falhou o requirements. & pause & exit /b 1)
echo.
python -c "import torch;print('CUDA disponivel:',torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')"
echo.
echo Para Penteado e Templates (FLUX Kontext) precisas de conta Hugging Face:
echo   1. Aceita a licenca em https://huggingface.co/black-forest-labs/FLUX.1-Kontext-dev
echo   2. Cria um token (Read) em https://huggingface.co/settings/tokens
set /p LOGIN=Queres fazer login agora? (s/n): 
if /i "%LOGIN%"=="s" hf auth login
echo.
echo Pronto. Usa run.bat para arrancar.
pause
