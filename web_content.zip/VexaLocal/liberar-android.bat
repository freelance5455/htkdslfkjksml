@echo off
chcp 65001 >nul
echo Executa este ficheiro como Administrador (botao direito).
netsh advfirewall firewall add rule name="Vexa Local 8000" dir=in action=allow protocol=TCP localport=8000 profile=private
echo Feito. Se a rede estiver como "Publica", muda-a para "Privada" nas definicoes do Windows.
pause
