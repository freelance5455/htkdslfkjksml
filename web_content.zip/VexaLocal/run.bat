@echo off
chcp 65001 >nul
title Vexa Local
cd /d "%~dp0"
if not exist venv\Scripts\activate.bat (echo Corre primeiro o setup.bat & pause & exit /b 1)
call venv\Scripts\activate.bat
start "" http://localhost:8000
python main.py
pause
