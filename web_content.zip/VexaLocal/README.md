# Vexa Local – Vídeo & Foto (100 % local)

Gerador de vídeo e foto que corre no teu PC (RTX 5080). O Android usa a app pelo browser, via Wi-Fi.

## Requisitos
- Windows 10/11, driver NVIDIA recente, Python 3.10–3.12
- Espaço em disco: ~100 GB (os modelos descarregam na primeira utilização)
- RAM: 32 GB mínimo; **64 GB recomendado** para o Wan 14B (foto→vídeo)

## Instalar e arrancar
1. `setup.bat` (instala PyTorch CUDA 12.8 + bibliotecas). Faz login no Hugging Face quando pedir.
2. `run.bat` (abre http://localhost:8000).

## Usar no Android
1. Telemóvel e PC na mesma rede Wi-Fi.
2. Corre `liberar-android.bat` **como administrador** (abre a porta 8000 na firewall).
3. No Android abre o endereço que aparece na consola, por exemplo `http://192.168.1.20:8000`.
4. Chrome → ⋮ → "Adicionar ao ecrã principal" para ter ícone.

## Separadores
| Separador | Modelo |
|---|---|
| Foto→Vídeo | LTX-Video, Wan 2.1 14B I2V, CogVideoX 5B I2V |
| Texto→Vídeo | LTX-Video, Wan 2.1 1.3B, CogVideoX 5B |
| Melhorar | Real-ESRGAN x4 (2× ou 4×) |
| Penteado / Templates | FLUX.1 Kontext dev (precisa de login Hugging Face) |
| Histórico | Tudo o que já geraste (pasta `data/outputs`) |

Só uma tarefa corre de cada vez na GPU; as restantes ficam na fila.

## Problemas comuns
- **CUDA out of memory**: usa LTX, ou fecha outros programas que usem a GPU.
- **Wan 14B muito lento / sem RAM**: usa LTX para foto→vídeo, ou define a variável `WAN_I2V_MODEL` para outro modelo Wan I2V.
- **401/403 no Penteado ou Templates**: falta aceitar a licença do FLUX Kontext ou fazer `hf auth login`.
- **Android não abre**: confirma a mesma rede, a firewall (passo 2) e que a rede do PC está como "Privada".
- Qualquer erro aparece no cartão da tarefa e na consola do `run.bat`.
