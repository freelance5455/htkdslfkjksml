-- APPRECIATE native CLOUD resource links. These fields only store provider-issued IDs.
ALTER TABLE cloud_projects
  ADD COLUMN IF NOT EXISTS cloud_repository_name TEXT,
  ADD COLUMN IF NOT EXISTS source_uploaded_at TIMESTAMPTZ;
ALTER TABLE cloud_deployment_requests
  ADD COLUMN IF NOT EXISTS cloud_build_id TEXT,
  ADD COLUMN IF NOT EXISTS cloud_application_id TEXT,
  ADD COLUMN IF NOT EXISTS cloud_image_tag TEXT,
  ADD COLUMN IF NOT EXISTS provider_result JSONB NOT NULL DEFAULT '{}'::jsonb;
CREATE INDEX IF NOT EXISTS cloud_projects_repository_idx ON cloud_projects(cloud_repository_name);
