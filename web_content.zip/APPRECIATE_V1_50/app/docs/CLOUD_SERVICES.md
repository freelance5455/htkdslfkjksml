# APPRECIATE CLOUD connection

APPRECIATE connects to the independently running APPRECIATE CLOUD control plane using `APPRECIATE_CLOUD_URL` and `APPRECIATE_CLOUD_API_KEY` configured on the APPRECIATE server. The Cloud Services page reports whether the control plane is reachable and links to its owner portal.

APPRECIATE CLOUD v1.3 includes native APPRECIATE CODE repository creation, ZIP source upload, Dockerfile builds, and container deployment. It does not depend on GitLab, Render, Forgejo or Coolify.

The APPRECIATE application project/deployment records are not automatically converted into cloud deployments in this release. Use the APPRECIATE CLOUD portal to create a CODE project, upload source, build and deploy. The in-app project request remains a planning/request record, not proof that a container is running.

This is an owner-operated early release. Customer accounts, tenant isolation, Git push/clone transport, build queues, database provisioning per project, domain/TLS automation, backup/restore, quotas, and independent security testing remain incomplete. Do not expose the owner API key to customers.


## Private service connection

When deployed with the root Docker Compose stack, the APPRECIATE API checks the cloud-control service over the private Docker network using `APPRECIATE_CLOUD_INTERNAL_URL=http://cloud-control:3100`. `APPRECIATE_CLOUD_URL` remains the public HTTPS address used by the owner browser. This prevents the API health check from depending on public DNS or routing back into the same server. The owner API key remains server-side.


## Native APPRECIATE CLOUD source-to-deployment workflow (v1.50.0)

The authenticated APPRECIATE API now provisions a private native Git repository when CLOUD is configured. Each project owner can upload a ZIP source archive (maximum 24 MB) through the APPRECIATE application. The API forwards the archive server-to-server; the CLOUD API key is never exposed to the browser. The deploy action runs a native CLOUD build first and only calls the deployment endpoint after a successful build. A deployment is marked `live` only after CLOUD returns a running application and application ID. Build or deployment errors are recorded as `failed`.

Required server environment: `APPRECIATE_CLOUD_INTERNAL_URL` (preferred internal service URL), `APPRECIATE_CLOUD_URL` (public/control-panel URL), and `APPRECIATE_CLOUD_API_KEY`. The API key must exactly match `CLOUD_ADMIN_KEY` on the CLOUD host. Keep the native CLOUD management API private; do not publish its admin key or expose the Docker socket to the public internet.

Apply database migration `010_native_cloud_resources.sql` before using this workflow. Source archives must contain a Dockerfile at the project root (or one top-level project folder); the current native build runner requires it. The default runtime container port is 3000 and can be overridden in the deployment request.

This is a source-code integration. A real build/deployment still requires the native CLOUD service, PostgreSQL, Git, Docker Engine, secure network routing, and production TLS to be configured and tested on the deployment host.
