'use strict';

function createCloudProvider({ baseUrl, apiKey, fetchImpl = fetch, timeoutMs = 30000 }) {
  const base = String(baseUrl || '').replace(/\/$/, '');
  const key = String(apiKey || '');
  function configured() { return Boolean(base && key); }
  async function request(path, { method = 'GET', body, raw, timeoutMs: customTimeout } = {}) {
    if (!configured()) { const e = new Error('APPRECIATE CLOUD is not configured.'); e.status = 503; throw e; }
    const headers = { authorization: `Bearer ${key}` };
    if (raw) headers['content-type'] = 'application/zip';
    else if (body !== undefined) headers['content-type'] = 'application/json';
    let response;
    try {
      response = await fetchImpl(`${base}${path}`, {
        method, headers, body: raw || (body === undefined ? undefined : JSON.stringify(body)),
        signal: AbortSignal.timeout(customTimeout || timeoutMs)
      });
    } catch (cause) {
      const e = new Error('APPRECIATE CLOUD could not be reached.'); e.status = 503; e.cause = cause; throw e;
    }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const e = new Error(data.error || `APPRECIATE CLOUD returned HTTP ${response.status}.`);
      e.status = response.status >= 500 ? 502 : response.status; e.providerStatus = response.status; throw e;
    }
    return data;
  }
  return {
    configured,
    status: () => request('/api/v1/status'),
    createRepository: (name) => request('/api/v1/repositories', { method: 'POST', body: { name } }),
    uploadSource: (name, archive) => request(`/api/v1/repositories/${encodeURIComponent(name)}/source`, { method: 'POST', raw: archive, timeoutMs: 120000 }),
    build: (repository, branch) => request('/api/v1/builds', { method: 'POST', body: { repository, branch }, timeoutMs: 20 * 60 * 1000 }),
    deploy: (name, image, containerPort = 3000) => request('/api/v1/deployments', { method: 'POST', body: { name, image, container_port: containerPort }, timeoutMs: 120000 })
  };
}
module.exports = { createCloudProvider };
