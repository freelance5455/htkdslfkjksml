'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createCloudProvider } = require('../cloud-provider');

test('cloud provider sends authenticated repository requests', async () => {
  const calls = [];
  const provider = createCloudProvider({ baseUrl: 'http://cloud:3100/', apiKey: 'secret', fetchImpl: async (url, options) => {
    calls.push({ url, options });
    return { ok: true, json: async () => ({ ok: true, repository: { name: 'p-123' } }) };
  } });
  const result = await provider.createRepository('p-123');
  assert.equal(result.repository.name, 'p-123');
  assert.equal(calls[0].url, 'http://cloud:3100/api/v1/repositories');
  assert.equal(calls[0].options.headers.authorization, 'Bearer secret');
  assert.deepEqual(JSON.parse(calls[0].options.body), { name: 'p-123' });
});

test('cloud provider sends ZIP bytes unchanged', async () => {
  const archive = Buffer.from('zip-bytes');
  let call;
  const provider = createCloudProvider({ baseUrl: 'http://cloud', apiKey: 'secret', fetchImpl: async (url, options) => {
    call = { url, options }; return { ok: true, json: async () => ({ ok: true, files: 2 }) };
  } });
  await provider.uploadSource('repo-1', archive);
  assert.equal(call.url, 'http://cloud/api/v1/repositories/repo-1/source');
  assert.equal(call.options.headers['content-type'], 'application/zip');
  assert.equal(call.options.body, archive);
});

test('cloud provider reports unavailable configuration without network calls', async () => {
  const provider = createCloudProvider({ baseUrl: '', apiKey: '' });
  assert.equal(provider.configured(), false);
  await assert.rejects(provider.status(), { status: 503 });
});

test('cloud provider maps upstream errors without leaking credentials', async () => {
  const provider = createCloudProvider({ baseUrl: 'http://cloud', apiKey: 'secret', fetchImpl: async () => ({ ok: false, status: 400, json: async () => ({ error: 'Dockerfile missing' }) }) });
  await assert.rejects(provider.build('repo-1', 'main'), (error) => error.status === 400 && error.message === 'Dockerfile missing');
});
