# V51 — Excel Buttons Robust Android Fix

Built from V50.

## Fixed
- Choose File uses `ACTION_GET_CONTENT` with `ACTION_OPEN_DOCUMENT` fallback.
- WebView file chooser and custom native importer remain separate.
- MIME hints are supplied without requiring persistable URI permissions.
- If the Android bridge is unavailable or fails, Choose File falls back to the HTML file input.
- Download Excel template reports success/failure in the import dialog.
- If direct Android Downloads saving fails, the app falls back to the system Save dialog.
- Existing native XLSX/CSV parsing, preview, Supabase import, login, balance, banked entries, and other features are preserved.

## Version
- Android versionCode 23
- Android versionName 2.19

This package is the new baseline for future updates.
