/**
 * AWS Lambda Function: Tiffin Tracker Cloud API
 * Runtime: Node.js 20.x
 * Handler: index.handler
 * 
 * Provides secure serverless backend for Maa Annapurna Tiffin Service.
 * Partitioned by Cognito User ID (sub) in AWS DynamoDB.
 */

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

const REGION = process.env.AWS_REGION || process.env.REGION || 'ap-south-1';
const TABLE_NAME = process.env.TABLE_NAME || 'TiffinTrackerData';

const ddbClient = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(ddbClient);

// CORS Headers required for cross-origin web browser invocations
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS',
  'Content-Type': 'application/json'
};

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  // Determine HTTP Method
  const httpMethod = event.httpMethod || event.requestContext?.http?.method || 'GET';

  // Handle CORS Preflight OPTIONS Request
  if (httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: 'CORS Preflight OK' })
    };
  }

  try {
    // 1. Securely Extract User ID from Cognito Authorizer Claims
    // Supports both HTTP API (JWT Authorizer) and REST API (Cognito Authorizer)
    let userId = null;

    if (event.requestContext?.authorizer?.jwt?.claims?.sub) {
      // HTTP API with JWT authorizer
      userId = event.requestContext.authorizer.jwt.claims.sub;
    } else if (event.requestContext?.authorizer?.claims?.sub) {
      // REST API with Cognito User Pools authorizer
      userId = event.requestContext.authorizer.claims.sub;
    } else if (event.headers?.Authorization || event.headers?.authorization) {
      // Fallback: Parse sub claim directly from Bearer JWT payload
      const authHeader = event.headers.Authorization || event.headers.authorization;
      const token = authHeader.replace(/^Bearer\s+/i, '');
      try {
        const parts = token.split('.');
        if (parts.length === 3) {
          const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf8'));
          userId = payload.sub || payload['cognito:username'];
        }
      } catch (e) {
        console.warn('Could not extract sub from JWT token:', e.message);
      }
    }

    // Direct parameter fallback for testing in AWS Console
    if (!userId && event.queryStringParameters?.userId) {
      userId = event.queryStringParameters.userId;
    }

    if (!userId && event.body) {
      try {
        const parsed = JSON.parse(event.body);
        if (parsed.userId) userId = parsed.userId;
      } catch {}
    }

    if (!userId) {
      return {
        statusCode: 401,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: 'Unauthorized',
          message: 'Missing or invalid Cognito User ID in authorization header'
        })
      };
    }

    console.log(`Processing request for Partition Key userId: ${userId}`);

    // 2. Process GET Request -> Load User's Tiffin Data
    if (httpMethod === 'GET') {
      const getCmd = new GetCommand({
        TableName: TABLE_NAME,
        Key: { userId }
      });

      const result = await docClient.send(getCmd);

      if (!result.Item) {
        // Return blank/starter state if user is accessing for the first time
        return {
          statusCode: 200,
          headers: CORS_HEADERS,
          body: JSON.stringify({
            message: 'First time user login, initialized clean partition',
            item: null
          })
        };
      }

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          message: 'Data loaded successfully from DynamoDB',
          item: result.Item
        })
      };
    }

    // 3. Process POST / PUT Request -> Save User's Tiffin Data
    if (httpMethod === 'POST' || httpMethod === 'PUT') {
      let bodyData = {};
      try {
        bodyData = typeof event.body === 'string' ? JSON.parse(event.body) : (event.body || {});
      } catch (parseErr) {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid JSON body in request' })
        };
      }

      const itemToSave = {
        userId: userId, // Primary Partition Key
        updatedAt: new Date().toISOString(),
        clients: Array.isArray(bodyData.clients) ? bodyData.clients : [],
        logs: Array.isArray(bodyData.logs) ? bodyData.logs : [],
        boxStates: bodyData.boxStates || {},
        settings: bodyData.settings || {},
        weeklyMenu: bodyData.weeklyMenu || {},
        customMenus: Array.isArray(bodyData.customMenus) ? bodyData.customMenus : [],
        extraItemsCatalog: Array.isArray(bodyData.extraItemsCatalog) ? bodyData.extraItemsCatalog : [],
        qrDatabase: Array.isArray(bodyData.qrDatabase) ? bodyData.qrDatabase : []
      };

      const putCmd = new PutCommand({
        TableName: TABLE_NAME,
        Item: itemToSave
      });

      await docClient.send(putCmd);

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          message: 'User business data securely stored in AWS DynamoDB',
          updatedAt: itemToSave.updatedAt,
          userId: userId
        })
      };
    }

    // Unsupported HTTP Method
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };

  } catch (error) {
    console.error('Lambda Execution Error:', error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        error: 'Internal Server Error',
        message: error.message
      })
    };
  }
};
