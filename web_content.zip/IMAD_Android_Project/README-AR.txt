IMAD Android project — v1.0

هذا مشروع Android Studio أولي لتغليف واجهة IMAD المحلية داخل تطبيق Android (WebView).
لا يحتوي على خدمات إنترنت ولا صلاحية INTERNET. بيانات الواجهة مخزنة في WebView localStorage.

كيفية إخراج APK:
1. نزّل وثبّت Android Studio من الموقع الرسمي على حاسوب.
2. فك الضغط عن IMAD_Android_Project.zip.
3. من Android Studio اختر Open ثم اختر مجلد IMAD_Android_Project.
4. وافق على تثبيت/مزامنة Gradle إذا طلب البرنامج ذلك، وتأكد أن Android SDK Platform 35 مثبت.
5. من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6. عند النجاح اضغط Locate من إشعار Android Studio للحصول على app-debug.apk.
7. انقل app-debug.apk إلى هاتفك وثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر.

مهم:
- هذه حزمة مصدر Android وليست APK مبنية.
- يلزم Android Studio وAndroid SDK لبناء APK؛ هذه البيئة لم يتوفر فيها Android SDK/Gradle لإخراج APK مباشرة.
- اختبر النسخة وصدّر نسخة احتياطية قبل إدخال معلومات مهمة.
- رمز PIN الحالي حاجز واجهة وليس تشفيراً قوياً للبيانات المحلية.
- إذا مسحت بيانات التطبيق أو حذفته، قد تفقد بياناته؛ احتفظ بملف JSON الاحتياطي خارج التطبيق.
