/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : IG-2-1-1 */
registerLessonDetail(1, 2, "ig-2-1-1", {
  title: "Leçon 1 : Algèbre de Boole, Portes logiques et Circuits Additionneurs",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Comprendre le passage de la logique mathématique de George Boole aux circuits électroniques (thèse de Claude Shannon).",
    "Maîtriser les 6 portes logiques (NOT, AND, OR, NAND, NOR, XOR) et l'universalité de NAND.",
    "Appliquer toutes les lois de l'algèbre de Boole, y compris les deux Lois de De Morgan.",
    "Comprendre comment un processeur additionne deux bits physiquement grâce au Demi-Additionneur."
  ],
  prerequisites: ["Niveau 1 d'Informatique générale (système binaire et bits)."],
  sections: [
    {
      type: "theory",
      title: "1. De la philosophie de Boole au mémoire légendaire de Shannon",
      text: "En 1854, le mathématicien britannique George Boole publie « An Investigation of the Laws of Thought ». Il y démontre que le raisonnement logique peut s'écrire sous forme d'équations algébriques avec seulement deux valeurs : VRAI (1) et FAUX (0).\n\nPendant 80 ans, ces travaux restent purement théoriques. Mais en 1937, Claude Shannon (étudiant de 21 ans au MIT) prouve dans son mémoire de master que des interrupteurs montés en série correspondent exactement au « ET » logique, et montés en parallèle au « OU » logique. L'électronique numérique et l'architecture des processeurs venaient de naître."
    },
    {
      type: "definition",
      term: "Variables et Opérateurs Booléens",
      text: "Une variable booléenne (A, B, C...) vaut uniquement 0 (FAUX) ou 1 (VRAI). Les trois opérations de base sont :\n• Négation (NON / NOT) : notée Ā. Inverse l'état (0→1, 1→0).\n• Conjonction (ET / AND) : notée A · B. Vaut 1 uniquement si A=1 ET B=1.\n• Disjonction (OU / OR) : notée A + B. Vaut 1 dès qu'au moins l'un des deux vaut 1."
    },
    {
      type: "table",
      title: "2. Tables de vérité des portes logiques majeures",
      headers: ["A", "B", "AND (A·B)", "OR (A+B)", "XOR (A⊕B)", "NAND", "NOR"],
      rows: [
        ["0", "0", "0", "0", "0", "1", "1"],
        ["0", "1", "0", "1", "1", "1", "0"],
        ["1", "0", "0", "1", "1", "1", "0"],
        ["1", "1", "1", "1", "0", "0", "0"]
      ]
    },
    {
      type: "theory",
      title: "3. L'universalité des portes NAND et NOR",
      text: "Les portes NAND (NON-ET) et NOR (NON-OU) sont l'inverse exact de AND et OR. Fait industriel majeur : la porte NAND est dite « universelle ». En assemblant uniquement des portes NAND, un ingénieur peut recréer NOT, AND, OR, XOR et bâtir un processeur complet ! En électronique CMOS, une porte NAND coûte moins de transistors qu'une porte AND, d'où le nom des mémoires « NAND Flash » dans vos smartphones."
    },
    {
      type: "theory",
      title: "4. Propriétés algébriques et Lois de De Morgan",
      text: "Pour réduire le nombre de transistors d'une puce (et donc économiser la batterie et éviter la surchauffe), on simplifie les équations logiques grâce aux lois suivantes :",
      bullets: [
        "Identité : A + 0 = A   |   A · 1 = A",
        "Élément absorbant : A + 1 = 1   |   A · 0 = 0",
        "Idempotence (propre au booléen) : A + A = A   |   A · A = A",
        "Complémentarité : A + Ā = 1   |   A · Ā = 0",
        "Double négation : NON(NON A) = A",
        "Distributivité double : A + (B · C) = (A + B) · (A + C)",
        "1re Loi de De Morgan : NON(A · B) = Ā + B̄  (la barre cassée change · en +)",
        "2e Loi de De Morgan : NON(A + B) = Ā · B̄  (la barre cassée change + en ·)"
      ]
    },
    {
      type: "code",
      lang: "Circuit : Comment l'UAL additionne 2 bits (Demi-Additionneur)",
      code: [
        "Objectif : Calculer A + B pour obtenir Somme (S) et Retenue (C = Carry).",
        "  0 + 0 = 0  (S=0, C=0)",
        "  0 + 1 = 1  (S=1, C=0)",
        "  1 + 0 = 1  (S=1, C=0)",
        "  1 + 1 = 10 en binaire → S=0, Retenue C=1 !",
        "",
        "Observation dans la table de vérité :",
        "  - S vaut 1 quand A et B diffèrent → S = A XOR B",
        "  - C vaut 1 quand A=1 ET B=1      → C = A AND B",
        "",
        "Schéma du Demi-Additionneur (Half Adder) :",
        "  A ──┬────────────► [ XOR ] ──► S (Somme)",
        "      │  ┌─────────► [     ]",
        "  B ──┼──┘",
        "      └──► [ AND ] ──► C (Retenue)",
        "  A ─────► [     ]",
        "",
        "En reliant 64 Additionneurs en cascade, on obtient l'additionneur 64 bits du CPU !"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter",
      text: "1) Ne confondez jamais le '+' booléen (OU logique : 1 + 1 = 1) avec le '+' arithmétique (1 + 1 = 10 en binaire).\n2) En appliquant De Morgan sur NON(A · B), n'oubliez pas de transformer le ET (·) en OU (+).\n3) En programmation (C, Java, JS), distinguez && / || (conditions if) de & / | / ^ (opérations bit-à-bit sur les octets)."
    },
    {
      type: "example",
      title: "Application directe en Programmation",
      text: "En code, les lois de De Morgan rendent les conditions beaucoup plus lisibles : « if (!(age >= 18 && inscrit == true)) » devient immédiatement par De Morgan : « if (age < 18 || inscrit == false) » (« si mineur OU non inscrit »)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Simplification algébrique pas à pas",
      question: "Simplifiez au maximum en justifiant chaque étape :\n1) F = A + (A · B)\n2) G = (A · B) + (A · B̄)\n3) H = NON( (NON A) + B )",
      solution: "1) F = A · (1 + B) = A · 1 = A (Loi d'absorption).\n2) G = A · (B + B̄) = A · 1 = A (Complémentarité).\n3) Par De Morgan : H = NON(NON A) · (NON B) = A · B̄."
    },
    {
      title: "Exercice 2 — Contrôle d'accès salle serveurs JOSTECH",
      question: "La porte s'ouvre (S = 1) si badge admin valide (B = 1) ET PIN exact (C = 1), OU si clé d'urgence tournée (U = 1), mais JAMAIS s'il y a verrouillage incendie (V = 1).\nÉcrivez l'équation booléenne de S.",
      solution: "Condition d'ouverture : (B · C) + U.\nBlocage incendie exige V = 0 (soit V̄ = 1).\nÉquation finale : S = ((B · C) + U) · V̄."
    },
    {
      title: "Exercice 3 — Chiffrement XOR",
      question: "Avec la propriété (M ⊕ K) ⊕ K = M, chiffrez M = 1011 avec la clé K = 0110 (C = M ⊕ K), puis déchiffrez C ⊕ K.",
      solution: "1) C = 1011 ⊕ 0110 = 1101.\n2) C ⊕ K = 1101 ⊕ 0110 = 1011 = M retrouvé !"
    }
  ],
  summary: "L'algèbre de Boole gouverne les circuits électroniques et la logique logicielle. La porte NAND est universelle, l'additionneur binaire repose sur XOR + AND, et les lois de De Morgan simplifient aussi bien les puces que nos programmes.",
  references: [
    "Boole, G. (1854) — An Investigation of the Laws of Thought.",
    "Shannon, C. E. (1938) — A Symbolic Analysis of Relay and Switching Circuits.",
    "Tanenbaum, A. S. — Architecture de l'ordinateur, Pearson."
  ]
});