package com.monee.personal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final int REQUEST_OPEN_BACKUP = 1001;
    private static final int REQUEST_SAVE_BACKUP = 1002;
    private static final long MIN_NATIVE_SPLASH_MS = 900L;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupContent;
    private FrameLayout root;
    private View nativeSplash;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private long nativeSplashStartedAt;
    private boolean appReady = false;
    private boolean nativeSplashClosing = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_Monee);
        super.onCreate(savedInstanceState);

        nativeSplashStartedAt = android.os.SystemClock.uptimeMillis();
        setSplashSystemBars();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244, 251, 249));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 251, 249));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        nativeSplash = createNativeSplash();
        root.addView(nativeSplash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallbackParam,
                    FileChooserParams fileChooserParams
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackParam;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try {
                    startActivityForResult(intent, REQUEST_OPEN_BACKUP);
                    return true;
                } catch (Exception ex) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "ไม่สามารถเปิดตัวเลือกไฟล์ได้", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }

        // Safety fallback: never leave the native splash stuck forever.
        mainHandler.postDelayed(() -> { appReady = true; hideNativeSplashWhenReady(); }, 6000L);
    }

    private View createNativeSplash() {
        ImageView image = new ImageView(this);
        image.setBackgroundColor(Color.rgb(246, 255, 252));
        image.setImageResource(R.drawable.monee_splash_native);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setAdjustViewBounds(false);
        image.setContentDescription("Monee กำลังเตรียมข้อมูล");
        image.setAlpha(1f);
        return image;
    }

    private void setSplashSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(16, 185, 130));
        window.setNavigationBarColor(Color.rgb(50, 50, 52));
        window.getDecorView().setSystemUiVisibility(0);
    }

    private void setAppSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(244, 251, 249));
        window.setNavigationBarColor(Color.rgb(244, 251, 249));
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );
    }

    private void hideNativeSplashWhenReady() {
        if (nativeSplash == null || nativeSplashClosing) return;
        if (!appReady) return;

        long elapsed = android.os.SystemClock.uptimeMillis() - nativeSplashStartedAt;
        long wait = Math.max(0L, MIN_NATIVE_SPLASH_MS - elapsed);
        nativeSplashClosing = true;

        mainHandler.postDelayed(() -> {
            if (nativeSplash == null) return;
            nativeSplash.animate()
                    .alpha(0f)
                    .setDuration(220L)
                    .withEndAction(() -> {
                        if (root != null && nativeSplash != null) {
                            root.removeView(nativeSplash);
                        }
                        nativeSplash = null;
                        setAppSystemBars();
                    })
                    .start();
        }, wait);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OPEN_BACKUP) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }

        if (requestCode == REQUEST_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupContent != null) {
                Uri uri = data.getData();
                try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                    if (output != null) {
                        output.write(pendingBackupContent.getBytes(StandardCharsets.UTF_8));
                        output.flush();
                        Toast.makeText(this, "บันทึกไฟล์สำรองแล้ว", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ex) {
                    Toast.makeText(this, "บันทึกไฟล์สำรองไม่สำเร็จ", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupContent = null;
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript(
                "window.handleAndroidBack ? window.handleAndroidBack() : false",
                result -> {
                    if ("true".equals(result)) return;
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        MainActivity.super.onBackPressed();
                    }
                }
        );
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class AndroidBridge {

        @JavascriptInterface
        public void appReady() {
            runOnUiThread(() -> {
                appReady = true;
                hideNativeSplashWhenReady();
            });
        }

        @JavascriptInterface
        public void saveBackup(String content, String filename) {
            pendingBackupContent = content;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,
                        (filename == null || filename.trim().isEmpty())
                                ? "monee-backup.json"
                                : filename
                );
                try {
                    startActivityForResult(intent, REQUEST_SAVE_BACKUP);
                } catch (Exception ex) {
                    pendingBackupContent = null;
                    Toast.makeText(MainActivity.this, "ไม่สามารถเลือกตำแหน่งบันทึกได้", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
