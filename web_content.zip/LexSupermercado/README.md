# Sigma de Laboratório — Supermercado do Lex (Android)

Jogo 3D (WebGL) dentro de um app Android (WebView).

## Gerar o APK
1. Instale o **Android Studio** (qualquer versão recente).
2. *File → Open* e escolha esta pasta (`LexSupermercado`). Aguarde o Gradle sincronizar (precisa de internet na primeira vez).
3. *Build → Build Bundle(s) / APK(s) → Build APK(s)*.
4. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`. Mande para o celular e instale (permita "fontes desconhecidas").

Pela linha de comando: `./gradlew assembleDebug`

## Onde estão as coisas
- Jogo (código): `app/src/main/assets/www/index.html`
- Texturas (PNG 256x256): `app/src/main/assets/www/textures/`
- Texturas embutidas de reserva: `app/src/main/assets/www/textures.js`
- Activity Android: `app/src/main/java/com/lexgames/supermercado/MainActivity.java`

## Como jogar
- Arraste na tela para olhar ao redor.
- Toque em **COBRAR** quando o cliente chegar ao balcão.
- Depois de 3 clientes, o Lex aparece. Escolha: **ACEITAR** (ele leva a cesta e metade do caixa) ou **RECUSAR** (ele não gosta).

## Testar no navegador (sem Android)
Abra `app/src/main/assets/www/index.html` no Chrome (com `--allow-file-access-from-files`, ou sirva a pasta com `python3 -m http.server`).
