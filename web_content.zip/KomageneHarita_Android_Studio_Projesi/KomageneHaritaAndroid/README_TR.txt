KOMAGENE HARITA - ANDROID STUDIO PROJESI

Bu bir Android Studio kaynak projesidir; derlenmis APK degildir.

OZELLIKLER
- OpenStreetMap harita katmani (internet gerekir).
- Kayseri ve Sivas icin Overpass API uzerinden OSM'de "Komagene" adi/markasi olan kayitlari arar.
- Google Maps navigasyon baglantisi acar.
- Yapildi / geri al / sil / manuel sube ekleme.
- Yapildi durumu ve sube listesi cihazda localStorage ile saklanir.

ONEMLI
- OpenStreetMap'te bulunmayan Komagene subeleri otomatik cikmaz. OSM verisi eksik olabilir; elle ekleme var.
- Overpass servisleri ve OSM karo sunuculari internet ve servis politikalarina tabidir; kesintisiz hizmet garantisi yoktur.
- OpenStreetMap karo kaynagi uzerindeki kullanim kosullarina uyun; uygulamada atif gorunur.
- Veriler bu telefonda saklanir; baska telefonlarla ortak senkronizasyon yoktur.
- Google Maps uygulamasi kurulu degilse navigasyon linki tarayicida acilabilir.

APK OLUSTURMA
1. Bilgisayara Android Studio kur.
2. Bu ZIP'i cikart.
3. Android Studio > Open > KomageneHarita klasorunu sec.
4. Gradle sync tamamlaninca Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK genellikle app/build/outputs/apk/debug/app-debug.apk yolunda olusur.

Bu proje Android Studio/Gradle ile derlenmelidir. Bu ortamda Android SDK ile APK derlemesi yapilmamistir.
