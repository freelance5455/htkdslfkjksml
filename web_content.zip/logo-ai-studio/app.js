const palettes = {
  violet:{a:"#7357e8",b:"#42b7d5",c:"#17213d"},
  sunset:{a:"#ff765e",b:"#ffbd69",c:"#542f45"},
  forest:{a:"#2e8b70",b:"#b8d8a8",c:"#203c35"},
  mono:{a:"#20242e",b:"#8c929e",c:"#30343d"}
};
const names = ["Nova Orbit","Nova Form","Nova Signature"];
const styles = ["modern","minimal","luxury"];
let currentStyle="modern", currentPalette="violet", selected=0;
const $ = id => document.getElementById(id);
const nameInput=$("brandName"), taglineInput=$("tagline");
const safeText = s => (s || "").trim().slice(0,48);
function initials(name){const parts=safeText(name).split(/\s+/).filter(Boolean);return parts.length>1?parts.slice(0,2).map(x=>x[0]).join("").toUpperCase():(parts[0]||"NOVA").slice(0,1).toUpperCase();}
function symbols(style,industry){
  const industrySymbols={tech:["✦","◈","⌘"],food:["✿","◉","❋"],fashion:["✧","◇","A"],fitness:["✦","◈","↗"],creative:["✳","◉","✧"],nature:["❋","◈","✿"]};
  const s=industrySymbols[industry]||industrySymbols.tech;
  return style==="luxury"?[initials(nameInput.value),s[1],"✧"]:style==="minimal"?[s[1],"◯",s[0]]:style==="playful"?[s[2],s[0],"✿"]:[s[0],s[1],s[2]];
}
function updateColors(){
 const p=palettes[currentPalette];document.documentElement.style.setProperty("--a",p.a);document.documentElement.style.setProperty("--b",p.b);document.documentElement.style.setProperty("--c",p.c);
}
function render(){
 const brand=safeText(nameInput.value)||"YOUR BRAND", tagline=safeText(taglineInput.value).toUpperCase();
 const industry=$("industry").value, syms=symbols(currentStyle,industry);
 const variants=[currentStyle,currentStyle==="modern"?"minimal":"modern","luxury"];
 const cards=[...document.querySelectorAll(".logo-card")];
 cards.forEach((card,i)=>{
   const st=variants[i], sym=syms[i];
   const logo=card.querySelector(".generated-logo");
   logo.className="generated-logo logo-"+st;
   logo.querySelector(".symbol").textContent=sym;
   logo.querySelector(".wordmark").textContent=brand.toUpperCase();
   logo.querySelector(".tagline-preview").textContent=tagline;
   card.querySelector(".card-bottom strong").textContent=names[i].replace("Nova",brand);
   card.classList.toggle("chosen",i===selected);
   card.querySelector(".select-btn").textContent=i===selected?"محدد ✓":"اختيار";
   card.querySelector(".card-bottom span").textContent=[st==="modern"?"عصري · هندسي":st==="minimal"?"بسيط · واضح":"فاخر · أنيق"][0];
 });
 const chosen=cards[selected], logo=chosen.querySelector(".generated-logo");
 $("selectedName").textContent=chosen.querySelector(".card-bottom strong").textContent;
 $("mockName").textContent=brand.toUpperCase();$("appName").textContent=brand.toUpperCase();$("socialName").textContent=brand.toUpperCase();
 $("mockTagline").textContent=tagline;$("appIcon").textContent=logo.querySelector(".symbol").textContent;
 document.querySelector(".mock-symbol").textContent=logo.querySelector(".symbol").textContent;
 document.querySelector(".social-symbol").textContent=logo.querySelector(".symbol").textContent;
 $("resultCount").textContent="3 أفكار جاهزة";
}
function showToast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove("show"),2400);}
document.querySelectorAll(".style-option").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".style-option").forEach(x=>x.classList.remove("selected"));btn.classList.add("selected");currentStyle=btn.dataset.style;render();}));
document.querySelectorAll(".palette").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".palette").forEach(x=>x.classList.remove("selected"));btn.classList.add("selected");currentPalette=btn.dataset.palette;updateColors();render();}));
[nameInput,taglineInput,$("industry")].forEach(el=>el.addEventListener("input",render));
document.querySelectorAll(".logo-card").forEach(card=>card.addEventListener("click",()=>{selected=Number(card.dataset.variant);render();}));
$("generateBtn").addEventListener("click",()=>{if(!safeText(nameInput.value)){showToast("أدخل اسم العلامة أولاً.");nameInput.focus();return;}selected=0;render();showToast("تم إنشاء 3 أفكار أولية جديدة.");});
function makeSvg(){
 const brand=safeText(nameInput.value)||"YOUR BRAND", tagline=safeText(taglineInput.value).toUpperCase();
 const p=palettes[currentPalette], card=document.querySelectorAll(".logo-card")[selected], symbol=card.querySelector(".symbol").textContent, style=card.querySelector(".generated-logo").classList.contains("logo-luxury")?"Georgia":"Arial";
 const escaped=s=>s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c]));
 const symbolSize=symbol.length>1?76:90;
 return `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="700" viewBox="0 0 1000 700"><rect width="1000" height="700" fill="#ffffff"/><g text-anchor="middle"><text x="500" y="285" font-family="${style}" font-size="${symbolSize}" font-weight="700" fill="${p.a}">${escaped(symbol)}</text><text x="500" y="405" font-family="Arial,sans-serif" font-size="94" font-weight="800" letter-spacing="13" fill="${p.c}">${escaped(brand.toUpperCase())}</text><text x="500" y="470" font-family="Arial,sans-serif" font-size="25" letter-spacing="6" fill="#9699a6">${escaped(tagline)}</text></g></svg>`;
}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);}
$("downloadSvg").addEventListener("click",()=>{download(new Blob([makeSvg()],{type:"image/svg+xml;charset=utf-8"}),"logo-design.svg");showToast("تم تجهيز ملف SVG.");});
$("downloadPng").addEventListener("click",()=>{const svg=makeSvg(),url=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml"})),img=new Image();img.onload=()=>{const canvas=document.createElement("canvas");canvas.width=2000;canvas.height=1400;const ctx=canvas.getContext("2d");ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);canvas.toBlob(blob=>download(blob,"logo-design.png"),"image/png");URL.revokeObjectURL(url);showToast("تم تجهيز ملف PNG.");};img.onerror=()=>showToast("تعذر تصدير الصورة في هذا المتصفح.");img.src=url;});
updateColors();render();