'use strict';
const $=s=>document.querySelector(s),V=$('#view');
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const opt=(a,s)=>a.map(([k,t])=>`<option value="${esc(k)}"${String(s)===String(k)?' selected':''}>${esc(t)}</option>`).join('');
let U=null,CSRF='',LK=null;
const G={Male:'نارینه',Female:'ښځینه'},ST={Active:'فعال',Promoted:'لوړ شوی',Repeated:'تکراري',Graduated:'فارغ',Transferred:'لېږدول شوی',Dropped:'پرېښی'},
EX={Monthly:'میاشتنۍ',FourMonth:'څلورمیاشتنۍ',Midterm:'نیمه‌کلنۍ',Final:'کلنۍ'},RL={Admin:'مدیر سیسټم',Teacher:'ښوونکی',Staff:'کارمند'},AT={P:'حاضر',A:'غایب',L:'ناوخته',E:'رخصتي'};
const can=p=>!p||U.perms.includes(p),MT={Cash:'نغدي',Bank:'بانک',Mobile:'موبایل'},HS={Admission:'شمولیت',Enrollment:'ثبت‌نام',Promotion:'لوړېدنه',Transfer:'انتقال',Graduation:'فراغت',Deactivation:'غیرفعال کېدل',Reactivation:'بیا فعالېدل',Other:'نور'},LV={Pending:'په انتظار',Approved:'منل شوی',Rejected:'رد شوی'},
AUD={All:'ټول',Students:'زده‌کوونکي',Teachers:'ښوونکي',Parents:'والدین',Staff:'کارکوونکي'},DAYS=['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'],
tdy=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10),
segs=(n,c)=>Object.keys(AT).map(s=>`<label class="s${s}"><input type="radio" name="${n}" value="${s}"${c==s?' checked':''}><span>${AT[s]}</span></label>`).join(''),
av=(p,n,c='')=>/^(uploads\/|data:image\/)/.test(p||'')?`<img class="av ${c}" src="${esc(p)}" alt="">`:`<div class="av ph ${c}">${esc((n||'?')[0])}</div>`,yn=v=>+v?'هو':'نه',cy=()=>(LK.years.find(y=>+y.IsCurrent)||{}).id;
const OP={gender:()=>Object.entries(G),status:()=>Object.entries(ST),exam:()=>Object.entries(EX),role:()=>Object.entries(RL),
classes:()=>LK.classes.map(c=>[c.id,c.Grade+' - '+c.Section]),years:()=>LK.years.map(y=>[y.id,y.YearName]),
subjects:()=>LK.subjects.map(s=>[s.id,s.SubjectName]),teachers:()=>LK.teachers.map(t=>[t.id,t.FullName]),
students:()=>LK.students.map(s=>[s.id,s.name]),exams:()=>LK.exams.map(e=>[e.id,e.ExamName]),
feetypes:()=>(LK.feetypes||[]).map(x=>[x.id,x.FeeName]),expcats:()=>(LK.expcats||[]).map(x=>[x.id,x.CategoryName]),books:()=>LK.books.map(x=>[x.id,x.Title]),
employees:()=>(LK.employees||[]).map(x=>[x.id,x.FullName]),roles:()=>(LK.roles||[]).map(x=>[x.id,x.RoleName]),fees:()=>(LK.fees||[]).map(x=>[x.id,x.name]),enr:()=>(LK.enr||[]).map(x=>[x.id,x.name]),method:()=>Object.entries(MT),hstatus:()=>Object.entries(HS),days:()=>DAYS.map((d,i)=>[i,d]),audience:()=>Object.entries(AUD),grades12:()=>Array.from({length:12},(_,i)=>[i+1,String(i+1)]),lstatus:()=>Object.entries(LV)};
const f=(n,l,o={})=>({n,l,t:'text',...o});

async function api(a,{params={},body=null}={}){
 const o={credentials:'same-origin',headers:{}};
 if(body!==null){o.method='POST';o.headers['Content-Type']='application/json';o.headers['X-CSRF-Token']=CSRF;o.body=JSON.stringify(body)}
 let r;try{r=await fetch('api.php?'+new URLSearchParams({action:a,...params}),o)}catch{throw new Error('د سرور سره اړیکه نشته')}
 let d={};try{d=await r.json()}catch{}
 if(r.status==401&&a!='login'){showLogin();throw new Error(d.error||'بیا ننوځئ')}
 if(!r.ok)throw new Error(d.error||'تېروتنه');return d}
async function apiUpload(ent,id,file){const fd=new FormData();fd.append('entity',ent);fd.append('id',id);fd.append('file',file,file.name||'photo.jpg');const r=await fetch('api.php?action=upload',{method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':CSRF},body:fd});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'تېروتنه');return d}
function toast(m,e){const dl=[...document.querySelectorAll('dialog[open]')].pop();if(dl&&e){let b=dl.querySelector('.ferr');if(!b){b=document.createElement('div');b.className='ferr';dl.prepend(b)}b.textContent=m}const t=$('#toast');t.textContent=m;t.className='show'+(e?' err':'');clearTimeout(toast.t);toast.t=setTimeout(()=>t.className='',3500)}
const act=async(fn,done)=>{try{await fn();toast('ترسره شو');if(done)await done()}catch(x){toast(x.message,1)}};
const lk=async()=>LK=await api('lookups');

const ENT={
students:{t:'زده‌کوونکي',id:'StudentID',w:'AS',q:1,c:[['FirstName','نوم'],['FatherName','د پلار نوم'],['GrandfatherName','د نیکه نوم'],['Gender','جنسیت',v=>G[v]],['Phone','تلیفون'],['IsActive','فعال',yn]],
 fd:[f('FirstName','نوم',{req:1}),f('FatherName','د پلار نوم',{req:1}),f('GrandfatherName','د نیکه نوم'),f('Gender','جنسیت',{t:'select',o:'gender',req:1}),f('BirthDate','د زېږېدو نېټه',{t:'date'}),f('Phone','تلیفون'),f('Address','پته'),f('GuardianName','د سرپرست نوم'),f('GuardianPhone','د سرپرست تلیفون'),f('AdmissionDate','د شمولیت نېټه',{t:'date'}),f('FatherOccupation','د پلار مسلک'),f('FatherPhone','د پلار تلیفون'),f('PermanentAddress','تړلې پته'),f('IsActive','فعال',{t:'check',def:1})]},
teachers:{t:'ښوونکي',id:'TeacherID',w:'AS',q:1,c:[['FullName','نوم'],['Specialty','تخصص'],['Phone','تلیفون'],['HireDate','د دندې نېټه'],['IsActive','فعال',yn]],
 fd:[f('FullName','نوم',{req:1}),f('FatherName','د پلار نوم'),f('Gender','جنسیت',{t:'select',o:'gender'}),f('Specialty','تخصص'),f('Education','تحصیل'),f('Phone','تلیفون'),f('Address','پته'),f('HireDate','د دندې نېټه',{t:'date'}),f('BaseSalary','اصلي معاش',{t:'number'}),f('IsActive','فعال',{t:'check',def:1})]},
classes:{t:'ټولګي',id:'ClassID',w:'AS',c:[['Grade','ټولګی'],['Section','څانګه'],['HomeroomName','د ټولګي ښوونکی']],
 fd:[f('Grade','ټولګی (1 تر 12)',{t:'select',o:'grades12',req:1}),f('Section','څانګه (یوه یا څو، په کوما جلا کړئ: الف، ب، ج)',{req:1}),f('HomeroomTeacherID','د ټولګي ښوونکی',{t:'select',o:'teachers'})]},
subjects:{t:'مضمونونه',id:'SubjectID',w:'AS',q:1,c:[['SubjectName','مضمون'],['WeeklyHours','اونیز ساعتونه']],
 fd:[f('SubjectName','مضمون',{req:1}),f('WeeklyHours','اونیز ساعتونه',{t:'number'})]},
years:{t:'تعلیمي کال',id:'YearID',w:'AS',c:[['YearName','کال'],['StartDate','پیل'],['EndDate','پای'],['IsCurrent','اوسنی',yn]],
 fd:[f('YearName','کال (لکه 1405)',{req:1}),f('StartDate','د پیل نېټه',{t:'date',req:1}),f('EndDate','د پای نېټه',{t:'date',req:1}),f('IsCurrent','اوسنی کال',{t:'check'})]},
enrollments:{t:'ثبت‌نام',id:'EnrollmentID',w:'AS',q:1,fl:[['ClassID','ټولګی','classes'],['YearID','کال','years']],
 c:[['StudentName','زده‌کوونکی'],['Grade','ټولګی'],['Section','څانګه'],['YearName','کال'],['Status','حالت',v=>ST[v]]],
 fd:[f('StudentID','زده‌کوونکی',{t:'select',o:'students',req:1}),f('ClassID','ټولګی',{t:'select',o:'classes',req:1}),f('YearID','کال',{t:'select',o:'years',req:1,def:cy}),f('EnrollDate','د ثبت نېټه',{t:'date'}),f('Status','حالت',{t:'select',o:'status',def:'Active'})]},
assign:{t:'د مضمون ویش',id:'AssignmentID',w:'AS',q:1,fl:[['ClassID','ټولګی','classes'],['YearID','کال','years']],
 c:[['FullName','ښوونکی'],['SubjectName','مضمون'],['Grade','ټولګی'],['Section','څانګه'],['YearName','کال']],
 fd:[f('TeacherID','ښوونکی',{t:'select',o:'teachers',req:1}),f('SubjectID','مضمون',{t:'select',o:'subjects',req:1}),f('ClassID','ټولګی',{t:'select',o:'classes',req:1}),f('YearID','کال',{t:'select',o:'years',req:1,def:cy})]},
exams:{t:'ازموینې',id:'ExamID',w:'AS',q:1,fl:[['YearID','کال','years']],c:[['ExamName','نوم'],['ExamType','ډول',v=>EX[v]],['YearName','کال'],['ExamDate','نېټه'],['MaxScore','اعظمي نمره'],['PassMark','حد %']],
 fd:[f('ExamName','د ازموینې نوم',{req:1}),f('ExamType','ډول',{t:'select',o:'exam',req:1}),f('YearID','کال',{t:'select',o:'years',req:1,def:cy}),f('ExamDate','نېټه',{t:'date'}),f('MaxScore','اعظمي نمره',{t:'number',def:100}),f('PassMark','د بریالیتوب حد (%)',{t:'number',def:40})]},
users:{t:'کاروونکي',id:'UserID',q:1,c:[['Username','کارن نوم'],['FullName','نوم'],['RoleName','رول'],['IsActive','فعال',yn]],
 fd:[f('Username','کارن نوم',{req:1}),f('FullName','بشپړ نوم'),f('Password','پاسورډ (لږ تر لږه ۸ توري؛ په سمون کې خالي پرېږدئ)',{t:'password'}),f('RoleID','رول',{t:'select',o:'roles',req:1}),f('TeacherID','ښوونکی (که اړوند وي)',{t:'select',o:'teachers'}),f('IsActive','فعال',{t:'check',def:1})]},
guardians:{t:'والدین',id:'GuardianID',q:1,c:[['StudentName','زده‌کوونکی'],['FullName','سرپرست'],['Relation','اړیکه'],['Phone','تلیفون'],['IsPrimary','اصلي',yn]],
 fd:[f('StudentID','زده‌کوونکی',{t:'select',o:'students',req:1}),f('FullName','سرپرست',{req:1}),f('Relation','اړیکه (پلار، تره...)'),f('Phone','تلیفون'),f('Address','پته'),f('IsPrimary','اصلي سرپرست',{t:'check',def:1})]},
employees:{t:'کارکوونکي',id:'EmployeeID',q:1,c:[['FullName','نوم'],['Position','دنده'],['Phone','تلیفون'],['BaseSalary','معاش'],['IsActive','فعال',yn]],
 fd:[f('FullName','نوم',{req:1}),f('FatherName','د پلار نوم'),f('Position','دنده'),f('Phone','تلیفون'),f('Address','پته'),f('HireDate','د دندې نېټه',{t:'date'}),f('BaseSalary','اصلي معاش',{t:'number'}),f('IsActive','فعال',{t:'check',def:1})]},
classsubjects:{t:'د ټولګي مضمونونه',id:'ClassSubjectID',q:1,fl:[['ClassID','ټولګی','classes']],c:[['Grade','ټولګی'],['Section','څانګه'],['SubjectName','مضمون']],
 fd:[f('ClassID','ټولګی',{t:'select',o:'classes',req:1}),f('SubjectID','مضمون',{t:'select',o:'subjects',req:1})]},
feetypes:{t:'د فیس ډولونه',id:'FeeTypeID',q:1,c:[['FeeName','نوم'],['DefaultAmount','معمولي اندازه']],fd:[f('FeeName','نوم',{req:1}),f('DefaultAmount','معمولي اندازه',{t:'number'})]},
studentfees:{t:'د زده‌کوونکو فیسونه',id:'StudentFeeID',q:1,fl:[['ClassID','ټولګی','classes'],['YearID','کال','years'],['FeeTypeID','د فیس ډول','feetypes']],
 c:[['StudentName','زده‌کوونکی'],['Grade','ټولګی'],['FeeName','فیس'],['Amount','اندازه'],['Paid','تادیه شوې'],['Bal','پاتې',(v,r)=>r.Amount-r.Paid]],
 fd:[f('EnrollmentID','زده‌کوونکی (ثبت‌نام)',{t:'select',o:'enr',req:1}),f('FeeTypeID','د فیس ډول',{t:'select',o:'feetypes',req:1}),f('Amount','اندازه',{t:'number',req:1}),f('DueDate','وروستۍ نېټه',{t:'date'}),f('Note','یادښت')],
 tb:[{l:'ټولګي ته فیس ورکول',fn:l=>form('feebulk',null,l)}]},
feebulk:{id:'x',sa:'fee_bulk',fd:[f('FeeTypeID','د فیس ډول',{t:'select',o:'feetypes',req:1}),f('ClassID','ټولګی',{t:'select',o:'classes',req:1}),f('YearID','کال',{t:'select',o:'years',req:1,def:cy}),f('Amount','اندازه',{t:'number',req:1}),f('DueDate','وروستۍ نېټه',{t:'date'})]},
payments:{t:'تادیات',id:'PaymentID',q:1,c:[['StudentName','زده‌کوونکی'],['FeeName','فیس'],['Amount','اندازه'],['PayDate','نېټه'],['Method','ډول',v=>MT[v]],['ReceiptNo','رسید']],
 fd:[f('StudentFeeID','فیس (پاتې بیلانس)',{t:'select',o:'fees',req:1}),f('Amount','اندازه',{t:'number',req:1}),f('PayDate','نېټه',{t:'date'}),f('Method','ډول',{t:'select',o:'method',def:'Cash'}),f('ReceiptNo','د رسید شمېره')]},
expcats:{t:'د لګښت ډولونه',id:'CategoryID',q:1,c:[['CategoryName','نوم']],fd:[f('CategoryName','نوم',{req:1})]},
expenses:{t:'لګښتونه',id:'ExpenseID',q:1,fl:[['CategoryID','ډول','expcats']],c:[['CategoryName','ډول'],['Amount','اندازه'],['ExpDate','نېټه'],['Description','تفصیل']],
 fd:[f('CategoryID','ډول',{t:'select',o:'expcats',req:1}),f('Amount','اندازه',{t:'number',req:1}),f('ExpDate','نېټه',{t:'date'}),f('Description','تفصیل')]},
salaries:{t:'معاشونه',id:'SalaryID',q:1,c:[['PersonName','نوم'],['PayMonth','میاشت'],['BaseAmount','اصلي'],['Bonus','بونس'],['Deduction','کسر'],['NetAmount','خالص'],['PayDate','نېټه']],
 fd:[f('TeacherID','ښوونکی',{t:'select',o:'teachers'}),f('EmployeeID','کارکوونکی (یا ښوونکی، یو وټاکئ)',{t:'select',o:'employees'}),f('PayMonth','میاشت (YYYY-MM)',{req:1}),f('BaseAmount','اصلي معاش',{t:'number',req:1}),f('Bonus','بونس',{t:'number',def:0}),f('Deduction','کسر',{t:'number',def:0}),f('PayDate','نېټه',{t:'date'}),f('Note','یادښت')]},
books:{t:'کتابونه',id:'BookID',q:1,c:[['Title','نوم'],['Author','لیکوال'],['Category','ډول'],['Copies','شمېر'],['Available','شته']],
 fd:[f('Title','د کتاب نوم',{req:1}),f('Author','لیکوال'),f('Category','ډول'),f('Copies','شمېر',{t:'number',def:1})]},
loans:{t:'د کتابونو امانت',id:'LoanID',q:1,c:[['Title','کتاب'],['Borrower','امانت اخیستونکی'],['LoanDate','نېټه'],['DueDate','وروستۍ نېټه'],['ReturnDate','بیرته']],
 fd:[f('BookID','کتاب',{t:'select',o:'books',req:1}),f('StudentID','زده‌کوونکی',{t:'select',o:'students'}),f('TeacherID','ښوونکی (یا زده‌کوونکی، یو وټاکئ)',{t:'select',o:'teachers'}),f('LoanDate','نېټه',{t:'date'}),f('DueDate','وروستۍ نېټه',{t:'date',req:1})],
 ra:[{l:'بیرته راغی',p:'loans.w',show:r=>!r.ReturnDate,fn:(r,l)=>act(()=>api('loan_return',{body:{id:r.LoanID}}),l)}]},
history:{t:'د زده‌کوونکو تاریخچه',id:'HistoryID',perm:'students',q:1,c:[['StudentName','زده‌کوونکی'],['EventType','پېښه',v=>HS[v]],['EventDate','نېټه'],['Note','یادښت']],
 fd:[f('StudentID','زده‌کوونکی',{t:'select',o:'students',req:1}),f('EventType','پېښه',{t:'select',o:'hstatus',req:1}),f('EventDate','نېټه',{t:'date'}),f('Note','یادښت')]},
tdocs:{t:'تحصیلي اسناد',id:'DocID',perm:'teachers',q:1,c:[['PersonName','ښوونکی'],['DocType','ډول'],['Title','سرلیک'],['IssuedBy','ورکوونکې اداره'],['IssueDate','نېټه']],
 fd:[f('TeacherID','ښوونکی',{t:'select',o:'teachers',req:1}),f('DocType','ډول (بکلوریا، لیسانس...)',{req:1}),f('Title','سرلیک',{req:1}),f('IssuedBy','ورکوونکې اداره'),f('IssueDate','نېټه',{t:'date'})]},
leaves:{t:'رخصتي',id:'LeaveID',q:1,c:[['PersonName','نوم'],['StartDate','له'],['EndDate','تر'],['Reason','دلیل'],['Status','حالت',v=>LV[v]]],
 fd:[f('TeacherID','ښوونکی',{t:'select',o:'teachers'}),f('EmployeeID','کارکوونکی (یا ښوونکی، یو وټاکئ)',{t:'select',o:'employees'}),f('StartDate','له',{t:'date',req:1}),f('EndDate','تر',{t:'date',req:1}),f('Reason','دلیل'),f('Status','حالت',{t:'select',o:'lstatus',def:'Pending'})]},
jobs:{t:'د دندو تاریخچه',id:'JobID',perm:'salaries',q:1,c:[['PersonName','نوم'],['Position','دنده'],['StartDate','له'],['EndDate','تر'],['Note','یادښت']],
 fd:[f('TeacherID','ښوونکی',{t:'select',o:'teachers'}),f('EmployeeID','کارکوونکی (یا ښوونکی، یو وټاکئ)',{t:'select',o:'employees'}),f('Position','دنده',{req:1}),f('StartDate','له',{t:'date',req:1}),f('EndDate','تر',{t:'date'}),f('Note','یادښت')]},
notices:{t:'خبرتیاوې',id:'NoticeID',q:1,c:[['Title','سرلیک'],['Audience','ګډونوال',v=>AUD[v]],['PublishDate','نېټه'],['ExpiresOn','تر'],['IsActive','فعال',yn]],
 fd:[f('Title','سرلیک',{req:1}),f('Body','متن'),f('Audience','ګډونوال',{t:'select',o:'audience',def:'All'}),f('PublishDate','د خپرېدو نېټه',{t:'date'}),f('ExpiresOn','د پای نېټه',{t:'date'}),f('IsActive','فعال',{t:'check',def:1})]},
sdocs:{t:'د زده‌کوونکو اسناد',id:'DocID',q:1,c:[['StudentName','زده‌کوونکی'],['DocType','ډول'],['Title','سرلیک'],['IssueDate','نېټه']],
 fd:[f('StudentID','زده‌کوونکی',{t:'select',o:'students',req:1}),f('DocType','ډول (تذکره، شهادتنامه...)',{req:1}),f('Title','سرلیک',{req:1}),f('IssueDate','نېټه',{t:'date'})]},
timetable:{t:'مهال‌وېش',id:'SlotID',c:[],fd:[f('YearID','کال',{t:'select',o:'years',req:1,def:cy}),f('ClassID','ټولګی',{t:'select',o:'classes',req:1}),f('DayOfWeek','ورځ',{t:'select',o:'days',req:1}),f('PeriodNo','د درس شمېره (1-12)',{t:'number',req:1}),f('SubjectID','مضمون',{t:'select',o:'subjects',req:1}),f('TeacherID','ښوونکی',{t:'select',o:'teachers'}),f('StartTime','پیل',{t:'time'}),f('EndTime','پای',{t:'time'}),f('Room','صنف/خونه')]},
payroll:{id:'x',sa:'payroll_run',fd:[f('month','میاشت (YYYY-MM)',{req:1})]},
roles:{t:'رولونه',id:'RoleID',c:[['RoleName','رول']],fd:[f('RoleName','رول',{req:1})],ra:[{l:'صلاحیتونه',p:'roles.r',show:r=>r.RoleID!=1,fn:r=>permDlg(r)}]},
audit:{t:'د بدلونونو ثبت',id:'LogID',q:1,ro:1,c:[['CreatedAt','وخت'],['Username','کاروونکی'],['Action','عمل'],['TableName','جدول'],['RecordID','ID'],['Detail','جزئیات',v=>(v||'').slice(0,50)]]}};

ENT.salaries.tb=[{l:'د میاشتې معاشونه جوړول',fn:l=>form('payroll',null,l)}];
const upl=(ent,p)=>[{l:'فایل پورته کول',p,fn:(r,l)=>photoDlg(ent,r.DocID,'',l,1)},{l:'لیدل',p:ent=='sdocs'?'sdocs.r':'teachers.r',show:r=>/^uploads\//.test(r.DocFile||''),fn:r=>window.open(r.DocFile,'_blank','noopener')}];
ENT.sdocs.ra=upl('sdocs','sdocs.w');ENT.tdocs.ra=upl('tdocs','teachers.w');
const prof=(k,kind,id)=>({l:'پروفایل',p:k+'.r',fn:r=>profile(kind,r[id])});
ENT.students.ra=[prof('students','student','StudentID')];ENT.teachers.ra=[prof('teachers','teacher','TeacherID')];ENT.employees.ra=[prof('employees','employee','EmployeeID')];
ENT.enrollments.ra=[{l:'کارنامه',p:'grades.r',fn:r=>cardPick(r.EnrollmentID)}];ENT.students.c.unshift(['StudentCode','نمبر']);ENT.students.c.unshift(['PhotoFile','عکس',(v,r)=>({h:av(v,r.FirstName)})]);
ENT.teachers.c.unshift(['PhotoFile','عکس',(v,r)=>({h:av(v,r.FullName)})]);ENT.employees.c.unshift(['PhotoFile','عکس',(v,r)=>({h:av(v,r.FullName)})]);ENT.users.c.unshift(['PhotoFile','عکس',(v,r)=>({h:av(v,r.Username)})]);
ENT.users.ra=[{l:'عکس بدلول',p:'users.w',fn:(r,l)=>photoDlg('users',r.UserID,r.PhotoFile,l)}];
function fld(x,r){const v=r&&r[x.n]!==undefined?r[x.n]:(typeof x.def=='function'?x.def():x.def),rq=x.req?'required':'';
 if(x.t=='check')return`<label class="ck"><input type="checkbox" name="${x.n}"${+v?' checked':''}> ${x.l}</label>`;
 if(x.t=='select')return`<label>${x.l}<select name="${x.n}" ${rq}><option value="">—</option>${opt(OP[x.o](),v)}</select></label>`;
 return`<label>${x.l}<input type="${x.t}" name="${x.n}" value="${x.t=='password'?'':esc(v)}" ${rq}${x.t=='number'?' step="any"':''}></label>`}
function form(k,row,done){const E=ENT[k],d=$('#dlg2');d.className='';
 d.innerHTML=`<form id="fm"><h3>${row&&row[E.id]!=null?'سمون':'نوی ریکارډ'}</h3>${E.fd.map(x=>fld(x,row)).join('')}<div class="bar"><button class="btn">ثبت</button><button type="button" class="btn gh" id="cx">بندول</button></div></form>`;
 d.showModal();$('#cx').onclick=()=>d.close();
 $('#fm').onsubmit=async ev=>{ev.preventDefault();const data={};
  E.fd.forEach(x=>{const el=ev.target.elements[x.n];data[x.n]=x.t=='check'?el.checked:el.value});
  if(k=='users'&&!data.Password)delete data.Password;
  await act(async()=>{if(k=='classes'&&!(row&&row[E.id]!=null)){const ss=String(data.Section||'').split(/[,،\s]+/).filter(Boolean),bad=[];if(!ss.length)throw new Error('څانګه ولیکئ');for(const sc of ss){try{await api('save',{params:{entity:k},body:{id:null,data:{...data,Section:sc}}})}catch(x){bad.push(sc)}}await lk();if(bad.length)throw new Error('دا څانګې مخکې شته یا ثبت نشوې: '+bad.join('، '))}else await(E.sa?api(E.sa,{body:data}):api('save',{params:{entity:k},body:{id:row?row[E.id]:null,data}}));d.close();await lk()},done)}}

async function crud(k){const E=ENT[k],cw=can((E.perm||k)+'.w')&&!E.ro;let q=window.__q||'',pg=1,fl={},rows=[],tm;window.__q='';
 V.innerHTML=`<div class="bar"><h2>${E.t}</h2>${cw&&E.fd&&!E.sa?'<button class="btn" id="add">+ نوی</button>':''}${cw?(E.tb||[]).map((t,i)=>`<button class="btn gh" data-t="${i}">${t.l}</button>`).join(''):''}</div><div class="bar">${E.q?'<input id="q" placeholder="لټون..." value="'+esc(window.__q||'')+'">':''}${(E.fl||[]).map(([n,l,o])=>`<select data-f="${n}"><option value="">${l}: ټول</option>${opt(OP[o]())}</select>`).join('')}</div><div id="ls"></div><div class="bar" id="pgr"></div>`;
 const load=async()=>{try{const d=await api('list',{params:{entity:k,q,page:pg,...fl}});rows=d.rows;
  $('#ls').innerHTML=rows.length?`<table class="tbl"><thead><tr>${E.c.map(c=>`<th>${c[1]}</th>`).join('')}<th></th></tr></thead><tbody>${rows.map((r,i)=>`<tr>${E.c.map(c=>`<td data-l="${c[1]}">${cell(c[2]?c[2](r[c[0]],r):r[c[0]])}</td>`).join('')}<td class="act">${(E.ra||[]).map((a,j)=>can(a.p)&&(!a.show||a.show(r))?`<button class="btn sm gh" data-r="${i}|${j}">${a.l}</button>`:'').join('')}${cw?`<button class="btn sm" data-e="${i}">سمول</button><button class="btn sm red" data-d="${i}">حذف</button>`:''}</td></tr>`).join('')}</tbody></table>`:'<p class="mut">هېڅ ریکارډ نشته</p>';
  const n=Math.ceil(d.total/25)||1;$('#pgr').innerHTML=`<button class="btn sm gh" id="pv" ${pg<2?'disabled':''}>مخکینی</button><span>${pg}/${n} (${d.total})</span><button class="btn sm gh" id="nx" ${pg>=n?'disabled':''}>بل</button>`}catch(x){toast(x.message,1)}};
 V.onclick=e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='add')form(k,null,load);else if(b.dataset.e)form(k,rows[b.dataset.e],load);
  else if(b.dataset.d){if(confirm('ډاډه یاست چې حذف یې کړئ؟'))act(async()=>{await api('delete',{params:{entity:k},body:{id:rows[b.dataset.d][E.id]}});await lk()},load)}
  else if(b.dataset.t)E.tb[b.dataset.t].fn(load);else if(b.dataset.r){const[i,j]=b.dataset.r.split('|');E.ra[j].fn(rows[i],load)}
  else if(b.id=='pv'){pg--;load()}else if(b.id=='nx'){pg++;load()}};
 V.oninput=e=>{if(e.target.id=='q'){q=e.target.value;pg=1;clearTimeout(tm);tm=setTimeout(load,300)}};
 V.onchange=e=>{const n=e.target.dataset.f;if(n){fl[n]=e.target.value;pg=1;load()}};
 load()}

const pick=(extra='')=>`<div class="bar"><select id="c">${opt(OP.classes())}</select><select id="y">${opt(OP.years(),cy())}</select>${extra}<button class="btn" id="go">راوړل</button></div><div id="ls"></div>`;
async function attPage(){let rows=[];
 const td=new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
 V.innerHTML=`<h2>حاضري</h2>`+pick(`<input type="date" id="d" value="${td}">`);
 V.onclick=async e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='go'){try{rows=(await api('att_sheet',{params:{class_id:$('#c').value,year_id:$('#y').value,date:$('#d').value}})).rows;
   $('#ls').innerHTML=rows.length?`<button class="btn sm gh" id="all">ټول حاضر</button>`+rows.map(r=>`<div class="rw"><b>${esc(r.name)}</b><div class="seg">${Object.keys(AT).map(s=>`<label class="s${s}"><input type="radio" name="a${r.EnrollmentID}" value="${s}"${r.Status==s?' checked':''}><span>${AT[s]}</span></label>`).join('')}</div></div>`).join('')+(can('attendance.w')?`<button class="btn" id="sv">ثبت</button>`:'')+``:'<p class="mut">په دې ټولګي کې فعال زده‌کوونکي نشته</p>'}catch(x){toast(x.message,1)}}
  else if(b.id=='all')document.querySelectorAll('input[value=P]').forEach(i=>i.checked=true);
  else if(b.id=='sv'){const items=rows.map(r=>({EnrollmentID:r.EnrollmentID,Status:(document.querySelector(`input[name=a${r.EnrollmentID}]:checked`)||{}).value})).filter(i=>i.Status);
   act(()=>api('att_save',{body:{date:$('#d').value,items}}))}}}
async function gradePage(){let rows=[],mx=100;
 V.innerHTML=`<h2>نمرې</h2>`+pick(`<select id="x">${opt(LK.exams.map(e=>[e.id,e.ExamName]))}</select><select id="s">${opt(OP.subjects())}</select>`);
 V.onclick=async e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='go'){try{const d=await api('gr_sheet',{params:{class_id:$('#c').value,year_id:$('#y').value,exam_id:$('#x').value,subject_id:$('#s').value}});rows=d.rows;mx=d.max;
   $('#ls').innerHTML=rows.length?`<p class="mut">اعظمي نمره: ${esc(mx)}</p>`+rows.map(r=>`<div class="rw"><b>${esc(r.name)}</b><input type="number" step="any" min="0" max="${esc(mx)}" data-id="${r.EnrollmentID}" value="${esc(r.Score)}"></div>`).join('')+(can('grades.w')?`<button class="btn" id="sv">ثبت</button>`:'')+`<button class="btn gh" id="gpr">🖨️ چاپ</button>`:'<p class="mut">په دې ټولګي کې فعال زده‌کوونکي نشته</p>'}catch(x){toast(x.message,1)}}
  else if(b.id=='gpr')printGrades(rows,mx);
  else if(b.id=='sv'){const items=[...document.querySelectorAll('input[data-id]')].map(i=>({EnrollmentID:i.dataset.id,Score:i.value}));
   act(()=>api('gr_save',{body:{exam_id:$('#x').value,subject_id:$('#s').value,items}}))}}}
const SCH='assets/img/school.jpg';
const PM=['جنوري','فبروري','مارچ','اپریل','می','جون','جولای','اګست','سپتمبر','اکتوبر','نومبر','دسمبر'],go=h=>{if(location.hash=='#'+h)route();else location.hash=h};
let CAL=null;
const calHtml=()=>{const n=new Date(),{y,m}=CAL,off=(new Date(y,m,1).getDay()+1)%7,dim=new Date(y,m+1,0).getDate(),cells=[];for(let i=0;i<off;i++)cells.push('');for(let i=1;i<=dim;i++)cells.push(i);
 return `<div class="nv"><button data-cal="1">›</button><span>${y} ${PM[m]}</span><button data-cal="-1">‹</button></div><div class="cg7">${['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'].map(w=>`<span class="wd">${w}</span>`).join('')}${cells.map(c=>`<span class="dy${c&&y==n.getFullYear()&&m==n.getMonth()&&c==n.getDate()?' td':''}">${c}</span>`).join('')}</div>`};
const gcard=(c,ic,v,l,sub,n,t,ic2)=>`<div class="gc ${c}"><div class="gi">${ic}</div><div class="gt"><b>${v}</b><span>${l}</span><small>${sub}</small></div><span class="pl">↑ ${t?Math.round(n*100/t):0}%</span><span class="g2">${ic2}</span></div>`;
async function dashPage(){try{const d=await api('dash'),n=new Date();if(!CAL)CAL={y:n.getFullYear(),m:n.getMonth()};
 const A=Object.fromEntries(d.att.map(a=>[a.Status,+a.n])),tot=Object.values(A).reduce((a,b)=>a+b,0),pr=k=>tot?Math.round((A[k]||0)*100/tot):0,g0=Object.fromEntries((d.gender||[]).map(x=>[x.Gender,+x.n])),mal=g0.Male||0,fem=g0.Female||0,gt=mal+fem,mp=gt?Math.round(mal*100/gt):0,cg=d.cg||[];
 const bell=(d.leaves_pending||0)+(d.overdue_loans||0)+((A.A||0)?1:0);$('#bn').textContent=bell;$('#bn').classList.toggle('hidden',!bell);
 const mx=Math.max(20,...cg.flatMap(c=>[+c.m,+c.f])),st=Math.ceil(mx/5/10)*10||20,top=st*5,ticks=[0,1,2,3,4,5].map(i=>i*st);
 const QA=[['👩‍🎓','نوی زده کوونکی',()=>form('students',null,route),'students.w','c2'],['🧑‍🏫','نوی ښوونکی',()=>form('teachers',null,route),'teachers.w','c1'],['📝','د نمرو ثبت',()=>go('grades'),'grades.w','c3'],['📋','د حاضرۍ ثبت',()=>go('attendance'),'attendance.w','c4'],['🧪','ازموینه ټاکل',()=>form('exams',null,route),'exams.w','c5'],['🖨️','راپورونه چاپول',()=>go('reports'),'reports.r','c6']].filter(q=>can(q[3]));
 const ar=(l,k,c)=>`<div class="ar"><span>${l}</span><div><i style="width:${pr(k)}%;background:${c}"></i></div><em>${pr(k)}%</em></div>`;
 V.innerHTML=`<section class="hero"><img class="hbg" src="${SCH}" alt=""><div class="ht"><h2>د حسین خېلو عالي لیسه</h2><p>علم، اخلاق، پرمختګ</p></div><img class="hp" src="${SCH}" alt="د ښوونځي عکس"><div class="q">❝ تعلیم د روښانه راتلونکي بنسټ دی ❞ &nbsp;📚</div></section>
 <div class="dg"><div class="lc"><div class="stg">${gcard('b','🎓',d.students,'ټول زده کوونکي',d.new_students+' د دې کال شمولیت',d.new_students,d.students,'👥')+gcard('g','🧑‍🏫',d.teachers,'ښوونکي','فعال ښوونکي',d.new_teachers,d.teachers,'👤')+gcard('o','👤',d.employees,'اداري کارکوونکي','فعال کارکوونکي',d.new_employees,d.employees,'👥')+gcard('p','🏢',d.classes,'ټولګي','فعال ټولګي',0,d.classes,'🏫')}</div>
 <div class="cr"><div class="pn2"><div class="hdr2"><h3>📊 د ټولګیو د زده کوونکو شمېر</h3><div class="lgn"><span><i style="background:#2563eb"></i>هلکان</span><span><i style="background:#ec4899"></i>نجونې</span></div></div>
  ${cg.length?`<div class="bc"><div class="ya">${ticks.map(t=>`<span>${t}</span>`).join('')}</div><div class="bp">${cg.map(c=>`<div class="bg2"><i style="height:${c.m/top*100}%;background:#2563eb"><u>${c.m}</u></i><i style="height:${c.f/top*100}%;background:#ec4899"><u>${c.f}</u></i><span>${esc(c.Grade+'-'+c.Section)}</span></div>`).join('')}</div></div>`:'<p class="mut">ثبت‌نام نشته</p>'}</div>
  <div class="pn2"><h3>👥 د زده کوونکو جنسیت</h3><div class="dn"><div class="ring" style="background:conic-gradient(#2563eb 0 ${mp}%,#ec4899 ${mp}% 100%)"><div class="ct"><small>ټول</small><b>${gt}</b></div></div><div class="dl"><div><small style="color:#2563eb">● هلکان</small><b>${gt?mp:0}%</b><small>${mal}</small></div><div><small style="color:#ec4899">● نجونې</small><b>${gt?100-mp:0}%</b><small>${fem}</small></div></div></div></div>
  <div class="pn2"><h3>🗓️ د حاضرۍ لنډ راپور</h3>${ar('حاضر','P','#22c55e')+ar('غیرحاضر','A','#ef4444')+ar('رخصت','E','#f59e0b')+ar('ناوخته','L','#8b5cf6')}<small class="mut">نن ورځ، ${tot} ریکارډه</small></div></div></div>
 <div class="pn2 cw3"><h3>📅 د تعلیمي کال تقویم</h3><div id="cal">${calHtml()}</div><div class="lgd"><div><i style="background:#22c55e"></i>حاضر<b>${A.P||0}</b></div><div><i style="background:#ef4444"></i>غیرحاضر<b>${A.A||0}</b></div><div><i style="background:#f59e0b"></i>رخصت<b>${A.E||0}</b></div><div><i style="background:#8b5cf6"></i>ناوخته<b>${A.L||0}</b></div></div></div></div>
 <div class="bm"><div class="pn2"><div class="hdr2"><h3>🧑‍🎓 وروستي ثبت شوي زده کوونکي</h3><a href="#students" style="font-size:.85rem;color:#2563eb">ټول وګوری ‹</a></div><table class="rt"><thead><tr><th>شمېر</th><th>نوم</th><th>د پلار نوم</th><th>ټولګی</th><th>د ثبت نېټه</th><th>حالت</th></tr></thead><tbody>${(d.recent||[]).map((r,i)=>`<tr><td>${i+1}</td><td><span class="mini">${esc((r.name||'?')[0])}</span>${esc(r.name)}</td><td>${esc(r.FatherName)}</td><td>${esc(r.cls)}</td><td>${esc(r.EnrollDate)}</td><td><span class="pill">${esc(ST[r.Status]||r.Status)}</span></td></tr>`).join('')||'<tr><td colspan="6" class="mut">هېڅ نشته</td></tr>'}</tbody></table></div>
 <div class="pn2"><h3>🔗 چټک لاسرسی</h3><div class="qk">${QA.map((q,i)=>`<button class="${q[4]}" data-qa="${i}"><span>${q[0]}</span>${q[1]}</button>`).join('')}</div></div></div>
 <div class="ft"><span>© ${n.getFullYear()} ټول حقوق خوندي دي</span><span>د حسین خېلو عالي لیسه | د معلوماتو مدیریت سیستم | نسخه 1.0.0</span></div>`;
 V.onclick=e=>{const q=e.target.closest('[data-qa]'),cb=e.target.closest('[data-cal]');if(q)QA[q.dataset.qa][2]();if(cb){CAL.m+=+cb.dataset.cal;if(CAL.m<0){CAL.m=11;CAL.y--}if(CAL.m>11){CAL.m=0;CAL.y++}$('#cal').innerHTML=calHtml()}}}catch(x){toast(x.message,1)}}

const PG={students:['زده‌کوونکي','students.r'],enrollments:['ثبت‌نام','enrollments.r'],history:['تاریخچه','students.r'],teachers:['ښوونکي','teachers.r'],assign:['د مضمون ویش','assign.r'],jobs:['د دندو تاریخچه','salaries.r'],leaves:['رخصتي','leaves.r'],classes:['ټولګي','classes.r'],years:['تعلیمي کال','years.r'],subjects:['مضمونونه','subjects.r'],classsubjects:['د ټولګي مضمونونه','classsubjects.r'],attendance:['د زده‌کوونکو حاضري','attendance.r'],staffatt:['د ښوونکو او کارکوونکو حاضري','staffatt.r'],exams:['ازموینې','exams.r'],grades:['نمرې او پایلې','grades.r'],bulletins:['د نمرو خبرپاڼې','bulletins.r'],about:['د جوړوونکي معلومات','about.r'],timetable:['مهال‌وېش','timetable.r'],guardians:['والدین','guardians.r'],books:['کتابونه','books.r'],loans:['د کتابونو امانت','loans.r'],employees:['کارکوونکي','employees.r'],salaries:['معاشونه','salaries.r'],expcats:['د لګښت ډولونه','expcats.r'],expenses:['لګښتونه','expenses.r'],promotion:['د زده‌کوونکو ارتقا','promotion.r'],reports:['راپورونه','reports.r'],users:['کاروونکي','users.r'],audit:['د بدلونونو ثبت','audit.r'],roles:['رولونه او صلاحیتونه','roles.r'],notices:['خبرتیاوې','notices.r'],sdocs:['د زده‌کوونکو اسناد','sdocs.r'],tdocs:['د ښوونکو اسناد','teachers.r'],backup:['Backup او Recovery','backup.r']};
const MODS20=[[1,'د زده‌کوونکو مدیریت','Student Management','د زده‌کوونکو ټول معلومات','🎓',['students','enrollments','history']],[2,'د استادانو مدیریت','Teacher Management','د استادانو معلومات او اسناد','👩‍🏫',['teachers','assign','jobs','leaves']],[3,'د ټولګیو مدیریت','Class Management','صنفونه او ټولګي','🏫',['classes','years']],[4,'د مضامینو مدیریت','Subject Management','د تدریس مضامین','📘',['subjects','classsubjects']],[5,'د حاضري سیستم','Attendance Management','د زده‌کوونکو او استادانو حاضري','🗓️',['attendance','staffatt']],[6,'د ازموینو مدیریت','Examination Management','د ازموینو تنظیم','🧪',['exams']],[7,'د نمرو سیستم','Marks & Results','د نمرو ثبت او محاسبه','💯',['grades','bulletins']],[8,'د جوړوونکي په اړه','About the Developer','د جوړوونکي او سیستم معلومات','ℹ️',['about']],[9,'د مهال‌وېش سیستم','Timetable Management','د درسونو مهال‌وېش','⏰',['timetable']],[10,'د والدینو مدیریت','Parent Management','د والدینو معلومات او اړیکې','👪',['guardians']],[11,'د کتابتون سیستم','Library Management','کتابونه او پور اخیستل','📚',['books','loans']],[12,'د کارکوونکو مدیریت','Staff Management','اداري کارکوونکي','👷',['employees']],[13,'د معاشونو سیستم','Payroll Management','د معاشونو محاسبه','💵',['salaries','expenses','expcats']],[14,'د زده‌کوونکو ارتقا','Student Promotion','بل ټولګي ته د زده‌کوونکو انتقال','⬆️',['promotion']],[15,'د راپورونو سیستم','Reports & Analytics','احصایې او راپورونه','📊',['reports']],[16,'د کاروونکو مدیریت','User Management','د سیستم کاروونکي','👤',['users','audit']],[17,'د اجازو سیستم','Roles & Permissions','د کاروونکو صلاحیتونه','🔐',['roles']],[18,'د خبرتیاوو سیستم','Notifications','د والدینو، استادانو او زده‌کوونکو خبرتیاوې','🔔',['notices']],[19,'د اسنادو مدیریت','Document Management','عکسونه او اړوند اسناد','🗂️',['sdocs','tdocs']],[20,'د بیک‌اپ سیستم','Backup & Recovery','د معلوماتو خوندي ساتل او بېرته ترلاسه کول','💾',['backup']]];
const GR=[['dash','اصلي صفحه','🏠',[['dash','']]],['modules','ټول ماډولونه','🧩',[['modules','']]]].concat(MODS20.map(m=>['m'+m[0],m[1],m[4],m[5].map(k=>[k,PG[k][0],PG[k][1]])]));
const NAV=Object.entries(PG).map(([k,v])=>[k,v[0],v[1]]).concat([['dash','اصلي صفحه',''],['modules','ټول ماډولونه','']]);
const MOD=Object.fromEntries(NAV.map(n=>[n[0],n[1]]));

const cell=v=>v&&typeof v=='object'?v.h:esc(v);
const tbl=d=>{const h=d[0]?Object.keys(d[0]):[];return d.length?`<table class="tbl"><thead><tr>${h.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${d.map(r=>`<tr>${h.map(x=>`<td data-l="${esc(x)}">${cell(r[x])}</td>`).join('')}</tr>`).join('')}</tbody></table>`:''};
const REP={attendance:{t:'د زده‌کوونکو حاضرۍ راپور (میاشتنی/کلنی)',pm:'attendance.r',p:[['class_id','ټولګی','classes'],['year_id','کال','years'],['from','له نېټې','date'],['to','تر نېټې','date']]},
staffatt:{t:'د ښوونکو او کارکوونکو حاضرۍ راپور',pm:'staffatt.r',p:[['from','له نېټې','date'],['to','تر نېټې','date']]},
card:{t:'د زده‌کوونکي کارنامه',pm:'grades.r',p:[['enrollment_id','زده‌کوونکی','enr'],['exam_id','ازموینه','exams']]},
results:{t:'د ټولګي درجه‌بندي او مقامونه',pm:'grades.r',p:[['class_id','ټولګی','classes'],['year_id','کال','years'],['exam_id','ازموینه','exams']]},
passfail:{t:'د بریالیو او ناکامو راپور',pm:'grades.r',p:[['year_id','کال','years'],['exam_id','ازموینه','exams']]}};
async function repPage(){const ks=Object.keys(REP).filter(k=>can(REP[k].pm));
 if(!ks.length){V.innerHTML='<p class="mut">د راپورونو اجازه نشته</p>';return}
 const draw=k=>`<div class="bar">${REP[k].p.map(([n,l,o])=>o=='date'?`<label>${l}<input type="date" data-p="${n}"></label>`:`<label>${l}<select data-p="${n}">${opt(OP[o](),o=='years'?cy():'')}</select></label>`).join('')}${REP[k].p.some(p=>p[0]=='from')?'<button class="btn sm gh" data-q="m">دا میاشت</button><button class="btn sm gh" data-q="y">دا کال</button>':''}<button class="btn" id="go">اجرا</button></div>`;
 V.innerHTML=`<h2>راپورونه</h2><div class="bar"><select id="rk">${opt(ks.map(k=>[k,REP[k].t]))}</select></div><div id="pp">${draw(ks[0])}</div><div id="ls"></div>`;
 V.onchange=e=>{if(e.target.id=='rk'){$('#pp').innerHTML=draw(e.target.value);$('#ls').innerHTML=''}};
 V.onclick=async e=>{const b=e.target.closest('button');if(!b)return;if(b.id=='pr')return print();
  if(b.dataset.q){const n=new Date(),y=n.getFullYear(),m=n.getMonth(),z=x=>String(x).padStart(2,'0'),fr=b.dataset.q=='m'?`${y}-${z(m+1)}-01`:`${y}-01-01`,to=b.dataset.q=='m'?`${y}-${z(m+1)}-${z(new Date(y,m+1,0).getDate())}`:`${y}-12-31`;document.querySelector('[data-p=from]').value=fr;document.querySelector('[data-p=to]').value=to;return}
  if(b.id=='go'){const p={name:$('#rk').value};document.querySelectorAll('[data-p]').forEach(i=>p[i.dataset.p]=i.value);
   if(p.name=='card')return cardDlg(+p.enrollment_id,+p.exam_id);
   try{const d=(await api('report',{params:p})).rows,ok=d.filter(r=>r['نتیجه']=='بریالی').length;$('#ls').innerHTML=d.length?'<button class="btn sm gh" id="pr">چاپ</button>'+tbl(d)+(p.name=='passfail'&&d[0]&&d[0]['نتیجه']!==undefined?`<p><b>بریالي:</b> ${ok} | <b>ناکام:</b> ${d.length-ok}</p>`:''):'<p class="mut">پایله نشته</p>'}catch(x){toast(x.message,1)}}}}
async function bkPage(){let r;V.innerHTML=`<div class="bar"><h2>Backup</h2>${can('backup.w')?'<button class="btn" id="bk">Backup اوس واخله</button>':''}</div><p class="mut">د Backup/Recovery پلان او کمانډونه په database/Backup_Recovery.sql کې دي.</p><div id="ls"></div>`;
 const load=async()=>{try{const d=await api('backup_list');$('#ls').innerHTML=d.rows.length?tbl(d.rows):`<p class="mut">${esc(d.note||'تر اوسه Backup نشته')}</p>`}catch(x){toast(x.message,1)}};
 V.onclick=e=>{if(e.target.id=='bk')act(async()=>{r=await api('backup_run',{body:{}})},async()=>{await load();toast('Backup: '+r.file)})};load()}
async function permDlg(r){try{const d=await api('role_perms',{params:{role_id:r.RoleID}}),g={};d.rows.forEach(p=>{const[m,a]=p.Code.split('.');(g[m]??={})[a]=+p.Granted});
 const dl=$('#dlg2');dl.className='';dl.innerHTML=`<form id="fm"><h3>صلاحیتونه: ${esc(r.RoleName)}</h3>${Object.entries(g).map(([m,v])=>`<div class="rw"><b>${esc(MOD[m]||m)}</b><span class="seg2"><label class="ck"><input type="checkbox" value="${m}.r"${v.r?' checked':''}> لیدل</label><label class="ck"><input type="checkbox" value="${m}.w"${v.w?' checked':''}> بدلون</label></span></div>`).join('')}<div class="bar"><button class="btn">ثبت</button><button type="button" class="btn gh" id="cx">بندول</button></div></form>`;
 dl.showModal();$('#cx').onclick=()=>dl.close();
 $('#fm').onsubmit=async e=>{e.preventDefault();await act(async()=>{await api('role_perms_save',{body:{role_id:r.RoleID,codes:[...e.target.querySelectorAll('input:checked')].map(i=>i.value)}});dl.close()})}}catch(x){toast(x.message,1)}}


const LSTALL=async(ent,params)=>{let pg=1,o=[],t=1;while(o.length<t){const d=await api('list',{params:{entity:ent,page:pg,...params}});o.push(...d.rows);t=d.total;if(!d.rows.length)break;pg++}return o};
function modulesPage(){V.innerHTML=`<h2>ټول ماډولونه</h2><div class="mod">${MODS20.map(m=>{const pgs=m[5].filter(k=>can(PG[k][1]));return `<button class="mc${pgs.length?'':' off'}" data-go="${pgs[0]||''}"><i>${m[0]}</i><span class="mi2">${m[4]}</span><b>${m[1]}</b><small>${m[2]}</small><em>${m[3]}</em></button>`}).join('')}</div>`;
 V.onclick=e=>{const b=e.target.closest('[data-go]');if(b&&b.dataset.go)go(b.dataset.go)}}
async function ttPage(){let rows=[],mode='c';const cw=can('timetable.w');
 V.innerHTML=`<h2>د مهال‌وېش سیستم</h2><div class="bar"><select id="mode"><option value="c">د ټولګي مهال‌وېش</option><option value="t">د ښوونکي مهال‌وېش</option></select><select id="c">${opt(OP.classes())}</select><select id="t" class="hidden">${opt(OP.teachers())}</select><select id="y">${opt(OP.years(),cy())}</select><button class="btn" id="go">راوړل</button></div><div id="ls"></div>`;
 const sel=()=>mode=='c'?{ClassID:$('#c').value,YearID:$('#y').value}:{TeacherID:$('#t').value,YearID:$('#y').value};
 const draw=()=>{const mp=Math.max(6,...rows.map(r=>+r.PeriodNo)),cell=(d,p)=>{const r=rows.find(x=>+x.DayOfWeek==d&&+x.PeriodNo==p);return r?`<td class="tt on" ${cw?`data-e="${r.SlotID}"`:''}><b>${esc(r.SubjectName)}</b><small>${esc(mode=='c'?(r.TeacherName||''):r.Grade+'-'+r.Section)}</small>${r.StartTime?`<small>${esc(r.StartTime)}${r.EndTime?'–'+esc(r.EndTime):''}</small>`:''}${cw?`<button class="x" data-x="${r.SlotID}">✕</button>`:''}</td>`:`<td class="tt" ${cw?`data-n="${d}|${p}"`:''}>${cw?'+':''}</td>`};
  $('#ls').innerHTML=`<div class="ttw"><table class="ttg"><thead><tr><th></th>${DAYS.slice(0,6).map(d=>`<th>${d}</th>`).join('')}</tr></thead><tbody>${Array.from({length:mp},(_,i)=>`<tr><th>${i+1}</th>${[0,1,2,3,4,5].map(d=>cell(d,i+1)).join('')}</tr>`).join('')}</tbody></table></div><button class="btn sm gh" id="pr">چاپ</button>`};
 const load=async()=>{try{rows=await LSTALL('timetable',sel());draw()}catch(x){toast(x.message,1)}};
 V.onchange=e=>{if(e.target.id=='mode'){mode=e.target.value;$('#c').classList.toggle('hidden',mode!='c');$('#t').classList.toggle('hidden',mode!='t');$('#ls').innerHTML=''}};
 V.onclick=e=>{const b=e.target.closest('button,[data-n],[data-e]');if(!b)return;
  if(b.id=='go')load();else if(b.id=='pr')print();
  else if(b.dataset.x){if(confirm('حذف شي؟'))act(()=>api('delete',{params:{entity:'timetable'},body:{id:+b.dataset.x}}),load)}
  else if(b.dataset.n){const[d,p]=b.dataset.n.split('|');form('timetable',{YearID:+$('#y').value,ClassID:mode=='c'?+$('#c').value:undefined,TeacherID:mode=='t'?+$('#t').value:undefined,DayOfWeek:+d,PeriodNo:+p},load)}
  else if(b.dataset.e)form('timetable',rows.find(r=>r.SlotID==b.dataset.e),load)}}
async function promoPage(){let rows=[];const cw=can('promotion.w');
 V.innerHTML=`<h2>د زده‌کوونکو ارتقا</h2><p class="mut">لومړی نوی تعلیمي کال جوړ کړئ، بیا زده‌کوونکي بل ټولګي ته انتقال کړئ. که ازموینه وټاکئ، یوازې بریالي په ډیفالټ ټاکل کېږي.</p><div class="pn2"><div class="bar"><label>له ټولګي<select id="fc">${opt(OP.classes())}</select></label><label>له کال<select id="fy">${opt(OP.years(),cy())}</select></label><label>ازموینه (اختیاري)<select id="fx"><option value="">—</option>${opt(OP.exams())}</select></label><button class="btn" id="go">راوړل</button></div><div id="ls"></div></div>`;
 V.onclick=async e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='go'){try{rows=(await api('promote_list',{params:{class_id:$('#fc').value,year_id:$('#fy').value,exam_id:$('#fx').value}})).rows;
   const nx=LK.classes.find(c=>c.id==$('#fc').value)||{},to=LK.classes.find(c=>c.Grade==+nx.Grade+1&&c.Section==nx.Section)||LK.classes.find(c=>c.Grade==+nx.Grade+1);
   $('#ls').innerHTML=rows.length?`<table class="tbl"><thead><tr><th><input type="checkbox" id="ca" checked></th><th>نمبر</th><th>نوم</th><th>نتیجه</th></tr></thead><tbody>${rows.map(r=>`<tr><td><input type="checkbox" class="ck1" data-id="${r.EnrollmentID}"${r.passed!=null&&!+r.passed?'':' checked'}></td><td data-l="نمبر">${esc(r.StudentCode)}</td><td data-l="نوم">${esc(r.name)}</td><td data-l="نتیجه">${r.passed==null?'—':(+r.passed?'بریالی':'ناکام')}</td></tr>`).join('')}</tbody></table>${cw?`<div class="bar"><label>عمل<select id="pm"><option value="promote">بل ټولګي ته لوړول</option><option value="repeat">په ټولګي کې پاتې کول</option><option value="graduate">فراغت</option></select></label><label>نوی ټولګی<select id="tc">${opt(OP.classes(),to?to.id:'')}</select></label><label>نوی کال<select id="ty">${opt(OP.years())}</select></label><button class="btn" id="run">اجرا</button></div>`:''}`:'<p class="mut">فعال زده‌کوونکي نشته</p>'}catch(x){toast(x.message,1)}}
  else if(b.id=='run'){const ids=[...document.querySelectorAll('.ck1:checked')].map(i=>+i.dataset.id);if(!ids.length)return toast('زده‌کوونکي وټاکئ',1);if(!confirm(ids.length+' زده‌کوونکي؟'))return;
   try{const r=await api('promote',{body:{ids,mode:$('#pm').value,to_class:$('#tc').value,to_year:$('#ty').value}});toast(`ترسره شو: ${r.done} | تېر شول: ${r.skipped}`);$('#go').click()}catch(x){toast(x.message,1)}}};
 V.onchange=e=>{if(e.target.id=='ca')document.querySelectorAll('.ck1').forEach(i=>i.checked=e.target.checked)}}
async function aboutPage(){const d={};try{(await api('about_get')).rows.forEach(r=>d[r.k]=r.v||'')}catch{}
 const cw=can('about.w'),F=[['creator_name','د جوړوونکي نوم'],['creator_title','دنده / تخصص'],['creator_phone','تلیفون'],['creator_email','بریښنالیک'],['creator_note','ځانګړی یادښت'],['school_address','د ښوونځي پته'],['school_phone','د ښوونځي تلیفون']];
 V.innerHTML=`<h2>د جوړوونکي په اړه</h2><div class="two"><div class="pn2"><h3>ℹ️ د سیستم معلومات</h3><div class="kv"><div><span>سیستم</span><b>د حسین خېلو عالي لیسه - د معلوماتو مدیریت سیستم</b></div><div><span>نسخه</span><b>1.0.0</b></div><div><span>ټکنالوژي</span><b>PHP + SQL Server + JavaScript</b></div></div></div>
 <div class="pn2"><h3>👤 د جوړوونکي او ښوونځي معلومات</h3><form id="af">${F.map(([k,l])=>cw?`<label>${l}<input name="${k}" value="${esc(d[k])}"></label>`:`<div class="kv"><div><span>${l}</span><b>${esc(d[k])||'—'}</b></div></div>`).join('')}${cw?'<button class="btn">ثبت</button>':''}</form></div></div>`;
 if(cw)$('#af').onsubmit=e=>{e.preventDefault();const b={};F.forEach(([k])=>b[k]=e.target.elements[k].value);act(()=>api('about_save',{body:b}))}}
async function notifDlg(){try{const d=await api('notice_feed'),dl=$('#dlg2');dl.className='';
 dl.innerHTML=`<h3>🔔 خبرتیاوې</h3>${d.rows.length?d.rows.map(n=>`<div class="rw" style="display:block"><b>${esc(n.Title)}</b> <small class="mut">${esc(n.PublishDate)} | ${esc(AUD[n.Audience]||'')}</small><p style="margin:4px 0">${esc(n.Body)}</p></div>`).join(''):'<p class="mut">فعالې خبرتیاوې نشته</p>'}<div class="bar">${can('notices.w')?'<button class="btn" id="nn">+ نوې خبرتیا</button>':''}<button class="btn gh" id="cx">بندول</button></div>`;
 dl.showModal();$('#cx').onclick=()=>dl.close();if($('#nn'))$('#nn').onclick=()=>{dl.close();form('notices',null,()=>{})}}catch(x){toast(x.message,1)}}

const setMe=()=>{const nm=U.FullName||U.Username;$('#who').textContent=nm;$('#wl').textContent='ښه راغلاست، '+nm;$('#meav').innerHTML=/^(uploads\/|data:image\/)/.test(U.PhotoFile||'')?`<img class="uimg" src="${esc(U.PhotoFile)}" alt="">`:esc((nm||'?')[0].toUpperCase())};
const shrink=f=>new Promise(res=>{if(!f.type||!f.type.startsWith('image/'))return res(f);const r=new FileReader();r.onerror=()=>res(f);r.onload=()=>{const im=new Image();im.onerror=()=>res(f);im.onload=()=>{const k=Math.min(1,700/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);c.toBlob(b=>res(b||f),'image/jpeg',.85)};im.src=r.result};r.readAsDataURL(f)});
function bulletinDlg(d){const dl=$('#dlg2');dl.className='wide';const S=d.subjects,mx=+d.exam.max,ps=+d.exam.pass;let view='sheet';
 const sheet=()=>`<div class="bul"><div class="sh"><h3>د حسین خېلو عالي لیسه</h3><h4>د ټولګي د نمرو خبرپاڼه</h4><p>ټولګی: <b>${esc(d.class)}</b> | کال: <b>${esc(d.year)}</b> | ازموینه: <b>${esc(d.exam.name)}</b> (${esc(EX[d.exam.type]||'')}) | اعظمي نمره: ${mx} | د بریالیتوب حد: ${ps}%</p></div>
 <div class="ttw"><table class="rt btb"><thead><tr><th>#</th><th>نمبر</th><th>نوم</th>${S.map(s=>`<th>${esc(s.name)}</th>`).join('')}<th>مجموعه</th><th>%</th><th>مقام</th><th>نتیجه</th></tr></thead><tbody>${d.rows.map((r,i)=>`<tr class="${r.result=='ناکام'?'fl':''}"><td>${i+1}</td><td>${esc(r.code)}</td><td>${esc(r.name)}</td>${S.map(s=>{const v=(r.scores||{})[s.id];return `<td class="${v!=null&&v*100/mx<ps?'lo':''}">${v==null?'—':v}</td>`}).join('')}<td>${r.n?r.total:'—'}</td><td>${r.pct==null?'—':r.pct}</td><td>${r.rank??'—'}</td><td>${esc(r.result)}</td></tr>`).join('')}</tbody></table></div>
 <p>ټول: ${d.stats.count} | نمره‌شوي: ${d.stats.graded} | بریالي: ${d.stats.pass} | ناکام: ${d.stats.fail} | اوسط: ${d.stats.avg}%</p><div class="sig"><span>د ټولګي ښوونکی</span><span>د لیسې مدیر</span></div></div>`;
 const cards=()=>d.rows.filter(r=>r.n).map(r=>`<div class="pgc"><div class="card-h">${av(r.photo,r.name)}<div><h3>د حسین خېلو عالي لیسه - نمراتو پاڼه</h3><div><b>${esc(r.name)}</b> (${esc(r.code)})</div><div class="mut">ټولګی ${esc(d.class)} | کال ${esc(d.year)} | ${esc(d.exam.name)}</div></div></div>
 <table class="rt"><thead><tr><th>مضمون</th><th>نمره</th><th>اعظمي</th><th>%</th><th>نتیجه</th></tr></thead><tbody>${S.filter(s=>(r.scores||{})[s.id]!=null).map(s=>{const v=r.scores[s.id],p=v*100/mx;return `<tr><td>${esc(s.name)}</td><td>${v}</td><td>${mx}</td><td>${p.toFixed(1)}</td><td>${p<ps?'ناکام':'بریالی'}</td></tr>`}).join('')}</tbody></table>
 <p><b>مجموعه:</b> ${r.total} | <b>فیصدي:</b> ${r.pct}% | <b>نتیجه:</b> ${esc(r.result)} | <b>مقام:</b> ${r.rank}/${d.stats.graded}</p><div class="sig"><span>د ټولګي ښوونکی</span><span>د لیسې مدیر</span></div></div>`).join('')||'<p class="mut">نمرې نشته</p>';
 const draw=()=>{dl.innerHTML=`<div class="bar"><button class="btn" id="pr">🖨️ چاپ</button><button class="btn gh" id="vs">${view=='sheet'?'د زده‌کوونکو کارنامې (هر یو جلا پاڼه)':'د ټولګي خبرپاڼه'}</button><button class="btn gh" id="cx">بندول</button></div>${view=='sheet'?sheet():cards()}`;$('#pr').onclick=()=>print();$('#vs').onclick=()=>{view=view=='sheet'?'cards':'sheet';draw()};$('#cx').onclick=()=>dl.close()};
 draw();if(dl.open)dl.close();dl.showModal()}
function printGrades(rows,mx){const t=id=>($('#'+id).selectedOptions[0]||{}).text||'',dl=$('#dlg2');dl.className='wide';
 dl.innerHTML=`<div class="bar"><button class="btn" id="pr">🖨️ چاپ</button><button class="btn gh" id="cx">بندول</button></div><div class="bul"><div class="sh"><h3>د حسین خېلو عالي لیسه</h3><h4>د نمرو ثبت پاڼه</h4><p>ټولګی: <b>${esc(t('c'))}</b> | کال: <b>${esc(t('y'))}</b> | ازموینه: <b>${esc(t('x'))}</b> | مضمون: <b>${esc(t('s'))}</b> | اعظمي نمره: ${esc(mx)}</p></div><table class="rt btb"><thead><tr><th>#</th><th>نوم</th><th>نمره</th><th>لاسلیک</th></tr></thead><tbody>${[...document.querySelectorAll('input[data-id]')].map((i,k)=>`<tr><td>${k+1}</td><td>${esc(rows[k].name)}</td><td>${esc(i.value)}</td><td></td></tr>`).join('')}</tbody></table><div class="sig"><span>د مضمون ښوونکی</span><span>مدیر</span></div></div>`;
 if(dl.open)dl.close();dl.showModal();$('#pr').onclick=()=>print();$('#cx').onclick=()=>dl.close()}
async function bulletinsPage(){const cw=can('bulletins.w');let rows=[];
 V.innerHTML=`<h2>د نمرو خبرپاڼې</h2><div class="pn2"><div class="bar"><label>ټولګی<select id="c">${opt(OP.classes())}</select></label><label>کال<select id="y">${opt(OP.years(),cy())}</select></label><label>ازموینه<select id="x">${opt(OP.exams())}</select></label><button class="btn" id="bd">جوړول او کتل</button>${cw?'<button class="btn gh" id="ba">د ټولو ټولګیو خبرپاڼې جوړول</button>':''}</div><p class="mut">خبرپاڼه د نمرو له ثبت سره خپله جوړېږي او دلته ذخیره کېږي. هر وخت یې لیدلی او چاپولی شئ.</p></div><h3>ذخیره شوې خبرپاڼې</h3><div id="ls"></div>`;
 const load=async()=>{try{rows=await LSTALL('bulletins',{YearID:$('#y').value});$('#ls').innerHTML=rows.length?`<table class="tbl"><thead><tr><th>ټولګی</th><th>ازموینه</th><th>زده‌کوونکي</th><th>بریالي</th><th>وخت</th><th></th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td data-l="ټولګی">${esc(r.Grade+'-'+r.Section)}</td><td data-l="ازموینه">${esc(r.ExamName)}</td><td data-l="زده‌کوونکي">${r.StudentCount}</td><td data-l="بریالي">${r.PassCount}</td><td data-l="وخت">${esc(r.GeneratedAt)}</td><td class="act"><button class="btn sm" data-v="${i}">لیدل / چاپ</button>${cw?`<button class="btn sm red" data-d="${i}">حذف</button>`:''}</td></tr>`).join('')}</tbody></table>`:'<p class="mut">تر اوسه ذخیره شوې خبرپاڼې نشته</p>'}catch(x){toast(x.message,1)}};
 V.onchange=e=>{if(e.target.id=='y')load()};
 V.onclick=async e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='bd'){try{bulletinDlg(await api('bulletin_build',{params:{class_id:$('#c').value,year_id:$('#y').value,exam_id:$('#x').value}}));load()}catch(x){toast(x.message,1)}}
  else if(b.id=='ba'){try{const r=await api('bulletin_all',{body:{year_id:$('#y').value,exam_id:$('#x').value}});toast(r.count+' خبرپاڼې جوړې شوې');load()}catch(x){toast(x.message,1)}}
  else if(b.dataset.v){try{bulletinDlg(await api('bulletin_get',{params:{id:rows[b.dataset.v].BulletinID}}))}catch(x){toast(x.message,1)}}
  else if(b.dataset.d){if(confirm('حذف شي؟'))act(()=>api('delete',{params:{entity:'bulletins'},body:{id:rows[b.dataset.d].BulletinID}}),load)}};
 load()}
function profileEditDlg(){const d=$('#dlg2');d.className='';d.innerHTML=`<form id="fm"><h3>زما پروفایل</h3><div class="ph0"><button type="button" class="avb" id="pp">${av(U.PhotoFile,U.FullName||U.Username,'big')}</button></div><p class="mut" style="text-align:center">د عکس بدلولو لپاره په عکس کېکاږئ</p><label>بشپړ نوم<input name="n" value="${esc(U.FullName||'')}" required></label><div class="bar"><button class="btn">ثبت</button><button type="button" class="btn gh" id="cx">بندول</button></div></form>`;
 d.open&&d.close();d.showModal();$('#cx').onclick=()=>d.close();
 $('#pp').onclick=()=>photoDlg('users',U.UserID,U.PhotoFile,async()=>{const r=await api('me');U=r.user;setMe();profileEditDlg()});
 $('#fm').onsubmit=async e=>{e.preventDefault();await act(async()=>{await api('profile_update',{body:{FullName:e.target.n.value}});const r=await api('me');U=r.user;setMe();d.close()})}}
const KD={student:{e:'students',n:r=>r.FirstName+' '+r.FatherName,s:r=>r.StudentCode,k:'StudentID'},teacher:{e:'teachers',n:r=>r.FullName,s:r=>r.Specialty||'ښوونکی',k:'TeacherID'},employee:{e:'employees',n:r=>r.FullName,s:r=>r.Position||'کارکوونکی',k:'EmployeeID'}};
const LST=(ent,params)=>api('list',{params:{entity:ent,...params}}).then(d=>d.rows,()=>[]);
const flink=p=>/^(uploads\/|data:)/.test(p||'')?`<a href="${esc(p)}" target="_blank" rel="noopener">لیدل</a> `:'';
async function profile(kind,id){const K=KD[kind],E=ENT[K.e],d=$('#dlg'),pre={[K.k]:id};let tab='info',D={};
 const TABS={student:[['info','معلومات'],['guardians','سرپرستان'],['history','تاریخچه'],['years','پخواني کلونه او ازموینې'],['docs','اسناد']],
  teacher:[['info','معلومات'],['docs','اسناد'],['assign','تدریس'],['jobs','دندې'],['salaries','معاشونه'],['att','حاضري او رخصتي']],
  employee:[['info','معلومات'],['jobs','دندې'],['salaries','معاشونه'],['att','حاضري او رخصتي']]}[kind];
 const add=ent=>can((ENT[ent].perm||ent)+'.w')?`<button class="btn sm" data-add="${ent}">+ نوی</button>`:'';
 const TB=(ent,rows)=>add(ent)+(rows.length?tbl(rows):'<p class="mut">هېڅ نشته</p>');
 const body=()=>{const P=D.person;
  if(tab=='info')return `<div class="kv">${E.fd.filter(x=>x.t!='password').map(x=>{let v=P[x.n];if(x.t=='check')v=yn(v);else if(x.t=='select')v=x.o=='gender'?G[v]:(OP[x.o]().find(o=>o[0]==v)||[])[1];return `<div><span>${esc(x.l)}</span><b>${esc(v)}</b></div>`}).join('')}</div>`+(can(K.e+'.w')?'<button class="btn sm" data-edit="1">سمون</button>':'');
  if(tab=='guardians')return TB('guardians',D.guardians.map(r=>({'سرپرست':r.FullName,'اړیکه':r.Relation,'تلیفون':r.Phone,'پته':r.Address,'اصلي':yn(r.IsPrimary)})));
  if(tab=='history')return TB('history',D.history.map(r=>({'پېښه':HS[r.EventType],'نېټه':r.EventDate,'یادښت':r.Note})));
  if(tab=='years'){const y=D.yr||{years:[],exams:[]},yn2=Object.fromEntries(y.years.map(r=>[r.EnrollmentID,r.YearName]));
   return (y.years.length?tbl(y.years.map(r=>({'کال':r.YearName,'ټولګی':r.Grade+' '+r.Section,'حالت':ST[r.Status],'حاضر':r.Present,'غایب':r.Absent}))):'<p class="mut">هېڅ نشته</p>')+'<h3>ازموینې</h3>'+(y.exams.length?tbl(y.exams.map(x=>({'کال':yn2[x.EnrollmentID],'ازموینه':x.ExamName,'ډول':EX[x.ExamType],'مجموعه':x.Total+'/'+x.MaxTotal,'فیصدي':(+x.Pct).toFixed(1),'نتیجه':+x.Pct>=+x.PassMark?'بریالی':'ناکام','کارنامه':{h:`<button class="btn sm gh" data-card="${x.EnrollmentID}|${x.ExamID}">کارنامه</button>`}}))):'<p class="mut">هېڅ نشته</p>')}
  if(tab=='docs')return TB(kind=='student'?'sdocs':'tdocs',D.docs.map(r=>({'ډول':r.DocType,'سرلیک':r.Title,'اداره':r.IssuedBy||'','نېټه':r.IssueDate,'فایل':{h:flink(r.DocFile)+(can(kind=='student'?'sdocs.w':'teachers.w')?`<button class="btn sm gh" data-doc="${r.DocID}">پورته کول</button>`:'')}})));
  if(tab=='assign')return D.assign.length?tbl(D.assign.map(r=>({'مضمون':r.SubjectName,'ټولګی':r.Grade+' '+r.Section,'کال':r.YearName}))):'<p class="mut">هېڅ نشته</p>';
  if(tab=='jobs')return TB('jobs',D.jobs.map(r=>({'دنده':r.Position,'له':r.StartDate,'تر':r.EndDate,'یادښت':r.Note})));
  if(tab=='salaries')return D.salaries.length?tbl(D.salaries.map(r=>({'میاشت':r.PayMonth,'اصلي':r.BaseAmount,'بونس':r.Bonus,'کسر':r.Deduction,'خالص':r.NetAmount,'نېټه':r.PayDate}))):'<p class="mut">هېڅ نشته</p>';
  if(tab=='att'){const c=Object.fromEntries(D.att.map(a=>[a.Status,a.n]));return `<h3>دا کال حاضري</h3><div class="cards">${Object.keys(AT).map(s=>`<div class="card"><b>${c[s]||0}</b>${AT[s]}</div>`).join('')}</div><h3>رخصتي</h3>`+TB('leaves',D.leaves.map(r=>({'له':r.StartDate,'تر':r.EndDate,'دلیل':r.Reason,'حالت':LV[r.Status]})))}};
 const draw=()=>{const P=D.person;d.innerHTML=`<div class="ph-head"><button class="avb" data-photo="1">${av(P.PhotoFile,K.n(P))}</button><div><h3>${esc(K.n(P))}</h3><span class="mut">${esc(K.s(P))}</span></div></div><div class="tabs">${TABS.map(([k,l])=>`<button class="btn sm ${k==tab?'':'gh'}" data-tab="${k}">${l}</button>`).join('')}</div><div>${body()}</div><div class="bar"><button class="btn gh" id="cx">بندول</button></div>`};
 const load=async()=>{try{const[p]=await LST(K.e,{[K.k]:id});if(!p)return toast('نه شته',1);D={person:p};
  if(kind=='student'){[D.guardians,D.docs,D.history,D.yr]=await Promise.all([LST('guardians',{StudentID:id}),LST('sdocs',{StudentID:id}),LST('history',{StudentID:id}),api('student_years',{params:{id}}).catch(()=>({years:[],exams:[]}))])}
  else{const w={[K.k]:id};[D.docs,D.jobs,D.salaries,D.leaves,D.att,D.assign]=await Promise.all([kind=='teacher'?LST('tdocs',w):[],LST('jobs',w),LST('salaries',w),LST('leaves',w),api('staff_summary',{params:{kind:kind=='teacher'?'T':'E',id}}).then(x=>x.rows,()=>[]),kind=='teacher'?LST('assign',w):[]])}
  draw()}catch(x){toast(x.message,1)}};
 d.className='';d.onclick=e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='cx')d.close();else if(b.dataset.tab){tab=b.dataset.tab;draw()}
  else if(b.dataset.photo){if(can(K.e+'.w'))photoDlg(K.e,id,D.person.PhotoFile,load)}
  else if(b.dataset.edit)form(K.e,D.person,load);else if(b.dataset.add)form(b.dataset.add,pre,load);
  else if(b.dataset.card){const[en,ex]=b.dataset.card.split('|');cardDlg(+en,+ex)}
  else if(b.dataset.doc)photoDlg(kind=='student'?'sdocs':'tdocs',+b.dataset.doc,'',load,1)};
 d.showModal();load()}
function photoDlg(ent,id,cur,done,doc){const d=$('#dlg2');d.className='';
 d.innerHTML=`<form id="fm"><h3>${doc?'فایل پورته کول':'عکس'}</h3>${doc?'':`<div class="ph0" id="pv">${av(cur,'?','big')}</div>`}<label><input type="file" id="fl" accept="${doc?'image/*,application/pdf':'image/*'}"></label><div class="bar"><button class="btn">پورته کول</button><button type="button" class="btn gh" id="cx">بندول</button></div></form>`;
 d.open&&d.close();d.showModal();$('#cx').onclick=()=>d.close();
 $('#fl').onchange=e=>{const f=e.target.files[0];if(f&&!doc&&f.type.startsWith('image/')){const r=new FileReader();r.onload=()=>{$('#pv').innerHTML=`<img class="av big" src="${r.result}" alt="">`};r.readAsDataURL(f)}};
 $('#fm').onsubmit=async e=>{e.preventDefault();const f=$('#fl').files[0];if(!f)return toast('فایل وټاکئ',1);await act(async()=>{await apiUpload(ent,id,doc?f:await shrink(f));d.close()},done)}}
async function cardDlg(en,ex){try{const d=await api('report_card',{params:{enrollment_id:en,exam_id:ex}}),S=d.student,m=d.sum,dl=$('#dlg2');dl.className='wide';
 dl.innerHTML=`<div class="card-h">${av(S.PhotoFile,S.name)}<div><h3>د حسین خېلو لېسه - نمراتو پاڼه</h3><div>${esc(S.name)} (${esc(S.code)})</div><div class="mut">د پلار نوم: ${esc(S.father)} | ټولګی ${esc(S.grade)} ${esc(S.section)} | کال ${esc(S.year)}</div></div></div><h3>${esc(d.exam.name)}</h3>${tbl(d.rows)}<p><b>مجموعه:</b> ${m.total}/${m.maxTotal} | <b>فیصدي:</b> ${m.pct}% | <b>نتیجه:</b> ${m.pass?'بریالی':'ناکام'} | <b>مقام:</b> ${m.rank}/${m.count}</p><div class="bar"><button class="btn" id="pr">چاپ</button><button class="btn gh" id="cx">بندول</button></div>`;
 if(dl.open)dl.close();dl.showModal();$('#cx').onclick=()=>dl.close();$('#pr').onclick=()=>print()}catch(x){toast(x.message,1)}}
function cardPick(en){const d=$('#dlg2');d.className='';d.innerHTML=`<form id="fm"><h3>ازموینه وټاکئ</h3><label><select id="xs">${opt(OP.exams())}</select></label><div class="bar"><button class="btn">کارنامه</button><button type="button" class="btn gh" id="cx">بندول</button></div></form>`;
 d.showModal();$('#cx').onclick=()=>d.close();$('#fm').onsubmit=e=>{e.preventDefault();cardDlg(en,+$('#xs').value)}}
async function staffAttPage(){let rows=[];V.innerHTML=`<h2>د ښوونکو او کارکوونکو حاضري</h2><div class="bar"><input type="date" id="d" value="${tdy()}"><button class="btn" id="go">راوړل</button></div><div id="ls"></div>`;
 V.onclick=async e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='go'){try{rows=(await api('staff_sheet',{params:{date:$('#d').value}})).rows;$('#ls').innerHTML=rows.length?`<button class="btn sm gh" id="all">ټول حاضر</button>`+rows.map((r,i)=>`<div class="rw"><b>${esc(r.name)} <small class="mut">${esc(r.typ)}</small></b><div class="seg">${segs('s'+i,r.Status)}</div></div>`).join('')+(can('staffatt.w')?'<button class="btn" id="sv">ثبت</button>':''):'<p class="mut">هېڅ نشته</p>'}catch(x){toast(x.message,1)}}
  else if(b.id=='all')document.querySelectorAll('input[value=P]').forEach(i=>i.checked=true);
  else if(b.id=='sv'){const items=rows.map((r,i)=>({kind:r.kind,id:r.id,Status:(document.querySelector(`input[name=s${i}]:checked`)||{}).value})).filter(i=>i.Status);act(()=>api('staff_save',{body:{date:$('#d').value,items}}))}}}
const IC={dash:'🏠',reports:'📊',students:'👨‍🎓',history:'🕘',guardians:'👪',enrollments:'📝',classes:'🏫',subjects:'📖',classsubjects:'🗂️',years:'📅',teachers:'👩‍🏫',employees:'👷',tdocs:'🎓',assign:'🧩',jobs:'💼',staffatt:'✅',leaves:'🌴',attendance:'🗓️',exams:'🧪',grades:'💯',feetypes:'🏷️',studentfees:'🧾',payments:'💰',expcats:'📂',expenses:'💸',salaries:'💵',books:'📚',loans:'🔖',users:'👤',roles:'🔐',audit:'🕵️',backup:'💾'};
function route(){const k=location.hash.slice(1)||'dash',ok=NAV.filter(n=>can(n[2]));
 $('#mn').innerHTML=GR.map(g=>{const its=g[3].filter(i=>can(i[2]||''));if(!its.length)return'';const act=its.some(i=>i[0]==k),ic=`<span class="ic">${g[2]}</span><b>${g[1]}</b><em>›</em>`;
  return g[3].length==1?`<a class="mi${act?' on':''}" href="#${its[0][0]}">${ic}</a>`:`<div class="mg${act?' open':''}"><button class="mi" data-g="1">${ic}</button><div class="sub">${its.map(i=>`<a href="#${i[0]}"${i[0]==k?' class="on"':''}>${i[1]}</a>`).join('')}</div></div>`}).join('');
 document.body.classList.remove('open');V.onclick=V.oninput=V.onchange=null;
 if(!ok.some(n=>n[0]==k))return dashPage();
 ({dash:dashPage,attendance:attPage,grades:gradePage,staffatt:staffAttPage,modules:modulesPage,bulletins:bulletinsPage,timetable:ttPage,promotion:promoPage,about:aboutPage,reports:repPage,backup:bkPage})[k]?.()??crud(k)}
function showLogin(){U=null;$('#app').classList.add('hidden');$('#login').classList.remove('hidden')}
async function start(r){U=r.user;CSRF=r.csrf;await lk();$('#login').classList.add('hidden');$('#app').classList.remove('hidden');$('#role').textContent=RL[U.Role]||U.Role;setMe();route()}
$('#lf').onsubmit=async e=>{e.preventDefault();try{await start(await api('login',{body:{username:e.target.u.value,password:e.target.p.value}}));e.target.p.value=''}catch(x){toast(x.message,1)}};
$('#um').onclick=async e=>{if(e.target.id=='lo'){e.preventDefault();try{await api('logout',{body:{}})}catch{}showLogin()}else if(e.target.id=='pe'){e.preventDefault();$('#umenu').classList.add('hidden');profileEditDlg()}else if(e.target.id=='chp'){e.preventDefault();$('#umenu').classList.add('hidden');photoDlg('users',U.UserID,U.PhotoFile,async()=>{const r=await api('me');U=r.user;setMe()})}else $('#umenu').classList.toggle('hidden')};
$('#mn').onclick=e=>{const b=e.target.closest('[data-g]');if(b)b.parentElement.classList.toggle('open')};
$('#bell').onclick=notifDlg;
$('#gs').onkeydown=e=>{if(e.key=='Enter'&&U&&can('students.r')){window.__q=e.target.value;go('students')}};
const tick=()=>{const d=new Date();let t='';try{const f=new Intl.DateTimeFormat('fa-AF-u-ca-persian',{weekday:'long'}),g=new Intl.DateTimeFormat('fa-AF-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'});t=f.format(d)+'، '+g.format(d).replace(/-/g,'/')}catch{t=d.toLocaleDateString()}$('#dd').textContent=t;$('#tt').textContent=d.toLocaleTimeString('en-US')};
setInterval(tick,1000);tick();
$('#rf').onclick=()=>U&&route();
$('#menu').onclick=()=>document.body.classList.toggle('open');
addEventListener('hashchange',()=>U&&route());
api('me').then(r=>r.user?start(r):showLogin()).catch(()=>showLogin());
