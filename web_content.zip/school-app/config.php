<?php
// د ډیټابیس تنظیمات - دلته خپلې معلومات ولیکئ
const DB_SERVER='localhost';   // یا localhost\SQLEXPRESS
const DB_NAME='HussainKhelSchool';
const DB_USER='school_app';
const DB_PASS='CHANGE_ME';
const BACKUP_DIR='C:\\SchoolBackups';   // فولډر باید SQL Server ته د Write اجازه ولري
function db():PDO{static $p=null;
 return $p??=new PDO('sqlsrv:Server='.DB_SERVER.';Database='.DB_NAME.';TrustServerCertificate=1;LoginTimeout=5',DB_USER,DB_PASS,[
  PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::SQLSRV_ATTR_ENCODING=>PDO::SQLSRV_ENCODING_UTF8]);}
