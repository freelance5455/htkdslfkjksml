<?php
// لومړی مدیر جوړوي. یوازې له ورته کمپیوټر څخه کار کوي. وروسته دا فایل ړنګ کړئ.
require __DIR__.'/config.php';
if(!in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1']))exit('Forbidden');
if((int)db()->query("SELECT COUNT(*) FROM Users WHERE RoleID=1")->fetchColumn()>0)exit('Admin already exists. Delete setup.php');
$m='';
if($_SERVER['REQUEST_METHOD']==='POST'){$u=trim($_POST['u']??'');$p=$_POST['p']??'';$fn=trim($_POST['n']??'')?:'امان الله هوتک';
 if($u===''||strlen($p)<8)$m='کارن نوم ولیکئ او پاسورډ لږ تر لږه ۸ توري وي';
 else{db()->prepare("INSERT INTO Users (Username,PasswordHash,RoleID,FullName,PhotoFile) VALUES (?,?,1,?,?)")->execute([$u,password_hash($p,PASSWORD_DEFAULT),$fn,'uploads/users/amanullah.png']);exit('Done. Delete setup.php, then open index.html');}}
?><!doctype html><html dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font:16px sans-serif;max-width:320px;margin:10vh auto">
<h3>د لومړي مدیر جوړول</h3><p style="color:#b42318"><?=htmlspecialchars($m)?></p>
<form method="post"><p><input name="n" placeholder="بشپړ نوم" value="امان الله هوتک" style="width:100%;padding:8px"></p><p><input name="u" placeholder="کارن نوم" style="width:100%;padding:8px"></p><p><input name="p" type="password" placeholder="پاسورډ (8+)" style="width:100%;padding:8px"></p><button style="padding:8px 16px">جوړول</button></form></body></html>
