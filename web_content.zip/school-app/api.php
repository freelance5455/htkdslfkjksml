<?php
require __DIR__.'/config.php';
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]);
session_start();
header('Content-Type: application/json; charset=utf-8');
function out($d,$c=200){http_response_code($c);echo json_encode($d,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function fail($m,$c=400){out(['error'=>$m],$c);}
function q($sql,$a=[]){$s=db()->prepare($sql);$s->execute($a);return $s;}
function hist($sid,$t,$n=null){global $u;q('INSERT INTO StudentHistory (StudentID,EventType,Note,CreatedBy) VALUES (?,?,?,?)',[(int)$sid,$t,$n,$u['UserID']]);}
function bdata($cid,$yid,$xid){
 $x=q('SELECT ExamID,ExamName,ExamType,MaxScore,PassMark FROM Exams WHERE ExamID=?',[$xid])->fetch();$c=q('SELECT Grade,Section FROM Classes WHERE ClassID=?',[$cid])->fetch();$y=q('SELECT YearName FROM AcademicYears WHERE YearID=?',[$yid])->fetchColumn();
 if(!$x||!$c||$y===false)fail('ازموینه، ټولګی یا کال نشته',404);
 $st=q("SELECT e.EnrollmentID,s.StudentCode,s.FirstName+N' '+s.FatherName name,s.PhotoFile FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID WHERE e.ClassID=? AND e.YearID=? AND e.Status NOT IN (N'Transferred',N'Dropped') ORDER BY s.FirstName,s.FatherName",[$cid,$yid])->fetchAll();
 $gr=q('SELECT g.EnrollmentID,g.SubjectID,sb.SubjectName,g.Score FROM Grades g JOIN Enrollments e ON e.EnrollmentID=g.EnrollmentID JOIN Subjects sb ON sb.SubjectID=g.SubjectID WHERE e.ClassID=? AND e.YearID=? AND g.ExamID=?',[$cid,$yid,$xid])->fetchAll();
 $subs=[];$sc=[];foreach($gr as $g){$subs[(int)$g['SubjectID']]=$g['SubjectName'];$sc[$g['EnrollmentID']][(int)$g['SubjectID']]=(float)$g['Score'];}
 asort($subs);$mx=(float)$x['MaxScore'];$pm=(float)$x['PassMark'];$rows=[];
 foreach($st as $s){$v=$sc[$s['EnrollmentID']]??[];$t=array_sum($v);$n=count($v);$fl=0;foreach($v as $z)if($z*100/$mx<$pm)$fl++;
  $rows[]=['code'=>$s['StudentCode'],'name'=>$s['name'],'photo'=>$s['PhotoFile'],'scores'=>(object)$v,'total'=>$t,'n'=>$n,'pct'=>$n?round($t*100/($n*$mx),1):null,'failed'=>$fl,'result'=>$n?($fl?'ناکام':'بریالی'):'—'];}
 $tots=array_column(array_filter($rows,fn($r)=>$r['n']>0),'total');
 foreach($rows as &$r)$r['rank']=$r['n']?1+count(array_filter($tots,fn($t)=>$t>$r['total'])):null;unset($r);
 $done=array_values(array_filter($rows,fn($r)=>$r['n']>0));$pass=count(array_filter($done,fn($r)=>$r['failed']==0));
 return ['class'=>$c['Grade'].'-'.$c['Section'],'year'=>$y,'exam'=>['id'=>$xid,'name'=>$x['ExamName'],'type'=>$x['ExamType'],'max'=>$mx,'pass'=>$pm],
  'subjects'=>array_map(fn($id,$n)=>['id'=>$id,'name'=>$n],array_keys($subs),array_values($subs)),'rows'=>$rows,
  'stats'=>['count'=>count($rows),'graded'=>count($done),'pass'=>$pass,'fail'=>count($done)-$pass,'avg'=>$done?round(array_sum(array_column($done,'pct'))/count($done),1):0]];}
function bstore($cid,$yid,$xid,$d){global $u;$t='خبرپاڼه - '.$d['class'].' - '.$d['exam']['name'].' - '.$d['year'];$j=json_encode($d,JSON_UNESCAPED_UNICODE);
 $n=q('UPDATE ResultBulletins SET Title=?,StudentCount=?,PassCount=?,DataJson=?,GeneratedAt=SYSDATETIME(),GeneratedBy=? WHERE ClassID=? AND YearID=? AND ExamID=?',[$t,$d['stats']['graded'],$d['stats']['pass'],$j,$u['UserID'],$cid,$yid,$xid])->rowCount();
 if(!$n)q('INSERT INTO ResultBulletins (ClassID,YearID,ExamID,Title,StudentCount,PassCount,DataJson,GeneratedBy) VALUES (?,?,?,?,?,?,?,?)',[$cid,$yid,$xid,$t,$d['stats']['graded'],$d['stats']['pass'],$j,$u['UserID']]);}
function iv($k){$v=$_GET[$k]??'';if(!ctype_digit((string)$v))fail("ناسم $k");return (int)$v;}
function okd($v){$x=DateTime::createFromFormat('!Y-m-d',(string)$v);return $x&&$x->format('Y-m-d')===$v;}
function has($p){global $u;return in_array($p,$u['perms']??[],true);}
function need($p){if(!has($p))fail('دا کار ته اجازه نشته',403);}
function audit($a,$t,$id=null,$d=null){global $u;try{q('INSERT INTO AuditLogs (UserID,Action,TableName,RecordID,Detail,IP) VALUES (?,?,?,?,?,?)',[$u['UserID']??null,$a,$t,$id,$d===null?null:json_encode($d,JSON_UNESCAPED_UNICODE),$_SERVER['REMOTE_ADDR']??null]);}catch(Throwable $x){error_log((string)$x);}}
function ent(){global $E;return $E[$_GET['entity']??'']??fail('نه شته',404);}
function cv($n,$d,$v){[$t,$p,$r]=$d;
 if($v===null||$v===''){if($r==1)fail("اړین ډګر ډک کړئ: $n");return null;}
 if($t=='b')return filter_var($v,FILTER_VALIDATE_BOOLEAN)?1:0;
 if($t=='s'){$v=trim((string)$v);if(mb_strlen($v)>$p)fail("$n ډېر اوږد دی");return $v;}
 if($t=='d'){if(!okd($v))fail("$n نېټه ناسمه ده");return $v;}
 if($t=='e'){if(!in_array($v,$p,true))fail("$n ناسم دی");return $v;}
 if(!is_numeric($v)||($p&&($v<$p[0]||$v>$p[1])))fail("$n ناسم دی");
 return $t=='i'?(int)$v:(float)$v;}
set_exception_handler(function($x){$n=$x instanceof PDOException?($x->errorInfo[1]??0):0;
 if($n==547)fail(stripos($x->getMessage(),'DELETE')!==false?'دا ریکارډ په نورو برخو کې کارول شوی، حذف نشي':'ورکړل شوي معلومات سم نه دي');
 if(in_array($n,[2627,2601]))fail('دا ریکارډ مخکې شته');
 error_log((string)$x);fail('د سرور تېروتنه',500);});

$act=$_GET['action']??'';$post=$_SERVER['REQUEST_METHOD']==='POST';
$b=$post?(json_decode(file_get_contents('php://input'),true)?:[]):[];
if($post&&$act!=='login'&&!hash_equals($_SESSION['csrf']??'-',$_SERVER['HTTP_X_CSRF_TOKEN']??''))fail('غیر مجاز غوښتنه',403);

if($act=='login'&&$post){
 if(($_SESSION['fails']??0)>=5&&time()-($_SESSION['ft']??0)<300)fail('ډېرې هڅې وشوې، ۵ دقیقې وروسته هڅه وکړئ',429);
 $r=q('SELECT u.UserID,u.Username,u.PasswordHash,u.TeacherID,u.RoleID,u.PhotoFile,u.FullName,r.RoleName Role FROM Users u JOIN Roles r ON r.RoleID=u.RoleID WHERE u.Username=? AND u.IsActive=1',[trim((string)($b['username']??''))])->fetch();
 if(!$r||!password_verify((string)($b['password']??''),$r['PasswordHash'])){$_SESSION['fails']=($_SESSION['fails']??0)+1;$_SESSION['ft']=time();fail('د کارن نوم یا پاسورډ ناسم دی',401);}
 session_regenerate_id(true);unset($r['PasswordHash']);$r['perms']=q('SELECT p.Code FROM RolePermissions rp JOIN Permissions p ON p.PermissionID=rp.PermissionID WHERE rp.RoleID=?',[$r['RoleID']])->fetchAll(PDO::FETCH_COLUMN);
 $_SESSION=['user'=>$r,'csrf'=>bin2hex(random_bytes(32))];$u=$r;audit('login','Users',$r['UserID']);
 out(['user'=>$r,'csrf'=>$_SESSION['csrf']]);}
if($act=='me')out(['user'=>$_SESSION['user']??null,'csrf'=>$_SESSION['csrf']??'']);
$u=$_SESSION['user']??null;if(!$u)fail('لومړی ننوځئ',401);
if($act=='logout'&&$post){session_destroy();out(['ok'=>1]);}

$cls=['Male','Female'];
$E=[
'students'=>['t'=>'Students','k'=>'StudentID','from'=>'Students s','o'=>'s.StudentID DESC',
 'f'=>"s.StudentID,s.FirstName,s.FatherName,s.GrandfatherName,CONVERT(varchar(10),s.BirthDate,23) BirthDate,s.Gender,s.Phone,s.Address,s.GuardianName,s.GuardianPhone,CONVERT(varchar(10),s.AdmissionDate,23) AdmissionDate,s.StudentCode,s.FatherOccupation,s.FatherPhone,s.PermanentAddress,s.PhotoFile,s.IsActive",
 's'=>['s.FirstName','s.FatherName','s.Phone','s.StudentCode'],'fl'=>['IsActive'=>'s.IsActive','StudentID'=>'s.StudentID'],
 'c'=>['FirstName'=>['s',100,1],'FatherName'=>['s',100,1],'GrandfatherName'=>['s',100,0],'BirthDate'=>['d',0,0],'Gender'=>['e',$cls,1],'Phone'=>['s',20,0],'Address'=>['s',200,0],'GuardianName'=>['s',100,0],'GuardianPhone'=>['s',20,0],'AdmissionDate'=>['d',0,2],'FatherOccupation'=>['s',100,0],'FatherPhone'=>['s',20,0],'PermanentAddress'=>['s',200,0],'IsActive'=>['b',0,2]]],
'teachers'=>['t'=>'Teachers','k'=>'TeacherID','from'=>'Teachers t','o'=>'t.TeacherID DESC',
 'f'=>"t.TeacherID,t.FullName,t.FatherName,t.Gender,t.Specialty,t.Education,t.Phone,t.Address,CONVERT(varchar(10),t.HireDate,23) HireDate,t.BaseSalary,t.PhotoFile,t.IsActive",
 's'=>['t.FullName','t.Phone'],'fl'=>['TeacherID'=>'t.TeacherID'],
 'c'=>['FullName'=>['s',100,1],'FatherName'=>['s',100,0],'Gender'=>['e',$cls,0],'Specialty'=>['s',100,0],'Education'=>['s',100,0],'Phone'=>['s',20,0],'Address'=>['s',200,0],'HireDate'=>['d',0,0],'BaseSalary'=>['n',[0,1e9],0],'IsActive'=>['b',0,2]]],
'classes'=>['t'=>'Classes','k'=>'ClassID','from'=>'Classes c LEFT JOIN Teachers t ON t.TeacherID=c.HomeroomTeacherID','o'=>'c.Grade,c.Section',
 'f'=>'c.ClassID,c.Grade,c.Section,c.HomeroomTeacherID,t.FullName HomeroomName','s'=>['c.Section'],'fl'=>['Grade'=>'c.Grade'],
 'c'=>['Grade'=>['i',[1,12],1],'Section'=>['s',10,1],'HomeroomTeacherID'=>['i',0,0]]],
'subjects'=>['t'=>'Subjects','k'=>'SubjectID','from'=>'Subjects b','o'=>'b.SubjectName',
 'f'=>'b.SubjectID,b.SubjectName,b.WeeklyHours','s'=>['b.SubjectName'],'fl'=>[],
 'c'=>['SubjectName'=>['s',100,1],'WeeklyHours'=>['i',[1,40],0]]],
'years'=>['t'=>'AcademicYears','k'=>'YearID','from'=>'AcademicYears y','o'=>'y.YearID DESC',
 'f'=>"y.YearID,y.YearName,CONVERT(varchar(10),y.StartDate,23) StartDate,CONVERT(varchar(10),y.EndDate,23) EndDate,y.IsCurrent",'s'=>['y.YearName'],'fl'=>[],
 'c'=>['YearName'=>['s',20,1],'StartDate'=>['d',0,1],'EndDate'=>['d',0,1],'IsCurrent'=>['b',0,2]]],
'enrollments'=>['t'=>'Enrollments','k'=>'EnrollmentID','from'=>'Enrollments e JOIN Students s ON s.StudentID=e.StudentID JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID','o'=>'y.YearID DESC,c.Grade,s.FirstName,e.EnrollmentID',
 'f'=>"e.EnrollmentID,e.StudentID,e.ClassID,e.YearID,s.FirstName+N' '+s.FatherName StudentName,c.Grade,c.Section,y.YearName,CONVERT(varchar(10),e.EnrollDate,23) EnrollDate,e.Status",
 's'=>['s.FirstName','s.FatherName'],'fl'=>['ClassID'=>'e.ClassID','YearID'=>'e.YearID','StudentID'=>'e.StudentID'],
 'c'=>['StudentID'=>['i',0,1],'ClassID'=>['i',0,1],'YearID'=>['i',0,1],'EnrollDate'=>['d',0,2],'Status'=>['e',['Active','Promoted','Repeated','Graduated','Transferred','Dropped'],2]]],
'assign'=>['t'=>'TeachingAssignments','k'=>'AssignmentID','from'=>'TeachingAssignments a JOIN Teachers t ON t.TeacherID=a.TeacherID JOIN Subjects b ON b.SubjectID=a.SubjectID JOIN Classes c ON c.ClassID=a.ClassID JOIN AcademicYears y ON y.YearID=a.YearID','o'=>'y.YearID DESC,c.Grade,a.AssignmentID',
 'f'=>'a.AssignmentID,a.TeacherID,a.SubjectID,a.ClassID,a.YearID,t.FullName,b.SubjectName,c.Grade,c.Section,y.YearName',
 's'=>['t.FullName','b.SubjectName'],'fl'=>['ClassID'=>'a.ClassID','YearID'=>'a.YearID','TeacherID'=>'a.TeacherID'],
 'c'=>['TeacherID'=>['i',0,1],'SubjectID'=>['i',0,1],'ClassID'=>['i',0,1],'YearID'=>['i',0,1]]],
'exams'=>['t'=>'Exams','k'=>'ExamID','from'=>'Exams x JOIN AcademicYears y ON y.YearID=x.YearID','o'=>'x.ExamID DESC',
 'f'=>"x.ExamID,x.ExamName,x.ExamType,x.YearID,y.YearName,CONVERT(varchar(10),x.ExamDate,23) ExamDate,x.MaxScore,x.PassMark",'s'=>['x.ExamName'],'fl'=>['YearID'=>'x.YearID'],
 'c'=>['ExamName'=>['s',100,1],'ExamType'=>['e',['Monthly','FourMonth','Midterm','Final'],1],'YearID'=>['i',0,1],'ExamDate'=>['d',0,0],'MaxScore'=>['n',[1,100],2],'PassMark'=>['n',[0,100],2]]],
'users'=>['t'=>'Users','k'=>'UserID','from'=>'Users u JOIN Roles r ON r.RoleID=u.RoleID','o'=>'u.UserID',
 'f'=>'u.UserID,u.Username,u.FullName,u.RoleID,u.PhotoFile,r.RoleName,u.TeacherID,u.IsActive','s'=>['u.Username','u.FullName'],'fl'=>[],
 'c'=>['Username'=>['s',50,1],'FullName'=>['s',100,0],'RoleID'=>['i',0,1],'TeacherID'=>['i',0,0],'IsActive'=>['b',0,2]]],
'guardians'=>['t'=>'Guardians','k'=>'GuardianID','from'=>'Guardians g JOIN Students s ON s.StudentID=g.StudentID','o'=>'g.GuardianID DESC',
 'f'=>"g.GuardianID,g.StudentID,s.FirstName+N' '+s.FatherName StudentName,g.FullName,g.Relation,g.Phone,g.Address,g.IsPrimary",'s'=>['g.FullName','s.FirstName','g.Phone'],'fl'=>['StudentID'=>'g.StudentID'],
 'c'=>['StudentID'=>['i',0,1],'FullName'=>['s',100,1],'Relation'=>['s',50,0],'Phone'=>['s',20,0],'Address'=>['s',200,0],'IsPrimary'=>['b',0,2]]],
'employees'=>['t'=>'Employees','k'=>'EmployeeID','from'=>'Employees e','o'=>'e.EmployeeID DESC',
 'f'=>"e.EmployeeID,e.FullName,e.FatherName,e.Position,e.Phone,e.Address,CONVERT(varchar(10),e.HireDate,23) HireDate,e.BaseSalary,e.PhotoFile,e.IsActive",'s'=>['e.FullName','e.Position'],'fl'=>['EmployeeID'=>'e.EmployeeID'],
 'c'=>['FullName'=>['s',100,1],'FatherName'=>['s',100,0],'Position'=>['s',100,0],'Phone'=>['s',20,0],'Address'=>['s',200,0],'HireDate'=>['d',0,0],'BaseSalary'=>['n',[0,1e9],0],'IsActive'=>['b',0,2]]],
'classsubjects'=>['t'=>'ClassSubjects','k'=>'ClassSubjectID','from'=>'ClassSubjects cs JOIN Classes c ON c.ClassID=cs.ClassID JOIN Subjects b ON b.SubjectID=cs.SubjectID','o'=>'c.Grade,b.SubjectName',
 'f'=>'cs.ClassSubjectID,cs.ClassID,cs.SubjectID,c.Grade,c.Section,b.SubjectName','s'=>['b.SubjectName'],'fl'=>['ClassID'=>'cs.ClassID'],
 'c'=>['ClassID'=>['i',0,1],'SubjectID'=>['i',0,1]]],
'feetypes'=>['t'=>'FeeTypes','k'=>'FeeTypeID','from'=>'FeeTypes ft','o'=>'ft.FeeName','f'=>'ft.FeeTypeID,ft.FeeName,ft.DefaultAmount','s'=>['ft.FeeName'],'fl'=>['StudentID'=>'g.StudentID'],
 'c'=>['FeeName'=>['s',100,1],'DefaultAmount'=>['n',[0,1e9],0]]],
'studentfees'=>['t'=>'StudentFees','k'=>'StudentFeeID','from'=>'StudentFees sf JOIN Enrollments e ON e.EnrollmentID=sf.EnrollmentID JOIN Students s ON s.StudentID=e.StudentID JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID JOIN FeeTypes ft ON ft.FeeTypeID=sf.FeeTypeID','o'=>'sf.StudentFeeID DESC',
 'f'=>"sf.StudentFeeID,sf.EnrollmentID,sf.FeeTypeID,s.FirstName+N' '+s.FatherName StudentName,c.Grade,c.Section,y.YearName,ft.FeeName,sf.Amount,(SELECT ISNULL(SUM(p.Amount),0) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID) Paid,CONVERT(varchar(10),sf.DueDate,23) DueDate,sf.Note",
 's'=>['s.FirstName','s.FatherName'],'fl'=>['ClassID'=>'e.ClassID','YearID'=>'e.YearID','FeeTypeID'=>'sf.FeeTypeID'],
 'c'=>['EnrollmentID'=>['i',0,1],'FeeTypeID'=>['i',0,1],'Amount'=>['n',[0,1e9],1],'DueDate'=>['d',0,0],'Note'=>['s',200,0]]],
'payments'=>['t'=>'Payments','k'=>'PaymentID','from'=>'Payments p JOIN StudentFees sf ON sf.StudentFeeID=p.StudentFeeID JOIN Enrollments e ON e.EnrollmentID=sf.EnrollmentID JOIN Students s ON s.StudentID=e.StudentID JOIN FeeTypes ft ON ft.FeeTypeID=sf.FeeTypeID','o'=>'p.PaymentID DESC','auto'=>['ReceivedBy'],
 'f'=>"p.PaymentID,p.StudentFeeID,s.FirstName+N' '+s.FatherName StudentName,ft.FeeName,p.Amount,CONVERT(varchar(10),p.PayDate,23) PayDate,p.Method,p.ReceiptNo",'s'=>['s.FirstName','s.FatherName','p.ReceiptNo'],'fl'=>[],
 'c'=>['StudentFeeID'=>['i',0,1],'Amount'=>['n',[0.01,1e9],1],'PayDate'=>['d',0,2],'Method'=>['e',['Cash','Bank','Mobile'],2],'ReceiptNo'=>['s',30,0]]],
'expcats'=>['t'=>'ExpenseCategories','k'=>'CategoryID','from'=>'ExpenseCategories ec','o'=>'ec.CategoryName','f'=>'ec.CategoryID,ec.CategoryName','s'=>['ec.CategoryName'],'fl'=>[],
 'c'=>['CategoryName'=>['s',100,1]]],
'expenses'=>['t'=>'Expenses','k'=>'ExpenseID','from'=>'Expenses x JOIN ExpenseCategories ec ON ec.CategoryID=x.CategoryID','o'=>'x.ExpenseID DESC','auto'=>['CreatedBy'],
 'f'=>"x.ExpenseID,x.CategoryID,ec.CategoryName,x.Amount,CONVERT(varchar(10),x.ExpDate,23) ExpDate,x.Description",'s'=>['x.Description','ec.CategoryName'],'fl'=>['CategoryID'=>'x.CategoryID'],
 'c'=>['CategoryID'=>['i',0,1],'Amount'=>['n',[0.01,1e9],1],'ExpDate'=>['d',0,2],'Description'=>['s',200,0]]],
'salaries'=>['t'=>'SalaryPayments','k'=>'SalaryID','from'=>'SalaryPayments sp LEFT JOIN Teachers t ON t.TeacherID=sp.TeacherID LEFT JOIN Employees em ON em.EmployeeID=sp.EmployeeID','o'=>'sp.SalaryID DESC',
 'f'=>"sp.SalaryID,sp.TeacherID,sp.EmployeeID,ISNULL(t.FullName,em.FullName) PersonName,sp.PayMonth,sp.BaseAmount,sp.Bonus,sp.Deduction,sp.NetAmount,CONVERT(varchar(10),sp.PayDate,23) PayDate,sp.Note",'s'=>['sp.PayMonth','t.FullName','em.FullName'],'fl'=>['TeacherID'=>'sp.TeacherID','EmployeeID'=>'sp.EmployeeID'],
 'c'=>['TeacherID'=>['i',0,0],'EmployeeID'=>['i',0,0],'PayMonth'=>['s',7,1],'BaseAmount'=>['n',[0,1e9],1],'Bonus'=>['n',[0,1e9],2],'Deduction'=>['n',[0,1e9],2],'PayDate'=>['d',0,2],'Note'=>['s',200,0]]],
'books'=>['t'=>'Books','k'=>'BookID','from'=>'Books b','o'=>'b.BookID DESC',
 'f'=>"b.BookID,b.Title,b.Author,b.Category,b.Copies,b.Copies-(SELECT COUNT(*) FROM BookLoans l WHERE l.BookID=b.BookID AND l.ReturnDate IS NULL) Available",'s'=>['b.Title','b.Author'],'fl'=>[],
 'c'=>['Title'=>['s',200,1],'Author'=>['s',100,0],'Category'=>['s',100,0],'Copies'=>['i',[0,100000],2]]],
'loans'=>['t'=>'BookLoans','k'=>'LoanID','from'=>'BookLoans l JOIN Books b ON b.BookID=l.BookID LEFT JOIN Students s ON s.StudentID=l.StudentID LEFT JOIN Teachers t ON t.TeacherID=l.TeacherID','o'=>'l.LoanID DESC',
 'f'=>"l.LoanID,l.BookID,l.StudentID,l.TeacherID,b.Title,ISNULL(s.FirstName+N' '+s.FatherName,t.FullName) Borrower,CONVERT(varchar(10),l.LoanDate,23) LoanDate,CONVERT(varchar(10),l.DueDate,23) DueDate,CONVERT(varchar(10),l.ReturnDate,23) ReturnDate",'s'=>['b.Title','s.FirstName','t.FullName'],'fl'=>['BookID'=>'l.BookID'],
 'c'=>['BookID'=>['i',0,1],'StudentID'=>['i',0,0],'TeacherID'=>['i',0,0],'LoanDate'=>['d',0,2],'DueDate'=>['d',0,1]]],
'history'=>['t'=>'StudentHistory','k'=>'HistoryID','perm'=>'students','auto'=>['CreatedBy'],'from'=>'StudentHistory h JOIN Students s ON s.StudentID=h.StudentID','o'=>'h.EventDate DESC,h.HistoryID DESC',
 'f'=>"h.HistoryID,h.StudentID,s.FirstName+N' '+s.FatherName StudentName,h.EventType,CONVERT(varchar(10),h.EventDate,23) EventDate,h.Note",'s'=>['h.Note','s.FirstName','s.FatherName'],'fl'=>['StudentID'=>'h.StudentID'],
 'c'=>['StudentID'=>['i',0,1],'EventType'=>['e',['Admission','Enrollment','Promotion','Transfer','Graduation','Deactivation','Reactivation','Other'],1],'EventDate'=>['d',0,2],'Note'=>['s',200,0]]],
'tdocs'=>['t'=>'TeacherDocuments','k'=>'DocID','perm'=>'teachers','from'=>'TeacherDocuments d JOIN Teachers t ON t.TeacherID=d.TeacherID','o'=>'d.DocID DESC',
 'f'=>"d.DocID,d.TeacherID,t.FullName PersonName,d.DocType,d.Title,d.IssuedBy,CONVERT(varchar(10),d.IssueDate,23) IssueDate,d.DocFile",'s'=>['d.Title','d.DocType','t.FullName'],'fl'=>['TeacherID'=>'d.TeacherID'],
 'c'=>['TeacherID'=>['i',0,1],'DocType'=>['s',50,1],'Title'=>['s',200,1],'IssuedBy'=>['s',100,0],'IssueDate'=>['d',0,0]]],
'timetable'=>['t'=>'Timetable','k'=>'SlotID','from'=>'Timetable tt JOIN Classes c ON c.ClassID=tt.ClassID JOIN Subjects b ON b.SubjectID=tt.SubjectID JOIN AcademicYears y ON y.YearID=tt.YearID LEFT JOIN Teachers t ON t.TeacherID=tt.TeacherID','o'=>'tt.DayOfWeek,tt.PeriodNo,tt.SlotID',
 'f'=>"tt.SlotID,tt.YearID,tt.ClassID,tt.DayOfWeek,tt.PeriodNo,tt.SubjectID,tt.TeacherID,c.Grade,c.Section,b.SubjectName,t.FullName TeacherName,y.YearName,LEFT(CONVERT(varchar(8),tt.StartTime,108),5) StartTime,LEFT(CONVERT(varchar(8),tt.EndTime,108),5) EndTime,tt.Room",'s'=>['b.SubjectName','t.FullName'],'fl'=>['ClassID'=>'tt.ClassID','YearID'=>'tt.YearID','TeacherID'=>'tt.TeacherID'],
 'c'=>['YearID'=>['i',0,1],'ClassID'=>['i',0,1],'DayOfWeek'=>['i',[0,6],1],'PeriodNo'=>['i',[1,12],1],'SubjectID'=>['i',0,1],'TeacherID'=>['i',0,0],'StartTime'=>['s',5,0],'EndTime'=>['s',5,0],'Room'=>['s',30,0]]],
'notices'=>['t'=>'Notices','k'=>'NoticeID','from'=>'Notices n','o'=>'n.NoticeID DESC','auto'=>['CreatedBy'],
 'f'=>"n.NoticeID,n.Title,n.Body,n.Audience,CONVERT(varchar(10),n.PublishDate,23) PublishDate,CONVERT(varchar(10),n.ExpiresOn,23) ExpiresOn,n.IsActive",'s'=>['n.Title','n.Body'],'fl'=>[],
 'c'=>['Title'=>['s',150,1],'Body'=>['s',1000,0],'Audience'=>['e',['All','Students','Teachers','Parents','Staff'],2],'PublishDate'=>['d',0,2],'ExpiresOn'=>['d',0,0],'IsActive'=>['b',0,2]]],
'sdocs'=>['t'=>'StudentDocuments','k'=>'DocID','from'=>'StudentDocuments d JOIN Students s ON s.StudentID=d.StudentID','o'=>'d.DocID DESC',
 'f'=>"d.DocID,d.StudentID,s.FirstName+N' '+s.FatherName StudentName,d.DocType,d.Title,CONVERT(varchar(10),d.IssueDate,23) IssueDate,d.DocFile",'s'=>['d.Title','d.DocType','s.FirstName','s.FatherName'],'fl'=>['StudentID'=>'d.StudentID'],
 'c'=>['StudentID'=>['i',0,1],'DocType'=>['s',50,1],'Title'=>['s',200,1],'IssueDate'=>['d',0,0]]],
'bulletins'=>['t'=>'ResultBulletins','k'=>'BulletinID','from'=>'ResultBulletins b JOIN Classes c ON c.ClassID=b.ClassID JOIN AcademicYears y ON y.YearID=b.YearID JOIN Exams x ON x.ExamID=b.ExamID','o'=>'y.YearID DESC,c.Grade,x.ExamID DESC',
 'f'=>"b.BulletinID,b.ClassID,b.YearID,b.ExamID,b.Title,c.Grade,c.Section,y.YearName,x.ExamName,b.StudentCount,b.PassCount,CONVERT(varchar(16),b.GeneratedAt,120) GeneratedAt",'s'=>['b.Title'],'fl'=>['ClassID'=>'b.ClassID','YearID'=>'b.YearID','ExamID'=>'b.ExamID'],'c'=>[]],
'leaves'=>['t'=>'LeaveRequests','k'=>'LeaveID','from'=>'LeaveRequests lv LEFT JOIN Teachers t ON t.TeacherID=lv.TeacherID LEFT JOIN Employees em ON em.EmployeeID=lv.EmployeeID','o'=>'lv.LeaveID DESC',
 'f'=>"lv.LeaveID,lv.TeacherID,lv.EmployeeID,ISNULL(t.FullName,em.FullName) PersonName,CONVERT(varchar(10),lv.StartDate,23) StartDate,CONVERT(varchar(10),lv.EndDate,23) EndDate,lv.Reason,lv.Status",'s'=>['t.FullName','em.FullName','lv.Reason'],'fl'=>['TeacherID'=>'lv.TeacherID','EmployeeID'=>'lv.EmployeeID'],
 'c'=>['TeacherID'=>['i',0,0],'EmployeeID'=>['i',0,0],'StartDate'=>['d',0,1],'EndDate'=>['d',0,1],'Reason'=>['s',200,0],'Status'=>['e',['Pending','Approved','Rejected'],2]]],
'jobs'=>['t'=>'JobHistory','k'=>'JobID','perm'=>'salaries','from'=>'JobHistory j LEFT JOIN Teachers t ON t.TeacherID=j.TeacherID LEFT JOIN Employees em ON em.EmployeeID=j.EmployeeID','o'=>'j.StartDate DESC,j.JobID DESC',
 'f'=>"j.JobID,j.TeacherID,j.EmployeeID,ISNULL(t.FullName,em.FullName) PersonName,j.Position,CONVERT(varchar(10),j.StartDate,23) StartDate,CONVERT(varchar(10),j.EndDate,23) EndDate,j.Note",'s'=>['j.Position','t.FullName','em.FullName'],'fl'=>['TeacherID'=>'j.TeacherID','EmployeeID'=>'j.EmployeeID'],
 'c'=>['TeacherID'=>['i',0,0],'EmployeeID'=>['i',0,0],'Position'=>['s',100,1],'StartDate'=>['d',0,1],'EndDate'=>['d',0,0],'Note'=>['s',200,0]]],
'roles'=>['t'=>'Roles','k'=>'RoleID','from'=>'Roles r','o'=>'r.RoleID','f'=>'r.RoleID,r.RoleName','s'=>['r.RoleName'],'fl'=>[],'c'=>['RoleName'=>['s',50,1]]],
'audit'=>['t'=>'AuditLogs','k'=>'LogID','ro'=>1,'from'=>'AuditLogs a LEFT JOIN Users u ON u.UserID=a.UserID','o'=>'a.LogID DESC',
 'f'=>"a.LogID,u.Username,a.Action,a.TableName,a.RecordID,a.Detail,CONVERT(varchar(19),a.CreatedAt,120) CreatedAt",'s'=>['a.Action','a.TableName','u.Username'],'fl'=>[],'c'=>[]],

];

if($act=='lookups')out([
 'classes'=>q('SELECT ClassID id,Grade,Section FROM Classes ORDER BY Grade,Section')->fetchAll(),
 'years'=>q('SELECT YearID id,YearName,IsCurrent FROM AcademicYears ORDER BY StartDate DESC')->fetchAll(),
 'subjects'=>q('SELECT SubjectID id,SubjectName FROM Subjects ORDER BY SubjectName')->fetchAll(),
 'teachers'=>q('SELECT TeacherID id,FullName FROM Teachers WHERE IsActive=1 ORDER BY FullName')->fetchAll(),
 'exams'=>q('SELECT ExamID id,ExamName,YearID,MaxScore FROM Exams ORDER BY ExamID DESC')->fetchAll(),
 'students'=>q("SELECT StudentID id,FirstName+N' - '+FatherName name FROM Students WHERE IsActive=1 ORDER BY FirstName,FatherName")->fetchAll(),
 'feetypes'=>has('studentfees.r')?q('SELECT FeeTypeID id,FeeName,DefaultAmount FROM FeeTypes ORDER BY FeeName')->fetchAll():[],
 'fees'=>has('payments.r')?q("SELECT sf.StudentFeeID id,s.FirstName+N' '+s.FatherName+N' - '+ft.FeeName+N' ('+CAST(sf.Amount-ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID),0) AS NVARCHAR(20))+N')' name FROM StudentFees sf JOIN Enrollments e ON e.EnrollmentID=sf.EnrollmentID JOIN Students s ON s.StudentID=e.StudentID JOIN FeeTypes ft ON ft.FeeTypeID=sf.FeeTypeID WHERE sf.Amount>ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID),0) ORDER BY s.FirstName")->fetchAll():[],
 'enr'=>(has('grades.r')||has('studentfees.r')||has('enrollments.r'))?q("SELECT e.EnrollmentID id,s.FirstName+N' '+s.FatherName+N' - '+CAST(c.Grade AS NVARCHAR(3))+N' '+c.Section+N' ('+y.YearName+N')' name FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID ORDER BY y.YearID DESC,c.Grade,s.FirstName")->fetchAll():[],
 'expcats'=>has('expenses.r')?q('SELECT CategoryID id,CategoryName FROM ExpenseCategories ORDER BY CategoryName')->fetchAll():[],
 'books'=>q('SELECT BookID id,Title FROM Books ORDER BY Title')->fetchAll(),
 'employees'=>(has('employees.r')||has('salaries.r'))?q('SELECT EmployeeID id,FullName FROM Employees WHERE IsActive=1 ORDER BY FullName')->fetchAll():[],
 'roles'=>has('roles.r')||has('users.r')?q('SELECT RoleID id,RoleName FROM Roles ORDER BY RoleID')->fetchAll():[]]);

if($act=='list'){$e=ent();need(($e['perm']??$_GET['entity']).'.r');$w=[];$a=[];$s=trim((string)($_GET['q']??''));
 if($s!==''){$w[]='('.implode(' OR ',array_map(fn($c)=>"$c LIKE ?",$e['s'])).')';foreach($e['s'] as $_)$a[]='%'.str_replace(['[','%','_'],['[[]','[%]','[_]'],$s).'%';}
 if(isset($_GET['id'])&&ctype_digit((string)$_GET['id'])){$w[]=explode(',',$e['f'])[0].'=?';$a[]=(int)$_GET['id'];}
 foreach($e['fl'] as $n=>$c)if(($_GET[$n]??'')!==''){if(!ctype_digit((string)$_GET[$n]))fail('ناسم فلټر');$w[]="$c=?";$a[]=(int)$_GET[$n];}
 $w=$w?' WHERE '.implode(' AND ',$w):'';$pg=max(1,(int)($_GET['page']??1));$off=($pg-1)*25;
 $tot=(int)q("SELECT COUNT(*) FROM {$e['from']}$w",$a)->fetchColumn();
 out(['total'=>$tot,'rows'=>q("SELECT {$e['f']} FROM {$e['from']}$w ORDER BY {$e['o']} OFFSET $off ROWS FETCH NEXT 25 ROWS ONLY",$a)->fetchAll()]);}

if($act=='save'&&$post){$e=ent();need(($e['perm']??$_GET['entity']).'.w');if(!empty($e['ro']))fail('بدلون نشي کېدلی',403);$ent=$_GET['entity'];$id=$b['id']??null;$dt=$b['data']??[];$c=[];
 foreach($e['c'] as $n=>$d){if($id!==null&&!array_key_exists($n,$dt))continue;$v=cv($n,$d,$dt[$n]??null);if($v===null&&($id===null||$d[2]==2))continue;$c[$n]=$v;}
 if($ent=='users'){$pw=(string)($dt['Password']??'');if(($id===null||$pw!=='')&&strlen($pw)<8)fail('پاسورډ لږ تر لږه ۸ توري وي');
  if($pw!=='')$c['PasswordHash']=password_hash($pw,PASSWORD_DEFAULT);
  if($id!==null&&(int)$id===(int)$u['UserID']&&isset($c['IsActive'])&&!$c['IsActive'])fail('خپل ځان نشئ بندولی');}
 foreach($e['auto']??[] as $n)if($id===null)$c[$n]=$u['UserID'];
 if($ent=='payments'){$sf=$c['StudentFeeID']??fail('فیس وټاکئ');$r=q('SELECT f.Amount-ISNULL((SELECT SUM(Amount) FROM Payments WHERE StudentFeeID=f.StudentFeeID AND PaymentID<>?),0) FROM StudentFees f WHERE f.StudentFeeID=?',[(int)($id??0),$sf])->fetchColumn();if($r===false||($c['Amount']??0)>$r)fail('تادیه د پاتې بیلانس ('.round((float)$r,2).') څخه ډېره ده');}
 if($ent=='salaries'){if(isset($c['TeacherID'])==isset($c['EmployeeID']))fail('یا ښوونکی یا کارکوونکی وټاکئ');if(isset($c['PayMonth'])&&!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$c['PayMonth']))fail('میاشت د YYYY-MM بڼه ولري');}
 if($ent=='loans'&&$id===null){if(isset($c['StudentID'])==isset($c['TeacherID']))fail('یا زده‌کوونکی یا ښوونکی وټاکئ');if((int)q('SELECT Copies-(SELECT COUNT(*) FROM BookLoans WHERE BookID=b.BookID AND ReturnDate IS NULL) FROM Books b WHERE BookID=?',[$c['BookID']])->fetchColumn()<1)fail('دا کتاب اوس شته نه دی');}
 if(($ent=='leaves'||$ent=='jobs')&&isset($c['TeacherID'])==isset($c['EmployeeID']))fail('یا ښوونکی یا کارکوونکی وټاکئ');
 if($ent=='timetable'){foreach(['StartTime','EndTime'] as $tn)if(isset($c[$tn])&&!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$c[$tn]))fail('وخت د HH:MM بڼه ولري');$cid=(int)($id??0);
 if(isset($c['ClassID'],$c['YearID'],$c['DayOfWeek'],$c['PeriodNo'])&&q('SELECT COUNT(*) FROM Timetable WHERE YearID=? AND ClassID=? AND DayOfWeek=? AND PeriodNo=? AND SlotID<>?',[$c['YearID'],$c['ClassID'],$c['DayOfWeek'],$c['PeriodNo'],$cid])->fetchColumn())fail('دا ټولګی په دې وخت کې مخکې مضمون لري');
 if(!empty($c['TeacherID'])&&isset($c['YearID'],$c['DayOfWeek'],$c['PeriodNo'])&&q('SELECT COUNT(*) FROM Timetable WHERE YearID=? AND TeacherID=? AND DayOfWeek=? AND PeriodNo=? AND SlotID<>?',[$c['YearID'],$c['TeacherID'],$c['DayOfWeek'],$c['PeriodNo'],$cid])->fetchColumn())fail('ښوونکی په دې وخت بل ټولګي کې مصروف دی');}
 if(!$c)fail('هېڅ معلومات نشته');
 $oldS=$ent=='students'&&$id!==null?q('SELECT IsActive FROM Students WHERE StudentID=?',[(int)$id])->fetchColumn():null;
 $olde=$ent=='enrollments'&&$id!==null?q('SELECT StudentID,Status FROM Enrollments WHERE EnrollmentID=?',[(int)$id])->fetch():null;
 $p=db();$p->beginTransaction();
 if($id===null)$id=q("INSERT INTO {$e['t']} (".implode(',',array_keys($c)).") OUTPUT INSERTED.{$e['k']} VALUES (".implode(',',array_fill(0,count($c),'?')).")",array_values($c))->fetchColumn();
 else q("UPDATE {$e['t']} SET ".implode(',',array_map(fn($k)=>"$k=?",array_keys($c)))." WHERE {$e['k']}=?",[...array_values($c),(int)$id]);
 if($ent=='years'&&!empty($c['IsCurrent']))q('UPDATE AcademicYears SET IsCurrent=0 WHERE YearID<>?',[(int)$id]);
 $p->commit();$d=$c;unset($d['PasswordHash']);audit($b['id']===null?'insert':'update',$e['t'],(int)$id,$d);
 if($ent=='students'){if($b['id']===null)hist($id,'Admission');elseif($oldS!==null&&isset($c['IsActive'])&&(int)$oldS!==(int)$c['IsActive'])hist($id,$c['IsActive']?'Reactivation':'Deactivation');}
 if($ent=='enrollments'){if($b['id']===null)hist($c['StudentID'],'Enrollment');elseif($olde&&isset($c['Status'])&&$c['Status']!==$olde['Status']){$mp=['Transferred'=>'Transfer','Graduated'=>'Graduation','Promoted'=>'Promotion','Dropped'=>'Deactivation','Active'=>'Reactivation'];hist($olde['StudentID'],$mp[$c['Status']]??'Other','حالت: '.$c['Status']);}}out(['id'=>$id]);}

if($act=='delete'&&$post){$e=ent();need(($e['perm']??$_GET['entity']).'.w');if(!empty($e['ro']))fail('بدلون نشي کېدلی',403);$id=(int)($b['id']??0);
 if($_GET['entity']=='users'&&$id===(int)$u['UserID'])fail('خپل ځان نشئ حذفولی');
 if($_GET['entity']=='roles'&&$id==1)fail('د مدیر رول نشي حذفېدلی');q("DELETE FROM {$e['t']} WHERE {$e['k']}=?",[$id]);audit('delete',$e['t'],$id);out(['ok'=>1]);}

if($act=='att_sheet'){need('attendance.r');$d=$_GET['date']??'';if(!okd($d))fail('نېټه ناسمه ده');
 out(['rows'=>q("SELECT e.EnrollmentID,s.FirstName+N' '+s.FatherName name,a.Status FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID LEFT JOIN Attendance a ON a.EnrollmentID=e.EnrollmentID AND a.AttDate=? WHERE e.ClassID=? AND e.YearID=? AND e.Status=N'Active' ORDER BY s.FirstName,s.FatherName",[$d,iv('class_id'),iv('year_id')])->fetchAll()]);}
if($act=='att_save'&&$post){need('attendance.w');$d=$b['date']??'';if(!okd($d))fail('نېټه ناسمه ده');
 $p=db();$p->beginTransaction();
 foreach($b['items']??[] as $it){$s=$it['Status']??'';if(!in_array($s,['P','A','L','E'],true))fail('ناسم حالت');$e=(int)$it['EnrollmentID'];
  q('DELETE FROM Attendance WHERE EnrollmentID=? AND AttDate=?',[$e,$d]);q('INSERT INTO Attendance (EnrollmentID,AttDate,Status) VALUES (?,?,?)',[$e,$d,$s]);}
 $p->commit();out(['ok'=>1]);}

if($act=='gr_sheet')need('grades.r');
if($act=='gr_sheet')out(['max'=>q('SELECT MaxScore FROM Exams WHERE ExamID=?',[iv('exam_id')])->fetchColumn(),
 'rows'=>q("SELECT e.EnrollmentID,s.FirstName+N' '+s.FatherName name,g.Score FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID LEFT JOIN Grades g ON g.EnrollmentID=e.EnrollmentID AND g.ExamID=? AND g.SubjectID=? WHERE e.ClassID=? AND e.YearID=? AND e.Status=N'Active' ORDER BY s.FirstName,s.FatherName",[iv('exam_id'),iv('subject_id'),iv('class_id'),iv('year_id')])->fetchAll()]);
if($act=='gr_save'&&$post){need('grades.w');$ex=(int)($b['exam_id']??0);$sb=(int)($b['subject_id']??0);
 $mx=q('SELECT MaxScore FROM Exams WHERE ExamID=?',[$ex])->fetchColumn();if($mx===false)fail('ازموینه نشته');
 $p=db();$p->beginTransaction();
 foreach($b['items']??[] as $it){$e=(int)$it['EnrollmentID'];$s=$it['Score']??'';
  q('DELETE FROM Grades WHERE EnrollmentID=? AND ExamID=? AND SubjectID=?',[$e,$ex,$sb]);if($s==='')continue;
  if(!is_numeric($s)||$s<0||$s>$mx)fail("نمره باید د ۰ او $mx ترمنځ وي");
  q('INSERT INTO Grades (EnrollmentID,ExamID,SubjectID,Score) VALUES (?,?,?,?)',[$e,$ex,$sb,(float)$s]);}
 $p->commit();
 try{$e0=(int)($b['items'][0]['EnrollmentID']??0);$r0=q('SELECT ClassID,YearID FROM Enrollments WHERE EnrollmentID=?',[$e0])->fetch();if($r0){$d=bdata((int)$r0['ClassID'],(int)$r0['YearID'],$ex);if($d['stats']['graded'])bstore((int)$r0['ClassID'],(int)$r0['YearID'],$ex,$d);}}catch(Throwable $x){error_log((string)$x);}
 out(['ok'=>1]);}

if($act=='dash')out([
 'students'=>(int)q('SELECT COUNT(*) FROM Students WHERE IsActive=1')->fetchColumn(),
 'teachers'=>(int)q('SELECT COUNT(*) FROM Teachers WHERE IsActive=1')->fetchColumn(),
 'grades'=>q("SELECT c.Grade,COUNT(*) n FROM Enrollments e JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID WHERE y.IsCurrent=1 AND e.Status=N'Active' GROUP BY c.Grade ORDER BY c.Grade")->fetchAll(),
 'att'=>q('SELECT Status,COUNT(*) n FROM Attendance WHERE AttDate=CAST(GETDATE() AS date) GROUP BY Status')->fetchAll(),
 'employees'=>(int)q('SELECT COUNT(*) FROM Employees WHERE IsActive=1')->fetchColumn(),'classes'=>(int)q('SELECT COUNT(*) FROM Classes')->fetchColumn(),
 'staff'=>q('SELECT Status,COUNT(*) n FROM StaffAttendance WHERE AttDate=CAST(GETDATE() AS date) GROUP BY Status')->fetchAll(),
 'exam'=>q('SELECT x.ExamName,COUNT(r.EnrollmentID) n,ISNULL(SUM(CASE WHEN r.pct>=x.PassMark THEN 1 ELSE 0 END),0) pass FROM (SELECT TOP 1 ExamID,ExamName,PassMark FROM Exams ORDER BY ExamID DESC) x LEFT JOIN (SELECT g.EnrollmentID,g.ExamID,AVG(g.Score*100.0/ex.MaxScore) pct FROM Grades g JOIN Exams ex ON ex.ExamID=g.ExamID GROUP BY g.EnrollmentID,g.ExamID) r ON r.ExamID=x.ExamID GROUP BY x.ExamName')->fetch()?:null,
  'new_students'=>(int)q('SELECT COUNT(*) FROM Students WHERE IsActive=1 AND YEAR(AdmissionDate)=YEAR(GETDATE())')->fetchColumn(),
 'new_teachers'=>(int)q('SELECT COUNT(*) FROM Teachers WHERE IsActive=1 AND YEAR(HireDate)=YEAR(GETDATE())')->fetchColumn(),
 'new_employees'=>(int)q('SELECT COUNT(*) FROM Employees WHERE IsActive=1 AND YEAR(HireDate)=YEAR(GETDATE())')->fetchColumn(),
 'gender'=>q('SELECT Gender,COUNT(*) n FROM Students WHERE IsActive=1 GROUP BY Gender')->fetchAll(),
 'cg'=>q("SELECT c.Grade,c.Section,SUM(CASE WHEN s.Gender='Male' THEN 1 ELSE 0 END) m,SUM(CASE WHEN s.Gender='Female' THEN 1 ELSE 0 END) f FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID WHERE y.IsCurrent=1 AND e.Status=N'Active' GROUP BY c.Grade,c.Section ORDER BY c.Grade,c.Section")->fetchAll(),
 'recent'=>q("SELECT TOP 5 s.StudentID,s.FirstName name,s.FatherName,CAST(c.Grade AS NVARCHAR(3))+N'-'+c.Section cls,CONVERT(varchar(10),e.EnrollDate,23) EnrollDate,e.Status FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID JOIN Classes c ON c.ClassID=e.ClassID ORDER BY e.EnrollmentID DESC")->fetchAll(),
 'subjects'=>(int)q('SELECT COUNT(*) FROM Subjects')->fetchColumn(),'guardians'=>(int)q('SELECT COUNT(*) FROM Guardians')->fetchColumn(),
 'exams_n'=>(int)q('SELECT COUNT(*) FROM Exams x JOIN AcademicYears y ON y.YearID=x.YearID WHERE y.IsCurrent=1')->fetchColumn(),
 'leaves_pending'=>has('leaves.r')?(int)q("SELECT COUNT(*) FROM LeaveRequests WHERE Status=N'Pending'")->fetchColumn():null,
 'overdue_loans'=>has('loans.r')?(int)q('SELECT COUNT(*) FROM BookLoans WHERE ReturnDate IS NULL AND DueDate<CAST(GETDATE() AS DATE)')->fetchColumn():null,
 'att7'=>q("SELECT CONVERT(varchar(10),AttDate,23) d,SUM(CASE WHEN Status='P' THEN 1 ELSE 0 END) p,SUM(CASE WHEN Status='A' THEN 1 ELSE 0 END) a,SUM(CASE WHEN Status='L' THEN 1 ELSE 0 END) l FROM Attendance WHERE AttDate>=DATEADD(day,-6,CAST(GETDATE() AS DATE)) GROUP BY AttDate ORDER BY AttDate")->fetchAll(),
 'money'=>0?q("SELECT (SELECT ISNULL(SUM(Amount),0) FROM Payments WHERE PayDate=CAST(GETDATE() AS DATE)) today_income,(SELECT ISNULL(SUM(Amount),0) FROM Expenses WHERE ExpDate=CAST(GETDATE() AS DATE)) today_expense,(SELECT ISNULL(SUM(Amount),0) FROM StudentFees)-(SELECT ISNULL(SUM(Amount),0) FROM Payments) outstanding,(SELECT COUNT(*) FROM StudentFees sf WHERE sf.Amount>ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID),0)) unpaid_n,(SELECT COUNT(*) FROM StudentFees sf WHERE sf.DueDate<CAST(GETDATE() AS DATE) AND sf.Amount>ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID),0)) overdue_n,(SELECT ISNULL(SUM(sf.Amount-ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID),0)),0) FROM StudentFees sf WHERE sf.DueDate<CAST(GETDATE() AS DATE) AND sf.Amount>ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID=sf.StudentFeeID),0)) overdue_amt")->fetch():null,
 'fee30'=>0?q("SELECT CONVERT(varchar(10),PayDate,23) d,SUM(Amount) s FROM Payments WHERE PayDate>=DATEADD(day,-29,CAST(GETDATE() AS DATE)) GROUP BY PayDate ORDER BY PayDate")->fetchAll():null,
 'fin'=>0?q('SELECT (SELECT ISNULL(SUM(Amount),0) FROM Payments WHERE PayDate>=DATEFROMPARTS(YEAR(GETDATE()),MONTH(GETDATE()),1)) income,(SELECT ISNULL(SUM(Amount),0) FROM Expenses WHERE ExpDate>=DATEFROMPARTS(YEAR(GETDATE()),MONTH(GETDATE()),1)) expense,(SELECT ISNULL(SUM(NetAmount),0) FROM SalaryPayments WHERE PayDate>=DATEFROMPARTS(YEAR(GETDATE()),MONTH(GETDATE()),1)) salary')->fetch():null]);

if($act=='role_perms'){need('roles.r');out(['rows'=>q('SELECT p.Code,CASE WHEN rp.RoleID IS NULL THEN 0 ELSE 1 END Granted FROM Permissions p LEFT JOIN RolePermissions rp ON rp.PermissionID=p.PermissionID AND rp.RoleID=? ORDER BY p.Code',[iv('role_id')])->fetchAll()]);}
if($act=='role_perms_save'&&$post){need('roles.w');$r=(int)($b['role_id']??0);if($r==1)fail('د مدیر صلاحیتونه نشي بدلېدلی');
 $p=db();$p->beginTransaction();q('DELETE FROM RolePermissions WHERE RoleID=?',[$r]);
 foreach($b['codes']??[] as $c)q('INSERT INTO RolePermissions (RoleID,PermissionID) SELECT ?,PermissionID FROM Permissions WHERE Code=?',[$r,(string)$c]);
 $p->commit();audit('role_perms','RolePermissions',$r,$b['codes']??[]);out(['ok'=>1]);}
if($act=='fee_bulk'&&$post){need('studentfees.w');$am=$b['Amount']??'';if(!is_numeric($am)||$am<=0)fail('اندازه ناسمه ده');$dd=($b['DueDate']??'')?:null;if($dd!==null&&!okd($dd))fail('نېټه ناسمه ده');
 $ft=(int)($b['FeeTypeID']??0);
 $s=q("INSERT INTO StudentFees (EnrollmentID,FeeTypeID,Amount,DueDate) SELECT e.EnrollmentID,?,CAST(? AS DECIMAL(12,2)),CAST(? AS DATE) FROM Enrollments e WHERE e.ClassID=? AND e.YearID=? AND e.Status=N'Active' AND NOT EXISTS(SELECT 1 FROM StudentFees f WHERE f.EnrollmentID=e.EnrollmentID AND f.FeeTypeID=?)",[$ft,(string)$am,$dd,(int)($b['ClassID']??0),(int)($b['YearID']??0),$ft]);
 audit('fee_bulk','StudentFees',null,$b);out(['count'=>$s->rowCount()]);}
if($act=='loan_return'&&$post){need('loans.w');$id=(int)($b['id']??0);q('UPDATE BookLoans SET ReturnDate=CAST(GETDATE() AS DATE) WHERE LoanID=? AND ReturnDate IS NULL',[$id]);audit('loan_return','BookLoans',$id);out(['ok'=>1]);}
$RP=['attendance'=>['EXEC sp_ClassAttendance ?,?,?,?',['class_id','year_id','from','to'],'attendance.r'],'card'=>['EXEC sp_StudentReportCard ?',['enrollment_id'],'grades.r'],
 'results'=>['EXEC sp_ClassResults ?,?,?',['class_id','year_id','exam_id'],'grades.r'],'defaulters'=>['EXEC sp_FeeDefaulters ?',['year_id'],'payments.r'],'finance'=>['EXEC sp_FinanceSummary ?,?',['from','to'],'payments.r'],
 'passfail'=>['EXEC sp_PassFailSummary ?,?',['year_id','exam_id'],'grades.r'],'staffatt'=>['EXEC sp_StaffAttendance ?,?',['from','to'],'staffatt.r']];
if($act=='report'){need('reports.r');$r=$RP[$_GET['name']??'']??fail('نه شته',404);need($r[2]);$a=[];
 foreach($r[1] as $n){$v=$_GET[$n]??'';if($n=='from'||$n=='to'){if(!okd($v))fail('نېټه ناسمه ده');}elseif(!ctype_digit((string)$v))fail("ناسم $n");$a[]=$v;}
 out(['rows'=>q($r[0],$a)->fetchAll()]);}
if($act=='backup_list'){need('backup.r');try{out(['rows'=>q("SELECT TOP 20 CONVERT(varchar(19),backup_finish_date,120) [نېټه],CASE type WHEN 'D' THEN N'Full' WHEN 'I' THEN N'Differential' WHEN 'L' THEN N'Log' END [ډول],CAST(backup_size/1048576.0 AS DECIMAL(10,1)) [MB] FROM msdb.dbo.backupset WHERE database_name=? ORDER BY backup_finish_date DESC",[DB_NAME])->fetchAll()]);}
 catch(Throwable $x){error_log((string)$x);out(['rows'=>[],'note'=>'د Backup تاریخچې لیدلو اجازه نشته']);}}
if($act=='backup_run'&&$post){need('backup.w');$sep=(strpos(BACKUP_DIR,'\\')!==false||strpos(BACKUP_DIR,':')!==false)?'\\':'/';
 $f=rtrim(BACKUP_DIR,'\\/').$sep.DB_NAME.'_'.date('Ymd_His').'.bak';
 $s=db()->prepare('BACKUP DATABASE ['.DB_NAME.'] TO DISK = ? WITH INIT, CHECKSUM');$s->execute([$f]);do{}while($s->nextRowset());
 audit('backup','Database',null,['file'=>$f]);out(['file'=>$f]);}

if($act=='upload'&&$post){$UP=['students'=>['Students','StudentID','PhotoFile',0],'teachers'=>['Teachers','TeacherID','PhotoFile',0],'employees'=>['Employees','EmployeeID','PhotoFile',0],'users'=>['Users','UserID','PhotoFile',0],'tdocs'=>['TeacherDocuments','DocID','DocFile',1],'sdocs'=>['StudentDocuments','DocID','DocFile',1]];
 $en=$_POST['entity']??'';$m=$UP[$en]??fail('نه شته',404);if(!($en=='users'&&(int)($_POST['id']??0)===(int)$u['UserID']))need(($E[$en]['perm']??$en).'.w');$id=(int)($_POST['id']??0);
 $f=$_FILES['file']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK||$f['size']>3*1048576)fail('فایل ناسم یا ډېر لوی دی (تر 3MB)');
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']+($m[3]?['application/pdf'=>'pdf']:[]);
 if(!isset($ext[$mime]))fail('یوازې عکس'.($m[3]?' یا PDF':'').' منل کېږي');
 $old=q("SELECT {$m[2]} FROM {$m[0]} WHERE {$m[1]}=?",[$id])->fetchColumn();if($old===false)fail('ریکارډ نشته',404);
 $dir=__DIR__.'/uploads/'.$en;if(!is_dir($dir))mkdir($dir,0755,true);$name=bin2hex(random_bytes(12)).'.'.$ext[$mime];
 if(!move_uploaded_file($f['tmp_name'],"$dir/$name"))fail('فایل ذخیره نشو',500);
 q("UPDATE {$m[0]} SET {$m[2]}=? WHERE {$m[1]}=?",["uploads/$en/$name",$id]);
 if($old)@unlink("$dir/".basename($old));if($en=='users'&&$id===(int)$u['UserID'])$_SESSION['user']['PhotoFile']="uploads/$en/$name";
 audit('upload',$m[0],$id);out(['file'=>"uploads/$en/$name"]);}
if($act=='student_years'){need('students.r');need('grades.r');$id=iv('id');
 out(['years'=>q("SELECT e.EnrollmentID,y.YearName,c.Grade,c.Section,e.Status,(SELECT COUNT(*) FROM Attendance a WHERE a.EnrollmentID=e.EnrollmentID AND a.Status='P') Present,(SELECT COUNT(*) FROM Attendance a WHERE a.EnrollmentID=e.EnrollmentID AND a.Status='A') Absent FROM Enrollments e JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID WHERE e.StudentID=? ORDER BY y.StartDate DESC",[$id])->fetchAll(),
 'exams'=>q("SELECT g.EnrollmentID,ex.ExamID,ex.ExamName,ex.ExamType,ex.PassMark,SUM(g.Score) Total,SUM(ex.MaxScore) MaxTotal,AVG(g.Score*100.0/ex.MaxScore) Pct FROM Grades g JOIN Exams ex ON ex.ExamID=g.ExamID JOIN Enrollments e ON e.EnrollmentID=g.EnrollmentID WHERE e.StudentID=? GROUP BY g.EnrollmentID,ex.ExamID,ex.ExamName,ex.ExamType,ex.PassMark ORDER BY ex.ExamID",[$id])->fetchAll()]);}
if($act=='report_card'){need('grades.r');$en=iv('enrollment_id');$ex=iv('exam_id');
 $st=q("SELECT s.StudentCode code,s.FirstName+N' '+s.FatherName name,s.FatherName father,s.PhotoFile,c.Grade grade,c.Section section,y.YearName year,e.ClassID,e.YearID FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID JOIN Classes c ON c.ClassID=e.ClassID JOIN AcademicYears y ON y.YearID=e.YearID WHERE e.EnrollmentID=?",[$en])->fetch()?:fail('نه شته',404);
 $x=q('SELECT ExamName name,PassMark,MaxScore FROM Exams WHERE ExamID=?',[$ex])->fetch()?:fail('ازموینه نشته',404);
 $rows=q("SELECT sb.SubjectName [مضمون],g.Score [نمره],ex.MaxScore [اعظمي],CAST(g.Score*100.0/ex.MaxScore AS DECIMAL(5,1)) [فیصدي],CASE WHEN g.Score*100.0/ex.MaxScore>=ex.PassMark THEN N'بریالی' ELSE N'ناکام' END [نتیجه] FROM Grades g JOIN Exams ex ON ex.ExamID=g.ExamID JOIN Subjects sb ON sb.SubjectID=g.SubjectID WHERE g.EnrollmentID=? AND g.ExamID=? ORDER BY sb.SubjectName",[$en,$ex])->fetchAll();
 $rk=q("WITH r AS (SELECT g.EnrollmentID,AVG(g.Score*100.0/ex.MaxScore) pct,SUM(g.Score) tot,SUM(ex.MaxScore) mx FROM Grades g JOIN Exams ex ON ex.ExamID=g.ExamID JOIN Enrollments e ON e.EnrollmentID=g.EnrollmentID WHERE g.ExamID=? AND e.ClassID=? AND e.YearID=? GROUP BY g.EnrollmentID),k AS (SELECT *,RANK() OVER (ORDER BY pct DESC) rk,COUNT(*) OVER () n FROM r) SELECT * FROM k WHERE EnrollmentID=?",[$ex,$st['ClassID'],$st['YearID'],$en])->fetch();
 $pct=$rk?round((float)$rk['pct'],1):0;
 out(['student'=>$st,'exam'=>$x,'rows'=>$rows,'sum'=>['total'=>(float)($rk['tot']??0),'maxTotal'=>(float)($rk['mx']??0),'pct'=>$pct,'rank'=>$rk['rk']??'-','count'=>$rk['n']??0,'pass'=>count($rows)>0&&$pct>=(float)$x['PassMark']]]);}
if($act=='staff_sheet'){need('staffatt.r');$d=$_GET['date']??'';if(!okd($d))fail('نېټه ناسمه ده');
 out(['rows'=>q("SELECT * FROM (SELECT 'T' kind,t.TeacherID id,t.FullName name,N'ښوونکی' typ,a.Status FROM Teachers t LEFT JOIN StaffAttendance a ON a.TeacherID=t.TeacherID AND a.AttDate=? WHERE t.IsActive=1 UNION ALL SELECT 'E',e.EmployeeID,e.FullName,N'کارکوونکی',a.Status FROM Employees e LEFT JOIN StaffAttendance a ON a.EmployeeID=e.EmployeeID AND a.AttDate=? WHERE e.IsActive=1) x ORDER BY typ,name",[$d,$d])->fetchAll()]);}
if($act=='staff_save'&&$post){need('staffatt.w');$d=$b['date']??'';if(!okd($d))fail('نېټه ناسمه ده');$p=db();$p->beginTransaction();
 foreach($b['items']??[] as $it){$s=$it['Status']??'';if(!in_array($s,['P','A','L','E'],true))fail('ناسم حالت');$col=($it['kind']??'')=='T'?'TeacherID':'EmployeeID';$i=(int)$it['id'];
  q("DELETE FROM StaffAttendance WHERE $col=? AND AttDate=?",[$i,$d]);q("INSERT INTO StaffAttendance ($col,AttDate,Status) VALUES (?,?,?)",[$i,$d,$s]);}
 $p->commit();audit('staff_save','StaffAttendance',null,['date'=>$d]);out(['ok'=>1]);}
if($act=='staff_summary'){need('staffatt.r');$col=($_GET['kind']??'')=='T'?'TeacherID':'EmployeeID';
 out(['rows'=>q("SELECT Status,COUNT(*) n FROM StaffAttendance WHERE $col=? AND AttDate>=DATEFROMPARTS(YEAR(GETDATE()),1,1) GROUP BY Status",[iv('id')])->fetchAll()]);}
if($act=='notice_feed'){$r=$u['Role'];$aud=($r=='Admin'||$r=='Staff')?null:($r=='Teacher'?['All','Teachers']:['All','Staff']);$w=$aud?' AND n.Audience IN ('.implode(',',array_fill(0,count($aud),'?')).')':'';
 out(['rows'=>q("SELECT TOP 10 n.NoticeID,n.Title,n.Body,n.Audience,CONVERT(varchar(10),n.PublishDate,23) PublishDate FROM Notices n WHERE n.IsActive=1 AND (n.ExpiresOn IS NULL OR n.ExpiresOn>=CAST(GETDATE() AS DATE))$w ORDER BY n.PublishDate DESC,n.NoticeID DESC",$aud??[])->fetchAll()]);}
$AB=['creator_name','creator_title','creator_phone','creator_email','creator_note','school_address','school_phone'];
if($act=='about_get'){need('about.r');out(['rows'=>q('SELECT SettingKey k,SettingValue v FROM AppSettings')->fetchAll()]);}
if($act=='about_save'&&$post){need('about.w');foreach($AB as $k)if(array_key_exists($k,$b)){$v=mb_substr(trim((string)$b[$k]),0,500);if(!q('UPDATE AppSettings SET SettingValue=? WHERE SettingKey=?',[$v,$k])->rowCount())q('INSERT INTO AppSettings (SettingKey,SettingValue) VALUES (?,?)',[$k,$v]);}audit('about_save','AppSettings');out(['ok'=>1]);}
if($act=='promote_list'){need('promotion.r');$ex=($_GET['exam_id']??'')!==''?iv('exam_id'):0;
 out(['rows'=>q("SELECT e.EnrollmentID,s.StudentCode,s.FirstName+N' '+s.FatherName name,CASE WHEN r.n IS NULL THEN NULL WHEN r.failed=0 THEN 1 ELSE 0 END passed FROM Enrollments e JOIN Students s ON s.StudentID=e.StudentID LEFT JOIN (SELECT g.EnrollmentID,COUNT(*) n,SUM(CASE WHEN g.Score*100.0/x.MaxScore<x.PassMark THEN 1 ELSE 0 END) failed FROM Grades g JOIN Exams x ON x.ExamID=g.ExamID WHERE g.ExamID=? GROUP BY g.EnrollmentID) r ON r.EnrollmentID=e.EnrollmentID WHERE e.ClassID=? AND e.YearID=? AND e.Status=N'Active' ORDER BY s.FirstName,s.FatherName",[$ex,iv('class_id'),iv('year_id')])->fetchAll()]);}
if($act=='promote'&&$post){need('promotion.w');$mode=$b['mode']??'';if(!in_array($mode,['promote','repeat','graduate'],true))fail('ناسم عمل');$ty=(int)($b['to_year']??0);$tc=(int)($b['to_class']??0);
 if($mode!='graduate'&&(!$ty||!$tc))fail('نوی ټولګی او کال وټاکئ');
 $p=db();$p->beginTransaction();$done=0;$skip=0;
 foreach(array_unique(array_map('intval',$b['ids']??[])) as $eid){$o=q("SELECT StudentID,ClassID,YearID FROM Enrollments WHERE EnrollmentID=? AND Status=N'Active'",[$eid])->fetch();if(!$o){$skip++;continue;}
  if($mode=='graduate'){q("UPDATE Enrollments SET Status=N'Graduated' WHERE EnrollmentID=?",[$eid]);hist($o['StudentID'],'Graduation');$done++;continue;}
  if($ty==(int)$o['YearID']||q('SELECT COUNT(*) FROM Enrollments WHERE StudentID=? AND YearID=?',[$o['StudentID'],$ty])->fetchColumn()){$skip++;continue;}
  q('INSERT INTO Enrollments (StudentID,ClassID,YearID) VALUES (?,?,?)',[$o['StudentID'],$tc,$ty]);
  q('UPDATE Enrollments SET Status=? WHERE EnrollmentID=?',[$mode=='promote'?'Promoted':'Repeated',$eid]);hist($o['StudentID'],$mode=='promote'?'Promotion':'Enrollment',$mode=='promote'?null:'تکرار');$done++;}
 $p->commit();audit('promote','Enrollments',null,['mode'=>$mode,'done'=>$done,'skipped'=>$skip]);out(['done'=>$done,'skipped'=>$skip]);}
if($act=='payroll_run'&&$post){need('salaries.w');$m=(string)($b['month']??'');if(!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$m))fail('میاشت د YYYY-MM بڼه ولري');
 $p=db();$p->beginTransaction();
 $n=q('INSERT INTO SalaryPayments (TeacherID,PayMonth,BaseAmount) SELECT t.TeacherID,CAST(? AS CHAR(7)),t.BaseSalary FROM Teachers t WHERE t.IsActive=1 AND t.BaseSalary IS NOT NULL AND NOT EXISTS(SELECT 1 FROM SalaryPayments s WHERE s.TeacherID=t.TeacherID AND s.PayMonth=?)',[$m,$m])->rowCount();
 $n+=q('INSERT INTO SalaryPayments (EmployeeID,PayMonth,BaseAmount) SELECT e.EmployeeID,CAST(? AS CHAR(7)),e.BaseSalary FROM Employees e WHERE e.IsActive=1 AND e.BaseSalary IS NOT NULL AND NOT EXISTS(SELECT 1 FROM SalaryPayments s WHERE s.EmployeeID=e.EmployeeID AND s.PayMonth=?)',[$m,$m])->rowCount();
 $p->commit();audit('payroll_run','SalaryPayments',null,['month'=>$m,'count'=>$n]);out(['count'=>$n]);}
if($act=='bulletin_build'){need('bulletins.r');$cid=iv('class_id');$yid=iv('year_id');$xid=iv('exam_id');$d=bdata($cid,$yid,$xid);if($d['stats']['graded'])bstore($cid,$yid,$xid,$d);out($d);}
if($act=='bulletin_get'){need('bulletins.r');$j=q('SELECT DataJson FROM ResultBulletins WHERE BulletinID=?',[iv('id')])->fetchColumn();if(!$j)fail('نه شته',404);out(json_decode($j,true));}
if($act=='bulletin_all'&&$post){need('bulletins.w');$yid=(int)($b['year_id']??0);$xid=(int)($b['exam_id']??0);$n=0;
 foreach(q('SELECT DISTINCT ClassID FROM Enrollments WHERE YearID=?',[$yid])->fetchAll(PDO::FETCH_COLUMN) as $cid){$d=bdata((int)$cid,$yid,$xid);if($d['stats']['graded']){bstore((int)$cid,$yid,$xid,$d);$n++;}}
 audit('bulletin_all','ResultBulletins',null,['year'=>$yid,'exam'=>$xid,'count'=>$n]);out(['count'=>$n]);}
if($act=='profile_update'&&$post){$n=mb_substr(trim((string)($b['FullName']??'')),0,100);if($n==='')fail('نوم ولیکئ');q('UPDATE Users SET FullName=? WHERE UserID=?',[$n,$u['UserID']]);$_SESSION['user']['FullName']=$n;audit('profile_update','Users',(int)$u['UserID']);out(['ok'=>1]);}
fail('نامعلومه غوښتنه',404);
