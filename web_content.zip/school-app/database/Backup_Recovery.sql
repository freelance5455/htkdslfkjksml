/* =====================================================
   د Backup او Recovery پلان - HussainKhelSchool
   =====================================================
   پلان:
   - Full Backup:         هره جمعه شپه (یا اونۍ کې یو ځل)
   - Differential Backup: هره ورځ شپه
   - Log Backup:          هر ساعت (که Recovery = FULL)
   - کاپي: Backup فایلونه په بل ډیسک/USB/Cloud کې هم وساتئ (3-2-1 اصل)
   - ساتل: وروستۍ 30 ورځې؛ هره میاشت یو Backup Restore کړئ ترڅو ډاډ ومومئ چې کار کوي
   لاندې C:\SchoolBackups فولډر مو جوړ کړئ او SQL Server ته یې د Write اجازه ورکړئ. */

USE master;
GO
ALTER DATABASE HussainKhelSchool SET RECOVERY FULL;
GO

-- 1) Full Backup
BACKUP DATABASE HussainKhelSchool
TO DISK = N'C:\SchoolBackups\HK_Full.bak'
WITH INIT, COMPRESSION, CHECKSUM, STATS = 10;
RESTORE VERIFYONLY FROM DISK = N'C:\SchoolBackups\HK_Full.bak' WITH CHECKSUM;
GO

-- 2) Differential Backup
BACKUP DATABASE HussainKhelSchool
TO DISK = N'C:\SchoolBackups\HK_Diff.bak'
WITH DIFFERENTIAL, INIT, COMPRESSION, CHECKSUM;
GO

-- 3) Log Backup
BACKUP LOG HussainKhelSchool
TO DISK = N'C:\SchoolBackups\HK_Log.trn'
WITH INIT, COMPRESSION, CHECKSUM;
GO

-- 4) د ډیټابیس روغتیا چک (هره اونۍ)
DBCC CHECKDB (HussainKhelSchool) WITH NO_INFOMSGS;
GO

/* ===== Recovery (بیرته راوړل) =====
   الف) یوازې Full:
      RESTORE DATABASE HussainKhelSchool FROM DISK = N'C:\SchoolBackups\HK_Full.bak' WITH REPLACE, RECOVERY;
   ب) Full + Differential + Log تر یوه وخته پورې:
      RESTORE DATABASE HussainKhelSchool FROM DISK = N'C:\SchoolBackups\HK_Full.bak' WITH NORECOVERY, REPLACE;
      RESTORE DATABASE HussainKhelSchool FROM DISK = N'C:\SchoolBackups\HK_Diff.bak' WITH NORECOVERY;
      RESTORE LOG HussainKhelSchool FROM DISK = N'C:\SchoolBackups\HK_Log.trn' WITH STOPAT = N'2026-10-10T10:30:00', RECOVERY;
   مهم: Restore مه چلوئ تر څو اپ بند نه وي (ټول کارونکي وتلي وي). */

-- 5) SQL Server Agent Job (هره جمعه 02:00 Full). SQL Express کې Agent نشته؛ هلته Windows Task Scheduler + sqlcmd وکاروئ.
USE msdb;
GO
EXEC sp_add_job @job_name = N'HK Full Backup';
EXEC sp_add_jobstep @job_name = N'HK Full Backup', @step_name = N'Full', @subsystem = N'TSQL',
     @command = N'BACKUP DATABASE HussainKhelSchool TO DISK = N''C:\SchoolBackups\HK_Full.bak'' WITH INIT, COMPRESSION, CHECKSUM';
EXEC sp_add_jobschedule @job_name = N'HK Full Backup', @name = N'Weekly Fri 02:00',
     @freq_type = 8, @freq_interval = 32, @freq_recurrence_factor = 1, @active_start_time = 20000;
EXEC sp_add_jobserver @job_name = N'HK Full Backup';
GO
