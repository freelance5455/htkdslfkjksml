\xEF\xBB\xBF/* =====================================================
   د حسین خېلو لېسې ډیټابیس (SQL Server)
   Hussain Khel School Database - Grades 1 to 12
   دولتي مکتب: د فیس برخه نشته
   چلول: په SSMS یا Azure Data Studio کې پرانیزه او Execute کړه
   ===================================================== */

IF DB_ID(N'HussainKhelSchool') IS NULL
    CREATE DATABASE HussainKhelSchool;
GO
USE HussainKhelSchool;
GO

/* ---------- 1. تعلیمي کال ---------- */
CREATE TABLE AcademicYears (
    YearID      INT IDENTITY(1,1) PRIMARY KEY,
    YearName    NVARCHAR(20) NOT NULL UNIQUE,      -- لکه 1405
    StartDate   DATE NOT NULL,
    EndDate     DATE NOT NULL,
    IsCurrent   BIT NOT NULL DEFAULT 0,
    CONSTRAINT CK_Year_Dates CHECK (EndDate > StartDate)
);
GO

/* ---------- 2. ښوونکي ---------- */
CREATE TABLE Teachers (
    TeacherID   INT IDENTITY(1,1) PRIMARY KEY,
    FullName    NVARCHAR(100) NOT NULL,
    FatherName  NVARCHAR(100) NULL,
    Gender      NVARCHAR(10) NULL,
    Specialty   NVARCHAR(100) NULL,
    Education   NVARCHAR(100) NULL,
    Phone       NVARCHAR(20) NULL,
    Address     NVARCHAR(200) NULL,
    HireDate    DATE NULL,
    BaseSalary  DECIMAL(12,2) NULL,
    PhotoFile   NVARCHAR(200) NULL,
    IsActive    BIT NOT NULL DEFAULT 1,
    CONSTRAINT CK_Teacher_Gender CHECK (Gender IN (N'Male', N'Female') OR Gender IS NULL)
);
GO

/* ---------- 3. ټولګي (1 تر 12) ---------- */
CREATE TABLE Classes (
    ClassID             INT IDENTITY(1,1) PRIMARY KEY,
    Grade               TINYINT NOT NULL,
    Section             NVARCHAR(10) NOT NULL,
    HomeroomTeacherID   INT NULL,
    CONSTRAINT CK_Class_Grade CHECK (Grade BETWEEN 1 AND 12),
    CONSTRAINT UQ_Class UNIQUE (Grade, Section),
    CONSTRAINT FK_Class_Teacher FOREIGN KEY (HomeroomTeacherID)
        REFERENCES Teachers(TeacherID)
);
GO

/* ---------- 4. مضمونونه ---------- */
CREATE TABLE Subjects (
    SubjectID   INT IDENTITY(1,1) PRIMARY KEY,
    SubjectName NVARCHAR(100) NOT NULL UNIQUE,
    WeeklyHours TINYINT NULL,
    CONSTRAINT CK_Subject_Hours CHECK (WeeklyHours IS NULL OR WeeklyHours BETWEEN 1 AND 40)
);
GO

/* ---------- 5. زده‌کوونکي ---------- */
CREATE TABLE Students (
    StudentID       INT IDENTITY(1,1) PRIMARY KEY,
    FirstName       NVARCHAR(100) NOT NULL,
    FatherName      NVARCHAR(100) NOT NULL,
    GrandfatherName NVARCHAR(100) NULL,
    BirthDate       DATE NULL,
    Gender          NVARCHAR(10) NOT NULL,
    Phone           NVARCHAR(20) NULL,
    Address         NVARCHAR(200) NULL,
    GuardianName    NVARCHAR(100) NULL,
    GuardianPhone   NVARCHAR(20) NULL,
    AdmissionDate   DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    StudentCode     AS ('HK-' + RIGHT('00000' + CAST(StudentID AS VARCHAR(10)), 5)) PERSISTED,   -- ځانګړی نمبر
    FatherOccupation NVARCHAR(100) NULL,
    FatherPhone     NVARCHAR(20) NULL,
    PermanentAddress NVARCHAR(200) NULL,
    PhotoFile       NVARCHAR(200) NULL,
    IsActive        BIT NOT NULL DEFAULT 1,
    CONSTRAINT CK_Student_Gender CHECK (Gender IN (N'Male', N'Female')),
    CONSTRAINT CK_Student_Birth CHECK (BirthDate IS NULL OR BirthDate < GETDATE())
);
GO

/* ---------- 6. ثبت‌نام (زده‌کوونکی + ټولګی + کال) ---------- */
CREATE TABLE Enrollments (
    EnrollmentID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID    INT NOT NULL,
    ClassID      INT NOT NULL,
    YearID       INT NOT NULL,
    EnrollDate   DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    Status       NVARCHAR(20) NOT NULL DEFAULT N'Active',
    CONSTRAINT CK_Enroll_Status CHECK (Status IN (N'Active', N'Promoted', N'Repeated', N'Graduated', N'Transferred', N'Dropped')),
    CONSTRAINT UQ_Enroll UNIQUE (StudentID, YearID),
    CONSTRAINT FK_Enroll_Student FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    CONSTRAINT FK_Enroll_Class   FOREIGN KEY (ClassID)   REFERENCES Classes(ClassID),
    CONSTRAINT FK_Enroll_Year    FOREIGN KEY (YearID)    REFERENCES AcademicYears(YearID)
);
GO

/* ---------- 7. د ښوونکو مضمون ویش ---------- */
CREATE TABLE TeachingAssignments (
    AssignmentID INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID    INT NOT NULL,
    SubjectID    INT NOT NULL,
    ClassID      INT NOT NULL,
    YearID       INT NOT NULL,
    CONSTRAINT UQ_Assign UNIQUE (SubjectID, ClassID, YearID),
    CONSTRAINT FK_Assign_Teacher FOREIGN KEY (TeacherID) REFERENCES Teachers(TeacherID),
    CONSTRAINT FK_Assign_Subject FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    CONSTRAINT FK_Assign_Class   FOREIGN KEY (ClassID)   REFERENCES Classes(ClassID),
    CONSTRAINT FK_Assign_Year    FOREIGN KEY (YearID)    REFERENCES AcademicYears(YearID)
);
GO

/* ---------- 8. حاضري ---------- */
-- P = حاضر، A = غایب، L = ناوخته، E = رخصتي
CREATE TABLE Attendance (
    AttendanceID INT IDENTITY(1,1) PRIMARY KEY,
    EnrollmentID INT NOT NULL,
    AttDate      DATE NOT NULL,
    Status       CHAR(1) NOT NULL,
    Note         NVARCHAR(200) NULL,
    CONSTRAINT CK_Att_Status CHECK (Status IN ('P', 'A', 'L', 'E')),
    CONSTRAINT UQ_Att UNIQUE (EnrollmentID, AttDate),
    CONSTRAINT FK_Att_Enroll FOREIGN KEY (EnrollmentID) REFERENCES Enrollments(EnrollmentID)
);
GO

/* ---------- 9. ازموینې ---------- */
CREATE TABLE Exams (
    ExamID    INT IDENTITY(1,1) PRIMARY KEY,
    ExamName  NVARCHAR(100) NOT NULL,
    ExamType  NVARCHAR(20) NOT NULL,
    YearID    INT NOT NULL,
    ExamDate  DATE NULL,
    MaxScore  DECIMAL(5,2) NOT NULL DEFAULT 100,
    PassMark  DECIMAL(5,2) NOT NULL DEFAULT 40,      -- د بریالیتوب لږ تر لږه فیصدي
    CONSTRAINT CK_Exam_Type CHECK (ExamType IN (N'Monthly', N'FourMonth', N'Midterm', N'Final')),
    CONSTRAINT CK_Exam_Pass CHECK (PassMark BETWEEN 0 AND 100),
    CONSTRAINT CK_Exam_Max CHECK (MaxScore > 0),
    CONSTRAINT FK_Exam_Year FOREIGN KEY (YearID) REFERENCES AcademicYears(YearID)
);
GO

/* ---------- 10. نمرې ---------- */
CREATE TABLE Grades (
    GradeID      INT IDENTITY(1,1) PRIMARY KEY,
    EnrollmentID INT NOT NULL,
    ExamID       INT NOT NULL,
    SubjectID    INT NOT NULL,
    Score        DECIMAL(5,2) NOT NULL,
    CONSTRAINT CK_Grade_Score CHECK (Score >= 0 AND Score <= 100),
    CONSTRAINT UQ_Grade UNIQUE (EnrollmentID, ExamID, SubjectID),
    CONSTRAINT FK_Grade_Enroll  FOREIGN KEY (EnrollmentID) REFERENCES Enrollments(EnrollmentID),
    CONSTRAINT FK_Grade_Exam    FOREIGN KEY (ExamID)       REFERENCES Exams(ExamID),
    CONSTRAINT FK_Grade_Subject FOREIGN KEY (SubjectID)    REFERENCES Subjects(SubjectID)
);
GO

/* ---------- 11. رولونه، صلاحیتونه، کاروونکي ---------- */
CREATE TABLE Roles (
    RoleID   INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE Permissions (
    PermissionID INT IDENTITY(1,1) PRIMARY KEY,
    Code         NVARCHAR(60) NOT NULL UNIQUE      -- لکه students.r (لیدل) یا students.w (بدلون)
);
CREATE TABLE RolePermissions (
    RoleID       INT NOT NULL,
    PermissionID INT NOT NULL,
    PRIMARY KEY (RoleID, PermissionID),
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID) ON DELETE CASCADE,
    FOREIGN KEY (PermissionID) REFERENCES Permissions(PermissionID) ON DELETE CASCADE
);
CREATE TABLE Users (
    UserID       INT IDENTITY(1,1) PRIMARY KEY,
    Username     NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    RoleID       INT NOT NULL REFERENCES Roles(RoleID),
    TeacherID    INT NULL REFERENCES Teachers(TeacherID),
    FullName     NVARCHAR(100) NULL,                     -- د ښودلو نوم (بدلېدلی شي)
    PhotoFile    NVARCHAR(200) NULL,
    IsActive     BIT NOT NULL DEFAULT 1
);
GO

/* ---------- 1. سرپرستان ---------- */
CREATE TABLE Guardians (
    GuardianID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID  INT NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
    FullName   NVARCHAR(100) NOT NULL,
    Relation   NVARCHAR(50) NULL,
    Phone      NVARCHAR(20) NULL,
    Address    NVARCHAR(200) NULL,
    IsPrimary  BIT NOT NULL DEFAULT 1
);

/* ---------- 2. کارکوونکي (غیر ښوونکي) ---------- */
CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FullName   NVARCHAR(100) NOT NULL,
    FatherName NVARCHAR(100) NULL,
    Position   NVARCHAR(100) NULL,
    Phone      NVARCHAR(20) NULL,
    Address    NVARCHAR(200) NULL,
    HireDate   DATE NULL,
    BaseSalary DECIMAL(12,2) NULL,
    PhotoFile  NVARCHAR(200) NULL,
    IsActive   BIT NOT NULL DEFAULT 1
);

/* ---------- 5. د ټولګي مضمونونه ---------- */
CREATE TABLE ClassSubjects (
    ClassSubjectID INT IDENTITY(1,1) PRIMARY KEY,
    ClassID   INT NOT NULL REFERENCES Classes(ClassID),
    SubjectID INT NOT NULL REFERENCES Subjects(SubjectID),
    CONSTRAINT UQ_ClassSubject UNIQUE (ClassID, SubjectID)
);

/* ---------- 8. فیسونه او تادیات ---------- */
CREATE TABLE FeeTypes (
    FeeTypeID     INT IDENTITY(1,1) PRIMARY KEY,
    FeeName       NVARCHAR(100) NOT NULL UNIQUE,
    DefaultAmount DECIMAL(12,2) NULL
);
CREATE TABLE StudentFees (
    StudentFeeID INT IDENTITY(1,1) PRIMARY KEY,
    EnrollmentID INT NOT NULL REFERENCES Enrollments(EnrollmentID),
    FeeTypeID    INT NOT NULL REFERENCES FeeTypes(FeeTypeID),
    Amount       DECIMAL(12,2) NOT NULL CHECK (Amount >= 0),
    DueDate      DATE NULL,
    Note         NVARCHAR(200) NULL
);
CREATE TABLE Payments (
    PaymentID    INT IDENTITY(1,1) PRIMARY KEY,
    StudentFeeID INT NOT NULL REFERENCES StudentFees(StudentFeeID),
    Amount       DECIMAL(12,2) NOT NULL CHECK (Amount > 0),
    PayDate      DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    Method       NVARCHAR(10) NOT NULL DEFAULT N'Cash' CHECK (Method IN (N'Cash', N'Bank', N'Mobile')),
    ReceiptNo    NVARCHAR(30) NULL,
    ReceivedBy   INT NULL REFERENCES Users(UserID)
);

/* ---------- 9. مالي مدیریت ---------- */
CREATE TABLE ExpenseCategories (
    CategoryID   INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL UNIQUE
);
CREATE TABLE Expenses (
    ExpenseID   INT IDENTITY(1,1) PRIMARY KEY,
    CategoryID  INT NOT NULL REFERENCES ExpenseCategories(CategoryID),
    Amount      DECIMAL(12,2) NOT NULL CHECK (Amount > 0),
    ExpDate     DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    Description NVARCHAR(200) NULL,
    CreatedBy   INT NULL REFERENCES Users(UserID)
);

/* ---------- 10. معاشونه (ښوونکي یا کارکوونکي) ---------- */
CREATE TABLE SalaryPayments (
    SalaryID   INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID  INT NULL REFERENCES Teachers(TeacherID),
    EmployeeID INT NULL REFERENCES Employees(EmployeeID),
    PayMonth   CHAR(7) NOT NULL,                       -- YYYY-MM
    BaseAmount DECIMAL(12,2) NOT NULL CHECK (BaseAmount >= 0),
    Bonus      DECIMAL(12,2) NOT NULL DEFAULT 0,
    Deduction  DECIMAL(12,2) NOT NULL DEFAULT 0,
    NetAmount  AS (BaseAmount + Bonus - Deduction) PERSISTED,
    PayDate    DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    Note       NVARCHAR(200) NULL,
    CONSTRAINT CK_Salary_Who CHECK ((TeacherID IS NULL AND EmployeeID IS NOT NULL) OR (TeacherID IS NOT NULL AND EmployeeID IS NULL)),
    CONSTRAINT CK_Salary_Month CHECK (PayMonth LIKE '[0-9][0-9][0-9][0-9]-[0-1][0-9]')
);

/* ---------- 14. کتابتون ---------- */
CREATE TABLE Books (
    BookID   INT IDENTITY(1,1) PRIMARY KEY,
    Title    NVARCHAR(200) NOT NULL,
    Author   NVARCHAR(100) NULL,
    Category NVARCHAR(100) NULL,
    Copies   INT NOT NULL DEFAULT 1 CHECK (Copies >= 0)
);
CREATE TABLE BookLoans (
    LoanID     INT IDENTITY(1,1) PRIMARY KEY,
    BookID     INT NOT NULL REFERENCES Books(BookID),
    StudentID  INT NULL REFERENCES Students(StudentID),
    TeacherID  INT NULL REFERENCES Teachers(TeacherID),
    LoanDate   DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    DueDate    DATE NOT NULL,
    ReturnDate DATE NULL,
    CONSTRAINT CK_Loan_Who CHECK ((StudentID IS NULL AND TeacherID IS NOT NULL) OR (StudentID IS NOT NULL AND TeacherID IS NULL)),
    CONSTRAINT CK_Loan_Dates CHECK (DueDate >= LoanDate AND (ReturnDate IS NULL OR ReturnDate >= LoanDate))
);

/* ---------- 9. د مهال‌وېش سیستم ---------- */
CREATE TABLE Timetable (
    SlotID    INT IDENTITY(1,1) PRIMARY KEY,
    YearID    INT NOT NULL REFERENCES AcademicYears(YearID),
    ClassID   INT NOT NULL REFERENCES Classes(ClassID),
    DayOfWeek TINYINT NOT NULL CHECK (DayOfWeek BETWEEN 0 AND 6),     -- 0 شنبه ... 5 پنجشنبه، 6 جمعه
    PeriodNo  TINYINT NOT NULL CHECK (PeriodNo BETWEEN 1 AND 12),
    SubjectID INT NOT NULL REFERENCES Subjects(SubjectID),
    TeacherID INT NULL REFERENCES Teachers(TeacherID),
    StartTime TIME NULL,
    EndTime   TIME NULL,
    Room      NVARCHAR(30) NULL,
    CONSTRAINT UQ_TT_Class UNIQUE (YearID, ClassID, DayOfWeek, PeriodNo)
);
CREATE UNIQUE INDEX UQ_TT_Teacher ON Timetable (YearID, TeacherID, DayOfWeek, PeriodNo) WHERE TeacherID IS NOT NULL;

/* ---------- 18. خبرتیاوې ---------- */
CREATE TABLE Notices (
    NoticeID    INT IDENTITY(1,1) PRIMARY KEY,
    Title       NVARCHAR(150) NOT NULL,
    Body        NVARCHAR(1000) NULL,
    Audience    NVARCHAR(10) NOT NULL DEFAULT N'All' CHECK (Audience IN (N'All', N'Students', N'Teachers', N'Parents', N'Staff')),
    PublishDate DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    ExpiresOn   DATE NULL,
    IsActive    BIT NOT NULL DEFAULT 1,
    CreatedBy   INT NULL REFERENCES Users(UserID)
);

/* ---------- 19. د زده‌کوونکو اسناد ---------- */
CREATE TABLE StudentDocuments (
    DocID     INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
    DocType   NVARCHAR(50) NOT NULL,
    Title     NVARCHAR(200) NOT NULL,
    IssueDate DATE NULL,
    DocFile   NVARCHAR(200) NULL
);

/* ---------- 8. د سیستم او جوړوونکي معلومات ---------- */
CREATE TABLE AppSettings (
    SettingKey   NVARCHAR(50) PRIMARY KEY,
    SettingValue NVARCHAR(500) NULL
);

/* ---------- 7. د ټولګي د نمرو خبرپاڼې (خپله جوړېږي او ذخیره کېږي) ---------- */
CREATE TABLE ResultBulletins (
    BulletinID   INT IDENTITY(1,1) PRIMARY KEY,
    ClassID      INT NOT NULL REFERENCES Classes(ClassID),
    YearID       INT NOT NULL REFERENCES AcademicYears(YearID),
    ExamID       INT NOT NULL REFERENCES Exams(ExamID),
    Title        NVARCHAR(200) NOT NULL,
    StudentCount INT NOT NULL DEFAULT 0,
    PassCount    INT NOT NULL DEFAULT 0,
    DataJson     NVARCHAR(MAX) NOT NULL,                 -- د خبرپاڼې بشپړ معلومات (JSON)
    GeneratedAt  DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    GeneratedBy  INT NULL REFERENCES Users(UserID),
    CONSTRAINT UQ_Bulletin UNIQUE (ClassID, YearID, ExamID)
);

/* ---------- 13. د بدلونونو ثبت ---------- */
CREATE TABLE AuditLogs (
    LogID     BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserID    INT NULL,
    Action    NVARCHAR(30) NOT NULL,
    TableName NVARCHAR(60) NULL,
    RecordID  INT NULL,
    Detail    NVARCHAR(MAX) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    IP        NVARCHAR(45) NULL
);
GO

/* ---------- د زده‌کوونکي تاریخچه ---------- */
CREATE TABLE StudentHistory (
    HistoryID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
    EventType NVARCHAR(20) NOT NULL,
    EventDate DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    Note      NVARCHAR(200) NULL,
    CreatedBy INT NULL REFERENCES Users(UserID),
    CONSTRAINT CK_Hist_Type CHECK (EventType IN (N'Admission', N'Enrollment', N'Promotion', N'Transfer', N'Graduation', N'Deactivation', N'Reactivation', N'Other'))
);

/* ---------- د ښوونکو تحصیلي اسناد ---------- */
CREATE TABLE TeacherDocuments (
    DocID     INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID INT NOT NULL REFERENCES Teachers(TeacherID) ON DELETE CASCADE,
    DocType   NVARCHAR(50) NOT NULL,
    Title     NVARCHAR(200) NOT NULL,
    IssuedBy  NVARCHAR(100) NULL,
    IssueDate DATE NULL,
    DocFile   NVARCHAR(200) NULL
);

/* ---------- د ښوونکو او کارکوونکو حاضري ---------- */
CREATE TABLE StaffAttendance (
    StaffAttID INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID  INT NULL REFERENCES Teachers(TeacherID),
    EmployeeID INT NULL REFERENCES Employees(EmployeeID),
    AttDate    DATE NOT NULL,
    Status     CHAR(1) NOT NULL,
    Note       NVARCHAR(200) NULL,
    CONSTRAINT CK_SAtt_Status CHECK (Status IN ('P', 'A', 'L', 'E')),
    CONSTRAINT CK_SAtt_Who CHECK ((TeacherID IS NULL AND EmployeeID IS NOT NULL) OR (TeacherID IS NOT NULL AND EmployeeID IS NULL))
);
CREATE UNIQUE INDEX UX_SAtt_T ON StaffAttendance (TeacherID, AttDate) WHERE TeacherID IS NOT NULL;
CREATE UNIQUE INDEX UX_SAtt_E ON StaffAttendance (EmployeeID, AttDate) WHERE EmployeeID IS NOT NULL;

/* ---------- رخصتي ---------- */
CREATE TABLE LeaveRequests (
    LeaveID    INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID  INT NULL REFERENCES Teachers(TeacherID),
    EmployeeID INT NULL REFERENCES Employees(EmployeeID),
    StartDate  DATE NOT NULL,
    EndDate    DATE NOT NULL,
    Reason     NVARCHAR(200) NULL,
    Status     NVARCHAR(10) NOT NULL DEFAULT N'Pending' CHECK (Status IN (N'Pending', N'Approved', N'Rejected')),
    CONSTRAINT CK_Leave_Who CHECK ((TeacherID IS NULL AND EmployeeID IS NOT NULL) OR (TeacherID IS NOT NULL AND EmployeeID IS NULL)),
    CONSTRAINT CK_Leave_Dates CHECK (EndDate >= StartDate)
);

/* ---------- د دندو تاریخچه ---------- */
CREATE TABLE JobHistory (
    JobID      INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID  INT NULL REFERENCES Teachers(TeacherID),
    EmployeeID INT NULL REFERENCES Employees(EmployeeID),
    Position   NVARCHAR(100) NOT NULL,
    StartDate  DATE NOT NULL,
    EndDate    DATE NULL,
    Note       NVARCHAR(200) NULL,
    CONSTRAINT CK_Job_Who CHECK ((TeacherID IS NULL AND EmployeeID IS NOT NULL) OR (TeacherID IS NOT NULL AND EmployeeID IS NULL))
);
GO

/* ---------- Indexes (د چټکې لټون لپاره) ---------- */
CREATE INDEX IX_Students_Name      ON Students (FirstName, FatherName);
CREATE INDEX IX_Enroll_Class_Year  ON Enrollments (ClassID, YearID);
CREATE INDEX IX_Att_Date           ON Attendance (AttDate);
CREATE INDEX IX_Grades_Enroll      ON Grades (EnrollmentID);
GO

/* ---------- Views (چمتو راپورونه) ---------- */
CREATE VIEW vw_StudentClass AS
SELECT s.StudentID,
       s.FirstName, s.FatherName, s.GrandfatherName,
       c.Grade, c.Section, y.YearName, e.Status
FROM Enrollments e
JOIN Students s       ON s.StudentID = e.StudentID
JOIN Classes c        ON c.ClassID   = e.ClassID
JOIN AcademicYears y  ON y.YearID    = e.YearID;
GO

CREATE VIEW vw_StudentResults AS
SELECT s.StudentID, s.FirstName, s.FatherName,
       c.Grade, c.Section, y.YearName,
       ex.ExamName, sb.SubjectName, g.Score
FROM Grades g
JOIN Enrollments e    ON e.EnrollmentID = g.EnrollmentID
JOIN Students s       ON s.StudentID    = e.StudentID
JOIN Classes c        ON c.ClassID      = e.ClassID
JOIN AcademicYears y  ON y.YearID       = e.YearID
JOIN Exams ex         ON ex.ExamID      = g.ExamID
JOIN Subjects sb      ON sb.SubjectID   = g.SubjectID;
GO

CREATE VIEW vw_AttendanceSummary AS
SELECT e.EnrollmentID, s.FirstName, s.FatherName, c.Grade, c.Section,
       SUM(CASE WHEN a.Status = 'P' THEN 1 ELSE 0 END) AS PresentDays,
       SUM(CASE WHEN a.Status = 'A' THEN 1 ELSE 0 END) AS AbsentDays,
       SUM(CASE WHEN a.Status = 'L' THEN 1 ELSE 0 END) AS LateDays,
       SUM(CASE WHEN a.Status = 'E' THEN 1 ELSE 0 END) AS LeaveDays
FROM Enrollments e
JOIN Students s ON s.StudentID = e.StudentID
JOIN Classes c  ON c.ClassID   = e.ClassID
LEFT JOIN Attendance a ON a.EnrollmentID = e.EnrollmentID
GROUP BY e.EnrollmentID, s.FirstName, s.FatherName, c.Grade, c.Section;
GO

/* ---------- 12. اضافي راپورونه (Views او Stored Procedures) ---------- */
CREATE VIEW vw_StudentFeeBalance AS
SELECT sf.StudentFeeID, s.FirstName, s.FatherName, c.Grade, c.Section, y.YearName, ft.FeeName,
       sf.Amount, ISNULL(SUM(p.Amount), 0) AS Paid, sf.Amount - ISNULL(SUM(p.Amount), 0) AS Balance
FROM StudentFees sf
JOIN Enrollments e ON e.EnrollmentID = sf.EnrollmentID
JOIN Students s ON s.StudentID = e.StudentID
JOIN Classes c ON c.ClassID = e.ClassID
JOIN AcademicYears y ON y.YearID = e.YearID
JOIN FeeTypes ft ON ft.FeeTypeID = sf.FeeTypeID
LEFT JOIN Payments p ON p.StudentFeeID = sf.StudentFeeID
GROUP BY sf.StudentFeeID, s.FirstName, s.FatherName, c.Grade, c.Section, y.YearName, ft.FeeName, sf.Amount;
GO
CREATE VIEW vw_BookAvailability AS
SELECT b.BookID, b.Title, b.Copies,
       b.Copies - (SELECT COUNT(*) FROM BookLoans l WHERE l.BookID = b.BookID AND l.ReturnDate IS NULL) AS Available
FROM Books b;
GO
CREATE OR ALTER PROCEDURE sp_ClassAttendance @ClassID INT, @YearID INT, @From DATE, @To DATE AS
BEGIN
    SET NOCOUNT ON;
    SELECT s.FirstName + N' ' + s.FatherName AS [زده‌کوونکی],
           SUM(CASE WHEN a.Status = 'P' THEN 1 ELSE 0 END) AS [حاضر],
           SUM(CASE WHEN a.Status = 'A' THEN 1 ELSE 0 END) AS [غایب],
           SUM(CASE WHEN a.Status = 'L' THEN 1 ELSE 0 END) AS [ناوخته],
           SUM(CASE WHEN a.Status = 'E' THEN 1 ELSE 0 END) AS [رخصتي],
           COUNT(a.AttendanceID) AS [ټول]
    FROM Enrollments e
    JOIN Students s ON s.StudentID = e.StudentID
    LEFT JOIN Attendance a ON a.EnrollmentID = e.EnrollmentID AND a.AttDate BETWEEN @From AND @To
    WHERE e.ClassID = @ClassID AND e.YearID = @YearID AND e.Status = N'Active'
    GROUP BY e.EnrollmentID, s.FirstName, s.FatherName ORDER BY s.FirstName;
END;
GO
CREATE OR ALTER PROCEDURE sp_StudentReportCard @EnrollmentID INT AS
BEGIN
    SET NOCOUNT ON;
    SELECT ex.ExamName AS [ازموینه], sb.SubjectName AS [مضمون], g.Score AS [نمره], ex.MaxScore AS [اعظمي],
           CAST(g.Score * 100.0 / ex.MaxScore AS DECIMAL(5,1)) AS [فیصدي],
           CASE WHEN g.Score * 100.0 / ex.MaxScore >= ex.PassMark THEN N'بریالی' ELSE N'ناکام' END AS [نتیجه]
    FROM Grades g JOIN Exams ex ON ex.ExamID = g.ExamID JOIN Subjects sb ON sb.SubjectID = g.SubjectID
    WHERE g.EnrollmentID = @EnrollmentID ORDER BY ex.ExamID, sb.SubjectName;
END;
GO
CREATE OR ALTER PROCEDURE sp_ClassResults @ClassID INT, @YearID INT, @ExamID INT AS
BEGIN
    SET NOCOUNT ON;
    SELECT s.FirstName + N' ' + s.FatherName AS [زده‌کوونکی], COUNT(g.GradeID) AS [مضمونونه], SUM(g.Score) AS [مجموعه],
           CAST(AVG(g.Score * 100.0 / ex.MaxScore) AS DECIMAL(5,1)) AS [فیصدي],
           SUM(CASE WHEN g.Score * 100.0 / ex.MaxScore < ex.PassMark THEN 1 ELSE 0 END) AS [ناکام مضمونونه],
           CASE WHEN AVG(g.Score * 100.0 / ex.MaxScore) >= ex.PassMark THEN N'بریالی' ELSE N'ناکام' END AS [نتیجه],
           RANK() OVER (ORDER BY AVG(g.Score * 100.0 / ex.MaxScore) DESC) AS [رتبه]
    FROM Enrollments e JOIN Students s ON s.StudentID = e.StudentID
    JOIN Grades g ON g.EnrollmentID = e.EnrollmentID AND g.ExamID = @ExamID
    JOIN Exams ex ON ex.ExamID = g.ExamID
    WHERE e.ClassID = @ClassID AND e.YearID = @YearID AND e.Status = N'Active'
    GROUP BY e.EnrollmentID, s.FirstName, s.FatherName, ex.PassMark ORDER BY [رتبه];
END;
GO
CREATE OR ALTER PROCEDURE sp_PassFailSummary @YearID INT, @ExamID INT AS
BEGIN
    SET NOCOUNT ON;
    SELECT c.Grade AS [ټولګی], c.Section AS [څانګه], COUNT(*) AS [ټول],
           SUM(CASE WHEN r.pct >= r.pm THEN 1 ELSE 0 END) AS [بریالي],
           SUM(CASE WHEN r.pct < r.pm THEN 1 ELSE 0 END) AS [ناکام],
           CAST(100.0 * SUM(CASE WHEN r.pct >= r.pm THEN 1 ELSE 0 END) / COUNT(*) AS DECIMAL(5,1)) AS [د بریالیتوب %]
    FROM (SELECT e.ClassID, AVG(g.Score * 100.0 / ex.MaxScore) AS pct, MAX(ex.PassMark) AS pm
          FROM Grades g JOIN Exams ex ON ex.ExamID = g.ExamID JOIN Enrollments e ON e.EnrollmentID = g.EnrollmentID
          WHERE g.ExamID = @ExamID AND e.YearID = @YearID GROUP BY e.EnrollmentID, e.ClassID) r
    JOIN Classes c ON c.ClassID = r.ClassID GROUP BY c.Grade, c.Section ORDER BY c.Grade, c.Section;
END;
GO
CREATE OR ALTER PROCEDURE sp_StaffAttendance @From DATE, @To DATE AS
BEGIN
    SET NOCOUNT ON;
    SELECT x.nm AS [نوم], x.typ AS [ډول],
           SUM(CASE WHEN a.Status = 'P' THEN 1 ELSE 0 END) AS [حاضر], SUM(CASE WHEN a.Status = 'A' THEN 1 ELSE 0 END) AS [غایب],
           SUM(CASE WHEN a.Status = 'L' THEN 1 ELSE 0 END) AS [ناوخته], SUM(CASE WHEN a.Status = 'E' THEN 1 ELSE 0 END) AS [رخصتي]
    FROM (SELECT TeacherID AS tid, NULL AS eid, FullName AS nm, N'ښوونکی' AS typ FROM Teachers WHERE IsActive = 1
          UNION ALL SELECT NULL, EmployeeID, FullName, N'کارکوونکی' FROM Employees WHERE IsActive = 1) x
    LEFT JOIN StaffAttendance a ON (a.TeacherID = x.tid OR a.EmployeeID = x.eid) AND a.AttDate BETWEEN @From AND @To
    GROUP BY x.tid, x.eid, x.nm, x.typ ORDER BY x.typ, x.nm;
END;
GO
CREATE OR ALTER PROCEDURE sp_FeeDefaulters @YearID INT AS
BEGIN
    SET NOCOUNT ON;
    SELECT s.FirstName + N' ' + s.FatherName AS [زده‌کوونکی], c.Grade AS [ټولګی],
           SUM(f.Amount) AS [ټول فیس], SUM(f.Paid) AS [تادیه], SUM(f.Amount - f.Paid) AS [پاتې]
    FROM (SELECT sf.EnrollmentID, sf.Amount, ISNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.StudentFeeID = sf.StudentFeeID), 0) AS Paid FROM StudentFees sf) f
    JOIN Enrollments e ON e.EnrollmentID = f.EnrollmentID JOIN Students s ON s.StudentID = e.StudentID JOIN Classes c ON c.ClassID = e.ClassID
    WHERE e.YearID = @YearID
    GROUP BY e.EnrollmentID, s.FirstName, s.FatherName, c.Grade
    HAVING SUM(f.Amount - f.Paid) > 0 ORDER BY [پاتې] DESC;
END;
GO
CREATE OR ALTER PROCEDURE sp_FinanceSummary @From DATE, @To DATE AS
BEGIN
    SET NOCOUNT ON;
    SELECT i.V AS [عاید], x.V AS [لګښتونه], sl.V AS [معاشونه], i.V - x.V - sl.V AS [خالص]
    FROM (SELECT ISNULL(SUM(Amount),0) V FROM Payments WHERE PayDate BETWEEN @From AND @To) i,
         (SELECT ISNULL(SUM(Amount),0) V FROM Expenses WHERE ExpDate BETWEEN @From AND @To) x,
         (SELECT ISNULL(SUM(NetAmount),0) V FROM SalaryPayments WHERE PayDate BETWEEN @From AND @To) sl;
END;
GO

/* ---------- رولونه او صلاحیتونه (Seed) ---------- */
INSERT INTO Roles (RoleName) VALUES (N'Admin'), (N'Staff'), (N'Teacher'), (N'Accountant'), (N'Librarian');
INSERT INTO Permissions (Code)
SELECT m + '.' + a FROM (VALUES ('students'),('guardians'),('teachers'),('employees'),('classes'),('subjects'),('classsubjects'),('years'),
 ('enrollments'),('assign'),('attendance'),('exams'),('grades'),('feetypes'),('studentfees'),('payments'),('expcats'),('expenses'),
 ('salaries'),('books'),('loans'),('staffatt'),('leaves'),('reports'),('users'),('roles'),('audit'),('backup'),('timetable'),('promotion'),('notices'),('sdocs'),('about'),('bulletins')) M(m)
CROSS JOIN (VALUES ('r'),('w')) A(a);
GO
DECLARE @mod TABLE (PermissionID INT, M NVARCHAR(30));
INSERT INTO @mod SELECT PermissionID, LEFT(Code, CHARINDEX('.', Code) - 1) FROM Permissions;
INSERT INTO RolePermissions SELECT 1, PermissionID FROM Permissions;
INSERT INTO RolePermissions SELECT 2, PermissionID FROM @mod WHERE M IN ('students','guardians','teachers','employees','classes','subjects','classsubjects','years','enrollments','assign','attendance','exams','grades','books','loans','staffatt','leaves','reports');
INSERT INTO RolePermissions SELECT 3, PermissionID FROM Permissions WHERE Code IN ('students.r','guardians.r','classes.r','subjects.r','classsubjects.r','years.r','enrollments.r','assign.r','attendance.r','attendance.w','exams.r','grades.r','grades.w','books.r','loans.r','reports.r');
INSERT INTO RolePermissions SELECT 4, p.PermissionID FROM Permissions p JOIN @mod m ON m.PermissionID = p.PermissionID
 WHERE m.M IN ('feetypes','studentfees','payments','expcats','expenses','salaries','reports') OR p.Code IN ('students.r','teachers.r','employees.r','classes.r','years.r','enrollments.r');
INSERT INTO RolePermissions SELECT 5, p.PermissionID FROM Permissions p JOIN @mod m ON m.PermissionID = p.PermissionID
 WHERE m.M IN ('books','loans') OR p.Code IN ('students.r','teachers.r');
INSERT INTO RolePermissions SELECT 2, PermissionID FROM @mod WHERE M IN ('timetable','promotion','notices','sdocs') UNION SELECT 2, PermissionID FROM Permissions WHERE Code = 'about.r';
INSERT INTO RolePermissions SELECT 3, PermissionID FROM Permissions WHERE Code IN ('timetable.r','notices.r','about.r');
INSERT INTO RolePermissions SELECT 4, PermissionID FROM Permissions WHERE Code IN ('notices.r','about.r');
INSERT INTO RolePermissions SELECT 5, PermissionID FROM Permissions WHERE Code IN ('notices.r','about.r');
INSERT INTO AppSettings (SettingKey) VALUES (N'creator_name'), (N'creator_title'), (N'creator_phone'), (N'creator_email'), (N'creator_note'), (N'school_address'), (N'school_phone');
INSERT INTO RolePermissions SELECT 2, PermissionID FROM @mod WHERE M = 'bulletins';
INSERT INTO RolePermissions SELECT 3, PermissionID FROM Permissions WHERE Code = 'bulletins.r';
GO

CREATE UNIQUE INDEX UX_Students_Code ON Students (StudentCode);
CREATE INDEX IX_Hist_Student ON StudentHistory (StudentID);
CREATE INDEX IX_Guardians_Student ON Guardians (StudentID);
CREATE INDEX IX_StudentFees_Enroll ON StudentFees (EnrollmentID);
CREATE INDEX IX_Payments_Fee ON Payments (StudentFeeID);
CREATE INDEX IX_Loans_Book ON BookLoans (BookID) WHERE ReturnDate IS NULL;
CREATE INDEX IX_Audit_Date ON AuditLogs (CreatedAt);
GO

/* نمونه: د فیس ډولونه، د لګښت ډولونه */
INSERT INTO FeeTypes (FeeName, DefaultAmount) VALUES (N'د ثبت‌نام فیس', 200), (N'میاشتنی فیس', 100);
INSERT INTO ExpenseCategories (CategoryName) VALUES (N'برېښنا'), (N'د ښوونځي لوازم'), (N'ترمیم');
GO

/* ---------- نمونه معلومات ---------- */
INSERT INTO AcademicYears (YearName, StartDate, EndDate, IsCurrent)
VALUES (N'1405', '2026-03-21', '2027-01-15', 1);

INSERT INTO Subjects (SubjectName, WeeklyHours) VALUES
(N'پښتو', 5), (N'دري', 4), (N'ریاضي', 5), (N'علوم', 4),
(N'اسلامي زده‌کړې', 3), (N'انګلیسي', 3), (N'ټولنیز علوم', 3);

-- د 1 تر 12 ټولګي، یوه څانګه (الف)
WITH n AS (
    SELECT 1 AS g
    UNION ALL
    SELECT g + 1 FROM n WHERE g < 12
)
INSERT INTO Classes (Grade, Section)
SELECT g, N'الف' FROM n;
GO

INSERT INTO Exams (ExamName, ExamType, YearID, MaxScore)
VALUES (N'نیمه‌کلنۍ ازموینه', N'Midterm', 1, 100),
       (N'کلنۍ ازموینه', N'Final', 1, 100);
GO

/* ---------- ګټورې پوښتنې (Queries) ---------- */
-- د یو ټولګي ټول زده‌کوونکي (مثلاً 7 ټولګی):
-- SELECT * FROM vw_StudentClass WHERE Grade = 7 AND YearName = N'1405';

-- د هر ټولګي د زده‌کوونکو شمېر:
-- SELECT Grade, COUNT(*) AS Total FROM vw_StudentClass GROUP BY Grade ORDER BY Grade;

-- د یو زده‌کوونکي ټولې نمرې:
-- SELECT * FROM vw_StudentResults WHERE StudentID = 1;
