package com.convertidorpro.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.view.ViewGroup
import android.widget.Toast
import android.graphics.Color
import android.util.Base64
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBytes: ByteArray? = null
    private var pendingName: String = "archivo.bin"
    private var pendingMime: String = "application/octet-stream"

    companion object {
        private const val FILE_CHOOSER_REQUEST = 4101
        private const val SAVE_FILE_REQUEST = 4102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(234, 248, 255)
        window.navigationBarColor = Color.rgb(255, 255, 255)
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility =
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = true
        settings.setSupportZoom(false)
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.addJavascriptInterface(NativeFileSaver(), "AndroidFileSaver")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                return try {
                    // Build a predictable Android document-picker intent. WebView's generated
                    // intent varies by Android version and may ignore multiple selection.
                    val params = fileChooserParams
                    val acceptTypes = params?.acceptTypes
                        ?.flatMap { it.split(",") }
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() && it.contains("/") }
                        ?.distinct()
                        .orEmpty()
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = if (acceptTypes.size == 1) acceptTypes.first() else "*/*"
                        if (acceptTypes.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, acceptTypes.toTypedArray())
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    this@MainActivity.fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            private fun routeUrl(url: String?): Boolean {
                if (url == null || (!url.startsWith("https://") && !url.startsWith("http://"))) return false
                // The ZIP extraction library is intentionally loaded from this CDN.
                if (url.startsWith("https://cdn.jsdelivr.net/")) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    true
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "No se pudo abrir el enlace", Toast.LENGTH_SHORT).show()
                    true
                }
            }
            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = routeUrl(url)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                routeUrl(request?.url?.toString())
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeFileSaver {
        @JavascriptInterface
        fun saveFile(fileName: String, mimeType: String, base64Data: String) {
            runOnUiThread {
                try {
                    if (base64Data.length > 180_000_000) {
                        Toast.makeText(this@MainActivity, "Archivo demasiado grande para guardar desde la app", Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    pendingBytes = Base64.decode(base64Data, Base64.DEFAULT)
                    pendingName = fileName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "archivo.bin" }
                    pendingMime = mimeType.ifBlank { "application/octet-stream" }
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = pendingMime
                        putExtra(Intent.EXTRA_TITLE, pendingName)
                    }
                    startActivityForResult(intent, SAVE_FILE_REQUEST)
                } catch (e: Exception) {
                    pendingBytes = null
                    Toast.makeText(this@MainActivity, "No se pudo preparar el archivo: ${e.message ?: "error"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val callback = fileChooserCallback
            fileChooserCallback = null
            val result = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                else data.data?.let { arrayOf(it) }
            } else null
            callback?.onReceiveValue(result)
            return
        }
        if (requestCode == SAVE_FILE_REQUEST) {
            val bytes = pendingBytes
            pendingBytes = null
            if (resultCode == RESULT_OK && data?.data != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes) }
                        ?: throw IOException("No se pudo abrir el destino")
                    Toast.makeText(this, "Archivo guardado correctamente", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Error al guardar: ${e.message ?: "error"}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Guardado cancelado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        webView.removeJavascriptInterface("AndroidFileSaver")
        webView.destroy()
        super.onDestroy()
    }
}
