plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.convertidorpro.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.convertidorpro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }
}
