# Converter Pro para Android 1.3 — proyecto fuente

Este proyecto de Android Studio empaqueta Converter Pro como una app Android mediante WebView, con selector nativo de archivos con filtros MIME y guardado usando el selector de destino de Android. Tema blanco/celeste/negro.

## Funciones incluidas en esta versión
- Conversión real de imágenes a PNG, JPG/JPEG y WebP usando decodificación y recodificación del navegador.
- Conversión de audio compatible a WAV PCM.
- Creación de archivos ZIP estándar para archivos seleccionados y resultados convertidos.
- Extracción de ZIP con el motor fflate cargado desde CDN cuando se usa esa función (requiere internet la primera vez).
- Renombrado/cambio de extensión, claramente separado de una conversión real.
- Icono de aplicación propio en estilo celeste y oscuro.
- Límite de guardado integrado de 32 MB para reducir el riesgo de cierres por memoria al convertir datos binarios a Base64.

## Crear el APK
1. En una computadora instala Android Studio estable y sus componentes de Android SDK.
2. Descomprime este ZIP.
3. En Android Studio, abre la carpeta `ConvertidorPro_Android` (no el ZIP).
4. Espera a que Gradle sincronice y descargue los complementos.
5. Selecciona **Build > Build APK(s)**. El APK de depuración suele aparecer en `app/build/outputs/apk/debug/app-debug.apk`.

## Estado de compilación
Este paquete es un proyecto fuente de Android Studio, **no un APK ya compilado**. En esta preparación se revisó la sintaxis JavaScript y se probó que el ZIP generado por la herramienta sea legible con un lector ZIP estándar; no se pudo ejecutar una compilación Android real. No incluye Gradle Wrapper porque no se pudo descargar en el entorno de preparación; Android Studio debe tener Gradle disponible para sincronizar el proyecto. El entorno donde se preparó no dispone de Android SDK ni de Gradle instalado, así que no se ha podido generar ni probar aquí un APK instalable. El proyecto incluye los archivos Kotlin, manifest, estilos y recursos web necesarios para abrirlo en Android Studio.

## Límites conocidos
- La conversión de audio depende de los formatos/códecs que Android WebView pueda decodificar.
- La extracción ZIP descarga el motor fflate desde jsDelivr cuando se usa por primera vez; necesita conexión y puede no funcionar en redes que bloqueen CDN. En Android, el resultado se guarda mediante el selector de destino del sistema.
- Crear ZIP usa el método Store (sin compresión adicional); los ZIP resultantes son estándar, pero pueden ser grandes.
- Cambiar una extensión no convierte los datos del archivo.
- Esta versión no incluye todavía conversión universal de vídeos, PDF/Office, MP3 ni texturas PVR. No se deben asumir compatibilidades que no estén listadas.
