MARKET COST - Projet Android WebView + Firebase

Ce projet contient l'interface Market Cost dans:
app/src/main/assets/www/index.html

Compilation:
1. Ouvrir ce dossier dans AIDE.
2. Laisser AIDE synchroniser Gradle.
3. Choisir Run/Build APK.
4. Installer l'APK généré.

Firebase:
La configuration Firebase Web est déjà incluse dans index.html.
L'application nécessite Internet pour synchroniser Firebase; localStorage reste disponible
pour les fonctions locales existantes.

Important:
Ce projet ne contient aucune clé privée de compte de service. La configuration Web Firebase
est destinée à être utilisée côté client.
