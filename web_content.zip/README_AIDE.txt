ANIVORA - AIDE
1. Extract this ZIP.
2. In AIDE choose Open/Import Gradle Project.
3. Select the folder containing settings.gradle, build.gradle and app.
4. Let Gradle sync.
5. Choose Run/Build to create the debug APK.
6. If Android SDK licenses are requested, accept them.
