const KEY="ar_hisab_v1";
let db=JSON.parse(localStorage.getItem(KEY)||'{"customers":[],"transactions":[],"settings":{"shopName":"AR Hisab"}}');

const $=id=>document.getElementById(id);
const money=n=>`${Number(n||0).toLocaleString('en-US')} AFN`;
const save=()=>{localStorage.setItem(KEY,JSON.stringify(db));render()};

function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}
function now(){const d=new Date();return {iso:d.toISOString(),date:d.toLocaleDateString('en-CA'),time:d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})}}
function customerDue(id){return db.transactions.filter(t=>t.customerId===id).reduce((s,t)=>s+t.total-t.paid,0)}
function render(){
  $('shopName').value=db.settings.shopName||'AR Hisab';
  const today=new Date().toLocaleDateString('en-CA');
  const due=db.customers.reduce((s,c)=>s+customerDue(c.id),0);
  $('totalDue').textContent=money(due);
  $('customerCount').textContent=db.customers.length;
  const todayTx=db.transactions.filter(t=>t.date===today);
  $('todayCount').textContent=todayTx.length;
  $('todayPaid').textContent=money(todayTx.reduce((s,t)=>s+t.paid,0));
  const q=$('searchInput').value.trim().toLowerCase();
  const list=db.customers.filter(c=>c.name.toLowerCase().includes(q));
  $('customerList').innerHTML=list.map(c=>{
    const d=customerDue(c.id);
    return `<div class="customer-row" data-id="${c.id}">
      <div><strong>${esc(c.name)}</strong><div class="muted">${esc(c.phone||'')} ${c.address?'• '+esc(c.address):''}</div></div>
      <div class="due ${d?'positive':'zero'}">${money(d)}<div class="muted">پاتې</div></div>
    </div>`;
  }).join('');
  $('emptyCustomers').style.display=list.length?'none':'block';
  $('todayTransactions').innerHTML=todayTx.slice().reverse().map(t=>`
    <div class="tx-row"><div><strong>${esc(t.customerName)} — ${esc(t.item)}</strong>
    <div class="muted">${t.date} • ${t.time} • مقدار: ${t.qty}</div></div>
    <div><strong>${money(t.total)}</strong><div class="muted">پاتې: ${money(t.total-t.paid)}</div></div></div>`).join('');
  $('emptyTransactions').style.display=todayTx.length?'none':'block';
  document.querySelectorAll('.customer-row').forEach(x=>x.onclick=()=>showCustomer(x.dataset.id));
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}

$('addCustomerBtn').onclick=()=>{$('customerForm').reset();$('customerDialog').showModal()}
$('addTransactionBtn').onclick=()=>{
  if(!db.customers.length){alert('لومړی یو پیرودونکی اضافه کړئ.');return}
  $('txCustomer').innerHTML=db.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
  $('transactionForm').reset();$('txQty').value=1;$('txPrice').value=0;$('txPaid').value=0;calc();$('transactionDialog').showModal()
}
$('customerForm').onsubmit=e=>{e.preventDefault();db.customers.push({id:uid(),name:$('customerName').value.trim(),phone:$('customerPhone').value.trim(),address:$('customerAddress').value.trim(),note:$('customerNote').value.trim(),createdAt:now().iso});save();$('customerDialog').close()}
function calc(){const total=(Number($('txQty').value)||0)*(Number($('txPrice').value)||0);$('txTotal').textContent=money(total)}
['txQty','txPrice'].forEach(id=>$(id).addEventListener('input',calc));
$('transactionForm').onsubmit=e=>{e.preventDefault();const total=(Number($('txQty').value)||0)*(Number($('txPrice').value)||0),paid=Math.min(Number($('txPaid').value)||0,total),c=db.customers.find(x=>x.id===$('txCustomer').value),d=now();db.transactions.push({id:uid(),customerId:c.id,customerName:c.name,item:$('txItem').value.trim(),qty:Number($('txQty').value)||0,price:Number($('txPrice').value)||0,total,paid,note:$('txNote').value.trim(),date:d.date,time:d.time,createdAt:d.iso});save();$('transactionDialog').close()}

function showCustomer(id){
 const c=db.customers.find(x=>x.id===id); if(!c)return;
 const tx=db.transactions.filter(t=>t.customerId===id).slice().reverse();
 const total=tx.reduce((s,t)=>s+t.total,0),paid=tx.reduce((s,t)=>s+t.paid,0),due=total-paid;
 $('customerView').innerHTML=`<h2>${esc(c.name)}</h2>
 <div class="muted">${c.phone?'📞 '+esc(c.phone):''} ${c.address?' • 📍 '+esc(c.address):''}</div>
 <div class="summary"><div>ټول اخیستل<strong>${money(total)}</strong></div><div>ټول ورکړل<strong>${money(paid)}</strong></div><div>پاتې<strong>${money(due)}</strong></div></div>
 <div class="tx-actions"><button class="primary" onclick="addForCustomer('${c.id}')">＋ نوې معامله</button><button onclick="deleteCustomer('${c.id}')">حذف</button></div>
 <hr>${tx.map(t=>`<div class="tx-row"><div><strong>${esc(t.item)}</strong><div class="muted">${t.date} ${t.time} • مقدار ${t.qty}</div></div><div><strong>${money(t.total)}</strong><div class="muted">ورکړل: ${money(t.paid)} • پاتې: ${money(t.total-t.paid)}</div></div></div>`).join('')||'<div class="empty">تر اوسه معامله نشته.</div>'}`;
 $('customerViewDialog').showModal();
}
window.addForCustomer=id=>{ $('customerViewDialog').close(); $('txCustomer').innerHTML=db.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');$('txCustomer').value=id;$('transactionForm').reset();$('txCustomer').value=id;$('txQty').value=1;$('txPrice').value=0;$('txPaid').value=0;calc();$('transactionDialog').showModal()}
window.deleteCustomer=id=>{if(confirm('دا پیرودونکی او د هغه ټول حسابونه حذف شي؟')){db.customers=db.customers.filter(c=>c.id!==id);db.transactions=db.transactions.filter(t=>t.customerId!==id);save();$('customerViewDialog').close()}}
$('searchInput').oninput=render;
$('settingsBtn').onclick=()=>$('settingsDialog').showModal();
$('saveSettings').onclick=()=>{db.settings.shopName=$('shopName').value.trim()||'AR Hisab';save();$('settingsDialog').close()}
$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`AR-Hisab-Backup-${new Date().toLocaleDateString('en-CA')}.json`;a.click();URL.revokeObjectURL(a.href)}
$('importBtn').onclick=()=>$('importFile').click();
$('importFile').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.customers||!x.transactions)throw 0;if(confirm('اوسني معلومات د Backup سره بدل شي؟')){db=x;save();alert('Backup په بریالیتوب راوستل شو.')}}catch{alert('Backup فایل ناسم دی.')}};r.readAsText(f)}
$('backupNav').onclick=()=>$('settingsDialog').showModal();
$('customersNav').onclick=()=>window.scrollTo({top:document.querySelector('.section').offsetTop-10,behavior:'smooth'});
$('reportsNav').onclick=()=>alert('راپورونه په بل قدم کې د همدې معلوماتو پر بنسټ فعالیږي.');
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
render();