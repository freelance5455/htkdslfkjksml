import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.arhisab.app',
  appName: 'AR Hisab',
  webDir: '.',
  bundledWebRuntime: false
};

export default config;
