# AR Hisab — Android Build

## Build APK from an Android phone
1. Create/sign in to a GitHub account.
2. Create a new repository (for example: `ar-hisab`).
3. Upload all files from this folder to the repository.
4. Open **Actions** → **Build AR Hisab Android APK** → **Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run → **Artifacts** → download `AR-Hisab-debug-apk`.
7. Extract the ZIP and install `app-debug.apk` on Android.

Package ID: `com.arhisab.app`
App name: `AR Hisab`
