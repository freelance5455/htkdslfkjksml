AR HISAB

دا نسخه د هر ډول دوکان لپاره د مشتریانو او حسابونو لومړنی بشپړ PWA prototype دی.

فایلونه:
- index.html
- style.css
- app.js
- manifest.json

اوسني امکانات:
- پیرودونکي
- اختیاري موبایل او پته
- جنس، مقدار، قیمت
- ورکړل شوې او پاتې پیسې
- اتومات تاریخ او وخت
- د پیرودونکي بشپړ حساب
- لټون
- Dashboard
- محلي JSON Backup/Restore
- موبایل-friendly/PWA جوړښت

مهم:
Google Drive/Google Account automatic cloud backup د دې لپاره د Google OAuth او backend/cloud database ته اړتیا لري. دا برخه باید د publish وروسته د اصلي Google Cloud project سره وصل شي؛ یوازې HTML/CSS/JS کې د Google password یا token ساتل خوندي نه دي.

د کارولو لپاره:
1. ټول فایلونه په یوه فولډر کې وساتئ.
2. index.html خلاص کړئ، یا فولډر په هر static hosting کې publish کړئ.
3. په موبایل کې یې د browser له لارې Add to Home Screen کولی شئ.
