# Blockcraft APK

Needs: Node.js 18+, Android Studio (with an Android SDK), and internet for the one-time setup.

1. Download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js and save it as `www/three.min.js`
   (without it the app still works, but only while online).
2. In this folder run:
   npm install
   npx cap add android
   npx cap sync
   npx cap open android
3. In Android Studio wait for Gradle to finish, then Build > Build Bundle(s) / APK(s) > Build APK(s).
   The file is at android/app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and install it
   (allow "install unknown apps").

Optional: for landscape, add android:screenOrientation="sensorLandscape" to the <activity> tag in
android/app/src/main/AndroidManifest.xml.
