// Cloudinary Upload Helper for BooKErth
// v2 — inclui suporte a 'document' (PDF/raw) e 'capa' (capas de livros)
const CLOUDINARY_CLOUD_NAME = "dcwc9xnp8";
const CLOUDINARY_UPLOAD_PRESET = "bro_uploads";
const CLOUDINARY_API_KEY = "897327451892792";

const MEDIA_CONFIG = {
  image: { resourceType: 'image', maxSizeMB: 10, folder: 'geylin/profiles' },
  video: { resourceType: 'video', maxSizeMB: 100, folder: 'geylin/videos' },
  audio: { resourceType: 'video', maxSizeMB: 50, folder: 'geylin/audios' },
  document: { resourceType: 'raw', maxSizeMB: 50, folder: 'geylin/livros' },
  capa: { resourceType: 'image', maxSizeMB: 10, folder: 'geylin/capas' }
};

function detectMediaType(file) {
  const mime = file.type.toLowerCase();
  if (mime === 'application/pdf') return 'document';
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('video/')) return 'video';
  if (mime.startsWith('audio/')) return 'audio';
  return null;
}

function validateFile(file) {
  const type = detectMediaType(file);
  if (!type) return { valid: false, error: 'Formato não suportado. Aceita: imagem, vídeo, áudio.' };
  const config = MEDIA_CONFIG[type];
  if (file.size > config.maxSizeMB * 1024 * 1024) {
    return { valid: false, error: `Ficheiro muito grande. Máx: ${config.maxSizeMB}MB.` };
  }
  return { valid: true, type };
}

async function uploadToCloudinary(file, type, onProgress) {
  const config = MEDIA_CONFIG[type];
  if (!config) {
    throw new Error(`Tipo de ficheiro desconhecido: "${type}". Verifica se estás a usar a versão mais recente de cloudinary-upload.js (precisa dos tipos 'document' e 'capa').`);
  }
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  formData.append('api_key', CLOUDINARY_API_KEY);
  formData.append('folder', config.folder);
  formData.append('resource_type', config.resourceType);

  if (type === 'image' || type === 'capa') {
    formData.append('quality', 'auto');
    formData.append('fetch_format', 'auto');
  }

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable && onProgress) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    });
    xhr.addEventListener('load', () => {
      if (xhr.status === 200) {
        const res = JSON.parse(xhr.responseText);
        resolve({
          url: res.secure_url,
          publicId: res.public_id,
          type,
          format: res.format,
          width: res.width,
          height: res.height
        });
      } else {
        let msg = 'Upload falhou (' + xhr.status + ')';
        try {
          const errRes = JSON.parse(xhr.responseText);
          if (errRes && errRes.error && errRes.error.message) msg = errRes.error.message;
        } catch (parseErr) { /* mantém msg genérica */ }
        reject(new Error(msg));
      }
    });
    xhr.addEventListener('error', () => reject(new Error('Erro de rede')));
    xhr.open('POST', `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/${config.resourceType}/upload`);
    xhr.send(formData);
  });
}

// Expor globalmente
window.uploadToCloudinary = uploadToCloudinary;
window.validateFile = validateFile;
window.detectMediaType = detectMediaType;
