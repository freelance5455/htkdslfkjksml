package com.trademater.myapp;

// Splash Activity placeholder