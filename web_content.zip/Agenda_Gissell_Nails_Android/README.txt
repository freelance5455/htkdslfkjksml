AGENDA GISSELL NAILS — PROYECTO ANDROID
=======================================

Este proyecto envuelve la última versión de la agenda en una aplicación Android
llamada "Agenda Gissell Nails". La agenda funciona localmente y conserva sus
datos mediante el almacenamiento del navegador dentro de WebView.

Para generar el APK:
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Selecciona Build > Build APK(s).
4. El APK aparecerá normalmente en:
   app/build/outputs/apk/debug/app-debug.apk

Nombre de la aplicación:
Agenda Gissell Nails

Nota:
El APK de depuración no está firmado para publicación en Play Store, pero sí
sirve para instalarlo manualmente en un Android.
