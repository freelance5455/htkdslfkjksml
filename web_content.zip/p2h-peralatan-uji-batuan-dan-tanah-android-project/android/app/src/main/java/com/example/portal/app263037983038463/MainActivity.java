package com.example.portal.app263037983038463;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
