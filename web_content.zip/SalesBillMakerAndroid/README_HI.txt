SALES BILL MAKER - ANDROID APP PROJECT

इस फोल्डर में Android Studio प्रोजेक्ट है। यह अभी APK फ़ाइल नहीं है।

APK बनाने का तरीका:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को Extract करके SalesBillMaker फोल्डर Open करें।
3. Gradle Sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें, अगर पूछा जाए।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. APK को अपने Android फोन में भेजकर इंस्टॉल करें। फोन में अनुमति पूछे जाने पर केवल अपने बनाए APK को इंस्टॉल करने की अनुमति दें।

ऐप की सुविधाएँ:
- ग्राहक और दुकान की जानकारी
- सामान, मात्रा, रेट और डिस्काउंट
- कुल रकम की गणना
- बिल सेव/री-ओपन (फोन में ऐप डेटा के अंदर WebView storage)
- बिल प्रिंट/PDF संवाद

नोट: यह शुरुआती संस्करण है; GST, स्टॉक मैनेजमेंट और क्लाउड बैकअप शामिल नहीं हैं। APK इस वातावरण में compile नहीं किया गया है क्योंकि Android SDK/Gradle build tools उपलब्ध नहीं हैं।
