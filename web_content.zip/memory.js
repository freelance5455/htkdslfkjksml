// Armazenamento local (IndexedDB): conversas, memórias de longo prazo e configurações.
const S=['chats','mems','cfg'];let P;
const db=()=>P||(P=new Promise((ok,no)=>{const r=indexedDB.open('gabxai',1);r.onupgradeneeded=()=>S.forEach(s=>r.result.createObjectStore(s,{keyPath:'id'}));r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}));
const tx=async(s,m,f)=>{const d=await db();return new Promise((ok,no)=>{const t=d.transaction(s,m),q=f(t.objectStore(s));t.oncomplete=()=>ok(q&&q.result);t.onerror=()=>no(t.error)})};
export const put=(s,v)=>tx(s,'readwrite',o=>o.put(v));
export const get=(s,id)=>tx(s,'readonly',o=>o.get(id));
export const all=s=>tx(s,'readonly',o=>o.getAll());
export const del=(s,id)=>tx(s,'readwrite',o=>o.delete(id));
export const wipe=async()=>{for(const s of S)await tx(s,'readwrite',o=>o.clear())};
export const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const tok=t=>new Set((t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').match(/[a-z0-9]{3,}/g)||[]));
// Recuperação: sobreposição de palavras entre a pergunta e cada memória.
export async function recall(q,n=5){const k=tok(q);return(await all('mems')).map(m=>({m,s:[...tok(m.text)].filter(w=>k.has(w)).length})).filter(x=>x.s>0).sort((a,b)=>b.s-a.s).slice(0,n).map(x=>x.m)}
export const remember=t=>put('mems',{id:uid(),text:t,ts:Date.now()});
