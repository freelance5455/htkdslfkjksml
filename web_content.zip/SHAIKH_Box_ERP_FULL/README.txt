SHAIKH Box ERP - Full Offline Edition (v1 foundation)

Included:
Dashboard, Menu, Company Profile, Box Designer preview, Corrugated Costing,
Quick GST Billing, Quotations, Party/Vendor, Purchase, Stock IN/OUT,
Khata Book, Reports, local persistent storage and JSON backup.

Android build:
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).

Important:
This is a functional offline business prototype/foundation. Before production deployment,
GST invoice/legal compliance, accounting rules, backup encryption, multi-user sync,
printer/WhatsApp integrations and exact factory costing formulas should be validated.
