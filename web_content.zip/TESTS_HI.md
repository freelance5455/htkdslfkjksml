# v1.5.3 verification

- Regression fix: Paper Monitor is initialized independently of the Live API button.
- Separate status outputs are used for read-only API checks and Paper Monitor.
- Added overlap guard and malformed saved-state / malformed API JSON handling.
- Node.js unit tests cover the Groww read-only proxy and BUY/SELL SL/Target threshold logic.
- Scope of tests: mock/unit tests only. No live Groww token, real API call, Netlify deploy, live order, or Android APK install was tested.
