const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENROUTER_API_KEY;
const TEXT_MODEL = process.env.OPENROUTER_TEXT_MODEL || "openrouter/free";
const VISION_MODEL = process.env.OPENROUTER_VISION_MODEL || "google/gemma-4-26b-a4b-it:free";

app.use(cors());
app.use(express.json({ limit: "12mb" }));

app.get("/", (_, res) => res.json({ ok: true, service: "Fanci AI" }));
app.get("/health", (_, res) => res.json({ ok: true }));

function imageContent(message, image) {
  return [
    { type: "text", text: String(message || "Analisis gambar ini.").trim() || "Analisis gambar ini." },
    { type: "image_url", image_url: { url: image } }
  ];
}

function cleanReply(reply) {
  if (typeof reply !== "string") return "";
  return reply
    .replace(/^\s*(?:User\s+Safety|Safety|Moderation)\s*:\s*[^\n]*\n?/i, "")
    .trim();
}

app.post("/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: "OPENROUTER_API_KEY belum disetel di Railway." });

    const message = String(req.body?.message || "").trim();
    const image = typeof req.body?.image === "string" ? req.body.image : null;
    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    if (!message && !image) return res.status(400).json({ error: "message atau image diperlukan." });

    const safeHistory = history
      .filter(x => x && (x.role === "user" || x.role === "assistant") && typeof x.content === "string")
      .slice(-16)
      .map(x => ({ role: x.role, content: x.content }));

    const system = { role: "system", content: "Kamu adalah Fanci AI. Ngobrollah seperti teman AI modern: hangat, natural, santai, responsif, dan tidak kaku atau terlalu formal. Ikuti gaya bahasa pengguna tanpa berlebihan. Jangan selalu mengulang pertanyaan pengguna. Untuk obrolan ringan, jawab ringan; untuk pertanyaan serius, jawab jelas dan tenang. Balas dalam bahasa pengguna; gunakan Bahasa Indonesia jika pengguna memakai Bahasa Indonesia. Jangan menampilkan metadata internal, status moderasi, label keselamatan, nama field API, token, atau teks seperti User Safety: safe. Jika ada gambar, benar-benar gunakan isi gambar untuk menjawab pertanyaan pengguna. Jika gambar tidak terbaca, katakan dengan jujur." };
    const current = { role: "user", content: image ? imageContent(message, image) : message };
    const model = image ? VISION_MODEL : TEXT_MODEL;

    const body = { model, messages: [system, ...safeHistory, current], temperature: 0.7 };
    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://fanci-ai-production.up.railway.app",
        "X-Title": "Fanci AI"
      },
      body: JSON.stringify(body)
    });

    const data = await r.json().catch(() => ({}));
    if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || `OpenRouter HTTP ${r.status}` });

    const reply = cleanReply(data?.choices?.[0]?.message?.content);
    if (!reply) return res.status(502).json({ error: "Model tidak mengembalikan teks." });
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Terjadi kesalahan pada server Fanci AI." });
  }
});

app.listen(PORT, () => console.log(`Fanci AI server listening on ${PORT}`));
