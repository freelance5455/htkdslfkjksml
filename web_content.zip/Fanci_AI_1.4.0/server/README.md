# Fanci AI Railway server

Replace the current Railway `server.js` with this one, or deploy this `server/` directory.

Required environment variable:
- `OPENROUTER_API_KEY` — keep this only in Railway.

Optional:
- `OPENROUTER_TEXT_MODEL` (default `openrouter/free`)
- `OPENROUTER_VISION_MODEL` (default `google/gemma-4-26b-a4b-it:free`)

The image route uses a vision-capable model and receives the compressed image as a base64 data URL.
