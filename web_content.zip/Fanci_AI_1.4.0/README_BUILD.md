# Fanci AI 1.2.0 — Android Modular

Modules:
- `app`: Android application, WebView UI, gallery/camera file chooser, native TTS bridge.
- `core`: shared Fanci configuration.

AI architecture:
Android APK -> Railway `/chat` -> OpenRouter.
The OpenRouter API key is NOT stored in this project or APK.

Build with Android Studio:
1. Open this folder.
2. Let Gradle sync (Gradle 8.7 + Android Gradle Plugin 8.5.2).
3. Build > Generate App Bundle / APK > Generate APK.

For a local/Termux build with Android SDK configured:
`./gradlew assembleDebug`

Release:
`./gradlew assembleRelease`

Note: this source archive intentionally does not contain Gradle caches, SDK files, or node_modules. Those are build dependencies and would unnecessarily inflate the ZIP.


## Fanci AI 1.4.0 Vision fix

This version uses a native Android gallery picker instead of relying on the WebView file chooser. The selected photo is resized to at most 1280 px, JPEG-compressed, converted to a data URL, and passed to the web UI. The UI then sends it as `image` to `/chat`.

For Railway, deploy `server/server.js` and keep `OPENROUTER_API_KEY` only in Railway. Image requests use the free multimodal model `google/gemma-4-26b-a4b-it:free` by default; text requests use `openrouter/free`.

The Android free build does not request CAMERA permission.


## Fanci AI 1.5 Premium Update
- Premium glassmorphism/dark purple-blue UI with original inline character artwork.
- Natural conversation system prompt.
- Vision photo chat retained.
- Send request can be cancelled by pressing the send button again while processing.
- Camera remains a Pro UI feature; no CAMERA permission was added to AndroidManifest.
- OpenRouter API key remains server-side on Railway.
