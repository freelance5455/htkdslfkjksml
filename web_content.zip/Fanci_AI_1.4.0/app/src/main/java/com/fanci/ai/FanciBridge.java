package com.fanci.ai;

import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;

public final class FanciBridge {
    private final MainActivity activity;
    private final TextToSpeech tts;

    public FanciBridge(MainActivity activity, TextToSpeech tts) {
        this.activity = activity;
        this.tts = tts;
    }

    @JavascriptInterface
    public void speak(String text) {
        if (tts != null) {
            tts.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "fanci");
        }
    }

    @JavascriptInterface
    public void pickGallery() {
        activity.openGallery();
    }
}
