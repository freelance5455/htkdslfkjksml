package com.fanci.ai;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private static final int GALLERY_REQUEST = 2001;
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,8,18));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(6,6,15));
        getWindow().getDecorView().setSystemUiVisibility(0);

        tts = new TextToSpeech(this, status -> {
            if (tts != null && status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("id", "ID"));
        });

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(8,8,18));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new FanciBridge(this, tts), "AndroidFanci");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public void openGallery() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try { startActivityForResult(intent, GALLERY_REQUEST); }
        catch (Exception e) {
            Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
            fallback.setType("image/*");
            startActivityForResult(fallback, GALLERY_REQUEST);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            imageExecutor.execute(() -> {
                String dataUrl = uriToDataUrl(uri);
                runOnUiThread(() -> {
                    if (webView == null) return;
                    if (dataUrl == null) {
                        webView.evaluateJavascript("window.toast && window.toast('Foto gagal dibaca')", null);
                    } else {
                        String js = "window.onNativeImage(" + toJsString(dataUrl) + ");";
                        webView.evaluateJavascript(js, null);
                    }
                });
            });
        }
    }

    private String uriToDataUrl(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            Bitmap original = BitmapFactory.decodeStream(in);
            if (original == null) return null;
            int max = 1280;
            float scale = Math.min(1f, max / (float)Math.max(original.getWidth(), original.getHeight()));
            int w = Math.max(1, Math.round(original.getWidth() * scale));
            int h = Math.max(1, Math.round(original.getHeight() * scale));
            Bitmap bitmap = (scale < 1f) ? Bitmap.createScaledBitmap(original, w, h, true) : original;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 78, out);
            if (bitmap != original) bitmap.recycle();
            original.recycle();
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private String toJsString(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        imageExecutor.shutdownNow();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
