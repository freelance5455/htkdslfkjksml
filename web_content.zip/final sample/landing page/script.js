// ========================================
// FIGURES OF SPEECH - LANDING PAGE
// ========================================

function startLearning() {

    // Small button animation
    const button = document.querySelector(".start-button");

    button.innerHTML = "Opening App... ✨";

    button.style.pointerEvents = "none";


    // Open the main menu
    setTimeout(function () {

        window.location.href = "../menu/menu.html";

    }, 600);
}