/* =========================
   FIGURES OF SPEECH APP
========================= */


/* Current progress */

let progress = 0;


/* Load saved progress */

const savedProgress = localStorage.getItem("figuresProgress");

if (savedProgress !== null) {
    progress = Number(savedProgress);
}


/* Update progress when page loads */

window.addEventListener("load", function () {

    updateProgress();

});


/* =========================
   UPDATE PROGRESS
========================= */

function updateProgress() {

    const progressText =
        document.getElementById("progressText");

    const progressFill =
        document.getElementById("progressFill");


    progressText.textContent =
        progress + "%";

    progressFill.style.width =
        progress + "%";
}


/* =========================
   OPEN ACTIVITY
========================= */

function openActivity(activity) {

    if (activity === "learn") {

        increaseProgress(10);
        window.location.href = "../learn page/learn page.html";

    }

    else if (activity === "practice") {

        increaseProgress(10);
        window.location.href = "../practice page/practice page.html";

    }

    else if (activity === "challenge") {

        increaseProgress(10);
        window.location.href = "../challenge page/index.html";

    }

}


/* =========================
   INCREASE PROGRESS
========================= */

function increaseProgress(amount) {

    progress += amount;


    if (progress > 100) {
        progress = 100;
    }


    localStorage.setItem(
        "figuresProgress",
        progress
    );


    updateProgress();

}