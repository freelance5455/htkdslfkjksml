MACROFLOW - STARTER PROJECT

HOW TO RUN
1. Extract the ZIP file.
2. Open the MacroFlow folder.
3. Open index.html in a modern browser (Chrome recommended).
4. Create a rule and use "Run test trigger" to test manual rules.

WHAT IS INCLUDED
- Local rule storage using browser localStorage.
- Create and delete automation rules.
- Manual test trigger.
- Battery-level trigger where supported.
- Online/offline network triggers.
- Time trigger checked every minute while the page is open.
- Notification, vibration, website-opening actions.
- Wi-Fi action placeholder with an explanation of browser restrictions.

IMPORTANT LIMITATIONS
This is a browser-based starter project, not a native Android APK.
The page must remain open for its JavaScript timers and event listeners to run.
Browser APIs differ by device. Battery Status API is unavailable in some browsers.
A normal website cannot turn Wi-Fi on/off or reliably launch arbitrary installed apps.
For reliable background automations and native device controls, build a native Android
application with the appropriate Android APIs and permissions.

SECURITY
This starter does not execute arbitrary custom JavaScript supplied by users.
Rules are stored locally in this browser profile. Clearing browser site data may erase them.
