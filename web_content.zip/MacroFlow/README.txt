MACROFLOW - EXPANDED STARTER PROJECT

CONTENTS
- index.html, styles.css, app.js
- Searchable macro library with 320+ starter recipes
- Create, add, save and delete macros
- Notification and location permission prompts when the relevant feature is selected
- Battery and online/offline event hooks where the browser supports them
- Manual test trigger, vibration and website-opening actions
- Developer credit: Etienne Forster

RUN
1. Extract MacroFlow_Pro.zip.
2. Open index.html in Chrome or another modern browser.
3. Use Macro library to search recipes and press Add.
4. Check Permissions for notification and location access.

IMPORTANT PLATFORM LIMITATIONS
This is a browser/PWA starter, not a native Android app and not a complete MacroDroid replacement.
A browser cannot directly toggle Wi-Fi, launch arbitrary installed apps, reliably monitor sensors
while closed, or guarantee background location/time automations. Some APIs (including Battery
Status) are unavailable in many browsers. Location permission is requested only when a
location-trigger recipe is selected. Notification permission is requested when a notification
recipe is added or when you press Allow notifications.

For a true Android automation app, the project needs a native Android layer using supported
Android APIs and runtime permissions. Android restricts several actions for privacy and security.
The macro library includes starter recipes; recipes that require native Android capabilities are
clearly marked as concepts or native-only in the interface.
