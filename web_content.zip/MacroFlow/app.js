(() => {
  "use strict";
  const STORAGE_KEY = "macroflow_rules_v1";
  const $ = (id) => document.getElementById(id);
  const readRules = () => {
    try { const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); return Array.isArray(value) ? value : []; }
    catch { return []; }
  };
  let rules = readRules();
  const save = () => localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
  const safeText = (value) => String(value ?? "");
  const labels = {
    MANUAL_BUTTON: "Manual test", BATTERY: "Battery", TIME: "Time", NETWORK_CHANGE: "Network",
    NOTIFICATION: "Notification", VIBRATE: "Vibration", OPEN_APP: "Open website", TOGGLE_WIFI: "Wi-Fi request"
  };

  function render() {
    const list = $("rules-list");
    list.replaceChildren();
    if (!rules.length) {
      const empty = document.createElement("p");
      empty.className = "empty-state";
      empty.textContent = 'No automations yet. Select "Create rule" to add one.';
      list.append(empty); return;
    }
    rules.forEach(rule => {
      const card = document.createElement("article"); card.className = "rule-card";
      const details = document.createElement("div");
      const name = document.createElement("strong"); name.textContent = rule.name;
      const meta = document.createElement("div"); meta.className = "rule-meta";
      meta.textContent = `${labels[rule.trigger.type] || rule.trigger.type} → ${labels[rule.action.type] || rule.action.type}`;
      details.append(name, meta);
      const actions = document.createElement("div"); actions.className = "rule-actions";
      const tag = document.createElement("span"); tag.className = "tag"; tag.textContent = "Saved";
      const del = document.createElement("button"); del.className = "delete-btn"; del.textContent = "Delete";
      del.setAttribute("aria-label", `Delete ${rule.name}`);
      del.addEventListener("click", () => { rules = rules.filter(r => r.id !== rule.id); save(); render(); });
      actions.append(tag, del); card.append(details, actions); list.append(card);
    });
  }

  function matches(rule, type, payload) {
    if (rule.trigger.type !== type) return false;
    const c = rule.trigger.conditions || {};
    for (const [key, expected] of Object.entries(c)) {
      const actual = payload[key];
      if (key === "level" && Number(actual) * 100 > Number(expected)) return false;
      else if (key !== "level" && String(actual) !== String(expected)) return false;
    }
    return true;
  }

  async function runAction(action) {
    const config = action.config || {};
    if (action.type === "NOTIFICATION") {
      const title = config.title || "MacroFlow", body = config.message || "Your automation ran.";
      if ("Notification" in window && Notification.permission === "granted") new Notification(title, { body });
      else if ("Notification" in window && Notification.permission !== "denied") {
        const permission = await Notification.requestPermission();
        if (permission === "granted") new Notification(title, { body }); else alert(`${title}\n${body}`);
      } else alert(`${title}\n${body}`);
    } else if (action.type === "VIBRATE") {
      if (navigator.vibrate) navigator.vibrate([250, 120, 250]);
      else $("test-result").textContent = "Vibration is not supported in this browser.";
    } else if (action.type === "OPEN_APP") {
      if (config.url && /^https?:\/\//i.test(config.url)) window.open(config.url, "_blank", "noopener,noreferrer");
      else alert("Add a valid https:// website URL to this rule.");
    } else if (action.type === "TOGGLE_WIFI") {
      alert("Browsers cannot switch Wi-Fi directly. This action is a placeholder for a native Android version.");
    }
  }

  function process(type, payload = {}) {
    const found = rules.filter(rule => matches(rule, type, payload));
    found.forEach(rule => runAction(rule.action));
    $("test-result").textContent = found.length ? `${found.length} matching automation(s) ran.` : "No matching automations for this trigger.";
  }

  $("show-form").addEventListener("click", () => $("form-panel").classList.remove("hidden"));
  $("cancel-form").addEventListener("click", () => $("form-panel").classList.add("hidden"));
  $("create-rule-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const key = safeText(data.get("conditionKey"));
    let value = safeText(data.get("conditionValue")).trim();
    const conditions = {};
    if (key && value) conditions[key] = key === "level" ? Math.max(0, Math.min(100, Number(value))) : value;
    rules.push({
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random())),
      name: safeText(data.get("name")).trim(),
      trigger: { type: data.get("triggerType"), conditions },
      action: { type: data.get("actionType"), config: {
        title: data.get("notifTitle"), message: data.get("notifMessage"), url: data.get("url")
      }}
    });
    save(); render(); event.currentTarget.reset(); $("form-panel").classList.add("hidden");
    $("status").textContent = "Saved";
  });
  $("manual-trigger").addEventListener("click", () => process("MANUAL_BUTTON", { timestamp: Date.now() }));

  // Battery monitoring is browser-dependent and works only while this page is active.
  if (navigator.getBattery) {
    navigator.getBattery().then(battery => {
      const update = () => process("BATTERY", { level: battery.level });
      battery.addEventListener("levelchange", update); update();
    }).catch(() => {});
  }
  window.addEventListener("online", () => process("NETWORK_CHANGE", { status: "online" }));
  window.addEventListener("offline", () => process("NETWORK_CHANGE", { status: "offline" }));

  // Time rules are checked once per minute while the page remains open.
  function checkTime() {
    const now = new Date(), clock = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
    process("TIME", { time: clock });
  }
  setInterval(checkTime, 60000);
  render();
})();