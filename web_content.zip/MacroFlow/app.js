(() => {
"use strict";
const $ = id => document.getElementById(id), KEY = "macroflow_rules_v2";
const read = () => { try { const x=JSON.parse(localStorage.getItem(KEY)||"[]"); return Array.isArray(x)?x:[]; } catch { return []; } };
let rules=read(), activeFilter="All";
const categories = {
"Battery":["Battery drops below 20%","Battery reaches 80%","Battery is fully charged","Battery starts charging","Battery stops charging","Battery is critically low","Battery level changes","Power saver reminder","Charging reminder","Unplug reminder","Battery check-in","Low battery alert","Full charge alert","Charging status notice","Battery morning report","Battery evening report","Battery level test","Battery saver notification","Charge cable reminder","Battery health check"],
"Time":["Morning greeting","Good night reminder","Lunch reminder","Study time alert","Break reminder","Daily planning reminder","Evening routine","Weekend reminder","Hourly check-in","Every 30 minutes","Wake-up notification","Bedtime notification","Water break reminder","Homework reminder","Reading reminder","Exercise reminder","Daily summary","Weekly planning","Calendar prep reminder","Custom time alert"],
"Network":["Internet comes online","Internet goes offline","Connection restored alert","Offline mode reminder","Online status notice","Network change log","Reconnect reminder","Wi-Fi availability note","Data connection reminder","Connection check"],
"Location":["Location permission test","Arrive at saved place (concept)","Leave saved place (concept)","Location check-in (concept)","Home arrival reminder (concept)","School arrival reminder (concept)","Work arrival reminder (concept)","Location-based note (concept)","Nearby reminder (concept)","Location status check (concept)"],
"Manual":["Quick reminder button","Test notification","Test vibration","Open favourite website","Start focus session","End focus session","Show daily checklist","Quick status alert","Manual battery check","Manual network check","Launch web shortcut","Personal reminder","Study mode prompt","Break mode prompt","Custom note alert","Run test macro","Quick motivation","Daily goal reminder","Manual check-in","Emergency contact page shortcut"]
};
const triggers=["Manual test","At a selected time","Battery status","Internet status","Location (permission required)"];
const actions=["Show notification","Vibrate","Open a website","Wi-Fi action (native Android only)","Save a reminder (in-app concept)","Display a message"];
const templates=[];
for (const [cat,names] of Object.entries(categories)) {
  names.forEach((name,i)=>templates.push({name,category:cat,trigger:triggers[i%triggers.length],action:actions[i%actions.length],triggerType:({Battery:"BATTERY",Time:"TIME",Network:"NETWORK_CHANGE",Location:"LOCATION",Manual:"MANUAL_BUTTON"})[cat],actionType:({0:"NOTIFICATION",1:"VIBRATE",2:"OPEN_APP",3:"TOGGLE_WIFI",4:"NOTIFICATION",5:"NOTIFICATION"})[i%6]}));
}
const adjectives=["Quick","Smart","Daily","Simple","Automatic","Personal","Helpful","Custom","Instant","Routine","Context","Flexible","Easy","Pro","Extra"];
const nouns=["Reminder","Alert","Check","Notice","Prompt","Helper","Routine","Shortcut","Status","Assistant","Nudge","Monitor","Update","Action","Task"];
for(let i=0;templates.length<320;i++){
 const cat=["Battery","Time","Network","Manual"][i%4];
 templates.push({name:`${adjectives[i%15]} ${nouns[Math.floor(i/15)%15]} ${Math.floor(i/60)+1}`,category:cat,trigger:triggers[i%4],action:actions[i%3],triggerType:({Battery:"BATTERY",Time:"TIME",Network:"NETWORK_CHANGE",Manual:"MANUAL_BUTTON"})[cat],actionType:["NOTIFICATION","VIBRATE","OPEN_APP"][i%3]});
}
function save(){localStorage.setItem(KEY,JSON.stringify(rules));}
function renderRules(){
 const list=$("rules-list");list.replaceChildren();
 if(!rules.length){const p=document.createElement("p");p.className="empty-state";p.textContent="No macros yet. Add one from the library or create your own.";list.append(p);return;}
 rules.forEach(r=>{const card=document.createElement("article");card.className="rule-card";const left=document.createElement("div"),b=document.createElement("strong"),m=document.createElement("div");b.textContent=r.name;m.className="rule-meta";m.textContent=`${r.trigger.type} → ${r.action.type}`;left.append(b,m);const right=document.createElement("div");right.className="rule-actions";const tag=document.createElement("span");tag.className="tag";tag.textContent="Saved";const del=document.createElement("button");del.className="delete-btn";del.textContent="Delete";del.onclick=()=>{rules=rules.filter(x=>x.id!==r.id);save();renderRules();};right.append(tag,del);card.append(left,right);list.append(card);});
}
function addMacro(t){
 rules.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random()),name:t.name,trigger:{type:t.triggerType,conditions:{}},action:{type:t.actionType,config:{title:t.name,message:`Macro "${t.name}" was triggered.`}}});
 save();renderRules();$("status").textContent="Macro added";
}
function renderLibrary(){
 const list=$("template-list"),q=$("search").value.toLowerCase();list.replaceChildren();
 const shown=templates.filter(t=>(activeFilter==="All"||t.category===activeFilter)&&`${t.name} ${t.category} ${t.trigger} ${t.action}`.toLowerCase().includes(q));
 $("shown-count").textContent=`${shown.length} of ${templates.length} recipes`;
 shown.forEach(t=>{const card=document.createElement("article");card.className="template-card";const left=document.createElement("div"),b=document.createElement("strong"),m=document.createElement("div");b.textContent=t.name;m.className="template-meta";m.textContent=`${t.category} · ${t.trigger} → ${t.action}`;left.append(b,m);const btn=document.createElement("button");btn.className="primary";btn.textContent="＋ Add";btn.onclick=()=>{if(t.triggerType==="LOCATION"){requestLocation().then(ok=>{if(ok)addMacro(t);});return;}if(t.actionType==="NOTIFICATION")requestNotifications();addMacro(t);};card.append(left,btn);list.append(card);});
}
function buildFilters(){
 const box=$("filters");["All",...Object.keys(categories)].forEach(c=>{const b=document.createElement("button");b.className="filter"+(c==="All"?" active":"");b.textContent=c;b.onclick=()=>{activeFilter=c;[...box.children].forEach(x=>x.classList.toggle("active",x===b));renderLibrary();};box.append(b);});
}
async function requestNotifications(){
 if(!("Notification" in window)){alert("Notifications are not supported in this browser.");return false;}
 if(Notification.permission==="granted")return true;
 const p=await Notification.requestPermission();return p==="granted";
}
function requestLocation(){
 return new Promise(resolve=>{if(!navigator.geolocation){alert("Location is not supported by this browser.");resolve(false);return;}
 navigator.geolocation.getCurrentPosition(()=>{alert("Location permission granted. Note: reliable background geofencing needs a native Android app.");resolve(true);},()=>{alert("Location permission was not granted. You can enable it in browser site settings.");resolve(false);},{timeout:10000});});
}
function runAction(a){const c=a.config||{};if(a.type==="NOTIFICATION"){if("Notification"in window&&Notification.permission==="granted")new Notification(c.title||"MacroFlow",{body:c.message||"Macro ran."});else alert(`${c.title||"MacroFlow"}\n${c.message||"Macro ran."}`);}else if(a.type==="VIBRATE"){if(navigator.vibrate)navigator.vibrate([250,120,250]);else alert("Vibration is not supported.");}else if(a.type==="OPEN_APP"){if(c.url&&/^https?:\/\//i.test(c.url))window.open(c.url,"_blank","noopener,noreferrer");else alert("Add a website URL in a custom macro to use this action.");}else alert("Direct Wi-Fi control requires a native Android app.");}
function process(type,payload={}){const matched=rules.filter(r=>r.trigger.type===type);matched.forEach(r=>runAction(r.action));$("test-result").textContent=matched.length?`${matched.length} matching macro(s) ran.`:"No macros matched this test trigger.";}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tab-page").forEach(x=>x.classList.toggle("hidden",x.id!==b.dataset.tab));});
$("show-form").onclick=()=>$("form-panel").classList.remove("hidden");$("cancel-form").onclick=()=>$("form-panel").classList.add("hidden");
$("create-rule-form").onsubmit=e=>{e.preventDefault();const d=new FormData(e.currentTarget),key=d.get("conditionKey"),val=d.get("conditionValue");const conditions={};if(key&&val)conditions[key]=key==="level"?Number(val):val;const type=d.get("triggerType");if(type==="LOCATION"){requestLocation().then(ok=>{if(ok)finish();});}else finish();
function finish(){rules.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name:d.get("name"),trigger:{type,conditions,time:d.get("time")},action:{type:d.get("actionType"),config:{title:d.get("notifTitle"),message:d.get("notifMessage"),url:d.get("url")}}});save();renderRules();e.currentTarget.reset();$("form-panel").classList.add("hidden");}};
$("manual-trigger").onclick=()=>process("MANUAL_BUTTON");$("search").oninput=renderLibrary;
$("ask-notifications").onclick=requestNotifications;$("ask-location").onclick=requestLocation;
$("battery-status").textContent=navigator.getBattery?"Available in this browser":"Not exposed by this browser";
if(navigator.getBattery)navigator.getBattery().then(b=>{b.addEventListener("levelchange",()=>process("BATTERY",{level:b.level}));}).catch(()=>{});
window.addEventListener("online",()=>process("NETWORK_CHANGE",{status:"online"}));window.addEventListener("offline",()=>process("NETWORK_CHANGE",{status:"offline"}));
setInterval(()=>{const d=new Date(),time=`${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;rules.filter(r=>r.trigger.type==="TIME"&&r.trigger.time===time).forEach(r=>runAction(r.action));},60000);
$("library-count").textContent=`${templates.length}+`;buildFilters();renderLibrary();renderRules();
})();