/* MIDOK 1.6 — sessions mémorisées à la demande ; aucun mot de passe enregistré. */
const MidokDevice={
 remember:false,key:null,profile:null,locked:false,write:Promise.resolve(),backArmed:false,
 storageKey(){return 'midok-session-v16:'+MIDOK_APP+':'+Cloud.config().url},
 read(){try{const p=JSON.parse(localStorage.getItem(this.storageKey())||'null');if(!p||p.until<Date.now())return null;return p}catch{return null}},
 b64(v){return btoa(String.fromCharCode(...new Uint8Array(v))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')},
 bytes(v){return Uint8Array.from(atob(v.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0))},
 async persist(){
  if(!this.remember||!Cloud.auth?.refresh_token||!Cloud.account||Cloud.account.must_change_password)return;
  const account=Cloud.account, auth=Cloud.auth;
  const old=this.profile||this.read();
  const name=MIDOK_APP==='membre'?(typeof state!=='undefined'?state.record?.member?.name:''): 'Administration MIDOK';
  const p={user:auth.user.id,name:name||account.code,login:MIDOK_APP==='admin'?auth.user.email:account.code,until:old?.user===auth.user.id?old.until:Date.now()+30*86400000};
  const refresh=auth.refresh_token;
  this.write=this.write.catch(()=>{}).then(async()=>{
   if(old?.credential){
    if(!this.key)throw Error('Déverrouillez le téléphone avant de mémoriser la session.');
    const iv=crypto.getRandomValues(new Uint8Array(12));
    p.credential=old.credential;p.salt=old.salt;p.iv=this.b64(iv);
    p.sealed=this.b64(await crypto.subtle.encrypt({name:'AES-GCM',iv},this.key,new TextEncoder().encode(refresh)));
   }else p.refresh=refresh;
   localStorage.setItem(this.storageKey(),JSON.stringify(p));this.profile=p;
  });
  await this.write;
 },
 async unlock(p){
  const credential=await navigator.credentials.get({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)),allowCredentials:[{id:this.bytes(p.credential),type:'public-key'}],userVerification:'required',extensions:{prf:{eval:{first:this.bytes(p.salt)}}}}});
  const first=credential?.getClientExtensionResults()?.prf?.results?.first;
  if(!first)throw Error('Ce téléphone ne fournit pas le déverrouillage sécurisé requis. Utilisez votre mot de passe.');
  this.key=await crypto.subtle.importKey('raw',first,'AES-GCM',false,['encrypt','decrypt']);
  return new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:this.bytes(p.iv)},this.key,this.bytes(p.sealed)));
 },
 async resume(){
  const p=this.read(),out=document.getElementById('cloud-error'),b=document.getElementById('remembered-enter');if(!p)return;
  b.disabled=true;out.textContent='Ouverture de votre espace…';
  try{
   const refresh=p.credential?await this.unlock(p):p.refresh;
   if(!refresh)throw Error('Saisissez votre mot de passe pour vous reconnecter.');
   this.profile=p;this.remember=true;
   const a=await Cloud.call('/auth/v1/token?grant_type=refresh_token','POST',{refresh_token:refresh});
   if(a.user?.id!==p.user)throw Error('Identité de session incorrecte.');
   Cloud.setAuth(a);await Cloud.enter();
  }catch(e){Cloud.auth=null;this.remember=false;out.textContent=e.name==='NotAllowedError'?'Déverrouillage annulé. Vous pouvez réessayer ou saisir votre mot de passe.':e.message;}finally{b.disabled=false}
 },
 async enableBiometric(){
  try{
   if(location.protocol!=='https:'||!window.PublicKeyCredential||!navigator.credentials||!crypto.subtle)throw Error('Le déverrouillage du téléphone nécessite une version HTTPS et un navigateur compatible. Cette version ToApp ne le propose pas.');
   if(!this.remember||!this.read())throw Error('Connectez-vous en cochant « Se souvenir de moi » avant d’activer cette option.');
   const salt=crypto.getRandomValues(new Uint8Array(32));
   const credential=await navigator.credentials.create({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)),rp:{name:'MIDOK',id:location.hostname},user:{id:new TextEncoder().encode(Cloud.auth.user.id),name:Cloud.account.code,displayName:this.profile?.name||Cloud.account.code},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',residentKey:'preferred',userVerification:'required'},extensions:{prf:{eval:{first:salt}}},timeout:60000}});
   let first=credential?.getClientExtensionResults()?.prf?.results?.first;
   if(!first){const c=await navigator.credentials.get({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)),allowCredentials:[{type:'public-key',id:credential.rawId}],userVerification:'required',extensions:{prf:{eval:{first:salt}}}}});first=c?.getClientExtensionResults()?.prf?.results?.first;}
   if(!first)throw Error('Cette clé d’accès ne prend pas en charge le coffre sécurisé. La connexion classique reste disponible.');
   this.key=await crypto.subtle.importKey('raw',first,'AES-GCM',false,['encrypt','decrypt']);
   this.profile={...this.read(),credential:this.b64(credential.rawId),salt:this.b64(salt)};
   await this.persist();alert('Déverrouillage du téléphone activé. Android choisira l’empreinte, le visage ou le code selon ses réglages.');Cloud.securityPage();
  }catch(e){alert(e.name==='NotAllowedError'?'Activation annulée.':e.message)}
 },
 async forget(){await this.write.catch(()=>{});localStorage.removeItem(this.storageKey());this.profile=null;this.key=null;this.remember=false;},
 async connected(){
  try{await this.persist()}catch(e){Cloud.message('Connexion réussie, mémorisation impossible : '+e.message)}
  this.backArmed=false;
  if(!this.historyReady){this.historyReady=true;try{history.replaceState({midok:'base'},'');history.pushState({midok:'guard'},'')}catch{}}
 },
 back(){
  if(!Cloud.auth)return;
  const exit=document.getElementById('midok-exit');if(exit?.open){exit.close();return;}
  const opened=document.querySelector('dialog[open]');if(opened){opened.close();return;}
  const home=MIDOK_APP==='admin'?'dashboard':'home';
  if(page!==home||!this.backArmed){go(home);this.backArmed=true;return;}
  let d=exit;if(!d){d=document.createElement('dialog');d.id='midok-exit';document.body.append(d)}
  d.innerHTML='<div class="exit-mark">?</div><h2>Quitter mon espace</h2><p>Voulez-vous vous déconnecter ?</p><div class="mobile-actions"><button id="exit-no" class="secondary">NON</button><button id="exit-yes">OUI</button></div>';
  d.querySelector('#exit-no').onclick=()=>d.close();d.querySelector('#exit-yes').onclick=()=>Cloud.logout();d.showModal();
 }
};
window.addEventListener('popstate',()=>{if(Cloud.auth){try{history.pushState({midok:'guard'},'')}catch{}MidokDevice.back()}});
document.addEventListener('backbutton',e=>{e.preventDefault();MidokDevice.back()},false);
