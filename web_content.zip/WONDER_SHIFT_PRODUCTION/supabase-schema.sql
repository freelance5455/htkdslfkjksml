-- WONDER SHIFT - schéma Supabase de production
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  role text not null check (role in ('Agent','Superviseur','Développeur')) default 'Agent',
  active boolean not null default true,
  photo_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.operations (
  id text primary key,
  agent_id uuid references auth.users(id),
  agent text not null,
  type text not null check (type in ('Recette','Dépense')),
  service text not null,
  task text not null,
  quantity numeric not null check (quantity > 0),
  unit_price numeric not null check (unit_price >= 0),
  discount numeric not null default 0 check (discount >= 0),
  total numeric not null check (total >= 0),
  client text,
  payment text,
  observation text,
  date timestamptz not null,
  deleted boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stock_items (
  id text primary key,
  name text not null,
  unit text not null,
  initial numeric not null default 0,
  entries numeric not null default 0,
  exits numeric not null default 0,
  alert numeric not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stock_movements (
  id text primary key,
  stock_id text references public.stock_items(id) on delete cascade,
  quantity numeric not null,
  agent_id uuid references auth.users(id),
  agent text,
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id text primary key,name text not null,active boolean not null default true,builtin boolean not null default false,created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.tasks (
  id text primary key,name text not null,price numeric not null default 0,active boolean not null default true,builtin boolean not null default false,created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
  id text primary key, user_id uuid references auth.users(id), action text not null, metadata jsonb, created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.operations enable row level security;
alter table public.stock_items enable row level security;
alter table public.stock_movements enable row level security;
alter table public.services enable row level security;
alter table public.tasks enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.current_role() returns text language sql stable security definer set search_path=public as $$ select role from public.profiles where id=auth.uid() and active=true limit 1 $$;

create policy "profiles self read" on public.profiles for select using (id=auth.uid() or public.current_role()='Développeur');
create policy "profiles dev write" on public.profiles for all using (public.current_role()='Développeur') with check (public.current_role()='Développeur');
create policy "operations read authenticated" on public.operations for select to authenticated using (true);
create policy "operations insert authenticated" on public.operations for insert to authenticated with check (agent_id=auth.uid() or public.current_role() in ('Superviseur','Développeur'));
create policy "operations update supervisors" on public.operations for update to authenticated using (agent_id=auth.uid() or public.current_role() in ('Superviseur','Développeur')) with check (agent_id=auth.uid() or public.current_role() in ('Superviseur','Développeur'));
create policy "stock read authenticated" on public.stock_items for select to authenticated using (true);
create policy "stock dev write" on public.stock_items for all to authenticated using (public.current_role()='Développeur') with check (public.current_role()='Développeur');
create policy "stock movements read" on public.stock_movements for select to authenticated using (true);
create policy "stock movements write" on public.stock_movements for insert to authenticated with check (public.current_role() in ('Superviseur','Développeur'));
create policy "catalog read" on public.services for select to authenticated using (true);
create policy "catalog dev write" on public.services for all to authenticated using (public.current_role()='Développeur') with check (public.current_role()='Développeur');
create policy "tasks read" on public.tasks for select to authenticated using (true);
create policy "tasks dev write" on public.tasks for all to authenticated using (public.current_role()='Développeur') with check (public.current_role()='Développeur');
create policy "audit read dev" on public.audit_logs for select to authenticated using (public.current_role()='Développeur');
create policy "audit insert auth" on public.audit_logs for insert to authenticated with check (user_id=auth.uid());

-- Après création d'un utilisateur dans Auth, créer son profil :
-- insert into public.profiles(id,name,role) values ('UUID_AUTH','Nom','Agent');
