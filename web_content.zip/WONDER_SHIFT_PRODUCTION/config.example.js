// Renommer en config.js pour activer la synchronisation Supabase.
// Utiliser uniquement la clé anon publique. Jamais service_role.
window.WS_CONFIG={supabaseUrl:'https://VOTRE-PROJET.supabase.co',supabaseAnonKey:'VOTRE_ANON_KEY'};
