# Carreira de Craque v1.51.5 — Avanço de temporada corrigido

- O botão `INICIAR NOVA TEMPORADA!` agora verifica diretamente as partidas do clube do atleta.
- Se todas as partidas do clube estiverem marcadas como disputadas, a finalização da temporada é executada mesmo quando o contador de rodadas estiver dessincronizado.
- Se houver partidas realmente pendentes, a mensagem informa a quantidade encontrada.
- Após avançar, salva o estado e retorna à tela Início.
- Não gera placares fictícios nem marca partidas pendentes como disputadas.

Validação: sintaxe JavaScript e integridade do ZIP. Não foi possível testar a interface dentro do jogo nem confirmar recuperação de um save específico.
