ALIEN TEKNO STUDIO — PODKLAD PRO SKUTEČNÉ ANDROID APK

Co je v balíčku:
- www/index.html: tvůj funkční Alien Tekno Studio mixák
- package.json a capacitor.config.json: konfigurace pro zabalení do Android aplikace

DŮLEŽITÉ: Toto je zdrojový projekt, ne hotový APK. APK se musí sestavit pomocí Android SDK.

Doporučený nástroj:
Android Studio (oficiální nástroj Google):
https://developer.android.com/studio

Postup na počítači:
1. Nainstaluj Node.js 22 nebo novější a Android Studio.
2. Rozbal ZIP.
3. Otevři terminál ve složce Alien-Tekno-Studio.
4. Spusť postupně:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
5. V Android Studiu počkej na dokončení synchronizace Gradle.
6. Vyber Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Výsledné testovací APK najdeš v android/app/build/outputs/apk/debug/app-debug.apk.
8. Přenes APK do telefonu a nainstaluj ho. Android může požádat o povolení instalace z daného zdroje.

Pokud chceš APK pro veřejné šíření, vytvoř podepsanou release verzi a bezpečně si ulož svůj podpisový klíč.

Oficiální návody:
Android Studio — https://developer.android.com/build/build-for-release
Capacitor — https://capacitorjs.com/docs/getting-started/environment-setup
