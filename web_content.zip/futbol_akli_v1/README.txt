FUTBOL AKLI — PROTOTİP SÜRÜM 1.0

AÇMA:
1. ZIP dosyasını telefona indir.
2. Dosyalar uygulamasında ZIP'i çıkar.
3. index.html dosyasına dokunup Chrome ile aç.

İÇERİK:
- Mobil uyumlu tek sayfa prototip
- Ana sayfa, arama, futbolcu profilleri, kulüp ve turnuva kartları
- Karşılaştırma ekranı, taktik kartları, tarih çizelgesi, arşiv görünümü

ÖNEMLİ:
Bu bir web prototipidir; mağazaya yüklenmiş Android/iOS uygulaması değildir.
İstatistikler ve örnek profiller demo amaçlıdır. Canlı veri API'si, sunucu,
hesap sistemi, veri tabanı ve çevrimdışı uygulama paketi içermez.
