# CPLS V2 — Stage 1117

## هدف
پایدارسازی واقعی اتصال بازار و جلوگیری از درخواست‌های تکراری پس از جابه‌جایی صفحات.

## تغییرات
- Futures feed فقط یک scheduler ثابت دارد؛ `getFuturesSnapshot()` و بازشدن دوباره صفحه دیگر poll فوری و تکراری ایجاد نمی‌کنند.
- فاصله Futures روی حدود 1.5 ثانیه باقی مانده و Market + Order Book از همان چرخه کنترل‌شده تغذیه می‌شوند.
- WebSocket اسپات ابتدا از `wss://www.lbkex.net/ws/V2/` استفاده می‌کند و در تلاش بعدی به endpoint قدیمی‌تر `wss://api.lbank.info/ws/V2/` می‌رود. این تغییر برای سازگاری با مهاجرت API انجام شد؛ REST اصلی همچنان `api.lbkex.com` است.
- صفحه Futures دیگر fallback مرورگری موازی ندارد؛ منبع اصلی Futures همان Native Android است تا CORS و چند اتصال همزمان باعث `OFFLINE` کاذب نشود.
- هیچ endpoint حدسی برای Futures K-Line اضافه نشد. مستند رسمی Contract API فعلی فقط REST روی `lbkperp.lbank.com` و WebSocket روی `lbkperpws.lbank.com/ws` را اعلام می‌کند و endpoint عمومی K-Line را در بخش عمومی فعلی نشان نمی‌دهد.
- کندل Futures همچنان از نمونه‌های قیمت واقعی دریافتی از Market API ساخته می‌شود؛ داده ساختگی وارد نشده است.

## پژوهش
مستند رسمی LBank Contract API: https://www.lbank.com/en-US/docs/contract.html
مستند رسمی فعلی، Market Data و Market Order را public معرفی می‌کند و خطاهای 183/10012 را برای نرخ درخواست بالا/درخواست بیش از حد ثبت کرده است.

## گام بعدی
تا وقتی فرمت subscription رسمی Futures WebSocket به‌صورت قابل اتکا از LBank منتشر/قابل تأیید نشود، پیام subscription حدسی وارد برنامه نمی‌شود. اولویت بعدی: تست اتصال واقعی روی دستگاه و ثبت پاسخ سرور `lbkperpws.lbank.com/ws` در صورت امکان.
