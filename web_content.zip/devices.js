function renderDevicesPage(c) {
  const busy = db.devices.filter(d => d.s && !d.s.end).length;

  c.innerHTML = `${current === "home" ? `
    <h2>Game Lounge</h2>
    <p class="muted">ملخص الصالة وحالة الأجهزة والطاولات.</p>

    <div class="stats">
      <div class="stat">
        <small>إجمالي الأجهزة والطاولات</small>
        <strong>${db.devices.length}</strong>
      </div>
      <div class="stat">
        <small>المشغولة</small>
        <strong style="color:#ff637c">${busy}</strong>
      </div>
      <div class="stat">
        <small>المتاحة</small>
        <strong style="color:#38d49d">${db.devices.length - busy}</strong>
      </div>
      <div class="stat">
        <small>الجلسات المغلقة</small>
        <strong>${db.history.length}</strong>
      </div>
    </div>` : ""}

    <div class="bar">
      <div>
        <h2>${current === "home" ? "الأجهزة والطاولات" : "إدارة الأجهزة والطاولات"}</h2>
        <p class="muted">اختر نوع الجهاز لفتح قائمته.</p>
      </div>
      <button class="primary" onclick="deviceForm()">＋ إضافة جهاز أو طاولة</button>
    </div>

    ${current === "home" || deviceCategoryFilter === "الكل"
      ? categoryMenuHtml()
      : `<div class="category-view-head">
          <button onclick="deviceCategory('الكل')">← رجوع إلى أنواع الأجهزة</button>
          <h3>${deviceGroups.find(g => g.key === deviceCategoryFilter)?.title || "أجهزة أخرى"}</h3>
        </div>
        ${deviceGroupHtml(
          deviceCategoryFilter,
          deviceGroups.find(g => g.key === deviceCategoryFilter)?.title || "أجهزة أخرى"
        )}`
    }`;
}

function card(d) {
  
const s = d.s;
const paused = !!(s && !s.end && s.pausedAt);
const busy = !!(s && !s.end);
const done = !!(s && s.end);
const ord = sum(s);


  const icon = categoryOf(d) === "كمبيوتر" ? "🖥️"
    : categoryOf(d) === "بلايستيشن" ? "🎮"
    : categoryOf(d) === "بلياردو" ? "🎱"
    : categoryOf(d) === "فيشة" ? "⚽" : "🎯";

  return `<article class="card device ${busy ? "busy" : done ? "done" : ""}">
    <div class="between">
      <div>
        <h3>${icon} ${esc(d.name)}</h3>
        <small class="muted">${esc(d.type)} · ${priceText(d.rate)} للساعة</small>
      </div>
     <span class="pill ${busy ? "status-unavailable" : done ? "status-unavailable" : "status-available"}">
  ${busy ? "مشغول" : done ? "انتهت الجلسة" : "متاح"}
</span>
    </div>

    ${busy ? `
      
<div class="mini">
  <small class="muted">${paused ? "الجلسة متوقفة مؤقتاً" : "الوقت المنقضي"}</small>
  <div class="timer" id="timer${d.id}">${
    time(Math.max(0, (s.pausedAt || Date.now()) - s.start - (s.pausedTotal || 0)))
  }</div>
  <small class="muted">المدة المحددة: ${s.minutes ? s.minutes + " دقيقة" : "مفتوحة"}</small>
</div>

      <div class="actions">
        <button onclick="orders(${d.id})">🛒 الطلبات (${s.orders.length})</button>
      
${paused
  ? `<button class="good" onclick="resumeSession(${d.id})">▶ استئناف</button>`
  : `<button onclick="pauseSession(${d.id})">⏸ إيقاف مؤقت</button>`
}
<button class="bad" onclick="stop(${d.id})">إنهاء وحساب</button>

        <button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
      </div>
      <div class="sum">
        <span class="muted">مجموع الطلبات</span>
        <b class="gold">${cash(ord)}</b>
      </div>
    ` : done ? `
<div class="session-billing">
  <div class="billing-row">
    <span>أجرة الجلسة</span>
    <strong>${cash(s.game)}</strong>
  </div>
  <div class="billing-row">
    <span>مجموع الطلبات</span>
    <strong>${cash(s.orderTotal)}</strong>
  </div>
  <div class="billing-total">
    <span>المبلغ الكامل</span>
    <strong>${cash(s.total)}</strong>
  </div>
</div>
      <div class="actions">
        <button class="good" onclick="finishSession(${d.id})">إنهاء</button>
        <button onclick="showOrders(${d.id})">عرض الطلبات</button>
        <button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
      </div>
    ` : `
      <div class="mini">
        <small class="muted">سعر الساعة</small>
        <h3>${priceText(d.rate)}</h3>
      </div>
      <div class="actions">
        <button class="good" onclick="startForm(${d.id})">▶ بدء الوقت</button>
        <button onclick="editDevice(${d.id})">تعديل</button>
        <button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
      </div>
    `}
  </article>`;
}

// ========================================
// 4. النوافذ المنبثقة
// ========================================
function modal(html) {
  document.getElementById("modal").innerHTML = html;
  document.getElementById("bg").classList.add("show");
}

function closemodal() {
  document.getElementById("bg").classList.remove("show");
}

// ========================================
// 5. أسعار ساعات اللعب
// ========================================
function rateForType(type) {
  const group = categoryOf({ type });
  return Number(db.hourlyRates[group]) || 0;
}

function deviceForm() {
  modal(`<h3>إضافة جهاز أو طاولة</h3>

    <div class="field">
      <label for="dn">اسم الجهاز أو الطاولة</label>
      <input id="dn" placeholder="مثلاً: كمبيوتر 3 أو بلياردو 1">
    </div>

    <div class="field">
      <label for="dt">نوع الجهاز</label>
      <select id="dt" onchange="fillDeviceRate()">
        <option value="كمبيوتر">كمبيوتر</option>
        <option value="PS5">بلايستيشن 5</option>
        <option value="PS4">بلايستيشن 4</option>
        <option value="PS3">بلايستيشن 3</option>
        <option value="بلياردو">بلياردو</option>
        <option value="فيشة">فيشة</option>
        <option value="آخر">أخرى</option>
      </select>
    </div>

    <div class="field">
      <label for="dcount">العدد المطلوب إضافته</label>
      <input id="dcount" type="number" min="1" max="200" value="1" step="1">
      <small class="muted">مثال: اكتب 20 لإضافة عشرين جهازاً مرقّماً تلقائياً.</small>
    </div>
    <div class="field">
      <label for="dr">سعر الساعة</label>
      <input id="dr" type="number" min="0" step="any"
        placeholder="يظهر السعر تلقائياً عند تحديد النوع">
      <small class="muted">يمكنك تعديل السعر لهذا الجهاز وحده.</small>
    </div>

    <button class="primary" onclick="addDevice()">حفظ الجهاز</button>
    <button onclick="closemodal()">إلغاء</button>`);

  fillDeviceRate();
}

function fillDeviceRate() {
  const type = document.getElementById("dt")?.value;
  const rateInput = document.getElementById("dr");
  if (!rateInput) return;

  rateInput.value = rateForType(type) || "";
}

function hourlyRatesForm() {
  const rates = db.hourlyRates;

  modal(`<h3>أسعار ساعات اللعب</h3>
    <p class="muted">حدد سعر الساعة لكل نوع. ستظهر هذه الأسعار تلقائياً عند إضافة جهاز جديد.</p>

    <div class="field">
      <label for="rateComputer">🖥️ سعر ساعة الكمبيوتر</label>
      <input id="rateComputer" type="number" min="0" step="any"
        value="${Number(rates["كمبيوتر"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="ratePlaystation">🎮 سعر ساعة البلايستيشن</label>
      <input id="ratePlaystation" type="number" min="0" step="any"
        value="${Number(rates["بلايستيشن"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="rateFisha">⚽ سعر ساعة الفيشة</label>
      <input id="rateFisha" type="number" min="0" step="any"
        value="${Number(rates["فيشة"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="rateBilliards">🎱 سعر ساعة البلياردو</label>
      <input id="rateBilliards" type="number" min="0" step="any"
        value="${Number(rates["بلياردو"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="rateOther">🎯 سعر ساعة الأجهزة الأخرى</label>
      <input id="rateOther" type="number" min="0" step="any"
        value="${Number(rates["أخرى"]) || ""}" placeholder="أدخل السعر">
    </div>

    <button class="primary" onclick="saveHourlyRates()">حفظ أسعار الساعات</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveHourlyRates() {
  const fields = [
    ["كمبيوتر", "rateComputer"],
    ["بلايستيشن", "ratePlaystation"],
    ["فيشة", "rateFisha"],
    ["بلياردو", "rateBilliards"],
    ["أخرى", "rateOther"]
  ];

  const newRates = {};

  for (const [key, id] of fields) {
    const input = document.getElementById(id);
    const raw = input.value.trim();
    const value = Number(raw);

    if (raw !== "" && (!Number.isFinite(value) || value < 0)) {
      return notify("تحقق من أسعار الساعات المدخلة.");
    }

    newRates[key] = raw === "" ? 0 : value;
  }

  db.hourlyRates = newRates;

  try {
    save();
    closemodal();
    render();
    notify("تم حفظ أسعار ساعات اللعب");
  } catch (e) {
    notify("تعذّر حفظ الأسعار");
  }
}

// ========================================
// 6. إضافة الأجهزة وتعديلها وحذفها
// ========================================
function addDevice() {
  const n = document.getElementById("dn").value.trim();
  const raw = document.getElementById("dr").value;
  const r = Number(raw);
  const t = document.getElementById("dt").value;
  const count = Math.floor(Number(document.getElementById("dcount")?.value || 1));

  if (!n || raw === "" || !Number.isFinite(r) || r <= 0) {
    return notify("أدخل اسم الجهاز وسعر ساعة أكبر من صفر");
  }
  if (!Number.isInteger(count) || count < 1 || count > 200) return notify("العدد يجب أن يكون من 1 إلى 200");

  const existing = db.devices.filter(d => String(d.type) === String(t)).length;
  for (let i = 0; i < count; i++) {
    const label = count === 1 ? n : `${n} ${existing + i + 1}`;
    db.devices.push({ id: db.id++, name: label, type: t, rate: r });
  }

  save();
  closemodal();
  render();
  notify(count === 1 ? "تمت إضافة الجهاز بنجاح" : `تمت إضافة ${count} أجهزة/طاولات بنجاح`);
}

function editDevice(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  modal(`<h3>تعديل الجهاز</h3>
    <div class="field">
      <label for="dn">الاسم</label>
      <input id="dn" value="${esc(d.name)}">
    </div>
    <div class="field">
      <label for="dr">سعر الساعة</label>
      <input id="dr" type="number" min="0.01" step="any"
        value="${Number(d.rate) > 0 ? d.rate : ""}">
    </div>
    <button class="primary" onclick="saveDevice(${id})">حفظ التعديل</button>
    <button class="bad" onclick="delDevice(${id})">حذف الجهاز</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveDevice(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  const n = document.getElementById("dn").value.trim();
  const raw = document.getElementById("dr").value;
  const r = Number(raw);

  if (!n || raw === "" || !Number.isFinite(r) || r <= 0) {
    return notify("أدخل اسم الجهاز وسعر ساعة صحيحاً");
  }

  d.name = n;
  d.rate = r;

  save();
  closemodal();
  render();
  notify("تم حفظ التعديل");
}

function delDevice(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  if (d.s && !d.s.end) {
    return notify("لا يمكن حذف جهاز لديه جلسة جارية. أوقف الجلسة أولاً.");
  }

  if (!confirm(`هل تريد حذف «${d.name}»؟ ستبقى الجلسات السابقة في التقارير.`)) {
    return;
  }

  db.devices = db.devices.filter(x => x.id !== id);
  save();
  closemodal();
  render();
  notify("تم حذف الجهاز");
}

// ========================================
// 7. الجلسات والوقت
// ========================================
function startForm(id) {
  const d = db.devices.find(x => x.id === id);

  if (!d || !(Number(d.rate) > 0)) {
    return notify("أدخل سعر الساعة أولاً من تعديل الجهاز أو أسعار الساعات");
  }

  modal(`<h3>بدء جلسة</h3>
    <div class="field">
      <label for="customer">اسم الزبون (اختياري)</label>
      <input id="customer">
    </div>
    <div class="field">
      <label for="minutes">المدة بالدقائق</label>
      <input id="minutes" type="number" min="1"
        placeholder="اتركها فارغة لوقت مفتوح">
    </div>
    <p class="muted">تُحسب أجرة اللعب بحسب سعر الساعة والوقت المستهلك.</p>
    <button class="good" onclick="start(${id})">بدء الوقت</button>
    <button onclick="closemodal()">إلغاء</button>`);
}


function start(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  const minutesRaw = document.getElementById("minutes").value;
  const n = Number(minutesRaw);

  if (minutesRaw !== "" && (!Number.isFinite(n) || n <= 0)) {
    return notify("أدخل مدة صحيحة أو اترك الحقل فارغاً");
  }

  if (d.s && !d.s.end) {
    return notify("هذه الجلسة تعمل بالفعل");
  }

  d.s = {
    start: Date.now(),
    pausedAt: null,
    pausedTotal: 0,
    customer: document.getElementById("customer").value.trim(),
    minutes: minutesRaw === "" ? null : n,
    orders: [],
    end: null
  };

  save();
  closemodal();
  render();
  notify("بدأت الجلسة");
}

function pauseSession(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;

  if (!s || s.end || s.pausedAt) return;

  s.pausedAt = Date.now();

  save();
  render();
  notify("تم إيقاف الجلسة مؤقتاً");
}

function resumeSession(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;

  if (!s || s.end || !s.pausedAt) return;

  s.pausedTotal = (s.pausedTotal || 0)
    + (Date.now() - s.pausedAt);

  s.pausedAt = null;

  save();
  render();
  notify("تم استئناف الجلسة");
}

function stop(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;

  if (!s || s.end) return;

  const now = Date.now();

  // إذا كانت الجلسة متوقفة مؤقتاً، نحسب الاستراحة حتى الآن
  if (s.pausedAt) {
    s.pausedTotal = (s.pausedTotal || 0)
      + (now - s.pausedAt);
    s.pausedAt = null;
  }

  s.end = now;

  // حساب وقت اللعب الفعلي بعد استبعاد الاستراحات
  const elapsed = Math.max(
    0,
    s.end - s.start - (s.pausedTotal || 0)
  );

  s.game = Math.ceil(
    elapsed / 3600000 * Number(d.rate)
  );

  s.orderTotal = sum(s);
  s.total = s.game + s.orderTotal;

  db.history.push({
    device: d.name,
    type: d.type,
    category: categoryOf(d),
    customer: s.customer,
    game: s.game,
    orders: s.orderTotal,
    total: s.total,
    start: s.start,
    end: s.end,
    date: localDate(new Date(s.end))
  });

  save();
  render();
  notify("تم إنهاء الجلسة وحفظ الحساب");
}


function finishSession(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d || !d.s || !d.s.end) return;

  d.s = null;
  save();
  render();
  notify("انتهت الجلسة وأصبح الجهاز متاحاً");
}

function showOrders(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;
  if (!s) return;

  modal(`<h3>طلبات ${esc(d.name)}</h3>
    <div class="summary">
      ${(s.orders || []).map(o => `
        <div class="sum">
          <span>${esc(o.name)} × ${o.qty}</span>
          <b>${cash(o.price * o.qty)}</b>
        </div>
      `).join("") || "لا توجد طلبات"}
      <hr>
      <div class="sum">
        <b>مجموع الطلبات</b>
        <b class="gold">${cash(s.orderTotal ?? sum(s))}</b>
      </div>
    </div>
    <button onclick="closemodal()">إغلاق</button>`);
}

// ========================================
