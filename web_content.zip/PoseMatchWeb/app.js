const video = document.getElementById("camera");
const reference = document.getElementById("reference");
const canvas = document.getElementById("overlay");
const ctx = canvas.getContext("2d");
const statusEl = document.getElementById("status");
const hintEl = document.getElementById("hint");
const scoreEl = document.getElementById("score");
const guideEl = document.getElementById("cameraGuide");
const input = document.getElementById("referenceInput");
const opacity = document.getElementById("opacity");
const startBtn = document.getElementById("start");
const flipBtn = document.getElementById("flip");
const captureBtn = document.getElementById("capture");

let stream = null;
let detector = null;
let referencePose = null;
let livePose = null;
let facing = "environment";
let running = false;
let busy = false;
let refImageReady = false;

const KEYPOINTS = [
  "nose","left_shoulder","right_shoulder","left_elbow","right_elbow",
  "left_wrist","right_wrist","left_hip","right_hip","left_knee",
  "right_knee","left_ankle","right_ankle","left_heel","right_heel",
  "left_foot_index","right_foot_index"
];

function setCanvasSize() {
  const r = canvas.getBoundingClientRect();
  const dpr = Math.min(devicePixelRatio || 1, 2);
  canvas.width = Math.round(r.width * dpr);
  canvas.height = Math.round(r.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener("resize", setCanvasSize);

function normalizePose(pose) {
  if (!pose || !pose.keypoints) return null;
  const pts = pose.keypoints.filter(p => KEYPOINTS.includes(p.name) && (p.score ?? 1) >= .35);
  if (pts.length < 5) return null;
  const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  const minY = Math.min(...ys), maxY = Math.max(...ys);
  const w = Math.max(maxX-minX, 1), h = Math.max(maxY-minY, 1);
  const map = {};
  for (const p of pts) {
    map[p.name] = {
      x:(p.x-minX)/w, y:(p.y-minY)/h,
      score:p.score ?? 1
    };
  }
  return {points:map, minX,maxX,minY,maxY};
}

function similarity(a,b) {
  if (!a || !b) return 0;
  let sum=0, n=0;
  for (const k of KEYPOINTS) {
    if (!a.points[k] || !b.points[k]) continue;
    const dx=a.points[k].x-b.points[k].x, dy=a.points[k].y-b.points[k].y;
    const d=Math.hypot(dx,dy);
    sum += Math.max(0, 1-d/.75);
    n++;
  }
  return n ? 100*sum/n : 0;
}

function guidance(ref, live) {
  if (!ref || !live) return "Step into frame so your full body is visible.";
  const get=(name,axis)=>ref.points[name]&&live.points[name] ? live.points[name][axis]-ref.points[name][axis] : null;
  const sy=["left_shoulder","right_shoulder"].map(k=>get(k,"y")).filter(v=>v!==null);
  const sx=["left_shoulder","right_shoulder"].map(k=>get(k,"x")).filter(v=>v!==null);
  if (sy.length) {
    const v=sy.reduce((a,b)=>a+b,0)/sy.length;
    if(v>.08) return "Raise your upper body slightly";
    if(v<-.08) return "Lower your upper body slightly";
  }
  if (sx.length) {
    const v=sx.reduce((a,b)=>a+b,0)/sx.length;
    if(v>.08) return "Move slightly left";
    if(v<-.08) return "Move slightly right";
  }
  const nd=get("nose","y");
  if(nd!==null) {
    if(nd>.08) return "Lower your chin slightly";
    if(nd<-.08) return "Raise your chin slightly";
  }
  return "Fine-tune your pose";
}

function drawSkeleton(pose, color, alpha=1) {
  if (!pose) return;
  const r=canvas.getBoundingClientRect(), w=r.width, h=r.height;
  const lines=[
    ["left_shoulder","right_shoulder"],
    ["left_shoulder","left_elbow"],["left_elbow","left_wrist"],
    ["right_shoulder","right_elbow"],["right_elbow","right_wrist"],
    ["left_shoulder","left_hip"],["right_shoulder","right_hip"],
    ["left_hip","right_hip"],
    ["left_hip","left_knee"],["left_knee","left_ankle"],
    ["right_hip","right_knee"],["right_knee","right_ankle"]
  ];
  ctx.save();
  ctx.strokeStyle=color; ctx.fillStyle=color; ctx.globalAlpha=alpha;
  ctx.lineWidth=4;
  for(const [a,b] of lines){
    const p=pose.points[a], q=pose.points[b];
    if(!p||!q) continue;
    ctx.beginPath(); ctx.moveTo(p.x*w,p.y*h); ctx.lineTo(q.x*w,q.y*h); ctx.stroke();
  }
  for(const p of Object.values(pose.points)){
    ctx.beginPath(); ctx.arc(p.x*w,p.y*h,5,0,Math.PI*2); ctx.fill();
  }
  ctx.restore();
}

function drawFrameGuide(pose) {
  if (!pose) { guideEl.textContent="Camera guide: find the subject"; return; }
  const width = pose.maxX-pose.minX;
  const center=(pose.minX+pose.maxX)/2;
  if(width<.35) guideEl.textContent="Camera guide: move closer";
  else if(width>.85) guideEl.textContent="Camera guide: move back";
  else if(center<.40) guideEl.textContent="Camera guide: move camera right";
  else if(center>.60) guideEl.textContent="Camera guide: move camera left";
  else guideEl.textContent="Camera guide: framing looks good";
}

async function loadDetector() {
  if(detector) return;
  statusEl.textContent="Loading pose AI…";
  detector=await poseDetection.createDetector(
    poseDetection.SupportedModels.MoveNet,
    {modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING}
  );
  statusEl.textContent="Pose AI ready";
}

async function startCamera() {
  try {
    await loadDetector();
    if(stream) stream.getTracks().forEach(t=>t.stop());
    stream=await navigator.mediaDevices.getUserMedia({
      video:{
        facingMode:{ideal:facing},
        width:{ideal:1280},
        height:{ideal:720},
        // Best-effort autofocus request. Browser/device support varies.
        advanced:[{focusMode:"continuous"}]
      },
      audio:false
    });
    video.srcObject=stream;
    await video.play();
    running=true;
    startBtn.textContent="Stop";
    statusEl.textContent="Camera live";
    setCanvasSize();
    requestAnimationFrame(loop);
  } catch(e) {
    console.error(e);
    statusEl.textContent="Camera permission/error";
    hintEl.textContent="Use HTTPS (or localhost) and allow camera permission.";
  }
}

function stopCamera() {
  running=false;
  if(stream) stream.getTracks().forEach(t=>t.stop());
  stream=null; video.srcObject=null;
  startBtn.textContent="Start camera";
  statusEl.textContent="Camera off";
}

async function loop() {
  if(!running) return;
  if(!busy && detector && video.readyState>=2) {
    busy=true;
    try {
      const poses=await detector.estimatePoses(video,{flipHorizontal:facing==="user"});
      livePose=normalizePose(poses[0]);
      const s=referencePose&&livePose?similarity(referencePose,livePose):0;
      scoreEl.textContent=referencePose&&livePose?`${Math.round(s)}%`:"—";
      hintEl.textContent=referencePose&&livePose
        ? (s>=85?"✓ Pose matched — hold still":guidance(referencePose,livePose))
        : "Load a reference photo to compare poses.";
      drawFrameGuide(livePose);
      ctx.clearRect(0,0,canvas.clientWidth,canvas.clientHeight);
      // Live skeleton is a guide; the reference image remains the main visual overlay.
      drawSkeleton(livePose,"#00ff9d",.9);
    } catch(e) { console.warn(e); }
    busy=false;
  }
  requestAnimationFrame(loop);
}

input.addEventListener("change", async e=>{
  const file=e.target.files?.[0];
  if(!file) return;
  const url=URL.createObjectURL(file);
  reference.src=url;
  reference.style.display="block";
  reference.onload=async ()=>{
    try{
      await loadDetector();
      const poses=await detector.estimatePoses(reference,{flipHorizontal:false});
      referencePose=normalizePose(poses[0]);
      if(referencePose){
        statusEl.textContent="Reference loaded";
        hintEl.textContent="Match the reference pose.";
      } else {
        statusEl.textContent="Reference pose not found";
        hintEl.textContent="Use a clear full-body photo with one visible person.";
      }
    }catch(err){
      statusEl.textContent="Reference analysis failed";
      console.error(err);
    }
  };
});

opacity.addEventListener("input",()=>reference.style.opacity=Number(opacity.value)/100);

startBtn.addEventListener("click",()=>running?stopCamera():startCamera());

flipBtn.addEventListener("click",async()=>{
  facing=facing==="environment"?"user":"environment";
  if(running) await startCamera();
});

captureBtn.addEventListener("click",()=>{
  if(!video.videoWidth) return;
  const out=document.createElement("canvas");
  out.width=video.videoWidth; out.height=video.videoHeight;
  const c=out.getContext("2d");
  c.drawImage(video,0,0,out.width,out.height);
  const a=document.createElement("a");
  a.href=out.toDataURL("image/jpeg",.92);
  a.download=`posematch-${Date.now()}.jpg`;
  a.click();
});

setCanvasSize();
