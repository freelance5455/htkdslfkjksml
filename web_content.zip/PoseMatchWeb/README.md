# PoseMatch Camera — Web Version

A browser-based prototype for personal use.

## Features
- Phone camera preview
- Front/rear camera switching
- Reference photo overlay with opacity control
- Live pose detection in the browser
- Reference-vs-live pose similarity score
- Basic movement/chin guidance
- Basic camera framing guidance
- Photo capture
- Best-effort continuous autofocus request

## Important
Camera access normally requires a secure context: HTTPS or localhost. Opening index.html directly as a file may not allow camera access in many browsers.

This prototype uses TensorFlow.js + MoveNet in the browser. It is intentionally lightweight. For truly high-accuracy recreation, the next version should add perspective/depth calibration, segmentation, better landmark weighting, temporal smoothing, and a reference-camera calibration mode.

## Run on Windows 10
Option A: upload the folder to any HTTPS static host.

Option B: run a local server from this folder:
Python 3:
    python -m http.server 8000
Then open:
    http://localhost:8000

For phone testing, localhost on the PC is not the phone's localhost; use an HTTPS deployment or a suitable local HTTPS development setup.

The browser implementation uses TensorFlow.js/MoveNet for pose inference. See:
https://www.tensorflow.org/js
https://www.tensorflow.org/hub/tutorials/tf2_object_detection
