# Run@Rate Dashboard Android App

This Android Studio project wraps the existing self-contained Run@Rate HTML dashboard in a native Android WebView.

## Included mobile functions
- Offline operation with no server or internet connection
- Five-station Run@Rate controls and responsive phone layout
- Persistent data using WebView local storage
- XLSX and JSON export to `Downloads/RunRate`
- Android system printing / PDF output
- Dark and light modes

## Build the APK
1. Open this folder in Android Studio Ladybug or newer.
2. Allow Gradle Sync to complete. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.1.0, compile SDK 35 and minimum Android 10 (API 29).
3. Select `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Install the generated `app-debug.apk` from `app/build/outputs/apk/debug/` on the phone.

For a signed production APK, use `Build > Generate Signed App Bundle or APK` and store the signing key securely.
