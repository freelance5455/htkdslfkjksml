/* =====================================================================
   ALASH MC — ДЕРЕКТЕР ФАЙЛЫ
   Жаңа ақпарат қосу үшін тек осы файлды өзгертсеңіз жеткілікті.
   Түс атаулары: mint, sky, peach, lilac, butter, rose
   ===================================================================== */
window.CONFIG = {
  name: 'Alash MC',
  appVersion: '2.0',
  ip: 'alashmc.xyz',
  version: '1.21.11+',
  slogan: 'Өз әлеміңді құр. Өз тарихыңды жаз.',
  telegram: 'https://t.me/ALASHMS',

  // Басты беттің үлкен суреті. Мысалы: 'assets/images/spawn.jpg'
  // Бос қалса — жұмсақ блоктар көрсетіледі. Суретті қосымшаның мәзірінен де таңдауға болады.
  heroImage: '',

  // Алтын мен кейс кілтінің бағасы (спавндағы тақтадан)
  gold:   { amount: 100, price: 300 },   // 100 алтын = 300 ₸
  caseKey:{ amount: 1,   price: 700 },   // 1 кілт   = 700 ₸

  // Спавнда көрсетілген пайдалы командалар
  basicCommands: [
    ['/rtp',             'кездейсоқ жерге ұшу'],
    ['/kit claim start', 'бастапқы кит алу'],
    ['/menu',            'бас меню'],
    ['/warp',            'варптар тізімі']
  ],

  // Привилегиялар (донат тізімі). Әр дәреже алдыңғы дәрежелердің командаларын да қамтиды.
  // cmds — тек осы дәрежеде жаңадан ашылатын командалар.
  ranks: [
    { id:'nomad',  name:'NOMAD',   price:290,  color:'butter', auction:15, homes:2,  blocks:null,
      cmds:[
        ['/hat',     'қолдағы затты бас киім ретінде кию'],
        ['/craft',   'қашықтан верстак ашу'],
        ['/suicide', 'кейіпкерді жылдам өлтіру'],
        ['/kit claim nomad', 'Номад жиынтығын алу']
      ]},
    { id:'batyr',  name:'BATYR',   price:450,  color:'sky',    auction:20, homes:3,  blocks:null,
      cmds:[
        ['/anvil', 'қашықтан тес (anvil) ашу'],
        ['/ec',    'қашықтан эндер-сандық ашу'],
        ['/feed',  'аштықты толық толтыру'],
        ['/kit claim batyr', 'Батыр жиынтығын алу']
      ]},
    { id:'sultan', name:'SULTAN',  price:990,  color:'peach',  auction:25, homes:5,  blocks:null,
      cmds:[
        ['/repair', 'қолдағы затты жөндеу'],
        ['/near',   'жақын маңдағы ойыншыларды көру'],
        ['/kit claim sultan', 'Сұлтан жиынтығын алу']
      ]},
    { id:'kagan',  name:'KAGAN',   price:2220, color:'mint',   auction:30, homes:7,  blocks:null,
      cmds:[
        ['/top',  'ең жоғарғы блокқа көтерілу'],
        ['/nick', 'ойын ішіндегі атты өзгерту'],
        ['/kit claim kagan', 'Қаған жиынтығын алу']
      ]},
    { id:'han',    name:'HAN',     price:3790, color:'rose',   auction:40, homes:10, blocks:null,
      cmds:[
        ['/rename', 'қолдағы заттың атын өзгерту'],
        ['/heal',   'денсаулықты толық қалпына келтіру'],
        ['/kit claim khan', 'Хан жиынтығын алу']
      ]},
    { id:'ulyhan', name:'ULY HAN', price:5000, color:'lilac',  auction:50, homes:15, blocks:16,
      cmds:[
        ['/repair all', 'барлық заттарды жөндеу'],
        ['/fly',        'ұшуды қосу/өшіру'],
        ['/kit claim ulykhan', 'Ұлы Хан жиынтығын алу']
      ]}
  ],

  // Галерея орындары. src — файл жолы (мысалы 'assets/images/spawn.jpg'). Бос болса орынбасар шығады.
  gallery: [
    { id:'spawn', title:'Спавн',        src:'' },
    { id:'mine',  title:'Шахта',        src:'' },
    { id:'pvp',   title:'PvP арена',    src:'' },
    { id:'shop',  title:'Донат дүкені', src:'' }
  ],

  // Мүмкіндік беттеріндегі суреттер (галереяда көрінбейді)
  pageSlots: {
    seller:  { id:'seller',  title:'Скупщик',  src:'' },
    automine:{ id:'automine',title:'Автошахта',src:'' }
  },

  // Нақты варптар болса осында қосыңыз: { name:'Спавн', cmd:'/warp spawn', desc:'Сипаттама' }
  warps: [],

  // Нақты ивенттер болса осында қосыңыз: { title:'Атауы', when:'Күні мен уақыты', desc:'Сипаттама' }
  events: [],

  // Басты бет пен «Мүмкіндіктер» беті. color — түс атауы
  features: [
    { id:'kits',     icon:'👑', title:'Донат киттер',     desc:'6 привилегия мен командалар', color:'butter', wide:true },
    { id:'commands', icon:'⌨️', title:'Командалар',       desc:'Іздеу және таңдаулылар',      color:'sky' },
    { id:'shop',     icon:'🛒', title:'Донат дүкені',     desc:'Алтын, кілт, калькулятор',    color:'mint' },
    { id:'compare',  icon:'📊', title:'Салыстыру',        desc:'Дәрежелер кестесі',           color:'lilac' },
    { id:'auction',  icon:'⚖️', title:'Аукцион',          desc:'Сату және сатып алу',         color:'peach' },
    { id:'seller',   icon:'💰', title:'Скупщик',          desc:'Заттарды сату',               color:'butter' },
    { id:'automine', icon:'⛏️', title:'Автошахта',        desc:'Автоматты қазу',              color:'sky' },
    { id:'warps',    icon:'🌀', title:'Варптар',          desc:'Орындарға ұшу',               color:'mint' },
    { id:'pvp',      icon:'⚔️', title:'PvP арена',        desc:'Шайқас аймағы',               color:'rose' },
    { id:'events',   icon:'🎉', title:'Ивенттер',         desc:'Іс-шаралар',                  color:'peach' },
    { id:'connect',  icon:'🔌', title:'Қосылу нұсқаулығы',desc:'Java және Bedrock',           color:'lilac', wide:true }
  ],

  // Жиі қойылатын сұрақтар (тек нақты белгілі ақпарат)
  faq: [
    ['Қандай нұсқамен кіремін?',
     'Сервер 1.21.11 және одан жоғары нұсқаларды қолдайды. Java Edition мен Bedrock Edition ойыншылары кіре алады.'],
    ['Сервер қашан ашық?',
     'Сервер 24/7 жұмыс істейді.'],
    ['Донатты қалай сатып аламын?',
     'Привилегия, алтын және кейс кілтін Telegram арқылы сатып аласыз: t.me/ALASHMS. Қосымшаның ішінде төлем жасалмайды.'],
    ['Бастапқы затты қалай аламын?',
     'Серверге кіргеннен кейін /kit claim start командасын жазыңыз. Кездейсоқ жерге ұшу үшін /rtp қолданыңыз.'],
    ['Онлайн ойыншылар саны неге көрінбейді?',
     'Нақты санды көрсету үшін серверлік API қажет. Ол қосылмағандықтан, жалған сан көрсетілмейді.']
  ]
};
