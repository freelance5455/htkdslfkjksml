/* =====================================================================
   ALASH MC — ҚОСЫМША ЛОГИКАСЫ
   1. Утилиталар   2. Сақтау (localStorage, IndexedDB)   3. Суреттер
   4. Қабаттар (back батырмасы)   5. Басты экрандар   6. Мүмкіндік беттері
   7. Оқиғалар   8. Іске қосу
   ===================================================================== */
'use strict';
(() => {
const C = window.CONFIG;

/* ---------- 1. УТИЛИТАЛАР ---------- */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
const fmt = n => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ₸';
const tgLink = () => esc(C.telegram);
const isHttp = /^https?:$/.test(location.protocol);

const PATHS = {
  home:'<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  image:'<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.01"/>',
  copy:'<rect x="9" y="9" width="12" height="12" rx="3"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  menu:'<path d="M4 7h16M4 12h16M4 17h10"/>',
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  left:'<path d="M15 5l-7 7 7 7"/>',
  right:'<path d="M9 5l7 7-7 7"/>',
  down:'<path d="M6 9l6 6 6-6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  swap:'<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  heart:'<path d="M12 20s-7-4.4-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.6-9 9-9 9z"/>',
  send:'<path d="M21 3L10 14M21 3l-7 18-4-7-7-4z"/>',
  share:'<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
  download:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  camera:'<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'
};
const ico = (name, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${PATHS[name]}</svg>`;
const col = c => `--c:var(--${c});--cd:var(--${c}-d);--ct:var(--${c}-t)`;

let toastTimer;
function toast(msg, err = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.toggle('err', err);
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on'), 2400);
}
const haptic = () => { try { navigator.vibrate && navigator.vibrate(25); } catch (_) {} };

async function copy(text, okMsg) {
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; }
  catch (_) {
    try {
      const a = document.createElement('textarea');
      a.value = text; a.setAttribute('readonly', '');
      a.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
      document.body.appendChild(a); a.select();
      ok = document.execCommand('copy'); a.remove();
    } catch (__) {}
  }
  if (ok) { toast(okMsg || 'Көшірілді!'); haptic(); }
  else toast('Көшіру мүмкін болмады. Мәтінді қолмен белгілеп көшіріңіз.', true);
}
const copyIP = () => copy(C.ip, `IP көшірілді: ${C.ip}`);

/* ---------- 2. САҚТАУ ---------- */
const LS = {
  get(k, d) { try { const v = localStorage.getItem('alash.' + k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem('alash.' + k, JSON.stringify(v)); } catch (_) {} }
};
const SS = {
  get(k, d) { try { return sessionStorage.getItem('alash.' + k) || d; } catch (_) { return d; } },
  set(k, v) { try { sessionStorage.setItem('alash.' + k, v); } catch (_) {} }
};

// IndexedDB — қолданушы қосқан суреттер осы құрылғыда сақталады
const DB = (() => {
  let p;
  const open = () => p || (p = new Promise((res, rej) => {
    if (!('indexedDB' in window)) return rej(new Error('IndexedDB жоқ'));
    const rq = indexedDB.open('alash-mc', 1);
    rq.onupgradeneeded = () => rq.result.createObjectStore('img');
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  }));
  const run = async (mode, fn) => {
    const db = await open();
    return new Promise((res, rej) => {
      const t = db.transaction('img', mode);
      fn(t.objectStore('img'));
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  };
  return {
    async all() {
      try {
        const db = await open();
        return await new Promise((res, rej) => {
          const out = {};
          const rq = db.transaction('img').objectStore('img').openCursor();
          rq.onsuccess = () => { const c = rq.result; if (c) { out[c.key] = c.value; c.continue(); } else res(out); };
          rq.onerror = () => rej(rq.error);
        });
      } catch (_) { return {}; }
    },
    put: (k, blob) => run('readwrite', s => s.put(blob, k)),
    del: k => run('readwrite', s => s.delete(k))
  };
})();

/* ---------- 3. СУРЕТТЕР ---------- */
const IMG = {
  urls: {},
  async init() {
    const all = await DB.all();
    Object.keys(all).forEach(k => { this.urls[k] = URL.createObjectURL(all[k]); });
  },
  get(id, fallback) { return this.urls[id] || fallback || ''; },
  async set(id, blob) {
    let saved = true;
    try { await DB.put(id, blob); } catch (_) { saved = false; }
    if (this.urls[id]) URL.revokeObjectURL(this.urls[id]);
    this.urls[id] = URL.createObjectURL(blob);
    return saved;
  },
  async remove(id) {
    try { await DB.del(id); } catch (_) {}
    if (this.urls[id]) { URL.revokeObjectURL(this.urls[id]); delete this.urls[id]; }
  }
};

function pickFile() {
  return new Promise(res => {
    const inp = $('#fileInput');
    inp.value = '';
    inp.onchange = () => res(inp.files && inp.files[0] ? inp.files[0] : null);
    inp.oncancel = () => res(null);
    inp.click();
  });
}
function fileToBlob(file, max = 1600) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const im = new Image();
    im.onload = () => {
      const k = Math.min(1, max / Math.max(im.width, im.height));
      const c = document.createElement('canvas');
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob(b => b ? res(b) : rej(new Error('blob')), 'image/jpeg', 0.88);
    };
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    im.src = url;
  });
}
async function pickAndStore(id) {
  const f = await pickFile();
  if (!f) return false;
  try {
    toast('Сурет өңделуде...');
    const blob = await fileToBlob(f);
    const saved = await IMG.set(id, blob);
    toast(saved ? 'Сурет қосылды!' : 'Сурет тек осы сессияда сақталады', !saved);
    return true;
  } catch (_) {
    toast('Суретті ашу мүмкін болмады', true);
    return false;
  }
}

const customSlots = () => LS.get('customSlots', []);
const galleryList = () => [...C.gallery, ...customSlots()];
const allSlots = () => [...galleryList(), ...Object.values(C.pageSlots || {})];
const slotById = id => allSlots().find(s => s.id === id);

function phHTML(s) {
  return `<div class="shot-ph" data-slot="${esc(s.id)}">
    <div style="font-size:36px">📷</div><b>${esc(s.title)}</b>
    <small>Скриншотты осында қосыңыз</small>
    <button class="btn small" data-act="add" data-id="${esc(s.id)}">${ico('plus')} СУРЕТ ҚОСУ</button></div>`;
}
function shotHTML(s, extra = '') {
  const src = IMG.get(s.id, s.src);
  const canDelete = s.custom || IMG.urls[s.id];
  const body = src
    ? `<img src="${esc(src)}" alt="${esc(s.title)}" data-slot="${esc(s.id)}" loading="lazy">
       <div class="shot-cap">${esc(s.title)}</div>
       <div class="shot-tools">
         <button class="clay-icon" data-act="replace" data-id="${esc(s.id)}" aria-label="Суретті ауыстыру">${ico('swap')}</button>
         ${canDelete ? `<button class="clay-icon" data-act="remove" data-id="${esc(s.id)}" aria-label="Суретті өшіру">${ico('trash')}</button>` : ''}
       </div>`
    : phHTML(s);
  return `<div class="shot reveal ${extra}" ${src ? `data-shot="${esc(s.id)}"` : ''}>${body}</div>`;
}
// Сурет жолы қате болса — орынбасар көрсету
document.addEventListener('error', e => {
  const t = e.target;
  if (t && t.tagName === 'IMG' && t.dataset.slot) {
    const s = slotById(t.dataset.slot);
    const box = t.closest('.shot');
    if (s && box) { box.removeAttribute('data-shot'); box.innerHTML = phHTML(s); }
  }
}, true);

/* ---------- 4. ҚАБАТТАР (артқа батырмасы) ---------- */
const state = { tab: 'home', page: null, sheet: false, lb: false };
const pushed = { detail: false, sheet: false, lb: false };
let ignorePop = 0;
const hpush = n => { try { history.pushState({ l: n }, ''); pushed[n] = true; } catch (_) { pushed[n] = false; } };
const hpop = n => { if (pushed[n]) { pushed[n] = false; ignorePop++; history.back(); } };
window.addEventListener('popstate', () => {
  if (ignorePop > 0) { ignorePop--; return; }
  if (state.lb) closeLb(true);
  else if (state.sheet) closeSheet(true);
  else if (state.page) closeDetail(true);
});

/* ---------- 5. ТАҚЫРЫП, НАВИГАЦИЯ ---------- */
function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  $('#themeBtn').innerHTML = ico(t === 'dark' ? 'sun' : 'moon');
  const m = $('meta[name="theme-color"]');
  if (m) m.content = t === 'dark' ? '#27243d' : '#f1edfb';
}
const toggleTheme = () => {
  const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  LS.set('theme', t); applyTheme(t); haptic();
};

const TABS = [
  { id:'home',     label:'Басты бет',     icon:'home'  },
  { id:'features', label:'Мүмкіндіктер',  icon:'grid'  },
  { id:'gallery',  label:'Галерея',       icon:'image' },
  { id:'about',    label:'Сервер туралы', icon:'info'  }
];
function renderNav() {
  $('#nav').innerHTML = TABS.map(t => `<button data-go="${t.id}" aria-label="${t.label}">${ico(t.icon)}<span>${t.label}</span></button>`).join('');
}

// Көрінгенде жұмсақ пайда болу анимациясы
const io = 'IntersectionObserver' in window
  ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.06 })
  : null;
function reveal(root, restart = false) {
  $$('.reveal', root).forEach((el, i) => {
    if (restart) el.classList.remove('in');
    el.style.transitionDelay = Math.min(i, 7) * 45 + 'ms';
    if (io) io.observe(el); else el.classList.add('in');
  });
}

function go(tab) {
  if (!TABS.some(t => t.id === tab)) tab = 'home';
  if (state.page) closeDetail(false);
  state.tab = tab;
  $$('.view').forEach(v => v.classList.toggle('active', v.id === 'v-' + tab));
  $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.go === tab));
  const v = $('#v-' + tab);
  v.scrollTop = 0;
  reveal(v, true);
  SS.set('tab', tab);
}

/* ---------- 6. БАСТЫ ЭКРАНДАР ---------- */
const favs = () => LS.get('favs', []);

function cmdRow(cmd, desc, color, tag) {
  const on = favs().includes(cmd);
  return `<div class="cmd" role="button" tabindex="0" data-copy="${esc(cmd)}" style="--ct:var(--${color}-t)">
    <code>${esc(cmd)}</code>
    <span>${esc(desc)}${tag ? ` · <b>${esc(tag)}</b>` : ''}</span>
    <button class="fav ${on ? 'on' : ''}" data-fav="${esc(cmd)}" aria-label="Таңдаулыға қосу">${ico('heart')}</button>
  </div>`;
}
function featCard(f) {
  return `<button class="fcard reveal ${f.wide ? 'wide' : ''}" style="${col(f.color)}" data-open="${f.id}">
    <div class="ic">${f.icon}</div><div><b>${esc(f.title)}</b><small>${esc(f.desc)}</small></div></button>`;
}

function renderHome() {
  const hero = IMG.get('hero', C.heroImage);
  const art = hero
    ? `<div class="hero-bg" style="background-image:url('${esc(hero)}')"></div>`
    : `<div class="hero-art"><i class="blk a"></i><i class="blk b"></i><i class="blk c"></i><i class="blk d"></i><i class="blk e"></i></div>`;
  const featured = ['kits', 'commands', 'shop', 'connect'].map(id => C.features.find(f => f.id === id)).filter(Boolean);
  $('#v-home').innerHTML = `
    <div class="hero">
      ${art}
      <div><span class="chip"><i class="dot"></i>24/7 ашық</span></div>
      <h1>ALASH <b>MC</b></h1>
      <p class="slogan">${esc(C.slogan)}</p>
      <div class="ipbox"><div><small>СЕРВЕР IP</small><code>${esc(C.ip)}</code></div></div>
      <div class="row">
        <button class="btn" data-act="copyip">${ico('copy')} IP КӨШІРУ</button>
        <button class="btn ghost" data-go="about">СЕРВЕР ТУРАЛЫ</button>
      </div>
      <div class="badges"><span class="chip">☕ Java Edition</span><span class="chip">🧱 Bedrock Edition</span><span class="chip">v${esc(C.version)}</span></div>
    </div>

    <div class="stats">
      <div class="card stat reveal"><b>24/7</b><span>Үнемі ашық</span></div>
      <div class="card stat reveal"><b>2 нұсқа</b><span>Java + Bedrock</span></div>
      <div class="card stat reveal"><b>${esc(C.version)}</b><span>Ойын нұсқасы</span></div>
    </div>

    <h2 class="h2">Қалай бастаймын?</h2>
    <p class="sub">Үш қарапайым қадам.</p>
    <div class="steps">
      <div class="card step reveal" style="${col('mint')}"><div class="n">1</div><div><b>IP көшіріңіз</b><p>${esc(C.ip)} — жоғарыдағы батырманы басыңыз.</p></div></div>
      <div class="card step reveal" style="${col('sky')}"><div class="n">2</div><div><b>Серверге қосылыңыз</b><p>Minecraft ${esc(C.version)} нұсқасымен, Java немесе Bedrock арқылы. <a href="#" data-open="connect" style="text-decoration:underline">Нұсқаулық</a></p></div></div>
      <div class="card step reveal" style="${col('peach')}"><div class="n">3</div><div><b>Кит алыңыз</b><p>Ойынға кіргеннен кейін /kit claim start жазыңыз.</p></div></div>
    </div>

    <h2 class="h2">Бастау командалары</h2>
    <p class="sub">Басып көшіріп алыңыз. ♥ белгісімен таңдаулыға қосуға болады.</p>
    <div class="cmd-list">${C.basicCommands.map(c => cmdRow(c[0], c[1], 'mint', '')).join('')}</div>

    <h2 class="h2">Жылдам өту</h2>
    <p class="sub">Қажетті бөлімді таңдаңыз.</p>
    <div class="grid">${featured.map(featCard).join('')}</div>`;
  reveal($('#v-home'));
}

function renderFeatures() {
  $('#v-features').innerHTML = `
    <h2 class="h2" style="margin-top:6px">Мүмкіндіктер</h2>
    <p class="sub">Alash MC серверінің барлық бөлімдері бір жерде.</p>
    <div class="grid">${C.features.map(featCard).join('')}</div>`;
  reveal($('#v-features'));
}

function renderGallery() {
  $('#v-gallery').innerHTML = `
    <h2 class="h2" style="margin-top:6px">Галерея</h2>
    <p class="sub">Суретті басып толық экранда ашыңыз. Өз скриншоттарыңызды қосуға болады — олар тек осы құрылғыда сақталады.</p>
    ${galleryList().map(s => shotHTML(s)).join('')}
    <button class="btn lilac block" data-act="addslot">${ico('plus')} ЖАҢА СУРЕТ ҚОСУ</button>`;
  reveal($('#v-gallery'));
}

function renderAbout() {
  $('#v-about').innerHTML = `
    <h2 class="h2" style="margin-top:6px">Сервер туралы</h2>
    <p class="sub">Қазақстандық Minecraft сервері. Java және Bedrock ойыншылары бір әлемде ойнайды.</p>
    <div class="info">
      <div class="it reveal"><span>Атауы</span><b>${esc(C.name)}</b></div>
      <div class="it reveal"><span>IP</span><b>${esc(C.ip)}</b></div>
      <div class="it reveal"><span>Нұсқа</span><b>${esc(C.version)}</b></div>
      <div class="it reveal"><span>Платформа</span><b>Java + Bedrock</b></div>
      <div class="it reveal"><span>Жұмыс уақыты</span><b>24/7</b></div>
      <div class="it reveal"><span>Telegram</span><b>t.me/ALASHMS</b></div>
    </div>
    <div class="row wrap">
      <button class="btn" data-act="copyip">${ico('copy')} IP КӨШІРУ</button>
      <a class="btn sky" href="${tgLink()}" target="_blank" rel="noopener">${ico('send')} TELEGRAM</a>
    </div>
    <h2 class="h2">Жиі қойылатын сұрақтар</h2>
    ${C.faq.map(q => `<div class="faq reveal"><button data-faq><span>${esc(q[0])}</span>${ico('down', 'chev')}</button><div class="faq-b"><p>${esc(q[1])}</p></div></div>`).join('')}
    <div class="note mt"><b>Ескерту.</b> Онлайн ойыншылар санын көрсету, ойыншы статистикасы және аукционмен жұмыс істеу үшін серверлік API қажет. Ол әзірге қосылмаған, сондықтан мұндай деректер жалған көрсетілмейді.</div>`;
  reveal($('#v-about'));
}

const renderAll = () => { renderHome(); renderFeatures(); renderGallery(); renderAbout(); };

/* ---------- 7. МҮМКІНДІК БЕТТЕРІ ---------- */
const st = { cum: LS.get('cum', false), q: '', f: 'all', ed: 'java', calc: { rank: '', gold: 0, keys: 0 } };

// --- Донат киттер
function rankHTML(r, i, open) {
  const list = st.cum
    ? C.ranks.slice(0, i + 1).flatMap(x => x.cmds.map(c => ({ c: c[0], d: c[1], tag: x.name, col: x.color })))
    : r.cmds.map(c => ({ c: c[0], d: c[1], tag: '', col: r.color }));
  const perks = [[r.auction, 'АУКЦИОН СЛОТЫ'], [r.homes, 'ҮЙ НҮКТЕСІ']];
  if (r.blocks) perks.push([r.blocks, 'ПРИВАТ БЛОК']);
  return `<div class="rank reveal ${open ? 'open' : ''}" data-id="${r.id}" style="${col(r.color)}">
    <button class="rank-h" data-rank>
      <span class="rank-badge">${esc(r.name)}</span>
      <span class="meta">${r.auction} аукцион слоты<br>${r.homes} үй нүктесі${r.blocks ? ` · ${r.blocks} приват блок` : ''}</span>
      <span class="price">${fmt(r.price)}</span>${ico('down', 'chev')}
    </button>
    <div class="rank-b"><div><div class="rank-in">
      <div class="perks" style="grid-template-columns:repeat(${perks.length},1fr)">
        ${perks.map(p => `<div class="perk"><b>${p[0]}</b><span>${p[1]}</span></div>`).join('')}
      </div>
      <h4>Қолжетімді командалар</h4>
      <p class="inherit">${st.cum ? 'Осы дәреже мен алдыңғы дәрежелердің барлық командалары.' : 'Алдыңғы дәрежелердің командалары да қосылады.'}</p>
      <div class="cmd-list">${list.map(x => cmdRow(x.c, x.d, x.col, x.tag)).join('')}</div>
      <a class="btn block mt" href="${tgLink()}" target="_blank" rel="noopener">САТЫП АЛУ · ${fmt(r.price)}</a>
    </div></div></div></div>`;
}
const ranksHTML = openIds => C.ranks.map((r, i) => rankHTML(r, i, openIds.includes(r.id))).join('');

// --- Командалар
function allCmds() {
  return [
    ...C.basicCommands.map(c => ({ c: c[0], d: c[1], tag: 'Бастау', fid: 'start', col: 'mint' })),
    ...C.ranks.flatMap(r => r.cmds.map(c => ({ c: c[0], d: c[1], tag: r.name, fid: r.id, col: r.color })))
  ];
}
function cmdListHTML() {
  const q = st.q.trim().toLowerCase(), fv = favs();
  const rows = allCmds().filter(x =>
    (st.f === 'all' || (st.f === 'fav' && fv.includes(x.c)) || st.f === x.fid) &&
    (!q || (x.c + ' ' + x.d + ' ' + x.tag).toLowerCase().includes(q)));
  if (rows.length) return rows.map(x => cmdRow(x.c, x.d, x.col, x.tag)).join('');
  return `<div class="empty clay-in">${st.f === 'fav' && !q ? 'Таңдаулы командалар әзірге жоқ. ♥ белгісін басып қосыңыз.' : 'Ештеңе табылмады.'}</div>`;
}
function filterPills() {
  const mk = (id, label, c) => `<button data-f="${id}" class="${st.f === id ? 'on' : ''}" style="${col(c)}">${label}</button>`;
  return mk('all', 'Барлығы', 'mint') + mk('fav', '♥ Таңдаулы', 'rose') + mk('start', 'Бастау', 'sky') + C.ranks.map(r => mk(r.id, r.name, r.color)).join('');
}

// --- Калькулятор
function calcCalc() {
  const r = C.ranks.find(x => x.id === st.calc.rank);
  const gold = st.calc.gold / C.gold.amount * C.gold.price;
  const keys = st.calc.keys / C.caseKey.amount * C.caseKey.price;
  const total = (r ? r.price : 0) + gold + keys;
  const parts = [];
  if (r) parts.push(`${r.name} привилегиясы`);
  if (st.calc.gold) parts.push(`${st.calc.gold} алтын`);
  if (st.calc.keys) parts.push(`${st.calc.keys} кейс кілті`);
  const nick = (LS.get('nick', '') || '').trim();
  const text = `Сәлем! Alash MC серверінен сатып алғым келеді.\nНик: ${nick || '—'}\nТапсырыс: ${parts.join(', ') || '—'}\nЖиыны: ${fmt(total)}`;
  return { r, total, text };
}
function calcUpdate(root) {
  const c = calcCalc();
  $('#goldVal', root).textContent = st.calc.gold + ' алтын';
  $('#keyVal', root).textContent = st.calc.keys + ' кілт';
  $('#calcTotal', root).textContent = fmt(c.total);
  $$('[data-crank]', root).forEach(b => b.classList.toggle('on', b.dataset.crank === st.calc.rank));
}

// --- Қосылу
function connectSteps() {
  const java = [
    ['Minecraft Java Edition ашыңыз', `Ойын нұсқасы ${C.version} болуы керек.`],
    ['Көп ойыншылы ойынға өтіңіз', 'Multiplayer (Көп ойыншылы ойын) → Add Server (Сервер қосу).'],
    ['IP жазыңыз', `Server Address жолына ${C.ip} енгізіп, Done басыңыз.`],
    ['Серверге кіріңіз', 'Alash MC серверін таңдап, Join Server басыңыз. Кіргеннен кейін /kit claim start жазыңыз.']
  ];
  const bed = [
    ['Minecraft Bedrock Edition ашыңыз', `Телефон, планшет немесе консоль. Нұсқа ${C.version} болуы керек.`],
    ['Серверлер бөліміне өтіңіз', 'Play (Ойнау) → Servers (Серверлер) → Add Server (Сервер қосу).'],
    ['Деректерді толтырыңыз', `Server Name: Alash MC. Server Address: ${C.ip}.`],
    ['Порт', 'Порт жолын өзгертпей қалдырыңыз. Қосыла алмасаңыз, порт туралы Telegram-да сұраңыз.'],
    ['Серверге кіріңіз', 'Серверді таңдап қосылыңыз. Кіргеннен кейін /kit claim start жазыңыз.']
  ];
  const cols = ['mint', 'sky', 'peach', 'lilac', 'butter'];
  return (st.ed === 'java' ? java : bed).map((s, i) =>
    `<div class="card step reveal in" style="${col(cols[i % cols.length])}"><div class="n">${i + 1}</div><div><b>${esc(s[0])}</b><p>${esc(s[1])}</p></div></div>`).join('');
}

const infoPage = (text, slotId) => () => {
  const s = slotById(slotId);
  return `<p class="sub">${text}</p>
    <div class="note">Нақты ақпарат пен скриншоттар кейін қосылады. Суретті төмендегі орынға қазірдің өзінде қосуға болады.</div>
    <div class="mt2">${s ? shotHTML(s) : ''}</div>`;
};

const PAGES = {
  kits: {
    title: 'Донат киттер',
    html: () => `<p class="sub">Привилегияны басып, командаларын көріңіз. Киттің ішіндегі заттар тізімі әзірге көрсетілмеген.</p>
      <div class="seg clay"><button data-cum="0" class="${st.cum ? '' : 'on'}">Осы дәреже</button><button data-cum="1" class="${st.cum ? 'on' : ''}">Алдыңғылармен</button></div>
      <div class="mt" id="rankList">${ranksHTML([C.ranks[0].id])}</div>`,
    click(e, D) {
      const b = e.target.closest('[data-cum]');
      if (!b) return;
      st.cum = b.dataset.cum === '1'; LS.set('cum', st.cum);
      $$('.seg button', D).forEach(x => x.classList.toggle('on', x === b));
      const open = $$('.rank.open', D).map(x => x.dataset.id);
      $('#rankList', D).innerHTML = ranksHTML(open);
      $$('.reveal', D).forEach(x => x.classList.add('in'));
    }
  },

  commands: {
    title: 'Командалар',
    html: () => `<p class="sub">Командаға басып көшіріп алыңыз. Қажеттілерін ♥ белгісімен сақтаңыз.</p>
      <div class="search">${ico('search')}<input id="cmdQ" type="search" placeholder="Команданы іздеу..." autocomplete="off" value="${esc(st.q)}"></div>
      <div class="pills" id="cmdPills">${filterPills()}</div>
      <div class="cmd-list" id="cmdList">${cmdListHTML()}</div>`,
    click(e, D) {
      const b = e.target.closest('[data-f]');
      if (!b) return;
      st.f = b.dataset.f;
      $$('#cmdPills button', D).forEach(x => x.classList.toggle('on', x === b));
      $('#cmdList', D).innerHTML = cmdListHTML();
    },
    input(e, D) {
      if (e.target.id !== 'cmdQ') return;
      st.q = e.target.value;
      $('#cmdList', D).innerHTML = cmdListHTML();
    }
  },

  shop: {
    title: 'Донат дүкені',
    html: () => {
      const nick = esc(LS.get('nick', ''));
      return `<p class="sub">Сатып алу Telegram арқылы жүзеге асады. Қосымшаның ішінде төлем жасалмайды.</p>
      <div class="grid">
        <div class="card center reveal in" style="${col('butter')}"><div style="font-size:38px">🪙</div><b style="display:block;margin:8px 0 4px">${C.gold.amount} алтын</b><span style="font-size:20px;font-weight:900;color:var(--ct)">${fmt(C.gold.price)}</span></div>
        <div class="card center reveal in" style="${col('lilac')}"><div style="font-size:38px">🗝️</div><b style="display:block;margin:8px 0 4px">${C.caseKey.amount} кейс кілті</b><span style="font-size:20px;font-weight:900;color:var(--ct)">${fmt(C.caseKey.price)}</span></div>
      </div>
      <h2 class="h2">Калькулятор</h2>
      <div class="card calc">
        <div class="calc-row"><label>Привилегия</label><div class="pills" id="calcRanks" style="margin:0 -4px -6px">
          <button data-crank="" style="${col('mint')}">Жоқ</button>
          ${C.ranks.map(r => `<button data-crank="${r.id}" style="${col(r.color)}">${esc(r.name)}</button>`).join('')}
        </div></div>
        <div class="calc-row"><label>Алтын <b id="goldVal"></b></label><input type="range" id="goldR" min="0" max="3000" step="${C.gold.amount}" value="${st.calc.gold}"></div>
        <div class="calc-row"><label>Кейс кілті <b id="keyVal"></b></label><input type="range" id="keyR" min="0" max="10" step="1" value="${st.calc.keys}"></div>
        <div class="calc-row"><label>Ойын ішіндегі ник</label><div class="search plain" style="margin:0"><input id="nickIn" type="text" maxlength="24" placeholder="Мысалы: Erb4khyt" autocomplete="off" value="${nick}"></div></div>
        <div class="calc-total"><span>ЖИЫНЫ</span><b id="calcTotal">0 ₸</b></div>
        <div class="row mt"><button class="btn lilac" data-calc="copy">${ico('copy')} МӘТІНДІ КӨШІРУ</button><a class="btn sky" href="${tgLink()}" target="_blank" rel="noopener">${ico('send')} TELEGRAM</a></div>
      </div>
      <div class="note mt">Тапсырыс мәтінін көшіріп, Telegram-да жіберіңіз. Төлемді әкімші растайды.</div>
      <div class="mt2">${shotHTML(slotById('shop'))}</div>`;
    },
    after(D) { calcUpdate(D); },
    click(e, D) {
      const b = e.target.closest('[data-crank]');
      if (b) { st.calc.rank = b.dataset.crank; calcUpdate(D); return; }
      if (e.target.closest('[data-calc="copy"]')) copy(calcCalc().text, 'Тапсырыс мәтіні көшірілді!');
    },
    input(e, D) {
      if (e.target.id === 'goldR') st.calc.gold = +e.target.value;
      else if (e.target.id === 'keyR') st.calc.keys = +e.target.value;
      else if (e.target.id === 'nickIn') LS.set('nick', e.target.value);
      calcUpdate(D);
    }
  },

  compare: {
    title: 'Дәрежелерді салыстыру',
    html: () => `<p class="sub">Әр привилегияның негізгі артықшылықтары.</p>
      <div class="table">
        <div class="trow head"><span style="text-align:left">ДӘРЕЖЕ</span><span>АУКЦИОН</span><span>ҮЙ</span><span>ПРИВАТ</span></div>
        ${C.ranks.map(r => `<div class="trow reveal in" style="${col(r.color)}"><span class="nm">${esc(r.name)}</span><span>${r.auction}</span><span>${r.homes}</span><span>${r.blocks || '—'}</span></div>`).join('')}
      </div>
      <div class="note mt2">Приват блок саны тек ULY HAN дәрежесінде көрсетілген. Қалған дәрежелерде бұл мүмкіндік туралы ақпарат жоқ.</div>`
  },

  auction: {
    title: 'Аукцион',
    html: () => {
      const max = Math.max(...C.ranks.map(r => r.auction));
      return `<p class="sub">Ойыншылар заттарын бір-біріне сатып, сатып ала алады. Привилегия жоғары болған сайын аукционда көбірек слот беріледі.</p>
      <div class="card"><div class="bars">
        ${C.ranks.map(r => `<div class="bar-row" style="${col(r.color)}"><span>${esc(r.name)}</span><div class="bar-track"><div class="bar-fill" data-w="${Math.round(r.auction / max * 100)}"></div></div><b>${r.auction}</b></div>`).join('')}
      </div></div>
      <div class="note mt2">Аукцион ойын ішінде жұмыс істейді. Қосымшада нақты лоттар мен бағалар көрсетілмейді, өйткені ол үшін серверлік интеграция қажет.</div>`;
    },
    after(D) { requestAnimationFrame(() => requestAnimationFrame(() => $$('.bar-fill', D).forEach(b => { b.style.width = b.dataset.w + '%'; }))); }
  },

  seller:   { title: 'Скупщик',   html: infoPage('Ойын ішіндегі заттарды скупщикке сатуға болады.', 'seller') },
  automine: { title: 'Автошахта', html: infoPage('Автошахта туралы сипаттама мен ерекшеліктер осында болады.', 'automine') },
  pvp:      { title: 'PvP арена', html: infoPage('Шайқас атмосферасы бар PvP аймағы.', 'pvp') },

  warps: {
    title: 'Варптар',
    html: () => `<p class="sub">Варптар тізімін ойын ішінде ашыңыз.</p>
      <div class="cmd-list"><div class="cmd" role="button" tabindex="0" data-copy="/warp" style="--ct:var(--sky-t)"><code>/warp</code><span>варптар тізімі</span></div>
      <div class="cmd" role="button" tabindex="0" data-copy="/rtp" style="--ct:var(--mint-t)"><code>/rtp</code><span>кездейсоқ жерге ұшу</span></div></div>
      ${C.warps.length
        ? `<div class="grid mt2">${C.warps.map(w => `<div class="card reveal in"><b style="display:block;margin-bottom:6px">🌀 ${esc(w.name)}</b><p class="sub" style="margin:0 0 10px">${esc(w.desc || '')}</p>${w.cmd ? `<div class="cmd" role="button" tabindex="0" data-copy="${esc(w.cmd)}" style="--ct:var(--lilac-t)"><code>${esc(w.cmd)}</code></div>` : ''}</div>`).join('')}</div>`
        : `<div class="note mt2">Нақты варп атаулары кейін осы жерге карточкалармен қосылады.</div>`}`
  },

  events: {
    title: 'Ивенттер',
    html: () => C.events.length
      ? `<div class="cmd-list">${C.events.map(ev => `<div class="card reveal in"><b style="display:block;font-size:16px">🎉 ${esc(ev.title)}</b><div class="chip mt">${esc(ev.when || '')}</div><p class="sub" style="margin:12px 0 0">${esc(ev.desc || '')}</p></div>`).join('')}</div>`
      : `<p class="sub">Ивенттер кестесі әзірге жарияланбаған.</p>
         <div class="note">Жаңалықтар мен ивент уақыты Telegram арнасында жарияланады.</div>
         <a class="btn sky block mt2" href="${tgLink()}" target="_blank" rel="noopener">${ico('send')} TELEGRAM АРНАСЫ</a>`
  },

  connect: {
    title: 'Қосылу нұсқаулығы',
    html: () => `<p class="sub">Өзіңіздің ойын нұсқаңызды таңдаңыз.</p>
      <div class="seg clay"><button data-ed="java" class="${st.ed === 'java' ? 'on' : ''}">☕ Java</button><button data-ed="bedrock" class="${st.ed === 'bedrock' ? 'on' : ''}">🧱 Bedrock</button></div>
      <div class="steps mt" id="connSteps">${connectSteps()}</div>
      <button class="btn block mt2" data-act="copyip">${ico('copy')} IP КӨШІРУ: ${esc(C.ip)}</button>`,
    click(e, D) {
      const b = e.target.closest('[data-ed]');
      if (!b) return;
      st.ed = b.dataset.ed;
      $$('.seg button', D).forEach(x => x.classList.toggle('on', x === b));
      $('#connSteps', D).innerHTML = connectSteps();
    }
  }
};

function openPage(id, keepScroll = false) {
  const p = PAGES[id];
  if (!p) return;
  const D = $('#detail');
  const top = D.scrollTop;
  D.innerHTML = `<div class="dhead"><button class="clay-icon" data-act="back" aria-label="Артқа">${ico('left')}</button><h3>${esc(p.title)}</h3></div><div class="body">${p.html()}</div>`;
  D.onclick = p.click ? e => p.click(e, D) : null;
  D.oninput = p.input ? e => p.input(e, D) : null;
  if (p.after) p.after(D);
  reveal(D);
  D.scrollTop = keepScroll ? top : 0;
  if (!state.page) { D.classList.add('open'); hpush('detail'); }
  state.page = id;
}
function closeDetail(fromPop) {
  if (!state.page) return;
  $('#detail').classList.remove('open');
  state.page = null;
  if (fromPop) pushed.detail = false; else hpop('detail');
}
const refreshAfterImageChange = () => {
  renderGallery(); renderHome();
  if (state.page) openPage(state.page, true);
};

/* ---------- ЛАЙТБОКС ---------- */
let lbList = [], lbIdx = 0;
function showLb() {
  const s = lbList[lbIdx];
  if (!s) return;
  $('#lbImg').src = IMG.get(s.id, s.src);
  $('#lbImg').alt = s.title;
  $('#lbCap').textContent = `${s.title}${lbList.length > 1 ? ` · ${lbIdx + 1}/${lbList.length}` : ''}`;
  $('#lbPrev').style.display = $('#lbNext').style.display = lbList.length > 1 ? '' : 'none';
}
function openLb(id) {
  lbList = allSlots().filter(s => IMG.get(s.id, s.src));
  lbIdx = Math.max(0, lbList.findIndex(s => s.id === id));
  if (!lbList.length) return;
  showLb();
  $('#lightbox').classList.add('on');
  if (!state.lb) { state.lb = true; hpush('lb'); }
}
function closeLb(fromPop) {
  if (!state.lb) return;
  $('#lightbox').classList.remove('on');
  state.lb = false;
  if (fromPop) pushed.lb = false; else hpop('lb');
}
const stepLb = d => { if (lbList.length < 2) return; lbIdx = (lbIdx + d + lbList.length) % lbList.length; showLb(); };

/* ---------- МӘЗІР (төменнен шығатын парақ) ---------- */
let deferredInstall = null;
function openSheet(html) {
  $('#sheetCard').innerHTML = html;
  $('#sheet').classList.add('on');
  if (!state.sheet) { state.sheet = true; hpush('sheet'); }
}
function closeSheet(fromPop) {
  if (!state.sheet) return;
  $('#sheet').classList.remove('on');
  state.sheet = false;
  if (fromPop) pushed.sheet = false; else hpop('sheet');
}
function openMenu() {
  const hasHero = !!IMG.urls.hero;
  openSheet(`
    <h3>Мәзір</h3><p class="sub">Alash MC · қосымша v${esc(C.appVersion)}</p>
    <div class="sheet-steps">
      <a class="menu-item" href="${tgLink()}" target="_blank" rel="noopener">${ico('send')}<span>Telegram арнасы</span></a>
      <button class="menu-item" data-act="share">${ico('share')}<span>Достарыңмен бөлісу</span></button>
      <button class="menu-item" data-act="install">${ico('download')}<span>Қосымшаны орнату</span></button>
      <button class="menu-item" data-act="theme">${ico('moon')}<span>Ашық / қараңғы тақырып</span></button>
      <button class="menu-item" data-act="heroset">${ico('camera')}<span>Басты бет суретін таңдау</span></button>
      ${hasHero ? `<button class="menu-item" data-act="heroreset">${ico('trash')}<span>Басты бет суретін қайтару</span></button>` : ''}
    </div>
    <button class="btn ghost block" data-act="closesheet">ЖАБУ</button>`);
}
async function share() {
  const data = { title: 'Alash MC', text: `Alash MC — Minecraft сервері. IP: ${C.ip} (${C.version}), Java және Bedrock.` };
  if (isHttp) data.url = location.href;
  if (navigator.share) { try { await navigator.share(data); } catch (_) {} }
  else copy(data.text + (data.url ? ' ' + data.url : ''), 'Мәтін көшірілді. Енді жібере аласыз!');
}
async function installApp() {
  if (deferredInstall) {
    deferredInstall.prompt();
    try { await deferredInstall.userChoice; } catch (_) {}
    deferredInstall = null;
    return;
  }
  openSheet(`
    <h3>Қосымшаны орнату</h3>
    <p class="sub">Alash MC-ті басты экранға қосып, қосымша сияқты ашуға болады.</p>
    <div class="sheet-steps">
      <div class="card step" style="${col('mint')}"><div class="n">1</div><div><b>Chrome мәзірін ашыңыз</b><p>Браузердің оң жақ жоғарғы бұрышындағы ⋮ белгісі.</p></div></div>
      <div class="card step" style="${col('sky')}"><div class="n">2</div><div><b>«Басты экранға қосу» таңдаңыз</b><p>Немесе «Қосымшаны орнату». Safari-де: Бөлісу → «На экран Домой».</p></div></div>
    </div>
    ${isHttp ? '' : '<div class="note">Орнату тек сайт https арқылы ашылғанда жұмыс істейді. Файл ретінде ашылса, бұл мүмкіндік қолжетімсіз.</div>'}
    <button class="btn ghost block mt" data-act="closesheet">ЖАБУ</button>`);
}

/* ---------- 8. ОҚИҒАЛАР ---------- */
function toggleFav(cmd) {
  let f = favs();
  const on = !f.includes(cmd);
  f = on ? [...f, cmd] : f.filter(x => x !== cmd);
  LS.set('favs', f);
  $$('[data-fav]').forEach(b => { if (b.dataset.fav === cmd) b.classList.toggle('on', on); });
  haptic();
  toast(on ? 'Таңдаулыға қосылды ♥' : 'Таңдаулыдан алынды');
  if (state.page === 'commands' && st.f === 'fav') $('#cmdList').innerHTML = cmdListHTML();
}

async function act(name, d) {
  switch (name) {
    case 'copyip': return copyIP();
    case 'back': return closeDetail(false);
    case 'menu': return openMenu();
    case 'closesheet': return closeSheet(false);
    case 'theme': return toggleTheme();
    case 'share': return share();
    case 'install': closeSheet(false); return void setTimeout(installApp, 380);
    case 'add':
    case 'replace':
      if (await pickAndStore(d.id)) refreshAfterImageChange();
      return;
    case 'remove': {
      if (!confirm('Суретті өшіру керек пе?')) return;
      const s = slotById(d.id);
      await IMG.remove(d.id);
      if (s && s.custom) LS.set('customSlots', customSlots().filter(x => x.id !== d.id));
      toast('Сурет өшірілді');
      return refreshAfterImageChange();
    }
    case 'addslot': {
      const id = 'c' + Date.now();
      const n = customSlots().length + 1;
      if (await pickAndStore(id)) {
        LS.set('customSlots', [...customSlots(), { id, title: `Сурет ${n}`, src: '', custom: true }]);
        refreshAfterImageChange();
      } else await IMG.remove(id);
      return;
    }
    case 'heroset':
      closeSheet(false);
      if (await pickAndStore('hero')) { renderHome(); go('home'); }
      return;
    case 'heroreset':
      closeSheet(false);
      await IMG.remove('hero'); renderHome(); toast('Бастапқы көрініс қайтарылды');
      return;
  }
}

document.addEventListener('click', e => {
  const t = e.target.closest('[data-fav],[data-act],[data-go],[data-open],[data-rank],[data-faq],[data-shot],[data-copy]');
  if (!t) return;
  const d = t.dataset;
  if (t.tagName === 'A' && t.getAttribute('href') === '#') e.preventDefault();
  if ('fav' in d) return toggleFav(d.fav);
  if ('act' in d) return act(d.act, d);
  if ('go' in d) return go(d.go);
  if ('open' in d) return openPage(d.open);
  if ('rank' in d) return t.closest('.rank').classList.toggle('open');
  if ('faq' in d) return t.closest('.faq').classList.toggle('open');
  if ('shot' in d) return openLb(d.shot);
  if ('copy' in d) return copy(d.copy, `Команда көшірілді: ${d.copy}`);
});
document.addEventListener('keydown', e => {
  if (state.lb) {
    if (e.key === 'Escape') closeLb(false);
    else if (e.key === 'ArrowLeft') stepLb(-1);
    else if (e.key === 'ArrowRight') stepLb(1);
    return;
  }
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.cmd[data-copy]')) {
    e.preventDefault(); copy(e.target.dataset.copy, `Команда көшірілді: ${e.target.dataset.copy}`);
  }
});

let sx = 0;
$('#lbImg').addEventListener('touchstart', e => { sx = e.changedTouches[0].clientX; }, { passive: true });
$('#lbImg').addEventListener('touchend', e => {
  const dx = e.changedTouches[0].clientX - sx;
  if (Math.abs(dx) > 50) stepLb(dx < 0 ? 1 : -1);
}, { passive: true });
$('#lbClose').onclick = () => closeLb(false);
$('#lbPrev').onclick = () => stepLb(-1);
$('#lbNext').onclick = () => stepLb(1);
$('#lightbox').addEventListener('click', e => { if (e.target.id === 'lightbox') closeLb(false); });
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') closeSheet(false); });
$('#themeBtn').onclick = toggleTheme;
$('#menuBtn').onclick = openMenu;

window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; });
window.addEventListener('appinstalled', () => { deferredInstall = null; toast('Қосымша орнатылды!'); });

/* ---------- 9. ІСКЕ ҚОСУ ---------- */
async function init() {
  applyTheme(LS.get('theme', 'light'));
  $('#menuBtn').innerHTML = ico('menu');
  $('#lbClose').innerHTML = ico('close');
  $('#lbPrev').innerHTML = ico('left');
  $('#lbNext').innerHTML = ico('right');
  try { await IMG.init(); } catch (_) {}
  renderNav();
  renderAll();
  go(SS.get('tab', 'home'));
  if ('serviceWorker' in navigator && isHttp) navigator.serviceWorker.register('sw.js').catch(() => {});
}

const wait = ms => new Promise(r => setTimeout(r, ms));
Promise.all([init().catch(err => console.error(err)), wait(1150)]).then(() => $('#loader').classList.add('hide'));
})();
