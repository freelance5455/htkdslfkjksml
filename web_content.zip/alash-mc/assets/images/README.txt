Сервер скриншоттарын осы буманың ішіне салыңыз (spawn.jpg, mine.jpg, pvp.jpg, shop.jpg ...).
Содан кейін config.js файлында тиісті орынның src жолына жазыңыз, мысалы:
  { id:'spawn', title:'Спавн', src:'assets/images/spawn.jpg' }
