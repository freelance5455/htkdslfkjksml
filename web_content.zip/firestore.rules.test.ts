import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const rulesContent = fs.readFileSync('./firestore.rules', 'utf8');

interface AuthContext {
  uid: string;
  emailVerified: boolean;
}

function isValidId(id: string): boolean {
  return typeof id === 'string' && id.length >= 1 && id.length <= 128 && /^[a-zA-Z0-9_-]+$/.test(id);
}

function evaluateDirtyPayload(
  collection: string,
  docId: string,
  operation: 'create' | 'update' | 'list' | 'get',
  auth: AuthContext | null,
  payload: Record<string, unknown>,
  existingDoc: Record<string, unknown> | null,
  parentProfileExists = true,
  serverTime = '2026-11-13T00:00:00Z'
): 'ALLOWED' | 'PERMISSION_DENIED' {
  if (!auth) return 'PERMISSION_DENIED';
  if (operation !== 'list' && !isValidId(docId)) return 'PERMISSION_DENIED';

  if (operation === 'create' || operation === 'update') {
    if (!auth.emailVerified) return 'PERMISSION_DENIED';
  }

  if (collection === 'users') {
    if (operation === 'list') return 'PERMISSION_DENIED';
    if (auth.uid !== docId) return 'PERMISSION_DENIED';
    if (payload.uid !== auth.uid) return 'PERMISSION_DENIED';
  }

  if (collection === 'memories') {
    if (operation === 'list') {
      if (!existingDoc || existingDoc.ownerId !== auth.uid) return 'PERMISSION_DENIED';
      return 'ALLOWED';
    }
    const allowedKeys = ['ownerId', 'title', 'content', 'category', 'userConsented', 'createdAt', 'updatedAt'];
    const keys = Object.keys(payload);
    if (!allowedKeys.every((k) => keys.includes(k)) || !keys.every((k) => allowedKeys.includes(k))) {
      return 'PERMISSION_DENIED';
    }
    if (payload.ownerId !== auth.uid) return 'PERMISSION_DENIED';
    if (payload.userConsented !== true) return 'PERMISSION_DENIED';
    if (typeof payload.title !== 'string' || payload.title.length < 1 || payload.title.length > 150) {
      return 'PERMISSION_DENIED';
    }
    if (typeof payload.content !== 'string' || payload.content.length < 1 || payload.content.length > 2000) {
      return 'PERMISSION_DENIED';
    }
    if (operation === 'create') {
      if (!parentProfileExists) return 'PERMISSION_DENIED';
      if (payload.createdAt !== serverTime || payload.updatedAt !== serverTime) return 'PERMISSION_DENIED';
    }
    if (operation === 'update') {
      if (!existingDoc || existingDoc.ownerId !== auth.uid) return 'PERMISSION_DENIED';
      if (payload.ownerId !== existingDoc.ownerId || payload.createdAt !== existingDoc.createdAt) {
        return 'PERMISSION_DENIED';
      }
      if (payload.updatedAt !== serverTime) return 'PERMISSION_DENIED';
    }
    return 'ALLOWED';
  }

  if (collection === 'tasks') {
    const allowedKeys = ['ownerId', 'title', 'category', 'priority', 'dueDate', 'completed', 'createdAt', 'updatedAt'];
    const keys = Object.keys(payload);
    if (!allowedKeys.every((k) => keys.includes(k)) || !keys.every((k) => allowedKeys.includes(k))) {
      return 'PERMISSION_DENIED';
    }
    if (payload.ownerId !== auth.uid) return 'PERMISSION_DENIED';
    if (typeof payload.title !== 'string' || payload.title.length < 1 || payload.title.length > 200) {
      return 'PERMISSION_DENIED';
    }
    if (operation === 'create' && !parentProfileExists) return 'PERMISSION_DENIED';
    return 'ALLOWED';
  }

  if (collection === 'conversations') {
    if (operation === 'update') return 'PERMISSION_DENIED';
    if (operation === 'list') {
      if (!existingDoc || existingDoc.ownerId !== auth.uid) return 'PERMISSION_DENIED';
      return 'ALLOWED';
    }
    const allowedKeys = ['ownerId', 'sessionId', 'role', 'content', 'module', 'language', 'createdAt'];
    const keys = Object.keys(payload);
    if (!allowedKeys.every((k) => keys.includes(k)) || !keys.every((k) => allowedKeys.includes(k))) {
      return 'PERMISSION_DENIED';
    }
    if (payload.ownerId !== auth.uid) return 'PERMISSION_DENIED';
    if (typeof payload.content !== 'string' || payload.content.length < 1 || payload.content.length > 20000) {
      return 'PERMISSION_DENIED';
    }
    if (payload.createdAt !== serverTime || !parentProfileExists) return 'PERMISSION_DENIED';
    return 'ALLOWED';
  }

  return 'PERMISSION_DENIED';
}

test('Firestore rules file contains all 8 pillars and mandatory collection match blocks', () => {
  assert.ok(rulesContent.includes("rules_version = '2';"));
  assert.ok(rulesContent.includes('match /{document=**} {\n      allow read, write: if false;\n    }'));
  assert.ok(rulesContent.includes('match /users/{userId}'));
  assert.ok(rulesContent.includes('match /conversations/{messageId}'));
  assert.ok(rulesContent.includes('match /memories/{memoryId}'));
  assert.ok(rulesContent.includes('match /tasks/{taskId}'));
  assert.ok(rulesContent.includes('match /study_progress/{progressId}'));
});

test('Dirty Dozen #1: Identity Spoofing on Profile returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'users',
    'user_B',
    'create',
    { uid: 'user_A', emailVerified: true },
    { uid: 'user_B', displayName: 'Spoofer' },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #2: Unverified Email Write returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'memories',
    'mem_1',
    'create',
    { uid: 'user_A', emailVerified: false },
    {
      ownerId: 'user_A',
      title: 'Goal',
      content: 'Pass CUET',
      category: 'Study Goal',
      userConsented: true,
      createdAt: '2026-11-13T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #3: Shadow Field Injection on Create returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'memories',
    'mem_1',
    'create',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      title: 'Goal',
      content: 'Pass CUET',
      category: 'Study Goal',
      userConsented: true,
      isAdmin: true,
      createdAt: '2026-11-13T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #4: Update-Gap Type Poisoning returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'tasks',
    'task_1',
    'update',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      title: 99999,
      category: 'Study',
      priority: 'High',
      dueDate: '2026-11-14',
      completed: false,
      createdAt: '2026-11-13T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    { ownerId: 'user_A', createdAt: '2026-11-13T00:00:00Z' }
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #5: Immutable Field Tampering returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'memories',
    'mem_1',
    'update',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      title: 'Updated',
      content: 'Fact',
      category: 'Personal',
      userConsented: true,
      createdAt: '2020-01-01T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    { ownerId: 'user_A', createdAt: '2026-11-13T00:00:00Z' }
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #6: Client Timestamp Forgery returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'conversations',
    'msg_1',
    'create',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      sessionId: 'sess_1',
      role: 'user',
      content: 'Hello',
      module: 'chat',
      language: 'English',
      createdAt: '1999-01-01T00:00:00Z',
    },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #7: Consent Bypass on Memory returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'memories',
    'mem_2',
    'create',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      title: 'Secret',
      content: 'Unconsented data',
      category: 'Personal',
      userConsented: false,
      createdAt: '2026-11-13T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #8: ID Poisoning Attack returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'tasks',
    'invalid$id!with*special*chars',
    'create',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      title: 'Task',
      category: 'Daily',
      priority: 'Low',
      dueDate: 'Today',
      completed: false,
      createdAt: '2026-11-13T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #9: Denial-of-Wallet Oversized String returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'conversations',
    'msg_2',
    'create',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      sessionId: 'sess_1',
      role: 'user',
      content: 'x'.repeat(25000),
      module: 'chat',
      language: 'English',
      createdAt: '2026-11-13T00:00:00Z',
    },
    null
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #10: Cross-Tenant List Scraping returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'memories',
    'mem_any',
    'list',
    { uid: 'user_A', emailVerified: true },
    {},
    { ownerId: 'user_B' }
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #11: Orphaned Sub-Entity Creation returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'tasks',
    'task_1',
    'create',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      title: 'Study Hiragana',
      category: 'Japanese',
      priority: 'High',
      dueDate: '2026-11-15',
      completed: false,
      createdAt: '2026-11-13T00:00:00Z',
      updatedAt: '2026-11-13T00:00:00Z',
    },
    null,
    false
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('Dirty Dozen #12: Unauthorized Action Keys on Conversation Update returns PERMISSION_DENIED', () => {
  const res = evaluateDirtyPayload(
    'conversations',
    'msg_1',
    'update',
    { uid: 'user_A', emailVerified: true },
    {
      ownerId: 'user_A',
      sessionId: 'sess_1',
      role: 'assistant',
      content: 'Tampered content',
      module: 'chat',
      language: 'English',
      createdAt: '2026-11-13T00:00:00Z',
    },
    { ownerId: 'user_A' }
  );
  assert.equal(res, 'PERMISSION_DENIED');
});

test('UserProfile rules allow all 6 Voice Personalities including Japanese Teacher', () => {
  for (const voice of [
    'Natural Male',
    'Natural Female',
    'Anime Hero',
    'Anime Girl',
    'Japanese Teacher',
    'My Voice',
  ]) {
    assert.ok(rulesContent.includes(`'${voice}'`), `Missing voice ${voice} in firestore.rules`);
  }
});

