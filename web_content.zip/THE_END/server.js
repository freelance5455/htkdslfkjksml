// THE END multiplayer relay server
// Install: npm install
// Run: npm start
// Host this server publicly for internet multiplayer, or on your Wi-Fi for LAN play.
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: process.env.PORT || 8080 });
const clients = new Map();
let nextId = 1;
function broadcast(data, except) {
  const msg = JSON.stringify(data);
  for (const ws of wss.clients) if (ws !== except && ws.readyState === WebSocket.OPEN) ws.send(msg);
}
wss.on('connection', ws => {
  const id = String(nextId++);
  clients.set(ws, { id, name: 'Ranger', x: 3.5, y: 3.5, angle: 0, hp: 100 });
  ws.send(JSON.stringify({ type: 'welcome', id }));
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    const p = clients.get(ws); if (!p) return;
    if (msg.type === 'join') p.name = String(msg.name || 'Ranger').slice(0,20);
    if (msg.type === 'update') {
      for (const k of ['x','y','angle','hp']) if (Number.isFinite(msg[k])) p[k] = msg[k];
    }
    if (msg.type === 'chat') broadcast({ type:'chat', id, name:p.name, text:String(msg.text||'').slice(0,180) });
  });
  ws.on('close', () => { clients.delete(ws); broadcast({ type:'left', id }); });
});
setInterval(() => {
  const players = [...clients.values()];
  broadcast({ type:'state', players });
}, 100);
console.log('THE END multiplayer server listening on port ' + (process.env.PORT || 8080));
