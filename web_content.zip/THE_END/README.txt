THE END — COSMIC SURVIVAL
==========================

CONTENTS
- index.html: playable browser game (2.5D ray-cast 3D style).
- server.js: simple WebSocket multiplayer relay server.
- package.json: server dependency and start command.

PLAY OFFLINE (Android or PC)
1. Extract the ZIP.
2. Open index.html in Chrome, Firefox, or another modern browser.
3. Tap PLAY OFFLINE. The campaign runs locally and does not need internet.
   If your Android file manager cannot open HTML directly, use a browser's
   Open file option or an HTML viewer app.

CONTROLS
Desktop: WASD / arrow keys move, mouse movement turns (click canvas first),
click or Space fires, Q changes weapon.
Mobile: on-screen arrows move, FIRE shoots, SWAP changes weapon.

WEAPONS
Plasma Rifle, Galaxy Blaster, Void Cannon, Nova Beam.

ENEMIES AND BOSSES
Defeat shadow monsters to collect cosmic energy. Every fourth wave summons
a Cosmic Final Boss: The Void Emperor, Nebula Devourer, or The Last Star.
Bosses have much more health and reward extra energy.

ONLINE MULTIPLAYER — IMPORTANT
The HTML client has a WebSocket connection option and this ZIP includes a
starter relay server. It is not a hosted public server, and online multiplayer
will not work until you deploy/run the server.

On a computer/VPS:
  npm install
  npm start
The server listens on port 8080 (or the PORT environment variable).
Open port 8080 / configure your host to allow WebSocket connections.
In the game choose ONLINE MULTIPLAYER and enter:
  ws://YOUR_SERVER_IP:8080
For a public HTTPS-hosted website, use a secure WebSocket address:
  wss://your-domain.example

For local Wi-Fi testing, run the server on a computer and enter:
  ws://COMPUTER_LAN_IP:8080

This is a starter multiplayer relay, not a complete synchronized combat
backend: it currently relays player presence/state and chat. Shared enemies,
damage, matchmaking, accounts, anti-cheat, and persistent progression would
need further server-side development. The offline campaign is fully playable
without a server.

CAMPAIGN LENGTH AND CUTSCENES
-----------------------------
The story campaign is structured as 8 chapters with 8 unique Cosmic Final
Bosses. It is designed for an estimated playtime of about 2 hours; actual
length varies with player skill and time spent fighting. Cinematic story cards
play at the opening, before every boss, after every chapter, and at the ending.
Use the CONTINUE button to resume gameplay after each scene.

GAME STORY
The stars are going dark. A living rift called The End is consuming entire
systems, turning their guardians into monsters. You are the last Cosmic
Ranger. Fight through the broken sectors, harvest energy from the creatures,
and face the ancient entities behind the collapse. Destroy the final boss
and decide whether the universe gets another dawn.
