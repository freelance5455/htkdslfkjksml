# প্রশ্নমেকার প্রো (Question Maker Pro)

Offline question-paper app: Bangla / Arabic (RTL) / English, board & madrasah question bank, MCQ sets ক–ঘ with shuffled answer keys, CQ & short questions, auto generator, Word/PDF export, drafts, dark mode.

## Run in a browser / install as PWA
Serve the `www/` folder over HTTPS (e.g. GitHub Pages, Netlify) and use "Add to Home screen".

## Get the APK (easiest: GitHub Actions)
1. Create a GitHub repo and push this whole folder.
2. Open the **Actions** tab → *Build Android APK* → Run workflow.
3. Download `question-maker-apk` → `app-debug.apk` and install it on your phone
   (allow "Install unknown apps").

## Get the APK (locally)
Requires Node 20+, JDK 17, Android SDK.
```
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```
Or `npx cap open android` and use Android Studio → Build → Build APK(s).

## Adding your own questions
Use **＋ নতুন প্রশ্ন**, **📋 বাল্ক যোগ** (paste many MCQs; mark the correct option with `*`), or import a JSON backup (**⬇ এক্সপোর্ট → JSON ইমপোর্ট**).
The built-in bank is only a small sample; verify board-frequency labels against your own sources.
