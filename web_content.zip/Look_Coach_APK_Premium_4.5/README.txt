LOOK COACH 4.5
Version inspirée des meilleures fonctions d'apps de coaching lookmaxing/jawline, avec identité originale.

Nouveautés :
- séance guidée avec minuterie
- suivi photo local
- indicateur de score personnel
- métriques de progression
- plan quotidien et routines existants
- navigation mobile basse

Sécurité : les exercices sont bien-être/posture, sans promesse de modification osseuse. Éviter toute pratique douloureuse ou dangereuse.
