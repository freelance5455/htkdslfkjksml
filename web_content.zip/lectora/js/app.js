// ========== LECTORA - Aplicación de seguimiento de lectura ==========

const STORAGE_KEY = 'lectora_data_v1';

// Quotes inspiradoras
const QUOTES = [
  "Un libro es un sueño que tienes en tus manos. — Neil Gaiman",
  "La lectura es al espíritu lo que el ejercicio al cuerpo. — Joseph Addison",
  "Hay libros que se devoran, otros que se saborean. — Francis Bacon",
  "Leer es viajar sin moverse del sofá. — Anónimo",
  "Los libros son amigos que nunca decepcionan. — Anónimo",
  "Una habitación sin libros es como un cuerpo sin alma. — Cicerón",
  "La lectura hace al hombre completo. — Francis Bacon",
  "Cada libro es una nueva aventura esperando ser descubierta.",
  "Lee para crecer, lee para soñar, lee para vivir más vidas.",
  "El que lee mucho y anda mucho, ve mucho y sabe mucho. — Cervantes"
];

// Default cover SVG as data URI
const DEFAULT_COVER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='200' viewBox='0 0 140 200'%3E%3Crect fill='%23e8d5d5' width='140' height='200' rx='8'/%3E%3Crect fill='%23d4c1ec' x='15' y='20' width='110' height='160' rx='4'/%3E%3Ctext x='70' y='105' text-anchor='middle' font-size='40' fill='%238b6f6f'%3E📖%3C/text%3E%3C/svg%3E";

// Achievements definitions
const ACHIEVEMENTS = [
  { id: 'first_book', title: 'Primer libro terminado', icon: '🎉', desc: 'Completaste tu primer libro' },
  { id: 'pages_100', title: '100 páginas', icon: '📄', desc: 'Leíste 100 páginas en total' },
  { id: 'books_5', title: 'Cinco libros', icon: '📚', desc: 'Terminaste 5 libros' },
  { id: 'streak_7', title: '7 días de lectura', icon: '🔥', desc: 'Registraste lectura 7 días distintos' },
  { id: 'pages_500', title: '500 páginas', icon: '🏆', desc: 'Alcanzaste 500 páginas leídas' },
  { id: 'books_10', title: 'Diez libros', icon: '👑', desc: 'Completaste 10 libros' }
];

// App State
let state = {
  books: [],
  sessions: [],
  diary: [],
  goals: {
    monthlyBooks: 2,
    dailyPages: 20,
    challenges: []
  },
  achievements: {},
  settings: {
    userName: 'Lector/a'
  }
};

// ========== Persistence ==========
function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      state = { ...state, ...data };
    } else {
      seedSampleData();
    }
  } catch (e) {
    console.error('Error loading data', e);
    seedSampleData();
  }
}

function saveData() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Error saving', e);
    showToast('Error al guardar datos');
  }
}

function seedSampleData() {
  const now = new Date();
  const monthAgo = new Date(now);
  monthAgo.setDate(monthAgo.getDate() - 25);

  state.books = [
    {
      id: genId(),
      title: 'Cien años de soledad',
      author: 'Gabriel García Márquez',
      cover: '',
      genre: 'Realismo mágico',
      totalPages: 471,
      pagesRead: 180,
      startDate: monthAgo.toISOString().slice(0, 10),
      endDate: '',
      rating: 0,
      status: 'leyendo',
      comments: 'Una obra maestra del realismo mágico.'
    },
    {
      id: genId(),
      title: 'El principito',
      author: 'Antoine de Saint-Exupéry',
      cover: '',
      genre: 'Fábula',
      totalPages: 96,
      pagesRead: 96,
      startDate: '2025-09-01',
      endDate: '2025-09-05',
      rating: 5,
      status: 'terminado',
      comments: 'Hermoso e inolvidable.'
    },
    {
      id: genId(),
      title: '1984',
      author: 'George Orwell',
      cover: '',
      genre: 'Distopía',
      totalPages: 328,
      pagesRead: 0,
      startDate: '',
      endDate: '',
      rating: 0,
      status: 'pendiente',
      comments: ''
    }
  ];

  state.sessions = [
    {
      id: genId(),
      bookId: state.books[0].id,
      date: new Date().toISOString().slice(0, 10),
      startPage: 160,
      endPage: 180,
      pagesRead: 20,
      minutes: 45,
      notes: 'Capítulo interesante sobre Macondo.',
      favoriteQuote: ''
    }
  ];

  state.diary = [
    {
      id: genId(),
      bookId: state.books[1].id,
      date: '2025-09-05',
      content: 'Una reflexión profunda sobre la amistad y la inocencia. "Lo esencial es invisible a los ojos."',
      type: 'reseña'
    }
  ];

  saveData();
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ========== Helpers ==========
function $(sel, ctx = document) { return ctx.querySelector(sel); }
function $$(sel, ctx = document) { return [...ctx.querySelectorAll(sel)]; }

function formatDate(d) {
  if (!d) return '—';
  const date = typeof d === 'string' ? new Date(d + 'T00:00:00') : d;
  return date.toLocaleDateString('es', { day: 'numeric', month: 'short', year: 'numeric' });
}

function getProgress(book) {
  if (!book.totalPages) return 0;
  return Math.min(100, Math.round((book.pagesRead / book.totalPages) * 100));
}

function getBookById(id) {
  return state.books.find(b => b.id === id);
}

function showToast(msg, duration = 2500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

function starsHTML(rating, interactive = false, size = '') {
  let html = `<div class="stars ${size}" ${interactive ? 'data-interactive="true"' : ''}>`;
  for (let i = 1; i <= 5; i++) {
    html += `<span class="${i <= rating ? '' : 'empty'}" data-val="${i}">★</span>`;
  }
  html += '</div>';
  return html;
}

// ========== Navigation ==========
function showSection(name) {
  $$('.section').forEach(s => s.classList.remove('active'));
  $$('.nav-btn').forEach(b => b.classList.remove('active'));
  const sec = $(`#section-${name}`);
  if (sec) sec.classList.add('active');
  $$(`.nav-btn[data-section="${name}"]`).forEach(b => b.classList.add('active'));
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Refresh section content
  switch (name) {
    case 'inicio': renderHome(); break;
    case 'biblioteca': renderLibrary(); break;
    case 'registrar': renderRegisterForm(); break;
    case 'metas': renderGoals(); break;
    case 'estadisticas': renderStats(); break;
    case 'diario': renderDiary(); break;
    case 'calendario': renderCalendar(); break;
    case 'config': renderConfig(); break;
  }
}

// ========== Home ==========
function renderHome() {
  const hour = new Date().getHours();
  let saludo = 'Buenas noches';
  if (hour < 12) saludo = 'Buenos días';
  else if (hour < 20) saludo = 'Buenas tardes';

  $('#greeting').textContent = `${saludo}, ${state.settings.userName} 👋`;

  // Quote
  const q = QUOTES[Math.floor(Math.random() * QUOTES.length)];
  $('#home-quote').textContent = q;

  // Stats
  const terminados = state.books.filter(b => b.status === 'terminado').length;
  const pendientes = state.books.filter(b => b.status === 'pendiente').length;
  const leyendo = state.books.filter(b => b.status === 'leyendo');

  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();
  const pagesThisMonth = state.sessions
    .filter(s => {
      const d = new Date(s.date + 'T00:00:00');
      return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
    })
    .reduce((sum, s) => sum + (s.pagesRead || 0), 0);

  $('#stat-terminados').textContent = terminados;
  $('#stat-pendientes').textContent = pendientes;
  $('#stat-paginas-mes').textContent = pagesThisMonth;
  $('#stat-leyendo').textContent = leyendo.length;

  // Monthly goal progress
  const goalBooks = state.goals.monthlyBooks || 2;
  const booksThisMonth = state.books.filter(b => {
    if (b.status !== 'terminado' || !b.endDate) return false;
    const d = new Date(b.endDate + 'T00:00:00');
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  }).length;
  const goalPct = Math.min(100, Math.round((booksThisMonth / goalBooks) * 100));
  $('#goal-progress-fill').style.width = goalPct + '%';
  $('#goal-progress-text').textContent = `${booksThisMonth} / ${goalBooks} libros este mes (${goalPct}%)`;

  // Currently reading
  const container = $('#currently-reading');
  if (leyendo.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="icon">📖</div><p>No tienes libros en lectura actualmente.<br>¡Agrega uno desde Mi biblioteca!</p></div>`;
  } else {
    container.innerHTML = leyendo.map(b => bookCardHTML(b)).join('');
  }
}

function bookCardHTML(book) {
  const pct = getProgress(book);
  const cover = book.cover || DEFAULT_COVER;
  return `
    <div class="card book-card" onclick="openBookDetail('${book.id}')">
      <div class="book-cover">
        ${book.cover ? `<img src="${book.cover}" alt="Portada">` : '📖'}
      </div>
      <div class="book-info">
        <div class="book-title">${esc(book.title)}</div>
        <div class="book-author">${esc(book.author)}</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
        <div class="progress-text">${book.pagesRead} / ${book.totalPages} págs · ${pct}%</div>
        <span class="badge badge-${book.status}">${statusLabel(book.status)}</span>
      </div>
    </div>
  `;
}

function statusLabel(s) {
  return { pendiente: 'Pendiente', leyendo: 'Leyendo', terminado: 'Terminado', abandonado: 'Abandonado' }[s] || s;
}

function esc(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ========== Library ==========
let libraryFilters = { search: '', genre: '', status: '', rating: '' };

function renderLibrary() {
  const genres = [...new Set(state.books.map(b => b.genre).filter(Boolean))].sort();
  const genreSelect = $('#filter-genre');
  genreSelect.innerHTML = '<option value="">Todos los géneros</option>' + genres.map(g => `<option value="${esc(g)}">${esc(g)}</option>`).join('');
  genreSelect.value = libraryFilters.genre;

  $('#filter-status').value = libraryFilters.status;
  $('#filter-rating').value = libraryFilters.rating;
  $('#filter-search').value = libraryFilters.search;

  let books = [...state.books];
  if (libraryFilters.search) {
    const q = libraryFilters.search.toLowerCase();
    books = books.filter(b => b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q));
  }
  if (libraryFilters.genre) books = books.filter(b => b.genre === libraryFilters.genre);
  if (libraryFilters.status) books = books.filter(b => b.status === libraryFilters.status);
  if (libraryFilters.rating) books = books.filter(b => b.rating >= parseInt(libraryFilters.rating));

  const container = $('#library-list');
  if (books.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="icon">📚</div><p>No se encontraron libros.</p></div>`;
  } else {
    container.innerHTML = books.map(b => bookCardHTML(b)).join('');
  }
}

function applyLibraryFilters() {
  libraryFilters.search = $('#filter-search').value.trim();
  libraryFilters.genre = $('#filter-genre').value;
  libraryFilters.status = $('#filter-status').value;
  libraryFilters.rating = $('#filter-rating').value;
  renderLibrary();
}

// ========== Book Modal ==========
let editingBookId = null;

function openBookModal(id = null) {
  editingBookId = id;
  const modal = $('#modal-book');
  const title = $('#modal-book-title');
  const form = $('#form-book');
  form.reset();
  $('#book-cover-preview').innerHTML = '📖';
  $('#book-cover-data').value = '';

  if (id) {
    const book = getBookById(id);
    if (!book) return;
    title.textContent = 'Editar libro';
    $('#book-title').value = book.title;
    $('#book-author').value = book.author;
    $('#book-genre').value = book.genre || '';
    $('#book-total-pages').value = book.totalPages || '';
    $('#book-pages-read').value = book.pagesRead || 0;
    $('#book-start-date').value = book.startDate || '';
    $('#book-end-date').value = book.endDate || '';
    $('#book-status').value = book.status;
    $('#book-comments').value = book.comments || '';
    $('#book-rating').value = book.rating || 0;
    updateStarsDisplay(book.rating || 0);
    if (book.cover) {
      $('#book-cover-preview').innerHTML = `<img src="${book.cover}" alt="Portada">`;
      $('#book-cover-data').value = book.cover;
    }
  } else {
    title.textContent = 'Agregar libro';
    $('#book-status').value = 'pendiente';
    $('#book-pages-read').value = 0;
    $('#book-rating').value = 0;
    updateStarsDisplay(0);
  }
  modal.classList.add('active');
}

function closeModal(id) {
  $(`#${id}`).classList.remove('active');
}

function updateStarsDisplay(val) {
  $$('#book-stars-input span').forEach(s => {
    s.classList.toggle('empty', parseInt(s.dataset.val) > val);
  });
  $('#book-rating').value = val;
}

function handleCoverUpload(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 1.5 * 1024 * 1024) {
    showToast('La imagen es muy grande (máx 1.5 MB)');
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    const data = e.target.result;
    $('#book-cover-data').value = data;
    $('#book-cover-preview').innerHTML = `<img src="${data}" alt="Portada">`;
  };
  reader.readAsDataURL(file);
}

function saveBook(e) {
  e.preventDefault();
  const title = $('#book-title').value.trim();
  const author = $('#book-author').value.trim();
  if (!title || !author) {
    showToast('Título y autor son obligatorios');
    return;
  }
  const totalPages = parseInt($('#book-total-pages').value) || 0;
  let pagesRead = parseInt($('#book-pages-read').value) || 0;
  if (pagesRead > totalPages && totalPages > 0) pagesRead = totalPages;

  const data = {
    title,
    author,
    cover: $('#book-cover-data').value || '',
    genre: $('#book-genre').value.trim(),
    totalPages,
    pagesRead,
    startDate: $('#book-start-date').value,
    endDate: $('#book-end-date').value,
    rating: parseInt($('#book-rating').value) || 0,
    status: $('#book-status').value,
    comments: $('#book-comments').value.trim()
  };

  if (editingBookId) {
    const idx = state.books.findIndex(b => b.id === editingBookId);
    if (idx >= 0) {
      state.books[idx] = { ...state.books[idx], ...data };
    }
    showToast('Libro actualizado');
  } else {
    state.books.push({ id: genId(), ...data });
    showToast('Libro agregado');
  }
  saveData();
  checkAchievements();
  closeModal('modal-book');
  if ($('#section-biblioteca').classList.contains('active')) renderLibrary();
  if ($('#section-inicio').classList.contains('active')) renderHome();
}

function openBookDetail(id) {
  const book = getBookById(id);
  if (!book) return;
  const pct = getProgress(book);
  const sessions = state.sessions.filter(s => s.bookId === id).sort((a, b) => b.date.localeCompare(a.date));

  $('#detail-title').textContent = book.title;
  $('#detail-body').innerHTML = `
    <div class="flex gap-2" style="align-items:flex-start;margin-bottom:1.25rem;">
      <div class="book-cover" style="width:90px;height:130px;">
        ${book.cover ? `<img src="${book.cover}">` : '📖'}
      </div>
      <div>
        <p style="font-weight:600;margin-bottom:0.25rem;">${esc(book.author)}</p>
        <p class="mb-1"><span class="badge badge-${book.status}">${statusLabel(book.status)}</span></p>
        ${book.genre ? `<p class="mb-1" style="font-size:0.9rem;color:var(--texto-suave);">${esc(book.genre)}</p>` : ''}
        ${starsHTML(book.rating)}
        <div class="progress-bar mt-1" style="width:160px;"><div class="progress-fill" style="width:${pct}%"></div></div>
        <p class="progress-text">${book.pagesRead} / ${book.totalPages} · ${pct}%</p>
      </div>
    </div>
    <p class="mb-1"><strong>Inicio:</strong> ${formatDate(book.startDate)} · <strong>Fin:</strong> ${formatDate(book.endDate)}</p>
    ${book.comments ? `<p class="mb-1" style="font-style:italic;">"${esc(book.comments)}"</p>` : ''}
    <h4 class="mt-2 mb-1">Sesiones de lectura (${sessions.length})</h4>
    ${sessions.length ? sessions.slice(0, 5).map(s => `
      <div class="list-item">
        <div>
          <strong>${formatDate(s.date)}</strong> · págs ${s.startPage}–${s.endPage} (${s.pagesRead} págs)
          ${s.minutes ? ` · ${s.minutes} min` : ''}
        </div>
      </div>
    `).join('') : '<p class="empty-state" style="padding:1rem;">Sin sesiones aún</p>'}
  `;
  $('#detail-edit-btn').onclick = () => { closeModal('modal-detail'); openBookModal(id); };
  $('#detail-delete-btn').onclick = () => deleteBook(id);
  $('#modal-detail').classList.add('active');
}

function deleteBook(id) {
  if (!confirm('¿Eliminar este libro y todas sus sesiones asociadas?')) return;
  state.books = state.books.filter(b => b.id !== id);
  state.sessions = state.sessions.filter(s => s.bookId !== id);
  state.diary = state.diary.filter(d => d.bookId !== id);
  saveData();
  showToast('Libro eliminado');
  closeModal('modal-detail');
  renderLibrary();
  renderHome();
}

// ========== Register Session ==========
function renderRegisterForm() {
  const select = $('#session-book');
  const reading = state.books.filter(b => b.status === 'leyendo' || b.status === 'pendiente');
  select.innerHTML = '<option value="">Selecciona un libro</option>' +
    reading.map(b => `<option value="${b.id}">${esc(b.title)} (${b.pagesRead}/${b.totalPages})</option>`).join('');

  $('#session-date').value = new Date().toISOString().slice(0, 10);
  $('#session-start-page').value = '';
  $('#session-end-page').value = '';
  $('#session-minutes').value = '';
  $('#session-notes').value = '';
  $('#session-quote').value = '';
  $('#session-pages-calc').textContent = '0';

  // Recent sessions
  const recent = [...state.sessions].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
  const list = $('#recent-sessions');
  if (recent.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>Aún no hay sesiones registradas.</p></div>';
  } else {
    list.innerHTML = recent.map(s => {
      const book = getBookById(s.bookId);
      return `
        <div class="list-item">
          <div>
            <strong>${book ? esc(book.title) : 'Libro eliminado'}</strong><br>
            <span style="font-size:0.85rem;color:var(--texto-suave);">${formatDate(s.date)} · ${s.pagesRead} págs · ${s.minutes || 0} min</span>
          </div>
          <div class="flex gap-1">
            <button class="btn btn-secondary btn-sm" onclick="editSession('${s.id}')">✏️</button>
            <button class="btn btn-danger btn-sm" onclick="deleteSession('${s.id}')">🗑️</button>
          </div>
        </div>
      `;
    }).join('');
  }
}

function calcSessionPages() {
  const start = parseInt($('#session-start-page').value) || 0;
  const end = parseInt($('#session-end-page').value) || 0;
  const pages = Math.max(0, end - start);
  $('#session-pages-calc').textContent = pages;
  return pages;
}

function onBookSelectForSession() {
  const id = $('#session-book').value;
  const book = getBookById(id);
  if (book) {
    $('#session-start-page').value = book.pagesRead || 0;
    calcSessionPages();
  }
}

let editingSessionId = null;

function saveSession(e) {
  e.preventDefault();
  const bookId = $('#session-book').value;
  if (!bookId) {
    showToast('Selecciona un libro');
    return;
  }
  const startPage = parseInt($('#session-start-page').value) || 0;
  const endPage = parseInt($('#session-end-page').value) || 0;
  const pagesRead = Math.max(0, endPage - startPage);
  if (pagesRead <= 0) {
    showToast('Las páginas deben ser válidas (final > inicial)');
    return;
  }

  const data = {
    bookId,
    date: $('#session-date').value,
    startPage,
    endPage,
    pagesRead,
    minutes: parseInt($('#session-minutes').value) || 0,
    notes: $('#session-notes').value.trim(),
    favoriteQuote: $('#session-quote').value.trim()
  };

  if (editingSessionId) {
    const idx = state.sessions.findIndex(s => s.id === editingSessionId);
    if (idx >= 0) state.sessions[idx] = { ...state.sessions[idx], ...data };
    editingSessionId = null;
    showToast('Sesión actualizada');
  } else {
    state.sessions.push({ id: genId(), ...data });
    showToast('Sesión registrada 📖');
  }

  // Update book progress
  const book = getBookById(bookId);
  if (book) {
    book.pagesRead = Math.max(book.pagesRead, endPage);
    if (book.status === 'pendiente') {
      book.status = 'leyendo';
      if (!book.startDate) book.startDate = data.date;
    }
    if (book.totalPages > 0 && book.pagesRead >= book.totalPages) {
      book.pagesRead = book.totalPages;
      book.status = 'terminado';
      if (!book.endDate) book.endDate = data.date;
      showToast('¡Felicitaciones! Libro terminado 🎉');
    }
  }

  saveData();
  checkAchievements();
  renderRegisterForm();
  if ($('#section-inicio').classList.contains('active')) renderHome();
}

function editSession(id) {
  const s = state.sessions.find(x => x.id === id);
  if (!s) return;
  editingSessionId = id;
  $('#session-book').value = s.bookId;
  $('#session-date').value = s.date;
  $('#session-start-page').value = s.startPage;
  $('#session-end-page').value = s.endPage;
  $('#session-minutes').value = s.minutes || '';
  $('#session-notes').value = s.notes || '';
  $('#session-quote').value = s.favoriteQuote || '';
  calcSessionPages();
  showSection('registrar');
  window.scrollTo({ top: 0 });
}

function deleteSession(id) {
  if (!confirm('¿Eliminar esta sesión?')) return;
  state.sessions = state.sessions.filter(s => s.id !== id);
  // Recalculate book pagesRead from remaining sessions (simple approach: keep max)
  // For simplicity we don't auto-recalc downward; user can edit book manually
  saveData();
  showToast('Sesión eliminada');
  renderRegisterForm();
}

// ========== Goals ==========
function renderGoals() {
  $('#goal-monthly-books').value = state.goals.monthlyBooks || 2;
  $('#goal-daily-pages').value = state.goals.dailyPages || 20;

  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();

  const booksThisMonth = state.books.filter(b => {
    if (b.status !== 'terminado' || !b.endDate) return false;
    const d = new Date(b.endDate + 'T00:00:00');
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  }).length;

  const goalB = state.goals.monthlyBooks || 2;
  const pctB = Math.min(100, Math.round((booksThisMonth / goalB) * 100));
  $('#meta-libros-fill').style.width = pctB + '%';
  $('#meta-libros-text').textContent = `${booksThisMonth} de ${goalB} libros (${pctB}%)`;

  // Daily pages today
  const today = now.toISOString().slice(0, 10);
  const pagesToday = state.sessions
    .filter(s => s.date === today)
    .reduce((sum, s) => sum + s.pagesRead, 0);
  const goalP = state.goals.dailyPages || 20;
  const pctP = Math.min(100, Math.round((pagesToday / goalP) * 100));
  $('#meta-paginas-fill').style.width = pctP + '%';
  $('#meta-paginas-text').textContent = `${pagesToday} de ${goalP} páginas hoy (${pctP}%)`;

  // Reading days
  const uniqueDays = new Set(state.sessions.map(s => s.date)).size;
  $('#reading-days-count').textContent = uniqueDays;

  // Achievements
  const achContainer = $('#achievements-list');
  achContainer.innerHTML = ACHIEVEMENTS.map(a => {
    const unlocked = !!state.achievements[a.id];
    return `
      <div class="achievement ${unlocked ? 'unlocked' : ''}">
        <div class="achievement-icon">${a.icon}</div>
        <div>
          <strong>${a.title}</strong>
          <div style="font-size:0.8rem;color:var(--texto-suave);">${a.desc}</div>
        </div>
      </div>
    `;
  }).join('');

  // Motivational
  if (pctB >= 100) {
    $('#goal-message').innerHTML = '<div class="quote-box">¡Meta mensual alcanzada! Eres una máquina de leer 🌟</div>';
  } else if (pctP >= 100) {
    $('#goal-message').innerHTML = '<div class="quote-box">¡Meta diaria cumplida! Sigue así 💪</div>';
  } else {
    $('#goal-message').innerHTML = '';
  }
}

function saveGoals() {
  state.goals.monthlyBooks = parseInt($('#goal-monthly-books').value) || 2;
  state.goals.dailyPages = parseInt($('#goal-daily-pages').value) || 20;
  saveData();
  showToast('Metas guardadas');
  renderGoals();
}

function checkAchievements() {
  const terminados = state.books.filter(b => b.status === 'terminado').length;
  const totalPages = state.sessions.reduce((s, x) => s + x.pagesRead, 0);
  const uniqueDays = new Set(state.sessions.map(s => s.date)).size;

  const checks = {
    first_book: terminados >= 1,
    pages_100: totalPages >= 100,
    books_5: terminados >= 5,
    streak_7: uniqueDays >= 7,
    pages_500: totalPages >= 500,
    books_10: terminados >= 10
  };

  let newUnlock = false;
  for (const [id, ok] of Object.entries(checks)) {
    if (ok && !state.achievements[id]) {
      state.achievements[id] = true;
      newUnlock = true;
      const a = ACHIEVEMENTS.find(x => x.id === id);
      if (a) showToast(`¡Logro desbloqueado: ${a.title}! ${a.icon}`, 4000);
    }
  }
  if (newUnlock) saveData();
}

// ========== Statistics ==========
function renderStats() {
  // Books finished by month (last 6 months)
  const months = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, label: d.toLocaleDateString('es', { month: 'short', year: '2-digit' }) });
  }

  const booksByMonth = months.map(m => {
    return state.books.filter(b => b.status === 'terminado' && b.endDate && b.endDate.startsWith(m.key)).length;
  });

  // Pages by week (approx last 4 weeks)
  const pagesByWeek = [0, 0, 0, 0];
  state.sessions.forEach(s => {
    const d = new Date(s.date + 'T00:00:00');
    const diff = Math.floor((now - d) / (7 * 24 * 3600 * 1000));
    if (diff >= 0 && diff < 4) pagesByWeek[3 - diff] += s.pagesRead;
  });

  // Total time
  const totalMinutes = state.sessions.reduce((s, x) => s + (x.minutes || 0), 0);
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  $('#stat-total-time').textContent = hours > 0 ? `${hours}h ${mins}min` : `${mins} min`;

  // Genres
  const genreCount = {};
  state.books.filter(b => b.status === 'terminado' && b.genre).forEach(b => {
    genreCount[b.genre] = (genreCount[b.genre] || 0) + 1;
  });
  const topGenres = Object.entries(genreCount).sort((a, b) => b[1] - a[1]).slice(0, 5);
  $('#stat-genres').innerHTML = topGenres.length
    ? topGenres.map(([g, c]) => `<div class="list-item"><span>${esc(g)}</span><strong>${c}</strong></div>`).join('')
    : '<p class="empty-state">Sin datos aún</p>';

  // Ratings avg
  const rated = state.books.filter(b => b.rating > 0);
  const avgRating = rated.length ? (rated.reduce((s, b) => s + b.rating, 0) / rated.length).toFixed(1) : '—';
  $('#stat-avg-rating').textContent = avgRating;

  // Simple bar charts with pure CSS/HTML
  renderSimpleChart('#chart-books-month', months.map(m => m.label), booksByMonth, 'Libros');
  renderSimpleChart('#chart-pages-week', ['Hace 3 sem', 'Hace 2 sem', 'Semana pasada', 'Esta semana'], pagesByWeek, 'Páginas');
}

function renderSimpleChart(selector, labels, values, unit) {
  const max = Math.max(...values, 1);
  const el = $(selector);
  el.innerHTML = `
    <div style="display:flex;align-items:flex-end;gap:8px;height:160px;padding-top:10px;">
      ${values.map((v, i) => `
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;height:100%;justify-content:flex-end;">
          <span style="font-size:0.7rem;margin-bottom:4px;font-weight:600;">${v}</span>
          <div style="width:100%;background:linear-gradient(180deg,var(--rosa-oscuro),var(--lavanda));border-radius:6px 6px 0 0;height:${Math.max(4, (v / max) * 100)}%;min-height:4px;transition:height 0.5s;"></div>
          <span style="font-size:0.65rem;margin-top:6px;color:var(--texto-suave);text-align:center;">${labels[i]}</span>
        </div>
      `).join('')}
    </div>
  `;
}

// ========== Diary ==========
function renderDiary() {
  const list = $('#diary-list');
  const entries = [...state.diary].sort((a, b) => b.date.localeCompare(a.date));
  if (entries.length === 0) {
    list.innerHTML = '<div class="empty-state"><div class="icon">✍️</div><p>Tu diario literario está vacío.<br>Escribe tu primera reflexión.</p></div>';
    return;
  }
  list.innerHTML = entries.map(e => {
    const book = e.bookId ? getBookById(e.bookId) : null;
    return `
      <div class="card">
        <div class="flex-between mb-1">
          <span style="font-size:0.85rem;color:var(--texto-suave);">${formatDate(e.date)} · ${e.type || 'nota'}</span>
          <div class="flex gap-1">
            <button class="btn btn-secondary btn-sm" onclick="editDiary('${e.id}')">✏️</button>
            <button class="btn btn-danger btn-sm" onclick="deleteDiary('${e.id}')">🗑️</button>
          </div>
        </div>
        ${book ? `<p style="font-weight:600;margin-bottom:0.4rem;">📖 ${esc(book.title)}</p>` : ''}
        <p style="white-space:pre-wrap;">${esc(e.content)}</p>
      </div>
    `;
  }).join('');
}

let editingDiaryId = null;

function openDiaryModal(id = null) {
  editingDiaryId = id;
  const form = $('#form-diary');
  form.reset();
  const select = $('#diary-book');
  select.innerHTML = '<option value="">Sin libro asociado</option>' +
    state.books.map(b => `<option value="${b.id}">${esc(b.title)}</option>`).join('');
  $('#diary-date').value = new Date().toISOString().slice(0, 10);

  if (id) {
    const e = state.diary.find(x => x.id === id);
    if (e) {
      $('#diary-book').value = e.bookId || '';
      $('#diary-date').value = e.date;
      $('#diary-type').value = e.type || 'reflexión';
      $('#diary-content').value = e.content;
    }
  }
  $('#modal-diary').classList.add('active');
}

function saveDiary(e) {
  e.preventDefault();
  const content = $('#diary-content').value.trim();
  if (!content) {
    showToast('Escribe algo primero');
    return;
  }
  const data = {
    bookId: $('#diary-book').value || null,
    date: $('#diary-date').value,
    type: $('#diary-type').value,
    content
  };
  if (editingDiaryId) {
    const idx = state.diary.findIndex(x => x.id === editingDiaryId);
    if (idx >= 0) state.diary[idx] = { ...state.diary[idx], ...data };
    showToast('Entrada actualizada');
  } else {
    state.diary.push({ id: genId(), ...data });
    showToast('Entrada guardada');
  }
  saveData();
  closeModal('modal-diary');
  renderDiary();
}

function editDiary(id) {
  openDiaryModal(id);
}

function deleteDiary(id) {
  if (!confirm('¿Eliminar esta entrada?')) return;
  state.diary = state.diary.filter(d => d.id !== id);
  saveData();
  showToast('Entrada eliminada');
  renderDiary();
}

// ========== Calendar ==========
let calYear, calMonth;

function renderCalendar() {
  if (calYear === undefined) {
    const n = new Date();
    calYear = n.getFullYear();
    calMonth = n.getMonth();
  }
  const first = new Date(calYear, calMonth, 1);
  const last = new Date(calYear, calMonth + 1, 0);
  const startDay = first.getDay(); // 0=Sun
  const daysInMonth = last.getDate();

  $('#cal-title').textContent = first.toLocaleDateString('es', { month: 'long', year: 'numeric' });

  // Pages per day map
  const pagesMap = {};
  state.sessions.forEach(s => {
    if (s.date.startsWith(`${calYear}-${String(calMonth + 1).padStart(2, '0')}`)) {
      pagesMap[s.date] = (pagesMap[s.date] || 0) + s.pagesRead;
    }
  });

  const todayStr = new Date().toISOString().slice(0, 10);
  let html = '';
  // Empty cells
  for (let i = 0; i < startDay; i++) {
    html += `<div class="cal-day other-month"></div>`;
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const has = pagesMap[dateStr];
    const isToday = dateStr === todayStr;
    html += `<div class="cal-day ${has ? 'has-reading' : ''} ${isToday ? 'today' : ''}" onclick="showDayDetail('${dateStr}')" title="${has ? has + ' págs' : ''}">
      <span>${d}</span>
      ${has ? `<span style="font-size:0.6rem;">${has}p</span>` : ''}
    </div>`;
  }
  $('#cal-grid').innerHTML = html;
}

function changeMonth(delta) {
  calMonth += delta;
  if (calMonth > 11) { calMonth = 0; calYear++; }
  if (calMonth < 0) { calMonth = 11; calYear--; }
  renderCalendar();
}

function showDayDetail(dateStr) {
  const sessions = state.sessions.filter(s => s.date === dateStr);
  const total = sessions.reduce((s, x) => s + x.pagesRead, 0);
  if (sessions.length === 0) {
    showToast(`Sin lectura el ${formatDate(dateStr)}`);
    return;
  }
  let msg = `${formatDate(dateStr)}: ${total} páginas\n`;
  sessions.forEach(s => {
    const b = getBookById(s.bookId);
    msg += `• ${b ? b.title : '?'}: ${s.pagesRead} págs\n`;
  });
  alert(msg);
}

// ========== Config ==========
function renderConfig() {
  $('#config-name').value = state.settings.userName || '';
  const totalBooks = state.books.length;
  const totalSessions = state.sessions.length;
  const totalDiary = state.diary.length;
  $('#config-stats').textContent = `${totalBooks} libros · ${totalSessions} sesiones · ${totalDiary} entradas de diario`;
}

function saveConfig() {
  state.settings.userName = $('#config-name').value.trim() || 'Lector/a';
  saveData();
  showToast('Configuración guardada');
  renderHome();
}

function exportData() {
  const data = JSON.stringify(state, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `lectora-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('Copia de seguridad descargada');
}

function importData(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (!data.books || !Array.isArray(data.books)) throw new Error('Formato inválido');
      if (!confirm('Esto reemplazará todos tus datos actuales. ¿Continuar?')) return;
      state = { ...state, ...data };
      saveData();
      showToast('Datos importados correctamente');
      showSection('inicio');
    } catch (err) {
      showToast('Error al importar: archivo inválido');
    }
  };
  reader.readAsText(file);
  input.value = '';
}

function clearAllData() {
  if (!confirm('¿Estás seguro? Se borrarán TODOS tus libros, sesiones, metas y notas. Esta acción no se puede deshacer.')) return;
  if (!confirm('Última confirmación: ¿Borrar todo permanentemente?')) return;
  localStorage.removeItem(STORAGE_KEY);
  state = {
    books: [],
    sessions: [],
    diary: [],
    goals: { monthlyBooks: 2, dailyPages: 20, challenges: [] },
    achievements: {},
    settings: { userName: 'Lector/a' }
  };
  saveData();
  showToast('Todos los datos han sido eliminados');
  showSection('inicio');
}

// ========== Init ==========
function init() {
  loadData();
  checkAchievements();

  // Nav
  $$('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => showSection(btn.dataset.section));
  });

  // Stars input
  $$('#book-stars-input span').forEach(s => {
    s.addEventListener('click', () => updateStarsDisplay(parseInt(s.dataset.val)));
  });

  // Session page calc
  $('#session-start-page')?.addEventListener('input', calcSessionPages);
  $('#session-end-page')?.addEventListener('input', calcSessionPages);
  $('#session-book')?.addEventListener('change', onBookSelectForSession);

  // Forms
  $('#form-book')?.addEventListener('submit', saveBook);
  $('#form-session')?.addEventListener('submit', saveSession);
  $('#form-diary')?.addEventListener('submit', saveDiary);

  // PWA install
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    $('#install-banner')?.classList.add('show');
  });
  $('#install-btn')?.addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') showToast('¡App instalada!');
      deferredPrompt = null;
      $('#install-banner')?.classList.remove('show');
    }
  });

  // Service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(console.error);
  }

  showSection('inicio');
}

document.addEventListener('DOMContentLoaded', init);

// Expose for inline handlers
window.showSection = showSection;
window.openBookModal = openBookModal;
window.closeModal = closeModal;
window.openBookDetail = openBookDetail;
window.handleCoverUpload = handleCoverUpload;
window.applyLibraryFilters = applyLibraryFilters;
window.saveSession = saveSession;
window.editSession = editSession;
window.deleteSession = deleteSession;
window.saveGoals = saveGoals;
window.openDiaryModal = openDiaryModal;
window.editDiary = editDiary;
window.deleteDiary = deleteDiary;
window.changeMonth = changeMonth;
window.showDayDetail = showDayDetail;
window.saveConfig = saveConfig;
window.exportData = exportData;
window.importData = importData;
window.clearAllData = clearAllData;
window.deleteBook = deleteBook;
