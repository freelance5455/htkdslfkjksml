IRON PERFORMANCE — ST Personal Trainer

Contents:
- index.html: responsive Arabic client management web app.
- assets/iron-performance-logo.png: your provided logo unchanged.

Features:
- Client profiles with unique ID, name, phone, age, package sessions, subscription type/date, status and notes.
- Multiple InBody records per client.
- Assessment records (experience, stress, mobility, posture, notes).
- Workout sheets per client with multiple days and exercises; each exercise supports sets, reps, weight and notes.
- Printable workout sheets.
- JSON export/import backup.
- Local browser storage; no remote libraries are needed.

Open index.html in a modern browser. This is an offline-friendly web app prototype, not an Android APK. Data is stored in that browser on that device; export backups regularly because clearing browser storage can erase data.
