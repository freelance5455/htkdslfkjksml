# Socle 3.3 — Détails des damistes et rendu lumineux 3D

## Objectif
Renforcer la lisibilité et la richesse visuelle de la scène 3D sans changer les règles de jeu, les compétitions, le calendrier ou les données de carrière.

## Améliorations
- Éclairage WebGL enrichi : lumière diffuse, lumière de remplissage, reflet spéculaire, contour lumineux et brume atmosphérique légère.
- Figurines humanoïdes enrichies : chaussures, jambes, tunique, col, écusson, détails du visage et couronne distincte pour les dames.
- Tribunes plus vivantes : silhouettes de supporters avec têtes et gestes de bras.
- Conservation des animations de déplacement, de prise, de réflexion, de présentation, de victoire et de défaite.

## Limites connues
Les modèles restent des figurines 3D stylisées générées procéduralement. Cette étape ne prétend pas fournir des humains photoréalistes, une capture de mouvement professionnelle ni un rendu équivalent à un jeu commercial AAA.

## Compatibilité
Le moteur de règles, les interfaces de match et les huit moteurs de compétition restent hors du périmètre de modification de cette étape.
