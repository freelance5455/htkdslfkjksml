document.addEventListener("DOMContentLoaded", () => {
  const whatsappNumber = "201274847048";
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  document.querySelectorAll(".inquire").forEach((button) => {
    button.addEventListener("click", () => {
      const product = button.dataset.product || "المنتجات";
      const message = `السلام عليكم، أريد الاستفسار عن: ${product} من التوكيل الأصلي لمستلزمات الورش والمصانع.`;
      const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank", "noopener,noreferrer");
    });
  });
});
