/* NIZAMY PRO Android bridge — Capacitor native notifications only; browser/Electron remain supported. */
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

const isNativeAndroid = Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
window.nzIsAndroidApp = isNativeAndroid;

window.nzAndroidRequestNotificationPermission = async function () {
  if (!isNativeAndroid) return false;
  let permission = await LocalNotifications.checkPermissions();
  if (permission.display !== 'granted') permission = await LocalNotifications.requestPermissions();
  return permission.display === 'granted';
};

window.nzAndroidNotify = async function ({ title, body, target } = {}) {
  if (!isNativeAndroid) throw new Error('Native Android notifications are unavailable');
  const permitted = await window.nzAndroidRequestNotificationPermission();
  if (!permitted) throw new Error('Notification permission not granted');
  const id = Math.floor(Date.now() % 2147483000) || 1;
  await LocalNotifications.schedule({
    notifications: [{
      id,
      title: String(title || 'NIZAMY PRO'),
      body: String(body || ''),
      extra: target ? { target } : undefined,
      schedule: { at: new Date(Date.now() + 250) }
    }]
  });
  return true;
};

if (isNativeAndroid) {
  LocalNotifications.addListener('localNotificationActionPerformed', event => {
    const target = event?.notification?.extra?.target;
    if (!target) return;
    const openTarget = () => {
      if (typeof window.nzOpenNotificationTarget === 'function') window.nzOpenNotificationTarget(target);
      else window.__nzmPendingNotificationTarget = target;
    };
    if (document.readyState === 'complete') openTarget();
    else window.addEventListener('load', openTarget, { once: true });
  });
}
