# CodeHub Online-ready

Prototype responsive cho điện thoại, nền đen.

## Online thật
App đã chuẩn bị giao diện tài khoản, nhưng để có dữ liệu người dùng thật cần cấu hình backend. Khuyến nghị Firebase Authentication + Firestore + Storage, hoặc Supabase Auth + Database + Storage.

### Dữ liệu nên có
users, posts, follows, likes, saved_posts, files.

### Bảo mật
Saved posts phải được giới hạn theo user ID ở database rules; file upload cần kiểm tra loại/kích thước.

Mở index.html để xem giao diện.
