// gw_calc.js

/**
 * Calculates chirp mass.
 * @param {number} m1 Mass 1.
 * @param {number} m2 Mass 2.
 * @returns {number} Chirp mass.
 */
function chirp_mass(m1, m2) {
    return Math.pow(m1 * m2, 3.0 / 5.0) / Math.pow(m1 + m2, 1.0 / 5.0);
}

/**
 * Calculates semi-major axis from orbital frequency.
 * @param {number} omegatoact Constant relating omega to a. (Comegatoa in Python)
 * @param {number} freq_val Orbital frequency (omega).
 * @returns {number} Semi-major axis.
 */
function semimajora(omegatoact, freq_val) {
    if (freq_val === 0) return Infinity; // Avoid division by zero if frequency is zero
    return omegatoact * Math.pow(freq_val, -2.0 / 3.0);
}

/**
 * Calculates GW frequency evolution (vectorized for pre-merger).
 * @param {number} Act Constant A for frequency calculation.
 * @param {number} Bct Constant B for frequency calculation (time of coalescence).
 * @param {number} Mchirp_val Chirp mass.
 * @param {number[]} t_array Array of time values (frames).
 * @param {number} merger_frame Frame number of merger.
 * @param {number} frametotime Conversion factor.
 * @returns {number[]} Array of frequencies.
 */
function freq_vectorized(Act, Bct, Mchirp_val, t_array, merger_frame, frametotime) {
    const freq_array = [];
    const Mchirp_pow = Math.pow(Mchirp_val, -5.0 / 8.0);
    const const_freq_val_at_merger = Act * Mchirp_pow * Math.pow(Bct - merger_frame * frametotime, -3.0 / 8.0);

    for (let i = 0; i < t_array.length; i++) {
        const t = t_array[i];
        if (t <= merger_frame) {
            const time_to_coalescence = Bct - t * frametotime;
            if (time_to_coalescence <= 0) { // Should not happen if Bct is set correctly
                 freq_array.push(const_freq_val_at_merger); // Use merger freq if somehow past Bct
            } else {
                freq_array.push(Act * Mchirp_pow * Math.pow(time_to_coalescence, -3.0 / 8.0));
            }
        } else {
            freq_array.push(const_freq_val_at_merger); // Constant post-merger frequency
        }
    }
    return freq_array;
}

/**
 * Calculates GW frequency for position calculation (slightly different post-merger).
 * @param {number} Act
 * @param {number} Bct
 * @param {number} Mchirp_val
 * @param {number} t
 * @param {number} merger_frame
 * @param {number} frametotime
 * @returns {number}
 */
function freq_pos(Act, Bct, Mchirp_val, t, merger_frame, frametotime) {
    const Mchirp_pow = Math.pow(Mchirp_val, -5.0 / 8.0);
    if (t <= merger_frame) {
        const time_to_coalescence = Bct - t * frametotime;
         if (time_to_coalescence <= 0) {
            return Act * Mchirp_pow * Math.pow(Bct - merger_frame * frametotime, -3.0 / 8.0);
        }
        return Act * Mchirp_pow * Math.pow(time_to_coalescence, -3.0 / 8.0);
    } else {
        // Python: Act * np.power(Mchirp,-5.0/8.0) * np.power(Bct - merger_frame*frametotime, -3.0/8.0)*(1 + (t-merger_frame)*frametotime)
        // This implies frequency increases linearly post-merger for position calculation, which is unusual.
        // The original freq() function for wave calculation holds it constant.
        // Let's stick to the Python version for freq_pos.
        const base_freq = Act * Mchirp_pow * Math.pow(Bct - merger_frame * frametotime, -3.0 / 8.0);
        //return base_freq * (1 + (t - merger_frame) * frametotime * 0.1); // Added a small factor to prevent excessive growth, adjust if needed
        return base_freq * (1 + (t - merger_frame) * frametotime);
    }
}


/**
 * Calculates constant A for frequency calculation.
 * freqA(amerge, Comegatoa, Mchirp, CfreqB, merger_frame, frametotime)
 * @returns {number}
 */
function freqA_const(amerge, Comegatoa, Mchirp_val, CfreqB, merger_frame, frametotime) {
    const term1 = amerge / Comegatoa;
    const term2 = Math.pow(Mchirp_val, -5.0 / 2.0);
    const time_diff = CfreqB - merger_frame * frametotime;
    if (time_diff <= 0) { // Avoid issues if merger_frame*frametotime >= CfreqB
        // This implies the merger happens at or after the coalescence time Bct, which is problematic.
        // Default to a small positive number to avoid NaN/Infinity.
        // This case indicates an issue with parameter setup (CfreqB should be > merger_frame * frametotime).
        console.warn("Problematic CfreqB and merger_frame relation in freqA_const. CfreqB:", CfreqB, "merger_time:", merger_frame * frametotime);
        return Math.pow(term1 * term2 * Math.pow(1e-6, -1.0/4.0), -3.0/2.0); // Use a small placeholder for time_diff
    }
    const term3 = Math.pow(time_diff, -1.0 / 4.0);
    return Math.pow(term1 * term2 * term3, -3.0 / 2.0);
}


/**
 * Calculates GW strain h_xy component.
 * @param {number} strainct Strain constant (Cstrain).
 * @param {number} omega Orbital frequency.
 * @param {number} a Semi-major axis.
 * @param {number} e Eccentricity.
 * @param {number} t Time (frame).
 * @param {number} frametotime Conversion factor.
 * @param {number} [xyparam=1.0]
 * @param {number} [diagparam=0.0]
 * @returns {number} Strain value.
 */
function calculate_strain(strainct, omega, a, e, t, frametotime, xyparam = 1.0, diagparam = 0.0) {
    const params = orbitalParams(omega, a, e, t, frametotime);
    const { x, y } = xy_coords(params.rs, params.thetas);
    const { xd, yd } = xyd_velocities(params.rs, params.thetas, params.thetads, params.rds);
    const { xdd, ydd } = xydd_accelerations(params.rs, params.thetas, params.rds, params.thetads, params.rdds, params.thetadds);

    const h_xy_term = xyparam * (xdd * y + 2.0 * xd * yd + x * ydd);
    const h_diag_term = diagparam * (2.0 * Math.pow(xd, 2) + 2.0 * x * xdd - (2.0 * Math.pow(yd, 2) + 2.0 * y * ydd));
    
    return strainct * (h_xy_term + h_diag_term);
}

/**
 * Calculates gravitational wave amplitude for a given frame (vectorized approach).
 * @param {number[]} times Array of time values (frames).
 * @param {number} Act Constant A for frequency.
 * @param {number} Bct Constant B for frequency.
 * @param {number} omegatoact Constant relating omega to a.
 * @param {number} Mchirp_val Chirp mass.
 * @param {number} e Eccentricity.
 * @param {number} Cstrain Strain constant.
 * @param {number} merger_frame Frame of merger.
 * @param {number} frametotime Conversion factor.
 * @returns {number[]} Array of wave amplitudes.
 */
function wave_vectorized(times, Act, Bct, omegatoact, Mchirp_val, e, Cstrain, merger_frame, frametotime) {
    const results = [];
    const omegas = freq_vectorized(Act, Bct, Mchirp_val, times, merger_frame, frametotime);
    const merger_omega_at_merger_frame = freq_vectorized(Act, Bct, Mchirp_val, [merger_frame], merger_frame, frametotime)[0];

    for (let i = 0; i < times.length; i++) {
        const t = times[i];
        const current_omega = omegas[i];
        let current_a;

        if (t < merger_frame) {
            current_a = semimajora(omegatoact, current_omega);
        } else {
            current_a = semimajora(omegatoact, merger_omega_at_merger_frame);
        }

        let strain_val = calculate_strain(Cstrain, current_omega, current_a, e, t, frametotime);

        if (t >= merger_frame) {
            strain_val *= Math.exp(0.05 * (merger_frame - t)); // Ringdown decay
        }
        results.push(strain_val);
    }
    return results;
}
