// math_helpers.js

/**
 * Creates an array of evenly spaced numbers over a specified interval.
 * @param {number} start - The starting value of the sequence.
 * @param {number} stop - The end value of the sequence.
 * @param {number} num - Number of samples to generate.
 * @returns {number[]}
 */
function linspace(start, stop, num) {
    const arr = [];
    if (num === 0) return arr;
    if (num === 1) {
        arr.push(start);
        return arr;
    }
    const step = (stop - start) / (num - 1);
    for (let i = 0; i < num; i++) {
        arr.push(start + step * i);
    }
    return arr;
}

/**
 * Creates 2D grid coordinates from 1D coordinate arrays.
 * @param {number[]} x - Array of x coordinates.
 * @param {number[]} y - Array of y coordinates.
 * @returns {{X: number[][], Y: number[][]}} Object containing X and Y grids.
 */
function meshgrid(x, y) {
    const X = [];
    const Y = [];
    for (let j = 0; j < y.length; j++) {
        X.push([...x]);
        const yRow = [];
        for (let i = 0; i < x.length; i++) {
            yRow.push(y[j]);
        }
        Y.push(yRow);
    }
    return { X, Y };
}

/**
 * Solves Kepler's equation M = psi - e * sin(psi) for psi using Newton's method.
 * @param {number} omega - Mean motion.
 * @param {number} e - Eccentricity.
 * @param {number} t - Time (frame number).
 * @param {number} frametotime - Conversion factor from frame to time.
 * @param {number} [tol=1e-10] - Tolerance for convergence.
 * @param {number} [max_iter=10] - Maximum iterations.
 * @returns {number} psi - Eccentric anomaly.
 */
function solvePsi(omega, e, t, frametotime, tol = 1e-10, max_iter = 20) { // Increased max_iter slightly
    const M = omega * t * frametotime;
    let psi = M; // Initial guess
    for (let iter = 0; iter < max_iter; iter++) {
        const f_psi = psi - e * Math.sin(psi) - M;
        const df_dpsi = 1.0 - e * Math.cos(psi);
        if (Math.abs(df_dpsi) < 1e-12) { // Avoid division by zero or very small number
             // This can happen if e is close to 1 and cos(psi) is close to 1/e
             // Or if the derivative is genuinely zero at the root.
             // For orbital mechanics, this is less common with typical e < 1
             // console.warn("Derivative close to zero in solvePsi", {omega, e, t, frametotime, psi, df_dpsi});
             // If M is small, psi is small. If M is pi, psi is pi.
             // A more robust solver might be needed for extreme cases, but Newton's usually works.
             if (Math.abs(M) < tol) return 0;
             if (Math.abs(M - Math.PI) < tol) return Math.PI;
             // Fallback or break if stuck
             break;
        }
        const delta = f_psi / df_dpsi;
        psi -= delta;
        if (Math.abs(delta) < tol) {
            return psi;
        }
    }
    // console.warn(`solvePsi did not converge after ${max_iter} iterations for M=${M}, e=${e}. Returning current psi=${psi}`);
    return psi; // Return best guess if no convergence
}


/**
 * Helper to create a 2D array (matrix) filled with a value.
 * @param {number} rows
 * @param {number} cols
 * @param {*} fillValue
 * @returns {Array<Array<*>>}
 */
function createMatrix(rows, cols, fillValue = 0) {
    return Array(rows).fill(null).map(() => Array(cols).fill(fillValue));
}

/**
 * Helper to get unique, sorted values from an array.
 * @param {number[]} arr
 * @returns {number[]}
 */
function uniqueSorted(arr) {
    return [...new Set(arr)].sort((a, b) => a - b);
}

/**
 * Rounds a number to a specified number of decimal places.
 * @param {number} num
 * @param {number} decimals
 * @returns {number}
 */
function roundTo(num, decimals) {
    const factor = Math.pow(10, decimals);
    return Math.round(num * factor) / factor;
}
