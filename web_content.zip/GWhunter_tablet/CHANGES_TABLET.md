# Tablet fixes (crash on load)

Cause: the app precomputed all 49 simulations at "expo" quality and kept every
frame as nested JavaScript arrays -> ~1.2 GB of RAM before the loading bar
finished. Android browsers/WebViews kill the tab long before that.

Changes
1. index.html: window.EXPO_MODE = false (the app's own switch for non-exhibition
   devices: lighter simulation, idle throttle, language follows the browser).
2. simulation_core.js: every frame is stored as one flat Float32Array instead of
   a nested array; Z1/Z2 are computed per frame instead of all frames at once;
   wave-grid index lookup hoisted out of the frame loop.
3. main_animation.js: reads the flat frames through a small zAt() helper.

Result (all 49 simulations): ~539 MB retained / 1.29 GB peak  ->  ~240 MB / ~400 MB.
Output numerically identical (max difference 1e-6 on values up to 32).

To restore exhibition behaviour set window.EXPO_MODE = true in index.html.
