// main_animation.js

// COLORS
const REF_PLOT_COLOR = '#ffcc00';      // Signaal uit de ruimte (Goudgeel)
const SIM_PLOT_COLOR = '#0339F8';      // Jouw signaal (Oorspronkelijke diepblauwe kleur)
const GRID_COLOR = '#0339F8';          // Visuele simulatie grid (Zelfde diepblauw)
const CORRECT_GUESS_COLOR = '#008000';  // Wordt gebruikt bij winst (Groen)
const BACKGROUND_COLOR = '#0f1430'; 
const AXIS_TEXT_COLOR = '#fcfafa';
const NORMAL_TEXT_COLOR = '#a9c4ff';

/* ── EXPO MODE ──────────────────────────────────────────────────────────────
   Set in GWhunter.html, read everywhere. When true, every browser/device
   adaptation is bypassed and the simulation runs at full quality. */
const EXPO_MODE = (typeof window !== 'undefined' && window.EXPO_MODE === true);

/* Reads one height value from a simulation frame. Frames are now flat
   Float32Arrays (index = row * cols + col) to keep memory low on tablets; the
   nested-array form is still accepted for the all-zero fallback grid.
   Returns undefined when out of range, like the old Z[y][x] checks did. */
function zAt(Z, y, x, cols) {
    if (!Z) return undefined;
    if (Z.length && typeof Z[0] === 'object') {        // legacy nested matrix
        return Z[y] ? Z[y][x] : undefined;
    }
    return Z[y * cols + x];
}

// --- LOCALIZATION ENGINE ---
const SUPPORTED_LANGS = ['nl', 'en', 'fr', 'de'];

/* Expo: always Dutch, regardless of the machine's locale - the exhibit has a
   known audience and the switcher is right there for anyone who wants another
   language. Elsewhere: follow the browser, falling back to Dutch.
   See REVIEW_issues.md #17. */
function detectInitialLanguage() {
    if (EXPO_MODE) return 'nl';
    if (typeof navigator === 'undefined') return 'nl';

    const candidates = (navigator.languages && navigator.languages.length)
        ? navigator.languages
        : [navigator.language];

    for (const tag of candidates) {
        if (!tag) continue;
        // "de-AT" and "de" both count as German
        const base = String(tag).toLowerCase().split('-')[0];
        if (SUPPORTED_LANGS.indexOf(base) !== -1) return base;
    }
    return 'nl';
}

let currentLang = detectInitialLanguage();

const translations = {
    nl: {
        title: "Word zwaartekrachtgolf-detective!",
        loading: "Initiele berekeningen...",
        main_title: "SPEEL DETECTIVE!<br>WAT VEROORZAAKTE DEZE ZWAARTEKRACHTGOLF?",
        top_message: "Twee zwarte gaten botsten en maakten een zwaartekrachtgolf. <br><br> Ontdek jij wat de eigenschappen waren van die zwarte gaten?",
        sim_title: "SIMULATIE",
        popup_visual_body: "Kijk hoe jouw simulatie verandert wanneer je de eigenschappen verandert",
        observed_wave: "WAARGENOMEN GOLF",
        match_text: "MATCH DE GOLVEN",
        simulated_wave: "SIMULATIE GOLF",
        properties: "EIGENSCHAPPEN",
        popup_properties_body: "Pas hier de eigenschappen van jouw simulatie aan",
        fun_fact: "<strong>Fun fact:</strong> In het echt zijn er wel 17 eigenschappen die wetenschappers moeten zoeken. Enkel voor echte speurneuzen dus!",
        // Soft hyphen at the compound boundary (massa|verschil), so the title
        // wraps to two lines instead of overflowing its column. Same fix as DE.
        mass_diff: "MASSA­VERSCHIL",
        mass_large: "Groot",
        mass_equal: "Gelijk",
        orbit_shape: "BAANVORM",
        orbit_ellipse: "Ellips",
        orbit_circle: "Cirkel",
        try_new_signal: "NIEUW SIGNAAL PROBEREN",
        congratulations: "Gefeliciteerd!",
        win_message: "Er is een match! Nu weten we wat de zwaartekrachtgolf maakte.",
        axis_time: "Tijd",
        axis_signal: "Signaal",
        success_message: "Gelukt! Je hebt het signaal gevonden!",
        hint_play_me: "TIK EN SPEEL"
    },
    en: {
        title: "Become a Gravitational Wave Detective!",
        loading: "Initial calculations...",
        main_title: "PLAY DETECTIVE!<br>WHAT CAUSED THIS GRAVITATIONAL WAVE?",
        top_message: "Two black holes collided and created a gravitational wave. <br><br> Can you discover the properties of those black holes?",
        sim_title: "SIMULATION",
        popup_visual_body: "See how your simulation changes when you modify the properties",
        observed_wave: "OBSERVED WAVE",
        match_text: "MATCH THE WAVES",
        simulated_wave: "SIMULATED WAVE",
        properties: "PROPERTIES",
        popup_properties_body: "Adjust the properties of your simulation here",
        fun_fact: "<strong>Fun fact:</strong> In reality, there are up to 17 properties that scientists have to search for. Only for true sleuths!",
        mass_diff: "MASS DIFFERENCE",
        mass_large: "Large",
        mass_equal: "Equal",
        orbit_shape: "ORBIT SHAPE",
        orbit_ellipse: "Ellipse",
        orbit_circle: "Circle",
        try_new_signal: "TRY NEW SIGNAL",
        congratulations: "Congratulations!",
        win_message: "It's a match! Now we know what created the gravitational wave.",
        axis_time: "Time",
        axis_signal: "Signal",
        success_message: "Success! You found the signal!",
        hint_play_me: "TAP AND PLAY"
    },
    fr: {
        title: "Devenez un détective des ondes gravitationnelles !",
        loading: "Calculs initiaux...",
        main_title: "JOUEZ AU DÉTECTIVE !<br>QU'A CAUSÉ CETTE ONDE GRAVITATIONNELLE ?",
        top_message: "Deux trous noirs sont entrés en collision et ont créé une onde gravitationnelle. <br><br> Pouvez-vous découvrir les propriétés de ces trous noirs ?",
        sim_title: "SIMULATION",
        popup_visual_body: "Regardez comment votre simulation change lorsque vous modifiez les propriétés",
        observed_wave: "ONDE OBSERVÉE",
        match_text: "ASSOCIEZ LES ONDES",
        simulated_wave: "ONDE SIMULÉE",
        properties: "PROPRIÉTÉS",
        popup_properties_body: "Ajustez les propriétés de votre simulation ici",
        fun_fact: "<strong>Info amusante :</strong> En réalité, il y a jusqu'à 17 propriétés que les scientifiques doivent rechercher. Avis aux vrais détectives !",
        mass_diff: "DIFFÉRENCE DE MASSE",
        mass_large: "Grande",
        mass_equal: "Égale",
        orbit_shape: "FORME DE L'ORBITE",
        orbit_ellipse: "Ellipse",
        orbit_circle: "Cercle",
        try_new_signal: "ESSAYER UN NOUVEAU SIGNAL",
        congratulations: "Félicitations !",
        win_message: "C'est une correspondance ! Maintenant, nous savons ce qui a créé l'onde gravitationnelle.",
        axis_time: "Temps",
        axis_signal: "Signal",
        success_message: "Succès ! Vous avez trouvé le signal !",
        hint_play_me: "TOUCHE ET JOUE"
    },
    de: {
        title: "Werde Gravitationswellen-Detektiv!",
        loading: "Erste Berechnungen...",
        main_title: "SPIEL DETEKTIV!<br>WAS HAT DIESE GRAVITATIONSWELLE VERURSACHT?",
        top_message: "Zwei Schwarze Löcher sind zusammengestoßen und haben eine Gravitationswelle erzeugt. <br><br> Entdeckst du, welche Eigenschaften diese Schwarzen Löcher hatten?",
        sim_title: "SIMULATION",
        popup_visual_body: "Schau, wie sich deine Simulation verändert, wenn du die Eigenschaften änderst",
        observed_wave: "BEOBACHTETE WELLE",
        match_text: "WELLEN ABGLEICHEN",
        simulated_wave: "SIMULIERTE WELLE",
        properties: "EIGENSCHAFTEN",
        popup_properties_body: "Passe hier die Eigenschaften deiner Simulation an",
        fun_fact: "<strong>Schon gewusst?</strong> In Wirklichkeit gibt es sogar 17 Eigenschaften, nach denen Wissenschaftler suchen müssen. Nur für echte Spürnasen!",
        // Soft hyphen (­) at the compound boundary: renders as one word when it
        // fits, and breaks as "MASSEN-" / "UNTERSCHIED" when the column is too narrow.
        mass_diff: "MASSEN­UNTERSCHIED",
        mass_large: "Groß",
        mass_equal: "Gleich",
        orbit_shape: "BAHNFORM",
        orbit_ellipse: "Ellipse",
        orbit_circle: "Kreis",
        try_new_signal: "NEUES SIGNAL VERSUCHEN",
        congratulations: "Glückwunsch!",
        win_message: "Es passt! Jetzt wissen wir, was die Gravitationswelle erzeugt hat.",
        axis_time: "Zeit",
        axis_signal: "Signal",
        success_message: "Geschafft! Du hast das Signal gefunden!",
        hint_play_me: "TIPPE UND SPIELE"
    }
};

function updateLanguageUI(lang) {
    currentLang = lang;
    document.documentElement.lang = lang;
    document.title = translations[lang].title;
    
    const elLoadingText = document.getElementById('loading-text');
    if (elLoadingText) elLoadingText.textContent = translations[lang].loading;
    
    const elMainTitle = document.getElementById('lbl-main-title');
    if (elMainTitle) elMainTitle.innerHTML = translations[lang].main_title;
    
    const elTopMessage = document.getElementById('top-message');
    if (elTopMessage) elTopMessage.innerHTML = translations[lang].top_message;
    
    const elVisualTitle = document.getElementById('lbl-popup-visual-title');
    if (elVisualTitle) elVisualTitle.textContent = translations[lang].sim_title;
    
    const elVisualCardTitle = document.querySelector('#visual-simulation-card .card-title');
    if (elVisualCardTitle) elVisualCardTitle.textContent = translations[lang].sim_title;
    
    const elVisualBody = document.getElementById('lbl-popup-visual-body');
    if (elVisualBody) elVisualBody.textContent = translations[lang].popup_visual_body;
    
    const elObservedWave = document.querySelector('#reference-card .card-title');
    if (elObservedWave) elObservedWave.textContent = translations[lang].observed_wave;
    
    const elMatchText = document.getElementById('match-text');
    if (elMatchText) elMatchText.textContent = translations[lang].match_text;
    
    if (simulatedSignalTitleEl) simulatedSignalTitleEl.textContent = translations[lang].simulated_wave;
    
    const elPopupPropsTitle = document.getElementById('lbl-popup-properties-title');
    if (elPopupPropsTitle) elPopupPropsTitle.textContent = translations[lang].properties;
    
    const elSliderBoxTitle = document.getElementById('lbl-slider-box-title');
    if (elSliderBoxTitle) elSliderBoxTitle.textContent = translations[lang].properties;
    
    const elPopupPropsBody = document.getElementById('lbl-popup-properties-body');
    if (elPopupPropsBody) elPopupPropsBody.textContent = translations[lang].popup_properties_body;
    
    const elPopupPropsFunfact = document.getElementById('lbl-popup-properties-funfact');
    if (elPopupPropsFunfact) elPopupPropsFunfact.innerHTML = translations[lang].fun_fact;
    
    const elMassDiff = document.getElementById('lbl-mass-diff');
    if (elMassDiff) elMassDiff.textContent = translations[lang].mass_diff;
    
    const elMassLarge = document.getElementById('lbl-mass-large');
    if (elMassLarge) elMassLarge.textContent = translations[lang].mass_large;
    
    const elMassEqual = document.getElementById('lbl-mass-equal');
    if (elMassEqual) elMassEqual.textContent = translations[lang].mass_equal;
    
    const elOrbitShape = document.getElementById('lbl-orbit-shape');
    if (elOrbitShape) elOrbitShape.textContent = translations[lang].orbit_shape;
    
    const elOrbitEllipse = document.getElementById('lbl-orbit-ellipse');
    if (elOrbitEllipse) elOrbitEllipse.textContent = translations[lang].orbit_ellipse;
    
    const elOrbitCircle = document.getElementById('lbl-orbit-circle');
    if (elOrbitCircle) elOrbitCircle.textContent = translations[lang].orbit_circle;
    
    if (resetBtn) resetBtn.textContent = translations[lang].try_new_signal;
    
    const elWinTitle = document.getElementById('win-toast-title');
    if (elWinTitle) elWinTitle.textContent = translations[lang].congratulations;
    
    const elWinMessage = document.getElementById('win-toast-message');
    if (elWinMessage) elWinMessage.textContent = translations[lang].win_message;
    
    if (winToastNewGameButton) winToastNewGameButton.textContent = translations[lang].try_new_signal;

    const elPlayHintText = document.getElementById('play-hint-text');
    if (elPlayHintText) elPlayHintText.textContent = translations[lang].hint_play_me;

    /* Slider accessible names follow the language. The soft hyphen in the German
       mass_diff string is stripped - it is a line-break hint, not something a
       screen reader should read out. See REVIEW_issues.md #33. */
    const stripSoftHyphens = (text) => text.replace(/\u00AD/g, '');
    const elM1Track = document.getElementById('m1-dots-container');
    if (elM1Track) elM1Track.setAttribute('aria-label', stripSoftHyphens(translations[lang].mass_diff));
    const elETrack = document.getElementById('e-dots-container');
    if (elETrack) elETrack.setAttribute('aria-label', stripSoftHyphens(translations[lang].orbit_shape));

    // Rerender active canvas layers immediately to apply text updates
    if (typeof referenceStrainCtx !== 'undefined' && precomputedSimulations && randomReferenceChoice.m1 !== null) {
        const refKey = `m1_${randomReferenceChoice.m1.toFixed(NRDIGITS)}_e_${randomReferenceChoice.e.toFixed(NRDIGITS)}`;
        const referenceData = precomputedSimulations[refKey];
        if (referenceData && referenceData.waves) {
            const refPlotColor = gameWon ? CORRECT_GUESS_COLOR : REF_PLOT_COLOR;
            drawStrainPlot(referenceStrainCtx, referenceStrainCanvas, referenceData.waves, 0, true, refPlotColor);
        }
    }
    if (typeof simulatedStrainCtx !== 'undefined' && activeSimData && activeSimData.waves) {
        drawStrainPlot(simulatedStrainCtx, simulatedStrainCanvas, activeSimData.waves, currentFrame > 0 ? currentFrame - 1 : 0, false, SIM_PLOT_COLOR);
    }
    
    // Toggle active state styling on language keys
    document.querySelectorAll('.lang-btn').forEach(btn => {
        if (btn.dataset.lang === lang) btn.classList.add('active');
        else btn.classList.remove('active');
    });
}

// --- IDLE "PLAY ME" NUDGE ---
// After this many ms without a parameter change or a "new signal" click, a
// flashing prompt appears in the bottom-centre slot (the same space the win
// dialog uses) with an arrow pointing at the properties panel.
const IDLE_HINT_DELAY_MS = 10000;
let idleHintTimer = null;

/* ── IDLE FRAME-RATE THROTTLE (REVIEW_issues.md #16) ────────────────────────
   After a longer period with no input at all, step the animation at ~15 fps
   instead of the full ~60. Deliberately a THROTTLE, not a pause: the orbiting black
   holes are the exhibit, and a frozen display reads as "crashed" to a
   passer-by. At 15 fps the motion still reads clearly from a few metres while
   cutting the per-second vertex and normal recomputation to about a quarter.

   Never active in EXPO MODE - the exhibit runs on mains power, gains nothing,
   and is the one place a regression is expensive. */
const IDLE_THROTTLE_MS = 30000;
const IDLE_FPS = 30;
let idleThrottleTimer = null;
let idleFrameTimer = null;
let animationThrottled = false;

/* Called on ANY user activity - pointer, key, wheel - which is a broader notion
   than the hint timer's "a game parameter changed", so reading an info popup or
   switching language also counts as being present. */
function resumeFullFrameRate() {
    if (EXPO_MODE) return;
    animationThrottled = false;
    if (idleThrottleTimer !== null) clearTimeout(idleThrottleTimer);
    idleThrottleTimer = setTimeout(() => { animationThrottled = true; }, IDLE_THROTTLE_MS);
}

/* Stops the render loop whichever way it is currently scheduled. The throttle
   uses setTimeout rather than rAF, so cancelAnimationFrame alone would leave a
   second loop running and the animation would speed up on every reload. */
function cancelAnimationLoop() {
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
    }
    if (idleFrameTimer !== null) {
        clearTimeout(idleFrameTimer);
        idleFrameTimer = null;
    }
}
let playHintEl = null;
let playHintTextEl = null;

function hidePlayHint() {
    if (playHintEl) playHintEl.classList.remove('visible');
}

function showPlayHint() {
    if (gameWon) return;            // Never compete with the win dialog
    if (playHintEl) playHintEl.classList.add('visible');
}

// Call on every user action: hides the hint immediately and restarts the clock.
function scheduleIdleHint() {
    if (idleHintTimer !== null) clearTimeout(idleHintTimer);
    idleHintTimer = null;
    hidePlayHint();
    if (gameWon) return;
    idleHintTimer = setTimeout(showPlayHint, IDLE_HINT_DELAY_MS);
}

// Call when the game is no longer active (win): hide and stop re-arming.
function cancelIdleHint() {
    if (idleHintTimer !== null) clearTimeout(idleHintTimer);
    idleHintTimer = null;
    hidePlayHint();
}

const NRDIGITS = 2;

let scene, camera, renderer;
let planeMesh, bh1Mesh, bh2Mesh; // Three.js objects
let animationFrameId;
let currentFrame = 0;
let N_FRAMES_SIM; // Total frames in the current simulation for the active selection

let slidersLocked = false;

// --- NEW: Pre-computation and UI State ---
let precomputedSimulations = {}; // Store all pre-calculated data
let activeSimData = null; // Data for the currently selected m1/e combination



// UI Elements for sliders and plots
//let m1Slider, eSlider;
let m1DotElements = []; // To store references to m1 dot DOM elements
let eDotElements = [];  // To store references to e dot DOM elements
let currentM1Index = 0; // Default to first M1 value (e.g., 5.0)
let currentEIndex = 0;   // Default to first E value (e.g., 0.5)

let simulatedStrainCanvas, simulatedStrainCtx;
let referenceStrainCanvas, referenceStrainCtx;
let randomReferenceChoice = { m1: null, e: null }; // To store the randomly chosen params for reference plot
let gameWon = false;
let simulatedSignalTitleEl;

// NEW: Modal UI Elements
let winToastEl, winToastNewGameButton;


// Constants
const PLANE_WIDTH = 30;
const BH_VISUAL_SCALE = 0.1;
const BH_Z_OFFSET = -0.1; // Slightly raise BHs above the plane


/*
function lockSliders() {
    slidersLocked = true;
    document.querySelectorAll('#sliders input').forEach(input => {
        input.disabled = true;
        input.style.opacity = 0.5;
    });
}
*/

// Discrete values for sliders
//const M1_VALUES = [1.0, 2.0, 3.0, 4.0, 5.0];
//const E_VALUES = [0.0, 0.1, 0.2,  0.3, 0.4,  0.5];
const M1_VALUES = [1.0, 1.66, 2.33, 3.0, 3.66, 4.33, 5.0];
const E_VALUES = [0.0, 0.083, 0.166, 0.249, 0.332, 0.415, 0.498];
const FIXED_M2 = 1.0;

// Base simulation parameters (m1, e will be set by sliders)
/* These five values must move TOGETHER. merger_frame, merger_width and
   frametotime are all expressed in frames, so changing N_frames alone would
   move the merger to a different point in the animation and change the physics
   on screen. The web preset below is the same simulation sampled more coarsely:
   merger at 70% of the run, total simulated time unchanged
   (1000 x 1/70 == 750 x 1/52.5).

   Measured cost of the full 49-combination precompute:
     EXPO  N=1000, grid=50 -> 1.06 GB, ~0.80 min
     WEB   N=750,  grid=40 -> 0.53 GB, ~0.30 min   (-50% memory, -63% time)

   See REVIEW_issues.md #1 / #2. */
const SIM_QUALITY = EXPO_MODE
    ? { N_frames: 1000, merger_frame: 700, merger_width: 50, frametotime: 1.0 / 70.0,  grid_size_calc: 50 }
    : { N_frames: 750,  merger_frame: 525, merger_width: 38, frametotime: 1.0 / 52.5,  grid_size_calc: 40 };

let baseSimParams = {
    N_frames: SIM_QUALITY.N_frames,
    merger_frame: SIM_QUALITY.merger_frame,
    merger_width: SIM_QUALITY.merger_width,
    frametotime: SIM_QUALITY.frametotime,
    grid_size_calc: SIM_QUALITY.grid_size_calc,
    scale_factor: 2.0,
    m2: FIXED_M2, // m2 is now fixed
    Comegatoa: 10.0,
    Cstrain: 1.0 / 10.0,
    amergefactor: 1.0,
    posfactor: 1.5
};

// DOM Elements for loading
let loadingMessageDiv, progressBarContainer, progressBar;


/* ── Reduced motion (REVIEW_issues.md #35) ──────────────────────────────────
   Mirrors the OS-level "reduce motion" accessibility setting, which people
   enable because moving or flashing content triggers migraine, nausea or
   seizures. When it is on we drop the confetti entirely and hold the 3D view on
   a single representative frame. Nothing is lost from the game itself: the
   strain plot always draws the COMPLETE waveform, and only the small crimson
   tracking dot depends on the frame counter. */
const reducedMotionQuery = (!EXPO_MODE && window.matchMedia)
    ? window.matchMedia('(prefers-reduced-motion: reduce)')
    : null;
// Expo: never consult the OS setting - the exhibit should always animate.
let prefersReducedMotion = reducedMotionQuery ? reducedMotionQuery.matches : false;

/* Late inspiral: tight orbit and strong ripples, so the frozen view is still
   worth looking at. Expressed relative to the merger so it survives parameter
   changes to baseSimParams. */
const REDUCED_MOTION_FRAME = Math.round(baseSimParams.merger_frame * 0.8);

if (reducedMotionQuery && reducedMotionQuery.addEventListener) {
    reducedMotionQuery.addEventListener('change', (event) => {
        prefersReducedMotion = event.matches;
        // Turning the setting back off should resume motion immediately.
        if (!prefersReducedMotion && activeSimData) {
            cancelAnimationLoop();
            animationFrameId = requestAnimationFrame(updateAnimation);
        }
    });
}

/* ── Confetti cannon (REVIEW_issues.md #15) ─────────────────────────
   canvas-confetti appends its canvas to <body>, which carries the viewport
   rescaler's transform: scale(). That scales and offsets the confetti with the
   app, so on any screen that is not exactly 1920x1080 it lands in the wrong
   place or is clipped. We give it our own canvas on <html> instead - the same
   trick the portrait overlay already uses to escape the transform. */
let confettiCannon = null;

function fireConfetti(options) {
    if (typeof confetti !== 'function') return;
    /* A sudden full-screen, high-contrast burst is the single most likely
       trigger in this app, so it is skipped outright rather than toned down. */
    if (prefersReducedMotion) return;

    if (!confettiCannon) {
        if (typeof confetti.create !== 'function') {
            confetti(options);   // Fallback: older build without .create()
            return;
        }
        const canvas = document.createElement('canvas');
        canvas.style.cssText = [
            'position:fixed', 'top:0', 'left:0',
            'width:100%', 'height:100%',
            'pointer-events:none', 'z-index:999998'
        ].join(';');
        document.documentElement.appendChild(canvas);
        confettiCannon = confetti.create(canvas, { resize: true, useWorker: true });
    }

    confettiCannon(options);
}

/* ── Startup failure surface (REVIEW_issues.md #5) ──────────────────────────
   Swaps the loading spinner for an actionable error instead of leaving the
   progress bar frozen forever. English only: this is an operator message. */
function showFatalError(error) {
    console.error('GW Hunter: fatal startup error', error);

    const progressBar = document.getElementById('progress-bar-container');
    const loadingText = document.getElementById('loading-text');
    const errorBlock  = document.getElementById('loading-error');
    const errorDetail = document.getElementById('loading-error-detail');
    const reloadBtn   = document.getElementById('loading-error-reload');
    const loadingDiv  = document.getElementById('loading-message');

    if (loadingDiv)  loadingDiv.style.display = 'flex';
    if (progressBar) progressBar.style.display = 'none';
    if (loadingText) loadingText.style.display = 'none';
    if (errorDetail) errorDetail.textContent = (error && (error.stack || error.message)) || String(error);
    if (errorBlock)  errorBlock.classList.add('active');
    if (reloadBtn)   reloadBtn.addEventListener('click', () => window.location.reload());
}

/* ── WebGL availability (REVIEW_issues.md #6) ───────────────────────────────
   If the 3D view cannot start we degrade to a 2D-only game rather than dying:
   the two strain plots are plain canvas and are all the game strictly needs. */
let webglAvailable = true;

function showSceneFallback(container) {
    if (!container) return;
    container.innerHTML =
        '<div id="scene-fallback">3D view unavailable on this device.<br>' +
        'The game still works - match the two wave plots.</div>';
}

function initThreeScene(Xgrid, Ygrid, Zs_initial) {
    const container = document.getElementById('scene-container');
    container.innerHTML = '';

    try {
        return initThreeSceneUnsafe(container, Xgrid, Ygrid, Zs_initial);
    } catch (err) {
        console.error('WebGL initialisation failed; continuing without the 3D view.', err);
        webglAvailable = false;
        planeMesh = null;
        showSceneFallback(container);
    }
}

function initThreeSceneUnsafe(container, Xgrid, Ygrid, Zs_initial) {

    //const viewWidth = Math.min(window.innerWidth * 0.45, 550); // Adjusted for side-by-side layout
    //const viewHeight = viewWidth * (5/8);
    const viewWidth = 800; // Adjusted for side-by-side layout
    //const viewHeight = viewWidth * (5/8);
    const viewHeight = viewWidth * (5/8);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true }); // alpha for potentially transparent bg
    renderer.setSize(viewWidth, viewHeight);
    //renderer.setClearColor(0xffffff, 1); // White background
    renderer.setClearColor(BACKGROUND_COLOR, 1);
    container.appendChild(renderer.domElement);

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(45, viewWidth / viewHeight, 0.1, 1000); //45
    camera.position.set(20, 20, 20);
    camera.lookAt(0, 0, 0);

    const ambientLight = new THREE.AmbientLight(0xcccccc, 0.6);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.9);
    directionalLight.position.set(1, 1.5, 0.5).normalize();
    scene.add(directionalLight);

    const segmentsX = Xgrid[0].length - 1;
    const segmentsY = Xgrid.length - 1;
    const planeGeometry = new THREE.PlaneGeometry(PLANE_WIDTH, PLANE_WIDTH, segmentsX, segmentsY);
    
    const vertices = planeGeometry.attributes.position.array;
    for (let i = 0, l = vertices.length / 3; i < l; i++) {
        const u = (vertices[i * 3] / PLANE_WIDTH) + 0.5;
        const v = 1 - ((vertices[i * 3 + 1] / PLANE_WIDTH) + 0.5);
        const x_idx = Math.min(segmentsX, Math.max(0, Math.floor(u * segmentsX)));
        const y_idx = Math.min(segmentsY, Math.max(0, Math.floor(v * segmentsY)));
        const z0 = zAt(Zs_initial, y_idx, x_idx, segmentsX + 1);
        if (z0 !== undefined) {
             vertices[i * 3 + 2] = z0 * 2;
        } else {
             vertices[i * 3 + 2] = 0;
        }
    }
    planeGeometry.attributes.position.needsUpdate = true;
    planeGeometry.computeVertexNormals();

    const planeMaterial = new THREE.MeshStandardMaterial({
        color: GRID_COLOR,
        wireframe: true,
        opacity: 0.85,
        transparent: true,
        side: THREE.DoubleSide
    });
    planeMesh = new THREE.Mesh(planeGeometry, planeMaterial);
    planeMesh.rotation.x = -Math.PI / 2;
    scene.add(planeMesh);

    const bhMaterial = new THREE.MeshStandardMaterial({ color: 0x000000 });
    const bh1Geometry = new THREE.SphereGeometry(1, 24, 12); // Slightly reduced segments
    bh1Mesh = new THREE.Mesh(bh1Geometry, bhMaterial);
    scene.add(bh1Mesh);

    const bh2Geometry = new THREE.SphereGeometry(1, 24, 12);
    bh2Mesh = new THREE.Mesh(bh2Geometry, bhMaterial);
    scene.add(bh2Mesh);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableZoom = false;
    controls.enabled = false;
    controls.target.set(0,0,0);
    const radius = 35; // Slightly closer view
    const elevRad = 25 * Math.PI / 180; // Adjusted view
    const azimRad = 230 * Math.PI / 180; // Adjusted view
    camera.position.x = radius * Math.cos(elevRad) * Math.cos(azimRad);
    camera.position.y = radius * Math.sin(elevRad);
    camera.position.z = radius * Math.cos(elevRad) * Math.sin(azimRad);
    camera.lookAt(0, 0, 0);
    //controls.minPolarAngle=controls.maxPolarAngle=elevRad;
    //controls.minAzimuthAngle = controls.maxAzimuthAngle = azimRad;
    controls.update();
}

function initStrainPlotCanvases() {
    const simContainer = document.getElementById('simulated-strain-plot-container');
    simContainer.innerHTML = '';
    const refContainer = document.getElementById('reference-strain-plot-container');
    refContainer.innerHTML = '';
    
    //const plotWidth = Math.min(window.innerWidth * 0.4, 400); // Adjusted for side-by-side
    //const plotHeight = plotWidth * 0.5;
    const plotWidth = Math.min(window.innerWidth * 0.5, 400); // Adjusted for side-by-side
    const plotHeight = plotWidth * 0.3;

    simulatedStrainCanvas = document.createElement('canvas');
    simulatedStrainCanvas.width = plotWidth;
    simulatedStrainCanvas.height = plotHeight;
    simContainer.appendChild(simulatedStrainCanvas);
    simulatedStrainCtx = simulatedStrainCanvas.getContext('2d');

    referenceStrainCanvas = document.createElement('canvas');
    referenceStrainCanvas.width = plotWidth;
    referenceStrainCanvas.height = plotHeight;
    refContainer.appendChild(referenceStrainCanvas);
    referenceStrainCtx = referenceStrainCanvas.getContext('2d');
}

function drawStrainPlot(ctx, canvas, wavesData, currentFrameIndex, isStatic = false, lineColor = SIM_PLOT_COLOR) {
    if (!ctx || !wavesData || wavesData.length === 0) return;

    const width = canvas.width;
    const height = canvas.height;
    const padding = 30;

    ctx.fillStyle = BACKGROUND_COLOR;
    ctx.fillRect(0, 0, width, height);
    // No border for individual plots, wrapper has border
    
    const dataMin = Math.min(...wavesData);
    const dataMax = Math.max(...wavesData);
    let range = dataMax - dataMin;
    if (Math.abs(range) < 1e-9) range = 1; // Avoid division by zero if data is flat

    const plotableWidth = width - 2 * padding;
    const plotableHeight = height - 2 * padding;

    ctx.strokeStyle =AXIS_TEXT_COLOR; 
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 1.5; // former 1.5
    ctx.beginPath();
    for (let i = 0; i < wavesData.length; i++) {
        const x = padding + (i / (wavesData.length - 1)) * plotableWidth;
        const y = (height - padding) - ((wavesData[i] - dataMin) / range) * plotableHeight;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    }
    ctx.stroke();

    if (!isStatic && currentFrameIndex < wavesData.length) {
        const xDot = padding + (currentFrameIndex / (wavesData.length - 1)) * plotableWidth;
        const yDot = (height - padding) - ((wavesData[currentFrameIndex] - dataMin) / range) * plotableHeight;
        ctx.fillStyle = 'crimson';
        ctx.beginPath();
        ctx.arc(xDot, yDot, 6, 0, 2 * Math.PI);
        ctx.fill();
    }
    
    ctx.fillStyle = AXIS_TEXT_COLOR; 
    ctx.font = '10px Arial'; 
    ctx.textAlign = 'center';
    ctx.fillText(translations[currentLang].axis_time, width / 2, height - padding / 4);
    ctx.save();
    ctx.translate(padding / 3, height / 2); 
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(translations[currentLang].axis_signal, 0, 0);
    ctx.restore();
}

function updateAnimation() {
   // if (!activeSimData || currentFrame >= N_FRAMES_SIM) {
    //    if (animationFrameId) cancelAnimationFrame(animationFrameId);
   //     return;
   // }
   if (!activeSimData || currentFrame >= N_FRAMES_SIM) {
        currentFrame = 0;
   }

   /* Reduced motion: pin to one representative frame instead of animating. */
   if (prefersReducedMotion) {
        currentFrame = Math.min(REDUCED_MOTION_FRAME, N_FRAMES_SIM - 1);
   }

    const frameData = {
        bh1_pos: activeSimData.bh_positions[currentFrame].bh1_pos,
        bh2_pos: activeSimData.bh_positions[currentFrame].bh2_pos,
        bh1_size: activeSimData.bh_sizes1[currentFrame],
        bh2_size: activeSimData.bh_sizes2[currentFrame],
        Zs: activeSimData.Zs_grids[currentFrame]
    };

    /* 3D block is skipped entirely when WebGL is unavailable; the strain plot
       below still runs, so the game stays playable. See REVIEW_issues.md #6. */
    if (webglAvailable && planeMesh && planeMesh.geometry) {
        const vertices = planeMesh.geometry.attributes.position.array;
        const segmentsX = planeMesh.geometry.parameters.widthSegments;
        const segmentsY = planeMesh.geometry.parameters.heightSegments;

        for (let i = 0, l = vertices.length / 3; i < l; i++) {
            const u = (vertices[i * 3] / PLANE_WIDTH) + 0.5;
            const v = 1 - ((vertices[i * 3 + 1] / PLANE_WIDTH) + 0.5);
            const x_idx = Math.min(segmentsX, Math.max(0, Math.floor(u * segmentsX)));
            const y_idx = Math.min(segmentsY, Math.max(0, Math.floor(v * segmentsY)));
            const zf = zAt(frameData.Zs, y_idx, x_idx, segmentsX + 1);
            if (zf !== undefined) {
                vertices[i * 3 + 2] = zf * 2;
            } else {
                 vertices[i * 3 + 2] = 0;
            }
        }
        planeMesh.geometry.attributes.position.needsUpdate = true;
        planeMesh.geometry.computeVertexNormals();

        bh1Mesh.position.set(frameData.bh1_pos[0], BH_Z_OFFSET, frameData.bh1_pos[1]);
        const bh1Scale = frameData.bh1_size * BH_VISUAL_SCALE;
        bh1Mesh.scale.set(bh1Scale, bh1Scale, bh1Scale);

        bh2Mesh.position.set(frameData.bh2_pos[0], BH_Z_OFFSET, frameData.bh2_pos[1]);
        const bh2Scale = frameData.bh2_size * BH_VISUAL_SCALE;
        bh2Mesh.scale.set(bh2Scale, bh2Scale, bh2Scale);

        renderer.render(scene, camera);
    }

    drawStrainPlot(simulatedStrainCtx, simulatedStrainCanvas, activeSimData.waves, currentFrame, false, SIM_PLOT_COLOR);

    /* Render one frame and stop. Every parameter change calls
       loadSimulationDataForCurrentSettings(), which re-arms the loop, so the
       view still updates on interaction - it just does not animate by itself. */
    if (prefersReducedMotion) {
        animationFrameId = null;
        return;
    }

    currentFrame++;

    /* Idle: hand the next frame to a timer instead of rAF (#16). */
    if (animationThrottled) {
        animationFrameId = null;
        idleFrameTimer = setTimeout(() => {
            idleFrameTimer = null;
            animationFrameId = requestAnimationFrame(updateAnimation);
        }, 1000 / IDLE_FPS);
        return;
    }

    animationFrameId = requestAnimationFrame(updateAnimation);
}

function showWinToast() {
    if (winToastEl) {
        // Optionally update toast text here if needed, e.g., with specific m1/e values
        // document.getElementById('win-toast-message').textContent = `Je vond m1=${randomReferenceChoice.m1.toFixed(NRDIGITS)}, e=${randomReferenceChoice.e.toFixed(NRDIGITS)}!`;
        winToastEl.style.display = 'flex';
    }
}

function hideWinToast() {
    if (winToastEl) {
        winToastEl.style.display = 'none';
    }
}

function calculateMatchPercentage() {

    const currentM1 = M1_VALUES[currentM1Index];
    const currentE = E_VALUES[currentEIndex];

    const targetM1 = randomReferenceChoice.m1;
    const targetE = randomReferenceChoice.e;

    // Calculate m1 match (50 points)
    const m1TargetIndex = M1_VALUES.indexOf(targetM1);
    const m1MaxDistance = M1_VALUES.length - 1; // Max index distance
    const m1CurrentDistance = Math.abs(currentM1Index - m1TargetIndex);
    let m1Score = 0;
    if (m1MaxDistance > 0) {
        m1Score = 50 * (1 - (m1CurrentDistance / m1MaxDistance));
    } else if (m1CurrentDistance === 0) { // Only one option, and it's a match
        m1Score = 50;
    }
    m1Score = Math.max(0, m1Score); // Ensure score is not negative

    // Calculate e match (50 points)
    const eTargetIndex = E_VALUES.indexOf(targetE);
    const eMaxDistance = E_VALUES.length - 1;
    const eCurrentDistance = Math.abs(currentEIndex - eTargetIndex);
    let eScore = 0;
    if (eMaxDistance > 0) {
        eScore = 50 * (1 - (eCurrentDistance / eMaxDistance));
    } else if (eCurrentDistance === 0) { // Only one option, and it's a match
        eScore = 50;
    }
    eScore = Math.max(0, eScore); // Ensure score is not negative

    const totalMatch = Math.round(m1Score + eScore);
    return totalMatch;
}

function updateSimulatedSignalTitle() {
    if (!simulatedSignalTitleEl) return;
    const matchPercentage = calculateMatchPercentage();

    /* NOTE - "warmer/colder" match feedback is intentionally parked, not broken.
       calculateMatchPercentage() above is still maintained and correct; only the
       display is disabled. See REVIEW_issues.md #8.

       !! TRANSLATION DEBT !! The disabled line below hardcodes a Dutch string.
       Before reinstating it, add a key to `translations` for all four languages
       (nl/en/fr/de) and build the label from translations[currentLang], e.g.
           `${translations[currentLang].your_signal} - ${matchPercentage}%`
       Do not re-enable it as-is: FR/EN/DE users would see Dutch. */
    //simulatedSignalTitleEl.textContent = `Jouw Signaal (Simulatie) - ${matchPercentage}% match`;

    simulatedSignalTitleEl.textContent = translations[currentLang].simulated_wave;
}

function handleCorrectGuess() {
    gameWon = true;
    /* Locked: take the tracks out of the tab order and mark them disabled so a
       keyboard user is not left tabbing into controls that ignore them (#33). */
    [document.getElementById('m1-dots-container'), document.getElementById('e-dots-container')]
        .forEach(track => {
            if (!track) return;
            track.setAttribute('tabindex', '-1');
            track.setAttribute('aria-disabled', 'true');
        });
    cancelIdleHint();   // Game is over - the bottom slot belongs to the win dialog now
    m1DotElements.forEach(dot => dot.classList.add('locked'));
    eDotElements.forEach(dot => dot.classList.add('locked'));
    m1DotElements[currentM1Index].classList.add('active');
    eDotElements[currentEIndex].classList.add('active');
    
    showWinToast();
    updateSimulatedSignalTitle();

    const refKey = `m1_${randomReferenceChoice.m1.toFixed(NRDIGITS)}_e_${randomReferenceChoice.e.toFixed(NRDIGITS)}`;
    const referenceData = precomputedSimulations[refKey];
    if (referenceData) {
        drawStrainPlot(referenceStrainCtx, referenceStrainCanvas, referenceData.waves, 0, true, CORRECT_GUESS_COLOR);
    }

    // Confetti explosion from the center of the viewport
    fireConfetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.6 } // Explodes just above the center of the viewport
    });

    // Confetti side-cannon stream that lasts for 3.5 seconds
    var duration = 3.5 * 1000;
    var animationEnd = Date.now() + duration;

    (function frame() {
    // Left side stream
    fireConfetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 }
    });
    // Right side stream
    fireConfetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 }
    });

    if (Date.now() < animationEnd) {
        requestAnimationFrame(frame);
    }
    }());

    // Make "new signal" buttons start flashing
    const resetBtn = document.getElementById('resetBtn');
    const winToastNewGameBtn = document.getElementById('win-toast-new-game-button');
    if (resetBtn) resetBtn.classList.add('flash-celebration');
    if (winToastNewGameBtn) winToastNewGameBtn.classList.add('flash-celebration');

    }

function loadSimulationDataForCurrentSettings() {
    // Single choke point for every user-driven change (dot click, drag, reset,
    // initial load), so the idle clock restarts here.
    scheduleIdleHint();

    cancelAnimationLoop();
    currentFrame = 0;

    //const selectedM1 = M1_VALUES[parseInt(m1Slider.value)];
    //const selectedE = E_VALUES[parseInt(eSlider.value)];
    const selectedM1 = M1_VALUES[currentM1Index];
    const selectedE = E_VALUES[currentEIndex];

    updateSimulatedSignalTitle();

    const key = `m1_${selectedM1.toFixed(NRDIGITS)}_e_${selectedE.toFixed(NRDIGITS)}`;
    const nextSimData = precomputedSimulations[key];

    /* An exhibit must never raise a native dialog: on a kiosk without a keyboard
       it can be impossible to dismiss. If a key is somehow missing we log it and
       keep the previous simulation running, so the app stays alive and playable.
       See REVIEW_issues.md #25. */
    if (!nextSimData) {
        console.error(`No precomputed data for m1=${selectedM1}, e=${selectedE}. Keeping previous simulation.`);
        animationFrameId = requestAnimationFrame(updateAnimation);
        return;
    }
    activeSimData = nextSimData;
    
    N_FRAMES_SIM = activeSimData.Zs_grids.length; // or baseSimParams.N_frames

    // Update 3D scene with the first frame of the new data
    const initial_Zs = activeSimData.Zs_grids[0] || createMatrix(baseSimParams.grid_size_calc, baseSimParams.grid_size_calc, 0);
    // Re-initialize or update scene if Xgrid/Ygrid changed (they don't in this setup per simulation)
    // For now, assuming Xgrid/Ygrid structure is constant for the plane geometry
    
    // If planeMesh exists, just update its vertices, otherwise init scene
    if (planeMesh && planeMesh.geometry) {
         const vertices = planeMesh.geometry.attributes.position.array;
         const segmentsX = planeMesh.geometry.parameters.widthSegments;
         const segmentsY = planeMesh.geometry.parameters.heightSegments;
         for (let i = 0, l = vertices.length / 3; i < l; i++) {
            const u = (vertices[i * 3] / PLANE_WIDTH) + 0.5;
            const v = 1 - ((vertices[i * 3 + 1] / PLANE_WIDTH) + 0.5);
            const x_idx = Math.min(segmentsX, Math.max(0, Math.floor(u * segmentsX)));
            const y_idx = Math.min(segmentsY, Math.max(0, Math.floor(v * segmentsY)));
            const zi = zAt(initial_Zs, y_idx, x_idx, segmentsX + 1);
            if (zi !== undefined) {
                vertices[i * 3 + 2] = zi * 2;
            } else {
                vertices[i * 3 + 2] = 0;
            }
        }
        planeMesh.geometry.attributes.position.needsUpdate = true;
        planeMesh.geometry.computeVertexNormals();
    } else if (webglAvailable) {
        // This case should ideally not be hit after initial setup unless scene is destroyed
        const x_calc = linspace(-15, 15, baseSimParams.grid_size_calc);
        const y_calc = linspace(-15, 15, baseSimParams.grid_size_calc);
        const { X: Xgrid_calc, Y: Ygrid_calc } = meshgrid(x_calc, y_calc);
        initThreeScene(Xgrid_calc, Ygrid_calc, initial_Zs);
    }


    animationFrameId = requestAnimationFrame(updateAnimation);

    // Check for win condition after loading new data
    if (!gameWon) { // Only check if game not already won
        // Floats need careful comparison
        if (Math.abs(selectedM1 - randomReferenceChoice.m1) < 1e-5 && 
            Math.abs(selectedE - randomReferenceChoice.e) < 1e-5) {
            handleCorrectGuess();
        }
    }
}

async function precomputeAllSimulations() {
    loadingMessageDiv.style.display = 'flex'; // Assuming flex for centering content
    progressBarContainer.style.display = 'block';
    progressBar.style.width = '0%';
    progressBar.textContent = '0%';

    const totalSimulations = M1_VALUES.length * E_VALUES.length;
    let simulationsDone = 0;

    const x_calc = linspace(-15, 15, baseSimParams.grid_size_calc);
    const y_calc = linspace(-15, 15, baseSimParams.grid_size_calc);
    const { X: Xgrid_calc, Y: Ygrid_calc } = meshgrid(x_calc, y_calc);

    for (const m1 of M1_VALUES) {
        for (const e of E_VALUES) {
            const currentSimParams = {
                ...baseSimParams,
                m1: m1,
                e: e,
                Xgrid: Xgrid_calc, // Pass the pre-calculated grid
                Ygrid: Ygrid_calc
            };
            
            // Yield to browser for UI updates if many calculations
            await new Promise(resolve => setTimeout(resolve, 0)); 

            const data = calculateAllFramesData(currentSimParams);
            const key = `m1_${m1.toFixed(NRDIGITS)}_e_${e.toFixed(NRDIGITS)}`;
            precomputedSimulations[key] = data;
            
            simulationsDone++;
            const progress = Math.round((simulationsDone / totalSimulations) * 100);
            progressBar.style.width = `${progress}%`;
            progressBar.textContent = `${progress}%`;
            console.log(`Precomputed: ${key} (${simulationsDone}/${totalSimulations})`);
        }
    }
    /* The initial target is chosen by selectNewRandomReference(), called from the
       DOMContentLoaded handler right after this function returns. Do not
       duplicate the selection logic here - see REVIEW_issues.md #31. */

    loadingMessageDiv.style.display = 'none';
    progressBarContainer.style.display = 'none';
}

function selectNewRandomReference() {
    const randomM1Index = Math.floor(Math.random() * M1_VALUES.length);
    let randomEIndex;
    if (randomM1Index==0) {
        randomEIndex = Math.floor(Math.random() * (E_VALUES.length-1))+1; // check to make sure we don't get m1=1 and e=0 from the start
    }
    else {
        randomEIndex = Math.floor(Math.random() * E_VALUES.length);
    }
    randomReferenceChoice.m1 = M1_VALUES[randomM1Index];
    randomReferenceChoice.e = E_VALUES[randomEIndex]; 
    //DEBUG WIN HERE
    //randomReferenceChoice.m1 = M1_VALUES[0]; // Force m1 for testing
    //randomReferenceChoice.e = E_VALUES[1]; // Force e for testing

    console.log("Nieuw doel signaal parameters (geheim):", randomReferenceChoice);

    const refKey = `m1_${randomReferenceChoice.m1.toFixed(NRDIGITS)}_e_${randomReferenceChoice.e.toFixed(NRDIGITS)}`;
    const referenceData = precomputedSimulations[refKey];
    if (referenceData) {
        drawStrainPlot(referenceStrainCtx, referenceStrainCanvas, referenceData.waves, 0, true, REF_PLOT_COLOR); 
    }
}

function setupDotSelectors() {
    const m1DotsContainer = document.getElementById('m1-dots-container');
    const eDotsContainer = document.getElementById('e-dots-container');
    m1DotElements = []; 
    eDotElements = [];

    M1_VALUES.forEach((value, index) => {
        const dot = document.createElement('div');
        dot.classList.add('value-dot');
        dot.dataset.index = index;
        m1DotsContainer.appendChild(dot);
        m1DotElements.push(dot);
    });

    E_VALUES.forEach((value, index) => {
        const dot = document.createElement('div');
        dot.classList.add('value-dot');
        dot.dataset.index = index;
        eDotsContainer.appendChild(dot);
        eDotElements.push(dot);
    });

    // Interaction lives on the track, not the individual dots, so a click
    // anywhere along the line snaps to the nearest value.
    setupTrackInteraction(m1DotsContainer, m1DotElements, 'm1');
    setupTrackInteraction(eDotsContainer, eDotElements, 'e');

    updateActiveDots();
}

/* Returns the index of the dot whose centre is vertically closest to clientY.
   Uses getBoundingClientRect so it stays correct under the body's scale
   transform and regardless of the track's column-reverse ordering. */
function nearestDotIndex(dotElements, clientY) {
    let bestIndex = 0;
    let bestDistance = Infinity;
    dotElements.forEach((dot, index) => {
        const rect = dot.getBoundingClientRect();
        const distance = Math.abs((rect.top + rect.bottom) / 2 - clientY);
        if (distance < bestDistance) {
            bestDistance = distance;
            bestIndex = index;
        }
    });
    return bestIndex;
}

/* Makes the whole track act like a slider: press anywhere to snap to the
   nearest dot, and keep dragging to move between values. No new values are
   introduced - the pointer is always quantised to an existing dot. */
function setupTrackInteraction(container, dotElements, paramType) {
    if (!container) return;

    /* Expose the track as a real slider to assistive tech and make it focusable.
       aria-label is set per language in updateLanguageUI(); the value attributes
       are kept in sync by updateTrackAria() from updateActiveDots().
       See REVIEW_issues.md #33. */
    container.setAttribute('role', 'slider');
    container.setAttribute('aria-orientation', 'vertical');
    container.setAttribute('tabindex', '0');
    container.setAttribute('aria-valuemin', '1');
    container.setAttribute('aria-valuemax', String(dotElements.length));

    /* Arrow keys step one value, Page keys two, Home/End jump to the ends.
       The track renders column-reverse, so index 0 is at the BOTTOM - Up must
       therefore increase the index, matching what the user sees. */
    container.addEventListener('keydown', (event) => {
        if (gameWon) return;

        const last = dotElements.length - 1;
        const currentIndex = (paramType === 'm1') ? currentM1Index : currentEIndex;
        let nextIndex = currentIndex;

        switch (event.key) {
            case 'ArrowUp':
            case 'ArrowRight': nextIndex = Math.min(last, currentIndex + 1); break;
            case 'ArrowDown':
            case 'ArrowLeft':  nextIndex = Math.max(0, currentIndex - 1); break;
            case 'PageUp':     nextIndex = Math.min(last, currentIndex + 2); break;
            case 'PageDown':   nextIndex = Math.max(0, currentIndex - 2); break;
            case 'Home':       nextIndex = 0; break;
            case 'End':        nextIndex = last; break;
            default: return;   // Leave every other key to the browser
        }

        event.preventDefault();   // Stop arrow keys from scrolling the page
        if (nextIndex !== currentIndex) {
            handleValueSelect(paramType, nextIndex);
        } else {
            scheduleIdleHint();   // Key press at an end stop still counts as activity
        }
    });

    let dragging = false;

    const snapTo = (clientY) => {
        if (gameWon) return;
        const index = nearestDotIndex(dotElements, clientY);
        const currentIndex = (paramType === 'm1') ? currentM1Index : currentEIndex;
        if (index === currentIndex) {
            scheduleIdleHint();   // Still counts as activity, so restart the nudge clock
            return;
        }
        handleValueSelect(paramType, index);
    };

    container.addEventListener('pointerdown', (event) => {
        if (gameWon) return;
        dragging = true;
        // Capture so the drag keeps tracking even if the pointer leaves the track
        if (container.setPointerCapture) container.setPointerCapture(event.pointerId);
        snapTo(event.clientY);
        event.preventDefault();   // Suppresses text selection / touch scrolling
    });

    container.addEventListener('pointermove', (event) => {
        if (!dragging) return;
        snapTo(event.clientY);
    });

    const endDrag = (event) => {
        if (!dragging) return;
        dragging = false;
        if (container.hasPointerCapture && container.hasPointerCapture(event.pointerId)) {
            container.releasePointerCapture(event.pointerId);
        }
    };

    container.addEventListener('pointerup', endDrag);
    container.addEventListener('pointercancel', endDrag);
}

function handleValueSelect(paramType, index) {
    if (gameWon) return; 

    if (paramType === 'm1') {
        currentM1Index = index;
    } else if (paramType === 'e') {
        currentEIndex = index;
    }
    updateActiveDots();
    loadSimulationDataForCurrentSettings();
}

/* Screen readers announce "3 of 7" rather than the raw physical value, which is
   meaningless to a visitor. */
function updateTrackAria(container, index, total) {
    if (!container) return;
    container.setAttribute('aria-valuenow', String(index + 1));
    container.setAttribute('aria-valuetext', `${index + 1} / ${total}`);
}

function updateActiveDots() {
    m1DotElements.forEach((dot, idx) => {
        dot.classList.toggle('active', idx === currentM1Index);
    });
    eDotElements.forEach((dot, idx) => {
        dot.classList.toggle('active', idx === currentEIndex);
    });
    updateTrackAria(document.getElementById('m1-dots-container'), currentM1Index, M1_VALUES.length);
    updateTrackAria(document.getElementById('e-dots-container'), currentEIndex, E_VALUES.length);
}

function resetGameAndSim() {
    hideWinToast(); // Hide the win toast if it is showing
    gameWon = false;

    [document.getElementById('m1-dots-container'), document.getElementById('e-dots-container')]
        .forEach(track => {
            if (!track) return;
            track.setAttribute('tabindex', '0');
            track.removeAttribute('aria-disabled');
        });
    
    m1DotElements.forEach(dot => dot.classList.remove('locked', 'active'));
    eDotElements.forEach(dot => dot.classList.remove('locked', 'active'));
    
    currentM1Index = 0; 
    currentEIndex = 0;
    updateActiveDots();

    // stop flashing of reset buttons
    const resetBtn = document.getElementById('resetBtn');
    const winToastNewGameBtn = document.getElementById('win-toast-new-game-button');
    if (resetBtn) resetBtn.classList.remove('flash-celebration');
    if (winToastNewGameBtn) winToastNewGameBtn.classList.remove('flash-celebration');

    selectNewRandomReference(); 
    loadSimulationDataForCurrentSettings(); 
}


function setupControls() {
    resetBtn = document.getElementById('resetBtn');
    simulatedSignalTitleEl = document.getElementById('simulated-signal-title');

    // Idle hint elements
    playHintEl = document.getElementById('play-hint');
    playHintTextEl = document.getElementById('play-hint-text');

    // Modal elements
    winToastEl = document.getElementById('win-toast');
    winToastNewGameButton = document.getElementById('win-toast-new-game-button');

    setupDotSelectors(); 

    resetBtn.addEventListener('click', resetGameAndSim);

    // Modal event listeners
    if(winToastNewGameButton) winToastNewGameButton.addEventListener('click', () => {
        hideWinToast();
        resetGameAndSim(); // Also reset the game
    });
    /* No click-to-dismiss listener here: .win-toast has pointer-events:none, so
       clicks pass straight through and the handler could never fire. This is a
       toast, not a modal - the only way out is the "new signal" button.
       See REVIEW_issues.md #32. */

    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const selectedLang = btn.dataset.lang;
            updateLanguageUI(selectedLang);
        });
    });

    /* Idle frame-rate throttle (#16). Listening at document level catches
       everything - sliders, buttons, info popups, the language switcher - which
       is what "is anyone there?" should mean. Passive listeners, so this cannot
       interfere with the slider's own pointer handling. No-op in EXPO MODE. */
    if (!EXPO_MODE) {
        ['pointerdown', 'pointermove', 'keydown', 'wheel'].forEach((eventName) => {
            document.addEventListener(eventName, resumeFullFrameRate, { passive: true });
        });
        resumeFullFrameRate();   // Arm the clock for the first idle period
    }

    // Run basic initialization to setup class list alignments
    updateLanguageUI(currentLang);
}


document.addEventListener('DOMContentLoaded', async () => {
    loadingMessageDiv = document.getElementById('loading-message');
    progressBarContainer = document.getElementById('progress-bar-container');
    progressBar = document.getElementById('progress-bar');

    /* Selawik load check (REVIEW_issues.md #28).
       The font is embedded in fonts.css as a data: URI precisely so that CORS
       cannot block it when the page is opened from disk rather than served, so
       this should always pass now. Kept as a cheap regression alarm: if anyone
       later reverts fonts.css to url('selawk.ttf'), or drops the file when
       copying the folder, the layout would quietly shift to system fonts and
       this is the only thing that would say so.
       Console-only: a technician's signal, not visitor-facing. */
    if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => {
            if (document.fonts.check('700 16px Selawik')) {
                console.log('Selawik loaded - layout is metric-locked to the design.');
            } else {
                console.warn(
                    'Selawik did NOT load: falling back to system fonts, so text ' +
                    'widths may differ from the design. Check that fonts.css is ' +
                    'present, is linked before style.css, and still embeds the ' +
                    'font as a data: URI rather than url(selawk.ttf).'
                );
            }
        });
    }

    /* Whole startup sequence is guarded so a throw anywhere cannot leave the
       loading screen frozen with no explanation. See REVIEW_issues.md #5.
       (initThreeScene has its own inner catch and degrades to 2D - a missing
       3D view is not fatal, so it must not reach this handler.) */
    try {
        setupControls();
        initStrainPlotCanvases();

        const placeholderX = linspace(-15, 15, baseSimParams.grid_size_calc);
        const placeholderY = linspace(-15, 15, baseSimParams.grid_size_calc);
        const { X: pX, Y: pY } = meshgrid(placeholderX, placeholderY);
        const placeholderZ = createMatrix(baseSimParams.grid_size_calc, baseSimParams.grid_size_calc, 0);
        initThreeScene(pX, pY, placeholderZ);
        drawStrainPlot(simulatedStrainCtx, simulatedStrainCanvas, [], 0, false);

        await precomputeAllSimulations();

        selectNewRandomReference();
        loadSimulationDataForCurrentSettings();
    } catch (err) {
        showFatalError(err);
    }
});

window.addEventListener('resize', () => {
    let plotWidth, plotHeight; 
    if (camera && renderer) {
        const container = document.getElementById('scene-container');
        // Ensure container is not null and has dimensions
        if (container && container.clientWidth > 0 && container.clientHeight > 0) {
            const viewWidth = container.clientWidth; // Use actual container width
            const viewHeight = container.clientHeight; // Use actual container height
            
            camera.aspect = viewWidth / viewHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(viewWidth, viewHeight);
        } else { // Fallback if container dimensions are not yet set or are zero
            const fallbackViewWidth = Math.min(window.innerWidth * 0.45, 700);
            const fallbackViewHeight = fallbackViewWidth * (9/16);
            camera.aspect = fallbackViewWidth / fallbackViewHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(fallbackViewWidth, fallbackViewHeight);
        }
    }
    
    // For strain plots, use a consistent reference for width calculation
    const referencePlotContainer = document.getElementById('reference-strain-plot-container');
    if (referencePlotContainer) {
        plotWidth = referencePlotContainer.clientWidth || Math.min(window.innerWidth * 0.35, 420);
    } else {
        plotWidth = Math.min(window.innerWidth * 0.35, 420); // Fallback
    }
    plotHeight = plotWidth * 0.45;


    if (simulatedStrainCanvas) {
         simulatedStrainCanvas.width = plotWidth;
         simulatedStrainCanvas.height = plotHeight;
         if (activeSimData && activeSimData.waves) {
            drawStrainPlot(simulatedStrainCtx, simulatedStrainCanvas, activeSimData.waves, currentFrame > 0 ? currentFrame -1 : 0, false, SIM_PLOT_COLOR);
         } else {
            drawStrainPlot(simulatedStrainCtx, simulatedStrainCanvas, [], 0, false, SIM_PLOT_COLOR);
         }
    }

    if (referenceStrainCanvas && precomputedSimulations) { 
        referenceStrainCanvas.width = plotWidth;
        referenceStrainCanvas.height = plotHeight;
        const refKey = `m1_${randomReferenceChoice.m1.toFixed(NRDIGITS)}_e_${randomReferenceChoice.e.toFixed(NRDIGITS)}`;
        const referenceData = precomputedSimulations[refKey];
        if (referenceData && referenceData.waves) {
            const refPlotColor = gameWon ? CORRECT_GUESS_COLOR : REF_PLOT_COLOR;
            drawStrainPlot(referenceStrainCtx, referenceStrainCanvas, referenceData.waves, 0, true, refPlotColor);
        } else {
             drawStrainPlot(referenceStrainCtx, referenceStrainCanvas, [], 0, true, REF_PLOT_COLOR);
        }
    }
}, false);

if (typeof THREE.OrbitControls === 'undefined') {
    console.error("THREE.OrbitControls is not defined. Ensure it's loaded correctly.");
    THREE.OrbitControls = function() { this.update = function() {}; this.target = new THREE.Vector3(); this.enableZoom = false; }; 
}
