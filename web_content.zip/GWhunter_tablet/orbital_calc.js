// orbital_calc.js

/**
 * Calculates the radial distance in an elliptical orbit.
 * r(a, e, psi) = a * (1 - e * cos(psi))
 * @param {number} a - Semi-major axis.
 * @param {number} e - Eccentricity.
 * @param {number} psi_val - Eccentric anomaly.
 * @returns {number} Radial distance.
 */
function r_distance(a, e, psi_val) {
    return a * (1.0 - e * Math.cos(psi_val));
}

/**
 * Calculates the radial velocity.
 * rd(a, e, psi, psid) = a * e * sin(psi) * psid
 * @param {number} a - Semi-major axis.
 * @param {number} e - Eccentricity.
 * @param {number} psi_val - Eccentric anomaly.
 * @param {number} psid_val - Time derivative of eccentric anomaly.
 * @returns {number} Radial velocity.
 */
function rd_velocity(a, e, psi_val, psid_val) {
    return a * e * Math.sin(psi_val) * psid_val;
}

/**
 * Calculates the true anomaly.
 * theta(e, psi) = 2.0 * arctan(sqrt((1+e)/(1-e)) * tan(psi/2.0))
 * @param {number} e - Eccentricity.
 * @param {number} psi_val - Eccentric anomaly.
 * @returns {number} True anomaly.
 */
function theta_anomaly(e, psi_val) {
    if (Math.abs(1.0 - e) < 1e-9 && e >= 1.0) { // Handle e close to 1 for the factor
        // For e=1 (parabolic), theta = psi.
        // Or if e > 1 (hyperbolic), (1-e) is negative, sqrt factor complex.
        // Given e <= 0.5, this branch is for extreme robustness / future-proofing.
        if (e === 1.0) return psi_val; // Simplification for e=1
        // For e > 1, the formula for theta changes. We assume e < 1.
    }
    const factor = Math.sqrt((1.0 + e) / (1.0 - e));
    return 2.0 * Math.atan2(factor * Math.tan(psi_val / 2.0), 1.0);
}

/**
 * Calculates the time derivative of the true anomaly. (Robust version)
 * Original formula: sqrt((1+e)/(1-e)) * psid * (cos^2(theta/2) / cos^2(psi/2))
 * Limit of (cos^2(theta/2) / cos^2(psi/2)) as psi->PI is (1-e)/(1+e).
 * @param {number} a - Semi-major axis (not directly used, for signature consistency).
 * @param {number} e - Eccentricity.
 * @param {number} psi_val - Eccentric anomaly.
 * @param {number} theta_val - True anomaly.
 * @param {number} psid_val - Time derivative of eccentric anomaly.
 * @returns {number} Time derivative of true anomaly.
 */
function thetad_angular_velocity(a, e, psi_val, theta_val, psid_val) {
    const NEAR_ZERO_THRESHOLD = 1e-8; // Threshold for cos(psi/2) being close to zero

    // Pre-calculate factor to avoid issues if e=1
    let factor_sqrt;
    if (Math.abs(1.0 - e) < NEAR_ZERO_THRESHOLD && e >= 1.0) { // e.g. e is exactly 1 or very close
        // For e=1, theta=psi, so thetad=psid. The factor sqrt((1+e)/(1-e)) is Inf.
        // This indicates the original formula is ill-suited for e=1.
        // Since our simulation uses e <= 0.5, we proceed, but this highlights e=1 issues.
        if (e === 1.0) return psid_val; // Correct for e=1 if theta=psi
        factor_sqrt = Infinity; // Placeholder if e is >1 and 1-e is negative (complex result)
                                // but this shouldn't happen with problem constraints.
    } else {
        factor_sqrt = Math.sqrt((1.0 + e) / (1.0 - e)); // Safe for e < 1
    }
    
    if (isNaN(factor_sqrt) || !isFinite(factor_sqrt)) {
        // This can happen if e > 1, making (1-e) negative.
        // console.warn(`thetad_angular_velocity: factor_sqrt is problematic for e=${e}`);
        // Fallback based on simpler physics if possible, or return psid_val as a guess.
        return psid_val; // A fallback, might not be accurate for e > 1.
    }


    const cos_psi_half = Math.cos(psi_val / 2.0);

    if (Math.abs(cos_psi_half) < NEAR_ZERO_THRESHOLD) {
        // psi is very close to PI. theta should also be very close to PI.
        // The ratio cos^2(theta/2) / cos^2(psi/2) approaches (1-e)/(1+e).
        if (Math.abs(1.0 + e) < NEAR_ZERO_THRESHOLD) { // Avoid division by zero if e approx -1 (unphysical)
            return 0;
        }
        const ratio_limit = (1.0 - e) / (1.0 + e);
        return factor_sqrt * psid_val * ratio_limit;
    } else {
        // Standard case: psi is not PI
        const cos_theta_half = Math.cos(theta_val / 2.0);
        const cos_psi_half_sq = cos_psi_half * cos_psi_half;
        const cos_theta_half_sq = cos_theta_half * cos_theta_half;
        return factor_sqrt * psid_val * (cos_theta_half_sq / cos_psi_half_sq);
    }
}


/**
 * Calculates the time derivative of the eccentric anomaly.
 * psid(omega, e, psi) = omega / (1 - e * cos(psi))
 * @param {number} omega - Mean motion.
 * @param {number} e - Eccentricity.
 * @param {number} psi_val - Eccentric anomaly.
 * @returns {number} Time derivative of eccentric anomaly.
 */
function psid_eccentric_anomaly_rate(omega, e, psi_val) {
    const denominator = 1.0 - e * Math.cos(psi_val);
    // Denominator is bounded by (1-e) and (1+e). For e < 1, it's always positive.
    if (Math.abs(denominator) < 1e-10) { // Should not be hit if e < 1
        return omega / (1e-10 * Math.sign(denominator || 1)); // Avoid actual zero, preserve sign
    }
    return omega / denominator;
}

/**
 * Calculates the second time derivative of the true anomaly.
 * @param {number} omega
 * @param {number} a
 * @param {number} e
 * @param {number} psis_val
 * @param {number} thetas_val
 * @param {number} thetads_val
 * @param {number} psids_val
 * @returns {number}
 */
function thetadd_angular_acceleration(omega, a, e, psis_val, thetas_val, thetads_val, psids_val) {
    // This function is highly sensitive if psis_val is near PI due to tan(psis/2) and (1/cos(psis/2))^2
    // The perturbation of psis_val in orbitalParams should help avoid exact PI.

    const cos_psis_half = Math.cos(psis_val / 2.0);
    if (Math.abs(cos_psis_half) < 1e-8) { // If psis_val is still too close to PI
        // This indicates the perturbation might not have been enough, or this is a sensitive point.
        // console.warn("thetadd: psis_val is very close to PI, result might be unstable.", psis_val);
        // Returning 0 or a capped value might be safer than Inf/NaN.
        return 0; // Fallback to prevent NaN/Inf propagation
    }
    const tan_psis_half = Math.tan(psis_val / 2.0);


    const term1_factor_sqrt_val = (1.0 - e);
    if (Math.abs(term1_factor_sqrt_val) < 1e-9 && e >= 1.0) return 0; // e.g. e=1
    const term1_factor = Math.sqrt((e + 1.0) / term1_factor_sqrt_val);
    if (isNaN(term1_factor) || !isFinite(term1_factor)) return 0; // Safety for e > 1

    const cos_thetas_half = Math.cos(thetas_val / 2.0);
    const cos_psis_half_sq_inv = 1.0 / (cos_psis_half * cos_psis_half);

    const term_in_paren = thetads_val * Math.sin(thetas_val / 2.0) * (e * Math.cos(psis_val) - 1.0) -
                          psids_val * cos_thetas_half * tan_psis_half * (2.0 * e * Math.cos(psis_val) + e - 1.0);

    const numerator = term1_factor * omega * cos_thetas_half * cos_psis_half_sq_inv * term_in_paren;
    
    const denominator_base = (e * Math.cos(psis_val) - 1.0);
    const denominator = denominator_base * denominator_base;
    
    if (Math.abs(denominator) < 1e-9) return 0; // Avoid division by zero
    
    const result = numerator / denominator;
    if (isNaN(result) || !isFinite(result)) {
        // console.warn(`thetadd resulted in ${result}. Inputs: omega=${omega}, e=${e}, psis=${psis_val}, thetas=${thetas_val}, thetads=${thetads_val}, psids=${psids_val}`);
        return 0; // Fallback
    }
    return result;
}

/**
 * Calculates the second time derivative of radial distance.
 * @param {number} omega
 * @param {number} a
 * @param {number} e
 * @param {number} psi_val
 * @param {number} psid_val
 * @returns {number}
 */
function rdd_radial_acceleration(omega, a, e, psi_val, psid_val) {
    const numerator = a * e * psid_val * omega * (-e + Math.cos(psi_val));
    const denominator_base = (-1.0 + e * Math.cos(psi_val));
    const denominator = denominator_base * denominator_base; // Always positive or zero
    if (Math.abs(denominator) < 1e-9) return 0; // Avoid division by zero
    return numerator / denominator;
}


/**
 * Computes all key orbital parameters for a given time.
 * @param {number} omega - Mean motion.
 * @param {number} a - Semi-major axis.
 * @param {number} e - Eccentricity.
 * @param {number} t - Time (frame number).
 * @param {number} frametotime - Conversion factor.
 * @returns {object} Object containing psis, rs, thetas, psids, rds, thetads, rdds, thetadds.
 */
function orbitalParams(omega, a, e, t, frametotime) {
    let psis_val = solvePsi(omega, e, t, frametotime);

    // --- Perturbation for psi if too close to 0 or PI ---
    const epsilon_perturb = 1e-7; // Small perturbation
    if (Math.abs(psis_val - Math.PI) < epsilon_perturb) {
        // If psis_val is PI, (Math.PI - psis_val) is 0. Math.sign(0) is 0. So add epsilon_perturb.
        // If psis_val is PI - tiny, sign is 1. psis_val becomes PI - epsilon_perturb.
        // If psis_val is PI + tiny, sign is -1. psis_val becomes PI + epsilon_perturb.
        // We want to move it slightly away from PI.
        psis_val = Math.PI - epsilon_perturb; // Consistently move it to one side of PI
    } else if (Math.abs(psis_val) < epsilon_perturb) { // Near 0
        // Similar logic: move slightly away from 0 if it's causing issues (e.g. tan(psi/2) for psi=0 is fine)
        // Typically psi=0 is less problematic for these formulas than psi=PI.
        // psis_val = epsilon_perturb; // if needed
    }
    // --- End Perturbation ---

    const rs_val = r_distance(a, e, psis_val);
    const thetas_val = theta_anomaly(e, psis_val); // This uses tan(psi/2), perturbation helps
    const psids_val = psid_eccentric_anomaly_rate(omega, e, psis_val);
    const thetads_val = thetad_angular_velocity(a, e, psis_val, thetas_val, psids_val);
    const rds_val = rd_velocity(a, e, psis_val, psids_val);
    const thetadds_val = thetadd_angular_acceleration(omega, a, e, psis_val, thetas_val, thetads_val, psids_val);
    const rdds_val = rdd_radial_acceleration(omega, a, e, psis_val, psids_val);

    return {
        psis: psis_val,
        rs: rs_val,
        thetas: thetas_val,
        psids: psids_val,
        rds: rds_val,
        thetads: thetads_val,
        rdds: rdds_val,
        thetadds: thetadds_val
    };
}

/**
 * Converts polar coordinates (r, theta) to Cartesian (x, y).
 * @param {number} rs_val - Radial distance.
 * @param {number} thetas_val - True anomaly.
 * @returns {{x: number, y: number}} Cartesian coordinates.
 */
function xy_coords(rs_val, thetas_val) {
    return {
        x: rs_val * Math.cos(thetas_val),
        y: rs_val * Math.sin(thetas_val)
    };
}

/**
 * Computes Cartesian velocities (xd, yd).
 * @param {number} rs_val
 * @param {number} thetas_val
 * @param {number} thetads_val
 * @param {number} rds_val
 * @returns {{xd: number, yd: number}}
 */
function xyd_velocities(rs_val, thetas_val, thetads_val, rds_val) {
    return {
        xd: rds_val * Math.cos(thetas_val) - rs_val * Math.sin(thetas_val) * thetads_val,
        yd: rds_val * Math.sin(thetas_val) + rs_val * Math.cos(thetas_val) * thetads_val
    };
}

/**
 * Computes Cartesian accelerations (xdd, ydd).
 * @param {number} rs_val
 * @param {number} thetas_val
 * @param {number} rds_val
 * @param {number} thetads_val
 * @param {number} rdds_val
 * @param {number} thetadds_val
 * @returns {{xdd: number, ydd: number}}
 */
function xydd_accelerations(rs_val, thetas_val, rds_val, thetads_val, rdds_val, thetadds_val) {
    return {
        xdd: rdds_val * Math.cos(thetas_val) - rs_val * Math.sin(thetas_val) * thetadds_val - 2.0 * rds_val * Math.sin(thetas_val) * thetads_val,
        ydd: rdds_val * Math.sin(thetas_val) + rs_val * Math.cos(thetas_val) * thetadds_val + 2.0 * rds_val * Math.cos(thetas_val) * thetads_val
    };
}
