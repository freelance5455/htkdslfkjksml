// simulation_core.js

/**
 * Calculates the positions of the two black holes.
 * @param {number} f Current frame.
 * @param {number} m1 Mass of BH1.
 * @param {number} m2 Mass of BH2.
 * @param {number} omega Current orbital frequency (omega_pos).
 * @param {number} a Current semi-major axis.
 * @param {number} e Eccentricity.
 * @param {number} frametotime Time per frame.
 * @returns {{bh1_pos: [number, number], bh2_pos: [number, number]}}
 */
function position_BHs(f, m1, m2, omega, a, e, frametotime) {
    const M = m1 + m2;
    if (M === 0) return { bh1_pos: [0, 0], bh2_pos: [0, 0] };

    const params = orbitalParams(omega, a, e, f, frametotime);
    const { x: xred, y: yred } = xy_coords(params.rs, params.thetas);

    const bh1_pos = [-m2 / M * xred, -m2 / M * yred];
    const bh2_pos = [m1 / M * xred, m1 / M * yred];
    
    return { bh1_pos, bh2_pos };
}

/**
 * Calculates the warping effect due to a single black hole.
 * @param {number[][]} Xgrid Meshgrid X coordinates.
 * @param {number[][]} Ygrid Meshgrid Y coordinates.
 * @param {[number, number]} bh_pos Position of the black hole [x, y].
 * @param {number} mass Mass of the black hole.
 * @param {number} scale_factor Intensity of warping.
 * @returns {number[][]} Z_warp grid.
 */
function gravitational_warp(Xgrid, Ygrid, bh_pos, mass, scale_factor) {
    const Z_warp = [];
    const rows = Xgrid.length;
    const cols = Xgrid[0].length;

    for (let i = 0; i < rows; i++) {
        const row = [];
        for (let j = 0; j < cols; j++) {
            let rs_dist = Math.sqrt(Math.pow(Xgrid[i][j] - bh_pos[0], 2) + Math.pow(Ygrid[i][j] - bh_pos[1], 2));
            
            //rs_dist = Math.max(rs_dist, 0.1); // Prevent division by zero, ensure minimum distance
            //row.push(-scale_factor * mass / rs_dist);
            row.push(-scale_factor * mass / (rs_dist+0.3) );
        }
        Z_warp.push(row);
    }
    return Z_warp;
}

/**
 * Calculates the size of a black hole based on the frame number (merger progress).
 * @param {number} f Current frame.
 * @param {number} M Mass of the black hole (used for base size).
 * @param {number} merger_frame Frame of merger.
 * @param {number} merger_width Duration of merger transition.
 * @returns {number} Size of the black hole.
 */
function bh_size(f, M, merger_frame, merger_width) {
    const size_single = 8.0 * Math.sqrt(M);
    const size_double = Math.sqrt(2.0) * size_single; 

    if (f <= merger_frame - merger_width) {
        return size_single;
    }
    if (f < merger_frame + merger_width) { 
        return size_single + (size_double - size_single) * (f - (merger_frame - merger_width)) / (2 * merger_width);
    }
    return size_double; 
}

/**
 * Computes wave grids for Zs calculation.
 * @param {number[]} frames Array of frame numbers.
 * @param {number[][]} Rgrid Grid of radial distances from origin.
 * @param {number} ConstA Constant A for frequency.
 * @param {number} CfreqB Constant B for frequency (coalescence time).
 * @param {number} Comegatoa Constant relating omega to a.
 * @param {number} Mchirp_val Chirp mass.
 * @param {number} e Eccentricity.
 * @param {number} Cstrain Strain constant.
 * @param {number} merger_frame Frame of merger.
 * @param {number} frametotime Time per frame.
 * @param {number} [precision=4] Decimal precision for rounding R values.
 * @returns {Array<Array<Array<number>>>} wave_grids[frame_index][row_index][col_index]
 */
function compute_wave_grids_js(frames, Rgrid, ConstA, CfreqB, Comegatoa, Mchirp_val, e, Cstrain, merger_frame, frametotime, precision = 4) {
    const Rgrid_flat_rounded = Rgrid.flat().map(r => roundTo(r, precision));
    const unique_Rs = uniqueSorted(Rgrid_flat_rounded);

    const R_to_index = new Map();
    unique_Rs.forEach((r_val, i) => R_to_index.set(r_val, i)); // Corrected variable name

    const all_waves_at_unique_R_and_time_offsets = [];

    for (let i = 0; i < frames.length; i++) {
        const f = frames[i];
        const times_for_this_frame = unique_Rs.map(r_val => f - 5.0 * r_val); 
        
        const wave_values_for_times = wave_vectorized(
            times_for_this_frame, ConstA, CfreqB, Comegatoa, Mchirp_val, e, Cstrain, merger_frame, frametotime
        );
        all_waves_at_unique_R_and_time_offsets.push(wave_values_for_times);
    }
    
    const wave_grids_all_frames = []; 
    const n_rows = Rgrid.length;
    const n_cols = Rgrid[0].length;

    /* SPEED: the cell -> unique-radius lookup does not depend on the frame, so
       resolve it once here instead of rounding + Map-looking-up every cell on
       every one of the ~750-1000 frames. Identical results, less CPU. */
    const cell_R_index = new Int32Array(n_rows * n_cols);
    for (let r = 0; r < n_rows; r++) {
        for (let c = 0; c < n_cols; c++) {
            const idx = R_to_index.get(roundTo(Rgrid[r][c], precision));
            cell_R_index[r * n_cols + c] = (idx === undefined) ? -1 : idx;
        }
    }

    for (let frame_idx = 0; frame_idx < frames.length; frame_idx++) {
        const current_frame_grid = createMatrix(n_rows, n_cols);
        for (let r = 0; r < n_rows; r++) {
            for (let c = 0; c < n_cols; c++) {
                const unique_R_idx = cell_R_index[r * n_cols + c] < 0 ? undefined : cell_R_index[r * n_cols + c];
                if (unique_R_idx !== undefined && unique_R_idx < all_waves_at_unique_R_and_time_offsets[frame_idx].length) { // Added boundary check
                    current_frame_grid[r][c] = all_waves_at_unique_R_and_time_offsets[frame_idx][unique_R_idx];
                } else {
                    // console.warn(`compute_wave_grids_js: Indexing issue for Rval ${rounded_R_val} at frame ${frame_idx}. unique_R_idx: ${unique_R_idx}`);
                    current_frame_grid[r][c] = 0; // Fallback
                }
            }
        }
        wave_grids_all_frames.push(current_frame_grid);
    }
    return wave_grids_all_frames;
}


/**
 * Main calculation function to generate data for all frames.
 * @param {object} params - Contains all simulation parameters.
 * @returns {object} Object containing arrays of data for each frame: waves, bh_positions, bh_sizes1, bh_sizes2, Zs_grids.
 */
function calculateAllFramesData(params) {
    const {
        N_frames, merger_frame, merger_width, frametotime, Xgrid, Ygrid,
        m1, m2, e, Comegatoa, Cstrain, scale_factor, amergefactor, posfactor
    } = params;

    const M_total = m1 + m2;

    const frames = Array.from({ length: N_frames }, (_, i) => i);

    const CfreqB = (merger_frame + merger_width) * frametotime; 
    const Mchirp_val = chirp_mass(m1, m2);
    const amerge = (m1 + m2) / amergefactor; 
    
    let ConstA;
    if (CfreqB <= merger_frame * frametotime) {
        // console.warn("CfreqB is too small. Adjusting for stability. Original CfreqB:", CfreqB, "Merger time:", merger_frame * frametotime);
        const adjustedCfreqB = (merger_frame + merger_width + 10) * frametotime; 
        ConstA = freqA_const(amerge, Comegatoa, Mchirp_val, adjustedCfreqB, merger_frame, frametotime);
    } else {
        ConstA = freqA_const(amerge, Comegatoa, Mchirp_val, CfreqB, merger_frame, frametotime);
    }
    
    if (isNaN(ConstA) || !isFinite(ConstA)) {
        // console.error("ConstA is NaN or Infinite. Check parameters.", {amerge, Comegatoa, Mchirp_val, CfreqB, merger_frame, frametotime});
        ConstA = 0.1; 
    }

    const Rgrid = Xgrid.map((row, i) => row.map((x_val, j) => Math.sqrt(x_val * x_val + Ygrid[i][j] * Ygrid[i][j])));

    const omegas_all_frames = freq_vectorized(ConstA, CfreqB, Mchirp_val, frames, merger_frame, frametotime);
    let semi_major_axes = omegas_all_frames.map(omega => semimajora(Comegatoa, omega));

    for (let i = 0; i < frames.length; i++) {
        if (frames[i] > merger_frame) {
            semi_major_axes[i] *= Math.exp((merger_frame - frames[i]) * 0.04);
        }
    }

    const psis_all_frames_raw = frames.map((f, i) => solvePsi(omegas_all_frames[i], e, f, frametotime));
    // Perturbation is now inside orbitalParams, so psis_all_frames_raw is not strictly needed here if orbitalParams is called once per frame.
    // For true_anomalies_all_frames, we need the (potentially perturbed) psi from orbitalParams.
    // Let's get true_anomalies after full orbitalParams calculation if needed, or pass perturbed psi.
    // For now, this is okay as theta_anomaly will use the perturbed psi if called after orbitalParams.
    
    const bh_positions = []; 
    const bh_kinematics = [];
    const true_anomalies_all_frames = []; // Will be populated during the loop

    const omegas_for_pos_calc = frames.map(f => freq_pos(ConstA, CfreqB, Mchirp_val, f, merger_frame, frametotime));

    let max_bh1_acc_mag_overall = 0; // For potential normalization later
    let max_bh2_acc_mag_overall = 0;
    
    for (let i = 0; i < frames.length; i++) {
        const current_omega = omegas_for_pos_calc[i];
        const current_a = semi_major_axes[i];
        const f = frames[i];

        // Calculate full orbital parameters for the reduced mass
        const ops_reduced = orbitalParams(current_omega, current_a, e, f, frametotime);
        true_anomalies_all_frames.push(ops_reduced.thetas); 

        // Calculate Cartesian kinematics for the reduced mass
        const { x: x_red, y: y_red } = xy_coords(ops_reduced.rs, ops_reduced.thetas);
        const { xd: xd_red, yd: yd_red } = xyd_velocities(ops_reduced.rs, ops_reduced.thetas, ops_reduced.thetads, ops_reduced.rds);
        const { xdd: xdd_red, ydd: ydd_red } = xydd_accelerations(ops_reduced.rs, ops_reduced.thetas, ops_reduced.rds, ops_reduced.thetads, ops_reduced.rdds, ops_reduced.thetadds);

        // Derive individual BH positions
        const bh1_pos_x = (-m2 / M_total) * x_red;
        const bh1_pos_y = (-m2 / M_total) * y_red;
        const bh2_pos_x = (m1 / M_total) * x_red;
        const bh2_pos_y = (m1 / M_total) * y_red;
        bh_positions.push({ bh1_pos: [bh1_pos_x, bh1_pos_y], bh2_pos: [bh2_pos_x, bh2_pos_y] });

        // Derive individual BH accelerations and their magnitudes
        const bh1_acc_x = (-m2 / M_total) * xdd_red;
        const bh1_acc_y = (-m2 / M_total) * ydd_red;
        const bh1_acc_mag = Math.sqrt(bh1_acc_x * bh1_acc_x + bh1_acc_y * bh1_acc_y);

        const bh2_acc_x = (m1 / M_total) * xdd_red;
        const bh2_acc_y = (m1 / M_total) * ydd_red;
        const bh2_acc_mag = Math.sqrt(bh2_acc_x * bh2_acc_x + bh2_acc_y * bh2_acc_y);
        
        bh_kinematics.push({ bh1_acc_mag, bh2_acc_mag });

        if (bh1_acc_mag > max_bh1_acc_mag_overall) max_bh1_acc_mag_overall = bh1_acc_mag;
        if (bh2_acc_mag > max_bh2_acc_mag_overall) max_bh2_acc_mag_overall = bh2_acc_mag;
    }


    if (merger_frame - merger_width > 0 && semi_major_axes.length > merger_frame - merger_width) {
        const a_at_transition = semi_major_axes[merger_frame - merger_width];
        for (let i = 0; i < frames.length; i++) {
            if (frames[i] <= merger_frame - merger_width) {
                const current_a = semi_major_axes[i];
                //const scale_adj = 1.0 + posfactor * (current_a - a_at_transition) * 0.1; // Added 0.1 to moderate effect
                const scale_adj = 1.0 + posfactor * (current_a - a_at_transition);
                bh_positions[i].bh1_pos[0] *= scale_adj;
                bh_positions[i].bh1_pos[1] *= scale_adj;
                bh_positions[i].bh2_pos[0] *= scale_adj;
                bh_positions[i].bh2_pos[1] *= scale_adj;
            }
        }
    }

    const bh_sizes1 = frames.map(f => bh_size(f, m1, merger_frame, merger_width));
    const bh_sizes2 = frames.map(f => bh_size(f, m2, merger_frame, merger_width));

    const waves = wave_vectorized(frames, ConstA, CfreqB, Comegatoa, Mchirp_val, e, Cstrain, merger_frame, frametotime);

    /* MEMORY FIX (tablet crash): Z1/Z2 used to be built for ALL frames at once
       (two full N_frames x grid x grid nested arrays) before being summed. They
       are now computed one frame at a time inside the loop below, so only one
       frame's worth is ever alive. Same numbers, far lower peak memory. */

    const wave_grids_for_Zs = compute_wave_grids_js(
        frames, Rgrid, ConstA, CfreqB, Comegatoa, Mchirp_val, e, Cstrain, merger_frame, frametotime
    );

    const Zs_grids = []; 
    const n_rows_grid = Xgrid.length;
    const n_cols_grid = Xgrid[0].length;

    const RIPPLE_GLOBAL_SCALE = 0.03; // Adjusted global scale factor for ripple magnitude (default 0.015)
    const K_FACTOR_RIPPLE = 0.75; // Wave number for ripple: smaller = wider waves, larger = tighter waves (default 0.75)
    const RIPPLE_FALLOFF_STEEPNESS = 0.2; // Controls how quickly ripple amplitude falls with distance from BH (default 0.3)
    const ACCEL_RIPPLE_SENSITIVITY = 5.0; // How much BH acceleration modulates its ripple component strength
                                          // Lower values make it more subtle. (default 0.2)
    const ACCEL_NORMALIZATION_FACTOR = Math.max(1, max_bh1_acc_mag_overall, max_bh2_acc_mag_overall) / 2; // Normalize by roughly half the max observed accel
    const RIPPLE_PROPAGATION_SPEED = 0.01; // Speed of ripple "information" propagation in grid units per frame (default 5.0)

    // Helper function for linear interpolation of acceleration
    const getInterpolatedAcceleration = (bh_idx_str, retarded_frame_exact, N_frames_total) => {
        if (retarded_frame_exact < 0) {
            return bh_kinematics[0] ? bh_kinematics[0][bh_idx_str] : 0; // Use first frame's accel if retarded time is too early
        }
        if (retarded_frame_exact >= N_frames_total - 1) {
            return bh_kinematics[N_frames_total - 1] ? bh_kinematics[N_frames_total - 1][bh_idx_str] : 0; // Use last frame's accel
        }

        const frame_floor = Math.floor(retarded_frame_exact);
        const frame_ceil = Math.ceil(retarded_frame_exact);
        const fraction = retarded_frame_exact - frame_floor;

        if (frame_floor === frame_ceil) { // Exact frame
            return bh_kinematics[frame_floor] ? bh_kinematics[frame_floor][bh_idx_str] : 0;
        }
        
        const acc_floor = bh_kinematics[frame_floor] ? bh_kinematics[frame_floor][bh_idx_str] : 0;
        const acc_ceil = bh_kinematics[frame_ceil] ? bh_kinematics[frame_ceil][bh_idx_str] : 0;

        return acc_floor + (acc_ceil - acc_floor) * fraction;
    };

    for (let i = 0; i < frames.length; i++) {
        /* MEMORY FIX: one flat Float32Array per frame (index = row * n_cols + col)
           instead of a nested array of 64-bit numbers. ~4x smaller, no per-row
           array objects, and far kinder to the garbage collector. */
        const current_Zs_grid = new Float32Array(n_rows_grid * n_cols_grid);
        const Z1_frame = gravitational_warp(Xgrid, Ygrid, bh_positions[i].bh1_pos, m1, scale_factor);
        const Z2_frame = gravitational_warp(Xgrid, Ygrid, bh_positions[i].bh2_pos, m2, scale_factor);
        const current_theta_f = true_anomalies_all_frames[i]; 
        const current_wave_grid_for_frame = wave_grids_for_Zs[i]; 

        const bh1_pos_curr = bh_positions[i].bh1_pos;
        const bh2_pos_curr = bh_positions[i].bh2_pos;
        const current_kinematics = bh_kinematics[i];

        for (let r_idx = 0; r_idx < n_rows_grid; r_idx++) {
            for (let c_idx = 0; c_idx < n_cols_grid; c_idx++) {
                const base_warp = Z1_frame[r_idx][c_idx] + Z2_frame[r_idx][c_idx];

                /*
                const R_val = Rgrid[r_idx][c_idx];
                
                let wave_component_on_grid = 0;
                if (current_wave_grid_for_frame && 
                    current_wave_grid_for_frame[r_idx] !== undefined && // Check row exists
                    current_wave_grid_for_frame[r_idx][c_idx] !== undefined) { // Check col exists
                    wave_component_on_grid = current_wave_grid_for_frame[r_idx][c_idx];
                }


                // --- Safety Check for wave_component_on_grid ---
                if (isNaN(wave_component_on_grid) || !isFinite(wave_component_on_grid)) {
                    // console.warn(`Bad wave_component_on_grid at frame ${i}, r_idx ${r_idx}, c_idx ${c_idx}: ${wave_component_on_grid}. Setting to 0.`);
                    wave_component_on_grid = 0; 
                }
                // --- End Safety Check ---
                
                // Clamp the absolute wave component to prevent excessively large ripples
                const MAX_ABS_WAVE_RIPPLE_CONTRIBUTION = 100; // Adjust this threshold as needed
                const effective_wave_abs = Math.min(Math.abs(wave_component_on_grid), MAX_ABS_WAVE_RIPPLE_CONTRIBUTION);


                const ripple = 0.01 * Math.cos(R_val - current_theta_f) * effective_wave_abs; 
                */

                let effective_wave_abs = 0; // This is overall GW amplitude at grid point based on origin-retarded time
                if (current_wave_grid_for_frame && 
                    current_wave_grid_for_frame[r_idx] !== undefined && 
                    current_wave_grid_for_frame[r_idx][c_idx] !== undefined) {
                    effective_wave_abs = current_wave_grid_for_frame[r_idx][c_idx];
                }

                if (isNaN(effective_wave_abs) || !isFinite(effective_wave_abs)) {
                    effective_wave_abs = 0; 
                }
                
                const MAX_ABS_WAVE_RIPPLE_CONTRIBUTION = 10; 
                effective_wave_abs = Math.min(Math.abs(effective_wave_abs), MAX_ABS_WAVE_RIPPLE_CONTRIBUTION);

                const grid_x = Xgrid[r_idx][c_idx];
                const grid_y = Ygrid[r_idx][c_idx];

                // --- BH1 Ripple Component with Retarded Acceleration ---
                const dx1 = grid_x - bh1_pos_curr[0]; // Distance to BH1 at current time (for phase)
                const dy1 = grid_y - bh1_pos_curr[1];
                const R_rel1 = Math.sqrt(dx1 * dx1 + dy1 * dy1) + 1e-6; 
                const retarded_frame1 = i - R_rel1 / RIPPLE_PROPAGATION_SPEED;
                const acc_bh1_retarded = getInterpolatedAcceleration('bh1_acc_mag', retarded_frame1, N_frames);
                const norm_accel1 = acc_bh1_retarded / (ACCEL_NORMALIZATION_FACTOR || 1.0);
                const strength_mod1 = (1.0 + ACCEL_RIPPLE_SENSITIVITY * norm_accel1);
                const amplitude_falloff1 = 1.0 / (1.0 + R_rel1 * RIPPLE_FALLOFF_STEEPNESS);
                const ripple_component1 = strength_mod1 * amplitude_falloff1 * Math.cos(K_FACTOR_RIPPLE * R_rel1 - current_theta_f);

                // --- BH2 Ripple Component with Retarded Acceleration ---
                const dx2 = grid_x - bh2_pos_curr[0]; // Distance to BH2 at current time (for phase)
                const dy2 = grid_y - bh2_pos_curr[1];
                const R_rel2 = Math.sqrt(dx2 * dx2 + dy2 * dy2) + 1e-6;
                const retarded_frame2 = i - R_rel2 / RIPPLE_PROPAGATION_SPEED;
                const acc_bh2_retarded = getInterpolatedAcceleration('bh2_acc_mag', retarded_frame2, N_frames);
                const norm_accel2 = acc_bh2_retarded / (ACCEL_NORMALIZATION_FACTOR || 1.0);
                const strength_mod2 = (1.0 + ACCEL_RIPPLE_SENSITIVITY * norm_accel2);
                const amplitude_falloff2 = 1.0 / (1.0 + R_rel2 * RIPPLE_FALLOFF_STEEPNESS);
                const ripple_component2 = strength_mod2 * amplitude_falloff2 * Math.cos(K_FACTOR_RIPPLE * R_rel2 - current_theta_f);
                
                const combined_pattern_effect = (ripple_component1 + ripple_component2) * 0.5; 
                const final_ripple = RIPPLE_GLOBAL_SCALE * combined_pattern_effect * effective_wave_abs;
                
                current_Zs_grid[r_idx * n_cols_grid + c_idx] = base_warp + final_ripple;
            }
        }
        Zs_grids.push(current_Zs_grid);
    }

    return { waves, bh_positions, bh_kinematics, bh_sizes1, bh_sizes2, Zs_grids, Zs_cols: n_cols_grid, Xgrid, Ygrid };
}
