
## 3.2 UI
- Light/Dark mode with persistent selection.
- Simplified icons and redesigned sidebar labels.
- Compact welcome strip fills the upper empty area without changing the game layout.
- Improved notification/report/admin surfaces.
- Offline mode blocks the app with a clear no-internet screen until connectivity returns.
# X Gaming 3.0

نسخة مطورة مبنية مباشرة على آخر تصميم X Gaming بدون إعادة تصميم الواجهة.

## ما تم إضافته
- الحفاظ على الثيم والتخطيط الحاليين والأيقونات الخضراء.
- مدير تنزيل Android أصلي لملفات APK / OBB / DATA داخل `Downloads/XGaming`.
- إشعار عند بدء التحميل واستخدام إشعار النظام عند اكتماله.
- طلب صلاحيات Android من النظام للإشعارات والتخزين على الإصدارات التي تحتاجه.
- إشعارات خلفية للألعاب الجديدة وتحديثات الألعاب باستخدام WorkManager.
- مزامنة كتالوج الألعاب دوريًا مع السيرفر.
- منع حذف كتالوج السيرفر تلقائيًا عند أول تشغيل.
- حسابات حقيقية على السيرفر عند توفر API: Register/Login باستخدام bcrypt + JWT.
- وضع محلي احتياطي للحسابات عند عدم توفر السيرفر.
- المفضلة محليًا مع عداد داخل الملف الشخصي.
- تقييمات وتعليقات كما كانت موجودة، مع تحسين صفحة تفاصيل اللعبة.
- لوحة المسؤول: إضافة لعبة، تصنيفها، الإصدار، الوصف، التقييم، APK/OBB/DATA، الصور، حذف اللعبة، واستقبال البلاغات.
- Backend داخل مجلد `server` مع PostgreSQL دائم، صور، ألعاب، بلاغات، حسابات، وواجهة تحديث التطبيق.
- فحص تحديث التطبيق وفتح مثبت Android بالطريقة الرسمية.

## مهم
التطبيق الحالي يشير إلى:
`https://xgaming-api-1scl-production.up.railway.app/api`

إذا نشرت Backend الموجود في مجلد `server` على سيرفر جديد، غيّر قيمة `SERVER_API` في:
`app/src/main/assets/script.js`

ثم ابنِ APK من Android Studio.

## تشغيل السيرفر
انسخ `.env.example` إلى `.env`، ضع `DATABASE_URL` و`ADMIN_SECRET` و`JWT_SECRET`، ثم:

```bash
npm install
npm start
```

السيرفر ينشئ جداول PostgreSQL تلقائيًا عند التشغيل.

## XGaming 3.1 updates
- Game cover images are the primary visual on cards and detail pages.
- APK/OBB/DATA are URL fields; no game binaries are bundled in the app.
- Added game size, hidden/published state, editing, hiding/showing, deletion, and admin statistics.
- Added notification settings and server announcement polling.
- Removed the X Gaming brand text from the top of the home page while preserving the existing design.
