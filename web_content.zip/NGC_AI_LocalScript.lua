--// NGC AI | BLACK SAND GLASS
--// Roblox Executor (LocalScript) - conecta com o app NGC AI Bridge

local CoreGui = game:GetService("CoreGui")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local RELAY = "https://ntfy.sh"
local NICK = LocalPlayer.Name:lower()
local TOPIC_IN = "ngchub-v1-" .. NICK .. "-a"   -- app -> roblox
local TOPIC_OUT = "ngchub-v1-" .. NICK .. "-r"  -- roblox -> app
local CHUNK = 3400
local MAX_ROUNDS = 10

local httpRequest = (syn and syn.request) or (http and http.request) or http_request or request
    or (fluxus and fluxus.request)

local GUI_NAME = "NGCAIPanel"
local old = CoreGui:FindFirstChild(GUI_NAME)
if old then old:Destroy() end

local SYSTEM = [[Você é a IA do NGC AI, rodando dentro de um jogo Roblox, conectada ao cliente do jogador. Responda no idioma do usuário, curto e direto.
Para inspecionar o jogo, emita blocos <tool>{JSON}</tool> (pode emitir vários na mesma resposta). O resultado volta numa mensagem com blocos <result>.
Ferramentas:
<tool>{"name":"tree","path":"Workspace","depth":2}</tool> lista filhos
<tool>{"name":"props","path":"Workspace.Part"}</tool> propriedades e atributos
<tool>{"name":"source","path":"Workspace.Script"}</tool> código de um script
<tool>{"name":"find","query":"Part","class":"BasePart","path":"Workspace"}</tool> busca por nome/classe
<tool>{"name":"players"}</tool> jogadores e posições
<tool>{"name":"run","code":"print(1)"}</tool> executa Luau no cliente (pode estar desativado pelo usuário)
Caminhos no formato Workspace.Map.Part. Não invente nomes: explore com tree/find antes. Quando tiver a resposta final, responda sem <tool>.]]

-- ESTADO
local state = {
    connected = false,
    models = {},
    model = "",
    provider = "",
    exec = false,
    waiting = false,
}

local Screen = Instance.new("ScreenGui")
Screen.Name = GUI_NAME
Screen.ResetOnSpawn = false
Screen.DisplayOrder = 999
Screen.Parent = CoreGui

local function make(class, props, parent)
    local o = Instance.new(class)
    for k, v in pairs(props) do o[k] = v end
    o.Parent = parent
    return o
end

local function corner(o, r)
    make("UICorner", {CornerRadius = UDim.new(0, r)}, o)
end

-- PAINEL
local Frame = make("Frame", {
    Name = "MainFrame",
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromOffset(340, 430),
    BackgroundColor3 = Color3.fromRGB(8, 8, 9),
    BackgroundTransparency = 0.22,
    BorderSizePixel = 0,
    ClipsDescendants = true,
}, Screen)
corner(Frame, 13)

local FrameScale = make("UIScale", {Scale = 1}, Frame)

make("UIStroke", {
    Color = Color3.fromRGB(125, 125, 130),
    Transparency = 0.78,
    Thickness = 1,
}, Frame)

local Texture = make("ImageLabel", {
    Name = "SandTexture",
    Size = UDim2.fromScale(1, 1),
    BackgroundTransparency = 1,
    Image = "rbxassetid://6238544817",
    ImageColor3 = Color3.fromRGB(185, 185, 190),
    ImageTransparency = 0.76,
    ScaleType = Enum.ScaleType.Tile,
    TileSize = UDim2.fromOffset(48, 48),
    ZIndex = 1,
}, Frame)
corner(Texture, 13)

local Title = make("TextLabel", {
    Name = "Title",
    Position = UDim2.new(0, 14, 0, 4),
    Size = UDim2.new(1, -58, 0, 42),
    BackgroundTransparency = 1,
    Text = "NGC AI",
    TextColor3 = Color3.fromRGB(245, 245, 245),
    TextSize = 15,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
    ZIndex = 2,
}, Frame)

local Close = make("TextButton", {
    Name = "CloseButton",
    AnchorPoint = Vector2.new(1, 0),
    Position = UDim2.new(1, -8, 0, 0),
    Size = UDim2.fromOffset(32, 48),
    BackgroundTransparency = 1,
    BorderSizePixel = 0,
    Text = "×",
    TextColor3 = Color3.fromRGB(240, 240, 240),
    TextSize = 38,
    Font = Enum.Font.Gotham,
    AutoButtonColor = false,
    ZIndex = 3,
}, Frame)

Close.MouseEnter:Connect(function()
    TweenService:Create(Close, TweenInfo.new(0.12), {TextColor3 = Color3.fromRGB(150, 150, 155)}):Play()
end)
Close.MouseLeave:Connect(function()
    TweenService:Create(Close, TweenInfo.new(0.12), {TextColor3 = Color3.fromRGB(240, 240, 240)}):Play()
end)

local Content = make("Frame", {
    Name = "Content",
    Position = UDim2.new(0, 9, 0, 48),
    Size = UDim2.new(1, -18, 1, -57),
    BackgroundColor3 = Color3.fromRGB(15, 15, 17),
    BackgroundTransparency = 0.48,
    BorderSizePixel = 0,
    ZIndex = 2,
}, Frame)
corner(Content, 9)
make("UIStroke", {Color = Color3.fromRGB(125, 125, 130), Transparency = 0.88}, Content)

-- TELA DE ESPERA
local Waiting = make("TextLabel", {
    Name = "Waiting",
    Position = UDim2.fromOffset(12, 12),
    Size = UDim2.new(1, -24, 1, -24),
    BackgroundTransparency = 1,
    Text = "Aguardando o app conectar...\n\nUsuário: " .. LocalPlayer.Name
        .. "\n\nAbra o NGC AI Bridge, coloque este nick e a API key.",
    TextColor3 = Color3.fromRGB(210, 210, 215),
    TextSize = 13,
    Font = Enum.Font.Gotham,
    TextWrapped = true,
    ZIndex = 3,
}, Content)

-- CHAT
local Chat = make("Frame", {
    Name = "Chat",
    Size = UDim2.fromScale(1, 1),
    BackgroundTransparency = 1,
    Visible = false,
    ZIndex = 3,
}, Content)

local TopRow = make("Frame", {
    Position = UDim2.fromOffset(6, 6),
    Size = UDim2.new(1, -12, 0, 26),
    BackgroundTransparency = 1,
    ZIndex = 4,
}, Chat)

local function styleBtn(props, parent)
    local b = make("TextButton", {
        BackgroundColor3 = Color3.fromRGB(28, 28, 32),
        BackgroundTransparency = 0.2,
        BorderSizePixel = 0,
        TextColor3 = Color3.fromRGB(235, 235, 240),
        TextSize = 11,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
        ZIndex = 5,
    }, parent)
    for k, v in pairs(props) do b[k] = v end
    corner(b, 7)
    return b
end

local ModelBtn = styleBtn({
    Position = UDim2.fromOffset(0, 0),
    Size = UDim2.new(1, -124, 1, 0),
    Text = "model",
    TextTruncate = Enum.TextTruncate.AtEnd,
}, TopRow)

local NewBtn = styleBtn({
    Position = UDim2.new(1, -120, 0, 0),
    Size = UDim2.fromOffset(52, 26),
    Text = "Novo",
}, TopRow)

local ExecBtn = styleBtn({
    Position = UDim2.new(1, -62, 0, 0),
    Size = UDim2.fromOffset(62, 26),
    Text = "Exec: OFF",
    TextSize = 10,
}, TopRow)

local Log = make("ScrollingFrame", {
    Position = UDim2.fromOffset(6, 38),
    Size = UDim2.new(1, -12, 1, -82),
    BackgroundTransparency = 1,
    BorderSizePixel = 0,
    ScrollBarThickness = 3,
    CanvasSize = UDim2.new(0, 0, 0, 0),
    AutomaticCanvasSize = Enum.AutomaticSize.Y,
    ZIndex = 4,
}, Chat)
make("UIListLayout", {Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder}, Log)

local InputRow = make("Frame", {
    AnchorPoint = Vector2.new(0, 1),
    Position = UDim2.new(0, 6, 1, -6),
    Size = UDim2.new(1, -12, 0, 32),
    BackgroundTransparency = 1,
    ZIndex = 4,
}, Chat)

local Input = make("TextBox", {
    Size = UDim2.new(1, -64, 1, 0),
    BackgroundColor3 = Color3.fromRGB(24, 24, 28),
    BackgroundTransparency = 0.2,
    BorderSizePixel = 0,
    Text = "",
    PlaceholderText = "Pergunte algo...",
    PlaceholderColor3 = Color3.fromRGB(120, 120, 128),
    TextColor3 = Color3.fromRGB(240, 240, 245),
    TextSize = 13,
    Font = Enum.Font.Gotham,
    TextXAlignment = Enum.TextXAlignment.Left,
    ClearTextOnFocus = false,
    ZIndex = 5,
}, InputRow)
corner(Input, 8)
make("UIPadding", {PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8)}, Input)

local SendBtn = styleBtn({
    Position = UDim2.new(1, -58, 0, 0),
    Size = UDim2.fromOffset(58, 32),
    Text = "Enviar",
    TextSize = 12,
}, InputRow)

-- LISTA DE MODELOS
local ModelList = make("Frame", {
    Position = UDim2.fromOffset(6, 36),
    Size = UDim2.new(1, -12, 1, -80),
    BackgroundColor3 = Color3.fromRGB(10, 10, 12),
    BackgroundTransparency = 0.05,
    BorderSizePixel = 0,
    Visible = false,
    ZIndex = 20,
}, Chat)
corner(ModelList, 9)
make("UIStroke", {Color = Color3.fromRGB(125, 125, 130), Transparency = 0.8}, ModelList)

local SearchBox = make("TextBox", {
    Position = UDim2.fromOffset(6, 6),
    Size = UDim2.new(1, -12, 0, 26),
    BackgroundColor3 = Color3.fromRGB(24, 24, 28),
    BorderSizePixel = 0,
    Text = "",
    PlaceholderText = "buscar modelo...",
    PlaceholderColor3 = Color3.fromRGB(120, 120, 128),
    TextColor3 = Color3.fromRGB(240, 240, 245),
    TextSize = 12,
    Font = Enum.Font.Gotham,
    TextXAlignment = Enum.TextXAlignment.Left,
    ClearTextOnFocus = false,
    ZIndex = 21,
}, ModelList)
corner(SearchBox, 7)
make("UIPadding", {PaddingLeft = UDim.new(0, 8)}, SearchBox)

local ModelScroll = make("ScrollingFrame", {
    Position = UDim2.fromOffset(6, 38),
    Size = UDim2.new(1, -12, 1, -44),
    BackgroundTransparency = 1,
    BorderSizePixel = 0,
    ScrollBarThickness = 3,
    CanvasSize = UDim2.new(0, 0, 0, 0),
    AutomaticCanvasSize = Enum.AutomaticSize.Y,
    ZIndex = 21,
}, ModelList)
make("UIListLayout", {Padding = UDim.new(0, 3), SortOrder = Enum.SortOrder.LayoutOrder}, ModelScroll)

local function BuildModelList(filter)
    for _, c in ipairs(ModelScroll:GetChildren()) do
        if c:IsA("TextButton") then c:Destroy() end
    end
    filter = (filter or ""):lower()
    local shown = 0
    for i, m in ipairs(state.models) do
        if filter == "" or m:lower():find(filter, 1, true) then
            shown += 1
            if shown > 200 then break end
            local b = make("TextButton", {
                LayoutOrder = i,
                Size = UDim2.new(1, -4, 0, 24),
                BackgroundColor3 = (m == state.model) and Color3.fromRGB(55, 55, 62) or Color3.fromRGB(26, 26, 30),
                BorderSizePixel = 0,
                Text = m,
                TextColor3 = Color3.fromRGB(235, 235, 240),
                TextSize = 11,
                Font = Enum.Font.Gotham,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextTruncate = Enum.TextTruncate.AtEnd,
                ZIndex = 22,
            }, ModelScroll)
            corner(b, 6)
            make("UIPadding", {PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8)}, b)
            b.Activated:Connect(function()
                state.model = m
                ModelBtn.Text = "🧠 " .. m
                ModelList.Visible = false
            end)
        end
    end
end

SearchBox:GetPropertyChangedSignal("Text"):Connect(function()
    BuildModelList(SearchBox.Text)
end)

ModelBtn.Activated:Connect(function()
    ModelList.Visible = not ModelList.Visible
    if ModelList.Visible then BuildModelList(SearchBox.Text) end
end)

-- MENSAGENS
local order = 0
local function AddMsg(role, text)
    order += 1
    local isNote = (role == "sys" or role == "tool")
    local colors = {
        user = Color3.fromRGB(42, 42, 50),
        ai = Color3.fromRGB(20, 20, 24),
        sys = Color3.fromRGB(0, 0, 0),
        tool = Color3.fromRGB(0, 0, 0),
    }
    local l = make("TextLabel", {
        LayoutOrder = order,
        Size = UDim2.new(1, -4, 0, 0),
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundColor3 = colors[role] or colors.ai,
        BackgroundTransparency = isNote and 1 or 0.25,
        BorderSizePixel = 0,
        Text = text,
        TextWrapped = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top,
        TextColor3 = isNote and Color3.fromRGB(140, 140, 150) or Color3.fromRGB(235, 235, 240),
        TextSize = isNote and 11 or 13,
        Font = Enum.Font.Gotham,
        ZIndex = 5,
    }, Log)
    make("UIPadding", {
        PaddingLeft = UDim.new(0, 7), PaddingRight = UDim.new(0, 7),
        PaddingTop = UDim.new(0, 5), PaddingBottom = UDim.new(0, 5),
    }, l)
    corner(l, 8)
    task.delay(0.06, function()
        Log.CanvasPosition = Vector2.new(0, math.max(0, Log.AbsoluteCanvasSize.Y))
    end)
end

-- RESPONSIVO
local function UpdateSize()
    local camera = workspace.CurrentCamera
    if not camera then return end
    local size = camera.ViewportSize
    Frame.Size = UDim2.fromOffset(
        math.min(340, math.max(230, size.X - 24)),
        math.min(430, math.max(240, size.Y - 40))
    )
end
UpdateSize()

local function BindCamera()
    local camera = workspace.CurrentCamera
    if camera then
        camera:GetPropertyChangedSignal("ViewportSize"):Connect(UpdateSize)
        UpdateSize()
    end
end
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(BindCamera)
BindCamera()

-- ARRASTAR
local dragging = false
local dragStart
local startPosition

Title.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPosition = Frame.Position
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if dragging and (
        input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch
    ) then
        local delta = input.Position - dragStart
        Frame.Position = UDim2.new(
            startPosition.X.Scale,
            startPosition.X.Offset + delta.X,
            startPosition.Y.Scale,
            startPosition.Y.Offset + delta.Y
        )
    end
end)

UserInputService.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = false
    end
end)

-- BOTÃO DO TOPBAR
local function FindStackedElements()
    for _, obj in ipairs(CoreGui:GetDescendants()) do
        if obj.Name == "StackedElements" and obj:IsA("GuiObject") then
            return obj
        end
    end
end

local Container
local TopbarButton
local ButtonScale
local isOpen = true
local busy = false

local function PlayTween(object, duration, style, direction, properties)
    local tween = TweenService:Create(object, TweenInfo.new(duration, style, direction), properties)
    tween:Play()
    return tween
end

local function CreateTopbarButton()
    local target = FindStackedElements()
    if not target then return false end

    local previous = target:FindFirstChild("NGCAIButtonContainer")
    if previous then previous:Destroy() end

    Container = Instance.new("Frame")
    Container.Name = "NGCAIButtonContainer"
    Container.Size = UDim2.fromOffset(52, 44)
    Container.BackgroundTransparency = 1
    Container.Parent = target
    Container.Visible = false

    TopbarButton = Instance.new("ImageButton")
    TopbarButton.Name = "ReopenNGCAI"
    TopbarButton.AnchorPoint = Vector2.new(0.5, 0.5)
    TopbarButton.Position = UDim2.fromScale(0.5, 0.5)
    TopbarButton.Size = UDim2.fromOffset(44, 44)
    TopbarButton.BackgroundColor3 = Color3.fromRGB(12, 12, 14)
    TopbarButton.BackgroundTransparency = 0.08
    TopbarButton.Image = ""
    TopbarButton.AutoButtonColor = false
    TopbarButton.Parent = Container

    Instance.new("UICorner", TopbarButton).CornerRadius = UDim.new(1, 0)

    ButtonScale = Instance.new("UIScale")
    ButtonScale.Parent = TopbarButton

    local Symbol = Instance.new("TextLabel")
    Symbol.Name = "NGCIcon"
    Symbol.AnchorPoint = Vector2.new(0.5, 0.5)
    Symbol.Position = UDim2.fromScale(0.5, 0.5)
    Symbol.Size = UDim2.fromOffset(34, 34)
    Symbol.BackgroundTransparency = 1
    Symbol.Text = "ϟ"
    Symbol.TextColor3 = Color3.new(1, 1, 1)
    Symbol.TextSize = 32
    Symbol.Font = Enum.Font.GothamBold
    Symbol.Parent = TopbarButton

    TopbarButton.Activated:Connect(function()
        if busy or isOpen then return end
        busy = true

        PlayTween(ButtonScale, 0.16, Enum.EasingStyle.Quint,
            Enum.EasingDirection.In, {Scale = 0.05}).Completed:Wait()

        Container.Visible = false
        ButtonScale.Scale = 1

        Frame.Position = UDim2.fromScale(0.5, 0.5)
        FrameScale.Scale = 0.05
        Frame.Visible = true
        isOpen = true

        PlayTween(FrameScale, 0.38, Enum.EasingStyle.Back,
            Enum.EasingDirection.Out, {Scale = 1}).Completed:Once(function()
            busy = false
        end)
    end)

    return true
end

local function ShowTopbarButton()
    if not (Container and Container.Parent) then return end
    Container.Visible = true
    ButtonScale.Scale = 0.05
    PlayTween(ButtonScale, 0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out, {Scale = 1})
end

Close.Activated:Connect(function()
    if busy or not isOpen then return end
    busy = true
    isOpen = false

    PlayTween(FrameScale, 0.28, Enum.EasingStyle.Quint,
        Enum.EasingDirection.In, {Scale = 0.05}).Completed:Wait()

    Frame.Visible = false
    FrameScale.Scale = 1

    if CreateTopbarButton() then
        ShowTopbarButton()
    end

    busy = false
end)

task.spawn(function()
    while Screen.Parent do
        if not (Container and Container.Parent) then
            if CreateTopbarButton() and not isOpen then
                ShowTopbarButton()
            end
        end
        task.wait(1)
    end
end)

----------------------------------------------------------------
-- FERRAMENTAS (a IA enxerga o jogo)
----------------------------------------------------------------
local function Resolve(path)
    path = tostring(path or "Workspace")
    local cur = game
    for seg in path:gmatch("[^%.]+") do
        if seg ~= "game" then
            local nxt = cur:FindFirstChild(seg)
            if not nxt and cur == game then
                local ok, svc = pcall(game.GetService, game, seg)
                if ok then nxt = svc end
            end
            if not nxt then
                return nil, "não achei '" .. seg .. "' em " .. cur:GetFullName()
            end
            cur = nxt
        end
    end
    return cur
end

local Tools = {}

Tools.tree = function(a)
    local root, err = Resolve(a.path)
    if not root then return err end
    local depth = math.clamp(tonumber(a.depth) or 2, 1, 6)
    local lines, count = {}, 0
    local function walk(o, d)
        for _, c in ipairs(o:GetChildren()) do
            count += 1
            if count > 250 then return end
            lines[#lines + 1] = string.rep("  ", d - 1) .. c.Name .. " [" .. c.ClassName .. "]"
            if d < depth then walk(c, d + 1) end
        end
    end
    walk(root, 1)
    return root:GetFullName() .. "\n" .. table.concat(lines, "\n") .. (count > 250 and "\n...[limite 250]" or "")
end

local PROPS = {
    "Name", "ClassName", "Parent", "Position", "Size", "CFrame", "Orientation", "Color", "Material",
    "Transparency", "Anchored", "CanCollide", "Text", "Value", "Enabled", "Visible", "Health",
    "MaxHealth", "WalkSpeed", "JumpPower", "Velocity", "Mass", "Shape",
}

Tools.props = function(a)
    local o, err = Resolve(a.path)
    if not o then return err end
    local lines = {}
    for _, p in ipairs(PROPS) do
        local ok, v = pcall(function() return o[p] end)
        if ok and v ~= nil then
            lines[#lines + 1] = p .. " = " .. tostring(v)
        end
    end
    local okA, attrs = pcall(function() return o:GetAttributes() end)
    if okA then
        for k, v in pairs(attrs) do
            lines[#lines + 1] = "@" .. k .. " = " .. tostring(v)
        end
    end
    lines[#lines + 1] = "filhos: " .. #o:GetChildren()
    return table.concat(lines, "\n")
end

Tools.source = function(a)
    local o, err = Resolve(a.path)
    if not o then return err end
    if not o:IsA("LuaSourceContainer") then return "não é um script" end
    local ok, src = false, nil
    if decompile then ok, src = pcall(decompile, o) end
    if not ok or type(src) ~= "string" or src == "" then
        ok, src = pcall(function() return o.Source end)
    end
    if ok and type(src) == "string" and src ~= "" then return src end
    return "não foi possível ler o código"
end

Tools.find = function(a)
    local root, err = Resolve(a.path or "game")
    if not root then return err end
    local name = tostring(a.query or ""):lower()
    local class = a.class
    local out = {}
    for _, o in ipairs(root:GetDescendants()) do
        local okName = (name == "") or o.Name:lower():find(name, 1, true)
        local okClass = (not class) or o:IsA(class)
        if okName and okClass then
            out[#out + 1] = o:GetFullName() .. " [" .. o.ClassName .. "]"
            if #out >= 40 then break end
        end
    end
    if #out == 0 then return "nada encontrado" end
    return table.concat(out, "\n")
end

Tools.players = function()
    local out = {}
    for _, p in ipairs(Players:GetPlayers()) do
        local pos, hp = "?", "?"
        local ch = p.Character
        if ch then
            local r = ch:FindFirstChild("HumanoidRootPart")
            local h = ch:FindFirstChildOfClass("Humanoid")
            if r then pos = tostring(r.Position) end
            if h then hp = tostring(math.floor(h.Health)) end
        end
        out[#out + 1] = p.Name .. " (" .. p.DisplayName .. ") pos=" .. pos .. " hp=" .. hp
    end
    return table.concat(out, "\n")
end

Tools.run = function(a)
    if not state.exec then
        return "execução desativada pelo usuário (botão Exec)"
    end
    local fn, err = loadstring(tostring(a.code or ""))
    if not fn then return "erro de sintaxe: " .. tostring(err) end
    local logs = {}
    local base = getfenv(1)
    local env = setmetatable({
        print = function(...)
            local t = {}
            for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
            logs[#logs + 1] = table.concat(t, " ")
        end,
    }, {__index = base})
    pcall(setfenv, fn, env)
    local ok, res = pcall(fn)
    local out = table.concat(logs, "\n")
    if not ok then out = out .. "\nerro: " .. tostring(res)
    elseif res ~= nil then out = out .. "\nretorno: " .. tostring(res) end
    if out == "" then out = "ok (sem saída)" end
    return out
end

local function RunTool(body)
    local ok, call = pcall(HttpService.JSONDecode, HttpService, body)
    if not ok or type(call) ~= "table" then
        return "<result>JSON inválido</result>"
    end
    local name = tostring(call.name)
    local fn = Tools[name]
    if not fn then
        return '<result name="' .. name .. '">ferramenta desconhecida</result>'
    end
    local ok2, out = pcall(fn, call)
    out = tostring(out)
    if not ok2 then out = "erro: " .. out end
    if #out > 6000 then out = out:sub(1, 6000) .. "\n...[cortado]" end
    return '<result name="' .. name .. '">' .. out .. "</result>"
end

local function Context()
    local ok, s = pcall(function()
        local ch = LocalPlayer.Character
        local root = ch and ch:FindFirstChild("HumanoidRootPart")
        return string.format(
            "[contexto] Jogador: %s (id %d) | PlaceId: %d | Jogo: %s | Players: %d | Pos: %s",
            LocalPlayer.Name, LocalPlayer.UserId, game.PlaceId, game.Name,
            #Players:GetPlayers(), root and tostring(root.Position) or "?"
        )
    end)
    return ok and s or ""
end

----------------------------------------------------------------
-- RELAY (ntfy) COM O APP
----------------------------------------------------------------
local function utf8Chunks(s, size)
    local out, pos, len = {}, 1, #s
    if len == 0 then return {""} end
    while pos <= len do
        local stop = math.min(pos + size - 1, len)
        while stop < len and stop > pos do
            local b = s:byte(stop + 1)
            if b >= 0x80 and b <= 0xBF then stop -= 1 else break end
        end
        out[#out + 1] = s:sub(pos, stop)
        pos = stop + 1
    end
    return out
end

local function publish(kind, id, payload)
    if not httpRequest then return end
    local parts = utf8Chunks(payload, CHUNK)
    for i, p in ipairs(parts) do
        pcall(httpRequest, {
            Url = RELAY .. "/" .. TOPIC_OUT,
            Method = "POST",
            Headers = {["Content-Type"] = "text/plain; charset=utf-8"},
            Body = kind .. "|" .. id .. "|" .. i .. "|" .. #parts .. "\n" .. p,
        })
    end
end

local pending = {}
local bufs = {}
local seen = {}
local lastSince = tostring(os.time() - 60)
local nextPoll = 0

local function guid()
    return HttpService:GenerateGUID(false):gsub("-", ""):sub(1, 8)
end

local function onMessage(kind, id, full)
    if kind == "hello" then
        local ok, d = pcall(HttpService.JSONDecode, HttpService, full)
        if not ok or type(d) ~= "table" then return end
        state.models = d.models or {}
        state.provider = d.provider or "?"
        local found = false
        for _, m in ipairs(state.models) do
            if m == state.model then found = true break end
        end
        if not found then state.model = d.model or state.models[1] or "" end
        ModelBtn.Text = "🧠 " .. state.model
        BuildModelList(SearchBox.Text)
        if not state.connected then
            state.connected = true
            Waiting.Visible = false
            Chat.Visible = true
            AddMsg("sys", "Conectado: " .. state.provider .. " · " .. #state.models .. " modelos")
        end
    elseif kind == "reply" then
        if pending[id] == false then
            local ok, d = pcall(HttpService.JSONDecode, HttpService, full)
            pending[id] = (ok and type(d) == "table") and d or {ok = false, error = "resposta inválida"}
        end
    end
end

local function handleRaw(m)
    local nl = m:find("\n", 1, true)
    if not nl then return end
    local kind, id, i, n = m:sub(1, nl - 1):match("^(%w+)|([^|]+)|(%d+)|(%d+)$")
    if not kind then return end
    i, n = tonumber(i), tonumber(n)
    local b = bufs[id]
    if not b then
        b = {n = n, got = 0, parts = {}}
        bufs[id] = b
    end
    if not b.parts[i] then
        b.parts[i] = m:sub(nl + 1)
        b.got += 1
    end
    if b.got >= b.n then
        bufs[id] = nil
        onMessage(kind, id, table.concat(b.parts, "", 1, b.n))
    end
end

local function poll()
    if not httpRequest then return end
    local ok, res = pcall(httpRequest, {
        Url = RELAY .. "/" .. TOPIC_IN .. "/json?poll=1&since=" .. lastSince,
        Method = "GET",
    })
    if not ok or not res or res.StatusCode ~= 200 then return end
    for line in string.gmatch(res.Body or "", "[^\n]+") do
        local okj, j = pcall(HttpService.JSONDecode, HttpService, line)
        if okj and type(j) == "table" and j.event == "message" and j.id and not seen[j.id] then
            seen[j.id] = true
            lastSince = j.id
            handleRaw(j.message or "")
        end
    end
end

local function ask(text, reset)
    local id = guid()
    local payload = {id = id, model = state.model, text = text}
    if reset then
        payload.reset = true
        payload.system = SYSTEM
    end
    pending[id] = false
    state.waiting = true
    nextPoll = os.clock() + 2
    publish("chat", id, HttpService:JSONEncode(payload))
    local t0 = os.clock()
    while pending[id] == false and os.clock() - t0 < 150 do
        task.wait(0.4)
    end
    state.waiting = false
    local r = pending[id]
    pending[id] = nil
    if not r then return false, "tempo esgotado (app fechado?)" end
    if not r.ok then return false, r.error or "erro" end
    return true, r.text
end

task.spawn(function()
    if not httpRequest then return end
    publish("ping", guid(), "{}")
    local lastPing = os.clock()
    while Screen.Parent do
        if os.clock() >= nextPoll then
            poll()
            local interval = state.waiting and 2.5 or (state.connected and 20 or 5)
            nextPoll = os.clock() + interval
        end
        if not state.connected and os.clock() - lastPing > 60 then
            lastPing = os.clock()
            publish("ping", guid(), "{}")
        end
        task.wait(0.5)
    end
end)

if not httpRequest then
    Waiting.Text = "Seu executor não tem função de request (http_request/request). Não dá pra conectar com o app."
end

----------------------------------------------------------------
-- LÓGICA DO CHAT
----------------------------------------------------------------
local needReset = true
local chatBusy = false

local function Run(text)
    if chatBusy then return end
    chatBusy = true
    local toSend = text
    if needReset then toSend = Context() .. "\n\n" .. text end
    local finished = false
    for round = 1, MAX_ROUNDS do
        local ok, out = ask(toSend, needReset)
        needReset = false
        if not ok then
            AddMsg("sys", "⚠ " .. tostring(out))
            finished = true
            break
        end
        local calls = {}
        for body in out:gmatch("<tool>(.-)</tool>") do
            calls[#calls + 1] = body
        end
        local shown = out:gsub("<tool>.-</tool>", "")
        shown = shown:match("^%s*(.-)%s*$")
        if shown ~= "" then AddMsg("ai", shown) end
        if #calls == 0 then
            finished = true
            break
        end
        local results = {}
        for _, c in ipairs(calls) do
            AddMsg("tool", "🔧 " .. c:sub(1, 120))
            results[#results + 1] = RunTool(c)
        end
        toSend = table.concat(results, "\n")
    end
    if not finished then
        AddMsg("sys", "limite de " .. MAX_ROUNDS .. " rodadas de ferramentas atingido")
    end
    chatBusy = false
end

local function Submit()
    local text = Input.Text:match("^%s*(.-)%s*$")
    if text == "" or not state.connected or chatBusy then return end
    Input.Text = ""
    AddMsg("user", text)
    task.spawn(Run, text)
end

SendBtn.Activated:Connect(Submit)
Input.FocusLost:Connect(function(enter)
    if enter then Submit() end
end)

NewBtn.Activated:Connect(function()
    if chatBusy then return end
    for _, c in ipairs(Log:GetChildren()) do
        if c:IsA("TextLabel") then c:Destroy() end
    end
    needReset = true
    AddMsg("sys", "Nova conversa")
end)

ExecBtn.Activated:Connect(function()
    state.exec = not state.exec
    ExecBtn.Text = state.exec and "Exec: ON" or "Exec: OFF"
    ExecBtn.TextColor3 = state.exec and Color3.fromRGB(255, 120, 120) or Color3.fromRGB(235, 235, 240)
end)

print("[NGC AI] carregado. Aguardando app para @" .. LocalPlayer.Name)
