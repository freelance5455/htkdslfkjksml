// Serves the bundled English text data to the reader without any network download.
importScripts('eng-data.js');
(function(){
  var realFetch = self.fetch ? self.fetch.bind(self) : null;
  self.fetch = function(url, opts){
    if (String(url).indexOf('eng.traineddata') !== -1) {
      var bin = atob(self.ENG_GZ_B64), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return Promise.resolve(new Response(bytes, {status: 200}));
    }
    return realFetch(url, opts);
  };
})();
importScripts('worker.min.js');
