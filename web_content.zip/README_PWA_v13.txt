NaKlik PWA v13 — paket za postavljanje

SADRŽAJ
- index.html: postojeća NaKlik aplikacija sa PWA podrškom
- manifest.webmanifest: ime aplikacije, boja i ikone
- service-worker.js: keširanje osnovnog interfejsa i offline fallback
- icons/: ikone aplikacije

KAKO POSTAVITI
1. Postavi SVE fajlove i folder icons na isti hosting/folder.
2. Hosting mora da koristi HTTPS (localhost je dozvoljen samo za lokalni razvoj).
3. Otvori HTTPS adresu na telefonu.
4. U Chrome-u izaberi „Instaliraj aplikaciju“ ili meni ⋮ > „Dodaj na početni ekran“.
5. Prvo otvaranje treba da bude online kako bi se keširali osnovni fajlovi.

VAŽNA OGRANIČENJA
- Offline keš omogućava otvaranje osnovnog interfejsa; nije potpuni offline režim.
- Prijava, pretraga serverskih oglasa, poruke i rezervacije i dalje zahtevaju internet i ispravno podešen Supabase.
- Ovaj paket ne aktivira push obaveštenja kada je aplikacija zatvorena.
- Ne postavljaj Supabase service_role/secret ključ u HTML. Koristi samo anon/publishable ključ.
- Aplikacija je PWA paket za testiranje, ne objavljena aplikacija u prodavnici.
