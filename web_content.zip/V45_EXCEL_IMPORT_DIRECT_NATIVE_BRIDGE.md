# V45 — Excel Import Direct Native Bridge

Based on V44.

- Choose File on Android now calls an explicit `AndroidDPM.pickImportFile()` bridge directly; it no longer depends on WebView `onShowFileChooser`.
- Download Excel Template on Android writes directly to the public Downloads collection on Android 10+ using MediaStore.
- Web keeps the normal file-input and browser-download fallbacks.
- Native Android XLSX/CSV parsing and the existing Supabase batch-import flow are preserved.
- Android versionCode 17 / versionName 2.13.
