# Sample content licence

The six original demonstration works shipped with Jesma Novels are offered under the Creative Commons Attribution 4.0 International licence (CC BY 4.0).

You may share and adapt these demonstration works, including commercially, provided appropriate attribution is given and changes are indicated.

Attribution should identify the work title, the demonstration author name shown in the app, Jesma Novels as the demo collection, and the CC BY 4.0 licence.

Licence: https://creativecommons.org/licenses/by/4.0/

This licence applies only to the sample demonstration works. It does not apply to content uploaded by users. User-created works remain the property of their respective creators.
