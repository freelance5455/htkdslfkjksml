DAILY WAGES - Starter Version

Files:
- index.html: app screens
- styles.css: responsive design
- app.js: worker/site records and local save
- manifest.json: installable web app metadata
- sw.js: offline app shell cache

Current features:
- Two home-page boxes only
- Add/edit/delete workers
- Monthly date list and wage amount per worker
- Share monthly worker summary through WhatsApp
- Add work locations
- Income/expense entries with automatic totals
- Finish and archive completed work
- Local browser storage and offline app shell

Important limitations:
- This starter saves records locally in the browser/device.
- Gmail/mobile registration, secure cloud database, cross-device sync,
  conflict handling and automated cloud backup are NOT configured yet.
- Do not use this as the only copy of important financial records.
- For testing, serve over HTTPS or localhost; service workers do not work
  reliably when opening index.html directly from a file manager.
