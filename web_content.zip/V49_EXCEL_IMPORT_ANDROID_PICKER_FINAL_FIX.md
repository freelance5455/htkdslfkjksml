# V48 – Excel Import Android Bridge Root Fix

Based directly on V47.

## Root cause
The Android HTML and native bridge did not use one consistent picker path. The Choose File UI could fall back to a WebView input and remain on “Opening file picker…”.

## Fix
- Choose File in Android explicitly calls `AndroidDPM.pickImportFile()`.
- `pickImportFile()` is actually exposed by `MainActivity.AndroidBridge`.
- Android opens ACTION_OPEN_DOCUMENT on the UI thread, with ACTION_GET_CONTENT fallback.
- The selected URI is parsed by the existing native XLSX/CSV parser.
- The URI is also returned to any WebView file callback.
- Import preview and existing Supabase batch insertion remain unchanged.
- Version code bumped to 20 / version 2.16.
