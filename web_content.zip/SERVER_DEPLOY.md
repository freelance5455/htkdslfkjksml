# AliChat V3.6 server

This directory contains the backend that the APK connects to. The APK does **not** execute `server.js` itself.

## Fastest deployment with Docker

1. Install Docker on a VPS/server.
2. Copy this project to the server.
3. Copy `.env.example` to `.env` and set VAPID keys if Push is needed.
4. Run:

```bash
docker compose up -d --build
```

The API/WebSocket server listens on port 3000.

## APK server address

Set the APK's Server URL to the public HTTPS address of this server, for example:

`https://chat.example.com`

The app automatically derives the WebSocket endpoint as `wss://chat.example.com/ws`.

For a direct IP deployment without TLS, use `http://SERVER_IP:3000`; WebSocket becomes `ws://SERVER_IP:3000/ws`. HTTPS/WSS is recommended for production.

## Important

The included SQLite database is stored in `alichat.db`. The project is PostgreSQL/Redis-ready, but those services are not required for the initial deployment.
