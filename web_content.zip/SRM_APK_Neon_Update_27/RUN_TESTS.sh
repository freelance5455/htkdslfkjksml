#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for test in tests/*.test.cjs; do node "$test"; done
