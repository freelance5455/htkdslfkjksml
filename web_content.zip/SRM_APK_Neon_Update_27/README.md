## Update 20 (2026-10-14)
- Added a GitHub Actions workflow that runs regression tests, checks Android asset parity, builds the debug APK with JDK 17/Gradle 8.7/Android SDK, and publishes the APK as a downloadable workflow artifact.
- Added a single-command Android asset synchronizer and parity test; fixed missing `local-engine/` documents in the Android bundle so service-worker precache paths exist.
- Advanced Android version to 20.0 and refreshed the offline cache version.

# SRM APK — AI Creative Studio (Update 27)

A local-first creative studio PWA with an AI Horde cloud Text-to-Image test engine. Update 27 adds service-worker registration error details to exported device diagnostics and explicitly installs Android SDK platform 35/build-tools 35.0.0 in CI before compiling. The shell precaches the explicit index document instead of a fragile directory URL, and the Android build script checks required SDK packages before building. Android APK build/device testing is still required; passing source tests are not proof of a compiled APK or successful live generation.

## Existing app safeguards and features

- Search saved local projects by title, prompt, workflow, or brief text. Search only filters the visible list; it does not alter saved records.

- Reject malformed MIME strings in native task smoke-test evidence; valid evidence must include `passed: true`, a positive safe-integer `outputBytes`, and a syntactically valid MIME type.
- Protect asynchronous model-manifest loading against stale file-read completions, so an older selection cannot overwrite a newer selection.
- Protect asynchronous SHA-256 verification against stale jobs when another weights file is selected or model-session metadata is cleared.
- Correct app title, diagnostics version, and service-worker shell cache version to Update 20.
- Add regression coverage for MIME evidence validation and key release/version invariants.

## Android host foundation

- Added an Android Gradle project scaffold (`android/`) that packages the local studio UI as app assets and opens it with AndroidX WebViewAssetLoader.
- Added a constrained WebView host: file/content URL access disabled, mixed content blocked, external navigation blocked, WebView debugging disabled, a tightly constrained JavaScript-to-native Downloads bridge, and network permission only for the cloud image test engine.
- Added system document-picker support for local file inputs.
- The native shell is a foundation only: it does not provide AI inference, signing keys, Gradle wrapper, or a verified APK. Build/device validation requires Android SDK + Gradle and should be performed before release.

## Current capabilities

**Implemented in the app:** deterministic prompt/brief structuring, project save/import/export, local media preview, local Canvas 2D image adjustments, model-manifest metadata validation, browser SHA-256 verification (up to 512 MiB, memory-intensive), capability diagnostics, and an AI Horde cloud Text-to-Image test engine. Android 10+ exports can use the guarded native Downloads bridge.

**Not implemented / not verified:** bundled/offline model weights, local AI inference, Text-to-Video/Image-to-Video/Audio Lip Sync synthesis, live success of cloud image generation, and a compiled/installable APK. An Android Gradle project is present, but this environment has no available Gradle/Android SDK build result or inference runtime. A model manifest or bridge report is not proof of genuine inference. The cloud image test sends prompts to AI Horde only when the user invokes that feature; prompt sharing depends on the provider and request settings.

## Android assets and CI build

Run `./SYNC_ANDROID_ASSETS.sh` after changing the web UI, service worker, manifest, changelog, or local-engine documentation. Run `./SYNC_ANDROID_ASSETS.sh --check` to verify the Android bundle matches the web source. The GitHub Actions workflow runs the tests and builds a debug APK on pushes to `main`/`master`, pull requests, or manual dispatch. Download the APK from the workflow run’s **Artifacts** section; this repository snapshot itself has not produced an APK.

## Run locally

Serve the folder on `localhost` or HTTPS for service-worker and Web Crypto features. For example, with Node.js installed:

```sh
npx http-server . -p 8080
```

Then open `http://localhost:8080`.

## Tests

```sh
node tests/project-schema.test.cjs
node tests/engine-contract.test.cjs
node tests/project-search.test.cjs
node tests/android-host.test.cjs
node tests/android-assets.test.cjs
node --check service-worker.js
```

The test suite checks source-level invariants and pure validation helpers; it is not a physical-device or AI inference test.

## Privacy and limits

Image Lab processing is performed in-browser. Project metadata is stored in localStorage. Project backups contain project data, not embedded media. Diagnostics omit prompts, project contents, and media bytes. The service worker caches the app shell only. The browser weight verifier reads the selected file into memory; use native streaming verification for large model files.


### Update 21: Text-to-Image test
Open the app and scroll to **Text-to-Image Test Engine**. Enter a prompt and tap **Generate image**. Internet is required. Anonymous AI Horde jobs are low priority and may queue; an optional personal AI Horde API key can improve priority. The prompt is sent to AI Horde, and anonymous requests may be shared. This is cloud inference, not an offline model.


### Update 22: Text-to-image troubleshooting
The Text-to-Image Test Engine now includes **Check service & models** and **Refresh models**. Check connectivity first, then choose a model that appears in the live list. If a request hangs, it times out instead of waiting forever; temporary queue polling failures retry automatically. Generation still requires internet and AI Horde workers, and anonymous requests may be shared.


### Update 25: Native export payload validation
- Android Downloads now validates PNG/JPEG/WebP signatures and rejects MIME/payload mismatches.
- Plain-text and JSON exports must be valid UTF-8; JSON exports must parse as one complete JSON value.
- Downloads reports success only after MediaStore finalization succeeds; failed saves are cleaned up.
- Bumped Android version, diagnostics, cloud client identifier and service-worker cache to 25.
- Source tests only; no compiled APK or physical-device verification is claimed.

The Android host now routes service-worker requests through WebViewAssetLoader and exposes a narrow save bridge for PNG/JPEG/WebP, text and JSON files. The bridge accepts calls only after the bundled app origin has loaded, sanitizes filenames, limits file size to 20 MiB, and writes to Downloads on Android 10+. Older Android versions or failed native saves fall back to browser download behavior. Planning quality is explicitly marked as not rendered, and video duration is hidden for non-video workflows.


## Update 27 status and remaining work

- Added registration-error details to local diagnostics so an absent service-worker registration is distinguishable from a lookup exception.
- CI explicitly installs Android platform 35 and build-tools 35.0.0 before the Gradle build.
- Source regression checks validate release metadata, diagnostic fields and SDK preflight.
- **Not yet verified:** CI execution, compiled APK, phone installation, service-worker behavior on device, cloud image-generation success, and native/offline AI inference.
