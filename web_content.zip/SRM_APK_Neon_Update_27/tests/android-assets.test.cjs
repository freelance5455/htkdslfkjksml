const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.join(__dirname, '..');
const assets = path.join(root, 'android/app/src/main/assets');
for (const file of ['index.html', 'service-worker.js', 'manifest.json', 'README.md', 'CHANGELOG.md', 'local-engine-INTEGRATION.txt']) {
  assert.equal(fs.readFileSync(path.join(root, file), 'utf8'), fs.readFileSync(path.join(assets, file), 'utf8'), `${file} must be synchronized into Android assets`);
}
for (const file of ['INTEGRATION_PLAN.txt', 'model-manifest.example.json', 'ANDROID_BRIDGE_CONTRACT.md']) {
  assert.ok(fs.existsSync(path.join(assets, 'local-engine', file)), `missing offline-cached local-engine asset: ${file}`);
}
assert.match(fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8'), /srm-apk-shell-v27/);
console.log('Android asset sync tests passed: web shell and offline-cached engine docs are bundled.');
