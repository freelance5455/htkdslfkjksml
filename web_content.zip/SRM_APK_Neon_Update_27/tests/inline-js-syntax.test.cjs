const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync('index.html', 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
assert.ok(scripts.length > 0, 'HTML should contain inline application scripts');
let checked = 0;
for (const [index, match] of scripts.entries()) {
  const source = match[1].trim();
  if (!source) continue;
  assert.doesNotThrow(() => new vm.Script(source, { filename: `index-inline-${index}.js` }), `inline script ${index} must parse`);
  checked++;
}
assert.ok(checked > 0, 'at least one non-empty inline script should be checked');
console.log(`Inline JavaScript syntax test passed (${checked} script blocks).`);
