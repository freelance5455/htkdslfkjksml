const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');

const match = html.match(/function isValidMimeType\(value\)\s*\{[^}]*\}/);
assert.ok(match, 'MIME validator must exist in app source');
const context = {};
vm.createContext(context);
vm.runInContext(`${match[0]}; this.isValidMimeType = isValidMimeType;`, context);
const valid = ['image/png', 'video/mp4', 'audio/mpeg', 'application/octet-stream', 'model/vnd.example+json'];
for (const mime of valid) assert.equal(context.isValidMimeType(mime), true, `${mime} should be valid`);
const invalid = ['', 'image', '/png', 'image/', 'image/png\nmalicious', 'image/png; charset=utf-8', 'image/png '.repeat(20)];
for (const mime of invalid) assert.equal(context.isValidMimeType(mime), false, `${JSON.stringify(mime)} should be invalid`);
assert.equal(context.isValidMimeType(null), false);

assert.match(html, /manifestLoadToken/);
assert.match(html, /weightsVerificationToken/);
assert.match(html, /update:"27"/);
assert.match(html, /SRM-APK-Update-27-diagnostics\.json/);
assert.match(html, /AI Creative Studio Update 27/);
assert.match(sw, /srm-apk-shell-v27/);
assert.doesNotMatch(sw, /srm-apk-shell-v15/);
console.log('Engine contract tests passed: MIME validation, stale async guards, and current release invariants.');
