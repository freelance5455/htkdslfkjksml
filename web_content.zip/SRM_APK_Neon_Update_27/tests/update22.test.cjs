const assert=require('node:assert/strict'),fs=require('node:fs');
const html=fs.readFileSync('index.html','utf8'),gradle=fs.readFileSync('android/app/build.gradle.kts','utf8'),sw=fs.readFileSync('service-worker.js','utf8');
assert.match(gradle,/versionCode\s*=\s*27/);assert.match(gradle,/versionName\s*=\s*"27\.0"/);
assert.match(html,/api\/v2\/status\/heartbeat/);assert.match(html,/api\/v2\/status\/models\?type=image/);assert.match(html,/t2iModel/);assert.match(html,/Request timed out after 25 seconds/);assert.match(html,/after 3 attempts/);assert.match(html,/lastBlob\.type/);assert.match(sw,/srm-apk-shell-v27/);
assert.match(fs.readFileSync('android/app/src/main/assets/index.html','utf8'),/Check service &amp; models/);
console.log('Cloud service diagnostics, model discovery, timeout/retry and release checks passed');
