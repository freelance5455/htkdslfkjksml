## Update 26 (2026-10-14)

- Removed the fragile `./` directory URL from the service-worker precache list; the explicit `./index.html` entry remains, reducing install-time cache failure risk in Android WebViewAssetLoader.
- Bumped Android version, diagnostics metadata, mobile-test storage key, and service-worker cache to 26.
- Strengthened the Android build script with asset parity, regression, JavaScript syntax, APK existence, and SHA-256 checks.
- Added Update 26 regression coverage for the explicit offline shell precache contract.
- Validation is source-level only; this environment still has no Gradle executable or Android SDK, so no compiled APK/device test is claimed.

## Update 25 (2026-10-14)

- Hardened Android Downloads exports by validating PNG/JPEG/WebP signatures against declared MIME types.
- Require valid UTF-8 for text/JSON exports and a complete parseable JSON value for JSON files.
- Report save success only after MediaStore clears `IS_PENDING`; failed saves attempt to remove incomplete files.
- Bumped Android version to 25.0, diagnostics metadata, AI Horde client identifier, and service-worker cache.
- Added regression tests for native payload validation and current release metadata.
- Validation is source-level only; APK compilation and physical-device tests are not claimed.

## Update 24 (2026-10-14)

- Fixed the creative brief export button to use the shared Android-aware file save helper.
- Surface native Downloads bridge failure reasons in the UI instead of implying the file was definitely saved.
- Improve generated-image download failure messaging when browser/native download paths do not complete.
- Bumped Android version to 24.0, diagnostics, cloud client identifier and service-worker cache.
- Verification is source-level only; APK compilation and physical-device tests are not claimed.

## Update 23 (2026-10-14)
- Routed Android WebView service-worker requests through WebViewAssetLoader to improve offline app-shell caching.
- Added a constrained native Downloads bridge for supported image, text and JSON exports on Android 10+, with trusted-origin checks, filename sanitization and a 20 MiB limit. Browser downloads remain the fallback.
- Improved service-worker failure diagnostics; marked quality options as planning-only and hid video duration for non-video workflows.
- Bumped Android version and service-worker cache to 23; synchronized bundled assets and added regression tests.
- Validation is source-level only unless a compiled APK and device test are separately reported.

## Update 20 (2026-10-14)
- Fixed stale diagnostics metadata: exported reports now correctly identify Update 20 and use the matching filename.
- Aligned the Local Inference Bridge badge, app title, and Android version metadata with Update 20.
- Bumped the offline shell cache to v20 so browsers replace stale cached app assets.
- Added regression tests that reject stale release identifiers and verify diagnostics metadata.

## Update 19 (2026-10-14)
- Added a GitHub Actions workflow that runs regression tests, checks Android asset parity, builds the debug APK with JDK 17/Gradle 8.7/Android SDK, and publishes the APK as a downloadable workflow artifact.
- Added a single-command Android asset synchronizer and parity test; fixed missing `local-engine/` documents in the Android bundle so service-worker precache paths exist.
- Advanced Android version to 19.0 and refreshed the offline cache version.

## Update 18 (2026-10-14)
- Improved Android WebView document-picker MIME handling and multiple-file selection.
- Added regression checks and a local Android build helper.


## Update 21 — Text-to-Image cloud test engine
- Added a real AI Horde text-to-image request flow with job polling, progress, queue status, error handling, preview, open-original and download actions.
- Supports 512x512, 512x768 and 768x512, bounded steps, optional negative prompt, and optional user API key held only in page memory.
- Anonymous mode uses the documented public low-priority key; anonymous prompts may be shared. Cloud generation requires internet and is not offline/local inference.
- Added Android INTERNET permission and synchronized the app shell assets.
- Validation covers static contract and package integrity; live provider execution and APK compilation were not available in this build environment.


## Update 22 — Text-to-image engine reliability
- Added a live AI Horde heartbeat check and refreshable image-model list with worker counts, so users can choose a model that is currently listed by the service.
- Added a 25-second request timeout and retry handling for temporary queue-polling network errors.
- Improved generated-image download filenames by respecting the returned image MIME type.
- Bumped Android version and service-worker cache to 22; synchronized bundled assets.


## Update 27 (2026-10-14)

- Exported device diagnostics now retain the service-worker registration failure reason and report registration/control state explicitly.
- Fixed stale diagnostics status copy to identify Update 27.
- Android CI explicitly installs platform-tools, Android SDK platform 35, and build-tools 35.0.0 before Gradle compilation.
- Added regression coverage for service-worker diagnostics and required SDK packages.
- Static source validation only; CI has not been run from this environment and no compiled APK/device test is claimed.
