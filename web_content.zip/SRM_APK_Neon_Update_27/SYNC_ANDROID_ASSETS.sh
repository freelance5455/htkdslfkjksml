#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT"
DEST="$ROOT/android/app/src/main/assets"
FILES=(index.html service-worker.js manifest.json README.md CHANGELOG.md local-engine-INTEGRATION.txt)
MODE="${1:-sync}"
if [[ "$MODE" != "sync" && "$MODE" != "--check" ]]; then
  echo "Usage: $0 [--check]" >&2
  exit 2
fi
mkdir -p "$DEST"
failed=0
for file in "${FILES[@]}"; do
  if [[ "$MODE" == "--check" ]]; then
    if ! cmp -s "$SRC/$file" "$DEST/$file"; then
      echo "Asset out of sync: $file"
      failed=1
    fi
  else
    cp "$SRC/$file" "$DEST/$file"
  fi
done
if [[ "$MODE" == "--check" ]]; then
  if [[ -d "$SRC/local-engine" ]]; then
    while IFS= read -r -d '' file; do
      rel="${file#"$SRC/"}"
      if ! cmp -s "$SRC/$rel" "$DEST/$rel"; then
        echo "Asset out of sync: $rel"
        failed=1
      fi
    done < <(find "$SRC/local-engine" -type f -print0)
    while IFS= read -r -d '' file; do
      rel="${file#"$DEST/"}"
      if [[ ! -f "$SRC/$rel" ]]; then
        echo "Unexpected bundled asset: $rel"
        failed=1
      fi
    done < <(find "$DEST/local-engine" -type f -print0 2>/dev/null || true)
  fi
  [[ "$failed" -eq 0 ]] || exit 1
  echo "Android bundled web assets are in sync."
else
  rm -rf "$DEST/local-engine"
  if [[ -d "$SRC/local-engine" ]]; then cp -R "$SRC/local-engine" "$DEST/local-engine"; fi
  echo "Android bundled web assets synchronized."
fi
