package com.srm.creative

import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONTokener
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.ServiceWorkerClientCompat
import androidx.webkit.ServiceWorkerControllerCompat
import androidx.webkit.WebViewClientCompat

class MainActivity : ComponentActivity() {
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var studioWebView: WebView? = null
    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = pendingFileCallback
        pendingFileCallback = null
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val uris = when {
                data?.clipData != null -> (0 until data.clipData!!.itemCount).map { data.clipData!!.getItemAt(it).uri }.toTypedArray()
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            callback?.onReceiveValue(uris)
        } else callback?.onReceiveValue(null)
    }

    private inner class AndroidDownloadsBridge {
        @Volatile private var trustedOrigin = false

        fun updateOrigin(url: String?) {
            val page = runCatching { Uri.parse(url ?: "") }.getOrNull()
            trustedOrigin = page?.scheme == "https" && page.host == "appassets.androidplatform.net" && page.path?.startsWith("/assets/") == true
        }

        @JavascriptInterface
        fun saveFile(rawName: String?, rawMime: String?, encoded: String?): String {
            // Only the bundled app origin is trusted; external navigation remains blocked.
            if (!trustedOrigin) return "ERROR:untrusted app origin"
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "UNSUPPORTED:Android 10 or newer required for direct Downloads saving"
            val mime = rawMime?.lowercase()?.trim() ?: return "ERROR:missing file type"
            val allowed = setOf("image/png", "image/jpeg", "image/webp", "text/plain", "application/json")
            if (mime !in allowed) return "ERROR:file type not allowed"
            val data = encoded ?: return "ERROR:missing file data"
            if (data.length > 28_000_000) return "ERROR:file exceeds 20 MB limit"
            val bytes = try { Base64.decode(data, Base64.DEFAULT) } catch (_: IllegalArgumentException) { return "ERROR:invalid file data" }
            if (bytes.isEmpty() || bytes.size > 20 * 1024 * 1024) return "ERROR:file must be between 1 byte and 20 MB"
            // Check the actual payload instead of trusting a caller-supplied MIME type.
            val payloadMatchesMime = when (mime) {
                "image/png" -> bytes.size >= 8 && bytes.copyOfRange(0, 8).contentEquals(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
                "image/jpeg" -> bytes.size >= 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()
                "image/webp" -> bytes.size >= 12 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF" && String(bytes, 8, 4, Charsets.US_ASCII) == "WEBP"
                "text/plain", "application/json" -> runCatching {
                    val decoder = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                    val text = decoder.decode(ByteBuffer.wrap(bytes)).toString()
                    if (mime == "application/json") {
                        val json = JSONTokener(text)
                        json.nextValue()
                        json.nextClean() == '\u0000'
                    } else true
                }.getOrDefault(false)
                else -> false
            }
            if (!payloadMatchesMime) return "ERROR:file content does not match its declared type"
            val safeName = (rawName ?: "srm-export").substringAfterLast('/').substringAfterLast('\\')
                .replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "srm-export" }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = this@MainActivity.contentResolver
            var uri: Uri? = null
            return try {
                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return "ERROR:could not create Downloads file"
                resolver.openOutputStream(uri!!, "w")?.use { it.write(bytes) }
                    ?: throw IllegalStateException("could not open Downloads file")
                val ready = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                if (resolver.update(uri!!, ready, null, null) != 1) throw IllegalStateException("could not finalize Downloads file")
                "OK:$safeName"
            } catch (e: Exception) {
                uri?.let { runCatching { resolver.delete(it, null, null) } }
                "ERROR:" + (e.message ?: "save failed").take(140)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        // WebView service-worker requests use a separate client from normal page requests.
        // Route them through AssetLoader too, otherwise the offline shell can fail inside APKs.
        try {
            ServiceWorkerControllerCompat.getInstance().setServiceWorkerClient(object : ServiceWorkerClientCompat() {
                override fun shouldInterceptRequest(request: WebResourceRequest) = assetLoader.shouldInterceptRequest(request.url)
            })
            ServiceWorkerControllerCompat.getInstance().serviceWorkerWebSettings.apply {
                allowFileAccess = false
                allowContentAccess = false
            }
        } catch (_: Exception) {
            // The app remains usable online on WebView versions without service-worker support.
        }
        val webView = WebView(this)
        studioWebView = webView
        setContentView(webView)
        val downloadsBridge = AndroidDownloadsBridge()
        webView.addJavascriptInterface(downloadsBridge, "SRMDownloads")
        webView.settings.apply {
            javaScriptEnabled = true // required by the bundled local-first studio UI
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
        }
        WebView.setWebContentsDebuggingEnabled(false)
        webView.webViewClient = object : WebViewClientCompat() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                downloadsBridge.updateOrigin(url)
                super.onPageStarted(view, url, favicon)
            }
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) = assetLoader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Only the bundled app origin is allowed inside this WebView. External navigation is blocked.
                return !(request.url.scheme == "https" && request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/assets/") == true)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = callback
                // Honor the page's accepted MIME types while retaining a safe all-files fallback.
                val accepted = params.acceptTypes
                    .flatMap { it.split(",") }
                    .map { it.trim().lowercase() }
                    .filter { it.contains("/") && !it.contains(";") }
                    .distinct()
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = when {
                        accepted.isEmpty() || accepted.any { it == "*/*" } -> "*/*"
                        accepted.size == 1 -> accepted.first()
                        else -> "*/*"
                    }
                    if (accepted.size > 1 && accepted.none { it == "*/*" }) {
                        putExtra(Intent.EXTRA_MIME_TYPES, accepted.toTypedArray())
                    }
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try { filePicker.launch(Intent.createChooser(intent, "Choose media or model file")); true }
                catch (_: Exception) { pendingFileCallback = null; callback.onReceiveValue(null); true }
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
        if (savedInstanceState == null) webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        else if (webView.restoreState(savedInstanceState) == null) webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        studioWebView?.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onPause() {
        studioWebView?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        studioWebView?.onResume()
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        studioWebView?.destroy()
        studioWebView = null
        super.onDestroy()
    }
}
