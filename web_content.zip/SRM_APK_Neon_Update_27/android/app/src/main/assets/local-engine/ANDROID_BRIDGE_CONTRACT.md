# SRM Native Inference Bridge Contract — Update 11

The UI does not bundle or invent an inference engine. Android host code may expose `window.SRMNativeInference` only after a real on-device runtime is initialized.

## Required capability method

`await window.SRMNativeInference.getCapabilities()` returns a JSON-serializable object. Example:

```json
{
  "runtimeVersion": "1.0.0",
  "models": [{"modelId":"local-model-id","loaded":true,"tasks":["text-to-image"]}],
  "taskSmokeTests": {"text-to-image": {"passed": true, "outputBytes": 2048, "outputMime": "image/png"}}
}
```

Supported task IDs: `text-to-image`, `image-to-video`, `text-to-video`, `audio-lip-sync`. The UI marks a task ready only if a model object has a `modelId`, `loaded: true`, and explicitly lists the task in `tasks`, and `taskSmokeTests[taskId]` is an object with `passed: true`, positive integer `outputBytes`, and a bounded `outputMime` string. Global `modelLoaded` flags, booleans, and legacy string model lists are not sufficient. The handshake times out after 8 seconds. This remains runtime-reported evidence, not independent proof; release testing must inspect actual output bytes and quality.

## Implementation requirements

- Run inference on-device; no hosted AI endpoint or hidden network fallback.
- Validate model provenance, license, architecture, tensor shapes, runtime compatibility, and memory requirements before loading.
- Keep expensive inference off the UI thread; report cancellable progress only from real runtime events.
- Reject unsupported inputs and report errors without pretending an output was created.
- Use a minimal, validated Android WebView bridge; do not expose arbitrary file paths or generic shell execution to JavaScript.
- The browser SHA-256 verifier reads the entire selected file into memory and is capped at 512 MiB. Large model packages should use native streaming hash verification.

## Offline behavior

The service worker caches only same-origin app-shell resources. Navigation can fall back to the cached app shell when offline; failed asset requests no longer incorrectly return `index.html`.


## Update 11 strict task test evidence
Each task test must report an output-backed record, for example `{"passed":true,"outputBytes":2048,"outputMime":"image/png"}`. Values are validated and reduced to safe fields before diagnostics export. This metadata does not transfer output bytes to the web UI and must never be fabricated by a host adapter.
