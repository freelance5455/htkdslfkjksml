plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.srm.creative"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.srm.creative"
        minSdk = 26
        targetSdk = 35
        versionCode = 27
        versionName = "27.0"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}
