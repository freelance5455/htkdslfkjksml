## Update 20 (2026-10-14)
- Fixed release/diagnostics version drift and advanced Android metadata to 20.0.
- Kept the GitHub Actions debug build workflow and Android asset parity checks.

# Android host foundation (Update 20)

The Android project packages the local-first web studio in an AndroidX WebViewAssetLoader shell. It constrains navigation, disables file/content URL access and mixed content, disables WebView debugging, and does not expose a JavaScript-to-native bridge.

## Build

Requires JDK 17, Android SDK platform 35, build-tools 35.0.0, and Gradle 8.7. The helper checks that the required SDK packages are installed:

```sh
./build-release.sh
```

Or push this folder to a GitHub repository and run the `SRM Android build` workflow. The workflow publishes `app-debug.apk` as an artifact only after tests and compilation pass.

## Important limitations

This is a debug build foundation, not a signed production release. No trained generative model or inference runtime is bundled, and this source snapshot has not been compiled in the current environment. Real image/video generation and on-device testing remain required before claiming those capabilities.
