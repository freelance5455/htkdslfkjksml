#!/usr/bin/env bash
set -euo pipefail
ANDROID_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$ANDROID_DIR/.." && pwd)"
cd "$ROOT"
if ! command -v node >/dev/null 2>&1; then echo "Node.js is required to run regression checks." >&2; exit 2; fi
if ! command -v gradle >/dev/null 2>&1; then echo "Gradle 8.7 is required. Install Gradle and Android SDK platform/build-tools 35, then rerun." >&2; exit 2; fi
if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then echo "Set ANDROID_HOME or ANDROID_SDK_ROOT to your Android SDK directory." >&2; exit 2; fi
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ ! -d "$SDK_ROOT/platforms/android-35" ]]; then echo "Android SDK platform 35 is missing at $SDK_ROOT/platforms/android-35. Install it with sdkmanager \"platforms;android-35\"." >&2; exit 2; fi
if [[ ! -d "$SDK_ROOT/build-tools/35.0.0" ]]; then echo "Android build-tools 35.0.0 are missing. Install them with sdkmanager \"build-tools;35.0.0\"." >&2; exit 2; fi
./SYNC_ANDROID_ASSETS.sh --check
./RUN_TESTS.sh
node --check service-worker.js
cd "$ANDROID_DIR"
gradle --no-daemon --stacktrace clean assembleDebug
APK="$ANDROID_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -s "$APK" ]]; then echo "Build reported success but APK is missing or empty: $APK" >&2; exit 3; fi
sha256sum "$APK" > "$APK.sha256"
printf '\nAPK output: %s\nChecksum: %s\n' "$APK" "$APK.sha256"
cat "$APK.sha256"
