GOMOKU XO — PROJET ANDROID

Le jeu HTML a été emballé dans une application Android WebView. Le jeu est intégré aux assets et peut fonctionner hors ligne.

Pour générer l'APK :
1. Installe Android Studio sur un ordinateur.
2. Ouvre le dossier GomokuXO_Android dans Android Studio (Open).
3. Laisse Gradle synchroniser et installe le SDK Android demandé si Android Studio le propose.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK sera normalement dans app/build/outputs/apk/debug/app-debug.apk.

Identifiant d'application : com.legend.gomukoxo
Orientation : portrait
Version : 1.0

Note : ce dossier est le projet Android prêt à compiler, pas un APK déjà compilé. L'environnement de préparation ne contient pas le SDK Android/Gradle nécessaires pour produire et tester directement le fichier APK.
