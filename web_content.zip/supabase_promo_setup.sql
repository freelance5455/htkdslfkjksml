-- Выполнить в Supabase -> SQL Editor
create table if not exists public.promo_codes (
  code text primary key,
  reward_type text not null check (reward_type in ('money','phone')),
  reward_amount bigint,
  reward_phone text,
  active boolean not null default true,
  max_uses integer not null default 100000,
  uses_count integer not null default 0,
  created_at timestamptz not null default now(),
  check ((reward_type = 'money' and reward_amount > 0) or (reward_type = 'phone' and reward_phone is not null))
);
create table if not exists public.promo_redemptions (
  code text not null references public.promo_codes(code) on delete cascade,
  device_id text not null,
  redeemed_at timestamptz not null default now(),
  primary key (code, device_id)
);
alter table public.promo_codes enable row level security;
alter table public.promo_redemptions enable row level security;
revoke all on public.promo_codes from anon, authenticated;
revoke all on public.promo_redemptions from anon, authenticated;

create or replace function public.redeem_promo(p_code text, p_device_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p promo_codes%rowtype;
begin
  if p_code is null or length(p_code) > 32 or p_device_id is null or length(p_device_id) > 100 then
    return jsonb_build_object('valid', false, 'message', 'Некорректный код.');
  end if;
  select * into p from promo_codes where code = upper(trim(p_code)) and active = true for update;
  if not found then return jsonb_build_object('valid', false, 'message', 'Такого промокода нет.'); end if;
  if p.uses_count >= p.max_uses then return jsonb_build_object('valid', false, 'message', 'Лимит активаций этого промокода исчерпан.'); end if;
  if exists(select 1 from promo_redemptions where code = p.code and device_id = p_device_id) then
    return jsonb_build_object('valid', false, 'message', 'Этот промокод уже использован на этом устройстве.');
  end if;
  insert into promo_redemptions(code, device_id) values (p.code, p_device_id);
  update promo_codes set uses_count = uses_count + 1 where code = p.code;
  if p.reward_type = 'money' then
    return jsonb_build_object('valid', true, 'reward', jsonb_build_object('type','money','amount',p.reward_amount));
  else
    return jsonb_build_object('valid', true, 'reward', jsonb_build_object('type','phone','name',p.reward_phone));
  end if;
end; $$;
revoke all on function public.redeem_promo(text,text) from public;
grant execute on function public.redeem_promo(text,text) to service_role;
