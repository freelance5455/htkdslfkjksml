import React, { useState } from 'react';
import {
  Sparkles,
  FileCode,
  Code,
  DollarSign,
  MapPin,
  LogIn,
  ChevronRight,
  Star,
  Play,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import { TEMPLATE_CATEGORIES, DEFAULT_TEMPLATES } from '../data/defaultTemplates';
import { TemplateItem } from '../types';

interface Props {
  onSelectTemplate: (template: TemplateItem) => void;
  onPreviewTemplate: (template: TemplateItem) => void;
}

export const TemplatesTab: React.FC<Props> = ({ onSelectTemplate, onPreviewTemplate }) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'interaction':
        return <Sparkles className="w-5 h-5 text-teal-600" />;
      case 'starters':
        return <FileCode className="w-5 h-5 text-emerald-600" />;
      case 'libraries':
        return <Code className="w-5 h-5 text-rose-500" />;
      case 'ads':
        return <DollarSign className="w-5 h-5 text-emerald-600" />;
      case 'device':
        return <MapPin className="w-5 h-5 text-blue-600" />;
      case 'auth':
        return <LogIn className="w-5 h-5 text-sky-600" />;
      default:
        return <Code className="w-5 h-5 text-slate-600" />;
    }
  };

  const getCategoryBg = (id: string) => {
    switch (id) {
      case 'interaction': return 'bg-teal-50';
      case 'starters': return 'bg-emerald-50';
      case 'libraries': return 'bg-rose-50';
      case 'ads': return 'bg-emerald-50';
      case 'device': return 'bg-blue-50';
      case 'auth': return 'bg-sky-50';
      default: return 'bg-slate-50';
    }
  };

  const activeCategory = TEMPLATE_CATEGORIES.find((c) => c.id === selectedCategoryId);
  const categoryTemplates = selectedCategoryId
    ? DEFAULT_TEMPLATES.filter((t) => t.category === selectedCategoryId)
    : [];

  return (
    <div className="pb-24 pt-3 px-4 max-w-xl mx-auto space-y-4">
      {!selectedCategoryId ? (
        <>
          <div className="pt-1">
            <h2 className="text-sm font-semibold text-slate-700">
              Ready-made HTML projects that use native Android APIs.
            </h2>
          </div>

          <div className="space-y-2.5">
            {TEMPLATE_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategoryId(cat.id)}
                className="w-full p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-slate-200 transition flex items-center justify-between group text-left cursor-pointer"
              >
                <div className="flex items-center gap-3.5">
                  <div className={`p-3 rounded-2xl ${getCategoryBg(cat.id)} transition`}>
                    {getCategoryIcon(cat.id)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-slate-900 text-sm">{cat.name}</h3>
                      {cat.star && (
                        <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{cat.desc}</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-slate-600 group-hover:translate-x-0.5 transition" />
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className="space-y-4">
          <button
            onClick={() => setSelectedCategoryId(null)}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Categories
          </button>

          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              {activeCategory?.name}
              {activeCategory?.star && <Star className="w-4 h-4 fill-amber-400 text-amber-400" />}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{activeCategory?.desc}</p>
          </div>

          {categoryTemplates.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-2xl border border-slate-100">
              <p className="text-xs text-slate-500">
                Templates in this category are ready to inject. Click below to load the starter template!
              </p>
              <button
                onClick={() => onSelectTemplate(DEFAULT_TEMPLATES[0])}
                className="mt-3 px-4 py-2 bg-sky-600 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                Use Starter Template
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {categoryTemplates.map((t) => (
                <div
                  key={t.id}
                  className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-slate-900">{t.title}</h4>
                        {t.badge && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                            {t.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{t.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-50">
                    <button
                      onClick={() => onPreviewTemplate(t)}
                      className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5" /> Preview
                    </button>
                    <button
                      onClick={() => onSelectTemplate(t)}
                      className="flex-1 py-2 px-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      Use Template <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
