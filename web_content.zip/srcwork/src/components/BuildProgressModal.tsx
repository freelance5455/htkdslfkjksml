import React, { useEffect, useRef } from 'react';
import { Download, Play, ArrowLeft, Terminal, FolderArchive, Smartphone } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Project } from '../types';
import { BuildLog } from '../utils/apkBuilder';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  progress: number;
  stepText: string;
  logs: BuildLog[];
  isComplete: boolean;
  project: Project;
  apkBlob: Blob | null;
  onDownloadProjectZip: () => void;
  onOpenSimulator: () => void;
}

export const BuildProgressModal: React.FC<Props> = ({
  isOpen,
  onClose,
  progress,
  stepText,
  logs,
  isComplete,
  project,
  apkBlob,
  onDownloadProjectZip,
  onOpenSimulator,
}) => {
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  useEffect(() => {
    if (isComplete) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        console.error(e);
      }
    }
  }, [isComplete]);

  if (!isOpen) return null;

  const handleDownloadApk = () => {
    if (!apkBlob) return;
    const url = URL.createObjectURL(apkBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.packageName.replace(/\./g, '_')}_v${project.versionName}.apk`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <button
            onClick={onClose}
            className="p-2 -ml-2 text-slate-500 hover:text-slate-800 rounded-full hover:bg-slate-100 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            {isComplete ? 'Build Successful!' : 'Building APK'}
          </h2>
          <div className="w-9" />
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 flex flex-col items-center space-y-4">
          <div className="relative flex flex-col items-center justify-center pt-2">
            {/* Percentage Circle Spinner */}
            <div className="w-24 h-24 rounded-full border-4 border-slate-100 border-t-sky-500 flex items-center justify-center animate-spin">
              <div className="w-20 h-20 rounded-full bg-slate-50 flex items-center justify-center">
                <span className="text-xl font-bold font-mono text-slate-800">
                  %{progress}
                </span>
              </div>
            </div>

            {/* Little Cat Mascot sitting and looking up from video 01:53 */}
            <div className="w-12 h-12 mt-3 select-none flex items-center justify-center">
              <svg viewBox="0 0 64 64" className="w-full h-full text-slate-900" fill="currentColor">
                {/* Cat head & ears */}
                <path d="M 20 28 L 22 14 L 30 22 L 34 22 L 42 14 L 44 28 C 48 34 46 42 42 46 C 40 48 38 49 32 49 C 26 49 24 48 22 46 C 18 42 16 34 20 28 Z" fill="#1e293b" />
                {/* Cat eyes looking up */}
                <ellipse cx="26" cy="30" rx="2.5" ry="3.5" fill="#ffffff" />
                <circle cx="26" cy="28.5" r="1.5" fill="#0f172a" />
                <ellipse cx="38" cy="30" rx="2.5" ry="3.5" fill="#ffffff" />
                <circle cx="38" cy="28.5" r="1.5" fill="#0f172a" />
                {/* Cat nose & mouth */}
                <polygon points="32,36 30.5,34 33.5,34" fill="#fb7185" />
                <path d="M 30.5 36.5 Q 32 38 33.5 36.5" stroke="#94a3b8" strokeWidth="1" fill="none" />
                {/* Cat body & paws sitting */}
                <ellipse cx="32" cy="53" rx="10" ry="7" fill="#1e293b" />
                <circle cx="28" cy="57" r="3" fill="#334155" />
                <circle cx="36" cy="57" r="3" fill="#334155" />
                {/* Cat tail curled up */}
                <path d="M 42 53 Q 48 51 46 42 Q 44 38 41 40" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" fill="none" />
              </svg>
            </div>

            <p className="text-xs text-slate-500 mt-2 font-medium">
              {stepText || 'This process may take up to 1 minute, do not turn off your screen'}
            </p>
          </div>

          {/* Terminal Logs Window */}
          <div className="w-full h-52 bg-black rounded-2xl p-4 font-mono text-[11px] sm:text-xs text-white overflow-y-auto space-y-1.5 border border-slate-800 shadow-inner">
            <div className="flex items-center gap-1.5 text-slate-500 pb-2 border-b border-slate-800 text-[10px]">
              <Terminal className="w-3.5 h-3.5 text-sky-400" />
              <span>BUILD OUTPUT CONSOLE</span>
            </div>
            {logs.map((log, idx) => (
              <div key={idx} className="whitespace-pre-wrap leading-relaxed">
                <span className="text-slate-500 mr-2">{log.timestamp}</span>
                <span
                  className={
                    log.type === 'success'
                      ? 'text-emerald-400 font-bold'
                      : log.type === 'warn'
                      ? 'text-amber-400'
                      : log.type === 'dim'
                      ? 'text-slate-500'
                      : 'text-slate-200'
                  }
                >
                  {log.message}
                </span>
              </div>
            ))}
            <div ref={terminalEndRef} />
          </div>

          {/* Action buttons upon completion */}
          {isComplete && (
            <div className="w-full space-y-2 pt-2 animate-in fade-in slide-in-from-bottom-3 duration-300">
              <button
                onClick={handleDownloadApk}
                className="w-full py-3.5 px-4 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl font-semibold shadow-lg shadow-sky-600/30 flex items-center justify-center gap-2 transition active:scale-[0.98] cursor-pointer"
              >
                <Download className="w-4 h-4" /> Download APK ({project.name}.apk)
              </button>
              <button
                onClick={onDownloadProjectZip}
                className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-900 text-white rounded-2xl font-semibold flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <FolderArchive className="w-4 h-4 text-amber-400" /> Download Android Studio Project (.zip)
              </button>
              <button
                onClick={() => {
                  onClose();
                  onOpenSimulator();
                }}
                className="w-full py-3 px-4 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-2xl font-semibold flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Play className="w-4 h-4 text-emerald-600" /> Launch in Live Android Simulator
              </button>

              {/* Real Phone Installation Tip */}
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-[11px] text-emerald-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                  <span>How to install on any Android phone:</span>
                </div>
                <p className="text-[11px] leading-relaxed text-emerald-800">
                  Transfer the downloaded <b>{project.name}.apk</b> to your phone. Tap on it and select <b>"Install"</b>. If prompted, toggle <b>"Allow from this source / Install Unknown Apps"</b> in Settings. All permissions (Camera, Photos, Videos, GPS, Google Login) will work natively!
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
