import React, { useState } from 'react';
import {
  ArrowLeft,
  Lock,
  Download,
  Trash2,
  Copy,
  Check,
  AlertTriangle,
  Lightbulb,
  Plus,
  Info,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Keystore } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  keystores: Keystore[];
  onSaveKeystore: (keystore: Keystore) => void;
  onDeleteKeystore?: (id: string) => void;
}

export const KeystoreManagerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  keystores,
  onSaveKeystore,
  onDeleteKeystore,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [lostKeyExpanded, setLostKeyExpanded] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [packageName, setPackageName] = useState('com.htmltoapk.app');
  const [alias, setAlias] = useState('key0');
  const [validity, setValidity] = useState(25);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownloadKeystore = (ks: Keystore) => {
    const content = `-----BEGIN KEYSTORE CERTIFICATE-----
Algorithm: ${ks.algorithm || 'RSA'}
KeySize: 2048
Alias: ${ks.alias}
Validity: ${ks.validityYears} Years
Created: ${new Date(ks.createdAt).toISOString()}
SHA-1: ${ks.sha1}
SHA-256: ${ks.sha256}
Owner: CN=${ks.name}, OU=Mobile, O=HTMLtoAPK, C=US
-----END KEYSTORE CERTIFICATE-----`;
    const blob = new Blob([content], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${ks.name.replace(/[^a-zA-Z0-9]/g, '_')}.jks`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const generateHex = (count: number) => {
      const chars = '0123456789ABCDEF';
      const pairs: string[] = [];
      for (let i = 0; i < count; i++) {
        pairs.push(
          chars[Math.floor(Math.random() * chars.length)] +
          chars[Math.floor(Math.random() * chars.length)]
        );
      }
      return pairs.join(':');
    };

    const newKeystore: Keystore = {
      id: 'ks_' + Date.now(),
      name: `${name.trim()} (${packageName.trim()})`,
      alias: alias.trim() || 'key0',
      algorithm: 'RSA',
      validityYears: validity,
      createdAt: Date.now(),
      projectLink: name.trim(),
      savedPath: 'Saved to Downloads/HTMLtoAPK/Keystores',
      sha1: generateHex(20),
      sha256: generateHex(32),
      isDefault: false,
    };

    onSaveKeystore(newKeystore);
    setName('');
    setShowAddForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <div className="bg-slate-50 min-h-screen sm:min-h-0 sm:rounded-3xl max-w-xl w-full sm:max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200 relative">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-100 px-4 py-3.5 flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1 -ml-1 text-slate-700 hover:text-slate-900 rounded-full hover:bg-slate-100 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-base font-bold text-slate-900">Keystore Manager</h2>
        </header>

        {/* Scrollable Content */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 pb-24">
          <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-xs flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-sky-50 text-sky-600 shrink-0">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">What is a Keystore?</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                A keystore is your app's digital signature. You MUST use the SAME keystore for ALL updates of an app published on Google Play. If you lose it, you cannot update your app anymore!
              </p>
            </div>
          </div>

          <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-xs flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-sky-50 text-sky-600 shrink-0">
              <Lightbulb className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">Important Tip</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                A default keystore is generated automatically. With Pro, you can import a custom keystore and keep your existing signature.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
            <button
              onClick={() => setLostKeyExpanded(!lostKeyExpanded)}
              className="w-full p-4 flex items-center justify-between text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-red-50 text-red-600">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900">Lost your signing key?</h4>
                  <p className="text-[11px] text-slate-400">Tap to expand</p>
                </div>
              </div>
              {lostKeyExpanded ? (
                <ChevronUp className="w-4 h-4 text-slate-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-400" />
              )}
            </button>
            {lostKeyExpanded && (
              <div className="p-4 pt-0 text-xs text-slate-500 border-t border-slate-50 leading-relaxed space-y-2">
                <p>
                  If you lost your keystore and your app is already published on Google Play with Play App Signing enabled, you can request a key reset from Google Play Console support.
                </p>
                <p>
                  Generate a new upload key in this manager, copy the new <b>SHA-1 and SHA-256 certificate fingerprints</b>, and submit them in the Google Play Console Developer Support request!
                </p>
              </div>
            )}
          </div>

          {/* Section: Your Keystores */}
          <div className="pt-2 space-y-3">
            <h3 className="font-bold text-sm text-slate-900">Your Keystores</h3>
            {keystores.map((ks) => (
              <div
                key={ks.id}
                className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3.5">
                    <div className="p-3 rounded-2xl bg-sky-50 text-sky-600 shrink-0">
                      <Lock className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 leading-snug">
                        {ks.name}
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Algorithm: {ks.algorithm || 'RSA'}
                      </p>
                      {ks.projectLink && (
                        <p className="text-xs text-sky-600 font-medium mt-0.5">
                          Project: {ks.projectLink}
                        </p>
                      )}
                      <p className="text-[11px] text-sky-600 font-medium mt-0.5">
                        {ks.savedPath || 'Saved to Downloads/HTMLtoAPK/Keystores'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleDownloadKeystore(ks)}
                      className="p-2 text-sky-600 hover:text-sky-800 rounded-xl hover:bg-sky-50 cursor-pointer"
                      title="Download Keystore File (.jks)"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    {!ks.isDefault && onDeleteKeystore && (
                      <button
                        onClick={() => onDeleteKeystore(ks.id)}
                        className="p-2 text-red-500 hover:text-red-700 rounded-xl hover:bg-red-50 cursor-pointer"
                        title="Delete Keystore"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Fingerprints */}
                <div className="pt-2 border-t border-slate-50 space-y-2">
                  <div className="text-[11px] font-bold text-slate-700">
                    Certificate fingerprints
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 flex items-start justify-between text-[11px] font-mono">
                    <div className="break-all text-slate-600 pr-2">
                      <span className="font-bold text-slate-800 block text-[10px] uppercase font-sans">
                        SHA-1
                      </span>
                      {ks.sha1}
                    </div>
                    <button
                      onClick={() => handleCopy(ks.sha1, ks.id + '_sha1')}
                      className="p-1.5 text-sky-600 hover:text-sky-800 rounded-lg hover:bg-white shrink-0 mt-1 cursor-pointer"
                      title="Copy SHA-1"
                    >
                      {copiedId === ks.id + '_sha1' ? (
                        <Check className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 flex items-start justify-between text-[11px] font-mono">
                    <div className="break-all text-slate-600 pr-2">
                      <span className="font-bold text-slate-800 block text-[10px] uppercase font-sans">
                        SHA-256
                      </span>
                      {ks.sha256}
                    </div>
                    <button
                      onClick={() => handleCopy(ks.sha256, ks.id + '_sha256')}
                      className="p-1.5 text-sky-600 hover:text-sky-800 rounded-lg hover:bg-white shrink-0 mt-1 cursor-pointer"
                      title="Copy SHA-256"
                    >
                      {copiedId === ks.id + '_sha256' ? (
                        <Check className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Floating Action Buttons */}
        <div className="absolute bottom-5 right-5 flex flex-col items-center gap-3 z-30">
          <button
            onClick={() => setShowAddForm(true)}
            className="w-13 h-13 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white shadow-lg flex items-center justify-center transition cursor-pointer"
            title="Create New Keystore"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Create Keystore Popup Modal */}
        {showAddForm && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl animate-in zoom-in-95 duration-200">
              <h3 className="text-base font-bold text-slate-900 mb-3">
                Create New Keystore
              </h3>
              <form onSubmit={handleGenerate} className="space-y-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    App / Keystore Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Calculator Pro"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Package Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="com.calculatorpro.app"
                    value={packageName}
                    onChange={(e) => setPackageName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Key Alias
                  </label>
                  <input
                    type="text"
                    placeholder="key0"
                    value={alias}
                    onChange={(e) => setAlias(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Validity (Years)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={validity}
                    onChange={(e) => setValidity(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="flex-1 py-2.5 border border-slate-200 rounded-xl font-semibold text-slate-600 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-semibold shadow-sm cursor-pointer"
                  >
                    Create Key
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
