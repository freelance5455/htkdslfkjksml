import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  ArrowLeft,
  CheckCircle2,
  Edit2,
  Smartphone,
  Sparkles,
  Key,
  FolderArchive,
} from 'lucide-react';
import { Project, Keystore } from '../types';
import { DEFAULT_TEMPLATES } from '../data/defaultTemplates';

interface Props {
  initialProject?: Project;
  keystores: Keystore[];
  onCancel: () => void;
  onSaveAndBuild: (project: Project) => void;
  onOpenCodeEditor: (code: string, onSave: (newCode: string) => void) => void;
  onManageKeystore: () => void;
}

export const NewProjectWizard: React.FC<Props> = ({
  initialProject,
  keystores,
  onCancel,
  onSaveAndBuild,
  onOpenCodeEditor,
  onManageKeystore,
}) => {
  const [currentStep, setCurrentStep] = useState(1);

  // Project state
  const [project, setProject] = useState<Project>(
    initialProject || {
      id: 'proj_' + Date.now(),
      name: 'Calculator Pro',
      packageName: 'com.htmltoapk.calculatorpro',
      versionCode: 1,
      versionName: '1.0',
      autoIncrementVersion: true,
      minSdk: 24,
      targetSdk: 36,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      sourceType: 'html_file',
      htmlContent: DEFAULT_TEMPLATES[0].htmlContent,
      files: {},
      selectedFileName: 'index.html',
      orientation: 'portrait',
      showStatusBar: true,
      showActionBar: false,
      keepScreenOn: false,
      showCameraCutout: false,
      desktopMode: false,
      showWatermark: false,
      primaryColor: '#2196F3',
      loadingBgColor: '#000000',
      permissions: {
        internet: true,
        networkState: true,
        readExternalStorage: true,
        writeExternalStorage: true,
        readMediaImages: true,
        readMediaVideo: true,
        readMediaAudio: true,
        camera: true,
        microphone: false,
        fineLocation: true,
        coarseLocation: true,
        notifications: true,
        exactAlarms: false,
        activityRecognition: false,
        vibration: true,
        phoneState: false,
      },
      iconUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=192&auto=format&fit=crop&q=80',
      iconName: 'calculator_icon.png',
      splash: {
        enabled: false,
        bgColor: '#0F1318',
        loaderStyle: 'circle',
        loaderColor: '#00E5CC',
        iconSize: 120,
        iconCorners: 16,
        loaderSize: 48,
        spacing: 28,
        displayDuration: 2,
        loaderThickness: 4,
        fadeDuration: 400,
      },
      webView: {
        javascriptEnabled: true,
        domStorageEnabled: true,
        allowFileAccess: true,
        allowContentAccess: true,
        universalFileAccess: true,
        fileAccessFromFileUrls: true,
        builtInZoomControls: false,
        useWideViewport: true,
        loadWithOverviewMode: true,
        geolocationEnabled: true,
        cacheMode: 'LOAD_DEFAULT',
        mixedContentMode: 'ALWAYS_ALLOW',
        pullToRefresh: false,
        noInternetDialog: false,
        loadingIndicator: false,
        backButtonNavigation: true,
        exitConfirmDialog: true,
        bypassGoogleOAuthUserAgent: true,
      },
      admob: {
        enabled: false,
        appId: '',
        bannerId: '',
        interstitialId: '',
        rewardedId: '',
      },
      outputFormat: 'apk',
      keystoreId: keystores[0]?.id || 'default_keystore',
    }
  );

  const stepNames = [
    'Info',
    'Content',
    'Display',
    'Permissions',
    'Icon',
    'Splash',
    'WebView',
    'Ads',
    'Summary',
    'Output',
  ];

  const handleNameChange = (name: string) => {
    const clean = name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const pkg = clean ? `com.htmltoapk.${clean}` : 'com.htmltoapk.app';
    setProject((prev) => ({
      ...prev,
      name,
      packageName: prev.packageName.startsWith('com.htmltoapk.') ? pkg : prev.packageName,
    }));
  };

  const handleHtmlFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setProject((prev) => ({
        ...prev,
        htmlContent: content,
        selectedFileName: file.name,
      }));
    };
    reader.readAsText(file);
  };

  const handleZipFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const zip = await JSZip.loadAsync(file);
      const filesMap: { [name: string]: string } = {};
      let foundIndexHtml = '';
      for (const [relativePath, zipEntry] of Object.entries(zip.files)) {
        if (!zipEntry.dir) {
          const content = await zipEntry.async('string');
          filesMap[relativePath] = content;
          if (relativePath.toLowerCase() === 'index.html' || relativePath.toLowerCase().endsWith('/index.html')) {
            foundIndexHtml = content;
          }
        }
      }
      setProject((prev) => ({
        ...prev,
        sourceType: 'zip_file',
        selectedFileName: file.name,
        files: filesMap,
        htmlContent: foundIndexHtml || Object.values(filesMap)[0] || '<h1>App Content</h1>',
      }));
    } catch {
      alert('Could not read ZIP file. Please ensure it is a valid zip archive.');
    }
  };

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setProject((prev) => ({
        ...prev,
        iconUrl: event.target?.result as string,
        iconName: file.name,
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleNext = () => {
    if (currentStep < 10) setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
    else onCancel();
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={handleBack}
              className="p-1 -ml-1 text-slate-700 hover:text-slate-900 rounded-full hover:bg-slate-100 transition cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-base font-bold text-slate-900">New Project</h1>
          </div>
          <span className="text-xs font-semibold text-sky-600">
            Step {currentStep} / 10 • {stepNames[currentStep - 1]}
          </span>
        </div>
        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1">
          <div
            className="bg-sky-500 h-1 transition-all duration-300 ease-out"
            style={{ width: `${currentStep * 10}%` }}
          />
        </div>
      </header>

      {/* Main Step Form Container */}
      <main className="max-w-xl mx-auto w-full p-4 flex-1">
        {/* STEP 1: INFO */}
        {currentStep === 1 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">App Information</h2>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                App Name
              </label>
              <input
                type="text"
                value={project.name}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="Calculator Pro"
                className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none transition"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                This is what users will see under your app icon.
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Package Name
              </label>
              <input
                type="text"
                value={project.packageName}
                onChange={(e) =>
                  setProject((p) => ({ ...p, packageName: e.target.value }))
                }
                placeholder="com.htmltoapk.calculatorpro"
                className="w-full px-4 py-3 text-sm font-mono border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none transition"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                A unique ID like com.yourname.yourapp. Use only lowercase letters and dots.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Version Code
                </label>
                <input
                  type="number"
                  min="1"
                  value={project.versionCode}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      versionCode: Number(e.target.value),
                    }))
                  }
                  className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  A number. Increase this for every update (e.g. 1, 2, 3...).
                </p>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Version Name
                </label>
                <input
                  type="text"
                  value={project.versionName}
                  onChange={(e) =>
                    setProject((p) => ({ ...p, versionName: e.target.value }))
                  }
                  placeholder="1.0"
                  className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  The version users see (e.g. 1.0, 1.1, 2.0).
                </p>
              </div>
            </div>

            <label className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer">
              <input
                type="checkbox"
                checked={project.autoIncrementVersion}
                onChange={(e) =>
                  setProject((p) => ({
                    ...p,
                    autoIncrementVersion: e.target.checked,
                  }))
                }
                className="w-4 h-4 rounded text-sky-600 mt-0.5"
              />
              <div>
                <div className="text-xs font-semibold text-slate-800">
                  Auto-increment version code
                </div>
                <div className="text-[11px] text-slate-400">
                  Automatically increase version code on each build
                </div>
              </div>
            </label>

            <div className="grid grid-cols-2 gap-4 pt-1">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Min SDK
                </label>
                <input
                  type="number"
                  value={project.minSdk}
                  onChange={(e) =>
                    setProject((p) => ({ ...p, minSdk: Number(e.target.value) }))
                  }
                  className="w-full px-4 py-2.5 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  24 = Android 7.0 Nougat
                </p>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Target SDK
                </label>
                <input
                  type="number"
                  value={project.targetSdk}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      targetSdk: Number(e.target.value),
                    }))
                  }
                  className="w-full px-4 py-2.5 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  36 = Android 16 (Play Store Ready)
                </p>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Custom URL Scheme (optional)
              </label>
              <input
                type="text"
                value={project.customUrlScheme || ''}
                onChange={(e) =>
                  setProject((p) => ({ ...p, customUrlScheme: e.target.value }))
                }
                placeholder="e.g. myapp"
                className="w-full px-4 py-2.5 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none font-mono"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Example: myapp:// opens myapp://anything
              </p>
            </div>
          </div>
        )}

        {/* STEP 2: CONTENT */}
        {currentStep === 2 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Content Source</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Upload your single index.html, ZIP project folder, or paste HTML code
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Source Type
              </label>
              <select
                value={project.sourceType}
                onChange={(e) =>
                  setProject((p) => ({
                    ...p,
                    sourceType: e.target.value as any,
                  }))
                }
                className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none bg-white font-medium"
              >
                <option value="html_file">Single HTML File (index.html)</option>
                <option value="zip_file">Project Folder / ZIP File</option>
                <option value="paste_html">Paste HTML Directly</option>
                <option value="web_url">Web URL</option>
              </select>
            </div>

            {/* 1. HTML File */}
            {project.sourceType === 'html_file' && (
              <div className="space-y-4">
                <label className="w-full py-4 px-4 bg-sky-50/80 hover:bg-sky-100 text-sky-700 rounded-2xl flex items-center justify-center cursor-pointer transition font-semibold text-xs border border-sky-200">
                  <input
                    type="file"
                    accept=".html,.htm"
                    onChange={handleHtmlFileUpload}
                    className="hidden"
                  />
                  <span>Select Single HTML File (index.html)</span>
                </label>

                {project.selectedFileName && (
                  <div className="flex items-center justify-between text-xs p-3 bg-slate-50 rounded-xl">
                    <span className="text-slate-600">
                      Selected: <b className="text-sky-600">{project.selectedFileName}</b>
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        onOpenCodeEditor(project.htmlContent, (code) =>
                          setProject((p) => ({ ...p, htmlContent: code }))
                        )
                      }
                      className="text-sky-600 hover:text-sky-700 font-semibold underline cursor-pointer"
                    >
                      Edit HTML
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* 2. Web URL */}
            {project.sourceType === 'web_url' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Web Address
                  </label>
                  <input
                    type="url"
                    placeholder="https://example.com"
                    value={project.webUrl || ''}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        webUrl: e.target.value,
                        selectedFileName: e.target.value || 'Web URL',
                      }))
                    }
                    className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Enter the full URL including https://
                  </p>
                </div>
              </div>
            )}

            {/* 3. Paste HTML */}
            {project.sourceType === 'paste_html' && (
              <div className="space-y-3">
                <div>
                  <textarea
                    rows={6}
                    placeholder="Paste HTML Code here..."
                    value={project.htmlContent || ''}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        htmlContent: e.target.value,
                        selectedFileName: 'pasted_index.html',
                      }))
                    }
                    className="w-full p-3 font-mono text-xs border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none resize-none"
                  />
                  <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1">
                    <span>Pasted HTML ({project.htmlContent?.length || 0} chars)</span>
                    <button
                      type="button"
                      onClick={() =>
                        onOpenCodeEditor(project.htmlContent, (code) =>
                          setProject((p) => ({ ...p, htmlContent: code }))
                        )
                      }
                      className="text-sky-600 font-semibold underline cursor-pointer"
                    >
                      Edit HTML
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 4. Project Folder / ZIP Archive */}
            {project.sourceType === 'zip_file' && (
              <div className="space-y-4">
                <label className="w-full py-4 px-4 bg-sky-50/80 hover:bg-sky-100 text-sky-700 rounded-2xl flex items-center justify-center gap-2 cursor-pointer transition font-semibold text-xs border border-sky-200">
                  <input
                    type="file"
                    accept=".zip"
                    onChange={handleZipFileUpload}
                    className="hidden"
                  />
                  <FolderArchive className="w-4 h-4 text-sky-600" />
                  <span>Select Project Folder / ZIP Archive</span>
                </label>

                {project.selectedFileName && (
                  <div className="text-xs p-3.5 bg-slate-50 rounded-2xl space-y-1.5 border border-slate-100">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">
                        Selected: <b className="text-sky-600">{project.selectedFileName}</b>
                      </span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                        {Object.keys(project.files).length || 1} files extracted
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Bundled directly into Android app assets for 100% offline use.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Status card */}
            <div className="p-3.5 rounded-2xl bg-sky-50/80 border border-sky-100 flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
              <span className="text-xs font-semibold text-sky-900">
                HTML structure verified & 100% offline ready
              </span>
            </div>
          </div>
        )}

        {/* STEP 3: DISPLAY */}
        {currentStep === 3 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Display Settings</h2>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Orientation
              </label>
              <select
                value={project.orientation}
                onChange={(e) =>
                  setProject((p) => ({
                    ...p,
                    orientation: e.target.value as any,
                  }))
                }
                className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none bg-white font-medium"
              >
                <option value="portrait">Portrait</option>
                <option value="landscape">Landscape</option>
                <option value="auto">Auto-rotate</option>
              </select>
            </div>

            <div className="space-y-3">
              {[
                {
                  key: 'showStatusBar',
                  title: 'Show status bar',
                  desc: 'Keep the top system status bar visible',
                },
                {
                  key: 'showActionBar',
                  title: 'Show action bar',
                  desc: 'Keep the app title bar visible',
                },
                {
                  key: 'keepScreenOn',
                  title: 'Keep screen on',
                  desc: 'Prevent the screen from turning off',
                },
                {
                  key: 'showCameraCutout',
                  title: 'Show camera cutout',
                  desc: 'Allow content to extend into the camera notch or punch hole area',
                },
                {
                  key: 'desktopMode',
                  title: 'Desktop mode',
                  desc: 'Load web pages in desktop browser layout',
                },
                {
                  key: 'showWatermark',
                  title: 'Show watermark',
                  desc: 'Display a small watermark in the generated app (Free to disable)',
                },
              ].map((item) => (
                <label
                  key={item.key}
                  className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50/70 border border-slate-100 cursor-pointer hover:bg-slate-50 transition"
                >
                  <input
                    type="checkbox"
                    checked={(project as any)[item.key]}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        [item.key]: e.target.checked,
                      }))
                    }
                    className="w-4 h-4 rounded text-sky-600 mt-0.5"
                  />
                  <div>
                    <div className="text-xs font-semibold text-slate-800">
                      {item.title}
                    </div>
                    <div className="text-[11px] text-slate-400">{item.desc}</div>
                  </div>
                </label>
              ))}
            </div>

            {/* Primary Color Palette */}
            <div className="pt-2">
              <label className="text-xs font-semibold text-slate-700 block mb-2">
                Primary Color
              </label>
              <div className="grid grid-cols-7 gap-2 mb-3">
                {[
                  '#2196F3', '#00BCD4', '#009688', '#4CAF50', '#8BC34A', '#CDDC39', '#FFEB3B',
                  '#FF9800', '#FF5722', '#F44336', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5',
                  '#1E293B', '#0F172A', '#0D9488', '#0284C7', '#4F46E5', '#7C3AED', '#DB2777',
                ].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setProject((p) => ({ ...p, primaryColor: c }))}
                    className={`w-8 h-8 rounded-full transition shadow-sm cursor-pointer ${
                      project.primaryColor === c ? 'ring-2 ring-offset-2 ring-sky-500 scale-110' : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={project.primaryColor}
                  onChange={(e) =>
                    setProject((p) => ({ ...p, primaryColor: e.target.value }))
                  }
                  className="w-32 px-3 py-2 text-xs font-mono border border-slate-200 rounded-xl"
                  placeholder="#2196F3"
                />
                <span className="text-[11px] text-slate-400">Custom HEX Color</span>
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: PERMISSIONS */}
        {currentStep === 4 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Permissions</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                All requested permissions (Video, Photo, Read Storage, GPS Location, Camera) are natively implemented!
              </p>
            </div>

            <div className="flex gap-2 pb-1">
              <button
                type="button"
                onClick={() =>
                  setProject((p) => ({
                    ...p,
                    permissions: {
                      internet: true,
                      networkState: true,
                      readExternalStorage: true,
                      writeExternalStorage: true,
                      readMediaImages: true,
                      readMediaVideo: true,
                      readMediaAudio: true,
                      camera: true,
                      microphone: true,
                      fineLocation: true,
                      coarseLocation: true,
                      notifications: true,
                      exactAlarms: true,
                      activityRecognition: true,
                      vibration: true,
                      phoneState: true,
                    },
                  }))
                }
                className="px-3 py-1.5 rounded-xl bg-sky-50 text-sky-700 text-xs font-semibold hover:bg-sky-100 cursor-pointer"
              >
                Select All
              </button>
              <button
                type="button"
                onClick={() =>
                  setProject((p) => ({
                    ...p,
                    permissions: {
                      ...p.permissions,
                      camera: true,
                      readMediaImages: true,
                      readMediaVideo: true,
                      fineLocation: true,
                      vibration: true,
                    },
                  }))
                }
                className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-semibold hover:bg-emerald-100 cursor-pointer"
              >
                Media & GPS Pack
              </button>
            </div>

            <div className="space-y-2.5 max-h-[60vh] overflow-y-auto pr-1">
              {[
                {
                  key: 'internet',
                  title: 'Internet',
                  desc: 'Web pages, URL content and external API calls',
                  id: 'android.permission.INTERNET',
                },
                {
                  key: 'networkState',
                  title: 'Network State',
                  desc: 'Check whether the device is online',
                  id: 'android.permission.ACCESS_NETWORK_STATE',
                },
                {
                  key: 'readExternalStorage',
                  title: 'Read External Storage',
                  desc: 'Local HTML files, gallery and file output',
                  id: 'android.permission.READ_EXTERNAL_STORAGE',
                },
                {
                  key: 'writeExternalStorage',
                  title: 'Write External Storage',
                  desc: 'Save downloads and cached assets',
                  id: 'android.permission.WRITE_EXTERNAL_STORAGE',
                },
                {
                  key: 'readMediaImages',
                  title: 'Read Photos & Images',
                  desc: 'Direct gallery photo picker on Android 13+',
                  id: 'android.permission.READ_MEDIA_IMAGES',
                },
                {
                  key: 'readMediaVideo',
                  title: 'Read Videos',
                  desc: 'Direct video file picker on Android 13+',
                  id: 'android.permission.READ_MEDIA_VIDEO',
                },
                {
                  key: 'camera',
                  title: 'Camera',
                  desc: 'Native WebChromeClient live camera and photo capture',
                  id: 'android.permission.CAMERA',
                },
                {
                  key: 'microphone',
                  title: 'Microphone',
                  desc: 'Audio recording and voice inputs',
                  id: 'android.permission.RECORD_AUDIO',
                },
                {
                  key: 'fineLocation',
                  title: 'Precise GPS Location',
                  desc: 'HTML5 Geolocation API connected with GPS',
                  id: 'android.permission.ACCESS_FINE_LOCATION',
                },
                {
                  key: 'vibration',
                  title: 'Vibration & Haptics',
                  desc: 'Phone vibration motor for buttons & feedback',
                  id: 'android.permission.VIBRATE',
                },
              ].map((perm) => (
                <label
                  key={perm.key}
                  className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50/70 border border-slate-100 cursor-pointer hover:bg-slate-50 transition"
                >
                  <input
                    type="checkbox"
                    checked={(project.permissions as any)[perm.key]}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        permissions: {
                          ...p.permissions,
                          [perm.key]: e.target.checked,
                        },
                      }))
                    }
                    className="w-4 h-4 rounded text-sky-600 mt-1"
                  />
                  <div>
                    <div className="text-xs font-semibold text-slate-800">
                      {perm.title}
                    </div>
                    <div className="text-[11px] text-slate-500">{perm.desc}</div>
                    <div className="text-[10px] font-mono text-sky-600 mt-0.5">
                      Permission: {perm.id}
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>
        )}

        {/* STEP 5: ICON */}
        {currentStep === 5 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">App Icon</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Choose a square image. This will be your app's icon on the phone.
              </p>
            </div>

            <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50 space-y-4">
              <div
                className="w-24 h-24 rounded-3xl shadow-lg border-2 border-white flex items-center justify-center overflow-hidden"
                style={{ backgroundColor: project.primaryColor }}
              >
                {project.iconUrl ? (
                  <img
                    src={project.iconUrl}
                    alt="App Icon"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Smartphone className="w-10 h-10 text-white" />
                )}
              </div>

              <label className="py-2.5 px-5 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl text-xs font-semibold shadow-md shadow-sky-600/20 cursor-pointer transition">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleIconUpload}
                  className="hidden"
                />
                Pick from Gallery
              </label>

              {project.iconName && (
                <span className="text-xs text-slate-500 font-mono">
                  Selected: {project.iconName}
                </span>
              )}
            </div>
          </div>
        )}

        {/* STEP 6: SPLASH */}
        {currentStep === 6 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Splash screen</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                First screen shown when the app opens
              </p>
            </div>

            {/* Pro Feature Unlocked Banner */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-sky-600 text-white text-xs">
                  ⭐
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">
                    Pro Feature (Unlocked Free)
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Full custom splash screen unlocked for free!
                  </div>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                FREE
              </span>
            </div>

            <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer">
              <div>
                <div className="text-xs font-semibold text-slate-800">
                  Enable splash screen
                </div>
                <div className="text-[11px] text-slate-400">
                  Shows your logo and loading animation when the app opens
                </div>
              </div>
              <input
                type="checkbox"
                checked={project.splash.enabled}
                onChange={(e) =>
                  setProject((p) => ({
                    ...p,
                    splash: { ...p.splash, enabled: e.target.checked },
                  }))
                }
                className="w-5 h-5 rounded text-sky-600 accent-sky-600"
              />
            </label>

            {!project.splash.enabled ? (
              <div className="p-3.5 rounded-2xl bg-sky-50/60 border border-sky-100 flex items-center gap-2.5 text-xs text-sky-900 font-semibold">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
                <span>Splash screen is disabled. The app will launch directly into main content.</span>
              </div>
            ) : null}

            {/* Live Phone Mockup matching video 01:20 - 01:21 */}
            <div className="flex justify-center py-2">
              <div
                className="w-48 h-64 rounded-3xl shadow-xl border-4 border-slate-800 flex flex-col items-center justify-center p-4 relative overflow-hidden transition-colors"
                style={{ backgroundColor: project.splash.bgColor }}
              >
                <div
                  className="rounded-2xl overflow-hidden shadow-md flex items-center justify-center mb-3"
                  style={{
                    width: `${project.splash.iconSize / 1.5}px`,
                    height: `${project.splash.iconSize / 1.5}px`,
                    borderRadius: `${project.splash.iconCorners}px`,
                    backgroundColor: project.primaryColor,
                  }}
                >
                  {project.iconUrl ? (
                    <img
                      src={project.iconUrl}
                      alt="Icon"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="grid grid-cols-2 gap-1 p-2 text-white font-bold text-xs">
                      <span>+</span><span>-</span><span>×</span><span>÷</span>
                    </div>
                  )}
                </div>

                {project.splash.loaderStyle === 'circle' && (
                  <div
                    className="w-7 h-7 rounded-full border-3 border-transparent border-t-white animate-spin"
                    style={{ borderTopColor: project.splash.loaderColor }}
                  />
                )}
                {project.splash.loaderStyle === 'bar' && (
                  <div className="w-20 h-1.5 bg-white/20 rounded-full overflow-hidden">
                    <div
                      className="w-10 h-full rounded-full animate-pulse"
                      style={{ backgroundColor: project.splash.loaderColor }}
                    />
                  </div>
                )}
                {project.splash.loaderStyle === 'pulse' && (
                  <div
                    className="w-4 h-4 rounded-full animate-ping"
                    style={{ backgroundColor: project.splash.loaderColor }}
                  />
                )}
              </div>
            </div>

            {/* Splash Controls matching video 01:21 - 01:23 */}
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Splash screen background
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={project.splash.bgColor}
                      onChange={(e) =>
                        setProject((p) => ({
                          ...p,
                          splash: { ...p.splash, bgColor: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-xl"
                    />
                    <div
                      className="w-7 h-7 rounded-lg border border-slate-300 shrink-0"
                      style={{ backgroundColor: project.splash.bgColor }}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Loader style
                  </label>
                  <select
                    value={project.splash.loaderStyle}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        splash: {
                          ...p.splash,
                          loaderStyle: e.target.value as any,
                        },
                      }))
                    }
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white"
                  >
                    <option value="circle">Circle</option>
                    <option value="bar">Bar</option>
                    <option value="pulse">Pulse</option>
                    <option value="none">None</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Ring / loader color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={project.splash.loaderColor}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        splash: { ...p.splash, loaderColor: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-xl"
                  />
                  <div
                    className="w-7 h-7 rounded-lg border border-slate-300 shrink-0"
                    style={{ backgroundColor: project.splash.loaderColor }}
                  />
                </div>
              </div>

              {/* Sliders matching video 01:22 - 01:23 */}
              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Icon size</span>
                  <span className="font-semibold">{project.splash.iconSize}dp</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="180"
                  value={project.splash.iconSize}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, iconSize: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Icon corners</span>
                  <span className="font-semibold">{project.splash.iconCorners}dp</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="48"
                  value={project.splash.iconCorners}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, iconCorners: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Loader size</span>
                  <span className="font-semibold">{project.splash.loaderSize}dp</span>
                </div>
                <input
                  type="range"
                  min="24"
                  max="80"
                  value={project.splash.loaderSize}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, loaderSize: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Spacing</span>
                  <span className="font-semibold">{project.splash.spacing}dp</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="50"
                  value={project.splash.spacing}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, spacing: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Display duration</span>
                  <span className="font-semibold">{project.splash.displayDuration}s</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="0.5"
                  value={project.splash.displayDuration}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, displayDuration: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Bar / loader thickness</span>
                  <span className="font-semibold">{project.splash.loaderThickness}dp</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="12"
                  value={project.splash.loaderThickness}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, loaderThickness: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-700 mb-1">
                  <span>Fade transition duration</span>
                  <span className="font-semibold">{project.splash.fadeDuration}ms</span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="1000"
                  step="50"
                  value={project.splash.fadeDuration}
                  onChange={(e) =>
                    setProject((p) => ({
                      ...p,
                      splash: { ...p.splash, fadeDuration: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-sky-600"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 7: WEBVIEW */}
        {currentStep === 7 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Navigation & Experience</h2>
            </div>

            <div className="space-y-3">
              {[
                {
                  key: 'pullToRefresh',
                  title: 'Pull to refresh',
                  desc: 'Swipe down to reload the web page',
                },
                {
                  key: 'noInternetDialog',
                  title: 'No internet dialog',
                  desc: 'Show an alert to retry when connection is lost',
                },
                {
                  key: 'loadingIndicator',
                  title: 'Loading indicator',
                  desc: 'Show a progress bar at the top while loading',
                },
                {
                  key: 'backButtonNavigation',
                  title: 'Back button history navigation',
                  desc: 'Navigate back in web history on back button press',
                },
                {
                  key: 'exitConfirmDialog',
                  title: 'Exit confirmation dialog',
                  desc: 'Show a confirmation popup before closing the app',
                },
              ].map((item) => (
                <label
                  key={item.key}
                  className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50/70 border border-slate-100 cursor-pointer hover:bg-slate-50 transition"
                >
                  <input
                    type="checkbox"
                    checked={(project.webView as any)[item.key]}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        webView: {
                          ...p.webView,
                          [item.key]: e.target.checked,
                        },
                      }))
                    }
                    className="w-4 h-4 rounded text-sky-600 mt-0.5 accent-sky-600"
                  />
                  <div>
                    <div className="text-xs font-semibold text-slate-800">
                      {item.title}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{item.desc}</div>
                  </div>
                </label>
              ))}
            </div>

            {/* Advanced WebView Settings matching video 01:29 - 01:36 */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-xl bg-sky-600 text-white text-xs">
                    ⭐
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      Advanced WebView Settings (Pro Free)
                    </div>
                    <div className="text-[11px] text-slate-500">
                      All advanced controls unlocked for free!
                    </div>
                  </div>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                  UNLOCKED
                </span>
              </div>

              <div className="space-y-3">
                {[
                  { key: 'javascriptEnabled', title: 'JavaScript Enabled' },
                  { key: 'domStorageEnabled', title: 'DOM Storage Enabled' },
                  { key: 'allowFileAccess', title: 'Allow File Access' },
                  { key: 'allowContentAccess', title: 'Allow Content Access' },
                  { key: 'universalFileAccess', title: 'Universal File Access' },
                  { key: 'fileAccessFromFileUrls', title: 'File Access From File URLs' },
                  { key: 'builtInZoomControls', title: 'Built-in Zoom Controls' },
                  { key: 'useWideViewport', title: 'Use Wide Viewport' },
                  { key: 'loadWithOverviewMode', title: 'Load With Overview Mode' },
                  { key: 'geolocationEnabled', title: 'Geolocation Enabled' },
                ].map((item) => (
                  <label
                    key={item.key}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-white border border-slate-100 shadow-xs cursor-pointer"
                  >
                    <span className="text-xs font-semibold text-slate-800">
                      {item.title}
                    </span>
                    <input
                      type="checkbox"
                      checked={(project.webView as any)[item.key]}
                      onChange={(e) =>
                        setProject((p) => ({
                          ...p,
                          webView: {
                            ...p.webView,
                            [item.key]: e.target.checked,
                          },
                        }))
                      }
                      className="w-5 h-5 rounded text-sky-600 accent-sky-600"
                    />
                  </label>
                ))}

                {/* Dropdowns for Cache & Mixed Content Mode */}
                <div className="space-y-1 pt-1">
                  <label className="text-xs font-semibold text-slate-700 block">
                    Cache Mode
                  </label>
                  <select
                    value={project.webView.cacheMode}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        webView: {
                          ...p.webView,
                          cacheMode: e.target.value as any,
                        },
                      }))
                    }
                    className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none bg-white font-medium"
                  >
                    <option value="LOAD_DEFAULT">Load Default</option>
                    <option value="LOAD_CACHE_ELSE_NETWORK">Cache Else Network</option>
                    <option value="LOAD_NO_CACHE">No Cache</option>
                    <option value="LOAD_CACHE_ONLY">Cache Only</option>
                  </select>
                </div>

                <div className="space-y-1 pt-1">
                  <label className="text-xs font-semibold text-slate-700 block">
                    Mixed Content Mode
                  </label>
                  <select
                    value={project.webView.mixedContentMode}
                    onChange={(e) =>
                      setProject((p) => ({
                        ...p,
                        webView: {
                          ...p.webView,
                          mixedContentMode: e.target.value as any,
                        },
                      }))
                    }
                    className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none bg-white font-medium"
                  >
                    <option value="COMPATIBILITY_MODE">Compatibility Mode</option>
                    <option value="ALWAYS_ALLOW">Always Allow</option>
                    <option value="NEVER_ALLOW">Never Allow</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 8: ADS */}
        {currentStep === 8 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">AdMob Ads</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Monetize your app with Google AdMob banners and interstitials
              </p>
            </div>

            <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer">
              <div>
                <div className="text-xs font-semibold text-slate-800">
                  Enable AdMob ads
                </div>
                <div className="text-[11px] text-slate-400">
                  Turn this on to show ads in your app
                </div>
              </div>
              <input
                type="checkbox"
                checked={project.admob.enabled}
                onChange={(e) =>
                  setProject((p) => ({
                    ...p,
                    admob: { ...p.admob, enabled: e.target.checked },
                  }))
                }
                className="w-5 h-5 rounded text-sky-600"
              />
            </label>
          </div>
        )}

        {/* STEP 9: SUMMARY */}
        {currentStep === 9 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Summary: Is Everything Correct?
              </h2>
            </div>

            <div className="space-y-2.5">
              {[
                { step: 1, label: 'App Name', val: project.name },
                { step: 1, label: 'Package', val: project.packageName },
                { step: 1, label: 'Version', val: `${project.versionName} (${project.versionCode})` },
                { step: 2, label: 'Content', val: project.selectedFileName || 'index.html' },
                {
                  step: 3,
                  label: 'Display',
                  val: `${project.orientation} • Color: ${project.primaryColor}`,
                },
                {
                  step: 4,
                  label: 'Permissions',
                  val: `${Object.values(project.permissions).filter(Boolean).length} permissions (Camera, Video, Photo, GPS)`,
                },
                { step: 5, label: 'Icon', val: project.iconName || 'Selected' },
                {
                  step: 7,
                  label: 'WebView',
                  val: 'JavaScript + Google OAuth Bypass Active',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-slate-50/70 border border-slate-100 flex items-center justify-between"
                >
                  <div>
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      {item.label}
                    </div>
                    <div className="text-xs font-semibold text-slate-800 mt-0.5 truncate max-w-[280px]">
                      {item.val}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(item.step)}
                    className="p-1.5 text-sky-600 hover:text-sky-700 rounded-lg hover:bg-sky-50 cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 10: OUTPUT */}
        {currentStep === 10 && (
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-6 animate-in fade-in duration-200">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Output Settings</h2>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">
                Format
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setProject((p) => ({ ...p, outputFormat: 'apk' }))}
                  className={`py-3 px-4 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                    project.outputFormat === 'apk'
                      ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  APK (Standard Android)
                </button>
                <button
                  type="button"
                  onClick={() => setProject((p) => ({ ...p, outputFormat: 'aab' }))}
                  className={`py-3 px-4 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                    project.outputFormat === 'aab'
                      ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  AAB (Play Store)
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Select Keystore
              </label>
              <select
                value={project.keystoreId}
                onChange={(e) =>
                  setProject((p) => ({ ...p, keystoreId: e.target.value }))
                }
                className="w-full px-4 py-3 text-sm border-2 border-slate-200 rounded-2xl focus:border-sky-500 focus:outline-none bg-white font-medium mb-2"
              >
                {keystores.map((ks) => (
                  <option key={ks.id} value={ks.id}>
                    {ks.name} (Alias: {ks.alias})
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={onManageKeystore}
                className="w-full py-2.5 px-4 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Key className="w-3.5 h-3.5" /> Manage Keystore
              </button>
            </div>

            {/* Build APK button */}
            <div className="pt-4 space-y-2">
              <button
                type="button"
                onClick={() => onSaveAndBuild(project)}
                className="w-full py-4 px-6 bg-sky-600 hover:bg-sky-700 active:scale-[0.98] text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-xl shadow-sky-600/30 text-sm transition cursor-pointer"
              >
                <Sparkles className="w-5 h-5" />
                <span>Build {project.outputFormat.toUpperCase()}</span>
              </button>
              <p className="text-center text-[11px] text-slate-400">
                This process may take up to 1 minute, do not turn off your screen
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Footer Navigation Buttons */}
      <footer className="sticky bottom-0 bg-white border-t border-slate-100 p-4">
        <div className="max-w-xl mx-auto flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleBack}
            className="flex-1 py-3 px-4 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-2xl font-semibold text-xs transition cursor-pointer"
          >
            {currentStep === 1 ? 'Cancel' : 'Back'}
          </button>
          {currentStep < 10 && (
            <button
              type="button"
              onClick={handleNext}
              className="flex-1 py-3 px-4 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl font-semibold text-xs transition shadow-md shadow-sky-600/20 cursor-pointer"
            >
              Next
            </button>
          )}
        </div>
      </footer>
    </div>
  );
};
