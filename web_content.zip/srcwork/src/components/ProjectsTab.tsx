import React, { useState } from 'react';
import {
  Plus,
  Play,
  Hammer,
  FolderArchive,
  Edit3,
  Trash2,
  Zap,
  Sliders,
  MoreVertical,
  X,
  FileCode,
} from 'lucide-react';
import { Project } from '../types';

interface Props {
  projects: Project[];
  onCreateProject: (mode: 'quick' | 'advanced') => void;
  onEditProject: (project: Project) => void;
  onDeleteProject: (projectId: string) => void;
  onBuildProject: (project: Project) => void;
  onTestProject: (project: Project) => void;
  onExportProjectZip: (project: Project) => void;
  onExportSingleIndex?: () => void;
}

export const ProjectsTab: React.FC<Props> = ({
  projects,
  onCreateProject,
  onEditProject,
  onDeleteProject,
  onBuildProject,
  onTestProject,
  onExportProjectZip,
  onExportSingleIndex,
}) => {
  const [showBuildChoiceModal, setShowBuildChoiceModal] = useState(false);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  const formatDate = (ts?: number) => {
    const d = ts ? new Date(ts) : new Date();
    const day = d.getDate().toString().padStart(2, '0');
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const year = d.getFullYear();
    return `${day}.${month}.${year}`;
  };

  const confirmDelete = () => {
    if (projectToDelete) {
      onDeleteProject(projectToDelete.id);
      setProjectToDelete(null);
    }
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-xl mx-auto space-y-4">
      {/* Create Project Button */}
      <button
        onClick={() => setShowBuildChoiceModal(true)}
        className="w-full py-3.5 px-4 bg-sky-600 hover:bg-sky-700 active:scale-[0.98] text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-sky-600/20 transition cursor-pointer"
      >
        <Plus className="w-5 h-5" />
        <span>Create Project</span>
      </button>

      {/* Single index.html banner for instant one-file export */}
      {onExportSingleIndex && (
        <div className="p-3.5 bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-100 rounded-2xl flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-600 text-white shrink-0">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-800">
                Poora Code Ek Hi index.html Me Chahiye?
              </div>
              <div className="text-[11px] text-slate-500">
                Self-contained standalone single file with zero dependencies
              </div>
            </div>
          </div>
          <button
            onClick={onExportSingleIndex}
            className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shrink-0 transition"
          >
            Get File
          </button>
        </div>
      )}

      {/* Projects List or Empty State */}
      {projects.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center select-none animate-in fade-in duration-200">
          <div className="w-48 h-48 relative flex items-center justify-center mb-6">
            <svg
              viewBox="0 0 200 200"
              className="w-full h-full text-slate-800"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
            >
              <circle cx="70" cy="50" r="14" fill="currentColor" />
              <line x1="70" y1="64" x2="70" y2="120" strokeWidth="4" />
              <line x1="70" y1="120" x2="55" y2="170" strokeWidth="3.5" />
              <line x1="70" y1="120" x2="85" y2="170" strokeWidth="3.5" />
              <path d="M 70 80 L 85 95 L 95 90" strokeWidth="3.5" strokeLinecap="round" />
              <path d="M 70 80 L 55 105" strokeWidth="3.5" strokeLinecap="round" />
              <rect x="120" y="145" width="45" height="25" rx="3" fill="#1e293b" />
              <path d="M 132 145 L 132 138 L 152 138 L 152 145" stroke="#1e293b" strokeWidth="2.5" />
              <line x1="108" y1="140" x2="114" y2="170" stroke="#64748b" strokeWidth="3" />
              <circle cx="108" cy="138" r="3" fill="#64748b" />
              <line x1="120" y1="165" x2="105" y2="170" stroke="#64748b" strokeWidth="2.5" />
            </svg>
          </div>
          <p className="text-slate-600 font-medium text-sm">
            No projects yet. Tap + to create one!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {projects.map((proj) => (
            <div
              key={proj.id}
              className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs hover:shadow-md transition space-y-3 relative"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-13 h-13 rounded-2xl flex items-center justify-center overflow-hidden border border-slate-100 shadow-xs"
                    style={{ backgroundColor: proj.primaryColor || '#fb923c' }}
                  >
                    {proj.iconUrl ? (
                      <img
                        src={proj.iconUrl}
                        alt={proj.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="grid grid-cols-2 gap-1 p-2 text-white font-bold text-xs">
                        <span>+</span><span>-</span><span>×</span><span>÷</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{proj.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {formatDate(proj.createdAt)}
                    </p>
                    <p className="text-xs text-slate-500 font-medium">
                      {proj.versionName} ({proj.versionCode})
                    </p>
                  </div>
                </div>

                {/* Right Action Icons (3-dots & blue trash can) */}
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <button
                      onClick={() =>
                        setActiveMenuId(activeMenuId === proj.id ? null : proj.id)
                      }
                      className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-50 cursor-pointer"
                      title="Options"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>

                    {activeMenuId === proj.id && (
                      <>
                        <div
                          className="fixed inset-0 z-40"
                          onClick={() => setActiveMenuId(null)}
                        />
                        <div className="absolute right-0 mt-1 w-52 bg-white rounded-2xl shadow-xl border border-slate-100 py-1.5 z-50 text-xs font-semibold animate-in fade-in zoom-in-95 duration-150">
                          <button
                            onClick={() => {
                              setActiveMenuId(null);
                              onEditProject(proj);
                            }}
                            className="w-full px-4 py-2.5 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                          >
                            <Edit3 className="w-4 h-4 text-sky-600" />
                            <span>Edit Settings</span>
                          </button>
                          <button
                            onClick={() => {
                              setActiveMenuId(null);
                              onExportProjectZip(proj);
                            }}
                            className="w-full px-4 py-2.5 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                          >
                            <FolderArchive className="w-4 h-4 text-amber-600" />
                            <span>Export Project (ZIP)</span>
                          </button>
                          <div className="border-t border-slate-100 my-1" />
                          <button
                            onClick={() => {
                              setActiveMenuId(null);
                              setProjectToDelete(proj);
                            }}
                            className="w-full px-4 py-2.5 text-left text-red-600 hover:bg-red-50 flex items-center gap-2.5"
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                            <span>Delete Project</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Direct Trash Icon */}
                  <button
                    onClick={() => setProjectToDelete(proj)}
                    className="p-2 text-sky-600 hover:text-red-600 rounded-full hover:bg-sky-50 transition cursor-pointer"
                    title="Delete Project"
                  >
                    <Trash2 className="w-5 h-5 text-sky-600" />
                  </button>
                </div>
              </div>

              {/* Quick Actions Row */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-50">
                <button
                  onClick={() => onBuildProject(proj)}
                  className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl text-xs font-semibold transition cursor-pointer"
                >
                  <Hammer className="w-3.5 h-3.5" />
                  <span>Build APK</span>
                </button>
                <button
                  onClick={() => onTestProject(proj)}
                  className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-xs font-semibold transition cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Live Test</span>
                </button>
                <button
                  onClick={() => onExportProjectZip(proj)}
                  className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold transition cursor-pointer"
                  title="Export Android Studio Project"
                >
                  <FolderArchive className="w-3.5 h-3.5 text-amber-500" />
                  <span>Android ZIP</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Custom In-App Delete Confirmation Modal */}
      {projectToDelete && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className="fixed inset-0"
            onClick={() => setProjectToDelete(null)}
          />
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative z-10 animate-in zoom-in-95 duration-150 text-center">
            <div className="w-14 h-14 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Delete Project?
            </h3>
            <p className="text-xs text-slate-500 mb-5 leading-relaxed">
              Are you sure you want to delete <b className="text-slate-800 font-semibold">"{projectToDelete.name}"</b>? This will permanently remove it from your projects.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setProjectToDelete(null)}
                className="py-3 px-4 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-2xl font-semibold text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="py-3 px-4 bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white rounded-2xl font-semibold text-xs shadow-md shadow-red-600/20 transition cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Build Choice Modal */}
      {showBuildChoiceModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-4 pt-16 sm:pt-20 overflow-y-auto">
          <div
            className="fixed inset-0"
            onClick={() => setShowBuildChoiceModal(false)}
          />
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative z-10 animate-in zoom-in-95 fade-in slide-in-from-top-4 duration-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">
                How do you want to build?
              </h2>
              <button
                onClick={() => setShowBuildChoiceModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setShowBuildChoiceModal(false);
                  onCreateProject('quick');
                }}
                className="w-full p-4 rounded-2xl border border-slate-200 hover:border-sky-500 hover:bg-sky-50/50 flex items-start gap-3.5 text-left transition group cursor-pointer"
              >
                <div className="p-2.5 rounded-xl bg-sky-100 text-sky-600 group-hover:bg-sky-500 group-hover:text-white transition">
                  <Zap className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">Quick Build</h4>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                    Just name, content and icon. We handle the rest.
                  </p>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowBuildChoiceModal(false);
                  onCreateProject('advanced');
                }}
                className="w-full p-4 rounded-2xl border border-slate-200 hover:border-sky-500 hover:bg-sky-50/50 flex items-start gap-3.5 text-left transition group cursor-pointer"
              >
                <div className="p-2.5 rounded-xl bg-slate-100 text-slate-600 group-hover:bg-sky-500 group-hover:text-white transition">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">Advanced Build</h4>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                    Full control over package, SDK, theme and permissions.
                  </p>
                </div>
              </button>
            </div>

            <button
              onClick={() => setShowBuildChoiceModal(false)}
              className="mt-4 w-full py-2.5 text-slate-400 hover:text-slate-600 text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
