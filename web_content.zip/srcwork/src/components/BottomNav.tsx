import React from 'react';
import { Home, Wrench, Settings } from 'lucide-react';

interface Props {
  currentTab: 'projects' | 'templates' | 'settings';
  onSelectTab: (tab: 'projects' | 'templates' | 'settings') => void;
}

export const BottomNav: React.FC<Props> = ({ currentTab, onSelectTab }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-100 py-1.5 px-6 shadow-lg">
      <div className="max-w-md mx-auto flex items-center justify-around">
        <button
          onClick={() => onSelectTab('projects')}
          className={`flex flex-col items-center py-1 px-4 rounded-2xl transition duration-150 ${
            currentTab === 'projects'
              ? 'text-sky-600 font-semibold'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div
            className={`p-1 rounded-xl transition ${
              currentTab === 'projects' ? 'bg-sky-50' : ''
            }`}
          >
            <Home className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">Projects</span>
        </button>

        <button
          onClick={() => onSelectTab('templates')}
          className={`flex flex-col items-center py-1 px-4 rounded-2xl transition duration-150 ${
            currentTab === 'templates'
              ? 'text-sky-600 font-semibold'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div
            className={`p-1 rounded-xl transition ${
              currentTab === 'templates' ? 'bg-sky-50' : ''
            }`}
          >
            <Wrench className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">Templates</span>
        </button>

        <button
          onClick={() => onSelectTab('settings')}
          className={`flex flex-col items-center py-1 px-4 rounded-2xl transition duration-150 ${
            currentTab === 'settings'
              ? 'text-sky-600 font-semibold'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div
            className={`p-1 rounded-xl transition ${
              currentTab === 'settings' ? 'bg-sky-50' : ''
            }`}
          >
            <Settings className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">Settings</span>
        </button>
      </div>
    </div>
  );
};
