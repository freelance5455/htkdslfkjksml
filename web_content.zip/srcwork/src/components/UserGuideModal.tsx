import React from 'react';
import { X, BookOpen, Sparkles, Smartphone, Code, Key } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const UserGuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-sky-100 text-sky-700">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">How to Use & Play Store Guide</h2>
              <p className="text-xs text-slate-500">HTML to APK Studio Pro Complete Documentation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-600">
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <Code className="w-4 h-4 text-sky-600" />
              1. Single index.html or ZIP File Upload
            </h3>
            <p className="text-xs leading-relaxed">
              You can upload either a single <b>index.html</b> file or a complete <b>ZIP archive</b> containing your HTML, CSS, JavaScript, and images. All assets are packed locally into the Android app's <code>assets/</code> folder so the app runs <b>100% offline</b> without needing an internet connection.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-sky-50 border border-sky-100 space-y-2">
            <h3 className="font-bold text-sky-950 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-sky-600" />
              2. Google Sign-in & JavaScript Compatibility
            </h3>
            <p className="text-xs text-sky-900 leading-relaxed">
              Normally, Google blocks OAuth authentication inside standard Android WebViews with <b>Error 403: disallowed_useragent</b>.
              Our builder automatically removes <code>; wv</code> and standard webview tokens from the <code>User-Agent</code> string. This makes Google authenticate your app just like Google Chrome on Android!
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-600" />
              3. Native Camera, Photos, Videos & GPS Location
            </h3>
            <p className="text-xs leading-relaxed">
              When you select permissions in Step 4:
            </p>
            <ul className="text-xs space-y-1 list-disc list-inside text-slate-700">
              <li><b>Photos & Videos:</b> Configures <code>WebChromeClient.onShowFileChooser</code> and <code>READ_MEDIA_IMAGES</code>/<code>READ_MEDIA_VIDEO</code>.</li>
              <li><b>Camera:</b> Grants WebRTC camera streaming and photo capture.</li>
              <li><b>GPS Location:</b> Automatically hooks HTML5 <code>navigator.geolocation</code> into Android's <code>ACCESS_FINE_LOCATION</code>.</li>
              <li><b>Vibration:</b> Connects <code>navigator.vibrate</code> to phone haptic motors.</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <Key className="w-4 h-4 text-amber-600" />
              4. Play Store (AAB) & Keystore Publishing
            </h3>
            <p className="text-xs leading-relaxed">
              For publishing to Google Play Console:
            </p>
            <ol className="text-xs space-y-1 list-decimal list-inside text-slate-700">
              <li>Create or select your release Keystore in <b>Keystore Manager</b>.</li>
              <li>Choose <b>AAB (Play Store)</b> format in Output settings.</li>
              <li>Download the ready project ZIP or signed bundle.</li>
              <li>Upload directly to Google Play Console under Production or Internal Testing!</li>
            </ol>
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold rounded-xl shadow-sm cursor-pointer"
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
};
