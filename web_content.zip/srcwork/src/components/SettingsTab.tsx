import React, { useState } from 'react';
import {
  Globe,
  Palette,
  Key,
  Star,
  HelpCircle,
  BookOpen,
  FileText,
  Mail,
  Trash2,
  Gift,
  ChevronRight,
  Check,
  FileCode,
} from 'lucide-react';

interface Props {
  onOpenKeystore: () => void;
  onOpenPro: () => void;
  onOpenGuide: () => void;
  onExportSingleIndex?: () => void;
}

export const SettingsTab: React.FC<Props> = ({
  onOpenKeystore,
  onOpenPro,
  onOpenGuide,
  onExportSingleIndex,
}) => {
  const [cacheCleared, setCacheCleared] = useState(false);
  const [cacheSize, setCacheSize] = useState('22.8 MB');

  const handleClearCache = () => {
    setCacheCleared(true);
    setCacheSize('0 KB');
    setTimeout(() => setCacheCleared(false), 3000);
  };

  return (
    <div className="pb-24 pt-3 px-4 max-w-xl mx-auto space-y-3">
      {/* Pro Banner */}
      <button
        onClick={onOpenPro}
        className="w-full p-4 rounded-3xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white flex items-center justify-between shadow-lg shadow-sky-600/20 text-left cursor-pointer"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-md">
            <Star className="w-5 h-5 fill-amber-300 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 font-bold text-sm">
              <span>HTML to APK Pro</span>
              <span className="text-[10px] bg-emerald-400 text-slate-950 font-extrabold px-2 py-0.5 rounded-full">
                ACTIVE
              </span>
            </div>
            <p className="text-xs text-sky-100 mt-0.5">
              100% Free Lifetime • All restrictions removed
            </p>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-sky-200" />
      </button>

      {/* Settings List */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm divide-y divide-slate-100 overflow-hidden text-sm">
        {/* Single File Option */}
        {onExportSingleIndex && (
          <div
            onClick={onExportSingleIndex}
            className="p-4 flex items-center justify-between hover:bg-sky-50 cursor-pointer transition bg-sky-50/40"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-sky-600 text-white">
                <FileCode className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-sky-900 text-xs sm:text-sm">
                  Single index.html File (All-in-One)
                </div>
                <div className="text-[11px] text-sky-700">
                  Poora code ek hi index file me download / copy karein
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-sky-400" />
          </div>
        )}

        {/* Language */}
        <div className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-sky-50 text-sky-600">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Language</div>
              <div className="text-[11px] text-slate-400">System default (English / Urdu)</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Theme */}
        <div className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Theme</div>
              <div className="text-[11px] text-slate-400">System (Auto)</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Keystore Manager */}
        <div
          onClick={onOpenKeystore}
          className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Keystore Manager</div>
              <div className="text-[11px] text-slate-400">Create & manage APK release keys</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Pro / Features */}
        <div
          onClick={onOpenPro}
          className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Star className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Pro Features Unlocked</div>
              <div className="text-[11px] text-slate-400">Google OAuth fix, AAB export, no watermarks</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* How to Use */}
        <div
          onClick={onOpenGuide}
          className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-sky-50 text-sky-600">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">How to Use</div>
              <div className="text-[11px] text-slate-400">Single index.html or ZIP to native app guide</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Play Store Guide */}
        <div
          onClick={onOpenGuide}
          className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-teal-50 text-teal-600">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Play Store Guide</div>
              <div className="text-[11px] text-slate-400">How to publish AAB & sign with Keystore</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Legal */}
        <div className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-100 text-slate-600">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Legal & Privacy</div>
              <div className="text-[11px] text-slate-400">Terms of service, Apache 2.0 license</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Send Feedback */}
        <div className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Send Feedback</div>
              <div className="text-[11px] text-slate-400">support@htmltoapk.pro</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>

        {/* Clear Cache */}
        <div
          onClick={handleClearCache}
          className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-rose-50 text-rose-600">
              <Trash2 className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Clear Cache</div>
              <div className="text-[11px] text-slate-400">
                {cacheCleared ? 'Cache cleared successfully!' : `Clean temporary build files (${cacheSize})`}
              </div>
            </div>
          </div>
          {cacheCleared ? (
            <Check className="w-4 h-4 text-emerald-600" />
          ) : (
            <ChevronRight className="w-4 h-4 text-slate-300" />
          )}
        </div>

        {/* Get Pro for Free */}
        <div
          onClick={onOpenPro}
          className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Gift className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-xs sm:text-sm">Get Pro for Free</div>
              <div className="text-[11px] text-slate-400">Unlocked and activated for all users</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300" />
        </div>
      </div>

      {/* Note from Developer */}
      <div className="p-4 rounded-3xl bg-amber-50/70 border border-amber-200/60 text-xs text-amber-900 space-y-2">
        <div className="flex items-center gap-2 font-bold text-amber-950">
          <span>☕</span>
          <span>A Note from the Developer</span>
        </div>
        <p className="leading-relaxed text-amber-800">
          Hi! My goal is to empower you to turn your web projects, single index.html files, and zip packages into real Android apps seamlessly, with native camera, photo/video picker, GPS location, and Google Sign-in support, without complex setup. Thank you for your support!
        </p>
      </div>
    </div>
  );
};
