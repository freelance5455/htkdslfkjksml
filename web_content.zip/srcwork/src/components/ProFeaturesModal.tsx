import React from 'react';
import { Sparkles, Check, X, ShieldCheck } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ProFeaturesModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center pt-2">
          <div className="inline-flex p-3 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 text-white shadow-lg shadow-orange-500/30 mb-3">
            <Sparkles className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">HTML to APK Pro</h2>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold mt-2">
            <ShieldCheck className="w-3.5 h-3.5" /> 100% Free Lifetime Unlocked
          </div>
          <p className="text-sm text-slate-500 mt-2">
            All premium features and limits have been completely unlocked for you!
          </p>
        </div>

        <div className="mt-6 space-y-3">
          {[
            { title: 'Google OAuth & Sign-in Fix', desc: 'Custom Chrome User-Agent removes 403 disallowed_useragent' },
            { title: 'All Native Permissions Enabled', desc: 'Camera, Video, Photos, GPS Location, Mic & Storage 100% supported' },
            { title: 'Full Offline Support', desc: 'Zero internet required, assets bundled directly into APK assets' },
            { title: 'Export in AAB format for Play Store', desc: 'Ready for official Google Play Store submission' },
            { title: 'Full Android Studio Project (ZIP)', desc: 'Complete Kotlin & Gradle source code included' },
            { title: 'No Watermark in Generated Apps', desc: 'Clean, professional branding for all your applications' },
            { title: 'Custom Keystore Manager', desc: 'Generate & sign with custom release keystores' },
          ].map((f, i) => (
            <div key={i} className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="p-1 rounded-full bg-emerald-500 text-white mt-0.5">
                <Check className="w-3.5 h-3.5" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-800">{f.title}</div>
                <div className="text-[11px] text-slate-500">{f.desc}</div>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full py-3.5 px-4 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl font-semibold shadow-md shadow-sky-600/20 transition active:scale-[0.98] cursor-pointer"
        >
          Awesome, Continue!
        </button>
      </div>
    </div>
  );
};
