import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  RotateCw,
  MapPin,
  Wifi,
  WifiOff,
  Vibrate,
  ArrowLeft,
  Smartphone,
  CheckCircle2,
} from 'lucide-react';
import { Project } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
}

export const LiveSimulatorModal: React.FC<Props> = ({ isOpen, onClose, project }) => {
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [isOffline, setIsOffline] = useState(false);
  const [simulatedVibrate, setSimulatedVibrate] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState('7:19 AM');
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;
      setCurrentTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!isOpen) return null;

  const showNotification = (msg: string) => {
    setNotificationMsg(msg);
    setTimeout(() => setNotificationMsg(null), 3000);
  };

  const triggerVibration = () => {
    setSimulatedVibrate(true);
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 100]);
    }
    showNotification('📱 Phone Vibrate: Pattern [100ms, 50ms, 100ms]');
    setTimeout(() => setSimulatedVibrate(false), 500);
  };

  const triggerMockGps = () => {
    showNotification('📍 GPS Location: 31.5204° N, 74.3587° E (Accuracy: 12m)');
    try {
      iframeRef.current?.contentWindow?.postMessage(
        { type: 'MOCK_GPS', coords: { latitude: 31.5204, longitude: 74.3587, accuracy: 12 } },
        '*'
      );
    } catch (e) {
      console.error(e);
    }
  };

  const triggerMockGoogleLogin = () => {
    showNotification('🔑 Google Sign-In: OAuth 2.0 handshake verified (Chrome UA)');
    try {
      iframeRef.current?.contentWindow?.postMessage(
        { type: 'GOOGLE_SIGN_IN_SUCCESS', email: 'user.test@gmail.com' },
        '*'
      );
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="flex flex-col lg:flex-row items-center justify-center gap-6 max-w-6xl w-full">
        {/* Device Frame */}
        <div
          className={`relative transition-all duration-300 ease-out flex flex-col items-center select-none ${
            orientation === 'portrait' ? 'w-[360px] h-[720px]' : 'w-[720px] h-[360px]'
          } ${simulatedVibrate ? 'animate-bounce' : ''}`}
        >
          {/* Phone Shell */}
          <div className="w-full h-full bg-slate-900 border-[8px] border-slate-800 rounded-[48px] shadow-2xl overflow-hidden flex flex-col relative ring-1 ring-white/10">
            {/* Status Bar */}
            {project.showStatusBar && (
              <div
                className="w-full h-7 px-6 flex items-center justify-between text-[11px] font-semibold tracking-tight z-20 text-white"
                style={{ backgroundColor: project.primaryColor || '#1e293b' }}
              >
                <span>{currentTime}</span>
                {/* Notch / Camera Cutout */}
                {project.showCameraCutout && (
                  <div className="w-4 h-4 rounded-full bg-black mx-auto ring-1 ring-slate-800/80"></div>
                )}
                <div className="flex items-center gap-2">
                  {isOffline ? (
                    <span className="flex items-center gap-1 text-red-300">
                      <WifiOff className="w-3.5 h-3.5" /> No Net
                    </span>
                  ) : (
                    <span className="flex items-center gap-1">
                      <Wifi className="w-3.5 h-3.5" /> 4G
                    </span>
                  )}
                  <span className="text-[10px]">100%</span>
                </div>
              </div>
            )}

            {/* Notification Banner Overlay */}
            {notificationMsg && (
              <div className="absolute top-9 left-3 right-3 z-30 p-2.5 bg-slate-900/95 border border-sky-500/40 text-sky-100 rounded-xl text-xs shadow-lg backdrop-blur animate-in slide-in-from-top-2 duration-150 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                <span className="truncate">{notificationMsg}</span>
              </div>
            )}

            {/* In-app Screen Content */}
            <div className="flex-1 bg-white relative overflow-hidden">
              {isOffline && project.webView.noInternetDialog ? (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-slate-100 text-slate-800">
                  <WifiOff className="w-12 h-12 text-slate-400 mb-3" />
                  <h3 className="font-bold text-base">No Internet Connection</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Please check your network settings and try again.
                  </p>
                  <button
                    onClick={() => setIsOffline(false)}
                    className="mt-4 px-4 py-2 bg-sky-600 text-white rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Retry
                  </button>
                </div>
              ) : (
                <iframe
                  ref={iframeRef}
                  srcDoc={project.htmlContent || '<h1>No content</h1>'}
                  title={project.name}
                  sandbox="allow-scripts allow-same-origin allow-modals allow-forms allow-popups"
                  className="w-full h-full border-none"
                />
              )}

              {/* Watermark preview if enabled */}
              {project.showWatermark && (
                <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur text-white text-[9px] px-2 py-0.5 rounded-full pointer-events-none">
                  Built with HTML to APK
                </div>
              )}
            </div>

            {/* Android Navigation Bar */}
            <div className="w-full h-9 bg-slate-950 flex items-center justify-around text-slate-400 z-20">
              <button
                onClick={() => {
                  try {
                    iframeRef.current?.contentWindow?.history.back();
                  } catch (e) {
                    console.error(e);
                  }
                  showNotification('Back button pressed (canGoBack)');
                }}
                className="p-1 hover:text-white cursor-pointer"
                title="Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="w-3.5 h-3.5 rounded-full border-2 border-slate-400" />
              <div className="w-3.5 h-3.5 border-2 border-slate-400 rounded-xs" />
            </div>
          </div>
        </div>

        {/* Controls & Device Hardware Testing Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white max-w-sm w-full space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-sky-400" />
              <div>
                <h3 className="font-bold text-sm text-slate-100">Live Device Tester</h3>
                <p className="text-[11px] text-slate-400">{project.name} (v{project.versionName})</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Hardware & Permissions Simulator
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={triggerVibration}
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold transition text-slate-200 cursor-pointer"
              >
                <Vibrate className="w-4 h-4 text-purple-400" />
                <span>Test Vibration</span>
              </button>
              <button
                onClick={triggerMockGps}
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold transition text-slate-200 cursor-pointer"
              >
                <MapPin className="w-4 h-4 text-emerald-400" />
                <span>Test GPS / Loc</span>
              </button>
              <button
                onClick={() => setIsOffline(!isOffline)}
                className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  isOffline ? 'bg-red-500/20 text-red-300 border border-red-500/40' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                }`}
              >
                {isOffline ? <WifiOff className="w-4 h-4 text-red-400" /> : <Wifi className="w-4 h-4 text-sky-400" />}
                <span>{isOffline ? 'Offline Mode' : 'Online Mode'}</span>
              </button>
              <button
                onClick={() => setOrientation(orientation === 'portrait' ? 'landscape' : 'portrait')}
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold transition text-slate-200 cursor-pointer"
              >
                <RotateCw className="w-4 h-4 text-amber-400" />
                <span>{orientation === 'portrait' ? 'Rotate Land' : 'Rotate Port'}</span>
              </button>
            </div>

            <button
              onClick={triggerMockGoogleLogin}
              className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-300 text-xs font-semibold transition cursor-pointer"
            >
              <span>🔑 Test Google Sign-in Handshake</span>
            </button>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 text-[11px] space-y-1.5 text-slate-400">
            <div className="flex justify-between">
              <span>Package:</span>
              <span className="font-mono text-slate-300 truncate max-w-[170px]">{project.packageName}</span>
            </div>
            <div className="flex justify-between">
              <span>JavaScript:</span>
              <span className="text-emerald-400 font-semibold">Enabled (ES6+)</span>
            </div>
            <div className="flex justify-between">
              <span>User-Agent Bypass:</span>
              <span className="text-sky-400 font-semibold">Active (OAuth Safe)</span>
            </div>
            <div className="flex justify-between">
              <span>Offline Ready:</span>
              <span className="text-emerald-400 font-semibold">100% Native</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold cursor-pointer"
          >
            Close Simulator
          </button>
        </div>
      </div>
    </div>
  );
};
