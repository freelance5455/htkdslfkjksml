import React, { useState } from 'react';
import { MoreVertical, ArrowLeft, HelpCircle, FileArchive, Download, Upload, FileCode } from 'lucide-react';

interface Props {
  currentTab: 'projects' | 'templates' | 'settings';
  isCreating: boolean;
  currentStep?: number;
  stepName?: string;
  onBack?: () => void;
  onImportZip?: () => void;
  onExportAllProjectsZip?: () => void;
  onExportAllAndroidZip?: () => void;
  onExportSingleIndexFile?: () => void;
  onHelp?: () => void;
}

export const TopHeader: React.FC<Props> = ({
  currentTab,
  isCreating,
  currentStep = 1,
  stepName = 'Info',
  onBack,
  onImportZip,
  onExportAllProjectsZip,
  onExportAllAndroidZip,
  onExportSingleIndexFile,
  onHelp,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);

  if (isCreating) {
    const progressPercent = currentStep * 10;
    return (
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-1 -ml-1 text-slate-700 hover:text-slate-900 rounded-full hover:bg-slate-100 transition"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-lg font-bold text-slate-900">New Project</h1>
          </div>
          <span className="text-xs font-semibold text-sky-600">
            Step {currentStep} / 10 • {stepName}
          </span>
        </div>
        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1">
          <div
            className="bg-sky-500 h-1 transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </header>
    );
  }

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between relative">
        <h1 className="text-xl font-bold tracking-tight text-slate-900">
          {currentTab === 'projects'
            ? 'My Projects'
            : currentTab === 'templates'
            ? 'Templates'
            : 'Settings'}
        </h1>

        <div className="flex items-center gap-1">
          {onExportSingleIndexFile && (
            <button
              onClick={onExportSingleIndexFile}
              className="px-2.5 py-1.5 text-xs font-semibold bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl flex items-center gap-1.5 transition"
              title="Get Single index.html File"
            >
              <FileCode className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Single index.html</span>
            </button>
          )}

          {currentTab === 'templates' && (
            <button
              onClick={onHelp}
              className="p-2 text-sky-600 hover:text-sky-700 rounded-full hover:bg-sky-50 transition"
              title="Help"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
          )}

          {currentTab === 'projects' && (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="p-2 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100 transition"
                title="Options"
              >
                <MoreVertical className="w-5 h-5" />
              </button>

              {menuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setMenuOpen(false)}
                  />
                  <div className="absolute right-0 mt-1 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 py-1.5 z-50 text-xs font-medium animate-in fade-in zoom-in-95 duration-150">
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onExportSingleIndexFile?.();
                      }}
                      className="w-full px-4 py-2.5 text-left text-sky-700 font-semibold hover:bg-sky-50 flex items-center gap-2.5"
                    >
                      <FileCode className="w-4 h-4 text-sky-600" />
                      <span>Single index.html File (All-in-One)</span>
                    </button>
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onImportZip?.();
                      }}
                      className="w-full px-4 py-2.5 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                    >
                      <Upload className="w-4 h-4 text-sky-600" />
                      <span>Import Project (ZIP)</span>
                    </button>
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onExportAllProjectsZip?.();
                      }}
                      className="w-full px-4 py-2.5 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                    >
                      <Download className="w-4 h-4 text-emerald-600" />
                      <span>Export All Projects (ZIP)</span>
                    </button>
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onExportAllAndroidZip?.();
                      }}
                      className="w-full px-4 py-2.5 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                    >
                      <FileArchive className="w-4 h-4 text-amber-600" />
                      <span>Export All as Android Projects (ZIP)</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
