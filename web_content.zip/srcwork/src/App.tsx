/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import JSZip from 'jszip';
import { Project, Keystore, TemplateItem } from './types';
import {
  getInitialProjects,
  saveProjects,
  getInitialKeystores,
  saveKeystores,
} from './utils/storage';
import { buildApkPackage, BuildLog } from './utils/apkBuilder';
import { generateAndroidProjectZip } from './utils/androidProjectGenerator';
import { TopHeader } from './components/TopHeader';
import { BottomNav } from './components/BottomNav';
import { ProjectsTab } from './components/ProjectsTab';
import { TemplatesTab } from './components/TemplatesTab';
import { SettingsTab } from './components/SettingsTab';
import { NewProjectWizard } from './components/NewProjectWizard';
import { LiveSimulatorModal } from './components/LiveSimulatorModal';
import { BuildProgressModal } from './components/BuildProgressModal';
import { KeystoreManagerModal } from './components/KeystoreManagerModal';
import { ProFeaturesModal } from './components/ProFeaturesModal';
import { UserGuideModal } from './components/UserGuideModal';
import { CodeEditorModal } from './components/CodeEditorModal';
import { SingleFileExportModal } from './components/SingleFileExportModal';

export default function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [keystores, setKeystores] = useState<Keystore[]>([]);
  const [currentTab, setCurrentTab] = useState<'projects' | 'templates' | 'settings'>('projects');

  // Wizard state
  const [isCreating, setIsCreating] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | undefined>(undefined);

  // Build Modal State
  const [buildModalOpen, setBuildModalOpen] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [buildStepText, setBuildStepText] = useState('');
  const [buildLogs, setBuildLogs] = useState<BuildLog[]>([]);
  const [isBuildComplete, setIsBuildComplete] = useState(false);
  const [activeBuildProject, setActiveBuildProject] = useState<Project | null>(null);
  const [builtApkBlob, setBuiltApkBlob] = useState<Blob | null>(null);

  // Simulator Modal State
  const [simulatorOpen, setSimulatorOpen] = useState(false);
  const [simulatorProject, setSimulatorProject] = useState<Project | null>(null);

  // Extra Modals
  const [keystoreModalOpen, setKeystoreModalOpen] = useState(false);
  const [proModalOpen, setProModalOpen] = useState(false);
  const [guideModalOpen, setGuideModalOpen] = useState(false);
  const [singleFileModalOpen, setSingleFileModalOpen] = useState(false);

  // Code Editor Modal
  const [codeEditorOpen, setCodeEditorOpen] = useState(false);
  const [codeToEdit, setCodeToEdit] = useState('');
  const [onSaveCodeCallback, setOnSaveCodeCallback] = useState<((newCode: string) => void) | null>(null);

  // Hidden File input for Zip import
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setProjects(getInitialProjects());
    setKeystores(getInitialKeystores());
  }, []);

  const handleUpdateProjects = (newProjects: Project[]) => {
    setProjects(newProjects);
    saveProjects(newProjects);
  };

  const handleSaveKeystore = (newKeystore: Keystore) => {
    const updated = [...keystores, newKeystore];
    setKeystores(updated);
    saveKeystores(updated);
  };

  const handleDeleteKeystore = (id: string) => {
    const updated = keystores.filter((k) => k.id !== id);
    setKeystores(updated);
    saveKeystores(updated);
  };

  // Start new project
  const handleStartCreate = (_mode: 'quick' | 'advanced') => {
    setEditingProject(undefined);
    setIsCreating(true);
  };

  // Edit existing project
  const handleEditProject = (proj: Project) => {
    setEditingProject(proj);
    setIsCreating(true);
  };

  // Delete project
  const handleDeleteProject = (id: string) => {
    const updated = projects.filter((p) => p.id !== id);
    handleUpdateProjects(updated);
  };

  // Save project from wizard and trigger build
  const handleSaveAndBuild = async (proj: Project) => {
    const updatedList = [...projects];
    const existingIndex = updatedList.findIndex((p) => p.id === proj.id);

    // Auto increment version code if enabled
    const finalProj: Project = {
      ...proj,
      versionCode: proj.autoIncrementVersion ? proj.versionCode + 1 : proj.versionCode,
      updatedAt: Date.now(),
      lastBuiltAt: Date.now(),
    };

    if (existingIndex >= 0) {
      updatedList[existingIndex] = finalProj;
    } else {
      updatedList.unshift(finalProj);
    }

    handleUpdateProjects(updatedList);
    setIsCreating(false);
    triggerBuildApk(finalProj);
  };

  // Trigger Build Modal & compilation animation
  const triggerBuildApk = async (proj: Project) => {
    setActiveBuildProject(proj);
    setBuildProgress(0);
    setBuildStepText('Initializing build environment...');
    setBuildLogs([]);
    setIsBuildComplete(false);
    setBuiltApkBlob(null);
    setBuildModalOpen(true);

    try {
      const blob = await buildApkPackage(proj, (percent, stepText, log) => {
        setBuildProgress(percent);
        setBuildStepText(stepText);
        setBuildLogs((prev) => [...prev, log]);
      });
      setBuiltApkBlob(blob);
      setIsBuildComplete(true);
    } catch (e: any) {
      setBuildLogs((prev) => [
        ...prev,
        {
          timestamp: new Date().toTimeString().split(' ')[0],
          message: 'Error during build: ' + (e?.message || e),
          type: 'warn',
        },
      ]);
    }
  };

  // Export full Android Studio project ZIP
  const handleExportProjectZip = async (proj: Project) => {
    try {
      const blob = await generateAndroidProjectZip(proj);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${proj.name.replace(/[^a-zA-Z0-9]/g, '_')}_AndroidStudio_Project.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert('Failed to generate project zip: ' + (err?.message || err));
    }
  };

  // Import Project ZIP
  const handleImportZip = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    JSZip.loadAsync(file).then(async (zip) => {
      let configJson = '';
      let indexHtml = '';
      const filesMap: { [name: string]: string } = {};

      for (const [path, entry] of Object.entries(zip.files)) {
        if (!entry.dir) {
          const content = await entry.async('string');
          filesMap[path] = content;
          if (path.endsWith('project-config.json')) {
            configJson = content;
          }
          if (path.toLowerCase().endsWith('index.html')) {
            indexHtml = content;
          }
        }
      }

      let newProj: Project;
      if (configJson) {
        try {
          newProj = JSON.parse(configJson);
          newProj.id = 'proj_' + Date.now();
        } catch {
          newProj = createDefaultFromZip(file.name, indexHtml || Object.values(filesMap)[0] || '', filesMap);
        }
      } else {
        newProj = createDefaultFromZip(file.name, indexHtml || Object.values(filesMap)[0] || '', filesMap);
      }

      handleUpdateProjects([newProj, ...projects]);
      alert(`Project "${newProj.name}" imported successfully!`);
    }).catch(() => {
      alert('Could not read ZIP file. Please ensure it is a valid project archive.');
    });
  };

  const createDefaultFromZip = (
    fileName: string,
    html: string,
    filesMap: { [k: string]: string }
  ): Project => {
    const cleanName = fileName.replace(/\.zip$/i, '').replace(/[^a-zA-Z0-9]/g, ' ').trim() || 'Imported App';
    const pkg = 'com.htmltoapk.' + cleanName.toLowerCase().replace(/[^a-z0-9]/g, '');

    return {
      id: 'proj_' + Date.now(),
      name: cleanName,
      packageName: pkg,
      versionCode: 1,
      versionName: '1.0',
      autoIncrementVersion: true,
      minSdk: 24,
      targetSdk: 36,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      sourceType: 'zip_file',
      htmlContent: html,
      files: filesMap,
      selectedFileName: fileName,
      orientation: 'portrait',
      showStatusBar: true,
      showActionBar: false,
      keepScreenOn: false,
      showCameraCutout: false,
      desktopMode: false,
      showWatermark: false,
      primaryColor: '#2196F3',
      loadingBgColor: '#000000',
      permissions: {
        internet: true,
        networkState: true,
        readExternalStorage: true,
        writeExternalStorage: true,
        readMediaImages: true,
        readMediaVideo: true,
        readMediaAudio: true,
        camera: true,
        microphone: true,
        fineLocation: true,
        coarseLocation: true,
        notifications: true,
        exactAlarms: false,
        activityRecognition: false,
        vibration: true,
        phoneState: false,
      },
      iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=192&auto=format&fit=crop&q=80',
      iconName: 'imported_icon.png',
      splash: {
        enabled: false,
        bgColor: '#0F1318',
        loaderStyle: 'circle',
        loaderColor: '#00E5CC',
        iconSize: 120,
        iconCorners: 16,
        loaderSize: 48,
        spacing: 28,
        displayDuration: 2,
        loaderThickness: 4,
        fadeDuration: 400,
      },
      webView: {
        javascriptEnabled: true,
        domStorageEnabled: true,
        allowFileAccess: true,
        allowContentAccess: true,
        universalFileAccess: true,
        fileAccessFromFileUrls: true,
        builtInZoomControls: false,
        useWideViewport: true,
        loadWithOverviewMode: true,
        geolocationEnabled: true,
        cacheMode: 'LOAD_DEFAULT',
        mixedContentMode: 'ALWAYS_ALLOW',
        pullToRefresh: false,
        noInternetDialog: false,
        loadingIndicator: false,
        backButtonNavigation: true,
        exitConfirmDialog: true,
        bypassGoogleOAuthUserAgent: true,
      },
      admob: {
        enabled: false,
        appId: '',
        bannerId: '',
        interstitialId: '',
        rewardedId: '',
      },
      outputFormat: 'apk',
      keystoreId: 'default_keystore',
    };
  };

  // Export All Projects ZIP
  const handleExportAllProjectsZip = async () => {
    if (projects.length === 0) return alert('No projects to export');
    const zip = new JSZip();
    projects.forEach((p) => {
      zip.file(`${p.name.replace(/[^a-zA-Z0-9]/g, '_')}/project-config.json`, JSON.stringify(p, null, 2));
      zip.file(`${p.name.replace(/[^a-zA-Z0-9]/g, '_')}/index.html`, p.htmlContent || '');
    });
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `All_HTML_to_APK_Projects_${new Date().toISOString().slice(0, 10)}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Export All as Android Projects ZIP
  const handleExportAllAndroidZip = async () => {
    if (projects.length === 0) return alert('No projects to export');
    const rootZip = new JSZip();
    for (const p of projects) {
      const projectBlob = await generateAndroidProjectZip(p);
      rootZip.file(`${p.name.replace(/[^a-zA-Z0-9]/g, '_')}_AndroidProject.zip`, projectBlob);
    }
    const blob = await rootZip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `All_AndroidStudio_Projects_${new Date().toISOString().slice(0, 10)}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Select template to build
  const handleSelectTemplate = (tmpl: TemplateItem) => {
    const pkg = 'com.htmltoapk.' + tmpl.id.replace(/-/g, '');
    const newProj: Project = {
      id: 'proj_' + Date.now(),
      name: tmpl.title,
      packageName: pkg,
      versionCode: 1,
      versionName: '1.0',
      autoIncrementVersion: true,
      minSdk: 24,
      targetSdk: 36,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      sourceType: 'template',
      htmlContent: tmpl.htmlContent,
      files: {},
      selectedFileName: tmpl.title + '.html',
      orientation: 'portrait',
      showStatusBar: true,
      showActionBar: false,
      keepScreenOn: false,
      showCameraCutout: false,
      desktopMode: false,
      showWatermark: false,
      primaryColor: '#2196F3',
      loadingBgColor: '#000000',
      permissions: {
        internet: true,
        networkState: true,
        readExternalStorage: true,
        writeExternalStorage: true,
        readMediaImages: true,
        readMediaVideo: true,
        readMediaAudio: true,
        camera: tmpl.recommendedPermissions.includes('camera'),
        microphone: tmpl.recommendedPermissions.includes('microphone'),
        fineLocation: tmpl.recommendedPermissions.includes('fineLocation'),
        coarseLocation: tmpl.recommendedPermissions.includes('coarseLocation'),
        notifications: true,
        exactAlarms: false,
        activityRecognition: false,
        vibration: tmpl.recommendedPermissions.includes('vibration'),
        phoneState: false,
      },
      iconUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=192&auto=format&fit=crop&q=80',
      iconName: tmpl.title + '_icon.png',
      splash: {
        enabled: false,
        bgColor: '#0F1318',
        loaderStyle: 'circle',
        loaderColor: '#00E5CC',
        iconSize: 120,
        iconCorners: 16,
        loaderSize: 48,
        spacing: 28,
        displayDuration: 2,
        loaderThickness: 4,
        fadeDuration: 400,
      },
      webView: {
        javascriptEnabled: true,
        domStorageEnabled: true,
        allowFileAccess: true,
        allowContentAccess: true,
        universalFileAccess: true,
        fileAccessFromFileUrls: true,
        builtInZoomControls: false,
        useWideViewport: true,
        loadWithOverviewMode: true,
        geolocationEnabled: true,
        cacheMode: 'LOAD_DEFAULT',
        mixedContentMode: 'ALWAYS_ALLOW',
        pullToRefresh: false,
        noInternetDialog: false,
        loadingIndicator: false,
        backButtonNavigation: true,
        exitConfirmDialog: true,
        bypassGoogleOAuthUserAgent: true,
      },
      admob: {
        enabled: false,
        appId: '',
        bannerId: '',
        interstitialId: '',
        rewardedId: '',
      },
      outputFormat: 'apk',
      keystoreId: 'default_keystore',
    };
    setEditingProject(newProj);
    setIsCreating(true);
  };

  // Preview template
  const handlePreviewTemplate = (tmpl: TemplateItem) => {
    const tempProj: Project = {
      id: 'preview_' + tmpl.id,
      name: tmpl.title,
      packageName: 'com.preview.' + tmpl.id,
      versionCode: 1,
      versionName: '1.0',
      autoIncrementVersion: false,
      minSdk: 24,
      targetSdk: 36,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      sourceType: 'template',
      htmlContent: tmpl.htmlContent,
      files: {},
      orientation: 'portrait',
      showStatusBar: true,
      showActionBar: false,
      keepScreenOn: false,
      showCameraCutout: false,
      desktopMode: false,
      showWatermark: false,
      primaryColor: '#2196F3',
      loadingBgColor: '#000000',
      permissions: {
        internet: true,
        networkState: true,
        readExternalStorage: true,
        writeExternalStorage: true,
        readMediaImages: true,
        readMediaVideo: true,
        readMediaAudio: true,
        camera: true,
        microphone: true,
        fineLocation: true,
        coarseLocation: true,
        notifications: true,
        exactAlarms: false,
        activityRecognition: false,
        vibration: true,
        phoneState: false,
      },
      iconUrl: '',
      iconName: '',
      splash: {
        enabled: false,
        bgColor: '#000',
        loaderStyle: 'none',
        loaderColor: '#fff',
        iconSize: 100,
        iconCorners: 10,
        loaderSize: 40,
        spacing: 20,
        displayDuration: 2,
        loaderThickness: 4,
        fadeDuration: 300,
      },
      webView: {
        javascriptEnabled: true,
        domStorageEnabled: true,
        allowFileAccess: true,
        allowContentAccess: true,
        universalFileAccess: true,
        fileAccessFromFileUrls: true,
        builtInZoomControls: false,
        useWideViewport: true,
        loadWithOverviewMode: true,
        geolocationEnabled: true,
        cacheMode: 'LOAD_DEFAULT',
        mixedContentMode: 'ALWAYS_ALLOW',
        pullToRefresh: false,
        noInternetDialog: false,
        loadingIndicator: false,
        backButtonNavigation: true,
        exitConfirmDialog: false,
        bypassGoogleOAuthUserAgent: true,
      },
      admob: {
        enabled: false,
        appId: '',
        bannerId: '',
        interstitialId: '',
        rewardedId: '',
      },
      outputFormat: 'apk',
      keystoreId: 'default_keystore',
    };
    setSimulatorProject(tempProj);
    setSimulatorOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans select-none antialiased">
      {/* Hidden file input for Project ZIP import */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".zip"
        onChange={handleImportZip}
        className="hidden"
      />

      {isCreating ? (
        <NewProjectWizard
          initialProject={editingProject}
          keystores={keystores}
          onCancel={() => setIsCreating(false)}
          onSaveAndBuild={handleSaveAndBuild}
          onOpenCodeEditor={(code, onSave) => {
            setCodeToEdit(code);
            setOnSaveCodeCallback(() => onSave);
            setCodeEditorOpen(true);
          }}
          onManageKeystore={() => setKeystoreModalOpen(true)}
        />
      ) : (
        <div className="min-h-screen flex flex-col justify-between">
          <TopHeader
            currentTab={currentTab}
            isCreating={false}
            onImportZip={() => fileInputRef.current?.click()}
            onExportAllProjectsZip={handleExportAllProjectsZip}
            onExportAllAndroidZip={handleExportAllAndroidZip}
            onExportSingleIndexFile={() => setSingleFileModalOpen(true)}
            onHelp={() => setGuideModalOpen(true)}
          />

          <main className="flex-1">
            {currentTab === 'projects' && (
              <ProjectsTab
                projects={projects}
                onCreateProject={handleStartCreate}
                onEditProject={handleEditProject}
                onDeleteProject={handleDeleteProject}
                onBuildProject={triggerBuildApk}
                onTestProject={(p) => {
                  setSimulatorProject(p);
                  setSimulatorOpen(true);
                }}
                onExportProjectZip={handleExportProjectZip}
                onExportSingleIndex={() => setSingleFileModalOpen(true)}
              />
            )}

            {currentTab === 'templates' && (
              <TemplatesTab
                onSelectTemplate={handleSelectTemplate}
                onPreviewTemplate={handlePreviewTemplate}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsTab
                onOpenKeystore={() => setKeystoreModalOpen(true)}
                onOpenPro={() => setProModalOpen(true)}
                onOpenGuide={() => setGuideModalOpen(true)}
                onExportSingleIndex={() => setSingleFileModalOpen(true)}
              />
            )}
          </main>

          <BottomNav currentTab={currentTab} onSelectTab={setCurrentTab} />
        </div>
      )}

      {/* Simulator Modal */}
      {simulatorProject && (
        <LiveSimulatorModal
          isOpen={simulatorOpen}
          onClose={() => setSimulatorOpen(false)}
          project={simulatorProject}
        />
      )}

      {/* Build Progress & Console Output Modal */}
      {activeBuildProject && (
        <BuildProgressModal
          isOpen={buildModalOpen}
          onClose={() => setBuildModalOpen(false)}
          progress={buildProgress}
          stepText={buildStepText}
          logs={buildLogs}
          isComplete={isBuildComplete}
          project={activeBuildProject}
          apkBlob={builtApkBlob}
          onDownloadProjectZip={() => handleExportProjectZip(activeBuildProject)}
          onOpenSimulator={() => {
            setSimulatorProject(activeBuildProject);
            setSimulatorOpen(true);
          }}
        />
      )}

      {/* Keystore Manager Modal */}
      <KeystoreManagerModal
        isOpen={keystoreModalOpen}
        onClose={() => setKeystoreModalOpen(false)}
        keystores={keystores}
        onSaveKeystore={handleSaveKeystore}
        onDeleteKeystore={handleDeleteKeystore}
      />

      {/* Pro Features Unlocked Modal */}
      <ProFeaturesModal
        isOpen={proModalOpen}
        onClose={() => setProModalOpen(false)}
      />

      {/* User Guide Documentation Modal */}
      <UserGuideModal
        isOpen={guideModalOpen}
        onClose={() => setGuideModalOpen(false)}
      />

      {/* Code Editor Modal */}
      <CodeEditorModal
        isOpen={codeEditorOpen}
        onClose={() => setCodeEditorOpen(false)}
        initialCode={codeToEdit}
        onSave={(newCode) => {
          if (onSaveCodeCallback) onSaveCodeCallback(newCode);
        }}
      />

      {/* Standalone Single File Modal */}
      <SingleFileExportModal
        isOpen={singleFileModalOpen}
        onClose={() => setSingleFileModalOpen(false)}
      />
    </div>
  );
}
