export interface Project {
  id: string;
  name: string;
  packageName: string;
  versionCode: number;
  versionName: string;
  autoIncrementVersion: boolean;
  minSdk: number;
  targetSdk: number;
  maxSdk?: number;
  customUrlScheme?: string;
  createdAt: number;
  updatedAt: number;

  // Content
  sourceType: 'html_file' | 'zip_file' | 'web_url' | 'paste_html' | 'template';
  htmlContent: string;
  files: { [filename: string]: string }; // filename -> content/dataUrl
  webUrl?: string;
  selectedFileName?: string;

  // Display
  orientation: 'portrait' | 'landscape' | 'auto';
  showStatusBar: boolean;
  showActionBar: boolean;
  keepScreenOn: boolean;
  showCameraCutout: boolean;
  desktopMode: boolean;
  showWatermark: boolean;
  primaryColor: string;
  loadingBgColor: string;

  // Permissions (Requested by user: video, photo, read, location, etc. 100% enabled)
  permissions: {
    internet: boolean;
    networkState: boolean;
    readExternalStorage: boolean;
    writeExternalStorage: boolean;
    readMediaImages: boolean;
    readMediaVideo: boolean;
    readMediaAudio: boolean;
    camera: boolean;
    microphone: boolean;
    fineLocation: boolean;
    coarseLocation: boolean;
    notifications: boolean;
    exactAlarms: boolean;
    activityRecognition: boolean;
    vibration: boolean;
    phoneState: boolean;
  };

  // Icon
  iconUrl: string;
  iconName: string;

  // Splash Screen
  splash: {
    enabled: boolean;
    bgColor: string;
    loaderStyle: 'circle' | 'bar' | 'pulse' | 'none';
    loaderColor: string;
    iconSize: number;
    iconCorners: number;
    loaderSize: number;
    spacing: number;
    displayDuration: number;
    loaderThickness: number;
    fadeDuration: number;
  };

  // WebView Settings (Crucial for Google login, JS, storage, offline)
  webView: {
    javascriptEnabled: boolean;
    domStorageEnabled: boolean;
    allowFileAccess: boolean;
    allowContentAccess: boolean;
    universalFileAccess: boolean;
    fileAccessFromFileUrls: boolean;
    builtInZoomControls: boolean;
    useWideViewport: boolean;
    loadWithOverviewMode: boolean;
    geolocationEnabled: boolean;
    cacheMode: 'LOAD_DEFAULT' | 'LOAD_CACHE_ELSE_NETWORK' | 'LOAD_NO_CACHE' | 'LOAD_CACHE_ONLY';
    mixedContentMode: 'ALWAYS_ALLOW' | 'COMPATIBILITY_MODE' | 'NEVER_ALLOW';
    pullToRefresh: boolean;
    noInternetDialog: boolean;
    loadingIndicator: boolean;
    backButtonNavigation: boolean;
    exitConfirmDialog: boolean;
    bypassGoogleOAuthUserAgent: boolean; // Overrides user-agent so Google Sign-In works in WebView
  };

  // Ads
  admob: {
    enabled: boolean;
    appId: string;
    bannerId: string;
    interstitialId: string;
    rewardedId: string;
  };

  // Build Output
  outputFormat: 'apk' | 'aab';
  keystoreId: string;
  lastBuiltAt?: number;
}

export interface Keystore {
  id: string;
  name: string;
  alias: string;
  algorithm?: string;
  validityYears: number;
  createdAt: number;
  projectLink?: string;
  savedPath?: string;
  sha1: string;
  sha256: string;
  isDefault?: boolean;
}

export interface TemplateItem {
  id: string;
  title: string;
  category: 'interaction' | 'starters' | 'libraries' | 'ads' | 'device' | 'auth' | 'sensors' | 'system' | 'dashboard';
  description: string;
  icon: string;
  badge?: string;
  htmlContent: string;
  recommendedPermissions: string[];
}
