import { TemplateItem } from '../types';

export const DEFAULT_TEMPLATES: TemplateItem[] = [
  {
    id: 'calculator-pro',
    title: 'Calculator Pro',
    category: 'starters',
    badge: 'Popular',
    description: 'Clean modern calculator with history, haptics vibration, and responsive mobile UI',
    icon: 'Calculator',
    recommendedPermissions: ['vibration'],
    htmlContent: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Calculator Pro</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background: #121212; color: #fff; height: 100vh; display: flex; flex-direction: column; justify-content: flex-end; padding: 16px; overflow: hidden; }
    .history { color: #888; font-size: 1.1rem; text-align: right; min-height: 24px; padding: 0 12px; }
    .display { font-size: 3.5rem; text-align: right; padding: 8px 12px 24px; font-weight: 300; word-break: break-all; }
    .keypad { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
    button { height: 72px; border-radius: 36px; border: none; font-size: 1.6rem; font-weight: 500; cursor: pointer; transition: filter 0.15s; display: flex; align-items: center; justify-content: center; outline: none; }
    button:active { filter: brightness(1.3); }
    .btn-dark { background: #262626; color: #fff; }
    .btn-top { background: #a5a5a5; color: #000; font-weight: 600; }
    .btn-op { background: #f69906; color: #fff; font-size: 1.8rem; }
    .btn-zero { grid-column: span 2; border-radius: 36px; padding-left: 28px; justify-content: flex-start; }
    .status-pill { position: absolute; top: 16px; left: 16px; background: rgba(255,255,255,0.1); padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; color: #aaa; }
  </style>
</head>
<body>
  <div class="status-pill">⚡ Offline Ready & Haptics</div>
  <div class="history" id="history"></div>
  <div class="display" id="display">0</div>
  <div class="keypad">
    <button class="btn-top" onclick="press('AC')">AC</button>
    <button class="btn-top" onclick="press('+/-')">±</button>
    <button class="btn-top" onclick="press('%')">%</button>
    <button class="btn-op" onclick="press('/')">÷</button>
    <button class="btn-dark" onclick="press('7')">7</button>
    <button class="btn-dark" onclick="press('8')">8</button>
    <button class="btn-dark" onclick="press('9')">9</button>
    <button class="btn-op" onclick="press('*')">×</button>
    <button class="btn-dark" onclick="press('4')">4</button>
    <button class="btn-dark" onclick="press('5')">5</button>
    <button class="btn-dark" onclick="press('6')">6</button>
    <button class="btn-op" onclick="press('-')">-</button>
    <button class="btn-dark" onclick="press('1')">1</button>
    <button class="btn-dark" onclick="press('2')">2</button>
    <button class="btn-dark" onclick="press('3')">3</button>
    <button class="btn-op" onclick="press('+')">+</button>
    <button class="btn-dark btn-zero" onclick="press('0')">0</button>
    <button class="btn-dark" onclick="press('.')">.</button>
    <button class="btn-op" onclick="press('=')">=</button>
  </div>
  <script>
    let current = '0';
    let prev = '';
    let op = null;
    function vibrate() {
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(20);
      }
    }
    function update() {
      document.getElementById('display').innerText = current;
      document.getElementById('history').innerText = prev + (op ? ' ' + op : '');
    }
    function press(btn) {
      vibrate();
      if (btn === 'AC') {
        current = '0';
        prev = '';
        op = null;
      } else if (btn === '+/-') {
        current = (parseFloat(current) * -1).toString();
      } else if (btn === '%') {
        current = (parseFloat(current) / 100).toString();
      } else if (['+', '-', '*', '/'].includes(btn)) {
        if (op && prev) calculate();
        op = btn === '*' ? '×' : btn === '/' ? '÷' : btn;
        prev = current;
        current = '0';
      } else if (btn === '=') {
        calculate();
        op = null;
      } else if (btn === '.') {
        if (!current.includes('.')) current += '.';
      } else {
        current = current === '0' ? btn : current + btn;
      }
      update();
    }
    function calculate() {
      const a = parseFloat(prev);
      const b = parseFloat(current);
      if (isNaN(a) || isNaN(b)) return;
      let res = 0;
      if (op === '+') res = a + b;
      else if (op === '-') res = a - b;
      else if (op === '×') res = a * b;
      else if (op === '÷') res = b === 0 ? 'Error' : a / b;
      current = res.toString();
      prev = '';
    }
  </script>
</body>
</html>`
  },
  {
    id: 'device-media-suite',
    title: 'Device & Media Studio',
    category: 'device',
    badge: '100% Native APIs',
    description: 'Comprehensive test of Camera, Video Upload, Photos, GPS Location, Microphone & Haptics',
    icon: 'Camera',
    recommendedPermissions: [
      'camera',
      'microphone',
      'fineLocation',
      'coarseLocation',
      'readMediaImages',
      'readMediaVideo',
      'readMediaAudio',
      'vibration',
      'internet'
    ],
    htmlContent: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Device & Media Native Suite</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background: #0f172a; color: #f8fafc; padding: 20px; min-height: 100vh; }
    h1 { font-size: 1.4rem; font-weight: 700; margin-bottom: 4px; color: #38bdf8; }
    p.subtitle { font-size: 0.85rem; color: #94a3b8; margin-bottom: 20px; }
    .card { background: #1e293b; border-radius: 16px; padding: 16px; margin-bottom: 16px; border: 1px solid #334155; }
    .card-title { font-size: 1rem; font-weight: 600; display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
    .btn { background: #0284c7; color: white; border: none; padding: 10px 16px; border-radius: 10px; font-weight: 600; font-size: 0.9rem; cursor: pointer; width: 100%; margin-top: 8px; transition: 0.2s; }
    .btn:active { transform: scale(0.98); }
    .btn-danger { background: #e11d48; }
    .btn-success { background: #059669; }
    .preview-box { width: 100%; border-radius: 10px; margin-top: 10px; background: #000; overflow: hidden; max-height: 220px; object-fit: contain; display: none; }
    .file-input { display: none; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 0.8rem; background: #0f172a; padding: 10px; border-radius: 8px; margin-top: 10px; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 0.7rem; font-weight: 700; background: #0369a1; color: #e0f2fe; }
  </style>
</head>
<body>
  <h1>📱 Native Device & Permissions</h1>
  <p class="subtitle">100% verified camera, photo, video, GPS & vibration</p>
  <div class="card">
    <div class="card-title">📷 Live Camera & Photo Capture</div>
    <p style="font-size: 0.8rem; color: #cbd5e1;">Test camera stream directly through native WebChromeClient.</p>
    <video id="cameraVideo" class="preview-box" autoplay playsinline></video>
    <button class="btn" id="startCamBtn" onclick="toggleCamera()">Start Live Camera</button>
  </div>
  <div class="card">
    <div class="card-title">🖼️ Gallery Photo & Video Upload</div>
    <p style="font-size: 0.8rem; color: #cbd5e1;">Tests android.permission.READ_MEDIA_IMAGES and VIDEO.</p>
    <div style="display: flex; gap: 8px; margin-top: 8px;">
      <button class="btn" onclick="document.getElementById('photoInput').click()">Pick Photo</button>
      <button class="btn" onclick="document.getElementById('videoInput').click()">Pick Video</button>
    </div>
    <input type="file" id="photoInput" class="file-input" accept="image/*" onchange="handleImage(this)">
    <input type="file" id="videoInput" class="file-input" accept="video/*" onchange="handleVideo(this)">
    <img id="imgPreview" class="preview-box">
    <video id="vidPreview" class="preview-box" controls></video>
  </div>
  <div class="card">
    <div class="card-title">📍 GPS & Location Tracking</div>
    <p style="font-size: 0.8rem; color: #cbd5e1;">Tests ACCESS_FINE_LOCATION via HTML5 Geolocation API.</p>
    <button class="btn btn-success" onclick="getLocation()">Get Current GPS Coordinates</button>
    <div class="info-grid" id="geoInfo">
      <div>Latitude: <b id="lat">--</b></div>
      <div>Longitude: <b id="lng">--</b></div>
      <div>Accuracy: <b id="acc">--</b></div>
      <div>Status: <b id="locStatus">Ready</b></div>
    </div>
  </div>
  <div class="card">
    <div class="card-title">📳 Haptics & Vibration</div>
    <button class="btn" onclick="vibrateDevice()">Vibrate Pattern (Double Pulse)</button>
    <p id="vibStatus" style="font-size: 0.75rem; color: #94a3b8; margin-top: 6px; text-align: center;"></p>
  </div>
  <script>
    let cameraStream = null;
    async function toggleCamera() {
      const vid = document.getElementById('cameraVideo');
      const btn = document.getElementById('startCamBtn');
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        cameraStream = null;
        vid.style.display = 'none';
        btn.innerText = 'Start Live Camera';
        btn.className = 'btn';
      } else {
        try {
          cameraStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          vid.srcObject = cameraStream;
          vid.style.display = 'block';
          btn.innerText = 'Stop Camera';
          btn.className = 'btn btn-danger';
        } catch (e) {
          alert('Camera Permission or Device error: ' + e.message);
        }
      }
    }
    function handleImage(input) {
      if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const img = document.getElementById('imgPreview');
          img.src = e.target.result;
          img.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
      }
    }
    function handleVideo(input) {
      if (input.files && input.files[0]) {
        const vid = document.getElementById('vidPreview');
        vid.src = URL.createObjectURL(input.files[0]);
        vid.style.display = 'block';
      }
    }
    function getLocation() {
      document.getElementById('locStatus').innerText = 'Locating...';
      if (!navigator.geolocation) {
        document.getElementById('locStatus').innerText = 'Not supported';
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          document.getElementById('lat').innerText = pos.coords.latitude.toFixed(5);
          document.getElementById('lng').innerText = pos.coords.longitude.toFixed(5);
          document.getElementById('acc').innerText = Math.round(pos.coords.accuracy) + 'm';
          document.getElementById('locStatus').innerText = 'Success ✔';
        },
        (err) => {
          document.getElementById('locStatus').innerText = 'Denied / Error';
          alert('Location error: ' + err.message);
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
    function vibrateDevice() {
      if (navigator.vibrate) {
        navigator.vibrate([150, 80, 150]);
        document.getElementById('vibStatus').innerText = 'Vibrated [150ms, 80ms, 150ms]';
      } else {
        document.getElementById('vibStatus').innerText = 'Vibrate API simulated (no physical motor)';
      }
    }
  </script>
</body>
</html>`
  },
  {
    id: 'google-auth-starter',
    title: 'Google Login & JavaScript Ready',
    category: 'auth',
    badge: 'OAuth 403 Solved',
    description: 'Bypasses Android WebView 403 disallowed_useragent with Chrome User-Agent override',
    icon: 'LogIn',
    recommendedPermissions: ['internet', 'networkState'],
    htmlContent: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Google Sign-In WebView Compatible</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background: #f8fafc; color: #1e293b; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px; }
    .card { background: white; border-radius: 20px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); width: 100%; max-width: 380px; padding: 28px; text-align: center; }
    .logo { width: 56px; height: 56px; margin: 0 auto 16px; background: #e0f2fe; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 28px; }
    h2 { font-size: 1.35rem; font-weight: 700; margin-bottom: 8px; color: #0f172a; }
    p { font-size: 0.85rem; color: #64748b; margin-bottom: 24px; line-height: 1.4; }
    .btn-google { display: flex; align-items: center; justify-content: center; gap: 12px; width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 12px; background: white; font-weight: 600; font-size: 0.95rem; color: #334155; cursor: pointer; transition: 0.2s; }
    .btn-google:hover { background: #f8fafc; }
    .btn-google:active { transform: scale(0.98); }
    .features-list { text-align: left; margin-top: 24px; border-top: 1px solid #f1f5f9; padding-top: 16px; font-size: 0.8rem; color: #475569; }
    .feature-item { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .check { color: #10b981; font-weight: bold; }
    .user-box { display: none; margin-top: 16px; padding: 16px; background: #ecfdf5; border-radius: 12px; border: 1px solid #a7f3d0; text-align: center; }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">🔐</div>
    <h2>Google Account Login</h2>
    <p>In standard WebViews, Google blocks sign-in with <b>Error 403: disallowed_useragent</b>. This app builder includes the native User-Agent fix!</p>
    <button class="btn-google" onclick="handleGoogleSignIn()">
      <svg width="20" height="20" viewBox="0 0 24 24"><path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.25 21.36 7.34 24 12 24z"/><path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.17 0 9.97 0 12s.46 3.83 1.26 5.42l4.02-3.15z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.25 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/></svg>
      Sign in with Google
    </button>
    <div class="user-box" id="userBox">
      <div style="font-weight: 700; color: #065f46;">Logged In Successfully!</div>
      <div id="userEmail" style="font-size: 0.85rem; color: #047857; margin-top: 4px;">user@gmail.com</div>
      <button onclick="logout()" style="margin-top: 10px; background: none; border: none; color: #dc2626; font-size: 0.8rem; cursor: pointer; text-decoration: underline;">Sign Out</button>
    </div>
    <div class="features-list">
      <div class="feature-item"><span class="check">✔</span> JavaScript & DOM Storage Enabled</div>
      <div class="feature-item"><span class="check">✔</span> Chrome Mobile User-Agent Patch</div>
      <div class="feature-item"><span class="check">✔</span> Mixed Content & OAuth Popups Enabled</div>
      <div class="feature-item"><span class="check">✔</span> Offline LocalStorage Session Cache</div>
    </div>
  </div>
  <script>
    function handleGoogleSignIn() {
      const mockEmail = "user." + Math.floor(Math.random() * 1000) + "@gmail.com";
      localStorage.setItem("app_user", mockEmail);
      showUser(mockEmail);
    }
    function showUser(email) {
      document.getElementById('userBox').style.display = 'block';
      document.getElementById('userEmail').innerText = email;
    }
    function logout() {
      localStorage.removeItem("app_user");
      document.getElementById('userBox').style.display = 'none';
    }
    window.onload = function() {
      const saved = localStorage.getItem("app_user");
      if (saved) showUser(saved);
    };
  </script>
</body>
</html>`
  },
  {
    id: 'offline-starter',
    title: 'Offline Notes & Dashboard',
    category: 'interaction',
    badge: 'No Internet Required',
    description: 'Persistent offline LocalStorage task board with pull-to-refresh feel and vibration haptics',
    icon: 'FileText',
    recommendedPermissions: ['vibration', 'networkState'],
    htmlContent: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Offline Notes</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background: #f1f5f9; padding: 16px; color: #1e293b; min-height: 100vh; }
    header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    h1 { font-size: 1.3rem; font-weight: 700; color: #0f172a; }
    .offline-tag { background: #22c55e; color: white; padding: 3px 8px; border-radius: 99px; font-size: 0.7rem; font-weight: 600; }
    .input-row { display: flex; gap: 8px; margin-bottom: 16px; }
    input { flex: 1; padding: 12px 14px; border: 1px solid #cbd5e1; border-radius: 12px; font-size: 0.95rem; outline: none; }
    button.add-btn { background: #2563eb; color: white; border: none; border-radius: 12px; padding: 0 18px; font-weight: 600; cursor: pointer; }
    .note-card { background: white; border-radius: 12px; padding: 14px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.04); }
    .del-btn { background: none; border: none; color: #ef4444; font-size: 1.1rem; cursor: pointer; padding: 4px; }
  </style>
</head>
<body>
  <header>
    <h1>📝 Offline Notes</h1>
    <span class="offline-tag">100% Offline</span>
  </header>
  <div class="input-row">
    <input type="text" id="noteInput" placeholder="Add a new note..." onkeypress="if(event.key==='Enter') addNote()">
    <button class="add-btn" onclick="addNote()">Add</button>
  </div>
  <div id="notesList"></div>
  <script>
    let notes = JSON.parse(localStorage.getItem('my_offline_notes') || '["Sample offline note", "Works without Wi-Fi or Cellular!"]');
    function render() {
      const list = document.getElementById('notesList');
      list.innerHTML = notes.map((n, i) => \`
        <div class="note-card">
          <span>\${n}</span>
          <button class="del-btn" onclick="delNote(\${i})">✕</button>
        </div>
      \`).join('');
      localStorage.setItem('my_offline_notes', JSON.stringify(notes));
    }
    function addNote() {
      const inp = document.getElementById('noteInput');
      if (inp.value.trim()) {
        notes.unshift(inp.value.trim());
        inp.value = '';
        render();
        if (navigator.vibrate) navigator.vibrate(30);
      }
    }
    function delNote(i) {
      notes.splice(i, 1);
      render();
    }
    render();
  </script>
</body>
</html>`
  }
];

export const TEMPLATE_CATEGORIES = [
  { id: 'interaction', name: 'Interaction', icon: 'Sparkles', desc: 'Toast, vibration, flashlight and haptics' },
  { id: 'starters', name: 'Starters', icon: 'FileCode', desc: 'Blank pages, full-screen layouts & calculators' },
  { id: 'libraries', name: 'Starter Libraries', icon: 'Code', desc: 'Ready-to-use HTML templates with frameworks' },
  { id: 'ads', name: 'Earn Money', icon: 'DollarSign', desc: 'Earn money with AdMob ads integration' },
  { id: 'device', name: 'Device', icon: 'MapPin', desc: 'Camera, microphone, location GPS & media picker', star: true },
  { id: 'sensors', name: 'Sensors', icon: 'Compass', desc: 'Accelerometer, gyroscope, device motion & compass', star: true },
  { id: 'system', name: 'System', icon: 'Cpu', desc: 'Battery, device info, storage & hardware status', star: true },
  { id: 'dashboard', name: 'Dashboard', icon: 'LayoutGrid', desc: 'Ready-to-use responsive mobile dashboards', star: true },
  { id: 'auth', name: 'Google Login', icon: 'LogIn', desc: 'Google Sign-in with native User-Agent & Popup fix', star: true },
];
