import { Project, Keystore } from '../types';
import { DEFAULT_TEMPLATES } from '../data/defaultTemplates';

const PROJECTS_KEY = 'html_to_apk_projects';
const KEYSTORES_KEY = 'html_to_apk_keystores';

export function getInitialProjects(): Project[] {
  try {
    const raw = localStorage.getItem(PROJECTS_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Failed to load projects from storage', e);
  }

  // Pre-seed with Calculator Pro project matching video only on first ever visit!
  const calcTemplate = DEFAULT_TEMPLATES[0];
  const initialProject: Project = {
    id: 'proj_calc_pro',
    name: 'Calculator Pro',
    packageName: 'com.htmltoapk.calculatorpro',
    versionCode: 1,
    versionName: '1.0',
    autoIncrementVersion: true,
    minSdk: 24,
    targetSdk: 36,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    sourceType: 'template',
    htmlContent: calcTemplate.htmlContent,
    files: {},
    selectedFileName: 'index.html',
    orientation: 'portrait',
    showStatusBar: true,
    showActionBar: false,
    keepScreenOn: false,
    showCameraCutout: false,
    desktopMode: false,
    showWatermark: false, // 100% Free unlocked!
    primaryColor: '#2196F3',
    loadingBgColor: '#000000',
    permissions: {
      internet: true,
      networkState: true,
      readExternalStorage: true,
      writeExternalStorage: true,
      readMediaImages: true,
      readMediaVideo: true,
      readMediaAudio: true,
      camera: true,
      microphone: false,
      fineLocation: true,
      coarseLocation: true,
      notifications: true,
      exactAlarms: false,
      activityRecognition: false,
      vibration: true,
      phoneState: false,
    },
    iconUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=192&auto=format&fit=crop&q=80',
    iconName: 'calculator_icon.png',
    splash: {
      enabled: false,
      bgColor: '#0F1318',
      loaderStyle: 'circle',
      loaderColor: '#00E5CC',
      iconSize: 120,
      iconCorners: 16,
      loaderSize: 48,
      spacing: 28,
      displayDuration: 2,
      loaderThickness: 4,
      fadeDuration: 400,
    },
    webView: {
      javascriptEnabled: true,
      domStorageEnabled: true,
      allowFileAccess: true,
      allowContentAccess: true,
      universalFileAccess: true,
      fileAccessFromFileUrls: true,
      builtInZoomControls: false,
      useWideViewport: true,
      loadWithOverviewMode: true,
      geolocationEnabled: true,
      cacheMode: 'LOAD_DEFAULT',
      mixedContentMode: 'ALWAYS_ALLOW',
      pullToRefresh: false,
      noInternetDialog: false,
      loadingIndicator: false,
      backButtonNavigation: true,
      exitConfirmDialog: true,
      bypassGoogleOAuthUserAgent: true,
    },
    admob: {
      enabled: false,
      appId: '',
      bannerId: '',
      interstitialId: '',
      rewardedId: '',
    },
    outputFormat: 'apk',
    keystoreId: 'default_keystore',
  };

  saveProjects([initialProject]);
  return [initialProject];
}

export function saveProjects(projects: Project[]) {
  try {
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  } catch (e) {
    console.error('Failed to save projects to storage', e);
  }
}

export function getInitialKeystores(): Keystore[] {
  try {
    const raw = localStorage.getItem(KEYSTORES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Failed to load keystores', e);
  }

  const defaultKeystore: Keystore = {
    id: 'default_keystore',
    name: 'Default (auto-generated)',
    alias: 'key0',
    validityYears: 25,
    createdAt: Date.now(),
    sha1: '3B:9A:88:51:D4:E8:22:90:3A:C1:67:8B:10:44:98:C3:FF:12:4A:88',
    sha256: '92:B4:7C:1E:58:A2:3D:0F:7A:B9:4C:1E:83:2A:B5:E8:77:C3:19:62:30:15:4D:99:A8:1B:32:00:8F:E2:76:CD',
    isDefault: true,
  };

  saveKeystores([defaultKeystore]);
  return [defaultKeystore];
}

export function saveKeystores(keystores: Keystore[]) {
  try {
    localStorage.setItem(KEYSTORES_KEY, JSON.stringify(keystores));
  } catch (e) {
    console.error('Failed to save keystores', e);
  }
}
