/* JOSTECH — MANUEL 04 : CYBERSÉCURITÉ NIVEAU 1 */
registerLessonDetail(4, 1, "sec-1-1-1", {
  title: "Leçon 1 : Triade CIA, Menaces Courantes et Défense en Profondeur",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Maîtriser les trois piliers : Confidentialité, Intégrité et Disponibilité (Triade CIA).",
    "Analyser les vecteurs d'attaque courants : Phishing, Ransomware et Ingénierie sociale.",
    "Appliquer la règle de sauvegarde 3-2-1, l'authentification MFA et la défense en profondeur."
  ],
  prerequisites: ["Culture numérique et notions de réseaux."],
  sections: [
    {
      type: "definition",
      term: "La Triade CIA (Confidentiality, Integrity, Availability)",
      text: "Toute architecture de cybersécurité repose sur trois exigences complémentaires :\n• Confidentialité : garantir que seules les personnes autorisées accèdent aux données (via chiffrement et contrôle d'accès).\n• Intégrité : garantir que les informations n'ont été ni altérées, ni falsifiées en transit ou en base (via hachage et signatures).\n• Disponibilité : garantir que les systèmes, cours et serveurs restent accessibles au moment voulu (via redondance et protection anti-DDoS)."
    },
    {
      type: "theory",
      title: "1. Anatomie des attaques les plus fréquentes",
      text: "La majorité des piratages ne viennent pas d'une faille mathématique complexe, mais de l'exploitation des faiblesses humaines ou d'erreurs de configuration.\n\nDans le Phishing (hameçonnage), l'attaquant envoie un faux SMS ou e-mail urgent imitant une banque ou une université pour pousser la victime à saisir son mot de passe sur un domaine piège. Dans un Ransomware (rançongiciel), un malware s'introduit via une pièce jointe piégée, chiffre tous les disques du réseau et réclame une rançon. L'ingénierie sociale (Social Engineering) consiste à manipuler psychologiquement un employé (urgence, autorité, peur) pour lui extorquer un accès."
    },
    {
      type: "code",
      lang: "Analyse d'URL : Repérer un faux site (Phishing)",
      code: [
        "Site officiel   : https://connexion.jostech.edu/login",
        "Site piège n°1  : https://jostech.edu.verif-compte-secu.com/login",
        "  --> Le vrai domaine est toujours juste avant le premier '/' : verif-compte-secu.com !",
        "Site piège n°2  : https://j0stech.edu/login (Typosquatting : 0 remplace o)"
      ].join("\n")
    },
    {
      type: "table",
      title: "2. Défense en Profondeur et Règle 3-2-1",
      headers: ["Couche de défense", "Mesure concrète"],
      rows: [
        ["Authentification", "Mots de passe longs uniques (gestionnaire) + MFA (2e facteur)."],
        ["Poste & Réseau", "Mises à jour rapides (patchs), pare-feu, principe du moindre privilège."],
        ["Résilience (3-2-1)", "3 copies des données, sur 2 supports différents, dont 1 hors ligne/hors site."]
      ]
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter",
      text: "1) Croire que le cadenas HTTPS garantit qu'un site est honnête : un site de phishing peut très bien avoir un certificat HTTPS gratuit ! HTTPS prouve seulement que la connexion vers le pirate est chiffrée.\n2) Réutiliser le même mot de passe sur plusieurs sites : si un petit site est piraté, les hackers testent vos identifiants partout ailleurs (Credential Stuffing)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Diagnostic Triade CIA",
      question: "Associez chaque incident au pilier CIA principalement touché :\nA) Un pirate modifie la note d'un étudiant de 08/20 à 18/20.\nB) Des copies d'examens confidentiels sont publiées sur un forum.\nC) Une attaque DDoS rend la plateforme inaccessible pendant 4 heures.",
      solution: "A) Intégrité (donnée falsifiée).\nB) Confidentialité (divulgation non autorisée).\nC) Disponibilité (service bloqué)."
    },
    {
      title: "Exercice 2 — Règle de sauvegarde 3-2-1",
      question: "Une université sauvegarde ses données sur le même disque dur principal, dans un second dossier. Pourquoi cela ne protège-t-il PAS contre un Ransomware ?",
      solution: "Le ransomware chiffre tous les dossiers et lecteurs connectés. Sans copie isolée hors ligne (le '1' hors site/hors ligne du 3-2-1), la sauvegarde est chiffrée avec l'original !"
    }
  ],
  summary: "La cybersécurité protège Confidentialité, Intégrité et Disponibilité par une défense en profondeur : MFA, vigilance anti-phishing, moindre privilège et sauvegardes 3-2-1.",
  references: ["ANSSI — Guide d'hygiène informatique.", "NIST Cybersecurity Framework (CSF 2.0)."]
});