-- FitKlot private app data. Run after full-app-schema.sql if the table already exists.
create table if not exists public.user_app_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{"profile":{},"weights":[],"measurements":[],"foods":[],"water":[],"recovery":[],"sessions":[],"plan":[],"theme":"dark"}'::jsonb,
  updated_at timestamptz not null default now(),
  constraint user_app_data_payload_object check (jsonb_typeof(payload) = 'object')
);
alter table public.user_app_data enable row level security;
revoke all on public.user_app_data from anon;
grant select, insert, update, delete on public.user_app_data to authenticated;
drop policy if exists "Users access only their own fitness data" on public.user_app_data;
create policy "Users access only their own fitness data" on public.user_app_data for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
