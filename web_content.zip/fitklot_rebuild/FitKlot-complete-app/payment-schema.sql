-- FitKlot AI monthly membership payments (₹50 / 30 days)
-- Run in Supabase SQL Editor after full-app-schema.sql.
-- This schema is designed for server-verified Razorpay payments. Never expose the service-role key.

-- Remove the obsolete promo system and its public RPC signatures.
drop function if exists public.claim_free_week();
drop function if exists public.claim_free_week(text);
drop function if exists public.redeem_fitklot7();
drop function if exists public.redeem_fitklot7(text);
drop function if exists public.fitklot7_status();
drop table if exists public.fitklot_promo_redemptions cascade;


create table if not exists public.fitklot_memberships (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text not null default 'inactive' check (status in ('active','inactive','expired')),
  plan text not null default 'monthly' check (plan = 'monthly'),
  started_at timestamptz,
  expires_at timestamptz,
  last_payment_id text unique,
  updated_at timestamptz not null default now()
);

create table if not exists public.fitklot_payment_orders (
  order_id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount = 5000),
  currency text not null default 'INR' check (currency = 'INR'),
  status text not null default 'created' check (status in ('created','paid','failed')),
  payment_id text unique,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create index if not exists fitklot_payment_orders_user_idx on public.fitklot_payment_orders(user_id, created_at desc);
alter table public.fitklot_memberships enable row level security;
alter table public.fitklot_payment_orders enable row level security;
revoke all on public.fitklot_memberships from anon, authenticated;
revoke all on public.fitklot_payment_orders from anon, authenticated;
grant select on public.fitklot_memberships to authenticated;
grant select on public.fitklot_payment_orders to authenticated;
drop policy if exists "Users can view their own membership" on public.fitklot_memberships;
create policy "Users can view their own membership" on public.fitklot_memberships for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can view their own payment orders" on public.fitklot_payment_orders;
create policy "Users can view their own payment orders" on public.fitklot_payment_orders for select to authenticated using (auth.uid() = user_id);

-- Only the server (service_role) can execute this function after verifying Razorpay signature AND captured payment.
create or replace function public.fitklot_activate_monthly_membership(p_order_id text, p_payment_id text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  o public.fitklot_payment_orders%rowtype;
  old_expiry timestamptz;
  new_start timestamptz;
  new_expiry timestamptz;
begin
  select * into o from public.fitklot_payment_orders where order_id = p_order_id for update;
  if not found then
    return jsonb_build_object('ok', false, 'message', 'Payment order not found.');
  end if;
  if o.amount <> 5000 or o.currency <> 'INR' then
    return jsonb_build_object('ok', false, 'message', 'Payment amount or currency is invalid.');
  end if;
  if o.status = 'paid' then
    if o.payment_id = p_payment_id then
      select expires_at into new_expiry from public.fitklot_memberships where user_id = o.user_id;
      return jsonb_build_object('ok', true, 'already_processed', true, 'expires_at', new_expiry, 'user_id', o.user_id);
    end if;
    return jsonb_build_object('ok', false, 'message', 'This order has already been processed.');
  end if;
  if o.status <> 'created' then
    return jsonb_build_object('ok', false, 'message', 'This payment order is not payable.');
  end if;
  select expires_at into old_expiry from public.fitklot_memberships where user_id = o.user_id for update;
  new_start := greatest(coalesce(old_expiry, now()), now());
  new_expiry := new_start + interval '1 month';
  insert into public.fitklot_memberships(user_id,status,plan,started_at,expires_at,last_payment_id,updated_at)
  values(o.user_id,'active','monthly',new_start,new_expiry,p_payment_id,now())
  on conflict(user_id) do update set status='active', plan='monthly', started_at=new_start,
    expires_at=new_expiry, last_payment_id=p_payment_id, updated_at=now();
  update public.fitklot_payment_orders set status='paid', payment_id=p_payment_id, paid_at=now() where order_id=p_order_id;
  return jsonb_build_object('ok', true, 'already_processed', false, 'expires_at', new_expiry, 'user_id', o.user_id);
end;
$function$;

revoke all on function public.fitklot_activate_monthly_membership(text,text) from public, anon, authenticated;
grant execute on function public.fitklot_activate_monthly_membership(text,text) to service_role;
notify pgrst, 'reload schema';


-- UPI QR payment submissions are review-only; submitting a UTR never activates membership.
create table if not exists public.fitklot_upi_payment_submissions (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  transaction_id text not null unique,
  payment_date date not null,
  payment_time time not null,
  amount integer not null check (amount = 5000),
  currency text not null default 'INR' check (currency = 'INR'),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewer_note text
);
create index if not exists fitklot_upi_submissions_user_idx on public.fitklot_upi_payment_submissions(user_id, submitted_at desc);
alter table public.fitklot_upi_payment_submissions enable row level security;
revoke all on public.fitklot_upi_payment_submissions from anon, authenticated;
-- The Cloudflare Worker service role writes submissions; no client-side membership activation policy is granted.
