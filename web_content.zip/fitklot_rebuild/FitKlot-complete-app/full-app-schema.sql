-- FitKlot relational data model and private account policies.
-- Run this file first; then run payment-schema.sql to enable paid memberships.
-- All personal rows are scoped to auth.uid(). Keep service-role credentials server-side.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  date_of_birth date,
  age smallint check (age is null or age between 13 and 110),
  sex text check (sex is null or sex in ('female','male')),
  height_cm numeric(6,2) check (height_cm is null or height_cm between 80 and 250),
  current_weight_kg numeric(7,2) check (current_weight_kg is null or current_weight_kg between 25 and 400),
  target_weight_kg numeric(7,2) check (target_weight_kg is null or target_weight_kg between 25 and 400),
  goal text,
  experience text,
  preferred_split text,
  training_days smallint check (training_days is null or training_days between 1 and 7),
  workout_duration_min smallint check (workout_duration_min is null or workout_duration_min between 15 and 240),
  equipment text[] not null default '{}',
  dietary_preference text,
  focus_muscle_groups text not null default '',
  movement_limitations text not null default '',
  avoid_exercise_names text not null default '',
  activity_factor numeric(3,2) check (activity_factor is null or activity_factor between 1 and 2.5),
  sleep_hours numeric(3,1) check (sleep_hours is null or sleep_hours between 0 and 24),
  calorie_target_kcal integer check (calorie_target_kcal is null or calorie_target_kcal between 500 and 10000),
  protein_target_g numeric(6,1) check (protein_target_g is null or protein_target_g between 0 and 1000),
  unit_preference text not null default 'metric' check (unit_preference in ('metric','imperial')),
  avoid_text text not null default '',
  body_fat_pct numeric(4,1) check (body_fat_pct is null or body_fat_pct between 2 and 70),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles add column if not exists focus_muscle_groups text not null default '';
alter table public.profiles add column if not exists movement_limitations text not null default '';
alter table public.profiles add column if not exists avoid_exercise_names text not null default '';
alter table public.profiles add column if not exists preferred_split text;

create table if not exists public.user_app_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object'),
  updated_at timestamptz not null default now()
);

create table if not exists public.exercise_library (
  id text primary key,
  name text not null unique,
  primary_muscle text not null,
  secondary_muscles text[] not null default '{}',
  equipment text[] not null default '{}',
  difficulty text not null default 'Beginner',
  instructions text not null default '',
  form_cues text[] not null default '{}',
  common_mistakes text[] not null default '{}',
  alternatives text[] not null default '{}',
  source_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.food_reference (
  id text primary key,
  name text not null unique,
  serving_g numeric(7,2) not null default 100 check (serving_g > 0),
  calories_kcal numeric(8,2) not null check (calories_kcal >= 0),
  protein_g numeric(7,2) not null default 0 check (protein_g >= 0),
  carbohydrates_g numeric(7,2) not null default 0 check (carbohydrates_g >= 0),
  fat_g numeric(7,2) not null default 0 check (fat_g >= 0),
  fibre_g numeric(7,2) check (fibre_g is null or fibre_g >= 0),
  source_name text not null default 'User-entered estimate',
  source_url text,
  reviewed_at date,
  created_at timestamptz not null default now()
);

-- Curated exercise reference seed; no demonstration URLs are supplied unless verified.
insert into public.exercise_library(id,name,primary_muscle,secondary_muscles,equipment,difficulty,instructions,form_cues,common_mistakes,alternatives) values
('barbell-bench-press','Barbell bench press','Chest',array['Triceps','Shoulders'],array['Barbell','Bench'],'Intermediate','Compound press for chest, triceps and front delts. Keep shoulder blades stable and lower with control.',array['Use a controlled range','Keep wrists stacked'],array['Bouncing the bar','Forcing a painful shoulder range'],array['Dumbbell bench press','Push-up']),
('incline-dumbbell-press','Incline dumbbell press','Chest',array['Triceps','Shoulders'],array['Dumbbells','Bench'],'Beginner','Press dumbbells from a low incline; use a comfortable range.',array['Keep ribs steady','Lower with control'],array['Excessive arch','Dropping elbows too low'],array['Push-up','Barbell bench press']),
('push-up','Push-up','Chest',array['Triceps','Core'],array['Bodyweight'],'Beginner','Brace your body, keep a straight line, and lower with control.',array['Keep head and hips aligned','Use a controlled tempo'],array['Sagging hips','Rushing repetitions'],array['Incline push-up','Band chest press']),
('cable-fly','Cable fly','Chest',array['Shoulders'],array['Cable'],'Beginner','Use light resistance and bring arms together without shrugging.',array['Keep a soft elbow bend','Move smoothly'],array['Overstretching','Using momentum'],array['Dumbbell fly']),
('lat-pulldown','Lat pulldown','Back',array['Biceps','Shoulders'],array['Cable','Machine'],'Beginner','Pull elbows down toward your sides; avoid swinging.',array['Keep torso steady','Control the return'],array['Pulling behind the neck','Leaning far back'],array['Resistance band row','Inverted row']),
('seated-cable-row','Seated cable row','Back',array['Biceps','Shoulders'],array['Cable'],'Beginner','Keep torso steady and pull toward your lower ribs.',array['Keep shoulders relaxed','Pause briefly'],array['Rocking the torso','Shrugging'],array['Resistance band row','One-arm dumbbell row']),
('one-arm-dumbbell-row','One-arm dumbbell row','Back',array['Biceps'],array['Dumbbells'],'Beginner','Support your body and pull elbow toward your hip.',array['Keep torso supported','Lower with control'],array['Twisting to lift','Jerking the weight'],array['Seated cable row','Inverted row']),
('barbell-deadlift','Barbell deadlift','Back',array['Glutes','Hamstrings','Legs'],array['Barbell'],'Advanced','Learn hip hinge technique first; keep load close and spine controlled.',array['Brace before lifting','Keep load close'],array['Jerking the load','Continuing when position changes'],array['Romanian deadlift','Dumbbell deadlift']),
('overhead-press','Overhead press','Shoulders',array['Triceps','Core'],array['Barbell'],'Intermediate','Brace your trunk and press overhead without leaning back.',array['Keep ribs stacked','Use a pain-free range'],array['Leaning back','Shrugging through reps'],array['Band overhead press','Dumbbell press']),
('lateral-raise','Lateral raise','Shoulders',array[],array['Dumbbells'],'Beginner','Use a light load and raise arms smoothly to a comfortable height.',array['Lead with elbows','Control lowering'],array['Swinging the torso','Lifting through pain'],array['Band lateral raise']),
('face-pull','Face pull','Shoulders',array['Back'],array['Cable'],'Beginner','Pull rope toward face with controlled external rotation.',array['Keep neck relaxed','Use light resistance'],array['Overextending the back','Pulling too heavy'],array['Band pull-apart']),
('biceps-curl','Biceps curl','Arms',array['Biceps'],array['Dumbbells'],'Beginner','Keep elbows steady and avoid using momentum.',array['Keep wrists neutral','Lower slowly'],array['Swinging the torso','Bending the wrists'],array['Band biceps curl','Hammer curl']),
('triceps-pushdown','Triceps pushdown','Arms',array['Triceps'],array['Cable'],'Beginner','Keep elbows near your sides and extend smoothly.',array['Move forearms','Keep shoulders relaxed'],array['Flared elbows','Leaning bodyweight into reps'],array['Close-grip push-up']),
('hammer-curl','Hammer curl','Arms',array['Biceps','Forearms'],array['Dumbbells'],'Beginner','Keep neutral wrists and control both phases.',array['Keep elbows near sides','Move steadily'],array['Using momentum','Shrugging'],array['Band biceps curl','Biceps curl']),
('barbell-squat','Barbell squat','Legs',array['Glutes','Core'],array['Barbell'],'Intermediate','Use a comfortable stance and depth; brace and keep feet planted.',array['Brace before descent','Keep whole foot grounded'],array['Knees collapsing inward','Losing control at depth'],array['Bodyweight squat','Leg press']),
('leg-press','Leg press','Legs',array['Glutes'],array['Machine'],'Beginner','Keep hips against the pad and avoid locking knees forcefully.',array['Use a comfortable range','Control lowering'],array['Lifting hips from pad','Locking knees hard'],array['Bodyweight squat']),
('romanian-deadlift','Romanian deadlift','Legs',array['Glutes','Hamstrings'],array['Barbell'],'Intermediate','Hinge at hips with soft knees and a neutral spine.',array['Keep bar close','Stop when position changes'],array['Turning hinge into squat','Rounding under fatigue'],array['Dumbbell Romanian deadlift']),
('leg-curl','Leg curl','Legs',array['Hamstrings'],array['Machine'],'Beginner','Move smoothly and avoid bouncing the weight.',array['Use controlled tempo','Keep hips settled'],array['Bouncing','Using excessive load'],array['Slider leg curl']),
('calf-raise','Calf raise','Calves',array[],array['Machine'],'Beginner','Use full comfortable range and pause at the top.',array['Pause briefly','Lower under control'],array['Bouncing repetitions','Using a painful stretch'],array['Standing calf raise']),
('plank','Plank','Core',array['Shoulders'],array['Bodyweight'],'Beginner','Brace abs and glutes; stop when position breaks down.',array['Keep body aligned','Breathe steadily'],array['Sagging hips','Holding breath'],array['Dead bug']),
('dead-bug','Dead bug','Core',array[],array['Bodyweight'],'Beginner','Keep lower back gently anchored while extending opposite limbs.',array['Move slowly','Use a comfortable range'],array['Arching back','Rushing the movement'],array['Plank']),
('cable-crunch','Cable crunch','Core',array[],array['Cable'],'Beginner','Curl ribs toward pelvis without pulling with your arms.',array['Move through trunk','Use light load'],array['Pulling with arms','Hinging at hips'],array['Dead bug']),
('glute-bridge','Bodyweight glute bridge','Glutes',array['Hamstrings'],array['Bodyweight'],'Beginner','Brace gently and lift hips only as high as you can without arching.',array['Press through feet','Pause at top'],array['Overarching back','Pushing only through toes'],array['Dumbbell glute bridge']),
('hip-thrust','Hip thrust','Glutes',array['Hamstrings'],array['Barbell'],'Intermediate','Keep ribs down and pause briefly at the top without overextending the back.',array['Brace ribs','Control the top position'],array['Overextending spine','Bouncing repetitions'],array['Bodyweight glute bridge']),
('standing-calf-raise','Standing calf raise','Calves',array[],array['Bodyweight'],'Beginner','Use a stable support and lower through a comfortable range.',array['Hold a stable support','Move steadily'],array['Bouncing','Using an unstable surface'],array['Calf raise']),
('seated-calf-raise','Seated calf raise','Calves',array[],array['Machine'],'Beginner','Move slowly and avoid bouncing at the bottom.',array['Pause briefly','Use comfortable range'],array['Bouncing','Loading through pain'],array['Standing calf raise']),
('wrist-curl','Wrist curl','Forearms',array[],array['Dumbbells'],'Beginner','Use a light load and keep the forearm supported.',array['Keep forearm supported','Move wrists steadily'],array['Using heavy load','Moving the elbow'],array['Farmer carry']),
('farmer-carry','Farmer carry','Forearms',array['Core','Shoulders'],array['Dumbbells'],'Intermediate','Walk tall with a load you can hold without leaning or pain.',array['Walk tall','Keep shoulders relaxed'],array['Leaning to one side','Holding breath'],array['Wrist curl']),
('inverted-row','Inverted row','Back',array['Biceps'],array['Bodyweight'],'Beginner','Use a secure bar setup and keep your body aligned as you row.',array['Secure the bar','Keep body aligned'],array['Using an unstable setup','Jerking the body'],array['Seated cable row']),
('band-row','Resistance band row','Back',array['Biceps'],array['Resistance bands'],'Beginner','Anchor the band safely and pull elbows back with control.',array['Check anchor point','Control return'],array['Using a damaged band','Leaning back to finish'],array['Seated cable row']),
('band-chest-press','Band chest press','Chest',array['Triceps'],array['Resistance bands'],'Beginner','Anchor the band securely and press without shrugging.',array['Check anchor point','Keep shoulders comfortable'],array['Using a damaged band','Arching excessively'],array['Push-up']),
('band-squat','Band squat','Legs',array['Glutes'],array['Resistance bands'],'Beginner','Keep the band secure and use a controlled comfortable squat depth.',array['Check band position','Keep feet grounded'],array['Knees collapsing','Using an unstable anchor'],array['Bodyweight squat']),
('band-overhead-press','Band overhead press','Shoulders',array['Triceps'],array['Resistance bands'],'Beginner','Stand securely on the band and press without leaning back.',array['Stand securely','Keep ribs stacked'],array['Standing on damaged band','Leaning back'],array['Overhead press']),
('band-curl','Band biceps curl','Arms',array['Biceps'],array['Resistance bands'],'Beginner','Stand securely on the band and curl without swinging.',array['Check band condition','Keep elbows steady'],array['Using a damaged band','Swinging torso'],array['Biceps curl']),
('close-grip-push-up','Close-grip push-up','Arms',array['Chest','Triceps'],array['Bodyweight'],'Beginner','Keep elbows close and use a comfortable range; elevate hands to make it easier.',array['Keep body aligned','Use an easier incline if needed'],array['Forcing painful range','Sagging hips'],array['Triceps pushdown']),
('chin-up','Chin-up','Back',array['Biceps'],array['Bodyweight'],'Advanced','Use a secure bar and controlled reps; use assistance if needed.',array['Use secure equipment','Control lowering'],array['Kipping when not intended','Dropping rapidly'],array['Lat pulldown']),
('bodyweight-squat','Bodyweight squat','Legs',array['Glutes','Core'],array['Bodyweight'],'Beginner','Keep feet stable and use a depth you can control comfortably.',array['Keep whole foot grounded','Control descent'],array['Knees collapsing inward','Losing balance'],array['Band squat']),
('reverse-lunge','Reverse lunge','Legs',array['Glutes'],array['Bodyweight'],'Beginner','Step back to a stable stance and keep the movement controlled.',array['Keep stance stable','Use support if needed'],array['Rushing the step','Forcing a painful range'],array['Leg press']),
('bear-crawl-hold','Bear crawl hold','Full body',array['Core','Shoulders'],array['Bodyweight'],'Beginner','Brace and keep knees hovering only if that position is comfortable.',array['Use a stable surface','Keep torso steady'],array['Holding breath','Continuing through pain'],array['Plank']),
('dumbbell-thruster','Dumbbell thruster','Full body',array['Legs','Shoulders'],array['Dumbbells'],'Intermediate','Use a manageable load and link the squat and press smoothly.',array['Use a controlled squat','Keep load manageable'],array['Rushing transitions','Leaning back overhead'],array['Bodyweight squat'])
on conflict (id) do nothing;

-- Clearly labelled generic estimates copied from the offline reference list. Verify package labels and preparation; these are not a verified nutrition database.
insert into public.food_reference(id,name,serving_g,calories_kcal,protein_g,carbohydrates_g,fat_g,fibre_g,source_name) values
('egg-whole','Egg, whole',100,143,12.6,0.7,9.5,null,'FitKlot generic reference estimate — verify label and preparation'),
('paneer','Paneer',100,265,18.3,1.2,20.8,null,'FitKlot generic reference estimate — verify label and preparation'),
('tofu','Tofu',100,76,8.1,1.9,4.8,null,'FitKlot generic reference estimate — verify label and preparation'),
('chicken-cooked','Chicken breast, cooked',100,165,31,0,3.6,null,'FitKlot generic reference estimate — verify label and preparation'),
('milk-whole','Milk, whole',100,61,3.2,4.8,3.3,null,'FitKlot generic reference estimate — verify label and preparation'),
('curd','Curd, plain',100,61,3.5,4.7,3.3,null,'FitKlot generic reference estimate — verify label and preparation'),
('greek-yogurt','Greek yogurt, plain',100,97,9,3.9,5,null,'FitKlot generic reference estimate — verify label and preparation'),
('dal-cooked','Dal, cooked',100,116,9,20,0.4,null,'FitKlot generic reference estimate — verify label and preparation'),
('chickpeas-cooked','Chickpeas, cooked',100,164,8.9,27.4,2.6,null,'FitKlot generic reference estimate — verify label and preparation'),
('rajma-cooked','Rajma, cooked',100,127,8.7,22.8,0.5,null,'FitKlot generic reference estimate — verify label and preparation'),
('rice-cooked','Rice, cooked',100,130,2.7,28.2,0.3,null,'FitKlot generic reference estimate — verify label and preparation'),
('roti-wheat','Roti, whole wheat',100,297,9.8,46,7.5,null,'FitKlot generic reference estimate — verify label and preparation'),
('oats-dry','Oats, dry',100,389,16.9,66.3,6.9,null,'FitKlot generic reference estimate — verify label and preparation'),
('banana','Banana',100,89,1.1,22.8,0.3,null,'FitKlot generic reference estimate — verify label and preparation'),
('apple','Apple',100,52,0.3,13.8,0.2,null,'FitKlot generic reference estimate — verify label and preparation'),
('almonds','Almonds',100,579,21.2,21.6,49.9,null,'FitKlot generic reference estimate — verify label and preparation'),
('peanut-butter','Peanut butter',100,588,25,20,50,null,'FitKlot generic reference estimate — verify label and preparation'),
('potato-boiled','Potato, boiled',100,87,1.9,20.1,0.1,null,'FitKlot generic reference estimate — verify label and preparation'),
('broccoli','Broccoli',100,34,2.8,6.6,0.4,null,'FitKlot generic reference estimate — verify label and preparation'),
('salmon-cooked','Salmon, cooked',100,206,22,0,12.4,null,'FitKlot generic reference estimate — verify label and preparation'),
('whey-powder','Whey protein powder',100,400,80,8,6,null,'FitKlot generic reference estimate — verify label and preparation')
on conflict (id) do nothing;

create table if not exists public.workout_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  split text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, id)
);
create unique index if not exists workout_plans_one_active_per_user
  on public.workout_plans(user_id) where active;

create table if not exists public.workout_plan_days (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id uuid not null,
  day_index smallint not null check (day_index between 1 and 14),
  name text not null,
  scheduled_weekday smallint check (scheduled_weekday is null or scheduled_weekday between 0 and 6),
  unique (user_id, id),
  unique (user_id, plan_id, day_index),
  foreign key (user_id, plan_id) references public.workout_plans(user_id, id) on delete cascade
);

create table if not exists public.workout_plan_exercises (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day_id uuid not null,
  sort_order smallint not null default 1 check (sort_order between 1 and 100),
  exercise_name text not null,
  primary_muscle text,
  equipment text,
  sets smallint not null default 3 check (sets between 1 and 20),
  reps text not null default '8–12' check (length(reps) <= 40),
  rest_seconds smallint not null default 90 check (rest_seconds between 0 and 900),
  target_weight_kg numeric(7,2) check (target_weight_kg is null or target_weight_kg >= 0),
  notes text not null default '',
  foreign key (user_id, day_id) references public.workout_plan_days(user_id, id) on delete cascade
);

create table if not exists public.workout_sessions (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  workout_name text not null,
  session_date date not null default current_date,
  started_at timestamptz,
  ended_at timestamptz,
  duration_min integer not null default 0 check (duration_min >= 0),
  perceived_difficulty smallint check (perceived_difficulty is null or perceived_difficulty between 1 and 10),
  notes text not null default '',
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.workout_sets (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  session_id text not null,
  exercise_name text not null,
  set_number smallint not null check (set_number between 1 and 100),
  weight_kg numeric(7,2) not null default 0 check (weight_kg >= 0),
  repetitions smallint not null default 0 check (repetitions between 0 and 1000),
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  primary key (user_id, id),
  foreign key (user_id, session_id) references public.workout_sessions(user_id, id) on delete cascade
);
create index if not exists workout_sets_user_exercise_idx on public.workout_sets(user_id, exercise_name);

create table if not exists public.exercise_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  exercise_name text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, exercise_name)
);

create table if not exists public.weight_entries (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  measured_at date not null default current_date,
  time_local time not null default localtime,
  weight_kg numeric(7,2) not null check (weight_kg between 25 and 400),
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);
alter table public.weight_entries add column if not exists time_local time not null default localtime;
create index if not exists weight_entries_user_date_idx on public.weight_entries(user_id, measured_at desc);

create table if not exists public.body_measurements (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  measured_at date not null default current_date,
  waist_cm numeric(6,2) check (waist_cm is null or waist_cm between 20 and 250),
  chest_cm numeric(6,2) check (chest_cm is null or chest_cm between 20 and 250),
  arm_cm numeric(6,2) check (arm_cm is null or arm_cm between 5 and 150),
  thigh_cm numeric(6,2) check (thigh_cm is null or thigh_cm between 10 and 200),
  hip_cm numeric(6,2) check (hip_cm is null or hip_cm between 20 and 250),
  body_fat_pct numeric(4,1) check (body_fat_pct is null or body_fat_pct between 2 and 70),
  notes text not null default '',
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.food_diary_entries (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  eaten_at date not null default current_date,
  food_name text not null,
  serving_g numeric(8,2) not null check (serving_g > 0),
  meal_type text not null default 'Snack',
  calories_kcal numeric(9,2) not null default 0 check (calories_kcal >= 0),
  protein_g numeric(8,2) not null default 0 check (protein_g >= 0),
  carbohydrates_g numeric(8,2) not null default 0 check (carbohydrates_g >= 0),
  fat_g numeric(8,2) not null default 0 check (fat_g >= 0),
  fibre_g numeric(8,2) check (fibre_g is null or fibre_g >= 0),
  source_name text not null default 'Manual estimate',
  source_id text,
  is_estimate boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);
alter table public.food_diary_entries add column if not exists source_name text not null default 'Manual estimate';
alter table public.food_diary_entries add column if not exists source_id text;
create index if not exists food_diary_user_date_idx on public.food_diary_entries(user_id, eaten_at desc);

create table if not exists public.daily_nutrition_summaries (
  user_id uuid not null references auth.users(id) on delete cascade,
  summary_date date not null,
  calories_kcal numeric(10,2) not null default 0,
  protein_g numeric(9,2) not null default 0,
  carbohydrates_g numeric(9,2) not null default 0,
  fat_g numeric(9,2) not null default 0,
  fibre_g numeric(9,2) not null default 0,
  meals_logged integer not null default 0,
  updated_at timestamptz not null default now(),
  primary key (user_id, summary_date)
);

create table if not exists public.saved_meals (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  name text not null,
  meal_type text not null default 'Meal',
  items jsonb not null default '[]'::jsonb check (jsonb_typeof(items) = 'array'),
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.saved_meal_items (
  user_id uuid not null,
  meal_id text not null,
  item_order smallint not null check (item_order between 1 and 100),
  food_name text not null,
  serving_g numeric(8,2) not null check (serving_g > 0),
  calories_kcal numeric(9,2) not null default 0,
  protein_g numeric(8,2) not null default 0,
  carbohydrates_g numeric(8,2) not null default 0,
  fat_g numeric(8,2) not null default 0,
  fibre_g numeric(8,2),
  primary key (user_id, meal_id, item_order),
  foreign key (user_id, meal_id) references public.saved_meals(user_id, id) on delete cascade
);

create table if not exists public.weekly_meal_plans (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  week_start date not null,
  plan jsonb not null default '[]'::jsonb check (jsonb_typeof(plan) = 'array'),
  grocery_list jsonb not null default '[]'::jsonb check (jsonb_typeof(grocery_list) = 'array'),
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.grocery_lists (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  week_start date,
  name text not null default 'Meal plan groceries',
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.grocery_list_items (
  user_id uuid not null,
  list_id text not null,
  item_order smallint not null check (item_order between 1 and 500),
  item_name text not null,
  amount numeric(9,2),
  unit text not null default 'g',
  checked boolean not null default false,
  primary key (user_id, list_id, item_order),
  foreign key (user_id, list_id) references public.grocery_lists(user_id, id) on delete cascade
);

create table if not exists public.water_logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  logged_at date not null default current_date,
  amount_ml integer not null check (amount_ml between 1 and 10000),
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);
create index if not exists water_logs_user_date_idx on public.water_logs(user_id, logged_at desc);

create table if not exists public.recovery_logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  logged_at date not null default current_date,
  sleep_hours numeric(3,1) check (sleep_hours is null or sleep_hours between 0 and 24),
  energy smallint check (energy is null or energy between 1 and 5),
  soreness smallint check (soreness is null or soreness between 1 and 5),
  workout_difficulty smallint check (workout_difficulty is null or workout_difficulty between 1 and 10),
  notes text not null default '',
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.personal_records (
  user_id uuid not null references auth.users(id) on delete cascade,
  exercise_name text not null,
  max_weight_kg numeric(7,2) not null default 0,
  best_repetitions smallint not null default 0,
  best_volume_kg numeric(10,2) not null default 0,
  achieved_on date,
  updated_at timestamptz not null default now(),
  primary key (user_id, exercise_name)
);

create table if not exists public.reminders (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  reminder_type text not null,
  label text not null,
  time_local time not null,
  days_of_week smallint[] not null default '{0,1,2,3,4,5,6}' check (array_position(days_of_week, null) is null),
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  in_app_enabled boolean not null default true,
  push_enabled boolean not null default false,
  workout_enabled boolean not null default true,
  meals_enabled boolean not null default true,
  hydration_enabled boolean not null default true,
  weigh_in_enabled boolean not null default true,
  recovery_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.in_app_notifications (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  title text not null,
  body text not null default '',
  notification_type text not null default 'general',
  read_at timestamptz,
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.progress_photos (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  storage_path text not null unique,
  caption text not null default '',
  taken_at date not null default current_date,
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.coach_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  used_at timestamptz not null default now(),
  primary key (user_id, used_at)
);
create index if not exists coach_usage_recent_idx on public.coach_usage(user_id, used_at desc);
create table if not exists public.food_search_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  used_at timestamptz not null default now(),
  primary key (user_id, used_at)
);
create index if not exists food_search_usage_recent_idx on public.food_search_usage(user_id, used_at desc);

-- Protect every personal table. Revoke anonymous access explicitly; grants and RLS both matter.
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','user_app_data','workout_plans','workout_plan_days','workout_plan_exercises',
    'workout_sessions','workout_sets','exercise_favorites','weight_entries','body_measurements',
    'food_diary_entries','daily_nutrition_summaries','saved_meals','saved_meal_items','weekly_meal_plans',
    'grocery_lists','grocery_list_items','water_logs','recovery_logs',
    'personal_records','reminders','notification_preferences','in_app_notifications','progress_photos','coach_usage','food_search_usage'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on table public.%I from anon', t);
    execute format('grant select, insert, update, delete on table public.%I to authenticated', t);
    execute format('drop policy if exists %I on public.%I', t || '_select_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_insert_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_update_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_delete_own', t);
    execute format('create policy %I on public.%I for select to authenticated using (user_id = (select auth.uid()))', t || '_select_own', t);
    execute format('create policy %I on public.%I for insert to authenticated with check (user_id = (select auth.uid()))', t || '_insert_own', t);
    execute format('create policy %I on public.%I for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()))', t || '_update_own', t);
    execute format('create policy %I on public.%I for delete to authenticated using (user_id = (select auth.uid()))', t || '_delete_own', t);
  end loop;
end $$;

alter table public.exercise_library enable row level security;
alter table public.food_reference enable row level security;
revoke all on public.exercise_library, public.food_reference from anon, authenticated;
grant select on public.exercise_library, public.food_reference to anon, authenticated;
drop policy if exists exercise_library_read on public.exercise_library;
create policy exercise_library_read on public.exercise_library for select to anon, authenticated using (true);
drop policy if exists food_reference_read on public.food_reference;
create policy food_reference_read on public.food_reference for select to anon, authenticated using (true);

-- Mirror the local-first app cache into relational tables in one transaction.
-- The legacy JSON row remains a per-user recovery snapshot for backwards compatibility.
create or replace function public.sync_fitklot_state(p_payload jsonb)
returns jsonb
language plpgsql
security invoker
set search_path = public, pg_temp
as $function$
declare
  uid uuid := (select auth.uid());
  prof jsonb := coalesce(p_payload->'profile', '{}'::jsonb);
  it jsonb;
  sess jsonb;
  set_item jsonb;
  plan_item jsonb;
  day_item jsonb;
  ex_item jsonb;
  day_uid uuid;
  plan_uid uuid;
  sess_id text;
  seq integer;
  ex_order integer;
begin
  if uid is null then raise exception 'Authentication required'; end if;
  if jsonb_typeof(p_payload) <> 'object' then raise exception 'State payload must be a JSON object'; end if;

  insert into public.user_app_data(user_id,payload,updated_at)
  values(uid,p_payload,now())
  on conflict(user_id) do update set payload=excluded.payload,updated_at=excluded.updated_at;

  insert into public.profiles(user_id,full_name,date_of_birth,age,sex,height_cm,current_weight_kg,target_weight_kg,goal,experience,
     training_days,workout_duration_min,equipment,dietary_preference,activity_factor,sleep_hours,preferred_split,
     calorie_target_kcal,protein_target_g,unit_preference,avoid_text,body_fat_pct,focus_muscle_groups,movement_limitations,avoid_exercise_names,updated_at)
  values(uid,coalesce(prof->>'name',''),nullif(prof->>'birthDate','')::date,nullif(prof->>'age','')::smallint,nullif(prof->>'sex',''),
    nullif(prof->>'height','')::numeric,nullif(prof->>'weight','')::numeric,nullif(prof->>'target','')::numeric,
    nullif(prof->>'goal',''),nullif(prof->>'level',''),nullif(prof->>'days','')::smallint,
    nullif(prof->>'minutes','')::smallint,
    case when jsonb_typeof(prof->'equipment')='array' then array(select jsonb_array_elements_text(prof->'equipment'))
      when nullif(prof->>'equipment','') is not null then array[prof->>'equipment'] else '{}'::text[] end,
     nullif(prof->>'diet',''),nullif(prof->>'activity','')::numeric,nullif(prof->>'sleep','')::numeric,nullif(prof->>'split',''),
    nullif(prof->>'calories','')::integer,nullif(prof->>'protein','')::numeric,
     coalesce(nullif(prof->>'units',''),'metric'),coalesce(prof->>'avoid',''),nullif(prof->>'bodyFat','')::numeric,
     coalesce(prof->>'focus',''),coalesce(prof->>'injuries',''),coalesce(prof->>'avoidExercises',''),now())
  on conflict(user_id) do update set full_name=excluded.full_name,date_of_birth=excluded.date_of_birth,age=excluded.age,sex=excluded.sex,
    height_cm=excluded.height_cm,current_weight_kg=excluded.current_weight_kg,target_weight_kg=excluded.target_weight_kg,
    goal=excluded.goal,experience=excluded.experience,training_days=excluded.training_days,
    workout_duration_min=excluded.workout_duration_min,equipment=excluded.equipment,
    dietary_preference=excluded.dietary_preference,activity_factor=excluded.activity_factor,
     sleep_hours=excluded.sleep_hours,preferred_split=excluded.preferred_split,calorie_target_kcal=excluded.calorie_target_kcal,
    protein_target_g=excluded.protein_target_g,unit_preference=excluded.unit_preference,
     avoid_text=excluded.avoid_text,body_fat_pct=excluded.body_fat_pct,focus_muscle_groups=excluded.focus_muscle_groups,
     movement_limitations=excluded.movement_limitations,avoid_exercise_names=excluded.avoid_exercise_names,updated_at=now();

  delete from public.workout_plans where user_id=uid;
  if jsonb_array_length(coalesce(p_payload->'plan','[]'::jsonb)) > 0 then
     insert into public.workout_plans(user_id,name,split) values(uid,'My training plan',nullif(prof->>'split','')) returning id into plan_uid;
    seq := 0;
    for plan_item in select value from jsonb_array_elements(p_payload->'plan') loop
      seq := seq + 1;
      seq := coalesce(nullif(plan_item->>'order','')::integer,seq);
      insert into public.workout_plan_days(user_id,plan_id,day_index,name)
        values(uid,plan_uid,least(greatest(seq,1),14),coalesce(plan_item->>'name','Training day')) returning id into day_uid;
      ex_order := 0;
      for ex_item in select value from jsonb_array_elements(coalesce(plan_item->'exercises','[]'::jsonb)) loop
        ex_order := ex_order + 1;
        insert into public.workout_plan_exercises(user_id,day_id,sort_order,exercise_name,primary_muscle,equipment,sets,reps,rest_seconds,target_weight_kg,notes)
        values(uid,day_uid,least(coalesce(nullif(ex_item->>'order','')::integer,ex_order),100),coalesce(ex_item->>'name','Exercise'),
          nullif(ex_item->>'muscle',''),nullif(ex_item->>'equipment',''),
          least(greatest(coalesce(nullif(ex_item->>'sets','')::integer,3),1),20),coalesce(nullif(ex_item->>'reps',''),'8–12'),
          least(greatest(coalesce(nullif(ex_item->>'rest','')::integer,90),0),900),nullif(ex_item->>'kg','')::numeric,coalesce(ex_item->>'notes',''));
      end loop;
    end loop;
  end if;

  delete from public.workout_sessions where user_id=uid;
  seq := 0;
  for sess in select value from jsonb_array_elements(coalesce(p_payload->'sessions','[]'::jsonb)) loop
    seq := seq + 1;
    sess_id := coalesce(nullif(sess->>'id',''),md5(sess::text)||':'||seq);
    insert into public.workout_sessions(user_id,id,workout_name,session_date,duration_min,notes)
      values(uid,sess_id,coalesce(sess->>'name','Workout'),coalesce(nullif(sess->>'date','')::date,current_date),
        greatest(coalesce(nullif(sess->>'duration','')::integer,0),0),coalesce(sess->>'notes',''));
    seq := 0;
    for set_item in select value from jsonb_array_elements(coalesce(sess->'sets','[]'::jsonb)) loop
      seq := seq + 1;
      insert into public.workout_sets(user_id,id,session_id,exercise_name,set_number,weight_kg,repetitions,completed)
      values(uid,coalesce(nullif(set_item->>'id',''),sess_id||':'||seq),sess_id,coalesce(set_item->>'exercise','Exercise'),
        greatest(coalesce(nullif(set_item->>'set','')::integer,seq),1),greatest(coalesce(nullif(set_item->>'kg','')::numeric,0),0),
        greatest(coalesce(nullif(set_item->>'reps','')::integer,0),0),coalesce((set_item->>'done')::boolean,false));
    end loop;
  end loop;

  delete from public.weight_entries where user_id=uid;
  seq := 0;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'weights','[]'::jsonb)) loop
    seq := seq + 1;
    insert into public.weight_entries(user_id,id,measured_at,time_local,weight_kg)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)||':'||seq),coalesce(nullif(it->>'date','')::date,current_date),
        coalesce(nullif(it->>'time','')::time,time '12:00'),nullif(it->>'kg','')::numeric);
  end loop;

  delete from public.body_measurements where user_id=uid;
  seq := 0;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'measurements','[]'::jsonb)) loop
    seq := seq + 1;
    insert into public.body_measurements(user_id,id,measured_at,waist_cm,chest_cm,arm_cm,thigh_cm,hip_cm,body_fat_pct,notes)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)||':'||seq),coalesce(nullif(it->>'date','')::date,current_date),
        nullif(it->'values'->>'waist','')::numeric,nullif(it->'values'->>'chest','')::numeric,nullif(it->'values'->>'arm','')::numeric,
        nullif(it->'values'->>'thigh','')::numeric,nullif(it->'values'->>'hips','')::numeric,nullif(it->'values'->>'bodyFat','')::numeric,coalesce(it->>'notes',''));
  end loop;

  delete from public.food_diary_entries where user_id=uid;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'foods','[]'::jsonb)) loop
    insert into public.food_diary_entries(user_id,id,eaten_at,food_name,serving_g,meal_type,calories_kcal,protein_g,carbohydrates_g,fat_g,fibre_g,source_name,source_id,is_estimate)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),coalesce(nullif(it->>'date','')::date,current_date),
        coalesce(it->>'name','Food'),greatest(coalesce(nullif(it->>'qty','')::numeric,100),0.01),coalesce(it->>'meal','Snack'),
        greatest(coalesce(nullif(it->>'kcal','')::numeric,0),0),greatest(coalesce(nullif(it->>'protein','')::numeric,0),0),
        greatest(coalesce(nullif(it->>'carbs','')::numeric,0),0),greatest(coalesce(nullif(it->>'fat','')::numeric,0),0),
        nullif(it->>'fiber','')::numeric,coalesce(nullif(it->>'source',''),'Manual estimate'),nullif(it->>'sourceId',''),true);
  end loop;

  delete from public.daily_nutrition_summaries where user_id=uid;
  insert into public.daily_nutrition_summaries(user_id,summary_date,calories_kcal,protein_g,carbohydrates_g,fat_g,fibre_g,meals_logged)
    select uid,eaten_at,sum(calories_kcal),sum(protein_g),sum(carbohydrates_g),sum(fat_g),sum(coalesce(fibre_g,0)),count(*)
    from public.food_diary_entries where user_id=uid group by eaten_at;

  delete from public.saved_meals where user_id=uid;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'savedMeals','[]'::jsonb)) loop
    insert into public.saved_meals(user_id,id,name,meal_type,items)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),coalesce(it->>'name','Saved meal'),coalesce(it->>'meal','Meal'),
        coalesce(it->'items','[]'::jsonb));
    seq := 0;
    for ex_item in select value from jsonb_array_elements(coalesce(it->'items','[]'::jsonb)) loop
      seq := seq + 1;
      insert into public.saved_meal_items(user_id,meal_id,item_order,food_name,serving_g,calories_kcal,protein_g,carbohydrates_g,fat_g,fibre_g)
        values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),least(seq,100),coalesce(ex_item->>'name','Food'),
          greatest(coalesce(nullif(ex_item->>'qty','')::numeric,100),0.01),coalesce(nullif(ex_item->>'kcal','')::numeric,0),
          coalesce(nullif(ex_item->>'protein','')::numeric,0),coalesce(nullif(ex_item->>'carbs','')::numeric,0),
          coalesce(nullif(ex_item->>'fat','')::numeric,0),nullif(ex_item->>'fiber','')::numeric);
    end loop;
  end loop;

  delete from public.weekly_meal_plans where user_id=uid;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'weeklyPlans','[]'::jsonb)) loop
    insert into public.weekly_meal_plans(user_id,id,week_start,plan,grocery_list)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),coalesce(nullif(it->>'weekStart','')::date,current_date),
        coalesce(it->'days','[]'::jsonb),coalesce(it->'groceries','[]'::jsonb));
  end loop;

  delete from public.grocery_lists where user_id=uid;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'groceryLists','[]'::jsonb)) loop
    insert into public.grocery_lists(user_id,id,week_start,name)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),nullif(it->>'weekStart','')::date,coalesce(it->>'name','Meal plan groceries'));
    seq := 0;
    for ex_item in select value from jsonb_array_elements(coalesce(it->'items','[]'::jsonb)) loop
      seq := seq + 1;
      insert into public.grocery_list_items(user_id,list_id,item_order,item_name,amount,unit,checked)
        values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),least(seq,500),coalesce(ex_item->>'name','Item'),
          nullif(ex_item->>'amount','')::numeric,coalesce(ex_item->>'unit','g'),coalesce((ex_item->>'checked')::boolean,false));
    end loop;
  end loop;

  delete from public.water_logs where user_id=uid;
  seq := 0;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'water','[]'::jsonb)) loop
    seq := seq + 1;
    insert into public.water_logs(user_id,id,logged_at,amount_ml)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)||':'||seq),coalesce(nullif(it->>'date','')::date,current_date),
        greatest(coalesce(nullif(it->>'ml','')::integer,0),1));
  end loop;

  delete from public.recovery_logs where user_id=uid;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'recovery','[]'::jsonb)) loop
    insert into public.recovery_logs(user_id,id,logged_at,sleep_hours,energy,soreness,workout_difficulty,notes)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),coalesce(nullif(it->>'date','')::date,current_date),
        nullif(it->>'sleep','')::numeric,nullif(it->>'energy','')::smallint,nullif(it->>'soreness','')::smallint,
        nullif(it->>'difficulty','')::smallint,coalesce(it->>'notes',''));
  end loop;

  delete from public.reminders where user_id=uid;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'reminders','[]'::jsonb)) loop
    insert into public.reminders(user_id,id,reminder_type,label,time_local,days_of_week,enabled)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)),coalesce(it->>'type','general'),coalesce(it->>'label','Reminder'),
        coalesce(nullif(it->>'time','')::time,time '09:00'),
        case when jsonb_typeof(it->'days')='array' then array(select value::smallint from jsonb_array_elements_text(it->'days')) else '{0,1,2,3,4,5,6}'::smallint[] end,
        coalesce((it->>'enabled')::boolean,true));
  end loop;

  insert into public.notification_preferences(user_id,in_app_enabled,push_enabled,workout_enabled,meals_enabled,hydration_enabled,weigh_in_enabled,recovery_enabled)
  values(uid,coalesce((p_payload->'notificationPrefs'->>'inApp')::boolean,true),coalesce((p_payload->'notificationPrefs'->>'push')::boolean,false),
    coalesce((p_payload->'notificationPrefs'->>'workouts')::boolean,true),coalesce((p_payload->'notificationPrefs'->>'meals')::boolean,true),
    coalesce((p_payload->'notificationPrefs'->>'water')::boolean,true),coalesce((p_payload->'notificationPrefs'->>'weight')::boolean,true),
    coalesce((p_payload->'notificationPrefs'->>'recovery')::boolean,true))
  on conflict(user_id) do update set in_app_enabled=excluded.in_app_enabled,push_enabled=excluded.push_enabled,
    workout_enabled=excluded.workout_enabled,meals_enabled=excluded.meals_enabled,hydration_enabled=excluded.hydration_enabled,
    weigh_in_enabled=excluded.weigh_in_enabled,recovery_enabled=excluded.recovery_enabled,updated_at=now();

  delete from public.in_app_notifications where user_id=uid;
  seq := 0;
  for it in select value from jsonb_array_elements(coalesce(p_payload->'notifications','[]'::jsonb)) loop
    seq := seq + 1;
    insert into public.in_app_notifications(user_id,id,title,body,notification_type,read_at,created_at)
      values(uid,coalesce(nullif(it->>'id',''),md5(it::text)||':'||seq),coalesce(it->>'title','FitKlot reminder'),
        coalesce(it->>'body',''),coalesce(it->>'type','general'),nullif(it->>'readAt','')::timestamptz,
        coalesce(nullif(it->>'createdAt','')::timestamptz,now()));
  end loop;

  delete from public.exercise_favorites where user_id=uid;
  insert into public.exercise_favorites(user_id,exercise_name)
    select uid,value from jsonb_array_elements_text(coalesce(p_payload->'favorites','[]'::jsonb)) on conflict do nothing;

  delete from public.personal_records where user_id=uid;
  insert into public.personal_records(user_id,exercise_name,max_weight_kg,best_repetitions,best_volume_kg,achieved_on)
    select uid,exercise_name,max(weight_kg),max(repetitions),max(weight_kg*repetitions),
      (array_agg(s.session_date order by weight_kg desc, s.session_date desc))[1]
    from public.workout_sets ws join public.workout_sessions s on s.user_id=ws.user_id and s.id=ws.session_id
    where ws.user_id=uid and ws.completed group by exercise_name;

  return jsonb_build_object('ok',true,'synced_at',now());
end;
$function$;

revoke all on function public.sync_fitklot_state(jsonb) from public, anon;
grant execute on function public.sync_fitklot_state(jsonb) to authenticated;

create or replace function public.claim_fitklot_coach_slot()
returns boolean
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  uid uuid := (select auth.uid());
  recent_count integer;
begin
  if uid is null then raise exception 'Authentication required'; end if;
  perform pg_advisory_xact_lock(hashtextextended(uid::text, 0));
  delete from public.coach_usage where user_id=uid and used_at < clock_timestamp() - interval '5 minutes';
  select count(*) into recent_count from public.coach_usage
    where user_id=uid and used_at > clock_timestamp() - interval '5 minutes';
  if recent_count >= 12 then return false; end if;
  insert into public.coach_usage(user_id,used_at) values(uid,clock_timestamp());
  return true;
end;
$function$;
revoke all on function public.claim_fitklot_coach_slot() from public, anon;
grant execute on function public.claim_fitklot_coach_slot() to authenticated;

-- Rate-limit the optional USDA lookup and keep usage rows inaccessible to clients.
alter table public.food_search_usage enable row level security;
revoke all on table public.coach_usage, public.food_search_usage from anon, authenticated;

create or replace function public.claim_fitklot_food_search_slot()
returns boolean
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  uid uuid := (select auth.uid());
  recent_count integer;
begin
  if uid is null then raise exception 'Authentication required'; end if;
  perform pg_advisory_xact_lock(hashtextextended(uid::text, 1));
  delete from public.food_search_usage where user_id=uid and used_at < clock_timestamp() - interval '1 minute';
  select count(*) into recent_count from public.food_search_usage
    where user_id=uid and used_at > clock_timestamp() - interval '1 minute';
  if recent_count >= 20 then return false; end if;
  insert into public.food_search_usage(user_id,used_at) values(uid,clock_timestamp());
  return true;
end;
$function$;
revoke all on function public.claim_fitklot_food_search_slot() from public, anon;
grant execute on function public.claim_fitklot_food_search_slot() to authenticated;

-- Progress photos must use a private Storage bucket named `progress-photos`.
-- Create the bucket in Supabase Storage; the object name must start with the user's UUID.
drop policy if exists fitklot_progress_photos_select on storage.objects;
drop policy if exists fitklot_progress_photos_insert on storage.objects;
drop policy if exists fitklot_progress_photos_update on storage.objects;
drop policy if exists fitklot_progress_photos_delete on storage.objects;
create policy fitklot_progress_photos_select on storage.objects for select to authenticated
  using (bucket_id='progress-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy fitklot_progress_photos_insert on storage.objects for insert to authenticated
  with check (bucket_id='progress-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy fitklot_progress_photos_update on storage.objects for update to authenticated
  using (bucket_id='progress-photos' and (storage.foldername(name))[1]=(select auth.uid())::text)
  with check (bucket_id='progress-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy fitklot_progress_photos_delete on storage.objects for delete to authenticated
  using (bucket_id='progress-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);

notify pgrst, 'reload schema';
