FitKlot Android APK project
===========================

This folder is a native Android WebView wrapper for the FitKlot app. The AndroidManifest.xml is at app/src/main/AndroidManifest.xml. The HTML, CSS and JavaScript are bundled in app/src/main/assets, so the app opens locally and its guest fitness tools work without hosting the site.

Build an installable debug APK
------------------------------

1. Install an Android Studio version that supports Android Gradle Plugin 9.4, then add Android SDK Platform 37 and Build Tools 36.0.0 in SDK Manager.
2. Use JDK 17 (Android Studio's bundled JDK is suitable) and install Gradle 9.6.0.
3. Open this android folder in Android Studio. If prompted, select the local Gradle 9.6.0 installation, then let Gradle sync and download the AndroidX dependencies.
4. In Android Studio, choose Build > Build Bundle(s) / APK(s) > Build APK(s). Or run `gradle :app:assembleDebug` from this folder.
5. The debug APK is created at app/build/outputs/apk/debug/app-debug.apk.
6. Copy that APK to an Android phone, open it, and allow the file manager/browser to install apps from this source if Android asks.

This workspace does not include an Android SDK/JDK/Gradle installation, so it contains the native project and manifest but no prebuilt APK. Android Studio downloads the Gradle and Android dependencies during the first sync.

App details and limits
----------------------

- Application ID: com.fitklot.app
- Android compatibility: Android 10 (API 29) and later. The project compiles and targets API 37.
- JavaScript and DOM storage are enabled for the bundled app; direct file:// access is disabled.
- INTERNET is declared for configured Supabase and other online features. Guest tracking and the offline coach continue to use local app storage.
- No camera, contacts, location, or notification permission is requested. Geolocation is disabled in the WebView. The browser-based AR preview may report unavailable inside Android WebView; the 3D WebGL preview remains available when the installed WebView supports WebGL.
- This debug APK is signed with a development key and is intended for personal installation/testing. Create a private release signing key in Android Studio for distribution. Never share that key.
