plugins {
    id("com.android.application")
}

android {
    namespace = "com.fitklot.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.fitklot.app"
        minSdk = 29
        targetSdk = 37
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.17.0")
    implementation("androidx.webkit:webkit:1.17.1")
}
