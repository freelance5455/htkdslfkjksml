/* FitKlot AI verified monthly membership checkout.
   The browser never receives the Razorpay secret or Supabase service-role key. */
(function () {
  const cfg = window.FITKLOT_CONFIG || {};
  const apiBase = String(cfg.paymentApiBase || '/api').replace(/\/$/, '');
  const freePages = new Set(['dashboard', 'pricing', 'helpdesk', 'settings']);
  const premiumPages = new Set(['workouts', 'nutrition', 'progress', 'recovery', 'records', 'achievements', 'profile', 'session', 'exercises', 'foods', 'plan', 'coach']);
  let checkoutBusy = false;
  let checkoutInstance = null;

  function apiUrl(path) { return apiBase + path; }
  async function getAccessToken() {
    if (!window.supabase || !window.FITKLOT_CONFIG) throw new Error('Sign in is required before purchasing membership.');
    const client = (typeof supa !== 'undefined' && supa) ? supa : window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);
    const { data, error } = await client.auth.getSession();
    if (error || !data?.session?.access_token) throw new Error('Please sign in or create an account to purchase membership.');
    return data.session.access_token;
  }
  async function request(path, token, body) {
    const response = await fetch(apiUrl(path), {
      method: body ? 'POST' : 'GET',
      headers: Object.assign({ 'Authorization': 'Bearer ' + token, 'Accept': 'application/json' }, body ? { 'Content-Type': 'application/json' } : {}),
      body: body ? JSON.stringify(body) : undefined,
      credentials: 'omit'
    });
    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (!response.ok || data.ok === false) throw new Error(data.error || data.message || 'Payment service is unavailable. Please try again.');
    return data;
  }
  function renderUpiFallbackQR() {
    const box = document.getElementById('fitklotUpiQr');
    if (!box || box.dataset.ready === '1') return;
    const uri = 'upi://pay?pa=' + encodeURIComponent('priyanshuuuuuu@slc') + '&pn=' + encodeURIComponent('FitKlot AI') + '&am=50.00&cu=INR&tn=' + encodeURIComponent('FitKlot AI monthly membership');
    if (window.QRCode) { box.innerHTML = ''; new QRCode(box, { text: uri, width: 220, height: 220, colorDark: '#111111', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M }); box.dataset.ready = '1'; }
    else { box.textContent = 'QR library unavailable. Use secure checkout above.'; }
  }
  function status(text, bad) {
    const el = document.getElementById('checkoutStatus');
    if (el) { el.textContent = text; el.style.color = bad ? '#ef7d7d' : ''; }
  }
  function showCongrats() {
    window.fitklotPaidActive = true;
    const el = document.getElementById('membershipWelcomeToast');
    if (el) {
      el.innerHTML = '<b>Congratulations! 🎉</b><span>Your FitKlot membership is active. Enjoy your workout ✦</span>';
      el.classList.add('visible');
      clearTimeout(window.fitklotWelcomeTimer);
      window.fitklotWelcomeTimer = setTimeout(() => el.classList.remove('visible'), 5000);
    }
  }
  function updateMembershipNavLocks() {
    const active = !!window.fitklotPaidActive;
    document.querySelectorAll('[data-page]').forEach(btn => {
      const page = btn.dataset.page;
      if (!page || freePages.has(page) || !premiumPages.has(page)) return;
      let lock = btn.querySelector('.fitklot-nav-lock');
      if (!active) {
        if (!lock) { lock = document.createElement('span'); lock.className = 'fitklot-nav-lock'; lock.textContent = '🔒'; lock.setAttribute('aria-label', 'Premium'); btn.appendChild(lock); }
      } else if (lock) lock.remove();
    });
  }
  window.updateMembershipNavLocks = updateMembershipNavLocks;

  // Gate premium screens at navigation time. Dashboard, pricing, settings and Help Desk remain accessible.
  const originalGo = window.go;
  if (typeof originalGo === 'function') {
    window.go = function (page) {
      if (premiumPages.has(page) && !window.fitklotPaidActive) {
        if (typeof originalGo === 'function') originalGo('pricing');
        status('🔒 This feature is part of FitKlot Premium. Unlock everything for ₹50/month.', false);
        if (typeof window.toast === 'function') window.toast('Unlock FitKlot Premium for ₹50/month');
        return;
      }
      return originalGo.apply(this, arguments);
    };
  }

  window.refreshPaidMembershipStatus = async function (showMessage) {
    try {
      const token = await getAccessToken();
      const data = await request('/membership', token);
      window.fitklotPaidActive = !!data.active && !!data.expires_at && Date.parse(data.expires_at) > Date.now();
      window.fitklotMembershipExpiresAt = data.expires_at ? Date.parse(data.expires_at) : 0;
      if (typeof serverMembership !== 'undefined') serverMembership = window.fitklotPaidActive ? { active: true, expiresAt: window.fitklotMembershipExpiresAt, source: 'verified-payment' } : null;
      if (typeof window.updateSiteMembershipGate === 'function') window.updateSiteMembershipGate();
      updateMembershipNavLocks();
      if (showMessage) status(window.fitklotPaidActive ? 'Your membership is active until ' + new Date(window.fitklotMembershipExpiresAt).toLocaleDateString() + '.' : 'No active membership was found for this account.', false);
      return data;
    } catch (e) {
      window.fitklotPaidActive = false;
      window.fitklotMembershipExpiresAt = 0;
      updateMembershipNavLocks();
      if (showMessage) status(e.message || 'Could not check membership. Please try again.', true);
      return { active: false, error: e.message };
    }
  };

  window.startSecureCheckout = async function () {
    if (checkoutBusy) return;
    checkoutBusy = true;
    const button = document.getElementById('checkoutButton');
    if (button) { button.disabled = true; button.textContent = 'Preparing secure checkout…'; }
    try {
      const token = await getAccessToken();
      const order = await request('/create-order', token, { plan: 'monthly' });
      if (!order.order_id || !order.key_id) throw new Error('Payment provider did not return a valid checkout order.');
      if (!window.Razorpay) {
        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://checkout.razorpay.com/v1/checkout.js';
          script.onload = resolve;
          script.onerror = () => reject(new Error('Secure checkout could not load. Check your internet connection.'));
          document.head.appendChild(script);
        });
      }
      const options = {
        key: order.key_id,
        amount: 5000,
        currency: 'INR',
        name: 'FitKlot AI',
        description: 'FitKlot Premium · 30 days',
        order_id: order.order_id,
        prefill: { email: order.email || '' },
        notes: { plan: 'monthly' },
        theme: { color: '#35d66f' },
        modal: { ondismiss: () => status('Checkout closed. No membership was activated.', false) },
        handler: async function (response) {
          try {
            status('Payment received. Verifying securely before unlocking your account…', false);
            const verified = await request('/verify-payment', token, {
              order_id: response.razorpay_order_id,
              payment_id: response.razorpay_payment_id,
              signature: response.razorpay_signature
            });
            try { checkoutInstance?.close(); } catch (_) {}
            window.fitklotPaidActive = true;
            window.fitklotMembershipExpiresAt = Date.parse(verified.expires_at);
            if (typeof serverMembership !== 'undefined') serverMembership = { active: true, expiresAt: window.fitklotMembershipExpiresAt, source: 'verified-payment' };
            if (typeof window.updateSiteMembershipGate === 'function') window.updateSiteMembershipGate();
            updateMembershipNavLocks();
            status('Payment verified. Your membership is active.', false);
            showCongrats();
            setTimeout(() => { if (typeof window.go === 'function') window.go('dashboard'); }, 700);
          } catch (e) {
            status('Payment may have succeeded, but verification is still pending. Do not pay again. Tap Restore membership in a moment or contact support. ' + (e.message || ''), true);
          }
        }
      };
      checkoutInstance = new window.Razorpay(options);
      checkoutInstance.on('payment.failed', function (event) {
        status((event?.error?.description || 'Payment was not completed. No membership was activated.'), true);
      });
      checkoutInstance.open();
    } catch (e) {
      status(e.message || 'Could not start checkout. Please try again.', true);
      if (/sign in|create an account/i.test(e.message || '') && typeof window.showAuth === 'function') window.showAuth('login');
    } finally {
      checkoutBusy = false;
      if (button) { button.disabled = false; button.textContent = 'Unlock everything · Pay ₹50'; }
    }
  };

  document.addEventListener('DOMContentLoaded', () => {
    updateMembershipNavLocks();
    renderUpiFallbackQR();
    if (window.supabase && cfg.supabaseUrl && cfg.supabaseAnonKey) {
      try {
        const client = (typeof supa !== 'undefined' && supa) ? supa : window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);
        client.auth.onAuthStateChange((event) => {
          if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
            setTimeout(() => window.refreshPaidMembershipStatus(false), 0);
          }
          if (event === 'SIGNED_OUT') {
            window.fitklotPaidActive = false;
            window.fitklotMembershipExpiresAt = 0;
            updateMembershipNavLocks();
          }
        });
        window.refreshPaidMembershipStatus(false);
      } catch (e) { console.warn('FitKlot membership status unavailable until configured.'); }
    }
  });
})();
