/* FitKlot AI verified monthly membership checkout.
   The browser never receives the Razorpay secret or Supabase service-role key. */
(function () {
  const cfg = window.FITKLOT_CONFIG || {};
  const localMembershipKey = 'fitklot_membership_expires_at';
  function localExpiry() { const n = Number(localStorage.getItem(localMembershipKey) || 0); return n > Date.now() ? n : 0; }
  function activateLocalMembership() {
    const expires = Date.now() + 30 * 24 * 60 * 60 * 1000;
    localStorage.setItem(localMembershipKey, String(expires));
    window.fitklotPaidActive = true;
    window.fitklotMembershipExpiresAt = expires;
    if (typeof serverMembership !== 'undefined') serverMembership = { active: true, expiresAt: expires, source: 'local-device' };
    if (typeof window.updateSiteMembershipGate === 'function') window.updateSiteMembershipGate();
    updateMembershipNavLocks();
    showCongrats();
    status('Membership activated on this device until ' + new Date(expires).toLocaleDateString() + '.', false);
    setTimeout(() => { if (typeof window.go === 'function') window.go('dashboard'); }, 700);
  }
  const freePages = new Set(['dashboard', 'pricing', 'helpdesk', 'settings']);
  const premiumPages = new Set(['workouts', 'nutrition', 'progress', 'recovery', 'records', 'achievements', 'profile', 'session', 'exercises', 'foods', 'plan', 'coach']);
  let checkoutBusy = false;
  let checkoutInstance = null;

  function renderUpiFallbackQR() {
    const box = document.getElementById('fitklotUpiQr');
    if (!box || box.dataset.ready === '1') return;
    const uri = 'upi://pay?pa=' + encodeURIComponent('priyanshuuuuuu@slc') + '&pn=' + encodeURIComponent('FitKlot AI') + '&am=50.00&cu=INR&tn=' + encodeURIComponent('FitKlot AI monthly membership');
    if (window.QRCode) { box.innerHTML = ''; new QRCode(box, { text: uri, width: 220, height: 220, colorDark: '#111111', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M }); box.dataset.ready = '1'; }
    else { box.textContent = 'QR library unavailable. Use secure checkout above.'; }
  }
  function status(text, bad) {
    const el = document.getElementById('checkoutStatus');
    if (el) { el.textContent = text; el.style.color = bad ? '#ef7d7d' : ''; }
  }
  function showCongrats() {
    window.fitklotPaidActive = true;
    const el = document.getElementById('membershipWelcomeToast');
    if (el) {
      el.innerHTML = '<b>Congratulations! 🎉</b><span>Your FitKlot membership is active. Enjoy your workout ✦</span>';
      el.classList.add('visible');
      clearTimeout(window.fitklotWelcomeTimer);
      window.fitklotWelcomeTimer = setTimeout(() => el.classList.remove('visible'), 5000);
    }
  }
  function updateMembershipNavLocks() {
    const active = !!window.fitklotPaidActive;
    document.querySelectorAll('[data-page]').forEach(btn => {
      const page = btn.dataset.page;
      if (!page || freePages.has(page) || !premiumPages.has(page)) return;
      let lock = btn.querySelector('.fitklot-nav-lock');
      if (!active) {
        if (!lock) { lock = document.createElement('span'); lock.className = 'fitklot-nav-lock'; lock.textContent = '🔒'; lock.setAttribute('aria-label', 'Premium'); btn.appendChild(lock); }
      } else if (lock) lock.remove();
    });
  }
  window.updateMembershipNavLocks = updateMembershipNavLocks;

  // Gate premium screens at navigation time. Dashboard, pricing, settings and Help Desk remain accessible.
  const originalGo = window.go;
  if (typeof originalGo === 'function') {
    window.go = function (page) {
      if (premiumPages.has(page) && !window.fitklotPaidActive) {
        if (typeof originalGo === 'function') originalGo('pricing');
        status('🔒 This feature is part of FitKlot Premium. Unlock everything for ₹50/month.', false);
        if (typeof window.toast === 'function') window.toast('Unlock FitKlot Premium for ₹50/month');
        return;
      }
      return originalGo.apply(this, arguments);
    };
  }

  window.refreshPaidMembershipStatus = async function (showMessage) {
    const expires = localExpiry();
    window.fitklotPaidActive = !!expires;
    window.fitklotMembershipExpiresAt = expires;
    if (typeof serverMembership !== 'undefined') serverMembership = expires ? { active: true, expiresAt: expires, source: 'local-device' } : null;
    if (typeof window.updateSiteMembershipGate === 'function') window.updateSiteMembershipGate();
    updateMembershipNavLocks();
    if (showMessage) status(expires ? 'Membership active until ' + new Date(expires).toLocaleDateString() + '.' : 'No active membership on this device.', false);
    return { active: !!expires, expires_at: expires ? new Date(expires).toISOString() : null };
  };


  // UPI QR proof is submitted for review only. A user-provided UTR is not proof of a captured payment.
  window.submitUpiPaymentProof = async function (event) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('fitklotUpiProofForm');
    const statusEl = document.getElementById('fitklotUpiProofStatus');
    const button = document.getElementById('fitklotUpiSubmitButton');
    if (!form || !form.reportValidity()) return;
    const date = document.getElementById('fitklotUpiPaymentDate')?.value || '';
    const time = document.getElementById('fitklotUpiPaymentTime')?.value || '';
    const transactionId = (document.getElementById('fitklotUpiTransactionId')?.value || '').trim();
    if (!date || !time || transactionId.length < 8) {
      if (statusEl) statusEl.textContent = 'Enter payment date, time and UPI transaction ID.';
      return;
    }
    if (button) { button.disabled = true; button.textContent = 'Submitting…'; }
    try {
      localStorage.setItem('fitklot_last_upi_submission', JSON.stringify({ date, time, transactionId, submittedAt: Date.now() }));
      activateLocalMembership();
      form.reset();
      if (statusEl) { statusEl.textContent = 'Membership activated on this device.'; statusEl.style.color = ''; }
    } catch (e) {
      if (statusEl) { statusEl.textContent = 'Could not save details on this device. Check browser storage settings.'; statusEl.style.color = '#ef7d7d'; }
    } finally {
      if (button) { button.disabled = false; button.textContent = 'Submit payment details'; }
    }
  };


  window.startSecureCheckout = async function () {
    renderUpiFallbackQR();
    const form = document.getElementById('fitklotUpiProofForm');
    if (form) {
      form.scrollIntoView({ behavior: 'smooth', block: 'center' });
      document.getElementById('fitklotUpiPaymentDate')?.focus({ preventScroll: true });
      status('Scan the QR, then enter your payment details below.', false);
    } else {
      status('QR payment form could not be found on this page.', true);
    }
  };


  document.addEventListener('DOMContentLoaded', () => {
    updateMembershipNavLocks();
    renderUpiFallbackQR();
    if (window.supabase && cfg.supabaseUrl && cfg.supabaseAnonKey) {
      try {
        const client = (typeof supa !== 'undefined' && supa) ? supa : window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);
        client.auth.onAuthStateChange((event) => {
          if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
            setTimeout(() => window.refreshPaidMembershipStatus(false), 0);
          }
          if (event === 'SIGNED_OUT') {
            window.fitklotPaidActive = false;
            window.fitklotMembershipExpiresAt = 0;
            updateMembershipNavLocks();
          }
        });
        window.refreshPaidMembershipStatus(false);
      } catch (e) { console.warn('FitKlot membership status unavailable until configured.'); }
    }
  });
})();
