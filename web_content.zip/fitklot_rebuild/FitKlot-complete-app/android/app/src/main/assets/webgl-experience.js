(() => {
  const canvas = document.getElementById('dumbbellCanvas');
  const stage = document.getElementById('modelStage');
  const arButton = document.getElementById('arPreviewButton');
  const status = document.getElementById('modelStatus');
  const fallback = document.getElementById('modelFallback');
  if (!canvas || !stage) return;

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let gl;
  try {
    gl = canvas.getContext('webgl', { alpha: true, antialias: true, powerPreference: 'low-power' }) ||
      canvas.getContext('experimental-webgl', { alpha: true, antialias: true });
  } catch (_) {}
  if (!gl) {
    fallback.hidden = false;
    status.textContent = 'WebGL is unavailable · other app tools still work';
    if (arButton) { arButton.disabled = true; arButton.textContent = 'AR unavailable'; }
    installScrollReveals();
    return;
  }

  const vertexSource = [
    'attribute vec3 aPosition;',
    'attribute vec3 aNormal;',
    'uniform mat4 uModel;',
    'uniform mat4 uView;',
    'uniform mat4 uProjection;',
    'varying vec3 vNormal;',
    'varying vec3 vPosition;',
    'void main(){',
    '  vec4 world = uModel * vec4(aPosition, 1.0);',
    '  vPosition = world.xyz;',
    '  vNormal = normalize(mat3(uModel) * aNormal);',
    '  gl_Position = uProjection * uView * world;',
    '}',
  ].join('\n');
  const fragmentSource = [
    'precision mediump float;',
    'uniform vec3 uColor;',
    'varying vec3 vNormal;',
    'varying vec3 vPosition;',
    'void main(){',
    '  vec3 n = normalize(vNormal);',
    '  vec3 light = normalize(vec3(-0.42, 0.72, 0.55));',
    '  float diffuse = max(dot(n, light), 0.0);',
    '  vec3 viewDir = normalize(vec3(0.0, 0.0, 3.0) - vPosition);',
    '  vec3 halfDir = normalize(light + viewDir);',
    '  float specular = pow(max(dot(n, halfDir), 0.0), 38.0);',
    '  vec3 color = uColor * (0.3 + 0.72 * diffuse) + vec3(0.76, 1.0, 0.91) * specular * 0.32;',
    '  gl_FragColor = vec4(color, 1.0);',
    '}',
  ].join('\n');

  function compileShader(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const message = gl.getShaderInfoLog(shader) || 'WebGL shader compilation failed.';
      gl.deleteShader(shader);
      throw new Error(message);
    }
    return shader;
  }

  let program, attributes, uniforms, parts;
  try {
    const vertex = compileShader(gl.VERTEX_SHADER, vertexSource);
    const fragment = compileShader(gl.FRAGMENT_SHADER, fragmentSource);
    program = gl.createProgram();
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || 'WebGL program linking failed.');
    attributes = { position: gl.getAttribLocation(program, 'aPosition'), normal: gl.getAttribLocation(program, 'aNormal') };
    uniforms = {
      model: gl.getUniformLocation(program, 'uModel'),
      view: gl.getUniformLocation(program, 'uView'),
      projection: gl.getUniformLocation(program, 'uProjection'),
      color: gl.getUniformLocation(program, 'uColor'),
    };
    gl.useProgram(program);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.clearColor(0, 0, 0, 0);
    parts = [
      { mesh: createCylinder(0.065, 1.9, 40), x: 0, color: [0.75, 0.82, 0.87] },
      { mesh: createCylinder(0.40, 0.28, 48), x: -0.82, color: [0.09, 0.13, 0.17] },
      { mesh: createCylinder(0.40, 0.28, 48), x: 0.82, color: [0.09, 0.13, 0.17] },
      { mesh: createCylinder(0.24, 0.07, 40), x: -0.66, color: [0.30, 0.95, 0.70] },
      { mesh: createCylinder(0.24, 0.07, 40), x: 0.66, color: [0.30, 0.95, 0.70] },
      { mesh: createCylinder(0.13, 0.06, 36), x: -1.00, color: [0.47, 1.00, 0.77] },
      { mesh: createCylinder(0.13, 0.06, 36), x: 1.00, color: [0.47, 1.00, 0.77] },
    ];
  } catch (error) {
    fallback.hidden = false;
    status.textContent = '3D preview could not start · other app tools still work';
    if (arButton) { arButton.disabled = true; arButton.textContent = 'AR unavailable'; }
    console.warn('FitKlot WebGL model:', error.message);
    installScrollReveals();
    return;
  }

  function createCylinder(radius, length, segments) {
    const positions = [], normals = [];
    const half = length / 2;
    const add = (a, b, c, na, nb, nc) => {
      positions.push(...a, ...b, ...c);
      normals.push(...na, ...nb, ...nc);
    };
    for (let i = 0; i < segments; i++) {
      const a0 = (i / segments) * Math.PI * 2, a1 = ((i + 1) / segments) * Math.PI * 2;
      const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
      const l0 = [-half, radius * c0, radius * s0], r0 = [half, radius * c0, radius * s0];
      const l1 = [-half, radius * c1, radius * s1], r1 = [half, radius * c1, radius * s1];
      const n0 = [0, c0, s0], n1 = [0, c1, s1];
      add(l0, r1, r0, n0, n1, n0);
      add(l0, l1, r1, n0, n1, n1);
      const centerLeft = [-half, 0, 0], centerRight = [half, 0, 0];
      add(centerRight, r0, r1, [1, 0, 0], [1, 0, 0], [1, 0, 0]);
      add(centerLeft, l1, l0, [-1, 0, 0], [-1, 0, 0], [-1, 0, 0]);
    }
    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
    const normalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);
    return { buffer, normalBuffer, count: positions.length / 3 };
  }

  function multiply(a, b) {
    const out = new Float32Array(16);
    for (let col = 0; col < 4; col++) {
      for (let row = 0; row < 4; row++) {
        out[col * 4 + row] =
          a[row] * b[col * 4] + a[4 + row] * b[col * 4 + 1] +
          a[8 + row] * b[col * 4 + 2] + a[12 + row] * b[col * 4 + 3];
      }
    }
    return out;
  }

  function translation(x, y, z) {
    return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
  }

  function scaleMatrix(x, y, z) {
    return new Float32Array([x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]);
  }

  function rotateX(angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]);
  }

  function rotateY(angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]);
  }

  function normalize(v) {
    const length = Math.hypot(v[0], v[1], v[2]) || 1;
    return [v[0] / length, v[1] / length, v[2] / length];
  }

  function lookAt(eye, center, up) {
    const z = normalize([eye[0] - center[0], eye[1] - center[1], eye[2] - center[2]]);
    const x = normalize([up[1] * z[2] - up[2] * z[1], up[2] * z[0] - up[0] * z[2], up[0] * z[1] - up[1] * z[0]]);
    const y = [z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0]];
    return new Float32Array([
      x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0,
      -(x[0] * eye[0] + x[1] * eye[1] + x[2] * eye[2]),
      -(y[0] * eye[0] + y[1] * eye[1] + y[2] * eye[2]),
      -(z[0] * eye[0] + z[1] * eye[1] + z[2] * eye[2]), 1,
    ]);
  }

  function perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
  }

  function drawObject(model, projection, view) {
    gl.useProgram(program);
    gl.uniformMatrix4fv(uniforms.projection, false, projection);
    gl.uniformMatrix4fv(uniforms.view, false, view);
    for (const part of parts) {
      const modelPart = multiply(model, translation(part.x, 0, 0));
      gl.uniformMatrix4fv(uniforms.model, false, modelPart);
      gl.uniform3fv(uniforms.color, part.color);
      gl.bindBuffer(gl.ARRAY_BUFFER, part.mesh.buffer);
      gl.enableVertexAttribArray(attributes.position);
      gl.vertexAttribPointer(attributes.position, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, part.mesh.normalBuffer);
      gl.enableVertexAttribArray(attributes.normal);
      gl.vertexAttribPointer(attributes.normal, 3, gl.FLOAT, false, 0, 0);
      gl.drawArrays(gl.TRIANGLES, 0, part.mesh.count);
    }
  }

  let rotationX = -0.28, rotationY = 0.45, dragging = false, lastX = 0, lastY = 0, previousFrame = 0;
  let xrSession = null, xrReferenceSpace = null, hitTestSource = null, candidatePlacement = null, placedMatrix = null;
  let animationFrame = 0;
  const viewMatrix = lookAt([0, 0, 3.1], [0, 0, 0], [0, 1, 0]);

  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect(), ratio = Math.min(2, window.devicePixelRatio || 1);
    const width = Math.max(1, Math.round(rect.width * ratio)), height = Math.max(1, Math.round(rect.height * ratio));
    if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
  }

  function drawPreview(time) {
    animationFrame = window.requestAnimationFrame(drawPreview);
    if (xrSession || document.hidden) return;
    resizeCanvas();
    const delta = previousFrame ? Math.min(40, time - previousFrame) : 0;
    previousFrame = time;
    if (!reducedMotion && !dragging) rotationY += delta * 0.00022;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const projection = perspective(Math.PI / 4.1, canvas.width / canvas.height, 0.1, 100);
    const model = multiply(rotateY(rotationY), rotateX(rotationX));
    drawObject(model, projection, viewMatrix);
  }

  canvas.addEventListener('pointerdown', (event) => {
    dragging = true; lastX = event.clientX; lastY = event.clientY;
    canvas.setPointerCapture?.(event.pointerId);
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!dragging) return;
    rotationY += (event.clientX - lastX) * 0.012;
    rotationX = Math.max(-1.1, Math.min(1.1, rotationX + (event.clientY - lastY) * 0.01));
    lastX = event.clientX; lastY = event.clientY;
  });
  const stopDragging = () => { dragging = false; };
  canvas.addEventListener('pointerup', stopDragging);
  canvas.addEventListener('pointercancel', stopDragging);
  canvas.addEventListener('keydown', (event) => {
    const step = 0.14;
    if (event.key === 'ArrowLeft') rotationY -= step;
    else if (event.key === 'ArrowRight') rotationY += step;
    else if (event.key === 'ArrowUp') rotationX = Math.max(-1.1, rotationX - step);
    else if (event.key === 'ArrowDown') rotationX = Math.min(1.1, rotationX + step);
    else return;
    event.preventDefault();
  });
  window.addEventListener('resize', resizeCanvas, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !xrSession) previousFrame = 0;
  });
  animationFrame = window.requestAnimationFrame(drawPreview);

  async function refreshARSupport() {
    if (!arButton) return;
    if (!window.isSecureContext || !navigator.xr || typeof navigator.xr.isSessionSupported !== 'function') {
      arButton.disabled = true;
      arButton.textContent = 'AR needs a supported phone';
      status.textContent = '3D works here · AR needs HTTPS and an AR-capable browser';
      return;
    }
    try {
      const supported = await navigator.xr.isSessionSupported('immersive-ar');
      arButton.disabled = !supported;
      arButton.textContent = supported ? 'View in AR' : 'AR not supported here';
      status.textContent = supported ? 'Drag to rotate · place this model in AR' : 'Interactive 3D · AR is not available on this device';
    } catch (_) {
      arButton.disabled = true;
      arButton.textContent = 'AR not supported here';
      status.textContent = 'Interactive 3D · AR support could not be detected';
    }
  }

  async function startAR() {
    let session;
    try {
      arButton.disabled = true;
      status.textContent = 'Starting camera-based AR preview…';
      session = await navigator.xr.requestSession('immersive-ar', { requiredFeatures: ['hit-test'], optionalFeatures: ['local-floor'] });
      await gl.makeXRCompatible();
      const layer = new XRWebGLLayer(session, gl, { alpha: true, antialias: true });
      session.updateRenderState({ baseLayer: layer });
      xrReferenceSpace = await session.requestReferenceSpace('local');
      const viewerSpace = await session.requestReferenceSpace('viewer');
      hitTestSource = await session.requestHitTestSource({ space: viewerSpace });
      xrSession = session;
      candidatePlacement = null;
      placedMatrix = null;
      session.addEventListener('select', () => {
        if (candidatePlacement) {
          placedMatrix = new Float32Array(candidatePlacement);
          status.textContent = 'Model placed · move around to preview the scale';
        }
      });
      session.addEventListener('end', () => {
        xrSession = null; hitTestSource = null; xrReferenceSpace = null; candidatePlacement = null; placedMatrix = null;
        if (arButton) { arButton.textContent = 'View in AR'; arButton.disabled = false; }
        status.textContent = 'Drag to rotate · offline 3D preview';
      }, { once: true });
      arButton.textContent = 'Exit AR preview';
      arButton.disabled = false;
      status.textContent = 'Move your phone to find a surface, then tap to place';
      session.requestAnimationFrame(renderXRFrame);
    } catch (error) {
      if (session) {
        try { await session.end(); } catch (_) {}
      }
      xrSession = null;
      arButton.disabled = false;
      status.textContent = 'AR could not start. Check camera permission and device support.';
      console.warn('FitKlot AR preview:', error.message || error);
    }
  }

  function renderXRFrame(_time, frame) {
    const session = frame.session;
    if (!session || session !== xrSession) return;
    session.requestAnimationFrame(renderXRFrame);
    const viewerPose = frame.getViewerPose(xrReferenceSpace);
    if (!viewerPose) return;
    const hits = hitTestSource ? frame.getHitTestResults(hitTestSource) : [];
    const hitPose = hits.length ? hits[0].getPose(xrReferenceSpace) : null;
    if (!placedMatrix && hitPose) candidatePlacement = new Float32Array(hitPose.transform.matrix);
    gl.bindFramebuffer(gl.FRAMEBUFFER, session.renderState.baseLayer.framebuffer);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const placement = placedMatrix || candidatePlacement;
    for (const view of viewerPose.views) {
      const viewport = session.renderState.baseLayer.getViewport(view);
      gl.viewport(viewport.x, viewport.y, viewport.width, viewport.height);
      if (placement) {
        const lift = translation(0, 0.10, 0);
        const size = scaleMatrix(0.23, 0.23, 0.23);
        drawObject(multiply(multiply(placement, lift), size), view.projectionMatrix, view.transform.inverse.matrix);
      }
    }
  }

  if (arButton) arButton.addEventListener('click', () => {
    if (xrSession) xrSession.end();
    else if (!arButton.disabled) startAR();
  });
  refreshARSupport();

  function installScrollReveals() {
    const targets = document.querySelectorAll('.page .welcome, .page .card');
    if (!targets.length) return;
    if (!('IntersectionObserver' in window)) {
      targets.forEach((element) => element.classList.add('fx-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('fx-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -28px 0px' });
    targets.forEach((element, index) => {
      element.classList.add('fx-reveal');
      element.style.setProperty('--fx-delay', Math.min(index % 4, 3) * 60 + 'ms');
      observer.observe(element);
    });
  }
  installScrollReveals();
})();
