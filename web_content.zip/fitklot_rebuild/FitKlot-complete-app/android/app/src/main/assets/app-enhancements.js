/* FitKlot product modules layered onto the original local-first tracker. */
(() => {
  const extras = [
    ['dietplanner', '🥗', 'Meal plans'],
    ['analytics', '▤', 'Analytics'],
    ['reminders', '♧', 'Reminders'],
    ['photos', '▧', 'Progress photos'],
  ];
  const $ = (selector, root = document) => root.querySelector(selector);
  const id = () => crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const safe = (value) => typeof esc === 'function' ? esc(value) : String(value ?? '');
  const asNumber = (value) => Number(value) || 0;
  function getProfileAge(profile={}) {
    const savedAge=asNumber(profile.age);
    if(savedAge>0)return savedAge;
    if(!profile.birthDate)return 0;
    const born=new Date(String(profile.birthDate)+'T12:00:00'),now=new Date();
    if(!Number.isFinite(born.getTime())||born>now)return 0;
    return now.getFullYear()-born.getFullYear()-(now<new Date(now.getFullYear(),born.getMonth(),born.getDate())?1:0);
  }
  async function edgeErrorMessage(error, fallback) {
    try {
      const response=error?.context;
      const detail=await response?.clone?.().json();
      if(typeof detail?.error==='string'&&detail.error.trim())return detail.error;
    } catch {}
    return error?.message||fallback;
  }
  let reminderTimer = null;
  let loadedPhotoUid = null;
  let baseRenderAll = null;
  let baseRenderExercises = null;
  let baseRenderSession = null;

  function ensureState() {
    for (const key of ['savedMeals', 'weeklyPlans', 'groceryLists', 'savedRoutines', 'reminders', 'notifications']) {
      if (!Array.isArray(state[key])) state[key] = [];
    }
    state.notificationPrefs ||= { inApp: true, push: false, workouts: true, meals: true, water: true, weight: true, recovery: true };
  }

  function mountPage(pageId, title, eyebrow, description, body) {
    if ($(`#page-${pageId}`)) return;
    const root = $('.content');
    if (!root) return;
    const section = document.createElement('section');
    section.className = 'page';
    section.id = `page-${pageId}`;
    section.innerHTML = `<div class="welcome"><div><div class="eyebrow">${safe(eyebrow)}</div><h2>${safe(title)}<span class="accent">.</span></h2><p>${safe(description)}</p></div></div>${body}`;
    root.append(section);
  }

  function mountNewPages() {
    const nav = typeof NAV !== 'undefined' ? NAV : [];
    for (const item of extras) if (!nav.some(([page]) => page === item[0])) nav.push(item);

    mountPage('dietplanner', 'Weekly meal planner', 'PLAN YOUR FUEL', 'Build an editable plan and shopping list from clearly labelled food estimates.', `
      <div class="notice">Meal portions use the app’s generic reference estimates. Brands, recipes and cooking methods vary. Check package labels and adjust servings. The plan is a starting point, not medical nutrition advice.</div>
      <div class="grid two">
        <div class="card"><div class="card-head"><h3>Plan preferences</h3><span class="tag">EDITABLE</span></div>
          <div class="field"><label for="mealBudget">Food budget</label><select id="mealBudget"><option value="balanced">Balanced selection</option><option value="budget">Budget-friendly staples</option></select></div>
          <div class="field" style="margin-top:12px"><label for="mealCount">Meals per day</label><select id="mealCount"><option value="3">3 meals</option><option value="4" selected>3 meals + snack</option></select></div>
          <p class="smallnote" id="mealPlanTarget"></p><div class="actions"><button class="btn" id="generateMealPlan">Generate 7-day plan</button><button class="btn secondary" id="clearMealPlan">Clear plan</button></div>
        </div>
        <div class="card"><div class="card-head"><h3>Grocery list</h3><button class="chip" id="exportGroceries">Export list</button></div><div id="groceryList" class="list"><div class="empty">Generate a meal plan to build its grocery list.</div></div></div>
      </div>
      <div class="card" style="margin-top:15px"><div class="card-head"><h3>This week</h3><span class="tag" id="mealPlanStatus">NO PLAN YET</span></div><div id="weeklyMealPlan" class="meal-week"><div class="empty">Choose your preferences to create an editable week of meals.</div></div></div>`);

    mountPage('analytics', 'Progress analytics', 'LOOK AT THE TREND', 'Review recorded training, weigh-ins and nutrition without treating daily changes as outcomes.', `
      <div class="grid stats">
        <div class="card"><div class="muted">Training this week</div><div class="statnum" id="analyticWorkouts">—</div><div class="statfoot" id="analyticWorkoutNote"></div></div>
        <div class="card"><div class="muted">Weight trend</div><div class="statnum" id="analyticWeight">—</div><div class="statfoot">Based on available weigh-ins</div></div>
        <div class="card"><div class="muted">Logged nutrition days</div><div class="statnum" id="analyticNutritionDays">—</div><div class="statfoot">Days with at least one food entry</div></div>
        <div class="card"><div class="muted">Recorded volume this month</div><div class="statnum" id="analyticVolume">—</div><div class="statfoot">Completed sets × reps × logged load</div></div>
      </div>
      <div class="grid two" style="margin-top:15px"><div class="card"><div class="card-head"><h3>Workout frequency · 8 weeks</h3></div><div id="weeklyActivityChart" class="analytics-bars"></div></div><div class="card"><div class="card-head"><h3>Weight · 12 weeks</h3></div><div id="weeklyWeightChart" class="analytics-bars"></div><p class="smallnote">A rolling average helps smooth ordinary day-to-day variation. It does not predict when you will reach a goal.</p></div><div class="card"><div class="card-head"><h3>Daily calories · 14 days</h3></div><div id="dailyNutritionChart" class="analytics-bars"></div><p class="smallnote">Bars use diary entries. Days without food logs are shown as empty, not zero-calorie days.</p></div></div>
      <div class="card" style="margin-top:15px"><div class="card-head"><h3>Monthly summary</h3></div><div id="monthlySummary" class="list"><div class="empty">Log workouts, meals and weigh-ins to see a summary.</div></div></div>`);

    mountPage('reminders', 'Reminders & notifications', 'YOUR SCHEDULE, YOUR CHOICE', 'Set optional local reminders for workouts, meals, hydration and check-ins.', `
      <div class="notice">In-app reminders run while FitKlot is open in this browser. Browser notifications require permission and may not arrive when the browser is closed. Push notifications are not configured.</div>
      <div class="grid two"><div class="card"><div class="card-head"><h3>Add a reminder</h3></div>
        <form id="reminderForm"><div class="formgrid"><div class="field"><label for="reminderType">Reminder type</label><select id="reminderType"><option value="workout">Workout</option><option value="meal">Meal</option><option value="water">Hydration</option><option value="weight">Weight check-in</option><option value="recovery">Sleep / recovery</option><option value="general">Other</option></select></div>
        <div class="field"><label for="reminderTime">Time</label><input id="reminderTime" type="time" value="09:00" required></div><div class="field full"><label for="reminderLabel">Reminder</label><input id="reminderLabel" maxlength="90" placeholder="e.g. Take a water break" required></div></div>
        <div class="field" style="margin-top:10px"><label><input id="reminderDaily" type="checkbox" checked> Repeat every day</label></div><button class="btn" style="margin-top:12px">Save reminder</button></form>
        <div class="actions"><button class="btn secondary" id="requestNotifications">Allow browser notifications</button></div><p id="notificationPermission" class="smallnote" aria-live="polite"></p>
      </div><div class="card"><div class="card-head"><h3>Reminder settings</h3></div><div id="notificationSettings" class="list"></div><div class="card-head" style="margin-top:18px"><h3>Upcoming reminders</h3></div><div id="reminderList" class="list"></div></div></div>
      <div class="card" style="margin-top:15px"><div class="card-head"><h3>In-app notifications</h3><button class="chip" id="clearNotifications">Clear read</button></div><div id="notificationList" class="list"></div></div>`);

    mountPage('photos', 'Progress photos', 'PRIVATE BY DEFAULT', 'Keep progress photos in your private Supabase Storage bucket when configured.', `
      <div class="notice">Photos are private records. This feature requires a signed-in account and a private Supabase Storage bucket named <code>progress-photos</code>. Only the owner’s signed-in session can create short-lived viewing links. Photos are not sent to the AI coach.</div>
      <div class="grid two"><div class="card"><div class="card-head"><h3>Add a photo</h3><span class="tag">PRIVATE STORAGE</span></div>
        <form id="progressPhotoForm"><div class="field"><label for="progressPhotoFile">Choose a photo (JPEG, PNG or WebP; up to 10 MB)</label><input id="progressPhotoFile" type="file" accept="image/jpeg,image/png,image/webp" required></div><div class="field" style="margin-top:12px"><label for="progressPhotoCaption">Caption (optional)</label><input id="progressPhotoCaption" maxlength="100" placeholder="e.g. Front · relaxed"></div><div class="field" style="margin-top:12px"><label for="progressPhotoDate">Photo date</label><input id="progressPhotoDate" type="date" required></div><button class="btn" style="margin-top:12px">Upload privately</button><p id="progressPhotoStatus" class="smallnote" aria-live="polite"></p></form>
      </div><div class="card"><div class="card-head"><h3>Your photos</h3><button class="chip" id="refreshProgressPhotos">Refresh</button></div><div id="progressPhotoGrid" class="photo-grid"><div class="empty">Sign in and configure private storage to use this feature.</div></div></div></div>`);

    if (typeof buildNav === 'function') buildNav();
  }

  function addProfileFields() {
    const form = $('#profileForm');
    const grid = form?.querySelector('.formgrid');
    if (!grid || $('#pUnits')) return;
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <div class="field"><label for="pUnits">Units</label><select id="pUnits"><option value="metric">Metric (kg / cm)</option><option value="imperial">Imperial (lb / in)</option></select></div>
      <div class="field"><label for="pBirthDate">Date of birth (optional)</label><input id="pBirthDate" type="date"></div>
      <div class="field"><label for="pBodyFat">Body-fat percentage (optional, entered by you)</label><input id="pBodyFat" type="number" min="2" max="70" step="0.1" placeholder="Only if known from a suitable method"></div>
      <div class="field"><label for="pFocus">Muscle groups to prioritize</label><input id="pFocus" maxlength="120" placeholder="e.g. back, shoulders"></div>
      <div class="field"><label for="pInjuries">Injuries or movement limits (optional)</label><input id="pInjuries" maxlength="240" placeholder="Optional context for your coach"></div>
      <div class="field full"><label for="pAvoidExercises">Exercises or movements to avoid</label><input id="pAvoidExercises" maxlength="240" placeholder="e.g. squat, overhead press; separate items with commas"></div>`;
    grid.append(...Array.from(wrapper.children));
    const units = $('#pUnits');
    units.value = state.profile.units || 'metric';
    units.addEventListener('change', changeDisplayedUnits);
    setDisplayedUnits(units.value, units.value === 'imperial');
    $('#pBirthDate').value = state.profile.birthDate || '';
    $('#pBodyFat').value = state.profile.bodyFat || '';
    $('#pFocus').value = state.profile.focus || '';
    $('#pInjuries').value = state.profile.injuries || '';
    $('#pAvoidExercises').value = state.profile.avoidExercises || '';
    form.addEventListener('submit', onProfileSubmit, true);
    const baseFillProfileForm = window.fillProfileForm;
    if (baseFillProfileForm && !window.__fitklotProfileFillWrapped) {
      window.fillProfileForm = function(...args) {
        displayUnits = 'metric';
        baseFillProfileForm.apply(this, args);
        $('#pUnits').value = state.profile.units || 'metric';
        $('#pBirthDate').value = state.profile.birthDate || '';
        $('#pBodyFat').value = state.profile.bodyFat || '';
        $('#pFocus').value = state.profile.focus || '';
        $('#pInjuries').value = state.profile.injuries || '';
        $('#pAvoidExercises').value = state.profile.avoidExercises || '';
        setDisplayedUnits($('#pUnits').value, $('#pUnits').value === 'imperial');
        updateProfileSafetyNotice();
      };
      window.__fitklotProfileFillWrapped = true;
    }
  }

  let displayUnits = 'metric';
  function setDisplayedUnits(units, convertCurrent) {
    const height = $('#pHeight'), weight = $('#pWeight'), target = $('#pTarget');
    if (!height || !weight || !target) return;
    if (convertCurrent && units !== displayUnits) {
      if (units === 'imperial') {
        if (height.value) height.value = (asNumber(height.value) / 2.54).toFixed(1);
        if (weight.value) weight.value = (asNumber(weight.value) / 0.45359237).toFixed(1);
        if (target.value) target.value = (asNumber(target.value) / 0.45359237).toFixed(1);
      } else {
        if (height.value) height.value = (asNumber(height.value) * 2.54).toFixed(1);
        if (weight.value) weight.value = (asNumber(weight.value) * 0.45359237).toFixed(1);
        if (target.value) target.value = (asNumber(target.value) * 0.45359237).toFixed(1);
      }
    }
    displayUnits = units;
    const unitLabel = units === 'imperial' ? 'in' : 'cm';
    const weightLabel = units === 'imperial' ? 'lb' : 'kg';
    $('#pHeight').labels[0].textContent = `Height (${unitLabel})`;
    $('#pWeight').labels[0].textContent = `Current weight (${weightLabel})`;
    $('#pTarget').labels[0].textContent = `Target weight (${weightLabel})`;
    height.min = units === 'imperial' ? '31.5' : '80'; height.max = units === 'imperial' ? '98.5' : '250';
    weight.min = target.min = units === 'imperial' ? '55' : '25';
    weight.max = target.max = units === 'imperial' ? '882' : '400';
    const w = $('#wValue');
    if (w) w.labels[0].textContent = `Weight (${weightLabel})`;
    for (const key of ['mWaist','mChest','mArm','mThigh','mHips']) {
      const input = $(`#${key}`);
      if (input?.labels?.[0]) input.labels[0].textContent = `${({mWaist:'Waist',mChest:'Chest',mArm:'Arm',mThigh:'Thigh',mHips:'Hips'})[key]} (${units === 'imperial' ? 'in' : 'cm'})`;
      if (input) {
        input.dataset.metricMin ||= String(Number(input.min) || 0);
        input.dataset.metricMax ||= String(Number(input.max) || 250);
        input.min = units === 'imperial' ? String((Number(input.dataset.metricMin) / 2.54).toFixed(1)) : input.dataset.metricMin;
        input.max = units === 'imperial' ? String((Number(input.dataset.metricMax) / 2.54).toFixed(1)) : input.dataset.metricMax;
      }
    }
  }

  function changeDisplayedUnits(event) { setDisplayedUnits(event.target.value, true); }

  function onProfileSubmit(event) {
    event.preventDefault();
    event.stopImmediatePropagation();
    const units = $('#pUnits').value;
    const height = asNumber($('#pHeight').value) * (units === 'imperial' ? 2.54 : 1);
    const weight = asNumber($('#pWeight').value) * (units === 'imperial' ? 0.45359237 : 1);
    const target = asNumber($('#pTarget').value) * (units === 'imperial' ? 0.45359237 : 1);
    if (height && (height < 80 || height > 250) || weight && (weight < 25 || weight > 400) || target && (target < 25 || target > 400)) {
      toast('Check your height and weight values.'); return;
    }
    const birthDate = $('#pBirthDate').value;
    let age = $('#pAge').value;
    if (birthDate) {
      const born = new Date(`${birthDate}T12:00:00`), now = new Date();
      age = String(now.getFullYear() - born.getFullYear() - (now < new Date(now.getFullYear(), born.getMonth(), born.getDate()) ? 1 : 0));
    }
    state.profile = {
      name: $('#pName').value.trim(), age, sex: $('#pSex').value,
      height: height ? height.toFixed(1) : '', weight: weight ? weight.toFixed(1) : '', target: target ? target.toFixed(1) : '',
      goal: $('#pGoal').value, level: $('#pLevel').value, days: $('#pDays').value, minutes: $('#pMinutes').value,
      equipment: $('#pEquipment').value, diet: $('#pDiet').value, activity: $('#pActivity').value, sleep: $('#pSleep').value,
      calories: $('#pCalories').value, protein: $('#pProtein').value, avoid: $('#pAvoid').value,
      units, birthDate, bodyFat: $('#pBodyFat').value, focus: $('#pFocus').value.trim(), injuries: $('#pInjuries').value.trim(), avoidExercises: $('#pAvoidExercises').value.trim(),split:state.profile.split||split,
    };
    updateProfileSafetyNotice();
    save();
    toast('Fitness profile saved');
  }

  function migrateMeasurementValues() {
    for (const entry of state.measurements || []) {
      if (entry.values) {
        entry.waist ??= entry.values.waist;
        entry.chest ??= entry.values.chest;
        entry.arm ??= entry.values.arm;
        entry.thigh ??= entry.values.thigh;
      }
    }
  }

  function installUnitAwareForms() {
    const weightForm = $('#weightForm');
    if(weightForm&&!$('#wTime')){const field=document.createElement('div');field.className='field';field.innerHTML='<label for="wTime">Time</label><input id="wTime" type="time" required>';weightForm.querySelector('.formgrid')?.append(field);$('#wTime').value=`${String(new Date().getHours()).padStart(2,'0')}:${String(new Date().getMinutes()).padStart(2,'0')}`;}
    weightForm?.addEventListener('submit', (event) => {
      event.preventDefault(); event.stopImmediatePropagation();
      const units = state.profile.units || 'metric';
      const value = asNumber($('#wValue').value) * (units === 'imperial' ? 0.45359237 : 1);
      const date = $('#wDate').value,time=$('#wTime')?.value;
      if (value < 25 || value > 400 || !date||!time) { toast('Check weight, date and time'); return; }
      state.weights.push({ id: id(), kg: Number(value.toFixed(2)), date,time });
      state.profile.weight = String(Number(value.toFixed(2)));
      save(); toast('Weight saved');
    }, true);
    const measureForm = $('#measureForm');
    measureForm?.addEventListener('submit', (event) => {
      event.preventDefault(); event.stopImmediatePropagation();
      const factor = state.profile.units === 'imperial' ? 2.54 : 1;
      const values = Object.fromEntries(['waist','chest','arm','thigh','hips'].map((key) => {
        const input = $(`#m${key[0].toUpperCase()}${key.slice(1)}`);
        return [key, input.value ? Number((asNumber(input.value) * factor).toFixed(1)) : ''];
      }));
      if (!Object.values(values).some(Boolean)) { toast('Enter at least one measurement'); return; }
      state.measurements.push({ id: id(), date: today(), values });
      save(); toast('Measurements saved');
    }, true);
  }

  function foodItems() { return typeof FOODS !== 'undefined' ? FOODS : []; }
  function dietAllowed(foodName, profile) {
    const name = foodName.toLowerCase();
    const diet = String(profile.diet || '').toLowerCase();
    if ((diet.includes('vegan')) && /egg|milk|curd|yogurt|paneer|chicken|salmon|fish|whey|butter/.test(name)) return false;
    if (diet.includes('vegetarian') && !diet.includes('eggetarian') && /chicken|salmon|fish|meat/.test(name)) return false;
    if (diet.includes('eggetarian') && /chicken|salmon|fish|meat/.test(name)) return false;
    const avoid = String(profile.avoid || '').toLowerCase().split(/[,;]+/).map((x) => x.trim()).filter(Boolean);
    if (avoid.some((word) => word.length > 2 && name.includes(word))) return false;
    const allergyGroups=[[/milk|dairy|lactose/,/milk|curd|yogurt|paneer|whey|butter/],[/peanut/,/peanut/],[/egg/,/egg/],[/fish|seafood/,/fish|salmon/],[/chicken|poultry/,/chicken/]];
    if(allergyGroups.some(([trigger,foods])=>avoid.some((word)=>trigger.test(word))&&foods.test(name)))return false;
    return true;
  }

  function pickFood(pattern, available, fallbackPattern = /dal|tofu|rice|banana/i) {
    return available.find((food) => pattern.test(food[0])) || available.find((food) => fallbackPattern.test(food[0])) || available[0];
  }

  function foodPortion(food, grams) {
    return { name: food[0], qty: grams, kcal: food[1] * grams / 100, protein: food[2] * grams / 100,
      carbs: food[3] * grams / 100, fat: food[4] * grams / 100, fiber: null };
  }

  function mealTotals(items) {
    return items.reduce((sum, item) => ({ kcal: sum.kcal + item.kcal, protein: sum.protein + item.protein,
      carbs: sum.carbs + item.carbs, fat: sum.fat + item.fat }), { kcal: 0, protein: 0, carbs: 0, fat: 0 });
  }

  function buildMealDay(dayIndex, available, budget, mealsPerDay) {
    const item = (regex, grams) => foodPortion(pickFood(regex, available), grams);
    const breakfast = [item(/oats/i, budget ? 50 : 60), item(/banana|apple/i, 100)];
    const dairyOrEgg = available.find((f) => /egg|greek yogurt|curd|milk|tofu/i.test(f[0]));
    if (dairyOrEgg) breakfast.push(foodPortion(dairyOrEgg, /egg|tofu/i.test(dairyOrEgg[0]) ? 100 : 150));
    const lunchProteinPattern = dayIndex % 3 === 0 ? /chicken|tofu|paneer|dal|rajma/i : dayIndex % 3 === 1 ? /dal|chickpeas|tofu|paneer|chicken/i : /rajma|egg|tofu|dal|chicken/i;
    const lunch = [item(/rice/i, 170), item(lunchProteinPattern, 150), item(/broccoli|potato/i, 100)];
    const dinner = [item(/roti/i, budget ? 60 : 70), item(/tofu|paneer|chicken|salmon|dal|rajma/i, 150), item(/broccoli|potato/i, 100)];
    const snack = [item(dayIndex % 2 ? /apple|banana/i : /curd|greek yogurt|chickpeas|almonds/i, 100)];
    const result = [{ name: 'Breakfast', items: breakfast }, { name: 'Lunch', items: lunch }, { name: 'Dinner', items: dinner }];
    if (mealsPerDay === 4) result.splice(2, 0, { name: 'Snack', items: snack });
    return result;
  }

  function mondayOfWeek(date = new Date()) {
    const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const day = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - day);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function generateMealPlan() {
    const profile = state.profile || {};
    const available = foodItems().filter((food) => dietAllowed(food[0], profile));
    if (!available.length) { toast('No reference foods match these restrictions. Adjust the food restrictions first.'); return; }
    const target = targets().cal || 0;
    const age=getProfileAge(profile);
    if (age > 0 && age < 18 && Number(profile.calories) > 0) {
      toast('Calorie-specific meal planning is unavailable for users under 18. Ask a qualified pediatric health professional to set any target.'); return;
    }
    if (Number(profile.calories) > 0 && Number(profile.calories) < 1200) {
      toast('That calorie target may be unsafe. Review it with a qualified health professional before planning.'); return;
    }
    const budget = $('#mealBudget').value === 'budget';
    const mealsPerDay = Number($('#mealCount').value) || 4;
    const weekStart = mondayOfWeek();
    const days = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(`${weekStart}T12:00:00`); date.setDate(date.getDate() + i);
      let meals = buildMealDay(i, available, budget, mealsPerDay);
      const currentKcal = meals.reduce((sum, meal) => sum + mealTotals(meal.items).kcal, 0);
      const factor = target && currentKcal > 0 ? Math.max(0.75, Math.min(1.25, target / currentKcal)) : 1;
      meals = meals.map((meal) => ({ ...meal, items: meal.items.map((food) => foodPortion(foodItems().find((f) => f[0] === food.name), Math.max(10, Math.round(food.qty * factor)))) }));
      days.push({ date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`, meals });
    }
    const groceryMap = new Map();
    for (const day of days) for (const meal of day.meals) for (const food of meal.items) {
      groceryMap.set(food.name, (groceryMap.get(food.name) || 0) + food.qty);
    }
    const groceries = [...groceryMap].map(([name, amount]) => ({ name, amount: Math.round(amount), unit: 'g', checked: false }));
    state.weeklyPlans.unshift({ id: id(), weekStart, title: budget ? 'Budget-friendly week' : 'Balanced week', days, groceries });
    state.weeklyPlans = state.weeklyPlans.slice(0, 8);
    save(); toast('A seven-day editable meal plan is ready');
  }

  function logPlannedMeal(dayIndex, mealIndex) {
    const plan = state.weeklyPlans[0], day = plan?.days?.[dayIndex], meal = day?.meals?.[mealIndex];
    if (!meal) return;
    for (const food of meal.items) state.foods.push({ id: id(), date: today(), name: food.name, qty: food.qty, meal: meal.name,
      kcal: food.kcal, protein: food.protein, carbs: food.carbs, fat: food.fat, fiber: food.fiber,
      source: food.source || 'FitKlot generic reference estimate', sourceId: food.sourceId || null });
    save(); go('nutrition'); toast(`${meal.name} logged with estimated nutrition`);
  }

  function updatePlannedPortion(dayIndex,mealIndex,itemIndex,grams) {
    const plan=state.weeklyPlans?.[0],item=plan?.days?.[dayIndex]?.meals?.[mealIndex]?.items?.[itemIndex],food=foodItems().find((entry)=>entry[0]===item?.name);
    const amount=Number(grams);if(!plan||!item||!food||!Number.isFinite(amount)||amount<10||amount>3000){toast('Serving must be between 10 and 3,000 grams.');renderDietPlan();return;}
    Object.assign(item,foodPortion(food,amount));
    const totalsByFood=new Map();for(const day of plan.days)for(const meal of day.meals)for(const entry of meal.items)totalsByFood.set(entry.name,(totalsByFood.get(entry.name)||0)+entry.qty);
    plan.groceries=[...totalsByFood].map(([name,total])=>({name,amount:Math.round(total),unit:'g',checked:plan.groceries.find((entry)=>entry.name===name)?.checked||false}));
    save();
  }

  function toggleGrocery(index, checked) {
    const plan = state.weeklyPlans[0], item = plan?.groceries?.[index];
    if (!item) return;
    item.checked = checked; save();
  }

  function renderDietPlan() {
    const target = $('#mealPlanTarget');
    if (target) target.textContent = targets().cal ? `Daily target: about ${fmt(targets().cal)} kcal · ${targets().protein ? fmt(targets().protein) + ' g protein' : 'protein target not set'} · Uses your saved profile.` : 'Add an age, height, weight, activity level and optional sex selection or set a calorie target in your profile. Without a target, portions remain generic estimates.';
    const plan = state.weeklyPlans?.[0];
    const status = $('#mealPlanStatus'), root = $('#weeklyMealPlan'), groceries = $('#groceryList');
    if (!root || !groceries) return;
    if (!plan) { if (status) status.textContent = 'NO PLAN YET'; root.innerHTML = '<div class="empty">Choose your preferences to create an editable week of meals.</div>'; groceries.innerHTML = '<div class="empty">Generate a meal plan to build its grocery list.</div>'; return; }
    if (status) status.textContent = `${plan.title.toUpperCase()} · WEEK OF ${plan.weekStart}`;
    root.innerHTML = plan.days.map((day, i) => `<article class="meal-day"><div class="card-head"><h3>${new Date(`${day.date}T12:00:00`).toLocaleDateString(undefined,{weekday:'long',month:'short',day:'numeric'})}</h3><span class="tag">${fmt(day.meals.reduce((a,m)=>a+mealTotals(m.items).kcal,0))} EST. KCAL</span></div>${day.meals.map((meal,j) => `<div class="planned-meal"><b>${safe(meal.name)}</b><div class="planned-items">${meal.items.map((f,k)=>`<label class="portion-row"><span>${safe(f.name)}</span><input type="number" min="10" max="3000" step="10" value="${Math.round(f.qty)}" data-plan-portion data-day="${i}" data-meal="${j}" data-item="${k}" aria-label="${safe(f.name)} serving in grams"><small>g</small></label>`).join('')}</div><small>${fmt(mealTotals(meal.items).kcal)} kcal est. · P ${mealTotals(meal.items).protein.toFixed(1)} g</small><button class="chip" data-action="log-planned-meal" data-day="${i}" data-meal="${j}">Log meal today</button></div>`).join('')}</article>`).join('');
    groceries.innerHTML = plan.groceries.length ? plan.groceries.map((item,i) => `<label class="listitem grocery-item"><input type="checkbox" data-grocery="${i}" ${item.checked?'checked':''}><span class="grow">${safe(item.name)} <small>${fmt(item.amount)} ${safe(item.unit)}</small></span></label>`).join('') : '<div class="empty">No grocery items in this plan.</div>';
  }

  function saveTodaysMealTemplate() {
    const items = state.foods.filter((food) => food.date === today()).map((food) => ({ name: food.name, qty: food.qty, kcal: food.kcal, protein: food.protein, carbs: food.carbs, fat: food.fat, fiber: food.fiber, source: food.source, sourceId: food.sourceId }));
    if (!items.length) { toast('Log at least one food before saving a meal template.'); return; }
    state.savedMeals.unshift({ id: id(), name: `Saved meal · ${today()}`, meal: 'Meal', items });
    save(); toast('Meal template saved');
  }

  function applyMealTemplate(templateId) {
    const template = state.savedMeals.find((meal) => meal.id === templateId);
    if (!template) return;
    for (const item of template.items || []) state.foods.push({ id: id(), date: today(), meal: template.meal || 'Meal', ...item });
    save(); toast('Saved meal added to today’s diary');
  }

  function renderMealTemplates() {
    let root = $('#savedMealTemplates');
    if (!root) {
      const diary = $('#foodDiary')?.closest('.card');
      if (!diary) return;
      root = document.createElement('div'); root.id = 'savedMealTemplates'; root.className = 'saved-templates'; diary.append(root);
    }
    root.innerHTML = `<div class="card-head"><h3>Saved meals</h3><button class="chip" data-action="save-meal-template">Save today as a meal</button></div>${state.savedMeals.length ? state.savedMeals.slice(0,8).map((item)=>`<div class="listitem"><div class="grow"><b>${safe(item.name)}</b><small>${(item.items||[]).length} food items · estimates</small></div><button class="chip" data-action="apply-meal-template" data-id="${safe(item.id)}">Add today</button><button class="chip" data-action="delete-meal-template" data-id="${safe(item.id)}" aria-label="Delete saved meal">×</button></div>`).join('') : '<div class="empty">Save a meal template to repeat it later.</div>'}`;
  }

  function weekStartDate(daysBack) { const d = new Date(); d.setDate(d.getDate() - daysBack); const offset = (d.getDay() + 6) % 7; d.setDate(d.getDate() - offset); return d; }
  function fmtDate(date) { return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; }
  function renderAnalytics() {
    if (!$('#weeklyActivityChart')) return;
    const sessions = state.sessions || [], weights = (state.weights || []).slice().sort((a,b)=>a.date.localeCompare(b.date));
    const now = new Date(), currentWeek = new Date(now); currentWeek.setDate(now.getDate() - ((now.getDay()+6)%7));
    const cutoff = new Date(currentWeek); cutoff.setDate(cutoff.getDate()-49);
    const weekly = Array.from({length:8},(_,i)=>{const start=new Date(cutoff);start.setDate(start.getDate()+i*7);const end=new Date(start);end.setDate(end.getDate()+7);return {label:start.toLocaleDateString(undefined,{month:'short',day:'numeric'}),count:sessions.filter(s=>{const d=new Date(`${s.date}T12:00:00`);return d>=start&&d<end}).length}});
    const lastWeight = weights.at(-1), firstWeight = weights.find((x)=>new Date(`${x.date}T12:00:00`)>=new Date(now.getFullYear(),now.getMonth(),now.getDate()-83));
    const weeklyCounts = weekly.map((w)=>w.count), maxCount = Math.max(1,...weeklyCounts);
    $('#weeklyActivityChart').innerHTML = weekly.map((w)=>`<div class="analytics-bar-col"><div class="analytics-bar" style="height:${Math.max(4,w.count/maxCount*100)}%" title="${w.count} workouts"></div><small>${safe(w.label)}</small></div>`).join('');
    const weightBuckets = [];
    for (let i=0;i<12;i++) { const start = new Date(now); start.setDate(start.getDate()-(11-i)*7); const end = new Date(start); end.setDate(end.getDate()+7); const values = weights.filter((x)=>{const d=new Date(`${x.date}T12:00:00`);return d>=start&&d<end}).map((x)=>asNumber(x.kg)); weightBuckets.push({label:start.toLocaleDateString(undefined,{month:'short',day:'numeric'}),value:values.length?values.reduce((a,b)=>a+b,0)/values.length:null}); }
    const vals = weightBuckets.map((x)=>x.value).filter((x)=>x!==null), min=Math.min(...vals),max=Math.max(...vals),range=max-min;
    $('#weeklyWeightChart').innerHTML = vals.length ? weightBuckets.map((w)=>`<div class="analytics-bar-col"><div class="analytics-bar purple" style="height:${w.value===null?3:range?25+(w.value-min)/range*70:55}%" title="${w.value===null?'No weigh-in':w.value.toFixed(1)+' kg weekly average'}"></div><small>${safe(w.label)}</small></div>`).join('') : '<div class="empty">No weigh-ins yet. Add a few over time to see a trend.</div>';
    const nutritionDays=Array.from({length:14},(_,i)=>{const d=new Date(now);d.setDate(now.getDate()-(13-i));const key=fmtDate(d),entries=(state.foods||[]).filter((item)=>item.date===key);return {key,label:d.toLocaleDateString(undefined,{weekday:'short'}),kcal:entries.reduce((sum,item)=>sum+asNumber(item.kcal),0),logged:entries.length>0};});
    const maxKcal=Math.max(1,...nutritionDays.filter((day)=>day.logged).map((day)=>day.kcal));
    $('#dailyNutritionChart').innerHTML=nutritionDays.some((day)=>day.logged)?nutritionDays.map((day)=>`<div class="analytics-bar-col"><div class="analytics-bar orange" style="height:${day.logged?Math.max(4,day.kcal/maxKcal*100):3}%" title="${day.logged?`${fmt(day.kcal)} kcal logged · ${day.key}`:`No food log · ${day.key}`}" aria-label="${day.logged?`${fmt(day.kcal)} calories logged`:'No food logged'}"></div><small>${safe(day.label)}</small></div>`).join(''):'<div class="empty">No food entries yet. Log meals to build this history.</div>';
    const thisMonday=fmtDate(currentWeek), thisSunday=new Date(currentWeek);thisSunday.setDate(thisSunday.getDate()+7);
    const weekSessions=sessions.filter((s)=>s.date>=thisMonday&&s.date<fmtDate(thisSunday)).length;
    $('#analyticWorkouts').textContent=String(weekSessions);$('#analyticWorkoutNote').textContent=`${state.profile.days||'—'} planned days per week`;
    $('#analyticWeight').textContent=lastWeight?`${lastWeight.kg} kg`: '—';
    const loggedDays=new Set((state.foods||[]).map((x)=>x.date)).size;$('#analyticNutritionDays').textContent=String(loggedDays);
    const monthPrefix=fmtDate(new Date(now.getFullYear(),now.getMonth(),1)).slice(0,7);
    const monthSets=sessions.filter((s)=>String(s.date||'').startsWith(monthPrefix)).flatMap((s)=>s.sets||[]);
    const volume=monthSets.filter((s)=>s.done||s.kg||s.reps).reduce((a,s)=>a+asNumber(s.kg)*asNumber(s.reps),0);
    $('#analyticVolume').textContent=`${fmt(volume)} kg`;
    const monthSessions=sessions.filter((s)=>String(s.date||'').startsWith(monthPrefix)).length;
    const target=targets().cal, daysWithTarget=target?(state.foods||[]).filter((f)=>String(f.date||'').startsWith(monthPrefix)).map((f)=>f.date):[];
    const distinctDays=[...new Set(daysWithTarget)];
    const inside=distinctDays.filter((date)=>{const kcal=(state.foods||[]).filter((f)=>f.date===date).reduce((sum,f)=>sum+asNumber(f.kcal),0);return Math.abs(kcal-target)<=target*.1}).length;
    $('#monthlySummary').innerHTML=`<div class="listitem"><div class="grow"><b>${monthSessions} completed workouts this month</b><small>Counts only sessions saved in your history.</small></div></div><div class="listitem"><div class="grow"><b>${monthSets.length} sets with logged performance</b><small>Training volume is sum of recorded sets × reps × load; body-weight movements without load may be undercounted.</small></div></div><div class="listitem"><div class="grow"><b>${distinctDays.length?`${inside} of ${distinctDays.length} logged food days within ±10% of your target`:'No calorie target or food days to summarize'}</b><small>Adherence is a rough diary comparison and does not measure diet quality.</small></div></div>${firstWeight&&lastWeight?`<div class="listitem"><div class="grow"><b>${weights.length} weigh-ins recorded</b><small>Latest recorded weight changed ${(lastWeight.kg-firstWeight.kg>0?'+':'')+(lastWeight.kg-firstWeight.kg).toFixed(1)} kg from the first entry in this view. No goal date is predicted.</small></div></div>`:'<div class="empty">Log multiple weigh-ins to compare a longer trend.</div>'}`;
  }

  function notification(idValue, title, body, type) {
    state.notifications.unshift({ id: id(), sourceId: idValue, title, body, type, createdAt: new Date().toISOString(), readAt: null });
    state.notifications = state.notifications.slice(0,100);
    if (state.notificationPrefs?.inApp !== false) {
      const status = $('#notificationPermission'); if (status) status.textContent = `${title}: ${body}`;
      if (typeof toast === 'function') toast(title);
    }
    save();
  }

  function renderReminders() {
    const list = $('#reminderList'); if (!list) return;
    const prefs = state.notificationPrefs || {};
    const options = [['inApp','In-app reminders'],['push','Browser notifications'],['workouts','Workout reminders'],['meals','Meal reminders'],['water','Hydration reminders'],['weight','Weigh-in reminders'],['recovery','Sleep and recovery reminders']];
    $('#notificationSettings').innerHTML = options.map(([key,label])=>`<label class="listitem"><span class="grow">${safe(label)}</span><input type="checkbox" data-pref="${key}" ${prefs[key]?'checked':''}></label>`).join('');
    list.innerHTML = state.reminders.length ? state.reminders.map((item,index)=>`<div class="listitem"><div class="grow"><b>${safe(item.label)}</b><small>${safe(item.type)} · ${safe(item.time)} · ${item.enabled?'enabled':'paused'}</small></div><button class="chip" data-action="toggle-reminder" data-index="${index}">${item.enabled?'Pause':'Resume'}</button><button class="chip" data-action="delete-reminder" data-index="${index}" aria-label="Delete reminder">×</button></div>`).join('') : '<div class="empty">No reminders set. Add one if it would help your routine.</div>';
    const notes = $('#notificationList');
    if (notes) notes.innerHTML = state.notifications.length ? state.notifications.slice(0,30).map((item,index)=>`<div class="listitem"><div class="grow"><b>${safe(item.title)}</b><small>${safe(item.body)} · ${new Date(item.createdAt).toLocaleString()}</small></div>${item.readAt?'':'<button class="chip" data-action="read-notification" data-index="'+index+'">Mark read</button>'}</div>`).join('') : '<div class="empty">No in-app notifications yet.</div>';
  }

  function runReminderChecks() {
    if (!Array.isArray(state.reminders)) return;
    const now = new Date(), hhmm = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`, day = now.getDay();
    state.reminders.forEach((item) => {
      const preference={workout:'workouts',meal:'meals',water:'water',weight:'weight',recovery:'recovery'}[item.type];
      if (!item.enabled || preference&&state.notificationPrefs?.[preference]===false || item.time !== hhmm || (Array.isArray(item.days) && !item.days.includes(day))) return;
      const marker = `fitklot.reminder.${item.id}.${today()}.${hhmm}`;
      if (sessionStorage.getItem(marker)) return;
      sessionStorage.setItem(marker,'1');
      notification(marker,item.label,'Your scheduled reminder is due.',item.type);
      if (state.notificationPrefs?.push && window.Notification?.permission === 'granted') new Notification(item.label,{body:'Your scheduled FitKlot reminder is due.'});
    });
  }

  function renderPhotos() {
    const root = $('#progressPhotoGrid'); if (!root) return;
    if (!supa || !sessionUid) { loadedPhotoUid=null;root.innerHTML='<div class="empty">Sign in to store progress photos privately. Offline guests cannot upload photos.</div>'; return; }
    if(loadedPhotoUid===sessionUid)return;
    root.innerHTML='<div class="empty">Use Refresh to load your private photos.</div>';
  }

  async function loadPhotos() {
    const root=$('#progressPhotoGrid'); if(!root)return;
    if(!supa||!sessionUid){root.innerHTML='<div class="empty">Sign in to store progress photos privately.</div>';return;}
    root.innerHTML='<div class="empty">Loading your private photos…</div>';
    let data,error;
    try{({data,error}=await supa.from('progress_photos').select('id,storage_path,caption,taken_at').eq('user_id',sessionUid).order('taken_at',{ascending:false}));}
    catch(err){root.innerHTML=`<div class="empty">Could not load private photos. ${safe(err.message||'Check your connection.')}</div>`;return;}
    if(error){root.innerHTML=`<div class="empty">Photo storage is not configured yet. ${safe(error.message)}</div>`;return;}
    if(!data?.length){root.innerHTML='<div class="empty">No photos saved. Uploaded photos remain in your private account bucket.</div>';return;}
    const signed=await Promise.all(data.map(async (photo)=>{try{const result=await supa.storage.from('progress-photos').createSignedUrl(photo.storage_path,300);return {...photo,url:result.data?.signedUrl,error:result.error};}catch(error){return {...photo,url:null,error};}}));
    loadedPhotoUid=sessionUid;
    root.innerHTML=signed.map((photo)=>`<article class="photo-item">${photo.url?`<img src="${safe(photo.url)}" alt="Private progress photo, ${safe(photo.taken_at)}" loading="lazy">`:'<div class="empty">Preview unavailable</div>'}<div><b>${safe(photo.taken_at)}</b><p>${safe(photo.caption||'Progress photo')}</p><button class="chip" data-action="delete-photo" data-id="${safe(photo.id)}" data-path="${safe(photo.storage_path)}">Delete</button></div></article>`).join('');
  }

  async function uploadPhoto(event) {
    event.preventDefault();
    const status=$('#progressPhotoStatus'), file=$('#progressPhotoFile').files?.[0];
    if(!supa||!sessionUid){status.textContent='Sign in to upload private photos.';return;}
    if(!file){status.textContent='Choose a photo first.';return;}
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>10*1024*1024){status.textContent='Choose a JPEG, PNG or WebP image smaller than 10 MB.';return;}
    const photoId=id(),path=`${sessionUid}/${photoId}.${file.type==='image/png'?'png':file.type==='image/webp'?'webp':'jpg'}`;
    status.textContent='Uploading to your private storage…';
    let uploadError;
    try{({error:uploadError}=await supa.storage.from('progress-photos').upload(path,file,{contentType:file.type,upsert:false}));}
    catch(err){status.textContent=`Upload failed: ${err.message||'check your connection.'}`;return;}
    if(uploadError){status.textContent=`Upload failed: ${uploadError.message}`;return;}
    let rowError;
    try{({error:rowError}=await supa.from('progress_photos').insert({user_id:sessionUid,id:photoId,storage_path:path,caption:$('#progressPhotoCaption').value.trim(),taken_at:$('#progressPhotoDate').value||today()}));}
    catch(err){await supa.storage.from('progress-photos').remove([path]);status.textContent=`Photo metadata was not saved: ${err.message||'network error'}`;return;}
    if(rowError){await supa.storage.from('progress-photos').remove([path]);status.textContent=`Photo metadata was not saved: ${rowError.message}`;return;}
    event.currentTarget.reset();$('#progressPhotoDate').value=today();status.textContent='Photo uploaded privately.';await loadPhotos();
  }

  async function deletePhoto(button) {
    if(!confirm('Permanently delete this progress photo?'))return;
    const {error:storageError}=await supa.storage.from('progress-photos').remove([button.dataset.path]);
    if(storageError){toast(`Photo could not be deleted: ${storageError.message}`);return;}
    const {error}=await supa.from('progress_photos').delete().eq('id',button.dataset.id).eq('user_id',sessionUid);
    if(error){toast(`Photo record could not be removed: ${error.message}`);return;}
    await loadPhotos();toast('Progress photo deleted');
  }

  function installExerciseDetails() {
    addExerciseReferenceData();
    if (!baseRenderExercises) return;
    window.renderExercises = function() {
      baseRenderExercises();
      document.querySelectorAll('#exerciseGrid .exercise').forEach((card,index)=>{
        const matching = EXERCISES.filter((x)=>(muscle==='All'||muscle==='Favorites'||x[1]===muscle||muscle==='Arms'&&x[1]==='Arms'||muscle==='Legs'&&x[1]==='Legs')&&(document.getElementById('exerciseSearch')?.value===''||x.join(' ').toLowerCase().includes(document.getElementById('exerciseSearch').value.toLowerCase())));
        const name=card.querySelector('h4')?.textContent; const exercise=EXERCISES.find((x)=>x[0]===name); if(!exercise)return;
        if(card.querySelector('[data-exercise-details]'))return;
        const button=document.createElement('button');button.type='button';button.className='chip';button.textContent='Instructions';button.dataset.exerciseDetails=exercise[0];card.append(button);
      });
    };
  }

  function addExerciseReferenceData() {
    const additions = [
      ['Dumbbell glute bridge','Glutes','Dumbbells','Beginner','Press through the whole foot and finish with a controlled hip extension.','🍑'],
      ['Hip thrust','Glutes','Barbell','Intermediate','Keep ribs down and pause briefly at the top without overextending the back.','🍑'],
      ['Bodyweight glute bridge','Glutes','Bodyweight','Beginner','Brace gently and lift hips only as high as you can without arching.','🍑'],
      ['Standing calf raise','Calves','Bodyweight','Beginner','Use a stable support and lower through a comfortable range.','🦵'],
      ['Seated calf raise','Calves','Machine','Beginner','Move slowly and avoid bouncing at the bottom.','🦵'],
      ['Wrist curl','Forearms','Dumbbells','Beginner','Use a light load and keep the forearm supported.','💪'],
      ['Farmer carry','Forearms','Dumbbells','Intermediate','Walk tall with a load you can hold without leaning or pain.','🚶'],
      ['Inverted row','Back','Bodyweight','Beginner','Use a secure bar setup and keep your body aligned as you row.','🏋️'],
      ['Resistance band row','Back','Resistance bands','Beginner','Anchor the band safely and pull elbows back with control.','🪢'],
      ['Band chest press','Chest','Resistance bands','Beginner','Anchor the band securely and press without shrugging.','🪢'],
      ['Band squat','Legs','Resistance bands','Beginner','Keep the band secure and use a controlled comfortable squat depth.','🪢'],
      ['Band overhead press','Shoulders','Resistance bands','Beginner','Stand securely on the band and press without leaning back.','🪢'],
      ['Band biceps curl','Arms','Resistance bands','Beginner','Stand securely on the band and curl without swinging.','🪢'],
      ['Close-grip push-up','Arms','Bodyweight','Beginner','Keep elbows close and use a comfortable range; elevate hands to make it easier.','🤸'],
      ['Chin-up','Back','Bodyweight','Advanced','Use a secure bar and controlled reps; use assistance if needed.','🏋️'],
      ['Bodyweight squat','Legs','Bodyweight','Beginner','Keep feet stable and use a depth you can control comfortably.','🦵'],
      ['Reverse lunge','Legs','Bodyweight','Beginner','Step back to a stable stance and keep the movement controlled.','🦵'],
      ['Bear crawl hold','Full body','Bodyweight','Beginner','Brace and keep knees hovering only if that position is comfortable.','🐻'],
      ['Dumbbell thruster','Full body','Dumbbells','Intermediate','Use a manageable load and link the squat and press smoothly.','🏋️'],
    ];
    if (typeof EXERCISES !== 'undefined') for (const item of additions) if (!EXERCISES.some((x) => x[0] === item[0])) EXERCISES.push(item);
    const filters=$('#muscleFilters');
    for(const group of ['Glutes','Calves','Forearms','Full body','Biceps','Triceps','Abs']) if(filters&&!filters.querySelector(`[data-muscle="${group}"]`)){
      const button=document.createElement('button');button.className='chip';button.dataset.muscle=group;button.textContent=group;button.addEventListener('click',()=>{const query={Biceps:'curl',Triceps:'triceps',Abs:''}[group];muscle={Biceps:'Arms',Triceps:'Arms',Abs:'Core'}[group]||group;$('#exerciseSearch').value=query??'';filters.querySelectorAll('[data-muscle]').forEach((item)=>item.classList.toggle('active',item===button));renderExercises();});filters.append(button);
    }
    const equipmentFilter=$('#equipmentFilter');if(equipmentFilter&&!Array.from(equipmentFilter.options).some((option)=>option.value==='Resistance bands')){const option=document.createElement('option');option.textContent='Resistance bands';equipmentFilter.append(option);}
  }

  function showExerciseDetails(name) {
    const x=EXERCISES.find((item)=>item[0]===name);if(!x)return;
    const mistakes = /bench|press/i.test(name) ? ['Avoid bouncing the weight or forcing a painful shoulder range.','Keep wrists stacked over the forearms.']
      : /squat|leg press/i.test(name) ? ['Avoid losing foot contact or letting the knees collapse inward.','Use a depth you can control without pain.']
      : /deadlift|romanian/i.test(name) ? ['Avoid jerking the load or rounding under fatigue.','Keep the load close and stop when your back position changes.']
      : /row|pulldown/i.test(name) ? ['Avoid swinging the torso to move the load.','Keep the movement controlled through the full comfortable range.']
      : /curl/i.test(name) ? ['Avoid swinging the torso or bending the wrists to finish a rep.']
      : ['Avoid rushing repetitions or using a load that changes your form.','Stop if you feel sharp or worsening pain.'];
    const alternatives=EXERCISES.filter((other)=>other[1]===x[1]&&other[0]!==x[0]).slice(0,4);
    const secondary=({
      'Barbell bench press':['Triceps','front deltoids'],'Incline dumbbell press':['Triceps','front deltoids'],'Push-up':['Triceps','core'],'Lat pulldown':['Biceps','rear deltoids'],'Seated cable row':['Biceps','rear deltoids'],'Barbell squat':['Glutes','core'],'Romanian deadlift':['Glutes','hamstrings'],'Overhead press':['Triceps','core'],'Biceps curl':['Forearms'],'Hammer curl':['Forearms'],'Triceps pushdown':['Triceps'],'Plank':['Shoulders','core'],'Dead bug':['Core'],
    })[name]||[];
    const planExercise=state.plan.flatMap((day)=>day.exercises||[]).find((item)=>item.name===name);
    const prescription=planExercise?`${planExercise.sets} sets · ${planExercise.reps} reps · ${planExercise.rest||90}s rest`:state.profile?.goal==='strength'?'3–4 sets · 4–6 reps · 150s rest':state.profile?.goal==='endurance'?'2–3 sets · 12–18 reps · 60s rest':'3 sets · 8–12 reps · 90s rest';
    modal(`<div class="exercise-detail"><div class="tag">${safe(x[1])} · ${safe(x[2])} · ${safe(x[3])}</div><h3>${safe(x[0])}</h3><p>${safe(x[4])}</p><p><b>Primary muscle:</b> ${safe(x[1])}<br><b>Secondary muscles:</b> ${secondary.length?secondary.map(safe).join(', '):'Not listed in this offline reference'}<br><b>Suggested work:</b> ${safe(prescription)}</p><h4>Form cues</h4><ul><li>Use a comfortable range of motion and a controlled tempo.</li><li>Choose a load that lets you keep steady technique.</li><li>Stop if you feel sharp pain; ask a qualified trainer for in-person form feedback.</li></ul><h4>Common mistakes to watch</h4><ul>${mistakes.map((tip)=>`<li>${safe(tip)}</li>`).join('')}</ul><h4>Alternatives</h4><div class="chips">${alternatives.map((item)=>`<button class="chip" data-action="replace-plan-exercise" data-name="${safe(item[0])}">${safe(item[0])}</button>`).join('')||'<span class="muted">Add a suitable alternative from the exercise library.</span>'}</div><p class="smallnote">No demonstration media is attached to this exercise yet. Increase repetitions or load only when technique and recovery are good; this app never increases loads automatically.</p></div>`, 'Exercise instructions');
  }

  function installPlanEditor() {
    window.viewPlanDay=function(dayIndex){
      const day=state.plan[dayIndex];if(!day)return;
      modal(`<div class="list"><div class="listitem"><div class="grow"><b>${safe(day.name)}</b><small>Adjust order, movement, sets, reps and rest.</small></div></div>${day.exercises.map((exercise,index)=>`<div class="listitem"><div class="grow"><b>${safe(exercise.name)}</b><small>${exercise.sets} sets · ${safe(exercise.reps)} reps · ${exercise.rest||90}s rest</small></div><button class="chip" data-action="move-exercise" data-day="${dayIndex}" data-index="${index}" data-dir="-1" aria-label="Move earlier" ${index===0?'disabled':''}>↑</button><button class="chip" data-action="move-exercise" data-day="${dayIndex}" data-index="${index}" data-dir="1" aria-label="Move later" ${index===day.exercises.length-1?'disabled':''}>↓</button><button class="chip" onclick="editExercise(${dayIndex},${index})">Edit</button><button class="chip" data-action="replace-exercise" data-day="${dayIndex}" data-index="${index}">Replace</button><button class="chip" onclick="removeExercise(${dayIndex},${index})" aria-label="Remove exercise">×</button></div>`).join('')}</div><div class="actions"><button class="btn secondary" onclick="addExercise(${dayIndex})">+ Add exercise</button></div>`, `Edit ${day.name}`);
    };
    const workoutCard=$('#planList')?.closest('.card');
    if(workoutCard&&!$('#planReason')){const note=document.createElement('div');note.id='planReason';note.className='notice';note.hidden=true;$('#planList').after(note);}
    if(workoutCard&&!$('#routineSaveTools')){
      const tools=document.createElement('div');tools.id='routineSaveTools';tools.className='actions';tools.innerHTML='<button class="btn secondary" id="saveRoutine">Save routine</button><select id="savedRoutineSelect" aria-label="Saved routines"><option value="">Choose a saved routine</option></select><button class="btn secondary" id="loadRoutine">Load routine</button>';
      $('#planList').after(tools);
    }
    $('#saveRoutine')?.addEventListener('click',()=>{if(!state.plan.length){toast('Build a routine first');return;}const name=prompt('Name this routine','My routine');if(!name?.trim())return;state.savedRoutines.unshift({id:id(),name:name.trim().slice(0,60),plan:JSON.parse(JSON.stringify(state.plan))});save();toast('Routine saved');});
    $('#loadRoutine')?.addEventListener('click',()=>{const saved=state.savedRoutines.find((x)=>x.id===$('#savedRoutineSelect').value);if(!saved){toast('Choose a saved routine');return;}state.plan=JSON.parse(JSON.stringify(saved.plan));save();toast(`${saved.name} loaded`);});
    const baseRenderPlan=window.renderPlan;
    if(baseRenderPlan&&!window.__fitklotPlanWrapped){window.renderPlan=function(){baseRenderPlan();const select=$('#savedRoutineSelect');if(select)select.innerHTML='<option value="">Choose a saved routine</option>'+state.savedRoutines.map((x)=>`<option value="${safe(x.id)}">${safe(x.name)}</option>`).join('');};window.__fitklotPlanWrapped=true;}
    const baseGeneratePlan=window.generatePlan;
    if(baseGeneratePlan&&!window.__fitklotGeneratorWrapped){window.generatePlan=function(...args){baseGeneratePlan.apply(this,args);personalizePlan();};window.__fitklotGeneratorWrapped=true;}
    const baseStartWorkout=window.startWorkout;
    if(baseStartWorkout&&!window.__fitklotStartSafetyWrapped){window.startWorkout=function(...args){const hadPlan=state.plan.length>0,result=sanitizePlanForProfile();if(result.changed){save();const parts=[];if(result.replaced)parts.push(result.replaced+' movement(s) replaced');if(result.removed)parts.push(result.removed+' movement(s) removed');toast('Workout adjusted for your equipment and limitation notes: '+parts.join(', ')+'.');}if(hadPlan&&!state.plan.length){toast('No safe movements remain in this plan. Update it before starting a workout.');go('workouts');return;}return baseStartWorkout.apply(this,args);};window.__fitklotStartSafetyWrapped=true;}
  }

  function compatibleEquipment(exercise, profile) {
    const available=String(profile.equipment||'Full gym').toLowerCase(),needed=exercise[2];
    if(available.includes('full'))return true;
    if(available.includes('dumbbell'))return ['Dumbbells','Bodyweight'].includes(needed);
    if(available.includes('band'))return ['Resistance bands','Bodyweight'].includes(needed);
    if(available.includes('bodyweight'))return needed==='Bodyweight';
    if(available.includes('home'))return ['Dumbbells','Bodyweight','Resistance bands','Machine'].includes(needed);
    return true;
  }

  const LIMITATION_EXERCISE_RULES = [
    { limitation: /\b(knee|knees|patella|patellar|meniscus|acl|mcl)\b/i, label: 'knee', exercise: /squat|lunge|leg press|leg extension|step.?up|jump/i },
    { limitation: /\b(lower back|back|spine|disc|sciatic|sciatica)\b/i, label: 'back', exercise: /deadlift|romanian|good morning|bent.?over|barbell row|back extension|hyperextension|barbell squat/i },
    { limitation: /\b(shoulder|rotator cuff|collarbone)\b/i, label: 'shoulder', exercise: /overhead press|shoulder press|upright row|lateral raise|bench press|incline.*press|dip|push.?up|face pull|cable fly/i },
    { limitation: /\b(wrist|carpal|hand)\b/i, label: 'wrist or hand', exercise: /barbell|push.?up|plank|burpee|wrist curl|front rack/i },
    { limitation: /\b(elbow|tennis elbow|golfer.?s elbow)\b/i, label: 'elbow', exercise: /curl|triceps|bench press|overhead|push.?up|dip|row/i },
    { limitation: /\b(hip|groin)\b/i, label: 'hip or groin', exercise: /squat|lunge|leg press|deadlift|hip thrust|step.?up/i },
    { limitation: /\b(ankle|foot|achilles)\b/i, label: 'ankle or foot', exercise: /squat|lunge|jump|calf raise|step.?up|leg press/i },
    { limitation: /\b(neck|cervical)\b/i, label: 'neck', exercise: /shrug|overhead|upright row|deadlift|barbell squat/i },
  ];

  function exerciseLimitationLabels(profile = {}) {
    const notes = String(profile.injuries || '') + ' ' + String(profile.movementLimitations || '');
    return LIMITATION_EXERCISE_RULES.filter((rule) => rule.limitation.test(notes)).map((rule) => rule.label);
  }

  function isExerciseExcluded(name, profile = {}) {
    const candidate = String(name || '').toLowerCase();
    const explicit = String(profile.avoidExercises || '').split(/[,\n;]+/).map((term) => term.trim().toLowerCase()).filter(Boolean);
    const notes = String(profile.injuries || '') + ' ' + String(profile.movementLimitations || '');
    return explicit.some((term) => candidate.includes(term)) ||
      LIMITATION_EXERCISE_RULES.some((rule) => rule.limitation.test(notes) && rule.exercise.test(candidate));
  }

  function sanitizePlanForProfile() {
    const profile = state.profile || {};
    let replaced = 0, removed = 0;
    state.plan = (state.plan || []).map((day) => ({
      ...day,
      exercises: (day.exercises || []).map((entry) => {
        const source = EXERCISES.find((item) => item[0] === entry.name);
        if (!isExerciseExcluded(entry.name, profile) && (!source || compatibleEquipment(source, profile))) return entry;
        const muscle = entry.muscle || source?.[1];
        const alternative = EXERCISES.find((item) =>
          item[1] === muscle && item[0] !== entry.name &&
          compatibleEquipment(item, profile) && !isExerciseExcluded(item[0], profile));
        if (!alternative) { removed += 1; return null; }
        replaced += 1;
        return { ...entry, name: alternative[0], muscle: alternative[1], equipment: alternative[2] };
      }).filter(Boolean),
    })).filter((day) => day.exercises.length > 0);
    return { changed: replaced + removed > 0, replaced, removed };
  }

  function personalizePlan() {
    const profile=state.profile||{},goal=profile.goal||'general',level=String(profile.level||'Beginner').toLowerCase();
    const avoidTerms=String(profile.avoidExercises||'').split(/[,\n;]+/).map((term)=>term.trim().toLowerCase()).filter(Boolean);
    const limitationLabels=exerciseLimitationLabels(profile);
    const isAvoided=(name)=>isExerciseExcluded(name,profile);
    const latestRecovery=[...(state.recovery||[])].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))[0];
    const recoveryAge=latestRecovery?.date?Math.floor((new Date().setHours(0,0,0,0)-Date.parse(String(latestRecovery.date)+'T00:00:00'))/86400000):99;
    const hasRecoveryConcern=!!latestRecovery&&recoveryAge>=0&&recoveryAge<=3&&(asNumber(latestRecovery.soreness)>=4||(asNumber(latestRecovery.energy)>0&&asNumber(latestRecovery.energy)<=2)||(asNumber(latestRecovery.sleep)>0&&asNumber(latestRecovery.sleep)<5.5)||asNumber(latestRecovery.difficulty)>=9);
    const maxExercises=Math.max(2,(asNumber(profile.minutes)<=35?3:asNumber(profile.minutes)<=50?4:5)-(hasRecoveryConcern?1:0));
    state.plan=(state.plan||[]).map((day)=>{
      const exercises=(day.exercises||[]).map((entry)=>{
        let source=EXERCISES.find((item)=>item[0]===entry.name);
        if(!source&&isAvoided(entry.name))return null;
        if(source&&isAvoided(source[0])){source=EXERCISES.find((item)=>item[1]===source[1]&&compatibleEquipment(item,profile)&&!isAvoided(item[0]))||null;if(!source)return null;}
        if(source&&!compatibleEquipment(source,profile)){source=EXERCISES.find((item)=>item[1]===source[1]&&compatibleEquipment(item,profile)&&!isAvoided(item[0]))||null;if(!source)return null;}
        const next={...entry};if(source){next.name=source[0];next.muscle=source[1];next.equipment=source[2];}
        if(goal==='strength'){next.sets=level==='beginner'?3:4;next.reps='4–6';next.rest=150;}
        else if(goal==='endurance'){next.sets=level==='beginner'?2:3;next.reps='12–18';next.rest=60;}
        else {next.sets=level==='beginner'?2:3;next.reps=goal==='muscle'?'6–12':'8–12';next.rest=90;}
        if(hasRecoveryConcern){next.sets=Math.max(1,asNumber(next.sets)-1);next.rest=Math.min(240,asNumber(next.rest)+30);}
        return next;
      }).filter(Boolean).slice(0,maxExercises);
      return {...day,exercises};
    });
    const reason=$('#planReason');if(reason){reason.hidden=false;reason.textContent=`Starter routine based on your ${goal.replace(/([A-Z])/g,' $1')} goal, ${profile.level||'beginner'} experience, ${profile.days||state.plan.length} training days, ${profile.equipment||'selected'} equipment, and ${profile.minutes||60}-minute sessions. Edit any exercise. Choose starting loads you can control with sound technique; no weight is auto-increased. Start with a gradual warm-up and finish with an easy cool-down if it feels helpful.`;}
    if(reason&&avoidTerms.length)reason.textContent+=' Excluded exercise names matching: '+avoidTerms.join(', ')+'.';
    if(reason&&limitationLabels.length)reason.textContent+=' Broadly filtered movements associated with your '+limitationLabels.join(', ')+' limitation note(s). This keyword safeguard is not a medical assessment; have a qualified professional confirm suitable movements.';
    if(reason&&hasRecoveryConcern)reason.textContent+=' Recent recovery logs suggest taking a lighter session, so this plan uses one fewer exercise and set where possible with longer rest. Adjust further or rest if you have pain or still feel unwell.';
    save();
  }

  function moveExercise(dayIndex,index,delta) {
    const exercises=state.plan[dayIndex]?.exercises;const target=index+delta;
    if(!exercises||target<0||target>=exercises.length)return;
    [exercises[index],exercises[target]]=[exercises[target],exercises[index]];save();viewPlanDay(dayIndex);
  }

  function replaceExercise(dayIndex,index) {
    const current=state.plan[dayIndex]?.exercises?.[index];if(!current)return;
    const profile=state.profile||{},source=EXERCISES.find((e)=>e[0]===current.name),muscle=current.muscle||source?.[1];
    const options=EXERCISES.filter((x)=>x[1]===muscle&&x[0]!==current.name&&compatibleEquipment(x,profile)&&!isExerciseExcluded(x[0],profile));
    if(!options.length){toast('No safe compatible replacement is available for this movement. Review your limitations with a qualified professional.');return;}
    modal(`<div class="field"><label for="replacementExercise">Replacement movement</label><select id="replacementExercise">${options.map((x)=>`<option value="${safe(x[0])}">${safe(x[0])} · ${safe(x[2])}</option>`).join('')}</select></div><div class="actions"><button class="btn" id="confirmExerciseReplacement">Replace exercise</button></div>`, 'Replace exercise');
    $('#confirmExerciseReplacement')?.addEventListener('click',()=>{const selected=EXERCISES.find((x)=>x[0]===$('#replacementExercise').value);if(!selected)return;if(isExerciseExcluded(selected[0],state.profile||{})||!compatibleEquipment(selected,state.profile||{})){toast('That movement no longer matches your equipment or limitation settings.');return;}current.name=selected[0];current.muscle=selected[1];current.equipment=selected[2];save();viewPlanDay(dayIndex);toast('Exercise replaced');});
  }

  function addPreviousPerformance() {
    if(!baseRenderSession||!session)return;
    document.querySelectorAll('#sessionExercises > .card').forEach((card)=>{
      if(card.querySelector('.previous-performance'))return;
      const name=card.querySelector('h3')?.textContent;
      const lastSession=[...(state.sessions||[])].reverse().find((item)=>(item.sets||[]).some((set)=>set.exercise===name));
      const previous=(lastSession?.sets||[]).filter((set)=>set.exercise===name);
      const summary=previous.slice(0,3).map((set)=>`${set.kg||0} kg × ${set.reps||0}`).join(' · ');
      const label=document.createElement('p');label.className='smallnote previous-performance';label.textContent=summary?`Previous session: ${summary}`:'No previous performance logged for this movement.';
      card.insertBefore(label,card.querySelector('.setrow'));
      if(previous.some((set)=>set.done)){const bestReps=Math.max(...previous.filter((set)=>set.done).map((set)=>asNumber(set.reps)));const tip=document.createElement('p');tip.className='smallnote progression-tip';tip.textContent=bestReps>=12?'Progression idea: if all sets feel controlled and recovery is good, try a small load increase or one more rep. Keep the load the same if technique or recovery is off.':'Progression idea: aim to match or add a rep with steady form before increasing load. Do not increase if you have pain or poor recovery.';label.after(tip);}
    });
  }

  function installSessionControls() {
    const sessionUI=$('#sessionUI'),actions=sessionUI?.querySelector('.actions:last-child');if(!actions)return;
    let button=$('#pauseWorkout');if(!button){button=document.createElement('button');button.id='pauseWorkout';button.type='button';button.className='btn secondary';button.onclick=()=>window.toggleWorkoutPause?.();actions.prepend(button);}
    button.textContent=session?.pausedAt?'Resume workout':'Pause workout';
    button.hidden=!session;
    if(!window.__fitklotPauseMethod){
      window.toggleWorkoutPause=function(){if(!session)return;if(session.pausedAt){session.start+=Date.now()-session.pausedAt;session.pausedAt=null;}else session.pausedAt=Date.now();state.activeSession=session;save();renderSession();installSessionControls();};
      const finish=window.finishWorkout;if(finish)window.finishWorkout=function(...args){if(session?.pausedAt){session.start+=Date.now()-session.pausedAt;session.pausedAt=null;}return finish.apply(this,args);};
      window.__fitklotPauseMethod=true;
    }
  }

  function renderRepeatButtons() {
    const root=$('#workoutHistory');if(!root)return;
    root.querySelectorAll('.listitem').forEach((row,index)=>{
      if(row.querySelector('[data-action="repeat-workout"]'))return;
      const button=document.createElement('button');button.type='button';button.className='chip';button.dataset.action='repeat-workout';button.dataset.index=String(index);button.textContent='Repeat';
      row.append(button);
    });
  }

  function repeatWorkout(index) {
    if(session){toast('Finish or end your current workout before repeating another.');return;}
    const previous=[...(state.sessions||[])].reverse()[index];if(!previous)return;
    const grouped=new Map();for(const set of previous.sets||[]){const name=set.exercise||'Exercise';if(!grouped.has(name))grouped.set(name,[]);grouped.get(name).push(set);}
    const profile=state.profile||{};let skipped=0;
    for(const [name] of grouped){const ref=EXERCISES.find((x)=>x[0]===name);if(isExerciseExcluded(name,profile)||(ref&&!compatibleEquipment(ref,profile))){grouped.delete(name);skipped++;}}
    if(skipped)toast('Skipped '+skipped+' previous movement(s) because of your current equipment or limitation notes.');
    if(!grouped.size){toast('This saved workout has no exercise sets to repeat.');return;}
    session={name:`Repeat · ${previous.name||'Workout'}`,date:today(),start:Date.now(),sets:[],exercises:[...grouped].map(([name,sets])=>({name,sets:Math.max(1,...sets.map((set)=>asNumber(set.set))),reps:'8–12',rest:90,logged:Array.from({length:Math.max(1,...sets.map((set)=>asNumber(set.set)))},()=>({kg:'',reps:'',done:false}))}))};
    state.activeSession=session;save();go('workouts');renderSession();toast('Previous workout copied into a fresh session');
  }

  function installCoachConsent() {
    const page=$('#page-coach'),form=$('#coachForm');if(!page||!form||$('#coachAiConsent'))return;
    const notice=page.querySelector('.notice');if(notice)notice.textContent='The offline rule-based coach works without an AI service. Optional online answers require the server-side coach setup below and explicit consent for each question.';
    const badge=page.querySelector('.welcome .tag');if(badge)badge.textContent='OFFLINE + OPTIONAL AI';
    const box=document.createElement('div');box.className='notice coach-consent';box.innerHTML='<b>Offline coach stays available.</b> For optional AI answers, sign in and check this box for each question. The question and relevant saved profile, food, workout and weight summaries are sent securely through FitKlot’s server to OpenAI. We do not send your name, photos, or full account record. <label class="consent-check"><input id="coachAiConsent" type="checkbox"> Send this question and relevant saved fitness context to the AI service</label>';
    form.before(box);
    form.addEventListener('submit',async(event)=>{
      const consent=$('#coachAiConsent');if(!consent?.checked)return;
      event.preventDefault();event.stopImmediatePropagation();
      const question=$('#coachInput').value.trim(),response=$('#coachResponse'),button=form.querySelector('[type="submit"]');if(!question)return;
      if(!sessionUid||!supa){response.innerHTML='<div class="notice">Sign in with your configured account to use online AI. The offline coach remains available to guests.</div>';return;}
      button.disabled=true;response.innerHTML='<div class="empty">Checking your session and generating an answer…</div>';
      try{
        const {data,error}=await supa.functions.invoke('coach',{body:{question,today:today()}});
        if(error)throw error;
        if(data?.error)throw new Error(data.error);
        if(!data?.answer)throw new Error('The AI coach returned no answer. Try again or use the offline coach.');
        response.innerHTML=`<div class="coach-answer"><div class="tag">AI COACH · SAVED CONTEXT</div><p>${safe(data.answer).replace(/\n/g,'<br>')}</p><small>AI-generated guidance · verify estimates · not medical advice</small></div>`;
      }catch(error){
        const message=await edgeErrorMessage(error,'AI coach is unavailable.');
        response.innerHTML=`<div class="notice error-notice">${safe(message)} <button class="chip" id="offlineCoachFallback">Use offline guidance</button></div>`;
        $('#offlineCoachFallback')?.addEventListener('click',()=>{response.innerHTML=`<div class="coach-answer"><div class="tag">OFFLINE GUIDANCE</div><p>${safe(coachAnswer(question))}</p><small>Rule-based response · not medical advice</small></div>`;});
      }finally{button.disabled=false;}
    },true);
  }

  function installFoodDataSearch() {
    const form=$('#foodForm');
    if(!form||$('#fdcSearchPanel'))return;
    const panel=document.createElement('section');
    panel.id='fdcSearchPanel';
    panel.className='notice fdc-search-panel';
    panel.innerHTML='<div class="fdc-search-head"><b>Verified database lookup · USDA FoodData Central</b><span class="tag">ONLINE, OPTIONAL</span></div><p>Search generic foods and branded products when signed in. Only the search terms go to USDA; no profile or diary is sent for lookup. Values are USDA records; check the specific food, serving basis and product label. Indian-food coverage varies.</p><form id="fdcSearchForm" class="fdc-search-form"><label class="visually-hidden" for="fdcQuery">Search USDA FoodData Central</label><input id="fdcQuery" type="search" maxlength="100" minlength="2" placeholder="Search a food, e.g. lentils or paneer" required><button class="btn secondary" type="submit">Search database</button></form><div id="fdcSearchStatus" class="smallnote" aria-live="polite">Offline reference foods and manual logging remain available.</div><div id="fdcSearchResults" class="list"></div>';
    form.before(panel);
    const source=document.createElement('input');source.type='hidden';source.id='foodSource';source.value='Manual estimate';
    const sourceId=document.createElement('input');sourceId.type='hidden';sourceId.id='foodSourceId';sourceId.value='';
    form.append(source,sourceId);
    const foodName=$('#foodSearch');
    const resetFoodSource=()=>{if($('#foodSource'))$('#foodSource').value='Manual estimate';if($('#foodSourceId'))$('#foodSourceId').value='';};
    foodName?.addEventListener('input',resetFoodSource);
    document.addEventListener('click',(event)=>{if(event.target.closest('#foodQuick .chip'))resetFoodSource();});
    const results=$('#fdcSearchResults'),status=$('#fdcSearchStatus'),search=$('#fdcSearchForm');
    search.addEventListener('submit',async(event)=>{
      event.preventDefault();
      const query=$('#fdcQuery').value.trim();
      if(query.length<2){status.textContent='Enter at least two characters.';return;}
      if(!supa||!sessionUid){status.textContent='Sign in and connect online for USDA search. The offline food list remains available.';return;}
      const button=search.querySelector('button');button.disabled=true;status.textContent='Searching USDA FoodData Central…';results.replaceChildren();
      try{
        const {data,error}=await supa.functions.invoke('food-search',{body:{query}});
        if(error)throw new Error(data?.error||await edgeErrorMessage(error,'The food database could not be reached.'));
        if(data?.error)throw new Error(data.error);
        const foods=Array.isArray(data?.foods)?data.foods:[];
        if(!foods.length){status.textContent='No complete nutrient matches found. Try another name or enter values from a label.';return;}
        status.textContent=foods.length+' results · USDA values per 100 g · check the product and preparation.';
        const resultMap=new Map();
        foods.forEach((food)=>{
          resultMap.set(String(food.fdcId),food);
          const row=document.createElement('article');row.className='listitem fdc-result';
          const details=document.createElement('div');details.className='grow';
          details.innerHTML='<b>'+safe(food.name)+'</b><small>'+safe(food.dataType)+(food.brandOwner?' · '+safe(food.brandOwner):'')+' · USDA FDC #'+safe(food.fdcId)+' · per 100 g</small><small>'+asNumber(food.kcal).toFixed(1)+' kcal · P '+asNumber(food.protein).toFixed(1)+' g · C '+asNumber(food.carbs).toFixed(1)+' g · F '+asNumber(food.fat).toFixed(1)+' g'+(food.fiber==null?'':' · fibre '+asNumber(food.fiber).toFixed(1)+' g')+'</small>';
          const sourceLink=document.createElement('a');sourceLink.href=String(food.sourceUrl||('https://fdc.nal.usda.gov/food-details/'+encodeURIComponent(String(food.fdcId))+'/nutrients'));sourceLink.target='_blank';sourceLink.rel='noopener noreferrer';sourceLink.textContent='View USDA record';sourceLink.className='smallnote';details.append(sourceLink);
          const use=document.createElement('button');use.type='button';use.className='chip';use.textContent='Use this food';use.dataset.fdcId=String(food.fdcId);
          use.addEventListener('click',()=>{
            const selected=resultMap.get(use.dataset.fdcId);if(!selected)return;
            $('#foodSearch').value=selected.name;
            $('#foodKcal').value=selected.kcal;$('#foodProt').value=selected.protein;$('#foodCarb').value=selected.carbs;$('#foodFat').value=selected.fat;
            $('#foodQty').value=100;$('#foodFiber').value=selected.fiber??'';
            $('#foodSource').value=selected.source||'USDA FoodData Central';$('#foodSourceId').value=String(selected.fdcId);
            status.textContent='Selected USDA FDC #'+selected.fdcId+'. Nutrition values are per 100 g; adjust the serving and check the actual label or preparation.';
            $('#foodSearch').focus();
          });
          row.append(details,use);results.append(row);
        });
      }catch(error){status.textContent=error?.message||'USDA search is unavailable. Offline food logging remains available.';}
      finally{button.disabled=false;}
    });
  }
  function installDataEntryNotices() {
    installProfileSafetyNotice();
    const nutrition=$('#page-nutrition');
    if(nutrition&&!$('#nutritionEstimateNotice')){const notice=document.createElement('div');notice.id='nutritionEstimateNotice';notice.className='notice';notice.textContent='Built-in Indian food values are generic reference estimates. Optional online USDA FoodData Central results are source-labelled and usually per 100 g; Indian food coverage, recipes, brands and cooking methods vary. Check package labels where available. No barcode scanner is included.';nutrition.insertBefore(notice,nutrition.children[1]);}
    const form=$('#foodForm');

    if(form&&!$('#fiberField')){const field=document.createElement('div');field.className='field';field.id='fiberField';field.innerHTML='<label for="foodFiber">Fibre (g / 100 g, optional)</label><input id="foodFiber" type="number" min="0" max="100" step="0.1" placeholder="If known">';form.querySelector('.formgrid')?.append(field);}
    const measurements=$('#measureForm');
    if(measurements&&!$('#mHips')){const field=document.createElement('div');field.className='field';field.innerHTML='<label for="mHips">Hips</label><input id="mHips" type="number" min="20" max="250" step="0.1">';measurements.querySelector('.formgrid')?.append(field);}
    const dashboard=$('#page-dashboard');
    if(dashboard&&!$('#onboardingHint')){const card=document.createElement('div');card.id='onboardingHint';card.className='notice onboarding-hint';card.innerHTML='<b>Get your profile set up</b><span>Add your goal, schedule and equipment so FitKlot can tailor workout and meal suggestions.</span><button class="chip" data-action="start-onboarding">Start setup</button><button class="chip" data-action="open-profile">Edit profile</button>';$('.welcome',dashboard)?.after(card);}
    const settings=$('#page-settings');
    if(settings&&!$('#unitSettingsHint')){const note=document.createElement('div');note.id='unitSettingsHint';note.className='smallnote';note.textContent='Set your preferred metric or imperial units in your fitness profile. Values are stored in metric units for consistent calculations.';settings.querySelector('.card')?.prepend(note);}
    installFoodDataSearch();
  }

  function updateProfileSafetyNotice() {
    const notice=$('#profileSafetyNotice');
    if(!notice)return;
    const birthDate=$('#pBirthDate')?.value;
    const age=getProfileAge({age:$('#pAge')?.value,birthDate});
    const calories=asNumber($('#pCalories')?.value),protein=asNumber($('#pProtein')?.value);
    const units=$('#pUnits')?.value||'metric';
    const weight=asNumber($('#pWeight')?.value)*(units==='imperial'?0.45359237:1);
    const warnings=[];
    if(age>0&&age<18&&calories>0)warnings.push('For users under 18, calorie targets should be set with a qualified pediatric health professional. FitKlot does not estimate calorie needs for minors.');
    else if(calories>0&&calories<1200)warnings.push('This calorie target is below 1,200 kcal/day and may be too low for many adults. Review it with a qualified health professional; FitKlot cannot determine that it is safe.');
    if(protein>0&&weight>0&&protein/weight>2.5)warnings.push('This protein target is unusually high relative to body weight. Discuss it with a qualified professional, especially with a medical condition or prescribed diet.');
    notice.hidden=warnings.length===0;
    notice.textContent=warnings.join(' ');
  }

  function installProfileSafetyNotice() {
    const form=$('#profileForm');
    if(!form)return;
    let notice=$('#profileSafetyNotice');
    if(!notice){notice=document.createElement('div');notice.id='profileSafetyNotice';notice.className='notice';notice.hidden=true;notice.setAttribute('role','status');notice.setAttribute('aria-live','polite');form.append(notice);}
    for(const selector of ['#pAge','#pBirthDate','#pCalories','#pProtein','#pWeight','#pUnits'])$(selector)?.addEventListener('input',updateProfileSafetyNotice);
    for(const selector of ['#pBirthDate'])$(selector)?.addEventListener('change',updateProfileSafetyNotice);
    for(const selector of ['#pUnits'])$(selector)?.addEventListener('change',updateProfileSafetyNotice);
    updateProfileSafetyNotice();
  }

  function renderOnboardingHint() {
    const hint=$('#onboardingHint');if(!hint)return;
    const profile=state.profile||{};const complete=profile.goal&&profile.height&&profile.weight&&profile.days&&profile.equipment;
    hint.hidden=!!complete;
  }

  function startOnboarding() {
    const profile=state.profile||{};
    modal(`<div id="onboardingWizard"><p class="muted">Optional health details can be skipped. Measurements are saved in metric units. You can change these settings later.</p>
      <div class="wizard-panel" data-step="0"><div class="eyebrow">STEP 1 OF 3 · ABOUT YOU</div><div class="formgrid"><div class="field"><label for="obName">Name</label><input id="obName" maxlength="80" value="${safe(profile.name||'')}"></div><div class="field"><label for="obBirth">Date of birth (optional)</label><input id="obBirth" type="date" value="${safe(profile.birthDate||'')}"></div><div class="field"><label for="obSex">Sex for optional calorie estimate</label><select id="obSex"><option value="">Skip</option><option value="female">Female</option><option value="male">Male</option></select></div><div class="field"><label for="obHeight">Height (cm, optional)</label><input id="obHeight" type="number" min="80" max="250" step="0.1" value="${safe(profile.height||'')}"></div><div class="field"><label for="obWeight">Current weight (kg, optional)</label><input id="obWeight" type="number" min="25" max="400" step="0.1" value="${safe(profile.weight||'')}"></div><div class="field"><label for="obTarget">Target weight (kg, optional)</label><input id="obTarget" type="number" min="25" max="400" step="0.1" value="${safe(profile.target||'')}"></div></div></div>
      <div class="wizard-panel" data-step="1" hidden><div class="eyebrow">STEP 2 OF 3 · TRAINING</div><div class="formgrid"><div class="field"><label for="obGoal">Goal</label><select id="obGoal"><option value="fatloss">Fat loss</option><option value="muscle">Muscle gain</option><option value="recomposition">Body recomposition</option><option value="strength">Strength</option><option value="endurance">Endurance</option><option value="general">General fitness</option></select></div><div class="field"><label for="obLevel">Experience</label><select id="obLevel"><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></div><div class="field"><label for="obDays">Training days per week</label><select id="obDays"><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option></select></div><div class="field"><label for="obMinutes">Workout duration</label><select id="obMinutes"><option>30</option><option>45</option><option>60</option><option>75</option><option>90</option></select></div><div class="field"><label for="obEquipment">Available equipment</label><select id="obEquipment"><option>Full gym</option><option>Dumbbells</option><option>Home gym</option><option>Resistance bands</option><option>Bodyweight</option></select></div><div class="field"><label for="obSplit">Preferred workout style</label><select id="obSplit"><option>Upper / Lower</option><option>Push / Pull / Legs</option><option>Full body</option><option>Bro split</option><option>Strength</option></select></div><div class="field"><label for="obFocus">Muscle groups to prioritize</label><input id="obFocus" maxlength="120" value="${safe(profile.focus||'')}"></div><div class="field full"><label for="obAvoidExercises">Exercises or movements to avoid</label><input id="obAvoidExercises" maxlength="240" value="" placeholder="e.g. squat, overhead press; separate items with commas"></div><div class="field full"><label for="obInjuries">Injuries or movement limits (optional)</label><input id="obInjuries" maxlength="240" value="${safe(profile.injuries||'')}"></div></div></div>
      <div class="wizard-panel" data-step="2" hidden><div class="eyebrow">STEP 3 OF 3 · FUEL & RECOVERY</div><div class="formgrid"><div class="field"><label for="obDiet">Dietary preference</label><select id="obDiet"><option>Non-vegetarian</option><option>Vegetarian</option><option>Eggetarian</option><option>Vegan</option><option>Custom</option></select></div><div class="field"><label for="obActivity">Typical daily activity</label><select id="obActivity"><option value="1.2">Mostly sitting</option><option value="1.375">Lightly active</option><option value="1.55">Moderately active</option><option value="1.725">Very active</option></select></div><div class="field"><label for="obSleep">Sleep hours (optional)</label><input id="obSleep" type="number" min="0" max="24" step="0.25" value="${safe(profile.sleep||'')}"></div><div class="field"><label for="obBodyFat">Body-fat % (optional, if measured)</label><input id="obBodyFat" type="number" min="2" max="70" step="0.1" value="${safe(profile.bodyFat||'')}"></div><div class="field full"><label for="obAvoid">Food allergies, restrictions or disliked foods</label><textarea id="obAvoid" maxlength="500">${safe(profile.avoid||'')}</textarea></div><div class="field"><label for="obWaist">Waist (cm, optional)</label><input id="obWaist" type="number" min="20" max="250" step="0.1"></div><div class="field"><label for="obChest">Chest (cm, optional)</label><input id="obChest" type="number" min="20" max="250" step="0.1"></div><div class="field"><label for="obArm">Arm (cm, optional)</label><input id="obArm" type="number" min="5" max="150" step="0.1"></div><div class="field"><label for="obThigh">Thigh (cm, optional)</label><input id="obThigh" type="number" min="10" max="200" step="0.1"></div><div class="field"><label for="obHips">Hips (cm, optional)</label><input id="obHips" type="number" min="20" max="250" step="0.1"></div></div></div>
      <div class="actions"><button class="btn secondary" id="wizardBack" type="button">Back</button><span class="grow muted" id="wizardStepLabel">1 of 3</span><button class="btn" id="wizardNext" type="button">Next</button><button class="btn" id="wizardSave" type="button" hidden>Save profile</button><button class="chip" id="wizardSkip" type="button">Skip for now</button></div><p class="smallnote" id="wizardError" role="status"></p></div>`, 'Personalized setup');
    const panels=[...document.querySelectorAll('.wizard-panel')];let current=0;
    const setValue=(selector,value)=>{const input=$(selector);if(input&&value!=null&&value!=='')input.value=value;};
    setValue('#obSex',profile.sex);setValue('#obGoal',profile.goal||'recomposition');setValue('#obLevel',profile.level||'Beginner');setValue('#obDays',profile.days||'4');setValue('#obMinutes',profile.minutes||'60');setValue('#obEquipment',profile.equipment||'Full gym');setValue('#obSplit',profile.split||split);setValue('#obAvoidExercises',profile.avoidExercises||'');setValue('#obDiet',profile.diet||'Non-vegetarian');setValue('#obActivity',profile.activity||'1.55');
    const render=()=>{panels.forEach((panel,index)=>panel.hidden=index!==current);$('#wizardBack').disabled=current===0;$('#wizardNext').hidden=current===panels.length-1;$('#wizardSave').hidden=current!==panels.length-1;$('#wizardStepLabel').textContent=`${current+1} of ${panels.length}`;};render();
    $('#wizardBack').addEventListener('click',()=>{current=Math.max(0,current-1);render();});
    $('#wizardNext').addEventListener('click',()=>{const h=asNumber($('#obHeight').value),w=asNumber($('#obWeight').value);if(current===0&&((h&& (h<80||h>250))||(w&&(w<25||w>400)))){$('#wizardError').textContent='Check your height and weight values.';return;}$('#wizardError').textContent='';current=Math.min(panels.length-1,current+1);render();});
    $('#wizardSkip').addEventListener('click',()=>$('#modal')?.remove());
    $('#wizardSave').addEventListener('click',()=>{
      const birthDate=$('#obBirth').value;let age=profile.age||'';
      if(birthDate){const born=new Date(`${birthDate}T12:00:00`),now=new Date();age=String(now.getFullYear()-born.getFullYear()-(now<new Date(now.getFullYear(),born.getMonth(),born.getDate())?1:0));}
      split=$('#obSplit').value;state.profile={...profile,name:$('#obName').value.trim(),birthDate,age,sex:$('#obSex').value,height:$('#obHeight').value,weight:$('#obWeight').value,target:$('#obTarget').value,goal:$('#obGoal').value,level:$('#obLevel').value,days:$('#obDays').value,minutes:$('#obMinutes').value,equipment:$('#obEquipment').value,split,diet:$('#obDiet').value,activity:$('#obActivity').value,sleep:$('#obSleep').value,bodyFat:$('#obBodyFat').value,avoid:$('#obAvoid').value.trim(),focus:$('#obFocus').value.trim(),injuries:$('#obInjuries').value.trim(),avoidExercises:$('#obAvoidExercises').value.trim(),units:profile.units||'metric'};
      const values={waist:$('#obWaist').value,chest:$('#obChest').value,arm:$('#obArm').value,thigh:$('#obThigh').value,hips:$('#obHips').value};if(Object.values(values).some(Boolean))state.measurements.push({id:id(),date:today(),values});
      fillProfileForm();save();$('#modal')?.remove();go('dashboard');toast('Personalized profile saved');
    });
  }

  function renderBodyComposition() {
    const root=$('#bodyMetrics'),pct=asNumber(state.profile?.bodyFat),kg=asNumber(state.weights.slice().sort((a,b)=>a.date.localeCompare(b.date)).at(-1)?.kg||state.profile?.weight);
    if(!root||!pct||!kg||root.querySelector('.body-composition'))return;
    const fat=kg*pct/100,lean=kg-fat,imperial=state.profile?.units==='imperial',factor=imperial?2.20462262:1,unit=imperial?'lb':'kg';
    const card=document.createElement('div');card.className='card body-composition';card.innerHTML=`<div class="muted">Composition estimate</div><div class="bigvalue">${(fat*factor).toFixed(1)} ${unit} fat · ${(lean*factor).toFixed(1)} ${unit} lean</div><div class="smallnote">Calculated from your entered ${pct}% body-fat value and recorded weight. The result is only as accurate as that measurement; it is not inferred from weight.</div>`;root.append(card);
  }

  function formatImperialDisplays() {
    const orderedWeights=[...(state.weights||[])].sort((a,b)=>b.date.localeCompare(a.date));
    document.querySelectorAll('#weightHistory tbody tr').forEach((row,index)=>{const dateCell=row.children[0],entry=orderedWeights[index];if(dateCell&&entry)dateCell.textContent=`${entry.date}${entry.time?' · '+entry.time:''}`;});
    if(state.profile?.units!=='imperial')return;
    const convert=(kg)=>`${(asNumber(kg)/0.45359237).toFixed(1)} lb`;
    const dash=$('#dashWeight');const lastWeight=[...(state.weights||[])].sort((a,b)=>b.date.localeCompare(a.date))[0];if(dash)dash.innerHTML=`${lastWeight?convert(lastWeight.kg):'—'} <span class="unit"></span>`;
    const progress=$('#progressMetrics');if(progress)progress.innerHTML=progress.innerHTML.replace(/(-?\d+(?:\.\d+)?) kg/g,(_,value)=>convert(value));
    document.querySelectorAll('#weightHistory tbody tr').forEach((row)=>{const cell=row.children[1];if(cell){const number=Number.parseFloat(cell.textContent);if(Number.isFinite(number))cell.textContent=convert(number);}});
    for(const chartId of ['weightChart','progressChart'])document.querySelectorAll(`#${chartId} .bar`).forEach((bar)=>{const match=bar.title.match(/[0-9.]+/);if(match)bar.title=convert(match[0]);});
    const foot=$('#weightFoot');if(foot)foot.textContent=lastWeight?(state.profile.target?`${((asNumber(state.profile.target)-asNumber(lastWeight.kg))/0.45359237).toFixed(1)} lb from target`:`Last recorded ${lastWeight.date}`):'Log your first weigh-in';
    document.querySelectorAll('#measureHistory .listitem').forEach((row)=>{row.innerHTML=row.innerHTML.replace(/(waist|chest|arm|thigh|hips) ([0-9.]+) cm/gi,(_,label,value)=>`${label[0].toUpperCase()+label.slice(1)} ${(asNumber(value)/2.54).toFixed(1)} in`);});
    const metrics=$('#bodyMetrics');if(metrics)metrics.innerHTML=metrics.innerHTML.replace(/(-?\d+(?:\.\d+)?) kg/g,(_,value)=>convert(value));
    const records=$('#recordsList');if(records)records.innerHTML=records.innerHTML.replace(/(-?\d+(?:\.\d+)?) kg/g,(_,value)=>convert(value));
    const volume=$('#recVolume');if(volume)volume.innerHTML=volume.innerHTML.replace(/(-?\d+(?:\.\d+)?)\s*<span class="unit">kg<\/span>/,(_,value)=>`${(asNumber(value)/0.45359237).toFixed(1)} <span class="unit">lb</span>`);
    document.querySelectorAll('.previous-performance').forEach((label)=>{label.textContent=label.textContent.replace(/(-?\d+(?:\.\d+)?) kg/g,(_,value)=>convert(value));});
    const analyticsWeight=$('#analyticWeight');if(analyticsWeight?.textContent.includes('kg'))analyticsWeight.textContent=analyticsWeight.textContent.replace(/(-?\d+(?:\.\d+)?) kg/g,(_,value)=>convert(value));
    document.querySelectorAll('#weeklyWeightChart .analytics-bar').forEach((bar)=>{if(/kg/.test(bar.title))bar.title=bar.title.replace(/(-?\d+(?:\.\d+)?) kg/g,(_,value)=>convert(value));});
    const live=$('#sessionExercises');if(live)live.querySelectorAll('.setrow input[type="number"]').forEach((input)=>{if(input.dataset.unitConverted)return;if(input.value){input.value=(asNumber(input.value)/0.45359237).toFixed(1);}input.placeholder='lb';input.dataset.unitConverted='1';});
    live?.querySelectorAll('.setrow').forEach((row)=>{const first=row.querySelector('span');if(first?.textContent==='SET'){const unit=row.children[1];if(unit)unit.textContent='LB';}});
  }

  function installImperialSessionLogger() {
    const baseLogSet=window.logSet;if(!baseLogSet||window.__fitklotUnitsWrapped)return;
    window.logSet=function(i,j,key,value){if(key==='kg'&&state.profile?.units==='imperial')value=String(asNumber(value)*0.45359237);return baseLogSet(i,j,key,value);};
    window.__fitklotUnitsWrapped=true;
  }

  function renderExtras() {
    renderOnboardingHint();renderBodyComposition();renderDietPlan();renderMealTemplates();renderAnalytics();renderReminders();renderPhotos();formatImperialDisplays();
    const todayFoods=(state.foods||[]).filter((item)=>item.date===today());const fiber=$('#nFiber');if(fiber)fiber.textContent=todayFoods.reduce((sum,item)=>sum+asNumber(item.fiber),0).toFixed(1);const water=$('#nWater');if(water)water.textContent=String((state.water||[]).filter((item)=>item.date===today()).reduce((sum,item)=>sum+asNumber(item.ml),0));const meals=$('#nMealCount');if(meals)meals.textContent=String(new Set(todayFoods.map((item)=>item.meal).filter(Boolean)).size);document.querySelectorAll('#foodDiary .listitem').forEach((row,index)=>{const item=todayFoods.slice().reverse()[index];if(!item?.source||row.dataset.sourceShown)return;const note=document.createElement('small');note.className='food-source-note';note.append(document.createTextNode('Source: '+item.source+(item.sourceId?' · FDC #'+item.sourceId:'')));if(String(item.source||'').includes('USDA')&&/^\d+$/.test(String(item.sourceId||''))){note.append(document.createTextNode(' · '));const link=document.createElement('a');link.href='https://fdc.nal.usda.gov/food-details/'+encodeURIComponent(String(item.sourceId))+'/nutrients';link.target='_blank';link.rel='noopener noreferrer';link.textContent='View source';note.append(link);}row.querySelector('.grow')?.append(note);row.dataset.sourceShown='1';});
    addPreviousPerformance();renderRepeatButtons();installSessionControls();
  }

  function onDocumentClick(event) {
    const button=event.target.closest('[data-action]');if(!button)return;
    const action=button.dataset.action;
    if(action==='log-planned-meal')logPlannedMeal(Number(button.dataset.day),Number(button.dataset.meal));
    if(action==='save-meal-template')saveTodaysMealTemplate();
    if(action==='apply-meal-template')applyMealTemplate(button.dataset.id);
    if(action==='delete-meal-template'){state.savedMeals=state.savedMeals.filter((x)=>x.id!==button.dataset.id);save();}
    if(action==='open-profile')go('profile');
    if(action==='start-onboarding')startOnboarding();
    if(action==='move-exercise')moveExercise(Number(button.dataset.day),Number(button.dataset.index),Number(button.dataset.dir));
    if(action==='replace-exercise')replaceExercise(Number(button.dataset.day),Number(button.dataset.index));
    if(action==='toggle-reminder'){const item=state.reminders[Number(button.dataset.index)];if(item){item.enabled=!item.enabled;save();}}
    if(action==='delete-reminder'){state.reminders.splice(Number(button.dataset.index),1);save();}
    if(action==='read-notification'){const item=state.notifications[Number(button.dataset.index)];if(item){item.readAt=new Date().toISOString();save();}}
    if(action==='delete-photo')deletePhoto(button);
    if(action==='repeat-workout')repeatWorkout(Number(button.dataset.index));
    if(action==='replace-plan-exercise'){
      const exercise=EXERCISES.find((item)=>item[0]===button.dataset.name);
      if(exercise){modal(`<p>Use <b>${safe(exercise[0])}</b> as a substitute in your current plan?</p><div class="actions"><button class="btn" id="confirmLibraryReplacement">Replace first matching muscle-group exercise</button></div>`, 'Replace movement');$('#confirmLibraryReplacement')?.addEventListener('click',()=>{for(const day of state.plan){const index=day.exercises.findIndex((item)=>item.muscle===exercise[1]);if(index>=0){day.exercises[index]={...day.exercises[index],name:exercise[0],muscle:exercise[1],equipment:exercise[2]};save();toast('Plan exercise replaced');return;}}toast('No matching exercise was found in the current plan.');});}
    }
  }

  function installPageHandlers() {
    $('#generateMealPlan')?.addEventListener('click',generateMealPlan);
    $('#clearMealPlan')?.addEventListener('click',()=>{if(confirm('Delete the saved weekly meal plans?')){state.weeklyPlans=[];save();}});
    $('#exportGroceries')?.addEventListener('click',()=>{const plan=state.weeklyPlans[0];if(!plan){toast('Generate a meal plan first');return;}const text=plan.groceries.map((x)=>`${x.checked?'[x]':'[ ]'} ${x.name} — ${x.amount} ${x.unit}`).join('\n');const blob=new Blob([text],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`fitklot-grocery-list-${plan.weekStart}.txt`;a.click();URL.revokeObjectURL(a.href);});
    $('#reminderForm')?.addEventListener('submit',(event)=>{event.preventDefault();const time=$('#reminderTime').value,label=$('#reminderLabel').value.trim(),type=$('#reminderType').value;if(!time||!label)return;state.reminders.push({id:id(),type,label,time,days:$('#reminderDaily').checked?[0,1,2,3,4,5,6]:[new Date().getDay()],enabled:true});save();event.currentTarget.reset();$('#reminderTime').value='09:00';toast('Reminder saved');});
    $('#requestNotifications')?.addEventListener('click',async()=>{const status=$('#notificationPermission');if(!('Notification' in window)){status.textContent='This browser does not support notifications.';return;}const permission=await Notification.requestPermission();status.textContent=permission==='granted'?'Browser notifications allowed. They only run while the app is open.':`Browser notification permission: ${permission}. In-app reminders still work.`;state.notificationPrefs.push=permission==='granted';save();});
    $('#notificationSettings')?.addEventListener('change',(event)=>{const key=event.target.dataset.pref;if(!key)return;state.notificationPrefs[key]=event.target.checked;save();});
    $('#clearNotifications')?.addEventListener('click',()=>{state.notifications=state.notifications.filter((x)=>!x.readAt);save();});
    $('#splitChoices')?.addEventListener('click',(event)=>{const button=event.target.closest('[data-split]');if(!button)return;setTimeout(()=>{split=button.dataset.split;state.profile.split=split;save();},0);});
    $('#progressPhotoForm')?.addEventListener('submit',uploadPhoto);
    $('#refreshProgressPhotos')?.addEventListener('click',loadPhotos);
    $('#progressPhotoDate').value=today();
    document.addEventListener('change',(event)=>{if(event.target.matches('[data-grocery]'))toggleGrocery(Number(event.target.dataset.grocery),event.target.checked);if(event.target.matches('[data-plan-portion]'))updatePlannedPortion(Number(event.target.dataset.day),Number(event.target.dataset.meal),Number(event.target.dataset.item),event.target.value);});
    document.addEventListener('click',onDocumentClick);
    if(!window.__fitklotExerciseSafetyGuard){document.addEventListener('click',(event)=>{const button=event.target.closest('#exerciseGrid .btn.secondary');if(!button)return;const name=button.closest('.exercise')?.querySelector('h4')?.textContent||'',exercise=EXERCISES.find((item)=>item[0]===name);if(exercise&&(isExerciseExcluded(name,state.profile||{})||!compatibleEquipment(exercise,state.profile||{}))){event.preventDefault();event.stopImmediatePropagation();toast('This exercise conflicts with your equipment or limitation settings.');}},true);window.__fitklotExerciseSafetyGuard=true;}
    document.addEventListener('click',(event)=>{const filter=event.target.closest('#muscleFilters [data-muscle]');if(filter&&!['Biceps','Triceps'].includes(filter.dataset.muscle)&&$('#exerciseSearch').value){$('#exerciseSearch').value='';renderExercises();}});
    document.addEventListener('click',(event)=>{const button=event.target.closest('[data-exercise-details]');if(button)showExerciseDetails(button.dataset.exerciseDetails);});
    const foodForm=$('#foodForm');
    if(foodForm&&!foodForm.dataset.fiberHandler){
      foodForm.dataset.fiberHandler='1';
      foodForm.addEventListener('submit',(event)=>{
        event.preventDefault();event.stopImmediatePropagation();
        const qty=asNumber($('#foodQty').value),name=$('#foodSearch').value.trim();
        const vals=['foodKcal','foodProt','foodCarb','foodFat'].map((key)=>asNumber($(`#${key}`).value));
        if(!name||qty<=0||qty>3000||vals.some((value)=>value<0)){toast('Check food name, values and serving size.');return;}
        const scale=qty/100;
        state.foods.push({id:id(),date:today(),name,qty,meal:$('#foodMeal').value,kcal:vals[0]*scale,protein:vals[1]*scale,carbs:vals[2]*scale,fat:vals[3]*scale,fiber:$('#foodFiber').value?asNumber($('#foodFiber').value)*scale:null,source:$('#foodSource')?.value||'Manual estimate',sourceId:$('#foodSourceId')?.value||null});
        save();toast('Food added to diary');
      },true);
    }
  }

  function init() {
    ensureState();migrateMeasurementValues();mountNewPages();addProfileFields();installUnitAwareForms();installDataEntryNotices();installPlanEditor();
    baseRenderAll=window.renderAll; if(baseRenderAll&&!window.__fitklotRenderWrapped){window.renderAll=function(...args){baseRenderAll(...args);renderExtras();};window.__fitklotRenderWrapped=true;}
    baseRenderExercises=window.renderExercises;installExerciseDetails();
    baseRenderSession=window.renderSession;if(baseRenderSession&&!window.__fitklotSessionWrapped){window.renderSession=function(...args){const result=baseRenderSession(...args);addPreviousPerformance();formatImperialDisplays();installSessionControls();return result;};window.__fitklotSessionWrapped=true;}
    installImperialSessionLogger();installCoachConsent();installPageHandlers();
    const baseOpenApp=window.openApp;
    if(baseOpenApp&&!window.__fitklotOpenAppWrapped){window.openApp=function(...args){const result=baseOpenApp.apply(this,args);const uid=args[2];if(uid&&!state.profile?.goal){const marker=`fitklot.onboarding.${uid}`;if(!sessionStorage.getItem(marker)){sessionStorage.setItem(marker,'1');setTimeout(startOnboarding,250);}}return result;};window.__fitklotOpenAppWrapped=true;}
    if(sessionUid&&!state.profile?.goal){const marker=`fitklot.onboarding.${sessionUid}`;if(!sessionStorage.getItem(marker)){sessionStorage.setItem(marker,'1');setTimeout(startOnboarding,250);}}
    if(typeof buildNav==='function')buildNav();renderExtras();
    if(reminderTimer)clearInterval(reminderTimer);reminderTimer=setInterval(runReminderChecks,30000);runReminderChecks();
    if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
