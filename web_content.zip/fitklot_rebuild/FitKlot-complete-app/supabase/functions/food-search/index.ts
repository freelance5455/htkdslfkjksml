import { createClient } from "jsr:@supabase/supabase-js@2";
import { normalizeFdcFood } from "../_shared/fooddata.mjs";

const allowedOrigins = (Deno.env.get("FITKLOT_ALLOWED_ORIGINS") || "")
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);

function headersFor(request: Request) {
  const origin = request.headers.get("Origin") || "";
  const originAllowed = !!origin && allowedOrigins.includes(origin);
  return {
    "Access-Control-Allow-Origin": originAllowed ? origin : "null",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin",
  };
}

function respond(request: Request, status: number, payload: Record<string, unknown>) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...headersFor(request), "Content-Type": "application/json" },
  });
}

Deno.serve(async (request: Request) => {
  const origin = request.headers.get("Origin") || "";
  if (origin && !allowedOrigins.includes(origin)) {
    return respond(request, 403, { error: "This site is not allowed to use food search." });
  }
  if (request.method === "OPTIONS") return new Response("ok", { headers: headersFor(request) });
  if (request.method !== "POST") return respond(request, 405, { error: "Method not allowed." });

  const authorization = request.headers.get("Authorization");
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return respond(request, 401, { error: "Sign in to use online food search. Offline food logging remains available." });

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const fdcApiKey = Deno.env.get("USDA_FDC_API_KEY");
  if (!supabaseUrl || !anonKey) return respond(request, 503, { error: "Food-search authentication is not configured." });
  if (!fdcApiKey) return respond(request, 503, { error: "USDA food search is not configured yet. The offline food list remains available." });

  let body: { query?: unknown };
  try {
    const raw = await request.text();
    if (raw.length > 2000) return respond(request, 413, { error: "Shorten the food search query and try again." });
    body = JSON.parse(raw);
  } catch {
    return respond(request, 400, { error: "The food search request could not be read." });
  }

  const query = typeof body.query === "string" ? body.query.trim() : "";
  if (query.length < 2 || query.length > 100) {
    return respond(request, 400, { error: "Enter 2–100 characters to search." });
  }

  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: authData, error: authError } = await userClient.auth.getUser(token);
  if (authError || !authData.user) return respond(request, 401, { error: "Your session has expired. Sign in again." });

  const { data: hasSlot, error: rateError } = await userClient.rpc("claim_fitklot_food_search_slot");
  if (rateError) return respond(request, 503, { error: "Run the latest full-app-schema.sql migration to enable online food search." });
  if (hasSlot !== true) return respond(request, 429, { error: "Food search is temporarily rate-limited. Please try again in a minute." });

  try {
    const endpoint = new URL("https://api.nal.usda.gov/fdc/v1/foods/search");
    endpoint.searchParams.set("api_key", fdcApiKey);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query,
        pageSize: 12,
        pageNumber: 1,
        dataType: ["Foundation", "SR Legacy", "Survey (FNDDS)", "Branded"],
      }),
    });
    if (!response.ok) {
      console.error("USDA FoodData Central request failed with status", response.status);
      return respond(request, 502, { error: "The USDA food database is temporarily unavailable. Use a local reference food or enter a label manually." });
    }
    const result = await response.json();
    const foods = Array.isArray(result.foods)
      ? result.foods.map(normalizeFdcFood).filter(Boolean).slice(0, 12)
      : [];
    return respond(request, 200, { foods, source: "USDA FoodData Central", basis: "per 100 g" });
  } catch (error) {
    console.error("USDA food search failed:", error instanceof Error ? error.name : "unknown error");
    return respond(request, 502, { error: "Could not connect to the USDA food database. Offline food logging remains available." });
  }
});