function nutrient(nutrients, patterns) {
  for (const pattern of patterns) {
    const item = nutrients.find((entry) => {
      const name = String(entry.nutrientName || entry.name || "").toLowerCase();
      return pattern.test(name) && Number.isFinite(Number(entry.value));
    });
    if (item) return { value: Number(item.value), unit: String(item.unitName || "").toLowerCase() };
  }
  return null;
}

export function normalizeFdcFood(food) {
  const nutrients = Array.isArray(food?.foodNutrients) ? food.foodNutrients : [];
  const energy = nutrient(nutrients, [/^energy$/i]);
  const protein = nutrient(nutrients, [/^protein$/i]);
  const carbs = nutrient(nutrients, [/^carbohydrate, by difference$/i, /^carbohydrate$/i]);
  const fat = nutrient(nutrients, [/^total lipid \(fat\)$/i, /^total fat$/i]);
  const fiber = nutrient(nutrients, [/^fiber, total dietary$/i, /^dietary fiber$/i]);
  let calories = energy?.value ?? null;
  if (calories !== null && /^(kj|kilojoule|kilojoules)$/.test(energy.unit)) calories /= 4.184;

  const values = [calories, protein?.value ?? null, carbs?.value ?? null, fat?.value ?? null];
  if (values.some((value) => value === null || !Number.isFinite(value) || value < 0)) return null;
  if (calories > 1000 || values.slice(1).some((value) => value > 100)) return null;

  const fdcId = Number(food.fdcId);
  if (!Number.isInteger(fdcId) || fdcId <= 0) return null;
  const description = String(food.description || "").trim().slice(0, 180);
  if (!description) return null;

  return {
    fdcId,
    name: description,
    dataType: String(food.dataType || "FoodData Central").slice(0, 40),
    brandOwner: String(food.brandOwner || "").slice(0, 80),
    servingSize: food.servingSize == null || food.servingSize === "" ? null : (Number.isFinite(Number(food.servingSize)) ? Number(food.servingSize) : null),
    servingSizeUnit: String(food.servingSizeUnit || "").slice(0, 16),
    kcal: Math.round(calories * 10) / 10,
    protein: Math.round(protein.value * 10) / 10,
    carbs: Math.round(carbs.value * 10) / 10,
    fat: Math.round(fat.value * 10) / 10,
    fiber: fiber ? Math.round(fiber.value * 10) / 10 : null,
    basis: "per 100 g",
    source: "USDA FoodData Central",
    sourceUrl: "https://fdc.nal.usda.gov/food-details/" + fdcId + "/nutrients",
  };
}