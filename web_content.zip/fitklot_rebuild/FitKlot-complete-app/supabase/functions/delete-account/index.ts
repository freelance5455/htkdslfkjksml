import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function respond(status: number, payload: Record<string, unknown>) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return respond(405, { ok: false, message: "Method not allowed." });

  const authorization = request.headers.get("Authorization");
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return respond(401, { ok: false, message: "Sign in again before deleting your account." });

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !anonKey || !serviceRoleKey) {
    return respond(503, { ok: false, message: "Account deletion is not configured on the server." });
  }

  const authClient = createClient(supabaseUrl, anonKey, { auth: { persistSession: false } });
  const { data, error: authError } = await authClient.auth.getUser(token);
  if (authError || !data.user) return respond(401, { ok: false, message: "Your session is invalid or expired." });

  const adminClient = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });
  const { data: buckets, error: bucketError } = await adminClient.storage.listBuckets();
  if (bucketError) return respond(500, { ok: false, message: "Private account files could not be checked. No account changes were made." });
  if (buckets.some((bucket) => bucket.name === "progress-photos")) {
    const paths: string[] = [];
    for (let offset = 0; ; offset += 500) {
      const { data: files, error: listError } = await adminClient.storage
        .from("progress-photos")
        .list(data.user.id, { limit: 500, offset, sortBy: { column: "name", order: "asc" } });
      if (listError) return respond(500, { ok: false, message: "Private account photos could not be listed. No account changes were made." });
      paths.push(...(files || []).filter((file) => file.id).map((file) => `${data.user.id}/${file.name}`));
      if (!files || files.length < 500) break;
    }
    if (paths.length) {
      const { error: photoError } = await adminClient.storage.from("progress-photos").remove(paths);
      if (photoError) return respond(500, { ok: false, message: "Private account photos could not be deleted. No account changes were made." });
    }
  }
  const { error: deleteError } = await adminClient.auth.admin.deleteUser(data.user.id);
  if (deleteError) return respond(500, { ok: false, message: "The account could not be deleted. No account changes were confirmed." });

  return respond(200, { ok: true });
});
