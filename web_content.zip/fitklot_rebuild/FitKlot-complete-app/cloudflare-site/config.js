/* FitKlot AI public configuration.
   The publishable key is intended for browser use. Never put a Supabase secret/service-role key here. */
window.FITKLOT_CONFIG = {
  supabaseUrl: "https://vyqhcmxyabrscibshfte.supabase.co",
  supabaseAnonKey: "sb_publishable_HGnK9AQJ7J3vhB1oGeN3yA_2dpsxk4q",
  paymentApiBase: "/api",
};
