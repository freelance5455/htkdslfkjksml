-- FitKlot AI verified monthly membership payments (₹50 / 30 days)
-- Safe additive repair for missing membership/payment schema objects.
-- Run after full-app-schema.sql instead of payment-schema.sql.
-- This file intentionally does not drop legacy promo functions/tables or user data.
-- Keep the service-role key server-side; only the payment Worker may activate membership.

create table if not exists public.fitklot_memberships (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text not null default 'inactive' check (status in ('active','inactive','expired')),
  plan text not null default 'monthly' check (plan = 'monthly'),
  started_at timestamptz,
  expires_at timestamptz,
  last_payment_id text unique,
  updated_at timestamptz not null default now()
);

create table if not exists public.fitklot_payment_orders (
  order_id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount = 5000),
  currency text not null default 'INR' check (currency = 'INR'),
  status text not null default 'created' check (status in ('created','paid','failed')),
  payment_id text unique,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create index if not exists fitklot_payment_orders_user_idx on public.fitklot_payment_orders(user_id, created_at desc);
alter table public.fitklot_memberships enable row level security;
alter table public.fitklot_payment_orders enable row level security;
revoke all on public.fitklot_memberships from anon, authenticated;
revoke all on public.fitklot_payment_orders from anon, authenticated;
grant select on public.fitklot_memberships to authenticated;
grant select on public.fitklot_payment_orders to authenticated;
drop policy if exists "Users can view their own membership" on public.fitklot_memberships;
create policy "Users can view their own membership" on public.fitklot_memberships for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can view their own payment orders" on public.fitklot_payment_orders;
create policy "Users can view their own payment orders" on public.fitklot_payment_orders for select to authenticated using (auth.uid() = user_id);

-- Only the server (service_role) can execute this function after verifying Razorpay signature AND captured payment.
create or replace function public.fitklot_activate_monthly_membership(p_order_id text, p_payment_id text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  o public.fitklot_payment_orders%rowtype;
  old_expiry timestamptz;
  new_start timestamptz;
  new_expiry timestamptz;
begin
  select * into o from public.fitklot_payment_orders where order_id = p_order_id for update;
  if not found then
    return jsonb_build_object('ok', false, 'message', 'Payment order not found.');
  end if;
  if o.amount <> 5000 or o.currency <> 'INR' then
    return jsonb_build_object('ok', false, 'message', 'Payment amount or currency is invalid.');
  end if;
  if o.status = 'paid' then
    if o.payment_id = p_payment_id then
      select expires_at into new_expiry from public.fitklot_memberships where user_id = o.user_id;
      return jsonb_build_object('ok', true, 'already_processed', true, 'expires_at', new_expiry, 'user_id', o.user_id);
    end if;
    return jsonb_build_object('ok', false, 'message', 'This order has already been processed.');
  end if;
  if o.status <> 'created' then
    return jsonb_build_object('ok', false, 'message', 'This payment order is not payable.');
  end if;
  select expires_at into old_expiry from public.fitklot_memberships where user_id = o.user_id for update;
  new_start := greatest(coalesce(old_expiry, now()), now());
  new_expiry := new_start + interval '1 month';
  insert into public.fitklot_memberships(user_id,status,plan,started_at,expires_at,last_payment_id,updated_at)
  values(o.user_id,'active','monthly',new_start,new_expiry,p_payment_id,now())
  on conflict(user_id) do update set status='active', plan='monthly', started_at=new_start,
    expires_at=new_expiry, last_payment_id=p_payment_id, updated_at=now();
  update public.fitklot_payment_orders set status='paid', payment_id=p_payment_id, paid_at=now() where order_id=p_order_id;
  return jsonb_build_object('ok', true, 'already_processed', false, 'expires_at', new_expiry, 'user_id', o.user_id);
end;
$function$;

revoke all on function public.fitklot_activate_monthly_membership(text,text) from public, anon, authenticated;
grant execute on function public.fitklot_activate_monthly_membership(text,text) to service_role;
notify pgrst, 'reload schema';

-- Local post-apply check: all three values should be true.
select
  to_regclass('public.fitklot_memberships') is not null as membership_table_exists,
  to_regclass('public.fitklot_payment_orders') is not null as payment_orders_table_exists,
  to_regprocedure('public.fitklot_activate_monthly_membership(text,text)') is not null as activation_function_exists;

