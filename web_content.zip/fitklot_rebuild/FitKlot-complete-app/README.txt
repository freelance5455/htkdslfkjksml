# FitKlot AI

FitKlot is a responsive, local-first fitness app for desktop and mobile browsers. The guest tracker works offline; Supabase accounts, private cloud sync, private photo storage and the optional online AI coach require the setup below. The interface adapts to phone and desktop layouts, has dark mode by default, and can switch to light mode.

## Run the app

Open `index.html` in a browser for local guest use, or serve this folder over HTTP to enable the installable PWA shell and service worker. Guest data stays in that browser on that device. Use a private device for fitness records. Export a JSON backup in Settings before changing browsers or devices.

## Android APK

An Android WebView project is included in `android/`, with its launcher manifest at `android/app/src/main/AndroidManifest.xml` and a bundled offline copy of the web app. It supports Android 10 (API 29) through API 37. Open the `android/` folder in Android Studio and follow `android/README_ANDROID.txt` to build and install a debug APK. This package contains the Android project files, not a prebuilt APK; an Android SDK/JDK build environment is required to create the APK.

## Included modules

- Dashboard, guided onboarding and editable fitness profile.
- Workout split planner, exercise library and favorites, live sessions, rest timer, pause/resume, previous performance, repeat workout, editable routines, workout history and personal records.
- Food diary, calorie and macro totals, adjustable portions, reusable meals, editable seven-day meal plans and grocery lists. Built-in Indian food values are generic estimates; authenticated users can optionally search USDA FoodData Central online when configured.
- Weight and body measurement logs, BMI screening estimate, optional user-entered body-fat estimate, weight trend charts and progress analytics.
- Optional recovery, sleep, energy, soreness, hydration, in-app reminders and browser notifications while the app is open.
- Private progress photos when a private Supabase Storage bucket is configured.
- Offline rule-based coach. A separate opt-in online coach endpoint is included but needs an OpenAI key and deployment.
- Data export, local/cloud data deletion, account deletion, dark/light themes and a PWA cache for the static app shell.
- Native WebGL dumbbell preview with pointer and keyboard rotation, lightweight scroll reveals that respect reduced-motion settings, and a WebXR surface-placement AR preview when the device/browser supports it.

## Nutrition and health limits

Food records in the built-in list are generic estimates copied from the original offline reference list; they are not a verified nutrition database. Optional USDA FoodData Central search returns source-labelled generic or branded records and stores the FDC ID with logged entries. It requires internet access, a USDA data.gov key stored server-side, and deployment of the food-search function. Its Indian-food coverage varies, and recipe, brand, serving and cooking differences still matter. Verify package labels where available. No barcode scanner or exercise demo video is included.

BMI and energy requirements are estimates. Automatic calorie estimation requires an adult age, height, weight, activity level and a voluntary sex selection; otherwise set a manual target. Profile warnings flag very low calorie and unusually high protein targets; calorie-scaled meal plans are blocked for users under 18 with a manual calorie target and for manual targets below 1,200 kcal/day. These safeguards do not establish that any other target is safe. Body-fat, lean-body-mass and fat-mass values are shown only when the user enters a body-fat percentage. The app does not diagnose conditions or promise a goal date. For injuries, persistent symptoms, medical conditions or specialized diets, consult a qualified professional.

The 3D preview is generated locally and needs no model CDN. AR is optional and is enabled only when the browser reports immersive AR support; camera access, HTTPS and device/browser support are required. If AR or WebGL is unavailable, the rest of the app remains usable and the 3D stage shows a fallback. Scroll animations are disabled for users who request reduced motion. AR has not been hardware-tested on every supported device.

## Supabase setup (optional cloud features)

1. Configure Supabase Auth URLs for the deployed site. To allow signup without confirmation, turn off Confirm email in Authentication → Sign In / Providers → Email.
2. In Supabase SQL Editor, run `full-app-schema.sql`, then `payment-schema.sql`. For payment setup, follow `PAYMENTS-SETUP.md`.
3. Deploy account deletion and optional food lookup with supabase functions deploy delete-account and supabase functions deploy food-search. Deploy the online coach with supabase functions deploy coach when its OpenAI key is configured.
4. Publish `config.js` with the project URL and publishable/anon key only. Never put a Supabase service-role key in browser files.
5. For private photos, create a **private** Storage bucket named `progress-photos`. Apply the Storage policies in `full-app-schema.sql`. Object names are scoped under each user's UUID.
6. The app calls `sync_fitklot_state` for authenticated saves. Personal tables are protected with row-level security. Guest data never uploads.

The SQL creates owner-scoped relational tables for profiles, exercises and foods, workout plans and sets, weight/body measurements, food logs, summaries, saved meals, weekly meal plans, groceries, hydration, recovery, personal records, notifications, reminders, photo metadata and coach request limits. It also retains a private JSON snapshot for compatibility and recovery.

## Optional online AI coach

Public visitors can browse the dashboard. Workout, nutrition, coach and progress sections are locked until the server confirms an active membership. The local offline coach remains available after membership activation. The online coach asks for explicit consent each time, sends a minimized profile/log summary without the user's name or photos, applies rate limiting and safety instructions, and uses the OpenAI Responses API only from a Supabase Edge Function.

To enable it, configure the OpenAI Platform connection/key, then set secrets in the Supabase project (never in `config.js`):

```text
OPENAI_API_KEY=<your server-side key>
OPENAI_MODEL=gpt-5.4-mini
FITKLOT_ALLOWED_ORIGINS=https://your-deployed-domain.example
```

Set secrets with the Supabase CLI or dashboard, then deploy `supabase/functions/coach` using `supabase functions deploy coach`. Run the latest `full-app-schema.sql` first. Until the key and function are configured and tested, the online coach reports that it is unavailable and the local coach continues to work.

## Optional USDA FoodData Central lookup

Create a free data.gov API key for USDA FoodData Central. Store it as the Supabase Edge Function secret USDA_FDC_API_KEY, never in config.js. Set FITKLOT_ALLOWED_ORIGINS to the deployed site origin, then deploy supabase/functions/food-search with supabase functions deploy food-search. Authenticated users can search this database online; guest and offline food logging continue to use built-in estimates and manual entries. The app stores the USDA source name and FDC ID with each selected entry, with a link to the source record.

USDA FoodData Central data are public domain and USDA requests attribution. Search is rate-limited per signed-in user. See the [USDA API Guide](https://fdc.nal.usda.gov/api-guide/) for key setup, usage limits, data types and attribution. USDA records are not a complete Indian food database, and nutrient values remain estimates for the selected item and preparation.
## Cloudflare deploy

The configured Worker publishes only `cloudflare-site/`. From this project root, run `npx wrangler login` once and then `npx wrangler deploy`. Alternatively, use the included `cloudflare-static-upload.zip` for Cloudflare Pages Direct Upload. Do not upload the outer source ZIP as if it were the static site; it includes SQL and Supabase TypeScript backend files that are not browser assets. See `CLOUDFLARE_DEPLOY.txt`.

## Features that still need external configuration

- Supabase project/Auth, schema migrations, Storage bucket and Edge Function deployment are not preconfigured here.
- OpenAI secret provisioning and online coach deployment are not complete until OpenAI Platform is connected and Supabase secrets are configured. USDA food lookup also remains unavailable until its data.gov key is stored as a Supabase secret and the function is deployed.
- Automatic payment activation requires the Razorpay Cloudflare Worker, secrets, database SQL and webhook described in PAYMENTS-SETUP.md. It is not live until those are configured and tested.
- Browser reminders require permission and only run while the app is open. Push delivery is not configured.
- No barcode scanner or exercise demonstration videos are connected.

The public Supabase publishable key in `config.js` is intended for browser use. Protect all personal data with the included RLS policies and never expose privileged keys.


Membership: one ₹50/month plan; promo codes removed. Automatic unlocking requires the configured Razorpay Worker. Read PAYMENTS-SETUP.md before publishing.
