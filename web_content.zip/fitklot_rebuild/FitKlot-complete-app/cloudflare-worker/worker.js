const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
function json(data, status = 200, origin = '*') { return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, 'access-control-allow-origin': origin, 'access-control-allow-headers': 'authorization, content-type, x-razorpay-signature', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'vary': 'Origin' } }); }
function fail(message, status, origin) { return json({ ok: false, error: message }, status, origin); }
function corsOrigin(request, env) { const origin = request.headers.get('Origin') || ''; const allowed = (env.ALLOWED_ORIGINS || 'https://klot.in,https://www.klot.in').split(',').map(s => s.trim()); return allowed.includes(origin) ? origin : allowed[0]; }
async function hmacHex(secret, value) { const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value)); return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, '0')).join(''); }
function timingSafeEqual(a, b) { if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false; let out = 0; for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i); return out === 0; }
function basic(key, secret) { return 'Basic ' + btoa(key + ':' + secret); }
async function authUser(request, env) {
  const bearer = request.headers.get('Authorization') || '';
  if (!bearer.startsWith('Bearer ')) throw new Error('Please sign in to continue.');
  const response = await fetch(env.SUPABASE_URL.replace(/\/$/, '') + '/auth/v1/user', { headers: { apikey: env.SUPABASE_PUBLISHABLE_KEY, Authorization: bearer } });
  if (!response.ok) throw new Error('Your session is invalid or expired. Please sign in again.');
  return await response.json();
}
async function supabaseRest(env, path, options = {}) {
  const response = await fetch(env.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/' + path, {
    method: options.method || 'GET',
    headers: { apikey: env.SUPABASE_SERVICE_ROLE_KEY, Authorization: 'Bearer ' + env.SUPABASE_SERVICE_ROLE_KEY, 'content-type': 'application/json', Prefer: options.prefer || 'return=representation', ...(options.headers || {}) },
    body: options.body === undefined ? undefined : JSON.stringify(options.body)
  });
  const text = await response.text();
  let data; try { data = text ? JSON.parse(text) : null; } catch (_) { data = { raw: text }; }
  if (!response.ok) throw new Error(data?.message || data?.hint || data?.error || 'Database request failed.');
  return data;
}
async function rpcActivate(env, orderId, paymentId) {
  const result = await supabaseRest(env, 'rpc/fitklot_activate_monthly_membership', { method: 'POST', body: { p_order_id: orderId, p_payment_id: paymentId } });
  if (!result || result.ok !== true) throw new Error(result?.message || 'Membership activation was not confirmed.');
  return result;
}
async function getOrder(env, orderId, userId) {
  const rows = await supabaseRest(env, `fitklot_payment_orders?order_id=eq.${encodeURIComponent(orderId)}&user_id=eq.${encodeURIComponent(userId)}&select=order_id,user_id,amount,currency,status,payment_id`);
  return Array.isArray(rows) ? rows[0] : null;
}
async function createOrder(request, env, origin) {
  const user = await authUser(request, env);
  if (!env.RAZORPAY_KEY_ID || !env.RAZORPAY_KEY_SECRET || !env.SUPABASE_SERVICE_ROLE_KEY) return fail('Payment setup is incomplete. Contact FitKlot support.', 503, origin);
  const payload = await request.json().catch(() => ({}));
  if (payload.plan !== 'monthly') return fail('Only the ₹50 monthly plan is available.', 400, origin);
  const create = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST', headers: { Authorization: basic(env.RAZORPAY_KEY_ID, env.RAZORPAY_KEY_SECRET), 'content-type': 'application/json' },
    body: JSON.stringify({ amount: 5000, currency: 'INR', receipt: ('fk_' + user.id.replace(/-/g, '').slice(0, 18) + '_' + Date.now().toString(36)).slice(0, 40), notes: { user_id: user.id, plan: 'monthly', product: 'FitKlot AI' } })
  });
  const order = await create.json().catch(() => ({}));
  if (!create.ok || !order.id) return fail(order.error?.description || 'Could not create secure checkout order.', 502, origin);
  await supabaseRest(env, 'fitklot_payment_orders', { method: 'POST', prefer: 'resolution=merge-duplicates,return=representation', body: { order_id: order.id, user_id: user.id, amount: 5000, currency: 'INR', status: 'created' } });
  return json({ ok: true, key_id: env.RAZORPAY_KEY_ID, order_id: order.id, amount: 5000, currency: 'INR', email: user.email || '' }, 200, origin);
}
async function verifyPayment(request, env, origin) {
  const user = await authUser(request, env);
  const body = await request.json().catch(() => ({}));
  const { order_id, payment_id, signature } = body;
  if (![order_id, payment_id, signature].every(v => typeof v === 'string' && v.length > 5)) return fail('Payment verification details are incomplete.', 400, origin);
  const order = await getOrder(env, order_id, user.id);
  if (!order) return fail('This payment order does not belong to your account.', 403, origin);
  if (order.status === 'paid' && order.payment_id === payment_id) {
    const rows = await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(user.id)}&select=status,expires_at`);
    return json({ ok: true, active: rows?.[0]?.status === 'active' && Date.parse(rows[0].expires_at) > Date.now(), expires_at: rows?.[0]?.expires_at }, 200, origin);
  }
  const expected = await hmacHex(env.RAZORPAY_KEY_SECRET, order_id + '|' + payment_id);
  if (!timingSafeEqual(expected, signature)) return fail('Payment signature could not be verified.', 400, origin);
  const paymentResponse = await fetch('https://api.razorpay.com/v1/payments/' + encodeURIComponent(payment_id), { headers: { Authorization: basic(env.RAZORPAY_KEY_ID, env.RAZORPAY_KEY_SECRET) } });
  const payment = await paymentResponse.json().catch(() => ({}));
  if (!paymentResponse.ok || payment.status !== 'captured' || payment.order_id !== order_id || payment.amount !== 5000 || payment.currency !== 'INR') return fail('Payment is not captured for the exact ₹50 monthly order yet. Please wait and restore membership before paying again.', 409, origin);
  const activated = await rpcActivate(env, order_id, payment_id);
  const rows = await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(user.id)}&select=status,expires_at`);
  const membership = rows?.[0];
  if (!membership || membership.status !== 'active') return fail('Payment was verified, but membership status could not be read. Contact support; do not pay again.', 500, origin);
  return json({ ok: true, active: true, expires_at: membership.expires_at, already_processed: !!activated.already_processed }, 200, origin);
}
async function ensureOwnerPremium(user, env) {
  const adminEmail = (env.ADMIN_EMAIL || 'priyanshujangraaaawork@gmail.com').trim().toLowerCase();
  if (!user.email || user.email.toLowerCase() !== adminEmail) return null;
  if (!env.SUPABASE_SERVICE_ROLE_KEY) throw new Error('Admin backend is not configured with a server-side database key.');
  const rows = await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(user.id)}&select=user_id,status,plan,started_at,expires_at`);
  const current = rows?.[0];
  const now = new Date();
  const expiry = new Date(now);
  expiry.setUTCFullYear(expiry.getUTCFullYear() + 100);
  // Avoid rewriting the row on every membership check once the 100-year grant exists.
  const sufficientlyLong = current?.status === 'active' && current.expires_at && Date.parse(current.expires_at) > Date.now() + 99 * 365.25 * 24 * 60 * 60 * 1000;
  if (!sufficientlyLong) {
    const patch = { status: 'active', plan: 'monthly', started_at: now.toISOString(), expires_at: expiry.toISOString(), updated_at: now.toISOString() };
    if (current) await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(user.id)}`, { method: 'PATCH', body: patch });
    else await supabaseRest(env, 'fitklot_memberships', { method: 'POST', body: { user_id: user.id, ...patch } });
  }
  return { active: true, plan: 'monthly', expires_at: sufficientlyLong ? current.expires_at : expiry.toISOString() };
}

async function membership(request, env, origin) {
  const user = await authUser(request, env);
  const ownerGrant = await ensureOwnerPremium(user, env);
  if (ownerGrant) return json({ ok: true, active: true, plan: 'monthly', expires_at: ownerGrant.expires_at, owner_premium: true }, 200, origin);
  const rows = await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(user.id)}&select=status,plan,started_at,expires_at`);
  const m = rows?.[0]; const active = !!m && m.status === 'active' && Date.parse(m.expires_at) > Date.now();
  return json({ ok: true, active, plan: active ? 'monthly' : null, expires_at: m?.expires_at || null }, 200, origin);
}
async function webhook(request, env, origin) {
  const raw = await request.text();
  const supplied = request.headers.get('X-Razorpay-Signature') || '';
  if (!env.RAZORPAY_WEBHOOK_SECRET) return fail('Webhook is not configured.', 503, origin);
  const expected = await hmacHex(env.RAZORPAY_WEBHOOK_SECRET, raw);
  if (!timingSafeEqual(expected, supplied)) return fail('Invalid webhook signature.', 400, origin);
  const event = JSON.parse(raw);
  if (event.event === 'payment.captured') {
    const payment = event.payload?.payment?.entity;
    if (payment && payment.status === 'captured' && payment.amount === 5000 && payment.currency === 'INR' && payment.order_id) {
      const orders = await supabaseRest(env, `fitklot_payment_orders?order_id=eq.${encodeURIComponent(payment.order_id)}&select=order_id,user_id,amount,currency,status`);
      if (orders?.[0] && orders[0].amount === 5000 && orders[0].currency === 'INR') await rpcActivate(env, payment.order_id, payment.id);
    }
  }
  return json({ ok: true }, 200, origin);
}

async function requireAdmin(request, env) {
  const user = await authUser(request, env);
  const adminEmail = (env.ADMIN_EMAIL || 'priyanshujangraaaawork@gmail.com').trim().toLowerCase();
  if (!adminEmail) throw new Error('Admin is not configured. Set ADMIN_EMAIL in Cloudflare Worker variables.');
  if (!user.email || user.email.toLowerCase() !== adminEmail) throw new Error('Forbidden: this account is not the configured admin.');
  if (!env.SUPABASE_SERVICE_ROLE_KEY) throw new Error('Admin backend is not configured with a server-side database key.');
  return user;
}
async function adminMemberships(request, env, origin) {
  await requireAdmin(request, env);
  const rows = await supabaseRest(env, 'fitklot_memberships?select=user_id,status,plan,started_at,expires_at,updated_at&order=updated_at.desc');
  return json({ ok: true, memberships: rows || [] }, 200, origin);
}
async function adminChangeMembership(request, env, origin) {
  await requireAdmin(request, env);
  const body = await request.json().catch(() => ({}));
  const userId = typeof body.user_id === 'string' ? body.user_id : '';
  const action = body.action;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(userId)) return fail('Invalid user ID.', 400, origin);
  if (!['grant','revoke'].includes(action)) return fail('Unsupported admin action.', 400, origin);
  const existing = await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(userId)}&select=user_id`);
  const now = new Date();
  const patch = action === 'grant'
    ? { status: 'active', plan: 'monthly', started_at: now.toISOString(), expires_at: new Date(now.getTime()+30*24*60*60*1000).toISOString(), updated_at: now.toISOString() }
    : { status: 'inactive', updated_at: now.toISOString() };
  if (existing && existing.length) {
    await supabaseRest(env, `fitklot_memberships?user_id=eq.${encodeURIComponent(userId)}`, { method: 'PATCH', prefer: 'return=representation', body: patch });
  } else {
    if (action === 'revoke') return json({ ok: true, action, message: 'No membership existed for this account.' }, 200, origin);
    await supabaseRest(env, 'fitklot_memberships', { method: 'POST', prefer: 'return=representation', body: { user_id: userId, ...patch } });
  }
  return json({ ok: true, action }, 200, origin);
}

export default {
  async fetch(request, env) {
    const origin = corsOrigin(request, env);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'access-control-allow-origin': origin, 'access-control-allow-headers': 'authorization, content-type, x-razorpay-signature', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-max-age': '86400', 'vary': 'Origin' } });
    const url = new URL(request.url);
    try {
      if (url.pathname === '/api/admin/memberships' && request.method === 'GET') return await adminMemberships(request, env, origin);
      if (url.pathname === '/api/admin/membership' && request.method === 'POST') return await adminChangeMembership(request, env, origin);
      if (url.pathname === '/api/create-order' && request.method === 'POST') return await createOrder(request, env, origin);
      if (url.pathname === '/api/verify-payment' && request.method === 'POST') return await verifyPayment(request, env, origin);
      if (url.pathname === '/api/membership' && request.method === 'GET') return await membership(request, env, origin);
      if (url.pathname === '/api/razorpay-webhook' && request.method === 'POST') return await webhook(request, env, origin);
      return fail('Not found.', 404, origin);
    } catch (e) {
      return fail(e?.message || 'Unexpected payment service error.', 500, origin);
    }
  }
};
