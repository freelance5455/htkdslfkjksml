# FitKlot AI payments — ₹50/month

This build has one paid plan only: ₹50 for one calendar month (the database extends access by one calendar month). Promo codes and weekly/yearly offers have been removed from the app UI and SQL setup.

## Important: live automatic unlocking requires account setup

The ZIP contains the Razorpay checkout integration and a Cloudflare Worker. Payment is not live until you configure your own Razorpay account and deploy the Worker. Never place Razorpay secrets or a Supabase service-role key in browser files.

## 1. Supabase

1. Open the Supabase SQL Editor for the project configured in `config.js`.
2. Run `full-app-schema.sql` if not already applied.
3. Run `payment-schema.sql`. It creates the private membership/order tables and a server-only, idempotent activation RPC.
4. Authentication → Sign In / Providers → Email: turn **Confirm email** OFF if you want signup without email confirmation.
5. Authentication → URL Configuration: Site URL `https://klot.in`, allowed redirect URL `https://klot.in/**`.
6. The earlier Supabase secret key was exposed in chat. Revoke/rotate it before production. Use the new service-role key only as a Cloudflare Worker secret. Never paste it into `config.js`.

## 2. Razorpay

1. Create/verify a Razorpay account and enable the payment methods you want to accept. Use Test Mode first.
2. In Cloudflare, deploy `cloudflare-worker/worker.js` as a Worker named `fitklot-payment-api`. Bind the route `klot.in/api/*` (and `www.klot.in/api/*` if your site uses www) to this Worker.
3. Add these Worker secrets/variables. Secrets should be added with Cloudflare's secret UI or `wrangler secret put`, not committed into the ZIP:
   - `RAZORPAY_KEY_ID` (secret variable; the ID is not a password but keep the pair together)
   - `RAZORPAY_KEY_SECRET` (secret)
   - `RAZORPAY_WEBHOOK_SECRET` (secret)
   - `SUPABASE_SERVICE_ROLE_KEY` (secret; rotate the previously exposed key first)
   - `SUPABASE_PUBLISHABLE_KEY` (the browser-safe publishable key from the Supabase project)
   - `SUPABASE_URL` = `https://vyqhcmxyabrscibshfte.supabase.co`
   - `ALLOWED_ORIGINS` = `https://klot.in,https://www.klot.in`
4. Set `paymentApiBase` in the public `config.js` to `/api` when the Worker is routed on the same domain.
5. In Razorpay Webhooks, add `https://klot.in/api/razorpay-webhook` and subscribe to `payment.captured`. Set the webhook secret to the same `RAZORPAY_WEBHOOK_SECRET`.
6. Test with Razorpay Test Mode and test cards/UPI. Only after test mode works should you switch to live keys. Do not accept a screenshot or UTR as proof of automatic payment.

## 3. Expected flow

- Visitors can browse the dashboard. Premium pages redirect to the plan screen until the server reports an active membership. Plans & Payment, Help Desk, and Settings remain accessible.
- Checkout creates a ₹50 INR Razorpay order on the server. The server verifies the signed checkout response and independently checks that the payment is captured for the correct ₹50 order.
- The database RPC activates membership once per payment and sets the expiry one calendar month from now (or from the current expiry when renewing). Repeated verification does not add a second month.
- On verified success, checkout completes, a Congratulations popup appears, and the app returns to Dashboard.

## 4. Before going live

- Run the SQL in a test project first and review RLS policies.
- Verify test payments, declined payments, cancel/close checkout, duplicate callbacks, expired membership, renewals, logout/login on a second device, and webhook delivery.
- Ensure the Razorpay account is approved for live transactions and that your terms/refund/contact details are published.
- This package has not been connected to your Razorpay account or tested against live Supabase. The automatic flow becomes active only after you complete these configuration steps.

## UPI QR payment review form (added in this build)
The pricing page includes date, time, and UPI transaction ID fields for users who paid using the QR code. The submission is stored as `pending` in `fitklot_upi_payment_submissions`; it does NOT unlock membership by itself. A UTR typed by a user is not proof that funds were received. Verify the payment in your UPI/bank account before granting access through a secure, admin-controlled process. Apply the updated `payment-schema.sql` in Supabase before using this form. The Worker route `/api/upi-submission` is included in this ZIP.
