import RNFS from 'react-native-fs';
import { initLlama } from 'llama.rn';

const MODEL_FILE = 'qwen2.5-1.5b-instruct-q4_k_m.gguf';
const MODEL_URL =
  'https://huggingface.co/unsloth/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf';

class OfflineAIModelManager {
  constructor() {
    this.localModelPath = `${RNFS.DocumentDirectoryPath}/${MODEL_FILE}`;
    this.context = null;
    this.downloadJob = null;
  }

  async isModelDownloaded() {
    try {
      const exists = await RNFS.exists(this.localModelPath);
      if (!exists) return false;
      const stat = await RNFS.stat(this.localModelPath);
      return Number(stat.size) > 0;
    } catch {
      return false;
    }
  }

  async downloadModel(onProgress) {
    // Remove an incomplete file left by an interrupted download.
    if (await RNFS.exists(this.localModelPath)) {
      await RNFS.unlink(this.localModelPath);
    }

    this.downloadJob = RNFS.downloadFile({
      fromUrl: MODEL_URL,
      toFile: this.localModelPath,
      progressDivider: 1,
      progress: ({ bytesWritten, contentLength }) => {
        const percent =
          contentLength > 0
            ? Math.min(100, (bytesWritten / contentLength) * 100)
            : 0;
        onProgress?.(percent);
      },
    });

    try {
      const result = await this.downloadJob.promise;
      if (result.statusCode !== 200) {
        throw new Error(`Model download failed (HTTP ${result.statusCode}).`);
      }

      const stat = await RNFS.stat(this.localModelPath);
      if (!Number(stat.size)) {
        throw new Error('The downloaded model file is empty.');
      }
      onProgress?.(100);
      return this.localModelPath;
    } catch (error) {
      if (await RNFS.exists(this.localModelPath)) {
        await RNFS.unlink(this.localModelPath).catch(() => {});
      }
      throw error;
    } finally {
      this.downloadJob = null;
    }
  }

  async cancelDownload() {
    if (this.downloadJob?.jobId != null) {
      RNFS.stopDownload(this.downloadJob.jobId);
    }
  }

  async loadModel() {
    if (this.context) return this.context;

    if (!(await this.isModelDownloaded())) {
      throw new Error('Offline model is not downloaded yet. Download it first.');
    }

    // Start conservatively for Android phones. Increase n_ctx only after testing
    // available RAM. GPU offload support depends on the device/build.
    this.context = await initLlama({
      model: this.localModelPath,
      n_ctx: 2048,
      n_gpu_layers: 0,
    });

    return this.context;
  }

  async generate(prompt, onToken) {
    const context = await this.loadModel();

    // Qwen2.5 Instruct chat template for a single user message.
    const formattedPrompt =
      `<|im_start|>system\nYou are MindMate AI, a helpful assistant. ` +
      `Answer clearly and safely.<|im_end|>\n` +
      `<|im_start|>user\n${prompt}<|im_end|>\n` +
      `<|im_start|>assistant\n`;

    const result = await context.completion(
      {
        prompt: formattedPrompt,
        n_predict: 256,
        temperature: 0.7,
        stop: ['<|im_end|>', '<|im_start|>'],
      },
      (data) => {
        if (data?.token) onToken?.(data.token);
      },
    );

    return result?.text ?? '';
  }

  async release() {
    if (this.context) {
      await this.context.release?.();
      this.context = null;
    }
  }
}

export default new OfflineAIModelManager();
