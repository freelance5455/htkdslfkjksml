TradeSignal AI V4.6.6 — Laboratório de Ablação do Score

Objetivo: identificar matematicamente o componente T/M/V/R/P com maior evidência de vazamento de performance.

O motor V4.6.6 permanece congelado. Cada teste retira temporariamente uma família do score e compara com a referência.

Componentes:
T = Trend
M = Momentum
V = Volume
R = Regime
P = Potential

Históricos: 3K, 5K, 15K. Horizontes: H3, H5, H10, H20.

Métricas: sinais, Delta sinais, edge bruto/op, líquido/op, acumulado, DD, PF, efeito e ICC.

ICC >= 80 = candidato a culpado provável; não autoriza alteração do motor sozinho. A decisão causal exige melhora de edge e líquido em pelo menos 2/3 históricos, sem aumento relevante de DD.
