SATORU VPS — website preview

1. Extract this ZIP.
2. Open index.html in Chrome to preview locally.
3. To publish free: create a Cloudflare account, open Workers & Pages > Create > Pages, and upload the extracted site files using Direct Upload (or connect a Git repository).
4. This is a static marketing-site preview only. It does not create VPS instances, accept payments, or manage customer servers.
5. Do not advertise the illustrative plans as available products until you have real server capacity, security, support, billing and provisioning configured.
