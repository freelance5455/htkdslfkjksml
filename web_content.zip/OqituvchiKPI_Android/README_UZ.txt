O'QITUVCHI KPI — ANDROID ILOVA LOYIHASI

1. Android Studio o'rnating.
2. Ushbu papkani Android Studio orqali Open qiling.
3. Gradle Sync tugashini kuting.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ni bosing.
5. app-debug.apk hosil bo'ladi.

Ilova internet talab qilmaydi: ma'lumotlar telefonning localStorage xotirasida saqlanadi.

Hozirgi versiya:
- 45 o'qituvchi namunasi
- 8 hujjat turi
- hujjatni ko'rib belgilash
- KPI avtomatik hisoblash
- kamchiliklar ro'yxati
- haftalik/oylik ko'rinish
- ballarni Sozlamalar orqali o'zgartirish
