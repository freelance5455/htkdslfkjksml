import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return Response.json({ valid: false, message: "Method not allowed" }, { status: 405, headers: cors });
  try {
    const { code, device_id } = await req.json();
    if (typeof code !== "string" || typeof device_id !== "string" || !/^[A-Z0-9_-]{1,32}$/i.test(code) || device_id.length < 5 || device_id.length > 100) {
      return Response.json({ valid: false, message: "Некорректный промокод." }, { status: 400, headers: cors });
    }
    const url = Deno.env.get("SUPABASE_URL")!;
    const key = Deno.env.get("PROMO_SERVICE_ROLE_KEY")!;
    const supabase = createClient(url, key);
    const { data, error } = await supabase.rpc("redeem_promo", { p_code: code.toUpperCase().trim(), p_device_id: device_id });
    if (error) throw error;
    return Response.json(data, { status: 200, headers: cors });
  } catch (e) {
    console.error(e);
    return Response.json({ valid: false, message: "Ошибка сервера. Попробуй позже." }, { status: 500, headers: cors });
  }
});
