gdjs.LoseCode = {};
gdjs.LoseCode.localVariables = [];
gdjs.LoseCode.GDNewSpriteObjects1= [];
gdjs.LoseCode.GDNewSpriteObjects2= [];
gdjs.LoseCode.GDNewTextObjects1= [];
gdjs.LoseCode.GDNewTextObjects2= [];
gdjs.LoseCode.GDNewText2Objects1= [];
gdjs.LoseCode.GDNewText2Objects2= [];
gdjs.LoseCode.GDNewText3Objects1= [];
gdjs.LoseCode.GDNewText3Objects2= [];
gdjs.LoseCode.GDNewSprite2Objects1= [];
gdjs.LoseCode.GDNewSprite2Objects2= [];


gdjs.LoseCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(0.015);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9318852);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "(Oopsies!) Five Night's at Freddy's FREE");
}{gdjs.evtTools.sound.playSound(runtimeScene, "audio_musicnear.mp3", true, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText3"), gdjs.LoseCode.GDNewText3Objects1);
{for(var i = 0, len = gdjs.LoseCode.GDNewText3Objects1.length ;i < len;++i) {
    gdjs.LoseCode.GDNewText3Objects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()));
}
}}

}


};

gdjs.LoseCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoseCode.GDNewSpriteObjects1.length = 0;
gdjs.LoseCode.GDNewSpriteObjects2.length = 0;
gdjs.LoseCode.GDNewTextObjects1.length = 0;
gdjs.LoseCode.GDNewTextObjects2.length = 0;
gdjs.LoseCode.GDNewText2Objects1.length = 0;
gdjs.LoseCode.GDNewText2Objects2.length = 0;
gdjs.LoseCode.GDNewText3Objects1.length = 0;
gdjs.LoseCode.GDNewText3Objects2.length = 0;
gdjs.LoseCode.GDNewSprite2Objects1.length = 0;
gdjs.LoseCode.GDNewSprite2Objects2.length = 0;

gdjs.LoseCode.eventsList0(runtimeScene);
gdjs.LoseCode.GDNewSpriteObjects1.length = 0;
gdjs.LoseCode.GDNewSpriteObjects2.length = 0;
gdjs.LoseCode.GDNewTextObjects1.length = 0;
gdjs.LoseCode.GDNewTextObjects2.length = 0;
gdjs.LoseCode.GDNewText2Objects1.length = 0;
gdjs.LoseCode.GDNewText2Objects2.length = 0;
gdjs.LoseCode.GDNewText3Objects1.length = 0;
gdjs.LoseCode.GDNewText3Objects2.length = 0;
gdjs.LoseCode.GDNewSprite2Objects1.length = 0;
gdjs.LoseCode.GDNewSprite2Objects2.length = 0;


return;

}

gdjs['LoseCode'] = gdjs.LoseCode;
