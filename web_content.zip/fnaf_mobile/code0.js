gdjs.TitleCode = {};
gdjs.TitleCode.localVariables = [];
gdjs.TitleCode.GDiconObjects1= [];
gdjs.TitleCode.GDiconObjects2= [];
gdjs.TitleCode.GDBGObjects1= [];
gdjs.TitleCode.GDBGObjects2= [];
gdjs.TitleCode.GDbuttonObjects1= [];
gdjs.TitleCode.GDbuttonObjects2= [];
gdjs.TitleCode.GDtitleObjects1= [];
gdjs.TitleCode.GDtitleObjects2= [];
gdjs.TitleCode.GDDemoObjects1= [];
gdjs.TitleCode.GDDemoObjects2= [];
gdjs.TitleCode.GDNewObjects1= [];
gdjs.TitleCode.GDNewObjects2= [];
gdjs.TitleCode.GDContinueObjects1= [];
gdjs.TitleCode.GDContinueObjects2= [];
gdjs.TitleCode.GDNewSpriteObjects1= [];
gdjs.TitleCode.GDNewSpriteObjects2= [];


gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDNewObjects1Objects = Hashtable.newFrom({"New": gdjs.TitleCode.GDNewObjects1});
gdjs.TitleCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9275724);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "garble.mp3", true, 100, -(7));
}{gdjs.evtTools.advancedWindow.setAlwaysOnTop(false, "pop-up-menu", runtimeScene);
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Five Night's at Freddy's FREE");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.window.centerWindow(runtimeScene);
}{gdjs.evtTools.advancedWindow.setMinimizable(false, runtimeScene);
}{gdjs.evtTools.advancedWindow.setClosable(false, runtimeScene);
}{gdjs.evtTools.advancedWindow.setMovable(false, runtimeScene);
}{gdjs.evtTools.advancedWindow.setResizable(false, runtimeScene);
}{gdjs.evtTools.advancedWindow.setFullScreenable(false, runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("New"), gdjs.TitleCode.GDNewObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDNewObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9278564);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


};

gdjs.TitleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TitleCode.GDiconObjects1.length = 0;
gdjs.TitleCode.GDiconObjects2.length = 0;
gdjs.TitleCode.GDBGObjects1.length = 0;
gdjs.TitleCode.GDBGObjects2.length = 0;
gdjs.TitleCode.GDbuttonObjects1.length = 0;
gdjs.TitleCode.GDbuttonObjects2.length = 0;
gdjs.TitleCode.GDtitleObjects1.length = 0;
gdjs.TitleCode.GDtitleObjects2.length = 0;
gdjs.TitleCode.GDDemoObjects1.length = 0;
gdjs.TitleCode.GDDemoObjects2.length = 0;
gdjs.TitleCode.GDNewObjects1.length = 0;
gdjs.TitleCode.GDNewObjects2.length = 0;
gdjs.TitleCode.GDContinueObjects1.length = 0;
gdjs.TitleCode.GDContinueObjects2.length = 0;
gdjs.TitleCode.GDNewSpriteObjects1.length = 0;
gdjs.TitleCode.GDNewSpriteObjects2.length = 0;

gdjs.TitleCode.eventsList0(runtimeScene);
gdjs.TitleCode.GDiconObjects1.length = 0;
gdjs.TitleCode.GDiconObjects2.length = 0;
gdjs.TitleCode.GDBGObjects1.length = 0;
gdjs.TitleCode.GDBGObjects2.length = 0;
gdjs.TitleCode.GDbuttonObjects1.length = 0;
gdjs.TitleCode.GDbuttonObjects2.length = 0;
gdjs.TitleCode.GDtitleObjects1.length = 0;
gdjs.TitleCode.GDtitleObjects2.length = 0;
gdjs.TitleCode.GDDemoObjects1.length = 0;
gdjs.TitleCode.GDDemoObjects2.length = 0;
gdjs.TitleCode.GDNewObjects1.length = 0;
gdjs.TitleCode.GDNewObjects2.length = 0;
gdjs.TitleCode.GDContinueObjects1.length = 0;
gdjs.TitleCode.GDContinueObjects2.length = 0;
gdjs.TitleCode.GDNewSpriteObjects1.length = 0;
gdjs.TitleCode.GDNewSpriteObjects2.length = 0;


return;

}

gdjs['TitleCode'] = gdjs.TitleCode;
