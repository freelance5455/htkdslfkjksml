# Five Night's at Freddys FREE — Versión Mobile (HTML5 / PWA)

Adaptación del fangame original (export Electron de GDevelop) para funcionar en móviles y tablets.

## Cómo jugar

### Opción 1: Directo en el navegador del móvil
1. Sube toda la carpeta `fnaf_mobile` a cualquier hosting (GitHub Pages, Netlify, itch.io, etc.) o sirve los archivos localmente.
2. Abre `index.html` desde el navegador del teléfono/tablet.
3. Toca el botón **"New"** en la pantalla de título.

### Opción 2: Instalar como PWA (App)
- En Android (Chrome): menú → "Añadir a la pantalla de inicio" / "Instalar app".
- En iOS (Safari): Compartir → "Añadir a pantalla de inicio".

### Opción 3: Servidor local rápido
```bash
# Desde esta carpeta
npx serve .
# o
python -m http.server 8080
```
Luego abre la IP de tu PC desde el móvil (misma red WiFi).

## Controles
- **Touch** funciona automáticamente (GDevelop convierte los toques en clics de ratón).
- Solo hay un botón principal en la pantalla de título ("New").
- El "juego" actual es muy simple: después de ~10 segundos pasa a la pantalla de derrota (parece un prototipo/demo del autor).

## Cambios realizados para mobile
- Viewport y meta tags optimizados para móvil
- Prevención de gestos del navegador (pinch-zoom, pull-to-refresh)
- `touch-action: none` y bloqueo de selección de texto
- Manifest PWA para poder instalarse como app
- Aviso opcional de orientación horizontal
- Forzado de `touchSimulateMouse`

## Notas
- El juego original es un **fangame muy básico** hecho con GDevelop por MarioFan12L1Alt.
- No es el FNAF completo con cámaras, energía y animatrónicos. Es principalmente pantalla de título + escena corta.
- Los archivos de Electron (AdvancedWindow) están presentes pero no rompen nada en navegador.

## Para mejorar más (si quieres)
1. Recuperar el proyecto `.json` original de GDevelop y exportar nativamente a Android.
2. Añadir más lógica de juego (el actual es casi un placeholder).
3. Empaquetar con Capacitor para generar APK real.

---
Adaptado automáticamente a partir del export original.
