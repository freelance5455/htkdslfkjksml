APK ALMA YOLLARI
1) Android Studio: Klasoru ac (File > Open) -> Sync -> Build > Build APK(s).
   APK: app/build/outputs/apk/debug/app-debug.apk
2) Bilgisayar kurmadan: klasoru GitHub'a yukle -> Actions > "Build APK" -> artifact'tan indir.
Not: Oyun three.js ve mqtt'yi CDN'den yukluyor, ilk calismada internet gerekir.
