# İşçilerin kendi telefonundan giriş — Firebase kurulumu

Uygulama artık işçileri **buluta** kaydeder. Usta bir işçiyi ekleyince, o işçi **kendi telefonunda** aynı uygulamayı açıp ad + şifre ile girer.

## 1. Firebase projesi oluşturun (ücretsiz)

1. https://console.firebase.google.com adresine gidin
2. Google hesabıyla giriş yapın
3. **Add project** / Proje ekle → isim verin (ör. `tesis-yonetim`)
4. Google Analytics’i kapatabilirsiniz → Create project

## 2. Realtime Database açın

1. Sol menü: **Build → Realtime Database**
2. **Create Database**
3. Konum: `europe-west1` (veya size yakın)
4. Başlangıç: **Test mode** (1 ay açık kalır; sonra kuralları güncelleyin)

Test mode kuralları (geçici):

```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

## 3. Web uygulaması ekleyin

1. Proje genel bakış → **</> Web** ikonu
2. Uygulama takma adı: `tesis`
3. Firebase Hosting işaretlemeyin → Register
4. Çıkan `firebaseConfig` değerlerini kopyalayın

## 4. index.html içine yapıştırın

`index.html` dosyasında şu bloğu bulun:

```js
const firebaseConfig = {
    apiKey: "BURAYA_API_KEY",
    authDomain: "BURAYA_PROJE.firebaseapp.com",
    databaseURL: "https://BURAYA_PROJE-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "BURAYA_PROJE",
    storageBucket: "BURAYA_PROJE.appspot.com",
    messagingSenderId: "000000000000",
    appId: "1:000000000000:web:xxxxxxxxxxxx"
};
```

Firebase konsolundaki gerçek değerlerle değiştirin.  
**databaseURL** satırını özellikle Realtime Database sayfasındaki URL ile doldurun.

## 5. Kullanım

1. Ustabaşı girişi: `ustabaşı261933` / `ustabaşı261933`
2. **İşçiler** sekmesinden işçi ekleyin → şifre oluşur
3. Şifreyi işçiye verin
4. İşçi kendi telefonunda uygulamayı açar:
   - Kullanıcı adı = eklenen ad (ör. Mehmet Yılmaz)
   - Şifre = ustanın verdiği kod

İnternet gerekir (bulut senkron için).

## Önemli

- Tüm telefonlar **aynı Firebase projesini** kullanmalı (aynı config)
- APK yapıyorsanız config’i yazdıktan sonra HTML’i assets’e koyun
- Test mode kuralları herkese yazma izni verir; üretimde kuralları sıkılaştırın
