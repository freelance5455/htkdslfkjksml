// Usage: node tools/make-activation-hash.js "كود التفعيل"
// Prints the SHA-256 hash to paste into src/main.js as ACTIVATION_CODE_SHA256.
const crypto = require('node:crypto');
const code = process.argv.slice(2).join(' ').trim();
if (!code) {
  console.error('Usage: node tools/make-activation-hash.js "كود التفعيل"');
  process.exit(1);
}
console.log(crypto.createHash('sha256').update(code, 'utf8').digest('hex'));
