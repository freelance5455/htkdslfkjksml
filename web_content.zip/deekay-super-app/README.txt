DEE KAY SUPER APP — WEB APP PROJECT

Files:
- index.html: app home page
- css/styles.css: mobile-friendly styling and light theme
- js/app.js: calculator, local notes, to-do list, sharing, backup/restore
- manifest.json: installable web app details
- service-worker.js: offline cache when served from HTTPS or localhost
- assets/icons/deekay.svg: app icon

TEST ON ANDROID:
1. Extract this folder in Acode or your file manager.
2. Open index.html in your browser to test basic tools. Notes/tasks use browser local storage.
3. For installable/offline service-worker support, host the folder on HTTPS or run it through a local web server. Opening a file directly (file://) does not enable service workers.
4. This project is a web app, not an APK yet. To make an APK, wrap the web app using an Android WebView project or a trusted HTML-to-APK builder.

IMPORTANT:
- Local notes/tasks may be lost if browser data is cleared. Use Backup regularly.
- The calculator only evaluates basic arithmetic expressions and parentheses.
- Browser sharing support depends on the Android browser.
