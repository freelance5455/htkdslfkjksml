(() => {
  const $ = (id) => document.getElementById(id);
  const subject = $('tutorSubject');
  const question = $('tutorQuestion');
  const chat = $('tutorChat');
  const status = $('tutorStatus');
  const statusText = $('tutorStatusText');
  const errorBox = $('tutorError');
  const storageKey = 'scoredeck_ai_server_base';
  let apiBase = localStorage.getItem(storageKey) || (location.protocol === 'file:' ? '' : location.origin);
  let messages = [];
  let activeSubject = subject.value;
  let waitingForClarification = false;
  let busy = false;

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);

  const settings = document.createElement('details');
  settings.className = 'card tutor-card';
  settings.style.marginTop = '10px';
  settings.innerHTML = `<summary style="cursor:pointer;font-weight:750">⚙ Connect your Study AI server</summary>
    <p class="tutor-hint" style="margin:8px 0">For the Android app, enter your deployed HTTPS server URL. The API key belongs on the server.</p>
    <div class="tutor-compose-actions"><input id="tutorServerUrl" class="input" type="url" placeholder="https://your-scoredeck-server.example" style="flex:1;min-width:210px" aria-label="Study AI server URL"><button type="button" id="tutorSaveServer">Save server</button></div>`;
  $('tutorForm').before(settings);
  $('tutorServerUrl').value = apiBase;
  $('tutorSaveServer').addEventListener('click', () => {
    const value = $('tutorServerUrl').value.trim().replace(/\/$/, '');
    if (!value) { apiBase = ''; localStorage.removeItem(storageKey); showError('Add your Study AI server URL before asking a question.'); return; }
    try { const url = new URL(value); if (!['https:', 'http:'].includes(url.protocol)) throw new Error(); }
    catch { showError('Enter a valid http or https server URL.'); return; }
    apiBase = value;
    localStorage.setItem(storageKey, value);
    errorBox.classList.add('tutor-hidden');
    settings.open = false;
  });
  settings.addEventListener('toggle', () => {
    if (settings.open) $('tutorServerUrl').value = localStorage.getItem(storageKey) || apiBase;
  });

  const exampleLabels = ['Accounts · Goodwill', 'English · Letter format', 'Business Studies · Delegation', 'Macro · Multiplier', 'Indian Economy · Green Revolution', 'Applied Maths · Derivative'];
  document.querySelectorAll('[data-tutor-example]').forEach((button, index) => {
    button.textContent = exampleLabels[index] || 'Try an example';
    button.addEventListener('click', () => {
      if (busy) return;
      if (subject.value !== button.dataset.tutorSubject) {
        subject.value = button.dataset.tutorSubject;
        startNewSubject();
      }
      question.value = button.dataset.tutorExample;
      question.focus();
    });
  });

  function showError(message) {
    errorBox.textContent = message;
    errorBox.classList.remove('tutor-hidden');
  }

  function startNewSubject() {
    messages = [];
    activeSubject = subject.value;
    waitingForClarification = false;
    chat.innerHTML = '<div class="tutor-empty">New subject, fresh conversation. Ask away; include the full details and any figures or text it refers to.</div>';
    updateComposer();
  }

  function updateComposer() {
    $('tutorQuestionLabel').textContent = waitingForClarification ? 'Answer the clarification' : 'Your question or follow-up';
    question.placeholder = waitingForClarification
      ? 'Add the missing detail here…'
      : 'Type a question, include the full details, and add any figures or text it refers to…';
    $('tutorSend').textContent = waitingForClarification ? 'Send clarification' : (messages.length ? 'Ask follow-up' : 'Get an explanation');
  }

  function renderMessages() {
    if (!messages.length) {
      chat.innerHTML = '<div class="tutor-empty">Choose a subject and ask away.<br>For calculations, include the full question and any figures given.</div>';
      return;
    }
    chat.innerHTML = messages.map((message) => {
      if (message.role === 'user') return `<div class="tutor-msg user"><div class="tutor-msg-label">You</div><div class="tutor-reasoning">${esc(message.text)}</div></div>`;
      const result = message.result;
      const clarify = result.needsClarification;
      return `<div class="tutor-msg assistant"><div class="tutor-msg-label">Study AI · ${esc(activeSubject)}</div><div class="tutor-reasoning"><b>Reasoning:</b><br>${esc(result.reasoning)}</div>${clarify
        ? `<div class="tutor-clarify"><b>Clarification needed:</b> ${esc(result.clarifyingQuestion)}</div>`
        : `<div class="tutor-answer"><b>Answer:</b> ${esc(result.answer)}</div>`}</div>`;
    }).join('');
    chat.scrollTop = chat.scrollHeight;
  }

  async function askTutor(userText) {
    apiBase = localStorage.getItem(storageKey) || (location.protocol === 'file:' ? '' : location.origin);
    if (!apiBase) { settings.open = true; showError('Connect your Study AI server to begin. For Android, enter the HTTPS URL of your deployed server.'); return null; }
    errorBox.classList.add('tutor-hidden');
    status.classList.remove('tutor-hidden');
    statusText.textContent = waitingForClarification ? 'Reviewing the added detail…' : 'Working through the question…';
    busy = true;
    $('tutorSend').disabled = true;
    document.querySelectorAll('.tutor-example').forEach((button) => { button.disabled = true; });
    try {
      const response = await fetch(`${apiBase}/api/study-ai/answer`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: activeSubject, question: userText, history: messages.slice(0, -1).map((message) => message.role === 'user'
          ? { role: 'user', content: message.text }
          : { role: 'assistant', content: JSON.stringify(message.result) }) })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Study AI server returned ${response.status}.`);
      return data.result;
    } catch (error) {
      const message = error instanceof TypeError
        ? 'Could not reach the Study AI server. Check the saved HTTPS URL and server status.'
        : error.message;
      showError(message);
      return null;
    } finally {
      status.classList.add('tutor-hidden');
      busy = false;
      $('tutorSend').disabled = false;
      document.querySelectorAll('.tutor-example').forEach((button) => { button.disabled = false; });
    }
  }

  $('tutorForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (busy) return;
    const userText = question.value.trim();
    if (!userText) return;
    if (subject.value !== activeSubject) startNewSubject();
    const hadClarification = waitingForClarification;
    messages.push({ role: 'user', text: userText });
    renderMessages();
    question.value = '';
    const result = await askTutor(userText);
    if (!result) { messages.pop(); renderMessages(); question.value = userText; return; }
    if (typeof result.reasoning !== 'string' || typeof result.answer !== 'string' || typeof result.needsClarification !== 'boolean') {
      messages.pop(); renderMessages(); question.value = userText;
      showError('Study AI returned an incomplete response. Please try again.');
      return;
    }
    messages.push({ role: 'assistant', result });
    waitingForClarification = result.needsClarification;
    renderMessages();
    updateComposer();
    if (hadClarification && !waitingForClarification) question.placeholder = 'Ask another question or follow up…';
    question.focus();
  });

  subject.addEventListener('change', () => {
    if (subject.value !== activeSubject) startNewSubject();
  });
  $('tutorClear').addEventListener('click', () => {
    messages = [];
    waitingForClarification = false;
    errorBox.classList.add('tutor-hidden');
    renderMessages(); updateComposer(); question.value = ''; question.focus();
  });
  updateComposer();
})();
