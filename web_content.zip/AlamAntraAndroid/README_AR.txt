مشروع تطبيق متجر عالم عنترة - Android

اسم التطبيق: متجر عالم عنترة
اسم الحزمة: com.thsmaydy.alamantra

تم تضمين صفحة المتجر الحالية داخل التطبيق في:
app/src/main/assets/index.html

طريقة استخراج APK:
1. افتح المشروع بواسطة Android Studio.
2. انتظر تنزيل Gradle والمكتبات.
3. من القائمة اختر:
   Build > Build APK(s)
4. ستجد ملف APK عادة داخل:
   app/build/outputs/apk/debug/

حقوق التصميم:
جميع الحقوق محفوظة © متجر عالم عنترة | بواسطة المهندس/ توفيق الصميدي | TH.SMAYDY
