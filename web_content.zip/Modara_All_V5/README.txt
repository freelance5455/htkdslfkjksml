Modara All V5

Included:
- V4 features preserved
- Petty Cash H.Office received entries: date + amount, add/edit/delete
- Automatic total available and balance remaining
- Opening float is editable (default Rs. 20,000)
- Bill lines and receipt history
- V5 app icon (PNG and SVG)
- Browser-local storage, export/import backup

Open index.html in a browser. This package is a web app prototype, not an Android APK.
