package com.fitandfuckable.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.android.gms.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.android.gms.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.barcode.common.Barcode;

public class MainActivity extends Activity {
    private WebView webView;
    private GmsBarcodeScanner scanner;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ScannerBridge(), "AndroidScanner");

        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E, Barcode.FORMAT_CODE_128)
                .enableAutoZoom()
                .build();
        scanner = GmsBarcodeScanning.getClient(this, options);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class ScannerBridge {
        @JavascriptInterface public void startScan() {
            runOnUiThread(() -> scanner.startScan()
                .addOnSuccessListener(barcode -> {
                    String value = barcode.getRawValue();
                    if (value != null) webView.evaluateJavascript(
                        "window.onNativeBarcodeScanned && window.onNativeBarcodeScanned('" + jsEscape(value) + "')", null);
                })
                .addOnCanceledListener(() -> webView.evaluateJavascript(
                    "window.onNativeBarcodeError && window.onNativeBarcodeError('Scan annulé.')", null))
                .addOnFailureListener(e -> webView.evaluateJavascript(
                    "window.onNativeBarcodeError && window.onNativeBarcodeError('Scanner indisponible. Vérifie Google Play Services et réessaie.')", null)));
        }
    }

    private static String jsEscape(String value) {
        return value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
