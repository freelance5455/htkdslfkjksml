# Fit&Fuckable — projet Android

Cette archive contient le projet source Android, son interface HTML intégrée et un script `gradlew` de démarrage pour Linux/GitHub Actions.

## Contenu attendu
- `settings.gradle` et `build.gradle` à la racine
- `gradlew` et `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.properties`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/fitandfuckable/app/MainActivity.java`
- `app/src/main/assets/index.html`

## Compilation dans GitHub Actions
Utiliser Java 17, puis exécuter depuis ce dossier :

```sh
chmod +x gradlew
./gradlew assembleDebug
```

L'APK debug est produit dans `app/build/outputs/apk/debug/app-debug.apk`.

## À savoir
Le script `gradlew` inclus est un bootstrap léger qui télécharge Gradle 8.9 ; ce n'est pas le wrapper officiel, car le JAR officiel n'a pas pu être récupéré dans cet environnement. La première compilation nécessite une connexion Internet pour Gradle et les dépendances Android. Le projet contient l'interface HTML existante et le scanner ML Kit.
