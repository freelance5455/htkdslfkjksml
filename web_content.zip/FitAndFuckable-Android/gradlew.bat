@echo off
echo This project bootstrap is intended for Linux CI (GitHub Actions).
echo Use the included gradlew script in GitHub Actions to build the APK.
exit /b 1
