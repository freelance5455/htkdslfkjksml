# Instalação do JARVIS no Android

## Opção 1: Android Studio
1. Extraia o ZIP.
2. Abra a pasta `JarvisFull` no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Escolha `Build > Build APK(s)`.
5. O APK aparecerá em:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Passe o APK para o celular e abra o arquivo para instalar.
7. Se o Android pedir autorização para instalar de uma fonte externa, habilite a permissão para o aplicativo que está abrindo o APK.

## Opção 2: GitHub Actions
O projeto possui `.github/workflows/build-apk.yml`.
Depois de colocar o projeto em um repositório GitHub:
1. Abra a aba Actions.
2. Execute `Build JARVIS APK`.
3. Ao terminar, abra os artefatos da execução.
4. Baixe `JARVIS-debug-apk`.
5. Transfira o APK para o Android e instale.

## Por que o ZIP não contém diretamente um APK?
Um APK precisa ser compilado pelo Android Gradle Plugin usando o SDK do Android. O ambiente desta conversa não possui o Android SDK/Build Tools necessários para produzir um APK nativo confiável diretamente.

## Instalação por cabo não é necessária
Depois que o APK estiver pronto, ele pode ser enviado ao próprio celular por nuvem, navegador, mensageiro, cabo ou outro método de transferência.

## Permissões
Na primeira utilização, o Android pode pedir permissões. O `AccessibilityService` é especialmente poderoso e deve ser ativado manualmente em:
Configurações > Acessibilidade > JARVIS.

O aplicativo não deve tentar contornar as proteções do Android para se instalar ou conceder permissões sozinho.
