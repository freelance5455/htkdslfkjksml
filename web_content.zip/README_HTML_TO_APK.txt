SHAIB draz — HTML to APK upload bundle

This ZIP is a web asset bundle, not an APK. It contains index.html at both the root and web/index.html, with the required ads/ folders beside each entry point.

In the HTML-to-APK app, extract this ZIP first, then choose the folder or start page that contains index.html. If it asks for a start page, select index.html (or web/index.html if it specifically uses the /web/ path). Make sure the ads folder is included in the packaged assets.

If the converter still shows appassets.androidplatform.net/web/index.html, check that web/index.html and web/ads are included in its project/package before building.
