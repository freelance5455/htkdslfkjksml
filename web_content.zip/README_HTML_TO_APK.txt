ENTRE RÍOS FLY FISHING — PAQUETE HTML PARA APK BUILDER

Contenido principal:
- index.html = aplicación
- manifest.json = configuración PWA
- sw.js = caché offline

CONFIGURACIÓN RECOMENDADA EN HTML TO APK BUILDER:
Nombre: Entre Ríos Fly Fishing
Package/ID: cl.entrerios.flyfishing
Orientación: Portrait
Página inicial: index.html
JavaScript: Activado
DOM Storage / Local Storage: Activado
Acceso a Internet: Activado
Zoom: Desactivado o automático
Pantalla completa: Sí
Barra de acción: Oculta
Color principal: #123B2A
Color secundario: #D7B56D

ICONO:
El proyecto actualmente utiliza un logotipo integrado en la interfaz. Para un icono PNG definitivo de Play Store podemos crear uno separado cuando elijas el logo final.

IMPORTANTE:
Esta versión es de demostración. El login, cuotas y datos mostrados son datos demo.
Antes de usar datos reales de socios hay que conectar un backend seguro (Supabase Auth/Database + RLS).
