CARD SCHOOL PRO V16 — VERSION HTML TO APK

Cette archive est préparée pour les convertisseurs HTML to APK Builder.

IMPORTANT : index.html est autonome (CSS + JavaScript intégrés). Les images nécessaires sont à côté de index.html.

Dans HTML to APK Builder :
1. Importer le dossier ou le ZIP.
2. Choisir index.html comme page d’accueil si demandé.
3. Activer JavaScript.
4. Autoriser caméra/appareil photo et fichiers/galerie si l’application propose ces options.
5. Générer l’APK.

PDF : le moteur PDF.js est chargé à la demande depuis CDN.
OCR : Tesseract est chargé à la demande depuis CDN.
JPG : html2canvas est chargé à la demande depuis CDN.
Ces fonctions peuvent donc nécessiter Internet dans cette version.
