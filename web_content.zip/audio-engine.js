// =====================================================================
// JUZISOUND AUDIO ENGINE & DSP PROCESSOR
// Web Audio API Low-Latency Ethno Solo Sampler & Synthesizer
// =====================================================================

class JuzisoundAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.limiter = null;

    // EQ
    this.eqLow = null;
    this.eqMid = null;
    this.eqHigh = null;

    // Ефекти: Delay & Reverb
    this.delayNode = null;
    this.delayFeedback = null;
    this.delayFilter = null;
    this.delayGain = null;

    this.reverbNode = null;
    this.reverbGain = null;

    // Активни гласове (полифония / моно легато)
    this.activeVoices = new Map(); // midiNote -> [voice objects]
    this.lastMidiNote = null;      // за Portamento / Legato
    this.lastFrequency = null;

    // Настройки на звуковия пач
    this.instrument = 'clarinet';  // 'clarinet', 'sax', 'accordion', 'bouzouki', 'kaval', 'juzi_lead'
    this.harmonyInstrument = 'same'; // 'same' или друг инструмент за терцата!

    // Настройки за контролери и дишане (Breath Controller)
    this.breathValue = 1.0;        // 0.0 .. 1.0 (CC#11 / CC#2)
    this.breathCurve = 'exp';      // 'linear', 'exp', 's-curve'
    this.pitchBendSemi = 0;        // -12 .. +12 semitones
    this.pitchBendRange = 2;       // +/- 2 semitones default (или 12 за етно спускания)
    this.modWheel = 0;             // CC#1 Vibrato depth
    this.portamentoTime = 0.04;    // 40ms плавен глисандо преход

    // Сила на звука
    this.soloVolume = 0.9;
    this.harmonyVolume = 0.8;

    // Ефекти параметри
    this.delayTime = 0.32;         // 320ms ехо
    this.delayFeedbackVal = 0.42;  // 42% повторения
    this.delayMix = 0.35;          // 35% Wet
    this.reverbDecay = 2.2;        // 2.2 секунди
    this.reverbMix = 0.30;         // 30% Wet

    // Заредени външни семпли (.wav)
    this.customSamples = {};
  }

  // Инициализация при първо кликване / докосване (Web Audio изискване)
  init() {
    if (this.ctx) return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AudioContext({ latencyHint: 'interactive' });

    // Master Gain & Limiter
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.85;

    this.limiter = this.ctx.createDynamicsCompressor();
    this.limiter.threshold.value = -1.0;
    this.limiter.knee.value = 0.0;
    this.limiter.ratio.value = 20.0;
    this.limiter.attack.value = 0.002;
    this.limiter.release.value = 0.05;

    // 3-Band EQ
    this.eqLow = this.ctx.createBiquadFilter();
    this.eqLow.type = 'lowshelf';
    this.eqLow.frequency.value = 100;
    this.eqLow.gain.value = 2.0; // лек бас

    this.eqMid = this.ctx.createBiquadFilter();
    this.eqMid.type = 'peaking';
    this.eqMid.frequency.value = 2500;
    this.eqMid.gain.value = 1.0;

    this.eqHigh = this.ctx.createBiquadFilter();
    this.eqHigh.type = 'highshelf';
    this.eqHigh.frequency.value = 8000;
    this.eqHigh.gain.value = 2.5; // кристални високи за солата

    // Delay верига (Стерео / Аналогов Hi-Cut филтър)
    this.delayNode = this.ctx.createDelay(2.0);
    this.delayNode.delayTime.value = this.delayTime;

    this.delayFeedback = this.ctx.createGain();
    this.delayFeedback.gain.value = this.delayFeedbackVal;

    this.delayFilter = this.ctx.createBiquadFilter();
    this.delayFilter.type = 'lowpass';
    this.delayFilter.frequency.value = 3500; // омекотяване на ехото

    this.delayGain = this.ctx.createGain();
    this.delayGain.gain.value = this.delayMix;

    // Delay рутиране: In -> DelayNode -> Filter -> Feedback -> DelayNode
    this.delayNode.connect(this.delayFilter);
    this.delayFilter.connect(this.delayFeedback);
    this.delayFeedback.connect(this.delayNode);
    this.delayFilter.connect(this.delayGain);

    // Reverb верига (Синтезиран конволвер за зала)
    this.reverbNode = this.ctx.createConvolver();
    this.generateReverbImpulse(this.reverbDecay);
    this.reverbGain = this.ctx.createGain();
    this.reverbGain.gain.value = this.reverbMix;
    this.reverbNode.connect(this.reverbGain);

    // Свързване на цялата звукова верига:
    // EQ -> MasterGain -> Limiter -> Destination (Говорители / Слушалки)
    this.eqLow.connect(this.eqMid);
    this.eqMid.connect(this.eqHigh);
    this.eqHigh.connect(this.masterGain);

    // Ефекти паралелно:
    this.eqHigh.connect(this.delayNode);
    this.eqHigh.connect(this.reverbNode);

    this.delayGain.connect(this.masterGain);
    this.reverbGain.connect(this.masterGain);

    this.masterGain.connect(this.limiter);
    this.limiter.connect(this.ctx.destination);
  }

  // Генериране на естествена сватбарска реверберация
  generateReverbImpulse(duration = 2.2, decay = 2.0) {
    if (!this.ctx) return;
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * duration;
    const impulse = this.ctx.createBuffer(2, length, sampleRate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    for (let i = 0; i < length; i++) {
      const n = i / length;
      const factor = Math.exp(-n * decay * 3);
      left[i] = (Math.random() * 2 - 1) * factor;
      right[i] = (Math.random() * 2 - 1) * factor;
    }
    this.reverbNode.buffer = impulse;
  }

  // Преобразуване на MIDI нота в честота (Hz) + микротунинг
  midiToFreq(midiNote, detuneCents = 0) {
    const totalCents = (midiNote - 69) * 100 + detuneCents;
    return 440 * Math.pow(2, totalCents / 1200);
  }

  // Включване на нота (Note On)
  noteOn(midiNote, velocity = 100, isHarmonized = false, detuneCents = 0) {
    if (!this.ctx) this.init();
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const targetInst = isHarmonized && this.harmonyInstrument !== 'same'
      ? this.harmonyInstrument
      : this.instrument;

    const baseFreq = this.midiToFreq(midiNote, detuneCents);
    const velFactor = velocity / 127;
    const now = this.ctx.currentTime;

    // Създаване на гласов синтезатор
    const voice = this.createEthnoVoice(targetInst, baseFreq, velFactor, isHarmonized, now);

    // Записваме гласа в масива с активни ноти
    if (!this.activeVoices.has(midiNote)) {
      this.activeVoices.set(midiNote, []);
    }
    this.activeVoices.get(midiNote).push(voice);

    this.lastMidiNote = midiNote;
    this.lastFrequency = baseFreq;

    return voice;
  }

  // Изключване на нота (Note Off)
  noteOff(midiNote) {
    if (!this.activeVoices.has(midiNote)) return;
    const voices = this.activeVoices.get(midiNote);
    const now = this.ctx.currentTime;

    for (const voice of voices) {
      voice.release(now);
    }
    this.activeVoices.delete(midiNote);
  }

  // Спиране на всички ноти (Panic / All Notes Off)
  allNotesOff() {
    const now = this.ctx ? this.ctx.currentTime : 0;
    for (const [note, voices] of this.activeVoices.entries()) {
      for (const voice of voices) {
        voice.release(now);
      }
    }
    this.activeVoices.clear();
  }

  // Създаване на етно глас според избрания инструмент
  createEthnoVoice(instrumentType, targetFreq, velocity, isHarmonized, now) {
    const ctx = this.ctx;
    const voiceGain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    // Сила на звука (Соло срещу Терца)
    const baseVolume = (isHarmonized ? this.harmonyVolume : this.soloVolume) * velocity;
    voiceGain.gain.setValueAtTime(0.001, now);

    // Portamento / Legato Glide: плавно тръгване от предишната нота
    let startFreq = targetFreq;
    if (this.lastFrequency && this.portamentoTime > 0.005) {
      startFreq = this.lastFrequency;
    }

    const oscNodes = [];

    switch (instrumentType) {
      case 'clarinet': {
        // КЛАРИНЕТ: Квадратна вълна + тесен резонантен филтър (кухо дървено тяло)
        const osc = ctx.createOscillator();
        osc.type = 'square';
        osc.frequency.setValueAtTime(startFreq, now);
        if (startFreq !== targetFreq) {
          osc.frequency.exponentialRampToValueAtTime(targetFreq, now + this.portamentoTime);
        }

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1400, now);
        filter.Q.setValueAtTime(2.8, now);

        // Attack envelope
        voiceGain.gain.exponentialRampToValueAtTime(baseVolume * 0.9, now + 0.025);

        osc.connect(filter);
        oscNodes.push(osc);
        break;
      }

      case 'sax': {
        // САКСОФОН: Ярка трионообразна вълна (Sawtooth) + хаплив филтър
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        osc1.type = 'sawtooth';
        osc2.type = 'sawtooth';
        osc1.frequency.setValueAtTime(startFreq, now);
        osc2.frequency.setValueAtTime(startFreq * 1.004, now); // детюнинг за плътност

        if (startFreq !== targetFreq) {
          osc1.frequency.exponentialRampToValueAtTime(targetFreq, now + this.portamentoTime);
          osc2.frequency.exponentialRampToValueAtTime(targetFreq * 1.004, now + this.portamentoTime);
        }

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(3200, now);
        filter.Q.setValueAtTime(4.0, now);

        voiceGain.gain.exponentialRampToValueAtTime(baseVolume * 0.95, now + 0.015);

        osc1.connect(filter);
        osc2.connect(filter);
        oscNodes.push(osc1, osc2);
        break;
      }

      case 'accordion': {
        // АКОРДЕОН: Двоен глас (Кабина + Класически Musette трептене)
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const osc3 = ctx.createOscillator();
        osc1.type = 'sawtooth';
        osc2.type = 'sawtooth';
        osc3.type = 'triangle'; // поддържаща мекота

        osc1.frequency.setValueAtTime(startFreq, now);
        osc2.frequency.setValueAtTime(startFreq * 1.006, now); // балканско вибро
        osc3.frequency.setValueAtTime(startFreq * 0.5, now);   // бас подложка 1 октава надолу

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(4500, now);
        filter.Q.setValueAtTime(1.5, now);

        voiceGain.gain.exponentialRampToValueAtTime(baseVolume * 0.85, now + 0.02);

        osc1.connect(filter);
        osc2.connect(filter);
        osc3.connect(filter);
        oscNodes.push(osc1, osc2, osc3);
        break;
      }

      case 'bouzouki': {
        // БУЗУКИ / ТАМБУРА: Остър метален щрих с бърз спад
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(targetFreq, now);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(2800, now);
        filter.Q.setValueAtTime(2.0, now);

        voiceGain.gain.setValueAtTime(baseVolume * 1.1, now);
        voiceGain.gain.exponentialRampToValueAtTime(baseVolume * 0.35, now + 0.18);

        osc.connect(filter);
        oscNodes.push(osc);
        break;
      }

      case 'kaval': {
        // КАВАЛ / ФРУЛА: Синусоида/триъгълник + дъх
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(startFreq, now);
        if (startFreq !== targetFreq) {
          osc.frequency.exponentialRampToValueAtTime(targetFreq, now + this.portamentoTime * 1.5);
        }

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1800, now);
        filter.Q.setValueAtTime(1.8, now);

        voiceGain.gain.exponentialRampToValueAtTime(baseVolume * 0.8, now + 0.04);

        osc.connect(filter);
        oscNodes.push(osc);
        break;
      }

      case 'juzi_lead':
      default: {
        // JUZI LEAD: Прорязващ синхронизиран моно синт за сватбарски сола
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        osc1.type = 'sawtooth';
        osc2.type = 'square';
        osc1.frequency.setValueAtTime(startFreq, now);
        osc2.frequency.setValueAtTime(startFreq * 1.003, now);

        if (startFreq !== targetFreq) {
          osc1.frequency.exponentialRampToValueAtTime(targetFreq, now + this.portamentoTime);
          osc2.frequency.exponentialRampToValueAtTime(targetFreq * 1.003, now + this.portamentoTime);
        }

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(5000, now);
        filter.Q.setValueAtTime(5.0, now);

        voiceGain.gain.exponentialRampToValueAtTime(baseVolume, now + 0.01);

        osc1.connect(filter);
        osc2.connect(filter);
        oscNodes.push(osc1, osc2);
        break;
      }
    }

    // Връзка на гласа към филтъра, гейна и главния вход
    filter.connect(voiceGain);
    voiceGain.connect(this.eqLow);

    // Старт на осцилаторите
    for (const osc of oscNodes) {
      osc.start(now);
    }

    return {
      oscNodes,
      filter,
      voiceGain,
      targetFreq,
      release: (releaseTime) => {
        try {
          voiceGain.gain.cancelScheduledValues(releaseTime);
          voiceGain.gain.setValueAtTime(voiceGain.gain.value, releaseTime);
          voiceGain.gain.exponentialRampToValueAtTime(0.0001, releaseTime + 0.08); // 80ms естествен релийз
          setTimeout(() => {
            for (const osc of oscNodes) {
              try { osc.stop(); osc.disconnect(); } catch (e) {}
            }
            filter.disconnect();
            voiceGain.disconnect();
          }, 120);
        } catch (e) {}
      }
    };
  }

  // Обработка на Breath Controller (CC#11 / CC#2)
  setBreath(value0to1) {
    this.breathValue = Math.max(0, Math.min(1, value0to1));
    if (!this.ctx) return;

    // Изчисляване на кривата (експоненциална за естествено свирене с кларинет)
    let shaped = this.breathValue;
    if (this.breathCurve === 'exp') {
      shaped = Math.pow(this.breathValue, 1.8);
    }

    const now = this.ctx.currentTime;

    // Влияние върху всички активни ноти: Сила + Яркост на филтъра (Cutoff)
    for (const [note, voices] of this.activeVoices.entries()) {
      for (const v of voices) {
        if (v.filter && v.filter.frequency) {
          const baseFreq = 800 + (shaped * 6000);
          v.filter.frequency.setTargetAtTime(baseFreq, now, 0.015);
        }
        if (v.voiceGain && v.voiceGain.gain) {
          v.voiceGain.gain.setTargetAtTime(shaped * this.soloVolume, now, 0.015);
        }
      }
    }
  }

  // Pitch Bend (-8192 .. +8191 -> полутонове)
  setPitchBend(normalizedVal) {
    this.pitchBendSemi = normalizedVal * this.pitchBendRange;
    if (!this.ctx) return;
    const now = this.ctx.currentTime;

    const bendRatio = Math.pow(2, this.pitchBendSemi / 12);

    for (const [note, voices] of this.activeVoices.entries()) {
      for (const v of voices) {
        for (const osc of v.oscNodes) {
          osc.frequency.setTargetAtTime(v.targetFreq * bendRatio, now, 0.01);
        }
      }
    }
  }

  // Настройка на Delay в реално време
  setDelay(time, feedback, mix) {
    this.delayTime = time;
    this.delayFeedbackVal = feedback;
    this.delayMix = mix;
    if (this.delayNode && this.ctx) {
      this.delayNode.delayTime.setTargetAtTime(time, this.ctx.currentTime, 0.05);
      this.delayFeedback.gain.setTargetAtTime(feedback, this.ctx.currentTime, 0.05);
      this.delayGain.gain.setTargetAtTime(mix, this.ctx.currentTime, 0.05);
    }
  }

  // Настройка на Reverb в реално време
  setReverb(decay, mix) {
    this.reverbDecay = decay;
    this.reverbMix = mix;
    if (this.reverbGain && this.ctx) {
      this.reverbGain.gain.setTargetAtTime(mix, this.ctx.currentTime, 0.05);
      this.generateReverbImpulse(decay);
    }
  }

  // Настройка на EQ
  setEQ(lowDb, midDb, highDb) {
    if (this.eqLow && this.ctx) {
      const now = this.ctx.currentTime;
      this.eqLow.gain.setTargetAtTime(lowDb, now, 0.05);
      this.eqMid.gain.setTargetAtTime(midDb, now, 0.05);
      this.eqHigh.gain.setTargetAtTime(highDb, now, 0.05);
    }
  }
}

window.JuzisoundAudioEngine = JuzisoundAudioEngine;
