# FF MAX ARENA — Android project (WebView wrapper)

এই ফোল্ডারটি একটি **Android Studio source project**। এতে আপনার HTML demo-টি Android WebView-এর ভিতরে চলে, এবং deposit/withdrawal-এর screenshot/QR image বাছাই করার file picker-ও যুক্ত আছে। এটি এখনো তৈরি APK নয়।

## APK বানানোর সহজ পদ্ধতি

1. কম্পিউটারে Android Studio ইনস্টল করুন: https://developer.android.com/studio
2. ZIP ফাইলটি Extract করুন। Android Studio → **Open** → Extract করা `FF_MAX_ARENA_Android_Project` ফোল্ডারটি বেছে নিন।
3. Android Studio-কে Gradle sync শেষ করতে দিন। SDK Platform 35 ও প্রয়োজনীয় Android Build Tools ইনস্টল করতে বললে অনুমতি দিন।
4. USB debugging চালু করা Android ফোন সংযোগ করুন, অথবা Android Studio-র Device Manager থেকে emulator চালু করুন। তারপর **Run ▶** চাপুন।
5. APK বানাতে: **Build → Build Bundle(s) / APK(s) → Build APK(s)**। শেষ হলে notification-এর **locate** লিংক চাপুন। সাধারণত APK পাওয়া যায় `app/build/outputs/apk/debug/app-debug.apk`-এ।
6. ফোনে APK পাঠিয়ে ইনস্টল করুন। ফোনে “Install unknown apps” অনুমতি চাইতে পারে—শুধু নিজের তৈরি/বিশ্বস্ত APK-এর জন্য অনুমতি দিন।

## কমান্ড লাইন দিয়ে (Android SDK ও Gradle ইনস্টল থাকলে)

Project folder-এ গিয়ে:

```bash
gradle assembleDebug
```

APK path: `app/build/outputs/apk/debug/app-debug.apk`

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- বর্তমান HTML হলো **demo/prototype**। Wallet balance, requests ও admin approval browser-session-এর মধ্যে demo হিসেবেই থাকে; এটি কোনো বাস্তব পেমেন্ট নেয় বা পাঠায় না এবং নিরাপদ server database নয়।
- Public launch-এর আগে backend, secure login, admin authorization, server-side balance validation, payment-provider verification, privacy policy, data-safety declaration, app icon/signing এবং device testing প্রয়োজন।
- বাস্তব টাকার entry fee/prize যুক্ত tournament Google Play-এর real-money gambling/games policy-তে সীমাবদ্ধ হতে পারে। Play Store-এ প্রকাশের আগে বর্তমান policy ও প্রযোজ্য ভারতীয় আইন যাচাই করুন।
- Play Store-এ upload করার জন্য সাধারণত signed **Android App Bundle (.aab)** তৈরি করতে হয়; debug APK Play Store release-এর বিকল্প নয়।
- App ID বর্তমানে `com.ffmaxarena.app`। Play Store-এ প্রকাশের আগে নিজের unique application ID বেছে নিন; একবার প্রকাশের পর বদলানো জটিল হতে পারে।
