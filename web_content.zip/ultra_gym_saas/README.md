# GYMORA Ultra Premium — Working Demo v2

This build is a **functional browser demo**, not a production backend.

## Working now
- Members: add/edit member, full contact details, plan, expiry, balance and profile photo; data persists in browser localStorage.
- Scanner & attendance: camera permission flow using `getUserMedia()` plus QR detection when the browser exposes `BarcodeDetector`; manual Member ID fallback is always available.
- Payments: record payment, update member balance for paid transactions, transaction list, CSV export.
- Leads & CRM: add leads, move New → Trial → Hot → Converted, delete leads.
- Content Studio: add banner/offer/announcement/link and image assets, publish state, AI campaign draft/save.
- Settings: owner/business/UPI/Instagram values and local reset.
- Dashboard + analytics: update from local demo data.
- Chatbot: local rule-based Gym Copilot using the current browser data.
- Responsive layouts for mobile, tablet and desktop.

## Scanner note
Camera access requires permission and a secure context such as HTTPS or localhost. `BarcodeDetector` has limited browser availability, so the UI intentionally includes a Member ID fallback instead of pretending QR scanning works everywhere.

## Production upgrade needed
For real client deployment: secure authentication, cloud database/API, encrypted storage, server-side authorization, object storage, real payment gateway/UPI integration, WhatsApp Business API, push notifications, audit logs, backups and a production-grade QR scanner library/native mobile camera layer.
