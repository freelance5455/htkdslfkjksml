
export interface ServiceCategory {
  title: string;
  id: string;
  icon: string;
  subServices: string[];
}

export interface FeaturedStat {
  label: string;
  value: string;
  icon: string;
}
