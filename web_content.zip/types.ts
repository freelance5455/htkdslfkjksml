
export enum View {
  RADAR = 'RADAR',
  CHAT = 'CHAT',
  WALLET = 'WALLET',
  ACCOUNT = 'ACCOUNT',
  POST_GIG = 'POST_GIG',
  PERSONAL_INFO = 'PERSONAL_INFO',
  MANAGE_GIGS = 'MANAGE_GIGS',
  SECURITY_SAFETY = 'SECURITY_SAFETY',
  SUPPORT_CHAT = 'SUPPORT_CHAT',
  JOB_DETAILS = 'JOB_DETAILS'
}

export enum AppState {
  SPLASH = 'SPLASH',
  ONBOARDING = 'ONBOARDING',
  AUTH = 'AUTH',
  ROLE_SELECTION = 'ROLE_SELECTION',
  MAIN = 'MAIN'
}

export enum UserTier {
  ROOKIE = 'Rookie',
  RISING_STAR = 'Rising Star',
  ELITE = 'Elite',
  PREMIUM = 'Premium'
}

export interface UserStats {
  jobsCompleted: number;
  jobsPostedCount: number; // For Employer Instant Payout goal
  averageRating: number;
  currentTier: UserTier;
  memberSince: string;
}

export type VerificationStatus = 'unverified' | 'pending' | 'verified';

export interface StructuredAddress {
  street: string;
  suburb: string;
  city: string;
  province: string;
  postalCode: string;
}

export interface UserProfile {
  id: string; // Added ID for easier lookup in admin panel
  fullName: string;
  email: string;
  phone: string;
  idNumber: string;
  address: string | StructuredAddress;
  bio: string;
  isAvailable: boolean;
  walletBalance: number;
  escrowBalance: number;
  emergencyContact: string;
  emergencyContacts: string[];
  skills?: string[]; // Hustler skill set (e.g. Electrical, Handyman, Plumbing, etc.)
  pushNotificationSettings?: PushNotificationSettings;
  isAdmin?: boolean; // Admin flag
  verification: {
    phone: VerificationStatus;
    identity: VerificationStatus;
    facial: VerificationStatus;
    address: VerificationStatus;
  };
  verificationDocs?: {
    idFront?: string;
    idBack?: string;
    selfie?: string;
    residence?: string;
  };
}

export interface Transaction {
  id: string;
  userId?: string; // Reference to user
  userName?: string; // For admin view
  type: 'in' | 'out' | 'transfer';
  label: string;
  amount: number;
  timestamp: number;
  status: 'completed' | 'pending' | 'rejected';
  method?: string;
  fee?: number;
}

export interface ChatMessage {
  id: string;
  senderId: string; // 'me' | 'other' | 'system'
  text: string;
  timestamp: number;
  isAi?: boolean;
}

export interface ChatThread {
  id: string;
  otherUserName: string;
  lastMessage: string;
  timestamp: number;
  unread: boolean;
  avatar: string;
  hustlerId?: string;
  skill?: string;
  category?: string;
  hourlyRate?: number;
  rating?: number;
  phone?: string;
  distanceKm?: number;
  isVerified?: boolean;
  isHired?: boolean;
  messages?: ChatMessage[];
  occupantRole?: 'hustler' | 'employer';
  completedJobs?: number; // how many jobs worked
  hustlersHired?: number; // how many hustlers hired
  jobsPosted?: number;
  skills?: string[];
  bio?: string;
  tier?: UserTier | string;
  reviewsCount?: number;
  escrowTrackRecord?: string;
  memberSince?: string;
}

export type GigStatus = 'open' | 'active' | 'pending_approval' | 'completed';

export interface Gig {
  id: string;
  title: string;
  description: string;
  price: number;
  location: [number, number];
  category: string;
  datePosted: number;
  hustlerId?: string;
  isFeatured?: boolean;
  featuredExpiry?: number;
  status: GigStatus;
  requiresPoW: boolean;
  referencePhoto?: string;
  beforePhoto?: string;
  afterPhoto?: string;
  isVerifiedUser?: boolean;
}

export interface AvailableHustler {
  id: string;
  name: string;
  avatar: string;
  skill: string;
  category: string;
  rating: number;
  reviewsCount: number;
  hourlyRate: number;
  location: [number, number];
  distanceKm: number;
  isVerified: boolean;
  tier: UserTier;
  bio: string;
  isOnline: boolean;
  isWorking?: boolean;
  status?: 'available' | 'working' | 'offline';
  currentGigId?: string;
  completedJobs: number;
  phone?: string;
}

export interface PushNotificationSettings {
  enabled: boolean;
  immediateRadiusKm: number; // strictly 5km for immediate alerts
  highPayingThreshold: number; // default R800 - R1,000+ for hustlers
  skillsOnly: boolean; // alert only when matching user's skill set
  soundEnabled: boolean; // synthesized audio chime
  browserPushEnabled: boolean; // Web Notification API
  // Employer specific push settings
  employerMatchAlertsEnabled?: boolean; // Alert employer when available hustlers match posted gigs
  minHustlerRating?: number; // Filter by minimum rating (e.g. 4.5+)
}

export interface HighPayingGigAlert {
  id: string;
  gig: Gig;
  distanceKm: number;
  matchedSkill: string;
  timestamp: number;
  read?: boolean;
}

export interface EmployerHustlerMatchAlert {
  id: string;
  hustler: AvailableHustler;
  matchedGig: Gig;
  distanceKm: number;
  timestamp: number;
  read?: boolean;
}

