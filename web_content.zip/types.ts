export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number; // Index 0-3
  explanation: string;
}

export interface Section {
  id: string;
  title: string;
  startNumber?: number;
  questions: Question[];
}

export type MarginPreset = 'Normal' | 'Narrow' | 'Moderate' | 'Wide';

export interface PageSettings {
  margin: MarginPreset;
  showBorder: boolean;
}

export interface DocumentMetadata {
  title: string;
  showTitle: boolean;
  subtitle: string;
  showSubtitle: boolean;
  pageSettings: PageSettings;
}

export enum GenerationType {
  TOPIC = 'TOPIC',
  TEXT = 'TEXT'
}

export interface GenerationConfig {
  type: GenerationType;
  prompt: string;
  count: number;
}