# Hush: phone-number sign-up messenger

Real users, real SMS verification, end-to-end encrypted 1:1 chat (ECDH P-256 + AES-GCM in the browser).

## Setup (about 10 minutes)
1. Create a project at https://console.firebase.google.com
2. Build > Authentication > Sign-in method: enable **Phone**. Add test numbers while developing.
3. Build > Firestore Database: create a database, then paste `firestore.rules` into the Rules tab and publish.
4. Project settings > Your apps > Web: copy the config into `FIREBASE_CONFIG` near the top of the script in `index.html`.
5. Authentication > Settings > Authorized domains: add the domain you host on.
6. Host the folder anywhere HTTPS (Firebase Hosting: `firebase init hosting`, then `firebase deploy`).

## Notes
- Real SMS requires the Firebase Blaze (pay-as-you-go) plan beyond the free test numbers.
- Phone numbers are stored only as SHA-256 hashes. A determined attacker can brute-force hashes of phone numbers, so treat this as obscurity, not secrecy.
- The private key lives in the browser's localStorage. Clearing it or switching device loses chat history. Add key backup before real launch.
- Not security-audited. For production, move to libsignal and get an independent review.
- Group chats, media, voice notes and calls are not included yet.
