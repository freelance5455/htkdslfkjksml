(()=>{
const prefix='gryphon-app-local:v1:aac7bdd1-fc74-47db-8a8d-a1fa0ac9f190:';
window.gryphon={storage:{
get:async key=>JSON.parse(localStorage.getItem(prefix+key)||'null'),
set:async(key,value)=>{localStorage.setItem(prefix+key,JSON.stringify(value));return value},
remove:async key=>{localStorage.removeItem(prefix+key)}}};
})();