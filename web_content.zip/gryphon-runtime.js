(()=>{
const prefix='gryphon-app-local:v1:3616a4ca-4180-4a1e-bbdb-c9d892ffd635:';
window.gryphon={storage:{
get:async key=>JSON.parse(localStorage.getItem(prefix+key)||'null'),
set:async(key,value)=>{localStorage.setItem(prefix+key,JSON.stringify(value));return value},
remove:async key=>{localStorage.removeItem(prefix+key)}}};
})();