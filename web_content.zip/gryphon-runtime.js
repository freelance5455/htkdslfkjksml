(()=>{
const prefix='gryphon-app-local:v1:7e495c22-ca04-4871-a685-569880754606:';
window.gryphon={storage:{
get:async key=>JSON.parse(localStorage.getItem(prefix+key)||'null'),
set:async(key,value)=>{localStorage.setItem(prefix+key,JSON.stringify(value));return value},
remove:async key=>{localStorage.removeItem(prefix+key)}}};
})();