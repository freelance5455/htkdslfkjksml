import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAnalytics, isSupported } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-analytics.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyAQ0GpGRuNwZIgdu5tPSh9hklyPZkPl4Sk",
  authDomain: "cassuendejornal.firebaseapp.com",
  projectId: "cassuendejornal",
  storageBucket: "cassuendejornal.firebasestorage.app",
  messagingSenderId: "486922464736",
  appId: "1:486922464736:web:8bfe94aff6ce1bb3424f85",
  measurementId: "G-Y0W7B2D751"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
isSupported().then(ok => { if (ok) getAnalytics(app); }).catch(() => {});

/* ---------- Efeito de escrita ---------- */
const frases = [
  "Olá",
  "Eu sou uma tecnologia personalizada criado para realizações pessoais",
  "Resolvo problemas difíceis de matemática e programação..."
];
const alvo = document.getElementById("typing-text");
const espera = ms => new Promise(r => setTimeout(r, ms));

async function escrever() {
  let i = 0;
  while (true) {
    const frase = frases[i];
    for (let c = 1; c <= frase.length; c++) { alvo.textContent = frase.slice(0, c); await espera(55); }
    await espera(1600);
    for (let c = frase.length; c >= 0; c--) { alvo.textContent = frase.slice(0, c); await espera(25); }
    await espera(350);
    i = (i + 1) % frases.length;
  }
}
escrever();

/* ---------- Mostrar/ocultar senha ---------- */
const senha = document.getElementById("senha");
const olho = document.getElementById("ver-senha");
olho.addEventListener("click", () => {
  const ver = senha.type === "password";
  senha.type = ver ? "text" : "password";
  olho.innerHTML = `<i class="bi bi-eye${ver ? "-slash" : ""}"></i>`;
  olho.setAttribute("aria-label", ver ? "Ocultar senha" : "Mostrar senha");
});

/* ---------- Login ---------- */
const form = document.getElementById("form-login");
const erro = document.getElementById("erro");
const botao = document.getElementById("entrar");

const mensagens = {
  "auth/invalid-email": "Email inválido.",
  "auth/invalid-credential": "Email ou senha incorretos.",
  "auth/user-not-found": "Email ou senha incorretos.",
  "auth/wrong-password": "Email ou senha incorretos.",
  "auth/too-many-requests": "Muitas tentativas. Tente novamente mais tarde.",
  "auth/network-request-failed": "Sem ligação à internet.",
  "auth/operation-not-allowed": "Ative o login por Email/Senha no Firebase Authentication."
};

form.addEventListener("submit", async e => {
  e.preventDefault();
  erro.textContent = "";
  const email = document.getElementById("email").value.trim();
  if (!email || !senha.value) { erro.textContent = "Preencha o email e a senha."; return; }

  botao.disabled = true;
  try {
    await signInWithEmailAndPassword(auth, email, senha.value);
    document.getElementById("boas-vindas").classList.add("ativo");
    setTimeout(() => { window.location.href = "hom.html"; }, 2200);
  } catch (err) {
    erro.textContent = mensagens[err.code] || "Não foi possível entrar. Tente novamente.";
    botao.disabled = false;
  }
});
