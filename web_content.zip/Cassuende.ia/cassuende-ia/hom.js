import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDocs, deleteDoc, query, orderBy, onSnapshot, serverTimestamp }
  from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { REGRAS } from "./regras.js";
import { CONFIG } from "./config.js";

const app = initializeApp({
  apiKey: "AIzaSyAQ0GpGRuNwZIgdu5tPSh9hklyPZkPl4Sk",
  authDomain: "cassuendejornal.firebaseapp.com",
  projectId: "cassuendejornal",
  storageBucket: "cassuendejornal.firebasestorage.app",
  messagingSenderId: "486922464736",
  appId: "1:486922464736:web:8bfe94aff6ce1bb3424f85",
  measurementId: "G-Y0W7B2D751"
});
const auth = getAuth(app), db = getFirestore(app);

const TAREFAS = [
  ["bi-book", "Encontrar materiais didácticos raros na internet", "Procuro apostilas, acervos e artigos difíceis de achar."],
  ["bi-shield-check", "Verificar Sistemas e as suas seguranças", "Analiso os teus sistemas e indico o que corrigir."],
  ["bi-file-earmark-pdf", "Recomendar fontes para baixar livros PDF gratuitos", "Indico bibliotecas e acervos com livros grátis."],
  ["bi-mortarboard", "Criar cursos de estudos", "Monto um plano completo, com etapas e exercícios."],
  ["bi-youtube", "Ver vídeos do YouTube", "Sugiro canais e pesquisas para aprender qualquer tema."],
  ["bi-film", "Recomendar filmes bons recentes e mostrar onde baixar", "Escolho os melhores e digo onde obtê-los."],
  ["bi-controller", "Onde encontrar os melhores jogos da PlayStation grátis", "Aponto os melhores jogos sem custo."]
];

const $ = id => document.getElementById(id);
const palco = $("palco"), conversa = $("conversa"), entrada = $("entrada"), btnEnviar = $("btn-enviar");
let uid = null, convId = null, hist = [], ocupado = false, unsub = null;

/* ---------- Navegação ---------- */
function mostrar(v) {
  for (const id of ["inicio", "tarefas", "chat"]) $(id).hidden = id !== v;
  palco.scrollTop = 0;
}
const gaveta = (abrir) => { $("gaveta").classList.toggle("ativo", abrir); $("sombra").classList.toggle("ativo", abrir); };
$("btn-menu").onclick = () => gaveta(true);
$("btn-fechar").onclick = $("sombra").onclick = () => gaveta(false);
$("btn-tarefa").onclick = () => mostrar("tarefas");
$("btn-voltar").onclick = () => mostrar("inicio");
const nova = () => { convId = null; hist = []; conversa.innerHTML = ""; marcarAtivo(); mostrar("inicio"); gaveta(false); };
$("btn-nova").onclick = $("btn-nova2").onclick = nova;
$("btn-sair").onclick = () => signOut(auth);

$("lista-tarefas").innerHTML = TAREFAS.map(([ic, t, d], i) =>
  `<button class="tarefa" data-i="${i}"><i class="bi ${ic}"></i><span><b>${t}</b><small>${d}</small></span></button>`).join("");
$("lista-tarefas").onclick = e => { const b = e.target.closest(".tarefa"); if (b) enviar(TAREFAS[b.dataset.i][1]); };

/* ---------- Markdown mínimo ---------- */
const esc = s => s.replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function md(t) {
  const blocos = [];
  t = esc(t).replace(/```(\w*)\n?([\s\S]*?)(```|$)/g, (_, l, c) => { blocos.push(`<pre><code>${c.replace(/\n$/, "")}</code></pre>`); return `\u0000${blocos.length - 1}\u0000`; });
  const inl = s => s.replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*\n]+)\*/g, "<em>$1</em>").replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  let out = "", lista = null, m;
  const fecha = () => { if (lista) { out += `</${lista}>`; lista = null; } };
  for (const l of t.split("\n")) {
    if (/^\u0000\d+\u0000$/.test(l.trim())) { fecha(); out += l.trim(); }
    else if ((m = l.match(/^#{1,4}\s+(.*)/))) { fecha(); out += `<h4>${inl(m[1])}</h4>`; }
    else if ((m = l.match(/^\s*[-*]\s+(.*)/))) { if (lista !== "ul") { fecha(); out += "<ul>"; lista = "ul"; } out += `<li>${inl(m[1])}</li>`; }
    else if ((m = l.match(/^\s*\d+[.)]\s+(.*)/))) { if (lista !== "ol") { fecha(); out += "<ol>"; lista = "ol"; } out += `<li>${inl(m[1])}</li>`; }
    else if (!l.trim()) fecha();
    else { fecha(); out += `<p>${inl(l)}</p>`; }
  }
  fecha();
  return out.replace(/\u0000(\d+)\u0000/g, (_, i) => blocos[i]);
}

/* ---------- Bolhas ---------- */
const rolar = () => { palco.scrollTop = palco.scrollHeight; };
function bolha(role, texto) {
  const d = document.createElement("div");
  d.className = "msg " + role;
  if (role === "ia") d.innerHTML = md(texto || ""); else d.textContent = texto;
  conversa.appendChild(d); rolar(); return d;
}

/* ---------- OpenRouter com efeito typing ---------- */
function responder(el) {
  return new Promise(async (resolve, reject) => {
    let full = "", shown = 0, fim = false;
    const timer = setInterval(() => {
      const resto = full.length - shown;
      if (resto > 0) { shown += Math.max(1, Math.ceil(resto / 30)); el.innerHTML = md(full.slice(0, shown)) + '<span class="cursor"></span>'; rolar(); }
      else if (fim) { clearInterval(timer); el.innerHTML = md(full); resolve(full); }
    }, 20);
    el.innerHTML = '<span class="cursor"></span>';
    try {
      const msgs = [{ role: "system", content: REGRAS }, ...hist.slice(-CONFIG.maxMensagensContexto)];
      const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + CONFIG.openrouterKey, "X-Title": "Cassuende.IA" },
        body: JSON.stringify({ model: CONFIG.modelo + (CONFIG.pesquisaWeb ? ":online" : ""), stream: true, messages: msgs })
      });
      if (!r.ok) throw new Error("OpenRouter " + r.status);
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "";
      for (;;) {
        const { done, value } = await rd.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        const linhas = buf.split("\n"); buf = linhas.pop();
        for (const l of linhas) {
          if (!l.startsWith("data: ")) continue;
          const d = l.slice(6).trim(); if (d === "[DONE]") continue;
          try { const t = JSON.parse(d).choices?.[0]?.delta?.content; if (t) full += t; } catch {}
        }
      }
      if (!full) throw new Error("Resposta vazia");
      fim = true;
    } catch (e) { clearInterval(timer); reject(e); }
  });
}

/* ---------- Firestore ---------- */
const colConv = () => collection(db, "users", uid, "conversas");
async function salvar(role, texto) {
  try {
    await addDoc(collection(db, "users", uid, "conversas", convId, "mensagens"), { role, texto: texto.slice(0, 19900), criadoEm: serverTimestamp() });
    await setDoc(doc(colConv(), convId), { atualizadoEm: serverTimestamp() }, { merge: true });
  } catch (e) { console.warn("Não foi possível sincronizar:", e); }
}

async function enviar(texto) {
  texto = (texto || "").trim();
  if (!texto || ocupado) return;
  ocupado = true; btnEnviar.disabled = true; entrada.value = ""; ajustar(); mostrar("chat");
  if (!convId) {
    convId = doc(colConv()).id;
    try { await setDoc(doc(colConv(), convId), { titulo: texto.slice(0, 50), criadoEm: serverTimestamp(), atualizadoEm: serverTimestamp() }); } catch (e) { console.warn(e); }
    marcarAtivo();
  }
  bolha("user", texto); hist.push({ role: "user", content: texto }); salvar("user", texto);
  const el = bolha("ia", "");
  try {
    const resp = await responder(el);
    hist.push({ role: "assistant", content: resp }); salvar("ia", resp);
  } catch (e) {
    el.className = "msg erro";
    el.textContent = "Não consegui responder agora (" + e.message + "). Verifica a ligação e a chave da OpenRouter.";
    hist.pop();
  }
  ocupado = false; btnEnviar.disabled = false; entrada.focus();
}

async function abrir(id) {
  convId = id; hist = []; conversa.innerHTML = ""; gaveta(false); marcarAtivo(); mostrar("chat");
  const snap = await getDocs(query(collection(db, "users", uid, "conversas", id, "mensagens"), orderBy("criadoEm")));
  snap.forEach(d => { const { role, texto } = d.data(); bolha(role === "ia" ? "ia" : "user", texto); hist.push({ role: role === "ia" ? "assistant" : "user", content: texto }); });
  rolar();
}
async function apagar(id) {
  if (!confirm("Apagar esta conversa?")) return;
  const ms = await getDocs(collection(db, "users", uid, "conversas", id, "mensagens"));
  await Promise.all(ms.docs.map(m => deleteDoc(m.ref)));
  await deleteDoc(doc(colConv(), id));
  if (id === convId) nova();
}
const marcarAtivo = () => document.querySelectorAll("#lista-historico li").forEach(li => li.classList.toggle("ativo", li.dataset.id === convId));

function ouvirHistorico() {
  unsub?.();
  unsub = onSnapshot(query(colConv(), orderBy("atualizadoEm", "desc")), snap => {
    const ul = $("lista-historico");
    if (snap.empty) { ul.innerHTML = '<li class="vazio">Ainda não há conversas.</li>'; return; }
    ul.innerHTML = snap.docs.map(d => `<li data-id="${d.id}"><button class="titulo">${esc(d.data().titulo || "Conversa")}</button><button class="apagar" aria-label="Apagar"><i class="bi bi-trash3"></i></button></li>`).join("");
    marcarAtivo();
  });
}
$("lista-historico").onclick = e => {
  const li = e.target.closest("li[data-id]"); if (!li) return;
  e.target.closest(".apagar") ? apagar(li.dataset.id) : abrir(li.dataset.id);
};

/* ---------- Compositor ---------- */
function ajustar() { entrada.style.height = "auto"; entrada.style.height = Math.min(entrada.scrollHeight, 140) + "px"; }
entrada.addEventListener("input", ajustar);
entrada.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && matchMedia("(hover:hover)").matches) { e.preventDefault(); enviar(entrada.value); } });
$("compor").addEventListener("submit", e => { e.preventDefault(); enviar(entrada.value); });

/* ---------- Sessão ---------- */
onAuthStateChanged(auth, u => {
  if (!u) { location.replace("index.html"); return; }
  uid = u.uid; ouvirHistorico();
});
