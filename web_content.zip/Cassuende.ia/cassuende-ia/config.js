// ATENÇÃO: qualquer chave colocada aqui fica visível a quem abrir a página.
export const CONFIG = {
  openrouterKey: "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",
  modelo: "openai/gpt-4o-mini",   // troque por qualquer modelo da OpenRouter
  pesquisaWeb: false,             // true = acrescenta ":online" ao modelo (pesquisa na web, custa mais)
  maxMensagensContexto: 20
};
