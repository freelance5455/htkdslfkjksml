// تشغيل: node setup.js
// يحمّل three.js، يثبّت Capacitor، ينشئ مشروع Android، ويضبط الاتجاه الأفقي وملء الشاشة.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const run = (cmd) => { console.log('> ' + cmd); execSync(cmd, { stdio: 'inherit' }); };

(async () => {
  const threePath = path.join('www', 'three.min.js');
  if (!fs.existsSync(threePath) || fs.statSync(threePath).size < 100000) {
    console.log('تنزيل three.js ...');
    const res = await fetch('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js');
    if (!res.ok) throw new Error('فشل تنزيل three.js: ' + res.status);
    fs.writeFileSync(threePath, Buffer.from(await res.arrayBuffer()));
  }

  run('npm install');
  if (!fs.existsSync('android')) run('npx cap add android');
  run('npx cap sync android');

  const manifest = path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml');
  let m = fs.readFileSync(manifest, 'utf8');
  if (!m.includes('screenOrientation')) {
    m = m.replace('<activity ', '<activity android:screenOrientation="sensorLandscape" ');
    fs.writeFileSync(manifest, m);
    console.log('تم ضبط الاتجاه الأفقي في AndroidManifest.xml');
  }

  const styles = path.join('android', 'app', 'src', 'main', 'res', 'values', 'styles.xml');
  if (fs.existsSync(styles)) {
    let s = fs.readFileSync(styles, 'utf8');
    if (!s.includes('windowFullscreen')) {
      s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
      fs.writeFileSync(styles, s);
      console.log('تم تفعيل ملء الشاشة');
    }
  }

  run('npx cap sync android');
  console.log('\nجاهز. الآن شغّل:  npx cap open android');
  console.log('ثم في Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)');
})().catch((e) => { console.error(e.message || e); process.exit(1); });
