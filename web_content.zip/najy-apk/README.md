# ناجي في البرية: مشروع APK أفقي

## المطلوب على جهازك
- Node.js 18 أو أحدث
- Android Studio (يأتي معه Android SDK وJDK)

## الخطوات
1. افتح الطرفية داخل هذا المجلد.
2. شغّل: `node setup.js`
   (ينزّل three.js، ويثبّت Capacitor، وينشئ مشروع Android، ويضبط الاتجاه الأفقي وملء الشاشة).
3. شغّل: `npx cap open android` ليفتح المشروع في Android Studio، وانتظر انتهاء Gradle Sync.
4. من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد الملف في: `android/app/build/outputs/apk/debug/app-debug.apk`، انسخه إلى هاتفك وثبّته.

## ملاحظات
- لتعديل اللعبة: عدّل `www/index.html` ثم شغّل `npx cap sync android` وابنِ مجددًا.
- الخط العربي (Reem Kufi / Cairo) يتحمّل من الإنترنت، وبدون اتصال يظهر خط النظام.
- للنشر على Google Play يلزم بناء ملف AAB موقّع: Build > Generate Signed Bundle / APK.
- إن ظهرت شاشة «أدِر الهاتف» فالجهاز عمودي. التطبيق مضبوط على الأفقي في الإعدادات.
