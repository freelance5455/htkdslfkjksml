Part Fitment Finder - Android App Project
========================================
এটি Android Studio-ready project।

Build:
1. Android Studio-তে এই folder খুলুন।
2. Gradle sync শেষ হতে দিন।
3. Build > Build APK(s) নির্বাচন করুন।
4. Debug APK সাধারণত app/build/outputs/apk/debug/app-debug.apk এ তৈরি হবে।

App-এর UI assets/index.html-এ রাখা হয়েছে।
বর্তমান app offline/localStorage database ব্যবহার করে।
TecDoc/PartSouq live data পেতে বৈধ API/data licence এবং backend integration প্রয়োজন।
