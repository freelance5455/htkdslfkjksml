ServiceSaathi — Car Washing + Hair Cutting starter

WHAT THIS ZIP DOES
- A mobile-friendly HTML demo with customer booking form.
- Owner can add workers (car washing, hair cutting, or both).
- Owner can assign workers to bookings and cycle booking status.
- Demo data is stored only in this browser using localStorage.

IMPORTANT
This is NOT yet an online multi-user app. LocalStorage data does not sync between phones.
To make it genuinely online, create a Firebase project and connect Firebase Authentication + Cloud Firestore.
Before real customers use it, secure admin/worker/customer permissions with Firestore Security Rules.
Do not put service-account secrets in HTML.

BEGINNER STEPS
1. Unzip this folder on your phone.
2. Open index.html in Acode and preview it, or open it in a browser.
3. Try adding a worker in Owner / Admin, then create a booking in Book Service.
4. To make it online, open https://firebase.google.com/docs/web/setup and create a Firebase Web app.
5. Enable Authentication (email/password or phone) and create a Cloud Firestore database.
6. Replace the demo localStorage code with authenticated Firestore reads/writes and secure rules.
7. Host the web app over HTTPS (Firebase Hosting is one option). Then wrap it into an APK if desired.

SECURITY NOTE
This demo's Owner / Admin tab is not password-protected. Do not publish it as a production app or enter real customer data until authentication and authorization rules are implemented.
