package com.cofre.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.graphics.BitmapFactory;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(2, 13, 36));
        getWindow().setNavigationBarColor(Color.rgb(2, 13, 36));
        getWindow().getDecorView().setSystemUiVisibility(0);
        showSplash();
    }
    private void showSplash() {
        ImageView splash = new ImageView(this);
        splash.setBackgroundColor(Color.rgb(2, 13, 36));
        try { splash.setImageBitmap(BitmapFactory.decodeStream(getAssets().open("splash.png"))); }
        catch (Exception ignored) {}
        splash.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setContentView(splash);
        splash.postDelayed(this::showApp, 1400);
    }
    private void showApp() {
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setDefaultTextEncodingName("UTF-8");
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        View v = getWindow().getDecorView().findViewById(android.R.id.content);
        if (v instanceof WebView && ((WebView)v).canGoBack()) ((WebView)v).goBack();
        else super.onBackPressed();
    }
}
