COFRE - projeto Android baseado no HTML enviado


O projeto empacota o HTML original em um WebView local, com armazenamento local (localStorage),
ícone do app derivado do logo enviado e splash screen com a arte COFRE enviada.


PARA COMPILAR O APK:
1. Instale Android Studio (https://developer.android.com/studio).
2. Abra Android Studio > Open e selecione esta pasta (cofre_android).
3. Aguarde sincronização do Gradle e instalação do SDK Android 35 (se solicitado).
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK será gerado em app/build/outputs/apk/debug/app-debug.apk.

O APK ainda não está incluído: este ambiente não tem Android SDK/Gradle instalado para compilar.
