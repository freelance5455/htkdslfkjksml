Nazmus Sakib | Investment Calculator - Android APK Project

এই project AndroidIDE বা Android Studio দিয়ে build করা যাবে।

মূল calculator রাখা হয়েছে:
app/src/main/assets/index.html

App icon:
app/src/main/res/drawable/app_icon.png

AndroidIDE:
1. ZIP extract করুন।
2. AndroidIDE-তে project folder open/import করুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Assemble Debug / Run চাপুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk এ তৈরি হবে।

নোট: APK offline local HTML calculator চালায়। PDF button-এর আচরণ WebView/Android version অনুযায়ী ভিন্ন হতে পারে।
