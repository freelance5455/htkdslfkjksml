// Список достижений. Новое достижение = одна строка здесь + 2 строки текста (ach_<id>_n и ach_<id>_d) в ru/en/zh.
// id — имя; icon — номер картинки в assets/img/ach_icons.png (иконки 64x64 подряд слева направо, с 0);
// coins — приз; stat — что считаем (см. ACH_STAT в js/game/achievements.js); need — сколько нужно набрать.
// Новая иконка: функция i_<имя> в tools/ach/icons_*.py + python3 tools/make_ach_icons.py, и увеличить ACH_ICONS.
const ACH_ICONS=25; // сколько иконок в ach_icons.png
const ACH=[
 // кормление
 {id:'meal',     icon:0,  coins:15,  stat:'eaten',    need:1},
 {id:'gourmet',  icon:1,  coins:40,  stat:'eaten',    need:10},
 {id:'feast',    icon:2,  coins:60,  stat:'eaten',    need:50},
 {id:'glutton',  icon:3,  coins:120, stat:'eaten',    need:200},
 // линька
 {id:'molt',     icon:4,  coins:30,  stat:'molts',    need:1},
 {id:'molt5',    icon:5,  coins:70,  stat:'molts',    need:5},
 // питомцы
 {id:'collector',icon:6,  coins:40,  stat:'pets',     need:2},
 {id:'zoo',      icon:7,  coins:100, stat:'pets',     need:5},
 {id:'species',  icon:8,  coins:90,  stat:'species',  need:4},
 {id:'mantis',   icon:9,  coins:50,  stat:'mantis',   need:1},
 {id:'snake',    icon:10, coins:50,  stat:'snake',    need:1},
 {id:'happy',    icon:23, coins:40,  stat:'mood',     need:100},
 // мини-игра и ежедневный бонус
 {id:'hunter',   icon:11, coins:30,  stat:'mg',       need:60},
 {id:'sniper',   icon:12, coins:80,  stat:'mg',       need:120},
 {id:'regular',  icon:13, coins:25,  stat:'streak',   need:3},
 {id:'week',     icon:14, coins:70,  stat:'streak',   need:7},
 // инкубатор
 {id:'hatch',    icon:15, coins:40,  stat:'hatched',  need:1},
 {id:'brood',    icon:16, coins:100, stat:'hatched',  need:25},
 {id:'cups',     icon:17, coins:60,  stat:'cups',     need:5},
 {id:'trader',   icon:18, coins:30,  stat:'sold',     need:1},
 // кормовые насекомые
 {id:'farmer',   icon:19, coins:25,  stat:'colonies', need:1},
 {id:'farm',     icon:20, coins:60,  stat:'colonies', need:3},
 // террариум и деньги
 {id:'decor',    icon:21, coins:20,  stat:'decor',    need:1},
 {id:'designer', icon:22, coins:80,  stat:'decor',    need:5},
 {id:'rich',     icon:24, coins:80,  stat:'coins',    need:2000}
];
