// Данные: названия видов, корма (INS), кормовые ключи
const SPN={boehmei:'Brachypelma Boehmei',albo:'Tliltocatl albopilosus',hamori:'Brachypelma hamori',murinus:'Pterinochilus murinus',muticus:'Pelinobius muticus',scorpion3:'Pandinus imperator',mantis:'Spodromantis lineola'};
const SPK=['boehmei','albo','hamori','murinus','muticus'];
const KEYS=['turk','arg','cri'],FOOD=[...KEYS,'mou'];
const spn0=k=>{k=bs(k);return isSn(k)?t('n_'+k):SPN[k]};
const spnDef=k=>{const n=String(k).split('#')[1];return spn0(k)+(n?' #'+n:'')};
const spn=k=>{const d=S.d&&S.d[k];return(d&&d.name)||spnDef(k)};
const INS={
 turk:{n:'Туркменский таракан',pl:'Туркменские тараканы',go:'m_roach',c1:'#5a2a10',c2:'#8e3b17',c3:'#b5531f'},
 arg:{n:'Аргентинский таракан',pl:'Аргентинские тараканы',go:'m_roach',c1:'#150d09',c2:'#2a1c14',c3:'#4d3626'},
 mou:{go:'m_mouse'},
 cri:{n:'Классический сверчок',pl:'Классические сверчки',go:'m_cri',c1:'#6b4a24',c2:'#a8844a',c3:'#c9a468'}
};
