// Иконка замка (сталь + латунь) для закрытых карточек
// ---- замок: попиксельно в родном разрешении холста (сталь + латунь, обводка, блики, заклёпки, замочная скважина, тень) ----
const LOCKC={};
function lockCanvas(w){let c=LOCKC[w];if(c)return c;
 const h=Math.round(w*1.25);c=LOCKC[w]=document.createElement('canvas');c.width=w;c.height=h;
 const ctx=c.getContext('2d'),im=ctx.createImageData(w,h),d=im.data,hx=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16));
 const ST=['#454f54','#74828a','#a6b3ba','#d8e1e5','#ffffff'].map(hx),BR=['#5e3806','#9a6610','#d29418','#f0bf3e','#fff2a6'].map(hx),OL=hx('#1f120c'),KH=hx('#150b07');
 const Lx=-.5,Ly=-.55,Lz=.67,ot=Math.max(1,Math.round(w/44));
 const sdR=(X,Y,cx,cy,hw,hh,r)=>{const qx=Math.abs(X-cx)-(hw-r),qy=Math.abs(Y-cy)-(hh-r);return Math.hypot(Math.max(qx,0),Math.max(qy,0))+Math.min(Math.max(qx,qy),0)-r};
 const SC=.5,SY=.37,RC=.255,HT=.065,SY2=.78;
 const shackle=(X,Y)=>{let s,nx,ny;
  if(Y<SY){const dx=X-SC,dy=Y-SY,r=Math.hypot(dx,dy);s=(r-RC)/HT;if(Math.abs(s)>1)return -1;nx=dx/r*s;ny=dy/r*s}
  else{if(Y>SY2)return -1;const dx=X-SC;s=(Math.abs(dx)-RC)/HT;if(Math.abs(s)>1)return -1;nx=Math.sign(dx)*s;ny=0}
  return Math.max(0,nx*Lx+ny*Ly+Math.sqrt(Math.max(0,1-s*s))*Lz)};
 const BODY=(X,Y)=>sdR(X,Y,.5,.865,.43,.315,.12),PLATE=(X,Y)=>sdR(X,Y,.5,.865,.35,.235,.07);
 const grad=(f,X,Y)=>{const e=.004,gx=f(X+e,Y)-f(X-e,Y),gy=f(X,Y+e)-f(X,Y-e),l=Math.hypot(gx,gy)||1;return[gx/l,gy/l]};
 const lit=(f,X,Y)=>{const n=grad(f,X,Y);return-(n[0]*Lx+n[1]*Ly)/.743};
 const RIV=[[.215,.685],[.785,.685],[.215,1.045],[.785,1.045]];
 const inKey=(X,Y)=>Math.hypot(X-.5,Y-.8)<.068||(Y>=.8&&Y<=1.01&&Math.abs(X-.5)<=.03+.024*(Y-.8)/.21);
 const body=(X,Y)=>{const sd=BODY(X,Y);if(sd>0)return null;const e=-sd,t=(Y-.55)/.63;let i;
  if(e<.05){const l=lit(BODY,X,Y);i=l>.55?4:l>.15?3:l>-.3?2:l>-.7?1:0}
  else{const pd=PLATE(X,Y);
   if(pd<0){const e2=-pd;if(e2<.018){i=lit(PLATE,X,Y)>0?1:3}else{i=t<.45?2:1;const q=X+Y;if(q>1.0&&q<1.06&&Y<1.0)i=Math.min(4,i+2)}}
   else i=t<.45?3:2}
  if(Y<.63&&Math.abs(Math.abs(X-.5)-RC)<HT+.015)i=Math.max(0,i-1);
  let col=BR[i];
  for(const r of RIV){const dd=Math.hypot(X-r[0],Y-r[1]);if(dd<.032){const u=((X-r[0])+(Y-r[1]))/.032;col=BR[u<-.5?4:u<.35?3:1]}else if(dd<.043)col=BR[0]}
  if(inKey(X,Y))col=KH;else if(inKey(X-.016,Y-.016))col=BR[3];
  return col};
 const idm=new Uint8Array(w*h),col=new Array(w*h);
 for(let j=0;j<h;j++)for(let i=0;i<w;i++){const X=(i+.5)/w,Y=(j+.5)/w,b=body(X,Y);
  if(b){idm[j*w+i]=2;col[j*w+i]=b}else{const sh=shackle(X,Y);if(sh>=0){idm[j*w+i]=1;col[j*w+i]=ST[sh<.18?0:sh<.42?1:sh<.68?2:sh<.88?3:4]}}}
 const at=(i,j)=>i<0||j<0||i>=w||j>=h?0:idm[j*w+i],so=Math.max(1,Math.round(w/30)),DIR=[[1,0],[-1,0],[0,1],[0,-1]];
 for(let j=0;j<h;j++)for(let i=0;i<w;i++){const id=idm[j*w+i],p=(j*w+i)*4;let o=null,a=255;
  if(id){let edge=false;for(let k=1;k<=ot&&!edge;k++)for(const q of DIR){const n=at(i+q[0]*k,j+q[1]*k);if(n===0||(id===2&&n===1)){edge=true;break}}
   o=edge?OL:col[j*w+i]}
  else if(at(i-so,j-so)){o=[0,0,0];a=90}
  if(o){d[p]=o[0];d[p+1]=o[1];d[p+2]=o[2];d[p+3]=a}}
 ctx.putImageData(im,0,0);return c}
function stampLock(c,cx,cy,w){const l=lockCanvas(w);c.save();c.setTransform(1,0,0,1,0,0);c.imageSmoothingEnabled=false;c.drawImage(l,Math.round(cx-l.width/2),Math.round(cy-l.height/2));c.restore()}

