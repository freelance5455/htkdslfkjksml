// Отрисовка кормовых насекомых (таракан, сверчок), мышь-приманка
// Кормовые — готовые спрайты assets/img/bug_arg|turk|cri.png (их делает tools/make_bugs.py из фото tools/src/bugs_ref.png). Голова внизу, насекомое бежит к пауку.
// Каждый файл — лента кадров в один ряд: кадр 0 — тело (статично), кадры 1..8 — лапы (цикл ходьбы), кадры 9..16 — усики (покачивание).
// Рисуем три слоя друг на друга: лапы -> тело -> усики, у лап и усиков свой темп.
// w,h — размер кадра в пикселях спрайта; ax,ay — где в кадре центр тела (это и есть точка (x,y) насекомого)
const BUG_SP={
 arg:{src:'assets/img/bug_arg.png',w:24,h:40,ax:11.9,ay:16.1},
 turk:{src:'assets/img/bug_turk.png',w:17,h:29,ax:9.1,ay:13},
 cri:{src:'assets/img/bug_cri.png',w:14,h:26,ax:7.2,ay:9.9}
};
const BUG_N=8,BUG_M=8,BUG_K=.75,BUG_LEG=22,BUG_ANT=5; // кадров лап / усиков; размер пикселя спрайта в пикселях игры; скорость лап и усиков (рад/с)
const BUG_IM={};for(const k in BUG_SP){const im=new Image();im.onload=()=>{try{if(typeof shopBugsRedraw==='function')shopBugsRedraw()}catch(e){}};im.src=BUG_SP[k].src;BUG_IM[k]=im}
function drawBug(k,x,y,t){x=Math.round(x);y=Math.round(y);if(k==='mou'){mouseR(x,y+3,Math.PI/2,t,.75);return}
 const B=BUG_SP[k],im=BUG_IM[k];if(!B||!im||!im.complete||!im.naturalWidth)return;
 const tr=g.getTransform(),sc=Math.hypot(tr.a,tr.b)||1,e=sc*BUG_K,sn=v=>Math.round(v*sc)/sc,fr=(w,n)=>Math.floor((((t*w/6.2832)%1)+1)%1*n)%n;
 const dx=sn(x-B.ax*BUG_K),dy=sn(y-B.ay*BUG_K),dw=B.w*BUG_K,dh=B.h*BUG_K;
 g.save();g.imageSmoothingEnabled=e<2;g.imageSmoothingQuality='high';
 for(const c of[1+fr(BUG_LEG,BUG_N),0,1+BUG_N+fr(BUG_ANT,BUG_M)])g.drawImage(im,c*B.w,0,B.w,B.h,dx,dy,dw,dh); // лапы, тело, усики
 g.restore()}
function drawPrey(o){const j=st==='chew'?Math.sin(T*35)*(1-o.p)*1.3:0,x=Math.round(o.x+j),y=Math.round(o.y),I=INS[o.k];
 if(o.p<.7)drawBug(o.k,x,y,T);else{ell(x,y,4,3,I.c1);ell(x,y,3,2,I.c2);px(x-1,y-1,2,1,I.c3)}}

