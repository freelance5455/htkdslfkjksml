// Хелперы паука: полосатая лапа, мини-паук для витрин
// полосатая лапа: участок t0..t1 вдоль пути основание→колено→кончик
function bandLine(bs,kn,tp,w1,w2,t0,t1,c){const l1=Math.hypot(kn[0]-bs[0],kn[1]-bs[1]),l2=Math.hypot(tp[0]-kn[0],tp[1]-kn[1]),k=l1/((l1+l2)||1);
 const pt=t=>t<=k?[lerp(bs[0],kn[0],k?t/k:0),lerp(bs[1],kn[1],k?t/k:0)]:[lerp(kn[0],tp[0],(t-k)/(1-k)),lerp(kn[1],tp[1],(t-k)/(1-k))];
 if(t0<k){const a=pt(t0),b=pt(Math.min(t1,k));line(a[0],a[1],b[0],b[1],c,w1)}
 if(t1>k){const a=pt(Math.max(t0,k)),b=pt(t1);line(a[0],a[1],b[0],b[1],c,w2)}}
// паук в мини-размере на любом холсте (для бокса в магазине)
// временно ставит позу паука для рисования миниатюр; что бы ни случилось, всё возвращается назад
function withPose(p,fn){const o={x:sp.x,y:sp.y,ang,st,jaw,chew,PC,SC,PH,am,rx:ab.rx,ry:ab.ry};
 try{sp.x=p.x;sp.y=p.y;ang=p.ang||0;st='idle';jaw=0;chew=0;PC=p.PC;
  if(p.SC!==undefined)SC=p.SC;if(p.PH!==undefined)PH=p.PH;if(p.am!==undefined)am=p.am;if(p.ab!==undefined)ab.rx=ab.ry=p.ab;
  fn()}finally{sp.x=o.x;sp.y=o.y;ang=o.ang;st=o.st;jaw=o.jaw;chew=o.chew;PC=o.PC;SC=o.SC;PH=o.PH;am=o.am;ab.rx=o.rx;ab.ry=o.ry}}
function spiderAt(ctx,k,x,y,s,tt){withPose({x,y,ang:Math.sin(tt*.7)*.08,PC:PAL[bs(k)],SC:s,PH:tt*2.2,am:3.2+Math.sin(tt*.9)*.8,ab:10},()=>onCtx(ctx,drawSpider))}
