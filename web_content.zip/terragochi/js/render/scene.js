// Сборка кадра: draw() выбирает сцену по виду питомца
function drawInsBoxes(){document.querySelectorAll('#sgrid7 canvas.inner').forEach(c=>{const k=c.dataset.sk,x=c.getContext('2d');
 withPose({x:64,y:52,PC:PC,ab:10,am:3.2,PH:0},()=>{const T0=T;T=0;try{drawMantisScene(true);x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;x.drawImage(cv,160,0,320,416,0,0,80,104)}finally{T=T0}});
 fixCtx(x,2);if(!ownN(k)){x.fillStyle='rgba(10,6,4,.6)';x.fillRect(0,0,40,52);stampLock(x,40,50,34)}})}
function draw(){if(isMn(S.species)){mnK=S.species;drawMantisScene();return}drawBg(g);drawDecor();if(isSn(S.species)){sk.sp=S.species;{const f=stageF(D),o=64*(1-f);snakeRender(f,o,o,sk);if(sk.mo&&!sk.att)mouseR(o+sk.mo.x*f,o+sk.mo.y*f,sk.mo.a,T,f)}}else if(isSc(S.species))scorpionDraw();else{if(prey)drawPrey(prey);drawSpider()}for(const f of fx)(f.bad?drawDrop:drawHeart)(Math.round(f.x),Math.round(f.y),'#ff5a7a')}
/*DEBUG-START*/$('dbg').onclick=()=>{D.sat=0;save()};/*DEBUG-END*/
