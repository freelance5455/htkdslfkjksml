// Ранний показ меню: текст кнопок ставится сразу после загрузки языков, ещё до тяжёлой части игры.
// (Подписи под кнопками «Выбор питомца» и «Заработать» добавятся чуть позже, место под них уже зарезервировано в menu.css.)
document.querySelectorAll('#menu [data-i]').forEach(e=>{e.textContent=t(e.dataset.i)});
document.documentElement.lang=LANG;document.title=t('doc');
