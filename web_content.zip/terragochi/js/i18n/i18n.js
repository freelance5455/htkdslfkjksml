// Ядро локализации: таблица TR, выбор языка, функция t(). Сами строки — в js/i18n/ru.js, uk.js, en.js, zh.js
const TR={ru:{},uk:{},en:{},zh:{}};
let LANG='ru';try{const l=localStorage.getItem('spiderLang');LANG=['en','ru','uk','zh'].includes(l)?l:(/^ru/i.test(navigator.language||'')?'ru':/^uk/i.test(navigator.language||'')?'uk':/^zh/i.test(navigator.language||'')?'zh':'en')}catch(e){}
const t=k=>TR[LANG][k]??TR.ru[k]??k;
