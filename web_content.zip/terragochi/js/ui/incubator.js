// Экран «Инкубатор»: коконы, общий контейнер, стаканчики, кнопки отладки
/*INC-START*/
let incSig='',incT=0,incK=0,incArm={k:null,t:0};
const incFmt=s=>{s=Math.max(0,Math.ceil(s));const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h?h+t('ml_h')+' '+m+t('ml_m'):Math.max(1,m)+t('ml_m')};
const incAge=s=>{const d=Math.floor(s/86400),h=Math.floor(s%86400/3600);return d?d+t('ml_d')+' '+h+t('ml_h'):Math.max(0,h)+t('ml_h')};
// ---- рисование (пиксель-арт, вид сбоку; в стаканчиках картинка статичная) ----
// ---- паучок из картинки assets/img/sling.png: 10 кадров ходьбы по 48x30, смотрит ВЛЕВО; нижняя строка кадра = земля ----
const SLT={boehmei:.4,hamori:.35,murinus:.55,muticus:.4,albo:0}; // насколько подкрасить под вид (0 = как нарисовано)
const SLI=new Image(),SLC={};SLI.onload=()=>{for(const k in SLC)delete SLC[k]};SLI.src='assets/img/sling.png';
const slOk=()=>SLI.complete&&SLI.naturalWidth>0;
// размеры берутся из самой картинки: кадр любого размера с пропорцией 48:30 (96x60, 144x90 …), число кадров — по ширине полоски
const slH=()=>SLI.naturalHeight,slF=()=>Math.max(1,Math.round(SLI.naturalWidth/(SLI.naturalHeight*1.6))),slW=()=>SLI.naturalWidth/slF();
const incR=()=>slOk()?Math.max(1,Math.round(slW()/48)):1; // во сколько раз холсты чётче базовых (чтобы картинка высокого разрешения не размывалась)
function slSheet(sp){const k=bs(sp);if(SLC[k])return SLC[k];const c=document.createElement('canvas');c.width=SLI.naturalWidth;c.height=SLI.naturalHeight;const x=c.getContext('2d');x.drawImage(SLI,0,0);
 const a=SLT[k]||0;if(a){x.globalCompositeOperation='source-atop';x.globalAlpha=a;x.fillStyle=(PAL[k]||PAL.boehmei).carO;x.fillRect(0,0,c.width,c.height)}return SLC[k]=c}
// x — центр, y — земля, fr — номер кадра, sc — размер (1 = 48 пикселей), dir: -1 влево (как нарисовано), 1 вправо
// змейка-малыш (маисовый полоз / шаровидный питон): рисуется кодом, вид сбоку. x — центр, y — земля, sc — размер (1 ≈ 48 пикселей длиной), dir: -1 голова слева, 1 справа.
// Цвета по видам — таблица SNB: b — основной, s — пятна, v — брюшко/светлая часть головы.
const SNB={corn:{b:'#e0852f',s:'#b3321c',h:'#f2a04a'},ball:{b:'#2c1b10',s:'#a9783a',h:'#4d3524'}};
function incBabySnake(x,y,sp,tm,ph,sc,dir){const C=SNB[bs(sp)]||SNB.corn,u=sc*incR()*1.2,N=24,d=dir||1,w=tm?tm*2.4:0,OL='#120905';
 const rad=t=>u*(.75+2.1*Math.sin(Math.min(1,t*1.5)*1.5708))*(t>.9?1-(t-.9)*3:1); // от тонкого хвоста к телу, у головы чуть уже («шея»)
 const P=[];for(let i=0;i<=N;i++){const t=i/N;P.push([x+d*(t*44-22)*u,y-(3.8+2.4*Math.sin(t*9.5-w*2+ph*1.3)*(.3+.7*t))*u,t])}
 aEll(x,y,23*u,2.2*u,0,'rgba(0,0,0,.28)'); // тень
 for(const q of P)disc(q[0],q[1],rad(q[2])+.8*u,OL); // контур
 for(const q of P)disc(q[0],q[1],rad(q[2]),C.b);
 P.forEach((q,i)=>{if(i%4===2&&i<N-3){disc(q[0],q[1]-.25*u,rad(q[2])*.5,C.s)}else if(i%4===0&&i>2&&i<N-3)disc(q[0],q[1]-rad(q[2])*.45,rad(q[2])*.22,C.h)}); // пятна и блик
 const H=P[N],hx=H[0]+d*1.6*u,hy=H[1];
 aEll(hx,hy,4*u,2.9*u,0,OL);aEll(hx,hy,3.3*u,2.3*u,0,C.b);aEll(hx-d*.2*u,hy-.7*u,2*u,.8*u,0,C.h);
 disc(hx+d*.8*u,hy-.9*u,Math.max(.7,.75*u),'#f4f0e0');disc(hx+d*1*u,hy-.9*u,Math.max(.5,.4*u),OL); // глаз
 const tg=tm?Math.sin(tm*11+ph)*.9:0;aLine(hx+d*3.3*u,hy+.2*u,hx+d*6.3*u,hy+(.2+tg)*u,'#c8323c',Math.max(1,.5*u))} // язычок
function incSling(x,y,sp,tm,ph,sc,dir){if(isSnB(sp))return incBabySnake(x,y,sp,tm,ph,sc,dir);if(!slOk())return incSlingOld(x,y,sp,tm,ph,sc,dir);
 const SW=slW(),SH=slH(),w=SW*sc,h=SH*sc,fr=tm?Math.floor((tm*9+ph*3))%slF():Math.min(4,slF()-1);
 g.imageSmoothingEnabled=sc<1;g.imageSmoothingQuality='high';g.save();g.translate(Math.round(x),Math.round(y-h));if(dir>0)g.scale(-1,1);
 g.drawImage(slSheet(sp),fr*SW,0,SW,SH,Math.round(-w/2),0,Math.round(w),Math.round(h));g.restore();g.imageSmoothingEnabled=false}
// паучок-тарантул сбоку (смотрит вправо, dir=-1 — влево). x — центр, y — земля под лапами, sc — размер (1 ≈ 26 пикселей в ширину).
// Все ноги растут из головогруди; бедро идёт вверх к «колену», голень вниз к земле. Задние ноги уходят за брюшко, дальние — тёмные.
function incSlingOld(x,y,sp,tm,ph,sc,dir){const P=PAL[bs(sp)]||PAL.boehmei,s=sc||1,d=dir||1,w=Math.round(Math.sin(tm*7+ph)),by=y-6*s;
 const X=v=>Math.round(x+d*v*s),Y=v=>Math.round(by+v*s),LG=[[4,10,-7,12],[2,6,-9,8],[-1,-6,-9,-9],[-3,-11,-6,-13]];
 const leg=(k,o,up,lo,kn)=>{const[hx,kx,ky,fx]=LG[k],sw=s>.9?(k%2?w:-w):0;line(X(hx+o),Y(1),X(kx+o),Y(ky),up);line(X(kx+o),Y(ky),X(fx+o+sw),y,lo);if(kn)px(X(kx+o),Y(ky),1,1,kn)};
 const far=[1,3,0,2];for(const k of far)leg(k,1,'#241810','#3c281c');                       // дальние ноги
 leg(3,0,P.legU,P.legL,P.joint);leg(2,0,P.legU,P.legL,P.joint);                             // ближние задние
 ell(X(-4),by,5*s,4*s,P.abO||'#222');ell(X(-4),by-s,3*s,2*s,P.abI||'#333');px(X(-6),Y(-2),1,1,'rgba(255,255,255,.7)'); // брюшко
 ell(X(4),by+s,4*s,3*s,P.carO||'#c60');ell(X(4),by+s,2*s,1*s,P.carI||P.carO||'#a40');     // головогрудь
 px(X(6),Y(-1),1,1,'#fff');px(X(7),Y(3),1,2,P.chelA||'#111');px(X(8),Y(3),1,1,P.palp||P.legL);  // глаз, хелицеры, педипальпа
 leg(1,0,P.legU,P.legL,P.joint);leg(0,0,P.legU,P.legL,P.joint)}                              // ближние передние
function incCocoonAt(x,y,pct,tm){const w=pct>.9?Math.round(Math.sin(tm*14)):0;
 px(x-8,y,16,1,'rgba(0,0,0,.3)');ell(x+w,y-5,8,6,'#8f8468');ell(x+w,y-5.5,7,5.2,'#e8dfc6');ell(x-2+w,y-8,4,2.5,'#f6f0de');px(x-3+w,y-9,2,1,'#fffdf4');
 line(x-5+w,y-4,x+5+w,y-6,'rgba(150,140,110,.6)');line(x-3+w,y-1,x+4+w,y-3,'rgba(150,140,110,.5)');if(pct>.75)px(x+2+w,y-5,2,2,'rgba(90,60,40,.7)')}
// контейнер с коконами: k-й по счёту, в нём до 3 коконов (координаты 96x64)
function incDrawCoBox(c,k,tm){const I=S.inc,R=incR();if(c.width!==192*R){c.width=192*R;c.height=128*R}
 onCtx(c.getContext('2d'),()=>{g.imageSmoothingEnabled=false;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);
  g.setTransform(2*R,0,0,2*R,0,0);
  px(0,0,96,64,'#c9d9d9');px(0,0,96,64,'rgba(255,255,255,.1)');px(0,44,96,20,'#6b4a2c');px(0,44,96,2,'#8a6540');
  for(let i=0;i<30;i++)px((i*37+k*11)%96,46+(i*11)%16,1,1,i%2?'#59391f':'#7d5a36');
  I.co.slice(k*3,k*3+3).forEach((q,i)=>incCocoonAt(Math.round(16+i*32),50-(i%2)*2,1-q.t/q.c,tm));
  px(0,0,96,3,'#3a2f31');px(0,0,2,64,'rgba(255,255,255,.45)');px(94,0,2,64,'rgba(255,255,255,.3)');g.setTransform(1,0,0,1,0,0)})}
// яйцо змеи: кожистое, белёсое. pct — насколько близко вылупление (в конце яйца подрагивают)
function incEggAt(x,y,pct,tm,i){const w=pct>.9?Math.round(Math.sin(tm*13+i*2)):0;
 px(x-5,y,10,1,'rgba(0,0,0,.28)');ell(x+w,y-4,5,4,'#a79c80');ell(x+w,y-4.5,4.4,3.6,'#efe8d4');px(x-2+w,y-6,2,1,'#fffdf2');if(pct>.8)line(x-1+w,y-6,x+1+w,y-3,'rgba(120,100,70,.75)')}
// контейнер с яйцами: k-й по счёту, в нём одна кладка (координаты 96x64). Яйца лежат кучкой: нижний ряд и верхний
function incDrawEgBox(c,k,tm){const I=S.inc,R=incR(),q=I.eg[k];if(c.width!==192*R){c.width=192*R;c.height=128*R}
 onCtx(c.getContext('2d'),()=>{g.imageSmoothingEnabled=false;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);
  g.setTransform(2*R,0,0,2*R,0,0);
  px(0,0,96,64,'#d3e0dc');px(0,0,96,64,'rgba(255,255,255,.1)');px(0,42,96,22,'#b8aa86');px(0,42,96,2,'#d2c59f');
  for(let i=0;i<34;i++)px((i*37+k*13)%96,45+(i*11)%18,1,1,i%2?'#9d8f6a':'#cfc29c');
  if(q){const pct=1-q.t/q.c,b=Math.min(7,Math.ceil(q.n*.6)),u=q.n-b;
   for(let i=0;i<b;i++)incEggAt(Math.round(48+(i-(b-1)/2)*11),58,pct,tm,i);
   for(let i=0;i<u;i++)incEggAt(Math.round(48+(i-(u-1)/2)*11),52,pct,tm,i+b)}
  else{g.fillStyle='rgba(0,0,0,.12)';g.fillRect(0,0,96,64)}
  px(0,0,96,3,'#3a3f3f');px(0,0,2,64,'rgba(255,255,255,.45)');px(94,0,2,64,'rgba(255,255,255,.3)');g.setTransform(1,0,0,1,0,0)})}
function incDrawCrowd(c,tm){const I=S.inc,R=incR();if(c.width!==256*R){c.width=256*R;c.height=128*R}
 onCtx(c.getContext('2d'),()=>{g.imageSmoothingEnabled=false;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);
 g.setTransform(2*R,0,0,2*R,0,0); // фон и коконы рисуем в координатах 128x64, паучков — в полном разрешении
 px(0,0,128,64,'#c9d9d9');px(0,0,128,64,'rgba(255,255,255,.1)');px(0,44,128,20,'#6b4a2c');px(0,44,128,2,'#8a6540');
 for(let i=0;i<40;i++)px((i*37)%128,46+(i*11)%16,1,1,i%2?'#59391f':'#7d5a36');
 g.setTransform(1,0,0,1,0,0);
 const all=[];let k=0;for(const gr of I.cr){const m=Math.min(gr.n,14);for(let i=0;i<m;i++,k++){const u=tm*(.25+bh(k,5)*.3)+bh(k,6)*6.28;all.push({k,sp:gr.sp,x:Math.round(2*R*(14+bh(k,1)*100+Math.sin(u)*6)),y:Math.round(2*R*(48+bh(k,2)*13)),dir:Math.cos(u)>=0?1:-1})}}
 all.sort((a,b)=>a.y-b.y);for(const q of all)incSling(q.x,q.y,q.sp,tm,q.k,.5,q.dir);
 g.setTransform(2*R,0,0,2*R,0,0);
 px(0,0,128,3,'#3a2f31');px(0,0,2,64,'rgba(255,255,255,.45)');px(126,0,2,64,'rgba(255,255,255,.3)');g.setTransform(1,0,0,1,0,0)})}
function incDrawCup(c,i){const u=S.inc.cups[i],R=incR();if(c.width!==72*R){c.width=72*R;c.height=84*R}
 onCtx(c.getContext('2d'),()=>{g.imageSmoothingEnabled=false;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);g.setTransform(R,0,0,R,0,0);
 px(0,0,72,84,u?'#cfe0e0':'#b9c6c8');px(0,0,72,84,'rgba(255,255,255,.1)');
 const wet=u?u.wt/100:0,sub=wet>.5?'#5a3a20':wet>.2?'#7d5a36':'#9c8052';
 px(0,58,72,26,sub);px(0,58,72,2,'rgba(255,255,255,.18)');for(let k=0;k<30;k++)px((k*29+i*7)%72,62+(k*13)%20,1,1,k%2?'rgba(0,0,0,.25)':'rgba(255,255,255,.12)');
 if(u){if(wet>.3)for(let k=0;k<6;k++)px(6+k*11+(i%3),56+((k*7)%3),2,1,'rgba(170,215,235,.7)');
  g.setTransform(1,0,0,1,0,0);incSling(36*R,62*R,u.sp,0,i,Math.min(1,.7+(u.age||0)/(14*86400)*.3),i%2?1:-1); // растёт с возрастом: от 70% до 100%
  g.setTransform(R,0,0,R,0,0);
  if(u.fd<=0||u.wt<=0){px(56,6,11,11,'#b33a22');px(60,8,3,5,'#fff');px(60,15,3,2,'#fff')}}
 else{g.fillStyle='rgba(0,0,0,.18)';g.fillRect(0,0,72,84)}
 px(0,0,72,5,'#4b3f40');for(let k=0;k<9;k++)px(3+k*8,1,3,2,'#1c1213');
 px(0,5,2,79,'rgba(255,255,255,.5)');px(70,5,2,79,'rgba(255,255,255,.3)');g.setTransform(1,0,0,1,0,0)})}
// ---- сборка экрана ----
const incNm=sp=>typeof spn0==='function'?spn0(bs(sp)):bs(sp);
const incShort=sp=>{if(isSnB(sp))return incNm(sp);const w=incNm(sp).split(' ');return w.length>1?w[0][0]+'. '+w.slice(1).join(' '):w[0]};
function incSigNow(){const I=S.inc;return LANG+'|'+I.co.map(c=>c.id).join(',')+'|'+I.eg.map(c=>c.id).join(',')+'|'+I.cr.map(g=>g.sp+g.n).join(',')+'|'+I.cups.map(c=>c?c.sp:'-').join(',')+'|'+incFree()}
function incBuild(){const I=S.inc,box=$('incBody'),cr=incCrowd();
 const nb=Math.max(2,Math.ceil(I.co.length/3));let cob='';
 for(let k=0;k<nb;k++){const rows=I.co.slice(k*3,k*3+3).map(c=>`<div class="icl"><span>🥚 ${incShort(c.sp)} · ~${c.n}</span><small data-t="${c.id}"></small><div class="bar"><i data-pb="${c.id}"></i></div></div>`).join('');
  cob+=`<div class="ico"><canvas class="icv" data-cob="${k}" width="192" height="128"></canvas>${rows}</div>`}
 const cups=I.cups.map((u,i)=>u?`<div class="icup" data-cup="${i}"><canvas class="icv" width="72" height="84"></canvas><b class="inm" data-age="${i}"></b>
  <div class="bar"><i data-fd="${i}"></i></div><div class="bar"><i data-wt="${i}"></i></div>
  <div class="btnrow"><button data-a="feed" data-i2="${i}" aria-label="${t('inc_feed')}">🍗</button><button data-a="wet" data-i2="${i}" aria-label="${t('inc_wet')}">💧</button><button data-a="sell" data-i2="${i}" aria-label="${t('inc_sell')}" class="sl">💰</button></div></div>`
  :`<div class="icup empty" data-cup="${i}"><canvas class="icv" width="72" height="84"></canvas></div>`).join('');
 let egb='';for(let k=0;k<INC.maxEg;k++){const q=I.eg[k];
  const row=q?`<div class="icl"><span>🥚 ${incShort(q.sp)} · ${q.n}</span><small data-t="${q.id}"></small><div class="bar"><i data-pb="${q.id}"></i></div></div>`:`<div class="icl"><span style="opacity:.6">${t('inc_free')}</span></div>`;
  egb+=`<div class="ico"><canvas class="icv" data-egb="${k}" width="192" height="128"></canvas>${row}</div>`}
 box.innerHTML=`<div class="sign">${t('inc_s_co')} ${I.co.length}/${INC.maxCo}</div><div class="icos">${cob}</div><div class="icshelf"></div>
 <div class="sign">${t('inc_s_eg')} ${I.eg.length}/${INC.maxEg}</div><div class="icos">${egb}</div><div class="icshelf"></div>
 <div class="sign">${t('inc_s_cr')}</div><div class="icrowd"><canvas class="icv" id="incCr" width="256" height="128"></canvas><p id="incCrT"></p>
  <div class="btnrow"><button data-a="seat" ${cr&&incFree()?'':'disabled'}>${t('inc_seat')}</button><button data-a="seatAll" ${cr&&incFree()?'':'disabled'}>${t('inc_seat_all')}</button></div>
  <button class="ghost" data-a="sellCr" ${cr?'':'disabled'} style="margin-top:8px">💰 ${t('inc_sell_cr')} · ${incPrice(0)}</button></div>
 <div class="sign">${t('inc_s_cups')}</div>
 <p class="ileg">🍗 ${t('inc_fd')} · 💧 ${t('inc_wt')} · <span id="incCupN"></span></p>
 <div class="btnrow" style="margin-bottom:10px"><button class="ghost" data-a="feedAll">🍗 ${t('inc_feed_all')}</button><button class="ghost" data-a="wetAll">💧 ${t('inc_wet_all')}</button></div>
 <button class="ghost icbuy" data-a="buyCups"></button>
 <div class="icups">${cups}</div>`;
 incSig=incSigNow();incDrawCups()}
function incDrawCups(){document.querySelectorAll('#incBody [data-cup]').forEach(el=>{const cv=el.querySelector('canvas'),i=+el.dataset.cup;if(!S.inc.cups[i]){if(cv.dataset.d)return;cv.dataset.d=1}incDrawCup(cv,i)})}
function incRefresh(){const I=S.inc;
 {const n=I.cups.length,bb=document.querySelector('#incBody [data-a="buyCups"]'),cn=$('incCupN');if(cn)cn.textContent=t('inc_cups_n')+n+'/'+INC.cupMax;
  if(bb){const full=n>=INC.cupMax;bb.textContent=full?t('inc_cup_max'):'➕ '+t('inc_buy_cups').replace('{n}',Math.min(INC.cupStep,INC.cupMax-n))+' · '+INC.cupPrice+' 💰';bb.disabled=full||S.coins<INC.cupPrice}}
 for(const c of [...I.co,...I.eg]){const a=document.querySelector('[data-t="'+c.id+'"]'),b=document.querySelector('[data-pb="'+c.id+'"]');if(a){a.textContent='⏳ '+incFmt(c.t);a.title=t('inc_in')+incFmt(c.t)}if(b)b.style.width=Math.max(0,Math.min(100,100*(1-c.t/c.c))).toFixed(1)+'%'}
 const n=incCrowd(),ct=$('incCrT');if(ct)ct.textContent=n?t('inc_crowd')+n+' · '+t('inc_free_n')+incFree()+(I.cr.reduce((a,g)=>a+(isSnB(g.sp)?0:g.n),0)>1?' ⚠ '+t('inc_eat'):''):(I.co.length?'':t('inc_crowd0'));
 I.cups.forEach((u,i)=>{if(!u)return;const f=document.querySelector('[data-fd="'+i+'"]'),w=document.querySelector('[data-wt="'+i+'"]'),a=document.querySelector('[data-age="'+i+'"]');
  if(f){f.style.width=u.fd.toFixed(1)+'%';f.style.background=u.fd<25?'#b33a22':'#e8590c'}
  if(w){w.style.width=u.wt.toFixed(1)+'%';w.style.background=u.wt<25?'#b33a22':'#2f8fd6'}
  if(a){a.textContent=incShort(u.sp);a.title=incNm(u.sp)+' · '+t('inc_age')+incAge(u.age||0)+' · 💰 '+incPrice(u.age||0)+((u.fd<=0||u.wt<=0)?' ⚠ '+incFmt(INC.die-(u.z||0)):'')}})}
function incUI(){if($('inc').hidden)return;if(incSig!==incSigNow())incBuild();incRefresh()}
function incDraw(tm){const cr=$('incCr');if(cr)incDrawCrowd(cr,tm);document.querySelectorAll('#incBody canvas[data-cob]').forEach(c=>incDrawCoBox(c,+c.dataset.cob,tm));
 document.querySelectorAll('#incBody canvas[data-egb]').forEach(c=>incDrawEgBox(c,+c.dataset.egb,tm));
 if(tm-incK>.5){incK=tm;incUI();incDrawCups()}} // стаканчики статичные, перерисовываем раз в полсекунды (цвет земли, значок тревоги)
function renderInc(){incTick();incBuild();incRefresh();$('incMsg').textContent=''}
// ---- кнопки ----
$('bInc').onclick=()=>show('inc');$('backI').onclick=()=>show('breed',1);
$('incBody').onclick=e=>{const b=e.target.closest('button[data-a]');if(!b||b.disabled)return;const a=b.dataset.a,i=+b.dataset.i2,m=$('incMsg');m.textContent='';
 if(a==='seat'){m.textContent=incSeat(false)?t('inc_seated'):t('inc_nofree')}
 else if(a==='seatAll'){const n=incSeat(true);m.textContent=n?t('inc_seated')+n:t('inc_nofree')}
 else if(a==='feed'){incFeed(i);m.textContent=t('inc_fed')}
 else if(a==='wet'){incWater(i);m.textContent=t('inc_wetd')}
 else if(a==='sell'||a==='sellCr'){const key=a==='sell'?i:'cr';
  if(incArm.k!==key||Date.now()>incArm.t){incArm={k:key,t:Date.now()+3000};m.textContent=t('inc_sell_q');return}
  incArm={k:null,t:0};const r=a==='sell'?incSell(i):incSellCrowd();m.textContent=r?t('inc_sold')+r:''}
 else if(a==='buyCups'){const r=incBuyCups();m.textContent=r==='ok'?t('inc_cups_bought'):r==='coins'?t('inc_nocoins'):t('inc_cup_max')}
 else if(a==='feedAll'){incFeedAll();m.textContent=t('inc_fed')}
 else if(a==='wetAll'){incWaterAll();m.textContent=t('inc_wetd')}
 incBuild();incRefresh()};
// ---- кнопки отладки (удалить перед релизом вместе с блоком в index.html) ----
if($('incD1')){
 $('incD1').onclick=()=>{const sp=SPK[Math.floor(Math.random()*SPK.length)];const ok=incAddCocoon(sp,6+Math.floor(Math.random()*7));save();incBuild();incRefresh();$('incMsg').textContent=ok?t('inc_d_ok'):t('mt_r_co')};
 $('incD2').onclick=()=>{S.inc.co.forEach(c=>c.t=0);S.inc.eg.forEach(c=>c.t=0);incStep(0);incNotify();incBuild();incRefresh();$('incMsg').textContent=t('inc_d_ok')};
 $('incD3').onclick=()=>{incSim(6*3600);incNotify();incBuild();incRefresh();$('incMsg').textContent=t('inc_d_ok')};
 $('incD4').onclick=()=>{S.inc.cups.forEach(c=>{if(c){c.fd=10;c.wt=10}});save();incRefresh();$('incMsg').textContent=t('inc_d_ok')};
 $('incD5').onclick=()=>{S.inc.cups.forEach(c=>{if(c){c.fd=0;c.wt=0;c.z=INC.die-60}});save();incRefresh();$('incMsg').textContent=t('inc_d_ok')};
 $('incD7').onclick=()=>{const sp=['corn','ball'][Math.floor(Math.random()*2)];const ok=incAddEggs(sp,MATE.nSp[sp][1]);save();incBuild();incRefresh();$('incMsg').textContent=ok?t('inc_d_ok'):t('mt_r_eg')};
 $('incD6').onclick=()=>{const I=S.inc;I.co=[];I.eg=[];I.cr=[];I.cups=I.cups.map(()=>null);I.eatT=0;save();incBuild();incRefresh();$('incMsg').textContent=t('inc_d_ok')}}
/*INC-END*/
