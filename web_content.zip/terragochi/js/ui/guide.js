// Гид Артэс: при первом входе в террариум затемняет фон и «печатает» реплику. Флаг S.guide хранится в сохранении.
// Тексты — ключи gd_* в js/i18n/ru|en|zh.js. Стили — css/guide.css. Кадры — assets/img/guide_1..7.png (67×125 + чёрный контур 2 px).
// Кадры: голова одинаковая, меняется только рука (1 — рука опущена, 7 — поднята). Добавить кадр = положить guide_8.png и дописать путь в GD_FR.
const GD_FR=['assets/img/guide_1.png','assets/img/guide_2.png','assets/img/guide_3.png','assets/img/guide_4.png','assets/img/guide_5.png','assets/img/guide_6.png','assets/img/guide_7.png'];
const GD_IDLE_MS=5000;
let gdIdle=0,gdOpen=false,gdDone=false,gdPend=false,gdTm=0,gdTx=[],gdI=0,gdAn=0;
const gdReduce=()=>{try{return matchMedia('(prefers-reduced-motion:reduce)').matches}catch(e){return false}};
function gdFit(){const im=$('gdImg');if(!im.naturalHeight)return;const k=Math.max(1,Math.floor(Math.min(innerHeight*.58,440)/im.naturalHeight));im.style.width=im.naturalWidth*k+'px';im.style.height=im.naturalHeight*k+'px'}
function gdRender(){$('gdA').textContent=gdTx.slice(0,gdI).join('');$('gdB').textContent=gdTx.slice(gdI).join('')}
function gdTick(){if(!gdOpen)return;gdI++;gdRender();if(gdI>=gdTx.length){gdFinish();return}
 const ch=gdTx[gdI-1];gdTm=setTimeout(gdTick,/[.!?…。！？]/.test(ch)?280:/[,;:—，、；：]/.test(ch)?150:34)}
function gdFinish(){clearTimeout(gdTm);clearTimeout(gdIdle);gdIdle=setTimeout(()=>{if(gdOpen&&gdDone)gdClose()},GD_IDLE_MS);gdI=gdTx.length;gdRender();gdDone=true;$('gdHint').textContent=t('gd_end');$('gdHint').classList.add('on')}
// Анимация гида: проигрывается один раз при первом показе (кадры 0→последний), затем остаётся последний кадр.
const GD_FIRST_DELAY=650,GD_FRAME_MS=170,GD_PEAK=0.83,GD_BACK=3,GD_POKES=2,GD_PEAK_MS=240;
// Рука «тычет» в надпись: вперёд до ~83% анимации, назад (рука остаётся видна), так GD_POKES раз, затем до последнего кадра.
function gdSeq(n){const last=n-1,pk=Math.min(last,Math.max(1,Math.round(last*GD_PEAK))),bk=Math.min(GD_BACK,pk-1),q=[];
 for(let i=1;i<=pk;i++)q.push(i);
 for(let r=1;r<GD_POKES;r++){for(let i=pk-1;i>=bk;i--)q.push(i);for(let i=bk+1;i<=pk;i++)q.push(i)}
 for(let i=pk-1;i>=bk;i--)q.push(i);
 for(let i=bk+1;i<=last;i++)q.push(i);
 return q.map((f,k)=>({f,d:(f===pk&&q[k+1]!==undefined&&q[k+1]<f)?GD_PEAK_MS:GD_FRAME_MS}))}
function gdAnim(){clearTimeout(gdAn);const im=$('gdImg'),last=GD_FR.length-1;
 im.onload=gdFit;GD_FR.forEach(u=>{const p=new Image();p.src=u});
 if(gdReduce()){im.src=GD_FR[last];return}
 im.classList.remove('idle');im.src=GD_FR[0];const seq=gdSeq(GD_FR.length);let k=0;
 const step=()=>{if(!gdOpen)return;const s=seq[k++];im.src=GD_FR[s.f];if(k<seq.length)gdAn=setTimeout(step,s.d);else im.classList.add('idle')};
 gdAn=setTimeout(step,GD_FIRST_DELAY)}
function guideShow(){if(gdOpen)return;gdOpen=true;gdDone=false;const el=$('guide'),im=$('gdImg');
 gdTx=Array.from(t('gd_1'));gdI=0;gdRender();$('gdName').textContent=t('gd_name');$('gdHint').textContent=t('gd_tap');$('gdHint').classList.remove('on');
 gdAnim();
 el.hidden=false;void el.offsetWidth;el.classList.add('on');
 if(gdReduce())gdFinish();else gdTm=setTimeout(gdTick,750)}
function gdClose(){if(!gdOpen)return;gdOpen=false;clearTimeout(gdTm);clearTimeout(gdIdle);clearTimeout(gdAn);$('gdImg').classList.remove('idle');const el=$('guide');el.classList.remove('on');S.guide=1;save();setTimeout(()=>{if(!gdOpen)el.hidden=true},380)}
function guideMaybe(){if(S.guide||gdOpen||gdPend)return;gdPend=true;setTimeout(()=>{gdPend=false;if(cur==='game'&&!S.guide)guideShow()},480)}
$('guide').onclick=()=>{if(!gdOpen)return;if(gdDone)gdClose();else gdFinish()};
addEventListener('keydown',e=>{if(!gdOpen)return;if(e.key==='Enter'||e.key===' '||e.key==='Escape'){e.preventDefault();if(gdDone)gdClose();else gdFinish()}});
addEventListener('resize',()=>{if(gdOpen)gdFit()});
$('sGuide').onclick=()=>{if(gdOpen)return;S.guide=0;guideShow()};
