// Фон магазина: джунгли-пещера, рисуется один раз
/* ---- фон магазина: джунгли-пещера, рисуется один раз в картинку ---- */
(function buildShopArt(){
 try{
 const W=112,H=300,c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');
 onCtx(x,()=>{
  const wrap=(fn)=>{for(const dy of[-H,0,H])fn(dy)};
  // основа: тёмный зелёно-коричневый грунт с шумом
  for(let y=0;y<H;y++)for(let xx=0;xx<W;xx++){
   const n=hsh(xx*7.3+y*13.1),m=hsh(Math.floor(xx/3)*5+Math.floor(y/3)*17+3),k=Math.sin(y*.045+xx*.03)*.5+.5;
   const t=.35*n+.4*m+.25*k;
   const col=t<.3?'#0b1510':t<.55?'#101d15':t<.78?'#152619':'#1a2e1e';px(xx,y,1,1,col)}
  // тёмные пятна-тени и светлые пятна сырости
  for(let i=0;i<26;i++){const cx=hsh(i*3.1)*W,cy=hsh(i*5.7)*H,r=4+hsh(i*9.3)*9;
   wrap(d=>ell(cx,cy+d,r,r*.7,i%3?'#0a120d':'#1d3322'))}
  // сотовая деревянная структура (пористое дерево) по бокам
  const comb=(cx0,cy0,rw,rh,seed0)=>wrap(d=>{
   for(let gy=-rh-4;gy<=rh+4;gy+=6)for(let gx=-rw-4;gx<=rw+4;gx+=7){
    const ox=gx+((Math.round(gy/6)&1)?3.5:0);
    const nx=ox/rw,ny=gy/rh,dd=nx*nx+ny*ny+(hsh(ox*1.7+gy*2.3+seed0)-.5)*.5;
    if(dd>1)continue;
    const X=cx0+ox,Y=cy0+gy+d,e=dd>.7;
    ell(X,Y,4,4,'#4a2f18');ell(X,Y,3,3,e?'#5f3d1f':'#6f4824');
    ell(X,Y+.5,2,2,'#0a0603');px(X-1,Y-1,2,1,'#2b180a');px(X-3,Y-2,1,1,'#8a5a2b')}});
  comb(8,70,15,34,1);comb(104,160,14,40,5);comb(6,235,13,26,9);comb(106,20,12,22,13);
  // корни: извилистые, с бликом и тенью
  const root=(sx,sy,len,r,seed1,dir)=>wrap(d=>{
   let X=sx,Y=sy+d,a=Math.PI/2+dir*.25;
   for(let i=0;i<len;i++){
    a+=(hsh(seed1+i*.37)-.5)*.5-(X-W/2)*.0009*dir*0;X+=Math.cos(a)*1;Y+=Math.sin(a)*1;
    const rr=Math.max(1.2,r*(1-i/len*.55));
    ell(X+1,Y+1,rr,rr,'#1a0f08');ell(X,Y,rr,rr,'#4a2c15');
    ell(X-rr*.35,Y-rr*.2,Math.max(1,rr*.55),Math.max(1,rr*.7),'#6a4322');
    if(hsh(seed1+i)<.35)px(X-rr*.4-1,Y-1,1,1,'#9a6b3a');
    if(hsh(seed1*2+i)<.25)px(X+rr*.5,Y,1,1,'#2a170a');
    if(i%9===8&&hsh(seed1+i*3)<.7){const bx=X,by=Y,ba=a+(hsh(i+seed1)<.5?-1:1)*.9;
     for(let j=0;j<10;j++){const q=Math.max(1,rr*.5*(1-j/12));ell(bx+Math.cos(ba)*j,by+Math.sin(ba)*j+j*.15,q,q,j%2?'#3d240f':'#5a3a1d')}}}});
  root(14,-4,150,4.2,2.1,1);root(40,-6,120,3.2,5.3,-1);root(70,0,170,3.6,8.8,1);root(98,-5,140,4.4,11.4,-1);
  root(6,120,110,3,14.9,1);root(104,100,120,3.4,17.2,-1);root(52,200,100,2.6,21.5,1);root(86,190,80,2.2,23.9,-1);
  // мох на корнях и камнях
  for(let i=0;i<230;i++){const xx=Math.floor(hsh(i*1.9)*W),yy=Math.floor(hsh(i*4.3)*H);
   const v=hsh(i*7.7);wrap(d=>{px(xx,yy+d,2+(v<.4),1,v<.3?'#2f6b2a':v<.6?'#3f8a35':'#5aa83f');px(xx+1,yy+d-1,1,1,'#7fcc4f')})}
  // замшелые камни
  const rock=(cx,cy,rx,ry)=>wrap(d=>{const Y=cy+d;
   ell(cx+1,Y+2,rx+1,ry,'#050806');ell(cx,Y,rx,ry,'#3b423d');ell(cx-1,Y-1,rx-1,ry-1,'#58615a');
   ell(cx-rx*.3,Y-ry*.45,rx*.45,ry*.3,'#7b857d');
   for(let i=-rx;i<=rx;i++){const h=Math.round(ry*Math.sqrt(1-i*i/(rx*rx)));if(hsh(i*3+cx)<.8){px(cx+i,Y-h,1,2+(hsh(i+cy)<.5),'#2f7a2c');px(cx+i,Y-h,1,1,'#6fc04a')}}
   px(cx+rx*.3,Y,1,2,'#262c28')});
  rock(14,40,10,6);rock(98,110,9,6);rock(12,180,11,7);rock(100,255,10,6);rock(30,275,8,5);
  // папоротники
  const fern=(bx,by,ang,n,len,seed2)=>wrap(d=>{
   for(let f=0;f<n;f++){const a=ang+(f-(n-1)/2)*.42,L=len*(.7+hsh(seed2+f)*.5);let px0=bx,py0=by+d;
    for(let s=1;s<=L;s++){const t=s/L,cx=bx+Math.cos(a)*s+Math.sin(a)*Math.sin(t*3)*.9*0,cy=by+d+Math.sin(a)*s+t*t*L*.35;
     px(cx,cy,1,1,t<.5?'#2f8a3a':'#4fbf4a');
     if(s%2===0&&t<.92){const w=Math.round((1-t)*4+1),nx=-Math.sin(a),ny=Math.cos(a);
      for(let k=1;k<=w;k++){px(cx+nx*k,cy+ny*k*.6+k*.4,1,1,k===w?'#78d65a':'#2f8a3a');px(cx-nx*k,cy-ny*k*.6+k*.4,1,1,k===w?'#78d65a':'#2a7a33')}}}}});
  fern(2,100,-.2,5,18,3);fern(110,60,Math.PI+.2,5,18,7);fern(4,210,-.3,4,16,11);fern(109,225,Math.PI+.3,4,16,15);fern(8,290,-.5,5,20,19);fern(104,285,Math.PI+.5,5,20,23);
  // свисающие лианы с листьями
  for(let i=0;i<9;i++){const sx=6+hsh(i*8.3)*100,len=18+hsh(i*2.9)*50;wrap(d=>{
   for(let y=0;y<len;y++){const xx=sx+Math.sin(y*.25+i)*1.4;px(xx,y+d,1,1,y%7===0?'#4a8a3a':'#2c5c2a');
    if(y%6===3){px(xx+1,y+d,2,1,'#4fa83f');px(xx-2,y+d+1,2,1,'#3a8a35');px(xx+2,y+d,1,1,'#7fcc4f')}}})}
  // светлячки и споры
  for(let i=0;i<34;i++){const xx=Math.floor(hsh(i*6.1)*W),yy=Math.floor(hsh(i*2.2)*H);
   wrap(d=>{px(xx,yy+d,1,1,i%3?'#d7f2a0':'#ffd36b');if(i%4===0){px(xx-1,yy+d,3,1,'rgba(255,230,140,.28)');px(xx,yy+d-1,1,3,'rgba(255,230,140,.28)')}})}
 });
 document.documentElement.style.setProperty('--shbg','url('+c.toDataURL()+')');
 // фонарь
 const l=document.createElement('canvas');l.width=11;l.height=22;const y2=l.getContext('2d');
 onCtx(y2,()=>{px(5,0,1,5,'#8a9296');px(3,5,5,1,'#2b2f31');px(2,6,7,1,'#4b5559');
  px(2,7,7,9,'#3a2a14');px(3,7,5,9,'#ffbf4a');px(4,8,3,7,'#fff1b8');px(5,8,1,7,'#ffffff');
  px(3,7,1,9,'#e98a1f');px(7,7,1,9,'#e98a1f');px(2,16,7,1,'#4b5559');px(3,17,5,1,'#2b2f31');px(4,18,3,1,'#2b2f31');px(5,19,1,2,'#8a9296')});
 document.documentElement.style.setProperty('--shlamp','url('+l.toDataURL()+')');
 // паучок на нити и мерцание фонарей
 const sp=document.createElement('canvas');sp.width=13;sp.height=11;
 onCtx(sp.getContext('2d'),()=>{const K2='#2a1c14';line(1,2,4,4,K2);line(1,8,4,6,K2);line(0,5,4,5,K2);line(11,2,8,4,K2);line(11,8,8,6,K2);line(12,5,8,5,K2);
  ell(6,5,2,3,'#4a3526');ell(6,6,2,2,'#6b4a33');px(5,3,1,1,'#e8590c');px(7,3,1,1,'#e8590c');px(6,5,1,2,'#c8431e');px(6,1,1,1,'#d9ded6')});
 document.documentElement.style.setProperty('--shspd','url('+sp.toDataURL()+')');
 document.querySelectorAll('#shop .scene,#ward .scene').forEach(sc=>sc.insertAdjacentHTML('afterbegin','<i class="glw l"></i><i class="glw r"></i><i class="hang"></i>'));
 }catch(e){}
})();

