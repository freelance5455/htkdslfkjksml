// Магазин: вкладки, покупки, аксессуары, гардероб, имя питомца
/*SHOP-START*/
const CN=document.querySelectorAll('.cn');let CELLS=[];
const SPIDER=(()=>{const L=[[4,4],[3,3],[4,5],[3,5],[2,5],[4,6],[3,6],[2,6],[4,7],[3,8]],B=[[5,4],[6,4],[5,5],[6,5],[5,6],[6,6],[5,7],[6,7]];return B.concat(L,L.map(p=>[11-p[0],p[1]]))})();
const COINI=new Image();COINI.onload=()=>document.querySelectorAll('.cc').forEach(drawCoin);COINI.src='assets/img/coin.png';
function drawCoin(c){const x2=c.getContext('2d');x2.setTransform(1,0,0,1,0,0);x2.imageSmoothingEnabled=false;x2.clearRect(0,0,48,48);
 if(COINI.complete&&COINI.naturalWidth){x2.imageSmoothingEnabled=true;x2.imageSmoothingQuality='high';x2.drawImage(COINI,0,0,48,48);return}
 const sp=new Set(SPIDER.map(p=>p[0]+','+p[1]));
 for(let y=0;y<48;y++)for(let x=0;x<48;x++){const dx=x+.5-24,dy=y+.5-24,dd=Math.hypot(dx,dy);if(dd>23)continue;
  let col;
  if(dd>21.5)col='#6e4206';else if(dd>20.5)col='#b07612';else if(dd>18.5)col='#e09a1c';else if(dd>17.5)col='#c98a18';
  else if(dx+dy<-14&&dd<17)col='#fff4b8';else if(dx+dy<-6)col='#ffe27a';else if(dx-dy>10)col='#c48a1a';else col='#f0c443';
  if(dd>13.5&&dd<14.5)col='#c98a18';
  if(sp.has(Math.floor(x/4)+','+Math.floor(y/4)))col='#2a1a14';
  x2.fillStyle=col;x2.fillRect(x,y,1,1)}
}
function drawInner(k){g.setTransform(1,0,0,1,0,0);g.drawImage(SPFLOOR,0,0);fixCtx(g,2);[[4,18],[36,26],[9,43],[22,45],[33,42]].forEach((p,i)=>drawBug(k,p[0],p[1],.3+i))}
let shopTab=0,insT=0,shT=0;
const SPFLOOR=(()=>{const c=document.createElement('canvas');c.width=80;c.height=104;sandTex(c,23,2,3,[{x:4,y:22,rx:26,ry:14}]);return c})();
// part=1 (из главного цикла): за один кадр рисуем не больше ~7 мс банок, остальные — в следующих кадрах; во время переходов экранов не рисуем
function boxEach(sel,part,key,fn){const L=document.querySelectorAll(sel);if(!part){L.forEach(fn);return}
 if(!L.length||document.body.classList.contains('trans'))return;const t0=performance.now();let k=key.n||0,done=0;
 while(done<L.length){const i=(k+done)%L.length;fn(L[i],i);done++;if(performance.now()-t0>7)break}key.n=(k+done)%L.length}
const BXS={n:0},BXR={n:0};
function drawSpBoxes(part){boxEach('#sgrid2 canvas.inner',part,BXS,(c,i)=>{const k=c.dataset.sk,x=c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.drawImage(SPFLOOR,0,0);fixCtx(x,2);if(isSc(k))scorpionBox(x,T+i*1.9,k);else spiderAt(x,k,20,24,.34,T+i*1.9);
 if(!ownN(k)){x.fillStyle='rgba(10,6,4,.6)';x.fillRect(0,0,40,52);stampLock(x,40,50,34)}})}
function drawRepBoxes(part){boxEach('#sgrid3 canvas.inner',part,BXR,(c,i)=>{const k=c.dataset.sk,x=c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.drawImage(SPFLOOR,0,0);fixCtx(x,2);{const CP=drawRepBoxes.cp||(drawRepBoxes.cp={}); // вертикальные позы для узких «банок»: свернувшаяся змея крупным планом, с полной детализацией
 if(!CP[k])CP[k]=mkP(rotFit({corn:SKP,boa:boaRaw,ball:ballRaw}[k]||SKP,Math.PI/2,[10,14,88,114]),PTH[k].k);
 const bak=PTH[k];PTH[k]=CP[k];try{onCtx(x,()=>snakeRender(.42,0,0,{...CALM,sp:k,ph:i*2}))}finally{PTH[k]=bak}}
 if(!ownN(k)){x.fillStyle='rgba(10,6,4,.6)';x.fillRect(0,0,40,52);stampLock(x,40,50,34)}})}
function refreshSp(){document.querySelectorAll('[data-sbuy]').forEach(b=>{const k=b.dataset.sbuy,n=ownN(k),full=n>=MAXP;b.disabled=full;b.querySelector('span').textContent=full?t('sp_max'):t('buyN');b.querySelector('canvas').hidden=full;
 const c=b.parentNode;let s=c.querySelector('.cnt5');if(!s){s=document.createElement('small');s.className='cnt5';s.style.textAlign='center';c.insertBefore(s,b)}s.textContent=t('sp_cnt')+n+'/'+MAXP})}
function newPet(f){
 if(f.indexOf('#')>0){const d=mk();S.d[f]=d;d.decOwn={};d.bgOwn={soil:true};d.bg='soil';if(isSn(f)){d.bgOwn.snk=true;d.bg='snk'}
  d.dec=S.mkDec(null,d);d.stage=1;d.vr=[-1,0,1][Math.floor(Math.random()*3)];
  if(isSpd(f)){d.sex=Math.random()<.5?'m':'f';d.L=6;d.fm=0;d.stage=stageL(6);d.molt=mNew(f,false)}else{if(isSnB(f))d.sex=Math.random()<.5?'m':'f';d.molt=mNew(f,true)}}
 S.own[f]=true}
function buySp(k){const m=$('shMsg'),f=freeSlot(k);if(!f){m.textContent=t('sp_max');return}if(S.coins<50){m.textContent=t('nocoin50');return}S.coins-=50;newPet(f);if(!S.own[S.species])mFix();save();refreshSp();try{renderPick()}catch(e){}if(isMn(k))try{drawInsBoxes()}catch(e){}m.textContent=t('unl')+spn(f)}
function refreshAcc(){refreshDec();document.querySelectorAll('[data-bbuy]').forEach(b=>{const k=b.dataset.bbuy,o=S.bgOwn[k],sel=S.bg===k;b.disabled=sel;b.querySelector('span').textContent=sel?t('selected'):o?t('sel_b'):t('buy25');b.querySelector('canvas').hidden=!!o});
 document.querySelectorAll('#sgrid4 canvas.inner').forEach(c=>{const k=c.dataset.bk,x=c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;x.drawImage(BGK[k],128,96,160,208,0,0,80,104);
  if(!S.bgOwn[k]){x.fillStyle='rgba(10,6,4,.55)';x.fillRect(0,0,80,104);fixCtx(x,2);stampLock(x,40,50,34)}})}
function refreshDec(){document.querySelectorAll('[data-dbuy]').forEach(b=>{const n=S.dec[b.dataset.dbuy];if(!n)return;b.querySelector('span').textContent=!n.own?t(dprice(b.dataset.dbuy)===HPRICE?'buy25':'buy50'):n.on?t('dec_del'):t('put');b.querySelector('canvas').hidden=n.own});
 document.querySelectorAll('canvas.inner[data-dk]').forEach(c=>{const k=c.dataset.dk,n=S.dec[k],x=c.getContext('2d');if(!n)return;x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;
  if(MDK.includes(k)){const q=MPX[k];x.drawImage(mnPrevCanvas(k),q[0],q[1],q[2],q[3],0,0,80,104);fixCtx(x,2)}
  else{const pv=PV[k];x.drawImage(BGK.soil,128,96,160,208,0,0,80,104);fixCtx(x,2);onCtx(x,()=>DEC[k].f(20,27,pv[0],pv[1],1))}
  if(!n.own){x.fillStyle='rgba(10,6,4,.55)';x.fillRect(0,0,40,52);stampLock(x,40,50,34)}})}
function bgAct(k){const m=$('wMsg');if(S.bgOwn[k]){S.bg=k;save();refreshAcc();m.textContent=t('bg_set')+t('bg_'+k);return}if(S.coins<25){m.textContent=t('nocoin25');return}S.coins-=25;S.bgOwn[k]=true;save();refreshAcc();m.textContent=t('unl')+t('bg_'+k)}
const TABS=[['tFeed','scFeed'],['tSp','scSp'],['tRep','scRep'],['tIns','scIns'],['tBr','scBr']];
function tab(n,anim){shopTab=n;shT=0;insT=0;TABS.forEach((q,i)=>{$(q[0]).classList.toggle('on',i===n);$(q[1]).hidden=i!==n});const a=$(TABS[n][1]);a.classList.remove('tin');if(anim){void a.offsetWidth;a.classList.add('tin')}$('shMsg').textContent='';if(n)refreshSp()}
function stock(){document.querySelectorAll('[data-st]').forEach(e=>e.textContent=S.inv[e.dataset.st])}
function buy(k){const m=$('shMsg');if(S.coins<5){m.textContent=t('nocoin');return}S.coins-=5;S.inv[k]++;save();stock();m.textContent=t('bought')+t('n_'+k)}
function drawCells(){for(const b of CELLS)onCtx(b.firstChild.getContext('2d'),()=>{g.drawImage(bg,184,184,144,144,0,0,36,36);drawBug(b.dataset.k,18,13,T)})}
function buildBg(){const ks=isSn(S.species)?['snk',...BKS]:BKS;let h='';
 for(let r=0;r<ks.length;r+=3){const row=ks.slice(r,r+3),st=row.length===1?' style="grid-column:2"':'';
  for(const k of row)h+=`<div class="box"${st}><div class="lid"></div><canvas class="inner" width="80" height="104" data-bk="${k}"></canvas></div>`;h+='<div class="plank"></div>';
  for(const k of row)h+=`<div class="bcell"${st}><b class="nm" data-i="bg_${k}"></b><button data-bbuy="${k}"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div>`}
 const g4=$('sgrid4');g4.innerHTML=h;g4.querySelectorAll('[data-bbuy]').forEach(b=>b.onclick=()=>bgAct(b.dataset.bbuy));g4.querySelectorAll('.cc').forEach(drawCoin);g4.querySelectorAll('[data-i]').forEach(e=>e.textContent=t(e.dataset.i))}
function shopBugsRedraw(){const gr=$('sgrid');if(!gr)return; // банки и наклейки рисуются один раз, поэтому перерисовываем, когда картинки насекомых загрузились
 gr.querySelectorAll('canvas.inner').forEach(c=>onCtx(c.getContext('2d'),()=>drawInner(c.dataset.k)));
 gr.querySelectorAll('.sticker canvas').forEach(c=>onCtx(c.getContext('2d'),()=>{g.clearRect(0,0,36,36);drawBug(c.dataset.k,18,13,.5)}))}
(()=>{let h='';
 for(let r=0;r<FOOD.length;r+=3){const ks=FOOD.slice(r,r+3);for(const k of ks)h+=`<div class="box"><div class="lid"></div><canvas class="inner" width="80" height="104" data-k="${k}"></canvas><div class="sticker"><canvas width="36" height="36" data-k="${k}"></canvas><span data-i="p_${k}"></span></div></div>`;
 h+='<div class="plank"></div>';
 for(const k of ks)h+=`<div class="bcell"><small><i data-i="stock"></i><b data-st="${k}">0</b></small><button data-buy="${k}"><span data-i="buy1"></span><canvas class="cc" width="48" height="48"></canvas></button></div>`}
 const gr=$('sgrid');gr.innerHTML=h;
 shopBugsRedraw();
 gr.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buy(b.dataset.buy));
 let h2='';
 const SPSH=[...SPK,'scorpion3'];for(let r=0;r<SPSH.length;r+=3){const ks=SPSH.slice(r,r+3);
  for(const k of ks)h2+=`<div class="box${ks.length==2&&k===ks[0]?' c2':''}"><div class="lid"></div><canvas class="inner" width="80" height="104" data-sk="${k}"></canvas></div>`;
  h2+='<div class="plank"></div>';
  for(const k of ks)h2+=`<div class="bcell${ks.length==2&&k===ks[0]?' c2':''}"><b class="nm">${SPN[k]}</b><button data-sbuy="${k}"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div>`}
 let h3='';for(const k of['corn','boa','ball'])h3+=`<div class="box"><div class="lid"></div><canvas class="inner" width="80" height="104" data-sk="${k}"></canvas></div>`;
 h3+='<div class="plank"></div>';
 for(const k of['corn','boa','ball'])h3+=`<div class="bcell"><b class="nm" data-i="n_${k}"></b><button data-sbuy="${k}"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div>`;
 const g3=$('sgrid3');g3.innerHTML=h3;g3.querySelectorAll('[data-sbuy]').forEach(b=>b.onclick=()=>buySp(b.dataset.sbuy));
  const g7=$('sgrid7');g7.innerHTML='<div class="box"><div class="lid"></div><canvas class="inner" width="80" height="104" data-sk="mantis"></canvas></div><div class="plank"></div><div class="bcell"><b class="nm">Spodromantis lineola</b><button data-sbuy="mantis"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div>';g7.querySelectorAll('[data-sbuy]').forEach(b=>b.onclick=()=>buySp(b.dataset.sbuy));
 buildBg();
 const mkDec=(id,ks)=>{let h='';for(const k of ks)h+=`<div class="box"><div class="lid"></div><canvas class="inner" width="80" height="104" data-dk="${k}"></canvas></div>`;h+='<div class="plank"></div>';
  for(const k of ks)h+=`<div class="bcell"><b class="nm" data-i="n_${k}"></b>${HIDES.includes(k)?'<small data-i="hut_d" style="text-align:center"></small>':''}<button data-dbuy="${k}"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div>`;
  const g=$(id);g.innerHTML=h;g.querySelectorAll('[data-dbuy]').forEach(b=>b.onclick=()=>decAct(b.dataset.dbuy))};
 mkDec('sgrid5',['snag','stone','plant']);mkDec('sgrid6',['hut','log','shell']);
 const g2=$('sgrid2');g2.innerHTML=h2;g2.querySelectorAll('[data-sbuy]').forEach(b=>b.onclick=()=>buySp(b.dataset.sbuy));
 $('cells').innerHTML=FOOD.map(k=>`<button class="cell" data-k="${k}"><canvas width="36" height="36"></canvas><b data-i="n_${k}"></b><em><i data-i="have"></i><span>0</span></em></button>`).join('');
 CELLS=[...document.querySelectorAll('.cell')];CELLS.forEach(b=>b.onclick=()=>startFeed(b.dataset.k));
 document.querySelectorAll('.cc').forEach(drawCoin)})();
function mkDecG(id,ks){let h='';for(const k of ks)h+=`<div class="box"><div class="lid"></div><canvas class="inner" width="80" height="104" data-dk="${k}"></canvas></div>`;h+='<div class="plank"></div>';
 for(const k of ks)h+=`<div class="bcell"><b class="nm" data-i="n_${k}"></b>${HIDES.includes(k)?'<small data-i="hut_d" style="text-align:center"></small>':''}<button data-dbuy="${k}"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div>`;
 const gg=$(id);gg.innerHTML=h;gg.querySelectorAll('[data-dbuy]').forEach(b=>b.onclick=()=>decAct(b.dataset.dbuy));gg.querySelectorAll('.cc').forEach(drawCoin);gg.querySelectorAll('[data-i]').forEach(e=>e.textContent=t(e.dataset.i))}
function renderWard(){const mn=isMn(S.species);$('scAcc').hidden=false;$('wEmpty').hidden=true;$('wMsg').textContent='';$('wPet').textContent=spn(S.species);$('wNameIn').value=(S.d[S.species]&&S.d[S.species].name)||'';$('wNameIn').placeholder=spnDef(S.species);
 buildBg();mkDecG('sgrid5',mn?MDK:['snag','stone','plant']);
 $('wSignH').hidden=mn;$('sgrid6').hidden=mn;if(mn)$('sgrid6').innerHTML='';else mkDecG('sgrid6',['hut','log','shell']);
 refreshAcc()}
function saveName(){const k=S.species,d=S.d[k],v=$('wNameIn').value.replace(/\s+/g,' ').trim().slice(0,20);
 if(v&&v!==spnDef(k))d.name=v;else delete d.name;save();$('wNameIn').value=d.name||'';$('wNameIn').blur();
 $('wPet').textContent=spn(k);petUI();try{renderPick()}catch(e){}$('mCur').textContent=spn(k);$('wMsg').textContent=t('nm_ok')}
$('wNameBtn').onclick=saveName;$('wNameIn').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();saveName()}};
$('pen').onclick=()=>{from='game';show('ward')};
$('backW').onclick=()=>{decSel=defSel();decUI();show('game',1)};
$('mShop').onclick=()=>{from='menu';show('shop')};$('backS').onclick=()=>show(from,1);
$('selX').onclick=()=>closeSel();$('selShop').onclick=()=>{closeSel(1);from='game';show('shop')};
TABS.forEach((q,i)=>$(q[0]).onclick=()=>{if(shopTab!==i)tab(i,1)});
/*SHOP-END*/
