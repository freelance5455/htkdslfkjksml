// Настройки: язык, сброс прогресса, музыка
// ---- язык и настройки ----
function applyLang(){document.documentElement.lang=LANG;petUI();document.title=t('doc');
 document.querySelectorAll('[data-i]').forEach(e=>e.textContent=t(e.dataset.i));
 $('mCur').textContent=S.own[S.species]?spn(S.species):'—';$('sCur').textContent=({ru:'Русский',uk:'Українська',zh:'简体中文',en:'English'})[LANG];
 $('lRu').classList.toggle('on',LANG==='ru');$('lUk').classList.toggle('on',LANG==='uk');$('lEn').classList.toggle('on',LANG==='en');$('lZh').classList.toggle('on',LANG==='zh');
 $('msg').textContent=t(msgK);for(const i of['pMsg','shMsg','mMsg','eMsg','wMsg'])$(i).textContent='';renderEarn();updEarn();mgUI();
 paintReset();paintMus();paintSfx();refreshSp();refreshAcc();renderPick();decUI();$('wPet').textContent=spn(S.species);petUI()}
function setLang(l){LANG=l;try{localStorage.setItem('spiderLang',l)}catch(e){}applyLang()}
let armed=false,armT=0;
function paintReset(){const b=$('sReset');b.textContent=t(armed?'reset_c':'reset');b.classList.toggle('danger',armed)}
function disarm(){clearTimeout(armT);armed=false;paintReset()}
$('mSet').onclick=()=>show('settings');
$('sBack').onclick=()=>{disarm();show('menu',1)};
$('sLang').onclick=()=>{disarm();show('lang')};
$('lBack').onclick=()=>show('settings',1);
$('lRu').onclick=()=>setLang('ru');$('lUk').onclick=()=>setLang('uk');$('lEn').onclick=()=>setLang('en');$('lZh').onclick=()=>setLang('zh');
$('sReset').onclick=()=>{if(!armed){armed=true;paintReset();armT=setTimeout(disarm,3500);return}
 noSave=true;try{localStorage.removeItem('spiderTama2')}catch(e){}location.reload()};
/*MENU-END*/
document.addEventListener('touchstart',()=>{},{passive:true});


