// Навигация между экранами, выбор питомца, drag-n-drop карточек
/*MENU-START*/
let from='menu';
let cur='menu',fin=null;
// вход: новый экран выезжает снизу вверх; выход: текущий уезжает сверху вниз
const show=(id,back)=>{if(decEdit&&id!=='game')decEnd();if(fin)fin();if(id===cur)return;if(id==='game')guideMaybe();if(cur==='mgame'&&id!=='mgame')mgStop();
 if(id==='shop'){tab(0);stock();$('shMsg').textContent=''}if(id==='menu')$('mCur').textContent=spn(S.species);if(id==='pick')renderPick();if(id==='menu')updEarn();if(id==='earn'){renderEarn();$('eMsg').textContent=''}if(id==='mgame')mgReset();if(id==='ward')renderWard();if(id==='inc')renderInc();if(id==='mate')renderMate();
 const o=$(cur),n=$(id),A=back?o:n,cl=back?'sOut':'sIn';cur=id;n.hidden=false;A.classList.add(cl);
 const to=setTimeout(()=>fin&&fin(),back?310:350);document.body.classList.add('trans');
 fin=()=>{clearTimeout(to);A.classList.remove(cl);o.hidden=true;document.body.classList.remove('trans');fin=null}};
const PICKBOX=document.querySelector('#pick .cards');let pickEdit=false,drag=null;
function pickOrder(){const all=[...PICKBOX.querySelectorAll('.card')].map(b=>b.dataset.sp);
 let o=Array.isArray(S.order)?S.order.filter(k=>all.includes(k)):[];
 for(const k of all)if(!o.includes(k))o.push(k);S.order=o;return o}
function pickLayout(){pickOrder().forEach(k=>PICKBOX.appendChild(PICKBOX.querySelector('.card[data-sp="'+k+'"]')))}
function setEdit(on){pickEdit=on;$('pick').classList.toggle('editing',on);$('pEdit').innerHTML=on?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19z"/><path d="M14 7l3 3"/></svg>';$('pHint').hidden=!on;$('pHint').textContent=t('p_hint');$('pMsg').textContent=''}
$('pEdit').onclick=()=>setEdit(!pickEdit);
function pickCommit(){const dom=[...PICKBOX.querySelectorAll('.card')].filter(b=>!b.hidden).map(b=>b.dataset.sp);let i=0;
 S.order=pickOrder().map(k=>dom.includes(k)?dom[i++]:k);save()}
function dragEnd(){if(!drag)return;const d=drag;drag=null;d.g.remove();d.c.classList.remove('ph');
 removeEventListener('pointermove',dragMove);removeEventListener('pointerup',dragEnd);removeEventListener('pointercancel',dragEnd);pickCommit()}
function dragMove(e){if(!drag)return;e.preventDefault();
 drag.g.style.transform='translate('+(e.clientX-drag.ox)+'px,'+(e.clientY-drag.oy)+'px)';
 const P=$('pick');if(e.clientY<90)P.scrollTop-=12;else if(e.clientY>innerHeight-90)P.scrollTop+=12;
 const el=document.elementFromPoint(e.clientX,e.clientY),tg=el&&el.closest&&el.closest('.card');
 if(tg&&tg!==drag.c&&!tg.hidden&&PICKBOX.contains(tg)){const kids=[...PICKBOX.children];
  PICKBOX.insertBefore(drag.c,kids.indexOf(drag.c)<kids.indexOf(tg)?tg.nextSibling:tg)}}
PICKBOX.addEventListener('pointerdown',e=>{if(!pickEdit||drag||(e.pointerType==='mouse'&&e.button))return;
 const c=e.target.closest('.card');if(!c||c.hidden)return;e.preventDefault();
 const r=c.getBoundingClientRect(),g=c.cloneNode(true);
 g.querySelector('canvas').getContext('2d').drawImage(c.querySelector('canvas'),0,0);
 g.classList.add('drag');g.style.width=r.width+'px';g.style.height=r.height+'px';g.style.animation='none';
 g.style.transform='translate('+r.left+'px,'+r.top+'px)';document.body.appendChild(g);c.classList.add('ph');
 drag={c,g,ox:e.clientX-r.left,oy:e.clientY-r.top};
 addEventListener('pointermove',dragMove,{passive:false});addEventListener('pointerup',dragEnd);addEventListener('pointercancel',dragEnd)});
function syncCards(){
 PICKBOX.querySelectorAll('.card').forEach(b=>{if(b.dataset.sp.indexOf('#')>0&&!S.own[b.dataset.sp])b.remove()});
 for(const k in S.d){if(k.indexOf('#')<1||!S.own[k]||PICKBOX.querySelector('.card[data-sp="'+k+'"]'))continue;
  const sib=[...PICKBOX.querySelectorAll('.card')].filter(b=>bs(b.dataset.sp)===bs(k));if(!sib.length)continue;
  const c=sib[0].cloneNode(true);c.dataset.sp=k;c.classList.remove('sel','lock','ph');const nb=c.querySelector('b');if(nb)nb.removeAttribute('data-i');c.onclick=cardClick;
  const last=sib[sib.length-1];PICKBOX.insertBefore(c,last.nextSibling);
  if(Array.isArray(S.order)&&!S.order.includes(k)){let ix=-1;S.order.forEach((q,i)=>{if(bs(q)===bs(k)&&S.own[q])ix=i});if(ix<0)S.order.push(k);else S.order.splice(ix+1,0,k)}}}
function renderPick(){syncCards();setEdit(false);pickLayout();document.querySelectorAll('.card').forEach(b=>{const k=b.dataset.sp;b.hidden=!S.own[k];if(b.hidden)return;
 {const dd=S.d[k];const nb=b.querySelector('b');let bd=nb.querySelector('.sx');if(!bd){bd=document.createElement('i');bd.className='sx';nb.prepend(bd)}
  const on=sexSeen(k);bd.hidden=!on;
  if(on){bd.className='sx '+dd.sex;const P='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">';
   bd.innerHTML=dd.sex==='m'?P+'<circle cx="10" cy="14" r="5.5"/><path d="M14 10l6-6M14.5 4H20v5.5"/></svg>':P+'<circle cx="12" cy="9" r="5.5"/><path d="M12 14.5V22M8.5 18.5h7"/></svg>'}}
 {const nb=b.querySelector('b');let tn=[...nb.childNodes].find(n=>n.nodeType===3);if(!tn){tn=document.createTextNode('');nb.appendChild(tn)}tn.nodeValue=spn(k)}
 const x=b.querySelector('canvas').getContext('2d');
 withPose({x:64,y:52,PC:PAL[bs(k)]||PC,SC:.7*stageF(S.d[k]),ab:10,am:3.2,PH:0},()=>{const T0=T;T=0;try{if(isMn(k)){const m0=mnK;mnK=k;try{drawMantisScene(true)}finally{mnK=m0}}else{const dk=S.d[k],bk=dk.bg&&BGK[dk.bg]?dk.bg:(isSn(k)?'snk':'soil');drawBg(g,bk);drawDecor(dk.dec);if(isSn(k))snakeRender(1,0,0,{...CALM,sp:k});else if(isSc(k))scorpionStill(dk,0,k);else drawSpider()}
  x.imageSmoothingEnabled=false;x.drawImage(cv,0,0,256,256);if(!S.own[k]){x.fillStyle='rgba(10,6,4,.55)';x.fillRect(0,0,256,256);stampLock(x,128,126,96)}}finally{T=T0}});
 b.classList.toggle('sel',k===S.species);b.classList.toggle('lock',!S.own[k]);b.querySelector('small').textContent=S.own[k]?'':t('lockt')})}
function cardClick(){const b=this;if(pickEdit)return;if(!S.own[b.dataset.sp]){$('pMsg').textContent=t('p_locked');return}if(st!=='idle'){$('pMsg').textContent=t('p_wait');return}S.species=b.dataset.sp;D=S.d[S.species];PC=PAL[bs(S.species)]||PC;petUI();decSel=defSel();decUI();save();show('game')}
document.querySelectorAll('.card').forEach(b=>b.onclick=cardClick);
$('mPlay').onclick=()=>{if(!mFix()){$('mMsg').textContent=t('m_nopet');return}$('mMsg').textContent='';show('game')};$('back').onclick=()=>show('menu',1);
$('mPick').onclick=()=>show('pick');$('backP').onclick=()=>show('menu',1);
$('mCur').textContent=spn(S.species);

