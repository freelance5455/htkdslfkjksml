// Экран «Спаривание»: выбор самца и самки, кнопка «Свести», сцена для будущей анимации
/*MATE-START*/
let mateSel={m:null,f:null},mateSig='',mtT=0,mateFx=null; // mateFx — идущая сейчас анимация {t0,ok,m,f}; ставится после спаривания
const MATE_FX_LEN=2.4; // сколько секунд длится анимация-заглушка
const mateSexIcon=s=>{const P='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">';
 return s==='m'?P+'<circle cx="10" cy="14" r="5.5"/><path d="M14 10l6-6M14.5 4H20v5.5"/></svg>':P+'<circle cx="12" cy="9" r="5.5"/><path d="M12 14.5V22M8.5 18.5h7"/></svg>'};
const mateList=()=>Object.keys(S.d).filter(k=>mateIs(k)&&sexSeen(k)); // пол виден: пауки — с 8-й линьки, змеи — со стадии SNX
// ---- рисование ----
function mateFloor(x,w,h){x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;for(let X=0;X<w;X+=80)x.drawImage(SPFLOOR,0,0,80,Math.min(104,h),X,0,80,Math.min(104,h))}
// змея рисуется один раз в полном размере (128x128, прозрачный фон, как на экране выбора питомца) и потом уменьшается — так тёмный питон не теряется
const MSNC={};
function mateSnakeCv(k){const b=bs(k);if(MSNC[b])return MSNC[b];const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.imageSmoothingEnabled=false;
 onCtx(x,()=>snakeRender(1,0,0,{...CALM,sp:b}));return MSNC[b]=c}
function mateThumb(c,k,tm){const x=c.getContext('2d');
 if(isSnB(k)){x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;x.drawImage(BGK.snk,128,128,128,128,0,0,80,80);x.imageSmoothingEnabled=true;x.drawImage(mateSnakeCv(k),0,0,128,128,0,0,80,80);x.imageSmoothingEnabled=false;return}
 mateFloor(x,80,80);fixCtx(x,2);spiderAt(x,k,20,22,.34,tm)}
// питомец на сцене: паук или змея (px_ — центр по горизонтали)
function mateAt(x,k,px_,py,tm){if(isSnB(k)){x.imageSmoothingEnabled=true;x.drawImage(mateSnakeCv(k),0,0,128,128,px_-28,3+Math.sin(tm*1.3)*.8,56,56);x.imageSmoothingEnabled=false}else spiderAt(x,k,px_,py,.27,tm)}
// ---- сцена. Сейчас: два паучка стоят, после спаривания сходятся и появляются сердечки. ----
// Сюда потом: настоящая анимация. mateFx.ok — удалось или нет, mateFx.t0 — когда началась (секунды), tm — текущее время.
function mateStage(c,tm){const x=c.getContext('2d'),W2=120,H2=60;x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;const m=mateFx?mateFx.m:mateSel.m,f=mateFx?mateFx.f:mateSel.f;
 x.drawImage(isSnB(m)||isSnB(f)?BGK.snk:BGK.soil,128,160,256,128,0,0,240,120);fixCtx(x,2);
 let p=0;if(mateFx){p=(tm-mateFx.t0)/MATE_FX_LEN;if(p>=1){mateFx=null;p=0}}
 const near=p>0?Math.sin(Math.min(1,p)*Math.PI):0; // 0 → 1 → 0: сходятся и расходятся
 if(m&&!(mateFx&&mateFx.eaten&&p>.5))mateAt(x,m,32+near*14,34,tm); // съеденный самец пропадает
 if(f)mateAt(x,f,88-near*14,34,tm+1.7);
 if(!m&&!f){x.fillStyle='rgba(60,40,20,.55)';x.font='8px sans-serif';x.textAlign='center';x.fillText('?',W2/2,H2/2)}
 if(mateFx&&mateFx.ok&&p>.35){x.font='9px sans-serif';x.textAlign='center';x.fillStyle='#ff6fa0';for(let i=0;i<3;i++){const u=(p-.35)*1.6+i*.25;x.globalAlpha=Math.max(0,1-u);x.fillText('♥',W2/2-8+i*8,26-u*14)}x.globalAlpha=1}}
// ---- сборка ----
function mateCard(k){const d=S.d[k],ok=mateMature(k),sel=mateSel[d.sex]===k,pre=matePre(k);
 const st=ok?(pre?t('mt_molt'):mateWait(k,d.sex)>0?t('mt_rest'):t('mt_ready')):t('mt_young')+(isSnB(k)?' '+(d.stage||1)+'/'+MATE.minSt:' L'+(d.L||6)+'/'+MATE.minL);
 return`<button class="mcard${sel?' sel':''}${ok?'':' off'}" data-k="${k}"><canvas width="80" height="80"></canvas><b>${spn(k)}</b><small><i class="msx ${d.sex}">${mateSexIcon(d.sex)}</i> ${mSt(k).split(' · ').filter((_,i)=>i!==1).join(' · ')}</small><em>${st}</em></button>`}
function mateSigNow(){return LANG+'|'+mateList().map(k=>k+S.d[k].L+(mateMature(k)?1:0)+(matePre(k)?1:0)+(mateSel.m===k||mateSel.f===k?'*':'')).join(',')}
function mateBuild(){const all=mateList(),ms=all.filter(k=>S.d[k].sex==='m'),fs=all.filter(k=>S.d[k].sex==='f');
 if(mateSel.m&&!ms.includes(mateSel.m))mateSel.m=null;if(mateSel.f&&!fs.includes(mateSel.f))mateSel.f=null;
 const col=(ar,h)=>`<div class="sign">${h}</div>${ar.length?`<div class="mgrid">${ar.map(mateCard).join('')}</div>`:`<p class="mempty">${t('mt_none')}</p>`}`;
 $('mateBody').innerHTML=col(ms,'♂ '+t('mt_males'))+col(fs,'♀ '+t('mt_females'));
 $('mateBody').querySelectorAll('.mcard').forEach(b=>mateThumb(b.querySelector('canvas'),b.dataset.k,0));
 mateSig=mateSigNow();mateRefresh()}
function mateRefresh(){const m=mateSel.m,f=mateSel.f,c=m&&f?mateCheck(m,f):null,M=S.mate;
 $('mateGo').disabled=!(c&&c.ok);
 $('mateInfo').textContent=!m||!f?t('mt_pick'):c.ok?spn(m)+'  ♥  '+spn(f)+' · '+t('mt_max')+MATE.clutch(m,f)[1]+(MATE.risk(m,f)>0?' · '+t('mt_risk')+Math.round(MATE.risk(m,f)*100)+'%':''):t('mt_r_'+c.rule.id);
 $('mateCnt').textContent=t('mt_cnt')+M.cnt+' · '+t('mt_cnt_ok')+M.ok}
function mateUI(){if($('mate').hidden)return;if(mateSig!==mateSigNow())mateBuild();else mateRefresh()}
function mateDraw(tm){const c=$('mateCv');if(c)mateStage(c,tm)}
function renderMate(){mateSel={m:null,f:null};mateFx=null;$('mateMsg').textContent='';mateBuild()}
// ---- кнопки ----
$('bMate').onclick=()=>show('mate');$('backT').onclick=()=>show('breed',1);
$('mBreed').onclick=()=>show('breed');$('bBack').onclick=()=>show('menu',1);
$('mateBody').onclick=e=>{const b=e.target.closest('.mcard');if(!b)return;const k=b.dataset.k,d=S.d[k],m=$('mateMsg');m.textContent='';
 if(!mateMature(k)){m.textContent=t('mt_r_mat');return}
 mateSel[d.sex]=mateSel[d.sex]===k?null:k;mateBuild()};
$('mateGo').onclick=()=>{const m=mateSel.m,f=mateSel.f,msg=$('mateMsg');if(!m||!f)return;
 const r=mateGo(m,f);if(r.fail){msg.textContent=t('mt_r_'+r.fail);mateBuild();return}
 mateFx={t0:performance.now()/1000,ok:r.ok,m,f,eaten:r.eaten};
 msg.textContent=r.eaten?t('mt_eat'):r.ok?t(isSnB(r.sp)?'mt_ok_sn':'mt_ok')+r.n:t('mt_fail');
 mateSel={m:null,f:null};mateEv=[];mateBuild()};
/*MATE-END*/
