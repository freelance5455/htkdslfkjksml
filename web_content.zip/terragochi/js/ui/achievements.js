// Достижения: экран-список (как в Террарии: рамка с картинкой, название, описание, приз) и всплывашка при получении
document.documentElement.style.setProperty('--acn',ACH_ICONS);
function renderAch(){const done=ACH.filter(a=>S.ach[a.id]).length;
 $('aSub').textContent=t('ach_cnt')+done+' / '+ACH.length;
 $('alist').innerHTML=ACH.map(a=>{const ok=!!S.ach[a.id],v=Math.min(a.need,ACH_STAT[a.stat]());
  return '<div class="ach'+(ok?' done':'')+'"><i class="ai" style="--n:'+a.icon+'"></i><div class="at"><b>'+t('ach_'+a.id+'_n')+'</b><span>'+t('ach_'+a.id+'_d')+'</span>'
   +(ok?'':'<em class="pb"><u style="width:'+Math.round(v/a.need*100)+'%"></u></em><small>'+v+' / '+a.need+'</small>')
   +'</div><div class="ap"><i></i>+'+a.coins+(ok?'<small>'+t('ach_done')+'</small>':'')+'</div></div>'}).join('')}
$('mAch').onclick=()=>{achCheck();renderAch();show('ach')};
$('aBack').onclick=()=>show('menu',1);

// всплывашка «Достижение получено!» (очередь: если сразу несколько, показываются по очереди)
const AQ=[];let aBusy=false;
const achEl=document.createElement('div');achEl.id='achToast';
achEl.innerHTML='<i class="ai"></i><div class="at"><small></small><b></b></div><div class="ap"><i></i><span></span></div>';document.body.appendChild(achEl);
function achToast(a){AQ.push(a);if(!aBusy)achNext()}
function achNext(){const a=AQ.shift();if(!a){aBusy=false;return}aBusy=true;
 achEl.querySelector('.ai').style.setProperty('--n',a.icon);achEl.querySelector('small').textContent=t('ach_new');
 achEl.querySelector('b').textContent=t('ach_'+a.id+'_n');achEl.querySelector('.ap span').textContent='+'+a.coins;
 achEl.classList.add('on');setTimeout(()=>{achEl.classList.remove('on');setTimeout(achNext,450)},3800)}
