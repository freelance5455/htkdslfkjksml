// Низкоуровневая графика: контекст холста, px/line/ell, повороты, генератор rnd
const $=id=>document.getElementById(id),cv=$('c'),W=128;
let g=cv.getContext('2d');g.imageSmoothingEnabled=false;
const SCALE=4;const fixCtx=(c,k=SCALE)=>{c.setTransform(k,0,0,k,0,0);c.imageSmoothingEnabled=false};
function onCtx(c,fn){const o=g;g=c;try{fn()}finally{g=o}}
const K={dk:'#2a1a14',or:'#e8590c',or2:'#ff8a2b',or3:'#b8430a',bk:'#0d0806',ab:'#1a0f0b',ab2:'#2e1c14'};
const snapH=v=>Math.round(v);
const px=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(snapH(x),snapH(y),w,h)};
function line(x0,y0,x1,y1,c,w=1){x0=Math.round(x0);y0=Math.round(y0);x1=Math.round(x1);y1=Math.round(y1);
 const dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1;let e=dx+dy;
 for(;;){px(x0,y0,w,w,c);if(x0===x1&&y0===y1)break;const e2=2*e;if(e2>=dy){e+=dy;x0+=sx}if(e2<=dx){e+=dx;y0+=sy}}}
function ell(cx,cy,rx,ry,c){cx=Math.round(cx);cy=Math.round(cy);rx=Math.max(1,rx);ry=Math.max(1,ry);
 for(let y=-ry;y<=ry;y++){const hw=Math.round(rx*Math.sqrt(1-y*y/(ry*ry)));px(cx-hw,cy+y,hw*2+1,1,c)}}
function rEll(cx,cy,rx,ry,a,c){const co=Math.cos(a),si=Math.sin(a),R=Math.ceil(Math.max(rx,ry))+1;g.fillStyle=c;
 for(let y=Math.floor(cy-R);y<=cy+R;y+=.5)for(let x=Math.floor(cx-R);x<=cx+R;x+=.5){const dx=x+.25-cx,dy=y+.25-cy,u=(dx*co+dy*si)/rx,v=(-dx*si+dy*co)/ry;if(u*u+v*v<=1)g.fillRect(x,y,.5,.5)}}
function rRect(cx,cy,hw,hh,a,c){const co=Math.cos(a),si=Math.sin(a),R=Math.ceil(Math.hypot(hw,hh))+1;g.fillStyle=c;
 for(let y=Math.floor(cy-R);y<=cy+R;y+=.5)for(let x=Math.floor(cx-R);x<=cx+R;x+=.5){const dx=x+.25-cx,dy=y+.25-cy;if(Math.abs(dx*co+dy*si)<=hw&&Math.abs(-dx*si+dy*co)<=hh)g.fillRect(x,y,.5,.5)}}
let seed=7;const rnd=()=>(seed=seed*16807%2147483647)/2147483647;
