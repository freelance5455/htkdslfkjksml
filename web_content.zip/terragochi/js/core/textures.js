// Процедурные текстуры грунта/песка/подстилки, фон террариума, «лечение» канвасов
function sandTex(c,seed,m,pebs,holes){const W=c.width,H=c.height,cx2=c.getContext('2d'),im=cx2.createImageData(W,H),d=im.data;let q=seed;const r=()=>(q=q*16807%2147483647)/2147483647;
 const P=[[217,184,124],[201,164,104],[228,197,143],[191,154,94],[169,132,80]];
 const put=(x,y,col)=>{const i=(y*W+x)*4;d[i]=col[0];d[i+1]=col[1];d[i+2]=col[2];d[i+3]=255};
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const v=r();put(x,y,v<.1?P[1]:v<.16?P[2]:v<.2?P[3]:v<.215?P[4]:P[0])}
 for(let p=0;p<pebs;p++){const cx0=r()*W,cy0=r()*H,rx=(1.5+r()*2)*m,ry=rx*(.55+r()*.2);
  for(let y=Math.floor(cy0-ry-1);y<=cy0+ry+1;y++)for(let x=Math.floor(cx0-rx-1);x<=cx0+rx+1;x++){if(x<0||y<0||x>=W||y>=H)continue;
   const nx=(x+.5-cx0)/rx,ny=(y+.5-cy0)/ry,f=nx*nx+ny*ny;if(f>1)continue;const lit=-(nx+ny)*.7;
   put(x,y,f>.72?[122,82,48]:lit>.35?[232,200,150]:lit>-.25?[169,132,80]:[140,106,60])}}
 for(const h of holes){for(let y=Math.floor(h.y-h.ry);y<=h.y+h.ry;y++)for(let x=Math.floor(h.x-h.rx);x<=h.x+h.rx;x++){if(x<0||y<0||x>=W||y>=H)continue;
   const nx=(x+.5-h.x)/h.rx,ny=(y+.5-h.y)/h.ry,f=nx*nx+ny*ny;if(f>1)continue;put(x,y,f>.8?[74,54,38]:[46,32,22])}}
 cx2.putImageData(im,0,0)}
const bg=document.createElement('canvas');bg.width=bg.height=512;sandTex(bg,23,4,8,[]);
function groundTex(c,kind){const W=c.width,H=c.height,cx2=c.getContext('2d'),im=cx2.createImageData(W,H),d=im.data,soil=kind==='soil';let q=soil?31:47;const r=()=>(q=q*16807%2147483647)/2147483647;
 const put=(x,y,col)=>{if(x<0||y<0||x>=W||y>=H)return;const i=(y*W+x)*4;d[i]=col[0];d[i+1]=col[1];d[i+2]=col[2];d[i+3]=255};
 const P=soil?[[104,74,48],[92,64,40],[118,86,56],[80,54,34],[66,44,28]]:[[84,122,56],[72,106,48],[98,138,64],[60,92,40],[48,76,32]];
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const v=r();put(x,y,v<.1?P[1]:v<.16?P[2]:v<.2?P[3]:v<.215?P[4]:P[0])}
 const shape=(cx0,cy0,rx,ry,a,cl)=>{const co=Math.cos(a),si=Math.sin(a),R=Math.ceil(Math.max(rx,ry))+1;
  for(let y=Math.floor(cy0-R);y<=cy0+R;y++)for(let x=Math.floor(cx0-R);x<=cx0+R;x++){const dx=x+.5-cx0,dy=y+.5-cy0,u=(dx*co+dy*si)/rx,v=(-dx*si+dy*co)/ry,f=u*u+v*v;if(f>1)continue;const lit=-(u*.5+v*.7);put(x,y,f>.7?cl[0]:lit>.35?cl[2]:lit>-.2?cl[1]:cl[0])}};
 if(soil){for(let i=0;i<90;i++)shape(r()*W,r()*H,4+r()*6,2+r()*1.6,r()*3.14,[[56,36,20],[126,88,52],[160,114,72]]);
  for(let i=0;i<16;i++)shape(r()*W,r()*H,3+r()*3,2+r()*2,r()*3.14,[[70,70,66],[120,118,112],[160,158,150]])}
 else{for(let i=0;i<70;i++)shape(r()*W,r()*H,7+r()*9,5+r()*6,r()*3.14,[[42,66,28],[104,148,70],[136,180,92]]);
  for(let i=0;i<26;i++){const x0=r()*W,y0=r()*H,a=r()*3.14;shape(x0,y0,6+r()*3,2.6+r()*1,a,[[92,62,30],[150,108,54],[184,138,70]]);
   for(let k=-5;k<=5;k++)put(Math.round(x0+Math.cos(a)*k),Math.round(y0+Math.sin(a)*k),[96,62,30])}}
 cx2.putImageData(im,0,0)}
const mkG=k=>{const c=document.createElement('canvas');c.width=c.height=512;groundTex(c,k);return c};
const BGK={sand:bg,soil:mkG('soil'),moss:mkG('moss')},BKS=['soil','sand','moss'];
const SNKI=new Image();BGK.snk=mkG('soil');
function drawSnk(){const c=BGK.snk,x=c.getContext('2d');x.imageSmoothingEnabled=false;x.drawImage(SNKI,0,0,512,512)}
SNKI.onload=()=>{drawSnk();try{refreshAcc()}catch(e){}};SNKI.src='assets/img/bg_snake_forest.png';
function drawBg(c,k){k=k||(typeof S!=='undefined'&&S.bg)||'soil';c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,c.canvas.width,c.canvas.height);c.fillStyle='#d9b87c';c.fillRect(0,0,c.canvas.width,c.canvas.height);c.drawImage(BGK[k]||bg,0,0);fixCtx(c,SCALE)}
// браузер может стереть содержимое offscreen-канвасов, пока вкладка в фоне: проверяем и пересоздаём
const alive=c=>{try{return c.getContext('2d').getImageData(c.width>>1,c.height>>1,1,1).data[3]>0}catch(e){return true}};
let healT=0;
function heal(force){const n=performance.now();if(!force&&n-healT<1000)return;healT=n;
 try{if(!alive(bg))sandTex(bg,23,4,8,[])}catch(e){}
 try{for(const k of['soil','moss'])if(!alive(BGK[k]))groundTex(BGK[k],k)}catch(e){}
 try{if(SNKI.complete&&SNKI.naturalWidth&&!alive(BGK.snk))drawSnk()}catch(e){}
 try{if(!alive(SPFLOOR))sandTex(SPFLOOR,23,2,3,[{x:4,y:22,rx:26,ry:14}])}catch(e){}
 try{if(CARL.some(c=>!alive(c))){CARC=new WeakMap();CARL.length=0}}catch(e){}}
['visibilitychange','pageshow','focus'].forEach(ev=>addEventListener(ev,()=>{if(!document.hidden)heal(true)}));
const SPOTS=Array.from({length:46},()=>{const a=rnd()*6.28,r=Math.sqrt(rnd());return[Math.cos(a)*r,Math.sin(a)*r,rnd()<.3]});
const LEGS=[[-6,-6,-20,-26,-38,-22],[-8,-3,-28,-16,-50,-10],[-8,2,-30,2,-50,14],[-6,6,-24,22,-40,38]];
