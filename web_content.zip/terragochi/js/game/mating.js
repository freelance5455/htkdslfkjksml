// Спаривание: правила (без рисования). Экран — js/ui/mating.js.
// Сейчас: берём самца и самку одного вида, оба половозрелые → кокон (пауки) или яйца (змеи) попадают в инкубатор (incAddCocoon / incAddEggs).
// Всё, что потом захочется усложнить (шансы, условия, перерывы, размер кладки, гибель самца) — в блоке MATE ниже.
const MATE={
 minL:13,            // с какой линьки паук половозрелый (L13 = «адульт»)
 minSt:10,           // змеи: с какой стадии (1..10) половозрелые
 sameSpecies:true,   // скрещивать только особей одного вида (false — гибриды: кокон будет вида самки)
 cd:{m:0,f:0},       // перерыв после спаривания, секунд (самец / самка); 0 = без ограничений
 n:[5,30],           // сколько паучков в коконе: от и до (максимум 30)
 pen:[0,7,15],       // штраф к максимуму кладки САМКИ: 0 / 1 / 2 её «невыросших» линьки (d.fm), только самкам
 nSp:{corn:[10,10],ball:[5,5]}, // свои размеры кладки по видам: маисовый полоз — 10 яиц, шаровидный питон — 5 (число яиц у змей постоянное)
 hatch:null,         // время до вылупления, секунд; null = как в инкубаторе (INC.hatch)
 log:30,             // сколько последних спариваний помнить в S.mate.log
 // шанс успеха от 0 до 1. Сюда потом: настроение, сытость, укрытие, возраст, предыдущие попытки…
 chance:(km,kf)=>1,
 // Самка съедает самца. Шанс считается отдельно по сытости и по настроению самки (0..100), потом они складываются:
 // порог — ниже него риск есть; p0 — шанс прямо на пороге; p1 — шанс при нуле (между ними плавно растёт); итог = 1-(1-по_сытости)*(1-по_настроению), не больше max.
 // Если самка съела самца — спаривание не удалось, кокона нет, самец погибает.
 eat:{sat:{th:65,p0:.70,p1:.95},mood:{th:40,p0:.70,p1:.95},max:.97},
 risk:(km,kf)=>{if(isSnB(kf))return 0; // змея самца не съедает
  const E=MATE.eat,d=S.d[kf]||{},q=(v,o)=>v<o.th?o.p0+(o.p1-o.p0)*(o.th-v)/o.th:0;
  return Math.min(E.max,1-(1-q(d.sat||0,E.sat))*(1-q(d.mood||0,E.mood)))},
 // размер кладки [от, до]. Сюда потом: размер самки, сытость, число прошлых кладок…
 clutch:(km,kf)=>{const b=MATE.nSp[bs(kf)]||MATE.n,f=(S.d[kf]&&S.d[kf].fm)||0,p=MATE.pen[Math.min(MATE.pen.length-1,f)];return[b[0],Math.max(b[0],b[1]-p)]},
 // Условия. Проверяются по порядку, первое невыполненное — причина отказа (key — строка во всех i18n).
 // Новое условие = ещё одна строка в этом списке + текст mt_r_<id> в ru/en/zh.
 rules:[
  {id:'own',  ok:(m,f)=>mateIs(m)&&mateIs(f)},
  {id:'sex',  ok:(m,f)=>S.d[m].sex==='m'&&S.d[f].sex==='f'},
  {id:'sp',   ok:(m,f)=>!MATE.sameSpecies||bs(m)===bs(f)},
  {id:'mat',  ok:(m,f)=>mateMature(m)&&mateMature(f)},
  {id:'molt', ok:(m,f)=>!matePre(m)&&!matePre(f)},
  {id:'cd',   ok:(m,f)=>mateWait(m,'m')<=0&&mateWait(f,'f')<=0},
  {id:'co',   ok:(m,f)=>isSnB(f)||!incCoFull()},   // пауки: есть ли место под кокон
  {id:'eg',   ok:(m,f)=>!isSnB(f)||!incEgFull()}    // змеи: есть ли свободный контейнер под яйца
 ]
};
// данные: S.mate = {cnt: всего попыток, ok: удачных, log: последние спаривания}; у каждого паука d.mate = {cnt, last}
S.mate=S.mate||{};{const M=S.mate;M.cnt=M.cnt||0;M.ok=M.ok||0;M.log=Array.isArray(M.log)?M.log:[]}
let mateEv=[]; // события для анимации/уведомлений: сюда кладётся результат каждого спаривания
const mateIs=k=>!!(k&&S.own[k]&&S.d[k]&&((isSpd(k)&&!isSc(k))||isSnB(k))); // пауки (кроме скорпиона) и маисовый полоз / шаровидный питон
const mateMature=k=>mateIs(k)&&(isSnB(k)?(S.d[k].stage||1)>=MATE.minSt:(S.d[k].L||6)>=MATE.minL);
const matePre=k=>!!(S.d[k]&&S.d[k].molt&&S.d[k].molt.ph==='pre'); // перед линькой паук не до того
// сколько секунд ещё ждать после прошлого спаривания (s — 'm' или 'f')
function mateWait(k,s){const c=MATE.cd[s]||0,d=S.d[k];if(!c||!d||!d.mate||!d.mate.last)return 0;return Math.max(0,(d.mate.last+c*1000-Date.now())/1000)}
// можно ли свести этих двоих: {ok:true} или {ok:false, rule:{id}}
function mateCheck(km,kf){for(const r of MATE.rules)if(!r.ok(km,kf))return{ok:false,rule:r};return{ok:true}}
// свести: возвращает результат {ok, m, f, sp, n, ts} или {fail:'id условия'}; кокон добавляется в инкубатор сам
function mateGo(km,kf){const c=mateCheck(km,kf);if(!c.ok)return{fail:c.rule.id};
 const now=Date.now(),sp=bs(kf),r={ok:false,m:km,f:kf,sp,n:0,ts:now};
 for(const k of[km,kf]){const d=S.d[k];d.mate=d.mate||{cnt:0,last:0};d.mate.cnt++;d.mate.last=now}
 r.eaten=Math.random()<MATE.risk(km,kf);r.ok=!r.eaten&&Math.random()<MATE.chance(km,kf);
 if(r.ok){const[a,b]=MATE.clutch(km,kf);r.n=a+Math.floor(Math.random()*(b-a+1));if(isSnB(sp))incAddEggs(sp,r.n);else incAddCocoon(sp,r.n,MATE.hatch)}
 const M=S.mate;M.cnt++;if(r.ok)M.ok++;M.log.push({ts:now,m:km,f:kf,sp,ok:r.ok,n:r.n,eaten:r.eaten});while(M.log.length>MATE.log)M.log.shift();
 mateEv.push(r);if(r.eaten){M.eaten=(M.eaten||0)+1;mDie(km,'mt_eaten')}save();return r}
