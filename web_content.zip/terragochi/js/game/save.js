// Сохранение в localStorage
let PC=PAL[bs(S.species)]||PAL.boehmei;
let noSave=false;const save=()=>{if(noSave)return;try{S.ts=Date.now();localStorage.setItem('spiderTama2',JSON.stringify(S))}catch(e){}};
setInterval(save,5000);document.addEventListener('visibilitychange',save);

