// Рост и линька, условия террариума, смерть/новые питомцы, первичная локализация
/* ================= ЛИНЬКА (упрощённая) + проверка террариума ================= */
const MCYC={spider:2700,mantis:1800,snake:3300},MPRE=420;
/* ---- линьки пауков по GDD: [весь цикл, предлинька] в часах; индекс = L-6 ---- */
const MH=3600; // секунд в «часе» из GDD (для быстрой проверки можно поставить 3)
const GROW=[[35,9],[48,13],[67,18],[92,25],[127,36],[173,50],[236,68],[311,90],[403,117],[518,153],[656,198],[817,252],[1001,315],[1208,387]];
const GROWF=[[15,4],[21,5],[28,6],[38,9],[52,13],[69,17],[92,23],[121,32],[155,41],[196,54]];
const spTab=k=>bs(k)==='murinus'?GROWF:GROW,spFin=k=>spTab(k).length+6; // медленные L20, быстрые L16
const stageL=L=>1+9*(Math.min(L,13)-6)/7; // размер растёт L6..L13, дальше без изменений
// Неудачная линька (условий террариума выполнено меньше 2): с шансом MFAIL.p питомец её переживает — линька засчитывается (L+1), но размер не растёт.
// Не больше MFAIL.max раз на питомца (иначе вырастут совсем мелкие адульты). Счётчик — d.fm; он же даёт самкам штраф к кладке (MATE.pen в js/game/mating.js).
const MFAIL={p:.35,max:2};
const stageD=d=>stageL(Math.max(6,Math.min(d.L||6,13)-(d.fm||0))); // размер по линьке минус «невыросшие» линьки
// T_actual = T_base * K_temp * K_feed * K_hum (у нас нет термометра: K_temp=1)
function molK(k){const d=S.d[k],kf=d.sat>=50?1:1+(50-d.sat)/50,kh=(MBG[bs(k)]||['soil']).includes(d.bg)?1:1.15;return 1*kf*kh}
function mFmt(s){s=Math.max(0,Math.ceil(s));const d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);
 if(d)return d+t('ml_d')+' '+h+t('ml_h');if(h)return h+t('ml_h')+' '+m+t('ml_m');return Math.max(1,m)+t('ml_m')}
function mClock(s){s=Math.ceil(s);return s>=3600?mFmt(s):Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
function mSt(k){const d=S.d[k];if(!isSpd(k))return t('ml_stage')+d.stage+'/10'+(sexSeen(k)?' · '+t(d.sex==='m'?'sx_m':'sx_f'):'');const L=d.L||6,old=bs(k)==='murinus'?15:16,m=d.sex==='m';let s='L'+L;
 if(L>=8&&d.sex)s+=' · '+t(m?'sx_m':'sx_f'); // пол определён сразу, но показывается только с 8-й линьки
 if(L===13)s+=' · '+t('st_ad');else if(!m&&L>=old)s+=' · '+t('st_old');else if(!m&&L>13)s+=' · '+t('st_f');if(d.fm)s+=' · '+t('st_fm')+d.fm;return s}
const mGrp=k=>isMn(k)?'mantis':isSn(k)?'snake':'spider';
const mCyc=k=>MCYC[mGrp(k)]*(.8+Math.random()*.4)*(.5+.5*(((S.d[k]&&S.d[k].stage)||1)-1)/9);
const MBG={boehmei:['sand','soil'],hamori:['sand','soil'],albo:['soil','moss'],murinus:['sand','soil'],muticus:['soil','sand'],scorpion3:['sand','soil'],mantis:['soil','moss'],corn:['snk','soil','moss'],ball:['snk','soil','moss'],boa:['snk','soil','moss']};
const inPre=()=>!!(D&&D.molt&&D.molt.ph==='pre');
function rsc(){return SC/.7}
// размер: база по стадии (0.42..1.0) и индивидуальная вариация d.vr = -1/0/+1 (±15% к финалу).
// Вариация проявляется постепенно: на старте ~2% от своих 10%, к последней линьке полные 10%.
const stageF=d=>{const st=(d&&d.stage)||1,b=.42+(st-1)*.58/9,v=(d&&d.vr)||0;if(!v)return b;
 const f=b*(1+.15*v*(.2+.8*(st-1)/9));return d.L?f:Math.min(1,f)}; // змеи и богомол упираются в границы экрана: потолок 1.0
function mFix(){if(S.own[S.species])return true;const o=Object.keys(S.own).find(q=>S.own[q]);if(!o)return false;
 S.species=o;D=S.d[o];PC=PAL[bs(o)]||PC;petUI();decSel=defSel();decUI();return true}
function mNew(k,first){if(isSpd(k)){const d=S.d[k];if(d&&d.sex==='m'&&(d.L||6)>=13){const c=(bs(k)==='murinus'?276:714)*MH;return{ph:'adult',t:c,c,n:0,v:2}}
  const L=Math.max(6,Math.min((d&&d.L)||6,spFin(k)-1)),r=spTab(k)[L-6],c=(r[0]-r[1])*MH;return{ph:'ok',t:c,c,pre:r[1]*MH,n:0,v:2}}
 const c=first?600+Math.random()*600:mCyc(k);return{ph:'ok',t:c,c,n:0}}
(function mInit(){const off=window.OFFS||0,offF=window.OFFF||0;
 for(const k in S.d){const d=S.d[k],sp=isSpd(k);let m=d.molt;if(!d.stage)d.stage=1;if(d.vr===undefined)d.vr=[-1,0,1][Math.floor(Math.random()*3)];
  if(isSnB(k)&&!d.sex)d.sex=Math.random()<.5?'m':'f'; // змеям пол тоже достаётся при рождении
  if(sp){if(!d.sex)d.sex=Math.random()<.5?'m':'f';if(!d.L)d.L=Math.max(6,Math.min(13,6+Math.round((d.stage-1)*7/9)));d.stage=stageD(d);if(!m||m.v!==2||typeof m.t!=='number'||(m.ph!=='ok'&&m.ph!=='pre'&&m.ph!=='adult')||(d.sex==='m'&&d.L>=13&&m.ph!=='adult')){d.molt=mNew(k,false);continue}}
  else if(!m||typeof m.t!=='number'||(m.ph!=='ok'&&m.ph!=='pre')){d.molt=mNew(k,true);continue}
  if(!m.c)m.c=Math.max(60,m.t);
  const o=sp?offF:off;
  if(S.own[k]&&o>0){const K=sp&&m.ph!=='adult'?molK(k):1;
   if(m.ph==='ok'){m.t-=o/K;if(m.t<=0){const left=-m.t;m.ph='pre';m.c=sp?(m.pre||MPRE):MPRE;m.t=sp?m.c-left:MPRE}}
   else m.t=sp?m.t-o/K:Math.max(60,m.t-o/K)}}})();
// условия: укрытие, подходящий грунт, общее состояние
function mConds(k){const d=S.d[k],ks=isMn(k)?MDK:HIDES;
 return[ks.some(q=>d.dec[q]&&d.dec[q].on),(MBG[bs(k)]||['soil']).includes(d.bg),d.mood>=40&&d.sat>=25]}
let toastT=0;const toastEl=document.createElement('div');toastEl.id='toast';document.body.appendChild(toastEl);
function mToast(s){toastEl.textContent=s;toastEl.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>toastEl.classList.remove('on'),4500)}
function mDie(k,key){const d=S.d[k];d.sat=60;d.mood=50;d.stage=1;d.vr=[-1,0,1][Math.floor(Math.random()*3)];if(isSpd(k)){d.L=6;d.fm=0;d.sex=Math.random()<.5?'m':'f'}else if(isSnB(k))d.sex=Math.random()<.5?'m':'f';d.molt=mNew(k,false);S.own[k]=false;delete d.name;delete d.mate;
 const tx=spn(k)+' '+t(key||'m_dead');
 if(S.species===k){const ok=mFix();
  if(!ok&&(cur==='game'||cur==='ward')){show('menu',1);$('mMsg').textContent=t('m_nopet')}
  else if(ok&&cur==='ward')renderWard()}
 save();mToast(tx);try{refreshSp();renderPick();$('mCur').textContent=S.own[S.species]?spn(S.species):'—'}catch(e){}}
function mSoft(k){const d=S.d[k];d.fm=(d.fm||0)+1;d.L=(d.L||6)+1;d.stage=stageD(d);d.molt=mNew(k,false);d.molt.n=(d.molt.n||0)+1;d.mood=Math.max(0,d.mood-20);
 const fm=' '+d.fm+'/'+MFAIL.max;
 if(k===S.species){setMsg('m_mlf');$('msg').textContent+=fm+' · '+mSt(k)}else mToast(spn(k)+': '+t('m_mlf')+fm+' · '+mSt(k));
 save()}
function mResolve(k){const d=S.d[k],n=mConds(k).filter(Boolean).length,sp=isSpd(k);
 if(sp&&(d.L||6)+1>=spFin(k)){mDie(k,'m_old');return} // последний цикл заканчивается естественной смертью
 if(sp&&n<=1&&(d.fm||0)<MFAIL.max&&Math.random()<MFAIL.p){mSoft(k);return} // 35%: пережил, линька засчитана, но не вырос
 if(n<=1&&Math.random()<(n?.25:.5)){mDie(k);return}
 if(sp&&bs(k)!=='murinus'&&d.L===18&&Math.random()<.2){mDie(k);return} // предельный возраст: шанс гибели при линьке
 if(n>=2){if(sp){d.L=(d.L||6)+1;d.stage=stageD(d)}else d.stage=Math.min(10,(d.stage||1)+1)}d.molt=mNew(k,false);d.molt.n=(d.molt.n||0)+1;
 const coins=n===3?10:n===2?3:0;S.coins+=coins;
 d.mood=Math.max(0,Math.min(100,d.mood+(n===3?25:n===2?-20:-35)));
 const key='m_ml'+Math.max(1,n);
 if(k===S.species){setMsg(key);$('msg').textContent+=' · '+mSt(k);if(n>=2)for(let i=0;i<4;i++)fx.push({x:44+i*14,y:40-i%2*8,l:1.4,bad:n===2})}
 else mToast(spn(k)+': '+t(key)+' · '+mSt(k));
 save()}
let mUiK='';
function moltTick(dt){
 for(const k in S.d){if(!S.own[k])continue;const m=S.d[k].molt;if(!m)continue;m.t-=dt/(isSpd(k)&&m.ph!=='adult'?molK(k):1);
  if(m.t<=0){
   if(m.ph==='ok'){m.ph='pre';m.t=m.pre||MPRE;m.c=m.t;save();if(k===S.species)setMsg('m_pre');else mToast(spn(k)+': '+t('m_pre'))}
   else if(m.ph==='adult'){if(k!==S.species||st==='idle')mDie(k,'m_old');else m.t=0}else if(k!==S.species||st==='idle')mResolve(k);else m.t=0}}
 const m=D.molt,pre=m.ph==='pre',el=$('mlt'),sp=isSpd(S.species),rem=m.t*(sp&&m.ph!=='adult'?molK(S.species):1);
 if(!isSn(S.species)&&!isMn(S.species))SC=.7*stageF(D);
 if(!$('game').hidden){
  if(!decEdit)$('feed').disabled=st!=='idle'||pre;
  const c=pre?mConds(S.species):[],key=LANG+D.stage+'.'+(D.L||'')+m.ph+(pre?Math.ceil(rem/(rem>=3600?60:1))+c.join():Math.ceil(rem/10));
  if(key!==mUiK){mUiK=key;el.hidden=false;el.classList.toggle('warn',pre);
   if(pre){const s=Math.ceil(rem),nm=[t(isMn(S.species)?'ml_climb':'ml_hide'),t('ml_bg'),t('ml_st')];
    el.innerHTML='<div class="mlp">'+mSt(S.species)+' · '+t('ml_pre')+' · '+mClock(s)+'</div><div class="mlp" style="opacity:.8">'+t('ml_chk')+'</div><div class="mlc">'+c.map((v,i)=>'<span class="'+(v?'y':'n')+'">'+(v?'✓ ':'✗ ')+nm[i]+'</span>').join('')+'</div>'}
   else{const pc=Math.max(0,Math.min(100,100*(1-m.t/(m.c||m.t||1))));
    el.innerHTML=mSt(S.species)+' · '+t(m.ph==='adult'?'ml_life':'ml_next')+(sp?mFmt(rem):Math.max(1,Math.ceil(m.t/60))+t('ml_min'))+'<div class="bar"><i style="width:'+pc.toFixed(1)+'%"></i></div>'}}}}
if($('dbg2'))$('dbg2').onclick=()=>{D.molt.t=0;save()};
applyLang();
let last=performance.now();
