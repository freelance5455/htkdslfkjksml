// Разведение кормовых насекомых (тараканы, сверчки)
/* ---- разведение кормовых ---- */
let brT=0,brK=0;S.br=S.br||{};
const BR={turk:{p:15,b:.045,m:.05,cap:100,f:.53,w:.7,d:.01,sz:.62},arg:{p:20,b:.03,m:.04,cap:120,f:.69,w:.8,d:.01,sz:.75},cri:{p:10,b:.08,m:.08,cap:160,f:.43,w:1.2,d:.03,sz:.6}};
const BRKS=['turk','arg','cri'],brSt={};
/* Расход еды: чем больше в садке, тем быстрее убывает. Едоки = взрослые + половина молоди; x = едоки / cap (0..1).
   Расход в минуту = f * (base + gain * x): новая колония (10 шт.) держится около 2 часов (f подобран под это для каждого вида, колония растёт и ест всё больше), полный садок ест примерно втрое больше новой. Правь числа здесь */
const BRF={base:.7,gain:2.3,juv:.5};
const brEat=(c,r)=>r.f*(BRF.base+BRF.gain*Math.min(1,(c.a+c.j*BRF.juv)/r.cap));
const bh=(i,j)=>{const x=Math.sin(i*127.1+j*311.7)*43758.5453;return x-Math.floor(x)};
function brSim(k){const c=S.br[k],r=BR[k];if(!c)return;const now=Date.now();let n=Math.floor((now-c.ts)/60000);if(n<1)return;c.ts=n>480?now:c.ts+n*60000;n=Math.min(n,480);
 while(n--){c.fd=Math.max(0,c.fd-brEat(c,r));
  if(c.fd>0){const room=Math.max(0,1-(c.a+c.j)/r.cap);c.j+=c.a*r.b*room;const m=c.j*r.m;c.j-=m;c.a+=m}
  else{c.a-=c.a*r.d;c.j-=c.j*r.d*1.6}}}
const brAvail=c=>Math.floor(c.j)+Math.max(0,Math.floor(c.a)-6);
function brBuild(k){const mk=()=>{const c=document.createElement('canvas');c.width=192;c.height=108;const x=c.getContext('2d');x.imageSmoothingEnabled=false;return[c,x]};
 const [b,bx]=mk(),[f,fx]=mk(),cri=k==='cri';
 onCtx(bx,()=>{px(10,31,173,66,'rgba(190,220,232,.13)');px(10,31,173,12,'rgba(255,255,255,.08)');
  const sub=cri?['#a88a5a','#b9996a','#8f7347','#7d623b']:['#6b4226','#7d4e2d','#59341d','#8a5a35'];
  for(let X=10;X<183;X++){const top=64+Math.round(2*Math.sin(X*.13)+1.5*Math.sin(X*.31));for(let Y=top;Y<97;Y++){const v=bh(X,Y);px(X,Y,1,1,v<.12?sub[1]:v<.2?sub[2]:v<.24?sub[3]:sub[0])}}
  for(let L=0;L<6;L++){const y0=35+L*10.2|0,off=L%2?4:0;px(12,y0,84,9,'#7d6c58');px(12,y0,84,7,'#a8947a');px(12,y0,84,1,'#c3b098');
   for(let q=0;q<8;q++){const cx=14+off+q*10.4;if(cx>92)continue;ell(cx,y0+3,4.6,3,'#c3b098');ell(cx,y0+4,3,2,'#b09d84');px(cx-1,y0+6,3,2,'#3c2f24')}
   for(let i=0;i<14;i++)px(12+((bh(i,L+9)*83)|0),y0+((bh(i,L+3)*7)|0),1,1,'#8a7860')}
  px(95,35,2,62,'#6a5a48');px(12,35,1,62,'#c3b098');
  ell(148,92,33,6,'#6c6672');ell(148,91,31,4.8,'#8d8794');ell(148,91,28,3.6,'#4a4650')});
 onCtx(fx,()=>{px(6,28,181,3,'#bfb0ae');px(8,30,2,68,'#2b1c1c');px(183,30,2,68,'#2b1c1c');px(8,97,177,2,'#2b1c1c');
  px(12,33,3,60,'rgba(255,255,255,.55)');px(16,33,1,40,'rgba(255,255,255,.3)');px(175,33,2,58,'rgba(255,255,255,.35)');px(12,94,170,1,'rgba(255,255,255,.25)');
  for(let y=6;y<=24;y++){const e=Math.round((y-6)/18*10);px(14-e,y,164+e*2,1,y===6?'#1a1214':'#4b3f40')}
  px(2,24,189,6,'#3a2f31');px(2,24,189,1,'#1a1214');px(2,29,189,1,'#1a1214');px(4,25,185,1,'#5c4f50');
  for(let i=0;i<9;i++)for(const x0 of[24,120]){const X=x0+i*6;line(X+3,9,X,20,'#1c1213',2)}
  px(80,9,32,8,'#2e2425');px(82,11,28,4,'#1a1213')});
 return brSt[k]={b,f}}
function brSlice(cx,cy,r){const ry=r*.85;ell(cx+3,cy,r+1,ry+1,'#8a3d08');ell(cx+3,cy,r,ry,'#b4590e');ell(cx,cy,r+1,ry+1,'#8a3d08');ell(cx,cy,r,ry,'#ee8a1c');ell(cx,cy,r-1.5,ry-1.3,'#f8b552');ell(cx,cy,r*.5,ry*.5,'#f2a03a');px(cx,cy,1,1,'#fbd08a');px(cx-r+1,cy-2,1,2,'#fbd08a')}
function brDraw(tm){
 for(const k of BRKS)brSim(k);
 document.querySelectorAll('#brGrid canvas.brcv').forEach(cv=>{const k=cv.dataset.k,c=S.br[k],r=BR[k],B=brSt[k]||brBuild(k),x=cv.getContext('2d');x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false;x.clearRect(0,0,192,108);x.drawImage(B.b,0,0);
  onCtx(x,()=>{
   if(c){if(c.fd>0){const n=Math.min(5,Math.floor(c.fd/20)+1),R=[7,6.5,6,5.5,5],Y=[85,84,85,84,85];for(let i=n-1;i>=0;i--)brSlice(123+i*12.5,Y[i],R[i])}
    const N=Math.min(18,Math.ceil((c.a+c.j)/4)),ad=c.a/Math.max(1,c.a+c.j);
    for(let i=0;i<N;i++){const juv=i/N>=ad,s=r.sz*(juv?.62:1),sp=.3+bh(i,3)*.5,ph=bh(i,4)*6.28,u=tm*sp+ph,mv=Math.sin(u*1.7)>-.35;
     const on=i%2===0;let bx=on?20+bh(i,1)*64+Math.sin(u)*7:76+bh(i,1)*98+Math.sin(u)*9,by=on?46+bh(i,2)*34:78+bh(i,2)*12;const dir=Math.cos(u)>=0?1:-1;
     x.save();
     if(i<2&&N>6){const L=i===0;x.translate(L?15:178,Math.round(44+Math.sin(u*.7)*10));x.rotate(L?Math.PI/2:-Math.PI/2)}
     else x.translate(Math.round(bx),Math.round(by));
     x.scale(dir,1);if(k==='cri')cricketSide(0,0,s,tm+i,mv);else roachSide(0,0,s,tm+i,mv,k);x.restore()}}
   else px(2,6,189,93,'rgba(10,6,4,.5)')});
  x.drawImage(B.f,0,0)});
 if(tm-brK>.5){brK=tm;brRefresh()}}
function brRefresh(){document.querySelectorAll('#brGrid .brc').forEach(el=>{const k=el.dataset.k,r=BR[k],c=S.br[k],q=a=>el.querySelector(a);
  q('.brnm').textContent=t('p_'+k);q('.brbuy').hidden=!!c;q('.brinfo').hidden=!c;q('.brbuy span').textContent=t('br_buy')+' '+r.p;
  const st=q('.brst');if(!c){st.textContent=t('br_empty');return}
  st.textContent=t('br_adult')+' '+Math.floor(c.a)+' · '+t('br_juv')+' '+Math.floor(c.j)+' · '+t('br_stock')+' '+S.inv[k]+((c.fd<=0)?'  ⚠ '+t('br_starve'):'');
  q('.bf').textContent=t('br_food');
  const f1=q('.bar.f i');f1.style.width=c.fd+'%';f1.style.background=c.fd<25?'#b33a22':'#e8590c';
  q('[data-a=feed]').textContent='🥕 '+t('br_feed');
  const n=brAvail(c),tb=q('[data-a=take]');tb.textContent=t('br_take')+' ('+Math.min(10,Math.max(0,n))+')';tb.disabled=n<1})}
(()=>{const g=$('brGrid');g.innerHTML=BRKS.map(k=>`<div class="brc" data-k="${k}"><canvas class="brcv" width="192" height="108" data-k="${k}"></canvas><div class="plank"></div><div class="bcell"><b class="nm brnm"></b></div><div class="brst"></div>
<div class="brinfo"><div class="brb"><span class="bf"></span><div class="bar f"><i></i></div></div><div class="bcell brbt"><button data-a="feed"></button><button data-a="take"></button></div></div>
<div class="bcell brbuy"><button data-a="buy"><span></span><canvas class="cc" width="48" height="48"></canvas></button></div></div>`).join('');
 g.querySelectorAll('.cc').forEach(drawCoin);
 g.onclick=e=>{const b=e.target.closest('button[data-a]');if(!b)return;const k=b.closest('.brc').dataset.k,a=b.dataset.a,r=BR[k],c=S.br[k],m=$('shMsg');
  if(a==='buy'){if(c)return;if(S.coins<r.p){m.textContent=t('br_nocoin');return}S.coins-=r.p;S.br[k]={a:6,j:4,fd:100,wt:100,ts:Date.now()};m.textContent=t('br_bought')+t('p_'+k)}
  else if(!c)return;
  else if(a==='feed'){c.fd=100;m.textContent=t('br_fed')}
  else if(a==='water'){c.wt=100;m.textContent=t('br_wet')}
  else if(a==='take'){const n=Math.min(10,brAvail(c));if(n<1){m.textContent=t('br_few');return}const fj=Math.min(n,Math.floor(c.j));c.j-=fj;c.a-=n-fj;S.inv[k]=(S.inv[k]||0)+n;m.textContent=t('br_got')+n;try{stock()}catch(_){}}
  save();brRefresh()}})();
