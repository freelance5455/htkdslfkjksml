// Декор террариума: коряги/камни/растения, режим редактирования
/*DECOR-START*/
// коряга, вид сверху: тень на грунте, сучья, кора с бликом слева-сверху и трещинами
const SNG={tr:[[-23,3,5.2],[-14,-1,4.2],[-4,-2,3.6],[7,1,3.2],[16,3,2.5],[24,0,1.5]],
 br:[[[-5,-2,3],[-9,-9,2.2],[-13,-15,1.2]],[[8,1,2.8],[12,8,2],[15,15,1.1]],[[-15,-1,3.2],[-19,6,1.8]],[[-9,-9,2.2],[-4,-14,1.1]]]};
function drawSnag(cx,cy,s,a,sh){const co=Math.cos(a),si=Math.sin(a),T=(x,y)=>[cx+(x*co-y*si)*s,cy+(x*si+y*co)*s],chains=[SNG.tr,...SNG.br];
 const pass=(dx,dy,k,add,col)=>{for(const ch of chains)for(let i=0;i<ch.length-1;i++){const p=ch[i],q=ch[i+1],A=T(p[0],p[1]),B=T(q[0],q[1]);
   caps([A[0]+dx,A[1]+dy],[B[0]+dx,B[1]+dy],Math.max(.4,(p[2]*k+add)*s),Math.max(.4,(q[2]*k+add)*s),col)}};
 if(sh)pass(2.4*s,3.2*s,1,.3,'rgba(24,14,6,.26)');
 pass(0,0,1,.55,'#3d2a1a');pass(0,0,1,0,'#8a6a48');pass(.5*s,.6*s,.74,0,'#755638');pass(-.45*s,-.5*s,.55,0,'#b39166');pass(-.8*s,-.9*s,.22,0,'#dcc298');
 const tr=SNG.tr;for(let i=0;i<tr.length-1;i++){const p=tr[i],q=tr[i+1],A=T(p[0],p[1]),B=T(q[0],q[1]),dx=B[0]-A[0],dy=B[1]-A[1],L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;
  for(const o of[-.5,.15,.6]){if(hsh(i*7+o*13)<.25)continue;const r0=p[2]*s*o*.8,r1=q[2]*s*o*.8,t0=.12+hsh(i+o*9)*.2,t1=.7+hsh(i*3+o*5)*.25;
   caps([A[0]+dx*t0+nx*lerp(r0,r1,t0),A[1]+dy*t0+ny*lerp(r0,r1,t0)],[A[0]+dx*t1+nx*lerp(r0,r1,t1),A[1]+dy*t1+ny*lerp(r0,r1,t1)],.3*s,.3*s,'#5e4429')}}
 {const k=T(-9,1);caps(k,k,1.2*s,1.2*s,'#4a3220');caps(k,k,.65*s,.65*s,'#6a4c30')}
 {const e=T(24,0);caps(e,e,1.5*s,1.5*s,'#4a3220');caps(e,e,1.1*s,1.1*s,'#cfb07f');caps(e,e,.45*s,.45*s,'#8a6a48')}
 for(const ch of SNG.br){const q=ch[ch.length-1],e=T(q[0],q[1]);caps(e,e,q[2]*s*.9,q[2]*s*.9,'#cfb07f')}}
function drawStones(cx,cy,s,a,sh){const co=Math.cos(a),si=Math.sin(a),T=(x,y)=>[cx+(x*co-y*si)*s,cy+(x*si+y*co)*s],R=[[0,0,11,8,.5],[-13,8,6.5,5,-.4],[12,9,4.2,3.5,.9],[-4,-12,2.8,2.4,0]];
 const rk=(r,k,add,dx,dy,col)=>{const p=T(r[0],r[1]);rEll(p[0]+dx*s,p[1]+dy*s,Math.max(.6,(r[2]*k+add)*s),Math.max(.6,(r[3]*k+add)*s),a+r[4],col)};
 if(sh)for(const r of R)rk(r,1,.3,2.4,3.2,'rgba(24,14,6,.26)');
 for(const r of R){rk(r,1,.55,0,0,'#3a3835');rk(r,1,0,0,0,'#8b8782');rk(r,.78,0,.5,.6,'#6f6c67');rk(r,.6,0,-.5,-.5,'#b4b0a8');rk(r,.25,0,-.9,-.9,'#dedad0')}
 for(let j=0;j<12;j++){const u=(hsh(j*2.3)*2-1)*.8,v=(hsh(j*4.1+3)*2-1)*.7;if(u*u+v*v>.8)continue;const p=T(u*10,v*7);px(p[0],p[1],1,1,j%3?'#5e5b57':'#cdc9bf')}
 {const p=T(-4,-1),q=T(3,3);line(p[0],p[1],q[0],q[1],'#55524e')}}
function drawPlant(cx,cy,s,a,sh){const lf=(ang,len,w,base,lit,ox,oy,mode)=>{const ca=Math.cos(ang),sa=Math.sin(ang),A=[cx+ox+ca*2*s,cy+oy+sa*2*s],M=[cx+ox+ca*len*.5*s,cy+oy+sa*len*.5*s],B=[cx+ox+ca*len*s,cy+oy+sa*len*s];
  if(mode===0){caps(A,M,1.2*s,w*s,base);caps(M,B,w*s,.5*s,base);return}
  caps(A,M,1.2*s+.5,w*s+.5,'#1d4421');caps(M,B,w*s+.5,.6*s,'#1d4421');caps(A,M,1.2*s,w*s,base);caps(M,B,w*s,.5*s,base);
  caps([A[0]-.4*s,A[1]-.5*s],[M[0]-.4*s,M[1]-.5*s],.6*s,w*s*.55,lit);caps([M[0]-.4*s,M[1]-.5*s],[B[0]-.3*s,B[1]-.3*s],w*s*.55,.3*s,lit);
  caps([A[0]+ca*s,A[1]+sa*s],[B[0]-ca*s,B[1]-sa*s],.25*s,.15*s,'#b2e394')};
 const O=[],I=[];for(let i=0;i<9;i++)O.push([a+i*6.2832/9,15*(.88+hsh(i*3.3)*.24)]);for(let i=0;i<6;i++)I.push([a+.35+i*6.2832/6,9*(.9+hsh(i*5.1)*.2)]);
 if(sh)for(const l of O)lf(l[0],l[1],3.2,'rgba(24,14,6,.26)',0,2.4*s,3.2*s,0);
 for(const l of O)lf(l[0],l[1],3.2,'#3f8f3a','#6fb85a',0,0,1);
 for(const l of I)lf(l[0],l[1],2.4,'#4fa646','#86cf6c',0,0,1);
 caps([cx,cy],[cx,cy],2*s,2*s,'#2f6e2c');caps([cx-.3*s,cy-.4*s],[cx-.3*s,cy-.4*s],1.2*s,1.2*s,'#8fd070')}
function drawHut(cx,cy,s,a,sh){const R=13,co=Math.cos(a),si=Math.sin(a),T=(x,y)=>[cx+(x*co-y*si)*s,cy+(x*si+y*co)*s];
 if(sh)rEll(cx+2.4*s,cy+3.2*s,(R+.5)*s,(R+.5)*s,0,'rgba(24,14,6,.28)');
 rEll(cx,cy,(R+.6)*s,(R+.6)*s,0,'#2e1d10');rEll(cx,cy,R*s,R*s,0,'#5d3f26');rEll(cx-.8*s,cy-.9*s,R*.88*s,R*.88*s,0,'#7a5535');
 rEll(cx-2*s,cy-2.4*s,R*.55*s,R*.55*s,0,'#98714a');rEll(cx-3.6*s,cy-4*s,R*.22*s,R*.22*s,0,'#b98f60');
 for(let i=0;i<24;i++){const an=hsh(i*1.7)*6.2832,r0=R*(.2+.6*hsh(i*2.9+1)),L=2+hsh(i*3.7)*3,x0=cx+Math.cos(an)*r0*s,y0=cy+Math.sin(an)*r0*s;line(x0,y0,x0+Math.cos(an+.5)*L*s,y0+Math.sin(an+.5)*L*s,i%3?'#43301c':'#a67c52')}
 const E=T(R*.62,0);rEll(E[0],E[1],4.4*s,6.4*s,a,'#a07a52');rEll(E[0],E[1],3.6*s,5.6*s,a,'#120a05');rEll(E[0]-.5*s,E[1]-.6*s,2.2*s,3.4*s,a,'#2a180c')}
function drawLog(cx,cy,s,a,sh){const co=Math.cos(a),si=Math.sin(a),T=(x,y)=>[cx+(x*co-y*si)*s,cy+(x*si+y*co)*s],P=[[-22,2,9],[-4,-2,11],[14,1,11]];
 const pass=(dx,dy,add,k,col)=>{for(let i=0;i<2;i++){const A=T(P[i][0],P[i][1]),B=T(P[i+1][0],P[i+1][1]);caps([A[0]+dx*s,A[1]+dy*s],[B[0]+dx*s,B[1]+dy*s],(P[i][2]*k+add)*s,(P[i+1][2]*k+add)*s,col)}};
 if(sh)pass(2.4,3.2,.3,1,'rgba(24,14,6,.28)');
 {const A=T(-10,-9),B=T(-15,-18);if(sh)caps([A[0]+2.4*s,A[1]+3.2*s],[B[0]+2.4*s,B[1]+3.2*s],3.6*s,2.6*s,'rgba(24,14,6,.28)');caps(A,B,3.8*s,2.8*s,'#3d2a1a');caps(A,B,3.1*s,2.1*s,'#8a6a48');caps(B,B,1.6*s,1.6*s,'#cfb07f');caps(B,B,.7*s,.7*s,'#8a6a48')}
 pass(0,0,.8,1,'#3d2a1a');pass(0,0,0,1,'#8a6a48');pass(.6,.8,0,.75,'#755638');pass(-1.4,-2.4,0,.45,'#b39166');pass(-2.4,-4,0,.17,'#dcc298');
 for(let i=0;i<12;i++){const u=-20+hsh(i*3.1)*28,v=(hsh(i*5.3+2)*2-1)*7,L=3+hsh(i*7.7)*4,A=T(u,v),B=T(u+L,v+(hsh(i*1.9)-.5)*1.5);line(A[0],A[1],B[0],B[1],i%3?'#4a3220':'#a98558')}
 {const k=T(-12,3);caps(k,k,2.4*s,2.4*s,'#3d2a1a');caps(k,k,1.7*s,1.7*s,'#5e4429');caps(k,k,.8*s,.8*s,'#7a5a38')}
 for(const m of[[-16,-4,3.2,2],[-7,6,3.6,2.4],[-1,-8,2.6,1.8]]){const q=T(m[0],m[1]);rEll(q[0],q[1],m[2]*s,m[3]*s,a,'#4a7a34');rEll(q[0]-.5*s,q[1]-.5*s,m[2]*.6*s,m[3]*.6*s,a,'#7cae52')}
 const E=T(14.5,1);rEll(E[0],E[1],5.4*s,11.4*s,a,'#3d2a1a');rEll(E[0],E[1],4.7*s,10.6*s,a,'#cfb07f');rEll(E[0],E[1],3.9*s,9.1*s,a,'#a98558');
 rEll(E[0]+.3*s,E[1],3.2*s,8*s,a,'#120a05');rEll(E[0]-.3*s,E[1]-.6*s,1.8*s,4.6*s,a,'#2a180c')}
function drawShell(cx,cy,s,a,sh){const co=Math.cos(a),si=Math.sin(a),T=(x,y)=>[cx+(x*co-y*si)*s,cy+(x*si+y*co)*s];
 const E=(x,y,rx,ry,r,col)=>{const p=T(x,y);rEll(p[0],p[1],rx*s,ry*s,a+r,col)};
 if(sh)E(-3+2.4,3.2,20.5,16.5,0,'rgba(24,14,6,.28)');
 E(17.5,0,5.4,10.4,0,'#3d3318');E(17.8,0,4.4,9.2,0,'#120a05');E(17.4,-.4,2.4,5,0,'#2a180c');
 E(-3,0,21,17,0,'#3d3318');E(-3,0,20,16,0,'#6a5a2b');E(-3,0,17,13.2,0,'#7e6d34');E(-3,0,15.6,12,0,'#8c7b3e');
 for(let i=0;i<16;i++){const an=i*6.2832/16,c=Math.cos(an);if(c>.8)continue;const x=-3+18.4*c,y=14.8*Math.sin(an);E(x,y,3.2,2.7,an,'#3d3318');E(x,y,2.5,2,an,i%2?'#7a6a35':'#8a7a3e')}
 const sc=(x,y,rx,ry,r)=>{E(x,y,rx+.9,ry+.9,r,'#3d3318');E(x,y,rx,ry,r,'#9d8c4a');E(x+.6,y+.7,rx*.75,ry*.75,r,'#867638');E(x-.8,y-1,rx*.5,ry*.45,r,'#bfae66');E(x-1.2,y-1.4,rx*.2,ry*.18,r,'#e4d594')};
 for(const sg of[1,-1])for(const x of[-12,-4.5,3])sc(x,sg*9.4,3.7,3.9,sg*.25);
 for(const x of[-14.5,-7,.5,8])sc(x,0,3.9,5,0);
 E(-5,-3,9,5,0,'rgba(255,240,190,.08)')}
const DEC={stone:{f:drawStones,s:1.6,r:40},snag:{f:drawSnag,s:1.125,r:33},hut:{f:drawHut,s:1.7,r:24},log:{f:drawLog,s:1,r:22},shell:{f:drawShell,s:1,r:22},plant:{f:drawPlant,s:.8,r:16}},DK=['stone','snag','hut','log','shell','plant'],HIDES=['hut','log','shell'],PV={snag:[.8,.95],stone:[1,0],plant:[.8,0],hut:[.9,0],log:[.55,0],shell:[.5,0]},DPRICE=50,HPRICE=25,dprice=k=>HIDES.includes(k)?HPRICE:DPRICE;
let decEdit=false,dragO=null,decSel='snag';
const dsn=()=>S.dec[decSel],decKeys=()=>isMn(S.species)?MDK:DK,anyOn=()=>decKeys().some(k=>S.dec[k].on),defSel=()=>decKeys().find(q=>S.dec[q].on)||(isMn(S.species)?'mbr':'snag');
const DSPR={};
function decSprite(k,a){const key=a+'|'+DEC[k].s;let e=DSPR[k];if(!e||e.key!==key){const c=e&&e.c||document.createElement('canvas');c.width=c.height=128*SCALE;const x=c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,c.width,c.height);fixCtx(x);onCtx(x,()=>DEC[k].f(64,64,DEC[k].s,a,1));e=DSPR[k]={key,c}}return e.c}
function drawDecor(dec){const DD=dec||S.dec;for(const k of DK){const n=DD[k];if(n.on)g.drawImage(decSprite(k,n.a),Math.round(n.x)-64,Math.round(n.y)-64,128,128)}
 if(decEdit&&!dec){const k0=Math.floor(T*6);for(const k of DK){const n=S.dec[k];if(!n.on)continue;const R=DEC[k].r,sel=k===decSel;for(let i=0;i<28;i++)if(i%4===0)px(n.x+Math.cos(i/28*6.283)*R,n.y+Math.sin(i/28*6.283)*R,1,1,sel?'#ffe27a':'#ffffff')}}}
function decUI(){$('decBtn').hidden=!(anyOn()&&!decEdit);updRot();$('decBar').hidden=!decEdit;$('feed').hidden=decEdit;const d=$('dbg');if(d)d.hidden=decEdit;cv.style.touchAction=decEdit?'none':''}
function decEnd(){decEdit=false;dragO=null;save();decUI()}
const decPt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)/r.width*128,(e.clientY-r.top)/r.height*128]};
const mnAnch={mbr:[64,0],mvine:[24,0],morch:[0,33]};
const decMove=(x,y)=>{const n=dsn();
 if(isMn(S.species)){const L=MLIM[decSel];if(!L)return;const cl=v=>Math.max(L[0],Math.min(L[1],Math.round(v)));
  if(decSel==='morch'){n.x=0;n.y=cl(y+dragO[1])}else{n.y=0;n.x=cl(x+dragO[0])}return}
 n.x=Math.max(0,Math.min(128,x+dragO[0]));n.y=Math.max(0,Math.min(128,y+dragO[1]))};
// кнопка «повернуть» у богомола превращается в «отразить» (только для коряги); подсказка тоже своя
function updRot(){const mn=isMn(S.species),b=$('decRot'),h=document.querySelector('#decBar .sub');if(!b||!h)return;
 b.hidden=mn&&decSel!=='mbr';const k1=mn?'dec_flip':'dec_rot',k2=mn?'dec_hintM':'dec_hint';
 if(b.dataset.i!==k1){b.dataset.i=k1;b.textContent=t(k1)}if(h.dataset.i!==k2){h.dataset.i=k2;h.textContent=t(k2)}}
cv.addEventListener('pointerdown',e=>{if(!decEdit)return;e.preventDefault();const[x,y]=decPt(e),mn=isMn(S.species);let best=null,bd=1e9;
 for(const k of decKeys()){const n=S.dec[k];if(!n.on)continue;
  if(mn){const q=mnBox(k),p=3;if(x>=q[0]-p&&x<=q[2]+p&&y>=q[1]-p&&y<=q[3]+p){const ar=(q[2]-q[0])*(q[3]-q[1]);if(ar<bd){bd=ar;best=k}}}
  else{const d=Math.hypot(x-n.x,y-n.y);if(d<DEC[k].r&&d<bd){bd=d;best=k}}}
 if(best){decSel=best;const n=dsn();dragO=[n.x-x,n.y-y]}else{const an=mn&&mnAnch[decSel]||[0,0];dragO=mn?[-an[0],-an[1]]:[0,0]}
 decMove(x,y);updRot();try{cv.setPointerCapture(e.pointerId)}catch(_){}});
cv.addEventListener('pointermove',e=>{if(decEdit&&dragO){const[x,y]=decPt(e);decMove(x,y)}});
['pointerup','pointercancel'].forEach(ev=>cv.addEventListener(ev,()=>{if(dragO){dragO=null;save()}}));
$('decBtn').onclick=()=>{if(!S.dec[decSel]||!S.dec[decSel].on||!decKeys().includes(decSel))decSel=defSel();decEdit=true;decUI()};$('decOk').onclick=decEnd;
$('decRot').onclick=()=>{const n=dsn();if(isMn(S.species)){if(decSel==='mbr'){n.a=n.a?0:1;save()}return}n.a=(n.a+Math.PI/4)%(Math.PI*2);save()};
$('decDel').onclick=()=>{dsn().on=false;const k=decKeys().find(q=>S.dec[q].on);if(k){decSel=k;save();decUI()}else decEnd();refreshAcc()};
function decAct(k){const m=$('wMsg'),n=S.dec[k];
 if(!n.own){const pr=dprice(k);if(S.coins<pr){m.textContent=t(pr===HPRICE?'nocoin25':'nocoin50');return}S.coins-=pr;n.own=true;m.textContent=t('dec_got')}
 else{n.on=!n.on;m.textContent='';if(n.on)decSel=k}
 if(n.on&&HIDES.includes(k))for(const q of HIDES)if(q!==k)S.dec[q].on=false;
 save();refreshAcc();decUI()}
/*DECOR-END*/
