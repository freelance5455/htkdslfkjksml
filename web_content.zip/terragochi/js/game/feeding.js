// Логика кормления: выбор корма, очки сытости, запуск кормёжки
let SC=.7; // масштаб паука (позже будет расти с возрастом)
const sp={x:64,y:52},ab={rx:7,ry:7},ANG0=Math.PI,NT=8,DELTA=Math.PI/NT;
let walk=false,st='idle',tm=0,T=0,PH=0,prey=null,reach=0,chew=0,jaw=0,over=false,L0={x:64,y:52,a:0},LG={sx:0,sy:0,fx:0,fy:-1,th:0},ang=0,tn=0,am=1.5,fq=2.5,twitch=0,tgt={x:64,y:20},fx=[];
const ease=x=>x<=0?0:x>=1?1:x*x*(3-2*x),lerp=(a,b,k)=>a+(b-a)*k;
// точка тела (X,Y относительно центра головогруди) -> мир, поворот вокруг центра тела
const Q=(a,X,Y)=>{const c=Math.cos(a),s=Math.sin(a),dy=(Y-12)*SC,x=X*SC;return[sp.x+x*c-dy*s,sp.y+12+x*s+dy*c]};
const P=(X,Y)=>Q(ang,X,Y);
function aimAt(dt,spd,o){const px=sp.x,py=sp.y+12;let d=Math.atan2(o.x-px,-(o.y-py))-ang;d=Math.atan2(Math.sin(d),Math.cos(d));const s=Math.max(-spd*dt,Math.min(spd*dt,d));ang=Math.max(-1.3,Math.min(1.3,ang+s));return d-s}
let msgK='m_hungry';function setMsg(k){msgK=k;$('msg').textContent=t(k)}
function go(s,m){st=s;tm=0;setMsg(m);$('feed').disabled=s!=='idle'}
$('feed').onclick=()=>{if(st==='idle'&&!inPre())openSel()};

/* ---- размеры добычи и 4 стадии сытости ---- */
let feedK='cri';
const feedTier=sp=>{if(!isSpd(sp))return 3;const L=(S.d[sp]&&S.d[sp].L)||6;return L<9?1:L<11?2:3};
function feedMul(k,sp){if(k==='mou'||!isSpd(sp))return 1;const T=feedTier(sp);if(T===1)return k==='cri'?1:0;if(T===2)return k==='turk'?1:k==='cri'?.5:0;return k==='arg'?1:k==='turk'?.5:.25}
const feedPts=()=>25*feedMul(feedK,S.species);
function fxLbl(b){let f=b.querySelector('.fx');if(!f){f=document.createElement('small');f.className='fx';f.style.cssText='display:block;font-size:12px;opacity:.8';b.appendChild(f)}const m=feedMul(b.dataset.k,S.species);f.textContent=m<=0?t('fd_no'):'+'+25*m+'%'}
function selHintSet(){let h=$('selHint');if(!h){$('cells').insertAdjacentHTML('beforebegin','<p class="sub" id="selHint" style="margin:8px 0 0"></p>');h=$('selHint')}h.textContent=isSpd(S.species)?t('fd_h'+feedTier(S.species)):''}
function openSel(){CELLS.forEach(b=>{const n=S.inv[b.dataset.k];b.querySelector('span').textContent=n;const ok=feedMul(b.dataset.k,S.species)>0;b.disabled=n<1;b.hidden=!ok||isSn(S.species)!==(b.dataset.k==='mou');fxLbl(b)});selHintSet();const e=$('sel');clearTimeout(selT);e.classList.remove('sOut','sIn');e.hidden=false;void e.offsetWidth;e.classList.add('sIn');selT=setTimeout(()=>e.classList.remove('sIn'),350)}
let selT=0;
function closeSel(fast){const e=$('sel');clearTimeout(selT);if(fast){e.hidden=true;e.classList.remove('sIn','sOut');return}e.classList.remove('sIn');e.classList.add('sOut');selT=setTimeout(()=>{e.hidden=true;e.classList.remove('sOut')},310)}
function startFeed(k){if(st!=='idle'||S.inv[k]<1||isSn(S.species)!==(k==='mou')||feedMul(k,S.species)<=0)return;feedK=k;if(k==='mou')return startFeedS(k);S.inv[k]--;closeSel();over=D.sat>=75;
 prey={k,x:30+Math.random()*68,y:-8,p:0,tx:24+Math.random()*80,ty:14+Math.random()*14};if(isSc(S.species))Object.assign(prey,scPrey0());if(isMn(S.species))Object.assign(prey,{x:-6,y:mnBY(-6)-2,tx:82-28*stageF(D),stops:[10,26,40],si:0,pause:0,mv:true});save();go('approach',INS[k].go)}
cv.addEventListener('pointerdown',()=>{if(!decEdit&&st==='idle'){D.mood=Math.max(0,D.mood-3);twitch=.5;setMsg(isSn(S.species)?'m_tws':'m_tw')}});

