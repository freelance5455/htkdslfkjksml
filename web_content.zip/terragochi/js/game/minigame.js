// Мини-игра «лови насекомых»
// мини-игра: насекомые бегут вниз, нужно успеть тапнуть
const MG={st:'ready',time:30,el:0,score:0,combo:0,missed:0,coins:0,rec:false,bugs:[],fx:[],spawn:0,cv:$('mc')};
MG.ctx=MG.cv.getContext('2d');MG.ctx.imageSmoothingEnabled=false;
const MGT={turk:{sp:40,pts:1,rad:8},arg:{sp:52,pts:3,rad:10,hp:2},cri:{sp:84,pts:3,rad:8},was:{sp:56,pts:-5,rad:10}};
const DG={'0':'111101101101111','1':'010110010010111','2':'111001111100111','3':'111001111001111','4':'101101111001001','5':'111100111001111','6':'111100111101111','7':'111001001001001','8':'111101111101111','9':'111101111001111','+':'000010111010000','-':'000000111000000','x':'101101010101101'};
function pxText(str,x,y,c){const bits=[];[...str].forEach((ch,i)=>{const gl=DG[ch];if(gl)for(let k=0;k<15;k++)if(gl[k]==='1')bits.push([x+i*4+k%3,y+Math.floor(k/3)])});
 for(const b of bits)for(const o of[[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,1],[-1,1],[1,-1]])px(b[0]+o[0],b[1]+o[1],1,1,'#2a1a14');
 for(const b of bits)px(b[0],b[1],1,1,c)}
function mgUI(){const m=$('mgMsg');
 m.textContent=MG.st==='over'?t('mg_end')+MG.score+t('mg_coins')+MG.coins+(MG.rec?t('mg_rec'):'')+' · '+t('mg_esc')+MG.missed:t('mg_hint');
 const b=$('mgBtn');b.hidden=MG.st==='run';b.textContent=t(MG.st==='over'?'mg_again':'mg_start')}
function mgReset(){MG.st='ready';MG.time=30;MG.el=0;MG.score=0;MG.combo=0;MG.missed=0;MG.bugs=[];MG.fx=[];MG.spawn=.3;mgUI()}
function mgStop(){MG.st='ready';MG.bugs=[];MG.fx=[]}
function mgEnd(){qMg();MG.st='over';MG.bugs=[];MG.coins=Math.min(25,Math.floor(MG.score/4));S.coins+=MG.coins;MG.rec=MG.score>S.mgBest;if(MG.rec)S.mgBest=MG.score;save();mgUI()}
$('mgBtn').onclick=()=>{mgReset();MG.st='run';mgUI()};
const mgMult=()=>Math.min(3,1+Math.floor(MG.combo/5));
const mgPen=(x,y,n)=>{MG.score=Math.max(0,MG.score-n);MG.combo=0;MG.fx.push({x,y,a:0,txt:'-'+n,bad:1})};
MG.cv.addEventListener('pointerdown',e=>{if(MG.st!=='run')return;e.preventDefault();
 const r=MG.cv.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*128,y=(e.clientY-r.top)/r.height*128;let bi=-1,bd=1e9;
 MG.bugs.forEach((b,i)=>{const d=Math.hypot(b.x-x,b.y-y);if(d<MGT[b.k].rad&&d<bd){bd=d;bi=i}});
 if(bi<0){mgPen(x,y,1);return}
 const b=MG.bugs[bi];
 if(b.k==='was'){MG.bugs.splice(bi,1);mgPen(b.x,b.y,5);return}
 if(--b.hp>0){b.fl=.25;MG.fx.push({x:b.x,y:b.y,a:0,txt:'',sm:1});return}
 MG.bugs.splice(bi,1);MG.combo++;const pt=MGT[b.k].pts*mgMult();MG.score+=pt;MG.fx.push({x:b.x,y:b.y,a:0,txt:'+'+pt})});
function drawWasp(x,y,t){x=Math.round(x);y=Math.round(y);const fl=Math.sin(t*50)>0?1:0,bk='#1a120a',yl='#f2c12e';
 for(const s of[-1,1]){ell(x+s*5,y-2-fl,4,2+fl,'#bfe0ee');ell(x+s*5,y-2-fl,3,1+fl,'#eef8fc');line(x+s*2,y+1,x+s*5,y+5+fl,bk);line(x+s*2,y+3,x+s*4,y+7,bk)}
 ell(x,y-5,3,5,yl);px(x-3,y-6,7,1,bk);px(x-2,y-3,5,1,bk);px(x-1,y-9,3,1,bk);px(x,y-12,1,3,bk);
 ell(x,y+1,3,3,bk);ell(x,y+5,2,2,yl);px(x-2,y+5,1,1,'#c0281c');px(x+2,y+5,1,1,'#c0281c')}
function mgTick(dt){
 if(MG.st==='run'){MG.time-=dt;MG.el+=dt;const prog=Math.min(1,MG.el/30);MG.spawn-=dt;
  if(MG.spawn<=0&&MG.bugs.length<12){MG.spawn=lerp(.8,.3,prog)*(.8+Math.random()*.4);const r=Math.random()*100,nw=MG.bugs.filter(b=>b.k==='was').length,wp=prog>.1&&nw<3?12+prog*14:0,k=r<wp?'was':r<wp+(100-wp)*.42?'turk':r<wp+(100-wp)*.7?'arg':'cri';
   MG.bugs.push({k,x:14+Math.random()*100,y:-14,t:Math.random()*5,ph:Math.random()*6,hp:MGT[k].hp||1,fl:0,v:MGT[k].sp*(1+prog*.7)*(.85+Math.random()*.3)})}
  for(const b of MG.bugs){b.t+=dt;b.fl=Math.max(0,b.fl-dt);let v=b.v;
   if(b.k==='cri'){v*=1+.7*Math.max(0,Math.sin(b.t*3+b.ph));b.x=Math.max(8,Math.min(120,b.x+Math.sin(b.t*5+b.ph)*52*dt))}
   else if(b.k==='was')b.x=Math.max(8,Math.min(120,b.x+Math.sin(b.t*3.4+b.ph)*46*dt));
   b.y+=v*dt}
  let esc=0;MG.bugs=MG.bugs.filter(b=>{const ok=b.y<142;if(!ok&&b.k!=='was')esc++;return ok});
  if(esc){MG.missed+=esc;MG.score=Math.max(0,MG.score-esc);MG.combo=0}
  if(MG.time<=0)mgEnd()}
 for(const f of MG.fx)f.a+=dt;MG.fx=MG.fx.filter(f=>f.a<.65);
 onCtx(MG.ctx,()=>{drawBg(g,'sand');
  MG.bugs.slice().sort((a,b)=>a.y-b.y).forEach(b=>{if(b.k==='was'){drawWasp(b.x,b.y,b.t);return}drawBug(b.k,b.x,b.y,b.t);
   if(b.fl>0)for(let i=0;i<10;i++){const an=i/10*6.283+b.t*8;px(b.x+Math.cos(an)*11,b.y+Math.sin(an)*11,1,1,'#fff3c0')}
   else if(b.hp<(MGT[b.k].hp||1))line(Math.round(b.x)-3,Math.round(b.y)-4,Math.round(b.x)+2,Math.round(b.y)+1,'#d8c8a8')});
  for(const f of MG.fx){if(f.a<.35){const r=2+f.a*(f.sm?16:34),n=f.sm?8:12;for(let i=0;i<n;i++){const an=i/n*6.283;px(f.x+Math.cos(an)*r,f.y+Math.sin(an)*r,1,1,f.bad?'#ff5a4a':f.sm?'#fff':'#ffe27a')}}
   if(f.txt)pxText(f.txt,Math.round(f.x-f.txt.length*2),Math.round(f.y-8-f.a*22),f.bad?'#ff8a7a':'#fff3c0')}});
 $('mgS').textContent=MG.score;$('mgC').textContent='x'+mgMult();$('mgT').textContent=Math.max(0,Math.ceil(MG.time))}
