// Достижения: проверка условий и выдача монет (без рисования; всплывашку и экран рисует js/ui/achievements.js)
// Выданные достижения лежат в S.ach = {id: время}; они сохраняются вместе с игрой и не отбираются.
S.ach=S.ach||{};
const ACH_STAT={
 eaten:()=>Object.values(S.d).reduce((a,d)=>a+(d.eaten||0),0),
 molts:()=>Object.keys(S.d).reduce((a,k)=>{const d=S.d[k];return a+Math.max((d.molt&&d.molt.n)||0,isSpd(k)?Math.max(0,(d.L||6)-6):0)},0),
 pets:()=>Object.keys(S.own).filter(k=>S.own[k]).length,
 mg:()=>S.mgBest||0,
 streak:()=>(S.daily&&S.daily.streak)||0,
 // виды (без дублей «#2…»), богомол, змеи
 species:()=>new Set(Object.keys(S.own).filter(k=>S.own[k]).map(bs)).size,
 mantis:()=>S.own.mantis?1:0,
 snake:()=>Object.keys(S.own).some(k=>S.own[k]&&['corn','boa','ball'].includes(bs(k)))?1:0,
 mood:()=>Math.max(0,...Object.keys(S.own).filter(k=>S.own[k]&&S.d[k]).map(k=>Math.round(S.d[k].mood||0))),
 // инкубатор: вылупилось всего (S.inc.hat), стаканчиков занято сейчас, продано (S.inc.sold)
 hatched:()=>(S.inc&&S.inc.hat)||0,
 cups:()=>S.inc&&S.inc.cups?S.inc.cups.filter(Boolean).length:0,
 sold:()=>(S.inc&&S.inc.sold)||0,
 // фермы кормовых и декор (лучший по числу купленных предметов питомец)
 colonies:()=>Object.keys(S.br||{}).filter(k=>S.br[k]).length,
 decor:()=>Math.max(0,...Object.keys(S.d).map(k=>Object.keys(S.d[k].decOwn||{}).filter(q=>S.d[k].decOwn[q]).length)),
 coins:()=>Math.floor(S.coins||0)};
function achCheck(){let n=0;
 for(const a of ACH){if(S.ach[a.id]||ACH_STAT[a.stat]()<a.need)continue;
  S.ach[a.id]=Date.now();S.coins+=a.coins;n++;try{achToast(a)}catch(e){}}
 if(n)save();return n}
// проверяем раз в секунду (дёшево: пара сложений); первая проверка — через 1.5 с после старта
setTimeout(()=>{achCheck();setInterval(achCheck,1000)},1500);
