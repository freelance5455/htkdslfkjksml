// Инкубатор: правила. Кокон → вылупление → общий контейнер → рассадка по стаканчикам → кормление и увлажнение.
// Без рисования (экран — js/ui/incubator.js). Все числа для настройки — в блоке INC ниже.
const INC={
 cups:12,         // сколько стаканчиков (мест для рассадки) в начале игры
 cupStep:4,       // сколько стаканчиков даёт одна покупка
 cupPrice:5,      // цена одной покупки, монет
 cupMax:80,       // больше стаканчиков купить нельзя
 maxCo:6,         // сколько коконов может быть в игре одновременно (два контейнера по 3)
 maxEg:4,         // сколько кладок яиц змей одновременно: у яиц свои контейнеры, одна кладка = один контейнер
 egHatch:{corn:30*3600,ball:36*3600}, // время до вылупления яиц по видам, секунд (если вида нет в списке — 36 часов)
 hatch:24*3600,   // время до вылупления кокона, секунд
 fdDrop:100/(12*3600), // сытость: с 100% до 0 за 12 часов
 wtDrop:100/(18*3600), // влажность: с 100% до 0 за 18 часов
 die:6*3600,      // сколько секунд можно прожить с нулевой сытостью или влажностью, потом паучок погибает
 eat:20*60,       // пока паучки сидят вместе: раз в столько секунд один съедает другого
 offMax:3*24*3600, // сколько времени «пока вас не было» засчитывать, максимум
 sell:{base:5,perDay:2,max:40} // цена паучка: основа + за каждый день возраста, не больше max
};
S.inc=S.inc||{};{const I=S.inc;I.co=Array.isArray(I.co)?I.co:[];I.eg=Array.isArray(I.eg)?I.eg:[];I.cr=Array.isArray(I.cr)?I.cr:[];
 I.cups=Array.isArray(I.cups)?I.cups:[];while(I.cups.length<INC.cups)I.cups.push(null);I.id=I.id||1;I.eatT=I.eatT||0;I.ts=I.ts||Date.now()}
const incCrowd=()=>S.inc.cr.reduce((a,g)=>a+g.n,0);
const incFree=()=>S.inc.cups.filter(c=>!c).length;
// новый кокон: sp — вид, n — сколько паучков вылупится, t — через сколько секунд
const incCoFull=()=>S.inc.co.length>=INC.maxCo;
// возвращает false, если мест для кокона нет
// яйца змей: свои контейнеры (S.inc.eg), одна кладка = один контейнер. n — сколько яиц, t0 — через сколько секунд вылупятся (по умолчанию INC.egHatch)
const incEgFull=()=>S.inc.eg.length>=INC.maxEg;
function incAddEggs(sp,n,t0){const I=S.inc;if(I.eg.length>=INC.maxEg)return false;const c=t0==null?(INC.egHatch[bs(sp)]||36*3600):t0;I.eg.push({id:I.id++,sp,n,t:c,c});return true}
function incAddCocoon(sp,n,t0){const I=S.inc;if(I.co.length>=INC.maxCo)return false;I.co.push({id:I.id++,sp,n,t:t0==null?INC.hatch:t0,c:INC.hatch});return true}
// один шаг времени (dt секунд)
function incStep(dt){const I=S.inc;
 for(const c of I.co)c.t-=dt;
 for(const c of I.eg)c.t-=dt;
 const done=I.co.filter(c=>c.t<=0);
 if(done.length){I.co=I.co.filter(c=>c.t>0);for(const c of done){const g=I.cr.find(q=>q.sp===c.sp);if(g)g.n+=c.n;else I.cr.push({sp:c.sp,n:c.n})}
  const hn=done.reduce((a,c)=>a+c.n,0);I.hat=(I.hat||0)+hn;incEv.push(['hatch',hn])}
 // яйца змей: вылупились → змейки в общий контейнер
 const doneE=I.eg.filter(c=>c.t<=0);
 if(doneE.length){I.eg=I.eg.filter(c=>c.t>0);for(const c of doneE){const g=I.cr.find(q=>q.sp===c.sp);if(g)g.n+=c.n;else I.cr.push({sp:c.sp,n:c.n})}
  const hn=doneE.reduce((a,c)=>a+c.n,0);I.hat=(I.hat||0)+hn;incEv.push(['hatchS',hn])}
 // тесно вместе — паучки съедают друг друга (змейки друг друга не едят)
 const spN=()=>I.cr.reduce((a,g)=>a+(isSnB(g.sp)?0:g.n),0);
 if(spN()>1){I.eatT+=dt;while(I.eatT>=INC.eat&&spN()>1){I.eatT-=INC.eat;const g=I.cr.filter(q=>!isSnB(q.sp)).reduce((a,b)=>b.n>a.n?b:a);g.n--;incEv.push(['eaten',1])}
  I.cr=I.cr.filter(g=>g.n>0)}else I.eatT=0;
 I.cups.forEach((c,i)=>{if(!c)return;c.age=(c.age||0)+dt;c.fd=Math.max(0,c.fd-dt*INC.fdDrop);c.wt=Math.max(0,c.wt-dt*INC.wtDrop);
  if(c.fd<=0||c.wt<=0){c.z=(c.z||0)+dt;if(c.z>=INC.die){I.cups[i]=null;incEv.push(['died',1])}}else c.z=Math.max(0,(c.z||0)-dt)})}
// события, которые случились при расчёте (экран/уведомления их забирают)
let incEv=[];
// прокрутить время вперёд на sec секунд (кусочками, чтобы вылупление посреди срока считалось честно)
function incSim(sec){let left=Math.max(0,sec);while(left>0){const d=Math.min(left,300);incStep(d);left-=d}}
// вызывается каждый кадр: сверяет часы и досчитывает прошедшее время (в том числе пока игра была закрыта)
function incTick(){const I=S.inc,now=Date.now(),e=(now-I.ts)/1000;if(e<1)return;I.ts=now;incSim(Math.min(e,INC.offMax));incNotify()}
function incNotify(){if(!incEv.length)return;const ev=incEv;incEv=[];let h=0,hs=0,d=0;for(const[k,n]of ev){if(k==='hatch')h+=n;else if(k==='hatchS')hs+=n;else if(k==='died')d+=n}
 if(h)mToast(t('inc_hatched')+h);else if(hs)mToast(t('inc_hatched_sn')+hs);else if(d)mToast(t('inc_died'));
 save();try{incUI()}catch(_){}}
// действия игрока
function incSeat(all){const I=S.inc;let n=0;
 while(incCrowd()>0&&incFree()>0){const g=I.cr[0],i=I.cups.findIndex(c=>!c);I.cups[i]={sp:g.sp,fd:100,wt:100,z:0,age:0};g.n--;if(g.n<=0)I.cr.shift();n++;if(!all)break}
 save();return n}
// покупка стаканчиков: 'ok' / 'coins' (не хватает монет) / 'max' (достигнут предел)
function incBuyCups(){const I=S.inc;if(I.cups.length>=INC.cupMax)return'max';if(S.coins<INC.cupPrice)return'coins';
 S.coins-=INC.cupPrice;const n=Math.min(INC.cupStep,INC.cupMax-I.cups.length);for(let i=0;i<n;i++)I.cups.push(null);save();return'ok'}
function incFeed(i){const c=S.inc.cups[i];if(!c)return;c.fd=100;save()}
function incWater(i){const c=S.inc.cups[i];if(!c)return;c.wt=100;save()}
function incFeedAll(){S.inc.cups.forEach(c=>{if(c)c.fd=100});save()}
function incWaterAll(){S.inc.cups.forEach(c=>{if(c)c.wt=100});save()}
// продажа: цена зависит от возраста; вес/цена для малька из общего контейнера — базовая
const incPrice=age=>Math.min(INC.sell.max,Math.round(INC.sell.base+INC.sell.perDay*(age||0)/86400));
function incSell(i){const c=S.inc.cups[i];if(!c)return 0;const p=incPrice(c.age);S.inc.cups[i]=null;S.coins+=p;S.inc.sold=(S.inc.sold||0)+1;save();return p}
function incSellCrowd(){const I=S.inc;if(!I.cr.length)return 0;const g=I.cr[0];g.n--;if(g.n<=0)I.cr.shift();const p=incPrice(0);S.coins+=p;I.sold=(I.sold||0)+1;save();return p}
