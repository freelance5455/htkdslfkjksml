// Модель сохранения S: виды, инвентарь, монеты, миграции старых сохранений
// несколько питомцев одного вида: ключи вида «boehmei», «boehmei#2» … «boehmei#5»
const bs=k=>String(k).split('#')[0],MAXP=5;
const slotsOf=b=>[b,...[2,3,4,5].map(n=>b+'#'+n)];
const ownN=b=>slotsOf(b).filter(q=>S.own&&S.own[q]).length;
const freeSlot=b=>slotsOf(b).find(q=>!(S.own&&S.own[q]));
const mk=()=>({sat:0,mood:50,eaten:0});
const isSpd=k=>!['corn','boa','ball','mantis'].includes(bs(k)),isSc=k=>bs(k)==='scorpion3',TS=1/72;let S={species:'boehmei',d:{boehmei:mk(),albo:mk(),hamori:mk(),murinus:mk(),muticus:mk(),scorpion3:mk(),mantis:mk(),corn:mk(),boa:mk(),ball:mk()},own:{boehmei:true},coins:999,inv:{turk:0,arg:0,cri:0,mou:0},ts:Date.now()};
try{let j=JSON.parse(localStorage.getItem('spiderTama2')||'null');if(j){
 if(!j.d){const k=j.species||'boehmei';j={species:k,d:{[k]:{sat:j.sat,mood:j.mood,eaten:j.eaten}},ts:j.ts}}
 S=j;S.d.boehmei=S.d.boehmei||mk();S.d.albo=S.d.albo||mk();S.d.hamori=S.d.hamori||mk();S.d.murinus=S.d.murinus||mk();S.d.muticus=S.d.muticus||mk();S.d.scorpion3=S.d.scorpion3||mk();S.d.mantis=S.d.mantis||mk();S.d.corn=S.d.corn||mk();S.d.boa=S.d.boa||mk();S.d.ball=S.d.ball||mk();
 const eF=Math.max(0,(Date.now()-(j.ts||Date.now()))/1000),e=Math.min(eF,21600);window.OFFS=e;window.OFFF=eF;for(const k in S.d){const d=S.d[k],sp=isSpd(k),f=sp?TS*(d.molt&&d.molt.ph==='pre'?.1:1):1,ee=sp?Math.min(eF,259200):e;d.sat=Math.max(0,d.sat-ee*.04*f);d.mood=Math.min(100,Math.max(0,d.mood-ee*.02*f+((d.dec&&['hut','log','shell'].some(q=>d.dec[q]&&d.dec[q].on))?ee*.1*f:0)))}}}catch(e){}
S.species=S.species||'boehmei';
if(typeof S.coins!=='number')S.coins=999;S.inv=S.inv||{};for(const k of['turk','arg','cri','mou'])S.inv[k]=S.inv[k]||0;
// удалённые виды (чёрный и старый императорский скорпионы): вычищаем из старых сохранений вместе с копиями «#2…»
{const rm=k=>bs(k)==='scorpion'||bs(k)==='scorpion2';
 if(S.d&&typeof S.d==='object')for(const k of Object.keys(S.d))if(rm(k))delete S.d[k];
 if(S.own&&typeof S.own==='object')for(const k of Object.keys(S.own))if(rm(k))delete S.own[k];
 if(Array.isArray(S.order))S.order=S.order.filter(k=>!rm(k));
 if(rm(S.species))S.species='boehmei';
 if(S.own&&typeof S.own==='object'&&!Object.keys(S.own).some(k=>S.own[k])){S.own.boehmei=true;S.species='boehmei';S.d=S.d||{};S.d.boehmei=S.d.boehmei||mk()}}
if(!S.own){S.own={boehmei:true};for(const k in S.d)if(S.d[k].eaten>0)S.own[k]=true}if(!S.own[S.species]){const o0=Object.keys(S.own).find(q=>S.own[q]);if(o0)S.species=o0}
// защита от битых/старых сохранений: у каждого питомца из own и у текущего вида обязана быть запись в S.d, числа — конечные
if(!S.d||typeof S.d!=='object')S.d={};
if(typeof S.own!=='object'||!S.own)S.own={boehmei:true};
for(const k in S.own)if(S.own[k]&&!S.d[k])S.d[k]=mk();
if(!S.d[S.species])S.species=Object.keys(S.d).find(q=>S.own[q])||'boehmei';
if(!S.d[S.species])S.d[S.species]=mk();
for(const k in S.d){const d=S.d[k];if(!d||typeof d!=='object'){S.d[k]=mk();continue}if(!isFinite(d.sat))d.sat=0;if(!isFinite(d.mood))d.mood=50;if(!isFinite(d.eaten))d.eaten=0}
S.daily=S.daily&&typeof S.daily.last==='string'?S.daily:{last:'',streak:0};S.mgBest=S.mgBest||0;const DEFD={snag:[92,98,.5],stone:[36,94,.3],plant:[104,26,0],hut:[34,40,0],log:[92,40,.3],shell:[40,92,0],mbr:[0,0,0],mvine:[0,0,0],morch:[0,0,0]};S.bgOwn=S.bgOwn||{};
// покупки общие (склад), а расстановка декора и фон у каждого питомца свои
// покупки у каждого питомца свои (d.decOwn / d.bgOwn), расстановка и фон тоже
{const od=S.dec,ob=S.bg,gDec=Object.assign({},S.decOwn||{}),gBg=Object.assign({},S.bgOwn);
 if(od)for(const k in od)if(od[k]&&od[k].own)gDec[k]=true;
 if(!S.v3){for(const k in S.d){S.d[k].decOwn=Object.assign({},gDec);S.d[k].bgOwn=Object.assign({},gBg)}S.v3=1}
 const mkDec=(src,d)=>{const o={};for(const k in DEFD){const v=Object.assign({on:false,x:DEFD[k][0],y:DEFD[k][1],a:DEFD[k][2]},src&&src[k]||{});delete v.own;o[k]=v;Object.defineProperty(v,'own',{get(){return !!d.decOwn[k]},set(b){d.decOwn[k]=!!b},enumerable:false,configurable:true})}return o};
 for(const k in S.d){const d=S.d[k];d.decOwn=d.decOwn||{};d.bgOwn=d.bgOwn||{};d.bgOwn.soil=true;if(['corn','boa','ball'].includes(bs(k))){d.bgOwn.snk=true;if(!S.v4&&(!d.bg||d.bg==='soil'))d.bg='snk'}d.dec=mkDec(d.dec||od,d);
  for(const q in d.dec)if(d.dec[q].on)d.decOwn[q]=true;
  if(!(BKS.includes(d.bg)||d.bg==='snk')||!d.bgOwn[d.bg])d.bg='soil'}
 S.v4=1;
 delete S.dec;delete S.bg;delete S.decOwn;delete S.bgOwn;
 Object.defineProperty(S,'dec',{get(){return S.d[S.species].dec},enumerable:false,configurable:true});
 Object.defineProperty(S,'bg',{get(){return S.d[S.species].bg},set(v){S.d[S.species].bg=v},enumerable:false,configurable:true});
 Object.defineProperty(S,'bgOwn',{get(){return S.d[S.species].bgOwn},enumerable:false,configurable:true});
 Object.defineProperty(S,'decOwn',{get(){return S.d[S.species].decOwn},enumerable:false,configurable:true});
 S.mkDec=mkDec}
let D=S.d[S.species];
