// Заработок: ежедневный бонус и задания дня
// ---------- заработок: ежедневный бонус и мини-игра ----------
const DAILY=[10,15,20,25,30,40,60];
const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
function dailyInfo(){const now=new Date(),today=ymd(now),y=new Date(now);y.setDate(y.getDate()-1);const d=S.daily,can=d.last!==today,ns=can?(d.last===ymd(y)?d.streak+1:1):d.streak,idx=((ns-1)%7+7)%7;return{can,ns,idx,reward:DAILY[idx],today}}
function updEarn(){$('mEarnS').textContent=dailyInfo().can?t('e_ready'):''}
function renderEarn(){const d=dailyInfo();
 $('dInfo').textContent=(d.can?t('d_ready')+d.reward:t('d_done'))+(S.daily.streak>0?' · '+t('d_streak')+S.daily.streak:'');
 $('dStrip').innerHTML=DAILY.map((v,i)=>`<div class="${i<d.idx||(!d.can&&i===d.idx)?'done':''} ${i===d.idx?'cur':''}"><small>${t('day')} ${i+1}</small>${v}</div>`).join('');
 $('dClaim').disabled=!d.can;$('dClaim').textContent=t(d.can?'d_claim':'d_wait');$('mgBest').textContent=t('mg_best')+S.mgBest;renderQ()}
$('dClaim').onclick=()=>{const d=dailyInfo();if(!d.can)return;S.daily={last:d.today,streak:d.ns};S.coins+=d.reward;save();renderEarn();updEarn();$('eMsg').textContent=t('d_got')+d.reward};

/* ---- ежедневные задания ---- */
const QR=[15,10,10],QBONUS=15;
const eatenTot=()=>Object.values(S.d).reduce((a,x)=>a+(x.eaten||0),0);
function qInit(){const today=ymd(new Date());if(!S.q||S.q.day!==today)S.q={day:today,base:eatenTot(),mg:0,got:[false,false,false],bonus:false}}
function qMg(){try{qInit();S.q.mg++;save()}catch(e){}}
function qProg(){qInit();const q=S.q,pm=S.d[S.species]||{mood:0};return[Math.min(3,Math.max(0,eatenTot()-q.base)),Math.min(1,q.mg),pm.mood>=80?1:0]}
function renderQ(){const el=$('qList');if(!el)return;const P=qProg(),N=[3,1,1],K=['q_feed','q_mg','q_mood'];
 let h=K.map((k,i)=>{const ok=P[i]>=N[i],got=S.q.got[i];return `<div class="qrow${got?' got':''}"><span>${t(k)}${N[i]>1?` <small>${P[i]}/${N[i]}</small>`:''}</span><button data-q="${i}"${ok&&!got?'':' disabled'}>${got?t('q_done'):t('q_take')+' +'+QR[i]}</button></div>`}).join('');
 if(S.q.got.every(Boolean))h+=`<p class="qb">${t('q_all')} +${QBONUS}${S.q.bonus?' ✓':''}</p>`;
 el.innerHTML=h;el.querySelectorAll('button[data-q]').forEach(b=>b.onclick=()=>{const i=+b.dataset.q,P2=qProg();if(S.q.got[i]||P2[i]<N[i])return;S.q.got[i]=true;let r=QR[i];if(S.q.got.every(Boolean)&&!S.q.bonus){S.q.bonus=true;r+=QBONUS}S.coins+=r;save();renderQ();$('eMsg').textContent=t('q_got')+r})}
try{qInit()}catch(e){}
$('mEarn').onclick=()=>show('earn');$('backE').onclick=()=>show('menu',1);
$('mgGo').onclick=()=>show('mgame');$('backM').onclick=()=>show('earn',1);

