// Питомец-птицеед: рендер конечностей и карапакса, update() основной логики
// ================= ПТИЦЕЕД v3 =================
const SHC={};
function shd(c,k){const key=c+k;if(SHC[key])return SHC[key];const n=parseInt(c.slice(1),16),f=k>0?v=>v+(255-v)*k:v=>v*(1+k);
 return SHC[key]='#'+[n>>16,n>>8&255,n&255].map(v=>Math.max(0,Math.min(255,Math.round(f(v)))).toString(16).padStart(2,'0')).join('')}
const lumn=c=>{const n=parseInt(c.slice(1),16);return .3*(n>>16)+.59*(n>>8&255)+.11*(n&255)};
const hsh=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s)};
const mix2=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
function caps(a,b,r0,r1,c){r0=Math.max(.5,r0);r1=Math.max(.5,r1);
 const dx=b[0]-a[0],dy=b[1]-a[1],L2=dx*dx+dy*dy,R=Math.max(r0,r1)+.5;
 const x0=Math.floor(Math.min(a[0],b[0])-R),x1=Math.ceil(Math.max(a[0],b[0])+R),y0=Math.floor(Math.min(a[1],b[1])-R),y1=Math.ceil(Math.max(a[1],b[1])+R);
 g.fillStyle=c;
 for(let y=y0;y<=y1;y+=.5){let run=null;
  for(let x=x0;x<=x1+.5;x+=.5){let ins=false;
   if(x<=x1){const qx=x+.25-a[0],qy=y+.25-a[1];let t=L2?(qx*dx+qy*dy)/L2:0;t=t<0?0:t>1?1:t;
    const ex=qx-dx*t,ey=qy-dy*t,r=r0+(r1-r0)*t;ins=ex*ex+ey*ey<=r*r}
   if(ins){if(run===null)run=x}else if(run!==null){g.fillRect(run,y,x-run,.5);run=null}}}}
function cyl(a,b,r0,r1,c,hi){
 if(Math.max(r0,r1)<.95){caps(a,b,r0,r1,c);return}
 caps(a,b,r0,r1,shd(c,-.34));
 caps([a[0]-.16*r0,a[1]-.16*r0],[b[0]-.16*r1,b[1]-.16*r1],r0*.8,r1*.8,c);
 caps([a[0]-.42*r0,a[1]-.42*r0],[b[0]-.42*r1,b[1]-.42*r1],r0*.3,r1*.3,hi||shd(c,.28))}
function bristle(a,b,r,c,seed,n){const dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;g.fillStyle=c;
 for(let j=0;j<n;j++)for(const sd of[-1,1]){const t=(j+.3+hsh(seed+j*3.1+sd)*.5)/n,bx=a[0]+dx*t,by=a[1]+dy*t,o=r+.1;
  g.fillRect(bx+nx*o*sd,by+ny*o*sd,.5,.5);if(hsh(seed+j+sd*5)<.5)g.fillRect(bx+nx*(o+.5)*sd+dx/L*.3,by+ny*(o+.5)*sd+dy/L*.3,.5,.5)}}
// ---- конечность из 7 сегментов: 0 тазик, 1 вертлуг, 2 бедро, 3 коленная чашечка, 4 голень, 5 предлапка, 6 лапка ----
const LR7=[[3.8,3.5],[3.4,3.4],[3.8,3.5],[3.6,3.4],[3.3,2.7],[2.4,1.9],[1.9,1.2]];
function limb(bs,kn,tp,ls,id){
 const sg=PC.seg,k=SC*ls,hi=SC>=.5,rr=(i,e)=>LR7[i][e]*k;
 const l1=Math.hypot(kn[0]-bs[0],kn[1]-bs[1]),l2=Math.hypot(tp[0]-kn[0],tp[1]-kn[1]),L=(l1+l2)||1,kf=l1/L;
 const f=[0,.08,.15,kf-.07,kf+.06],R=1-f[4];f.push(f[4]+R*.4,f[4]+R*.78,1);
 const at=q=>{const d=q*L;return d<=l1?mix2(bs,kn,l1?d/l1:0):mix2(kn,tp,l2?(d-l1)/l2:0)};
 const pt=f.map(at),ORD=[0,1,6,5,4,2,3];
 if(k*LR7[2][0]<.95){for(const i of ORD)caps(pt[i],pt[i+1],rr(i,0),rr(i,1),sg[i]);caps(kn,kn,rr(3,0),rr(3,0),sg[3])}
 else{
  for(const i of ORD)caps(pt[i],pt[i+1],rr(i,0),rr(i,1),shd(sg[i],-.34));caps(kn,kn,rr(3,0),rr(3,0),shd(sg[3],-.34));
  for(const i of ORD){const a=pt[i],b=pt[i+1],r0=rr(i,0),r1=rr(i,1);caps([a[0]-.16*r0,a[1]-.16*r0],[b[0]-.16*r1,b[1]-.16*r1],r0*.8,r1*.8,sg[i])}
  {const r=rr(3,0);caps([kn[0]-.16*r,kn[1]-.16*r],[kn[0]-.16*r,kn[1]-.16*r],r*.8,r*.8,sg[3])}
  for(const i of[2,3,4,5,6]){const a=pt[i],b=pt[i+1],r0=rr(i,0),r1=rr(i,1);caps([a[0]-.42*r0,a[1]-.42*r0],[b[0]-.42*r1,b[1]-.42*r1],r0*.22,r1*.22,shd(sg[i],lumn(sg[i])<60?.16:.24))}
  // чёткие границы между сегментами (складки сочленений)
  for(let j=2;j<=6;j++){const a=pt[j],b=pt[j+1],dx=b[0]-a[0],dy=b[1]-a[1],ln=Math.hypot(dx,dy)||1,nx=-dy/ln,ny=dx/ln,r=Math.max(rr(j-1,1),rr(j,0))*.95;
   g.fillStyle=PC.ring&&(PC.ringJ||[3,4]).includes(j)?PC.ring:shd(sg[j],-.55);for(let t=-r;t<=r;t+=.5)g.fillRect(a[0]+nx*t,a[1]+ny*t,.5,.5)}
 }
 if(hi)for(const i of[2,3,4,5,6]){const a=pt[i],b=pt[i+1];bristle(a,b,Math.max(rr(i,0),rr(i,1))*.9,PC.lh||shd(sg[i],.3),id*17+i*5,i>=4?3:2)}
 g.fillStyle=PC.tip;g.fillRect(tp[0]-.25,tp[1]-.25,1,1)}
// ---- карапакс: статичная картинка (эллипс, слегка вогнутый у хелицер и чуть выпуклый сзади), без внешнего «пуха» ----
function carE(X,Y){const aX=Math.abs(X),ty=(Y-.1)/10.3,wy=10.6*Math.pow(Math.max(0,1-Math.pow(Math.abs(ty),2.3)),1/2.3);
 const yf=-9.5+1.1*Math.max(0,1-(aX/7.5)**2),yb=9.7+.7*Math.max(0,1-(aX/6)**2);return Math.min(wy-aX,Y-yf,yb-Y)}
let FT={};
let CARC=new WeakMap();const CARL=[];
function getCar(P0,sc){let m=CARC.get(P0);if(!m){m={};CARC.set(P0,m)}const key=sc.toFixed(3);if(m[key])return m[key];
 const CS=1.15,u=.5/sc/CS,HW=13,HH=12.5,W=Math.ceil(2*HW/u),H=Math.ceil(2*HH/u),cv2=document.createElement('canvas');cv2.width=W;cv2.height=H;
 const cx=cv2.getContext('2d'),im=cx.createImageData(W,H),d=im.data;
 const F=P0.carF,I=P0.carI,dark=lumn(I)<70,EYE=[[.8,-6.3],[2,-5.9],[.9,-4.9],[2.1,-4.7]],er=Math.max(.55,u*.58);
 const put=(i,j,c)=>{const n=parseInt(c.slice(1),16),o=(j*W+i)*4;d[o]=n>>16;d[o+1]=n>>8&255;d[o+2]=n&255;d[o+3]=255};
 for(let j=0;j<H;j++)for(let i=0;i<W;i++){
  const X=(i+.5-W/2)*u,Y=(j+.5-H/2)*u,aX=Math.abs(X),e=carE(X,Y);if(e<0)continue;
  const dome=1-((X/10.6)**2+((Y-.3)/10.2)**2),l=dome*.55-(X*.025+Y*.02),h1=hsh(i*13.7+j*7.3);let col;
  const RW=P0.rimW||.85;
  if(RW>1.2&&e<RW)col=e<.9?shd(F,.1):e>RW-.8?shd(F,-.4):F;
  else if(e<RW)col=l>.35?shd(F,.08):shd(F,-.12);
  else{
   col=l>.42?shd(I,.1):l>.18?I:shd(I,-.18);
   if(e<1.7)col=shd(col,-.28);
   if(P0.sheen&&l>.3&&h1<.14)col=P0.sheen;
   const dx=aX,dy=Y-3.2,r=Math.hypot(dx,dy);
   if(P0.stria){const an=Math.atan2(dx,-dy);if(r>1.6&&r<e*1.25+5)for(const ak of P0.striaA)if(Math.abs(an-ak)*r<(P0.striaW||.4)){col=P0.stria;break}}
   else if(r>2&&r<e*1.5+4&&(i+j&1)===0){const an=Math.atan2(dx,-dy);for(const ak of[.6,1.15,1.7,2.3])if(Math.abs(an-ak)*r<.5){col=dark?shd(col,.12):shd(col,-.3);break}}
   if(aX<.4&&Y>-3.2&&Y<3.2)col=dark?shd(col,.14):shd(col,-.35);
   const te=((X/2.7)**2+((Y+5.6)/1.8)**2);
   if(te<1){col=shd(I,.1);if(te>.68)col=shd(I,-.5)}
   for(const q of EYE)for(const sx of[-1,1])if(Math.hypot(X-sx*q[0],Y-q[1])<er)col=P0.eye;
   const Y0=3.2+.35*(X/2.2)**2;if(aX<2.3){if(Math.abs(Y-Y0)<Math.max(.5,u*.55))col='#050302';else if(Y>Y0+.5&&Y<Y0+1.2+u*.3)col=shd(col,.22)}
  }
  put(i,j,col)}
 cx.putImageData(im,0,0);CARL.push(cv2);return m[key]=cv2}
function drawCar(){const s=getCar(PC,SC),C=P(0,0);g.save();g.translate(Math.round(C[0]*2)/2,Math.round(C[1]*2)/2);g.rotate(ang);g.drawImage(s,-s.width/4,-s.height/4,s.width/2,s.height/2);g.restore()}
function drawSpider(){const s0=SC;SC=s0*((PC&&PC.big)||1);try{drawSpider0()}finally{SC=s0}}
function drawSpider0(){const turning=st==='turn',hi=SC>=.5,foot=walk&&(st==='stalk'||st==='freeze');
 // --- 8 ходильных ног ---
 for(let i=0;i<4;i++)for(const s of[-1,1]){const L=LEGS[i],m=s<0?1:-1,ph=i*1.4+(s>0?Math.PI:0)+(i%2)*.7;
  const a=Math.sin(PH+ph)*am,b=Math.cos(PH+ph)*am,bs=P(m*L[0],L[1]);let kn,tp;
  if(turning){const grp=(i+(s>0?1:0))%2,bb=Math.floor(tn),f=tn-bb,w=grp?.5:0,sv=ease((f-w)/.45),la=ANG0+DELTA*(bb+sv);
   kn=Q((ang+la)/2,m*L[2],L[3]);tp=Q(la,m*L[4],L[5]);
   if(sv>0&&sv<1){const l=.25*Math.sin(Math.PI*sv);tp=[lerp(tp[0],kn[0],l),lerp(tp[1],kn[1],l)]}
  }else if(foot){
   const rest=P(m*L[4],L[5]),kr=P(m*L[2],L[3]),key=i*2+(s>0?1:0),grp=(i+(s>0?1:0))%2;
   let F=FT[key];if(!F)F=FT[key]={x:rest[0],y:rest[1],sx:0,sy:0,tx:0,ty:0,t0:-9,act:false,grp,lift:0};
   if(F.act){const k=Math.min(1,(T-F.t0)/.13),e=ease(k);F.x=lerp(F.sx,F.tx,e);F.y=lerp(F.sy,F.ty,e);F.lift=Math.sin(Math.PI*k);if(k>=1)F.act=false}
   else{F.lift=0;if(Math.hypot(F.x-rest[0],F.y-rest[1])>5.5*SC){let other=false;for(const q in FT)if(FT[q].act&&FT[q].grp!==grp)other=true;
    if(!other){F.act=true;F.t0=T;F.sx=F.x;F.sy=F.y;F.tx=rest[0]+(rest[0]-F.x)*.5;F.ty=rest[1]+(rest[1]-F.y)*.5}}}
   tp=[F.x,F.y];const vx=tp[0]-bs[0],vy=tp[1]-bs[1],rx0=rest[0]-bs[0],ry0=rest[1]-bs[1],q0=rx0*rx0+ry0*ry0||1,ex=kr[0]-bs[0],ey=kr[1]-bs[1],k0=(ex*rx0+ey*ry0)/q0,h0=(-ex*ry0+ey*rx0)/q0,lf=1+.4*F.lift;
   kn=[bs[0]+vx*k0-vy*h0*lf,bs[1]+vy*k0+vx*h0*lf]
  }else{const kx=m*L[2]+a*.5,ky=L[3]+b*.5,tx=m*L[4]+a,ty=L[5]+b;kn=P(kx,ky);tp=P(tx,ty)}
  limb(bs,kn,tp,1,i*2+(s>0?1:0))}
 // --- брюшко: однотонная основа, пятна и продольные волоски (по виду) ---
 const br=Math.sin(T*2)*.4,rx=(ab.rx+br)*1.15,ry=(ab.ry+br)*1.15,ay=8+ry,A=P(0,ay);
 if(hi)for(const s of[-1,1])caps(P(s*.9,ay+ry-1.5),P(s*1.1,ay+ry+1.7),.9*SC,.65*SC,shd(PC.abO,.3));
 rEll(A[0],A[1],rx*SC,ry*SC,ang,PC.abO);rEll(A[0],A[1],(rx-1)*SC,(ry-1)*SC,ang,PC.abI);
 if(!PC.flat){const H=P(-2,ay-3);rEll(H[0],H[1],Math.max(2,rx-6)*SC,Math.max(2,ry-7)*SC,ang,PC.abH)}
 if(!PC.flat)for(const p of SPOTS){const q=P(p[0]*(rx-2),ay+p[1]*(ry-2));px(q[0],q[1],1,1,p[2]?PC.spotA:PC.spotB)}
 if(PC.tiger){const tc=PC.tiger;caps(P(0,ay-ry*.8),P(0,ay+ry*.8),.55*SC,.35*SC,tc[1]);
  for(let j=0;j<6;j++){const Y=ay-ry*.72+j*ry*.29,w=(rx-1.4)*(1-Math.pow((j-2.3)/4.4,2)*.55);
   for(const s of[-1,1]){const a0=P(0,Y),m=P(s*w*.55,Y+ry*.2),e=P(s*w,Y+ry*.04+j*.2);caps(a0,m,.95*SC,.8*SC,tc[0]);caps(m,e,.8*SC,.3*SC,tc[0])}}}
 if(hi&&PC.abHN)for(let j=0;j<PC.abHN;j++){const u=(hsh(j*1.7)*2-1)*.88,v=(hsh(j*2.9+5)*2-1)*.8;if(u*u+v*v>.85)continue;
  let X=u*rx,Y=ay+v*ry;const n=Math.round((2+hsh(j*5.1)*2.8)/.7);g.fillStyle=j%3?PC.abHair:shd(PC.abHair,.22);
  for(let q=0;q<n;q++){if(((X/rx)**2+((Y-ay)/ry)**2)>1.04)break;const pp=P(X,Y);g.fillRect(pp[0],pp[1],.5,.5);X+=u*.25;Y+=.7}}
 // --- педипальпы: те же 7 сегментов и окрас, что у ног, но короче и тоньше ---
 for(const s of[-1,1]){const w=Math.sin(PH*1.2+s)*1.5,v=Math.cos(PH*1.2),ck=chew;
  const b0=P(s*6.5,-8),kn=P(s*12.5,-21.5+ck*1.5),tp=P(s*(7.4-ck*3.4)+s*w*(1-ck*.5),-32+v*1+ck*4);
  limb(b0,kn,tp,.8,20+(s>0?1:0))}
 // --- хелицеры: массивные, раскрываются и жуют как раньше (op) ---
 const op=jaw*2.5+chew*(Math.sin(T*16)*.5+.5)*2,fw=op*.22;
 for(const s of[-1,1]){
  const c0=P(s*(3.6+op*.3),-8),c1=P(s*(3.8+op*.5),-19.5-fw);
  cyl(c0,c1,3.5*SC,3.2*SC,PC.chelA,shd(PC.chelA,.32));
  if(hi){g.fillStyle=PC.hair;for(let q=0;q<5;q++){const X=s*(1+q*1.25+op*.4),a=P(X,-19-fw-hsh(q+s*7)*.8),b=P(X,-20.2-fw-hsh(q+s*7)*.8);g.fillRect(a[0],a[1],.5,.5);g.fillRect(b[0],b[1],.5,.5)}}
  const f0=P(s*(3.7+op*.6),-18.6-fw),fm=P(s*(4.3+op*.95),-22-fw*1.3),ft=P(s*(2.8+op*1.05),-25.6-fw*1.6);
  cyl(f0,fm,1.8*SC,1.3*SC,PC.fang,shd(PC.fang,.5));cyl(fm,ft,1.3*SC,.45*SC,PC.fang,shd(PC.fang,.5))}
 drawCar()}
function drawDrop(x,y){['010','010','111','111'].forEach((r,j)=>[...r].forEach((v,i)=>{if(v==='1')px(x+i,y+j,1,1,'#8dbd3c')}))}
function drawHeart(x,y,c){['01010','11111','01110','00100'].forEach((r,j)=>[...r].forEach((v,i)=>{if(v==='1')px(x+i,y+j,1,1,c)}))}

const UI={},B1=$('b1'),B2=$('b2'),CNTE=$('cnt');
function update(dt){tm+=dt;T+=dt;chew=0;jaw=0;walk=false;
 for(const k in S.d){const d=S.d[k],f=isSpd(k)?TS*(d.molt&&d.molt.ph==='pre'?.1:1):1;d.sat=Math.max(0,d.sat-.04*dt*f);d.mood=Math.min(100,Math.max(0,d.mood+(-(d.sat<30?.08:.02)+(d.dec.hut.on||d.dec.log.on||d.dec.shell.on?.1:0))*dt*f))}
 const tr=D.sat<25?[7,7]:D.sat<50?[9,9]:D.sat<75?[11.5,11.5]:[14,14];ab.rx+=(tr[0]-ab.rx)*Math.min(1,dt*3);ab.ry+=(tr[1]-ab.ry)*Math.min(1,dt*3);
 const hungry=D.sat<30;let tfq=hungry?1.6:2.6,tam=hungry?.8:1.5;
 if(D.sat>85){tfq=1.2;tam=.5}
 if(twitch>0){twitch-=dt;tam=6;tfq=14}
 if(isSn(S.species))snakeStep(dt);
 else if(isMn(S.species))mantisStep(dt);
 else if(isSc(S.species))scorpionStep(dt);
 else if(st==='idle'){sp.y=52+Math.sin(T*1.3);reach=0;ang=0}
 else if(st==='approach'){const dx=prey.tx-prey.x,dy=prey.ty-prey.y,dd=Math.hypot(dx,dy);const stp=Math.min(dd,44*dt);if(dd>1){prey.x+=dx/dd*stp;prey.y+=dy/dd*stp}tfq=7.5;tam=3;aimAt(dt,3.6,prey);
  if(dd-stp<=1)go('stalk','m_stalk')}
 else if(st==='stalk'){const da=aimAt(dt,4.8,prey),F=P(0,-18),dist=Math.hypot(F[0]-prey.x,F[1]-prey.y);tfq=7.5;tam=3;
  if(Math.abs(da)<.35&&dist>14*rsc()){const v=38*dt*rsc();sp.x+=Math.sin(ang)*v;sp.y-=Math.cos(ang)*v;walk=true}
  if(Math.abs(da)<.1&&dist<=16*rsc())go('freeze','m_freeze')}
 else if(st==='freeze'){walk=true;aimAt(dt,3,prey);tfq=.5;tam=.2;jaw=ease(tm/.2);
  if(tm>.28){const F=P(0,-18);LG={sx:sp.x,sy:sp.y,fx:Math.sin(ang),fy:-Math.cos(ang),th:Math.min(14*rsc(),Math.max(0,Math.hypot(F[0]-prey.x,F[1]-prey.y)-1.5))};go('lunge','m_lunge')}}
 else if(st==='lunge'){const k=ease(tm/.18);jaw=1-ease((tm-.12)/.06);sp.x=LG.sx+LG.fx*LG.th*k;sp.y=LG.sy+LG.fy*LG.th*k;tam=0;tgt={x:prey.x,y:prey.y};
  if(tm>=.18)go('chew','m_chew')}
 else if(st==='chew'){prey.p=Math.min(1,tm/1.8);
  {const H=P(0,-17);prey.x=lerp(prey.x,H[0],Math.min(1,dt*20));prey.y=lerp(prey.y,H[1],Math.min(1,dt*20))}
  reach=1;chew=1;tfq=8;tam=2;tgt={x:prey.x,y:prey.y};
  if(tm>1.9){L0={x:sp.x,y:sp.y,a:ang};go('leave','m_leave')}}
 else if(st==='leave'){const k=ease(tm/1.1),r=ease(tm/.35);ang=lerp(L0.a,0,r);sp.x=lerp(L0.x,64,r);sp.y=lerp(L0.y,-60,k);{const H=P(0,-17);prey.x=H[0];prey.y=H[1]}
  reach=Math.max(0,1-tm/.4);chew=.6;tgt={x:prey.x,y:prey.y};tfq=10;tam=4.5;
  if(tm>=1.1){prey=null;reach=0;go('away','m_away')}}
 else if(st==='away'){sp.y=-80;if(tm>.5){ang=Math.PI;go('return','m_ret')}}
 else if(st==='return'){const k=ease(tm/1);sp.y=lerp(-60,52,k);ang=Math.PI;tfq=10;tam=k<.8?4.5:.4;
  if(tm>=1){tn=0;go('turn','m_turn')}}
 else if(st==='turn'){const k=Math.min(1,tm/1.3),k2=ease(k)*.5+k*.5;tn=k2*NT;ang=ANG0+tn*DELTA;sp.y=52;
  if(tm>=1.3){ang=0;D.sat=Math.min(100,D.sat+feedPts());D.mood=over?Math.max(0,D.mood-25):Math.min(100,D.mood+15);D.eaten++;save();
   for(let i=0;i<4;i++)fx.push({x:sp.x-16+i*10,y:sp.y-12-i%2*8,l:1.4,bad:over});
   go('idle',over?'m_over':'m_ok')}}
 fq+=(tfq-fq)*Math.min(1,dt*6);am+=(tam-am)*Math.min(1,dt*6);PH+=fq*dt;if(!walk)FT={};
 for(const f of fx){f.y+=(f.bad?8:-14)*dt;f.l-=dt}fx=fx.filter(f=>f.l>0);
 {const w1=Math.round(D.sat*2)/2+'%',w2=Math.round(D.mood*2)/2+'%';if(UI.w1!==w1){UI.w1=w1;B1.style.width=w1}if(UI.w2!==w2){UI.w2=w2;B2.style.width=w2}}
 if(UI.co!==S.coins){UI.co=S.coins;CN.forEach(e=>{e.textContent=S.coins})}
 {const c=t('eaten')+D.eaten;if(UI.c!==c){UI.c=c;CNTE.textContent=c}}
 if(st==='idle'&&twitch<=0&&hungry&&!inPre()&&msgK!=='m_hungry'&&Math.floor(T)%6===0)setMsg('m_hungry')}
