// Питомцы-змеи: полоз/питон/удав, мышь, анимация тела, шаг симуляции
// ---------- маисовый полоз и мышь ----------
const HD={x:60,y:80,a:3.5};
let sk={ext:0,mx:64,my:64,jaw:0,bu:1,ba:0,mo:null,att:false,mp:0,fat:1,amp:.9,main:true,ph:0};
const CALM={ext:0,jaw:0,bu:1,ba:0,fat:1,amp:.9,mx:0,my:0,att:false,mo:null,mp:0,main:false,ph:0};
const SKP=[[96,108],[66,112],[36,102],[22,78],[30,52],[56,38],[86,40],[104,58],[100,82],[80,92],[60,84]]; // от хвоста к голове
const crm=(a,b,c,d,t)=>{const t2=t*t,t3=t2*t;return .5*(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t2+(-a+3*b-3*c+d)*t3)};
const smo=(a,b,x)=>{x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)};
// мышь: тело — неизменные слои (контур, спина, голова, уши), анимируются только лапы, хвост и усы; l — вдоль тела, w — поперёк
function mouseR(x,y,a,t,s){const co=Math.cos(a),si=Math.sin(a),at=(l,w)=>[x+(co*l-si*w)*s,y+(si*l+co*w)*s],ln=(p,q,c)=>line(p[0],p[1],q[0],q[1],c),dt=(p,c)=>px(p[0],p[1],1,1,c);
 const fur='#8d867c',fur2='#a8a196',hi='#c4bdb1',pk='#d9a0a0';
 let pv=at(-7,0);for(let i=1;i<=7;i++){const q=at(-7-i*1.7,Math.sin(t*9+i*.8)*1.8*(i/7));ln(pv,q,i>5?'#c48a8a':pk);pv=q} // хвост
 for(const sg of[-1,1]){const fa=Math.sin(t*20+(sg>0?0:Math.PI)),ha=-fa; // диагональная походка
  const f0=at(3.6,sg*2.8),f1=at(4.6+fa*2,sg*5.2);ln(f0,f1,'#6f685f');dt(f1,pk); // передняя лапа и пальцы
  const h0=at(-3.6,sg*3),h1=at(-5,sg*5.8),h2=at(-3.4+ha*2.2,sg*6.4);ln(h0,h1,'#6f685f');ln(h1,h2,'#6f685f');dt(h2,pk)} // задняя: бедро, голень, стопа
 const sh=at(.6,.9);rEll(sh[0],sh[1],7.5*s,4.4*s,a,'rgba(0,0,0,.16)');
 const B=at(0,0);rEll(B[0],B[1],7.5*s,4.4*s,a,fur);rEll(B[0],B[1],6.5*s,3.4*s,a,fur2);
 const sp=at(-.5,0);rEll(sp[0],sp[1],5.4*s,.9*s,a,fur); // тёмная полоса по хребту
 for(const sg of[-1,1]){const hp=at(-3.6,sg*2.3);rEll(hp[0],hp[1],2.6*s,1.7*s,a,fur);const sd=at(1.2,sg*1.6);rEll(sd[0],sd[1],3.2*s,.8*s,a,hi)} // бёдра и блики на боках
 for(const sg of[-1,1]){const e=at(6,sg*3.6);rEll(e[0],e[1],2.1*s,2.1*s,a,fur);rEll(e[0],e[1],1.3*s,1.3*s,a,pk)} // уши
 const H=at(8,0);rEll(H[0],H[1],4.2*s,2.9*s,a,fur2);const sn=at(10.6,0);rEll(sn[0],sn[1],2.6*s,1.8*s,a,hi); // голова и морда
 for(const sg of[-1,1]){const e=at(9,sg*1.7);px(e[0],e[1],1,1,'#1c0f0a')}
 for(const sg of[-1,1]){const w0=at(11.4,sg*.9),w1=at(14.2,sg*(3.2+Math.sin(t*7+sg)*.7)),w2=at(14,sg*.4);ln(w0,w1,'#d8d2c8');ln(w0,w2,'#d8d2c8')} // усы
 const nz=at(12.4,0),nn=Math.max(1,Math.round(s*1.5));px(nz[0],nz[1],nn,nn,'#d98a8a')}
function disc(cx,cy,r,c){if(r<=0)return;g.fillStyle=c;g.beginPath();g.arc(cx,cy,r,0,6.283185);g.fill()}
const aEll=(cx,cy,rx,ry,a,c)=>{g.fillStyle=c;g.beginPath();g.ellipse(cx,cy,Math.max(.05,rx),Math.max(.05,ry),a,0,6.283185);g.fill()};
const aLine=(x0,y0,x1,y1,c,w=1)=>{g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke()};
const isSn=k=>{k=bs(k);return k==='corn'||k==='boa'||k==='ball'};
// Разведение змей: размножаются маисовый полоз и шаровидный питон (императорский удав — нет, с ним сложно)
const isSnB=k=>{k=bs(k);return k==='corn'||k==='ball'};
const SNX=4; // с какой стадии (1..10) у змеи виден пол
// виден ли у питомца пол: пауки — с 8-й линьки, разводимые змеи — со стадии SNX
const sexSeen=k=>{const d=S.d[k];return !!(d&&d.sex&&(isSnB(k)?(d.stage||1)>=SNX:isSpd(k)&&(d.L||6)>=8))};
const SNK={
 corn:{w:[1.7,6.3,2.2],tipF:8.4,base:'#e0852f',hi:'#f2a04a',ol:'#1c0f0a',bu:'#f0b36d',per:19,len:10.5,kr:.62,bg:1},
 boa:{w:[2.2,12.5,6],nk:[.78,.97],tipF:10.5,base:'#a39469',hi:'#c4b789',ol:'#2a1a10',bu:'#d6c99c',per:27,len:12,kr:.72,bg:.5,hs:1,hwd:1,hwf:.85,hd:'#4a2e1b',hdd:'#5a3a22',eye:'#d9a43a',zones:[[.13,'#8c3d26'],[.23,'#a45634'],[.33,'#b07c52']]},
 ball:{w:[1.4,6.2,3],nk:[.82,.97],tipF:10,base:'#2c1b10',hi:'#4d3524',ol:'#120905',bu:'#d9c28f',per:15,len:8,kr:.5,bg:.45,hs:.95,hwd:1,hwf:.55,hd:'#cdb078',hdd:'#120905',eye:'#c98a2a'}
};
// массивная клиновидная голова питонообразных: широкие скулы, длинная морда
function boaHead(hX,hY,ha,s0,o,mini,K){const s=s0*(K.hs||1),W=K.hwf||.6,co=Math.cos(ha),si=Math.sin(ha),F0=-7,F1=10.5,L=F1-F0;
 const WD=K.hwd||1,hw0=f=>{const t=(f-F0)/L;if(t<0)return 5.6;if(t>1)return 0;if(t<.3)return 5.6+3.2*smo(0,.3,t);if(t<.86)return lerp(8.8,3.7,(t-.3)/.56);return 3.7*Math.sqrt(Math.max(0,1-Math.pow((t-.86)/.14,2)))},hw=f=>hw0(f)*WD;
 const LP=(f,v)=>[hX+(co*f-si*v*W)*s,hY+(si*f+co*v*W)*s];
 const FS=[];for(let f=F0;f<F1;f+=.35)FS.push(f);FS.push(F1-.02,F1);
 const a0=FS.map(f=>LP(f,hw(f))),b0=FS.map(f=>LP(f,-hw(f))).reverse(),hp=new Path2D();hp.moveTo(a0[0][0],a0[0][1]);for(const q of a0)hp.lineTo(q[0],q[1]);for(const q of b0)hp.lineTo(q[0],q[1]);hp.closePath();
 if(mini){g.fillStyle=K.base;g.fill(hp);for(const q of[-1,1]){const e=LP(3,q*4.6);px(e[0],e[1],1,1,'#150a06')}return}
 g.save();g.lineJoin='round';g.strokeStyle=K.ol;g.lineWidth=2.2*s;g.stroke(hp);g.restore();
 const gr=g.createLinearGradient(hX-6*s,hY-8*s,hX+6*s,hY+8*s);gr.addColorStop(0,K.hi);gr.addColorStop(.5,K.base);gr.addColorStop(1,shd(K.base,-.3));g.fillStyle=gr;g.fill(hp);
 g.save();g.clip(hp);
 {const a=[],b=[];for(let f=-6;f<=9;f+=.5){const w=.25+.9*(1-(f+6)/15);a.push(LP(f,w));b.push(LP(f,-w))}g.fillStyle=K.hdd;g.beginPath();g.moveTo(a[0][0],a[0][1]);for(const q of a)g.lineTo(q[0],q[1]);for(const q of b.reverse())g.lineTo(q[0],q[1]);g.closePath();g.fill()}
 for(const q of[-1,1]){let a=LP(1.4,q*4),b=LP(5.2,q*3.4);aLine(a[0],a[1],b[0],b[1],shd(K.base,-.32),1.3*s);
  a=LP(3.4,q*5.2);b=LP(-4.6,q*7.4);aLine(a[0],a[1],b[0],b[1],K.hd,1.5*s);
  a=LP(3.8,q*4.6);b=LP(9.8,q*1.5);aLine(a[0],a[1],b[0],b[1],K.hd,.9*s);
  for(let f=-3.5;f<=9;f+=1.6){const w=hw(f);a=LP(f,q*(w-.2));b=LP(f,q*(w-1.9));aLine(a[0],a[1],b[0],b[1],shd(K.base,-.42),.8*s)}
  for(let f=3.6;f<=9;f+=1.7)for(const v of[1.6,3.1]){const e=LP(f+(v>2?.8:0),q*v*(1-(f-3)/16));aEll(e[0],e[1],.55*s,.4*s,ha,shd(K.base,.18))}}
 g.restore();
 if(o.jaw>.05){const m=LP(9.2,0);aEll(m[0],m[1],(2.2*o.jaw+.4)*s*.8,(3.4*o.jaw+.4)*s*.8,ha,'#8c1f30');aEll(m[0],m[1],(1.3*o.jaw+.2)*s*.8,(2*o.jaw+.2)*s*.8,ha,'#c43a50')}
 for(const q of[-1,1]){const e=LP(3.2,q*5);aEll(e[0],e[1],1.7*s,1.7*s,0,K.ol);aEll(e[0],e[1],1.3*s,1.3*s,0,K.eye);aEll(e[0],e[1],.4*s,1.05*s,ha,'#0a0504');aEll(e[0]-.35*s,e[1]-.4*s,.35*s,.3*s,0,'#fff3c9')}
 for(const q of[-1,1]){const e=LP(9.8,q*1.3);aEll(e[0],e[1],.55*s,.4*s,ha,'#120a06')}}
// голова маисового полоза: удлинённая, с копьевидным рисунком, золотистым глазом и полосой за глазом
function cornHead(hX,hY,ha,s,o,K){const co=Math.cos(ha),si=Math.sin(ha),F0=-8,F1=8.6,L=F1-F0;
 const hw=f=>{const t=(f-F0)/L;if(t<0)return 3.6;if(t>1)return 0;if(t<.26)return 3.6+1.5*smo(0,.26,t);if(t<.84)return lerp(5.1,3.1,(t-.26)/.58);return 3.1*Math.sqrt(Math.max(0,1-Math.pow((t-.84)/.16,2)))};
 const sp=f=>f<-6.5||f>4.6?-1:f<-1.5?.8+(f+6.5)/5*.9:1.7*(4.6-f)/6.1;
 const LP=(f,v)=>[hX+(co*f-si*v)*s,hY+(si*f+co*v)*s],sh0=K.base;
 // контур головы — векторный путь: края сглажены, обводка одинаковой толщины под любым углом, в том числе вокруг носа
 const side=[],FS=[];for(let f=F0;f<F1;f+=.3)FS.push(f);FS.push(F1-.02,F1);
 const hp=(()=>{const p=new Path2D(),top=FS.map(f=>LP(f,hw(f))),bot=FS.map(f=>LP(f,-hw(f))).reverse();p.moveTo(top[0][0],top[0][1]);for(const q of top)p.lineTo(q[0],q[1]);for(const q of bot)p.lineTo(q[0],q[1]);p.closePath();return p})();
 const ol=(()=>{const p=new Path2D(),a=FS.map(f=>LP(f,hw(f))),b=FS.map(f=>LP(f,-hw(f))).reverse(),all=a.concat(b);p.moveTo(all[0][0],all[0][1]);for(const q of all)p.lineTo(q[0],q[1]);return p})();
 g.save();g.lineJoin='round';g.lineCap='round';g.strokeStyle=K.ol;g.lineWidth=2.4*s;g.stroke(ol);g.restore();
 g.fillStyle=K.ol;g.fill(hp);
 g.fillStyle=sh0;g.fill(hp);
 // направление света (как у тела): сверху-слева
 const half=(c,sg)=>{const Bx=hX-.6*c*s,By=hY-.8*c*s,Tx=.8,Ty=-.6,Bg=60,p=new Path2D();p.moveTo(Bx+Tx*Bg,By+Ty*Bg);p.lineTo(Bx-Tx*Bg,By-Ty*Bg);p.lineTo(Bx-Tx*Bg+sg*-.6*Bg,By-Ty*Bg+sg*-.8*Bg);p.lineTo(Bx+Tx*Bg+sg*-.6*Bg,By+Ty*Bg+sg*-.8*Bg);p.closePath();return p};
 g.save();g.clip(hp);
 g.fillStyle=shd(sh0,-.2);g.fill(half(-2.8,-1));g.fillStyle=K.hi;g.fill(half(2.4,1));
 // копьевидный рисунок на голове
 const spP=(pad)=>{const p=new Path2D(),a=[],b=[];for(let f=-6.5;f<=4.6;f+=.25){const w=sp(f)+pad;a.push(LP(f,w));b.push(LP(f,-w))}a.push(LP(4.6,0));p.moveTo(a[0][0],a[0][1]);for(const q of a)p.lineTo(q[0],q[1]);for(const q of b.reverse())p.lineTo(q[0],q[1]);p.closePath();return p};
 g.fillStyle=K.ol;g.fill(spP(.7));
 const sin_=spP(0);g.save();g.clip(sin_);g.fillStyle='#b3261e';g.fillRect(hX-30,hY-30,60,60);g.fillStyle='#8e1c18';g.fill(half(-2,-1));g.fillStyle='#d4402c';g.fill(half(1,1));g.restore();
 g.restore();
 for(const q of[-1,1]){let a=LP(2.6,q*3.8),b=LP(-4.6,q*4.5);aLine(a[0],a[1],b[0],b[1],'#3a140c',1);
  a=LP(8.1,q*1.2);b=LP(-1.5,q*3.9);aLine(a[0],a[1],b[0],b[1],shd(K.base,-.3),1)}
 if(o.jaw>.05){const m=LP(7,0);aEll(m[0],m[1],3.2*o.jaw+.5,2.4*o.jaw+.5,ha,'#7a1428');const m2=LP(7.4,0);aEll(m2[0],m2[1],2.2*o.jaw+.2,1.5*o.jaw+.2,ha,'#c43a50')}
 for(const q of[-1,1]){const e=LP(3.3,q*3.2);aEll(e[0],e[1],1.5,1.5,0,'#3a140c');aEll(e[0],e[1],1.1,1.1,0,'#e8a22c');aEll(e[0],e[1],.55,.7,0,'#0a0504');aEll(e[0]-.1,e[1]-.2,.4,.4,0,'#fff3c9')}
 for(const q of[-1,1]){const e=LP(8,q*1.2);aEll(e[0],e[1],.5,.5,0,'#1a0a06')}}
const SRC=(()=>{const c=[0];for(let i=1;i<SKP.length;i++)c[i]=c[i-1]+Math.hypot(SKP[i][0]-SKP[i-1][0],SKP[i][1]-SKP[i-1][1]);return c})();
// Узор и ширина привязаны к «покою» тела (SRC), а не к текущей длине: при рывке пятна растягиваются вместе с шеей и не появляются заново
// позы по фото: точки по центру тела от хвоста к голове (пиксели фото) -> поворот -> вписать в поле игры; k — индекс, где «пружина» шеи крепится к кольцам
const rotFit=(P,rot,bx)=>{const c=Math.cos(rot),n=Math.sin(rot),r=P.map(p=>[p[0]*c-p[1]*n,p[0]*n+p[1]*c]);let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;for(const p of r){x0=Math.min(x0,p[0]);x1=Math.max(x1,p[0]);y0=Math.min(y0,p[1]);y1=Math.max(y1,p[1])}
 const k=Math.min((bx[2]-bx[0])/(x1-x0),(bx[3]-bx[1])/(y1-y0)),ex=(bx[0]+bx[2])/2-(x0+x1)/2*k,ey=bx[3]-y1*k;return r.map(p=>[+(p[0]*k+ex).toFixed(2),+(p[1]*k+ey).toFixed(2)])};
const mkP=(P,k)=>{const r=[0];for(let i=1;i<P.length;i++)r[i]=r[i-1]+Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);return{p:P,r,k}};
const spir=(cx,cy,rx,ry,f0,a0,sw,n)=>{const o=[];for(let k=0;k<=n;k++){const u=k/n,a=a0-u*sw,f=f0+(1-f0)*Math.pow(u,.8);o.push([cx+rx*f*Math.cos(a),cy+ry*f*Math.sin(a)])}return o};
const BALL_N=22,SWB=2.7*Math.PI;
const ballRaw=spir(592,255,120,155,.56,Math.PI-.25+SWB,SWB,BALL_N).concat([[440,290],[385,292],[335,275],[318,225],[318,170],[285,128],[245,150],[215,205],[172,250]]);
const boaRaw=[[395,205],[345,260],[322,350],[335,440],[350,520],[318,585],[250,615],[185,590],[165,500],[165,400],[170,250],[190,135],[255,85],[420,72],[600,92],[770,95],[890,140],[940,230],[915,330],[850,405],[765,430],[700,400],[675,330],[640,250],[560,195],[470,205],[415,285],[435,380],[470,430],[525,462],[535,505],[505,548]];
const PTH={corn:mkP(SKP),ball:mkP(rotFit(ballRaw,Math.PI/2,[16,48,112,116]),BALL_N),boa:mkP(rotFit(boaRaw,Math.PI,[16,48,112,116]),25)};
function snakeRender(s,ox,oy,o){
 const ks=Math.min(1,s),ol=Math.max(.5,ks),sp_=bs(o.sp||'corn'),K=SNK[sp_],bp=sp_==='ball',boa=sp_==='boa'||bp,SKQ=PTH[sp_].p,SRQ=PTH[sp_].r,mini=s<.4,tt=T+(o.ph||0),ext=o.ext,sw=1-ext,N=SKQ.length,C=SKQ.map(q=>[q[0],q[1]]),RT=SRQ[N-1];
 C[N-1][0]+=Math.sin(tt*.9)*1.6*sw;C[N-1][1]+=Math.cos(tt*.7)*1.1*sw;
 if(ext>0&&PTH[sp_].k!==undefined){ // бросок «пружиной»: шея сперва скручивается плотнее (S сильнее), затем выпрямляется в линию к цели
  const k0=PTH[sp_].k,A=C[k0],Hh=C[N-1],sN=SRQ[N-1]-SRQ[k0]||1,w=smo(.3,1,ext),cc=smo(0,.3,ext)*(1-w),
  Tx=lerp(Hh[0],o.mx,.95),Ty=lerp(Hh[1],o.my,.95),Ex=lerp(Hh[0],Tx,smo(0,.3,ext)*.2*(1-w)),Ey=lerp(Hh[1],Ty,smo(0,.3,ext)*.2*(1-w)),
  dx=Tx-A[0],dy=Ty-A[1],dd=Math.hypot(dx,dy)||1,kk=Math.max(.7,Math.min(1.5,dd/sN))*sN/dd;
  for(let i=k0+1;i<N;i++){const u=(SRQ[i]-SRQ[k0])/sN,bx=A[0]+(Hh[0]-A[0])*u,by=A[1]+(Hh[1]-A[1])*u,lx=C[i][0]-bx,ly=C[i][1]-by,sc=1-.22*cc,
   cx=A[0]+(Ex-A[0])*u*sc+lx*(1+.8*cc),cy=A[1]+(Ey-A[1])*u*sc+ly*(1+.8*cc),sx=A[0]+dx*u*kk,sy=A[1]+dy*u*kk;
   C[i][0]=lerp(cx,sx,w);C[i][1]=lerp(cy,sy,w)}}
 else if(ext>0){const L=(i,k)=>{C[i][0]=lerp(C[i][0],o.mx,k);C[i][1]=lerp(C[i][1],o.my,k)};L(N-1,ext*.92);L(N-2,ext*.38);L(N-3,ext*.1)}
 const pts=[];let lastR=1;
 for(let i=0;i<N-1;i++){const a=C[Math.max(0,i-1)],b=C[i],c=C[i+1],d=C[Math.min(N-1,i+2)],ch=Math.hypot(c[0]-b[0],c[1]-b[1]),m=Math.max(2,Math.ceil(ch)),rat=ch/(SRQ[i+1]-SRQ[i]);lastR=rat;
  for(let j=0;j<m;j++){const u=j/m;pts.push([crm(a[0],b[0],c[0],d[0],u),crm(a[1],b[1],c[1],d[1],u),SRQ[i]+u*(SRQ[i+1]-SRQ[i]),rat])}}
 pts.push([C[N-1][0],C[N-1][1],RT,lastR]);
 const n=pts.length,X=[],Y=[],R=[],SD=[],BG=[],COL=[],TL=[],RS=[],NX=[],NY=[],CL=[0];
 for(let i=1;i<n;i++)CL[i]=CL[i-1]+Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);
 for(let i=0;i<n;i++){const rs=pts[i][2],u=rs/RT,a=pts[Math.max(0,i-1)],b=pts[Math.min(n-1,i+1)],tx=b[0]-a[0],ty=b[1]-a[1],tl=Math.hypot(tx,ty)||1,
  off=Math.sin(u*16-tt*1.7)*o.amp*smo(0,.3,u)*(1-u*.7)*(.4+.6*sw);
  X[i]=ox+(pts[i][0]-ty/tl*off)*s;Y[i]=oy+(pts[i][1]+tx/tl*off)*s;RS[i]=rs;
  let nx=-ty/tl,ny=tx/tl;if(nx*-.6+ny*-.8<0){nx=-nx;ny=-ny}NX[i]=nx;NY[i]=ny; // нормаль в сторону света
  const inf=Math.exp(-Math.pow((u-o.bu)/.04,2))*o.ba;BG[i]=inf;
  const ws=Math.max(.74,Math.min(1,1/Math.sqrt(Math.max(.01,pts[i][3])))), // растянутая шея чуть тоньше
  fatK=(K.bg<1&&o.fat>1)?1+(o.fat-1)*.35:o.fat,wd=(K.w[0]+K.w[1]*smo(0,.42,u)-K.w[2]*smo(K.nk?K.nk[0]:.78,K.nk?K.nk[1]:.97,u))*fatK*ws+inf*5.5*K.bg;R[i]=Math.max((mini?.8:1)*Math.max(.7,ks),wd/2*s);
  let c=K.base,tail=false;if(K.zones)for(const z of K.zones)if(u<z[0]){c=z[1];tail=u<.3;break}
  COL[i]=BG[i]>.35?K.bu:c;TL[i]=tail;
  // порог толщины — по ширине тела в покое (без fat/шеи/вздутия), иначе при рывке и кормлении пятна мигают
  const wS=(K.w[0]+K.w[1]*smo(0,.42,u)-K.w[2]*smo(K.nk?K.nk[0]:.78,K.nk?K.nk[1]:.97,u))*.5*s;
  SD[i]=u>.1&&u<.93&&(rs%K.per)<K.len&&Math.max((mini?.8:1)*Math.max(.7,ks),wS)>=(mini?.9:1.9*ks)}
 // участки, перекрытые более поздней частью тела (другим витком), без деталей узора
 const OC=[];if(!mini)for(let i=0;i<n;i++){let h=false;for(let j=i+1;j<n;j++){if(CL[j]-CL[i]<2.5*(R[i]+R[j])+4)continue;const dx=X[i]-X[j],dy=Y[i]-Y[j];if(dx*dx+dy*dy<R[j]*R[j]*.72){h=true;break}}OC[i]=h}
 if(!mini)for(let i=0;i<n;i++)disc(X[i],Y[i],R[i]+ol,K.ol);
 for(let i=0;i<n;i++)disc(X[i],Y[i],R[i],COL[i]);
 if(!mini&&!boa){
  // объём трубы: тень, середина, блик
  for(let i=0;i<n;i++)if(!OC[i]&&R[i]>2.2*ks)disc(X[i]-NX[i]*R[i]*.42,Y[i]-NY[i]*R[i]*.42,R[i]*.58,shd(COL[i],-.2));
  for(let i=0;i<n;i++)if(!OC[i]&&R[i]>2.2*ks)disc(X[i]+NX[i]*R[i]*.2,Y[i]+NY[i]*R[i]*.2,R[i]*.62,COL[i]);
  for(let i=0;i<n;i++)if(!OC[i]&&R[i]>2.6*ks)disc(X[i]+NX[i]*R[i]*.42,Y[i]+NY[i]*R[i]*.42,R[i]*.3,K.hi);
  // чешуя: редкие светлые и тёмные крапинки, привязаны к телу
  for(let i=0;i<n;i++){if(OC[i]||R[i]<2.2*ks||SD[i])continue;const f=Math.floor(RS[i]*.5),h=hsh(f*3.7+(i&1)*1.3),l=(hsh(f*1.9+i*.37)*2-1)*R[i]*.78;
   if(h<.34)disc(X[i]+NX[i]*l,Y[i]+NY[i]*l,.55,shd(COL[i],.2));else if(h<.6)disc(X[i]+NX[i]*l,Y[i]+NY[i]*l,.55,shd(COL[i],-.16))}
  // седловины: чёрная окантовка, красная заливка, блик
  for(let i=0;i<n;i++)if(SD[i]&&!OC[i])disc(X[i],Y[i],R[i]*K.kr+ol,K.ol);
  for(let i=0;i<n;i++)if(SD[i]&&!OC[i])disc(X[i],Y[i],R[i]*K.kr,'#b3261e');
  for(let i=0;i<n;i++)if(SD[i]&&!OC[i]&&R[i]>2.6*ks){disc(X[i]-NX[i]*R[i]*.22,Y[i]-NY[i]*R[i]*.22,R[i]*K.kr*.5,'#8e1c18');disc(X[i]+NX[i]*R[i]*.2,Y[i]+NY[i]*R[i]*.2,R[i]*K.kr*.42,'#d4402c')}
  // мелкие боковые пятна между седловинами
  for(let i=0;i<n;i++){if(OC[i]||R[i]<2.8*ks||RS[i]/RT<.12||RS[i]/RT>.92)continue;const ph=RS[i]%K.per;if(Math.abs(ph-(K.len+(K.per-K.len)/2))<1.5)for(const q of[-1,1])disc(X[i]+NX[i]*q*R[i]*.7,Y[i]+NY[i]*q*R[i]*.7,Math.max(.9*ks,R[i]*.2),'#7a2418')}
 }
 if(!mini&&boa)for(let i=0;i<n;i++)if(!SD[i]&&R[i]>2.2*ks)px(X[i]-R[i]*.4,Y[i]-R[i]*.45,1,1,K.hi);
 if(mini){for(let i=0;i<n;i++)if(SD[i])px(X[i],Y[i],1,1,bp?'#c2a15f':boa?'#4a2a1b':'#b3261e')}
 else if(bp){ // шаровидный питон: тёмный фон, светлые «пятна-бока» парами
   for(let i=0;i<n;i++)if(!OC[i]&&R[i]>2.2*ks)disc(X[i]+NX[i]*R[i]*.25,Y[i]+NY[i]*R[i]*.25,R[i]*.5,shd(COL[i],.14));
   for(let i=0;i<n;i++){if(OC[i]||R[i]<2.4*ks||RS[i]/RT<.06)continue;const ph=RS[i]%K.per;if(ph>=K.len)continue;const wv=Math.sin(ph/K.len*Math.PI);if(wv<.15)continue;
    for(const q of[-1,1]){const cx=X[i]+NX[i]*q*R[i]*.56,cy=Y[i]+NY[i]*q*R[i]*.56,r=R[i]*.46*Math.min(1,wv*1.6);disc(cx,cy,r+.8*ol,'#1a0e08');disc(cx,cy,r,'#b8975a');disc(cx-NX[i]*r*.25,cy-NY[i]*r*.25,r*.55,'#cfb274');disc(cx+NX[i]*r*.2,cy+NY[i]*r*.2,r*.28,'#8a6a38')}}}
  else if(boa){
  for(let i=0;i<n;i++)if(SD[i])disc(X[i],Y[i],R[i]*K.kr+(TL[i]?1.4:.6),TL[i]?'#e6d39c':'#1f120a');
  for(let i=0;i<n;i++)if(SD[i])disc(X[i],Y[i],R[i]*K.kr,TL[i]?'#5a1e12':'#46281a');
  for(let i=0;i<n;i++)if(SD[i]&&!TL[i]&&R[i]>=4.5*ks&&(RS[i]%K.per)>K.len*.3&&(RS[i]%K.per)<K.len*.7)disc(X[i],Y[i],R[i]*.28,'#c6b987')}
 else{for(let i=0;i<n;i++)if(SD[i])disc(X[i],Y[i],R[i]*K.kr+ol,K.ol);
  for(let i=0;i<n;i++)if(SD[i])disc(X[i],Y[i],R[i]*K.kr,'#b3261e')}
 const a0=pts[Math.max(0,n-8)],p1=pts[n-1],ha=Math.atan2(p1[1]-a0[1],p1[0]-a0[0]),hx=Math.cos(ha),hy=Math.sin(ha),hX=ox+(p1[0]+hx*4)*s,hY=oy+(p1[1]+hy*4)*s,tipF=K.tipF;
 if(o.main){HD.x=p1[0]+hx*(4+tipF-1.9);HD.y=p1[1]+hy*(4+tipF-1.9);HD.a=ha}
 // проглоченная часть мыши скрыта: видно только то, что ещё перед пастью
 if(o.att&&o.mo&&o.mp<.995){const Mx=hX+hx*(tipF-.5)*s,My=hY+hy*(tipF-.5)*s,Lg=200,qx=-hy,qy=hx;
  g.save();g.beginPath();g.moveTo(Mx+qx*Lg,My+qy*Lg);g.lineTo(Mx+hx*Lg+qx*Lg,My+hy*Lg+qy*Lg);g.lineTo(Mx+hx*Lg-qx*Lg,My+hy*Lg-qy*Lg);g.lineTo(Mx-qx*Lg,My-qy*Lg);g.closePath();g.clip();
  mouseR(ox+o.mo.x*s,oy+o.mo.y*s,o.mo.a,tt,s);g.restore()}
 if(boa)boaHead(hX,hY,ha,s,o,mini,K);
 else if(!mini)cornHead(hX,hY,ha,s,o,K);
 else{const hl=Math.max(2,8.4*s),hw=Math.max(1.5,5.6*s);rEll(hX,hY,hl,hw,ha,K.base);
  for(const sg of[-1,1]){const ex=hX+hx*2.2*s-hy*sg*3.6*s,ey=hY+hy*2.2*s+hx*sg*3.6*s;rEll(ex,ey,.6,.6,0,'#140a06')}}
 if(!mini){const fl=(tt%3.4)<.5?Math.abs(Math.sin(tt*26)):0;if(fl>.05&&o.jaw<.05){const nx=hX+hx*(tipF-.5)*s,ny=hY+hy*(tipF-.5)*s,tl=7*fl*s,fk=2.6*s,tx=nx+hx*tl,ty=ny+hy*tl;aLine(nx,ny,tx,ty,'#c8203a');aLine(tx,ty,tx+Math.cos(ha+.6)*fk,ty+Math.sin(ha+.6)*fk,'#c8203a');aLine(tx,ty,tx+Math.cos(ha-.6)*fk,ty+Math.sin(ha-.6)*fk,'#c8203a')}}}
function startFeedS(k){feedK=k;S.inv[k]--;closeSel();over=D.sat>=75;
 const tx=Math.max(14,Math.min(114,HD.x+Math.cos(HD.a)*30)),ty=Math.max(10,Math.min(114,HD.y+Math.sin(HD.a)*30));
 const f=stageF(D),o=64*(1-f),L=v=>(v-o)/f; // экран -> координаты змеи (на малых стадиях поле змеи меньше экрана)
 const sx=o+tx*f,sy=o+ty*f,ex=[[sx,-10],[-10,sy],[138,sy]].map(e=>[e,Math.hypot(e[0]-sx,e[1]-sy)]).sort((a,b)=>a[1]-b[1])[Math.random()<.5?0:1][0];
 sk.mo={x:L(ex[0]===-10||ex[0]===138?ex[0]:Math.max(10,Math.min(118,sx+(Math.random()-.5)*50))),y:L(ex[1]===-10?-10:Math.max(10,Math.min(118,ex[1]))),tx,ty,a:Math.PI/2,v:90*Math.max(1,.75/f)};sk.att=false;sk.mp=0;sk.ba=sk.ba;save();go('approach','m_mouse')}
function attachM(sq){const m=sk.mo;if(!m)return;const d=lerp(12,-19,sk.mp);m.x=HD.x+Math.cos(HD.a)*d;m.y=HD.y+Math.sin(HD.a)*d;m.a=HD.a+Math.PI+sq}
function snakeStep(dt){sk.main=true;sk.fat=.88+.24*D.sat/100;sk.amp=twitch>0?4.5:st==='travel'?1.7:.9;sk.jaw=0;const m=sk.mo,e3=Math.min(1,dt*3);
 if(st==='idle'){sk.ext=lerp(sk.ext,0,Math.min(1,dt*6));sk.ba=Math.max(0,sk.ba-dt*.04);sk.att=false;sk.mo=null}
 else if(st==='approach'){const dx=m.tx-m.x,dy=m.ty-m.y,dd=Math.hypot(dx,dy);const stp=Math.min(dd,(m.v||90)*dt);if(dd>1.5){m.x+=dx/dd*stp;m.y+=dy/dd*stp;m.a=Math.atan2(dy,dx)}
  sk.mx=m.x;sk.my=m.y;sk.ext=lerp(sk.ext,.16,e3);if(dd-stp<=1.5)go('sfreeze','m_sfreeze')}
 else if(st==='sfreeze'){sk.mx=m.x;sk.my=m.y;sk.ext=lerp(sk.ext,.3,Math.min(1,dt*8));if(tm>.3)go('strike','m_lunge')}
 else if(st==='strike'){sk.ext=lerp(.3,1,ease(tm/.15));sk.jaw=ease(tm/.12);if(tm>=.15){sk.att=true;sk.mp=0;go('hold','m_shold')}}
 else if(st==='hold'){sk.ext=1-.12*ease(tm/.5);sk.jaw=1;attachM(Math.sin(tm*30)*.35);if(tm>=.5)go('pull','m_swal')}
 else if(st==='pull'){const k=ease(tm/1);sk.ext=.88*(1-k);sk.mp=.4*k;sk.jaw=1;attachM(Math.sin(tm*26)*.3*(1-k));if(tm>=1)go('swallow','m_swal')}
 else if(st==='swallow'){const k=Math.min(1,tm/1.3);sk.ext=0;sk.mp=.4+.6*ease(k);sk.jaw=1-ease((tm-.85)/.45);attachM(Math.sin(tm*22)*.2*(1-k));
  if(tm>=1.3){sk.att=false;sk.mo=null;sk.bu=.98;sk.ba=1;go('travel','m_trav')}}
 else if(st==='travel'){const k=ease(tm/3.8);sk.bu=lerp(.98,.42,k);sk.jaw=Math.max(0,.5*Math.sin(tm*9))*(1-k);if(tm>=3.8)go('rest','m_rest')}
 else if(st==='rest'){if(tm>=.8){D.sat=Math.min(100,D.sat+feedPts());D.mood=over?Math.max(0,D.mood-25):Math.min(100,D.mood+15);D.eaten++;save();
  for(let i=0;i<4;i++)fx.push({x:HD.x-24+i*14,y:HD.y-14-i%2*8,l:1.4,bad:over});go('idle',over?'m_overs':'m_ok')}}}
function petUI(){const e=$('gTitle');const bk=bs(S.species);e.dataset.i=isMn(bk)?'title_m':isSc(bk)?'title_sc':bk==='boa'?'title_boa':bk==='ball'?'title_ball':isSn(bk)?'title_s':'title';e.textContent=(D&&D.name)||t(e.dataset.i)}
