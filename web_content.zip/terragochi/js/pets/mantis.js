// Питомец-богомол: вертикальный террариум, декор, отрисовка, шаг
// ================= БОГОМОЛ Spodromantis lineola: вертикальный террариум, вид сбоку =================
const isMn=k=>bs(k)==='mantis';
const MNB=[[119,84],[88,80],[46,76],[4,70]],MNX=119;
const mnBY=x=>{for(let i=0;i<3;i++){const p=MNB[i],q=MNB[i+1];if(x<=p[0]&&x>=q[0])return lerp(p[1],q[1],(p[0]-x)/(p[0]-q[0]))}return x<MNB[3][0]?MNB[3][1]:MNB[0][1]};
const mn={lean:0,ext:0,chew:0,hx:76,hy:40,gx:-.8,gy:.3};
// статичные спрайты с арта (одна сетка, один масштаб): голова с глазами, переднегрудь+грудь, крыло+брюшко
const MSP={head:new Image(),wing:new Image(),body:new Image(),n:0};
MSP.head.src='assets/img/mantis_head.png';MSP.wing.src='assets/img/mantis_wing.png';MSP.body.src='assets/img/mantis_body.png';
MSP.head.onload=MSP.wing.onload=MSP.body.onload=()=>{if(++MSP.n>2){try{renderPick()}catch(e){}try{drawInsBoxes()}catch(e){}}};
const mspOk=i=>i.complete&&i.naturalWidth>0;
// цвета сняты с фото: листовой зелёный, светлые ноги, белое пятно на крыле, голубоватые глаза, жёлтая линия рта
const MC={wing:'#4c9a3b',wingF:'#37762c',wingE:'#86c85f',vein:'#6db24d',neck:'#80ba4a',head:'#a0d060',fem:'#9ccf5c',leg:'#78b24a',legT:'#93c25c',abd:'#cdd47c',pup:'#0a1f12',mouth:'#e8a83a',ant:'#6e4429',spine:'#f1f6dc',claw:'#5a3a20',stig:'#f3efd2'};
// ---- террариум богомола: статичный слой (фон, грунт, декор, рама, стволы, ветка), рисуется один раз и кэшируется ----
const MLIM={mbr:[-20,20],mvine:[-5,70],morch:[-3,54]};
const MDK=['mbr','mvine','morch'],MPX={mbr:[80,24,320,416],mvine:[0,24,320,416],morch:[264,24,232,302]};
const MNC=document.createElement('canvas');MNC.width=MNC.height=512;let MNK='';
const MPV={};
let mnK='mantis';const mnD=()=>S.d[mnK]||S.d.mantis;
const mnBgK=()=>{const k=mnD().bg;return BKS.includes(k)?k:'soil'};
const mnDecOn=()=>{const d=mnD().dec,o={};for(const k of MDK)if(d[k]&&d[k].on)o[k]=1;return o};
// брёвнышко с объёмом: контур, тело, тень снизу, блик сверху
const mnWood=(a,b,r0,r1,P)=>{const m=v=>Math.max(.5,v);
 caps([a[0],a[1]+.6],[b[0],b[1]+.6],r0+.6,r1+.6,P[0]);caps(a,b,r0,r1,P[1]);
 caps([a[0],a[1]+r0*.4],[b[0],b[1]+r1*.4],m(r0*.55),m(r1*.55),P[2]);caps([a[0],a[1]-r0*.1],[b[0],b[1]-r1*.1],m(r0*.55),m(r1*.55),P[1]);
 caps([a[0]-.2,a[1]-r0*.5],[b[0]-.2,b[1]-r1*.5],m(r0*.26),m(r1*.26),P[3])};
const mnTwig=(pts,r0,r1,P,cut)=>{const n=pts.length-1;for(let i=0;i<n;i++)mnWood(pts[i],pts[i+1],lerp(r0,r1,i/n),lerp(r0,r1,(i+1)/n),P);
 if(cut){const e=pts[n];caps(e,e,r1+.5,r1+.5,P[0]);caps(e,e,r1,r1,'#cfb07f');caps(e,e,Math.max(.5,r1*.45),Math.max(.5,r1*.45),'#8a6a48')}};
const mnKnot=(x,y,s,P)=>{rEll(x,y,1.7*s,1.35*s,0,P[0]);rEll(x-.2,y-.1,1.15*s,.9*s,0,P[2]);px(x-.5,y-.4,1,1,P[3])};
const mnMoss=(x,y,rx,ry)=>{rEll(x,y,rx,ry,0,'#2f5a26');rEll(x-.2,y-.2,rx*.85,ry*.8,0,'#4a7a34');rEll(x-.6,y-.5,rx*.5,ry*.45,0,'#7cae52')};
// основная ветка, на которой сидит богомол: геометрия MNB прежняя (лапы стоят на ней), но с корой, сучками, наростом мха снизу
function mnMainBranch(){
 const rr=[2.5,2,1.5,1],PM=['#3a2515','#6d4c2f','#523720','#9a7549'],yb=mnBY;
 mnTwig([[100,yb(100)+1],[103.5,yb(100)+4.5],[106,yb(100)+7.2]],1.1,.65,PM,1);
 mnTwig([[62,yb(62)+1],[59,yb(62)+4.5],[57.5,yb(62)+8.2]],1,.6,PM,1);
 mnTwig([[28,yb(28)],[24.5,yb(28)-5],[20,yb(28)-10],[20.5,yb(28)-15]],1.15,.55,PM,1);
 mnTwig([[24.5,yb(28)-5],[29,yb(28)-9.5],[31,yb(28)-12.5]],.7,.45,PM,1);
 mnTwig([[14,yb(14)],[10.5,yb(14)-4],[7,yb(14)-6.5]],.9,.5,PM,1);
 for(let i=0;i<3;i++){const p=MNB[i],q=MNB[i+1],n=Math.max(2,Math.round((p[0]-q[0])/4));
  for(let j=0;j<n;j++){const u0=j/n,u1=(j+1)/n,w=(u,k)=>lerp(rr[i],rr[i+1],u)+(hsh(i*17+k*3.1)-.5)*.35;
   mnWood([lerp(p[0],q[0],u0),lerp(p[1],q[1],u0)],[lerp(p[0],q[0],u1),lerp(p[1],q[1],u1)],w(u0,j),w(u1,j+1),PM)}}
 for(let x=7;x<117;x+=2.6){const j=Math.floor(x/2.6),y=yb(x),r=lerp(1,2.5,(x-4)/115);
  if(hsh(j*1.7)>.45)px(x,y-r*.2+hsh(j*3.3)*r*.9,2,1,PM[0]);if(hsh(j*2.9)>.7)px(x+1,y-r*.6,1,1,'#b08a5c')}
 mnKnot(52,yb(52)+.8,1,PM);mnKnot(92,yb(92)+.8,1.1,PM);
 for(const m of[[38,2.6,1.3],[76,1.9,1],[96,2.4,1.2]])mnMoss(m[0],yb(m[0])+lerp(1,2.5,(m[0]-4)/115)*.75,m[1],m[2])}
// ствол справа
function mnTrunk(){const PT=['#3a2515','#6d4c2f','#523720','#9a7549'],tx=y=>MNX+Math.sin(y*.09)*1.1;
 mnTwig([[tx(12)-1,12.5],[MNX-5,10.4],[MNX-7.8,10.2]],1.2,.75,PT,1);
 mnTwig([[tx(96)-1,96],[MNX-5.5,93.6],[MNX-8,94]],1.1,.7,PT,1);
 for(let y=4;y<110;y+=4){const A=[tx(y),y],B=[tx(y+4),y+4.6],r=3.1+hsh(y*.31)*.35,m=v=>Math.max(.5,v);
  caps([A[0]+.4,A[1]],[B[0]+.4,B[1]],r+.5,r+.5,PT[0]);caps(A,B,r,r,PT[1]);
  caps([A[0]+r*.45,A[1]],[B[0]+r*.45,B[1]],m(r*.55),m(r*.55),PT[2]);caps([A[0]-r*.1,A[1]],[B[0]-r*.1,B[1]],m(r*.55),m(r*.55),PT[1]);
  caps([A[0]-r*.5,A[1]],[B[0]-r*.5,B[1]],m(r*.26),m(r*.26),PT[3])}
 for(let y=8;y<106;y+=4.5){const j=Math.floor(y/4.5),x=tx(y)+(hsh(j*1.9)*3.2-1.8);if(hsh(j*2.3)>.35)px(x,y,1,3,PT[0]);if(hsh(j*3.7)>.6)px(x-1,y+1,1,2,'#b08a5c')}
 mnKnot(tx(40)-.6,40,1.15,PT);mnKnot(tx(68)+.4,68,1,PT);
 caps([tx(104)-1,105.5],[MNX-6.5,109.4],1.5,.8,PT[0]);caps([tx(104)-1,105.5],[MNX-6.5,109.4],1.1,.5,PT[1]);
 caps([tx(104)+1,105.5],[MNX+5.5,109.4],1.5,.8,PT[0]);caps([tx(104)+1,105.5],[MNX+5.5,109.4],1.1,.5,PT[1]);
 mnMoss(MNX-1.6,100,2.4,1.4);mnMoss(MNX+1.2,88,1.6,1)}
// декор 1: коряга через весь террариум (рисуется ПОЗАДИ богомола, его ветки и ствола, внизу — там, где ничего не занято)
function mnDrift(){const P=['#3d2a1a','#8a6a48','#6c5036','#c4a470'],pts=[[-4,102.5],[22,100],[52,97],[84,94.5],[112,91.5],[130,90]],rs=[3.1,2.8,2.4,2.1,1.9,1.8];
 const ya=x=>{for(let i=0;i<5;i++)if(x<=pts[i+1][0])return lerp(pts[i][1],pts[i+1][1],(x-pts[i][0])/(pts[i+1][0]-pts[i][0]));return pts[5][1]};
 const ra=x=>{for(let i=0;i<5;i++)if(x<=pts[i+1][0])return lerp(rs[i],rs[i+1],(x-pts[i][0])/(pts[i+1][0]-pts[i][0]));return rs[5]};
 mnTwig([[58,96.2],[62,91.5],[65.5,87.8]],1.2,.6,P,1);mnTwig([[36,99],[33,103.5],[32,106]],1,.6,P,1);
 for(let i=0;i<5;i++)mnWood(pts[i],pts[i+1],rs[i],rs[i+1],P);
 for(let x=3;x<125;x+=3){const j=Math.floor(x/3),y=ya(x),r=ra(x);if(hsh(j*2.1)>.4)px(x,y-r*.3+hsh(j*5.1)*r*.8,2,1,P[0]);if(hsh(j*1.3)>.6)px(x+1,y-r*.6,2,1,'#e6d2a8')}
 mnKnot(34,ya(34)+.5,1.2,P);mnKnot(78,ya(78)+.5,1,P);
 for(const x of[12,42,104])mnMoss(x,ya(x)-ra(x)*.85,3.2,1.2)}
// декор 2: лиана свисает с крышки; листья сидят на стеблях на черешках
function mnVine(){const ST=[[[10,3],[8.5,15],[11.5,25],[9.5,36],[12.5,46],[11.2,55]],[[23,3],[24.5,13],[22.5,22],[24.5,31],[23.4,38]],[[37,3],[35.5,12],[37.5,19],[36.6,25]]],
 LC=[['#3f8a3a','#6dbb55'],['#4fa646','#86d067'],['#357a34','#5fae4c']];
 const lf=(x,y,a,s,c)=>{const ca=Math.cos(a),sa=Math.sin(a),cx=x+ca*3.4*s,cy=y+sa*3.4*s;line(x,y,x+ca*1.6,y+sa*1.6,'#2c5a28');
  rEll(cx,cy,3.6*s,2.2*s,a,'#1f4a22');rEll(cx-.2,cy-.2,3.2*s,1.8*s,a,c[0]);rEll(cx-.5,cy-.6,2.2*s,.8*s,a,c[1]);caps([x+ca*1.4,y+sa*1.4],[cx+ca*2.4*s,cy+sa*2.4*s],.5,.5,'#2f6f33')};
 ST.forEach((s,si)=>{lf(s[0][0],s[0][1]+3,si%2?2.7:.45,.8,LC[si%3]);lf(s[0][0],s[0][1]+3,si%2?.45:2.7,.7,LC[(si+1)%3])});
 ST.forEach(s=>{for(let i=0;i<s.length-1;i++)caps(s[i],s[i+1],1.1,1.1,'#1d3d1c');for(let i=0;i<s.length-1;i++)caps(s[i],s[i+1],.6,.6,'#4a8a3a')});
 ST.forEach((s,si)=>{for(let i=1;i<s.length;i++){const last=i===s.length-1,side=(i+si)%2?1:-1,a=last?1.45:(side>0?.55:Math.PI-.55)+(hsh(si*9+i)-.5)*.5;
  lf(s[i][0],s[i][1],a,last?.8:.9+hsh(i+si*5)*.3,LC[(i+si)%3])}});
 const e=ST[0][5];line(e[0],e[1],e[0]+1,e[1]+3,'#4a8a3a');line(e[0]+1,e[1]+3,e[0]-1,e[1]+5,'#4a8a3a');line(e[0]-1,e[1]+5,e[0]-2,e[1]+4,'#4a8a3a')}
// декор 3: орхидея на кусочке пробки, прикреплена к стволу (рисуется после ствола, до ветки и богомола)
function mnOrchid(){
 rEll(115.6,33,3.4,6.2,.08,'#33210f');rEll(115.4,33,2.9,5.7,.08,'#8a6a48');rEll(114.8,32,1.6,4,.08,'#b39166');px(116,36,1,1,'#5e4429');px(114,30,1,1,'#5e4429');
 for(const r of[[[115,37],[112.5,42],[113.4,47.5]],[[116,38],[114.5,44],[116.5,49]],[[114.5,28],[111.5,25.5]]]){for(let i=0;i<r.length-1;i++)line(r[i][0],r[i][1],r[i+1][0],r[i+1][1],'#9dbd96');const e=r[r.length-1];px(e[0],e[1],1,1,'#d4e6cf')}
 const ol=(ang,len,w,cv2)=>{const B=[114.2,31],M=[B[0]+Math.cos(ang)*len*.5,B[1]+Math.sin(ang)*len*.5],E=[M[0]+Math.cos(ang+cv2)*len*.5,M[1]+Math.sin(ang+cv2)*len*.5];
  caps(B,M,1.1,w+.5,'#1d4a26');caps(M,E,w+.5,.6,'#1d4a26');caps(B,M,.8,w,'#2f7a3a');caps(M,E,w,.5,'#2f7a3a');
  caps([B[0]-.3,B[1]-.5],[M[0]-.3,M[1]-.5],.5,w*.45,'#5aa650');caps([M[0]-.3,M[1]-.5],[E[0]-.2,E[1]-.3],Math.max(.5,w*.45),.5,'#7cc35e')};
 ol(Math.PI+.95,12,2.1,-.5);ol(Math.PI+.12,13.5,2.4,.55);ol(Math.PI-.55,10.5,1.9,-.55);
 const sp=[[114.4,30],[112.4,22],[108,15.8],[102.5,12.6],[97.5,13.2]];
 for(let i=0;i<4;i++)caps(sp[i],sp[i+1],1,1,'#244f26');for(let i=0;i<4;i++)caps(sp[i],sp[i+1],.6,.6,'#5a9a46');
 const fl=(x,y,s)=>{for(let i=0;i<5;i++){const a=i*1.2566-1.57;rEll(x+Math.cos(a)*1.5*s,y+Math.sin(a)*1.5*s,1.9*s,1.15*s,a,'#c9578f')}
  for(let i=0;i<5;i++){const a=i*1.2566-1.57;rEll(x+Math.cos(a)*1.4*s-.2,y+Math.sin(a)*1.4*s-.2,1.55*s,.85*s,a,'#f7d3e4')}
  rEll(x,y,1.1*s,1.1*s,0,'#ffd34d');px(x-.5,y-.5,1,1,'#b0306e')};
 fl(110.3,19.6,1);fl(106.2,15.2,1.05);fl(101.6,12.4,1);fl(97.8,13.6,.85);rEll(95,15.6,1.1,1.5,.5,'#e58fb8');rEll(94.8,15.3,.6,.9,.5,'#f7d3e4')}
function mnLip(bk){
 if(bk==='sand'){px(0,107,128,1,'#9c7f45');for(let x=1;x<128;x+=5)px(x+hsh(x)*3,106,2,1,'#c9ac6c')}
 else if(bk==='moss'){px(0,107,128,1,'#233f1d');for(let x=0;x<128;x+=2){const h=hsh(x*1.37);if(h>.35)px(x,106-(h>.75?1:0),2,2,h>.88?'#8fc56a':'#3f7a32')}}
 else px(0,107,128,1,'#3b281a')}
// каждый подвижный декор и неподвижные слои кэшируются спрайтами; двигаем декор простым drawImage со смещением (перерисовки не нужны)
const MNS={};
function mnSpr(name,x0,y0,x1,y1,fn){let e=MNS[name];if(!e){e=MNS[name]={c:document.createElement('canvas'),x0,y0,w:x1-x0,h:y1-y0,ok:false};e.c.width=e.w*SCALE;e.c.height=e.h*SCALE}
 if(!e.ok){const x=e.c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,e.c.width,e.c.height);fixCtx(x,SCALE);x.translate(-x0,-y0);onCtx(x,fn);e.ok=true}return e}
const mnPut=(e,dx,dy)=>g.drawImage(e.c,e.x0+dx,e.y0+dy,e.w,e.h);
function mnFrame(){
 px(0,0,128,5,'#23282a');for(let x=1;x<128;x+=3)for(let y=1;y<5;y+=2)px(x,y,1,1,'#4b5456');px(0,5,128,1,'#10181a');
 px(0,0,2,128,'#2b3234');px(126,0,2,128,'#2b3234');px(2,6,1,100,'rgba(255,255,255,.4)');px(124,6,1,100,'rgba(255,255,255,.25)');
 mnTrunk()}
function mnOff(){const d=mnD().dec,c=(v,L)=>Math.max(L[0],Math.min(L[1],Math.round(+v||0)));
 return{bx:c(d.mbr.x,MLIM.mbr),fl:d.mbr.a?1:0,vx:c(d.mvine.x,MLIM.mvine),oy:c(d.morch.y,MLIM.morch)}}
function mnLayer(bk,on,o){o=o||{};
 g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,512,512);
 const gr=g.createLinearGradient(0,0,0,512);gr.addColorStop(0,'#dfe3d0');gr.addColorStop(1,'#bcc6a8');g.fillStyle=gr;g.fillRect(0,0,512,512);
 fixCtx(g,SCALE);
 g.drawImage(BGK[bk]||BGK.soil,0,0,512,80,0,108,128,20);mnLip(bk);
 if(on.mbr)mnPut(o.fl?mnSpr('driftF',-26,82,154,110,()=>{g.translate(128,0);g.scale(-1,1);mnDrift()}):mnSpr('drift',-26,82,154,110,mnDrift),o.bx|0,0);
 if(on.mvine)mnPut(mnSpr('vine',-2,0,56,64,mnVine),o.vx|0,0);
 mnPut(mnSpr('mid',0,0,128,128,mnFrame),0,0);
 if(on.morch)mnPut(mnSpr('orch',88,4,124,56,mnOrchid),0,o.oy|0);
 mnPut(mnSpr('br',0,0,128,128,mnMainBranch),0,0)}
function mnScene(){const bk=mnBgK(),on=mnDecOn(),o=mnOff(),key=bk+MDK.map(k=>on[k]?1:0).join('')+'|'+o.bx+','+o.fl+','+o.vx+','+o.oy;
 if(!alive(MNC)){for(const k in MNS)MNS[k].ok=false;MNK=''}
 if(key!==MNK){onCtx(MNC.getContext('2d'),()=>mnLayer(bk,on,o));MNK=key}
 g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,512,512);g.drawImage(MNC,0,0);fixCtx(g,SCALE)}
// рамки выделения декора богомола в режиме редактирования
function mnBox(k){const o=mnOff();return k==='mbr'?[Math.max(2,-4+o.bx),84,Math.min(126,131+o.bx),108]:k==='mvine'?[3+o.vx,3,44+o.vx,58]:[93,7+o.oy,121,52+o.oy]}
function mnEditOverlay(){const k0=Math.floor(T*6);for(const k of MDK){const n=S.dec[k];if(!n.on)continue;const b=mnBox(k),sel=k===decSel,cl=sel?'#ffe27a':'#ffffff';let i=0;
 const dot=(x,y)=>{const j=i++;if(j%4===0)px(x,y,1,1,cl)};
 for(let x=b[0];x<=b[2];x++){dot(x,b[1]);dot(x,b[3])}for(let y=b[1]+1;y<b[3];y++){dot(b[0],y);dot(b[2],y)}}}
function mnPrevCanvas(k){let c=MPV[k];if(!c||!alive(c)){c=MPV[k]=c||document.createElement('canvas');c.width=c.height=512;onCtx(c.getContext('2d'),()=>mnLayer('soil',{[k]:1}))}return c}
function mnDraw(t,lean,ext,chew,aim,fat,card){
 const A=-(lean+Math.sin(t*1.1)*.012),cA=Math.cos(A),sA=Math.sin(A),PX=82,PY=76;
 const R=(x,y)=>{const dx=x-PX,dy=y-PY;return[PX+dx*cA-dy*sA,PY+dx*sA+dy*cA]};
 const dk=s=>shd(s,-.3),fy=x=>mnBY(x)-2.3,LA=11.5,LB=13.8,LC=11,lp=(p,q,k)=>[lerp(p[0],q[0],k),lerp(p[1],q[1],k)];
 const Mc=(a,b,r0,r1,c)=>{caps(a,b,r0,r1,shd(c,-.36));caps([a[0]-.25,a[1]-.25],[b[0]-.25,b[1]-.25],r0*.78,r1*.78,c);caps([a[0]-.5,a[1]-.5],[b[0]-.5,b[1]-.5],r0*.25,r1*.25,shd(c,.3))};
 // нога: бедро, голень, членистая лапка с коготком; колено тёмное; у ближних ног светлая полоска и шипики
 const leg=(b,k,f,c1,c2,n)=>{const a=lp(k,f,.76);
  if(n)rEll(f[0]+.5,f[1]+.9,3,.8,0,'rgba(20,12,6,.22)');
  Mc(b,k,1.3,1.05,c1);Mc(k,a,.95,.65,c2);
  for(let i=0;i<4;i++)caps(lp(a,f,i/4),lp(a,f,(i+.78)/4),.55,.45,i%2?shd(c2,-.22):shd(c2,.14));
  if(n){px(k[0]-.5,k[1]-.5,2,2,dk(c1));caps(lp(b,k,.2),lp(b,k,.85),.3,.3,shd(c1,.32));
   const dx=k[0]-b[0],dy=k[1]-b[1],L=Math.hypot(dx,dy)||1;}
  px(f[0]-1,f[1],3,1,MC.claw);px(f[0]-2,f[1]+1,1,1,MC.claw);px(f[0]+2,f[1]+1,1,1,MC.claw)};
 // ловчая лапа: двухзвенная кинематика, локоть всегда вверху (форма /\)
 const ik=(S0,p,FA,FB)=>{const dx=p[0]-S0[0],dy=p[1]-S0[1],d=Math.hypot(dx,dy)||1,dm=Math.min(d,FA+FB-.05),ux=dx/d,uy=dy/d,
  al=Math.acos(Math.max(-1,Math.min(1,(FA*FA+dm*dm-FB*FB)/(2*FA*dm)))),ca=Math.cos(al),sa=Math.sin(al),
  c1=[S0[0]+(ux*ca-uy*sa)*FA,S0[1]+(ux*sa+uy*ca)*FA],c2=[S0[0]+(ux*ca+uy*sa)*FA,S0[1]+(-ux*sa+uy*ca)*FA];
  return{K:c1[1]<c2[1]?c1:c2,T:[S0[0]+ux*dm,S0[1]+uy*dm]}};
  // хватательная лапа из 3 сегментов: тазик (вниз), бедро (вверх-вперёд), голень (вниз) — Z-образно; хватают последние два
 const S0=R(67.5,40.5),un=v=>{const l=Math.hypot(v[0],v[1])||1;return[v[0]/l,v[1]/l]};
 const mk3=(d1,d2,d3)=>{const a=un(d1),b=un(d2),c=un(d3),E=[67.5+a[0]*LA,40.5+a[1]*LA],K=[E[0]+b[0]*LB,E[1]+b[1]*LB],T=[K[0]+c[0]*LC,K[1]+c[1]*LC];return{E:R(E[0],E[1]),K:R(K[0],K[1]),T:R(T[0],T[1])}};
 const mixP=(p,q,k)=>({E:lp(p.E,q.E,k),K:lp(p.K,q.K,k),T:lp(p.T,q.T,k)});
 const fixP=p=>{const u=(a,b,L)=>{const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1;return[a[0]+dx/d*L,a[1]+dy/d*L]};const E=u(S0,p.E,LA),K=u(E,p.K,LB);return{E,K,T:u(K,p.T,LC)}};
 let pose=mk3([-.1,1],[-.68,-.73],[.08,1]);
 if(aim&&ext>.001){const ax=aim.x,ay=aim.y-1,dx=ax-S0[0],dy=ay-S0[1],d=Math.hypot(dx,dy)||1,E=[S0[0]+dx/d*LA*.9,S0[1]+dy/d*LA*.9],q=ik(E,[ax,ay],LB,LC);pose=fixP(mixP(pose,{E,K:q.K,T:q.T},ext))}
 if(chew>.001)pose=fixP(mixP(pose,mk3([-.5,.85],[-.45,-.89],[.6,.8]),chew));
 const spines=(p,q,r,n,ref,len,sl)=>{const dx=q[0]-p[0],dy=q[1]-p[1],L=Math.hypot(dx,dy)||1;let nx=-dy/L,ny=dx/L;const d=nx*ref[0]+ny*ref[1];if(Math.abs(d)<.5?ny<0:d<0){nx=-nx;ny=-ny}
  for(let i=1;i<=n;i++){const k=i/(n+1),x=p[0]+dx*k+nx*r,y=p[1]+dy*k+ny*r,l=len*(i%2?1:.62),ex=x+nx*l+dx/L*sl,ey=y+ny*l+dy/L*sl;line(x,y,ex,ey,'#6a4526')}};
 const fore=(O,c,sh)=>{const s0=[S0[0]+O[0],S0[1]+O[1]],E=[pose.E[0]+O[0],pose.E[1]+O[1]],K=[pose.K[0]+O[0],pose.K[1]+O[1]],T2=[pose.T[0]+O[0],pose.T[1]+O[1]];
  Mc(s0,E,1.8,1.5,c);Mc(E,K,2.4,1.9,c);Mc(K,T2,1.6,.8,c);
  px(E[0]-.5,E[1]-.5,2,2,dk(c));px(K[0]-.5,K[1]-.5,2,2,dk(c));
  if(sh){const e=lp(s0,E,.22);px(e[0]-1,e[1]-1,2,2,'#f3efd2');px(e[0],e[1],1,1,'#1d2a14');
   caps(lp(E,K,.15),lp(E,K,.85),.4,.4,dk(c));
   spines(E,K,2.0,5,[T2[0]-(E[0]+K[0])/2,T2[1]-(E[1]+K[1])/2],2.1,.5);spines(K,T2,1.3,5,[E[0]-(K[0]+T2[0])/2,E[1]-(K[1]+T2[1])/2],1.6,.6)}
  const dx=T2[0]-K[0],dy=T2[1]-K[1],L=Math.hypot(dx,dy)||1;caps(T2,[T2[0]+dx/L*2.8-dy/L*1.1,T2[1]+dy/L*2.8+dx/L*1.1],.9,.3,MC.claw);return T2};
 // дальняя сторона
 leg(R(85.5,60.8),R(81,66.5),[80,fy(80)],dk(MC.leg),dk(MC.legT),0);leg(R(96,64.3),R(103.5,68.5),[110,fy(110)],dk(MC.leg),dk(MC.legT),0);
 fore([1.8,-.8],dk(MC.fem),0);
 // крыло+брюшко и переднегрудь+грудь: спрайты арта, поворачиваются вместе с телом
 const wb=R(80,51.6),spr=(im,ox,oy)=>{if(mspOk(im)){g.save();g.translate(Math.round(wb[0]),Math.round(wb[1]));g.rotate(A);g.drawImage(im,ox,oy,im.naturalWidth/2,im.naturalHeight/2);g.restore()}};
 spr(MSP.wing,0,0);spr(MSP.body,-14.62,-17.17);
 leg(R(80,61.5),R(71,62),[71,fy(71)],MC.leg,MC.legT,1);leg(R(91,62.8),R(98.5,67),[105,fy(105)],MC.leg,MC.legT,1);
 const T2=fore([0,0],MC.fem,1);mn.hx=T2[0]-1;mn.hy=T2[1]+1;
 // голова: жёстко сидит на теле (шея не тянется), зрачки следят за добычей
 {const op=chew*(Math.sin(t*20)*.5+.5)*1.4,HW=13,HH=10.5,hc=R(64.1,34.4),cH=Math.cos(A),sH=Math.sin(A),
  lx=(u,v)=>[hc[0]+cH*(u-HW/2)-sH*(v-HH/2),hc[1]+sH*(u-HW/2)+cH*(v-HH/2)];
  if(mspOk(MSP.head)){g.save();g.translate(Math.round(hc[0]),Math.round(hc[1]));g.rotate(A);g.drawImage(MSP.head,-HW/2,-HH/2,HW,HH);g.restore()}
  const E=[lx(2.2,3.2),lx(10.4,3.2)];let tx=-.7+Math.sin(t*.7)*.6,ty=.25+Math.sin(t*.5)*.3;
  if(!card&&prey){const ex=(E[0][0]+E[1][0])/2,ey=E[0][1],dx=prey.x-ex,dy=(prey.y-2)-ey,d=Math.hypot(dx,dy)||1,m=Math.min(1,d/12);tx=dx/d*m;ty=dy/d*m}
  if(card){tx=-.7;ty=.3}
  const k=card?1:.18;mn.gx=lerp(mn.gx,tx,k);mn.gy=lerp(mn.gy,ty,k);
  for(const e of E){const ox=mn.gx*1.2,oy=mn.gy*1.3,h=v=>Math.round(v*2)/2;
   g.fillStyle=MC.pup;g.fillRect(h(e[0]-.75+ox),h(e[1]-1+oy),1.5,2);
   g.fillStyle='#1f5a33';g.fillRect(h(e[0]-.75+ox),h(e[1]+1+oy),1.5,.5);
   g.fillStyle='#e8fff0';g.fillRect(h(e[0]-1.5+ox*.4),h(e[1]-1.9+oy*.4),1,.5);g.fillRect(h(e[0]-1.5+ox*.4),h(e[1]-1.4+oy*.4),.5,.5)}
  if(op>.25){const m0=lx(4.9,10+op*.7),m1=lx(8.1,10+op*.7);px(m0[0],m0[1],1,1,MC.claw);px(m1[0],m1[1],1,1,MC.claw)}
  for(const [bx,sd,k2] of[[4.6,-1,0],[8.6,1,1.7]]){const p=lx(bx,.4),w1=Math.sin(t*2.2+k2)*.9,w2=Math.sin(t*1.7+k2)*1.5,
   pts=sd<0?[p,[p[0]-2.5,p[1]-7+w1*.3],[p[0]-7.6+w1,p[1]-13.8],[p[0]-12.8+w2,p[1]-16.3+w1]]:[p,[p[0]+5.5,p[1]-8+w1*.3],[p[0]+10+w1,p[1]-12],[p[0]+16+w2,p[1]-14+w1]];
   for(let i=0;i<3;i++)line(pts[i][0],pts[i][1],pts[i+1][0],pts[i+1][1],i==2?shd(MC.ant,.25):MC.ant)}}
}
// кормовые в боковом виде для сцены богомола: мв — идёт ли сейчас (лапы шевелятся только на ходу)
function roachSide(x,y,s,t,mv,k){const I=INS[k],arg=k==='arg',B=y-4.4*s,ph=t*13,pr=arg?'#9a7a46':'#e0a040',dk=shd(I.c1,-.25),lg=arg?'#3a281c':I.c1;
 const leg=(i,far)=>{const q=ph+i*2.1+(far?Math.PI:0),sw=mv?Math.sin(q):0,lf=mv?Math.max(0,Math.cos(q)):0,ox=(i-1)*3.4*s,
  H=[x+ox,B+1.4*s],K=[x+ox+(i-1)*2.4*s+sw*.8*s,y-3.9*s-lf*1.2*s],F=[x+ox+(i-1)*3.7*s*.9+sw*1.6*s,y-lf*1.3*s],c=far?shd(lg,-.3):lg;
  line(H[0],H[1],K[0],K[1],c);line(K[0],K[1],F[0],F[1],c);px(K[0],K[1]-1,1,1,far?c:shd(I.c3,-.1));px(F[0],F[1],1,1,I.c1);if(!far){px((K[0]+F[0])/2+1,(K[1]+F[1])/2,1,1,shd(lg,.35))}};
 for(let i=0;i<3;i++)leg(i,1);
 rEll(x+.5*s,y+.8,6.4*s,1,0,'rgba(30,20,10,.2)');
 rEll(x,B,6.5*s,3.9*s,0,dk);rEll(x,B,6*s,3.4*s,0,I.c2);
 rEll(x-1.3*s,B-.4*s,4.9*s,2.9*s,0,shd(I.c2,.1));rEll(x-1.6*s,B-1.4*s,3.8*s,1.1*s,0,I.c3);
 line(x-5*s,B+.6*s,x+2*s,B-1.8*s,dk);
 for(let i=0;i<3;i++){const ax=x-5.4*s+i*.9*s;line(ax,B+1.6*s,ax+.5,B+3*s,dk)}
 rEll(x+4.5*s,B-.6*s,2.9*s,2.9*s,0,pr);rEll(x+4.4*s,B-.5*s,2.4*s,2.4*s,0,I.c2);rEll(x+4*s,B-1.3*s,1.5*s,1*s,0,I.c3);px(x+4*s,B+.2*s,1,1,dk);
 rEll(x+7*s,B+1*s,1.7*s,1.5*s,0,dk);px(x+7.7*s,B+.3*s,1,1,'#f2d9a0');px(x+7.4*s,B+.5*s,1,1,'#080403');px(x+8.2*s,B+2.2*s,1,1,shd(I.c2,.2));
 const wig=Math.sin(t*(mv?5:10))*1.1,w2=Math.sin(t*(mv?4:8)+1.7)*1.2,p0=[x+8.3*s,B+.1*s],p1=[p0[0]+2.6*s,p0[1]-2.3*s+wig],p2=[p1[0]+3*s,p1[1]-1.4*s+w2];
 line(p0[0],p0[1],p1[0],p1[1],lg);line(p1[0],p1[1],p2[0],p2[1],lg);px(p1[0],p1[1],1,1,shd(lg,.4));
 for(const d of[-.6,.9]){line(x-6.3*s,B+d*s,x-8.6*s,B+d*s*1.6,lg)}
 for(let i=0;i<3;i++)leg(i,0)}
function cricketSide(x,y,s,t,mv){const c1='#6b4a24',c2='#a8844a',c3='#c9a468',dk='#3a2812',B=y-4.2*s,ph=t*13;
 const th=(hx,hy,kx,ky,fx,fy,sw,far)=>{const c=far?shd(c2,-.3):c2,d=far?shd(c1,-.3):c1;caps([hx,hy],[kx,ky],1.2*s,.9*s,c);line(kx,ky,fx+sw,fy,d);px(fx+sw-1,fy,2,1,dk)};
 const sw=i=>mv?Math.sin(ph+i*2.1)*1.5*s:0;
 th(x+3.5*s,B+1.2*s,x+6.2*s,y-3*s,x+7*s,y,sw(2),1);th(x+.8*s,B+1.4*s,x+2.6*s,y-3.2*s,x+3*s,y,sw(0),1);
 line(x-1.5*s,B+1*s,x-5.4*s,B-2.6*s,shd(c2,-.3));line(x-5.4*s,B-2.6*s,x-1.4*s+sw(1),y,shd(c1,-.3));
 rEll(x+.5*s,y+.8,6*s,1,0,'rgba(30,20,10,.2)');
 for(const d of[-.5,.8]){line(x-5.6*s,B+d*s,x-9*s,B+d*s*1.8-.5,c1)} // церки
 rEll(x,B,5.7*s,2.7*s,0,dk);rEll(x,B,5.2*s,2.3*s,0,c2);rEll(x-.2*s,B+.7*s,4.6*s,1.1*s,0,shd(c2,-.18));
 for(let i=0;i<4;i++){const ax=x-4.6*s+i*1.1*s;line(ax,B+.4*s,ax,B+2*s,shd(c2,-.3))}
 rEll(x-1.4*s,B-.8*s,4.4*s,1.7*s,0,shd(c1,.04));rEll(x-1.6*s,B-1.3*s,3.4*s,.7*s,0,c3);
 for(let i=0;i<4;i++){const ax=x-4.4*s+i*1.8*s;line(ax,B-.4*s,ax+1.2*s,B-1.6*s,dk)}
 rEll(x+3.3*s,B-.9*s,1.8*s,1.9*s,0,shd(c1,.12));
 rEll(x+5.8*s,B-.2*s,2.1*s,2.2*s,0,c1);rEll(x+6.5*s,B-.9*s,.9*s,1*s,0,'#150a05');px(x+6.2*s,B-1.4*s,1,1,'#f2d9a0');px(x+7.6*s,B+1.6*s,1,1,dk);px(x+6.8*s,B+1.8*s,1,1,c3);
 const w1=Math.sin(t*(mv?5:9))*1.3,w2=Math.sin(t*(mv?4:7)+1.4)*1.8,p0=[x+7.4*s,B-1.3*s],p1=[p0[0]+3*s,p0[1]-3*s+w1],p2=[p1[0]+4*s,p1[1]-2.4*s+w2],p3=[p2[0]+3.4*s,p2[1]-1*s+w1];
 line(p0[0],p0[1],p1[0],p1[1],c1);line(p1[0],p1[1],p2[0],p2[1],c1);line(p2[0],p2[1],p3[0],p3[1],shd(c1,.2));
 th(x+3.4*s,B+1.4*s,x+6*s,y-2.7*s,x+7.2*s,y,sw(1),0);th(x+.9*s,B+1.4*s,x+2.4*s,y-3*s,x+3.3*s,y,sw(2),0);
 // задняя прыгательная нога: толстое бедро с полоской, голень с шипиками
 caps([x-1.4*s,B+1*s],[x-5.2*s,B-2.4*s],1.9*s,1.3*s,c2);caps([x-1.8*s,B+.4*s],[x-4.8*s,B-2.6*s],.6*s,.4*s,c3);
 const kx=x-5.2*s,ky=B-2.4*s,fx=x-1.2*s+sw(0),fy=y;line(kx,ky,fx,fy,c1);for(let i=1;i<5;i++){const k=i/5;px(kx+(fx-kx)*k+1,ky+(fy-ky)*k,1,1,c3)}px(fx-1,fy,3,1,dk);px(kx,ky-1,1,1,dk)}
function drawPreyM(o){const k=o.k,s=(k==='cri'?.95:k==='turk'?.9:1.05)*(1-o.p*.85),x=Math.round(o.x),y=Math.round(o.y)+1,mv=o.mv!==false&&st!=='lunge'&&st!=='chew';
 if(k==='cri')cricketSide(x,y,s,T,mv);else roachSide(x,y,s,T,mv,k)}
function drawMantisScene(card){
 mnScene();const fat=card?.75:.35+.65*D.sat/100,pr=card?null:prey;
 if(pr&&(st==='approach'||st==='stalk'||st==='freeze'))drawPreyM(pr);
 {const f=card?1:stageF(D),pv=[82,80];g.save();if(f!==1){g.translate(pv[0],pv[1]);g.scale(f,f);g.translate(-pv[0],-pv[1])}const pa=pr&&(st==='freeze'||st==='lunge'||st==='chew')?pr:null,ai=pa&&f!==1?{x:pv[0]+(pa.x-pv[0])/f,y:pv[1]+(pa.y-pv[1])/f}:pa;mnDraw(card?0:T,card?.06:mn.lean,card?0:mn.ext,card?0:mn.chew,ai,fat,card);g.restore()}
 if(pr&&(st==='lunge'||st==='chew'))drawPreyM(pr);
 if(pr&&st==='drop'){g.save();g.globalAlpha=Math.max(0,Math.min(1,1-(pr.y-102)/16));g.translate(pr.x,pr.y);g.rotate(pr.rot);g.translate(-pr.x,-pr.y);drawPreyM(pr);g.restore()}
 if(!card)for(const f of fx)(f.bad?drawDrop:drawHeart)(Math.round(f.x),Math.round(f.y),'#ff5a7a');if(!card&&decEdit)mnEditOverlay()}
function mantisStep(dt){const e=Math.min(1,dt*4);
 const lt=st==='approach'?.08:st==='stalk'?.14:st==='freeze'?.2:st==='lunge'?.32:st==='chew'?.05+Math.sin(T*18)*.012:0;
 mn.lean=lerp(mn.lean,lt+(twitch>0?Math.sin(T*40)*.05:0),e);
 mn.ext=st==='lunge'?lerp(mn.ext,1,Math.min(1,dt*16)):lerp(mn.ext,st==='freeze'?.25:0,Math.min(1,dt*6));mn.chew=lerp(mn.chew,st==='chew'?1:0,Math.min(1,dt*10));
 if(prey&&st!=='approach')prey.mv=false;
 if(st==='approach'){if(prey.pause>0){prey.pause-=dt;prey.mv=false}else{prey.mv=true;prey.x+=24*dt;prey.y=mnBY(prey.x)-2;const sx=prey.stops[prey.si];if(sx!==undefined&&prey.x>=sx){prey.x=sx;prey.si++;prey.pause=.6+Math.random()*.5}}
  if(prey.x>=prey.tx){prey.x=prey.tx;prey.mv=false;go('stalk','m_stalk')}}
 else if(st==='stalk'){if(tm>.6)go('freeze','m_freeze')}
 else if(st==='freeze'){if(tm>.7)go('lunge','m_lunge')}
 else if(st==='lunge'){if(tm>.18)go('chew','m_chew')}
 else if(st==='chew'){prey.p=.55*Math.min(1,tm/1.5);const k=Math.min(1,dt*10);prey.x=lerp(prey.x,82+(mn.hx-82)*stageF(D),k);prey.y=lerp(prey.y,80+(mn.hy-80)*stageF(D),k);
  if(tm>1.6){prey.vy=0;prey.vx=-5;prey.rot=0;go('drop','m_leave')}}
 else if(st==='drop'){prey.vy+=190*dt;prey.y+=prey.vy*dt;prey.x+=prey.vx*dt;prey.rot+=dt*5;
  if(prey.y>120){prey=null;D.sat=Math.min(100,D.sat+feedPts());D.mood=over?Math.max(0,D.mood-25):Math.min(100,D.mood+15);D.eaten++;save();
   for(let i=0;i<4;i++)fx.push({x:50+i*10,y:30-i%2*8,l:1.4,bad:over});go('idle',over?'m_over':'m_ok')}}}
