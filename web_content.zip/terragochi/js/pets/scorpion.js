// Питомец-скорпион (императорский, Pandinus imperator; ключ вида scorpion3). Рисунок — готовые спрайты assets/img/scorpion3_*.png: кадры 96×96 в ряд, вид сверху, голова вниз.
// Рост, линьки, сытость и корма — по правилам птицеедов (isSpd в js/game/state.js), здесь только картинка и движение.
// Кормёжка: добыча выходит снизу → скорпион идёт вниз (ходьба) → съедает (12 кадров) → разворот на 180° → идёт обратно вверх → разворот → покой.
const SCSRC={'3idle':'assets/img/scorpion3_idle.png','3walk':'assets/img/scorpion3_walk.png','3turn':'assets/img/scorpion3_turn.png','3eat':'assets/img/scorpion3_eat.png'};
const SCFR=96,SCS=.75,SCSTR=16,SCWD=26; // кадр; масштаб (1 пиксель спрайта = 3 экранных); шаг за цикл ходьбы (в пикселях спрайта); путь вниз до добычи
const SCPY=[82,82,91,91,90,82,75,74,74,74,null,null]; // где в кадре поедания центр добычи (строка), null — добычи уже нет
const SCE=[[0,.3],[1,.1],[2,.1],[3,.12],[4,.12],[5,.18],[6,.2]],SCT=[]; // порядок и длительность кадров поедания (сек)
for(let i=0;i<12;i++)SCE.push([7+[0,1,2,1][i%4],.12]); // жуёт: кадры 8-9-10-9, 12 шагов
SCE.push([10,.2],[11,.25]);
{let a=0;for(const q of SCE){a+=q[1];SCT.push(a)}}
const SCIM={};for(const k in SCSRC){const im=new Image();im.onload=()=>{try{if(cur==='pick')renderPick()}catch(e){}};im.src=SCSRC[k];SCIM[k]=im}
const sc={x:64,y:48,k:'idle',i:0,up:false,ph:0};
// геометрия по размеру: s — масштаб, home — центр в покое, ye — центр при поедании, py — где стоит добыча
const scGeo=f=>{const s=SCS*f,home=Math.round(36+12*f),ye=home+SCWD;return{s,home,ye,py:ye+34*s}};
const scPrey0=()=>({x:64+Math.random()*24-12,y:150,tx:64,ty:scGeo(stageF(D)).py});
// кадр i листа kind; (cx,cy) — центр кадра, up — повернуть на 180° (ходьба вверх)
function scFrame(kind,i,cx,cy,s,up,sp){const im=SCIM['3'+kind];if(!im||!im.complete||!im.naturalWidth)return;
 const w=SCFR*s,k=g.getTransform().a*s;
 g.save();g.imageSmoothingEnabled=k<2;g.imageSmoothingQuality='high';
 g.translate(Math.round(cx*4)/4,Math.round(cy*4)/4);if(up)g.rotate(Math.PI);
 g.drawImage(im,i*SCFR,0,SCFR,SCFR,-w/2,-w/2,w,w);g.restore()}
// добыча бежит снизу вверх: насекомое нарисовано головой вниз, поэтому разворачиваем на 180°
function scPrey(o){const x=Math.round(o.x),y=Math.round(o.y);g.save();g.translate(x,y);g.rotate(Math.PI);g.translate(-x,-y);drawPrey(o);g.restore()}
function scorpionDraw(){const G=scGeo(stageF(D));if(prey)scPrey(prey);scFrame(sc.k,sc.i,sc.x,sc.y,G.s,sc.up,S.species)}
function scorpionStill(d,tt,sp){const G=scGeo(stageF(d));scFrame('idle',Math.floor((tt||0)*5)%6,64,G.home,G.s,false,sp)} // карточка выбора питомца
function scorpionBox(ctx,tt,sp){onCtx(ctx,()=>scFrame('idle',Math.floor(tt*5)%6,20,27,.5,false,sp))} // банка в магазине
function scorpionStep(dt){const G=scGeo(stageF(D)),s=G.s,cyc=Math.max(.8,Math.min(2.5,22/(SCSTR*s))),v=cyc*SCSTR*s;
 if(st==='idle'){const fps=D.sat<30?7:D.sat>85?3.5:5;sc.k='idle';sc.i=Math.floor(T*fps)%6;sc.x=64+(twitch>0?Math.sin(T*70)*1.2:0);sc.y=G.home;sc.up=false}
 else if(st==='approach'){sc.k='idle';sc.i=Math.floor(T*7)%6;sc.x=64;sc.y=G.home;sc.up=false;
  const dx=prey.tx-prey.x,dy=prey.ty-prey.y,dd=Math.hypot(dx,dy),stp=Math.min(dd,44*dt);if(dd>1){prey.x+=dx/dd*stp;prey.y+=dy/dd*stp}
  if(dd-stp<=1){sc.ph=0;go('stalk','m_stalk')}}
 else if(st==='stalk'){sc.ph+=cyc*dt;sc.k='walk';sc.i=Math.floor(sc.ph*8)%8;sc.up=false;sc.x=64;sc.y=Math.min(G.ye,sc.y+v*dt);
  if(sc.y>=G.ye-.01){sc.y=G.ye;go('eat','m_chew')}}
 else if(st==='eat'){const j=SCT.findIndex(x=>tm<x),fi=SCE[j<0?SCE.length-1:j][0];sc.k='eat';sc.i=fi;sc.x=64;sc.y=G.ye;sc.up=false;
  if(prey){const py=SCPY[fi];if(py===null)prey=null;else{const q=Math.min(1,dt*30);prey.x=lerp(prey.x,64,q);prey.y=lerp(prey.y,G.ye+(py-48)*s,q);prey.p=fi<5?0:fi<6?.5:.8}}
  if(tm>=SCT[SCT.length-1]){prey=null;go('turn','m_turn')}}
 else if(st==='turn'||st==='turn2'){const i=Math.min(8,Math.floor(Math.min(1,tm/.9)*9));sc.k='turn';sc.i=st==='turn'?i:8-i;sc.x=64;sc.y=st==='turn'?G.ye:G.home;sc.up=false;
  if(tm>=.9){if(st==='turn'){sc.ph=0;go('return','m_ret')}else{
   D.sat=Math.min(100,D.sat+feedPts());D.mood=over?Math.max(0,D.mood-25):Math.min(100,D.mood+15);D.eaten++;save();
   for(let i=0;i<4;i++)fx.push({x:sc.x-16+i*10,y:sc.y-14-i%2*8,l:1.4,bad:over});go('idle',over?'m_over':'m_ok')}}}
 else if(st==='return'){sc.ph+=cyc*dt;sc.k='walk';sc.i=Math.floor(sc.ph*8)%8;sc.up=true;sc.x=64;sc.y=Math.max(G.home,sc.y-v*dt);
  if(sc.y<=G.home+.01){sc.y=G.home;go('turn2','m_turn')}}}
