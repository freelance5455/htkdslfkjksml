// Звуки интерфейса: нажатие кнопки и покупка (файлы assets/audio/*.mp3, в релиз встраиваются сами)
// Громкость каждого звука — число в SFX.vol (1 = как в файле). Покупка определяется по тому, что после нажатия стало меньше монет.
// Надёжность на телефонах/в WebView: файл читается без fetch (data-URI -> байты), контекст «будится» прямо внутри касания,
// а если WebAudio не сработал — играет обычный <audio>.
const SFX={on:true,ctx:null,buf:{},vol:{click:.35,buy:.8},src:{click:'assets/audio/click.mp3',buy:'assets/audio/buy.mp3'},pool:{}};
try{if(localStorage.getItem('spiderSfx')==='0')SFX.on=false}catch(e){}
function sfxBytes(u){if(u.slice(0,5)==='data:'){const b=atob(u.slice(u.indexOf(',')+1)),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return Promise.resolve(a.buffer)}return fetch(u).then(r=>r.arrayBuffer())}
function sfxDecode(k){const c=SFX.ctx;if(!c)return;sfxBytes(SFX.src[k]).then(b=>new Promise((ok,no)=>{const r=c.decodeAudioData(b,ok,no);if(r&&r.catch)r.catch(no)})).then(b=>{SFX.buf[k]=b}).catch(()=>{})}
function sfxInit(){if(SFX.ctx)return;const C=window.AudioContext||window.webkitAudioContext;if(!C)return;try{SFX.ctx=new C()}catch(e){SFX.ctx=null;return}
 for(const k in SFX.src)sfxDecode(k)}
// будим контекст синхронно внутри касания (iOS/Telegram разрешают звук только так)
function sfxWake(){if(!SFX.ctx)sfxInit();const c=SFX.ctx;if(c&&c.state!=='running'){try{const r=c.resume();if(r&&r.catch)r.catch(()=>{})}catch(e){}}}
function sfxAudio(k){try{let a=SFX.pool[k];if(!a){a=SFX.pool[k]=new Audio(SFX.src[k]);a.preload='auto'}a.volume=Math.min(1,SFX.vol[k]);a.currentTime=0;const r=a.play();if(r&&r.catch)r.catch(()=>{})}catch(e){}}
function sfx(k){if(!SFX.on)return;const c=SFX.ctx,b=SFX.buf[k];
 if(!c||!b||c.state!=='running'){sfxAudio(k);return}
 try{const s=c.createBufferSource(),gn=c.createGain();gn.gain.value=SFX.vol[k];s.buffer=b;s.connect(gn);gn.connect(c.destination);s.start()}catch(e){sfxAudio(k)}}
sfxInit();
// первое касание/клик в любом виде будит звук (на телефоне засчитывается отпускание пальца)
['pointerup','touchend','click','keydown'].forEach(e=>document.addEventListener(e,sfxWake,{passive:true,capture:true}));
// любая нажатая (не отключённая) кнопка: после её обработчика смотрим, потратились ли монеты → «покупка», иначе «клик»
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('button');if(!b||b.disabled)return;const c0=S.coins;sfxWake();
 setTimeout(()=>sfx(S.coins<c0?'buy':'click'),0)},true);
// Настройки: отдельный выключатель звуков интерфейса (музыка — в music.js)
function paintSfx(){$('sSfx').textContent=t(SFX.on?'sfx_on':'sfx_off')}
$('sSfx').onclick=()=>{SFX.on=!SFX.on;try{localStorage.setItem('spiderSfx',SFX.on?'1':'0')}catch(e){}paintSfx()};
paintSfx();
