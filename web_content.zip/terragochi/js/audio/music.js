// Фоновая музыка (генерируется через WebAudio, файлов нет)
// Слои: тёплый «пэд» из аккордов, арпеджио, редкие «колокольчики» мелодии, тихий ночной шум и далёкие сверчки.
// Структура: 8 аккордов (часть A + часть B), цикл ~26 секунд.
const MU={ctx:null,on:true,timer:0,nxt:0,step:0,out:null,master:null};
try{if(localStorage.getItem('spiderMusic')==='0')MU.on=false}catch(e){}
const mf=m=>440*Math.pow(2,(m-69)/12),
 CH=[[60,64,67,71],[57,60,64,67],[53,57,60,64],[55,59,62,64],[50,53,57,60],[52,55,59,62],[53,57,60,64],[55,60,62,67]],
 BS=[36,33,29,31,38,40,29,31],AP=[0,2,1,3,2,1,3,2],PENT=[72,74,76,79,81,84,86],
 mh=n=>(Math.imul(n^0x9e37,2246822519)>>>0)>>>9;
function setupAudio(){const c=MU.ctx;MU.out=c.createGain();const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1700;
 const dl=c.createDelay(1);dl.delayTime.value=.42;const fb=c.createGain();fb.gain.value=.38;const wet=c.createGain();wet.gain.value=.35;
 MU.master=c.createGain();MU.master.gain.value=0;MU.out.connect(lp);lp.connect(MU.master);lp.connect(dl);dl.connect(fb);fb.connect(dl);dl.connect(wet);wet.connect(MU.master);MU.master.connect(c.destination);
 // ночной шум (ветер/влажный воздух): мягкий, медленно «дышит»
 const nb=c.createBuffer(1,c.sampleRate*2,c.sampleRate),d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 const ns=c.createBufferSource();ns.buffer=nb;ns.loop=true;const nf=c.createBiquadFilter();nf.type='lowpass';nf.frequency.value=380;
 const ng=c.createGain();ng.gain.value=.014;const lf=c.createOscillator();lf.frequency.value=.07;const lg=c.createGain();lg.gain.value=.009;
 lf.connect(lg);lg.connect(ng.gain);ns.connect(nf);nf.connect(ng);ng.connect(MU.master);ns.start();lf.start()}
function tone(type,f,t0,dur,vol,att){const c=MU.ctx,o=c.createOscillator(),gn=c.createGain();o.type=type;o.frequency.value=f;
 gn.gain.setValueAtTime(0,t0);gn.gain.linearRampToValueAtTime(vol,t0+att);gn.gain.exponentialRampToValueAtTime(.0001,t0+dur);o.connect(gn);gn.connect(MU.out);o.start(t0);o.stop(t0+dur+.05)}
function bell(f,t,dur,vol){tone('sine',f,t,dur,vol,.012);tone('sine',f*2,t,dur*.45,vol*.22,.01)}
function musStep(n,t){const ci=Math.floor(n/8)%8,ch=CH[ci],j=n%8,h=mh(n),pad=n===0?.5:1.4;
 // пэд и бас: смена аккорда каждые 8 шагов
 if(j===0){for(const m of ch){tone('triangle',mf(m),t,5,.035,pad);tone('sine',mf(m)*1.004,t,5,.025,pad+.2)}tone('sine',mf(BS[ci]),t,3.4,.12,.08)}
 // арпеджио
 if((n*7)%11!==0)tone('triangle',mf(ch[AP[j]]+12*(j%3===2?2:1)),t,1.1,.05,.01);
 // мелодия-«колокольчики»: в части A редко, в части B чаще; последняя нота аккорда тянется дольше
 if(n>=8&&j%2===1&&h%(ci<4?4:3)===0)bell(mf(PENT[h%7]),t,j===7?2.6:1.7,.032);
 // далёкие сверчки: три тихих щелчка раз в ~10 секунд
 if(n%24===13)for(let k=0;k<3;k++)tone('sine',4300+k*70,t+k*.1,.07,.006,.006)}
function musPump(){const c=MU.ctx;if(!c||c.state!=='running')return;if(MU.nxt<c.currentTime)MU.nxt=c.currentTime+.05;
 while(MU.nxt<c.currentTime+.8){musStep(MU.step,MU.nxt);MU.nxt+=.4;MU.step++}}
// запускает расписание, как только контекст реально «заговорил» (после разрешения браузера)
function musKick(){const c=MU.ctx;if(!c||!MU.on||c.state!=='running'||MU.timer)return;MU.nxt=c.currentTime+.05;MU.timer=setInterval(musPump,200);musPump()}
function musicStart(){if(!MU.on)return;const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
 if(!MU.ctx){try{MU.ctx=new C();setupAudio();MU.ctx.onstatechange=musKick}catch(e){MU.ctx=null;return}}
 MU.master.gain.setTargetAtTime(.5,MU.ctx.currentTime,.3);
 if(MU.ctx.state!=='running')MU.ctx.resume().then(musKick,()=>{});else musKick()}
function musicStop(){if(!MU.ctx)return;MU.master.gain.setTargetAtTime(0,MU.ctx.currentTime,.25);clearInterval(MU.timer);MU.timer=0;setTimeout(()=>{if(!MU.on&&MU.ctx)MU.ctx.suspend()},1200)}
// Браузеры разрешают звук только после касания, а на телефоне касание засчитывается, когда палец ОТПУЩЕН (pointerup/touchend/click),
// поэтому слушаем именно их, а не pointerdown. Слушатели остаются навсегда: если система «усыпит» звук, следующее касание его разбудит.
const musUnlock=()=>{if(!MU.on)return;if(!MU.ctx)musicStart();else if(MU.ctx.state!=='running')MU.ctx.resume().then(musKick,()=>{});else if(!MU.timer)musKick()};
['pointerup','touchend','click','keydown'].forEach(e=>document.addEventListener(e,musUnlock,{passive:true,capture:true}));
document.addEventListener('visibilitychange',()=>{if(!MU.ctx)return;if(document.hidden)MU.ctx.suspend();else if(MU.on)MU.ctx.resume().then(musKick,()=>{})});
// попытка начать сразу при загрузке (в некоторых оболочках, например Telegram, звук разрешён без касания); если нельзя — начнётся с первого касания
musicStart();
function paintMus(){$('sMus').textContent=t(MU.on?'mus_on':'mus_off')}
$('sMus').onclick=()=>{MU.on=!MU.on;try{localStorage.setItem('spiderMusic',MU.on?'1':'0')}catch(e){}if(MU.on)musicStart();else musicStop();paintMus()};

