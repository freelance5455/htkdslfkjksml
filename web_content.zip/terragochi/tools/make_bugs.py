#!/usr/bin/env python3
"""Кормовые насекомые (аргентинский и туркменский таракан, сверчок) из фото tools/src/bugs_ref.png -> assets/img/bug_arg|turk|cri.png.
Запуск: python3 tools/make_bugs.py   (нужны Pillow, numpy, scipy; --preview сохраняет контрольный лист в tools/src/bugs_preview.png)

Что делает: вырезает насекомое из фото, делит на ТЕЛО (статично), ЛАПЫ (каждая — отдельный кусок, качается вокруг «бедра») и УСИКИ,
поворачивает на 180° (голова вниз), уменьшает в F раз до пиксель-арта и собирает ленту кадров в один ряд:
  кадр 0 — тело, кадры 1..N — лапы (цикл ходьбы), кадры N+1..N+M — усики (покачивание).
В игре (js/render/prey.js) три слоя рисуются друг на друга: лапы -> тело -> усики, у лап и усиков свой темп."""
import sys, math, pathlib
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / 'tools/src/bugs_ref.png'
K = .75         # размер пикселя спрайта в пикселях игры (должен совпадать с BUG_K в js/render/prey.js)
LEN = {'arg': 17, 'turk': 12, 'cri': 9}   # длина тела (без усиков, лап и церок) в пикселях игры
THR = {'arg': (.45, .3, .2), 'turk': (.4, .2, .12), 'cri': (.35, .15, .08)}   # порог заметности пикселя: тело, лапы, усики (у мелких тоньше линии)
GAIN = {'cri': 1.2}   # подсветка цвета: у совсем мелкого сверчка на грунте иначе не разглядеть
F = 10          # во сколько раз уменьшаем фото (1 пиксель спрайта = F пикселей фото); считается под LEN
N, M = 8, 8     # кадров лап / усиков
BOX = {'arg': (100, 505, 140, 820), 'turk': (580, 965, 140, 830), 'cri': (1060, 1435, 150, 835)}   # x0,x1,y0,y1 на фото
LEG = {'arg': (9, 14), 'turk': (9, 14), 'cri': (8, 10)}   # размах лапы: угол (°) и сдвиг вдоль тела (пикселей фото)
REAR = (4, 6)        # задние прыгательные ноги сверчка качаются слабее
ANT = 4.5            # размах усиков, °

A = np.array(Image.open(SRC).convert('RGB')).astype(int)

def disk(r):
    y, x = np.ogrid[-r:r + 1, -r:r + 1]; return x * x + y * y <= r * r

def big(mask):
    lab, n = ndi.label(mask); s = ndi.sum(mask, lab, range(1, n + 1)); return lab == 1 + int(np.argmax(s))

def segment(k):
    """-> картинка, тело, лапы [(маска, бедро, сторона, номер, (угол, сдвиг))], усики [(маска, основание, сторона)]"""
    x0, x1, y0, y1 = BOX[k]; c = A[y0:y1, x0:x1]
    al = ndi.binary_closing(c.max(2) > 22, iterations=1)
    H, W = al.shape; yy, xx = np.mgrid[0:H, 0:W]
    legs, ants = [], []
    if k != 'cri':
        body = big(ndi.binary_opening(al, structure=disk(18))); blen = np.ptp(np.where(body.any(1))[0]) + 1
        by = np.where(body.any(1))[0]; bx = np.where(body.any(0))[0]; cx = (bx.min() + bx.max()) / 2; top = by.min()
        lab, n = ndi.label(al & ~body, structure=np.ones((3, 3)))
        pairs = []
        for i in range(1, n + 1):
            m = lab == i; ys, xs = np.where(m)
            if m.sum() < 400: body |= m; continue
            if ys.min() < top - 60:                      # усики (слиплись с головой)
                head = m & (yy > top - 45) & (abs(xx - cx) < 40); body |= head; m = m & ~head
                for side, mm in ((-1, m & (xx < cx)), (1, m & (xx >= cx))):
                    if mm.any(): ants.append((mm, side))
            else: pairs.append((m, int(np.sign(xs.mean() - cx)), ys.mean()))
        ys_sorted = sorted({round(p[2] / 40) for p in pairs})
        for m, side, my in pairs:
            idx = min(range(len(ys_sorted)), key=lambda j: abs(ys_sorted[j] - round(my / 40)))
            legs.append((m, side, idx, LEG[k]))
    else:
        body = big(ndi.binary_opening(al, structure=disk(9))); blen = np.ptp(np.where(body.any(1))[0]) + 1
        bx = np.where(body.any(0))[0]; cx = (bx.min() + bx.max()) / 2
        rest = al & ~body; lab, n = ndi.label(rest, structure=np.ones((3, 3)))
        sizes = ndi.sum(rest, lab, range(1, n + 1)); order = np.argsort(-sizes)
        parts = {}
        for r, i in enumerate(order[:5]): parts[r] = lab == i + 1
        for i in order[5:]: body |= lab == i + 1
        big_ = parts[0]
        # усики: два куска сверху; остальное — по областям (координаты вырезки)
        cand = [parts[r] for r in range(1, 5)]
        tops = sorted(cand, key=lambda m: np.where(m)[0].min())
        for m in tops[:2]:
            ys, xs = np.where(m); ants.append((m, -1 if xs.mean() < cx else 1))
        for m in tops[2:]:                                # передние лапы
            ys, xs = np.where(m); legs.append((m, -1 if xs.mean() < cx else 1, 0, LEG[k]))
        lx, rx = 140, 232
        mid_l = big_ & (xx < lx) & (yy <= 375); mid_r = big_ & (xx >= rx - 6) & (yy <= 375)
        rear_l = big_ & (xx < lx) & (yy > 375); rear_r = big_ & (xx >= rx) & (yy > 375)
        for m, side, i, a in ((mid_l, -1, 1, LEG[k]), (mid_r, 1, 1, LEG[k]), (rear_l, -1, 2, REAR), (rear_r, 1, 2, REAR)):
            if m.any(): legs.append((m, side, i, a))
        body |= big_ & ~(mid_l | mid_r | rear_l | rear_r)
    dist = ndi.distance_transform_edt(~body)
    L = []
    for m, side, idx, amp in legs:
        d = dist[m]; sel = m & (dist <= d.min() + 5); ys, xs = np.where(sel)
        L.append((m, (xs.mean(), ys.mean()), side, idx, amp))
    Aa = []
    for m, side in ants:
        ys, xs = np.where(m); j = np.argmax(ys); Aa.append((m, (xs[j], ys[j]), side))
    return c, body, L, Aa, blen

def layer_rgba(c, m, shape):
    """RGBA-слой по маске; цвет вне маски = средний цвет (чтобы при повороте не появлялось тёмной каймы)"""
    rgb = np.zeros(shape + (3,), np.uint8); rgb[:] = c[m].mean(0).astype(np.uint8); rgb[m] = c[m]
    a = (m * 255).astype(np.uint8); return Image.fromarray(np.dstack([rgb, a]), 'RGBA')

def pixelate(img, thr):
    """RGBA полного размера -> пиксель-арт: усреднение блоков F×F, альфа жёсткая (порог thr)"""
    a = np.array(img).astype(float); a = a[::-1, ::-1]        # поворот на 180°: голова вниз
    h, w = a.shape[:2]; al = a[..., 3] / 255
    pre = (a[..., :3] * al[..., None]).reshape(h // F, F, w // F, F, 3).sum((1, 3))
    aa = al.reshape(h // F, F, w // F, F).sum((1, 3)); cov = aa / (F * F)
    out = np.zeros((h // F, w // F, 4), np.uint8)
    ok = cov >= thr; out[ok, :3] = np.clip(pre[ok] / aa[ok][:, None] * GAIN.get(KEY, 1), 0, 255).astype(np.uint8); out[ok, 3] = 255
    return out

def build(k):
    global F, KEY
    KEY = k
    c, body, legs, ants, blen = segment(k); H, W = body.shape
    F = max(1, round(blen * K / LEN[k])); tb, tl, ta = THR[k]
    Hp, Wp = -(-H // F) * F, -(-W // F) * F
    pad = lambda im: (lambda b: (b.paste(im, (0, 0)), b)[1])(Image.new('RGBA', (Wp, Hp), (0, 0, 0, 0)))
    base = pad(layer_rgba(c, body, (H, W)))
    legl = [(pad(layer_rgba(c, m, (H, W))), hip, side, idx, amp) for m, hip, side, idx, amp in legs]
    antl = [(pad(layer_rgba(c, m, (H, W))), b, side) for m, b, side in ants]
    cells = [pixelate(base, tb)]
    for f in range(N):
        ph = 2 * math.pi * f / N; lay = Image.new('RGBA', (Wp, Hp), (0, 0, 0, 0))
        for im, hip, side, idx, (ang, sh) in legl:
            p = ph + (math.pi if (idx + (side > 0)) & 1 else 0)   # шаг «треногой»: соседние лапы в противофазе
            r = im.rotate(side * ang * math.sin(p), resample=Image.BICUBIC, center=hip, translate=(0, -sh * math.sin(p)))
            lay = Image.alpha_composite(lay, r)
        cells.append(pixelate(lay, tl))
    for f in range(M):
        ph = 2 * math.pi * f / M; lay = Image.new('RGBA', (Wp, Hp), (0, 0, 0, 0))
        for im, b, side in antl:
            lay = Image.alpha_composite(lay, im.rotate(ANT * math.sin(ph + side * 1.7), resample=Image.BICUBIC, center=b))
        cells.append(pixelate(lay, ta))
    by = np.where(body.any(1))[0]; bx = np.where(body.any(0))[0]
    ax, ay = (Wp - (bx.min() + bx.max() + 1) / 2) / F, (Hp - (by.min() + by.max() + 1) / 2) / F   # центр тела после поворота
    sheet = np.concatenate(cells, 1)
    return Image.fromarray(sheet, 'RGBA'), (Wp // F, Hp // F, round(ax, 1), round(ay, 1))

if __name__ == '__main__':
    prev = []
    for k in BOX:
        im, (w, h, ax, ay) = build(k); out = ROOT / f'assets/img/bug_{k}.png'; im.save(out, optimize=True)
        print(f'{k}: кадр {w}×{h}, центр тела ({ax}, {ay}), кадров {1 + N + M}, файл {out.stat().st_size} байт')
        prev.append(im)
    if '--preview' in sys.argv:
        z = 3; W = max(p.width for p in prev); Hh = sum(p.height for p in prev)
        sh = Image.new('RGBA', (W, Hh), (30, 20, 14, 255)); y = 0
        for p in prev: sh.alpha_composite(p, (0, y)); y += p.height
        sh.resize((W * z, Hh * z), Image.NEAREST).save(ROOT / 'tools/src/bugs_preview.png')
