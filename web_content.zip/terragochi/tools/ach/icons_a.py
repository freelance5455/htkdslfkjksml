from kit import *

SILVER = '#c9d3da'
PALE = dict(body='#cdbfa4', abd='#dccfb4', leg='#cdbfa4', knee='#ebe0c8', pat='#b6a98d', eyes='#cdbfa4')
ALBO = dict(body='#bdbdc4', abd='#ecebea', leg='#c9c9d0', knee='#f6f6f4', pat='#8f8f9a')

def i_meal(cv):  # первый обед: таракан на тарелке с вилкой и ножом
    ground(cv, 32, 56, 26, 4)
    cv.paint(M().ell(32, 38, 20, 17), '#ece7dc', hl=2, sd=3)
    cv.paint(M().ell(32, 38, 14.5, 12), '#f8f5ee', outline=True, oc=(160, 150, 134), hl=0, sd=2, sdt=.12)
    roach(cv, 32, 37, .95, rot=-.4)
    f = M(); f.line((6.5, 58), (6.5, 36), 3.2).rect(2.5, 18, 10.5, 36, 1.5)
    for tx in (3.2, 5.6, 8.0): f.rect(tx, 10, tx + 1.8, 21)
    cv.paint(f, SILVER, hl=1, sd=1, hlt=.5)
    k = M(); k.line((57.5, 58), (57.5, 38), 3.2).poly([(54, 36), (54, 12), (57, 9), (61, 14), (61, 36)])
    cv.paint(k, SILVER, hl=1, sd=1, hlt=.5)
    sparkle(cv, 14, 10, 3); sparkle(cv, 50, 8, 2.4)

def i_gourmet(cv):  # сытый и довольный: счастливый паук с круглым брюшком
    ground(cv, 32, 57, 20, 3)
    spider(cv, 32, 30, .95, mood='happy', abd_scale=1.12)
    heart(cv, 9, 11, .5); heart(cv, 55, 12, .42); sparkle(cv, 49, 52, 3); sparkle(cv, 14, 50, 2.4)

def i_feast(cv):  # пир горой: миска с насекомыми
    ground(cv, 32, 58, 26, 3)
    cv.paint(M().ell(32, 40, 24, 6.5), '#4a2c16', hl=0, sd=0)
    for x, y, r, k in ((21, 32, -.5, 'r'), (42, 31, .6, 'c'), (32, 25, .1, 'r'), (13, 37, -1.1, 'c'), (51, 38, 1.2, 'r')):
        (roach(cv, x, y, .62, rot=r) if k == 'r' else cricket(cv, x, y, .62, rot=r))
    cv.paint(M().poly([(8, 40)] + bez((8, 40), (9, 58), (32, 60), 10) + bez((32, 60), (55, 58), (56, 40), 10) + [(56, 40)] + bez((56, 40), (32, 47), (8, 40), 8)), '#9a6430', hl=2, sd=3)
    cv.flat(M().rect(9, 47, 55, 48.5), '#6a3f1c'); cv.flat(M().rect(11, 53, 53, 54.5), '#6a3f1c')
    cv.paint(M().path(bez((8, 40), (32, 47), (56, 40), 12), 2.6), '#c58a4a', hl=0, sd=1)
    sparkle(cv, 12, 12, 3.4); sparkle(cv, 53, 14, 2.6); sparkle(cv, 32, 8, 2)

def i_glutton(cv):  # бездонное брюшко: король обжор
    ground(cv, 32, 58, 22, 3)
    spider(cv, 32, 35, .9, mood='happy', abd_scale=1.18)
    crown(cv, 32, 17, 1.0)
    sparkle(cv, 8, 24, 3); sparkle(cv, 57, 28, 3.4); sparkle(cv, 10, 52, 2.4)

def i_molt(cv):  # первая линька: старая шкурка и новый паук
    spider(cv, 24, 25, .78, rot=-.35, **PALE, mood='normal')
    spider(cv, 40, 41, .72, rot=.18)
    sparkle(cv, 54, 12, 3.5); sparkle(cv, 10, 52, 2.8); sparkle(cv, 52, 56, 2)

def i_molt5(cv):  # мастер линьки: шкурка + золотая медаль «5»
    spider(cv, 27, 25, .9, rot=-.15, **PALE)
    for pts, col in (([(37, 33), (44, 48), (50, 44), (45, 33)], '#d63a36'), ([(50, 33), (45, 48), (52, 50), (58, 38)], '#2f6fd0')):
        cv.paint(M().poly(pts), col, hl=0, sd=1)
    cv.paint(M().ell(46, 47, 12.5), '#f2b21c', hl=2, sd=3, hlt=.45)
    cv.paint(M().ell(46, 47, 9.2), '#ffd45a', outline=True, oc=(160, 100, 12), hl=0, sd=2, sdt=.25)
    digits(cv, '5', 43, 42, 2, '#b34a10', oc=(90, 40, 8))
    sparkle(cv, 12, 52, 3); sparkle(cv, 58, 12, 3.2)

def i_collector(cv):  # коллекционер: два паука разных видов
    spider(cv, 22, 24, .64, rot=-.2, **ALBO)
    spider(cv, 41, 40, .68, rot=.15)
    heart(cv, 51, 13, .5); sparkle(cv, 10, 50, 3)

def mini_tank(cv, x0, y0, x1, y1, sp, plant=True):
    cv.paint(M().rect(x0, y0, x1, y1, 1), '#2b2a2e', hl=0, sd=0)
    inner = M().rect(x0 + 1.5, y0 + 1.5, x1 - 1.5, y1 - 1.5)
    cv.flat(inner, '#a9d6de', 255)
    cv.flat(M().rect(x0 + 1.5, y0 + 1.5, x1 - 1.5, y0 + 3.5), '#d7eef2')
    soil = M().rect(x0 + 1.5, y1 - 5.5, x1 - 1.5, y1 - 1.5); cv.flat(soil, '#6b4226'); cv.speckle(soil, '#8a5a35', 6, int(x0)); cv.flat(M().rect(x0 + 1.5, y1 - 5.5, x1 - 1.5, y1 - 4.5), '#8a5a35')
    if plant:
        px_ = x1 - 5.5; cv.flat(M().line((px_, y1 - 5), (px_ - 2, y1 - 11), 1.6).line((px_, y1 - 5), (px_ + 2, y1 - 10), 1.6).line((px_, y1 - 5), (px_, y1 - 13), 1.6), '#3f8f3a')
    cv.flat(M().poly([(x0 + 3, y0 + 2), (x0 + 6, y0 + 2), (x0 + 3, y0 + 9)]), '#ffffff', 90)
    mini_spider(cv, (x0 + x1) / 2 - 1.5, y1 - 10.5, 1.15, **sp)

def i_zoo(cv):  # зверинец: 5 террариумов на полках
    S = [dict(body='#2a1d1a', abd='#e8631a'), dict(body='#aaaab2', abd='#ecebea'), dict(body='#3c2a1c', abd='#c0482a'), dict(body='#4a3a2c', abd='#b89a62'), dict(body='#243a6a', abd='#3a7ad0')]
    xs = [3, 24, 45]
    for i, x in enumerate(xs): mini_tank(cv, x, 6, x + 16.5, 28, S[i])
    for i, x in enumerate((13.5, 34.5)): mini_tank(cv, x, 35, x + 16.5, 57, S[3 + i])
    for y in (28, 57): cv.paint(M().rect(1, y, 63, y + 3.5), '#9a6430', hl=1, sd=1)
    sparkle(cv, 58, 33, 3)

def i_species(cv):  # знаток видов: книга + лупа
    ground(cv, 28, 60, 24, 3)
    cv.paint(M().poly([(2, 33), (27, 38), (52, 33), (52, 57), (27, 62), (2, 57)]), '#8a2a2a', hl=1, sd=2)
    cv.paint(M().poly([(5, 29), (26, 34), (26, 58), (5, 53)]), '#f6efdc', hl=0, sd=2, sdt=.18)
    cv.paint(M().poly([(28, 34), (49, 29), (49, 53), (28, 58)]), '#fbf4e2', hl=0, sd=2, sdt=.18)
    cv.flat(M().rect(26, 34, 28, 58), '#a89a78')
    for i, y in enumerate((38, 43, 48, 53)): cv.flat(M().line((31, y + 3 - i * .5), (46, y - 1.5 - i * .1), 1.1), '#b8ab8e')
    mini_spider(cv, 15.5, 44, 1.9, outline=True)
    cv.flat(M().line((8, 34), (22, 37), 1.2), '#b8ab8e')
    cv.paint(M().line((52, 34), (61, 47), 4.2), '#6a3f1c', hl=1, sd=1)
    cv.paint(M().ell(43, 20, 15), '#d9a21c', hl=2, sd=3, hlt=.45)
    cv.paint(M().ell(43, 20, 11.6), '#cfeef5', outline=True, oc=(90, 70, 20), hl=0, sd=0)
    mini_spider(cv, 43, 19.5, 2.0, body='#2a1d1a', abd='#e8631a', outline=True, eyes=True)
    cv.flat(M().ell(37.5, 13, 3.4, 1.6, -.7), '#ffffff', 170)
    cv.flat(M().path(bez((33, 26), (37, 31), (44, 32), 6), 1.2), '#ffffff', 110)

def i_mantis(cv):  # молитвенная поза: богомол
    G, GL = '#6fbf3a', '#a6e05e'
    ground(cv, 32, 60, 18, 2.5)
    for side in (-1, 1):
        cv.paint(M().path([(32 + side * 3, 31), (32 + side * 15, 36), (32 + side * 20, 50)], 2.6, 1.8), '#4f9a2a', hl=0, sd=1)
        cv.paint(M().path([(32 + side * 2, 37), (32 + side * 11, 46), (32 + side * 13, 58)], 2.4, 1.6), '#4f9a2a', hl=0, sd=1)
    cv.paint(M().ell(32, 44, 8.2, 17), '#58a82e', hl=2, sd=3)
    cv.flat(M().line((32, 29), (32, 60), 1, .6), '#3f7f20')
    for side in (-1, 1): cv.flat(M().ell(32 + side * 4, 46, 1.6, 12, side * .15), '#8fd250', 160)
    cv.paint(M().ell(32, 29, 4.2, 8.4), G, hl=1, sd=2)
    cv.paint(M().poly([(23, 12), (32, 7), (41, 12), (37, 19.5), (27, 19.5)]), G, hl=1, sd=2)
    for side in (-1, 1):
        cv.flat(M().path(bez((32 + side * 3, 8), (32 + side * 5, -1), (32 + side * 13, 1), 8), .9), '#2f6a1c')
        cv.paint(M().ell(32 + side * 6.5, 13.5, 3, 3.7), '#1d2a1c', hl=0, sd=0, oc=(20, 40, 14))
        cv.dot(32 + side * 6.5 - 1, 12, '#ffffff'); cv.dot(32 + side * 6.5 - 1, 13, '#bfe8a0')
    for side in (-1, 1):
        a = M().path([(32 + side * 3, 25), (32 + side * 13, 17), (32 + side * 10, 29)], 3.8, 2.8)
        cv.paint(a, G, hl=1, sd=1)
        for t in (.25, .5, .75):
            bx = 32 + side * (3 + 10 * t + 1.5); cv.paint(M().poly([(bx, 20 + 8 * t), (bx + side * 3.6, 22 + 8 * t), (bx, 24 + 8 * t)]), '#e9f4c0', hl=0, sd=0, oc=(40, 70, 20))
    sparkle(cv, 8, 10, 3); sparkle(cv, 57, 52, 2.6)

def i_snake(cv):  # змеиный друг: кукурузный полоз, свернувшийся кольцами
    ground(cv, 32, 58, 25, 4)
    O, R, DK = '#ec8a2c', '#b8321e', (60, 18, 12)
    prev = None
    def ring(cy, rx, ry, a0, a1, n=30):
        return [(32 + math.cos(a0 + (a1 - a0) * i / n) * rx, cy + math.sin(a0 + (a1 - a0) * i / n) * ry) for i in range(n + 1)]
    def blotches(pts, step=3, flip=0):
        for i in range(0, len(pts) - 1, step):
            x, y = pts[i]; x2, y2 = pts[min(i + 1, len(pts) - 1)]; ang = math.atan2(y2 - y, x2 - x)
            yield M().ell(x, y, 1.3, 3.2, ang + 1.5708)
    chunks = [ring(48, 22, 8, 0.3, 6.6, 36), ring(38, 17, 6.6, .1, 6.4, 32)]
    for pts in chunks:
        m = tube(cv, pts, 9.2, 8.6, O, hl=2, sd=2)
        for b in blotches(pts): cv.flat(b, R, clip=m)
    neck = bez((32 + 17, 40), (49, 24), (40, 22), 14) + bez((40, 22), (31, 20), (33, 12), 10)
    tube(cv, neck, 8, 6, O, hl=1, sd=1)
    head = M().ell(33, 10.5, 6.4, 5.2, .3); cv.paint(head, '#f09a38', hl=1, sd=2)
    cv.flat(M().ell(33, 8.6, 3.2, 1.3, .3), R, clip=head)
    cv.paint(M().ell(30, 8.8, 1.8, 1.9), '#ffd23a', hl=0, sd=0, oc=(30, 10, 6)); cv.flat(M().ell(30, 9, .8, 1.2), '#150a08'); cv.dot(29, 8, '#fff')
    cv.paint(M().ell(36.5, 9.5, 1.7, 1.8), '#ffd23a', hl=0, sd=0, oc=(30, 10, 6)); cv.flat(M().ell(36.7, 9.7, .8, 1.2), '#150a08')
    cv.flat(M().line((38.5, 13), (44, 15), .9).line((44, 15), (46.5, 13.5), .8).line((44, 15), (46.5, 16.8), .8), '#d6283a')
    sparkle(cv, 10, 14, 3); sparkle(cv, 56, 52, 2.6)

def i_hunter(cv):  # меткий охотник: мишень со стрелой
    ground(cv, 30, 58, 22, 3)
    cv.paint(M().ell(30, 33, 25), '#f4efe2', hl=2, sd=3)
    cv.paint(M().ell(30, 33, 21), '#d9362c', outline=False, hl=0, sd=0)
    cv.paint(M().ell(30, 33, 16.5), '#f4efe2', outline=False, hl=0, sd=0)
    cv.paint(M().ell(30, 33, 12), '#d9362c', outline=False, hl=0, sd=0)
    cv.paint(M().ell(30, 33, 7.5), '#f4efe2', outline=False, hl=0, sd=0)
    cv.paint(M().ell(30, 33, 3.6), '#d9362c', outline=True, hl=0, sd=0)
    sh = M().line((31, 33), (58, 8), 2.2); cv.paint(sh, '#a67c52', hl=0, sd=1)
    cv.paint(M().poly([(50, 9), (60, 3), (61, 12)]), '#e8e2d0', hl=0, sd=0); cv.paint(M().poly([(55, 15), (62, 12), (58, 19)]), '#e8e2d0', hl=0, sd=0)
    cv.paint(M().poly([(27, 36), (31, 31), (34, 35)]), '#aab4bc', hl=0, sd=0)
    sparkle(cv, 8, 10, 3.2); sparkle(cv, 56, 54, 2.4)

def i_sniper(cv):  # снайпер: оптический прицел
    cv.paint(M().ell(32, 32, 28), '#3a3d46', hl=2, sd=3, hlt=.3)
    cv.paint(M().ell(32, 32, 23.5), '#1c2a2e', outline=True, oc=(10, 8, 10), hl=0, sd=0)
    lens = M().ell(32, 32, 21.5); cv.flat(lens, '#2e5a52')
    cv.flat(M().ell(32, 36, 18, 14), '#3a7566', clip=lens)
    cv.flat(M().ell(28, 22, 10, 5, -.4), '#6fb8a0', 150, clip=lens)
    for (x0, y0, x1, y1) in ((10, 32, 26, 32), (38, 32, 54, 32), (32, 10, 32, 26), (32, 38, 32, 54)): cv.flat(M().line((x0, y0), (x1, y1), 1.2), '#f2f6e8', clip=lens)
    for d in (-12, 12): cv.flat(M().ell(32 + d, 32, 1, 1), '#f2f6e8'); cv.flat(M().ell(32, 32 + d, 1, 1), '#f2f6e8')
    cv.flat(M().ell(32, 32, 7.5), '#e04a32', 0); 
    roach(cv, 34, 31, .5, rot=.6, col='#1a2a24', head='#0e1a16', shell='#0e1a16')
    cv.paint(M().ell(32, 32, 2.2), '#ff5a3a', outline=False, hl=0, sd=0)
    cv.flat(M().path(bez((13, 24), (18, 14), (28, 10), 10), 1.6), '#ffffff', 170)
    star(cv, 52, 52, 8.5)

SET = [i_meal, i_gourmet, i_feast, i_glutton, i_molt, i_molt5, i_collector, i_zoo, i_species, i_mantis, i_snake, i_hunter, i_sniper]
