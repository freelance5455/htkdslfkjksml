"""Мини-набор для рисования пиксель-арт иконок 64x64: формы-маски, обводка, объём (блик слева-сверху, тень справа-снизу),
падающая тень. Все формы рисуются с 4-кратным запасом и потом режутся порогом -> получаются чёткие пиксели без размытия."""
import math, random
from PIL import Image, ImageDraw, ImageFilter, ImageChops

W = 64
SS = 4
OUT = (26, 14, 12)

def hexc(h):
    if isinstance(h, tuple): return h
    h = h.lstrip('#')
    if len(h) == 3: h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def mix(a, b, t): return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))
def lighten(c, t): return mix(hexc(c), (255, 246, 214), t)
def darken(c, t): return mix(hexc(c), (30, 12, 48), t)
def shift(m, dx, dy):
    r = Image.new('L', m.size, 0); r.paste(m, (dx, dy)); return r
def sub(a, b): return ImageChops.subtract(a, b)
def inter(a, b): return ImageChops.multiply(a, b)
def union(*ms):
    r = ms[0]
    for m in ms[1:]: r = ImageChops.lighter(r, m)
    return r

class M:
    """Построитель маски. Координаты — в пикселях иконки (0..64), дробные можно."""
    def __init__(s):
        s.im = Image.new('L', (W * SS, W * SS), 0); s.d = ImageDraw.Draw(s.im)
    def _p(s, pts): return [(x * SS, y * SS) for x, y in pts]
    def ell(s, cx, cy, rx, ry=None, rot=0.0):
        ry = rx if ry is None else ry; c, si = math.cos(rot), math.sin(rot); pts = []
        for i in range(56):
            a = i / 56 * 6.2832; x, y = math.cos(a) * rx, math.sin(a) * ry
            pts.append((cx + x * c - y * si, cy + x * si + y * c))
        s.d.polygon(s._p(pts), fill=255); return s
    def poly(s, pts): s.d.polygon(s._p(pts), fill=255); return s
    def rect(s, x0, y0, x1, y1, r=0):
        if r: s.d.rounded_rectangle([x0 * SS, y0 * SS, x1 * SS - 1, y1 * SS - 1], radius=r * SS, fill=255)
        else: s.d.rectangle([x0 * SS, y0 * SS, x1 * SS - 1, y1 * SS - 1], fill=255)
        return s
    def line(s, a, b, w0, w1=None):
        w1 = w0 if w1 is None else w1
        dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy) or 1; nx, ny = -dy / L, dx / L
        s.poly([(a[0] + nx * w0 / 2, a[1] + ny * w0 / 2), (b[0] + nx * w1 / 2, b[1] + ny * w1 / 2),
                (b[0] - nx * w1 / 2, b[1] - ny * w1 / 2), (a[0] - nx * w0 / 2, a[1] - ny * w0 / 2)])
        s.ell(a[0], a[1], w0 / 2); s.ell(b[0], b[1], w1 / 2); return s
    def path(s, pts, w0, w1=None):
        w1 = w0 if w1 is None else w1; n = len(pts) - 1
        for i in range(n): s.line(pts[i], pts[i + 1], w0 + (w1 - w0) * i / n, w0 + (w1 - w0) * (i + 1) / n)
        return s
    def px(s, x, y, w=1, h=1): s.d.rectangle([x * SS, y * SS, (x + w) * SS - 1, (y + h) * SS - 1], fill=255); return s
    def done(s): return s.im.resize((W, W), Image.BOX).point(lambda v: 255 if v >= 128 else 0)

def bez(p0, p1, p2, n=12):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0], (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in [i / n for i in range(n + 1)]]

class Cv:
    def __init__(s):
        s.im = Image.new('RGBA', (W, W), (0, 0, 0, 0)); s.rng = random.Random(7)
    def fill(s, mask, col, a=255):
        col = hexc(col)
        if a == 255: s.im.paste(col + (255,), (0, 0), mask)
        else:
            L = Image.new('RGBA', (W, W), (0, 0, 0, 0)); L.paste(col + (a,), (0, 0), mask); s.im = Image.alpha_composite(s.im, L)
    def paint(s, m, col, outline=True, oc=OUT, hl=2, sd=2, hlt=.34, sdt=.34, grad=None, a=255, clip=None, excl=None):
        mask = m.done() if isinstance(m, M) else m
        if clip is not None: mask = inter(mask, clip.done() if isinstance(clip, M) else clip)
        col = hexc(col)
        if outline:
            ring = sub(mask.filter(ImageFilter.MaxFilter(3)), mask)
            if excl is not None: ring = sub(ring, excl)
            s.fill(ring, oc)
        if grad:
            bb = mask.getbbox()
            if bb:
                nb = 4; y0, y1 = bb[1], bb[3]
                for k in range(nb):
                    band = Image.new('L', (W, W), 0); ImageDraw.Draw(band).rectangle([0, y0 + (y1 - y0) * k // nb, W, y0 + (y1 - y0) * (k + 1) // nb - 1], fill=255)
                    s.fill(inter(mask, band), mix(col, hexc(grad), k / (nb - 1)), a)
        else: s.fill(mask, col, a)
        ex = (lambda b: sub(b, excl)) if excl is not None else (lambda b: b)
        if sd: s.fill(ex(sub(mask, shift(mask, -sd, -sd))), darken(col, sdt), a)
        if hl: s.fill(ex(sub(mask, shift(mask, hl, hl))), lighten(col, hlt), a)
        return mask
    def flat(s, m, col, a=255, clip=None):
        mask = m.done() if isinstance(m, M) else m
        if clip is not None: mask = inter(mask, clip.done() if isinstance(clip, M) else clip)
        s.fill(mask, col, a); return mask
    def speckle(s, mask, col, n, seed=1, clipin=1):
        mask = mask.done() if isinstance(mask, M) else mask
        r = random.Random(seed); inner = mask.filter(ImageFilter.MinFilter(3)) if clipin else mask
        pts = [(x, y) for y in range(W) for x in range(W) if inner.getpixel((x, y))]
        r.shuffle(pts)
        for x, y in pts[:n]: s.im.putpixel((x, y), hexc(col) + (255,))
    def dot(s, x, y, col, a=255):
        if 0 <= x < W and 0 <= y < W:
            if a == 255: s.im.putpixel((int(x), int(y)), hexc(col) + (255,))
            else:
                L = Image.new('RGBA', (W, W), (0, 0, 0, 0)); L.putpixel((int(x), int(y)), hexc(col) + (a,)); s.im = Image.alpha_composite(s.im, L)
    def hline(s, x0, x1, y, col):
        for x in range(int(x0), int(x1) + 1): s.dot(x, y, col)
    def finish(s, shadow=True):
        if shadow:
            al = s.im.split()[3].point(lambda v: 255 if v > 40 else 0)
            sh = Image.new('RGBA', (W, W), (0, 0, 0, 0)); sh.paste((8, 4, 16, 110), (0, 0), shift(al, 1, 2))
            sh.alpha_composite(s.im); s.im = sh
        return s.im

# ---------- мелкие общие детали ----------
def sparkle(cv, x, y, r=3, col='#fff3b0'):
    m = M(); m.poly([(x, y - r), (x + r * .32, y - r * .32), (x + r, y), (x + r * .32, y + r * .32), (x, y + r), (x - r * .32, y + r * .32), (x - r, y), (x - r * .32, y - r * .32)])
    cv.paint(m, col, outline=False, hl=0, sd=0)

def ground(cv, cx, cy, rx, ry, a=90):
    cv.flat(M().ell(cx, cy, rx, ry), (10, 6, 16), a)

FONT = {'0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111', '4': '101101111001001', '5': '111100111001111',
        '6': '111100111101111', '7': '111001001001001', '8': '111101111101111', '9': '111101111001111'}
def digits(cv, text, x, y, sc, col, oc=OUT, hl=0):
    m = M()
    for i, ch in enumerate(text):
        for k, b in enumerate(FONT[ch]):
            if b == '1': m.rect(x + (i * 4 + k % 3) * sc, y + (k // 3) * sc, x + (i * 4 + k % 3 + 1) * sc, y + (k // 3 + 1) * sc)
    cv.paint(m, col, outline=True, oc=oc, hl=hl, sd=0)

def coin(cv, cx, cy, r=6, col='#f2b21c'):
    cv.paint(M().ell(cx, cy, r), col, hl=1, sd=1, hlt=.45, sdt=.4)
    cv.paint(M().ell(cx, cy, r * .66), lighten(col, .12), outline=False, hl=0, sd=1, sdt=.25)
    cv.flat(M().rect(cx - 1, cy - r * .4, cx + 1, cy + r * .4), darken(col, .45))
    cv.dot(int(cx - r * .55), int(cy - r * .55), '#fff6c8')

def heart(cv, cx, cy, s=1.0, col='#e0343e'):
    m = M(); m.ell(cx - 5 * s, cy - 3 * s, 5.6 * s, 5.2 * s).ell(cx + 5 * s, cy - 3 * s, 5.6 * s, 5.2 * s).poly([(cx - 10.2 * s, cy - .5 * s), (cx + 10.2 * s, cy - .5 * s), (cx, cy + 11 * s)])
    cv.paint(m, col, hl=2, sd=2, hlt=.4)
    cv.flat(M().ell(cx - 6.5 * s, cy - 5.2 * s, 1.7 * s, 1.2 * s, -.6), '#ffd0d0')

def crown(cv, cx, cy, s=1.0):
    m = M(); m.poly([(cx - 9 * s, cy + 5 * s), (cx - 10 * s, cy - 6 * s), (cx - 5 * s, cy - 1 * s), (cx, cy - 8 * s), (cx + 5 * s, cy - 1 * s), (cx + 10 * s, cy - 6 * s), (cx + 9 * s, cy + 5 * s)])
    cv.paint(m, '#f2b21c', hl=1, sd=2, hlt=.45)
    cv.paint(M().rect(cx - 9 * s, cy + 2 * s, cx + 9 * s, cy + 6 * s), '#d9941a', hl=1, sd=1)
    for dx, col in ((-5, '#e0343e'), (0, '#3aa0e8'), (5, '#e0343e')): cv.paint(M().ell(cx + dx * s, cy + 4 * s, 1.5 * s), col, outline=False, hl=0, sd=0)
    for dx, dy in ((-10, -6), (0, -8), (10, -6)): cv.paint(M().ell(cx + dx * s, cy + dy * s, 1.5 * s), '#fff0a0', hl=0, sd=0)

# ---------- паук (вид сверху, голова вверх) ----------
LEGS = [((4, -3), (13, -13), (20, -6)), ((5, -1), (16, -7), (24, 1)), ((5, 2), (16, 3), (23, 12)), ((4, 5), (12, 13), (14, 22))]
def spider(cv, cx, cy, s=1.0, body='#2a1d1a', abd='#e8631a', leg='#2b1c16', knee='#f0a53a', pat='#1d120e', eyes='#ffd23a',
           mood='normal', rot=0.0, legs_only=False, no_legs=False, abd_scale=1.0, pose=0, baby_dots=False, alpha=255):
    c, si = math.cos(rot), math.sin(rot)
    def P(x, y): return (cx + (x * c - y * si) * s, cy + (x * si + y * c) * s)
    def E(x, y, rx, ry, a=0): px_, py_ = P(x, y); return M().ell(px_, py_, rx * s, ry * s, a + rot)
    if not no_legs:
        for side in (-1, 1):
            for i, (a0, k, f) in enumerate(LEGS):
                if pose == 1 and i == 0: k = (13, -16); f = (17, -23)           # передние лапки подняты
                p0, p1, p2 = P(a0[0] * side, a0[1]), P(k[0] * side, k[1]), P(f[0] * side, f[1])
                m = M(); m.line(p0, p1, 3.4 * s, 2.7 * s).line(p1, p2, 2.7 * s, 1.9 * s)
                cv.paint(m, leg, hl=1, sd=1, hlt=.22, sdt=.3)
                cv.paint(M().ell(p1[0], p1[1], 1.9 * s), knee, outline=False, hl=0, sd=0)
                cv.dot(round(p2[0]), round(p2[1]), lighten(leg, .1))
    if legs_only: return
    # брюшко
    ab = E(0, 12 * abd_scale, 9.6 * s / s, 11.5 * abd_scale)
    cv.paint(ab, abd, hl=2, sd=3, hlt=.4, sdt=.4)
    mk = ab
    cv.flat(E(0, 12 * abd_scale + 1, 1.9, 8.2 * abd_scale), pat, clip=mk)
    for sd_ in (-1, 1):
        cv.flat(E(sd_ * 5.2, 12 * abd_scale + 3, 1.2, 4.6 * abd_scale, sd_ * -.25), darken(abd, .55), clip=mk)
    cv.flat(E(0, 12 * abd_scale + 1, .8, 6.5 * abd_scale), darken(pat, .0) if False else (60, 24, 16), clip=mk)
    cv.speckle(ab, lighten(abd, .5), 12, 3); cv.speckle(ab, darken(abd, .5), 10, 4)
    if baby_dots:
        r = random.Random(11)
        for _ in range(26):
            bx, by = P(r.uniform(-7.5, 7.5), 12 + r.uniform(-7, 10))
            if ((bx - P(0, 12)[0]) / (8.2 * s)) ** 2 + ((by - P(0, 12)[1]) / (10 * s)) ** 2 > 1: continue
            cv.paint(M().ell(bx, by, 1.05 * s, 1.1 * s), '#f4e6bc', hl=0, sd=0, outline=True, oc=(50, 24, 14))
            cv.flat(M().line((bx - 1.8, by + .4), (bx + 1.8, by + .4), .7), (50, 24, 14), 220)
    # головогрудь
    cs = E(0, -2, 8 * s / s, 7.2)
    cv.paint(cs, body, hl=2, sd=2, hlt=.28, sdt=.3)
    cv.flat(E(0, .5, 2.2, 1.7), darken(body, .35))
    cv.speckle(cs, lighten(body, .35), 8, 5)
    # хелицеры и педипальпы
    for side in (-1, 1):
        fx, fy = P(side * 2.6, -8.5); cv.paint(M().ell(fx, fy, 1.9 * s, 2.6 * s, rot), '#4a2a22', hl=0, sd=1)
        px_, py_ = P(side * 6.2, -8.6); cv.paint(M().ell(px_, py_, 1.7 * s, 2.4 * s, rot + side * .5), leg, hl=0, sd=0)
    # глаза
    for side in (-1, 1):
        ex, ey = P(side * 3.1, -5.3)
        if mood == 'happy':
            cv.flat(M().path(bez((ex - 2.2 * s, ey + .8), (ex, ey - 2.6 * s), (ex + 2.2 * s, ey + .8), 8), 1.5 * s), '#ffe9b8')
            continue
        cv.paint(M().ell(ex, ey, 2.4 * s, 2.5 * s), eyes, hl=0, sd=0, oc=(20, 8, 6))
        cv.flat(M().ell(ex + .1, ey + .3, 1.2 * s, 1.5 * s), '#150a08'); cv.dot(round(ex - .8 * s), round(ey - .9 * s), '#ffffff')
    if mood == 'happy':
        for side in (-1, 1):
            bx, by = P(side * 5.6, -3.3); cv.flat(M().ell(bx, by, 1.8 * s, 1.1 * s), '#ff8a8a', 150)

# ---------- таракан (вид сверху, голова вверх) ----------
def roach(cv, cx, cy, s=1.0, rot=0.0, col='#8a5a30', head='#3a2412', shell='#9a5a2a'):
    c, si = math.cos(rot), math.sin(rot)
    def P(x, y): return (cx + (x * c - y * si) * s, cy + (x * si + y * c) * s)
    for side in (-1, 1):
        for a0, f in (((3.5, -3), (10, -9)), ((4, 1), (11, 2)), ((3.5, 5), (9, 12))):
            p0 = P(a0[0] * side, a0[1]); k = P((a0[0] + f[0]) / 2 * side * 1.05, (a0[1] + f[1]) / 2 - 3); p1 = P(f[0] * side, f[1])
            m = M(); m.line(p0, k, 1.8 * s, 1.6 * s).line(k, p1, 1.6 * s, 1.1 * s); cv.paint(m, '#4a2c16', hl=0, sd=0)
        an = [P(side * 1.6, -9.5)] + bez(P(side * 2, -10), P(side * 5, -19), P(side * 13, -15), 8)
        cv.flat(M().path(an, 1.0 * s), '#2a180a')
    body = M().ell(*P(0, 3.5), 6.6 * s, 10.4 * s, rot)
    cv.paint(body, shell, hl=2, sd=3, hlt=.32, sdt=.4)
    cv.flat(M().line(P(0, -2), P(0, 11.5), .9 * s, .6 * s), darken(shell, .5), clip=body)
    cv.flat(M().ell(*P(-2.6, 1.8), 1.4 * s, 4.2 * s, rot + .15), lighten(shell, .5), 190, clip=body)
    pr = M().ell(*P(0, -4.5), 6.0 * s, 4.2 * s, rot); cv.paint(pr, lighten(shell, .18), hl=1, sd=1, hlt=.35)
    cv.flat(M().ell(*P(0, -4.4), 3.6 * s, 2.1 * s, rot), darken(shell, .45), clip=pr)
    cv.flat(M().ell(*P(0, -4.6), 2.2 * s, 1.1 * s, rot), lighten(shell, .3), clip=pr)
    cv.paint(M().ell(*P(0, -9), 2.5 * s, 2.2 * s, rot), head, hl=0, sd=0)

# ---------- кузнечик/сверчок ----------
def cricket(cv, cx, cy, s=1.0, rot=0.0, col='#6b8a2c'):
    c, si = math.cos(rot), math.sin(rot)
    def P(x, y): return (cx + (x * c - y * si) * s, cy + (x * si + y * c) * s)
    for side in (-1, 1):
        k = P(side * 11, 2); f = P(side * 8, 13); a = P(side * 3, 2)
        m = M(); m.line(a, k, 2.4 * s, 2.0 * s).line(k, f, 2.0 * s, 1.1 * s); cv.paint(m, darken(col, .3), hl=0, sd=0)
        an = bez(P(side * 1.5, -9), P(side * 6, -16), P(side * 12, -15), 6); cv.flat(M().path(an, .9 * s), '#2a180a')
    b = M().ell(*P(0, 4), 5 * s, 9 * s, rot); cv.paint(b, col, hl=2, sd=3, hlt=.3, sdt=.4)
    cv.flat(M().ell(*P(-1.8, 3), 1.2 * s, 5 * s, rot), lighten(col, .45), 170, clip=b)
    cv.paint(M().ell(*P(0, -4), 4.2 * s, 3.4 * s, rot), lighten(col, .02), hl=1, sd=1)
    cv.paint(M().ell(*P(0, -9), 3.2 * s, 2.8 * s, rot), darken(col, .2), hl=1, sd=1)
    for sd_ in (-1, 1): cv.dot(round(P(sd_ * 1.4, -9.5)[0]), round(P(sd_ * 1.4, -9.5)[1]), '#ffffff')


# ---------- ещё детали ----------
def star(cv, cx, cy, r=8, col='#f2b21c'):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5; rr = r if i % 2 == 0 else r * .45; pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    cv.paint(M().poly(pts), col, hl=1, sd=1, hlt=.45)

def flame(cv, cx, cy, s=1.0):
    def f(k, dy): 
        return M().poly(bez((cx, cy - 12 * k * s + dy), (cx + 3 * k * s, cy - 4 * k * s + dy), (cx + 7 * k * s, cy + 1 * k * s + dy), 6)
                        + bez((cx + 7 * k * s, cy + 1 * k * s + dy), (cx + 7 * k * s, cy + 9 * k * s + dy), (cx, cy + 10 * k * s + dy), 6)
                        + bez((cx, cy + 10 * k * s + dy), (cx - 7 * k * s, cy + 9 * k * s + dy), (cx - 7 * k * s, cy + 1 * k * s + dy), 6)
                        + bez((cx - 7 * k * s, cy + 1 * k * s + dy), (cx - 3 * k * s, cy - 4 * k * s + dy), (cx, cy - 12 * k * s + dy), 6))
    cv.paint(f(1, 0), '#e8461c', hl=0, sd=2, sdt=.3)
    cv.paint(f(.68, 2.2 * s), '#f89a1c', outline=False, hl=0, sd=0)
    cv.paint(f(.38, 4.2 * s), '#ffe27a', outline=False, hl=0, sd=0)

def drop(cv, cx, cy, s=1.0, col='#3aa0e8'):
    m = M().poly(bez((cx, cy - 8 * s), (cx + 2 * s, cy - 3 * s), (cx + 5 * s, cy + 1 * s), 6) + bez((cx + 5 * s, cy + 1 * s), (cx + 5 * s, cy + 7 * s), (cx, cy + 7 * s), 6)
                 + bez((cx, cy + 7 * s), (cx - 5 * s, cy + 7 * s), (cx - 5 * s, cy + 1 * s), 6) + bez((cx - 5 * s, cy + 1 * s), (cx - 2 * s, cy - 3 * s), (cx, cy - 8 * s), 6))
    cv.paint(m, col, hl=1, sd=2, hlt=.45)
    cv.dot(round(cx - 2 * s), round(cy + 1 * s), '#ffffff')

def mini_spider(cv, cx, cy, sc=1.0, body='#2a1d1a', abd='#e8631a', leg=None, outline=False, eyes=False):
    leg = leg or darken(body, .1)
    for side in (-1, 1):
        for i, (ax, ay, kx, ky, fx, fy) in enumerate([(1, -1, 3.6, -3.4, 5.4, -1.2), (1.4, 0, 4.4, -1.2, 6, 1.6), (1.4, 1, 4.4, 1.2, 5.6, 4.2), (1, 2, 3.2, 3.4, 3.8, 6)]):
            m = M().line((cx + side * ax * sc, cy + ay * sc), (cx + side * kx * sc, cy + ky * sc), max(1, .55 * sc)).line((cx + side * kx * sc, cy + ky * sc), (cx + side * fx * sc, cy + fy * sc), max(1, .5 * sc), max(1, .4 * sc))
            cv.paint(m, leg, outline=outline and sc >= 2, hl=0, sd=0)
    ab = M().ell(cx, cy + 2.4 * sc, 2.6 * sc, 3.2 * sc); cv.paint(ab, abd, outline=outline, hl=1 if sc >= 2 else 0, sd=1 if sc >= 2 else 0)
    cs = M().ell(cx, cy - .4 * sc, 2.1 * sc, 1.9 * sc); cv.paint(cs, body, outline=outline, hl=0, sd=0)
    if eyes:
        for sd_ in (-1, 1): cv.dot(round(cx + sd_ * .9 * sc), round(cy - 1 * sc), '#ffd23a')

def mini_roach(cv, cx, cy, s=1.0, col='#9a5a2a', face=1):
    for k in (-3, 0, 3): cv.flat(M().line((cx + k * s, cy + 1 * s), (cx + k * s, cy + 3.4 * s), 1), '#2a180a')
    cv.paint(M().ell(cx, cy, 5.6 * s, 3.1 * s), col, hl=1, sd=1)
    cv.paint(M().ell(cx + face * 4.8 * s, cy - .4 * s, 1.9 * s, 1.7 * s), '#3a2412', hl=0, sd=0)
    cv.flat(M().path(bez((cx + face * 6 * s, cy - 1 * s), (cx + face * 8 * s, cy - 4 * s), (cx + face * 11 * s, cy - 3 * s), 5), .8), '#2a180a')

def tube(cv, pts, w0, w1, col, prev=None, hl=1, sd=1):
    m = M().path(pts, w0, w1).done(); cv.paint(m, col, hl=hl, sd=sd, excl=prev); return m
