from kit import *
from icons_a import ALBO, PALE

def calendar(cv, head, cx=32, y0=10, x0=7, x1=57, y1=57):
    cv.paint(M().rect(x0, y0, x1, y1, 4), '#f7f0de', hl=2, sd=3, sdt=.2)
    cv.paint(M().rect(x0, y0, x1, y0 + 14, 4), head, hl=2, sd=2)
    cv.flat(M().rect(x0 + 1, y0 + 8, x1 - 1, y0 + 14), head)
    cv.flat(M().rect(x0 + 1, y0 + 12, x1 - 1, y0 + 13.5), darken(head, .35))
    for rx in (x0 + 11, x1 - 11):
        cv.paint(M().rect(rx - 1.8, y0 - 5, rx + 1.8, y0 + 5, 1.5), '#5a5a64', hl=1, sd=1)
        cv.dot(int(rx), y0 + 8, '#ffffff', 80)

def i_regular(cv):  # постоянный гость: календарь с галочкой
    calendar(cv, '#d63a36')
    for gx in range(4):
        for gy in range(2):
            cv.flat(M().rect(13 + gx * 11, 28 + gy * 12.5, 18 + gx * 11, 32 + gy * 12.5), '#d8cfb6')
    cv.paint(M().path([(18, 41), (28, 50), (46, 29)], 6.2), '#3aa83a', hl=1, sd=1, hlt=.45)
    sparkle(cv, 54, 10, 3); sparkle(cv, 8, 56, 2.2)

def i_week(cv):  # неделя заботы: календарь «7» с огоньком
    calendar(cv, '#e08a1c', x1=52, x0=5)
    digits(cv, '7', 18, 29, 4, '#d9502a', oc=(80, 24, 10), hl=1)
    for i in range(7): cv.flat(M().rect(9 + i * 5.6, 53, 13 + i * 5.6, 55.2), '#3aa83a')
    flame(cv, 52, 18, 1.15)
    sparkle(cv, 9, 8, 2.4)

def i_hatch(cv):  # первые малыши: кокон треснул, паучата вылезают
    ground(cv, 32, 58, 26, 4)
    cv.flat(M().path(bez((12, 4), (20, 18), (22, 30), 8), .8), '#e8e6dc', 200); cv.flat(M().path(bez((52, 4), (44, 18), (42, 30), 8), .8), '#e8e6dc', 200)
    sac = M().ell(32, 37, 19, 18); cv.paint(sac, '#f0e9d2', hl=3, sd=3, hlt=.4, sdt=.28)
    for a0 in (-.6, .1, .8):
        cv.flat(M().path([(32 + math.cos(a0 + t) * 19, 37 + math.sin(a0 + t) * 18) for t in [i * .28 for i in range(-5, 6)]], .9), '#cfc4a4', 200, clip=sac)
    for y in (32, 42, 50): cv.flat(M().line((16, y), (47, y + (3 if y == 32 else -2)), .8), '#d4c9aa', 150, clip=sac)
    hole = M().poly([(30, 24), (34, 27), (37, 22), (41, 28), (46, 27), (44, 33), (47, 39), (41, 38), (38, 44), (34, 38), (28, 40), (31, 33), (27, 29)])
    cv.paint(hole, '#2a1810', hl=0, sd=0, oc=(120, 100, 70), clip=sac)
    cv.flat(M().ell(37, 34, 6, 5), '#4a2a1a', clip=hole)
    cv.paint(M().poly([(30, 24), (34, 27), (33, 22.5)]), '#f8f2de', hl=0, sd=0, oc=(120, 100, 70)); cv.paint(M().poly([(41, 28), (46, 27), (43, 23.5)]), '#f8f2de', hl=0, sd=0, oc=(120, 100, 70))
    mini_spider(cv, 38, 34, 1.5, body='#2a1d1a', abd='#e8631a', outline=True, eyes=True)
    mini_spider(cv, 9, 54, 1.7, outline=True); mini_spider(cv, 54, 54, 1.7, abd='#c0482a', outline=True)
    mini_spider(cv, 52, 22, 1.2); sparkle(cv, 8, 24, 3)

def i_brood(cv):  # целый выводок: мама с детишками на спине
    ground(cv, 32, 58, 22, 3)
    spider(cv, 32, 31, .95, baby_dots=True, mood='happy', abd_scale=1.1, abd='#7a4a2a', pat='#3a2214', knee='#e8b66a')
    heart(cv, 8, 12, .5); heart(cv, 56, 12, .5); sparkle(cv, 10, 52, 2.6); sparkle(cv, 56, 50, 2.6)

def plastic_cup(cv, cx, top=22, bot=55, hw_t=9.4, hw_b=6.6, spider_col=None, soil=True, water=False):
    cupm = M().poly([(cx - hw_t, top), (cx + hw_t, top), (cx + hw_b, bot), (cx - hw_b, bot)])
    cm = cv.paint(cupm, '#cfe8f0', hl=0, sd=0, a=120, oc=(40, 60, 80))
    if soil:
        s_m = M().poly([(cx - hw_t, bot - 10), (cx + hw_t, bot - 10), (cx + hw_b, bot), (cx - hw_b, bot)])
        cv.flat(s_m, '#6b4226', clip=cm); cv.flat(M().rect(cx - 12, bot - 10, cx + 12, bot - 8.6), '#8a5a35', clip=cm); cv.speckle(inter(s_m.done(), cm), '#8a5a35', 7, int(cx))
    cv.flat(M().poly([(cx - hw_t + 1.5, top + 2), (cx - hw_t + 3.8, top + 2), (cx - hw_b + 3.2, bot - 3), (cx - hw_b + 1.2, bot - 3)]), '#ffffff', 120, clip=cm)
    cv.paint(M().ell(cx, top, hw_t + .8, 2.4), '#eef6f9', hl=0, sd=0, oc=(40, 60, 80))
    cv.flat(M().ell(cx, top, hw_t - .8, 1.2), '#aac6d0')
    if spider_col: mini_spider(cv, cx + 1, bot - 15.5, 1.5, **spider_col)

def i_cups(cv):  # хозяин стаканчиков
    ground(cv, 32, 57, 29, 3)
    S = [dict(body='#2a1d1a', abd='#e8631a'), dict(body='#aaaab2', abd='#ecebea'), dict(body='#3c2a1c', abd='#c0482a')]
    for i, cx in enumerate((12.5, 32, 51.5)): plastic_cup(cv, cx, 24, 56, 8.2, 6.0, S[i], water=False)
    drop(cv, 32, 11, 1.0); sparkle(cv, 9, 12, 2.6); sparkle(cv, 55, 11, 2.6)

def i_trader(cv):  # первая сделка: мешочек монет и паучок
    ground(cv, 30, 58, 24, 3)
    sack = M().ell(28, 43, 19, 16.5); cv.paint(sack, '#c8934a', hl=3, sd=3, hlt=.3, sdt=.32)
    cv.paint(M().poly([(15, 18), (24, 28), (32, 28), (41, 18), (37, 24), (28, 21), (19, 24)]), '#c8934a', hl=1, sd=1)
    cv.paint(M().rect(20, 25, 36, 30, 2), '#c8934a', hl=1, sd=1)
    cv.paint(M().rect(19, 29, 37, 32.6, 1.5), '#c9342f', hl=1, sd=1, hlt=.4)
    cv.speckle(sack, '#a06f2c', 14, 3)
    cv.paint(M().ell(28, 44, 9, 9), '#f4e6bc', hl=0, sd=2, sdt=.15, oc=(110, 70, 24))
    mini_spider(cv, 28, 43, 2.1, body='#2a1d1a', abd='#e8631a', outline=False)
    coin(cv, 49, 51, 7.5); coin(cv, 52, 38, 6.6); coin(cv, 44, 58, 5)
    sparkle(cv, 52, 22, 3.6); sparkle(cv, 9, 14, 2.6)

def bin_(cv, x0, y0, x1, y1, lid='#3a7bd5', roaches=3, lid_h=5):
    body = M().rect(x0 + 1, y0 + lid_h, x1 - 1, y1, 2)
    cm = cv.paint(body, '#cfe6f0', hl=0, sd=2, sdt=.18, a=150, oc=(40, 60, 80))
    cv.flat(M().rect(x0 + 3, y0 + lid_h + 2, x1 - 3, y1 - 2), '#a8c6d0', 80, clip=cm)
    h = y1 - y0 - lid_h
    for i in range(3):
        tx = x0 + 4 + i * (x1 - x0 - 8) / 3
        cv.paint(M().rect(tx, y1 - h * .72, tx + (x1 - x0 - 10) / 3.4, y1 - 1.5, 1.5), '#c9a56a', hl=1, sd=1, clip=cm)
        cv.flat(M().ell(tx + (x1 - x0 - 10) / 6.8, y1 - h * .72, (x1 - x0 - 10) / 6.8, 1.4), '#3a2a18', clip=cm)
    for i in range(roaches): mini_roach(cv, x0 + 6 + i * (x1 - x0 - 14) / max(1, roaches - 1) if roaches > 1 else (x0 + x1) / 2, y1 - 4.2, min(.9, (x1 - x0) / 34), face=1 if i % 2 else -1)
    cv.flat(M().rect(x0 + 3, y0 + lid_h + 2, x0 + 4.6, y1 - 3), '#ffffff', 130)
    cv.paint(M().rect(x0, y0, x1, y0 + lid_h, 1.5), lid, hl=1, sd=1)
    cv.paint(M().rect((x0 + x1) / 2 - 5, y0 - 1.5, (x0 + x1) / 2 + 5, y0 + 2, 1), darken(lid, .15), hl=1, sd=0)

def i_farmer(cv):  # фермер: контейнер с тараканами
    ground(cv, 32, 58, 28, 3)
    bin_(cv, 4, 16, 60, 56, roaches=3)
    cv.paint(M().ell(51, 49, 5.2, 4.2), '#ee8a1c', hl=1, sd=1); cv.flat(M().ell(51, 49, 2.4, 1.8), '#f8b552')
    sparkle(cv, 10, 10, 2.8); sparkle(cv, 57, 12, 2.4)

def i_farm(cv):  # кормовая империя: три контейнера и корона
    ground(cv, 32, 59, 30, 3)
    bin_(cv, 3, 40, 30, 57, roaches=2, lid_h=4); bin_(cv, 34, 40, 61, 57, roaches=2, lid_h=4, lid='#3aa83a')
    bin_(cv, 18.5, 25, 45.5, 41, roaches=2, lid_h=4, lid='#d9502a')
    crown(cv, 32, 13, 1.0); sparkle(cv, 8, 20, 3); sparkle(cv, 57, 22, 3)

def i_decor(cv):  # уютный уголок: домик, растение, камень
    ground(cv, 32, 56, 29, 5, 100)
    cv.paint(M().ell(32, 53, 29, 6), '#4a7a3a', hl=1, sd=2); cv.speckle(M().ell(32, 53, 29, 6), '#7ab35a', 18, 4); cv.speckle(M().ell(32, 53, 29, 6), '#2f5a28', 12, 5)
    hut = M().poly([(8, 52)] + bez((8, 52), (6, 22), (28, 20), 14) + bez((28, 20), (46, 22), (46, 52), 14) + [(46, 52)])
    cv.paint(hut, '#8a5a35', hl=3, sd=3, hlt=.3, sdt=.35)
    for i, y in enumerate((28, 35, 42, 49)): cv.flat(M().path(bez((8 + i * .5, y + 1), (27, y - 4), (46 - i * .5, y + 1), 10), .9), '#5e3a1e', 190, clip=hut)
    cv.speckle(hut, '#b98a58', 14, 7); 
    door = M().ell(27, 50, 8, 11); cv.paint(door, '#1a0e08', hl=0, sd=0, clip=hut, oc=(40, 20, 10))
    cv.flat(M().rect(0, 52, 64, 64), (0, 0, 0), 0)
    for sd_ in (-1, 1): cv.paint(M().ell(27 + sd_ * 2.8, 46, 1.6, 1.8), '#ffd23a', outline=False, hl=0, sd=0); cv.dot(27 + sd_ * 2.8, 46, '#150a08')
    for i, (ang, l) in enumerate(((-1.0, 15), (-.45, 17), (.1, 17), (.65, 15), (-1.5, 11))):
        cv.paint(M().path([(51, 49), (51 + math.sin(ang) * l * .6, 49 - math.cos(ang) * l * .7), (51 + math.sin(ang) * l, 49 - math.cos(ang) * l)], 4.4, 1.4), '#4aa24a', hl=1, sd=1)
    cv.paint(M().ell(51, 50, 3, 2.4), '#2f6e2c', hl=0, sd=0)
    cv.paint(M().ell(14, 56, 6.5, 4.5), '#8b8782', hl=2, sd=2); cv.flat(M().ell(12.5, 54, 2.6, 1.4, -.3), '#cfcbc2')
    sparkle(cv, 54, 20, 3); sparkle(cv, 9, 14, 2.6)

def i_designer(cv):  # дизайнер террариума: большой оформленный террариум
    cv.paint(M().rect(3, 9, 61, 57, 3), '#3a2a1c', hl=2, sd=2)
    gl = M().rect(6, 12, 58, 54); cv.flat(gl, '#9fd0d6'); cv.flat(M().rect(6, 12, 58, 24), '#bfe3e6')
    cv.flat(M().ell(44, 18, 12, 6), '#dff2f2', 130, clip=gl)
    soil = M().rect(6, 43, 58, 54); cv.flat(soil, '#6b4226'); cv.speckle(soil, '#8a5a35', 22, 3); cv.flat(M().rect(6, 43, 58, 44.4), '#8a5a35')
    cv.flat(M().ell(32, 44, 22, 3), '#4a7a3a', clip=gl)
    cv.flat(M().path(bez((46, 12), (49, 22), (44, 32), 8), 1.8), '#3f8f3a', clip=gl)
    for t in (.2, .5, .8): 
        x = 46 + 3 * t - 4 * t * t; y = 12 + 20 * t
        cv.paint(M().ell(x + 2, y, 2.6, 1.4, .4), '#4aa24a', outline=False, hl=0, sd=0, clip=gl)
    hut = M().poly([(9, 46)] + bez((9, 46), (8, 29), (22, 28), 10) + bez((22, 28), (35, 29), (35, 46), 10) + [(35, 46)])
    cv.paint(hut, '#8a5a35', hl=2, sd=2, clip=gl); cv.paint(M().ell(22, 44, 5.4, 7.2), '#1a0e08', hl=0, sd=0, clip=hut, oc=(40, 20, 10))
    for sd_ in (-1, 1): cv.dot(22 + sd_ * 2, 41, '#ffd23a')
    for ang, l in ((-.9, 9), (-.2, 11), (.5, 9), (1.1, 6)):
        cv.paint(M().path([(46, 45), (46 + math.sin(ang) * l * .5, 45 - math.cos(ang) * l * .7), (46 + math.sin(ang) * l, 45 - math.cos(ang) * l)], 3.4, 1.2), '#4aa24a', hl=1, sd=1, clip=gl)
    cv.paint(M().ell(52, 36, 2.6, 2.6), '#ff7ab0', hl=0, sd=0, clip=gl); cv.paint(M().ell(52, 36, 1, 1), '#ffe27a', outline=False, hl=0, sd=0)
    cv.paint(M().ell(39, 48, 5.2, 3.8), '#8b8782', hl=2, sd=2, clip=gl)
    cv.flat(M().poly([(8, 14), (13, 14), (8, 26)]), '#ffffff', 110)
    star(cv, 55, 10, 8.5); sparkle(cv, 6, 8, 3)

def i_happy(cv):  # счастливый питомец
    ground(cv, 32, 58, 20, 3)
    spider(cv, 32, 35, .9, mood='happy', pose=1)
    heart(cv, 9, 13, .62); heart(cv, 55, 14, .55); heart(cv, 32, 9, .5); sparkle(cv, 8, 44, 3); sparkle(cv, 57, 46, 2.6)

def i_rich(cv):  # богач: сундук с сокровищами
    ground(cv, 32, 60, 27, 3)
    lid = M().poly([(9, 36), (13, 13)] + bez((13, 13), (32, 6), (51, 13), 10) + [(55, 36)])
    cv.paint(lid, '#7a4a22', hl=2, sd=2); cv.flat(M().poly([(14, 33), (17, 16)] + bez((17, 16), (32, 11), (47, 16), 8) + [(50, 33)]), '#5a2a1a')
    cv.flat(M().rect(12, 17, 52, 18.5), '#d9941a', 255, clip=lid)
    heap = M().ell(32, 33, 21, 9); cv.paint(heap, '#f2b21c', hl=2, sd=2)
    for (x, y, r) in ((20, 31, 5), (29, 27, 5.4), (40, 30, 5), (47, 33, 4.4), (14, 34, 4.4), (33, 33, 5)): coin(cv, x, y, r)
    cv.paint(M().poly([(22, 24), (26, 20), (30, 24), (26, 29)]), '#3aa0e8', hl=1, sd=1, hlt=.5); cv.flat(M().poly([(24, 23), (26, 21), (27, 23)]), '#cfeaff')
    cv.paint(M().poly([(40, 26), (43, 22), (47, 26), (43, 31)]), '#e0343e', hl=1, sd=1, hlt=.5); cv.flat(M().poly([(42, 25), (43, 23), (44, 25)]), '#ffd0d0')
    front = M().rect(7, 37, 57, 58, 3); cv.paint(front, '#8a5a35', hl=2, sd=3, hlt=.3)
    for x in (18, 30, 42): cv.flat(M().rect(x, 38, x + 1, 57), '#5e3a1e', 200, clip=front)
    cv.paint(M().rect(7, 37, 57, 42.5), '#9aa3ab', hl=1, sd=1, hlt=.5); cv.paint(M().rect(7, 52.5, 57, 58), '#9aa3ab', hl=1, sd=1, hlt=.5)
    cv.paint(M().rect(27, 40, 37, 51, 2), '#f2b21c', hl=1, sd=1, hlt=.5); cv.flat(M().ell(32, 44.5, 1.6, 1.6), '#3a2410'); cv.flat(M().rect(31.2, 44.5, 32.8, 48.5), '#3a2410')
    for x in (10, 54): 
        for y in (40, 55): cv.dot(x, y, '#e8ecee')
    sparkle(cv, 10, 8, 3.4); sparkle(cv, 54, 6, 3); sparkle(cv, 32, 4, 2)

SET = [i_regular, i_week, i_hatch, i_brood, i_cups, i_trader, i_farmer, i_farm, i_decor, i_designer, i_happy, i_rich]
