#!/usr/bin/env python3
"""Рисует спрайты скорпиона №3 (assets/img/scorpion3_{idle,walk,turn,eat}.png). Нужен Pillow + numpy.
Кадры 96x96 в ряд, вид сверху, голова ВНИЗ (как у scorpion/scorpion2). Тело неподвижно,
анимированы 8 ходильных ног (тренога), 2 клешни (рука + пальцы), хвост чуть качается, хелицеры жуют.
Запуск: python3 tools/make_scorpion3.py [--preview]   (--preview кладёт лист в /tmp/sc3_preview.png)"""
import math, sys, pathlib
import numpy as np
from PIL import Image, ImageDraw

F, C = 96, 48
ROOT = pathlib.Path(__file__).resolve().parent.parent / 'assets' / 'img'
OUT = (6, 7, 10, 255)
def hx(s): s = s.lstrip('#'); return tuple(int(s[i:i+2], 16) for i in (0, 2, 4)) + (255,)
# палитры: dk — тень, base, mid, lt — блик, sp — зеркальный блик
PAL = {
 'shell': dict(dk=hx('0b0d12'), base=hx('151922'), mid=hx('1f2531'), lt=hx('323d50'), sp=hx('6f8299')),
 'claw':  dict(dk=hx('0d0f14'), base=hx('171b24'), mid=hx('222a37'), lt=hx('36445a'), sp=hx('7d92aa')),
 'tail':  dict(dk=hx('0e0f14'), base=hx('1a1d26'), mid=hx('272d3a'), lt=hx('3b4658'), sp=hx('6f8299')),
 'sting': dict(dk=hx('3a0f08'), base=hx('6b1d12'), mid=hx('93311f'), lt=hx('c05a34'), sp=hx('f0a070')),
 'acul':  dict(dk=hx('1c0a06'), base=hx('3b150c'), mid=hx('5e2616'), lt=hx('8a4326'), sp=hx('c47a45')),
 'legU':  dict(dk=hx('0b0d12'), base=hx('151922'), mid=hx('1f2531'), lt=hx('323d50'), sp=hx('6f8299')),
 'legL':  dict(dk=hx('0e0f14'), base=hx('1a1d26'), mid=hx('272d3a'), lt=hx('3b4658'), sp=hx('6f8299')),
 'legT':  dict(dk=hx('13151b'), base=hx('222936'), mid=hx('2f3a4b'), lt=hx('44546a'), sp=hx('7d92aa')),
 'pleur': dict(dk=hx('21140b'), base=hx('4a2f1b'), mid=hx('6b4526'), lt=hx('8a6236'), sp=hx('a8803f')),
 'chel':  dict(dk=hx('3a2412'), base=hx('7a5530'), mid=hx('a37a48'), lt=hx('c9a468'), sp=hx('e6cc90')),
}
TEETH = hx('d8d0bc')

def rot(p, a):
    c, s = math.cos(a), math.sin(a); return (p[0]*c - p[1]*s, p[0]*s + p[1]*c)
def ell(cx, cy, rx, ry, deg=0, n=28):
    a = math.radians(deg); out = []
    for i in range(n):
        t = 2*math.pi*i/n; x, y = rx*math.cos(t), ry*math.sin(t); r = rot((x, y), a); out.append((cx+r[0], cy+r[1]))
    return out
def cap(p0, p1, r0, r1):
    dx, dy = p1[0]-p0[0], p1[1]-p0[1]; L = math.hypot(dx, dy) or 1; nx, ny = -dy/L, dx/L
    return [ell(p0[0], p0[1], r0, r0, n=14), ell(p1[0], p1[1], r1, r1, n=14),
            [(p0[0]+nx*r0, p0[1]+ny*r0), (p1[0]+nx*r1, p1[1]+ny*r1), (p1[0]-nx*r1, p1[1]-ny*r1), (p0[0]-nx*r0, p0[1]-ny*r0)]]
def taper(pts, ws):
    L, R = [], []
    for i, p in enumerate(pts):
        a = pts[max(0, i-1)]; b = pts[min(len(pts)-1, i+1)]
        dx, dy = b[0]-a[0], b[1]-a[1]; l = math.hypot(dx, dy) or 1; nx, ny = -dy/l, dx/l
        L.append((p[0]+nx*ws[i]/2, p[1]+ny*ws[i]/2)); R.append((p[0]-nx*ws[i]/2, p[1]-ny*ws[i]/2))
    return [L + R[::-1]]
def er(m):
    p = np.pad(m, 1); return m & p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:]
def dil(m):
    p = np.pad(m, 1); return m | p[:-2, 1:-1] | p[2:, 1:-1] | p[1:-1, :-2] | p[1:-1, 2:]
def sh(m, dx, dy):  # сдвиг маски
    r = np.zeros_like(m); H, W = m.shape
    r[max(0, dy):H+min(0, dy), max(0, dx):W+min(0, dx)] = m[max(0, -dy):H-max(0, dy), max(0, -dx):W-max(0, dx)]; return r

class R:
    def __init__(s, ang=0.0):
        s.ang = ang; s.img = np.zeros((F, F, 4), np.uint8)
    def T(s, p):
        x, y = rot(p, s.ang); return (C + x, C + y)
    def mask(s, polys):
        m = Image.new('L', (F, F), 0); d = ImageDraw.Draw(m)
        if polys and isinstance(polys[0][0], (int, float)): polys = [polys]   # одиночный полигон
        for poly in polys: d.polygon([s.T(p) for p in poly], fill=255)
        return np.array(m) > 0
    def part(s, polys, pal, dots=(), outline=OUT, hl=True, rd=True, cyl=None):
        m = s.mask(polys); P = PAL[pal]
        e1 = er(m); e2 = er(e1); e3 = er(e2)
        L = np.zeros((F, F, 4), np.uint8)
        L[dil(m) & ~m] = outline
        L[m] = P['base']
        ring_dark = m & ~e1 & (~sh(m, -1, -1) | ~sh(m, 0, -1) | ~sh(m, -1, 0))  # низ/право
        L[m & ~e1] = P['base']
        if rd: L[ring_dark] = P['dk']
        L[e1 & ~e2] = P['mid'] if True else P['base']
        L[e2] = P['mid']
        if hl:
            L[e2 & ~sh(e2, 1, 1)] = P['lt']          # блик у верх-лево внутреннего ядра
            L[e3 & ~sh(e3, 1, 1)] = P['sp'] if pal in ('shell', 'claw', 'tail', 'sting', 'legU', 'legL', 'legT') else P['lt']
        if cyl:                                   # объём: блик по оси, тень к бокам (в локальных координатах)
            cx, w = cyl[0], cyl[1]; ca, sa = math.cos(s.ang), math.sin(s.ang)
            yy, xx = np.mgrid[0:F, 0:F]; lx = (xx - C)*ca + (yy - C)*sa; ly = -(xx - C)*sa + (yy - C)*ca
            fr = np.abs(lx - cx + 1.2)/w
            if len(cyl) > 2:                      # купол: радиально от точки блика (cy, h)
                fr = np.hypot((lx - cx + 1.2)/w, (ly - cyl[2])/cyl[3])
            L[e1] = P['base']; L[e1 & (fr < .85)] = P['mid']; L[e1 & (fr < .55)] = P['lt']
            if len(cyl) > 2: L[e1 & (fr < .22)] = P['sp']
            L[m & ~e1 & (lx > cx + w*.3)] = P['dk']; L[e1 & (lx > cx + w*.8)] = P['dk']
        for (x, y) in dots:                       # зернистость (точки в местных координатах)
            X, Y = s.T((x, y)); X, Y = int(round(X)), int(round(Y))
            if 0 <= X < F and 0 <= Y < F and e1[Y, X]: L[Y, X] = P['lt']
        a = L[..., 3] > 0
        s.img[a] = L[a]
    def dot(s, p, col):
        X, Y = s.T(p); X, Y = int(round(X)), int(round(Y))
        if 0 <= X < F and 0 <= Y < F and s.img[Y, X, 3]: s.img[Y, X] = col
    def px(s, p, col):
        X, Y = s.T(p); X, Y = int(round(X)), int(round(Y))
        if 0 <= X < F and 0 <= Y < F: s.img[Y, X] = col
    def done(s): return Image.fromarray(s.img, 'RGBA')

# ---------- геометрия ----------
HIP = [(5.8, 18.0), (6.4, 15.0), (6.8, 12.0), (6.6, 9.0)]            # ноги 1..4 (правая сторона)
REST = [(21.0, 29.0), (26.5, 20.0), (26.5, 6.5), (22.5, -6.0)]
LU, LL = 10.4, 11.8                                                  # бедро+колено / голень+лапка
GROUP = [0, 1, 0, 1]                                                 # тренога: правая 1,3 + левая 2,4 — группа 0
SHOULD = (6.4, 16.5); LA, LC = 12.0, 20.0                            # плечо клешни, длина руки, длина клешни (кисть+пальцы)

def ik(S, T, a, b, sd, out=True):
    dx, dy = T[0]-S[0], T[1]-S[1]; d = math.hypot(dx, dy)
    d = max(abs(a-b)+.2, min(a+b-.05, d)); ux, uy = dx/(math.hypot(dx, dy) or 1), dy/(math.hypot(dx, dy) or 1)
    A = (a*a - b*b + d*d)/(2*d); h = math.sqrt(max(0, a*a - A*A)); mx, my = S[0]+ux*A, S[1]+uy*A
    k1 = (mx - uy*h, my + ux*h); k2 = (mx + uy*h, my - ux*h)
    k = k1 if (k1[0]*sd > k2[0]*sd) == out else k2
    return k, (S[0]+ux*d, S[1]+uy*d)

def leg(r, i, sd, off, lift=0.0):
    hx_, hy_ = HIP[i]; fx, fy = REST[i]
    H = (hx_*sd, hy_); Ft = ((fx - lift*1.6)*sd + off[0]*sd, fy + off[1])
    K, Ft = ik(H, Ft, LU, LL, sd)
    r.part(cap(H, K, 2.0, 1.7), 'legU'); r.part(ell(K[0], K[1], 2.1, 2.1), 'legU')
    r.part(cap(K, Ft, 1.5, 1.0), 'legL')
    dx, dy = Ft[0]-K[0], Ft[1]-K[1]; l = math.hypot(dx, dy) or 1
    tip = (Ft[0]+dx/l*2.2, Ft[1]+dy/l*2.2)
    r.part(cap(Ft, tip, 1.0, .5), 'legT')

def claw(r, sd, T, op, chewing=False):
    S = (SHOULD[0]*sd, SHOULD[1]); Tg = (T[0]*sd, T[1])
    E, Tip = ik(S, Tg, LA, LC, sd)
    r.part(cap(S, E, 3.6, 3.3), 'claw'); r.part(ell(E[0], E[1], 3.7, 3.7), 'claw')
    dx, dy = Tip[0]-E[0], Tip[1]-E[1]; l = math.hypot(dx, dy) or 1; d = (dx/l, dy/l)
    n = (sd*d[1], -sd*d[0])                    # «наружу»
    W = E
    def P(u, v): return (W[0]+d[0]*u+n[0]*v, W[1]+d[1]*u+n[1]*v)
    hc = (4.4, 0.0); hand = ell(*P(5.4, 0.2), 6.6, 4.9, deg=math.degrees(math.atan2(d[1], d[0])))
    dots = [P(u, v) for u in (0.0, 2.0, 4.0, 6.0, 8.0) for v in (-3.6, -1.6, .4, 2.4, 4.2) if ((u-5.4)/6.6)**2+((v-.2)/4.9)**2 < .7]
    # фиксированный (внутренний) палец
    Hi = P(9.6, -2.1); fl = 11.0
    fp = [(Hi[0]+d[0]*fl*t - n[0]*1.6*t*t, Hi[1]+d[1]*fl*t - n[1]*1.6*t*t) for t in (0, .35, .7, 1)]
    # подвижный (внешний) палец — раскрывается наружу
    al = math.radians(42*op); Ho = P(9.6, 2.4)
    dm = (d[0]*math.cos(al)+n[0]*math.sin(al), d[1]*math.cos(al)+n[1]*math.sin(al))
    nm = (n[0]*math.cos(al)-d[0]*math.sin(al), n[1]*math.cos(al)-d[1]*math.sin(al))
    mp = [(Ho[0]+dm[0]*fl*t - nm[0]*4.6*t*t, Ho[1]+dm[1]*fl*t - nm[1]*4.6*t*t) for t in (0, .35, .7, 1)]
    r.part(taper(fp, [4.2, 3.4, 2.2, .7]), 'claw')
    r.part(taper(mp, [4.2, 3.4, 2.2, .7]), 'claw')
    r.part([hand], 'claw', dots=dots)
    if op < .4:                                    # белые зубчики по линии смыкания
        for k, t in enumerate((.35, .5, .65, .8)):
            q = fp[1] if t < .5 else fp[2]
            r.dot((q[0]+n[0]*(.5 if k%2 else -.1), q[1]+n[1]*(.5 if k%2 else -.1)), TEETH)

def tail(r, sw):
    pos = (0.0, -17.0); a = -90.0; segs = []
    bends = [1, 4, 9, 14, 16]; hw = [3.9, 3.6, 3.4, 3.2, 3.0]
    for k in range(5):
        a += bends[k]; aa = math.radians(a + sw*(k+1)/5)
        e = (pos[0]+math.cos(aa)*4.8, pos[1]+math.sin(aa)*4.8); segs.append((pos, e, hw[k], aa)); pos = e
    aa = math.radians(a + 14 + sw*1.1); ve = (pos[0]+math.cos(aa)*6.0, pos[1]+math.sin(aa)*6.0)
    ab = math.radians(a + 14 + 38 + sw*1.2)
    ac = [(ve[0]+math.cos(math.radians(a+14+38*t+sw*1.2))*5.6*t, ve[1]+math.sin(math.radians(a+14+38*t+sw*1.2))*5.6*t) for t in (0, .5, 1)]
    # от дальнего к ближнему
    r.part(taper([ve, ac[1], ac[2]], [2.6, 1.9, .6]), 'tail')
    c = ((pos[0]+ve[0])/2, (pos[1]+ve[1])/2)
    r.part(ell(c[0], c[1], 4.4, 3.4, deg=math.degrees(aa)), 'tail')
    for p0, p1, w, ang in segs[::-1]:
        nx, ny = -math.sin(ang), math.cos(ang)
        q = [(p0[0]+nx*w, p0[1]+ny*w), (p1[0]+nx*(w-.45), p1[1]+ny*(w-.45)), (p1[0]-nx*(w-.45), p1[1]-ny*(w-.45)), (p0[0]-nx*w, p0[1]-ny*w)]
        r.part([q], 'tail', hl=False, cyl=((p0[0]+p1[0])/2, w*.9))

def body(r, chew=0.0, tsw=0.0):
    tail(r, tsw)                                         # хвост под последним тергитом
    HW = [7.6, 7.6, 7.4, 7.2, 6.8, 6.3, 5.6]             # узкое брюшко, чуть шире к голове
    for i in range(6, -1, -1):                           # ровно 7 сегментов: от хвоста до границы панциря (y=+9.6)
        yf = 9.6 - i*3.8; yr = yf - 4.4; w = HW[i]
        r.part([[(-w+1.0, yf), (w-1.0, yf), (w, yf-1), (w*.97, yr+1), (w*.88, yr), (-w*.88, yr), (-w*.97, yr+1), (-w, yf-1)]], 'shell', rd=False, hl=False, cyl=(0, w*1.0))
    for sd in (-1, 1):                                  # хелицеры (жуют)
        ox = 1.9*sd + (-0.9*sd*chew if chew > .5 else .5*sd*chew)
        r.part(cap((1.9*sd, 19.5), (ox, 24.6), 1.7, 1.3), 'chel')
    y0, y1 = 9.6, 21.5
    ys = [y0 + (y1-y0)*k/12 for k in range(13)]; ws = [8.0*(1 - .5*((y-y0)/(y1-y0))**2.0) for y in ys]
    ws[-1] *= .62; ws[-2] *= .86
    r.part([[(w, y) for w, y in zip(ws, ys)] + [(-w, y) for w, y in zip(ws[::-1], ys[::-1])]], 'shell', hl=False, cyl=(0, 8.0, 14.5, 9.0))   # панцирь без «глаз»

# ---------- анимации ----------
def foot_gait(ph, A=4.0, lift=2.0):
    ph %= 1.0
    if ph < .5: return (0, A*(1-4*ph), 0)
    u = (ph-.5)*2; return (0, -A + 2*A*u, math.sin(math.pi*u)*lift)

def draw_legs(r, ph, env=1.0, A=4.0):
    for i in range(4):
        for sd in (1, -1):
            g = GROUP[i] if sd == 1 else 1-GROUP[i]
            _, y, l = foot_gait(ph + g*.5, A*env); leg(r, i, sd, (0, y*(1 if i < 2 else 1)), l*env)

def frame_walk(i, up=False):
    r = R(); ph = i/8
    draw_legs(r, ph)
    body(r, 0, 2.0*math.sin(2*math.pi*ph))
    for sd, c in ((1, 0), (-1, math.pi)):
        s = math.sin(2*math.pi*ph + c)
        claw(r, sd, (9.0 + .6*s, 38.5 + 1.8*s), .22 + .12*s)
    return r.done()

def frame_idle(i):
    r = R(); u = 2*math.pi*i/6
    for k in range(4):
        for sd in (1, -1):
            ph = u + k*1.7 + (0 if sd == 1 else 2.4); off = (.7*math.sin(ph), 1.0*math.sin(ph*1+.9))
            leg(r, k, sd, off, 0.0 + (.9 if math.sin(ph) > .8 else 0))
    body(r, 0, 1.6*math.sin(u))
    for sd, c in ((1, 0), (-1, 2.2)):
        s = math.sin(u + c)
        claw(r, sd, (9.4 + .5*s, 39.0 + 1.2*s), .12 + .18*(1+math.sin(u*1+c+1))/2)
    return r.done()

EAT = [((9.8, 38.5), .35, 0), ((11.5, 40.5), .8, 0), ((5.0, 41.0), 1.0, 0), ((3.8, 41.0), .45, 0), ((2.8, 40.5), 0, 0), ((2.8, 40.0), 0, 0),
       ((2.4, 34.0), 0, .3), ((2.2, 32.5), 0, 0), ((2.2, 32.0), 0, .8), ((2.2, 32.5), 0, 1.0), ((6.0, 37.0), .5, .3), ((9.4, 39.0), .2, 0)]
def frame_eat(i):
    r = R(); T, op, ch = EAT[i]
    for k in range(4):
        for sd in (1, -1):
            w = .5*math.sin(i*1.3 + k*1.1 + (0 if sd == 1 else 2)); leg(r, k, sd, (0, w*(1.6 if k == 0 and 6 <= i <= 9 else 1)), 0)
    body(r, ch, .8*math.sin(i))
    wob = 0.5*math.sin(i*2.4) if 7 <= i <= 9 else 0
    claw(r, 1, (T[0], T[1]+wob), op); claw(r, -1, (T[0], T[1]-wob), op)
    return r.done()

def frame_turn(i):
    r = R(ang=math.pi*i/8); env = min(1, i/1.5, (8-i)/1.5) if 0 < i < 8 else 0
    draw_legs(r, i*.24, env=env, A=3.4)
    body(r, 0, 1.0*math.sin(i))
    s = math.sin(i*.9)
    claw(r, 1, (9.4+.6*s, 37.0), .2+.1*s); claw(r, -1, (9.4-.6*s, 37.0), .2-.1*s)
    return r.done()

def sheet(frames, name):
    im = Image.new('RGBA', (F*len(frames), F), (0, 0, 0, 0))
    for k, f in enumerate(frames): im.paste(f, (F*k, 0))
    im.save(ROOT / name); return im

if __name__ == '__main__':
    sh_ = {'idle': sheet([frame_idle(i) for i in range(6)], 'scorpion3_idle.png'),
           'walk': sheet([frame_walk(i) for i in range(8)], 'scorpion3_walk.png'),
           'turn': sheet([frame_turn(i) for i in range(9)], 'scorpion3_turn.png'),
           'eat':  sheet([frame_eat(i) for i in range(12)], 'scorpion3_eat.png')}
    print({k: v.size for k, v in sh_.items()})
    if '--preview' in sys.argv:
        W = max(v.width for v in sh_.values()); big = Image.new('RGBA', (W, F*4), (122, 98, 66, 255))
        for j, k in enumerate(('idle', 'walk', 'turn', 'eat')): big.alpha_composite(sh_[k], (0, F*j))
        big.save('/tmp/sc3_preview.png')
