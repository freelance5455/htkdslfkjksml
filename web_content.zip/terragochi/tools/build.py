#!/usr/bin/env python3
"""Сборка: index.html + css/ + js/ + assets/ -> dist/terragochi.html (один файл).
Порядок файлов берётся из тегов <link>/<script> в index.html. Запуск: python3 tools/build.py"""
import re, base64, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
html = (root / 'index.html').read_text(encoding='utf-8')

def read(p): return (root / p).read_text(encoding='utf-8')

# CSS: все <link rel=stylesheet> -> один <style>
css_tags = re.findall(r'<link rel="stylesheet" href="([^"]+)">', html)
css = '\n'.join(read(p) for p in css_tags)
# картинки в CSS: url(../assets/img/x.png) -> data URI
css = re.sub(r"url\(\.\./(assets/img/[\w.-]+\.png)\)",
             lambda m: "url(data:image/png;base64," + base64.b64encode((root / m.group(1)).read_bytes()).decode() + ")", css)
html = re.sub(r'<link rel="stylesheet" href="[^"]+">\n?', '', html)
html = html.replace('</head>', f'<style>\n{css}</style>\n</head>', 1)

# JS: все <script src> -> один <script> в исходном порядке
js_tags = re.findall(r'<script src="([^"]+)"></script>', html)
js = '\n'.join(read(p) for p in js_tags)

# картинки: 'assets/img/x.png' -> data URI
def inline(m):
    data = base64.b64encode((root / m.group(1)).read_bytes()).decode()
    return f"'data:image/png;base64,{data}'"
js = re.sub(r"'(assets/img/[\w.-]+\.png)'", inline, js)
# звуки: 'assets/audio/x.mp3' -> data URI
def inline_audio(m):
    data = base64.b64encode((root / m.group(1)).read_bytes()).decode()
    return f"'data:audio/mpeg;base64,{data}'"
js = re.sub(r"'(assets/audio/[\w.-]+\.mp3)'", inline_audio, js)
assert '</script' not in js

html = re.sub(r'<script src="[^"]+"></script>\n?', '', html)
# Быстрый старт: часть до early.js (языки + текст меню) выполняется сразу, остальное (тяжёлое) — после первого кадра
cut = js_tags.index('js/i18n/early.js') + 1
js1 = '\n'.join(read(p) for p in js_tags[:cut])
assert js.startswith(js1)
js2 = js[len(js1):]
loader = r"""(function(){
var q=null,ok=0,banner=0;
// Нажатия, сделанные пока тяжёлая часть ещё грузится, не теряем: запоминаем кнопку и нажимаем её, когда игра готова
function early(e){var b=e.target&&e.target.closest&&e.target.closest('button');if(!b)return;q=b;e.stopPropagation();e.preventDefault()}
document.addEventListener('click',early,true);
// Если игра не смогла запуститься (битое сохранение и т.п.) — показываем понятное сообщение вместо «мёртвых» кнопок
window.addEventListener('error',function(){if(ok||banner||!document.body)return;banner=1;
 var d=document.createElement('div');d.style.cssText='position:fixed;left:8px;right:8px;bottom:8px;z-index:999;background:#3a1810;color:#ffe9c0;border:2px solid #b9791a;border-radius:12px;padding:12px;font:15px system-ui,sans-serif;text-align:center';
 d.innerHTML='<div style="margin-bottom:8px">Ошибка запуска игры / Startup error</div>';
 var a=document.createElement('button'),c=document.createElement('button');a.textContent='Перезагрузить / Reload';c.textContent='Сбросить сохранение / Reset save';
 a.style.cssText=c.style.cssText='margin:3px;padding:8px 12px;font:inherit;border-radius:8px';
 a.onclick=function(){location.reload()};
 c.onclick=function(){if(confirm('Удалить сохранение? / Delete save?')){try{localStorage.removeItem('spiderTama2')}catch(e){}location.reload()}};
 d.appendChild(a);d.appendChild(c);document.body.appendChild(d)});
var d=0;
function go(){if(d)return;d=1;var s=document.createElement('script');s.text=document.getElementById('rest').textContent;document.body.appendChild(s);
 ok=!!window.__ok;document.removeEventListener('click',early,true);var b=q;q=null;
 if(b&&b.isConnected&&!b.disabled)setTimeout(function(){b.click()},0)}
requestAnimationFrame(function(){requestAnimationFrame(go)});setTimeout(go,400)})();"""
html = html.replace('</body>', f'<script>\n{js1}\n{loader}</script>\n<script type="text/plain" id="rest">\n{js2}</script>\n</body>', 1)

out = root / 'dist' / 'terragochi.html'
out.write_text(html, encoding='utf-8')
print(f'{out.relative_to(root)}: {out.stat().st_size/1024:.0f} КБ, JS-файлов: {len(js_tags)}, CSS-файлов: {len(css_tags)}')
