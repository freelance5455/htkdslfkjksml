#!/usr/bin/env python3
"""Рисует иконки достижений 64x64 -> assets/img/ach_icons.png (одна лента, иконки подряд слева направо).
Запуск: python3 tools/make_ach_icons.py   (нужен Pillow). Порядок иконок = номера icon в js/data/achievements.js.
Правка иконки: tools/ach/icons_a.py / icons_b.py (функция i_<имя>), общие рисовалки — tools/ach/kit.py."""
import sys, pathlib
here = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(here / 'ach'))
from kit import Cv, Image, W
import icons_a, icons_b

ORDER = icons_a.SET + icons_b.SET   # 0..24
root = here.parent
sheet = Image.new('RGBA', (W * len(ORDER), W), (0, 0, 0, 0))
for i, fn in enumerate(ORDER):
    cv = Cv(); fn(cv); sheet.alpha_composite(cv.finish(), (i * W, 0))
out = root / 'assets' / 'img' / 'ach_icons.png'
sheet.save(out, optimize=True)
print(f'{out.relative_to(root)}: {len(ORDER)} иконок, {sheet.width}x{sheet.height}, {out.stat().st_size/1024:.0f} КБ')
if '--preview' in sys.argv:
    cols = 7; rows = (len(ORDER) + cols - 1) // cols
    pv = Image.new('RGBA', (W * cols, W * rows), (40, 70, 55, 255))
    for i in range(len(ORDER)): pv.alpha_composite(sheet.crop((i * W, 0, i * W + W, W)), ((i % cols) * W, (i // cols) * W))
    pv.resize((pv.width * 3, pv.height * 3), Image.NEAREST).save('/home/claude/ach_preview.png')
