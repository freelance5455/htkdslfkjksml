# Carreira de Craque v1.46.8

- Corrigido o lugar certo da interface: **Ligas → Brasil** (`brazilWorldView`).
- G4 verde forte nas Séries A, B e C.
- Z4 vermelho nas Séries A e B.
- Legenda da zona verde/vermelha adicionada logo abaixo da classificação.
- Estilos aplicados diretamente nas células da tabela para não depender apenas da cor da linha.
