-- SANBANK — bloqueio administrativo do acesso ao aplicativo por conta.
-- O Gerente só pode bloquear contas com aparelho registrado por consentimento.
-- A sessão do usuário consulta apenas o próprio status; não altera saldo ou dados financeiros.
begin;

create table if not exists public.sanbank_app_access_controls (
  account text primary key check (account ~ '^[0-9]{6}$'),
  blocked boolean not null default false,
  block_id uuid not null default gen_random_uuid(),
  block_reason text not null default '',
  source_installation_id uuid,
  blocked_by text,
  blocked_at timestamptz,
  updated_at timestamptz not null default now(),
  unblocked_by text,
  unblocked_at timestamptz,
  unblock_reason text not null default ''
);

alter table public.sanbank_app_access_controls enable row level security;
revoke all on table public.sanbank_app_access_controls from public, anon, authenticated;

create or replace function public.sanbank_admin_app_access_list()
returns setof jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public, extensions
as $function$
declare
  v_me text := public.sanbank_current_account();
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  if not coalesce(public.sanbank_is_admin(), false) then raise exception 'SANBANK_ADMIN_REQUIRED'; end if;
  return query
    with latest_devices as (
      select distinct on (d.account) d.*
      from public.sanbank_device_registrations d
      where d.consent_status = 'accepted'
      order by d.account, d.last_seen desc, d.id desc
    )
    select coalesce(to_jsonb(d), '{}'::jsonb) || jsonb_build_object(
      'account', coalesce(d.account, c.account),
      'installation_id', coalesce(d.installation_id, c.source_installation_id),
      'device_model', coalesce(d.device_model, 'Registro de aparelho indisponível'),
      'device_manufacturer', coalesce(d.device_manufacturer, ''),
      'android_version', coalesce(d.android_version, ''),
      'android_sdk', d.android_sdk,
      'app_version', coalesce(d.app_version, ''),
      'last_seen', coalesce(d.last_seen, c.updated_at),
      'server_observed_ip', case when d.server_observed_ip is null then null else host(d.server_observed_ip) end,
      'app_blocked', coalesce(c.blocked, false),
      'app_block_id', c.block_id,
      'app_block_reason', coalesce(c.block_reason, ''),
      'app_blocked_at', c.blocked_at,
      'app_unblocked_at', c.unblocked_at
    )
    from latest_devices d
    full outer join public.sanbank_app_access_controls c on c.account = d.account
    where d.account is not null or coalesce(c.blocked, false)
    order by coalesce(d.last_seen, c.updated_at) desc nulls last, coalesce(d.account, c.account);
end;
$function$;

create or replace function public.sanbank_admin_block_app_access(
  p_account text,
  p_installation_id uuid,
  p_reason text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public, extensions
as $function$
declare
  v_me text := public.sanbank_current_account();
  v_row public.sanbank_app_access_controls%rowtype;
  v_reason text := left(trim(coalesce(p_reason, '')), 500);
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  if not coalesce(public.sanbank_is_admin(), false) then raise exception 'SANBANK_ADMIN_REQUIRED'; end if;
  if p_account is null or p_account !~ '^[0-9]{6}$' then raise exception 'SANBANK_DEVICE_ACCOUNT_REQUIRED'; end if;
  if p_installation_id is null then raise exception 'SANBANK_DEVICE_INSTALLATION_REQUIRED'; end if;
  if not exists (
    select 1 from public.sanbank_device_registrations d
    where d.account = p_account and d.installation_id = p_installation_id and d.consent_status = 'accepted'
  ) then raise exception 'SANBANK_CONSENTED_DEVICE_NOT_FOUND'; end if;
  if v_reason = '' then v_reason := 'Movimentações suspeitas ou componente estranho'; end if;

  insert into public.sanbank_app_access_controls (
    account, blocked, block_id, block_reason, source_installation_id, blocked_by, blocked_at,
    updated_at, unblocked_by, unblocked_at, unblock_reason
  ) values (
    p_account, true, gen_random_uuid(), v_reason, p_installation_id, v_me, now(), now(), null, null, ''
  )
  on conflict (account) do update set
    blocked = true,
    block_id = case when public.sanbank_app_access_controls.blocked
      then public.sanbank_app_access_controls.block_id else gen_random_uuid() end,
    block_reason = excluded.block_reason,
    source_installation_id = excluded.source_installation_id,
    blocked_by = v_me,
    blocked_at = case when public.sanbank_app_access_controls.blocked
      then public.sanbank_app_access_controls.blocked_at else now() end,
    updated_at = now(),
    unblocked_by = null,
    unblocked_at = null,
    unblock_reason = ''
  returning * into v_row;

  return to_jsonb(v_row) || jsonb_build_object('ok', true);
end;
$function$;

create or replace function public.sanbank_admin_unblock_app_access(
  p_account text,
  p_reason text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public, extensions
as $function$
declare
  v_me text := public.sanbank_current_account();
  v_count integer := 0;
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  if not coalesce(public.sanbank_is_admin(), false) then raise exception 'SANBANK_ADMIN_REQUIRED'; end if;
  if p_account is null or p_account !~ '^[0-9]{6}$' then raise exception 'SANBANK_DEVICE_ACCOUNT_REQUIRED'; end if;
  update public.sanbank_app_access_controls
     set blocked = false,
         updated_at = now(),
         unblocked_by = v_me,
         unblocked_at = now(),
         unblock_reason = left(trim(coalesce(p_reason, '')), 500)
   where account = p_account and blocked = true;
  get diagnostics v_count = row_count;
  return jsonb_build_object('ok', true, 'account', p_account, 'unblocked', v_count > 0);
end;
$function$;

create or replace function public.sanbank_check_my_app_access()
returns jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public, extensions
as $function$
declare
  v_me text := public.sanbank_current_account();
  v_row public.sanbank_app_access_controls%rowtype;
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  if v_me !~ '^[0-9]{6}$' or coalesce(public.sanbank_is_admin(), false) then
    return jsonb_build_object('blocked', false, 'account', v_me);
  end if;
  select * into v_row from public.sanbank_app_access_controls where account = v_me;
  if not found then return jsonb_build_object('blocked', false, 'account', v_me); end if;
  return jsonb_build_object(
    'blocked', v_row.blocked,
    'account', v_me,
    'block_id', v_row.block_id,
    'reason', v_row.block_reason,
    'blocked_at', v_row.blocked_at,
    'updated_at', v_row.updated_at
  );
end;
$function$;

revoke all on function public.sanbank_admin_app_access_list() from public;
grant execute on function public.sanbank_admin_app_access_list() to anon, authenticated;
revoke all on function public.sanbank_admin_block_app_access(text, uuid, text) from public;
grant execute on function public.sanbank_admin_block_app_access(text, uuid, text) to anon, authenticated;
revoke all on function public.sanbank_admin_unblock_app_access(text, text) from public;
grant execute on function public.sanbank_admin_unblock_app_access(text, text) to anon, authenticated;
revoke all on function public.sanbank_check_my_app_access() from public;
grant execute on function public.sanbank_check_my_app_access() to anon, authenticated;

notify pgrst, 'reload schema';
commit;
