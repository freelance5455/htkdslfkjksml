LUNAR — Android Studio project

WHAT THIS IS
A starter Android project that wraps the supplied LUNAR HTML app in an Android WebView. It includes the HTML at app/src/main/assets/index.html and supports JavaScript, browser storage, online YouTube requests, and the HTML audio-file picker.

BUILD AN APK
1. Unzip LUNAR-Android.zip.
2. On the PC, open Android Studio.
3. Choose Open and select the unzipped LUNAR-Android folder (the folder containing settings.gradle).
4. Allow Gradle sync and install any SDK platform Android Studio asks for.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build completes, use the notification's Locate link. The APK is usually at app/build/outputs/apk/debug/app-debug.apk.

IMPORTANT
- This is a starter project, not a compiled or tested APK. Android Studio must build it.
- For public distribution, test the APK on real devices first. A public download link requires uploading the APK to a hosting/release service. Google Play publishing is a separate process.
- The YouTube search section still requires the app user to supply their own YouTube Data API v3 key, as in the original HTML.
