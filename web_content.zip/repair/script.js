// Database Key Access
const validKeys = {
    "AFYGX": "PROJECT",
    "Rend": "Rend12",
    "FREE1": "FREE2"
};

let animationInterval = null;

// Handle Login Form
function handleLogin() {
    const userVal = document.getElementById("username").value.trim();
    const passVal = document.getElementById("password").value.trim();
    const errText = document.getElementById("login-error");

    if (validKeys[userVal] && validKeys[userVal] === passVal) {
        document.getElementById("login-screen").classList.remove("active");
        document.getElementById("app-screen").classList.add("active");
        startPerformanceAnimation(true); // Default ON
    } else {
        errText.innerText = "Username atau Password Salah!";
    }
}

// Sakelar Mute / Unmute Musik Video
function toggleMuteVideo() {
    const video = document.getElementById('bg-video');
    const icons = document.querySelectorAll('.mute-icon');

    if (video) {
        if (video.muted) {
            video.muted = false;
            video.play();
            icons.forEach(icon => {
                icon.className = 'mute-icon fa-solid fa-volume-high';
            });
        } else {
            video.muted = true;
            icons.forEach(icon => {
                icon.className = 'mute-icon fa-solid fa-volume-xmark';
            });
        }
    }
}

// Navigasi Tab
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));

    document.getElementById(tabId).classList.add('active');

    if (tabId === 'tab-home') document.getElementById('nav-home').classList.add('active');
    if (tabId === 'tab-aim') document.getElementById('nav-aim').classList.add('active');
    if (tabId === 'tab-boost') document.getElementById('nav-boost').classList.add('active');
}

// Tampilkan Popup di Tengah
function showPopup(message) {
    document.getElementById("modal-text").innerText = message;
    document.getElementById("center-modal").style.display = "flex";
}

function closePopup() {
    document.getElementById("center-modal").style.display = "none";
}

// Trigger Switch Toggle di AIM & BOOST
function onToggleFeature(switchEl) {
    if (switchEl.checked) {
        showPopup("Pemasangan Berhasil");
    }
}

// Performance Mode Animation
function togglePerformanceMode(switchEl) {
    const statusText = document.getElementById("switch-status-text");
    statusText.innerText = switchEl.checked ? "ON" : "OFF";
    startPerformanceAnimation(switchEl.checked);
}

function startPerformanceAnimation(isOn) {
    if (animationInterval) clearInterval(animationInterval);

    const ring = document.getElementById('perf-ring');
    const valText = document.getElementById('perf-val');
    const radius = 88;
    const circumference = 2 * Math.PI * radius;

    ring.style.strokeDasharray = `${circumference} ${circumference}`;

    animationInterval = setInterval(() => {
        let min = isOn ? 60 : 30;
        let max = isOn ? 98 : 50;

        let randomVal = Math.floor(Math.random() * (max - min + 1)) + min;
        valText.innerText = randomVal + "%";

        const offset = circumference - (randomVal / 100) * circumference;
        ring.style.strokeDashoffset = offset;
    }, 1200);
}
function handleLogin() {
    const userVal = document.getElementById("username").value.trim();
    const passVal = document.getElementById("password").value.trim();
    const errText = document.getElementById("login-error");

    if (validKeys[userVal] && validKeys[userVal] === passVal) {
        document.getElementById("login-screen").classList.remove("active");
        document.getElementById("app-screen").classList.add("active");
        startPerformanceAnimation(false); // Diubah ke false agar default OFF
    } else {
        errText.innerText = "Username atau Password Salah!";
    }
}
