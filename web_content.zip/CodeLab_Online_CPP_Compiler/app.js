(() => {
  const $ = id => document.getElementById(id);
  const DEFAULT_API = "https://ce.judge0.com";
  const starter = {
    c: '#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    printf("Enter two numbers: ");\n    scanf("%d %d", &a, &b);\n    printf("Sum = %d\\\\n", a + b);\n    return 0;\n}\n',
    cpp: '#include <iostream>\nusing namespace std;\n\nint main() {\n    int a, b;\n    cout << "Enter two numbers: ";\n    cin >> a >> b;\n    cout << "Sum = " << a + b << endl;\n    return 0;\n}\n'
  };
  let api = localStorage.getItem("codelab_api") || DEFAULT_API;
  let apiKey = localStorage.getItem("codelab_key") || "";
  let currentFile = "main.cpp";
  const code = $("code"), language = $("language");
  const saved = localStorage.getItem("codelab_code_cpp");
  code.value = saved || starter.cpp;

  function updateLines() {
    const count = code.value.split("\n").length;
    $("lineNumbers").textContent = Array.from({length: count}, (_,i) => i+1).join("\n");
    $("lineNumbers").scrollTop = code.scrollTop;
    const before = code.value.slice(0, code.selectionStart).split("\n");
    $("cursorInfo").textContent = `Line ${before.length}, Column ${before[before.length-1].length+1}`;
  }
  function setFilename() {
    currentFile = language.value === "c" ? "main.c" : "main.cpp";
    $("filename").textContent = currentFile;
  }
  function saveLocal() {
    localStorage.setItem("codelab_code_" + language.value, code.value);
    $("saveStatus").textContent = "Saved in this browser";
  }
  function setMessage(el, value, cls="") {
    el.textContent = value;
    if (cls) el.className = cls;
  }
  code.addEventListener("input", () => { updateLines(); $("saveStatus").textContent = "Unsaved changes"; });
  code.addEventListener("click", updateLines);
  code.addEventListener("keyup", updateLines);
  code.addEventListener("scroll", () => $("lineNumbers").scrollTop = code.scrollTop);
  code.addEventListener("keydown", e => {
    if (e.key === "Tab") {
      e.preventDefault();
      const start = code.selectionStart, end = code.selectionEnd;
      code.setRangeText("    ", start, end, "end"); updateLines();
    }
    if (e.key === "Enter" && e.ctrlKey) runCode();
  });
  language.addEventListener("change", () => {
    saveLocal();
    code.value = localStorage.getItem("codelab_code_" + language.value) || starter[language.value];
    setFilename(); updateLines(); $("saveStatus").textContent = "Ready";
  });
  $("newBtn").onclick = () => {
    if (!confirm("Start a new blank program? Save your current code first if needed.")) return;
    code.value = language.value === "c" ? starter.c : starter.cpp;
    updateLines(); $("saveStatus").textContent = "New program";
  };
  $("saveBtn").onclick = saveLocal;
  $("downloadBtn").onclick = () => {
    const blob = new Blob([code.value], {type:"text/plain;charset=utf-8"});
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = currentFile; a.click();
    URL.revokeObjectURL(a.href);
  };
  $("openBtn").onclick = () => $("filePicker").click();
  $("filePicker").addEventListener("change", async e => {
    const file = e.target.files[0]; if (!file) return;
    code.value = await file.text();
    if (file.name.toLowerCase().endsWith(".c")) language.value = "c";
    else if (/\.(cpp|cc|hpp)$/i.test(file.name)) language.value = "cpp";
    currentFile = file.name; $("filename").textContent = currentFile; updateLines();
    $("saveStatus").textContent = "Opened " + file.name; e.target.value = "";
  });
  $("clearInputBtn").onclick = () => $("stdin").value = "";
  $("clearOutputBtn").onclick = () => setMessage($("output"), "Your program output will appear here.", "output-area muted");
  $("clearErrorBtn").onclick = () => setMessage($("errors"), "No compiler messages.", "error-area muted");
  $("copyOutputBtn").onclick = async () => {
    try { await navigator.clipboard.writeText($("output").textContent); $("runStatus").textContent = "Output copied"; }
    catch { $("runStatus").textContent = "Clipboard access unavailable"; }
  };
  $("themeBtn").onclick = () => document.body.classList.toggle("light");
  $("settingsBtn").onclick = () => {
    $("apiUrl").value = api; $("apiKey").value = apiKey; $("settingsDialog").showModal();
  };
  $("resetApiBtn").onclick = () => { $("apiUrl").value = DEFAULT_API; $("apiKey").value = ""; };
  $("saveApiBtn").onclick = e => {
    e.preventDefault();
    api = $("apiUrl").value.trim().replace(/\/+$/, "") || DEFAULT_API;
    apiKey = $("apiKey").value.trim();
    localStorage.setItem("codelab_api", api); localStorage.setItem("codelab_key", apiKey);
    $("settingsDialog").close(); $("runStatus").textContent = "API settings saved";
  };

  const b64encode = str => {
    const bytes = new TextEncoder().encode(str);
    let binary = ""; bytes.forEach(b => binary += String.fromCharCode(b));
    return btoa(binary);
  };
  const b64decode = str => {
    if (!str) return "";
    const binary = atob(str); const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  };
  const headers = () => {
    const h = {"Content-Type":"application/json"};
    if (apiKey) { h["X-RapidAPI-Key"] = apiKey; h["X-RapidAPI-Host"] = new URL(api).host; }
    return h;
  };
  async function runCode() {
    const btn = $("runBtn");
    btn.disabled = true; btn.innerHTML = "Running…";
    setMessage($("output"), "Submitting code to online compiler…", "output-area muted");
    setMessage($("errors"), "Waiting for compiler…", "error-area muted");
    $("runStatus").textContent = "Compiling";
    try {
      const payload = {
        source_code: b64encode(code.value),
        language_id: language.value === "c" ? 50 : 54,
        stdin: b64encode($("stdin").value),
        cpu_time_limit: 5,
        wall_time_limit: 10
      };
      const response = await fetch(api + "/submissions?base64_encoded=true&wait=false", {
        method:"POST", headers:headers(), body:JSON.stringify(payload)
      });
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`Compiler API returned ${response.status}: ${detail.slice(0,500)}`);
      }
      const submitted = await response.json();
      if (!submitted.token) throw new Error("The compiler did not return a submission token.");
      let result = null;
      for (let i=0; i<30; i++) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        const poll = await fetch(api + "/submissions/" + encodeURIComponent(submitted.token) + "?base64_encoded=true", {headers:headers()});
        if (!poll.ok) throw new Error(`Could not get result (${poll.status}).`);
        result = await poll.json();
        if (result.status && result.status.id > 2) break;
      }
      if (!result || !result.status || result.status.id <= 2) throw new Error("Execution is taking too long. Please try again.");
      const stdout = b64decode(result.stdout);
      const stderr = b64decode(result.stderr);
      const compile = b64decode(result.compile_output);
      const message = [compile, stderr, result.message || ""].filter(Boolean).join("\n").trim();
      setMessage($("output"), stdout || (message ? "No standard output." : "Program finished with no output."), "output-area");
      setMessage($("errors"), message || "No compiler errors.", "error-area" + (message ? "" : " muted"));
      const status = result.status.description || "Finished";
      $("runStatus").textContent = `${status}${result.time ? " · " + result.time + "s" : ""}${result.memory ? " · " + result.memory + " KB" : ""}`;
    } catch (err) {
      setMessage($("output"), "Unable to run program.", "output-area muted");
      setMessage($("errors"), err.message + "\n\nCheck your internet connection and API settings. The public compiler service may be rate-limited.", "error-area");
      $("runStatus").textContent = "Run failed";
    } finally {
      btn.disabled = false; btn.innerHTML = "<span>▶</span> Run code";
    }
  }
  $("runBtn").onclick = runCode;
  setFilename(); updateLines();
})();