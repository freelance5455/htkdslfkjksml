# CodeLab — Online C/C++ Compiler

A responsive, single-column C/C++ practice IDE. It uses the Judge0-compatible online submissions API.

## Included
- C (GCC) and C++ (G++) selection
- Browser code editor with line numbers, tab indentation, and Ctrl+Enter to run
- Program input box for `scanf()` / `cin`
- Separate program output and compiler messages
- Open, save-to-browser, and download `.c` / `.cpp` files
- Light/dark theme toggle
- Configurable Judge0 API endpoint and optional API key

## Run locally
Open `index.html` in a modern browser, or serve this folder using a static web server.

## Deploy to Netlify
1. Extract the ZIP.
2. Drag the extracted folder (containing `index.html`) into Netlify Drop, or connect the folder/repository to Netlify.
3. No build command or publish directory is required (the root folder is the publish directory).

## Online compiler configuration
The default API base URL is `https://ce.judge0.com`. If that public endpoint is unavailable, rate-limited, or blocks browser requests, open **API settings** and enter a Judge0-compatible API base URL. If your provider requires RapidAPI authentication, enter your key there.

For production use, do not expose a private API key in a public frontend. Put the key behind your own serverless/backend proxy and configure the app to call that proxy.

## Important input limitation
This frontend sends the complete contents of the Program input box with the submission. Enter all values before clicking **Run code**. Judge0 submissions do not provide a live terminal/PTY where a user can type more input after the program has started and printed a prompt. True prompt-by-prompt interactive input requires a separate backend that runs processes in a pseudo-terminal and streams input/output over WebSockets.

## Language IDs
- C (GCC): 50
- C++ (G++): 54
