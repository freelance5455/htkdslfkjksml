const products = [];
let id=1;
products.push({id:id++,name:'Wireless Headphones',cat:'Electronics',price:499,emoji:'📱'});
products.push({id:id++,name:'Smart Watch Pro',cat:'Electronics',price:672,emoji:'📱'});
products.push({id:id++,name:'Bluetooth Speaker',cat:'Electronics',price:845,emoji:'📱'});
products.push({id:id++,name:'Wireless Earbuds',cat:'Electronics',price:1018,emoji:'📱'});
products.push({id:id++,name:'Power Bank 20000mAh',cat:'Electronics',price:1191,emoji:'📱'});
products.push({id:id++,name:'Fast USB Charger',cat:'Electronics',price:1364,emoji:'📱'});
products.push({id:id++,name:'USB-C Cable',cat:'Electronics',price:1537,emoji:'📱'});
products.push({id:id++,name:'Phone Stand',cat:'Electronics',price:1710,emoji:'📱'});
products.push({id:id++,name:'Wireless Mouse',cat:'Electronics',price:1883,emoji:'📱'});
products.push({id:id++,name:'Mechanical Keyboard',cat:'Electronics',price:2056,emoji:'📱'});
products.push({id:id++,name:'1080p Webcam',cat:'Electronics',price:2229,emoji:'📱'});
products.push({id:id++,name:'LED Desk Light',cat:'Electronics',price:2402,emoji:'📱'});
products.push({id:id++,name:'Mini Projector',cat:'Electronics',price:2575,emoji:'📱'});
products.push({id:id++,name:'Smart LED Bulb',cat:'Electronics',price:2748,emoji:'📱'});
products.push({id:id++,name:'Portable Fan',cat:'Electronics',price:2921,emoji:'📱'});
products.push({id:id++,name:'Digital Alarm Clock',cat:'Electronics',price:3094,emoji:'📱'});
products.push({id:id++,name:'Gaming Headset',cat:'Electronics',price:3267,emoji:'📱'});
products.push({id:id++,name:'Phone Tripod',cat:'Electronics',price:3440,emoji:'📱'});
products.push({id:id++,name:'Smart Home Camera',cat:'Electronics',price:3613,emoji:'📱'});
products.push({id:id++,name:'Bluetooth Keyboard',cat:'Electronics',price:3786,emoji:'📱'});
products.push({id:id++,name:'Laptop Cooling Pad',cat:'Electronics',price:3959,emoji:'📱'});
products.push({id:id++,name:'HDMI Cable',cat:'Electronics',price:4132,emoji:'📱'});
products.push({id:id++,name:'USB Hub',cat:'Electronics',price:4305,emoji:'📱'});
products.push({id:id++,name:'Fitness Smart Band',cat:'Electronics',price:4478,emoji:'📱'});
products.push({id:id++,name:'Car Phone Charger',cat:'Electronics',price:4651,emoji:'📱'});
products.push({id:id++,name:'Streetwear Hoodie',cat:'Fashion',price:399,emoji:'👕'});
products.push({id:id++,name:'Running Sneakers',cat:'Fashion',price:572,emoji:'👕'});
products.push({id:id++,name:'Classic T-Shirt',cat:'Fashion',price:745,emoji:'👕'});
products.push({id:id++,name:'Denim Jeans',cat:'Fashion',price:918,emoji:'👕'});
products.push({id:id++,name:'Casual Shirt',cat:'Fashion',price:1091,emoji:'👕'});
products.push({id:id++,name:'Sports Shorts',cat:'Fashion',price:1264,emoji:'👕'});
products.push({id:id++,name:'Cotton Joggers',cat:'Fashion',price:1437,emoji:'👕'});
products.push({id:id++,name:'Winter Jacket',cat:'Fashion',price:1610,emoji:'👕'});
products.push({id:id++,name:'Baseball Cap',cat:'Fashion',price:1783,emoji:'👕'});
products.push({id:id++,name:'Classic Sunglasses',cat:'Fashion',price:1956,emoji:'👕'});
products.push({id:id++,name:'Leather Wallet',cat:'Fashion',price:2129,emoji:'👕'});
products.push({id:id++,name:'Casual Backpack',cat:'Fashion',price:2302,emoji:'👕'});
products.push({id:id++,name:'Sports Socks Pack',cat:'Fashion',price:2475,emoji:'👕'});
products.push({id:id++,name:'Canvas Shoes',cat:'Fashion',price:2648,emoji:'👕'});
products.push({id:id++,name:'Flip Flops',cat:'Fashion',price:2821,emoji:'👕'});
products.push({id:id++,name:'Formal Trousers',cat:'Fashion',price:2994,emoji:'👕'});
products.push({id:id++,name:'Polo T-Shirt',cat:'Fashion',price:3167,emoji:'👕'});
products.push({id:id++,name:'Oversized T-Shirt',cat:'Fashion',price:3340,emoji:'👕'});
products.push({id:id++,name:'Rain Jacket',cat:'Fashion',price:3513,emoji:'👕'});
products.push({id:id++,name:'Travel Duffle Bag',cat:'Fashion',price:3686,emoji:'👕'});
products.push({id:id++,name:'Running Cap',cat:'Fashion',price:3859,emoji:'👕'});
products.push({id:id++,name:'Fashion Belt',cat:'Fashion',price:4032,emoji:'👕'});
products.push({id:id++,name:'Winter Beanie',cat:'Fashion',price:4205,emoji:'👕'});
products.push({id:id++,name:'Sports Tracksuit',cat:'Fashion',price:4378,emoji:'👕'});
products.push({id:id++,name:'Classic Watch',cat:'Fashion',price:4551,emoji:'👕'});
products.push({id:id++,name:'Gaming Controller',cat:'Gaming',price:599,emoji:'🎮'});
products.push({id:id++,name:'RGB Gaming Keyboard',cat:'Gaming',price:772,emoji:'🎮'});
products.push({id:id++,name:'Gaming Mouse',cat:'Gaming',price:945,emoji:'🎮'});
products.push({id:id++,name:'RGB Mouse Pad',cat:'Gaming',price:1118,emoji:'🎮'});
products.push({id:id++,name:'Gaming Chair',cat:'Gaming',price:1291,emoji:'🎮'});
products.push({id:id++,name:'USB Gaming Microphone',cat:'Gaming',price:1464,emoji:'🎮'});
products.push({id:id++,name:'Gaming Desk Mat',cat:'Gaming',price:1637,emoji:'🎮'});
products.push({id:id++,name:'Controller Stand',cat:'Gaming',price:1810,emoji:'🎮'});
products.push({id:id++,name:'RGB Light Strip',cat:'Gaming',price:1983,emoji:'🎮'});
products.push({id:id++,name:'Gaming Headphones',cat:'Gaming',price:2156,emoji:'🎮'});
products.push({id:id++,name:'Mobile Gaming Trigger',cat:'Gaming',price:2329,emoji:'🎮'});
products.push({id:id++,name:'Phone Gaming Cooler',cat:'Gaming',price:2502,emoji:'🎮'});
products.push({id:id++,name:'Gamepad Holder',cat:'Gaming',price:2675,emoji:'🎮'});
products.push({id:id++,name:'Gaming Mouse Bungee',cat:'Gaming',price:2848,emoji:'🎮'});
products.push({id:id++,name:'RGB Gaming Speakers',cat:'Gaming',price:3021,emoji:'🎮'});
products.push({id:id++,name:'Streaming Light',cat:'Gaming',price:3194,emoji:'🎮'});
products.push({id:id++,name:'Keyboard Wrist Rest',cat:'Gaming',price:3367,emoji:'🎮'});
products.push({id:id++,name:'Console Storage Stand',cat:'Gaming',price:3540,emoji:'🎮'});
products.push({id:id++,name:'Gaming Laptop Stand',cat:'Gaming',price:3713,emoji:'🎮'});
products.push({id:id++,name:'Gaming Finger Sleeves',cat:'Gaming',price:3886,emoji:'🎮'});
products.push({id:id++,name:'Controller Charging Dock',cat:'Gaming',price:4059,emoji:'🎮'});
products.push({id:id++,name:'RGB Gaming Desk Lamp',cat:'Gaming',price:4232,emoji:'🎮'});
products.push({id:id++,name:'Gaming Cable Organizer',cat:'Gaming',price:4405,emoji:'🎮'});
products.push({id:id++,name:'Gaming Webcam',cat:'Gaming',price:4578,emoji:'🎮'});
products.push({id:id++,name:'Portable Game Controller',cat:'Gaming',price:4751,emoji:'🎮'});
products.push({id:id++,name:'Modern Table Lamp',cat:'Home',price:299,emoji:'🏠'});
products.push({id:id++,name:'Coffee Maker',cat:'Home',price:472,emoji:'🏠'});
products.push({id:id++,name:'Electric Kettle',cat:'Home',price:645,emoji:'🏠'});
products.push({id:id++,name:'Non Stick Fry Pan',cat:'Home',price:818,emoji:'🏠'});
products.push({id:id++,name:'Dinner Plate Set',cat:'Home',price:991,emoji:'🏠'});
products.push({id:id++,name:'Water Bottle',cat:'Home',price:1164,emoji:'🏠'});
products.push({id:id++,name:'Storage Box Set',cat:'Home',price:1337,emoji:'🏠'});
products.push({id:id++,name:'Wall Clock',cat:'Home',price:1510,emoji:'🏠'});
products.push({id:id++,name:'Cushion Set',cat:'Home',price:1683,emoji:'🏠'});
products.push({id:id++,name:'Bedsheet Set',cat:'Home',price:1856,emoji:'🏠'});
products.push({id:id++,name:'Pillow Pair',cat:'Home',price:2029,emoji:'🏠'});
products.push({id:id++,name:'Kitchen Knife Set',cat:'Home',price:2202,emoji:'🏠'});
products.push({id:id++,name:'Lunch Box',cat:'Home',price:2375,emoji:'🏠'});
products.push({id:id++,name:'Glass Tumbler Set',cat:'Home',price:2548,emoji:'🏠'});
products.push({id:id++,name:'Floor Mat',cat:'Home',price:2721,emoji:'🏠'});
products.push({id:id++,name:'Laundry Basket',cat:'Home',price:2894,emoji:'🏠'});
products.push({id:id++,name:'Clothes Hangers Pack',cat:'Home',price:3067,emoji:'🏠'});
products.push({id:id++,name:'Vacuum Cleaner',cat:'Home',price:3240,emoji:'🏠'});
products.push({id:id++,name:'Air Purifier',cat:'Home',price:3413,emoji:'🏠'});
products.push({id:id++,name:'Mini Blender',cat:'Home',price:3586,emoji:'🏠'});
products.push({id:id++,name:'Toaster',cat:'Home',price:3759,emoji:'🏠'});
products.push({id:id++,name:'Rice Cooker',cat:'Home',price:3932,emoji:'🏠'});
products.push({id:id++,name:'Spice Rack',cat:'Home',price:4105,emoji:'🏠'});
products.push({id:id++,name:'LED Night Light',cat:'Home',price:4278,emoji:'🏠'});
products.push({id:id++,name:'Decorative Vase',cat:'Home',price:4451,emoji:'🏠'});
products.push({id:id++,name:'Face Wash',cat:'Beauty',price:199,emoji:'🧴'});
products.push({id:id++,name:'Shampoo',cat:'Beauty',price:372,emoji:'🧴'});
products.push({id:id++,name:'Body Lotion',cat:'Beauty',price:545,emoji:'🧴'});
products.push({id:id++,name:'Hair Brush',cat:'Beauty',price:718,emoji:'🧴'});
products.push({id:id++,name:'Makeup Organizer',cat:'Beauty',price:891,emoji:'🧴'});
products.push({id:id++,name:'Lip Balm',cat:'Beauty',price:1064,emoji:'🧴'});
products.push({id:id++,name:'Perfume Gift Set',cat:'Beauty',price:1237,emoji:'🧴'});
products.push({id:id++,name:'Hand Cream',cat:'Beauty',price:1410,emoji:'🧴'});
products.push({id:id++,name:'Bath Towel',cat:'Beauty',price:1583,emoji:'🧴'});
products.push({id:id++,name:'Travel Toiletry Bag',cat:'Beauty',price:1756,emoji:'🧴'});
products.push({id:id++,name:'Notebook Set',cat:'Stationery',price:149,emoji:'📚'});
products.push({id:id++,name:'Ball Pen Pack',cat:'Stationery',price:322,emoji:'📚'});
products.push({id:id++,name:'School Backpack',cat:'Stationery',price:495,emoji:'📚'});
products.push({id:id++,name:'Sketch Book',cat:'Stationery',price:668,emoji:'📚'});
products.push({id:id++,name:'Color Pencil Set',cat:'Stationery',price:841,emoji:'📚'});
products.push({id:id++,name:'Desk Organizer',cat:'Stationery',price:1014,emoji:'📚'});
products.push({id:id++,name:'Sticky Notes Pack',cat:'Stationery',price:1187,emoji:'📚'});
products.push({id:id++,name:'Study Table Lamp',cat:'Stationery',price:1360,emoji:'📚'});
products.push({id:id++,name:'Calculator',cat:'Stationery',price:1533,emoji:'📚'});
products.push({id:id++,name:'Diary 2026',cat:'Stationery',price:1706,emoji:'📚'});
let cart=JSON.parse(localStorage.getItem("shopx-cart")||"[]");
let wishlist=JSON.parse(localStorage.getItem("shopx-wishlist")||"[]");
let category="All";

function money(n){return "₹"+n.toLocaleString("en-IN")}

function renderProducts(){
  const q=(document.getElementById("searchInput").value||"").trim().toLowerCase();
  let list=products.filter(p=>{
    const categoryOK=category==="All"||p.cat===category;
    const text=(p.name+" "+p.cat).toLowerCase();
    return categoryOK && text.includes(q);
  });
  const sort=document.getElementById("sortSelect").value;
  if(sort==="low")list.sort((a,b)=>a.price-b.price);
  if(sort==="high")list.sort((a,b)=>b.price-a.price);

  document.getElementById("products").innerHTML=list.length?list.map(p=>`
  <article class="product">
   <button class="wish" onclick="toggleWish(${p.id})">${wishlist.includes(p.id)?"♥":"♡"}</button>
   <div class="pic" onclick="productDetails(${p.id})">${p.emoji}</div>
   <div class="cat">${p.cat}</div><h3>${p.name}</h3>
   <div class="bottom"><span class="price">${money(p.price)}</span><button class="add" onclick="addCart(${p.id})">Add</button></div>
  </article>`).join(""):`<div class="empty" style="grid-column:1/-1">No products found.</div>`;
  updateCount();
}

function filterCategory(c,btn){category=c;document.querySelectorAll(".nav button").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts()}
function addCart(id){cart.push(id);localStorage.setItem("shopx-cart",JSON.stringify(cart));updateCount();openCart()}
function updateCount(){document.getElementById("cartCount").textContent=cart.length}
function toggleWish(id){wishlist=wishlist.includes(id)?wishlist.filter(x=>x!==id):[...wishlist,id];localStorage.setItem("shopx-wishlist",JSON.stringify(wishlist));renderProducts()}
function showWishlist(){const items=products.filter(p=>wishlist.includes(p.id));openModal(`<h2>♡ Wishlist</h2>${items.length?items.map(p=>`<div class="cart-item"><span>${p.emoji} ${p.name}</span><b>${money(p.price)}</b></div>`).join(""):"<div class='empty'>Your wishlist is empty.</div>"}`)}
function openCart(){
  const counts={};cart.forEach(id=>counts[id]=(counts[id]||0)+1);
  const ids=Object.keys(counts).map(Number);let total=0;
  const body=ids.length?ids.map(id=>{const p=products.find(x=>x.id===id),qty=counts[id];total+=p.price*qty;return `<div class="cart-item"><span>${p.emoji} ${p.name} × ${qty}</span><b>${money(p.price*qty)}</b></div>`}).join(""):"<div class='empty'>Your cart is empty.</div>";
  openModal(`<h2>🛒 Your Cart</h2>${body}${ids.length?`<h3 style="margin-top:20px">Total: ${money(total)}</h3><button class="checkout" onclick="checkout()">Proceed to Checkout</button>`:""}`)
}
function productDetails(id){const p=products.find(x=>x.id===id);openModal(`<div style="text-align:center;font-size:90px">${p.emoji}</div><p class="eyebrow">${p.cat}</p><h2>${p.name}</h2><p style="margin:12px 0;color:#666">A quality ShopX pick, ready to add to your cart.</p><h2>${money(p.price)}</h2><button class="checkout" onclick="closeModal();addCart(${p.id})">Add to Cart</button>`)}
function checkout(){openModal(`<h2>Checkout</h2><p style="margin:15px 0;color:#666">Demo checkout — connect your payment gateway and backend to accept real orders.</p><input placeholder="Full name" style="width:100%;padding:12px;margin:6px 0;border:1px solid #ddd;border-radius:8px"><input placeholder="Delivery address" style="width:100%;padding:12px;margin:6px 0;border:1px solid #ddd;border-radius:8px"><button class="checkout" onclick="alert('Demo order placed!');cart=[];localStorage.setItem('shopx-cart','[]');closeModal();updateCount()">Place Demo Order</button>`)}
function openModal(content){document.getElementById("modalContent").innerHTML=content;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
renderProducts();
