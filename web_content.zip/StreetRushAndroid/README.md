# Street Rush Android Project

This is a ready-to-build Android Studio project wrapping the included Street Rush HTML game in a native Android WebView.

## Build APK
1. Install Android Studio.
2. Open this `StreetRushAndroid` folder.
3. Let Gradle sync and install any requested Android SDK components.
4. Choose **Build > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

For a shareable release APK, use **Build > Generate Signed Bundle / APK** and create/select a signing key.

The game itself is in `app/src/main/assets/index.html`.
