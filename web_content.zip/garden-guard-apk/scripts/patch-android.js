// Run after "npx cap add android": landscape lock, immersive fullscreen, notch support.
const fs = require('fs'), path = require('path');
const root = 'android/app/src/main';
function find(d, n) {
  for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, f.name);
    if (f.isDirectory()) { const r = find(p, n); if (r) return r; }
    else if (f.name === n) return p;
  }
}
const ma = find(root + '/java', 'MainActivity.java');
const pkg = /package\s+([\w.]+);/.exec(fs.readFileSync(ma, 'utf8'))[1];
fs.writeFileSync(ma, `package ${pkg};

import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    hideBars();
    WebSettings ws = getBridge().getWebView().getSettings();
    ws.setSupportZoom(false);
    ws.setBuiltInZoomControls(false);
    ws.setDisplayZoomControls(false);
    getBridge().getWebView().addJavascriptInterface(new ExitBridge(), "AndroidExit");
  }
  private class ExitBridge {
    @JavascriptInterface
    public void exit() {
      runOnUiThread(() -> finishAndRemoveTask());
    }
  }
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) hideBars();
  }
  private void hideBars() {
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    c.hide(WindowInsetsCompat.Type.systemBars());
    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
  }
}
`);
const st = root + '/res/values/styles.xml';
let s = fs.readFileSync(st, 'utf8');
if (!s.includes('windowLayoutInDisplayCutoutMode'))
  s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
fs.writeFileSync(st, s);
const mf = root + '/AndroidManifest.xml';
let m = fs.readFileSync(mf, 'utf8');
if (!m.includes('screenOrientation')) m = m.replace('<activity', '<activity android:screenOrientation="sensorLandscape"');
fs.writeFileSync(mf, m);
console.log('Android project patched: landscape, immersive, notch');
