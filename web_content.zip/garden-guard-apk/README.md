# Garden Guard: Android APK

The app runs fullscreen in landscape, with the story and menu music (www/audio/wacky.mp3) and the in-game music (www/audio/zen.mp3) bundled for offline play.

## Option A: build in the cloud (no installs)
1. Create a GitHub repository and upload everything in this folder (keep the .github folder).
2. Open the Actions tab and run "Build Android APK" (about 5 minutes; it also runs on every push to main).
3. Download the artifact "garden-guard-apk" and unzip it to get app-debug.apk.
4. Copy the APK to your phone, tap it, and allow installs from unknown apps.

## Option B: build on your computer
Needs Node 20+, JDK 17 and the Android SDK (Android Studio).
    npm install
    npx cap add android
    node scripts/patch-android.js
    npx cap sync android
    cd android && ./gradlew assembleDebug
APK: android/app/build/outputs/apk/debug/app-debug.apk

## Updating the game
Replace www/index.html (and www/audio if the music changes), then push to GitHub or rebuild.

## Before Google Play
- Change appId in capacitor.config.json (now com.example.gardenguard).
- Debug APKs are for testing. Play needs a signed release bundle: ./gradlew bundleRelease with your own keystore.
- Add an icon: npm i -D @capacitor/assets, put icon.png (1024x1024) in an assets folder, run npx capacitor-assets generate --android
