# Superhero City: Rise of Legends — Starter Prototype

A small browser-playable 3D prototype built with Three.js. It is designed as a low-poly starting point, not a finished AAA game.

## Play it
1. Extract the ZIP.
2. Open `index.html` in a modern browser with internet access. The Three.js module is loaded from jsDelivr CDN.
3. If the browser blocks modules when opening a local file, run a local web server from this folder:
   - Python installed: `python -m http.server 8000`
   - Then open `http://localhost:8000`
4. On Android, the easiest test is to host the folder on a local web server or upload it to a static web host, then open the page in Chrome. Touch buttons are included.

## Controls
- PC: WASD / arrow keys move, drag mouse to look, Space jump / toggle armor flight, F attack, E web pull (Threadrunner), H switch hero, U upgrades.
- Mobile: directional pad, Jump/Fly, Attack, Web Pull, Mission. Drag the screen to look around.
- Defeat red bots to earn credits; open Upgrades to improve health, energy, and attack power.

## What is included
- A small low-poly city with roads, buildings, windows, and a landmark tower.
- Original heroes: Aegis (armored flight) and Threadrunner (web pull / leap).
- Rogue bots, combat, HP/energy, one mission objective, and upgrades.
- Keyboard and touch controls.

## Important limitations / next steps
- This is a prototype with primitive geometry and placeholder mechanics. It does not include licensed Iron Man or Spider-Man characters/assets.
- Android/PC support here means it runs in a browser on both; it is not yet a native APK or Windows executable.
- For a larger project, move to Godot or Unity, add proper character models/animations, collision/pathfinding, sound, save data, more missions, and Android/Windows export.
- Three.js must be reachable from the internet unless you bundle the library locally.
