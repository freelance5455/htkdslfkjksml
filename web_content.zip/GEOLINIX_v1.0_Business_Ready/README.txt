GEOLINIX v1.0 — BUSINESS-READY LOBBY
===================================

WHAT THIS IS
A mobile-first front-end prototype for the next GEOLINIX lobby and initial business-revenue experience.

INCLUDED
- Redesigned premium navy/electric-blue home lobby
- GEO AI, GEO MAPS, CONNECT and DISCOVER entry points
- Business Hub profile draft form (local device only)
- Proposed subscription plans (interest buttons only; no charges)
- Revenue overview clearly separating actual preview revenue from targets
- GEO MARKET listing draft form (local device only)
- Workspace and profile preview screens
- Responsive layout for Android phones

IMPORTANT LIMITATIONS
This is NOT a production app and NOT an APK.
No live AI model, map provider, messaging service, cloud accounts, payment gateway, subscription billing, marketplace checkout or payout system is connected.
Business and product drafts are stored only in the browser's local storage.
Plan prices are hypotheses to validate with real businesses, not active offers.
K10,000/week is an ambition, not a guarantee.

HOW TO PREVIEW ON ANDROID
1. Download the ZIP.
2. Open your Files app and go to Downloads.
3. Extract the ZIP.
4. Open the extracted GEOLINIX_v1.0_Business_Ready folder.
5. Open index.html in Chrome or another browser.

NEXT PRODUCTION STEPS
1. Secure authentication and cloud database.
2. Real GEO AI backend (API key stored server-side, never in the app).
3. Business directory and discovery backend.
4. Approved payment provider integration and adult-managed legal/payment accounts.
5. Moderation, privacy, security, analytics and operational testing.
6. Android packaging and device testing.
