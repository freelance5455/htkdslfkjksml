package com.alex.tizeninstaller;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.OpenableColumns;import android.database.Cursor;import android.view.*;import android.webkit.*;import android.widget.*;import java.io.*;

public class MainActivity extends Activity {
 EditText ip,port; TextView status; Uri selected;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(makeUi());}
 View makeUi(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,32,32,32);
  WebView web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.loadUrl("file:///android_asset/index.html");root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
  ip=new EditText(this);ip.setHint("Watch IP address");root.addView(ip);port=new EditText(this);port.setText("26101");port.setInputType(2);root.addView(port);
  Button pick=new Button(this);pick.setText("Choose .tpk / .wgt / .rpm");root.addView(pick);pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,7);});
  Button install=new Button(this);install.setText("Connect + Install");root.addView(install);status=new TextView(this);status.setText("Ready");root.addView(status);
  install.setOnClickListener(v->{if(selected==null){status.setText("Choose a package first");return;}new Thread(()->doInstall()).start();});return root;}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==7&&c==RESULT_OK&&d!=null){selected=d.getData();status.setText("Package selected");}}
 void doInstall(){runOnUiThread(()->status.setText("Connecting..."));File f=null;try{f=copyToCache(selected);SdbClient s=new SdbClient(ip.getText().toString().trim(),Integer.parseInt(port.getText().toString().trim()),10000);s.connect();runOnUiThread(()->status.setText("Connected. Installing..."));s.install(f);s.close();runOnUiThread(()->status.setText("Install command sent successfully."));}catch(Exception e){String m=e.getMessage()==null?e.toString():e.getMessage();runOnUiThread(()->status.setText("Failed: "+m));}finally{if(f!=null)f.delete();}}
 File copyToCache(Uri u)throws Exception{String name="package.tpk";Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null){if(c.moveToFirst())name=c.getString(0);c.close();}File f=new File(getCacheDir(),name);try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(f)){byte[]b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return f;}
}
