# Tizen Native SDB Installer

A dependency-free Android Java prototype with a native SDB client and an HTML asset for the UI.

## Important
Samsung documents Galaxy Watch SDB over Wi-Fi on port 26101 with debugging enabled. The Android TizenAppInstaller project also demonstrates implementing SDB directly on Android. This project follows that general approach without third-party libraries.

The project is experimental. It has not been tested against a physical watch in this environment. Package signing, watch firmware differences, and SDB authentication can prevent installation.

Build as a normal Android Gradle project. It is **not** an HTML-to-APK project; `index.html` is only an embedded asset while the native Java layer performs networking and installation.

Use only legitimate Tizen packages you are authorized to install.
