COLEYNS NEXUS AI — Interface Prototype v0.1

This ZIP contains a mobile-first front-end prototype with Chat, Memory,
Notes & Tasks, and Tools screens.

IMPORTANT:
- This is a user-interface prototype, NOT a connected AI assistant.
- It is NOT an APK yet.
- Chat replies are demo text; no AI service or API key is included.
- Notes are temporary demo data and are not saved after closing the page.
- No account credentials or secrets are included.

Preview:
Open index.html in a modern browser.

Packaging:
Upload this ZIP to a compatible HTML-to-APK builder that accepts ZIP projects.
Builder capabilities, pricing, signing, and Android compatibility vary; verify
those details before uploading. A WebView wrapper cannot provide unrestricted
phone-call handling or deep hardware control. Those require native Android
roles, permissions, and device/version support.

Next development stages:
1. Test the interface on the target Android phone.
2. Add a secure backend for the AI connection (never put private API keys in
   the public app files).
3. Add persistent, user-controlled memory and notes.
4. Add web search and voice.
5. Add only supported, permission-based Android integrations.
