/* =====================================================
   QUÉ BOLÁ SHOP 🛒
   FEED.JS
   SESIÓN + PERMISOS + BANNER
   ===================================================== */


/* =====================================================
   CONFIGURACIÓN DE AUTENTICACIÓN
   ===================================================== */

const AUTH_API =
    "https://que-bola-shop-auth.fonito93punk.workers.dev";


/* =====================================================
   CONFIGURACIÓN DEL BANNER
   ===================================================== */

const BANNERS = [

    "baner/baner1.jpg"

];


const BANNER_DURACION =
    15000;


const BANNER_TRANSICION =
    800;


/* =====================================================
   ESTADO DEL BANNER
   ===================================================== */

let bannerActual = 0;

let bannerIntervalo = null;


/* =====================================================
   INICIO
   ===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        comprobarAcceso();

    }
);


/* =====================================================
   COMPROBAR ACCESO
   ===================================================== */

async function comprobarAcceso() {

    const token =
        localStorage.getItem(
            "que_bola_shop_token"
        );


    /*
       Si no existe token,
       no puede entrar al Feed.
    */

    if (!token) {

        window.location.href =
            "index.html";

        return;

    }


    /*
       Validamos el token
       directamente con el servidor.
    */

    try {

        const respuesta =
            await fetch(
                `${AUTH_API}/sesion`,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }

                }
            );


        let datos;


        try {

            datos =
                await respuesta.json();

        } catch {

            datos = null;

        }


        /*
           Sesión inválida.
        */

        if (
            !respuesta.ok ||
            !datos ||
            !datos.ok
        ) {

            limpiarSesion();

            window.location.href =
                "index.html";

            return;

        }


        /*
           Actualizar información
           del usuario si el servidor
           devuelve datos nuevos.
        */

        if (
            datos.usuario
        ) {

            localStorage.setItem(
                "que_bola_shop_usuario",
                JSON.stringify(
                    datos.usuario
                )
            );

        }


        if (
            datos.sesion &&
            datos.sesion.fecha_expiracion
        ) {

            localStorage.setItem(
                "que_bola_shop_expiracion",
                datos.sesion.fecha_expiracion
            );

        }


        /*
           Sesión correcta.
           Continuamos cargando el Feed.
        */

        await cargarPermisos();

        iniciarFeed();

    } catch (error) {

        console.error(
            "Error comprobando la sesión:",
            error
        );


        /*
           Si no podemos validar la sesión,
           por seguridad no mostramos el Feed.
        */

        limpiarSesion();

        window.location.href =
            "index.html";

    }

}


/* =====================================================
   INICIAR FEED
   ===================================================== */

function iniciarFeed() {

    iniciarMenuMovil();

}


/* =====================================================
   MENÚ MÓVIL
   ===================================================== */

function iniciarMenuMovil() {

    const menuButton =
        document.getElementById(
            "menuButton"
        );


    const mobileMenu =
        document.getElementById(
            "mobileMenu"
        );


    if (
        !menuButton ||
        !mobileMenu
    ) {

        return;

    }


    menuButton.addEventListener(
        "click",
        () => {

            const activo =
                mobileMenu.classList.toggle(
                    "active"
                );


            menuButton.setAttribute(
                "aria-expanded",
                activo
                    ? "true"
                    : "false"
            );


            menuButton.textContent =
                activo
                    ? "✕"
                    : "☰";

        }
    );


    const mobileLinks =
        mobileMenu.querySelectorAll(
            "a"
        );


    mobileLinks.forEach(
        link => {

            link.addEventListener(
                "click",
                () => {

                    mobileMenu.classList.remove(
                        "active"
                    );


                    menuButton.setAttribute(
                        "aria-expanded",
                        "false"
                    );


                    menuButton.textContent =
                        "☰";

                }
            );

        }
    );

}


/* =====================================================
   CARGAR PERMISOS
   ===================================================== */

async function cargarPermisos() {

    const token =
        obtenerToken();


    if (!token) {

        ocultarElementosProtegidos();

        return null;

    }


    try {

        const respuesta =
            await fetch(
                `${AUTH_API}/permisos`,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }

                }
            );


        let datos;


        try {

            datos =
                await respuesta.json();

        } catch {

            datos = null;

        }


        if (
            !respuesta.ok ||
            !datos ||
            !datos.ok
        ) {

            console.warn(
                "No se pudieron cargar los permisos."
            );


            ocultarElementosProtegidos();

            return null;

        }


        const permisos =
            datos.permisos || {};


        localStorage.setItem(
            "que_bola_shop_permisos",
            JSON.stringify(
                permisos
            )
        );


        actualizarInterfazPermisos(
            permisos
        );


        return permisos;


    } catch (error) {

        console.error(
            "Error cargando permisos:",
            error
        );


        /*
           Intentamos utilizar los permisos
           guardados anteriormente.
        */

        const permisosGuardados =
            obtenerPermisos();


        if (permisosGuardados) {

            actualizarInterfazPermisos(
                permisosGuardados
            );


            return permisosGuardados;

        }


        ocultarElementosProtegidos();

        return null;

    }

}


/* =====================================================
   ACTUALIZAR INTERFAZ SEGÚN PERMISOS
   ===================================================== */

function actualizarInterfazPermisos(
    permisos
) {

    /*
       TIENDA OFICIAL
    */

    actualizarElementoPorPermiso(
        permisos,
        "ver_tienda"
    );

}


/* =====================================================
   ELEMENTOS POR PERMISO
   ===================================================== */

function actualizarElementoPorPermiso(
    permisos,
    permiso
) {

    const permitido =
        permisos &&
        permisos[permiso] === true;


    /*
       Elementos que contienen
       data-permiso.
    */

    document
        .querySelectorAll(
            `[data-permiso="${permiso}"]`
        )
        .forEach(
            elemento => {

                elemento.hidden =
                    !permitido;

            }
        );

}


/* =====================================================
   OCULTAR ELEMENTOS PROTEGIDOS
   ===================================================== */

function ocultarElementosProtegidos() {

    document
        .querySelectorAll(
            "[data-permiso]"
        )
        .forEach(
            elemento => {

                elemento.hidden =
                    true;

            }
        );

}


/* =====================================================
   CREAR BANNERS
   ===================================================== */

function crearBanners() {

    const bannerContainer =
        document.getElementById(
            "bannerContainer"
        );


    if (
        !bannerContainer
    ) {

        return;

    }


    /*
       Limpiar el contenedor
       antes de crear los banners.
    */

    bannerContainer.innerHTML = "";


    /*
       Si no hay banners,
       no hacemos nada.
    */

    if (
        BANNERS.length === 0
    ) {

        return;

    }


    /*
       Crear las imágenes.
    */

    BANNERS.forEach(
        (ruta, indice) => {

            const imagen =
                document.createElement(
                    "img"
                );


            imagen.src =
                ruta;


            imagen.alt =
                "Promoción de Qué Bolá SHOP🛒";


            imagen.className =
                "banner-image";


            /*
               El primer banner
               aparece inicialmente.
            */

            if (
                indice === 0
            ) {

                imagen.classList.add(
                    "active"
                );

            }


            /*
               Si una imagen no existe,
               la ocultamos sin romper
               el resto del Feed.
            */

            imagen.addEventListener(
                "error",
                () => {

                    console.warn(
                        "No se pudo cargar el banner:",
                        ruta
                    );

                    imagen.remove();

                }
            );


            bannerContainer.appendChild(
                imagen
            );

        }
    );


    /*
       Crear indicadores
       solamente si hay más
       de un banner.
    */

    crearIndicadores();


    /*
       Comenzar reproducción
       automática.
    */

    iniciarIntervalo();

}


/* =====================================================
   CREAR INDICADORES
   ===================================================== */

function crearIndicadores() {

    const bannerContainer =
        document.getElementById(
            "bannerContainer"
        );


    if (
        !bannerContainer ||
        BANNERS.length <= 1
    ) {

        return;

    }


    const indicadores =
        document.createElement(
            "div"
        );


    indicadores.className =
        "banner-indicators";


    BANNERS.forEach(
        (_, indice) => {

            const boton =
                document.createElement(
                    "button"
                );


            boton.type =
                "button";


            boton.className =
                "banner-indicator";


            if (
                indice === 0
            ) {

                boton.classList.add(
                    "active"
                );

            }


            boton.setAttribute(
                "aria-label",
                `Mostrar banner ${indice + 1}`
            );


            boton.addEventListener(
                "click",
                () => {

                    mostrarBanner(
                        indice
                    );


                    reiniciarIntervalo();

                }
            );


            indicadores.appendChild(
                boton
            );

        }
    );


    bannerContainer.appendChild(
        indicadores
    );

}


/* =====================================================
   MOSTRAR BANNER
   ===================================================== */

function mostrarBanner(
    nuevoIndice
) {

    const bannerContainer =
        document.getElementById(
            "bannerContainer"
        );


    if (
        !bannerContainer
    ) {

        return;

    }


    const imagenes =
        bannerContainer.querySelectorAll(
            ".banner-image"
        );


    const indicadores =
        bannerContainer.querySelectorAll(
            ".banner-indicator"
        );


    if (
        !imagenes.length
    ) {

        return;

    }


    /*
       Evitar índices inválidos.
    */

    if (
        nuevoIndice < 0 ||
        nuevoIndice >= BANNERS.length
    ) {

        return;

    }


    /*
       Quitar el banner actual.
    */

    if (
        imagenes[bannerActual]
    ) {

        imagenes[
            bannerActual
        ].classList.remove(
            "active"
        );

    }


    /*
       Activar nuevo banner.
    */

    if (
        imagenes[nuevoIndice]
    ) {

        imagenes[
            nuevoIndice
        ].classList.add(
            "active"
        );

    }


    /*
       Actualizar indicadores.
    */

    indicadores.forEach(
        (indicador, indice) => {

            indicador.classList.toggle(
                "active",
                indice === nuevoIndice
            );

        }
    );


    bannerActual =
        nuevoIndice;

}


/* =====================================================
   INICIAR INTERVALO
   ===================================================== */

function iniciarIntervalo() {

    detenerIntervalo();


    if (
        BANNERS.length <= 1
    ) {

        return;

    }


    bannerIntervalo =
        setInterval(
            () => {

                const siguiente =
                    (
                        bannerActual + 1
                    ) %
                    BANNERS.length;


                mostrarBanner(
                    siguiente
                );

            },
            BANNER_DURACION
        );

}


/* =====================================================
   REINICIAR INTERVALO
   ===================================================== */

function reiniciarIntervalo() {

    detenerIntervalo();

    iniciarIntervalo();

}


/* =====================================================
   DETENER INTERVALO
   ===================================================== */

function detenerIntervalo() {

    if (
        bannerIntervalo
    ) {

        clearInterval(
            bannerIntervalo
        );


        bannerIntervalo =
            null;

    }

}


/* =====================================================
   OBTENER TOKEN
   ===================================================== */

function obtenerToken() {

    return localStorage.getItem(
        "que_bola_shop_token"
    );

}


/* =====================================================
   OBTENER PERMISOS
   ===================================================== */

function obtenerPermisos() {

    const permisos =
        localStorage.getItem(
            "que_bola_shop_permisos"
        );


    if (!permisos) {

        return null;

    }


    try {

        return JSON.parse(
            permisos
        );

    } catch {

        return null;

    }

}


/* =====================================================
   LIMPIAR SESIÓN
   ===================================================== */

function limpiarSesion() {

    localStorage.removeItem(
        "que_bola_shop_token"
    );


    localStorage.removeItem(
        "que_bola_shop_usuario"
    );


    localStorage.removeItem(
        "que_bola_shop_expiracion"
    );


    localStorage.removeItem(
        "que_bola_shop_permisos"
    );

}