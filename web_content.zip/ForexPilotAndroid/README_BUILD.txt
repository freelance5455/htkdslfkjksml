FOREX PILOT ANDROID DEMO — BUILD FROM YOUR PHONE

This is a demo dashboard only. It does not connect to MT5 and does not place live trades.

To build an APK using GitHub Actions from an Android phone:
1. Extract this ZIP on your phone.
2. On github.com, create a NEW PUBLIC or PRIVATE repository named ForexPilotAndroid. Keep it empty (do not add README/license/gitignore).
3. Open the extracted ForexPilotAndroid folder in your phone's file manager.
4. Upload the CONTENTS of that folder to the repository root, including the hidden .github folder. The root should contain settings.gradle, build.gradle, app/, and .github/.
5. In GitHub, open the repository's Actions tab. If prompted, enable Actions.
6. Choose “Build Forex Pilot demo APK” on the left, tap “Run workflow”, then tap the green “Run workflow” button.
7. Wait for the run to finish successfully. Open the completed run and download the artifact named ForexPilot-debug-apk.
8. Extract the downloaded artifact ZIP and tap app-debug.apk to install. If Android blocks it, allow your browser/files app to install unknown apps only if you trust the file you downloaded from your own GitHub Actions run.

If the phone's file manager cannot show or upload the hidden .github folder, tell me; we'll use an alternate route.
