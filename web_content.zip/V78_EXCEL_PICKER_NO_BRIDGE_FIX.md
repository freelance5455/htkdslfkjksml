# V78 Excel Picker No-Bridge Fix

Built from V77. The Android Excel Choose File action no longer depends on `AndroidDPM.pickImportFile()` or the WebView `onShowFileChooser()` callback. The button navigates to `dpm-import://pick`; MainActivity intercepts that URL and launches the native Android file picker directly. Existing native parsing/import and Supabase paths are unchanged.
