-- EST Studio application schema.

create table if not exists profiles (
  user_id text primary key,
  full_name text not null,
  username text not null unique,
  bio text not null default '',
  avatar text,
  role text not null default 'developer',
  created_at timestamptz not null default now(),
  constraint profiles_role_chk check (role in ('owner', 'admin', 'developer', 'viewer'))
);

create table if not exists invitations (
  id text primary key,
  token text not null unique,
  role text not null,
  created_by text not null,
  accepted_by text,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  constraint invitations_role_chk check (role in ('admin', 'developer', 'viewer'))
);

create table if not exists projects (
  id text primary key,
  name text not null,
  slug text not null unique,
  description text not null default '',
  template text not null,
  current_branch text not null default 'main',
  created_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists project_members (
  project_id text not null,
  user_id text not null,
  role text not null,
  primary key (project_id, user_id),
  constraint project_members_role_chk check (role in ('owner', 'admin', 'developer', 'viewer'))
);

create index if not exists project_members_user_idx on project_members (user_id);

create table if not exists files (
  id text primary key,
  project_id text not null,
  path text not null,
  kind text not null,
  content text not null default '',
  language text not null default '',
  assignee_id text,
  locked_by text,
  locked_at timestamptz,
  updated_by text,
  updated_at timestamptz not null default now(),
  unique (project_id, path),
  constraint files_kind_chk check (kind in ('file', 'dir'))
);

create index if not exists files_project_idx on files (project_id);

create table if not exists presence (
  project_id text not null,
  user_id text not null,
  file_path text,
  line_no integer,
  updated_at timestamptz not null default now(),
  primary key (project_id, user_id)
);

create table if not exists branches (
  id text primary key,
  project_id text not null,
  name text not null,
  head_commit_id text,
  created_by text not null,
  created_at timestamptz not null default now(),
  unique (project_id, name)
);

create table if not exists commits (
  id text primary key,
  project_id text not null,
  branch_name text not null,
  parent_id text,
  parent2_id text,
  message text not null,
  author_id text not null,
  snapshot text not null,
  created_at timestamptz not null default now()
);

create index if not exists commits_project_idx on commits (project_id, created_at);

create table if not exists tasks (
  id text primary key,
  project_id text not null,
  title text not null,
  description text not null default '',
  status text not null default 'todo',
  file_path text,
  assignee_id text,
  created_by text not null,
  created_at timestamptz not null default now(),
  constraint tasks_status_chk check (status in ('todo', 'doing', 'review', 'done'))
);

create index if not exists tasks_project_idx on tasks (project_id);

create table if not exists channels (
  id text primary key,
  kind text not null,
  project_id text,
  name text,
  dm_key text unique,
  created_by text not null,
  created_at timestamptz not null default now(),
  constraint channels_kind_chk check (kind in ('project', 'team', 'dm'))
);

create table if not exists channel_members (
  channel_id text not null,
  user_id text not null,
  last_read_at timestamptz not null default now(),
  primary key (channel_id, user_id)
);

create index if not exists channel_members_user_idx on channel_members (user_id);

create table if not exists messages (
  id text primary key,
  channel_id text not null,
  user_id text not null,
  body text not null,
  parent_id text,
  snippet text,
  snippet_path text,
  created_at timestamptz not null default now()
);

create index if not exists messages_channel_idx on messages (channel_id, created_at);

create table if not exists reviews (
  id text primary key,
  project_id text not null,
  title text not null,
  branch_name text not null,
  status text not null default 'open',
  author_id text not null,
  created_at timestamptz not null default now(),
  constraint reviews_status_chk check (status in ('open', 'approved', 'changes'))
);

create table if not exists review_comments (
  id text primary key,
  review_id text not null,
  user_id text not null,
  file_path text,
  line_no integer,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists deployments (
  id text primary key,
  project_id text not null,
  status text not null,
  log text not null default '',
  snapshot text not null default '',
  created_by text not null,
  created_at timestamptz not null default now(),
  constraint deployments_status_chk check (status in ('building', 'live', 'failed'))
);

create index if not exists deployments_project_idx on deployments (project_id, created_at);

create table if not exists backups (
  id text primary key,
  project_id text not null,
  note text not null default '',
  snapshot text not null,
  created_by text not null,
  created_at timestamptz not null default now()
);

create index if not exists backups_project_idx on backups (project_id, created_at);

create table if not exists audit_log (
  id text primary key,
  user_id text,
  action text not null,
  target text,
  meta text,
  created_at timestamptz not null default now()
);

create index if not exists audit_created_idx on audit_log (created_at);

create table if not exists ai_messages (
  id text primary key,
  project_id text not null,
  user_id text not null,
  role text not null,
  content text not null,
  created_at timestamptz not null default now()
);

create index if not exists ai_messages_project_idx on ai_messages (project_id, user_id, created_at);

create table if not exists ai_usage (
  id text primary key,
  user_id text not null,
  created_at timestamptz not null default now()
);

create index if not exists ai_usage_user_idx on ai_usage (user_id, created_at);
