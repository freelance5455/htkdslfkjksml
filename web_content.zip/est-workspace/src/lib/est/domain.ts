export const ROLES = ["owner", "admin", "developer", "viewer"] as const;
export type Role = (typeof ROLES)[number];

export const TEMPLATE_IDS = ["blank", "react", "next", "laravel", "node"] as const;
export type TemplateId = (typeof TEMPLATE_IDS)[number];

export type TreeEntry = { path: string; kind: "file" | "dir"; content: string };
export type SnapFile = TreeEntry;

const RANK: Record<Role, number> = { viewer: 0, developer: 1, admin: 2, owner: 3 };

export function roleRank(role: Role): number {
  return RANK[role];
}

export function isRole(value: string): value is Role {
  return (ROLES as readonly string[]).includes(value);
}

export function isTemplate(value: string): value is TemplateId {
  return (TEMPLATE_IDS as readonly string[]).includes(value);
}

export function validPath(path: string): boolean {
  if (!path || path.length > 180) return false;
  if (path.startsWith("/") || path.endsWith("/")) return false;
  return path.split("/").every((part) => {
    if (!part || part === "." || part === "..") return false;
    if (part.includes("\\") || /[\u0000-\u001f]/.test(part)) return false;
    return true;
  });
}

export function languageFromPath(path: string): string {
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    js: "javascript",
    jsx: "javascript",
    mjs: "javascript",
    ts: "typescript",
    tsx: "typescript",
    css: "css",
    html: "html",
    json: "json",
    md: "markdown",
    php: "php",
    py: "python",
    vue: "html",
    sql: "sql",
  };
  return map[ext] ?? "plaintext";
}

export function parentDirs(path: string): string[] {
  const parts = path.split("/");
  const dirs: string[] = [];
  for (let i = 1; i < parts.length; i += 1) dirs.push(parts.slice(0, i).join("/"));
  return dirs;
}

export function withDirs(files: { path: string; content: string }[]): TreeEntry[] {
  const dirs = new Set<string>();
  for (const file of files) {
    for (const dir of parentDirs(file.path)) dirs.add(dir);
  }
  return [
    ...[...dirs].sort().map((path) => ({ path, kind: "dir" as const, content: "" })),
    ...files.map((file) => ({ path: file.path, kind: "file" as const, content: file.content })),
  ];
}

export function parseSnapshot(raw: string | null | undefined): SnapFile[] {
  if (!raw) return [];
  try {
    const value = JSON.parse(raw) as SnapFile[];
    if (!Array.isArray(value)) return [];
    return value.filter((file) => file && typeof file.path === "string" && (file.kind === "file" || file.kind === "dir"));
  } catch {
    return [];
  }
}

export function gitStatus(files: SnapFile[], head: SnapFile[]) {
  const base = new Map(head.map((file) => [file.path, file]));
  const work = new Map(files.map((file) => [file.path, file]));
  const modified: string[] = [];
  const added: string[] = [];
  const deleted: string[] = [];
  for (const [path, file] of work) {
    const previous = base.get(path);
    if (!previous) added.push(path);
    else if (previous.content !== file.content || previous.kind !== file.kind) modified.push(path);
  }
  for (const path of base.keys()) if (!work.has(path)) deleted.push(path);
  return {
    modified,
    added,
    deleted,
    clean: modified.length + added.length + deleted.length === 0,
  };
}

export function mergeTexts(base: string, ours: string, theirs: string, label: string) {
  if (ours === theirs || theirs === base) return { content: ours, conflict: false };
  if (ours === base) return { content: theirs, conflict: false };
  const oursLines = ours.split("\n");
  const theirLines = theirs.split("\n");
  const baseLines = base.split("\n");
  if (oursLines.length === theirLines.length && theirLines.length === baseLines.length && oursLines.length < 900) {
    const out: string[] = [];
    let conflict = false;
    for (let i = 0; i < oursLines.length; i += 1) {
      const o = oursLines[i] ?? "";
      const t = theirLines[i] ?? "";
      const b = baseLines[i] ?? "";
      if (o === t) out.push(o);
      else if (o === b) out.push(t);
      else if (t === b) out.push(o);
      else {
        conflict = true;
        out.push("<<<<<<< HEAD", o, "=======", t, `>>>>>>> ${label}`);
      }
    }
    return { content: out.join("\n"), conflict };
  }
  return {
    content: `<<<<<<< HEAD\n${ours}\n=======\n${theirs}\n>>>>>>> ${label}\n`,
    conflict: true,
  };
}

export function hasConflictMarkers(content: string): boolean {
  return content.includes("<<<<<<< HEAD");
}

export type Diagnostic = { line: number; message: string; severity: "warn" | "error" };

export function diagnose(path: string, content: string): Diagnostic[] {
  if (path.endsWith(".md")) return [];
  const issues: Diagnostic[] = [];
  content.split("\n").forEach((line, index) => {
    const n = index + 1;
    const trimmed = line.trim();
    if (line.length > 140) issues.push({ line: n, message: "line-too-long", severity: "warn" });
    if (/\b(TODO|FIXME)\b/.test(line)) issues.push({ line: n, message: "todo", severity: "warn" });
    if (trimmed === "debugger" || trimmed.startsWith("debugger;")) {
      issues.push({ line: n, message: "debugger", severity: "error" });
    }
    if (/(^|[^!=])==([^=]|$)/.test(line) && !trimmed.startsWith("//") && !trimmed.startsWith("*")) {
      issues.push({ line: n, message: "eqeqeq", severity: "warn" });
    }
    if (/\bconsole\.log\(/.test(line)) issues.push({ line: n, message: "console", severity: "warn" });
  });
  return issues.slice(0, 80);
}

export type TestResult = { name: string; ok: boolean; detail: string };

export function runProjectTests(files: { path: string; content: string }[]): TestResult[] {
  const tests = files.filter((file) => file.path.endsWith(".test.js"));
  if (!tests.length) return [];
  return tests.map((file) => {
    const logs: string[] = [];
    const fakeConsole = {
      log: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
      error: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
      warn: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
      info: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
    };
    const assert = {
      equal(actual: unknown, expected: unknown) {
        if (actual !== expected) throw new Error(`expected ${String(expected)} but got ${String(actual)}`);
      },
      ok(value: unknown, message?: string) {
        if (!value) throw new Error(message || "assertion failed");
      },
    };
    try {
      const fn = new Function("assert", "console", `"use strict";\n${file.content}`);
      fn(assert, fakeConsole);
      return { name: file.path, ok: true, detail: logs.join("\n") || "passed" };
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed";
      return { name: file.path, ok: false, detail: [message, ...logs].filter(Boolean).join("\n") };
    }
  });
}

function lookup(files: Map<string, string>, href: string): string | undefined {
  const clean = href.replace(/^\.\//, "").replace(/^\//, "");
  return files.get(clean) ?? files.get(href);
}

function injectBridge(html: string): string {
  const bridge = `<script>
    (function(){
      function send(level, args){
        try { parent.postMessage({ source: "est-preview", level: level, args: args.map(function(v){ return typeof v === "string" ? v : JSON.stringify(v); }) }, "*"); } catch (e) {}
      }
      ["log","info","warn","error"].forEach(function(level){
        var original = console[level];
        console[level] = function(){ send(level, Array.prototype.slice.call(arguments)); if (original) original.apply(console, arguments); };
      });
      window.addEventListener("error", function(event){ send("error", [String(event.message || "error")]); });
    })();
  </script>`;
  if (html.includes("<head>")) return html.replace("<head>", `<head>${bridge}`);
  return bridge + html;
}

function inlineAssets(html: string, files: Map<string, string>): string {
  let next = html.replace(/<link\b[^>]*href=["']([^"']+)["'][^>]*>/gi, (full, href: string) => {
    if (!String(href).endsWith(".css")) return full;
    const css = lookup(files, href);
    return css == null ? full : `<style>${css}</style>`;
  });
  next = next.replace(/<script\b([^>]*?)\bsrc=["']([^"']+)["']([^>]*)><\/script>/gi, (full, before: string, src: string, after: string) => {
    const code = lookup(files, src);
    if (code == null) return full;
    return `<script${before}${after}>\n${code}\n</script>`;
  });
  return injectBridge(next);
}

function reactShell(source: string, css: string): string {
  return injectBridge(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>${css}</style>
</head>
<body>
<div id="root"></div>
<script src="https://unpkg.com/react@18.3.1/umd/react.production.min.js"></script>
<script src="https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js"></script>
<script src="https://unpkg.com/@babel/standalone@7.29.0/babel.min.js"></script>
<script type="text/babel">
${source}
if (typeof App !== "undefined") {
  ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
}
</script>
</body>
</html>`);
}

function apiShell(source: string): string {
  const found: { method: string; path: string; body: string }[] = [];
  const re = /["'](GET|POST|PUT|DELETE)\s+([^"']+)["']\s*:\s*(\{[\s\S]*?\})/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(source))) {
    found.push({ method: match[1] ?? "GET", path: match[2] ?? "/", body: match[3] ?? "{}" });
  }
  const rows = found.length
    ? found
        .map(
          (route) =>
            `<tr><td>${route.method}</td><td>${route.path}</td><td><pre>${route.body.replace(/</g, "<")}</pre></td></tr>`,
        )
        .join("")
    : `<tr><td colspan="3">No routes found. Define a routes object.</td></tr>`;
  return injectBridge(`<!DOCTYPE html><html><head><meta charset="utf-8"/><style>
    body{margin:0;font-family:system-ui;background:#f5f7fa;color:#1a2733}
    main{max-width:760px;margin:0 auto;padding:32px 20px}
    h1{color:#2f6f96;font-weight:600}
    table{width:100%;border-collapse:collapse;background:#fff}
    td,th{border-bottom:1px solid #d5e0e8;text-align:start;padding:10px;font-size:14px;vertical-align:top}
    pre{margin:0;white-space:pre-wrap;font-family:ui-monospace,monospace}
  </style></head><body><main><h1>EST API</h1><p>Simulated routes from server.js</p><table><thead><tr><th>Method</th><th>Path</th><th>Body</th></tr></thead><tbody>${rows}</tbody></table></main></body></html>`);
}

export function buildPreviewDoc(files: { path: string; kind: string; content: string }[]): string | null {
  const map = new Map(files.filter((file) => file.kind === "file").map((file) => [file.path, file.content]));
  const index = map.get("index.html");
  if (index) return inlineAssets(index, map);
  const blade = [...map.entries()].find(([path]) => path.endsWith(".blade.php"));
  if (blade) return injectBridge(blade[1]);
  const page = map.get("src/App.jsx") ?? map.get("app/page.jsx");
  if (page) return reactShell(page, map.get("src/styles.css") ?? map.get("app/globals.css") ?? "");
  const server = map.get("server.js");
  if (server) return apiShell(server);
  return null;
}

const README = `# EST project

Edit files in EST Studio. The preview refreshes as you save.
Tests live in \`*.test.js\` and run from the terminal with \`npm test\`.
`;

const TEST = `assert.equal(1 + 1, 2);
assert.ok("EST".length === 3);
`;

const PKG = (name: string, extra: Record<string, string> = {}) =>
  JSON.stringify(
    {
      name,
      private: true,
      scripts: { test: "est test", lint: "est lint", format: "est format" },
      dependencies: extra,
    },
    null,
    2,
  );

const SITE_CSS = `*{box-sizing:border-box}
body{margin:0;font-family:"IBM Plex Sans Arabic","Segoe UI",sans-serif;background:#f5f7fa;color:#1a2733}
header{display:flex;justify-content:space-between;align-items:center;padding:20px 7vw}
header strong{color:#2f6f96;letter-spacing:.08em}
.hero{padding:24px 7vw 64px;max-width:760px}
.kicker{color:#2f6f96;font-weight:600;margin:0 0 8px}
h1{font-size:clamp(2rem,4vw,3.2rem);line-height:1.15;margin:0 0 12px;color:#2f6f96;font-weight:600}
p{line-height:1.6}
button{background:#2f6f96;color:#f4f9fc;border:0;border-radius:10px;padding:12px 18px;font:inherit;cursor:pointer}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;padding:0 7vw 64px}
article{background:#fff;border:1px solid #d5e0e8;border-radius:16px;padding:16px}
article h2{margin:0 0 6px;font-size:1rem;color:#2f6f96}
`;

const REACT_APP = `function App() {
  const [pulse, setPulse] = React.useState(0);
  return (
    <div>
      <header>
        <strong>EST</strong>
        <span>Web studio</span>
      </header>
      <section className="hero">
        <p className="kicker">Collaborative build</p>
        <h1>Quiet websites, built together.</h1>
        <p>Change this React file and the preview updates after you save.</p>
        <button onClick={() => setPulse(pulse + 1)}>Pulse {pulse}</button>
      </section>
      <section className="grid">
        <article><h2>Design</h2><p>Soft surfaces and a single blue accent.</p></article>
        <article><h2>Build</h2><p>Files, tasks, and review in one place.</p></article>
        <article><h2>Ship</h2><p>Run tests, then deploy a snapshot.</p></article>
      </section>
    </div>
  );
}
`;

const HTML_PAGE = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>EST</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <header><strong>EST</strong><span id="clock"></span></header>
  <section class="hero">
    <p class="kicker">قالب فارغ</p>
    <h1>ابدأ الصفحة من هنا.</h1>
    <p>حرّر HTML وCSS وJS. المعاينة تتحدث بعد الحفظ.</p>
    <button id="ping" type="button">جاهز</button>
  </section>
  <script src="app.js"></script>
</body>
</html>
`;

const HTML_JS = `const button = document.querySelector("#ping");
const clock = document.querySelector("#clock");
button?.addEventListener("click", () => {
  button.textContent = "تم";
  console.log("EST preview ready");
});
if (clock) clock.textContent = new Date().toLocaleTimeString();
`;

const NODE_SERVER = `const routes = {
  "GET /": { service: "EST", ok: true },
  "GET /health": { status: "ok" },
  "POST /contact": { received: true }
};

function route(method, path) {
  return routes[method + " " + path] || { error: "not_found" };
}

console.log("EST API listening");
console.log(JSON.stringify(route("GET", "/health")));
`;

const LARAVEL_BLADE = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>EST Laravel</title>
  <style>
    body{margin:0;font-family:sans-serif;background:#f5f7fa;color:#1a2733}
    main{max-width:720px;margin:0 auto;padding:48px 20px}
    h1{color:#2f6f96}
    code{font-family:ui-monospace,monospace}
  </style>
</head>
<body>
  <main>
    <p>EST · Laravel</p>
    <h1>مرحباً بك في القالب.</h1>
    <p>المسار <code>routes/web.php</code> يعرض هذا القالب. عدّل الملف وشاهد المعاينة.</p>
  </main>
</body>
</html>
`;

const LARAVEL_ROUTE = `<?php

use Illuminate\\Support\\Facades\\Route;

Route::get('/', function () {
    return view('welcome');
});
`;

export function templateTree(id: TemplateId): TreeEntry[] {
  if (id === "react" || id === "next") {
    const page = id === "next" ? "app/page.jsx" : "src/App.jsx";
    const css = id === "next" ? "app/globals.css" : "src/styles.css";
    return withDirs([
      { path: page, content: REACT_APP },
      { path: css, content: SITE_CSS },
      { path: "package.json", content: PKG(id === "next" ? "est-next" : "est-react", { react: "^18.3.1", "react-dom": "^18.3.1" }) },
      { path: "tests/smoke.test.js", content: TEST },
      { path: "README.md", content: README },
    ]);
  }
  if (id === "laravel") {
    return withDirs([
      { path: "resources/views/welcome.blade.php", content: LARAVEL_BLADE },
      { path: "routes/web.php", content: LARAVEL_ROUTE },
      { path: "composer.json", content: JSON.stringify({ name: "est/laravel", require: { php: "^8.3" } }, null, 2) },
      { path: "tests/smoke.test.js", content: TEST },
      { path: "README.md", content: README },
    ]);
  }
  if (id === "node") {
    return withDirs([
      { path: "server.js", content: NODE_SERVER },
      { path: "package.json", content: PKG("est-api") },
      { path: "tests/smoke.test.js", content: TEST },
      { path: "README.md", content: README },
    ]);
  }
  return withDirs([
    { path: "index.html", content: HTML_PAGE },
    { path: "styles.css", content: SITE_CSS },
    { path: "app.js", content: HTML_JS },
    { path: "package.json", content: PKG("est-blank") },
    { path: "tests/smoke.test.js", content: TEST },
    { path: "README.md", content: README },
  ]);
}

export type TermEffect =
  | { type: "test" }
  | { type: "lint" }
  | { type: "format" }
  | { type: "commit"; message: string }
  | { type: "checkout"; name: string; force?: boolean }
  | { type: "branch"; name: string }
  | { type: "merge"; name: string }
  | { type: "add-dep"; name: string };

export function execTerminal(
  line: string,
  ctx: { cwd: string; files: SnapFile[]; branch: string; statusText: string; logText: string },
): { output: string; clear?: boolean; cwd?: string; effect?: TermEffect } {
  const trimmed = line.trim();
  if (!trimmed) return { output: "" };
  const [cmd, ...rest] = trimmed.split(/\s+/);
  const arg = rest.join(" ");
  if (cmd === "help") {
    return {
      output:
        "ls  cd  pwd  cat  clear  git status  git log  git branch  git checkout  git commit -m  git merge  npm test  npm run lint  npm run format  npm install <pkg>",
    };
  }
  if (cmd === "clear") return { output: "", clear: true };
  if (cmd === "pwd") return { output: "/" + ctx.cwd };
  if (cmd === "ls") {
    const base = (arg || ctx.cwd).replace(/^\//, "").replace(/\/$/, "");
    const names = new Set<string>();
    for (const file of ctx.files) {
      if (base && !file.path.startsWith(base + "/") && file.path !== base) continue;
      const restPath = base ? file.path.slice(base.length + 1) : file.path;
      if (!restPath || restPath === file.path && base) {
        if (file.path === base) names.add(file.path.split("/").pop() || file.path);
        continue;
      }
      names.add(restPath.split("/")[0] || restPath);
    }
    return { output: [...names].sort().join("\n") || "(empty)" };
  }
  if (cmd === "cd") {
    if (!arg || arg === "/") return { output: "", cwd: "" };
    if (arg === "..") {
      const parts = ctx.cwd.split("/").filter(Boolean);
      parts.pop();
      return { output: "", cwd: parts.join("/") };
    }
    const next = ctx.cwd ? `${ctx.cwd}/${arg}`.replace(/^\//, "") : arg.replace(/^\//, "");
    const exists = ctx.files.some((file) => file.path === next || file.path.startsWith(next + "/"));
    if (!exists) return { output: `no such path: ${arg}` };
    return { output: "", cwd: next };
  }
  if (cmd === "cat") {
    const path = arg.startsWith("/") ? arg.slice(1) : ctx.cwd ? `${ctx.cwd}/${arg}` : arg;
    const file = ctx.files.find((item) => item.path === path && item.kind === "file");
    return { output: file ? file.content : `no such file: ${path}` };
  }
  if (cmd === "git" && rest[0] === "status") return { output: ctx.statusText || "clean" };
  if (cmd === "git" && rest[0] === "log") return { output: ctx.logText || "no commits" };
  if (cmd === "git" && rest[0] === "branch") {
    if (rest[1]) return { output: "", effect: { type: "branch", name: rest[1] } };
    return { output: `* ${ctx.branch}` };
  }
  if (cmd === "git" && rest[0] === "checkout") {
    const force = rest.includes("-f");
    const name = rest.find((part) => part !== "-f");
    if (!name) return { output: "usage: git checkout <branch>" };
    return { output: "", effect: { type: "checkout", name, force } };
  }
  if (cmd === "git" && rest[0] === "commit") {
    const message = trimmed.match(/-m\s+["']?(.+?)["']?$/)?.[1]?.trim();
    if (!message) return { output: "usage: git commit -m \"message\"" };
    return { output: "", effect: { type: "commit", message } };
  }
  if (cmd === "git" && rest[0] === "merge") {
    if (!rest[1]) return { output: "usage: git merge <branch>" };
    return { output: "", effect: { type: "merge", name: rest[1] } };
  }
  if (cmd === "npm" && rest[0] === "test") return { output: "", effect: { type: "test" } };
  if (cmd === "npm" && rest[0] === "run" && rest[1] === "lint") return { output: "", effect: { type: "lint" } };
  if (cmd === "npm" && rest[0] === "run" && rest[1] === "format") return { output: "", effect: { type: "format" } };
  if (cmd === "npm" && rest[0] === "install") {
    const name = rest[1];
    if (!name || name.startsWith("-")) return { output: "usage: npm install <package>" };
    return { output: "", effect: { type: "add-dep", name } };
  }
  return { output: `command not found: ${cmd}. type help` };
}

export function mentionQuery(value: string): string | null {
  const match = /(?:^|\s)@([a-z0-9_]{0,20})$/i.exec(value);
  return match ? match[1].toLowerCase() : null;
}

export function applyMention(value: string, username: string): string {
  return value.replace(/(^|\s)@[a-z0-9_]{0,20}$/i, (_full, lead: string) => `${lead}@${username} `);
}

export type TraceResult = { steps: number[]; logs: string[]; error: string; paused: number | null };

export function traceJavaScript(source: string, breakpoints: number[], maxSteps = 80): TraceResult {
  const lines = source.split("\n");
  const body = lines
    .map((line, index) => (canProbe(line, lines[index - 1] ?? "") ? `__estStep(${index + 1}); ${line}` : line))
    .join("\n");
  const steps: number[] = [];
  const logs: string[] = [];
  let paused: number | null = null;
  const stops = new Set(breakpoints);
  const step = (n: number) => {
    steps.push(n);
    if (steps.length > maxSteps) throw new Error("step limit");
    if (stops.has(n)) {
      paused = n;
      const halt = new Error("breakpoint");
      halt.name = "EstBreakpoint";
      throw halt;
    }
  };
  const fakeConsole = {
    log: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
    info: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
    warn: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
    error: (...args: unknown[]) => logs.push(args.map(String).join(" ")),
  };
  try {
    const fn = new Function("__estStep", "console", `"use strict";\n${body}`);
    fn(step, fakeConsole);
    return { steps, logs, error: "", paused };
  } catch (error) {
    if (error instanceof Error && error.name === "EstBreakpoint") return { steps, logs, error: "", paused };
    return { steps, logs, error: error instanceof Error ? error.message : "failed", paused };
  }
}

function canProbe(line: string, prev: string): boolean {
  const text = line.trim();
  const before = prev.trim();
  if (!text.endsWith(";") || text.startsWith("//") || text.startsWith("*") || text.startsWith("import ") || text.startsWith("export ")) {
    return false;
  }
  if (text.includes("`") || text.includes("${")) return false;
  if ((text.split('"').length - 1) % 2 || (text.split("'").length - 1) % 2) return false;
  if (/[,({=\\]$/.test(before)) return false;
  return true;
}
