export async function formatSource(path: string, content: string): Promise<string> {
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  let parser = "";
  if (ext === "css") parser = "css";
  else if (ext === "html" || ext === "svg") parser = "html";
  else if (ext === "md") parser = "markdown";
  else if (ext === "json") parser = "json";
  else if (ext === "ts" || ext === "tsx") parser = "babel-ts";
  else if (["js", "jsx", "mjs"].includes(ext)) parser = "babel";
  else return content;

  const prettier = await import("prettier/standalone");
  const [babel, estree, html, postcss, markdown] = await Promise.all([
    import("prettier/plugins/babel"),
    import("prettier/plugins/estree"),
    import("prettier/plugins/html"),
    import("prettier/plugins/postcss"),
    import("prettier/plugins/markdown"),
  ]);
  const plugins = [babel, estree, html, postcss, markdown].map((mod) => {
    const record = mod as { default?: unknown };
    return record.default ?? mod;
  });
  return prettier.format(content, { parser, plugins, printWidth: 90 });
}
