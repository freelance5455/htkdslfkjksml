import { create } from "zustand";

export type Lang = "ar" | "en";
export type ThemeName = "light" | "dark";

function apply(lang: Lang, theme: ThemeName) {
  if (typeof document === "undefined") return;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.documentElement.classList.toggle("dark", theme === "dark");
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#0e141b" : "#f5f7fa");
}

type Prefs = {
  lang: Lang;
  theme: ThemeName;
  setLang: (lang: Lang) => void;
  toggleTheme: () => void;
  hydrate: () => void;
};

export const usePrefs = create<Prefs>((set, get) => ({
  lang: "ar",
  theme: "light",
  hydrate: () => {
    const lang: Lang = localStorage.getItem("est-lang") === "en" ? "en" : "ar";
    const theme: ThemeName = localStorage.getItem("est-theme") === "dark" ? "dark" : "light";
    apply(lang, theme);
    set({ lang, theme });
  },
  setLang: (lang) => {
    localStorage.setItem("est-lang", lang);
    apply(lang, get().theme);
    set({ lang });
  },
  toggleTheme: () => {
    const theme: ThemeName = get().theme === "dark" ? "light" : "dark";
    localStorage.setItem("est-theme", theme);
    apply(get().lang, theme);
    set({ theme });
  },
}));
