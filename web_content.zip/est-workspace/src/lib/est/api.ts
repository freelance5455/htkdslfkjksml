import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import {
  gitStatus,
  isRole,
  isTemplate,
  languageFromPath,
  mergeTexts,
  parentDirs,
  parseSnapshot,
  roleRank,
  templateTree,
  validPath,
  type Role,
  type SnapFile,
  type TemplateId,
} from "@/lib/est/domain";

type Row = Record<string, unknown>;

function nid(): string {
  return crypto.randomUUID();
}

function num(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function text(value: unknown, max: number): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function obj(input: unknown): Record<string, unknown> {
  return input && typeof input === "object" ? (input as Record<string, unknown>) : {};
}

async function emailOf(sql: Sql, userId: string): Promise<string | null> {
  const rows = await sql<{ email: string }>`select email from "user" where id = ${userId} limit 1`;
  return rows[0]?.email ?? null;
}

type Profile = {
  userId: string;
  fullName: string;
  username: string;
  bio: string;
  avatar: string | null;
  role: Role;
};

function mapProfile(row: Row): Profile {
  return {
    userId: String(row.user_id),
    fullName: String(row.full_name),
    username: String(row.username),
    bio: String(row.bio ?? ""),
    avatar: row.avatar ? String(row.avatar) : null,
    role: String(row.role) as Role,
  };
}

async function profileOf(sql: Sql, userId: string): Promise<Profile | null> {
  const rows = await sql<Row>`select user_id, full_name, username, bio, avatar, role from profiles where user_id = ${userId}`;
  return rows[0] ? mapProfile(rows[0]) : null;
}

async function audit(sql: Sql, userId: string, action: string, target: string, meta = "") {
  await sql`insert into audit_log (id, user_id, action, target, meta) values (${nid()}, ${userId}, ${action}, ${target}, ${meta})`;
}

type FileRec = {
  id: string;
  path: string;
  kind: "file" | "dir";
  content: string;
  language: string;
  assigneeId: string | null;
  lockedBy: string | null;
  lockedAt: number | null;
  updatedBy: string | null;
  updatedAt: number;
};

function mapFile(row: Row): FileRec {
  return {
    id: String(row.id),
    path: String(row.path),
    kind: row.kind === "dir" ? "dir" : "file",
    content: String(row.content ?? ""),
    language: String(row.language ?? ""),
    assigneeId: row.assignee_id ? String(row.assignee_id) : null,
    lockedBy: row.locked_by ? String(row.locked_by) : null,
    lockedAt: row.locked_at == null ? null : num(row.locked_at),
    updatedBy: row.updated_by ? String(row.updated_by) : null,
    updatedAt: num(row.updated_at),
  };
}

async function filesOf(sql: Sql, projectId: string): Promise<FileRec[]> {
  const rows = await sql<Row>`
    select id, path, kind, content, language, assignee_id, locked_by, updated_by,
      case when locked_at is null then null else (extract(epoch from locked_at) * 1000)::float8 end as locked_at,
      (extract(epoch from updated_at) * 1000)::float8 as updated_at
    from files where project_id = ${projectId} order by path`;
  return rows.map(mapFile);
}

async function access(sql: Sql, userId: string, projectId: string, min: Role) {
  const profile = await profileOf(sql, userId);
  if (!profile) return { error: "profile_required" as const };
  const member = await sql<{ role: string }>`select role from project_members where project_id = ${projectId} and user_id = ${userId}`;
  const projectRole = member[0] && isRole(member[0].role) ? member[0].role : null;
  const effective: Role | null =
    projectRole ?? (profile.role === "owner" || profile.role === "admin" ? "admin" : null);
  if (!effective || roleRank(effective) < roleRank(min)) return { error: "forbidden" as const };
  const projects = await sql<Row>`select id, name, slug, description, template, current_branch, created_by from projects where id = ${projectId}`;
  if (!projects[0]) return { error: "not_found" as const };
  return { profile, role: effective, project: projects[0] };
}

async function accessSlug(sql: Sql, userId: string, slug: string, min: Role) {
  const found = await sql<{ id: string }>`select id from projects where slug = ${slug} limit 1`;
  if (!found[0]) return { error: "not_found" as const };
  return access(sql, userId, found[0].id, min);
}

function snapFrom(files: FileRec[]): SnapFile[] {
  return files.map((file) => ({ path: file.path, kind: file.kind, content: file.content }));
}

async function headSnapshot(sql: Sql, projectId: string, branch: string): Promise<{ id: string | null; files: SnapFile[] }> {
  const rows = await sql<{ head_commit_id: string | null }>`select head_commit_id from branches where project_id = ${projectId} and name = ${branch} limit 1`;
  const commitId = rows[0]?.head_commit_id ?? null;
  if (!commitId) return { id: null, files: [] };
  const commits = await sql<{ snapshot: string }>`select snapshot from commits where id = ${commitId}`;
  return { id: commitId, files: parseSnapshot(commits[0]?.snapshot) };
}

async function writeSnapshot(sql: Sql, projectId: string, userId: string, files: SnapFile[]) {
  const existing = await filesOf(sql, projectId);
  const byPath = new Map(existing.map((file) => [file.path, file]));
  const keep = new Set(files.map((file) => file.path));
  for (const file of files) {
    const prev = byPath.get(file.path);
    if (prev) {
      await sql`update files set kind = ${file.kind}, content = ${file.content}, language = ${file.kind === "file" ? languageFromPath(file.path) : ""}, updated_by = ${userId}, updated_at = now(), locked_by = null, locked_at = null where id = ${prev.id}`;
    } else {
      await sql`insert into files (id, project_id, path, kind, content, language, updated_by) values (${nid()}, ${projectId}, ${file.path}, ${file.kind}, ${file.content}, ${file.kind === "file" ? languageFromPath(file.path) : ""}, ${userId})`;
    }
  }
  for (const file of existing) {
    if (!keep.has(file.path)) await sql`delete from files where id = ${file.id}`;
  }
  await sql`update projects set updated_at = now() where id = ${projectId}`;
}

async function makeBackup(sql: Sql, projectId: string, userId: string, note: string, files: SnapFile[]) {
  await sql`insert into backups (id, project_id, note, snapshot, created_by) values (${nid()}, ${projectId}, ${note}, ${JSON.stringify(files)}, ${userId})`;
  const old = await sql<{ id: string }>`select id from backups where project_id = ${projectId} order by created_at desc offset 20`;
  for (const row of old) await sql`delete from backups where id = ${row.id}`;
}

async function ensureDir(sql: Sql, projectId: string, userId: string, path: string) {
  const rows = await sql<{ id: string }>`select id from files where project_id = ${projectId} and path = ${path}`;
  if (rows[0]) return;
  await sql`insert into files (id, project_id, path, kind, content, language, updated_by) values (${nid()}, ${projectId}, ${path}, 'dir', '', '', ${userId})`;
}

function validUsername(value: string): boolean {
  return /^[a-z0-9_]{3,20}$/.test(value);
}

function validAvatar(value: string | null): boolean {
  if (!value) return true;
  return value.startsWith("data:image/") && value.length < 80_000;
}

export const registrationMode = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql<{ n: unknown }>`select count(*) as n from profiles`;
  return { inviteOnly: num(rows[0]?.n) > 0 };
});

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const profile = await profileOf(sql, context.userId);
    const count = await sql<{ n: unknown }>`select count(*) as n from profiles`;
    const total = num(count[0]?.n);
    const email = await emailOf(sql, context.userId);
    if (!profile) {
      return { ok: true as const, profile: null, email, canBootstrap: total === 0, inviteOnly: total > 0, projects: [] };
    }
    const projects = await listVisible(sql, context.userId, profile.role);
    return { ok: true as const, profile, email, canBootstrap: false, inviteOnly: false, projects };
  });

async function listVisible(sql: Sql, userId: string, orgRole: Role) {
  const rows =
    orgRole === "owner" || orgRole === "admin"
      ? await sql<Row>`
          select p.id, p.name, p.slug, p.description, p.template, p.current_branch,
            coalesce(m.role, 'admin') as role,
            (extract(epoch from p.updated_at) * 1000)::float8 as updated_at
          from projects p
          left join project_members m on m.project_id = p.id and m.user_id = ${userId}
          order by p.updated_at desc`
      : await sql<Row>`
          select p.id, p.name, p.slug, p.description, p.template, p.current_branch, m.role,
            (extract(epoch from p.updated_at) * 1000)::float8 as updated_at
          from projects p
          join project_members m on m.project_id = p.id and m.user_id = ${userId}
          order by p.updated_at desc`;
  return rows.map((row) => ({
    id: String(row.id),
    name: String(row.name),
    slug: String(row.slug),
    description: String(row.description ?? ""),
    template: String(row.template),
    branch: String(row.current_branch),
    role: String(row.role),
    updatedAt: num(row.updated_at),
  }));
}

export const completeOnboarding = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (await profileOf(sql, context.userId)) return { ok: false as const, error: "exists" };
    const fullName = text(data.fullName, 80);
    const username = text(data.username, 20).toLowerCase();
    const bio = text(data.bio, 280);
    const avatar = text(data.avatar, 80_000) || null;
    const inviteToken = text(data.inviteToken, 80);
    if (fullName.length < 2) return { ok: false as const, error: "name" };
    if (!validUsername(username)) return { ok: false as const, error: "username" };
    if (!validAvatar(avatar)) return { ok: false as const, error: "avatar" };
    const taken = await sql`select user_id from profiles where username = ${username}`;
    if (taken[0]) return { ok: false as const, error: "username_taken" };
    const count = await sql<{ n: unknown }>`select count(*) as n from profiles`;
    let role: Role = "developer";
    let inviteId: string | null = null;
    if (num(count[0]?.n) === 0) role = "owner";
    else {
      if (!inviteToken) return { ok: false as const, error: "invite_required" };
      const invites = await sql<Row>`select id, role from invitations where token = ${inviteToken} and accepted_by is null and expires_at > now() limit 1`;
      if (!invites[0] || !isRole(String(invites[0].role))) return { ok: false as const, error: "invite_invalid" };
      role = String(invites[0].role) as Role;
      inviteId = String(invites[0].id);
    }
    await sql`insert into profiles (user_id, full_name, username, bio, avatar, role) values (${context.userId}, ${fullName}, ${username}, ${bio}, ${avatar}, ${role})`;
    if (inviteId) await sql`update invitations set accepted_by = ${context.userId} where id = ${inviteId}`;
    if (role === "owner") {
      const channelId = nid();
      await sql`insert into channels (id, kind, name, created_by) values (${channelId}, 'team', 'general', ${context.userId})`;
      await sql`insert into channel_members (channel_id, user_id) values (${channelId}, ${context.userId})`;
    } else {
      const rooms = await sql<{ id: string }>`select id from channels where kind = 'team'`;
      for (const room of rooms) {
        await sql`insert into channel_members (channel_id, user_id) values (${room.id}, ${context.userId}) on conflict (channel_id, user_id) do nothing`;
      }
    }
    await audit(sql, context.userId, "profile.create", username, role);
    return { ok: true as const };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const profile = await profileOf(sql, context.userId);
    if (!profile) return { ok: false as const, error: "profile_required" };
    const fullName = text(data.fullName, 80);
    const username = text(data.username, 20).toLowerCase();
    const bio = text(data.bio, 280);
    const avatar = data.avatar == null ? profile.avatar : text(data.avatar, 80_000) || null;
    if (fullName.length < 2) return { ok: false as const, error: "name" };
    if (!validUsername(username)) return { ok: false as const, error: "username" };
    if (!validAvatar(avatar)) return { ok: false as const, error: "avatar" };
    const taken = await sql`select user_id from profiles where username = ${username} and user_id <> ${context.userId}`;
    if (taken[0]) return { ok: false as const, error: "username_taken" };
    await sql`update profiles set full_name = ${fullName}, username = ${username}, bio = ${bio}, avatar = ${avatar} where user_id = ${context.userId}`;
    await audit(sql, context.userId, "profile.update", username);
    return { ok: true as const };
  });

export const getProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).username, 20).toLowerCase())
  .handler(async ({ context, data: username }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    const rows = await sql<Row>`select user_id, full_name, username, bio, avatar, role from profiles where username = ${username}`;
    if (!rows[0]) return { ok: false as const, error: "not_found" };
    const profile = mapProfile(rows[0]);
    const projects = await sql<Row>`
      select p.id, p.name, p.slug, m.role
      from project_members m join projects p on p.id = m.project_id
      where m.user_id = ${profile.userId} order by p.name`;
    const email = profile.userId === context.userId ? await emailOf(sql, context.userId) : null;
    return {
      ok: true as const,
      profile,
      email,
      self: profile.userId === context.userId,
      projects: projects.map((row) => ({
        id: String(row.id),
        name: String(row.name),
        slug: String(row.slug),
        role: String(row.role),
      })),
    };
  });

export const getTeam = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    const members = (await sql<Row>`select user_id, full_name, username, bio, avatar, role from profiles order by full_name`).map(mapProfile);
    const projects = await sql<{ id: string; name: string; slug: string }>`select id, name, slug from projects order by name`;
    const invites =
      roleRank(me.role) >= roleRank("admin")
        ? await sql<Row>`
            select id, token, role, (extract(epoch from expires_at) * 1000)::float8 as expires_at
            from invitations where accepted_by is null and expires_at > now() order by created_at desc`
        : [];
    return {
      ok: true as const,
      me,
      members,
      projects,
      invites: invites.map((row) => ({
        id: String(row.id),
        token: String(row.token),
        role: String(row.role),
        expiresAt: num(row.expires_at),
      })),
    };
  });

export const createInvite = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me || roleRank(me.role) < roleRank("admin")) return { ok: false as const, error: "forbidden" };
    const role = text(data.role, 20);
    if (role !== "admin" && role !== "developer" && role !== "viewer") return { ok: false as const, error: "role" };
    if (role === "admin" && me.role !== "owner") return { ok: false as const, error: "forbidden" };
    const token = nid().replace(/-/g, "") + nid().slice(0, 8);
    const id = nid();
    await sql`insert into invitations (id, token, role, created_by, expires_at) values (${id}, ${token}, ${role}, ${context.userId}, now() + interval '14 days')`;
    await audit(sql, context.userId, "invite.create", role);
    return { ok: true as const, token, id };
  });

export const revokeInvite = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).id, 80))
  .handler(async ({ context, data: inviteId }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me || roleRank(me.role) < roleRank("admin")) return { ok: false as const, error: "forbidden" };
    await sql`delete from invitations where id = ${inviteId} and accepted_by is null`;
    await audit(sql, context.userId, "invite.revoke", inviteId);
    return { ok: true as const };
  });

export const setOrgRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me || roleRank(me.role) < roleRank("admin")) return { ok: false as const, error: "forbidden" };
    const userId = text(data.userId, 80);
    const role = text(data.role, 20);
    if (!isRole(role)) return { ok: false as const, error: "role" };
    const target = await profileOf(sql, userId);
    if (!target) return { ok: false as const, error: "not_found" };
    if (me.role !== "owner" && (target.role === "owner" || target.role === "admin" || role === "owner" || role === "admin")) {
      return { ok: false as const, error: "forbidden" };
    }
    if (target.role === "owner" && role !== "owner") {
      const owners = await sql<{ n: unknown }>`select count(*) as n from profiles where role = 'owner'`;
      if (num(owners[0]?.n) <= 1) return { ok: false as const, error: "last_owner" };
    }
    await sql`update profiles set role = ${role} where user_id = ${userId}`;
    await audit(sql, context.userId, "role.update", target.username, role);
    return { ok: true as const };
  });

export const getStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    const admin = roleRank(me.role) >= roleRank("admin");
    const projects = admin
      ? await sql<{ n: unknown }>`select count(*) as n from projects`
      : await sql<{ n: unknown }>`select count(*) as n from project_members where user_id = ${context.userId}`;
    const members = await sql<{ n: unknown }>`select count(*) as n from profiles`;
    const tasks = admin
      ? await sql<{ n: unknown }>`select count(*) as n from tasks where status <> 'done'`
      : await sql<{ n: unknown }>`select count(*) as n from tasks where status <> 'done' and project_id in (select project_id from project_members where user_id = ${context.userId})`;
    const deploys = admin
      ? await sql<{ n: unknown }>`select count(*) as n from deployments where status = 'live'`
      : await sql<{ n: unknown }>`select count(*) as n from deployments where status = 'live' and project_id in (select project_id from project_members where user_id = ${context.userId})`;
    const messages = await sql<{ n: unknown }>`
      select count(*) as n from messages m
      join channel_members cm on cm.channel_id = m.channel_id and cm.user_id = ${context.userId}`;
    const commits = admin
      ? await sql<Row>`select to_char(created_at, 'MM-DD') as day, count(*) as n from commits where created_at > now() - interval '7 days' group by 1 order by min(created_at)`
      : await sql<Row>`select to_char(created_at, 'MM-DD') as day, count(*) as n from commits where created_at > now() - interval '7 days' and project_id in (select project_id from project_members where user_id = ${context.userId}) group by 1 order by min(created_at)`;
    const activity = admin
      ? await sql<Row>`
          select a.action, a.target, a.meta, pr.full_name, (extract(epoch from a.created_at) * 1000)::float8 as created_at
          from audit_log a left join profiles pr on pr.user_id = a.user_id
          order by a.created_at desc limit 12`
      : await sql<Row>`
          select a.action, a.target, a.meta, pr.full_name, (extract(epoch from a.created_at) * 1000)::float8 as created_at
          from audit_log a left join profiles pr on pr.user_id = a.user_id
          where a.user_id = ${context.userId}
          order by a.created_at desc limit 12`;
    return {
      ok: true as const,
      projects: num(projects[0]?.n),
      members: num(members[0]?.n),
      openTasks: num(tasks[0]?.n),
      liveDeploys: num(deploys[0]?.n),
      messages: num(messages[0]?.n),
      commits: commits.map((row) => ({ day: String(row.day), count: num(row.n) })),
      activity: activity.map((row) => ({
        action: String(row.action),
        target: row.target ? String(row.target) : "",
        meta: row.meta ? String(row.meta) : "",
        name: row.full_name ? String(row.full_name) : "",
        at: num(row.created_at),
      })),
    };
  });

export const getAudit = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me || roleRank(me.role) < roleRank("admin")) return { ok: false as const, error: "forbidden" };
    const rows = await sql<Row>`
      select a.action, a.target, a.meta, pr.full_name, pr.username,
        (extract(epoch from a.created_at) * 1000)::float8 as created_at
      from audit_log a left join profiles pr on pr.user_id = a.user_id
      order by a.created_at desc limit 80`;
    return {
      ok: true as const,
      entries: rows.map((row) => ({
        action: String(row.action),
        target: row.target ? String(row.target) : "",
        meta: row.meta ? String(row.meta) : "",
        name: row.full_name ? String(row.full_name) : "",
        username: row.username ? String(row.username) : "",
        at: num(row.created_at),
      })),
    };
  });

async function uniqueSlug(sql: Sql, name: string) {
  const base =
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 40) || "project";
  for (let i = 0; i < 6; i += 1) {
    const slug = i === 0 ? base : `${base}-${i + 1}`;
    const rows = await sql`select id from projects where slug = ${slug}`;
    if (!rows[0]) return slug;
  }
  return `${base}-${nid().slice(0, 6)}`;
}

export const createProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me || roleRank(me.role) < roleRank("developer")) return { ok: false as const, error: "forbidden" };
    const name = text(data.name, 80);
    const description = text(data.description, 400);
    const template = text(data.template, 20);
    if (name.length < 2 || !isTemplate(template)) return { ok: false as const, error: "invalid" };
    const slug = await uniqueSlug(sql, name);
    const projectId = nid();
    const tree = templateTree(template as TemplateId);
    await sql`insert into projects (id, name, slug, description, template, created_by) values (${projectId}, ${name}, ${slug}, ${description}, ${template}, ${context.userId})`;
    await sql`insert into project_members (project_id, user_id, role) values (${projectId}, ${context.userId}, 'owner')`;
    for (const file of tree) {
      await sql`insert into files (id, project_id, path, kind, content, language, updated_by) values (${nid()}, ${projectId}, ${file.path}, ${file.kind}, ${file.content}, ${file.kind === "file" ? languageFromPath(file.path) : ""}, ${context.userId})`;
    }
    const commitId = nid();
    const branchId = nid();
    await sql`insert into commits (id, project_id, branch_name, message, author_id, snapshot) values (${commitId}, ${projectId}, 'main', ${"Initial commit"}, ${context.userId}, ${JSON.stringify(tree)})`;
    await sql`insert into branches (id, project_id, name, head_commit_id, created_by) values (${branchId}, ${projectId}, 'main', ${commitId}, ${context.userId})`;
    const channelId = nid();
    await sql`insert into channels (id, kind, project_id, name, created_by) values (${channelId}, 'project', ${projectId}, ${"project"}, ${context.userId})`;
    await sql`insert into channel_members (channel_id, user_id) values (${channelId}, ${context.userId})`;
    await makeBackup(sql, projectId, context.userId, "initial", tree);
    await audit(sql, context.userId, "project.create", slug, template);
    return { ok: true as const, slug };
  });

export const addProjectMember = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const gate = await access(sql, context.userId, projectId, "admin");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const username = text(data.username, 20).toLowerCase();
    const role = text(data.role, 20);
    if (!isRole(role) || role === "owner") return { ok: false as const, error: "role" };
    const person = await sql<{ user_id: string }>`select user_id from profiles where username = ${username}`;
    if (!person[0]) return { ok: false as const, error: "not_found" };
    await sql`insert into project_members (project_id, user_id, role) values (${projectId}, ${person[0].user_id}, ${role}) on conflict (project_id, user_id) do update set role = ${role}`;
    const channel = await sql<{ id: string }>`select id from channels where project_id = ${projectId} and kind = 'project' limit 1`;
    if (channel[0]) {
      await sql`insert into channel_members (channel_id, user_id) values (${channel[0].id}, ${person[0].user_id}) on conflict (channel_id, user_id) do nothing`;
    }
    await audit(sql, context.userId, "project.member", username, role);
    return { ok: true as const };
  });

export const getProject = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).slug, 80))
  .handler(async ({ context, data: slug }) => {
    const sql = await getSql();
    const gate = await accessSlug(sql, context.userId, slug, "viewer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const projectId = String(gate.project.id);
    const files = await filesOf(sql, projectId);
    const members = await sql<Row>`
      select m.user_id, m.role, p.full_name, p.username, p.avatar
      from project_members m join profiles p on p.user_id = m.user_id
      where m.project_id = ${projectId} order by p.full_name`;
    const branches = await sql<Row>`select name, head_commit_id from branches where project_id = ${projectId} order by name`;
    const commits = await sql<Row>`
      select c.id, c.branch_name, c.message, c.parent_id, pr.username,
        (extract(epoch from c.created_at) * 1000)::float8 as created_at
      from commits c left join profiles pr on pr.user_id = c.author_id
      where c.project_id = ${projectId} order by c.created_at desc limit 40`;
    const tasks = await sql<Row>`
      select id, title, description, status, file_path, assignee_id,
        (extract(epoch from created_at) * 1000)::float8 as created_at
      from tasks where project_id = ${projectId} order by created_at`;
    const reviews = await sql<Row>`
      select id, title, branch_name, status, author_id,
        (extract(epoch from created_at) * 1000)::float8 as created_at
      from reviews where project_id = ${projectId} order by created_at desc`;
    const comments = await sql<Row>`
      select c.id, c.review_id, c.user_id, c.file_path, c.line_no, c.body, pr.username,
        (extract(epoch from c.created_at) * 1000)::float8 as created_at
      from review_comments c
      join reviews r on r.id = c.review_id
      left join profiles pr on pr.user_id = c.user_id
      where r.project_id = ${projectId} order by c.created_at`;
    const backups = await sql<Row>`
      select id, note, (extract(epoch from created_at) * 1000)::float8 as created_at
      from backups where project_id = ${projectId} order by created_at desc limit 12`;
    const deployments = await sql<Row>`
      select id, status, log, (extract(epoch from created_at) * 1000)::float8 as created_at
      from deployments where project_id = ${projectId} order by created_at desc limit 8`;
    const channel = await sql<{ id: string }>`select id from channels where project_id = ${projectId} and kind = 'project' limit 1`;
    const branch = String(gate.project.current_branch);
    const head = await headSnapshot(sql, projectId, branch);
    const ai = await sql<Row>`
      select id, role, content, (extract(epoch from created_at) * 1000)::float8 as created_at
      from ai_messages where project_id = ${projectId} and user_id = ${context.userId}
      order by created_at desc limit 30`;
    return {
      ok: true as const,
      role: gate.role,
      project: {
        id: projectId,
        name: String(gate.project.name),
        slug: String(gate.project.slug),
        description: String(gate.project.description ?? ""),
        template: String(gate.project.template),
        branch,
      },
      files,
      members: members.map((row) => ({
        userId: String(row.user_id),
        role: String(row.role),
        fullName: String(row.full_name),
        username: String(row.username),
        avatar: row.avatar ? String(row.avatar) : null,
      })),
      branches: branches.map((row) => ({ name: String(row.name), head: row.head_commit_id ? String(row.head_commit_id) : null })),
      commits: commits.map((row) => ({
        id: String(row.id),
        branch: String(row.branch_name),
        message: String(row.message),
        parentId: row.parent_id ? String(row.parent_id) : null,
        username: row.username ? String(row.username) : "",
        at: num(row.created_at),
      })),
      tasks: tasks.map((row) => ({
        id: String(row.id),
        title: String(row.title),
        description: String(row.description ?? ""),
        status: String(row.status),
        filePath: row.file_path ? String(row.file_path) : "",
        assigneeId: row.assignee_id ? String(row.assignee_id) : null,
        at: num(row.created_at),
      })),
      reviews: reviews.map((row) => ({
        id: String(row.id),
        title: String(row.title),
        branch: String(row.branch_name),
        status: String(row.status),
        authorId: String(row.author_id),
        at: num(row.created_at),
      })),
      comments: comments.map((row) => ({
        id: String(row.id),
        reviewId: String(row.review_id),
        userId: String(row.user_id),
        username: row.username ? String(row.username) : "",
        filePath: row.file_path ? String(row.file_path) : "",
        line: row.line_no == null ? null : num(row.line_no),
        body: String(row.body),
        at: num(row.created_at),
      })),
      backups: backups.map((row) => ({ id: String(row.id), note: String(row.note ?? ""), at: num(row.created_at) })),
      deployments: deployments.map((row) => ({
        id: String(row.id),
        status: String(row.status),
        log: String(row.log ?? ""),
        at: num(row.created_at),
      })),
      channelId: channel[0]?.id ?? null,
      head: head.files,
      ai: ai
        .map((row) => ({
          id: String(row.id),
          role: String(row.role),
          content: String(row.content),
          at: num(row.created_at),
        }))
        .reverse(),
    };
  });

export const syncProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const gate = await access(sql, context.userId, projectId, "viewer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const versions = data.versions && typeof data.versions === "object" ? (data.versions as Record<string, unknown>) : {};
    const filePath = text(data.filePath, 180);
    const line = Math.max(1, Math.round(num(data.line)) || 1);
    if (roleRank(gate.role) >= roleRank("developer")) {
      await sql`
        insert into presence (project_id, user_id, file_path, line_no, updated_at)
        values (${projectId}, ${context.userId}, ${filePath || null}, ${line}, now())
        on conflict (project_id, user_id) do update set file_path = ${filePath || null}, line_no = ${line}, updated_at = now()`;
      if (filePath) {
        await sql`update files set locked_by = ${context.userId}, locked_at = now() where project_id = ${projectId} and path = ${filePath} and kind = 'file' and (locked_by is null or locked_by = ${context.userId} or locked_at < now() - interval '90 seconds')`;
      }
    }
    const files = await filesOf(sql, projectId);
    const changed = files.filter((file) => file.kind === "file" && file.updatedAt > num(versions[file.path]) + 20 && file.updatedBy !== context.userId);
    const presence = await sql<Row>`
      select p.user_id, p.file_path, p.line_no, pr.full_name, pr.username,
        (extract(epoch from p.updated_at) * 1000)::float8 as updated_at
      from presence p join profiles pr on pr.user_id = p.user_id
      where p.project_id = ${projectId} and p.updated_at > now() - interval '30 seconds'`;
    return {
      ok: true as const,
      changed: changed.map((file) => ({ path: file.path, content: file.content, updatedAt: file.updatedAt, updatedBy: file.updatedBy })),
      headers: files.map((file) => ({
        path: file.path,
        lockedBy: file.lockedBy,
        lockedAt: file.lockedAt,
        assigneeId: file.assigneeId,
        updatedAt: file.updatedAt,
      })),
      presence: presence
        .filter((row) => String(row.user_id) !== context.userId)
        .map((row) => ({
          userId: String(row.user_id),
          fullName: String(row.full_name),
          username: String(row.username),
          filePath: row.file_path ? String(row.file_path) : "",
          line: num(row.line_no),
          at: num(row.updated_at),
        })),
    };
  });

export const saveFile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const path = text(data.path, 180);
    const content = typeof data.content === "string" ? data.content.slice(0, 200_000) : "";
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (!validPath(path)) return { ok: false as const, error: "path" };
    const rows = await sql<Row>`
      select id, content, locked_by, updated_by,
        case when locked_at is null then null else (extract(epoch from locked_at) * 1000)::float8 end as locked_at,
        (extract(epoch from updated_at) * 1000)::float8 as updated_at
      from files where project_id = ${projectId} and path = ${path} and kind = 'file'`;
    const row = rows[0];
    if (!row) return { ok: false as const, error: "not_found" };
    const lockedBy = row.locked_by ? String(row.locked_by) : null;
    const lockedAt = row.locked_at == null ? null : num(row.locked_at);
    if (lockedBy && lockedBy !== context.userId && lockedAt && Date.now() - lockedAt < 90_000) {
      return { ok: false as const, error: "locked" };
    }
    const base = data.baseUpdatedAt == null ? null : num(data.baseUpdatedAt);
    const serverUpdated = num(row.updated_at);
    if (base != null && serverUpdated > base + 50 && String(row.updated_by ?? "") !== context.userId && String(row.content ?? "") !== content) {
      return { ok: false as const, error: "conflict", serverContent: String(row.content ?? ""), serverUpdatedAt: serverUpdated };
    }
    await sql`update files set content = ${content}, language = ${languageFromPath(path)}, locked_by = ${context.userId}, locked_at = now(), updated_by = ${context.userId}, updated_at = now() where id = ${String(row.id)}`;
    await sql`update projects set updated_at = now() where id = ${projectId}`;
    const updated = await sql<{ updated_at: unknown }>`select (extract(epoch from updated_at) * 1000)::float8 as updated_at from files where id = ${String(row.id)}`;
    return { ok: true as const, updatedAt: num(updated[0]?.updated_at) };
  });

export const createPath = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const path = text(data.path, 180);
    const kind = data.kind === "dir" ? "dir" : "file";
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (!validPath(path)) return { ok: false as const, error: "path" };
    const exists = await sql`select id from files where project_id = ${projectId} and path = ${path}`;
    if (exists[0]) return { ok: false as const, error: "exists" };
    for (const dir of parentDirs(path)) await ensureDir(sql, projectId, context.userId, dir);
    await sql`insert into files (id, project_id, path, kind, content, language, updated_by) values (${nid()}, ${projectId}, ${path}, ${kind}, '', ${kind === "file" ? languageFromPath(path) : ""}, ${context.userId})`;
    await audit(sql, context.userId, "file.create", path);
    return { ok: true as const };
  });

export const deletePath = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const path = text(data.path, 180);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (!validPath(path)) return { ok: false as const, error: "path" };
    await sql`delete from files where project_id = ${projectId} and (path = ${path} or left(path, length(${path}) + 1) = ${path + "/"})`;
    await audit(sql, context.userId, "file.delete", path);
    return { ok: true as const };
  });

export const renamePath = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const from = text(data.from, 180);
    const to = text(data.to, 180);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (!validPath(from) || !validPath(to)) return { ok: false as const, error: "path" };
    if (from === to || to.startsWith(`${from}/`)) return { ok: false as const, error: "path_overlap" };
    const rows = await sql<{ id: string; path: string }>`select id, path from files where project_id = ${projectId} and (path = ${from} or left(path, length(${from}) + 1) = ${from + "/"})`;
    if (!rows.length) return { ok: false as const, error: "not_found" };
    const selectedIds = new Set(rows.map((row) => String(row.id)));
    const allPaths = await sql<{ id: string; path: string }>`select id, path from files where project_id = ${projectId}`;
    const occupied = new Set(allPaths.filter((row) => !selectedIds.has(String(row.id))).map((row) => String(row.path)));
    const destinations = rows.map((row) => to + row.path.slice(from.length));
    if (destinations.some((path) => occupied.has(path)) || new Set(destinations).size !== destinations.length) {
      return { ok: false as const, error: "exists" };
    }
    for (const dir of parentDirs(to)) await ensureDir(sql, projectId, context.userId, dir);
    // Move via unique temporary names to avoid collisions when source and destination
    // trees overlap in the same project (the final destinations were prevalidated).
    const tempPaths = rows.map(() => `.est-rename-${nid()}`);
    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i]!;
      await sql`update files set path = ${tempPaths[i]!} where id = ${row.id}`;
    }
    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i]!;
      const next = destinations[i]!;
      await sql`update files set path = ${next}, language = ${languageFromPath(next)}, updated_by = ${context.userId}, updated_at = now() where id = ${row.id}`;
    }
    await audit(sql, context.userId, "file.rename", `${from} -> ${to}`);
    return { ok: true as const };
  });

export const assignFile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const path = text(data.path, 180);
    const assigneeId = text(data.assigneeId, 80) || null;
    const gate = await access(sql, context.userId, projectId, "admin");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (assigneeId) {
      const member = await sql`select user_id from project_members where project_id = ${projectId} and user_id = ${assigneeId}`;
      if (!member[0]) return { ok: false as const, error: "not_found" };
    }
    await sql`update files set assignee_id = ${assigneeId} where project_id = ${projectId} and path = ${path}`;
    await audit(sql, context.userId, "file.assign", path, assigneeId ?? "");
    return { ok: true as const };
  });

export const unlockFile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const path = text(data.path, 180);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (roleRank(gate.role) >= roleRank("admin")) {
      await sql`update files set locked_by = null, locked_at = null where project_id = ${projectId} and path = ${path}`;
    } else {
      await sql`update files set locked_by = null, locked_at = null where project_id = ${projectId} and path = ${path} and locked_by = ${context.userId}`;
    }
    return { ok: true as const };
  });

async function commitTo(sql: Sql, projectId: string, userId: string, branch: string, message: string, parent2: string | null) {
  const files = await filesOf(sql, projectId);
  const head = await headSnapshot(sql, projectId, branch);
  const status = gitStatus(snapFrom(files), head.files);
  if (!parent2 && status.clean) return { ok: false as const, error: "empty" };
  const commitId = nid();
  await sql`insert into commits (id, project_id, branch_name, parent_id, parent2_id, message, author_id, snapshot) values (${commitId}, ${projectId}, ${branch}, ${head.id}, ${parent2}, ${message}, ${userId}, ${JSON.stringify(snapFrom(files))})`;
  await sql`update branches set head_commit_id = ${commitId} where project_id = ${projectId} and name = ${branch}`;
  await sql`update projects set updated_at = now() where id = ${projectId}`;
  await makeBackup(sql, projectId, userId, `commit: ${message}`, snapFrom(files));
  await audit(sql, userId, "git.commit", branch, message);
  return { ok: true as const, id: commitId };
}

export const gitCommit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const message = text(data.message, 200);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (message.length < 2) return { ok: false as const, error: "message" };
    return commitTo(sql, projectId, context.userId, String(gate.project.current_branch), message, null);
  });

export const gitBranch = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const name = text(data.name, 40);
    const checkout = Boolean(data.checkout);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (!/^[a-zA-Z0-9._/-]{1,40}$/.test(name) || name.includes("..")) return { ok: false as const, error: "branch" };
    const current = String(gate.project.current_branch);
    const head = await headSnapshot(sql, projectId, current);
    const exists = await sql`select id from branches where project_id = ${projectId} and name = ${name}`;
    if (exists[0]) return { ok: false as const, error: "exists" };
    await sql`insert into branches (id, project_id, name, head_commit_id, created_by) values (${nid()}, ${projectId}, ${name}, ${head.id}, ${context.userId})`;
    if (checkout) await sql`update projects set current_branch = ${name} where id = ${projectId}`;
    await audit(sql, context.userId, "git.branch", name);
    return { ok: true as const };
  });

export const gitCheckout = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const name = text(data.name, 40);
    const force = Boolean(data.force);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const branch = await sql`select name from branches where project_id = ${projectId} and name = ${name}`;
    if (!branch[0]) return { ok: false as const, error: "not_found" };
    const current = String(gate.project.current_branch);
    const files = await filesOf(sql, projectId);
    const head = await headSnapshot(sql, projectId, current);
    if (!force && !gitStatus(snapFrom(files), head.files).clean) return { ok: false as const, error: "dirty" };
    const next = await headSnapshot(sql, projectId, name);
    await writeSnapshot(sql, projectId, context.userId, next.files);
    await sql`update projects set current_branch = ${name} where id = ${projectId}`;
    await audit(sql, context.userId, "git.checkout", name);
    return { ok: true as const };
  });

async function ancestorIds(sql: Sql, start: string | null): Promise<string[]> {
  const order: string[] = [];
  const seen = new Set<string>();
  const queue = start ? [start] : [];
  while (queue.length && order.length < 300) {
    const current = queue.shift();
    if (!current || seen.has(current)) continue;
    seen.add(current);
    order.push(current);
    const rows = await sql<{ parent_id: string | null; parent2_id: string | null }>`select parent_id, parent2_id from commits where id = ${current}`;
    if (rows[0]?.parent_id) queue.push(rows[0].parent_id);
    if (rows[0]?.parent2_id) queue.push(rows[0].parent2_id);
  }
  return order;
}

export const gitMerge = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const source = text(data.source, 40);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const current = String(gate.project.current_branch);
    if (source === current) return { ok: false as const, error: "same" };
    const sourceHead = await headSnapshot(sql, projectId, source);
    const ourHead = await headSnapshot(sql, projectId, current);
    if (!sourceHead.id) return { ok: false as const, error: "not_found" };
    const ourAncestors = new Set(await ancestorIds(sql, ourHead.id));
    const theirAncestors = await ancestorIds(sql, sourceHead.id);
    if (ourAncestors.has(sourceHead.id)) return { ok: true as const, conflicts: [] as string[], fast: true };
    if (ourHead.id && theirAncestors.includes(ourHead.id)) {
      await writeSnapshot(sql, projectId, context.userId, sourceHead.files);
      await sql`update branches set head_commit_id = ${sourceHead.id} where project_id = ${projectId} and name = ${current}`;
      await audit(sql, context.userId, "git.merge", `${source} -> ${current}`, "fast-forward");
      return { ok: true as const, conflicts: [] as string[], fast: true };
    }
    const baseId = theirAncestors.find((id) => ourAncestors.has(id)) ?? null;
    let baseFiles: SnapFile[] = [];
    if (baseId) {
      const row = await sql<{ snapshot: string }>`select snapshot from commits where id = ${baseId}`;
      baseFiles = parseSnapshot(row[0]?.snapshot);
    }
    const ours = new Map((await filesOf(sql, projectId)).map((file) => [file.path, file]));
    const theirs = new Map(sourceHead.files.map((file) => [file.path, file]));
    const base = new Map(baseFiles.map((file) => [file.path, file]));
    const paths = new Set<string>([...ours.keys(), ...theirs.keys()]);
    const conflicts: string[] = [];
    const next: SnapFile[] = [];
    for (const path of paths) {
      const o = ours.get(path);
      const t = theirs.get(path);
      const b = base.get(path);
      if (o && !t) {
        if (!b) next.push({ path, kind: o.kind, content: o.content });
        continue;
      }
      if (t && !o) {
        next.push({ path, kind: t.kind, content: t.content });
        continue;
      }
      if (!o || !t) continue;
      if (o.kind === "dir" || t.kind === "dir") {
        next.push({ path, kind: "dir", content: "" });
        continue;
      }
      const merged = mergeTexts(b?.content ?? "", o.content, t.content, source);
      if (merged.conflict) conflicts.push(path);
      next.push({ path, kind: "file", content: merged.content });
    }
    await writeSnapshot(sql, projectId, context.userId, next);
    if (!conflicts.length) await commitTo(sql, projectId, context.userId, current, `Merge ${source} into ${current}`, sourceHead.id);
    await audit(sql, context.userId, "git.merge", `${source} -> ${current}`, conflicts.join(","));
    return { ok: true as const, conflicts, fast: false };
  });

export const saveTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const title = text(data.title, 120);
    const description = text(data.description, 500);
    const status = text(data.status, 20) || "todo";
    const filePath = text(data.filePath, 180) || null;
    const assigneeId = text(data.assigneeId, 80) || null;
    const taskId = text(data.id, 80);
    if (!["todo", "doing", "review", "done"].includes(status) || title.length < 2) return { ok: false as const, error: "invalid" };
    if (filePath) {
      if (!validPath(filePath)) return { ok: false as const, error: "path" };
      const file = await sql`select id from files where project_id = ${projectId} and path = ${filePath} and kind = 'file'`;
      if (!file[0]) return { ok: false as const, error: "file_not_found" };
    }
    if (assigneeId) {
      const member = await sql`select user_id from project_members where project_id = ${projectId} and user_id = ${assigneeId}`;
      if (!member[0]) return { ok: false as const, error: "assignee_not_member" };
    }
    if (taskId) {
      const existing = await sql`select id from tasks where id = ${taskId} and project_id = ${projectId}`;
      if (!existing[0]) return { ok: false as const, error: "not_found" };
      await sql`update tasks set title = ${title}, description = ${description}, status = ${status}, file_path = ${filePath}, assignee_id = ${assigneeId} where id = ${taskId} and project_id = ${projectId}`;
      await audit(sql, context.userId, "task.update", title);
      return { ok: true as const, id: taskId };
    }
    const id = nid();
    await sql`insert into tasks (id, project_id, title, description, status, file_path, assignee_id, created_by) values (${id}, ${projectId}, ${title}, ${description}, ${status}, ${filePath}, ${assigneeId}, ${context.userId})`;
    await audit(sql, context.userId, "task.create", title);
    return { ok: true as const, id };
  });

export const moveTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const status = text(data.status, 20);
    const taskId = text(data.id, 80);
    if (!["todo", "doing", "review", "done"].includes(status)) return { ok: false as const, error: "invalid" };
    const existing = await sql`select id from tasks where id = ${taskId} and project_id = ${projectId}`;
    if (!existing[0]) return { ok: false as const, error: "not_found" };
    await sql`update tasks set status = ${status} where id = ${taskId} and project_id = ${projectId}`;
    await audit(sql, context.userId, "task.move", taskId, status);
    return { ok: true as const };
  });

async function channelAllowed(sql: Sql, userId: string, channelId: string) {
  const rows = await sql`select channel_id from channel_members where channel_id = ${channelId} and user_id = ${userId}`;
  return Boolean(rows[0]);
}

export const listChannels = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    const rows = await sql<Row>`
      select c.id, c.kind, c.project_id, c.name, c.dm_key, p.slug, p.name as project_name,
        (select count(*) from messages msg where msg.channel_id = c.id and msg.created_at > m.last_read_at and msg.user_id <> ${context.userId}) as unread
      from channels c
      join channel_members m on m.channel_id = c.id and m.user_id = ${context.userId}
      left join projects p on p.id = c.project_id
      order by c.created_at`;
    const channels = [];
    for (const row of rows) {
      let title = row.name ? String(row.name) : "";
      let peer: string | null = null;
      if (row.kind === "dm") {
        const other = await sql<Row>`
          select pr.full_name, pr.username from channel_members cm
          join profiles pr on pr.user_id = cm.user_id
          where cm.channel_id = ${String(row.id)} and cm.user_id <> ${context.userId} limit 1`;
        title = other[0] ? String(other[0].full_name) : "DM";
        peer = other[0] ? String(other[0].username) : null;
      } else if (row.kind === "project") title = String(row.project_name ?? title);
      channels.push({
        id: String(row.id),
        kind: String(row.kind),
        projectId: row.project_id ? String(row.project_id) : null,
        slug: row.slug ? String(row.slug) : null,
        title,
        peer,
        unread: num(row.unread),
      });
    }
    return { ok: true as const, channels, role: me.role };
  });

export const createTeamChannel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).name, 32))
  .handler(async ({ context, data: rawName }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    if (me.role !== "owner" && me.role !== "admin") return { ok: false as const, error: "forbidden" };
    const name = rawName.trim();
    if (name.length < 2 || /[\u0000-\u001f]/.test(name)) return { ok: false as const, error: "invalid" };
    const existing = await sql<{ id: string }>`select id from channels where kind = 'team' and lower(name) = ${name.toLowerCase()} limit 1`;
    if (existing[0]) return { ok: false as const, error: "exists" };
    const channelId = nid();
    await sql`insert into channels (id, kind, name, created_by) values (${channelId}, 'team', ${name}, ${context.userId})`;
    const people = await sql<{ user_id: string }>`select user_id from profiles`;
    for (const person of people) {
      await sql`insert into channel_members (channel_id, user_id) values (${channelId}, ${person.user_id}) on conflict (channel_id, user_id) do nothing`;
    }
    await audit(sql, context.userId, "channel.create", name);
    return { ok: true as const, channelId };
  });

export const openDm = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).username, 20).toLowerCase())
  .handler(async ({ context, data: username }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    const other = await sql<{ user_id: string }>`select user_id from profiles where username = ${username}`;
    if (!other[0]) return { ok: false as const, error: "not_found" };
    if (other[0].user_id === context.userId) return { ok: false as const, error: "self" };
    const key = [context.userId, other[0].user_id].sort().join("|");
    const existing = await sql<{ id: string }>`select id from channels where dm_key = ${key}`;
    if (existing[0]) return { ok: true as const, channelId: existing[0].id };
    const channelId = nid();
    await sql`insert into channels (id, kind, dm_key, created_by) values (${channelId}, 'dm', ${key}, ${context.userId})`;
    await sql`insert into channel_members (channel_id, user_id) values (${channelId}, ${context.userId})`;
    await sql`insert into channel_members (channel_id, user_id) values (${channelId}, ${other[0].user_id})`;
    return { ok: true as const, channelId };
  });

export const listMessages = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).channelId, 80))
  .handler(async ({ context, data: channelId }) => {
    const sql = await getSql();
    if (!(await channelAllowed(sql, context.userId, channelId))) return { ok: false as const, error: "forbidden" };
    const rows = await sql<Row>`
      select m.id, m.user_id, m.body, m.parent_id, m.snippet, m.snippet_path, pr.full_name, pr.username, pr.avatar,
        (extract(epoch from m.created_at) * 1000)::float8 as created_at
      from messages m join profiles pr on pr.user_id = m.user_id
      where m.channel_id = ${channelId}
      order by m.created_at asc limit 300`;
    await sql`update channel_members set last_read_at = now() where channel_id = ${channelId} and user_id = ${context.userId}`;
    return {
      ok: true as const,
      messages: rows.map((row) => ({
        id: String(row.id),
        userId: String(row.user_id),
        body: String(row.body),
        parentId: row.parent_id ? String(row.parent_id) : null,
        snippet: row.snippet ? String(row.snippet) : "",
        snippetPath: row.snippet_path ? String(row.snippet_path) : "",
        fullName: String(row.full_name),
        username: String(row.username),
        avatar: row.avatar ? String(row.avatar) : null,
        at: num(row.created_at),
      })),
    };
  });

export const postMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await profileOf(sql, context.userId);
    if (!me) return { ok: false as const, error: "profile_required" };
    const channelId = text(data.channelId, 80);
    if (!(await channelAllowed(sql, context.userId, channelId))) return { ok: false as const, error: "forbidden" };
    const body = text(data.body, 4000);
    const snippet = typeof data.snippet === "string" ? data.snippet.slice(0, 8000) : "";
    const snippetPath = text(data.snippetPath, 180);
    const parentId = text(data.parentId, 80) || null;
    if (!body && !snippet) return { ok: false as const, error: "empty" };
    const id = nid();
    await sql`insert into messages (id, channel_id, user_id, body, parent_id, snippet, snippet_path) values (${id}, ${channelId}, ${context.userId}, ${body}, ${parentId}, ${snippet || null}, ${snippetPath || null})`;
    return { ok: true as const, id };
  });

export const saveReview = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const title = text(data.title, 120);
    const branch = text(data.branch, 40);
    if (title.length < 2) return { ok: false as const, error: "invalid" };
    const exists = await sql`select name from branches where project_id = ${projectId} and name = ${branch}`;
    if (!exists[0]) return { ok: false as const, error: "not_found" };
    const id = nid();
    await sql`insert into reviews (id, project_id, title, branch_name, author_id) values (${id}, ${projectId}, ${title}, ${branch}, ${context.userId})`;
    await audit(sql, context.userId, "review.create", title, branch);
    return { ok: true as const, id };
  });

export const reviewComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const reviewId = text(data.reviewId, 80);
    const reviews = await sql<{ project_id: string }>`select project_id from reviews where id = ${reviewId}`;
    if (!reviews[0]) return { ok: false as const, error: "not_found" };
    const gate = await access(sql, context.userId, reviews[0].project_id, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const body = text(data.body, 1000);
    const filePath = text(data.filePath, 180) || null;
    const line = data.line == null || data.line === "" ? null : Math.round(num(data.line));
    if (!body) return { ok: false as const, error: "empty" };
    await sql`insert into review_comments (id, review_id, user_id, file_path, line_no, body) values (${nid()}, ${reviewId}, ${context.userId}, ${filePath}, ${line}, ${body})`;
    return { ok: true as const };
  });

export const setReviewStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const reviewId = text(data.id, 80);
    const status = text(data.status, 20);
    if (!["open", "approved", "changes"].includes(status)) return { ok: false as const, error: "invalid" };
    const reviews = await sql<{ project_id: string }>`select project_id from reviews where id = ${reviewId}`;
    if (!reviews[0]) return { ok: false as const, error: "not_found" };
    const gate = await access(sql, context.userId, reviews[0].project_id, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    await sql`update reviews set status = ${status} where id = ${reviewId}`;
    await audit(sql, context.userId, "review.status", reviewId, status);
    return { ok: true as const };
  });

export const reviewDiff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const branch = text(data.branch, 40);
    const gate = await access(sql, context.userId, projectId, "viewer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const main = await headSnapshot(sql, projectId, "main");
    const other = await headSnapshot(sql, projectId, branch);
    const base = new Map(main.files.filter((file) => file.kind === "file").map((file) => [file.path, file.content]));
    const next = new Map(other.files.filter((file) => file.kind === "file").map((file) => [file.path, file.content]));
    const paths = new Set([...base.keys(), ...next.keys()]);
    const diffs = [];
    for (const path of paths) {
      const before = base.get(path) ?? "";
      const after = next.get(path) ?? "";
      if (before === after) continue;
      diffs.push({ path, before, after, status: !base.has(path) ? "added" : !next.has(path) ? "deleted" : "modified" });
    }
    return { ok: true as const, diffs };
  });

export const publishDeploy = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const passed = Boolean(data.passed);
    const log = typeof data.log === "string" ? data.log.slice(0, 8000) : "";
    const files = await filesOf(sql, projectId);
    const id = nid();
    if (!passed) {
      await sql`insert into deployments (id, project_id, status, log, snapshot, created_by) values (${id}, ${projectId}, 'failed', ${log}, '', ${context.userId})`;
      await audit(sql, context.userId, "deploy.fail", String(gate.project.slug));
      return { ok: true as const, id, status: "failed" as const };
    }
    const snapshot = JSON.stringify(snapFrom(files));
    await makeBackup(sql, projectId, context.userId, "deploy", snapFrom(files));
    await sql`insert into deployments (id, project_id, status, log, snapshot, created_by) values (${id}, ${projectId}, 'live', ${log}, ${snapshot}, ${context.userId})`;
    await audit(sql, context.userId, "deploy.live", String(gate.project.slug));
    return { ok: true as const, id, status: "live" as const };
  });

export const getLive = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).slug, 80))
  .handler(async ({ context, data: slug }) => {
    const sql = await getSql();
    const gate = await accessSlug(sql, context.userId, slug, "viewer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const rows = await sql<{ snapshot: string; log: string }>`
      select snapshot, log from deployments
      where project_id = ${String(gate.project.id)} and status = 'live'
      order by created_at desc limit 1`;
    if (!rows[0]) return { ok: false as const, error: "not_found" };
    return { ok: true as const, name: String(gate.project.name), snapshot: rows[0].snapshot, log: rows[0].log };
  });

export const restoreBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const backupId = text(data.id, 80);
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const rows = await sql<{ snapshot: string }>`select snapshot from backups where id = ${backupId} and project_id = ${projectId}`;
    if (!rows[0]) return { ok: false as const, error: "not_found" };
    await writeSnapshot(sql, projectId, context.userId, parseSnapshot(rows[0].snapshot));
    await audit(sql, context.userId, "backup.restore", backupId);
    return { ok: true as const };
  });

export const createBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => text(obj(input).projectId, 80))
  .handler(async ({ context, data: projectId }) => {
    const sql = await getSql();
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    const files = await filesOf(sql, projectId);
    await makeBackup(sql, projectId, context.userId, "manual", snapFrom(files));
    await audit(sql, context.userId, "backup.create", String(gate.project.slug));
    return { ok: true as const };
  });

function parseAi(raw: string): { message: string; edits: { path: string; content: string }[]; runTests: boolean } {
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenced?.[1] ?? raw;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start < 0 || end <= start) return { message: raw.slice(0, 4000), edits: [], runTests: false };
  try {
    const json = JSON.parse(body.slice(start, end + 1)) as {
      message?: unknown;
      edits?: { path?: unknown; content?: unknown }[];
      runTests?: unknown;
    };
    const edits = Array.isArray(json.edits)
      ? json.edits
          .filter((edit) => edit && typeof edit.path === "string" && typeof edit.content === "string" && validPath(edit.path) && edit.content.length < 80_000)
          .slice(0, 6)
          .map((edit) => ({ path: String(edit.path), content: String(edit.content) }))
      : [];
    return { message: text(json.message, 4000) || raw.slice(0, 4000), edits, runTests: Boolean(json.runTests) };
  } catch {
    return { message: raw.slice(0, 4000), edits: [], runTests: false };
  }
}

export const askAi = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => obj(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const projectId = text(data.projectId, 80);
    const message = text(data.message, 4000);
    const activePath = text(data.activePath, 180);
    const extra = typeof data.extra === "string" ? data.extra.slice(0, 6000) : "";
    const gate = await access(sql, context.userId, projectId, "developer");
    if ("error" in gate) return { ok: false as const, error: gate.error };
    if (message.length < 1) return { ok: false as const, error: "empty" };
    const usage = await sql<{ n: unknown }>`select count(*) as n from ai_usage where user_id = ${context.userId} and created_at > now() - interval '1 hour'`;
    if (num(usage[0]?.n) >= 24) return { ok: false as const, error: "rate" };
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "ai_unavailable" };
    const history = await sql<{ role: string; content: string }>`
      select role, content from ai_messages
      where project_id = ${projectId} and user_id = ${context.userId}
      order by created_at desc limit 8`;
    await sql`insert into ai_usage (id, user_id) values (${nid()}, ${context.userId})`;
    await sql`insert into ai_messages (id, project_id, user_id, role, content) values (${nid()}, ${projectId}, ${context.userId}, 'user', ${message})`;
    const files = await filesOf(sql, projectId);
    const packed = files
      .filter((file) => file.kind === "file")
      .slice(0, 14)
      .map((file) => `--- ${file.path}\n${file.content.slice(0, 2800)}`)
      .join("\n")
      .slice(0, 22_000);
    const messages = [
      {
        role: "system",
        content:
          "You are the EST Studio coding assistant. Reply in the user's language (Arabic or English). Return ONLY JSON with keys message (string), edits (array of {path, content} full files), runTests (boolean). Keep edits minimal and valid. No secrets.",
      },
      ...history.reverse().map((item) => ({ role: item.role === "assistant" ? "assistant" : "user", content: item.content.slice(0, 2000) })),
      {
        role: "user",
        content: `Active file: ${activePath || "(none)"}\nBranch: ${String(gate.project.current_branch)}\n\nProject files:\n${packed}\n\n${extra ? `Extra context:\n${extra}\n\n` : ""}Request: ${message}`,
      },
    ];
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model: "grok-4.5", temperature: 0.2, max_tokens: 1800, messages }),
    });
    if (!response.ok) return { ok: false as const, error: "ai_failed" };
    const body = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    const parsed = parseAi(body.choices?.[0]?.message?.content ?? "");
    await sql`insert into ai_messages (id, project_id, user_id, role, content) values (${nid()}, ${projectId}, ${context.userId}, 'assistant', ${parsed.message})`;
    return { ok: true as const, message: parsed.message, edits: parsed.edits, runTests: parsed.runTests };
  });
