import { useEffect, useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { registrationMode } from "@/lib/est/api";
import { errorText, useI18n } from "@/lib/est/i18n";
import { Mark } from "@/components/est/chrome";
import { Button, Field, TextInput, buttonClass } from "@/components/est/ui";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const { t } = useI18n();
  if (isPending) {
    return (
      <div className="grid min-h-dvh place-items-center">
        <div className="h-10 w-28 animate-pulse rounded-md bg-muted" />
      </div>
    );
  }
  if (user) return <Navigate to="/studio" />;
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <section className="hidden flex-col justify-between bg-sidebar p-10 lg:flex">
        <div className="flex items-center gap-2 text-primary">
          <Mark />
          <span className="font-semibold">EST Studio</span>
        </div>
        <div>
          <h1 className="text-balance text-4xl font-semibold text-primary">{t("heroTitle")}</h1>
          <p className="mt-3 max-w-md text-muted-foreground">{t("closed")}</p>
        </div>
        <p className="text-sm text-muted-foreground">EST</p>
      </section>
      <section className="grid place-items-center px-4 py-10">
        <LoginForm />
      </section>
    </div>
  );
}

function LoginForm() {
  const { t } = useI18n();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [inviteOnly, setInviteOnly] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    void registrationMode()
      .then((result) => setInviteOnly(result.inviteOnly))
      .catch(() => setInviteOnly(false));
  }, []);

  const token = typeof window !== "undefined" ? window.sessionStorage.getItem("est.invite") ?? "" : "";

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    if (password.length < 8) {
      setError(t("passwordShort"));
      return;
    }
    if (mode === "up" && inviteOnly && !token) {
      setError(t("err_invite_required"));
      return;
    }
    setBusy(true);
    try {
      if (mode === "up") {
        const result = await authClient.signUp.email({
          email,
          password,
          name: name.trim() || email.split("@")[0] || "EST",
        });
        if (result.error) {
          setError(result.error.message || t("authFailed"));
          return;
        }
      } else {
        const result = await authClient.signIn.email({ email, password });
        if (result.error) {
          setError(result.error.message || t("authFailed"));
          return;
        }
      }
      window.location.href = "/studio";
    } catch {
      setError(t("authFailed"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="w-full max-w-md">
      <Link to="/" className="mb-6 flex items-center gap-2 text-primary lg:hidden">
        <Mark />
        <span className="font-semibold">EST Studio</span>
      </Link>
      <h2 className="text-2xl font-semibold text-primary">{t("loginTitle")}</h2>
      <p className="mt-2 text-sm text-muted-foreground">{t("loginBody")}</p>
      <p className="mt-3 text-sm text-foreground">{inviteOnly ? t("inviteOnly") : t("firstOwner")}</p>
      <div className="mt-5 grid gap-2">
        {GROK_PROVIDERS.map((provider) => (
          <button
            key={provider.providerId}
            type="button"
            className={buttonClass("outline", true)}
            onClick={() => {
              void signIn(provider.providerId, { callbackURL: "/studio" }).catch((reason: unknown) => {
                toast.error(reason instanceof Error ? reason.message : t("authFailed"));
              });
            }}
          >
            {provider.label}
          </button>
        ))}
      </div>
      <form className="mt-5 grid gap-3" onSubmit={submit}>
        {mode === "up" ? (
          <Field label={t("fullName")}>
            <TextInput value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" />
          </Field>
        ) : null}
        <Field label={t("email")}>
          <TextInput type="email" required value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" />
        </Field>
        <Field label={t("password")}>
          <div className="flex gap-2">
            <TextInput
              type={show ? "text" : "password"}
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete={mode === "up" ? "new-password" : "current-password"}
            />
            <Button type="button" variant="ghost" onClick={() => setShow((value) => !value)}>
              {show ? t("hidePassword") : t("showPassword")}
            </Button>
          </div>
        </Field>
        {error ? <p className="text-sm text-danger">{errorText(t, error) === error ? error : errorText(t, error)}</p> : null}
        <Button type="submit" variant="primary" disabled={busy}>
          {busy ? t("working") : mode === "up" ? t("createAccount") : t("signIn")}
        </Button>
      </form>
      <button type="button" className="mt-4 text-sm text-primary" onClick={() => setMode(mode === "in" ? "up" : "in")}>
        {mode === "in" ? t("noAccount") : t("haveAccount")}
      </button>
    </div>
  );
}
