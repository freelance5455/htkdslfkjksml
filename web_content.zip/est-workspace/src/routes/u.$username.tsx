import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { getProfile, updateProfile } from "@/lib/est/api";
import { errorText, useI18n } from "@/lib/est/i18n";
import { AppFrame, RequireUser } from "@/components/est/chrome";
import { Avatar, AvatarEditor, Badge, Button, Field, TextArea, TextInput } from "@/components/est/ui";

export const Route = createFileRoute("/u/$username")({
  component: () => <RequireUser><ProfilePage /></RequireUser>,
});

function ProfilePage() {
  const { username } = Route.useParams();
  const { t } = useI18n();
  const [data, setData] = useState<Extract<Awaited<ReturnType<typeof getProfile>>, { ok: true }> | null>(null);
  const [missing, setMissing] = useState(false);
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState("");
  const [handle, setHandle] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [error, setError] = useState("");

  async function load() {
    const result = await getProfile({ data: { username } });
    if (!result.ok) {
      setMissing(true);
      return;
    }
    setData(result);
    setFullName(result.profile.fullName);
    setHandle(result.profile.username);
    setBio(result.profile.bio);
    setAvatar(result.profile.avatar);
  }

  useEffect(() => {
    void load();
  }, [username]);

  if (missing) return <AppFrame><p>{t("notFound")}</p></AppFrame>;
  if (!data) return <AppFrame><p className="text-muted-foreground">{t("loading")}</p></AppFrame>;

  return (
    <AppFrame>
      <section className="flex flex-wrap items-start gap-4">
        <Avatar name={data.profile.fullName} src={data.profile.avatar} size="lg" />
        <div>
          <h1 className="text-3xl font-semibold text-primary">{data.profile.fullName}</h1>
          <p className="text-muted-foreground" dir="ltr">@{data.profile.username}</p>
          {data.email ? <p className="text-sm text-muted-foreground">{data.email}</p> : null}
          <p className="mt-2 max-w-xl text-sm">{data.profile.bio || t("bioEmpty")}</p>
          <div className="mt-2"><Badge>{t(`role_${data.profile.role}`)}</Badge></div>
          {data.self ? <Button className="mt-3" onClick={() => setEditing((value) => !value)}>{t("editProfile")}</Button> : null}
        </div>
      </section>
      {editing ? (
        <form
          className="mt-6 grid max-w-lg gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            void updateProfile({ data: { fullName, username: handle, bio, avatar: avatar ?? "" } }).then(async (result) => {
              if (!result.ok) {
                setError(errorText(t, result.error));
                return;
              }
              setEditing(false);
              window.location.href = `/u/${handle}`;
            });
          }}
        >
          <Field label={t("fullName")}><TextInput value={fullName} onChange={(event) => setFullName(event.target.value)} /></Field>
          <Field label={t("username")}><TextInput value={handle} onChange={(event) => setHandle(event.target.value.toLowerCase())} dir="ltr" /></Field>
          <Field label={t("bio")}><TextArea value={bio} onChange={(event) => setBio(event.target.value)} /></Field>
          <AvatarEditor value={avatar} onChange={setAvatar} labels={{ avatar: t("avatar"), zoom: t("zoom"), remove: t("removeAvatar") }} />
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button type="submit" variant="primary">{t("saveProfile")}</Button>
        </form>
      ) : null}
      <h2 className="mt-8 text-lg font-semibold text-primary">{t("sharedProjects")}</h2>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {data.projects.map((project) => (
          <Link key={project.id} to="/p/$slug" params={{ slug: project.slug }} className="rounded-xl border border-border bg-card p-4">
            <span className="font-medium text-primary">{project.name}</span>
            <span className="mt-1 block text-sm text-muted-foreground">{t(`role_${project.role}`)}</span>
          </Link>
        ))}
      </div>
    </AppFrame>
  );
}
