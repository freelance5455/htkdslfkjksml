import { createFileRoute, Link } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useI18n } from "@/lib/est/i18n";
import { Mark, ThemeLang } from "@/components/est/chrome";
import { buttonClass, cn } from "@/components/est/ui";

export const Route = createFileRoute("/")({ component: Home });

const features = ["feat1", "feat2", "feat3", "feat4", "feat5", "feat6"] as const;
const steps = ["step1", "step2", "step3", "step4"] as const;

function Home() {
  const { t } = useI18n();
  return (
    <div className="min-h-dvh bg-background">
      <header className="mx-auto flex max-w-5xl flex-wrap items-center gap-3 px-4 py-4">
        <div className="flex items-center gap-2 text-primary">
          <Mark />
          <span className="font-semibold">Studio</span>
        </div>
        <div className="ms-auto">
          <ThemeLang />
        </div>
      </header>
      <main className="mx-auto grid max-w-5xl gap-12 px-4 pb-16 pt-6">
        <section className="grid max-w-3xl gap-4">
          <p className="text-sm font-medium text-primary">{t("heroKicker")}</p>
          <h1 className="text-balance text-4xl font-semibold tracking-tight text-primary md:text-5xl">{t("heroTitle")}</h1>
          <p className="max-w-2xl text-lg text-muted-foreground">{t("heroBody")}</p>
          <div className="flex flex-wrap gap-2">
            <Enter />
          </div>
          <p className="text-sm text-muted-foreground">{t("closed")}</p>
        </section>
        <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((key) => (
            <article key={key} className="rounded-xl border border-border bg-card p-4">
              <h2 className="font-semibold text-primary">{t(key)}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{t(`${key}b`)}</p>
            </article>
          ))}
        </section>
        <section className="grid gap-4">
          <h2 className="text-2xl font-semibold text-primary">{t("howTitle")}</h2>
          <ol className="grid gap-3 md:grid-cols-4">
            {steps.map((key, index) => (
              <li key={key} className="rounded-xl border border-border bg-sidebar p-4">
                <span className="text-sm tabular-nums text-primary">{index + 1}</span>
                <h3 className="mt-2 font-medium">{t(key)}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{t(`${key}b`)}</p>
              </li>
            ))}
          </ol>
        </section>
      </main>
    </div>
  );
}

function Enter() {
  const { user, isPending } = useCurrentUserState();
  const { t } = useI18n();
  if (isPending) return <div className="h-11 w-40 animate-pulse rounded-md bg-muted" />;
  return (
    <Link to={user ? "/studio" : "/login"} className={cn(buttonClass("primary"))}>
      {user ? t("enter") : t("signIn")}
    </Link>
  );
}
