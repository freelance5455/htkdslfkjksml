import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { PrefsSync } from "@/components/est/chrome";
import { usePrefs } from "@/lib/est/prefs";
import appCss from "../styles.css?url";

const APP_NAME = "EST Studio";

function EstToaster() {
  const theme = usePrefs((state) => state.theme);
  return <Toaster theme={theme} position="top-center" />;
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "description", content: "EST Studio — منصة التطوير التعاونية لفريق EST" },
      { name: "theme-color", content: "#f5f7fa" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Arabic:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <HeadContent />
        <script
          dangerouslySetInnerHTML={{
            __html:
              "(function(){try{var t=localStorage.getItem('est-theme');if(t==='dark')document.documentElement.classList.add('dark');var l=localStorage.getItem('est-lang')||'ar';document.documentElement.lang=l;document.documentElement.dir=l==='ar'?'rtl':'ltr';}catch(e){}})();",
          }}
        />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <PrefsSync />
          <Outlet />
          <EstToaster />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
