import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { createTeamChannel, listChannels, listMessages, openDm, postMessage } from "@/lib/est/api";
import { applyMention, mentionQuery } from "@/lib/est/domain";
import { errorText, useI18n } from "@/lib/est/i18n";
import { AppFrame, RequireUser } from "@/components/est/chrome";
import { Avatar, Button, MentionText, TextArea, TextInput } from "@/components/est/ui";

export const Route = createFileRoute("/inbox")({ component: () => <RequireUser><InboxPage /></RequireUser> });

type Channel = Extract<Awaited<ReturnType<typeof listChannels>>, { ok: true }>["channels"][number];
type Message = Extract<Awaited<ReturnType<typeof listMessages>>, { ok: true }>["messages"][number];

function InboxPage() {
  const { t } = useI18n();
  const [channels, setChannels] = useState<Channel[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState("");
  const [thread, setThread] = useState<string | null>(null);
  const [username, setUsername] = useState("");
  const [channelName, setChannelName] = useState("");
  const [role, setRole] = useState("developer");

  async function refreshChannels(select = active) {
    const result = await listChannels();
    if (!result.ok) return;
    setChannels(result.channels);
    setRole(result.role);
    const next = select && result.channels.some((channel) => channel.id === select) ? select : result.channels[0]?.id ?? null;
    setActive(next);
  }

  useEffect(() => {
    void refreshChannels(null);
    const timer = window.setInterval(() => void refreshChannels(), 5000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!active) return;
    let stop = false;
    const pull = () => {
      void listMessages({ data: { channelId: active } }).then((result) => {
        if (!stop && result.ok) setMessages(result.messages);
      });
    };
    pull();
    const timer = window.setInterval(pull, 3000);
    return () => {
      stop = true;
      window.clearInterval(timer);
    };
  }, [active]);

  const roots = messages.filter((message) => !message.parentId);
  const replies = useMemo(() => messages.filter((message) => message.parentId === thread), [messages, thread]);
  const query = mentionQuery(body);
  const names = useMemo(() => {
    const found = new Set<string>();
    for (const message of messages) found.add(message.username);
    return [...found];
  }, [messages]);
  const suggestions = query == null ? [] : names.filter((name) => name.startsWith(query)).slice(0, 6);

  async function send(parentId?: string) {
    if (!active || !body.trim()) return;
    const result = await postMessage({ data: { channelId: active, body, parentId: parentId ?? "" } });
    if (!result.ok) {
      toast.error(errorText(t, result.error));
      return;
    }
    setBody("");
    const next = await listMessages({ data: { channelId: active } });
    if (next.ok) setMessages(next.messages);
  }

  return (
    <AppFrame>
      <h1 className="text-3xl font-semibold text-primary">{t("inbox")}</h1>
      <div className="mt-4 grid gap-4 lg:grid-cols-[16rem_1fr]">
        <aside className="grid content-start gap-2">
          <form
            className="flex gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              void openDm({ data: { username: username.trim().toLowerCase() } }).then(async (result) => {
                if (!result.ok) {
                  toast.error(errorText(t, result.error === "self" ? "self" : result.error));
                  return;
                }
                setUsername("");
                await refreshChannels(result.channelId);
              });
            }}
          >
            <input
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              placeholder={t("openDm")}
              className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
              dir="ltr"
            />
          </form>
          {role === "owner" || role === "admin" ? (
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void createTeamChannel({ data: { name: channelName } }).then(async (result) => {
                  if (!result.ok) {
                    toast.error(errorText(t, result.error));
                    return;
                  }
                  setChannelName("");
                  await refreshChannels(result.channelId);
                });
              }}
            >
              <TextInput value={channelName} onChange={(event) => setChannelName(event.target.value)} placeholder={t("channelName")} />
              <Button type="submit" variant="primary">{t("newChannel")}</Button>
            </form>
          ) : null}
          {channels.map((channel) => (
            <button
              key={channel.id}
              type="button"
              onClick={() => { setActive(channel.id); setThread(null); }}
              className={`rounded-lg px-3 py-2 text-start ${active === channel.id ? "bg-accent text-primary" : "hover:bg-muted"}`}
            >
              <span className="block text-sm font-medium">{channel.title}</span>
              <span className="text-xs text-muted-foreground">{channel.kind === "dm" ? t("direct") : channel.kind === "team" ? t("general") : t("projects")}</span>
              {channel.unread ? <span className="ms-2 text-xs tabular-nums text-primary">{channel.unread}</span> : null}
            </button>
          ))}
        </aside>
        <section className="flex min-h-[60dvh] flex-col rounded-xl border border-border bg-card">
          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {roots.length === 0 ? <p className="text-sm text-muted-foreground">{t("noMessages")}</p> : null}
            {roots.map((message) => (
              <article key={message.id} className="grid grid-cols-[auto_1fr] gap-2">
                <Avatar name={message.fullName} src={message.avatar} size="sm" />
                <div>
                  <p className="text-sm font-medium">{message.fullName} <span className="text-muted-foreground" dir="ltr">@{message.username}</span></p>
                  <p className="whitespace-pre-wrap text-sm"><MentionText body={message.body} /></p>
                  <button type="button" className="mt-1 text-xs text-primary" onClick={() => setThread(message.id)}>{t("reply")}</button>
                </div>
              </article>
            ))}
            {thread ? (
              <div className="rounded-lg border border-border bg-sidebar p-3">
                <p className="text-sm font-medium text-primary">{t("thread")}</p>
                {replies.map((message) => (
                  <p key={message.id} className="mt-2 text-sm"><span className="font-medium">{message.fullName}: </span>{message.body}</p>
                ))}
                <div className="mt-2 flex gap-2">
                  <TextArea value={body} onChange={(event) => setBody(event.target.value)} placeholder={t("writeMessage")} />
                </div>
                <Button className="mt-2" variant="primary" onClick={() => void send(thread)}>{t("send")}</Button>
              </div>
            ) : null}
          </div>
          {!thread ? (
            <form
              className="grid gap-2 border-t border-border p-3"
              onSubmit={(event) => {
                event.preventDefault();
                void send();
              }}
            >
              {suggestions.length ? (
                <div className="flex flex-wrap gap-1">
                  {suggestions.map((name) => (
                    <button key={name} type="button" className="rounded-md bg-accent px-2 py-1 text-xs text-primary" onClick={() => setBody(applyMention(body, name))}>
                      @{name}
                    </button>
                  ))}
                </div>
              ) : null}
              <div className="flex gap-2">
                <TextArea value={body} onChange={(event) => setBody(event.target.value)} placeholder={t("writeMessage")} />
                <Button type="submit" variant="primary">{t("send")}</Button>
              </div>
            </form>
          ) : null}
        </section>
      </div>
    </AppFrame>
  );
}
