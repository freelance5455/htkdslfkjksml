import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { getLive } from "@/lib/est/api";
import { buildPreviewDoc, parseSnapshot } from "@/lib/est/domain";
import { useI18n } from "@/lib/est/i18n";
import { RequireUser } from "@/components/est/chrome";
import { buttonClass } from "@/components/est/ui";

export const Route = createFileRoute("/live/$slug")({
  component: () => <RequireUser><LivePage /></RequireUser>,
});

function LivePage() {
  const { slug } = Route.useParams();
  const { t } = useI18n();
  const [doc, setDoc] = useState<string | null>(null);
  const [name, setName] = useState(slug);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    void getLive({ data: { slug } }).then((result) => {
      if (!result.ok) {
        setMissing(true);
        return;
      }
      setName(result.name);
      setDoc(buildPreviewDoc(parseSnapshot(result.snapshot)));
    });
  }, [slug]);

  return (
    <div className="flex h-dvh flex-col bg-background">
      <header className="flex items-center gap-3 border-b border-border px-4 py-3">
        <Link to="/p/$slug" params={{ slug }} className={buttonClass("ghost")}>{t("back")}</Link>
        <h1 className="font-semibold text-primary">{name}</h1>
        <span className="text-sm text-ok">{t("live")}</span>
      </header>
      {missing ? <p className="p-6 text-muted-foreground">{t("noDeploys")}</p> : null}
      {doc ? <iframe title={name} sandbox="allow-scripts" srcDoc={doc} className="min-h-0 w-full flex-1 bg-card" /> : null}
    </div>
  );
}
