import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { addProjectMember, createInvite, getAudit, getTeam, revokeInvite, setOrgRole } from "@/lib/est/api";
import { ROLES, type Role } from "@/lib/est/domain";
import { errorText, useI18n } from "@/lib/est/i18n";
import { AppFrame, RequireUser } from "@/components/est/chrome";
import { Avatar, Badge, Button, Field, TextInput } from "@/components/est/ui";

export const Route = createFileRoute("/team")({ component: () => <RequireUser><TeamPage /></RequireUser> });

type Team = Extract<Awaited<ReturnType<typeof getTeam>>, { ok: true }>;

function TeamPage() {
  const { t } = useI18n();
  const [team, setTeam] = useState<Team | null>(null);
  const [audit, setAudit] = useState<Extract<Awaited<ReturnType<typeof getAudit>>, { ok: true }> | null>(null);
  const [role, setRole] = useState<Role>("developer");
  const [username, setUsername] = useState("");
  const [projectId, setProjectId] = useState("");
  const [memberRole, setMemberRole] = useState<Role>("developer");

  async function refresh() {
    const next = await getTeam();
    if (!next.ok) return;
    setTeam(next);
    if (!projectId && next.projects[0]) setProjectId(next.projects[0].id);
    if (next.me.role === "owner" || next.me.role === "admin") {
      const log = await getAudit();
      if (log.ok) setAudit(log);
    }
  }

  useEffect(() => {
    void refresh();
  }, []);

  if (!team) return <AppFrame><p className="text-muted-foreground">{t("loading")}</p></AppFrame>;
  const admin = team.me.role === "owner" || team.me.role === "admin";

  return (
    <AppFrame>
      <h1 className="text-3xl font-semibold text-primary">{t("team")}</h1>
      <div className="mt-6 grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <section className="grid gap-2">
          {team.members.map((member) => (
            <article key={member.userId} className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card p-3">
              <Avatar name={member.fullName} src={member.avatar} />
              <div className="min-w-0 flex-1">
                <Link to="/u/$username" params={{ username: member.username }} className="font-medium text-primary">{member.fullName}</Link>
                <p className="text-sm text-muted-foreground" dir="ltr">@{member.username}</p>
              </div>
              {admin && member.userId !== team.me.userId && (team.me.role === "owner" || (member.role !== "owner" && member.role !== "admin")) ? (
                <select
                  className="h-11 rounded-md border border-border bg-card px-2 text-sm"
                  value={member.role}
                  onChange={(event) => {
                    const next = event.target.value as Role;
                    void setOrgRole({ data: { userId: member.userId, role: next } }).then((result) => {
                      if (!result.ok) toast.error(errorText(t, result.error));
                      else void refresh();
                    });
                  }}
                >
                  {ROLES.filter((item) => team.me.role === "owner" || (item !== "owner" && item !== "admin")).map((item) => (
                    <option key={item} value={item}>{t(`role_${item}`)}</option>
                  ))}
                </select>
              ) : (
                <Badge>{t(`role_${member.role}`)}</Badge>
              )}
            </article>
          ))}
        </section>
        <div className="grid gap-4 content-start">
          {admin ? (
            <section className="rounded-xl border border-border bg-card p-4">
              <h2 className="font-semibold text-primary">{t("invites")}</h2>
              <form
                className="mt-3 flex gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  void createInvite({ data: { role } }).then(async (result) => {
                    if (!result.ok) {
                      toast.error(errorText(t, result.error));
                      return;
                    }
                    const link = `${window.location.origin}/join/${result.token}`;
                    await navigator.clipboard.writeText(link);
                    toast.success(t("copied"));
                    void refresh();
                  });
                }}
              >
                <select className="h-11 flex-1 rounded-md border border-border bg-card px-2" value={role} onChange={(event) => setRole(event.target.value as Role)}>
                  {(team.me.role === "owner" ? ["admin", "developer", "viewer"] : ["developer", "viewer"]).map((item) => (
                    <option key={item} value={item}>{t(`role_${item}`)}</option>
                  ))}
                </select>
                <Button type="submit" variant="primary">{t("createInvite")}</Button>
              </form>
              <ul className="mt-3 grid gap-2">
                {team.invites.length === 0 ? <li className="text-sm text-muted-foreground">{t("noInvites")}</li> : null}
                {team.invites.map((invite) => (
                  <li key={invite.id} className="flex items-center justify-between gap-2 text-sm">
                    <button
                      type="button"
                      className="truncate text-primary"
                      dir="ltr"
                      onClick={() => {
                        void navigator.clipboard.writeText(`${window.location.origin}/join/${invite.token}`);
                        toast.success(t("copied"));
                      }}
                    >
                      {t(`role_${invite.role}`)} · {t("copyLink")}
                    </button>
                    <Button variant="danger" className="h-9" onClick={() => void revokeInvite({ data: { id: invite.id } }).then(() => refresh())}>{t("revoke")}</Button>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
          {admin && team.projects.length ? (
            <section className="rounded-xl border border-border bg-card p-4">
              <h2 className="font-semibold text-primary">{t("addMember")}</h2>
              <form
                className="mt-3 grid gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  void addProjectMember({ data: { projectId, username, role: memberRole } }).then((result) => {
                    if (!result.ok) toast.error(errorText(t, result.error));
                    else {
                      setUsername("");
                      toast.success(t("copied"));
                    }
                  });
                }}
              >
                <Field label={t("username")}>
                  <TextInput value={username} onChange={(event) => setUsername(event.target.value.toLowerCase())} dir="ltr" required />
                </Field>
                <select className="h-11 rounded-md border border-border bg-card px-2" value={projectId} onChange={(event) => setProjectId(event.target.value)}>
                  {team.projects.map((project) => <option key={project.id} value={project.id}>{project.name}</option>)}
                </select>
                <select className="h-11 rounded-md border border-border bg-card px-2" value={memberRole} onChange={(event) => setMemberRole(event.target.value as Role)}>
                  {["admin", "developer", "viewer"].map((item) => <option key={item} value={item}>{t(`role_${item}`)}</option>)}
                </select>
                <Button type="submit" variant="primary">{t("addMember")}</Button>
              </form>
            </section>
          ) : null}
        </div>
      </div>
      {audit ? (
        <section className="mt-6">
          <h2 className="mb-3 text-lg font-semibold text-primary">{t("audit")}</h2>
          <div className="overflow-x-auto rounded-xl border border-border">
            <table className="w-full min-w-[36rem] text-sm">
              <thead className="bg-sidebar text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 text-start font-medium">{t("when")}</th>
                  <th className="px-3 py-2 text-start font-medium">{t("by")}</th>
                  <th className="px-3 py-2 text-start font-medium">{t("action")}</th>
                  <th className="px-3 py-2 text-start font-medium">{t("target")}</th>
                </tr>
              </thead>
              <tbody>
                {audit.entries.length === 0 ? (
                  <tr><td className="px-3 py-3 text-muted-foreground" colSpan={4}>{t("auditEmpty")}</td></tr>
                ) : audit.entries.map((entry, index) => (
                  <tr key={`${entry.at}-${index}`} className="border-t border-border">
                    <td className="px-3 py-2 tabular-nums text-muted-foreground">{new Date(entry.at).toLocaleString()}</td>
                    <td className="px-3 py-2">{entry.name}</td>
                    <td className="px-3 py-2">{entry.action}</td>
                    <td className="px-3 py-2">{entry.target}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
    </AppFrame>
  );
}
