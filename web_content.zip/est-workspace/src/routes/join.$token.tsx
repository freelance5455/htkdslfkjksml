import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/est/i18n";
import { Mark } from "@/components/est/chrome";
import { buttonClass } from "@/components/est/ui";

export const Route = createFileRoute("/join/$token")({ component: JoinPage });

function JoinPage() {
  const { token } = Route.useParams();
  const { t } = useI18n();
  useEffect(() => {
    window.sessionStorage.setItem("est.invite", token);
  }, [token]);
  return (
    <main className="grid min-h-dvh place-items-center px-4">
      <div className="w-full max-w-md rounded-xl border border-border bg-card p-6">
        <div className="flex items-center gap-2 text-primary">
          <Mark />
          <h1 className="text-xl font-semibold">{t("joined")}</h1>
        </div>
        <p className="mt-3 text-sm text-muted-foreground">{t("closed")}</p>
        <p className="mt-3 font-mono text-sm text-foreground" dir="ltr">
          {token}
        </p>
        <Link to="/login" className={`${buttonClass("primary")} mt-5`}>
          {t("continue")}
        </Link>
      </div>
    </main>
  );
}
