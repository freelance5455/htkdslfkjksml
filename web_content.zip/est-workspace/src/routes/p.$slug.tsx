import { createFileRoute } from "@tanstack/react-router";
import { RequireUser } from "@/components/est/chrome";
import { ProjectIde } from "@/components/est/ide";

export const Route = createFileRoute("/p/$slug")({
  component: ProjectRoute,
});

function ProjectRoute() {
  const { slug } = Route.useParams();
  return (
    <RequireUser>
      <ProjectIde slug={slug} />
    </RequireUser>
  );
}
