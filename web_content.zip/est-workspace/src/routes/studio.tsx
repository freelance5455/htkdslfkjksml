import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts";
import { completeOnboarding, createProject, getMe, getStats } from "@/lib/est/api";
import { TEMPLATE_IDS } from "@/lib/est/domain";
import { errorText, useI18n } from "@/lib/est/i18n";
import { AppFrame, RequireUser } from "@/components/est/chrome";
import { AvatarEditor, Badge, Button, Field, Modal, TextArea, TextInput } from "@/components/est/ui";

export const Route = createFileRoute("/studio")({ component: () => <RequireUser><Studio /></RequireUser> });

type Me = Awaited<ReturnType<typeof getMe>>;
type Stats = Awaited<ReturnType<typeof getStats>>;

function Studio() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [me, setMe] = useState<Me | null>(null);
  const [stats, setStats] = useState<Extract<Stats, { ok: true }> | null>(null);
  const [open, setOpen] = useState(false);

  async function refresh() {
    const next = await getMe();
    setMe(next);
    if (next.profile) {
      const pulse = await getStats();
      if (pulse.ok) setStats(pulse);
    }
  }

  useEffect(() => {
    void refresh().catch(() => toast.error(t("saveFailed")));
  }, []);

  if (!me) return <AppFrame><p className="text-muted-foreground">{t("loading")}</p></AppFrame>;
  if (!me.profile) {
    return (
      <AppFrame>
        <Onboarding canBootstrap={me.canBootstrap} onDone={() => void refresh()} />
      </AppFrame>
    );
  }

  const profile = me.profile;
  return (
    <AppFrame>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm text-muted-foreground">{t("welcome")}</p>
          <h1 className="text-3xl font-semibold text-primary">{profile.fullName}</h1>
        </div>
        {profile.role !== "viewer" ? (
          <Button variant="primary" onClick={() => setOpen(true)}>{t("newProject")}</Button>
        ) : null}
      </div>
      {stats ? (
        <section className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label={t("projectCount")} value={stats.projects} />
          <Stat label={t("memberCount")} value={stats.members} />
          <Stat label={t("openTasks")} value={stats.openTasks} />
          <Stat label={t("liveDeploys")} value={stats.liveDeploys} />
        </section>
      ) : null}
      <div className="mt-6 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <section>
          <h2 className="mb-3 text-lg font-semibold text-primary">{t("projects")}</h2>
          {me.projects.length === 0 ? (
            <div className="rounded-xl border border-border bg-card p-5">
              <p className="font-medium">{t("emptyProjects")}</p>
              <p className="mt-1 text-sm text-muted-foreground">{t("createFirst")}</p>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {me.projects.map((project) => (
                <Link key={project.id} to="/p/$slug" params={{ slug: project.slug }} className="rounded-xl border border-border bg-card p-4 hover:bg-accent">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-semibold text-primary">{project.name}</h3>
                    <Badge>{t(`template_${project.template}`)}</Badge>
                  </div>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{project.description || project.branch}</p>
                  <p className="mt-3 text-xs text-muted-foreground">{t(`role_${project.role}`)} · {project.branch}</p>
                </Link>
              ))}
            </div>
          )}
        </section>
        <section className="rounded-xl border border-border bg-card p-4">
          <h2 className="font-semibold text-primary">{t("stats")}</h2>
          {stats && stats.commits.length ? (
            <div className="mt-3 h-40">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.commits}>
                  <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="var(--muted-foreground)" />
                  <YAxis allowDecimals={false} width={24} tick={{ fontSize: 12 }} stroke="var(--muted-foreground)" />
                  <Bar dataKey="count" fill="var(--primary)" radius={4} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="mt-3 text-sm text-muted-foreground">{t("chartEmpty")}</p>
          )}
          <h3 className="mt-4 text-sm font-medium">{t("activity")}</h3>
          <ul className="mt-2 grid gap-2">
            {stats?.activity.length ? stats.activity.map((item, index) => (
              <li key={`${item.at}-${index}`} className="text-sm">
                <span className="text-foreground">{item.name || t("you")}</span>
                <span className="text-muted-foreground"> · {item.action}</span>
              </li>
            )) : <li className="text-sm text-muted-foreground">{t("noActivity")}</li>}
          </ul>
        </section>
      </div>
      <NewProject
        open={open}
        onOpenChange={setOpen}
        onCreated={(slug) => void navigate({ to: "/p/$slug", params: { slug } })}
      />
    </AppFrame>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums text-primary">{value}</p>
    </div>
  );
}

function Onboarding({ canBootstrap, onDone }: { canBootstrap: boolean; onDone: () => void }) {
  const { t } = useI18n();
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setToken(window.sessionStorage.getItem("est.invite") ?? "");
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const result = await completeOnboarding({ data: { fullName, username, bio, avatar: avatar ?? "", inviteToken: token } });
    setBusy(false);
    if (!result.ok) {
      setError(errorText(t, result.error));
      return;
    }
    window.sessionStorage.removeItem("est.invite");
    onDone();
  }

  return (
    <form className="mx-auto grid max-w-lg gap-4" onSubmit={submit}>
      <div>
        <h1 className="text-3xl font-semibold text-primary">{t("onboardTitle")}</h1>
        <p className="mt-2 text-sm text-muted-foreground">{canBootstrap ? t("firstOwner") : t("onboardBody")}</p>
      </div>
      <Field label={t("fullName")}>
        <TextInput required value={fullName} onChange={(event) => setFullName(event.target.value)} />
      </Field>
      <Field label={t("username")} hint={t("usernameHint")}>
        <TextInput required value={username} onChange={(event) => setUsername(event.target.value.toLowerCase())} dir="ltr" />
      </Field>
      <Field label={t("bio")}>
        <TextArea value={bio} maxLength={280} onChange={(event) => setBio(event.target.value)} />
      </Field>
      <AvatarEditor value={avatar} onChange={setAvatar} labels={{ avatar: t("avatar"), zoom: t("zoom"), remove: t("removeAvatar") }} />
      {!canBootstrap ? (
        <Field label={t("inviteToken")}>
          <TextInput value={token} onChange={(event) => setToken(event.target.value)} dir="ltr" />
        </Field>
      ) : null}
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Button type="submit" variant="primary" disabled={busy}>{busy ? t("working") : t("saveProfile")}</Button>
    </form>
  );
}

export function NewProject({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (open: boolean) => void; onCreated: (slug: string) => void }) {
  const { t } = useI18n();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [template, setTemplate] = useState<(typeof TEMPLATE_IDS)[number]>("react");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const result = await createProject({ data: { name, description, template } });
    setBusy(false);
    if (!result.ok) {
      setError(errorText(t, result.error));
      return;
    }
    onOpenChange(false);
    onCreated(result.slug);
  }

  return (
    <Modal open={open} onOpenChange={onOpenChange} title={t("newProject")}>
      <form className="grid gap-3" onSubmit={submit}>
        <Field label={t("name")}>
          <TextInput required value={name} onChange={(event) => setName(event.target.value)} />
        </Field>
        <Field label={t("description")}>
          <TextArea value={description} onChange={(event) => setDescription(event.target.value)} />
        </Field>
        <div className="grid gap-2">
          {TEMPLATE_IDS.map((id) => (
            <button
              key={id}
              type="button"
              onClick={() => setTemplate(id)}
              className={`rounded-lg border px-3 py-2 text-start ${template === id ? "border-primary bg-accent" : "border-border bg-card"}`}
            >
              <span className="font-medium text-primary">{t(`template_${id}`)}</span>
              <span className="mt-1 block text-sm text-muted-foreground">{t(`template_${id}_b`)}</span>
            </button>
          ))}
        </div>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <div className="flex justify-end gap-2">
          <Button type="button" onClick={() => onOpenChange(false)}>{t("cancel")}</Button>
          <Button type="submit" variant="primary" disabled={busy}>{t("create")}</Button>
        </div>
      </form>
    </Modal>
  );
}
