import { useEffect, useMemo, useRef, useState, type ComponentType } from "react";
import { Link } from "@tanstack/react-router";
import { Group, Panel, Separator } from "react-resizable-panels";
import { toast } from "sonner";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import {
  askAi,
  assignFile,
  createBackup,
  createPath,
  deletePath,
  getProject,
  gitBranch,
  gitCheckout,
  gitCommit,
  gitMerge,
  listMessages,
  moveTask,
  postMessage,
  publishDeploy,
  renamePath,
  restoreBackup,
  reviewComment,
  reviewDiff,
  saveFile,
  saveReview,
  saveTask,
  setReviewStatus,
  syncProject,
  unlockFile,
} from "@/lib/est/api";
import {
  applyMention,
  buildPreviewDoc,
  diagnose,
  execTerminal,
  gitStatus,
  languageFromPath,
  mentionQuery,
  runProjectTests,
  traceJavaScript,
  type SnapFile,
} from "@/lib/est/domain";
import { formatSource } from "@/lib/est/format";
import { errorText, useI18n } from "@/lib/est/i18n";
import { usePrefs } from "@/lib/est/prefs";
import { Mark, ThemeLang, useOnline } from "@/components/est/chrome";
import { Avatar, Button, MentionText, buttonClass } from "@/components/est/ui";

type Loaded = Extract<Awaited<ReturnType<typeof getProject>>, { ok: true }>;
type FileRow = Loaded["files"][number];
type EditorProps = {
  path: string;
  value: string;
  language: string;
  dark: boolean;
  readOnly: boolean;
  peers: { id: string; name: string; line: number }[];
  breakpoints: number[];
  revealLine: number;
  onChange: (value: string) => void;
  onCursor: (line: number) => void;
  onToggleBreakpoint: (line: number) => void;
};

const COLUMNS = ["todo", "doing", "review", "done"] as const;

export function ProjectIde({ slug }: { slug: string }) {
  const { t } = useI18n();
  const user = useCurrentUser();
  const theme = usePrefs((state) => state.theme);
  const online = useOnline();
  const [data, setData] = useState<Loaded | null>(null);
  const [error, setError] = useState("");
  const [files, setFiles] = useState<FileRow[]>([]);
  const [head, setHead] = useState<SnapFile[]>([]);
  const [open, setOpen] = useState<string[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [split, setSplit] = useState<string | null>(null);
  const [dirty, setDirty] = useState<Record<string, boolean>>({});
  const [filter, setFilter] = useState("");
  const [side, setSide] = useState<"preview" | "chat" | "ai" | "tasks" | "git" | "review">("preview");
  const [bottom, setBottom] = useState<"terminal" | "problems" | "debug">("terminal");
  const [showBottom, setShowBottom] = useState(true);
  const [pane, setPane] = useState<"code" | "files" | "side" | "term">("code");
  const [wide, setWide] = useState(false);
  const [presence, setPresence] = useState<Extract<Awaited<ReturnType<typeof syncProject>>, { ok: true }>["presence"]>([]);
  const [status, setStatus] = useState("saved");
  const [conflict, setConflict] = useState<{ path: string; mine: string; theirs: string } | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [term, setTerm] = useState<string[]>(["EST terminal — help"]);
  const [cwd, setCwd] = useState("");
  const [line, setLine] = useState(1);
  const [cmd, setCmd] = useState("");
  const [messages, setMessages] = useState<Extract<Awaited<ReturnType<typeof listMessages>>, { ok: true }>["messages"]>([]);
  const [draft, setDraft] = useState("");
  const [thread, setThread] = useState<string | null>(null);
  const [aiText, setAiText] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [proposals, setProposals] = useState<{ path: string; content: string }[]>([]);
  const [aiLog, setAiLog] = useState<{ role: string; content: string }[]>([]);
  const [pathDraft, setPathDraft] = useState("");
  const [pathKind, setPathKind] = useState<"file" | "dir">("file");
  const [commitMsg, setCommitMsg] = useState("");
  const [branchName, setBranchName] = useState("");
  const [mergeFrom, setMergeFrom] = useState("main");
  const [taskTitle, setTaskTitle] = useState("");
  const [reviewTitle, setReviewTitle] = useState("");
  const [reviewBranch, setReviewBranch] = useState("main");
  const [activeReview, setActiveReview] = useState<string | null>(null);
  const [diffs, setDiffs] = useState<{ path: string; before: string; after: string; status: string }[]>([]);
  const [comment, setComment] = useState("");
  const [deploying, setDeploying] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [paletteQuery, setPaletteQuery] = useState("");
  const [breaks, setBreaks] = useState<Record<string, number[]>>({});
  const [reveal, setReveal] = useState(0);
  const [Editor, setEditor] = useState<ComponentType<EditorProps> | null>(null);

  const filesRef = useRef(files);
  const dirtyRef = useRef(dirty);
  const activeRef = useRef(active);
  const lineRef = useRef(line);
  const dataRef = useRef(data);
  const timers = useRef<Record<string, number>>({});
  filesRef.current = files;
  dirtyRef.current = dirty;
  activeRef.current = active;
  lineRef.current = line;
  dataRef.current = data;

  useEffect(() => {
    const media = window.matchMedia("(min-width: 1024px)");
    const apply = () => setWide(media.matches);
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, []);

  useEffect(() => {
    void import("@/components/est/monaco-host").then((mod) => setEditor(() => mod.MonacoHost));
  }, []);

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      const payload = event.data as { source?: string; level?: string; args?: string[] };
      if (payload?.source !== "est-preview") return;
      setLogs((items) => [...items.slice(-60), `${payload.level ?? "log"}: ${(payload.args ?? []).join(" ")}`]);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  async function load(full = false) {
    const result = await getProject({ data: { slug } });
    if (!result.ok) {
      setError(result.error || "invalid");
      return;
    }
    setError("");
    setData(result);
    setFiles(result.files);
    setHead(result.head);
    setAiLog(result.ai.map((item) => ({ role: item.role, content: item.content })));
    if (full || !activeRef.current) {
      const first = result.files.find((file) => file.kind === "file");
      if (first) {
        setOpen([first.path]);
        setActive(first.path);
      }
    }
  }

  useEffect(() => {
    void load(true);
  }, [slug]);

  useEffect(() => {
    if (!data) return;
    const timer = window.setInterval(() => {
      const current = dataRef.current;
      if (!current || !navigator.onLine) return;
      const versions: Record<string, number> = {};
      for (const file of filesRef.current) versions[file.path] = file.updatedAt;
      void syncProject({
        data: {
          projectId: current.project.id,
          versions,
          filePath: activeRef.current ?? "",
          line: lineRef.current,
        },
      }).then((result) => {
        if (!result.ok) return;
        setPresence(result.presence);
        setFiles((currentFiles) =>
          currentFiles.map((file) => {
            const header = result.headers.find((item) => item.path === file.path);
            const changed = result.changed.find((item) => item.path === file.path);
            if (changed && !dirtyRef.current[file.path]) {
              return {
                ...file,
                content: changed.content,
                updatedAt: changed.updatedAt,
                updatedBy: changed.updatedBy,
                lockedBy: header?.lockedBy ?? null,
                lockedAt: header?.lockedAt ?? null,
                assigneeId: header?.assigneeId ?? file.assigneeId,
              };
            }
            if (!header) return file;
            return { ...file, lockedBy: header.lockedBy, lockedAt: header.lockedAt, assigneeId: header.assigneeId };
          }),
        );
      });
    }, 2500);
    return () => window.clearInterval(timer);
  }, [data?.project.id]);

  useEffect(() => {
    if (!data?.channelId) return;
    const pull = () => {
      void listMessages({ data: { channelId: data.channelId as string } }).then((result) => {
        if (result.ok) setMessages(result.messages);
      });
    };
    pull();
    const timer = window.setInterval(pull, 3000);
    return () => window.clearInterval(timer);
  }, [data?.channelId]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        const path = activeRef.current;
        const file = filesRef.current.find((item) => item.path === path);
        if (path && file) void persist(path, file.content, file.updatedAt);
      }
      if ((event.metaKey || event.ctrlKey) && (event.key.toLowerCase() === "k" || event.key.toLowerCase() === "p")) {
        event.preventDefault();
        setPaletteOpen(true);
      }
      if (event.key === "Escape") setPaletteOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!data) return;
    let stop = false;
    const flush = async () => {
      if (!navigator.onLine) return;
      const raw = localStorage.getItem("est.pending");
      if (!raw) return;
      let pending: { projectId: string; path: string; content: string; baseUpdatedAt: number | null }[] = [];
      try {
        pending = JSON.parse(raw) as typeof pending;
      } catch {
        return;
      }
      const mine = pending.filter((item) => item.projectId === data.project.id);
      if (!mine.length) return;
      const rest = pending.filter((item) => item.projectId !== data.project.id);
      const kept = [...rest];
      for (const item of mine) {
        if (stop) return;
        const result = await saveFile({
          data: { projectId: item.projectId, path: item.path, content: item.content, baseUpdatedAt: item.baseUpdatedAt },
        });
        if (!result.ok) kept.push(item);
      }
      localStorage.setItem("est.pending", JSON.stringify(kept.slice(-30)));
      if (!stop) {
        setStatus("saved");
        await load(false);
      }
    };
    void flush();
    window.addEventListener("online", flush);
    return () => {
      stop = true;
      window.removeEventListener("online", flush);
    };
  }, [data?.project.id]);

  async function persist(path: string, content: string, base: number | null) {
    const current = dataRef.current;
    if (!current) return;
    if (!navigator.onLine) {
      queue(current.project.id, path, content, base);
      setStatus("offline");
      return;
    }
    setStatus("saving");
    try {
      const result = await saveFile({ data: { projectId: current.project.id, path, content, baseUpdatedAt: base } });
      if (!result.ok && result.error === "conflict" && "serverContent" in result) {
        setConflict({ path, mine: content, theirs: String(result.serverContent ?? "") });
        setStatus("conflict");
        return;
      }
      if (!result.ok) {
        toast.error(errorText(t, result.error));
        setStatus("unsaved");
        return;
      }
      setDirty((map) => ({ ...map, [path]: false }));
      setFiles((items) => items.map((file) => (file.path === path ? { ...file, content, updatedAt: result.updatedAt } : file)));
      setStatus("saved");
    } catch {
      queue(current.project.id, path, content, base);
      setStatus("offline");
    }
  }

  function updateFile(path: string, content: string) {
    setFiles((items) => items.map((file) => (file.path === path ? { ...file, content } : file)));
    setDirty((map) => ({ ...map, [path]: true }));
    setStatus("unsaved");
    window.clearTimeout(timers.current[path]);
    timers.current[path] = window.setTimeout(() => {
      const file = filesRef.current.find((item) => item.path === path);
      void persist(path, content, file?.updatedAt ?? null);
    }, 900);
  }

  const canEdit = data ? data.role !== "viewer" : false;
  const activeFile = files.find((file) => file.path === active) ?? null;
  const locked = Boolean(
    activeFile &&
      user &&
      activeFile.lockedBy &&
      activeFile.lockedBy !== user.id &&
      activeFile.lockedAt &&
      Date.now() - activeFile.lockedAt < 90_000,
  );
  const readOnly = !canEdit || locked;
  const preview = useMemo(() => buildPreviewDoc(files), [files]);
  const problems = useMemo(
    () => files.filter((file) => file.kind === "file").flatMap((file) => diagnose(file.path, file.content).map((issue) => ({ ...issue, path: file.path }))),
    [files],
  );
  const statusInfo = gitStatus(
    files.map((file) => ({ path: file.path, kind: file.kind, content: file.content })),
    head,
  );

  function openFile(path: string) {
    setOpen((items) => (items.includes(path) ? items : [...items, path]));
    setActive(path);
    setPane("code");
  }

  async function mutate(path: string) {
    await load(false);
    if (path) openFile(path);
  }

  async function run(lineText: string) {
    const current = dataRef.current;
    if (!current) return;
    const snap = filesRef.current.map((file) => ({ path: file.path, kind: file.kind, content: file.content }));
    const result = execTerminal(lineText, {
      cwd,
      files: snap,
      branch: current.project.branch,
      statusText: statusInfo.clean
        ? "clean"
        : [...statusInfo.modified.map((item) => `M ${item}`), ...statusInfo.added.map((item) => `A ${item}`), ...statusInfo.deleted.map((item) => `D ${item}`)].join("\n"),
      logText: current.commits.map((commit) => `${commit.branch} ${commit.message}`).join("\n"),
    });
    if (result.clear) {
      setTerm([]);
      return;
    }
    if (result.cwd != null) setCwd(result.cwd);
    const outputs = [`$ ${lineText}`];
    if (result.output) outputs.push(result.output);
    if (result.effect?.type === "test") outputs.push(formatTests(runProjectTests(snap)));
    if (result.effect?.type === "lint") outputs.push(problems.map((issue) => `${issue.path}:${issue.line} ${issue.message}`).join("\n") || t("problemsNone"));
    if (result.effect?.type === "format" && activeRef.current) {
      const file = filesRef.current.find((item) => item.path === activeRef.current);
      if (file) {
        const formatted = await formatSource(file.path, file.content);
        updateFile(file.path, formatted);
        outputs.push(t("format"));
      }
    }
    if (result.effect?.type === "commit") {
      const saved = await gitCommit({ data: { projectId: current.project.id, message: result.effect.message } });
      outputs.push(saved.ok ? saved.id : errorText(t, saved.error));
      if (saved.ok) await load(false);
    }
    if (result.effect?.type === "checkout") {
      const saved = await gitCheckout({ data: { projectId: current.project.id, name: result.effect.name, force: result.effect.force } });
      outputs.push(saved.ok ? result.effect.name : errorText(t, saved.error));
      if (saved.ok) await load(false);
    }
    if (result.effect?.type === "branch") {
      const saved = await gitBranch({ data: { projectId: current.project.id, name: result.effect.name, checkout: true } });
      outputs.push(saved.ok ? result.effect.name : errorText(t, saved.error));
      if (saved.ok) await load(false);
    }
    if (result.effect?.type === "merge") {
      const saved = await gitMerge({ data: { projectId: current.project.id, source: result.effect.name } });
      outputs.push(saved.ok ? (saved.conflicts.length ? saved.conflicts.join(", ") : t("mergeOk")) : errorText(t, saved.error));
      if (saved.ok) await load(false);
    }
    if (result.effect?.type === "add-dep") {
      const pkg = filesRef.current.find((file) => file.path === "package.json");
      if (pkg) {
        const json = JSON.parse(pkg.content || "{}") as { dependencies?: Record<string, string> };
        json.dependencies = { ...(json.dependencies ?? {}), [result.effect.name]: "latest" };
        updateFile(pkg.path, JSON.stringify(json, null, 2));
        outputs.push(t("depAdded"));
      }
    }
    setTerm((items) => [...items, ...outputs].slice(-200));
  }

  if (error) {
    return (
      <main className="grid min-h-dvh place-items-center px-4">
        <div className="max-w-md text-center">
          <h1 className="text-xl font-semibold text-primary">{errorText(t, error)}</h1>
          {error === "profile_required" ? <Link to="/studio" className={`${buttonClass("primary")} mt-4`}>{t("finishProfile")}</Link> : null}
        </div>
      </main>
    );
  }
  if (!data || !user) {
    return (
      <div className="grid min-h-dvh place-items-center gap-2">
        <Mark />
        <p className="text-sm text-muted-foreground">{t("loading")}</p>
      </div>
    );
  }

  const tree = files.filter((file) => {
    if (filter && !file.path.toLowerCase().includes(filter.toLowerCase())) return false;
    if (filter) return true;
    const parts = file.path.split("/");
    for (let index = 1; index < parts.length; index += 1) {
      if (collapsed[parts.slice(0, index).join("/")]) return false;
    }
    return true;
  });
  const paletteItems = [
    ...files.filter((file) => file.kind === "file").map((file) => ({ id: file.path, label: file.path, run: () => openFile(file.path) })),
    { id: "tests", label: t("runTests"), run: () => void run("npm test") },
    { id: "debug", label: t("runDebug"), run: () => runDebug() },
    { id: "format", label: t("format"), run: () => { if (activeFile) void formatSource(activeFile.path, activeFile.content).then((next) => updateFile(activeFile.path, next)); } },
    { id: "deploy", label: t("deploy"), run: () => void deploy() },
    { id: "preview", label: t("preview"), run: () => { setSide("preview"); setPane("side"); } },
    { id: "chat", label: t("chat"), run: () => { setSide("chat"); setPane("side"); } },
    { id: "ai", label: t("ai"), run: () => { setSide("ai"); setPane("side"); } },
    { id: "tasks", label: t("tasks"), run: () => { setSide("tasks"); setPane("side"); } },
    { id: "git", label: t("git"), run: () => { setSide("git"); setPane("side"); } },
    { id: "review", label: t("review"), run: () => { setSide("review"); setPane("side"); } },
  ].filter((item) => !paletteQuery || item.label.toLowerCase().includes(paletteQuery.toLowerCase())).slice(0, 12);

  return (
    <div className="flex h-dvh flex-col bg-background">
      <header className="flex flex-wrap items-center gap-2 border-b border-border bg-sidebar px-3 py-2">
        <Link to="/studio" className="flex items-center gap-2 text-primary"><Mark className="size-8 text-xs" /> </Link>
        <div className="min-w-0">
          <h1 className="truncate text-sm font-semibold text-primary">{data.project.name}</h1>
          <p className="text-xs text-muted-foreground">{data.project.branch} · {t(status === "saving" ? "saving" : status === "unsaved" ? "unsaved" : status === "offline" ? "offline" : "saved")}</p>
        </div>
        <div className="flex -space-x-2">
          {presence.map((person) => (
            <span key={person.userId} title={`${person.fullName} · ${person.filePath}`} className="rounded-full ring-2 ring-sidebar">
              <Avatar name={person.fullName} size="sm" />
            </span>
          ))}
        </div>
        <div className="ms-auto flex flex-wrap items-center gap-1">
          <Button className="h-9" onClick={() => void run("npm test")}>{t("runTests")}</Button>
          <Button className="h-9" variant="primary" disabled={!canEdit || deploying} onClick={() => void deploy()}>
            {deploying ? t("deploying") : t("deploy")}
          </Button>
          <ThemeLang />
        </div>
      </header>
      {!online ? <p className="bg-accent px-3 py-1 text-sm text-warn">{t("offline")}</p> : null}
      {!canEdit ? <p className="bg-accent px-3 py-1 text-sm text-primary">{t("viewerNotice")}</p> : null}
      {locked ? <p className="bg-accent px-3 py-1 text-sm text-warn">{t("err_locked")}</p> : null}
      <div className="flex gap-1 border-b border-border px-2 py-1 lg:hidden">
        {(["files", "code", "side", "term"] as const).map((item) => (
          <button key={item} type="button" className={`h-10 flex-1 rounded-md text-sm ${pane === item ? "bg-accent text-primary" : ""}`} onClick={() => setPane(item)}>
            {t(item === "files" ? "files" : item === "code" ? "workspace" : item === "side" ? side : "terminal")}
          </button>
        ))}
      </div>
      <div className="min-h-0 flex-1">
        {wide ? (
          <Group orientation="vertical" className="h-full">
            <Panel defaultSize="74%" minSize="40%">
              <Group orientation="horizontal" className="h-full">
                <Panel defaultSize="20%" minSize="14%">{filePane(tree)}</Panel>
                <Separator className="w-1.5 bg-border" />
                <Panel defaultSize="52%" minSize="30%">{editorPane()}</Panel>
                <Separator className="w-1.5 bg-border" />
                <Panel defaultSize="28%" minSize="18%">{sidePane()}</Panel>
              </Group>
            </Panel>
            {showBottom ? <Separator className="h-1.5 bg-border" /> : null}
            {showBottom ? <Panel defaultSize="26%" minSize="12%">{bottomPane()}</Panel> : null}
          </Group>
        ) : (
          <div className="h-full">
            {pane === "files" ? filePane(tree) : null}
            {pane === "code" ? editorPane() : null}
            {pane === "side" ? sidePane() : null}
            {pane === "term" ? bottomPane() : null}
          </div>
        )}
      </div>
      <footer className="flex items-center gap-3 border-t border-border px-3 py-1 text-xs text-muted-foreground">
        <span dir="ltr">{activeFile?.language || ""}</span>
        <span className="tabular-nums">{t("line")} {line}</span>
        <span>{t(`role_${data.role}`)}</span>
        <button type="button" className="ms-auto text-primary" onClick={() => setPaletteOpen(true)}>{t("palette")}</button>
      </footer>
      {paletteOpen ? (
        <div className="fixed inset-0 z-50 bg-foreground/25 px-4 pt-[12dvh]" onClick={() => setPaletteOpen(false)}>
          <div className="mx-auto w-full max-w-lg rounded-xl border border-border bg-card p-2" onClick={(event) => event.stopPropagation()}>
            <input
              autoFocus
              value={paletteQuery}
              onChange={(event) => setPaletteQuery(event.target.value)}
              placeholder={t("paletteHint")}
              className="h-11 w-full rounded-md bg-sidebar px-3 text-sm outline-none"
            />
            <ul className="mt-2 max-h-72 overflow-auto">
              {paletteItems.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    className="flex h-10 w-full items-center rounded-md px-2 text-start text-sm hover:bg-accent"
                    onClick={() => {
                      setPaletteOpen(false);
                      setPaletteQuery("");
                      item.run();
                    }}
                  >
                    <span className="truncate" dir="ltr">{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : null}
      {conflict ? (
        <div className="fixed inset-x-4 bottom-4 z-40 mx-auto max-w-lg rounded-xl border border-border bg-card p-4 shadow-sm">
          <p className="font-medium text-primary">{t("conflict")}</p>
          <p className="mt-1 font-mono text-xs" dir="ltr">{conflict.path}</p>
          <div className="mt-3 flex gap-2">
            <Button variant="primary" onClick={() => { updateFile(conflict.path, conflict.mine); setConflict(null); }}>{t("useMine")}</Button>
            <Button onClick={() => { updateFile(conflict.path, conflict.theirs); setConflict(null); }}>{t("useTheirs")}</Button>
          </div>
        </div>
      ) : null}
    </div>
  );

  function filePane(rows: FileRow[]) {
    return (
      <div className="flex h-full flex-col bg-sidebar">
        <div className="flex items-center gap-1 border-b border-border p-2">
          <input value={filter} onChange={(event) => setFilter(event.target.value)} placeholder={t("searchFiles")} className="h-9 w-full rounded-md border border-border bg-card px-2 text-sm" />
        </div>
        {canEdit ? (
          <form
            className="flex gap-1 border-b border-border p-2"
            onSubmit={(event) => {
              event.preventDefault();
              void createPath({ data: { projectId: data!.project.id, path: pathDraft, kind: pathKind } }).then(async (result) => {
                if (!result.ok) toast.error(errorText(t, result.error));
                else {
                  setPathDraft("");
                  await mutate(pathKind === "file" ? pathDraft : "");
                }
              });
            }}
          >
            <input value={pathDraft} onChange={(event) => setPathDraft(event.target.value)} placeholder={t("path")} className="h-9 w-full rounded-md border border-border bg-card px-2 text-xs" dir="ltr" />
            <button type="button" className="text-xs text-primary" onClick={() => setPathKind(pathKind === "file" ? "dir" : "file")}>{pathKind === "file" ? t("newFile") : t("newFolder")}</button>
          </form>
        ) : null}
        <div className="min-h-0 flex-1 overflow-auto p-1">
          {rows.map((file) => {
            const depth = file.path.split("/").length - 1;
            const who = presence.find((person) => person.filePath === file.path);
            const assignee = data!.members.find((member) => member.userId === file.assigneeId);
            return (
              <div key={file.path} className={`flex items-center gap-1 rounded-md pr-1 ${active === file.path ? "bg-accent" : "hover:bg-muted"}`} style={{ paddingInlineStart: `${8 + depth * 12}px` }}>
                <button
                  type="button"
                  className="min-h-9 flex-1 truncate py-1 text-start text-sm"
                  dir="ltr"
                  onClick={() => {
                    if (file.kind === "dir") setCollapsed((map) => ({ ...map, [file.path]: !map[file.path] }));
                    else openFile(file.path);
                  }}
                >
                  {file.kind === "dir" ? `${collapsed[file.path] ? "▸ " : "▾ "}${file.path.split("/").pop()}/` : file.path.split("/").pop()}
                </button>
                {who ? <span className="text-xs text-primary">{who.username}</span> : null}
                {assignee ? <span className="text-xs text-muted-foreground">@{assignee.username}</span> : null}
                {canEdit && file.kind === "file" && file.lockedBy ? (
                  <button type="button" className="text-xs text-muted-foreground" onClick={() => void unlockFile({ data: { projectId: data!.project.id, path: file.path } })}>{t("unlock")}</button>
                ) : null}
              </div>
            );
          })}
        </div>
        {canEdit && active ? (
          <div className="flex flex-wrap gap-1 border-t border-border p-2">
            <button type="button" className="text-xs text-danger" onClick={() => {
              if (!confirm(t("confirmDelete"))) return;
              void deletePath({ data: { projectId: data!.project.id, path: active } }).then(() => load(false));
            }}>{t("delete")}</button>
            <button type="button" className="text-xs text-primary" onClick={() => {
              const next = prompt(t("path"), active) ?? "";
              if (!next || next === active) return;
              void renamePath({ data: { projectId: data!.project.id, from: active, to: next } }).then(() => mutate(next));
            }}>{t("rename")}</button>
            {data && data.role !== "developer" && data.role !== "viewer" ? (
              <select
                className="h-8 rounded-md border border-border bg-card text-xs"
                value={activeFile?.assigneeId ?? ""}
                onChange={(event) => {
                  if (!data) return;
                  void assignFile({ data: { projectId: data.project.id, path: active, assigneeId: event.target.value } }).then(() => load(false));
                }}
              >
                <option value="">{t("unassigned")}</option>
                {data.members.map((member) => <option key={member.userId} value={member.userId}>{member.username}</option>)}
              </select>
            ) : null}
          </div>
        ) : null}
      </div>
    );
  }

  function editorPane() {
    return (
      <div className="flex h-full min-h-0 flex-col">
        <div className="flex items-center gap-1 overflow-x-auto border-b border-border px-2">
          {open.map((path) => (
            <button key={path} type="button" className={`flex h-10 items-center gap-2 px-2 text-sm ${active === path ? "text-primary" : "text-muted-foreground"}`} onClick={() => setActive(path)}>
              <span dir="ltr">{path.split("/").pop()}{dirty[path] ? " •" : ""}</span>
              <span
                role="button"
                className="text-xs"
                onClick={(event) => {
                  event.stopPropagation();
                  setOpen((items) => items.filter((item) => item !== path));
                  if (active === path) setActive(open.find((item) => item !== path) ?? null);
                }}
              >
                ×
              </span>
            </button>
          ))}
          <div className="ms-auto flex gap-1 py-1">
            <Button className="h-8" disabled={readOnly || !activeFile} onClick={() => activeFile && void formatSource(activeFile.path, activeFile.content).then((next) => updateFile(activeFile.path, next))}>{t("format")}</Button>
            <Button className="h-8" onClick={() => setSplit(split ? null : active)}>{split ? t("closeSplit") : t("split")}</Button>
            <Button className="h-8" onClick={() => setShowBottom((value) => !value)}>{t("terminal")}</Button>
          </div>
        </div>
        <div className="grid min-h-0 flex-1" style={{ gridTemplateColumns: split ? "1fr 1fr" : "1fr" }}>
          {editorFor(active)}
          {split ? editorFor(split) : null}
        </div>
      </div>
    );
  }

  function editorFor(path: string | null) {
    const file = files.find((item) => item.path === path);
    if (!file || !Editor) return <div className="h-full bg-card" />;
    const held = Boolean(file.lockedBy && user && file.lockedBy !== user.id && file.lockedAt && Date.now() - file.lockedAt < 90_000);
    const peers = presence
      .filter((person) => person.filePath === file.path)
      .map((person) => ({ id: person.userId, name: person.username, line: person.line }));
    return (
      <div className="h-full min-h-0" dir="ltr">
        <Editor
          path={file.path}
          language={file.language || languageFromPath(file.path)}
          value={file.content}
          dark={theme === "dark"}
          readOnly={!canEdit || held}
          peers={peers}
          breakpoints={breaks[file.path] ?? []}
          revealLine={reveal}
          onChange={(value) => updateFile(file.path, value)}
          onCursor={setLine}
          onToggleBreakpoint={(next) =>
            setBreaks((map) => {
              const list = map[file.path] ?? [];
              const marks = list.includes(next) ? list.filter((item) => item !== next) : [...list, next].sort((a, b) => a - b);
              return { ...map, [file.path]: marks };
            })
          }
        />
      </div>
    );
  }

  function sidePane() {
    const tabs = ["preview", "chat", "ai", "tasks", "git", "review"] as const;
    return (
      <div className="flex h-full min-h-0 flex-col bg-card">
        <div className="flex overflow-x-auto border-b border-border">
          {tabs.map((tab) => (
            <button key={tab} type="button" className={`h-10 px-2 text-sm ${side === tab ? "text-primary" : "text-muted-foreground"}`} onClick={() => { setSide(tab); setPane("side"); }}>
              {t(tab)}
            </button>
          ))}
        </div>
        <div className="min-h-0 flex-1 overflow-auto p-3">
          {side === "preview" ? (
            <div className="grid h-full grid-rows-[auto_1fr_auto] gap-2">
              <p className="text-xs text-muted-foreground">{t("reload")}</p>
              {preview ? <iframe title="preview" sandbox="allow-scripts" srcDoc={preview} className="h-full min-h-64 w-full rounded-md border border-border bg-card" /> : <p className="text-sm text-muted-foreground">{t("none")}</p>}
              <pre className="max-h-24 overflow-auto font-mono text-xs text-muted-foreground" dir="ltr">{logs.join("\n")}</pre>
            </div>
          ) : null}
          {side === "chat" ? chatPane() : null}
          {side === "ai" ? aiPane() : null}
          {side === "tasks" ? taskPane() : null}
          {side === "git" ? gitPane() : null}
          {side === "review" ? reviewPane() : null}
        </div>
      </div>
    );
  }

  function chatPane() {
    const roots = messages.filter((message) => !message.parentId);
    const query = mentionQuery(draft);
    const suggestions = query == null || !data ? [] : data.members.filter((member) => member.username.startsWith(query)).slice(0, 6);
    return (
      <div className="grid gap-3">
        {roots.map((message) => (
          <article key={message.id}>
            <p className="text-sm font-medium">{message.fullName}</p>
            <p className="whitespace-pre-wrap text-sm"><MentionText body={message.body} /></p>
            {message.snippet ? <pre className="mt-1 overflow-auto rounded-md bg-sidebar p-2 font-mono text-xs" dir="ltr">{message.snippet}</pre> : null}
            <button type="button" className="text-xs text-primary" onClick={() => setThread(message.id)}>{t("reply")}</button>
            {thread === message.id ? messages.filter((item) => item.parentId === message.id).map((item) => (
              <p key={item.id} className="mt-1 text-sm text-muted-foreground">{item.fullName}: <MentionText body={item.body} /></p>
            )) : null}
          </article>
        ))}
        {suggestions.length ? (
          <div className="flex flex-wrap gap-1">
            {suggestions.map((member) => (
              <button key={member.userId} type="button" className="rounded-md bg-accent px-2 py-1 text-xs text-primary" onClick={() => setDraft(applyMention(draft, member.username))}>
                @{member.username}
              </button>
            ))}
          </div>
        ) : null}
        <textarea value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={t("writeMessage")} className="min-h-20 rounded-md border border-border bg-sidebar p-2 text-sm" />
        <div className="flex flex-wrap gap-2">
          <Button variant="primary" onClick={() => void sendChat()}>{t("send")}</Button>
          <Button onClick={() => {
            if (!activeFile) return;
            void postMessage({ data: { channelId: data!.channelId, body: draft || activeFile.path, snippet: activeFile.content.slice(0, 4000), snippetPath: activeFile.path, parentId: thread ?? "" } }).then(() => setDraft(""));
          }}>{t("snippet")}</Button>
        </div>
      </div>
    );
  }

  async function sendChat() {
    if (!data?.channelId) return;
    const result = await postMessage({ data: { channelId: data.channelId, body: draft, parentId: thread ?? "" } });
    if (!result.ok) toast.error(errorText(t, result.error));
    setDraft("");
  }

  function aiPane() {
    return (
      <div className="grid gap-3">
        <div className="grid gap-2">
          {aiLog.map((item, index) => (
            <p key={index} className="whitespace-pre-wrap text-sm">
              <span className="font-medium text-primary">{item.role === "assistant" ? t("assistant") : t("you")}: </span>
              {item.content}
            </p>
          ))}
        </div>
        {proposals.length ? (
          <div className="rounded-lg border border-border p-2">
            <p className="text-sm font-medium">{t("proposed")}</p>
            {proposals.map((edit) => <p key={edit.path} className="font-mono text-xs" dir="ltr">{edit.path}</p>)}
            <Button className="mt-2" variant="primary" onClick={() => void applyEdits()}>{t("aiApply")}</Button>
          </div>
        ) : null}
        <textarea value={aiText} onChange={(event) => setAiText(event.target.value)} placeholder={t("aiPlaceholder")} className="min-h-24 rounded-md border border-border bg-sidebar p-2 text-sm" />
        <Button variant="primary" disabled={aiBusy || !canEdit} onClick={() => void ask(aiText)}>{aiBusy ? t("aiThinking") : t("send")}</Button>
        <Button
          disabled={aiBusy || !canEdit}
          onClick={() => void ask(t("fixTests"), formatTests(runProjectTests(filesRef.current)))}
        >
          {t("fixTests")}
        </Button>
        <p className="text-xs text-muted-foreground">{t("packages")}</p>
      </div>
    );
  }

  async function ask(message: string, extra = "") {
    if (!message.trim()) return;
    setAiBusy(true);
    setAiLog((items) => [...items, { role: "user", content: message }]);
    const result = await askAi({ data: { projectId: data!.project.id, message, activePath: active ?? "", extra } });
    setAiBusy(false);
    setAiText("");
    if (!result.ok) {
      toast.error(errorText(t, result.error));
      return;
    }
    setAiLog((items) => [...items, { role: "assistant", content: result.message }]);
    setProposals(result.edits);
    if (result.runTests) setTerm((items) => [...items, formatTests(runProjectTests(filesRef.current))]);
  }

  async function applyEdits() {
    for (const edit of proposals) {
      const existing = filesRef.current.find((file) => file.path === edit.path);
      if (!existing) {
        await createPath({ data: { projectId: data!.project.id, path: edit.path, kind: "file" } });
      }
      await saveFile({ data: { projectId: data!.project.id, path: edit.path, content: edit.content, baseUpdatedAt: existing?.updatedAt ?? null } });
    }
    setProposals([]);
    toast.success(t("applied"));
    await load(false);
  }

  function taskPane() {
    return (
      <div className="grid gap-3">
        {canEdit ? (
          <form className="flex gap-2" onSubmit={(event) => {
            event.preventDefault();
            void saveTask({ data: { projectId: data!.project.id, title: taskTitle, status: "todo", filePath: active ?? "" } }).then(async (result) => {
              if (!result.ok) toast.error(errorText(t, result.error));
              setTaskTitle("");
              await load(false);
            });
          }}>
            <input value={taskTitle} onChange={(event) => setTaskTitle(event.target.value)} placeholder={t("taskTitle")} className="h-10 w-full rounded-md border border-border bg-sidebar px-2 text-sm" />
            <Button type="submit" variant="primary">{t("addTask")}</Button>
          </form>
        ) : null}
        <div className="grid gap-2 sm:grid-cols-2">
          {COLUMNS.map((column) => (
            <section
              key={column}
              className="rounded-lg bg-sidebar p-2"
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => {
                const id = event.dataTransfer.getData("text/plain");
                void moveTask({ data: { projectId: data!.project.id, id, status: column } }).then(() => load(false));
              }}
            >
              <h3 className="text-sm font-medium text-primary">{t(column === "review" ? "reviewCol" : column)}</h3>
              {data!.tasks.filter((task) => task.status === column).map((task) => (
                <article key={task.id} draggable={canEdit} onDragStart={(event) => event.dataTransfer.setData("text/plain", task.id)} className="mt-2 rounded-md border border-border bg-card p-2">
                  <p className="text-sm">{task.title}</p>
                  {task.filePath ? <button type="button" className="text-xs text-primary" dir="ltr" onClick={() => openFile(task.filePath)}>{task.filePath}</button> : null}
                </article>
              ))}
            </section>
          ))}
        </div>
      </div>
    );
  }

  function gitPane() {
    return (
      <div className="grid gap-3 text-sm">
        <p>{t("branch")}: <span className="text-primary">{data!.project.branch}</span></p>
        <p className="font-mono text-xs" dir="ltr">
          {statusInfo.clean ? "clean" : [...statusInfo.modified.map((item) => `M ${item}`), ...statusInfo.added.map((item) => `A ${item}`), ...statusInfo.deleted.map((item) => `D ${item}`)].join("\n")}
        </p>
        <form className="flex gap-2" onSubmit={(event) => {
          event.preventDefault();
          void gitCommit({ data: { projectId: data!.project.id, message: commitMsg } }).then(async (result) => {
            if (!result.ok) toast.error(errorText(t, result.error));
            else { setCommitMsg(""); await load(false); }
          });
        }}>
          <input value={commitMsg} onChange={(event) => setCommitMsg(event.target.value)} placeholder={t("commitMsg")} className="h-10 w-full rounded-md border border-border px-2" />
          <Button type="submit" variant="primary" disabled={!canEdit}>{t("commit")}</Button>
        </form>
        <form className="flex gap-2" onSubmit={(event) => {
          event.preventDefault();
          void gitBranch({ data: { projectId: data!.project.id, name: branchName, checkout: true } }).then(async (result) => {
            if (!result.ok) toast.error(errorText(t, result.error));
            else { setBranchName(""); await load(false); }
          });
        }}>
          <input value={branchName} onChange={(event) => setBranchName(event.target.value)} placeholder={t("createBranch")} className="h-10 w-full rounded-md border border-border px-2" dir="ltr" />
          <Button type="submit" disabled={!canEdit}>{t("create")}</Button>
        </form>
        <div className="flex flex-wrap gap-1">
          {data!.branches.map((branch) => (
            <button key={branch.name} type="button" className="rounded-md bg-accent px-2 py-1 text-xs text-primary" onClick={() => void gitCheckout({ data: { projectId: data!.project.id, name: branch.name, force: false } }).then(async (result) => {
              if (!result.ok && result.error === "dirty" && confirm(t("dirty"))) {
                await gitCheckout({ data: { projectId: data!.project.id, name: branch.name, force: true } });
              }
              await load(false);
            })}>{branch.name}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <select className="h-10 flex-1 rounded-md border border-border bg-card px-2" value={mergeFrom} onChange={(event) => setMergeFrom(event.target.value)}>
            {data!.branches.map((branch) => <option key={branch.name}>{branch.name}</option>)}
          </select>
          <Button disabled={!canEdit} onClick={() => void gitMerge({ data: { projectId: data!.project.id, source: mergeFrom } }).then(async (result) => {
            if (!result.ok) toast.error(errorText(t, result.error));
            else toast.success(result.conflicts.length ? result.conflicts.join(", ") : t("mergeOk"));
            await load(false);
          })}>{t("merge")}</Button>
        </div>
        <ul className="grid gap-1">
          {data!.commits.map((commit) => <li key={commit.id} className="text-xs text-muted-foreground">{commit.message}</li>)}
        </ul>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => void createBackup({ data: { projectId: data!.project.id } }).then(() => load(false))}>{t("backup")}</Button>
          <Link to="/live/$slug" params={{ slug: data!.project.slug }} className={buttonClass("outline")}>{t("openLive")}</Link>
        </div>
        <ul className="grid gap-1">
          {data!.backups.map((backup) => (
            <li key={backup.id} className="flex items-center justify-between gap-2 text-xs">
              <span>{backup.note || t("manual")}</span>
              <button type="button" className="text-primary" onClick={() => {
                if (!confirm(t("restoreConfirm"))) return;
                void restoreBackup({ data: { projectId: data!.project.id, id: backup.id } }).then(() => load(false));
              }}>{t("restore")}</button>
            </li>
          ))}
        </ul>
        <ul className="grid gap-1">
          {data!.deployments.map((item) => <li key={item.id} className="text-xs">{item.status} · {new Date(item.at).toLocaleString()}</li>)}
        </ul>
      </div>
    );
  }

  function reviewPane() {
    const review = data!.reviews.find((item) => item.id === activeReview) ?? null;
    return (
      <div className="grid gap-3 text-sm">
        <form className="grid gap-2" onSubmit={(event) => {
          event.preventDefault();
          void saveReview({ data: { projectId: data!.project.id, title: reviewTitle, branch: reviewBranch } }).then(async (result) => {
            if (!result.ok) toast.error(errorText(t, result.error));
            setReviewTitle("");
            await load(false);
          });
        }}>
          <input value={reviewTitle} onChange={(event) => setReviewTitle(event.target.value)} placeholder={t("reviewTitle")} className="h-10 rounded-md border border-border px-2" />
          <select value={reviewBranch} onChange={(event) => setReviewBranch(event.target.value)} className="h-10 rounded-md border border-border bg-card px-2">
            {data!.branches.map((branch) => <option key={branch.name}>{branch.name}</option>)}
          </select>
          <Button type="submit" disabled={!canEdit}>{t("newReview")}</Button>
        </form>
        {data!.reviews.map((item) => (
          <button key={item.id} type="button" className="rounded-md border border-border px-2 py-2 text-start" onClick={() => {
            setActiveReview(item.id);
            void reviewDiff({ data: { projectId: data!.project.id, branch: item.branch } }).then((result) => {
              if (result.ok) setDiffs(result.diffs);
            });
          }}>
            <span className="font-medium text-primary">{item.title}</span>
            <span className="mt-1 block text-xs text-muted-foreground">{item.branch} · {item.status}</span>
          </button>
        ))}
        {review ? (
          <div className="grid gap-2">
            <div className="flex gap-2">
              <Button onClick={() => void setReviewStatus({ data: { id: review.id, status: "approved" } }).then(() => load(false))}>{t("approve")}</Button>
              <Button onClick={() => void setReviewStatus({ data: { id: review.id, status: "changes" } }).then(() => load(false))}>{t("requestChanges")}</Button>
            </div>
            {diffs.length === 0 ? <p className="text-muted-foreground">{t("diffEmpty")}</p> : null}
            {diffs.map((diff) => (
              <article key={diff.path} className="rounded-md border border-border p-2">
                <p className="font-mono text-xs" dir="ltr">{diff.status} {diff.path}</p>
                <pre className="mt-1 max-h-40 overflow-auto font-mono text-xs" dir="ltr">{diff.after.slice(0, 1200)}</pre>
                <form className="mt-2 flex gap-2" onSubmit={(event) => {
                  event.preventDefault();
                  void reviewComment({ data: { reviewId: review.id, body: comment, filePath: diff.path, line } }).then(async () => {
                    setComment("");
                    await load(false);
                  });
                }}>
                  <input value={comment} onChange={(event) => setComment(event.target.value)} placeholder={t("comment")} className="h-9 w-full rounded-md border border-border px-2 text-xs" />
                  <Button type="submit">{t("send")}</Button>
                </form>
                {data!.comments.filter((item) => item.reviewId === review.id && item.filePath === diff.path).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className="mt-1 text-start text-xs"
                    onClick={() => {
                      if (item.filePath) openFile(item.filePath);
                      if (item.line) setReveal(item.line);
                    }}
                  >
                    {item.username}{item.line ? `:${item.line}` : ""}: {item.body}
                  </button>
                ))}
              </article>
            ))}
          </div>
        ) : <p className="text-muted-foreground">{t("pickReview")}</p>}
      </div>
    );
  }

  function bottomPane() {
    return (
      <div className="flex h-full min-h-0 flex-col bg-sidebar">
        <div className="flex gap-2 border-b border-border px-2">
          <button type="button" className={`h-9 text-sm ${bottom === "terminal" ? "text-primary" : "text-muted-foreground"}`} onClick={() => setBottom("terminal")}>{t("terminal")}</button>
          <button type="button" className={`h-9 text-sm ${bottom === "problems" ? "text-primary" : "text-muted-foreground"}`} onClick={() => setBottom("problems")}>{t("problems")} {problems.length ? `(${problems.length})` : ""}</button>
          <button type="button" className={`h-9 text-sm ${bottom === "debug" ? "text-primary" : "text-muted-foreground"}`} onClick={() => setBottom("debug")}>{t("debug")}</button>
        </div>
        {bottom === "terminal" ? (
          <div className="flex min-h-0 flex-1 flex-col" dir="ltr">
            <pre className="min-h-0 flex-1 overflow-auto p-2 font-mono text-xs">{term.join("\n")}</pre>
            <form className="flex border-t border-border" onSubmit={(event) => { event.preventDefault(); const next = cmd; setCmd(""); void run(next); }}>
              <span className="px-2 py-2 font-mono text-xs text-primary">/</span>
              <input value={cmd} onChange={(event) => setCmd(event.target.value)} className="h-10 w-full bg-transparent font-mono text-xs outline-none" placeholder={t("terminalHint")} />
            </form>
          </div>
        ) : bottom === "problems" ? (
          <ul className="overflow-auto p-2 text-sm">
            {problems.length === 0 ? <li className="text-muted-foreground">{t("problemsNone")}</li> : null}
            {problems.map((issue, index) => (
              <li key={`${issue.path}-${issue.line}-${index}`}>
                <button type="button" className={issue.severity === "error" ? "text-danger" : "text-warn"} onClick={() => openFile(issue.path)}>
                  {issue.path}:{issue.line} {issue.message}
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="grid content-start gap-2 overflow-auto p-2 text-sm">
            <div className="flex flex-wrap items-center gap-2">
              <Button className="h-9" variant="primary" onClick={runDebug}>{t("runDebug")}</Button>
              <span className="text-xs text-muted-foreground">{t("noBreakpoints")}</span>
            </div>
            {(breaks[active ?? ""] ?? []).map((mark) => (
              <button key={mark} type="button" className="text-start text-xs text-danger" onClick={() => { if (!active) return; openFile(active); setReveal(mark); }}>
                {active}:{mark}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  function runDebug() {
    if (!activeFile) return;
    if (!/\.(js|mjs|cjs)$/.test(activeFile.path)) {
      setTerm((items) => [...items, t("debugJsOnly")]);
      setBottom("terminal");
      setShowBottom(true);
      return;
    }
    const result = traceJavaScript(activeFile.content, breaks[activeFile.path] ?? []);
    if (result.paused) setReveal(result.paused);
    const summary = result.paused ? `${t("pausedAt")} ${result.paused}` : result.error || t("debugOk");
    setTerm((items) => [...items, `$ debug ${activeFile.path}`, summary, result.logs.join("\n")].filter(Boolean));
    setBottom("terminal");
    setShowBottom(true);
  }

  async function deploy() {
    setDeploying(true);
    const tests = runProjectTests(filesRef.current);
    const passed = tests.every((item) => item.ok) && (tests.length > 0 || true);
    const realPass = tests.length === 0 || tests.every((item) => item.ok);
    const log = tests.length ? formatTests(tests) : t("noTests");
    setTerm((items) => [...items, log]);
    const result = await publishDeploy({ data: { projectId: data!.project.id, passed: realPass, log } });
    setDeploying(false);
    if (!result.ok) toast.error(errorText(t, result.error));
    else toast.success(result.status === "live" ? t("live") : t("testsFailed"));
    void passed;
    await load(false);
  }
}

function queue(projectId: string, path: string, content: string, baseUpdatedAt: number | null) {
  const current = JSON.parse(localStorage.getItem("est.pending") || "[]") as { projectId: string; path: string; content: string; baseUpdatedAt: number | null }[];
  current.push({ projectId, path, content, baseUpdatedAt });
  localStorage.setItem("est.pending", JSON.stringify(current.slice(-30)));
}

function formatTests(results: { name: string; ok: boolean; detail: string }[]) {
  if (!results.length) return "no tests";
  return results.map((result) => `${result.ok ? "ok" : "fail"} ${result.name}\n${result.detail}`).join("\n");
}
