import { useEffect, useRef } from "react";
import Editor, { loader, type OnMount } from "@monaco-editor/react";
import * as monaco from "monaco-editor";

type GlobalWithMonaco = typeof globalThis & {
  MonacoEnvironment?: { getWorker: (id: string, label: string) => Worker };
};

const host = globalThis as GlobalWithMonaco;
host.MonacoEnvironment = {
  getWorker(_id, label) {
    if (label === "json") {
      return new Worker(new URL("monaco-editor/esm/vs/language/json/json.worker.js", import.meta.url), { type: "module" });
    }
    if (label === "css" || label === "scss" || label === "less") {
      return new Worker(new URL("monaco-editor/esm/vs/language/css/css.worker.js", import.meta.url), { type: "module" });
    }
    if (label === "html" || label === "handlebars" || label === "razor") {
      return new Worker(new URL("monaco-editor/esm/vs/language/html/html.worker.js", import.meta.url), { type: "module" });
    }
    if (label === "typescript" || label === "javascript") {
      return new Worker(new URL("monaco-editor/esm/vs/language/typescript/ts.worker.js", import.meta.url), { type: "module" });
    }
    return new Worker(new URL("monaco-editor/esm/vs/editor/editor.worker.js", import.meta.url), { type: "module" });
  },
};

loader.config({ monaco });

let themes = false;

function ensureThemes(api: typeof monaco) {
  if (themes) return;
  themes = true;
  api.editor.defineTheme("est-light", {
    base: "vs",
    inherit: true,
    rules: [],
    colors: {
      "editor.background": "#ffffff",
      "editor.foreground": "#1a2733",
      "editorLineNumber.foreground": "#8aa0b2",
      "editor.selectionBackground": "#d5e8f4",
      "editorCursor.foreground": "#2f6f96",
      "editorGutter.background": "#fbfcfd",
    },
  });
  api.editor.defineTheme("est-dark", {
    base: "vs-dark",
    inherit: true,
    rules: [],
    colors: {
      "editor.background": "#101820",
      "editor.foreground": "#e6eef5",
      "editorLineNumber.foreground": "#6d8294",
      "editor.selectionBackground": "#1e3a4c",
      "editorCursor.foreground": "#8ebcda",
      "editorGutter.background": "#121922",
    },
  });
}

export function MonacoHost({
  path,
  value,
  language,
  dark,
  readOnly,
  peers,
  breakpoints,
  revealLine,
  onChange,
  onCursor,
  onToggleBreakpoint,
}: {
  path: string;
  value: string;
  language: string;
  dark: boolean;
  readOnly: boolean;
  peers: { id: string; name: string; line: number }[];
  breakpoints: number[];
  revealLine: number;
  onChange: (value: string) => void;
  onCursor: (line: number) => void;
  onToggleBreakpoint: (line: number) => void;
}) {
  const onChangeRef = useRef(onChange);
  const onCursorRef = useRef(onCursor);
  const onBreakRef = useRef(onToggleBreakpoint);
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const decoRef = useRef<monaco.editor.IEditorDecorationsCollection | null>(null);
  useEffect(() => {
    onChangeRef.current = onChange;
    onCursorRef.current = onCursor;
    onBreakRef.current = onToggleBreakpoint;
  }, [onChange, onCursor, onToggleBreakpoint]);

  const handleMount: OnMount = (editor) => {
    editorRef.current = editor;
    editor.onDidChangeCursorPosition((event) => onCursorRef.current(event.position.lineNumber));
    editor.onMouseDown((event) => {
      const kind = event.target.type;
      const gutter =
        kind === monaco.editor.MouseTargetType.GUTTER_GLYPH_MARGIN ||
        kind === monaco.editor.MouseTargetType.GUTTER_LINE_NUMBERS;
      const line = event.target.position?.lineNumber;
      if (gutter && line) onBreakRef.current(line);
    });
  };

  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) return;
    const marks = [
      ...breakpoints.map((line) => ({
        range: new monaco.Range(line, 1, line, 1),
        options: { glyphMarginClassName: "est-breakpoint" },
      })),
      ...peers
        .filter((peer) => peer.line > 0)
        .map((peer) => ({
          range: new monaco.Range(peer.line, 1, peer.line, 1),
          options: {
            isWholeLine: true,
            className: "est-peer-line",
            after: { content: `  ${peer.name}`, inlineClassName: "est-peer-name" },
          },
        })),
    ];
    if (!decoRef.current) decoRef.current = editor.createDecorationsCollection(marks);
    else decoRef.current.set(marks);
  }, [breakpoints, peers, path, value]);

  useEffect(() => {
    if (revealLine > 0) editorRef.current?.revealLineInCenter(revealLine);
  }, [revealLine, path]);

  return (
    <Editor
      path={path}
      language={language}
      value={value}
      theme={dark ? "est-dark" : "est-light"}
      beforeMount={ensureThemes}
      onMount={handleMount}
      onChange={(next) => onChangeRef.current(next ?? "")}
      loading={<div className="h-full bg-card" />}
      options={{
        readOnly,
        fontFamily: "IBM Plex Mono, ui-monospace, monospace",
        fontSize: 13,
        minimap: { enabled: false },
        glyphMargin: true,
        wordWrap: "on",
        scrollBeyondLastLine: false,
        smoothScrolling: true,
        padding: { top: 12 },
        automaticLayout: true,
        tabSize: 2,
        renderLineHighlight: "line",
      }}
    />
  );
}
