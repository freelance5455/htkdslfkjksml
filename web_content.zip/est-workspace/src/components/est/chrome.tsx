import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Moon, Sun } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useI18n } from "@/lib/est/i18n";
import { usePrefs } from "@/lib/est/prefs";
import { buttonClass, cn } from "@/components/est/ui";

export function PrefsSync() {
  const hydrate = usePrefs((state) => state.hydrate);
  useEffect(() => {
    hydrate();
  }, [hydrate]);
  return null;
}

export function Mark({ className }: { className?: string }) {
  return (
    <span className={cn("grid size-9 place-items-center rounded-md bg-primary text-xs font-semibold tracking-wide text-primary-foreground", className)}>
      EST
    </span>
  );
}

function ThemeLang() {
  const { t, lang } = useI18n();
  const theme = usePrefs((state) => state.theme);
  const toggleTheme = usePrefs((state) => state.toggleTheme);
  const setLang = usePrefs((state) => state.setLang);
  const [install, setInstall] = useState<Event | null>(null);
  const [iosHint, setIosHint] = useState(false);

  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setInstall(event);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  return (
    <div className="flex items-center gap-1">
      <button type="button" className={buttonClass("ghost")} onClick={() => setLang(lang === "ar" ? "en" : "ar")}>
        {t("language")}
      </button>
      <button type="button" className={cn(buttonClass("ghost"), "px-2")} onClick={toggleTheme} aria-label={theme === "dark" ? t("themeToLight") : t("themeToDark")}>
        {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
      </button>
      <button
        type="button"
        className={buttonClass("ghost")}
        onClick={() => {
          const prompt = install as (Event & { prompt?: () => Promise<void> }) | null;
          if (prompt?.prompt) {
            void prompt.prompt();
            setInstall(null);
            return;
          }
          setIosHint((value) => !value);
        }}
      >
        {t("install")}
      </button>
      {iosHint ? <span className="max-w-48 text-xs text-muted-foreground">{t("installIos")}</span> : null}
    </div>
  );
}

export function AppFrame({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const path = useRouterState({ select: (state) => state.location.pathname });
  const online = useOnline();
  const links = [
    { to: "/studio", label: t("workspace") },
    { to: "/team", label: t("team") },
    { to: "/inbox", label: t("inbox") },
  ] as const;

  return (
    <div className="min-h-dvh bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-sidebar">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <Link to="/studio" className="flex items-center gap-2 font-semibold text-primary">
            <Mark />
            <span>Studio</span>
          </Link>
          <nav className="flex items-center gap-1">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={cn(
                  "rounded-md px-3 py-2 text-sm",
                  path.startsWith(link.to) ? "bg-accent text-primary" : "text-foreground hover:bg-muted",
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="ms-auto flex flex-wrap items-center gap-2">
            <ThemeLang />
            <UserButton />
          </div>
        </div>
        {!online ? <p className="border-t border-border px-4 py-2 text-sm text-warn">{t("offline")}</p> : null}
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
    </div>
  );
}

export function RequireUser({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const { t } = useI18n();
  if (isPending) {
    return (
      <div className="grid min-h-dvh place-items-center gap-3">
        <Mark />
        <p className="text-sm text-muted-foreground">{t("loading")}</p>
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return children;
}

export function useOnline() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);
  return online;
}

export { ThemeLang };
