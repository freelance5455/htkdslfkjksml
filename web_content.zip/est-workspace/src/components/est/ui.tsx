import { useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Variant = "primary" | "ghost" | "outline" | "danger";

export function buttonClass(variant: Variant = "outline", block = false) {
  return cn(
    "inline-flex h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-opacity disabled:pointer-events-none disabled:opacity-50",
    block && "w-full",
    variant === "primary" && "bg-primary text-primary-foreground hover:opacity-90",
    variant === "ghost" && "bg-transparent text-foreground hover:bg-muted",
    variant === "outline" && "border border-border bg-card text-foreground hover:bg-accent",
    variant === "danger" && "text-danger hover:bg-accent",
  );
}

export function Button({
  variant = "outline",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return <button type={type} className={cn(buttonClass(variant), className)} {...props} />;
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="font-medium">{label}</span>
      {children}
      {hint ? <span className="text-xs text-muted-foreground">{hint}</span> : null}
    </label>
  );
}

export function TextInput({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground",
        className,
      )}
      {...props}
    />
  );
}

export function TextArea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "min-h-24 w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground",
        className,
      )}
      {...props}
    />
  );
}

export function Badge({ children }: { children: ReactNode }) {
  return <span className="rounded-md bg-accent px-2 py-1 text-xs font-medium text-primary">{children}</span>;
}

export function Avatar({ name, src, size = "md" }: { name: string; src?: string | null; size?: "sm" | "md" | "lg" }) {
  const box = size === "sm" ? "size-8 text-xs" : size === "lg" ? "size-16 text-lg" : "size-10 text-sm";
  if (src) return <img src={src} alt="" className={cn(box, "rounded-full object-cover")} />;
  const letter = name.trim().slice(0, 1) || "E";
  return <span className={cn(box, "grid place-items-center rounded-full bg-accent font-semibold text-primary")}>{letter}</span>;
}

export function Modal({
  open,
  onOpenChange,
  title,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-foreground/30 px-4 py-6" onClick={() => onOpenChange(false)}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[85dvh] w-full max-w-lg overflow-auto rounded-xl border border-border bg-card p-4"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 className="text-lg font-semibold text-primary">{title}</h2>
        <div className="mt-3">{children}</div>
      </div>
    </div>
  );
}

export function AvatarEditor({
  value,
  onChange,
  labels,
}: {
  value: string | null;
  onChange: (value: string | null) => void;
  labels: { avatar: string; zoom: string; remove: string };
}) {
  const [zoom, setZoom] = useState(1);
  const [source, setSource] = useState<string | null>(null);

  function paint(src: string, scale: number) {
    const image = new Image();
    image.onload = () => {
      const size = 256;
      const canvas = document.createElement("canvas");
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#e7f1f7";
      ctx.fillRect(0, 0, size, size);
      const cover = Math.max(size / image.width, size / image.height) * scale;
      const width = image.width * cover;
      const height = image.height * cover;
      ctx.drawImage(image, (size - width) / 2, (size - height) / 2, width, height);
      onChange(canvas.toDataURL("image/jpeg", 0.82));
    };
    image.src = src;
  }

  return (
    <div className="grid gap-2">
      <span className="text-sm font-medium">{labels.avatar}</span>
      <div className="flex items-center gap-3">
        <Avatar name={labels.avatar} src={value} size="lg" />
        <input
          type="file"
          accept="image/*"
          className="text-sm"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
              const next = String(reader.result || "");
              setSource(next);
              paint(next, zoom);
            };
            reader.readAsDataURL(file);
          }}
        />
      </div>
      <label className="grid gap-1 text-xs text-muted-foreground">
        {labels.zoom}
        <input
          type="range"
          min={1}
          max={2.4}
          step={0.05}
          value={zoom}
          onChange={(event) => {
            const next = Number(event.target.value);
            setZoom(next);
            if (source) paint(source, next);
          }}
        />
      </label>
      {value ? (
        <button
          type="button"
          className="justify-self-start text-sm text-danger"
          onClick={() => {
            setSource(null);
            onChange(null);
          }}
        >
          {labels.remove}
        </button>
      ) : null}
    </div>
  );
}

export function MentionText({ body }: { body: string }) {
  const parts = body.split(/(@[a-z0-9_]+)/gi);
  return (
    <>
      {parts.map((part, index) =>
        part.startsWith("@") ? (
          <span key={`${part}-${index}`} className="text-primary">
            {part}
          </span>
        ) : (
          <span key={`${index}-t`}>{part}</span>
        ),
      )}
    </>
  );
}
