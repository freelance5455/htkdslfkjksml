APLIKASI PENCATATAN KENDARAAN OFFLINE

Isi paket:
- index.html : aplikasi utama, seluruh CSS dan JavaScript sudah menyatu.
- README.txt : petunjuk penggunaan.

CARA MENJALANKAN OFFLINE
1. Ekstrak ZIP ini.
2. Buka file index.html menggunakan browser (Chrome/Edge).
3. Aplikasi dapat dipakai tanpa internet.
4. Data disimpan di penyimpanan lokal browser/perangkat yang sama.

FITUR
- Tambah, edit, hapus, dan cari data.
- Nomor urut otomatis.
- Cetak laporan A4 dengan baris kosong tambahan seperti formulir contoh.
- Ekspor CSV untuk Excel.
- Cadangkan/pulihkan data melalui JSON.

CATATAN UNTUK DIJADIKAN APK
- Unggah file index.html ke konverter HTML-to-APK atau masukkan seluruh folder proyek jika konverter meminta ZIP.
- Pilih mode offline/local HTML jika tersedia.
- Aktifkan penyimpanan lokal/WebView DOM Storage bila ada pengaturan tersebut.
- Setelah instalasi, uji tambah data, tutup aplikasi, lalu buka kembali untuk memastikan data tetap tersimpan.
- Jangan menghapus data aplikasi jika ingin mempertahankan catatan. Buat cadangan JSON secara berkala.

Aplikasi ini menyimpan data hanya di perangkat, tidak mengirim data ke server.
