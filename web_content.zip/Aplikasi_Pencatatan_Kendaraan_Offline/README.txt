APLIKASI PENCATATAN KENDARAAN OFFLINE - SEDERHANA

Tombol yang tersedia hanya:
- Simpan Data
- Cetak Laporan

Data tersimpan lokal di perangkat menggunakan localStorage. Kolom: Tanggal, Nomor Polisi, Nomor Seri, Tujuan, Tonase, Keterangan. Nomor urut otomatis.

Cara membuat APK:
1. Ekstrak ZIP.
2. Unggah index.html ke HTMLtoAPK.
3. Pastikan JavaScript aktif.
4. Aktifkan DOM Storage/Local Storage bila tersedia.
5. Build dan instal APK.

Catatan: cetak langsung di APK memerlukan dukungan Android PrintManager pada WebView/konverter. Jika dialog cetak tidak muncul, konverter yang digunakan perlu mengaktifkan dukungan cetak WebView; alternatifnya buka aplikasi melalui Chrome Android.
