from app.registry import build_registry, five_loka_matrix, DNA_TOTAL
from app.policy import decide
from app.models import Verdict
def test_registry_has_184():
    assert DNA_TOTAL == 184 and len(build_registry()) == 184
def test_matrix_has_920_unvalidated_slots():
    m=five_loka_matrix(); assert len(m)==920 and all(x["status"]=="TAHAN" for x in m)
def test_fail_closed():
    v,_=decide([Verdict.TAHAN]); assert v==Verdict.TAHAN
def test_explicit_violation_tolak():
    v,_=decide([Verdict.TAHAN],explicit_violation=True); assert v==Verdict.TOLAK
def test_all_pass_lolos():
    v,_=decide([Verdict.LOLOS]); assert v==Verdict.LOLOS
