from uuid import uuid4
from .models import Verdict, EvaluationResponse
from .policy import decide
from .agents import advisory_agents
from .audit import audit_event

def evaluate(req):
    rid=req.request_id or str(uuid4())
    # 920 matrix slots + one input gate. No check is marked implemented by default.
    statuses=[Verdict.TAHAN]*921
    verdict,reasons=decide(statuses)
    proposals=advisory_agents(req.text)
    event=audit_event("evaluation",rid,{"verdict":verdict.value,"proposal_count":len(proposals)})
    return EvaluationResponse(request_id=rid,verdict=verdict,reasons=reasons,
        advice="Tinjau risiko, sumber, dan konteks. Jangan gunakan sebagai keputusan otomatis.",
        checks_total=921,checks_passed=0,audit_state="TAHAN"), proposals, event
