from .models import Verdict

def decide(check_statuses: list[Verdict], explicit_violation: bool=False):
    if explicit_violation:
        return Verdict.TOLAK, ["Pelanggaran kebijakan eksplisit terdeteksi."]
    if not check_statuses or any(s != Verdict.LOLOS for s in check_statuses):
        return Verdict.TAHAN, ["Satu atau lebih gerbang belum LOLOS; fail-closed."]
    return Verdict.LOLOS, ["Semua gerbang yang dikonfigurasi LOLOS."]
