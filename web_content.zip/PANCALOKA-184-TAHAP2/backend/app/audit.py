from datetime import datetime, timezone
from hashlib import sha256
import json

def audit_event(event: str, request_id: str, details: dict):
    payload={"at":datetime.now(timezone.utc).isoformat(),"event":event,
             "request_id":request_id,"details":details}
    canonical=json.dumps(payload,sort_keys=True,separators=(",",":"))
    return {**payload,"digest_sha256":sha256(canonical.encode()).hexdigest()}
