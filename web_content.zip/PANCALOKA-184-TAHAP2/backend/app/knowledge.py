from pydantic import BaseModel, Field
from datetime import datetime, timezone
from uuid import uuid4
class KnowledgeRecord(BaseModel):
    id: str = Field(default_factory=lambda:str(uuid4()))
    text: str
    source: str
    source_hash: str
    approved: bool = False
    created_at: str = Field(default_factory=lambda:datetime.now(timezone.utc).isoformat())
class KnowledgeStore:
    def __init__(self): self.records: dict[str,KnowledgeRecord]={}
    def add(self, rec:KnowledgeRecord): self.records[rec.id]=rec; return rec
    def approved(self): return [r for r in self.records.values() if r.approved]
