from .models import Check, Verdict
LOKA_COUNTS = {"ASMA":99,"AKSARA":20,"HIJAIYAH":29,"ANGKA":10,"ABJAD":26}
DNA_TOTAL = sum(LOKA_COUNTS.values())
CHECKS_TOTAL = 920

def build_registry():
    rows=[]
    for loka, count in LOKA_COUNTS.items():
        for n in range(1,count+1):
            rows.append(Check(id=f"{loka}-{n:03d}", loka=loka))
    return rows

def five_loka_matrix():
    # 184 rules × 5 domains = 920 slots; slots are not assertions of validation.
    return [{"rule_id":f"DNA-{i:03d}", "domain":d, "status":Verdict.TAHAN.value}
            for i in range(1,185) for d in LOKA_COUNTS]
