from enum import Enum
from pydantic import BaseModel, Field
from typing import Any

class Verdict(str, Enum):
    LOLOS = "LOLOS"
    TAHAN = "TAHAN"
    TOLAK = "TOLAK"

class Check(BaseModel):
    id: str
    loka: str
    status: Verdict = Verdict.TAHAN
    implemented: bool = False
    rationale: str = "Belum ada bukti implementasi/audit."

class EvaluationRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)
    context: dict[str, Any] = Field(default_factory=dict)
    request_id: str | None = None

class EvaluationResponse(BaseModel):
    request_id: str
    verdict: Verdict
    reasons: list[str]
    advice: str
    checks_total: int = 921
    checks_passed: int = 0
    audit_state: str = "TAHAN"
