from pydantic import BaseModel
class AgentProposal(BaseModel):
    agent: str
    summary: str
    concerns: list[str]
    suggested_questions: list[str]
    # Proposals are advisory: no approval, tool, or side-effect fields.

def advisory_agents(text: str):
    return [
      AgentProposal(agent="analisis",summary="Perlu analisis konteks oleh operator.",
                   concerns=["Konteks belum diverifikasi."],suggested_questions=["Apa tujuan dan batas penggunaan?"]),
      AgentProposal(agent="keamanan",summary="Periksa risiko dan data sensitif.",
                   concerns=["Klasifikasi data belum dilakukan."],suggested_questions=["Apakah data rahasia/identitas?"]),
      AgentProposal(agent="pengetahuan",summary="Perlu sumber dan provenance.",
                   concerns=["Tidak ada sumber terlampir."],suggested_questions=["Sumber mana yang otoritatif?"]),
      AgentProposal(agent="review",summary="Review manusia diperlukan.",
                   concerns=["Tidak ada audit independen."],suggested_questions=["Siapa reviewer yang berwenang?"])
    ]
