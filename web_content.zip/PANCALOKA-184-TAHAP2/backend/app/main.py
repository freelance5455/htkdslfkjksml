from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .registry import build_registry, five_loka_matrix, DNA_TOTAL
from .models import EvaluationRequest
from .orchestrator import evaluate
from .knowledge import KnowledgeStore, KnowledgeRecord

app = FastAPI(title="PancalokaTunggalPrana Firewall 184 — V7", version="7.0.0")
# Development/local HTML integration. No credentials are enabled.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)
registry = build_registry()
knowledge = KnowledgeStore()

@app.get("/health")
def health():
    return {"status": "TAHAN", "version": "V7", "production_ready": False}

@app.get("/v1/registry")
def get_registry():
    return {"dna_total": DNA_TOTAL, "rules": [r.model_dump() for r in registry]}

@app.get("/v1/matrix")
def get_matrix():
    return {"slots": 920, "validated": 0, "status": "TAHAN", "matrix": five_loka_matrix()}

@app.post("/v1/evaluate")
def eval_request(req: EvaluationRequest):
    result, proposals, event = evaluate(req)
    return {"result": result.model_dump(), "agent_proposals": [p.model_dump() for p in proposals], "audit_event": event}

@app.post("/v1/knowledge")
def add_knowledge(rec: KnowledgeRecord):
    return knowledge.add(rec)

@app.get("/v1/knowledge")
def list_knowledge():
    return {"records": [r.model_dump() for r in knowledge.records.values()], "approved_count": len(knowledge.approved())}
