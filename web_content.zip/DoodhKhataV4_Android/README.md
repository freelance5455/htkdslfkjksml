# दूध खाता — Proper Android App Project

यह V4.1 का Android WebView app project है। इसमें दूध, Credit/जमा, Extra Due, पिछला बकाया, बाकी/Advance और date-wise history का हिसाब शामिल है।

## Build
1. इस project को Android Studio या किसी compatible Android IDE में खोलें।
2. Gradle sync पूरा होने दें।
3. Build > Build APK(s) से debug APK बनाएं।

Application ID: `com.doodhkhata.v4`
Version: `4.1`
Min SDK: 23
Target/Compile SDK: 35

## Data
App का customer data WebView local storage में रखा जाता है और app के अंदर बना रहता है। App uninstall करने पर Android सामान्यतः app data हटा सकता है; महत्वपूर्ण हिसाब का backup अलग से रखना उचित है।
