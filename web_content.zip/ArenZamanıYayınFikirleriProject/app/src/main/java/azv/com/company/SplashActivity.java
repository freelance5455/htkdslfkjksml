package azv.com.company;

// Splash Activity placeholder