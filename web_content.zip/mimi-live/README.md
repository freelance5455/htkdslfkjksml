# Mimi Live – AI tự trò chuyện với người xem TikTok

## Cần chuẩn bị
1. Cài Node.js bản 20.6 trở lên: https://nodejs.org
2. Lấy API key Anthropic: https://console.anthropic.com
3. Một tài khoản TikTok đang LIVE (đang phát mới kết nối được)

## Cài đặt
```
cd mimi-live
npm install
copy .env.example .env      (Mac/Linux: cp .env.example .env)
```
Mở file `.env`, điền TIKTOK_USERNAME (không có dấu @) và ANTHROPIC_API_KEY.

## Chạy
```
npm start
```
Mở http://localhost:3000 → bấm "Đổi ảnh nhân vật" để dùng hình của bạn, bấm "Bật tiếng đọc".

## Đưa lên livestream
- Dùng TikTok LIVE Studio hoặc OBS: thêm nguồn "Browser/Window Capture" trỏ tới
  `http://localhost:3000/?clean` (bản không có nút, nền trong suốt).
- Âm thanh Mimi phát ra từ máy bạn: thu bằng "Desktop/Application audio capture".

## Tùy chỉnh
- Tính cách nhân vật: sửa `persona.txt`.
- Đổi model: sửa hằng số MODEL trong `server.js`.
- Chi phí: mỗi bình luận ≈ 1 lần gọi API nhỏ. Hàng đợi giữ tối đa 4 việc để không bị quá tải.

---
# BẢN MỚI: Mèo phản ứng như game (không cần nói chuyện)
- Quà nhỏ → mèo nhảy múa; quà vừa → nhảy cao + pháo; quà lớn → xoay vòng + mưa pháo.
- Thả tim → tim bay lên; theo dõi/chia sẻ → mèo nhảy và chào; có người vào → vẫy tay.
- Vắng người: mèo tự nhảy, tự nói câu mẫu, lâu quá thì ngủ gật.
- `AI_TALK=0` (mặc định): hoàn toàn miễn phí, không cần API key.
- `AI_TALK=1` + `ANTHROPIC_API_KEY`: mèo còn dùng AI trả lời bình luận.
- Nút "▶ Thử hiệu ứng" trên trang để xem trước các hoạt ảnh không cần live.

# TẠO APK (Android)
Server phải chạy ở nơi bật 24/7 (VPS hoặc dịch vụ như Render/Railway/Fly.io), vì
thư viện đọc TikTok live không chạy được bên trong app điện thoại.
1. Đưa thư mục này lên máy chủ, chạy `npm install && npm start`, lấy địa chỉ https://...
2. Tạo APK bọc địa chỉ đó, chọn 1 trong 2 cách:
   a) Không cần code: dùng PWABuilder.com hoặc Appilix.com, dán địa chỉ, tải APK.
   b) Dùng Android Studio:
      npm i -g @capacitor/cli && npm i @capacitor/core @capacitor/android
      npx cap init Mimi vn.mimi.live --web-dir=public
      (trong capacitor.config.json thêm: "server": {"url": "https://DIA-CHI-CUA-BAN", "cleartext": false})
      npx cap add android && npx cap open android  → Build > Build APK
3. Cài APK lên điện thoại, mở app, bật TikTok Live kiểu chia sẻ màn hình (Live Gaming)
   và chọn ứng dụng Mimi để phát.
