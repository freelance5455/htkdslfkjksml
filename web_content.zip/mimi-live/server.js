const fs = require('fs');
const http = require('http');
const express = require('express');
const { WebSocketServer } = require('ws');
const { WebcastPushConnection } = require('tiktok-live-connector');

const { TIKTOK_USERNAME, ANTHROPIC_API_KEY, PORT = 3000, AI_TALK = '0' } = process.env;
if (!TIKTOK_USERNAME) { console.error('Thiếu TIKTOK_USERNAME trong .env'); process.exit(1); }
const useAI = AI_TALK === '1' && !!ANTHROPIC_API_KEY;
let ai = null, persona = '';
if (useAI) {
  const Anthropic = require('@anthropic-ai/sdk');
  ai = new Anthropic({ apiKey: ANTHROPIC_API_KEY });
  persona = fs.readFileSync('persona.txt', 'utf8');
}

const app = express();
app.use(express.static('public'));
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
const broadcast = (m) => wss.clients.forEach((c) => c.readyState === 1 && c.send(JSON.stringify(m)));

// --- AI trả lời bình luận (tùy chọn) ---
let busy = false, history = [];
async function aiReply(user, comment) {
  if (!useAI || busy) return;
  busy = true;
  try {
    history.push({ role: 'user', content: `${user} bình luận: "${comment}"` });
    history = history.slice(-10);
    const r = await ai.messages.create({ model: 'claude-haiku-5-5', max_tokens: 150, system: persona, messages: history });
    const reply = r.content.map((b) => b.text || '').join('').trim();
    history.push({ role: 'assistant', content: reply });
    broadcast({ type: 'say', user, reply });
  } catch (e) { console.error('Lỗi AI:', e.message); }
  busy = false;
}

// --- TikTok LIVE -> sự kiện cho nhân vật ---
const tk = new WebcastPushConnection(TIKTOK_USERNAME);
const ev = (kind, user, extra = {}) => { broadcast({ type: 'event', kind, user, ...extra }); console.log(kind, user, extra.text || ''); };
tk.on('chat', (d) => { ev('chat', d.nickname, { text: d.comment }); aiReply(d.nickname, d.comment); });
tk.on('gift', (d) => {
  if (d.giftType === 1 && !d.repeatEnd) return; // chờ hết chuỗi quà liên tiếp
  const n = d.repeatCount || 1;
  ev('gift', d.nickname, { text: d.giftName, count: n, diamonds: (d.diamondCount || 1) * n });
});
tk.on('like', (d) => ev('like', d.nickname, { count: d.likeCount || 1, total: d.totalLikeCount }));
tk.on('follow', (d) => ev('follow', d.nickname));
tk.on('share', (d) => ev('share', d.nickname));
tk.on('member', (d) => ev('join', d.nickname));
tk.on('disconnected', () => { console.log('Mất kết nối, thử lại sau 10s'); setTimeout(connect, 10000); });
function connect() {
  tk.connect().then((s) => console.log(`Đã kết nối live @${TIKTOK_USERNAME} (room ${s.roomId})`))
    .catch((e) => { console.error('Chưa kết nối được (đã bật live chưa?):', e.message || e); setTimeout(connect, 15000); });
}
server.listen(PORT, () => { console.log(`Mở http://localhost:${PORT}  |  AI trả lời: ${useAI ? 'BẬT' : 'TẮT'}`); connect(); });
