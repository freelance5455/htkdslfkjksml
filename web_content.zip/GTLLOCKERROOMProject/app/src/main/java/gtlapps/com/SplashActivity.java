package gtlapps.com;

// Splash Activity placeholder