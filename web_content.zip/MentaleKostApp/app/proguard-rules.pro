# Règles ProGuard - non nécessaires pour ce projet (pas d'obfuscation requise).
