# MentaleKost — Application Android (hors Play Store)

Ce dossier est un **projet Android Studio complet**. Il transforme ton
application web (index.html/css/js) en vraie application Android installable
(fichier `.apk`), 100% hors-ligne, sans aucun passage par le Play Store.

## Pourquoi passer par un ordinateur une seule fois
Compiler un `.apk` nécessite les outils officiels d'Android (SDK + Gradle).
Je ne peux pas générer directement le fichier `.apk` fini depuis cette
conversation — il faut les compiler avec **Android Studio** (gratuit), sur un
ordinateur, une seule fois. Une fois le `.apk` obtenu, tu peux ensuite
l'envoyer et l'installer sur autant de téléphones que tu veux via
Xender/Bluetooth, sans ordinateur et sans internet.

## Étapes

### 1. Installer Android Studio
Télécharge-le gratuitement sur https://developer.android.com/studio (Windows/Mac/Linux).

### 2. Ouvrir le projet
- Lance Android Studio → "Open" → sélectionne ce dossier (`MentaleKostApp`).
- Laisse Android Studio synchroniser le projet (il télécharge automatiquement
  ce qu'il lui faut la première fois — connexion internet nécessaire
  uniquement pour cette étape de compilation, pas pour l'application finale).

### 3. Générer le fichier .apk
- Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- Une fois terminé, clique sur la notification "locate" (ou va dans
  `app/build/outputs/apk/debug/app-debug.apk`).

### 4. Partager et installer
- Envoie `app-debug.apk` par Xender ou Bluetooth vers n'importe quel téléphone Android.
- Sur le téléphone qui reçoit : ouvre le fichier `.apk` reçu pour l'installer.
- Android affichera un avertissement "Installation bloquée / source inconnue"
  (normal pour toute application installée hors Play Store) → autorise
  l'installation depuis cette source dans les paramètres proposés, puis réessaie.

## Ce que contient l'application
- Toute l'application (classes, élèves, notes, bulletins, paramètres, code
  d'accès) fonctionne **entièrement hors-ligne**, aucune permission internet
  n'est demandée — les données restent uniquement sur le téléphone.
- Les fichiers web sont dans `app/src/main/assets/` (index.html, css/, js/) :
  si tu me redemandes des modifications de l'appli plus tard, je peux te
  redonner juste ces 3 fichiers à remplacer ici, sans retoucher au reste du
  projet Android.
- Icône et nom de l'app ("MentaleKost") déjà configurés.

## Mettre à jour l'application plus tard
Si je te donne une nouvelle version de `index.html` / `style.css` / `app.js`,
remplace simplement les fichiers correspondants dans
`app/src/main/assets/` (et `app/src/main/assets/css/`,
`app/src/main/assets/js/`), puis refais l'étape 3 pour régénérer le `.apk`.
