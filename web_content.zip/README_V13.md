# WONDER SHIFT V13 — paquet réconcilié

## Principe
Cette version ne repart PAS de zéro. Elle est construite à partir de l'état Supabase déjà réalisé dans le projet : tables, compte Développeur, fonctions et politiques déjà créées.

## Corrections apportées après comparaison avec l'état Supabase connu
- Synchronisation étendue aux clôtures hebdomadaires et aux appareils.
- Les tables restreintes `sync_conflicts` / `report_exports` ne sont plus interrogées inutilement par les Agents.
- Les suppressions locales de catalogue ne laissent plus un enregistrement cloud actif : l'application désactive les services/tâches/consommables et synchronise leur nouvel état.
- Les créations/modifications de services, tâches et stock sont maintenant mises en file de synchronisation.
- Les mouvements de stock sont synchronisés.
- Les alertes de stock sont synchronisées.
- Le profil normalisé ne peut plus devenir vide lorsque `name` existe mais est vide.
- L'invitation d'un utilisateur renseigne `name/full_name` et `active/is_active` et nettoie le compte Auth si la création du profil échoue.
- CORS des Edge Functions peut être restreint via le secret `APP_ORIGIN`.
- Les anciennes policies sont réconciliées avant la création des policies V13.
- L'audit des opérations et remises est conservé.

## Supabase : une seule action utilisateur
Dans SQL Editor, exécuter uniquement :
`supabase-reconciliation-v13.sql`

Ne pas réexécuter les anciennes migrations v2-v11 et ne pas exécuter l'ancien `supabase-production-final.sql`.

## Edge Functions
Déployer :
- `manage-user`
- `send-report`

Puis configurer uniquement les secrets nécessaires côté Edge Function. Ne jamais mettre `service_role` dans l'application.

## Limite de validation
Le réseau d'exécution utilisé pour cette vérification ne peut pas joindre directement le domaine Supabase du projet. La comparaison avec Supabase est donc basée sur toutes les actions et SQL déjà établis dans le projet, plus l'inspection complète du paquet V12. Le test live Auth/RLS/sync devra être effectué après le déploiement.
