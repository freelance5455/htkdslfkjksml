const arena = document.getElementById("arena");
const scoreEl = document.getElementById("score");
const timeEl = document.getElementById("time");
const bestEl = document.getElementById("best");
const comboText = document.getElementById("comboText");
const startOverlay = document.getElementById("startOverlay");
const endOverlay = document.getElementById("endOverlay");
const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");
const finalScoreEl = document.getElementById("finalScore");
const finalComboEl = document.getElementById("finalCombo");
const finalRankEl = document.getElementById("finalRank");
const soundToggle = document.getElementById("soundToggle");
const diffBtns = document.querySelectorAll(".diff-btn");

let score = 0;
let timeLeft = 30;
let combo = 0;
let maxCombo = 0;
let bestScore = 0;
let timerId = null;
let spawnTimeout = null;
let running = false;
let soundOn = true;
let difficulty = "normal";
let audioCtx = null;

try {
  bestScore = parseInt(localStorage.getItem("neon_reflex_best") || "0", 10);
  if (isNaN(bestScore)) bestScore = 0;
} catch (e) {
  bestScore = 0;
}
bestEl.textContent = bestScore;

function playBeep(freq, duration) {
  if (!soundOn) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    if (!audioCtx) audioCtx = new AudioContextClass();
    if (audioCtx.state === "suspended") audioCtx.resume();

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}

soundToggle.addEventListener("click", () => {
  soundOn = !soundOn;
  soundToggle.textContent = soundOn ? "🔊" : "🔇";
});

diffBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    diffBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    difficulty = btn.dataset.speed;
  });
});

function clearTargets() {
  arena.querySelectorAll(".target, .float-score").forEach((el) => el.remove());
}

function showFloatText(x, y, text, color) {
  const el = document.createElement("div");
  el.className = "float-score";
  el.textContent = text;
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  el.style.color = color;
  arena.appendChild(el);
  setTimeout(() => el.remove(), 550);
}

function spawnTarget() {
  if (!running) return;
  clearTargets();

  const rect = arena.getBoundingClientRect();
  const isGold = Math.random() < 0.22;
  const size = difficulty === "pro" ? (isGold ? 48 : 54) : (isGold ? 56 : 64);

  const maxX = Math.max(10, rect.width - size - 16);
  const maxY = Math.max(10, rect.height - size - 16);
  const x = Math.floor(Math.random() * maxX) + 8;
  const y = Math.floor(Math.random() * maxY) + 8;

  const target = document.createElement("div");
  target.className = `target ${isGold ? "gold" : "normal"}`;
  target.style.width = `${size}px`;
  target.style.height = `${size}px`;
  target.style.left = `${x}px`;
  target.style.top = `${y}px`;
  target.textContent = isGold ? "+3" : "+1";

  const hitHandler = (e) => {
    e.stopPropagation();
    if (!running) return;

    const points = isGold ? 3 : 1;
    score += points;
    combo += 1;
    if (combo > maxCombo) maxCombo = combo;

    scoreEl.textContent = score;
    comboText.textContent = combo >= 3 ? `🔥 ${combo}x Combo Streak!` : "Nice hit!";

    playBeep(isGold ? 740 : 520, 0.08);
    try {
      if (navigator.vibrate) navigator.vibrate(15);
    } catch (err) {}

    showFloatText(x + size / 4, y, `+${points}`, isGold ? "#ffd166" : "#00e5ff");
    clearTimeout(spawnTimeout);
    spawnTarget();
  };

  target.addEventListener("pointerdown", hitHandler);
  arena.appendChild(target);

  const stayTime = difficulty === "pro" ? 950 : 1400;
  spawnTimeout = setTimeout(() => {
    if (!running) return;
    combo = 0;
    comboText.textContent = "Missed! Combo reset.";
    spawnTarget();
  }, stayTime);
}

arena.addEventListener("pointerdown", (e) => {
  if (!running) return;
  if (e.target === arena) {
    combo = 0;
    comboText.textContent = "Miss tap! Target par tap karo.";
    playBeep(200, 0.07);
  }
});

function endGame() {
  running = false;
  clearInterval(timerId);
  clearTimeout(spawnTimeout);
  clearTargets();

  if (score > bestScore) {
    bestScore = score;
    bestEl.textContent = bestScore;
    try {
      localStorage.setItem("neon_reflex_best", String(bestScore));
    } catch (e) {}
  }

  finalScoreEl.textContent = score;
  finalComboEl.textContent = `${maxCombo}x`;

  if (score >= 45) finalRankEl.textContent = "God-Tier Reflex! ⚡";
  else if (score >= 25) finalRankEl.textContent = "Pro Gamer Speed! 🔥";
  else finalRankEl.textContent = "Good Warmup! 💪";

  endOverlay.classList.remove("hidden");
  playBeep(330, 0.22);
}

function startGame() {
  score = 0;
  timeLeft = 30;
  combo = 0;
  maxCombo = 0;
  running = true;

  scoreEl.textContent = "0";
  timeEl.textContent = "30s";
  comboText.textContent = "Go! Targets tap karo!";
  startOverlay.classList.add("hidden");
  endOverlay.classList.add("hidden");

  spawnTarget();

  clearInterval(timerId);
  timerId = setInterval(() => {
    timeLeft -= 1;
    timeEl.textContent = `${timeLeft}s`;
    if (timeLeft <= 0) {
      endGame();
    }
  }, 1000);
}

startBtn.addEventListener("click", startGame);
restartBtn.addEventListener("click", startGame);
