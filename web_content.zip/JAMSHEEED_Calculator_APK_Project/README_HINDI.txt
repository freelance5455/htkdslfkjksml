JAMSHEEED Calculator - APK Project

यह प्रोजेक्ट आपकी HTML calculator को Android ऐप में पैक करता है।

APK बनाने का आसान तरीका:
1. Android Studio इंस्टॉल करें।
2. इस पूरे folder को Android Studio में Open करें।
3. Gradle sync पूरा होने दें।
4. ऊपर Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK बनने के बाद उसे अपने Android फोन में इंस्टॉल कर सकते हैं।

Project package: com.jamsheed.calculator
App name: JAMSHEEED Calculator
Minimum Android: 6.0 (API 23)

नोट: इस चैट में सीधे signed APK बनाना संभव नहीं है क्योंकि Android SDK/Gradle build environment उपलब्ध नहीं है। यह पूरा APK-ready Android Studio project है।
