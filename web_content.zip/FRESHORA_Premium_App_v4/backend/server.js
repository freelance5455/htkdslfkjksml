const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {URL}=require('url');
const ROOT=path.join(__dirname,'..');
const DATA_DIR=path.join(__dirname,'data');
const DB_FILE=path.join(DATA_DIR,'db.json');
const PORT=process.env.PORT||3000;
if(!fs.existsSync(DATA_DIR))fs.mkdirSync(DATA_DIR,{recursive:true});
if(!fs.existsSync(DB_FILE))fs.writeFileSync(DB_FILE,JSON.stringify({users:[],bookings:[],sessions:[]},null,2));
function db(){return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}
function save(x){fs.writeFileSync(DB_FILE,JSON.stringify(x,null,2));}
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PATCH,OPTIONS'});res.end(JSON.stringify(data));}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>1e6)req.destroy();});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});});}
function id(prefix){return prefix+'-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(2).toString('hex').toUpperCase();}
function hash(p,s=crypto.randomBytes(16).toString('hex')){return s+':'+crypto.scryptSync(p,s,64).toString('hex');}
function verify(p,stored){const [s,h]=String(stored).split(':');try{return crypto.timingSafeEqual(Buffer.from(h,'hex'),crypto.scryptSync(p,s,64));}catch{return false;}}
function token(){return crypto.randomBytes(32).toString('hex');}
function auth(req,data){const h=req.headers.authorization||'';const t=h.startsWith('Bearer ')?h.slice(7):'';const s=data.sessions.find(x=>x.token===t);return s?data.users.find(u=>u.id===s.userId):null;}
function safeUser(u){return {id:u.id,name:u.name,identity:u.identity,email:u.email||'',phone:u.phone||'',role:u.role||'customer',createdAt:u.createdAt};}
function serve(req,res){let pathname=new URL(req.url,'http://localhost').pathname; if(pathname==='/')pathname='/index.html'; if(pathname==='/admin')pathname='/admin/index.html'; const file=path.join(ROOT,path.normalize(pathname)); if(!file.startsWith(ROOT)||!fs.existsSync(file)||fs.statSync(file).isDirectory())return json(res,404,{error:'Not found'}); const ext=path.extname(file); const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});fs.createReadStream(file).pipe(res);}
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS')return json(res,204,{});
 if(!req.url.startsWith('/api/'))return serve(req,res);
 const u=new URL(req.url,'http://localhost');const p=u.pathname;let data=db();
 try{
  if(req.method==='POST'&&p==='/api/auth/signup'){
   const b=await body(req);if(!b.name||!b.identity||!b.password||b.password.length<4)return json(res,400,{error:'Name, identity and 4+ character password are required.'});
   if(data.users.some(x=>x.identity.toLowerCase()===String(b.identity).toLowerCase()))return json(res,409,{error:'Account already exists.'});
   const isEmail=String(b.identity).includes('@');const user={id:id('USR'),name:String(b.name).trim(),identity:String(b.identity).trim(),email:isEmail?String(b.identity).trim():'',phone:isEmail?'':String(b.identity).trim(),passwordHash:hash(b.password),role:'customer',createdAt:new Date().toISOString()};data.users.push(user);const t=token();data.sessions.push({token:t,userId:user.id,createdAt:Date.now()});save(data);return json(res,201,{token:t,user:safeUser(user),profile:{name:user.name,email:user.email,phone:user.phone,district:'Trivandrum',address:''}});
  }
  if(req.method==='POST'&&p==='/api/auth/login'){
   const b=await body(req);const user=data.users.find(x=>x.identity.toLowerCase()===String(b.identity||'').toLowerCase());if(!user||!verify(b.password||'',user.passwordHash))return json(res,401,{error:'Invalid login details.'});const t=token();data.sessions.push({token:t,userId:user.id,createdAt:Date.now()});save(data);return json(res,200,{token:t,user:safeUser(user)});
  }
  if(req.method==='POST'&&p==='/api/auth/logout'){const user=auth(req,data);const t=(req.headers.authorization||'').slice(7);data.sessions=data.sessions.filter(x=>x.token!==t);save(data);return json(res,200,{ok:true});}
  if(p==='/api/me'&&req.method==='GET'){const user=auth(req,data);if(!user)return json(res,401,{error:'Login required.'});return json(res,200,{user:safeUser(user)});}
  if(p==='/api/bookings'&&req.method==='POST'){
   const user=auth(req,data);const b=await body(req);if(!b.name||!b.phone||!b.service||!b.district)return json(res,400,{error:'Missing required booking fields.'});if(!['Trivandrum','Kollam'].includes(b.district))return json(res,400,{error:'FRESHORA currently accepts bookings only from Trivandrum and Kollam.'});
   const booking={...b,id:id('FR'),status:'Pending',createdAt:new Date().toISOString(),userId:user?.id||null};delete booking.password;data.bookings.unshift(booking);save(data);return json(res,201,{booking});
  }
  if(p==='/api/bookings'&&req.method==='GET'){const user=auth(req,data);let list=user?data.bookings.filter(x=>x.userId===user.id):data.bookings;return json(res,200,{bookings:list});}
  if(p.startsWith('/api/bookings/')&&req.method==='PATCH'){
   const user=auth(req,data);if(!user||user.role!=='admin')return json(res,403,{error:'Admin access required.'});const b=data.bookings.find(x=>x.id===p.split('/').pop());if(!b)return json(res,404,{error:'Booking not found.'});const patch=await body(req);if(patch.status)b.status=patch.status;save(data);return json(res,200,{booking:b});
  }
  if(p==='/api/admin/bookings'&&req.method==='GET'){const user=auth(req,data);if(!user||user.role!=='admin')return json(res,403,{error:'Admin access required.'});return json(res,200,{bookings:data.bookings});}
  return json(res,404,{error:'API route not found.'});
 }catch(e){console.error(e);return json(res,500,{error:'Server error.'});}
});
server.listen(PORT,()=>console.log(`FRESHORA backend running: http://localhost:${PORT}`));
