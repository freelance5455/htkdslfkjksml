# FRESHORA Backend

Node.js backend for the FRESHORA Premium App. It uses a small JSON database so the project can run without a paid cloud service.

## Run

1. Install Node.js 18+.
2. Open a terminal in this `backend` folder.
3. Run:

```bash
npm start
```

4. Open `http://localhost:3000`.
5. Admin page: `http://localhost:3000/admin/`

The frontend automatically uses `/api` when served by this backend.

## API

- `POST /api/auth/signup`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/me`
- `POST /api/bookings`
- `GET /api/bookings`
- `GET /api/admin/bookings`
- `PATCH /api/bookings/:id`

## Production note

This backend is intended as a simple starter backend. For production, move the database to PostgreSQL/Supabase, use HTTPS, add rate limiting, email/phone OTP via a trusted provider, secure admin provisioning, backups, and a real payment gateway. Never commit secrets or payment credentials to the frontend.
