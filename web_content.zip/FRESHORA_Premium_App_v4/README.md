# FRESHORA Premium App v4 — Mobile Business App

A mobile-first, premium black + gold frontend app for FRESHORA Cleaning Services.

## Included
- Premium responsive app UI
- Trivandrum + Kollam service-area restriction in booking
- Phone/email login + signup demo using localStorage
- Saved customer profile
- Smart price estimator using FRESHORA's provided ranges
- 6 services: Deep, Normal, Water Tank, Well, Bathroom, Sofa
- Booking history with local status timeline
- WhatsApp booking / follow-up flow
- Shop section with cart and WhatsApp order request
- Subscription calculator and plan enquiry
- UPI ID + bank transfer details + UPI app intent
- UTR submission through WhatsApp
- Installable PWA shell + service worker caching
- Install prompt banner
- Local admin dashboard with status updates + JSON/CSV export
- FAQ / support section

## Important
This is a frontend/static app. The login/signup is a device-local demo and does not send real OTPs or provide secure multi-device authentication. Real authentication, cloud bookings, staff accounts, live order status, online payments and a shared admin dashboard need a backend such as Firebase, Supabase, or a custom API.

The shop currently uses placeholder products/prices because no real catalogue or pricing was supplied.

## Run
Open `index.html` in a browser. PWA install/service-worker features work best when served from a small local web server or hosted site.

## Backend integration (v5)
The `backend/` folder now contains a Node.js API with persistent customer accounts and cloud-style booking flow. Run `npm start` inside `backend/`, then open `http://localhost:3000`. The frontend uses the API when available and falls back to local demo storage when opened directly without a server.

## Shop
The Shop is intentionally marked **Coming Soon**. Tapping Shop opens a premium Coming Soon dialog and WhatsApp notification option. Product/cart UI remains in the project for future activation.
