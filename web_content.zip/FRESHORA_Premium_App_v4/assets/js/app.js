const WA_NUMBER = '918086868808';
const WA_MESSAGE_LINK = 'https://wa.me/message/ZD74JPVIVAGGM1';
const UPI_ID = 'ak1sshi4kklml-1@oksbi';
const RATES = {
  deep:{label:'Deep Cleaning',unit:'sq.ft',min:5,max:10,kind:'area'},
  normal:{label:'Normal Cleaning',unit:'sq.ft',min:4,max:5,kind:'area'},
  tank:{label:'Water Tank',unit:'litre',min:1.20,max:1.60,kind:'area'},
  well:{label:'Well Cleaning',unit:'job',min:4500,max:8000,kind:'fixed'},
  bathroom:{label:'Bathroom',unit:'bathroom',min:1500,max:2000,kind:'area'},
  sofa:{label:'Sofa Cleaning',unit:'quote',min:0,max:0,kind:'quote'}
};
let deferredPrompt = null;
let cart = JSON.parse(localStorage.getItem('freshora_cart')||'[]');
const API_BASE = localStorage.getItem('freshora_api') || '/api';
let apiToken = localStorage.getItem('freshora_api_token') || '';
async function api(path, options={}){
  try{
    const headers={'Content-Type':'application/json',...(options.headers||{})};
    if(apiToken) headers.Authorization='Bearer '+apiToken;
    const res=await fetch(API_BASE+path,{...options,headers});
    const data=await res.json().catch(()=>({}));
    if(!res.ok) throw new Error(data.error||'API request failed');
    return data;
  }catch(err){ return {error:err.message,offline:true}; }
}

const $ = id => document.getElementById(id);
function money(v){ return '₹'+Number(v||0).toLocaleString('en-IN',{maximumFractionDigits:2}); }
function escapeHTML(s=''){ return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function toast(msg){ const t=$('toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(window.__toast); window.__toast=setTimeout(()=>t.classList.remove('show'),2600); }
function openWhatsApp(msg='Hello FRESHORA, I need a cleaning service enquiry.'){ window.open(WA_NUMBER ? 'https://wa.me/'+WA_NUMBER+'?text='+encodeURIComponent(msg) : WA_MESSAGE_LINK,'_blank'); }
function openWhatsAppDirect(){ window.open(WA_MESSAGE_LINK,'_blank'); }
function copyText(text){ if(navigator.clipboard){navigator.clipboard.writeText(text).then(()=>toast('Copied to clipboard.'));}else{toast('Copy is not supported on this browser.');} }
function openUpi(){ window.location.href='upi://pay?pa='+encodeURIComponent(UPI_ID)+'&pn='+encodeURIComponent('FRESHORA Premium Cleaning'); }
function showNotifications(){ toast('No new notifications.'); $('notifDot').classList.remove('show'); }

function openAuth(){ $('authGate').classList.remove('hidden'); document.body.classList.add('modal-open'); }
function closeAuth(){ $('authGate').classList.add('hidden'); document.body.classList.remove('modal-open'); }
function switchAuth(mode){
  document.querySelectorAll('.auth-tab').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));
  $('authSubtitle').textContent=mode==='login'?'Login with your phone number or email.':'Create a customer account on this device.';
  $('nameOptional').textContent=mode==='login'?'(optional)':'*';
  $('authName').required=mode==='signup'; $('authSubmit').innerHTML=mode==='login'?'Login <span>↗</span>':'Create account <span>↗</span>';
  $('authForm').dataset.mode=mode;
}
function togglePassword(){ const i=$('authPassword'); i.type=i.type==='password'?'text':'password'; }
function guestLogin(){ localStorage.setItem('freshora_auth',JSON.stringify({guest:true,name:'Guest'})); closeAuth(); syncAccountUI(); toast('Continuing as Guest.'); }
$('authForm').addEventListener('submit',async e=>{
  e.preventDefault(); const mode=e.currentTarget.dataset.mode||'login';
  const identity=$('authIdentity').value.trim(); const password=$('authPassword').value;
  if(mode==='signup' && !$('authName').value.trim()) return toast('Please enter your name.');
  if(!identity||password.length<4) return toast('Please enter a valid login and 4+ character password.');
  const endpoint=mode==='signup'?'/auth/signup':'/auth/login';
  const payload=mode==='signup'?{name:$('authName').value.trim(),identity,password}:{identity,password};
  const result=await api(endpoint,{method:'POST',body:JSON.stringify(payload)});
  if(!result.error){
    apiToken=result.token||''; if(apiToken)localStorage.setItem('freshora_api_token',apiToken);
    const account=result.user||{name:$('authName').value.trim()||identity,identity,guest:false};
    localStorage.setItem('freshora_auth',JSON.stringify(account));
    if(result.profile) localStorage.setItem('freshora_profile',JSON.stringify(result.profile));
    else if(mode==='signup'&&!getProfile().name) localStorage.setItem('freshora_profile',JSON.stringify({name:account.name,phone:identity.includes('@')?'':identity,email:identity.includes('@')?identity:'',address:'',district:'Trivandrum'}));
    closeAuth(); loadProfile(); syncAccountUI(); toast(mode==='signup'?'Account created securely.':'Welcome back.'); return;
  }
  // Demo/offline fallback keeps the UI usable when the backend is not running.
  const account={name:$('authName').value.trim() || (identity.includes('@')?identity.split('@')[0]:identity),identity,password,guest:false};
  localStorage.setItem('freshora_auth',JSON.stringify(account)); closeAuth(); syncAccountUI(); toast('Backend unavailable — saved as local demo.');
});
async function logoutLocal(){ await api('/auth/logout',{method:'POST'}); apiToken=''; localStorage.removeItem('freshora_api_token'); localStorage.removeItem('freshora_auth'); toast('Logged out.'); syncAccountUI(); }
function getProfile(){ return JSON.parse(localStorage.getItem('freshora_profile')||'{}'); }
function openAccount(){ const auth=JSON.parse(localStorage.getItem('freshora_auth')||'null'); if(!auth||auth.guest===undefined){openAuth();return;} location.hash='#profile'; }
function syncAccountUI(){ const p=getProfile(); const a=JSON.parse(localStorage.getItem('freshora_auth')||'null'); const name=p.name||a?.name||'Guest'; $('profileInitial').textContent=name.trim().charAt(0).toUpperCase()||'G'; $('profileChipName').textContent=name==='Guest'?'Guest':name.split(' ')[0]; $('profileAvatar').textContent=$('profileInitial').textContent; $('profileWelcome').textContent=name; }

function selectService(type){ $('service').value=type; location.hash='#booking'; updateBookingFields(); setTimeout(()=>{$('qty').focus();},200); }
function updateBookingFields(){
  const type=$('service').value; const r=RATES[type]; const label=$('qtyLabel'); const qty=$('qty');
  $('serviceExtra').classList.add('hidden'); $('extraQty').value='';
  if(type==='deep'||type==='normal'){label.textContent='Area (sq.ft) *'; qty.placeholder='e.g. 1000'; qty.required=true;}
  else if(type==='tank'){label.textContent='Tank capacity (litres) *'; qty.placeholder='e.g. 1000'; qty.required=true;}
  else if(type==='bathroom'){label.textContent='Number of bathrooms *'; qty.placeholder='e.g. 2'; qty.required=true;}
  else if(type==='well'){label.textContent='Number of wells *'; qty.placeholder='e.g. 1'; qty.required=true;}
  else {label.textContent='Sofa quantity / size *'; qty.placeholder='Enter quantity'; qty.required=true; $('serviceExtra').classList.remove('hidden'); $('extraLabel').textContent='Sofa notes / seats (optional)'; $('extraQty').placeholder='e.g. 5 seats';}
  calculateBooking();
}
function calculateBooking(){
  const type=$('service').value, qty=Number($('qty').value)||0, r=RATES[type]; let low=r.min, high=r.max;
  if(r.kind==='quote'){ $('estimate').textContent='Quote'; $('estimateText').textContent='Final price after sofa size/type review'; $('rangeMin').textContent='Quote on request'; $('rangeMax').textContent=''; return {type,qty,low:0,high:0,r}; }
  if(r.kind==='area'||type==='well'){ low=qty*r.min; high=qty*r.max; }
  if(!qty){ $('estimate').textContent=money(0); $('rangeMin').textContent=''; $('rangeMax').textContent=''; $('estimateText').textContent=r.label; return {type,qty,low,high,r}; }
  $('estimate').textContent=money(low)+' – '+money(high);
  $('rangeMin').textContent='Approx. from '+money(low); $('rangeMax').textContent='Up to about '+money(high);
  $('estimateText').textContent=`${r.label} • ${r.unit}`;
  return {type,qty,low,high,r};
}
function fillFromProfile(){ const p=getProfile(); if(!p.name&&!p.phone&&!p.address){toast('No saved profile yet.');return;} $('bname').value=p.name||''; $('bphone').value=p.phone||''; $('address').value=p.address||''; $('district').value=p.district||'Trivandrum'; toast('Saved profile filled.'); }

$('service').addEventListener('change',updateBookingFields); $('qty').addEventListener('input',calculateBooking);
$('bookingForm').addEventListener('submit',async e=>{
  e.preventDefault(); const c=calculateBooking();
  const phone=$('bphone').value.trim(); if(phone.replace(/\D/g,'').length<10) return toast('Please enter a valid phone number.');
  const booking={id:'FR-'+Date.now().toString().slice(-8),createdAt:new Date().toISOString(),name:$('bname').value.trim(),phone,service:c.r.label,type:c.type,quantity:c.qty,propertyType:$('propertyType').value,district:$('district').value,date:$('date').value,time:$('time').value,address:$('address').value.trim(),notes:$('notes').value.trim(),approxLow:c.low,approxHigh:c.high,status:'Pending'};
  const saved=await api('/bookings',{method:'POST',body:JSON.stringify(booking)});
  if(saved.error){ const list=getBookings(); list.unshift(booking); localStorage.setItem('freshora_bookings',JSON.stringify(list)); }
  else { booking.id=saved.booking.id; booking.status=saved.booking.status; const list=getBookings(); list.unshift(booking); localStorage.setItem('freshora_bookings',JSON.stringify(list)); }
  localStorage.setItem('freshora_profile',JSON.stringify({name:booking.name,phone:booking.phone,email:getProfile().email||'',address:booking.address,district:booking.district}));
  renderBookings(); loadProfile(); syncAccountUI();
  const msg=`FRESHORA BOOKING\nBooking ID: ${booking.id}\nCustomer: ${booking.name}\nPhone: ${booking.phone}\nDistrict: ${booking.district}\nService: ${booking.service}\nArea/Quantity: ${booking.quantity}\nApprox. Estimate: ${booking.approxLow?money(booking.approxLow)+' – '+money(booking.approxHigh):'Quote required'}\nDate: ${booking.date||'Not specified'}\nTime: ${booking.time||'Not specified'}\nAddress: ${booking.address}\nNotes: ${booking.notes||'None'}\n\nFinal quote is subject to job review.`;
  openWhatsApp(msg); toast('Booking saved. Opening WhatsApp…');
  e.target.reset(); $('district').value=booking.district; updateBookingFields();
});

function getBookings(){ return JSON.parse(localStorage.getItem('freshora_bookings')||'[]'); }
async function hydrateBookings(){
  const result=await api('/bookings');
  if(!result.error && Array.isArray(result.bookings)){ localStorage.setItem('freshora_bookings',JSON.stringify(result.bookings)); renderBookings(); }
}
function statusSteps(status){ return ['Pending','Confirmed','In Progress','Completed'].map(x=>`<span class="${x===status?'on':''}">${x}</span>`).join(''); }
function renderBookings(){ const list=getBookings(); const box=$('bookingHistory'); if(!list.length){box.innerHTML=`<div class="empty-card"><div class="empty-icon">☷</div><h3>No bookings yet</h3><p>Your saved bookings will appear here.</p><a class="gold-btn" href="#booking">Book a service</a></div>`;return;}
  box.innerHTML=list.map(x=>`<article class="history-card"><div class="history-top"><div><span class="booking-id">${escapeHTML(x.id)}</span><h3>${escapeHTML(x.service)}</h3></div><span class="status-pill">${escapeHTML(x.status||'Pending')}</span></div><div class="history-meta"><span>◈ ${escapeHTML(x.district)}</span><span>▣ ${escapeHTML(x.date||'Date not set')}</span><span>⌂ ${escapeHTML(x.address)}</span></div><div class="status-steps">${statusSteps(x.status||'Pending')}</div><div class="history-bottom"><span>${x.approxLow?money(x.approxLow)+' – '+money(x.approxHigh):'Final quote required'}</span><button class="outline-btn" onclick="sendBookingAgain('${x.id}')">WhatsApp</button></div></article>`).join(''); }
function sendBookingAgain(id){ const b=getBookings().find(x=>x.id===id); if(!b)return; openWhatsApp(`FRESHORA FOLLOW-UP\nBooking ID: ${b.id}\nCustomer: ${b.name}\nService: ${b.service}\nDistrict: ${b.district}\nPlease provide an update on this booking.`); }

function saveProfile(){ const p={name:$('pname').value.trim(),phone:$('pphone').value.trim(),email:$('pemail').value.trim(),district:$('pdistrict').value,address:$('paddress').value.trim()}; localStorage.setItem('freshora_profile',JSON.stringify(p)); const a=JSON.parse(localStorage.getItem('freshora_auth')||'null'); if(a&&!a.guest){a.name=p.name||a.name;localStorage.setItem('freshora_auth',JSON.stringify(a));} syncAccountUI(); $('profileMsg').textContent='Profile saved locally on this device.'; toast('Profile saved.'); }
function loadProfile(){ const p=getProfile(); $('pname').value=p.name||''; $('pphone').value=p.phone||''; $('pemail').value=p.email||''; $('pdistrict').value=p.district||'Trivandrum'; $('paddress').value=p.address||''; syncAccountUI(); }

function calculateSubscription(){ const area=Number($('subArea').value)||0, blocks=Math.max(1,Number($('subBlocks').value)||1); const monthly=(area/1000)*5000*blocks; $('subMonth').textContent=money(monthly); $('subYear').textContent=money(monthly*12); const code=$('redeem').value.trim(); $('redeemMsg').textContent=code?'Redeem code received. Final discount can be verified by FRESHORA.':''; return {area,blocks,monthly}; }
$('subArea').addEventListener('input',calculateSubscription); $('subBlocks').addEventListener('input',calculateSubscription);
function requestPlan(name){ openWhatsApp(`FRESHORA SUBSCRIPTION ENQUIRY\nPlan: ${name}\nPlease share availability and final confirmation.`); }
function requestCustomPlan(){ const x=calculateSubscription(); openWhatsApp(`FRESHORA CUSTOM PLAN ENQUIRY\nArea: ${x.area} sq.ft\nBlocks: ${x.blocks}\nApprox monthly: ${money(x.monthly)}\nApprox yearly: ${money(x.monthly*12)}\nRedeem code: ${$('redeem').value.trim()||'None'}`); }
function sendUTR(){ const utr=$('utr').value.trim(); if(!utr)return toast('Enter the UTR/reference number first.'); openWhatsApp(`FRESHORA UTR SUBMISSION\nUTR: ${utr}`); toast('Opening WhatsApp…'); }

function addToCart(name,price){ cart.push({name,price}); localStorage.setItem('freshora_cart',JSON.stringify(cart)); updateCartCount(); toast(name+' added to cart.'); }
function updateCartCount(){ $('cartCount').textContent=cart.length; }
function openCart(){
  const layer=$('modalLayer'); layer.classList.remove('hidden'); document.body.classList.add('modal-open');
  const rows=cart.length?cart.map((x,i)=>`<div class="cart-row"><div><b>${escapeHTML(x.name)}</b><small>${escapeHTML(x.price)}</small></div><button class="text-btn" onclick="removeFromCart(${i})">Remove</button></div>`).join(''):`<div class="empty-cart"><span>▣</span><b>Your cart is empty</b><small>Add a cleaning product to create an order request.</small></div>`;
  layer.innerHTML=`<div class="modal-card"><button class="modal-close" onclick="closeModal()">×</button><div class="eyebrow">YOUR CART</div><h2>Shop order request</h2><div>${rows}</div>${cart.length?`<button class="gold-btn wide" onclick="checkoutCart()">Send order request on WhatsApp ↗</button>`:''}</div>`;
}
function removeFromCart(i){cart.splice(i,1);localStorage.setItem('freshora_cart',JSON.stringify(cart));updateCartCount();openCart();}
function checkoutCart(){ const items=cart.map(x=>`• ${x.name} — ${x.price}`).join('\n'); openWhatsApp(`FRESHORA SHOP ORDER REQUEST\n${items}\n\nPlease share availability and final total.`); closeModal(); }
function closeModal(){ $('modalLayer').classList.add('hidden'); document.body.classList.remove('modal-open'); }
function showShopComingSoon(){
  const layer=$('modalLayer'); layer.classList.remove('hidden'); document.body.classList.add('modal-open');
  layer.innerHTML=`<div class="modal-card coming-soon-card"><button class="modal-close" onclick="closeModal()">×</button><div class="coming-icon">✦</div><div class="eyebrow">FRESHORA SHOP</div><h2>Coming Soon</h2><p>Our premium cleaning products and home-care essentials are being prepared. Shop will open soon.</p><button class="gold-btn wide" onclick="openWhatsApp('Hello FRESHORA, I want to know when the Shop will launch.')">Notify me on WhatsApp ↗</button></div>`;
}
function openShop(){ location.hash='#shop'; setTimeout(showShopComingSoon,80); }
function filterShop(cat){ document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.filter===cat)); document.querySelectorAll('.shop-card[data-cat]').forEach(c=>c.classList.toggle('hidden',cat!=='all'&&c.dataset.cat!==cat)); }

function maybeInstall(){ if(localStorage.getItem('freshora_install_dismissed'))return; setTimeout(()=>{ if(deferredPrompt)$('installBanner').classList.remove('hidden');},1600); }
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;maybeInstall();});
async function installApp(){ if(!deferredPrompt){toast('Browser install is not available right now.');return;} deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; dismissInstall(); }
function dismissInstall(){ $('installBanner').classList.add('hidden'); localStorage.setItem('freshora_install_dismissed','1'); }

if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});

document.addEventListener('DOMContentLoaded',()=>{
  switchAuth('login'); updateBookingFields(); loadProfile(); renderBookings(); hydrateBookings(); calculateSubscription(); updateCartCount();
  const today=new Date().toISOString().slice(0,10); $('date').min=today; $('notifDot').classList.toggle('show',!localStorage.getItem('freshora_notif_seen'));
  $('notifDot').addEventListener('click',()=>localStorage.setItem('freshora_notif_seen','1'));
  maybeInstall();
});

// Close modal when tapping the backdrop.
$('modalLayer').addEventListener('click',e=>{if(e.target.id==='modalLayer')closeModal();});
