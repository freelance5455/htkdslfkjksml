K-DRAMA PLUS — PROTOTIPO WEB

Abrir index.html en un navegador para probar el diseño.
Incluye catálogo ficticio, búsqueda, filtros por país/género, favoritos, navegación y una pantalla de reproductor integrado de demostración.

No incluye episodios completos licenciados ni APK. Los nombres e historias del catálogo son ejemplos ficticios; los episodios están deshabilitados hasta conectar archivos de video autorizados o un proveedor que permita la reproducción dentro de la aplicación.

Es un diseño original inspirado en funciones comunes de apps de mini dramas. No copia el código, la marca ni los recursos de DramaBox.
