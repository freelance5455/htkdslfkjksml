OURSON RUNNER BSW — version 1
========================

CONTENU
- index.html : écran du jeu
- style.css  : interface adaptée au mobile
- game.js    : gameplay, dessin, obstacles, miel, score et meilleur score
- manifest.json : informations pour une installation de type PWA

TESTER SUR ANDROID
1. Décompressez le ZIP dans un dossier.
2. Ouvrez index.html avec un navigateur ou un éditeur proposant un aperçu web.
   Certaines fonctions PWA/localStorage peuvent être limitées si le fichier est ouvert directement.
3. Pour un test fiable, hébergez le dossier sur un service HTTPS statique.
4. Ouvrez la page hébergée sur le téléphone et touchez JOUER.
5. Touchez l'écran pour sauter. Vous pouvez aussi appuyer sur ESPACE dans un navigateur avec clavier.

IMPORTANT : ceci est une première version jouable en HTML5, pas encore un APK.
Pour produire un APK natif, il faut empaqueter les fichiers web avec Capacitor et compiler avec Android SDK/Gradle.
La compilation native est généralement beaucoup plus simple sur un ordinateur. Depuis un téléphone uniquement,
il faut utiliser un environnement cloud de compilation ou un service de build compatible ; les étapes exactes
dépendent du service choisi.

COMMANDES
- Toucher l'écran : sauter
- Espace / flèche haut : sauter
- JOUER / REJOUER : démarrer la partie

FONCTIONNALITÉS
- Ourson dessiné en code (aucune image externe nécessaire)
- Obstacles en forme de troncs
- Pots de miel à collecter
- Score, compteur de miel, meilleur score sauvegardé localement
- Difficulté progressive et petit effet sonore de saut
