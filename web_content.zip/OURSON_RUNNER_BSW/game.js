(() => {
'use strict';
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const overlay = document.getElementById('overlay');
const playBtn = document.getElementById('playBtn');
const scoreEl = document.getElementById('score');
const honeyEl = document.getElementById('honey');
const bestEl = document.getElementById('best');
const overlayTitle = document.getElementById('overlayTitle');
const overlayText = document.getElementById('overlayText');

let W=0,H=0,ground=0,last=0,gameState='menu',score=0,honey=0,best=0,speed=310,spawnTimer=0,honeyTimer=0,elapsed=0;
let obstacles=[],honeys=[],particles=[],clouds=[];
const bear={x:90,y:0,w:56,h:62,vy:0,onGround:true,run:0};
const gravity=1750;
try { best=Number(localStorage.getItem('oursonBest')||0); } catch(e) {}
bestEl.textContent=best;

function resize(){
 const dpr=Math.min(window.devicePixelRatio||1,2);
 W=window.innerWidth; H=window.innerHeight;
 canvas.width=Math.floor(W*dpr); canvas.height=Math.floor(H*dpr);
 canvas.style.width=W+'px';canvas.style.height=H+'px';
 ctx.setTransform(dpr,0,0,dpr,0,0);
 ground=H*0.79;
 bear.x=Math.max(45,W*0.14);
 if(bear.onGround) bear.y=ground-bear.h;
 clouds=[{x:W*.18,y:H*.2,s:1},{x:W*.65,y:H*.14,s:.8},{x:W*.88,y:H*.28,s:.65}];
}
window.addEventListener('resize',resize);
resize();

function reset(){
 score=0;honey=0;speed=Math.max(300,W*.42);spawnTimer=.9;honeyTimer=1.3;elapsed=0;
 obstacles=[];honeys=[];particles=[];
 bear.vy=0;bear.onGround=true;bear.y=ground-bear.h;bear.run=0;
 scoreEl.textContent='0';honeyEl.textContent='0';
}
function start(){reset();gameState='playing';overlay.classList.add('hidden');last=performance.now();requestAnimationFrame(loop);}
function endGame(){
 gameState='over';
 if(score>best){best=score;try{localStorage.setItem('oursonBest',String(best));}catch(e){}}
 bestEl.textContent=best;
 overlayTitle.textContent='Oups !';
 overlayText.textContent=`L'ourson a parcouru ${score} mètres et ramassé ${honey} pots de miel. On recommence ?`;
 playBtn.textContent='REJOUER ↻';
 overlay.classList.remove('hidden');
}
function jump(){
 if(gameState!=='playing')return;
 if(bear.onGround){bear.vy=-Math.min(690,H*1.05);bear.onGround=false; soundJump(); }
}
playBtn.addEventListener('click',start);
canvas.addEventListener('pointerdown',e=>{if(gameState==='playing'){e.preventDefault();jump();}});
window.addEventListener('keydown',e=>{if(e.code==='Space'||e.code==='ArrowUp'){e.preventDefault();if(gameState==='playing')jump();else start();}});
function soundJump(){
 try{
 const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
 const ac=new AC(),o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(420,ac.currentTime);o.frequency.exponentialRampToValueAtTime(680,ac.currentTime+.09);g.gain.setValueAtTime(.07,ac.currentTime);g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+.13);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+.14);o.onended=()=>ac.close();
 }catch(e){}
}
function roundedRect(x,y,w,h,r,fill,stroke){
 ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=3;ctx.stroke();}
}
function drawBackground(dt){
 const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#79d5ff');sky.addColorStop(.58,'#d9f7ff');sky.addColorStop(.59,'#a6e76b');sky.addColorStop(1,'#4caa4c');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 // sun
 ctx.fillStyle='#ffe77a';ctx.beginPath();ctx.arc(W*.82,H*.18,Math.min(W,H)*.055,0,Math.PI*2);ctx.fill();
 // distant hills
 ctx.fillStyle='#8fdc7b';ctx.beginPath();ctx.moveTo(0,ground);for(let x=0;x<=W+20;x+=20)ctx.lineTo(x,ground-55-Math.sin(x*.012)*22);ctx.lineTo(W,ground+10);ctx.lineTo(0,ground+10);ctx.fill();
 // clouds drift
 ctx.fillStyle='#fff';for(const c of clouds){if(gameState==='playing')c.x-=speed*.035*dt;if(c.x<-90)c.x=W+60;drawCloud(c.x,c.y,c.s);}
 // ground
 ctx.fillStyle='#63c94f';ctx.fillRect(0,ground,W,H-ground);
 ctx.fillStyle='#3e9b40';ctx.fillRect(0,ground,W,8);
 ctx.fillStyle='#b6e76a';
 const offset=(elapsed*speed*.7)%45;
 for(let x=-offset;x<W;x+=45){ctx.beginPath();ctx.ellipse(x,ground+25,10,3,0,0,Math.PI*2);ctx.fill();}
 // trees in background
 for(let x=-(elapsed*speed*.16%150);x<W+100;x+=150){
   const tx=x+60,ty=ground-50;
   ctx.fillStyle='#8b5b36';ctx.fillRect(tx-7,ty-50,14,56);
   ctx.fillStyle='#3eaa58';ctx.beginPath();ctx.arc(tx,ty-57,31,0,Math.PI*2);ctx.fill();
   ctx.fillStyle='#58c96c';ctx.beginPath();ctx.arc(tx-12,ty-65,17,0,Math.PI*2);ctx.fill();
 }
}
function drawCloud(x,y,s){ctx.beginPath();ctx.arc(x,y,17*s,0,Math.PI*2);ctx.arc(x+20*s,y-8*s,22*s,0,Math.PI*2);ctx.arc(x+43*s,y,16*s,0,Math.PI*2);ctx.fill();}
function drawBear(){
 const x=bear.x,y=bear.y,run=Math.sin(bear.run*13);
 ctx.save();ctx.translate(x,y);
 // shadow
 ctx.fillStyle='#2d7d3b55';ctx.beginPath();ctx.ellipse(29,bear.h+3,32,7,0,0,Math.PI*2);ctx.fill();
 // legs
 ctx.strokeStyle='#8b512d';ctx.lineWidth=12;ctx.lineCap='round';
 ctx.beginPath();ctx.moveTo(19,47);ctx.lineTo(17+run*5,58);ctx.stroke();
 ctx.beginPath();ctx.moveTo(39,47);ctx.lineTo(41-run*5,58);ctx.stroke();
 // ears
 ctx.fillStyle='#a9673c';ctx.beginPath();ctx.arc(13,12,11,0,Math.PI*2);ctx.arc(43,12,11,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#eaa17d';ctx.beginPath();ctx.arc(13,12,5,0,Math.PI*2);ctx.arc(43,12,5,0,Math.PI*2);ctx.fill();
 // body and head
 ctx.fillStyle='#b97843';ctx.beginPath();ctx.ellipse(29,39,22,22,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#d79a5e';ctx.beginPath();ctx.arc(29,25,25,0,Math.PI*2);ctx.fill();
 // muzzle
 ctx.fillStyle='#f4d5a5';ctx.beginPath();ctx.ellipse(31,32,14,11,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#39291f';ctx.beginPath();ctx.arc(23,23,2.8,0,Math.PI*2);ctx.arc(39,23,2.8,0,Math.PI*2);ctx.fill();
 ctx.beginPath();ctx.ellipse(31,29,4,3,0,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle='#65402b';ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(31,32);ctx.lineTo(31,36);ctx.quadraticCurveTo(27,40,24,36);ctx.stroke();
 // belly patch
 ctx.fillStyle='#f0c58c';ctx.beginPath();ctx.ellipse(29,45,12,11,0,0,Math.PI*2);ctx.fill();
 // little scarf
 ctx.fillStyle='#e84d52';ctx.beginPath();ctx.moveTo(10,39);ctx.quadraticCurveTo(29,48,48,38);ctx.lineTo(45,45);ctx.quadraticCurveTo(29,54,13,45);ctx.fill();
 ctx.beginPath();ctx.moveTo(39,45);ctx.lineTo(48,57);ctx.lineTo(35,51);ctx.fill();
 ctx.restore();
}
function drawLog(o){
 const x=o.x,y=ground-o.h;
 roundedRect(x,y,o.w,o.h,8,'#89552e','#5b351d');
 ctx.fillStyle='#bd8248';ctx.beginPath();ctx.ellipse(x+o.w-3,y+o.h/2,8,o.h/2-2,0,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle='#754321';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x+o.w-3,y+o.h/2,4,o.h/2-5,0,0,Math.PI*2);ctx.stroke();
 ctx.fillStyle='#5cae43';ctx.beginPath();ctx.ellipse(x+o.w*.45,y-2,12,5,-.4,0,Math.PI*2);ctx.fill();
}
function drawHoney(h){
 const bob=Math.sin(elapsed*6+h.phase)*4,x=h.x,y=h.y+bob;
 ctx.save();ctx.translate(x,y);
 ctx.fillStyle='#ffd13f';ctx.beginPath();ctx.ellipse(0,0,13,15,0,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle='#d58a1e';ctx.lineWidth=2;ctx.stroke();
 ctx.fillStyle='#fff0a2';ctx.beginPath();ctx.ellipse(-4,-5,4,6,-.3,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#895222';ctx.fillRect(-8,-17,16,4);
 ctx.font='bold 10px sans-serif';ctx.fillStyle='#87501e';ctx.textAlign='center';ctx.fillText('M',0,4);
 ctx.restore();
}
function overlap(a,b){return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;}
function update(dt){
 elapsed+=dt;score=Math.floor(elapsed*10);speed=Math.min(690,310+elapsed*7.5);
 bear.run+=dt;bear.vy+=gravity*dt;bear.y+=bear.vy*dt;
 if(bear.y>=ground-bear.h){bear.y=ground-bear.h;bear.vy=0;bear.onGround=true;}
 spawnTimer-=dt;if(spawnTimer<=0){const h=27+Math.random()*18;obstacles.push({x:W+30,w:32+Math.random()*15,h});spawnTimer=Math.max(.72,1.35-Math.min(.5,elapsed*.004))+Math.random()*.45;}
 honeyTimer-=dt;if(honeyTimer<=0){honeys.push({x:W+25,y:ground-105-Math.random()*65,w:24,h:28,phase:Math.random()*6});honeyTimer=1.2+Math.random()*1.2;}
 for(const o of obstacles)o.x-=speed*dt;
 for(const h of honeys)h.x-=speed*dt;
 obstacles=obstacles.filter(o=>o.x+o.w>-10);honeys=honeys.filter(h=>h.x>-30);
 const bearBox={x:bear.x+8,y:bear.y+7,w:bear.w-15,h:bear.h-10};
 for(const o of obstacles){const ob={x:o.x+3,y:ground-o.h+4,w:o.w-6,h:o.h-4};if(overlap(bearBox,ob)){endGame();return;}}
 for(let i=honeys.length-1;i>=0;i--){const h=honeys[i];if(overlap(bearBox,{x:h.x-10,y:h.y-12,w:20,h:24})){honeys.splice(i,1);honey++;score+=5;for(let k=0;k<8;k++)particles.push({x:h.x,y:h.y,vx:(Math.random()-.5)*100,vy:-Math.random()*100,life:.5});}}
 for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;}particles=particles.filter(p=>p.life>0);
 scoreEl.textContent=score;honeyEl.textContent=honey;
}
function draw(){
 drawBackground(0);
 for(const h of honeys)drawHoney(h);
 for(const o of obstacles)drawLog(o);
 for(const p of particles){ctx.globalAlpha=Math.max(0,p.life*2);ctx.fillStyle='#ffd13f';ctx.beginPath();ctx.arc(p.x,p.y,4,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
 drawBear();
 if(gameState==='playing'){
   ctx.fillStyle='#ffffffaa';ctx.font='bold 12px system-ui';ctx.textAlign='left';ctx.fillText('VITESSE '+Math.round(speed/3)+'%',12,H-18);
 }
}
function loop(now){
 if(gameState!=='playing')return;
 const dt=Math.min((now-last)/1000,.035);last=now;
 update(dt);draw();
 if(gameState==='playing')requestAnimationFrame(loop);
}
function idleLoop(){if(gameState!=='playing'){draw();requestAnimationFrame(idleLoop);}}
draw();requestAnimationFrame(idleLoop);
})();
