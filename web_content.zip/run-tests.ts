import { RealExecutionHardeningTest } from './src/mission/realExecutionHardeningTest';
import { SimulationMissionTestRunner } from './src/mission/simulationMissionTest';
import { SimulationDebuggerTestSuite } from './src/debugger/simulationDebuggerTest';
import { runPersistenceAndResumeTests } from './src/mission/missionPersistenceTest';
import { runUniversalAppBuilderTestSuite } from './src/builder/universalAppBuilderTest';
import { runUniversalAppBuilderP21TestSuite } from './src/builder/universalAppBuilderP21Test';
import { runUniversalAppBuilderP22TestSuite } from './src/builder/universalAppBuilderP22Test';
import { UniversalAppBuilderP23TestSuite } from './src/builder/universalAppBuilderP23Test';
import { UniversalAppBuilderP24TestSuite } from './src/builder/universalAppBuilderP24Test';
import { UniversalAppBuilderP40Test } from './src/builder/universalAppBuilderP40Test';
import { UniversalAppBuilderP42Test } from './src/builder/universalAppBuilderP42Test';
import { runP43VfxCoreTests } from './src/builder/universalAppBuilderP43Test';
import { runP44AudioCoreTests } from './src/builder/universalAppBuilderP44Test';
import { UniversalAppBuilderP45Test } from './src/builder/universalAppBuilderP45Test';
import { runUniversalAppBuilderP46Tests } from './src/builder/universalAppBuilderP46Test';
import { runUniversalAppBuilderP47Tests } from './src/builder/universalAppBuilderP47Test';
import { UniversalAppBuilderP48Test } from './src/builder/universalAppBuilderP48Test';
import { runUniversalAppBuilderP49Tests } from './src/builder/universalAppBuilderP49Test';
import { UniversalAppBuilderP50Test } from './src/builder/universalAppBuilderP50Test';
import { UniversalAppBuilderP51Test } from './src/builder/universalAppBuilderP51Test';
import { UniversalAppBuilderP53Test } from './src/builder/universalAppBuilderP53Test';
import { P54ProductionHardeningTestSuite } from './src/builder/creative/production/p54ProductionHardeningTests';
import { P55AutonomousCreativeProductionTestSuite } from './src/builder/creative/production/p55AutonomousCreativeProductionTests';
import { runP57RealVideoVerificationTests } from './src/builder/creative/production/p57RealVideoVerificationTests';
import { runP58ExtendedNeuralVideoTests } from './src/builder/creative/production/p58ExtendedNeuralVideoTests';
import { AppBuildingVerificationTest } from './src/builder/appBuildingVerificationTest';

async function main() {
  console.log('=== RUNNING REAL EXECUTION HARDENING TESTS ===');
  const hardening = await RealExecutionHardeningTest.runAllHardeningChecks();
  console.log(`Hardening: ${hardening.passedCount}/${hardening.results.length} passed.`);
  for (const r of hardening.results) {
    console.log(`  [${r.passed ? 'PASS' : 'FAIL'}] ${r.test}${r.error ? ` - Error: ${r.error}` : ''}`);
  }

  console.log('\n=== RUNNING SIMULATION MISSION TEST SUITE (30+ TESTS) ===');
  const missionTests = await SimulationMissionTestRunner.runAllTests();
  console.log(`Missions: ${missionTests.passedCount}/${missionTests.totalCount} passed.`);
  for (const r of missionTests.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.error}`);
  }

  console.log('\n=== RUNNING SELF-HEALING DEBUGGER TEST SUITE (12 TESTS) ===');
  const debuggerTests = await SimulationDebuggerTestSuite.runSuite();
  console.log(`Debugger: ${debuggerTests.passedTests}/${debuggerTests.totalTests} passed.`);
  for (const r of debuggerTests.cases) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.details}`);
  }

  console.log('\n=== RUNNING P1.4 PERSISTENCE & SAFE RESUME TEST SUITE (11 TESTS) ===');
  const persistenceTests = await runPersistenceAndResumeTests();
  console.log(`Persistence & Resume: ${persistenceTests.passed}/${persistenceTests.passed + persistenceTests.failed} passed.`);
  for (const r of persistenceTests.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.error}`);
    else console.log(`  [PASS] ${r.name}`);
  }

  console.log('\n=== RUNNING P2.0 UNIVERSAL APP BUILDER TEST SUITE (10 TESTS) ===');
  const p2Tests = await runUniversalAppBuilderTestSuite();
  console.log(`P2.0 Universal Builder: ${p2Tests.passedTests}/${p2Tests.totalTests} passed.`);
  for (const r of p2Tests.cases) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.details}`);
    else console.log(`  [PASS] ${r.name}`);
  }

  console.log('\n=== RUNNING P2.1 END-TO-END APP GENERATION TEST SUITE (20 TESTS) ===');
  const p21Tests = await runUniversalAppBuilderP21TestSuite();
  console.log(`P2.1 End-to-End Generation: ${p21Tests.passedTests}/${p21Tests.totalTests} passed.`);
  for (const r of p21Tests.cases) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.details}`);
    else console.log(`  [PASS] ${r.name}`);
  }

  console.log('\n=== RUNNING P2.2 GENERAL-PURPOSE APPLICATION SYNTHESIS TEST SUITE (20 TESTS) ===');
  const p22Tests = await runUniversalAppBuilderP22TestSuite();
  console.log(`P2.2 Synthesis: ${p22Tests.passedTests}/${p22Tests.totalTests} passed.`);
  for (const r of p22Tests.cases) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.details}`);
    else console.log(`  [PASS] ${r.name}`);
  }

  console.log('\n=== RUNNING P2.3 UNIVERSAL RUNTIME & REPAIR TEST SUITE (20 TESTS) ===');
  const p23Report = await UniversalAppBuilderP23TestSuite.runAllTests();
  console.log(`P2.3 Runtime & Repair: ${p23Report.passedTests}/${p23Report.totalTests} passed.`);
  for (const r of p23Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.evidence}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P2.4 CREATIVE & MEDIA APPLICATION BUILDER TEST SUITE (20 TESTS) ===');
  const p24Report = await UniversalAppBuilderP24TestSuite.runAllTests();
  console.log(`P2.4 Creative & Media: ${p24Report.passedTests}/${p24Report.totalTests} passed.`);
  for (const r of p24Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.evidence}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P4.0 PRODUCTION NEURAL CREATIVE EXECUTION PLATFORM TEST SUITE (30 TESTS) ===');
  const p40Report = await UniversalAppBuilderP40Test.runAllTests();
  console.log(`P4.0 Neural Platform: ${p40Report.passedTests}/${p40Report.totalTests} passed.`);
  for (const r of p40Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.details}${r.error ? ` - Error: ${r.error}` : ''}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P4.2 REAL NEURAL MEDIA GENERATION PIPELINE TEST SUITE (30 TESTS) ===');
  const p42Report = await UniversalAppBuilderP42Test.runAllTests();
  console.log(`P4.2 Neural Pipeline: ${p42Report.passedTests}/${p42Report.totalTests} passed.`);
  for (const r of p42Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.details}${r.error ? ` - Error: ${r.error}` : ''}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P4.3 PRODUCTION VFX CORE TEST SUITE ===');
  const p43Report = await runP43VfxCoreTests();
  console.log(`P4.3 VFX Core: ${p43Report.passed}/${p43Report.total} passed.`);

  console.log('\n=== RUNNING P4.4 PRODUCTION SFX & AV SYNCHRONIZATION TEST SUITE (28 TESTS) ===');
  const p44Report = await runP44AudioCoreTests();
  console.log(`P4.4 Audio Core: ${p44Report.passedTests}/${p44Report.totalTests} passed.`);

  console.log('\n=== RUNNING P4.5 PRODUCTION MEDIA ASSEMBLY, RENDER & EXPORT TEST SUITE (15 TESTS) ===');
  const p45Report = await UniversalAppBuilderP45Test.getInstance().runAllTests();
  console.log(`P4.5 Production Media Assembly: ${p45Report.passedTests}/${p45Report.totalTests} passed.`);
  for (const r of p45Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.error}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P4.6 PRODUCTION DELIVERY & RENDER HARDENING TEST SUITE ===');
  const p46Report = await runUniversalAppBuilderP46Tests();
  console.log(`P4.6 Render Hardening: ${p46Report.passedCount}/${p46Report.total} passed.`);
  for (const r of p46Report.results) {
    if (!r.passed) console.log(`  [FAIL] [${r.suite}] ${r.name}: ${r.message}`);
    else console.log(`  [PASS] [${r.suite}] ${r.name} (${r.latencyMs}ms)`);
  }

  console.log('\n=== RUNNING P4.7 REAL DEVICE RENDER & PRODUCTION DELIVERY TEST SUITE ===');
  const p47Report = await runUniversalAppBuilderP47Tests();
  console.log(`P4.7 Real Device Render: ${p47Report.passedCount}/${p47Report.total} passed.`);
  for (const r of p47Report.results) {
    if (!r.passed) console.log(`  [FAIL] [${r.suite}] ${r.name}: ${r.message}`);
    else console.log(`  [PASS] [${r.suite}] ${r.name} (${r.latencyMs}ms)`);
  }

  console.log('\n=== RUNNING P4.8 CINEMATIC CAMERA, OPTICS & SHOT INTELLIGENCE TEST SUITE ===');
  const p48Report = await UniversalAppBuilderP48Test.getInstance().runAllTests();
  console.log(`P4.8 Cinematic Optics: ${p48Report.passed}/${p48Report.total} passed.`);
  for (const r of p48Report.results) {
    if (!r.passed) console.log(`  [FAIL] [${r.suite}] ${r.name}: ${r.message}`);
    else console.log(`  [PASS] [${r.suite}] ${r.name} (${r.latencyMs}ms)`);
  }

  console.log('\n=== RUNNING P4.9 PROFESSIONAL COLOR SCIENCE & CINEMATIC FINISHING TEST SUITE ===');
  const p49Report = await runUniversalAppBuilderP49Tests();
  console.log(`P4.9 Color Science: ${p49Report.passed}/${p49Report.total} passed.`);
  for (const r of p49Report.results) {
    if (!r.passed) console.log(`  [FAIL] [${r.suite}] ${r.name}: ${r.message}`);
    else console.log(`  [PASS] [${r.suite}] ${r.name} (${r.latencyMs}ms)`);
  }

  console.log('\n=== RUNNING P5.0 UNIFIED PRODUCTION PIPELINE & ORCHESTRATION TEST SUITE (8 TESTS) ===');
  const p50Report = await UniversalAppBuilderP50Test.runAllTests();
  console.log(`P5.0 Production Orchestration: ${p50Report.passedTests}/${p50Report.totalTests} passed.`);
  for (const r of p50Report.results) {
    if (!r.passed) console.log(`  [FAIL] [${r.suite}] ${r.testName}: ${r.details}`);
    else console.log(`  [PASS] [${r.suite}] ${r.testName}`);
  }

  console.log('\n=== RUNNING P5.1 REAL GENERATION BRING-UP & PROOF TEST SUITE (25 TESTS) ===');
  const p51Report = await UniversalAppBuilderP51Test.runAllTests();
  console.log(`P5.1 Real Generation & Proof: ${p51Report.passedTests}/${p51Report.totalTests} passed.`);
  for (const r of p51Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.error}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P5.3 PLAYABLE MEDIA DELIVERY & INGESTION TEST SUITE ===');
  const p53Report = await UniversalAppBuilderP53Test.runAllTests();
  console.log(`P5.3 Playable Media & Ingestion: ${p53Report.passedTests}/${p53Report.totalTests} passed.`);
  for (const r of p53Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.id}: ${r.name} - ${r.error}`);
    else console.log(`  [PASS] ${r.id}: ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P5.4 REAL EXECUTION, OUTPUT PROOF & HARDENING TEST SUITE (30 TESTS) ===');
  const p54Report = await P54ProductionHardeningTestSuite.runAllTests();
  console.log(`P5.4 Hardening & Proof: ${p54Report.passed}/${p54Report.passed + p54Report.failed} passed.`);
  for (const r of p54Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.error}`);
    else console.log(`  [PASS] ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P5.5 AUTONOMOUS CREATIVE PRODUCTION & END-TO-END DELIVERY TEST SUITE (30+ TESTS) ===');
  const p55Report = await P55AutonomousCreativeProductionTestSuite.runAllTests();
  console.log(`P5.5 Autonomous Production: ${p55Report.passed}/${p55Report.passed + p55Report.failed} passed.`);
  for (const r of p55Report.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.error}`);
    else console.log(`  [PASS] ${r.name} (${r.durationMs}ms)`);
  }

  console.log('\n=== RUNNING P5.7 REAL VIDEO GENERATION VERIFICATION & PROOF TEST SUITE (14 TESTS) ===');
  const p57Report = await runP57RealVideoVerificationTests();
  console.log(`P5.7 Real Video Verification: ${p57Report.passed}/${p57Report.total} passed.`);
  for (const f of p57Report.failed) {
    console.log(`  [FAIL] ${f}`);
  }

  console.log('\n=== RUNNING P5.8 & P5.8.4 EXTENDED NEURAL VIDEO TEST SUITE (46 TESTS) ===');
  const p58Report = await runP58ExtendedNeuralVideoTests();
  console.log(`P5.8 & P5.8.4 Extended Neural Video: ${p58Report.passed}/${p58Report.total} passed.`);
  for (const f of p58Report.failed) {
    console.log(`  [FAIL] ${f}`);
  }

  console.log('\n=== RUNNING P0 APP BUILDING VERIFICATION TEST SUITE (10 TESTS) ===');
  const appBuildingReport = await AppBuildingVerificationTest.runSuite();
  console.log(`P0 App Building: ${appBuildingReport.passedCount}/${appBuildingReport.totalCount} passed.`);
  for (const r of appBuildingReport.results) {
    if (!r.passed) console.log(`  [FAIL] ${r.name}: ${r.error}`);
    else console.log(`  [PASS] ${r.name}`);
  }

  const totalFailures = 
    hardening.failedCount + 
    missionTests.failedCount + 
    debuggerTests.failedTests + 
    persistenceTests.failed + 
    p2Tests.failedTests +
    p21Tests.failedTests +
    p22Tests.failedTests +
    p23Report.failedTests +
    p24Report.failedTests +
    p40Report.failedTests +
    p42Report.failedTests +
    (p43Report.total - p43Report.passed) +
    (p44Report.totalTests - p44Report.passedTests) +
    p45Report.failedTests +
    p46Report.failedCount +
    p47Report.failedCount +
    p48Report.failed +
    p49Report.failed +
    (p50Report.totalTests - p50Report.passedTests) +
    p51Report.failedTests +
    p53Report.failedTests +
    p54Report.failed +
    p55Report.failed +
    (p57Report.total - p57Report.passed) +
    (p58Report.total - p58Report.passed) +
    (appBuildingReport.totalCount - appBuildingReport.passedCount);

  const totalPassed = 
    hardening.passedCount + 
    missionTests.passedCount + 
    debuggerTests.passedTests + 
    persistenceTests.passed + 
    p2Tests.passedTests + 
    p21Tests.passedTests + 
    p22Tests.passedTests + 
    p23Report.passedTests + 
    p24Report.passedTests + 
    p40Report.passedTests + 
    p42Report.passedTests +
    p43Report.passed +
    p44Report.passedTests +
    p45Report.passedTests +
    p46Report.passedCount +
    p47Report.passedCount +
    p48Report.passed +
    p49Report.passed +
    p50Report.passedTests +
    p51Report.passedTests +
    p53Report.passedTests +
    p54Report.passed +
    p55Report.passed +
    p57Report.passed +
    p58Report.passed +
    appBuildingReport.passedCount;

  if (totalFailures > 0) {
    console.error(`\n❌ TEST SUITE FAILED (${totalFailures} failures)`);
    process.exit(1);
  } else {
    console.log(`\n✅ ALL ${totalPassed} TESTS PASSED (${hardening.passedCount} Hardening, ${missionTests.passedCount} Missions, ${debuggerTests.passedTests} Debugger, ${persistenceTests.passed} Persistence/Resume, ${p2Tests.passedTests} P2.0 Builder, ${p21Tests.passedTests} P2.1 Generation, ${p22Tests.passedTests} P2.2 Synthesis, ${p23Report.passedTests} P2.3 Runtime & Repair, ${p24Report.passedTests} P2.4 Creative & Media, ${p40Report.passedTests} P4.0 Neural Platform, ${p42Report.passedTests} P4.2 Neural Pipeline, ${p43Report.passed} P4.3 VFX Core, ${p44Report.passedTests} P4.4 Audio/AV Sync Core, ${p45Report.passedTests} P4.5 Media Assembly & Render, ${p46Report.passedCount} P4.6 Hardening, ${p47Report.passedCount} P4.7 Real-Device Delivery, ${p48Report.passed} P4.8 Optics/Camera, ${p49Report.passed} P4.9 Color Science, ${p50Report.passedTests} P5.0 Production Orchestration, ${p51Report.passedTests} P5.1 Proof & Truth Layer, ${p53Report.passedTests} P5.3 Playable Media Delivery & Ingestion, ${p54Report.passed} P5.4 Real Execution & Proof Hardening, ${p55Report.passed} P5.5 Autonomous Creative Production & Delivery, ${p57Report.passed} P5.7 Real Video Generation Verification & Proof, ${p58Report.passed} P5.8 & P5.8.4 Extended Neural Video Verification, ${appBuildingReport.passedCount} P0 End-to-End App Building Verification)`);
    process.exit(0);
  }
}


main().catch(err => {
  console.error('Fatal error running tests:', err);
  process.exit(1);
});
