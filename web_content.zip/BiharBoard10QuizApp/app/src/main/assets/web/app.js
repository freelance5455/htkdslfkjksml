(() => {
const KEY="bb10_custom_questions_v1", BEST="bb10_best_v1";
let custom=JSON.parse(localStorage.getItem(KEY)||"[]");
let questions=[...APP_DATA.questions,...custom];
let state={screen:"home",subject:null,chapter:null,quiz:[],i:0,score:0,answered:false,timer:null,seconds:30};

const app=document.getElementById("app");
const esc=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));
function save(){localStorage.setItem(KEY,JSON.stringify(custom));questions=[...APP_DATA.questions,...custom]}
function toast(t){let x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),1800)}
function header(title,sub=""){return `<div class="top"><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>`}
function nav(){return `<div class="nav"><button class="btn alt" onclick="go('home')">⌂ होम</button><button class="btn alt" onclick="go('add')">＋ प्रश्न जोड़ें</button></div>`}
function renderHome(){
 app.innerHTML=header("Bihar Board 10 Quiz","कक्षा 10 • बिहार बोर्ड • 2026 तैयारी")+
 `<div class="wrap">${nav()}<div class="card"><b>अपना नाम</b><input id="name" class="input" placeholder="नाम लिखें" value="${esc(localStorage.getItem('bb_name')||'')}"><button class="btn" onclick="setName()">सेव करें</button><button class="btn alt" style="margin-left:7px" onclick="googleInfo()">🔐 Google Login</button><p class="muted small">Google login के लिए अपने Firebase/Google OAuth credentials जोड़ना होगा; app बिना login के भी offline चलता है।</p></div><h3>विषय चुनें</h3><div class="grid">`+
 Object.entries(APP_DATA.subjects).map(([id,s])=>`<button class="card subject" onclick="subjects('${id}')"><span class="pill">कक्षा 10</span><b>${esc(s.name)}</b><span class="muted">${s.chapters.length} अध्याय</span></button>`).join("")+
 `</div><div class="card"><div class="row between"><b>मेरे जोड़े प्रश्न</b><span class="pill">${custom.length}</span></div><p class="muted">आप खुद MCQ जोड़ सकते हैं। वे इसी डिवाइस में सुरक्षित रहेंगे।</p></div></div>`;
}
function subjects(id){
 state.screen="chapters";state.subject=id;
 const s=APP_DATA.subjects[id];
 app.innerHTML=header(s.name,"अध्याय चुनें • फिर क्विज शुरू करें")+`<div class="wrap">${nav()}<div class="list">${s.chapters.map(c=>{
 const count=questions.filter(q=>q.subject===id&&q.chapter===c).length;
 return `<button class="card" onclick="chapter('${esc(c).replace(/'/g,"\\'")}')"><b>${esc(c)}</b><div class="muted">${count} प्रश्न उपलब्ध</div></button>`;
 }).join("")}</div></div>`;
}
function chapter(c){
 state.chapter=c;
 const qs=questions.filter(q=>q.subject===state.subject&&q.chapter===c);
 app.innerHTML=header(c,"क्विज शुरू करने से पहले प्रश्नों की संख्या देखें")+`<div class="wrap">${nav()}<div class="card"><h2>${esc(APP_DATA.subjects[state.subject].name)}</h2><p>${qs.length} प्रश्न उपलब्ध हैं।</p><p class="muted">हर प्रश्न के लिए 30 सेकंड। गलत उत्तर पर अंक नहीं कटेंगे।</p><button class="btn" onclick="startQuiz()">▶ क्विज शुरू करें</button></div></div>`;
}
function startQuiz(){
 let qs=questions.filter(q=>q.subject===state.subject&&q.chapter===state.chapter);
 qs=qs.sort(()=>Math.random()-.5).slice(0,Math.min(10,qs.length));
 if(!qs.length){toast("इस अध्याय में अभी प्रश्न नहीं हैं");return}
 state.quiz=qs;state.i=0;state.score=0;state.answered=false;showQ();
}
function showQ(){
 clearInterval(state.timer);state.seconds=30;state.answered=false;
 const q=state.quiz[state.i], total=state.quiz.length;
 app.innerHTML=header("क्विज",`${state.i+1} / ${total} प्रश्न`)+`<div class="wrap"><div class="card"><div class="row between"><span>स्कोर: ${state.score}</span><b id="timer">30s</b></div><div class="progress"><i style="width:${(state.i/total)*100}%"></i></div><h2>${esc(q.q)}</h2><div id="opts">${q.opts.map((o,n)=>`<button class="option" onclick="answer(${n})">${String.fromCharCode(65+n)}. ${esc(o)}</button>`).join("")}</div><p id="feedback" class="muted"></p></div></div>`;
 state.timer=setInterval(()=>{state.seconds--;const t=document.getElementById("timer");if(t)t.textContent=state.seconds+"s";if(state.seconds<=0){clearInterval(state.timer);answer(-1)}},1000);
}
function answer(n){
 if(state.answered)return;state.answered=true;clearInterval(state.timer);
 const q=state.quiz[state.i], buttons=[...document.querySelectorAll(".option")];
 buttons.forEach((b,i)=>{if(i===q.ans)b.classList.add("correct");if(i===n&&n!==q.ans)b.classList.add("wrong");b.disabled=true});
 if(n===q.ans)state.score++;
 const f=document.getElementById("feedback");f.textContent=n===q.ans?"✓ सही उत्तर!":(n===-1?"⏱ समय समाप्त":`✗ सही उत्तर: ${q.opts[q.ans]}`);
 setTimeout(()=>{state.i++;if(state.i<state.quiz.length)showQ();else result()},900);
}
function result(){
 const best=Math.max(Number(localStorage.getItem(BEST)||0),state.score);localStorage.setItem(BEST,best);
 app.innerHTML=header("क्विज पूरा!","आपने क्विज समाप्त कर लिया है")+`<div class="wrap"><div class="card"><div class="score">${state.score}/${state.quiz.length}</div><p style="text-align:center">Best score: ${best}</p><div class="row"><button class="btn" onclick="startQuiz()">फिर से खेलें</button><button class="btn alt" onclick="go('home')">होम</button></div></div></div>`;
}
function add(){
 app.innerHTML=header("प्रश्न जोड़ें","अपना MCQ बनाएं")+`<div class="wrap">${nav()}<div class="card"><label>विषय</label><select id="aqs" class="input">${Object.entries(APP_DATA.subjects).map(([id,s])=>`<option value="${id}">${s.name}</option>`)}</select><label>अध्याय</label><select id="aqc" class="input"></select><label>प्रश्न</label><textarea id="aq" rows="3" placeholder="प्रश्न लिखें"></textarea><label>विकल्प A</label><input id="a0" class="input"><label>विकल्प B</label><input id="a1" class="input"><label>विकल्प C</label><input id="a2" class="input"><label>विकल्प D</label><input id="a3" class="input"><label>सही विकल्प</label><select id="aa" class="input"><option value="0">A</option><option value="1">B</option><option value="2">C</option><option value="3">D</option></select><button class="btn" onclick="addQ()">प्रश्न सेव करें</button></div></div>`;
 const sel=document.getElementById("aqs");const ch=document.getElementById("aqc");
 function fill(){ch.innerHTML=APP_DATA.subjects[sel.value].chapters.map(x=>`<option>${esc(x)}</option>`).join("")}
 sel.onchange=fill;fill();
}
function addQ(){
 const subject=document.getElementById("aqs").value,chapter=document.getElementById("aqc").value,q=document.getElementById("aq").value.trim(),opts=[0,1,2,3].map(i=>document.getElementById("a"+i).value.trim()),ans=Number(document.getElementById("aa").value);
 if(!q||opts.some(x=>!x)){toast("सभी फील्ड भरें");return}
 custom.push({id:"c"+Date.now(),subject,chapter,q,opts,ans});save();toast("प्रश्न सेव हो गया");setTimeout(()=>go('home'),700);
}
function setName(){localStorage.setItem('bb_name',document.getElementById("name").value.trim());toast("नाम सेव हो गया")}
function googleInfo(){alert("Real Google Login के लिए Firebase Authentication या Google OAuth client ID configure करना जरूरी है. इस source में login UI रखा गया है ताकि credentials जोड़ते ही इसे connect किया जा सके.");}
function go(x){if(x==="add")add();else renderHome()}
window.subjects=subjects;window.chapter=chapter;window.startQuiz=startQuiz;window.answer=answer;window.go=go;window.addQ=addQ;window.setName=setName;window.googleInfo=googleInfo;
renderHome();
})();