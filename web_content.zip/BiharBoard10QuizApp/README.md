# Bihar Board 10 Quiz App

यह एक offline-first Android WebView app project है।

## मुख्य फीचर
- कक्षा 10 बिहार बोर्ड 2026 तैयारी
- गणित, विज्ञान और हिंदी
- अध्यायवार MCQ quiz
- 30 सेकंड प्रति प्रश्न
- स्कोर और best score
- खुद प्रश्न जोड़ने की सुविधा
- LocalStorage में custom questions
- Internet के बिना core quiz चलता है
- Android WebView में local asset loading
- पुराने `appassets.androidplatform.net/web/index.html` path bug से बचने के लिए app सीधे `file:///android_asset/web/index.html` लोड करता है

## Build
Android Studio में यह project खोलें और Gradle Sync करके Run/Build APK करें।

## Google Login
Google login को production में चलाने के लिए अपना Firebase/Google OAuth configuration जोड़ना जरूरी है। बिना credentials के कोई app सुरक्षित तरीके से आपके Google account में login नहीं कर सकता। Core quiz login के बिना चलता है।

## महत्वपूर्ण
Bihar Board की syllabus/question content को publish करने से पहले अपने 2026 textbook/syllabus से cross-check करें। इस project में sample questions और chapter data दिए गए हैं ताकि app तुरंत चल सके।
