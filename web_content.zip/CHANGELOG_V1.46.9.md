# v1.46.9 — Correção da simulação da Série C

- Corrigida a rotina que simula a rodada da Série C em paralelo às partidas da carreira.
- A Série C recupera snapshots ausentes/incompletos em saves antigos e passa a registrar os resultados da rodada, atualizar a classificação e avançar o contador de rodadas.
- A rotina altera somente o snapshot da Série C; as tabelas das Séries A e B não são modificadas por esta correção.
- Quando a carreira está na Série C, os jogos continuam sendo atualizados pela tabela principal da própria carreira, evitando simular a mesma rodada duas vezes.
- Validação de sintaxe JavaScript concluída. O ciclo completo de temporada ainda precisa de teste dentro do jogo.
