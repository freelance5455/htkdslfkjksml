const allQuestions = [
{q:"What is the largest ocean?", a:["Atlantic","Pacific","Indian","Arctic"], c:1},
{q:"How many continents are there?", a:["5","6","7","8"], c:2},
{q:"Capital of Japan?", a:["Seoul","Beijing","Tokyo","Bangkok"], c:2},
{q:"Which planet is called Red Planet?", a:["Venus","Mars","Jupiter","Saturn"], c:1},
{q:"How many days in a week?", a:["5","6","7","8"], c:2},
{q:"What do bees make?", a:["Milk","Honey","Water","Bread"], c:1},
{q:"Largest country by area?", a:["China","USA","Russia","Canada"], c:2},
{q:"How many colors in a rainbow?", a:["5","6","7","8"], c:2},
{q:"Which animal is king of jungle?", a:["Tiger","Lion","Elephant","Bear"], c:1},
{q:"What is 10 x 10?", a:["100","10","1000","50"], c:0},
{q:"Capital of Malawi?", a:["Blantyre","Lilongwe","Mzuzu","Zomba"], c:1},
{q:"Which gas do humans breathe?", a:["Carbon","Oxygen","Nitrogen","Helium"], c:1},
{q:"How many legs does a spider have?", a:["6","8","4","10"], c:1},
{q:"Fastest land animal?", a:["Lion","Cheetah","Tiger","Horse"], c:1},
{q:"What is H2O?", a:["Salt","Water","Air","Sugar"], c:1},
{q:"Which continent is Egypt in?", a:["Asia","Africa","Europe","Australia"], c:1},
{q:"How many minutes in an hour?", a:["30","60","90","100"], c:1},
{q:"What color is the sky?", a:["Green","Blue","Red","Yellow"], c:1},
{q:"Which is the smallest planet?", a:["Mercury","Mars","Earth","Venus"], c:0},
{q:"Who invented light bulb?", a:["Tesla","Edison","Newton","Einstein"], c:1},
// add more quickly...
{q:"Capital of USA?", a:["New York","Washington DC","LA","Chicago"], c:1},
{q:"How many players in football team?", a:["9","10","11","12"], c:2},
{q:"Which month has 28 days?", a:["February","All months","January","December"], c:1},
{q:"Largest desert?", a:["Sahara","Gobi","Kalahari","Arctic"], c:0},
{q:"What does CPU stand for?", a:["Central Processing Unit","Computer Unit","Core Unit","Main Unit"], c:0},
{q:"How many teeth does adult have?", a:["28","30","32","34"], c:2},
{q:"Which is not a fruit?", a:["Apple","Carrot","Mango","Banana"], c:1},
{q:"Capital of UK?", a:["London","Manchester","Birmingham","Liverpool"], c:0},
{q:"How many sides in triangle?", a:["2","3","4","5"], c:1},
{q:"Which animal lays eggs?", a:["Dog","Cat","Chicken","Cow"], c:2},
];

for(let i=allQuestions.length; i<100; i++){
  allQuestions.push({q:`Sample Question ${i+1}: 2+${i}=?`, a:[`${i}`,`${i+1}`,`${i+2}`,`${i+3}`], c:1});
}

let quiz = [], idx=0, score=0, total=10;

// LOADER
window.onload = ()=>{ setTimeout(()=>{ document.getElementById("loader").style.display="none"; show("home"); }, 2600); }

function show(id){ document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active")); document.getElementById(id).classList.add("active"); }
function showCounts(){ show("countScreen"); }
function goHome(){ show("home"); }

function start(n){
  total=n; quiz = [...allQuestions].sort(()=>0.5-Math.random()).slice(0,n);
  idx=0; score=0; show("quiz"); load();
}

function load(){
  let q=quiz[idx];
  document.getElementById("qText").innerText = `Q${idx+1}/${total}: ${q.q}`;
  let html=""; let letters=["A","B","C","D"];
  q.a.forEach((opt,i)=>{ html+=`<button class="opt" onclick="ans(${i},this)"><b>${letters[i]}</b> ${opt}</button>`; });
  document.getElementById("opts").innerHTML=html;
}

function ans(i,btn){
  let correct = quiz[idx].c;
  if(i===correct){ btn.classList.add("correct"); score++; } else { btn.classList.add("wrong"); document.querySelectorAll(".opt")[correct].classList.add("correct"); }
  setTimeout(()=>nextQ(),700);
}

function nextQ(){
  idx++;
  if(idx<total) load();
  else {
    show("scoreScreen");
    document.getElementById("scoreBig").innerText = `${score} / ${total}`;
    document.getElementById("scoreMsg").innerText = score/total>0.7 ? "Excellent!" : score/total>0.4 ? "Good Try!" : "Keep Practicing!";
  }
}