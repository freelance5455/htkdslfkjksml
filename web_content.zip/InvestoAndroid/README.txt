INVESTO ANDROID APP
====================

This is a simple Android WebView wrapper around the Investo single-file web app.

What is included:
- Login screen (demo login; any username/password)
- Starting balance: Rs 1,00,000
- Demo portfolio: RELIANCE, TCS, INFY
- Buy / Sell
- Holdings and balance
- Transaction history
- Logout
- Local device storage

IMPORTANT:
This is a demo investment app. It does NOT connect to a stock exchange, broker, bank,
or real money account. Prices are demo/static prices.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on your Android phone.

The project uses Java/Kotlin Android tooling and does not need an internet connection
for the app itself after the project dependencies have been downloaded.
