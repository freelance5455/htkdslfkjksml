GUILTY CROWN: EVERLASTING — PERSONAL FAN WEBSITE

Preview:
Open index.html. The three pages are Home, The Changes, and Characters.

Character portraits:
On the Characters page, choose “Add / change image” under a square. Images are saved in IndexedDB in this browser on this device, so they persist when you revisit the page. They are not uploaded to a server and do not automatically sync to another device/browser. Keep a backup of your images.

PWA / Android:
For installable app behavior, host the site over HTTPS, then open it in Chrome on Android and choose Install app / Add to Home screen. To package an APK, use PWABuilder with the hosted URL.

This is an unofficial personal fan concept, not affiliated with or endorsed by the original creators or rights holders.
