const groups = [
  ["Main characters", [["Shu Ouma","Main protagonist"],["Inori Yuzuriha","EGOIST vocalist · Undertaker"],["Gai Tsutsugami","Undertaker leader"],["Haruka Ouma","Shu's mother"],["Mana Ouma","Shu's sister"],["Yahiro Samukawa","Shu's friend"],["Souta Tamadate","Shu's friend"],["Hare Menjou","Shu's classmate"]]],
  ["Undertaker & school", [["Ayase Shinomiya","Undertaker pilot"],["Tsugumi","Undertaker operator"],["Arisa Kuhouin","Student council president"],["Kanōn Kusama","Student council member"],["Shibungi","Undertaker member"],["Oogumo","Undertaker member"],["Kenji Kido","Undertaker member"]]],
  ["GHQ & opponents", [["Daryl Yan","GHQ officer"],["Makoto Waltz Segai","GHQ major"],["Yuu","Connected to Daath"],["Keido Shuuichirou","GHQ / Sephirah"],["Dan Eagleman","GHQ general"],["Yoshino","GHQ officer"]]],
  ["Lost Christmas & other figures", [["Souta's classmates","School survivors"],["Triton","Lost Christmas-era figure"],["Carol","Lost Christmas-era figure"],["Daath","Organization / entity"]]]
];

const dbName = "EverlastingCharacterImages";
const storeName = "portraits";
let dbPromise;
function openDB(){
  if(dbPromise) return dbPromise;
  dbPromise=new Promise((resolve,reject)=>{
    if(!("indexedDB" in window)){reject(new Error("Image storage is not supported by this app."));return;}
    const req=indexedDB.open(dbName,2);
    req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(storeName))req.result.createObjectStore(storeName);};
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error||new Error("Could not open image storage."));
    req.onblocked=()=>reject(new Error("Image storage is busy. Close other Everlasting tabs and try again."));
  });
  return dbPromise;
}
async function getImage(key){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const req=db.transaction(storeName,"readonly").objectStore(storeName).get(key);
    req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);
  });
}
async function saveImage(key,file){
  const db=await openDB();
  const blob=new Blob([await file.arrayBuffer()],{type:file.type||"image/jpeg"});
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,"readwrite");
    tx.objectStore(storeName).put(blob,key);
    tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error("Could not save this image."));
    tx.onabort=()=>reject(tx.error||new Error("Image saving was cancelled."));
  });
}
async function deleteImage(key){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,"readwrite");tx.objectStore(storeName).delete(key);
    tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);
  });
}
function keyFor(name){return name.toLowerCase().replace(/[^a-z0-9]+/g,"-");}
function setPortrait(img,placeholder,remove,blob){
  if(img.dataset.objectUrl) URL.revokeObjectURL(img.dataset.objectUrl);
  const url=URL.createObjectURL(blob);img.dataset.objectUrl=url;img.src=url;
  img.hidden=false;placeholder.hidden=true;remove.hidden=false;
}
async function render(){
  const root=document.getElementById("character-groups");
  const status=document.getElementById("image-status");
  if(navigator.storage?.persist) navigator.storage.persist().catch(()=>{});
  for(const [groupName,people] of groups){
    const section=document.createElement("section");section.className="character-group";
    const heading=document.createElement("h2");heading.textContent=groupName;section.appendChild(heading);
    const grid=document.createElement("div");grid.className="character-grid";
    for(const [name,role] of people){
      const key=keyFor(name),card=document.createElement("article");card.className="character-card";
      const label=document.createElement("label");label.className="portrait";label.setAttribute("aria-label",`Add or change image for ${name}`);
      const input=document.createElement("input");input.className="file-input";input.type="file";input.accept="image/*";input.setAttribute("aria-label",`Choose image for ${name}`);
      const placeholder=document.createElement("span");placeholder.className="placeholder";placeholder.textContent="＋";
      const img=document.createElement("img");img.alt=`${name} portrait`;img.hidden=true;
      const hint=document.createElement("span");hint.className="upload-hint";hint.textContent="ADD PORTRAIT";
      label.append(placeholder,img,hint,input);
      const title=document.createElement("div");title.className="character-name";title.textContent=name;
      const sub=document.createElement("div");sub.className="character-role";sub.textContent=role;
      const actions=document.createElement("div");actions.className="image-actions";
      const change=document.createElement("button");change.type="button";change.textContent="Add / change image";change.onclick=()=>input.click();
      const remove=document.createElement("button");remove.type="button";remove.className="remove";remove.textContent="Remove";remove.hidden=true;
      remove.onclick=async()=>{try{await deleteImage(key);if(img.dataset.objectUrl)URL.revokeObjectURL(img.dataset.objectUrl);delete img.dataset.objectUrl;img.removeAttribute("src");img.hidden=true;placeholder.hidden=false;remove.hidden=true;status.textContent=`${name}'s image removed.`;}catch(e){status.textContent=e.message;}};
      input.addEventListener("change",async()=>{
        const file=input.files?.[0];if(!file)return;
        if(!file.type.startsWith("image/")){status.textContent="Please choose an image file.";return;}
        if(file.size>15*1024*1024){status.textContent="Please choose an image smaller than 15 MB.";input.value="";return;}
        try{await saveImage(key,file);setPortrait(img,placeholder,remove,file);status.textContent=`${name}'s image is saved on this device.`;}
        catch(e){status.textContent=`Couldn't save the image: ${e.message||"storage unavailable"}`;}
        input.value="";
      });
      actions.append(change,remove);card.append(label,title,sub,actions);grid.appendChild(card);
      try{const saved=await getImage(key);if(saved)setPortrait(img,placeholder,remove,saved);}
      catch(e){status.textContent=`Image storage unavailable: ${e.message||"Please use a supported Android app/browser."}`;}
    }
    section.appendChild(grid);root.appendChild(section);
  }
}
render().catch(e=>{document.getElementById("image-status").textContent=`Image gallery unavailable: ${e.message||"Please reopen the app."}`;});
