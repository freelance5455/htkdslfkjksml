const groups = [
  ["Main characters", [
    ["Shu Ouma","Main protagonist"],["Inori Yuzuriha","EGOIST vocalist · Undertaker"],["Gai Tsutsugami","Undertaker leader"],["Haruka Ouma","Shu's mother"],["Mana Ouma","Shu's sister"],["Yahiro Samukawa","Shu's friend"],["Souta Tamadate","Shu's friend"],["Hare Menjou","Shu's classmate"]
  ]],
  ["Undertaker & school", [
    ["Ayase Shinomiya","Undertaker pilot"],["Tsugumi","Undertaker operator"],["Arisa Kuhouin","Student council president"],["Kanōn Kusama","Student council member"],["Shibungi","Undertaker member"],["Oogumo","Undertaker member"],["Kenji Kido","Undertaker member"]
  ]],
  ["GHQ & opponents", [
    ["Daryl Yan","GHQ officer"],["Makoto Waltz Segai","GHQ major"],["Yuu","Connected to Daath"],["Keido Shuuichirou","GHQ / Sephirah"],["Dan Eagleman","GHQ general"],["Yoshino","GHQ officer"]
  ]],
  ["Lost Christmas & other figures", [
    ["Souta's classmates","School survivors"],["Triton","Lost Christmas-era figure"],["Carol","Lost Christmas-era figure"],["Daath","Organization / entity"]
  ]]
];

const dbName = "EverlastingCharacterImages";
const storeName = "portraits";
function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(dbName,1);
    req.onupgradeneeded=()=>req.result.createObjectStore(storeName);
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}
async function getImage(key){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const req=db.transaction(storeName,"readonly").objectStore(storeName).get(key);
    req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);
  });
}
async function saveImage(key,file){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,"readwrite");
    tx.objectStore(storeName).put(file,key);
    tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);
  });
}
async function deleteImage(key){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,"readwrite");tx.objectStore(storeName).delete(key);
    tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);
  });
}
function keyFor(name){return name.toLowerCase().replace(/[^a-z0-9]+/g,"-");}
async function render(){
  const root=document.getElementById("character-groups");
  for(const [groupName,people] of groups){
    const section=document.createElement("section");section.className="character-group";
    const heading=document.createElement("h2");heading.textContent=groupName;section.appendChild(heading);
    const grid=document.createElement("div");grid.className="character-grid";
    for(const [name,role] of people){
      const key=keyFor(name), card=document.createElement("article");card.className="character-card";
      const label=document.createElement("label");label.className="portrait";label.tabIndex=0;label.setAttribute("aria-label",`Add or change image for ${name}`);
      const input=document.createElement("input");input.className="file-input";input.type="file";input.accept="image/*";
      const placeholder=document.createElement("span");placeholder.className="placeholder";placeholder.textContent="＋";
      const img=document.createElement("img");img.alt=`${name} portrait`;img.hidden=true;
      const hint=document.createElement("span");hint.className="upload-hint";hint.textContent="ADD PORTRAIT";
      label.append(placeholder,img,hint,input);
      const title=document.createElement("div");title.className="character-name";title.textContent=name;
      const sub=document.createElement("div");sub.className="character-role";sub.textContent=role;
      const actions=document.createElement("div");actions.className="image-actions";
      const change=document.createElement("button");change.type="button";change.textContent="Add / change image";change.onclick=()=>input.click();
      const remove=document.createElement("button");remove.type="button";remove.className="remove";remove.textContent="Remove";remove.hidden=true;
      remove.onclick=async()=>{await deleteImage(key);img.removeAttribute("src");img.hidden=true;placeholder.hidden=false;remove.hidden=true;};
      input.addEventListener("change",async()=>{
        const file=input.files&&input.files[0];if(!file)return;
        if(!file.type.startsWith("image/"))return;
        await saveImage(key,file);
        const url=URL.createObjectURL(file);img.src=url;img.hidden=false;placeholder.hidden=true;remove.hidden=false;
      });
      actions.append(change,remove);card.append(label,title,sub,actions);grid.appendChild(card);
      const saved=await getImage(key);
      if(saved){img.src=URL.createObjectURL(saved);img.hidden=false;placeholder.hidden=true;remove.hidden=false;}
    }
    section.appendChild(grid);root.appendChild(section);
  }
}
render().catch(()=>{document.getElementById("character-groups").textContent="Your browser could not open local image storage. Try a current version of Chrome or Edge.";});
