
(()=>{'use strict';
let W=960;const H=540,T=40,MAX_LEVEL=60;
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d',{alpha:false});ctx.imageSmoothingEnabled=false;
const $=s=>document.getElementById(s);
// Match game world's view width to the device display; preserve pixel character proportions.
// A 20:9 screen sees more of the level than a 16:9 screen, instead of stretching the pixels.
function fitLandscapeViewport(){
 const shell=document.getElementById('shell');
 const box=shell.getBoundingClientRect();
 const boxW=shell.offsetWidth||box.width;
 const boxH=shell.offsetHeight||box.height;
 if(!boxW||!boxH)return;
 const ratio=boxW/boxH;
 const desired=Math.max(680,Math.min(1750,Math.round(H*ratio)));
 if(desired!==W){
   W=desired;
   canvas.width=W;
   canvas.height=H;
   ctx.imageSmoothingEnabled=false;
   if(stage&&typeof camera==='number')camera=Math.max(0,Math.min(camera,Math.max(0,stage.width-W)));
 }
}

// Supports Android System WebView, generic HTML-to-APK wrappers, and desktop Chrome.
const APK_TOUCH_DEVICE = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || /Android|Mobile/i.test(navigator.userAgent);
if(APK_TOUCH_DEVICE)document.body.classList.add('apk-touch');
// Android APK / WebView: ask for landscape at startup, retry on user gesture.
// The native AndroidManifest/HTML-to-APK landscape setting remains authoritative.
let apkLandscapePending=false,apkLastLandscapeTry=0;
function apkTryLandscape(fromUserGesture=false){
 if(!APK_TOUCH_DEVICE)return;
 const now=performance.now();
 if(apkLandscapePending||now-apkLastLandscapeTry<650)return;
 const orientation=window.screen&&screen.orientation;
 if(window.innerWidth>window.innerHeight && (!orientation || /^landscape/.test(orientation.type||'')))return;
 apkLastLandscapeTry=now;
 apkLandscapePending=true;
 (async()=>{
   // Screen Orientation API may require fullscreen or a direct user action.
   if(fromUserGesture && !document.fullscreenElement){
     const target=document.documentElement;
     const request=target.requestFullscreen||target.webkitRequestFullscreen;
     if(request){try{await Promise.resolve(request.call(target,{navigationUI:'hide'}));}catch(e){}}
   }
   try{if(orientation&&typeof orientation.lock==='function')await orientation.lock('landscape');}
   catch(e){/* Non-enabled WebViews rely on the APK landscape setting. */}
   finally{apkLandscapePending=false;}
 })();
}
window.addEventListener('pageshow',()=>apkTryLandscape(false));
document.addEventListener('visibilitychange',()=>{if(!document.hidden)apkTryLandscape(false);});
document.addEventListener('pointerdown',()=>{
 if(APK_TOUCH_DEVICE&&window.innerHeight>window.innerWidth)apkTryLandscape(true);
},{capture:true,passive:true});
function apkBackAction(){
 if(state==='playing'){pause();return true;}
 if(state==='paused'){goHome();return true;}
 if(state==='shop'){$('shopBackBtn').click();return true;}
 if(state==='levels'||state==='help'||state==='album'||state==='story'||state==='won'||state==='dialogue'){goHome();return true;}
 if(state==='photo'){closePhotoMode();return true;}
 return false;
}
// Wraps commonly deliver Backspace/BrowserBack instead of Escape.
window.addEventListener('keydown',e=>{
 if(e.code==='Backspace'||e.key==='BrowserBack'||e.key==='GoBack'){
   if(apkBackAction()){e.preventDefault();e.stopImmediatePropagation();}
 }
},true);
document.addEventListener('contextmenu',e=>{
 if(e.target.closest('#shell'))e.preventDefault();
});
document.addEventListener('dragstart',e=>{
 if(e.target.closest('#shell'))e.preventDefault();
});
// Prevent accidental Android swipe/overscroll only during gameplay;
// menus and help remain vertically scrollable.
document.addEventListener('touchmove',e=>{
 if((state==='playing'||state==='cutscene')&&e.target.closest('#shell')&&e.cancelable)e.preventDefault();
},{passive:false});

const overlays=['menu','help','levels','paused','won','shop','story','album','dialogue','photo'];const COLORS=[
 {name:'Gül Bahçesi',sky:['#6bbce9','#f7c2e6'],far:'#9bc9bd',mid:'#6eae97',ground:'#a65c45',top:'#6ed473',trim:'#389e59',tree:'#fd86bb',orn:'#fff2b6'},
 {name:'Şeker Tepeleri',sky:['#ffa4cf','#ffdfaa'],far:'#ec9bb7',mid:'#bc79bd',ground:'#aa6b5d',top:'#ffb1d3',trim:'#e276b5',tree:'#f59cb5',orn:'#fff0c2'},
 {name:'Bulut Adaları',sky:['#69cbfc','#deeaff'],far:'#b0d5ee',mid:'#85afe5',ground:'#8f6fbd',top:'#e9efff',trim:'#b5cbff',tree:'#fff4fe',orn:'#ffe7a6'},
 {name:'Kristal Mağara',sky:['#453a79','#8b68b5'],far:'#6e5592',mid:'#4e3b79',ground:'#635083',top:'#85d6cf',trim:'#40a9b0',tree:'#8f6cff',orn:'#d0fcff'},
 {name:'Ayışığı Ormanı',sky:['#182b63','#684a93'],far:'#35466b',mid:'#25385a',ground:'#5b4263',top:'#70bfa0',trim:'#498b7a',tree:'#9c70e4',orn:'#fff4c3'},
 {name:'Kalp Şatosu',sky:['#ff9ab4','#b57fe5'],far:'#c899cc',mid:'#855da5',ground:'#946789',top:'#ffd3b7',trim:'#ec95b3',tree:'#e76eaa',orn:'#fff3c6'}
];
const META=['Çiçekler, düz yollar ve ilk küçük zıplamalar','Şeker renginde tepeler ve sürpriz bloklar','Bulutlar, basamaklar ve hareketli platformlar','Parlayan kristaller, mağara geçitleri','Ay ışığında engeller ve gizli ödüller','Kalp şatosuna giden son romantik yolculuk'];
let save={unlocked:1,best:{},sound:true,roseWallet:0,ownedOutfits:[0],outfit:0,mode:'normal',gifts:{},photos:[]};try{const s=JSON.parse(localStorage.getItem('kalpten-kalbe-save-v1')||'null');if(s&&typeof s==='object'){save={...save,...s};save.unlocked=Math.min(61,Math.max(1,Number(save.unlocked)||1));save.roseWallet=Math.max(0,Number(save.roseWallet)||0);save.ownedOutfits=Array.isArray(save.ownedOutfits)?[...new Set([0,...save.ownedOutfits.filter(x=>Number.isInteger(x)&&x>=0&&x<=3)])]:[0];save.outfit=save.ownedOutfits.includes(save.outfit)?save.outfit:0;}}catch(e){}
save.mode=['normal','hard','relax','love'].includes(save.mode)?save.mode:'normal';
if(!save.gifts||typeof save.gifts!=='object'||Array.isArray(save.gifts))save.gifts={};
if(!Array.isArray(save.photos))save.photos=[];
if(save.best&&save.best[60])save.unlocked=61;
const persist=()=>{try{localStorage.setItem('kalpten-kalbe-save-v1',JSON.stringify(save));}catch(e){}};
let state='menu',cutsceneTime=0,level=1,world=0,stage=null,player=null,camera=0,seconds=0,hearts=0,roses=0,score=0,particles=[],bubbles=[],screenShake=0,toastTimer=0,checkpointX=100,levelPage=0,muted=!save.sound,frame=0,held={left:false,right:false,jump:false},jumpQueued=false,clock=0,audio=null,musicClock=0,musicStep=0,secretReturn=null,pendingSecret=false,secretZone=false,shopPrevious='menu',goalNoticeCooldown=0,damageCount=0,chestsOpened=0,missionToastCooldown=0,cat={x:40,y:375,bob:0,helpCD:0},portalCooldown=0,portalQueued=false,dashCooldown=0,activeStory=0,albumBackTarget='menu',storyBackTarget='won',seenStoryDuringCompletion=false;
let cutsceneCameraTarget=0,dialogueSeen=new Set(),dialogueNPC=null,dialogueCooldown=0,photographyOrigin='playing',photoCaptured='',photoThumb='',finalBubblesClock=0,cutsceneTuneIndex=0,photoCounter=0;
function show(id){overlays.forEach(o=>$(o).classList.toggle('hidden',o!==id));$('hud').style.display=(id===null?'flex':'none');$('hudMission').style.display=(id===null?'block':'none');$('touch').classList.toggle('on',id===null);if(id!==null){Object.keys(held).forEach(k=>held[k]=false);jumpQueued=false;}}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function randseed(seed){let a=seed>>>0;return ()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
const randi=(r,a,b)=>a+Math.floor(r()*(b-a+1));

const OUTFITS=[
 {name:'Pembe Bahar',icon:'🌸',price:0,desc:'Orijinal pembe kazak · sevdiğimiz görünüm'},
 {name:'Gül Broşu',icon:'🌹',price:15,desc:'Yakada küçük gül broşu'},
 {name:'Ay Işığı',icon:'🌙',price:30,desc:'Parlayan ay broşu ve minik yıldızlar'},
 {name:'Kristal Kalp',icon:'💎',price:50,desc:'Işıltılı kalp rozeti ve pembe parıltılar'}
];
// V16.6: Original fully produced acoustic-inspired chiptune / romantic fantasy soundtrack.
// Warm piano, kalimba, soft strings, arpeggiated plucks, bass and gentle rhythm;
// pre-rendered and embedded as MP3 for reliable offline Android WebView playback.
const V166_MUSIC_MAIN='assets/music_01.mp3';
const V166_MUSIC_FINALE='assets/music_02.mp3';
const v166Tracks={
 main:new Audio(V166_MUSIC_MAIN),
 finale:new Audio(V166_MUSIC_FINALE)
};
for(const track of Object.values(v166Tracks)){
 track.preload='auto';track.loop=true;track.playsInline=true;
 track.volume=.55;
}
let loveMusicKey='',loveAudioActivated=false,v166Playing=null;
function v166DesiredMusic(){
 if(state==='paused'||state==='photo'||state==='dialogue')return null;
 if(state==='cutscene'||state==='won'||state==='story'||(level===61&&state==='playing'))return 'finale';
 if(['menu','levels','shop','album','help','playing'].includes(state))return 'main';
 return null;
}
function syncV166Music(){
 const song=!muted&&loveAudioActivated&&!document.hidden?v166DesiredMusic():null;
 const next=song?v166Tracks[song]:null;
 if(v166Playing!==next){
   if(v166Playing)v166Playing.pause();
   v166Playing=next;
   if(next){next.currentTime=0;const task=next.play();if(task&&task.catch)task.catch(()=>{});}
 }
 if(!next)return;
 const boss=(state==='playing'&&level%10===0&&stage&&stage.enemies&&stage.enemies.some(e=>e.alive&&e.type===4&&player&&Math.abs(e.x-player.x)<730));
 next.playbackRate=boss?1.13:1;
 const volume=song==='finale'?.53:state==='menu'?.37:boss?.56:.50;
 if(Math.abs(next.volume-volume)>.002)next.volume=volume;
 // Resume may be required after Android WebView returns from the background.
 if(next.paused&&audio?.state!=='suspended'){const task=next.play();if(task&&task.catch)task.catch(()=>{});}
}
function startLoveAudio(){loveAudioActivated=true;syncV166Music();}
function playRomanticScore(dt){syncV166Music();}
// Gesture-gated audio works in Chrome and Android HTML-to-APK WebViews.
document.addEventListener('pointerdown',startLoveAudio,{capture:true,passive:true});
document.addEventListener('touchstart',startLoveAudio,{capture:true,passive:true});
document.addEventListener('keydown',startLoveAudio,{capture:true});
function openShop(from){shopPrevious=from||'menu';state='shop';show('shop');renderShop();}
function renderShop(){
 $('roseBalance').textContent='🌹 '+save.roseWallet+' gül biriktirdin';
 $('outfitGrid').innerHTML=OUTFITS.map((o,i)=>{
  const owned=save.ownedOutfits.includes(i),selected=save.outfit===i;
  const action=selected?'✓ ÜZERİNDE':owned?'GİY':'🌹 '+o.price;
  return `<button class="outfitCard ${selected?'selected':''} ${owned?'':'locked'}" data-outfit="${i}" aria-label="${o.name}, ${action}"><span class="outfitIcon">${o.icon}</span><span class="outfitInfo">${o.name}<small>${o.desc}</small></span><span class="outfitPrice">${action}</span></button>`;
 }).join('');
 $('outfitGrid').querySelectorAll('[data-outfit]').forEach(btn=>btn.addEventListener('click',()=>{
  const i=Number(btn.dataset.outfit),o=OUTFITS[i];
  if(!save.ownedOutfits.includes(i)){
   if(save.roseWallet<o.price){$('roseBalance').textContent='🌹 '+(o.price-save.roseWallet)+' gül daha toplamalısın!';return;}
   save.roseWallet-=o.price;save.ownedOutfits.push(i);
  }
  save.outfit=i;persist();sound(930,.12,'triangle');renderShop();
 }));
}
function drawOutfitAccent(center,bottom,scale,t){
 if(save.outfit===0)return;
 const sx=scale, yy=bottom-35*sx, xx=center+12*sx;
 if(save.outfit===1){rose(xx-4,yy-5,11*sx);drawRect(center-6*sx,bottom-21*sx,17*sx,3*sx,'#d94583');}
 if(save.outfit===2){
  drawRect(center-14*sx,bottom-22*sx,28*sx,4*sx,'#c5a7f5');
  star(xx,yy,8*sx,'#fff6c5');star(center-19*sx,bottom-61*sx+Math.sin(t*3)*2,5*sx,'#f0dcff');
  star(center+22*sx,bottom-67*sx+Math.cos(t*2)*2,4*sx,'#f0dcff');
 }
 if(save.outfit===3){
  drawRect(center-14*sx,bottom-22*sx,28*sx,4*sx,'#bcecf5');
  heart(xx-3,yy-4,10*sx,'#baf7ff');
  star(center+26*sx,bottom-66*sx+Math.sin(t*3)*4,7*sx,'#ffe6ff');
  star(center-23*sx,bottom-42*sx+Math.sin(t*2)*3,5*sx,'#c1f7ff');
 }
}
function enterSecret(){
 if(secretZone||!pendingSecret)return;
 const oldX=player.x;
 secretReturn={stage,player,camera,checkpointX,returnX:oldX+T*3};
 pendingSecret=false;secretZone=true;
 const ncol=28,ground=Array(ncol).fill(420),gap=Array(ncol).fill(false);
 const items=[];
 for(let i=5;i<25;i+=3)items.push({x:i*T+8,y:ground[i]-75-(i%2)*24,type:i%2===0?'rose':'heart',taken:false,bob:i});
 items.push({x:14*T,y:ground[14]-100,type:'shield',taken:false,bob:1});
 stage={width:ncol*T,ncol,ground,gap,platforms:[{x:9*T,y:315,w:3*T,h:17,moving:false},{x:17*T,y:305,w:3*T,h:17,moving:false}],blocks:[],items,enemies:[],checkpoints:[],boy:{x:Infinity,y:0,w:0,h:0},seed:-1};
 resetPlayer(75,secretReturn.player.health);player.shield=secretReturn.player.shield;player.doubleTimer=secretReturn.player.doubleTimer;player.magnetTimer=secretReturn.player.magnetTimer;player.dashTimer=secretReturn.player.dashTimer;player.glideTimer=secretReturn.player.glideTimer;
 camera=0;notify('✨ GİZLİ ODA! Kalpleri topla, sağdan çık.',3);sound(1050,.18,'triangle');
}
function exitSecret(){
 if(!secretZone||!secretReturn)return;
 const current=player,back=secretReturn;
 stage=back.stage;player=back.player;checkpointX=back.checkpointX;
 player.x=Math.min(stage.width-300,back.returnX);player.y=groundAt(player.x)-player.h;player.vx=0;player.vy=0;player.inv=2;
 player.shield=current.shield;player.doubleTimer=current.doubleTimer;player.magnetTimer=current.magnetTimer;player.dashTimer=current.dashTimer;player.glideTimer=current.glideTimer;
 camera=clamp(player.x-300,0,stage.width-W);
 secretZone=false;secretReturn=null;notify('💝 Gizli oda ödülleri senin!',2.8);sound(1000,.18,'sine');
}

// V11: optional missions, weather, portals, cat, treasure and romantic memories.
const STORIES=[
 {n:10,icon:'🌸',title:'İLK BULUŞMA',text:'Gül bahçesindeki ilk yolculuğun sonunda birlikte oturup çiçekleri izlediniz. Her yeni yol, güzel bir anıya dönüştü.'},
 {n:20,icon:'🧺',title:'PİKNİK GÜNÜ',text:'Şeker tepelerinde küçük bir piknik yaptınız. Gülüşleriniz bütün dünyayı daha renkli kıldı.'},
 {n:30,icon:'☁️',title:'BULUTLARIN ÜSTÜNDE',text:'Bulutların üstünde yan yana durup yeni hayaller kurdunuz. En güzel macera, birlikte ilerlemekti.'},
 {n:40,icon:'💎',title:'IŞILTILI BİR ANI',text:'Kristal mağarada saklı bir kalp buldunuz. Küçük sürprizler bile birlikteyken büyülü olur.'},
 {n:50,icon:'🌙',title:'YILDIZLARI İZLERKEN',text:'Ay ışığının altında yıldızları sayıp uzun uzun konuştunuz. Gece, ortak bir hatıraya dönüştü.'},
 {n:60,icon:'🏰',title:'KALP ŞATOSU',text:'Altmış macera boyunca bütün yollar sonunda aynı yere çıktı: birbirinizin yanına. Ama bir sürpriz daha var...'},
 {n:61,icon:'💝',title:'SONSUZ BAHÇE',text:'Gizli bahçede artık engeller yok. Birlikte yürüyebilir, gülleri toplayabilir ve bu güzel anın tadını çıkarabilirsiniz. İyi ki varsın ❤️'}
];
function missionFor(n){if(n===61)return {type:'walk',target:0,label:'Sürpriz bahçeye ulaş'};const r=(n-1)%4;return r===0?{type:'hearts',target:4,label:'4 kalp topla'}:r===1?{type:'roses',target:3,label:'3 gül topla'}:r===2?{type:'chest',target:1,label:'Gizli sandığı aç'}:{type:'clean',target:0,label:'Hasar almadan bitir'};}
function missionAchieved(){const m=stage?.mission;if(!m)return false;return m.type==='hearts'?hearts>=m.target:m.type==='roses'?roses>=m.target:m.type==='chest'?chestsOpened>=1:m.type==='walk'?true:damageCount===0;}
function missionStatus(){if(!stage?.mission)return '';const m=stage.mission,v=m.type==='hearts'?hearts:m.type==='roses'?roses:m.type==='chest'?chestsOpened:m.type==='clean'?damageCount:0;return m.type==='clean'?(damageCount===0?'✨ Hasarsız gidiyorsun':'🌷 Tekrar deneyebilirsin'):m.type==='walk'?'💗 Düşmansız sürpriz bahçe':`${m.label} (${Math.min(m.target,v)}/${m.target})`;}
function makeGarden(){
 const ncol=104,w=ncol*T,ground=Array(ncol).fill(420),gap=Array(ncol).fill(false),items=[],platforms=[],blocks=[],enemies=[],checkpoints=[];
 for(let i=7;i<ncol-10;i+=4){items.push({x:i*T+12,y:ground[i]-73,type:i%3===0?'heart':'rose',taken:false,bob:i});}
 for(const i of [24,48,73])platforms.push({x:i*T,y:330,w:3*T,h:17,moving:false,type:'normal'});
 return {width:w,ncol,ground,gap,platforms,blocks,items,enemies,checkpoints,boy:{x:w-145,y:369,w:37,h:52},seed:61,chests:[{x:26*T,y:385,w:34,h:35,opened:false,secret:true}],portals:[],mission:missionFor(61),weather:'petals'};
}
function setupExtras(st,n){
 const r=randseed(98731+n*57);
 st.mission=missionFor(n);st.chests=[];st.portals=[];
 const spots=n===1?[62]:[Math.floor(st.ncol*.22),Math.floor(st.ncol*.52)];
 for(const tile0 of spots){let tile=tile0;while((st.gap[tile]||st.gap[tile-1]||st.gap[tile+1])&&tile<st.ncol-25)tile++;if(tile>=st.ncol-25)continue;st.chests.push({x:tile*T+2,y:st.ground[tile]-33,w:36,h:33,opened:false,secret:tile0===spots[1]});}
 if(n>=4 && n%4===0){
  let a=Math.floor(st.ncol*.30),b=Math.floor(st.ncol*.64);
  while(st.gap[a]&&a<st.ncol-30)a++;while(st.gap[b]&&b<st.ncol-25)b++;
  st.portals.push({x:a*T,y:st.ground[a]-76,w:36,h:76,target:b*T+8});
  st.portals.push({x:b*T,y:st.ground[b]-76,w:36,h:76,target:a*T+8});
 }
 for(let i=0;i<st.platforms.length;i++){
  const pl=st.platforms[i];pl.type='normal';pl.breakTimer=0;pl.brokenTimer=0;
  if(n>=6 && i%7===3)pl.type='spring';
  else if(n>=11 && i%9===4)pl.type='crumble';
 }
 // Kademeli güçlendirmeler: dash ilk kez 5, süzülme ilk kez 8. bölümde.
 const special=n>=8?'glide':n>=5?'dash':null;
 if(special){const i=Math.floor(st.ncol*.42);if(!st.gap[i])st.items.push({x:i*T,y:st.ground[i]-116,type:n%2===0&&n>=8?'glide':'dash',taken:false,bob:i});}
 st.weather=n%5===0?'rain':n%7===0?'wind':n%3===0?'petals':'sunny';
 if(n>=41&&n%2===0)st.weather='snow';
 return st;
}
function openChest(c){if(c.opened)return;c.opened=true;chestsOpened++;save.roseWallet+=c.secret?6:3;roses+=c.secret?6:3;score+=150;persist();dust(c.x+17,c.y,'#ffde88',18);sound(1040,.17,'triangle');notify(`🎁 SANDIK! +${c.secret?6:3} gül`,1.8);refreshHUD();}
function usePortal(){
 if(tryTalkNPC())return;
 if(state!=='playing'||secretZone||portalCooldown>0||!stage.portals?.length)return;
 const nearby=stage.portals.find(port=>Math.abs(player.x+player.w/2-(port.x+18))<70 && Math.abs(player.y+player.h/2-(port.y+40))<105);
 if(!nearby)return;
 const target=nearby.target;let safeX=target;
 if(groundAt(safeX)===Infinity){safeX+=T*2;}
 if(!Number.isFinite(groundAt(safeX)))return;
 player.x=safeX;player.y=groundAt(safeX)-player.h;player.vy=0;player.vx=0;player.inv=.6;portalCooldown=1.5;camera=clamp(player.x-300,0,Math.max(0,stage.width-W));sound(1100,.20,'triangle');dust(player.x,player.y,'#c9a4ff',16);notify('🌀 Kalp portalından geçtin!',1.4);
}
function triggerDash(){if(state!=='playing'||!player||player.dashTimer<=0||dashCooldown>0)return;player.vx=player.facing*410;player.dashBurst=.32;dashCooldown=2.0;dust(player.x+10,player.y+31,'#b3f4ff',12);sound(830,.14,'triangle');notify('💨 Kalp hızı!',1.0);}
function drawPortal(port){
 const x=port.x,y=port.y;ctx.save();ctx.strokeStyle='#57277a';ctx.lineWidth=9;ctx.beginPath();ctx.ellipse(x+18,y+38,19,39,0,0,Math.PI*2);ctx.stroke();ctx.strokeStyle='#e6aaff';ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(x+18,y+38,14,35,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#ae77ec70';ctx.beginPath();ctx.ellipse(x+18,y+38,12,31,0,0,Math.PI*2);ctx.fill();heart(x+8,y+30+Math.sin(clock*4)*5,19,'#ffe3ff');ctx.restore();
}
function drawChest(c){
 drawRect(c.x,c.y+9,34,24,c.opened?'#8a6670':'#925538');drawRect(c.x+3,c.y+12,28,16,c.opened?'#bd9f9d':'#d69b55');drawRect(c.x+13,c.y+8,8,25,'#ffdc91');drawRect(c.x+4,c.y+19,25,4,'#ffdc91');
 if(c.opened){drawRect(c.x-2,c.y-2,38,9,'#e6a676');star(c.x+17,c.y-13,8,'#fff0ae');}
 else{drawRect(c.x+3,c.y+4,28,7,'#e8ac68');heart(c.x+14,c.y+12,8,'#f774a4');}
}
function drawCat(){
 if(secretZone||!cat)return;const x=cat.x,y=cat.y;
 drawRect(x+7,y+10,22,15,'#f9efe4');drawRect(x+10,y+6,18,10,'#fff9ed');drawRect(x+11,y+3,5,7,'#f9e5e7');drawRect(x+23,y+3,5,7,'#f9e5e7');drawRect(x+14,y+12,3,3,'#39233a');drawRect(x+23,y+12,3,3,'#39233a');drawRect(x+19,y+15,3,3,'#ee99ac');drawRect(x+10,y+24,5,5,'#ddd2d3');drawRect(x+23,y+24,5,5,'#ddd2d3');drawRect(x+28,y+16,6,4,'#f9efe4');if(stage.chests?.some(c=>!c.opened&&Math.abs(c.x-x)<110))star(x+30,y-4+Math.sin(clock*5)*2,9,'#ffe99b');
}
function updateCat(dt){
 if(!player||secretZone)return;
 cat.x+=(player.x-56-cat.x)*Math.min(1,dt*4.5);cat.y+=(player.y+player.h-27-cat.y)*Math.min(1,dt*6);cat.helpCD=Math.max(0,cat.helpCD-dt);
 if(cat.helpCD<=0){const near=stage.items.find(it=>!it.taken&&(it.type==='heart'||it.type==='rose')&&Math.abs(it.x-cat.x)<26&&Math.abs(it.y-cat.y)<35);if(near){collect(near);cat.helpCD=4;dust(near.x,near.y,'#fff2d8',6);}}
}
function drawWeather(){
 if(!stage)return;const kind=stage.weather;if(kind==='sunny')return;
 ctx.save();const t=clock;
 const count=(kind==='rain'?55:kind==='snow'?38:kind==='petals'?32:24)*(v16Perf.quality===1?.55:1);
 for(let i=0;i<count;i++){
  const x=((i*167+(kind==='wind'?t*85:kind==='snow'?t*17:kind==='rain'?t*65:t*22)-camera*.045)%(W+120)+W+120)%(W+120)-40;
  const y=((i*83+(kind==='rain'?t*360:kind==='snow'?t*46:kind==='petals'?t*29:t*10))%(H+90)+H+90)%(H+90)-50;
  if(kind==='rain')drawRect(x,y,2,12,'#d6efff75');
  else if(kind==='snow')star(x,y,3,'#ffffffb8');
  else if(kind==='wind'){drawRect(x,y,22,2,'#ffffff50');}
  else{drawRect(x,y,6,4,'#ffd1eeb3');}
 }
 ctx.restore();
}
function showStory(n){
 const info=STORIES.find(s=>s.n===n);if(!info)return;activeStory=n;storyBackTarget='won';albumBackTarget='won';state='story';show('story');$('storyIcon').textContent=info.icon;$('storyTitle').textContent=info.title;$('storyText').textContent=info.text;$('storyImg').src=coupleFrames[(Math.floor(n/10))%4].src;seenStoryDuringCompletion=true;
}
function renderAlbum(){
 renderAlbumV12();
 $('albumGrid').innerHTML=STORIES.map((m,i)=>{
  const unlocked=!!save.best[m.n] || (m.n<=60&&save.unlocked>m.n) || (m.n===61&&!!save.best[61]);
  const worldGrad=["linear-gradient(145deg,#79335b,#d583af)","linear-gradient(145deg,#8e4c7c,#e9aa80)","linear-gradient(145deg,#427ac1,#9dc7e7)","linear-gradient(145deg,#473363,#9779cc)","linear-gradient(145deg,#1e326b,#64558e)","linear-gradient(145deg,#8f4b97,#efa5be)","linear-gradient(145deg,#a9558d,#f7c7d6)"];
  return `<button style="background:${unlocked?worldGrad[i]:'#362844'}" class="albumCard ${unlocked?'':'locked'}" data-story="${m.n}" ${unlocked?'':'disabled'}>${unlocked?`<img alt="Anı ${i+1}" src="${coupleFrames[i%4].src}" />`:`<div class="lockedMemory">💌</div>`}<span>${unlocked?m.icon:'🔒'} ${unlocked?m.title:'Kilitli anı'}</span><small>${unlocked?'Bölüm '+m.n+' tamamlandı':'Bölüm '+m.n+' bitir'}</small></button>`;
 }).join('');
 $('albumGrid').querySelectorAll('[data-story]').forEach(el=>el.onclick=()=>{showStory(Number(el.dataset.story));albumBackTarget='album';});
}
function openAlbum(back='menu'){albumBackTarget=back;state='album';show('album');renderAlbum();}


const GIFT_TYPES=[
  {id:'letter',label:'Aşk Mektubu',icon:'💌'},
  {id:'bouquet',label:'Gül Buketi',icon:'💐'},
  {id:'ribbon',label:'Hatıra Kurdele',icon:'🎀'},
  {id:'star',label:'Yıldız Hatırası',icon:'🌟'},
  {id:'ring',label:'Sürpriz Kutu',icon:'🎁'}
];
const NPC_DIALOGUES=[
  {name:'Çiçekçi Teyze',icon:'🌺',color:'#f4b6d7',line:'Güller en güzel kalpten verilince açar. Bir buket de benden!'},
  {name:'Kalp Perisi',icon:'🧚',color:'#baabff',line:'Yolun sonunda seni seven biri var. Kalpleriniz hep birlikte atsın!'},
  {name:'Bilge Bahçıvan',icon:'🌿',color:'#9fdaac',line:'Güzel bir yolculuk acele etmeden de tamamlanır. Küçük mutlulukları topla!'},
  {name:'Minik Gezgin',icon:'🧸',color:'#ffe4a4',line:'En güzel hazine, birlikte biriktirdiğiniz anılar!'}
];
function applyV12Level(st,n){
 st.giftsFound=0;
 const rng=randseed(38391+n*97);
 st.npcs=[];
 if(n<61){
   const count=n<=10?1:2;
   for(let k=0;k<count;k++){
     const center=Math.floor(st.ncol*(k===0?.18:.69));
     let i=center;
     while(i<st.ncol-19 && (st.gap[i]||st.gap[i-1]||st.gap[i+1])) i++;
     if(i<st.ncol-19)st.npcs.push({x:i*T+8,y:st.ground[i]-42,type:(n+k)%NPC_DIALOGUES.length,talked:false});
   }
   for(const frac of [.34,.71]){
      let i=Math.floor(st.ncol*frac);
      while(i<st.ncol-18&&(st.gap[i]||st.gap[i+1]))i++;
      if(i<st.ncol-18)st.items.push({x:i*T+16,y:st.ground[i]-72,type:'gift',giftId:GIFT_TYPES[(n+i)%GIFT_TYPES.length].id,taken:false,bob:rng()*6});
   }
   // Non-punishing modes keep progression/boss gates intact.
   if(save.mode==='relax')st.enemies=st.enemies.filter((e,i)=>e.type===4||i%2===0);
   if(save.mode==='love')st.enemies=st.enemies.filter(e=>e.type===4);
   if(save.mode==='love')for(const e of st.enemies)if(e.type===4)e.hp=1;
   if(save.mode==='hard'){
     // Challenge: more and quicker enemies, but safe ground, checkpoints and three hearts remain unchanged.
     for(const e of st.enemies){
       e.vx*=e.type===4?1.16:1.28;
       e.range=Math.round(e.range*(e.type===4?1.08:1.15));
       if(e.type===4)e.hp+=1;
     }
     // Gradually add one to four stompable enemies. Avoid gaps, gates, checkpoints, NPCs and boss area.
     for(const target of (n<=10?[105]:n<=20?[58,151]:n<=40?[58,105,151]:[58,105,151,195])){
       let ti=target;
       if(ti>=st.ncol-23)continue;
       while(ti<Math.min(target+10,st.ncol-23)){
         const x=ti*T;
         if(!st.gap[ti-1]&&!st.gap[ti]&&!st.gap[ti+1]&&!st.gap[ti+2]
           &&Math.abs(x-st.boy.x)>520
           &&!st.enemies.some(e=>Math.abs(e.x-x)<300)
           &&!st.checkpoints.some(c=>Math.abs(c.x-x)<240)
           &&!st.npcs.some(npc=>Math.abs(npc.x-x)<150)
           &&!st.portals.some(port=>Math.abs(port.x-x)<120)
           &&!st.chests.some(ch=>Math.abs(ch.x-x)<120)){
           st.enemies.push({x,y:st.ground[ti]-29,startX:x,w:29,h:28,
             vx:(ti%2===0?1:-1)*(49+Math.min(20,Math.floor(n/4))),
             range:45+((n+ti)%24),alive:true,type:0});
           break;
         }
         ti++;
       }
     }
   }
 }else{
   st.npcs=[{x:14*T,y:378,type:0,talked:false},{x:58*T,y:378,type:1,talked:false}];
   st.items.push({x:58*T,y:333,type:'gift',giftId:'bouquet',taken:false,bob:0});
 }
 return st;
}
function drawGift(x,y,t){
 const floatY=Math.sin(t*2+((x|0)%10)) * 2;
 drawRect(x-13,y-12+floatY,27,23,'#833e6b');drawRect(x-10,y-10+floatY,21,17,'#ffe0a1');
 drawRect(x-2,y-14+floatY,6,23,'#f483a9');drawRect(x-12,y-3+floatY,25,5,'#f483a9');
 heart(x-4,y-21+floatY,11,'#fff6d5');
}
function drawNPCFriend(n){
 const x=n.x,y=n.y,b=NPC_DIALOGUES[n.type],bob=Math.sin(clock*2+n.x*.001)*1.1;
 ctx.fillStyle='#0000001c';ctx.fillRect(x+3,y+38,27,3);
 drawRect(x+10,y+21+bob,19,22,b.color);
 drawRect(x+15,y+12+bob,14,15,'#f2c6a8');
 drawRect(x+12,y+9+bob,19,8,n.type===1?'#d9c6fd':'#68454c');
 drawRect(x+17,y+18+bob,3,3,'#272339');drawRect(x+26,y+18+bob,3,3,'#272339');
 drawRect(x+11,y+42+bob,8,4,'#f8e6f4');drawRect(x+24,y+42+bob,8,4,'#f8e6f4');
 if(n.type===0)rose(x+3,y+24+bob,13);
 if(n.type===1)star(x+3,y+14+bob,12,'#fff0a7');
 if(!n.talked&&Math.abs(n.x-player.x)<105){
   drawRect(x-8,y-22,48,19,'#41254f');drawRect(x-7,y-21,46,17,'#ffe8fa');
   ctx.save();ctx.fillStyle='#653d68';ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillText('E / 💬',x+16,y-9);ctx.restore();
 }
}
function tryTalkNPC(){
 if(state!=='playing'||secretZone)return false;
 const n=stage.npcs?.find(n=>!n.talked&&Math.abs(n.x-player.x)<96&&Math.abs(n.y-player.y)<62);
 if(!n)return false;
 const info=NPC_DIALOGUES[n.type];n.talked=true;dialogueNPC=n;
 if(n.type===0){save.gifts.bouquet=(save.gifts.bouquet||0)+1;persist();}
 $('npcPortrait').textContent=info.icon;$('dialogueName').textContent=info.name;
 $('dialogueText').textContent=info.line+(n.type===0?' 🎁 Buket albümüne eklendi.':'');
 state='dialogue';show('dialogue');sound(670,.12,'triangle');return true;
}
function showPhotoMode(){
 if(state!=='playing'&&state!=='paused'&&state!=='cutscene')return;
 photographyOrigin=state;
 // Capture only the game canvas, without the HUD or overlays.
 try{photoCaptured=canvas.toDataURL('image/png');
   const mini=document.createElement('canvas');mini.width=240;mini.height=135;
   mini.getContext('2d').drawImage(canvas,0,0,240,135);
   photoThumb=mini.toDataURL('image/jpeg',.58);
   $('photoPreview').src=photoCaptured;
 }catch(e){notify('Fotoğraf alınamadı.',2);return;}
 state='photo';show('photo');
}
function closePhotoMode(){
 state=photographyOrigin;show(photographyOrigin==='paused'?'paused':null);
 if(state==='cutscene'){$('hud').style.display='none';$('hudMission').style.display='none';$('touch').classList.remove('on');$('scenePhotoBtn').style.display='block';}
 last=performance.now();
}
function savePhoto(){
 if(!photoCaptured)return;
 save.photos.push({level,shot:photoThumb,date:new Date().toLocaleDateString('tr-TR')});
 save.photos=save.photos.slice(-8);persist();
 try{const link=document.createElement('a');link.download='kalpten-kalbe-ani-bolum-'+level+'.png';link.href=photoCaptured;document.body.appendChild(link);link.click();link.remove();}catch(e){/* APK wrapper can omit downloads; album copy is already saved. */}
 closePhotoMode();notify('📸 Anın albüme eklendi!',2);
}
function renderAlbumV12(){
 $('giftGrid').innerHTML=GIFT_TYPES.map(g=>`<div class="giftItem"><b>${g.icon} ${g.label}</b><span>${save.gifts[g.id]||0} adet</span></div>`).join('');
 $('photoGallery').innerHTML=save.photos.length?save.photos.map((p,i)=>`<figure class="photoMemory"><img alt="Kaydedilen oyun anısı" src="${p.shot}"/><figcaption>📷 Bölüm ${p.level} · ${p.date}</figcaption></figure>`).join(''):'<div class="smallprint">Henüz fotoğraf yok. Oyunda 📸 tuşuna basarak ilk anını kaydet.</div>';
}
function syncGameMode(){
 const desc={normal:'Dengeli Mario tarzı macera; kademeli zorluk.',hard:'🔥 Zor: Daha hızlı ve daha fazla düşman; bossların 1 canı fazla. Kontrol noktaları korunur.',relax:'Daha az düşman; aynı ödüller ve bölümler.',love:'Düşmansız keşif; sadece boss bölümlerinde kolay bir karşılaşma.'};
 document.querySelectorAll('[data-mode]').forEach(b=>{b.classList.toggle('selected',b.dataset.mode===save.mode);b.setAttribute('aria-pressed',String(b.dataset.mode===save.mode));});
 $('modeDescription').textContent=desc[save.mode];
}
function drawEnvironmentalDepth(){
 // Weather-like light animation, deliberately subtle over scenic paintings.
 const t=clock, par=camera*.09;
 ctx.save();
 if(world===0 || world===1 || world===5){
   // Sunlit drifting petals with varied depth and speed.
   for(let i=0;i<13;i++){
     const xx=((i*117+Math.sin(t*.65+i)*9-par*.55+t*(5+(i%3)*3))%(W+80)+W+80)%(W+80)-35;
     const yy=66+(i*47)%315+Math.sin(t*1.5+i)*8;
     ctx.save();ctx.translate(xx,yy);ctx.rotate(.2*Math.sin(t*1.6+i));
     ctx.fillStyle=i%3===0?'#fff2e2ad':'#ffb9d3a8';
     ctx.fillRect(0,0,i%3===0?5:4,i%2===0?3:5);
     ctx.restore();
   }
 }
 if(world===2){
   for(let i=0;i<8;i++){
     const x=((i*172-par*.4)%(W+200)+W+200)%(W+200)-80;
     const y=78+(i*53)%215;
     ctx.fillStyle='rgba(255,255,255,.1)';
     ctx.beginPath();ctx.ellipse(x,y,42+10*Math.sin(i+t*.1),9,0,0,Math.PI*2);ctx.fill();
   }
 }
 if(world===3 || world===4){
   for(let i=0;i<24;i++){
     const x=((i*139-par*.3)%(W+60)+W+60)%(W+60);
     const y=65+(i*73)%310+Math.sin(t+i*2)*8;
     const opacity=.35+.28*Math.sin(t*2+i);
     ctx.fillStyle=world===3?'rgba(135,250,255,'+opacity.toFixed(3)+')':'rgba(255,236,159,'+opacity.toFixed(3)+')';
     ctx.fillRect(Math.round(x),Math.round(y),i%4===0?3:2,i%4===0?3:2);
   }
 }
 ctx.restore();
}

function drawDialogueHUD(){
 if(state==='cutscene'&&cutsceneTime>1.05&&cutsceneTime<5.4){
   const messages=level===61?['Sana kavuştum!','Her macera seninle güzel.','Bu oyun senin için yapıldı ❤️']:
      level%3===0?['Yine buluştuk!','Birlikte daha güçlüyüz.','Yeni bir maceraya!']:
      level%3===1?['Bir gül de sana 🌹','El ele devam edelim!','İyi ki varsın ❤️']:
      ['Sonunda yanındayım!','Birlikte yürüyelim.','Seni çok seviyorum 💕'];
   const index=Math.min(2,Math.floor((cutsceneTime-1.05)/1.42));
   const txt=messages[index];
   ctx.save();ctx.font='bold 20px system-ui';ctx.textAlign='center';
   ctx.fillStyle='#2e1a45d9';ctx.fillRect(W/2-195,32,390,44);
   ctx.strokeStyle='#ffbad8';ctx.lineWidth=2;ctx.strokeRect(W/2-195,32,390,44);
   ctx.fillStyle='#fff7e9';ctx.fillText(txt,W/2,61);ctx.restore();
 }
}

function makeLevel(n){
 if(n===61)return enhanceV16Level(applyV12Level(makeGarden(),61),61);
 const r=randseed(n*124579+7341),difficulty=(n-1)/59,w=Math.floor((228+(n%10)*2))*T,ncol=w/T;
 const ground=Array(ncol).fill(420),gap=Array(ncol).fill(false);let height=0,change=19;
 for(let i=0;i<ncol;i++){if(i>18&&i<ncol-15&&i>=change){height=clamp(height+randi(r,-1,1),-1,1);change=i+randi(r,17,29);}ground[i]=420-height*38;}
 for(let i=24;i<ncol-21;i+=randi(r,22,35)){
  if(r()<(0.48+difficulty*.38)){let len=1+(r()<.27+difficulty*.34?1:0)+(n>35&&r()<.10?1:0);for(let j=i;j<i+len&&j<ncol-18;j++){if(j%116<7||j%116>110)continue;gap[j]=true;}}
 }
 for(let i=0;i<15;i++){gap[i]=false;ground[i]=420;}for(let i=ncol-18;i<ncol;i++){gap[i]=false;ground[i]=420;}
 for(let j=0;j<ncol;j++){if(j%116<6||j%116>110)gap[j]=false;}
 const platforms=[],blocks=[],items=[],enemies=[],checkpoints=[];
 for(let i=28;i<ncol-25;i+=randi(r,14,23)){
  const yy=ground[i];if(!gap[i]&&r()<.72){const x=(i+0.4)*T;platforms.push({x,y:yy-randi(r,80,113),w:randi(r,2,4)*T,h:17,moving:n>=21&&r()<(.10+difficulty*.15),center:x,amplitude:20+r()*28,t:r()*7,lastX:x});}
 }
 for(let i=16;i<ncol-23;i+=randi(r,18,31)){
  if(!gap[i]&&!gap[i+1]&&r()<.74){const count=r()<.33?2:1;for(let z=0;z<count;z++){blocks.push({x:(i+z)*T,y:ground[i]-randi(r,152,162),w:T,h:T,type:r()<.64?'question':'brick',hit:false});}}
 }
 for(let i=8;i<ncol-12;i+=randi(r,5,10)){
  if(gap[i])continue;const rose=r()<.36;const x=(i+.5)*T;const y=ground[i]-randi(r,54,84);items.push({x,y,type:rose?'rose':'heart',taken:false,bob:r()*Math.PI*2});
  if(r()<.24){items.push({x:x+30,y:y-29,type:rose?'heart':'rose',taken:false,bob:r()*6});}
 }
 const enemySpacing=Math.floor(81-difficulty*34);for(let i=45;i<ncol-23;i+=enemySpacing+randi(r,-12,12)){
  if(gap[i]||gap[i-1]||gap[i+1]||gap[i+2]||r()<(n<4?.55:.14))continue;
  enemies.push({x:i*T,y:ground[i]-29,startX:i*T,w:29,h:28,vx:(n<11?31:38+difficulty*25)*(r()<.5?-1:1),range:randi(r,32,70),alive:true,type:n>=31&&r()<.28?1:0});
 }
 for(let i=95;i<ncol-20;i+=95){checkpoints.push({x:i*T,y:ground[i]-94,active:false});gap[i]=gap[i+1]=gap[i+2]=false;}
 // Koleksiyon ve tehlikeler giriş, çıkış ve kontrol noktalarında çakışmaz.
 // Tehlikeler sıkışmasın: her 10. bölümün sonunda iki-üç vuruşluk nazik bir boss var.
 if(n%10===0){
   const i=ncol-12,x=i*T;
   for(let q=i-7;q<ncol;q++)gap[q]=false;
   for(let q=enemies.length-1;q>=0;q--)if(Math.abs(enemies[q].x-x)<420)enemies.splice(q,1);
   enemies.push({x,y:ground[i]-60,startX:x,w:62,h:60,vx:-34,range:118,alive:true,type:4,hp:n===60?3:2});
 }
 // Yeni düşman türleri kademeli açılır (uçan arı, dikenli top, salyangoz).
 for(const e of enemies){
   if(e.type===4)continue;
   const odds=r();
   if(n>=13&&odds<.17){e.type=2;e.y-=45;e.baseY=e.y;e.h=24;e.w=29;e.range=75;e.vx*=.85;}
   else if(n>=25&&odds<.33){e.type=3;e.h=24;e.w=29;}
   else if(n>=6&&odds<.52){e.type=1;}
 }
 // Güçlendirmeler: kalp kalkanı, çift zıplama ve yakındaki kalpleri çekme.
 for(const fraction of [.27,.55,.78]){
   const i=Math.floor(ncol*fraction);
   if(!gap[i]&&!gap[i-1])items.push({x:i*T+12,y:ground[i]-110,type:fraction===.27?'shield':fraction===.55?'double':'magnet',taken:false,bob:i});
 }
 // Bazı gizli tuğlalar gerçek oynanabilir bonus odalara açılır.
 if(n===1||n%3===0){
   const block=blocks.find(b=>b.type==='brick'&&b.x>1150&&b.x<w-2700);
   if(block)block.type='secret';
   else{const i=Math.floor(ncol*.33);if(!gap[i])blocks.push({x:i*T,y:ground[i]-154,w:T,h:T,type:'secret',hit:false});}
 }
 const boy={x:w-185,y:ground[ncol-5]-51,w:37,h:52};
 return enhanceV16Level(applyV12Level(setupExtras({width:w,ncol,ground,gap,platforms,blocks,items,enemies,checkpoints,boy,seed:n},n),n),n);
}
// V16: themed optional upper lanes, short stairs, bridges and moving stepping-stones.
function enhanceV16Level(stage,n){
 stage.v16PatternNames=[];
 stage.bossShots=[];
 stage.bossShotsFired=0;
 stage.bossHits=0;
 if(n===61)return stage;
 const motifs=['Çiçek Basamakları','Kalp Yolu','Bulut Köprüsü','Zigzag Teras','Hareketli Adacıklar'];
 const sections=n<=3?[.36,.68]:n<=15?[.22,.49,.74]:[.20,.42,.65,.82];
 for(let sidx=0;sidx<sections.length;sidx++){
  const ti=Math.floor(stage.ncol*sections[sidx]);
  let i=-1;
  // Find a corridor away from checkpoints and the finish. Each section gets
  // a real set piece rather than randomly disappearing whenever a tiny gap occurs.
  for(const offset of [0,8,-8,16,-16,24,-24,32,-32]){
   const candidate=ti+offset-3;
   if(candidate<25||candidate+20>stage.ncol-25)continue;
   if(stage.checkpoints.some(cp=>Math.abs(cp.x-candidate*T)<270))continue;
   if(Math.abs(stage.boy.x-candidate*T)<680)continue;
   if(stage.v16PatternPositions?.some(x=>Math.abs(x-candidate*T)<800))continue;
   i=candidate;break;
  }
  if(i<0)continue;
  if(!stage.v16PatternPositions)stage.v16PatternPositions=[];
  stage.v16PatternPositions.push(i*T);
  // The authored alternative route is placed above a deliberately safe landing
  // zone; remove only tiny accidental random gaps inside its landing corridor.
  for(let k=i-2;k<i+19;k++)stage.gap[k]=false;
  const type=(Math.floor((n-1)/4)+sidx)%5;
  const groundY=stage.ground[i],baseX=i*T;
  // Clean up only conflicting ordinary platforms/blocks in an optional route.
  stage.platforms=stage.platforms.filter(pl=>pl.x<baseX-75||pl.x>baseX+730);
  stage.blocks=stage.blocks.filter(bl=>bl.type==='secret'||bl.x<baseX-35||bl.x>baseX+740);
  const add=(dx,dy,w=112,moving=false)=>{
   const pl={x:baseX+dx,y:groundY-dy,w,h:17,moving,center:baseX+dx,
     amplitude:moving?30:0,t:(n*.29+dx*.008),lastX:baseX+dx,
     type:'normal',breakTimer:0,brokenTimer:0};
   stage.platforms.push(pl);return pl;
  };
  if(type===0){add(20,69);add(145,116);add(270,160);add(395,111);add(520,74);}
  else if(type===1){add(25,88,130);add(190,92,120);add(360,142,130);add(530,87,120);}
  else if(type===2){add(20,68,110);add(180,105,135);add(362,69,110);add(520,100,130);}
  else if(type===3){add(10,75,120);add(155,128,100);add(280,77,120);add(435,129,100);add(570,79,120);}
  else{add(20,75,130);add(205,115,115,n>=21);add(392,79,120,n>=21);add(555,110,115);}
  stage.v16PatternNames.push(motifs[type]);
  for(let j=0;j<3;j++){
   const ox=[88,320,585][j],oy=type===0?[106,195,115][j]:[122,176,120][j];
   stage.items.push({x:baseX+ox,y:groundY-oy,type:j===1?'rose':'heart',taken:false,bob:(j+n)*1.15});
  }
 }
 // Each of six guardians gains a distinctive, avoidable attack style.
 for(const e of stage.enemies){if(e.type!==4)continue;
  e.bossKind=Math.max(0,Math.min(5,Math.floor(n/10)-1));
  e.bossCooldown=2.0;e.bossWarning=0;e.bossAttacks=0;
 }
 return stage;
}

function groundAt(x){const i=clamp(Math.floor(x/T),0,stage.ncol-1);return stage.gap[i]?Infinity:stage.ground[i];}
function resetPlayer(x=96,health=3){const y=groundAt(x);player={x,y:y-49,w:29,h:49,vx:0,vy:0,onGround:false,coyote:0,inv:0,health:clamp(health,1,3),facing:1,prevBottom:y,steps:0,jumps:0,v16Pose:'idle',v16OldPose:'idle',v16PoseTime:0,shield:0,doubleTimer:0,magnetTimer:0,dashTimer:0,glideTimer:0,dashBurst:0,wall:0};}
function launch(n){$('scenePhotoBtn').style.display='none';secretReturn=null;secretZone=false;pendingSecret=false;musicStep=0;musicClock=0;loveMusicKey='';level=n;world=Math.min(5,Math.floor((level-1)/10));stage=makeLevel(level);camera=0;seconds=0;score=0;hearts=0;roses=0;checkpointX=100;damageCount=0;chestsOpened=0;portalCooldown=0;dashCooldown=0;cat={x:40,y:380,bob:0,helpCD:0};dialogueCooldown=0;dialogueNPC=null;cutsceneTuneIndex=0;particles=[];bubbles=[];screenShake=0;toastTimer=0;resetPlayer();state='playing';show(null);$('hudLevel').textContent=(save.mode==='hard'&&level!==61?'🔥 ZOR · ':'🌸 ')+level+'/61';refreshHUD();notify(level===61?'💝 GİZLİ BAHÇE — İYİ Kİ VARSIN!':COLORS[world].name+' · Bölüm '+level+(save.mode==='hard'?' · 🔥 ZOR MOD':'')+(level%10===0?' · ÖZEL BOSS BÖLÜMÜ!':''),2.8);last=performance.now();}
function refreshHUD(){if(!player)return;const powers=[player.shield>0?'🛡 Kalkan':'',player.doubleTimer>0?'⚡ Çift zıpla':'',player.magnetTimer>0?'🧲 Mıknatıs':''].filter(Boolean);$('hudPower').textContent=(powers.length?powers.join(' · '):'✨ Güç yok')+(player.dashTimer>0?' · 💨 Hız':'')+(player.glideTimer>0?' · 🪂 Süzül':'');$('hudMission').textContent='🎯 '+missionStatus();$('hudLives').textContent='❤️'.repeat(player.health)+'🖤'.repeat(3-player.health);$('hudItems').textContent='💗 '+hearts+' · 🌹 '+roses+' · 🎁 '+(stage?.giftsFound||0);const m=Math.floor(seconds/60),s=Math.floor(seconds%60);$('hudTime').textContent=`⏱ ${m}:${String(s).padStart(2,'0')}`;}
function notify(text,time=2.0){$('toast').textContent=text;$('toast').style.display='block';toastTimer=time;}
function sound(freq=500,dur=.08,type='sine',volume=.035){if(muted)return;try{audio=audio||new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();const o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.setValueAtTime(freq,audio.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(80,freq*.7),audio.currentTime+dur);g.gain.setValueAtTime(volume,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+dur);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+dur+.02);}catch(e){}}
function dust(x,y,color='#ffe2e6',amount=8){const rng=Math.random;for(let i=0;i<amount;i++)particles.push({x,y,vx:(rng()-.5)*155,vy:-rng()*190-25,life:0.35+rng()*.5,size:2+rng()*5,color});}
function hurt(){if(player.inv>0)return;if(save.mode==='love'&&player.health<=1){player.inv=2;player.vy=-210;notify('💗 Aşk modu: maceraya devam!',1.5);return;}if(player.shield>0){player.shield--;player.inv=1.15;sound(760,.18,'triangle');dust(player.x+15,player.y+22,'#a3eeff',15);notify('🛡 Kalp kalkanın seni korudu!',1.5);refreshHUD();return;}damageCount++;player.health--;player.inv=1.5;player.vy=-270;player.vx=player.facing*-150;screenShake=8;sound(225,.20,'sawtooth',.05);dust(player.x+15,player.y+28,'#ff609b',14);if(player.health<=0){player.health=3;respawn();notify('💗 Vazgeçmek yok! Kontrol noktasından devam.',2.7);}refreshHUD();}
function respawn(){const remainingLives=player.health,old=player;resetPlayer(checkpointX,remainingLives);player.shield=old.shield;player.doubleTimer=old.doubleTimer;player.magnetTimer=old.magnetTimer;player.dashTimer=old.dashTimer;player.glideTimer=old.glideTimer;player.inv=1.5;camera=clamp(player.x-300,0,Math.max(0,stage.width-W));}
function collect(item){
 item.taken=true;
 if(item.type==='gift'){const id=item.giftId||'letter';save.gifts[id]=(save.gifts[id]||0)+1;stage.giftsFound=(stage.giftsFound||0)+1;save.roseWallet+=2;score+=80;persist();dust(item.x,item.y,'#ffe5a5',19);sound(1030,.19,'triangle');notify('🎁 '+(GIFT_TYPES.find(g=>g.id===id)?.label||'Hediye')+' albüme eklendi!',2);refreshHUD();return;}
 if(item.type==='heart'){hearts++;score+=20;sound(750,.10,'sine');dust(item.x,item.y,'#ff78b8',7);}
 else if(item.type==='rose'){roses++;score+=35;save.roseWallet++;persist();sound(990,.14,'triangle');dust(item.x,item.y,'#f53d83',9);}
 else if(item.type==='shield'){player.shield=Math.min(2,player.shield+1);notify('🛡 Kalp kalkanı kazandın!',1.8);sound(820,.22,'sine');dust(item.x,item.y,'#b5f7ff',12);}
 else if(item.type==='double'){player.doubleTimer=20;player.jumps=0;notify('⚡ 20 saniye çift zıplama!',2);sound(920,.2,'triangle');dust(item.x,item.y,'#ffe8a4',12);}
 else if(item.type==='magnet'){player.magnetTimer=20;notify('🧲 20 saniye kalp mıknatısı!',2);sound(700,.21,'triangle');dust(item.x,item.y,'#ffd0eb',12);}
 else if(item.type==='dash'){player.dashTimer=25;notify('💨 25 saniye HIZ gücü! Shift veya HIZ',2);sound(1030,.2,'triangle');}
 else if(item.type==='glide'){player.glideTimer=25;notify('🪂 25 saniye süzülme! Havada ZIPLA tuşunu tut',2);sound(890,.2,'triangle');}
 refreshHUD();
}
function questionHit(b){
 if(b.hit)return;
 const secret=b.type==='secret';b.hit=true;b.type='empty';
 if(secret){pendingSecret=true;notify('✨ Gizli kapı bulundu!',1.8);dust(b.x+20,b.y,'#b2eaff',12);sound(1100,.18,'triangle');return;}
 hearts++;score+=25;refreshHUD();sound(900,.14,'square',.036);dust(b.x+20,b.y-2,'#ffeaa3',10);
}
function complete(){
 if(state!=='playing')return;
 state='cutscene';cutsceneTime=0;cutsceneCameraTarget=Math.max(0,stage.boy.x-W*.47);$('scenePhotoBtn').style.display='block';
 Object.keys(held).forEach(k=>held[k]=false);jumpQueued=false;
 $('touch').classList.remove('on');$('hud').style.display='none';$('hudMission').style.display='none';
 $('toast').style.display='none';toastTimer=0;
 sound(660,.12,'triangle');
}
function finishComplete(){
 if(state!=='cutscene')return;
 state='won';$('scenePhotoBtn').style.display='none';show('won');
 save.unlocked=Math.max(save.unlocked,Math.min(61,level+1));
 const prev=save.best[level];
 const stars=1+((hearts>=4||roses>=3)?1:0)+(missionAchieved()?1:0);
 if(!prev||seconds<prev.time)save.best[level]={time:seconds,hearts,roses,stars};
 else if(stars>(prev.stars||1))save.best[level].stars=stars;
 persist();
 sound(880,.28,'triangle');setTimeout(()=>sound(1180,.25,'triangle'),200);
 const milestone=level%10===0;
 $('winTitle').textContent=level===61?'İYİ Kİ VARSIN! 💝':level===60?'SONSUZA DEK BERABER! 💍':milestone?'BİRLİKTE BAŞARDINIZ! 🌹':'KAVUŞTUNUZ! 💞';
 $('winSubtitle').textContent=level===61?'Bu oyun senin için yapıldı ❤️' :level===60?'60 bölümün sonunda kalpler yine bir arada!':milestone?'Yeni bir dünyaya el ele gidiyorsunuz!':`Bölüm ${level} tamamlandı. Birlikte bir başka maceraya!`;
 $('winStars').textContent='★'.repeat(stars)+'☆'.repeat(3-stars);$('winMission').textContent='🎯 '+stage.mission.label+(missionAchieved()?' — TAMAMLANDI ✓':' — Başka denemede başarabilirsin');
 $('winStats').innerHTML=`<span>💗 ${hearts} kalp</span><span>🌹 ${roses} gül</span><span>⏱ ${Math.floor(seconds/60)}:${String(Math.floor(seconds%60)).padStart(2,'0')}</span><span>🌹 Birikim: ${save.roseWallet}</span><span>🎁 Bu bölüm: ${stage.giftsFound||0}</span>`;
 $('finalNote').style.display=(level===60||level===61)?'block':'none';
 $('finalNote').textContent=level===61?'Bu oyun senin için yapıldı ❤️ İyi ki varsın. Her yolun sonunda el ele olalım.': 'İyi ki varsın ❤️ 61. bölümde seni düşmansız, sürprizlerle dolu bir bahçe bekliyor!';
 $('nextBtn').textContent=level===61?'🗺 DÜNYA HARİTASI':level===60?'💝 GİZLİ 61. BÖLÜM':'SONRAKİ BÖLÜM ▶';
 if(level%10===0||level===61)showStory(level);
}
function getSolids(left,right){const arr=[];const a=clamp(Math.floor(left/T)-1,0,stage.ncol-1),b=clamp(Math.floor(right/T)+1,0,stage.ncol-1);for(let i=a;i<=b;i++)if(!stage.gap[i])arr.push({x:i*T,y:stage.ground[i],w:T,h:H-stage.ground[i]+100,type:'ground'});for(const block of stage.blocks)if(block.x+block.w>left-2&&block.x<right+2)arr.push(block);return arr;}
function intersect(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
function physics(dt){
 const p=player;const dir=(held.right?1:0)-(held.left?1:0);
 const accelerate=1550,maxSpeed=p.dashTimer>0?245:208;
 p.dashBurst=Math.max(0,(p.dashBurst||0)-dt);const lastWall=p.wall||0;p.wall=0;
 if(dir){p.vx+=dir*accelerate*dt;p.vx=clamp(p.vx,-maxSpeed,maxSpeed);p.facing=dir;}
 else{const f=1250*dt;p.vx=Math.abs(p.vx)<=f?0:p.vx-Math.sign(p.vx)*f;}
 if(p.dashBurst>0)p.vx=p.facing*410;
 p.coyote=p.onGround?.10:Math.max(0,p.coyote-dt);
 if(jumpQueued){
  if(p.onGround||p.coyote>0){p.vy=-505;p.onGround=false;p.coyote=0;p.jumps=1;sound(510,.13,'square',.024);dust(p.x+p.w/2,p.y+p.h,'#fff2d3',5);}
  else if(lastWall!==0){p.vy=-430;p.vx=-lastWall*220;p.facing=-lastWall;p.wall=0;p.jumps=1;sound(710,.12,'triangle');}
  else if(p.doubleTimer>0&&p.jumps<2){p.vy=-460;p.jumps=2;sound(690,.16,'triangle',.028);dust(p.x+15,p.y+38,'#ffe8a9',11);}
  jumpQueued=false;
 }
 // Dynamic platforms
 for(const pl of stage.platforms){if(pl.brokenTimer>0){pl.brokenTimer=Math.max(0,pl.brokenTimer-dt);continue;}if(!pl.moving)continue;const old=pl.x;pl.x=pl.center+Math.sin(clock*1.1+pl.t)*pl.amplitude;pl.lastX=old;if(p.onGround&&Math.abs(p.y+p.h-pl.y)<3&&p.x+p.w>old&&p.x<old+pl.w)p.x+=pl.x-old;}
 const oldx=p.x;p.x+=p.vx*dt;p.x=clamp(p.x,0,stage.width-p.w);
 for(const box of getSolids(Math.min(oldx,p.x),Math.max(oldx+p.w,p.x+p.w)))if(intersect(p,box)){
  if(p.vx>0&&oldx+p.w<=box.x+6){p.x=box.x-p.w;p.vx=0;p.wall=1;}
  else if(p.vx<0&&oldx>=box.x+box.w-6){p.x=box.x+box.w;p.vx=0;p.wall=-1;}
 }
 p.prevBottom=p.y+p.h;const oldy=p.y;p.vy=Math.min(830,p.vy+1220*dt);if(!held.jump&&p.vy<-180)p.vy+=900*dt; if(held.jump&&p.glideTimer>0&&p.vy>110)p.vy=110;
 if(p.wall!==0&&p.vy>120&&!p.onGround)p.vy=120;
 p.y+=p.vy*dt;p.onGround=false;
 for(const box of getSolids(p.x,p.x+p.w)){
  if(!intersect(p,box))continue;
  if(p.vy>=0&&p.prevBottom<=box.y+10){p.y=box.y-p.h;p.vy=0;p.onGround=true;}
  else if(p.vy<0&&oldy>=box.y+box.h-9){p.y=box.y+box.h;p.vy=25;if(box.type==='question'||box.type==='secret')questionHit(box);else if(box.type==='brick'){sound(320,.07,'square',.027);dust(box.x+20,box.y+30,'#da9d73',4);}}
 }
 for(const pl of stage.platforms){
  if(pl.brokenTimer>0)continue;
  if(p.vy>=0&&p.prevBottom<=pl.y+8&&p.y+p.h>=pl.y&&p.x+p.w>pl.x+3&&p.x<pl.x+pl.w-3){
   p.y=pl.y-p.h;p.vy=0;p.onGround=true;
   if(pl.type==='spring'){p.vy=-655;p.onGround=false;sound(740,.15,'triangle');dust(p.x+14,p.y+45,'#f7ef9d',7);}
   else if(pl.type==='crumble'){pl.breakTimer+=dt;if(pl.breakTimer>.24){pl.brokenTimer=2.1;pl.breakTimer=0;p.onGround=false;notify('⚠️ Platform kırılıyor!',1);}}
  }
 }
 if(p.onGround)p.jumps=0;
 p.v16PoseTime=Math.max(0,(p.v16PoseTime||0)-dt);
 if(pendingSecret){enterSecret();return;}
 if(p.y>H+130){hurt();if(player===p)respawn();return;}
 if(p.inv>0)p.inv=Math.max(0,p.inv-dt);
 if(p.doubleTimer>0)p.doubleTimer=Math.max(0,p.doubleTimer-dt);
 if(p.magnetTimer>0)p.magnetTimer=Math.max(0,p.magnetTimer-dt);
 if(p.dashTimer>0)p.dashTimer=Math.max(0,p.dashTimer-dt);
 if(p.glideTimer>0)p.glideTimer=Math.max(0,p.glideTimer-dt);
 portalCooldown=Math.max(0,portalCooldown-dt);dashCooldown=Math.max(0,dashCooldown-dt);
 for(const c of stage.chests||[]){if(!c.opened&&intersect(p,{x:c.x-3,y:c.y-7,w:40,h:41}))openChest(c);}
 p.steps+=Math.abs(p.vx)*dt;
 for(const item of stage.items){
  if(item.taken)continue;
  const dx=item.x-(p.x+p.w/2),dy=item.y-(p.y+p.h/2);
  if(Math.abs(dx)<(p.magnetTimer>0?120:23)&&Math.abs(dy)<(p.magnetTimer>0?100:33))collect(item);
 }
 for(const e of stage.enemies){
  if(!e.alive||Math.abs(e.x-p.x)>740)continue;
  e.x+=e.vx*dt;
  if(Math.abs(e.x-e.startX)>e.range||groundAt(e.x+e.w/2)===Infinity)e.vx=-e.vx;
  const gy=groundAt(e.x+e.w/2);
  if(e.type===2)e.y=e.baseY+Math.sin(clock*2.2+e.startX)*20;
  else if(Number.isFinite(gy))e.y=gy-e.h;
  if(intersect(p,e)){
   const stomp=p.vy>60&&p.prevBottom<=e.y+19;
   if(stomp&&e.type!==3){
    if(e.type===4){
     e.hp--;p.vy=-360;sound(260,.24,'sawtooth',.035);dust(e.x+30,e.y,'#ffdba4',15);
     p.inv=.6;
     if(e.hp<=0){e.alive=false;score+=350;notify('🏆 KALP BEKÇİSİ YENİLDİ!',2.5);dust(e.x+30,e.y,'#ffefac',26);}
     else {notify('💥 Harika! '+e.hp+' vuruş kaldı.',1.4);p.x-=34;}
    }else{e.alive=false;p.vy=-335;score+=50;sound(315,.14,'square',.03);dust(e.x+15,e.y,'#ffddad',13);}
   }else hurt();
  }
 }
 updateBossAttacksV16(dt);
 if(secretZone){if(p.x>stage.width-135){exitSecret();return;}}
 else{
  for(const cp of stage.checkpoints)if(cp.x<p.x+15&&!cp.active){cp.active=true;checkpointX=cp.x+40;sound(775,.16,'triangle',.028);notify('🌷 Kontrol noktası kaydedildi',1.5);}
  if(p.x+p.w>stage.boy.x-20&&Math.abs(p.y-stage.boy.y)<90){
   if(stage.enemies.some(e=>e.alive&&e.type===4)){
    if(goalNoticeCooldown<=0){notify('🏆 Önce kalp bekçisini geç!',1.7);goalNoticeCooldown=2;}
   }else complete();
  }
 }
 goalNoticeCooldown=Math.max(0,goalNoticeCooldown-dt);
 camera=clamp(camera+(clamp(p.x-300,0,stage.width-W)-camera)*Math.min(1,dt*5),0,stage.width-W);
 updateCat(dt);
}
function drawRect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h));}
function pix(x,y,s,col){drawRect(x,y,s,s,col);}
function heart(x,y,s=18,col='#ff467c'){ctx.save();ctx.translate(Math.floor(x),Math.floor(y));const z=s/16;ctx.scale(z,z);drawRect(2,1,4,3,col);drawRect(10,1,4,3,col);drawRect(0,4,16,5,col);drawRect(2,9,12,3,col);drawRect(4,12,8,2,col);drawRect(6,14,4,2,col);drawRect(3,4,3,2,'#ffb3d5');drawRect(2,7,2,1,'#ffb3d5');ctx.restore();}
function rose(x,y,s=22){ctx.save();ctx.translate(Math.floor(x),Math.floor(y));ctx.scale(s/22,s/22);drawRect(10,11,3,11,'#337d43');drawRect(5,14,7,3,'#49b867');drawRect(12,17,5,3,'#49b867');drawRect(6,4,12,9,'#af194a');drawRect(8,1,9,11,'#ee3c6d');drawRect(5,4,8,7,'#fd6193');drawRect(10,3,5,3,'#ffb2c5');drawRect(11,8,6,2,'#d72256');ctx.restore();}
function star(x,y,s=10,color='#fff2bb'){drawRect(x+s*.35,y,s*.3,s,color);drawRect(x,y+s*.35,s,s*.3,color);}
function cloud(x,y,s=1,c='#fffaf4aa'){drawRect(x+13*s,y,55*s,18*s,c);drawRect(x+25*s,y-12*s,32*s,35*s,c);drawRect(x,y+8*s,93*s,14*s,c);drawRect(x+67*s,y+1*s,32*s,21*s,c);}
function decoBush(x,y,w,c1,c2,flower){
 drawRect(x,y,w,18,c1);drawRect(x+6,y-8,w-12,12,c1);drawRect(x+12,y-15,w-24,10,c2);drawRect(x+3,y+6,6,4,'#ffffff14');drawRect(x+w-12,y+5,7,4,'#0000001a');
 if(flower){for(let i=0;i<Math.max(2,Math.floor(w/22));i++){const fx=x+8+i*16, fy=y-2-(i%2)*5;drawRect(fx,fy,4,4,flower);drawRect(fx+1,fy+4,2,4,'#67b84b');}}
}
function decoTree(x,baseY,trunk,leaf1,leaf2,flower){
 drawRect(x+18,baseY-88,14,92,trunk);drawRect(x+16,baseY-92,18,8,'#ffffff18');
 drawRect(x-4,baseY-90,58,22,leaf1);drawRect(x-12,baseY-68,74,24,leaf1);drawRect(x+2,baseY-110,44,24,leaf2);drawRect(x+10,baseY-126,28,18,leaf2);
 drawRect(x+2,baseY-84,8,6,'#ffffff18');drawRect(x+36,baseY-58,9,6,'#00000018');
 if(flower){for(let i=0;i<6;i++){const fx=x-2+(i*10)%54, fy=baseY-86+(i%3)*12;drawRect(fx,fy,4,4,flower);}}
}
function candyTree(x,baseY){
 drawRect(x+22,baseY-86,12,90,'#d9b4ff');drawRect(x+8,baseY-112,42,26,'#ff93ca');drawRect(x-4,baseY-92,66,26,'#ffb35a');drawRect(x+12,baseY-72,44,20,'#87df95');
 drawRect(x+14,baseY-107,8,7,'#fff1c4');drawRect(x+36,baseY-88,8,7,'#fff1c4');
}
function cloudTree(x,baseY){
 drawRect(x+18,baseY-82,12,84,'#dcecff');drawRect(x+8,baseY-104,40,19,'#ffffff');drawRect(x-6,baseY-85,68,22,'#f7fbff');drawRect(x+16,baseY-122,28,16,'#ffffff');
 drawRect(x+3,baseY-78,8,5,'#d5e8ff');drawRect(x+41,baseY-70,10,5,'#d5e8ff');
}
function crystalPlant(x,baseY){
 drawRect(x+20,baseY-75,10,79,'#55417f');ctx.fillStyle='#72eff1';ctx.beginPath();ctx.moveTo(x+25,baseY-124);ctx.lineTo(x+8,baseY-76);ctx.lineTo(x+22,baseY-76);ctx.lineTo(x+31,baseY-98);ctx.closePath();ctx.fill();ctx.fillStyle='#b7fbff';ctx.beginPath();ctx.moveTo(x+44,baseY-102);ctx.lineTo(x+35,baseY-64);ctx.lineTo(x+47,baseY-64);ctx.lineTo(x+55,baseY-88);ctx.closePath();ctx.fill();drawRect(x+2,baseY-40,52,12,'#6b56a0');
}
function moonTree(x,baseY){
 drawRect(x+20,baseY-90,12,92,'#41375c');drawRect(x+1,baseY-108,50,24,'#8b72e8');drawRect(x-10,baseY-86,72,24,'#6d58bf');drawRect(x+11,baseY-127,30,20,'#a491f2');for(let i=0;i<4;i++)star(x+5+i*14,baseY-88+(i%2)*8,5,'#ffe38b');
}
function castleTree(x,baseY){
 drawRect(x+19,baseY-92,14,95,'#b67798');drawRect(x+3,baseY-110,47,20,'#f1b2ce');drawRect(x-6,baseY-88,66,24,'#e778ad');drawRect(x+10,baseY-128,32,18,'#ffd5e6');for(let i=0;i<5;i++)heart(x+1+i*11,baseY-84+(i%2)*7,5,'#fff0f6');
}
const scenicSources=[
"assets/image_04.webp",
"assets/image_05.webp",
"assets/image_06.webp",
"assets/image_07.webp",
"assets/image_08.webp",
"assets/image_09.webp"
];
const scenicImages=scenicSources.map(src=>{const i=new Image();i.decoding="async";i.src=src;return i;});
const foregroundSources=[
"assets/image_10.webp",
"assets/image_11.webp",
"assets/image_12.webp",
"assets/image_13.webp",
"assets/image_14.webp",
"assets/image_15.webp"
];
const foregroundImages=foregroundSources.map(src=>{const i=new Image();i.decoding="async";i.src=src;return i;});
// V15: illustrated scenic panorama. Artwork is entirely embedded in this HTML.
// Two genuinely different scrolling speeds; no circle-tree primitive overlays.
// V16: independent art-derived parallax layers. All sources live inside this HTML.
const v16Layers=new Map();
function v16MakeArtStrip(image){
 if(!image||!image.complete||!image.naturalWidth)return null;
 const w=image.naturalWidth,h=image.naturalHeight;
 const canvas=document.createElement('canvas');canvas.width=w*2;canvas.height=h;
 const b=canvas.getContext('2d',{alpha:true});
 b.imageSmoothingEnabled=true;b.drawImage(image,0,0);
 b.save();b.translate(w*2,0);b.scale(-1,1);b.drawImage(image,0,0);b.restore();
 return {canvas,w,h,period:w*2};
}
function v16GetArt(image){
 if(!image||!image.naturalWidth)return null;
 let cached=v16Layers.get(image);
 if(!cached){cached=v16MakeArtStrip(image);if(cached)v16Layers.set(image,cached);}
 return cached;
}
function v16PaintLayer(image,travel,rate,y,height,opacity=1){
 const tile=v16GetArt(image);if(!tile)return;
 const {canvas,period}=tile;
 let x=((travel*rate)%period+period)%period;
 ctx.save();ctx.imageSmoothingEnabled=true;ctx.globalAlpha=opacity;
 let screenX=0;
 while(screenX<W){
  const chunk=Math.min(W-screenX,period-x);
  if(chunk<=0)break;
  ctx.drawImage(canvas,x,0,chunk,tile.h,screenX,y,chunk,height);
  screenX+=chunk;x=0;
 }
 ctx.restore();
}
function v16PaintBand(image,travel,rate,srcY,srcH,dstY,dstH,opacity=1){
 const tile=v16GetArt(image);if(!tile)return;
 const {canvas,period,h}=tile;
 const sy=Math.max(0,Math.min(h-1,Math.round(srcY)));
 const sh=Math.max(1,Math.min(h-sy,Math.round(srcH)));
 let x=((travel*rate)%period+period)%period;
 ctx.save();ctx.imageSmoothingEnabled=true;ctx.globalAlpha=opacity;
 let screenX=0;
 while(screenX<W){
  const chunk=Math.min(W-screenX,period-x);
  if(chunk<=0)break;
  ctx.drawImage(canvas,x,sy,chunk,sh,screenX,dstY,chunk,dstH);
  screenX+=chunk;x=0;
 }
 ctx.restore();
}
function drawBackdrop(){
 const travel=(state==='cutscene')?camera+W*.18:Math.max(camera,(player?.x||0)-115,0);
 const far=scenicImages[world]||scenicImages[0];
 if(far&&far.complete&&far.naturalWidth){
   // Clean version: only the main backdrop remains.
   // Removed all faint semi-transparent overlays, mist, glow and extra ghost images.
   v16PaintLayer(far,travel,.14,0,H,1);
 }else{
   const th=COLORS[world],g=ctx.createLinearGradient(0,0,0,H);
   g.addColorStop(0,th.sky[0]);g.addColorStop(1,th.sky[1]);
   ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 }
}

function floatingDetails(){
 // Decorative particles are deterministic and parallax-scrolled (not physical pickups).
 for(let i=0;i<(v16Perf.quality===1?11:19);i++){
  const x=((i*73-camera*.22+clock*(i%3===0?7:-3))%(W+75)+W+75)%(W+75);
  const y=90+(i*53)%280+Math.sin(clock*.9+i)*6;
  const col=world===4?'#fff1a2':world===3?'#a9f5ff':world===2?'#ffffff':world===1?'#ffe8a8':'#ffd2ed';
  drawRect(Math.round(x),Math.round(y),i%3===0?4:3,i%3===0?4:3,col);
 }
}
function grassTile(x,y,top,gnd,trim,col){
 drawRect(x,y,T,H-y,gnd);
 drawRect(x,y,T,10,top);drawRect(x,y+10,T,6,trim);
 drawRect(x+2,y+16,T-4,6,'#00000010');drawRect(x+5,y+32,8,7,'#00000016');drawRect(x+26,y+44,8,6,'#ffffff16');
 for(let i=0;i<5;i++){const bx=x+3+i*7, h=4+(i%3);drawRect(bx,y-h,4,h,top);}
 if(col%2===0){drawRect(x+8,y+2,4,3,'#d9ffc4');drawRect(x+22,y+4,4,3,'#d9ffc4');drawRect(x+31,y+1,3,4,'#c1ff95');}
 if(col%3===0){drawRect(x+13,y-2,2,6,'#67b84b');drawRect(x+11,y-5,6,3,'#ffd8ec');}
 if(col%5===0){drawRect(x+28,y-3,2,7,'#67b84b');drawRect(x+26,y-6,6,3,'#ffe9a3');}
 if(col%7===0){drawRect(x+18,y+24,5,9,'#00000014');}
 for(let q=0;q<6;q++){const ox=(q*13+col*7)%36+2,oy=y+16+((q*19+col*3)%102);
   if(oy<H){drawRect(x+ox,oy,3+(q%2),3,q%3===0?'#f8d79b48':q%2?'#00000018':'#ffffff22');}}
 for(let q=0;q<3;q++){const dx=x+(col*5+q*11)%37,hh=3+((col+q)%5);drawRect(dx,y-hh,3,hh,top);}
 if(world===0||world===5){if(col%5===1){drawRect(x+17,y-10,2,10,'#398f59');drawRect(x+12,y-13,12,4,'#ffb5d5');drawRect(x+16,y-17,4,12,'#fff4ec');}}

}
function drawTiles(){const th=COLORS[world];let a=Math.max(0,Math.floor(camera/T)-2),b=Math.min(stage.ncol-1,Math.floor((camera+W)/T)+2);for(let i=a;i<=b;i++){if(stage.gap[i])continue;let x=i*T;grassTile(x,stage.ground[i],th.top,th.ground,th.trim,i);if(i>0&&!stage.gap[i-1]&&stage.ground[i-1]<stage.ground[i])drawRect(x,stage.ground[i-1],7,stage.ground[i]-stage.ground[i-1],th.ground);}
 for(let i=a;i<=b;i++){
  if(stage.gap[i]||i%4!==0)continue;
  const x=i*T,y=stage.ground[i];
  if(world===0||world===5){
   drawRect(x+5,y-11,3,12,'#398b54');rose(x+1,y-17,13);
   drawRect(x+27,y-8,2,9,'#4baf64');star(x+28,y-13,4,'#f4f9c4');
  }else if(world===1){drawRect(x+14,y-10,12,10,'#ff8ac4');drawRect(x+18,y-14,4,5,'#ffe7ef');}
  else if(world===2){cloud(x+6,y-12,.13,'#ffffffaa');}
  else if(world===3){star(x+11,y-9,7,'#a7faff');}
  else {star(x+15,y-11,6,'#ffe6a0');}
 }
 for(const pl of stage.platforms){if(pl.brokenTimer>0||pl.x+pl.w<camera-20||pl.x>camera+W+20)continue;drawRect(pl.x,pl.y,pl.w,15,world===2?'#f0e7fd':'#a58079');drawRect(pl.x,pl.y,pl.w,7,th.top);for(let k=0;k<pl.w;k+=21)drawRect(pl.x+k+3,pl.y+10,8,3,'#25132133');if(pl.moving){drawRect(pl.x+pl.w/2-9,pl.y+5,18,4,'#fff3ad');}if(pl.type==='spring'){drawRect(pl.x+6,pl.y-6,pl.w-12,7,'#ffcc6c');for(let k=8;k<pl.w-8;k+=22)heart(pl.x+k,pl.y-13,9,'#ffaac5');}if(pl.type==='crumble'){for(let k=12;k<pl.w-8;k+=23){drawRect(pl.x+k,pl.y+4,13,2,'#774e51');drawRect(pl.x+k+5,pl.y+7,2,7,'#744454');}}}
 for(const bl of stage.blocks){if(bl.x+T<camera-5||bl.x>camera+W+5)continue;if(bl.type==='brick'||bl.type==='secret'){drawRect(bl.x,bl.y,T,T,bl.type==='secret'?'#72528a':'#6f3d42');drawRect(bl.x+3,bl.y+3,T-6,T-6,'#bd7557');drawRect(bl.x+3,bl.y+15,34,3,'#713841');drawRect(bl.x+18,bl.y+3,3,12,'#713841');drawRect(bl.x+10,bl.y+19,3,17,'#713841');if(bl.type==='secret')star(bl.x+20,bl.y+18,9,'#c7eeff');}else{drawRect(bl.x,bl.y,T,T,'#8b5a73');drawRect(bl.x+3,bl.y+3,34,34,bl.type==='empty'?'#b89aa4':'#ffd16e');drawRect(bl.x+7,bl.y+7,26,5,'#fff2b3');if(bl.type==='question'){heart(bl.x+12,bl.y+11,16,'#f56897');drawRect(bl.x+17,bl.y+32,5,3,'#a45f66');}}}
}

// Approved, photo-derived characters in higher-resolution 16-bit pixel art.
const sprites={};
for(const key of ['girl_idle','girl_run1','girl_run2','girl_jump','boy_idle','boy_run1','boy_run2']) sprites[key]=new Image();
for(const key of ['girl_run0_new','girl_run1_new','girl_run2_new','girl_run3_new']) sprites[key]=new Image();
sprites['girl_idle'].src='assets/image_01.png';
sprites['girl_run1'].src='assets/image_02.png';
sprites['girl_run2'].src='assets/image_03.png';
sprites['girl_jump'].src='assets/image_04.png';
sprites['boy_idle'].src='assets/image_05.png';
sprites['boy_run1'].src='assets/image_06.png';
sprites['boy_run2'].src='assets/image_07.png';
// V5: consistent four-pose run cycle; transparent PNGs with background artifacts removed.
sprites['girl_run0_new'].src='assets/image_08.png';
sprites['girl_run1_new'].src='assets/image_09.png';
sprites['girl_run2_new'].src='assets/image_10.png';
sprites['girl_run3_new'].src='assets/image_11.png';
// Source-image alpha bounds, excluding unused transparent pixels around each pose.
// A fixed *visible* height prevents the character shrinking when idle -> running.
// Resting pose: same right-facing art style as running, both feet on the ground.
sprites['girl_idle_stand']=new Image();
sprites['girl_idle_stand'].src='assets/image_12.png';
const spriteBounds={
 girl_idle:[8,6,65,118],girl_idle_stand:[0,0,92,224],girl_jump:[9,0,70,114],
 girl_run0_new:[22,11,71,128],girl_run1_new:[20,11,75,128],
 girl_run2_new:[10,11,94,128],girl_run3_new:[20,11,76,128],
 girl_run1:[0,5,85,119],girl_run2:[0,4,76,118],
 boy_idle:[3,7,63,112],boy_run1:[0,2,76,108],boy_run2:[0,0,67,111]
};
function drawNPC(x,y,male=false,action='idle',dir=1,scale=1,t=0,distance=null){
 // Dururken gerçek ayakta bekleme pozu, koşarken ve zıplarken koşu kareleri.
 // Boyut yine sabit görünür yüksekliğe ve ayak hizasına göre çizilir.
 let key=male?'boy_idle':'girl_idle_stand';
 const moving=action==='run'||action==='walk';
 const airborne=action==='jump'||action==='fall';
 // Kullanıcı isteği: koşu karakteri ve zıplama karakteri aynı çizim ailesinden olsun.
 // Bu yüzden jump/fall sırasında ayrı jump sprite yerine aynı run sprite seti kullanılır.
 if(moving||airborne){
   const stride=distance===null?t*164:distance;
   const index=((Math.floor(stride/27)%4)+4)%4;
   if(male){
     key=(index%2?'boy_run2':'boy_run1');
   }else{
     key='girl_run'+index+'_new';
   }
 }
 const im=sprites[key];
 if(!im||!im.complete||!im.naturalWidth){drawNPCFallback(x,y,male,action,dir,scale,t);return;}
 const box=spriteBounds[key]||[0,0,im.naturalWidth,im.naturalHeight];
 // Match all poses by visible body HEIGHT, keeping their natural width / silhouette.
 const visibleHeight=(male?66:70)*scale;
 const visibleWidth=visibleHeight*box[2]/box[3];
 const center=x+16*scale;
 const bottom=y+49*scale;
 ctx.save();
 if(dir<0){ctx.translate(center*2,0);ctx.scale(-1,1);}
 ctx.imageSmoothingEnabled=false;
 ctx.drawImage(im,box[0],box[1],box[2],box[3],
  Math.round(center-visibleWidth/2),Math.round(bottom-visibleHeight),
  Math.round(visibleWidth),Math.round(visibleHeight));
 if(!male)drawOutfitAccent(center,bottom,scale,t);
 ctx.restore();
}
function drawNPCFallback(x,y,male=false,action='idle',dir=1,scale=1,t=0){
 // Piksel-ızgaralı, onaylanan karakterlere uygun çizim: kızda siyah türban/gözlük/pembe kazak,
 // erkekte kısa koyu saç/sakal/koyu yeşil üst.
 ctx.save();ctx.translate(Math.round(x),Math.round(y));if(dir<0){ctx.translate(32*scale,0);ctx.scale(-1,1);}ctx.scale(scale,scale);
 let swing=action==='run'?Math.sin(t*13)*5:action==='walk'?Math.sin(t*8)*3:0;
 let bob=action==='run'?Math.abs(Math.sin(t*13))*2:Math.sin(t*2)*.8;
 const c=male?{skin:'#e8b08d',edge:'#714c45',hair:'#28212d',cloth:'#285244',shade:'#16372e'}:{skin:'#f2c7ac',edge:'#a67168',hair:'#191821',cloth:'#fa9ab9',shade:'#d66e98'};
 drawRect(5,35,9,13,'#252536');drawRect(17,35,9,13,'#252536');drawRect(3+swing,44,13,5,'#edf1fa');drawRect(18-swing,44,13,5,'#edf1fa');
 drawRect(4,25+bob,25,15,c.shade);drawRect(7,25+bob,20,12,c.cloth);drawRect(2,28+bob,5,12,c.cloth);drawRect(28,28+bob,5,12,c.cloth);drawRect(2,38+bob,6,3,c.skin);drawRect(27,38+bob,6,3,c.skin);
 if(male){drawRect(5,8+bob,24,22,c.skin);drawRect(6,7+bob,22,7,c.hair);drawRect(4,10+bob,7,9,c.hair);drawRect(23,7+bob,6,10,c.hair);drawRect(7,2+bob,20,7,c.hair);drawRect(12,21+bob,14,4,'#765b50');drawRect(15,19+bob,7,4,'#b78070');drawRect(12,15+bob,3,3,'#29252c');drawRect(23,15+bob,3,3,'#29252c');drawRect(16,25+bob,8,2,'#724849');}
 else {drawRect(3,3+bob,27,30,c.hair);drawRect(5,5+bob,23,6,'#35313a');drawRect(8,10+bob,18,19,c.skin);drawRect(4,12+bob,5,17,c.hair);drawRect(25,12+bob,6,17,c.hair);drawRect(2,26+bob,29,9,c.hair);drawRect(8,33+bob,21,4,c.hair);drawRect(8,15+bob,23,3,'#222029');drawRect(8,15+bob,3,10,'#222029');drawRect(28,15+bob,3,10,'#222029');drawRect(10,23+bob,19,3,'#222029');drawRect(13,18+bob,3,4,'#342a34');drawRect(24,18+bob,3,4,'#342a34');drawRect(17,26+bob,6,2,'#ae6a72');}
 if(action==='win'){star(27,-9,6,'#ffe6a5');}ctx.restore();
}
// V16: six different telegraphed attacks (rose, bouncing pollen, falling stars,
// crystal, moon bolt, final heart volley). Does not spawn attacks in stage 61.
const V16_BOSS_NAMES=['Gül Fırtınası','Zıplayan Polen','Yıldız Yağmuru','Kristal Okları','Ay Işığı','Kalp Dalgası'];
const V16_BOSS_COLORS=['#ff7ca6','#ffd77b','#a8eeff','#82ecff','#aaa9ff','#ffd6ec'];
function v16SpawnBossShot(e){
 const p=player,kind=e.bossKind,hard=save.mode==='hard';
 const mul=hard?1.12:1;
 const push=(x,y,vx,vy,r=10,gravity=0,phase=0)=>stage.bossShots.push({x,y,vx:vx*mul,vy,gravity,r,kind,phase,age:0});
 const x=e.x-10,y=e.y;
 if(kind===0){push(x,y+32,-145,-5,11);}
 else if(kind===1){push(x,y+20,-135,-190,11,400);push(x+14,y+30,-110,-130,9,340);}
 else if(kind===2){push(p.x+34,92,0,185,12,85);}
 else if(kind===3){push(x,y+9,-165,0,10);push(x-8,y+44,-165,0,9);}
 else if(kind===4){push(x,y+26,-150,-25,11,0,1);}
 else if(kind===5){push(x,y+15,-170,-60,9);push(x-9,y+33,-180,-5,11);push(x,y+45,-145,40,8);}
 e.bossAttacks++;stage.bossShotsFired+=kind===1||kind===3?2:kind===5?3:1;
 sound(240+kind*60,.10,'triangle',.018);
}
function updateBossAttacksV16(dt){
 if(!stage||secretZone||level===61)return;
 const bosses=stage.enemies.filter(e=>e.alive&&e.type===4);
 for(const e of bosses){
   if(Math.abs(player.x-e.x)>650){e.bossCooldown=Math.max(1.0,e.bossCooldown||2);e.bossWarning=0;continue;}
   e.bossCooldown=(e.bossCooldown||2)-dt;
   e.bossWarning=e.bossCooldown<.75&&e.bossCooldown>0?e.bossCooldown:0;
   if(e.bossCooldown<=0){v16SpawnBossShot(e);e.bossCooldown=(save.mode==='hard'?2.35:3.1)+(e.bossKind%3)*.22;}
 }
 const shots=stage.bossShots||[];
 for(const shot of shots){
   shot.age+=dt;
   shot.x+=shot.vx*dt;shot.y+=shot.vy*dt;
   shot.vy+=shot.gravity*dt;
   if(shot.phase===1)shot.y+=Math.sin(shot.age*11)*1.35;
   const b={x:shot.x-shot.r,y:shot.y-shot.r,w:shot.r*2,h:shot.r*2};
   if(intersect(player,b)){
      const wasInv=player.inv>0;
      hurt();
      if(!wasInv)stage.bossHits++;
      shot.age=100;
   }
 }
 stage.bossShots=shots.filter(a=>a.age<5&&a.x>camera-200&&a.x<camera+W+300&&a.y<H+65&&a.y>-80);
}
function drawBossV16(e){
 const k=e.bossKind||0;
 const c=V16_BOSS_COLORS[k];
 const b=Math.sin(clock*3+k)*2;
 drawRect(e.x+7,e.y+27+b,49,33,'#55344f');
 drawRect(e.x+4,e.y+14+b,55,32,k===3?'#416e91':k===4?'#5a528a':'#b45c87');
 drawRect(e.x+14,e.y+2+b,35,20,c);
 drawRect(e.x+20,e.y+22+b,6,8,'#fdf9f8');drawRect(e.x+39,e.y+22+b,6,8,'#fdf9f8');
 drawRect(e.x+22,e.y+26+b,3,5,'#41243f');drawRect(e.x+41,e.y+26+b,3,5,'#41243f');
 if(k===0){rose(e.x+25,e.y-6+b,17);}
 if(k===1){for(let i=0;i<3;i++)star(e.x+10+i*20,e.y+5+b,5,'#ffed9f');}
 if(k===2){star(e.x+32,e.y+10+b,15,'#ffffff');}
 if(k===3){star(e.x+31,e.y+4+b,17,'#a2fbff');}
 if(k===4){ctx.fillStyle='#fff6ba';ctx.beginPath();ctx.arc(e.x+33,e.y+10+b,12,0,Math.PI*2);ctx.fill();ctx.fillStyle='#5a528a';ctx.beginPath();ctx.arc(e.x+39,e.y+7+b,11,0,Math.PI*2);ctx.fill();}
 if(k===5){heart(e.x+19,e.y+3+b,24,'#ffe7f4');}
 for(let i=0;i<Math.min(e.hp,5);i++)heart(e.x+5+i*13,e.y-26,11,'#ff9dbf');
 if(e.bossWarning>0){
   const pulse=.55+.45*Math.sin(clock*24);
   ctx.save();ctx.globalAlpha=pulse;ctx.strokeStyle='#ffefac';ctx.lineWidth=3;
   ctx.strokeRect(e.x-7,e.y-12,74,78);ctx.restore();
   ctx.save();ctx.textAlign='center';ctx.fillStyle='#fff9dd';ctx.font='bold 13px sans-serif';
   ctx.fillText('⚠ '+V16_BOSS_NAMES[k],e.x+30,e.y-41);ctx.restore();
 }
}
function drawBossShotV16(q){
 ctx.save();ctx.globalAlpha=.95;
 const color=V16_BOSS_COLORS[q.kind];
 ctx.fillStyle=color;ctx.beginPath();ctx.arc(q.x,q.y,q.r,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle='#ffffffd1';ctx.lineWidth=2;ctx.stroke();
 ctx.restore();
 if(q.kind===0||q.kind===5)heart(q.x-7,q.y-5,15,'#fff3f8');
 else if(q.kind===2||q.kind===3)star(q.x-6,q.y-5,12,'#f0ffff');
 else if(q.kind===4)star(q.x-6,q.y-5,11,'#fcf2d2');
}

function drawEnemy(e){
 const bob=Math.sin(clock*5+e.x*.002)*1.6;
 if(e.type===4){drawBossV16(e);return;}
 if(e.type===2){ // bee
  drawRect(e.x+3,e.y+10+bob,25,13,'#f7c456');drawRect(e.x+9,e.y+9+bob,5,15,'#6b4d50');drawRect(e.x+20,e.y+9+bob,4,15,'#6b4d50');
  drawRect(e.x+2,e.y+3+bob,12,9,'#e8faffb9');drawRect(e.x+15,e.y+1+bob,11,9,'#e8faffb9');drawRect(e.x+24,e.y+14+bob,3,4,'#31203a');return;
 }
 if(e.type===3){ // hedgehog/spikes
  drawRect(e.x+3,e.y+13+bob,26,11,'#89599f');for(let i=0;i<5;i++){drawRect(e.x+i*6+2,e.y+6+bob,4,8,'#c9a1ef');}
  drawRect(e.x+23,e.y+15+bob,3,3,'#fff3e7');return;
 }
 if(e.type===1){ // snail
  drawRect(e.x+1,e.y+16+bob,28,11,'#9981c5');drawRect(e.x+5,e.y+3+bob,19,20,'#d3b0ed');drawRect(e.x+10,e.y+9+bob,9,8,'#ab77c3');
  drawRect(e.x+25,e.y+9+bob,3,9,'#d7bca5');drawRect(e.x+23,e.y+5+bob,5,4,'#fff7ed');return;
 }
 // mushroom
 drawRect(e.x+3,e.y+7+bob,24,18,'#a64b5c');drawRect(e.x+7,e.y+3+bob,16,9,'#e38178');drawRect(e.x+1,e.y+15+bob,29,12,'#d66c77');
 drawRect(e.x+7,e.y+15+bob,4,6,'#fff4e7');drawRect(e.x+18,e.y+15+bob,4,6,'#fff4e7');drawRect(e.x+8,e.y+18+bob,2,4,'#29183a');drawRect(e.x+19,e.y+18+bob,2,4,'#29183a');
}
function drawPowerup(x,y,type){
 const color=type==='shield'?'#84edff':type==='double'?'#ffe381':type==='dash'?'#92ffc9':type==='glide'?'#c7f3ff':'#ecc2ff';
 ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,15+Math.sin(clock*4)*2,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#58356a';ctx.font='bold 18px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(type==='shield'?'✦':type==='double'?'↑':type==='dash'?'➤':type==='glide'?'◒':'◎',x,y+1);
}
function drawFlag(cp){drawRect(cp.x,cp.y,5,94,'#f9dfae');drawRect(cp.x+4,cp.y+4,28,23,cp.active?'#8ce3b1':'#ff8ac0');heart(cp.x+11,cp.y+9,13,'#ffffff');}
function drawSecretExit(){const x=stage.width-110,y=groundAt(x)-86;drawRect(x,y,58,86,'#b978cf');drawRect(x+7,y+8,44,78,'#e7bffb');drawRect(x+15,y+18,28,68,'#68337f');heart(x+16,y+27,25,'#ffd9f0');}
function drawGoalArch(){
 const b=stage.boy,x=b.x,y=groundAt(b.x)-51;
 const hover=Math.sin(clock*3)*3;
 drawRect(x-45,y-36,6,88,'#ecd4bb');drawRect(x+74,y-36,6,88,'#ecd4bb');
 drawRect(x-47,y-40,130,10,'#9d6b91');
 for(let i=0;i<7;i++)rose(x-45+i*18,y-54+Math.sin(i*.6)*9,19);
 heart(x+14,y-82+hover,33);
}
function drawGoal(){const b=stage.boy;drawGoalArch();drawNPC(b.x,groundAt(b.x)-51,true,'idle',-1,1.1,clock);}
// V10: Four synchronized walking poses with genuinely linked hands, black hair and fairer/darker complexion.
const coupleFrames = [
  'assets/image_16.webp',
  'assets/image_17.webp',
  'assets/image_18.webp',
  'assets/image_19.webp'
].map(src=>{const im=new Image();im.src=src;return im;});
function drawCoupleFrame(worldX,groundY,pose){
 const pic=coupleFrames[pose%4];
 const h=81, w=90;
 if(pic&&pic.complete&&pic.naturalWidth){
   ctx.save();ctx.imageSmoothingEnabled=false;
   ctx.drawImage(pic,Math.round(worldX),Math.round(groundY-h),w,h);
   ctx.restore();
 }else{
   drawNPC(worldX,groundY-49,false,'idle',1,1.04,clock);
   drawNPC(worldX+39,groundY-49,true,'idle',1,1.1,clock);
 }
}
function drawLoveWalk(){
 const bx=stage.boy.x, groundY=groundAt(bx), y=groundY-49, t=cutsceneTime;
 // Enter together gradually, meet, then walk in sync holding hands.
 const approach=Math.min(1,t/1.05);
 const walk=Math.max(0,t-2.0);
 const groupX=bx-54 + Math.min(walk,3.7)*26;
 if(t<1.7){
   // Approach and look at one another without stretching their arms as a fake connector.
   const gx=bx-80+approach*28;
   drawNPC(gx,y,false,t<1.05?'walk':'idle',1,1.04,clock,t*145);
   drawNPC(bx+8,y,true,'idle',-1,1.1,clock);
   if(t>1.05){heart(bx+3,y-83+Math.sin(t*7)*3,22,'#ff80b7');}
 }else{
   // Couple poses contain two complete connected arms and hands — never a flat line.
   const idx=t<2.0?0:Math.floor((t-2.0)/0.20)%4;
   const theme=level===61?1:level%4;
   if(theme===0&&t>=2.55&&t<=4.8){
      // Bench scene: seated at the same scale with feet/legs partly hidden by the front rail.
      const sx=bx-58;
      drawRect(sx-13,groundY-21,122,8,'#c89188');drawRect(sx-10,groundY-13,5,24,'#714564');drawRect(sx+98,groundY-13,5,24,'#714564');
      drawCoupleFrame(sx,groundY-7,0);
      drawRect(sx-13,groundY-20,122,10,'#f2bdae');
      drawRect(sx-6,groundY-10,6,13,'#714564');drawRect(sx+95,groundY-10,6,13,'#714564');
      for(let k=0;k<3;k++)heart(sx+k*43,groundY-110+Math.sin(t*4+k)*7,9,'#ffd7e7');
   }else if(theme===2&&t>=2.6&&t<=4.6){
      // Stay side by side and lean towards each other, as in a gentle hug.
      drawCoupleFrame(bx-55,groundY,0);
      heart(bx-23,groundY-93+Math.sin(t*5)*4,22,'#ffd2e6');
      star(bx+12,groundY-83,7,'#fff1b9');
   }else{
      drawCoupleFrame(groupX,groundY,idx);
   }
   if(theme===1&&t>2.9&&t<4.7){rose(groupX+40,groundY-62+Math.sin(t*4)*2,18);}
   if(theme===3&&t>3.0){star(groupX+48,groundY-92,10,'#ffedd2');}
 }
 const drift=Math.max(0,t-1.6)*13;
 for(let i=0;i<9;i++){
   const phase=t*1.15+i*.81, px=bx-35+i*18+drift+Math.sin(phase)*5, py=y-75-((phase*23)%105);
   heart(px,py,8+(i%3)*2,i%3===0?'#ffd9ed':'#ff78ad');
 }
 if(level%3===1&&t>3.1)rose(bx+25+drift,y-83+Math.sin(t*6)*3,19);
 if(level%3===2&&t>3.1)heart(bx+20+drift,y-92+Math.sin(t*7)*5,26,'#ffdded');
 if(level%10===0){
   for(let i=0;i<22;i++){
    const x=bx-95+i*13+drift*.6,py=y-140+((t*45+i*19)%165);
    drawRect(x,py,4+(i%2)*2,5,i%2?'#ffd786':'#ff95c4');
   }
   ctx.save();ctx.font='bold 20px system-ui';ctx.textAlign='center';ctx.fillStyle='#fff5cb';ctx.shadowColor='#4c225b';ctx.shadowBlur=7;
   ctx.fillText(level>=60?'İYİ Kİ VARSIN ❤️':'BİRLİKTE DAHA GÜÇLÜYÜZ!',bx+40,y-148);ctx.restore();
 }
 if(level===60&&t>2.4){for(let i=0;i<7;i++)star(bx-95+i*28+drift*.6,y-120+(i%3)*17,8,'#fff4c0');}
}
// V16: pose changes cross-fade using existing photo-derived sprites, never resize hitboxes.
function drawPlayerV16(){
 const action=player.onGround?(Math.abs(player.vx)>20?'run':'idle'):'jump';
 if(player.v16Pose!==action){player.v16OldPose=player.v16Pose||action;player.v16Pose=action;player.v16PoseTime=.11;}
 const a=clamp(1-(player.v16PoseTime||0)/.11,0,1);
 if(player.v16PoseTime>0&&player.v16OldPose!==action){
   ctx.save();ctx.globalAlpha=1-a;
   drawNPC(player.x-2,player.y,false,player.v16OldPose,player.facing,1.04,clock,player.steps);
   ctx.restore();
   ctx.save();ctx.globalAlpha=a;
   drawNPC(player.x-2,player.y,false,action,player.facing,1.04,clock,player.steps);
   ctx.restore();
 }else drawNPC(player.x-2,player.y,false,action,player.facing,1.04,clock,player.steps);
}

// V16: framing and timed subtitles, separate from the existing synchronized 4-frame handholding.
function drawCinematicOverlayV16(){
 if(state!=='cutscene')return;
 const t=cutsceneTime;
 ctx.save();ctx.resetTransform();
 const band=26;
 ctx.fillStyle='rgba(16,9,27,.88)';ctx.fillRect(0,0,W,band);ctx.fillRect(0,H-band,W,band);
 const line=level===61?'Seninle her yol bir masal. İyi ki varsın ❤️':
   t<1.5?'Bunca yol, bir güzel buluşma için…':
   t<2.7?'Yan yana geldiniz.':'El ele, yeni maceralara…';
 ctx.font='bold 16px system-ui';ctx.textAlign='center';ctx.fillStyle='#fff1cb';
 ctx.shadowColor='#27102b';ctx.shadowBlur=7;ctx.fillText(line,W/2,H-8);ctx.restore();
}

function render(){frame++;
 drawBackdrop();drawEnvironmentalDepth();floatingDetails();ctx.save();if(screenShake>0){ctx.translate((Math.random()-.5)*screenShake,(Math.random()-.5)*screenShake);}
 if(state==='cutscene'){const z=1+Math.min(1,cutsceneTime/1.2)*.055;ctx.translate(W/2,H/2);ctx.scale(z,z);ctx.translate(-W/2,-H/2);}
 ctx.translate(-Math.floor(camera),0);drawTiles();
 if(state==='cutscene'&&camera+W>stage.width-6){
   const gy=groundAt(stage.width-12),th=COLORS[world],x=stage.width;
   const sw=camera+W-x+25;
   if(Number.isFinite(gy)&&sw>0){
     drawRect(x,gy,sw,H-gy,th.ground);drawRect(x,gy,sw,10,th.top);drawRect(x,gy+10,sw,6,th.trim);
     for(let j=0;j<Math.ceil(sw/35);j++){const fx=x+j*35+6;drawRect(fx,gy-5,4,6,th.top);if(j%2===0)rose(fx+9,gy-15,11);}
   }
 }

 const low=camera-55,high=camera+W+55;
 for(const cp of stage.checkpoints)if(cp.x>low&&cp.x<high)drawFlag(cp);
 for(const it of stage.items)if(!it.taken&&it.x>low&&it.x<high){const y=it.y+Math.sin(clock*3+it.bob)*4;if(it.type==='rose')rose(it.x-11,y-12,23);else if(it.type==='heart')heart(it.x-12,y-10,24);else if(it.type==='gift')drawGift(it.x,y,clock);else drawPowerup(it.x,y,it.type);}
 for(const e of stage.enemies)if(e.alive&&e.x>low&&e.x<high)drawEnemy(e);
 for(const shot of stage.bossShots||[])if(shot.x>low-40&&shot.x<high+40)drawBossShotV16(shot);
 for(const c of stage.chests||[])if(c.x>low-70&&c.x<high+70)drawChest(c);
 for(const n of stage.npcs||[])if(n.x>low-60&&n.x<high+60)drawNPCFriend(n);
 for(const port of stage.portals||[])if(port.x>low-70&&port.x<high+70)drawPortal(port);
 if(secretZone)drawSecretExit();else if(state==='cutscene')drawLoveWalk();else drawGoal();
 // Hasar sonrası karakter ASLA gizlenmez. Korunma süresi hafif pembe çerçeveyle belirtilir.
  if(state!=='cutscene'&&player.inv>0){
    const pulse=0.48+0.18*Math.sin(clock*12);
    ctx.save();ctx.strokeStyle=`rgba(255,113,185,${pulse})`;ctx.lineWidth=3;
    ctx.strokeRect(Math.round(player.x-7),Math.round(player.y-7),Math.round(player.w+13),Math.round(player.h+14));
    ctx.restore();
  }
  if(state!=='cutscene'){
    drawPlayerV16();
  }
 if(state!=='cutscene')drawCat();
 for(const p of particles)drawRect(p.x,p.y,p.size,p.size,p.color);
 ctx.restore();drawWeather();drawDialogueHUD();drawCinematicOverlayV16();
 // Köşelerde küçük bilgi ve ilerleme çizgisi
 drawRect(75,H-13,W-150,5,'#220e3688');drawRect(75,H-13,(W-150)*clamp(player.x/stage.width,0,1),5,'#ffd6a7');heart(60,H-20,17);heart(W-70,H-20,17,'#ffd7ee');
}
function update(dt){if(state==='cutscene'){clock+=dt;cutsceneTime+=dt;camera+=(cutsceneCameraTarget-camera)*Math.min(1,dt*4.2);if(cutsceneTime>1.5&&Math.floor(cutsceneTime*3)%4===0&&cutsceneTuneIndex<6){sound([659,784,880,784,988,1175][cutsceneTuneIndex++],.11,'triangle',.013);}if(cutsceneTime>=(level===61?7.1:5.7))finishComplete();return;}if(state==='playing'){seconds+=dt;clock+=dt;/* original multi-track soundtrack is driven by the main loop */const inAir=player&&!player.onGround;const downwardSpeed=player?player.vy:0;physics(dt);if(inAir&&player&&player.onGround&&downwardSpeed>180){dust(player.x+14,player.y+player.h,'#e9eac7',5);}for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=380*dt;p.life-=dt;}particles=particles.filter(p=>p.life>0);screenShake=Math.max(0,screenShake-dt*25);if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$('toast').style.display='none';}if(frame%10===0)refreshHUD();}}
// V16: automatic visual quality throttle (no effect on physics, level or save data).
const v16Perf={quality:2,total:0,frames:0,lowStreak:0};
function v16FrameQuality(dt){
 if(dt<=0||dt>.10)return;
 v16Perf.total+=dt;v16Perf.frames++;
 if(v16Perf.frames<60)return;
 const avg=v16Perf.total/v16Perf.frames;
 if(avg>.025){v16Perf.lowStreak++;if(v16Perf.lowStreak>=2)v16Perf.quality=1;}
 else if(avg<.019){v16Perf.quality=2;v16Perf.lowStreak=0;}
 v16Perf.total=0;v16Perf.frames=0;
}
document.addEventListener('visibilitychange',()=>{
 if(document.hidden&&state==='playing')pause();
 if(document.hidden&&audio?.state==='running')audio.suspend().catch(()=>{});syncV166Music();
});

let last=performance.now();function loop(now){const rawDt=(now-last)/1000||0;let dt=Math.min(.035,rawDt);last=now;v16FrameQuality(rawDt);update(dt);playRomanticScore(dt);if(stage)render();else drawMenuBackground(now/1000);requestAnimationFrame(loop);}
function drawMenuBackground(t){
 const bg=scenicImages[0];
 if(bg&&bg.complete&&bg.naturalWidth){
   ctx.save();ctx.imageSmoothingEnabled=true;
   ctx.drawImage(bg,190+60*Math.sin(t*.09),0,W,H,0,0,W,H);
   ctx.restore();
 }else{
   const grd=ctx.createLinearGradient(0,0,0,H);grd.addColorStop(0,'#8f56c8');grd.addColorStop(1,'#ffd9b6');ctx.fillStyle=grd;ctx.fillRect(0,0,W,H);
 }
 ctx.fillStyle='#24112b13';ctx.fillRect(0,0,W,H);
 for(let i=0;i<14;i++){
   const x=((i*87+t*6)%(W+90)+W+90)%(W+90),y=50+(i*67)%320+Math.sin(t+i)*4;
   ctx.fillStyle=i%2===0?'#ffe1eea8':'#fff8d696';ctx.fillRect(Math.round(x),Math.round(y),3,4);
 }
}

function pause(){if(state!=='playing')return;state='paused';show('paused');$('pauseInfo').textContent=`${COLORS[world].name} · Bölüm ${level} · ${Math.floor(seconds/60)} dk ${Math.floor(seconds%60)} sn · ${hearts} kalp · ${roses} gül`;}
function resume(){if(state!=='paused')return;state='playing';show(null);last=performance.now();}
function openMap(page){
 levelPage=clamp(page,0,5);const tabs=$('worldTabs'),grid=$('levelGrid');tabs.innerHTML='';grid.innerHTML='';
 COLORS.forEach((c,i)=>{let b=document.createElement('button');b.className='worldTab'+(i===levelPage?' selected':'');
  const done=Object.keys(save.best).filter(k=>Math.ceil(Number(k)/10)===i+1).length;
  b.textContent=`${i+1}. ${c.name} ${done}/10`;b.onclick=()=>openMap(i);tabs.appendChild(b);});
 $('progressPct').textContent=`💗 ${Object.keys(save.best).filter(k=>Number(k)>=1&&Number(k)<=60).length}/60 bölüm · %${Math.round(Object.keys(save.best).filter(k=>Number(k)>=1&&Number(k)<=60).length/60*100)} tamamlandı · ${save.roseWallet} 🌹`;$('gardenBtn').style.display=save.unlocked>=61?'block':'none';
 $('worldDescription').textContent=`${save.mode==='relax'?'🌷 Rahat':save.mode==='love'?'💞 Aşk':'🎮 Normal'} · ${META[levelPage]} · Bölümler ${levelPage*10+1}-${levelPage*10+10} · Her bölüm ≈ 1 dk`;
 let route='';for(let j=0;j<10;j++){
   const n=levelPage*10+j+1,done=Boolean(save.best[n]),current=n===save.unlocked;
   route+=(j?`<span class="routeLine ${done?'complete':''}"></span>`:'')+`<span class="routeDot ${done?'complete':current?'current':''}">${done?'✓':j===9?'🏰':'♥'}</span>`;
 }
 $('routeRibbon').innerHTML=route;
 for(let i=levelPage*10+1;i<=levelPage*10+10;i++){
  const unlocked=i<=save.unlocked,done=Boolean(save.best[i]);const btn=document.createElement('button');
  btn.className='levelCell'+(unlocked?'':' locked')+(done?' done':'');btn.disabled=!unlocked;
  const stars=save.best[i]?.stars||1;
  btn.innerHTML=unlocked?`${i}<span>${done?'★'.repeat(stars)+'☆'.repeat(3-stars):i%10===0?'🏆 BOSS':'▶ Oyna'}</span>`:`🔒<span>${i}</span>`;
  btn.onclick=()=>launch(i);grid.appendChild(btn);
 }
 $('gardenBtn').textContent=save.best[61]?'💝 61. BÖLÜM ✓ TEKRAR OYNA':'💝 61. BÖLÜM — GİZLİ BAHÇE';state='levels';show('levels');
}
function updateMenuUI(){
 const completed=Object.keys(save.best||{}).map(Number).filter(n=>!isNaN(n)&&n>=1&&n<=61).length;
 const progress=Math.max(0,Math.min(100,Math.round(completed/61*100)));
 const giftCount=save.gifts?Object.keys(save.gifts).filter(k=>save.gifts[k]).length:0;
 const memoryCount=(save.photos?.length||0)+Math.min(7,Math.floor(completed/10));
 if($('menuUnlocked'))$('menuUnlocked').textContent=String(save.unlocked);
 if($('menuRoses'))$('menuRoses').textContent=String(save.roseWallet||0);
 if($('menuMemories'))$('menuMemories').textContent=String(memoryCount);
 if($('menuGifts'))$('menuGifts').textContent=String(giftCount);
 if($('menuSoftProgress'))$('menuSoftProgress').textContent='İlerleme: %'+progress;
 syncGameMode();
}
function goHome(){state='menu';$('scenePhotoBtn').style.display='none';show('menu');$('playBtn').textContent=save.unlocked>1?'▶ KALDIĞIN YERDEN':'▶ MACERAYA BAŞLA';updateMenuUI();}
$('playBtn').onclick=()=>{apkTryLandscape();launch(save.unlocked);};$('selectBtn').onclick=()=>openMap(Math.floor((save.unlocked-1)/10));$('levelsBack').onclick=goHome;$('soundBtn').onclick=()=>{muted=!muted;save.sound=!muted;persist();$('soundBtn').textContent=muted?'🔇 SES + MÜZİK KAPALI':'🔊 SES + MÜZİK AÇIK';if(!muted){startLoveAudio();sound(660,.08);}else{syncV166Music();}};$('pauseBtn').onclick=pause;$('resumeBtn').onclick=resume;$('restartBtn').onclick=()=>launch(level);$('homeBtn').onclick=goHome;$('mapBtn').onclick=()=>openMap(Math.floor((level-1)/10));$('nextBtn').onclick=()=>level===61?openMap(5):launch(level+1);
$('soundBtn').textContent=muted?'🔇 SES + MÜZİK KAPALI':'🔊 SES + MÜZİK AÇIK';
$('gardenBtn').onclick=()=>{if(save.unlocked>=61)launch(61);};$('albumBtn').onclick=()=>openAlbum('menu');$('albumBack').onclick=()=>{if(albumBackTarget==='story'){state='story';show('story');}else if(albumBackTarget==='won'){state='won';show('won');}else{state='menu';show('menu');}};$('storyAlbum').onclick=()=>openAlbum('story');$('storyContinue').onclick=()=>{if(albumBackTarget==='album'){openAlbum('menu');}else{state='won';show('won');}};
$('menuInfoBtn').onclick=()=>{state='help';show('help');sound(720,.09);};$('helpBack').onclick=()=>goHome();window.addEventListener('keydown',e=>{if(e.code==='Escape'&&state==='help'){e.preventDefault();goHome();}});
 $('shopBtn').onclick=()=>openShop('menu');$('pauseShopBtn').onclick=()=>openShop('paused');$('shopBackBtn').onclick=()=>{state=shopPrevious;show(shopPrevious);};
const keys={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'jump',KeyW:'jump',Space:'jump'};
window.addEventListener('keydown',e=>{if(e.code==='KeyE'||e.code==='ArrowDown'||e.code==='KeyS'){if(state==='playing'){e.preventDefault();usePortal();}return;}if(e.code==='ShiftLeft'||e.code==='ShiftRight'){if(state==='playing'){e.preventDefault();triggerDash();}return;}if(keys[e.code]){e.preventDefault();if(state==='playing'){if(keys[e.code]==='jump'&&!held.jump)jumpQueued=true;held[keys[e.code]]=true;}}else if(e.code==='Escape'||e.code==='KeyP'){e.preventDefault();if(state==='playing')pause();else if(state==='paused')resume();}});
window.addEventListener('keyup',e=>{if(keys[e.code]){e.preventDefault();held[keys[e.code]]=false;}});
window.addEventListener('blur',()=>{if(state==='playing')pause();Object.keys(held).forEach(k=>held[k]=false);});
for(const b of document.querySelectorAll('[data-key]')){const k=b.dataset.key;b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(err){}if(k==='jump'&&!held.jump)jumpQueued=true;held[k]=true;b.classList.add('active');});for(const evt of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(evt,e=>{e.preventDefault();held[k]=false;b.classList.remove('active');});}
for(const b of document.querySelectorAll('[data-action]'))b.addEventListener('pointerdown',e=>{e.preventDefault();if(b.dataset.action==='portal')usePortal();else triggerDash();});

document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{save.mode=b.dataset.mode;persist();syncGameMode();sound(780,.12,'triangle');});
syncGameMode();
updateMenuUI();
$('photoBtn').onclick=showPhotoMode;
$('scenePhotoBtn').onclick=showPhotoMode;
$('pausePhotoBtn').onclick=showPhotoMode;
$('photoCancel').onclick=closePhotoMode;
$('photoSave').onclick=savePhoto;
$('dialogueContinue').onclick=()=>{state='playing';show(null);last=performance.now();};
window.addEventListener('keydown',e=>{
 if(e.code==='KeyF'&&(state==='playing'||state==='paused'||state==='cutscene')){e.preventDefault();showPhotoMode();}
 else if(e.code==='Escape'&&state==='photo'){e.stopPropagation();closePhotoMode();}
 else if((e.code==='Enter'||e.code==='Escape')&&state==='dialogue'){e.preventDefault();$('dialogueContinue').click();}
});


window.addEventListener('orientationchange',()=>{
 if(window.innerHeight>window.innerWidth){
   apkTryLandscape(false);
 }
});

// Landscape request on launch, with a touch-activated fallback for restrictive wrappers.
// The fullscreen portrait blocker was removed; landscape handled by native Activity.
// Zıplamak için dokunmatik ekranda aynı anda iki ayrı parmak desteklenir.
window.addEventListener('resize',fitLandscapeViewport,{passive:true});
window.addEventListener('orientationchange',()=>setTimeout(fitLandscapeViewport,80));
if(window.visualViewport)window.visualViewport.addEventListener('resize',fitLandscapeViewport,{passive:true});
fitLandscapeViewport();
show('menu');apkTryLandscape(false);requestAnimationFrame(loop);
})();
