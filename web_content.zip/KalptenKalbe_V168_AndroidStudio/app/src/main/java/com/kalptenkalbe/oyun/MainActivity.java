package com.kalptenkalbe.oyun;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;
import java.io.IOException;
import java.util.HashMap;

public class MainActivity extends Activity {
  private WebView webView;
  private static final String HOST = "appassets.androidplatform.net";
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    immersive();
    webView = new WebView(this);
    webView.setBackgroundColor(0xFF231331);
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setMediaPlaybackRequiresUserGesture(true);
    settings.setAllowFileAccess(false);
    settings.setAllowContentAccess(false);
    webView.setWebChromeClient(new WebChromeClient());
    webView.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req){
        Uri uri=req.getUrl();
        if(!"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost()))return super.shouldInterceptRequest(v,req);
        String path=uri.getPath();
        if(path==null || !path.startsWith("/web/")) return error404();
        String relative=path.substring(5);
        if(relative.isEmpty())relative="index.html";
        if(relative.startsWith("/") || relative.contains("..") || relative.contains("\\"))return error404();
        try{
          InputStream input=getAssets().open("web/"+relative);
          String mime="application/octet-stream";
          if(relative.endsWith(".html"))mime="text/html";
          else if(relative.endsWith(".css"))mime="text/css";
          else if(relative.endsWith(".js"))mime="application/javascript";
          else if(relative.endsWith(".webp"))mime="image/webp";
          else if(relative.endsWith(".png"))mime="image/png";
          else if(relative.endsWith(".jpg"))mime="image/jpeg";
          else if(relative.endsWith(".mp3"))mime="audio/mpeg";
          HashMap<String,String> headers=new HashMap<>();
          headers.put("Cache-Control","max-age=3600");
          return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,input);
        }catch(IOException e){return error404();}
      }
      private WebResourceResponse error404(){
        return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",new HashMap<>(),new java.io.ByteArrayInputStream("Missing app asset".getBytes(java.nio.charset.StandardCharsets.UTF_8)));
      }
    });
    setContentView(webView);
    webView.loadUrl("https://"+HOST+"/web/index.html");
  }
  private void immersive(){
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
  }
  @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused)immersive();}
  @Override public void onBackPressed(){
    if(webView!=null)webView.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape',bubbles:true}))",null);
    else super.onBackPressed();
  }
  @Override protected void onPause(){if(webView!=null)webView.onPause();super.onPause();}
  @Override protected void onResume(){super.onResume();if(webView!=null)webView.onResume();immersive();}
  @Override protected void onDestroy(){if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
