Kalpten Kalbe V16.8 Android Studio Kaynak Projesi (APK değildir).

1. Android Studio > Open: bu klasörü aç.
2. Gradle sync / gerekirse SDK 35 ve JDK 17 kurulumuna izin ver.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
5. Manifest SCREEN_ORIENTATION_LANDSCAPE, offline assets /web/index.html.

Dikkat: Bir dönüştürücünün oluşturduğu APK bozuksa, HTML düzenlemesi tek başına onun içindeki yanlış WebView yapılandırmasını düzeltemez. Bu proje alternatif bir uygulama kabuğu sağlar.
Uygulama paketi / imzası değişirse eski APK kayıtları otomatik taşınmayabilir.
