#!/bin/bash
# Fix-IndoNix
# Todos com 2>/dev/null || true
# (Original é módulo Zygisk - aqui comandos genéricos de performance)

echo "Aplicando Fix-IndoNix (comandos genéricos)..."

settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true
settings put global force_gpu_rendering 1 2>/dev/null || true
setprop debug.performance.tuning 1 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
pm trim-caches 999G 2>/dev/null || true

echo "Fix-IndoNix (comandos base) aplicado!"
echo "Nota: O original é módulo Zygisk. Instale via Magisk para efeito completo."
