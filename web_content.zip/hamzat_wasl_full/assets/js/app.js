const names={director:"مدير المؤسسة",vice:"الناظر / نائب المدير",teacher:"الأستاذ",student:"التلميذ",parent:"الولي",admin_staff:"العامل الإداري",professional_staff:"العامل المهني",counselor:"مستشار التوجيه",supervisor:"مشرف المنصة"};
const menus={
director:[["home","الرئيسية","⌂"],["approvals","الموافقات","✓"],["institution","المؤسسة","▦"],["members","الأعضاء","♙"],["announcements","الإعلانات","▤"],["space","فضاء المؤسسة","◇"],["reports","التقارير","▥"],["audit","سجل العمليات","◷"],["settings","الإعدادات","⚙"]],
vice:[["home","الرئيسية","⌂"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["announcements","الإعلانات","▤"],["tasks","المهام","✓"],["lessons","الدروس","▣"],["settings","الإعدادات","⚙"]],
teacher:[["home","الرئيسية","⌂"],["classes","أقسامي","▦"],["lessons","الدروس والتمارين","▣"],["grades","العلامات","▥"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["settings","الإعدادات","⚙"]],
student:[["home","الرئيسية","⌂"],["lessons","الدروس","▣"],["grades","العلامات","▥"],["attendance","الغيابات","◷"],["announcements","الإعلانات","▤"],["notifications","الإشعارات","♧"],["settings","الإعدادات","⚙"]],
parent:[["home","الرئيسية","⌂"],["grades","العلامات","▥"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["announcements","الإعلانات","▤"],["notifications","الإشعارات","♧"],["settings","الإعدادات","⚙"]],
admin_staff:[["home","الرئيسية","⌂"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["tasks","المهام","✓"],["members","الأعضاء","♙"],["announcements","الإعلانات","▤"],["settings","الإعدادات","⚙"]],
professional_staff:[["home","الرئيسية","⌂"],["tasks","المهام","✓"],["notifications","التبليغات","✉"],["announcements","الإعلانات","▤"],["settings","الإعدادات","⚙"]],
counselor:[["home","الرئيسية","⌂"],["members","التلاميذ","♙"],["space","فضاء المؤسسة","◇"],["summons","الاستدعاءات","✉"],["announcements","الإعلانات","▤"],["settings","الإعدادات","⚙"]],
supervisor:[["home","الرئيسية","⌂"],["institutions","المؤسسات","▦"],["accounts","حسابات المديرين","♙"],["audit","سجل العمليات","◷"],["settings","الإعدادات","⚙"]]};
const titles={home:"الرئيسية",approvals:"الموافقات",institution:"المؤسسة والهيكل",members:"الأعضاء",announcements:"الإعلانات",space:"فضاء المؤسسة",reports:"التقارير",audit:"سجل العمليات",settings:"الإعدادات",attendance:"الغيابات",summons:"الاستدعاءات",tasks:"المهام والتبليغات",lessons:"الدروس والتمارين",grades:"العلامات والنتائج",notifications:"الإشعارات",classes:"أقسامي",institutions:"المؤسسات",accounts:"حسابات المديرين"};
const sample={announcements:[["انطلاق همزة وصل","مرحبًا بكم في النسخة التجريبية للمؤسسة.","الجميع"],["تنظيم استعمال المنصة","تظهر الخدمات وفق دور كل مستخدم وصلاحياته.","الأساتذة والموظفون"],["ملاحظة تقنية","لا تستخدم بيانات حقيقية في هذا النموذج.","الجميع"]],
members:[["مريم بن صالح","تلميذة","2 ثانوي علوم تجريبية","نشط"],["أمين قادري","أستاذ","رياضيات","نشط"],["سارة بوعلام","موظفة","إدارة","مراجعة"]],
attendance:[["مريم بن صالح","2 ثانوي 1","13 أكتوبر","غياب"],["ياسين مراد","2 ثانوي 2","13 أكتوبر","تأخر"]],
grades:[["مريم بن صالح","رياضيات","فرض 1","15.5"],["ياسين مراد","فيزياء","تقويم مستمر","13"]],
approvals:[["طلب تسجيل — أمين قادري","مطابق للقائمة","أخضر"],["طلب تسجيل — سارة بوعلام","يحتاج مراجعة","أصفر"],["طلب الناظر","قرار المدير مطلوب","حساس"]],
tasks:[["تحضير قاعة الاجتماعات","العامل المهني","قيد التنفيذ"],["تجهيز ملف القسم","العامل الإداري","جديدة"]],
lessons:[["مراجعة الدوال","رياضيات","2 ثانوي 1","درس"],["قوانين الحركة","فيزياء","2 ثانوي 2","تمرين"]],
summons:[["ولي مريم بن صالح","متابعة الغيابات","بانتظار الاستلام"],["ولي ياسين مراد","موعد مع الإدارة","تم الإرسال"]],
institutions:[["ثانوية الأمل","—","نشطة"],["متوسطة النور","—","تجريبية"]]};
let role=document.body.dataset.role||sessionStorage.getItem("hwRole")||"student",user=sessionStorage.getItem("hwName")||"مستخدم تجريبي";
let store;try{store=JSON.parse(localStorage.getItem("hwStore"))||{announcements:sample.announcements,tasks:sample.tasks,audit:[]}}catch(e){store={announcements:sample.announcements,tasks:sample.tasks,audit:[]}}
const $=id=>document.getElementById(id),esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function save(){localStorage.setItem("hwStore",JSON.stringify(store))}
function toast(t){let e=$("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2500)}
function log(t){store.audit.unshift([t,user,new Date().toLocaleString("ar-DZ")]);save()}
function table(head,rows,act=false){return `<div class="tablewrap"><table class="data"><thead><tr>${head.map(x=>`<th>${x}</th>`).join("")}${act?"<th>إجراء</th>":""}</tr></thead><tbody>${rows.map((r,i)=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join("")}${act?`<td><button class="btn soft small" data-detail="${i}">عرض</button></td>`:""}</tr>`).join("")}</tbody></table></div>`}
function init(){
 if(document.body.classList.contains("login")){$("enter").onclick=()=>{let r=$("role").value;sessionStorage.setItem("hwRole",r);sessionStorage.setItem("hwName",$("name").value.trim()||"مستخدم تجريبي");location.href=`roles/${r}/dashboard.html`};return}
 document.querySelectorAll("[data-user]").forEach(e=>e.textContent=user);document.querySelectorAll("[data-role]:not(body)").forEach(e=>e.textContent=names[role]);
 buildNav();buildHome();buildPages();
 $("logout").onclick=()=>{sessionStorage.clear();location.href="../../index.html"};
 $("theme").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("hwTheme",document.body.classList.contains("dark")?"dark":"light")};
 if(localStorage.getItem("hwTheme")==="dark")document.body.classList.add("dark");
 $("bell").onclick=()=>showPage((menus[role]||menus.student).some(x=>x[0]==="notifications")?"notifications":"announcements");
}
function buildNav(){
 let m=menus[role]||menus.student;
 $("menu").innerHTML=m.map((x,i)=>`<button class="navbtn ${i===0?"active":""}" data-go="${x[0]}"><span>${x[2]}</span>${x[1]}</button>`).join("");
 let mobile=[...m.slice(0,4),...(m.length>4?[["more","المزيد","•••"]]:[])];
 $("mobile").innerHTML=mobile.map((x,i)=>`<button class="${i===0?"active":""}" data-mob="${x[0]}"><span>${x[2]}</span>${x[1]}</button>`).join("");
 document.querySelectorAll("[data-go]").forEach(x=>x.onclick=()=>showPage(x.dataset.go));
 document.querySelectorAll("[data-mob]").forEach(x=>x.onclick=()=>{if(x.dataset.mob==="more"){let extra=m.slice(4);openModal("المزيد",extra.map(v=>`<button class="btn soft small" data-extra="${v[0]}" style="margin:4px">${v[1]}</button>`).join(""));document.querySelectorAll("[data-extra]").forEach(z=>z.onclick=()=>{closeModal();showPage(z.dataset.extra)})}else showPage(x.dataset.mob)});
}
function showPage(id){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));let p=$("page-"+id);if(!p){toast("القسم غير متاح لهذا الدور.");return}p.classList.add("active");document.querySelectorAll("[data-go]").forEach(x=>x.classList.toggle("active",x.dataset.go===id));document.querySelectorAll("[data-mob]").forEach(x=>x.classList.toggle("active",x.dataset.mob===id));$("crumb").textContent=titles[id]||"المزيد";window.scrollTo({top:0,behavior:"smooth"})}
function buildHome(){
 const stats={
director:[["طلبات الموافقة","7"],["الأعضاء","428"],["الإعلانات","12"],["التقارير","4"]],
vice:[["غيابات اليوم","23"],["الاستدعاءات","8"],["الأقسام","18"],["المهام","5"]],
teacher:[["أقسامي","4"],["التلاميذ","126"],["الدروس","16"],["علامات معلقة","3"]],
student:[["دروس جديدة","8"],["آخر معدل","14.25"],["الغيابات","2"],["الإعلانات","4"]],
parent:[["الأبناء","1"],["آخر معدل","14.25"],["الغيابات","2"],["الاستدعاءات","1"]],
admin_staff:[["الطلبات","6"],["الاستدعاءات","2"],["الغيابات","23"],["الأعضاء","428"]],
professional_staff:[["المهام","6"],["مهام جديدة","2"],["الإعلانات","5"],["التبليغات","1"]],
counselor:[["التلاميذ","126"],["المواعيد","4"],["الملفات","9"],["الإشعارات","3"]],
supervisor:[["المؤسسات","2"],["حسابات المديرين","2"],["حالة الخدمة","مستقرة"],["عمليات اليوم","8"]]}[role]||[["دروس جديدة","8"],["آخر معدل","14.25"],["الغيابات","2"],["الإعلانات","4"]];
 $("stats").innerHTML=stats.map((s,i)=>`<article class="stat"><label>${s[0]}</label><strong>${s[1]}</strong><small>بيانات تجريبية</small></article>`).join("");
 const welcome={director:"لوحة قيادة المؤسسة: الموافقات والهيكل والأعضاء والإعلانات والتقارير.",vice:"تنظيم الحياة المدرسية ومتابعة الغيابات والاستدعاءات والمهام.",teacher:"فضاء الأقسام والدروس والتمارين والعلامات.",student:"تابع الدروس والنتائج والغيابات والإعلانات.",parent:"تابع المسار الدراسي والإشعارات والاستدعاءات.",admin_staff:"تنظيم الملفات والمهام والخدمات الإدارية.",professional_staff:"تابع المهام المسندة وأبلغ عن إنجازها.",counselor:"فضاء التوجيه ومرافقة التلاميذ.",supervisor:"إدارة المؤسسات وحسابات المديرين دون الاطلاع على بيانات التلاميذ."};
 $("welcome").textContent=welcome[role]||welcome.student;
 $("latest").innerHTML=store.announcements.slice(0,3).map(a=>`<article class="ann"><b>${esc(a[0])}</b><p>${esc(a[1])}</p><span class="tag">${esc(a[2])}</span></article>`).join("");
 let links=(menus[role]||menus.student).filter(x=>x[0]!=="home").slice(0,4);$("quick").innerHTML=links.map(x=>`<button data-quick="${x[0]}"><span>${x[2]}</span>${x[1]}</button>`).join("");document.querySelectorAll("[data-quick]").forEach(x=>x.onclick=()=>showPage(x.dataset.quick));
}
function shell(id,desc,body){return `<section class="page" id="page-${id}"><div class="heading"><div><h1>${titles[id]}</h1><p>${desc}</p></div><span class="badge">${names[role]}</span></div>${body}</section>`}
function form(fields,button="حفظ تجريبي"){return `<form class="panel formgrid" data-form="${fields[0][0]}">${fields.map(f=>`<div class="${f[3]?"full":""}"><label>${f[1]}</label>${f[2]==="textarea"?`<textarea class="field" name="${f[0]}" rows="3" required></textarea>`:`<input class="field" name="${f[0]}" ${f[2]==="date"?'type="date"':f[2]==="number"?'type="number" min="0" max="20" step=".25"':'type="text"'} required>`}</div>`).join("")}<div class="full"><button class="btn primary">${button}</button></div></form>`}
function pageBody(id){
 let intro=`<div class="intro">واجهة تجريبية للوحدة. العمليات تحفظ محليًا على هذا المتصفح فقط؛ الربط الحقيقي والصلاحيات وقاعدة البيانات ستضاف في مرحلة الخادم.</div>`;
 if(id==="approvals")return intro+`<div class="toolbar"><input class="field" id="searchRows" placeholder="بحث في الطلبات"><button class="btn primary small" id="bulk">قبول الطلبات الخضراء</button></div><div id="tbl">${table(["الطلب","الحالة","التصنيف"],sample.approvals,true)}</div>`;
 if(id==="institution")return intro+`<div class="stats"><div class="stat"><label>السنة الدراسية</label><strong>2026 / 2027</strong></div><div class="stat"><label>الأطوار</label><strong>ثانوي</strong></div><div class="stat"><label>المستويات</label><strong>2 و3</strong></div><div class="stat"><label>الأقسام</label><strong>18</strong></div></div>`+form([["name","اسم القسم"],["branch","الشعبة"]],"إضافة قسم تجريبي");
 if(id==="members")return intro+`<div class="toolbar"><input class="field" id="searchRows" placeholder="بحث عن عضو"><button class="btn primary small" id="csv">استيراد CSV</button></div><div id="tbl">${table(["الاسم","الصفة","التفاصيل","الحالة"],sample.members,true)}</div>`;
 if(id==="announcements")return intro+form([["title","عنوان الإعلان"],["audience","الجمهور"],["body","نص الإعلان","textarea",true]],"نشر الإعلان")+`<div class="panel"><h3>الإعلانات المنشورة</h3><div id="annlist"></div></div>`;
 if(id==="attendance")return intro+form([["student","اسم التلميذ"],["class","القسم"],["date","التاريخ","date"],["status","الحالة"]],"تسجيل الغياب / التأخر")+`<div class="panel"><h3>سجل الغيابات</h3><div id="tbl">${table(["التلميذ","القسم","التاريخ","الحالة"],sample.attendance)}</div></div>`;
 if(id==="space")return intro+form([["type","نوع البلاغ: عام أو خاص بالإدارة"],["identity","الهوية: باسمي أو مجهول"],["title","موضوع البلاغ"],["body","التفاصيل","textarea",true]],"إرسال البلاغ")+`<div class="panel"><h3>حالات البلاغ</h3><p style="font-size:10px;color:var(--muted)">جديد • قيد المعالجة • تم الحل. كشف هوية المبلّغ المجهول للمدير فقط مع تسجيل العملية.</p></div>`;
 if(id==="lessons")return intro+form([["title","عنوان الدرس / التمرين"],["subject","المادة"],["class","القسم"],["type","النوع: درس أو تمرين أو واجب"],["body","النص أو الرابط","textarea",true]],"نشر المورد")+`<div class="panel"><h3>الموارد المنشورة</h3><div id="tbl">${table(["العنوان","المادة","القسم","النوع"],sample.lessons)}</div></div>`;
 if(id==="grades")return intro+form([["student","اسم التلميذ"],["subject","المادة"],["kind","نوع التقييم"],["mark","العلامة / 20","number"]],"إضافة علامة")+`<div class="panel"><h3>العلامات</h3><div id="tbl">${table(["التلميذ","المادة","التقييم","العلامة"],sample.grades)}</div></div>`;
 if(id==="summons")return intro+form([["parent","اسم الولي"],["reason","سبب الاستدعاء"],["date","موعد مقترح","date"]],"إنشاء طلب استدعاء")+`<div class="panel"><h3>الاستدعاءات</h3><div id="tbl">${table(["الولي","السبب","الحالة"],sample.summons,true)}</div></div>`;
 if(id==="tasks")return intro+form([["title","عنوان المهمة"],["assignee","المكلّف: إداري أو مهني"]],"إسناد المهمة")+`<div class="panel"><h3>المهام المسندة</h3><div id="tbl">${table(["المهمة","المكلّف","الحالة"],store.tasks,true)}</div></div>`;
 if(id==="notifications")return intro+`<div id="annlist"></div>`;
 if(id==="reports")return intro+`<div class="stats"><div class="stat"><label>سجلات الغياب</label><strong>23</strong></div><div class="stat"><label>استدعاءات مفتوحة</label><strong>8</strong></div><div class="stat"><label>البلاغات</label><strong>5</strong></div><div class="stat"><label>تم حلها</label><strong>3</strong></div></div><div class="panel"><h3>ملخص حسب الفترة</h3><select class="field"><option>هذا الأسبوع</option><option>هذا الشهر</option><option>الفصل الأول</option></select></div>`;
 if(id==="audit")return intro+`<div class="panel"><h3>سجل العمليات</h3><div id="tbl">${store.audit.length?table(["العملية","المستخدم","التاريخ"],store.audit):"لا توجد عمليات بعد."}</div></div>`;
 if(id==="settings")return intro+`<div class="panel"><h3>المظهر</h3><p style="font-size:10px;color:var(--muted)">اختر الوضع المناسب.</p><button class="btn soft" id="light">نهاري</button> <button class="btn primary" id="dark">ليلي</button> <button class="btn line" id="auto">تلقائي</button></div><div class="panel"><h3>الحساب</h3><p style="font-size:10px;color:var(--muted)">الاسم الظاهر: ${esc(user)} — ${names[role]}</p><button class="btn line small" id="rename">تغيير الاسم التجريبي</button></div>`;
 if(id==="classes")return intro+table(["القسم","المادة","عدد التلاميذ","الحالة"],[["2 ثانوي 1","رياضيات","32","نشط"],["2 ثانوي 2","رياضيات","30","نشط"],["3 ثانوي 1","رياضيات","28","نشط"]]);
 if(id==="institutions")return intro+form([["name","اسم المؤسسة"],["region","المنطقة"]],"إنشاء مؤسسة تجريبية")+`<div class="panel"><div id="tbl">${table(["المؤسسة","المنطقة","الحالة"],sample.institutions)}</div></div>`;
 if(id==="accounts")return intro+form([["name","اسم المدير"],["institution","المؤسسة"]],"إصدار حساب تجريبي");
 return intro+`<div class="panel">هذه الصفحة جزء من مساحة الدور المختار.</div>`;
}
function buildPages(){let m=menus[role]||menus.student;$("pages").innerHTML=m.filter(x=>x[0]!=="home").map(x=>shell(x[0],"إدارة ومتابعة خدمات المؤسسة التعليمية.",pageBody(x[0]))).join("");renderLists();wireForms()}
function renderLists(){let a=$("annlist");if(a)a.innerHTML=store.announcements.map(x=>`<article class="ann"><b>${esc(x[0])}</b><p>${esc(x[1])}</p><span class="tag">${esc(x[2])}</span></article>`).join("")}
function wireForms(){
 document.querySelectorAll("form[data-form]").forEach(f=>f.onsubmit=e=>{e.preventDefault();let d=Object.fromEntries(new FormData(f));let id=f.closest(".page").id.replace("page-","");
 if(id==="announcements"){store.announcements.unshift([d.title,d.body,d.audience]);save();renderLists();buildHome();log("نشر إعلان: "+d.title)}
 else if(id==="tasks"){store.tasks.unshift([d.title,d.assignee,"جديدة"]);save();log("إسناد مهمة: "+d.title)}
 else if(id==="attendance"){sample.attendance.unshift([d.student,d.class,d.date,d.status]);log("تسجيل "+d.status+" للتلميذ "+d.student)}
 else if(id==="grades"){sample.grades.unshift([d.student,d.subject,d.kind,d.mark]);log("إضافة علامة: "+d.student)}
 else if(id==="lessons"){sample.lessons.unshift([d.title,d.subject,d.class,d.type]);log("نشر مورد: "+d.title)}
 else if(id==="summons"){sample.summons.unshift([d.parent,d.reason,"طلب جديد"]);log("إنشاء استدعاء")}
 else if(id==="space"){log("بلاغ جديد: "+d.title)}
 else if(id==="institution"){log("إضافة قسم: "+d.name)}
 else if(id==="institutions"){sample.institutions.unshift([d.name,d.region,"تجريبية"]);log("إنشاء مؤسسة: "+d.name)}
 else if(id==="accounts"){log("إصدار حساب مدير تجريبي: "+d.name)}
 let t=f.parentElement.querySelector("#tbl");if(t){let rows=id==="attendance"?sample.attendance:id==="grades"?sample.grades:id==="lessons"?sample.lessons:id==="summons"?sample.summons:id==="tasks"?store.tasks:id==="institutions"?sample.institutions:null;if(rows)t.innerHTML=table(rows[0].length===4?["الاسم","التفاصيل","البيان","الحالة"]:["الاسم","التفاصيل","الحالة"],rows,true)}
 f.reset();toast("تم حفظ العملية في النسخة التجريبية.");
 });
 $("bulk")?.addEventListener("click",()=>{log("محاكاة قبول الطلبات الخضراء");toast("تمت محاكاة قبول الطلبات الخضراء.")});
 $("csv")?.addEventListener("click",()=>alert("استيراد CSV الفعلي سيُضاف عند ربط الخادم. هذه الواجهة لا ترفع الملفات بعد."));
 $("light")?.addEventListener("click",()=>setTheme("light"));$("dark")?.addEventListener("click",()=>setTheme("dark"));$("auto")?.addEventListener("click",()=>setTheme(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light"));
 $("rename")?.addEventListener("click",()=>{let n=prompt("الاسم التجريبي الجديد:");if(n){user=n;sessionStorage.setItem("hwName",n);document.querySelectorAll("[data-user]").forEach(x=>x.textContent=n);toast("تم تحديث الاسم.")}});
 document.querySelectorAll("[data-detail]").forEach(x=>x.onclick=()=>alert("تفاصيل توضيحية — ستضاف إجراءات حسب صلاحية الدور."));
}
function setTheme(t){document.body.classList.toggle("dark",t==="dark");localStorage.setItem("hwTheme",t)}
function openModal(title,html){let box=document.createElement("div");box.className="modalbg show";box.innerHTML=`<div class="modal"><h3>${title}</h3>${html}<button class="btn line small" id="closeM">إغلاق</button></div>`;document.body.appendChild(box);box.querySelector("#closeM").onclick=()=>box.remove();box.onclick=e=>{if(e.target===box)box.remove()}}
function closeModal(){document.querySelector(".modalbg")?.remove()}
document.addEventListener("DOMContentLoaded",init);
