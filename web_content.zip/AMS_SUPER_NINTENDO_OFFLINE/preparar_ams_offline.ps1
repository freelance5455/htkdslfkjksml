$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Assets = Join-Path $ProjectRoot 'app\src\main\assets'
$EmuDir = Join-Path $Assets 'emulatorjs'
$DataDir = Join-Path $EmuDir 'data'
$ZipOut = Join-Path $ProjectRoot 'AMS_SUPER_NINTENDO_OFFLINE_ASSETS.zip'

New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
Write-Host 'Baixando a distribuição oficial do EmulatorJS (requer internet nesta etapa)...' -ForegroundColor Cyan
$api = 'https://api.github.com/repos/EmulatorJS/EmulatorJS/releases/latest'
$release = Invoke-RestMethod -Uri $api -Headers @{ 'User-Agent' = 'AMS-Super-Nintendo-Offline-Setup' }
$asset = $release.assets | Where-Object { $_.name -match '\.zip$' } | Select-Object -First 1
if (-not $asset) { throw 'A release não publicou um ZIP. Consulte a distribuição oficial do EmulatorJS e coloque os arquivos da pasta data em app\src\main\assets\emulatorjs\data.' }
$tmpZip = Join-Path $env:TEMP 'ams_emulatorjs_release.zip'
$tmpDir = Join-Path $env:TEMP 'ams_emulatorjs_release'
Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $tmpZip -Headers @{ 'User-Agent' = 'AMS-Super-Nintendo-Offline-Setup' }
if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force
$loader = Get-ChildItem -Path $tmpDir -Recurse -File -Filter 'loader.js' | Select-Object -First 1
if (-not $loader) { throw 'O ZIP não contém loader.js.' }
$sourceData = $loader.Directory.FullName
if (Test-Path $DataDir) { Remove-Item $DataDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
Copy-Item -Path (Join-Path $sourceData '*') -Destination $DataDir -Recurse -Force
$required = @('loader.js')
foreach ($f in $required) { if (-not (Test-Path (Join-Path $DataDir $f))) { throw "Arquivo obrigatório ausente: $f" } }
$wasm = Get-ChildItem $DataDir -Recurse -File -Filter '*.wasm' | Select-Object -First 1
if (-not $wasm) { throw 'Nenhum arquivo WASM foi encontrado. Distribuição incompleta: não marque como pronto para offline.' }
if (Test-Path $ZipOut) { Remove-Item $ZipOut -Force }
Compress-Archive -Path (Join-Path $Assets '*') -DestinationPath $ZipOut -Force
Write-Host 'Assets do emulador copiados para app\src\main\assets\emulatorjs\data' -ForegroundColor Green
Write-Host "Backup criado: $ZipOut" -ForegroundColor Green
Write-Host 'Agora copie a pasta app/src/main/assets para android-example/app/src/main/assets e compile o APK no Android Studio.' -ForegroundColor Yellow
