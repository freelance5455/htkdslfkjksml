Projeto Android de exemplo para AMS SUPER NINTENDO.

Antes de compilar, copie o conteúdo de ../app/src/main/assets para app/src/main/assets DESTE projeto, incluindo emulatorjs/data completo preparado pelo script PowerShell.
Abra esta pasta android-example no Android Studio e compile o APK.

WebViewAssetLoader serve os assets em https://appassets.androidplatform.net/assets/, permitindo caminhos relativos locais, IndexedDB e workers sem file://.
Não compile esperando emulador pronto enquanto emulatorjs/data não estiver preenchido com a distribuição completa.
