# My Animal – Projet APK Android (multi-écran)

Projet Android complet qui transforme le jeu HTML **My Animal** en application native.
Conçu pour fonctionner **sans bug d’affichage** sur :

- Téléphones (portrait & paysage)
- Tablettes
- Foldables / multi-fenêtres
- Écrans larges

## Contenu du projet

```
MyAnimalAPK/
├── www/index.html                          ← jeu original
├── android-project/                        ← projet Android Studio
│   ├── app/src/main/
│   │   ├── assets/index.html               ← le jeu embarqué
│   │   ├── java/.../MainActivity.java      ← WebView optimisée
│   │   ├── res/mipmap-*/ic_launcher.png
│   │   └── AndroidManifest.xml
│   └── ...
└── README.md
```

## Comment générer l’APK

### Méthode recommandée (Android Studio)

1. Installe **Android Studio** : https://developer.android.com/studio
2. Ouvre Android Studio → **Open** → sélectionne le dossier  
   `MyAnimalAPK/android-project`
3. Attends la synchronisation Gradle (1re fois : 2-5 min)
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. Clique sur **locate** → tu obtiens  
   `app/build/outputs/apk/debug/app-debug.apk`

Tu peux installer ce fichier sur n’importe quel téléphone/tablette Android.

### Version release signée (Play Store)

**Build → Generate Signed Bundle / APK** → crée un keystore → Release.

## Ce qui a été optimisé pour tous les écrans

| Fonctionnalité | Détail |
|---------------|--------|
| Rotation libre | Portrait + paysage + inversés (`fullSensor`) |
| Pas de recréation d’activité | `configChanges` complet → pas de flash ni de reset |
| Redimensionnement forcé | Appel automatique de `resize()` du jeu à chaque rotation |
| Mode immersif | Barres système cachées, edge-to-edge |
| Tablettes / multi-fenêtre | `resizeableActivity="true"` + `smallestScreenSize` |
| Zoom système désactivé | `textZoom=100` pour éviter les décalages de police |
| Canvas haute densité | Le jeu utilise déjà `devicePixelRatio` |

Le HTML du jeu contient déjà :
- `viewport-fit=cover`
- écouteurs `resize` + `orientationchange` + `ResizeObserver`
- positionnement en `%` / `vw` / `safe-area-inset`

→ Combiné avec la WebView ci-dessus, l’affichage reste stable sur tous les formats.

## Permissions

- **Caméra** (optionnelle) → fonction photo AR
- Internet (déclaré mais le jeu fonctionne 100 % hors-ligne)

## Icône & nom

- Nom affiché : **My Animal**
- Icône : patte orange (tu peux la remplacer dans `res/mipmap-*`)

Bon jeu ! 🐾
