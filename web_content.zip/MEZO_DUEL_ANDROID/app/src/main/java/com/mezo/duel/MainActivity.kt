package com.mezo.duel
import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity:Activity(){
 private lateinit var web:WebView; private lateinit var bt:BluetoothManager; private val REQ=501
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);requestedOrientation=android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
  web=WebView(this).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.allowFileAccess=true;settings.allowContentAccess=true;webViewClient=WebViewClient();webChromeClient=WebChromeClient()};setContentView(web)
  bt=BluetoothManager(this,object:BluetoothManager.Callback{override fun onState(type:String,payload:String){runOnUiThread{web.evaluateJavascript("window.onBluetoothEvent(${q(type)},${q(payload)});",null)}};override fun onMessage(json:String){runOnUiThread{web.evaluateJavascript("window.onBluetoothMessage(${q(json)});",null)}}})
  web.addJavascriptInterface(Bridge(),"AndroidBT");web.loadUrl("file:///android_asset/index.html");requestBtPermissions()
 }
 private fun q(s:String)="\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\""
 private fun requestBtPermissions(){val p=if(Build.VERSION.SDK_INT>=31)arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_ADVERTISE)else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION);val m=p.filter{checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED};if(m.isNotEmpty())requestPermissions(m.toTypedArray(),REQ)else ensureEnabled()}
 private fun ensureEnabled(){if(!bt.enabled())startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),REQ)}
 inner class Bridge{@JavascriptInterface fun startHost(){runOnUiThread{ensureEnabled();bt.host()}};@JavascriptInterface fun scan(){runOnUiThread{ensureEnabled();bt.discover()}};@JavascriptInterface fun connect(address:String){bt.connect(address)};@JavascriptInterface fun send(json:String){bt.send(json)};@JavascriptInterface fun closeConnection(){bt.closeConnection()};@JavascriptInterface fun isAvailable()=bt.hasAdapter()}
 override fun onDestroy(){bt.close();web.destroy();super.onDestroy()}
}
