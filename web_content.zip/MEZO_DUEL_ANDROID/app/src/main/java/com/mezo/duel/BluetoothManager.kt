package com.mezo.duel
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.CopyOnWriteArraySet
class BluetoothManager(private val context: Context, private val callback: Callback) {
 interface Callback { fun onState(type:String,payload:String="{}"); fun onMessage(json:String) }
 private val adapter=BluetoothAdapter.getDefaultAdapter(); private val uuid=UUID.fromString("9b6d3b20-5c5d-4c5b-9b8e-4d2c1d8e3a71")
 private var server:BluetoothServerSocket?=null; @Volatile private var socket:BluetoothSocket?=null; private val exec=Executors.newCachedThreadPool(); private val found=CopyOnWriteArraySet<String>()
 private val receiver=object:BroadcastReceiver(){ @SuppressLint("MissingPermission") override fun onReceive(c:Context?,i:Intent?){ if(i?.action==BluetoothDevice.ACTION_FOUND){ val d=i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)?:return; val n=try{d.name?:"جهاز Bluetooth"}catch(_:Exception){"جهاز Bluetooth"}; if(found.add(d.address))callback.onState("device","{\"name\":${q(n)},\"address\":${q(d.address)}}") } } }
 init{context.registerReceiver(receiver,IntentFilter(BluetoothDevice.ACTION_FOUND),Context.RECEIVER_NOT_EXPORTED)}
 private fun q(s:String)="\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\""
 fun hasAdapter()=adapter!=null
 @SuppressLint("MissingPermission") fun enabled()=adapter?.isEnabled==true
 @SuppressLint("MissingPermission") fun discover(){val a=adapter?:return callback.onState("error","{\"message\":\"Bluetooth غير متاح\"}");found.clear();if(a.isDiscovering)a.cancelDiscovery();if(!a.startDiscovery())callback.onState("error","{\"message\":\"تعذر بدء البحث عن الأجهزة\"}") else callback.onState("scan","{\"ok\":true}")}
 @SuppressLint("MissingPermission") fun host(){val a=adapter?:return callback.onState("error","{\"message\":\"Bluetooth غير متاح\"}");exec.execute{try{server?.close();server=a.listenUsingRfcommWithServiceRecord("MEZO DUEL",uuid);callback.onState("host","{\"ok\":true}");val s=server!!.accept();socket=s;server?.close();server=null;callback.onState("connected","{\"role\":\"host\"}");startIo(s)}catch(e:Exception){callback.onState("error","{\"message\":${q(e.message?:"فشل إنشاء الاتصال")}}")} } }
 @SuppressLint("MissingPermission") fun connect(address:String){val a=adapter?:return callback.onState("error","{\"message\":\"Bluetooth غير متاح\"}");exec.execute{try{a.cancelDiscovery();val d=a.getRemoteDevice(address);val s=d.createRfcommSocketToServiceRecord(uuid);s.connect();socket=s;callback.onState("connected","{\"role\":\"client\",\"name\":${q(d.name?:"")},\"address\":${q(address)}}");startIo(s)}catch(e:Exception){callback.onState("error","{\"message\":${q(e.message?:"فشل الاتصال")}}")} } }
 fun send(json:String){exec.execute{try{socket?.outputStream?.let{it.write((json.replace("\n","")+"\n").toByteArray(StandardCharsets.UTF_8));it.flush()}}catch(e:Exception){callback.onState("error","{\"message\":${q(e.message?:"تعذر الإرسال")}}")} } }
 private fun startIo(s:BluetoothSocket){exec.execute{try{val r=BufferedReader(InputStreamReader(s.inputStream,StandardCharsets.UTF_8));while(true){val line=r.readLine()?:break;callback.onMessage(line)}}catch(_:Exception){callback.onState("disconnected","{}")}}}
 @SuppressLint("MissingPermission") fun closeConnection(){try{socket?.close()}catch(_:Exception){};socket=null}
 fun close(){try{server?.close()}catch(_:Exception){};closeConnection();exec.shutdownNow();try{context.unregisterReceiver(receiver)}catch(_:Exception){}}
}
