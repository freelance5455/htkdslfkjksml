# Brazilian Sensei

Premium Free Fire Community Sensitivity Guide (Web App + PWA)

## Features

- Clean login screen (Demo: Username `20` / Password `10`)
- Dashboard with 2GB / 4GB / 6GB / 7GB+ RAM profiles
- Individual sensitivity pages with copy buttons
- Dark gaming UI with neon accents + Brazilian theme
- Fully mobile-friendly + works on desktop
- PWA-ready (can be installed on Android)
- Easy-to-edit sensitivity values in `data.js`
- No game modification, no cheats, no root required

## How to Use

### Option 1: Open directly
1. Open `index.html` in any modern browser (Chrome recommended).
2. Login with:
   - **Username:** `20`
   - **Password:** `10`

### Option 2: Host online (recommended)
Upload the entire `brazilian-sensei` folder to any free hosting:
- GitHub Pages
- Netlify
- Vercel
- Firebase Hosting
- etc.

Then open the link on your phone → “Add to Home Screen” for app-like experience.

### Option 3: Convert to Android APK
You can turn this PWA into a real APK using:
- [PWABuilder](https://www.pwabuilder.com/)
- Capacitor
- Bubblewrap (Trusted Web Activity)

## Editing Sensitivity Values

Open `data.js` and change any numbers. Example:

```js
"2gb": {
  title: "2GB RAM Profile",
  settings: [
    { name: "General", value: 98 },
    { name: "Red Dot", value: 85 },
    // ... change freely
  ]
}
```

No need to touch the HTML or CSS.

## Important Notes

- These are **Community Recommended Profiles** only.
- Not official Free Fire / Garena settings.
- Sensitivity depends on device, DPI, refresh rate and personal preference.
- This app does **not** modify Free Fire files or inject any code.

## File Structure

```
brazilian-sensei/
├── index.html      → Main app
├── styles.css      → Custom styles & animations
├── app.js          → Login + navigation logic
├── data.js         → Sensitivity values (edit here)
├── sw.js           → Offline support
├── manifest.json   → PWA config
└── README.md
```

---

Made for educational / community use only.  
Not affiliated with Garena or Free Fire.