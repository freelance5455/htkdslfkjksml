// ============================================
// Brazilian Sensei - Sensitivity Data
// Easy to edit: just change the numbers below
// ============================================

const SENSITIVITY_DATA = {
  "2gb": {
    title: "2GB RAM Profile",
    subtitle: "Optimized for low-end devices",
    color: "cyan",
    settings: [
      { name: "General", value: 98 },
      { name: "Red Dot", value: 85 },
      { name: "2X Scope", value: 78 },
      { name: "4X Scope", value: 72 },
      { name: "Sniper Scope", value: 58 },
      { name: "Free Look", value: 70 }
    ]
  },
  "4gb": {
    title: "4GB RAM Profile",
    subtitle: "Balanced for mid-range phones",
    color: "green",
    settings: [
      { name: "General", value: 95 },
      { name: "Red Dot", value: 82 },
      { name: "2X Scope", value: 75 },
      { name: "4X Scope", value: 68 },
      { name: "Sniper Scope", value: 55 },
      { name: "Free Look", value: 68 }
    ]
  },
  "6gb": {
    title: "6GB RAM Profile",
    subtitle: "Smooth experience for upper mid-range",
    color: "purple",
    settings: [
      { name: "General", value: 92 },
      { name: "Red Dot", value: 80 },
      { name: "2X Scope", value: 73 },
      { name: "4X Scope", value: 65 },
      { name: "Sniper Scope", value: 52 },
      { name: "Free Look", value: 65 }
    ]
  },
  "7gb": {
    title: "7GB+ RAM Profile",
    subtitle: "Precision settings for flagship devices",
    color: "yellow",
    settings: [
      { name: "General", value: 90 },
      { name: "Red Dot", value: 78 },
      { name: "2X Scope", value: 70 },
      { name: "4X Scope", value: 62 },
      { name: "Sniper Scope", value: 50 },
      { name: "Free Look", value: 62 }
    ]
  }
};

// Color mapping for dynamic styling
const COLOR_MAP = {
  cyan: {
    text: "text-neon-cyan",
    border: "border-neon-cyan/30",
    bg: "bg-neon-cyan/10",
    button: "hover:border-neon-cyan/50"
  },
  green: {
    text: "text-neon-green",
    border: "border-neon-green/30",
    bg: "bg-neon-green/10",
    button: "hover:border-neon-green/50"
  },
  purple: {
    text: "text-neon-purple",
    border: "border-neon-purple/30",
    bg: "bg-neon-purple/10",
    button: "hover:border-neon-purple/50"
  },
  yellow: {
    text: "text-neon-yellow",
    border: "border-neon-yellow/30",
    bg: "bg-neon-yellow/10",
    button: "hover:border-neon-yellow/50"
  }
};