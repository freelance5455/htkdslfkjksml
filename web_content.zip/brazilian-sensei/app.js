// ============================================
// Brazilian Sensei - App Logic
// ============================================

const DEMO_USER = "20";
const DEMO_PASS = "10";

// Elements
const loginScreen = document.getElementById("login-screen");
const telegramScreen = document.getElementById("telegram-screen");
const app = document.getElementById("app");
const dashboard = document.getElementById("dashboard");
const profilePage = document.getElementById("profile-page");
const loginBtn = document.getElementById("login-btn");
const logoutBtn = document.getElementById("logout-btn");
const continueBtn = document.getElementById("continue-btn");
const backBtn = document.getElementById("back-btn");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const loginError = document.getElementById("login-error");
const profileTitle = document.getElementById("profile-title");
const sensitivityList = document.getElementById("sensitivity-list");
const toast = document.getElementById("toast");

// Check if already logged in (session)
function checkSession() {
  if (sessionStorage.getItem("bs_logged_in") === "true") {
    // Always show Telegram screen first after login (even on refresh)
    showTelegramScreen();
  }
}

// Login
loginBtn.addEventListener("click", handleLogin);
passwordInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleLogin();
});
usernameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleLogin();
});

function handleLogin() {
  const user = usernameInput.value.trim();
  const pass = passwordInput.value.trim();

  if (user === DEMO_USER && pass === DEMO_PASS) {
    sessionStorage.setItem("bs_logged_in", "true");
    loginError.classList.add("hidden");
    showTelegramScreen();
  } else {
    loginError.classList.remove("hidden");
    // Small shake animation
    loginError.classList.add("animate-shake");
    setTimeout(() => loginError.classList.remove("animate-shake"), 400);
  }
}

function showTelegramScreen() {
  loginScreen.classList.add("hidden");
  app.classList.add("hidden");
  telegramScreen.classList.remove("hidden");
}

function showApp() {
  loginScreen.classList.add("hidden");
  telegramScreen.classList.add("hidden");
  app.classList.remove("hidden");
  showDashboard();
}

// Continue button (after Telegram)
continueBtn.addEventListener("click", () => {
  showApp();
});

// Logout
logoutBtn.addEventListener("click", () => {
  sessionStorage.removeItem("bs_logged_in");
  app.classList.add("hidden");
  telegramScreen.classList.add("hidden");
  loginScreen.classList.remove("hidden");
  usernameInput.value = "";
  passwordInput.value = "";
  loginError.classList.add("hidden");
});

// Dashboard navigation
document.querySelectorAll(".ram-card").forEach(card => {
  card.addEventListener("click", () => {
    const ram = card.dataset.ram;
    openProfile(ram);
  });
});

// Back button
backBtn.addEventListener("click", showDashboard);

function showDashboard() {
  dashboard.classList.remove("hidden");
  profilePage.classList.add("hidden");
}

function openProfile(ramKey) {
  const data = SENSITIVITY_DATA[ramKey];
  if (!data) return;

  const colors = COLOR_MAP[data.color];

  profileTitle.textContent = data.title;
  profileTitle.className = `text-xl font-bold ${colors.text}`;

  // Build sensitivity cards
  sensitivityList.innerHTML = data.settings.map((item, index) => `
    <div class="sensitivity-card bg-dark-800 border border-white/10 rounded-2xl p-4 flex items-center justify-between hover:border-white/20 transition-all" style="animation-delay: ${index * 50}ms">
      <div>
        <div class="text-sm text-gray-400 mb-0.5">${item.name}</div>
        <div class="text-2xl font-bold ${colors.text}">${item.value}</div>
      </div>
      <button 
        onclick="copyValue(${item.value}, this)"
        class="copy-btn flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs font-medium hover:bg-white/10 hover:border-white/20 active:scale-95 transition-all"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
        </svg>
        Copy
      </button>
    </div>
  `).join("");

  dashboard.classList.add("hidden");
  profilePage.classList.remove("hidden");

  // Trigger entrance animation
  document.querySelectorAll(".sensitivity-card").forEach(card => {
    card.classList.add("animate-fade-in");
  });
}

// Copy functionality
function copyValue(value, btn) {
  navigator.clipboard.writeText(value.toString()).then(() => {
    // Visual feedback on button
    const original = btn.innerHTML;
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-neon-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
      </svg>
      Copied
    `;
    btn.classList.add("border-neon-green/40", "text-neon-green");

    showToast();

    setTimeout(() => {
      btn.innerHTML = original;
      btn.classList.remove("border-neon-green/40", "text-neon-green");
    }, 1500);
  }).catch(() => {
    // Fallback for older browsers
    const temp = document.createElement("textarea");
    temp.value = value;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand("copy");
    document.body.removeChild(temp);
    showToast();
  });
}

function showToast() {
  toast.classList.remove("opacity-0", "translate-y-2");
  toast.classList.add("opacity-100", "translate-y-0");
  
  setTimeout(() => {
    toast.classList.add("opacity-0", "translate-y-2");
    toast.classList.remove("opacity-100", "translate-y-0");
  }, 1800);
}

// Init
checkSession();