Sky Hopper
===========

An original browser game inspired by one-button flying arcade games.

How to play:
- Open index.html in a modern browser.
- Tap/click the game or press Space/Arrow Up to flap.
- Avoid the gates and beat your best score.

No external libraries or network connection are required.
