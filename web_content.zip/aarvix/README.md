# Aarvix

Healthcare queue and token-booking app for India. One self-contained file: `index.html`.

## Important: data stays on each phone
All data (patients, clinics, bookings) is stored in the device's `localStorage`. It is **not shared between phones**. A booking made on a patient's phone will not appear on the clinic's phone. Payment is pay-at-clinic only and the OTP is a demo (auto-fills, no SMS).

## Demo data
On first launch three demo doctors are created (clinic phones `9000000001`, `9000000002`, `9000000003`) so the app can be explored. To remove them, delete them from the Admin > Doctors tab, or set up your own data.

## Admin
PIN `8068`. Five wrong tries lock the keypad for 10 minutes.

## Photos on the Home banner
The scrolling banner uses built-in artwork. To use real photos, add image paths to the `HERO_PHOTOS` array near the top of the script, for example `['img/1.jpg','img/2.jpg','img/3.jpg','img/4.jpg']`.

## Wrap for Android (Capacitor)
```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/app
npx cap init Aarvix com.aarvix.app --web-dir=www
mkdir www && cp index.html www/
npx cap add android
npx cap sync
npx cap open android
```
The Android back button is already handled (goes back through screens, exits from the first screen). Bundle the Poppins font locally if the app must look identical offline.

## Logo
`logo.svg` is the vector logo traced from the original image, and `icon-512.png` is a ready app icon. The same shapes are used on the splash screen and headers.

## New in this version
- **Stay logged in:** patients, clinics and admin stay logged in until they tap Log out.
- **Clinic code login:** on the clinic login screen, switch to "Clinic code" and enter the 8-character code given at registration. The code is checked before login (invalid or disabled clinics are refused). Demo clinic codes are shown in Admin > Doctors.
- **Delete account:** at the bottom of the clinic dashboard. The clinic disappears from the patient app and its bookings are deleted.
- **50 tokens a day:** each doctor has 50 tokens per day (no wrap-around). On the clinic dashboard, "Offline tokens" lets the clinic enter the last token already given to patients at the hospital. Online booking opens after that number.
- **Complete & call next:** moves to the next token even if that patient never booked online. Offline tokens are called in order, timed, and used for the average minutes per patient, so everyone's time left stays accurate.
- **Patient home:** every doctor card shows the fee and the estimated wait. Sort chips: All, Low wait, High wait, Fee low, Fee high, Open now. The doctor page keeps fee and wait visible while scrolling.
- **Premium (₹49):** an option on the pay screen for "book now" tickets. The patient is called right after the patient who is inside. It shows on the receipt and in admin revenue.
