مشروع Android للآلة الحاسبة الاحترافية

طريقة البناء باستخدام Android Studio:
1) فك ضغط المشروع.
2) افتح مجلد CalculatorPro-Android في Android Studio.
3) انتظر Gradle Sync ثم اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4) ستجد الملف في app/build/outputs/apk/debug/app-debug.apk

بديل تلقائي عبر GitHub Actions:
- ارفع محتويات المجلد إلى مستودع GitHub جديد.
- افتح تبويب Actions وشغّل Build Android APK.
- نزّل Artifact باسم CalculatorPro-debug-apk بعد نجاح البناء.

الحزمة الحالية هي مشروع مصدر قابل للبناء وليست APK جاهزاً. يتطلب إنشاء APK أدوات Android SDK/Gradle غير متوفرة في بيئة التنفيذ الحالية.
