const chatEl = document.getElementById('chat');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const settingsBtn = document.getElementById('settingsBtn');
const settingsModal = document.getElementById('settingsModal');
const apiKeyInput = document.getElementById('apiKeyInput');
const modelSelect = document.getElementById('modelSelect');
const saveSettings = document.getElementById('saveSettings');
const closeSettings = document.getElementById('closeSettings');

let messages = [];
let isWaiting = false;

// Load saved settings
function loadSettings() {
  const key = localStorage.getItem('xai_api_key') || '';
  const model = localStorage.getItem('xai_model') || 'grok-3';
  apiKeyInput.value = key;
  modelSelect.value = model;
  return { key, model };
}

function saveSettingsToStorage() {
  localStorage.setItem('xai_api_key', apiKeyInput.value.trim());
  localStorage.setItem('xai_model', modelSelect.value);
}

function addMessage(role, content, isError = false) {
  const div = document.createElement('div');
  div.className = `message ${role}${isError ? ' error' : ''}`;
  div.textContent = content;
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
  return div;
}

function showTyping() {
  const div = document.createElement('div');
  div.className = 'message assistant typing';
  div.id = 'typing';
  div.textContent = 'جاري التفكير...';
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
}

function removeTyping() {
  const t = document.getElementById('typing');
  if (t) t.remove();
}

async function sendMessage() {
  const text = userInput.value.trim();
  if (!text || isWaiting) return;

  const { key, model } = loadSettings();
  if (!key) {
    addMessage('system', 'من فضلك أدخل مفتاح xAI API أولاً من الإعدادات ⚙️', true);
    settingsModal.classList.remove('hidden');
    return;
  }

  addMessage('user', text);
  messages.push({ role: 'user', content: text });
  userInput.value = '';
  userInput.style.height = 'auto';
  isWaiting = true;
  sendBtn.disabled = true;
  showTyping();

  try {
    const response = await fetch('https://api.x.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key}`
      },
      body: JSON.stringify({
        model: model,
        messages: messages,
        stream: false,
        temperature: 0.7
      })
    });

    removeTyping();

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error?.message || `خطأ ${response.status}`);
    }

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || 'لم يتم استلام رد.';
    addMessage('assistant', reply);
    messages.push({ role: 'assistant', content: reply });
  } catch (err) {
    removeTyping();
    addMessage('system', 'خطأ: ' + err.message, true);
  } finally {
    isWaiting = false;
    sendBtn.disabled = false;
    userInput.focus();
  }
}

// Event listeners
sendBtn.addEventListener('click', sendMessage);

userInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

userInput.addEventListener('input', () => {
  userInput.style.height = 'auto';
  userInput.style.height = Math.min(userInput.scrollHeight, 120) + 'px';
});

settingsBtn.addEventListener('click', () => {
  loadSettings();
  settingsModal.classList.remove('hidden');
});

closeSettings.addEventListener('click', () => {
  settingsModal.classList.add('hidden');
});

saveSettings.addEventListener('click', () => {
  saveSettingsToStorage();
  settingsModal.classList.add('hidden');
  addMessage('system', 'تم حفظ الإعدادات بنجاح ✓');
});

// Initial
loadSettings();
addMessage('system', 'مرحباً! أنا Grok بدون حدود. أدخل مفتاح الـ API من الإعدادات وابدأ المحادثة.');
userInput.focus();
