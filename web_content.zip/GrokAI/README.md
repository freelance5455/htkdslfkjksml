# Grok AI - Unlimited Chat App

تطبيق دردشة مع Grok بدون أي حدود داخل التطبيق.

## طريقة البناء

### الأسهل (موصى به):
1. افتح المجلد في **Android Studio**
2. انتظر حتى ينتهي Gradle Sync
3. اضغط Run أو Build → Build Bundle(s) / APK(s) → Build APK(s)
4. هتلاقي الـ APK في: `app/build/outputs/apk/debug/app-debug.apk`

### من سطر الأوامر:
```bash
./gradlew assembleDebug
```

## الاستخدام
1. ثبت الـ APK على هاتفك
2. افتح التطبيق
3. اضغط على أيقونة الإعدادات ⚙️
4. أدخل مفتاح xAI API الخاص بك (من console.x.ai)
5. ابدأ المحادثة بدون حدود

## ملاحظات
- المفتاح يتخزن محلياً على الجهاز فقط
- يدعم الموديلات: grok-3, grok-2, grok-3-mini
- يحتاج إنترنت
