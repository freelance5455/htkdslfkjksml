# Screen Time Tracker — Android app (Kotlin + WebView UI)

Your logo is the app icon and the opening animation. Day theme = cream / forest green / bronze (from the logo);
Night theme = dark brown / gold (from your web app). Tap the sun/moon button, or choose Auto / Day / Night in Settings.

## Build the APK
1. Install **Android Studio** (free) → **Open** → select this `ScreenTime` folder. Let Gradle sync.
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Install `app/build/outputs/apk/debug/app-debug.apk` on your phone.
(Command line: `gradle wrapper && ./gradlew assembleDebug`)

## First launch
Animated splash → permissions screen:
- **Usage access** (required) – reads screen time, app launches, unlocks
- **Notification access** (optional) – counts notifications per app (contents are never read)
- **Alerts** (optional) – goal / limit / focus reminders

## Screens
- **Today** – only today's data. Five options on top (like your reference): Screen Time · Summary · App Launches · Notifications · Device Unlocks
- **Week** – the same five options with a date navigator: ‹ › arrows, Hourly / Daily / Weekly intervals, "Jump to today"; tap bars or heat-map cells to open any day
- **Stats** – Usage Stats like your reference: Daily / Weekly, All apps · Distracting · Productive · Others filter, stacked Mon–Sun bars, totals, search. Tap any app to set its category and a custom Productive / Distracting split for a day (the rest counts as Others). "Choose productive & distracting apps" sorts many apps quickly (also in Settings)
- **Focus** – timer that buzzes even when the app is closed
- **Blocks** – one-tap app blocking (opening a blocked app shows “Go back to study”) and the Game blocker (see below)
- **Settings** – theme, goal, alerts, app limits, widgets, permissions
- **Widgets** – Today (4×2), Ring (2×2), Week (4×2); they follow Day / Night

## Notes
- Android keeps detailed history for only ~1–2 weeks; this app saves every day from install onward (about 4 months), so older days fill in over time.
- Notification counts come from Android's own events plus the optional Notification access.
- Fonts: drop `Lora.ttf` / `PlayfairDisplay.ttf` into `app/src/main/assets/www/fonts/` for the exact web-app fonts.
- Needs Android 8.0+ (API 26).

## Performance & motion notes (v2.1)
- Usage data is now fetched on a background thread (`Native.query`) and posted back to the page, so taps and animations never wait on Android's usage database.
- Day history moved out of the settings file (`st_hist`, migrated automatically on first launch); unchanged days are no longer re-written on every tab switch.
- Widget redraws are debounced (goal +/- taps, theme flips) instead of spawning a thread per tap.
- Theme switch is a single GPU cross-fade (view transition) with the status/navigation bars fading in sync; no more page-wide colour transitions.
- Tap feedback: spring press on rows/buttons/tabs/bars, soft touch-following glow, selected-row highlight while the limit sheet is open, swipe-down-to-dismiss sheet.

## Blocks, game blocker & reminders (v2.2)
- **Blocks tab** – switch any app on to block it, off to unblock. First turn on *Blocking access*: Settings → Accessibility → Screen Time. The service only reads which app is on top, never screen contents. If Android says "Restricted setting" (sideloaded APK): Settings → Apps → Screen Time → ⋮ → *Allow restricted settings*, then try again.
- **Game blocker** (on by default, switch it off in Blocks): detects BGMI / PUBG Mobile, Free Fire (+ MAX) and Call of Duty Mobile. Pop-up on every app open until uninstalled (can be skipped), a notification when one gets installed, and the game is blocked from opening.
- **Reminders** – "almost at your goal" at 90 %, "goal exceeded" at 100 %, plus the existing app-limit alerts. With Blocking access on they are checked live (every ~2 min while you use the phone); otherwise every 15 min.

## Menu, Wallet, Profile & Our Apps (v2.3)
The logo in the top-left corner is now a **menu button** (three lines) that opens Wallet · Profile · Our Apps.

- **Wallet** – every finished day on which you spent **4h or less on Distracting apps** credits **₹100** (productive and "Others" time is never counted; mark your apps in Stats → *Choose productive & distracting apps*). Days with no usage data are skipped. Rewards start from the day the wallet is first opened. The page shows your balance, today's progress, streak, and the full credit / debit history. At **₹2,000** you can **Level up** (the credits are spent and logged as a debit).
- **Level themes** – each level unlocks a profile theme (Classic → Bronze Glow → Emerald Aurora → Royal Amethyst → Sunset Blaze → Ocean Nebula → Rose Gold Dream → Cosmic Legend, which repeats after level 8). The theme only styles the card at the top of the Profile page.
- **Profile** – set / change / remove your photo (picked from the gallery, cropped square and stored privately on the phone), see your level and **streak** (grows while today is within 4h of distracting apps; vanishes the moment you pass 4h), turn **notifications** on or off (this switch now silences every alert the app sends), and **Contact us** at the bottom, which opens your mail app with a message to sudeepsahoo9078@gmail.com.
- **Our Apps** – CBSH Attendance Tracker, Screen Time Tracker and MathTick. Each card opens a details sheet whose button, **Visit Our Site To Download**, opens https://cbsh-attendancetracker.vercel.app/ in the browser. To give an app its own link later, add `url:'https://…'` to its entry in the `APPS` list in `assets/www/index.html` and add the host to `Bridge.SITE_HOSTS`.

Code: `Wallet.kt` (credits, streak, levels), `Avatar.kt` (profile photo), new `Native` methods in `Bridge.kt`, the screens at the bottom of the script in `index.html`.

## Features page (v2.4)
New **Features** item in the three-line menu (between Profile and Our Apps). It shows every feature of the app as its own premium card: number, NEW badge, icon tile, title, description and tags. Cards reveal one after another as you scroll, and the whole menu now animates in/out smoothly (staggered drawer items, page slide-out on Back).
To add or edit a card, change the `FEATS` list in `assets/www/index.html`.

## v2.5 – first-run permissions, smoother motion
- **First launch** now walks through every permission one by one: Usage access (required), **Blocking access**, Notification access, Alerts. A progress bar shows how many are allowed, and the optional ones can be skipped.
- **Our Apps**: the "Heads up" note on CBSH Attendance Tracker is removed.
- **Performance**: tab switches fade out on the GPU, then build the next screen on the following frame; the option bar no longer animates layout; long app lists render in small chunks (with `content-visibility`); menu pages build after their slide-in starts; search is debounced; the installed-apps list is warmed in the background.
