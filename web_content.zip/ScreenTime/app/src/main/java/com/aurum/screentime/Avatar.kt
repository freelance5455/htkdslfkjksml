package com.aurum.screentime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File

/** Profile picture: picked from the gallery, centre-cropped to a square and kept privately in app storage. */
object Avatar {
    private const val SIZE = 512
    private fun file(c: Context) = File(c.applicationContext.filesDir, "avatar.jpg")

    fun save(c: Context, uri: Uri): Boolean = try {
        val cr = c.contentResolver
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
        var sample = 1
        while (b.outWidth / (sample * 2) >= SIZE && b.outHeight / (sample * 2) >= SIZE) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return false
        val rot = try {
            cr.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        if (rot != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = if (side > SIZE) Bitmap.createScaledBitmap(sq, SIZE, SIZE, true) else sq
        file(c).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Throwable) { false }

    fun delete(c: Context) { try { file(c).delete() } catch (e: Exception) { } }

    /** Base64 JPEG, or "" when no photo is set. */
    fun b64(c: Context): String = try {
        val f = file(c)
        if (!f.exists()) "" else Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
    } catch (e: Exception) { "" }
}
