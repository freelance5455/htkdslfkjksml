package com.aurum.screentime

import android.content.Context
import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject

/** Popular battle-royale / shooter games the "Game blocker" watches for. */
object Games {
    val PKGS: Map<String, String> = linkedMapOf(
        "com.pubg.imobile" to "BGMI",
        "com.tencent.ig" to "PUBG Mobile",
        "com.pubg.krmobile" to "PUBG Mobile (KR)",
        "com.vng.pubgmobile" to "PUBG Mobile (VN)",
        "com.rekoo.pubgm" to "PUBG Mobile (TW)",
        "com.tencent.iglite" to "PUBG Mobile Lite",
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.activision.callofduty.shooter" to "Call of Duty: Mobile",
        "com.garena.game.codm" to "Call of Duty: Mobile (Garena)",
        "com.tencent.tmgp.cod" to "Call of Duty: Mobile (CN)"
    )

    class Found(val pkg: String, val name: String, val since: Long)

    fun installed(c: Context): List<Found> {
        val pm = c.packageManager
        val out = ArrayList<Found>()
        for ((pkg, name) in PKGS) {
            try {
                @Suppress("DEPRECATION")
                val i = pm.getPackageInfo(pkg, 0)
                out.add(Found(pkg, name, i.firstInstallTime))
            } catch (e: PackageManager.NameNotFoundException) {
            } catch (e: Exception) { }
        }
        return out
    }

    /** [{pkg,name,icon}] for the pop-up inside the app (empty when the game blocker is switched off). */
    fun json(c: Context): String {
        val a = JSONArray()
        if (!Store.gameGuard(c)) return a.toString()
        for (g in installed(c)) {
            val o = JSONObject()
            o.put("pkg", g.pkg); o.put("name", g.name)
            val ic = UsageRepo.iconB64(c, g.pkg)
            if (ic.isNotEmpty()) o.put("icon", ic)
            a.put(o)
        }
        return a.toString()
    }

    /** One warning notification per install (a reinstall warns again). */
    fun warnNewInstalls(c: Context) {
        if (!Store.gameGuard(c)) return
        for (g in installed(c)) {
            val k = "gi_${g.pkg}_${g.since}"
            if (Store.flag(c, k)) continue
            Store.setFlag(c, k)
            Refresh.post(
                c, 4000 + (g.pkg.hashCode() and 0xFFFF),
                "${g.name} is installed",
                "That's a big time-sink. Uninstall it to stay on track — open Screen Time to remove it."
            )
        }
    }
}
