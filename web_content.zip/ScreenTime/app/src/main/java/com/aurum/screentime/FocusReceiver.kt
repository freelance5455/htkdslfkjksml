package com.aurum.screentime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

/** Fires when a Focus session ends while the app is closed. */
class FocusReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Refresh.post(c, 3000, "Focus session complete", "Beautifully done. Take a short break.")
        val v = c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= 26) v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120, 80, 260), -1))
    }
}
