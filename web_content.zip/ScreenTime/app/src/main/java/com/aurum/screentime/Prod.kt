package com.aurum.screentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Productive / Distracting / Others maths for the "Usage Stats" screen.
 * An app's time on a day is split by (1) the custom split the user typed for that day, otherwise
 * (2) the app's category. Whatever is not productive or distracting is "Others".
 */
object Prod {
    internal fun split(t: Long, cat: String?, cu: JSONArray?): LongArray {
        if (cu != null && cu.length() >= 2) {
            val p = cu.optLong(0).coerceIn(0L, t)
            val d = cu.optLong(1).coerceIn(0L, t - p)
            return longArrayOf(p, d, t - p - d)
        }
        return when (cat) {
            "p" -> longArrayOf(t, 0L, 0L)
            "d" -> longArrayOf(0L, t, 0L)
            else -> longArrayOf(0L, 0L, t)
        }
    }

    /** [hasData, total, productive, distracting] in ms for one day (honours categories and custom splits). */
    fun dayTotals(c: Context, n: Int): LongArray {
        val j = DayJson.dayObj(c, n)
        if (j.optBoolean("nodata", false)) return longArrayOf(0L, 0L, 0L, 0L)
        val cats = Store.cats(c)
        val sp = Store.splitsDay(c, UsageRepo.key(n))
        var t = 0L; var p = 0L; var d = 0L
        val aa = j.optJSONArray("apps")
        if (aa != null) for (i in 0 until aa.length()) {
            val x = aa.getJSONObject(i)
            val pkg = x.getString("pkg")
            val ms = x.optLong("t")
            if (ms <= 0L) continue
            val s = split(ms, cats[pkg], sp?.optJSONArray(pkg))
            t += ms; p += s[0]; d += s[1]
        }
        return longArrayOf(1L, t, p, d)
    }

    /**
     * Days from `from + count - 1` down to `from` (oldest first). Negative day numbers are the future
     * (the rest of the current week) and come back empty.
     * {days:[{ago,has,t,p,d,o,apps:[{pkg,name,t,p,d,o,cat,custom}]}], icons:{pkg:base64}}
     */
    fun build(c: Context, from: Int, count: Int): String {
        val cats = Store.cats(c)
        val days = JSONArray()
        val totals = HashMap<String, Long>()
        val names = HashMap<String, String>()
        for (n in (from + count - 1) downTo from) {
            val r = JSONObject()
            r.put("ago", n)
            var t = 0L; var p = 0L; var d = 0L; var o = 0L
            val apps = JSONArray()
            if (n < 0) {
                r.put("has", false)
            } else {
                val j = DayJson.dayObj(c, n)
                r.put("has", !j.optBoolean("nodata", false))
                val sp = Store.splitsDay(c, UsageRepo.key(n))
                val aa = j.optJSONArray("apps")
                if (aa != null) for (i in 0 until aa.length()) {
                    val x = aa.getJSONObject(i)
                    val pkg = x.getString("pkg")
                    val ms = x.optLong("t")
                    if (ms <= 0L) continue
                    val cu = sp?.optJSONArray(pkg)
                    val s = split(ms, cats[pkg], cu)
                    val e = JSONObject()
                    e.put("pkg", pkg); e.put("name", x.optString("name", pkg))
                    e.put("t", ms); e.put("p", s[0]); e.put("d", s[1]); e.put("o", s[2])
                    e.put("cat", cats[pkg] ?: "o"); e.put("custom", cu != null)
                    apps.put(e)
                    t += ms; p += s[0]; d += s[1]; o += s[2]
                    totals[pkg] = (totals[pkg] ?: 0L) + ms
                    names[pkg] = x.optString("name", pkg)
                }
            }
            r.put("t", t); r.put("p", p); r.put("d", d); r.put("o", o)
            r.put("apps", apps)
            days.put(r)
        }
        val icons = JSONObject()
        totals.entries.sortedByDescending { it.value }.take(40).forEach {
            val ic = UsageRepo.iconB64(c, it.key)
            if (ic.isNotEmpty()) icons.put(it.key, ic)
        }
        val out = JSONObject()
        out.put("days", days); out.put("icons", icons)
        return out.toString()
    }

    /** Every app used in the last 14 days (for the "choose apps" screen): [{pkg,name,t,cat,icon}] */
    fun apps(c: Context): String {
        val cats = Store.cats(c)
        val merged = DayJson.merge((0 until 14).map { DayJson.dayObj(c, it) })
        val aa = merged.optJSONArray("apps") ?: JSONArray()
        val out = JSONArray()
        val seen = HashSet<String>()
        for (i in 0 until aa.length()) {
            val x = aa.getJSONObject(i)
            val pkg = x.getString("pkg")
            if (x.optLong("t") <= 0L) continue
            seen.add(pkg)
            val e = JSONObject()
            e.put("pkg", pkg); e.put("name", x.optString("name", pkg)); e.put("t", x.optLong("t"))
            e.put("cat", cats[pkg] ?: "o")
            if (out.length() < 80) { val ic = UsageRepo.iconB64(c, pkg); if (ic.isNotEmpty()) e.put("icon", ic) }
            out.put(e)
        }
        // apps that are categorised but not used recently still need to be changeable
        for ((pkg, cat) in cats) if (pkg !in seen) {
            val e = JSONObject()
            e.put("pkg", pkg); e.put("name", UsageRepo.label(c, pkg)); e.put("t", 0L); e.put("cat", cat)
            out.put(e)
        }
        return out.toString()
    }
}
