package com.aurum.screentime

object Fmt {
    /** 3h 42m / 42m / 5h */
    fun dur(ms: Long): String {
        val m = Math.round(ms / 60000.0).toInt()
        if (m < 1) return if (ms > 0) "<1m" else "0m"
        val h = m / 60
        val mm = m % 60
        return when {
            h == 0 -> "${mm}m"
            mm == 0 -> "${h}h"
            else -> "${h}h ${mm}m"
        }
    }

    /** 3.2h */
    fun hoursShort(ms: Long): String {
        val h = ms / 3_600_000.0
        return if (h < 0.05) "0" else if (h >= 10) "${Math.round(h)}h" else String.format(java.util.Locale.US, "%.1fh", h)
    }
}
