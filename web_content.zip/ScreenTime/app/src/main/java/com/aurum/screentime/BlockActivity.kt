package com.aurum.screentime

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

/** Full-screen "go back to study" pop-up shown on top of a blocked app. */
class BlockActivity : ComponentActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark = Store.isDark(this)
        val bg = if (dark) 0xFF131209.toInt() else 0xFFFCF5E2.toInt()
        val ink = if (dark) 0xFFF4EBD3.toInt() else 0xFF1F3A1D.toInt()
        val muted = if (dark) 0xFFB8AE8E.toInt() else 0xFF6F6A52.toInt()
        val gold = if (dark) 0xFFE6B95C.toInt() else 0xFFA06818.toInt()
        val onGold = if (dark) 0xFF1B1608.toInt() else 0xFFFFF8E6.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val pkg = intent.getStringExtra("pkg") ?: ""
        val game = intent.getBooleanExtra("game", false)
        val name = UsageRepo.label(this, pkg)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val icon = ImageView(this)
        UsageRepo.iconBitmap(this, pkg, 192)?.let { icon.setImageBitmap(it) }
        root.addView(icon, LinearLayout.LayoutParams(dp(84), dp(84)))

        fun text(s: String, size: Float, color: Int, bold: Boolean, top: Int): TextView = TextView(this).apply {
            this.text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            typeface = if (bold) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            setPadding(0, dp(top), 0, 0)
        }
        root.addView(text("Go back to study", 30f, ink, true, 22))
        root.addView(
            text(
                if (game) "$name is blocked while the game blocker is on. Your future self will thank you."
                else "$name is blocked right now. Close it and get back to what matters.",
                16f, muted, false, 10
            )
        )

        val primary = Button(this).apply {
            this.text = "Go back to study"
            isAllCaps = false; textSize = 17f; setTextColor(onGold)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(16).toFloat() }
            setOnClickListener { goHome() }
        }
        root.addView(primary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(34) })

        val manage = TextView(this).apply {
            text = "Open Blocks to unblock"
            textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            setPadding(dp(12), dp(18), dp(12), dp(12))
            setOnClickListener {
                startActivity(
                    Intent(this@BlockActivity, MainActivity::class.java).putExtra("tab", "blocks")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
                finish()
            }
        }
        root.addView(manage)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goHome() }
        })
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) finish()
    }
}
