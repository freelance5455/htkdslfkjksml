package com.aurum.screentime

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Widgets {
    const val ACTION_REFRESH = "com.aurum.screentime.REFRESH"

    private class Pal(
        val dark: Boolean,
        val bgRes: Int,
        val ink: Int, val muted: Int,
        val gold: Int, val goldDeep: Int, val goldLight: Int,
        val danger: Int, val dangerDeep: Int,
        val track: Int, val tick: Int, val divider: Int
    )

    private fun pal(c: Context): Pal = if (Store.isDark(c))
        Pal(true, R.drawable.widget_bg, 0xFFF3EFE3.toInt(), 0xFFCBC0A5.toInt(),
            0xFFE6B95C.toInt(), 0xFFB8862A.toInt(), 0xFFF6DFA6.toInt(),
            0xFFF0957E.toInt(), 0xFFD9684F.toInt(), 0x22F3EFE3, 0x33E6B95C, 0x33E6B95C)
    else
        Pal(false, R.drawable.widget_bg_day, 0xFF1F3315.toInt(), 0xFF6F6A52.toInt(),
            0xFFA06818.toInt(), 0xFF8A5810.toInt(), 0xFFD2A24A.toInt(),
            0xFFC2553B.toInt(), 0xFF9E3F2A.toInt(), 0x261F3315, 0x44A06818, 0x44A06818)
    private val SERIF_BOLD: Typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    private val SERIF: Typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)

    private fun ids(c: Context, cls: Class<*>): IntArray =
        AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls))

    fun updateAll(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        val tIds = ids(c, TodayWidget::class.java)
        val rIds = ids(c, RingWidget::class.java)
        val wIds = ids(c, WeekWidget::class.java)
        if (tIds.isEmpty() && rIds.isEmpty() && wIds.isEmpty()) return

        val access = UsageRepo.hasAccess(c)
        val today = if (access) UsageRepo.day(c, 0) else null
        val goalMs = Store.goal(c) * 60000L

        if (tIds.isNotEmpty()) { val v = todayViews(c, today, goalMs, pal(c)); for (id in tIds) m.updateAppWidget(id, v) }
        if (rIds.isNotEmpty()) { val v = ringViews(c, today, goalMs, pal(c)); for (id in rIds) m.updateAppWidget(id, v) }
        if (wIds.isNotEmpty()) {
            val totals = if (access) (6 downTo 0).map { if (it == 0) today!!.total else UsageRepo.day(c, it).total } else null
            val v = weekViews(c, totals, goalMs, pal(c))
            for (id in wIds) m.updateAppWidget(id, v)
        }
    }

    fun pin(c: Context, kind: String): Boolean {
        val m = AppWidgetManager.getInstance(c)
        if (!m.isRequestPinAppWidgetSupported) return false
        val cls = when (kind) { "ring" -> RingWidget::class.java; "week" -> WeekWidget::class.java; else -> TodayWidget::class.java }
        return m.requestPinAppWidget(ComponentName(c, cls), null, null)
    }

    // ---------------------------------------------------------------- views

    private fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun refreshIntent(c: Context, cls: Class<*>, code: Int): PendingIntent = PendingIntent.getBroadcast(
        c, code, Intent(c, cls).setAction(ACTION_REFRESH),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun todayViews(c: Context, d: DayData?, goalMs: Long, pl: Pal): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_today)
        v.setOnClickPendingIntent(R.id.w_root, openApp(c))
        v.setOnClickPendingIntent(R.id.w_refresh, refreshIntent(c, TodayWidget::class.java, 1))
        val rows = intArrayOf(R.id.w_r1, R.id.w_r2, R.id.w_r3)
        val icons = intArrayOf(R.id.w_i1, R.id.w_i2, R.id.w_i3)
        val names = intArrayOf(R.id.w_n1, R.id.w_n2, R.id.w_n3)
        val times = intArrayOf(R.id.w_t1, R.id.w_t2, R.id.w_t3)
        v.setInt(R.id.w_root, "setBackgroundResource", pl.bgRes)
        v.setTextColor(R.id.w_label, pl.gold)
        v.setTextColor(R.id.w_time, pl.ink)
        v.setInt(R.id.w_div, "setBackgroundColor", pl.divider)
        v.setInt(R.id.w_refresh, "setColorFilter", pl.gold)
        for (i in 0..2) { v.setTextColor(names[i], pl.ink); v.setTextColor(times[i], pl.gold) }

        if (d == null) {
            v.setTextViewText(R.id.w_time, "—")
            v.setTextViewText(R.id.w_sub, "Tap to grant usage access")
            v.setTextColor(R.id.w_sub, pl.muted)
            v.setImageViewBitmap(R.id.w_bar, barBitmap(0f, false, pl))
            for (r in rows) v.setViewVisibility(r, View.INVISIBLE)
            return v
        }
        val frac = d.total.toFloat() / goalMs
        val over = frac > 1f
        v.setTextViewText(R.id.w_time, Fmt.dur(d.total))
        v.setImageViewBitmap(R.id.w_bar, barBitmap(frac, over, pl))
        v.setTextViewText(
            R.id.w_sub,
            if (over) "Over goal by ${Fmt.dur(d.total - goalMs)}"
            else "${(frac * 100).toInt()}% of ${Fmt.dur(goalMs)} goal · ${Fmt.dur(goalMs - d.total)} left"
        )
        v.setTextColor(R.id.w_sub, if (over) pl.danger else pl.muted)
        for (i in 0..2) {
            val a = d.apps.getOrNull(i)
            if (a == null) { v.setViewVisibility(rows[i], View.INVISIBLE); continue }
            v.setViewVisibility(rows[i], View.VISIBLE)
            val bmp = UsageRepo.iconBitmap(c, a.pkg, 64)
            if (bmp != null) v.setImageViewBitmap(icons[i], bmp)
            v.setTextViewText(names[i], UsageRepo.label(c, a.pkg))
            v.setTextViewText(times[i], Fmt.dur(a.ms))
        }
        return v
    }

    private fun ringViews(c: Context, d: DayData?, goalMs: Long, pl: Pal): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_ring)
        v.setOnClickPendingIntent(R.id.w_root, openApp(c))
        v.setInt(R.id.w_root, "setBackgroundResource", pl.bgRes)
        val bmp = if (d == null) ringBitmap(0f, "—", "grant access", false, pl)
        else {
            val f = d.total.toFloat() / goalMs
            ringBitmap(f, Fmt.dur(d.total), "of ${Fmt.dur(goalMs)} goal", f > 1f, pl)
        }
        v.setImageViewBitmap(R.id.w_ring, bmp)
        return v
    }

    private fun weekViews(c: Context, totals: List<Long>?, goalMs: Long, pl: Pal): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_week)
        v.setOnClickPendingIntent(R.id.w_root, openApp(c))
        v.setOnClickPendingIntent(R.id.w_refresh, refreshIntent(c, WeekWidget::class.java, 3))
        v.setInt(R.id.w_root, "setBackgroundResource", pl.bgRes)
        v.setTextColor(R.id.w_label, pl.gold)
        v.setTextColor(R.id.w_avg, pl.muted)
        v.setInt(R.id.w_refresh, "setColorFilter", pl.gold)
        if (totals == null) {
            v.setTextViewText(R.id.w_avg, "grant access")
            v.setImageViewBitmap(R.id.w_chart, weekBitmap(List(7) { 0L }, goalMs, pl))
        } else {
            v.setTextViewText(R.id.w_avg, "avg ${Fmt.dur(totals.sum() / 7)}")
            v.setImageViewBitmap(R.id.w_chart, weekBitmap(totals, goalMs, pl))
        }
        return v
    }

    // -------------------------------------------------------------- bitmaps

    private fun p(color: Int, style: Paint.Style = Paint.Style.FILL) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; this.style = style }

    private fun barBitmap(frac: Float, over: Boolean, pl: Pal): Bitmap {
        val w = 640; val h = 16
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val r = h / 2f
        cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, p(pl.track))
        val fw = (w * frac.coerceIn(0f, 1f)).coerceAtLeast(if (frac > 0f) h.toFloat() else 0f)
        if (fw > 0f) {
            val fill = p(pl.gold)
            fill.shader = if (over) LinearGradient(0f, 0f, w.toFloat(), 0f, pl.dangerDeep, pl.danger, Shader.TileMode.CLAMP)
            else LinearGradient(0f, 0f, w.toFloat(), 0f, pl.goldDeep, pl.goldLight, Shader.TileMode.CLAMP)
            cv.drawRoundRect(RectF(0f, 0f, fw, h.toFloat()), r, r, fill)
        }
        return b
    }

    private fun ringBitmap(frac: Float, big: String, small: String, over: Boolean, pl: Pal): Bitmap {
        val s = 420
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val stroke = 34f
        val pad = stroke / 2f + 14f
        val rect = RectF(pad, pad, s - pad, s - pad)
        val c0 = s / 2f

        // fine watch ticks
        val tick = p(pl.tick, Paint.Style.STROKE).apply { strokeWidth = 3f }
        for (i in 0 until 60) {
            val ang = Math.toRadians(i * 6.0)
            val r1 = c0 - 4f
            val r2 = c0 - if (i % 5 == 0) 13f else 8f
            cv.drawLine(
                (c0 + r1 * Math.sin(ang)).toFloat(), (c0 - r1 * Math.cos(ang)).toFloat(),
                (c0 + r2 * Math.sin(ang)).toFloat(), (c0 - r2 * Math.cos(ang)).toFloat(), tick
            )
        }

        cv.drawArc(rect, 0f, 360f, false, p(pl.track, Paint.Style.STROKE).apply { strokeWidth = stroke })
        val prog = p(pl.gold, Paint.Style.STROKE).apply { strokeWidth = stroke; strokeCap = Paint.Cap.ROUND }
        if (over) prog.color = pl.danger else {
            val sg = SweepGradient(c0, c0, intArrayOf(pl.goldDeep, pl.gold, pl.goldLight), null)
            val m = Matrix(); m.postRotate(-90f, c0, c0); sg.setLocalMatrix(m)
            prog.shader = sg
        }
        val sweep = 360f * frac.coerceIn(0f, 1f)
        if (sweep > 0.5f) cv.drawArc(rect, -90f, sweep, false, prog)

        val label = p(pl.gold).apply { typeface = SERIF_BOLD; textSize = 24f; letterSpacing = 0.2f; textAlign = Paint.Align.CENTER }
        cv.drawText("TODAY", c0, c0 - 62f, label)
        val bigP = p(pl.ink).apply { typeface = SERIF_BOLD; textSize = 96f; textAlign = Paint.Align.CENTER }
        while (bigP.measureText(big) > s * 0.56f && bigP.textSize > 30f) bigP.textSize -= 4f
        cv.drawText(big, c0, c0 + 24f, bigP)
        val sm = p(pl.muted).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC); textSize = 28f; textAlign = Paint.Align.CENTER }
        while (sm.measureText(small) > s * 0.5f && sm.textSize > 14f) sm.textSize -= 2f
        cv.drawText(small, c0, c0 + 74f, sm)
        return b
    }

    private fun weekBitmap(totals: List<Long>, goalMs: Long, pl: Pal): Bitmap {
        val w = 760; val h = 300
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val maxV = maxOf((goalMs * 1.2f).toLong(), (totals.maxOrNull() ?: 0L) + 1)
        val top = 34f; val base = 246f
        val area = base - top
        val slot = w / 7f
        val barW = slot * 0.5f
        val fmtDay = SimpleDateFormat("EEE", Locale.getDefault())

        // goal line
        val gy = base - area * (goalMs.toFloat() / maxV)
        val dash = p(pl.tick, Paint.Style.STROKE).apply { strokeWidth = 2f; pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f) }
        val line = Path(); line.moveTo(0f, gy); line.lineTo(w.toFloat(), gy)
        cv.drawPath(line, dash)

        for (i in 0 until 7) {
            val daysAgo = 6 - i
            val ms = totals.getOrElse(i) { 0L }
            val cx = slot * i + slot / 2f
            val bh = (area * (ms.toFloat() / maxV)).coerceAtLeast(if (ms > 0) 8f else 3f)
            val isToday = daysAgo == 0
            val over = ms > goalMs
            val fill = p(if (over) pl.danger else pl.gold)
            fill.alpha = if (isToday) 255 else 150
            cv.drawRoundRect(RectF(cx - barW / 2, base - bh, cx + barW / 2, base), 10f, 10f, fill)

            val val_ = p(if (isToday) pl.ink else pl.muted).apply { typeface = SERIF_BOLD; textSize = 22f; textAlign = Paint.Align.CENTER }
            cv.drawText(Fmt.hoursShort(ms), cx, base - bh - 10f, val_)

            val day = fmtDay.format(Date(UsageRepo.dayStart(daysAgo))).take(3)
            val lab = p(if (isToday) pl.gold else pl.muted).apply { typeface = if (isToday) SERIF_BOLD else SERIF; textSize = 24f; textAlign = Paint.Align.CENTER }
            cv.drawText(day, cx, 282f, lab)
        }
        return b
    }
}

abstract class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val pr = goAsync()
        Thread { try { Widgets.updateAll(context) } finally { pr.finish() } }.start()
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Widgets.ACTION_REFRESH) {
            val pr = goAsync()
            Thread { try { Refresh.run(context) } finally { pr.finish() } }.start()
        } else super.onReceive(context, intent)
    }

    override fun onEnabled(context: Context) { Refresh.schedule(context) }
}

class TodayWidget : BaseWidget()
class RingWidget : BaseWidget()
class WeekWidget : BaseWidget()
