package com.aurum.screentime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.animation.ValueAnimator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/** Everything the web UI can ask the phone. Exposed to JS as `Native`. */
class Bridge(private val act: MainActivity) {
    companion object {
        const val CONTACT_EMAIL = "sudeepsahoo9078@gmail.com"
        val SITE_HOSTS = setOf("cbsh-attendancetracker.vercel.app")
    }
    private val c: Context = act.applicationContext

    // usage queries run here, off the JS thread, and are posted back through window.__nr(id, json)
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "st-query").apply { isDaemon = true } }
    private val widgetsIo = Executors.newSingleThreadExecutor { r -> Thread(r, "st-widgets").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    private val widgetJob = Runnable { widgetsIo.execute { try { Refresh.run(c) } catch (e: Exception) { } } }
    private var barColor = 0
    private var barAnim: ValueAnimator? = null

    private fun notifOk(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun listenerOk(): Boolean = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    @JavascriptInterface
    fun getState(): String {
        val o = JSONObject()
        o.put("access", UsageRepo.hasAccess(c))
        o.put("goal", Store.goal(c))
        o.put("notify", Store.notify(c))
        o.put("haptics", Store.haptics(c))
        o.put("notifPerm", notifOk())
        o.put("listener", listenerOk())
        o.put("theme", Store.theme(c))
        o.put("systemDark", (c.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES)
        o.put("limits", JSONObject(Store.limits(c) as Map<*, *>))
        o.put("cats", JSONObject(Store.cats(c) as Map<*, *>))
        o.put("blocked", JSONArray(Store.blocked(c).toList()))
        o.put("gameGuard", Store.gameGuard(c))
        o.put("blockAccess", Blocks.accessEnabled(c))
        return o.toString()
    }

    /** Totals + hourly + per-app stats for `count` days starting `from` days ago (count=1 -> a single day). */
    @JavascriptInterface
    fun getPeriod(from: Int, count: Int): String {
        val list = (0 until count).map { DayJson.dayObj(c, from + it) }
        val o = DayJson.merge(list)
        o.put("ago", from); o.put("count", count)
        return DayJson.decorate(c, o).toString()
    }

    /**
     * Non-blocking version of getPeriod / getRange / getHeat. The UI used to call those synchronously,
     * freezing the page (and every animation) while Android's usage database was read.
     */
    @JavascriptInterface
    fun query(id: Int, name: String, args: String) {
        io.execute {
            var out: String? = null
            try {
                val a = JSONArray(args)
                out = when (name) {
                    "getPeriod" -> getPeriod(a.getInt(0), a.getInt(1))
                    "getRange" -> getRange(a.getInt(0), a.getInt(1))
                    "getHeat" -> getHeat()
                    "getProd" -> Prod.build(c, a.getInt(0), a.getInt(1))
                    "getApps" -> Prod.apps(c)
                    "getInstalled" -> Blocks.installed(c)
                    "getWallet" -> Wallet.sync(c).toString()
                    "levelUp" -> Wallet.levelUp(c).toString()
                    "getAvatar" -> JSONObject().put("img", Avatar.b64(c)).toString()
                    else -> null
                }
            } catch (e: Throwable) { }
            val js = if (out != null) "window.__nr($id,${JSONObject.quote(out)})" else "window.__nr($id,null,'error')"
            act.runOnUiThread { if (!act.isDestroyed) act.web.evaluateJavascript(js, null) }
        }
    }

    /** Per-day totals (oldest first): ago,label,full,has,t,l,n,u,s */
    @JavascriptInterface
    fun getRange(from: Int, count: Int): String = DayJson.summary(c, from, count).toString()

    /** Daily screen time for the last 119 days (index = days ago, -1 = unknown) for the heat map. */
    @JavascriptInterface
    fun getHeat(): String {
        val a = JSONArray()
        for (n in 0 until 119) {
            val v = if (n <= 14) DayJson.dayObj(c, n).let { if (it.optBoolean("nodata", false)) -1L else it.optLong("t") }
            else Store.dayMs(c, UsageRepo.key(n))
            a.put(v)
        }
        return a.toString()
    }

    @JavascriptInterface fun getLabel(pkg: String): String = UsageRepo.label(c, pkg)
    @JavascriptInterface fun getIcon(pkg: String): String = UsageRepo.iconB64(c, pkg)

    @JavascriptInterface fun setGoal(min: Int) { Store.setGoal(c, min); refreshWidgets() }
    @JavascriptInterface fun setNotify(v: Boolean) { Store.setNotify(c, v) }
    @JavascriptInterface fun setHaptics(v: Boolean) { Store.setHaptics(c, v) }
    @JavascriptInterface fun setLimit(pkg: String, min: Int) { Store.setLimit(c, pkg, min) }

    // ---- Blocks / game blocker ----
    @JavascriptInterface fun setBlocked(pkg: String, on: Boolean) { Store.setBlocked(c, pkg, on) }
    @JavascriptInterface fun setGameGuard(v: Boolean) { Store.setGameGuard(c, v) }

    /** Installed games (BGMI, Free Fire, Call of Duty...) as [{pkg,name,icon}]; empty when the game blocker is off. */
    @JavascriptInterface fun getGames(): String = try { Games.json(c) } catch (e: Exception) { "[]" }

    /** Opens Android's own uninstall dialog (only for the known game packages). */
    @JavascriptInterface
    fun uninstall(pkg: String): Boolean {
        if (!Games.PKGS.containsKey(pkg)) return false
        act.runOnUiThread {
            try { act.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) } catch (e: Exception) { }
        }
        return true
    }

    // ---- profile photo, support e-mail, website ----
    @JavascriptInterface fun pickAvatar() { act.runOnUiThread { act.pickImage() } }
    @JavascriptInterface fun removeAvatar() { Avatar.delete(c) }

    /** Opens the user's mail app with a new message to the developer already addressed. */
    @JavascriptInterface
    fun openMail(subject: String, body: String): Boolean = try {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(CONTACT_EMAIL))
            .putExtra(Intent.EXTRA_SUBJECT, subject)
            .putExtra(Intent.EXTRA_TEXT, body + "\n\nAndroid ${Build.VERSION.RELEASE} · ${Build.MODEL}")
        act.startActivity(i); true
    } catch (e: Exception) { false }

    /** Opens one of our own pages in the browser (https + allow-listed host only). */
    @JavascriptInterface
    fun openUrl(url: String): Boolean = try {
        val u = Uri.parse(url)
        val host = u.host ?: ""
        if (u.scheme != "https" || host !in SITE_HOSTS) false
        else { act.startActivity(Intent(Intent.ACTION_VIEW, u)); true }
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun openAccessibilitySettings(): Boolean = try {
        act.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    /** Tab the app was asked to open (e.g. "blocks" from the block screen); returned once. */
    @JavascriptInterface
    fun takeTab(): String { val t = act.pendingTab ?: ""; act.pendingTab = null; return t }

    /** Usage Stats: "p" = productive, "d" = distracting, anything else = Others. */
    @JavascriptInterface fun setCat(pkg: String, cat: String) { Store.setCat(c, pkg, cat) }

    /** Custom split for one app on the day `ago` days back (minutes). The remainder counts as Others. */
    @JavascriptInterface
    fun setSplit(ago: Int, pkg: String, productiveMin: Int, distractingMin: Int) {
        if (ago < 0) return
        Store.setSplit(c, UsageRepo.key(ago), pkg, productiveMin.coerceAtLeast(0) * 60_000L, distractingMin.coerceAtLeast(0) * 60_000L)
    }

    @JavascriptInterface
    fun clearSplit(ago: Int, pkg: String) { if (ago >= 0) Store.clearSplit(c, UsageRepo.key(ago), pkg) }

    /** Saves the theme choice, fades the system bars to the new colour and (debounced) redraws widgets. */
    @JavascriptInterface
    fun setTheme(mode: String, dark: Boolean) {
        Store.setTheme(c, mode)
        act.runOnUiThread {
            val to = if (dark) 0xFF131209.toInt() else 0xFFFCF5E2.toInt()
            val from = barColor
            barAnim?.cancel()
            if (from == 0 || from == to) {
                barColor = to
                act.window.statusBarColor = to
                act.window.navigationBarColor = to
            } else {
                barAnim = ValueAnimator.ofArgb(from, to).apply {
                    duration = 420
                    addUpdateListener {
                        barColor = it.animatedValue as Int
                        act.window.statusBarColor = barColor
                        act.window.navigationBarColor = barColor
                    }
                    start()
                }
            }
            val ctl = WindowInsetsControllerCompat(act.window, act.window.decorView)
            ctl.isAppearanceLightStatusBars = !dark
            ctl.isAppearanceLightNavigationBars = !dark
            act.web.setBackgroundColor(to)
        }
        refreshWidgets()
    }

    /** Coalesces bursts (goal +/- taps, theme flips) into one widget redraw on a background thread. */
    @JavascriptInterface
    fun refreshWidgets() {
        main.removeCallbacks(widgetJob)
        main.postDelayed(widgetJob, 900)
    }

    @JavascriptInterface
    fun openUsageSettings(): Boolean {
        return try {
            val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + c.packageName))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); act.startActivity(i); true
        } catch (e: Exception) {
            try {
                act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
            } catch (e2: Exception) { false }
        }
    }

    @JavascriptInterface
    fun openListenerSettings(): Boolean = try {
        act.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun requestNotifPermission() {
        act.runOnUiThread {
            if (Build.VERSION.SDK_INT >= 33 && !notifOk() && !Store.askedNotif(c)) {
                Store.setAskedNotif(c)
                act.askNotifications()
            } else {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { act.startActivity(i) } catch (e: Exception) { }
            }
        }
    }

    @JavascriptInterface
    fun pinWidget(kind: String): Boolean {
        var ok = false
        val latch = java.util.concurrent.CountDownLatch(1)
        act.runOnUiThread { try { ok = Widgets.pin(c, kind) } catch (e: Exception) { } finally { latch.countDown() } }
        latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        return ok
    }

    @JavascriptInterface
    fun haptic(kind: String) {
        if (!Store.haptics(c)) return
        act.runOnUiThread {
            val k = when (kind) {
                "success" -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
                "click" -> HapticFeedbackConstants.VIRTUAL_KEY
                else -> HapticFeedbackConstants.CLOCK_TICK
            }
            act.web.performHapticFeedback(k)
        }
    }

    private fun focusIntent(): PendingIntent = PendingIntent.getBroadcast(
        c, 77, Intent(c, FocusReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    @JavascriptInterface
    fun scheduleFocus(endMs: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endMs, focusIntent())
    }

    @JavascriptInterface
    fun cancelFocus() {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(focusIntent())
    }
}
