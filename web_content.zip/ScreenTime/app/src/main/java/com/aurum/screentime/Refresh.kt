package com.aurum.screentime

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class UsageWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Refresh.run(applicationContext) } catch (e: Exception) { /* try again next cycle */ }
        return Result.success()
    }
}

object Refresh {
    const val CHANNEL = "st_alerts"

    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Screen time alerts", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    fun schedule(c: Context) {
        val req = PeriodicWorkRequest.Builder(UsageWorker::class.java, 15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("st_refresh", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** Recompute today, store it, fire alerts and redraw every widget. */
    fun run(c: Context) {
        if (UsageRepo.hasAccess(c)) {
            val d = UsageRepo.day(c, 0)
            DayJson.persist(c, 0, d)
            checkAlerts(c, d)
        }
        try { Games.warnNewInstalls(c) } catch (e: Exception) { }
        Widgets.updateAll(c)
    }

    /** Light check used while the phone is in use: only the goal / limit reminders, no widget redraw. */
    fun live(c: Context) {
        if (!UsageRepo.hasAccess(c)) return
        checkAlerts(c, UsageRepo.day(c, 0))
    }

    private fun checkAlerts(c: Context, d: DayData) {
        if (!Store.notify(c)) return
        val day = UsageRepo.key(0)
        val goal = Store.goal(c) * 60000L

        if (d.total >= goal) {
            if (!Store.flag(c, "n100_$day")) {
                Store.setFlag(c, "n100_$day"); Store.setFlag(c, "n90_$day")
                post(c, 1001, "Daily goal exceeded", "You've used ${Fmt.dur(d.total)} of screen time today, over your ${Fmt.dur(goal)} goal. Put the phone down.")
            }
        } else if (d.total >= goal * 0.9 && !Store.flag(c, "n90_$day")) {
            Store.setFlag(c, "n90_$day")
            post(c, 1000, "Almost at your daily goal", "Only ${Fmt.dur(goal - d.total)} left before you reach your ${Fmt.dur(goal)} goal.")
        }

        for ((pkg, min) in Store.limits(c)) {
            val ms = d.apps.firstOrNull { it.pkg == pkg }?.ms ?: 0L
            val k = "nl_${pkg}_$day"
            if (ms >= min * 60000L && !Store.flag(c, k)) {
                Store.setFlag(c, k)
                post(c, 2000 + (pkg.hashCode() and 0xFFFF), "${UsageRepo.label(c, pkg)} limit reached",
                    "You've spent ${Fmt.dur(ms)} on ${UsageRepo.label(c, pkg)} today (limit ${Fmt.dur(min * 60000L)}).")
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun post(c: Context, id: Int, title: String, text: String) {
        if (!Store.notify(c)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        createChannel(c)
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFE6B95C.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(c).notify(id, n) } catch (e: SecurityException) { }
    }
}
