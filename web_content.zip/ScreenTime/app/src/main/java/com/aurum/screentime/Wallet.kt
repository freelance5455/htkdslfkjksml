package com.aurum.screentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Credits wallet.
 *  - Every finished day on which distracting-app time was 4h or less pays DAILY credits
 *    (productive and "other" time is never counted).
 *  - LEVEL_COST credits buy the next level, which unlocks a new profile theme.
 *  - Rewards start from the day the wallet is first opened; days with no usage data are skipped.
 */
object Wallet {
    const val DAILY = 100
    const val LEVEL_COST = 2000
    const val LIMIT_MS = 4 * 3_600_000L
    private const val MAX_HIST = 300

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("st_wallet", Context.MODE_PRIVATE)

    @Synchronized
    fun sync(c: Context): JSONObject {
        val p = sp(c)
        val today = UsageRepo.key(0)
        val e = p.edit()
        val saved = p.getString("start", null)
        val start: String = saved ?: today
        if (saved == null) e.putString("start", start)
        var last = p.getString("last", "") ?: ""
        var bal = p.getInt("bal", 0)
        var streak = p.getInt("streak", 0)
        var best = p.getInt("best", 0)
        var earned = p.getInt("earned", 0)
        val hist = JSONArray(p.getString("hist", "[]") ?: "[]")
        var newAmt = 0; var newDays = 0

        if (UsageRepo.hasAccess(c)) {
            val pending = (1..45).filter { val k = UsageRepo.key(it); k >= start && k > last }.sortedDescending() // oldest first
            for (n in pending) {
                val k = UsageRepo.key(n)
                val tot = Prod.dayTotals(c, n)
                if (tot[0] == 1L) {
                    if (tot[3] <= LIMIT_MS) {
                        bal += DAILY; earned += DAILY; streak += 1; if (streak > best) best = streak
                        newAmt += DAILY; newDays += 1
                        val h = JSONObject()
                        h.put("ts", UsageRepo.dayStart(n - 1)); h.put("type", "credit"); h.put("amt", DAILY)
                        h.put("day", k); h.put("d", tot[3])
                        hist.put(h)
                    } else streak = 0
                }
                last = k
            }
        }
        e.putString("last", last).putInt("bal", bal).putInt("streak", streak).putInt("best", best).putInt("earned", earned)
        // newest first, capped
        val list = ArrayList<JSONObject>()
        for (i in 0 until hist.length()) list.add(hist.getJSONObject(i))
        list.sortByDescending { it.optLong("ts") }
        val out = JSONArray(); list.take(MAX_HIST).forEach { out.put(it) }
        e.putString("hist", out.toString()).apply()

        val td = if (UsageRepo.hasAccess(c)) Prod.dayTotals(c, 0) else longArrayOf(0L, 0L, 0L, 0L)
        val o = JSONObject()
        o.put("bal", bal); o.put("level", p.getInt("level", 1)); o.put("cost", LEVEL_COST); o.put("daily", DAILY)
        o.put("limit", LIMIT_MS); o.put("earned", earned); o.put("best", best); o.put("start", start)
        o.put("streak", streak)
        o.put("todayHas", td[0] == 1L); o.put("todayT", td[1]); o.put("todayP", td[2]); o.put("todayD", td[3])
        // streak shown live: today counts while it is still within the limit, and vanishes the moment it is not
        o.put("liveStreak", if (td[0] == 1L && td[3] <= LIMIT_MS) streak + 1 else 0)
        o.put("newAmt", newAmt); o.put("newDays", newDays)
        o.put("hist", out)
        return o
    }

    @Synchronized
    fun levelUp(c: Context): JSONObject {
        val p = sp(c)
        val bal = p.getInt("bal", 0)
        val ok = bal >= LEVEL_COST
        if (ok) {
            val lv = p.getInt("level", 1) + 1
            val hist = JSONArray(p.getString("hist", "[]") ?: "[]")
            val h = JSONObject()
            h.put("ts", System.currentTimeMillis()); h.put("type", "debit"); h.put("amt", LEVEL_COST); h.put("level", lv)
            val out = JSONArray(); out.put(h)
            for (i in 0 until hist.length()) if (out.length() < MAX_HIST) out.put(hist.getJSONObject(i))
            p.edit().putInt("bal", bal - LEVEL_COST).putInt("level", lv).putString("hist", out.toString()).apply()
        }
        return sync(c).put("ok", ok)
    }
}
