package com.aurum.screentime

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar

/** Counts notifications per app (only the number — never their content). */
class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            if (sbn.isOngoing) return
            val n = sbn.notification
            if (n.flags and android.app.Notification.FLAG_GROUP_SUMMARY != 0) return
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            Store.addNotif(applicationContext, UsageRepo.key(0), sbn.packageName, hour)
        } catch (e: Exception) { }
    }
}
