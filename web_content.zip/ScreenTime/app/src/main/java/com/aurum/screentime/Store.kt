package com.aurum.screentime

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("st_prefs", Context.MODE_PRIVATE)

    /**
     * Day history lives in its own file. It used to share "st_prefs" with the settings, so every
     * toggle / goal tap / history write re-serialised several hundred KB of XML (the main cause of lag).
     */
    @Volatile private var moved = false
    private fun hp(c: Context): SharedPreferences {
        val h = c.applicationContext.getSharedPreferences("st_hist", Context.MODE_PRIVATE)
        if (!moved) synchronized(this) {
            if (!moved) {
                val old = sp(c)
                if (!old.getBoolean("hist_moved", false)) {
                    val he = h.edit()
                    val oe = old.edit()
                    for ((k, v) in old.all) {
                        if (v is String && (k.startsWith("dj_") || k.startsWith("nc_"))) { he.putString(k, v); oe.remove(k) }
                        else if (v is Long && k.startsWith("day_")) { he.putLong(k, v); oe.remove(k) }
                    }
                    he.commit()
                    oe.putBoolean("hist_moved", true)
                    oe.apply()
                }
                moved = true
            }
        }
        return h
    }
    private var prunedFor = ""

    fun goal(c: Context): Int = sp(c).getInt("goal", 240)
    fun setGoal(c: Context, minutes: Int) { sp(c).edit().putInt("goal", minutes.coerceIn(15, 1440)).apply() }

    fun notify(c: Context): Boolean = sp(c).getBoolean("notify", true)
    fun setNotify(c: Context, v: Boolean) { sp(c).edit().putBoolean("notify", v).apply() }

    fun haptics(c: Context): Boolean = sp(c).getBoolean("haptics", true)
    fun setHaptics(c: Context, v: Boolean) { sp(c).edit().putBoolean("haptics", v).apply() }

    fun askedNotif(c: Context): Boolean = sp(c).getBoolean("asked_notif", false)
    fun setAskedNotif(c: Context) { sp(c).edit().putBoolean("asked_notif", true).apply() }

    /** "auto" | "day" | "night" */
    fun theme(c: Context): String = sp(c).getString("theme", "auto") ?: "auto"
    fun setTheme(c: Context, t: String) { sp(c).edit().putString("theme", t).apply() }
    fun isDark(c: Context): Boolean = when (theme(c)) {
        "day" -> false
        "night" -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun limits(c: Context): Map<String, Int> {
        val o = JSONObject(sp(c).getString("limits", "{}") ?: "{}")
        val m = LinkedHashMap<String, Int>()
        val it = o.keys()
        while (it.hasNext()) { val k = it.next(); m[k] = o.optInt(k) }
        return m
    }

    fun setLimit(c: Context, pkg: String, minutes: Int) {
        val o = JSONObject(sp(c).getString("limits", "{}") ?: "{}")
        if (minutes <= 0) o.remove(pkg) else o.put(pkg, minutes)
        sp(c).edit().putString("limits", o.toString()).apply()
    }

    // ---- saved history (Android only keeps ~1-2 weeks of raw events, so we keep our own) ----
    fun saveDay(c: Context, key: String, ms: Long) {
        val h = hp(c)
        if (h.getLong("day_$key", -2L) != ms) h.edit().putLong("day_$key", ms).apply()
    }
    fun dayMs(c: Context, key: String): Long = hp(c).getLong("day_$key", -1L)
    fun dayJson(c: Context, key: String): String? = hp(c).getString("dj_$key", null)

    /** Writes only when the JSON actually changed; old days are pruned at most once per calendar day. */
    fun putDayJson(c: Context, key: String, json: String) {
        val h = hp(c)
        if (h.getString("dj_$key", null) == json) return
        val e = h.edit()
        e.putString("dj_$key", json)
        val today = UsageRepo.key(0)
        if (prunedFor != today) {
            prunedFor = today
            val cutoff = UsageRepo.key(130) // keep roughly 4 months
            for (k in h.all.keys) {
                if (k.startsWith("dj_") && k.substring(3) < cutoff) e.remove(k)
                if (k.startsWith("day_") && k.substring(4) < cutoff) e.remove(k)
                if (k.startsWith("nc_") && k.substring(3) < cutoff) e.remove(k)
                if (k.startsWith("sp_") && k.substring(3) < cutoff) e.remove(k)
            }
        }
        e.apply()
    }

    // ---- notification counts collected by NotifListener ----
    @Synchronized
    fun addNotif(c: Context, key: String, pkg: String, hour: Int) {
        val h = hp(c)
        val o = JSONObject(h.getString("nc_$key", "{}") ?: "{}")
        o.put(pkg, o.optInt(pkg) + 1)
        val hrs = o.optJSONArray("_h") ?: JSONArray().also { a -> for (i in 0 until 24) a.put(0) }
        hrs.put(hour, hrs.optInt(hour) + 1)
        o.put("_h", hrs)
        h.edit().putString("nc_$key", o.toString()).apply()
    }

    fun notifDay(c: Context, key: String): JSONObject? =
        hp(c).getString("nc_$key", null)?.let { JSONObject(it) }

    // ---- productive / distracting categories ----
    /** pkg -> "p" (productive) | "d" (distracting). Apps not in the map count as "Others". */
    fun cats(c: Context): Map<String, String> {
        val o = JSONObject(sp(c).getString("cats", "{}") ?: "{}")
        val m = LinkedHashMap<String, String>()
        val it = o.keys()
        while (it.hasNext()) { val k = it.next(); m[k] = o.optString(k) }
        return m
    }

    fun setCat(c: Context, pkg: String, cat: String) {
        val o = JSONObject(sp(c).getString("cats", "{}") ?: "{}")
        if (cat == "p" || cat == "d") o.put(pkg, cat) else o.remove(pkg)
        sp(c).edit().putString("cats", o.toString()).apply()
    }

    /** Custom split for one app on one day: {pkg:[productiveMs, distractingMs]}; the rest counts as Others. */
    fun splitsDay(c: Context, key: String): JSONObject? =
        hp(c).getString("sp_$key", null)?.let { JSONObject(it) }

    @Synchronized
    fun setSplit(c: Context, key: String, pkg: String, pMs: Long, dMs: Long) {
        val h = hp(c)
        val o = JSONObject(h.getString("sp_$key", "{}") ?: "{}")
        o.put(pkg, JSONArray().put(pMs).put(dMs))
        h.edit().putString("sp_$key", o.toString()).apply()
    }

    @Synchronized
    fun clearSplit(c: Context, key: String, pkg: String) {
        val h = hp(c)
        val o = JSONObject(h.getString("sp_$key", "{}") ?: "{}")
        o.remove(pkg)
        val e = h.edit()
        if (o.length() == 0) e.remove("sp_$key") else e.putString("sp_$key", o.toString())
        e.apply()
    }

    fun flag(c: Context, k: String): Boolean = sp(c).getBoolean("f_$k", false)
    fun setFlag(c: Context, k: String) { sp(c).edit().putBoolean("f_$k", true).apply() }

    // ---- blocks ----
    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet()) ?: emptySet()
    fun setBlocked(c: Context, pkg: String, on: Boolean) {
        val s = HashSet(blocked(c))
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("blocked", s).apply()
    }
    fun gameGuard(c: Context): Boolean = sp(c).getBoolean("game_guard", true)
    fun setGameGuard(c: Context, v: Boolean) { sp(c).edit().putBoolean("game_guard", v).apply() }
}
