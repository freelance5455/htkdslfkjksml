package com.aurum.screentime

import android.app.Application

class StApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Refresh.createChannel(this)
        Refresh.schedule(this)
    }
}
