package com.aurum.screentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** JSON shape shared with the web UI. All app entries: {pkg,name,t(ms),l(launches),n(notifications)} */
object DayJson {
    private fun arr(a: LongArray) = JSONArray().also { j -> a.forEach { j.put(it) } }
    private fun arr(a: IntArray) = JSONArray().also { j -> a.forEach { j.put(it) } }

    fun toJson(c: Context, d: DayData): JSONObject {
        val o = JSONObject()
        o.put("t", d.total); o.put("s", d.pickups); o.put("u", d.unlocks)
        o.put("l", d.launches); o.put("n", d.notifs)
        o.put("longest", d.longest); o.put("first", d.first)
        o.put("sess", arr(d.sessions))
        val h = JSONObject()
        h.put("t", arr(d.hourly)); h.put("u", arr(d.unlockHourly)); h.put("l", arr(d.launchHourly)); h.put("n", arr(d.notifHourly))
        o.put("h", h)
        val apps = JSONArray()
        for (a in d.apps) {
            val x = JSONObject()
            x.put("pkg", a.pkg); x.put("name", UsageRepo.label(c, a.pkg))
            x.put("t", a.ms); x.put("l", a.launches); x.put("n", a.notifs)
            apps.put(x)
        }
        o.put("apps", apps)
        return o
    }

    fun empty(): JSONObject {
        val o = JSONObject()
        o.put("t", 0L); o.put("s", 0); o.put("u", 0); o.put("l", 0); o.put("n", 0)
        o.put("longest", 0L); o.put("first", 0L)
        o.put("sess", arr(IntArray(5)))
        val h = JSONObject()
        for (k in arrayOf("t", "u", "l", "n")) h.put(k, arr(IntArray(24)))
        o.put("h", h)
        o.put("apps", JSONArray())
        o.put("nodata", true)
        return o
    }

    /** Save a finished/ongoing day so it survives after Android drops the raw events. */
    fun persist(c: Context, n: Int, d: DayData): JSONObject {
        val j = toJson(c, d)
        val key = UsageRepo.key(n)
        Store.putDayJson(c, key, j.toString())
        Store.saveDay(c, key, d.total)
        return j
    }

    /** Short-lived cache so switching tabs doesn't re-parse / re-build 14-49 day objects every time. Never mutated. */
    private val objCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, JSONObject>>()

    /** Best data we have for a day: live events (if still available) or our saved copy. */
    fun dayObj(c: Context, n: Int): JSONObject {
        val key = UsageRepo.key(n)
        val now = System.currentTimeMillis()
        val ttl = if (n == 0) 15_000L else 300_000L
        objCache[key]?.let { if (now - it.first < ttl) return it.second }
        val stored = Store.dayJson(c, key)?.let { JSONObject(it) }
        var res: JSONObject? = null
        if (n <= 14) {
            val d = UsageRepo.day(c, n)
            if (stored == null || d.total >= stored.optLong("t")) res = persist(c, n, d)
        }
        val out = res ?: stored ?: empty()
        if (objCache.size > 70) objCache.clear()
        objCache[key] = now to out
        return out
    }

    fun merge(list: List<JSONObject>): JSONObject {
        if (list.size == 1) return JSONObject(list[0].toString())
        val o = empty()
        var anyData = false
        var t = 0L; var s = 0; var u = 0; var l = 0; var n = 0; var longest = 0L; var first = 0L
        val sess = IntArray(5)
        val ht = LongArray(24); val hu = IntArray(24); val hl = IntArray(24); val hn = IntArray(24)
        val apps = LinkedHashMap<String, LongArray>()
        val names = HashMap<String, String>()
        for (j in list) {
            if (!j.optBoolean("nodata", false)) anyData = true
            t += j.optLong("t"); s += j.optInt("s"); u += j.optInt("u"); l += j.optInt("l"); n += j.optInt("n")
            longest = maxOf(longest, j.optLong("longest"))
            val f = j.optLong("first"); if (f > 0 && (first == 0L || f < first)) first = f
            j.optJSONArray("sess")?.let { a -> for (i in 0 until 5) sess[i] += a.optInt(i) }
            j.optJSONObject("h")?.let { h ->
                h.optJSONArray("t")?.let { a -> for (i in 0 until 24) ht[i] += a.optLong(i) }
                h.optJSONArray("u")?.let { a -> for (i in 0 until 24) hu[i] += a.optInt(i) }
                h.optJSONArray("l")?.let { a -> for (i in 0 until 24) hl[i] += a.optInt(i) }
                h.optJSONArray("n")?.let { a -> for (i in 0 until 24) hn[i] += a.optInt(i) }
            }
            val aa = j.optJSONArray("apps") ?: continue
            for (i in 0 until aa.length()) {
                val x = aa.getJSONObject(i)
                val p = x.getString("pkg")
                names[p] = x.optString("name", p)
                val v = apps.getOrPut(p) { LongArray(3) }
                v[0] += x.optLong("t"); v[1] += x.optLong("l"); v[2] += x.optLong("n")
            }
        }
        o.put("t", t); o.put("s", s); o.put("u", u); o.put("l", l); o.put("n", n)
        o.put("longest", longest); o.put("first", first); o.put("sess", arr(sess))
        val h = JSONObject(); h.put("t", arr(ht)); h.put("u", arr(hu)); h.put("l", arr(hl)); h.put("n", arr(hn))
        o.put("h", h)
        val out = JSONArray()
        apps.entries.sortedByDescending { it.value[0] }.forEach { e ->
            val x = JSONObject()
            x.put("pkg", e.key); x.put("name", names[e.key] ?: e.key)
            x.put("t", e.value[0]); x.put("l", e.value[1]); x.put("n", e.value[2])
            out.put(x)
        }
        o.put("apps", out)
        o.put("nodata", !anyData)
        return o
    }

    /** Adds saved limits and app icons (top apps of each metric) before sending to the UI. */
    fun decorate(c: Context, o: JSONObject): JSONObject {
        val lim = Store.limits(c)
        val apps = o.optJSONArray("apps") ?: return o
        val rows = (0 until apps.length()).map { apps.getJSONObject(it) }
        val want = HashSet<String>()
        for (m in arrayOf("t", "l", "n")) rows.sortedByDescending { it.optLong(m) }.take(12).forEach { want.add(it.getString("pkg")) }
        for (x in rows) {
            val p = x.getString("pkg")
            x.put("limit", lim[p] ?: 0)
            if (p in want) { val ic = UsageRepo.iconB64(c, p); if (ic.isNotEmpty()) x.put("icon", ic) }
        }
        return o
    }

    fun summary(c: Context, from: Int, count: Int): JSONArray {
        val fmtDay = SimpleDateFormat("EEE", Locale.getDefault())
        val fmtFull = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
        val res = JSONArray()
        for (n in (from + count - 1) downTo from) {
            val j = dayObj(c, n)
            val st = UsageRepo.dayStart(n)
            val r = JSONObject()
            r.put("ago", n); r.put("label", fmtDay.format(Date(st))); r.put("full", fmtFull.format(Date(st)))
            r.put("has", !j.optBoolean("nodata", false))
            r.put("t", j.optLong("t")); r.put("l", j.optInt("l")); r.put("n", j.optInt("n")); r.put("u", j.optInt("u")); r.put("s", j.optInt("s"))
            res.put(r)
        }
        return res
    }
}
