package com.aurum.screentime

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Process
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppUse(val pkg: String, val ms: Long, val launches: Int = 0, val notifs: Int = 0)

class DayData(
    val start: Long,
    val total: Long,
    val hourly: LongArray,
    val apps: List<AppUse>,
    val pickups: Int,
    val longest: Long,
    val first: Long,
    val unlocks: Int = 0,
    val unlockHourly: IntArray = IntArray(24),
    val launches: Int = 0,
    val launchHourly: IntArray = IntArray(24),
    val notifs: Int = 0,
    val notifHourly: IntArray = IntArray(24),
    val sessions: IntArray = IntArray(5)
)

object UsageRepo {
    private const val EV_RESUMED = 1
    private const val EV_PAUSED = 2
    private const val EV_SCREEN_ON = 15
    private const val EV_SCREEN_OFF = 16
    private const val EV_STOPPED = 23
    private const val EV_NOTIF = 12
    private const val EV_KEYGUARD_HIDDEN = 18

    private var ignoredCache: Set<String>? = null
    // thread-safe: queried from the bridge worker, the widget refresher and WorkManager at the same time
    private val launchableCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val iconCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val labelCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun hasAccess(c: Context): Boolean {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = checkMode(ao, c)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun checkMode(ao: AppOpsManager, c: Context): Int =
        if (Build.VERSION.SDK_INT >= 29)
            ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)

    fun dayStart(daysAgo: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return cal.timeInMillis
    }

    fun key(daysAgo: Int): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(dayStart(daysAgo)))

    private fun ignored(c: Context): Set<String> {
        ignoredCache?.let { return it }
        val s = HashSet<String>()
        s.add("com.android.systemui")
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        for (r in c.packageManager.queryIntentActivities(i, 0)) s.add(r.activityInfo.packageName)
        ignoredCache = s
        return s
    }

    private fun launchable(c: Context, pkg: String): Boolean =
        launchableCache.getOrPut(pkg) { c.packageManager.getLaunchIntentForPackage(pkg) != null }

    private class CacheEntry(val at: Long, val data: DayData)
    private val cache = HashMap<String, CacheEntry>()

    /** Cached wrapper: today refreshes every 15s, past days every 5 min. */
    @Synchronized
    fun day(c: Context, daysAgo: Int): DayData {
        val k = key(daysAgo)
        val ttl = if (daysAgo == 0) 15_000L else 300_000L
        val e = cache[k]
        val now = System.currentTimeMillis()
        if (e != null && now - e.at < ttl) return e.data
        val d = compute(c, daysAgo)
        cache[k] = CacheEntry(now, d)
        return d
    }

    private fun bucket(ms: Long): Int = when {
        ms < 60_000L -> 0
        ms < 5 * 60_000L -> 1
        ms < 15 * 60_000L -> 2
        ms < 30 * 60_000L -> 3
        else -> 4
    }

    /** Foreground time, launches, notifications and unlocks for one calendar day, from usage events. */
    fun compute(c: Context, daysAgo: Int): DayData {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val start = dayStart(daysAgo)
        val now = System.currentTimeMillis()
        val end = if (daysAgo == 0) now else dayStart(daysAgo - 1)
        val skip = ignored(c)

        val pkgMs = HashMap<String, Long>()
        val pkgLaunch = HashMap<String, Int>()
        val pkgNotif = HashMap<String, Int>()
        val hourly = LongArray(24)
        val uh = IntArray(24); val lh = IntArray(24); val nh = IntArray(24); val soh = IntArray(24)
        val sess = IntArray(5)
        var total = 0L
        var longest = 0L
        var pickups = 0
        var unlocks = 0
        var first = 0L
        var screenOnTs = 0L

        var cur: String? = null
        var curStart = 0L
        var lastPkg: String? = null

        fun hIdx(ts: Long): Int = ((ts - start) / 3_600_000L).toInt().coerceIn(0, 23)

        fun addHours(a: Long, b: Long) {
            var t = a
            while (t < b) {
                val idx = hIdx(t)
                val boundary = start + (idx + 1) * 3_600_000L
                val seg = minOf(b, boundary) - t
                if (seg <= 0) break
                hourly[idx] += seg
                t += seg
            }
        }

        fun close(at: Long) {
            val p = cur ?: return
            cur = null
            if (at > curStart && p !in skip) {
                val d = at - curStart
                pkgMs[p] = (pkgMs[p] ?: 0L) + d
                total += d
                if (d > longest) longest = d
                addHours(curStart, at)
            }
        }

        fun endSession(at: Long) {
            if (screenOnTs > 0L) {
                val d = at - screenOnTs
                if (d >= 1000L) sess[bucket(d)]++
                screenOnTs = 0L
            }
        }

        val events = usm.queryEvents(start, end)
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val ts = ev.timeStamp
            when (ev.eventType) {
                EV_RESUMED -> {
                    val p = ev.packageName
                    if (cur != null && cur != p) close(ts)
                    if (cur == null) { cur = p; curStart = ts }
                    if (p != lastPkg) {
                        lastPkg = p
                        if (p !in skip && launchable(c, p)) {
                            pkgLaunch[p] = (pkgLaunch[p] ?: 0) + 1
                            lh[hIdx(ts)]++
                        }
                    }
                }
                EV_PAUSED, EV_STOPPED -> if (cur == ev.packageName) close(ts)
                EV_SCREEN_ON -> { pickups++; soh[hIdx(ts)]++; if (first == 0L) first = ts; screenOnTs = ts }
                EV_SCREEN_OFF -> { close(ts); endSession(ts); lastPkg = null }
                EV_KEYGUARD_HIDDEN -> { unlocks++; uh[hIdx(ts)]++ }
                EV_NOTIF -> {
                    val p = ev.packageName
                    if (p != c.packageName && launchable(c, p)) {
                        pkgNotif[p] = (pkgNotif[p] ?: 0) + 1
                        nh[hIdx(ts)]++
                    }
                }
            }
        }
        if (cur != null) close(minOf(end, now))
        if (daysAgo == 0) endSession(now)

        // phones without a keyguard event: fall back to screen-on count
        if (unlocks == 0 && pickups > 0) { unlocks = pickups; for (i in 0 until 24) uh[i] = soh[i] }

        // merge in counts gathered live by NotifListener (never lower than the system's own events)
        Store.notifDay(c, key(daysAgo))?.let { o ->
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                if (k == "_h") continue
                pkgNotif[k] = maxOf(pkgNotif[k] ?: 0, o.optInt(k))
            }
            o.optJSONArray("_h")?.let { a -> for (i in 0 until 24) nh[i] = maxOf(nh[i], a.optInt(i)) }
        }

        val all = HashSet<String>()
        all.addAll(pkgMs.keys); all.addAll(pkgLaunch.keys); all.addAll(pkgNotif.keys)
        val apps = all
            .filter { it !in skip && launchable(c, it) }
            .map { AppUse(it, pkgMs[it] ?: 0L, pkgLaunch[it] ?: 0, pkgNotif[it] ?: 0) }
            .filter { it.ms >= 30_000L || it.launches > 0 || it.notifs > 0 }
            .sortedByDescending { it.ms }

        val launches = apps.sumOf { it.launches }
        val notifs = apps.sumOf { it.notifs }
        return DayData(start, total, hourly, apps, pickups, longest, first, unlocks, uh, launches, lh, notifs, nh, sess)
    }

    fun label(c: Context, pkg: String): String = labelCache.getOrPut(pkg) {
        try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        }
    }

    fun iconBitmap(c: Context, pkg: String, px: Int): Bitmap? = try {
        val d = c.packageManager.getApplicationIcon(pkg)
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        d.setBounds(0, 0, px, px)
        d.draw(cv)
        b
    } catch (e: Exception) { null }

    fun iconB64(c: Context, pkg: String): String = iconCache.getOrPut(pkg) {
        val b = iconBitmap(c, pkg, 72) ?: return@getOrPut ""
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
