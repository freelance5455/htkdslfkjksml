package com.aurum.screentime

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/**
 * Notices which app just came to the front. If it is on the block list (or is a game while the
 * game blocker is on) the "go back to study" screen is shown. It only reads the package name of the
 * window - never the screen contents. While running it also keeps goal reminders up to date and
 * warns the moment a game gets installed.
 */
class BlockService : AccessibilityService() {
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "st-live").apply { isDaemon = true } }
    private var lastBlock = 0L
    private var lastCheck = 0L
    private var receiver: BroadcastReceiver? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, i: Intent) {
                io.execute { try { Games.warnNewInstalls(applicationContext) } catch (e: Exception) { } }
            }
        }
        val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
        try { ContextCompat.registerReceiver(this, r, f, ContextCompat.RECEIVER_EXPORTED); receiver = r } catch (e: Exception) { }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val c = applicationContext
        val now = SystemClock.elapsedRealtime()

        // live goal / limit reminders (at most every 2 minutes)
        if (now - lastCheck > 120_000L) {
            lastCheck = now
            io.execute { try { Refresh.live(c) } catch (x: Exception) { } }
        }

        val game = Store.gameGuard(c) && Games.PKGS.containsKey(pkg)
        if (!game && pkg !in Store.blocked(c)) return
        if (now - lastBlock < 700L) return
        lastBlock = now

        val i = Intent(c, BlockActivity::class.java)
            .putExtra("pkg", pkg).putExtra("game", game)
            .addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        try { startActivity(i) } catch (x: Exception) { performGlobalAction(GLOBAL_ACTION_HOME) }
    }

    override fun onInterrupt() { }

    override fun onDestroy() {
        receiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        receiver = null
        io.shutdown()
        super.onDestroy()
    }
}
