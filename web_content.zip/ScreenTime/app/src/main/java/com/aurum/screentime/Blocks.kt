package com.aurum.screentime

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

object Blocks {
    /** True when the user has switched on the "Screen Time" accessibility service (needed to block apps). */
    fun accessEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(c, BlockService::class.java)
        return s.split(':').any { it.isNotBlank() && ComponentName.unflattenFromString(it) == me }
    }

    /** Every app with a launcher icon: [{pkg,name,icon}] sorted A-Z (blocked apps always get their icon). */
    fun installed(c: Context): String {
        val pm = c.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val rows = ArrayList<Pair<String, String>>()
        for (r in pm.queryIntentActivities(q, 0)) {
            val pkg = r.activityInfo.packageName
            if (pkg == c.packageName || !seen.add(pkg)) continue
            rows.add(pkg to r.loadLabel(pm).toString())
        }
        rows.sortBy { it.second.lowercase() }
        val blocked = Store.blocked(c)
        val out = JSONArray()
        for ((i, row) in rows.withIndex()) {
            val o = JSONObject()
            o.put("pkg", row.first); o.put("name", row.second)
            if (i < 120 || row.first in blocked) {
                val ic = UsageRepo.iconB64(c, row.first)
                if (ic.isNotEmpty()) o.put("icon", ic)
            }
            out.put(o)
        }
        return out.toString()
    }
}
