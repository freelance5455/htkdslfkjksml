package com.aurum.screentime

import android.Manifest
import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    lateinit var web: WebView
    @Volatile var pendingTab: String? = null

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { js("window.onNativeResume&&window.onNativeResume()") }

    private val avatarPicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) Thread {
                val ok = Avatar.save(applicationContext, uri)
                runOnUiThread { js("window.onAvatar&&window.onAvatar($ok)") }
            }.start()
        }

    fun pickImage() { try { avatarPicker.launch("image/*") } catch (e: Exception) { } }

    fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun js(code: String) { if (::web.isInitialized) web.evaluateJavascript(code, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingTab = intent?.getStringExtra("tab")
        web = WebView(this)
        web.setBackgroundColor(0xFFFCF5E2.toInt())
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            textZoom = 100
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(Bridge(this), "Native")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onNativeBack?window.onNativeBack():false)") { r ->
                    if (r != "true") moveTaskToBack(true)
                }
            }
        })
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingTab = intent.getStringExtra("tab")
    }

    override fun onResume() {
        super.onResume()
        Refresh.schedule(this)
        js("window.onNativeResume&&window.onNativeResume()")
        if (pendingTab != null) js("window.onNativeTab&&window.onNativeTab()")
    }

    override fun onPause() {
        super.onPause()
        Thread { try { Refresh.run(applicationContext) } catch (e: Exception) { } }.start()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
