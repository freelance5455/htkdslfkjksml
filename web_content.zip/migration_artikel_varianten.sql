-- STEP 14 · Produktfamilien & Varianten
alter table public.inventory_items
  add column if not exists variant text,
  add column if not exists product_key text;

alter table public.products
  add column if not exists variant text,
  add column if not exists product_key text;

create index if not exists inventory_items_household_product_key_idx
  on public.inventory_items(household_id, product_key);
create index if not exists products_household_product_key_idx
  on public.products(household_id, product_key);
