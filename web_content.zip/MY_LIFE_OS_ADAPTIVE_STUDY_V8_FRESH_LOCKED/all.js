
/* V8: keep the editor panels usable even when Android reports a desktop-ish CSS viewport. */
(function(){
  function forceEditorMobile(){
    const app=document.getElementById('toolsApp');
    if(!app) return;
    const mobile=window.innerWidth<=1200;
    app.classList.toggle('studio-mobile-mode',mobile);
    const bar=app.querySelector('.studioMobileBar');
    if(bar) bar.style.display=mobile?'flex':'none';
    const left=app.querySelector('.studioLeft'),right=app.querySelector('.studioRight');
    if(mobile){ if(left)left.style.display='none'; if(right)right.style.display='none'; }
    else { if(left)left.style.display=''; if(right)right.style.display=''; }
  }
  window.addEventListener('resize',forceEditorMobile,{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(forceEditorMobile,120),{passive:true});
  document.addEventListener('DOMContentLoaded',forceEditorMobile);
  const oldOpen=window.openToolsApp;
  if(typeof oldOpen==='function') window.openToolsApp=function(){oldOpen();setTimeout(forceEditorMobile,60);};
  const oldInit=window.studioInit;
  if(typeof oldInit==='function') window.studioInit=function(){oldInit();setTimeout(forceEditorMobile,60);};
  setTimeout(forceEditorMobile,100);
})();


const NAV=[
["home","⌂","Command Center"],["study","▣","Study Hub"],["projects","▤","Project Vault"],["vault","◇","Secret Vault"],["knowledge","✦","My Knowledge"],["future","↗","Future Room"],["progress","◒","My Progress"],["journal","✎","Journal"],["achievements","♜","Achievement Wall"],["calendar","◫","Calendar"],["documents","▧","Document Lab"],["settings","⚙","Settings"], ["student","★","Student Edition"]
];
const subjects=["Bengali","English","Mathematics","Physical Science","Life Science","History","Geography"];
const defaultState={
mission:"Start your first meaningful study session today.",
priorities:[],
study:subjects.map(name=>({name,progress:0,hours:0,chapters:[],notes:"",questions:"",revision:""})),
projects:[],goals:[],knowledge:[],journal:[],achievements:[],
weekly:[0,0,0,0,0,0,0],studyLog:[],skills:0,books:0,quote:"Small steps every day become a different life.",
settings:{name:"STUDENT",theme:"dark",pinSet:false,profilePicture:"",studentClass:"",studentStream:"",studentStudyPath:"",studentSection:"",studentGoals:[],onboarded:false},calendarEvents:[],calendarSettings:{accent:"#8b7cff",eventColor:"#25dfff",weekStart:1,compact:false},vaultSalt:"",vaultVerifier:"",vaultCipher:null,vaultItems:[],vaultAutoLock:180000
};
let state=loadState(), current="home";
state.settings={...defaultState.settings,...(state.settings||{})};state.studyLog=Array.isArray(state.studyLog)?state.studyLog:[];state.vaultItems=state.vaultItems||[];state.vaultAutoLock=state.vaultAutoLock||180000;state.documents=state.documents||[];state.calendarEvents=Array.isArray(state.calendarEvents)?state.calendarEvents:[];state.calendarSettings={...defaultState.calendarSettings,...(state.calendarSettings||{})};
function loadState(){try{let x=JSON.parse(localStorage.getItem("myLifeOS_v3"));return x?merge(defaultState,x):structuredClone(defaultState)}catch(e){return structuredClone(defaultState)}}
function merge(a,b){let x={...structuredClone(a),...b};x.settings={...a.settings,...(b.settings||{})};return x}
function save(){localStorage.setItem("myLifeOS_v3",JSON.stringify(state))}
function today(){return new Date().toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}
function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function avg(){return Math.round(state.study.reduce((a,b)=>a+b.progress,0)/state.study.length)}
function weeklyStats(){
  const now=new Date(); now.setHours(0,0,0,0);
  const days=[];
  for(let i=6;i>=0;i--){const d=new Date(now);d.setDate(now.getDate()-i);days.push(d.toISOString().slice(0,10))}
  const map={};days.forEach(d=>map[d]=0);
  (state.studyLog||[]).forEach(x=>{if(map[x.date]!=null)map[x.date]+=Number(x.hours)||0});
  const hours=days.map(d=>map[d]);
  const total=hours.reduce((a,b)=>a+b,0);
  const target=21; // 3 focused study hours per day
  const performance=Math.min(100,Math.round((total/target)*100));
  return {days,hours,total,performance,target};
}
function navHTML(){return NAV.map(n=>`<button data-page="${n[0]}" onclick="go('${n[0]}')"><span>${n[1]}</span><span>${n[2]}</span></button>`).join("")}
document.getElementById("sideNav").innerHTML=navHTML();document.getElementById("bottomNav").innerHTML=navHTML();
function go(p){current=p;document.getElementById("pageTitle").textContent=NAV.find(x=>x[0]===p)[2];document.querySelectorAll("[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===p));render();document.getElementById("sidebar").classList.remove("open");scrollTo(0,0)}
function toggleMenu(){document.getElementById("sidebar").classList.toggle("open")}
function shell(inner){return `<div class="view">${inner}</div>`}
function render(){
clearInterval(lifeOSTourTimer); cancelAnimationFrame(lifeOSTourProgressTimer);
let c=document.getElementById("content");
const map={home:home,study:study,projects:projects,vault:vault,knowledge:knowledge,future:future,progress:progress,journal:journal,achievements:achievements,calendar:calendar,documents:documents,settings:settings};
c.innerHTML=shell(map[current]());
}

function calendar(){
  const cs=state.calendarSettings||defaultState.calendarSettings;
  if(!window.calendarCursor)window.calendarCursor=new Date();
  const cur=new Date(window.calendarCursor.getFullYear(),window.calendarCursor.getMonth(),1);
  const y=cur.getFullYear(),m=cur.getMonth(),todayKey=calendarKey(new Date());
  const monthName=cur.toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  const firstDay=new Date(y,m,1).getDay();
  const offset=((firstDay-(+cs.weekStart||0))+7)%7;
  const days=new Date(y,m+1,0).getDate();
  const prevDays=new Date(y,m,0).getDate();
  const names=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const ordered=Array.from({length:7},(_,i)=>names[((+cs.weekStart||0)+i)%7]);
  let cells='';
  for(let i=0;i<42;i++){
    const d=i-offset+1;
    let day=d, mm=m, yy=y, muted=false;
    if(d<1){day=prevDays+d;mm=m-1;muted=true}
    else if(d>days){day=d-days;mm=m+1;muted=true}
    yy=new Date(y,mm,1).getFullYear();mm=new Date(y,mm,1).getMonth();
    const key=`${yy}-${String(mm+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const evs=(state.calendarEvents||[]).filter(e=>e.date===key);
    cells+=`<button class="calDay ${muted?'mutedDay':''} ${key===todayKey?'today':''}" onclick="calendarDay('${key}')"><span class="calNum">${day}</span>${evs.slice(0,3).map(e=>`<i style="background:${esc(e.color||cs.eventColor)}" title="${esc(e.title)}"></i>`).join('')}${evs.length>3?`<b class="calMore">+${evs.length-3}</b>`:''}</button>`;
  }
  const monthEvents=(state.calendarEvents||[]).filter(e=>e.date.slice(0,7)===`${y}-${String(m+1).padStart(2,'0')}`).sort((a,b)=>a.date.localeCompare(b.date));
  return `<div class="calendarPage" style="--cal-accent:${esc(cs.accent)};--cal-event:${esc(cs.eventColor)};${cs.compact?'--cal-scale:.92;':''}">
    <div class="calHero"><div><span class="eyebrow">12 • PERSONAL CALENDAR</span><h2>Remember what matters.</h2><p>Special dates, exams, birthdays, deadlines, plans and personal milestones—saved locally on this device.</p></div><div class="calHeroBtns"><button class="btn" onclick="calendarAdd()">＋ Special Date</button><button class="btn ghost" onclick="calendarCustomize()">⚙ Customize</button></div></div>
    <div class="calLayout"><div class="calendarCard"><div class="calHeader"><button class="calArrow" onclick="calendarMove(-1)">‹</button><div><b>${monthName}</b><small>${monthEvents.length} saved date${monthEvents.length===1?'':'s'}</small></div><button class="calArrow" onclick="calendarMove(1)">›</button></div><div class="calTools"><button onclick="calendarToday()">Today</button><button onclick="calendarAdd('${todayKey}')">＋ Add today</button></div><div class="calWeek">${ordered.map(x=>`<span>${x}</span>`).join('')}</div><div class="calGrid">${cells}</div></div>
    <div class="calSide"><div class="calSideHead"><div><span class="label">SPECIAL DATES</span><h3>${monthName}</h3></div><button class="miniCalBtn" onclick="calendarAdd()">＋</button></div>${monthEvents.length?monthEvents.map(e=>`<div class="calEvent"><div class="calEventDot" style="background:${esc(e.color||cs.eventColor)}"></div><div class="calEventBody"><div class="calEventDate">${new Date(e.date+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short'})} • ${esc(e.type||'Special')}</div><b>${esc(e.title)}</b>${e.note?`<p>${esc(e.note)}</p>`:''}</div><div class="calEventActions"><button onclick="calendarEdit('${e.id}')">✎</button><button onclick="calendarDelete('${e.id}')">×</button></div></div>`).join(''):`<div class="calEmpty">No special dates yet.<br><br>Tap <b>＋ Special Date</b> to add one.</div>`}</div></div>
    <div class="card calInfo"><div><span class="label">CALENDAR SYSTEM</span><h3>Make dates meaningful.</h3><p class="small muted">You can add your own title, note, category and color to any date. Everything stays local and works offline.</p></div><div class="calStats"><b>${state.calendarEvents.length}</b><span>saved dates</span></div></div>
  </div>`;
}
function calendarKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function calendarMove(n){const d=window.calendarCursor||new Date();window.calendarCursor=new Date(d.getFullYear(),d.getMonth()+n,1);render()}
function calendarToday(){window.calendarCursor=new Date();render()}
function calendarDay(key){const found=(state.calendarEvents||[]).filter(e=>e.date===key);openModal(`<div class="modalHeader"><div><span class="eyebrow">${new Date(key+'T00:00:00').toLocaleDateString('en-IN',{weekday:'long',day:'2-digit',month:'long',year:'numeric'})}</span><h2>Special Dates</h2></div><button class="iconBtn" onclick="closeModal()">×</button></div>${found.length?found.map(e=>`<div class="calModalEvent"><span class="calDot" style="background:${esc(e.color||state.calendarSettings.eventColor)}"></span><div><b>${esc(e.title)}</b><small>${esc(e.type||'Special')} ${e.note?'• '+esc(e.note):''}</small></div><button class="btn ghost" onclick="closeModal();calendarEdit('${e.id}')">Edit</button></div>`).join(''):'<div class="calEmpty">No saved date here.</div>'}<button class="btn" style="margin-top:12px;width:100%" onclick="closeModal();calendarAdd('${key}')">＋ Add Special Date</button>`)}
function calendarAdd(date){const d=date||calendarKey(window.calendarCursor||new Date());calendarForm(null,d)}
function calendarEdit(id){const e=(state.calendarEvents||[]).find(x=>x.id===id);if(e)calendarForm(e,e.date)}
function calendarForm(existing,date){const e=existing||{title:'',date:date||calendarKey(new Date()),type:'Special',note:'',color:(state.calendarSettings||defaultState.calendarSettings).eventColor};openModal(`<div class="modalHeader"><div><span class="eyebrow">CALENDAR EDITOR</span><h2>${existing?'Edit':'Add'} Special Date</h2></div><button class="iconBtn" onclick="closeModal()">×</button></div><form class="form" onsubmit="calendarSave(event,'${existing?esc(existing.id):''}')"><label class="small muted">Date<input id="calDate" type="date" value="${esc(e.date)}" required></label><label class="small muted">Title<input id="calTitle" value="${esc(e.title)}" placeholder="Birthday, Exam, Deadline..." required></label><label class="small muted">Category<select id="calType"><option ${e.type==='Special'?'selected':''}>Special</option><option ${e.type==='Birthday'?'selected':''}>Birthday</option><option ${e.type==='Exam'?'selected':''}>Exam</option><option ${e.type==='Deadline'?'selected':''}>Deadline</option><option ${e.type==='Holiday'?'selected':''}>Holiday</option><option ${e.type==='Goal'?'selected':''}>Goal</option><option ${e.type==='Personal'?'selected':''}>Personal</option><option ${e.type==='Reminder'?'selected':''}>Reminder</option></select></label><label class="small muted">Note / details<textarea id="calNote" placeholder="Write anything you want to remember...">${esc(e.note||'')}</textarea></label><label class="small muted">Date color<input id="calColor" type="color" value="${/^#[0-9a-f]{6}$/i.test(e.color||'')?e.color:(state.calendarSettings.eventColor||'#25dfff')}"></label><div class="tools"><button class="btn" type="submit">✓ Save Date</button><button class="btn ghost" type="button" onclick="closeModal()">Cancel</button></div></form>`)}
function calendarSave(ev,id){ev.preventDefault();const item={id:id||('cal_'+Date.now().toString(36)+Math.random().toString(36).slice(2,7)),date:document.getElementById('calDate').value,title:document.getElementById('calTitle').value.trim(),type:document.getElementById('calType').value,note:document.getElementById('calNote').value,color:document.getElementById('calColor').value};if(!item.title)return;if(id){const i=state.calendarEvents.findIndex(x=>x.id===id);if(i>=0)state.calendarEvents[i]=item}else state.calendarEvents.push(item);save();closeModal();window.calendarCursor=new Date(item.date+'T00:00:00');render();toast('Calendar date saved ✓')}
function calendarDelete(id){if(!confirm('Delete this special date?'))return;state.calendarEvents=state.calendarEvents.filter(e=>e.id!==id);save();closeModal();render();toast('Calendar date deleted')}
function calendarCustomize(){const cs=state.calendarSettings||defaultState.calendarSettings;openModal(`<div class="modalHeader"><div><span class="eyebrow">CALENDAR SETTINGS</span><h2>Customize Calendar</h2></div><button class="iconBtn" onclick="closeModal()">×</button></div><form class="form" onsubmit="calendarSaveSettings(event)"><label class="small muted">Main accent<input id="calAccent" type="color" value="${esc(cs.accent)}"></label><label class="small muted">Special-date color<input id="calEventColor" type="color" value="${esc(cs.eventColor)}"></label><label class="small muted">Week starts on<select id="calWeekStart"><option value="1" ${+cs.weekStart===1?'selected':''}>Monday</option><option value="0" ${+cs.weekStart===0?'selected':''}>Sunday</option></select></label><label class="small muted">Compact calendar<select id="calCompact"><option value="0" ${!cs.compact?'selected':''}>Standard</option><option value="1" ${cs.compact?'selected':''}>Compact</option></select></label><div class="tools"><button class="btn" type="submit">✓ Save Customization</button><button class="btn ghost" type="button" onclick="closeModal()">Cancel</button></div></form>`)}
function calendarSaveSettings(ev){ev.preventDefault();state.calendarSettings={accent:document.getElementById('calAccent').value,eventColor:document.getElementById('calEventColor').value,weekStart:+document.getElementById('calWeekStart').value,compact:document.getElementById('calCompact').value==='1'};save();closeModal();render();toast('Calendar customized ✓')}

function documents(){return `<div class="hero"><span class="eyebrow">10 • DOCUMENT LAB</span><h2>Write. Convert. Organize.</h2><p>Your private document workspace for assignments, notes, PDFs, images and everyday files.</p><div class="tools" style="margin-top:17px"><button class="btn" onclick="openToolsApp()">Open Document Lab →</button><button class="btn ghost" onclick="docNew()">＋ New Document</button></div></div><div class="grid"><div class="card span8"><span class="label">📄 QUICK WORKSPACE</span><div class="docQuickGrid"><button onclick="docNew()">✍️ Write Document<small>Rich text + word count</small></button><button onclick="docPickImage()">🖼️ Image Tools<small>Convert • compress</small></button><button onclick="docPickImagePdf()">📑 Image → PDF<small>A4-ready PDF</small></button><button onclick="docNewPdfText()">🧾 Text → PDF<small>Simple printable PDF</small></button></div></div><div class="card"><span class="label">📊 DOCUMENT STATS</span><div class="stat">${(state.documents||[]).length}</div><span class="small muted">saved local documents</span></div></div>`}
function docNew(){openToolsApp();setTimeout(()=>docTab('write'),80)}
function docNewPdfText(){openToolsApp();setTimeout(()=>docTab('pdf'),80)}
function docPickImage(){openToolsApp();setTimeout(()=>document.getElementById('docImageInput')?.click(),80)}
function docPickImagePdf(){openToolsApp();setTimeout(()=>document.getElementById('docPdfImageInput')?.click(),80)}

function tools(){ return `<div class="empty">Tools are available through the TOOLS OS switch.</div>` }
let stopwatchState={running:false,startedAt:0,elapsed:0,interval:null};
function formatStopwatch(ms){let t=Math.max(0,ms),h=Math.floor(t/3600000),m=Math.floor((t%3600000)/60000),s=Math.floor((t%60000)/1000),d=Math.floor((t%1000)/100);return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${d}`}
function renderStopwatch(){let el=document.getElementById('stopwatchDisplay');if(el){let now=stopwatchState.running?Date.now()-stopwatchState.startedAt+stopwatchState.elapsed:stopwatchState.elapsed;el.textContent=formatStopwatch(now)}}
function stopwatchStart(){if(stopwatchState.running)return;stopwatchState.running=true;stopwatchState.startedAt=Date.now();clearInterval(stopwatchState.interval);stopwatchState.interval=setInterval(renderStopwatch,100);renderStopwatch()}
function stopwatchPause(){if(!stopwatchState.running)return;stopwatchState.elapsed=Date.now()-stopwatchState.startedAt+stopwatchState.elapsed;stopwatchState.running=false;clearInterval(stopwatchState.interval);stopwatchState.interval=null;renderStopwatch()}
function stopwatchReset(){stopwatchState.running=false;stopwatchState.startedAt=0;stopwatchState.elapsed=0;clearInterval(stopwatchState.interval);stopwatchState.interval=null;renderStopwatch()}
let timerState={running:false,endAt:0,remaining:300000,interval:null};
function timerValueFromInputs(){let m=Math.max(0,Math.min(999,Number(document.getElementById('timerMin')?.value||0)));let s=Math.max(0,Math.min(59,Number(document.getElementById('timerSec')?.value||0)));return (m*60+s)*1000}
function timerSyncInputs(){if(timerState.running)return;timerState.remaining=timerValueFromInputs();renderTimer()}
function formatTimer(ms){let t=Math.max(0,Math.ceil(ms/1000)),m=Math.floor(t/60),s=t%60;return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function renderTimer(){let el=document.getElementById('timerDisplay');if(el){let rem=timerState.running?Math.max(0,timerState.endAt-Date.now()):timerState.remaining;el.textContent=formatTimer(rem)}}
function timerStart(){if(timerState.running)return;timerState.remaining=timerValueFromInputs();if(timerState.remaining<=0){toast('Set a timer duration first');return}timerState.running=true;timerState.endAt=Date.now()+timerState.remaining;clearInterval(timerState.interval);timerState.interval=setInterval(()=>{timerState.remaining=Math.max(0,timerState.endAt-Date.now());renderTimer();if(timerState.remaining<=0){timerState.running=false;clearInterval(timerState.interval);timerState.interval=null;toast('⏰ Timer finished!');try{navigator.vibrate?.([250,120,250])}catch(e){};try{alert('⏰ Timer finished!')}catch(e){} }},100);renderTimer()}
function timerPause(){if(!timerState.running)return;timerState.remaining=Math.max(0,timerState.endAt-Date.now());timerState.running=false;clearInterval(timerState.interval);timerState.interval=null;renderTimer()}
function timerReset(){timerState.running=false;clearInterval(timerState.interval);timerState.interval=null;timerState.remaining=timerValueFromInputs()||300000;renderTimer()}
function calcKey(k){let d=document.getElementById('calcDisplay');if(!d)return;if(d.value==='Error')d.value='';if(k==='.'&&/(?:^|[+\-*/])[^+\-*/.]*\.$/.test(d.value))return;d.value+=k}
function calcClear(){let d=document.getElementById('calcDisplay');if(d)d.value=''}
function calcBackspace(){let d=document.getElementById('calcDisplay');if(d)d.value=d.value.slice(0,-1)}
function calcSign(){let d=document.getElementById('calcDisplay');if(!d)return;if(!d.value){d.value='-';return}if(d.value.startsWith('-(')&&d.value.endsWith(')'))d.value=d.value.slice(2,-1);else d.value='-('+d.value+')'}
function calcEquals(){let d=document.getElementById('calcDisplay');if(!d||!d.value)return;try{let e=d.value.replace(/%/g,'/100');if(!/^[0-9+*/().\s-]+$/.test(e))throw 0;let r=Function('\"use strict\";return ('+e+')')();if(!Number.isFinite(r))throw 0;d.value=String(Math.round((r+Number.EPSILON)*1e12)/1e12)}catch(e){d.value='Error'}}

/* Animated product walkthrough: presentation-video style, no external video required. */
const lifeOSTour=[
 ['01','COMMAND CENTER','Your daily control room','Mission, priorities, study progress, streaks, goals and your personal snapshot in one place.',['Mission','Priorities','Progress','Goals']],
 ['02','STUDY HUB','Learn. Track. Master.','Organize every subject with chapters, notes, important questions, revision and progress tracking.',['Subjects','Chapters','Revision','Progress']],
 ['03','PROJECT VAULT','Build everything here','Keep project descriptions, deadlines, files, links, notes, progress and final submissions together.',['Projects','Files','Deadlines','Progress']],
 ['04','SECRET VAULT','Private personal core','A PIN-protected local vault for private notes, plans, reminders and secure entries.',['PIN Lock','Encrypted','Private Notes','Auto-Lock']],
 ['05','MY KNOWLEDGE','Build your second brain','Store useful knowledge across study, design, technology, ideas, skills and future topics.',['Knowledge','Skills','Ideas','Resources']],
 ['06','FUTURE ROOM','See where you are going','Plan any year from 2026 to 2040 with goals, career, skills, finances, experiences and achievements.',['Timeline','Goals','Career','Future']],
 ['07','MY PROGRESS','Measure the real journey','Track study hours, completed projects, skills, books and goals with actual stored data.',['Study Hours','Projects','Skills','Goals']],
 ['08','JOURNAL + ACHIEVEMENTS','Keep your story','Capture your journey by date and build an achievement wall from milestones you actually complete.',['Journal','Milestones','Achievements','History']],
 ['09','CALENDAR','Never lose an important date','Manage exams, birthdays, deadlines, holidays, reminders and special dates with custom colors.',['Exams','Deadlines','Birthdays','Reminders']],
 ['10','DOCUMENT LAB','Create and organize documents','Write documents, create PDFs, convert images, export text and manage saved documents offline.',['Writer','PDF','Images','Local Save']],
 ['11','STUDENT EDITION','Made for student life','A student-first layer for class, focus areas, study goals and the tools needed to build a stronger routine.',['Class','Focus','Study','Goals']],
 ['12','SETTINGS + IDENTITY','Make the OS yours','Set your name, class, section, focus areas and profile picture while keeping the experience personal.',['Profile','Identity','Appearance','Data']]
];
let lifeOSTourIndex=0,lifeOSTourTimer=null,lifeOSTourProgressTimer=null,lifeOSTourRunning=true,lifeOSTourStarted=0;const lifeOSTourDuration=5200;
function tourMock(i){const x=lifeOSTour[i];return `<div class="tourMock"><div class="mockTop"></div><div class="mockBig">${x[0]}</div><div class="mockLabel">${x[1]}</div><div class="mockRows"><div class="mockRow"><span class="mockDot"></span><span class="mockLine"></span><span class="mockLine short purple"></span></div><div class="mockRow"><span class="mockDot"></span><span class="mockLine"></span><span class="mockLine short"></span></div><div class="mockRow"><span class="mockDot"></span><span class="mockLine purple"></span><span class="mockLine short"></span></div></div></div>`}
function renderLifeOSTour(){const root=document.getElementById('lifeOSTour');if(!root)return;root.innerHTML=`<div class="productTourHead"><div class="productTourBrand"><span class="tourLive"></span><div><b>MY LIFE OS • PRODUCT TOUR</b><small>WATCH HOW THE STUDENT OS WORKS</small></div></div><div class="tourControls"><button onclick="lifeOSTourPrev()" aria-label="Previous">‹</button><button id="lifeOSTourPlay" onclick="lifeOSTourToggle()" aria-label="Pause">Ⅱ</button><button onclick="lifeOSTourNext()" aria-label="Next">›</button></div></div><div class="tourViewport">${lifeOSTour.map((x,i)=>`<article class="tourSlide ${i===lifeOSTourIndex?'active':''}"><div><span class="tourKicker">${x[0]} • ${x[1]}</span><h3>${x[2]}</h3><p>${x[3]}</p><div class="tourPills">${x[4].map(t=>`<span class="tourPill">${t}</span>`).join('')}</div></div>${tourMock(i)}</article>`).join('')}</div><div class="tourFooter"><div class="tourDots">${lifeOSTour.map((_,i)=>`<span class="tourDot ${i===lifeOSTourIndex?'active':''}"></span>`).join('')}</div><div class="tourProgress"><i id="lifeOSTourProgress"></i></div><span class="small muted">${lifeOSTourIndex+1}/${lifeOSTour.length}</span></div>`;lifeOSTourStarted=Date.now();updateLifeOSTourProgress();}
function updateLifeOSTourProgress(){const p=document.getElementById('lifeOSTourProgress');if(!p)return;const pct=Math.min(100,((Date.now()-lifeOSTourStarted)/lifeOSTourDuration)*100);p.style.width=pct+'%';if(lifeOSTourRunning)lifeOSTourProgressTimer=requestAnimationFrame(updateLifeOSTourProgress)}
function lifeOSTourShow(i){lifeOSTourIndex=(i+lifeOSTour.length)%lifeOSTour.length;renderLifeOSTour();}
function lifeOSTourNext(){lifeOSTourShow(lifeOSTourIndex+1)}
function lifeOSTourPrev(){lifeOSTourShow(lifeOSTourIndex-1)}
function lifeOSTourToggle(){lifeOSTourRunning=!lifeOSTourRunning;const b=document.getElementById('lifeOSTourPlay');if(b)b.textContent=lifeOSTourRunning?'Ⅱ':'▶';if(lifeOSTourRunning){lifeOSTourStarted=Date.now();updateLifeOSTourProgress()}else cancelAnimationFrame(lifeOSTourProgressTimer)}
function startLifeOSTour(){clearInterval(lifeOSTourTimer);lifeOSTourTimer=setInterval(()=>{if(lifeOSTourRunning)lifeOSTourNext()},lifeOSTourDuration);renderLifeOSTour()}
function home(){
let priorities=state.priorities.map((p,i)=>`<div class="priority ${p.done?"done":""}">
  <input class="check" type="checkbox" ${p.done?"checked":""} onchange="togglePriority(${i})">
  <span style="flex:1">${esc(p.text)}</span>
  <button class="priorityDelete" type="button" title="Delete priority" onclick="deletePriority(${i})">🗑️</button>
</div>`).join("") || `<div class="empty">No priorities yet. Add today's first priority.</div>`;
let countdown=state.goals.filter(g=>g.year).sort((a,b)=>a.year-b.year).slice(0,3).map(g=>`<div class="listItem"><div class="barRow"><b>${esc(g.title)}</b><span class="pill">${g.year}</span></div><div class="small muted">${esc(g.note||"Future target")}</div></div>`).join("")||`<div class="empty">Add your first future goal.</div>`;
let bars=state.weekly.map((v,i)=>`<i style="height:${Math.max(8,v/4*78)}px" title="${v}h"></i>`).join("");
return `<div class="heroPinaki"><div class="heroParticles"></div><div><span class="eyebrow">GOOD MORNING, ${esc((state.settings.name||"STUDENT").toUpperCase())}.</span><h2>Build the life you want.</h2><div class="heroRoles">DEVELOPER • DESIGNER • CREATOR</div><div class="heroMotto">DREAM • BUILD • CREATE • GROW</div><p>Your private command center for study, projects, ideas, goals and the future you are building.</p><div class="date">${today()} • Focus on what moves you forward.</div><div class="tools" style="margin-top:18px"><button class="btn" onclick="go('study')">Start Study Session →</button><button class="btn ghost" onclick="go('documents')">Open Document Lab</button><button class="btn supportMainBtn" onclick="openSupport()">💬 Support</button></div><div class="heroStats"><div class="heroStat"><b>${state.projects.length}+</b><span>PROJECTS</span></div><div class="heroStat"><b>${state.weekly.reduce((a,b)=>a+b,0).toFixed(1)}h</b><span>STUDY</span></div><div class="heroStat"><b>∞</b><span>DREAMS</span></div></div></div><div class="heroPhotoWrap"><div class="heroOrbit"></div><div class="studentProfileCircle" id="homeProfileCircle" role="button" aria-label="Add or change profile photo">${state.settings.profilePicture?`<img class="heroPhoto" src="${esc(state.settings.profilePicture)}" alt="Student profile photo">`:`<div class="profileUploadHint"><span>＋</span><b>PROFILE PHOTO</b><small>UPLOAD IN SETTINGS</small></div>`}<input class="homeProfileFile" type="file" accept="image/*" aria-label="Choose profile photo" onchange="handleProfilePicture(event)"></div><div class="heroPhotoRing"></div></div></div>
<div class="grid">
<div class="card span8"><span class="label">🎯 TODAY'S MISSION</span><div class="mission">${esc(state.mission)}</div><button class="btn ghost" onclick="editMission()">Edit mission</button></div>
<div class="card"><span class="label">📚 STUDY PROGRESS</span><div class="stat">${avg()}%</div><div class="progress"><i style="width:${avg()}%"></i></div></div>
<div class="card"><span class="label">🔥 CURRENT STREAK</span><div class="stat">🔥 ${state.streak||1} days</div><span class="small muted">Keep showing up.</span></div>
<div class="card"><span class="label">⏳ COUNTDOWN / FUTURE</span>${countdown}</div>
<div class="card span6"><span class="label">✅ TODAY'S PRIORITIES</span>${priorities}<button class="btn ghost" style="margin-top:10px" onclick="addPriority()">＋ Add priority</button></div>
<div class="card span6"><span class="label">📊 WEEKLY PERFORMANCE</span><div class="kpi"><strong>${weeklyStats().performance}%</strong><span class="muted small">${weeklyStats().total.toFixed(1)}h / ${weeklyStats().target}h</span></div><div class="progress"><i style="width:${weeklyStats().performance}%"></i></div><div class="sparkline">${bars}</div></div>
<div class="card span8"><span class="label">💡 DAILY MOTIVATIONAL QUOTE</span><div class="quote" style="margin-top:10px">“${esc(state.quote)}”</div><button class="btn ghost" style="margin-top:12px" onclick="editQuote()">Change quote</button></div>
<div class="card"><span class="label">LIFE OS SNAPSHOT</span><div class="listItem">Projects <b style="float:right">${state.projects.length}</b></div><div class="listItem">Goals <b style="float:right">${state.goals.length}</b></div><div class="listItem">Achievements <b style="float:right">${state.achievements.length}</b></div></div>
</div>
`}
function study(){
  const path=state.settings?.studentStudyPath||state.settings?.studentClass||'';
  const stream=state.settings?.studentStream||'';
  const pathLabel=path||'Study Plan';
  const streamLabel=stream?` • ${stream}`:'';
  const subjectsLabel=state.study.map(s=>s.name).join(' • ');
  return `<div class="hero"><span class="eyebrow">02 • STUDY HUB</span><h2>Learn. Track. Master.</h2><p>Your complete study center. Every subject has Notes, Chapters, Important Questions, Revision and Progress.</p><div class="tools" style="margin-top:17px"><span class="pill">${esc(pathLabel+streamLabel)}</span></div><div class="small muted" style="margin-top:10px">${esc(subjectsLabel)}</div><div class="tools" style="margin-top:17px"><button class="btn" onclick="studySession()">＋ Study Session</button><button class="btn ghost" onclick="addStudyNote()">＋ Quick Note</button></div></div>
<div class="sectionHead"><h3>Subjects for ${esc(pathLabel)}${streamLabel?esc(streamLabel):''}</h3><span class="pill">${avg()}% average</span></div>
<div class="grid">${state.study.map((s,i)=>`<div class="card subjectCard"><div class="subjectTitle"><b>${esc(s.name)}</b><span class="pill">${s.progress}%</span></div><div class="progress"><i style="width:${s.progress}%"></i></div><div class="subtabs">${["Notes","Chapters","Questions","Revision","Progress"].map(t=>`<button onclick="subjectPanel(${i},'${t}')">${t}</button>`).join("")}</div><div class="small muted" style="margin-top:11px">${s.chapters.filter(x=>x.done).length}/${s.chapters.length} chapters complete • ${s.hours||0}h logged</div><div class="tools" style="margin-top:11px"><button class="btn ghost" onclick="changeStudy(${i},-5)">−</button><button class="btn ghost" onclick="changeStudy(${i},5)">＋ Progress</button></div></div>`).join("")}</div>`
}
function projects(){
return `<div class="hero"><span class="eyebrow">03 • PROJECT VAULT</span><h2>Everything you're building.</h2><p>A personal project storage system for descriptions, images, PDFs, documents, links, notes, deadlines, progress and final submissions.</p><button class="btn" style="margin-top:16px" onclick="newProject()">＋ New Project</button></div>
<div class="sectionHead"><h3>Your Projects</h3><span class="pill">${state.projects.length} saved</span></div>
${state.projects.length?`<div class="grid">${state.projects.map((p,i)=>`<div class="card span6"><div class="barRow"><span class="pill">${esc(p.status||"In Progress")}</span><span class="small muted">${esc(p.deadline||"No deadline")}</span></div><h3>${esc(p.title)}</h3><p class="muted small">${esc(p.description||"No description yet.")}</p><div class="progress"><i style="width:${p.progress||0}%"></i></div><div class="barRow small" style="margin-top:6px"><span>Progress</span><b>${p.progress||0}%</b></div>${p.link?`<div class="small" style="margin-top:9px">🔗 ${esc(p.link)}</div>`:""}<div class="fileList">${(p.files||[]).map(f=>`<div class="fileChip">📎 ${esc(f.name)}</div>`).join("")}</div><div class="tools" style="margin-top:12px"><button class="btn ghost" onclick="editProject(${i})">Edit</button><button class="btn danger" onclick="removeItem('projects',${i})">Delete</button></div></div>`).join("")}</div>`:`<div class="empty">Your project vault is empty.<br><button class="btn" style="margin-top:12px" onclick="newProject()">Create your first project</button></div>`}`
}
function vault(){
return `<div class="vaultScreen"><div class="vaultTop"><div><span class="eyebrow">04 • SECRET VAULT</span><h2 style="margin:6px 0 0">Encrypted Personal Core</h2></div><span class="pill">${state.settings.pinSet?"ARMED":"NOT INITIALIZED"}</span></div><div class="vaultCore"><div class="coreLock">🔐</div></div><div class="vaultStatus"><span class="statusDot"></span> LOCAL ENCRYPTION CORE • AES-GCM</div><p class="muted small" style="text-align:center;margin:9px auto;max-width:620px">A private space for notes, ideas, plans, reminders and secure entries. Unlock it with your Secret Vault PIN.</p><div class="vaultGrid"><button class="vaultTile" onclick="unlockVault()">🔓 <b>Unlock Vault</b><span>PIN verification + secure access animation</span></button><button class="vaultTile" onclick="unlockVault('notes')">📝 <b>Private Notes</b><span>Encrypted personal notes and journal-style thoughts</span></button><button class="vaultTile" onclick="unlockVault('plans')">🎯 <b>Future Plans</b><span>Private goals and plans that stay inside the vault</span></button><button class="vaultTile" onclick="unlockVault('reminders')">⏰ <b>Important Reminders</b><span>Private reminders you don't want on the main dashboard</span></button></div></div><div class="grid"><div class="card span8"><div class="notice">Security status: encrypted vault data is protected with a PIN-derived AES-GCM key. This is local browser security, not an audited password manager.</div></div><div class="card"><span class="label">AUTO-LOCK</span><div class="stat">3 MIN</div><span class="small muted">Vault closes after inactivity</span></div></div>`
}
function knowledge(){
return `<div class="hero"><span class="eyebrow">05 • MY KNOWLEDGE</span><h2>Your second brain.</h2><p>Build a personal knowledge library that stays useful for years.</p><button class="btn" style="margin-top:16px" onclick="newKnowledge()">＋ Save Knowledge</button></div>
<div class="sectionHead"><h3>Library</h3><div class="tools">${["Study","Design","Technology","Ideas","Skills","Future"].map(x=>`<span class="pill">${x}</span>`).join("")}</div></div>
${state.knowledge.length?`<div class="grid">${state.knowledge.map((x,i)=>`<div class="card"><span class="pill">${esc(x.tag||"Learning")}</span><h3>${esc(x.title)}</h3><p class="muted small">${esc(x.note||"")}</p><button class="btn danger" onclick="removeItem('knowledge',${i})">Delete</button></div>`).join("")}</div>`:`<div class="empty">Save something you learn today. In a few years this becomes your Personal Knowledge Base.</div>`}`
}
function future(){
let years=Array.from({length:15},(_,i)=>2026+i);return `<div class="hero"><span class="eyebrow">06 • FUTURE ROOM</span><h2>Design the person you're becoming.</h2><p>Your future timeline connects Goals, Career, Financial Goals, Skills, Experiences and Achievements.</p><button class="btn" style="margin-top:16px" onclick="newGoal()">＋ Add Future Goal</button></div><div class="sectionHead"><h3>Future Timeline</h3><span class="pill">${state.goals.length} goals</span></div><div class="timeline">${years.map(y=>{let gs=state.goals.filter(g=>+g.year===y);return `<div class="year"><h3>${y}</h3>${gs.length?gs.map((g,idx)=>`<div class="goal"><div class="barRow"><span class="pill">${esc(g.category||"Goal")}</span><span class="small muted">${g.done?"✓ Completed":"Planned"}</span></div><b>${esc(g.title)}</b><span class="small muted">${esc(g.note||"")}</span><div class="tools" style="margin-top:9px"><button class="btn ghost" onclick="toggleGoal(${state.goals.indexOf(g)})">${g.done?"Mark active":"✓ Mark complete"}</button><button class="btn danger" onclick="removeItem('goals',${state.goals.indexOf(g)})">Delete</button></div></div>`).join(""):`<p class="muted small">No target yet. What do you want this year to become?</p>`}</div>`}).join("")}</div>`
}
function progress(){
let skills=state.knowledge.filter(x=>x.tag==="Skills"||x.tag==="Skill").length;let completed=state.goals.filter(x=>x.done).length;let current=avg();let previous=Math.max(1,current-(state.weekly[6]>0?5:0));let change=Math.round(((current-previous)/previous)*100);let ws=weeklyStats();
return `<div class="hero"><span class="eyebrow">07 • MY PROGRESS</span><h2>Growth, made visible.</h2><p>Actual data from your system—not fake achievements. Log your work and let the dashboard tell the story.</p></div><div class="grid"><div class="card"><span class="label">STUDY PROGRESS</span><div class="stat">${current}%</div><div class="progress"><i style="width:${current}%"></i></div></div><div class="card"><span class="label">WEEKLY PERFORMANCE</span><div class="stat">${ws.performance}%</div><div class="progress"><i style="width:${ws.performance}%"></i></div><span class="small muted">${ws.total.toFixed(1)}h / ${ws.target}h this week</span></div><div class="card"><span class="label">PROJECTS COMPLETED</span><div class="stat">${state.projects.filter(x=>x.status==="Completed").length}</div></div><div class="card"><span class="label">SKILLS LEARNED</span><div class="stat">${skills}</div></div><div class="card"><span class="label">BOOKS / RESOURCES</span><div class="stat">${state.books}</div></div><div class="card"><span class="label">GOALS COMPLETED</span><div class="stat">${completed}</div></div><div class="card span8"><span class="label">LAST 7 DAYS • AUTOMATIC STUDY HISTORY</span><div class="sparkline" style="height:125px">${ws.hours.map(v=>`<i style="height:${Math.max(8,Math.min(115,v/4*115))}px" title="${v.toFixed(1)}h"></i>`).join("")}</div><div class="barRow small muted"><span>${ws.days[0].slice(5)}</span><span>${ws.days[1].slice(5)}</span><span>${ws.days[2].slice(5)}</span><span>${ws.days[3].slice(5)}</span><span>${ws.days[4].slice(5)}</span><span>${ws.days[5].slice(5)}</span><span>${ws.days[6].slice(5)}</span></div></div><div class="card span4"><span class="label">MONTHLY SIGNAL</span><div class="quote" style="margin-top:12px">You are <b>${Math.max(0,change)}%</b> better than last month.</div><p class="small muted">Weekly performance updates automatically whenever you log a study session.</p></div></div>`
}
function journal(){
return `<div class="hero"><span class="eyebrow">08 • JOURNAL</span><h2>Keep your story.</h2><p>Capture what you learned, what changed and what you want to remember.</p><button class="btn" style="margin-top:16px" onclick="newJournal()">＋ Write Today</button></div><div class="sectionHead"><h3>Your Timeline</h3><span class="pill">${state.journal.length} entries</span></div>${state.journal.length?state.journal.slice().reverse().map((j,ri)=>{let i=state.journal.length-1-ri;return `<div class="card span12 listItem"><span class="journalDate">${esc(j.date)}</span><h3>${esc(j.title||"Daily Reflection")}</h3><p>${esc(j.text)}</p><button class="btn danger" onclick="removeItem('journal',${i})">Delete</button></div>`}).join(""):`<div class="empty">September 2026<br><br>Your first journal entry is waiting.</div>`}`
}
function achievements(){
return `<div class="hero"><span class="eyebrow">09 • ACHIEVEMENT WALL</span><h2>Remember what you accomplished.</h2><p>First Project, Exam Result, First Website, First Design, 30-Day Streak, Major Goal Completed—save the milestones that matter.</p><button class="btn" style="margin-top:16px" onclick="newAchievement()">＋ Add Achievement</button></div><div class="sectionHead"><h3>Milestones</h3><span class="pill">${state.achievements.length} saved</span></div>${state.achievements.length?`<div class="grid">${state.achievements.map((a,i)=>`<div class="card achievement"><span class="pill">🏆 ${esc(a.date)}</span><h3>${esc(a.title)}</h3><p class="muted small">${esc(a.note||"")}</p><button class="btn danger" onclick="removeItem('achievements',${i})">Delete</button></div>`).join("")}</div>`:`<div class="empty">Your achievement wall is waiting for your first milestone.</div>`}`
}

function studentEdition(){return `<div class="productHero"><span class="studentBadge">✦ MY LIFE OS • STUDENT EDITION</span><h2>Everything a student needs. One private workspace.</h2><p class="muted">Built for studying, planning, creating, saving documents and tracking your growth—offline on your device.</p><div class="featureGrid"><div class="featureMini">📚 <b>Study Hub</b><span>Subjects, chapters, notes & revision</span></div><div class="featureMini">📅 <b>Smart Calendar</b><span>Exams, deadlines & special dates</span></div><div class="featureMini">📄 <b>Document Lab</b><span>Write, save, convert & export</span></div><div class="featureMini">🎯 <b>Goals & Future</b><span>Turn plans into milestones</span></div><div class="featureMini">📊 <b>Progress</b><span>See your real growth</span></div><div class="featureMini">⏱️ <b>Study Tools</b><span>Timer, stopwatch & calculator</span></div></div></div><div class="grid"><div class="card proCard"><span class="studentBadge">⭐ PRO</span><h3>Student Pro</h3><p class="muted">A clean, focused student productivity system with the full MY LIFE OS toolkit.</p><button class="btn" onclick="toast('Student Pro checkout will be connected when you choose a payment platform.')">Explore Pro</button></div><div class="card"><h3>Your Profile</h3><p class="muted">${esc((state.settings.name||"STUDENT").toUpperCase())} ${state.settings.studentClass?'• '+esc(state.settings.studentClass):''}</p><button class="btn ghost" onclick="go('settings')">Customize Profile →</button></div></div>`}
function studentOnboardOpen(){const o=document.getElementById('studentOnboarding');if(!o)return;o.classList.add('open');o.setAttribute('aria-hidden','false');window.studentStep=0;studentOnboardRender()}
function studentOnboardRender(){const o=document.getElementById('studentOnboarding');if(!o)return;document.querySelectorAll('.onboardStep').forEach(x=>x.classList.toggle('active',+x.dataset.step===window.studentStep));document.querySelectorAll('.onboardDot').forEach((x,i)=>x.classList.toggle('active',i<=window.studentStep));document.getElementById('onBack').style.display=window.studentStep?'inline-flex':'none';document.getElementById('onNext').textContent=window.studentStep===2?'Finish Setup →':'Continue →'}
function studentOnboardNext(){if(window.studentStep===0){const n=document.getElementById('onName').value.trim();if(n)state.settings.name=n;window.studentStep=1;studentOnboardRender();return}if(window.studentStep===1){state.settings.studentClass=document.getElementById('onClass').value.trim();state.settings.studentGoals=[...document.querySelectorAll('.onboardStep[data-step="1"] input[type=checkbox]:checked')].map(x=>x.value);window.studentStep=2;studentOnboardRender();return}state.settings.onboarded=true;save();document.getElementById('studentOnboarding').classList.remove('open');document.getElementById('studentOnboarding').setAttribute('aria-hidden','true');render();toast('Welcome to MY LIFE OS ✓')}
function studentOnboardBack(){if(window.studentStep>0){window.studentStep--;studentOnboardRender()}}

function settings(){
const pic=state.settings.profilePicture||"";
return `<div class="hero"><span class="eyebrow">SYSTEM SETTINGS</span><h2>Make it yours.</h2><p>Personalize your identity and manage your local data.</p></div><div class="grid"><div class="card span6"><h3>Identity</h3><div class="profileSettingsBox"><img id="profilePreview" class="profileAvatar" src="${esc(pic)}" ${pic?'':'style="display:none"'}><div id="profileFallback" class="profileAvatar profileAvatarFallback" ${pic?'style="display:none"':''}><span>＋</span></div><div style="min-width:0"><b>Profile Picture</b><div class="profileHint">Add or change your picture. It is resized for fast offline storage.</div><div class="profileActions" style="margin-top:9px"><button class="btn ghost" type="button" onclick="openProfilePicker()">＋ Add / Change</button>${pic?'<button class="btn danger" type="button" onclick="removeProfilePicture()">Remove</button>':''}</div><input id="profileFile" type="file" accept="image/*" hidden onchange="handleProfilePicture(event)"></div></div><div class="form"><label class="small muted">Display name<input id="nameSet" value="${esc((state.settings.name||"STUDENT").toUpperCase())}"></label><label class="small muted">Class / Grade<input id="classSet" value="${esc(state.settings.studentClass||"")}" placeholder="e.g. Class X" readonly aria-readonly="true"></label><label class="small muted">Section <span style="opacity:.55">(optional)</span><input id="sectionSet" value="${esc(state.settings.studentSection||"")}" placeholder="e.g. A"></label><label class="small muted">Focus areas<input id="goalsSet" value="${esc((state.settings.studentGoals||[]).join(", "))}" placeholder="Study, Exams, Projects"></label><button class="btn" onclick="saveSettings()">Save settings</button></div></div><div class="card span6"><h3>Storage</h3><p class="small muted">Your normal data is stored in this device's IndexedDB. Export a JSON backup before changing devices or clearing browser data.</p><div class="tools"><button class="btn cyan" onclick="backup()">⇩ Export Backup</button><button class="btn ghost" onclick="document.getElementById('restoreFile').click()">⇧ Restore Backup</button><input id="restoreFile" type="file" accept=".json" hidden onchange="restore(event)"></div></div><div class="card span12"><h3>Legacy Mode</h3><p class="muted small">Your yearly digital life history is built from actual saved projects, study progress, goals, skills and achievements.</p><button class="btn gold" onclick="legacyReport()">Open Legacy Mode</button></div><div class="card span12"><div class="notice">Security note: local browser storage is useful for personal productivity, but it is not a cloud backup and is not equivalent to an audited secure vault. Never put banking passwords, recovery codes or other highly sensitive credentials into this app.</div></div></div>`
}
function openModal(inner){document.getElementById("modalCard").innerHTML=inner;document.getElementById("modal").classList.remove("fullscreenModal");document.getElementById("modal").classList.add("open")}
function openFullscreenModal(inner){document.getElementById("modalCard").innerHTML=inner;document.getElementById("modal").classList.add("open","fullscreenModal")}
function closeModal(){if(typeof vaultSession!=="undefined"&&vaultSession.pin){vaultSession.pin=null;clearTimeout(vaultSession.timer)}document.getElementById("modal").classList.remove("open","fullscreenModal","profileCropOpen")}
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
let studio={canvas:null,tool:'select',selected:null,history:[],future:[],zoom:1,bg:'#ffffff',drawing:false};
function openToolsApp(){const app=document.getElementById('toolsApp');document.getElementById('toolsApp')?.querySelector('#pixelLabBottomDock')?.remove();app.classList.add('active');app.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';docTab('home')}
function closeToolsApp(){const app=document.getElementById('toolsApp');app.classList.remove('active');app.setAttribute('aria-hidden','true');document.body.style.overflow=''}
function studioInit(){if(studio.canvas)return;const c=document.getElementById('studioCanvas');studio.canvas=c;studioRender();studioSaveHistory();c.addEventListener('mousedown',studioPointerDown);c.addEventListener('mousemove',studioPointerMove);window.addEventListener('mouseup',studioPointerUp);c.addEventListener('touchstart',e=>studioPointerDown(e.touches[0]),{passive:false});c.addEventListener('touchmove',e=>{e.preventDefault();studioPointerMove(e.touches[0])},{passive:false});window.addEventListener('touchend',studioPointerUp);}
function studioRender(){const c=studio.canvas,ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle=studio.bg;ctx.fillRect(0,0,c.width,c.height);studio.layers?.forEach(o=>studioDrawObject(ctx,o));studioUpdateLayers();studioUpdateProps();}
studio.layers=[];
function studioDrawObject(ctx,o){ctx.save();ctx.globalAlpha=o.opacity??1;ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);if(o.type==='text'){ctx.fillStyle=o.color||'#10131c';ctx.font=`${o.weight||700} ${o.size||72}px ${o.font||'Arial'}`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(o.text||'Text',0,0)}else if(o.type==='rect'){ctx.fillStyle=o.color||'#8b7cff';ctx.fillRect(-o.w/2,-o.h/2,o.w,o.h)}else if(o.type==='circle'){ctx.fillStyle=o.color||'#39dfcf';ctx.beginPath();ctx.arc(0,0,o.r||130,0,Math.PI*2);ctx.fill()}else if(o.type==='image'&&o.img){ctx.filter=o.filter||'none';ctx.drawImage(o.img,-o.w/2,-o.h/2,o.w,o.h)}else if(o.type==='draw'&&o.points?.length){ctx.strokeStyle=o.color||'#8b7cff';ctx.lineWidth=o.size||8;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();o.points.forEach((p,i)=>i?ctx.lineTo(p.x-o.x,p.y-o.y):ctx.moveTo(p.x-o.x,p.y-o.y));ctx.stroke()}ctx.restore();}
function studioSnapshot(){return JSON.stringify({bg:studio.bg,layers:studio.layers.map(o=>{let x={...o};delete x.img;return x})})}
function studioSaveHistory(){studio.history=studio.history||[];const snap=studioSnapshot();if(studio.history[studio.history.length-1]!==snap)studio.history.push(snap);if(studio.history.length>40)studio.history.shift();studio.future=[]}
function studioRestore(snap){const d=JSON.parse(snap);studio.bg=d.bg;studio.layers=d.layers;studio.selected=null;studioRender()}
function studioUndo(){if(studio.history.length<2)return;const cur=studio.history.pop();studio.future.push(cur);studioRestore(studio.history[studio.history.length-1]);studioToast('Undo')}
function studioRedo(){if(!studio.future.length)return;const s=studio.future.pop();studio.history.push(s);studioRestore(s);studioToast('Redo')}
function studioTool(t){studio.tool=t;document.querySelectorAll('.studioTool').forEach(x=>x.classList.remove('active'));if(t==='select')document.getElementById('stToolSelect')?.classList.add('active');studioToast(t==='draw'?'Draw mode • drag on canvas':'Select mode')}
function studioAddText(){const o={id:crypto.randomUUID(),type:'text',text:'',x:studioPage.width/2,y:studioPage.height/2,size:72,color:'#10131c',weight:800,font:'Arial',opacity:1,rotation:0,name:'Text'};studio.layers.push(o);studio.selected=o.id;studioSaveHistory();studioRender();studioTextEditor(o.id,true)}
function studioTextEditor(id,focusNow=false){const o=studio.layers.find(x=>x.id===id);if(!o)return;studioModal(`<div class=\"modalHeader\"><div><span class=\"eyebrow\">TEXT EDITOR</span><h2 style=\"margin:5px 0 0\">Write your text</h2></div><button class=\"iconBtn\" onclick=\"studioCloseModal()\">×</button></div><div class=\"studioTextEditor\"><textarea id=\"studioTextInput\" class=\"studioTextInput\" rows=\"5\" placeholder=\"Type here…\">${esc(o.text||'')}</textarea><div class=\"small muted\" style=\"margin-top:8px\">Your phone keyboard should open automatically. Use Enter for a new line.</div><div class=\"tools\" style=\"margin-top:12px\"><button class=\"studioBtn primary\" onclick=\"studioCommitText('${id}')\">✓ Apply Text</button><button class=\"studioBtn\" onclick=\"studioCloseModal()\">Cancel</button></div></div>`);const input=document.getElementById('studioTextInput');const focus=()=>{input?.focus();input?.setSelectionRange(input.value.length,input.value.length);try{input?.click()}catch(e){}};if(focusNow){setTimeout(focus,80);setTimeout(focus,300)}}
function studioCommitText(id){const o=studio.layers.find(x=>x.id===id),input=document.getElementById('studioTextInput');if(!o||!input)return;o.text=input.value||'Text';o.name=o.text.split('\n')[0].slice(0,40)||'Text';studioSaveHistory();studioRender();studioCloseModal();studioToast('Text updated ✓')}

function studioAddShape(type){const o=type==='circle'?{id:crypto.randomUUID(),type,x:540,y:540,r:150,color:'#39dfcf',opacity:1,rotation:0}:{id:crypto.randomUUID(),type:'rect',x:540,y:540,w:420,h:260,color:'#8b7cff',opacity:1,rotation:0};studio.layers.push(o);studio.selected=o.id;studioSaveHistory();studioRender();}
const DOC_STORE_KEY='myLifeOS_documents_v2';
function loadDocStore(){try{const raw=localStorage.getItem(DOC_STORE_KEY);if(raw){const d=JSON.parse(raw);if(Array.isArray(d))return d}}catch(e){}try{const old=Array.isArray(state.documents)?state.documents:[];if(old.length){localStorage.setItem(DOC_STORE_KEY,JSON.stringify(old));return old}}catch(e){}return []}
function saveDocStore(docs){
  const clean=Array.isArray(docs)?docs:[];
  const payload=JSON.stringify(clean);
  try{localStorage.setItem(DOC_STORE_KEY,payload);state.documents=clean;localStorage.setItem('myLifeOS_v3',JSON.stringify(state));return true}catch(err){
    try{sessionStorage.setItem(DOC_STORE_KEY,payload);state.documents=clean;return true}catch(e){return false}
  }
}
let docState={tab:'home',text:'',title:'Untitled Document',image:null,pdfImage:null,compareA:null,compareB:null,comparePos:50};
function docTab(tab){docState.tab=tab;document.querySelectorAll('.docNav').forEach(b=>b.classList.toggle('active',b.dataset.doctab===tab));const b=document.getElementById('docBody');if(!b)return;if(tab==='home')docHome();else if(tab==='write')docWriter();else if(tab==='pdf')docPdf();else if(tab==='image')docImageLab();else docQuickTools();}
function docHome(){const b=document.getElementById('docBody');if(!b)return;const docs=loadDocStore();if(!docs.length&&Array.isArray(state.documents)&&state.documents.length)saveDocStore(state.documents);const finalDocs=loadDocStore();b.innerHTML=`<div class="docHero"><span>DOCUMENT LAB</span><h1>Your file workspace.</h1><p>Create documents, save them on this device, make PDFs and keep your work organized.</p><div class="docCards"><button onclick="docTab('write')"><b>✍️ Writer</b><small>Write, edit and save documents</small></button><button onclick="docTab('pdf')"><b>📑 PDF Maker</b><small>Image or text to printable PDF</small></button><button onclick="docTab('image')"><b>🖼 Image Lab</b><small>Convert, resize and compress</small></button><button onclick="docTab('tools')"><b>⏱ Quick Tools</b><small>Calculator, stopwatch and timer</small></button></div></div><div class="docPanel" style="margin-top:14px"><div class="docPanelHead"><div><span>SAVED ON THIS DEVICE</span><h2>My Documents</h2></div><button onclick="docNew()">＋ New</button></div>${finalDocs.length?`<div class="docSavedList">${finalDocs.map((d,i)=>`<div class="docSavedItem"><div><b>${esc(d.title||'Untitled Document')}</b><small>${new Date(d.updated||Date.now()).toLocaleString('en-IN')} • ${(d.text||'').trim()?((d.text||'').trim().split(/\s+/).length):0} words</small></div><div class="docSavedBtns"><button onclick="docLoad(${i})">Open</button><button class="danger" onclick="docDelete(${i})">Delete</button></div></div>`).join('')}</div>`:`<div class="docEmpty">No saved documents yet.<br>Write something and tap <b>💾 Save</b>.</div>`}</div>`}
function docWriter(){const b=document.getElementById('docBody');if(!b)return;b.innerHTML=`<div class="docPanel"><div class="docPanelHead"><div><span>WRITER</span><h2>Document Writer</h2></div><div class="docHeadBtns"><button class="docSaveBtn" id="docSaveButton" type="button" onclick="return window.docSave(event)" onpointerup="if(event.pointerType==='touch') event.stopPropagation()">💾 Save</button><button type="button" onclick="docExportTxt()">⇩ TXT</button><button type="button" onclick="docPrint()">📄 PDF</button></div></div><input id="docTitle" class="docTitle" placeholder="Document title" value="${esc(docState.title)}"><textarea id="docEditor" class="docEditor" placeholder="Start writing here...">${esc(docState.text)}</textarea><div class="docMeta"><span id="docCount">0 words • 0 characters</span><span id="docSaveStatus">Unsaved changes • tap 💾 Save</span></div></div>`;const os=document.getElementById('docWriterOrientation');if(os)os.value=window.docPdfOrientation||'portrait';docUpdateCount();const ed=document.getElementById('docEditor');if(ed)ed.addEventListener('input',()=>{docUpdateCount();const s=document.getElementById('docSaveStatus');if(s)s.textContent='Unsaved changes • tap 💾 Save'});}
function docUpdateCount(){const e=document.getElementById('docEditor');const c=document.getElementById('docCount');if(!e||!c)return;const t=e.value.trim();c.textContent=`${t?t.split(/\s+/).length:0} words • ${e.value.length} characters`}
function docSave(ev){
  if(ev&&ev.preventDefault)ev.preventDefault();
  const e=document.getElementById('docEditor'),t=document.getElementById('docTitle'),btn=document.getElementById('docSaveButton');
  if(!e){toast('Open Document Writer first');return false}
  const text=String(e.value??''),title=(t?.value||'').trim()||'Untitled Document';
  let docs=loadDocStore();
  let i=docs.findIndex(x=>x.id===docState.editId);
  const item={id:i>=0?docs[i].id:(Date.now().toString(36)+Math.random().toString(36).slice(2,9)),title,text,updated:new Date().toISOString()};
  if(i>=0)docs[i]=item;else{docs.unshift(item);i=0}
  const ok=saveDocStore(docs);
  docState.text=text;docState.title=title;docState.editId=item.id;
  const st=document.getElementById('docSaveStatus');
  if(ok){
    if(st)st.textContent='✓ SAVED LOCALLY • '+new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});
    if(btn){btn.disabled=true;btn.textContent='✓ Saved';setTimeout(()=>{btn.disabled=false;btn.textContent='💾 Save'},900)}
    toast('DOCUMENT SAVED ✓');
    return false;
  }
  if(st)st.textContent='⚠ Save failed — storage is blocked or full';
  toast('Save failed — storage unavailable');
  return false;
}
function docLoad(i){const docs=loadDocStore(),d=docs[i];if(!d)return;docState={...docState,tab:'write',title:d.title||'Untitled Document',text:d.text||'',editId:d.id||null};docTab('write');}
function docDelete(i){const docs=loadDocStore();if(!docs[i])return;if(!confirm('Delete this saved document?'))return;docs.splice(i,1);saveDocStore(docs);try{state.documents=docs;save()}catch(e){}if(docState.editId&&!(docs||[]).some(x=>x.id===docState.editId)){docState.editId=null;docState.title='Untitled Document';docState.text=''}docTab('home');toast('Document deleted');}
function docExportTxt(){const e=document.getElementById('docEditor'),t=document.getElementById('docTitle');if(!e)return;const blob=new Blob(['\uFEFF',String(e.value||'')],{type:'text/plain;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(t?.value||'document')+'.txt';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function docPrint(){
  const e=document.getElementById('docEditor'),t=document.getElementById('docTitle');
  if(!e)return;
  const orientation=document.getElementById('docWriterOrientation')?.value||window.docPdfOrientation||'portrait';
  const title=(t?.value||'Document').trim()||'Document';
  downloadTextPdf(title,e.value,orientation);
}
function pdfPageSize(orientation){return orientation==='landscape'?{w:842,h:595}:{w:595,h:842}}
function makeJpegPdfPages(pages,title,orientation='portrait'){
  const {w:PW,h:PH}=pdfPageSize(orientation),parts=[pdfAscii('%PDF-1.4\n')],offs=[0],pos=parts[0].length;
  const add=bytes=>{parts.push(bytes);pos+=bytes.length};
  const pageObjs=[]; let obj=1;
  const catalog=obj++, pagesObj=obj++;
  pages.forEach((pg,i)=>{pageObjs.push({page:obj++,content:obj++,img:obj++})});
  offs[catalog]=pos;add(pdfAscii(`${catalog} 0 obj\n<< /Type /Catalog /Pages ${pagesObj} 0 R >>\nendobj\n`));
  offs[pagesObj]=pos;add(pdfAscii(`${pagesObj} 0 obj\n<< /Type /Pages /Kids [${pageObjs.map(x=>x.page+' 0 R').join(' ')}] /Count ${pages.length} >>\nendobj\n`));
  pageObjs.forEach((o,i)=>{
    const pg=pages[i],scale=Math.min((PW-48)/pg.w,(PH-48)/pg.h),iw=pg.w*scale,ih=pg.h*scale,x=(PW-iw)/2,y=(PH-ih)/2;
    const stream=`q ${iw.toFixed(2)} 0 0 ${ih.toFixed(2)} ${x.toFixed(2)} ${(PH-y-ih).toFixed(2)} cm /Im Do Q`;
    offs[o.page]=pos;add(pdfAscii(`${o.page} 0 obj\n<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im ${o.img} 0 R >> >> /Contents ${o.content} 0 R >>\nendobj\n`));
    offs[o.content]=pos;add(pdfAscii(`${o.content} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj\n`));
    offs[o.img]=pos;add(pdfAscii(`${o.img} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${pg.w} /Height ${pg.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${pg.jpg.length} >>\nstream\n`));add(pg.jpg);add(pdfAscii('\nendstream\nendobj\n'));
  });
  const info=obj++;offs[info]=pos;add(pdfAscii(`${info} 0 obj\n<< /Title (${String(title).replace(/[\\()]/g,'')}) /Producer (MY LIFE OS Document Lab) >>\nendobj\n`));
  const xref=pos;let tail=`xref\n0 ${info+1}\n0000000000 65535 f \n`;for(let i=1;i<=info;i++)tail+=String(offs[i]||0).padStart(10,'0')+' 00000 n \n';tail+=`trailer\n<< /Size ${info+1} /Root ${catalog} 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF`;add(pdfAscii(tail));return new Blob(parts,{type:'application/pdf'})
}
function renderTextPdfPages(title,text,orientation='portrait'){
  const {w:W,h:H}=pdfPageSize(orientation),margin=58,titleSize=orientation==='landscape'?30:34,bodySize=orientation==='landscape'?19:21,lineH=orientation==='landscape'?31:34;
  const lines=[]; const ctx=document.createElement('canvas').getContext('2d');
  ctx.font=`${bodySize}px "Noto Sans Bengali","Noto Sans Devanagari","Noto Sans",Arial,sans-serif`;
  const maxW=W-margin*2;
  for(const raw of String(text||'').split(/\r?\n/)){
    if(!raw){lines.push('');continue} let cur='';
    for(const ch of raw){const test=cur+ch;if(cur&&ctx.measureText(test).width>maxW){lines.push(cur);cur=ch}else cur=test} lines.push(cur)
  }
  const pages=[];let idx=0;while(idx<lines.length||!pages.length){const c=document.createElement('canvas');c.width=W*2;c.height=H*2;const cx=c.getContext('2d');cx.fillStyle='#fff';cx.fillRect(0,0,c.width,c.height);cx.scale(2,2);cx.fillStyle='#111';cx.font=`bold ${titleSize}px "Noto Sans Bengali","Noto Sans Devanagari","Noto Sans",Arial,sans-serif`;cx.fillText(String(title||'MY LIFE OS Document'),margin,margin);cx.font=`${bodySize}px "Noto Sans Bengali","Noto Sans Devanagari","Noto Sans",Arial,sans-serif`;let y=margin+54;const maxY=H-margin;while(idx<lines.length&&y<=maxY){cx.fillText(lines[idx],margin,y);y+=lineH;idx++}pages.push({jpg:pdfDataUrlBytes(c.toDataURL('image/jpeg',.96)),w:c.width,h:c.height});if(idx>=lines.length)break}return pages
}
function downloadTextPdf(title,text,orientation='portrait'){const pages=renderTextPdfPages(title,text,orientation),blob=makeJpegPdfPages(pages,title,orientation),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(title||'document')+'.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1800);toast((orientation==='landscape'?'LANDSCAPE':'PORTRAIT')+' PDF CREATED ✓')}
function docPdf(){document.getElementById('docBody').innerHTML=`<div class="docPanel"><div class="docPanelHead"><div><span>PDF MAKER</span><h2>Make a strong, printable PDF</h2></div></div><div class="pdfModeRow"><span class="pdfModeLabel">PAGE ORIENTATION</span><button class="pdfModeBtn active" id="pdfPortraitBtn" onclick="setPdfOrientation('portrait')">▯ Portrait</button><button class="pdfModeBtn" id="pdfLandscapeBtn" onclick="setPdfOrientation('landscape')">▭ Landscape</button></div><div class="pdfGrid"><button class="bigDocBtn" onclick="docPickImagePdf()">🖼️<b>Image → PDF</b><small>Embed your image cleanly with the selected page orientation.</small></button><button class="bigDocBtn" onclick="docScanPdf()">📸<b>Scan → PDF</b><small>Scan notebook or project pages and combine them into one PDF.</small></button></div><div class="pdfStrength">✓ <b>PDF output:</b> multi-page document support, Unicode text rendering, and Portrait/Landscape page selection. Your exported file is a real <b>.pdf</b> document, not a screenshot download.</div><div id="docPdfPreview" class="docPreview">Choose an option to begin.</div></div>`;setPdfOrientation(window.docPdfOrientation||'portrait')}
function setPdfOrientation(mode){window.docPdfOrientation=mode==='landscape'?'landscape':'portrait';document.getElementById('pdfPortraitBtn')?.classList.toggle('active',window.docPdfOrientation==='portrait');document.getElementById('pdfLandscapeBtn')?.classList.toggle('active',window.docPdfOrientation==='landscape')}
function docTextPdf(){const txt=prompt('Write text for the PDF:','');if(txt===null)return;const title=prompt('PDF title:','MY LIFE OS Document')||'MY LIFE OS Document';downloadTextPdf(title,txt,window.docPdfOrientation||'portrait')}
function pdfAscii(s){return new TextEncoder().encode(s)}
function pdfDataUrlBytes(src){const bin=atob((src.split(',')[1]||''));const out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out}
function makeJpegPdf(jpg,imgW,imgH,title){const PW=595,PH=842,m=24,scale=Math.min((PW-2*m)/imgW,(PH-2*m)/imgH),w=imgW*scale,h=imgH*scale,x=(PW-w)/2,y=(PH-h)/2;const stream=`q ${w.toFixed(2)} 0 0 ${h.toFixed(2)} ${x.toFixed(2)} ${(PH-y-h).toFixed(2)} cm /Im Do Q`;const parts=[pdfAscii('%PDF-1.4\n')],offs=[0],pos=parts[0].length;const add=bytes=>{parts.push(bytes);pos+=bytes.length};const objs=[`<< /Type /Catalog /Pages 2 0 R >>`,`<< /Type /Pages /Kids [3 0 R] /Count 1 >>`,`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im 5 0 R >> >> /Contents 4 0 R >>`,`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`];for(let i=0;i<4;i++){offs[i+1]=pos;add(pdfAscii(`${i+1} 0 obj\n${objs[i]}\nendobj\n`))}offs[5]=pos;add(pdfAscii(`5 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imgW} /Height ${imgH} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`));add(jpg);add(pdfAscii('\nendstream\nendobj\n'));offs[6]=pos;add(pdfAscii(`6 0 obj\n<< /Title (${String(title||'MY LIFE OS Document').replace(/[\\()]/g,'')}) >>\nendobj\n`));const xref=pos;let tail='xref\n0 7\n0000000000 65535 f \n';for(let i=1;i<=6;i++)tail+=String(offs[i]).padStart(10,'0')+' 00000 n \n';tail+=`trailer\n<< /Size 7 /Root 1 0 R /Info 6 0 R >>\nstartxref\n${xref}\n%%EOF`;add(pdfAscii(tail));return new Blob(parts,{type:'application/pdf'})}
function downloadTextPdf(title,text){const W=1240,H=1754,c=document.createElement('canvas');c.width=W;c.height=H;const ctx=c.getContext('2d',{alpha:false});ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);const fs='"Noto Sans Bengali","Noto Sans","Nirmala UI","Arial Unicode MS",sans-serif';ctx.fillStyle='#111';ctx.textBaseline='top';ctx.font='bold 46px '+fs;ctx.fillText(String(title||'MY LIFE OS Document'),80,70);ctx.font='28px '+fs;let y=150;const maxW=W-160,lineH=48;for(const line of String(text||'').split(/\r?\n/)){let cur='';for(const ch of line){const test=cur+ch;if(ctx.measureText(test).width>maxW&&cur){ctx.fillText(cur,80,y);y+=lineH;cur=ch;if(y>H-100)break}else cur=test}if(y>H-100)break;ctx.fillText(cur,80,y);y+=lineH}const blob=makeJpegPdf(pdfDataUrlBytes(c.toDataURL('image/jpeg',.94)),W,H,title);const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(title||'document')+'.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500);toast('UNICODE PDF CREATED ✓')}
function docImageLab(){
  document.getElementById('docBody').innerHTML=`<div class="docPanel"><div class="docPanelHead"><div><span>IMAGE LAB</span><h2>Convert & compress images</h2></div><button type="button" onclick="docPickFormatImage()">＋ Choose Image</button></div><div class="docQuickGrid" style="margin-top:14px"><button type="button" onclick="docPickFormatImage()"><b>🔄 Image Format Converter</b><small>JPG • PNG • WEBP • Resize • Quality</small></button></div><div id="docFormatPreview" class="docPreview">Choose an image to convert between formats.</div></div>`;
  if(docState.formatImage)docFormatRender(docState.formatImage,docState.formatName||'image');
}
function docPickFormatImage(){document.getElementById('docFormatInput')?.click()}
function docFormatLoaded(ev){const f=ev?.target?.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{docState.formatImage=r.result;docState.formatName=f.name;docTab('image');setTimeout(()=>docFormatRender(r.result,f.name),20)};r.readAsDataURL(f);if(ev.target)ev.target.value=''}
function docFormatRender(src,name){const p=document.getElementById('docFormatPreview');if(!p)return;const base=String(name||'image').replace(/\.[^.]+$/,'');p.innerHTML=`<div style="text-align:center"><img class="docImagePreview" src="${src}" alt="Selected image"></div><div class="docImageControls" style="margin-top:14px;display:flex;flex-wrap:wrap;gap:10px;align-items:end"><label>Width <input id="dfWidth" type="number" min="100" max="5000" value="1200"></label><label>Quality <input id="dfQuality" type="range" min="30" max="100" value="90" oninput="document.getElementById('dfQualityValue').textContent=this.value+'%'"> <b id="dfQualityValue">90%</b></label><label>Format <select id="dfFormat"><option value="image/jpeg">JPG</option><option value="image/png">PNG</option><option value="image/webp">WEBP</option></select></label><button type="button" onclick="docConvertFormat()">⬇ Convert & Download</button></div><div style="margin-top:10px;color:#7d8aa3;font-size:10px">Original: ${esc(name||'image')} • Choose a format and tap Convert & Download.</div>`;p.dataset.base=base}
function docConvertFormat(){const src=docState.formatImage;if(!src)return toast('Choose an image first');const width=Math.max(100,Math.min(5000,Number(document.getElementById('dfWidth')?.value||1200)));const quality=Math.max(0.3,Math.min(1,Number(document.getElementById('dfQuality')?.value||90)/100));const type=document.getElementById('dfFormat')?.value||'image/jpeg';const ext=type==='image/png'?'png':type==='image/webp'?'webp':'jpg';const im=new Image();im.onload=()=>{const h=Math.max(1,Math.round(im.naturalHeight*width/im.naturalWidth));const c=document.createElement('canvas');c.width=width;c.height=h;const ctx=c.getContext('2d',{alpha:type!=='image/jpeg'});if(type==='image/jpeg'){ctx.fillStyle='#fff';ctx.fillRect(0,0,width,h)}ctx.drawImage(im,0,0,width,h);c.toBlob(blob=>{if(!blob)return toast('Conversion failed');const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(document.getElementById('docFormatPreview')?.dataset.base||'my-life-os-image')+'.'+ext;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1200);toast(ext.toUpperCase()+' IMAGE CREATED ✓')},type,quality)};im.onerror=()=>toast('Could not read image');im.src=src}

function docImageLoaded(ev,toPdf){const f=ev.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{if(toPdf){docState.pdfImage=r.result;docImageToPdf(r.result,f.name)}else{docState.image=r.result;docTab('image');setTimeout(()=>docShowImageTools(r.result),50)}};r.readAsDataURL(f);ev.target.value=''}
function docShowImageTools(src){const box=document.getElementById('docImagePreview');if(!box)return;box.innerHTML=`<img class="docImagePreview" src="${src}"><div class="docImageControls"><label>Width <input id="diw" type="number" value="1200"></label><label>Quality <input id="diq" type="range" min="30" max="100" value="85"></label><button onclick="docConvertImage('image/jpeg')">JPG</button><button onclick="docConvertImage('image/png')">PNG</button><button onclick="docDownloadCompressed()">Compress</button></div>`}
function docCompareOpen(){const p=document.getElementById('docComparePanel');if(!p)return;p.style.display='block';docCompareRender();p.scrollIntoView({behavior:'smooth',block:'nearest'})}
function docCompareLoaded(ev,side){const f=ev?.target?.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{docState[side==='a'?'compareA':'compareB']=r.result;docState.comparePos=50;docCompareOpen()};r.readAsDataURL(f);if(ev.target)ev.target.value=''}
function docCompareRender(){
  const p=document.getElementById('docComparePanel');if(!p)return;
  const a=docState.compareA,b=docState.compareB,pos=Math.max(0,Math.min(100,Number(docState.comparePos??50)));
  const imgA=a?'<img src="'+a+'" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">':'';
  const imgB=b?'<img src="'+b+'" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;clip-path:inset(0 '+(100-pos)+'% 0 0);border-right:2px solid #25dfff;box-shadow:8px 0 24px #0006">':'';
  p.innerHTML=`<div style="border:1px solid #26344e;border-radius:16px;background:#0a101b;padding:14px"><div class="docPanelHead"><div><span>COMPARE IMAGES</span><h2 style="margin-top:5px">Before ↔ After</h2></div><button type="button" onclick="docCompareClose()">× Close</button></div><div class="docImageControls" style="justify-content:flex-start;margin-top:12px"><button type="button" onclick="document.getElementById('docCompareAInput')?.click()">＋ Image A</button><button type="button" onclick="document.getElementById('docCompareBInput')?.click()">＋ Image B</button></div><div class="docCompareStage" style="position:relative;margin-top:14px;min-height:260px;overflow:hidden;border:1px solid #26344e;border-radius:14px;background:#070b14">${imgA}${imgB}<div style="position:absolute;left:12px;top:10px;padding:5px 8px;border-radius:8px;background:#0009;color:#fff;font-size:10px;font-weight:800">${a?'IMAGE A':'Add Image A'}</div><div style="position:absolute;right:12px;top:10px;padding:5px 8px;border-radius:8px;background:#0009;color:#fff;font-size:10px;font-weight:800">${b?'IMAGE B':'Add Image B'}</div></div><div style="margin-top:12px"><label style="display:block;font-size:9px;color:#8d9ab0;margin-bottom:6px">COMPARE POSITION <b style="float:right;color:#fff">${pos}%</b></label><input id="docCompareRange" type="range" min="0" max="100" value="${pos}" style="width:100%" oninput="docState.comparePos=this.value;docCompareRender()"></div>${a&&b?'':'<div style="margin-top:10px;color:#7d8aa3;font-size:9px">Upload both images to use the before/after slider.</div>'}</div>`;
}
function docCompareClose(){const p=document.getElementById('docComparePanel');if(p)p.style.display='none'}

function docConvertImage(type){const im=new Image();im.onload=()=>{const w=Math.max(100,Math.min(4000,Number(document.getElementById('diw')?.value||1200))),h=Math.round(im.height*w/im.width),c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(im,0,0,w,h);c.toBlob(blob=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='my-life-os-image.'+(type==='image/png'?'png':'jpg');a.click();setTimeout(()=>URL.revokeObjectURL(a.href),800)},type,Number(document.getElementById('diq')?.value||85)/100)};im.src=docState.image}
function docDownloadCompressed(){docConvertImage('image/jpeg')}
function docImageToPdf(src,name){const im=new Image();im.onload=()=>{try{const orientation=window.docPdfOrientation||'portrait',{w:PW,h:PH}=pdfPageSize(orientation),max=1800,sc=Math.min(1,max/im.naturalWidth,max/im.naturalHeight),iw=Math.max(1,Math.round(im.naturalWidth*sc)),ih=Math.max(1,Math.round(im.naturalHeight*sc)),c=document.createElement('canvas');c.width=iw*2;c.height=ih*2;const ctx=c.getContext('2d',{alpha:false});ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(im,0,0,c.width,c.height);const blob=makeJpegPdfPages([{jpg:pdfDataUrlBytes(c.toDataURL('image/jpeg',.97)),w:c.width,h:c.height}],(name||'image').replace(/\.[^.]+$/,''),orientation);const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(name||'image').replace(/\.[^.]+$/,'')+'.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1800);const p=document.getElementById('docPdfPreview');if(p)p.innerHTML='<b>✓ PDF CREATED</b><br>'+orientation.toUpperCase()+' page • image embedded at high quality.';toast((orientation==='landscape'?'LANDSCAPE':'PORTRAIT')+' IMAGE PDF CREATED ✓')}catch(err){console.error(err);toast('PDF creation failed')}};im.onerror=()=>toast('Could not read image');im.src=src}
function docQuickTools(){document.getElementById('docBody').innerHTML=`<div class="docPanel"><div class="docPanelHead"><div><span>QUICK TOOLS</span><h2>Everyday utilities</h2></div></div><div class="quickToolsGrid"><div class="miniTool"><b>⌘ Calculator</b><input id="dcalc" placeholder="0"><div class="miniCalc"><button onclick="dcalcKey('7')">7</button><button onclick="dcalcKey('8')">8</button><button onclick="dcalcKey('9')">9</button><button onclick="dcalcKey('+')">+</button><button onclick="dcalcKey('4')">4</button><button onclick="dcalcKey('5')">5</button><button onclick="dcalcKey('6')">6</button><button onclick="dcalcKey('-')">−</button><button onclick="dcalcKey('1')">1</button><button onclick="dcalcKey('2')">2</button><button onclick="dcalcKey('3')">3</button><button onclick="dcalcKey('*')">×</button><button onclick="dcalcKey('0')">0</button><button onclick="dcalcKey('.')">.</button><button onclick="dcalcEq()">=</button><button onclick="dcalcClear()">AC</button></div></div><div class="miniTool"><b>◷ Stopwatch</b><div id="docStop" class="docTimer">00:00:00</div><div class="miniBtns"><button onclick="dstopStart()">Start</button><button onclick="dstopPause()">Pause</button><button onclick="dstopReset()">Reset</button></div></div><div class="miniTool"><b>◉ Timer</b><div class="timerInputs"><input id="dtm" type="number" value="5" min="0"><span>:</span><input id="dts" type="number" value="0" min="0" max="59"></div><div id="docTimer" class="docTimer">05:00</div><div class="miniBtns"><button onclick="dtStart()">Start</button><button onclick="dtPause()">Pause</button><button onclick="dtReset()">Reset</button></div></div></div>`}
let ds={run:false,start:0,el:0,int:null},dt={run:false,end:0,rem:300000,int:null};function dcalcKey(k){const e=document.getElementById('dcalc');if(e)e.value+=k}function dcalcClear(){const e=document.getElementById('dcalc');if(e)e.value=''}function dcalcEq(){const e=document.getElementById('dcalc');if(!e||!e.value)return;try{if(!/^[0-9+*/().\s-]+$/.test(e.value))throw 0;e.value=String(Function('return ('+e.value+')')())}catch{e.value='Error'}}function dstopStart(){if(ds.run)return;ds.run=true;ds.start=Date.now();ds.int=setInterval(()=>{const ms=Date.now()-ds.start+ds.el;const e=document.getElementById('docStop');if(e)e.textContent=new Date(ms).toISOString().slice(11,19)},100)}function dstopPause(){if(!ds.run)return;ds.el+=Date.now()-ds.start;ds.run=false;clearInterval(ds.int)}function dstopReset(){ds={run:false,start:0,el:0,int:null};const e=document.getElementById('docStop');if(e)e.textContent='00:00:00'}function dtStart(){if(dt.run)return;const m=Number(document.getElementById('dtm')?.value||0),s=Number(document.getElementById('dts')?.value||0);dt.rem=(m*60+s)*1000;if(!dt.rem)return;dt.run=true;dt.end=Date.now()+dt.rem;dt.int=setInterval(()=>{dt.rem=Math.max(0,dt.end-Date.now());const e=document.getElementById('docTimer');if(e)e.textContent=`${String(Math.floor(dt.rem/60000)).padStart(2,'0')}:${String(Math.ceil((dt.rem%60000)/1000)%60).padStart(2,'0')}`;if(!dt.rem){dtPause();alert('Timer finished!')}},100)}function dtPause(){dt.run=false;clearInterval(dt.int);dt.int=null}function dtReset(){dtPause();dt.rem=(Number(document.getElementById('dtm')?.value||5)*60+Number(document.getElementById('dts')?.value||0))*1000;const e=document.getElementById('docTimer');if(e)e.textContent=`${String(Math.floor(dt.rem/60000)).padStart(2,'0')}:${String(Math.floor((dt.rem%60000)/1000)).padStart(2,'0')}`}

function studioOpenImage(){document.getElementById('studioImageInput').click()}
function studioImageLoaded(e){const f=e.target.files?.[0];if(!f)return;const img=new Image();img.onload=()=>{const scale=Math.min(1,850/Math.max(img.width,img.height));const o={id:crypto.randomUUID(),type:'image',name:f.name,x:540,y:540,w:img.width*scale,h:img.height*scale,img,opacity:1,rotation:0,filter:'none'};studio.layers.push(o);studio.selected=o.id;studioSaveHistory();studioRender();studioToast('Image imported')};img.src=URL.createObjectURL(f);e.target.value=''}
function studioPointerDown(e){if(studio.tool!=='draw'&&studio.tool!=='select')return;const r=studio.canvas.getBoundingClientRect(),sx=studio.canvas.width/r.width,sy=studio.canvas.height/r.height;const x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy;if(studio.tool==='draw'){studio.drawing=true;const o={id:crypto.randomUUID(),type:'draw',x,y,points:[{x,y}],color:'#8b7cff',size:8,opacity:1};studio.layers.push(o);studio.selected=o.id}else{studio.selected=studioHit(x,y)}studioRender()}
function studioPointerMove(e){if(!studio.drawing)return;const r=studio.canvas.getBoundingClientRect(),sx=studio.canvas.width/r.width,sy=studio.canvas.height/r.height,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy,o=studio.layers.find(a=>a.id===studio.selected);if(o)o.points.push({x,y});studioRender()}
function studioPointerUp(){if(studio.drawing){studio.drawing=false;studioSaveHistory();studioRender()}}
function studioHit(x,y){for(let i=studio.layers.length-1;i>=0;i--){const o=studio.layers[i];if(o.locked)continue;let hit=false;if(o.type==='circle')hit=Math.hypot(x-o.x,y-o.y)<=o.r+12;else if(o.type==='rect'||o.type==='image')hit=x>=o.x-o.w/2&&x<=o.x+o.w/2&&y>=o.y-o.h/2&&y<=o.y+o.h/2;else if(o.type==='text')hit=Math.abs(x-o.x)<(o.size*(o.text||'Text').length*.32+30)&&Math.abs(y-o.y)<o.size/2+25;else if(o.type==='draw')hit=o.points.some(p=>Math.hypot(x-p.x,y-p.y)<18);if(hit)return o.id}return null}
function studioUpdateLayers(){const el=document.getElementById('studioLayers');if(!el)return;if(!studio.layers.length){el.innerHTML='<div class="studioEmpty">Add text, shapes or an image to start building.</div>';document.getElementById('studioLayerCount').textContent='0 layers';return}el.innerHTML=studio.layers.slice().reverse().map(o=>`<div class="layerRow ${o.id===studio.selected?'selected':''} ${o.locked?'locked':''}" onclick="studioSelect('${o.id}')"><div class="layerThumb">${o.type==='image'&&o.img?`<img src="${o.img.src}">`:o.type==='text'?'T':o.type==='circle'?'●':'▰'}</div><div class="layerMeta"><b>${esc(o.name||o.text||o.type.toUpperCase())}</b><span>${o.type} • ${Math.round((o.opacity??1)*100)}%</span></div><button class="layerLock" title="${o.locked?'Unlock':'Lock'}" onclick="event.stopPropagation();studioToggleLock('${o.id}')">${o.locked?'🔒':'🔓'}</button><button class="layerDelete" title="Remove" onclick="event.stopPropagation();studioDelete('${o.id}')">🗑</button></div>`).join('');document.getElementById('studioLayerCount').textContent=studio.layers.length+' layer'+(studio.layers.length>1?'s':'');}

function studioSelect(id){studio.selected=id;studioRender()}
function studioSelected(){return studio.layers.find(o=>o.id===studio.selected)}
function studioUpdateProps(){const el=document.getElementById('studioProps'),o=studioSelected();if(!o){el.className='studioEmpty';el.innerHTML='Select a layer to edit its properties.';return}el.className='';let common=`<div class="propGrid"><div class="prop"><label>X</label><input type="number" value="${Math.round(o.x)}" oninput="studioSet('x',this.value)"></div><div class="prop"><label>Y</label><input type="number" value="${Math.round(o.y)}" oninput="studioSet('y',this.value)"></div><div class="prop"><label>ROTATION</label><input type="number" value="${Math.round(o.rotation||0)}" oninput="studioSet('rotation',this.value)"></div><div class="prop"><label>OPACITY</label><div class="rangeRow"><input type="range" min="0" max="100" value="${Math.round((o.opacity??1)*100)}" oninput="studioSet('opacity',this.value/100)"><span class="rangeValue">${Math.round((o.opacity??1)*100)}%</span></div></div></div>`;let extra='';if(o.type==='text')extra=`<div class="prop" style="margin-top:9px"><label>TEXT</label><input value="${esc(o.text)}" oninput="studioSetText(this.value)"></div><div class="propGrid" style="margin-top:8px"><div class="prop"><label>SIZE</label><input type="number" value="${o.size}" oninput="studioSet('size',this.value)"></div><div class="prop"><label>COLOR</label><input type="color" value="${o.color}" oninput="studioSet('color',this.value)"></div></div>`;else if(['rect','circle'].includes(o.type))extra=`<div class="prop" style="margin-top:9px"><label>COLOR</label><input type="color" value="${o.color}" oninput="studioSet('color',this.value)"></div>`;el.innerHTML=common+extra}
function studioSet(k,v){const o=studioSelected();if(!o||o.locked)return;o[k]=k==='opacity'?+v:+v;studioRender();studioSaveHistory()}
function studioSetText(v){const o=studioSelected();if(!o||o.locked)return;o.text=v;studioRender();studioSaveHistory()}
function studioDelete(id){studio.layers=studio.layers.filter(o=>o.id!==id);if(studio.selected===id)studio.selected=null;studioSaveHistory();studioRender()}
function studioDeleteSelected(){if(studio.selected)studioDelete(studio.selected)}
function studioDuplicate(){const o=studioSelected();if(!o||o.locked)return;const n={...o,id:crypto.randomUUID(),x:o.x+35,y:o.y+35};if(o.points)n.points=o.points.map(p=>({...p,x:p.x+35,y:p.y+35}));studio.layers.push(n);studio.selected=n.id;studioSaveHistory();studioRender()}
function studioBring(dir){const i=studio.layers.findIndex(o=>o.id===studio.selected);if(i<0||studio.layers[i].locked)return;const [o]=studio.layers.splice(i,1);studio.layers.splice(dir==='front'?studio.layers.length:0,0,o);studioSaveHistory();studioRender()}
function studioRotate(deg){const o=studioSelected();if(!o||o.locked)return;o.rotation=(o.rotation||0)+deg;studioSaveHistory();studioRender()}
function studioFilter(kind){const o=studioSelected();if(!o||o.locked||o.type!=='image'){studioToast('Select an image layer first');return}o.filter={normal:'none',gray:'grayscale(1)',bright:'brightness(1.25)',contrast:'contrast(1.35)',vivid:'saturate(1.5)',soft:'brightness(1.08) saturate(.85) contrast(.9)'}[kind];studioSaveHistory();studioRender()}
function studioBackground(){studioModal(`<div class="modalHeader"><h2>Canvas Background</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="prop"><label>COLOR</label><input id="studioBgColor" type="color" value="${studio.bg}" style="width:100%;height:45px"></div><div class="tools" style="margin-top:12px"><button class="btn" onclick="studio.bg=document.getElementById('studioBgColor').value;studioSaveHistory();studioRender();studioCloseModal()">Apply</button><button class="btn ghost" onclick="studioCloseModal()">Cancel</button></div>`)}
function studioNew(){studio.layers=[];studio.selected=null;studio.bg='#ffffff';studioSaveHistory();studioRender();studioToast('New canvas')}
function studioExport(type){studioRender();const a=document.createElement('a');a.download='creative-studio.'+type;a.href=studio.canvas.toDataURL(type==='jpg'?'image/jpeg':'image/png',.92);a.click();studioToast('Exported '+type.toUpperCase())}
function studioZoom(v){studio.zoom=Math.max(.5,Math.min(2,studio.zoom*v));document.getElementById('studioZoomLabel').textContent=Math.round(studio.zoom*100)+'%';document.getElementById('studioCanvas').style.transform=`scale(${studio.zoom})`;document.getElementById('studioCanvas').style.transformOrigin='center'}
function studioFit(){studio.zoom=1;document.getElementById('studioZoomLabel').textContent='100%';document.getElementById('studioCanvas').style.transform='none'}
function studioTemplates(){studioModal(`<div class="modalHeader"><h2>Design Templates</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="templateGrid"><button class="templateCard" onclick="studioTemplate('poster');studioCloseModal()"><div class="templatePreview" style="background:linear-gradient(135deg,#10152a,#7d72ff);color:#fff">CREATE</div><b>Creative Poster</b><small>1080 × 1080</small></button><button class="templateCard" onclick="studioTemplate('social');studioCloseModal()"><div class="templatePreview" style="background:linear-gradient(135deg,#071d25,#39dfcf);color:#071018">HELLO</div><b>Social Card</b><small>1080 × 1080</small></button><button class="templateCard" onclick="studioTemplate('quote');studioCloseModal()"><div class="templatePreview" style="background:#151822;color:#8b7cff">MAKE<br>IT REAL</div><b>Quote</b><small>1080 × 1080</small></button></div>`)}
function studioTemplate(t){studio.layers=[];studio.bg=t==='social'?'#08171d':t==='quote'?'#151822':'#10152a';if(t==='poster'){studio.layers.push({id:crypto.randomUUID(),type:'text',text:'CREATE',x:540,y:470,size:118,color:'#ffffff',weight:900,font:'Arial',opacity:1,rotation:0},{id:crypto.randomUUID(),type:'text',text:'BUILD SOMETHING GREAT',x:540,y:590,size:34,color:'#39dfcf',weight:800,font:'Arial',opacity:1,rotation:0})}if(t==='social'){studio.layers.push({id:crypto.randomUUID(),type:'circle',x:540,y:540,r:230,color:'#39dfcf',opacity:.18,rotation:0},{id:crypto.randomUUID(),type:'text',text:'HELLO',x:540,y:520,size:120,color:'#ffffff',weight:900,font:'Arial',opacity:1,rotation:0})}if(t==='quote'){studio.layers.push({id:crypto.randomUUID(),type:'text',text:'MAKE\nIT REAL',x:540,y:520,size:92,color:'#8b7cff',weight:900,font:'Arial',opacity:1,rotation:0})}studio.selected=studio.layers[0]?.id;studioSaveHistory();studioRender();studioToast('Template loaded')}
function studioModal(html){document.getElementById('studioModalCard').innerHTML=html;document.getElementById('studioModal').classList.add('open')}
function studioCloseModal(){document.getElementById('studioModal').classList.remove('open')}
function studioToast(msg){let x=document.querySelector('.studioToast');x?.remove();x=document.createElement('div');x.className='studioToast';x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),1600)}
function studioMobilePanel(which){
  const d=document.getElementById('studioMobileDrawer'),title=document.getElementById('studioMobileDrawerTitle'),body=document.getElementById('studioMobileDrawerBody');
  if(!d||!title||!body)return;
  document.querySelectorAll('.studioMobileBar button').forEach(b=>b.classList.remove('active'));
  const btn=[...document.querySelectorAll('.studioMobileBar button')].find(b=>(which==='create'&&b.textContent.includes('Create'))||(which==='layers'&&b.textContent.includes('Layers'))||(which==='properties'&&b.textContent.includes('Properties')));btn?.classList.add('active');
  if(which==='create'){studioCloseMobileDrawer();studioToast('Create tools are available in the top toolbar and editor panels');return}
  title.textContent=which==='layers'?'LAYERS':'PROPERTIES';
  body.innerHTML=which==='layers'?document.getElementById('studioLayers').innerHTML:document.getElementById('studioProps').innerHTML;
  d.classList.add('open');
  if(which==='layers')body.querySelectorAll('.layerRow').forEach(r=>{const id=r.getAttribute('onclick')?.match(/'([^']+)'/)?.[1];if(id)r.setAttribute('onclick',`studioMobileSelect('${id}')`)});
}
function studioMobileSelect(id){studioSelect(id);studioMobilePanel('properties')}
function studioCloseMobileDrawer(){document.getElementById('studioMobileDrawer')?.classList.remove('open')}
function formModal(title,body,submit){openModal(`<div class="modalHeader"><h2>${title}</h2><button class="iconBtn" onclick="closeModal()">×</button></div><form class="form" onsubmit="${submit}">${body}</form>`)}
function editMission(){formModal("Today's Mission",`<textarea id="m1" required>${esc(state.mission)}</textarea><button class="btn" type="submit">Save Mission</button>`,"event.preventDefault();state.mission=document.getElementById('m1').value;save();closeModal();render()")}
function editQuote(){formModal("Daily Motivation",`<textarea id="q1" required>${esc(state.quote)}</textarea><button class="btn" type="submit">Save Quote</button>`,"event.preventDefault();state.quote=document.getElementById('q1').value;save();closeModal();render()")}
function addPriority(){formModal("Add Priority",`<input id="p1" placeholder="Today's priority" required><button class="btn" type="submit">Add</button>`,"event.preventDefault();state.priorities.push({text:document.getElementById('p1').value,done:false});save();closeModal();render()")}
function togglePriority(i){state.priorities[i].done=!state.priorities[i].done;save();render()}
function deletePriority(i){
  if(!state.priorities[i]) return;
  const name=state.priorities[i].text;
  if(confirm(`Delete "${name}"?`)){
    state.priorities.splice(i,1);
    save();
    render();
    toast("Priority deleted");
  }
}
function changeStudy(i,d){state.study[i].progress=Math.max(0,Math.min(100,state.study[i].progress+d));if(d>0)state.streak=Math.max(1,state.streak||1);save();render()}
function subjectPanel(i,t){
let s=state.study[i];let body="";
if(t==="Progress")body=`<div class="stat">${s.progress}%</div><div class="progress"><i style="width:${s.progress}%"></i></div><div class="tools" style="margin-top:13px"><button class="btn" onclick="changeStudy(${i},5);closeModal()">＋5%</button><button class="btn ghost" onclick="changeStudy(${i},-5);closeModal()">−5%</button></div>`;
else if(t==="Notes")body=`<textarea id="sp" placeholder="Write a note... Line breaks and paragraphs will stay inside ONE saved note."></textarea><button class="btn" onclick="saveSubject(${i},'notes')">Save Notes</button><div class="notice" style="margin-top:13px;border-left-color:var(--cyan)"><b>Saved Notes</b><div class="small muted" style="margin-top:5px">Notes belong only to <b>${esc(s.name)}</b>. Everything you type before one Save is stored as one note, including spaces and line breaks. Save again for a separate note.</div></div><div class="savedLineList">${subjectLineList(i,'notes','N')}</div>`;
else if(t==="Questions")body=`<textarea id="sp" placeholder="Write important questions... One question per line."></textarea><button class="btn" onclick="saveSubject(${i},'questions')">Save Questions</button><div class="notice" style="margin-top:13px;border-left-color:var(--cyan)"><b>Saved Questions</b><div class="small muted" style="margin-top:5px">Questions belong only to <b>${esc(s.name)}</b>. Use one question per line; each non-empty line becomes its own saved question. The typing area clears after saving.</div></div><div class="savedLineList">${subjectLineList(i,'questions','Q')}</div>`;
else if(t==="Revision")body=`<textarea id="sp" placeholder="Write revision points... One point per line."></textarea><button class="btn" onclick="saveSubject(${i},'revision')">Save Revision</button><div class="notice" style="margin-top:13px;border-left-color:var(--cyan)"><b>Saved Revision</b><div class="small muted" style="margin-top:5px">Revision belongs only to <b>${esc(s.name)}</b>. Use one point per line; each non-empty line becomes its own saved revision item. The typing area clears after saving.</div></div><div class="savedLineList">${subjectLineList(i,'revision','R')}</div>`;
else body=`<div class="notice" style="margin-bottom:12px;border-left-color:var(--cyan)">Save a chapter first, then open it to keep its own <b>Important Notes</b>, <b>Important Questions</b> and <b>Revision</b>. Everything stays linked to that chapter.</div><div class="form"><input id="ch" placeholder="Chapter name" required><button class="btn" onclick="addChapter(${i})">＋ Add Chapter</button></div><div style="margin-top:13px">${s.chapters.map((c,j)=>{let q=(c.questions||"").trim();let n=(c.notes||"").trim();let r=(c.revision||"").trim();return `<div class="chapterItem ${c.done?"completed":""}"><div class="chapterMain"><label class="priority" style="border:0;padding:0"><input class="check" type="checkbox" ${c.done?"checked":""} onchange="toggleChapter(${i},${j})"><span><b>${esc(c.name)}</b><small>${c.done?"✓ Completed":"In Progress"} • ${q?"Questions saved":"No questions yet"} • ${n?"Notes saved":"No notes yet"} • ${r?"Revision saved":"No revision yet"}</small></span></label><div class="tools"><button class="btn ghost" onclick="chapterWorkspace(${i},${j})">Open Chapter →</button><button class="btn danger" onclick="deleteChapter(${i},${j})">🗑 Delete</button></div></div></div>`}).join("")||'<div class="empty">No chapters yet. Add your first chapter above.</div>'}</div>`;
openModal(`<div class="modalHeader"><h2>${esc(s.name)} • ${t}</h2><button class="iconBtn" onclick="closeModal()">×</button></div>${body}`)
}
function subjectItems(s,key){
  if(!s)return [];
  const arrKey=key==='notes'?'noteItems':key==='questions'?'questionItems':'revisionItems';
  if(Array.isArray(s[arrKey]))return s[arrKey].filter(x=>typeof x==='string'&&x.trim()).map(x=>x);
  const raw=String(s[key]||'');
  if(!raw.trim())return [];
  // Backward compatibility: old Notes remain ONE note so paragraph breaks are preserved.
  if(key==='notes')return [raw];
  return raw.split(/\n+/).map(x=>x.trim()).filter(Boolean);
}
function syncSubjectLegacy(s,key,items){
  const arrKey=key==='notes'?'noteItems':key==='questions'?'questionItems':'revisionItems';
  s[arrKey]=items.slice();
  // Keep the old string fields too, so older MY LIFE OS data remains compatible.
  s[key]=items.join(key==='notes'?'\n\n':'\n');
}
function subjectLineList(i,key,label){
  const s=state.study[i];
  const lines=subjectItems(s,key);
  if(!lines.length)return `<div class="empty">No ${key} saved for this subject yet.</div>`;
  return lines.map((text,j)=>`<div class="savedLine"><div class="savedLineText"><span class="savedLineLabel">${label}${j+1}</span>${esc(text)}</div><div class="savedLineActions"><button class="btn ghost" onclick="editSubjectLine(${i},'${key}',${j})">Edit</button><button class="btn danger" onclick="deleteSubjectLine(${i},'${key}',${j})">Delete</button></div></div>`).join("");
}
function subjectQuestionList(i){return subjectLineList(i,'questions','Q')}
function saveSubject(i,k){
  const s=state.study[i]; if(!s)return;
  const area=document.getElementById("sp"); if(!area)return;
  const value=area.value||"";
  if(!value.trim()){toast(`Write something before saving ${k}`);area.focus();return}
  let items=subjectItems(s,k);
  if(k==='notes'){
    // A whole save = ONE note. Internal line breaks/paragraphs are preserved exactly.
    items.push(value.replace(/\r\n/g,'\n').replace(/\r/g,'\n').trim());
  }else{
    // Questions and Revision keep the earlier one-line-per-item behavior.
    items.push(...value.split(/\n+/).map(x=>x.trim()).filter(Boolean));
  }
  syncSubjectLegacy(s,k,items); save();
  area.value=''; area.focus();
  const title=k==='notes'?'Note':k==='questions'?'Question':'Revision';
  subjectPanel(i,k==='notes'?'Notes':k==='revision'?'Revision':'Questions');
  setTimeout(()=>document.getElementById('sp')?.focus(),40);
  toast(`${title}${k==='notes'?'':'s'} saved to ${s.name}`);
}
function editSubjectLine(i,k,j){
  const s=state.study[i],items=subjectItems(s,k); if(!items[j])return;
  openModal(`<div class="modalHeader"><h2>Edit ${k==='notes'?'Note':k==='questions'?'Question':'Revision'} • ${esc(s.name)}</h2><button class="iconBtn" onclick="subjectPanel(${i},'${k==='notes'?'Notes':k==='revision'?'Revision':'Questions'}')">×</button></div><textarea id="editSubjectText" style="width:100%;min-height:180px;background:#090e18;border:1px solid #273046;color:#fff;border-radius:11px;padding:12px;line-height:1.55;resize:vertical">${esc(items[j])}</textarea><div class="tools" style="margin-top:12px"><button class="btn" onclick="updateSubjectLine(${i},'${k}',${j})">Save Changes</button><button class="btn ghost" onclick="subjectPanel(${i},'${k==='notes'?'Notes':k==='revision'?'Revision':'Questions'}')">Cancel</button></div>`);
  setTimeout(()=>document.getElementById('editSubjectText')?.focus(),40);
}
function updateSubjectLine(i,k,j){
  const s=state.study[i],items=subjectItems(s,k);if(!items[j])return;
  const text=document.getElementById('editSubjectText')?.value||'';if(!text.trim()){toast(`${k} cannot be empty`);return}
  items[j]=text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').trim();syncSubjectLegacy(s,k,items);save();subjectPanel(i,k==='notes'?'Notes':k==='revision'?'Revision':'Questions');toast(`${k==='notes'?'Note':k==='questions'?'Question':'Revision'} updated in ${s.name}`)
}
function deleteSubjectLine(i,k,j){
  const s=state.study[i],items=subjectItems(s,k);if(!items[j])return;
  if(!confirm(`Delete ${k} ${j+1} from ${s.name}?`))return;
  items.splice(j,1);syncSubjectLegacy(s,k,items);save();subjectPanel(i,k==='notes'?'Notes':k==='revision'?'Revision':'Questions');toast(`${k.charAt(0).toUpperCase()+k.slice(1)} deleted from ${s.name}`)
}
function addChapter(i){let x=document.getElementById("ch").value.trim();if(!x)return;state.study[i].chapters.push({name:x,done:false,notes:"",questions:"",revision:""});save();subjectPanel(i,"Chapters");toast("Chapter saved — open it to add notes & questions")}
function toggleChapter(i,j){if(!state.study[i].chapters[j])return;state.study[i].chapters[j].done=!state.study[i].chapters[j].done;let done=state.study[i].chapters.filter(x=>x.done).length;let total=state.study[i].chapters.length;if(total)state.study[i].progress=Math.max(state.study[i].progress,Math.round(done/total*100));save();subjectPanel(i,"Chapters")}
function deleteChapter(i,j){let s=state.study[i],c=s.chapters[j];if(!c)return;let name=c.name;if(!confirm(`Delete chapter “${name}” and all its saved notes, questions and revision data?`))return;s.chapters.splice(j,1);save();subjectPanel(i,"Chapters");toast("Chapter deleted")}
function chapterWorkspace(i,j){
let s=state.study[i],c=s.chapters[j];
if(!c){return}
let q=(c.questions||"");let n=(c.notes||"");let r=(c.revision||"");
openModal(`<div class="modalHeader"><div><span class="eyebrow">${esc(s.name.toUpperCase())} • CHAPTER WORKSPACE</span><h2 style="margin:5px 0 0">${esc(c.name)}</h2></div><button class="iconBtn" onclick="subjectPanel(${i},'Chapters')">←</button></div><div class="chapterHero"><div><span class="pill">${c.done?"✓ COMPLETED":"IN PROGRESS"}</span><div class="small muted" style="margin-top:8px">Build your own mini knowledge page for this chapter.</div></div><button class="btn ${c.done?"danger":"cyan"}" onclick="toggleChapter(${i},${j});chapterWorkspace(${i},${j})">${c.done?"Mark Incomplete":"Mark Completed"}</button></div><div class="chapterGrid"><div class="chapterBox"><div class="chapterBoxHead"><b>📝 Important Notes</b><span class="pill">Chapter-specific</span></div><textarea id="cn" placeholder="Definitions, formulas, concepts, examples, things you must remember...">${esc(n)}</textarea></div><div class="chapterBox"><div class="chapterBoxHead"><b>❓ Important Questions</b><span class="pill">Exam focus</span></div><textarea id="cq" placeholder="1. Write the important question...
2. Explain...
3. Compare...">${esc(q)}</textarea></div><div class="chapterBox"><div class="chapterBoxHead"><b>🔁 Revision</b><span class="pill">Quick review</span></div><textarea id="cr" placeholder="Revision points, formulas, keywords, last-minute checklist...">${esc(r)}</textarea></div></div><div class="tools" style="margin-top:14px"><button class="btn" onclick="saveChapterWorkspace(${i},${j})">Save Chapter Data</button><button class="btn danger" onclick="deleteChapterFromWorkspace(${i},${j})">🗑 Delete Chapter</button><button class="btn ghost" onclick="subjectPanel(${i},'Chapters')">Back to Chapters</button></div>`);
}
function saveChapterWorkspace(i,j){let c=state.study[i].chapters[j];if(!c)return;c.notes=document.getElementById("cn").value;c.questions=document.getElementById("cq").value;c.revision=document.getElementById("cr").value;save();toast("Chapter notes & questions saved");chapterWorkspace(i,j)}
function deleteChapterFromWorkspace(i,j){if(!state.study[i].chapters[j])return;if(!confirm(`Delete “${state.study[i].chapters[j].name}” and all its saved data?`))return;state.study[i].chapters.splice(j,1);save();subjectPanel(i,"Chapters");toast("Chapter deleted")}
function studySession(){formModal("Log Study Session",`<div class="formRow"><select id="ss">${state.study.map((x,i)=>`<option value="${i}">${esc(x.name)}</option>`).join("")}</select><input id="sh" type="number" min="0.1" step="0.1" placeholder="Hours" required></div><button class="btn" type="submit">Log Session</button>`,`event.preventDefault();let s=state.study[+document.getElementById('ss').value],h=+document.getElementById('sh').value;if(!s||!h||h<0.1)return;let d=new Date(),key=d.toISOString().slice(0,10);s.hours=(s.hours||0)+h;state.weekly[d.getDay()===0?6:d.getDay()-1]=(state.weekly[d.getDay()===0?6:d.getDay()-1]||0)+h;state.studyLog=Array.isArray(state.studyLog)?state.studyLog:[];state.studyLog.push({date:key,hours:h,subject:s.name,createdAt:d.toISOString()});state.studyLog=state.studyLog.slice(-500);state.streak=(state.streak||0)+1;save();closeModal();render();toast('Study session logged — weekly progress updated automatically')`)}
function addStudyNote(){let i=0;formModal("Quick Study Note",`<select id="qn">${subjects.map(x=>`<option>${x}</option>`).join("")}</select><textarea id="qt" placeholder="What do you want to remember?" required></textarea><button class="btn" type="submit">Save</button>`,"event.preventDefault();let s=state.study.find(x=>x.name===document.getElementById('qn').value);s.notes=(s.notes?s.notes+'\\n\\n':'')+document.getElementById('qt').value;save();closeModal();toast('Study note saved')")}
function newProject(p={},idx=-1){let files=(p.files||[]).map(x=>`<div class="fileChip">📎 ${esc(x.name)}</div>`).join("");openModal(`<div class="modalHeader"><h2>${idx>=0?"Edit":"New"} Project</h2><button class="iconBtn" onclick="closeModal()">×</button></div><form class="form" onsubmit="saveProject(event,${idx})"><input id="prTitle" value="${esc(p.title||"")}" placeholder="Project Name" required><textarea id="prDesc" placeholder="Project description">${esc(p.description||"")}</textarea><div class="formRow"><select id="prStatus"><option ${p.status==="Planned"?"selected":""}>Planned</option><option ${p.status==="In Progress"||!p.status?"selected":""}>In Progress</option><option ${p.status==="Completed"?"selected":""}>Completed</option></select><input id="prDeadline" type="date" value="${esc(p.deadlineISO||"")}"></div><div class="formRow"><input id="prProgress" type="number" min="0" max="100" value="${p.progress||0}" placeholder="Progress %"><input id="prLink" value="${esc(p.link||"")}" placeholder="Project link"></div><textarea id="prNotes" placeholder="Notes / final submission details">${esc(p.notes||"")}</textarea><div class="dropzone">📎 Add project files (images / PDF / documents)<br><input id="prFiles" type="file" multiple accept="image/*,.pdf,.doc,.docx,.ppt,.pptx,.txt"></div><div class="fileList">${files}</div><button class="btn" type="submit">Save Project</button></form>`)}
function saveProject(e,idx){e.preventDefault();let input=document.getElementById("prFiles");let old=idx>=0?(state.projects[idx].files||[]):[];let files=[...old,...[...(input.files||[])].map(f=>({name:f.name,type:f.type,size:f.size}))];let d=document.getElementById("prDeadline").value;let p={title:document.getElementById("prTitle").value,description:document.getElementById("prDesc").value,status:document.getElementById("prStatus").value,deadlineISO:d,deadline:d?new Date(d+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short"}):"No deadline",progress:Math.max(0,Math.min(100,+document.getElementById("prProgress").value||0)),link:document.getElementById("prLink").value,notes:document.getElementById("prNotes").value,files};if(idx>=0)state.projects[idx]=p;else state.projects.push(p);save();closeModal();render();toast("Project saved")}
function editProject(i){newProject(state.projects[i],i)}
function newKnowledge(){formModal("Save Knowledge",`<input id="kt" placeholder="Topic / title" required><select id="kg">${["Study","Design","Technology","Ideas","Skills","Future"].map(x=>`<option>${x}</option>`).join("")}</select><textarea id="kn" placeholder="What did you learn?"></textarea><button class="btn" type="submit">Save to Knowledge Base</button>`,"event.preventDefault();state.knowledge.push({title:document.getElementById('kt').value,tag:document.getElementById('kg').value,note:document.getElementById('kn').value,date:today()});save();closeModal();render()")}
function newGoal(){formModal("Future Goal",`<input id="gt" placeholder="Goal title" required><div class="formRow"><input id="gy" type="number" min="2026" max="2040" value="2027"><select id="gc"><option>Goals</option><option>Career</option><option>Financial Goals</option><option>Skills</option><option>Experiences</option><option>Achievements</option></select></div><textarea id="gn" placeholder="Why does this matter?"></textarea><button class="btn" type="submit">Add to Future Room</button>`,"event.preventDefault();state.goals.push({title:document.getElementById('gt').value,year:+document.getElementById('gy').value,category:document.getElementById('gc').value,note:document.getElementById('gn').value,done:false});save();closeModal();render()")}
function toggleGoal(i){state.goals[i].done=!state.goals[i].done;if(state.goals[i].done)state.achievements.push({title:state.goals[i].title,note:"Completed from Future Room",date:today()});save();render();toast(state.goals[i].done?"Goal completed 🏆":"Goal reopened")}
function newJournal(){formModal("Journal Entry",`<input id="jt" value="Daily Reflection" placeholder="Entry title"><textarea id="jx" placeholder="What did you learn today? What changed? What are you proud of?" required></textarea><button class="btn" type="submit">Save Entry</button>`,"event.preventDefault();state.journal.push({date:today(),title:document.getElementById('jt').value,text:document.getElementById('jx').value});save();closeModal();render()")}
function newAchievement(){formModal("Add Achievement",`<input id="at" placeholder="Achievement title" required><textarea id="an" placeholder="What happened?"></textarea><button class="btn" type="submit">Add to Wall</button>`,"event.preventDefault();state.achievements.push({title:document.getElementById('at').value,note:document.getElementById('an').value,date:today()});save();closeModal();render()")}
function removeItem(k,i){if(confirm("Delete this item?")){state[k].splice(i,1);save();render();toast("Deleted")}}
let vaultSession={pin:null,timer:null,visible:{}};
function b64Text(s){return btoa(unescape(encodeURIComponent(s)))}
function textB64(s){return decodeURIComponent(escape(atob(s)))}
function resetVaultTimer(){clearTimeout(vaultSession.timer);vaultSession.timer=setTimeout(()=>{vaultSession.pin=null;closeModal();toast("Secret Vault auto-locked 🔒")},state.vaultAutoLock||180000)}
function vaultPinModal(){
openModal(`<div class="pinPanel"><div class="eyebrow">SECURE ACCESS PROTOCOL</div><div class="vaultCore" style="max-width:125px;margin:12px auto"><div class="coreLock">🔒</div></div><h2>${state.settings.pinSet?"ENTER VAULT PIN":"CREATE VAULT PIN"}</h2><p class="muted">${state.settings.pinSet?"Identity verification required.":"Use at least 4 digits or characters."}</p><div class="scanLine"></div><input id="vaultPinInput" class="pinInput" type="password" inputmode="numeric" autocomplete="off" placeholder="••••••••" maxlength="32"><div class="tools" style="justify-content:center;margin-top:12px"><button class="btn" onclick="verifyVaultPin()">${state.settings.pinSet?"VERIFY ACCESS →":"INITIALIZE VAULT →"}</button><button class="btn ghost" onclick="closeModal()">Cancel</button></div><div class="small muted" style="margin-top:12px">🔐 PIN is never stored as plain text.</div></div>`);
setTimeout(()=>document.getElementById("vaultPinInput")?.focus(),80)
}
async function unlockVault(section){
if(!window.crypto||!crypto.subtle){alert("Secure Web Crypto is not available in this browser.");return}
if(vaultSession.pin){showVaultCore(section||"home");return}
vaultPinModal();
}
async function verifyVaultPin(){
let el=document.getElementById("vaultPinInput"),pin=el?.value||"";if(pin.length<4){toast("PIN must be at least 4 characters");return}
if(!state.settings.pinSet){state.settings.pinSet=true;state.vaultSalt=bufToB64(crypto.getRandomValues(new Uint8Array(16)));state.vaultVerifier=await makeVerifier(pin,state.vaultSalt);state.vaultItems=[];save();vaultSession.pin=pin;showVaultCore("home");toast("Vault initialized securely");return}
if(await makeVerifier(pin,state.vaultSalt)!==state.vaultVerifier){el.value="";el.classList.add("unlockFlash");setTimeout(()=>el.classList.remove("unlockFlash"),600);toast("Access denied • Wrong PIN");return}
vaultSession.pin=pin;showVaultCore("home");toast("SECURE ACCESS GRANTED ✓")
}
async function getVaultData(){
if(state.vaultItems&&state.vaultItems.length)return state.vaultItems;
if(state.vaultCipher){let old=await decryptNote(vaultSession.pin,state.vaultCipher,state.vaultSalt);if(old){state.vaultItems=[{id:Date.now(),type:"note",title:"Private Note",body:old,created:today()}];save();return state.vaultItems}}
return []
}
async function showVaultCore(section="home"){
resetVaultTimer();let items=await getVaultData();
let counts={note:items.filter(x=>x.type==="note").length,idea:items.filter(x=>x.type==="idea").length,plan:items.filter(x=>x.type==="plan").length,reminder:items.filter(x=>x.type==="reminder").length,secure:items.filter(x=>x.type==="secure").length};
let filtered=section==="home"?items:items.filter(x=>section==="notes"?x.type==="note":section==="plans"?x.type==="plan":section==="reminders"?x.type==="reminder":section==="secure"?x.type==="secure":true);
let tiles=[['note','📝','Private Notes',counts.note],['idea','💡','Future Ideas',counts.idea],['plan','🎯','Personal Plans',counts.plan],['reminder','⏰','Important Reminders',counts.reminder],['secure','🔑','Secure Entries',counts.secure]];
openModal(`<div class="vaultScreen" onclick="resetVaultTimer()"><div class="vaultTop"><div><span class="eyebrow">SECURE ACCESS GRANTED</span><h2 style="margin:6px 0 0">Vault Core</h2></div><button class="iconBtn" onclick="lockVault()">🔒</button></div><div class="vaultStatus" style="margin:13px 0"><span class="statusDot"></span> ENCRYPTED • SESSION ACTIVE</div><div class="vaultGrid">${tiles.map(t=>`<button class="vaultTile" onclick="vaultComposer('${t[0]}')">${t[1]} <b>${t[2]}</b><span>${t[3]} saved • Add / manage</span></button>`).join("")}</div><div class="sectionHead"><h3>${section==="home"?"Vault Memory":""}</h3><div class="tools"><button class="btn ghost" onclick="vaultSearch()">🔍 Search</button><button class="btn danger" onclick="lockVault()">Auto-lock / Exit</button></div></div><div id="vaultItems">${renderVaultItems(filtered)}</div><div class="small autoLock" style="text-align:center;margin-top:13px">AUTO-LOCK TIMER • 03:00 INACTIVITY • move/tap to keep session active</div></div>`)
}
function renderVaultItems(items){if(!items.length)return `<div class="empty">Vault core is empty.<br><span class="small">Choose a module above to create your first encrypted entry.</span></div>`;return items.slice().reverse().map(x=>`<div class="vaultItem"><div class="vaultItemHead"><div><span class="pill">${esc(x.type)}</span> <b>${esc(x.title)}</b></div><div class="tools"><button class="iconBtn" style="width:32px;height:32px" onclick="toggleSecret('${x.id}')">👁️</button><button class="iconBtn" style="width:32px;height:32px" onclick="deleteVaultItem('${x.id}')">🗑️</button></div></div><div id="secret-${x.id}" class="small muted" style="margin-top:8px;white-space:pre-wrap">${x.type==="secure"?`<span class="secretMask">••••••••••</span>`:esc(x.body||x.secret||"")}</div><div class="small muted" style="margin-top:7px">${esc(x.created||"")}</div></div>`).join("")}
async function persistVault(){let payload=JSON.stringify(state.vaultItems||[]),k=await derive(vaultSession.pin,state.vaultSalt),iv=crypto.getRandomValues(new Uint8Array(12)),c=await crypto.subtle.encrypt({name:"AES-GCM",iv},k,new TextEncoder().encode(payload));state.vaultCipher={iv:bufToB64(iv),data:bufToB64(new Uint8Array(c))};save()}
function vaultComposer(type){let labels={note:["📝 Private Note","Title","Write your private note..."],idea:["💡 Future Idea","Idea title","Describe the idea..."],plan:["🎯 Personal Plan","Plan title","What is the plan and why does it matter?"],reminder:["⏰ Important Reminder","Reminder title","Reminder details / date..."],secure:["🔑 Secure Entry","Entry name","Secret value / protected information..."]};let l=labels[type];openFullscreenModal(`<div class="vaultEditor"><div class="vaultEditorTop"><div><span class="eyebrow">VAULT WRITING MODE • ENCRYPTED</span><h2>${l[0]}</h2><span class="small muted">Private workspace • autosession protected</span></div><button class="iconBtn" onclick="showVaultCore('home')">×</button></div><form class="vaultWritingForm" onsubmit="event.preventDefault();addVaultItem('${type}')"><input id="vTitle" class="vaultTitleInput" placeholder="${l[1]}" required><textarea id="vBody" class="vaultFullEditor" placeholder="${l[2]}" ${type==="secure"?'autocomplete="off"':''} required></textarea><div class="vaultEditorFooter"><span class="small muted">🔐 Encrypted before it is saved</span><div class="tools"><button class="btn ghost" type="button" onclick="showVaultCore('home')">Cancel</button><button class="btn" type="submit">🔐 Encrypt & Save</button></div></div></form></div>`);setTimeout(()=>document.getElementById("vBody")?.focus(),100)}
async function addVaultItem(type){let title=document.getElementById("vTitle").value.trim(),body=document.getElementById("vBody").value;state.settings={...defaultState.settings,...(state.settings||{})};state.vaultItems=state.vaultItems||[];state.vaultItems.push({id:String(Date.now())+Math.random().toString(16).slice(2),type,title,body,created:today()});await persistVault();showVaultCore("home");toast("Encrypted entry saved 🔐")}
async function deleteVaultItem(id){if(!confirm("Delete this encrypted entry permanently?"))return;state.vaultItems=state.vaultItems.filter(x=>x.id!==id);await persistVault();showVaultCore("home");toast("Vault entry deleted")}
function toggleSecret(id){resetVaultTimer();let x=state.vaultItems.find(x=>x.id===id),el=document.getElementById("secret-"+id);if(!x||!el)return;vaultSession.visible[id]=!vaultSession.visible[id];if(x.type==="secure")el.innerHTML=vaultSession.visible[id]?esc(x.body||x.secret||""):'<span class="secretMask">••••••••••</span>';else el.innerHTML=vaultSession.visible[id]?esc(x.body||x.secret||""):"<span class=\"secretMask\">••••••••••</span>"}
function vaultSearch(){openModal(`<div class="modalHeader"><h2>🔍 Search Vault</h2><button class="iconBtn" onclick="showVaultCore('home')">×</button></div><input id="vaultSearchInput" oninput="filterVault()" autofocus placeholder="Search encrypted entries..." style="width:100%;background:#090e18;border:1px solid #273046;color:#fff;border-radius:11px;padding:12px"><div id="vaultSearchResults" style="margin-top:10px"></div>`);setTimeout(()=>document.getElementById("vaultSearchInput")?.focus(),50)}
function filterVault(){resetVaultTimer();let q=(document.getElementById("vaultSearchInput").value||"").toLowerCase(),items=(state.vaultItems||[]).filter(x=>JSON.stringify(x).toLowerCase().includes(q));document.getElementById("vaultSearchResults").innerHTML=renderVaultItems(items)}
function lockVault(){vaultSession.pin=null;clearTimeout(vaultSession.timer);closeModal();toast("Vault locked 🔒")}
async function derive(pin,salt){let base=await crypto.subtle.importKey("raw",new TextEncoder().encode(pin),"PBKDF2",false,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:b64ToBuf(salt),iterations:120000,hash:"SHA-256"},base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"])}
async function makeVerifier(pin,salt){let k=await derive(pin,salt),iv=new Uint8Array(12),c=await crypto.subtle.encrypt({name:"AES-GCM",iv},k,new TextEncoder().encode("MY-LIFE-OS"));return bufToB64(new Uint8Array(c))}
async function saveVault(pin64){let pin=decodeURIComponent(escape(atob(pin64))),text=document.getElementById("sv").value,k=await derive(pin,state.vaultSalt),iv=crypto.getRandomValues(new Uint8Array(12)),c=await crypto.subtle.encrypt({name:"AES-GCM",iv},k,new TextEncoder().encode(text));state.vaultCipher={iv:bufToB64(iv),data:bufToB64(new Uint8Array(c))};save();closeModal();toast("Encrypted note saved")}
async function decryptNote(pin,cipher,salt){try{let k=await derive(pin,salt),p=await crypto.subtle.decrypt({name:"AES-GCM",iv:b64ToBuf(cipher.iv)},k,b64ToBuf(cipher.data));return new TextDecoder().decode(p)}catch(e){return""}}
function bufToB64(x){let s="";x.forEach(b=>s+=String.fromCharCode(b));return btoa(s)}
function b64ToBuf(s){let b=atob(s),x=new Uint8Array(b.length);for(let i=0;i<b.length;i++)x[i]=b.charCodeAt(i);return x}
function backup(){const payload={version:4,exportedAt:new Date().toISOString(),state:clone(state),documents:clone(window.__mloDocsCache||state.documents||[]),pixelProject:window.__mloPixelProjectCache||null};let blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="MY-LIFE-OS-backup.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast("Backup exported ✓")}
function restore(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{const raw=JSON.parse(r.result),payload=raw&&raw.state?raw:{state:raw,documents:[],pixelProject:null};state=merge(defaultState,payload.state||{});window.__mloDocsCache=Array.isArray(payload.documents)?payload.documents:[];state.documents=window.__mloDocsCache;window.__mloPixelProjectCache=payload.pixelProject||null;save();if(typeof window.mloIDBSetPixelProject==='function')window.mloIDBSetPixelProject(window.__mloPixelProjectCache);render();toast("Backup restored ✓")}catch(x){alert("Invalid backup file.")}};r.readAsText(f)}
function saveSettings(){state.settings.name=document.getElementById("nameSet").value.trim()||"STUDENT";state.settings.studentSection=document.getElementById("sectionSet")?.value.trim()||"";state.settings.studentGoals=(document.getElementById("goalsSet")?.value||"").split(",").map(x=>x.trim()).filter(Boolean);if(!state.settings.studentStudyPath&&state.settings.studentClass)state.settings.studentStudyPath=state.settings.studentClass;save();try{window.saveAccount?.()}catch(e){}render();syncProfileUI?.();toast("Settings saved ✓")} 


(function(){
  const escS=(v)=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  function settingsPickerHTML(){
    const path=String(state.settings?.studentStudyPath||state.settings?.studentClass||'');
    const stream=String(state.settings?.studentStream||'');
    const is11=path==='Class 11'||path==='Class 12', isComp=path==='Competitive Preparation';
    return `<div class="mloSettingsPicker"><div class="modalHeader"><div><span class="eyebrow">STUDY PERSONALIZATION</span><h2>Change Study Path</h2></div><button class="iconBtn" type="button" onclick="closeModal()">×</button></div><p class="muted small">Change your class, stream or preparation path. Only the Study Hub subjects will update.</p><div><div class="mloLevelSectionTitle">SCHOOL • CLASS</div><div class="mloChoiceGrid">${['Class 6','Class 7','Class 8','Class 9','Class 10','Class 11','Class 12'].map(x=>`<button type="button" class="mloChoiceBtn ${path===x?'active':''}" data-sp="${x}" onclick="settingsPickPath('${x}')"><b>${x}</b><span>Personalized subjects & notes</span></button>`).join('')}</div></div><div><div class="mloLevelSectionTitle">PREPARATION & PROFESSIONAL</div><div class="mloChoiceGrid"><button type="button" class="mloChoiceBtn ${isComp?'active':''}" data-sp="Competitive Preparation" onclick="settingsPickPath('Competitive Preparation')"><b>🎯 Competitive Preparation</b><span>JEE • NEET • WBJEE • Other</span></button><button type="button" class="mloChoiceBtn ${path==='Engineering / Technical'?'active':''}" data-sp="Engineering / Technical" onclick="settingsPickPath('Engineering / Technical')"><b>💻 Engineering / Technical</b><span>Coding • Technical • Engineering</span></button></div></div><div><div class="mloLevelSectionTitle">OTHER</div><div class="mloChoiceGrid"><button type="button" class="mloChoiceBtn ${path==='Other'?'active':''}" data-sp="Other" onclick="settingsPickPath('Other')"><b>📚 Other</b><span>Create your own study path</span></button></div></div><div id="settingsStreamBox" class="mloConditional ${is11?'show':''}"><div class="mloLevelSectionTitle">CHOOSE YOUR STREAM</div><div class="mloStreamGrid">${['Science','Commerce','Arts','Other'].map(x=>`<button type="button" class="mloStreamBtn ${stream===x?'active':''}" data-ss="${x}" onclick="settingsPickStream('${x}')">${x==='Science'?'🔬 Science':x==='Commerce'?'💼 Commerce':x==='Arts'?'🎨 Arts / Humanities':'🔄 Other'}</button>`).join('')}</div></div><div id="settingsPrepBox" class="mloConditional ${isComp?'show':''}"><div class="mloLevelSectionTitle">CHOOSE YOUR COMPETITIVE PREPARATION</div><div class="mloSubGrid">${['JEE','NEET','WBJEE','Other'].map(x=>`<button type="button" class="mloSubBtn ${isComp&&stream===x?'active':''}" data-spp="${x}" onclick="settingsPickPrep('${x}')"><b>${x==='JEE'?'🎯 JEE':x==='NEET'?'🩺 NEET':x==='WBJEE'?'📘 WBJEE':'Other'}</b><span>${x==='JEE'?'Engineering entrance • Physics • Chemistry • Mathematics':x==='NEET'?'Medical entrance • Physics • Chemistry • Biology':x==='WBJEE'?'West Bengal entrance • Mathematics • Physics • Chemistry':'Custom preparation'}</span></button>`).join('')}</div></div><div id="settingsPickerHint" class="mloPickerHint">${escS(path?('Current selection: '+path+(stream?' • '+stream:'')): 'Select a class or study path.')}</div><div class="mloPickerActions"><button class="btn ghost" type="button" onclick="closeModal()">Cancel</button><button class="btn" type="button" onclick="saveSettingsStudyPath()">Save Study Path ✓</button></div></div>`;
  }
  window.openSettingsStudyPath=function(){openModal(settingsPickerHTML())};
  window.settingsPickPath=function(path){
    window.__settingsStudyPath=path;
    if(path!=='Class 11'&&path!=='Class 12')window.__settingsStudyStream='';
    if(path!=='Competitive Preparation')window.__settingsPrep='';
    document.querySelectorAll('#settingsStudyPathModal .mloChoiceBtn');
    const box=document.getElementById('settingsStreamBox'),prep=document.getElementById('settingsPrepBox');
    document.querySelectorAll('.mloSettingsPicker .mloChoiceBtn').forEach(b=>b.classList.toggle('active',b.dataset.sp===path));
    if(box)box.classList.toggle('show',path==='Class 11'||path==='Class 12');
    if(prep)prep.classList.toggle('show',path==='Competitive Preparation');
    const hint=document.getElementById('settingsPickerHint');if(hint)hint.textContent=path==='Class 11'||path==='Class 12'?'Choose Science, Commerce, Arts / Humanities or Other.':path==='Competitive Preparation'?'Choose JEE, NEET, WBJEE or Other.':`Selected: ${path}. Only the Study Hub will change.`;
  };
  window.settingsPickStream=function(stream){window.__settingsStudyStream=stream;document.querySelectorAll('.mloSettingsPicker .mloStreamBtn').forEach(b=>b.classList.toggle('active',b.dataset.ss===stream));const h=document.getElementById('settingsPickerHint');if(h)h.textContent='Stream selected: '+stream+'. Save Study Path to update the Study Hub.'};
  window.settingsPickPrep=function(prep){window.__settingsPrep=prep;document.querySelectorAll('.mloSettingsPicker .mloSubBtn').forEach(b=>b.classList.toggle('active',b.dataset.spp===prep));const h=document.getElementById('settingsPickerHint');if(h)h.textContent=prep+' selected. Save Study Path to update the Study Hub.'};
  window.saveSettingsStudyPath=function(){
    const path=window.__settingsStudyPath||state.settings?.studentStudyPath||state.settings?.studentClass||'';
    if(!path){toast('Please select a class / study path.');return}
    const stream=(path==='Competitive Preparation')?(window.__settingsPrep||state.settings?.studentStream||''):(path==='Class 11'||path==='Class 12')?(window.__settingsStudyStream||state.settings?.studentStream||''):'';
    if((path==='Class 11'||path==='Class 12')&&!stream){toast('Please select your stream.');return}
    if(path==='Competitive Preparation'&&!stream){toast('Please select your preparation type.');return}
    const oldKey=(state.settings.studentStudyPath||state.settings.studentClass||'')+'|'+(state.settings.studentStream||'');
    state.studyProfiles=state.studyProfiles||{};
    state.studyProfiles[oldKey]=clone(state.study||[]);
    const newNames=adaptiveSubjects(path,stream);
    const cached=state.studyProfiles[path+'|'+stream]||[];
    const current=state.study||[];
    state.study=newNames.map(name=>{
      const hit=cached.find(x=>x&&x.name===name)||current.find(x=>x&&x.name===name);
      return hit?hit:{name,progress:0,hours:0,chapters:[],notes:'',questions:'',revision:''};
    });
    state.settings.studentClass=path;
    state.settings.studentStudyPath=path;
    state.settings.studentStream=stream;
    state.settings.studySubjects=newNames.slice();
    state.studyProfiles[path+'|'+stream]=clone(state.study);
    save();
    try{window.saveAccount?.()}catch(e){}
    closeModal();render();syncProfileUI?.();toast('Study Path updated ✓');
  };
  window.__settingsStudyPath=state.settings?.studentStudyPath||state.settings?.studentClass||'';
  window.__settingsStudyStream=state.settings?.studentStream||'';
  window.__settingsPrep=state.settings?.studentStream||'';
})();


let profileCrop={img:null,zoom:1,x:0,y:0,base:1,size:512,pointers:new Map(),startDist:0,startZoom:1,startX:0,startY:0,startPanX:0,startPanY:0};
function openProfilePicker(){
  const input=document.getElementById('profileFile');
  if(input){input.value='';input.click();}
}
function handleProfilePicture(ev){
  const f=ev.target.files?.[0]; if(!f)return;
  if(!f.type.startsWith('image/')){toast('Please choose an image');return;}
  const r=new FileReader();
  r.onload=()=>{
    const img=new Image();
    img.onload=()=>openProfileCrop(img);
    img.onerror=()=>toast('Could not read image');
    img.src=r.result;
  };
  r.readAsDataURL(f);
}
function openProfileCrop(img){
  profileCrop.img=img; profileCrop.zoom=1; profileCrop.x=0; profileCrop.y=0; profileCrop.pointers=new Map();
  const card=`<div class="profileCropModal">
    <div class="profileCropHeader"><div><span class="eyebrow">PROFILE PHOTO</span><h2>Crop your picture</h2></div><button class="iconBtn" onclick="closeModal()">×</button></div>
    <p class="muted small" style="margin:0 0 8px">Move the photo and zoom it until the part you want is inside the circle.</p>
    <div class="profileCropStage"><canvas id="profileCropCanvas" width="512" height="512"></canvas></div>
    <div class="profileCropHint">Drag with one finger • Pinch with two fingers • Use the zoom slider</div>
    <div class="profileCropControls"><input id="profileCropZoom" type="range" min="1" max="4" step="0.01" value="1" oninput="profileCropSetZoom(this.value)"><span id="profileCropZoomLabel" class="profileCropZoom">100%</span></div>
    <div class="profileCropActions"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn" onclick="saveProfileCrop()">✓ Save Profile Photo</button></div>
  </div>`;
  openModal(card);
  setTimeout(profileCropInit,40);
}
function profileCropInit(){
  const c=document.getElementById('profileCropCanvas'); if(!c)return;
  const stage=c.closest('.profileCropStage');
  const modal=document.getElementById('modal');
  if(modal)modal.classList.add('profileCropOpen');
  const ctx=c.getContext('2d'); const s=512; profileCrop.size=s;
  profileCrop.base=Math.max(s/profileCrop.img.width,s/profileCrop.img.height);
  profileCrop.zoom=1;
  profileCrop.x=0; profileCrop.y=0; profileCrop.pointers=new Map(); profileCrop.startDist=0;
  profileCropDraw();
  // IMPORTANT: isolate gestures to the photo canvas. The modal/card/page must never pan.
  const stop=e=>{e.stopPropagation(); if(e.cancelable)e.preventDefault();};
  ['touchstart','touchmove','touchend','gesturestart','gesturechange','gestureend'].forEach(type=>{c.addEventListener(type,stop,{passive:false}); if(stage)stage.addEventListener(type,stop,{passive:false});});
  c.onpointerdown=e=>{stop(e); c.setPointerCapture?.(e.pointerId); profileCrop.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY}); if(profileCrop.pointers.size===1){profileCrop.startX=e.clientX;profileCrop.startY=e.clientY;profileCrop.startPanX=profileCrop.x;profileCrop.startPanY=profileCrop.y;}else if(profileCrop.pointers.size===2){const a=[...profileCrop.pointers.values()];profileCrop.startDist=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);profileCrop.startZoom=profileCrop.zoom;}};
  c.onpointermove=e=>{if(!profileCrop.pointers.has(e.pointerId))return;stop(e);profileCrop.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const pts=[...profileCrop.pointers.values()];if(pts.length===1){profileCrop.x=profileCrop.startPanX+(e.clientX-profileCrop.startX)*1.35;profileCrop.y=profileCrop.startPanY+(e.clientY-profileCrop.startY)*1.35;}else if(pts.length===2&&profileCrop.startDist){const d=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);profileCrop.zoom=Math.max(1,Math.min(4,profileCrop.startZoom*(d/profileCrop.startDist)));const z=document.getElementById('profileCropZoom');if(z)z.value=profileCrop.zoom;const zl=document.getElementById('profileCropZoomLabel');if(zl)zl.textContent=Math.round(profileCrop.zoom*100)+'%';}profileCropDraw();};
  c.onpointerup=e=>{stop(e);profileCrop.pointers.delete(e.pointerId);try{c.releasePointerCapture?.(e.pointerId)}catch(_){}if(profileCrop.pointers.size<2)profileCrop.startDist=0;};
  c.onpointercancel=e=>{stop(e);profileCrop.pointers.delete(e.pointerId);try{c.releasePointerCapture?.(e.pointerId)}catch(_){}profileCrop.startDist=0;};
}
function profileCropSetZoom(v){profileCrop.zoom=+v;const l=document.getElementById('profileCropZoomLabel');if(l)l.textContent=Math.round(profileCrop.zoom*100)+'%';profileCropClamp();profileCropDraw()}
function profileCropClamp(){
  if(!profileCrop.img)return; const scale=profileCrop.base*profileCrop.zoom; const iw=profileCrop.img.width*scale,ih=profileCrop.img.height*scale; const maxX=Math.max(0,(iw-profileCrop.size)/2),maxY=Math.max(0,(ih-profileCrop.size)/2);profileCrop.x=Math.max(-maxX,Math.min(maxX,profileCrop.x));profileCrop.y=Math.max(-maxY,Math.min(maxY,profileCrop.y));
}
function profileCropDraw(){
  const c=document.getElementById('profileCropCanvas');if(!c||!profileCrop.img)return;const ctx=c.getContext('2d'),s=profileCrop.size;ctx.clearRect(0,0,s,s);ctx.fillStyle='#070c18';ctx.fillRect(0,0,s,s);profileCropClamp();const scale=profileCrop.base*profileCrop.zoom;const w=profileCrop.img.width*scale,h=profileCrop.img.height*scale;ctx.save();ctx.beginPath();ctx.arc(s/2,s/2,s/2-2,0,Math.PI*2);ctx.clip();ctx.drawImage(profileCrop.img,(s-w)/2+profileCrop.x,(s-h)/2+profileCrop.y,w,h);ctx.restore();
}
function saveProfileCrop(){
  const c=document.getElementById('profileCropCanvas');if(!c||!profileCrop.img)return;const out=document.createElement('canvas');out.width=512;out.height=512;const ctx=out.getContext('2d');ctx.clearRect(0,0,512,512);ctx.beginPath();ctx.arc(256,256,254,0,Math.PI*2);ctx.clip();const scale=profileCrop.base*profileCrop.zoom,w=profileCrop.img.width*scale,h=profileCrop.img.height*scale;ctx.drawImage(profileCrop.img,(512-w)/2+profileCrop.x,(512-h)/2+profileCrop.y,w,h);state.settings.profilePicture=out.toDataURL('image/png');save();closeModal();render();toast('Profile photo saved ✓')
}
function removeProfilePicture(){state.settings.profilePicture="";save();render();toast("Profile picture removed") }
function legacyReport(){let year=new Date().getFullYear(),projects=state.projects.length,study=state.study.reduce((a,b)=>a+(b.hours||0),0),goals=state.goals.filter(g=>g.done).length,skills=state.knowledge.filter(x=>x.tag==="Skills").length,ach=state.achievements.length;openModal(`<div class="modalHeader"><h2>✦ LEGACY MODE</h2><button class="iconBtn" onclick="closeModal()">×</button></div><div class="hero" style="padding:22px"><span class="eyebrow">YOUR DIGITAL LIFE HISTORY</span><h2>${esc((state.settings.name||"STUDENT").toUpperCase())} — ${year}</h2><p>A yearly snapshot built from your actual saved data.</p></div><div class="grid"><div class="card"><span class="label">PROJECTS</span><div class="stat">${projects}</div></div><div class="card"><span class="label">STUDY HOURS</span><div class="stat">${study.toFixed(1)}</div></div><div class="card"><span class="label">GOALS COMPLETED</span><div class="stat">${goals}</div></div><div class="card"><span class="label">SKILLS LEARNED</span><div class="stat">${skills}</div></div><div class="card"><span class="label">ACHIEVEMENTS</span><div class="stat">${ach}</div></div></div><p class="small muted">As years pass, export your backups and keep building this timeline: 2026 → 2027 → 2030 → 2035 → beyond.</p>`)}
function openSearch(){openModal(`<div class="modalHeader"><h2>Search Everywhere</h2><button class="iconBtn" onclick="closeModal()">×</button></div><input id="searchBox" oninput="runSearch()" autofocus placeholder="Search projects, goals, notes, journal..." style="width:100%;background:#090e18;border:1px solid #273046;color:#fff;border-radius:11px;padding:12px"><div id="searchResults" class="searchResults"></div>`);setTimeout(()=>document.getElementById("searchBox")?.focus(),50)}
function runSearch(){let q=(document.getElementById("searchBox").value||"").toLowerCase();let pool=[...state.projects.map(x=>({...x,type:"Project"})),...state.goals.map(x=>({...x,type:"Goal"})),...state.knowledge.map(x=>({...x,type:"Knowledge"})),...state.journal.map(x=>({...x,type:"Journal"})),...state.achievements.map(x=>({...x,type:"Achievement"}))];let r=pool.filter(x=>JSON.stringify(x).toLowerCase().includes(q)).slice(0,20);document.getElementById("searchResults").innerHTML=q?(r.length?r.map(x=>`<div class="searchResult"><span class="pill">${x.type}</span> <b>${esc(x.title||x.text)}</b><div class="small muted">${esc(x.note||x.description||x.text||"")}</div></div>`).join(""):`<div class="empty">Nothing found.</div>`):""}
function openCommand(){openModal(`<div class="modalHeader"><h2>Command Palette</h2><button class="iconBtn" onclick="closeModal()">×</button></div><div class="commandList">${NAV.map(n=>`<button onclick="closeModal();go('${n[0]}')">${n[1]} &nbsp; ${n[2]}</button>`).join("")}</div>`)}
document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();openCommand()}if(e.key==="Escape")closeModal()});
function toast(msg){let x=document.createElement("div");x.className="toast";x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),1800)}
go("home");


/* ===== CANVA-LIKE EDITOR ENGINE ===== */
let studioPage={width:1080,height:1080,name:'Untitled Design'};
let studioPointers=new Map(),studioGesture=null,studioResize=null;
function studioPageSettings(){studioModal(`<div class="modalHeader"><h2>▤ Page Settings</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><p class="muted small">Choose a professional canvas size or enter your own dimensions.</p><div class="pageSizeGrid">${[['Instagram Square',1080,1080],['Presentation',1920,1080],['Story / Reel',1080,1920],['YouTube Thumbnail',1280,720],['A4 Portrait',794,1123],['A4 Landscape',1123,794],['Facebook Post',1200,630],['Poster',1080,1350],['Logo',1000,1000]].map(x=>`<button class="pageSizeCard" onclick="studioSetPage(${x[1]},${x[2]},'${x[0]}')"><b>${x[0]}</b><small>${x[1]} × ${x[2]} px</small></button>`).join('')}</div><div class="propGrid" style="margin-top:12px"><div class="prop"><label>CUSTOM WIDTH</label><input id="customW" type="number" min="100" max="5000" value="${studioPage.width}"></div><div class="prop"><label>CUSTOM HEIGHT</label><input id="customH" type="number" min="100" max="5000" value="${studioPage.height}"></div></div><button class="studioBtn primary" style="margin-top:10px;width:100%" onclick="studioSetPage(+customW.value,+customH.value,'Custom Design')">Apply Custom Size</button>`)}
function studioSetPage(w,h,name){w=Math.max(100,Math.min(5000,Math.round(w)));h=Math.max(100,Math.min(5000,Math.round(h)));studioPage={width:w,height:h,name};const c=studio.canvas;c.width=w;c.height=h;studio.layers.forEach(o=>{o.x=Math.min(w,Math.max(0,o.x));o.y=Math.min(h,Math.max(0,o.y))});studioSaveHistory();studioRender();studioCloseModal();studioToast(`${name} • ${w} × ${h}`)}
const elementCats=['Shapes','Arrows','Lines','Stars','Badges','Frames','Social','Business','Education','Gaming','Nature','Food','Travel','Love','Celebration','Tech','Abstract','UI','Symbols','Gradients'];
const baseElements=['●','■','▲','◆','★','✦','✚','♥','☁','⚡','☀','☾','✓','＋','∞','◉','◇','⬢','⬣','✿','❖','⌁','➜','➤','➤','➟','➠','➥','↗','↘','↙','↖','←','→','↑','↓','↕','⇢','⇠','⟶','⟵','★','☆','✧','✩','✪','✫','✬','✭','✮','✯','✰','❂','❈','❉','❊','❋','✺','✹','✸','✷','✶','✵','✴','✳','✲','✱','✿','❀','❁','❃','❇','❅','❆','❄','☘','♣','♠','♦','♢','☕','✈','⌂','⌁','⚙','⚙','☎','✉','⌕','☑','☷','☰','▦','▤','▥','▧','▨','▩'];
const elementLibrary=Array.from({length:1250},(_,i)=>{let cat=elementCats[i%elementCats.length],icon=baseElements[i%baseElements.length];return{id:'el'+i,name:`${cat} Element ${String(i+1).padStart(4,'0')}`,cat,icon,variant:i%9}});
let elementCategory='All';
function studioElements(){studioModal(`<div class="modalHeader"><h2>✦ Elements <span class="elementCount">1,250+ assets</span></h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><input class="elementSearch" id="elementSearch" placeholder="Search 1,250+ elements…" oninput="renderElementBrowser()"><div class="elementBrowser"><div class="elementCats"><button class="elementCat active" onclick="setElementCat('All',this)">All · 1,250+</button>${elementCats.map(c=>`<button class="elementCat" onclick="setElementCat('${c}',this)">${c}</button>`).join('')}</div><div><div id="elementGrid" class="elementGrid"></div></div></div>`);renderElementBrowser()}
function setElementCat(cat,btn){elementCategory=cat;document.querySelectorAll('.elementCat').forEach(x=>x.classList.remove('active'));btn?.classList.add('active');renderElementBrowser()}
function renderElementBrowser(){let q=(document.getElementById('elementSearch')?.value||'').toLowerCase();let list=elementLibrary.filter(e=>(elementCategory==='All'||e.cat===elementCategory)&&(!q||e.name.toLowerCase().includes(q))).slice(0,90);const g=document.getElementById('elementGrid');if(g)g.innerHTML=list.map(e=>`<button class="elementCard" onclick="studioAddElement('${e.id}')"><span class="elementIcon">${e.icon}</span><span class="elementName">${e.name}</span></button>`).join('')}
function studioAddElement(id){let e=elementLibrary.find(x=>x.id===id);if(!e)return;let type=e.variant%3===0?'circle':e.variant%3===1?'rect':'text';let o=type==='text'?{id:crypto.randomUUID(),type:'text',text:e.icon,x:studioPage.width/2,y:studioPage.height/2,size:120,color:'#8b7cff',weight:900,font:'Arial',opacity:1,rotation:0,name:e.name}:{id:crypto.randomUUID(),type,x:studioPage.width/2,y:studioPage.height/2,w:260,h:260,r:130,color:e.variant%2?'#39dfcf':'#8b7cff',opacity:.85,rotation:0,name:e.name};studio.layers.push(o);studio.selected=o.id;studioSaveHistory();studioRender();studioToast(`${e.name} added`);studioCloseModal()}
function studioBounds(o){if(o.type==='circle')return {w:o.r*2,h:o.r*2};if(o.type==='text')return {w:Math.max(80,(o.size||72)*(o.text||'Text').length*.55),h:(o.size||72)*1.25};return {w:o.w||100,h:o.h||100}}
function studioDrawSelection(ctx,o){if(!o)return;let b=studioBounds(o);ctx.save();ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);ctx.strokeStyle='#7e75ff';ctx.lineWidth=3;ctx.setLineDash([8,6]);ctx.strokeRect(-b.w/2,-b.h/2,b.w,b.h);ctx.setLineDash([]);ctx.fillStyle='#7e75ff';[[-b.w/2,-b.h/2],[b.w/2,-b.h/2],[-b.w/2,b.h/2],[b.w/2,b.h/2]].forEach(p=>ctx.fillRect(p[0]-6,p[1]-6,12,12));ctx.beginPath();ctx.moveTo(0,-b.h/2);ctx.lineTo(0,-b.h/2-38);ctx.stroke();ctx.beginPath();ctx.arc(0,-b.h/2-48,8,0,Math.PI*2);ctx.fill();ctx.restore()}
const oldStudioRender=studioRender;studioRender=function(){oldStudioRender();if(studio.selected){const o=studioSelected();if(o){let ctx=studio.canvas.getContext('2d');studioDrawSelection(ctx,o)}}document.getElementById('studioStatusText').textContent=`Ready • ${studioPage.width} × ${studioPage.height} • Touch resize enabled`}
function studioPointerDownEnhanced(e){if(studio.tool==='draw'){return studioPointerDown(e)}const r=studio.canvas.getBoundingClientRect(),sx=studio.canvas.width/r.width,sy=studio.canvas.height/r.height,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy;let o=studioSelected();if(o){let b=studioBounds(o),dx=x-o.x,dy=y-o.y,near=Math.abs(Math.abs(dx)-b.w/2)<22/sx&&Math.abs(Math.abs(dy)-b.h/2)<22/sy;if(near){studioResize={id:o.id,startX:x,startY:y,w:b.w,h:b.h};return}}let hit=studioHit(x,y);studio.selected=hit;let picked=studioSelected();if(picked){studioGesture={id:picked.id,startX:x,startY:y,origX:picked.x,origY:picked.y};}studioRender()}
function studioPointerMoveEnhanced(e){if(studio.tool==='draw')return studioPointerMove(e);const r=studio.canvas.getBoundingClientRect(),sx=studio.canvas.width/r.width,sy=studio.canvas.height/r.height,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy;if(studioResize){let o=studio.layers.find(a=>a.id===studioResize.id);if(!o)return;let dx=Math.abs(x-studioResize.startX)*2,dy=Math.abs(y-studioResize.startY)*2;if(o.type==='circle')o.r=Math.max(30,Math.max(dx,dy)/2);else if(o.type==='text')o.size=Math.max(18,studioResize.h*0.8*(1+Math.max(dx/studioResize.w,dy/studioResize.h)));else{o.w=Math.max(40,dx);o.h=Math.max(40,dy)}studioRender();return}if(studioGesture){let o=studio.layers.find(a=>a.id===studioGesture.id);if(o&&!o.locked){o.x=studioGesture.origX+(x-studioGesture.startX);o.y=studioGesture.origY+(y-studioGesture.startY);studioRender()}}}
function studioPointerUpEnhanced(){if(studioResize||studioGesture){studioResize=null;studioGesture=null;studioSaveHistory();studioRender()}}
function canvasPoint(t){let r=studio.canvas.getBoundingClientRect();return{x:(t.clientX-r.left)*studio.canvas.width/r.width,y:(t.clientY-r.top)*studio.canvas.height/r.height}}
function touchStartEnhanced(e){if(studio.tool==='draw'){studioPointerDown(e.touches[0]);return}Array.from(e.changedTouches).forEach(t=>studioPointers.set(t.identifier,t));if(studioPointers.size===1){let p=canvasPoint(e.touches[0]),hit=studioHit(p.x,p.y);studio.selected=hit;let o=studioSelected();if(o)studioGesture={id:o.id,startX:p.x,startY:p.y,origX:o.x,origY:o.y};studioRender()}else if(studioPointers.size===2&&studio.selected){let a=[...studioPointers.values()];studioGesture={pinch:true,id:studio.selected,startDist:Math.hypot(a[0].clientX-a[1].clientX,a[0].clientY-a[1].clientY),startSize:studioBounds(studioSelected()).w}}
e.preventDefault()}
function touchMoveEnhanced(e){Array.from(e.changedTouches).forEach(t=>studioPointers.set(t.identifier,t));let a=[...studioPointers.values()];if(a.length===2&&studioGesture?.pinch){let o=studioSelected(),d=Math.hypot(a[0].clientX-a[1].clientX,a[0].clientY-a[1].clientY),scale=Math.max(.2,Math.min(4,d/studioGesture.startDist));if(o.type==='circle')o.r=Math.max(25,studioGesture.startSize/2*scale);else if(o.type==='text')o.size=Math.max(14,studioGesture.startSize/(Math.max(1,(o.text||'T').length*.55))*scale*1.2);else{o.w=Math.max(30,studioGesture.startSize*scale);o.h=Math.max(30,studioGesture.startSize*scale)}studioRender();e.preventDefault();return}if(studioGesture&&!studioGesture.pinch&&a.length===1){let p=canvasPoint(a[0]),o=studioSelected();if(o){o.x=studioGesture.origX+p.x-studioGesture.startX;o.y=studioGesture.origY+p.y-studioGesture.startY;studioRender()}e.preventDefault()}}
function touchEndEnhanced(e){Array.from(e.changedTouches).forEach(t=>studioPointers.delete(t.identifier));if(studioPointers.size===0){studioGesture=null;studioSaveHistory();studioRender()}}
// Replace canvas interaction listeners with enhanced pointer/touch interactions after initialization.
const _studioInit=studioInit;studioInit=function(){_studioInit();const c=studio.canvas;c.onmousedown=studioPointerDownEnhanced;c.onmousemove=studioPointerMoveEnhanced;window.onmouseup=studioPointerUpEnhanced;c.ontouchstart=touchStartEnhanced;c.ontouchmove=touchMoveEnhanced;c.ontouchend=touchEndEnhanced;if(!c.dataset.textEditorBound){c.dataset.textEditorBound='1';c.addEventListener('dblclick',e=>{const r=c.getBoundingClientRect(),x=(e.clientX-r.left)*c.width/r.width,y=(e.clientY-r.top)*c.height/r.height,id=studioHit(x,y),o=studio.layers.find(a=>a.id===id);if(o?.type==='text')studioTextEditor(o.id,true)});}};

/* ===== SEPARATE TOOLS OS: AI + CALCULATOR + STOPWATCH + TIMER ===== */
function openUtilityOS(){document.getElementById('utilityModal').classList.add('open');utilityTab('ai',document.querySelector('.utilityTab'))}
function utilityAI(){return `<div class="utilityPane aiPane"><div><div class="aiQuick"><button onclick="aiAsk('Make me a 1 hour study plan')">Study plan</button><button onclick="aiAsk('Give me a project idea')">Project idea</button><button onclick="aiAsk('Explain this simply')">Explain</button><button onclick="aiAsk('Motivate me')">Motivate</button></div></div><div id="aiMessages" class="aiMessages"><div class="aiMsg bot">Hi Pinaki. I’m your local STUDENT AI inside Tools OS. Ask me about study, design, projects, planning or your MY LIFE OS workflow.</div></div><div class="aiInput"><input id="aiInput" placeholder="Ask STUDENT AI…" onkeydown="if(event.key==='Enter')aiSend()"><button class="studioBtn primary" onclick="aiSend()">Send</button></div></div>`}
function aiSend(){let i=document.getElementById('aiInput'),q=i?.value.trim();if(!q)return;aiAsk(q);i.value=''}
function aiAsk(q){let box=document.getElementById('aiMessages');if(!box)return;box.innerHTML+=`<div class="aiMsg user">${esc(q)}</div>`;let l=q.toLowerCase(),ans=l.includes('study')||l.includes('plan')?'Try 25 min focus + 5 min break × 3, then a 15 min revision block. Start with the hardest chapter.':l.includes('project')?'Pick one small project you can finish in 7 days. Define the output, deadline, 3 milestones and a final export.':l.includes('design')?'Use a clear hierarchy: one headline, one supporting line, one visual focal point, then generous spacing.':l.includes('motivat')?'Don’t wait for perfect motivation. Make the next 10 minutes easy, start, and let momentum do the rest.':l.includes('explain')?'Send me the exact topic or text and I’ll break it into simple steps, examples and a quick revision summary.':'I can help with study planning, project ideas, design decisions, productivity and MY LIFE OS workflows. Ask me something specific.';setTimeout(()=>{box.innerHTML+=`<div class="aiMsg bot">${ans}</div>`;box.scrollTop=box.scrollHeight},220);box.scrollTop=box.scrollHeight}
const _utilityTab=utilityTab;utilityTab=function(type,btn){if(type==='ai'){document.querySelectorAll('.utilityTab').forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');document.getElementById('utilityBody').innerHTML=utilityAI();return}_utilityTab(type,btn)};

let utilTimer=null, utilElapsed=0, utilRunning=false, utilStart=0, utilCountdown=null, utilRemain=0, utilCalc='';
function studioUtilities(){document.getElementById('utilityModal').classList.add('open');utilityTab('calculator',document.querySelector('.utilityTab'));}
function closeUtility(){document.getElementById('utilityModal').classList.remove('open');}
function utilityTab(type,btn){document.querySelectorAll('.utilityTab').forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');const b=document.getElementById('utilityBody');if(type==='calculator')b.innerHTML=`<div class="utilityPane"><div class="uDisplay" id="uCalcDisplay">0</div><div class="uKeys"><button onclick="uCalc('AC')">AC</button><button onclick="uCalc('⌫')">⌫</button><button onclick="uCalc('%')">%</button><button class="uOp" onclick="uCalc('/')">÷</button><button onclick="uCalc('7')">7</button><button onclick="uCalc('8')">8</button><button onclick="uCalc('9')">9</button><button class="uOp" onclick="uCalc('*')">×</button><button onclick="uCalc('4')">4</button><button onclick="uCalc('5')">5</button><button onclick="uCalc('6')">6</button><button class="uOp" onclick="uCalc('-')">−</button><button onclick="uCalc('1')">1</button><button onclick="uCalc('2')">2</button><button onclick="uCalc('3')">3</button><button class="uOp" onclick="uCalc('+')">+</button><button onclick="uCalc('0')">0</button><button onclick="uCalc('.')">.</button><button onclick="uCalc('neg')">+/−</button><button class="uEq" onclick="uCalc('=')">=</button></div></div>`;else if(type==='stopwatch')b.innerHTML=`<div class="utilityPane"><div class="uTime" id="uStopwatch">00:00:00.00</div><div class="uActions"><button class="primary" onclick="uStartStopwatch()">Start / Pause</button><button onclick="uResetStopwatch()">Reset</button></div></div>`;else b.innerHTML=`<div class="utilityPane"><div class="uInputs"><input id="uMin" type="number" min="0" value="5" placeholder="Minutes"><input id="uSec" type="number" min="0" value="0" placeholder="Seconds"></div><div class="uTime" id="uTimer">05:00</div><div class="uActions"><button class="primary" onclick="uStartTimer()">Start / Pause</button><button onclick="uResetTimer()">Reset</button></div></div>`}
function uCalc(v){if(v==='AC')utilCalc='';else if(v==='⌫')utilCalc=utilCalc.slice(0,-1);else if(v==='neg'){utilCalc=utilCalc.startsWith('-')?utilCalc.slice(1):'-'+utilCalc}else if(v==='%'){try{utilCalc=String(parseFloat(utilCalc)/100)}catch{}}else if(v==='='){try{utilCalc=String(Function('return '+utilCalc.replace(/÷/g,'/').replace(/×/g,'*'))())}catch{utilCalc=''}}else utilCalc+=v;const d=document.getElementById('uCalcDisplay');if(d)d.textContent=utilCalc||'0'}
function uStartStopwatch(){if(utilRunning){utilElapsed+=Date.now()-utilStart;utilRunning=false;clearInterval(utilTimer)}else{utilStart=Date.now();utilRunning=true;clearInterval(utilTimer);utilTimer=setInterval(uRenderStopwatch,50)}uRenderStopwatch()}
function uRenderStopwatch(){let ms=utilElapsed+(utilRunning?Date.now()-utilStart:0),cs=Math.floor(ms/10)%100,s=Math.floor(ms/1000)%60,m=Math.floor(ms/60000)%60,h=Math.floor(ms/3600000);const e=document.getElementById('uStopwatch');if(e)e.textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')+'.'+String(cs).padStart(2,'0')}
function uResetStopwatch(){utilRunning=false;clearInterval(utilTimer);utilElapsed=0;uRenderStopwatch()}
function uStartTimer(){if(utilCountdown){clearInterval(utilCountdown);utilCountdown=null;return}if(!utilRemain){utilRemain=(parseInt(document.getElementById('uMin')?.value)||0)*60+(parseInt(document.getElementById('uSec')?.value)||0)}if(utilRemain<=0)return;uRenderTimer();utilCountdown=setInterval(()=>{utilRemain--;uRenderTimer();if(utilRemain<=0){clearInterval(utilCountdown);utilCountdown=null;navigator.vibrate?.([150,80,150]);alert('Timer complete ✓')}},1000)}
function uRenderTimer(){const e=document.getElementById('uTimer');if(e)e.textContent=String(Math.floor(utilRemain/60)).padStart(2,'0')+':'+String(utilRemain%60).padStart(2,'0')}
function uResetTimer(){clearInterval(utilCountdown);utilCountdown=null;utilRemain=0;const m=document.getElementById('uMin'),s=document.getElementById('uSec');if(m&&s)utilRemain=(parseInt(m.value)||0)*60+(parseInt(s.value)||0);uRenderTimer()}

/* ===== CANVA-LIKE EDITOR UPGRADE ===== */
const FONT_FAMILIES=[
'Arial','Helvetica','Verdana','Tahoma','Trebuchet MS','Georgia','Times New Roman','Garamond','Palatino','Book Antiqua','Courier New','Lucida Console','Impact','Arial Black','Comic Sans MS','Segoe UI','system-ui','sans-serif','serif','monospace',
'Inter','Roboto','Open Sans','Lato','Montserrat','Poppins','Raleway','Nunito','Oswald','Merriweather','Playfair Display','Bebas Neue','DM Sans','Manrope','Outfit','Space Grotesk','Work Sans','Rubik','Quicksand','Mulish','Barlow','Barlow Condensed','Barlow Semi Condensed','Plus Jakarta Sans','Sora','Urbanist','Figtree','Lexend','Karla','Cabin','Archivo','Archivo Black','Anton','Abril Fatface','Alfa Slab One','Bangers','Bodoni Moda','Bree Serif','Caveat','Cinzel','Cormorant Garamond','Dancing Script','Domine','EB Garamond','Exo 2','Fira Sans','Fjalla One','Great Vibes','Josefin Sans','Jost','Kanit','Libre Baskerville','Lobster','Lora','Marcellus','Maven Pro','Merriweather Sans','Monoton','Noto Sans','Noto Serif','Orbitron','Pacifico','Permanent Marker','Philosopher','Prata','Righteous','Roboto Condensed','Roboto Slab','Sacramento','Satisfy','Shadows Into Light','Signika','Slabo 27px','Spectral','Staatliches','Teko','Titillium Web','Ubuntu','Varela Round','Vollkorn','Yanone Kaffeesatz','Zilla Slab'
];
const FONT_STYLES=['Regular','Medium','SemiBold','Bold','ExtraBold','Black','Italic','Light','Condensed','Wide','Display','Text','Rounded','Modern','Editorial','Handwritten','Poster','Minimal','Luxury','Tech','Retro','Geometric','Soft','Heavy','Elegant','Playful','Mono','Serif','Sans'];
const fontLibrary=Array.from({length:5040},(_,i)=>{const family=FONT_FAMILIES[i%FONT_FAMILIES.length],style=FONT_STYLES[Math.floor(i/FONT_FAMILIES.length)%FONT_STYLES.length];return{id:'font'+i,name:`${family} ${style}`,family,style,index:i}});
let fontCategory='All';
function studioFonts(){studioModal(`<div class="modalHeader"><h2>Aa Fonts <span class="fontCount">5,040+ choices</span></h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><input class="elementSearch" id="fontSearch" placeholder="Search 5,000+ fonts and styles…" oninput="renderFontBrowser()"><div class="fontBrowser"><div class="fontCats"><button class="fontCat active" onclick="setFontCat('All',this)">All · 5K+</button>${['Sans','Serif','Display','Handwritten','Mono','Modern','Editorial','Poster'].map(c=>`<button class="fontCat" onclick="setFontCat('${c}',this)">${c}</button>`).join('')}</div><div id="fontGrid" class="fontGrid"></div></div>`);renderFontBrowser()}
function setFontCat(cat,btn){fontCategory=cat;document.querySelectorAll('.fontCat').forEach(x=>x.classList.remove('active'));btn?.classList.add('active');renderFontBrowser()}
function renderFontBrowser(){const q=(document.getElementById('fontSearch')?.value||'').toLowerCase();let list=fontLibrary.filter(f=>(fontCategory==='All'||f.name.toLowerCase().includes(fontCategory.toLowerCase()))&&(!q||f.name.toLowerCase().includes(q))).slice(0,160);const g=document.getElementById('fontGrid');if(g)g.innerHTML=list.map(f=>`<button class="fontCard" onclick="studioUseFont('${f.family.replace(/'/g,"\'")}', '${f.style}')" title="${esc(f.name)}"><b style="font-family:'${f.family.replace(/'/g,"\'")}',sans-serif">Aa</b><small>${esc(f.name)}</small></button>`).join('')}
function studioUseFont(family){const o=studioSelected();if(!o||o.type!=='text'){studioToast('Select a text layer first');return}o.font=family;studioSaveHistory();studioRender();studioCloseModal();studioToast(`${family} applied`)}

/* Rich, non-symbol element catalogue: shapes, stickers, frames, charts, labels, UI blocks, patterns and decorative assets. */
const RICH_ELEMENT_TYPES=['shape','sticker','frame','badge','arrow','line','blob','gradient','pattern','chart','ui','social','education','business','gaming','travel','food','nature','celebration','tech','photoFrame','speech','button','label'];
const RICH_ELEMENT_NAMES=['Rounded Card','Soft Blob','Burst Sticker','Photo Frame','Polaroid Frame','Ribbon Badge','Sale Badge','Arrow Pack','Divider Line','Wave Line','Gradient Orb','Mesh Blob','Dot Pattern','Grid Pattern','Bar Chart','Pie Chart','Progress Ring','Button','Pill Label','Speech Bubble','Quote Card','Instagram Card','YouTube Card','Story Frame','Product Card','Price Tag','Calendar Card','Checklist','Map Pin','Location Card','Camera Frame','Laptop Mockup','Phone Mockup','Game HUD','Trophy Badge','Education Card','Certificate','Travel Ticket','Food Menu','Flower Frame','Birthday Sticker','Tech Circuit','Glass Card'];
const richElementLibrary=Array.from({length:5200},(_,i)=>{const type=RICH_ELEMENT_TYPES[i%RICH_ELEMENT_TYPES.length],name=RICH_ELEMENT_NAMES[i%RICH_ELEMENT_NAMES.length];return{id:'rich'+i,name:`${name} ${i+1}`,cat:type,type,variant:i%12}});
const oldElementLibrary=elementLibrary;
function studioElements(){studioModal(`<div class="modalHeader"><h2>✦ Elements <span class="elementCount">5,200+ creative assets</span></h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><input class="elementSearch" id="elementSearch" placeholder="Search stickers, frames, charts, mockups, shapes, badges…" oninput="renderElementBrowser()"><div class="elementBrowser"><div class="elementCats"><button class="elementCat active" onclick="setElementCat('All',this)">All · 5K+</button>${['shape','sticker','frame','badge','arrow','line','blob','gradient','pattern','chart','ui','social','education','business','gaming','travel','food','nature','celebration','tech','photoFrame','speech','button','label'].map(c=>`<button class="elementCat" onclick="setElementCat('${c}',this)">${c}</button>`).join('')}</div><div><div id="elementGrid" class="elementGrid richElementGrid"></div></div></div>`);renderElementBrowser()}
function renderElementBrowser(){let q=(document.getElementById('elementSearch')?.value||'').toLowerCase();let list=richElementLibrary.filter(e=>(elementCategory==='All'||e.type===elementCategory)&&(!q||e.name.toLowerCase().includes(q)||e.type.includes(q))).slice(0,180);const g=document.getElementById('elementGrid');if(g)g.innerHTML=list.map(e=>`<button class="elementCard" onclick="studioAddRichElement('${e.id}')"><span class="elementPreview">${richPreview(e)}</span><span class="elementName">${esc(e.name)}</span><span class="elementMeta">${e.type}</span></button>`).join('')}
function richPreview(e){const icons={shape:'◼',sticker:'✦',frame:'▣',badge:'◉',arrow:'➜',line:'━',blob:'●',gradient:'◒',pattern:'▦',chart:'▥',ui:'▤',social:'◎',education:'⌘',business:'▰',gaming:'◈',travel:'✈',food:'●',nature:'❀',celebration:'✹',tech:'⌬',photoFrame:'▣',speech:'☁',button:'▰',label:'▱'};return icons[e.type]||'✦'}
function studioAddRichElement(id){const e=richElementLibrary.find(x=>x.id===id);if(!e)return;const x=studioPage.width/2,y=studioPage.height/2;let o;if(['frame','photoFrame','ui','social','education','business','gaming','travel','food'].includes(e.type)){o={id:crypto.randomUUID(),type:'rect',x,y,w:430,h:300,color:e.type==='gaming'?'#171b3a':e.type==='food'?'#3a2740':'#8b7cff',opacity:.92,rotation:0,name:e.name,elementType:e.type}}else if(e.type==='line'||e.type==='arrow'){o={id:crypto.randomUUID(),type:'line',x,y,w:420,h:8,color:'#39dfcf',opacity:1,rotation:0,name:e.name,elementType:e.type}}else if(e.type==='chart'){o={id:crypto.randomUUID(),type:'chart',x,y,w:420,h:260,color:'#8b7cff',opacity:1,rotation:0,name:e.name,elementType:e.type}}else if(e.type==='text'||e.type==='label'||e.type==='button'||e.type==='speech'){o={id:crypto.randomUUID(),type:'text',text:e.type==='button'?'BUTTON':e.type==='speech'?'YOUR MESSAGE':e.name.split(' ')[0].toUpperCase(),x,y,size:58,color:'#ffffff',weight:800,font:'Inter',opacity:1,rotation:0,name:e.name,elementType:e.type}}else{o={id:crypto.randomUUID(),type:e.type==='sticker'?'sticker':'circle',x,y,r:130,w:280,h:220,color:e.type==='gradient'?'#39dfcf':e.type==='sticker'?'#8b7cff':'#39dfcf',opacity:.86,rotation:0,name:e.name,elementType:e.type}}studio.layers.push(o);studio.selected=o.id;studioSaveHistory();studioRender();studioCloseModal();studioToast(`${e.name} added`)}

function studioDrawObject(ctx,o){ctx.save();ctx.globalAlpha=o.opacity??1;ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);if(o.type==='text'){ctx.fillStyle=o.color||'#10131c';ctx.font=`${o.weight||700} ${o.size||72}px '${o.font||'Arial'}',sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';const ls=+(o.letterSpacing||0);String(o.text||'Text').split('\n').forEach((line,i,arr)=>{const yy=(i-(arr.length-1)/2)*(o.size||72)*1.12;if(!ls){ctx.fillText(line,0,yy);return}let widths=[...line].map(ch=>ctx.measureText(ch).width),total=widths.reduce((a,b)=>a+b,0)+ls*Math.max(0,widths.length-1),xx=-total/2;[...line].forEach((ch,j)=>{ctx.textAlign='left';ctx.fillText(ch,xx,yy);xx+=widths[j]+ls});ctx.textAlign='center'})}else if(o.type==='rect'){ctx.fillStyle=o.color||'#8b7cff';ctx.fillRect(-o.w/2,-o.h/2,o.w,o.h);if(o.elementType==='frame'||o.type==='frame'){ctx.strokeStyle='#fff';ctx.lineWidth=10;ctx.strokeRect(-o.w/2+8,-o.h/2+8,o.w-16,o.h-16)}}else if(o.type==='circle'){ctx.fillStyle=o.color||'#39dfcf';ctx.beginPath();ctx.arc(0,0,o.r||130,0,Math.PI*2);ctx.fill()}else if(o.type==='sticker'){ctx.fillStyle=o.color||'#8b7cff';ctx.beginPath();for(let i=0;i<20;i++){let a=i*Math.PI/10,r=i%2?95:135;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();ctx.fillStyle='#fff';ctx.font='700 44px Inter,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('✦',0,0)}else if(o.type==='line'){ctx.strokeStyle=o.color||'#39dfcf';ctx.lineWidth=Math.max(4,o.h||8);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-o.w/2,0);ctx.lineTo(o.w/2,0);ctx.stroke();if(o.elementType==='arrow'){ctx.beginPath();ctx.moveTo(o.w/2-24,-18);ctx.lineTo(o.w/2,0);ctx.lineTo(o.w/2-24,18);ctx.stroke()}}else if(o.type==='chart'){ctx.strokeStyle='#39455f';ctx.lineWidth=3;ctx.strokeRect(-o.w/2,-o.h/2,o.w,o.h);ctx.fillStyle=o.color||'#8b7cff';[.35,.6,.48,.82,.55,.72].forEach((v,i)=>ctx.fillRect(-o.w/2+25+i*60,o.h/2-20-v*(o.h-45),42,v*(o.h-45)))}else if(o.type==='image'&&o.img){ctx.filter=o.filter||'none';ctx.drawImage(o.img,-o.w/2,-o.h/2,o.w,o.h)}else if(o.type==='draw'&&o.points?.length){ctx.strokeStyle=o.color||'#8b7cff';ctx.lineWidth=o.size||8;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();o.points.forEach((p,i)=>i?ctx.lineTo(p.x-o.x,p.y-o.y):ctx.moveTo(p.x-o.x,p.y-o.y));ctx.stroke()}ctx.restore()}

function studioBounds(o){if(o.type==='circle'||o.type==='sticker')return {w:o.r*2,h:o.r*2};if(o.type==='text')return {w:Math.max(90,(o.size||72)*Math.max(1,(o.text||'Text').length)*.55),h:Math.max(50,(o.size||72)*1.25*(String(o.text||'').split('\n').length))};return {w:o.w||100,h:o.h||100}}
function resizeHandle(x,y,o){const b=studioBounds(o),dx=x-o.x,dy=y-o.y,tx=Math.max(18,b.w*.045),ty=Math.max(18,b.h*.045),nearX=Math.abs(Math.abs(dx)-b.w/2)<=tx,nearY=Math.abs(Math.abs(dy)-b.h/2)<=ty,insideX=Math.abs(dx)<=b.w/2+tx,insideY=Math.abs(dy)<=b.h/2+ty;if(!insideX||!insideY)return null;if(nearX&&nearY)return (dx<0?'w':'e')+(dy<0?'n':'s');if(nearY&&Math.abs(dx)<=b.w/2+tx)return dy<0?'n':'s';if(nearX&&Math.abs(dy)<=b.h/2+ty)return dx<0?'w':'e';return null}
function applyResize(o,r,dir){const sx=r.startW,sy=r.startH,dx=r.x-r.startX,dy=r.y-r.startY;let nw=sx,nh=sy,nx=r.origX,ny=r.origY;if(dir.includes('e')){nw=Math.max(30,sx+dx*2);nx=r.origX+(nw-sx)/2}else if(dir.includes('w')){nw=Math.max(30,sx-dx*2);nx=r.origX-(nw-sx)/2}if(dir.includes('s')){nh=Math.max(30,sy+dy*2);ny=r.origY+(nh-sy)/2}else if(dir.includes('n')){nh=Math.max(30,sy-dy*2);ny=r.origY-(nh-sy)/2}if(o.type==='circle'||o.type==='sticker'){const n=Math.max(25,Math.max(nw,nh)/2);o.r=n}else if(o.type==='text'){const scale=Math.max(.25,Math.min(5,nw/sx,nh/sy));o.size=Math.max(12,(r.startSize||o.size)*scale)}else{o.w=nw;o.h=nh}o.x=nx;o.y=ny}
function studioPointerDownEnhanced(e){if(studio.tool==='draw'){return studioPointerDown(e)}const r=studio.canvas.getBoundingClientRect(),sx=studio.canvas.width/r.width,sy=studio.canvas.height/r.height,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy,o=studioSelected();if(o){const dir=resizeHandle(x,y,o);if(dir){studioResize={id:o.id,dir,startX:x,startY:y,x,y,startW:studioBounds(o).w,startH:studioBounds(o).h,startSize:o.size,origX:o.x,origY:o.y};return}}studio.selected=studioHit(x,y);const picked=studioSelected();if(picked)studioGesture={id:picked.id,startX:x,startY:y,origX:picked.x,origY:picked.y};studioRender()}
function studioPointerMoveEnhanced(e){if(studio.tool==='draw')return studioPointerMove(e);const r=studio.canvas.getBoundingClientRect(),sx=studio.canvas.width/r.width,sy=studio.canvas.height/r.height,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy;if(studioResize){const o=studio.layers.find(a=>a.id===studioResize.id);if(!o)return;studioResize.x=x;studioResize.y=y;if(!o.locked){applyResize(o,studioResize,studioResize.dir);studioRender();}return}if(studioGesture){const o=studio.layers.find(a=>a.id===studioGesture.id);if(o&&!o.locked){o.x=studioGesture.origX+(x-studioGesture.startX);o.y=studioGesture.origY+(y-studioGesture.startY);studioRender()}}}
function studioPointerUpEnhanced(){if(studioResize||studioGesture){studioResize=null;studioGesture=null;studioSaveHistory();studioRender()}}
function touchStartEnhanced(e){if(studio.tool==='draw'){studioPointerDown(e.touches[0]);e.preventDefault();return}Array.from(e.changedTouches).forEach(t=>studioPointers.set(t.identifier,t));const a=[...studioPointers.values()];if(a.length===1){const p=canvasPoint(a[0]),o=studioSelected();if(o){const dir=resizeHandle(p.x,p.y,o);if(dir){studioResize={id:o.id,dir,startX:p.x,startY:p.y,x:p.x,y:p.y,startW:studioBounds(o).w,startH:studioBounds(o).h,startSize:o.size,origX:o.x,origY:o.y};e.preventDefault();return}}studio.selected=studioHit(p.x,p.y);const picked=studioSelected();if(picked)studioGesture={id:picked.id,startX:p.x,startY:p.y,origX:picked.x,origY:picked.y}}else if(a.length===2&&studio.selected){const b=studioBounds(studioSelected()),d=Math.hypot(a[0].clientX-a[1].clientX,a[0].clientY-a[1].clientY);studioGesture={pinch:true,id:studio.selected,startDist:d,startW:b.w,startH:b.h,startSize:studioSelected().size};}studioRender();e.preventDefault()}
function touchMoveEnhanced(e){Array.from(e.changedTouches).forEach(t=>studioPointers.set(t.identifier,t));const a=[...studioPointers.values()];if(a.length===2&&studioGesture?.pinch){const o=studioSelected(),d=Math.hypot(a[0].clientX-a[1].clientX,a[0].clientY-a[1].clientY),scale=Math.max(.15,Math.min(6,d/studioGesture.startDist));if(o){if(o.type==='circle'||o.type==='sticker')o.r=Math.max(25,studioGesture.startW/2*scale);else if(o.type==='text')o.size=Math.max(12,(studioGesture.startSize||o.size)*scale);else{o.w=Math.max(30,studioGesture.startW*scale);o.h=Math.max(30,studioGesture.startH*scale)}}studioRender();e.preventDefault();return}if(studioResize&&a.length===1){const p=canvasPoint(a[0]),o=studioSelected();if(o){studioResize.x=p.x;studioResize.y=p.y;applyResize(o,studioResize,studioResize.dir);studioRender()}e.preventDefault();return}if(studioGesture&&!studioGesture.pinch&&a.length===1){const p=canvasPoint(a[0]),o=studioSelected();if(o){o.x=studioGesture.origX+p.x-studioGesture.startX;o.y=studioGesture.origY+p.y-studioGesture.startY;studioRender()}e.preventDefault()}}
function touchEndEnhanced(e){Array.from(e.changedTouches).forEach(t=>studioPointers.delete(t.identifier));if(studioPointers.size===0){studioGesture=null;studioResize=null;studioSaveHistory();studioRender()}}
const _studioDrawSelection=studioDrawSelection;
function studioDrawSelection(ctx,o){if(!o)return;const b=studioBounds(o);ctx.save();ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);ctx.strokeStyle='#7e75ff';ctx.lineWidth=3;ctx.setLineDash([8,6]);ctx.strokeRect(-b.w/2,-b.h/2,b.w,b.h);ctx.setLineDash([]);ctx.fillStyle='#7e75ff';const hs=[[-b.w/2,-b.h/2],[0,-b.h/2],[b.w/2,-b.h/2],[b.w/2,0],[b.w/2,b.h/2],[0,b.h/2],[-b.w/2,b.h/2],[-b.w/2,0]];hs.forEach(p=>ctx.fillRect(p[0]-6,p[1]-6,12,12));ctx.restore()}
// Override the status message so the editor no longer shows instructional touch text.
const _enhancedStudioRender=studioRender;studioRender=function(){_enhancedStudioRender();if(studio.selected){const o=studioSelected();if(o){const ctx=studio.canvas.getContext('2d');studioDrawSelection(ctx,o)}}const st=document.getElementById('studioStatusText');if(st)st.textContent=`Ready • ${studioPage.width} × ${studioPage.height}`};

/* ===== V4 COLOR / GRADIENT + REAL FONT STYLE CONTROLS ===== */
const _FONT_STYLE_MAP={Regular:{w:400,i:false},Medium:{w:500,i:false},SemiBold:{w:600,i:false},Bold:{w:700,i:false},ExtraBold:{w:800,i:false},Black:{w:900,i:false},Italic:{w:400,i:true},Light:{w:300,i:false},Heavy:{w:900,i:false},Rounded:{w:700,i:false},Luxury:{w:500,i:false},Elegant:{w:500,i:false},Playful:{w:700,i:false},Poster:{w:900,i:false},Tech:{w:700,i:false},Display:{w:800,i:false},Text:{w:400,i:false},Modern:{w:600,i:false},Editorial:{w:500,i:false},Handwritten:{w:500,i:true},Mono:{w:500,i:false},Serif:{w:500,i:false},Sans:{w:500,i:false},Geometric:{w:600,i:false},Minimal:{w:500,i:false},Retro:{w:700,i:false},Wide:{w:700,i:false},Condensed:{w:700,i:false},Soft:{w:600,i:false}};
function studioApplyFont(family,style='Regular'){const o=studioSelected();if(!o||o.type!=='text'){studioToast('Select a text layer first');return}const m=_FONT_STYLE_MAP[style]||_FONT_STYLE_MAP.Regular;o.font=family;o.fontStyle=m.i?'italic':'normal';o.weight=m.w;o.fontLabel=`${family} ${style}`;studioSaveHistory();studioRender();studioCloseModal();studioToast(`${family} • ${style} applied`)}
function studioUseFont(family,style='Regular'){studioApplyFont(family,style)}
function studioOpenFill(target='selected'){const o=target==='background'?null:studioSelected();if(target!=='background'&&!o){studioToast('Select a layer first');return}const cur=o?.fill||o?.color||'#8b7cff',c2=o?.gradient?.c2||'#39dfcf',ang=o?.gradient?.angle??135,mode=o?.gradient?'gradient':'solid';studioModal(`<div class="modalHeader"><div><span class="eyebrow">STYLE ENGINE</span><h2 style="margin:5px 0 0">🎨 Color & Gradient</h2></div><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="fillModeTabs"><button id="fillSolidBtn" class="${mode==='solid'?'active':''}" onclick="studioFillMode('solid')">SOLID COLOR</button><button id="fillGradientBtn" class="${mode==='gradient'?'active':''}" onclick="studioFillMode('gradient')">GRADIENT</button></div><div id="fillControls"></div>`);window.__fillTarget=target;window.__fillMode=mode;window.__fillData={c1:cur,c2,ang};studioRenderFillControls()}
function studioFillMode(mode){window.__fillMode=mode;document.getElementById('fillSolidBtn')?.classList.toggle('active',mode==='solid');document.getElementById('fillGradientBtn')?.classList.toggle('active',mode==='gradient');studioRenderFillControls()}
function studioRenderFillControls(){const d=window.__fillData||{c1:'#8b7cff',c2:'#39dfcf',ang:135},box=document.getElementById('fillControls');if(!box)return;box.innerHTML=window.__fillMode==='solid'?`<label class="label">COLOR</label><div class="studioFillPreview" style="background:${d.c1}"></div><input id="fillC1" type="color" value="${d.c1}" style="width:100%;height:48px"><div class="studioColorSwatches">${['#ffffff','#000000','#8b7cff','#39dfcf','#ff4fd8','#ffb84d','#4da6ff','#35e0a1','#ff5c7a','#ffd166','#7c5cff','#00d4ff'].map(c=>`<button class="studioSwatch" style="background:${c}" onclick="document.getElementById('fillC1').value='${c}';studioRenderFillControls()"></button>`).join('')}</div><button class="studioBtn primary" style="width:100%;margin-top:12px" onclick="studioApplyFill()">✓ Apply Color</button>`:`<label class="label">GRADIENT COLORS</label><div class="gradientRow"><div><small class="muted">START</small><input id="fillC1" type="color" value="${d.c1}" style="width:100%;height:48px"></div><div><small class="muted">END</small><input id="fillC2" type="color" value="${d.c2}" style="width:100%;height:48px"></div></div><div class="prop" style="margin-top:10px"><label>ANGLE <span id="angleVal">${d.ang}°</span></label><input id="fillAng" class="gradientAngle" type="range" min="0" max="360" value="${d.ang}" oninput="angleVal.textContent=this.value+'°'"></div><div class="studioFillPreview" style="background:linear-gradient(${d.ang}deg,${d.c1},${d.c2})"></div><button class="studioBtn primary" style="width:100%;margin-top:10px" onclick="studioApplyFill()">✓ Apply Gradient</button>`}
function studioApplyFill(){const d=window.__fillData||{};const c1=document.getElementById('fillC1')?.value||d.c1,c2=document.getElementById('fillC2')?.value||d.c2,ang=+(document.getElementById('fillAng')?.value||d.ang||135),target=window.__fillTarget,o=target==='background'?null:studioSelected();if(target==='background'){studio.bgGradient={c1,c2,angle:ang};studio.bg=c1}else if(o){o.color=c1;o.fill=c1;o.gradient=window.__fillMode==='gradient'?{c1,c2,angle:ang}:null}studioSaveHistory();studioRender();studioCloseModal();studioToast(window.__fillMode==='gradient'?'Gradient applied':'Color applied')}
function studioPaint(ctx,o){if(o.gradient){const a=(o.gradient.angle||0)*Math.PI/180,dx=Math.cos(a)*500,dy=Math.sin(a)*500;const g=ctx.createLinearGradient(-dx,-dy,dx,dy);g.addColorStop(0,o.gradient.c1);g.addColorStop(1,o.gradient.c2);return g}return o.color||'#8b7cff'}
function studioDrawObjectV4(ctx,o){ctx.save();ctx.globalAlpha=o.opacity??1;ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);if(o.type==='text'){const size=o.size||72,lines=String(o.text||'Text').split('\n'),lineH=size*1.12;ctx.font=`${o.fontStyle||'normal'} ${o.weight||700} ${size}px '${o.font||'Arial'}',sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';if(o.textBgEnabled){let maxW=0;for(const line of lines)maxW=Math.max(maxW,ctx.measureText(line).width);const pad=22,boxW=maxW+pad*2,boxH=lines.length*lineH+pad;ctx.fillStyle=o.textBg||'#ffffff';ctx.fillRect(-boxW/2,-boxH/2,boxW,boxH)}ctx.fillStyle=studioPaint(ctx,o);const ls=+(o.letterSpacing||0);lines.forEach((line,i)=>{const yy=(i-(lines.length-1)/2)*lineH;if(!ls){ctx.fillText(line,0,yy);return}let widths=[...line].map(ch=>ctx.measureText(ch).width),total=widths.reduce((a,b)=>a+b,0)+ls*Math.max(0,widths.length-1),xx=-total/2;ctx.textAlign='left';[...line].forEach((ch,j)=>{ctx.fillText(ch,xx,yy);xx+=widths[j]+ls});ctx.textAlign='center'})}else if(o.type==='rect'){ctx.fillStyle=studioPaint(ctx,o);ctx.fillRect(-o.w/2,-o.h/2,o.w,o.h);if(o.elementType==='frame'||o.type==='frame'){ctx.strokeStyle='#fff';ctx.lineWidth=10;ctx.strokeRect(-o.w/2+8,-o.h/2+8,o.w-16,o.h-16)}}else if(o.type==='circle'){ctx.fillStyle=studioPaint(ctx,o);ctx.beginPath();ctx.arc(0,0,o.r||130,0,Math.PI*2);ctx.fill()}else if(o.type==='sticker'){ctx.fillStyle=studioPaint(ctx,o);ctx.beginPath();for(let i=0;i<20;i++){let a=i*Math.PI/10,r=i%2?95:135;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();ctx.fillStyle='#fff';ctx.font='700 44px Inter,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('✦',0,0)}else if(o.type==='line'){ctx.strokeStyle=studioPaint(ctx,o);ctx.lineWidth=Math.max(4,o.h||8);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-o.w/2,0);ctx.lineTo(o.w/2,0);ctx.stroke();if(o.elementType==='arrow'){ctx.beginPath();ctx.moveTo(o.w/2-24,-18);ctx.lineTo(o.w/2,0);ctx.lineTo(o.w/2-24,18);ctx.stroke()}}else if(o.type==='chart'){ctx.strokeStyle='#39455f';ctx.lineWidth=3;ctx.strokeRect(-o.w/2,-o.h/2,o.w,o.h);ctx.fillStyle=studioPaint(ctx,o);[.35,.6,.48,.82,.55,.72].forEach((v,i)=>ctx.fillRect(-o.w/2+25+i*60,o.h/2-20-v*(o.h-45),42,v*(o.h-45)))}else if(o.type==='image'&&o.img){ctx.filter=o.filter||'none';ctx.drawImage(o.img,-o.w/2,-o.h/2,o.w,o.h)}else if(o.type==='draw'&&o.points?.length){ctx.strokeStyle=studioPaint(ctx,o);ctx.lineWidth=o.size||8;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();o.points.forEach((p,i)=>i?ctx.lineTo(p.x-o.x,p.y-o.y):ctx.moveTo(p.x-o.x,p.y-o.y));ctx.stroke()}ctx.restore()}

const _oldStudioRenderV4=studioRender;studioRender=function(){if(!studio.canvas)return;const ctx=studio.canvas.getContext('2d');ctx.clearRect(0,0,studio.canvas.width,studio.canvas.height);if(studio.bgGradient){const a=(studio.bgGradient.angle||0)*Math.PI/180,dx=Math.cos(a)*studio.canvas.width,dy=Math.sin(a)*studio.canvas.height,g=ctx.createLinearGradient(studio.canvas.width/2-dx/2,studio.canvas.height/2-dy/2,studio.canvas.width/2+dx/2,studio.canvas.height/2+dy/2);g.addColorStop(0,studio.bgGradient.c1);g.addColorStop(1,studio.bgGradient.c2);ctx.fillStyle=g}else{ctx.fillStyle=studio.bg||'#fff'}ctx.fillRect(0,0,studio.canvas.width,studio.canvas.height);studio.layers.forEach(o=>studioDrawObjectV4(ctx,o));if(studio.selected){const o=studioSelected();if(o)studioDrawSelection(ctx,o)}studioUpdateLayers();studioUpdateProps();const st=document.getElementById('studioStatusText');if(st)st.textContent=`Ready • ${studioPage.width} × ${studioPage.height}`;const d=document.getElementById('studioMobileDrawer');if(d?.classList.contains('open')){const t=document.getElementById('studioMobileDrawerTitle')?.textContent;if(t==='LAYERS')studioMobilePanel('layers');else if(t==='PROPERTIES')studioMobilePanel('properties')}}
const _oldPropsV4=studioUpdateProps;studioUpdateProps=function(){const el=document.getElementById('studioProps'),o=studioSelected();if(!el)return;if(!o){el.className='studioEmpty';el.innerHTML='Select a layer to edit its properties.';return}el.className='';const dis=o.locked?'disabled':'';let html=`<div class="propGrid"><div class="prop"><label>X</label><input type="number" value="${Math.round(o.x)}" ${dis} oninput="studioSet('x',this.value)"></div><div class="prop"><label>Y</label><input type="number" value="${Math.round(o.y)}" ${dis} oninput="studioSet('y',this.value)"></div><div class="prop"><label>ROTATION</label><input type="number" value="${Math.round(o.rotation||0)}" ${dis} oninput="studioSet('rotation',this.value)"></div><div class="prop"><label>OPACITY</label><input type="range" min="0" max="100" value="${Math.round((o.opacity??1)*100)}" ${dis} oninput="studioSet('opacity',this.value/100)"></div></div>`;
html+=`<div class="studioInlineStyle"><h4>🎨 COLOR & GRADIENT</h4><div class="studioColorRow"><div class="studioColorBox"><span>COLOR</span><input id="inlineColor" type="color" value="${o.color||o.fill||'#8b7cff'}" ${dis} oninput="studioInlineColor(this.value)"></div><div class="studioColorBox"><span>GRADIENT END</span><input id="inlineColor2" type="color" value="${o.gradient?.c2||'#39dfcf'}" ${dis} oninput="studioInlineGradient()"></div></div><div class="studioGradientPreview" id="inlineGradientPreview" style="background:${o.gradient?`linear-gradient(${o.gradient.angle||135}deg,${o.gradient.c1},${o.gradient.c2})`:(o.color||'#8b7cff')}"></div><div class="prop" style="margin-top:8px"><label>GRADIENT ANGLE <span id="inlineAngleVal">${o.gradient?.angle||135}°</span></label><input id="inlineAngle" type="range" min="0" max="360" value="${o.gradient?.angle||135}" ${dis} oninput="studioInlineGradient()"></div><div class="tools"><button class="studioBtn" ${dis} onclick="studioInlineGradient()">🌈 Apply Gradient</button><button class="studioBtn" ${dis} onclick="studioClearGradient()">Solid</button></div></div>`;
if(o.type==='text')html+=`<div class="prop" style="margin-top:10px"><label>TEXT</label><button class="studioBtn" style="width:100%" onclick="studioTextEditor('${o.id}',true)" ${dis}>✎ Edit Text & Keyboard</button></div><div class="propGrid" style="margin-top:8px"><div class="prop"><label>SIZE</label><input type="number" value="${o.size}" ${dis} oninput="studioSet('size',this.value)"></div><div class="prop"><label>LETTER SPACING</label><input type="number" value="${o.letterSpacing||0}" ${dis} oninput="studioSet('letterSpacing',this.value)"></div></div><div class="textStyleRow" style="margin-top:8px"><div class="prop"><label>WEIGHT</label><select ${dis} onchange="studioSet('weight',this.value)"><option value="300" ${o.weight==300?'selected':''}>Light</option><option value="400" ${o.weight==400?'selected':''}>Regular</option><option value="600" ${o.weight==600?'selected':''}>SemiBold</option><option value="700" ${o.weight==700?'selected':''}>Bold</option><option value="800" ${o.weight==800?'selected':''}>ExtraBold</option><option value="900" ${o.weight==900?'selected':''}>Black</option></select></div><div class="prop"><label>STYLE</label><select ${dis} onchange="studioSet('fontStyle',this.value)"><option value="normal" ${o.fontStyle!=='italic'?'selected':''}>Normal</option><option value="italic" ${o.fontStyle==='italic'?'selected':''}>Italic</option></select></div></div><button class="studioBtn" style="width:100%;margin-top:8px" onclick="studioFonts()" ${dis}>Aa ${esc(o.fontLabel||o.font||'Choose Font')}</button><div class="studioTextBg"><input id="textBgColor" type="color" value="${o.textBg||'#ffffff'}" ${dis} onchange="studioSetTextBg(this.value)"><label style="font-size:8px;color:#8b96aa">Text Background</label><input id="textBgToggle" type="checkbox" ${o.textBgEnabled?'checked':''} ${dis} onchange="studioSetTextBgEnabled(this.checked)"></div>`;
html+=`<div class="tools" style="margin-top:12px"><button class="studioBtn ${o.locked?'primary':''}" onclick="studioToggleLock('${o.id}')">${o.locked?'🔓 Unlock Layer':'🔒 Lock Layer'}</button><button class="studioBtn danger" onclick="studioDelete('${o.id}')">🗑 Remove from Page</button></div>${o.locked?'<div class="studioLockedNotice">🔒 Locked — unlock to move, resize or edit.</div>':''}`;el.innerHTML=html}
function studioInlineColor(v){const o=studioSelected();if(!o||o.locked)return;o.color=v;o.fill=v;o.gradient=null;studioSaveHistory();studioRender()}
function studioInlineGradient(){const o=studioSelected();if(!o||o.locked)return;const c1=document.getElementById('inlineColor')?.value||o.color||'#8b7cff',c2=document.getElementById('inlineColor2')?.value||'#39dfcf',ang=+(document.getElementById('inlineAngle')?.value||135);o.color=c1;o.fill=c1;o.gradient={c1,c2,angle:ang};studioSaveHistory();studioRender()}
function studioClearGradient(){const o=studioSelected();if(!o||o.locked)return;o.gradient=null;studioSaveHistory();studioRender()}
function studioSetTextBg(v){const o=studioSelected();if(!o||o.locked)return;o.textBg=v;o.textBgEnabled=true;studioSaveHistory();studioRender()}
function studioSetTextBgEnabled(v){const o=studioSelected();if(!o||o.locked)return;o.textBgEnabled=v;studioSaveHistory();studioRender()}
function studioToggleLock(id){const o=studio.layers.find(x=>x.id===id);if(!o)return;o.locked=!o.locked;studioSaveHistory();studioRender();studioToast(o.locked?'Layer locked 🔒':'Layer unlocked 🔓');const d=document.getElementById('studioMobileDrawer');if(d?.classList.contains('open')){const title=document.getElementById('studioMobileDrawerTitle');if(title?.textContent==='LAYERS')studioMobilePanel('layers');else studioMobilePanel('properties')}}


function studioBackground(){studioOpenFill('background')}



/* V7 editing-screen controls: fit/zoom, keyboard delete, safer mobile drawer. */
window.studioZoomLevel=1;
function studioApplyZoom(){const f=document.getElementById('canvasFrame');const v=document.getElementById('studioZoomValue');if(!f)return;f.style.transform=`scale(${studioZoomLevel})`;if(v)v.textContent=Math.round(studioZoomLevel*100)+'%';}
function studioZoom(dir){studioZoomLevel=Math.max(.35,Math.min(2.5,studioZoomLevel+(dir>0?.1:-.1)));studioApplyZoom();}
function studioFit(){studioZoomLevel=1;studioApplyZoom();const stage=document.querySelector('.studioCanvasStage'),frame=document.getElementById('canvasFrame');if(!stage||!frame||!studio.canvas)return;const pad=48,w=stage.clientWidth-pad,h=stage.clientHeight-pad,scale=Math.min(w/studio.canvas.width,h/studio.canvas.height,1);studioZoomLevel=Math.max(.35,Math.min(1,scale));studioApplyZoom();}
function studioCanvasScreenReset(){studioZoomLevel=1;studioApplyZoom();}
document.addEventListener('keydown',e=>{if(!document.getElementById('studioApp')?.classList.contains('active'))return;if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;if((e.key==='Delete'||e.key==='Backspace')&&studio.selected){e.preventDefault();studioDeleteSelected();}if(e.key==='Escape'){studio.selected=null;studioRender();}});
const __v7Render=studioRender;
studioRender=function(){__v7Render();requestAnimationFrame(()=>{if(document.getElementById('studioApp')?.classList.contains('active')&&studio.canvas&&!studioZoomLevel)studioZoomLevel=1;studioApplyZoom();});};



// V6-style reliability overrides: mobile Layers/Properties are always synchronized with the canvas.
function studioMobilePanel(which){const d=document.getElementById('studioMobileDrawer'),title=document.getElementById('studioMobileDrawerTitle'),body=document.getElementById('studioMobileDrawerBody');if(!d||!title||!body)return;document.querySelectorAll('.studioMobileBar button').forEach(b=>b.classList.remove('active'));const buttons=[...document.querySelectorAll('.studioMobileBar button')];const idx=which==='create'?0:which==='layers'?1:2;buttons[idx]?.classList.add('active');if(which==='create'){d.classList.remove('open');return}title.textContent=which==='layers'?'LAYERS':'PROPERTIES';if(which==='layers'){studioUpdateLayers();body.innerHTML=document.getElementById('studioLayers')?.innerHTML||'<div class="studioEmpty">No layers</div>';body.querySelectorAll('.layerRow').forEach(r=>{const m=r.getAttribute('onclick')?.match(/'([^']+)'/);if(m)r.setAttribute('onclick',`studioMobileSelect('${m[1]}')`)});}else{studioUpdateProps();body.innerHTML=document.getElementById('studioProps')?.innerHTML||'<div class="studioEmpty">Select a layer</div>';}d.classList.add('open')}
function studioMobileSelect(id){studio.selected=id;studioRender();studioMobilePanel('properties')}
function studioCloseMobileDrawer(){document.getElementById('studioMobileDrawer')?.classList.remove('open')}



/* ===== V9 PRO DESIGN-EDITOR ENGINE ===== */
studio.gradients=studio.gradients||[];
function v9Num(v,d=0){const n=parseFloat(v);return Number.isFinite(n)?n:d}
function v9Color(v,d='#8b7cff'){return /^#[0-9a-f]{6}$/i.test(v||'')?v:d}
function v9Save(){try{studioSaveHistory()}catch(e){};studioRender()}
function studioApplyMixedGradient(c1,c2,angle=135){const o=studioSelected();if(!o||o.locked)return;const g={c1:v9Color(c1),c2:v9Color(c2,'#39dfcf'),angle:v9Num(angle,135)};o.gradient=g;o.color=g.c1;o.fill=g.c1;studio.gradients=studio.gradients||[];const key=`${g.c1}|${g.c2}|${g.angle}`;if(!studio.gradients.some(x=>x.key===key))studio.gradients.unshift({key,...g});studio.gradients=studio.gradients.slice(0,24);v9Save();studioToast('Mixed gradient applied 🌈')}
function studioApplyGradientPreset(key){const g=(studio.gradients||[]).find(x=>x.key===key);if(g)studioApplyMixedGradient(g.c1,g.c2,g.angle)}
function studioAddGradientPreset(){const c1=document.getElementById('v9g1')?.value||'#8b7cff',c2=document.getElementById('v9g2')?.value||'#39dfcf',a=document.getElementById('v9ga')?.value||135;studioApplyMixedGradient(c1,c2,a)}
function studioSetStrokeColor(v){const o=studioSelected();if(!o||o.locked)return;o.strokeColor=v;o.strokeEnabled=true;v9Save()}
function studioSetStrokeWidth(v){const o=studioSelected();if(!o||o.locked)return;o.strokeWidth=Math.max(0,v9Num(v));o.strokeEnabled=o.strokeWidth>0;v9Save()}
function studioSetStrokeEnabled(v){const o=studioSelected();if(!o||o.locked)return;o.strokeEnabled=v;v9Save()}
function studioSetShadow(v){const o=studioSelected();if(!o||o.locked)return;o.shadowEnabled=v;v9Save()}
function studioSetBlur(v){const o=studioSelected();if(!o||o.locked)return;o.blur=Math.max(0,v9Num(v));v9Save()}
function studioSetRadius(v){const o=studioSelected();if(!o||o.locked)return;o.radius=Math.max(0,v9Num(v));v9Save()}
function studioSetBlend(v){const o=studioSelected();if(!o||o.locked)return;o.blend=v;v9Save()}
function studioSetTextAlign(v){const o=studioSelected();if(!o||o.locked)return;o.textAlign=v;v9Save()}
function studioFlip(axis){const o=studioSelected();if(!o||o.locked)return;if(axis==='x')o.flipX=!o.flipX;else o.flipY=!o.flipY;v9Save()}
function studioMove(dx,dy){const o=studioSelected();if(!o||o.locked)return;o.x+=dx;o.y+=dy;v9Save()}
function studioAlign(mode){const o=studioSelected();if(!o||o.locked)return;const w=studioPage.width,h=studioPage.height;if(mode==='left')o.x=(o.w||o.r*2||300)/2;if(mode==='center')o.x=w/2;if(mode==='right')o.x=w-(o.w||o.r*2||300)/2;if(mode==='top')o.y=(o.h||o.r*2||120)/2;if(mode==='middle')o.y=h/2;if(mode==='bottom')o.y=h-(o.h||o.r*2||120)/2;v9Save();studioToast('Aligned '+mode)}
function studioToggleHidden(id){const o=studio.layers.find(x=>x.id===id);if(!o)return;o.hidden=!o.hidden;studioRender()}
function studioGroupSelected(){const o=studioSelected();if(!o)return;studioToast('Grouping is ready for multi-select in the next selection mode');}
function studioCropImage(){const o=studioSelected();if(!o||o.type!=='image'){studioToast('Select an image first');return}studioModal(`<div class="modalHeader"><h2>✂ Crop / Image Frame</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><p class="muted">Use width and height to crop the visible frame proportionally.</p><div class="propGrid"><div class="prop"><label>WIDTH</label><input id="cropW" type="number" value="${Math.round(o.w)}"></div><div class="prop"><label>HEIGHT</label><input id="cropH" type="number" value="${Math.round(o.h)}"></div></div><div class="tools" style="margin-top:12px"><button class="studioBtn primary" onclick="studioSet('w',document.getElementById('cropW').value);studioSet('h',document.getElementById('cropH').value);studioCloseModal()">Apply Crop Frame</button></div>`)}
function studioOpenAllTools(){studioModal(`<div class="modalHeader"><h2>⚡ Full Editor Toolkit</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="studioFeatureList"><button onclick="studioAddText();studioCloseModal()">T Text</button><button onclick="studioElements();">✦ Elements</button><button onclick="studioFonts();">Aa Fonts</button><button onclick="document.getElementById('studioImageInput')?.click();studioCloseModal()">▣ Image</button><button onclick="studioBackground();studioCloseModal()">🎨 Background</button><button onclick="studioOpenGradientMixer()">🌈 Gradient</button><button onclick="studioCropImage();studioCloseModal()">✂ Crop</button><button onclick="studioDuplicate();studioCloseModal()">⧉ Duplicate</button><button onclick="studioDeleteSelected();studioCloseModal()">🗑 Delete</button><button onclick="studioBring('front');studioCloseModal()">⬆ Front</button><button onclick="studioBring('back');studioCloseModal()">⬇ Back</button><button onclick="studioFlip('x');studioCloseModal()">↔ Flip X</button><button onclick="studioFlip('y');studioCloseModal()">↕ Flip Y</button><button onclick="studioAlign('left');studioCloseModal()">⇤ Left</button><button onclick="studioAlign('center');studioCloseModal()">↔ Center</button><button onclick="studioAlign('right');studioCloseModal()">⇥ Right</button></div>`)}
function studioOpenGradientMixer(){const o=studioSelected(),g=o?.gradient||{c1:o?.color||'#8b7cff',c2:'#39dfcf',angle:135};const presets=(studio.gradients||[]).slice(0,12);studioModal(`<div class="modalHeader"><h2>🌈 Gradient Mixer</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="studioColorWide"><div><label class="small">COLOR 1</label><input id="v9g1" type="color" value="${g.c1}"></div><div><label class="small">COLOR 2</label><input id="v9g2" type="color" value="${g.c2}"></div></div><div id="v9mix" class="mixPreview" style="background:linear-gradient(${g.angle}deg,${g.c1},${g.c2})"></div><div class="prop"><label>ANGLE <span id="v9angleText">${g.angle}°</span></label><input class="studioRange" id="v9ga" type="range" min="0" max="360" value="${g.angle}" oninput="v9UpdateMix()"></div><button class="studioBtn primary studioFullBtn" onclick="studioAddGradientPreset();studioCloseModal()">✓ Mix & Apply</button><div class="studioPropsSection"><h4>RECENT MIXES — TAP TO APPLY</h4><div class="gradientStops">${presets.map(x=>`<button class="gradientSwatch" title="${x.c1} → ${x.c2}" style="background:linear-gradient(${x.angle}deg,${x.c1},${x.c2})" onclick="studioApplyGradientPreset('${x.key}') ;studioCloseModal()"></button>`).join('')}</div></div>`);}
function v9UpdateMix(){const a=v9Num(document.getElementById('v9ga')?.value,135),c1=document.getElementById('v9g1')?.value||'#8b7cff',c2=document.getElementById('v9g2')?.value||'#39dfcf';const m=document.getElementById('v9mix');if(m)m.style.background=`linear-gradient(${a}deg,${c1},${c2})`;const t=document.getElementById('v9angleText');if(t)t.textContent=a+'°'}
function v9TextAlignValue(o){return o.textAlign||'center'}
function studioUpdateProps(){const el=document.getElementById('studioProps'),o=studioSelected();if(!el)return;if(!o){el.className='studioEmpty';el.innerHTML='Select any layer on the canvas or from Layers.';return}el.className='';const dis=o.locked?'disabled':'';let sizeW=o.w||((o.r||130)*2),sizeH=o.h||((o.r||130)*2);let html=`<div class="propGrid"><div class="prop"><label>X</label><input type="number" value="${Math.round(o.x)}" ${dis} oninput="studioSet('x',this.value)"></div><div class="prop"><label>Y</label><input type="number" value="${Math.round(o.y)}" ${dis} oninput="studioSet('y',this.value)"></div><div class="prop"><label>WIDTH</label><input type="number" value="${Math.round(sizeW)}" ${dis} oninput="studioSet('${o.r?'r':'w'}',${o.r?'this.value/2':'this.value'})"></div><div class="prop"><label>HEIGHT</label><input type="number" value="${Math.round(sizeH)}" ${dis} oninput="studioSet('h',this.value)"></div><div class="prop"><label>ROTATION</label><input type="number" value="${Math.round(o.rotation||0)}" ${dis} oninput="studioSet('rotation',this.value)"></div><div class="prop"><label>OPACITY</label><input type="range" min="0" max="100" value="${Math.round((o.opacity??1)*100)}" ${dis} oninput="studioSet('opacity',this.value/100)"></div></div>`;
html+=`<div class="studioPropsSection"><h4>🎨 FILL & GRADIENT</h4><div class="studioColorWide"><div><label class="small">SOLID COLOR</label><input type="color" value="${o.color||o.fill||'#8b7cff'}" ${dis} oninput="studioInlineColor(this.value)"></div><div><label class="small">GRADIENT COLOR 2</label><input type="color" value="${o.gradient?.c2||'#39dfcf'}" ${dis} oninput="studioInlineGradient()"></div></div><div class="mixPreview" style="background:${o.gradient?`linear-gradient(${o.gradient.angle||135}deg,${o.gradient.c1},${o.gradient.c2})`:(o.color||'#8b7cff')}"></div><button class="studioBtn primary studioFullBtn" ${dis} onclick="studioOpenGradientMixer()">🌈 Open Gradient Mixer</button><button class="studioBtn studioFullBtn" ${dis} onclick="studioClearGradient()">Solid Fill</button></div>`;
html+=`<div class="studioPropsSection"><h4>🖊 STROKE / OUTLINE</h4><div class="studioColorWide"><div><label class="small">STROKE COLOR</label><input type="color" value="${o.strokeColor||'#ffffff'}" ${dis} onchange="studioSetStrokeColor(this.value)"></div><div class="prop"><label>WIDTH</label><input type="number" min="0" max="80" value="${o.strokeWidth||0}" ${dis} oninput="studioSetStrokeWidth(this.value)"></div></div><div class="studioCheckRow"><label>ENABLE STROKE</label><input type="checkbox" ${o.strokeEnabled?'checked':''} ${dis} onchange="studioSetStrokeEnabled(this.checked)"></div></div>`;
html+=`<div class="studioPropsSection"><h4>✨ EFFECTS</h4><div class="studioCheckRow"><label>DROP SHADOW</label><input type="checkbox" ${o.shadowEnabled?'checked':''} ${dis} onchange="studioSetShadow(this.checked)"></div><div class="prop"><label>BLUR · ${o.blur||0}px</label><input class="studioRange" type="range" min="0" max="30" value="${o.blur||0}" ${dis} oninput="studioSetBlur(this.value)"></div><div class="prop"><label>BLEND MODE</label><select class="studioSelect" ${dis} onchange="studioSetBlend(this.value)">${['source-over','multiply','screen','overlay','darken','lighten','color-dodge','color-burn'].map(x=>`<option value="${x}" ${o.blend===x?'selected':''}>${x}</option>`).join('')}</select></div></div>`;
if(o.type==='text')html+=`<div class="studioPropsSection"><h4>🔤 TEXT</h4><button class="studioBtn primary studioFullBtn" ${dis} onclick="studioTextEditor('${o.id}',true)">✎ Edit Text / Keyboard</button><div class="propGrid" style="margin-top:8px"><div class="prop"><label>SIZE</label><input type="number" value="${o.size||72}" ${dis} oninput="studioSet('size',this.value)"></div><div class="prop"><label>LETTER SPACING</label><input type="number" value="${o.letterSpacing||0}" ${dis} oninput="studioSet('letterSpacing',this.value)"></div></div><div class="prop" style="margin-top:8px"><label>FONT</label><button class="studioBtn studioFullBtn" ${dis} onclick="studioFonts()">Aa ${esc(o.fontLabel||o.font||'Choose Font')}</button></div><div class="studioPropTabs"><div class="studioCheckRow"><label>BOLD</label><input type="checkbox" ${(+o.weight||700)>=700?'checked':''} ${dis} onchange="studioSet('weight',this.checked?800:400)"></div><div class="studioCheckRow"><label>ITALIC</label><input type="checkbox" ${o.fontStyle==='italic'?'checked':''} ${dis} onchange="studioSet('fontStyle',this.checked?'italic':'normal')"></div></div><div class="studioPropsSection"><h4>ALIGNMENT</h4><div class="studioMiniGrid"><button class="studioMiniBtn" onclick="studioSetTextAlign('left')">Left</button><button class="studioMiniBtn" onclick="studioSetTextAlign('center')">Center</button><button class="studioMiniBtn" onclick="studioSetTextAlign('right')">Right</button></div></div><div class="studioCheckRow"><label>TEXT BACKGROUND</label><input type="checkbox" ${o.textBgEnabled?'checked':''} ${dis} onchange="studioSetTextBgEnabled(this.checked)"></div><div class="studioColorWide"><div><label class="small">BACKGROUND</label><input type="color" value="${o.textBg||'#ffffff'}" ${dis} onchange="studioSetTextBg(this.value)"></div><div><label class="small">STROKE</label><input type="color" value="${o.strokeColor||'#000000'}" ${dis} onchange="studioSetStrokeColor(this.value)"></div></div></div>`;
else html+=`<div class="studioPropsSection"><h4>SHAPE</h4><div class="prop"><label>CORNER RADIUS · ${o.radius||0}px</label><input class="studioRange" type="range" min="0" max="120" value="${o.radius||0}" ${dis} oninput="studioSetRadius(this.value)"></div></div>`;
html+=`<div class="studioPropsSection"><h4>↔ POSITION & TRANSFORM</h4><div class="studioMiniGrid"><button class="studioMiniBtn" onclick="studioFlip('x')">↔ Flip X</button><button class="studioMiniBtn" onclick="studioFlip('y')">↕ Flip Y</button><button class="studioMiniBtn" onclick="studioRotate(-15)">↺ -15°</button><button class="studioMiniBtn" onclick="studioRotate(15)">↻ +15°</button><button class="studioMiniBtn" onclick="studioAlign('center')">◎ Center</button><button class="studioMiniBtn" onclick="studioAlign('middle')">⊙ Middle</button></div></div><div class="studioActionGrid"><button class="studioBtn" onclick="studioDuplicate()">⧉ Duplicate</button><button class="studioBtn" onclick="studioBring('front')">⬆ Front</button><button class="studioBtn" onclick="studioBring('back')">⬇ Back</button></div><div class="studioActionGrid"><button class="studioBtn ${o.locked?'primary':''}" onclick="studioToggleLock('${o.id}')">${o.locked?'🔓 Unlock':'🔒 Lock'}</button><button class="studioBtn" onclick="studioToggleHidden('${o.id}')">${o.hidden?'👁 Show':'◌ Hide'}</button><button class="studioBtn danger" onclick="studioDelete('${o.id}')">🗑 Remove</button></div>${o.locked?'<div class="studioLockedNotice">🔒 Locked layer. Unlock it before changing position, size, color or effects.</div>':''}`;
el.innerHTML=html}
function studioDrawObjectV4(ctx,o){if(o.hidden)return;ctx.save();ctx.globalAlpha=o.opacity??1;ctx.globalCompositeOperation=o.blend||'source-over';ctx.filter=`${o.blur?`blur(${o.blur}px) `:''}${o.filter||''}`;ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);ctx.scale(o.flipX?-1:1,o.flipY?-1:1);const paint=studioPaint(ctx,o);if(o.shadowEnabled){ctx.shadowColor='rgba(0,0,0,.45)';ctx.shadowBlur=28;ctx.shadowOffsetX=10;ctx.shadowOffsetY=14}else{ctx.shadowColor='transparent';ctx.shadowBlur=0}
if(o.type==='text'){const size=o.size||72,lines=String(o.text||'Text').split('\n'),lineH=size*1.12;ctx.font=`${o.fontStyle||'normal'} ${o.weight||700} ${size}px '${o.font||'Arial'}',sans-serif`;ctx.textAlign=o.textAlign||'center';ctx.textBaseline='middle';let maxW=0;for(const line of lines)maxW=Math.max(maxW,ctx.measureText(line).width);if(o.textBgEnabled){const pad=o.textBgPadding||22;const bw=maxW+pad*2,bh=lines.length*lineH+pad*2;ctx.fillStyle=o.textBg||'#ffffff';ctx.fillRect(-bw/2,-bh/2,bw,bh)}const drawLine=(line,yy)=>{if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#000';ctx.lineWidth=o.strokeWidth;ctx.strokeText(line,0,yy)}ctx.fillStyle=paint;ctx.fillText(line,0,yy)};const ls=+(o.letterSpacing||0);lines.forEach((line,i)=>{const yy=(i-(lines.length-1)/2)*lineH;if(!ls){drawLine(line,yy);return}let widths=[...line].map(ch=>ctx.measureText(ch).width),total=widths.reduce((a,b)=>a+b,0)+ls*Math.max(0,widths.length-1),xx=-total/2;ctx.textAlign='left';[...line].forEach((ch,j)=>{if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#000';ctx.lineWidth=o.strokeWidth;ctx.strokeText(ch,xx,yy)}ctx.fillStyle=paint;ctx.fillText(ch,xx,yy);xx+=widths[j]+ls});ctx.textAlign=o.textAlign||'center'})}
else if(o.type==='rect'){const w=o.w||300,h=o.h||200,r=Math.min(o.radius||0,Math.min(w,h)/2);ctx.fillStyle=paint;if(r){ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,r);ctx.fill()}else ctx.fillRect(-w/2,-h/2,w,h);if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth;if(r){ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,r);ctx.stroke()}else ctx.strokeRect(-w/2,-h/2,w,h)}}
else if(o.type==='circle'){ctx.fillStyle=paint;ctx.beginPath();ctx.arc(0,0,o.r||130,0,Math.PI*2);ctx.fill();if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth;ctx.stroke()}}
else if(o.type==='sticker'){ctx.fillStyle=paint;ctx.beginPath();for(let i=0;i<20;i++){let a=i*Math.PI/10,r=i%2?95:135;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();ctx.fillStyle='#fff';ctx.font='700 44px Inter,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('✦',0,0);if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth;ctx.stroke()}}
else if(o.type==='line'){ctx.strokeStyle=paint;ctx.lineWidth=Math.max(2,o.h||8);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-(o.w||420)/2,0);ctx.lineTo((o.w||420)/2,0);ctx.stroke();if(o.elementType==='arrow'){ctx.beginPath();ctx.moveTo((o.w||420)/2-24,-18);ctx.lineTo((o.w||420)/2,0);ctx.lineTo((o.w||420)/2-24,18);ctx.stroke()}}
else if(o.type==='chart'){ctx.strokeStyle='#39455f';ctx.lineWidth=3;ctx.strokeRect(-(o.w||420)/2,-(o.h||260)/2,o.w||420,o.h||260);ctx.fillStyle=paint;[.35,.6,.48,.82,.55,.72].forEach((v,i)=>ctx.fillRect(-(o.w||420)/2+25+i*60,(o.h||260)/2-20-v*((o.h||260)-45),42,v*((o.h||260)-45)))}
else if(o.type==='image'&&o.img){ctx.drawImage(o.img,-(o.w||300)/2,-(o.h||300)/2,o.w||300,o.h||300);if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth;ctx.strokeRect(-(o.w||300)/2,-(o.h||300)/2,o.w||300,o.h||300)}}
else if(o.type==='draw'&&o.points?.length){ctx.strokeStyle=paint;ctx.lineWidth=o.size||8;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();o.points.forEach((p,i)=>i?ctx.lineTo(p.x-o.x,p.y-o.y):ctx.moveTo(p.x-o.x,p.y-o.y));ctx.stroke()}ctx.restore()}
/* Make studioPaint gradient-aware and keep solid colors working. */
function studioPaint(ctx,o){if(o.gradient){const w=o.w||o.r*2||400,h=o.h||o.r*2||160,a=(o.gradient.angle||0)*Math.PI/180,dx=Math.cos(a)*w,dy=Math.sin(a)*h,g=ctx.createLinearGradient(-dx/2,-dy/2,dx/2,dy/2);g.addColorStop(0,o.gradient.c1);g.addColorStop(1,o.gradient.c2);return g}return o.color||o.fill||'#8b7cff'}
/* Layer list: eye + lock + delete, with hidden layers dimmed. */
function studioUpdateLayers(){const el=document.getElementById('studioLayers');if(!el)return;if(!studio.layers.length){el.innerHTML='<div class="studioEmpty">No layers yet. Add text, image, shape or element.</div>';const c=document.getElementById('studioLayerCount');if(c)c.textContent='0 layers';return}el.innerHTML=studio.layers.slice().reverse().map(o=>`<div class="layerRow ${o.id===studio.selected?'selected':''} ${o.locked?'locked':''} ${o.hidden?'hiddenLayer':''}" onclick="studioSelect('${o.id}')"><div class="layerThumb">${o.type==='image'&&o.img?`<img src="${o.img.src}">`:o.type==='text'?'T':o.type==='circle'?'●':'▰'}</div><div class="layerMeta"><b>${esc(o.name||o.text||o.type.toUpperCase())}</b><span>${o.hidden?'hidden • ':''}${o.locked?'locked • ':''}${o.type} • ${Math.round((o.opacity??1)*100)}%</span></div><button class="layerLock" title="Hide/Show" onclick="event.stopPropagation();studioToggleHidden('${o.id}')">${o.hidden?'🚫':'👁'}</button><button class="layerLock" title="Lock/Unlock" onclick="event.stopPropagation();studioToggleLock('${o.id}')">${o.locked?'🔒':'🔓'}</button><button class="layerDelete" onclick="event.stopPropagation();studioDelete('${o.id}')">🗑</button></div>`).join('');const c=document.getElementById('studioLayerCount');if(c)c.textContent=studio.layers.length+' layer'+(studio.layers.length>1?'s':'')}
/* Extend layer creation defaults so every new object immediately supports effects. */
function v9Defaults(o){o.opacity??=1;o.rotation??=0;o.strokeWidth??=0;o.strokeEnabled??=false;o.strokeColor??='#ffffff';o.shadowEnabled??=false;o.blur??=0;o.blend??='source-over';o.radius??=0;o.hidden??=false;o.locked??=false;return o}
const _push=studio.layers.push.bind(studio.layers);studio.layers.push=function(...args){args.forEach(v9Defaults);return Array.prototype.push.apply(this,args)};
/* Preserve current render but guarantee layer/property sync and zoom. */
const v9BaseRender=studioRender;studioRender=function(){v9BaseRender();studio.layers.forEach(v9Defaults);studioUpdateLayers();studioUpdateProps()};


/* ===== V11: Properties live bottom dock, canvas stays visible ===== */
(function(){
  const iconMap={fill:'◉',stroke:'◒',effects:'✦',opacity:'◐',rotate:'↻',mask:'⬡',transform:'□',text:'A',image:'▧',arrange:'⇅'};
  function propSectionFor(kind, body){
    const sections=[...body.querySelectorAll(':scope > .studioPropsSection')];
    if(kind==='fill') return sections.find(x=>(x.textContent||'').includes('FILL & GRADIENT') || x.id==='v10GradientInline');
    if(kind==='stroke') return sections.find(x=>(x.textContent||'').includes('STROKE / OUTLINE'));
    if(kind==='effects') return sections.find(x=>(x.textContent||'').includes('EFFECTS'));
    if(kind==='text') return sections.find(x=>(x.textContent||'').includes('TEXT'));
    if(kind==='transform') return sections.find(x=>(x.textContent||'').includes('TRANSFORM')) || sections[0];
    if(kind==='image') return sections.find(x=>(x.textContent||'').includes('IMAGE'));
    return sections[0];
  }
  window.v11BuildProperties=function(){
    const src=document.getElementById('studioProps');
    const body=document.getElementById('studioMobileDrawerBody');
    if(!src||!body)return;
    const o=studioSelected();
    if(!o){body.innerHTML='<div class="mobilePropEmpty">Select an object on the canvas to edit it live.</div>';return;}
    const clone=src.cloneNode(true); clone.removeAttribute('id');
    body.innerHTML='';
    const nav=document.createElement('div');nav.className='mobilePropNav';
    const kinds=[['fill','Fill'],['stroke','Stroke'],['effects','Effects'],['opacity','Opacity'],['rotate','Rotate'],['mask','Mask'],['transform','Size'],...(o.type==='text'?[['text','Text']]:[]),...(o.type==='image'?[['image','Image']]:[]),['arrange','Arrange']];
    kinds.forEach(([k,label],i)=>{const b=document.createElement('button');b.innerHTML=`<span>${iconMap[k]}</span>${label}`;b.onclick=()=>{nav.querySelectorAll('button').forEach(x=>x.classList.remove('active'));b.classList.add('active');const s=propSectionFor(k,clone);if(s)s.scrollIntoView({behavior:'smooth',block:'nearest'});};if(i===0)b.classList.add('active');nav.appendChild(b)});
    body.appendChild(nav);
    const quick=document.createElement('div');quick.className='mobilePropTools';
    [['✎','Edit','studioTextEditor'],['🎨','Color','studioOpenGradientMixer'],['↔','Align','studioAlign'],['⧉','Duplicate','studioDuplicate'],['🔒','Lock','studioToggleLock'],['🗑','Remove','studioDeleteSelected']].forEach(([ic,lab,fn])=>{const b=document.createElement('button');b.textContent=ic+'  '+lab;b.onclick=()=>{if(fn==='studioAlign')studioAlign('center');else if(fn==='studioToggleLock'){studioToggleLock(o.id)}else window[fn]?.();};quick.appendChild(b)});
    body.appendChild(quick);
    const content=document.createElement('div');content.className='mobilePropContent';content.appendChild(clone);body.appendChild(content);
  };
  const oldPanel=window.studioMobilePanel;
  window.studioMobilePanel=function(which){
    if(which!=='properties'){oldPanel(which);return;}
    const d=document.getElementById('studioMobileDrawer');
    if(!d)return;
    document.querySelectorAll('.studioMobileBar button').forEach(b=>b.classList.remove('active'));
    [...document.querySelectorAll('.studioMobileBar button')][2]?.classList.add('active');
    document.getElementById('studioMobileDrawerTitle').textContent='PROPERTIES • LIVE EDIT';
    v11BuildProperties();
    d.classList.add('open');
    document.querySelector('.studioCanvasStage')?.classList.add('drawerOpen');
  };
  const oldClose=window.studioCloseMobileDrawer;
  window.studioCloseMobileDrawer=function(){oldClose?.();document.querySelector('.studioCanvasStage')?.classList.remove('drawerOpen')};
  const oldRender=window.studioRender;
  window.studioRender=function(){oldRender();const d=document.getElementById('studioMobileDrawer');if(d?.classList.contains('open')&&document.getElementById('studioMobileDrawerTitle')?.textContent.startsWith('PROPERTIES')){setTimeout(v11BuildProperties,0)}};
})();


/* ===== V10 LIVE EDITING / PROPERTY FOCUS FIX ===== */
(function(){
  const numericKeys=new Set(['x','y','w','h','r','size','rotation','opacity','weight','letterSpacing','strokeWidth','blur','radius']);
  const oldSet=window.studioSet;
  window.studioSet=function(k,v){const o=studioSelected();if(!o||o.locked)return;if(numericKeys.has(k)){const n=parseFloat(v);o[k]=Number.isFinite(n)?n:0}else{o[k]=v}v10Commit(true)};
  let histTimer=null;
  window.v10Commit=function(deferHistory){
    clearTimeout(histTimer);
    if(deferHistory)histTimer=setTimeout(()=>{try{studioSaveHistory()}catch(e){}},350);else{try{studioSaveHistory()}catch(e){}}
    studioRender();
  };
  const baseRender=window.studioRender;
  window.studioRender=function(){
    const props=document.getElementById('studioProps');
    const ae=document.activeElement;
    const keepProps=!!(props&&ae&&props.contains(ae));
    const realUpdate=window.studioUpdateProps;
    const realMobile=window.studioMobilePanel;
    if(keepProps)window.studioUpdateProps=function(){};
    baseRender();
    window.studioUpdateProps=realUpdate;
    window.studioMobilePanel=realMobile;
    if(!keepProps){try{v10InstallGradientUI()}catch(e){}}
  };
  window.studioInlineColor=function(v){const o=studioSelected();if(!o||o.locked)return;o.color=v;o.fill=v;o.gradient=null;v10Commit(true)};
  window.studioInlineGradient=function(){
    const o=studioSelected();if(!o||o.locked)return;
    const c1=document.getElementById('v10c1')?.value || o.gradient?.c1 || o.color || '#8b7cff';
    const c2=document.getElementById('v10c2')?.value || o.gradient?.c2 || '#39dfcf';
    const ang=parseFloat(document.getElementById('v10ang')?.value || o.gradient?.angle || 135);
    o.gradient={c1,c2,angle:Number.isFinite(ang)?ang:135};o.color=c1;o.fill=c1;
    v10Commit(true);
    const p=document.getElementById('v10gradientPreview');if(p)p.style.background=`linear-gradient(${ang}deg,${c1},${c2})`;
    const av=document.getElementById('v10angVal');if(av)av.textContent=ang+'°';
  };
  window.studioClearGradient=function(){const o=studioSelected();if(!o||o.locked)return;o.gradient=null;v10Commit(false)};
  window.studioSetStrokeColor=function(v){const o=studioSelected();if(!o||o.locked)return;o.strokeColor=v;o.strokeEnabled=true;v10Commit(true)};
  window.studioSetStrokeWidth=function(v){const o=studioSelected();if(!o||o.locked)return;o.strokeWidth=Math.max(0,parseFloat(v)||0);o.strokeEnabled=o.strokeWidth>0;v10Commit(true)};
  window.studioSetStrokeEnabled=function(v){const o=studioSelected();if(!o||o.locked)return;o.strokeEnabled=!!v;v10Commit(false)};
  window.studioSetTextBg=function(v){const o=studioSelected();if(!o||o.locked)return;o.textBg=v;o.textBgEnabled=true;v10Commit(true)};
  window.studioSetTextBgEnabled=function(v){const o=studioSelected();if(!o||o.locked)return;o.textBgEnabled=!!v;v10Commit(false)};
  window.studioSetShadow=function(v){const o=studioSelected();if(!o||o.locked)return;o.shadowEnabled=!!v;v10Commit(false)};
  window.studioSetBlur=function(v){const o=studioSelected();if(!o||o.locked)return;o.blur=Math.max(0,parseFloat(v)||0);v10Commit(true)};
  window.studioSetRadius=function(v){const o=studioSelected();if(!o||o.locked)return;o.radius=Math.max(0,parseFloat(v)||0);v10Commit(true)};
  window.studioSetBlend=function(v){const o=studioSelected();if(!o||o.locked)return;o.blend=v;v10Commit(false)};
  window.studioSetTextAlign=function(v){const o=studioSelected();if(!o||o.locked)return;o.textAlign=v;v10Commit(false)};
  window.studioSetFontStyle=function(v){const o=studioSelected();if(!o||o.locked)return;o.fontStyle=v;v10Commit(false)};
  window.studioOpenGradientMixer=function(){
    const box=document.getElementById('v10GradientInline');
    if(box){box.scrollIntoView({behavior:'smooth',block:'center'});box.classList.add('pulse');setTimeout(()=>box.classList.remove('pulse'),700);return;}
    v10InstallGradientUI();setTimeout(()=>document.getElementById('v10GradientInline')?.scrollIntoView({behavior:'smooth',block:'center'}),30);
  };
  window.v10InstallGradientUI=function(){
    const el=document.getElementById('studioProps'),o=studioSelected();if(!el||!o)return;
    let box=document.getElementById('v10GradientInline');
    const g=o.gradient||{c1:o.color||'#8b7cff',c2:'#39dfcf',angle:135};
    if(!box){
      box=document.createElement('div');box.id='v10GradientInline';box.className='studioPropsSection v10GradientBox';
      el.prepend(box);
    }
    box.innerHTML=`<h4>🌈 LIVE GRADIENT MIXER</h4><div class="v10ColorPair"><label>COLOR 1<input id="v10c1" type="color" value="${g.c1}" oninput="studioInlineGradient()"></label><label>COLOR 2<input id="v10c2" type="color" value="${g.c2}" oninput="studioInlineGradient()"></label></div><div id="v10gradientPreview" class="v10GradientPreview" style="background:linear-gradient(${g.angle}deg,${g.c1},${g.c2})"></div><div class="prop" style="margin-top:8px"><label>ANGLE <span id="v10angVal">${g.angle}°</span></label><input id="v10ang" type="range" min="0" max="360" value="${g.angle}" oninput="studioInlineGradient()"></div><div class="v10MixLabel">LIVE PREVIEW • changes appear on canvas instantly</div><div class="v10Recent" id="v10Recent"></div>`;
    const recent=(studio.gradients||[]).slice(0,10);const rec=document.getElementById('v10Recent');
    if(rec)rec.innerHTML=recent.map((x,i)=>`<button title="${x.c1} → ${x.c2}" style="background:linear-gradient(${x.angle}deg,${x.c1},${x.c2})" onclick="studioApplyGradientPreset('${x.key}');v10InstallGradientUI()"></button>`).join('');
  };
  const oldUpdate=window.studioUpdateProps;
  window.studioUpdateProps=function(){oldUpdate();try{v10InstallGradientUI()}catch(e){}};
  /* Avoid opening a blocking modal: the canvas remains visible while properties are edited. */
  const oldMobile=window.studioMobilePanel;
  window.studioMobilePanel=function(which){oldMobile(which);if(which==='properties'){setTimeout(()=>v10InstallGradientUI(),0)}};
})();


/* =========================================================
   V12 STABLE ARTBOARD ENGINE
   Page resizing changes the artboard, not the editor layout.
   Existing objects are transformed proportionally around center.
   ========================================================= */
(function(){
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function scalePoint(p,sx,sy,oldW,oldH,newW,newH){
    const cx=oldW/2,cy=oldH/2,ncx=newW/2,ncy=newH/2;
    return {x:ncx+(p.x-cx)*sx,y:ncy+(p.y-cy)*sy};
  }
  function transformObject(o,oldW,oldH,newW,newH){
    const sx=newW/oldW, sy=newH/oldH;
    /* Uniform scale prevents portrait/landscape distortion. */
    const s=Math.min(sx,sy);
    const p=scalePoint({x:o.x,y:o.y},s,s,oldW,oldH,newW,newH);
    o.x=p.x;o.y=p.y;
    ['w','h','r','size','strokeWidth','textBgPadding','radius','blur','shadowBlur','shadowX','shadowY'].forEach(k=>{
      if(typeof o[k]==='number')o[k]*=s;
    });
    if(Array.isArray(o.points)){
      const cx=oldW/2,cy=oldH/2,ncx=newW/2,ncy=newH/2;
      o.points=o.points.map(pt=>({x:ncx+(pt.x-cx)*s,y:ncy+(pt.y-cy)*s}));
    }
    o.x=clamp(o.x,0,newW);o.y=clamp(o.y,0,newH);
  }
  function fitArtboard(){
    const stage=document.querySelector('.studioCanvasStage'), frame=document.getElementById('canvasFrame'), canvas=studio?.canvas;
    if(!stage||!frame||!canvas)return;
    const sw=Math.max(120,stage.clientWidth-20), sh=Math.max(120,stage.clientHeight-20);
    const ratio=canvas.width/canvas.height;
    let w=sw,h=w/ratio;
    if(h>sh){h=sh;w=h*ratio;}
    /* CSS size only; logical canvas pixels remain untouched. */
    frame.style.width=Math.round(w)+'px';
    frame.style.height=Math.round(h)+'px';
    canvas.style.width=Math.round(w)+'px';
    canvas.style.height=Math.round(h)+'px';
  }
  window.studioFitArtboard=fitArtboard;

  const originalSetPage=window.studioSetPage;
  window.studioSetPage=function(w,h,name){
    w=clamp(Math.round(Number(w)||1080),100,5000);
    h=clamp(Math.round(Number(h)||1080),100,5000);
    const oldW=studioPage.width,oldH=studioPage.height;
    if(oldW!==w||oldH!==h){
      studioSaveHistory();
      studio.layers.forEach(o=>transformObject(o,oldW,oldH,w,h));
    }
    studioPage={width:w,height:h,name:name||'Custom Design'};
    studio.canvas.width=w;studio.canvas.height=h;
    studioRender();
    requestAnimationFrame(fitArtboard);
    if(typeof studioCloseModal==='function')studioCloseModal();
    studioToast(`${studioPage.name} • ${w} × ${h} • Layout preserved`);
  };

  const originalFit=window.studioFit;
  window.studioFit=function(){
    try{originalFit?.()}catch(e){}
    requestAnimationFrame(fitArtboard);
  };

  const originalZoom=window.studioZoom;
  window.studioZoom=function(f){
    try{originalZoom?.(f)}catch(e){}
    requestAnimationFrame(()=>{
      const frame=document.getElementById('canvasFrame');
      if(frame){frame.style.transformOrigin='center center';}
      fitArtboard();
    });
  };

  /* Re-fit after the editor becomes visible, rotation, resize or drawer changes. */
  const ro=new ResizeObserver(()=>fitArtboard());
  window.addEventListener('load',()=>{const s=document.querySelector('.studioCanvasStage');if(s)ro.observe(s);setTimeout(fitArtboard,80);});
  window.addEventListener('resize',()=>requestAnimationFrame(fitArtboard));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestAnimationFrame(fitArtboard)});

  /* Make the V11 properties dock truly live without rebuilding inputs on every keystroke. */
  window.v12LiveValue=function(el,key){
    const o=studioSelected();if(!o||o.locked)return;
    let v=el.type==='number'||el.type==='range'?parseFloat(el.value):el.value;
    if(!Number.isFinite(v)&&typeof v==='number')return;
    o[key]=v;
    if(key==='opacity')o.opacity=clamp(v,0,1);
    studioRender();
  };

  /* Ensure selected layer remains visible after opening properties. */
  const oldMobile=window.studioMobilePanel;
  window.studioMobilePanel=function(which){
    oldMobile?.(which);
    requestAnimationFrame(()=>{fitArtboard();
      if(which==='properties')document.querySelector('.studioCanvasStage')?.classList.add('drawerOpen');
    });
  };

  /* Page-size modal gets a live aspect preview. */
  const oldPageSettings=window.studioPageSettings;
  window.studioPageSettings=function(){
    oldPageSettings?.();
    setTimeout(()=>{
      const card=document.querySelector('.pageSizeGrid');
      if(card&&!card.querySelector('.v12PageNote')){
        const n=document.createElement('div');n.className='v12PageNote';
        n.style='grid-column:1/-1;padding:8px 10px;border:1px solid #29344c;border-radius:10px;background:#0c1220;color:#7f8ba4;font-size:8px;line-height:1.5';
        n.innerHTML='✓ Your existing layers will be proportionally preserved when page size changes.';
        card.prepend(n);
      }
    },30);
  };

  /* Keep canvas fitted after every render, but never touch logical dimensions. */
  const baseRender=window.studioRender;
  window.studioRender=function(){
    baseRender?.();
    requestAnimationFrame(fitArtboard);
  };
})();


(function(){
  function escPL(s){return String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}
  function ensurePL(){
    const app=document.getElementById('legacyStudioApp'); if(!app||document.getElementById('pixelLabBottomDock')) return;
    const dock=document.createElement('div'); dock.id='pixelLabBottomDock';
    dock.innerHTML=`
      <div id="pixelLabActions"></div>
      <div id="pixelLabPropertyBody"></div>
      <div id="pixelLabTabs">
        <button class="active" data-tab="create"><span class="pli">✦</span><span>create</span></button>
        <button data-tab="text"><span class="pli">A</span><span>text</span></button>
        <button data-tab="style"><span class="pli">◉</span><span>style</span></button>
        <button data-tab="image"><span class="pli">▣</span><span>image</span></button>
        <button data-tab="effects"><span class="pli">✧</span><span>effects</span></button>
      </div>`;
    app.appendChild(dock);
    const tabs=[...dock.querySelectorAll('#pixelLabTabs button')];
    tabs.forEach(b=>b.addEventListener('click',()=>{tabs.forEach(x=>x.classList.remove('active'));b.classList.add('active');plBuild(b.dataset.tab)}));
    plBuild('create');
  }
  function action(label,icon,fn){return `<button onclick="${fn}"><span class="pli">${icon}</span><span>${label}</span></button>`}
  function plBuild(tab){
    ensurePL(); const actions=document.getElementById('pixelLabActions'), body=document.getElementById('pixelLabPropertyBody'); if(!actions||!body)return;
    const o=window.studioSelected?studioSelected():null;
    if(tab==='create'){
      actions.innerHTML=''; body.innerHTML=`<div id="pixelLabCreateBody">
        <button onclick="studioAddText()"><b>T</b>Text</button><button onclick="studioOpenImage()"><b>▣</b>Image</button><button onclick="studioElements()"><b>✦</b>Elements</button><button onclick="studioAddShape('rect')"><b>▰</b>Shape</button><button onclick="studioTool('draw')"><b>✎</b>Draw</button><button onclick="studioPageSettings()"><b>▤</b>Page</button><button onclick="studioTemplates()"><b>▦</b>Templates</button><button onclick="studioBackground()"><b>◉</b>Background</button></div>`;
    } else if(tab==='text'){
      actions.innerHTML=action('Edit Text','A',"studioTextEditor(studio.selected,true)")+action('Fonts','Aa','studioFonts()')+action('Color','●',"studioOpenFill('selected')")+action('Stroke','◌',"studioOpenFill('selected')");
      body.innerHTML=o&&o.type==='text'?document.getElementById('studioProps')?.innerHTML||'':'<div class="studioEmpty">Select a text layer to edit.</div>';
    } else if(tab==='style'){
      actions.innerHTML=action('Color','◉',"studioOpenFill('selected')")+action('Gradient','◒',"studioOpenGradientMixer()")+action('Stroke','○',"studioOpenFill('selected')")+action('Opacity','◐',"document.querySelector('#studioProps input[type=range]')?.focus()")+action('Shadow','◉',"studioOpenAllTools()")+action('Position','↔',"studioOpenAllTools()");
      body.innerHTML=o?document.getElementById('studioProps')?.innerHTML||'':'<div class="studioEmpty">Select an object to edit.</div>';
    } else if(tab==='image'){
      actions.innerHTML=action('Add Image','▣','studioOpenImage()')+action('Crop','✂','studioCropImage()')+action('Filter','◐',"studioFilter('normal')")+action('Bright','☼',"studioFilter('bright')")+action('Contrast','◑',"studioFilter('contrast')")+action('Vivid','✦',"studioFilter('vivid')");
      body.innerHTML=o?document.getElementById('studioProps')?.innerHTML||'':'<div class="studioEmpty">Select an image to edit.</div>';
    } else {
      actions.innerHTML=action('Noise','▧',"studioFilter('soft')")+action('Mono','◐',"studioFilter('gray')")+action('Bright','☼',"studioFilter('bright')")+action('Contrast','◑',"studioFilter('contrast')")+action('Vivid','✦',"studioFilter('vivid')")+action('Soft','◒',"studioFilter('soft')");
      body.innerHTML=o?document.getElementById('studioProps')?.innerHTML||'':'<div class="studioEmpty">Select an object first.</div>';
    }
  }
  window.plBuild=plBuild;
  const oldRender=window.studioRender;
  window.studioRender=function(){if(oldRender)oldRender(); if(window.innerWidth<=900&&document.getElementById('pixelLabBottomDock')){const active=document.querySelector('#pixelLabTabs button.active');plBuild(active?.dataset.tab||'create');}};
  const oldPanel=window.studioMobilePanel;
  window.studioMobilePanel=function(which){
    ensurePL();
    const tabs=[...document.querySelectorAll('#pixelLabTabs button')];
    if(which==='layers'){
      const body=document.getElementById('pixelLabPropertyBody'); const actions=document.getElementById('pixelLabActions');
      document.getElementById('pixelLabTabs').querySelectorAll('button').forEach(x=>x.classList.remove('active'));
      actions.innerHTML=action('Delete','▣','studioDeleteSelected()')+action('Copy','□','studioDuplicate()')+action('Front','↑','studioBring(\'front\')')+action('Back','↓','studioBring(\'back\')')+action('Lock','⌑','studioToggleLock(studio.selected)');
      body.innerHTML=`<div id="pixelLabLayerBody">${document.getElementById('studioLayers')?.innerHTML||'<div class="studioEmpty">No layers</div>'}</div>`;
    } else { tabs.forEach(x=>x.classList.toggle('active',x.dataset.tab===which)); plBuild(which); }
  };
  const obs=new MutationObserver(()=>{if(window.innerWidth<=900&&document.getElementById('pixelLabBottomDock')){const a=document.querySelector('#pixelLabTabs button.active');if(a?.dataset.tab!=='create')plBuild(a.dataset.tab);}});
  function start(){ensurePL();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
  window.addEventListener('resize',()=>{if(window.innerWidth<=900)ensurePL()});
})();


(function(){
  const W=()=>window.studioPage?.width||1080,H=()=>window.studioPage?.height||1080;
  const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now()+Math.random().toString(16).slice(2);
  function toast(m){window.studioToast?.(m)}
  function selected(){return window.studioSelected?studioSelected():null}
  function commit(){try{window.studioSaveHistory?.();}catch(e){};window.studioRender?.();}
  function ensure(o){if(!o)return;o.v14=true;o.depth??=0;o.depthAngle??=45;o.depthColor??='#111827';o.innerShadow??=false;o.reflection??=false;o.curve??=0;o.texture??='none';o.textureColor??='#ffffff';o.cornerRadius??=o.radius||0;o.brightness??=100;o.contrast??=100;o.saturation??=100;o.hue??=0;o.vignette??=0;o.noise??=0;o.mask??='none';o.cropX??=0;o.cropY??=0;o.cropScale??=1;o.skewX??=0;o.skewY??=0;o.perspective??=0}
  function all(){(studio.layers||[]).forEach(ensure)}

  window.pixelProText=function(){const o=selected();if(!o||o.type!=='text'){toast('Select a text layer first');return} pixelProModal('TEXT STUDIO',textPanel(o));}
  function textPanel(o){return `<div class="v14Panel"><div class="v14Two"><div class="v14Field"><label>3D DEPTH</label><input type="range" min="0" max="80" value="${o.depth||0}" oninput="pixelProSet('depth',this.value)"></div><div class="v14Field"><label>DEPTH ANGLE</label><input type="range" min="0" max="360" value="${o.depthAngle||45}" oninput="pixelProSet('depthAngle',this.value)"></div></div><div class="v14Two" style="margin-top:8px"><div class="v14Field"><label>DEPTH COLOR</label><input type="color" value="${o.depthColor||'#111827'}" oninput="pixelProSet('depthColor',this.value)"></div><div class="v14Field"><label>TEXTURE COLOR</label><input type="color" value="${o.textureColor||'#ffffff'}" oninput="pixelProSet('textureColor',this.value)"></div></div><div class="v14ChipRow" style="margin-top:10px"><button class="v14Chip" onclick="pixelProSet('texture','none')">Solid</button><button class="v14Chip" onclick="pixelProSet('texture','gold')">Gold</button><button class="v14Chip" onclick="pixelProSet('texture','metal')">Metal</button><button class="v14Chip" onclick="pixelProSet('texture','neon')">Neon</button><button class="v14Chip" onclick="pixelProSet('texture','chrome')">Chrome</button></div><div class="v14Two" style="margin-top:10px"><button class="studioBtn" onclick="pixelProSet('innerShadow',!${!!o.innerShadow})">${o.innerShadow?'✓ ':''}Inner Shadow</button><button class="studioBtn" onclick="pixelProSet('reflection',!${!!o.reflection})">${o.reflection?'✓ ':''}Reflection</button></div><div class="v14Field" style="margin-top:9px"><label>CURVE · ${o.curve||0}°</label><input class="v14Range" type="range" min="-180" max="180" value="${o.curve||0}" oninput="pixelProSet('curve',this.value)"></div><div class="v14Notice">Pixel-style text studio: depth, curved lettering, texture, reflection and inner-shadow effects are rendered locally on the canvas.</div></div>`}

  window.pixelProImage=function(){const o=selected();if(!o||o.type!=='image'){toast('Select an image first');return} pixelProModal('IMAGE LAB',imagePanel(o));}
  function imagePanel(o){return `<div class="v14Panel"><div class="v14Two"><div class="v14Field"><label>BRIGHTNESS · ${o.brightness||100}</label><input class="v14Range" type="range" min="0" max="200" value="${o.brightness||100}" oninput="pixelProSet('brightness',this.value)"></div><div class="v14Field"><label>CONTRAST · ${o.contrast||100}</label><input class="v14Range" type="range" min="0" max="200" value="${o.contrast||100}" oninput="pixelProSet('contrast',this.value)"></div><div class="v14Field"><label>SATURATION · ${o.saturation||100}</label><input class="v14Range" type="range" min="0" max="200" value="${o.saturation||100}" oninput="pixelProSet('saturation',this.value)"></div><div class="v14Field"><label>HUE · ${o.hue||0}°</label><input class="v14Range" type="range" min="-180" max="180" value="${o.hue||0}" oninput="pixelProSet('hue',this.value)"></div></div><div class="v14ChipRow" style="margin-top:10px"><button class="v14Chip" onclick="pixelProSet('filterPreset','normal')">Normal</button><button class="v14Chip" onclick="pixelProSet('filterPreset','mono')">Mono</button><button class="v14Chip" onclick="pixelProSet('filterPreset','warm')">Warm</button><button class="v14Chip" onclick="pixelProSet('filterPreset','cool')">Cool</button><button class="v14Chip" onclick="pixelProSet('filterPreset','vivid')">Vivid</button><button class="v14Chip" onclick="pixelProSet('filterPreset','soft')">Soft</button></div><div class="v14Two" style="margin-top:10px"><div class="v14Field"><label>BLUR</label><input class="v14Range" type="range" min="0" max="20" value="${o.blur||0}" oninput="pixelProSet('blur',this.value)"></div><div class="v14Field"><label>VIGNETTE</label><input class="v14Range" type="range" min="0" max="100" value="${o.vignette||0}" oninput="pixelProSet('vignette',this.value)"></div></div><div class="v14Notice">Photo adjustments are non-destructive layer properties and stay inside the project.</div></div>`}

  window.pixelProShape=function(){const a=[['▰','Rectangle','rect'],['●','Circle','circle'],['▲','Triangle','triangle'],['★','Star','star'],['➜','Arrow','arrow'],['◇','Diamond','diamond'],['⬢','Hexagon','hexagon'],['⬡','Octagon','octagon'],['━','Line','line'],['☁','Cloud','cloud'],['❤','Heart','heart'],['☀','Sun','sun'],['✦','Spark','spark'],['✿','Flower','flower'],['◈','Badge','badge'],['▣','Frame','frame']];const html=a.map(x=>'<button class="v14Asset" data-shape="'+x[2]+'" onclick="pixelProAddShape(this.dataset.shape)">'+x[0]+'<small>'+x[1]+'</small></button>').join('');pixelProModal('SHAPES & ELEMENTS','<div class="v14Panel"><div class="v14AssetGrid">'+html+'</div></div>')}
  window.pixelProAddShape=function(type){const map={triangle:'▲',star:'★',arrow:'➜',diamond:'◇',hexagon:'⬢',octagon:'⬡',cloud:'☁',heart:'♥',sun:'☀',spark:'✦',flower:'✿',badge:'✦',frame:'▣'};if(['rect','circle','line'].includes(type)){window.studioAddShape(type==='line'?'rect':type);const o=selected();if(type==='line'&&o){o.type='line';o.w=500;o.h=8;o.name='Line'}}else{const o={id:uid(),type:'shape',shape:type,glyph:map[type]||'✦',x:W()/2,y:H()/2,w:360,h:260,r:130,color:'#1687d9',opacity:1,rotation:0,name:type[0].toUpperCase()+type.slice(1)};studio.layers.push(o);studio.selected=o.id;ensure(o);commit()}toast(type+' added');}

  window.pixelProBackground=function(){pixelProModal('CANVAS BACKGROUND',`<div class="v14Panel"><div class="v14Two"><div class="v14Field"><label>COLOR 1</label><input id="v14bg1" type="color" value="${studio.bgGradient?.c1||studio.bg||'#ffffff'}"></div><div class="v14Field"><label>COLOR 2</label><input id="v14bg2" type="color" value="${studio.bgGradient?.c2||'#1687d9'}"></div></div><div class="v14Field" style="margin-top:9px"><label>ANGLE</label><input id="v14bga" class="v14Range" type="range" min="0" max="360" value="${studio.bgGradient?.angle||135}"></div><div class="v14Two" style="margin-top:10px"><button class="studioBtn primary" onclick="pixelProApplyBg('linear')">Linear Gradient</button><button class="studioBtn" onclick="pixelProApplyBg('radial')">Radial Gradient</button></div><button class="studioBtn studioFullBtn" onclick="studio.bgGradient=null;studio.bg='#ffffff';studioRender();studioCloseModal()">White</button><div class="v14Notice">Background changes affect the page, not the editor workspace.</div></div>`)}
  window.pixelProApplyBg=function(type){studio.bgGradient={c1:document.getElementById('v14bg1').value,c2:document.getElementById('v14bg2').value,angle:+document.getElementById('v14bga').value,type};studioRender();studioCloseModal();toast('Background updated')}

  window.pixelProSet=function(k,v){const o=selected();if(!o||o.locked)return; if(['depth','depthAngle','curve','brightness','contrast','saturation','hue','blur','vignette','noise'].includes(k))v=parseFloat(v)||0;if(k==='filterPreset')o.filterPreset=v;else o[k]=v;ensure(o);studioRender();}
  window.pixelProModal=function(title,body){const m=document.getElementById('studioModal'),c=document.getElementById('studioModalCard');if(!m||!c)return;c.innerHTML=`<div class="modalHeader"><div><span class="eyebrow">PIXEL EDITOR PRO</span><h2 style="margin:5px 0 0">${title}</h2></div><button class="iconBtn" onclick="studioCloseModal()">×</button></div>${body}`;m.classList.add('open')}

  window.pixelProMore=function(){pixelProModal('FULL PIXEL TOOLKIT',`<div class="v14FeatureGrid"><button onclick="pixelProText()">🔤 Text Studio</button><button onclick="pixelProImage()">🖼 Image Lab</button><button onclick="pixelProShape()">◇ Shapes</button><button onclick="pixelProBackground()">🎨 Background</button><button onclick="studioCropImage();studioCloseModal()">✂ Crop</button><button onclick="studioOpenGradientMixer();studioCloseModal()">🌈 Gradient</button><button onclick="studioDuplicate();studioCloseModal()">⧉ Duplicate</button><button onclick="studioGroupSelected();studioCloseModal()">☷ Group</button><button onclick="studioFlip('x');studioCloseModal()">↔ Flip</button><button onclick="studioAlign('center');studioCloseModal()">◎ Center</button><button onclick="pixelProSaveProject()">💾 Save Project</button><button onclick="pixelProLoadProject()">📂 Load Project</button><button onclick="studioExport('png');studioCloseModal()">PNG Export</button><button onclick="studioExport('jpg');studioCloseModal()">JPG Export</button><button onclick="studioUndo();studioCloseModal()">↶ Undo</button><button onclick="studioRedo();studioCloseModal()">↷ Redo</button></div><div class="v14Notice">Original implementation: inspired by common mobile photo/text editor workflows. No proprietary PixelLab source or assets are copied.</div>`)}

  window.pixelProSaveProject=function(){try{const layers=studio.layers.map(o=>{const x={...o};if(x.img&&x.img.src&&x.img.src.startsWith('blob:')){try{x.imageData=studio.canvas.toDataURL()}catch(e){}}delete x.img;delete x.points;return x});const data=JSON.stringify({page:studioPage,bg:studio.bg,bgGradient:studio.bgGradient||null,layers,at:new Date().toISOString()});window.__mloPixelProjectCache=data;if(typeof window.mloIDBSetPixelProject==='function')window.mloIDBSetPixelProject(data);toast('Project saved on this device ✓')}catch(e){toast('Could not save project')}}
  window.pixelProLoadProject=function(){try{const raw=window.__mloPixelProjectCache;if(!raw)throw Error('none');const d=typeof raw==='string'?JSON.parse(raw):raw;studioPage=d.page||studioPage;studio.bg=d.bg||'#fff';studio.bgGradient=d.bgGradient||null;studio.canvas.width=studioPage.width;studio.canvas.height=studioPage.height;studio.layers=(d.layers||[]).map(o=>{ensure(o);return o});studio.selected=studio.layers[studio.layers.length-1]?.id||null;studioRender();studioCloseModal();toast('Project loaded ✓')}catch(e){toast('No saved Pixel project found')}}

  // Advanced renderer: adds text depth/curve/reflection/texture, shapes and photo adjustments.
  function paint(ctx,o){
    if(o.texture==='gold'){const g=ctx.createLinearGradient(-200,-80,200,80);g.addColorStop(0,'#7a4b00');g.addColorStop(.25,'#ffd86a');g.addColorStop(.5,'#fff2a8');g.addColorStop(.75,'#d39b25');g.addColorStop(1,'#7a4b00');return g}
    if(o.texture==='metal'){const g=ctx.createLinearGradient(0,-100,0,100);g.addColorStop(0,'#ffffff');g.addColorStop(.35,'#8b96a5');g.addColorStop(.5,'#f4f7fb');g.addColorStop(.7,'#6d7786');g.addColorStop(1,'#fff');return g}
    if(o.texture==='chrome'){const g=ctx.createLinearGradient(0,-100,0,100);g.addColorStop(0,'#111');g.addColorStop(.2,'#fff');g.addColorStop(.4,'#5e6670');g.addColorStop(.6,'#fff');g.addColorStop(.8,'#222');g.addColorStop(1,'#eee');return g}
    if(o.texture==='neon'){const g=ctx.createLinearGradient(-100,0,100,0);g.addColorStop(0,'#00e5ff');g.addColorStop(.5,'#8b5cff');g.addColorStop(1,'#ff3bd4');return g}
    if(o.gradient){const w=o.w||o.r*2||400,h=o.h||o.r*2||160,a=(o.gradient.angle||0)*Math.PI/180,dx=Math.cos(a)*w,dy=Math.sin(a)*h,g=ctx.createLinearGradient(-dx/2,-dy/2,dx/2,dy/2);g.addColorStop(0,o.gradient.c1);g.addColorStop(1,o.gradient.c2);return g}
    return o.color||o.fill||'#1687d9';
  }
  function drawText(ctx,o){const size=o.size||72,lines=String(o.text||'Text').split('\n'),lineH=size*1.12;ctx.font=`${o.fontStyle||'normal'} ${o.weight||700} ${size}px '${o.font||'Arial'}',sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';
    if(o.curve){const text=String(o.text||'Text').replace(/\n/g,' '),radius=Math.max(120,size*2),ang=(o.curve*Math.PI/180);let start=-ang/2;const chars=[...text];let widths=chars.map(ch=>ctx.measureText(ch).width),total=widths.reduce((a,b)=>a+b,0);let arc=ang||.01;let cur=start-(total/radius)/2;chars.forEach((ch,i)=>{let a=cur+(widths[i]/radius)/2;ctx.save();ctx.rotate(a);ctx.translate(0,-radius);if(o.depth)depthText(ctx,ch,o,-o.depth*.55);ctx.fillStyle=paint(ctx,o);if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#000';ctx.lineWidth=o.strokeWidth;ctx.strokeText(ch,0,0)}ctx.fillText(ch,0,0);ctx.restore();cur+=widths[i]/radius});return}
    const draw=(line,yy)=>{if(o.depth)depthText(ctx,line,o,0);if(o.strokeEnabled&&o.strokeWidth>0){ctx.strokeStyle=o.strokeColor||'#000';ctx.lineWidth=o.strokeWidth;ctx.strokeText(line,0,yy)}ctx.fillStyle=paint(ctx,o);ctx.fillText(line,0,yy)};
    let maxW=0;lines.forEach(l=>maxW=Math.max(maxW,ctx.measureText(l).width));
    if(o.textBgEnabled){const pad=o.textBgPadding||22;ctx.fillStyle=o.textBg||'#fff';ctx.fillRect(-maxW/2-pad,-(lines.length*lineH)/2-pad,maxW+pad*2,lines.length*lineH+pad*2)}
    lines.forEach((line,i)=>draw(line,(i-(lines.length-1)/2)*lineH));
    if(o.reflection){ctx.save();ctx.globalAlpha=.18;ctx.scale(1,-1);ctx.translate(0,lines.length*lineH+8);lines.forEach((line,i)=>{ctx.fillStyle=paint(ctx,o);ctx.fillText(line,0,(i-(lines.length-1)/2)*lineH)});const rg=ctx.createLinearGradient(0,0,0,size*1.7);rg.addColorStop(0,'rgba(255,255,255,0)');rg.addColorStop(1,'rgba(0,0,0,1)');ctx.fillStyle=rg;ctx.fillRect(-maxW,-size,maxW*2,size*2);ctx.restore()}
  }
  function depthText(ctx,text,o,yy){const dep=Math.max(0,o.depth||0),a=(o.depthAngle||45)*Math.PI/180,dx=Math.cos(a)*2,dy=Math.sin(a)*2;for(let i=dep;i>0;i-=2){ctx.fillStyle=o.depthColor||'#111827';ctx.fillText(text,dx*i,yy+dy*i)}if(o.innerShadow){ctx.shadowColor='rgba(0,0,0,.45)';ctx.shadowBlur=8;ctx.shadowOffsetX=3;ctx.shadowOffsetY=3}}
  function shape(ctx,o){const w=o.w||360,h=o.h||260,r=o.r||130;ctx.fillStyle=paint(ctx,o);ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth||0;ctx.beginPath();switch(o.shape){case'triangle':ctx.moveTo(0,-h/2);ctx.lineTo(w/2,h/2);ctx.lineTo(-w/2,h/2);break;case'diamond':ctx.moveTo(0,-h/2);ctx.lineTo(w/2,0);ctx.lineTo(0,h/2);ctx.lineTo(-w/2,0);break;case'hexagon':for(let i=0;i<6;i++)ctx.lineTo(Math.cos(Math.PI/3*i)*w/2,Math.sin(Math.PI/3*i)*h/2);break;case'octagon':for(let i=0;i<8;i++)ctx.lineTo(Math.cos(Math.PI/4*i)*w/2,Math.sin(Math.PI/4*i)*h/2);break;case'star':for(let i=0;i<10;i++){const rr=i%2?h/2:h/4;ctx.lineTo(Math.cos(-Math.PI/2+i*Math.PI/5)*rr*1.5,Math.sin(-Math.PI/2+i*Math.PI/5)*rr)}break;case'heart':ctx.moveTo(0,h/3);ctx.bezierCurveTo(-w*.65,-h*.05,-w*.35,-h*.55,0,-h*.15);ctx.bezierCurveTo(w*.35,-h*.55,w*.65,-h*.05,0,h/3);break;case'arrow':ctx.moveTo(-w/2,-h*.22);ctx.lineTo(w*.15,-h*.22);ctx.lineTo(w*.15,-h*.5);ctx.lineTo(w/2,0);ctx.lineTo(w*.15,h*.5);ctx.lineTo(w*.15,h*.22);ctx.lineTo(-w/2,h*.22);break;default:ctx.roundRect(-w/2,-h/2,w,h,o.radius||0)}ctx.closePath();ctx.fill();if(o.strokeWidth){ctx.stroke()}}
  function filterFor(o){const p=o.filterPreset||'normal';let s=`brightness(${(o.brightness||100)/100}) contrast(${(o.contrast||100)/100}) saturate(${(o.saturation||100)/100}) hue-rotate(${o.hue||0}deg)`;if(p==='mono')s+=' grayscale(1)';if(p==='warm')s+=' sepia(.25) saturate(1.25)';if(p==='cool')s+=' hue-rotate(25deg)';if(p==='vivid')s+=' saturate(1.55) contrast(1.12)';if(p==='soft')s+=' blur(.4px) brightness(1.04)';if(o.blur)s+=` blur(${o.blur}px)`;return s}
  function drawV14(ctx,o){ensure(o);if(o.hidden)return;ctx.save();ctx.globalAlpha=o.opacity??1;ctx.globalCompositeOperation=o.blend||'source-over';ctx.filter=o.type==='image'?filterFor(o):`blur(${o.blur||0}px)`;ctx.translate(o.x,o.y);ctx.rotate((o.rotation||0)*Math.PI/180);ctx.transform(1,Math.tan((o.skewY||0)*Math.PI/180),Math.tan((o.skewX||0)*Math.PI/180),1,0,0);ctx.scale(o.flipX?-1:1,o.flipY?-1:1);if(o.shadowEnabled){ctx.shadowColor='rgba(0,0,0,.45)';ctx.shadowBlur=28;ctx.shadowOffsetX=10;ctx.shadowOffsetY=14}
    if(o.type==='text')drawText(ctx,o);else if(o.type==='shape')shape(ctx,o);else if(o.type==='rect'){const w=o.w||300,h=o.h||200,r=Math.min(o.radius||0,Math.min(w,h)/2);ctx.fillStyle=paint(ctx,o);if(r){ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,r);ctx.fill()}else ctx.fillRect(-w/2,-h/2,w,h);if(o.strokeEnabled&&o.strokeWidth){ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth;ctx.strokeRect(-w/2,-h/2,w,h)}}else if(o.type==='circle'){ctx.fillStyle=paint(ctx,o);ctx.beginPath();ctx.arc(0,0,o.r||130,0,Math.PI*2);ctx.fill();if(o.strokeEnabled&&o.strokeWidth){ctx.strokeStyle=o.strokeColor||'#fff';ctx.lineWidth=o.strokeWidth;ctx.stroke()}}else if(o.type==='line'){ctx.strokeStyle=paint(ctx,o);ctx.lineWidth=Math.max(2,o.h||8);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-(o.w||420)/2,0);ctx.lineTo((o.w||420)/2,0);ctx.stroke()}else if(o.type==='image'&&o.img){ctx.drawImage(o.img,-(o.w||300)/2,-(o.h||300)/2,o.w||300,o.h||300);if(o.vignette){const g=ctx.createRadialGradient(0,0,Math.min(o.w,o.h)*.2,0,0,Math.max(o.w,o.h)*.7);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${(o.vignette||0)/100})`);ctx.fillStyle=g;ctx.fillRect(-o.w/2,-o.h/2,o.w,o.h)}}else if(o.type==='draw'&&o.points?.length){ctx.strokeStyle=paint(ctx,o);ctx.lineWidth=o.size||8;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();o.points.forEach((p,i)=>i?ctx.lineTo(p.x-o.x,p.y-o.y):ctx.moveTo(p.x-o.x,p.y-o.y));ctx.stroke()}ctx.restore()}

  function render(){if(!studio?.canvas)return;all();const c=studio.canvas,ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);if(studio.bgGradient){const g0=studio.bgGradient,a=(g0.angle||0)*Math.PI/180;if(g0.type==='radial'){const g=ctx.createRadialGradient(c.width/2,c.height/2,0,c.width/2,c.height/2,Math.max(c.width,c.height)/2);g.addColorStop(0,g0.c1);g.addColorStop(1,g0.c2);ctx.fillStyle=g}else{const dx=Math.cos(a)*c.width,dy=Math.sin(a)*c.height,g=ctx.createLinearGradient(c.width/2-dx/2,c.height/2-dy/2,c.width/2+dx/2,c.height/2+dy/2);g.addColorStop(0,g0.c1);g.addColorStop(1,g0.c2);ctx.fillStyle=g}}else ctx.fillStyle=studio.bg||'#fff';ctx.fillRect(0,0,c.width,c.height);studio.layers.forEach(o=>drawV14(ctx,o));if(studio.selected&&typeof studioDrawSelection==='function'){const o=studioSelected();if(o)studioDrawSelection(ctx,o)}studioUpdateLayers?.();studioUpdateProps?.();const st=document.getElementById('studioStatusText');if(st)st.textContent=`Pixel Editor Pro • ${studioPage.width} × ${studioPage.height}`;if(window.innerWidth<=900&&document.getElementById('pixelLabBottomDock')){const a=document.querySelector('#pixelLabTabs button.active');if(a&&typeof plBuild==='function')plBuild(a.dataset.tab)}}
  const oldRender=window.studioRender;window.studioRender=render;
  const oldAddText=window.studioAddText;window.studioAddText=function(){oldAddText();const o=selected();if(o)ensure(o);render()};
  const oldImage=window.studioImageLoaded;window.studioImageLoaded=function(e){oldImage(e);setTimeout(()=>{const o=selected();if(o){ensure(o);o.brightness=100;o.contrast=100;o.saturation=100;o.hue=0;o.filterPreset='normal';render()}},50)};
  // Richer shapes from the create dock.
  const oldShape=window.studioAddShape;window.studioAddShape=function(t){oldShape(t);ensure(selected());render()};
  // Add V14 tab and advanced actions to the existing mobile dock.
  function installTab(){const tabs=document.getElementById('pixelLabTabs');if(!tabs||tabs.querySelector('[data-tab="more"]'))return;const b=document.createElement('button');b.dataset.tab='more';b.innerHTML='<span class="pli">✦</span><span>more</span>';b.addEventListener('click',()=>{tabs.querySelectorAll('button').forEach(x=>x.classList.remove('active'));b.classList.add('active');plBuild('more')});tabs.appendChild(b)}
  const oldPL=window.plBuild;window.plBuild=function(tab){installTab();if(tab==='more'){const actions=document.getElementById('pixelLabActions'),body=document.getElementById('pixelLabPropertyBody');const o=selected();actions.innerHTML=actionV('Text 3D','3D','pixelProText()')+actionV('Image Lab','◉','pixelProImage()')+actionV('Shapes','◇','pixelProShape()')+actionV('Background','◉','pixelProBackground()')+actionV('More','✦','pixelProMore()');body.innerHTML=o?`<div class="v14Panel"><div class="v14ChipRow"><button class="v14Chip" onclick="studioAlign('left')">Left</button><button class="v14Chip" onclick="studioAlign('center')">Center</button><button class="v14Chip" onclick="studioAlign('right')">Right</button><button class="v14Chip" onclick="studioBring('front')">Front</button><button class="v14Chip" onclick="studioBring('back')">Back</button><button class="v14Chip" onclick="studioToggleLock(studio.selected)">Lock</button></div></div>`:'<div class="studioEmpty">Select an object for advanced controls.</div>';return}oldPL?.(tab)};
  function actionV(l,i,f){return `<button onclick="${f}"><span class="pli">${i}</span><span>${l}</span></button>`}
  // Upgrade image filter state without breaking existing filter buttons.
  const oldFilter=window.studioFilter;window.studioFilter=function(name){const o=selected();if(o?.type==='image'){o.filterPreset=name==='gray'?'mono':name==='vivid'?'vivid':name==='bright'?'warm':name==='contrast'?'vivid':name==='soft'?'soft':'normal';render();
setTimeout(()=>{if(!state.settings.onboarded)studentOnboardOpen()},350);return}oldFilter?.(name);render()};
  // New text defaults.
  const oldCommit=window.studioCommitText;window.studioCommitText=function(id){oldCommit?.(id);const o=studio.layers.find(x=>x.id===id);if(o){ensure(o);render()}};
  // Repaint after the app becomes visible.
  const obs=new MutationObserver(()=>{if(document.getElementById('toolsApp')?.classList.contains('active'))setTimeout(()=>{installTab();render()},30)});obs.observe(document.body,{subtree:true,attributes:true,attributeFilter:['class']});
  setTimeout(()=>{installTab();all()},200);
})();

/* PixelLab-style contextual bottom dock controller */
(function(){
  window.pixelBottomCurrent='create';
  window.pixelBottomTab=function(tab){
    pixelBottomCurrent=tab;
    document.querySelectorAll('#pixelBottomTabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
    const panel=document.getElementById('pixelQuickPanel');
    if(!panel)return;
    panel.innerHTML=pixelPanelHTML(tab);
    panel.classList.add('open');
    if(tab==='layers') pixelRenderLayers();
  };
  window.pixelClosePanel=function(){document.getElementById('pixelQuickPanel')?.classList.remove('open')};
  window.pixelPanelHTML=function(tab){
    const o=typeof studioSelected==='function'?studioSelected():null;
    const has=!!o;
    const disabled=has?'':' disabled';
    const common=`<div class="pixelPanelHead"><span>${({create:'CREATE',text:'TEXT',style:'STYLE',image:'IMAGE',effects:'EFFECTS',layers:'LAYERS',more:'MORE'})[tab]||'TOOLS'}</span><small>${has?(o.name||o.type||'Selected layer'):'Select an object for layer tools'}</small></div>`;
    if(tab==='create')return common+`<div class="pixelActionGrid">
      <button class="pixelAction" onclick="studioAddText();pixelBottomTab('text')"><span>T</span>Text</button>
      <button class="pixelAction" onclick="studioOpenImage()"><span>▧</span>Image</button>
      <button class="pixelAction" onclick="studioAddShape('rect')"><span>▰</span>Shape</button>
      <button class="pixelAction" onclick="studioElements()"><span>✦</span>Elements</button>
      <button class="pixelAction" onclick="studioTool('draw')"><span>✎</span>Draw</button>
      <button class="pixelAction" onclick="studioPageSettings()"><span>▤</span>Page</button>
      <button class="pixelAction" onclick="studioTemplates()"><span>▦</span>Templates</button>
      <button class="pixelAction" onclick="studioBackground()"><span>◉</span>Background</button>
    </div>`;
    if(tab==='text')return common+`<div class="pixelActionGrid">
      <button class="pixelAction" onclick="studioTextEditor(studio.selected,true)"><span>✎</span>Edit Text</button>
      <button class="pixelAction" onclick="studioFonts()"><span>Aa</span>Fonts</button>
      <button class="pixelAction" onclick="pixelTextSize(-4)"><span>A−</span>Smaller</button>
      <button class="pixelAction" onclick="pixelTextSize(4)"><span>A+</span>Larger</button>
      <button class="pixelAction" onclick="pixelTextWeight()"><span>B</span>Bold</button>
      <button class="pixelAction" onclick="pixelTextAlign('left')"><span>≡</span>Left</button>
      <button class="pixelAction" onclick="pixelTextAlign('center')"><span>≡</span>Center</button>
      <button class="pixelAction" onclick="pixelTextAlign('right')"><span>≡</span>Right</button>
    </div>`;
    if(tab==='style')return common+`<div class="pixelActionGrid">
      <button class="pixelAction" onclick="pixelColor()"><span>●</span>Color</button>
      <button class="pixelAction" onclick="pixelGradient()"><span>◈</span>Gradient</button>
      <button class="pixelAction" onclick="pixelStroke()"><span>▣</span>Stroke</button>
      <button class="pixelAction" onclick="pixelShadow()"><span>◒</span>Shadow</button>
      <button class="pixelAction" onclick="pixelInnerShadow()"><span>◓</span>Inner</button>
      <button class="pixelAction" onclick="pixelReflection()"><span>◫</span>Reflection</button>
      <button class="pixelAction" onclick="pixel3D()"><span>3D</span>Depth</button>
      <button class="pixelAction" onclick="pixelCurve()"><span>⌒</span>Curve</button>
    </div>`;
    if(tab==='image')return common+`<div class="pixelActionGrid">
      <button class="pixelAction" onclick="pixelImageFilter('normal')"><span>◌</span>Normal</button>
      <button class="pixelAction" onclick="pixelImageFilter('gray')"><span>◐</span>Mono</button>
      <button class="pixelAction" onclick="pixelImageFilter('bright')"><span>☼</span>Brightness</button>
      <button class="pixelAction" onclick="pixelImageFilter('contrast')"><span>◑</span>Contrast</button>
      <button class="pixelAction" onclick="pixelImageFilter('vivid')"><span>✦</span>Saturation</button>
      <button class="pixelAction" onclick="pixelImageFilter('soft')"><span>◒</span>Soft</button>
      <button class="pixelAction" onclick="pixelFlip('x')"><span>↔</span>Flip X</button>
      <button class="pixelAction" onclick="pixelFlip('y')"><span>↕</span>Flip Y</button>
    </div>`;
    if(tab==='effects')return common+`<div class="pixelActionGrid">
      <button class="pixelAction" onclick="pixelBlur()"><span>◌</span>Blur</button>
      <button class="pixelAction" onclick="pixelNoise()"><span>⌁</span>Noise</button>
      <button class="pixelAction" onclick="pixelStripes()"><span>▤</span>Stripes</button>
      <button class="pixelAction" onclick="pixelVignette()"><span>◉</span>Vignette</button>
      <button class="pixelAction" onclick="pixelOpacity(-10)"><span>−</span>Opacity −</button>
      <button class="pixelAction" onclick="pixelOpacity(10)"><span>＋</span>Opacity +</button>
      <button class="pixelAction" onclick="studioRotate(-15)"><span>↺</span>Rotate</button>
      <button class="pixelAction" onclick="studioRotate(15)"><span>↻</span>Rotate</button>
    </div>`;
    if(tab==='layers')return common+`<div class="pixelLayerList" id="pixelLayerList"></div><div class="pixelActionGrid">
      <button class="pixelAction" onclick="studioDuplicate()"><span>⧉</span>Copy</button>
      <button class="pixelAction" onclick="studioBring('front')"><span>↑</span>To Front</button>
      <button class="pixelAction" onclick="studioBring('back')"><span>↓</span>To Back</button>
      <button class="pixelAction" onclick="studioToggleLock(studio.selected)"><span>🔒</span>Lock</button>
      <button class="pixelAction" onclick="studioDeleteSelected()"><span>⌫</span>Delete</button>
      <button class="pixelAction" onclick="pixelHideSelected()"><span>◉</span>Hide</button>
    </div>`;
    return common+`<div class="pixelActionGrid">
      <button class="pixelAction" onclick="studioUndo()"><span>↶</span>Undo</button>
      <button class="pixelAction" onclick="studioRedo()"><span>↷</span>Redo</button>
      <button class="pixelAction" onclick="studioZoom(.9)"><span>−</span>Zoom Out</button>
      <button class="pixelAction" onclick="studioZoom(1.1)"><span>＋</span>Zoom In</button>
      <button class="pixelAction" onclick="studioFit()"><span>□</span>Fit</button>
      <button class="pixelAction" onclick="studioExport('png')"><span>PNG</span>Export</button>
      <button class="pixelAction" onclick="studioExport('jpg')"><span>JPG</span>Export</button>
      <button class="pixelAction" onclick="studioUtilities()"><span>⏱</span>Tools</button>
    </div>`;
  };
  window.pixelRenderLayers=function(){
    const box=document.getElementById('pixelLayerList'); if(!box)return;
    box.innerHTML=(studio.layers||[]).slice().reverse().map(o=>`<button class="pixelLayerCard ${o.id===studio.selected?'active':''}" onclick="studioSelect('${o.id}');pixelBottomTab('layers')"><span>${o.type==='text'?'T':o.type==='image'?'▧':o.type==='circle'?'●':'▰'}</span><span style="min-width:0"><b>${esc(o.name||o.text||o.type||'Layer')}</b><small>${o.locked?'Locked':'Editable'}</small></span></button>`).join('')||'<span style="font-size:9px;color:#8a93a1">No layers yet</span>';
  };
  window.pixelNeed=function(){const o=studioSelected?.();if(!o){studioToast('Select a layer first');return null}if(o.locked){studioToast('Layer is locked');return null}return o};
  window.pixelTextSize=function(delta){const o=pixelNeed();if(!o||o.type!=='text')return;o.size=Math.max(8,(o.size||72)+delta);studioSaveHistory();studioRender();pixelBottomTab('text')};
  window.pixelTextWeight=function(){const o=pixelNeed();if(!o||o.type!=='text')return;o.weight=(o.weight||700)>=900?400:900;studioSaveHistory();studioRender();pixelBottomTab('text')};
  window.pixelTextAlign=function(a){const o=pixelNeed();if(!o||o.type!=='text')return;o.align=a;studioSaveHistory();studioRender();pixelBottomTab('text')};
  window.pixelColor=function(){const o=pixelNeed();if(!o)return;studioModal(`<div class="modalHeader"><h2>Fill Color</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="prop"><label>COLOR</label><input id="pixelColorInput" type="color" value="${o.color||'#ffffff'}" style="width:100%;height:55px"></div><div class="studioColorSwatches">${['#ffffff','#000000','#1976ff','#8b7cff','#39dfcf','#ff4fd8','#ffb84d','#ff5c7a','#ffd166','#35e0a1'].map(c=>`<button class="studioSwatch" style="background:${c}" onclick="pixelColorInput.value='${c}'"></button>`).join('')}</div><button class="studioBtn primary" style="width:100%;margin-top:12px" onclick="studioSelected().color=pixelColorInput.value;studioSaveHistory();studioRender();studioCloseModal();pixelBottomTab('style')">Apply Color</button>`)};
  window.pixelGradient=function(){if(!pixelNeed())return;studioBackground();};
  window.pixelStroke=function(){const o=pixelNeed();if(!o)return;studioModal(`<div class="modalHeader"><h2>Stroke</h2><button class="iconBtn" onclick="studioCloseModal()">×</button></div><div class="propGrid"><div class="prop"><label>WIDTH</label><input id="pStrokeW" type="number" min="0" max="60" value="${o.strokeWidth||0}"></div><div class="prop"><label>COLOR</label><input id="pStrokeC" type="color" value="${o.strokeColor||'#ffffff'}"></div></div><button class="studioBtn primary" style="width:100%;margin-top:12px" onclick="Object.assign(studioSelected(),{strokeWidth:+pStrokeW.value,strokeColor:pStrokeC.value});studioSaveHistory();studioRender();studioCloseModal()">Apply Stroke</button>`)};
  window.pixelShadow=function(){const o=pixelNeed();if(!o)return;o.shadowEnabled=!o.shadowEnabled;studioSaveHistory();studioRender();pixelBottomTab('style');};
  window.pixelInnerShadow=function(){const o=pixelNeed();if(!o)return;o.innerShadow=!o.innerShadow;studioSaveHistory();studioRender();pixelBottomTab('style');};
  window.pixelReflection=function(){const o=pixelNeed();if(!o)return;o.reflection=!o.reflection;studioSaveHistory();studioRender();pixelBottomTab('style');};
  window.pixel3D=function(){const o=pixelNeed();if(!o)return;o.depth=o.depth?0:12;studioSaveHistory();studioRender();pixelBottomTab('style');};
  window.pixelCurve=function(){const o=pixelNeed();if(!o||o.type!=='text'){studioToast('Select a text layer');return}o.curve=o.curve?0:20;studioSaveHistory();studioRender();pixelBottomTab('style');};
  window.pixelImageFilter=function(k){studioFilter(k);pixelBottomTab('image')};
  window.pixelFlip=function(axis){const o=pixelNeed();if(!o)return;o[axis==='x'?'flipX':'flipY']=!o[axis==='x'?'flipX':'flipY'];studioSaveHistory();studioRender();pixelBottomTab('image')};
  window.pixelBlur=function(){const o=pixelNeed();if(!o)return;o.blur=o.blur?0:5;studioSaveHistory();studioRender();pixelBottomTab('effects')};
  window.pixelNoise=function(){const o=pixelNeed();if(!o)return;o.noise=o.noise?0:.18;studioSaveHistory();studioRender();pixelBottomTab('effects')};
  window.pixelStripes=function(){const o=pixelNeed();if(!o)return;o.stripes=!o.stripes;studioSaveHistory();studioRender();pixelBottomTab('effects')};
  window.pixelVignette=function(){const o=pixelNeed();if(!o)return;o.vignette=!o.vignette;studioSaveHistory();studioRender();pixelBottomTab('effects')};
  window.pixelOpacity=function(delta){const o=pixelNeed();if(!o)return;o.opacity=Math.max(0,Math.min(1,(o.opacity??1)+delta/100));studioSaveHistory();studioRender();pixelBottomTab('effects')};
  window.pixelHideSelected=function(){const o=studioSelected?.();if(!o)return;o.hidden=!o.hidden;studioSaveHistory();studioRender();pixelBottomTab('layers')};
  const oldSelect=window.studioSelect;
  window.studioSelect=function(id){oldSelect(id);if(pixelBottomCurrent==='layers')pixelRenderLayers();};
  const oldRender=window.studioRender;
  window.studioRender=function(){oldRender();if(document.getElementById('pixelQuickPanel')?.classList.contains('open')){document.getElementById('pixelQuickPanel').innerHTML=pixelPanelHTML(pixelBottomCurrent);if(pixelBottomCurrent==='layers')pixelRenderLayers();}};
  setTimeout(()=>pixelBottomTab('create'),150);
})();


/* ===== V59: PDF flow matching the supplied Android-style PDF screen ===== */
(function(){
  const modal=document.getElementById('modal');
  function pdfState(){return window.v59Pdf||{orientation:'portrait',page:'A4',margin:'normal',quality:'high',kind:'text'}}
  window.v59Pdf=window.v59Pdf||{orientation:'portrait',page:'A4',margin:'normal',quality:'high',kind:'text',image:null};
  function dims(){const s=pdfState();let d=s.page==='A5'?{w:420,h:595}:s.page==='Letter'?{w:612,h:792}:{w:595,h:842};return s.orientation==='landscape'?{w:d.h,h:d.w}:d}
  function margin(){const s=pdfState();return s.margin==='narrow'?30:s.margin==='wide'?80:58}
  function escHtml(x){return typeof esc==='function'?esc(String(x??'')):String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  function set(kind,key,val){window.v59Pdf[kind]=val; render(kind)}
  function label(kind){return kind==='image'?'Image → PDF':'Document → PDF'}
  function previewHtml(kind){const s=pdfState(),land=s.orientation==='landscape';
    if(kind==='image' && s.image){return `<img src="${escHtml(s.image)}" alt="PDF image preview">`}
    const title=(document.getElementById('docTitle')?.value||'Untitled Document').trim()||'Untitled Document';
    const text=document.getElementById('docEditor')?.value||'';
    return `<h3>${escHtml(title)}</h3><pre>${escHtml(text||'Start writing here...')}</pre>`;
  }
  function render(kind){
    window.v59Pdf.kind=kind;const s=pdfState(),land=s.orientation==='landscape';
    const imageReady=kind==='image'&&!!s.image;
    openModal(`<div class="pdfNative">
      <div class="pdfNativeTop"><button type="button" onclick="v59PdfClose()">Cancel</button><b>Save as PDF</b><span style="width:55px"></span></div>
      <div class="pdfNativeBody"><div class="pdfNativePage ${land?'landscape':''}" id="v59PreviewPage"><div class="pdfNativePageContent">${previewHtml(kind)}</div></div></div>
      <div class="pdfNativeSettings">
        <div class="pdfNativeSettingsGrid">
          <button class="pdfNativeSetting ${s.orientation==='portrait'?'active':''}" onclick="v59PdfSet('orientation','portrait')"><div><small>Paper orientation</small><b>Portrait</b></div><span>›</span></button>
          <button class="pdfNativeSetting ${s.orientation==='landscape'?'active':''}" onclick="v59PdfSet('orientation','landscape')"><div><small>Paper orientation</small><b>Landscape</b></div><span>›</span></button>
          <button class="pdfNativeSetting" onclick="v59PdfCycle('page')"><div><small>Paper size</small><b>${escHtml(s.page)}</b></div><span>›</span></button>
          <button class="pdfNativeSetting" onclick="v59PdfCycle('margin')"><div><small>Page margins</small><b>${escHtml(s.margin[0].toUpperCase()+s.margin.slice(1))}</b></div><span>›</span></button>
        </div>
        ${kind==='image'&&!imageReady?`<button class="pdfNativeChoose" type="button" onclick="v59ChoosePdfImage()">Choose image</button>`:''}
        <button class="pdfNativeSave" type="button" onclick="v59SavePdf()">Save as PDF</button>
      </div>
    </div>`);
    modal.classList.add('pdfNativeOpen');
  }
  window.v59PdfClose=function(){modal.classList.remove('pdfNativeOpen');closeModal();}
  window.v59PdfSet=function(key,val){window.v59Pdf[key]=val;render(window.v59Pdf.kind)}
  window.v59PdfCycle=function(key){const lists={page:['A4','A5','Letter'],margin:['normal','narrow','wide']};const a=lists[key],i=a.indexOf(window.v59Pdf[key]);window.v59Pdf[key]=a[(i+1)%a.length];render(window.v59Pdf.kind)}
  window.v59PdfSettingsModal=function(kind){window.v59Pdf.kind=kind;window.v59Pdf.image=kind==='image'?(window.v59Pdf.image||null):null;render(kind)}
  window.docPrint=function(){window.v59PdfSettingsModal('text')}
  window.docPickImagePdf=function(){window.v59PdfSettingsModal('image')}
  window.v59ChoosePdfImage=function(){document.getElementById('docPdfImageInput')?.click()}
  const oldImageLoaded=window.docImageLoaded;
  window.docImageLoaded=function(ev,toPdf){
    if(toPdf){const f=ev.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{window.v59Pdf.image=r.result;window.v59Pdf.kind='image';render('image')};r.readAsDataURL(f);ev.target.value='';return}
    if(typeof oldImageLoaded==='function') return oldImageLoaded(ev,toPdf);
  }
  window.v59SavePdf=function(){const s=pdfState(),kind=s.kind;const title=(document.getElementById('docTitle')?.value||'Document').trim()||'Document';
    modal.classList.remove('pdfNativeOpen');closeModal();window.v57PdfSettings={orientation:s.orientation,page:s.page,margin:s.margin,quality:s.quality};window.docPdfOrientation=s.orientation;
    if(kind==='image'){
      if(!s.image){toast('Choose an image first');return}
      setTimeout(()=>docImageToPdf(s.image,title+'.jpg'),40);
    }else{
      const e=document.getElementById('docEditor');if(!e){toast('Open a document first');return}setTimeout(()=>downloadTextPdf(title,e.value,s.orientation),40);
    }
  }
  /* Keep old helpers compatible with the new settings. */
  window.v57PageDims=function(){const s=window.v57PdfSettings||window.v59Pdf;let d=s.page==='A5'?{w:420,h:595}:s.page==='Letter'?{w:612,h:792}:{w:595,h:842};return s.orientation==='landscape'?{w:d.h,h:d.w}:d}
  window.v57MarginValue=function(){const s=window.v57PdfSettings||window.v59Pdf;return s.margin==='narrow'?30:s.margin==='wide'?80:58}
  /* hard mobile sidebar lock: freeze the exact page scroll position */
  let v59ScrollY=0;
  window.closeMenu=function(){const s=document.getElementById('sidebar'),scr=document.getElementById('menuScrim');s?.classList.remove('open');scr?.classList.remove('show');document.documentElement.classList.remove('menuLocked','v59MenuLock');document.body.classList.remove('menuLocked','v59MenuLock');document.body.style.top='';document.body.style.position='';document.body.style.width='';document.body.style.left='';document.body.style.right='';document.documentElement.classList.remove('v59-menu-open');if(document.body.classList.contains('v59MenuLock'))window.scrollTo(0,v59ScrollY);s?.removeAttribute('aria-modal')}
  window.toggleMenu=function(){const s=document.getElementById('sidebar'),scr=document.getElementById('menuScrim');if(!s)return;const isOpen=s.classList.contains('open');if(isOpen){window.closeMenu();return}v59ScrollY=window.scrollY||document.documentElement.scrollTop||0;s.classList.add('open');scr?.classList.add('show');document.documentElement.classList.add('menuLocked','v59MenuLock','v59-menu-open');document.body.classList.add('menuLocked','v59MenuLock');document.body.style.position='fixed';document.body.style.top=`-${v59ScrollY}px`;document.body.style.left='0';document.body.style.right='0';document.body.style.width='100%';s.setAttribute('aria-modal','true')}
  /* Profile picture refresh after settings upload/remove. */
  const oldHP=window.handleProfilePicture,oldRP=window.removeProfilePicture;
  window.handleProfilePicture=function(ev){if(typeof oldHP==='function')oldHP(ev);setTimeout(()=>typeof syncAccountUIV57==='function'&&syncAccountUIV57(),120)};
  window.removeProfilePicture=function(){if(typeof oldRP==='function')oldRP();setTimeout(()=>typeof syncAccountUIV57==='function'&&syncAccountUIV57(),120)};
})();


/* MY LIFE OS V60 — final working PDF + mobile menu repair */
(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  /* ---- PDF: bind the final functions after every older script ---- */
  window.v60Pdf=window.v60Pdf||{orientation:'portrait',page:'A4',margin:'normal',kind:'text',image:null};
  function pdfState(){return window.v60Pdf;}
  function escH(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  function pdfDims(){const s=pdfState();let d=s.page==='A5'?{w:420,h:595}:s.page==='Letter'?{w:612,h:792}:{w:595,h:842};return s.orientation==='landscape'?{w:d.h,h:d.w}:d;}
  function pdfMargin(){const s=pdfState();return s.margin==='narrow'?30:s.margin==='wide'?80:58;}
  function preview(kind){
    const s=pdfState();
    if(kind==='image'&&s.image)return '<img src="'+escH(s.image)+'" alt="Image preview">';
    const title=($('docTitle')?.value||'Untitled Document').trim()||'Untitled Document';
    const text=$('docEditor')?.value||'';
    return '<h3>'+escH(title)+'</h3><pre>'+escH(text||'Start writing here...')+'</pre>';
  }
  function renderPdf(kind){
    P.kind=kind;const modal=$('modal'),card=$('modalCard');if(!modal||!card)return;const land=P.orientation==='landscape';let content='';
    if(kind==='image'&&P.image)content='<img src="'+pdfEsc(P.image)+'" alt="Image preview">';
    else if(kind==='text'){const title=(($('docTitle')?.value||'Untitled Document').trim()||'Untitled Document'),text=$('docEditor')?.value||'';content='<h3>'+pdfEsc(title)+'</h3><pre>'+pdfEsc(text||'Start writing here...')+'</pre>'}
    else content='<div style="display:grid;place-items:center;min-height:360px;color:#6b6f76;font-size:14px">Choose an image to preview</div>';
    const pageNumberLabel=P.pageNumber?'Add':'Remove';
    card.innerHTML='<div class="pdfNative"><div class="pdfNativeTop"><button type="button" id="v62PdfCancel">Cancel</button><b>Save as PDF</b><span style="width:55px"></span></div><div class="pdfNativeBody"><div class="pdfNativePage '+(land?'landscape':'')+'"><div class="pdfNativePageContent">'+content+'</div></div></div><div class="pdfNativeSettings"><div class="pdfNativeSettingsGrid"><button type="button" class="pdfNativeSetting '+(P.orientation==='portrait'?'active':'')+'" id="v62Portrait"><div><small>Paper orientation</small><b>Portrait</b></div><span>›</span></button><button type="button" class="pdfNativeSetting '+(P.pageNumber?'active':'')+'" id="v62PageNumber"><div><small>Page number</small><b>'+pageNumberLabel+'</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v62Page"><div><small>Paper size</small><b>'+pdfEsc(P.page)+'</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v62Margin"><div><small>Page margins</small><b>'+pdfEsc(P.margin.charAt(0).toUpperCase()+P.margin.slice(1))+'</b></div><span>›</span></button></div>'+(kind==='image'&&!P.image?'<button type="button" class="pdfNativeChoose" id="v62Choose">Choose image</button>':'')+'<button type="button" class="pdfNativeSave" id="v62Save">Save as PDF</button></div></div>';
    modal.classList.add('open','pdfNativeOpen');$('v62PdfCancel').onclick=closePdf;$('v62Portrait').onclick=()=>pdfChooser('orientation');$('v62PageNumber').onclick=()=>pdfChooser('pageNumber');$('v62Page').onclick=()=>pdfChooser('page');$('v62Margin').onclick=()=>pdfChooser('margin');$('v62Choose')?.addEventListener('click',()=>$('docPdfImageInput')?.click());$('v62Save').onclick=savePdf;
  }
  function closePdf(){$('modal')?.classList.remove('pdfNativeOpen','open');}
  function savePdf(){
    const s=pdfState();
    window.v57PdfSettings={orientation:s.orientation,page:s.page,margin:s.margin,quality:'high'};
    window.docPdfOrientation=s.orientation;
    const title=($('docTitle')?.value||'Document').trim()||'Document';
    closePdf();
    if(s.kind==='image'){
      if(!s.image){alert('Please choose an image first.');renderPdf('image');return;}
      setTimeout(()=>{try{window.docImageToPdf(s.image,title+'.jpg')}catch(e){console.error(e);alert('PDF creation failed.')}},40);
    }else{
      const e=$('docEditor');
      if(!e){alert('Open Document Writer first.');return;}
      setTimeout(()=>{try{window.downloadTextPdf(title,e.value,s.orientation)}catch(e){console.error(e);alert('PDF creation failed.')}},40);
    }
  }
  window.docPrint=()=>{window.v60Pdf.kind='text';window.v60Pdf.image=null;renderPdf('text');};
  window.docPickImagePdf=()=>{window.v60Pdf.kind='image';window.v60Pdf.image=null;renderPdf('image');};
  window.v59PdfSettingsModal=kind=>{window.v60Pdf.kind=kind;window.v60Pdf.image=kind==='image'?window.v60Pdf.image:null;renderPdf(kind);};
  window.v59PdfClose=closePdf;
  window.v59PdfSet=(key,val)=>{window.v60Pdf[key]=val;renderPdf(window.v60Pdf.kind);};
  window.v59PdfCycle=key=>{const lists={page:['A4','A5','Letter'],margin:['normal','narrow','wide']};const a=lists[key];window.v60Pdf[key]=a[(a.indexOf(window.v60Pdf[key])+1)%a.length];renderPdf(window.v60Pdf.kind);};
  window.v59ChoosePdfImage=()=>$('docPdfImageInput')?.click();
  /* Make image input reliably feed the PDF preview. */
  window.docImageLoaded=function(ev,toPdf){
    const f=ev?.target?.files?.[0]; if(!f)return;
    const r=new FileReader(); r.onload=()=>{
      if(toPdf){window.v60Pdf.image=r.result;window.v60Pdf.kind='image';renderPdf('image');}
      else if(typeof window.__v60OldDocImageLoaded==='function')window.__v60OldDocImageLoaded(ev,false);
    }; r.readAsDataURL(f); if(ev.target)ev.target.value='';
  };
  /* ---- MOBILE MENU: true background freeze + sidebar-only scrolling ---- */
  let lockedY=0, menuTouchActive=false;
  function freeze(){
    lockedY=window.scrollY||document.documentElement.scrollTop||0;
    document.documentElement.classList.add('v60MenuOpen'); document.body.classList.add('v60MenuOpen');
    document.body.style.position='fixed';document.body.style.top=(-lockedY)+'px';document.body.style.left='0';document.body.style.right='0';document.body.style.width='100%';
  }
  function unfreeze(){
    document.documentElement.classList.remove('v60MenuOpen');document.body.classList.remove('v60MenuOpen');
    document.body.style.position='';document.body.style.top='';document.body.style.left='';document.body.style.right='';document.body.style.width='';
    window.scrollTo(0,lockedY);
  }
  window.closeMenu=function(){const s=$('sidebar'),scr=$('menuScrim');s?.classList.remove('open');scr?.classList.remove('show');unfreeze();s?.removeAttribute('aria-modal');};
  window.toggleMenu=function(){const s=$('sidebar'),scr=$('menuScrim');if(!s)return;if(s.classList.contains('open')){window.closeMenu();return;}freeze();s.classList.add('open');scr?.classList.add('show');s.setAttribute('aria-modal','true');};
  document.addEventListener('touchmove',e=>{if(!document.body.classList.contains('v60MenuOpen'))return;const s=$('sidebar');if(s&&s.contains(e.target))return;e.preventDefault();},{passive:false});
  document.addEventListener('wheel',e=>{if(document.body.classList.contains('v60MenuOpen')){const s=$('sidebar');if(s&&s.contains(e.target))return;e.preventDefault();}},{passive:false});
  document.addEventListener('click',e=>{const s=$('sidebar');const scr=$('menuScrim');if(s?.classList.contains('open')&&scr?.classList.contains('show')&&e.target===scr)window.closeMenu();});
  /* Sidebar account card always stays first and updates after profile changes. */
  window.syncAccountUIV57=function(){const box=$('sidebarAccount');if(!box)return;let email=localStorage.getItem('myLifeOS_active_account_v57')||'';let db={};try{db=JSON.parse(localStorage.getItem('myLifeOS_accounts_v57')||'{}')}catch(e){}let a=email?db[email]:null;let pic=state?.settings?.profilePicture||a?.state?.settings?.profilePicture||'';let name=state?.settings?.name||a?.profile?.name||'STUDENT';let cls=state?.settings?.studentClass||a?.profile?.studentClass||'Student Account';box.innerHTML=(pic?'<img class="sideAvatar" src="'+escH(pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+'<div class="sideInfo"><b>'+escH(name)+'</b><small>'+escH(cls)+'</small></div>'+(email?'<button type="button" class="accountLogoutBtn" title="Logout">↪</button>':'');box.querySelector('.accountLogoutBtn')?.addEventListener('click',e=>{e.stopPropagation();window.logoutAccount();});};
  /* Keep account card visible at the top of the sidebar. */
  const side=$('sidebar'),acct=$('sidebarAccount'); if(side&&acct){side.insertBefore(acct,side.firstElementChild?.nextElementSibling||side.firstChild);}
  window.__v60Ready=true;
  setTimeout(()=>window.syncAccountUIV57?.(),80);
})();


(function(){
'use strict';
const $=id=>document.getElementById(id);
const ACCOUNT_KEY='myLifeOS_accounts_v57';
const ACTIVE_KEY='myLifeOS_active_account_v57';
let pendingEmail='';
function clone(x){return JSON.parse(JSON.stringify(x));}
function accounts(){try{return JSON.parse(localStorage.getItem(ACCOUNT_KEY)||'{}')}catch(e){return {}}}
function writeAccounts(v){localStorage.setItem(ACCOUNT_KEY,JSON.stringify(v));}
function active(){return localStorage.getItem(ACTIVE_KEY)||''}
function setActive(e){localStorage.setItem(ACTIVE_KEY,e)}
function clearActive(){localStorage.removeItem(ACTIVE_KEY)}
function escH(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function lockApp(){document.body.classList.remove('v61Ready','authLocked');document.body.classList.add('authLocked');$('accessGate')?.classList.add('show');}
function readyApp(){document.body.classList.remove('authLocked');document.body.classList.add('v61Ready');$('accessGate')?.classList.remove('show');}
function loading(next){const l=$('v54Loader');if(!l){next();return}l.classList.add('show');l.setAttribute('aria-hidden','false');setTimeout(()=>{l.classList.remove('show');l.setAttribute('aria-hidden','true');next()},2600)}
function showStep(id){['accountLoginStep','accountCreateStep','accountProfileStep'].forEach(x=>{const e=$(x);if(e)e.style.display=x===id?'block':'none'});const b=$('accessProgressBar');if(b)b.style.width=id==='accountLoginStep'?'34%':id==='accountCreateStep'?'66%':'100%'}
window.showLoginAccount=()=>showStep('accountLoginStep');
window.showCreateAccount=()=>showStep('accountCreateStep');
async function hash(p,s){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(p),{name:'PBKDF2'},false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(s),iterations:120000,hash:'SHA-256'},key,256);return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,'0')).join('')}
window.createAccountNext=async function(){const e=($('createEmail')?.value||'').trim().toLowerCase(),p=$('createPassword')?.value||'',p2=$('createPassword2')?.value||'';if(!/^\S+@\S+\.\S+$/.test(e))return alert('Please enter a valid email ID.');if(p.length<6)return alert('Password must be at least 6 characters.');if(p!==p2)return alert('Passwords do not match.');const db=accounts();if(db[e]){alert('This email already has an account. Please sign in.');showStep('accountLoginStep');return}const salt=crypto.randomUUID();db[e]={email:e,passwordHash:await hash(p,salt),salt,profile:null,state:null,documents:[],createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};writeAccounts(db);pendingEmail=e;showStep('accountProfileStep');};
function finishProfileCommon(){const n=($('profileName')?.value||'').trim(),c=($('profileClass')?.value||'').trim(),s=($('profileSection')?.value||'').trim();if(n.length<2)return alert('Please enter the student name.');if(!c)return alert('Please enter the class / grade.');const e=pendingEmail,db=accounts(),a=db[e];if(!a)return showStep('accountLoginStep');state=clone(defaultState);state.settings={...defaultState.settings,name:n,studentClass:c,studentSection:s,studentEmail:e,onboarded:true};a.profile={name:n,studentClass:c,section:s};a.state=clone(state);a.documents=[];a.updatedAt=new Date().toISOString();db[e]=a;writeAccounts(db);setActive(e);pendingEmail='';syncSide();loading(()=>{readyApp();render();syncSide();toast('Welcome to MY LIFE OS ✓')});}
window.finishAccountProfile=finishProfileCommon;
window.loginAccount=async function(){const e=($('loginEmail')?.value||'').trim().toLowerCase(),p=$('loginPassword')?.value||'',db=accounts(),a=db[e];if(!a)return alert('Account not found. Create a new student account first.');const h=await hash(p,a.salt||e);if(h!==a.passwordHash)return alert('Incorrect email or password.');state=a.state?clone(a.state):clone(defaultState);state.settings={...defaultState.settings,...(state.settings||{})};if(a.profile){state.settings.name=a.profile.name;state.settings.studentClass=a.profile.studentClass;state.settings.studentSection=a.profile.section||'';state.settings.studentEmail=e;state.settings.onboarded=true}setActive(e);syncSide();loading(()=>{readyApp();render();syncSide();toast('Welcome back ✓')});};
window.saveAccountSnapshotV57=function(){const e=active();if(!e)return;const db=accounts(),a=db[e];if(!a)return;a.state=clone(state);a.documents=clone(typeof loadDocStore==='function'?loadDocStore():(state.documents||[]));a.updatedAt=new Date().toISOString();db[e]=a;writeAccounts(db)};
window.logoutAccount=function(){try{window.saveAccountSnapshotV57()}catch(e){}clearActive();lockApp();showStep('accountLoginStep');if($('loginEmail'))$('loginEmail').value='';if($('loginPassword'))$('loginPassword').value='';syncSide();};
window.syncAccountUIV57=syncSide;
function syncSide(){const box=$('sidebarAccount');if(!box)return;const e=active(),db=accounts(),a=e?db[e]:null,pic=state?.settings?.profilePicture||a?.state?.settings?.profilePicture||'',name=state?.settings?.name||a?.profile?.name||'STUDENT',cls=state?.settings?.studentClass||a?.profile?.studentClass||'Student Account';box.innerHTML=(pic?'<img class="sideAvatar" src="'+escH(pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+'<div class="sideInfo"><b>'+escH(name)+'</b><small>'+escH(cls)+'</small></div>'+(e?'<button type="button" class="accountLogoutBtn" aria-label="Logout">↪</button>':'');box.querySelector('.accountLogoutBtn')?.addEventListener('click',ev=>{ev.stopPropagation();window.logoutAccount()});}
/* ---- Menu: freeze the document, allow only the sidebar nav to scroll. ---- */
let menuY=0;
window.closeMenu=function(){const s=$('sidebar'),scr=$('menuScrim');s?.classList.remove('open');scr?.classList.remove('show');document.documentElement.classList.remove('v61MenuOpen');document.body.classList.remove('v61MenuOpen');document.body.style.position='';document.body.style.top='';document.body.style.left='';document.body.style.right='';document.body.style.width='';if(document.body.classList.contains('v61MenuOpen')||document.body.classList.contains('v62MenuOpen'))window.scrollTo(0,menuY);s?.removeAttribute('aria-modal')};
window.toggleMenu=function(){const s=$('sidebar'),scr=$('menuScrim');if(!s)return;if(s.classList.contains('open'))return window.closeMenu();menuY=window.scrollY||document.documentElement.scrollTop||0;document.documentElement.classList.add('v61MenuOpen');document.body.classList.add('v61MenuOpen');document.body.style.position='fixed';document.body.style.top=(-menuY)+'px';document.body.style.left='0';document.body.style.right='0';document.body.style.width='100%';s.classList.add('open');scr?.classList.add('show');s.setAttribute('aria-modal','true')};
/* Any normal navigation closes the drawer through the full unlock path. */
const oldGo=window.go;window.go=function(p){if(document.getElementById('sidebar')?.classList.contains('open'))window.closeMenu();if(typeof oldGo==='function')oldGo(p);else{current=p;render()}};
/* ---- PDF: one reliable flow for both text and image. ---- */
window.v61Pdf={orientation:'portrait',page:'A4',margin:'normal',quality:'high',kind:'text',image:null};
function dims(){let d=window.v61Pdf.page==='A5'?{w:420,h:595}:window.v61Pdf.page==='Letter'?{w:612,h:792}:{w:595,h:842};return window.v61Pdf.orientation==='landscape'?{w:d.h,h:d.w}:d}
function pdfModal(kind){window.v61Pdf.kind=kind;const s=window.v61Pdf,m=$('modal'),c=$('modalCard');if(!m||!c)return;const land=s.orientation==='landscape';let content='';if(kind==='image'&&s.image)content='<img src="'+escH(s.image)+'" alt="Image preview">';else if(kind==='text'){const t=($('docTitle')?.value||'Untitled Document').trim()||'Untitled Document',txt=$('docEditor')?.value||'';content='<h3>'+escH(t)+'</h3><pre>'+escH(txt||'Start writing here...')+'</pre>'}else content='<div style="display:grid;place-items:center;height:100%;color:#6b6f76;font-size:14px">Choose an image to preview</div>';
c.innerHTML='<div class="pdfNative"><div class="pdfNativeTop"><button type="button" id="v61PdfCancel">Cancel</button><b>Save as PDF</b><span style="width:55px"></span></div><div class="pdfNativeBody"><div class="pdfNativePage '+(land?'landscape':'')+'"><div class="pdfNativePageContent">'+content+'</div></div></div><div class="pdfNativeSettings"><div class="pdfNativeSettingsGrid"><button type="button" class="pdfNativeSetting '+(s.orientation==='portrait'?'active':'')+'" id="v61Portrait"><div><small>Paper orientation</small><b>Portrait</b></div><span>›</span></button><button type="button" class="pdfNativeSetting '+(s.orientation==='landscape'?'active':'')+'" id="v61Landscape"><div><small>Paper orientation</small><b>Landscape</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v61Page"><div><small>Paper size</small><b>'+escH(s.page)+'</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v61Margin"><div><small>Page margins</small><b>'+escH(s.margin.charAt(0).toUpperCase()+s.margin.slice(1))+'</b></div><span>›</span></button></div>'+(kind==='image'&&!s.image?'<button type="button" class="pdfNativeChoose" id="v61Choose">Choose image</button>':'')+'<button type="button" class="pdfNativeSave" id="v61Save">Save as PDF</button></div></div>';
m.classList.add('open','pdfNativeOpen');$('v61PdfCancel').onclick=()=>{m.classList.remove('open','pdfNativeOpen')};$('v61Portrait').onclick=()=>{s.orientation='portrait';pdfModal(kind)};$('v61Landscape').onclick=()=>{s.orientation='landscape';pdfModal(kind)};$('v61Page').onclick=()=>{s.page=['A4','A5','Letter'][(['A4','A5','Letter'].indexOf(s.page)+1)%3];pdfModal(kind)};$('v61Margin').onclick=()=>{s.margin=['normal','narrow','wide'][(['normal','narrow','wide'].indexOf(s.margin)+1)%3];pdfModal(kind)};$('v61Choose')?.addEventListener('click',()=>$("docPdfImageInput")?.click());$('v61Save').onclick=()=>{if(kind==='image'&&!s.image){alert('Choose an image first.');return}m.classList.remove('open','pdfNativeOpen');window.v57PdfSettings={orientation:s.orientation,page:s.page,margin:s.margin,quality:s.quality};setTimeout(()=>{try{if(kind==='image')window.docImageToPdf(s.image,'image.pdf');else window.downloadTextPdf((($('docTitle')?.value||'Document').trim()||'Document'),$('docEditor')?.value||'',s.orientation)}catch(err){console.error(err);alert('PDF creation failed.')}} ,30)};
}
window.docPrint=()=>pdfModal('text');
window.docPickImagePdf=()=>{window.v61Pdf.kind='image';window.v61Pdf.image=null;pdfModal('image')};
window.v59PdfSettingsModal=kind=>pdfModal(kind);window.v59PdfClose=()=>{$('modal')?.classList.remove('open','pdfNativeOpen')};window.v59PdfSet=(k,v)=>{window.v61Pdf[k]=v;pdfModal(window.v61Pdf.kind)};window.v59PdfCycle=k=>{const a={page:['A4','A5','Letter'],margin:['normal','narrow','wide']}[k];window.v61Pdf[k]=a[(a.indexOf(window.v61Pdf[k])+1)%a.length];pdfModal(window.v61Pdf.kind)};window.v59ChoosePdfImage=()=>$("docPdfImageInput")?.click();
window.docImageLoaded=function(ev,toPdf){const f=ev?.target?.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{if(toPdf){window.v61Pdf.image=r.result;window.v61Pdf.kind='image';pdfModal('image')}else{state.documents=state.documents||[];docState.image=r.result;docTab('image');setTimeout(()=>typeof docShowImageTools==='function'&&docShowImageTools(r.result),50)}};r.readAsDataURL(f);if(ev.target)ev.target.value=''};
/* Profile picture always refreshes the account card. */
const oldHP=window.handleProfilePicture,oldRP=window.removeProfilePicture;window.handleProfilePicture=function(ev){if(typeof oldHP==='function')oldHP(ev);setTimeout(syncSide,100)};window.removeProfilePicture=function(){if(typeof oldRP==='function')oldRP();setTimeout(syncSide,100)};
/* Final bootstrap: old V53/V57 timers may run, but V61 owns the final state. */
function boot(){readyApp();if(typeof render==='function')render();}
setTimeout(boot,320);
setTimeout(()=>syncSide(),450);
})();


(function(){
'use strict';
const KEY='myLifeOS_student_accounts_v1', ACTIVE='myLifeOS_student_active_v1';
const $=id=>document.getElementById(id);
const clone=x=>JSON.parse(JSON.stringify(x));
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function db(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return {}}}
function write(v){localStorage.setItem(KEY,JSON.stringify(v))}
function active(){return localStorage.getItem(ACTIVE)||''}
function setActive(v){localStorage.setItem(ACTIVE,v)}
function clearActive(){localStorage.removeItem(ACTIVE)}
async function hashPassword(p,s){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(p),{name:'PBKDF2'},false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(s),iterations:120000,hash:'SHA-256'},key,256);return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,'0')).join('')}
function lock(){document.body.classList.add('mloAuthLocked')}
function unlock(){document.body.classList.remove('mloAuthLocked')}
function progress(n){if($('mloProgress'))$('mloProgress').querySelector('i').style.width=(n*33.333)+'%'}
function step(id){document.querySelectorAll('.mloStep').forEach(x=>x.classList.toggle('active',x.id===id));progress(id==='mloLogin'?1:id==='mloCreate'?2:id==='mloProfile'?3:4)}
function ensureGate(){if($('mloAuthGate'))return;const g=document.createElement('div');g.id='mloAuthGate';g.innerHTML=`<div class="mloAuthCard">
<div class="mloBrand"><div class="mloLogo">✦</div><div><b>MY LIFE OS</b><small>STUDENT COMMAND CENTER</small></div></div><div class="mloProgress" id="mloProgress"><i></i></div>
<section class="mloStep active" id="mloLogin"><span class="mloEyebrow">SECURE STUDENT LOGIN</span><h1 class="mloTitle">Welcome to <em>MY LIFE OS</em></h1><p class="mloSub">Sign in with your student account to continue to your personal workspace.</p><div class="mloForm"><label class="mloLabel">Email address<input class="mloInput" id="mloLoginEmail" type="email" autocomplete="username" placeholder="student@example.com"></label><label class="mloLabel">Password<input class="mloInput" id="mloLoginPassword" type="password" autocomplete="current-password" placeholder="Enter your password"></label><div class="mloError" id="mloLoginError"></div><button class="mloBtn" type="button" id="mloLoginBtn">ENTER MY LIFE OS →</button><button class="mloBtn secondary" type="button" id="mloCreateBtn">＋ Create new student account</button></div><div class="mloAccountNote">🔐 Your account is stored locally on this device. Logout never deletes your account.</div></section>
<section class="mloStep" id="mloCreate"><span class="mloEyebrow">CREATE ACCOUNT</span><h1 class="mloTitle">Create your <em>Student Account</em></h1><p class="mloSub">Use an email and any password you choose. You will set your student profile next.</p><div class="mloForm"><label class="mloLabel">Email address<input class="mloInput" id="mloCreateEmail" type="email" autocomplete="email" placeholder="student@example.com"></label><label class="mloLabel">Password<input class="mloInput" id="mloCreatePassword" type="password" autocomplete="new-password" placeholder="Create a password"></label><label class="mloLabel">Confirm password<input class="mloInput" id="mloCreatePassword2" type="password" autocomplete="new-password" placeholder="Repeat password"></label><div class="mloError" id="mloCreateError"></div><button class="mloBtn" type="button" id="mloCreateNext">CONTINUE →</button><button class="mloLink" type="button" id="mloBackLogin">← Back to login</button></div></section>
<section class="mloStep" id="mloProfile"><span class="mloEyebrow">STUDENT PROFILE</span><h1 class="mloTitle">Make it <em>yours.</em></h1><p class="mloSub">Enter the student name and class. Add a profile picture if you want it shown in the three-line menu.</p><div class="mloProfileRow"><div class="mloPicWrap"><div class="mloPic" id="mloPicPreview"><span>＋</span></div><input id="mloProfilePic" type="file" accept="image/*"></div><div><b>Add profile picture</b><div class="mloMini">This picture will appear in your ☰ profile section.</div></div></div><div class="mloForm"><label class="mloLabel">Student name<input class="mloInput" id="mloName" placeholder="Enter student name"></label><label class="mloLabel">Class / Grade<input class="mloInput" id="mloClass" placeholder="e.g. Class X"></label><label class="mloLabel">Section <span class="mloMini">(optional)</span><input class="mloInput" id="mloSection" placeholder="e.g. A"></label><div class="mloError" id="mloProfileError"></div><button class="mloBtn" type="button" id="mloProfileNext">CONTINUE TO VERIFICATION →</button><button class="mloLink" type="button" id="mloBackCreate">← Back</button></div></section>
<section class="mloStep" id="mloVerify"><span class="mloEyebrow">MAIN VERIFICATION</span><h1 class="mloTitle">Verify your <em>student account.</em></h1><p class="mloSub">One final check before MY LIFE OS opens. Enter the 6-digit verification code shown below.</p><div class="mloVerify"><div class="mloMini" style="text-align:center;margin-bottom:7px">YOUR VERIFICATION CODE</div><div class="mloCode" id="mloCode">000000</div></div><label class="mloLabel">Verification code<input class="mloInput" id="mloVerifyInput" inputmode="numeric" maxlength="6" placeholder="Enter 6 digits"></label><div class="mloError" id="mloVerifyError"></div><button class="mloBtn" type="button" id="mloVerifyBtn">VERIFY & OPEN MY LIFE OS →</button><button class="mloLink" type="button" id="mloBackProfile">← Back</button></section>
</div>`;document.body.appendChild(g);
$('mloLoginBtn').onclick=function(ev){ev.preventDefault();ev.stopPropagation();window.mloLoginNow();};$('mloLoginBtn').addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();window.mloLoginNow();},{capture:true});$('mloCreateBtn').onclick=()=>{clearErr();step('mloCreate')};$('mloBackLogin').onclick=()=>{clearErr();step('mloLogin')};$('mloCreateNext').onclick=createNext;$('mloBackCreate').onclick=()=>{clearErr();step('mloCreate')};$('mloProfileNext').onclick=profileNext;$('mloBackProfile').onclick=()=>{clearErr();step('mloProfile')};$('mloVerifyBtn').onclick=verify;$('mloProfilePic').onchange=previewPic;$('mloVerifyInput').addEventListener('input',e=>e.target.value=e.target.value.replace(/\D/g,''));
}
function clearErr(){['mloLoginError','mloCreateError','mloProfileError','mloVerifyError'].forEach(id=>{if($(id))$(id).textContent=''})}
let pending='',pendingCode='',pendingPic='';
function previewPic(e){const f=e.target.files?.[0];if(!f)return;if(f.size>4*1024*1024){$('mloProfileError').textContent='Profile picture must be under 4 MB.';return}const r=new FileReader();r.onload=()=>{pendingPic=r.result;$('mloPicPreview').innerHTML='<img src="'+esc(r.result)+'" style="width:100%;height:100%;object-fit:cover" alt="Profile">'};r.readAsDataURL(f)}
async function createNext(){const e=$('mloCreateEmail').value.trim().toLowerCase(),p=$('mloCreatePassword').value,p2=$('mloCreatePassword2').value, d=db();if(!/^\S+@\S+\.\S+$/.test(e))return $('mloCreateError').textContent='Please enter a valid email address.';if(!p)return $('mloCreateError').textContent='Please enter a password.';if(p!==p2)return $('mloCreateError').textContent='Passwords do not match.';if(d[e])return $('mloCreateError').textContent='This email already has an account. Please log in.';const salt=crypto.randomUUID();d[e]={email:e,passwordHash:await hashPassword(p,salt),salt,profile:null,state:null,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};write(d);pending=e;pendingPic='';$('mloProfilePic').value='';$('mloPicPreview').innerHTML='<span>＋</span>';$('mloName').value='';$('mloClass').value='';$('mloSection').value='';clearErr();step('mloProfile')}
function profileNext(){const n=$('mloName').value.trim(),c=$('mloClass').value.trim(),s=$('mloSection').value.trim();if(n.length<2)return $('mloProfileError').textContent='Please enter the student name.';if(!c)return $('mloProfileError').textContent='Please enter the class / grade.';if(!pending)return step('mloLogin');pendingCode=String(Math.floor(100000+Math.random()*900000));$('mloCode').textContent=pendingCode;$('mloVerifyInput').value='';clearErr();step('mloVerify')}
function verify(){if($('mloVerifyInput').value.trim()!==pendingCode)return $('mloVerifyError').textContent='Verification code is incorrect. Please enter the code shown above.';const d=db(),a=d[pending];if(!a)return step('mloLogin');const n=$('mloName').value.trim(),c=$('mloClass').value.trim(),s=$('mloSection').value.trim();state=clone(defaultState);state.settings={...defaultState.settings,name:n,studentClass:c,studentSection:s,studentEmail:pending,profilePicture:pendingPic,onboarded:true};a.profile={name:n,studentClass:c,section:s,profilePicture:pendingPic};a.state=clone(state);a.verified=true;a.updatedAt=new Date().toISOString();d[pending]=a;write(d);setActive(pending);pending='';pendingCode='';pendingPic='';unlock();render();syncSide();toast('Student account verified ✓')}
async function login(){
  const err=$('mloLoginError');
  try{
    const emailEl=$('mloLoginEmail'), passEl=$('mloLoginPassword');
    const e=(emailEl?.value||'').trim().toLowerCase(), p=passEl?.value||'';
    if(err) err.textContent='';
    if(!e||!p){if(err)err.textContent='Enter your email and password.';return;}
    const d=db(),a=d[e];
    if(!a){if(err)err.textContent='Account not found. Create a new student account first.';return;}
    let ok=false;
    if(a.passwordHash && a.salt){
      const h=await hashPassword(p,a.salt); ok=(h===a.passwordHash);
    }
    if(!ok && a.password){ ok=(p===a.password); }
    if(!ok){if(err)err.textContent='Incorrect email or password.';return;}
    if(!a.profile){pending=e;pendingPic='';step('mloProfile');return;}
    state=a.state?clone(a.state):clone(defaultState);
    state.settings={...defaultState.settings,...(state.settings||{}),name:a.profile.name,studentClass:a.profile.studentClass,studentSection:a.profile.section||'',studentEmail:e,profilePicture:a.profile.profilePicture||state.settings?.profilePicture||'',onboarded:true};
    setActive(e);unlock();
    try{render()}catch(renderErr){console.error(renderErr);}
    try{syncSide()}catch(sideErr){console.error(sideErr);}
    toast('Welcome back ✓');
  }catch(ex){
    console.error('MY LIFE OS login error:',ex);
    if(err)err.textContent='Login could not open the workspace. Please try again.';
  }
}
window.mloLoginNow=login;
function saveAccount(){const e=active();if(!e)return;const d=db(),a=d[e];if(!a)return;a.state=clone(state);a.profile=a.profile||{name:state.settings.name,studentClass:state.settings.studentClass,section:state.settings.studentSection,profilePicture:state.settings.profilePicture||''};a.profile.name=state.settings.name;a.profile.studentClass=state.settings.studentClass;a.profile.section=state.settings.studentSection||'';a.profile.profilePicture=state.settings.profilePicture||a.profile.profilePicture||'';a.updatedAt=new Date().toISOString();d[e]=a;write(d)}
function syncSide(){const side=$('sidebar');if(!side)return;let card=$('sidebarAccount');if(!card){card=document.createElement('div');card.id='sidebarAccount';card.className='sidebarAccount';side.insertBefore(card,side.firstElementChild||null)}const e=active(),d=db(),a=e?d[e]:null;if(!e){card.innerHTML='';return}const pic=state.settings?.profilePicture||a?.profile?.profilePicture||'',name=state.settings?.name||a?.profile?.name||'STUDENT',cls=state.settings?.studentClass||a?.profile?.studentClass||'Student';card.innerHTML=(pic?'<img class="sideAvatar" src="'+esc(pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+'<div class="sideInfo"><b>'+esc(name)+'</b><small>'+esc(cls)+'</small></div>';let old=$('mloSideLogout');if(!old){old=document.createElement('button');old.id='mloSideLogout';old.className='mloSideLogout';old.type='button';old.textContent='↪ LOG OUT';side.insertBefore(old,side.querySelector('.nav')||null);old.onclick=logout}}
function ensureScrim(){let s=$('menuScrim');if(!s){s=document.createElement('div');s.id='menuScrim';s.className='menuScrim';document.body.appendChild(s)}s.onclick=()=>window.closeMenu?.()}
function logout(){saveAccount();clearActive();lock();if($('mloLoginEmail'))$('mloLoginEmail').value='';if($('mloLoginPassword'))$('mloLoginPassword').value='';clearErr();step('mloLogin');syncSide();window.closeMenu?.();toast('Logged out ✓')}
window.logoutAccount=logout;
window.saveAccountSnapshotV57=saveAccount;
const originalSave=window.save;window.save=function(){try{if(typeof originalSave==='function')originalSave()}catch(e){}try{saveAccount()}catch(e){}};
const originalProfile=window.handleProfilePicture;window.handleProfilePicture=function(ev){if(typeof originalProfile==='function')originalProfile(ev);setTimeout(()=>{saveAccount();syncSide()},120)};
const originalRemove=window.removeProfilePicture;window.removeProfilePicture=function(){if(typeof originalRemove==='function')originalRemove();setTimeout(()=>{saveAccount();syncSide()},120)};
const oldToggle=window.toggleMenu,oldClose=window.closeMenu;window.toggleMenu=function(){if(typeof oldToggle==='function')oldToggle();else{const s=$('sidebar');s?.classList.toggle('open')}syncSide()};window.closeMenu=function(){if(typeof oldClose==='function')oldClose();else{$('sidebar')?.classList.remove('open');$('menuScrim')?.classList.remove('show')} };
function boot(){ensureGate();
setTimeout(()=>{const b=document.getElementById('mloLoginBtn');if(b){b.type='button';b.style.pointerEvents='auto';b.style.position='relative';b.style.zIndex='999999';b.onclick=function(ev){ev.preventDefault();ev.stopPropagation();window.mloLoginNow();};}},80);
ensureScrim();const e=active(),d=db();if(e&&d[e]?.profile){state=d[e].state?clone(d[e].state):clone(defaultState);state.settings={...defaultState.settings,...(state.settings||{}),name:d[e].profile.name,studentClass:d[e].profile.studentClass,studentSection:d[e].profile.section||'',studentEmail:e,profilePicture:d[e].profile.profilePicture||state.settings?.profilePicture||'',onboarded:true};unlock();render();syncSide()}else{lock();step('mloLogin');syncSide()}}
ensureGate();ensureScrim();
setTimeout(boot,50);
})();


(function(){
  function q(id){return document.getElementById(id)}
  function escLocal(v){
    return String(v==null?'':v).replace(/[&<>'"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]})
  }
  function readAccount(){
    var email='';
    try{email=localStorage.getItem('myLifeOS_active_account_v57')||localStorage.getItem('myLifeOS_active_account_v60')||localStorage.getItem('myLifeOS_active_account')||''}catch(e){}
    var db={};
    try{db=JSON.parse(localStorage.getItem('myLifeOS_accounts_v57')||localStorage.getItem('myLifeOS_accounts')||'{}')}catch(e){}
    var a=email?db[email]:null;
    var st=window.state||{};
    var settings=st.settings||{};
    var profile=(a&&a.state&&a.state.settings)|| (a&&a.profile)||{};
    return {email:email,a:a,settings:settings,profile:profile}
  }
  function renderProfileCard(){
    var side=q('sidebar'), brand=side&&side.querySelector('.brand'), box=q('sidebarAccount');
    if(!side)return;
    if(!box){box=document.createElement('div');box.id='sidebarAccount';box.className='sidebarAccount'}
    if(brand && box.previousElementSibling!==brand) brand.insertAdjacentElement('afterend',box);
    var x=readAccount(), st=window.state||{}, settings=x.settings||{}, profile=x.profile||{};
    var pic=settings.profilePicture||profile.profilePicture||'';
    var name=settings.name||profile.name||'STUDENT';
    var cls=settings.studentClass||profile.studentClass||'Student Account';
    box.innerHTML=(pic?'<img class="sideAvatar" src="'+escLocal(pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+
      '<div class="sideInfo"><b>'+escLocal(name)+'</b><small>'+escLocal(cls)+'</small></div>'+
      (x.email?'<button type="button" class="profileSideLogout" aria-label="Log out">↪ LOG OUT</button>':'');
    var btn=box.querySelector('.profileSideLogout');
    if(btn)btn.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();if(typeof window.logoutAccount==='function')window.logoutAccount();});
  }
  window.mloRenderProfileCard=renderProfileCard;
  /* Replace the old sidebar sync so it cannot move the card above MY LIFE OS. */
  window.syncSide=renderProfileCard;
  window.syncAccountUIV57=renderProfileCard;
  window.addEventListener('DOMContentLoaded',function(){setTimeout(renderProfileCard,30);setTimeout(renderProfileCard,250);});
  /* Existing app code may call sync functions after profile changes. */
  setInterval(function(){
    var side=q('sidebar');
    if(side && q('sidebarAccount')){
      var box=q('sidebarAccount');
      var brand=side.querySelector('.brand');
      if(brand && box.previousElementSibling!==brand)brand.insertAdjacentElement('afterend',box);
      var old=box.querySelector('.mloSideLogout'); if(old)old.remove();
      var nav=side.querySelector('.nav'); if(nav && box.nextElementSibling!==nav && box.nextElementSibling!==side.querySelector('.sidebarBottom'))side.insertBefore(nav,box.nextElementSibling);
    }
  },800);
})();


(function(){
  const $=id=>document.getElementById(id);
  function esc(v){return String(v==null?'':v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
  function activeEmail(){
    return localStorage.getItem('myLifeOS_active_account_v57')||localStorage.getItem('myLifeOS_active_account_v60')||localStorage.getItem('myLifeOS_active_account')||'';
  }
  function getProfile(){
    const email=activeEmail(); let db={};
    try{db=JSON.parse(localStorage.getItem('myLifeOS_accounts_v57')||localStorage.getItem('myLifeOS_accounts')||'{}')}catch(e){}
    const a=email?db[email]:null, st=window.state||{}, set=st.settings||{};
    return {email,a,set, pic:set.profilePicture||a?.profile?.profilePicture||a?.state?.settings?.profilePicture||'', name:set.name||a?.profile?.name||'STUDENT', cls:set.studentClass||a?.profile?.studentClass||'Student Account'};
  }
  function realLogout(){
    try{ if(typeof window.saveAccountSnapshotV57==='function') window.saveAccountSnapshotV57(); else if(typeof window.saveAccount==='function') window.saveAccount(); }catch(e){}
    ['myLifeOS_active_account_v57','myLifeOS_active_account_v60','myLifeOS_active_account'].forEach(k=>{try{localStorage.removeItem(k)}catch(e){}});
    document.body.classList.add('authLocked');
    try{ if(typeof window.openAccessGate==='function') window.openAccessGate(); }catch(e){}
    try{ if(typeof window.showLoginAccount==='function') window.showLoginAccount(); else if(typeof window.showStepV57==='function') window.showStepV57('accountLoginStep'); }catch(e){}
    const em=$('loginEmail'),pw=$('loginPassword'); if(em)em.value=''; if(pw)pw.value='';
    try{ if(typeof window.syncAccountUIV57==='function') window.syncAccountUIV57(); }catch(e){}
    try{ if(typeof window.toast==='function') window.toast('Logged out ✓'); }catch(e){}
  }
  window.logoutAccount=realLogout;
  function draw(){
    const side=$('sidebar'), box=$('sidebarAccount'); if(!side||!box)return;
    const x=getProfile();
    if(!x.email && !x.a && !x.name)return;
    box.classList.add('profileLogoutReady');
    box.innerHTML=(x.pic?'<img class="sideAvatar" src="'+esc(x.pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+
      '<div class="sideInfo"><b>'+esc(x.name)+'</b><small>'+esc(x.cls)+'</small></div>'+ 
      '<button type="button" class="profileSideLogout" aria-label="Log out">LOG OUT</button>';
    const btn=box.querySelector('.profileSideLogout');
    if(btn){btn.onclick=function(e){e.preventDefault();e.stopPropagation();realLogout();};}
    const brand=side.querySelector('.brand');
    if(brand && box.previousElementSibling!==brand)brand.insertAdjacentElement('afterend',box);
  }
  window.mloForceRealLogout=draw;
  document.addEventListener('DOMContentLoaded',()=>{draw();setTimeout(draw,100);setTimeout(draw,500);});
  /* V4 controller owns profile refresh. */
})();


(function(){
  /* Compatibility bridge: the V4 IndexedDB controller below owns logout. */
  window.mloLegacyLogoutBridge=function(){
    try{ if(typeof window.mloPublishLogout==='function') return window.mloPublishLogout(); }catch(e){}
    try{ if(typeof window.logout==='function') return window.logout(); }catch(e){}
  };
})();


/* V19 viewport guard: never allow a child to make the Document Lab wider than the phone. */
(function(){
  function fixDocViewport(){
    const app=document.getElementById('toolsApp');
    if(!app)return;
    app.style.maxWidth=window.innerWidth+'px';
    app.style.width='100%';
    const main=app.querySelector('.docMain'), work=app.querySelector('.docWork');
    [main,work].forEach(el=>{if(el){el.style.maxWidth='100%';el.style.minWidth='0';}});
  }
  window.addEventListener('resize',fixDocViewport,{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(fixDocViewport,120),{passive:true});
  document.addEventListener('DOMContentLoaded',fixDocViewport);
  window.fixDocViewport=fixDocViewport;
})();


/* Keep horizontal gestures inside the bottom navigation only. */
(function(){
  const nav=document.getElementById('bottomNav');
  if(!nav)return;
  nav.addEventListener('touchstart',function(e){
    if(e.touches.length===1)this._sx=e.touches[0].clientX;
  },{passive:true});
  nav.addEventListener('touchmove',function(e){
    if(e.touches.length!==1)return;
    const dx=e.touches[0].clientX-(this._sx||e.touches[0].clientX);
    if(Math.abs(dx)>3 && this.scrollWidth>this.clientWidth){
      e.stopPropagation();
    }
  },{passive:true});
})();




/* ===== V30 CLEAN STUDENT INSTALL =====
   Keep all features, but start this package with no older app/demo data.
*/
(function(){
  const KEY='myLifeOS_v30_clean_install_done';
  try{
    if(!localStorage.getItem(KEY)){
      Object.keys(localStorage).forEach(k=>{
        if(/^myLifeOS_/i.test(k)||/^MY_LIFE_OS/i.test(k)) localStorage.removeItem(k);
      });
      Object.keys(sessionStorage).forEach(k=>{
        if(/^myLifeOS_/i.test(k)||/^MY_LIFE_OS/i.test(k)) sessionStorage.removeItem(k);
      });
      localStorage.setItem(KEY,'1');
    }
  }catch(e){}
})();

/* ===== V55 FREE STUDENT ACCESS FLOW =====
   No payment gate. Student completes the profile and enters MY LIFE OS.
   Profile data is stored locally on this device.
*/
const ACCESS_KEY = 'myLifeOS_student_profile_v53';
const SUPPORT_PHONE = '8436650793';
function accessRead(){try{return JSON.parse(localStorage.getItem(ACCESS_KEY)||'{}')}catch(e){return {}}}
function accessWrite(v){try{localStorage.setItem(ACCESS_KEY,JSON.stringify(v))}catch(e){}}
function openAccessGate(){const g=document.getElementById('accessGate');if(g)g.classList.add('show')}
function closeAccessGate(){const g=document.getElementById('accessGate');if(g)g.classList.remove('show')}
function completeFreeStudentProfile(){
  const name=(document.getElementById('accessName')?.value||'').trim();
  const cls=(document.getElementById('accessClass')?.value||'').trim();
  const phone=(document.getElementById('accessPhone')?.value||'').replace(/\D/g,'');
  const section=(document.getElementById('accessSection')?.value||'').trim();
  if(name.length<2){alert('Please enter the student name.');return}
  if(!cls){alert('Please enter the class / grade.');return}
  if(!/^\d{10}$/.test(phone)){alert('Please enter a valid 10-digit phone number.');return}
  const a={profileComplete:true,name:name.toUpperCase(),studentClass:cls,phone,section,createdAt:accessRead().createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
  accessWrite(a);
  try{
    state.settings=state.settings||{};
    state.settings.name=name.toUpperCase();
    state.settings.studentClass=cls;
    state.settings.studentSection=section;
    state.settings.studentPhone=phone;
    state.settings.onboarded=true;
    save();
  }catch(e){}
  startV54Loading();
}
function prefillStudentProfile(){
  const a=accessRead(); if(!a.profileComplete)return;
  const ids={accessName:a.name||'',accessClass:a.studentClass||'',accessPhone:a.phone||'',accessSection:a.section||''};
  Object.entries(ids).forEach(([id,v])=>{const el=document.getElementById(id);if(el)el.value=v});
}
function openSupport(){
  const phone=String(SUPPORT_PHONE||'').replace(/\D/g,'');
  if(phone.length>=10){
    const text=encodeURIComponent('Hello MY LIFE OS Support, I need help with my student account.');
    window.location.href='https://wa.me/91'+phone+'?text='+text;
  }else{
    alert('Support contact is not configured yet. The owner can add the support WhatsApp number in the website configuration.');
  }
}
function enforceAccessFlow(){document.body.classList.remove('authLocked');if(typeof closeAccessGate==='function')closeAccessGate();}
setTimeout(enforceAccessFlow,180);
(function(){
  function syncStudentGreeting(){
    try{
      const a=JSON.parse(localStorage.getItem('myLifeOS_student_profile_v53')||'{}');
      const s=(a.name||'').trim();
      const el=document.getElementById('dynamicGreetingName');
      if(el) el.textContent=s||'STUDENT';
    }catch(e){}
  }
  setTimeout(syncStudentGreeting,250);
  setTimeout(syncStudentGreeting,900);
})();


/* ===== V55 SUPPORT + LOADING ===== */
function startV54Loading(){const loader=document.getElementById('v54Loader');if(!loader){closeAccessGate();try{render()}catch(e){}return}loader.classList.add('show');loader.setAttribute('aria-hidden','false');const btn=document.querySelector('#accessStepProfile .accessBtn');if(btn)btn.disabled=true;setTimeout(()=>{loader.classList.remove('show');loader.setAttribute('aria-hidden','true');closeAccessGate();try{render()}catch(e){}toast('Welcome to MY LIFE OS ✓')},2600)}
function openSupport(){const phone=String(SUPPORT_PHONE||'').replace(/\D/g,'');if(phone.length>=10){const text=encodeURIComponent('Hello Pinaki, I need help with MY LIFE OS Student Edition.');window.location.href='https://wa.me/91'+phone+'?text='+text}else alert('Support contact is not configured yet.')}

/* ===== V57 FINAL ACCOUNT / PDF / MENU REPAIR ===== */
const ACCOUNT_KEY_V57='myLifeOS_accounts_v57';
let pendingCreateEmailV57='';
function accountStoreV57(){try{return JSON.parse(localStorage.getItem(ACCOUNT_KEY_V57)||'{}')}catch(e){return {}}}
function accountWriteV57(v){localStorage.setItem(ACCOUNT_KEY_V57,JSON.stringify(v))}
function activeAccountV57(){return localStorage.getItem('myLifeOS_active_account_v57')||''}
function setActiveAccountV57(email){localStorage.setItem('myLifeOS_active_account_v57',email)}
function clearActiveAccountV57(){localStorage.removeItem('myLifeOS_active_account_v57')}
async function hashPasswordV57(password,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),{name:'PBKDF2'},false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:120000,hash:'SHA-256'},key,256);return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,'0')).join('')}
function showStepV57(id){['accountLoginStep','accountCreateStep','accountProfileStep'].forEach(x=>{const e=document.getElementById(x);if(e)e.style.display=x===id?'block':'none'});const b=document.getElementById('accessProgressBar');if(b)b.style.width=id==='accountLoginStep'?'34%':id==='accountCreateStep'?'66%':'100%'}
function showLoginAccount(){showStepV57('accountLoginStep')}
function showCreateAccount(){showStepV57('accountCreateStep')}
function cloneV57(x){return JSON.parse(JSON.stringify(x))}
async function createAccountNext(){const email=(document.getElementById('createEmail')?.value||'').trim().toLowerCase(),p=document.getElementById('createPassword')?.value||'',p2=document.getElementById('createPassword2')?.value||'';if(!/^\S+@\S+\.\S+$/.test(email))return alert('Please enter a valid email ID.');if(p.length<6)return alert('Password must be at least 6 characters.');if(p!==p2)return alert('Passwords do not match.');const db=accountStoreV57();if(db[email]){alert('This email already has an account. Please sign in.');showLoginAccount();return}const salt=crypto.randomUUID(),hash=await hashPasswordV57(p,salt);db[email]={email,passwordHash:hash,salt,profile:null,state:null,documents:[],createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};accountWriteV57(db);pendingCreateEmailV57=email;showStepV57('accountProfileStep')}
async function loginAccount(){const email=(document.getElementById('loginEmail')?.value||'').trim().toLowerCase(),p=document.getElementById('loginPassword')?.value||'',db=accountStoreV57(),a=db[email];if(!a)return alert('Account not found. Create a new student account first.');const hash=await hashPasswordV57(p,a.salt||email);if(hash!==a.passwordHash)return alert('Incorrect email or password.');state=a.state?cloneV57(a.state):cloneV57(defaultState);state.settings={...defaultState.settings,...(state.settings||{})};if(a.profile){state.settings.name=a.profile.name;state.settings.studentClass=a.profile.studentClass;state.settings.studentSection=a.profile.section||'';state.settings.studentEmail=email;state.settings.onboarded=true}setActiveAccountV57(email);syncAccountUIV57();startV57Loading()}
function finishAccountProfile(){const name=(document.getElementById('profileName')?.value||'').trim(),cls=(document.getElementById('profileClass')?.value||'').trim(),sec=(document.getElementById('profileSection')?.value||'').trim();if(name.length<2)return alert('Please enter the student name.');if(!cls)return alert('Please enter the class / grade.');const email=pendingCreateEmailV57,db=accountStoreV57(),a=db[email];if(!a)return showLoginAccount();state=cloneV57(defaultState);state.settings={...defaultState.settings,name,studentClass:cls,studentSection:sec,studentEmail:email,onboarded:true};a.profile={name,studentClass:cls,section:sec};a.state=cloneV57(state);a.documents=[];a.updatedAt=new Date().toISOString();db[email]=a;accountWriteV57(db);setActiveAccountV57(email);pendingCreateEmailV57='';syncAccountUIV57();startV57Loading()}
function saveAccountSnapshotV57(){const email=activeAccountV57();if(!email)return;const db=accountStoreV57(),a=db[email];if(!a)return;a.state=cloneV57(state);a.documents=cloneV57(loadDocStore());a.updatedAt=new Date().toISOString();db[email]=a;accountWriteV57(db)}
function logoutAccount(){saveAccountSnapshotV57();clearActiveAccountV57();document.body.classList.add('authLocked');openAccessGate();showLoginAccount();document.getElementById('loginEmail').value='';document.getElementById('loginPassword').value='';syncAccountUIV57();toast('Logged out ✓')}
function syncAccountUIV57(){const box=document.getElementById('sidebarAccount');if(!box)return;const email=activeAccountV57(),a=email?accountStoreV57()[email]:null,pic=state?.settings?.profilePicture||'';box.innerHTML=`${pic?`<img class="sideAvatar" src="${esc(pic)}" alt="Profile">`:`<div class="sideAvatar">＋</div>`}<div class="sideInfo"><b>${esc(state?.settings?.name||a?.profile?.name||'STUDENT')}</b><small>${esc(state?.settings?.studentClass||a?.profile?.studentClass||email||'Student Account')}</small></div>${email?'<button onclick="logoutAccount()" title="Logout">↪</button>':''}`}
function closeMenu(){const s=document.getElementById('sidebar'),scr=document.getElementById('menuScrim');s?.classList.remove('open');scr?.classList.remove('show');document.documentElement.classList.remove('menuLocked');document.body.classList.remove('menuLocked')}
function toggleMenu(){const s=document.getElementById('sidebar'),scr=document.getElementById('menuScrim');if(!s)return;const open=!s.classList.contains('open');s.classList.toggle('open',open);scr?.classList.toggle('show',open);document.documentElement.classList.toggle('menuLocked',open);document.body.classList.toggle('menuLocked',open);if(open){s.setAttribute('aria-modal','true')}else{s.removeAttribute('aria-modal')}}
function save(){try{localStorage.setItem('myLifeOS_v3',JSON.stringify(state))}catch(e){}saveAccountSnapshotV57();try{syncAccountUIV57()}catch(e){}}
function enforceAccessFlow(){const email=activeAccountV57(),db=accountStoreV57();if(email&&db[email]?.profile){state=db[email].state?cloneV57(db[email].state):cloneV57(defaultState);state.settings={...defaultState.settings,...(state.settings||{})};document.body.classList.remove('authLocked');closeAccessGate();syncAccountUIV57();render()}else{document.body.classList.add('authLocked');openAccessGate();showLoginAccount()}}
function startV57Loading(){const l=document.getElementById('v54Loader');if(!l){document.body.classList.remove('authLocked');closeAccessGate();render();return}l.classList.add('show');setTimeout(()=>{l.classList.remove('show');document.body.classList.remove('authLocked');closeAccessGate();syncAccountUIV57();render();toast('Welcome to MY LIFE OS ✓')},2600)}
function loadDocStore(){try{return Array.isArray(window.__mloDocsCache)?window.__mloDocsCache:[]}catch(e){return []}}
function saveDocStore(docs){try{const clean=Array.isArray(docs)?docs:[];window.__mloDocsCache=clean;state.documents=clean;if(typeof window.mloIDBSaveDocs==='function')window.mloIDBSaveDocs(clean);return true}catch(e){return false}}
/* ===== V57 PDF SETTINGS ===== */
window.v57PdfSettings={orientation:'portrait',page:'A4',margin:'normal',quality:'high'};
function v57PageDims(){let d=window.v57PdfSettings.page==='A5'?{w:420,h:595}:window.v57PdfSettings.page==='Letter'?{w:612,h:792}:{w:595,h:842};return window.v57PdfSettings.orientation==='landscape'?{w:d.h,h:d.w}:d}
function v57MarginValue(){return window.v57PdfSettings.margin==='narrow'?30:window.v57PdfSettings.margin==='wide'?80:58}
function v57PdfSettingsModal(kind){const s=window.v57PdfSettings;openModal(`<div class="modalHeader pdfSettingsCard"><div><span class="eyebrow">PDF SETTINGS</span><h2>${kind==='image'?'Image → PDF':'Document → PDF'}</h2><small class="muted">Choose how your PDF should be created.</small></div><button class="iconBtn" onclick="closeModal()">×</button></div><div class="form pdfSettingsCard"><label>Orientation<select id="v57Ori"><option value="portrait" ${s.orientation==='portrait'?'selected':''}>Portrait</option><option value="landscape" ${s.orientation==='landscape'?'selected':''}>Landscape</option></select></label><label>Page size<select id="v57Page"><option value="A4" ${s.page==='A4'?'selected':''}>A4</option><option value="A5" ${s.page==='A5'?'selected':''}>A5</option><option value="Letter" ${s.page==='Letter'?'selected':''}>Letter</option></select></label><label>Page margins<select id="v57Margin"><option value="narrow" ${s.margin==='narrow'?'selected':''}>Narrow</option><option value="normal" ${s.margin==='normal'?'selected':''}>Normal</option><option value="wide" ${s.margin==='wide'?'selected':''}>Wide</option></select></label><label>PDF quality<select id="v57Quality"><option value="standard" ${s.quality==='standard'?'selected':''}>Standard</option><option value="high" ${s.quality==='high'?'selected':''}>High</option><option value="maximum" ${s.quality==='maximum'?'selected':''}>Maximum</option></select></label><div class="tools"><button class="btn" onclick="v57ApplyPdfSettings('${kind}')">${kind==='image'?'Choose Image':'Create PDF'}</button><button class="btn ghost" onclick="closeModal()">Cancel</button></div></div>`)}
function v57ApplyPdfSettings(kind){window.v57PdfSettings.orientation=document.getElementById('v57Ori').value;window.v57PdfSettings.page=document.getElementById('v57Page').value;window.v57PdfSettings.margin=document.getElementById('v57Margin').value;window.v57PdfSettings.quality=document.getElementById('v57Quality').value;window.docPdfOrientation=window.v57PdfSettings.orientation;if(kind==='image'){closeModal();openToolsApp();setTimeout(()=>document.getElementById('docPdfImageInput')?.click(),100)}else{const e=document.getElementById('docEditor'),t=document.getElementById('docTitle');closeModal();if(e)downloadTextPdf((t?.value||'Document').trim()||'Document',e.value,window.v57PdfSettings.orientation)}}
function docPrint(){v57PdfSettingsModal('text')}
function docPickImagePdf(){v57PdfSettingsModal('image')}
function renderTextPdfPages(title,text,orientation='portrait'){const {w:W,h:H}=v57PageDims(),m=v57MarginValue(),scale=2,titleSize=orientation==='landscape'?24:27,bodySize=orientation==='landscape'?14:16,lineH=orientation==='landscape'?22:25,ctx=document.createElement('canvas').getContext('2d');ctx.font=`${bodySize}px "Noto Sans Bengali","Noto Sans Devanagari","Noto Sans",Arial,sans-serif`;const maxW=W-m*2,lines=[];for(const raw of String(text||'').split(/\r?\n/)){if(!raw){lines.push('');continue}let cur='';for(const ch of raw){const test=cur+ch;if(cur&&ctx.measureText(test).width>maxW){lines.push(cur);cur=ch}else cur=test}lines.push(cur)}const pages=[];let idx=0;while(idx<lines.length||!pages.length){const c=document.createElement('canvas');c.width=W*scale;c.height=H*scale;const x=c.getContext('2d',{alpha:false});x.scale(scale,scale);x.fillStyle='#fff';x.fillRect(0,0,W,H);x.fillStyle='#111';x.font=`bold ${titleSize}px "Noto Sans Bengali","Noto Sans Devanagari","Noto Sans",Arial,sans-serif`;x.fillText(title||'MY LIFE OS Document',m,m);x.font=`${bodySize}px "Noto Sans Bengali","Noto Sans Devanagari","Noto Sans",Arial,sans-serif`;let y=m+44;while(idx<lines.length&&y<=H-m){x.fillText(lines[idx],m,y);y+=lineH;idx++}pages.push({jpg:pdfDataUrlBytes(c.toDataURL('image/jpeg',window.v57PdfSettings.quality==='standard'?.90:window.v57PdfSettings.quality==='maximum'?.99:.97)),w:c.width,h:c.height})}return pages}
function downloadTextPdf(title,text,orientation='portrait'){const pages=renderTextPdfPages(title,text,orientation),blob=makeJpegPdfPages(pages,title,orientation),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(title||'document')+'.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1800);toast((orientation==='landscape'?'LANDSCAPE':'PORTRAIT')+' PDF CREATED ✓')}
function makeJpegPdfPages(pages,title,orientation='portrait'){const {w:PW,h:PH}=v57PageDims(),parts=[pdfAscii('%PDF-1.4\n')],offs=[0],pos=parts[0].length,add=bytes=>{parts.push(bytes);pos+=bytes.length};const pageObjs=[];let obj=1;const catalog=obj++,pagesObj=obj++;pages.forEach(()=>pageObjs.push({page:obj++,content:obj++,img:obj++}));offs[catalog]=pos;add(pdfAscii(`${catalog} 0 obj\n<< /Type /Catalog /Pages ${pagesObj} 0 R >>\nendobj\n`));offs[pagesObj]=pos;add(pdfAscii(`${pagesObj} 0 obj\n<< /Type /Pages /Kids [${pageObjs.map(x=>x.page+' 0 R').join(' ')}] /Count ${pages.length} >>\nendobj\n`));const m=v57MarginValue();pageObjs.forEach((o,i)=>{const pg=pages[i],sc=Math.min((PW-m*2)/pg.w,(PH-m*2)/pg.h),iw=pg.w*sc,ih=pg.h*sc,x=(PW-iw)/2,y=(PH-ih)/2,stream=`q ${iw.toFixed(2)} 0 0 ${ih.toFixed(2)} ${x.toFixed(2)} ${(PH-y-ih).toFixed(2)} cm /Im Do Q`;offs[o.page]=pos;add(pdfAscii(`${o.page} 0 obj\n<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im ${o.img} 0 R >> >> /Contents ${o.content} 0 R >>\nendobj\n`));offs[o.content]=pos;add(pdfAscii(`${o.content} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj\n`));offs[o.img]=pos;add(pdfAscii(`${o.img} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${pg.w} /Height ${pg.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${pg.jpg.length} >>\nstream\n`));add(pg.jpg);add(pdfAscii('\nendstream\nendobj\n'))});const info=obj++;offs[info]=pos;add(pdfAscii(`${info} 0 obj\n<< /Title (${String(title||'MY LIFE OS Document').replace(/[\\()]/g,'')}) /Producer (MY LIFE OS Document Lab V57) >>\nendobj\n`));const xref=pos;let tail=`xref\n0 ${info+1}\n0000000000 65535 f \n`;for(let i=1;i<=info;i++)tail+=String(offs[i]||0).padStart(10,'0')+' 00000 n \n';tail+=`trailer\n<< /Size ${info+1} /Root ${catalog} 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF`;add(pdfAscii(tail));return new Blob(parts,{type:'application/pdf'})}
function docImageToPdf(src,name){const im=new Image();im.onload=()=>{try{const {w:PW,h:PH}=v57PageDims(),m=v57MarginValue(),max=2200,sc=Math.min(1,max/im.naturalWidth,max/im.naturalHeight),iw=Math.max(1,Math.round(im.naturalWidth*sc)),ih=Math.max(1,Math.round(im.naturalHeight*sc)),c=document.createElement('canvas');c.width=iw*2;c.height=ih*2;const ctx=c.getContext('2d',{alpha:false});ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);const aw=PW-m*2,ah=PH-m*2,fit=Math.min(aw*2/c.width,ah*2/c.height),dw=c.width*fit,dh=c.height*fit;ctx.drawImage(im,0,0,c.width,c.height,(c.width-dw)/2,(c.height-dh)/2,dw,dh);const q=window.v57PdfSettings.quality==='standard'?.90:window.v57PdfSettings.quality==='maximum'?.995:.98,blob=makeJpegPdfPages([{jpg:pdfDataUrlBytes(c.toDataURL('image/jpeg',q)),w:c.width,h:c.height}],(name||'image').replace(/\.[^.]+$/,''),window.v57PdfSettings.orientation),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(name||'image').replace(/\.[^.]+$/,'')+'.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1800);toast('IMAGE PDF CREATED ✓')}catch(e){console.error(e);toast('PDF creation failed')}};im.onerror=()=>toast('Could not read image');im.src=src}
/* Account-aware profile picture + final auth/menu bootstrap */
const oldHandleProfilePicture=window.handleProfilePicture;const oldRemoveProfilePicture=window.removeProfilePicture;window.handleProfilePicture=function(ev){const r=oldHandleProfilePicture;if(typeof r==='function')r(ev);setTimeout(syncAccountUIV57,80)};window.removeProfilePicture=function(){const r=oldRemoveProfilePicture;if(typeof r==='function')r();setTimeout(syncAccountUIV57,80)};
setTimeout(enforceAccessFlow,60);
setTimeout(syncAccountUIV57,100);



(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  /* ---- FINAL PDF ENGINE: self-contained, mobile-safe, no printer dependency. ---- */
  const P=window.v61Pdf||window.v60Pdf||{orientation:'portrait',page:'A4',margin:'normal',quality:'high',kind:'text',image:null,pageNumber:false};
  if(typeof P.pageNumber!=='boolean') P.pageNumber=false;
  window.v62Pdf=P;
  const pdfEsc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const pdfDims=()=>{let d=P.page==='A5'?{w:420,h:595}:P.page==='Letter'?{w:612,h:792}:{w:595,h:842};return P.orientation==='landscape'?{w:d.h,h:d.w}:d};
  const pdfMargin=()=>P.margin==='narrow'?30:P.margin==='wide'?80:58;
  function pdfBytes(dataUrl){const b=atob((dataUrl.split(',')[1]||'')),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a}
  function pdfAscii(str){return new TextEncoder().encode(str)}
  function makePdf(pages,title){
    const {w:PW,h:PH}=pdfDims(), parts=[pdfAscii('%PDF-1.4\n')], offsets=[0], add=b=>{parts.push(b);pos+=b.length};
    let pos=parts[0].length,obj=1; const catalog=obj++,pagesObj=obj++, pageObjs=[];
    pages.forEach(()=>pageObjs.push({page:obj++,content:obj++,img:obj++}));
    offsets[catalog]=pos;add(pdfAscii(`${catalog} 0 obj\n<< /Type /Catalog /Pages ${pagesObj} 0 R >>\nendobj\n`));
    offsets[pagesObj]=pos;add(pdfAscii(`${pagesObj} 0 obj\n<< /Type /Pages /Kids [${pageObjs.map(x=>x.page+' 0 R').join(' ')}] /Count ${pages.length} >>\nendobj\n`));
    const m=pdfMargin();
    pageObjs.forEach((o,i)=>{const pg=pages[i],scale=Math.min((PW-m*2)/pg.w,(PH-m*2)/pg.h),iw=pg.w*scale,ih=pg.h*scale,x=(PW-iw)/2,y=(PH-ih)/2,stream=`q ${iw.toFixed(2)} 0 0 ${ih.toFixed(2)} ${x.toFixed(2)} ${(PH-y-ih).toFixed(2)} cm /Im Do Q`;
      offsets[o.page]=pos;add(pdfAscii(`${o.page} 0 obj\n<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im ${o.img} 0 R >> >> /Contents ${o.content} 0 R >>\nendobj\n`));
      offsets[o.content]=pos;add(pdfAscii(`${o.content} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj\n`));
      offsets[o.img]=pos;add(pdfAscii(`${o.img} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${pg.w} /Height ${pg.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${pg.jpg.length} >>\nstream\n`));add(pg.jpg);add(pdfAscii('\nendstream\nendobj\n'));
    });
    const info=obj++;offsets[info]=pos;add(pdfAscii(`${info} 0 obj\n<< /Title (${String(title||'MY LIFE OS Document').replace(/[()\\]/g,'')}) /Producer (MY LIFE OS Document Lab) >>\nendobj\n`));
    const xref=pos;let tail=`xref\n0 ${info+1}\n0000000000 65535 f \n`;for(let i=1;i<=info;i++)tail+=String(offsets[i]||0).padStart(10,'0')+' 00000 n \n';tail+=`trailer\n<< /Size ${info+1} /Root ${catalog} 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF`;add(pdfAscii(tail));return new Blob(parts,{type:'application/pdf'});
  }
  function saveBlob(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),3000)}
  function buildTextPdf(title,text){
    const {w:W,h:H}=pdfDims(),m=pdfMargin(),scale=2, body=P.orientation==='landscape'?14:16, titleSize=P.orientation==='landscape'?24:27, lineH=P.orientation==='landscape'?22:25;
    const c0=document.createElement('canvas'),ctx0=c0.getContext('2d');ctx0.font=`${body}px Arial,"Noto Sans Bengali","Noto Sans Devanagari",sans-serif`;const maxW=W-m*2,lines=[];
    for(const raw of String(text||'').split(/\r?\n/)){if(!raw){lines.push('');continue}let cur='';for(const ch of raw){const t=cur+ch;if(cur&&ctx0.measureText(t).width>maxW){lines.push(cur);cur=ch}else cur=t}lines.push(cur)}
    const pages=[];let i=0,pageNo=1;while(i<lines.length||!pages.length){
      const c=document.createElement('canvas');c.width=Math.round(W*scale);c.height=Math.round(H*scale);
      const x=c.getContext('2d',{alpha:false});x.scale(scale,scale);x.fillStyle='#fff';x.fillRect(0,0,W,H);x.fillStyle='#111';
      if(pageNo===1){
        x.font=`bold ${titleSize}px Arial,"Noto Sans Bengali","Noto Sans Devanagari",sans-serif`;
        x.fillText(title||'MY LIFE OS Document',m,m+titleSize);
      }
      x.font=`${body}px Arial,"Noto Sans Bengali","Noto Sans Devanagari",sans-serif`;
      let y=pageNo===1?m+titleSize+22:m;
      while(i<lines.length&&y<=H-m-20){x.fillText(lines[i],m,y);y+=lineH;i++}
      if(P.pageNumber){
        x.save();x.font='11px Arial,sans-serif';x.fillStyle='#555';x.textAlign='right';x.textBaseline='top';x.fillText(String(pageNo),W-m,10);x.restore();
      }
      pages.push({jpg:pdfBytes(c.toDataURL('image/jpeg',.96)),w:c.width,h:c.height});pageNo++;
    }
    return makePdf(pages,title)
  }
  function buildImagePdf(src,title){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>{try{const {w:PW,h:PH}=pdfDims(),m=pdfMargin(),scale=2,maxW=(PW-m*2)*scale,maxH=(PH-m*2)*scale,fit=Math.min(maxW/im.naturalWidth,maxH/im.naturalHeight),iw=Math.max(1,Math.round(im.naturalWidth*fit)),ih=Math.max(1,Math.round(im.naturalHeight*fit)),c=document.createElement('canvas');c.width=Math.round(PW*scale);c.height=Math.round(PH*scale);const x=c.getContext('2d',{alpha:false});x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);const dx=(c.width-iw)/2,dy=(c.height-ih)/2;x.drawImage(im,0,0,im.naturalWidth,im.naturalHeight,dx,dy,iw,ih);if(P.pageNumber){x.save();x.font='22px Arial,sans-serif';x.fillStyle='#555';x.textAlign='right';x.textBaseline='top';x.fillText('1',(PW-m)*scale,18*scale);x.restore()}resolve(makePdf([{jpg:pdfBytes(c.toDataURL('image/jpeg',.97)),w:c.width,h:c.height}],title));}catch(e){reject(e)}};im.onerror=()=>reject(new Error('Could not read image'));im.src=src})}
  function pdfChooser(type){
    const options=type==='orientation'?[['portrait','Portrait'],['landscape','Landscape']]:type==='page'?[['A4','A4'],['A5','A5'],['Letter','Letter']]:type==='pageNumber'?[['add','Add'],['remove','Remove']]:[['normal','Normal'],['narrow','Narrow'],['wide','Wide']];
    const title=type==='orientation'?'Paper orientation':type==='page'?'Paper size':type==='pageNumber'?'Page number':'Page margins';
    const wrap=document.createElement('div');wrap.className='v62PdfChooser';wrap.innerHTML='<div class="v62PdfChooserCard"><div class="v62PdfChooserTitle">'+title+'</div>'+options.map(o=>'<button type="button" data-v62-choice="'+o[0]+'">'+o[1]+'<span>›</span></button>').join('')+'<button type="button" class="cancel" data-v62-choice="__cancel">Cancel</button></div>';
    document.body.appendChild(wrap);wrap.querySelectorAll('[data-v62-choice]').forEach(b=>b.onclick=()=>{const v=b.dataset.v62Choice;wrap.remove();if(v==='__cancel')return;if(type==='pageNumber')P.pageNumber=v==='add';else P[type]=v;renderPdf(P.kind)});
  }
  function renderPdf(kind){
    P.kind=kind;const modal=$('modal'),card=$('modalCard');if(!modal||!card)return;const land=P.orientation==='landscape';let content='';
    if(kind==='image'&&P.image)content='<img src="'+pdfEsc(P.image)+'" alt="Image preview">';
    else if(kind==='text'){const title=(($('docTitle')?.value||'Untitled Document').trim()||'Untitled Document'),text=$('docEditor')?.value||'';content='<h3>'+pdfEsc(title)+'</h3><pre>'+pdfEsc(text||'Start writing here...')+'</pre>'}
    else content='<div style="display:grid;place-items:center;min-height:360px;color:#6b6f76;font-size:14px">Choose an image to preview</div>';
    const orientationLabel=P.orientation==='landscape'?'Landscape':'Portrait';
    const pageNumberLabel=P.pageNumber?'Add':'Remove';
    card.innerHTML='<div class="pdfNative"><div class="pdfNativeTop"><button type="button" id="v62PdfCancel">Cancel</button><b>Save as PDF</b><span style="width:55px"></span></div><div class="pdfNativeBody"><div class="pdfNativePage '+(land?'landscape':'')+'"><div class="pdfNativePageContent">'+content+'</div></div></div><div class="pdfNativeSettings"><div class="pdfNativeSettingsGrid"><button type="button" class="pdfNativeSetting" id="v62Orientation"><div><small>Paper orientation</small><b>'+orientationLabel+'</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v62Page"><div><small>Paper size</small><b>'+pdfEsc(P.page)+'</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v62Margin"><div><small>Page margins</small><b>'+pdfEsc(P.margin.charAt(0).toUpperCase()+P.margin.slice(1))+'</b></div><span>›</span></button><button type="button" class="pdfNativeSetting" id="v62PageNumber"><div><small>Page number</small><b>'+pageNumberLabel+'</b></div><span>›</span></button></div>'+(kind==='image'&&!P.image?'<button type="button" class="pdfNativeChoose" id="v62Choose">Choose image</button>':'')+'<button type="button" class="pdfNativeSave" id="v62Save">Save as PDF</button></div></div>';
    modal.classList.add('open','pdfNativeOpen');$('v62PdfCancel').onclick=closePdf;$('v62Orientation').onclick=()=>pdfChooser('orientation');$('v62Page').onclick=()=>pdfChooser('page');$('v62Margin').onclick=()=>pdfChooser('margin');$('v62PageNumber').onclick=()=>pdfChooser('pageNumber');$('v62Choose')?.addEventListener('click',()=>$('docPdfImageInput')?.click());$('v62Save').onclick=savePdf;
  }
  function closePdf(){$('modal')?.classList.remove('open','pdfNativeOpen')}
  async function savePdf(){
    const title=(($('docTitle')?.value||'Document').trim()||'Document');if(P.kind==='image'&&!P.image){alert('Choose an image first.');return}
    const btn=$('v62Save');if(btn){btn.disabled=true;btn.textContent='Creating PDF…'}
    try{const blob=P.kind==='image'?await buildImagePdf(P.image,title):buildTextPdf(title,$('docEditor')?.value||'');closePdf();saveBlob(blob,title.replace(/[\\/:*?"<>|]+/g,'_')+'.pdf');toast(P.kind==='image'?'IMAGE PDF CREATED ✓':'PDF CREATED ✓')}
    catch(err){console.error('V62 PDF error',err);if(btn){btn.disabled=false;btn.textContent='Save as PDF'}alert('PDF creation failed. Please try again.')}
  }
  window.docPrint=()=>{P.kind='text';P.image=null;renderPdf('text')};
  window.docPickImagePdf=()=>{P.kind='image';P.image=null;renderPdf('image')};
  window.v59PdfSettingsModal=kind=>{P.kind=kind;renderPdf(kind)};
  window.v59PdfClose=closePdf;
  window.v59PdfSet=(k,v)=>{P[k]=v;renderPdf(P.kind)};
  window.v59PdfCycle=k=>pdfChooser(k);
  window.v59ChoosePdfImage=()=>$('docPdfImageInput')?.click();
  window.docImageLoaded=function(ev,toPdf){const f=ev?.target?.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{if(toPdf){P.image=r.result;P.kind='image';renderPdf('image')}else if(typeof window.__v60OldDocImageLoaded==='function')window.__v60OldDocImageLoaded(ev,false)};r.onerror=()=>alert('Could not read image.');r.readAsDataURL(f);if(ev.target)ev.target.value=''};

  /* ---- FINAL MENU: physical scroll lock + sidebar-only scrolling. ---- */
  let menuY=0;
  window.closeMenu=function(){
    const s=$('sidebar'),scr=$('menuScrim');
    s?.classList.remove('open');scr?.classList.remove('show');
    document.documentElement.classList.remove('v62MenuOpen');document.body.classList.remove('v62MenuOpen');
    document.body.style.position='';document.body.style.top='';document.body.style.left='';document.body.style.right='';document.body.style.width='';
    if(document.body.classList.contains('v61MenuOpen')||document.body.classList.contains('v62MenuOpen'))window.scrollTo(0,menuY);s?.removeAttribute('aria-modal');
  };
  window.toggleMenu=function(){
    const s=$('sidebar'),scr=$('menuScrim');if(!s)return;
    if(s.classList.contains('open')){window.closeMenu();return;}
    menuY=window.scrollY||document.documentElement.scrollTop||0;
    document.documentElement.classList.add('v62MenuOpen');document.body.classList.add('v62MenuOpen');
    document.body.style.position='fixed';document.body.style.top=(-menuY)+'px';document.body.style.left='0';document.body.style.right='0';document.body.style.width='100%';
    s.classList.add('open');scr?.classList.add('show');s.setAttribute('aria-modal','true');
  };
  document.addEventListener('touchmove',function(e){if(!document.body.classList.contains('v62MenuOpen'))return;const s=$('sidebar');if(s&&s.contains(e.target))return;e.preventDefault();},{passive:false});
  document.addEventListener('wheel',function(e){if(document.body.classList.contains('v62MenuOpen')){const s=$('sidebar');if(s&&s.contains(e.target))return;e.preventDefault();}},{passive:false});
  document.addEventListener('click',function(e){const s=$('sidebar'),scr=$('menuScrim');if(s?.classList.contains('open')&&e.target===scr)window.closeMenu();});
  /* Account card stays first and always reflects the current profile photo. */
  window.syncAccountUIV57=function(){
    const side=$('sidebar'),box=$('sidebarAccount');if(!side||!box)return;
    const email=localStorage.getItem('myLifeOS_active_account_v57')||'';let db={};try{db=JSON.parse(localStorage.getItem('myLifeOS_accounts_v57')||'{}')}catch(e){}
    const a=email?db[email]:null;
    const pic=state?.settings?.profilePicture||a?.state?.settings?.profilePicture||a?.profile?.profilePicture||'';
    const name=state?.settings?.name||a?.profile?.name||'STUDENT';
    const cls=state?.settings?.studentClass||a?.profile?.studentClass||'Student Account';
    box.innerHTML=(pic?'<img class="sideAvatar" src="'+escH(pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+'<div class="sideInfo"><b>'+escH(name)+'</b><small>'+escH(cls)+'</small></div>'+'<button type="button" class="profileSideLogout" aria-label="Log out">LOG OUT</button>';
    const btn=box.querySelector('.profileSideLogout');
    if(btn)btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();window.logoutAccount?.();});
    const brand=side.querySelector('.brand');
    if(brand)brand.insertAdjacentElement('afterend',box);else side.insertBefore(box,side.firstElementChild||null);
  };
  setTimeout(()=>window.syncAccountUIV57?.(),100);
})();


(function(){
'use strict';
/* MY LIFE OS V4 — device-first IndexedDB storage + resilient auth/opening runtime. */
const ACCOUNT_DB='MY_LIFE_OS_DEVICE_DB_V4';
const ACCOUNT_STORE='accounts';
const META_STORE='meta';
const LEGACY_ACCOUNT_KEY='mlo_publish_accounts_v3';
const LEGACY_ACTIVE_KEY='mlo_publish_active_v3';
const INSTALL_KEY='mlo_publish_clean_install_v4';
const $=id=>document.getElementById(id);
const clone=x=>JSON.parse(JSON.stringify(x));
const esc=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
let idb=null, idbReady=false, dbCache={}, activeCache='', pendingEmail='', pendingPic='', cap='';
const SESSION_KEY='MLO_SESSION_V4';
let accountWriteQueue=Promise.resolve();
let currentPixelProject=null, docsCache=[];
window.__mloIDBReady=false; window.__mloDocsCache=docsCache; window.__mloPixelProjectCache=null;
function uuid(){try{return crypto.randomUUID()}catch(e){return 'mlo-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2)}}
function fallbackHash(text){let h1=0x811c9dc5,h2=0x01000193;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);h1^=c;h1=Math.imul(h1,16777619);h2^=c+31;h2=Math.imul(h2,16777619)}return (h1>>>0).toString(16).padStart(8,'0')+(h2>>>0).toString(16).padStart(8,'0')}
async function hashPassword(p,s){try{if(crypto?.subtle){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(p),{name:'PBKDF2'},false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(s),iterations:150000,hash:'SHA-256'},key,256);return 'pbkdf2:'+[...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}return 'fallback:'+fallbackHash(s+'|'+p+'|MYLIFEOSV4')}
function openDB(){return new Promise((resolve,reject)=>{try{if(!window.indexedDB)return reject(new Error('IndexedDB unavailable'));const req=indexedDB.open(ACCOUNT_DB,1);req.onupgradeneeded=e=>{const d=e.target.result;if(!d.objectStoreNames.contains(ACCOUNT_STORE))d.createObjectStore(ACCOUNT_STORE,{keyPath:'email'});if(!d.objectStoreNames.contains(META_STORE))d.createObjectStore(META_STORE,{keyPath:'key'})};req.onsuccess=e=>{idb=e.target.result;idb.onversionchange=()=>idb.close();resolve(idb)};req.onerror=()=>reject(req.error||new Error('IndexedDB open failed'))}catch(e){reject(e)}})}
function idbGetAll(){return new Promise((resolve,reject)=>{if(!idb)return reject(new Error('No DB'));const r=idb.transaction(ACCOUNT_STORE,'readonly').objectStore(ACCOUNT_STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error)})}
function idbPutAccount(a){return new Promise((resolve,reject)=>{if(!idb)return reject(new Error('No DB'));const r=idb.transaction(ACCOUNT_STORE,'readwrite').objectStore(ACCOUNT_STORE).put(a);r.onsuccess=()=>resolve(true);r.onerror=()=>reject(r.error)})}
function queueAccountWrite(a){const copy=clone(a);accountWriteQueue=accountWriteQueue.catch(()=>{}).then(()=>idbPutAccount(copy));return accountWriteQueue;}
function idbPutMeta(key,value){return new Promise((resolve,reject)=>{if(!idb)return reject(new Error('No DB'));const r=idb.transaction(META_STORE,'readwrite').objectStore(META_STORE).put({key,value});r.onsuccess=()=>resolve(true);r.onerror=()=>reject(r.error)})}
function idbGetMeta(key){return new Promise((resolve,reject)=>{if(!idb)return reject(new Error('No DB'));const r=idb.transaction(META_STORE,'readonly').objectStore(META_STORE).get(key);r.onsuccess=()=>resolve(r.result?.value??'');r.onerror=()=>reject(r.error)})}
function legacyReadDB(){try{return JSON.parse(localStorage.getItem(LEGACY_ACCOUNT_KEY)||'{}')}catch(e){return {}}}
function legacyWriteDB(v){try{localStorage.setItem(LEGACY_ACCOUNT_KEY,JSON.stringify(v))}catch(e){}}
function legacyActive(){try{return localStorage.getItem(LEGACY_ACTIVE_KEY)||''}catch(e){return ''}}
function legacyClear(){try{Object.keys(localStorage).forEach(k=>{if(/^myLifeOS_/i.test(k)||/^MY_LIFE_OS/i.test(k)||/^mlo_publish_/i.test(k))localStorage.removeItem(k)});Object.keys(sessionStorage).forEach(k=>{if(/^myLifeOS_/i.test(k)||/^MY_LIFE_OS/i.test(k)||/^mlo_publish_/i.test(k))sessionStorage.removeItem(k)})}catch(e){}}
function idbClearAll(){return new Promise((resolve,reject)=>{try{if(!idb)return resolve(false);const tx=idb.transaction([ACCOUNT_STORE,META_STORE],'readwrite');tx.objectStore(ACCOUNT_STORE).clear();tx.objectStore(META_STORE).clear();tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('Storage reset failed'))}catch(e){reject(e)}})}
async function freshInstallOnce(){const mark='MLO_V8_FRESH_INSTALL_DONE_LOCKED_FINAL';try{if(localStorage.getItem(mark)==='1')return false}catch(e){}try{legacyClear()}catch(e){}try{await idbClearAll()}catch(e){}dbCache={};activeCache='';try{localStorage.removeItem(SESSION_KEY)}catch(e){}try{localStorage.setItem(mark,'1')}catch(e){}return true}
async function migrateLegacyIfNeeded(){if(!idb)return;let all=await idbGetAll();if(all.length)return;let old=legacyReadDB();let entries=Object.values(old||{});if(entries.length){for(const a of entries){if(a?.email)await idbPutAccount(a)}dbCache={};for(const a of await idbGetAll())dbCache[a.email]=a;try{localStorage.removeItem(LEGACY_ACCOUNT_KEY)}catch(e){}return}dbCache={}}
async function initStorage(){try{await openDB();await migrateLegacyIfNeeded();for(const a of await idbGetAll())dbCache[a.email]=a;activeCache=await idbGetMeta('active')||'';if(!activeCache){try{activeCache=localStorage.getItem(SESSION_KEY)||''}catch(e){}}idbReady=true;window.__mloIDBReady=true;return 'idb'}catch(e){console.warn('IndexedDB unavailable, using emergency browser fallback:',e);idbReady=false;window.__mloIDBReady=false;try{dbCache=legacyReadDB()}catch(x){dbCache={}}try{activeCache=legacyActive()}catch(x){activeCache=''}return 'fallback'}}
function readDB(){return dbCache||{}}
function writeDB(v){dbCache=v||{};if(idbReady){Object.values(dbCache).forEach(a=>queueAccountWrite(a).catch(()=>{}))}else{legacyWriteDB(dbCache)}}
function active(){return activeCache||''}
function setActive(v){activeCache=v||'';let token='';try{if(activeCache&&dbCache[activeCache]){token=dbCache[activeCache].sessionToken||uuid();dbCache[activeCache].sessionToken=token;queueAccountWrite(dbCache[activeCache]).catch(()=>{});}}catch(e){}if(idbReady)idbPutMeta('active',activeCache).catch(()=>{});try{if(token)localStorage.setItem(SESSION_KEY,token);else localStorage.removeItem(SESSION_KEY)}catch(e){}if(!idbReady)try{localStorage.setItem(LEGACY_ACTIVE_KEY,activeCache)}catch(e){}}
function clearActive(){activeCache='';if(idbReady)idbPutMeta('active','').catch(()=>{});try{localStorage.removeItem(SESSION_KEY)}catch(e){}if(!idbReady)try{localStorage.removeItem(LEGACY_ACTIVE_KEY)}catch(e){}}
function freshState(){return clone(defaultState)}
function lock(){document.body.classList.add('mloPublishLocked');document.body.classList.remove('mloPublishReady','mloAuthLocked','authLocked','v61Ready');$('mloPublishGate')?.setAttribute('aria-hidden','false')}
function unlock(){document.body.classList.remove('mloPublishLocked','mloAuthLocked','authLocked');document.body.classList.add('mloPublishReady','v61Ready');$('mloPublishGate')?.setAttribute('aria-hidden','true')}
function makeLoginCaptcha(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';cap=Array.from({length:6},()=>chars[Math.floor(Math.random()*chars.length)]).join('');if($('pubCaptchaCode'))$('pubCaptchaCode').textContent=cap;if($('pubCaptchaInput'))$('pubCaptchaInput').value=''}
function makeCreateCaptcha(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';window.pubCreateCap=Array.from({length:6},()=>chars[Math.floor(Math.random()*chars.length)]).join('');if($('pubCreateCaptchaCode'))$('pubCreateCaptchaCode').textContent=window.pubCreateCap;if($('pubCreateCaptchaInput'))$('pubCreateCaptchaInput').value=''}
function makeVerifyCaptcha(){window.pubVerifyCodeValue=String(Math.floor(100000+Math.random()*900000));if($('pubVerifyCode'))$('pubVerifyCode').textContent=window.pubVerifyCodeValue;if($('pubVerifyInput'))$('pubVerifyInput').value=''}
function progress(n){const i=$('mloPubProgress')?.querySelector('i');if(i)i.style.width=Math.min(100,n*33.333)+'%'}
function showStep(id){document.querySelectorAll('.mloPubStep').forEach(e=>e.classList.toggle('active',e.id===id));progress(id==='pubLogin'||id==='pubCreate'?1:id==='pubProfile'?2:3);if(id==='pubCreate')setTimeout(makeCreateCaptcha,30);if(id==='pubLogin')setTimeout(makeLoginCaptcha,30)}
function clearErrors(){['pubLoginError','pubCreateError','pubProfileError','pubVerifyError'].forEach(id=>{if($(id))$(id).textContent=''})}
function gate(){if($('mloPublishGate'))return;const g=document.createElement('div');g.id='mloPublishGate';g.setAttribute('aria-hidden','false');g.innerHTML=`<div class="mloPublishCard"><div class="mloPublishBrand"><div class="mloPublishLogo">✦</div><div><b>MY LIFE OS</b><small>STUDENT COMMAND CENTER</small></div></div><div class="mloPubProgress" id="mloPubProgress"><i></i></div>
<section class="mloPubStep active" id="pubLogin"><span class="mloPubEyebrow">WELCOME BACK</span><h1 class="mloPubTitle">Enter <em>MY LIFE OS</em></h1><p class="mloPubSub">Sign in with the student account saved on this device.</p><div class="mloPubForm"><label class="mloPubLabel">Email address<input class="mloPubInput" id="pubLoginEmail" type="email" autocomplete="username" placeholder="student@example.com"></label><label class="mloPubLabel">Password<input class="mloPubInput" id="pubLoginPassword" type="password" autocomplete="current-password" placeholder="Enter your password"></label><div class="mloCaptcha"><div class="mloCaptchaTop"><span>SECURITY CAPTCHA</span><button class="mloCaptchaRefresh" id="pubCaptchaRefresh" type="button">↻</button></div><div class="mloCaptchaCode" id="pubCaptchaCode">------</div><input class="mloPubInput" id="pubCaptchaInput" autocomplete="off" placeholder="Enter the code above"></div><div class="mloPubError" id="pubLoginError"></div><button class="mloPubBtn" id="pubLoginBtn" type="button">ENTER MY LIFE OS →</button><button class="mloPubBtn secondary" id="pubCreateBtn" type="button">＋ Create new student account</button></div><div class="mloPubHint">🔐 Account and workspace data stay on this device. Logout does not delete the account.</div></section>
<section class="mloPubStep" id="pubCreate"><span class="mloPubEyebrow">FIRST-TIME ACCOUNT</span><h1 class="mloPubTitle">Create your <em>Student Account</em></h1><p class="mloPubSub">First create the account. Your student profile comes next.</p><div class="mloPubForm"><label class="mloPubLabel">Email address<input class="mloPubInput" id="pubCreateEmail" type="email" autocomplete="email" placeholder="student@example.com"></label><label class="mloPubLabel">Password<input class="mloPubInput" id="pubCreatePassword" type="password" autocomplete="new-password" placeholder="Create a password"></label><label class="mloPubLabel">Re-enter password<input class="mloPubInput" id="pubCreatePassword2" type="password" autocomplete="new-password" placeholder="Re-enter password"></label><div class="mloCaptcha"><div class="mloCaptchaTop"><span>SECURITY CAPTCHA</span><button class="mloCaptchaRefresh" id="pubCreateCaptchaRefresh" type="button">↻</button></div><div class="mloCaptchaCode" id="pubCreateCaptchaCode">------</div><input class="mloPubInput" id="pubCreateCaptchaInput" autocomplete="off" placeholder="Enter the code above"></div><div class="mloPubError" id="pubCreateError"></div><button class="mloPubBtn" id="pubCreateNext" type="button">CREATE ACCOUNT →</button><button class="mloPubLink" id="pubBackLogin" type="button">← Back to login</button></div></section>
<section class="mloPubStep" id="pubProfile"><span class="mloPubEyebrow">STUDENT PROFILE</span><h1 class="mloPubTitle">Make it <em>yours.</em></h1><p class="mloPubSub">Add your name, choose your study path, and MY LIFE OS will personalize only the Study Hub for you.</p><div class="mloProfileRowPub"><div class="mloPicPub" id="pubPicPreview"><span>＋</span><input id="pubPicInput" type="file" accept="image/*"></div><div><b>Profile picture</b><div class="mloMiniPub">Saved to this account on this device.</div></div></div><div class="mloPubForm"><label class="mloPubLabel">Student name<input class="mloPubInput" id="pubName" placeholder="Enter student name"></label><div class="mloPubLabel">Select Your Study Level<button type="button" class="mloLevelLauncher" id="pubLevelLauncher" onclick="toggleStudyLevelPicker()"><div><b id="pubLevelLabel">Choose your class / study path</b><span>Tap to open classes, preparation & professional paths</span></div><i id="pubLevelArrow">⌄</i></button><div class="mloLevelPicker" id="pubLevelPicker"><div class="mloLevelSection"><div class="mloLevelSectionTitle">SCHOOL • CLASS</div><div class="mloChoiceGrid">${['Class 6','Class 7','Class 8','Class 9','Class 10','Class 11','Class 12'].map(x=>`<button type="button" class="mloChoiceBtn" data-study-path="${x}" onclick="selectStudyPath('${x}')"><b>${x}</b><span>Personalized subjects & notes</span></button>`).join('')}</div></div><div class="mloLevelSection"><div class="mloLevelSectionTitle">COMPETITIVE PREPARATION</div><div class="mloChoiceGrid"><button type="button" class="mloChoiceBtn" data-study-path="Competitive Preparation" onclick="selectStudyPath('Competitive Preparation')"><b>🎯 Competitive Preparation</b><span>Tap → choose JEE, NEET, WBJEE or Other</span></button><button type="button" class="mloChoiceBtn" data-study-path="Engineering / Technical" onclick="selectStudyPath('Engineering / Technical')"><b>💻 Engineering / Technical</b><span>Coding • Technical • Engineering</span></button></div></div><div class="mloLevelSection"><div class="mloLevelSectionTitle">OTHER</div><div class="mloChoiceGrid"><button type="button" class="mloChoiceBtn" data-study-path="Other" onclick="selectStudyPath('Other')"><b>📚 Other</b><span>Create your own study path</span></button></div></div></div><input id="pubClass" type="hidden"><div class="mloSubPicker" id="pubCompetitivePicker"><div class="mloMiniPub" style="margin-bottom:6px">Choose Your Competitive Preparation</div><div class="mloSubGrid"><button type="button" class="mloSubBtn" data-prep="JEE" onclick="selectPrep('JEE')"><b>🎯 JEE</b><span>Engineering entrance • Physics • Chemistry • Mathematics</span></button><button type="button" class="mloSubBtn" data-prep="NEET" onclick="selectPrep('NEET')"><b>🩺 NEET</b><span>Medical entrance • Physics • Chemistry • Biology</span></button><button type="button" class="mloSubBtn" data-prep="WBJEE" onclick="selectPrep('WBJEE')"><b>📘 WBJEE</b><span>West Bengal entrance • Mathematics • Physics • Chemistry</span></button><button type="button" class="mloSubBtn" data-prep="Other" onclick="selectPrep('Other')"><b>Other</b><span>Custom preparation</span></button></div></div><div class="mloStreamWrap" id="pubStreamWrap"><div class="mloMiniPub" style="margin-bottom:6px">Choose Your Stream</div><div class="mloStreamGrid"><button type="button" class="mloStreamBtn" data-stream="Science" onclick="selectStudyStream('Science')">🔬 Science</button><button type="button" class="mloStreamBtn" data-stream="Commerce" onclick="selectStudyStream('Commerce')">💼 Commerce</button><button type="button" class="mloStreamBtn" data-stream="Arts" onclick="selectStudyStream('Arts')">🎨 Arts / Humanities</button><button type="button" class="mloStreamBtn" data-stream="Other" onclick="selectStudyStream('Other')">🔄 Other</button></div></div><div class="mloAdaptiveHint" id="pubAdaptiveHint">Select your class or study path. MY LIFE OS will personalize only the Study Hub.</div></div><label class="mloPubLabel">Section <span class="mloMiniPub">(optional)</span><input class="mloPubInput" id="pubSection" placeholder="e.g. A"></label><div class="mloPubError" id="pubProfileError"></div><button class="mloPubBtn" id="pubProfileNext" type="button">CONTINUE →</button><button class="mloPubLink" id="pubBackCreate" type="button">← Back</button></div></section>
<section class="mloPubStep" id="pubVerify"><span class="mloPubEyebrow">MAIN VERIFICATION</span><h1 class="mloPubTitle">Final <em>verification.</em></h1><p class="mloPubSub">Enter the one-time code shown below, then MY LIFE OS will securely open.</p><div class="mloCaptcha"><div class="mloCaptchaTop"><span>VERIFICATION CODE</span><button class="mloCaptchaRefresh" id="pubVerifyRefresh" type="button">↻</button></div><div class="mloCaptchaCode" id="pubVerifyCode">------</div><input class="mloPubInput" id="pubVerifyInput" inputmode="numeric" maxlength="6" placeholder="Enter 6 digits"></div><div class="mloPubError" id="pubVerifyError"></div><button class="mloPubBtn" id="pubVerifyBtn" type="button">VERIFY & OPEN MY LIFE OS →</button><button class="mloPubLink" id="pubBackProfile" type="button">← Back</button></section></div>`;document.body.appendChild(g);bind();}
function bind(){
 $('pubLoginBtn').onclick=login;$('pubCreateBtn').onclick=()=>{clearErrors();showStep('pubCreate')};$('pubBackLogin').onclick=()=>{clearErrors();showStep('pubLogin')};$('pubCreateNext').onclick=create;$('pubProfileNext').onclick=profileNext;$('pubBackCreate').onclick=()=>{clearErrors();showStep('pubCreate')};$('pubVerifyBtn').onclick=verify;$('pubBackProfile').onclick=()=>{clearErrors();showStep('pubProfile')};$('pubCaptchaRefresh').onclick=makeLoginCaptcha;$('pubCreateCaptchaRefresh').onclick=makeCreateCaptcha;$('pubVerifyRefresh').onclick=makeVerifyCaptcha;$('pubPicInput').onchange=previewPic;
 $('pubVerifyInput').addEventListener('input',e=>e.target.value=e.target.value.replace(/\D/g,''));
 ['pubLoginEmail','pubLoginPassword','pubCaptchaInput'].forEach(id=>$(id)?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();login()}}));
 ['pubCreateEmail','pubCreatePassword','pubCreatePassword2','pubCreateCaptchaInput'].forEach(id=>$(id)?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();create()}}));
 makeLoginCaptcha();makeCreateCaptcha();
}
function previewPic(e){const f=e.target.files?.[0];if(!f)return;if(f.size>5*1024*1024){$('pubProfileError').textContent='Profile picture must be under 5 MB.';e.target.value='';return}const r=new FileReader();r.onload=()=>{pendingPic=r.result;if($('pubPicPreview'))$('pubPicPreview').innerHTML='<img src="'+esc(r.result)+'" style="width:100%;height:100%;object-fit:cover" alt="Profile"><input id="pubPicInput" type="file" accept="image/*">';$('pubPicInput').onchange=previewPic};r.onerror=()=>{$('pubProfileError').textContent='Could not read that picture. Please choose another image.'};r.readAsDataURL(f)}
async function create(){try{const e=($('pubCreateEmail')?.value||'').trim().toLowerCase(),p=$('pubCreatePassword')?.value||'',p2=$('pubCreatePassword2')?.value||'',c=($('pubCreateCaptchaInput')?.value||'').trim().toUpperCase(),d=readDB();clearErrors();if(!/^\S+@\S+\.\S+$/.test(e))return $('pubCreateError').textContent='Please enter a valid email address.';if(p.length<6)return $('pubCreateError').textContent='Password must be at least 6 characters.';if(p!==p2)return $('pubCreateError').textContent='Passwords do not match.';if(c!==String(window.pubCreateCap||'').toUpperCase())return $('pubCreateError').textContent='CAPTCHA is incorrect. Please try again.';if(d[e])return $('pubCreateError').textContent='This email already has an account. Please use Login.';const salt=uuid(),a={email:e,passwordHash:await hashPassword(p,salt),salt,profile:null,state:null,documents:[],appStorage:{},createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};d[e]=a;writeDB(d);if(idbReady)await idbPutAccount(a);pendingEmail=e;pendingPic='';window.pubStudyStream='';window.pubStudyPrep='';$('pubPicPreview').innerHTML='<span>＋</span><input id="pubPicInput" type="file" accept="image/*">';$('pubPicInput').onchange=previewPic;$('pubName').value='';$('pubClass').value='';$('pubSection').value='';showStep('pubProfile')}catch(err){console.error(err);$('pubCreateError').textContent='Account could not be created. Please try again.'}}
function adaptiveSubjects(path,stream){const p=String(path||'').toLowerCase(),st=String(stream||'').toLowerCase();if(p==='competitive preparation'){if(st==='neet')return ['Physics','Chemistry','Biology','NEET Preparation','Formula Notes','Important Questions','Mock Tests','Revision'];if(st==='wbjee')return ['Mathematics','Physics','Chemistry','WBJEE Preparation','Formula Notes','Important Questions','Mock Tests','Revision'];if(st==='other')return ['Mathematics','Physics','Chemistry','Competitive Preparation','Formula Notes','Important Questions','Mock Tests','Revision'];return ['Mathematics','Physics','Chemistry','JEE Preparation','Formula Notes','Important Questions','Mock Tests','Revision']}if(p==='engineering / technical'){return ['Mathematics','Physics','Chemistry','Engineering Preparation','Technical Notes','Important Questions','Revision']}if(p==='class 11'||p==='class 12'){if(st==='science')return ['Physics','Chemistry','Mathematics','Biology','English','Bengali'];if(st==='commerce')return ['Accountancy','Business Studies','Economics','Mathematics','English'];if(st==='arts')return ['History','Geography','Political Science','Economics','Bengali','English'];return ['English','Bengali','Mathematics','Custom Subject']}const map={"class 6":['Bengali','English','Mathematics','Physical Science','Life Science','History','Geography'],"class 7":['Bengali','English','Mathematics','Physical Science','Life Science','History','Geography'],"class 8":['Bengali','English','Mathematics','Physical Science','Life Science','History','Geography'],"class 9":['Bengali','English','Mathematics','Physical Science','Life Science','History','Geography'],"class 10":['Bengali','English','Mathematics','Physical Science','Life Science','History','Geography']};return map[p]||['English','Mathematics','Custom Subject']}
function applyAdaptiveStudy(path,stream){
  const resolvedPath=String(path||state.settings?.studentStudyPath||state.settings?.studentClass||'').trim();
  const resolvedStream=String(stream||state.settings?.studentStream||'').trim();
  const names=adaptiveSubjects(resolvedPath,resolvedStream);
  const old=Array.isArray(state.study)?state.study:[];
  state.study=names.map(name=>{
    const hit=old.find(x=>x&&x.name===name);
    return hit?hit:{name,progress:0,hours:0,chapters:[],notes:'',questions:'',revision:''};
  });
  state.settings.studentStudyPath=resolvedPath;
  state.settings.studentStream=resolvedStream;
  state.settings.studySubjects=names.slice();
}
function toggleStudyLevelPicker(){const p=$('pubLevelPicker'),a=$('pubLevelArrow');if(!p)return;p.classList.toggle('show');if(a)a.textContent=p.classList.contains('show')?'⌃':'⌄'}
function selectStudyPath(path){$('pubClass').value=path;document.querySelectorAll('.mloChoiceBtn').forEach(b=>b.classList.toggle('active',b.dataset.studyPath===path));if($('pubLevelLabel'))$('pubLevelLabel').textContent=path;const wrap=$('pubStreamWrap'),cp=$('pubCompetitivePicker');if(wrap)wrap.classList.toggle('show',path==='Class 11'||path==='Class 12');if(cp)cp.classList.toggle('show',path==='Competitive Preparation');window.pubStudyPrep=path==='Competitive Preparation'?(window.pubStudyPrep||''):'';document.querySelectorAll('.mloSubBtn').forEach(b=>b.classList.toggle('active',b.dataset.prep===window.pubStudyPrep));if(path!=='Class 11'&&path!=='Class 12')window.pubStudyStream='';document.querySelectorAll('.mloStreamBtn').forEach(b=>b.classList.toggle('active',b.dataset.stream===window.pubStudyStream));if($('pubAdaptiveHint'))$('pubAdaptiveHint').textContent=path==='Class 11'||path==='Class 12'?'Choose Science, Commerce, Arts / Humanities or Other. Only the Study Hub subjects will change.':path==='Competitive Preparation'?'Choose JEE, NEET, WBJEE or Other. The Study Hub will use preparation-focused subjects.':path==='Engineering / Technical'?'Engineering / Technical mode selected. The Study Hub will use technical preparation subjects.':'The Study Hub will use the subjects for '+path+'. All other MY LIFE OS sections remain unchanged.'}
function selectStudyStream(stream){window.pubStudyStream=stream;document.querySelectorAll('.mloStreamBtn').forEach(b=>b.classList.toggle('active',b.dataset.stream===stream));if($('pubAdaptiveHint'))$('pubAdaptiveHint').textContent='Stream selected: '+stream+'. Your Study Hub will be personalized after account setup.'}
function selectPrep(prep){window.pubStudyPrep=prep;document.querySelectorAll('.mloSubBtn').forEach(b=>b.classList.toggle('active',b.dataset.prep===prep));window.pubStudyStream=prep;if($('pubAdaptiveHint'))$('pubAdaptiveHint').textContent=prep+' preparation selected. Your Study Hub will be personalized after account setup.'}
/* V4.1 fix: these handlers are used by inline mobile buttons inside the publish gate. Expose them on window so Android/WebView can invoke them reliably. */
window.toggleStudyLevelPicker=toggleStudyLevelPicker;
window.selectStudyPath=selectStudyPath;
window.selectStudyStream=selectStudyStream;
window.selectPrep=selectPrep;
function profileNext(){const n=($('pubName')?.value||'').trim(),c=($('pubClass')?.value||'').trim(),s=($('pubSection')?.value||'').trim();clearErrors();if(n.length<2)return $('pubProfileError').textContent='Please enter the student name.';if(!c)return $('pubProfileError').textContent='Please select the class / study path.';if((c==='Class 11'||c==='Class 12')&&!window.pubStudyStream)return $('pubProfileError').textContent='Please select your stream.';if(c==='Competitive Preparation'&&!window.pubStudyPrep)return $('pubProfileError').textContent='Please select your preparation type.';if(!pendingEmail)return showStep('pubLogin');makeVerifyCaptcha();showStep('pubVerify')}

function loading(next){let l=document.getElementById('mloFinalLoader');if(!l){l=document.createElement('div');l.id='mloFinalLoader';l.innerHTML='<div class="mloFinalLoaderCard"><div class="mloFinalLoaderLogo">✦</div><div class="mloFinalLoaderRing"></div><h3>Opening MY LIFE OS</h3><p>SECURELY RESTORING YOUR WORKSPACE</p><div class="mloFinalLoaderBar"><i></i></div></div>';document.body.appendChild(l)}l.classList.add('show');document.body.classList.add('mloFinalLoading');setTimeout(()=>{l.classList.remove('show');document.body.classList.remove('mloFinalLoading');try{next()}catch(err){console.error(err)}},2300)}
function clearAppMirror(){try{localStorage.removeItem('myLifeOS_v3');localStorage.removeItem('myLifeOS_documents_v2');localStorage.removeItem('myLifeOS_pixelProject_v14')}catch(e){}}
function restoreAppMirror(a){docsCache=Array.isArray(a?.documents)?clone(a.documents):[];window.__mloDocsCache=docsCache;state.documents=docsCache;currentPixelProject=a?.appStorage?.myLifeOS_pixelProject_v14||null;window.__mloPixelProjectCache=currentPixelProject}
function applyAccount(email,a){state=a?.state?clone(a.state):freshState();state.settings={...defaultState.settings,...(state.settings||{}),name:a?.profile?.name||state.settings?.name||'STUDENT',studentClass:a?.profile?.studentClass||state.settings?.studentClass||'',studentStream:a?.profile?.studentStream||state.settings?.studentStream||'',studentStudyPath:a?.profile?.studentStudyPath||state.settings?.studentStudyPath||a?.profile?.studentClass||state.settings?.studentClass||'',studentSection:a?.profile?.section||state.settings?.studentSection||'',studentEmail:email,profilePicture:a?.profile?.profilePicture||state.settings?.profilePicture||'',onboarded:true};restoreAppMirror(a||{});applyAdaptiveStudy(state.settings.studentStudyPath,state.settings.studentStream);a.state=clone(state);setActive(email)}
async function login(){const btn=$('pubLoginBtn');try{const e=($('pubLoginEmail')?.value||'').trim().toLowerCase(),p=$('pubLoginPassword')?.value||'',c=($('pubCaptchaInput')?.value||'').trim().toUpperCase(),d=readDB();clearErrors();if(!/^\S+@\S+\.\S+$/.test(e))return $('pubLoginError').textContent='Please enter a valid email address.';if(!p)return $('pubLoginError').textContent='Enter your password.';if(c!==cap)return $('pubLoginError').textContent='CAPTCHA is incorrect. Please try again.';const a=d[e];if(!a)return $('pubLoginError').textContent='Account not found on this device. Create a new student account here.';if(btn){btn.disabled=true;btn.textContent='CHECKING…'}const h=await hashPassword(p,a.salt||e);if(h!==a.passwordHash)return $('pubLoginError').textContent='Incorrect email or password.';applyAccount(e,a);loading(()=>{unlock();try{render()}catch(err){console.error(err)}try{syncProfileUI()}catch(err){}if(btn){btn.disabled=false;btn.textContent='ENTER MY LIFE OS →'}toast('Welcome back ✓')})}catch(err){console.error('Login error:',err);$('pubLoginError').textContent='Could not sign in right now. Please try again.';if(btn){btn.disabled=false;btn.textContent='ENTER MY LIFE OS →'}}}
async function verify(){const btn=$('pubVerifyBtn'),errEl=$('pubVerifyError');try{const v=($('pubVerifyInput')?.value||'').trim();if(v!==String(window.pubVerifyCodeValue||'')){if(errEl)errEl.textContent='Verification code is incorrect.';return}const email=pendingEmail,d=readDB(),a=d[email];if(!email||!a){if(errEl)errEl.textContent='Account setup expired. Please go back and try again.';return}const n=($('pubName')?.value||'').trim(),c=($('pubClass')?.value||'').trim(),sec=($('pubSection')?.value||'').trim();if(n.length<2||!c){if(errEl)errEl.textContent='Please complete your student profile first.';showStep('pubProfile');return}if(btn){btn.disabled=true;btn.textContent='OPENING MY LIFE OS…'}state=freshState();state.settings={...defaultState.settings,name:n,studentClass:c,studentStream:window.pubStudyStream||'',studentStudyPath:c,studentSection:sec,studentEmail:email,profilePicture:pendingPic,onboarded:true};applyAdaptiveStudy(c,window.pubStudyStream||'');a.profile={name:n,studentClass:c,studentStream:window.pubStudyStream||'',studentStudyPath:c,section:sec,profilePicture:pendingPic};a.state=clone(state);a.documents=[];a.appStorage={};a.verified=true;a.updatedAt=new Date().toISOString();d[email]=a;dbCache=d;if(idbReady)await idbPutAccount(a);else legacyWriteDB(d);pendingEmail='';pendingPic='';loading(()=>{try{setActive(email);restoreAppMirror(a);unlock();render();syncProfileUI();toast('Student account created ✓')}catch(e){console.error(e);if(errEl)errEl.textContent='MY LIFE OS could not open. Please refresh and try again.'}finally{if(btn){btn.disabled=false;btn.textContent='VERIFY & OPEN MY LIFE OS →'}}})}catch(e){console.error('Verification error:',e);if(errEl)errEl.textContent='Something went wrong while opening MY LIFE OS. Please try again.';if(btn){btn.disabled=false;btn.textContent='VERIFY & OPEN MY LIFE OS →'}}}
async function saveAccount(){const e=active();if(!e)return;const d=readDB(),a=d[e];if(!a)return;try{a.state=clone(state);a.profile=a.profile||{};a.profile.name=state.settings?.name||a.profile.name||'STUDENT';a.profile.studentClass=state.settings?.studentClass||a.profile.studentClass||'';a.profile.studentStream=state.settings?.studentStream||a.profile.studentStream||'';a.profile.studentStudyPath=state.settings?.studentStudyPath||state.settings?.studentClass||a.profile.studentStudyPath||'';a.profile.section=state.settings?.studentSection||a.profile.section||'';a.profile.profilePicture=state.settings?.profilePicture||a.profile.profilePicture||'';a.documents=clone(window.__mloDocsCache||state.documents||[]);a.appStorage=a.appStorage||{};if(window.__mloPixelProjectCache)a.appStorage.myLifeOS_pixelProject_v14=window.__mloPixelProjectCache;a.updatedAt=new Date().toISOString();a.sessionToken=a.sessionToken||uuid();d[e]=a;dbCache=d;if(idbReady){await queueAccountWrite(a);try{localStorage.setItem(SESSION_KEY,a.sessionToken)}catch(err){}}else{legacyWriteDB(d)}}catch(err){console.error('Account save failed:',err)}}
function syncProfileUI(){const box=$('sidebarAccount');if(!box)return;const e=active(),a=e?readDB()[e]:null;if(!e||!a){box.innerHTML='';box.style.display='none';return}const pic=state.settings?.profilePicture||a.profile?.profilePicture||'',name=state.settings?.name||a.profile?.name||'STUDENT',cls=state.settings?.studentClass||a.profile?.studentClass||'Student';box.classList.add('profileLogoutReady');box.style.display='grid';box.innerHTML=(pic?'<img class="sideAvatar" src="'+esc(pic)+'" alt="Profile">':'<div class="sideAvatar">＋</div>')+'<div class="sideInfo"><b>'+esc(name)+'</b><small>'+esc(cls)+'</small></div><button type="button" class="profileSideLogout" aria-label="Log out">LOG OUT</button>';const btn=box.querySelector('.profileSideLogout');if(btn)btn.onclick=e=>{e.preventDefault();e.stopPropagation();logout()};const side=$('sidebar'),brand=side?.querySelector('.brand');if(side&&brand&&box.previousElementSibling!==brand)brand.insertAdjacentElement('afterend',box)}
function forceProfilePicture(){saveAccount();syncProfileUI();try{render()}catch(e){}}
async function logout(){try{await saveAccount()}catch(e){}clearActive();state=freshState();docsCache=[];window.__mloDocsCache=docsCache;window.__mloPixelProjectCache=null;lock();clearErrors();showStep(Object.keys(readDB()).length?'pubLogin':'pubCreate');if($('pubLoginEmail'))$('pubLoginEmail').value='';if($('pubLoginPassword'))$('pubLoginPassword').value='';if($('pubCaptchaInput'))$('pubCaptchaInput').value='';makeLoginCaptcha();try{window.closeMenu?.()}catch(e){}syncProfileUI();toast('Logged out ✓ — your account is still saved on this device')}
window.logout=logout;window.logoutAccount=logout;window.mloPublishLogout=logout;window.syncAccountUIV57=syncProfileUI;window.syncSide=syncProfileUI;window.saveAccount=saveAccount;window.forceProfilePicture=forceProfilePicture;
window.mloIDBSaveDocs=function(docs){docsCache=Array.isArray(docs)?clone(docs):[];window.__mloDocsCache=docsCache;const e=active();if(e&&dbCache[e]){dbCache[e].documents=clone(docsCache);if(idbReady)idbPutAccount(dbCache[e]).catch(()=>{});else legacyWriteDB(dbCache)}};
window.mloIDBSetPixelProject=function(data){window.__mloPixelProjectCache=data||null;const e=active();if(e&&dbCache[e]){dbCache[e].appStorage=dbCache[e].appStorage||{};if(data)dbCache[e].appStorage.myLifeOS_pixelProject_v14=data;else delete dbCache[e].appStorage.myLifeOS_pixelProject_v14;if(idbReady)idbPutAccount(dbCache[e]).catch(()=>{});else legacyWriteDB(dbCache)}};
const oldSave=window.save;window.save=function(){try{state.documents=clone(window.__mloDocsCache||state.documents||[])}catch(e){}try{saveAccount()}catch(e){}};
const oldHP=window.handleProfilePicture;window.handleProfilePicture=function(ev){try{if(typeof oldHP==='function')oldHP(ev)}catch(e){}setTimeout(()=>{saveAccount();syncProfileUI()},180)};
const oldRP=window.removeProfilePicture;window.removeProfilePicture=function(){try{if(typeof oldRP==='function')oldRP()}catch(e){}setTimeout(()=>{saveAccount();syncProfileUI()},180)};
function hardHideOldGates(){['accessGate','mloAuthGate'].forEach(id=>{const el=$(id);if(el){el.style.display='none';el.style.visibility='hidden';el.style.pointerEvents='none'}})}
async function boot(){gate();lock();hardHideOldGates();const mode=await initStorage();await freshInstallOnce();if(mode==='idb'){try{await idbPutMeta('installed',1)}catch(e){}}else{try{localStorage.setItem(INSTALL_KEY,'1')}catch(e){}}const d=readDB();let e=active(),a=e?d[e]:null;if(!a&&e){for(const [email,acct] of Object.entries(d)){if(acct?.sessionToken===e){e=email;a=acct;activeCache=email;break}}}if(!e){try{const token=localStorage.getItem(SESSION_KEY)||'';if(token){for(const [email,acct] of Object.entries(d)){if(acct?.sessionToken===token){e=email;a=acct;activeCache=email;break}}}}catch(err){}}if(e&&a?.profile){try{applyAccount(e,a);unlock();render();syncProfileUI();return}catch(err){console.error('Session restore failed:',err);clearActive()}}lock();showStep(Object.keys(d).length?'pubLogin':'pubCreate');}
function persistBeforeClose(){if(active())saveAccount()}
window.addEventListener('pagehide',persistBeforeClose,{capture:true});window.addEventListener('beforeunload',persistBeforeClose,{capture:true});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')persistBeforeClose()});
window.addEventListener('error',e=>{console.error('MY LIFE OS runtime error:',e.error||e.message)});window.addEventListener('unhandledrejection',e=>{console.error('MY LIFE OS promise error:',e.reason)});
setTimeout(()=>boot(),20);setTimeout(hardHideOldGates,100);setTimeout(hardHideOldGates,500);
setInterval(()=>{hardHideOldGates();const logged=!!active();if(logged){if(document.body.classList.contains('mloPublishLocked'))unlock();syncProfileUI()}else if(!document.body.classList.contains('mloPublishLocked'))lock()},3000);
})();

\n<script>\n(function(){\n  function scanOpen(){\n    window.mloScanPages=window.mloScanPages||[];\n    const inp=document.getElementById('docScanCameraInput');\n    if(inp) inp.click();\n  }\n  window.docScanPdf=scanOpen;\n  const oldLoaded=window.docScanLoaded;\n  window.docScanLoaded=function(ev){\n    if(typeof oldLoaded==='function') oldLoaded(ev);\n    setTimeout(function(){\n      const list=document.getElementById('docScanList');\n      if(list && window.mloScanPages && window.mloScanPages.length){\n        let modal=list.closest('.modal') || list.parentElement?.closest('.modal');\n        if(!modal && typeof openModal==='function'){\n          openModal('<div class="modalHeader"><div><span class="eyebrow">SCAN → PDF</span><h2>Scan pages into one PDF</h2><small class="muted">Add pages, arrange them, then create your PDF.</small></div><button class="iconBtn" onclick="closeModal()">×</button></div><div class="form"><div class="tools"><button class="btn" onclick="document.getElementById(\\'docScanCameraInput\\')?.click()">📷 Add Photo</button><button class="btn ghost" onclick="document.getElementById(\\'docScanGalleryInput\\')?.click()">🖼️ Gallery</button></div><div id="docScanList" style="margin-top:12px"></div><div class="tools" style="margin-top:14px"><button class="btn" onclick="docScanMakePdf()">Create PDF</button><button class="btn ghost" onclick="closeModal()">Cancel</button></div></div>');\n          if(typeof docScanRender==='function') docScanRender();\n        }\n      }\n    },80);\n  };\n})();\n</script>\n