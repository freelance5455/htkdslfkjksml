Counter QR
==========
1. Unzip the folder.
2. Open index.html in Chrome (needs internet once to load fonts and the QR libraries).
3. On a phone: copy the folder to the phone and open index.html, or host it on any
   static site (Netlify, Vercel, GitHub Pages) and use "Add to Home screen".

First use: Portal tab > Merchant QR > upload your shop's QR image.
History is stored in the browser on that device only. Back up with Portal > Copy as CSV.
