package com.asx.obd2;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 1001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private BluetoothSocket socket;
    private InputStream input;
    private OutputStream output;
    private Thread readerThread;
    private volatile boolean reading;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidELM(), "AndroidELM");
        webView.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissions();
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
            }
        }
    }

    private boolean permissionsOk() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                 checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED);
    }

    private void notifyJs(final String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private void closeConnection() {
        reading = false;
        try { if (input != null) input.close(); } catch (Exception ignored) {}
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        input = null; output = null; socket = null;
    }

    public class AndroidELM {
        @JavascriptInterface public void connect() {
            if (!permissionsOk()) { notifyJs("window.onAndroidElmError('Bluetooth permissions are not granted')"); return; }
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { notifyJs("window.onAndroidElmError('Bluetooth is not supported')"); return; }
            if (!adapter.isEnabled()) { notifyJs("window.onAndroidElmError('Turn on Bluetooth first')"); return; }
            try {
                // Prefer the first paired ELM/OBD device. The HTML also accepts a name hint via localStorage.
                String wanted = null;
                try { wanted = webView.getSettings() != null ? null : null; } catch (Exception ignored) {}
                BluetoothDevice chosen = null;
                for (BluetoothDevice d : adapter.getBondedDevices()) {
                    String n = d.getName();
                    if (n != null && (n.toLowerCase().contains("elm") || n.toLowerCase().contains("obd") || n.toLowerCase().contains("vlink"))) { chosen = d; break; }
                    if (chosen == null) chosen = d;
                }
                if (chosen == null) { notifyJs("window.onAndroidElmError('No paired Bluetooth device. Pair the ELM327 in Android settings first.')"); return; }
                connectDevice(chosen);
            } catch (SecurityException e) { notifyJs("window.onAndroidElmError('Bluetooth permission denied')"); }
        }

        @JavascriptInterface public void connectTo(String address) {
            if (!permissionsOk()) { notifyJs("window.onAndroidElmError('Bluetooth permissions are not granted')"); return; }
            try {
                BluetoothDevice d = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address);
                connectDevice(d);
            } catch (Exception e) { notifyJs("window.onAndroidElmError(" + jsString(e.getMessage()) + ")"); }
        }

        @JavascriptInterface public String getPairedDevices() {
            if (!permissionsOk()) return "[]";
            try {
                StringBuilder b = new StringBuilder("[");
                boolean first = true;
                for (BluetoothDevice d : BluetoothAdapter.getDefaultAdapter().getBondedDevices()) {
                    if (!first) b.append(','); first = false;
                    b.append("{\"name\":").append(jsString(d.getName() == null ? "Bluetooth device" : d.getName()))
                     .append(",\"address\":").append(jsString(d.getAddress())).append('}');
                }
                return b.append(']').toString();
            } catch (SecurityException e) { return "[]"; }
        }

        @JavascriptInterface public void disconnect() { closeConnection(); notifyJs("window.onAndroidElmDisconnected()"); }

        @JavascriptInterface public String send(String command, String callbackId) {
            if (socket == null || !socket.isConnected() || output == null) {
                notifyJs("window.elmBridgeResponse(" + jsString(callbackId) + "," + jsString("ERROR: not connected") + ")");
                return "ERROR: not connected";
            }
            try {
                String cmd = command == null ? "" : command.trim();
                if (!cmd.endsWith("\r")) cmd += "\r";
                output.write(cmd.getBytes(StandardCharsets.US_ASCII)); output.flush();
                String response = readUntilPrompt();
                if (callbackId != null) notifyJs("window.elmBridgeResponse(" + jsString(callbackId) + "," + jsString(response) + ")");
                return response;
            } catch (Exception e) {
                String err = "ERROR: " + (e.getMessage() == null ? "I/O error" : e.getMessage());
                if (callbackId != null) notifyJs("window.elmBridgeResponse(" + jsString(callbackId) + "," + jsString(err) + ")");
                return err;
            }
        }

        private void connectDevice(BluetoothDevice device) {
            new Thread(() -> {
                closeConnection();
                try {
                    BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    s.connect();
                    socket = s; input = s.getInputStream(); output = s.getOutputStream();
                    notifyJs("window.onAndroidElmConnected(" + jsString(device.getName() == null ? device.getAddress() : device.getName()) + ")");
                    startReader();
                } catch (Exception e) {
                    closeConnection();
                    notifyJs("window.onAndroidElmError(" + jsString("Connection failed: " + e.getMessage()) + ")");
                }
            }).start();
        }

        private String readUntilPrompt() throws IOException {
            StringBuilder sb = new StringBuilder();
            long deadline = System.currentTimeMillis() + 5000;
            while (System.currentTimeMillis() < deadline) {
                while (input.available() > 0) {
                    int c = input.read();
                    if (c < 0) break;
                    sb.append((char)c);
                    if (c == '>') return sb.toString();
                }
                try { Thread.sleep(10); } catch (InterruptedException ignored) {}
            }
            return sb.toString();
        }

        private void startReader() {
            reading = true;
            readerThread = new Thread(() -> { while (reading && socket != null) { try { if (input != null && input.available() > 0) input.read(); else Thread.sleep(50); } catch (Exception ignored) { break; } } });
            readerThread.start();
        }
    }

    private String jsString(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "\\r").replace("\n", "\\n") + "\"";
    }

    @Override protected void onDestroy() { closeConnection(); if (webView != null) webView.destroy(); super.onDestroy(); }
}
