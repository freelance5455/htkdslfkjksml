# ASX OBD2 Dashboard — Android Java

Готовый Android-проект для Mitsubishi ASX 2018 1.6 + обычный Bluetooth Classic ELM327 (SPP).

## Сборка
1. Откройте папку в Android Studio.
2. Дождитесь синхронизации Gradle.
3. Подключите Android-смартфон.
4. Build → Build APK(s).

## Перед подключением ELM327
Сначала выполните сопряжение ELM327 в системных настройках Bluetooth Android.
После запуска приложения нажмите Connect.

## Как это работает
- `index.html` находится в `app/src/main/assets/`.
- Java `MainActivity` открывает HTML в WebView.
- `AndroidELM` предоставляет HTML мост к Bluetooth Classic SPP.
- Используется UUID `00001101-0000-1000-8000-00805F9B34FB`.
- Android 12+ запрашивает BLUETOOTH_CONNECT/SCAN.

Примечание: кнопка Connect автоматически выбирает первый сопряжённый Bluetooth-девайс, отдавая приоритет именам ELM/OBD/VLINK. Для более удобного выбора устройств метод `getPairedDevices()` уже доступен JS-мосту.
