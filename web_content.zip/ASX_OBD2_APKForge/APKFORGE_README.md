# ASX OBD2 Dashboard — APKForge edition

## Important
This archive is a native Android Java/Gradle project. The app requires the Java Bluetooth Classic SPP bridge (`AndroidELM`) because the HTML dashboard alone cannot access an ordinary Bluetooth Classic ELM327 adapter.

The public `ApkForge` toolkit is primarily an APK decompile/patch/rebuild/sign pipeline. Its documented input is an existing APK/decompiled project controlled by `build_config.json`; it is not a Gradle source-project builder. Therefore this archive keeps the native Gradle project intact instead of converting it into a misleading HTML-only package.

## Recommended build
Use a builder that accepts Android Gradle Java projects (or Android Studio) and build `app:assembleDebug`.

## App
- Package: `com.asx.obd2`
- Version: 1.0 (versionCode 1)
- Java
- WebView + local `index.html`
- Bluetooth Classic RFCOMM/SPP
- SPP UUID: `00001101-0000-1000-8000-00805F9B34FB`
- Android 12+ permissions: `BLUETOOTH_CONNECT`, `BLUETOOTH_SCAN`

## ELM327
Pair the ELM327 in Android Bluetooth settings before connecting from the dashboard.
