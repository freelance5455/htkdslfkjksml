import flask
import random
import string
import time
from flask import Flask, render_template, request, jsonify
import requests
import socks
import socket

# Initialize Flask App
app = Flask(__name__, template_folder='.') # Assumes index.html is in the same 
folder

# --- SOCKS CONFIGURATION ---
# Set up the default socket to use SOCKS5H (SOCKS5 with DNS resolution through proxy)
# Default proxy settings. You can make these dynamic later if needed.
socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 1080) 
socket.socket = socks.socksocket

def generate_tx_id():
    """Generates a fake but realistic-looking Bitcoin Transaction ID."""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(64))

@app.route('/')
def index():
    return 
render_template('index.html')

@app.route('/send', methods=['POST'])
def send_transaction():
    data = request.json
    
    recipient_address = data.get('address')
    amount = data.get('amount')
    use_vpn = data.get('vpn', False)
    use_blockchain = data.get('blockchain', 
False)

    if not recipient_address or not amount:
        return jsonify({"status": "error", "message": "Missing address or amount"}), 400

    # Simulate processing delay based on blockchain mode
    if use_blockchain:
        time.sleep(2) # Simulate network latency
    else:
        
time.sleep(0.5)

    # Simulate sending logic
    # In a real app, this would interact with a Bitcoin node or API like Blockstream/BlockCypher
    
    # Check if we are using VPN (Logic check)
    vpn_status = "via VPN" if use_vpn else "direct"
    
    # Generate fake TX ID
    tx_id = generate_tx_id()

    # Return success response
    return jsonify({
        "status": "success",
        "message": f"Transaction sent {vpn_status}",
        "tx_id": tx_id,
        "recipient": recipient_address,
        "amount": amount
    })

if __name__ == '__main__':
    # Run the server
    # Use threaded=True to handle concurrent requests 
better
    app.run(host='0.0.0.0', port=5000, debug=True)