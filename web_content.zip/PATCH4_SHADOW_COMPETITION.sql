-- ScoreDeck Patch 4: additive, private verified-interval shadow competition.
-- Apply only after review. Does not alter legacy leaderboard tables/functions.

create table if not exists private.competition_time_sessions (
  user_id uuid not null references auth.users(id) on delete cascade,
  source text not null check (source in ('home','focus','practice','sample_paper')),
  client_session_id text not null check (length(client_session_id) between 1 and 160),
  subject_key text,
  started_at timestamptz not null default now(),
  last_heartbeat_at timestamptz not null default now(),
  ended_at timestamptz,
  is_paused boolean not null default false,
  is_closed boolean not null default false,
  heartbeat_sequence bigint not null default 0 check (heartbeat_sequence >= 0),
  created_at timestamptz not null default now(),
  primary key (user_id, source, client_session_id)
);

create table if not exists private.competition_time_intervals (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  source text not null check (source in ('home','focus','practice','sample_paper')),
  client_session_id text not null,
  sequence bigint not null,
  started_at timestamptz not null,
  ended_at timestamptz not null,
  recorded_at timestamptz not null default now(),
  constraint competition_time_interval_positive check (ended_at > started_at),
  constraint competition_time_interval_unique unique (user_id, source, client_session_id, sequence),
  constraint competition_time_interval_session_fk foreign key (user_id, source, client_session_id)
    references private.competition_time_sessions(user_id, source, client_session_id) on delete cascade
);

create index if not exists competition_time_intervals_user_bounds_idx
  on private.competition_time_intervals(user_id, started_at, ended_at);

create table if not exists private.competition_shadow_weekly_stats (
  user_id uuid not null references auth.users(id) on delete cascade,
  week_start date not null,
  verified_seconds bigint not null default 0 check (verified_seconds >= 0),
  opted_in boolean not null default false,
  shared_rank bigint,
  updated_at timestamptz not null default now(),
  primary key (user_id, week_start)
);

alter table private.competition_time_sessions enable row level security;
alter table private.competition_time_intervals enable row level security;
alter table private.competition_shadow_weekly_stats enable row level security;

revoke all on private.competition_time_sessions, private.competition_time_intervals,
  private.competition_shadow_weekly_stats from public, anon, authenticated;

create or replace function public.competition_shadow_session(p_action text, p_source text, p_session_id text, p_subject_key text default null)
returns boolean
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := (select auth.uid());
  v_now timestamptz := clock_timestamp();
  v_session private.competition_time_sessions%rowtype;
  v_delta interval;
  v_end timestamptz;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if p_source is null or p_source not in ('home','focus','practice','sample_paper') then raise exception 'Invalid source'; end if;
  if p_session_id is null or length(p_session_id) < 1 or length(p_session_id) > 160 then raise exception 'Invalid session id'; end if;
  if p_subject_key is not null and p_subject_key not in ('accountancy','business_studies','economics','applied_mathematics','english_core') then raise exception 'Invalid subject'; end if;

  if p_action = 'start' then
    insert into private.competition_time_sessions(user_id,source,client_session_id,subject_key,started_at,last_heartbeat_at)
    values(v_uid,p_source,p_session_id,p_subject_key,v_now,v_now)
    on conflict(user_id,source,client_session_id) do nothing;
    select * into v_session from private.competition_time_sessions
      where user_id=v_uid and source=p_source and client_session_id=p_session_id for update;
    if v_session.is_closed then raise exception 'Session is already closed'; end if;
    return true;
  end if;

  select * into v_session from private.competition_time_sessions
    where user_id=v_uid and source=p_source and client_session_id=p_session_id for update;
  if not found then raise exception 'Session not found'; end if;
  if v_session.is_closed then return true; end if;

  if p_action = 'resume' then
    if not v_session.is_paused then return true; end if;
    update private.competition_time_sessions set is_paused=false,last_heartbeat_at=v_now,
      subject_key=coalesce(p_subject_key,subject_key) where user_id=v_uid and source=p_source and client_session_id=p_session_id;
    return true;
  end if;

  if p_action is null or p_action not in ('pulse','pause','complete','abandon') then raise exception 'Invalid action'; end if;
  if v_session.is_paused then
    if p_action in ('pause','abandon','complete') then
      update private.competition_time_sessions set is_closed=(p_action<>'pause'),ended_at=case when p_action<>'pause' then v_now else null end
      where user_id=v_uid and source=p_source and client_session_id=p_session_id;
    end if;
    return true;
  end if;

  v_delta := v_now-v_session.last_heartbeat_at;
  -- Credit only server-observed gaps no longer than 75 seconds. Longer gaps are
  -- deliberately discarded instead of trusting client elapsed-time claims.
  if v_delta > interval '0 seconds' and v_delta <= interval '75 seconds' then
    v_end := v_now;
    insert into private.competition_time_intervals(user_id,source,client_session_id,sequence,started_at,ended_at)
    values(v_uid,p_source,p_session_id,v_session.heartbeat_sequence+1,v_session.last_heartbeat_at,v_end)
    on conflict(user_id,source,client_session_id,sequence) do nothing;
  end if;

  update private.competition_time_sessions set
    last_heartbeat_at=v_now,
    heartbeat_sequence=heartbeat_sequence+1,
    is_paused=(p_action='pause'),
    is_closed=(p_action in ('complete','abandon')),
    ended_at=case when p_action in ('complete','abandon') then v_now else ended_at end,
    subject_key=coalesce(p_subject_key,subject_key)
  where user_id=v_uid and source=p_source and client_session_id=p_session_id;
  return true;
end;
$function$;

revoke all on function public.competition_shadow_session(text,text,text,text) from public, anon;
grant execute on function public.competition_shadow_session(text,text,text,text) to authenticated;

create or replace function public.refresh_competition_shadow()
returns boolean
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := (select auth.uid());
begin
  if v_uid is null or not exists (
    select 1 from public.scoredeck_admin_roles r where r.user_id=v_uid and r.role in ('owner','co_admin')
  ) then raise exception 'Owner/admin access required'; end if;

  with ranges as (
    select i.user_id, unnest(range_agg(tstzrange(i.started_at,i.ended_at,'[)'))) as r
    from private.competition_time_intervals i
    group by i.user_id
  ), weeks as (
    select x.user_id, g.monday::date as week_start,
      extract(epoch from least(upper(x.r),((g.monday+interval '7 days') at time zone 'Asia/Kolkata'))
        - greatest(lower(x.r),(g.monday at time zone 'Asia/Kolkata')))::bigint as seconds
    from ranges x
    cross join lateral generate_series(
      date_trunc('week',lower(x.r) at time zone 'Asia/Kolkata'),
      date_trunc('week',(upper(x.r)-interval '1 microsecond') at time zone 'Asia/Kolkata'),
      interval '7 days'
    ) as g(monday)
  ), totals as (
    select user_id,week_start,sum(seconds)::bigint as seconds from weeks where seconds>0 group by user_id,week_start
  ), ranks as (
    select t.user_id,t.week_start,rank() over(partition by t.week_start order by t.seconds desc) as shared_rank
    from totals t join public.profiles p on p.id=t.user_id where p.competition_opt_in
  ), candidates as (
    select t.user_id,t.week_start,t.seconds,p.competition_opt_in,r.shared_rank
    from totals t join public.profiles p on p.id=t.user_id
    left join ranks r on r.user_id=t.user_id and r.week_start=t.week_start
  )
  insert into private.competition_shadow_weekly_stats(user_id,week_start,verified_seconds,opted_in,shared_rank,updated_at)
  select user_id,week_start,seconds,competition_opt_in,shared_rank,clock_timestamp() from candidates
  on conflict(user_id,week_start) do update set verified_seconds=excluded.verified_seconds,
    opted_in=excluded.opted_in,shared_rank=excluded.shared_rank,updated_at=excluded.updated_at;

  -- Keep zero-activity current-week rows for opt-in profiles so rejoining users
  -- can appear in the whole current week as soon as verified time exists.
  insert into private.competition_shadow_weekly_stats(user_id,week_start,verified_seconds,opted_in,shared_rank,updated_at)
  select p.id,date_trunc('week',now() at time zone 'Asia/Kolkata')::date,0,true,null,clock_timestamp()
  from public.profiles p where p.competition_opt_in
  on conflict(user_id,week_start) do update set opted_in=true,updated_at=excluded.updated_at;

  update private.competition_shadow_weekly_stats s set opted_in=p.competition_opt_in,
    shared_rank=null,updated_at=clock_timestamp()
  from public.profiles p where p.id=s.user_id and not p.competition_opt_in;
  return true;
end;
$function$;

revoke all on function public.refresh_competition_shadow() from public, anon;
grant execute on function public.refresh_competition_shadow() to authenticated;

create or replace function public.get_competition_shadow_comparison()
returns table(
  week_start date,legacy_week_start date,user_id uuid,display_name text,competition_opt_in boolean,
  legacy_focus_seconds bigint,verified_focus_seconds bigint,delta_seconds bigint,verified_rank bigint
  ,previous_verified_rank bigint
)
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := (select auth.uid());
  v_week date := date_trunc('week',now() at time zone 'Asia/Kolkata')::date;
  v_legacy_week date := date_trunc('week',now() at time zone 'UTC')::date;
  v_previous_week date := (date_trunc('week',now() at time zone 'Asia/Kolkata')::date-7);
begin
  if v_uid is null or not exists (
    select 1 from public.scoredeck_admin_roles r where r.user_id=v_uid and r.role in ('owner','co_admin')
  ) then raise exception 'Owner/admin access required'; end if;
  perform public.refresh_competition_shadow();
  return query
  select v_week,v_legacy_week,p.id,p.display_name,p.competition_opt_in,
    coalesce(l.focus_seconds,0)::bigint,coalesce(s.verified_seconds,0)::bigint,
    coalesce(s.verified_seconds,0)-coalesce(l.focus_seconds,0),s.shared_rank,prev.shared_rank
  from public.profiles p
  left join public.competition_weekly_stats l on l.user_id=p.id and l.week_start=v_legacy_week and l.subject_key='__all__'
  left join private.competition_shadow_weekly_stats s on s.user_id=p.id and s.week_start=v_week
  left join private.competition_shadow_weekly_stats prev on prev.user_id=p.id and prev.week_start=v_previous_week
  where p.competition_opt_in
  order by s.shared_rank nulls last,p.display_name,p.id;
end;
$function$;

revoke all on function public.get_competition_shadow_comparison() from public, anon;
grant execute on function public.get_competition_shadow_comparison() to authenticated;
