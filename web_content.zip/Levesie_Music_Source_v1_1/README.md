# Levesie Music 1.1
Projet Android léger : interface noire et verte, catalogue de 23 artistes, lecture de fichiers audio locaux, lecture vidéo locale et lien vers TikTok.

Artistes : Gims, Dadju, Levesie One, Fally Ipupa, Aya Nakamura, Burna Boy, Wizkid, Davido, Rema, Tyla, Didi B, Himra, Magic System, Tiken Jah Fakoly, Alpha Blondy, Josey, Tayc, Ninho, Niska, Tiakola, Soolking, Innoss’B, Gaz Mawete.

Les profils sont des entrées de catalogue uniquement : aucun morceau commercial protégé n'est inclus. Pour écouter des chansons, importer des fichiers dont tu détiens les droits ou intégrer un service/API autorisé.

Compilation : ouvrir ce dossier dans Android Studio, synchroniser Gradle puis Build > Build APK(s). La taille finale doit être vérifiée après compilation ; l'objectif 5 Mo n'est pas garanti.
