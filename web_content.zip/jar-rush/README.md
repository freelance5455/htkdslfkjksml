# JAR RUSH

Casual physics car-merging puzzle game. Drop cars into the glass jar; two matching cars that touch merge into the next level. 19 cars, coins, collection, pause/settings, local save.

## What is in this ZIP
| Path | What it is |
|---|---|
| `index.html` | The whole game (art, logic and UI in one file). Open it in a browser - needs internet once for the physics library (Matter.js 0.19.0 from cdnjs). |
| `package.json`, `capacitor.config.json`, `scripts/` | Android wrapper setup (Capacitor) - builds APK and AAB. |
| `.github/workflows/build-android.yml` | Free cloud build: pushes produce an APK + test AAB with no local Android setup. |
| `marketing/jar-rush-ad.mp4` | 20 s vertical video ad (motion graphics + a scripted merge-chain demo, not a screen recording). |

## Play in a browser
Open `index.html` (internet needed for Matter.js). For fully offline browser play, put `matter.min.js` (0.19.0) in `libs/`.

## Build the Android app (APK / AAB)
**An .aab could not be built in the environment that made this project (no Android SDK / no internet), so no .aab file is included.** Any of these gets you one:

**A. GitHub (no installs):** create a repo, upload this folder, open the *Actions* tab -> *Build Android* -> Run workflow. Download the artifact `jar-rush-android` (debug APK + debug AAB).

**B. Your computer** (Node 20, JDK 17, Android Studio/SDK):
```
npm install
npm run android:add      # once
npm run android:apk      # -> android/app/build/outputs/apk/debug/app-debug.apk
npm run android:aab-debug# -> android/app/build/outputs/bundle/debug/app-debug.aab
```
**C. Play Store release AAB** (must be signed with YOUR key):
1. Create a keystore: `keytool -genkey -v -keystore jarrush.jks -alias jarrush -keyalg RSA -keysize 2048 -validity 10000`
2. In Android Studio open `android/` -> *Build > Generate Signed Bundle / APK > Android App Bundle*, pick the keystore. Or configure `signingConfigs` in `android/app/build.gradle` and run `npm run android:aab` -> `android/app/build/outputs/bundle/release/app-release.aab`.
3. Change `appId` in `capacitor.config.json` if `com.jarrush.game` is taken. Keep the keystore safe - Play needs the same key for every update.

## Game rules (as implemented)
* Merge points: `level^2*4 + level*3`, x(1 + 0.5 per extra chain step); chain window 1.5 s.
* Coins: new car level +1 per merge (+1 per extra chain step), +10 x level the first time a car is unlocked, +1 per 100 points at game over.
* Game over: a settled car stays above the dashed line for ~2 s.
* Save data (localStorage): best score, coins, highest car, stats, settings. Old 8-car saves migrate to the 19-car order.

## Testing performed
Automated browser test (headless Chromium, phone-size viewport, 31 checks, all passed): loading -> home, collection (19 cars, detail, back), "Coming Soon" badge layout, settings toggles, play, drop by touch, merge reward counted once, pause/resume/restart/home, no input while paused, Android back button, game over, persistence across reload, old-save migration, corrupt-save fallback, reset progress. **Limitation:** that test used a simplified stand-in for the physics engine (Matter.js could not be downloaded there), so the real physics feel and the final APK/AAB were NOT tested on a device. Please playtest on your phone.

## Known limitations
* Sounds/music are synthesized in code (no audio files); Google Font "Lilita One" loads online, with a system fallback.
* Home screen car/clouds are separate images over a repainted background; small retouch artifacts may be visible up close.
* iPhone tilt-parallax is not enabled (needs a permission prompt); the home screen is otherwise static.
