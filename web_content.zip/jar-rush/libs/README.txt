Put matter.min.js (Matter.js 0.19.0) here only if you want to run index.html fully offline in a browser. The Android build copies it automatically from npm.
