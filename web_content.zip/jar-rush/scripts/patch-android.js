// Locks the app to portrait after "cap add android". Safe to run repeatedly.
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(f)) { console.log('android/ not found - run: npm run android:add'); process.exit(0); }
let x = fs.readFileSync(f, 'utf8');
if (!x.includes('screenOrientation')) { x = x.replace('<activity', '<activity android:screenOrientation="portrait"'); fs.writeFileSync(f, x); console.log('portrait lock added'); }
