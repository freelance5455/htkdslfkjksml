// Builds ./www (what the Android app loads): the game page + a local copy of Matter.js so it works offline.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), www = path.join(root, 'www');
fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(www, 'libs'), { recursive: true });
fs.copyFileSync(path.join(root, 'index.html'), path.join(www, 'index.html'));
const m = path.join(root, 'node_modules', 'matter-js', 'build', 'matter.min.js');
if (!fs.existsSync(m)) { console.error('matter-js not installed. Run: npm install'); process.exit(1); }
fs.copyFileSync(m, path.join(www, 'libs', 'matter.min.js'));
console.log('www/ ready');
