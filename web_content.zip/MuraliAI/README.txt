Murali AI - multi-provider free AI chat (Chat / Images / Settings)

RUN
 1. Unzip. Host the folder free on GitHub Pages, Netlify Drop or Cloudflare Pages, then open the link on your phone and choose "Add to Home screen".
 2. Or open index.html directly (chat works; offline install needs hosting).

FREE KEYS (paste in Settings; takes 1 minute each)
 - Groq: console.groq.com
 - Gemini: aistudio.google.com/apikey
 - OpenRouter: openrouter.ai (models ending in :free)
 Pollinations works with no key.

HOW IT AVOIDS LIMITS
 - Tries providers top to bottom; on a limit error it moves to the next one.
 - If all are busy it counts down and retries automatically (up to 3 times).
 - Chats are saved in your phone browser (IndexedDB), so there is no app-side chat or storage limit.
 - Images use Pollinations (free, no key).
Free providers still have their own limits; chaining several makes them rare.

SPEED: answers stream word by word, Groq is tried first (fastest), slow providers time out after 12s.
IDENTITY: asking who built it returns "Murali Teja G".
APK: this is a web app. To make an APK, upload the hosted link to pwabuilder.com and download the Android package.
