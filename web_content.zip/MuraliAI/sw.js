self.addEventListener("install",e=>e.waitUntil(caches.open("fc1").then(c=>c.addAll(["index.html","manifest.json"]))));
self.addEventListener("fetch",e=>{if(e.request.method=="GET"&&new URL(e.request.url).origin==location.origin)e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
