package com.smartcity.presence;
import android.Manifest; import android.app.Activity; import android.os.Bundle; import android.webkit.*;
public class MainActivity extends Activity {
 WebView web;
 public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Object(){@JavascriptInterface public void requestPermissions(){runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10));}},"AndroidApp"); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
}
