# Stage 1181 — Ourbit API Alignment

Root-cause correction after Stage 1180 diagnostics.

## Verified API facts
- Spot REST base: https://api.ourbit.com
- Spot Kline endpoint: `/api/v3/klines`
- Ourbit documents intervals including `1m`, `5m`, `15m`, `30m`, `60m`, `4h`, `1d`, `1W`.
- CryptoPulse UI uses `1h`; Stage 1181 maps UI `1h` to Ourbit `60m`.
- UI `1w` maps to Ourbit `1W`.
- Futures Kline uses `contract.ourbit.com/api/v1/contract/kline/<SYMBOL>` with `Min1`, `Min5`, `Min15`, `Min30`, `Min60`, `Hour4`, `Day1` style intervals.

## Changes
1. Fixed the Spot native Ourbit K-line interval mapping.
2. Fixed the browser Ourbit K-line interval mapping.
3. Kept native HTTP path as primary to avoid WebView CORS dependence.
4. Corrected Futures status labels that still said LBank.
5. No synthetic candles or fake prices were added.

## Next runtime test
Use Settings → Ourbit Market Diagnostics first. Then test Home, Trade BTCUSDT, and Futures BTCUSDT.
