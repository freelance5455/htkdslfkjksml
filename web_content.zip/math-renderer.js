/* Offline mathematical notation renderer for Engineering Review Quiz.
   Handles common LaTeX-style commands and Unicode engineering notation without external services. */
(function () {
  const GREEK = {
    alpha:'α', beta:'β', gamma:'γ', delta:'δ', epsilon:'ε', varepsilon:'ε', zeta:'ζ', eta:'η',
    theta:'θ', vartheta:'ϑ', iota:'ι', kappa:'κ', lambda:'λ', mu:'μ', nu:'ν', xi:'ξ', pi:'π',
    rho:'ρ', sigma:'σ', tau:'τ', upsilon:'υ', phi:'φ', varphi:'ϕ', chi:'χ', psi:'ψ', omega:'ω',
    Gamma:'Γ', Delta:'Δ', Theta:'Θ', Lambda:'Λ', Xi:'Ξ', Pi:'Π', Sigma:'Σ', Phi:'Φ', Psi:'Ψ', Omega:'Ω'
  };
  const SYMBOLS = {
    times:'×', cdot:'·', ast:'∗', div:'÷', pm:'±', mp:'∓', neq:'≠', ne:'≠', le:'≤', leq:'≤', ge:'≥', geq:'≥',
    approx:'≈', equiv:'≡', propto:'∝', infty:'∞', degree:'°', partial:'∂', nabla:'∇', sum:'∑', prod:'∏', int:'∫',
    oint:'∮', rightarrow:'→', leftarrow:'←', leftrightarrow:'↔', implies:'⇒', to:'→', gets:'←', therefore:'∴',
    percent:'%', ell:'ℓ', Re:'ℜ', Im:'ℑ', forall:'∀', exists:'∃', in:'∈', notin:'∉', subset:'⊂',
    subseteq:'⊆', cup:'∪', cap:'∩', land:'∧', lor:'∨', neg:'¬', angle:'∠'
  };
  const SUBS = {
    '₀':'0','₁':'1','₂':'2','₃':'3','₄':'4','₅':'5','₆':'6','₇':'7','₈':'8','₉':'9',
    '₊':'+','₋':'−','₌':'=','₍':'(','₎':')','ₐ':'a','ₑ':'e','ₕ':'h','ₖ':'k','ₗ':'l','ₘ':'m',
    'ₙ':'n','ₒ':'o','ₚ':'p','ₛ':'s','ₜ':'t','ₓ':'x'
  };
  // Some books use modifier letters as visual subscripts even though Unicode classifies them as superscripts.
  const SUB_MODIFIERS = {'ᵢ':'i','ⱼ':'j','ᵣ':'r','ᵤ':'u','ᵥ':'v'};
  const SUPS = {
    '⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9',
    '⁺':'+','⁻':'−','⁼':'=','⁽':'(','⁾':')','ⁿ':'n','ⁱ':'i'
  };

  function readGroup(source, start) {
    if (source[start] !== '{') return { value: source[start] || '', end: start + (source[start] ? 1 : 0) };
    let depth = 1, i = start + 1;
    for (; i < source.length && depth; i++) {
      if (source[i] === '{') depth++;
      else if (source[i] === '}') depth--;
    }
    return { value: source.slice(start + 1, depth ? source.length : i - 1), end: i };
  }
  function readScriptGroup(source, start) {
    const opener = source[start];
    if (opener === '{') return readGroup(source, start);
    if (opener !== '(' && opener !== '[') return { value: source[start] || '', end: start + (source[start] ? 1 : 0) };
    const closer = opener === '(' ? ')' : ']';
    let depth = 1, i = start + 1;
    for (; i < source.length && depth; i++) {
      if (source[i] === opener) depth++;
      else if (source[i] === closer) depth--;
    }
    return { value: source.slice(start + 1, depth ? source.length : i - 1), end: i };
  }
  function appendScript(parent, text, kind) {
    const el = document.createElement(kind === 'sub' ? 'sub' : 'sup');
    el.className = kind === 'sub' ? 'math-sub' : 'math-sup';
    el.textContent = text;
    parent.append(el);
  }
  function appendAccent(parent, groupValue, kind) {
    const span = document.createElement('span');
    span.className = `math-accent math-${kind}`;
    const base = document.createElement('span');
    parse(groupValue, base);
    span.append(base);
    parent.append(span);
  }
  function parse(source, parent) {
    let i = 0;
    const addText = text => { if (text) parent.append(document.createTextNode(text)); };
    while (i < source.length) {
      const ch = source[i];
      if (ch === '\\') {
        const match = source.slice(i + 1).match(/^[A-Za-z]+|^./);
        if (!match) { addText(ch); i++; continue; }
        const cmd = match[0]; i += cmd.length + 1;
        if (cmd === 'frac' || cmd === 'dfrac' || cmd === 'tfrac') {
          while (source[i] === ' ') i++;
          const num = readGroup(source, i); i = num.end;
          while (source[i] === ' ') i++;
          const den = readGroup(source, i); i = den.end;
          const frac = document.createElement('span'); frac.className = 'math-fraction';
          const numerator = document.createElement('span'); numerator.className = 'math-numerator'; parse(num.value, numerator);
          const denominator = document.createElement('span'); denominator.className = 'math-denominator'; parse(den.value, denominator);
          frac.append(numerator, denominator); parent.append(frac); continue;
        }
        if (cmd === 'sqrt') {
          while (source[i] === ' ') i++;
          let index = null;
          if (source[i] === '[') { const end = source.indexOf(']', i + 1); if (end >= 0) { index = source.slice(i + 1, end); i = end + 1; } }
          const group = readGroup(source, i); i = group.end;
          const root = document.createElement('span'); root.className = 'math-root';
          if (index !== null) { const idx = document.createElement('sup'); idx.className = 'math-root-index'; parse(index, idx); root.append(idx); }
          const sign = document.createElement('span'); sign.className = 'math-root-sign'; sign.textContent = '√';
          const radicand = document.createElement('span'); radicand.className = 'math-radicand'; parse(group.value, radicand);
          root.append(sign, radicand); parent.append(root); continue;
        }
        if (['dot','ddot','bar','overline','hat','widehat','tilde','vec'].includes(cmd)) {
          const group = readGroup(source, i); i = group.end;
          const kind = ({dot:'overdot',ddot:'overddot',bar:'overbar',overline:'overbar',hat:'overhat',widehat:'overhat',tilde:'overtilde',vec:'overvec'})[cmd];
          appendAccent(parent, group.value, kind); continue;
        }
        if (['exp','ln','log','sin','cos','tan','cot','sec','csc','arcsin','arccos','arctan','max','min','lim','det'].includes(cmd)) { addText(cmd); continue; }
        if (cmd === 'boxed' || cmd === 'fbox') {
          const group = readGroup(source, i); i = group.end;
          const box = document.createElement('span'); box.className = 'math-boxed'; parse(group.value, box); parent.append(box); continue;
        }
        if (['text','textrm','textnormal','mathrm','mathbf','mathit','operatorname'].includes(cmd)) {
          const group = readGroup(source, i); i = group.end;
          const span = document.createElement('span');
          if (cmd === 'mathbf') span.style.fontWeight = '700';
          if (['mathrm','operatorname','text','textrm','textnormal'].includes(cmd)) span.style.fontStyle = 'normal';
          if (cmd === 'mathit') span.style.fontStyle = 'italic';
          parse(group.value, span); parent.append(span); continue;
        }
        if (cmd === 'begin' || cmd === 'end') {
          const env = readGroup(source, i); i = env.end;
          if (['aligned','alignedat','gathered','array','cases','equation','equation*','split'].includes(env.value)) continue;
          addText('\\' + cmd + '{' + env.value + '}'); continue;
        }
        if (cmd === 'left' || cmd === 'right' || cmd === ',' || cmd === ';' || cmd === '!' || cmd === ' ') continue;
        if (cmd === 'quad' || cmd === 'qquad') { const spacer = document.createElement('span'); spacer.className = cmd === 'quad' ? 'math-space' : 'math-space math-space-wide'; parent.append(spacer); continue; }
        if (GREEK[cmd] || SYMBOLS[cmd]) { addText(GREEK[cmd] || SYMBOLS[cmd]); continue; }
        addText(cmd); continue;
      }
      if (ch === '^' || ch === '_') {
        i++; while (source[i] === ' ') i++; const group = readScriptGroup(source, i); i = group.end;
        const el = document.createElement(ch === '^' ? 'sup' : 'sub'); el.className = ch === '^' ? 'math-sup' : 'math-sub'; parse(group.value, el); parent.append(el); continue;
      }
      if (SUBS[ch] || SUB_MODIFIERS[ch]) {
        let value = '';
        while (i < source.length && (SUBS[source[i]] || SUB_MODIFIERS[source[i]])) { value += SUBS[source[i]] || SUB_MODIFIERS[source[i]]; i++; }
        appendScript(parent, value, 'sub'); continue;
      }
      if (SUPS[ch]) {
        let value = '';
        while (i < source.length && SUPS[source[i]]) { value += SUPS[source[i]]; i++; }
        appendScript(parent, value, 'sup'); continue;
      }
      if (ch === '{' || ch === '}') { i++; continue; }
      if (ch === '&') { addText(' & '); i++; continue; }
      addText(ch); i++;
    }
  }
  function normalizePlain(value, equationMode = false) {
    let text = String(value ?? '');
    // Convert common plain-text engineering variable names into explicit subscript notation.
    const variables = [
      [/\bTdb\b/g,'T_{db}'], [/\bTwb\b/g,'T_{wb}'], [/\bTdp\b/g,'T_{dp}'],
      [/\bTin\b/g,'T_{in}'], [/\bTout\b/g,'T_{out}'], [/\bThot\b/g,'T_{hot}'], [/\bTcold\b/g,'T_{cold}'],
      [/\bTmean\b/g,'T_{mean}'], [/\bTroom\b/g,'T_{room}'], [/\bTsupply\b/g,'T_{supply}'],
      [/\bPsat\b/g,'P_{sat}'], [/\bPv\b/g,'P_v'], [/\bPs\b/g,'P_s'], [/\bRda\b/g,'R_{da}'], [/\bR_v\b/g,'R_v'], [/\bhg\b/g,'h_g'],
      [/\bcpa\b/g,'c_{p,a}'], [/\bcp,w\b/g,'c_{p,w}'], [/\bcp\b/g,'c_p'], [/\bcv\b/g,'c_v'],
      [/\bQdot_([A-Za-z0-9]+)\b/g,'\\dot{Q}_{$1}'], [/\bVdot_([A-Za-z0-9]+)\b/g,'\\dot{V}_{$1}'], [/\bmdot_([A-Za-z0-9]+)\b/g,'\\dot{m}_{$1}'],
      [/\bQdot\b/g,'\\dot{Q}'], [/\bVdot\b/g,'\\dot{V}'], [/\bmdot\b/g,'\\dot{m}'],
      [/\bPabs\b/g,'P_{abs}'], [/\bPgage\b/g,'P_{gage}'], [/\bPatm\b/g,'P_{atm}'],
      [/\bmdry\s+solid\b/g,'m_{dry solid}'], [/\bmwater\s+removed\b/g,'m_{water removed}'],
      [/\bmwater\b/g,'m_{water}'], [/\bmdry\b/g,'m_{dry}'], [/\bVdot\b/g,'\\dot{V}'], [/\bQdot\b/g,'\\dot{Q}']
    ];
    variables.forEach(([pattern,replacement]) => { text = text.replace(pattern,replacement); });
    text = text.replace(/ṁ(da|makeup|evap|w|[0-9]+)/g, (_, sub) => `\\dot{m}_{${sub}}`).replace(/ṁ/g,'\\dot{m}');
    text = text.replace(/ω(out|in|s)\b/g, (_, sub) => `ω_{${sub}}`);
    // Convert compact variable-number notation (h1, T2, A1) into proper subscript form.
    text = text.replace(/\b([A-Za-z])([0-9])\b/g, '$1_{$2}');
    text = text.replace(/([A-Za-z])\u0307/g, '\\dot{$1}');
    // Display common algebraic ratios as textbook stacked fractions only in equation-like fields.
    // The narrow patterns avoid converting ordinary prose or unit phrases into accidental fractions.
    if (equationMode) {
      text = text.replace(/\(([^()]+)\)\s*\/\s*\(([^()]+)\)/g, '\\frac{$1}{$2}');
      text = text.replace(/([^=;,+−\-()]+?)\s*\/\s*\(([^()]+)\)/g, (whole, numerator, denominator) => {
        const n = numerator.trim();
        if (!n || n.includes('\\frac') || n.includes('\\sqrt')) return whole;
        return `\\frac{${n}}{${denominator}}`;
      });
    }
    const replacements = [
      [/√\s*\[([^\[\]]*)\]/g, '\\sqrt{$1}'],
      [/√\s*\(([^()]*)\)/g, '\\sqrt{$1}'],
      [/√\s*([A-Za-z0-9])\b/g, '\\sqrt{$1}'],
      [/\b(?:squared)\b/gi, '^2'],
      [/\b(?:cubed)\b/gi, '^3'],
      // Render standalone numeric fractions as stacked textbook fractions; unit ratios with letters remain unchanged.
      [/(?<![A-Za-z0-9_.])([0-9]+(?:\.[0-9]+)?)\s*\/\s*([0-9]+(?:\.[0-9]+)?)(?![A-Za-z0-9_.])/g, '\\frac{$1}{$2}'],
      [/\\?\b(?:sqrt)\s*\(([^()]*)\)/g, '\\sqrt{$1}'],
      [/\\?\bfrac\s*\(([^()]*)\)\s*\/\s*\(([^()]*)\)/g, '\\frac{$1}{$2}'],
      [/\\?\bpi\b/g, 'π'], [/\\?\bvarepsilon\b/g, 'ε'], [/\\?\bepsilon\b/g, 'ε'],
      [/\\?\bneq\b/g, '≠'], [/\\?\bleq\b/g, '≤'], [/\\?\bgeq\b/g, '≥']
    ];
    replacements.forEach(([pattern,replacement]) => { text = text.replace(pattern,replacement); });
    return text;
  }
  window.renderMathInto = function (element, value) {
    if (!element) return;
    element.replaceChildren();
    const equationMode = /(^|\s)(formula-equation-line|math-line|math-line-item|final-answer|shortcut-formula|question)(\s|$)/.test(element.className || '') || Boolean(element.closest && element.closest('.formula-equation'));
    const source = normalizePlain(value, equationMode);
    // Keep plain prose as plain text unless it contains math markup or actual Unicode script characters.
    const hasUnicodeScripts = /[₀-₉₊₋₌₍₎ₐₑₕₖₗₘₙₒₚₛₜₓᵢⱼᵣᵤᵥ⁰-⁹⁺⁻⁼⁽⁾ⁿⁱ²³]/u.test(source);
    if (!/[\\^_]/.test(source) && !/\\frac|\\sqrt|\\dot|\\ddot/.test(source) && !hasUnicodeScripts) { element.textContent = source; return; }
    parse(source, element);
  };
  window.normalizeMathText = normalizePlain;
})();
