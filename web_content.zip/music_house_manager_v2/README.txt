MUSIC HOUSE Manager v2 — prototype

HOW TO TRY
1. Extract this ZIP.
2. Open index.html in a modern browser (Chrome recommended).
3. Use Purchase + Bill to save supplier/invoice details and a bill photo.
4. Use Customer Complaint to save customer contact, complaint, product photo and status.
5. Records tab searches saved records and shows attached photos.
6. Backup tab exports records and photos into a JSON backup.

CAMERA
The photo fields use the browser's image input with capture="environment". On supported Android browsers, this offers camera capture or gallery selection. Browser/device behavior can vary.

IMPORTANT LIMITATIONS
- This is a local prototype, not a signed Android APK and not a cloud-hosted app.
- Data is stored in IndexedDB for this browser/device. Do not clear browser storage; export backups regularly.
- No cloud sync, user login, multi-device sync, GST invoicing, or encrypted backup yet.
- Browser restrictions may limit camera prompts and local HTML behavior. If camera does not open from a local file, serve the app from HTTPS hosting or package it as an Android app.
- Test with sample records first and export a backup before relying on it for business-critical records.
