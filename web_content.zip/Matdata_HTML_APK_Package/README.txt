Matdata Prabandhan 2026 - HTML package

Open index.html in a modern browser to use the web app.
For an HTML-to-APK wrapper that requires a ZIP, upload this ZIP file.
The ZIP contains index.html at its root.

Note: A WebView wrapper does not automatically provide Android Bluetooth Classic/SPP printing.
Native Android printer integration must be implemented and tested separately.
