// ======================================================
// BACKUP & RESTORE BISNISAPP
// ======================================================


// ======================================================
// DAFTAR DATABASE BISNISAPP
// ======================================================

const daftarDatabase = [

    "dataBarang",

    "dataDistributor",

    "dataFaktur",

    "dataPenjualan",

    "dataRetur",

    "pengaturanBisnis"

];


// ======================================================
// BACKUP DATA
// ======================================================

function backupData() {

    const backup = {

        aplikasi: "BisnisApp",

        versi: "1.0",

        tanggalBackup:
            new Date().toISOString(),

        data: {}

    };


    // ==================================================
    // AMBIL DATABASE YANG ADA
    // ==================================================

    daftarDatabase.forEach(function(key) {

        const data =
            localStorage.getItem(key);


        // Hanya simpan database yang memang ada
        if (data !== null) {

            try {

                backup.data[key] =
                    JSON.parse(data);

            }

            catch (error) {

                backup.data[key] =
                    data;

            }

        }

    });


    // ==================================================
    // BUAT FILE JSON
    // ==================================================

    const isiFile =
        JSON.stringify(
            backup,
            null,
            2
        );


    const blob =
        new Blob(
            [isiFile],
            {
                type: "application/json"
            }
        );


    const url =
        URL.createObjectURL(blob);


    const link =
        document.createElement("a");


    const tanggal =
        new Date()
        .toISOString()
        .slice(0, 10);


    link.href = url;

    link.download =
        "BisnisApp-Backup-" +
        tanggal +
        ".json";


    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);


    URL.revokeObjectURL(url);


    alert(
        "Backup berhasil dibuat.\n\n" +
        "Semua data BisnisApp yang tersedia telah disimpan."
    );

}


// ======================================================
// RESTORE DATA
// ======================================================

function restoreData() {

    const input =
        document.getElementById(
            "fileRestore"
        );


    // ==================================================
    // CEK FILE
    // ==================================================

    if (!input.files.length) {

        alert(
            "Pilih file backup terlebih dahulu."
        );

        return;

    }


    const file =
        input.files[0];


    const pembaca =
        new FileReader();


    pembaca.onload =
        function(event) {

            try {

                // ==========================================
                // BACA FILE
                // ==========================================

                const backup =
                    JSON.parse(
                        event.target.result
                    );


                // ==========================================
                // VALIDASI FILE
                // ==========================================

                if (
                    !backup ||
                    backup.aplikasi !== "BisnisApp" ||
                    !backup.data ||
                    typeof backup.data !== "object"
                ) {

                    alert(
                        "File backup tidak valid atau bukan backup BisnisApp."
                    );

                    return;

                }


                // ==========================================
                // KONFIRMASI
                // ==========================================

                const yakin =
                    confirm(

                        "PERINGATAN!\n\n" +

                        "Restore akan mengganti data BisnisApp saat ini.\n\n" +

                        "Pastikan Anda sudah mempunyai backup data sekarang.\n\n" +

                        "Lanjutkan restore?"

                    );


                if (!yakin) {

                    return;

                }


                // ==========================================
                // HAPUS DATABASE BISNISAPP LAMA
                // ==========================================

                daftarDatabase.forEach(
                    function(key) {

                        localStorage.removeItem(key);

                    }
                );


                // ==========================================
                // MASUKKAN DATA BACKUP
                // ==========================================

                Object.keys(
                    backup.data
                ).forEach(
                    function(key) {

                        // Hanya restore database
                        // yang memang digunakan BisnisApp

                        if (
                            daftarDatabase.includes(key)
                        ) {

                            const nilai =
                                backup.data[key];


                            localStorage.setItem(

                                key,

                                typeof nilai === "string"

                                    ? nilai

                                    : JSON.stringify(
                                        nilai
                                    )

                            );

                        }

                    }
                );


                // ==========================================
                // BERSIHKAN ID DETAIL FAKTUR SEMENTARA
                // ==========================================

                localStorage.removeItem(
                    "fakturDetailId"
                );


                // ==========================================
                // BERHASIL
                // ==========================================

                alert(

                    "Restore berhasil.\n\n" +

                    "Data BisnisApp telah dikembalikan.\n\n" +

                    "Aplikasi akan dimuat ulang."

                );


                location.replace(
                    "index.html");

            }


            catch(error) {

                console.error(
                    "Restore error:",
                    error
                );


                alert(

                    "File backup rusak atau tidak dapat dibaca.\n\n" +

                    "Pastikan file yang dipilih adalah backup BisnisApp."

                );

            }

        };


    // ==================================================
    // BACA FILE
    // ==================================================

    pembaca.readAsText(file);

}


// ======================================================
// HAPUS SEMUA DATA
// ======================================================

function hapusSemuaData() {

    // ==========================================
    // KONFIRMASI PERTAMA
    // ==========================================

    const pertama =
        confirm(

            "PERINGATAN BESAR!\n\n" +

            "Semua data BisnisApp akan dihapus.\n\n" +

            "Data yang akan dihapus:\n" +

            "• Barang\n" +

            "• Distributor\n" +

            "• Faktur\n" +

            "• Penjualan\n" +

            "• Retur\n" +

            "• Pengaturan\n\n" +

            "Tindakan ini tidak dapat dibatalkan.\n\n" +

            "Lanjutkan?"

        );


    if (!pertama) {

        return;

    }


    // ==========================================
    // KONFIRMASI KEDUA
    // ==========================================

    const kedua =
        prompt(

            "Untuk memastikan penghapusan,\n" +

            "ketik:\n\n" +

            "HAPUS"

        );


    if (kedua !== "HAPUS") {

        alert(
            "Penghapusan dibatalkan."
        );

        return;

    }


    // ==========================================
    // HAPUS DATABASE
    // ==========================================

    daftarDatabase.forEach(
        function(key) {

            localStorage.removeItem(key);

        }
    );


    // Hapus ID detail sementara

    localStorage.removeItem(
        "fakturDetailId"
    );


    // ==========================================
    // SELESAI
    // ==========================================

    alert(
        "Semua data BisnisApp berhasil dihapus."
    );


    location.replace(
        "index.html");

}