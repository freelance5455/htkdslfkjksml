// ======================================================
// DETAIL FAKTUR
// File: js/detail-faktur.js
// ======================================================


// ======================================================
// FORMAT RUPIAH
// ======================================================

function formatRupiahDetail(angka) {

    return "Rp " +
        Number(angka || 0)
        .toLocaleString("id-ID");

}


// ======================================================
// AMBIL FAKTUR YANG DIPILIH
// ======================================================

function ambilFaktur() {

    const id =
        localStorage.getItem("fakturDetailId");

    if (!id) {
        return null;
    }

    const data =
        JSON.parse(
            localStorage.getItem("dataFaktur") || "[]"
        );

    return data.find(function(f) {

        return String(f.id) === String(id);

    });

}


// ======================================================
// STATUS FAKTUR
// ======================================================

function statusFaktur(faktur) {

    const total =
        Number(faktur.total || 0);

    const retur =
        Number(faktur.totalRetur || 0);

    const dibayar =
        Number(faktur.totalDibayar || 0);

    const sisa =
        Math.max(0, total - retur - dibayar);

    if (sisa <= 0) {

        return {
            teks: "🟢 Lunas",
            className: "status-lunas"
        };

    }

    if (dibayar > 0) {

        return {
            teks: "🟡 Sebagian",
            className: "status-sebagian"
        };

    }

    return {
        teks: "🔴 Belum Lunas",
        className: "status-belum"
    };

}


// ======================================================
// TAMPILKAN DETAIL
// ======================================================

function tampilkanDetail() {

    const container =
        document.getElementById("detailFaktur");

    const faktur =
        ambilFaktur();

    if (!faktur) {

        container.innerHTML = `
            <div class="kosong">
                ❌ Data faktur tidak ditemukan.
            </div>
        `;

        return;
    }


    const total =
        Number(faktur.total || 0);

    const totalRetur =
        Number(faktur.totalRetur || 0);

    const totalDibayar =
        Number(faktur.totalDibayar || 0);

    const sisa =
        Math.max(
            0,
            total - totalRetur - totalDibayar
        );


    const status =
        statusFaktur(faktur);


    let html = `

        <div class="detail-card">

            <h2>${faktur.nomor}</h2>

            <div class="info-faktur">

                <div class="info-row">
                    <span>Tanggal</span>
                    <strong>${faktur.tanggal}</strong>
                </div>

                <div class="info-row">
                    <span>Distributor</span>
                    <strong>
                        ${faktur.distributorNama || "-"}
                    </strong>
                </div>

                <div class="info-row">
                    <span>Status</span>
                    <strong class="${status.className}">
                        ${status.teks}
                    </strong>
                </div>

            </div>

        </div>


        <div class="detail-card">

            <h3>📦 Barang</h3>

            <div class="tabel-detail">

                <table>

                    <thead>

                        <tr>
                            <th>No</th>
                            <th>Barang</th>
                            <th>Qty</th>
                            <th>Harga</th>
                            <th>Total</th>
                        </tr>

                    </thead>

                    <tbody>
    `;


    const detail =
        faktur.detail || [];


    detail.forEach(function(item, index) {

        const qty =
            Number(item.qty || 0);

        const harga =
            Number(
                item.harga ??
                item.hargaBeli ??
                0
            );

        const subtotal =
            Number(
                item.subtotal ??
                (qty * harga)
            );


        html += `

            <tr>

                <td>${index + 1}</td>

                <td>
                    <strong>${item.nama}</strong>
                    <br>
                    <small>${item.kode}</small>
                </td>

                <td>
                    ${qty} ${item.satuan || ""}
                </td>

                <td>
                    ${formatRupiahDetail(harga)}
                </td>

                <td>
                    ${formatRupiahDetail(subtotal)}
                </td>

            </tr>

        `;

    });


    html += `

                    </tbody>

                </table>

            </div>

        </div>


        <div class="detail-card">

            <h3>💰 Ringkasan Pembayaran</h3>

            <div class="total-box">

                <div class="total-row">
                    <span>Total Faktur</span>
                    <strong>
                        ${formatRupiahDetail(total)}
                    </strong>
                </div>

                <div class="total-row">
                    <span>Total Retur</span>
                    <strong>
                        ${formatRupiahDetail(totalRetur)}
                    </strong>
                </div>

                <div class="total-row">
                    <span>Sudah Dibayar</span>
                    <strong>
                        ${formatRupiahDetail(totalDibayar)}
                    </strong>
                </div>

                <div class="total-row total-utama">
                    <span>Sisa</span>
                    <strong>
                        ${formatRupiahDetail(sisa)}
                    </strong>
                </div>

            </div>


            <div class="aksi-faktur">

                <button
                    class="tombol-aksi tombol-retur"
                    onclick="bukaRetur()">

                    ↩️ Retur

                </button>


                <button
                    class="tombol-aksi tombol-bayar"
                    onclick="bukaPembayaran()">

                    💰 Bayar

                </button>

            </div>


            <button
                class="tombol-kembali"
                onclick="appBack('pembelian.html')">

                ← Kembali

            </button>

        </div>

    `;


    // ==================================================
    // RIWAYAT PEMBAYARAN
    // ==================================================

    if (
        faktur.riwayatPembayaran &&
        faktur.riwayatPembayaran.length > 0
    ) {

        html += `

            <div class="detail-card">

                <h3>💳 Riwayat Pembayaran</h3>

        `;


        faktur.riwayatPembayaran
            .slice()
            .reverse()
            .forEach(function(bayar) {

                html += `

                    <div class="pembayaran-item">

                        <strong>
                            ${formatRupiahDetail(bayar.jumlah)}
                        </strong>

                        <br>

                        <small>
                            ${bayar.tanggal || ""}
                            ${bayar.waktu || ""}
                            ${bayar.keterangan
                                ? " - " + bayar.keterangan
                                : ""}
                        </small>

                    </div>

                `;

            });


        html += `
            </div>
        `;

    }


    container.innerHTML = html;

}


// ======================================================
// BUKA RETUR
// ======================================================

function bukaRetur() {

    location.replace("retur.html");

}


// ======================================================
// BUKA PEMBAYARAN
// ======================================================

function bukaPembayaran() {

    const id =
        localStorage.getItem("fakturDetailId");

    location.replace(
    "pembayaran.html?faktur=" + id);
}


// ======================================================
// JALANKAN
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    tampilkanDetail
);