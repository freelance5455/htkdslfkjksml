/* =====================================================
   KASIR / PENJUALAN
   ===================================================== */


/* ============================= */
/* DATA KERANJANG */
/* ============================= */

let keranjangKasir = [];


/* ============================= */
/* AMBIL DATA BARANG TERBARU */
/* ============================= */

function ambilDataBarangKasir() {

    return JSON.parse(
        localStorage.getItem("dataBarang") || "[]"
    );

}


/* ============================= */
/* FORMAT RUPIAH */
/* ============================= */

function formatRupiah(angka) {

    angka = Number(angka) || 0;

    return "Rp " + angka.toLocaleString("id-ID");

}


/* ============================= */
/* TOMBOL TAMBAH BARANG */
/* ============================= */

function fokusCariBarang() {

    const input = document.getElementById("cariBarangKasir");

    if (!input) return;

    input.focus();

    /*
       Kalau pencarian masih kosong,
       tampilkan semua barang.
    */

    if (input.value.trim() === "") {

        cariBarangKasir();

    }

}


/* ============================= */
/* CARI BARANG */
/* ============================= */

function cariBarangKasir() {

    const input =
        document.getElementById("cariBarangKasir");

    const container =
        document.getElementById("hasilPencarianBarang");

    if (!input || !container) return;


    const kata =
        input.value.trim().toLowerCase();


    const dataBarang =
        ambilDataBarangKasir();


    if (dataBarang.length === 0) {

        container.innerHTML = `
            <div class="keranjang-kosong">
                Belum ada barang di Data Barang.
            </div>
        `;

        return;

    }


    let hasil;


    /*
       Kalau pencarian kosong,
       tampilkan semua barang.
    */

    if (kata === "") {

        hasil = dataBarang;

    } else {

        hasil = dataBarang.filter(function(barang) {

            const kode =
                String(barang.kode || "").toLowerCase();

            const nama =
                String(barang.nama || "").toLowerCase();

            return (
                kode.includes(kata) ||
                nama.includes(kata)
            );

        });

    }


    if (hasil.length === 0) {

        container.innerHTML = `
            <div class="keranjang-kosong">
                Barang tidak ditemukan.
            </div>
        `;

        return;

    }


    let html = `
        <div class="hasil-barang-kasir">
    `;


    hasil.forEach(function(barang) {

        const stok =
            Number(barang.stok) || 0;

        const harga =
            Number(barang.hargaJual) || 0;


        html += `

            <div class="item-hasil-kasir">

                <div class="info-hasil-kasir">

                    <div class="nama-hasil-kasir">
                        ${escapeHtmlKasir(barang.nama)}
                    </div>

                    <div class="detail-hasil-kasir">
                        Kode: ${escapeHtmlKasir(barang.kode || "-")}
                        • Stok: ${stok}
                        ${escapeHtmlKasir(barang.satuan || "")}
                    </div>

                    <div class="harga-hasil-kasir">
                        ${formatRupiah(harga)}
                    </div>

                </div>


                <button
                    type="button"
                    class="tombol-pilih-kasir"
                    onclick="tambahKeKeranjang('${barang.id}')"
                    ${stok <= 0 ? "disabled" : ""}
                >
                    ${stok <= 0 ? "Habis" : "➕ Tambah"}
                </button>

            </div>

        `;

    });


    html += `
        </div>
    `;


    container.innerHTML = html;

}


/* ============================= */
/* ESCAPE HTML */
/* ============================= */

function escapeHtmlKasir(text) {

    return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* ============================= */
/* TAMBAH KE KERANJANG */
/* ============================= */

function tambahKeKeranjang(idBarang) {

    const dataBarang =
        ambilDataBarangKasir();


    const barang =
        dataBarang.find(function(item) {

            return String(item.id) === String(idBarang);

        });


    if (!barang) {

        alert("Barang tidak ditemukan.");

        return;

    }


    const stok =
        Number(barang.stok) || 0;


    if (stok <= 0) {

        alert("Stok barang habis.");

        return;

    }


    /*
       Cek apakah barang sudah ada
       di keranjang.
    */

    const index =
        keranjangKasir.findIndex(function(item) {

            return String(item.id) === String(idBarang);

        });


    if (index !== -1) {

        /*
           Kalau sudah ada,
           tambah qty 1.
        */

        const qtyBaru =
            Number(keranjangKasir[index].qty) + 1;


        if (qtyBaru > stok) {

            alert(
                "Jumlah melebihi stok yang tersedia."
            );

            return;

        }


        keranjangKasir[index].qty =
            qtyBaru;


    } else {

        /*
           Kalau belum ada,
           masukkan barang baru.
        */

        keranjangKasir.push({

            id: barang.id,

            kode: barang.kode,

            nama: barang.nama,

            satuan: barang.satuan,

            hargaJual:
                Number(barang.hargaJual) || 0,

            hargaBeli:
                Number(barang.hargaBeli) || 0,

            qty: 1

        });

    }


    tampilkanKeranjangKasir();

    hitungTotalKasir();

    /*
       Jangan menutup hasil pencarian.
       Jadi pengguna bisa langsung
       memilih barang kedua, ketiga, dst.
    */

}


/* ============================= */
/* TAMPILKAN KERANJANG */
/* ============================= */

function tampilkanKeranjangKasir() {

    const container =
        document.getElementById("keranjangKasir");

    if (!container) return;


    if (keranjangKasir.length === 0) {

        container.innerHTML = `
            <div class="keranjang-kosong">
                Belum ada barang.
                <br>
                Silakan tambahkan barang.
            </div>
        `;

        return;

    }


    let html = "";


    keranjangKasir.forEach(function(item, index) {

        const qty =
            Number(item.qty) || 0;

        const harga =
            Number(item.hargaJual) || 0;

        const totalItem =
            harga * qty;


        html += `

            <div class="item-keranjang">

                <div class="info-keranjang">

                    <div class="nama-keranjang">
                        ${escapeHtmlKasir(item.nama)}
                    </div>

                    <div class="kode-keranjang">
                        ${escapeHtmlKasir(item.kode || "-")}
                    </div>

                    <div class="harga-keranjang">
                        ${formatRupiah(harga)}
                        / ${escapeHtmlKasir(item.satuan || "pcs")}
                    </div>

                </div>


                <div class="kontrol-qty">

                    <div class="tombol-qty">

                        <button
                            type="button"
                            onclick="ubahQtyKasir(${index}, -1)"
                        >
                            −
                        </button>


                        <input
                            type="number"
                            class="input-qty-kasir"
                            value="${qty}"
                            min="1"
                            onchange="ubahQtyLangsungKasir(${index}, this.value)"
                        >


                        <button
                            type="button"
                            onclick="ubahQtyKasir(${index}, 1)"
                        >
                            +
                        </button>

                    </div>


                    <div class="total-item-kasir">
                        ${formatRupiah(totalItem)}
                    </div>

                </div>


                <button
                    type="button"
                    class="tombol-hapus-item"
                    onclick="hapusDariKeranjang(${index})"
                >
                    🗑️ Hapus Barang
                </button>

            </div>

        `;

    });


    container.innerHTML = html;

}


/* ============================= */
/* UBAH QTY + / - */
/* ============================= */

function ubahQtyKasir(index, perubahan) {

    if (!keranjangKasir[index]) return;


    const dataBarang =
        ambilDataBarangKasir();


    const item =
        keranjangKasir[index];


    const barang =
        dataBarang.find(function(b) {

            return String(b.id) === String(item.id);

        });


    if (!barang) {

        keranjangKasir.splice(index, 1);

        tampilkanKeranjangKasir();

        hitungTotalKasir();

        alert("Barang sudah dihapus dari Data Barang.");

        return;

    }


    const stok =
        Number(barang.stok) || 0;


    let qtyBaru =
        Number(item.qty) + Number(perubahan);


    if (qtyBaru < 1) {

        hapusDariKeranjang(index);

        return;

    }


    if (qtyBaru > stok) {

        alert(
            "Jumlah melebihi stok yang tersedia."
        );

        return;

    }


    item.qty = qtyBaru;


    tampilkanKeranjangKasir();

    hitungTotalKasir();

}


/* ============================= */
/* UBAH QTY LANGSUNG */
/* ============================= */

function ubahQtyLangsungKasir(index, nilai) {

    if (!keranjangKasir[index]) return;


    const dataBarang =
        ambilDataBarangKasir();


    const item =
        keranjangKasir[index];


    const barang =
        dataBarang.find(function(b) {

            return String(b.id) === String(item.id);

        });


    if (!barang) {

        keranjangKasir.splice(index, 1);

        tampilkanKeranjangKasir();

        hitungTotalKasir();

        alert("Barang sudah dihapus dari Data Barang.");

        return;

    }


    const stok =
        Number(barang.stok) || 0;


    let qty =
        parseInt(nilai);


    if (isNaN(qty) || qty < 1) {

        qty = 1;

    }


    if (qty > stok) {

        alert(
            "Jumlah melebihi stok yang tersedia."
        );

        qty = stok;

    }


    if (qty < 1) {

        keranjangKasir.splice(index, 1);

    } else {

        item.qty = qty;

    }


    tampilkanKeranjangKasir();

    hitungTotalKasir();

}


/* ============================= */
/* HAPUS BARANG */
/* ============================= */

function hapusDariKeranjang(index) {

    keranjangKasir.splice(index, 1);

    tampilkanKeranjangKasir();

    hitungTotalKasir();

}


/* ============================= */
/* HITUNG TOTAL */
/* ============================= */

function hitungTotalKasir() {

    let subtotal = 0;


    keranjangKasir.forEach(function(item) {

        subtotal +=
            (Number(item.hargaJual) || 0) *
            (Number(item.qty) || 0);

    });


    const inputDiskon =
        document.getElementById("diskonKasir");


    let diskon =
        nilaiUangInput(inputDiskon);


    if (diskon < 0) {

        diskon = 0;

    }


    if (diskon > subtotal) {

        diskon = subtotal;

    }


    if (inputDiskon) {

        inputDiskon.value = diskon;

    }


    const total =
        subtotal - diskon;


    const subtotalEl =
        document.getElementById("subtotalKasir");


    const totalEl =
        document.getElementById("totalKasir");


    if (subtotalEl) {

        subtotalEl.textContent =
            formatRupiah(subtotal);

    }


    if (totalEl) {

        totalEl.textContent =
            formatRupiah(total);

    }


    hitungKembalian();

}


/* ============================= */
/* HITUNG KEMBALIAN */
/* ============================= */

function hitungKembalian() {

    let subtotal = 0;


    keranjangKasir.forEach(function(item) {

        subtotal +=
            (Number(item.hargaJual) || 0) *
            (Number(item.qty) || 0);

    });


    const diskonInput =
        document.getElementById("diskonKasir");


    const bayarInput =
        document.getElementById("uangBayar");


    const diskon =
        nilaiUangInput(diskonInput);


    const dibayar =
        nilaiUangInput(bayarInput);


    const total =
        Math.max(0, subtotal - diskon);


    const kembalian =
        Math.max(0, dibayar - total);


    const kembalianEl =
        document.getElementById("kembalianKasir");


    if (kembalianEl) {

        kembalianEl.textContent =
            formatRupiah(kembalian);

    }

}


/* ============================= */
/* BERSIHKAN KERANJANG */
/* ============================= */

function bersihkanKeranjang() {

    if (keranjangKasir.length === 0) {

        return;

    }


    const yakin =
        confirm(
            "Bersihkan semua barang dari keranjang?"
        );


    if (!yakin) return;


    keranjangKasir = [];


    const diskon =
        document.getElementById("diskonKasir");


    const bayar =
        document.getElementById("uangBayar");


    const cari =
        document.getElementById("cariBarangKasir");


    if (diskon) {

        diskon.value = 0;

    }


    if (bayar) {

        bayar.value = "";

    }


    if (cari) {

        cari.value = "";

    }


    tampilkanKeranjangKasir();

    hitungTotalKasir();

    cariBarangKasir();

}


/* ============================= */
/* SIMPAN PENJUALAN */
/* ============================= */

function simpanPenjualan() {

    if (keranjangKasir.length === 0) {

        alert(
            "Tambahkan barang terlebih dahulu."
        );

        return;

    }


    const dataBarang =
        ambilDataBarangKasir();


    /*
       CEK SEMUA BARANG
       sebelum stok dikurangi.
    */

    for (const item of keranjangKasir) {

        const barang =
            dataBarang.find(function(b) {

                return String(b.id) === String(item.id);

            });


        if (!barang) {

            alert(
                "Barang " +
                item.nama +
                " sudah tidak tersedia."
            );

            return;

        }


        const stok =
            Number(barang.stok) || 0;


        const qty =
            Number(item.qty) || 0;


        if (qty > stok) {

            alert(
                "Stok " +
                item.nama +
                " tidak mencukupi."
            );

            return;

        }

    }


    /* ============================= */
    /* HITUNG TOTAL */
    /* ============================= */

    let subtotal = 0;

    let modal = 0;


    const detail = keranjangKasir.map(function(item) {

        const qty =
            Number(item.qty) || 0;

        const hargaJual =
            Number(item.hargaJual) || 0;

        const hargaBeli =
            Number(item.hargaBeli) || 0;


        subtotal +=
            hargaJual * qty;


        modal +=
            hargaBeli * qty;


        return {

            id: item.id,

            kode: item.kode,

            nama: item.nama,

            satuan: item.satuan,

            qty: qty,

            hargaJual: hargaJual,

            hargaBeli: hargaBeli,

            total:
                hargaJual * qty

        };

    });


    const diskonInput =
        document.getElementById("diskonKasir");


    const bayarInput =
        document.getElementById("uangBayar");


    let diskon =
        Number(
            diskonInput ? diskonInput.value : 0
        ) || 0;


    const dibayar =
        Number(
            bayarInput ? bayarInput.value : 0
        ) || 0;


    if (diskon < 0) {

        diskon = 0;

    }


    if (diskon > subtotal) {

        diskon = subtotal;

    }


    const total =
        subtotal - diskon;


    if (dibayar < total) {

        alert(
            "Uang bayar masih kurang."
        );

        return;

    }


    const kembalian =
        dibayar - total;


    const labaKotor =
        total - modal;


    /* ============================= */
    /* KURANGI STOK */
    /* ============================= */

    keranjangKasir.forEach(function(item) {

        const index =
            dataBarang.findIndex(function(b) {

                return String(b.id) === String(item.id);

            });


        if (index !== -1) {

            dataBarang[index].stok =
                Number(dataBarang[index].stok || 0) -
                Number(item.qty || 0);

        }

    });


    localStorage.setItem(
        "dataBarang",
        JSON.stringify(dataBarang)
    );


    /* ============================= */
    /* DATA PENJUALAN */
    /* ============================= */

    const dataPenjualan =
        JSON.parse(
            localStorage.getItem("dataPenjualan") || "[]"
        );


    const sekarang =
        new Date();


    const penjualan = {

        id:
            Date.now().toString(),

        tanggal:
            sekarang.toISOString(),

        detail:
            detail,

        subtotal:
            subtotal,

        diskon:
            diskon,

        total:
            total,

        dibayar:
            dibayar,

        kembalian:
            kembalian,

        modal:
            modal,

        labaKotor:
            labaKotor

    };


    dataPenjualan.push(penjualan);


    localStorage.setItem(
        "dataPenjualan",
        JSON.stringify(dataPenjualan)
    );


    /* ============================= */
    /* RESET */
    /* ============================= */

    keranjangKasir = [];


    if (diskonInput) {

        diskonInput.value = 0;

    }


    if (bayarInput) {

        bayarInput.value = "";

    }


    const cari =
        document.getElementById("cariBarangKasir");


    if (cari) {

        cari.value = "";

    }


    tampilkanKeranjangKasir();

    hitungTotalKasir();

    cariBarangKasir();

    tampilkanRiwayatPenjualan();


    alert(
        "Penjualan berhasil disimpan."
    );

}


/* ============================= */
/* RIWAYAT PENJUALAN */
/* ============================= */

/* ============================= */
/* BUKA TRANSAKSI DARI KASIR */
/* ============================= */

function bukaRiwayatKasir(idPenjualan) {

    /*
       Simpan ID transaksi yang dipilih.
       Halaman Riwayat Penjualan akan
       otomatis membuka transaksi tersebut.
    */

    localStorage.setItem(
        "penjualanTerpilihId",
        String(idPenjualan)
    );

    location.href = "riwayat-penjualan.html";
}


/* ============================= */
/* RIWAYAT PENJUALAN */
/* ============================= */

function tampilkanRiwayatPenjualan() {
    const container =
        document.getElementById("riwayatPenjualan");


    if (!container) return;


    const dataPenjualan =
        JSON.parse(
            localStorage.getItem("dataPenjualan") || "[]"
        );


    if (dataPenjualan.length === 0) {

        container.innerHTML = `
            <div class="keranjang-kosong">
                Belum ada riwayat penjualan.
            </div>
        `;

        return;

    }


    const input =
        document.getElementById("cariPenjualan");


    const kata =
        input
            ? input.value.trim().toLowerCase()
            : "";


    let hasil =
        [...dataPenjualan].reverse();


    if (kata !== "") {

        hasil = hasil.filter(function(penjualan) {

            const teks =
                JSON.stringify(penjualan)
                    .toLowerCase();

            return teks.includes(kata);

        });

    }


    if (hasil.length === 0) {

        container.innerHTML = `
            <div class="keranjang-kosong">
                Penjualan tidak ditemukan.
            </div>
        `;

        return;

    }


    let html = "";


    hasil.forEach(function(penjualan) {

        const tanggal =
            new Date(penjualan.tanggal);


        const tanggalTampil =
            tanggal.toLocaleDateString(
                "id-ID",
                {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric"
                }
            );


        const jumlahBarang =
            Array.isArray(penjualan.detail)
                ? penjualan.detail.reduce(
                    function(total, item) {
                        return total +
                            Number(item.qty || 0);
                    },
                    0
                )
                : 0;


        html += `

            <div
    class="item-riwayat-penjualan"
    onclick="bukaRiwayatKasir('${String(penjualan.id)}')"
    style="cursor:pointer;"
>

    <div class="judul-riwayat">

                <div class="detail-riwayat">
                    ${jumlahBarang} barang
                    • Diskon ${formatRupiah(penjualan.diskon || 0)}
                </div>

                <div class="total-riwayat">
                    Total:
                    ${formatRupiah(penjualan.total)}
                </div>

            </div>

        `;

    });


    container.innerHTML = html;

}


/* ============================= */
/* SAAT HALAMAN DIBUKA */
/* ============================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanKeranjangKasir();

        hitungTotalKasir();

        tampilkanRiwayatPenjualan();

        /*
           Jangan langsung menampilkan semua barang
           sampai tombol Tambah Barang ditekan.
        */

    }
);
// POS V2: tombol nominal pembayaran cepat
window.isiUangCepat = function(nominal) {
    const el = document.getElementById("uangBayar");
    if (!el) return;
    el.value = Number(nominal).toLocaleString("id-ID");
    if (typeof hitungKembalian === "function") hitungKembalian();
};
