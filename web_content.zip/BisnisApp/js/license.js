/* =========================================================
   BISNISAPP — TRIAL & LISENSI OFFLINE
   Trial default: 1 x 24 jam.
   Catatan: versi HTML tidak dapat membaca IMEI Android secara
   konsisten. Pengikatan utama menggunakan Device ID lokal.
========================================================= */
(function () {
  'use strict';

  const TRIAL_MS = 24 * 60 * 60 * 1000;
  const SECRET = 'BISNISAPP-OFFLINE-LICENSE-V1-CHANGE-ME-2026';
  const KEYS = {
    state: 'bisnisAppLicenseState',
    device: 'bisnisAppDeviceId',
    started: 'bisnisAppTrialStartedAt',
    lastSeen: 'bisnisAppTrialLastSeenAt'
  };

  const page = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const PUBLIC_PAGES = new Set(['license.html']);

  function getDeviceId() {
    let id = localStorage.getItem(KEYS.device);
    if (!id) {
      const raw = (crypto.randomUUID ? crypto.randomUUID() : ('xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c){
        const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8); return v.toString(16);
      }))).replace(/-/g, '').toUpperCase();
      id = raw.slice(0, 4) + '-' + raw.slice(4, 8) + '-' + raw.slice(8, 12) + '-' + raw.slice(12, 20);
      localStorage.setItem(KEYS.device, id);
    }
    return id;
  }

  function deviceName() {
    const ua = navigator.userAgent || '';
    if (/Android/i.test(ua)) {
      const m = ua.match(/Android[^;)]*;\s*(?:[a-z]{2}-[A-Z]{2};\s*)?([^;)]+?)(?:\s+Build\/[^;)]*)?[;)]/i);
      if (m && m[1]) return m[1].trim();
      return 'Perangkat Android';
    }
    if (/iPhone/i.test(ua)) return 'iPhone';
    if (/iPad/i.test(ua)) return 'iPad';
    return 'Perangkat Web';
  }

  function b64url(str) {
    return btoa(unescape(encodeURIComponent(str))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
  }
  function fromB64url(str) {
    str = String(str).replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    return decodeURIComponent(escape(atob(str)));
  }
  async function sha256Hex(text) {
    const data = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  async function makeSignature(payload) {
    return (await sha256Hex(SECRET + '|' + payload)).slice(0, 24).toUpperCase();
  }

  async function createSerial(data) {
    const payload = b64url(JSON.stringify(data));
    const sig = await makeSignature(payload);
    return 'BAPP1.' + payload + '.' + sig;
  }

  async function verifySerial(serial) {
    try {
      const parts = String(serial || '').trim().split('.');
      if (parts.length !== 3 || parts[0] !== 'BAPP1') return { ok:false, reason:'Format serial tidak dikenali.' };
      const expected = await makeSignature(parts[1]);
      if (expected !== parts[2].toUpperCase()) return { ok:false, reason:'Serial number tidak valid.' };
      const data = JSON.parse(fromB64url(parts[1]));
      const now = Date.now();
      if (!data.deviceId || data.deviceId !== getDeviceId()) return { ok:false, reason:'Serial ini terdaftar untuk perangkat lain.' };
      if (data.expiresAt && now > Number(data.expiresAt)) return { ok:false, reason:'Masa berlaku serial sudah berakhir.' };
      if (data.model && data.model !== deviceName()) return { ok:false, reason:'Nama perangkat tidak sesuai dengan lisensi.' };
      return { ok:true, data };
    } catch (e) {
      return { ok:false, reason:'Serial number tidak dapat dibaca.' };
    }
  }

  function ensureTrial() {
    let started = Number(localStorage.getItem(KEYS.started) || 0);
    const now = Date.now();
    if (!started) {
      started = now;
      localStorage.setItem(KEYS.started, String(started));
      localStorage.setItem(KEYS.lastSeen, String(now));
    }
    const lastSeen = Number(localStorage.getItem(KEYS.lastSeen) || started);
    if (now < lastSeen) {
      return { active:false, tampered:true, remaining:0, startedAt:started, expiresAt:started + TRIAL_MS };
    }
    localStorage.setItem(KEYS.lastSeen, String(now));
    const expiresAt = started + TRIAL_MS;
    return { active: now < expiresAt, tampered:false, remaining: Math.max(0, expiresAt - now), startedAt:started, expiresAt };
  }

  function getLicense() {
    try { return JSON.parse(localStorage.getItem(KEYS.state) || 'null'); } catch (_) { return null; }
  }

  function saveLicense(data, serial) {
    const record = Object.assign({}, data, { serial: serial, activatedAt: Date.now() });
    localStorage.setItem(KEYS.state, JSON.stringify(record));
    return record;
  }

  function formatDate(ts) {
    if (!ts) return '-';
    return new Date(Number(ts)).toLocaleDateString('id-ID', { day:'2-digit', month:'2-digit', year:'numeric' });
  }
  function formatRemaining(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const d = Math.floor(total / 86400);
    const h = Math.floor((total % 86400) / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    if (d > 0) return d + ' hari ' + h + ' jam';
    if (h > 0) return h + ' jam ' + m + ' menit';
    return m + ' menit ' + s + ' detik';
  }

  window.bisnisAppLicense = {
    TRIAL_MS, getDeviceId, deviceName, getLicense, ensureTrial, verifySerial,
    createSerial, saveLicense, formatDate, formatRemaining,
    getStatus: function () {
      const lic = getLicense();
      if (lic && (!lic.expiresAt || Date.now() <= Number(lic.expiresAt))) return { type:'licensed', license:lic };
      const trial = ensureTrial();
      return { type: trial.active ? 'trial' : 'expired', trial:trial, license:null };
    }
  };

  async function protectPage() {
    if (PUBLIC_PAGES.has(page)) return;
    const lic = getLicense();
    if (lic && (!lic.expiresAt || Date.now() <= Number(lic.expiresAt))) return;
    const trial = ensureTrial();
    if (!trial.active || trial.tampered) {
      location.replace('license.html?expired=1');
    }
  }

  function addTrialBadge() {
    if (PUBLIC_PAGES.has(page)) return;
    const status = window.bisnisAppLicense.getStatus();
    if (status.type !== 'trial') return;
    const badge = document.createElement('div');
    badge.className = 'license-mini-badge';
    badge.innerHTML = '<span>●</span> Trial · ' + formatRemaining(status.trial.remaining);
    badge.title = 'Buka Lisensi untuk melihat detail';
    badge.onclick = function () { location.href = 'license.html'; };
    document.body.appendChild(badge);
  }

  window.addEventListener('DOMContentLoaded', function () {
    protectPage().then(function () {
      addTrialBadge();
    });
  });
})();
