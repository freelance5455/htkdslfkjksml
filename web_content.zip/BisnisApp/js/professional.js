/* =========================================================
   BISNISAPP — PROFESSIONAL MOBILE UX
   Format uang, notifikasi, onboarding, dan kontrol keluar.
========================================================= */

(function () {
    "use strict";

    // ---------- FORMAT ANGKA UANG ----------
    window.nilaiUangInput = function (inputOrId) {
        const el = typeof inputOrId === "string"
            ? document.getElementById(inputOrId)
            : inputOrId;
        if (!el) return 0;
        const raw = String(el.value ?? "").replace(/[^\d]/g, "");
        return Number(raw) || 0;
    };

    window.formatAngkaUang = function (value) {
        const angka = Number(value) || 0;
        return angka.toLocaleString("id-ID");
    };

    function pasangFormatUang(el) {
        if (!el || el.dataset.moneyReady === "1") return;
        el.dataset.moneyReady = "1";

        const format = function () {
            const angka = String(el.value ?? "").replace(/[^\d]/g, "");
            el.value = angka ? Number(angka).toLocaleString("id-ID") : "";
        };

        el.addEventListener("input", format);
        el.addEventListener("blur", format);
        el.addEventListener("focus", function () {
            // Tetap tampil dengan titik agar mudah dibaca.
            format();
            try { el.select(); } catch (_) {}
        });
    }

    function siapkanInputUang() {
        document.querySelectorAll("[data-money-input]").forEach(pasangFormatUang);
    }

    // ---------- NOTIFIKASI ----------
    window.notifikasiApp = function (judul, pesan, tipe) {
        tipe = tipe || "info";
        let box = document.getElementById("notifikasiAppGlobal");

        if (!box) {
            box = document.createElement("div");
            box.id = "notifikasiAppGlobal";
            box.className = "notifikasi-app-global";
            box.innerHTML =
                '<div class="notifikasi-app-icon"></div>' +
                '<div class="notifikasi-app-copy">' +
                '<strong class="notifikasi-app-judul"></strong>' +
                '<span class="notifikasi-app-pesan"></span>' +
                '</div>';
            document.body.appendChild(box);
        }

        const icons = { success: "✓", error: "!", warning: "!", info: "i" };
        box.querySelector(".notifikasi-app-icon").textContent = icons[tipe] || "i";
        box.querySelector(".notifikasi-app-judul").textContent = judul;
        box.querySelector(".notifikasi-app-pesan").textContent = pesan;
        box.className = "notifikasi-app-global tampil " + tipe;

        clearTimeout(window.__bisnisAppNotifTimer);
        window.__bisnisAppNotifTimer = setTimeout(function () {
            box.classList.remove("tampil");
        }, 3800);
    };

    // ---------- ALERT MODERN ----------
    // Ganti dialog bawaan "Laman pada http://localhost menyatakan"
    // dengan notifikasi BisnisApp yang konsisten.
    window.alert = function (pesan) {
        if (typeof window.notifikasiApp === "function") {
            window.notifikasiApp("Pemberitahuan", String(pesan || ""), "warning");
        } else {
            console.warn("BisnisApp:", pesan);
        }
    };

    // ---------- KELUAR / LOGOUT ----------
    let sedangKeluar = false;

    window.logoutBisnisApp = function (alasan) {
        if (sedangKeluar) return;
        sedangKeluar = true;

        // Data bisnis di localStorage TIDAK dihapus.
        // Hanya sesi halaman yang dibersihkan.
        try {
            sessionStorage.removeItem("bisnisAppCurrentPage");
            sessionStorage.removeItem("bisnisAppPreviousPage");
            sessionStorage.setItem("bisnisAppLoggedOut", "1");
        } catch (_) {}

        notifikasiApp(
            "Berhasil keluar",
            alasan || "Sesi aplikasi telah ditutup. Data bisnis tetap aman.",
            "success"
        );

        setTimeout(function () {
            location.replace("index.html?logout=1");
        }, 650);
    };

    // NAVIGASI INTERNAL TANPA MENAMBAH HISTORY
    // Semua link HTML internal diarahkan memakai replace(), sehingga setiap
    // halaman menggantikan halaman sebelumnya. Ini mencegah Back Android
    // mengulang 10-20 halaman yang pernah dibuka.
    document.addEventListener("click", function (event) {
        const anchor = event.target && event.target.closest ? event.target.closest("a[href]") : null;
        if (!anchor) return;
        if (anchor.target && anchor.target !== "_self") return;
        const raw = anchor.getAttribute("href") || "";
        if (!raw || raw.startsWith("#") || raw.startsWith("javascript:")) return;
        try {
            const url = new URL(anchor.href, location.href);
            if (url.origin !== location.origin) return;
            if (!/\.html(?:$|[?#])/i.test(url.pathname)) return;
            event.preventDefault();
            location.replace(url.href);
        } catch (_) {}
    }, true);

    // Jangan mengambil alih event Back Android dengan popstate.
    // Navigasi internal memakai location.replace(), sehingga halaman tidak
    // menumpuk di history. Back Android kemudian diserahkan ke WebView/native host.

    // Tombol Home Android biasanya membuat halaman menjadi hidden.
    // Ini tidak bisa dibedakan sempurna dari berpindah aplikasi/lock screen.
    document.addEventListener("visibilitychange", function () {
        if (document.visibilityState === "hidden" && !sedangKeluar) {
            try { sessionStorage.setItem("bisnisAppPendingLogout", "1"); } catch (_) {}
        }
        if (document.visibilityState === "visible") {
            try {
                if (sessionStorage.getItem("bisnisAppPendingLogout") === "1") {
                    sessionStorage.removeItem("bisnisAppPendingLogout");
                    logoutBisnisApp("Aplikasi dibuka kembali setelah tombol Home. Sesi sebelumnya ditutup.");
                }
            } catch (_) {}
        }
    });

    // ---------- TOMBOL KELUAR APLIKASI GLOBAL ----------
    function buatTombolKeluar() {
        if (document.getElementById("bisnisAppExitButton")) return;

        const btn = document.createElement("button");
        btn.type = "button";
        btn.id = "bisnisAppExitButton";
        btn.className = "bisnisapp-exit-btn";
        btn.innerHTML = '<span class="exit-icon">↪</span><span class="exit-label">Keluar</span>';
        btn.setAttribute("aria-label", "Keluar aplikasi");
        btn.addEventListener("click", function () {
            const shade = document.getElementById("bisnisAppExitShade");
            if (shade) shade.classList.add("show");
        });
        document.body.appendChild(btn);

        const shade = document.createElement("div");
        shade.id = "bisnisAppExitShade";
        shade.className = "bisnisapp-exit-shade";
        shade.innerHTML =
            '<div class="bisnisapp-exit-dialog" role="dialog" aria-modal="true" aria-labelledby="judulKeluarApp">' +
            '<h3 id="judulKeluarApp">Keluar dari BisnisApp?</h3>' +
            '<p>Sesi aplikasi akan ditutup. Data bisnis tetap tersimpan dan tidak akan dihapus.</p>' +
            '<div class="bisnisapp-exit-actions">' +
            '<button type="button" class="bisnisapp-exit-cancel">Batal</button>' +
            '<button type="button" class="bisnisapp-exit-confirm">Keluar Aplikasi</button>' +
            '</div></div>';
        document.body.appendChild(shade);

        shade.querySelector(".bisnisapp-exit-cancel").addEventListener("click", function () {
            shade.classList.remove("show");
        });
        shade.addEventListener("click", function (e) {
            if (e.target === shade) shade.classList.remove("show");
        });
        shade.querySelector(".bisnisapp-exit-confirm").addEventListener("click", function () {
            // Jika WebView Android menyediakan bridge penutup aplikasi, gunakan.
            try {
                if (window.Android && typeof window.Android.closeApp === "function") {
                    window.Android.closeApp(); return;
                }
                if (window.App && typeof window.App.exitApp === "function") {
                    window.App.exitApp(); return;
                }
                if (window.navigator && navigator.app && typeof navigator.app.exitApp === "function") {
                    navigator.app.exitApp(); return;
                }
            } catch (_) {}

            // Fallback untuk HTML/WebView tanpa native bridge: tutup sesi,
            // pertahankan data, lalu kembali ke halaman awal.
            shade.classList.remove("show");
            logoutBisnisApp("Aplikasi ditutup. Data bisnis tetap aman.");
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        siapkanInputUang();
        buatTombolKeluar();

        // Format ulang input yang sudah berisi angka.
        document.querySelectorAll("[data-money-input]").forEach(function (el) {
            if (el.value) el.value = formatAngkaUang(String(el.value).replace(/[^\d]/g, ""));
        });

        // Bantuan cepat di halaman dashboard untuk pengguna baru.
        if (location.pathname.endsWith("index.html") || location.pathname.endsWith("/")) {
            const isLogout = new URLSearchParams(location.search).get("logout") === "1";
            if (isLogout) {
                setTimeout(function () {
                    notifikasiApp("Sampai jumpa", "Anda sudah keluar dari sesi aplikasi.", "info");
                }, 700);
            }

            try {
                if (localStorage.getItem("bisnisAppOnboardingDone") !== "1" && !isLogout) {
                    const modal = document.getElementById("panduanPemulaModal");
                    if (modal) modal.classList.add("tampil");
                }
            } catch (_) {}
        }
    });

    window.tutupPanduanPemula = function () {
        const modal = document.getElementById("panduanPemulaModal");
        if (modal) modal.classList.remove("tampil");
        try { localStorage.setItem("bisnisAppOnboardingDone", "1"); } catch (_) {}
    };

    window.bukaPanduanPemula = function () {
        const modal = document.getElementById("panduanPemulaModal");
        if (modal) modal.classList.add("tampil");
    };
})();


/* =========================================================
   TABEL LENGKAP — UI ONLY
   Menambahkan mode layar penuh untuk tabel tanpa menyentuh
   data, sorting, pencarian, atau fungsi transaksi.
========================================================= */
(function () {
    function siapkanModeTabelLengkap() {
        const tables = document.querySelectorAll(
            '.tabel-container, .tabel-detail, .tabel-distributor, .tabel-riwayat, .tabel-scroll, .tabel-pembelian, .tabel-retur, .tabel-laporan'
        );

        tables.forEach(function (container) {
            if (container.dataset.fullTableReady === '1') return;
            const table = container.querySelector('table');
            if (!table) return;

            container.dataset.fullTableReady = '1';
            container.classList.add('table-fullscreen-container');

            const trigger = document.createElement('button');
            trigger.type = 'button';
            trigger.className = 'table-fullscreen-trigger';
            trigger.innerHTML = '<span class="table-fullscreen-icon">↔</span><span>Lihat tabel lengkap</span>';
            container.parentNode.insertBefore(trigger, container);

            const close = document.createElement('button');
            close.type = 'button';
            close.className = 'table-fullscreen-close';
            close.innerHTML = '✕&nbsp; Tutup';
            container.appendChild(close);

            function buka() {
                container.classList.add('table-fullscreen-active');
                document.body.classList.add('table-fullscreen-open');
                container.scrollTop = 0;
                container.scrollLeft = 0;
                close.focus({ preventScroll: true });
            }

            function tutup() {
                container.classList.remove('table-fullscreen-active');
                document.body.classList.remove('table-fullscreen-open');
                trigger.focus({ preventScroll: true });
            }

            trigger.addEventListener('click', buka);
            close.addEventListener('click', tutup);

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape' && container.classList.contains('table-fullscreen-active')) {
                    tutup();
                }
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Beri kesempatan script halaman membuat tabel terlebih dahulu.
        setTimeout(siapkanModeTabelLengkap, 0);
    });

    // Dipanggil bila halaman aplikasi merender ulang tabel secara dinamis.
    window.siapkanModeTabelLengkap = siapkanModeTabelLengkap;
})();
