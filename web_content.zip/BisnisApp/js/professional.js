/* =========================================================
   BISNISAPP — PROFESSIONAL MOBILE UX
   Format uang, notifikasi, onboarding, dan kontrol keluar.
========================================================= */

(function () {
    "use strict";

    // ---------- FORMAT ANGKA UANG ----------
    window.nilaiUangInput = function (inputOrId) {
        const el = typeof inputOrId === "string"
            ? document.getElementById(inputOrId)
            : inputOrId;
        if (!el) return 0;
        const raw = String(el.value ?? "").replace(/[^\d]/g, "");
        return Number(raw) || 0;
    };

    window.formatAngkaUang = function (value) {
        const angka = Number(value) || 0;
        return angka.toLocaleString("id-ID");
    };

    function pasangFormatUang(el) {
        if (!el || el.dataset.moneyReady === "1") return;
        el.dataset.moneyReady = "1";

        const format = function () {
            const angka = String(el.value ?? "").replace(/[^\d]/g, "");
            el.value = angka ? Number(angka).toLocaleString("id-ID") : "";
        };

        el.addEventListener("input", format);
        el.addEventListener("blur", format);
        el.addEventListener("focus", function () {
            // Tetap tampil dengan titik agar mudah dibaca.
            format();
            try { el.select(); } catch (_) {}
        });
    }

    function siapkanInputUang() {
        document.querySelectorAll("[data-money-input]").forEach(pasangFormatUang);
    }

    // ---------- NOTIFIKASI ----------
    window.notifikasiApp = function (judul, pesan, tipe) {
        tipe = tipe || "info";
        let box = document.getElementById("notifikasiAppGlobal");

        if (!box) {
            box = document.createElement("div");
            box.id = "notifikasiAppGlobal";
            box.className = "notifikasi-app-global";
            box.innerHTML =
                '<div class="notifikasi-app-icon"></div>' +
                '<div class="notifikasi-app-copy">' +
                '<strong class="notifikasi-app-judul"></strong>' +
                '<span class="notifikasi-app-pesan"></span>' +
                '</div>';
            document.body.appendChild(box);
        }

        const icons = { success: "✓", error: "!", warning: "!", info: "i" };
        box.querySelector(".notifikasi-app-icon").textContent = icons[tipe] || "i";
        box.querySelector(".notifikasi-app-judul").textContent = judul;
        box.querySelector(".notifikasi-app-pesan").textContent = pesan;
        box.className = "notifikasi-app-global tampil " + tipe;

        clearTimeout(window.__bisnisAppNotifTimer);
        window.__bisnisAppNotifTimer = setTimeout(function () {
            box.classList.remove("tampil");
        }, 3800);
    };

    // ---------- ALERT MODERN ----------
    // Ganti dialog bawaan "Laman pada http://localhost menyatakan"
    // dengan notifikasi BisnisApp yang konsisten.
    window.alert = function (pesan) {
        if (typeof window.notifikasiApp === "function") {
            window.notifikasiApp("Pemberitahuan", String(pesan || ""), "warning");
        } else {
            console.warn("BisnisApp:", pesan);
        }
    };

    // ---------- KELUAR / LOGOUT ----------
    let sedangKeluar = false;

    window.logoutBisnisApp = function (alasan) {
        if (sedangKeluar) return;
        sedangKeluar = true;

        // Data bisnis di localStorage TIDAK dihapus.
        // Hanya sesi halaman yang dibersihkan.
        try {
            sessionStorage.removeItem("bisnisAppCurrentPage");
            sessionStorage.removeItem("bisnisAppPreviousPage");
            sessionStorage.setItem("bisnisAppLoggedOut", "1");
        } catch (_) {}

        notifikasiApp(
            "Berhasil keluar",
            alasan || "Sesi aplikasi telah ditutup. Data bisnis tetap aman.",
            "success"
        );

        setTimeout(function () {
            location.replace("index.html?logout=1");
        }, 650);
    };

    // Tombol Back Android/browser.
    window.addEventListener("popstate", function () {
        logoutBisnisApp("Tombol Back ditekan. Anda telah keluar dari sesi aplikasi.");
    });

    // Tombol Home Android biasanya membuat halaman menjadi hidden.
    // Ini tidak bisa dibedakan sempurna dari berpindah aplikasi/lock screen.
    document.addEventListener("visibilitychange", function () {
        if (document.visibilityState === "hidden" && !sedangKeluar) {
            try { sessionStorage.setItem("bisnisAppPendingLogout", "1"); } catch (_) {}
        }
        if (document.visibilityState === "visible") {
            try {
                if (sessionStorage.getItem("bisnisAppPendingLogout") === "1") {
                    sessionStorage.removeItem("bisnisAppPendingLogout");
                    logoutBisnisApp("Aplikasi dibuka kembali setelah tombol Home. Sesi sebelumnya ditutup.");
                }
            } catch (_) {}
        }
    });

    document.addEventListener("DOMContentLoaded", function () {
        siapkanInputUang();

        // Format ulang input yang sudah berisi angka.
        document.querySelectorAll("[data-money-input]").forEach(function (el) {
            if (el.value) el.value = formatAngkaUang(String(el.value).replace(/[^\d]/g, ""));
        });

        // Bantuan cepat di halaman dashboard untuk pengguna baru.
        if (location.pathname.endsWith("index.html") || location.pathname.endsWith("/")) {
            const isLogout = new URLSearchParams(location.search).get("logout") === "1";
            if (isLogout) {
                setTimeout(function () {
                    notifikasiApp("Sampai jumpa", "Anda sudah keluar dari sesi aplikasi.", "info");
                }, 700);
            }

            try {
                if (localStorage.getItem("bisnisAppOnboardingDone") !== "1" && !isLogout) {
                    const modal = document.getElementById("panduanPemulaModal");
                    if (modal) modal.classList.add("tampil");
                }
            } catch (_) {}
        }
    });

    window.tutupPanduanPemula = function () {
        const modal = document.getElementById("panduanPemulaModal");
        if (modal) modal.classList.remove("tampil");
        try { localStorage.setItem("bisnisAppOnboardingDone", "1"); } catch (_) {}
    };

    window.bukaPanduanPemula = function () {
        const modal = document.getElementById("panduanPemulaModal");
        if (modal) modal.classList.add("tampil");
    };
})();
