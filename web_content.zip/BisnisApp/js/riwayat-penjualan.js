/* ========================================
   RIWAYAT PENJUALAN BISNISAPP
   Menggunakan dataPenjualan yang sama
   dengan Kasir
======================================== */


/* ========================================
   VARIABEL EDIT
======================================== */

let indexPenjualanSedangDiedit = -1;


/* ========================================
   FORMAT RUPIAH
======================================== */

function formatRupiahRiwayat(angka) {

    return "Rp " +
        Number(angka || 0).toLocaleString("id-ID");

}


/* ========================================
   ESCAPE HTML
======================================== */

function escapeHtmlRiwayat(teks) {

    return String(teks ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* ========================================
   AMBIL DATA PENJUALAN
======================================== */

function ambilDataPenjualanRiwayat() {

    return JSON.parse(
        localStorage.getItem("dataPenjualan") || "[]"
    );

}


/* ========================================
   SIMPAN DATA PENJUALAN
======================================== */

function simpanDataPenjualanRiwayat(data) {

    localStorage.setItem(
        "dataPenjualan",
        JSON.stringify(data)
    );

}


/* ========================================
   AMBIL DATA BARANG
======================================== */

function ambilDataBarangRiwayat() {

    return JSON.parse(
        localStorage.getItem("dataBarang") || "[]"
    );

}


/* ========================================
   SIMPAN DATA BARANG
======================================== */

function simpanDataBarangRiwayat(data) {

    localStorage.setItem(
        "dataBarang",
        JSON.stringify(data)
    );

}


/* ========================================
   FORMAT TANGGAL
======================================== */

function formatTanggalRiwayat(tanggal) {

    if (!tanggal) {
        return "-";
    }

    const hasil = new Date(tanggal);

    if (isNaN(hasil.getTime())) {
        return tanggal;
    }

    return hasil.toLocaleDateString(
        "id-ID",
        {
            day: "2-digit",
            month: "2-digit",
            year: "numeric"
        }
    );

}


/* ========================================
   FORMAT WAKTU
======================================== */

function formatWaktuRiwayat(tanggal) {

    if (!tanggal) {
        return "";
    }

    const hasil = new Date(tanggal);

    if (isNaN(hasil.getTime())) {
        return "";
    }

    return hasil.toLocaleTimeString(
        "id-ID",
        {
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


/* ========================================
   NOMOR TRANSAKSI
======================================== */

function nomorTransaksiRiwayat(
    transaksi,
    index
) {

    if (transaksi.nomor) {
        return transaksi.nomor;
    }

    return "TRX-" +
        String(index + 1).padStart(4, "0");

}


/* ========================================
   TAMPILKAN RIWAYAT
======================================== */

function tampilkanRiwayatPenjualan() {

    const tempat =
        document.getElementById(
            "daftarRiwayatPenjualan"
        );

    if (!tempat) {
        return;
    }


    /* Ambil langsung database yang sama
       dengan Kasir */

    const data =
        ambilDataPenjualanRiwayat();


    const input =
        document.getElementById(
            "cariRiwayatPenjualan"
        );


    const kata =
        input
            ? input.value.trim().toLowerCase()
            : "";


    const jumlah =
        document.getElementById(
            "jumlahTransaksi"
        );


    if (jumlah) {

        jumlah.textContent =
            data.length + " transaksi";

    }


    /* ==============================
       JIKA BELUM ADA TRANSAKSI
    ============================== */

    if (data.length === 0) {

        tempat.innerHTML = `

            <div class="riwayat-kosong">

                📋

                <br><br>

                Belum ada transaksi penjualan.

                <br><br>

                Transaksi dari Kasir akan
                otomatis muncul di sini.

            </div>

        `;

        return;

    }


    /* ==============================
       SIMPAN INDEX ASLI
    ============================== */

    let hasil =
        data.map(function(transaksi, index) {

            return {

                transaksi: transaksi,

                indexAsli: index

            };

        });


    /* ==============================
       PENCARIAN
    ============================== */

    if (kata !== "") {

        hasil =
            hasil.filter(function(item) {

                const transaksi =
                    item.transaksi;


                const teks =
                    JSON.stringify(
                        transaksi
                    ).toLowerCase();


                return teks.includes(kata);

            });

    }


    /* ==============================
       URUTKAN TERBARU
    ============================== */

    hasil.sort(function(a, b) {

        const tanggalA =
            new Date(
                a.transaksi.tanggal || 0
            ).getTime();


        const tanggalB =
            new Date(
                b.transaksi.tanggal || 0
            ).getTime();


        if (tanggalB !== tanggalA) {

            return tanggalB - tanggalA;

        }


        return (
            Number(
                b.transaksi.id || 0
            ) -
            Number(
                a.transaksi.id || 0
            )
        );

    });


    /* ==============================
       JIKA PENCARIAN TIDAK DITEMUKAN
    ============================== */

    if (hasil.length === 0) {

        tempat.innerHTML = `

            <div class="riwayat-kosong">

                🔍

                <br><br>

                Transaksi tidak ditemukan.

            </div>

        `;

        return;

    }


    let html = "";


    /* ==============================
       BUAT DAFTAR
    ============================== */

    hasil.forEach(function(item) {

        const transaksi =
            item.transaksi;


        const index =
            item.indexAsli;


        const detail =
            Array.isArray(
                transaksi.detail
            )
                ? transaksi.detail
                : [];


        const jumlahBarang =
            detail.reduce(
                function(total, barang) {

                    return total +
                        Number(
                            barang.qty || 0
                        );

                },
                0
            );


        const nomor =
            nomorTransaksiRiwayat(
                transaksi,
                index
            );


        const tanggal =
            formatTanggalRiwayat(
                transaksi.tanggal
            );


        const waktu =
            formatWaktuRiwayat(
                transaksi.tanggal
            );


        html += `

            <div
                class="item-riwayat-penjualan"
                onclick="lihatDetailPenjualan(${index})">

                <div class="nomor-transaksi">

                    ${escapeHtmlRiwayat(
                        nomor
                    )}

                </div>


                <div class="judul-riwayat">

                    🧾 ${tanggal}

                    ${waktu
                        ? " • " + waktu
                        : ""
                    }

                </div>


                <div class="detail-riwayat">

                    ${jumlahBarang}
                    barang

                    • Diskon

                    ${formatRupiahRiwayat(
                        transaksi.diskon || 0
                    )}

                </div>


                <div class="total-riwayat">

                    Total:
                    ${formatRupiahRiwayat(
                        transaksi.total
                    )}

                </div>


                <div class="status-riwayat">

                    👆 Ketuk untuk melihat detail

                </div>

            </div>

        `;

    });


    tempat.innerHTML =
        html;

}


/* ========================================
   LIHAT DETAIL TRANSAKSI
======================================== */

function lihatDetailPenjualan(index) {

    const data =
        ambilDataPenjualanRiwayat();


    const transaksi =
        data[index];


    if (!transaksi) {

        alert(
            "Transaksi tidak ditemukan."
        );

        return;

    }


    const modal =
        document.getElementById(
            "modalDetailPenjualan"
        );


    const nomor =
        document.getElementById(
            "detailNomorTransaksi"
        );


    const isi =
        document.getElementById(
            "isiDetailPenjualan"
        );


    if (!modal || !isi) {
        return;
    }


    if (nomor) {

        nomor.textContent =
            nomorTransaksiRiwayat(
                transaksi,
                index
            );

    }


    const detail =
        Array.isArray(
            transaksi.detail
        )
            ? transaksi.detail
            : [];


    let html = "";


    detail.forEach(function(item) {

        const qty =
            Number(item.qty || 0);


        const harga =
            Number(
                item.hargaJual || 0
            );


        const total =
            Number(
                item.total ||
                harga * qty
            );


        html += `

            <div class="detail-item">

                <div class="detail-item-nama">

                    ${escapeHtmlRiwayat(
                        item.nama || "-"
                    )}

                </div>


                <div class="detail-item-info">

                    ${escapeHtmlRiwayat(
                        item.kode || "-"
                    )}

                    • ${qty}

                    ${escapeHtmlRiwayat(
                        item.satuan || ""
                    )}

                    ×

                    ${formatRupiahRiwayat(
                        harga
                    )}

                </div>


                <div class="detail-item-total">

                    ${formatRupiahRiwayat(
                        total
                    )}

                </div>

            </div>

        `;

    });


    html += `

        <div class="detail-total-box">

            <div class="detail-total-row">

                <span>Subtotal</span>

                <strong>
                    ${formatRupiahRiwayat(
                        transaksi.subtotal
                    )}
                </strong>

            </div>


            <div class="detail-total-row">

                <span>Diskon</span>

                <strong>
                    ${formatRupiahRiwayat(
                        transaksi.diskon
                    )}
                </strong>

            </div>


            <div class="detail-total-row total">

                <span>Total</span>

                <strong>
                    ${formatRupiahRiwayat(
                        transaksi.total
                    )}
                </strong>

            </div>


            <div class="detail-total-row">

                <span>Uang Bayar</span>

                <strong>
                    ${formatRupiahRiwayat(
                        transaksi.dibayar
                    )}
                </strong>

            </div>


            <div class="detail-total-row">

                <span>Kembalian</span>

                <strong>
                    ${formatRupiahRiwayat(
                        transaksi.kembalian
                    )}
                </strong>

            </div>

        </div>


        <button
            type="button"
            class="tombol-simpan-edit"
            onclick="bukaEditPenjualan(${index})">

            ✏️ Edit Transaksi

        </button>


        <button
            type="button"
            class="tombol-batal-transaksi"
            onclick="hapusPenjualan(${index})">

            🗑️ Batalkan Transaksi

        </button>

    `;


    isi.innerHTML =
        html;


    modal.style.display =
        "block";

}


/* ========================================
   TUTUP DETAIL
======================================== */

function tutupDetailPenjualan() {

    const modal =
        document.getElementById(
            "modalDetailPenjualan"
        );


    if (modal) {

        modal.style.display =
            "none";

    }

}


/* ========================================
   BUKA EDIT
======================================== */

function bukaEditPenjualan(index) {

    const data =
        ambilDataPenjualanRiwayat();


    const transaksi =
        data[index];


    if (!transaksi) {

        alert(
            "Transaksi tidak ditemukan."
        );

        return;

    }


    indexPenjualanSedangDiedit =
        index;


    tutupDetailPenjualan();


    const nomor =
        document.getElementById(
            "editNomorTransaksi"
        );


    if (nomor) {

        nomor.textContent =
            nomorTransaksiRiwayat(
                transaksi,
                index
            );

    }


    const diskon =
        document.getElementById(
            "editDiskon"
        );


    const dibayar =
        document.getElementById(
            "editDibayar"
        );


    if (diskon) {

        diskon.value =
            formatAngkaUang(transaksi.diskon || 0);

    }


    if (dibayar) {

        dibayar.value =
            formatAngkaUang(transaksi.dibayar || 0);

    }


    const isi =
        document.getElementById(
            "isiEditPenjualan"
        );


    if (!isi) {
        return;
    }


    const detail =
        Array.isArray(
            transaksi.detail
        )
            ? transaksi.detail
            : [];


    let html = "";


    detail.forEach(function(item, itemIndex) {

        html += `

            <div class="edit-item">

                <div class="edit-item-nama">

                    ${escapeHtmlRiwayat(
                        item.nama || "-"
                    )}

                </div>


                <div class="edit-item-info">

                    ${escapeHtmlRiwayat(
                        item.kode || "-"
                    )}

                    •

                    ${formatRupiahRiwayat(
                        item.hargaJual || 0
                    )}

                    /

                    ${escapeHtmlRiwayat(
                        item.satuan || "pcs"
                    )}

                </div>


                <div class="edit-item-kontrol">

                    <label>
                        Jumlah
                    </label>

                    <input
                        type="number"
                        min="0"
                        value="${Number(
                            item.qty || 0
                        )}"
                        onchange="hitungEditPenjualan()"
                        data-edit-item="${itemIndex}">

                </div>

            </div>

        `;

    });


    isi.innerHTML =
        html;


    const modal =
        document.getElementById(
            "modalEditPenjualan"
        );


    if (modal) {

        modal.style.display =
            "block";

    }


    hitungEditPenjualan();

}


/* ========================================
   HITUNG EDIT
======================================== */

function hitungEditPenjualan() {

    if (
        indexPenjualanSedangDiedit === -1
    ) {

        return;

    }


    const data =
        ambilDataPenjualanRiwayat();


    const transaksi =
        data[
            indexPenjualanSedangDiedit
        ];


    if (!transaksi) {
        return;
    }


    const inputs =
        document.querySelectorAll(
            "[data-edit-item]"
        );


    let subtotal = 0;


    inputs.forEach(function(input) {

        const itemIndex =
            Number(
                input.dataset.editItem
            );


        const item =
            transaksi.detail[itemIndex];


        if (!item) {
            return;
        }


        let qty =
            parseInt(
                input.value
            );


        if (
            isNaN(qty) ||
            qty < 0
        ) {

            qty = 0;

        }


        subtotal +=
            Number(
                item.hargaJual || 0
            ) * qty;

    });


    const inputDiskon =
        document.getElementById(
            "editDiskon"
        );


    let diskon =
        nilaiUangInput(inputDiskon) || 0;


    if (diskon < 0) {
        diskon = 0;
    }


    if (diskon > subtotal) {
        diskon = subtotal;
    }


    const total =
        subtotal - diskon;


    const inputDibayar =
        document.getElementById(
            "editDibayar"
        );


    const dibayar =
        nilaiUangInput(inputDibayar) || 0;


    const kembalian =
        Math.max(
            0,
            dibayar - total
        );


    const elSubtotal =
        document.getElementById(
            "editSubtotal"
        );


    const elDiskon =
        document.getElementById(
            "editDiskonTampil"
        );


    const elTotal =
        document.getElementById(
            "editTotal"
        );


    const elKembalian =
        document.getElementById(
            "editKembalian"
        );


    if (elSubtotal) {

        elSubtotal.textContent =
            formatRupiahRiwayat(
                subtotal
            );

    }


    if (elDiskon) {

        elDiskon.textContent =
            formatRupiahRiwayat(
                diskon
            );

    }


    if (elTotal) {

        elTotal.textContent =
            formatRupiahRiwayat(
                total
            );

    }


    if (elKembalian) {

        elKembalian.textContent =
            formatRupiahRiwayat(
                kembalian
            );

    }

}


/* ========================================
   SIMPAN EDIT
======================================== */

function simpanEditPenjualan() {

    if (
        indexPenjualanSedangDiedit === -1
    ) {

        return;

    }


    const dataPenjualan =
        ambilDataPenjualanRiwayat();


    const transaksi =
        dataPenjualan[
            indexPenjualanSedangDiedit
        ];


    if (!transaksi) {

        alert(
            "Transaksi tidak ditemukan."
        );

        return;

    }


    const dataBarang =
        ambilDataBarangRiwayat();


    const inputs =
        document.querySelectorAll(
            "[data-edit-item]"
        );


    /*
       Salin stok terlebih dahulu.
       Database asli belum diubah.
    */

    const stokSementara =
        dataBarang.map(function(barang) {

            return {

                id: barang.id,

                stok:
                    Number(
                        barang.stok || 0
                    )

            };

        });


    /* ==============================
       KEMBALIKAN STOK LAMA
    ============================== */

    if (
        Array.isArray(
            transaksi.detail
        )
    ) {

        transaksi.detail.forEach(
            function(item) {

                const barang =
                    stokSementara.find(
                        function(b) {

                            return String(b.id) ===
                                String(item.id);

                        }
                    );


                if (barang) {

                    barang.stok +=
                        Number(
                            item.qty || 0
                        );

                }

            }
        );

    }


    /* ==============================
       BUAT DETAIL BARU
    ============================== */

    const detailBaru = [];


    for (
        const input of inputs
    ) {

        const itemIndex =
            Number(
                input.dataset.editItem
            );


        const item =
            transaksi.detail[itemIndex];


        if (!item) {
            continue;
        }


        let qty =
            parseInt(
                input.value
            );


        if (
            isNaN(qty) ||
            qty < 0
        ) {

            qty = 0;

        }


        /*
           Qty 0 berarti barang
           dihapus dari transaksi.
        */

        if (qty === 0) {
            continue;
        }


        const stok =
            stokSementara.find(
                function(b) {

                    return String(b.id) ===
                        String(item.id);

                }
            );


        if (!stok) {

            alert(
                "Barang " +
                item.nama +
                " sudah tidak ada di Data Barang."
            );

            return;

        }


        if (qty > stok.stok) {

            alert(
                "Stok " +
                item.nama +
                " tidak mencukupi."
            );

            return;

        }


        stok.stok -= qty;


        const hargaJual =
            Number(
                item.hargaJual || 0
            );


        const hargaBeli =
            Number(
                item.hargaBeli || 0
            );


        detailBaru.push({

            id: item.id,

            kode: item.kode,

            nama: item.nama,

            satuan: item.satuan,

            qty: qty,

            hargaJual: hargaJual,

            hargaBeli: hargaBeli,

            total:
                hargaJual * qty

        });

    }


    /* ==============================
       JIKA SEMUA BARANG DIHAPUS
    ============================== */

    if (detailBaru.length === 0) {

        const yakin =
            confirm(
                "Semua barang menjadi 0.\n\nBatalkan transaksi ini?"
            );


        if (yakin) {

            hapusPenjualan(
                indexPenjualanSedangDiedit
            );

        }


        return;

    }


    /* ==============================
       HITUNG BARU
    ============================== */

    let subtotal = 0;

    let modal = 0;


    detailBaru.forEach(function(item) {

        subtotal +=
            Number(item.hargaJual) *
            Number(item.qty);


        modal +=
            Number(item.hargaBeli) *
            Number(item.qty);

    });


    const inputDiskon =
        document.getElementById(
            "editDiskon"
        );


    let diskon =
        nilaiUangInput(inputDiskon) || 0;


    if (diskon < 0) {
        diskon = 0;
    }


    if (diskon > subtotal) {
        diskon = subtotal;
    }


    const total =
        subtotal - diskon;


    const inputDibayar =
        document.getElementById(
            "editDibayar"
        );


    const dibayar =
        nilaiUangInput(inputDibayar) || 0;


    if (dibayar < total) {

        alert(
            "Uang bayar masih kurang."
        );

        return;

    }


    const kembalian =
        dibayar - total;


    const labaKotor =
        total - modal;


    /* ==============================
       UPDATE STOK
    ============================== */

    dataBarang.forEach(
        function(barang) {

            const stok =
                stokSementara.find(
                    function(b) {

                        return String(b.id) ===
                            String(barang.id);

                    }
                );


            if (stok) {

                barang.stok =
                    stok.stok;

            }

        }
    );


    /* ==============================
       UPDATE TRANSAKSI
    ============================== */

    transaksi.detail =
        detailBaru;

    transaksi.subtotal =
        subtotal;

    transaksi.diskon =
        diskon;

    transaksi.total =
        total;

    transaksi.dibayar =
        dibayar;

    transaksi.kembalian =
        kembalian;

    transaksi.modal =
        modal;

    transaksi.labaKotor =
        labaKotor;


    /* ==============================
       SIMPAN
    ============================== */

    simpanDataBarangRiwayat(
        dataBarang
    );


    simpanDataPenjualanRiwayat(
        dataPenjualan
    );


    tutupEditPenjualan();


    indexPenjualanSedangDiedit =
        -1;


    tampilkanRiwayatPenjualan();


    alert(
        "Transaksi berhasil diperbarui."
    );

}


/* ========================================
   TUTUP EDIT
======================================== */

function tutupEditPenjualan() {

    const modal =
        document.getElementById(
            "modalEditPenjualan"
        );


    if (modal) {

        modal.style.display =
            "none";

    }


    indexPenjualanSedangDiedit =
        -1;

}


/* ========================================
   BATAL / HAPUS TRANSAKSI
======================================== */

function hapusPenjualan(index) {

    if (
        typeof index !== "number"
    ) {

        index =
            indexPenjualanSedangDiedit;

    }


    if (index === -1) {
        return;
    }


    const dataPenjualan =
        ambilDataPenjualanRiwayat();


    const transaksi =
        dataPenjualan[index];


    if (!transaksi) {

        alert(
            "Transaksi tidak ditemukan."
        );

        return;

    }


    const yakin =
        confirm(
            "Batalkan transaksi ini?\n\nStok barang akan dikembalikan."
        );


    if (!yakin) {
        return;
    }


    const dataBarang =
        ambilDataBarangRiwayat();


    /* ==============================
       KEMBALIKAN STOK
    ============================== */

    if (
        Array.isArray(
            transaksi.detail
        )
    ) {

        transaksi.detail.forEach(
            function(item) {

                const barang =
                    dataBarang.find(
                        function(b) {

                            return String(b.id) ===
                                String(item.id);

                        }
                    );


                if (barang) {

                    barang.stok =
                        Number(
                            barang.stok || 0
                        ) +
                        Number(
                            item.qty || 0
                        );

                }

            }
        );

    }


    /* ==============================
       HAPUS TRANSAKSI
    ============================== */

    dataPenjualan.splice(
        index,
        1
    );


    /* ==============================
       SIMPAN
    ============================== */

    simpanDataBarangRiwayat(
        dataBarang
    );


    simpanDataPenjualanRiwayat(
        dataPenjualan
    );


    tutupDetailPenjualan();

    tutupEditPenjualan();


    tampilkanRiwayatPenjualan();


    alert(
        "Transaksi berhasil dibatalkan dan stok dikembalikan."
    );

}


/* ========================================
   KLIK DI LUAR MODAL
======================================== */

window.addEventListener(
    "click",
    function(event) {

        const modalDetail =
            document.getElementById(
                "modalDetailPenjualan"
            );


        const modalEdit =
            document.getElementById(
                "modalEditPenjualan"
            );


        if (
            event.target ===
            modalDetail
        ) {

            tutupDetailPenjualan();

        }


        if (
            event.target ===
            modalEdit
        ) {

            tutupEditPenjualan();

        }

    }
);


document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanRiwayatPenjualan();

        /*
           Jika halaman dibuka dari Riwayat Penjualan
           di Kasir, langsung buka transaksi yang dipilih.
        */

        const idTerpilih =
            localStorage.getItem("penjualanTerpilihId");

        if (idTerpilih) {

            const data =
                ambilDataPenjualanRiwayat();

            const index =
                data.findIndex(function(transaksi) {

                    return String(transaksi.id) ===
                        String(idTerpilih);

                });

            localStorage.removeItem(
                "penjualanTerpilihId"
            );

            if (index !== -1) {

                setTimeout(function() {

                    lihatDetailPenjualan(index);

                }, 100);

            }

        }

    }
);