// ======================================================
// RIWAYAT HARGA BELI
// Data sudah dibuat oleh pembelian.js di barang.riwayatHarga.
// ======================================================

function rupiah(angka) {
    return "Rp " + Number(angka || 0).toLocaleString("id-ID");
}

function persen(selisih, sebelumnya) {
    if (!sebelumnya) return "-";
    return (Math.abs(Number(selisih || 0)) / Number(sebelumnya) * 100).toFixed(2) + "%";
}

function tampilkanRiwayatHarga() {
    const box = document.getElementById("riwayatHarga");
    const cari = document.getElementById("cariHarga").value.toLowerCase();
    const barang = JSON.parse(localStorage.getItem("dataBarang") || "[]");

    const hasil = barang.filter(b =>
        String(b.kode).toLowerCase().includes(cari) ||
        String(b.nama).toLowerCase().includes(cari)
    );

    if (!hasil.length) {
        box.innerHTML = `<div class="kartu-riwayat">🔎 Barang tidak ditemukan.</div>`;
        return;
    }

    let html = "";
    hasil.forEach(b => {
        const riwayat = b.riwayatHarga || [];

        html += `
        <div class="kartu-riwayat">
            <h3>${b.kode} - ${b.nama}</h3>
            <p>Harga beli terakhir: <b>${rupiah(b.hargaBeli)}</b></p>`;

        if (!riwayat.length) {
            html += `<p>Belum ada riwayat pembelian.</p></div>`;
            return;
        }

        html += `<div class="tabel-riwayat"><table>
        <thead><tr><th>Tanggal</th><th>Faktur</th><th>Harga</th><th>Sebelumnya</th><th>Perubahan</th><th>%</th></tr></thead><tbody>`;

        riwayat.slice().reverse().forEach(r => {
            let kelas = "sama";
            let teks = "⚪ Harga Sama";
            if (r.status === "naik") {
                kelas = "naik";
                teks = "🔴 Naik " + rupiah(Math.abs(r.selisih));
            } else if (r.status === "turun") {
                kelas = "turun";
                teks = "🟢 Turun " + rupiah(Math.abs(r.selisih));
            }

            html += `<tr>
                <td>${r.tanggal}</td>
                <td>${r.nomorFaktur}</td>
                <td>${rupiah(r.harga)}</td>
                <td>${rupiah(r.hargaSebelumnya)}</td>
                <td class="${kelas}">${teks}</td>
                <td class="${kelas}">${persen(r.selisih, r.hargaSebelumnya)}</td>
            </tr>`;
        });

        html += `</tbody></table></div></div>`;
    });

    box.innerHTML = html;
}

document.addEventListener("DOMContentLoaded", tampilkanRiwayatHarga);
