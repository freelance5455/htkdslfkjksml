// ======================================================
// DETAIL FAKTUR
// File: js/detail-faktur.js
//
// Fungsi:
// 1. Mengambil ID faktur
// 2. Menampilkan informasi faktur
// 3. Menampilkan barang dalam faktur
// 4. Menampilkan total
// 5. Menampilkan pembayaran
// 6. Menyimpan pembayaran
// 7. Mengubah status faktur
// ======================================================


// ======================================================
// MENGAMBIL ID FAKTUR
// ======================================================

function ambilIdFaktur() {

    return localStorage.getItem(
        "fakturDetailId"
    );

}


// ======================================================
// MENCARI DATA FAKTUR
// ======================================================

function ambilDataFaktur() {

    const id =
        ambilIdFaktur();


    if (!id) {

        return null;

    }


    const data =
        JSON.parse(
            localStorage.getItem(
                "dataFaktur"
            ) || "[]"
        );


    return data.find(function(faktur) {

        return String(faktur.id) ===
            String(id);

    });

}


// ======================================================
// MENAMPILKAN DETAIL FAKTUR
// ======================================================

function tampilkanDetailFaktur() {

    const faktur =
        ambilDataFaktur();


    const informasi =
        document.getElementById(
            "informasiFaktur"
        );


    if (!faktur) {

        informasi.innerHTML = `

            <div class="faktur-tidak-ditemukan">

                ❌ Data faktur tidak ditemukan.

                <br><br>

                <button
                    type="button"
                    class="tombol-kembali"
                    onclick="kembaliKePembelian()">

                    ← Kembali

                </button>

            </div>

        `;

        return;

    }


    // ==================================================
    // STATUS
    // ==================================================

    let statusText = "";

    let statusClass = "";


    if (faktur.status === "lunas") {

        statusText = "🟢 Lunas";

        statusClass = "status-lunas";

    }

    else if (faktur.status === "sebagian") {

        statusText = "🟡 Sebagian Dibayar";

        statusClass = "status-sebagian";

    }

    else {

        statusText = "🔴 Belum Lunas";

        statusClass = "status-belum";

    }


    // ==================================================
    // INFORMASI FAKTUR
    // ==================================================

    informasi.innerHTML = `

        <h2>
            🧾 ${escapeHtml(faktur.nomor)}
        </h2>


        <div class="info-faktur-grid">

            <div>

                <span>
                    Nomor Faktur
                </span>

                <strong>
                    ${escapeHtml(faktur.nomor)}
                </strong>

            </div>


            <div>

                <span>
                    Tanggal
                </span>

                <strong>
                    ${escapeHtml(faktur.tanggal)}
                </strong>

            </div>


            <div>

                <span>
                    Distributor
                </span>

                <strong>
                    ${escapeHtml(
                        faktur.distributorNama
                    )}
                </strong>

            </div>


            <div>

                <span>
                    Status
                </span>

                <strong class="${statusClass}">

                    ${statusText}

                </strong>

            </div>

        </div>

    `;


    tampilkanBarangFaktur(
        faktur
    );


    tampilkanRingkasan(
        faktur
    );


    tampilkanInformasiPembayaran(
        faktur
    );

}


// ======================================================
// MENAMPILKAN BARANG
// ======================================================

function tampilkanBarangFaktur(faktur) {

    const container =
        document.getElementById(
            "detailBarangFaktur"
        );


    if (
        !faktur.detail ||
        faktur.detail.length === 0
    ) {

        container.innerHTML = `

            <div class="faktur-tidak-ditemukan">

                Tidak ada barang dalam faktur.

            </div>

            <div class="aksi-edit-faktur">

                <button
                    type="button"
                    class="tombol-edit-semua-detail"
                    onclick="bukaEditDetailFaktur()">

                    ✏️ Edit / Tambah Barang

                </button>

            </div>

        `;

        return;

    }


    let html = `

        <div class="tabel-detail">

            <table>

                <thead>

                    <tr>

                        <th>No</th>
                        <th>Barang</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Subtotal</th>

                    </tr>

                </thead>

                <tbody>

    `;


    faktur.detail.forEach(
        function(item, index) {

            const qty =
                Number(item.qty || 0);

            const harga =
                Number(
                    item.harga ??
                    item.hargaBeli ??
                    0
                );

            const subtotal =
                Number(
                    item.subtotal ??
                    (qty * harga)
                );


            html += `

                <tr>

                    <td>${index + 1}</td>

                    <td>

                        <strong>
                            ${escapeHtml(item.nama)}
                        </strong>

                        <br>

                        <small>
                            ${escapeHtml(item.kode)}
                            •
                            ${escapeHtml(item.satuan)}
                        </small>

                    </td>

                    <td>${qty}</td>

                    <td>${formatRupiah(harga)}</td>

                    <td>${formatRupiah(subtotal)}</td>

                </tr>

            `;

        }
    );


    html += `

                </tbody>

            </table>

        </div>


        <div class="aksi-edit-faktur">

            <button
                type="button"
                class="tombol-edit-semua-detail"
                onclick="bukaEditDetailFaktur()">

                ✏️ Edit / Tambah Barang

            </button>

        </div>

    `;


    container.innerHTML =
        html;

}


// ======================================================
// MEMBUKA HALAMAN EDIT DETAIL FAKTUR
// ======================================================

function bukaEditDetailFaktur() {

    const faktur =
        ambilDataFaktur();


    if (!faktur) {

        tampilkanNotifikasiFaktur(
            "Faktur tidak ditemukan",
            "Data faktur yang akan diedit tidak tersedia.",
            "error"
        );

        return;

    }


    location.replace(
        "edit-detailfaktur.html");

}


// ======================================================
// MENAMPILKAN RINGKASAN
// ======================================================

function tampilkanRingkasan(faktur) {

    const container =
        document.getElementById(
            "ringkasanFaktur"
        );


    const total =
        Number(faktur.total || 0);


    const totalRetur =
        Number(faktur.totalRetur || 0);


    const totalDibayar =
        Number(faktur.totalDibayar || 0);


    const sisa =
        Math.max(
            0,
            total - totalRetur - totalDibayar
        );


    container.innerHTML = `

        <h2>
            💰 Ringkasan
        </h2>


        <div class="ringkasan-row">

            <span>
                Total Faktur
            </span>

            <strong>
                ${formatRupiah(total)}
            </strong>

        </div>


        <div class="ringkasan-row">

            <span>
                Total Retur
            </span>

            <strong>
                ${formatRupiah(totalRetur)}
            </strong>

        </div>


        <div class="ringkasan-row">

            <span>
                Sudah Dibayar
            </span>

            <strong>
                ${formatRupiah(totalDibayar)}
            </strong>

        </div>


        <div class="ringkasan-row total-sisa">

            <span>
                Sisa Pembayaran
            </span>

            <strong>
                ${formatRupiah(sisa)}
            </strong>

        </div>

    `;

}


// ======================================================
// MENAMPILKAN INFORMASI PEMBAYARAN
// ======================================================

function tampilkanInformasiPembayaran(faktur) {

    const container =
        document.getElementById(
            "informasiPembayaran"
        );


    if (!container) {
        return;
    }


    const total =
        Number(faktur.total || 0);


    const totalRetur =
        Number(faktur.totalRetur || 0);


    const dibayar =
        Number(faktur.totalDibayar || 0);


    const sisa =
        Math.max(
            0,
            total -
            totalRetur -
            dibayar
        );


    container.innerHTML = `

        <div class="pembayaran-info-row">

            <span>
                Total Faktur
            </span>

            <strong>
                ${formatRupiah(total)}
            </strong>

        </div>


        <div class="pembayaran-info-row">

            <span>
                Sudah Dibayar
            </span>

            <strong>
                ${formatRupiah(dibayar)}
            </strong>

        </div>


        <div class="pembayaran-info-row">

            <span>
                Sisa
            </span>

            <strong>
                ${formatRupiah(sisa)}
            </strong>

        </div>

    `;

}


// ======================================================
// SIMPAN PEMBAYARAN
// ======================================================

function simpanPembayaran() {

    const faktur =
        ambilDataFaktur();


    if (!faktur) {

        alert(
            "Data faktur tidak ditemukan."
        );

        return;

    }


    const input =
        document.getElementById(
            "jumlahBayar"
        );


    const jumlah =
        nilaiUangInput(input);


    if (!jumlah || jumlah <= 0) {

        alert(
            "Masukkan jumlah pembayaran."
        );

        return;

    }


    const total =
        Number(faktur.total || 0);


    const totalRetur =
        Number(faktur.totalRetur || 0);


    const sudahDibayar =
        Number(faktur.totalDibayar || 0);


    const sisa =
        Math.max(
            0,
            total -
            totalRetur -
            sudahDibayar
        );


    if (sisa <= 0) {

        alert(
            "Faktur ini sudah lunas."
        );

        return;

    }


    // Tidak boleh membayar lebih besar
    // dari sisa tagihan

    if (jumlah > sisa) {

        alert(
            "Pembayaran melebihi sisa tagihan.\n\n" +
            "Sisa tagihan: " +
            formatRupiah(sisa)
        );

        return;

    }


    // ==================================================
    // UPDATE PEMBAYARAN
    // ==================================================

    faktur.totalDibayar =
        sudahDibayar +
        jumlah;


    const sisaBaru =
        Math.max(
            0,
            total -
            totalRetur -
            faktur.totalDibayar
        );


    faktur.sisa =
        sisaBaru;


    // ==================================================
    // UPDATE STATUS
    // ==================================================

    if (sisaBaru <= 0) {

        faktur.status =
            "lunas";

    }

    else if (faktur.totalDibayar > 0) {

        faktur.status =
            "sebagian";

    }

    else {

        faktur.status =
            "belum";

    }


    // ==================================================
    // SIMPAN DATABASE
    // ==================================================

    const semuaFaktur =
        JSON.parse(
            localStorage.getItem(
                "dataFaktur"
            ) || "[]"
        );


    const index =
        semuaFaktur.findIndex(
            function(f) {

                return String(f.id) ===
                    String(faktur.id);

            }
        );


    if (index === -1) {

        alert(
            "Data faktur tidak ditemukan di database."
        );

        return;

    }


    semuaFaktur[index] =
        faktur;


    localStorage.setItem(
        "dataFaktur",
        JSON.stringify(
            semuaFaktur
        )
    );


    // ==================================================
    // RESET INPUT
    // ==================================================

    input.value = "";


    alert(
        "Pembayaran berhasil disimpan."
    );


    // Tampilkan ulang
    tampilkanDetailFaktur();

}


// ======================================================
// KEMBALI KE PEMBELIAN
// ======================================================

function kembaliKePembelian() {
    appBack("pembelian.html");
}


// ======================================================
// FORMAT RUPIAH
// ======================================================

function formatRupiah(angka) {

    return "Rp " +
        Number(angka || 0)
            .toLocaleString("id-ID");

}


// ======================================================
// ESCAPE HTML
// ======================================================

function escapeHtml(teks) {

    return String(teks || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// ======================================================
// JALANKAN SAAT HALAMAN DIBUKA
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanDetailFaktur();

    }
);