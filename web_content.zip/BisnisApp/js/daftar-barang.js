// ======================================================
// DAFTAR BARANG BISNISAPP
// File: js/daftar-barang.js
//
// Fungsi:
// 1. Menampilkan semua barang
// 2. Pencarian barang
// 3. Sorting
// 4. Status stok
// 5. Edit barang
// 6. Hapus barang
// ======================================================



// ======================================================
// AMBIL DATA
// ======================================================

function ambilDataBarangDaftar() {

    try {

        const data =
            localStorage.getItem(
                "dataBarang"
            );

        if (!data) {
            return [];
        }

        const hasil =
            JSON.parse(data);

        return Array.isArray(hasil)
            ? hasil
            : [];

    }

    catch (error) {

        console.error(
            "Gagal membaca data barang:",
            error
        );

        return [];

    }

}



// ======================================================
// SIMPAN DATA
// ======================================================

function simpanDataBarangDaftar(
    data
) {

    localStorage.setItem(
        "dataBarang",
        JSON.stringify(data)
    );

}



// ======================================================
// ESCAPE HTML
// ======================================================

function escapeHtml(teks) {

    return String(teks || "")

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}



// ======================================================
// FORMAT RUPIAH
// ======================================================

function formatRupiahBarang(
    angka
) {

    return (
        "Rp " +
        Number(angka || 0)
            .toLocaleString("id-ID")
    );

}



// ======================================================
// STATUS STOK
// ======================================================

function statusStok(
    barang
) {

    const stok =
        Number(
            barang.stok || 0
        );


    const minimum =
        Number(
            barang.minimumStok || 0
        );



    if (stok <= 0) {

        return `
            <span class="status stok-habis">
                🔴 Habis
            </span>
        `;

    }



    if (stok <= minimum) {

        return `
            <span class="status stok-menipis">
                🟠 Menipis
            </span>
        `;

    }



    return `
        <span class="status stok-aman">
            🟢 Aman
        </span>
    `;

}



// ======================================================
// TAMPILKAN DAFTAR
// ======================================================

function tampilkanDaftarBarang() {


    const container =
        document.getElementById(
            "daftarBarang"
        );


    if (!container) {
        return;
    }



    let dataBarang =
        ambilDataBarangDaftar();



    // ==================================================
    // PENCARIAN
    // ==================================================

    const inputCari =
        document.getElementById(
            "cariBarang"
        );


    const pencarian =
        inputCari
            ? inputCari.value
                .trim()
                .toLowerCase()
            : "";



    if (pencarian) {

        dataBarang =
            dataBarang.filter(
                function(barang) {

                    const kode =
                        String(
                            barang.kode || ""
                        ).toLowerCase();


                    const nama =
                        String(
                            barang.nama || ""
                        ).toLowerCase();


                    return (
                        kode.includes(
                            pencarian
                        )
                        ||
                        nama.includes(
                            pencarian
                        )
                    );

                }
            );

    }



    // ==================================================
    // SORTING
    // ==================================================

    const selectUrutan =
        document.getElementById(
            "urutanBarang"
        );


    const urutan =
        selectUrutan
            ? selectUrutan.value
            : "default";



    if (urutan === "stok-naik") {

        dataBarang.sort(
            function(a, b) {

                return (
                    Number(a.stok || 0)
                    -
                    Number(b.stok || 0)
                );

            }
        );

    }



    else if (
        urutan === "stok-turun"
    ) {

        dataBarang.sort(
            function(a, b) {

                return (
                    Number(b.stok || 0)
                    -
                    Number(a.stok || 0)
                );

            }
        );

    }



    else if (
        urutan === "nama-az"
    ) {

        dataBarang.sort(
            function(a, b) {

                return String(
                    a.nama || ""
                ).localeCompare(
                    String(
                        b.nama || ""
                    ),
                    "id"
                );

            }
        );

    }



    else if (
        urutan === "nama-za"
    ) {

        dataBarang.sort(
            function(a, b) {

                return String(
                    b.nama || ""
                ).localeCompare(
                    String(
                        a.nama || ""
                    ),
                    "id"
                );

            }
        );

    }



    else if (
        urutan === "status"
    ) {

        dataBarang.sort(
            function(a, b) {

                const stokA =
                    Number(a.stok || 0);

                const stokB =
                    Number(b.stok || 0);

                const minA =
                    Number(
                        a.minimumStok || 0
                    );

                const minB =
                    Number(
                        b.minimumStok || 0
                    );


                const nilaiA =
                    stokA <= 0
                        ? 0
                        : stokA <= minA
                            ? 1
                            : 2;


                const nilaiB =
                    stokB <= 0
                        ? 0
                        : stokB <= minB
                            ? 1
                            : 2;


                return nilaiA - nilaiB;

            }
        );

    }



    // ==================================================
    // TIDAK ADA DATA
    // ==================================================

    if (
        dataBarang.length === 0
    ) {

        container.innerHTML = `

            <div class="kosong">

                📦

                <br><br>

                ${
                    pencarian
                        ? "Barang tidak ditemukan."
                        : "Belum ada barang."
                }

            </div>

        `;

        return;

    }



    // ==================================================
    // TABEL
    // ==================================================

    let html = `

        <div class="tabel-container">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Kode</th>

                        <th>Nama Barang</th>

                        <th>Satuan</th>

                        <th>Stok</th>

                        <th>Harga Beli</th>

                        <th>Harga Jual</th>

                        <th>Status</th>

                        <th>Aksi</th>

                    </tr>

                </thead>


                <tbody>

    `;



    dataBarang.forEach(
        function(barang, index) {


            const stok =
                Number(
                    barang.stok || 0
                );


            html += `

                <tr>

                    <td>
                        ${index + 1}
                    </td>


                    <td>
                        ${escapeHtml(
                            barang.kode || "-"
                        )}
                    </td>


                    <td>

                        <strong>
                            ${escapeHtml(
                                barang.nama || "-"
                            )}
                        </strong>

                    </td>


                    <td>
                        ${escapeHtml(
                            barang.satuan || "-"
                        )}
                    </td>


                    <td>
                        ${stok}
                    </td>


                    <td>
                        ${formatRupiahBarang(
                            barang.hargaBeli
                        )}
                    </td>


                    <td>
                        ${formatRupiahBarang(
                            barang.hargaJual
                        )}
                    </td>


                    <td>
                        ${statusStok(
                            barang
                        )}
                    </td>


                    <td>

                        <button
                            type="button"
                            class="tombol-edit"
                            onclick="editBarang('${String(
                                barang.id
                            )}')">

                            ✏️ Edit

                        </button>


                        <button
                            type="button"
                            class="tombol-hapus"
                            onclick="hapusBarang('${String(
                                barang.id
                            )}')">

                            🗑️ Hapus

                        </button>

                    </td>

                </tr>

            `;

        }
    );



    html += `

                </tbody>

            </table>

        </div>

    `;



    container.innerHTML =
        html;

}



// ======================================================
// EDIT BARANG
// ======================================================

function editBarang(id) {


    const dataBarang =
        ambilDataBarangDaftar();


    const barang =
        dataBarang.find(
            function(item) {

                return String(item.id)
                    === String(id);

            }
        );


    if (!barang) {

        alert(
            "Data barang tidak ditemukan."
        );

        return;

    }



    // Simpan ID barang
    // yang akan diedit

    localStorage.setItem(
        "editBarangId",
        barang.id
    );


    // Kembali ke form

    location.replace(
        "barang.html");

}



// ======================================================
// HAPUS BARANG
// ======================================================

function hapusBarang(id) {


    const dataBarang =
        ambilDataBarangDaftar();


    const index =
        dataBarang.findIndex(
            function(item) {

                return String(item.id)
                    === String(id);

            }
        );


    if (index === -1) {

        alert(
            "Data barang tidak ditemukan."
        );

        return;

    }



    const barang =
        dataBarang[index];



    // -----------------------------------------------
    // KONFIRMASI
    // -----------------------------------------------

    const yakin =
        confirm(

            "Hapus barang berikut?\n\n" +

            barang.kode +
            " - " +
            barang.nama +

            "\n\n" +

            "Data yang sudah dihapus " +
            "tidak dapat dikembalikan."

        );


    if (!yakin) {
        return;
    }



    // -----------------------------------------------
    // HAPUS
    // -----------------------------------------------

    dataBarang.splice(
        index,
        1
    );


    simpanDataBarangDaftar(
        dataBarang
    );



    // -----------------------------------------------
    // TAMPILKAN ULANG
    // -----------------------------------------------

    tampilkanDaftarBarang();

}



// ======================================================
// JALANKAN
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanDaftarBarang();



        // Pencarian

        const cari =
            document.getElementById(
                "cariBarang"
            );


        if (cari) {

            cari.addEventListener(
                "input",
                tampilkanDaftarBarang
            );

        }



        // Urutan

        const urutan =
            document.getElementById(
                "urutanBarang"
            );


        if (urutan) {

            urutan.addEventListener(
                "change",
                tampilkanDaftarBarang
            );

        }

    }
);