// ======================================================
// EDIT DETAIL FAKTUR
// ======================================================

let timeoutNotifikasiFaktur = null;
let aksiKonfirmasiFaktur = null;


// ======================================================
// DATABASE
// ======================================================

function ambilSemuaFakturEdit() {
    return JSON.parse(localStorage.getItem("dataFaktur") || "[]");
}

function ambilSemuaBarangEdit() {
    return JSON.parse(localStorage.getItem("dataBarang") || "[]");
}

function ambilFakturEdit() {

    const id = localStorage.getItem("fakturDetailId");

    if (!id) return null;

    return ambilSemuaFakturEdit().find(function(faktur) {
        return String(faktur.id) === String(id);
    }) || null;
}


// ======================================================
// FORMAT & KEAMANAN
// ======================================================

function formatRupiahEdit(angka) {
    return "Rp " + Number(angka || 0).toLocaleString("id-ID");
}

function escapeHtmlEdit(teks) {
    return String(teks ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// ======================================================
// NOTIFIKASI PROFESIONAL
// ======================================================

function tampilkanNotifikasiFaktur(judul, pesan, tipe = "success") {

    const box = document.getElementById("notifikasiEditFaktur");
    const icon = document.getElementById("notifikasiIcon");
    const title = document.getElementById("notifikasiJudul");
    const message = document.getElementById("notifikasiPesan");

    if (!box) {
        alert(judul + "\n\n" + pesan);
        return;
    }

    clearTimeout(timeoutNotifikasiFaktur);

    const ikon = {
        success: "✓",
        error: "!",
        warning: "!",
        info: "i"
    };

    icon.textContent = ikon[tipe] || "i";
    title.textContent = judul;
    message.textContent = pesan;

    box.className =
        "notifikasi-edit-faktur tampil " +
        (tipe || "success");

    timeoutNotifikasiFaktur = setTimeout(
        tutupNotifikasiFaktur,
        4200
    );
}

function tutupNotifikasiFaktur() {

    const box = document.getElementById("notifikasiEditFaktur");

    if (box) {
        box.classList.remove("tampil");
    }
}


// ======================================================
// MODAL KONFIRMASI
// ======================================================

function tampilkanModalKonfirmasiFaktur(
    judul,
    pesan,
    aksi,
    icon = "🗑️"
) {

    const modal = document.getElementById("modalKonfirmasiFaktur");
    const modalIcon = document.getElementById("modalIcon");
    const modalJudul = document.getElementById("modalJudul");
    const modalPesan = document.getElementById("modalPesan");
    const tombol = document.getElementById("modalTombolKonfirmasi");

    if (!modal) {
        if (confirm(pesan)) aksi();
        return;
    }

    aksiKonfirmasiFaktur = aksi;

    modalIcon.textContent = icon;
    modalJudul.textContent = judul;
    modalPesan.textContent = pesan;

    tombol.onclick = function() {
        const aksiSekarang = aksiKonfirmasiFaktur;
        tutupModalKonfirmasiFaktur();
        if (typeof aksiSekarang === "function") {
            aksiSekarang();
        }
    };

    modal.classList.add("tampil");
    modal.setAttribute("aria-hidden", "false");
}

function tutupModalKonfirmasiFaktur() {

    const modal = document.getElementById("modalKonfirmasiFaktur");

    if (modal) {
        modal.classList.remove("tampil");
        modal.setAttribute("aria-hidden", "true");
    }

    aksiKonfirmasiFaktur = null;
}


// ======================================================
// INFORMASI FAKTUR
// ======================================================

function tampilkanInformasiFakturEdit(faktur) {

    const container = document.getElementById("informasiFakturEdit");
    if (!container) return;

    const jumlahBarang = Array.isArray(faktur.detail)
        ? faktur.detail.length
        : 0;

    container.innerHTML = `

        <div class="edit-faktur-heading">
            <div>
                <span class="label-kecil-edit">FAKTUR PEMBELIAN</span>
                <h2>🧾 ${escapeHtmlEdit(faktur.nomor)}</h2>
            </div>

            <div class="badge-jumlah-item">
                ${jumlahBarang} item
            </div>
        </div>

        <div class="info-edit-grid">

            <div>
                <span>Nomor Faktur</span>
                <strong>${escapeHtmlEdit(faktur.nomor)}</strong>
            </div>

            <div>
                <span>Tanggal</span>
                <strong>${escapeHtmlEdit(faktur.tanggal)}</strong>
            </div>

            <div>
                <span>Distributor</span>
                <strong>${escapeHtmlEdit(faktur.distributorNama || "-")}</strong>
            </div>

        </div>

        <div class="catatan-edit">
            <strong>ℹ️ Catatan</strong><br>
            Perubahan jumlah dan penambahan barang akan langsung
            menyesuaikan stok pada Data Barang.
        </div>

    `;
}


// ======================================================
// TAMPILKAN BARANG DALAM FAKTUR
// ======================================================

function tampilkanBarangEdit(faktur) {

    const container = document.getElementById("daftarEditBarangFaktur");
    if (!container) return;

    const detail = Array.isArray(faktur.detail)
        ? faktur.detail
        : [];

    if (detail.length === 0) {
        container.innerHTML = `
            <div class="barang-kosong">
                <div class="barang-kosong-icon">📦</div>
                <strong>Belum ada barang</strong>
                <span>Gunakan pencarian di atas untuk menambahkan barang.</span>
            </div>
        `;
        return;
    }

    let html = "";

    detail.forEach(function(item, index) {

        const qty = Number(item.qty || 0);
        const harga = Number(item.harga ?? item.hargaBeli ?? 0);
        const subtotal = qty * harga;

        html += `

            <div class="edit-item-faktur">

                <div class="edit-item-header">

                    <div class="item-identitas-edit">
                        <div class="item-nomor-edit">${index + 1}</div>

                        <div>
                            <strong class="nama-barang">
                                ${escapeHtmlEdit(item.nama || "-")}
                            </strong>

                            <div class="kode-barang">
                                ${escapeHtmlEdit(item.kode || "-")}
                                ${item.satuan
                                    ? " • " + escapeHtmlEdit(item.satuan)
                                    : ""}
                            </div>
                        </div>
                    </div>

                    <div class="subtotal-edit">
                        ${formatRupiahEdit(subtotal)}
                    </div>

                </div>

                <div class="edit-row-form">

                    <div class="field-edit">
                        <label for="qty-edit-${index}">Jumlah</label>
                        <input
                            type="number"
                            id="qty-edit-${index}"
                            min="1"
                            step="1"
                            value="${qty}">
                    </div>

                    <div class="field-edit">
                        <label>Harga Beli</label>
                        <div class="harga-readonly-edit">
                            ${formatRupiahEdit(harga)}
                        </div>
                    </div>

                </div>

                <div class="aksi-item-edit">

                    <button
                        type="button"
                        class="tombol-simpan-item"
                        onclick="simpanPerubahanQty(${index})">
                        ✓ Simpan Jumlah
                    </button>

                    <button
                        type="button"
                        class="tombol-hapus-item-edit"
                        onclick="konfirmasiHapusBarangDariFaktur(${index})">
                        🗑️ Hapus
                    </button>

                </div>

            </div>
        `;
    });

    container.innerHTML = html;
}


// ======================================================
// SIMPAN DATABASE FAKTUR + BARANG
// ======================================================

function simpanFakturDanBarangEdit(faktur, semuaBarang) {

    const semuaFaktur = ambilSemuaFakturEdit();

    const indexFaktur = semuaFaktur.findIndex(function(item) {
        return String(item.id) === String(faktur.id);
    });

    if (indexFaktur === -1) return false;

    semuaFaktur[indexFaktur] = faktur;

    localStorage.setItem(
        "dataBarang",
        JSON.stringify(semuaBarang)
    );

    localStorage.setItem(
        "dataFaktur",
        JSON.stringify(semuaFaktur)
    );

    return true;
}


// ======================================================
// HITUNG TOTAL FAKTUR
// ======================================================

function hitungUlangTotalFakturEdit(faktur) {

    let total = 0;

    const detail = Array.isArray(faktur.detail)
        ? faktur.detail
        : [];

    detail.forEach(function(item) {

        const qty = Number(item.qty || 0);
        const harga = Number(item.harga ?? item.hargaBeli ?? 0);

        item.subtotal = qty * harga;
        total += item.subtotal;
    });

    faktur.subtotal = total;
    faktur.total = total;

    const totalRetur = Number(faktur.totalRetur || 0);
    const totalDibayar = Number(faktur.totalDibayar || 0);

    faktur.sisa = Math.max(
        0,
        total - totalRetur - totalDibayar
    );

    if (faktur.sisa <= 0) {
        faktur.status = "lunas";
    } else if (totalDibayar > 0) {
        faktur.status = "sebagian";
    } else {
        faktur.status = "belum";
    }
}


// ======================================================
// EDIT QTY
// ======================================================

function simpanPerubahanQty(index) {

    const faktur = ambilFakturEdit();

    if (!faktur || !Array.isArray(faktur.detail[index] ? faktur.detail : null)) {
        tampilkanNotifikasiFaktur(
            "Data tidak tersedia",
            "Faktur atau detail barang tidak ditemukan.",
            "error"
        );
        return;
    }

    const item = faktur.detail[index];
    const input = document.getElementById("qty-edit-" + index);

    if (!input) return;

    const qtyLama = Number(item.qty || 0);
    const qtyBaru = Number(input.value);

    if (!Number.isInteger(qtyBaru) || qtyBaru <= 0) {
        input.value = qtyLama;
        tampilkanNotifikasiFaktur(
            "Jumlah tidak valid",
            "Jumlah barang harus berupa angka bulat lebih dari 0.",
            "warning"
        );
        return;
    }

    if (qtyBaru === qtyLama) {
        tampilkanNotifikasiFaktur(
            "Tidak ada perubahan",
            "Jumlah barang masih sama seperti sebelumnya.",
            "info"
        );
        return;
    }

    const semuaBarang = ambilSemuaBarangEdit();
    const indexBarang = semuaBarang.findIndex(function(barang) {
        return barang && String(barang.id) === String(item.barangId);
    });

    if (indexBarang === -1) {
        tampilkanNotifikasiFaktur(
            "Barang tidak ditemukan",
            "Data barang tidak tersedia sehingga perubahan dibatalkan.",
            "error"
        );
        return;
    }

    const stokLama = Number(semuaBarang[indexBarang].stok || 0);
    const selisih = qtyBaru - qtyLama;
    const stokBaru = stokLama + selisih;

    if (stokBaru < 0) {
        tampilkanNotifikasiFaktur(
            "Stok tidak mencukupi",
            "Perubahan jumlah tidak dapat disimpan karena stok akan menjadi negatif.",
            "warning"
        );
        input.value = qtyLama;
        return;
    }

    semuaBarang[indexBarang].stok = stokBaru;
    item.qty = qtyBaru;

    hitungUlangTotalFakturEdit(faktur);

    if (!simpanFakturDanBarangEdit(faktur, semuaBarang)) {
        tampilkanNotifikasiFaktur(
            "Gagal menyimpan",
            "Perubahan belum tersimpan ke database aplikasi.",
            "error"
        );
        return;
    }

    tampilkanInformasiFakturEdit(faktur);
    tampilkanBarangEdit(faktur);

    tampilkanNotifikasiFaktur(
        "Perubahan berhasil disimpan",
        "Jumlah " + (item.nama || "barang") + " diperbarui dari " +
        qtyLama + " menjadi " + qtyBaru + ". Stok otomatis disesuaikan.",
        "success"
    );
}


// ======================================================
// HAPUS BARANG
// ======================================================

function konfirmasiHapusBarangDariFaktur(index) {

    const faktur = ambilFakturEdit();
    if (!faktur || !faktur.detail[index]) return;

    const item = faktur.detail[index];
    const qty = Number(item.qty || 0);

    tampilkanModalKonfirmasiFaktur(
        "Hapus barang dari faktur?",
        "Barang " + (item.nama || "ini") +
        " dengan jumlah " + qty +
        " akan dikeluarkan dari faktur dan stok akan disesuaikan.",
        function() {
            hapusBarangDariFaktur(index);
        },
        "🗑️"
    );
}

function hapusBarangDariFaktur(index) {

    const faktur = ambilFakturEdit();

    if (!faktur || !faktur.detail[index]) {
        tampilkanNotifikasiFaktur(
            "Data tidak ditemukan",
            "Barang yang akan dihapus tidak tersedia.",
            "error"
        );
        return;
    }

    const item = faktur.detail[index];
    const qty = Number(item.qty || 0);

    const semuaBarang = ambilSemuaBarangEdit();

    const indexBarang = semuaBarang.findIndex(function(barang) {
        return barang && String(barang.id) === String(item.barangId);
    });

    if (indexBarang === -1) {
        tampilkanNotifikasiFaktur(
            "Penghapusan dibatalkan",
            "Data barang tidak ditemukan sehingga stok tidak dapat disesuaikan dengan aman.",
            "error"
        );
        return;
    }

    const stokLama = Number(semuaBarang[indexBarang].stok || 0);
    const stokBaru = stokLama - qty;

    if (stokBaru < 0) {
        tampilkanNotifikasiFaktur(
            "Data stok tidak valid",
            "Penghapusan dibatalkan agar stok tidak menjadi negatif.",
            "error"
        );
        return;
    }

    semuaBarang[indexBarang].stok = stokBaru;
    faktur.detail.splice(index, 1);

    hitungUlangTotalFakturEdit(faktur);

    if (!simpanFakturDanBarangEdit(faktur, semuaBarang)) {
        tampilkanNotifikasiFaktur(
            "Gagal menyimpan",
            "Barang belum dihapus karena perubahan database gagal disimpan.",
            "error"
        );
        return;
    }

    tampilkanInformasiFakturEdit(faktur);
    tampilkanBarangEdit(faktur);

    tampilkanNotifikasiFaktur(
        "Barang berhasil dihapus",
        (item.nama || "Barang") + " telah dikeluarkan dari faktur dan stok otomatis disesuaikan.",
        "success"
    );
}


// ======================================================
// PENCARIAN BARANG UNTUK TAMBAH
// ======================================================

function cariBarangEdit() {

    const input = document.getElementById("cariBarangEdit");
    const hasil = document.getElementById("hasilCariBarangEdit");

    if (!input || !hasil) return;

    const kata = input.value.trim().toLowerCase();
    hasil.innerHTML = "";

    if (!kata) return;

    const dataBarang = ambilSemuaBarangEdit();

    const ditemukan = dataBarang
        .filter(function(barang) {
            if (!barang || barang.id === undefined || barang.id === null) {
                return false;
            }

            const kode = String(barang.kode || "").toLowerCase();
            const nama = String(barang.nama || "").toLowerCase();

            return kode.includes(kata) || nama.includes(kata);
        })
        .slice(0, 10);

    if (ditemukan.length === 0) {
        hasil.innerHTML = `
            <div class="hasil-cari-kosong-edit">
                Barang tidak ditemukan.
            </div>
        `;
        return;
    }

    hasil.innerHTML = ditemukan.map(function(barang) {
        return `
            <button
                type="button"
                class="hasil-cari-item-edit"
                onclick="pilihBarangEdit(${Number(barang.id)})">

                <strong>${escapeHtmlEdit(barang.nama)}</strong>

                <span>
                    ${escapeHtmlEdit(barang.kode || "-")}
                    • ${escapeHtmlEdit(barang.satuan || "-")}
                    • Stok ${Number(barang.stok || 0)}
                </span>

            </button>
        `;
    }).join("");
}

function pilihBarangEdit(id) {

    const dataBarang = ambilSemuaBarangEdit();

    const barang = dataBarang.find(function(item) {
        return item && String(item.id) === String(id);
    });

    if (!barang) {
        tampilkanNotifikasiFaktur(
            "Barang tidak ditemukan",
            "Data barang mungkin sudah dihapus.",
            "error"
        );
        return;
    }

    document.getElementById("barangEditId").value = barang.id;
    document.getElementById("cariBarangEdit").value = barang.nama || "";
    document.getElementById("namaBarangTerpilihEdit").textContent = barang.nama || "";
    document.getElementById("infoBarangTerpilihEdit").textContent =
        `${barang.kode || ""} • ${barang.satuan || ""} • Stok ${Number(barang.stok || 0)}`;

    document.getElementById("barangTerpilihEdit").style.display = "flex";
    document.getElementById("hasilCariBarangEdit").innerHTML = "";

    const harga = document.getElementById("hargaBeliBarangEdit");
    if (harga) {
        harga.value = formatAngkaUang(barang.hargaBeli || 0);
    }

    const qty = document.getElementById("qtyBarangEdit");
    if (qty) {
        qty.focus();
    }
}

function resetPencarianBarangEdit() {

    const input = document.getElementById("cariBarangEdit");
    const hasil = document.getElementById("hasilCariBarangEdit");
    const terpilih = document.getElementById("barangTerpilihEdit");
    const id = document.getElementById("barangEditId");
    const qty = document.getElementById("qtyBarangEdit");
    const harga = document.getElementById("hargaBeliBarangEdit");

    if (input) input.value = "";
    if (hasil) hasil.innerHTML = "";
    if (terpilih) terpilih.style.display = "none";
    if (id) id.value = "";
    if (qty) qty.value = "";
    if (harga) harga.value = "";
}


// ======================================================
// TAMBAH BARANG KE FAKTUR
// ======================================================

function tambahBarangKeFakturEdit() {

    const id = document.getElementById("barangEditId")?.value || "";
    const qty = Number(document.getElementById("qtyBarangEdit")?.value || 0);
    const harga = nilaiUangInput("hargaBeliBarangEdit");

    if (!id) {
        tampilkanNotifikasiFaktur(
            "Pilih barang terlebih dahulu",
            "Ketik nama atau kode barang, lalu pilih barang dari hasil pencarian.",
            "warning"
        );
        return;
    }

    if (!Number.isInteger(qty) || qty <= 0) {
        tampilkanNotifikasiFaktur(
            "Jumlah tidak valid",
            "Masukkan jumlah barang berupa angka bulat lebih dari 0.",
            "warning"
        );
        return;
    }

    if (!Number.isFinite(harga) || harga < 0) {
        tampilkanNotifikasiFaktur(
            "Harga tidak valid",
            "Harga beli tidak boleh negatif.",
            "warning"
        );
        return;
    }

    const faktur = ambilFakturEdit();
    const semuaBarang = ambilSemuaBarangEdit();

    if (!faktur) {
        tampilkanNotifikasiFaktur(
            "Faktur tidak ditemukan",
            "Barang tidak dapat ditambahkan karena faktur tidak tersedia.",
            "error"
        );
        return;
    }

    const indexBarang = semuaBarang.findIndex(function(barang) {
        return barang && String(barang.id) === String(id);
    });

    if (indexBarang === -1) {
        tampilkanNotifikasiFaktur(
            "Barang tidak ditemukan",
            "Data barang tidak tersedia.",
            "error"
        );
        return;
    }

    const barang = semuaBarang[indexBarang];

    if (!Array.isArray(faktur.detail)) {
        faktur.detail = [];
    }

    const itemLama = faktur.detail.find(function(item) {
        return String(item.barangId) === String(barang.id);
    });

    const stokLama = Number(barang.stok || 0);
    barang.stok = stokLama + qty;

    if (itemLama) {
        itemLama.qty = Number(itemLama.qty || 0) + qty;
        itemLama.harga = harga;
        itemLama.kode = barang.kode;
        itemLama.nama = barang.nama;
        itemLama.satuan = barang.satuan;

        tampilkanNotifikasiFaktur(
            "Barang ditambahkan",
            `${barang.nama} sudah ada di faktur. Jumlah ditambah ${qty} dan stok otomatis diperbarui.`,
            "success"
        );
    } else {
        faktur.detail.push({
            barangId: Number(barang.id),
            kode: barang.kode,
            nama: barang.nama,
            satuan: barang.satuan,
            qty: qty,
            harga: harga
        });

        tampilkanNotifikasiFaktur(
            "Barang berhasil ditambahkan",
            `${barang.nama} (${qty} ${barang.satuan || "item"}) ditambahkan ke faktur.`,
            "success"
        );
    }

    hitungUlangTotalFakturEdit(faktur);

    if (!simpanFakturDanBarangEdit(faktur, semuaBarang)) {
        // rollback paling aman dengan reload data dari localStorage yang belum berubah tidak tersedia,
        // tetapi localStorage hanya ditulis setelah seluruh perubahan selesai; simpanFakturAndBarang melakukan dua write.
        tampilkanNotifikasiFaktur(
            "Gagal menyimpan",
            "Perubahan tidak dapat disimpan ke database aplikasi.",
            "error"
        );
        return;
    }

    tampilkanInformasiFakturEdit(faktur);
    tampilkanBarangEdit(faktur);
    resetPencarianBarangEdit();
}


// ======================================================
// NAVIGASI
// ======================================================

function kembaliKeDetailFaktur() {
    appBack("detail-faktur.html");
}


// ======================================================
// INIT
// ======================================================

document.addEventListener("DOMContentLoaded", function() {

    const faktur = ambilFakturEdit();

    if (!faktur) {
        const informasi = document.getElementById("informasiFakturEdit");
        if (informasi) {
            informasi.innerHTML = `
                <div class="barang-kosong">
                    <div class="barang-kosong-icon">⚠️</div>
                    <strong>Faktur tidak ditemukan</strong>
                    <span>Silakan kembali ke daftar faktur dan pilih faktur yang ingin diedit.</span>
                </div>
            `;
        }
        return;
    }

    tampilkanInformasiFakturEdit(faktur);
    tampilkanBarangEdit(faktur);

    const input = document.getElementById("cariBarangEdit");
    if (input) {
        input.addEventListener("input", cariBarangEdit);
    }
});


// Tutup modal jika area luar modal disentuh.
document.addEventListener("click", function(event) {

    const modal = document.getElementById("modalKonfirmasiFaktur");

    if (modal && event.target === modal) {
        tutupModalKonfirmasiFaktur();
    }
});
