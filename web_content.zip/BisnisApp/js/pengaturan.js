// ======================================================
// PENGATURAN BISNISAPP
// ======================================================


// ======================================================
// LOAD PENGATURAN
// ======================================================

function muatPengaturan() {

    const data =
        JSON.parse(
            localStorage.getItem(
                "pengaturanBisnis"
            ) || "{}"
        );


    document.getElementById(
        "namaToko"
    ).value =
        data.namaToko || "";

  
document.getElementById(
    "deskripsiUsaha"
).value =
    data.deskripsiUsaha || "";
  

    document.getElementById(
        "alamatToko"
    ).value =
        data.alamatToko || "";


    document.getElementById(
        "nomorHP"
    ).value =
        data.nomorHP || "";


    document.getElementById(
        "namaPemilik"
    ).value =
        data.namaPemilik || "";


    document.getElementById(
        "prefixPenjualan"
    ).value =
        data.prefixPenjualan ||
        "TRX";


    document.getElementById(
        "prefixPembelian"
    ).value =
        data.prefixPembelian ||
        "FB";

}


// ======================================================
// SIMPAN PENGATURAN
// ======================================================

function simpanPengaturan() {

    const data = {

        namaToko:
            document.getElementById(
                "namaToko"
            ).value.trim(),


      deskripsiUsaha:
    document.getElementById(
        "deskripsiUsaha"
    ).value.trim(),

      
        alamatToko:
            document.getElementById(
                "alamatToko"
            ).value.trim(),


        nomorHP:
            document.getElementById(
                "nomorHP"
            ).value.trim(),


        namaPemilik:
            document.getElementById(
                "namaPemilik"
            ).value.trim(),


        prefixPenjualan:
            document.getElementById(
                "prefixPenjualan"
            ).value.trim() ||
            "TRX",


        prefixPembelian:
            document.getElementById(
                "prefixPembelian"
            ).value.trim() ||
            "FB"

    };


    localStorage.setItem(

        "pengaturanBisnis",

        JSON.stringify(data)

    );


    alert(
        "Pengaturan berhasil disimpan."
    );

}


// ======================================================
// JALANKAN
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    muatPengaturan
);