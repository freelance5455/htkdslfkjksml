// ======================================================
// RETUR BARANG PEMBELIAN
// ======================================================


// ======================================================
// FORMAT RUPIAH
// ======================================================

function formatRupiahRetur(angka) {

    return "Rp " +
        Number(angka || 0)
        .toLocaleString("id-ID");

}


// ======================================================
// AMBIL FAKTUR
// ======================================================

function ambilFakturRetur() {

    const id =
        localStorage.getItem(
            "fakturDetailId"
        );


    if (!id) {
        return null;
    }


    const data =
        JSON.parse(
            localStorage.getItem(
                "dataFaktur"
            ) || "[]"
        );


    return data.find(function(f) {

        return String(f.id) ===
            String(id);

    });

}


// ======================================================
// HITUNG TOTAL RETUR YANG SUDAH TERJADI
// UNTUK BARANG TERTENTU
// ======================================================

function qtySudahDiretur(
    nomorFaktur,
    kodeBarang
) {

    const dataRetur =
        JSON.parse(
            localStorage.getItem(
                "dataRetur"
            ) || "[]"
        );


    let jumlah = 0;


    dataRetur.forEach(function(retur) {

        if (
            String(retur.nomorFaktur) ===
                String(nomorFaktur) &&

            String(retur.kode) ===
                String(kodeBarang)
        ) {

            jumlah +=
                Number(retur.qty || 0);

        }

    });


    return jumlah;

}


// ======================================================
// TAMPILKAN FORM RETUR
// ======================================================

function tampilkanRetur() {

    const container =
        document.getElementById(
            "returContainer"
        );


    const faktur =
        ambilFakturRetur();


    if (!faktur) {

        container.innerHTML = `

            <div class="retur-card">

                ❌ Faktur tidak ditemukan.

            </div>

        `;

        return;

    }


    const detail =
        faktur.detail || [];


    if (detail.length === 0) {

        container.innerHTML = `

            <div class="retur-card">

                ❌ Faktur tidak mempunyai detail barang.

            </div>

        `;

        return;

    }


    let html = `

        <div class="retur-card">

            <h2>${faktur.nomor}</h2>

            <div class="retur-info">

                <div>
                    <strong>Distributor:</strong>
                    ${faktur.distributorNama || "-"}
                </div>

                <div>
                    <strong>Tanggal:</strong>
                    ${faktur.tanggal}
                </div>

            </div>

            <p>
                Masukkan jumlah barang yang ingin diretur.
            </p>

        </div>


        <div class="retur-card">

    `;


    detail.forEach(function(item, index) {

        const qtyBeli =
            Number(item.qty || 0);


        const sudahRetur =
            qtySudahDiretur(
                faktur.nomor,
                item.kode
            );


        const sisaRetur =
            Math.max(
                0,
                qtyBeli - sudahRetur
            );


        const harga =
            Number(
                item.harga ??
                item.hargaBeli ??
                0
            );


        html += `

            <div class="item-retur">

                <h3>
                    ${item.nama}
                </h3>

                <small>
                    Kode: ${item.kode}
                </small>


                <div class="retur-info">

                    <div>
                        Qty dibeli:
                        <strong>
                            ${qtyBeli}
                            ${item.satuan || ""}
                        </strong>
                    </div>

                    <div>
                        Sudah diretur:
                        <strong>
                            ${sudahRetur}
                        </strong>
                    </div>

                    <div>
                        Sisa dapat diretur:
                        <strong>
                            ${sisaRetur}
                        </strong>
                    </div>

                </div>


                <label>
                    Qty Retur
                </label>

                <input
                    type="number"
                    id="qtyRetur_${index}"
                    min="0"
                    max="${sisaRetur}"
                    value="0"
                    data-index="${index}"
                    data-kode="${item.kode}"
                    oninput="hitungNilaiRetur(${index})"
                >


                <label>
                    Alasan Retur
                </label>

                <select
                    id="alasanRetur_${index}"
                >

                    <option value="Rusak">
                        Rusak
                    </option>

                    <option value="Salah Barang">
                        Salah Barang
                    </option>

                    <option value="Tidak Sesuai">
                        Tidak Sesuai
                    </option>

                    <option value="Kelebihan">
                        Kelebihan
                    </option>

                    <option value="Lainnya">
                        Lainnya
                    </option>

                </select>


                <div class="nilai-retur">

                    Nilai:
                    <strong id="nilaiRetur_${index}">
                        Rp 0
                    </strong>

                </div>

            </div>

        `;

    });


    html += `

            <button
                class="tombol-simpan-retur"
                onclick="simpanRetur()">

                ↩️ Simpan Retur

            </button>


            <button
                class="tombol-kembali-retur"
                onclick="history.back()">

                ← Batal

            </button>

        </div>

    `;


    container.innerHTML = html;

}


// ======================================================
// HITUNG NILAI RETUR
// ======================================================

function hitungNilaiRetur(index) {

    const faktur =
        ambilFakturRetur();


    if (!faktur) {
        return;
    }


    const item =
        faktur.detail[index];


    const qty =
        Number(
            document.getElementById(
                "qtyRetur_" + index
            ).value
        ) || 0;


    const harga =
        Number(
            item.harga ??
            item.hargaBeli ??
            0
        );


    const total =
        qty * harga;


    document.getElementById(
        "nilaiRetur_" + index
    ).innerText =
        formatRupiahRetur(total);

}


// ======================================================
// SIMPAN RETUR
// ======================================================

function simpanRetur() {

    const faktur =
        ambilFakturRetur();


    if (!faktur) {

        alert(
            "Faktur tidak ditemukan."
        );

        return;

    }


    const detail =
        faktur.detail || [];


    let adaRetur = false;


    // ==============================================
    // DATA LAMA
    // ==============================================

    let dataRetur =
        JSON.parse(
            localStorage.getItem(
                "dataRetur"
            ) || "[]"
        );


    let dataBarang =
        JSON.parse(
            localStorage.getItem(
                "dataBarang"
            ) || "[]"
        );


    let totalNilaiRetur = 0;


    // ==============================================
    // PERIKSA SEMUA ITEM
    // ==============================================

    for (
        let index = 0;
        index < detail.length;
        index++
    ) {

        const item =
            detail[index];


        const input =
            document.getElementById(
                "qtyRetur_" + index
            );


        const qty =
            Number(
                input.value
            ) || 0;


        if (qty <= 0) {
            continue;
        }


        adaRetur = true;


        const qtyBeli =
            Number(item.qty || 0);


        const sudahRetur =
            qtySudahDiretur(
                faktur.nomor,
                item.kode
            );


        const sisa =
            qtyBeli - sudahRetur;


        if (qty > sisa) {

            alert(
                "Qty retur " +
                item.nama +
                " melebihi sisa yang dapat diretur."
            );

            return;

        }


        // ==========================================
        // CARI BARANG
        // ==========================================

        const indexBarang =
            dataBarang.findIndex(
                function(b) {

                    return String(b.kode) ===
                        String(item.kode);

                }
            );


        if (indexBarang === -1) {

            alert(
                "Barang " +
                item.nama +
                " tidak ditemukan di database."
            );

            return;

        }


        const stokSekarang =
            Number(
                dataBarang[indexBarang].stok || 0
            );


        // ==========================================
        // JANGAN BIARKAN STOK MINUS
        // ==========================================

        if (qty > stokSekarang) {

            alert(
                "Stok " +
                item.nama +
                " tidak mencukupi untuk retur.\n\n" +
                "Stok sekarang: " +
                stokSekarang +
                "\n" +
                "Qty retur: " +
                qty
            );

            return;

        }

    }


    if (!adaRetur) {

        alert(
            "Masukkan minimal satu Qty Retur."
        );

        return;

    }


    // ==============================================
    // SIMPAN SETIAP RETUR
    // ==============================================

    for (
        let index = 0;
        index < detail.length;
        index++
    ) {

        const item =
            detail[index];


        const qty =
            Number(
                document.getElementById(
                    "qtyRetur_" + index
                ).value
            ) || 0;


        if (qty <= 0) {
            continue;
        }


        const alasan =
            document.getElementById(
                "alasanRetur_" + index
            ).value;


        const harga =
            Number(
                item.harga ??
                item.hargaBeli ??
                0
            );


        const nilai =
            qty * harga;


        totalNilaiRetur +=
            nilai;


        // ==========================================
        // KURANGI STOK
        // ==========================================

        const indexBarang =
            dataBarang.findIndex(
                function(b) {

                    return String(b.kode) ===
                        String(item.kode);

                }
            );


        dataBarang[indexBarang].stok =
            Number(
                dataBarang[indexBarang].stok || 0
            ) - qty;


        // ==========================================
        // SIMPAN RIWAYAT RETUR
        // ==========================================

        dataRetur.push({

            id: Date.now() +
                Math.floor(
                    Math.random() * 1000
                ),

            nomorFaktur:
                faktur.nomor,

            fakturId:
                faktur.id,

            tanggal:
                new Date()
                .toISOString()
                .split("T")[0],

            kode:
                item.kode,

            nama:
                item.nama,

            satuan:
                item.satuan || "",

            qty:
                qty,

            harga:
                harga,

            total:
                nilai,

            alasan:
                alasan

        });

    }


    // ==============================================
    // UPDATE TOTAL RETUR FAKTUR
    // ==============================================

    faktur.totalRetur =
        Number(
            faktur.totalRetur || 0
        ) + totalNilaiRetur;


    // ==============================================
    // UPDATE SISA
    // ==============================================

    faktur.sisa =
        Math.max(
            0,
            Number(faktur.total || 0) -
            Number(faktur.totalRetur || 0) -
            Number(faktur.totalDibayar || 0)
        );


    // ==============================================
    // UPDATE STATUS
    // ==============================================

    if (faktur.sisa <= 0) {

        faktur.status =
            "lunas";

    }

    else if (
        Number(faktur.totalDibayar || 0) > 0
    ) {

        faktur.status =
            "sebagian";

    }

    else {

        faktur.status =
            "belum";

    }


    // ==============================================
    // UPDATE DATA FAKTUR
    // ==============================================

    const dataFaktur =
        JSON.parse(
            localStorage.getItem(
                "dataFaktur"
            ) || "[]"
        );


    const indexFaktur =
        dataFaktur.findIndex(
            function(f) {

                return String(f.id) ===
                    String(faktur.id);

            }
        );


    if (indexFaktur === -1) {

        alert(
            "Data faktur tidak ditemukan."
        );

        return;

    }


    dataFaktur[indexFaktur] =
        faktur;


    // ==============================================
    // SIMPAN SEMUA
    // ==============================================

    localStorage.setItem(
        "dataBarang",
        JSON.stringify(dataBarang)
    );


    localStorage.setItem(
        "dataRetur",
        JSON.stringify(dataRetur)
    );


    localStorage.setItem(
        "dataFaktur",
        JSON.stringify(dataFaktur)
    );


    alert(
        "Retur berhasil disimpan.\n\n" +
        "Nilai retur: " +
        formatRupiahRetur(
            totalNilaiRetur
        ) +
        "\n\nStok barang otomatis berkurang."
    );


    // Kembali ke detail
    location.href =
        "detail-faktur.html";

}


// ======================================================
// JALANKAN
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    tampilkanRetur
);