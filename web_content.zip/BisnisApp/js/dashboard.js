/* ========================================
   DASHBOARD BISNISAPP
======================================== */


/* ==============================
   FORMAT RUPIAH
============================== */

function formatRupiahDashboard(angka) {

    return "Rp " + Number(angka || 0).toLocaleString("id-ID");

}


/* ==============================
   FORMAT TANGGAL
============================== */

function tanggalHariIni() {

    const sekarang = new Date();

    return sekarang.toLocaleDateString("id-ID", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
    });

}


/* ==============================
   TANGGAL DATABASE
============================== */

function tanggalDatabaseHariIni() {

    const sekarang = new Date();

    const tahun = sekarang.getFullYear();

    const bulan = String(
        sekarang.getMonth() + 1
    ).padStart(2, "0");

    const hari = String(
        sekarang.getDate()
    ).padStart(2, "0");

    return `${tahun}-${bulan}-${hari}`;

}


/* ==============================
   AMBIL DATA DASHBOARD
============================== */

function ambilDataDashboard() {

    const penjualan =
        JSON.parse(
            localStorage.getItem("dataPenjualan")
        ) || [];

    const barang =
        JSON.parse(
            localStorage.getItem("dataBarang")
        ) || [];

    return {
        penjualan,
        barang
    };

}


/* ==============================
   TAMPILKAN IDENTITAS TOKO
============================== */

function tampilkanNamaUsaha() {

    const pengaturan =
        JSON.parse(
            localStorage.getItem(
                "pengaturanBisnis"
            ) || "{}"
        );


    /* ==========================
       NAMA TOKO
    =========================== */

    const namaToko =
        pengaturan.namaToko ||
        "BisnisApp";


    const tempatNama =
        document.getElementById(
            "namaUsahaDashboard"
        );


    if (tempatNama) {

        tempatNama.textContent =
            namaToko;

    }



    /* ==========================
       ALAMAT
    =========================== */

    const alamat =
        pengaturan.alamatToko ||
        "-";


    const tempatAlamat =
        document.getElementById(
            "alamatUsahaDashboard"
        );


    if (tempatAlamat) {

        tempatAlamat.textContent =
            "📍 " + alamat;

    }


    /* ==========================
       NOMOR HP
    =========================== */

    const nomorHP =
        pengaturan.nomorHP ||
        "-";


    const tempatHP =
        document.getElementById(
            "nomorHPUsahaDashboard"
        );


    if (tempatHP) {

        tempatHP.textContent =
            "📞 " + nomorHP;

    }


    /* ==========================
       NAMA PEMILIK
    =========================== */

    const namaPemilik =
        pengaturan.namaPemilik ||
        "-";


    const tempatPemilik =
        document.getElementById(
            "namaPemilikDashboard"
        );


    if (tempatPemilik) {

        tempatPemilik.textContent =
            "👤 " + namaPemilik;

    }

    /* --------------------------
       DESKRIPSI USAHA
    --------------------------- */

    const deskripsi =
        pengaturan.deskripsiUsaha ||
        "Ringkasan bisnis hari ini";


    const tempatDeskripsi =
        document.getElementById(
            "deskripsiUsahaDashboard"
        );


    if (tempatDeskripsi) {

        tempatDeskripsi.textContent =
            deskripsi;

    }
}

/* ==============================
   DASHBOARD UTAMA
============================== */

function tampilkanDashboard() {

    const data =
        ambilDataDashboard();


    const tanggalHariIniDatabase =
        tanggalDatabaseHariIni();


    /* --------------------------
       TAMPILKAN TANGGAL
    --------------------------- */

    const tanggal =
        document.getElementById(
            "tanggalHariIni"
        );


    if (tanggal) {

        tanggal.textContent =
            tanggalHariIni();

    }


    /* --------------------------
       FILTER PENJUALAN HARI INI
    --------------------------- */

    const transaksiHariIni =
        data.penjualan.filter(
            function(transaksi) {

                return (
                    transaksi.tanggal ===
                    tanggalHariIniDatabase
                );

            }
        );


    /* --------------------------
       HITUNG PENJUALAN & LABA
    --------------------------- */

    let totalPenjualan = 0;

    let totalLaba = 0;


    transaksiHariIni.forEach(
        function(transaksi) {

            totalPenjualan +=
                Number(
                    transaksi.total || 0
                );


            totalLaba +=
                Number(
                    transaksi.labaKotor || 0
                );

        }
    );


    /* --------------------------
       JUMLAH BARANG
    --------------------------- */

    const jumlahBarang =
        data.barang.length;


    /* --------------------------
       STOK MENIPIS
    --------------------------- */

    const barangMenipis =
        data.barang.filter(
            function(barang) {

                const stok =
                    Number(
                        barang.stok || 0
                    );


                const minimum =
                    Number(
                        barang.minimumStok || 0
                    );


                return stok <= minimum;

            }
        );


    /* --------------------------
       TAMPILKAN PENJUALAN
    --------------------------- */

    const penjualan =
        document.getElementById(
            "penjualanHariIni"
        );


    if (penjualan) {

        penjualan.textContent =
            formatRupiahDashboard(
                totalPenjualan
            );

    }


    /* --------------------------
       TAMPILKAN LABA
    --------------------------- */

    const laba =
        document.getElementById(
            "labaHariIni"
        );


    if (laba) {

        laba.textContent =
            formatRupiahDashboard(
                totalLaba
            );

    }


    /* --------------------------
       TAMPILKAN JUMLAH BARANG
    --------------------------- */

    const jumlah =
        document.getElementById(
            "jumlahBarang"
        );


    if (jumlah) {

        jumlah.textContent =
            jumlahBarang;

    }


    /* --------------------------
       TAMPILKAN STOK MENIPIS
    --------------------------- */

    const stok =
        document.getElementById(
            "stokMenipis"
        );


    if (stok) {

        stok.textContent =
            barangMenipis.length;

    }


    /* --------------------------
       TRANSAKSI TERBARU
    --------------------------- */

    tampilkanTransaksiTerbaru(
        data.penjualan
    );


    /* --------------------------
       STOK MENIPIS
    --------------------------- */

    tampilkanStokMenipis(
        barangMenipis
    );

}


/* ==============================
   TRANSAKSI TERBARU
============================== */

function tampilkanTransaksiTerbaru(
    dataPenjualan
) {

    const tempat =
        document.getElementById(
            "aktivitasTerbaru"
        );


    if (!tempat) {

        return;

    }


    if (
        !dataPenjualan ||
        dataPenjualan.length === 0
    ) {

        tempat.innerHTML = `
            <div class="dashboard-kosong">
                Belum ada transaksi penjualan.
            </div>
        `;

        return;

    }


    const transaksiTerbaru =
        [...dataPenjualan]
        .sort(
            function(a, b) {

                return Number(b.id || 0)
                    -
                    Number(a.id || 0);

            }
        )
        .slice(0, 5);


    tempat.innerHTML =
        transaksiTerbaru.map(
            function(transaksi) {

                return `
                    <div class="aktivitas-item">

                        <div class="aktivitas-kiri">

                            <div class="aktivitas-nomor">
                                ${escapeHtml(
                                    transaksi.nomor || "-"
                                )}
                            </div>

                            <div class="aktivitas-waktu">
                                ${escapeHtml(
                                    transaksi.tanggal || ""
                                )}
                                ${escapeHtml(
                                    transaksi.waktu || ""
                                )}
                            </div>

                        </div>

                        <div class="aktivitas-total">
                            ${formatRupiahDashboard(
                                transaksi.total
                            )}
                        </div>

                    </div>
                `;

            }
        )
        .join("");

}


/* ==============================
   STOK MENIPIS
============================== */

function tampilkanStokMenipis(
    barangMenipis
) {

    const tempat =
        document.getElementById(
            "daftarStokMenipis"
        );


    if (!tempat) {

        return;

    }


    if (
        !barangMenipis ||
        barangMenipis.length === 0
    ) {

        tempat.innerHTML = `
            <div class="dashboard-kosong">
                ✅ Semua stok masih aman.
            </div>
        `;

        return;

    }


    const daftar =
        [...barangMenipis]
        .sort(
            function(a, b) {

                return Number(a.stok || 0)
                    -
                    Number(b.stok || 0);

            }
        )
        .slice(0, 5);


    tempat.innerHTML =
        daftar.map(
            function(barang) {

                return `
                    <div class="stok-item">

                        <div>

                            <div class="stok-nama">
                                ${escapeHtml(
                                    barang.nama || "-"
                                )}
                            </div>

                            <div class="stok-kode">
                                ${escapeHtml(
                                    barang.kode || "-"
                                )}
                            </div>

                        </div>

                        <div class="stok-jumlah">

                            ${Number(
                                barang.stok || 0
                            )}

                            ${escapeHtml(
                                barang.satuan || ""
                            )}

                        </div>

                    </div>
                `;

            }
        )
        .join("");

}


/* ==============================
   KEAMANAN HTML
============================== */

function escapeHtml(teks) {

    return String(teks || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* ==============================
   JALANKAN DASHBOARD
============================== */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanNamaUsaha();

        tampilkanDashboard();

    }
);