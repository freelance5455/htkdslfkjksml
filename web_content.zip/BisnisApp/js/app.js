// BISNISAPP — NAVIGASI MOBILE (V2 FIX)
// Semua perpindahan antar halaman internal memakai location.replace(),
// sehingga riwayat browser tidak menumpuk dan tombol Back Android tidak
// kembali melewati puluhan halaman yang sebelumnya dibuka.
const APP_PARENT_PAGE = {
  "detail-faktur.html":"pembelian.html",
  "edit-detailfaktur.html":"detail-faktur.html",
  "pembayaran.html":"detail-faktur.html",
  "retur.html":"detail-faktur.html",
  "distributor.html":"pembelian.html",
  "barang.html":"daftar-barang.html",
  "riwayat-harga.html":"daftar-barang.html",
  "riwayat-penjualan.html":"kasir.html",
  "laporan.html":"menu.html",
  "pengaturan.html":"menu.html",
  "backup.html":"menu.html",
  "menu.html":"index.html",
  "kasir.html":"index.html",
  "pembelian.html":"menu.html",
  "daftar-barang.html":"barang.html",
  "index.html":"index.html"
};

function halamanSaatIni(){ return location.pathname.split("/").pop() || "index.html"; }

function appBack(fallback){
  // Tombol Kembali DI DALAM halaman hanya kembali ke halaman induknya.
  // Jangan logout dan jangan memakai history.back(), karena history Android
  // sengaja tidak dipakai sebagai navigasi internal BisnisApp.
  const parent = fallback || APP_PARENT_PAGE[halamanSaatIni()] || "index.html";
  try {
    location.replace(parent);
  } catch (_) {
    location.href = parent;
  }
}

// Bisa dipanggil dari onclick HTML maupun file JS halaman.
window.appBack = appBack;
window.kembaliKe = appBack;

// Pengaman: tombol Kembali internal harus memakai rute aplikasi, bukan
// history browser. Halaman yang dibuat dinamis juga dapat memanggil appBack().
window.addEventListener("popstate", function () {
  // Tidak melakukan history.back(). Dengan navigasi internal berbasis replace(),
  // event ini hanya dipakai sebagai fallback ketika host/WebView memunculkan popstate.
  try {
    const current = halamanSaatIni();
    const parent = APP_PARENT_PAGE[current];
    if (parent) location.replace(parent);
  } catch (_) {}
});

(function resetAppHistory(){
  try {
    // Jangan pushState. replaceState hanya menandai entry aktif tanpa
    // menambah tumpukan history.
    history.replaceState({bisnisApp:true,page:location.pathname}, "", location.href);
    sessionStorage.setItem("bisnisAppCurrentPage", halamanSaatIni());
  } catch(_) {}
})();
