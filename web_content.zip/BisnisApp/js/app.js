// ======================================================
// BISNISAPP — NAVIGASI HALAMAN
// ======================================================
const APP_PARENT_PAGE = {
    "detail-faktur.html":"pembelian.html",
    "edit-detailfaktur.html":"detail-faktur.html",
    "pembayaran.html":"detail-faktur.html",
    "retur.html":"detail-faktur.html",
    "distributor.html":"pembelian.html",
    "barang.html":"daftar-barang.html",
    "riwayat-harga.html":"daftar-barang.html",
    "riwayat-penjualan.html":"kasir.html",
    "laporan.html":"menu.html",
    "pengaturan.html":"menu.html"
};

function halamanSaatIni() {
    return location.pathname.split("/").pop() || "index.html";
}

function appBack(fallback) {
    const parent = fallback || APP_PARENT_PAGE[halamanSaatIni()] || "index.html";
    if (typeof logoutBisnisApp === "function") {
        logoutBisnisApp("Tombol kembali aplikasi digunakan. Sesi ditutup.");
    } else {
        location.replace(parent);
    }
}

// Buat satu entry riwayat sehingga Back Android dapat ditangani oleh aplikasi.
(function siapkanNavigasiAplikasi() {
    try {
        if (!history.state || !history.state.bisnisApp) {
            history.pushState(
                { bisnisApp:true, page:location.pathname },
                "",
                location.href
            );
        }
        sessionStorage.setItem("bisnisAppCurrentPage", halamanSaatIni());
    } catch (_) {}
})();
