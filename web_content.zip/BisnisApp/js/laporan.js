/* =====================================================
   LAPORAN BISNISAPP
   ===================================================== */


/* =========================
   FORMAT RUPIAH
   ========================= */

function formatRupiahLaporan(angka) {

    return "Rp" + Number(angka || 0).toLocaleString("id-ID");

}


/* =========================
   ESCAPE HTML
   ========================= */

function escapeHtmlLaporan(teks) {

    return String(teks ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* =========================
   AMBIL TANGGAL SAJA
   ========================= */

function ambilTanggalLaporan(tanggal) {

    if (!tanggal) {
        return "";
    }

    /*
       Bisa membaca:
       2026-09-04
       2026-09-04T10:30:00.000Z
    */

    if (String(tanggal).includes("T")) {

        const date = new Date(tanggal);

        if (!isNaN(date.getTime())) {

            const tahun =
                date.getFullYear();

            const bulan =
                String(date.getMonth() + 1)
                    .padStart(2, "0");

            const hari =
                String(date.getDate())
                    .padStart(2, "0");

            return `${tahun}-${bulan}-${hari}`;

        }

    }

    return String(tanggal).substring(0, 10);

}


/* =========================
   TANGGAL HARI INI
   ========================= */

function tanggalHariIni() {

    const sekarang = new Date();

    const tahun =
        sekarang.getFullYear();

    const bulan =
        String(sekarang.getMonth() + 1)
            .padStart(2, "0");

    const tanggal =
        String(sekarang.getDate())
            .padStart(2, "0");

    return `${tahun}-${bulan}-${tanggal}`;

}


/* =========================
   FORMAT TANGGAL TAMPILAN
   ========================= */

function formatTanggalLaporan(tanggal) {

    const tanggalNormal =
        ambilTanggalLaporan(tanggal);

    if (!tanggalNormal) {
        return "-";
    }

    const bagian =
        tanggalNormal.split("-");

    if (bagian.length !== 3) {
        return escapeHtmlLaporan(tanggalNormal);
    }

    return `${bagian[2]}-${bagian[1]}-${bagian[0]}`;

}


/* =========================
   CEK DATA DALAM PERIODE
   ========================= */

function termasukPeriode(tanggal, periode) {

    const tanggalNormal =
        ambilTanggalLaporan(tanggal);

    if (!tanggalNormal) {
        return false;
    }


    const sekarang =
        new Date();


    /* =====================
       SEMUA DATA
       ===================== */

    if (periode === "semua") {

        return true;

    }


    /* =====================
       HARI INI
       ===================== */

    if (periode === "hari") {

        return (
            tanggalNormal ===
            tanggalHariIni()
        );

    }


    /* =====================
       7 HARI TERAKHIR
       ===================== */

    if (periode === "minggu") {

        const tanggalData =
            new Date(
                tanggalNormal + "T00:00:00"
            );

        const batas =
            new Date(sekarang);

        batas.setHours(0, 0, 0, 0);

        batas.setDate(
            batas.getDate() - 6
        );

        return tanggalData >= batas;

    }


    /* =====================
       BULAN INI
       ===================== */

    if (periode === "bulan") {

        const tanggalData =
            new Date(
                tanggalNormal + "T00:00:00"
            );

        return (
            tanggalData.getMonth() ===
                sekarang.getMonth() &&

            tanggalData.getFullYear() ===
                sekarang.getFullYear()
        );

    }


    return false;

}


/* =========================
   AMBIL DATA
   ========================= */

function ambilDataLaporan() {

    const penjualan =
        JSON.parse(
            localStorage.getItem("dataPenjualan")
        ) || [];


    const pembelian =
        JSON.parse(
            localStorage.getItem("dataFaktur")
        ) || [];


    const retur =
        JSON.parse(
            localStorage.getItem("dataRetur")
        ) || [];


    return {

        penjualan,
        pembelian,
        retur

    };

}


/* =====================================================
   BUKA DETAIL PENJUALAN
   ===================================================== */

function bukaDetailPenjualanLaporan(idPenjualan) {

    localStorage.setItem(
        "penjualanTerpilihId",
        String(idPenjualan)
    );


    location.replace(
        "riwayat-penjualan.html");

}


/* =====================================================
   BUKA DETAIL PEMBELIAN
   ===================================================== */

function bukaDetailPembelianLaporan(idFaktur) {

    localStorage.setItem(
        "fakturDetailId",
        String(idFaktur)
    );


    location.replace(
        "detail-faktur.html");

}


/* =========================
   TAMPILKAN LAPORAN
   ========================= */

function tampilkanLaporan() {

    const elemenPeriode =
        document.getElementById(
            "periodeLaporan"
        );


    const periode =
        elemenPeriode ?
        elemenPeriode.value :
        "hari";


    const data =
        ambilDataLaporan();


    /* =====================
       FILTER PENJUALAN
       ===================== */

    const penjualan =
        data.penjualan.filter(
            item =>
                termasukPeriode(
                    item.tanggal,
                    periode
                )
        );


    /* =====================
       FILTER PEMBELIAN
       ===================== */

    const pembelian =
        data.pembelian.filter(
            item =>
                termasukPeriode(
                    item.tanggal,
                    periode
                )
        );


    /* =====================
       FILTER RETUR
       ===================== */

    const retur =
        data.retur.filter(
            item =>
                termasukPeriode(
                    item.tanggal,
                    periode
                )
        );


    /* =====================
       TOTAL PENJUALAN
       ===================== */

    let totalPenjualan = 0;

    penjualan.forEach(
        item => {

            totalPenjualan +=
                Number(item.total || 0);

        }
    );


    /* =====================
       TOTAL PEMBELIAN
       ===================== */

    let totalPembelian = 0;

    pembelian.forEach(
        item => {

            totalPembelian +=
                Number(
                    item.total ||
                    item.subtotal ||
                    0
                );

        }
    );


    /* =====================
       TOTAL RETUR
       ===================== */

    let totalRetur = 0;

    retur.forEach(
        item => {

            totalRetur +=
                Number(
                    item.total ||
                    item.nilaiRetur ||
                    0
                );

        }
    );


    /* =====================
       TOTAL LABA
       ===================== */

    let totalLaba = 0;

    penjualan.forEach(
        item => {

            totalLaba +=
                Number(
                    item.labaKotor || 0
                );

        }
    );


    /* =====================
       TAMPILKAN RINGKASAN
       ===================== */

    document.getElementById(
        "totalPenjualan"
    ).textContent =
        formatRupiahLaporan(
            totalPenjualan
        );


    document.getElementById(
        "totalPembelian"
    ).textContent =
        formatRupiahLaporan(
            totalPembelian
        );


    document.getElementById(
        "totalRetur"
    ).textContent =
        formatRupiahLaporan(
            totalRetur
        );


    document.getElementById(
        "totalLaba"
    ).textContent =
        formatRupiahLaporan(
            totalLaba
        );


    /* =====================
       JUMLAH TRANSAKSI
       ===================== */

    document.getElementById(
        "jumlahPenjualan"
    ).textContent =
        penjualan.length;


    document.getElementById(
        "jumlahPembelian"
    ).textContent =
        pembelian.length;


    /* =====================
       DETAIL
       ===================== */

    tampilkanDetailPenjualan(
        penjualan
    );


    tampilkanDetailPembelian(
        pembelian
    );

}


/* =====================================================
   DETAIL PENJUALAN
   ===================================================== */

function tampilkanDetailPenjualan(data) {

    const tempat =
        document.getElementById(
            "detailPenjualan"
        );


    if (!tempat) {
        return;
    }


    if (data.length === 0) {

        tempat.innerHTML =
            '<div class="data-kosong">Belum ada penjualan pada periode ini.</div>';

        return;

    }


    let html = `

        <div class="tabel-scroll">

            <table class="tabel-laporan">

                <thead>

                    <tr>

                        <th>Tanggal</th>

                        <th>No. Transaksi</th>

                        <th>Total</th>

                        <th>Laba</th>

                    </tr>

                </thead>

                <tbody>

    `;


    data.forEach(
        (item, index) => {

            /*
               ID transaksi digunakan agar
               detail yang dipilih tepat.
            */

            const idPenjualan =
                String(
                    item.id ??
                    ""
                );


            /*
               Nomor transaksi.
               Jika belum ada, gunakan
               nomor berdasarkan urutan.
            */

            const nomor =
                item.nomor ||
                `TRX-${String(
                    index + 1
                ).padStart(4, "0")}`;


            html += `

                <tr
                    class="baris-bisa-diklik"
                    onclick="bukaDetailPenjualanLaporan('${escapeHtmlLaporan(idPenjualan)}')"
                    title="Ketuk untuk melihat detail transaksi"
                >

                    <td>

                        ${formatTanggalLaporan(
                            item.tanggal
                        )}

                    </td>


                    <td>

                        ${escapeHtmlLaporan(
                            nomor
                        )}

                    </td>


                    <td>

                        ${formatRupiahLaporan(
                            item.total
                        )}

                    </td>


                    <td>

                        ${formatRupiahLaporan(
                            item.labaKotor
                        )}

                    </td>

                </tr>

            `;

        }
    );


    html += `

                </tbody>

            </table>

        </div>

        <div class="petunjuk-laporan">
            👆 Ketuk transaksi untuk melihat detail
        </div>

    `;


    tempat.innerHTML =
        html;

}


/* =====================================================
   DETAIL PEMBELIAN
   ===================================================== */

function tampilkanDetailPembelian(data) {

    const tempat =
        document.getElementById(
            "detailPembelian"
        );


    if (!tempat) {
        return;
    }


    if (data.length === 0) {

        tempat.innerHTML =
            '<div class="data-kosong">Belum ada pembelian pada periode ini.</div>';

        return;

    }


    let html = `

        <div class="tabel-scroll">

            <table class="tabel-laporan">

                <thead>

                    <tr>

                        <th>Tanggal</th>

                        <th>No. Faktur</th>

                        <th>Distributor</th>

                        <th>Total</th>

                    </tr>

                </thead>

                <tbody>

    `;


    data.forEach(
        (item, index) => {

            const idFaktur =
                String(
                    item.id ??
                    ""
                );


            const nomor =
                item.nomor ||
                `FAKTUR-${String(
                    index + 1
                ).padStart(4, "0")}`;


            html += `

                <tr
                    class="baris-bisa-diklik"
                    onclick="bukaDetailPembelianLaporan('${escapeHtmlLaporan(idFaktur)}')"
                    title="Ketuk untuk melihat detail faktur"
                >

                    <td>

                        ${formatTanggalLaporan(
                            item.tanggal
                        )}

                    </td>


                    <td>

                        ${escapeHtmlLaporan(
                            nomor
                        )}

                    </td>


                    <td>

                        ${escapeHtmlLaporan(
                            item.distributorNama ||
                            "-"
                        )}

                    </td>


                    <td>

                        ${formatRupiahLaporan(
                            item.total ||
                            item.subtotal
                        )}

                    </td>

                </tr>

            `;

        }
    );


    html += `

                </tbody>

            </table>

        </div>

        <div class="petunjuk-laporan">
            👆 Ketuk faktur untuk melihat detail
        </div>

    `;


    tempat.innerHTML =
        html;

}


/* =========================
   JALANKAN SAAT HALAMAN BUKA
   ========================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        tampilkanLaporan();

    }
);