// ======================================================
// DATA DISTRIBUTOR
// File: js/distributor.js
//
// Data disimpan di localStorage.
// Key yang digunakan:
// "dataDistributor"
// ======================================================


// ======================================================
// MENYIMPAN DISTRIBUTOR
// ======================================================

function simpanDistributor() {

    // Ambil nama distributor
    const nama =
        document.getElementById("namaDistributor")
        .value
        .trim();


    // Ambil kontak
    const kontak =
        document.getElementById("kontakDistributor")
        .value
        .trim();


    // Nama distributor wajib diisi
    if (!nama) {

        alert("Nama distributor wajib diisi.");

        return;
    }


    // Ambil data lama
    const dataLama =
        localStorage.getItem("dataDistributor");


    // Jika belum ada, buat array kosong
    let distributor =
        dataLama
        ? JSON.parse(dataLama)
        : [];


    // Cek apakah nama distributor sudah ada
    const sudahAda = distributor.some(function(item) {

        return item.nama.toLowerCase() === nama.toLowerCase();

    });


    if (sudahAda) {

        alert("Distributor tersebut sudah ada.");

        return;
    }


    // Buat data distributor baru
    distributor.push({

        id: Date.now(),

        nama: nama,

        kontak: kontak

    });


    // Simpan
    localStorage.setItem(
        "dataDistributor",
        JSON.stringify(distributor)
    );


    alert("Distributor berhasil disimpan.");


    // Kosongkan form
    document.getElementById("namaDistributor").value = "";
    document.getElementById("kontakDistributor").value = "";


    // Tampilkan ulang
    tampilkanDistributor();
}



// ======================================================
// MENAMPILKAN DISTRIBUTOR
// ======================================================

function tampilkanDistributor() {

    const container =
        document.getElementById("daftarDistributor");


    const data =
        localStorage.getItem("dataDistributor");


    // Belum ada distributor
    if (!data) {

        container.innerHTML = `
            <div class="distributor-kosong">
                🏢 Belum ada distributor.
            </div>
        `;

        return;
    }


    const distributor =
        JSON.parse(data);


    if (distributor.length === 0) {

        container.innerHTML = `
            <div class="distributor-kosong">
                🏢 Belum ada distributor.
            </div>
        `;

        return;
    }


    let html = `
        <div class="tabel-distributor">

            <table>

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Distributor</th>
                        <th>Kontak</th>
                    </tr>
                </thead>

                <tbody>
    `;


    distributor.forEach(function(item, index) {

        html += `
            <tr>

                <td>
                    ${index + 1}
                </td>

                <td>
                    <strong>${item.nama}</strong>
                </td>

                <td>
                    ${item.kontak || "-"}
                </td>

            </tr>
        `;

    });


    html += `
                </tbody>

            </table>

        </div>
    `;


    container.innerHTML = html;
}



// ======================================================
// JALANKAN SAAT HALAMAN DIBUKA
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanDistributor();

    }
);
