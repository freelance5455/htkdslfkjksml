BISNISAPP — UPDATE UI & UX

1. Tombol “Keluar” tersedia di semua halaman melalui professional.js.
2. Tombol Keluar menampilkan konfirmasi dan tidak menghapus data. Jika Android WebView menyediakan bridge Android.closeApp/App.exitApp/navigator.app.exitApp, bridge tersebut akan dipanggil. Tanpa bridge, fallback menutup sesi dan kembali ke halaman awal.
3. Back Android tidak lagi diambil alih oleh handler popstate. Navigasi internal tetap memakai location.replace agar history tidak menumpuk. Untuk benar-benar menutup aplikasi dari Back Android, wrapper Android perlu menangani Back/OnBackPressed.
4. Form Barang: Satuan default PCS dan menyediakan pilihan melalui datalist termasuk LUSIN. Pengguna tetap dapat mengetik satuan sendiri.
5. Minimum Stok default 1 dan tetap dapat diubah.
6. Panduan pemula diperluas menjadi 7 langkah praktis.
