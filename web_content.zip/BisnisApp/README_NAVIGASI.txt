BISNISAPP V2 - NAVIGASI MOBILE

Perbaikan navigasi:
1. Navigasi antar halaman internal memakai location.replace(), bukan history.push().
2. Link internal <a href="...html"> juga diubah menjadi replace oleh professional.js.
3. Tombol Kembali di DALAM halaman memakai appBack("halaman-induk.html").
4. appBack() TIDAK melakukan logout. Ia hanya membuka halaman induk yang benar.
5. Tombol Back Android tidak memakai history internal, sehingga tidak mundur melewati
   banyak form yang sebelumnya dibuka. Perilaku keluar aplikasi sepenuhnya tetap bergantung
   pada wrapper Android/native yang digunakan.
6. Data bisnis tidak dihapus saat navigasi.
7. Trial 1 hari dan modul lisensi tetap disertakan.
