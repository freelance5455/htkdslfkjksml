BISNISAPP V2 — FINAL TEST BUILD

Perbaikan:
- Navigasi internal menggunakan location.replace agar history tidak menumpuk.
- Tombol Kembali di halaman memakai appBack() dan rute induk.
- Tombol history.back() yang ditemukan pada halaman Retur, Detail Faktur, dan Pembayaran sudah diganti.
- app.js dan professional.js dimuat lebih awal agar notifikasi custom tersedia sebelum script halaman berjalan.
- Trial 1 hari dan sistem lisensi tetap dipertahankan.
- Data bisnis tidak dihapus saat logout.

Catatan:
Versi ini adalah build uji final untuk HTML/WebView. Untuk kontrol tombol Back Android yang benar-benar native dan keluar aplikasi, wrapper APK Android tetap perlu menangani OnBackPressed/BackDispatcher.
