$ErrorActionPreference = "Stop"

Write-Host "=== 极简热量记 APK 构建脚本 ===" -ForegroundColor Cyan

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

$sdk = $env:ANDROID_SDK_ROOT
if (-not $sdk) { $sdk = $env:ANDROID_HOME }
if (-not $sdk) {
    $candidate = Join-Path $env:LOCALAPPDATA "Android\Sdk"
    if (Test-Path $candidate) { $sdk = $candidate }
}

if (-not $sdk -or -not (Test-Path $sdk)) {
    throw "未找到 Android SDK。请先安装 Android Studio，并在 SDK Manager 中安装 Android SDK Platform 35。"
}

$escapedSdk = $sdk.Replace('\', '\\').Replace(':', '\:')
"sdk.dir=$escapedSdk" | Set-Content -Encoding ASCII (Join-Path $projectRoot "local.properties")
Write-Host "Android SDK: $sdk"

$gradleDir = Join-Path $projectRoot ".gradle-portable\gradle-8.9"
$gradleBat = Join-Path $gradleDir "bin\gradle.bat"

if (-not (Test-Path $gradleBat)) {
    $zip = Join-Path $projectRoot ".gradle-portable\gradle-8.9-bin.zip"
    New-Item -ItemType Directory -Force (Split-Path $zip) | Out-Null
    Write-Host "正在下载 Gradle 8.9..."
    Invoke-WebRequest "https://services.gradle.org/distributions/gradle-8.9-bin.zip" -OutFile $zip
    Expand-Archive -Path $zip -DestinationPath (Split-Path $gradleDir) -Force
}

Write-Host "开始构建 Debug APK..."
& $gradleBat --no-daemon :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Gradle 构建失败。" }

$apk = Join-Path $projectRoot "app\build\outputs\apk\debug\app-debug.apk"
if (-not (Test-Path $apk)) { throw "构建完成但未找到 APK。" }

$out = Join-Path $projectRoot "极简热量记-debug.apk"
Copy-Item $apk $out -Force
Write-Host ""
Write-Host "构建成功：$out" -ForegroundColor Green
Write-Host "把这个 APK 发送到安卓手机后即可安装。"
