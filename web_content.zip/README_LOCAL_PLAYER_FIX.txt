DhruvMovies Local Player Fix

This version fixes the Android WebView file picker used by PLAY LOCAL FILE.

How to use:
1. Build/install the APK.
2. Open a movie.
3. Tap PLAY LOCAL FILE.
4. Android's file picker should open.
5. Select a movie file you are authorized to use.
6. MP4 (H.264/AAC) is recommended for Android/WebView compatibility.

The movie stays on the device; it is not uploaded by this feature.
