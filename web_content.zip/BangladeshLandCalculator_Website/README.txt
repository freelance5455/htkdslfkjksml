Bangladesh Land Calculator website.
index.html is the website entry file.
ADSENSE_SETUP.txt explains where to put your real AdSense code.
