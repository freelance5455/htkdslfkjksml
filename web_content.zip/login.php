<?php
session_start(); require_once __DIR__ . '/includes.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$error = ''; $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = strtolower(trim($_POST['email'] ?? '')); $password = $_POST['password'] ?? '';
  if (!csrf_valid()) $error = 'Сессия формы устарела. Обновите страницу и попробуйте снова.';
  else {
    $found = null;
    foreach (users_read() as $u) if (strtolower($u['email']) === $email) { $found = $u; break; }
    if ($found && password_verify($password, $found['password'])) {
      session_regenerate_id(true); $_SESSION['user'] = ['name'=>$found['name'], 'email'=>$found['email']];
      header('Location: dashboard.php'); exit;
    } else $error = 'Неверный email или пароль.';
  }
}
$pageTitle = 'Вход'; include __DIR__ . '/header.php';
?>
<section class="auth-wrap"><div class="auth-aside"><div class="eyebrow">С РАДОСТЬЮ СНОВА</div><h1>С возвращением.</h1><p>Войди в аккаунт, чтобы открыть личный кабинет.</p><div class="aside-note">Твой профиль ждёт тебя.</div></div>
<div class="auth-card"><h2>Вход в аккаунт</h2><p class="muted">Введи свои данные</p>
<?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
<label>Email<input type="email" name="email" value="<?= h($email) ?>" required autocomplete="email" placeholder="you@example.com"></label>
<label>Пароль<input type="password" name="password" required autocomplete="current-password" placeholder="Твой пароль"></label>
<button class="btn primary full" type="submit">Войти <span>→</span></button></form>
<div class="auth-switch">Нет аккаунта? <a href="register.php">Зарегистрироваться</a></div></div></section>
<?php include __DIR__ . '/footer.php'; ?>