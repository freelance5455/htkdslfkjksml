<?php
require __DIR__.'/api/config.php';
if(isset($_SESSION['admin_id'])){header('Location: index.html');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=db()->prepare('SELECT * FROM admins WHERE login=? AND active=1 LIMIT 1');
 $s->execute([trim($_POST['login']??'')]); $a=$s->fetch();
 if($a && password_verify($_POST['password']??'', $a['password_hash'])){
   $_SESSION['admin_id']=$a['id']; $_SESSION['admin_login']=$a['login']; $_SESSION['role']=$a['role'];
   header('Location: index.html');exit;
 }
 $error='Неверный логин или пароль';
}
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Вход — CRIME RUSSIA</title><link rel="stylesheet" href="assets/style.css"></head><body class="login"><form method="post" class="loginbox"><h1>CRIME <span>RUSSIA</span></h1><?php if($error):?><p class="error"><?=htmlspecialchars($error)?></p><?php endif;?><input name="login" placeholder="Логин" required><input type="password" name="password" placeholder="Пароль" required><button>ВОЙТИ</button></form></body></html>