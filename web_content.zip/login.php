<?php
declare(strict_types=1);require_once __DIR__.'/app/auth.php';
if(auth_user()){header('Location: dashboard.php');exit;}
if(($_SERVER['REQUEST_METHOD']??'GET')==='GET' && (string)($_GET['direct']??'')!=='1'){$next=(string)($_GET['next']??'');$url='onboarding.php'.($next!==''?'?next='.rawurlencode($next):'');header('Location: '.$url);exit;}
$registerHref='onboarding-tour.php?flow=signup&next='.rawurlencode(isset($_GET['next'])?auth_redirect_target((string)$_GET['next']):'dashboard.php');
$error='';
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 if(!auth_csrf_valid()){$error='Your security token expired. Refresh the page and try again.';}
 else try{
 $email=(string)($_POST['email']??'');$password=(string)($_POST['password']??'');if(!auth_login($email,$password))throw new InvalidArgumentException('Email or password is incorrect.');$next=auth_redirect_target((string)($_POST['next']??$_GET['next']??'dashboard.php'));header('Location: '.$next);exit;}
 catch(InvalidArgumentException $e){$error=$e->getMessage();}catch(Throwable $e){$error='Unable to complete this request. Check the database configuration and try again.';}
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#090b08"><title>Welcome back · ANONYMOUX STUDIO</title><link rel="icon" type="image/png" sizes="32x32" href="assets/branding/favicon-32.png"><link rel="apple-touch-icon" href="assets/branding/anonymoux-icon-192.png"><link rel="stylesheet" href="assets/auth.css?v=1.5.0"><link rel="stylesheet" href="assets/glass-notifications.css?v=2.5.8"></head><body><div class="auth-wrap"><section class="auth-visual login-visual">
<a class="auth-brand" href="login.php"><img src="assets/branding/anonymoux-studio-logo.png" alt="ANONYMOUX STUDIO"></a>
<div class="auth-hero">
<span class="auth-kicker">ANONYMOUX STUDIO</span>
<h1>Make ideas<br>look <em>real.</em></h1>
<p>Transform images, reshape video, and create in real time — all from one secure creative studio.</p>
<div class="login-workspace-grid" aria-label="Explore the three creative workspaces">
<article class="login-workspace-card">
<img src="assets/login-workspaces/image-edit.webp" alt="AI image editing portrait preview" loading="eager">
<div class="login-workspace-overlay"><span class="workspace-number">01 / IMAGE</span><strong>Image Edit</strong><small>Refine and transform still images.</small></div>
</article>
<article class="login-workspace-card">
<img src="assets/login-workspaces/video-edit.webp" alt="AI video editing portrait preview" loading="lazy">
<div class="login-workspace-overlay"><span class="workspace-number">02 / VIDEO</span><strong>Video Edit</strong><small>Restyle and transform video footage.</small></div>
</article>
<article class="login-workspace-card">
<img src="assets/login-workspaces/realtime-edit.webp" alt="Realtime AI video transformation portrait preview" loading="lazy">
<div class="login-workspace-overlay"><span class="workspace-number">03 / LIVE</span><strong>Realtime Video Edit</strong><small>Transform live video as it happens.</small></div>
</article>
</div>
</div>
<div class="auth-foot">SECURE CREATIVE WORKSPACE · ANONYMOUX STUDIO</div>
</section><section class="auth-panel-wrap"><div class="auth-panel" id="sign-in-panel"><h2>Welcome back</h2><p class="auth-sub">Sign in to continue to your creative workspace.</p><?php if($error!==''): ?><div class="auth-alert" role="alert"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?><form method="post" action="login.php?direct=1" autocomplete="on"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><?php if(isset($_GET['next'])): ?><input type="hidden" name="next" value="<?=htmlspecialchars((string)$_GET['next'],ENT_QUOTES,'UTF-8')?>"><?php endif; ?><label class="auth-field"><span>EMAIL ADDRESS</span><input type="email" name="email" autocomplete="email" maxlength="190" required></label><label class="auth-field"><span>PASSWORD</span><input type="password" name="password" autocomplete="current-password" minlength="1" maxlength="200" required></label><button class="auth-submit" type="submit">Sign in to workspace <span aria-hidden="true">→</span></button></form><p class="auth-switch">New to the studio? <a href="<?=htmlspecialchars($registerHref,ENT_QUOTES,'UTF-8')?>">Create an account</a></p><p class="auth-legal">By continuing, you agree to use only media you own or have permission to process. Payment, subscriptions, and provider usage are shown only when a verified integration is configured.</p></div></section></div></body></html>