1) Install Android Studio. 2) File > Open > select this folder (CustomerPanelApp). 3) Wait for Gradle sync.
4) Build > Build Bundle(s)/APK(s) > Build APK(s).  APK: app/build/outputs/apk/debug/app-debug.apk
5) Copy the APK to the phone and install it (allow "install unknown apps").
The web app is app/src/main/assets/index.html
