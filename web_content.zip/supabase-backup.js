"use strict";
(function(){
 const cfg=window.MUEEN_SUPABASE_CONFIG||{}; let client=null;
 function ready(){return !!(cfg.url&&cfg.anonKey&&window.supabase?.createClient);}
 function sb(){if(!ready()) return null; if(!client) client=window.supabase.createClient(cfg.url,cfg.anonKey); return client;}
 async function session(){const c=sb(); if(!c) throw new Error("SUPABASE_NOT_CONFIGURED"); const s=await c.auth.getSession(); if(s?.data?.session) return s.data.session; const r=await c.auth.signInAnonymously(); if(r.error) throw r.error; return r.data.session;}
 function collect(){const ls={}; for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i); if(k) ls[k]=localStorage.getItem(k);} return {version:1,app:"MUEEN",createdAt:new Date().toISOString(),localStorage:ls};}
 async function backup(){if(!navigator.onLine) throw new Error("OFFLINE"); const c=sb(); const s=await session(); const r=await c.from("mueen_backups").upsert({user_id:s.user.id,payload:collect(),updated_at:new Date().toISOString()},{onConflict:"user_id"}); if(r.error) throw r.error; localStorage.setItem("mueen_supabase_last_backup",new Date().toISOString());}
 async function restore(){if(!navigator.onLine) throw new Error("OFFLINE"); const c=sb(); const s=await session(); const r=await c.from("mueen_backups").select("payload").eq("user_id",s.user.id).maybeSingle(); if(r.error) throw r.error; if(!r.data?.payload?.localStorage) throw new Error("NO_BACKUP"); Object.entries(r.data.payload.localStorage).forEach(([k,v])=>localStorage.setItem(k,v));}
 window.MueenSupabaseBackup={ready,backup,restore,collect};
})();
