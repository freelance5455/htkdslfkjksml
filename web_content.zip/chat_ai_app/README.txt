CHAT AI — starter app

This is the first working version of the app UI. It is intentionally not connected to an AI API yet.
Open index.html in a browser. On Android Chrome, a hosted version can be installed as an app from the browser menu.
Next step: connect a real AI backend/API securely (API key must not be placed directly in the client app).
