package com.baatchit.chat;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int NATIVE_GALLERY_REQUEST = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;
    private boolean nativeGalleryPending = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        configureWebView();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.setWebViewClient(new WebViewClient());

        // Native bridge: BaatChit ke Gallery buttons direct Android picker khol sakte hain.
        webView.addJavascriptInterface(new GalleryBridge(), "BaatChitGallery");

        // Fallback/standard WebView <input type="file"> support.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                cancelPendingFileChooser();
                pendingFileCallback = filePathCallback;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                }

                if (fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    Intent fallback = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    fallback.addCategory(Intent.CATEGORY_OPENABLE);
                    fallback.setType("image/*");
                    fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                            fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    try {
                        startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                    } catch (Exception ex) {
                        cancelPendingFileChooser();
                        Toast.makeText(MainActivity.this,
                                "Gallery/File Picker available nahi hai", Toast.LENGTH_LONG).show();
                    }
                }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    /** Direct native Gallery/Photo Picker. No storage permission is required. */
    private void openNativeGallery() {
        if (nativeGalleryPending) return;
        nativeGalleryPending = true;

        Intent intent;
        if (Build.VERSION.SDK_INT >= 33) {
            intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("image/*");
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
        }

        try {
            startActivityForResult(intent, NATIVE_GALLERY_REQUEST);
        } catch (ActivityNotFoundException e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType("image/*");
                startActivityForResult(fallback, NATIVE_GALLERY_REQUEST);
            } catch (Exception ex) {
                nativeGalleryPending = false;
                sendGalleryResult(null);
                Toast.makeText(this, "Gallery open nahi ho paayi", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String uriToDataUrl(Uri uri) {
        if (uri == null) return null;
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            Bitmap original = BitmapFactory.decodeStream(input);
            if (original == null) return null;

            int max = 1600;
            float scale = Math.min(1f, max / (float) Math.max(original.getWidth(), original.getHeight()));
            int w = Math.max(1, Math.round(original.getWidth() * scale));
            int h = Math.max(1, Math.round(original.getHeight() * scale));
            Bitmap bitmap = original;
            if (w != original.getWidth() || h != original.getHeight()) {
                bitmap = Bitmap.createScaledBitmap(original, w, h, true);
            }

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out);
            byte[] bytes = out.toByteArray();

            if (bitmap != original) bitmap.recycle();
            original.recycle();

            return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private void sendGalleryResult(String dataUrl) {
        final String value = dataUrl == null ? "null" : "\"" + escapeJs(dataUrl) + "\"";
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.__nativeGalleryResult(" + value + ");", null));
    }

    private String escapeJs(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\u2028", "\\u2028")
                .replace("\u2029", "\\u2029");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == NATIVE_GALLERY_REQUEST) {
            nativeGalleryPending = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                sendGalleryResult(uriToDataUrl(data.getData()));
            } else {
                sendGalleryResult(null);
            }
            return;
        }

        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        }
        pendingFileCallback.onReceiveValue(results);
        pendingFileCallback = null;
    }

    private void cancelPendingFileChooser() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
    }

    private class GalleryBridge {
        @JavascriptInterface
        public void openGallery() {
            runOnUiThread(() -> openNativeGallery());
        }
    }

    @Override
    protected void onDestroy() {
        cancelPendingFileChooser();
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.removeJavascriptInterface("BaatChitGallery");
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
