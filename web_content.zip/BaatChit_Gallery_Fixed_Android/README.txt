BaatChit - Gallery Fixed Android Project

Package: com.baatchit.chat
Version: 1.0.0 (versionCode 1)
Compile SDK: 35
Target SDK: 35
Minimum SDK: 24

Gallery/profile-photo fix:
- WebChromeClient.onShowFileChooser implemented.
- Android system picker used for <input type="file">.
- Multiple image selection supported when requested.
- Uri[] result returned to WebView callback.
- Existing BaatChit HTML/design is included unchanged.

Open this folder in Android Studio and build the APK.
