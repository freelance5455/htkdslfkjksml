BABA MusicPlayer starter project
================================

This is a mobile-friendly music-player web app packaged as a starter project.

Run/test:
- Open www/index.html in a modern browser.
- On Android, use a browser or wrap this project with Capacitor to build an Android app.
- Upload local MP3/WAV/M4A/OGG audio files with the Upload tab. Local audio plays in the built-in player.
- Search, favorites, playlist creation, queue display, artist follow demo, shuffle/repeat, volume, and playback seek controls are included.

Important limitations:
- The included sample tracks are demo listings, not actual music recordings.
- Imported audio is local to the current browser session and is not uploaded to cloud storage.
- Accounts, online music streaming, cross-device sync, downloads/offline library persistence, and publishing an installable APK require backend services and/or Android build tooling.
- Only upload audio you own or have permission to use.
