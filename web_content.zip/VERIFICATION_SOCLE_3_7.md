# Vérification — Socle 3.7

- 221 tests automatisés réussis sur 221 (`npm test`).
- Syntaxe JavaScript vérifiée pour tous les fichiers `src/` et `tests/` avec `node --check`.
- 31 modules JavaScript hors interface (`app.js`) comparés octet par octet à la Socle 3.6 : aucun changement. Cela comprend les moteurs de dames, arènes, simulation, calendrier, divisions, compétitions, statistiques individuelles, contrats des damistes, transferts, relations, horloge et scène 3D.
- Les modifications de ce socle sont limitées à l'interface `app.js`, au nouveau module `manager-consequences.js`, aux tests et à la documentation.
- Archive ZIP contrôlée après génération.
- Test visuel réel sur téléphone / navigateur mobile non effectué dans cet environnement.
