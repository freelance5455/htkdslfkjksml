FARM MANAGER 12.0 — Android WebView project

Что уже подготовлено:
- исходная игра сохранена как app/src/main/assets/index.html (UTF-8)
- Android-приложение открывает игру во встроенном WebView
- включены JavaScript и DOM Storage (localStorage для сохранений)
- добавлено разрешение на интернет для карты, тайлов и запросов OSM
- минимальная версия Android: 6.0 (API 23)

Важно:
Это ИСХОДНИКИ Android-проекта, не готовый APK.
Для APK нужна сборка Android Gradle Plugin 8.7.3 / Gradle 8.9+ и Android SDK 35.
Игра использует внешние интернет-ресурсы: Leaflet CDN, картографические тайлы и Overpass API.
Без интернета карта и загрузка объектов работать не будут; локальные игровые сохранения
хранятся в localStorage WebView.

Открыть папку проекта в Android Studio/AndroidIDE и выполнить сборку APK.
