plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.farmmanager.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.farmmanager.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 12
        versionName = "12.0"
    }
}
