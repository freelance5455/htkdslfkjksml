# JIN — Made by Azan

A responsive, offline-first personal tracker prototype with:
- Habit creation, daily completion and a 7-day overview
- Workout, weight and meal/calorie logs
- Income, expenses, budgets and savings goals (PKR)
- Manual trading journal with recorded P/L and win percentage
- Daily reflections and an offline MOJIN reflection helper
- Local data persistence, JSON backup export/import, delete controls
- PWA manifest and service worker for installable/offline use when served over HTTPS or localhost

## Run locally

Open `index.html` in a modern browser for the basic app. For install/offline PWA behavior, serve this folder from localhost or HTTPS (service workers do not work from ordinary `file://` URLs). Example if Python is installed:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` on the same device. On Android, host the folder on a static HTTPS host, open the link in Chrome, then choose **Install app** / **Add to Home screen**.

## About the APK

This delivery is the complete PWA source, not a compiled APK. To create an APK, wrap the web app with a tool such as Capacitor and build with Android Studio / Android SDK. An Android build environment is required; this archive alone is not an APK. No paid API is required for the current offline features. MOJIN currently provides offline reflection prompts, not live AI. A live AI feature requires a securely configured backend/API.

## Storage and privacy

App records are stored in this browser's localStorage. Clearing browser/app data can erase records, so use Profile → Export backup. Records do not sync between devices or connect to bank/trading accounts.
