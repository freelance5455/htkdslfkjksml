# Fun Race 3D — Sketchware Pro Ready

The original upload was an Android Studio Gradle project, so Sketchware cannot restore it directly as a project backup. Sketchware Pro backups use `.swb`. This folder contains the converted source pieces for a Sketchware Pro project.

## What was fixed
- Java-only Activity; no Kotlin DSL or AndroidX/AppCompat requirement in the Activity source.
- WebView loads `file:///android_asset/index.html`.
- Removed the broken absolute `/assets/0.2-9fd556a0/js/bannerads.js` reference from the supplied HTML.
- Added safe JavaScript bridge helpers for Unity interstitial/rewarded calls.
- Unity Game ID: 800275589.
- Placements: Banner_Android, Interstitial_Android, Rewarded_Android.
- Reward is sent to the page only from Unity's rewarded callback.

## Sketchware Pro setup
1. Create a new project in Sketchware Pro with package `com.funrace3d.unityads`.
2. Add a WebView named `gameWebView` and a bottom FrameLayout named `bannerContainer`, or replace the generated `main.xml` with `XML/main.xml`.
3. Copy `assets/index.html` into the project's Asset Manager.
4. Replace/import `Java/MainActivity.java` using Sketchware Pro's Java/Kotlin Manager / source editor.
5. Add INTERNET and AD_ID permissions.
6. Add the Unity Ads dependency shown in `Dependencies/unity_ads.txt` using Sketchware Pro's supported library/dependency manager.
7. Build with Unity test mode enabled.

### Important
A Sketchware `.swb` backup is not the same thing as an Android Studio ZIP. The files in this package are intentionally separated so they can be placed into a Sketchware project without Kotlin/Gradle-KTS files that Sketchware cannot use.
