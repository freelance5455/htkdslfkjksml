from pathlib import Path
import re,json,sys
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text()
for f in ('curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js'):
    assert f'<script src="{f}"></script>' in html,f
    html=html.replace(f'<script src="{f}"></script>','<script>\n'+(root/f).read_text()+'\n</script>')
for f in ('university-v8.css','inquiry-v9.css','kingdom-v10.css','career-v11.css','life-v12.css','academy-v13.css'):
    html=html.replace(f'<link rel="stylesheet" href="{f}">','<style>'+ (root/f).read_text()+'</style>')
html=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>','',html)

def init_page(browser,db=None):
    pg=browser.new_page(viewport={'width':390,'height':844},accept_downloads=True)
    pg.set_default_timeout(3500)
    errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
    data=db if db else {'loonieAcademy_v1':json.dumps({'onboarded':True,'done':{'79':'5/5'},'stars':{'79':3},'checks':{},'notes':{'79':'Old note from v7'},'sound':False})}
    pg.evaluate('''db=>{window.__db=db;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]??null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>{Object.keys(window.__db).forEach(k=>delete window.__db[k]);}}});}''',data)
    pg.set_content(html,wait_until='load',timeout=90000);pg.wait_for_timeout(100)
    assert not errors,errors[:3]
    return pg,errors

def route(pg,h):
    pg.evaluate('''()=>{for(const b of document.querySelectorAll('.overlay #mclose'))b.click();document.querySelectorAll('.overlay').forEach(x=>x.remove());}''')
    pg.evaluate('h=>location.hash="#"+h',h);pg.wait_for_timeout(60);pg.evaluate('route()')
    assert 'Something went wrong' not in pg.locator('#screen').inner_text(),pg.locator('#screen').inner_text()[:1500]

def test_lab(pg,id='market'):
    route(pg,'lab9-'+id)
    assert pg.locator('#iq-run').count()==1
    pg.locator('#iq-run').click()
    assert pg.evaluate(f'LOONIE_V9.lab("{id}").runs.length')==1
    pg.locator('[data-predict="up"]').click()
    pg.locator('[data-var]').first.fill(str(pg.evaluate(f'LOONIE_V9.lab("{id}").inputs.{LOONIE_V9_NULL}' ) if False else 20)) if False else None
    # change exactly one variable, using the range slider to guarantee valid
    pg.evaluate('''id=>{const d=LOONIE_V9.lab(id),v=LOONIE_V9.labs.find(x=>x.id===id).vars[0];const input=document.querySelector(`[data-range="${v.id}"]`);input.value=Math.min(v.max,d.inputs[v.id]+v.step);input.dispatchEvent(new Event('input',{bubbles:true}));}''',id)
    pg.locator('#iq-run').click()
    assert pg.evaluate(f'!!LOONIE_V9.lab("{id}").pair')
    pg.locator('#iq-conclusion').fill('I changed the first input and kept every other measured variable unchanged. The recorded result and the baseline show a difference in the output. I compared these numbers against my prediction and considered the model assumptions.')
    pg.evaluate('''id=>{const d=LOONIE_V9.lab(id),def=LOONIE_V9.labs.find(x=>x.id===id);for(let i=0;i<3;i++)document.querySelector(`[data-q="${i}"][data-a="${def.qs[i][2]}"]`).click();}''',id)
    pg.locator('#iq-submit').click()
    assert pg.evaluate(f'LOONIE_V9.lab("{id}").best')==100,id
    assert 'Lab complete' in pg.locator('#iq-feedback').inner_text()
    print('Lab complete',id,flush=True)

def test_case(pg,id='bank'):
    route(pg,'case9-'+id)
    pg.locator('[data-evidence]').all()[0].click()
    for x in pg.locator('[data-evidence]').all()[1:4]:x.click()
    pg.evaluate('''id=>{const d=LOONIE_V9.caseRecord(id),c=LOONIE_V9.cases.find(x=>x.id===id);for(let i=0;i<4;i++)document.querySelector(`[data-case-q="${i}"][data-case-a="${c.qs[i][2]}"]`).click();}''',id)
    pg.locator('#case9-writing').fill('The provided documents show different pieces of a transaction. I calculated the quantities using the stated rates and dates. I compared conflicting sources, and my recommendation is to check original documents before finalizing any finding or blaming anyone.')
    pg.locator('#case9-submit').click()
    assert pg.evaluate(f'LOONIE_V9.caseRecord("{id}").best')==100,id
    print('Case solved',id,flush=True)

def test_teach(pg,mode='guided',id=1):
    route(pg,'teach9-'+str(id));pg.locator(f'[data-mode="{mode}"]').click()
    if mode=='guided':
      for step in range(4):
        pg.evaluate('''step=>{const q=LOONIE_V9.labs[0];const d=LOONIE_V9.teachRecord(1).modes.guided;
        if(step===0)document.querySelector('[data-teach-choice="predict"][data-choice="0"]').click();
        if(step===1){document.querySelector('[data-teach-choice="correct"][data-choice="0"]').click();let x=document.querySelector('[data-teach-text="correction"]');x.value='This answer is correct according to the lesson explanation. The question requires checking the underlying principle rather than guessing a plausible distractor.';x.dispatchEvent(new Event('input',{bubbles:true}));}
        if(step===2){let x=document.querySelector('[data-teach-text="explanation"]');x.value='I would explain the whole topic using the specific concepts in the lesson and connect the steps to an actual practical example with numbers and a realistic limitation.';x.dispatchEvent(new Event('input',{bubbles:true}));}
        if(step===3){document.querySelector('[data-teach-choice="transfer"][data-choice="0"]').click();let x=document.querySelector('[data-teach-text="reflection"]');x.value='I should compare my answers with the actual lesson explanations again tomorrow.';x.dispatchEvent(new Event('input',{bubbles:true}));}
       }''',step)
        pg.locator('#iq-teach-next').click()
    elif mode=='mistakes':
      for i in range(4):
        pg.evaluate('''i=>{const q=LESSONS.find(l=>l.id===1).quiz[i];document.querySelector(`[data-teach-choice="m${i}"][data-choice="${q.a}"]`).click();const x=document.querySelector(`[data-teach-text="m${i}"]`);x.value='The correct choice follows the given lesson explanation and contradicts the incorrect statement made by Lou.';x.dispatchEvent(new Event('input',{bubbles:true}));}''',i)
        pg.locator('#iq-teach-next').click()
    else:
      for i in range(3):
        pg.locator(f'[data-teach-text="r{i}"]').fill('I think this relates to a specific principle discussed in the original lesson because I have recalled the useful steps and examples.')
        pg.locator('#iq-reveal').click()
        pg.locator('[data-self="2"]').click()
        pg.locator('#iq-teach-next').click()
    assert pg.evaluate('LOONIE_V9.teachRecord(1).modes.'+mode+'.complete'),mode
    print('Teach Lou done',mode,flush=True)

with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  pg,errors=init_page(browser)
  val=pg.evaluate('LOONIE_V9.validate()'); print('Validate:',val,flush=True)
  assert val['ok'] and val['university']['ok']
  assert (val['lessons'],val['questions'])==(807,3714)
  for h,needle in [('learn','Study hub'),('inquiry','Interactive Inquiry Studio'),('experiment-lab','Experimental Labs'),('investigations','Evidence Investigations'),('coach','Teach Lou Plus'),('notebook','Research Notebook'),('lab','Experimental Lab Studio'),('practice','Investigations Plus'),('uni','Personal University'),('uni-term-0','Semester')]:
    route(pg,h);assert needle.lower() in pg.locator('#screen').inner_text().lower(),(h,pg.locator('#screen').inner_text()[:150]);print('Route',h,'OK',flush=True)
  # exercise one fail and success; test one variable validity
  route(pg,'lab9-market');pg.locator('#iq-run').click();pg.locator('[data-predict="up"]').click()
  pg.evaluate('''()=>{for(const el of document.querySelectorAll('[data-range]')){el.value=Number(el.value)+Number(el.step);el.dispatchEvent(new Event('input'));}}''')
  pg.locator('#iq-run').click();assert not pg.evaluate('LOONIE_V9.lab("market").pair'),'multi-variable change wrongly accepted'
  pg.on('dialog',lambda d:d.accept());pg.locator('#iq-clear').click()
  for d in ['market','circuits','fall','savings','ecology','survey','inventory','takeoff','search']:test_lab(pg,d)
  for c in ['bank','saw','surveycase','build','phish','energy']:test_case(pg,c)
  for m in ['guided','mistakes','recall']:test_teach(pg,m)
  route(pg,'notebook');assert pg.locator('#iq-json').count() and pg.locator('#iq-csv').count()
  with pg.expect_download() as info:pg.locator('#iq-json').click()
  assert info.value.suggested_filename.endswith('.json')
  with pg.expect_download() as info:pg.locator('#iq-csv').click()
  assert info.value.suggested_filename.endswith('.csv')
  assert pg.evaluate('state.notes[79]')=='Old note from v7'
  assert pg.evaluate('Object.keys(state.inquiryV9.labs).length')==9
  assert pg.evaluate('LOONIE_V8.validate().ok')
  # existing full backup includes new module and restores without losing it
  backing=pg.evaluate('window.__db')
  assert 'inquiryV9' in json.loads(backing['loonieAcademy_v1'])
  page2,errors2=init_page(browser,backing)
  route(page2,'notebook');assert '9' in page2.locator('.inquiry-summary').inner_text()
  assert page2.evaluate('LOONIE_V9.lab("market").best')==100
  assert page2.evaluate('LOONIE_V8.validate().ok')
  assert not errors and not errors2,(errors[:8],errors2[:8])
  pg.screenshot(path=str(root/'qa-inquiry-phone.png'),full_page=True)
  page2.screenshot(path=str(root/'qa-notebook-phone.png'),full_page=True)
  print('PHASE 3 QA ALL PASS',flush=True)
  browser.close()
