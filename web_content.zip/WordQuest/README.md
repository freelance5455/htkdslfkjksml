# WordQuest — مغامرة إتقان المفردات الإنجليزية

لعبة لتعلّم المفردات الإنجليزية للناطقين بالعربية: جملة فيها فراغ + المعنى العربي، واللاعب يكتب الكلمة الناقصة.
مستويات CEFR من A1 إلى C2. تعمل بالكامل دون إنترنت ودون خادم (HTML/CSS/JavaScript بلا مكتبات).

## الحالة الحالية (بصراحة)
| المستوى | الكلمات |
|---|---|
| A1 / A2 / B1 / B2 / C1 | 100 لكل مستوى |
| C2 | 44 (المطلوب 100) |

المجموع 544 من 600. لم يُبنِ APK في هذه الحزمة — الحزمة **جاهزة للبناء** فقط (الخطوات أدناه).

## هيكل المشروع
```
WordQuest/
├── www/                      ← تطبيق الويب (هذا المجلد هو ما يُحزَم داخل APK)
│   ├── index.html
│   ├── manifest.json         ← PWA manifest
│   ├── service-worker.js     ← دعم العمل دون اتصال (عند التشغيل عبر http/https)
│   ├── css/style.css
│   ├── js/app.js             ← الواجهة + منطق اللعبة + التخزين المحلي
│   ├── data/a1.js … c2.js    ← قاعدة المفردات (ملف لكل مستوى)
│   └── assets/icons/         ← أيقونات 192 و512 (بديلة مؤقتة)
├── resources/icon.png        ← أيقونة 1024 (بديلة) لاستخدامها مع @capacitor/assets
├── capacitor.config.json     ← appId = com.wordquest.app ، webDir = www
├── package.json
└── tools/
    ├── validate.js           ← فحص قاعدة البيانات
    └── smoke.js              ← اختبار آلي للمحرك بدون متصفح
```

## التشغيل محليًا
- افتح `www/index.html` مباشرة في المتصفح (البيانات ملفات JS فلا حاجة إلى خادم)، أو:
  `cd www && python3 -m http.server 8000` ثم افتح http://localhost:8000
- الفحص: `node tools/validate.js` و`node tools/smoke.js` (يتطلب Node.js).

## إضافة مفردات
افتح الملف المناسب في `www/data/` وأضف صفًا في نهاية المصفوفة (لا تغيّر المحرك):
```
["word","المعنى","noun","Topic","Sentence with ___ blank.","ترجمة الجملة","Another example.","ترجمة المثال","contextual hint"]
```
- معرّف كل كلمة يُولَّد تلقائيًا من ترتيبها (`a1_001`…) — **أضف الكلمات الجديدة في آخر الملف فقط** حتى لا تتغير معرّفات الكلمات المحفوظة في تقدّم اللاعبين.
- الإجابات متعددة الكلمات (مثل `pick up`) مدعومة. لا تستخدم كلمات لها تهجئتان (colour/color) لأن اللعبة لا تقبل إجابات بديلة.
- شغّل `node tools/validate.js` بعد أي إضافة.

## بناء APK باستخدام Capacitor
المتطلبات: Node.js (إصدار LTS حديث)، JDK، وAndroid Studio مع Android SDK.

```bash
cd WordQuest
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/app
npx cap add android
npx cap sync android
```
ثم إمّا:
- **Android Studio:** `npx cap open android` ← Build ▸ Build APK(s) (للتجربة) أو Generate Signed Bundle / APK (للنشر).
- **سطر الأوامر:** `cd android && ./gradlew assembleDebug`
  ← الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

للنشر على Google Play تحتاج مفتاح توقيع (keystore) خاصًا بك وAAB موقَّعًا. بعد أي تعديل في `www/` نفّذ `npx cap sync android` ثم أعد البناء.

### أيقونة التطبيق
الأيقونات الحالية بديلة بسيطة. لتوليد أيقونات أندرويد كاملة من صورتك الخاصة: ضع `icon.png` (1024×1024) في `resources/` ثم
`npm install -D @capacitor/assets && npx capacitor-assets generate --android`.

### ما الذي يُنسخ وما الذي يُولَّد
- **تنسخه إلى المشروع النهائي:** `www/`، `capacitor.config.json`، `package.json`، `resources/` (والمجلد `tools/` اختياري).
- **يُولَّد تلقائيًا (لا تنسخه):** `node_modules/`، `package-lock.json`، `android/` وكل ما بداخله، ومجلدات `build/` و`.gradle/`.

## أذونات أندرويد
اللعبة لا تحتاج أي إذن. قالب Capacitor الافتراضي يضيف `INTERNET` في `android/app/src/main/AndroidManifest.xml`؛ يمكنك حذف هذا السطر إن أردت — اللعبة لا تتصل بالإنترنت.

## الخروج من التطبيق
زر «خروج» يستدعي `App.exitApp()` من إضافة `@capacitor/app` داخل APK. في المتصفح يعرض شاشة «إلى اللقاء» لأن المتصفحات لا تسمح بإغلاق التبويب برمجيًا.

## القيود المعروفة
- C2 فيه 44 كلمة فقط (يحتاج 56 إضافية).
- لم تُراجَع الترجمات العربية مراجعة لغوية بشرية؛ يُنصح بمراجعتها قبل الاستخدام التعليمي.
- بعض الجمل قد تقبل أكثر من إجابة في السياق؛ المعنى العربي والتلميح يحددان الكلمة المطلوبة.
- تصدير/استيراد التقدّم عبر نص يُنسخ ويُلصق (لا تنزيل ملف).
- الأصوات صفارات بسيطة مولَّدة (متوقفة افتراضيًا).
- لم يُجرَّب على جهاز أندرويد فعلي ولم يُبنَ APK هنا.
