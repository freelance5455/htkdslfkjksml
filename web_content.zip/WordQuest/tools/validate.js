// Usage: node tools/validate.js  — checks every data/*.js file
const fs=require('fs'),vm=require('vm'),path=require('path');
const dir=path.join(__dirname,'..','www','data');
const ctx={window:{}};ctx.window=ctx;vm.createContext(ctx);
fs.readdirSync(dir).filter(f=>f.endsWith('.js')).sort().forEach(f=>vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx));
const errs=[],ids=new Set();let total=0;
for(const [lv,rows] of Object.entries(ctx.WQ_DATA)){const words=new Set();
 rows.forEach((r,i)=>{const id=lv.toLowerCase()+'_'+String(i+1).padStart(3,'0');total++;
  if(r.length!==9)errs.push(id+': expected 9 fields, got '+r.length);
  r.forEach((v,k)=>{if(typeof v!=='string'||!v.trim())errs.push(id+': empty field #'+k)});
  if(!/___/.test(r[4]||''))errs.push(id+': sentence has no blank');
  if(new RegExp('\\b'+(r[0]||'').replace(/ /g,'\\s+')+'\\b','i').test(r[4]||''))errs.push(id+': sentence reveals the answer');
  if(ids.has(id))errs.push('duplicate id '+id);ids.add(id);
  const w=(r[0]||'').toLowerCase();if(words.has(w))errs.push(id+': duplicate word "'+w+'" in '+lv);words.add(w)});
 console.log(lv,rows.length,rows.length>=100?'OK':'< 100');}
console.log('TOTAL',total,errs.length?'\nERRORS:\n'+errs.join('\n'):'\nno data errors');
process.exit(errs.length?1:0);
