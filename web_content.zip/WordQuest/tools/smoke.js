// Usage: node tools/smoke.js — runs the game engine headlessly with stubbed DOM and plays a session
const fs=require('fs'),vm=require('vm'),path=require('path');
const W=path.join(__dirname,'..','www'),els={},store={};
const el=s=>els[s]||(els[s]={value:'',textContent:'',innerHTML:'',focus(){},select(){}});
const ctx={document:{querySelector:el,documentElement:{dataset:{},removeAttribute(){}}},localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v}},navigator:{},location:{protocol:'file:'},console,alert(){},confirm:()=>true,addEventListener(){}};
ctx.window=ctx;vm.createContext(ctx);
const run=f=>vm.runInContext(fs.readFileSync(path.join(W,f),'utf8'),ctx,{filename:f});
fs.readdirSync(W+'/data').sort().forEach(f=>run('data/'+f));run('js/app.js');
const t=`
const out=[];const ok=(n,c)=>out.push((c?'PASS ':'FAIL ')+n);
for(const v of ['menu','home','settings','book','bye']){view=v;render();ok('render '+v,$('#app').innerHTML.length>100)}
len=5;start('C1');ok('session has 5 unique questions',G.qs.length==5&&new Set(G.qs.map(q=>q.id)).size==5);
$('#a').value='zzzz';check();ok('wrong answer keeps question',!G.fb&&G.tries==1);
$('#a').value=' '+G.qs[0].word.toUpperCase()+' ';check();ok('correct answer (case/space insensitive)',G.fb&&G.fb.ok&&G.fb.pts==5);
render();ok('feedback screen renders',$('#app').innerHTML.includes(G.qs[0].ar));
next();hint();$('#a').value=G.qs[1].word;check();ok('letter hint lowers points',G.fb.pts==8);
next();finish(false,0);ok('reveal gives 0 and logs mistake',G.fb.pts==0&&S.mis.includes(G.qs[2].id));
next();skip();$('#a').value=G.qs[4].word;check();next();
ok('session ends on result screen',view=='result');render();ok('result renders',$('#app').innerHTML.includes('انتهت'));
ok('progress saved to localStorage',JSON.parse(localStorage.getItem('wq')).sessions==1);
view='home';render();start('مراجعة',S.mis);ok('mistake review session starts',G&&G.qs.length>0);
out.join('\\n')`;
console.log(vm.runInContext(t,ctx));
