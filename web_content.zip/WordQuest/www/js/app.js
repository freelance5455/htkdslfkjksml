
/* ===== DATA (separate block: add rows here, or move to data/a1.json… later) =====
 row = [word, arabic, pos, topic, sentence(___), sentenceAr, example, exampleAr, hint] */
const RAW=window.WQ_DATA; /* loaded from data/*.js */
const LV=[['A1','مبتدئ','كلمات يومية: الأسرة والطعام والأماكن'],['A2','أساسي','السفر والتسوق والأفعال المركبة'],['B1','متوسط','العمل والدراسة والتعبير عن الرأي'],['B2','فوق المتوسط','مفاهيم مجردة وتعابير مهنية'],['C1','متقدم','مفردات أكاديمية وفروق دقيقة'],['C2','إتقان','كلمات نادرة ودقة في الاختيار']];
const V={},BY={};
LV.forEach(([l])=>{V[l]=RAW[l].map((r,i)=>{const e={id:l.toLowerCase()+'_'+String(i+1).padStart(3,'0'),level:l,word:r[0],ar:r[1],pos:r[2],topic:r[3],sent:r[4],tr:r[5],ex:r[6],exAr:r[7],hint:r[8],diff:LV.findIndex(x=>x[0]==l)+1};BY[e.id]=e;return e})});
function validate(){const seen={},errs=[];Object.values(BY).forEach(e=>{if(!/___/.test(e.sent))errs.push(e.id+': no blank');['word','ar','pos','topic','tr','ex','exAr','hint'].forEach(k=>{if(!e[k])errs.push(e.id+': empty '+k)});const k=e.level+e.word;if(seen[k])errs.push('dup '+k);seen[k]=1});return errs}
/* ===== STORAGE ===== */
const D={score:0,sessions:0,ok:0,bad:0,best:{},m:{},nb:[],mis:[],ach:[],last:null,len:10,snd:false,theme:'auto'};
let S;try{S=Object.assign({},D,JSON.parse(localStorage.getItem('wq')||'{}'))}catch(e){S=Object.assign({},D)}
const save=()=>{try{localStorage.setItem('wq',JSON.stringify(S))}catch(e){}};
/* ===== UTILS ===== */
const $=s=>document.querySelector(s);
const norm=s=>s.trim().toLowerCase().replace(/[.,!?;:"]/g,'').replace(/\s+/g,' ');
const shuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const lev=(a,b)=>{let d=[...Array(b.length+1).keys()];for(let i=1;i<=a.length;i++){let p=d[0];d[0]=i;for(let j=1;j<=b.length;j++){let t=d[j];d[j]=Math.min(d[j]+1,d[j-1]+1,p+(a[i-1]==b[j-1]?0:1));p=t}}return d[b.length]};
const ACH={first:'🏅 أول انتصار',perfect:'🌟 جلسة مثالية',explorer:'🧭 مستكشف المفردات (10 كلمات متعلَّمة)',master:'👑 سيد المستوى (إتقان كل كلمات مستوى)'};
function unlock(k){if(!S.ach.includes(k))S.ach.push(k)}
const learned=l=>V[l].filter(e=>S.m[e.id]>0).length, mastered=l=>V[l].filter(e=>S.m[e.id]>=3).length;
/* ===== GAME ===== */
let G=null,len=S.len,view='menu';
function start(level,ids){let pool=ids?ids.map(i=>BY[i]):V[level];pool=shuf(pool);if(!ids&&len>0)pool=pool.slice(0,len);if(!pool.length)return;G={level:level,qs:pool,i:0,score:0,tries:0,h:0,fb:null,ok:[],bad:[]};if(!ids)S.last=level;save();view='play';render()}
function check(){const v=norm($('#a').value),q=G.qs[G.i];if(!v)return;G.tries++;
 if(v===norm(q.word)){const pts=Math.max(1,(G.tries==1?10:5)-2*G.h);finish(true,pts)}
 else{const near=lev(v,norm(q.word))<=2&&v.length>2;$('#msg').innerHTML='<span class=no>'+(near?'قريب! لكن الإملاء غير صحيح — راجع الحروف.':'ليست الكلمة المطلوبة. فكّر في المعنى وحاول مرة أخرى 💪')+'</span>';$('#a').select();beep(2)}}
function finish(ok,pts){const q=G.qs[G.i];G.fb={ok,pts};
 if(ok){beep(1);G.score+=pts;S.score+=pts;S.ok++;if(G.tries==1&&!G.h)S.m[q.id]=(S.m[q.id]||0)+1;G.ok.push(q);S.mis=S.mis.filter(x=>x!=q.id);unlock('first')}
 else{G.bad.push(q);S.bad++;if(!S.mis.includes(q.id))S.mis.push(q.id)}
 save();render()}
function skip(){const q=G.qs[G.i];G.bad.push(q);S.bad++;if(!S.mis.includes(q.id))S.mis.push(q.id);save();next()}
function next(){G.fb=null;G.tries=0;G.h=0;G.i++;if(G.i>=G.qs.length){endSession();return}render()}
function endSession(){S.sessions++;S.score+=10;G.score+=10;if(!G.bad.length&&G.ok.length)unlock('perfect');if(Object.values(S.m).filter(n=>n>0).length>=10)unlock('explorer');LV.forEach(([l])=>{if(mastered(l)==V[l].length)unlock('master')});if((S.best[G.level]||0)<G.score)S.best[G.level]=G.score;save();view='result';render()}
function hint(){G.h=Math.min(G.h+1,G.qs[G.i].word.length-1);pat()}
function pat(){const w=G.qs[G.i].word,e=$('#pat');if(e)e.textContent=[...w].map((c,i)=>c==' '?'/':i<G.h?c:'_').join(' ')}
function toggleNB(id){S.nb=S.nb.includes(id)?S.nb.filter(x=>x!=id):S.nb.concat(id);save();render()}
/* ===== VIEWS ===== */
function render(){applyTheme();const a=$('#app');a.innerHTML=({menu,home,play,result,book,settings,bye})[view]();if(view=='play'&&!G.fb){$('#a').focus();pat()}}
function home(){const tot=Object.keys(BY).length,ln=Object.values(BY).filter(e=>S.m[e.id]>0).length,p=Math.round(100*ln/tot);
 return `<div class="row sp"><button onclick="view='menu';render()">➡ القائمة الرئيسية</button><b>اختر المستوى</b></div>
 <div class=card><div class="row sp"><b>التقدم العام</b><span>${ln}/${tot} كلمة · ⭐ ${S.score}</span></div><div class=bar><i style="width:${p}%"></i></div>
 <p class=mut style="margin:8px 0 4px">عدد الأسئلة في الجلسة:</p><div class=row>${chips()}</div></div>
 ${S.last?`<button class=p style="width:100%" onclick="start('${S.last}')">▶ متابعة آخر مستوى (${S.last})</button>`:''}
 <div class=grid style="margin-top:12px">${LV.map(([l,n,d])=>`<button class="card lv" onclick="start('${l}')"><b class=en>${l}</b> <span>— ${n}</span><div class=mut>${d}</div><div style="margin-top:6px">📚 ${V[l].length} كلمة · ✅ ${learned(l)} · 🏆 ${mastered(l)}</div></button>`).join('')}</div>
 <div class=row style="margin-top:8px"><button onclick="start('مراجعة',S.mis)" ${S.mis.length?'':'disabled'}>🔁 مراجعة الأخطاء (${S.mis.length})</button><button onclick="view='book';render()">📒 دفتر المفردات (${S.nb.length})</button><button onclick="info()">ℹ️ النقاط</button><button onclick="reset()">🗑 إعادة ضبط</button></div>
 ${S.ach.length?`<div class=card><b>الإنجازات</b><br>${S.ach.map(k=>ACH[k]).join('<br>')}</div>`:''}`}
function play(){const q=G.qs[G.i],p=Math.round(100*G.i/G.qs.length),s=q.sent.replace('___','<span class=blank>&nbsp;</span>');
 const top=`<div class="row sp"><button onclick="view='home';render()" aria-label="رجوع">➡ المستويات</button><b class=en>${G.level} · ${G.i+1}/${G.qs.length}</b><b>⭐ ${G.score}</b></div><div class=bar style="margin-top:8px"><i style="width:${p}%"></i></div>`;
 if(G.fb){const f=G.fb,full=q.sent.replace('___','<mark>'+q.word+'</mark>');
  return top+`<div class="card pop"><p class="${f.ok?'ok':'no'}" style="font-size:1.2rem">${f.ok?'🎉 أحسنت! +'+f.pts+' نقطة':'💡 الإجابة: '+q.word+' (0 نقطة)'}</p>
  <p class="en s">${full}</p><p>${q.tr}</p><p class=en><b>${q.word}</b> <i>(${q.pos})</i> — ${q.ar}</p><hr style="border:0;border-top:1px solid var(--line)"><p class=en>${q.ex}</p><p class=mut>${q.exAr}</p>
  <div class=row><button class=p onclick="next()" autofocus>${G.i+1>=G.qs.length?'إنهاء الجلسة':'السؤال التالي ◀'}</button><button onclick="toggleNB('${q.id}')">${S.nb.includes(q.id)?'★ محفوظة':'☆ احفظ في الدفتر'}</button></div></div>`}
 return top+`<div class=card><p class="en s">${s}</p><p>المعنى: <b>${q.ar}</b> <span class="mut en">(${q.pos})</span></p><p class=mut>${q.hint}</p><div class="pat en" id=pat></div>
  <input id=a class=en dir=ltr autocomplete=off autocapitalize=off spellcheck=false aria-label="اكتب الكلمة الناقصة" placeholder="Type the missing word" onkeydown="if(event.key=='Enter')check()"><div id=msg aria-live=polite></div>
  <div class=row><button class=p onclick="check()">إرسال ✔</button><button onclick="hint()">💡 حرف (-2)</button><button onclick="skip()">تخطّي ⏭</button><button onclick="finish(false,0)">👁 أظهر الإجابة (0)</button></div></div>`}
function result(){const n=G.ok.length+G.bad.length,acc=n?Math.round(100*G.ok.length/n):0,li=a=>a.length?a.map(e=>`<span class=en>${e.word}</span> (${e.ar})`).join('، '):'—';
 return `<h1>🏁 انتهت الجلسة</h1><div class=card><p>الأسئلة: <b>${n}</b> · صحيحة: <b class=ok>${G.ok.length}</b> · خاطئة: <b class=no>${G.bad.length}</b></p><p>الدقة: <b>${acc}%</b> · النقاط: <b>⭐ ${G.score}</b> (يشمل مكافأة الإكمال 10)</p>
 <p><b>كلمات تعلّمتها:</b><br>${li(G.ok)}</p><p><b>تحتاج تدريبًا:</b><br>${li(G.bad)}</p>
 <div class=row><button class=p onclick="start('${G.level}'${G.level=='مراجعة'?',S.mis':''})">🔄 إعادة</button><button onclick="view='home';render()">القائمة</button></div></div>`}
function book(){const l=S.nb.map(i=>BY[i]);return `<div class="row sp"><button onclick="view='home';render()">➡ رجوع</button><h2 style="margin:0">📒 دفتر المفردات</h2></div>
 <input id=q dir=auto placeholder="بحث بالإنجليزية أو العربية" oninput="filt(this.value)" aria-label="بحث">
 <div id=bl>${bl(l)}</div>`}
const bl=l=>l.length?l.map(e=>`<div class=card><b class=en>${e.word}</b> <i class=en>(${e.pos})</i> — ${e.ar} <span class="mut en">· ${e.level} · ${e.topic}</span><p class=en>${e.ex}</p><p class=mut>${e.exAr}</p><button onclick="toggleNB('${e.id}')">إزالة</button></div>`).join(''):'<p class=mut>لا توجد كلمات محفوظة بعد.</p>';
function filt(v){v=v.trim().toLowerCase();$('#bl').innerHTML=bl(S.nb.map(i=>BY[i]).filter(e=>e.word.includes(v)||e.ar.includes(v)))}
function info(){alert('الصحيح من أول محاولة: 10 نقاط\nبعد محاولات: 5 نقاط\nكل حرف تلميح: -2 (الحد الأدنى 1)\nإظهار الإجابة: 0\nمكافأة إكمال الجلسة: +10\nتُعتبر الكلمة متقنة بعد 3 إجابات صحيحة من أول محاولة في جلسات مختلفة.')}
function reset(){if(confirm('هل تريد حذف كل التقدم؟ لا يمكن التراجع.')){S=Object.assign({},D,{best:{},m:{},nb:[],mis:[],ach:[],len:S.len,snd:S.snd,theme:S.theme});save();render()}}
/* ===== MENU / SETTINGS / EXIT ===== */
function menu(){const n=Object.values(S.m).filter(x=>x>0).length;
 return `<div class=hero><div class=logo>🎯</div><h1 style="font-size:2.6rem">WordQuest</h1><p class=sub>مغامرة إتقان المفردات الإنجليزية</p><div class=row style="justify-content:center">${LV.map(l=>`<span class="chip en" style="padding:4px 12px;border:1px solid var(--line)">${l[0]}</span>`).join('')}</div><p class=mut>⭐ ${S.score} نقطة · ✅ ${n} كلمة · 🎮 ${S.sessions} جلسة</p></div>
 <div class=menu>${S.last?`<button class=p onclick="start('${S.last}')">⏩ متابعة (${S.last})</button>`:''}<button class="${S.last?'':'p'}" onclick="view='home';render()">▶ لعب</button><button onclick="view='settings';render()">⚙️ إعدادات</button><button onclick="quit()">🚪 خروج</button></div>`}
const chips=()=>[[5,'5'],[10,'10'],[0,'الكل']].map(([n,t])=>`<button class="chip ${len==n?'on':''}" onclick="setLen(${n})">${t}</button>`).join('');
function setLen(n){len=S.len=n;save();render()}
function setTheme(k){S.theme=k;save();render()}
function applyTheme(){const r=document.documentElement;if(S.theme=='light'||S.theme=='dark')r.dataset.theme=S.theme;else r.removeAttribute('data-theme')}
let AC;function beep(t){if(!S.snd)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.frequency.value=t==1?880:220;g.gain.value=.08;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+.15)}catch(e){}}
function settings(){return `<div class="row sp"><button onclick="view='menu';render()">➡ القائمة</button><h2 style="margin:0">⚙️ الإعدادات</h2></div>
 <div class=card><b>عدد الأسئلة في الجلسة</b><div class=row style="margin-top:8px">${chips()}</div></div>
 <div class=card><b>المظهر</b><div class=row style="margin-top:8px">${[['auto','تلقائي'],['light','فاتح'],['dark','داكن']].map(([k,t])=>`<button class="chip ${S.theme==k?'on':''}" onclick="setTheme('${k}')">${t}</button>`).join('')}</div></div>
 <div class=card><div class="row sp"><b>المؤثرات الصوتية</b><button class="chip ${S.snd?'on':''}" aria-pressed="${!!S.snd}" onclick="S.snd=!S.snd;save();beep(1);render()">${S.snd?'مفعّلة':'متوقفة'}</button></div></div>
 <div class=card><b>بياناتك</b><p class=mut style="margin:4px 0">انسخ نص التقدم للاحتفاظ به، أو الصقه لاستعادته.</p><textarea id=bk dir=ltr aria-label="نص التقدم" style="width:100%;min-height:80px;font:inherit;border-radius:12px;border:2px solid var(--line);background:var(--bg);color:var(--ink)"></textarea><div class=row style="margin-top:8px"><button onclick="exp()">📋 تصدير</button><button onclick="imp()">⬆ استيراد</button><button onclick="reset()">🗑 إعادة ضبط</button></div><div id=bm class=mut aria-live=polite></div></div>`}
function exp(){const t=$('#bk');t.value=JSON.stringify(S);t.select();try{navigator.clipboard.writeText(t.value)}catch(e){}$('#bm').textContent='تم إنشاء نص التقدم — انسخه واحفظه.'}
function imp(){try{const o=JSON.parse($('#bk').value);if(typeof o.score!='number'||!o.m||typeof o.m!='object'||!Array.isArray(o.nb)||!Array.isArray(o.mis))throw 0;S=Object.assign({},D,o);S.nb=S.nb.filter(i=>BY[i]);S.mis=S.mis.filter(i=>BY[i]);len=S.len;save();applyTheme();$('#bm').textContent='✅ تم الاستيراد'}catch(e){$('#bm').textContent='❌ نص غير صالح'}}
function quit(){if(!confirm('هل تريد الخروج من اللعبة؟'))return;try{const A=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.App;if(A&&A.exitApp){A.exitApp();return}}catch(e){}view='bye';render();try{window.close()}catch(e){}}
function bye(){return `<div class=hero><div class=logo>👋</div><h1>إلى اللقاء!</h1><p class=sub>تم حفظ تقدمك تلقائيًا. يمكنك إغلاق الصفحة الآن.</p><div class=menu><button class=p onclick="view='menu';render()">↩ العودة إلى اللعبة</button></div></div>`}
const errs=validate();if(errs.length)console.warn('Data errors',errs);
render();

if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){addEventListener('load',()=>navigator.serviceWorker.register('service-worker.js').catch(()=>{}))}
