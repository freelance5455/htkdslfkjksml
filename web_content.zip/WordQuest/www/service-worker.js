const V='wordquest-v1';
const FILES=[
 "./",
 "assets/icons/icon-192.png",
 "assets/icons/icon-512.png",
 "css/style.css",
 "data/a1.js",
 "data/a2.js",
 "data/b1.js",
 "data/b2.js",
 "data/c1.js",
 "data/c2.js",
 "index.html",
 "js/app.js",
 "manifest.json"
];
self.addEventListener('install',e=>e.waitUntil(caches.open(V).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
