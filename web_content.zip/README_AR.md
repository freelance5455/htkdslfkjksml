# إنفينيتي طرحه — مشروع Android APK

هذا مشروع Android WebView جاهز لفتح ملف `index.html` الموجود داخل `app/src/main/assets`.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. اختر **Build > Build APK(s)**.
4. ملف APK التجريبي سيكون داخل `app/build/outputs/apk/debug/`.

التطبيق يعمل بواجهة WebView، وملف HTML يستخدم IndexedDB لحفظ البيانات محليًا.
