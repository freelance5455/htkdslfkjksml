# مشروع أندرويد: سهم

هذا مشروع Android Studio بسيط يعرض نموذج سهم داخل WebView.

## طريقة إنشاء APK
1. على كمبيوتر Windows أو Mac أو Linux، نزّل Android Studio من: https://developer.android.com/studio
2. فك ضغط `Sahm_AndroidStudio_Project.zip`.
3. افتح Android Studio واختر **Open** ثم اختر مجلد `SahmAndroid` الذي يحتوي على `settings.gradle`.
4. انتظر انتهاء Gradle Sync. إذا طلب Android Studio تثبيت Android SDK Platform 35 أو Build Tools، وافق على التثبيت.
5. من القائمة اختر **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
6. بعد اكتمال البناء، اضغط **Locate** في إشعار البناء. عادة يوجد APK التجريبي هنا:
   `app/build/outputs/apk/debug/app-debug.apk`
7. انقل `app-debug.apk` إلى هاتف Android وافتحه. إذا ظهرت رسالة حماية، اسمح مؤقتًا بالتثبيت من هذا المصدر الذي تستخدمه، ثم ثبّت التطبيق.

## تنبيهات
- هذا APK تجريبي محلي، لا ينشر الإعلانات على الإنترنت.
- الإعلانات المضافة تُحفظ محليًا على الجهاز داخل WebView، وقد تختفي عند مسح بيانات التطبيق أو إلغاء تثبيته.
- لا توجد قاعدة بيانات مشتركة، تسجيل دخول، رفع صور فعلي، أو لوحة تحكم.
- قبل إطلاق سوق عام، يلزم خادم وقاعدة بيانات وتخزين صور وسياسة خصوصية ومراجعة أمان.
- لا يتضمن المشروع ملف Gradle Wrapper؛ افتحه في Android Studio وسيقوم البرنامج بإعداد بيئة البناء عند الحاجة.
