# مشروع Android جاهز للبناء — حاسبة الكمون

هذا المشروع يحوّل ملف HTML المرفوع إلى تطبيق Android يعمل محليًا دون إنترنت.

## فتحه في AndroidIDE
1. فك ضغط الملف ZIP.
2. افتح AndroidIDE.
3. اختر Open Existing Project.
4. اختر المجلد `CuminCalculatorAndroid` الذي يحتوي على `settings.gradle`.
5. انتظر Gradle Sync.
6. اختر Build > Assemble Debug APK.
7. ملف APK سيكون في:
   `app/build/outputs/apk/debug/app-debug.apk`

لا تحذف مجلد `app/src/main/assets` لأن ملف `index.html` موجود بداخله.
