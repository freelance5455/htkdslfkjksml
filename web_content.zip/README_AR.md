# حزمة بناء تطبيق الأندرويد (APK) وصفحة الويب (PWA) - راصد الجيجات المحلي

تحتوي هذه الحزمة على كافة الملفات الجاهزة لتحويل التطبيق فوراً إلى ملف **APK** يعمل بدون إنترنت على أي هاتف أندرويد، أو رفعه كصفحة ويب تفاعلية قابلة للتثبيت (**PWA**).

## محتويات الحزمة:
- `www/index.html` : ملف التطبيق الرئيسي المستقل (يعمل 100% بدون إنترنت ويعزل بيانات كل جهاز تلقائياً).
- `www/manifest.json` : ملف تعريف تطبيق الويب (PWA Manifest).
- `www/sw.js` : ملف Service Worker للتخزين المسبق والعمل أوفلاين.
- `www/icons/icon.svg` : أيقونة التطبيق الرسمية عالية الدقة.
- `capacitor.config.json` & `package.json` : إعدادات Capacitor الرسمية لتحويل التطبيق إلى مشروع Android Studio وإخراج ملف APK.
- `config.xml` : ملف إعدادات Cordova / PhoneGap / Website2APK.

---

## طريقة 1: التحويل السريع إلى APK بدون برمجة (في دقيقة واحدة)
1. فك الضغط عن هذا الملف.
2. افتح برنامج **Website 2 APK Builder** أو موقع **WebIntoApp.com** أو تطبيق **Html2Apk**.
3. اختر المجلد `www` (الذي بداخله `index.html`) واضغط **Build / Generate APK**.

## طريقة 2: التحويل الاحترافي عبر Capacitor / Android Studio
```bash
npm install
npx cap add android
npx cap copy android
npx cap open android
```
ثم من قائمة Android Studio اختر: **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.

## طريقة 3: الاستخدام كصفحة ويب (Web / PWA)
افتح ملف `www/index.html` مباشرة في أي متصفح على الهاتف أو الكمبيوتر، أو ارفع محتويات مجلد `www` على أي استضافة ثابتة (مثل GitHub Pages أو Netlify) ليتمكن أي جهاز من تثبيته من المتصفح عبر زر **"إضافة إلى الشاشة الرئيسية"**.
