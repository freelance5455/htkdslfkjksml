# نظام العيادة V2
نسخة Web App محلية قابلة للتغليف كـ APK.
تشمل: حساب النسبة المستقل وتجميع كل الأيام تلقائياً، فترات عمل يدوية لكل يوم، ساعات ناتجة من الفترات، سعة مختلفة، بيانات الحجز (مسلسل/اسم/تليفون/نوع/تاريخ/ساعة/حضور/دفع)، تعديل ونقل، حضور، تقارير، مصروفات، عمليات، إعدادات ونسخ احتياطي.

## APK
يمكن استخدام Capacitor:
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "نظام العيادة" "com.clinic.booking" --web-dir .
npx cap add android
npx cap sync android
npx cap open android

البيانات محلية على الجهاز. المزامنة بين أجهزة متعددة تحتاج Backend وقاعدة بيانات.