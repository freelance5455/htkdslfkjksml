# منصة مذاكرة جامعة القاهرة - Android

المشروع يغلف ملف HTML داخل WebView ويعمل بدون الحاجة إلى اتصال بالإنترنت للمحتوى المحلي.

## ما تم إصلاحه
- نقل ملف HTML إلى `app/src/main/assets/index.html`.
- استبدال مسار شعار الكمبيوتر القديم بصورة محلية داخل assets.
- إزالة الاعتماد على Google Fonts الخارجي حتى يعمل التطبيق محلياً.
- تفعيل JavaScript وDOM Storage حتى يعمل المؤقت والحفظ المحلي والوضع الليلي.
- اسم الحزمة: `com.cairo.studyplanner`.

## بناء APK
افتح المجلد في Android Studio ثم اختر:
Build > Build APK(s)

ستجد ملف APK الناتج داخل:
`app/build/outputs/apk/debug/app-debug.apk`

> ملاحظة: بيئة المحادثة الحالية لا تحتوي على Android SDK/Gradle، لذلك تم تجهيز مشروع Android قابل للفتح والتجميع، وليس APK مبنياً هنا.
