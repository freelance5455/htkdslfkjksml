# NotifyStyle Android Hybrid

هذا المشروع يحوّل واجهة HTML إلى تطبيق Android حقيقي عبر WebView، ويضيف خدمة أصلية `NotificationListenerService` لقراءة إشعارات التطبيقات بعد موافقة المستخدم من إعدادات Android.

## فتح وبناء المشروع

افتح مجلد المشروع في Android Studio، انتظر مزامنة Gradle، ثم شغّل:

```bash
./gradlew assembleDebug
```

سيظهر APK في:

```text
app/build/outputs/apk/debug/app-debug.apk
```

يمكن تثبيته عبر:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

إذا لم يتوفر Android SDK أو Gradle Wrapper، افتح المشروع من Android Studio ليضيف الأدوات المطلوبة أو استخدم Android Studio Build > Make Project.

## تفعيل قراءة الإشعارات

بعد تثبيت التطبيق افتحه، ثم اذهب إلى إعدادات Android > Notification access، وفعّل NotifyStyle. الخدمة تلتقط الإشعارات الجديدة وتعرض نسخة NotifyStyle، وتحفظ سجلًا محليًا، وترسلها إلى واجهة WebView المفتوحة.

## حدود النظام

لا يمكن للتطبيق العادي استبدال لوحة إشعارات Android بالكامل. يمكنه قراءة الإشعارات وعرض نسخة بديلة ضمن الإذن المتاح. قد يقيّد HiOS عمل الخدمة في الخلفية؛ لذلك يجب السماح للتطبيق بالعمل في الخلفية وتعطيل Battery Optimization له عند الحاجة.

## الخصوصية

الإشعارات تمر داخل الجهاز فقط. لا يوجد خادم أو رفع تلقائي للمحتوى. لا تمنح إذن Notification access إلا إذا كنت موافقًا على أن يقرأ التطبيق محتوى الإشعارات لعرضها.
