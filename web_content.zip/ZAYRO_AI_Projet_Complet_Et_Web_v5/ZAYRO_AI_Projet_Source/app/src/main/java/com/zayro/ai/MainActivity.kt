package com.zayro.ai

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH
        }
        setContent {
            ZayroScreen(
                onSpeak = { text ->
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zayro_reply")
                }
            )
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ZayroScreen(onSpeak: (String) -> Unit) {
    val messages = remember {
        mutableStateListOf("ZAYRO" to "Bonjour ! Je suis ZAYRO AI. Que souhaites-tu faire ?")
    }
    var input by remember { mutableStateOf("") }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun sendMessage() {
        val question = input.trim()
        if (question.isEmpty()) return
        messages.add("Toi" to question)
        val answer = "J'ai bien reçu ton message. Mon interface est prête, mais mon cerveau IA en ligne doit encore être connecté."
        messages.add("ZAYRO" to answer)
        input = ""
        onSpeak(answer)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF55C8FF),
            background = Color(0xFF070B1A),
            surface = Color(0xFF111A35)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF101B45), Color(0xFF070B1A))))
                .padding(16.dp)
        ) {
            Text("ZAYRO AI", style = MaterialTheme.typography.headlineLarge, color = Color(0xFF72D5FF))
            Text("TON ASSISTANT MULTIMÉDIA", color = Color.LightGray)
            Spacer(Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { item ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (item.first == "ZAYRO") Color(0xFF17264B) else Color(0xFF26304A),
                                RoundedCornerShape(16.dp)
                            )
                            .padding(14.dp)
                    ) {
                        Text(item.first, color = Color(0xFF72D5FF), style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(4.dp))
                        Text(item.second, color = Color.White)
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Écris à ZAYRO…") },
                    maxLines = 3
                )
                IconButton(onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Parle à ZAYRO")
                    }
                    voiceLauncher.launch(intent)
                }) {
                    Icon(Icons.Default.Mic, contentDescription = "Parler", tint = Color(0xFF72D5FF))
                }
                IconButton(onClick = { sendMessage() }) {
                    Icon(Icons.Default.Send, contentDescription = "Envoyer", tint = Color(0xFF72D5FF))
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Version de démonstration — connexion au cerveau IA à configurer.",
                color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
