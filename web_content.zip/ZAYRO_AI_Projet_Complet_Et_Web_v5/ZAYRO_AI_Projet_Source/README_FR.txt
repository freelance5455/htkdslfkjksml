ZAYRO AI — PROJET ANDROID (SOURCE)

IMPORTANT
- Cette archive ZIP contient le CODE SOURCE du projet Android.
- Un ZIP ne s'installe pas comme une application Android.
- Pour installer l'application sur un Samsung, il faut un fichier APK.
- Cette archive n'est PAS un APK et ne contient PAS encore un cerveau IA distant opérationnel.

CONTENU
- Application Android Kotlin + Jetons Compose
- Interface de conversation ZAYRO
- Saisie vocale via le service vocal Android (après autorisation)
- Lecture des réponses avec la synthèse vocale Android
- Réponse de démonstration locale

LIMITES ACTUELLES
La conversation utilise une réponse de démonstration locale. Pour avoir un véritable cerveau IA indépendant de ChatGPT, il faudra connecter un fournisseur IA et protéger sa clé API dans un serveur. La génération réelle d'images/vidéos et l'écoute permanente « Hey Zayro » ne sont pas activées dans cette première base.

OUVRIR LE PROJET
Importer le dossier dans Android Studio ou un environnement Android compatible, puis construire l'APK.
Identifiant : com.zayro.ai
Nom : ZAYRO AI
