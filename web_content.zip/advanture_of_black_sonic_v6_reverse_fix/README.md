# Advanture of Black Sonic v2 — genişletilmiş prototip

## Eklenen içerikler
- Bölüm 1: Green Hill temalı koşu, halka yolları ve Badnik benzeri özgün çizim düşmanlar.
- Bölüm geçişi: Sonic'in Eggman'in uçan hava gemisine atladığı kısa ara sahne.
- Bölüm 2: Flying Battery temalı hava gemisi platformları ve tehlikeler.
- Bölüm 3: Death Egg içi ve mekanik göz boss'u.
- Ara sahne: Eggman Kaos Zümrüdü'nü çalar.
- Dönüşüm sahnesi: Hyper Sonic.
- Final: uzay/asteroit kovalamacası, iki aşamalı özgün final boss'u ve bitiş sahnesi.
- Daha gelişmiş, oyunun içinde çizilen karakter/düşman görünümleri; mobil düğmeler ve klavye kontrolleri.

## Kontroller
- Sol/Sağ: ekrandaki ◀ ▶ veya A/D/ok tuşları
- Zıpla: ZIPLA veya Space
- Homing Attack: HOMING veya X
- Güç patlaması: GÜÇ veya C
- Ara sahnede ekrana dokun veya bir tuşa basarak devam et.

## Bilinen prototip sınırları
Bu sürüm, oyunun çizimlerini Canvas ile üretir; orijinal Sonic oyunlarından çıkarılmış sprite dosyaları içermez. Resmî sprite sayfalarını kopyalamak yerine özgün, geçici çizimler kullanılmıştır. Sesler, gerçek sprite sheet animasyonları, checkpoint/kayıt sistemi ve gerçek cihazda performans testi sonraki işlerdir.

## v3 ses sistemi
- Her bölüm için ayrı, prosedürel olarak üretilen özgün chiptune müziği.
- Halka, zıplama, Homing Attack, hasar, boss vuruşu, güç patlaması, bölüm geçişi ve Hyper dönüşüm sesleri.
- Sesler Web Audio ile üretilir; ayrı ses dosyası gerekmez. İlk dokunuşta ses etkinleşir.
- Sonic Mania / Sonic & Knuckles / Doomsday kayıtları kopyalanmamıştır.

## APK oluşturma
Bu ZIP doğrudan APK değildir. Android Studio + Node.js + JDK 17 kurulu bilgisayarda:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
`package.json` ve `capacitor.config.json` hazırlandı. Android Studio'da Gradle sync bittikten sonra Build > Build Bundle(s) / APK(s) > Build APK(s) seç. Debug APK genellikle `android/app/build/outputs/apk/debug/app-debug.apk` altına çıkar.

## Test kontrol listesi
- [ ] Green Hill tamamlanınca hava gemisi ara sahnesi
- [ ] Flying Battery bölümünü bitirince Death Egg
- [ ] Mekanik göz boss'u
- [ ] Kaos Zümrüdü hırsızlığı ve Hyper dönüşüm ara sahnesi
- [ ] Doomsday uzay bölümü ve final boss'un iki aşaması
- [ ] Mobil butonların basılı tutma davranışı
- [ ] Boss ve düşman çarpışmaları, can kaybı ve yeniden başlatma
- [ ] Android gerçek cihazda yatay/dikey ekran testi


## v4 visibility fix
Moved the player draw call outside the camera-transformed world layer and now draws it at screen-space x = player.x - camera. This fixes the facing-left camera transform that could make Black Sonic appear to disappear. JavaScript syntax checked; gameplay still needs testing on device/browser.


## v5 görünürlük düzeltmesi
- Sonic, kamera dönüşümünden sonra ekran koordinatlarında çizilir; sola bakarken kamera kaynaklı kaybolma hatası giderilmeye çalışıldı.
- Geçersiz sayısal konumlarda güvenli konuma dönüş koruması eklendi.
- JavaScript sözdizimi kontrolü yapılmıştır; gerçek cihazda oynanış testi henüz yapılmamıştır.


## v6 geri yön / görünürlük düzeltmesi
- Sonic sola bakarken çizim dönüşümündeki hatalı `x*2 + genişlik` kaydırması düzeltildi; doğru ayna dönüşümü için `x + genişlik` kullanılıyor.
- Bu hata, karakterin geriye dönerken ekrandan kaymış gibi görünmesine neden olabilirdi.
- JavaScript sözdizimi kontrolü yapılmıştır; gerçek cihazda oynanış testi yapılmamıştır.
