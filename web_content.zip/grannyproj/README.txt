GRANNY'S JAIL: ESCAPE - package

1) Play in browser: open index.html in Chrome (needs internet: the 3D engine three.js loads from cdnjs).
2) Install like an app: open the published link in Chrome > menu > Add to Home screen.
3) Build your own APK: open the folder "android-project" in Android Studio, wait for Gradle sync,
   then Build > Build Bundle(s)/APK(s) > Build APK(s). (This project is a simple WebView wrapper. I could not
   build or test an APK in my environment, so it is untested.)
