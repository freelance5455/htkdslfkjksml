# Phantom Android Demo (independent recreation)

This is an Android Studio project that recreates the visible public-demo experience from the supplied `Phantom-Demo-0.2.0.ipa` as a local WebView app.

## Included
- Home dashboard with illustrative demo balance and chart
- Asset list (SOL, ETH, BTC, USDC) with sample values
- Explore/search and sample market cards
- Activity empty state
- Profile/settings screens
- Working tab navigation, token filtering, and informational dialogs
- Explicit demo-only notices; send/receive/swap/funding/wallet connections are intentionally nonfunctional

## Important limitations
- The supplied IPA contains a compiled iOS Mach-O app and a sealed demo catalog, not Android source code. This project is a visual/interaction recreation, not a binary conversion or a port of the original SwiftUI implementation.
- It is not an official Phantom product and is not affiliated with Phantom.
- All displayed balances and market values are illustrative. No wallet keys, seed phrases, real funds, network access, deposits, or transactions are supported.

## Build an APK
1. Install Android Studio (current stable) with Android SDK Platform 35 and a compatible JDK.
2. Open this folder (`PhantomAndroid`) in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

Package: `com.wston.phantom`  
Version: `0.2.0-android-demo`
