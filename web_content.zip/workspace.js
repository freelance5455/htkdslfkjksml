/* Learnova Creator Studio v2 — project workspace pages (autosave) */
(function(){
const p=data.projects.find(x=>x.id===Q.get("id"));if(!p)return;
const F={titleInput:"title",formatInput:"format",pillarInput:"pillar",lengthInput:"length",goalInput:"goal",audienceInput:"audience",researchInput:"research",hookInput:"hook",scriptInput:"script",aspectInput:"aspect",fpsInput:"fps",visualStyleInput:"visualStyle",editingInput:"editing",thumbTextInput:"thumbText",thumbMoodInput:"thumbMood",thumbPromptInput:"thumbPrompt",descriptionInput:"description",tagsInput:"tags",pronInput:"pronunciation",publishDateInput:"publishDate",publishTimeInput:"publishTime",timezoneInput:"timezone",uploadTypeInput:"uploadType"};
let t=null;
const stamp=()=>{const s=$("saveState");if(s)s.textContent="Saved · "+new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});$("progBar").style.width=progress(p)+"%";$("progTxt").textContent=progress(p)+"% ready to publish";};
function commit(){Object.entries(F).forEach(([id,k])=>{if($(id))p[k]=$(id).value;});
 const cs=document.querySelectorAll("[data-check]");if(cs.length){p.checks={};cs.forEach(c=>p.checks[c.dataset.check]=c.checked);}
 if($("titleInput")&&p.title.trim()){p.name=p.title.trim();$("editorTitle").textContent=p.title;}
 p.updated=new Date().toISOString();if(save())stamp();}
function later(){const s=$("saveState");if(s)s.textContent="Saving…";clearTimeout(t);t=setTimeout(commit,500);}
Object.entries(F).forEach(([id,k])=>{if($(id))$(id).value=p[k]??"";});
document.querySelectorAll("[data-check]").forEach(c=>c.checked=!!(p.checks&&p.checks[c.dataset.check]));
document.querySelector(".panel").addEventListener("input",e=>{if(!e.target.closest("[data-scene]"))later();});
document.querySelector(".panel").addEventListener("change",e=>{if(!e.target.closest("[data-scene]"))later();});
addEventListener("pagehide",()=>{if(t){clearTimeout(t);commit();}});
$("statusSelect").onchange=()=>{p.status=$("statusSelect").value;p.updated=new Date().toISOString();save();toast("Status updated.");};
$("duplicateBtn").onclick=()=>{const c=JSON.parse(JSON.stringify(p));c.id=uid();c.name=(p.name||"Video")+" (copy)";c.title=(p.title||p.name)+" (copy)";c.status="Idea";c.created=c.updated=new Date().toISOString();data.projects.unshift(c);save();location.href=location.pathname.split("/").pop()+"?id="+c.id;};
$("deleteBtn").onclick=()=>{if(!confirm(`Delete "${p.name}"? This cannot be undone unless you exported a backup.`))return;data.projects=data.projects.filter(x=>x.id!==p.id);save();location.href="projects.html";};
document.querySelectorAll("[data-copy]").forEach(b=>b.onclick=()=>copyText($(b.dataset.copy).value));
if($("defaultEditingBtn"))$("defaultEditingBtn").onclick=()=>{$("editingInput").value=DEFAULT_EDITING;later();toast("Starter checklist inserted.");};
if($("scriptInput")){const wc=()=>{const w=(($("hookInput").value+" "+$("scriptInput").value).trim().match(/\S+/g)||[]).length;const sh=p.format==="YouTube Short";$("wc").textContent=`${w} words · about ${Math.max(1,Math.round(w/150*60))} sec at 150 wpm`+(sh&&w>140?" ⚠ Too long for a 60-second Short":"")+(sh&&w<=140?" ✓ Fits a Short":"");};wc();$("scriptInput").addEventListener("input",wc);$("hookInput").addEventListener("input",wc);}
if($("sceneList")){
 const list=$("sceneList"),SS=["To do","Visual found","Voice done","Edited"];
 const sum=()=>{const d=p.scenes.filter(s=>s.status==="Edited").length;$("sceneSum").textContent=p.scenes.length?`${d} of ${p.scenes.length} scenes edited`:"";};
 const draw=()=>{list.innerHTML=p.scenes.length?p.scenes.map((s,i)=>`<article class="scene-card" data-scene="${s.id}"><div class="scene-card-head"><strong>SCENE ${i+1}</strong><span><button type="button" data-mv="-1" ${i?"":"disabled"} aria-label="Move up">↑</button> <button type="button" data-mv="1" ${i<p.scenes.length-1?"":"disabled"} aria-label="Move down">↓</button> <button type="button" data-rm="1">Remove</button></span></div><div class="scene-fields"><label>Scene / beat<input data-field="beat" value="${esc(s.beat)}" placeholder="Hook, intro, key point…"></label><label>Duration<input data-field="duration" value="${esc(s.duration)}" placeholder="5–10 sec"></label><label class="full">Production status<select data-field="status">${SS.map(x=>`<option${x===(s.status||SS[0])?" selected":""}>${x}</option>`).join("")}</select></label><label class="full">Narration excerpt<textarea data-field="narration" rows="2">${esc(s.narration)}</textarea></label><label class="full">Visual / AI prompt<textarea data-field="prompt" rows="3">${esc(s.prompt)}</textarea></label><label class="full">Editing notes<input data-field="notes" value="${esc(s.notes)}" placeholder="Captions, transition, sound effect…"></label></div></article>`).join(""):'<div class="empty">No scenes yet. Add one, or split your script into scenes.</div>';sum();};
 const onScene=e=>{const c=e.target.closest("[data-scene]"),s=c&&p.scenes.find(x=>x.id===c.dataset.scene);if(s&&e.target.dataset.field){s[e.target.dataset.field]=e.target.value;sum();p.updated=new Date().toISOString();clearTimeout(t);t=setTimeout(commit,500);}};list.addEventListener("input",onScene);list.addEventListener("change",onScene);
 list.addEventListener("change",e=>list.dispatchEvent(new Event("input",{bubbles:false})));
 list.addEventListener("click",e=>{const c=e.target.closest("[data-scene]");if(!c)return;const i=p.scenes.findIndex(x=>x.id===c.dataset.scene);
  if(e.target.dataset.rm){p.scenes.splice(i,1);}else if(e.target.dataset.mv){const j=i+ +e.target.dataset.mv;if(j<0||j>=p.scenes.length)return;[p.scenes[i],p.scenes[j]]=[p.scenes[j],p.scenes[i]];}else return;
  p.scenes.forEach((s,k)=>s.n=k+1);draw();commit();});
 $("addSceneBtn").onclick=()=>{p.scenes.push(newScene(p.scenes.length+1,"New scene","",""));draw();commit();};
 $("copyScenesBtn").onclick=()=>copyText(p.scenes.map((s,i)=>`SCENE ${i+1}: ${s.beat}\nDuration: ${s.duration}\nNarration: ${s.narration}\nVisual prompt: ${s.prompt}\nEditing notes: ${s.notes}`).join("\n\n"));
 $("splitBtn").onclick=()=>{const blocks=(p.script||"").split(/\n\s*\n/).map(b=>b.trim()).filter(Boolean);if(!blocks.length){toast("Write a script first.");return;}
  if(p.scenes.length&&confirm("Replace your current scenes with ones generated from the script?\n\nOK = replace. Cancel = add after existing scenes."))p.scenes=[];
  let c=0;blocks.forEach(b=>{const ls=b.split("\n").map(x=>x.trim()).filter(Boolean);let beat="Scene";if(ls.length>1&&/^[A-Z0-9 ()–\-:&]+$/.test(ls[0]))beat=ls.shift().replace(/\s*\(.*\)/,"");const txt=ls.join(" ");
   txt.split(/\n|(?<=\.)\s+(?=\d\.)/).forEach(t=>{if(t.trim()){p.scenes.push(Object.assign(newScene(p.scenes.length+1,beat,t.trim(),""),{status:SS[0]}));c++;}});});
  draw();commit();toast(c+" scene(s) added from your script.");};
 draw();
}
[["titleInput",100,"aim for 70 or less"],["descriptionInput",5000,""],["tagsInput",500,""]].forEach(([id,max,hint])=>{const el=$(id);if(!el)return;const s=document.createElement("small");s.className="cnt";el.after(s);const u=()=>{const n=el.value.length;s.textContent=n+"/"+max+(hint?" · "+hint:"");s.classList.toggle("over",n>max);};u();el.addEventListener("input",u);});
if($("scriptInput")){const b=document.createElement("button");b.type="button";b.className="secondary-btn";b.textContent="⬇ Download script (.txt)";b.onclick=()=>dl((p.name||"script").replace(/[^\w]+/g,"-")+"-script.txt",(p.title||p.name)+"\n\n"+(p.hook?"HOOK\n"+p.hook+"\n\n":"")+(p.script||"")+(p.pronunciation?"\n\nPRONUNCIATION NOTES\n"+p.pronunciation:""));$("wc").after(b);}
$("tplBtn").onclick=()=>{const n=prompt("Template name:",p.name);if(!n)return;const c=JSON.parse(JSON.stringify(p));delete c.id;c.publishDate="";c.status="Idea";c.checks={};(c.scenes||[]).forEach(s=>s.status="To do");(data.templates=data.templates||[]).push({id:uid(),name:n,project:c});save();toast("Template saved. Pick it when creating a new project.");};
})();
