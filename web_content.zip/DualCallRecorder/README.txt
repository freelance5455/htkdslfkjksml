YA Work Evidence + Dual Call Recorder  (شخصی - Huawei RNE-L21 / Honor 8 Lite / Android 8.0)

نصب:
1) پوشه را در Android Studio باز کنید (File > Open) و Gradle Sync بزنید.
2) Build > Build APK(s) (نسخه debug کافی است) و نصب روی گوشی.
3) برنامه را باز کنید، همه مجوزها را بدهید.
4) تب «ضبط تماس» > فعال‌سازی ضبط خودکار.
5) Settings > Battery > App launch > YA Work Evidence > Manual > هر سه گزینه روشن.
6) Settings > System > Date & time > Automatic date & time روشن.

بخش‌ها:
 - مدارک: عکس، فایل، فایل صوتی؛ هر کدام با SHA-256؛ باز کردن و ارسال (تلگرام، واتساپ، ایتا، ایمیل و...)
 - مکالمات: فهرست ضبط خودکار تماس‌ها با تاریخ شمسی، ساعت تهران، شماره، نام مخاطب، مدت؛ شناسایی خودکار کارفرما با شماره
 - دکمه پایین صفحه: ضبط صدای اطراف (روی همه تب‌ها در دسترس)
 - پشتیبان: JSON و چاپ/PDF

فایل‌ها: حافظه داخلی > CallRecordings (و زیرپوشه‌های Evidence، Ambient، Backup و فایل log.csv)
