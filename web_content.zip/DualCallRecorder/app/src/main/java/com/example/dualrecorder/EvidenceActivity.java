package com.example.dualrecorder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EvidenceActivity extends AppCompatActivity {

    private static final int RC_CAM = 201, RC_PICK = 202, RC_CHOOSER = 203;
    private static final String STATE_CAM = "camFile";

    private static final String[] REQUIRED = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    private static final String[] PERMS = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.PROCESS_OUTGOING_CALLS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
    };

    private static final Pattern CALL_NAME = Pattern.compile(
            "^CALL_(\\d{4}-\\d{2}-\\d{2})_(\\d{2})-(\\d{2})-(\\d{2})_(in|out)(?:_([0-9+]+))?_(2way|mic)\\.(\\w+)$");

    private WebView web;
    private SharedPreferences prefs;
    private File camFile;
    private String pickKind = "file";
    private ValueCallback<Uri[]> chooserCb;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(Prefs.FILE, MODE_PRIVATE);
        // اگر در حال عکس‌گرفتن، سیستم برنامه را از حافظه بیرون انداخت، مسیر عکس از دست نرود
        if (savedInstanceState != null) {
            String p = savedInstanceState.getString(STATE_CAM);
            if (p != null) camFile = new File(p);
        }

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    startActivityForResult(p.createIntent(), RC_CHOOSER);
                } catch (Exception e) {
                    chooserCb = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        if (!hasRequired()) ActivityCompat.requestPermissions(this, PERMS, 100);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (camFile != null) out.putString(STATE_CAM, camFile.getAbsolutePath());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        js("if (window.loadSettings) loadSettings();");
    }

    /** فقط فایل‌های داخل پوشه CallRecordings (و پوشه فایل‌های برنامه) مجاز به باز/ارسال هستند. */
    private boolean isAllowed(File f) {
        try {
            String p = f.getCanonicalPath();
            String a = Util.outputDir(this).getCanonicalPath() + File.separator;
            if (p.startsWith(a)) return true;
            File ext = getExternalFilesDir(null);
            return ext != null && p.startsWith(ext.getCanonicalPath() + File.separator);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasRequired() {
        for (String p : REQUIRED) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) return false;
        }
        return true;
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_CHOOSER) {
            if (chooserCb != null) {
                chooserCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                chooserCb = null;
            }
        } else if (requestCode == RC_CAM) {
            final File f = camFile;
            camFile = null;
            if (resultCode == RESULT_OK && f != null && f.exists() && f.length() > 0) {
                new Thread(() -> finishAttach(f, "photo")).start();
            } else if (f != null) {
                f.delete();
            }
        } else if (requestCode == RC_PICK) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                copyAndAttach(data.getData(), pickKind);
            }
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return "file";
    }

    private void copyAndAttach(final Uri uri, final String kind) {
        new Thread(() -> {
            try {
                String name = displayName(uri).replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
                File out = new File(Util.subDir(this, "Evidence"),
                        "EV_" + Util.jalaliStamp(System.currentTimeMillis()) + "_" + name);
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
                finishAttach(out, kind);
            } catch (Exception e) {
                js("onAttachError(" + JSONObject.quote(String.valueOf(e)) + ")");
            }
        }).start();
    }

    private void finishAttach(File f, String kind) {
        try {
            JSONObject o = new JSONObject();
            o.put("kind", kind);
            o.put("name", f.getName());
            o.put("path", f.getAbsolutePath());
            o.put("size", f.length());
            o.put("sha", Util.sha256(f));
            o.put("at", System.currentTimeMillis());
            js("onAttached(" + o.toString() + ")");
        } catch (Exception e) {
            js("onAttachError(" + JSONObject.quote(String.valueOf(e)) + ")");
        }
    }

    // ---------- خواندن log.csv ----------
    private static List<String> splitCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') { cur.append('"'); i++; }
                    else q = false;
                } else cur.append(c);
            } else if (c == '"') q = true;
            else if (c == ',') { out.add(cur.toString()); cur.setLength(0); }
            else cur.append(c);
        }
        out.add(cur.toString());
        return out;
    }

    private Map<String, List<String>> readLog(File log) {
        Map<String, List<String>> m = new HashMap<>();
        if (!log.exists()) return m;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(log), "UTF-8"))) {
            String line;
            boolean first = true;
            while ((line = r.readLine()) != null) {
                if (first) { first = false; continue; } // سرستون
                List<String> c = splitCsv(line);
                if (c.size() >= 10) m.put(c.get(6), c);
            }
        } catch (Exception ignored) { }
        return m;
    }

    // ---------- پل بین HTML و اندروید ----------
    private class Bridge {

        @JavascriptInterface
        public String getStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("enabled", prefs.getBoolean(Prefs.ENABLED, false));
                o.put("format", prefs.getString(Prefs.FORMAT, "m4a"));
                o.put("speaker", prefs.getBoolean(Prefs.SPEAKER, true));
                o.put("boot", prefs.getBoolean(Prefs.BOOT, true));
                o.put("mode", prefs.getString(Prefs.MODE, "auto"));
                o.put("perms", hasRequired());
                o.put("ambient", AmbientRecorderService.running);
                o.put("ambientStart", AmbientRecorderService.startMs);
                o.put("model", Build.MANUFACTURER + " " + Build.MODEL + " / Android " + Build.VERSION.RELEASE);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void setPref(String key, String val) {
            SharedPreferences.Editor e = prefs.edit();
            if ("format".equals(key)) {
                if (Arrays.asList("m4a", "aac", "3gp", "amrwb", "wav").contains(val)) e.putString(Prefs.FORMAT, val);
            }
            else if ("mode".equals(key)) e.putString(Prefs.MODE, "mic".equals(val) ? "mic" : "auto");
            else if ("speaker".equals(key)) e.putBoolean(Prefs.SPEAKER, "true".equals(val));
            else if ("boot".equals(key)) e.putBoolean(Prefs.BOOT, "true".equals(val));
            e.apply();
        }

        @JavascriptInterface
        public void startCalls() {
            runOnUiThread(() -> {
                if (!hasRequired()) {
                    ActivityCompat.requestPermissions(EvidenceActivity.this, PERMS, 100);
                    toast("ابتدا مجوزها را بدهید، سپس دوباره دکمه را بزنید");
                    return;
                }
                prefs.edit().putBoolean(Prefs.ENABLED, true).apply();
                Intent i = new Intent(EvidenceActivity.this, CallRecorderService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
                else startService(i);
                toast("ضبط خودکار تماس‌ها فعال شد");
            });
        }

        @JavascriptInterface
        public void stopCalls() {
            runOnUiThread(() -> {
                prefs.edit().putBoolean(Prefs.ENABLED, false).apply();
                stopService(new Intent(EvidenceActivity.this, CallRecorderService.class));
                toast("ضبط خودکار تماس‌ها متوقف شد");
            });
        }

        @JavascriptInterface
        public void requestPerms() {
            runOnUiThread(() -> ActivityCompat.requestPermissions(EvidenceActivity.this, PERMS, 100));
        }

        @JavascriptInterface
        public void batterySettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            });
        }

        @JavascriptInterface
        public String listCalls() {
            JSONArray arr = new JSONArray();
            try {
                File dir = Util.outputDir(EvidenceActivity.this);
                File[] files = dir.listFiles((d, n) -> n.startsWith("CALL_"));
                if (files == null) return "[]";
                List<File> list = new ArrayList<>(Arrays.asList(files));
                Collections.sort(list, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                Map<String, List<String>> log = readLog(new File(dir, "log.csv"));
                for (File f : list) {
                    JSONObject o = new JSONObject();
                    o.put("file", f.getName());
                    o.put("path", f.getAbsolutePath());
                    o.put("size", f.length());
                    o.put("ms", f.lastModified());
                    Matcher m = CALL_NAME.matcher(f.getName());
                    if (m.matches()) {
                        o.put("jdate", m.group(1));
                        o.put("jtime", m.group(2) + ":" + m.group(3) + ":" + m.group(4));
                        o.put("dir", m.group(5));
                        o.put("number", m.group(6) == null ? "" : m.group(6));
                        o.put("source", m.group(7));
                    }
                    List<String> c = log.get(f.getName());
                    if (c != null) {
                        o.put("iso", c.get(2));
                        o.put("name", c.get(5));
                        o.put("duration", c.get(8));
                        o.put("sha", c.get(9));
                        if (!o.has("number") || o.getString("number").isEmpty()) o.put("number", c.get(4));
                    }
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void attach(final String kind) {
            runOnUiThread(() -> {
                try {
                    if ("camera".equals(kind)) {
                        camFile = new File(Util.subDir(EvidenceActivity.this, "Evidence"),
                                "PHOTO_" + Util.jalaliStamp(System.currentTimeMillis()) + ".jpg");
                        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        i.putExtra(MediaStore.EXTRA_OUTPUT, Util.uriFor(EvidenceActivity.this, camFile));
                        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(i, RC_CAM);
                    } else {
                        pickKind = "image".equals(kind) ? "photo" : kind;
                        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("image".equals(kind) ? "image/*" : "audio".equals(kind) ? "audio/*" : "*/*");
                        startActivityForResult(Intent.createChooser(i, "انتخاب فایل"), RC_PICK);
                    }
                } catch (Exception e) {
                    toast("خطا: " + e);
                }
            });
        }

        @JavascriptInterface
        public String ambientStart() {
            if (!hasRequired()) {
                runOnUiThread(() -> ActivityCompat.requestPermissions(EvidenceActivity.this, PERMS, 100));
                return "perm";
            }
            runOnUiThread(() -> {
                Intent i = new Intent(EvidenceActivity.this, AmbientRecorderService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
                else startService(i);
            });
            for (int k = 0; k < 40 && !AmbientRecorderService.running; k++) {
                try { Thread.sleep(100); } catch (InterruptedException ignored) { }
            }
            return AmbientRecorderService.running ? "ok" : "fail";
        }

        @JavascriptInterface
        public String ambientStop() {
            AmbientRecorderService s = AmbientRecorderService.instance;
            if (s == null) return "";
            long st = AmbientRecorderService.startMs;
            File f = s.finish();
            if (f == null || !f.exists()) return "";
            try {
                JSONObject o = new JSONObject();
                o.put("kind", "ambient");
                o.put("name", f.getName());
                o.put("path", f.getAbsolutePath());
                o.put("size", f.length());
                o.put("sha", Util.sha256(f));
                o.put("at", st);
                o.put("dur", (System.currentTimeMillis() - st) / 1000);
                return o.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void openFile(final String path) {
            runOnUiThread(() -> {
                File f = new File(path);
                if (!f.exists()) { toast("فایل پیدا نشد"); return; }
                if (!isAllowed(f)) { toast("مسیر فایل مجاز نیست"); return; }
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Util.uriFor(EvidenceActivity.this, f), Util.mimeFor(f.getName()));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(i);
                } catch (Exception e) {
                    toast("برنامه‌ای برای باز کردن این فایل پیدا نشد");
                }
            });
        }

        @JavascriptInterface
        public void shareFile(final String path) {
            runOnUiThread(() -> shareInternal(new File(path)));
        }

        @JavascriptInterface
        public String saveBackup(String json) {
            try {
                File f = new File(Util.subDir(EvidenceActivity.this, "Backup"),
                        "YA-Work-Evidence-Backup-" + Util.jalaliStamp(System.currentTimeMillis()) + ".json");
                try (OutputStream os = new FileOutputStream(f)) {
                    os.write(json.getBytes("UTF-8"));
                }
                final File ff = f;
                runOnUiThread(() -> shareInternal(ff));
                return f.getAbsolutePath();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print("YA Work Evidence", web.createPrintDocumentAdapter("YA Work Evidence"),
                        new PrintAttributes.Builder().build());
            });
        }
    }

    private void shareInternal(File f) {
        if (!f.exists()) { toast("فایل پیدا نشد"); return; }
        if (!isAllowed(f)) { toast("مسیر فایل مجاز نیست"); return; }
        try {
            Uri u = Util.uriFor(this, f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(Util.mimeFor(f.getName()));
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.setClipData(ClipData.newRawUri("", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "ارسال با..."));
        } catch (Exception e) {
            toast("ارسال ممکن نشد: " + e);
        }
    }
}
