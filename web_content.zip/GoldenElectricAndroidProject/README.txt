Golden Electric & Solar System — Android Studio project

This is the Android app source project containing the shop billing UI as an offline WebView app.
It is NOT a compiled APK.

Build APK:
1. Install Android Studio on a computer.
2. Open this extracted folder as an existing project.
3. Allow Gradle sync/downloads.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find APK in app/build/outputs/apk/debug/app-debug.apk.

The build needs internet access for Gradle/Android SDK dependencies and an Android SDK installation.
Shop: Golden Electric & Solar System
Address: چوک بہادر پور، رحیم یار خان
Phones: 0300-7024406 / 0300-7024405
