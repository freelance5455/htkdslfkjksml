# Laundry Vibes Receipt Android App

This project wraps the supplied `laundry-vibes-receipt.html` in an offline Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on an Android phone.

## PDF
The HTML's existing `Print / Save PDF` button opens Android's system print dialog. The receipt uses A4 print CSS from the supplied HTML.

## Offline
The receipt HTML is bundled inside the APK under `app/src/main/assets`, so the receipt form itself does not require internet access.
