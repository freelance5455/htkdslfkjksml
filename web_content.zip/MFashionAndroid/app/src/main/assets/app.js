// M FASHION storefront demo. Replace the WhatsApp number below with your business number.
const WHATSAPP_NUMBER = "91XXXXXXXXXX"; // Example format: 919876543210 (country code + number, no + or spaces)

const products = [
 {id:1,name:"Classic Black Jacket",category:"Men",price:1499,old:1999,tag:"BESTSELLER",img:"https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=700&q=85"},
 {id:2,name:"Everyday White Shirt",category:"Men",price:899,old:1199,tag:"NEW",img:"https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=700&q=85"},
 {id:3,name:"Elegant Black Dress",category:"Women",price:1299,old:1699,tag:"TRENDING",img:"https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=700&q=85"},
 {id:4,name:"Casual Denim Look",category:"Women",price:1099,old:1499,tag:"POPULAR",img:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=700&q=85"},
 {id:5,name:"Minimal Hoodie",category:"Men",price:1199,old:1599,tag:"NEW",img:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=700&q=85"},
 {id:6,name:"Everyday Sneakers",category:"Accessories",price:1899,old:2299,tag:"FAVOURITE",img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=85"},
 {id:7,name:"Statement Handbag",category:"Accessories",price:1399,old:1799,tag:"JUST IN",img:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=700&q=85"},
 {id:8,name:"Soft Knit Top",category:"Women",price:799,old:999,tag:"ESSENTIAL",img:"https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=700&q=85"}
];
let activeFilter="All", cart=JSON.parse(localStorage.getItem("mfashion-cart")||"{}");
const $=s=>document.querySelector(s);
const money=n=>"₹"+n.toLocaleString("en-IN");
function renderProducts(){
 let list=products.filter(p=>(activeFilter==="All"||p.category===activeFilter)&&(`${p.name} ${p.category}`.toLowerCase().includes($("#searchInput").value.toLowerCase())));
 const sort=$("#sortSelect").value;if(sort==="low")list.sort((a,b)=>a.price-b.price);if(sort==="high")list.sort((a,b)=>b.price-a.price);
 $("#productGrid").innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image"><img src="${p.img}" alt="${p.name}" loading="lazy"><span class="product-tag">${p.tag}</span></div><div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><span class="price">${money(p.price)}</span><span class="old-price">${money(p.old)}</span><button class="add-btn" data-add="${p.id}">＋ Add to bag</button></div></article>`).join(""):`<p>No products found. Try another search.</p>`;
}
function saveCart(){localStorage.setItem("mfashion-cart",JSON.stringify(cart));renderCart();}
function addToCart(id){cart[id]=(cart[id]||0)+1;saveCart();showToast("Added to your bag");}
function changeQty(id,n){cart[id]=(cart[id]||0)+n;if(cart[id]<=0)delete cart[id];saveCart();}
function renderCart(){
 const entries=Object.entries(cart).filter(([id,q])=>q>0);let count=entries.reduce((s,[id,q])=>s+q,0),total=0;
 $("#cartCount").textContent=count;$("#drawerCount").textContent=`(${count})`;
 $("#cartItems").innerHTML=entries.length?entries.map(([id,q])=>{let p=products.find(x=>x.id===+id);total+=p.price*q;return `<div class="cart-line"><img src="${p.img}" alt=""><div><h4>${p.name}</h4><small>${money(p.price)}</small><div class="qty-controls"><button data-qty="${id}" data-delta="-1">−</button><span>${q}</span><button data-qty="${id}" data-delta="1">+</button></div></div><button class="remove-btn" data-remove="${id}" aria-label="Remove">×</button></div>`}).join(""):`<p class="empty-cart">Your bag is waiting for something special.</p>`;
 $("#cartSubtotal").textContent=money(total);
}
function openCart(){ $("#cartDrawer").classList.add("open");$("#overlay").classList.add("show");}
function closeCart(){ $("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("show");}
let toastTimer;function showToast(msg){$("#toast").textContent=msg;$("#toast").classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("#toast").classList.remove("show"),2100);}
document.addEventListener("click",e=>{
 const add=e.target.closest("[data-add]");if(add)addToCart(+add.dataset.add);
 const qty=e.target.closest("[data-qty]");if(qty)changeQty(+qty.dataset.qty,+qty.dataset.delta);
 const rem=e.target.closest("[data-remove]");if(rem){delete cart[rem.dataset.remove];saveCart();}
 const filter=e.target.closest("[data-filter]");if(filter){activeFilter=filter.dataset.filter;document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));renderProducts();if(filter.classList.contains("category-card"))document.querySelector("#shop").scrollIntoView({behavior:"smooth"});}
});
$("#cartToggle").addEventListener("click",openCart);$("#closeCart").addEventListener("click",closeCart);$("#overlay").addEventListener("click",closeCart);
$("#searchInput").addEventListener("input",renderProducts);$("#sortSelect").addEventListener("change",renderProducts);
$("#searchToggle").addEventListener("click",()=>{document.querySelector("#shop").scrollIntoView({behavior:"smooth"});$("#searchInput").focus();});
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>$("#mainNav").classList.remove("open")));
$("#checkoutBtn").addEventListener("click",()=>{
 const entries=Object.entries(cart).filter(([id,q])=>q>0);if(!entries.length){showToast("Your bag is empty");return;}
 if(WHATSAPP_NUMBER.includes("X")){showToast("Add your WhatsApp number in app.js first");return;}
 let total=0,lines=entries.map(([id,q])=>{let p=products.find(x=>x.id===+id);total+=p.price*q;return `${p.name} x ${q} — ${money(p.price*q)}`;});
 let msg=`Hello M FASHION! I would like to place an order:\n${lines.join("\n")}\nSubtotal: ${money(total)}\nPlease confirm availability, delivery charges and payment options.`;
 window.location.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
});
$("#newsletterForm").addEventListener("submit",e=>{e.preventDefault();$("#newsletterMessage").textContent="Thanks! Newsletter signup needs an email service connection.";e.target.reset();});
const translations={hi:{home:"होम",shop:"शॉप",categories:"कैटेगरी",about:"हमारे बारे में",contact:"संपर्क",shopNow:"कलेक्शन देखें"},bn:{home:"হোম",shop:"শপ",categories:"ক্যাটাগরি",about:"আমাদের সম্পর্কে",contact:"যোগাযোগ",shopNow:"কালেকশন দেখুন"},en:{home:"Home",shop:"Shop",categories:"Categories",about:"About",contact:"Contact",shopNow:"Shop the collection"}};
$("#languageSelect").addEventListener("change",e=>{let t=translations[e.target.value];document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=t[el.dataset.i18n]);});
$("#year").textContent=new Date().getFullYear();renderProducts();renderCart();
