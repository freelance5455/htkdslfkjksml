M FASHION Android app project (WebView wrapper)

This is an Android Studio project source, not a prebuilt APK.

BUILD APK:
1. Install Android Studio on a computer.
2. Open this folder (MFashionAndroid) in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the project.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).

BEFORE USING FOR REAL ORDERS:
- In app/src/main/assets/app.js, replace WHATSAPP_NUMBER = "91XXXXXXXXXX" with your WhatsApp number (digits only, including country code).
- Replace sample products, prices and images with your actual products.
- This app currently shows the storefront and shopping cart. It does not include real payment processing, server-side order storage, or an admin dashboard.
- Product images and Google Fonts load from the internet. The app needs an internet connection for those remote assets.
- Use a trusted payment provider and secure backend before accepting online payments.

APP ID: com.mfashion.store
APP NAME: M FASHION
