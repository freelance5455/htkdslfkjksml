Koo Koo Horror Stories - Android Studio Project

આ ZIP માં તમારું આપેલું HTML Android WebView app માં મૂકેલું છે.
Backend/Firebase નથી. Stories અને favourites WebView localStorage માં આ ફોન પર સેવ થાય છે.
Hindi voice narration માટે ફોનમાં Hindi text-to-speech voice ઉપલબ્ધ હોવી જરૂરી છે.

Build:
1. ZIP extract કરો.
2. Android Studio માં extracted KooKooHorror folder Open કરો.
3. Gradle Sync પૂરો થવા દો (પ્રથમ વખત internet જરૂરી છે).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk માં મળશે.

નોંધ:
- ZIP માં project source છે, APK નથી.
- ZIP size 5 MBથી ઘણી ઓછી છે.
- Admin Panel હાલ Local Admin છે; PIN/login protection નથી.
- Project Gradle wrapper binary વગર છે; Android Studio installed Gradle/Gradle sync નો ઉપયોગ કરશે.
