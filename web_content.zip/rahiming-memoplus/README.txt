RAHIMING MémoPlus
==================

Jeu de mémoire (cartes à paires) 100% hors ligne, en français.

Contenu :
- index.html : l'application complète (autonome, aucune dépendance externe requise pour fonctionner hors ligne, à part le chargement initial de la police Google Fonts si une connexion est disponible)

Utilisation :
- Ouvrir index.html dans un navigateur mobile ou desktop pour jouer directement.
- Pour en faire une application Android installable (.apk), ce fichier peut être empaqueté avec un outil comme Capacitor (https://capacitorjs.com) ou PWABuilder (https://www.pwabuilder.com).

Fonctionnalités :
- Écran de démarrage, menu principal, sélection de niveau (Facile 4x4 / Moyen 6x6 / Difficile 8x8)
- Jeu de cartes à paires avec score, temps, coups
- Historique des meilleurs scores par niveau (stocké localement sur l'appareil)
- Paramètres : mode clair/sombre, effets sonores, musique de fond
- Aucune connexion internet, aucun compte requis, toutes les données restent sur l'appareil
