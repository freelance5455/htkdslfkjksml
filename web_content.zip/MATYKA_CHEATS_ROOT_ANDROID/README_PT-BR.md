# MATYKA CHEATS ROOT — BLACK EDITION

Projeto Android híbrido: interface HTML em WebView + botão MC nativo usando `WindowManager`.

## O que está implementado
- Interface preta/vermelha e os 22 módulos distribuídos nas sete categorias solicitadas.
- Alternâncias dos módulos são somente estados visuais locais.
- Botões na interface para ativar e encerrar o atalho MC.
- Solicitação explícita da permissão `SYSTEM_ALERT_WINDOW`.
- Botão MC nativo circular e arrastável; toque abre o painel completo em uma janela flutuante com a interface HTML e as sete categorias.
- Serviço em primeiro plano com notificação persistente e ação **Encerrar**.

## Importante
Este projeto não injeta código, não altera jogos, não executa cheats e não controla outros aplicativos. O botão é apenas um atalho flutuante para abrir a própria interface MATYKA.

O projeto foi preparado como fonte Android Studio; não foi compilado nem testado neste ambiente. APK Forge/HTML-to-APK que apenas empacota HTML não compila os arquivos Java, o Manifest e o serviço Android. Use Android Studio ou Code Assist com suporte a projeto Android nativo para gerar o APK.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `MATYKA_CHEATS_ROOT_ANDROID` no Android Studio.
3. Aguarde a sincronização Gradle (plugin Android Gradle 8.7.3; compile/target SDK 35; min SDK 23).
4. Compile pelo menu **Build > Build APK(s)**.
5. Instale o APK e abra o MATYKA.
6. Toque em **ATIVAR MC FLUTUANTE** e conceda manualmente a permissão de sobreposição na tela do Android.
7. Para desligar, use **ENCERRAR MC** na interface ou **Encerrar** na notificação.

## Observações de compatibilidade
- `SYSTEM_ALERT_WINDOW` é uma autorização especial concedida pelo usuário nas configurações do Android.
- Android 8+ usa `TYPE_APPLICATION_OVERLAY`.
- O serviço usa o tipo `specialUse` para justificar o atalho flutuante iniciado pelo usuário; versões atuais exigem declaração específica e podem aplicar políticas adicionais de distribuição.
- Android 13+ possui permissão de notificações. A notificação é necessária para a experiência transparente do serviço; se a permissão for negada, o sistema ainda pode mostrar o serviço no gerenciador de tarefas, mas a visibilidade da notificação muda.
- Android 15 limita iniciar certos serviços em segundo plano. Por isso, o fluxo inicia o serviço a partir da Activity visível, depois da ação do usuário e da autorização.
- Fabricantes podem encerrar processos por economia de bateria; não há garantia de permanência após encerramento forçado, reinicialização ou restrições do fabricante.
- O rótulo `specialUse` pode exigir revisão adicional em publicação na Play Store. Para uso pessoal/testes, ainda é necessário testar no dispositivo real.

## Arquivos principais
- `app/src/main/assets/index.html`: interface.
- `app/src/main/java/.../MainActivity.java`: WebView e fluxo de autorização.
- `app/src/main/java/.../FloatingOverlayService.java`: atalho flutuante e notificação.
- `app/src/main/AndroidManifest.xml`: permissões e declaração do serviço.
