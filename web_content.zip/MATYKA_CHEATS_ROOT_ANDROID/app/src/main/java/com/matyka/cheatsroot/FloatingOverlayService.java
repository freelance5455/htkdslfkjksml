package com.matyka.cheatsroot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;

public class FloatingOverlayService extends Service {
    public static final String ACTION_START = "com.matyka.cheatsroot.START_OVERLAY";
    private static final String ACTION_STOP = "com.matyka.cheatsroot.STOP_OVERLAY";
    private static final String CHANNEL_ID = "matyka_overlay";
    private static final int NOTIFICATION_ID = 701;
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams params;
    private WindowManager.LayoutParams panelParams;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        showBubble();
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Botão flutuante MATYKA", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mostra o atalho MC enquanto o usuário mantém o recurso ativado");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, FloatingOverlayService.class).setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPending = PendingIntent.getService(this, 702, stop, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MATYKA — botão MC ativo")
                .setContentText("O atalho flutuante está ligado. Use Encerrar para desligá-lo.")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Encerrar", stopPending)
                .build();
    }

    private void showBubble() {
        if (bubble != null) return;
        TextView button = new TextView(this);
        button.setText("MC");
        button.setTextColor(Color.WHITE);
        button.setTextSize(16);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(255, 76, 104), Color.rgb(169, 0, 36)});
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), Color.rgb(255, 82, 107));
        button.setBackground(bg);
        button.setElevation(dp(12));

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(58), dp(58), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(16);
        params.y = dp(220);

        button.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x; startY = params.y;
                        downX = event.getRawX(); downY = event.getRawY(); moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - downX);
                        int dy = (int) (event.getRawY() - downY);
                        if (Math.abs(dx) + Math.abs(dy) > dp(5)) moved = true;
                        params.x = startX + dx; params.y = startY + dy;
                        try { windowManager.updateViewLayout(bubble, params); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) showPanel();
                        return true;
                }
                return false;
            }
        });
        bubble = button;
        windowManager.addView(bubble, params);
    }


    private void showPanel() {
        if (panel != null) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.rgb(9, 9, 11));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), Color.rgb(116, 24, 43));
        root.setBackground(panelBg);
        root.setClipToOutline(true);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(10), dp(10));
        header.setBackgroundColor(Color.rgb(25, 12, 17));
        TextView title = new TextView(this);
        title.setText("MATYKA ROOT  •  BLACK EDITION");
        title.setTextColor(Color.WHITE);
        title.setTextSize(11);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setLetterSpacing(0.08f);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(18);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(Color.rgb(125, 13, 37));
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> hidePanel());
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(58)));

        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8, 8, 9));
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(false);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new OverlayPanelBridge(), "AndroidOverlay");
        web.loadUrl("file:///android_asset/index.html");
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        int width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(24), dp(560));
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.82f);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        panelParams = new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;
        panel = root;
        windowManager.addView(panel, panelParams);
        if (bubble != null) bubble.setVisibility(View.GONE);
    }

    private void hidePanel() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }

    private class OverlayPanelBridge {
        @android.webkit.JavascriptInterface public void enable() {
            // O serviço já está ativo enquanto o painel flutuante está aberto.
            android.os.Handler h = new android.os.Handler(getMainLooper());
            h.post(() -> android.widget.Toast.makeText(FloatingOverlayService.this,
                    "Botão MC já está ativo", android.widget.Toast.LENGTH_SHORT).show());
        }
        @android.webkit.JavascriptInterface public void disable() {
            android.os.Handler h = new android.os.Handler(getMainLooper());
            h.post(() -> stopSelf());
        }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
