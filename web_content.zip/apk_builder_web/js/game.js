/**
 * APK Builder – client-side UI logic
 * Communicates with a trusted remote build endpoint.
 * Does NOT compile APKs locally.
 */

(function () {
  "use strict";

  // DOM references
  const endpointEl = document.getElementById("endpoint");
  const tokenEl = document.getElementById("token");
  const nameEl = document.getElementById("app-name");
  const descEl = document.getElementById("description");
  const versionEl = document.getElementById("version-name");
  const versionCodeEl = document.getElementById("version-code");
  const packageEl = document.getElementById("package-id");

  const zipInput = document.getElementById("zip-input");
  const iconInput = document.getElementById("icon-input");
  const btnZip = document.getElementById("btn-zip");
  const btnIcon = document.getElementById("btn-icon");
  const zipStatus = document.getElementById("zip-status");
  const iconStatus = document.getElementById("icon-status");
  const projectInfo = document.getElementById("project-info");

  const btnBuild = document.getElementById("btn-build");
  const btnInstall = document.getElementById("btn-install");
  const progressBar = document.getElementById("progress-bar");
  const statusEl = document.getElementById("status");
  const outputEl = document.getElementById("output");

  const btnHelp = document.getElementById("btn-help");
  const modal = document.getElementById("modal");
  const modalTitle = document.getElementById("modal-title");
  const modalMessage = document.getElementById("modal-message");
  const modalClose = document.getElementById("modal-close");

  // State
  let zipFile = null;
  let iconFile = null;
  let apkBlob = null;
  let apkUrl = null;
  let busy = false;

  const MAX_ZIP_SIZE = 200 * 1024 * 1024; // 200 MB

  // ---------- Helpers ----------
  function showModal(title, message) {
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modal.hidden = false;
  }

  function hideModal() {
    modal.hidden = true;
  }

  function setStatus(msg, progress) {
    statusEl.textContent = msg;
    if (typeof progress === "number") {
      progressBar.style.width = Math.min(100, Math.max(0, progress)) + "%";
    }
  }

  function setBusy(state) {
    busy = state;
    btnBuild.disabled = state;
  }

  function loadConfig() {
    try {
      const raw = localStorage.getItem("apkBuilderConfig");
      if (!raw) return;
      const cfg = JSON.parse(raw);
      if (cfg.endpoint) endpointEl.value = cfg.endpoint;
      if (cfg.token) tokenEl.value = cfg.token;
    } catch (_) {}
  }

  function saveConfig() {
    try {
      localStorage.setItem(
        "apkBuilderConfig",
        JSON.stringify({
          endpoint: endpointEl.value.trim(),
          token: tokenEl.value.trim(),
        })
      );
    } catch (_) {}
  }

  // ---------- File selection ----------
  btnZip.addEventListener("click", () => zipInput.click());
  btnIcon.addEventListener("click", () => iconInput.click());

  zipInput.addEventListener("change", async () => {
    const file = zipInput.files[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith(".zip")) {
      showModal("Invalid file", "Please select a .zip project file.");
      zipInput.value = "";
      return;
    }
    if (file.size > MAX_ZIP_SIZE) {
      showModal("ZIP too large", "ZIP must be 200 MB or smaller.");
      zipInput.value = "";
      return;
    }

    // Basic ZIP signature check
    try {
      const header = await file.slice(0, 4).arrayBuffer();
      const bytes = new Uint8Array(header);
      if (bytes[0] !== 0x50 || bytes[1] !== 0x4b) {
        showModal("Invalid ZIP", "This file is not a valid ZIP archive.");
        zipInput.value = "";
        return;
      }
    } catch (_) {
      showModal("ZIP error", "Could not read the selected file.");
      zipInput.value = "";
      return;
    }

    zipFile = file;
    zipStatus.classList.add("has-file");
    zipStatus.querySelector("span").textContent = "ZIP: " + file.name;

    // Simple detection by name patterns (client-side only)
    const name = file.name.toLowerCase();
    const detected = [];
    if (name.includes("buildozer") || name.includes("python")) detected.push("Python / Buildozer");
    if (name.includes("html") || name.includes("web")) detected.push("HTML / Web");
    if (name.includes("gradle") || name.includes("android")) detected.push("Android Gradle");
    if (detected.length === 0) detected.push("Unknown / requires a compatible template");

    projectInfo.textContent =
      "Detected: " +
      detected.join(", ") +
      ". Detection is only a clue; the remote builder decides if it can build this project.";
  });

  iconInput.addEventListener("change", () => {
    const file = iconInput.files[0];
    if (!file) return;
    if (!file.type.includes("png") && !file.name.toLowerCase().endsWith(".png")) {
      showModal("Invalid icon", "Choose a PNG image.");
      iconInput.value = "";
      return;
    }
    iconFile = file;
    iconStatus.classList.add("has-file");
    iconStatus.querySelector("span").textContent = "Icon: " + file.name;
  });

  // ---------- Validation ----------
  function validate() {
    const endpoint = endpointEl.value.trim();
    if (!endpoint.startsWith("https://")) {
      showModal("Endpoint required", "Enter a trusted HTTPS remote build endpoint first.");
      return false;
    }
    if (!zipFile) {
      showModal("ZIP required", "Import a valid project ZIP first.");
      return false;
    }
    if (!nameEl.value.trim()) {
      showModal("App name required", "Enter an app name.");
      return false;
    }
    const vc = parseInt(versionCodeEl.value, 10);
    if (isNaN(vc) || vc < 1) {
      showModal("Invalid version code", "Version code must be a positive integer.");
      return false;
    }
    const pkg = packageEl.value.trim();
    const parts = pkg.split(".");
    if (
      parts.length < 2 ||
      parts.some(
        (p) => !p || !/^[a-zA-Z][a-zA-Z0-9_]*$/.test(p)
      )
    ) {
      showModal("Invalid package ID", "Use a package ID like com.example.myapp.");
      return false;
    }
    return true;
  }

  // ---------- Build ----------
  btnBuild.addEventListener("click", async () => {
    if (busy) return;
    if (!validate()) return;

    saveConfig();
    setBusy(true);
    setStatus("Uploading project to remote build service...", 10);

    // Clean previous result
    if (apkUrl) {
      URL.revokeObjectURL(apkUrl);
      apkUrl = null;
    }
    apkBlob = null;
    btnInstall.disabled = true;
    outputEl.textContent = "Building…";

    try {
      const form = new FormData();
      form.append("project_zip", zipFile, zipFile.name);
      form.append("app_name", nameEl.value.trim());
      form.append("description", descEl.value.trim());
      form.append("version_name", versionEl.value.trim());
      form.append("version_code", versionCodeEl.value.trim());
      form.append("package_id", packageEl.value.trim());
      if (iconFile) {
        form.append("icon_png", iconFile, iconFile.name);
      }

      const headers = {};
      const token = tokenEl.value.trim();
      if (token) {
        headers["Authorization"] = "Bearer " + token;
      }

      setStatus("Waiting for remote service…", 40);

      const response = await fetch(endpointEl.value.trim(), {
        method: "POST",
        body: form,
        headers,
      });

      setStatus("Remote service responded. Checking build result…", 70);

      if (!response.ok) {
        let detail = "";
        try {
          detail = (await response.text()).slice(0, 1500);
        } catch (_) {
          detail = "No error details returned.";
        }
        throw new Error("Build service HTTP " + response.status + ": " + detail);
      }

      const contentType = (response.headers.get("content-type") || "").toLowerCase();
      let blob;

      if (
        contentType.includes("application/vnd.android.package-archive") ||
        contentType.includes("application/zip") ||
        contentType.includes("application/octet-stream")
      ) {
        blob = await response.blob();
      } else {
        // Expect JSON with apk_url or error
        const data = await response.json();
        if (data.error) {
          throw new Error(String(data.error));
        }
        const url = data.apk_url;
        if (!url || !String(url).startsWith("https://")) {
          throw new Error(
            "No HTTPS apk_url was returned. Service response: " +
              JSON.stringify(data).slice(0, 1000)
          );
        }
        setStatus("Downloading APK from build service…", 85);
        const dl = await fetch(url, { headers });
        if (!dl.ok) {
          throw new Error("APK download failed with HTTP " + dl.status);
        }
        blob = await dl.blob();
      }

      if (!blob || blob.size < 1000) {
        throw new Error("The returned file is too small to be a valid APK.");
      }

      // Quick ZIP signature check (APK is a ZIP)
      const sig = new Uint8Array(await blob.slice(0, 2).arrayBuffer());
      if (sig[0] !== 0x50 || sig[1] !== 0x4b) {
        throw new Error("The output is not a ZIP-based Android APK. Build rejected.");
      }

      apkBlob = blob;
      apkUrl = URL.createObjectURL(blob);

      const safeName =
        (nameEl.value.trim().replace(/[^a-zA-Z0-9 _-]/g, "").replace(/\s+/g, "_") ||
          "app") +
        "_" +
        versionEl.value.trim().replace(/\//g, "_") +
        ".apk";

      outputEl.textContent = safeName + "  (" + formatSize(blob.size) + ")";
      btnInstall.disabled = false;

      setStatus(
        "Build completed. Verify the APK and install it only if you trust its source.",
        100
      );
      showModal(
        "Build complete",
        "APK ready for download.\n\nSize: " +
          formatSize(blob.size) +
          "\n\nUse the Install / Open button or save the file. Only install APKs from sources you trust."
      );
    } catch (err) {
      setStatus("Build failed: " + err.message, 0);
      outputEl.textContent = "No APK built yet";
      showModal("Build failed", err.message);
    } finally {
      setBusy(false);
    }
  });

  // ---------- Install / Open ----------
  btnInstall.addEventListener("click", () => {
    if (!apkBlob || !apkUrl) {
      showModal("No APK available", "Build an APK successfully first.");
      return;
    }
    const a = document.createElement("a");
    a.href = apkUrl;
    a.download =
      (nameEl.value.trim().replace(/[^a-zA-Z0-9 _-]/g, "").replace(/\s+/g, "_") ||
        "app") +
      "_" +
      versionEl.value.trim().replace(/\//g, "_") +
      ".apk";
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

  // ---------- Help ----------
  btnHelp.addEventListener("click", () => {
    showModal(
      "Remote build API",
      "Your trusted HTTPS endpoint must accept multipart/form-data POST with fields:\n" +
        "• project_zip (ZIP file)\n" +
        "• app_name\n" +
        "• description\n" +
        "• version_name\n" +
        "• version_code\n" +
        "• package_id\n" +
        "• optional icon_png\n\n" +
        "If an API token is set, the request includes Authorization: Bearer TOKEN.\n\n" +
        "The service must return either:\n" +
        "• the APK bytes directly (application/vnd.android.package-archive), or\n" +
        "• JSON like {\"apk_url\":\"https://.../app.apk\"}\n\n" +
        "A JSON error field is shown to the user.\n\n" +
        "Only use a service you trust — uploading a ZIP sends its contents to that service."
    );
  });

  modalClose.addEventListener("click", hideModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) hideModal();
  });

  // ---------- Utils ----------
  function formatSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  }

  // Init
  loadConfig();
})();
