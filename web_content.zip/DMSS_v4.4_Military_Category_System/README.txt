DMSS v4.4 — Military Welcome & Category Navigation
==================================================

START
1. Extract this ZIP file.
2. Open index.html in a modern browser.
3. Sign in with your existing DMSS account.

NEW STRUCTURE
Login -> Welcome Popup (Bangla + English, Military style) -> Main Categories -> Subcategories -> Existing feature pages.

DEMO IMAGE REPLACEMENT
You can replace demo images directly inside the ZIP after extracting it. Keep the SAME filename, extension and folder path; no HTML editing is needed.

Category demo images (JPG):
- assets/images/money-management.jpg
- assets/images/kit-board.jpg
- assets/images/leave-management.jpg
- assets/images/report-center.jpg
- assets/images/data-management.jpg
- assets/images/profile-settings.jpg

Profile demo photo (JPG):
- assets/images/demo-photo.jpg

Welcome logo (PNG):
- assets/logo/dmss-demo-logo.png

For best results, use landscape images around 960 x 520 pixels for category images. The profile demo photo can be replaced with a square or portrait image. Keep the filenames unchanged.

NOTES
- Existing DMSS features and localStorage keys are retained.
- The app is designed for offline use after extraction.
- CSS and JavaScript remain embedded in index.html for compatibility; css/ and js/ are reserved for future modular upgrades.
- Export a fresh backup before replacing or upgrading the app. Keep the backup outside this folder.
- This app is not encrypted secure storage. Do not store sensitive, confidential, or operational military information here.
