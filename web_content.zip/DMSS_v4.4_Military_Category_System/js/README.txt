JavaScript is currently embedded in index.html to preserve the original offline app and its existing functions. This folder is reserved for future modular JS upgrades.
