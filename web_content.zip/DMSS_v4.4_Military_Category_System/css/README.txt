CSS styles are currently embedded in index.html to preserve the original offline app. This folder is reserved for future modular CSS upgrades.
