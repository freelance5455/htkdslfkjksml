# Android Release Build Environment

- Android Gradle Plugin: 8.7.3
- Gradle wrapper: 8.9
- Kotlin: 2.0.21
- compileSdk: 35
- targetSdk: 35
- minSdk: 26
- Java/JDK: 17+ compatible with the Android Gradle Plugin/toolchain
- Application ID: `com.getmoneymachine`
- Version: `1.0.0` / code `1`

The release signing configuration is supplied through Gradle project properties:
`RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, and `RELEASE_KEY_PASSWORD`.
Private signing material is not included in the source archive.

Build command:

```bash
./gradlew :app:assembleRelease
```

A networked environment with Android SDK platform 35/build-tools and the Gradle wrapper distribution must be available for the actual compilation. This source package does not fabricate an APK when that environment is unavailable.
