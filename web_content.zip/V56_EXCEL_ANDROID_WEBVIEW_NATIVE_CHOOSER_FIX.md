# V56 — Excel Android WebView Native Chooser Fix

Based on V55. The custom AndroidDPM picker bridge was removed from the user-facing Choose File action because it could silently stall on some TECNO/Android builds. Choose File is now a real HTML label/file input activated directly by the user. MainActivity already provides WebChromeClient.onShowFileChooser, so Android WebView launches its native document chooser and returns the selected URI through the standard callback. The existing Excel/CSV parser and import flow are unchanged.
