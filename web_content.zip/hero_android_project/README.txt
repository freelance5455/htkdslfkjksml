HERO TOURNAMENT Android app starter project

This is an Android Studio project, not a compiled APK yet. It packages the supplied HERO TOURNAMENT website into an Android WebView app, includes the supplied logo, and opens external links in the browser/apps.

Build APK:
1. On a computer, install Android Studio from https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose Open and select the extracted HERO-TOURNAMENT folder.
4. Allow Gradle sync and install any requested Android SDK Platform 35 components.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK is normally at app/build/outputs/apk/debug/app-debug.apk.

Note: This environment did not have the Android SDK/Gradle build setup, so it could not compile and verify an APK here. This project needs to be built using Android Studio before installation. The app's tournament registration still depends on the registration form/link configured in the website.
