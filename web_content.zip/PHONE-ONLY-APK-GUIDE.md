# CodeVerse APK build (phone-only workflow)

This ZIP has a GitHub Actions workflow that builds a debug APK in the cloud, so you do not need a PC.

## Important limitations
- This builds the web UI into an Android app. The existing Express/Gemini backend is separate and is not bundled into the APK. AI calls that use `/api/...` will not work in the installed app until the backend is deployed and the app is configured to call its HTTPS URL.
- Do not put Gemini API keys in frontend files or commit `.env` files.
- The workflow uses `npm install` because the original ZIP did not include a package-lock.json.

## Phone-only route (GitHub website)
1. Open github.com in your phone browser and sign in/create an account.
2. Create a new repository named `codeverse` (public or private).
3. Extract this ZIP using your phone's file manager/archive app.
4. On the repository page, use **Add file → Upload files** and upload the extracted project files/folders, including `.github/workflows/android-apk.yml`. Make sure hidden files are shown if needed. Do not upload `node_modules`, `dist`, `.env`, or API keys.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab and select **Build CodeVerse APK**. If the workflow did not start automatically, choose **Run workflow**.
7. Wait for the run to finish successfully. Open the completed run, scroll to **Artifacts**, and download `CodeVerse-debug-APK`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
8. Tap the APK and allow installation from your browser/files app if Android asks. Only install the APK you built from your own repository.

If uploading folders from mobile is too awkward, use GitHub's desktop website or a trusted Git client; the project files must be uploaded as files, not as one nested ZIP.
