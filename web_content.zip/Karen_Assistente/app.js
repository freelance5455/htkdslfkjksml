const $=id=>document.getElementById(id);
const chat=$("chat"), input=$("input"), mouth=$("mouth"), status=$("status"), thinking=$("thinking");
let current=[];
let preferredName=localStorage.getItem("karen_name")||"Peter";
let history=JSON.parse(localStorage.getItem("karen_history")||"[]");

function save(){ localStorage.setItem("karen_history",JSON.stringify(history)); }
function addMessage(text,who="karen",speak=false){
  const d=document.createElement("div"); d.className="msg "+who; d.textContent=text; chat.appendChild(d);
  chat.scrollTop=chat.scrollHeight; current.push({text,who,time:Date.now()});
  if(speak) say(text);
}
function persistCurrent(){
  if(!current.length)return;
  const id=history.length?history[history.length-1]:null;
  if(id && id.open){id.messages=current}else history.push({date:new Date().toLocaleString("pt-BR"),title:(current[0]?.text||"Conversa").slice(0,40),messages:current,open:true});
  save();
}
function say(text){
  if(!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang="pt-BR"; u.rate=.96; u.pitch=1.05;
  u.onstart=()=>mouth.classList.add("speaking");
  u.onend=()=>mouth.classList.remove("speaking");
  speechSynthesis.speak(u);
}
function answer(raw){
  const t=raw.trim(); const l=t.toLowerCase();
  if(!t)return;
  addMessage(t,"user");
  thinking.textContent="Karen está pensando...";
  let r;
  if(/\b(me chama|chame-me|pode me chamar|meu nome é)\b/.test(l)){
    const m=t.match(/(?:me chama|chame-me|pode me chamar|meu nome é)\s+(?:de\s+)?(.+)/i);
    if(m){preferredName=m[1].replace(/[.!?]+$/,"").trim(); localStorage.setItem("karen_name",preferredName);
      r=`Claro. A partir de agora vou chamar você de ${preferredName}.`;}
    else r=`Claro, ${preferredName}.`;
  } else if(/^(oi|olá|ola|hey|e aí|eai)\b/.test(l)){
    r=`Olá, ${preferredName}! Eu sou a Karen. Como posso ajudar você?`;
  } else if(/(quem é você|quem é vc|se apresente|se apresentar)/.test(l)){
    r=`Eu sou a Karen, sua assistente pessoal. Pode falar comigo por texto ou por voz.`;
  } else if(/(obrigad|valeu|brigad)/.test(l)){
    r=`De nada, ${preferredName}. Estou aqui.`;
  } else if(/(que horas|hora agora)/.test(l)){
    r=`Agora são ${new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}.`;
  } else if(/(teste|testando)/.test(l)){
    r=`Recebi perfeitamente, ${preferredName}. Estou pronta para o próximo comando.`;
  } else {
    r=`Entendi, ${preferredName}. Ainda estou na minha primeira versão, então essa parte de inteligência avançada será conectada na próxima etapa.`;
  }
  setTimeout(()=>{addMessage(r,"karen",true); thinking.textContent="Pronta para você, "+preferredName+"."; persistCurrent();},350);
}
$("sendBtn").onclick=()=>{answer(input.value);input.value=""};
input.addEventListener("keydown",e=>{if(e.key==="Enter"){$("sendBtn").click()}});
let recognition=null;
const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SpeechRecognition){
 recognition=new SpeechRecognition(); recognition.lang="pt-BR"; recognition.interimResults=false;
 recognition.onstart=()=>{$("micBtn").classList.add("listening");status.textContent="Estou ouvindo...";thinking.textContent="Karen está ouvindo...";}
 recognition.onend=()=>{$("micBtn").classList.remove("listening");status.textContent="Pronta para você, "+preferredName+".";thinking.textContent="Pronta para conversar."}
 recognition.onresult=e=>{input.value=e.results[0][0].transcript; answer(input.value); input.value=""}
 recognition.onerror=()=>{status.textContent="Não consegui ouvir. Tente novamente."}
}else $("micBtn").title="Seu navegador/WebView não oferece reconhecimento de voz";
$("micBtn").onclick=()=>{if(recognition){try{recognition.start()}catch(e){}}else alert("O reconhecimento de voz não está disponível nesta versão do WebView. O botão de voz será conectado à camada Android na próxima etapa.");};

function renderHistory(){
 const box=$("historyList");box.innerHTML="";
 if(!history.length){box.innerHTML='<p style="color:#8792a8">Nenhuma conversa salva ainda.</p>';return}
 [...history].reverse().forEach((h,idx)=>{
   const d=document.createElement("div");d.className="history-item";
   d.innerHTML=`<b>${h.title||"Conversa"}</b><br><small>${h.date||""}</small>`;
   d.onclick=()=>{chat.innerHTML="";current=[];(h.messages||[]).forEach(m=>addMessage(m.text,m.who,false));$("drawer").classList.add("hidden");}
   box.appendChild(d);
 });
}
$("historyBtn").onclick=()=>{$("drawer").classList.remove("hidden");renderHistory()};
$("closeHistory").onclick=()=>$("drawer").classList.add("hidden");
$("newChat").onclick=()=>{persistCurrent();chat.innerHTML="";current=[];$("drawer").classList.add("hidden");welcome()};
function welcome(){
 const text=`Olá, ${preferredName}! Eu sou a Karen.`;
 addMessage(text,"karen",true);
}
window.addEventListener("beforeunload",persistCurrent);
welcome();
