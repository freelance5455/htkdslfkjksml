KAREN — PRIMEIRA VERSÃO

O projeto foi preparado para ser convertido em APK pelo seu aplicativo "HTML to APK".

Incluído:
- Interface de conversa
- Campo para digitar
- Botão de microfone usando Speech Recognition quando o WebView/navegador oferecer suporte
- Voz da Karen usando Text-to-Speech do navegador/WebView
- Apresentação automática como Karen
- Nome padrão do usuário: Peter
- Alteração do apelido ("Karen, me chama de João")
- Histórico salvo automaticamente no armazenamento local
- Interface visual tecnológica
- Personagem feminina estilizada com cabelo claro e animação simples de boca durante a fala

IMPORTANTE:
Esta é a PRIMEIRA versão. A inteligência avançada por API e o controle de outros aplicativos Android (YouTube, Instagram etc.) ainda NÃO estão implementados. Essas partes exigem uma integração nativa/ponte Android e serão adicionadas nas próximas etapas.

A imagem em assets/karen_reference.png é apenas uma referência visual enviada durante o projeto; a interface usa uma personagem estilizada criada em HTML/CSS, não a foto como personagem.
