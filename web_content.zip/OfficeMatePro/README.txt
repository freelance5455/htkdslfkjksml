OFFICEMATE PRO - QUICK START

1. Extract the OfficeMatePro.zip file.
2. Open the OfficeMatePro folder.
3. Open index.html in Chrome, Edge, Firefox or another modern browser.
4. Use the sidebar to manage tasks, meetings, notes, document references and calculations.

OFFLINE SUPPORT
- The app works offline after the files are on the device because the app logic and styles are local.
- Google Fonts are optional; the app uses fallback fonts if there is no internet.
- Data is saved in the browser's localStorage on that device.

IMPORTANT DATA NOTES
- This first version stores data only in the browser on the device being used.
- Phone and computer do NOT automatically share data. Use Export backup on one device and Import backup on the other to transfer it.
- Do not enter passwords, confidential company information, customer financial details, or sensitive work data unless your father has permission to store it this way.
- Export backups regularly. Clearing browser data may erase locally saved records.
- The Document Register stores file names/locations only; it does not upload or store the actual documents.

To install as an app:
- For a simple local test, open index.html.
- For installable PWA behaviour, host the folder on an HTTPS static host or run it through a local development server. A service worker can be added in a later version for stronger offline caching.
