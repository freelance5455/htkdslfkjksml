(function() {
  console.log('Voice Activated!');
  
  let audioContext = null;
  let currentSettings = {
    gain: 1,
    bass: 0,
    treble: 0,
    echo: 0,
    loudness: 0
  };

  // Settings update listener
  window.addEventListener('message', (event) => {
    if (event.data.type === 'AUDIO_SETTINGS_UPDATE') {
      currentSettings = event.data.settings;
      console.log('Settings updated:', currentSettings);
    }
  });

  // Process audio stream
  function processAudioStream(originalStream) {
    try {
      // Create audio context if not exists
      if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
      }

      // Create source from original stream
      const source = audioContext.createMediaStreamSource(originalStream);
      
      // Create audio nodes
      const gainNode = audioContext.createGain();
      const bassEQ = audioContext.createBiquadFilter();
      const trebleEQ = audioContext.createBiquadFilter();
      const delayNode = audioContext.createDelay(5.0);
      const delayGain = audioContext.createGain();
      const masterGain = audioContext.createGain();
      
      // Configure Bass (Low Shelf)
      bassEQ.type = 'lowshelf';
      bassEQ.frequency.value = 200;
      bassEQ.gain.value = currentSettings.bass;
      
      // Configure Treble (High Shelf)
      trebleEQ.type = 'highshelf';
      trebleEQ.frequency.value = 3000;
      trebleEQ.gain.value = currentSettings.treble;
      
      // Configure Delay (Echo)
      delayNode.delayTime.value = 0.3;
      delayGain.gain.value = currentSettings.echo;
      
      // Main gain (NO COMPRESSOR - RAW LOUDNESS)
      gainNode.gain.value = currentSettings.gain * (1 + (currentSettings.loudness / 10));
      masterGain.gain.value = 1.0;
      
      // Connect nodes: source -> gain -> bass -> treble -> master (NO COMPRESSOR)
      source.connect(gainNode);
      gainNode.connect(bassEQ);
      bassEQ.connect(trebleEQ);
      trebleEQ.connect(masterGain);
      
      // Echo chain
      trebleEQ.connect(delayNode);
      delayNode.connect(delayGain);
      delayGain.connect(delayNode); // feedback
      delayGain.connect(masterGain);
      
      // Create destination
      const destination = audioContext.createMediaStreamDestination();
      masterGain.connect(destination);
      
      // Update settings dynamically
      const updateInterval = setInterval(() => {
        gainNode.gain.value = currentSettings.gain * (1 + (currentSettings.loudness / 10));
        bassEQ.gain.value = currentSettings.bass;
        trebleEQ.gain.value = currentSettings.treble;
        delayGain.gain.value = currentSettings.echo;
      }, 100);
      
      // Add video tracks if present
      const processedStream = destination.stream;
      originalStream.getVideoTracks().forEach(track => {
        processedStream.addTrack(track);
      });
      
      console.log('✅ Audio processing active!');
      window.postMessage({ type: 'AUDIO_STATUS', status: 'active' }, '*');
      
      return processedStream;
      
    } catch (error) {
      console.error('❌ Audio processing error:', error);
      return originalStream;
    }
  }

  // Override getUserMedia
  const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  
  navigator.mediaDevices.getUserMedia = async function(constraints) {
    console.log('📞 getUserMedia called:', constraints);
    
    const stream = await originalGetUserMedia(constraints);
    
    // Only process if audio is requested
    if (constraints && constraints.audio) {
      console.log('🎤 Processing audio stream...');
      return processAudioStream(stream);
    }
    
    return stream;
  };

  // Also override the legacy API
  if (navigator.getUserMedia) {
    const legacyGetUserMedia = navigator.getUserMedia.bind(navigator);
    navigator.getUserMedia = function(constraints, successCallback, errorCallback) {
      legacyGetUserMedia(constraints, (stream) => {
        if (constraints && constraints.audio) {
          successCallback(processAudioStream(stream));
        } else {
          successCallback(stream);
        }
      }, errorCallback);
    };
  }

  console.log('Voice Ready!');
})();