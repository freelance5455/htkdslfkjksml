const sliders = ['gain', 'bass', 'treble', 'echo', 'loudness'];

// Load saved settings
chrome.storage.local.get(sliders, (result) => {
  sliders.forEach(slider => {
    if (result[slider] !== undefined) {
      document.getElementById(slider).value = result[slider];
      document.getElementById(slider + 'Value').textContent = result[slider];
    }
  });
  sendSettings();
});

// Update on slider change
sliders.forEach(slider => {
  const input = document.getElementById(slider);
  const valueDisplay = document.getElementById(slider + 'Value');
  
  input.addEventListener('input', (e) => {
    const value = parseFloat(e.target.value);
    valueDisplay.textContent = value.toFixed(1);
    
    // Save to storage
    chrome.storage.local.set({ [slider]: value });
    
    sendSettings();
  });
});

// Reset button
document.getElementById('resetBtn').addEventListener('click', () => {
  const defaults = { gain: 1, bass: 0, treble: 0, echo: 0, loudness: 0 };
  
  Object.keys(defaults).forEach(slider => {
    document.getElementById(slider).value = defaults[slider];
    document.getElementById(slider + 'Value').textContent = defaults[slider];
  });
  
  chrome.storage.local.set(defaults);
  sendSettings();
});

// Send settings to content script
function sendSettings() {
  const settings = {
    gain: parseFloat(document.getElementById('gain').value),
    bass: parseFloat(document.getElementById('bass').value),
    treble: parseFloat(document.getElementById('treble').value),
    echo: parseFloat(document.getElementById('echo').value),
    loudness: parseFloat(document.getElementById('loudness').value)
  };
  
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: 'UPDATE_AUDIO_SETTINGS',
      settings: settings
    });
  });
}