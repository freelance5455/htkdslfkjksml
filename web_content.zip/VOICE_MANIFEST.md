# Voice Assets

The prototype includes real local audio files under `public/game/voice/`.

The runtime maps these files to Arden, Seraphine, Rook, Mira, Vale, Nyx, Sera, Kade, Astra, Orin, Lena, Cael, the Father, and demon/enemy voices.

The files are short voice samples used as character voice cues rather than full recorded dialogue for every line.

All 29 voice filenames referenced by the runtime are present in the ZIP.
