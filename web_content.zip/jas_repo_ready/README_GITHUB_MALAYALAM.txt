JAS Laundry Room - GitHub APK Build Package

IMPORTANT: GitHub does not unpack a ZIP file when you upload it to a repository.
You must extract this ZIP on your phone and upload the CONTENTS to the repository.

This ZIP contains the Android project at its root and the build workflow at:
.github/workflows/build-apk.yml

After all contents are committed to the repository's main branch:
1. Open the repository on GitHub.
2. Tap Actions.
3. Open the latest 'Build JAS Laundry Room APK' run.
4. Wait for a green check mark.
5. Download artifact 'JAS-Laundry-Room-debug-APK'.
6. Extract the artifact ZIP and install app-debug.apk.

No APK build or physical-device feature test has been completed here. A successful cloud build does not by itself verify WhatsApp Business sharing, Gallery saving, Bluetooth printing, or reminders on your phone.
