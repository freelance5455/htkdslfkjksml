# Carreira de Craque v1.47.5

- Corrigido o padrão da camisa titular do Flamengo na prévia SVG: faixas horizontais rubro-negras largas, seguindo a referência enviada pelo usuário.
- A alteração fica no padrão compartilhado `flamengo-home` do catálogo de camisas, então vale tanto para a carreira profissional quanto para a carreira Sub-20.
- Cache do PWA atualizado para v1.47.5.
