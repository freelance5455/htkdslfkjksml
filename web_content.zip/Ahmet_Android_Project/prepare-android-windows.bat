@echo off
echo Ahmet Android projesi hazirlaniyor...
npm install
if errorlevel 1 exit /b 1
if not exist android (
  npx cap add android
  if errorlevel 1 exit /b 1
)
npx cap sync android
if errorlevel 1 exit /b 1
echo Tamamlandi. Android Studio icin: npx cap open android
pause
