# Ahmet Android APK Projesi

Bu proje, Ahmet platformunun web arayüzünü Android uygulama kabuğuna dönüştürmek için Capacitor kullanır. Bu arşiv Android APK dosyasının kendisi değil, APK üretmek için kaynak proje ve adımlarıdır.

## Gerekenler
- Node.js LTS ve npm
- Android Studio (Android SDK dahil)
- Android Studio'nun kurulum ekranından güncel Android SDK Platform ve Build Tools
- Java: Android Studio'nun gömülü JDK'si önerilir

## 1) Projeyi hazırlama
ZIP dosyasını bilgisayarında çıkar. Terminali/Komut İstemi'ni `Ahmet_Android_Project` klasöründe aç ve çalıştır:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

`npx cap add android` komutunu aynı Android klasörü zaten oluşturulmuşsa tekrar çalıştırma; bu durumda `npx cap sync android` kullan.

## 2) Android Studio'dan APK üretme
1. Android Studio açılınca Gradle senkronizasyonunun bitmesini bekle.
2. Gerekirse Android SDK kurulumu uyarılarını tamamla.
3. Menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
4. İşlem bittiğinde APK konumu genellikle `android/app/build/outputs/apk/debug/app-debug.apk` olur.
5. APK'yı Android telefona aktar ve yükle. Telefonda yalnızca güvendiğin kaynaklardan gelen APK'ları yükle; cihaz kurulum sırasında izin isteyebilir.

## 3) Terminalden debug APK
Windows:
```bat
cd android
gradlew.bat assembleDebug
```
macOS/Linux:
```bash
cd android
./gradlew assembleDebug
```
Çıktı genellikle `android/app/build/outputs/apk/debug/app-debug.apk` konumundadır.

## 4) Uygulama güncelleme
`www` içindeki HTML/CSS/JS dosyalarını değiştirdikten sonra:
```bash
npx cap sync android
```
Ardından Android Studio'dan yeniden APK üret.

## Önemli
- Debug APK test içindir. Play Store veya dağıtım için imzalı release APK/AAB, uygulama ikonu, gizlilik politikası ve mağaza gereksinimleri ayrıca hazırlanmalıdır.
- AhmetTube kartları örnek içerik kullanır; gerçek video akışı ve yükleme için video servisi/API gerekir.
- Ahmet Store gerçek satış/ödeme yapmaz; ürün listesi prototipidir.
- Ahmet Yapay Zekâ arayüzü gerçek bir AI servisine bağlı değildir.
- Ahmet Harita aramaları OpenStreetMap web sayfasını açar; gömülü harita ve konum izinleri ayrıca geliştirilebilir.
- Bu projede gerçek kullanıcı hesabı, ödeme altyapısı veya özel sunucu bulunmaz.
