#!/usr/bin/env bash
set -e
npm install
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
echo "Hazır. Android Studio için: npx cap open android"
