Education Basics: School Escape — HTML prototype

Open index.html in a modern browser. Keyboard: arrows or WASD. On touch screens use the arrow pad. Collect 7 notebooks and reach the exit while avoiding the teacher.

This is a playable browser prototype inspired by the uploaded Unity IPA structure and school-game concept. It is not a direct conversion of the original Unity game: the IPA’s embedded .assets/.ress resources have not yet been decoded, so original 3D models, textures, and audio are not included. Sound effects are synthesized by the browser.
