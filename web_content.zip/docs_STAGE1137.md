# CPLS V2 — Stage 1137

## Candle Gap Detection
- Detects missing time intervals between generated candles without fabricating candles.
- Reports the number of detected data gaps during chart refresh.
- Preserves live OHLC, merge, boundary, zoom and continuity behavior.
- No guessed LBank Futures WebSocket subscription was introduced.

Source ZIP stage only; APK build not performed.
