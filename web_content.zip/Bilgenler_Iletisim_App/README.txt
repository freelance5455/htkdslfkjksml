BILGENLER ILETISIM - SERVIS & KASA

Bu paket, telefoncu işletmesi için mobil uyumlu web uygulaması/PWA kaynak kodudur.
İçerik: servis kayıtları, cihaz alım kayıtları, emanet aksesuar kontrolü, kasa giriş/çıkışları,
ciro özeti, al-sat cihazları ve CSV dışa aktarma.

ÖNEMLİ
- Şu an Firebase bilgileri doldurulmadığı için yerel kayıt modunda açılır. Yerel kayıtlar yalnızca o tarayıcı/cihazdadır.
- Birden fazla cihazda aynı verileri görmek için Firebase kurulumunu tamamlayın.
- APK dosyası bu kaynak paketin içinde henüz derlenmiş değildir. Önce Firebase ve HTTPS barındırma, sonra PWA2APK/Android paketleme gerekir.

FIREBASE KURULUMU (Google ile giriş + ortak bulut verisi)
1) https://console.firebase.google.com adresinden proje oluşturun.
2) Authentication > Sign-in method bölümünden Google sağlayıcısını etkinleştirin.
3) Firestore Database oluşturun.
4) Firestore Rules bölümüne bu paketteki firestore.rules içeriğini yapıştırıp yayınlayın.
5) Project settings > General > Your apps > Web app ile web uygulaması ekleyin.
6) Firebase'in verdiği yapılandırma bilgilerini firebase-config.js dosyasına yazın.
7) Uygulamayı HTTPS destekleyen bir sunucuya yükleyin (ör. Firebase Hosting).
8) Authentication > Settings > Authorized domains kısmında yayın alan adınızın bulunduğunu kontrol edin.
9) Aynı Google hesabıyla tüm telefon ve tabletlerde giriş yapın. Veriler Firestore üzerinden eşitlenir.

APK
Bu proje önce web uygulaması olarak yayınlanır. Ardından HTTPS adresi PWABuilder gibi bir PWA paketleyiciyle Android APK/AAB'ye dönüştürülebilir. Google girişinin paketlenmiş uygulamada çalışması için Firebase yetkili alan adı ve OAuth ayarları ayrıca test edilmelidir.

KASA HESABI
- Ana ekrandaki kasa bakiyesi nakit girişler eksi nakit çıkışlar olarak hesaplanır.
- Kart ve havale/EFT hareketleri ayrı kaydedilir, nakit kasasına eklenmez.
- Günlük ciro, kasa hareketlerindeki bugünkü gelir toplamıdır.
- Vergi/muhasebe amaçlı resmi kayıt sistemi yerine geçmez. Düzenli yedek alın.

GÜVENLİK NOTU
Firebase yapılandırmasındaki web apiKey gizli anahtar değildir; güvenlik Firestore Rules ve Google Authentication ile sağlanır.
Cihaz kilidi kullanın, Google hesabınızın şifresini paylaşmayın ve çalışanlar için ayrı kullanıcı yetkilendirmesi eklenmeden ortak hesabı paylaşmayın.
