// Firebase Console > Project settings > Your apps > Web app config
// Aşağıdaki alanları kendi Firebase projenizin bilgileriyle doldurun.
export const firebaseConfig = {
  apiKey: "BURAYA_API_KEY",
  authDomain: "BURAYA.firebaseapp.com",
  projectId: "BURAYA_PROJECT_ID",
  storageBucket: "BURAYA.appspot.com",
  messagingSenderId: "BURAYA_SENDER_ID",
  appId: "BURAYA_APP_ID"
};
