ХВОСТИКИ — проєкт Android-застосунку

Це вихідний проєкт для відкриття в Android Studio. Він містить HTML-версію застосунку в assets та Android WebView-оболонку.

Як отримати APK:
1. Встанови Android Studio на комп'ютер.
2. Відкрий папку KhvostykyAndroid як проєкт.
3. Дочекайся синхронізації Gradle.
4. Обери Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK зазвичай з'явиться в app/build/outputs/apk/debug/app-debug.apk.

У цьому середовищі немає Android SDK/Gradle, тому готовий APK тут не зібрано. Цей архів — саме проєкт для збирання, а не готовий APK.
