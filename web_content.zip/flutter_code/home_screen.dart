import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

// ============================================================================
// 1. FINTECH COLOR SYSTEM & TOKENS (Material 3)
// ============================================================================
class PoketSafeColors {
  static const Color primaryBlue = Color(0xFF1E3A8A); // Deep Navy Structure
  static const Color accentGreen = Color(0xFF22C55E); // Safe Balance & Surplus
  static const Color alertRed = Color(0xFFEF4444);    // Debit & Warning
  static const Color warningAmber = Color(0xFFF59E0B);
  static const Color healthBlue = Color(0xFF3B82F6);

  static const Color background = Color(0xFF020617);
  static const Color surface = Color(0xFF0F172A);
  static const Color surfaceHighlight = Color(0xFF1E293B);
  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textMuted = Color(0xFF94A3B8);
}

// ============================================================================
// 2. DOMAIN MODELS & ENUMS
// ============================================================================
enum HealthStatusTier { thriving, stable, caution, critical }

class AvailableMoneyData {
  final double safeBalance;
  final double dailySafeCap;
  final int daysUntilInflow;
  final String fundingSource;

  const AvailableMoneyData({
    required this.safeBalance,
    required this.dailySafeCap,
    required this.daysUntilInflow,
    required this.fundingSource,
  });
}

class FinancialHealthData {
  final int score; // 0 - 100
  final HealthStatusTier tier;
  final int runwayDays;
  final int daysUntilInflow;
  final String diagnosis;

  const FinancialHealthData({
    required this.score,
    required this.tier,
    required this.runwayDays,
    required this.daysUntilInflow,
    required this.diagnosis,
  });

  bool get hasDeficitGap => runwayDays < daysUntilInflow;
  int get gapDays => math.max(0, daysUntilInflow - runwayDays);
}

class UpcomingPaymentItem {
  final String id;
  final String title;
  final double amount;
  final DateTime dueDate;
  final bool isPaid;
  final String category; // 'hostel', 'wifi', 'debt', etc.

  const UpcomingPaymentItem({
    required this.id,
    required this.title,
    required this.amount,
    required this.dueDate,
    this.isPaid = false,
    required this.category,
  });
}

enum TransactionCategory { food, transport, campus, groceries, social, other }

class RecentTransactionItem {
  final String id;
  final String title;
  final double amount;
  final TransactionCategory category;
  final DateTime timestamp;

  const RecentTransactionItem({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.timestamp,
  });
}

// Combined View State for Home Screen
class HomeScreenState {
  final AvailableMoneyData availableMoney;
  final FinancialHealthData financialHealth;
  final List<UpcomingPaymentItem> upcomingPayments;
  final List<RecentTransactionItem> recentTransactions;
  final bool isLoading;

  const HomeScreenState({
    required this.availableMoney,
    required this.financialHealth,
    required this.upcomingPayments,
    required this.recentTransactions,
    this.isLoading = false,
  });
}

// ============================================================================
// 3. RIVERPOD STATE NOTIFIER
// ============================================================================
class HomeScreenNotifier extends StateNotifier<AsyncValue<HomeScreenState>> {
  HomeScreenNotifier() : super(const AsyncValue.loading()) {
    loadHomeData();
  }

  Future<void> loadHomeData() async {
    // Simulate real-time fetch or stream initialization
    await Future.delayed(const Duration(milliseconds: 350));

    state = AsyncValue.data(
      HomeScreenState(
        availableMoney: const AvailableMoneyData(
          safeBalance: 2415.00,
          dailySafeCap: 35.51,
          daysUntilInflow: 68,
          fundingSource: 'PTPTN Semester Loan',
        ),
        financialHealth: const FinancialHealthData(
          score: 78,
          tier: HealthStatusTier.stable,
          runwayDays: 74,
          daysUntilInflow: 68,
          diagnosis: 'Physical runway safely covers semester days at standard cafeteria burn.',
        ),
        upcomingPayments: [
          UpcomingPaymentItem(
            id: 'pay_1',
            title: 'Campus Hostel Room 304',
            amount: 450.00,
            dueDate: DateTime.now().add(const Duration(days: 4)),
            category: 'hostel',
          ),
          UpcomingPaymentItem(
            id: 'pay_2',
            title: 'Celcom 5G Student Plan',
            amount: 38.00,
            dueDate: DateTime.now().add(const Duration(days: 12)),
            category: 'wifi',
          ),
        ],
        recentTransactions: [
          RecentTransactionItem(
            id: 'tx_1',
            title: 'Nasi Kandar lunch + Teh O Ais',
            amount: 11.50,
            category: TransactionCategory.food,
            timestamp: DateTime.now().subtract(const Duration(hours: 2)),
          ),
          RecentTransactionItem(
            id: 'tx_2',
            title: 'Campus Shuttle Semester Card',
            amount: 15.00,
            category: TransactionCategory.transport,
            timestamp: DateTime.now().subtract(const Duration(days: 1)),
          ),
          RecentTransactionItem(
            id: 'tx_3',
            title: 'Photocopy Past Year Papers',
            amount: 6.00,
            category: TransactionCategory.campus,
            timestamp: DateTime.now().subtract(const Duration(days: 2)),
          ),
        ],
      ),
    );
  }

  void togglePaymentPaid(String id) {
    state.whenData((current) {
      final updatedList = current.upcomingPayments.map((item) {
        if (item.id == id) {
          return UpcomingPaymentItem(
            id: item.id,
            title: item.title,
            amount: item.amount,
            dueDate: item.dueDate,
            isPaid: !item.isPaid,
            category: item.category,
          );
        }
        return item;
      }).toList();

      state = AsyncValue.data(
        HomeScreenState(
          availableMoney: current.availableMoney,
          financialHealth: current.financialHealth,
          upcomingPayments: updatedList,
          recentTransactions: current.recentTransactions,
        ),
      );
    });
  }
}

final homeScreenProvider =
    StateNotifierProvider<HomeScreenNotifier, AsyncValue<HomeScreenState>>((ref) {
  return HomeScreenNotifier();
});

// ============================================================================
// 4. MAIN POKETSAFE HOME SCREEN (Material 3 + Responsive)
// ============================================================================
class PoketSafeHomeScreen extends ConsumerWidget {
  const PoketSafeHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final homeStateAsync = ref.watch(homeScreenProvider);
    final currencyFormat = NumberFormat.currency(symbol: 'RM ', decimalDigits: 2);

    return Scaffold(
      backgroundColor: PoketSafeColors.background,
      appBar: _buildAppBar(context),
      body: SafeArea(
        child: homeStateAsync.when(
          loading: () => const _HomeScreenLoadingSkeleton(),
          error: (err, stack) => Center(
            child: Text(
              'Error loading finances: $err',
              style: const TextStyle(color: PoketSafeColors.alertRed),
            ),
          ),
          data: (state) {
            return LayoutBuilder(
              builder: (context, constraints) {
                final isTabletOrDesktop = constraints.maxWidth >= 768;

                return Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1040),
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                      child: isTabletOrDesktop
                          ? _buildWideTwoColumnLayout(context, ref, state, currencyFormat)
                          : _buildMobileSingleColumnLayout(context, ref, state, currencyFormat),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: PoketSafeColors.background,
      elevation: 0,
      scrolledUnderElevation: 0,
      title: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [PoketSafeColors.primaryBlue, PoketSafeColors.accentGreen],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Center(
              child: Text(
                'P',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'PoketSafe',
                style: TextStyle(
                  color: PoketSafeColors.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  letterSpacing: -0.4,
                ),
              ),
              Text(
                'PTPTN Recipient · 68d runway',
                style: TextStyle(
                  color: PoketSafeColors.textMuted,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Mobile Layout: Clean vertical flow
  Widget _buildMobileSingleColumnLayout(
    BuildContext context,
    WidgetRef ref,
    HomeScreenState state,
    NumberFormat currencyFormat,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        AvailableMoneyCard(
          data: state.availableMoney,
          currencyFormat: currencyFormat,
        ),
        const SizedBox(height: 14),
        FinancialHealthCard(
          data: state.financialHealth,
        ),
        const SizedBox(height: 20),
        UpcomingPaymentsSection(
          payments: state.upcomingPayments,
          currencyFormat: currencyFormat,
          onTogglePayment: (id) => ref.read(homeScreenProvider.notifier).togglePaymentPaid(id),
        ),
        const SizedBox(height: 20),
        RecentTransactionsSection(
          transactions: state.recentTransactions,
          currencyFormat: currencyFormat,
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // Tablet/Desktop Layout: 2-Column Split
  Widget _buildWideTwoColumnLayout(
    BuildContext context,
    WidgetRef ref,
    HomeScreenState state,
    NumberFormat currencyFormat,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 5,
          child: Column(
            children: [
              AvailableMoneyCard(
                data: state.availableMoney,
                currencyFormat: currencyFormat,
              ),
              const SizedBox(height: 16),
              FinancialHealthCard(
                data: state.financialHealth,
              ),
            ],
          ),
        ),
        const SizedBox(width: 20),
        Expanded(
          flex: 5,
          child: Column(
            children: [
              UpcomingPaymentsSection(
                payments: state.upcomingPayments,
                currencyFormat: currencyFormat,
                onTogglePayment: (id) => ref.read(homeScreenProvider.notifier).togglePaymentPaid(id),
              ),
              const SizedBox(height: 16),
              RecentTransactionsSection(
                transactions: state.recentTransactions,
                currencyFormat: currencyFormat,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ============================================================================
// 5. REUSABLE SECTION 1: AVAILABLE MONEY CARD
// ============================================================================
class AvailableMoneyCard extends StatelessWidget {
  final AvailableMoneyData data;
  final NumberFormat currencyFormat;

  const AvailableMoneyCard({
    super.key,
    required this.data,
    required this.currencyFormat,
  });

  @override
  Widget build(BuildContext context) {
    final isDeficit = data.safeBalance <= 0;

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            PoketSafeColors.primaryBlue,
            Color(0xFF0F2461),
            PoketSafeColors.background,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: PoketSafeColors.primaryBlue.withOpacity(0.6), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: PoketSafeColors.primaryBlue.withOpacity(0.25),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.between,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: PoketSafeColors.accentGreen.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.shield_outlined,
                      color: PoketSafeColors.accentGreen,
                      size: 15,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'AVAILABLE TO SPEND',
                    style: TextStyle(
                      color: PoketSafeColors.textMuted,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.black45,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white12),
                ),
                child: Text(
                  '${data.daysUntilInflow}d left',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            currencyFormat.format(data.safeBalance),
            style: TextStyle(
              color: isDeficit ? PoketSafeColors.alertRed : PoketSafeColors.accentGreen,
              fontSize: 38,
              fontWeight: FontWeight.w900,
              fontFamily: 'monospace',
              letterSpacing: -1,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Protected after ring-fencing rent, bills & peer debts.',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.black26,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.between,
              children: [
                Row(
                  children: [
                    const Icon(Icons.calendar_today_outlined, size: 14, color: PoketSafeColors.textMuted),
                    const SizedBox(width: 6),
                    const Text('Daily Safe Limit:', style: TextStyle(color: PoketSafeColors.textMuted, fontSize: 12)),
                  ],
                ),
                Text(
                  '${currencyFormat.format(data.dailySafeCap)} / day',
                  style: const TextStyle(
                    color: PoketSafeColors.accentGreen,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// 6. REUSABLE SECTION 2: FINANCIAL HEALTH CARD (Survival Dial)
// ============================================================================
class FinancialHealthCard extends StatelessWidget {
  final FinancialHealthData data;

  const FinancialHealthCard({super.key, required this.data});

  Color _getTierColor(HealthStatusTier tier) {
    switch (tier) {
      case HealthStatusTier.thriving:
        return PoketSafeColors.accentGreen;
      case HealthStatusTier.stable:
        return PoketSafeColors.healthBlue;
      case HealthStatusTier.caution:
        return PoketSafeColors.warningAmber;
      case HealthStatusTier.critical:
        return PoketSafeColors.alertRed;
    }
  }

  String _getTierLabel(HealthStatusTier tier) {
    switch (tier) {
      case HealthStatusTier.thriving:
        return 'Thriving Runway';
      case HealthStatusTier.stable:
        return 'Stable Runway';
      case HealthStatusTier.caution:
        return 'Caution: High Burn';
      case HealthStatusTier.critical:
        return 'Critical Mode';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tierColor = _getTierColor(data.tier);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PoketSafeColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tierColor.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          // Radial Dial Gauge
          SizedBox(
            width: 80,
            height: 80,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                  size: const Size(80, 80),
                  painter: _RadialScorePainter(
                    score: data.score,
                    strokeColor: tierColor,
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${data.score}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'monospace',
                      ),
                    ),
                    const Text(
                      '/ 100',
                      style: TextStyle(
                        color: PoketSafeColors.textMuted,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          // Health Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: tierColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _getTierLabel(data.tier),
                        style: TextStyle(
                          color: tierColor,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Text(
                      '${data.runwayDays}d runway',
                      style: const TextStyle(
                        color: PoketSafeColors.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  data.diagnosis,
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RadialScorePainter extends CustomPainter {
  final int score;
  final Color strokeColor;

  _RadialScorePainter({required this.score, required this.strokeColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 5;

    final bgPaint = Paint()
      ..color = PoketSafeColors.primaryBlue.withOpacity(0.25)
      ..strokeWidth = 6.5
      ..style = PaintingStyle.stroke;

    final activePaint = Paint()
      ..color = strokeColor
      ..strokeWidth = 6.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, bgPaint);

    const startAngle = -math.pi / 2;
    final sweepAngle = (2 * math.pi) * (score / 100);

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepAngle,
      false,
      activePaint,
    );
  }

  @override
  bool shouldRepaint(covariant _RadialScorePainter oldDelegate) =>
      oldDelegate.score != score || oldDelegate.strokeColor != strokeColor;
}

// ============================================================================
// 7. REUSABLE SECTION 3: UPCOMING PAYMENTS MODULE
// ============================================================================
class UpcomingPaymentsSection extends StatelessWidget {
  final List<UpcomingPaymentItem> payments;
  final NumberFormat currencyFormat;
  final Function(String id) onTogglePayment;

  const UpcomingPaymentsSection({
    super.key,
    required this.payments,
    required this.currencyFormat,
    required this.onTogglePayment,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PoketSafeColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: PoketSafeColors.surfaceHighlight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.between,
            children: [
              const Text(
                'Upcoming Payments',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              ),
              Text(
                '${payments.where((p) => !p.isPaid).length} reserved',
                style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (payments.isEmpty)
            _buildEmptyPayments()
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: payments.length,
              separatorBuilder: (context, index) => const Divider(color: Colors.white10, height: 16),
              itemBuilder: (context, index) {
                final item = payments[index];
                final dueInDays = item.dueDate.difference(DateTime.now()).inDays;

                return Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: item.isPaid ? PoketSafeColors.accentGreen : PoketSafeColors.alertRed,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            style: TextStyle(
                              color: item.isPaid ? PoketSafeColors.textMuted : Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              decoration: item.isPaid ? TextDecoration.lineThrough : null,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            item.isPaid ? 'Settled this cycle' : 'Due in $dueInDays days (${DateFormat('MMM d').format(item.dueDate)})',
                            style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          currencyFormat.format(item.amount),
                          style: TextStyle(
                            color: item.isPaid ? PoketSafeColors.textMuted : Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                          ),
                        ),
                        InkWell(
                          onTap: () => onTogglePayment(item.id),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 2.0),
                            child: Text(
                              item.isPaid ? 'Undo' : 'Mark Paid',
                              style: const TextStyle(color: PoketSafeColors.healthBlue, fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyPayments() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Center(
        child: Text(
          'No scheduled bills or debts. All cash is available to spend.',
          style: TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
        ),
      ),
    );
  }
}

// ============================================================================
// 8. REUSABLE SECTION 4: RECENT TRANSACTIONS FEED
// ============================================================================
class RecentTransactionsSection extends StatelessWidget {
  final List<RecentTransactionItem> transactions;
  final NumberFormat currencyFormat;

  const RecentTransactionsSection({
    super.key,
    required this.transactions,
    required this.currencyFormat,
  });

  IconData _getCategoryIcon(TransactionCategory category) {
    switch (category) {
      case TransactionCategory.food:
        return Icons.restaurant_outlined;
      case TransactionCategory.transport:
        return Icons.directions_bus_outlined;
      case TransactionCategory.campus:
        return Icons.school_outlined;
      case TransactionCategory.groceries:
        return Icons.shopping_cart_outlined;
      case TransactionCategory.social:
        return Icons.celebration_outlined;
      case TransactionCategory.other:
        return Icons.more_horiz_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PoketSafeColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: PoketSafeColors.surfaceHighlight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.between,
            children: [
              const Text(
                'Recent Transactions',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              ),
              Text(
                '${transactions.length} items',
                style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (transactions.isEmpty)
            _buildEmptyTransactions()
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: transactions.length,
              separatorBuilder: (context, index) => const Divider(color: Colors.white10, height: 16),
              itemBuilder: (context, index) {
                final tx = transactions[index];
                final dateStr = DateFormat('MMM d, h:mm a').format(tx.timestamp);

                return Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.04),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Icon(
                        _getCategoryIcon(tx.category),
                        color: Colors.white70,
                        size: 17,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            tx.title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            dateStr,
                            style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '-${currencyFormat.format(tx.amount)}',
                      style: const TextStyle(
                        color: PoketSafeColors.alertRed,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyTransactions() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Center(
        child: Text(
          'No expenses recorded yet today. Keep daily burn low!',
          style: TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
        ),
      ),
    );
  }
}

// ============================================================================
// 9. LOADING SKELETON (Anti-CLS)
// ============================================================================
class _HomeScreenLoadingSkeleton extends StatelessWidget {
  const _HomeScreenLoadingSkeleton();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Container(
            height: 160,
            decoration: BoxDecoration(
              color: PoketSafeColors.surface,
              borderRadius: BorderRadius.circular(24),
            ),
          ),
          const SizedBox(height: 14),
          Container(
            height: 90,
            decoration: BoxDecoration(
              color: PoketSafeColors.surface,
              borderRadius: BorderRadius.circular(20),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            height: 120,
            decoration: BoxDecoration(
              color: PoketSafeColors.surface,
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        ],
      ),
    );
  }
}
