import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

// ============================================================================
// 1. FINTECH COLOR SYSTEM & TOKENS (Material 3)
// ============================================================================
class PoketSafeColors {
  static const Color primaryBlue = Color(0xFF1E3A8A); // Deep Navy Structure
  static const Color accentGreen = Color(0xFF22C55E); // Safe Balance / Primary CTA
  static const Color alertRed = Color(0xFFEF4444);    // Debit / Validation
  static const Color warningAmber = Color(0xFFF59E0B);

  static const Color background = Color(0xFF020617);
  static const Color surface = Color(0xFF0F172A);
  static const Color surfaceBorder = Color(0xFF1E293B);
  static const Color inputBackground = Color(0xFF1E293B);
  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textMuted = Color(0xFF94A3B8);
}

// ============================================================================
// 2. PAYMENT CATEGORY ENUM & PRESETS
// ============================================================================
enum PaymentCategory {
  bnpl('BNPL & Installments', Icons.credit_score_outlined),
  housing('Room / Hostel Rent', Icons.home_work_outlined),
  utilities('Mobile & Internet', Icons.wifi_tethering_outlined),
  tuition('Education & Lab', Icons.school_outlined),
  debt('Peer IOU', Icons.handshake_outlined),
  subscription('Subscriptions', Icons.subscriptions_outlined);

  final String label;
  final IconData icon;
  const PaymentCategory(this.label, this.icon);
}

// Preset shortcuts popular among Malaysian/Southeast Asian students
class PaymentPreset {
  final String name;
  final double? amount;
  final PaymentCategory category;

  const PaymentPreset(this.name, this.category, [this.amount]);
}

const List<PaymentPreset> kPopularStudentPresets = [
  PaymentPreset('SPayLater', PaymentCategory.bnpl, 100.0),
  PaymentPreset('Campus Hostel', PaymentCategory.housing, 450.0),
  PaymentPreset('Celcom / Digi 5G', PaymentCategory.utilities, 38.0),
  PaymentPreset('Roommate Dinner IOU', PaymentCategory.debt, 35.0),
];

// ============================================================================
// 3. ADD UPCOMING PAYMENT SCREEN (Material 3)
// ============================================================================
class AddUpcomingPaymentScreen extends StatefulWidget {
  final Function(Map<String, dynamic> paymentData)? onPaymentSaved;

  const AddUpcomingPaymentScreen({super.key, this.onPaymentSaved});

  @override
  State<AddUpcomingPaymentScreen> createState() => _AddUpcomingPaymentScreenState();
}

class _AddUpcomingPaymentScreenState extends State<AddUpcomingPaymentScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController(text: 'SPayLater');
  final TextEditingController _amountController = TextEditingController(text: '100');
  
  DateTime _selectedDueDate = DateTime.now().add(const Duration(days: 7));
  PaymentCategory _selectedCategory = PaymentCategory.bnpl;
  bool _isSubmitting = false;

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _applyPreset(PaymentPreset preset) {
    HapticFeedback.lightImpact();
    setState(() {
      _nameController.text = preset.name;
      if (preset.amount != null) {
        _amountController.text = preset.amount!.toStringAsFixed(0);
      }
      _selectedCategory = preset.category;
    });
  }

  Future<void> _selectDueDate(BuildContext context) async {
    HapticFeedback.lightImpact();
    final DateTime now = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDueDate,
      firstDate: now,
      lastDate: now.add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.dark(
              primary: PoketSafeColors.accentGreen,
              onPrimary: PoketSafeColors.background,
              surface: PoketSafeColors.surface,
              onSurface: PoketSafeColors.textPrimary,
            ),
            dialogBackgroundColor: PoketSafeColors.surface,
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != _selectedDueDate) {
      setState(() {
        _selectedDueDate = picked;
      });
    }
  }

  void _submitPayment() async {
    if (!_formKey.currentState!.validate()) {
      HapticFeedback.heavyImpact();
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    final double amount = double.parse(_amountController.text.trim());
    final String name = _nameController.text.trim();

    final paymentPayload = {
      'title': name,
      'amount': amount,
      'dueDate': _selectedDueDate,
      'category': _selectedCategory.name,
      'isPaidThisCycle': false,
      'createdAt': DateTime.now(),
    };

    // Simulate short network write or Firestore transaction
    await Future.delayed(const Duration(milliseconds: 300));

    if (widget.onPaymentSaved != null) {
      widget.onPaymentSaved!(paymentPayload);
    }

    if (mounted) {
      setState(() => _isSubmitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Locked RM ${amount.toStringAsFixed(2)} away from Safe Balance for $name'),
          backgroundColor: PoketSafeColors.primaryBlue,
          behavior: SnackBarBehavior.floating,
        ),
      );
      Navigator.of(context).pop(paymentPayload);
    }
  }

  @override
  Widget build(BuildContext context) {
    final formattedDueDate = DateFormat('d MMM yyyy').format(_selectedDueDate);
    final daysUntilDue = _selectedDueDate.difference(DateTime.now()).inDays;

    return Scaffold(
      backgroundColor: PoketSafeColors.background,
      appBar: AppBar(
        backgroundColor: PoketSafeColors.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close_rounded, color: PoketSafeColors.textPrimary),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Add Upcoming Payment',
          style: TextStyle(
            color: PoketSafeColors.textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Financial Invariant Notice Card
                _buildQuarantineNoticeCard(),
                const SizedBox(height: 20),

                // Quick Presets Carousel
                const Text(
                  'POPULAR STUDENT BILLS',
                  style: TextStyle(
                    color: PoketSafeColors.textMuted,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 8),
                _buildPresetsRow(),
                const SizedBox(height: 24),

                // Field 1: Payment Name
                _buildFieldLabel('Payment Name', isRequired: true),
                const SizedBox(height: 6),
                _buildNameField(),
                const SizedBox(height: 20),

                // Field 2: Amount
                _buildFieldLabel('Obligation Amount (RM)', isRequired: true),
                const SizedBox(height: 6),
                _buildAmountField(),
                const SizedBox(height: 20),

                // Field 3: Due Date Picker Trigger
                _buildFieldLabel('Due Date', isRequired: true),
                const SizedBox(height: 6),
                _buildDueDatePicker(formattedDueDate, daysUntilDue),
                const SizedBox(height: 20),

                // Field 4: Category Selector
                _buildFieldLabel('Category', isRequired: true),
                const SizedBox(height: 8),
                _buildCategorySelector(),
                const SizedBox(height: 36),

                // Submit Button
                _buildSubmitButton(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --------------------------------------------------------------------------
  // UI Sub-Components
  // --------------------------------------------------------------------------

  Widget _buildQuarantineNoticeCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: PoketSafeColors.primaryBlue.withOpacity(0.25),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PoketSafeColors.primaryBlue.withOpacity(0.5)),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.shield_outlined, color: PoketSafeColors.accentGreen, size: 20),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Automated Safe Balance Ring-Fencing',
                  style: TextStyle(
                    color: PoketSafeColors.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'This amount will be immediately deducted from your daily Safe-to-Spend limit so you never accidentally spend rent or installment money.',
                  style: TextStyle(color: PoketSafeColors.textMuted, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPresetsRow() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: kPopularStudentPresets.map((preset) {
          final isSelected = _nameController.text == preset.name;
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: ActionChip(
              backgroundColor: isSelected ? PoketSafeColors.primaryBlue : PoketSafeColors.surface,
              side: BorderSide(
                color: isSelected ? PoketSafeColors.accentGreen : PoketSafeColors.surfaceBorder,
              ),
              label: Text(
                preset.amount != null ? '${preset.name} (RM${preset.amount!.toInt()})' : preset.name,
                style: TextStyle(
                  color: isSelected ? PoketSafeColors.accentGreen : PoketSafeColors.textPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              avatar: Icon(
                preset.category.icon,
                size: 15,
                color: isSelected ? PoketSafeColors.accentGreen : PoketSafeColors.textMuted,
              ),
              onPressed: () => _applyPreset(preset),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildFieldLabel(String label, {bool isRequired = false}) {
    return Row(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: PoketSafeColors.textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
        if (isRequired)
          const Text(
            ' *',
            style: TextStyle(color: PoketSafeColors.alertRed, fontSize: 13),
          ),
      ],
    );
  }

  Widget _buildNameField() {
    return TextFormField(
      controller: _nameController,
      style: const TextStyle(color: PoketSafeColors.textPrimary, fontSize: 15),
      decoration: InputDecoration(
        hintText: 'e.g. SPayLater, Hostel Rental',
        hintStyle: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 14),
        filled: true,
        fillColor: PoketSafeColors.inputBackground,
        prefixIcon: const Icon(Icons.receipt_long_outlined, color: PoketSafeColors.textMuted, size: 20),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: PoketSafeColors.surfaceBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: PoketSafeColors.surfaceBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: PoketSafeColors.accentGreen, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      validator: (val) {
        if (val == null || val.trim().isEmpty) {
          return 'Please provide a payment name';
        }
        return null;
      },
    );
  }

  Widget _buildAmountField() {
    return TextFormField(
      controller: _amountController,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
      ],
      style: const TextStyle(
        color: PoketSafeColors.textPrimary,
        fontSize: 20,
        fontWeight: FontWeight.bold,
        fontFamily: 'monospace',
      ),
      decoration: InputDecoration(
        prefixText: 'RM ',
        prefixStyle: const TextStyle(
          color: PoketSafeColors.accentGreen,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          fontFamily: 'monospace',
        ),
        hintText: '0.00',
        hintStyle: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 18),
        filled: true,
        fillColor: PoketSafeColors.inputBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: PoketSafeColors.surfaceBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: PoketSafeColors.surfaceBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: PoketSafeColors.accentGreen, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      validator: (val) {
        if (val == null || val.trim().isEmpty) {
          return 'Enter payment amount';
        }
        final parsed = double.tryParse(val.trim());
        if (parsed == null || parsed <= 0) {
          return 'Amount must be greater than RM 0.00';
        }
        return null;
      },
    );
  }

  Widget _buildDueDatePicker(String formattedDate, int daysUntilDue) {
    return InkWell(
      onTap: () => _selectDueDate(context),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: PoketSafeColors.inputBackground,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: PoketSafeColors.surfaceBorder),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.between,
          children: [
            Row(
              children: [
                const Icon(Icons.event_outlined, color: PoketSafeColors.accentGreen, size: 20),
                const SizedBox(width: 12),
                Text(
                  formattedDate,
                  style: const TextStyle(
                    color: PoketSafeColors.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: PoketSafeColors.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white12),
              ),
              child: Text(
                daysUntilDue == 0 ? 'Due Today' : 'Due in $daysUntilDue days',
                style: const TextStyle(
                  color: PoketSafeColors.textMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategorySelector() {
    return Wrap(
      spacing: 8.0,
      runSpacing: 8.0,
      children: PaymentCategory.values.map((cat) {
        final isSelected = _selectedCategory == cat;
        return InkWell(
          onTap: () {
            HapticFeedback.lightImpact();
            setState(() => _selectedCategory = cat);
          },
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: isSelected ? PoketSafeColors.primaryBlue : PoketSafeColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? PoketSafeColors.accentGreen : PoketSafeColors.surfaceBorder,
                width: isSelected ? 1.4 : 1.0,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  cat.icon,
                  size: 16,
                  color: isSelected ? PoketSafeColors.accentGreen : PoketSafeColors.textMuted,
                ),
                const SizedBox(width: 8),
                Text(
                  cat.label,
                  style: TextStyle(
                    color: isSelected ? Colors.white : PoketSafeColors.textMuted,
                    fontSize: 12,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSubmitButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: _isSubmitting ? null : _submitPayment,
        style: ElevatedButton.styleFrom(
          backgroundColor: PoketSafeColors.accentGreen,
          foregroundColor: PoketSafeColors.background,
          elevation: 2,
          shadowColor: PoketSafeColors.accentGreen.withOpacity(0.35),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: _isSubmitting
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(PoketSafeColors.background),
                ),
              )
            : const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_outline_rounded, size: 18),
                  SizedBox(width: 8),
                  Text(
                    'Lock & Reserve Payment',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
      ),
    );
  }
}
