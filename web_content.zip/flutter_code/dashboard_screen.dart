import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

// ============================================================================
// 1. FINTECH PALETTE & THEME CONSTANTS (Material 3)
// ============================================================================
class PoketSafeColors {
  static const Color primaryBlue = Color(0xFF1E3A8A); // Dark Navy Blue
  static const Color accentGreen = Color(0xFF22C55E); // Safe / Growth Green
  static const Color alertRed = Color(0xFFEF4444);    // Debit / Warning Red
  static const Color warningAmber = Color(0xFFF59E0B);
  
  static const Color surfaceDark = Color(0xFF0F172A);
  static const Color backgroundDark = Color(0xFF020617);
  static const Color cardBorder = Color(0xFF1E293B);
  static const Color textMuted = Color(0xFF94A3B8);
}

// ============================================================================
// 2. DOMAIN MODELS & ENUMS
// ============================================================================
enum SurvivalTier {
  thriving,
  stable,
  caution,
  critical,
}

class DashboardMetrics {
  final double grossCash;
  final double unpaidCommitments;
  final double debtsOwed;
  final double lockedSavings;
  final double safeBalance;
  final int daysToDisbursement;
  final double dailySafeAllowance;
  final double todaySpent;
  final int survivalScore;
  final SurvivalTier survivalTier;
  final int runwayDays;
  final String fundingSource;

  const DashboardMetrics({
    required this.grossCash,
    required this.unpaidCommitments,
    required this.debtsOwed,
    required this.lockedSavings,
    required this.safeBalance,
    required this.daysToDisbursement,
    required this.dailySafeAllowance,
    required this.todaySpent,
    required this.survivalScore,
    required this.survivalTier,
    required this.runwayDays,
    required this.fundingSource,
  });

  double get todayRemaining => dailySafeAllowance - todaySpent;
}

enum ExpenseCategory {
  food,
  campus,
  transport,
  groceries,
  social,
  other,
}

class TransactionItem {
  final String id;
  final String title;
  final double amount;
  final ExpenseCategory category;
  final DateTime timestamp;

  const TransactionItem({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.timestamp,
  });
}

// ============================================================================
// 3. RIVERPOD STATE MANAGEMENT
// ============================================================================
class DashboardNotifier extends StateNotifier<DashboardMetrics> {
  DashboardNotifier()
      : super(const DashboardMetrics(
          grossCash: 3250.00,
          unpaidCommitments: 488.00,
          debtsOwed: 35.00,
          lockedSavings: 380.00,
          safeBalance: 2347.00,
          daysToDisbursement: 68,
          dailySafeAllowance: 34.51,
          todaySpent: 11.50,
          survivalScore: 84,
          survivalTier: SurvivalTier.thriving,
          runwayDays: 130,
          fundingSource: 'PTPTN Semester Loan Tranche',
        ));

  void logExpense(double amount, String title, ExpenseCategory category) {
    final updatedGross = math.max(0.0, state.grossCash - amount);
    final updatedSafe = math.max(0.0, state.safeBalance - amount);
    final updatedTodaySpent = state.todaySpent + amount;
    final updatedDailyCap = updatedSafe / state.daysToDisbursement;

    state = DashboardMetrics(
      grossCash: updatedGross,
      unpaidCommitments: state.unpaidCommitments,
      debtsOwed: state.debtsOwed,
      lockedSavings: state.lockedSavings,
      safeBalance: updatedSafe,
      daysToDisbursement: state.daysToDisbursement,
      dailySafeAllowance: updatedDailyCap,
      todaySpent: updatedTodaySpent,
      survivalScore: math.max(10, math.min(100, state.survivalScore - (amount > 30 ? 3 : 0))),
      survivalTier: state.survivalTier,
      runwayDays: math.max(0, (updatedSafe / 18.0).floor()),
      fundingSource: state.fundingSource,
    );
  }
}

final dashboardProvider =
    StateNotifierProvider<DashboardNotifier, DashboardMetrics>((ref) {
  return DashboardNotifier();
});

final recentTransactionsProvider =
    StateProvider<List<TransactionItem>>((ref) {
  return [
    TransactionItem(
      id: 'tx_1',
      title: 'Nasi Kandar lunch + Teh O Ais',
      amount: 11.50,
      category: ExpenseCategory.food,
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
    ),
    TransactionItem(
      id: 'tx_2',
      title: 'Campus Shuttle Semester Pass',
      amount: 15.00,
      category: ExpenseCategory.transport,
      timestamp: DateTime.now().subtract(const Duration(days: 1)),
    ),
    TransactionItem(
      id: 'tx_3',
      title: 'Photocopy Past Year Exam Pack',
      amount: 6.00,
      category: ExpenseCategory.campus,
      timestamp: DateTime.now().subtract(const Duration(days: 2)),
    ),
    TransactionItem(
      id: 'tx_4',
      title: 'Mydin Stationery & Mineral Water',
      amount: 8.50,
      category: ExpenseCategory.groceries,
      timestamp: DateTime.now().subtract(const Duration(days: 3)),
    ),
  ];
});

// ============================================================================
// 4. MAIN DASHBOARD SCREEN (Responsive Material 3 ConsumerWidget)
// ============================================================================
class PoketSafeDashboardScreen extends ConsumerWidget {
  const PoketSafeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final metrics = ref.watch(dashboardProvider);
    final transactions = ref.watch(recentTransactionsProvider);
    final currencyFormat = NumberFormat.currency(symbol: 'RM ', decimalDigits: 2);

    return Scaffold(
      backgroundColor: PoketSafeColors.backgroundDark,
      appBar: _buildAppBar(context, metrics),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Responsive break-point: Single column for mobile, 2-column for tablet/desktop
            final isWideScreen = constraints.maxWidth >= 768;

            return SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1100),
                  child: isWideScreen
                      ? _buildWideLayout(context, ref, metrics, transactions, currencyFormat)
                      : _buildNarrowLayout(context, ref, metrics, transactions, currencyFormat),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, DashboardMetrics metrics) {
    return AppBar(
      backgroundColor: PoketSafeColors.backgroundDark,
      elevation: 0,
      scrolledUnderElevation: 0,
      title: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [PoketSafeColors.primaryBlue, PoketSafeColors.accentGreen],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Center(
              child: Text(
                'P',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'PoketSafe',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  letterSpacing: -0.5,
                ),
              ),
              Text(
                '${metrics.daysToDisbursement} days to inflow',
                style: const TextStyle(
                  color: PoketSafeColors.textMuted,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.help_outline_rounded, color: PoketSafeColors.textMuted, size: 22),
          onPressed: () => _showFormulaSheet(context, metrics),
          tooltip: 'Safe Balance Formula',
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // Mobile Single Column
  Widget _buildNarrowLayout(
    BuildContext context,
    WidgetRef ref,
    DashboardMetrics metrics,
    List<TransactionItem> transactions,
    NumberFormat currencyFormat,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SafeBalanceHeroCard(metrics: metrics, currencyFormat: currencyFormat),
        const SizedBox(height: 14),
        _DailyBudgetCard(metrics: metrics, currencyFormat: currencyFormat),
        const SizedBox(height: 14),
        _SurvivalScoreCard(metrics: metrics),
        const SizedBox(height: 18),
        _QuickActionsSection(ref: ref),
        const SizedBox(height: 20),
        _RecentTransactionsSection(transactions: transactions, currencyFormat: currencyFormat),
        const SizedBox(height: 24),
      ],
    );
  }

  // Tablet & Desktop Split View
  Widget _buildWideLayout(
    BuildContext context,
    WidgetRef ref,
    DashboardMetrics metrics,
    List<TransactionItem> transactions,
    NumberFormat currencyFormat,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left Column (Safe Balance & Daily Budget)
        Expanded(
          flex: 5,
          child: Column(
            children: [
              _SafeBalanceHeroCard(metrics: metrics, currencyFormat: currencyFormat),
              const SizedBox(height: 16),
              _DailyBudgetCard(metrics: metrics, currencyFormat: currencyFormat),
              const SizedBox(height: 16),
              _QuickActionsSection(ref: ref),
            ],
          ),
        ),
        const SizedBox(width: 20),
        // Right Column (Survival Diagnostic & Transactions)
        Expanded(
          flex: 5,
          child: Column(
            children: [
              _SurvivalScoreCard(metrics: metrics),
              const SizedBox(height: 16),
              _RecentTransactionsSection(transactions: transactions, currencyFormat: currencyFormat),
            ],
          ),
        ),
      ],
    );
  }

  void _showFormulaSheet(BuildContext context, DashboardMetrics metrics) {
    showModalBottomSheet(
      context: context,
      backgroundColor: PoketSafeColors.surfaceDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'The PoketSafe Formula',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 14),
              _formulaRow('Gross Bank Cash', '+RM ${metrics.grossCash.toStringAsFixed(2)}', Colors.white),
              _formulaRow('Upcoming Commitments', '-RM ${metrics.unpaidCommitments.toStringAsFixed(2)}', PoketSafeColors.alertRed),
              _formulaRow('Peer Debts Owed', '-RM ${metrics.debtsOwed.toStringAsFixed(2)}', PoketSafeColors.warningAmber),
              _formulaRow('Locked Savings Vault', '-RM ${metrics.lockedSavings.toStringAsFixed(2)}', Colors.cyanAccent),
              const Divider(color: Colors.white24, height: 24),
              _formulaRow('Guaranteed Safe Balance', 'RM ${metrics.safeBalance.toStringAsFixed(2)}', PoketSafeColors.accentGreen, isBold: true),
              const SizedBox(height: 12),
              Text(
                'Daily Limit = RM ${metrics.safeBalance.toStringAsFixed(2)} ÷ ${metrics.daysToDisbursement} days = RM ${metrics.dailySafeAllowance.toStringAsFixed(2)} / day',
                style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _formulaRow(String label, String value, Color color, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.between,
        children: [
          Text(label, style: TextStyle(color: isBold ? Colors.white : PoketSafeColors.textMuted, fontSize: 13, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(value, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ============================================================================
// 5. COMPONENT: SAFE BALANCE HERO CARD
// ============================================================================
class _SafeBalanceHeroCard extends StatelessWidget {
  final DashboardMetrics metrics;
  final NumberFormat currencyFormat;

  const _SafeBalanceHeroCard({required this.metrics, required this.currencyFormat});

  @override
  Widget build(BuildContext context) {
    final isDeficit = metrics.safeBalance <= 0;

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            PoketSafeColors.primaryBlue,
            Color(0xFF0F2461),
            PoketSafeColors.backgroundDark,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: PoketSafeColors.primaryBlue.withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: PoketSafeColors.primaryBlue.withOpacity(0.25),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(22.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.between,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: PoketSafeColors.accentGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.shield_outlined,
                        color: PoketSafeColors.accentGreen,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'SAFE-TO-SPEND BALANCE',
                      style: TextStyle(
                        color: PoketSafeColors.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black38,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Text(
                    '${metrics.daysToDisbursement}d left',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              currencyFormat.format(metrics.safeBalance),
              style: TextStyle(
                color: isDeficit ? PoketSafeColors.alertRed : PoketSafeColors.accentGreen,
                fontSize: 38,
                fontWeight: FontWeight.w900,
                fontFamily: 'monospace',
                letterSpacing: -1,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Protected after reserving room rent, bills & peer debts.',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================================
// 6. COMPONENT: DAILY BUDGET CARD
// ============================================================================
class _DailyBudgetCard extends StatelessWidget {
  final DashboardMetrics metrics;
  final NumberFormat currencyFormat;

  const _DailyBudgetCard({required this.metrics, required this.currencyFormat});

  @override
  Widget build(BuildContext context) {
    final progress = metrics.dailySafeAllowance > 0
        ? (metrics.todaySpent / metrics.dailySafeAllowance).clamp(0.0, 1.0)
        : 1.0;
    final isOverspent = metrics.todayRemaining < 0;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PoketSafeColors.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: PoketSafeColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.between,
            children: [
              const Text(
                'Today\'s Safe Budget',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              ),
              Text(
                'Limit: ${currencyFormat.format(metrics.dailySafeAllowance)} / day',
                style: const TextStyle(color: PoketSafeColors.accentGreen, fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: Colors.white10,
              valueColor: AlwaysStoppedAnimation<Color>(
                isOverspent ? PoketSafeColors.alertRed : PoketSafeColors.accentGreen,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.between,
            children: [
              Text(
                'Spent today: ${currencyFormat.format(metrics.todaySpent)}',
                style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
              ),
              Text(
                isOverspent
                    ? 'Exceeded by ${currencyFormat.format(metrics.todayRemaining.abs())}'
                    : '${currencyFormat.format(metrics.todayRemaining)} buffer remaining',
                style: TextStyle(
                  color: isOverspent ? PoketSafeColors.alertRed : PoketSafeColors.accentGreen,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// 7. COMPONENT: SURVIVAL SCORE CARD (Custom Painter Dial)
// ============================================================================
class _SurvivalScoreCard extends StatelessWidget {
  final DashboardMetrics metrics;

  const _SurvivalScoreCard({required this.metrics});

  Color _getTierColor(SurvivalTier tier) {
    switch (tier) {
      case SurvivalTier.thriving:
        return PoketSafeColors.accentGreen;
      case SurvivalTier.stable:
        return Colors.blueAccent;
      case SurvivalTier.caution:
        return PoketSafeColors.warningAmber;
      case SurvivalTier.critical:
        return PoketSafeColors.alertRed;
    }
  }

  String _getTierLabel(SurvivalTier tier) {
    switch (tier) {
      case SurvivalTier.thriving:
        return 'Thriving & Resilient';
      case SurvivalTier.stable:
        return 'Stable Runway';
      case SurvivalTier.caution:
        return 'Caution: High Burn';
      case SurvivalTier.critical:
        return 'Emergency / Maggi Mode';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tierColor = _getTierColor(metrics.survivalTier);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PoketSafeColors.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tierColor.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 86,
            height: 86,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                  size: const Size(86, 86),
                  painter: _SurvivalDialPainter(
                    score: metrics.survivalScore,
                    strokeColor: tierColor,
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${metrics.survivalScore}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'monospace',
                      ),
                    ),
                    const Text(
                      '/ 100',
                      style: TextStyle(
                        color: PoketSafeColors.textMuted,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: tierColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: tierColor.withOpacity(0.3)),
                  ),
                  child: Text(
                    _getTierLabel(metrics.survivalTier),
                    style: TextStyle(
                      color: tierColor,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Physical runway: ${metrics.runwayDays} days safe at standard cafeteria cost.',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const SizedBox(height: 4),
                const Text(
                  'No gap deficit detected before next disbursement.',
                  style: TextStyle(color: PoketSafeColors.textMuted, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SurvivalDialPainter extends CustomPainter {
  final int score;
  final Color strokeColor;

  _SurvivalDialPainter({required this.score, required this.strokeColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 6;

    final bgPaint = Paint()
      ..color = PoketSafeColors.primaryBlue.withOpacity(0.3)
      ..strokeWidth = 7
      ..style = PaintingStyle.stroke;

    final progressPaint = Paint()
      ..color = strokeColor
      ..strokeWidth = 7
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, bgPaint);

    const startAngle = -math.pi / 2;
    final sweepAngle = (2 * math.pi) * (score / 100);

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepAngle,
      false,
      progressPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _SurvivalDialPainter oldDelegate) =>
      oldDelegate.score != score || oldDelegate.strokeColor != strokeColor;
}

// ============================================================================
// 8. COMPONENT: QUICK ACTIONS (Material 3 Touch Targets >= 48px)
// ============================================================================
class _QuickActionsSection extends StatelessWidget {
  final WidgetRef ref;

  const _QuickActionsSection({required this.ref});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _buildActionBtn(
          icon: Icons.add_circle_outline_rounded,
          label: 'Log Spend',
          color: PoketSafeColors.accentGreen,
          onTap: () {
            HapticFeedback.mediumImpact();
            ref.read(dashboardProvider.notifier).logExpense(
                  9.50,
                  'Campus Meal',
                  ExpenseCategory.food,
                );
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Logged RM 9.50 meal & deducted from Safe Balance'),
                duration: Duration(seconds: 2),
                backgroundColor: PoketSafeColors.primaryBlue,
              ),
            );
          },
        ),
        const SizedBox(width: 10),
        _buildActionBtn(
          icon: Icons.people_outline_rounded,
          label: 'Record IOU',
          color: Colors.cyanAccent,
          onTap: () => HapticFeedback.lightImpact(),
        ),
        const SizedBox(width: 10),
        _buildActionBtn(
          icon: Icons.receipt_long_outlined,
          label: 'Pay Bill',
          color: PoketSafeColors.primaryBlue,
          onTap: () => HapticFeedback.lightImpact(),
        ),
        const SizedBox(width: 10),
        _buildActionBtn(
          icon: Icons.savings_outlined,
          label: 'Lock Goal',
          color: Colors.amberAccent,
          onTap: () => HapticFeedback.lightImpact(),
        ),
      ],
    );
  }

  Widget _buildActionBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: PoketSafeColors.surfaceDark,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            constraints: const BoxConstraints(minHeight: 58),
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              border: Border.all(color: PoketSafeColors.cardBorder),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: color, size: 20),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// 9. COMPONENT: RECENT TRANSACTIONS STREAM
// ============================================================================
class _RecentTransactionsSection extends StatelessWidget {
  final List<TransactionItem> transactions;
  final NumberFormat currencyFormat;

  const _RecentTransactionsSection({
    required this.transactions,
    required this.currencyFormat,
  });

  IconData _getCategoryIcon(ExpenseCategory category) {
    switch (category) {
      case ExpenseCategory.food:
        return Icons.restaurant_outlined;
      case ExpenseCategory.transport:
        return Icons.directions_bus_outlined;
      case ExpenseCategory.campus:
        return Icons.school_outlined;
      case ExpenseCategory.groceries:
        return Icons.shopping_cart_outlined;
      case ExpenseCategory.social:
        return Icons.celebration_outlined;
      case ExpenseCategory.other:
        return Icons.more_horiz_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PoketSafeColors.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: PoketSafeColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.between,
            children: [
              const Text(
                'Recent Transactions',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              ),
              Text(
                '${transactions.length} items',
                style: const TextStyle(color: PoketSafeColors.textMuted, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: transactions.length,
            separatorBuilder: (context, index) => const Divider(color: Colors.white10, height: 16),
            itemBuilder: (context, index) {
              final tx = transactions[index];
              final dateStr = DateFormat('MMM d, h:mm a').format(tx.timestamp);

              return Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: Icon(
                      _getCategoryIcon(tx.category),
                      color: Colors.white70,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tx.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          dateStr,
                          style: const TextStyle(
                            color: PoketSafeColors.textMuted,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    '-${currencyFormat.format(tx.amount)}',
                    style: const TextStyle(
                      color: PoketSafeColors.alertRed,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
