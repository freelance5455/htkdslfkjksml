import 'package:cloud_firestore/cloud_firestore.dart';

// ============================================================================
// 1. USER MODEL (Collection: 'users')
// ============================================================================
class UserModel {
  final String id;
  final String email;
  final String displayName;
  final double grossCash;
  final DateTime nextDisbursementDate;
  final String currency;
  final String studentType; // 'ptptn' | 'scholarship' | 'working_student' | 'young_adult'
  final DateTime createdAt;
  final DateTime updatedAt;

  const UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    required this.grossCash,
    required this.nextDisbursementDate,
    this.currency = 'RM',
    this.studentType = 'ptptn',
    required this.createdAt,
    required this.updatedAt,
  });

  int get daysUntilInflow =>
      nextDisbursementDate.difference(DateTime.now()).inDays.clamp(1, 365);

  factory UserModel.fromJson(Map<String, dynamic> json, {String? id}) {
    return UserModel(
      id: id ?? json['id'] as String? ?? '',
      email: json['email'] as String? ?? '',
      displayName: json['displayName'] as String? ?? '',
      grossCash: (json['grossCash'] as num?)?.toDouble() ?? 0.0,
      nextDisbursementDate: _parseDateTime(json['nextDisbursementDate']),
      currency: json['currency'] as String? ?? 'RM',
      studentType: json['studentType'] as String? ?? 'ptptn',
      createdAt: _parseDateTime(json['createdAt']),
      updatedAt: _parseDateTime(json['updatedAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'displayName': displayName,
      'grossCash': grossCash,
      'nextDisbursementDate': Timestamp.fromDate(nextDisbursementDate),
      'currency': currency,
      'studentType': studentType,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? displayName,
    double? grossCash,
    DateTime? nextDisbursementDate,
    String? currency,
    String? studentType,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      grossCash: grossCash ?? this.grossCash,
      nextDisbursementDate: nextDisbursementDate ?? this.nextDisbursementDate,
      currency: currency ?? this.currency,
      studentType: studentType ?? this.studentType,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

// ============================================================================
// 2. TRANSACTION MODEL (Collection: 'transactions')
// ============================================================================
class TransactionModel {
  final String id;
  final String userId;
  final String title;
  final double amount;
  final String category; // 'food' | 'transport' | 'campus' | 'groceries' | 'social' | 'other'
  final String type; // 'expense' | 'income'
  final String paymentMethod; // 'cash' | 'duitnow_qr' | 'debit_card' | 'ewallet'
  final DateTime timestamp;
  final String? note;

  const TransactionModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.amount,
    required this.category,
    this.type = 'expense',
    this.paymentMethod = 'duitnow_qr',
    required this.timestamp,
    this.note,
  });

  bool get isExpense => type == 'expense';

  factory TransactionModel.fromJson(Map<String, dynamic> json, {String? id}) {
    return TransactionModel(
      id: id ?? json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      title: json['title'] as String? ?? '',
      amount: (json['amount'] as num?)?.toDouble() ?? 0.0,
      category: json['category'] as String? ?? 'other',
      type: json['type'] as String? ?? 'expense',
      paymentMethod: json['paymentMethod'] as String? ?? 'duitnow_qr',
      timestamp: _parseDateTime(json['timestamp']),
      note: json['note'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'title': title,
      'amount': amount,
      'category': category,
      'type': type,
      'paymentMethod': paymentMethod,
      'timestamp': Timestamp.fromDate(timestamp),
      'note': note,
    };
  }

  TransactionModel copyWith({
    String? id,
    String? userId,
    String? title,
    double? amount,
    String? category,
    String? type,
    String? paymentMethod,
    DateTime? timestamp,
    String? note,
  }) {
    return TransactionModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      category: category ?? this.category,
      type: type ?? this.type,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      timestamp: timestamp ?? this.timestamp,
      note: note ?? this.note,
    );
  }
}

// ============================================================================
// 3. PAYMENT MODEL (Collection: 'payments' — Commitments & Peer Debts)
// ============================================================================
class PaymentModel {
  final String id;
  final String userId;
  final String title;
  final double amount;
  final DateTime dueDate;
  final bool isPaidThisCycle;
  final String type; // 'commitment' | 'debt_i_owe' | 'debt_they_owe'
  final String category; // 'housing' | 'tuition' | 'utilities' | 'subscription' | 'peer_debt'
  final String frequency; // 'monthly' | 'semester' | 'one_time'
  final String? peerContact; // Optional phone/name for IOU

  const PaymentModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.amount,
    required this.dueDate,
    this.isPaidThisCycle = false,
    this.type = 'commitment',
    this.category = 'housing',
    this.frequency = 'monthly',
    this.peerContact,
  });

  bool get isDebt => type == 'debt_i_owe' || type == 'debt_they_owe';
  bool get shouldDeductFromSafeBalance => !isPaidThisCycle && (type == 'commitment' || type == 'debt_i_owe');

  factory PaymentModel.fromJson(Map<String, dynamic> json, {String? id}) {
    return PaymentModel(
      id: id ?? json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      title: json['title'] as String? ?? '',
      amount: (json['amount'] as num?)?.toDouble() ?? 0.0,
      dueDate: _parseDateTime(json['dueDate']),
      isPaidThisCycle: json['isPaidThisCycle'] as bool? ?? false,
      type: json['type'] as String? ?? 'commitment',
      category: json['category'] as String? ?? 'housing',
      frequency: json['frequency'] as String? ?? 'monthly',
      peerContact: json['peerContact'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'title': title,
      'amount': amount,
      'dueDate': Timestamp.fromDate(dueDate),
      'isPaidThisCycle': isPaidThisCycle,
      'type': type,
      'category': category,
      'frequency': frequency,
      'peerContact': peerContact,
    };
  }

  PaymentModel copyWith({
    String? id,
    String? userId,
    String? title,
    double? amount,
    DateTime? dueDate,
    bool? isPaidThisCycle,
    String? type,
    String? category,
    String? frequency,
    String? peerContact,
  }) {
    return PaymentModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      dueDate: dueDate ?? this.dueDate,
      isPaidThisCycle: isPaidThisCycle ?? this.isPaidThisCycle,
      type: type ?? this.type,
      category: category ?? this.category,
      frequency: frequency ?? this.frequency,
      peerContact: peerContact ?? this.peerContact,
    );
  }
}

// ============================================================================
// 4. INCOME MODEL (Collection: 'income' — Loans, Scholarships, Allowances)
// ============================================================================
class IncomeModel {
  final String id;
  final String userId;
  final String source; // 'ptptn' | 'scholarship' | 'parents' | 'part_time' | 'other'
  final String title;
  final double amount;
  final DateTime arrivalDate;
  final DateTime? nextExpectedDate;
  final String recurrence; // 'semester' | 'monthly' | 'one_off'
  final String? note;
  final DateTime createdAt;

  const IncomeModel({
    required this.id,
    required this.userId,
    required this.source,
    required this.title,
    required this.amount,
    required this.arrivalDate,
    this.nextExpectedDate,
    this.recurrence = 'semester',
    this.note,
    required this.createdAt,
  });

  factory IncomeModel.fromJson(Map<String, dynamic> json, {String? id}) {
    return IncomeModel(
      id: id ?? json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      source: json['source'] as String? ?? 'ptptn',
      title: json['title'] as String? ?? '',
      amount: (json['amount'] as num?)?.toDouble() ?? 0.0,
      arrivalDate: _parseDateTime(json['arrivalDate']),
      nextExpectedDate: json['nextExpectedDate'] != null
          ? _parseDateTime(json['nextExpectedDate'])
          : null,
      recurrence: json['recurrence'] as String? ?? 'semester',
      note: json['note'] as String?,
      createdAt: _parseDateTime(json['createdAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'source': source,
      'title': title,
      'amount': amount,
      'arrivalDate': Timestamp.fromDate(arrivalDate),
      'nextExpectedDate': nextExpectedDate != null
          ? Timestamp.fromDate(nextExpectedDate!)
          : null,
      'recurrence': recurrence,
      'note': note,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  IncomeModel copyWith({
    String? id,
    String? userId,
    String? source,
    String? title,
    double? amount,
    DateTime? arrivalDate,
    DateTime? nextExpectedDate,
    String? recurrence,
    String? note,
    DateTime? createdAt,
  }) {
    return IncomeModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      source: source ?? this.source,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      arrivalDate: arrivalDate ?? this.arrivalDate,
      nextExpectedDate: nextExpectedDate ?? this.nextExpectedDate,
      recurrence: recurrence ?? this.recurrence,
      note: note ?? this.note,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

// ============================================================================
// HELPER: Flexible DateTime Parser (Handles Firestore Timestamp, String & int)
// ============================================================================
DateTime _parseDateTime(dynamic value) {
  if (value is Timestamp) {
    return value.toDate();
  } else if (value is String) {
    return DateTime.tryParse(value) ?? DateTime.now();
  } else if (value is int) {
    return DateTime.fromMillisecondsSinceEpoch(value);
  }
  return DateTime.now();
}
