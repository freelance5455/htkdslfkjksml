T-shirt Mall Android Starter (PWA)

यह अभी native APK नहीं है। यह मोबाइल पर चलने वाला installable web app starter है।

चलाने के लिए:
1. इस folder की files किसी static hosting पर upload करें (HTTPS जरूरी है)।
2. Android Chrome में website खोलें।
3. Chrome menu > Add to Home screen / Install app चुनें।

Native APK बनाने के लिए Android Studio या Capacitor build और Android SDK की जरूरत होगी। यह environment APK compile नहीं कर रहा है।

सीमाएँ: Admin पर password नहीं; products/cart उसी browser/device के localStorage में रहते हैं; real payment/order backend नहीं है। Public use से पहले secure authentication, server/database और checkout integration जोड़ें।
