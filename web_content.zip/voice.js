
const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;

function setupVoice(buttonId, inputId) {
  const button = document.getElementById(buttonId);
  const input = document.getElementById(inputId);

  if (!button || !input) return;

  if (!SpeechRecognition) {
    button.addEventListener("click", () => {
      alert("المتصفح لا يدعم التسجيل الصوتي. جرّب Google Chrome.");
    });
    return;
  }

  const recognition = new SpeechRecognition();

  recognition.lang = "ar";
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  let recording = false;
  let restarting = false;

  function updateButton() {
    if (recording) {
      button.textContent = "🔴 جارٍ الاستماع... اضغط للإيقاف";
      button.classList.add("recording");
    } else {
      button.textContent =
        buttonId === "imageVoiceBtn"
          ? "🎙️ تحدث لوصف الصورة"
          : "🎙️ تحدث";

      button.classList.remove("recording");
    }
  }

  function startRecognition() {
    if (!recording || restarting) return;

    restarting = true;

    try {
      recognition.start();
    } catch (error) {
      console.log("Voice restart:", error);
      restarting = false;
    }
  }

  function stopRecognition() {
    recording = false;
    restarting = false;

    try {
      recognition.stop();
    } catch (error) {
      console.log("Voice stop:", error);
    }

    updateButton();
  }

  button.addEventListener("click", () => {
    if (recording) {
      stopRecognition();
      return;
    }

    recording = true;
    startRecognition();
  });

  recognition.onstart = () => {
    restarting = false;
    updateButton();
  };

  recognition.onresult = (event) => {
    let transcript = "";

    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) {
        transcript += event.results[i][0].transcript;
      }
    }

    transcript = transcript.trim();

    if (transcript) {
      input.value = input.value.trim()
        ? input.value.trim() + " " + transcript
        : transcript;

      input.dispatchEvent(new Event("input", {
        bubbles: true
      }));
    }
  };

  recognition.onerror = (event) => {
    console.error("Voice recognition error:", event.error);

    if (
      event.error === "not-allowed" ||
      event.error === "service-not-allowed" ||
      event.error === "audio-capture"
    ) {
      stopRecognition();

      if (event.error === "audio-capture") {
        alert("تعذر الوصول إلى الميكروفون. تأكد من أنه غير مستخدم من تطبيق آخر.");
      } else {
        alert("يجب السماح للمتصفح باستخدام الميكروفون.");
      }
    }
  };

  recognition.onend = () => {
    restarting = false;

    if (recording) {
      setTimeout(() => {
        startRecognition();
      }, 300);
    } else {
      updateButton();
    }
  };
}

setupVoice("imageVoiceBtn", "imagePrompt");
setupVoice("chatVoiceBtn", "aiPrompt");
