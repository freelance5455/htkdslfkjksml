package com.unai.tim;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private TiMSafeStorageBridge safeBridge;
    private TiMFileChooserChromeClient fileChooserBridge;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        safeBridge = new TiMSafeStorageBridge(this);
        WebView webView = getBridge().getWebView();

        // Register the SAF bridge before reloading the bundled page. Android WebView
        // exposes addJavascriptInterface objects to JavaScript after the next page load.
        webView.addJavascriptInterface(safeBridge, "TiMSafeStorage");

        // Preserve Capacitor's WebChromeClient behavior and TiM's image QR picker.
        fileChooserBridge = new TiMFileChooserChromeClient(getBridge());
        webView.setWebChromeClient(fileChooserBridge);

        // Ensure the already-started Capacitor page sees window.TiMSafeStorage.
        webView.post(webView::reload);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == TiMSafeStorageBridge.REQUEST_TREE) {
            boolean ok = safeBridge != null && safeBridge.onFolderResult(resultCode, data);
            final String js = "window.onTiMSafeFolderSelected && window.onTiMSafeFolderSelected(" + (ok ? "true" : "false") + ");";
            getBridge().getWebView().post(() -> getBridge().getWebView().evaluateJavascript(js, null));
        } else if (requestCode == TiMFileChooserChromeClient.REQUEST_IMAGE_FROM_EXPLORER) {
            if (fileChooserBridge != null) {
                fileChooserBridge.onExplorerResult(resultCode, data);
            }
        }
    }
}
