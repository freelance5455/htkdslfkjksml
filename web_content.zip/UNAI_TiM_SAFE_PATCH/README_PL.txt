UNAI TiM SAFE — PATCH INTEGRACYJNY

CO ZAWIERA
- www/index.html — aktualny TiM_WORLD_SAFE_SINGLE_FILE.html z obsługą SAFE.
- android/app/src/main/java/com/unai/tim/MainActivity.java
- android/app/src/main/java/com/unai/tim/TiMSafeStorageBridge.java
- android/app/src/main/java/com/unai/tim/TiMFileChooserChromeClient.java

NAJWAŻNIEJSZA POPRAWKA
MainActivity rejestruje obiekt JavaScript pod nazwą TiMSafeStorage, a następnie
wymusza ponowne załadowanie WebView. Android udostępnia obiekty
addJavascriptInterface JavaScriptowi po kolejnym załadowaniu strony. To
naprawia prawdopodobną przyczynę komunikatu, że SAFE nie widzi natywnego SAF.

ZGODNOŚĆ HTML ↔ JAVA
- HTML przekazuje nazwę UNAI_TIM_SAFE.timsafe.
- HTML przekazuje treść jako Base64.
- Java dekoduje Base64.
- Karta otrzymuje folder UNAI_SAFE, a w nim jeden plik UNAI_TIM_SAFE.timsafe.
- Zapis jest odczytywany ponownie i porównywany bajt po bajcie.
- Przy kolejnym zapisie poprzedni plik jest zastępowany po sprawdzeniu nowego.

INTEGRACJA
1. Skopiuj zawartość www/ do katalogu webDir projektu Capacitor (zwykle www/).
2. Skopiuj trzy pliki Java do android/app/src/main/java/com/unai/tim/.
   Zastąp nimi odpowiednie pliki w projekcie, nie twórz drugiej MainActivity.
3. W android/app/build.gradle sprawdź, czy istnieje zależność:
   implementation "androidx.documentfile:documentfile:1.0.1"
   Jeśli jej nie ma, dodaj ją w dependencies.
4. Skompiluj i zainstaluj nową APK. Odinstalowanie starej aplikacji może
   skasować jej lokalne dane; nie rób tego, jeśli chcesz zachować portfel.

TEST
- Otwórz SAFE i zapisz pakiet testowy.
- Wybierz główny katalog karty SDHC i zatwierdź dostęp.
- Oczekiwany folder: UNAI_SAFE.
- Oczekiwany plik: UNAI_TIM_SAFE.timsafe.
- Powtórz zapis i sprawdź, czy nie powstaje drugi plik.
- Sprawdź odczyt z prawidłową odpowiedzią/hasłem oraz odmowę dla błędnych danych.

OGRANICZENIA
To patch źródłowy, nie kompletny projekt Gradle ani gotowa APK. Nie wykonano
kompilacji Androida ani testu na fizycznym urządzeniu. SAFE pozostaje testem
nośnika: nie przenosi prawdziwych jednostek TiM. Samo szyfrowanie pliku nie
zapewnia ochrony przed kopiowaniem, cofnięciem stanu ani podwójnym użyciem
na dwóch całkowicie offline urządzeniach.
