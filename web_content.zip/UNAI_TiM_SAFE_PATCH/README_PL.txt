# UNAI TiM SAFE — pakiet integracyjny

## Co zawiera
- `www/index.html` — aktualny HTML TiM z obsługą zapisu SAFE przez `window.TiMSafeStorage`.
- `android/app/src/main/java/com/unai/tim/MainActivity.java` — przekazany plik MainActivity.
- `android/app/src/main/java/com/unai/tim/TiMFileChooserChromeClient.java` — przekazany obsługiwacz wyboru zdjęć QR.
- `android/app/src/main/java/com/unai/tim/TiMSafeStorageBridge.java` — poprawiony most SAF.

## Co zostało dopasowane
1. Wspólna nazwa pliku: `UNAI_TIM_SAFE.timsafe`.
2. HTML wysyła dane zakodowane Base64; Java dekoduje Base64 przed zapisem.
3. Po wybraniu głównego katalogu wymiennej karty SD, most tworzy folder `UNAI_SAFE`.
4. W folderze `UNAI_SAFE` dozwolony jest wyłącznie jeden plik SAFE (plus krótkotrwały plik roboczy podczas zapisu). Inne pliki w tym folderze powodują odmowę zapisu.
5. Zapis jest odczytywany ponownie i porównywany bajt po bajcie przed potwierdzeniem `OK`.
6. Pliki systemowe Androida w głównym katalogu karty nie blokują już zapisu.

## Integracja
To jest pakiet źródłowy / patch, a nie kompletny projekt Gradle ani gotowa APK.
Skopiuj zawartość `www/` do katalogu webDir używanego przez istniejący projekt Capacitor.
Skopiuj trzy pliki Java do `android/app/src/main/java/com/unai/tim/`.
Sprawdź, czy moduł aplikacji ma zależność AndroidX DocumentFile (`androidx.documentfile:documentfile`). Nie usuwaj pozostałych konfiguracji projektu.

## Ważne ograniczenia i testy
- `MainActivity` i `TiMFileChooserChromeClient` zostały dołączone bez zmian.
- HTML odczytuje pakiet przez standardowy wybór pliku Androida; wybierz `UNAI_SAFE/UNAI_TIM_SAFE.timsafe`.
- Ten etap nadal jest testem nośnika. Nie przechowuje ani nie przenosi prawdziwych jednostek TiM.
- Weryfikacja zapisu nie daje gwarancji odporności na skopiowanie pliku, cofnięcie stanu karty ani podwójne użycie na dwóch urządzeniach offline.
- Nie testowano kompilacji Gradle ani działania na fizycznym telefonie w tej sesji. Po kompilacji sprawdź: wybór karty SD, zapis, ponowny zapis (zastąpienie), odczyt i błędne hasło.
