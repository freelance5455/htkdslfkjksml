package com.unai.tim;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebChromeClient;

import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebChromeClient;

/**
 * File chooser bridge for TiM's image QR input.
 * Extends Capacitor's own client so camera, JS dialogs and permission handling remain intact.
 */
public final class TiMFileChooserChromeClient extends BridgeWebChromeClient {
    public static final int REQUEST_IMAGE_FROM_EXPLORER = 6412;

    private final Activity activity;
    private ValueCallback<Uri[]> pendingFileCallback;

    public TiMFileChooserChromeClient(Bridge bridge) {
        super(bridge);
        this.activity = bridge.getActivity();
    }

    @Override
    public boolean onShowFileChooser(
            WebView webView,
            ValueCallback<Uri[]> filePathCallback,
            WebChromeClient.FileChooserParams fileChooserParams) {

        // Only intercept the normal image-picker flow used by TiM's saved payment QR.
        // Keep Capacitor's standard handling for capture, non-image, or other file inputs.
        if (fileChooserParams == null || fileChooserParams.isCaptureEnabled()) {
            return super.onShowFileChooser(webView, filePathCallback, fileChooserParams);
        }

        String[] types = fileChooserParams.getAcceptTypes();
        boolean imageRequested = false;
        if (types != null) {
            for (String type : types) {
                if (type != null && (type.contains("image/*") || type.startsWith("image/"))) {
                    imageRequested = true;
                    break;
                }
            }
        }
        if (!imageRequested) {
            return super.onShowFileChooser(webView, filePathCallback, fileChooserParams);
        }

        // A WebView must never keep two unresolved file callbacks.
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        pendingFileCallback = filePathCallback;

        Intent openImage = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        openImage.addCategory(Intent.CATEGORY_OPENABLE);
        openImage.setType("image/*");
        openImage.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[] {"image/jpeg", "image/png", "image/webp"});
        openImage.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        openImage.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

        try {
            activity.startActivityForResult(
                    Intent.createChooser(openImage, "Wybierz zdjęcie QR"),
                    REQUEST_IMAGE_FROM_EXPLORER);
            return true;
        } catch (ActivityNotFoundException firstError) {
            // Fallback for Android builds/file managers without ACTION_OPEN_DOCUMENT.
            try {
                Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType("image/*");
                activity.startActivityForResult(
                        Intent.createChooser(fallback, "Wybierz zdjęcie QR"),
                        REQUEST_IMAGE_FROM_EXPLORER);
                return true;
            } catch (ActivityNotFoundException secondError) {
                deliver(null);
                return false;
            }
        }
    }

    public void onExplorerResult(int resultCode, Intent data) {
        Uri[] result = null;
        if (resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                result = new Uri[] { uri };
                try {
                    activity.getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (SecurityException ignored) {
                    // Some providers grant a temporary read permission only; the URI
                    // remains valid for the immediate WebView file-input callback.
                }
            }
        }
        deliver(result);
    }

    private void deliver(Uri[] result) {
        if (pendingFileCallback != null) {
            ValueCallback<Uri[]> callback = pendingFileCallback;
            pendingFileCallback = null;
            callback.onReceiveValue(result);
        }
    }
}
