package com.unai.tim;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Wąski most SAF dla lokalnego, zaufanego HTML TiM SAFE.
 * Na wybranej wymiennej karcie tworzy folder UNAI_SAFE i obsługuje
 * wyłącznie jeden plik UNAI_TIM_SAFE.timsafe.
 */
public final class TiMSafeStorageBridge {
    public static final int REQUEST_TREE = 7412;

    private static final String PREFS = "tim_safe_storage";
    private static final String TREE_URI = "tree_uri";
    private static final String SAFE_DIR = "UNAI_SAFE";
    private static final String FINAL_NAME = "UNAI_TIM_SAFE.timsafe";
    private static final String TEMP_NAME = ".UNAI_TIM_SAFE.timsafe.tmp";
    private static final int MAX_BYTES = 2 * 1024 * 1024;

    private final MainActivity activity;

    TiMSafeStorageBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void selectSafeFolder() {
        activity.runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            activity.startActivityForResult(i, REQUEST_TREE);
        });
    }

    boolean onFolderResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            return false;
        }

        Uri uri = data.getData();
        int flags = data.getFlags()
                & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            activity.getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception e) {
            return false;
        }

        if (!isRemovableCardTree(uri)) {
            return false;
        }

        activity.getSharedPreferences(PREFS, 0)
                .edit()
                .putString(TREE_URI, uri.toString())
                .apply();
        return true;
    }

    @JavascriptInterface
    public synchronized String saveSafeFile(String fileName, String base64Data) {
        if (!FINAL_NAME.equals(fileName) || base64Data == null) {
            return "ERROR_INVALID_NAME_OR_DATA";
        }

        DocumentFile temp = null;
        try {
            Uri tree = getSavedTree();
            if (tree == null || !isRemovableCardTree(tree)) {
                return "ERROR_CARD_NOT_SELECTED";
            }

            byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
            if (bytes.length == 0 || bytes.length > MAX_BYTES) {
                return "ERROR_INVALID_SIZE";
            }

            DocumentFile cardRoot = DocumentFile.fromTreeUri(activity, tree);
            if (cardRoot == null || !cardRoot.isDirectory() || !cardRoot.canWrite()) {
                return "ERROR_CARD_NOT_WRITABLE";
            }

            // Android system folders at card root are left untouched.
            // The dedicated UNAI_SAFE folder itself accepts only our one SAFE file.
            DocumentFile safeDir = cardRoot.findFile(SAFE_DIR);
            if (safeDir == null) {
                safeDir = cardRoot.createDirectory(SAFE_DIR);
            }
            if (safeDir == null || !safeDir.isDirectory() || !safeDir.canWrite()) {
                return "ERROR_SAFE_FOLDER";
            }

            DocumentFile existing = null;
            for (DocumentFile f : safeDir.listFiles()) {
                String name = f.getName();
                if (FINAL_NAME.equals(name)) {
                    existing = f;
                } else if (TEMP_NAME.equals(name)) {
                    if (!f.delete()) return "ERROR_TEMP_CLEANUP";
                } else {
                    return "ERROR_FOREIGN_FILES";
                }
            }

            temp = safeDir.createFile("application/octet-stream", TEMP_NAME);
            if (temp == null) return "ERROR_TEMP_CREATE";

            try (OutputStream out = activity.getContentResolver().openOutputStream(temp.getUri(), "w")) {
                if (out == null) {
                    temp.delete();
                    return "ERROR_WRITE";
                }
                out.write(bytes);
                out.flush();
            }

            byte[] check = readAll(temp.getUri());
            if (!java.util.Arrays.equals(bytes, check)) {
                temp.delete();
                return "ERROR_VERIFY_TEMP";
            }

            // Verify new data before deleting the previous SAFE package.
            if (existing != null && !existing.delete()) {
                temp.delete();
                return "ERROR_REPLACE";
            }

            if (!temp.renameTo(FINAL_NAME)) {
                return "ERROR_RENAME";
            }
            temp = null;

            DocumentFile finalFile = safeDir.findFile(FINAL_NAME);
            if (finalFile == null || !java.util.Arrays.equals(bytes, readAll(finalFile.getUri()))) {
                return "ERROR_VERIFY_FINAL";
            }

            int count = 0;
            for (DocumentFile f : safeDir.listFiles()) {
                if (FINAL_NAME.equals(f.getName())) count++;
                else return "ERROR_FOREIGN_FILES";
            }
            return count == 1 ? "OK" : "ERROR_FINAL_COUNT";
        } catch (Exception e) {
            if (temp != null) {
                try { temp.delete(); } catch (Exception ignored) { }
            }
            return "ERROR";
        }
    }

    private Uri getSavedTree() {
        String value = activity.getSharedPreferences(PREFS, 0).getString(TREE_URI, null);
        return value == null ? null : Uri.parse(value);
    }

    private boolean isRemovableCardTree(Uri tree) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(tree);
            int colon = docId.indexOf(':');
            if (colon <= 0) return false;

            String volume = docId.substring(0, colon);
            if ("primary".equalsIgnoreCase(volume)) return false;

            File[] dirs = activity.getExternalFilesDirs(null);
            for (File f : dirs) {
                if (f == null) continue;
                String path = f.getAbsolutePath();
                String marker = "/" + volume + "/Android/";
                if (path.contains(marker) && Environment.isExternalStorageRemovable(f)) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private byte[] readAll(Uri uri) throws Exception {
        try (InputStream in = activity.getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("read failed");
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) > 0) {
                out.write(buffer, 0, count);
            }
            return out.toByteArray();
        }
    }
}
