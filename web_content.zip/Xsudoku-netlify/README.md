# Sudoku Zen (Open Source MIT)

Juego de Sudoku moderno, intuitivo y sin dependencias de servidor, diseñado para desplegarse en segundos en [Netlify](https://www.netlify.com/).

## Características principales

- **Generador con solución única**: Algoritmo de *backtracking* que crea tableros nuevos en 4 niveles (*Fácil*, *Medio*, *Difícil* y *Experto*).
- **Animaciones modernas y sonido Web Audio**: Micro-interacciones fluidas, resaltado inteligente de filas/columnas/bloques, ondas al completar grupos, confeti de victoria y efectos de sonido sintetizados.
- **Modo Notas y Auto-Notas**: Anotación de candidatos estilo lápiz con limpieza automática al colocar números y cálculo instantáneo de candidatos.
- **Despliegue instantáneo (Zero-Build)**: Incluye `index.html` autocontenido y `netlify.toml`.

## Instalación rápida en Netlify

1. **Con Netlify Drop (sin cuenta ni consola)**:
   - Ve a [Netlify Drop](https://app.netlify.com/drop) ([Guía oficial](https://docs.netlify.com/start/quickstarts/netlify-drop-quickstart/)).
   - Arrastra esta carpeta o el archivo `.zip` directamente al recuadro de carga.
2. **Desde GitHub / Git**:
   - Sube este repositorio a GitHub y conéctalo en tu panel de [ Creación de Deploys en Netlify](https://docs.netlify.com/deploy/create-deploys/). El archivo `netlify.toml` configurará la publicación automáticamente.
