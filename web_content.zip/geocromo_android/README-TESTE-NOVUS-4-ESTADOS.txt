GEOCROMOINDICADOR — PACOTE EXPERIMENTAL NOVUS (4 ESTADOS)

OBJETIVO
Este pacote é um ambiente experimental isolado para estudar exclusivamente as quatro configurações:
1. Novus Conceptus Solae de Alta
2. Novus Conceptus Solae de Baixa
3. Novus Conceptus Lunae de Alta
4. Novus Conceptus Lunae de Baixa

IMPORTANTE SOBRE A VERSÃO ENTREGUE
A interface base incluída é a versão 1.7 recebida, com seu mecanismo existente de triângulos, backtest e otimizador. O mecanismo original ainda classifica tendências por dominância/área e otimiza tolerância de vértices, stop percentual e reversão. Ele NÃO deve ser tratado como validação já concluída das quatro classes Novus nem como prova de que encontrou stops lucrativos. Esta ressalva está registrada para não mascarar uma limitação conhecida do código-base.

OBJETIVO DO OTIMIZADOR
A otimização de entrada/stop deve ser avaliada por ativo e em amostra temporal separada:
- treino cronológico para selecionar parâmetros;
- teste fora da amostra sem selecionar parâmetros pelo resultado do teste;
- teste walk-forward em janelas sucessivas;
- comparação com referência sem stop e com regras simples;
- taxas, slippage e, quando aplicável, funding;
- retorno líquido, expectativa por operação, profit factor, drawdown máximo, exposição, número de operações e estabilidade entre ativos/períodos;
- rejeitar configurações com poucas operações ou que dependam de um único ativo/regime;
- usar apenas informação disponível no momento do sinal, sem look-ahead;
- tratar candles em que stop e alvo possam ser tocados sem ordem conhecida de forma conservadora.

ENTRADAS E STOPS A INVESTIGAR
1. Entrada no fechamento do bloco sinalizador, execução no próximo candle disponível.
2. Entrada por rompimento/retomada de vértice, com confirmação no fechamento e execução posterior.
3. Stop estrutural atrás do vértice/limitador relevante, com buffer baseado em ATR.
4. Stop de volatilidade por múltiplos de ATR, comparado ao stop estrutural.
5. Saída por mudança válida de estado Novus, invalidação geométrica ou stop.

REGRA DE INTEGRIDADE
Não declarar uma configuração “consistente a longo prazo” apenas por maior lucro histórico. Exigir resultados positivos ou robustos em teste fora da amostra, custos realistas, diferentes ativos e janelas temporais, além de registrar resultados negativos e incerteza. Não existe algoritmo que garanta consistência futura.

COMO ABRIR
Extraia o ZIP e abra geocromo_android/index.html num navegador moderno. A consulta direta à API pública da Binance exige conexão à internet e pode sofrer limites/CORS. Para uso em produção, a classificação dos quatro estados Novus e o motor de otimização descritos acima precisam ser implementados e auditados antes de interpretar o ranking como recomendação.
