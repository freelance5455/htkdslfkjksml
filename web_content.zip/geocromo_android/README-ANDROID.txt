GEOCROMOINDICADOR — PROJETO ANDROID

Este é um projeto Android Studio com WebView e o backtest original incluído localmente em app/src/main/assets/index.html.

Para gerar o APK:
1. Instale Android Studio (versão atual) com Android SDK Platform 35.
2. Extraia este ZIP.
3. No Android Studio, escolha Open e selecione a pasta Geocromoindicador.
4. Aguarde a sincronização do Gradle e eventuais downloads dos componentes Android.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de depuração ficará em app/build/outputs/apk/debug/app-debug.apk.

O app precisa de internet para consultar a API pública da Binance. O backtest é experimental, não inclui taxas nem slippage e não constitui recomendação financeira.

Limitação desta entrega: este ambiente não possui Android SDK/Gradle instalados, portanto o APK binário não pôde ser compilado aqui. O projeto-fonte está preparado para abrir e compilar no Android Studio.
