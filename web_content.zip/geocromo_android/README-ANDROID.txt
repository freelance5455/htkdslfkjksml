GEOCROMOINDICADOR — PROJETO ANDROID

Este é um projeto Android Studio com WebView e o backtest original incluído localmente em app/src/main/assets/index.html.

Para gerar o APK:
1. Instale Android Studio (versão atual) com Android SDK Platform 35.
2. Extraia este ZIP.
3. No Android Studio, escolha Open e selecione a pasta Geocromoindicador.
4. Aguarde a sincronização do Gradle e eventuais downloads dos componentes Android.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de depuração ficará em app/build/outputs/apk/debug/app-debug.apk.

O app precisa de internet para consultar a API pública da Binance. O backtest é experimental, não inclui taxas nem slippage e não constitui recomendação financeira.

Limitação desta entrega: este ambiente não possui Android SDK/Gradle instalados, portanto o APK binário não pôde ser compilado aqui. O projeto-fonte está preparado para abrir e compilar no Android Studio.


VERSÃO 1.1 — CORREÇÕES DE AUDITORIA (15/10/2026)
- Interseções de triângulos e limitadores só são aceitas quando estão dentro do bloco temporal de 26 candles.
- Triângulos incompletos, degenerados, com vértices repetidos ou área praticamente nula não classificam tendência.
- Empates de área ficam sem tendência, evitando decisão arbitrária.
- Retorno de operações vendidas e stop-loss corrigidos para usar a variação percentual em relação ao preço de entrada; stop adverso de 35% registra -35%.
- A versão mantém a lista multiativos, importação Binance/CSV/JSON e exportação CSV.

NOTA DE VALIDAÇÃO
O código JavaScript foi verificado sintaticamente. Este ZIP contém o projeto-fonte Android Studio; não contém APK compilado. Os resultados anteriores não foram recalculados porque seria necessário executar o backtest novamente com candles históricos disponíveis.

Atualização v1.3: stop loss removido. A posição é mantida enquanto a dominância dos blocos permanece igual e invertida quando muda. Vértices deduplicados com tolerância numérica e marcados no gráfico (U/T); limitadores aparecem em verde (L).

Atualização v1.5: stop loss (padrão 10% além dos vértices) e reversão por abertura/fechamento além dos vértices, ambos configuráveis. Detalhes em README-NETLIFY.txt.
Atualização v1.6: otimizador de configurações (ver README-NETLIFY.txt).
