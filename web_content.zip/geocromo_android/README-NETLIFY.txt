GEOCROMOINDICADOR — PACOTE WEB + ANDROID (v1.6)

CORREÇÃO: o ZIP agora inclui index.html na raiz e netlify.toml para publicação estática no Netlify.

NETLIFY:
1. Extraia o ZIP no computador.
2. No Netlify, crie/abra um site e faça deploy da pasta geocromo_android (a pasta que contém index.html e netlify.toml), ou envie o conteúdo dessa pasta conforme a interface de deploy.
3. O endereço público do site é diferente do endereço do painel app.netlify.com. Não use uma URL interna do painel como link do aplicativo.

ANDROID STUDIO:
Abra a pasta geocromo_android como projeto existente no Android Studio e aguarde a sincronização Gradle.

Observação: este ZIP contém o projeto-fonte Android e a versão web estática. Ele não contém APK já compilado.

Atualização v1.3: stop loss removido. A posição é mantida enquanto a dominância dos blocos permanece igual e invertida quando muda. Vértices deduplicados com tolerância numérica e marcados no gráfico (U/T); limitadores aparecem em verde (L).

Atualização v1.4: critério de entrada corrigido. Antes, os 3 vértices de cada triângulo precisavam estar dentro dos 26 candles do bloco, o que deixava a dominância indefinida em ~95% dos blocos (quase nenhuma operação). Agora há o campo 'Tolerância de vértices fora do bloco' (padrão 26 candles; 0 restaura o comportamento antigo). O limite de 26 candles continua valendo para os limitadores (L) e para os níveis de toque.


Atualização v1.5:
1) STOP LOSS: campo 'Stop loss (% além dos vértices)', padrão 10%. A referência é o vértice mais desfavorável entre os 6 vértices (U e T) do bloco sinalizador: o mais baixo para posição comprada, o mais alto para vendida (se a entrada já estiver além dele, vale o preço de entrada). O stop fica X% além dessa referência. É checado pelas mínimas/máximas de cada candle; em caso de gap, a saída é na abertura. Após o stop, a posição fica zerada até o próximo fechamento de bloco. 0 = sem stop.
2) REVERSÃO: campo 'Reverter se abertura e fechamento ficarem além dos vértices' (Ativado/Desativado). Se abertura E fechamento de um candle ficarem ambos abaixo do vértice mais baixo (comprado) ou ambos acima do vértice mais alto (vendido), a posição é encerrada no fechamento e a oposta é aberta no mesmo preço, até o próximo fechamento de bloco. No mesmo candle, o stop vale antes da reversão.
3) Com stop = 0 e reversão desativada, o resultado é idêntico ao da v1.4 (verificado em dados sintéticos).
4) Correção: a tabela 'Resultados por bloco' e as métricas estavam sendo sobrescritas por uma definição duplicada e escondiam entrada/resultado. Agora mostram operações, taxa de acerto, resultado médio, stops e reversões.
5) Os CSVs exportados ganharam as colunas stops e reversoes (no CSV por bloco, também 'eventos').

Atualização v1.6: nova seção '1b. Otimizador'. Baixa os ativos da lista multiativos e simula 64 configurações: stop (sem stop, 3, 5, 7,5, 10, 15, 20, 30%) x reversão (sim/não) x tolerância de vértices (0, 13, 26, 52). Os 60% primeiros blocos de cada ativo são o treino (usado na ordenação) e os 40% finais o teste. A linha 'sem stop, sem reversão, tol. 26' reproduz exatamente a v1.4 (verificado). Botões: aplicar a melhor configuração aos campos e exportar CSV (geocromoindicador-otimizador.csv). Sem taxas nem slippage.
