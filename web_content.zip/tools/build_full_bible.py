#!/usr/bin/env python3
"""Import and embed eBible.org's public-domain French Louis Segond 1910 corpus.
Usage: python3 tools/build_full_bible.py /path/to/fraLSG_html.zip
Requires beautifulsoup4: python3 -m pip install beautifulsoup4
"""
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path
from zipfile import ZipFile
from bs4 import BeautifulSoup, Tag

PROJECT = Path(__file__).resolve().parents[1]
STANDALONE = Path('/home/ubuntu/index.html')
SOURCE_URL = 'https://ebible.org/Scriptures/fraLSG_html.zip'


def app_books(html: str) -> list[tuple[str, int]]:
    match = re.search(r'const BOOKS=\[(.*?)\];', html, re.S)
    if not match:
        raise RuntimeError('BOOKS catalogue not found')
    books = re.findall(r"\['([^']+)',\s*'(?:AT|NT)',\s*(\d+)\]", match.group(1))
    if len(books) != 66:
        raise RuntimeError(f'Expected 66 app books, found {len(books)}')
    return [(name, int(chapters)) for name, chapters in books]


def verse_text(marker: Tag) -> str:
    parts = []
    for sibling in marker.next_siblings:
        if isinstance(sibling, Tag) and sibling.name == 'span' and 'verse' in (sibling.get('class') or []):
            break
        if isinstance(sibling, Tag):
            fragment = BeautifulSoup(str(sibling), 'html.parser')
            for note in fragment.select('.notemark, .popup'):
                note.decompose()
            parts.append(fragment.get_text('', strip=False))
        else:
            parts.append(str(sibling))
    return re.sub(r'\s+', ' ', ''.join(parts).replace('\xa0', ' ').replace('\u200b', '')).strip()


def extract(zip_path: Path, books: list[tuple[str, int]]) -> tuple[list[dict], dict[str, int]]:
    verses, counts = [], {}
    with ZipFile(zip_path) as archive:
        names = set(archive.namelist())
        index = BeautifulSoup(archive.read('index.htm'), 'html.parser')
        links = [a for a in index.select('.bookList a') if re.fullmatch(r'[^/]+\d+\.htm', a.get('href', ''))]
        if len(links) != 66:
            raise RuntimeError(f'Source index has {len(links)} books, expected 66')
        for (book, chapters), link in zip(books, links):
            m = re.fullmatch(r'(.*?)(\d+)\.htm', link['href'])
            if not m:
                raise RuntimeError(f'Cannot infer chapter filenames from {link["href"]}')
            stem, first_suffix = m.groups()
            book_count = 0
            for chapter in range(1, chapters + 1):
                filename = f'{stem}{chapter:0{len(first_suffix)}d}.htm'
                if filename not in names:
                    raise RuntimeError(f'Missing chapter file {filename}')
                page = BeautifulSoup(archive.read(filename), 'html.parser')
                markers = page.select('span.verse')
                if not markers:
                    raise RuntimeError(f'No verse markers in {filename}')
                numbers = []
                for marker in markers:
                    m = re.fullmatch(r'V(\d+)', marker.get('id', ''))
                    if not m:
                        raise RuntimeError(f'Invalid verse marker in {filename}')
                    number, text = int(m.group(1)), verse_text(marker)
                    if not text:
                        raise RuntimeError(f'Empty verse {book} {chapter}:{number}')
                    numbers.append(number)
                    verses.append({'ref': f'{book} {chapter}:{number}', 'book': book, 'ch': chapter, 'v': number, 'text': text})
                if not numbers or numbers[0] != 1 or numbers != list(range(1, numbers[-1] + 1)):
                    raise RuntimeError(f'Incomplete verse sequence in {filename}: {numbers[:4]} … {numbers[-4:]}')
                book_count += len(numbers)
            counts[book] = book_count
    if len(verses) < 30000 or len({v['ref'] for v in verses}) != len(verses):
        raise RuntimeError(f'Corpus size/reference validation failed: {len(verses)} verses')
    return verses, counts


def update_html(path: Path, verses: list[dict]) -> None:
    html = path.read_text(encoding='utf-8')
    html, viewport_count = re.subn(
        r'<meta name="viewport" content="[^"]*">',
        '<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">',
        html,
        count=1,
    )
    if viewport_count != 1:
        raise RuntimeError(f'Viewport meta tag not found in {path}')
    payload = json.dumps(verses, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    corpus_tag = f'<script type="application/json" id="bibleCorpus">{payload}</script>\n'
    html = re.sub(r'<script type="application/json" id="bibleCorpus">.*?</script>\s*', '', html, count=1, flags=re.S)
    html, count = re.subn(r'(<script>\s*\(\(\)=>\{)', lambda m: corpus_tag + m.group(1), html, count=1)
    if count != 1:
        raise RuntimeError(f'Application script not found in {path}')

    if 'const VERSES=JSON.parse(document.getElementById(\'bibleCorpus\').textContent);' not in html:
        old = re.search(r'// Sample quotations only\..*?const VERSES=\[.*?\n\];', html, re.S)
        if not old:
            old = re.search(r'const VERSES=\[.*?\n\];', html, re.S)
        if not old:
            raise RuntimeError(f'Could not find the sample VERSES array in {path}')
        new = "const VERSES=JSON.parse(document.getElementById('bibleCorpus').textContent);\nconst VERSE_BY_REFERENCE=new Map(VERSES.map(v=>[norm(v.ref).replace(/\\s/g,''),v]));\nconst VERSES_BY_CHAPTER=new Map();for(const v of VERSES){const key=`${v.book}|${v.ch}`;if(!VERSES_BY_CHAPTER.has(key))VERSES_BY_CHAPTER.set(key,[]);VERSES_BY_CHAPTER.get(key).push(v)}"
        html = html[:old.start()] + new + html[old.end():]

    replacements = {
        'Le texte embarqué est un échantillon de démonstration.': 'Texte complet Louis Segond 1910, disponible hors ligne.',
        'Recherchez dans les versets de l’échantillon embarqué ou ouvrez une référence connue.': 'Recherchez un mot, une référence ou un chapitre dans les 66 livres, même hors ligne.',
        'Une aide hors ligne fondée sur un petit ensemble de réponses et de versets intégrés. YELE n’est pas une IA générale et peut se tromper.': 'Un compagnon biblique hors ligne qui peut rechercher les 66 livres et répondre à des questions courantes. YELE n’est pas une IA générale et peut se tromper.',
        'Questions de démonstration — votre meilleur score reste sur l’appareil.': 'Répondez aux questions bibliques ; votre meilleur score reste sur cet appareil.',
        'Prototype hors ligne · v1.0': 'Bible complète hors ligne · v1.1.0',
        'Le texte de ce chapitre n’est pas inclus dans cet échantillon de démonstration.': 'Aucun verset n’est disponible pour ce chapitre dans le corpus local.',
        'Ce mode ne filtre pas encore automatiquement un corpus intégral.': 'Les histoires sont adaptées pour les enfants ; lisons et jouons ensemble avec un adulte.',
        'étapes de démonstration': 'étapes',
        '(Le texte intégral de ces chapitres n’est pas embarqué ici.)': 'Tu peux lire ces chapitres dans le lecteur biblique.',
        'Compagnon biblique local': 'Compagnon biblique hors ligne',
        'Disponible hors ligne · réponses locales': 'Hors ligne · Bible complète intégrée',
        '<p class="small muted" style="margin-top:18px">Créateur : JOSIAS MAYELE NYEMBO · YELE COMPAGNIE BY JMN · Kinseso, RDC</p>': '<p class="small muted" style="margin-top:18px">Créateur : JOSIAS MAYELE NYEMBO · YELE COMPAGNIE BY JMN · Kinseso, RDC</p><p class="small muted">Texte biblique : Louis Segond 1910, corpus téléchargé depuis <a href="https://ebible.org/fraLSG/" target="_blank" rel="noopener">eBible.org</a>. La page de droits eBible.org déclare cette édition dans le domaine public.</p>',
    }
    for old_text, new_text in replacements.items():
        html = html.replace(old_text, new_text)
    html = html.replace('let arr=VERSES.filter(v=>v.book===book[0]&&v.ch===ch);', 'let arr=VERSES_BY_CHAPTER.get(`${book[0]}|${ch}`)||[];')
    html = html.replace("$('corpusNotice').textContent=arr.length?'Extrait de démonstration ; le texte intégral de ce livre n’est pas embarqué.':'Corpus incomplet : cette application ne contient pas encore les textes intégraux.';", "$('corpusNotice').textContent=arr.length?'Louis Segond 1910 · chapitre complet · '+arr.length+' versets':'Aucun verset trouvé dans le corpus local.';")

    search_function = r'''function parseBibleReference(query){
 let q=norm(query).replace(/[.,]/g,' ').replace(/\s+/g,' ').trim();
 let names=[];for(const b of BOOKS){let aliases=[norm(b[0])];if(b[0]==='Psaumes')aliases.push('psaume');if(b[0]==='Cantique des Cantiques')aliases.push('cantique','cantique des cantiques');for(const a of aliases)names.push({book:b[0],alias:a})}
 names.sort((a,b)=>b.alias.length-a.alias.length);
 for(const item of names){if(q!==item.alias&&!q.startsWith(item.alias+' '))continue;let tail=q.slice(item.alias.length).replace(/^[:\s]+/,'');let m=tail.match(/^(\d{1,3})(?:\s*:\s*(\d{1,3})(?:\s*-\s*(\d{1,3}))?)?$/);if(m)return{book:item.book,ch:+m[1],verse:m[2]?+m[2]:null,end:m[3]?+m[3]:null}}
 return null
}
function doSearch(q){q=q.trim();if(!q){$('searchResults').innerHTML='<div class="empty">Saisissez un mot, un thème ou une référence.</div>';return}let n=norm(q),ref=parseBibleReference(q),res=[];if(ref){let chapter=VERSES_BY_CHAPTER.get(`${ref.book}|${ref.ch}`)||[];res=ref.verse===null?chapter:chapter.filter(v=>v.v>=ref.verse&&v.v<=(ref.end||ref.verse))}else res=VERSES.filter(v=>norm(v.ref+' '+v.text+' '+v.book).includes(n));let total=res.length,shown=res.slice(0,60);$('searchResults').innerHTML=shown.length?`<div class="small muted">${total} résultat${total===1?'':'s'}${total>60?' · 60 premiers affichés':''}</div>`+shown.map(v=>`<article class="result"><strong>${esc(v.ref)}</strong><p>${esc(v.text)}</p><button class="btn btn-outline btn-small" data-result="${esc(v.ref)}">Ouvrir dans le lecteur</button> <button class="btn btn-outline btn-small" data-addfav="${esc(v.ref)}">♡ Favori</button></article>`).join(''):'<div class="empty panel">Aucun résultat. Vérifiez l’orthographe ou la référence biblique.</div>';document.querySelectorAll('[data-result]').forEach(b=>b.onclick=()=>{let v=VERSE_BY_REFERENCE.get(norm(b.dataset.result).replace(/\s/g,''));if(v){state.readPos={book:v.book,ch:v.ch};save();go('reader')}});document.querySelectorAll('[data-addfav]').forEach(b=>b.onclick=()=>{let v=VERSE_BY_REFERENCE.get(norm(b.dataset.addfav).replace(/\s/g,''));if(v&&!state.favorites.some(x=>x.ref===v.ref)){state.favorites.unshift(v);save();toast('Favori enregistré')}})}'''
    # Remove the previously inserted reference parser, then replace the search function once.
    html = re.sub(r'function parseBibleReference\(query\)\{.*?\n\}(?=\nfunction doSearch\(q\))', '', html, count=1, flags=re.S)
    html, count = re.subn(r'function doSearch\(q\)\{.*?\n\$\(\'searchForm\'\)', lambda _: search_function + "\n$('searchForm')", html, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f'Could not replace search function in {path}')

    yele_prefix = 'function yeleAnswerBase(q){let n=norm(q),name=state.username?` ${state.username}`:\'\';let localFact=answerKnowledge(q,n);if(localFact)return localFact;'
    if yele_prefix not in html:
        raise RuntimeError(f'YELE answer function not found in {path}')
    if 'let ref=parseBibleReference(q);if(ref){let chapter=VERSES_BY_CHAPTER' not in html:
        yele_reader = "let ref=parseBibleReference(q);if(ref){let chapter=VERSES_BY_CHAPTER.get(`${ref.book}|${ref.ch}`)||[];let selected=ref.verse===null?chapter.filter(v=>v.v<=5):chapter.filter(v=>v.v>=ref.verse&&v.v<=(ref.end||ref.verse));if(selected.length){if(ref.verse===null)return `${ref.book} ${ref.ch} contient ${chapter.length} versets. En voici les premiers :\\n\\n`+selected.map(v=>`${v.ref} — ${v.text}`).join('\\n\\n')+(chapter.length>selected.length?'\\n\\nOuvre ce chapitre dans le lecteur pour lire la suite.':'');return selected.map(v=>`${v.ref} — ${v.text}`).join('\\n\\n')}};"
        html = html.replace(yele_prefix, yele_prefix + yele_reader, 1)
    html = html.replace("$('quickSearch').addEventListener('input',e=>{if(e.target.value.length>2){$('searchInput').value=e.target.value;go('search');doSearch(e.target.value)}});", '')
    path.write_text(html, encoding='utf-8')


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 tools/build_full_bible.py /path/to/fraLSG_html.zip')
    zip_path = Path(sys.argv[1]).resolve()
    if not zip_path.is_file():
        raise SystemExit(f'Source archive not found: {zip_path}')
    books = app_books((PROJECT / 'web/index.html').read_text(encoding='utf-8'))
    verses, counts = extract(zip_path, books)
    for target in (PROJECT / 'index.html', PROJECT / 'web/index.html', STANDALONE):
        if target.exists():
            update_html(target, verses)
    summary = {
        'translation': 'Louis Segond 1910', 'source': SOURCE_URL,
        'source_zip_sha256': hashlib.sha256(zip_path.read_bytes()).hexdigest(),
        'rights_notice': 'eBible.org declares this edition public domain on its copyright page.',
        'books': len(books), 'chapters': sum(chapters for _, chapters in books),
        'verses': len(verses), 'per_book_verse_counts': counts,
    }
    (PROJECT / 'legal').mkdir(exist_ok=True)
    (PROJECT / 'legal/LSG1910-PROVENANCE.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'Validated and embedded {len(verses):,} verses across {len(books)} books and {sum(c for _, c in books)} chapters.')
    print(f'Source: {SOURCE_URL}')

if __name__ == '__main__':
    main()
