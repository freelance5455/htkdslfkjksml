const fs=require('fs'),path=require('path'),cp=require('child_process');
const P='/home/user/project';
let bad=0;
const htmls=fs.readdirSync(P).filter(f=>f.endsWith('.html'));
const jss=fs.readdirSync(P).filter(f=>f.endsWith('.js'));
for(const j of jss){try{cp.execSync(`node --check ${path.join(P,j)}`,{stdio:'pipe'});}catch(e){console.log('SYNTAX FAIL',j,String(e.stderr).split('\n')[2]);bad++;}}
for(const h of htmls){
  const s=fs.readFileSync(path.join(P,h),'utf8');
  const ids=[...s.matchAll(/\sid="([^"]+)"/g)].map(m=>m[1]);
  const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);
  if(dup.length){console.log('DUP IDS',h,[...new Set(dup)].join(','));bad++;}
  const links=[...s.matchAll(/href="([^"#?:]+\.html)/g)].map(m=>m[1]);
  for(const l of new Set(links)) if(!fs.existsSync(path.join(P,l))){console.log('BROKEN LINK',h,'->',l);bad++;}
  const srcs=[...s.matchAll(/(?:src|href)="((?!https?:|data:|#)[^"]+\.(?:js|css|jpeg|jpg|png))"/g)].map(m=>m[1]);
  for(const r of new Set(srcs)) if(!fs.existsSync(path.join(P,r))){console.log('MISSING ASSET',h,'->',r);bad++;}
  if(!/<title>/.test(s)){console.log('NO TITLE',h);bad++;}
}
const allJs=jss.map(j=>fs.readFileSync(path.join(P,j),'utf8')).join('\n');
const allHtml=htmls.map(h=>fs.readFileSync(path.join(P,h),'utf8')).join('\n');
const refs=[...new Set([...allJs.matchAll(/getElementById\('([^']+)'\)/g)].map(m=>m[1]))];
const missing=refs.filter(id=>!allHtml.includes('id="'+id+'"')&&!allJs.includes('id="'+id+'"'));
if(missing.length){console.log('IDS NEVER IN DOM:',missing.join(','));}
for(const j of jss){const s=fs.readFileSync(path.join(P,j),'utf8');
  if(/console\.(log|error|warn|info)/.test(s)){console.log('CONSOLE IN',j);bad++;}
  if(/\/\*/.test(s)){console.log('BLOCK COMMENT IN',j);bad++;}}
for(const h of htmls){if(fs.readFileSync(path.join(P,h),'utf8').includes('<!--')){console.log('HTML COMMENT',h);bad++;}}
console.log(bad?('ISSUES: '+bad):'VERIFY CLEAN');
