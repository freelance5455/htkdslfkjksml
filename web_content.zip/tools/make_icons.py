import math
from PIL import Image, ImageDraw
# Geometri tunggal untuk SVG & PNG: ular S-melingkar, kepala bulat + mata. Kanvas 512.
pts=[(150+i*(212/40), 0) for i in range(41)]
def curve():
    out=[]
    # jalur S: tiga busur sinus vertikal
    for i in range(0,121):
        t=i/120
        x=130+252*t
        y=256+120*math.sin(t*math.pi*2.0+math.pi)
        out.append((x,y))
    return out
C=curve(); W=62
def fg_svg(bg=True):
    d=" ".join(("M" if i==0 else "L")+f"{x:.1f} {y:.1f}" for i,(x,y) in enumerate(C))
    hx,hy=C[-1]
    s=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">'
    if bg: s+='<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1f9d57"/><stop offset="1" stop-color="#0b3d24"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/>'
    s+=f'<path d="{d}" fill="none" stroke="#eaffd0" stroke-width="{W+14}" stroke-linecap="round" stroke-linejoin="round" opacity="0.25"/>'
    s+=f'<path d="{d}" fill="none" stroke="#3ddc84" stroke-width="{W}" stroke-linecap="round" stroke-linejoin="round"/>'
    s+=f'<path d="{d}" fill="none" stroke="#c8ff9a" stroke-width="12" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="2 34" opacity="0.8"/>'
    s+=f'<circle cx="{hx:.1f}" cy="{hy:.1f}" r="46" fill="#2bc26f"/><circle cx="{hx+14:.1f}" cy="{hy-16:.1f}" r="11" fill="#fff"/><circle cx="{hx+14:.1f}" cy="{hy+16:.1f}" r="11" fill="#fff"/><circle cx="{hx+17:.1f}" cy="{hy-16:.1f}" r="5" fill="#0b2a18"/><circle cx="{hx+17:.1f}" cy="{hy+16:.1f}" r="5" fill="#0b2a18"/>'
    s+=f'<path d="M{hx+44:.1f} {hy:.1f} l34 0 m0 0 l12 -9 m-12 9 l12 9" stroke="#ff5a5a" stroke-width="7" fill="none" stroke-linecap="round"/>'
    return s+'</svg>\n'
def render(size, bg=True, scale=1.0):
    S=size*2; im=Image.new("RGBA",(S,S),(0,0,0,0)); d=ImageDraw.Draw(im); k=S/512
    cx=cy=256
    P=[((x-cx)*scale+cx, (y-cy)*scale+cy) for x,y in C]
    if bg:
        # gradient diagonal
        g=Image.new("RGBA",(S,S))
        gp=g.load()
        for yy in range(S):
            for xx in range(S):
                t=(xx+yy)/(2*S); gp[xx,yy]=(int(31+(11-31)*t),int(157+(61-157)*t),int(87+(36-87)*t),255)
        mask=Image.new("L",(S,S),0); ImageDraw.Draw(mask).rounded_rectangle((0,0,S,S),radius=int(112*k),fill=255)
        im.paste(g,(0,0),mask); d=ImageDraw.Draw(im)
    def line(col,w,alpha=255):
        r=w*scale*k/2
        for (x,y) in P:
            d.ellipse((x*k-r,y*k-r,x*k+r,y*k+r),fill=col+(alpha,))
    line((234,255,208),W+14,70); line((61,220,132),W)
    hx,hy=P[-1]; hr=46*scale*k
    d.ellipse((hx*k-hr,hy*k-hr,hx*k+hr,hy*k+hr),fill=(43,194,111,255))
    for dy in(-16,16):
        ex,ey=(hx+14*scale)*k,(hy+dy*scale)*k; r=11*scale*k
        d.ellipse((ex-r,ey-r,ex+r,ey+r),fill=(255,255,255,255)); r2=5*scale*k; ex2=(hx+17*scale)*k
        d.ellipse((ex2-r2,ey-r2,ex2+r2,ey+r2),fill=(11,42,24,255))
    d.line(((hx+44*scale)*k,hy*k,(hx+78*scale)*k,hy*k),fill=(255,90,90,255),width=int(7*scale*k))
    return im.resize((size,size),Image.LANCZOS)
import os
o="assets/icons/"
open(o+"snake-logo.svg","w").write(fg_svg(True))
open(o+"favicon.svg","w").write(fg_svg(True))
open(o+"android-adaptive-foreground.svg","w").write(fg_svg(False))
render(512).save(o+"app-icon-512.png"); render(192).save(o+"app-icon-192.png"); render(48).save(o+"favicon.png")
render(432,False,0.62).save(o+"android-adaptive-foreground-432.png")  # zona aman 66%
Image.new("RGBA",(432,432),(15,100,60,255)).save(o+"android-adaptive-background-432.png")
for n,sz in (("mdpi",48),("hdpi",72),("xhdpi",96),("xxhdpi",144),("xxxhdpi",192)):
    os.makedirs(o+"android/mipmap-"+n,exist_ok=True); render(sz).save(o+f"android/mipmap-{n}/ic_launcher.png")
print(sorted(os.listdir(o)))
