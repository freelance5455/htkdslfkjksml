#!/usr/bin/env python3
"""Genera los sprites animados de los 4 personajes jugables que no tenían (vista lateral, mirando a la derecha):
   gotin (Brea viva) · cristalin (Prisma) · umbrio (Hueco) · dragon (Singular)
Formato idéntico a los Tiny Hero ya incluidos: una hoja por animación, fotogramas de 32x32 en fila
   <id>_idle.png (4) · <id>_walk.png (6) · <id>_attack.png (6) · <id>_hurt.png (4)
Uso: python3 tools/gen_heroes.py   (requiere Pillow). Determinista."""
import math, os
from PIL import Image, ImageDraw
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','assets','heroes')
NAVY=(20,22,48,255)
def C(h,a=255): h=h.lstrip('#'); return (int(h[0:2],16),int(h[2:4],16),int(h[4:6],16),a)

class F:
    def __init__(s): s.im=Image.new('RGBA',(32,32),(0,0,0,0)); s.d=ImageDraw.Draw(s.im)
    def e(s,cx,cy,rx,ry,c): s.d.ellipse([cx-rx,cy-ry,cx+rx,cy+ry],fill=c)
    def p(s,pts,c): s.d.polygon([(round(x),round(y)) for x,y in pts],fill=c)
    def r(s,x0,y0,x1,y1,c): s.d.rectangle([round(x0),round(y0),round(x1),round(y1)],fill=c)
    def px(s,x,y,c):
        x,y=round(x),round(y)
        if 0<=x<32 and 0<=y<32: s.im.putpixel((x,y),c)
    def l(s,x0,y0,x1,y1,c,w=1): s.d.line([(round(x0),round(y0)),(round(x1),round(y1))],fill=c,width=w)
    def finish(s,flash=False,alpha=1.0):
        a=s.im.split()[3]; w,h=s.im.size; src=a.load(); out=s.im.copy(); o=out.load(); px=s.im.load()
        for y in range(h):
            for x in range(w):
                if src[x,y]==0:
                    for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
                        nx,ny=x+dx,y+dy
                        if 0<=nx<w and 0<=ny<h and src[nx,ny]>0: o[x,y]=NAVY; break
                elif flash: o[x,y]=(255,255,255,255) if src[x,y]>0 and not (px[x,y][:3]==NAVY[:3]) else o[x,y]
        if alpha<1:
            for y in range(h):
                for x in range(w):
                    r,g,b,aa=o[x,y]; o[x,y]=(r,g,b,int(aa*alpha))
        return out

def sheet(name,frames):
    im=Image.new('RGBA',(32*len(frames),32),(0,0,0,0))
    for i,f in enumerate(frames): im.paste(f,(i*32,0))
    im.save(os.path.join(OUT,name+'.png'),optimize=True)

wave=lambda i,n,k=1,ph=0: math.sin((i/n)*6.2832*k+ph)
# ===================================== BREA VIVA (agua) =====================================
B0,B1,B2,BH=C('#2b4f66'),C('#16293a'),C('#7fe0d0'),C('#d9fff6'); BM=C('#3a6a85')
def brea(sx=1.0,sy=1.0,lift=0,lean=0,mouth=0,bub=0,drops=None,eye=0,squint=False):
    f=F(); cx=14+lean; base=30-lift; rx=10*sx; ry=11*sy; cy=base-ry+2
    f.e(cx,cy,rx,ry,B1); f.e(cx-1,cy-1,rx-1.5,ry-1.5,B0)                      # cuerpo
    f.r(cx-rx-1,base+1,cx+rx+1,32,(0,0,0,0)) if False else None
    f.e(cx-3,cy-3,rx*.5,ry*.42,BM)                                              # zona clara
    f.e(cx-4,cy-5,2.2,1.4,BH); f.px(cx-6,cy-3,BH)                               # brillo
    for k,dx in enumerate((-7,-3,2,6)):                                          # pliegue inferior ondulado
        f.e(cx+dx*sx,base-0.5,2.2,1.6+0.6*math.sin(bub*2+k),B1)
    f.e(cx+8*sx,cy+3,2,3,B1); f.e(cx-9*sx,cy+4,1.6,2.4,B1)                     # goteos laterales
    ex=cx+5*sx; ey=cy-3                                                          # ojos
    if squint:
        f.l(ex-5,ey-1,ex-1,ey+1,C('#0b1620'),2); f.l(ex+1,ey+1,ex+5,ey-1,C('#0b1620'),2)
    else:
        for ox in(-3.5,3.0): f.e(ex+ox,ey,2.6,3.2,C('#f2fffc')); f.e(ex+ox+1.2+eye,ey+.5,1.3,1.8,C('#10202e'))
    if mouth: f.e(ex+1,cy+4.5,2.4+mouth,1.6+mouth*.7,C('#0b1620')); f.px(ex+2,cy+4,B2)
    else: f.l(ex-1,cy+5,ex+3,cy+5,C('#0b1620'),1)
    for i,(bx,by,br) in enumerate(((cx-7,max(4,cy-12-bub*3),1.4),(cx+3,max(4,cy-14-bub*2+1),1.0))):                    # burbujas
        if bub>0: f.d.ellipse([bx-br,by-br,bx+br,by+br],outline=B2)
    for (dx,dy,r_) in (drops or []): f.e(dx,dy,r_,r_*.8,B2); f.px(dx-1,dy-1,BH)
    return f
def brea_frames():
    idle=[brea(1+.03*wave(i,4),1-.04*wave(i,4),bub=i/4) for i in range(4)]
    seq=[(1.10,.88,0),(.95,1.06,2),(.90,1.10,4),(.95,1.04,2),(1.12,.86,0),(1.04,.94,0)]
    walk=[brea(a,b,lift=c,lean=1,bub=i/6) for i,(a,b,c) in enumerate(seq)]
    att=[brea(1.18,.82,0,lean=-1,mouth=0,bub=.2),brea(1.1,.92,0,lean=0,mouth=0,eye=.5),
         brea(.9,1.1,2,lean=2,mouth=1.2,drops=[(26,18,1.4)]),brea(.94,1.06,1,lean=1,mouth=1.6,drops=[(28,17,2),(24,22,1.2)]),
         brea(1.0,1.0,0,lean=1,mouth=.8,drops=[(30,19,1.2)]),brea(1.04,.96,0,lean=0)]
    hurt=[brea(1.22,.78,0,lean=-2,squint=True),brea(1.22,.78,0,lean=-2,squint=True),brea(.96,1.06,1,lean=-1,squint=True),brea(1.04,.96,0,lean=0)]
    return idle,walk,att,hurt,[0,0,0,0,0,0]
# ===================================== PRISMA (hielo) =====================================
P0,P1,P2,PL=C('#5bbad6'),C('#2b6b88'),C('#d4f6ff'),C('#9fe8ff'); PD=C('#17406f')
def prisma(bob=0,shard=0,arm=0,flash=0,crack=False,glow=0,step=0,shake=0,spike=0):
    f=F(); cx=14+shake; by=-bob+.5
    for sgn,ph in((0,0),(1,2.1),(2,4.2)):                                       # esquirlas orbitando
        a=shard+ph; ox=cx+math.cos(a)*11+(arm*7 if sgn==0 else 0); oy=15+by+math.sin(a)*4-(5 if sgn==1 else 0)
        f.p([(ox,oy-3),(ox+2,oy),(ox,oy+3),(ox-2,oy)],PL); f.px(ox,oy-1,P2)
    f.p([(cx-5,29),(cx-1,29),(cx-2,32),(cx-6,32)],PD) if False else None
    for dx,st in((-4,0),(3,1)):                                                  # pies de cristal
        yy=28+by*0+(-1 if (step and st==step) else 0); f.p([(cx+dx-3,yy+1),(cx+dx+3,yy+1),(cx+dx+2,yy+4),(cx+dx-2,yy+4)],P1)
    f.p([(cx,12+by),(cx+9,19+by),(cx+6,29+by),(cx-6,29+by),(cx-9,19+by)],P0)   # torso facetado
    f.p([(cx,12+by),(cx+9,19+by),(cx+6,29+by),(cx,29+by)],P1)                   # mitad sombra
    f.p([(cx,12+by),(cx-9,19+by),(cx-4,21+by),(cx,16+by)],PL)                   # faceta clara
    f.p([(cx-1,19+by),(cx+3,22+by),(cx,26+by),(cx-3,22+by)],C('#ffffff') if glow else P2)   # núcleo
    f.p([(cx,3+by),(cx+6,9+by),(cx+4,15+by),(cx-4,15+by),(cx-6,9+by)],P0)      # cabeza
    f.p([(cx,3+by),(cx+6,9+by),(cx+4,15+by),(cx,15+by)],P1); f.p([(cx,3+by),(cx-6,9+by),(cx-2,9+by)],PL)
    for ox in(1,5): f.r(cx+ox,9+by,cx+ox+1,11+by,PD); f.px(cx+ox+1,9+by,C('#ffffff'))   # ojos
    if spike:
        sx=cx+10; f.p([(sx,19+by),(sx+spike,21+by),(sx,23+by)],PL); f.p([(sx,21+by),(sx+spike,21+by),(sx,23+by)],P0); f.px(sx+1,21+by,P2)
    if crack:
        f.l(cx-2,13+by,cx+1,18+by,PD); f.l(cx+1,18+by,cx-1,22+by,PD); f.l(cx+4,21+by,cx+5,27+by,PD)
    return f
def prisma_frames():
    idle=[prisma(bob=.7+.5*wave(i,4),shard=i*.8) for i in range(4)]
    walk=[prisma(bob=.5+1.2*abs(wave(i,6,.5)),shard=i*1.0,step=1+(i%2)) for i in range(6)]
    att=[prisma(shard=0,arm=-.4),prisma(shard=.5,arm=0,glow=1),prisma(shard=1,arm=1,glow=1,spike=5),prisma(shard=1.4,arm=1.5,glow=1,spike=9),prisma(shard=1.8,arm=1,glow=1,spike=5),prisma(shard=2.2,arm=.3)]
    hurt=[prisma(shake=-2,crack=True),prisma(shake=-1,crack=True,glow=1),prisma(shake=1,crack=True),prisma(shard=1,crack=True)]
    return idle,walk,att,hurt,[0,0,0,0,0,0]
# ===================================== HUECO (sombra) =====================================
H0,H1,H2,HC=C('#4a3270'),C('#241838'),C('#6b4aa0'),C('#ff5f7a'); HV=C('#0a0614')
def hueco(bob=0,hem=0,arm=0,orb=0,flare=0,lean=0,wisp=0):
    f=F(); cx=12+lean; by=-bob+1.5
    for k in range(3):                                                           # volutas traseras
        if wisp: f.e(cx-11-k*3,20+by+math.sin(hem*2+k)*2,1.6-.3*k,1.2,H1)
    pts=[(cx-6,12+by),(cx+6,12+by),(cx+10,30+by),(cx-10,30+by)]
    f.p(pts,H0); f.p([(cx,12+by),(cx+6,12+by),(cx+10,30+by),(cx+1,30+by)],H1)  # túnica y sombra
    for k in range(7):                                                           # dobladillo desgarrado
        x0=cx-10+k*3; yy=30+by+(2 if (k+int(hem*3))%2 else 0)*0+round(math.sin(hem*2+k)*1.5)
        f.p([(x0,28+by),(x0+3,28+by),(x0+1.5,min(31,yy+1))],H0 if k%2 else H1)
    f.e(cx,9+by,6.5,6.5,H0); f.e(cx+1,9+by,5,5,H1)                               # capucha
    f.p([(cx-6,6+by),(cx-1,2+by),(cx-4,9+by)],H2)                               # reflejo
    f.e(cx+2,10+by,3.6,4,HV)                                                    # rostro vacío
    for ox in(1,4):
        f.r(cx+ox,9+by,cx+ox+1,10+by+(1 if flare else 0),HC); 
        if flare: f.px(cx+ox,8+by,C('#ffd0da'))
    # brazo/manga que se extiende al atacar
    ax=cx+5+arm*5; f.p([(cx+4,17+by),(ax,17+by+arm*-1),(ax,20+by),(cx+4,21+by)],H0); f.r(ax,17+by-arm,ax+2,19+by,H2)
    if orb:
        ox=ax+3+orb*1.2; r=1.4+orb*1.0
        f.e(ox,18+by,r,r,C('#7a3fb8')); f.e(ox,18+by,r*.6,r*.6,HC); f.px(ox,18+by,C('#ffe0e8'))
    return f
def hueco_frames():
    idle=[hueco(bob=.7+.5*wave(i,4),hem=i*.8) for i in range(4)]
    walk=[hueco(bob=.5+.8*abs(wave(i,6,.5)),hem=i*1.0,lean=1,wisp=1) for i in range(6)]
    att=[hueco(arm=0,hem=0),hueco(arm=.5,orb=0,flare=1),hueco(arm=1,orb=1,flare=1,hem=1),hueco(arm=1,orb=2,flare=1,hem=2),hueco(arm=1,orb=2.6,flare=1,hem=3),hueco(arm=.3,hem=4)]
    hurt=[hueco(lean=-2,flare=1),hueco(lean=-2,flare=1),hueco(lean=-1),hueco(lean=0)]
    return idle,walk,att,hurt,[0,0,0,0,0,0]
# ===================================== SINGULAR (dragón) =====================================
D0,D1,D2,DG=C('#8a5fd1'),C('#42286e'),C('#b394f0'),C('#ffd66e'); DB=C('#f4e2b0'); DW=C('#5c3b9a')
def dragon(bob=0,leg=0,tail=0,wing=0,head=0,fire=0,lean=0,squint=False,jaw=0):
    f=F(); cx=10+lean; by=-bob+1
    ty=19+by+tail*2                                                                                # cola enroscada hacia arriba
    f.p([(cx-5,21+by),(cx-9,23+by),(cx-11,ty+1),(cx-9,ty-1),(cx-8,22+by)],D1); f.e(cx-6,22+by,3,2.2,D0)
    f.p([(cx-12,ty-1),(cx-9,ty-3),(cx-9,ty+1)],DG)
    wy=4+wing*3                                                                                    # ala (detrás del torso, bien visible)
    f.p([(cx-1,15+by),(cx-7,wy+by),(cx-10,wy+5+by),(cx-6,wy+6+by),(cx-5,wy+10+by),(cx,16+by)],DW)
    f.l(cx-1,15+by,cx-7,wy+by,D2); f.l(cx-7,wy+by,cx-10,wy+5+by,D2); f.l(cx-4,14+by,cx-6,wy+6+by,D1)
    for dx,st in((-3,0),(3,1)):                                                                    # patas
        up=-2 if (leg and ((st+int(leg))%2==0)) else 0
        f.r(cx+dx-1,25+by,cx+dx+2,29+up,D1); f.r(cx+dx-1,28+up,cx+dx+3,29+up,DB)
    f.e(cx+1,20+by,7,6.5,D1); f.e(cx,19+by,6.3,5.8,D0)                                              # torso
    f.e(cx+2,21+by,4,4,DB); f.l(cx,19+by,cx+5,19+by,C('#e8d3a0'))                                  # vientre
    hx=cx+6; hy=11+by+head                                                                          # cabeza
    f.e(hx,hy,5,4.6,D1); f.e(hx-.5,hy-.5,4.3,3.9,D0)
    f.p([(hx+2,hy-1),(hx+8,hy+1),(hx+8,hy+3),(hx+2,hy+4)],D0); f.r(hx+4,hy+3,hx+8,hy+3+max(jaw,0)+0,DB if not jaw else C('#1a0c24'))
    f.px(hx+7,hy,C('#12081c'))
    f.p([(hx-3,hy-3),(hx-4,hy-7),(hx-1,hy-4)],DB); f.p([(hx+1,hy-4),(hx+2,hy-7),(hx+3,hy-3)],DB)  # cuernos
    if squint: f.l(hx-1,hy-1,hx+3,hy,C('#12081c'),2)
    else: f.e(hx+1.5,hy-1,1.8,2.1,C('#fff4d8')); f.e(hx+2.4,hy-.5,.9,1.2,C('#12081c')); f.px(hx+1,hy-2,C('#ffffff'))
    if fire:
        fx=hx+9
        for k in range(fire):
            r_=1.8+k*1.0; f.e(fx+k*2.0,hy+2+((k%2)*2-1),r_,r_*.85,DG if k%2 else C('#ff8a3c'))
        f.e(fx+.5,hy+2,1.4,1.2,C('#fff6cc'))
    return f
def dragon_frames():
    idle=[dragon(bob=1+wave(i,4)*.8,wing=wave(i,4),tail=wave(i,4,1,1)) for i in range(4)]
    walk=[dragon(bob=.6*abs(wave(i,6,.5)),leg=i,wing=wave(i,6),tail=wave(i,6,1,2),lean=1) for i in range(6)]
    att=[dragon(head=-2,wing=1,lean=-1),dragon(head=-3,wing=1,jaw=1,lean=-2),dragon(head=0,fire=2,jaw=1,wing=-.5,lean=0),dragon(head=0,fire=3,jaw=1,wing=-1),dragon(head=0,fire=2,jaw=1),dragon(head=0,fire=0)]
    hurt=[dragon(lean=-2,squint=True,head=2,wing=-1),dragon(lean=-2,squint=True,head=2),dragon(lean=-1,squint=True),dragon(lean=0)]
    return idle,walk,att,hurt,[0,0,0,0,0,0]

def build(name,fn,flash_hurt=(1,)):
    idle,walk,att,hurt,_=fn()
    def fin(frames,flashes=(),alphas=None):
        return [f.finish(flash=(i in flashes),alpha=(alphas[i] if alphas else 1.0)) for i,f in enumerate(frames)]
    attf=fin(att)
    sheet(name+'_idle',fin(idle)); sheet(name+'_walk',fin(walk)); sheet(name+'_attack',attf)
    sheet(name+'_hurt',fin(hurt,flashes=flash_hurt,alphas=[1,.55,1,1] if name=='umbrio' else None))

if __name__=='__main__':
    build('gotin',brea_frames); build('cristalin',prisma_frames); build('umbrio',hueco_frames); build('dragon',dragon_frames)
    print('ok: 16 hojas en assets/heroes/')
