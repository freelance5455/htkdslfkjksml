/**
 * Engine 7: Ship Name Generator
 * Fandom and relationship ship portmanteaus, celebrity style combos, initials, and hashtag ship titles.
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('ship-form');
  const resultsContainer = document.getElementById('results-list');
  const resultsCountSpan = document.getElementById('results-count');
  const emptyState = document.getElementById('empty-state');
  const resultsCard = document.getElementById('results-card');
  const resetBtn = document.getElementById('reset-btn');
  const copyAllBtn = document.getElementById('copy-all-btn');

  if (!form) return;

  function clean(s) {
    return (s || '').trim().replace(/[^a-zA-Z]/g, '');
  }

  function cap(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : '';
  }

  function generateShipNames(p1, p2, fandomVibe, count) {
    p1 = clean(p1);
    p2 = clean(p2);
    const results = new Set();

    // Classic fandom portmanteau (e.g. Brangelina, Bennifer)
    const cut1 = Math.min(3, Math.ceil(p1.length / 2));
    const cut2 = Math.min(3, Math.ceil(p2.length / 2));

    results.add(cap(p1.slice(0, cut1) + p2.slice(cut2)));
    results.add(cap(p2.slice(0, cut2) + p1.slice(cut1)));
    results.add(cap(p1.slice(0, 2) + p2.slice(-3)));
    results.add(cap(p2.slice(0, 2) + p1.slice(-3)));
    results.add(cap(p1.slice(0, 4) + p2.slice(-2)));
    results.add(cap(p2.slice(0, 4) + p1.slice(-2)));

    // Fandom aesthetic tags
    if (fandomVibe === 'hashtag' || fandomVibe === 'all') {
      results.add(`#Team${cap(p1.slice(0, 3) + p2.slice(-2))}`);
      results.add(`#${cap(p1)}And${cap(p2)}`);
      results.add(`#${cap(p1.slice(0, 3))}${cap(p2.slice(0, 3))}`);
    }

    if (fandomVibe === 'bracket' || fandomVibe === 'all') {
      results.add(`[${p1.charAt(0).toUpperCase()}+${p2.charAt(0).toUpperCase()}] ${cap(p1.slice(0, 3) + p2.slice(-2))}`);
      results.add(`${cap(p1.slice(0, 2))}&${cap(p2.slice(0, 2))}`);
    }

    const output = [];
    results.forEach(r => {
      let score = 90;
      output.push({ name: r, score });
    });

    return output.slice(0, parseInt(count, 10) || 10);
  }

  function render(list) {
    resultsContainer.innerHTML = '';
    if (list.length === 0) {
      emptyState.classList.remove('hidden');
      resultsCard.classList.add('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    resultsCard.classList.remove('hidden');
    resultsCountSpan.textContent = list.length;

    list.forEach((item, index) => {
      const isFav = window.FavoritesManager ? window.FavoritesManager.isFavorite(item.name) : false;
      const card = document.createElement('div');
      card.className = 'result-card flex items-center justify-between p-3.5 sm:p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 shadow-sm animate-fade-in';
      card.innerHTML = `
        <div class="flex items-center gap-3">
          <span class="w-6 text-xs font-bold text-slate-400 dark:text-slate-500">${index + 1}.</span>
          <div>
            <span class="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-wide">${item.name}</span>
            <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-pink-50 text-pink-700 dark:bg-pink-950/50 dark:text-pink-300 border border-pink-200 dark:border-pink-800/50">
              Ship Match
            </span>
          </div>
        </div>
        <div class="flex items-center gap-1.5 sm:gap-2">
          <button type="button" class="copy-single-btn p-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Copy name" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
          </button>
          <button type="button" class="fav-single-btn p-2 text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition ${isFav ? 'text-rose-500 dark:text-rose-400' : ''}" title="Favorite" data-name="${item.name}">
            <svg class="w-4 h-4" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
          </button>
          <button type="button" class="share-single-btn p-2 text-slate-500 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Share" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
          </button>
        </div>
      `;
      resultsContainer.appendChild(card);
    });

    resultsContainer.querySelectorAll('.copy-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.copyToClipboard(btn.dataset.name));
    });

    resultsContainer.querySelectorAll('.fav-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const isAdded = window.FavoritesManager.toggle(name, 'Couple Tools', 'Ship Name Generator');
        const icon = btn.querySelector('svg');
        if (isAdded) {
          btn.classList.add('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'currentColor');
        } else {
          btn.classList.remove('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'none');
        }
      });
    });

    resultsContainer.querySelectorAll('.share-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.shareName(btn.dataset.name, 'Ship Name Generator'));
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const p1 = document.getElementById('char1').value;
    const p2 = document.getElementById('char2').value;
    const fandomVibe = document.getElementById('vibe-select')?.value || 'all';
    const count = document.getElementById('count-select')?.value || 10;

    if (!clean(p1) || !clean(p2)) {
      if (window.showToast) window.showToast('Please enter both characters or partners', 'error');
      return;
    }

    const results = generateShipNames(p1, p2, fandomVibe, count);
    render(results);
    resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      resultsContainer.innerHTML = '';
      resultsCard.classList.add('hidden');
      emptyState.classList.remove('hidden');
    });
  }

  if (copyAllBtn) {
    copyAllBtn.addEventListener('click', () => {
      const names = Array.from(resultsContainer.querySelectorAll('.result-card span.tracking-wide'))
        .map(el => el.textContent.trim());
      if (names.length > 0) {
        window.copyToClipboard(names.join('\n'), `Copied ${names.length} ship names!`);
      }
    });
  }
});
