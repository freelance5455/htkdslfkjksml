#!/usr/bin/env python3
# Buckwalter (ASCII) -> Arabic converter.
# In the BW source file, every Arabic string is wrapped as bw("...").
# Only those strings are converted; ids/keys stay ASCII.
import re, sys

SINGLE = {
    "'": 0x0621, "{": 0x0622, ">": 0x0623, "&": 0x0624, "<": 0x0625, "}": 0x0626,
    "A": 0x0627, "b": 0x0628, "p": 0x0629, "t": 0x062A, "v": 0x062B, "j": 0x062C,
    "H": 0x062D, "x": 0x062E, "d": 0x062F, "*": 0x0630, "r": 0x0631, "z": 0x0632,
    "s": 0x0633, "$": 0x0634, "S": 0x0635, "D": 0x0636, "T": 0x0637, "Z": 0x0638,
    "E": 0x0639, "g": 0x063A, "f": 0x0641, "q": 0x0642, "k": 0x0643, "l": 0x0644,
    "m": 0x0645, "n": 0x0646, "h": 0x0647, "w": 0x0648, "Y": 0x0649, "y": 0x064A,
    "F": 0x064B, "N": 0x064C, "K": 0x064D, "a": 0x064E, "u": 0x064F, "i": 0x0650,
    "~": 0x0651, "o": 0x0652, "_": 0x0640,
}

SENT = "\x00"

def convert(text: str) -> str:
    # protect custom tokens before char conversion
    text = text.replace("[[saw]]", SENT).replace("{X}", "\x01")
    out = []
    for ch in text:
        out.append(chr(SINGLE[ch]) if ch in SINGLE else ch)
    s = "".join(out)
    s = s.replace("?", "\u061F")   # -> ؟
    s = s.replace(",", "\u060C")   # -> ،
    s = s.replace(SENT, "\uFDFA").replace("\x01", "{X}")  # restore placeholder
    return s

def convert_ts(src_path: str, dst_path: str) -> None:
    src = open(src_path, encoding="utf-8").read()
    pat = re.compile(r'bw\("([^"\\\n]*)"\)')
    out = pat.sub(lambda m: '"' + convert(m.group(1)) + '"', src)
    open(dst_path, "w", encoding="utf-8").write(out)
    n = len(pat.findall(src))
    print(f"converted {n} strings: {src_path} -> {dst_path}")

if __name__ == "__main__":
    convert_ts(sys.argv[1], sys.argv[2])
