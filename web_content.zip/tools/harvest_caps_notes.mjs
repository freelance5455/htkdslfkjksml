/**
 * Multi-task outline helper for Learnly topic notes.
 * node tools/harvest_caps_notes.mjs
 * Creates missing PS note shells only — write original CAPS-aligned content.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.resolve(__dirname, "../content/grade11/physical_sciences");
const TASKS = [
  ["ps_vectors", 1, "resultant, components"],
  ["ps_newtons_laws", 1, "N1 N2 N3 free-body friction"],
  ["ps_gravitation", 1, "universal gravitation"],
  ["ps_electrostatics", 1, "Coulomb electric field"],
  ["ps_electromagnetism", 1, "Faraday right-hand rule"],
  ["ps_circuits", 1, "Ohm series parallel power"],
  ["ps_waves", 1, "v=fλ period"],
  ["ps_bonding", 2, "Lewis covalent bond energy"],
  ["ps_imf", 2, "London dipole hydrogen bond"],
  ["ps_stoich", 2, "mole concentration STP"],
  ["ps_energy_chem", 2, "exothermic activation energy"],
  ["ps_acids_bases", 2, "Bronsted-Lowry conjugates"],
  ["ps_redox", 2, "oxidation numbers OIL RIG"]
];
const results = [];
for (const [id, paper, focus] of TASKS) {
  const file = path.join(OUT, `${id}.json`);
  if (fs.existsSync(file)) {
    results.push({ id, status: "exists" });
    continue;
  }
  fs.writeFileSync(file, JSON.stringify({
    id, grade: 11, subject: "physical_sciences", paper,
    name: id.replace(/^ps_/, "").replaceAll("_", " "),
    about: `CAPS Grade 11 focus: ${focus}.`,
    key_facts: [`Focus: ${focus}`], formulae: [], worked_examples: []
  }, null, 2));
  results.push({ id, status: "created" });
}
console.log(JSON.stringify(results, null, 2));
