// تولید جفت‌کلید امضای لایسنس (ECDSA P-256)
// اجرا:  node tools/gen-keys.mjs
// خروجی:
//   SIGN_KEY  ← در Cloudflare به‌عنوان Secret با همین نام (کل JSON یک خطی)
//   pub       ← در www/config.js جایگزین مقدار pub شود
// ⚠️ اگر کلید عوض شود، باید APK جدید (با pub جدید) بین کاربران پخش شود.
import { webcrypto as crypto } from 'node:crypto';

const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
const pub = await crypto.subtle.exportKey('jwk', kp.publicKey);
const pick = (k, keys) => Object.fromEntries(keys.map((x) => [x, k[x]]));

console.log('\n=== SIGN_KEY (Secret در Cloudflare — محرمانه) ===');
console.log(JSON.stringify(pick(priv, ['kty', 'crv', 'x', 'y', 'd'])));
console.log('\n=== pub (در www/config.js — عمومی) ===');
console.log(JSON.stringify(pick(pub, ['kty', 'crv', 'x', 'y'])));
const rnd = Array.from(crypto.getRandomValues(new Uint8Array(24)), (b) => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[b % 62]).join('');
console.log('\n=== WEBHOOK_SECRET پیشنهادی ===');
console.log(rnd + '\n');
