// Genera CODEMAP.md: índice de secciones y funciones de index.html con números de línea (F19, fase A).
// Uso: node tools/codemap.js  (también lo ejecuta tools/build.js)
const fs=require('fs'),path=require('path');
function codemap(html){
  const L=html.split('\n'),out=[];
  out.push('# CODEMAP — mapa de index.html','','> Generado por `node tools/build.js` (o `node tools/codemap.js`). **No editar a mano.** Sirve para leer solo la zona necesaria en vez del archivo entero.','',
    '- Líneas: '+L.length+' · tamaño: '+(Buffer.byteLength(html)/1024).toFixed(0)+' KB · líneas de más de 600 caracteres: '+L.filter(l=>l.length>600).length,'');
  // bloques
  out.push('## Bloques','');const blocks=[];let st=null;
  L.forEach((l,i)=>{let m;
    if((m=l.match(/<style[^>]*>/))&&st===null)st={k:'CSS',a:i+1};
    else if(l.includes('</style>')&&st&&st.k==='CSS'){blocks.push({...st,b:i+1});st=null}
    if((m=l.match(/^<script([^>]*)>/))&&st===null)st={k:'script'+(m[1]?' '+m[1].trim():''),a:i+1};
    if(l.includes('</script>')&&st&&st.k.startsWith('script')){blocks.push({...st,b:i+1});st=null}});
  const bs=blocks.map(b=>b);out.push('| Bloque | Líneas |','|---|---|');bs.forEach(b=>out.push('| '+b.k+' | '+b.a+'–'+b.b+' |'));
  const body=L.findIndex(l=>l.includes('<body>')||l.includes('</style></head><body>'));
  const screens=[];L.forEach((l,i)=>{for(const m of l.matchAll(/<div id="([a-z0-9]+)" class="scr[^"]*"/g))screens.push(m[1]+'@'+(i+1))});
  out.push('','**Pantallas HTML (`.scr`):** '+screens.join(', '),'');
  // secciones por comentarios
  out.push('## Secciones (comentarios `// ----` y `// =====`)','');
  L.forEach((l,i)=>{const m=l.match(/^\s*\/\/\s*(?:-{3,}|={3,})\s*(.{3,110})/);if(m)out.push('- L'+(i+1)+': '+m[1].replace(/\s*=+\s*$/,'').trim())});
  // funciones
  out.push('','## Funciones de primer nivel','');const fn=[];
  L.forEach((l,i)=>{const m=l.match(/^(?:async )?function ([A-Za-z_$][\w$]*)\(([^)]*)\)/);if(m)fn.push(m[1]+'('+m[2]+')@'+(i+1))});
  out.push(fn.join(' · '));
  // tablas de datos
  out.push('','## Tablas y constantes de datos','');const cs=[];
  L.forEach((l,i)=>{const m=l.match(/^(?:const|let) ([A-Z][A-Z0-9_]{1,}|[A-Z]{2,}\w*)\s*=/);if(m)cs.push(m[1]+'@'+(i+1))});
  out.push(cs.join(' · '),'');
  const long=[];L.forEach((l,i)=>{if(l.length>600)long.push('L'+(i+1)+' ('+l.length+')')});
  out.push('## Líneas muy largas','',long.join(', ')||'ninguna','');
  return out.join('\n')}
module.exports={codemap};
if(require.main===module){const r=path.resolve(__dirname,'..');fs.writeFileSync(path.join(r,'CODEMAP.md'),codemap(fs.readFileSync(path.join(r,'index.html'),'utf8')));console.log('CODEMAP.md escrito')}
