/**
 * Engine 17: Clan Name Generator
 * Generates guild & clan titles with 2-4 letter dynamic clan tags and separate copy options.
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('clan-form');
  const resultsContainer = document.getElementById('results-list');
  const resultsCountSpan = document.getElementById('results-count');
  const emptyState = document.getElementById('empty-state');
  const resultsCard = document.getElementById('results-card');
  const resetBtn = document.getElementById('reset-btn');
  const copyAllBtn = document.getElementById('copy-all-btn');

  let gamingDb = { warrior: [], tactical: [], fantasy: [], dark: [], competitive: [], clanTags: [] };
  fetch('../../assets/data/gaming-words.json')
    .then(res => res.json())
    .then(data => { gamingDb = data; })
    .catch(err => console.log('Error loading gaming data', err));

  if (!form) return;

  function clean(s) {
    return (s || '').trim().replace(/[^a-zA-Z]/g, '');
  }

  function cap(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : '';
  }

  function generateClanNames(keyword, theme, count) {
    keyword = clean(keyword);
    const results = [];
    const used = new Set();

    const nounSets = {
      warrior: ['Warriors', 'Legion', 'Brigade', 'Vanguard', 'Squad', 'Order'],
      tactical: ['Syndicate', 'Division', 'Unit', 'Squad', 'Task Force', 'Cell'],
      fantasy: ['Dynasty', 'Kings', 'Realm', 'Covenant', 'Court', 'Order'],
      dark: ['Legion', 'Coven', 'Cult', 'Syndicate', 'Reapers', 'Order'],
      competitive: ['Elites', 'Alliance', 'Immortal', 'Dynasty', 'Kings', 'Squad']
    };
    const defaultNouns = ['Syndicate', 'Vanguard', 'Legion', 'Dynasty', 'Warriors', 'Squad', 'Elites', 'Brigade', 'Alliance', 'Immortal', 'Kings', 'Order'];
    const defaultAdjectives = ['Shadow', 'Apex', 'Phantom', 'Iron', 'Silent', 'Cyber', 'Dark', 'Nova', 'Mythic', 'Vicious', 'Vortex', 'Imperial'];

    const nouns = nounSets[theme] || defaultNouns;
    // Reuse the gaming word bank (loaded from gaming-words.json) as the adjective source when a
    // theme is selected, so the theme picker genuinely changes the vocabulary, not just labels.
    const adjectives = (gamingDb[theme] && gamingDb[theme].length > 0) ? gamingDb[theme] : defaultAdjectives;

    const tagsList = gamingDb.clanTags || ['VTX', 'PHX', 'SHD', 'RPR', 'NEX', 'ARC', 'GLD', 'BLZ'];

    for (let i = 0; i < (parseInt(count, 10) || 12); i++) {
      const adj = adjectives[i % adjectives.length];
      const noun = nouns[(i + 3) % nouns.length];
      const clanName = keyword ? `${cap(keyword)} ${noun}` : `${adj} ${noun}`;
      
      if (!used.has(clanName)) {
        used.add(clanName);
        // Create 3-letter tag
        const tag = (clanName.replace(/[^a-zA-Z]/g, '').slice(0, 3)).toUpperCase() || tagsList[i % tagsList.length];
        results.push({ name: clanName, tag: tag, score: 95 });
      }
    }

    return results;
  }

  function render(list) {
    resultsContainer.innerHTML = '';
    if (list.length === 0) {
      emptyState.classList.remove('hidden');
      resultsCard.classList.add('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    resultsCard.classList.remove('hidden');
    resultsCountSpan.textContent = list.length;

    list.forEach((item, index) => {
      const isFav = window.FavoritesManager ? window.FavoritesManager.isFavorite(item.name) : false;
      const card = document.createElement('div');
      card.className = 'result-card flex items-center justify-between p-3.5 sm:p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 shadow-sm animate-fade-in';
      card.innerHTML = `
        <div class="flex items-center gap-3">
          <span class="w-6 text-xs font-bold text-slate-400 dark:text-slate-500">${index + 1}.</span>
          <div>
            <div class="flex items-center gap-2 flex-wrap">
              <span class="px-2 py-0.5 rounded font-mono text-xs font-bold bg-slate-100 dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 border border-slate-200 dark:border-slate-600 cursor-pointer copy-tag-btn" title="Click to copy tag" data-tag="${item.tag}">[${item.tag}]</span>
              <span class="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-wide">${item.name}</span>
            </div>
          </div>
        </div>
        <div class="flex items-center gap-1.5 sm:gap-2">
          <button type="button" class="copy-single-btn p-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Copy clan name" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
          </button>
          <button type="button" class="fav-single-btn p-2 text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition ${isFav ? 'text-rose-500 dark:text-rose-400' : ''}" title="Favorite" data-name="${item.name}">
            <svg class="w-4 h-4" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
          </button>
          <button type="button" class="share-single-btn p-2 text-slate-500 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Share" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
          </button>
        </div>
      `;
      resultsContainer.appendChild(card);
    });

    resultsContainer.querySelectorAll('.copy-tag-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        window.copyToClipboard(btn.dataset.tag, `Copied clan tag: [${btn.dataset.tag}]`);
      });
    });

    resultsContainer.querySelectorAll('.copy-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.copyToClipboard(btn.dataset.name));
    });

    resultsContainer.querySelectorAll('.fav-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const isAdded = window.FavoritesManager.toggle(name, 'Gaming Tools', 'Clan Name Generator');
        const icon = btn.querySelector('svg');
        if (isAdded) {
          btn.classList.add('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'currentColor');
        } else {
          btn.classList.remove('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'none');
        }
      });
    });

    resultsContainer.querySelectorAll('.share-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.shareName(btn.dataset.name, 'Clan Name Generator'));
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const keyword = document.getElementById('clan-keyword').value;
    const theme = document.getElementById('theme-select')?.value || 'competitive';
    const count = document.getElementById('count-select')?.value || 12;

    const results = generateClanNames(keyword, theme, count);
    render(results);
    resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      resultsContainer.innerHTML = '';
      resultsCard.classList.add('hidden');
      emptyState.classList.remove('hidden');
    });
  }

  if (copyAllBtn) {
    copyAllBtn.addEventListener('click', () => {
      const names = Array.from(resultsContainer.querySelectorAll('.result-card span.tracking-wide'))
        .map(el => el.textContent.trim());
      if (names.length > 0) {
        window.copyToClipboard(names.join('\n'), `Copied ${names.length} clan names!`);
      }
    });
  }
});
