#!/usr/bin/env node
// Construcción y empaquetado (F12/F14/F19A). Un solo comando:  node tools/build.js
//   1) calcula la versión (hash del contenido)  2) escribe BUILD en index.html  3) regenera sw.js  4) regenera CODEMAP.md
//   5) ejecuta todos los tests  6) avisa de archivos huérfanos y del peso  7) crea dist/monstruos_de_bolsillo_AAAAMMDD.zip
// Opciones: --check (no escribe; falla si sw.js/BUILD/CODEMAP están desactualizados) · --no-test · --no-zip
const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const {codemap}=require('./codemap.js');
const R=path.resolve(__dirname,'..'),A=process.argv.slice(2),has=f=>A.includes(f);
const rd=f=>fs.readFileSync(path.join(R,f)),rds=f=>rd(f).toString('utf8');
const walk=d=>fs.readdirSync(path.join(R,d),{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(d+'/'+e.name):[d+'/'+e.name]).sort();
const BRE=/\/\*BUILD\*\/const BUILD=\{[^}]*\};\/\*\/BUILD\*\//;
const assets=walk('assets').filter(f=>/\.(png|jpe?g|webp|gif|svg|mp3|ogg|wav)$/i.test(f));
const core=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png'];
const html0=rds('index.html');if(!BRE.test(html0)){console.error('Falta el marcador /*BUILD*/ en index.html');process.exit(1)}
// versión = hash de todo lo que el jugador descarga (con el bloque BUILD neutralizado)
const hs=crypto.createHash('sha1');
hs.update(html0.replace(BRE,'/*BUILD*/'));hs.update(rd('tools/sw.template.js'));hs.update(rd('manifest.webmanifest'));hs.update(rd('icon-192.png'));hs.update(rd('icon-512.png'));
assets.forEach(f=>{hs.update(f);hs.update(rd(f))});
const h=hs.digest('hex').slice(0,8);
const old=(html0.match(BRE)[0].match(/"h":"([^"]*)"/)||[])[1],oldD=(html0.match(BRE)[0].match(/"d":"([^"]*)"/)||[])[1];
const today=new Date().toISOString().slice(0,10),d=old===h&&oldD&&oldD!=='dev'?oldD:today;   // la fecha solo cambia si cambia el contenido
const html=html0.replace(BRE,'/*BUILD*/const BUILD={"h":"'+h+'","d":"'+d+'"};/*/BUILD*/');
const sw=rds('tools/sw.template.js').replace('__CACHE__','mp-'+h).replace('__CORE__',JSON.stringify(core)).replace('__ASSETS__',JSON.stringify(assets));
const cm=codemap(html);
const outs=[['index.html',html],['sw.js',sw],['CODEMAP.md',cm]];
if(has('--check')){let bad=0;for(const [f,c] of outs){const cur=fs.existsSync(path.join(R,f))?rds(f):'';if(cur!==c){console.error('DESACTUALIZADO: '+f+' (ejecuta node tools/build.js)');bad++}}process.exit(bad?1:0)}
for(const [f,c] of outs)if(!fs.existsSync(path.join(R,f))||rds(f)!==c)fs.writeFileSync(path.join(R,f),c);
console.log('versión '+h+' ('+d+') · caché mp-'+h+' · '+assets.length+' recursos precacheados');
// huérfanos: PNG cuyo nombre (sin extensión) no aparece en index.html ni en ningún otro texto del juego (solo aviso)
const txt=html;const orf=assets.filter(f=>{const b=path.basename(f,path.extname(f)),k=b.startsWith('fx_')?b.slice(3):b.split('_')[0].replace(/\d+$/,'');return !txt.includes(k)});   // los sprites se cargan por nombre compuesto: se busca la parte clave
console.log(orf.length?'Posibles huérfanos (revisar, pueden cargarse por nombre compuesto): '+orf.join(', '):'Sin archivos huérfanos');
const tot=assets.reduce((s,f)=>s+fs.statSync(path.join(R,f)).size,0)+Buffer.byteLength(html);console.log('Peso de la primera carga: '+(tot/1048576).toFixed(2)+' MB');
let fail=0;
if(!has('--no-test')){for(const f of fs.readdirSync(R).filter(f=>/^tests.*\.js$/.test(f)).sort()){
  const r=cp.spawnSync(process.execPath,[f],{cwd:R,encoding:'utf8',timeout:300000}),o=(r.stdout||'')+(r.stderr||'');
  const bad=r.status!==0||/FALLA|ERROR/.test(o)||[...o.matchAll(/(\d+) fallos?/g)].some(m=>+m[1]>0);
  console.log((bad?'✗ ':'✓ ')+f+' · '+(o.trim().split('\n').pop()||''));if(bad){fail++;console.log(o.split('\n').filter(l=>/FALLA|ERROR/.test(l)).slice(0,8).join('\n'))}}}
if(fail){console.error('Hay pruebas que fallan: no se crea el zip.');process.exit(1)}
if(!has('--no-zip')){const dist=path.join(R,'dist');fs.mkdirSync(dist,{recursive:true});
  const name='monstruos_de_bolsillo_'+today.replace(/-/g,'')+'.zip',out=path.join(dist,name);if(fs.existsSync(out))fs.unlinkSync(out);
  let r=cp.spawnSync('zip',['-r','-q',out,'.','-x','dist/*','*.zip','node_modules/*','.git/*'],{cwd:R});
  if(r.error||r.status!==0){r=cp.spawnSync('python3',['-c','import sys,os,zipfile\nz=zipfile.ZipFile(sys.argv[1],"w",zipfile.ZIP_DEFLATED)\nfor d,_,fs in os.walk("."):\n  if d.startswith("./dist") or d.startswith("./node_modules") or d.startswith("./.git"):continue\n  for f in fs:\n    if not f.endswith(".zip"):z.write(os.path.join(d,f))\nz.close()',out],{cwd:R})}
  if(r.status!==0){console.error('No se pudo crear el zip');process.exit(1)}console.log('zip: dist/'+name+' ('+(fs.statSync(out).size/1048576).toFixed(2)+' MB)')}
