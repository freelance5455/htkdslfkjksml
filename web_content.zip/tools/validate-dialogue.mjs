// Quality gate for the dialogue library. Usage: node validate-dialogue.mjs dialogue-library.json [target=15000]
// Fails on: exact duplicates, near-duplicates (name/number-swap clones), banned words, over-long lines, bad placeholders.
import fs from 'node:fs';
const file = process.argv[2] || 'dialogue-library.json', target = +(process.argv[3] || 15000);
const lib = JSON.parse(fs.readFileSync(file, 'utf8')).categories;
const BANNED = ['रोबोट', 'अगला', 'अगली बारी', 'नंबर'];            // add abusive/hateful words here; reviewers must read every line too
const norm = (t) => t.replace(/\{[no]\}/g, '').replace(/[0-9०-९]+/g, '#').replace(/[^\u0900-\u097F# ]/g, '').replace(/\s+/g, ' ').trim();
const grams = (t) => { const w = t.split(' '), g = new Set(); for (let i = 0; i + 2 < w.length; i++) g.add(w.slice(i, i + 3).join(' ')); return g.size ? g : new Set(w); };
const jac = (a, b) => { let i = 0; for (const x of a) if (b.has(x)) i++; return i / (a.size + b.size - i || 1); };
const rows = Object.entries(lib).flatMap(([c, v]) => v.map((x) => ({ c, id: x.id, t: x.text, n: norm(x.text) })));
const problems = [], seen = new Map(), sh = rows.map((r) => grams(r.n));
rows.forEach((r, i) => {
  if (seen.has(r.n)) problems.push(`DUPLICATE ${r.id} = ${seen.get(r.n)}`); else seen.set(r.n, r.id);
  for (const b of BANNED) if (r.t.includes(b)) problems.push(`BANNED "${b}" in ${r.id}`);
  if (r.t.length > 110) problems.push(`TOO LONG for natural speech ${r.id}`);
  if (/\{[^no}]*\}/.test(r.t) || (r.t.match(/\{/g) || []).length !== (r.t.match(/\}/g) || []).length) problems.push(`BAD PLACEHOLDER ${r.id}`);
  for (let j = Math.max(0, i - 400); j < i; j++) if (rows[j].c === r.c && jac(sh[i], sh[j]) > 0.6) problems.push(`NEAR-DUPLICATE ${r.id} ~ ${rows[j].id}`);
});
console.log(`lines: ${rows.length} / target ${target}  (${((rows.length / target) * 100).toFixed(1)}%)`);
for (const [c, v] of Object.entries(lib)) console.log(`  ${c.padEnd(10)} ${v.length}`);
console.log(problems.length ? problems.join('\n') : 'no problems found');
process.exit(problems.length ? 1 : 0);
