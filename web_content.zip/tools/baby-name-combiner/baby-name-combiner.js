/**
 * Engine 10: Baby Name Combiner
 * Blends father's and mother's names phonetically and cross-references curated baby names dataset.
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('baby-combiner-form');
  const resultsContainer = document.getElementById('results-list');
  const resultsCountSpan = document.getElementById('results-count');
  const emptyState = document.getElementById('empty-state');
  const resultsCard = document.getElementById('results-card');
  const resetBtn = document.getElementById('reset-btn');
  const copyAllBtn = document.getElementById('copy-all-btn');

  let babyDb = [];
  fetch('../../assets/data/baby-names.json')
    .then(res => res.json())
    .then(data => { babyDb = data; })
    .catch(err => console.log('Loaded without offline DB', err));

  if (!form) return;

  function clean(s) {
    return (s || '').trim().replace(/[^a-zA-Z]/g, '');
  }

  function cap(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : '';
  }

  function combineBabyNames(father, mother, gender, count) {
    father = clean(father);
    mother = clean(mother);
    const results = [];
    const usedNames = new Set();

    // 1. Check curated database for phoneme overlaps from parents
    const fChunk = father.slice(0, 2).toLowerCase();
    const mChunk = mother.slice(0, 2).toLowerCase();
    const fEnd = father.slice(-2).toLowerCase();
    const mEnd = mother.slice(-2).toLowerCase();

    if (babyDb.length > 0) {
      babyDb.forEach(item => {
        if (gender !== 'all' && item.gender !== gender) return;
        const nLower = item.name.toLowerCase();
        if (nLower.includes(fChunk) || nLower.includes(mChunk) || nLower.endsWith(fEnd) || nLower.endsWith(mEnd)) {
          if (!usedNames.has(nLower)) {
            usedNames.add(nLower);
            results.push({
              name: item.name,
              origin: item.origin,
              meaning: item.meaning,
              type: 'Curated Name',
              gender: item.gender,
              score: 95
            });
          }
        }
      });
    }

    // 2. Generate phonetic hybrid blends
    const halfF = Math.ceil(father.length / 2);
    const halfM = Math.ceil(mother.length / 2);

    const hybridCandidates = [
      cap(father.slice(0, halfF) + mother.slice(halfM)),
      cap(mother.slice(0, halfM) + father.slice(halfF)),
      cap(father.slice(0, 2) + mother.slice(-2)),
      cap(mother.slice(0, 2) + father.slice(-2)),
      cap(father.slice(0, 3) + 'a'),
      cap(mother.slice(0, 3) + 'an'),
      cap(father.slice(0, 2) + mother.slice(0, 2) + 'el')
    ];

    hybridCandidates.forEach(cand => {
      const lower = cand.toLowerCase();
      if (cand.length >= 3 && cand.length <= 8 && !usedNames.has(lower)) {
        usedNames.add(lower);
        results.push({
          name: cand,
          origin: 'Parent Blend',
          meaning: 'Custom harmonious blend of parents\' names',
          type: 'Unique Blend',
          gender: gender === 'all' ? 'Unisex' : gender,
          score: 88
        });
      }
    });

    return results.slice(0, parseInt(count, 10) || 10);
  }

  function render(list) {
    resultsContainer.innerHTML = '';
    if (list.length === 0) {
      emptyState.classList.remove('hidden');
      resultsCard.classList.add('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    resultsCard.classList.remove('hidden');
    resultsCountSpan.textContent = list.length;

    list.forEach((item, index) => {
      const isFav = window.FavoritesManager ? window.FavoritesManager.isFavorite(item.name) : false;
      const card = document.createElement('div');
      card.className = 'result-card flex items-start justify-between p-3.5 sm:p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 shadow-sm animate-fade-in';
      card.innerHTML = `
        <div class="flex items-start gap-3">
          <span class="w-6 text-xs font-bold text-slate-400 dark:text-slate-500 mt-1">${index + 1}.</span>
          <div>
            <div class="flex items-center gap-2 flex-wrap">
              <span class="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-wide">${item.name}</span>
              <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${item.type === 'Curated Name' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/50'}">
                ${item.type}
              </span>
              <span class="text-xs text-slate-500 dark:text-slate-400">(${item.origin})</span>
            </div>
            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">${item.meaning}</p>
          </div>
        </div>
        <div class="flex items-center gap-1.5 sm:gap-2">
          <button type="button" class="copy-single-btn p-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Copy name" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
          </button>
          <button type="button" class="fav-single-btn p-2 text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition ${isFav ? 'text-rose-500 dark:text-rose-400' : ''}" title="Favorite" data-name="${item.name}">
            <svg class="w-4 h-4" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
          </button>
          <button type="button" class="share-single-btn p-2 text-slate-500 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Share" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
          </button>
        </div>
      `;
      resultsContainer.appendChild(card);
    });

    resultsContainer.querySelectorAll('.copy-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.copyToClipboard(btn.dataset.name));
    });

    resultsContainer.querySelectorAll('.fav-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const isAdded = window.FavoritesManager.toggle(name, 'Baby Tools', 'Baby Name Combiner');
        const icon = btn.querySelector('svg');
        if (isAdded) {
          btn.classList.add('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'currentColor');
        } else {
          btn.classList.remove('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'none');
        }
      });
    });

    resultsContainer.querySelectorAll('.share-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.shareName(btn.dataset.name, 'Baby Name Combiner'));
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const father = document.getElementById('father-name').value;
    const mother = document.getElementById('mother-name').value;
    const gender = document.getElementById('gender-select')?.value || 'all';
    const count = document.getElementById('count-select')?.value || 10;

    if (!clean(father) || !clean(mother)) {
      if (window.showToast) window.showToast('Please enter both parents\' names', 'error');
      return;
    }

    const results = combineBabyNames(father, mother, gender, count);
    render(results);
    resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      resultsContainer.innerHTML = '';
      resultsCard.classList.add('hidden');
      emptyState.classList.remove('hidden');
    });
  }

  if (copyAllBtn) {
    copyAllBtn.addEventListener('click', () => {
      const names = Array.from(resultsContainer.querySelectorAll('.result-card span.tracking-wide'))
        .map(el => el.textContent.trim());
      if (names.length > 0) {
        window.copyToClipboard(names.join('\n'), `Copied ${names.length} baby names!`);
      }
    });
  }
});
