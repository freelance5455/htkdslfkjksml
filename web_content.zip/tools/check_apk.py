"""للتأكد أن ملف APK الناتج يحتوي التطبيق فعلًا:  python3 tools/check_apk.py app-debug.apk
(APK ملف ZIP؛ هذا الفحص لا يحتاج أي أدوات أندرويد)"""
import sys,zipfile,re,json
if len(sys.argv)<2:sys.exit("usage: python3 check_apk.py path/to/app-debug.apk")
z=zipfile.ZipFile(sys.argv[1]);names=set(z.namelist());res=[]
def ok(n,c,extra=""):res.append(bool(c));print(("PASS " if c else "FAIL ")+n+(f"  [{extra}]" if extra else ""))
ok("AndroidManifest.xml present","AndroidManifest.xml" in names)
ok("classes.dex present (app code compiled)","classes.dex" in names)
ok("assets/index.html packaged inside the APK","assets/index.html" in names)
if "assets/index.html" in names:
    raw=z.read("assets/index.html");h=raw.decode("utf-8","replace")
    ok("index.html is the full app (size > 400 KB)",len(raw)>400_000,f"{len(raw)//1024} KB")
    blocks=re.findall(r'<script type="application/json" id="d-([a-z]+)">(.*?)</script>',h,re.S)
    n=sum(len(json.loads(b.replace("<\\/","</"))) for _,b in blocks)
    ok("library embedded: 3604 items in 19 sections",n==3604 and len(blocks)==19,f"{n} items, {len(blocks)} sections")
    ok("zajal section = 500",any(t=="zajal" and len(json.loads(b.replace("<\\/","</")))==500 for t,b in blocks))
    ok("no 'تقرير المكتبة' button","تقرير المكتبة" not in h)
    ok("no Claude/external UI dependency",not re.search(r'claude\.ai|artifact',h,re.I))
print("\nRESULT:","APK looks complete" if all(res) else "APK is MISSING required content — rebuild the project")
sys.exit(0 if all(res) else 1)
