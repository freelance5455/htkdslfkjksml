#!/usr/bin/env python3
"""Validate the full Bible JSON embedded in every delivered HTML copy."""
from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
HTML_PATHS = [
    PROJECT / 'index.html',
    PROJECT / 'web/index.html',
    Path('/home/ubuntu/index.html'),
    PROJECT / 'android/app/src/main/assets/public/index.html',
]

loaded: dict[Path, tuple[str, list[dict], str]] = {}
for path in HTML_PATHS:
    if not path.is_file():
        raise SystemExit(f'FAIL: expected HTML copy is missing: {path}')
    html = path.read_text(encoding='utf-8')
    corpus_match = re.search(r'<script type="application/json" id="bibleCorpus">(.*?)</script>', html, re.S)
    if not corpus_match:
        raise SystemExit(f'FAIL: embedded Bible corpus script is missing from {path}')
    verses = json.loads(corpus_match.group(1))
    app_script_match = re.search(r'<script>(.*?)</script>', html, re.S)
    if not app_script_match:
        raise SystemExit(f'FAIL: application JavaScript is missing from {path}')
    loaded[path] = (html, verses, app_script_match.group(1))

primary_path = PROJECT / 'web/index.html'
html, verses, app_script = loaded[primary_path]
book_match = re.search(r'const BOOKS=(\[.*?\]);', app_script, re.S)
if not book_match:
    raise SystemExit('FAIL: 66-book catalogue is missing')
books = re.findall(r"\['([^']+)',\s*'(?:AT|NT)',\s*(\d+)\]", book_match.group(1))
if len(books) != 66:
    raise SystemExit(f'FAIL: expected 66 books, found {len(books)}')
if not isinstance(verses, list) or len(verses) != 31170:
    raise SystemExit(f'FAIL: expected 31,170 embedded verses, found {len(verses) if isinstance(verses, list) else "invalid data"}')

by_chapter: dict[tuple[str, int], list[dict]] = defaultdict(list)
references: set[str] = set()
for verse in verses:
    if not all(key in verse for key in ('ref', 'book', 'ch', 'v', 'text')) or not verse['text'].strip():
        raise SystemExit(f"FAIL: malformed or empty verse: {verse!r}")
    if verse['ref'] in references:
        raise SystemExit(f"FAIL: duplicate reference {verse['ref']}")
    references.add(verse['ref'])
    by_chapter[(verse['book'], verse['ch'])].append(verse)

for name, chapter_count in books:
    expected_chapters = set(range(1, int(chapter_count) + 1))
    actual_chapters = {chapter for book, chapter in by_chapter if book == name}
    if actual_chapters != expected_chapters:
        raise SystemExit(f'FAIL: chapter coverage mismatch in {name}')
    for chapter in expected_chapters:
        rows = by_chapter[(name, chapter)]
        numbers = [row['v'] for row in rows]
        if numbers != list(range(1, len(numbers) + 1)):
            raise SystemExit(f'FAIL: verse sequence is incomplete in {name} {chapter}')

if sum(int(count) for _, count in books) != 1189 or len(by_chapter) != 1189:
    raise SystemExit(f'FAIL: expected 1,189 chapters, found {len(by_chapter)}')
for name, chapter_count in (('Genèse', 50), ('Malachie', 4), ('Matthieu', 28), ('Apocalypse', 22)):
    if not by_chapter[(name, 1)] or not by_chapter[(name, int(chapter_count))]:
        raise SystemExit(f'FAIL: missing first/last chapter for {name}')
for reference in ('Genèse 1:1', 'Jean 3:16', 'Psaumes 119:105', 'Apocalypse 22:21'):
    if reference not in references:
        raise SystemExit(f'FAIL: missing expected reference {reference}')

obsolete = re.compile(r'échantillon de démonstration|corpus incomplet|texte intégral .*n’est pas embarqué', re.I)
for path, (copy_html, copy_verses, copy_script) in loaded.items():
    if copy_verses != verses:
        raise SystemExit(f'FAIL: embedded corpus differs from web/index.html in {path}')
    if 'VERSES_BY_CHAPTER' not in copy_script or 'parseBibleReference' not in copy_script:
        raise SystemExit(f'FAIL: full-corpus navigation/search integration is missing from {path}')
    viewport = re.search(r'<meta name="viewport" content="([^"]*)">', copy_html)
    if not viewport or 'user-scalable=no' not in viewport.group(1) or 'maximum-scale=1' not in viewport.group(1):
        raise SystemExit(f'FAIL: pinch zoom is not disabled in {path}')
    visible_html = re.sub(r'<script type="application/json" id="bibleCorpus">.*?</script>', '', copy_html, flags=re.S)
    if obsolete.search(visible_html):
        raise SystemExit(f'FAIL: outdated sample/incomplete-corpus notice remains in {path}')

print(json.dumps({
    'status': 'PASS',
    'translation': 'Louis Segond 1910',
    'books': len(books),
    'chapters': len(by_chapter),
    'verses': len(verses),
    'unique_references': len(references),
    'html_copies_identical_corpus': [str(path) for path in loaded],
    'every_chapter_and_verse_sequence': 'PASS',
    'start_end_reference_samples': 'PASS',
    'full_corpus_search_and_reader': 'PASS',
    'obsolete_demo_labels': 'none',
}, ensure_ascii=False, indent=2))
