// Adds the app shell (no pull-to-refresh, Android Back, offline/update/install notices, PWA tags) to a built index.html.
// Run after every rebuild:  node tools/add-shell.mjs path/to/index.html     (idempotent)
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const HERE = path.dirname(fileURLToPath(import.meta.url)), file = process.argv[2] || path.join(HERE, '..', 'index.html');
let h = fs.readFileSync(file, 'utf8');
if (h.includes('<!--app-shell-->')) { console.log('shell already present'); process.exit(0); }
const css = fs.readFileSync(path.join(HERE, '..', 'shell', 'native.css'), 'utf8'), js = fs.readFileSync(path.join(HERE, '..', 'shell', 'native.js'), 'utf8');
if (js.includes('</script>')) throw new Error('native.js must not contain </script>');
// 1) CSP (meta): allow the app's own manifest / service worker / icons; scripts and styles stay inline-only
const csp = h.match(/<meta http-equiv="Content-Security-Policy" content="([^"]*)">/); if (!csp) throw new Error('CSP meta not found');
let c = csp[1].replace("img-src data: blob:", "img-src 'self' data: blob:");
if (!/manifest-src/.test(c)) c += "; manifest-src 'self'; worker-src 'self'";
h = h.replace(csp[0], `<meta http-equiv="Content-Security-Policy" content="${c}">`);
// 2) head: PWA tags
const head = '<!--app-shell--><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="AccoNova"><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icons/icon-192.png">';
h = h.replace('<meta name="theme-color"', head + '<meta name="theme-color"');
// 3) css before the first </style> in <head>
const i = h.indexOf('</style>'); if (i < 0 || i > h.indexOf('<body')) throw new Error('head <style> not found');
h = h.slice(0, i) + '\n' + css + '\n' + h.slice(i);
// 4) js before the LAST </body> (the app contains the string "</body>" inside its own scripts)
const cfg = 'window.NATIVE_CFG={navButtons:"nav.tabs button.tab:not(.back)",backButton:"nav.tabs button.tab.back",home:"i0"};';
const reg = 'if("serviceWorker"in navigator&&(location.protocol==="https:"||location.hostname==="localhost"))window.addEventListener("load",function(){navigator.serviceWorker.register("/sw.js").catch(function(){})});';
const j = h.lastIndexOf('</body>');
h = h.slice(0, j) + '<script>' + cfg + '</script>\n<script>' + js + '</script>\n<script>' + reg + '</script>\n' + h.slice(j);
fs.writeFileSync(file, h); console.log('shell added to', file);
