// Run: node build-legal.js  -> regenerates privacy.html and terms.html from js/config.js + js/legal.js
const fs = require('fs'), w = {};
for (const f of ['config', 'legal']) new Function('window', fs.readFileSync(__dirname + '/../js/' + f + '.js', 'utf8'))(w);
const page = (title, body) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} · ${w.EP.config.appName}</title><link rel="stylesheet" href="css/app.css"></head><body><main><h1>${title}</h1>${body}<p><a href="index.html">← ${w.EP.config.appName}</a></p></main></body></html>`;
fs.writeFileSync(__dirname + '/../privacy.html', page('Privacy Policy', w.EP.legal.privacy()));
fs.writeFileSync(__dirname + '/../terms.html', page('Terms of Use', w.EP.legal.terms()));
console.log('legal pages written');
