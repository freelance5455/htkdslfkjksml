#!/usr/bin/env python3
"""Download licensed media into the project and rewrite the PWA to use local files.

Run from any working directory:
    python tools/bundle_media.py

Requires internet for this one-time build step. The resulting app's photos and audio
are stored under assets/media and no longer need network access at runtime.
"""
from __future__ import annotations
import html as html_lib
import re
import sys
import time
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
ANIMALS = ("dog", "cat", "duck", "pig", "cow", "sheep", "lion", "elephant")
USER_AGENT = "ToddlerPlaylandMediaBundler/1.2 (user-initiated offline app build; https://commons.wikimedia.org/wiki/Commons:Contact_us)"
MAX_ATTEMPTS = 6
# Wikimedia may apply short rolling limits. Keep traffic deliberately low.
WIKIMEDIA_MIN_INTERVAL_SECONDS = 15.0
_last_wikimedia_request = 0.0


def is_valid_existing(path: Path) -> bool:
    """Recognize already downloaded files so a failed run can safely resume."""
    try:
        if path.stat().st_size < 1024:
            return False
        with path.open("rb") as f:
            head = f.read(16)
        suffix = path.suffix.lower()
        if suffix in (".jpg", ".jpeg"):
            return head.startswith(b"\xff\xd8\xff")
        if suffix == ".png":
            return head.startswith(b"\x89PNG\r\n\x1a\n")
        if suffix == ".ogg":
            return head.startswith(b"OggS")
        if suffix == ".mp3":
            return head.startswith(b"ID3") or any(
                head[i] == 0xFF and (head[i + 1] & 0xE0) == 0xE0
                for i in range(len(head) - 1)
            )
        return True
    except OSError:
        return False


def retry_delay(exc: HTTPError, attempt: int) -> float:
    """Respect Retry-After from the host, otherwise use exponential backoff."""
    header = exc.headers.get("Retry-After", "").strip() if exc.headers else ""
    # Wikimedia can continue returning 429 after its short Retry-After expires.
    # Use a conservative minimum cooldown in addition to the server's instruction,
    # rather than sending a request every 10 seconds and extending the block.
    conservative_floor = min(60.0 * (2 ** (attempt - 1)), 600.0)
    if header:
        try:
            return max(conservative_floor, min(float(header), 900.0))
        except ValueError:
            try:
                retry_at = parsedate_to_datetime(header)
                if retry_at.tzinfo is None:
                    retry_at = retry_at.replace(tzinfo=timezone.utc)
                server_delay = max(0.0, (retry_at - datetime.now(timezone.utc)).total_seconds())
                return max(conservative_floor, min(server_delay, 900.0))
            except (TypeError, ValueError, OverflowError):
                pass
    return conservative_floor


def download(url: str, destination: Path) -> None:
    global _last_wikimedia_request
    if destination.exists() and is_valid_existing(destination):
        print(f"  Already downloaded; keeping {destination.as_posix()}")
        return

    is_wikimedia = "wikimedia.org/" in url
    last_error: Exception | None = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        if is_wikimedia:
            elapsed = time.monotonic() - _last_wikimedia_request
            if elapsed < WIKIMEDIA_MIN_INTERVAL_SECONDS:
                time.sleep(WIKIMEDIA_MIN_INTERVAL_SECONDS - elapsed)
        req = Request(url, headers={
            "User-Agent": USER_AGENT,
            "Accept": "image/jpeg,image/png,audio/mpeg,audio/ogg,application/octet-stream,*/*;q=0.8",
        })
        try:
            with urlopen(req, timeout=60) as response:
                data = response.read()
                content_type = response.headers.get("Content-Type", "").lower()
            if is_wikimedia:
                _last_wikimedia_request = time.monotonic()
            if len(data) < 1024:
                raise RuntimeError(f"Unexpectedly small download ({len(data)} bytes): {url}")
            suffix = destination.suffix.lower()
            if suffix in (".jpg", ".jpeg", ".png"):
                has_image_signature = (data.startswith(b"\xff\xd8\xff") or data.startswith(b"\x89PNG\r\n\x1a\n"))
                if not content_type.startswith("image/") and not has_image_signature:
                    raise RuntimeError(f"Source did not return an image: {url} ({content_type})")
                if not has_image_signature:
                    raise RuntimeError(f"Downloaded image has an unexpected file signature: {url}")
            elif suffix == ".ogg" and not data.startswith(b"OggS"):
                raise RuntimeError(f"Source did not return an Ogg audio file: {url}")
            elif suffix == ".mp3" and not (data.startswith(b"ID3") or any(
                data[i] == 0xFF and (data[i + 1] & 0xE0) == 0xE0
                for i in range(min(64, len(data) - 1))
            )):
                raise RuntimeError(f"Source did not return an MP3 audio file: {url} ({content_type})")

            destination.parent.mkdir(parents=True, exist_ok=True)
            temp_path = destination.with_suffix(destination.suffix + ".part")
            temp_path.write_bytes(data)
            temp_path.replace(destination)
            return
        except HTTPError as exc:
            last_error = exc
            if exc.code == 429 and attempt < MAX_ATTEMPTS:
                delay = retry_delay(exc, attempt)
                print(f"  Host rate-limited the request (HTTP 429). Retrying in {delay:.0f}s ({attempt}/{MAX_ATTEMPTS - 1})...")
                time.sleep(delay)
                continue
            if exc.code in (500, 502, 503, 504) and attempt < MAX_ATTEMPTS:
                delay = min(5.0 * attempt, 30.0)
                print(f"  Temporary server error HTTP {exc.code}; retrying in {delay:.0f}s...")
                time.sleep(delay)
                continue
            raise
        except URLError as exc:
            last_error = exc
            if attempt < MAX_ATTEMPTS:
                delay = min(5.0 * attempt, 30.0)
                print(f"  Network error; retrying in {delay:.0f}s ({attempt}/{MAX_ATTEMPTS - 1})...")
                time.sleep(delay)
                continue
            raise
    if last_error:
        raise last_error


def main() -> int:
    index_path = ROOT / "index.html"
    sw_path = ROOT / "service-worker.js"
    credits_path = ROOT / "credits.html"
    readme_path = ROOT / "README.md"
    index = index_path.read_text(encoding="utf-8")
    sw = sw_path.read_text(encoding="utf-8")
    credits = credits_path.read_text(encoding="utf-8")
    readme = readme_path.read_text(encoding="utf-8")

    card_matches = re.findall(r'<button class="animal-card"[^>]*data-animal="([^"]+)"[\s\S]*?<img src="([^"]+)"', index)
    image_sources = {animal: html_lib.unescape(url) for animal, url in card_matches}
    if set(image_sources) != set(ANIMALS):
        raise RuntimeError("Couldn't identify all eight animal photos. No files were changed.")

    audio_sources: dict[str, dict[str, str]] = {}
    audio_block = index.split("const ANIMAL_AUDIO = {", 1)[1].split("\n    };", 1)[0]
    for animal in ANIMALS:
        match = re.search(rf"\b{animal}:\s*\{{([\s\S]*?)\n\s*\}}", audio_block)
        if not match:
            raise RuntimeError(f"Couldn't find audio definition for {animal}. No files were changed.")
        block = match.group(1)
        formats = {}
        for fmt in ("mp3", "ogg"):
            found = re.search(rf"\b{fmt}:\s*'([^']+)'", block)
            if found:
                formats[fmt] = found.group(1)
        if set(formats) != {"mp3", "ogg"}:
            raise RuntimeError(f"Missing MP3/OGG audio source for {animal}. No files were changed.")
        audio_sources[animal] = formats

    url_to_local: dict[str, str] = {}
    files_to_download: list[tuple[str, Path]] = []
    for animal, url in image_sources.items():
        relative = f"./assets/media/photos/{animal}.jpg"
        url_to_local[url] = relative
        files_to_download.append((url, Path("assets/media/photos") / f"{animal}.jpg"))
    for animal, formats in audio_sources.items():
        for fmt, url in formats.items():
            relative = f"./assets/media/audio/{animal}.{fmt}"
            url_to_local[url] = relative
            files_to_download.append((url, Path("assets/media/audio") / f"{animal}.{fmt}"))

    # Downloads go straight into assets/media one at a time. This makes the process
    # resumable: if a source rate-limits a later request, successful files stay put,
    # while source HTML/JS is left unchanged until every asset is present.
    try:
        print(f"Preparing {len(files_to_download)} media files. This step needs internet...")
        print("Downloads are spaced out to reduce Wikimedia rate limits; HTTP 429 triggers a conservative cooldown.")
        for idx, (url, relative_dest) in enumerate(files_to_download, 1):
            dest = ROOT / relative_dest
            print(f"[{idx}/{len(files_to_download)}] {relative_dest.as_posix()}")
            download(url, dest)

        # Only rewrite project files after all downloads succeeded.
        new_index = index
        for source, relative in url_to_local.items():
            # Image URLs in HTML attributes escape ampersands; JS URLs do not.
            new_index = new_index.replace(html_lib.escape(source, quote=True), relative)
            new_index = new_index.replace(source, relative)

        new_sw = sw
        for source, relative in url_to_local.items():
            new_sw = new_sw.replace('"' + source + '"', '"' + relative + '"')

        # URLs are normalized after the MEDIA_URLS array, allowing both remote URLs and
        # relative, physically bundled paths to work with the same service worker.
        new_credits = credits.replace(
            "When hosted over HTTPS and opened online once, the installed PWA downloads the animal photographs and recorded sounds into local browser cache. Wait until the app badge says <em>Offline ready</em> before disconnecting. For a physically bundled media release, run <code>python tools/bundle_media.py</code> on an internet-connected computer; this downloads the source files into the project and rewrites the app to use local assets.",
            "The photographs and recorded sounds are included locally in the app bundle under <code>assets/media/</code>. Playback does not request media from the internet. Source links and license credits are retained below."
        )
        new_readme = readme.replace(
            "The current ZIP does **not physically contain the photo/audio binary files**; it contains their source URLs and an automatic offline-cache step. A network connection is required once to download the media into the device's app cache. After the app displays **Offline ready**, the PWA is designed to play the animal media without a connection. This is a practical install-and-cache approach, but it is not the same as shipping every media file inside the ZIP.",
            "After running `python tools/bundle_media.py`, the project physically contains all photographs and recorded sounds under `assets/media/`. The app then loads media locally rather than from external URLs, so media playback does not require internet."
        )
        new_readme = new_readme.replace(
            "## Preview locally",
            "## Create a physically bundled media build\n\nOn an internet-connected computer, run `python tools/bundle_media.py` from any directory. The script downloads and verifies every source asset first; only after all downloads succeed does it rewrite the HTML and service worker to use the local files. Re-zip or deploy the resulting project folder.\n\n## Preview locally"
        )

        # All media assets are present and validated; now switch source references.
        index_path.write_text(new_index, encoding="utf-8")
        sw_path.write_text(new_sw, encoding="utf-8")
        credits_path.write_text(new_credits, encoding="utf-8")
        readme_path.write_text(new_readme, encoding="utf-8")
        print("Done. All 24 media assets are now stored locally under assets/media/.")
        print("The project files now reference local images/audio. Rebuild the ZIP before deployment.")
        return 0
    except Exception as exc:
        print(f"Media bundling stopped; source files are unchanged. Successfully downloaded files are kept in assets/media so you can safely rerun the command. Reason: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
