#!/usr/bin/env python3
"""Genera assets/icons/raven.png (atlas de 32 px) y el mapa emoji -> celda a partir de la hoja
'Free - Raven Fantasy Icons / Full Spritesheet / 32x32.png' (Clockwork Raven Studios).
Uso: python3 tools/gen_icons.py "<ruta a la hoja 32x32.png>"   (imprime el JS del mapa; guarda el atlas)
Cada entrada: (emojis, (fila, columna) de la hoja de 16 columnas[, 'azul'] ). Fila/columna empiezan en 0."""
import sys,json,colorsys
from PIL import Image
SHEET=sys.argv[1] if len(sys.argv)>1 else 'Free - Raven Fantasy Icons/Full Spritesheet/32x32.png'
M=[
 ('✦',(10,4)),('🏆',(0,14)),('📖',(6,0)),('⚙️',(0,1)),('🔮',(18,4)),('📜',(18,8)),('🎯',(134,9)),
 ('💀',(14,0)),('👹',(43,9)),('🦇',(43,12)),('🐺',(14,7)),('🍄',(16,0)),('🐉',(14,8)),('🪓',(91,8)),('🩸',(46,5)),
 ('🛡️',(41,7)),('🔥',(62,0)),('⚔️',(45,0)),('😈',(65,8)),('🌊',(51,2)),('⏱️⏳',(20,15)),('🧭',(2,10)),
 ('📈',(54,0)),('🛠️',(7,13)),('🧬',(0,13)),('☠️',(42,0)),('🌿',(15,1)),('⚡',(64,0)),('🌪️',(49,0)),
 ('🌑',(46,0)),('❄️',(63,5)),('💧',(46,5,'azul')),('🪨',(12,0)),('👟',(41,10)),('🔒',('custom','lock')),('✅',('custom','check')),
 ('🌋',(62,6)),('🌸',(16,6)),('🫧',(23,14)),('♥❤️',(41,2)),('💨',(45,3)),('🧲',(7,4)),('🥚',(14,11)),
 ('🌱',(56,4)),('♨️',(62,7)),('⛈️',(64,6)),('🌨️',(63,6)),('🕯️',(5,2)),('🔯',(20,2)),('🗡️',(94,0)),
 ('🌩️',(64,2)),('☄️',(47,10)),('🌀',(49,1)),('🧊',(63,0)),('🥀',(15,10)),('🌳',(1,15)),
 ('♜',(44,2)),('⬢',(113,0)),('❋',(60,9)),('☾',(52,8)),('✺',(47,14)),('◈',(10,13)),('◍',(113,1)),
 ('🔔',(61,10)),('🔱',(91,5)),('🕳️',(46,14)),('🌞',(61,13)),('🌠',(48,14)),('🔆',(96,3)),('🦅',(62,5)),
 ('⚖️',(7,11)),('✨',(61,9)),('⚛',(94,1))]
sh=Image.open(SHEET).convert('RGBA')
def custom(name):
    # Iconos propios (16x16 ampliados x2) con la misma paleta oscura de contorno que el pack
    pal={'O':(42,26,16),'G':(232,179,60),'g':(176,122,34),'h':(255,226,138),'S':(200,206,216),'s':(122,132,148),'K':(42,26,16)}
    if name=='lock':
        rows=['................','.....OOOOOO.....','....OSSSSSSO....','...OSsOOOOsSO...','...OSO....OSO...','...OSO....OSO...','...OSO....OSO...','..OOOOOOOOOOOO..',
              '.OhhhhhhhhhhhhO.','.OhGGGGGGGGGGgO.','.OhGGGGKKGGGGgO'[:16],'.OhGGGGKKGGGGgO'[:16],'.OhGGGGGKGGGGgO'[:16],'.OhGGGGGGGGGGgO.','.OggggggggggggO.','..OOOOOOOOOOOO..']
        rows=[r.ljust(16,'.')[:16] for r in rows];im=Image.new('RGBA',(16,16),(0,0,0,0));px=im.load()
        for y,r in enumerate(rows):
            for x,ch in enumerate(r):
                if ch in pal:px[x,y]=pal[ch]+(255,)
    else:
        from PIL import ImageDraw,ImageFilter
        base=Image.new('L',(16,16),0);d=ImageDraw.Draw(base);d.line([(3,8),(6,12),(13,4)],fill=255,width=3)
        base=base.point(lambda v:255 if v>90 else 0)
        edge=base.filter(ImageFilter.MaxFilter(3));im=Image.new('RGBA',(16,16),(0,0,0,0));px=im.load();b=base.load();e=edge.load()
        for y in range(16):
            for x in range(16):
                if e[x,y]:px[x,y]=(14,70,34,255)
                if b[x,y]:px[x,y]=(110,235,140,255) if y<8 or x>9 else (61,200,104,255)
    return im.resize((32,32),Image.NEAREST)
def cell(r,c):return sh.crop((c*32,r*32,c*32+32,r*32+32))
def azul(im):
    im=im.copy();px=im.load()
    for y in range(32):
        for x in range(32):
            r,g,b,a=px[x,y]
            if a:
                h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255);h=(h+0.58)%1
                r,g,b=[int(t*255) for t in colorsys.hsv_to_rgb(h,s,v)];px[x,y]=(r,g,b,a)
    return im
COLS=12;n=len(M);rows=(n+COLS-1)//COLS
at=Image.new('RGBA',(COLS*32,rows*32),(0,0,0,0));mp={}
for i,(em,pos) in enumerate(M):
    t=custom(pos[1]) if pos[0]=='custom' else cell(pos[0],pos[1]);t=azul(t) if len(pos)>2 else t
    at.alpha_composite(t,((i%COLS)*32,(i//COLS)*32))
    for ch in em.replace('\ufe0f',''):mp[ch]=[i%COLS,i//COLS]
at.save('assets/icons/raven.png',optimize=True)
# multi-codepoint emojis del mapa: ninguno; las claves son un solo carácter sin VS16
print('const ICM='+json.dumps(mp,ensure_ascii=False,separators=(',',':'))+',ICN='+str(COLS)+',ICR='+str(rows)+';')
# tablero de comprobación
pv=Image.new('RGBA',(COLS*100,rows*100),(34,26,48,255))
for i in range(n):pv.alpha_composite(at.crop(((i%COLS)*32,(i//COLS)*32,(i%COLS)*32+32,(i//COLS)*32+32)).resize((96,96),Image.NEAREST),((i%COLS)*100+2,(i//COLS)*100+2))
pv.convert('RGB').save('/home/claude/preview_icons.png')
