// Offline build step: turns dialogue-library.json into MP3 files with an authorized neural Hindi voice (Google Cloud Text-to-Speech).
// Needs: GOOGLE_APPLICATION_CREDENTIALS, billing enabled, and a licence/terms check for game use. Audition voices first:
//   list them with client.listVoices({languageCode:'hi-IN'}) and pick three that sound distinct to you.
// Usage: node generate-voice-audio.mjs dialogue-library.json out/audio/hi
import fs from 'node:fs'; import path from 'node:path';
import textToSpeech from '@google-cloud/text-to-speech';
const [lib, out] = [process.argv[2], process.argv[3] || 'audio/hi'];
const PERSONAS = [  // persona index = robot order in the game; "friend" commentary rotates through the same three
  { voice: 'hi-IN-Neural2-A', rate: 1.08, pitch: 2 },     // teasing / playful   (replace after auditioning)
  { voice: 'hi-IN-Neural2-B', rate: 0.95, pitch: -2 },    // dramatic / deep
  { voice: 'hi-IN-Neural2-C', rate: 1.15, pitch: 0 },     // excited / fast
];
const TONE = { dice6: [1.1, 3], sixes2: [1.15, 4], capture: [1.05, 2], captured: [1.1, 3], badluck: [0.92, -2], escape: [1.12, 3], win: [1.1, 3], defeat: [0.92, -2] }; // [rateMul, pitchAdd]
const client = new textToSpeech.TextToSpeechClient();
const data = JSON.parse(fs.readFileSync(lib, 'utf8')).categories;
for (const [cat, lines] of Object.entries(data)) for (const { id, text } of lines) {
  if (/\{[no]\}/.test(text)) continue;                    // lines with player names stay on device speech until name variants are recorded
  PERSONAS.forEach(async (p, i) => {
    const f = path.join(out, `p${i}`, `${id}.mp3`); if (fs.existsSync(f)) return;
    const [tr, tp] = TONE[cat] || [1, 0];
    const ssml = `<speak>${text.replace(/([!?।])\s/g, '$1<break time="260ms"/> ')}</speak>`;   // short comic pauses
    const [res] = await client.synthesizeSpeech({ input: { ssml }, voice: { languageCode: 'hi-IN', name: p.voice },
      audioConfig: { audioEncoding: 'MP3', speakingRate: p.rate * tr, pitch: p.pitch + tp } });
    fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, res.audioContent, 'binary');
  });
}
// In the game, register every file: FILES['hi.line.p<persona>.<id>'] = 'audio/hi/p<persona>/<id>.mp3'  (e.g. FILES['hi.line.p1.capture_3']).
