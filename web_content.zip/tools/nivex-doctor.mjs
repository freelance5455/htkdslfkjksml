import fs from 'node:fs';
const checks=['index.html','package.json','vite.config.ts','src/app.tsx','src/components/Editor.tsx','src/components/NivexCanvasPreview.tsx','public/nivex-logo.png','public/api/creator.json','vendor/create-vite-9.2.1/package.json'];
let ok=true;for(const f of checks){const yes=fs.existsSync(f);console.log(`${yes?'OK':'MISS'} ${f}`);ok&&=yes}
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));console.log(`NIVEX ${pkg.version} • Vite ${pkg.devDependencies?.vite||'n/a'} • create-vite ${pkg.devDependencies?.['create-vite']||'n/a'}`);process.exit(ok?0:1);
