// Dumps the English source strings (UI + legal) for translators → tools/translations/source-en.json
import fs from 'node:fs'; import vm from 'node:vm';
const ctx = { globalThis: null }; ctx.globalThis = ctx; vm.createContext(ctx);
for (const f of ['src/i18n.js', 'src/legal-texts.js']) vm.runInContext(fs.readFileSync(f, 'utf8'), ctx);
fs.writeFileSync('tools/translations/source-en.json', JSON.stringify({ ui: ctx.AN_I18N.en, legal: ctx.AN_LEGAL.en }, null, 1));
console.log('keys:', Object.keys(ctx.AN_I18N.en).length);
