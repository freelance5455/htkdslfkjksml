/**
 * Engine 1: Name Combiner
 * Phonetic segmentation, overlap detection, prefix-suffix crossover, 3-name blending, and readability scoring.
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('combiner-form');
  const resultsContainer = document.getElementById('results-list');
  const resultsCountSpan = document.getElementById('results-count');
  const emptyState = document.getElementById('empty-state');
  const resultsCard = document.getElementById('results-card');
  const resetBtn = document.getElementById('reset-btn');
  const copyAllBtn = document.getElementById('copy-all-btn');

  if (!form) return;

  function cleanName(str) {
    return (str || '').trim().replace(/[^a-zA-Z\s]/g, '');
  }

  function getSyllables(word) {
    word = word.toLowerCase();
    if (word.length <= 3) return [word];
    const vowels = 'aeiouy';
    const chunks = [];
    let cur = '';
    for (let i = 0; i < word.length; i++) {
      cur += word[i];
      if (vowels.includes(word[i]) && i < word.length - 1 && !vowels.includes(word[i + 1])) {
        chunks.push(cur);
        cur = '';
      }
    }
    if (cur) chunks.push(cur);
    return chunks.length > 0 ? chunks : [word];
  }

  function calculateScore(name, n1, n2) {
    let score = 70;
    const len = name.length;
    // Ideal length 4 to 8 chars
    if (len >= 4 && len <= 8) score += 15;
    else if (len < 3 || len > 12) score -= 20;

    // Vowel-consonant balance
    const vowels = (name.match(/[aeiouy]/gi) || []).length;
    const ratio = vowels / len;
    if (ratio >= 0.35 && ratio <= 0.6) score += 15;

    // Pronounceability penalty for triple consonants
    if (/[bcdfghjklmnpqrstvwxyz]{3,}/i.test(name)) score -= 25;

    return Math.min(99, Math.max(45, score));
  }

  function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  function generateCombinations(n1, n2, n3, style, count) {
    n1 = cleanName(n1);
    n2 = cleanName(n2);
    n3 = cleanName(n3);

    const candidates = new Set();

    // 1. Prefix + Suffix cross
    const p1 = n1.slice(0, Math.ceil(n1.length / 2));
    const s1 = n1.slice(Math.floor(n1.length / 2));
    const p2 = n2.slice(0, Math.ceil(n2.length / 2));
    const s2 = n2.slice(Math.floor(n2.length / 2));

    candidates.add(p1 + s2);
    candidates.add(p2 + s1);
    candidates.add(n1.slice(0, 2) + n2.slice(-3));
    candidates.add(n2.slice(0, 2) + n1.slice(-3));
    candidates.add(n1.slice(0, 3) + n2.slice(2));
    candidates.add(n2.slice(0, 3) + n1.slice(2));

    // 2. Overlap blending
    for (let i = 1; i < n1.length; i++) {
      const endChunk = n1.slice(i).toLowerCase();
      if (n2.toLowerCase().startsWith(endChunk)) {
        candidates.add(n1.slice(0, i) + n2);
      }
    }
    for (let i = 1; i < n2.length; i++) {
      const endChunk = n2.slice(i).toLowerCase();
      if (n1.toLowerCase().startsWith(endChunk)) {
        candidates.add(n2.slice(0, i) + n1);
      }
    }

    // 3. Syllable Splices
    const syl1 = getSyllables(n1);
    const syl2 = getSyllables(n2);
    syl1.forEach(c1 => {
      syl2.forEach(c2 => {
        candidates.add(c1 + c2);
        candidates.add(c2 + c1);
      });
    });

    // 4. If Name 3 exists, inject into combinations
    if (n3) {
      const p3 = n3.slice(0, Math.ceil(n3.length / 2));
      const s3 = n3.slice(Math.floor(n3.length / 2));
      candidates.add(p1 + p2.slice(0, 2) + s3);
      candidates.add(p3 + s1.slice(-2) + s2);
      candidates.add(n1.slice(0, 2) + n2.slice(0, 2) + n3.slice(-2));
      candidates.add(p2 + p3 + s1);
    }

    // Style-specific transformations
    const list = Array.from(candidates).map(name => {
      let transformed = capitalize(name);
      if (style === 'short' && transformed.length > 6) {
        transformed = transformed.slice(0, 5);
      }
      const score = calculateScore(transformed, n1, n2);
      return { name: transformed, score };
    });

    // Filter duplicates, sort by score
    const uniqueMap = new Map();
    list.forEach(item => {
      if (item.name.length >= 3 && !uniqueMap.has(item.name.toLowerCase())) {
        uniqueMap.set(item.name.toLowerCase(), item);
      }
    });

    return Array.from(uniqueMap.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, parseInt(count, 10) || 10);
  }

  function renderResults(results) {
    resultsContainer.innerHTML = '';
    if (results.length === 0) {
      emptyState.classList.remove('hidden');
      resultsCard.classList.add('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    resultsCard.classList.remove('hidden');
    resultsCountSpan.textContent = results.length;

    results.forEach((item, index) => {
      const isFav = window.FavoritesManager ? window.FavoritesManager.isFavorite(item.name) : false;
      const card = document.createElement('div');
      card.className = 'result-card flex items-center justify-between p-3.5 sm:p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 shadow-sm animate-fade-in';
      card.innerHTML = `
        <div class="flex items-center gap-3">
          <span class="w-6 text-xs font-bold text-slate-400 dark:text-slate-500">${index + 1}.</span>
          <div>
            <span class="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-wide">${item.name}</span>
            <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50">
              ${item.score}% Match
            </span>
          </div>
        </div>
        <div class="flex items-center gap-1.5 sm:gap-2">
          <button type="button" class="copy-single-btn p-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Copy name" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
          </button>
          <button type="button" class="fav-single-btn p-2 text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition ${isFav ? 'text-rose-500 dark:text-rose-400' : ''}" title="Favorite" data-name="${item.name}">
            <svg class="w-4 h-4" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
          </button>
          <button type="button" class="share-single-btn p-2 text-slate-500 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition" title="Share" data-name="${item.name}">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
          </button>
        </div>
      `;
      resultsContainer.appendChild(card);
    });

    // Bind event listeners
    resultsContainer.querySelectorAll('.copy-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.copyToClipboard(btn.dataset.name));
    });

    resultsContainer.querySelectorAll('.fav-single-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const isAdded = window.FavoritesManager.toggle(name, 'Core Tools', 'Name Combiner');
        const icon = btn.querySelector('svg');
        if (isAdded) {
          btn.classList.add('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'currentColor');
        } else {
          btn.classList.remove('text-rose-500', 'dark:text-rose-400');
          icon.setAttribute('fill', 'none');
        }
      });
    });

    resultsContainer.querySelectorAll('.share-single-btn').forEach(btn => {
      btn.addEventListener('click', () => window.shareName(btn.dataset.name, 'Name Combiner'));
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name1 = document.getElementById('name1').value;
    const name2 = document.getElementById('name2').value;
    const name3 = document.getElementById('name3')?.value || '';
    const style = document.getElementById('style-select')?.value || 'creative';
    const count = document.getElementById('count-select')?.value || 10;

    if (!cleanName(name1) || !cleanName(name2)) {
      if (window.showToast) window.showToast('Please enter both Name 1 and Name 2', 'error');
      return;
    }

    const results = generateCombinations(name1, name2, name3, style, count);
    renderResults(results);
    resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      resultsContainer.innerHTML = '';
      resultsCard.classList.add('hidden');
      emptyState.classList.remove('hidden');
    });
  }

  if (copyAllBtn) {
    copyAllBtn.addEventListener('click', () => {
      const names = Array.from(resultsContainer.querySelectorAll('.result-card span.tracking-wide'))
        .map(el => el.textContent.trim());
      if (names.length > 0) {
        window.copyToClipboard(names.join('\n'), `Copied ${names.length} names!`);
      }
    });
  }
});
