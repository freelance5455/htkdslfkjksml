// Usage: node tools/check-translation.mjs <lang>   — validates tools/translations/<lang>.json against source-en.json
import fs from 'node:fs';
const lang = process.argv[2]; const src = JSON.parse(fs.readFileSync('tools/translations/source-en.json', 'utf8'));
let tr; try { tr = JSON.parse(fs.readFileSync(`tools/translations/${lang}.json`, 'utf8')); } catch (e) { console.log('INVALID JSON:', e.message); process.exit(1); }
let bad = 0; const say = m => { bad++; if (bad < 60) console.log(m); };
const ph = s => (String(s).match(/\{\w+\}/g) || []).sort().join(',');
for (const k of Object.keys(src.ui)) {
  if (!(k in (tr.ui || {}))) { say('missing ui key: ' + k); continue; }
  if (typeof tr.ui[k] !== 'string') { say('not a string: ' + k); continue; }
  if (ph(src.ui[k]) !== ph(tr.ui[k])) say(`placeholder mismatch in ${k}: ${ph(src.ui[k])} vs ${ph(tr.ui[k])}`);
  if (src.ui[k].trim() && !tr.ui[k].trim()) say('empty translation: ' + k);
}
for (const k of Object.keys(tr.ui || {})) if (!(k in src.ui)) say('extra ui key: ' + k);
for (const kind of ['terms', 'privacy']) {
  const a = src.legal[kind], b = (tr.legal || {})[kind];
  if (!b) { say('missing legal.' + kind); continue; }
  if (!b.title || ph(a.intro) !== ph(b.intro)) say(`legal.${kind} title/intro problem`);
  if (a.sections.length !== b.sections.length) { say(`legal.${kind} sections count ${a.sections.length} vs ${b.sections.length}`); continue; }
  a.sections.forEach((s, i) => { const t = b.sections[i]; if (!Array.isArray(t) || t.length !== s.length) return say(`legal.${kind}[${i}] shape`); for (let j = 0; j < s.length; j++) if (ph(s[j]) !== ph(t[j])) say(`legal.${kind}[${i}][${j}] placeholders ${ph(s[j])} vs ${ph(t[j])}`); });
}
console.log(bad ? `${bad} PROBLEMS` : `OK ${lang}: ${Object.keys(tr.ui).length} ui keys, legal ok`); process.exit(bad ? 1 : 0);
