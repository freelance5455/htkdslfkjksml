import { cp, mkdir, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const vendor = new URL('../www/vendor/', import.meta.url);
await mkdir(vendor, { recursive: true });
const files = [
  ['node_modules/leaflet/dist/leaflet.js', 'leaflet.js'],
  ['node_modules/leaflet/dist/leaflet.css', 'leaflet.css'],
  ['node_modules/leaflet/dist/images', 'images'],
  ['node_modules/chart.js/dist/chart.umd.js', 'chart.umd.js']
];
for (const [from, to] of files) {
  if (!existsSync(from)) throw new Error(`Missing ${from}. Run npm install first.`);
  await rm(new URL(to, vendor), { recursive: true, force: true });
  await cp(from, new URL(to, vendor), { recursive: true });
}
console.log('Vendored Leaflet and Chart.js into www/vendor.');
