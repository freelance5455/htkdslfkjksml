import fs from 'node:fs';
import path from 'node:path';
const root=process.argv[2]||process.cwd(), src=path.join(root,'src');
const files=fs.readdirSync(src).filter(f=>f.endsWith('.js'));
const mods={};
for(const f of files){mods[f.replace('.js','')]={code:fs.readFileSync(path.join(src,f),'utf8'),deps:[]};}
const importRe=/^import\s*(?:\{([\s\S]*?)\}|(\*\s+as\s+\w+)|(\w+))\s*from\s*['"]\.\/([\w-]+)\.js['"];?[ \t]*$/gm;
function transform(name,code){
  const deps=new Set();let out=code;
  out=out.replace(importRe,(m,named,star,def,dep)=>{
    deps.add(dep);
    if(star)throw new Error('namespace import in '+name);
    if(def)throw new Error('default import in '+name);
    const spec=named.split(',').map(x=>x.trim()).filter(Boolean).map(x=>x.replace(/\s+as\s+/,': ')).join(', ');
    return `const { ${spec} } = __m['${dep}'];`;
  });
  const names=[];
  out=out.replace(/^export\s+(async\s+function\s*\*?|function\s*\*?|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm,(m,kind,id)=>{names.push(id);return `${kind} ${id}`;});
  out=out.replace(/^export\s*\{([^}]*)\};?[ \t]*$/gm,(m,list)=>{for(const x of list.split(',').map(s=>s.trim()).filter(Boolean)){const [a,b]=x.split(/\s+as\s+/);names.push(b?`${b}: ${a}`:a);}return '';});
  if(/^export\s/m.test(out))throw new Error('export restant dans '+name);
  if(/^import\s/m.test(out))throw new Error('import restant dans '+name);
  const exp=names.map(n=>n.includes(':')?n:`${n}`).join(', ');
  return {deps:[...deps],body:`__m['${name}'] = (() => {\n${out}\nreturn { ${exp} };\n})();`};
}
for(const n of Object.keys(mods)){const t=transform(n,mods[n].code);mods[n].deps=t.deps;mods[n].body=t.body;}
// tri topologique
const order=[],state={};
function visit(n,stack=[]){if(state[n]==='done')return;if(state[n]==='visiting')throw new Error('cycle: '+[...stack,n].join(' -> '));state[n]='visiting';for(const d of mods[n].deps){if(!mods[d])throw new Error('module manquant '+d);visit(d,[...stack,n]);}state[n]='done';order.push(n);}
for(const n of Object.keys(mods))if(n!=='app')visit(n);
visit('app');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
// script inline orientation
const inlineRe=/<script type="module">\s*import \{ initLandscapeGuidance \} from "\.\/src\/orientation\.js"([\s\S]*?)<\/script>/;
const mInline=html.match(inlineRe);
if(!mInline)throw new Error('script orientation introuvable');
const inlineBody=mInline[1].trim().replace(/^;/,'');
html=html.replace(inlineRe,'').replace('<script type="module" src="./src/app.js"></script>','');
html=html.replace(/<link rel="manifest"[^>]*>/,'').replace(/<link rel="(apple-touch-icon|icon)"[^>]*>/g,'');
const bundle=`<script>\n'use strict';\n(function(){\nconst __m={};\n${order.map(n=>mods[n].body).join('\n')}\nconst { initLandscapeGuidance } = __m['orientation'];\n${inlineBody}\n})();\n</script>`;
html=html.replace('</body>',bundle.replace(/\$/g,'$$$$')+'\n</body>');
fs.writeFileSync(process.argv[3]||path.join(root,'CGD_apercu.html'),html);
console.log('ok',order.length,'modules',Math.round(html.length/1024)+' Ko');
