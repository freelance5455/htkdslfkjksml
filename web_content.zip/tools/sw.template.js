// Service worker generado por tools/build.js desde tools/sw.template.js. NO editar sw.js a mano.
// Estrategia: index/manifest "red primero" (con caída a caché sin conexión); el resto "caché primero".
// La versión nueva NO se activa sola: la página muestra «Nueva versión disponible» y envía 'skip' al pulsar ACTUALIZAR.
const C='__CACHE__',CORE=__CORE__,ASSETS=__ASSETS__;
const tmo=(p,ms)=>new Promise((ok,ko)=>{const t=setTimeout(()=>ko(new Error('timeout')),ms);p.then(v=>{clearTimeout(t);ok(v)},e=>{clearTimeout(t);ko(e)})});
const put=(r,res)=>{if(res&&res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(r,cp)).catch(()=>{})}return res};
self.addEventListener('install',e=>e.waitUntil((async()=>{const c=await caches.open(C);await c.addAll(CORE);await Promise.all(ASSETS.map(u=>c.add(u).catch(()=>{})))})()));
self.addEventListener('message',e=>{if(e.data==='skip')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.origin!==self.location.origin)return;
  if(r.mode==='navigate'||/(\/|\/index\.html|\/manifest\.webmanifest)$/.test(u.pathname)){
    e.respondWith(tmo(fetch(u.href,{cache:'no-cache'}),5000).then(res=>put(r,res)).catch(()=>caches.match(r,{ignoreSearch:true}).then(m=>m||caches.match('index.html')).then(m=>m||new Response('Sin conexión',{status:503}))));return}
  e.respondWith(caches.match(r).then(m=>m||fetch(r).then(res=>put(r,res))).catch(()=>new Response('',{status:504})));
});
