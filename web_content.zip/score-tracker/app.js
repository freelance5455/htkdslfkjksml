

/* ===== Icons (inline SVG) ===== */
const ICONS = {
  sun: `<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`,
  moon: `<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`,
  plus: `<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>`,
  trash: `<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`,
  check: `<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`,
  alert: `<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`,
};

/* ===== Toast ===== */
function toast(msg, type = 'success') {
  const host = document.getElementById('toastHost');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  const iconHtml = type === 'success' ? ICONS.check : ICONS.alert;
  el.innerHTML = iconHtml + '<span>' + msg + '</span>';
  host.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 260);
  }, 2600);
}

/* ===== Jalali + week Sat–Fri ===== */
const PERSIAN_MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const WEEK_DAYS = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];

function toJalali(gy, gm, gd) {
  const g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
  let jy = (gy <= 1600) ? 0 : 979;
  gy -= (gy <= 1600) ? 621 : 1600;
  let gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
  let jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  let jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
  return { jy, jm, jd };
}
function jalaliParts(date) {
  const d = date instanceof Date ? date : new Date(date);
  const { jy, jm, jd } = toJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return { jy, jm, jd, monthName: PERSIAN_MONTHS[jm - 1] };
}
function formatJalaliDay(date) {
  const j = jalaliParts(date);
  return j.jd + ' ' + j.monthName;
}
function weekRangeText(sat) {
  const fri = new Date(sat); fri.setDate(fri.getDate() + 6);
  const a = jalaliParts(sat), b = jalaliParts(fri);
  if (a.jm === b.jm) return a.jd + ' تا ' + b.jd + ' ' + a.monthName;
  return a.jd + ' ' + a.monthName + ' تا ' + b.jd + ' ' + b.monthName;
}
function getSaturday(d = new Date()) {
  const date = new Date(d); date.setHours(0,0,0,0);
  const diff = (date.getDay() + 1) % 7;
  date.setDate(date.getDate() - diff);
  return date;
}
function getViewSaturday() {
  const sat = getSaturday(new Date());
  sat.setDate(sat.getDate() + weekOffset * 7);
  return sat;
}
function updateWeekNavButtons() {
  const nextBtn = document.getElementById('weekNextBtn');
  const prevBtn = document.getElementById('weekPrevBtn');
  if (nextBtn) nextBtn.disabled = weekOffset >= 0;
  if (prevBtn) prevBtn.disabled = false; // allow unlimited past
}
function isoDate(d) {
  const x = new Date(d);
  return x.getFullYear() + '-' + String(x.getMonth()+1).padStart(2,'0') + '-' + String(x.getDate()).padStart(2,'0');
}
function todayStr() { return isoDate(new Date()); }

/* ===== Offline emojis (Fluent 3D) ===== */
const EMOJI_IDS = ['ok','smile','sad','star','fire','thumbsup','party','muscle','blush','cry'];
const EMOJI_PATH = id => 'emojis/' + id + '.png';

/* ===== Data ===== */
const STORAGE_KEY = 'scoreTrackerData_v4';
const DEFAULT_QUAL = [
  { min: 0, max: 39, label: 'ضعیف', emoji: 'sad' },
  { min: 40, max: 69, label: 'متوسط', emoji: 'smile' },
  { min: 70, max: 100, label: 'عالی', emoji: 'ok' }
];

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { scores: [-2,0,1,2,3], tasks: [], logs: [], qual: DEFAULT_QUAL, theme: 'dark' };
    const d = JSON.parse(raw);
    if (!d.qual) d.qual = DEFAULT_QUAL;
    // migrate old unicode emoji to ids
    d.qual = d.qual.map(q => {
      if (EMOJI_IDS.includes(q.emoji)) return q;
      const map = { '😞':'sad','🙂':'smile','👌':'ok','⭐':'star','🔥':'fire','👍':'thumbsup','🎉':'party','💪':'muscle','😊':'blush','😢':'cry' };
      return { ...q, emoji: map[q.emoji] || 'star' };
    });
    if (!d.theme) d.theme = 'dark';
    return d;
  } catch {
    return { scores: [-2,0,1,2,3], tasks: [], logs: [], qual: DEFAULT_QUAL, theme: 'dark' };
  }
}
function saveData() { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
let data = loadData();
let weekOffset = 0; // 0 = current week, -1 = previous, etc. never > 0

function maxScore() { return Math.max(...data.scores.filter(s => s > 0), 1); }
function getQual(pct) {
  if (isNaN(pct)) return null;
  for (const q of data.qual) if (pct >= q.min && pct <= q.max) return q;
  return data.qual[data.qual.length - 1] || null;
}
function applyQual(pct, imgEl, textEl) {
  const q = getQual(pct);
  if (!q) { if (imgEl) imgEl.removeAttribute('src'); if (textEl) textEl.textContent = ''; return; }
  if (textEl) textEl.textContent = q.label + ' · ' + pct + '%';
  if (imgEl) { imgEl.src = EMOJI_PATH(q.emoji); imgEl.alt = q.label; }
}

function getWeekDays(sat) {
  const today = todayStr(), days = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(sat); d.setDate(d.getDate() + i);
    const iso = isoDate(d);
    days.push({ date: iso, label: WEEK_DAYS[i], jalali: formatJalaliDay(d), isToday: iso === today, isPastOrToday: iso <= today });
  }
  return days;
}
function findLog(taskId, date) { return data.logs.find(l => l.taskId === taskId && l.date === date); }
function escapeHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  data.theme = theme; saveData();
  const sw = document.getElementById('themeSwitch');
  if (sw) sw.checked = theme === 'light';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'light' ? '#faf6f0' : '#1a1612';
  // update sun/moon
  const btn = document.getElementById('themeToggleBtn');
  if (btn) {
    btn.innerHTML = theme === 'light' ? ICONS.moon : ICONS.sun;
  }
}

/* ===== Render ===== */
function renderWeekHeader() {
  document.getElementById('weekRange').textContent = weekRangeText(getViewSaturday());
  updateWeekNavButtons();
}

function renderWeekTable() {
  const sat = getViewSaturday(), days = getWeekDays(sat);
  const thead = document.querySelector('#weekTable thead');
  const tbody = document.querySelector('#weekTable tbody');
  let h = '<tr><th>روز</th>';
  data.tasks.forEach(t => { h += '<th>' + escapeHtml(t.name) + '</th>'; });
  h += '<th>جمع</th></tr>';
  thead.innerHTML = h;

  if (!data.tasks.length) {
    tbody.innerHTML = '<tr><td colspan="2" class="empty">از تب کارها یک کار اضافه کنید</td></tr>';
    document.getElementById('weekSum').textContent = '0';
    applyQual(0, document.getElementById('weekQualImg'), document.getElementById('weekQualText'));
    return;
  }

  let elapsedTotal = 0, elapsedDays = 0, rows = '';
  days.forEach(day => {
    let daySum = 0;
    rows += '<tr class="' + (day.isToday ? 'today' : '') + '">';
    rows += '<td>' + day.label + '<br><small style="opacity:.65;font-size:.75em">' + day.jalali + '</small></td>';
    data.tasks.forEach(t => {
      const log = findLog(t.id, day.date);
      if (log) {
        daySum += log.score;
        const cls = log.score > 0 ? 'pos' : log.score < 0 ? 'neg' : 'zero';
        const txt = log.score > 0 ? '+' + log.score : log.score;
        rows += '<td><span class="cell ' + cls + '" data-logid="' + log.id + '">' + txt + '</span></td>';
      } else {
        rows += '<td><span class="cell empty" data-task="' + t.id + '" data-date="' + day.date + '">+</span></td>';
      }
    });
    rows += '<td><strong>' + (daySum > 0 ? '+' + daySum : daySum) + '</strong></td></tr>';
    if (day.isPastOrToday) { elapsedTotal += daySum; elapsedDays++; }
  });
  tbody.innerHTML = rows;
  document.getElementById('weekSum').textContent = elapsedTotal > 0 ? '+' + elapsedTotal : elapsedTotal;
  const maxElapsed = data.tasks.length * maxScore() * Math.max(elapsedDays, 1);
  const pct = maxElapsed > 0 ? Math.round((elapsedTotal / maxElapsed) * 100) : 0;
  applyQual(pct, document.getElementById('weekQualImg'), document.getElementById('weekQualText'));

  tbody.querySelectorAll('.cell[data-logid]').forEach(el => el.onclick = () => openScoreModal(el.dataset.logid));
  tbody.querySelectorAll('.cell.empty').forEach(el => el.onclick = () => openScoreModal(null, el.dataset.task, el.dataset.date));
}

function renderTasksList() {
  const list = document.getElementById('tasksList');
  if (!data.tasks.length) { list.innerHTML = '<div class="empty">کاری تعریف نشده</div>'; return; }
  list.innerHTML = data.tasks.map(t =>
    '<div class="list-item"><span>' + escapeHtml(t.name) + '</span>' +
    '<button data-id="' + t.id + '" aria-label="حذف">' + ICONS.trash + '</button></div>'
  ).join('');
  
  list.querySelectorAll('button').forEach(btn => {
    btn.onclick = () => {
      if (!confirm('حذف این کار؟')) return;
      data.tasks = data.tasks.filter(x => x.id !== btn.dataset.id);
      saveData(); refreshAll(); toast('کار حذف شد');
    };
  });
}


function renderReports() {
  const sat = getViewSaturday();
  const days = getWeekDays(sat);
  const maxPerDay = data.tasks.length * maxScore();

  // ----- Weekly -----
  let elapsedTotal = 0, elapsedDays = 0;
  const wBody = document.querySelector('#reportWeekTable tbody');
  let wRows = '';
  days.forEach(day => {
    let sum = 0;
    data.tasks.forEach(t => { const l = findLog(t.id, day.date); if (l) sum += l.score; });
    if (day.isPastOrToday) { elapsedTotal += sum; elapsedDays++; }
    const pct = maxPerDay > 0 ? Math.round((sum / maxPerDay) * 100) : 0;
    wRows += '<tr class="' + (day.isToday ? 'today' : '') + '"><td>' + day.label + ' · ' + day.jalali +
      '</td><td>' + (sum > 0 ? '+' + sum : sum) + '</td><td>' + maxPerDay + '</td><td>' + pct + '%</td></tr>';
  });
  wBody.innerHTML = wRows || '<tr><td colspan="4" class="empty">—</td></tr>';
  const maxE = maxPerDay * Math.max(elapsedDays, 1);
  const weekPct = maxE > 0 ? Math.round((elapsedTotal / maxE) * 100) : 0;
  const wQ = getQual(weekPct);
  document.getElementById('rWeekStats').innerHTML =
    'مجموع تا امروز: <strong>' + (elapsedTotal > 0 ? '+' + elapsedTotal : elapsedTotal) +
    '</strong> · حداکثر: <strong>' + maxE + '</strong> · درصد: <strong>' + weekPct + '%</strong>' +
    (wQ ? ' · <span class="qi"><img src="' + EMOJI_PATH(wQ.emoji) + '" alt=""/>' + wQ.label + '</span>' : '');

  // ----- Monthly: one card per month that has data or current month -----
  // Build map: "jy-jm" -> { total, dayCount, maxDays }
  const monthMap = {}; // key: jy-jm
  data.logs.forEach(log => {
    const d = new Date(log.date + 'T12:00:00');
    const j = jalaliParts(d);
    const key = j.jy + '-' + String(j.jm).padStart(2, '0');
    if (!monthMap[key]) monthMap[key] = { jy: j.jy, jm: j.jm, total: 0, daysWithLog: new Set(), label: j.monthName + ' ' + j.jy };
    monthMap[key].total += log.score;
    monthMap[key].daysWithLog.add(log.date);
  });

  // Always include current Jalali month
  const nowJ = jalaliParts(new Date());
  const curKey = nowJ.jy + '-' + String(nowJ.jm).padStart(2, '0');
  if (!monthMap[curKey]) {
    monthMap[curKey] = { jy: nowJ.jy, jm: nowJ.jm, total: 0, daysWithLog: new Set(), label: nowJ.monthName + ' ' + nowJ.jy };
  }

  // Days in Jalali month (approx): 1-6: 31, 7-11: 30, 12: 29/30
  function jalaliMonthLength(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    // Esfand: leap roughly
    return 29;
  }

  // For max score of a month: tasks * maxScore * days elapsed in that month (or full month if past)
  function monthMaxScore(jy, jm) {
    const len = jalaliMonthLength(jy, jm);
    // Count how many calendar days of this Jalali month have passed (up to today)
    let elapsed = 0;
    // Scan gregorian range covering this month is hard; use days that exist in logs + today if current
    // Simpler: max = tasks * maxScore * number of distinct days we could have scored
    // Use: for past months full length; for current month use day-of-month
    if (jy === nowJ.jy && jm === nowJ.jm) {
      elapsed = nowJ.jd; // days from 1 to today in current month
    } else if (jy > nowJ.jy || (jy === nowJ.jy && jm > nowJ.jm)) {
      elapsed = 0;
    } else {
      elapsed = len;
    }
    return data.tasks.length * maxScore() * Math.max(elapsed, 1);
  }

  const monthKeys = Object.keys(monthMap).sort().reverse();
  const monthBox = document.getElementById('monthReports');
  if (!monthKeys.length) {
    monthBox.innerHTML = '<div class="empty">هنوز داده‌ای ثبت نشده</div>';
  } else {
    monthBox.innerHTML = monthKeys.map(key => {
      const m = monthMap[key];
      const maxS = monthMaxScore(m.jy, m.jm);
      const pct = maxS > 0 ? Math.round((m.total / maxS) * 100) : 0;
      const q = getQual(pct);
      const totalStr = m.total > 0 ? '+' + m.total : String(m.total);
      return '<div class="month-card">' +
        '<div class="month-card-head">' +
          '<strong>' + m.label + '</strong>' +
          (q ? '<span class="qi"><img src="' + EMOJI_PATH(q.emoji) + '" alt=""/>' + q.label + '</span>' : '') +
        '</div>' +
        '<div class="month-card-stats">' +
          '<div><span class="muted">مجموع</span><strong>' + totalStr + '</strong></div>' +
          '<div><span class="muted">حداکثر</span><strong>' + maxS + '</strong></div>' +
          '<div><span class="muted">درصد</span><strong>' + pct + '%</strong></div>' +
          '<div><span class="muted">روزهای ثبت‌شده</span><strong>' + m.daysWithLog.size + '</strong></div>' +
        '</div>' +
        '<div class="pct-bar"><div class="pct-fill" style="width:' + Math.min(100, Math.max(0, pct)) + '%"></div></div>' +
      '</div>';
    }).join('');
  }

  // ----- Yearly: for each year, table of 12 months -----
  const yearMap = {}; // jy -> { jm -> total }
  Object.values(monthMap).forEach(m => {
    if (!yearMap[m.jy]) yearMap[m.jy] = {};
    yearMap[m.jy][m.jm] = m.total;
  });
  // ensure current year
  if (!yearMap[nowJ.jy]) yearMap[nowJ.jy] = {};

  const yearBox = document.getElementById('yearReports');
  const years = Object.keys(yearMap).map(Number).sort((a, b) => b - a);
  if (!years.length) {
    yearBox.innerHTML = '<div class="empty">—</div>';
  } else {
    yearBox.innerHTML = years.map(jy => {
      let yearTotal = 0;
      let yearMax = 0;
      let rows = '';
      for (let jm = 1; jm <= 12; jm++) {
        const total = yearMap[jy][jm] || 0;
        yearTotal += total;
        const maxS = monthMaxScore(jy, jm);
        // only count max for months that started
        if (jy < nowJ.jy || (jy === nowJ.jy && jm <= nowJ.jm)) yearMax += maxS;
        const pct = maxS > 0 && (jy < nowJ.jy || (jy === nowJ.jy && jm <= nowJ.jm))
          ? Math.round((total / maxS) * 100) : 0;
        const q = (jy < nowJ.jy || (jy === nowJ.jy && jm <= nowJ.jm)) ? getQual(pct) : null;
        const isCur = jy === nowJ.jy && jm === nowJ.jm;
        const totalStr = total > 0 ? '+' + total : String(total);
        rows += '<tr class="' + (isCur ? 'today' : '') + '">' +
          '<td>' + PERSIAN_MONTHS[jm - 1] + '</td>' +
          '<td>' + totalStr + '</td>' +
          '<td>' + ((jy < nowJ.jy || (jy === nowJ.jy && jm <= nowJ.jm)) ? maxS : '—') + '</td>' +
          '<td>' + ((jy < nowJ.jy || (jy === nowJ.jy && jm <= nowJ.jm)) ? pct + '%' : '—') + '</td>' +
          '<td>' + (q ? '<span class="qi"><img src="' + EMOJI_PATH(q.emoji) + '" alt=""/>' + q.label + '</span>' : '—') + '</td>' +
        '</tr>';
      }
      const yPct = yearMax > 0 ? Math.round((yearTotal / yearMax) * 100) : 0;
      const yQ = getQual(yPct);
      return '<div class="year-block">' +
        '<div class="month-card-head">' +
          '<strong>سال ' + jy + '</strong>' +
          (yQ ? '<span class="qi"><img src="' + EMOJI_PATH(yQ.emoji) + '" alt=""/>' + yQ.label + ' · ' + yPct + '%</span>' : '') +
        '</div>' +
        '<div class="table-wrap"><table class="data-table compact">' +
          '<thead><tr><th>ماه</th><th>مجموع</th><th>حداکثر</th><th>درصد</th><th>ارزیابی</th></tr></thead>' +
          '<tbody>' + rows + '</tbody></table></div>' +
        '<div class="report-stats">مجموع سال: <strong>' + (yearTotal > 0 ? '+' + yearTotal : yearTotal) +
          '</strong> · حداکثر: <strong>' + yearMax + '</strong> · درصد: <strong>' + yPct + '%</strong></div>' +
      '</div>';
    }).join('');
  }
}

let emojiPickCallback = null;
function renderQualSettings() {
  const list = document.getElementById('qualList');
  list.innerHTML = data.qual.map((q, i) =>
    '<div class="qual-row">' +
    '<input type="number" class="q-min" value="' + q.min + '"/>' +
    '<input type="number" class="q-max" value="' + q.max + '"/>' +
    '<input type="text" class="q-label" value="' + escapeHtml(q.label) + '"/>' +
    '<button type="button" class="emoji-pick" data-i="' + i + '"><img src="' + EMOJI_PATH(q.emoji) + '" alt=""/></button>' +
    '<button type="button" class="q-del" data-i="' + i + '">×</button></div>'
  ).join('');
  list.querySelectorAll('.q-del').forEach(btn => {
    btn.onclick = () => { data.qual.splice(+btn.dataset.i, 1); renderQualSettings(); };
  });
  list.querySelectorAll('.emoji-pick').forEach(btn => {
    btn.onclick = () => openEmojiPicker(id => {
      data.qual[+btn.dataset.i].emoji = id;
      renderQualSettings();
    }, data.qual[+btn.dataset.i].emoji);
  });
}

function refreshAll() {
  renderWeekHeader();
  renderWeekTable();
  renderTasksList();
  renderReports();
  document.getElementById('scoresInput').value = data.scores.join(', ');
  renderQualSettings();
  applyTheme(data.theme || 'dark');
}

/* ===== Modals ===== */
function openScoreModal(logId, taskId, date) {
  const modal = document.getElementById('scoreModal');
  const delBtn = document.getElementById('modalDelete');
  document.getElementById('editingLogId').value = '';
  document.getElementById('logNote').value = '';
  delBtn.hidden = true;
  let selected = null;

  if (logId) {
    const log = data.logs.find(l => l.id === logId);
    if (!log) return;
    const task = data.tasks.find(t => t.id === log.taskId);
    document.getElementById('modalTitle').textContent = 'ویرایش امتیاز';
    document.getElementById('modalMeta').textContent = (task ? task.name : '') + ' · ' + formatJalaliDay(new Date(log.date));
    document.getElementById('editingLogId').value = log.id;
    document.getElementById('modalTaskId').value = log.taskId;
    document.getElementById('modalDate').value = log.date;
    document.getElementById('logNote').value = log.note || '';
    selected = log.score;
    delBtn.hidden = false;
  } else {
    const task = data.tasks.find(t => t.id === taskId);
    document.getElementById('modalTitle').textContent = 'ثبت امتیاز';
    document.getElementById('modalMeta').textContent = (task ? task.name : '') + ' · ' + formatJalaliDay(new Date(date));
    document.getElementById('modalTaskId').value = taskId;
    document.getElementById('modalDate').value = date;
  }

  const grid = document.getElementById('scoreButtons');
  grid.innerHTML = '';
  data.scores.forEach(s => {
    const btn = document.createElement('button');
    btn.className = 'score-chip ' + (s > 0 ? 'pos' : s < 0 ? 'neg' : '');
    if (selected !== null && selected === s) btn.classList.add('selected');
    btn.textContent = s > 0 ? '+' + s : s;
    btn.dataset.score = s;
    btn.onclick = () => { grid.querySelectorAll('.score-chip').forEach(b => b.classList.remove('selected')); btn.classList.add('selected'); };
    grid.appendChild(btn);
  });
  modal.hidden = false;
}

function closeScoreModal() { document.getElementById('scoreModal').hidden = true; }

function saveScoreModal() {
  const editId = document.getElementById('editingLogId').value;
  const taskId = document.getElementById('modalTaskId').value;
  const date = document.getElementById('modalDate').value;
  const note = document.getElementById('logNote').value.trim();
  const sel = document.querySelector('#scoreButtons .score-chip.selected');
  if (!sel) { toast('امتیاز را انتخاب کنید', 'error'); return; }
  const score = Number(sel.dataset.score);
  if (editId) {
    const log = data.logs.find(l => l.id === editId);
    if (log) { log.score = score; log.note = note; log.time = new Date().toTimeString().slice(0,5); }
    toast('امتیاز ویرایش شد');
  } else {
    const existing = findLog(taskId, date);
    if (existing) { existing.score = score; existing.note = note; }
    else data.logs.push({ id: Date.now().toString(), taskId, score, note, date, time: new Date().toTimeString().slice(0,5) });
    toast('امتیاز ثبت شد');
  }
  saveData(); closeScoreModal(); refreshAll();
  if (window.Telegram?.WebApp?.HapticFeedback) Telegram.WebApp.HapticFeedback.notificationOccurred('success');
}

function deleteScoreModal() {
  const editId = document.getElementById('editingLogId').value;
  if (!editId || !confirm('حذف شود؟')) return;
  data.logs = data.logs.filter(l => l.id !== editId);
  saveData(); closeScoreModal(); refreshAll();
  toast('امتیاز حذف شد');
}

function openEmojiPicker(cb, current) {
  emojiPickCallback = cb;
  const grid = document.getElementById('emojiGrid');
  grid.innerHTML = EMOJI_IDS.map(id =>
    '<button type="button" class="emoji-opt' + (id === current ? ' selected' : '') + '" data-id="' + id + '">' +
    '<img src="' + EMOJI_PATH(id) + '" alt="' + id + '"/></button>'
  ).join('');
  grid.querySelectorAll('.emoji-opt').forEach(btn => {
    btn.onclick = () => {
      if (emojiPickCallback) emojiPickCallback(btn.dataset.id);
      closeEmojiPicker();
      toast('ایموجی انتخاب شد');
    };
  });
  document.getElementById('emojiModal').hidden = false;
}
function closeEmojiPicker() { document.getElementById('emojiModal').hidden = true; emojiPickCallback = null; }

/* ===== Events ===== */
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
  });
});

document.getElementById('addTaskBtn').addEventListener('click', () => {
  const name = document.getElementById('newTaskName').value.trim();
  if (!name) { toast('نام کار را وارد کنید', 'error'); return; }
  data.tasks.push({ id: Date.now().toString(), name });
  saveData(); document.getElementById('newTaskName').value = '';
  refreshAll(); toast('کار اضافه شد');
});
document.getElementById('newTaskName').addEventListener('keypress', e => {
  if (e.key === 'Enter') document.getElementById('addTaskBtn').click();
});

document.getElementById('saveScoresBtn').addEventListener('click', () => {
  const scores = document.getElementById('scoresInput').value.split(',').map(s => Number(s.trim())).filter(n => !isNaN(n));
  if (!scores.length) { toast('حداقل یک امتیاز', 'error'); return; }
  data.scores = scores; saveData(); refreshAll(); toast('امتیازها ذخیره شد');
});
document.getElementById('saveQualBtn').addEventListener('click', () => {
  const rows = document.querySelectorAll('#qualList .qual-row');
  const qual = [];
  rows.forEach((row, i) => {
    const min = Number(row.querySelector('.q-min').value);
    const max = Number(row.querySelector('.q-max').value);
    const label = row.querySelector('.q-label').value.trim() || '—';
    const emoji = data.qual[i] ? data.qual[i].emoji : 'star';
    if (!isNaN(min) && !isNaN(max)) qual.push({ min, max, label, emoji });
  });
  if (!qual.length) { toast('حداقل یک بازه', 'error'); return; }
  data.qual = qual; saveData(); refreshAll(); toast('ارزیابی‌ها ذخیره شد');
});
document.getElementById('addQualBtn').addEventListener('click', () => {
  data.qual.push({ min: 0, max: 100, label: 'جدید', emoji: 'star' });
  renderQualSettings();
});

document.getElementById('exportBtn').addEventListener('click', () => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  a.download = 'score-tracker-' + todayStr() + '.json';
  a.click();
  toast('فایل ذخیره شد');
});
document.getElementById('importBtn').addEventListener('click', () => document.getElementById('importFile').click());
document.getElementById('importFile').addEventListener('change', e => {
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = ev => {
    try {
      const imp = JSON.parse(ev.target.result);
      if (!imp.scores || !imp.tasks || !imp.logs) throw 0;
      if (confirm('جایگزینی داده‌ها؟')) { data = imp; if (!data.qual) data.qual = DEFAULT_QUAL; saveData(); refreshAll(); toast('وارد شد'); }
    } catch { toast('فایل نامعتبر', 'error'); }
  };
  r.readAsText(f);
});
document.getElementById('clearBtn').addEventListener('click', () => {
  if (!confirm('همه داده‌ها پاک شوند؟')) return;
  data = { scores: [-2,0,1,2,3], tasks: [], logs: [], qual: DEFAULT_QUAL, theme: data.theme };
  saveData(); refreshAll(); toast('داده‌ها پاک شد');
});

document.getElementById('modalCancel').addEventListener('click', closeScoreModal);
document.getElementById('modalSave').addEventListener('click', saveScoreModal);
document.getElementById('modalDelete').addEventListener('click', deleteScoreModal);
document.getElementById('scoreModal').addEventListener('click', e => { if (e.target.id === 'scoreModal') closeScoreModal(); });
document.getElementById('emojiCancel').addEventListener('click', closeEmojiPicker);
document.getElementById('emojiModal').addEventListener('click', e => { if (e.target.id === 'emojiModal') closeEmojiPicker(); });

document.getElementById('themeSwitch').addEventListener('change', e => applyTheme(e.target.checked ? 'light' : 'dark'));
document.getElementById('themeToggleBtn').addEventListener('click', () => applyTheme(data.theme === 'dark' ? 'light' : 'dark'));

document.getElementById('weekPrevBtn').addEventListener('click', () => {
  weekOffset -= 1;
  refreshAll();
});
document.getElementById('weekNextBtn').addEventListener('click', () => {
  if (weekOffset >= 0) return;
  weekOffset = Math.min(0, weekOffset + 1);
  refreshAll();
});

if (window.Telegram?.WebApp) { Telegram.WebApp.ready(); Telegram.WebApp.expand(); }

refreshAll();
