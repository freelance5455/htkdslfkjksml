ALIF Browser V5.0 AI — HTML Package

Files:
- index.html: Complete responsive browser-style UI and JavaScript features.

Included:
1. Google search / website address navigation.
2. Gemini AI chat with optional Google Search grounding.
3. AI image generation UI using an image-generation Gemini model (availability depends on the API key/account/model access).
4. Image upload and Gemini image analysis.
5. Voice input through browser SpeechRecognition where supported.
6. Text-to-speech through browser SpeechSynthesis where supported.
7. Bangla/English home-screen language toggle.
8. Responsive mobile and desktop layout.

HOW TO USE:
1. Extract this ZIP.
2. Open index.html in Chrome or another modern browser, or load it as the homepage asset in an Android WebView wrapper.
3. Open Gemini API Settings and paste your own Gemini API key.
4. Use AI Chat, Image Generation, Voice, or Image Analysis.

IMPORTANT LIMITATIONS:
- This ZIP is an HTML/CSS/JavaScript web app package, NOT an APK.
- To make a native Android APK, package index.html in an Android WebView app using an APK builder that supports local HTML assets and JavaScript.
- Some websites block iframe embedding; use Open in new tab when necessary.
- Browser speech recognition depends on browser/device support and microphone permission.
- Image generation requires a currently available image-generation model enabled for your Google AI Studio API key. If the model is unavailable, the UI reports the API error.
- Do not publish a personal API key in a public APK. For a public app, use a secure backend to protect API credentials.
- Gemini API usage may have limits or costs.
