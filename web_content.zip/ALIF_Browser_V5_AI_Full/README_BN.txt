ALIF Browser V5.0 AI — HTML Package

Files:
- index.html: Complete responsive browser-style UI and JavaScript features.

Included:
1. Google search / website address navigation.
2. Gemini AI chat with optional Google Search grounding.
3. AI image generation using Gemini 3.1 Flash Image (Nano Banana 2) by default, with selectable Gemini 3.1 Flash Lite Image and Gemini 3 Pro Image models. Availability depends on API access, region, quota and billing.
4. Image upload and Gemini image analysis.
5. Voice input through browser SpeechRecognition where supported.
6. Text-to-speech through browser SpeechSynthesis where supported.
7. Bangla/English home-screen language toggle.
8. Responsive mobile and desktop layout.

HOW TO USE:
1. Extract this ZIP.
2. Open index.html in Chrome or another modern browser, or load it as the homepage asset in an Android WebView wrapper.
3. Open Gemini API Settings and paste your own Gemini API key.
4. Use AI Chat, Image Generation, Voice, or Image Analysis.

IMPORTANT LIMITATIONS:
- This ZIP is an HTML/CSS/JavaScript web app package, NOT an APK.
- To make a native Android APK, package index.html in an Android WebView app using an APK builder that supports local HTML assets and JavaScript.
- Some websites block iframe embedding; use Open in new tab when necessary.
- Browser speech recognition depends on browser/device support and microphone permission.
- Image generation defaults to gemini-3.1-flash-image (Nano Banana 2). You can also select gemini-3.1-flash-lite-image or gemini-3-pro-image. The selected model must be available to your Gemini API key and region; quota and charges may apply.
- Do not publish a personal API key in a public APK. For a public app, use a secure backend to protect API credentials.
- Gemini API usage may have limits or costs.
\nMODEL UPDATE: The previous legacy/preview image model call has been replaced with the current Gemini 3.1 image model family.\n