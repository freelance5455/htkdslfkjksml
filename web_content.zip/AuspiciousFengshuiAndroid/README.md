# Auspicious Fengshui Android App

This project wraps your supplied HTML page in an Android WebView. The HTML and `taylors-logo.png` are bundled in `app/src/main/assets`, so the local image remains inside the APK and does not depend on an internet connection. The page itself references Google Fonts and Font Awesome over HTTPS, so those optional fonts/icons need internet access.

## Get a real APK using GitHub Actions (no Android Studio needed)

1. Create a GitHub repository and upload the contents of this project ZIP to it (the `.github/workflows/build-apk.yml` file must be included).
2. Open the repository's **Actions** tab and select **Build Android APK**.
3. Click **Run workflow** (or wait for the build to finish after pushing to `main`/`master`).
4. Open the completed workflow run. Under **Artifacts**, download `AuspiciousFengshui-APK.zip` and extract `app-debug.apk`.
5. Transfer `app-debug.apk` to your Android phone and tap it to install. Android may ask you to allow installation from that source.

## Local build

Open this project in Android Studio with Android SDK 35 installed, sync Gradle, then run **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output is `app/build/outputs/apk/debug/app-debug.apk`.

Note: This environment does not include the Android SDK/Gradle installation and has no network access, so it cannot compile the APK directly here. The included GitHub Actions workflow is configured to build the APK on GitHub's hosted runner.
