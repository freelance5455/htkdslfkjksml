# v1.62.31 — Troféus da Série A e Série B

- Substituídas as imagens dos troféus da Série A e da Série B pelas novas artes enviadas pelo usuário.
- Recortadas em arquivos PNG individuais com fundo transparente.
- Mantidos os mesmos cards, posições, dimensões de exibição e referências dos arquivos.
- Nenhuma alteração em clubes, elencos, partidas, tabelas, calendário ou salvamentos.
