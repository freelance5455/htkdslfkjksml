# Scrap अड्डा — Android WebView Wrapper

This project wraps the supplied `Scrap_Adda_INDEX5_VOICE_FIXED_V2.html` as a real Android app.

## What is fixed
- Correct local asset URL using AndroidX WebViewAssetLoader
- Camera permission + WebView camera permission
- Gallery/file picker
- Location permission + geolocation prompt
- Hindi browser/WebView speech synthesis remains available
- External Google Maps links open outside the app
- Scrap अड्डा launcher icon
- Portrait mobile app

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Build > Build APK(s).
4. Install the generated debug APK on the phone.

No web hosting is required for the HTML itself. The app loads `app/src/main/assets/index.html` locally.

The HTML still uses internet resources for Leaflet, OpenStreetMap tiles and Google Fonts, so keep internet permission enabled.
