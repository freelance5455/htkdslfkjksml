import './globals.css';

export const metadata = {
  title: 'Your City Services',
  description: 'India-wide city-based service marketplace',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
