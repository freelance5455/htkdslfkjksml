import Link from 'next/link';

const features = [
  { icon: '🧰', title: 'Skilled professionals', text: 'Find electricians, plumbers, carpenters, mechanics and other local experts.' },
  { icon: '👷', title: 'Labour booking', text: 'Request individual workers or plan labour requirements in advance.' },
  { icon: '🚗', title: 'Mobility services', text: 'Eligible driver and vehicle services can be activated city by city after compliance checks.' },
  { icon: '📅', title: 'Flexible scheduling', text: 'Choose ASAP, next-day or an advance date for supported services.' },
];

export default function HomePage() {
  return (
    <div className="site-shell">
      <header className="container topbar">
        <div className="brand"><span className="brand-mark">YC</span><span>YOUR CITY SERVICES</span></div>
        <Link className="top-link" href="/admin">Admin login ↗</Link>
      </header>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <div className="eyebrow">ONE PLATFORM · MANY LOCAL SOLUTIONS</div>
            <h1>Your City.<br />Your Services.<br />One App.</h1>
            <p>Connect with local service professionals, request everyday help and discover work opportunities — city by city.</p>
            <Link className="cta" href="#services">Explore the idea ↓</Link>
          </div>
          <div className="hero-card">
            <div className="hero-face">👋</div>
            <h3>Namaste! Welcome.</h3>
            <p>We are building a more connected way to find and provide local services.</p>
          </div>
        </div>
      </section>
      <section className="section container" id="services">
        <h2>Services, connected locally.</h2>
        <p className="section-intro">The platform is designed for multiple cities. Actual service availability will depend on verified local supply and operational readiness.</p>
        <div className="grid">
          {features.map((feature) => (
            <article className="feature" key={feature.title}>
              <div className="emoji">{feature.icon}</div>
              <h3>{feature.title}</h3>
              <p>{feature.text}</p>
            </article>
          ))}
        </div>
      </section>
      <footer className="footer">
        <div className="container">© {new Date().getFullYear()} Your City Services · Availability varies by city and category.</div>
      </footer>
    </div>
  );
}
