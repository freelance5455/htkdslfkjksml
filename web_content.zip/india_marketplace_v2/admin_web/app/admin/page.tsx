'use client';

import { FormEvent, useCallback, useEffect, useState } from 'react';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

type City = {
  id: string;
  name: string;
  state_name: string;
  is_live: boolean;
  launch_at: string | null;
};
type Booking = {
  id: string;
  booking_type: string;
  status: string;
  address_text: string;
  created_at: string;
  cities: { name: string } | null;
  service_categories: { name: string } | null;
};
type Application = {
  id: string;
  full_name: string;
  phone: string;
  skills: string;
  status: string;
  created_at: string;
  cities: { name: string } | null;
};
type CityService = {
  id: string;
  city_id: string;
  category_id: string;
  is_live: boolean;
  service_categories: { name: string } | null;
};

let supabaseClient: SupabaseClient | null = null;
function getSupabase() {
  if (supabaseClient) return supabaseClient;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error('Missing Supabase environment variables. Configure admin_web/.env.local.');
  supabaseClient = createClient(url, key);
  return supabaseClient;
}

export default function AdminPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signedIn, setSignedIn] = useState(false);
  const [authorised, setAuthorised] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('Sign in with a founder/admin account.');
  const [isError, setIsError] = useState(false);
  const [cities, setCities] = useState<City[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [cityServices, setCityServices] = useState<CityService[]>([]);
  const [serviceCityId, setServiceCityId] = useState('');

  const loadDashboard = useCallback(async () => {
    const client = getSupabase();
    const [cityResult, bookingResult, appResult, cityServiceResult] = await Promise.all([
      client.from('cities').select('id,name,state_name,is_live,launch_at').order('name'),
      client.from('bookings')
        .select('id,booking_type,status,address_text,created_at,cities(name),service_categories(name)')
        .order('created_at', { ascending: false }).limit(100),
      client.from('provider_applications')
        .select('id,full_name,phone,skills,status,created_at,cities(name)')
        .order('created_at', { ascending: false }).limit(100),
      client.from('city_services')
        .select('id,city_id,category_id,is_live,service_categories(name)')
        .order('created_at', { ascending: true }),
    ]);

    const firstError = cityResult.error || bookingResult.error || appResult.error || undefined;
    const queryError = firstError || cityServiceResult.error;
    if (queryError) throw queryError;
    const loadedCities = (cityResult.data ?? []) as unknown as City[];
    setCities(loadedCities);
    setBookings((bookingResult.data ?? []) as unknown as Booking[]);
    setApplications((appResult.data ?? []) as unknown as Application[]);
    setCityServices((cityServiceResult.data ?? []) as unknown as CityService[]);
    setServiceCityId((current) => current || loadedCities[0]?.id || '');
  }, []);

  const verifyAdmin = useCallback(async () => {
    const client = getSupabase();
    const { data: userResult, error: userError } = await client.auth.getUser();
    if (userError || !userResult.user) return false;

    const { data: roles, error: roleError } = await client
      .from('user_roles')
      .select('role')
      .eq('user_id', userResult.user.id);

    if (roleError) throw roleError;
    return (roles ?? []).some((item: { role: string }) => item.role === 'admin');
  }, []);

  useEffect(() => {
    try {
      getSupabase().auth.getSession().then(async ({ data, error }) => {
        if (error) throw error;
        if (data.session) {
          setSignedIn(true);
          const allowed = await verifyAdmin();
          setAuthorised(allowed);
          if (allowed) await loadDashboard();
          else setMessage('This account does not have the admin role.');
        }
      }).catch((error: unknown) => {
        setMessage(error instanceof Error ? error.message : String(error));
        setIsError(true);
      });
    } catch (error) {
      setMessage(error instanceof Error ? error.message : String(error));
      setIsError(true);
    }
  }, [loadDashboard, verifyAdmin]);

  async function handleSignIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setMessage(''); setIsError(false);
    try {
      const { error } = await getSupabase().auth.signInWithPassword({ email, password });
      if (error) throw error;
      setSignedIn(true);
      const allowed = await verifyAdmin();
      setAuthorised(allowed);
      if (!allowed) {
        await getSupabase().auth.signOut();
        setSignedIn(false);
        throw new Error('This account is not an admin. Assign the admin role using the SQL in README.md.');
      }
      await loadDashboard();
      setMessage('Dashboard loaded.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : String(error));
      setIsError(true);
    } finally {
      setBusy(false);
    }
  }

  async function handleSignOut() {
    await getSupabase().auth.signOut();
    setSignedIn(false); setAuthorised(false);
    setCities([]); setBookings([]); setApplications([]);
    setMessage('Signed out.');
  }

  async function toggleCity(city: City) {
    setBusy(true); setMessage('Updating city launch setting…'); setIsError(false);
    try {
      const { error } = await getSupabase()
        .from('cities')
        .update({ is_live: !city.is_live })
        .eq('id', city.id);
      if (error) throw error;
      await loadDashboard();
      setMessage(`${city.name} is now ${city.is_live ? 'paused' : 'live'}.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : String(error));
      setIsError(true);
    } finally { setBusy(false); }
  }

  async function toggleCityService(service: CityService) {
    setBusy(true); setMessage('Updating city service availability…'); setIsError(false);
    try {
      const { error } = await getSupabase()
        .from('city_services')
        .update({ is_live: !service.is_live })
        .eq('id', service.id);
      if (error) throw error;
      await loadDashboard();
      setMessage(`${service.service_categories?.name ?? 'Service'} is now ${service.is_live ? 'paused' : 'live'} for the selected city.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : String(error));
      setIsError(true);
    } finally { setBusy(false); }
  }

  async function setLaunchDate(city: City) {
    const initial = city.launch_at ? new Date(city.launch_at).toISOString().slice(0, 16) : '';
    const value = window.prompt('Launch date/time (YYYY-MM-DDTHH:mm), or leave blank to clear:', initial);
    if (value === null) return;
    if (value.trim() && Number.isNaN(new Date(value).getTime())) {
      setMessage('Invalid date/time. Use YYYY-MM-DDTHH:mm.');
      setIsError(true);
      return;
    }
    const launchAt = value.trim() ? new Date(value).toISOString() : null;
    setBusy(true);
    try {
      const { error } = await getSupabase().from('cities').update({ launch_at: launchAt }).eq('id', city.id);
      if (error) throw error;
      await loadDashboard();
      setMessage(`Launch date updated for ${city.name}.`);
      setIsError(false);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : String(error));
      setIsError(true);
    } finally { setBusy(false); }
  }

  async function reviewApplication(application: Application, status: 'approved' | 'rejected') {
    setBusy(true);
    try {
      const { error } = await getSupabase().rpc('review_provider_application', {
        p_application_id: application.id,
        p_new_status: status,
      });
      if (error) throw error;
      await loadDashboard();
      setMessage(`Application ${status}. The provider role has been updated; identity and skill documents must still be checked by the operations team.`);
      setIsError(false);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : String(error));
      setIsError(true);
    } finally { setBusy(false); }
  }

  const pendingCount = applications.filter((a) => a.status === 'pending').length;
  const liveCount = cities.filter((c) => c.is_live).length;

  return (
    <main className="admin-page">
      <div className="container">
        <div className="topbar">
          <div className="brand"><span className="brand-mark">YC</span><span>MARKETPLACE ADMIN</span></div>
          <a className="top-link" href="/">← Public website</a>
        </div>

        {!signedIn || !authorised ? (
          <section className="panel" style={{ maxWidth: 480, margin: '55px auto' }}>
            <h1>Founder sign in</h1>
            <p className="muted">This area is restricted to accounts with the admin role.</p>
            <form onSubmit={handleSignIn}>
              <label htmlFor="email">Email</label>
              <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              <label htmlFor="password">Password</label>
              <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              <button className="btn" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
            </form>
            {message && <div className={`message ${isError ? 'error' : ''}`}>{message}</div>}
          </section>
        ) : (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
              <div>
                <h1 style={{ marginBottom: 5 }}>Operations overview</h1>
                <p className="muted">Manage city launch status, booking requests and provider applications.</p>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn secondary" onClick={() => loadDashboard().catch((e: unknown) => setMessage(String(e)))}>Refresh</button>
                <button className="btn" onClick={handleSignOut}>Sign out</button>
              </div>
            </div>

            {message && <div className={`message ${isError ? 'error' : ''}`}>{message}</div>}

            <section className="stats">
              <div className="stat"><span className="muted">Cities live</span><strong>{liveCount}/{cities.length}</strong></div>
              <div className="stat"><span className="muted">Booking requests</span><strong>{bookings.length}</strong></div>
              <div className="stat"><span className="muted">Pending providers</span><strong>{pendingCount}</strong></div>
            </section>

            <section className="panel">
              <h2>City launch controls</h2>
              <p className="muted">Activate a city only after its providers, service coverage, support and legal readiness are confirmed.</p>
              {cities.map((city) => (
                <div className="city-row" key={city.id}>
                  <div>
                    <div className="row-title">{city.name}, {city.state_name}</div>
                    <div className="muted">{city.launch_at ? `Launch: ${new Date(city.launch_at).toLocaleString()}` : 'Launch date not set'}</div>
                    <span className={`pill ${city.is_live ? 'live' : ''}`}>{city.is_live ? 'LIVE' : 'COMING SOON'}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <button className="btn secondary" disabled={busy} onClick={() => setLaunchDate(city)}>Set countdown</button>
                    <button className={`btn ${city.is_live ? 'danger' : ''}`} disabled={busy} onClick={() => toggleCity(city)}>
                      {city.is_live ? 'Pause city' : 'Activate city'}
                    </button>
                  </div>
                </div>
              ))}
            </section>

            <section className="panel">
              <h2>City-wise service controls</h2>
              <p className="muted">A city may be live while individual categories stay disabled until verified providers and operations are ready.</p>
              <label htmlFor="service-city">Choose city</label>
              <select id="service-city" value={serviceCityId} onChange={(event) => setServiceCityId(event.target.value)}>
                {cities.map((city) => <option key={city.id} value={city.id}>{city.name}, {city.state_name}</option>)}
              </select>
              <div style={{ marginTop: 12 }}>
                {cityServices.filter((service) => service.city_id === serviceCityId).map((service) => (
                  <div className="city-row" key={service.id}>
                    <div>
                      <div className="row-title">{service.service_categories?.name ?? 'Service category'}</div>
                      <span className={`pill ${service.is_live ? 'live' : ''}`}>{service.is_live ? 'ACTIVE IN THIS CITY' : 'NOT ACTIVE'}</span>
                    </div>
                    <button className={`btn ${service.is_live ? 'danger' : ''}`} disabled={busy} onClick={() => toggleCityService(service)}>
                      {service.is_live ? 'Deactivate' : 'Activate'}
                    </button>
                  </div>
                ))}
                {cityServices.filter((service) => service.city_id === serviceCityId).length === 0 && (
                  <p className="muted">No city categories found. Re-run the city_services seed section in the SQL editor.</p>
                )}
              </div>
            </section>

            <section className="panel">
              <h2>Provider applications</h2>
              <p className="muted">Review the application. Approval grants provider account mode, but identity, skills and documents still require manual verification.</p>
              {applications.length === 0 ? <p className="muted">No applications yet.</p> : applications.map((application) => (
                <div className="application-row" key={application.id}>
                  <div>
                    <div className="row-title">{application.full_name} · {application.phone}</div>
                    <div className="muted">{application.cities?.name ?? 'City'} · {application.skills}</div>
                    <span className={`pill ${application.status}`}>{application.status.toUpperCase()}</span>
                  </div>
                  {application.status === 'pending' && (
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn" disabled={busy} onClick={() => reviewApplication(application, 'approved')}>Approve</button>
                      <button className="btn danger" disabled={busy} onClick={() => reviewApplication(application, 'rejected')}>Reject</button>
                    </div>
                  )}
                </div>
              ))}
            </section>

            <section className="panel">
              <h2>Recent bookings</h2>
              {bookings.length === 0 ? <p className="muted">No booking requests yet.</p> : (
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>Service</th><th>City</th><th>Schedule</th><th>Status</th><th>Address</th><th>Created</th></tr></thead>
                    <tbody>
                      {bookings.map((booking) => (
                        <tr key={booking.id}>
                          <td>{booking.service_categories?.name ?? 'Service'}</td>
                          <td>{booking.cities?.name ?? 'City'}</td>
                          <td>{booking.booking_type.replace('_', ' ').toUpperCase()}</td>
                          <td><span className={`pill ${booking.status}`}>{booking.status.toUpperCase()}</span></td>
                          <td>{booking.address_text}</td>
                          <td>{new Date(booking.created_at).toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </main>
  );
}
