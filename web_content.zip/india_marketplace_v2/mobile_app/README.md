Flutter app source is in `lib/`. Follow the root README to generate native runner folders and run the app.
