import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.isConfigured) {
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseAnonKey,
    );
  }
  runApp(const MarketplaceApp());
}

SupabaseClient get supabase => Supabase.instance.client;

const navy = Color(0xFF15233B);
const blue = Color(0xFF3269D8);
const pageBg = Color(0xFFF5F7FB);

class MarketplaceApp extends StatelessWidget {
  const MarketplaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: blue,
      brightness: Brightness.light,
      surface: Colors.white,
    );
    return MaterialApp(
      title: 'Your City Services',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: pageBg,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: pageBg,
          foregroundColor: navy,
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE9EDF4)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF7F8FB),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E7EF)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E7EF)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: blue, width: 1.5),
          ),
        ),
      ),
      home: !AppConfig.isConfigured
          ? const SetupRequiredScreen()
          : const AuthGate(),
    );
  }
}

class SetupRequiredScreen extends StatelessWidget {
  const SetupRequiredScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.settings_suggest_rounded, size: 54, color: blue),
                    const SizedBox(height: 16),
                    Text('Connect your backend',
                        style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 10),
                    const Text(
                      'Copy lib/config.example.dart to lib/config.dart and add your Supabase Project URL and anon/publishable key. Then run flutter pub get and flutter run.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, snapshot) {
        final user = supabase.auth.currentUser;
        if (user == null) return const AuthScreen();
        return MainShell(key: ValueKey(user.id));
      },
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _createAccount = false;
  bool _busy = false;
  String? _message;
  bool _isError = false;

  Future<void> _submit() async {
    if (_email.text.trim().isEmpty || _password.text.length < 6) {
      setState(() {
        _message = 'Enter a valid email and a password of at least 6 characters.';
        _isError = true;
      });
      return;
    }
    if (_createAccount && _name.text.trim().isEmpty) {
      setState(() {
        _message = 'Please enter your name.';
        _isError = true;
      });
      return;
    }

    setState(() {
      _busy = true;
      _message = null;
    });

    try {
      if (_createAccount) {
        final response = await supabase.auth.signUp(
          email: _email.text.trim(),
          password: _password.text,
          data: {'full_name': _name.text.trim()},
        );
        if (response.session == null && mounted) {
          setState(() {
            _message = 'Account created. Check your email to confirm it, then sign in.';
            _isError = false;
          });
        }
      } else {
        await supabase.auth.signInWithPassword(
          email: _email.text.trim(),
          password: _password.text,
        );
      }
    } on AuthException catch (e) {
      if (mounted) {
        setState(() {
          _message = e.message;
          _isError = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _message = 'Something went wrong: $e';
          _isError = true;
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: const DecorationImage(
            image: NetworkImage('https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=1400&q=85&fit=crop'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(Color(0xDDF7FAFF), BlendMode.lighten),
          ),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFEAF0FF), pageBg, Color(0xFFF8FAFC)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(
                  children: [
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: navy,
                        borderRadius: BorderRadius.circular(25),
                        boxShadow: [
                          BoxShadow(
                            color: navy.withValues(alpha: 0.16),
                            blurRadius: 22,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.handshake_rounded,
                          size: 38, color: Colors.white),
                    ),
                    const SizedBox(height: 18),
                    Text('YOUR CITY SERVICES',
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                              letterSpacing: 2.2,
                              color: blue,
                              fontWeight: FontWeight.w800,
                            )),
                    const SizedBox(height: 8),
                    Text(
                      _createAccount ? 'Join your city.' : 'Welcome back.',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w800,
                            color: navy,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Local services, skilled people and everyday help — all in one place.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.blueGrey.shade600,
                          ),
                    ),
                    const SizedBox(height: 24),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(22),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(_createAccount ? 'Create account' : 'Sign in',
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    )),
                            const SizedBox(height: 18),
                            if (_createAccount) ...[
                              TextField(
                                controller: _name,
                                textCapitalization: TextCapitalization.words,
                                decoration: const InputDecoration(
                                  labelText: 'Full name',
                                  prefixIcon: Icon(Icons.person_outline),
                                ),
                              ),
                              const SizedBox(height: 12),
                            ],
                            TextField(
                              controller: _email,
                              keyboardType: TextInputType.emailAddress,
                              decoration: const InputDecoration(
                                labelText: 'Email address',
                                prefixIcon: Icon(Icons.mail_outline),
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _password,
                              obscureText: true,
                              decoration: const InputDecoration(
                                labelText: 'Password',
                                prefixIcon: Icon(Icons.lock_outline),
                              ),
                            ),
                            if (_message != null) ...[
                              const SizedBox(height: 12),
                              Text(
                                _message!,
                                style: TextStyle(
                                  color: _isError ? Colors.red.shade700 : Colors.green.shade700,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                            const SizedBox(height: 18),
                            FilledButton(
                              onPressed: _busy ? null : _submit,
                              style: FilledButton.styleFrom(
                                minimumSize: const Size.fromHeight(52),
                                backgroundColor: navy,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              child: _busy
                                  ? const SizedBox(
                                      width: 20, height: 20,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : Text(_createAccount ? 'Create account' : 'Sign in'),
                            ),
                            const SizedBox(height: 8),
                            TextButton(
                              onPressed: _busy
                                  ? null
                                  : () => setState(() {
                                        _createAccount = !_createAccount;
                                        _message = null;
                                      }),
                              child: Text(_createAccount
                                  ? 'Already have an account? Sign in'
                                  : 'New here? Create an account'),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Text('A city-first marketplace built for India.',
                        style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _tab = 0;
  bool _providerMode = false;
  bool _loadingDirectory = true;
  String? _loadError;
  List<Map<String, dynamic>> _cities = [];
  List<Map<String, dynamic>> _categories = [];
  String? _cityId;

  @override
  void initState() {
    super.initState();
    _loadDirectory();
  }

  Future<void> _loadDirectory() async {
    setState(() {
      _loadingDirectory = true;
      _loadError = null;
    });
    try {
      final cityRows = await supabase.from('cities').select().order('name');
      if (!mounted) return;
      setState(() {
        _cities = List<Map<String, dynamic>>.from(cityRows);
        _loadingDirectory = false;
      });
      if (_cityId != null) {
        await _loadCityCategories(_cityId!);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadError = e.toString();
        _loadingDirectory = false;
      });
    }
  }

  Future<void> _loadCityCategories(String cityId) async {
    try {
      final rows = await supabase
          .from('city_services')
          .select('is_live, service_categories!inner(id,name,icon_name,description,sort_order,is_active)')
          .eq('city_id', cityId);
      final parsed = <Map<String, dynamic>>[];
      for (final row in rows) {
        final rawCategory = row['service_categories'];
        if (rawCategory is Map && rawCategory['is_active'] == true) {
          parsed.add({
            ...Map<String, dynamic>.from(rawCategory),
            'city_service_live': row['is_live'] == true,
          });
        }
      }
      if (mounted) setState(() => _categories = parsed);
    } catch (e) {
      if (mounted) setState(() => _loadError = e.toString());
    }
  }

  Map<String, dynamic>? get _selectedCity {
    final matches = _cities.where((city) => city['id'] == _cityId).toList();
    return matches.isEmpty ? null : matches.first;
  }

  Future<void> _selectCity() async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          children: [
            Text('Choose your city',
                style: Theme.of(sheetContext).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    )),
            const SizedBox(height: 12),
            ..._cities.map((city) {
              final live = city['is_live'] == true;
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: live ? const Color(0xFFE4F6EC) : const Color(0xFFEAF0FF),
                    child: Icon(Icons.location_city, color: live ? Colors.green : blue),
                  ),
                  title: Text('${city['name']}, ${city['state_name']}'),
                  subtitle: Text(live ? 'Services are live' : 'Coming soon'),
                  trailing: city['id'] == _cityId
                      ? const Icon(Icons.check_circle, color: blue)
                      : const Icon(Icons.chevron_right),
                  onTap: () => Navigator.pop(sheetContext, city),
                ),
              );
            }),
          ],
        ),
      ),
    );
    if (result != null && mounted) {
      setState(() {
        _cityId = result['id'] as String;
        _categories = [];
        _loadError = null;
      });
      await _loadCityCategories(result['id'] as String);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(
        loading: _loadingDirectory,
        error: _loadError,
        cities: _cities,
        selectedCity: _selectedCity,
        categories: _categories,
        providerMode: _providerMode,
        onSelectCity: _selectCity,
        onRefresh: _loadDirectory,
        onToggleMode: (value) => setState(() => _providerMode = value),
      ),
      BookingsTab(),
      AccountTab(
        city: _selectedCity,
        onOpenCityPicker: _selectCity,
        providerMode: _providerMode,
        onToggleMode: (value) => setState(() => _providerMode = value),
      ),
    ];

    return Scaffold(
      body: SafeArea(
        child: IndexedStack(index: _tab, children: pages),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (index) => setState(() => _tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Bookings'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  final bool loading;
  final String? error;
  final List<Map<String, dynamic>> cities;
  final Map<String, dynamic>? selectedCity;
  final List<Map<String, dynamic>> categories;
  final bool providerMode;
  final VoidCallback onSelectCity;
  final Future<void> Function() onRefresh;
  final ValueChanged<bool> onToggleMode;

  const HomeTab({
    super.key,
    required this.loading,
    required this.error,
    required this.cities,
    required this.selectedCity,
    required this.categories,
    required this.providerMode,
    required this.onSelectCity,
    required this.onRefresh,
    required this.onToggleMode,
  });

  @override
  Widget build(BuildContext context) {
    final live = selectedCity?['is_live'] == true;
    final cityName = selectedCity?['name']?.toString() ?? 'your city';

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 28),
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: navy,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.handshake_rounded, color: Colors.white),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('YOUR CITY SERVICES',
                        style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, color: navy)),
                    Text('One app. Many local solutions.',
                        style: TextStyle(fontSize: 11, color: Colors.blueGrey.shade600)),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Refresh',
                onPressed: onRefresh,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _WelcomeHero(cityName: selectedCity?['name']?.toString()),
          const SizedBox(height: 16),
          InkWell(
            borderRadius: BorderRadius.circular(17),
            onTap: onSelectCity,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: const Color(0xFFE5EAF2)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.location_on_rounded, color: blue),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(selectedCity == null ? 'SELECT YOUR CITY' : 'YOUR CITY',
                            style: const TextStyle(fontSize: 10, letterSpacing: 1.2, color: Colors.blueGrey, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 3),
                        Text(selectedCity == null ? 'Choose location' : '$cityName, ${selectedCity!['state_name']}',
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      ],
                    ),
                  ),
                  const Icon(Icons.keyboard_arrow_down_rounded),
                ],
              ),
            ),
          ),
          if (selectedCity != null && !live) ...[
            const SizedBox(height: 14),
            ComingSoonPanel(
              cityName: cityName,
              launchAt: selectedCity?['launch_at']?.toString(),
            ),
          ],
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: const Color(0xFFE9EDF5),
              borderRadius: BorderRadius.circular(15),
            ),
            child: SegmentedButton<bool>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: false, label: Text('Find a service'), icon: Icon(Icons.search_rounded)),
                ButtonSegment(value: true, label: Text('Earn with us'), icon: Icon(Icons.work_outline_rounded)),
              ],
              selected: {providerMode},
              onSelectionChanged: (value) => onToggleMode(value.first),
              style: ButtonStyle(
                textStyle: WidgetStateProperty.all(const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                visualDensity: VisualDensity.compact,
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (loading)
            const Padding(
              padding: EdgeInsets.all(32),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (error != null)
            _ErrorCard(message: error!)
          else if (providerMode)
            _ProviderWelcomeCard(cityName: cityName)
          else ...[
            Row(
              children: [
                Expanded(
                  child: Text('Explore services',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                            color: navy,
                          )),
                ),
                Text('${categories.length} categories',
                    style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 12),
            if (categories.isEmpty)
              _EmptyCard(
                icon: Icons.storefront_outlined,
                title: selectedCity == null ? 'Choose your city first' : 'Services are being prepared',
                subtitle: selectedCity == null
                    ? 'Select a city to see its local service catalogue.'
                    : 'This city has not activated its service categories yet.',
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: categories.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 11,
                  mainAxisSpacing: 11,
                  childAspectRatio: 1.42,
                ),
                itemBuilder: (context, index) {
                  final category = categories[index];
                  final cityServiceLive = category['city_service_live'] == true;
                  return _CategoryCard(
                    category: category,
                    enabled: live && cityServiceLive,
                    onTap: () {
                      if (selectedCity == null) {
                        onSelectCity();
                      } else if (!live) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('$cityName bookings will open on launch day.')),
                        );
                      } else if (!cityServiceLive) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('${category['name']} is not active in $cityName yet.')),
                        );
                      } else {
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          showDragHandle: true,
                          builder: (_) => BookingComposer(
                            city: selectedCity!,
                            category: category,
                          ),
                        );
                      }
                    },
                  );
                },
              ),
          ],
          const SizedBox(height: 22),
          const _TrustStrip(),
        ],
      ),
    );
  }
}

class _WelcomeHero extends StatelessWidget {
  final String? cityName;
  const _WelcomeHero({this.cityName});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        image: const DecorationImage(
          image: NetworkImage('https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1200&q=85&fit=crop'),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(Color(0xAA10213A), BlendMode.darken),
        ),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF172946), Color(0xFF2C5EB7), Color(0xFF447DDF)],
        ),
        boxShadow: [
          BoxShadow(color: blue.withValues(alpha: 0.16), blurRadius: 20, offset: const Offset(0, 10)),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('NAMASTE 👋',
                    style: TextStyle(color: Color(0xFFBFD4FF), fontWeight: FontWeight.w800, letterSpacing: 1.7)),
                const SizedBox(height: 9),
                Text(
                  cityName == null ? 'Your city, connected.' : 'Hello, $cityName!',
                  style: const TextStyle(color: Colors.white, fontSize: 23, height: 1.12, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Find trusted local help or discover work opportunities near you.',
                  style: TextStyle(color: Colors.white70, height: 1.4, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            height: 82,
            width: 82,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.13),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white24),
            ),
            child: ClipOval(
              child: Image.network(
                'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=240&q=80&fit=crop',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Center(
                  child: Icon(Icons.handshake_rounded, color: Colors.white, size: 38),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final Map<String, dynamic> category;
  final bool enabled;
  final VoidCallback onTap;

  const _CategoryCard({
    required this.category,
    required this.enabled,
    required this.onTap,
  });

  String _photoFor(String name) {
    final value = name.toLowerCase();
    if (value.contains('electric')) return 'https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=700&q=80&fit=crop';
    if (value.contains('plumb')) return 'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=700&q=80&fit=crop';
    if (value.contains('carpent')) return 'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=700&q=80&fit=crop';
    if (value.contains('mechanic')) return 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=700&q=80&fit=crop';
    if (value.contains('ac')) return 'https://images.unsplash.com/photo-1631545806609-1c5c5c9cfc6b?w=700&q=80&fit=crop';
    if (value.contains('driver') || value.contains('vehicle')) return 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=700&q=80&fit=crop';
    return 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=700&q=80&fit=crop';
  }

  IconData _iconFor(String name) {
    switch (name) {
      case 'groups': return Icons.groups_rounded;
      case 'bolt': return Icons.bolt_rounded;
      case 'plumbing': return Icons.plumbing_rounded;
      case 'carpenter': return Icons.carpenter_rounded;
      case 'car_repair': return Icons.car_repair_rounded;
      case 'ac_unit': return Icons.ac_unit_rounded;
      case 'directions_car': return Icons.directions_car_rounded;
      case 'airport_shuttle': return Icons.airport_shuttle_rounded;
      default: return Icons.handyman_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tint = enabled ? blue : Colors.blueGrey;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Ink(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE7EBF2)),
          image: DecorationImage(
            image: NetworkImage(_photoFor(category['name']?.toString() ?? '')),
            fit: BoxFit.cover,
            colorFilter: const ColorFilter.mode(Color(0xAA10213A), BlendMode.darken),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: tint.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(_iconFor(category['icon_name']?.toString() ?? ''), color: Colors.white),
                ),
                const Icon(Icons.arrow_outward_rounded, size: 17, color: Colors.white70),
              ],
            ),
            Text(category['name']?.toString() ?? 'Service',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: Colors.white)),
            Text(
              enabled ? 'Book a service' : 'Coming soon',
              style: TextStyle(color: enabled ? Colors.white70 : const Color(0xFFFFD27A), fontSize: 11, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}

class ComingSoonPanel extends StatefulWidget {
  final String cityName;
  final String? launchAt;
  const ComingSoonPanel({super.key, required this.cityName, this.launchAt});

  @override
  State<ComingSoonPanel> createState() => _ComingSoonPanelState();
}

class _ComingSoonPanelState extends State<ComingSoonPanel> {
  Timer? _timer;
  Duration _remaining = Duration.zero;
  DateTime? _target;

  @override
  void initState() {
    super.initState();
    _target = DateTime.tryParse(widget.launchAt ?? '')?.toLocal();
    _update();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _update());
  }

  void _update() {
    if (_target == null) return;
    final difference = _target!.difference(DateTime.now());
    if (mounted) {
      setState(() => _remaining = difference.isNegative ? Duration.zero : difference);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasDate = _target != null;
    final days = _remaining.inDays;
    final hours = _remaining.inHours % 24;
    final minutes = _remaining.inMinutes % 60;
    final seconds = _remaining.inSeconds % 60;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(21),
        image: const DecorationImage(
          image: NetworkImage('https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1200&q=85&fit=crop'),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(Color(0xB8001020), BlendMode.darken),
        ),
        color: const Color(0xFF111F36),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFD27A), size: 18),
              const SizedBox(width: 7),
              const Text('COMING SOON',
                  style: TextStyle(color: Color(0xFFFFD27A), letterSpacing: 2, fontWeight: FontWeight.w900, fontSize: 11)),
              const Spacer(),
              const Icon(Icons.notifications_active_outlined, color: Colors.white70, size: 18),
            ],
          ),
          const SizedBox(height: 13),
          Text('${widget.cityName} is getting ready for something big.',
              style: const TextStyle(color: Colors.white, fontSize: 19, height: 1.2, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Your City. Your Services. One App.',
              style: TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 16),
          if (hasDate)
            Row(
              children: [
                _TimeTile(value: days.toString().padLeft(2, '0'), label: 'DAYS'),
                _TimeTile(value: hours.toString().padLeft(2, '0'), label: 'HRS'),
                _TimeTile(value: minutes.toString().padLeft(2, '0'), label: 'MIN'),
                _TimeTile(value: seconds.toString().padLeft(2, '0'), label: 'SEC'),
              ],
            )
          else
            const Text('Launch date will be announced soon.',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          const SizedBox(height: 15),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.09),
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Row(
              children: [
                Icon(Icons.verified_rounded, color: Color(0xFF8DE1B1), size: 19),
                SizedBox(width: 9),
                Expanded(
                  child: Text(
                    "You're on the early-access list! Get ready to book services on launch day.",
                    style: TextStyle(color: Colors.white, fontSize: 11, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TimeTile extends StatelessWidget {
  final String value;
  final String label;
  const _TimeTile({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: 7),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(value, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(label, style: const TextStyle(color: Colors.white60, fontSize: 9, letterSpacing: 1)),
          ],
        ),
      ),
    );
  }
}

class _ProviderWelcomeCard extends StatelessWidget {
  final String cityName;
  const _ProviderWelcomeCard({required this.cityName});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE7EBF2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.workspace_premium_rounded, color: blue, size: 34),
          const SizedBox(height: 12),
          Text('Earn with your skills in $cityName',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 7),
          const Text('Apply as a service provider, list your skills and get considered for customer requests after verification.'),
          const SizedBox(height: 13),
          const Text('Open Account → Apply as provider',
              style: TextStyle(fontWeight: FontWeight.bold, color: blue)),
        ],
      ),
    );
  }
}

class _TrustStrip extends StatelessWidget {
  const _TrustStrip();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF0FC),
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Row(
        children: [
          Icon(Icons.shield_outlined, color: blue),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Book only in active cities. Provider verification and payment features are being built in phases.',
              style: TextStyle(color: navy, fontSize: 11, height: 1.35),
            ),
          ),
        ],
      ),
    );
  }
}

class BookingComposer extends StatefulWidget {
  final Map<String, dynamic> city;
  final Map<String, dynamic> category;
  const BookingComposer({super.key, required this.city, required this.category});

  @override
  State<BookingComposer> createState() => _BookingComposerState();
}

class _BookingComposerState extends State<BookingComposer> {
  final _address = TextEditingController();
  final _details = TextEditingController();
  String _type = 'asap';
  DateTime _date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _time = const TimeOfDay(hour: 10, minute: 0);
  bool _busy = false;

  @override
  void dispose() {
    _address.dispose();
    _details.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date.isBefore(DateTime.now()) ? DateTime.now().add(const Duration(days: 1)) : _date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _time);
    if (picked != null) setState(() => _time = picked);
  }

  Future<void> _submit() async {
    if (_address.text.trim().length < 5) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a complete service address.')),
      );
      return;
    }

    DateTime? scheduled;
    if (_type != 'asap') {
      scheduled = DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute);
      if (!scheduled.isAfter(DateTime.now())) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Choose a future date and time.')),
        );
        return;
      }
      if (_type == 'next_day' && !DateUtils.isSameDay(_date, DateTime.now().add(const Duration(days: 1)))) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Next-day booking must be for tomorrow.')),
        );
        return;
      }
    }

    setState(() => _busy = true);
    try {
      await supabase.from('bookings').insert({
        'customer_id': supabase.auth.currentUser!.id,
        'city_id': widget.city['id'],
        'category_id': widget.category['id'],
        'booking_type': _type,
        'scheduled_at': scheduled?.toUtc().toIso8601String(),
        'address_text': _address.text.trim(),
        'work_details': _details.text.trim().isEmpty ? null : _details.text.trim(),
      });

      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your booking request has been submitted.')),
      );
    } on PostgrestException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Booking failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, bottom + 22),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Book ${widget.category['name']}',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text('${widget.city['name']} · Request a service',
                style: const TextStyle(color: Colors.blueGrey)),
            const SizedBox(height: 18),
            const Text('When do you need it?', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 9),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('ASAP'),
                  selected: _type == 'asap',
                  onSelected: (_) => setState(() => _type = 'asap'),
                ),
                ChoiceChip(
                  label: const Text('Tomorrow'),
                  selected: _type == 'next_day',
                  onSelected: (_) {
                    setState(() {
                      _type = 'next_day';
                      _date = DateTime.now().add(const Duration(days: 1));
                    });
                  },
                ),
                ChoiceChip(
                  label: const Text('Choose date'),
                  selected: _type == 'advance',
                  onSelected: (_) => setState(() => _type = 'advance'),
                ),
              ],
            ),
            if (_type != 'asap') ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _type == 'next_day' ? null : _pickDate,
                      icon: const Icon(Icons.calendar_month_outlined),
                      label: Text(DateFormat('dd MMM yyyy').format(_date)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.schedule_rounded),
                      label: Text(_time.format(context)),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 15),
            TextField(
              controller: _address,
              minLines: 2,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Full service address',
                hintText: 'House / street / landmark / locality',
                prefixIcon: Icon(Icons.location_on_outlined),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 11),
            TextField(
              controller: _details,
              minLines: 2,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Work details (optional)',
                hintText: 'Describe what you need help with',
                prefixIcon: Icon(Icons.notes_rounded),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 17),
            FilledButton(
              onPressed: _busy ? null : _submit,
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                backgroundColor: navy,
              ),
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Submit booking request'),
            ),
            const SizedBox(height: 8),
            const Text(
              'This starter submits a request only. Provider matching, confirmed price and payments are not connected yet.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.blueGrey),
            ),
          ],
        ),
      ),
    );
  }
}

class BookingsTab extends StatefulWidget {
  const BookingsTab({super.key});

  @override
  State<BookingsTab> createState() => _BookingsTabState();
}

class _BookingsTabState extends State<BookingsTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await supabase
        .from('bookings')
        .select('id, booking_type, scheduled_at, address_text, status, created_at, cities(name), service_categories(name)')
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        children: [
          Text('My bookings',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: navy)),
          const SizedBox(height: 6),
          const Text('View your recent service requests.', style: TextStyle(color: Colors.blueGrey)),
          const SizedBox(height: 18),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(34),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              if (snapshot.hasError) return _ErrorCard(message: snapshot.error.toString());
              final rows = snapshot.data ?? [];
              if (rows.isEmpty) {
                return const _EmptyCard(
                  icon: Icons.event_note_rounded,
                  title: 'No bookings yet',
                  subtitle: 'Your service requests will appear here.',
                );
              }
              return Column(
                children: rows.map((booking) {
                  final cityData = booking['cities'];
                  final catData = booking['service_categories'];
                  final city = cityData is Map ? cityData['name'] : 'City';
                  final category = catData is Map ? catData['name'] : 'Service';
                  final scheduled = booking['scheduled_at']?.toString();
                  final type = booking['booking_type'] == 'asap'
                      ? 'ASAP'
                      : booking['booking_type'] == 'next_day'
                          ? 'Tomorrow'
                          : 'Advance';
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 11),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(15),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(category.toString(),
                                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                                ),
                                _StatusPill(status: booking['status']?.toString() ?? 'requested'),
                              ],
                            ),
                            const SizedBox(height: 7),
                            Text('$city · $type', style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
                            if (scheduled != null) ...[
                              const SizedBox(height: 4),
                              Text(DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.parse(scheduled).toLocal()),
                                  style: const TextStyle(fontSize: 12)),
                            ],
                            const SizedBox(height: 8),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.location_on_outlined, size: 16, color: blue),
                                const SizedBox(width: 5),
                                Expanded(child: Text(booking['address_text']?.toString() ?? '',
                                    style: const TextStyle(fontSize: 12, color: Colors.blueGrey))),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}

class AccountTab extends StatelessWidget {
  final Map<String, dynamic>? city;
  final VoidCallback onOpenCityPicker;
  final bool providerMode;
  final ValueChanged<bool> onToggleMode;

  const AccountTab({
    super.key,
    required this.city,
    required this.onOpenCityPicker,
    required this.providerMode,
    required this.onToggleMode,
  });

  Future<void> _applyAsProvider(BuildContext context) async {
    if (city == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Choose your city on the Home tab first.')),
      );
      return;
    }
    // Provider pre-registration is intentionally allowed before launch.
    // The admin team can review applications before activating the city.
    final form = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => const ProviderApplicationDialog(),
    );
    if (form == null) return;

    try {
      await supabase.from('provider_applications').insert({
        'user_id': supabase.auth.currentUser!.id,
        'city_id': city!['id'],
        'full_name': form['name'],
        'phone': form['phone'],
        'skills': form['skills'],
        'experience_years': int.tryParse(form['experience'] ?? '') ?? 0,
      });
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Provider application submitted for review.')),
        );
      }
    } on PostgrestException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not submit application: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = supabase.auth.currentUser;
    final email = user?.email ?? 'Signed-in user';
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
      children: [
        Text('Your account',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: navy)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(17),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 27,
                  backgroundColor: Color(0xFFEAF0FC),
                  child: Icon(Icons.person_rounded, color: blue, size: 29),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(user?.userMetadata?['full_name']?.toString().isNotEmpty == true
                          ? user!.userMetadata!['full_name'].toString()
                          : 'Marketplace member',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      Text(email, style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.location_city_rounded, color: blue),
                title: const Text('Selected city'),
                subtitle: Text(city == null ? 'Not selected' : '${city!['name']}, ${city!['state_name']}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: onOpenCityPicker,
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.work_outline_rounded, color: blue),
                title: const Text('Apply as a service provider'),
                subtitle: const Text('Submit your skills for admin review'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _applyAsProvider(context),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Account mode', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: false, label: Text('Customer')),
                    ButtonSegment(value: true, label: Text('Provider')),
                  ],
                  selected: {providerMode},
                  onSelectionChanged: (v) => onToggleMode(v.first),
                ),
                const SizedBox(height: 8),
                const Text('Provider applications are reviewed before provider privileges are activated.',
                    style: TextStyle(color: Colors.blueGrey, fontSize: 11)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        OutlinedButton.icon(
          onPressed: () async => supabase.auth.signOut(),
          icon: const Icon(Icons.logout_rounded),
          label: const Text('Sign out'),
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.red.shade700,
            minimumSize: const Size.fromHeight(50),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Version 0.2.0 · Marketplace starter',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey, fontSize: 11)),
      ],
    );
  }
}

class ProviderApplicationDialog extends StatefulWidget {
  const ProviderApplicationDialog({super.key});

  @override
  State<ProviderApplicationDialog> createState() => _ProviderApplicationDialogState();
}

class _ProviderApplicationDialogState extends State<ProviderApplicationDialog> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _skills = TextEditingController();
  final _experience = TextEditingController(text: '0');

  @override
  void dispose() {
    _name.dispose(); _phone.dispose(); _skills.dispose(); _experience.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Provider application'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Full name')),
            const SizedBox(height: 10),
            TextField(controller: _phone, keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone number')),
            const SizedBox(height: 10),
            TextField(controller: _skills, maxLines: 2,
                decoration: const InputDecoration(labelText: 'Skills / services')),
            const SizedBox(height: 10),
            TextField(controller: _experience, keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Experience in years')),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            if (_name.text.trim().isEmpty || _phone.text.trim().length < 10 || _skills.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Enter your name, a valid phone number and skills.')),
              );
              return;
            }
            Navigator.pop(context, {
              'name': _name.text.trim(),
              'phone': _phone.text.trim(),
              'skills': _skills.text.trim(),
              'experience': _experience.text.trim(),
            });
          },
          child: const Text('Submit application'),
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String status;
  const _StatusPill({required this.status});

  @override
  Widget build(BuildContext context) {
    final isDone = status == 'completed';
    final isCancelled = status == 'cancelled' || status == 'rejected';
    final color = isDone ? Colors.green : isCancelled ? Colors.red : const Color(0xFFB26A00);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(20)),
      child: Text(status.replaceAll('_', ' ').toUpperCase(),
          style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 9)),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _EmptyCard({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: Column(
        children: [
          Icon(icon, size: 37, color: blue),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text(subtitle, textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
        ],
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  final String message;
  const _ErrorCard({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFEEEE),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text('Could not load data.\n$message',
          style: TextStyle(color: Colors.red.shade800, fontSize: 12)),
    );
  }
}
