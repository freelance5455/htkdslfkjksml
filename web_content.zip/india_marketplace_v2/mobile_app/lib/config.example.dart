class AppConfig {
  static const supabaseUrl = 'YOUR_SUPABASE_PROJECT_URL';
  static const supabaseAnonKey = 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY';

  static bool get isConfigured =>
      supabaseUrl.startsWith('https://') &&
      !supabaseUrl.contains('YOUR_') &&
      supabaseAnonKey.isNotEmpty &&
      !supabaseAnonKey.contains('YOUR_');
}
