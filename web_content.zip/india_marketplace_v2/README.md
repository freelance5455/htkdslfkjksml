# India Marketplace — Multi-city Marketplace Starter (v2)

This repository is a **strong starter foundation** for the India-wide marketplace discussed by the founders.

## Included in this version

### Flutter mobile app
- Polished Material 3 interface with a welcoming hero section.
- Email/password sign-up and sign-in using Supabase Auth.
- Customer home screen with city selection.
- City-specific Coming Soon card and live countdown using `cities.launch_at`.
- City-specific service catalogue: each city can activate only the categories it can currently fulfil; this is controlled from the admin dashboard.
- Booking request creation with ASAP, next-day and advance date/time options.
- My Bookings screen.
- Customer/provider mode switch and provider application form (pre-registration is allowed before city launch).
- Account screen and sign-out.

### Next.js web app
- Public landing page.
- Admin sign-in.
- Admin-role check using the database role table and RLS.
- City launch activation/deactivation.
- City-specific category activation/deactivation.
- Booking overview.
- Provider application review.

### Supabase
- Database schema and indexes.
- Sign-up profile/customer-role trigger.
- Row Level Security policies.
- Admin-only city, booking and provider-application controls.
- Seed cities and service categories.

> This is a starter, not a finished production marketplace. It does not yet include payment processing, provider discovery/matching, live tracking, provider acceptance workflow, refunds, payouts, full KYC, disputes, or vehicle-rental compliance. Do not advertise those as live features until built and tested.

---

# A. Software required on all three laptops

Install these on each development laptop:

1. Git: https://git-scm.com/
2. Visual Studio Code: https://code.visualstudio.com/
3. Flutter SDK: https://docs.flutter.dev/get-started/install
4. Android Studio (Android SDK + emulator): https://developer.android.com/studio
5. Node.js LTS: https://nodejs.org/
6. Supabase account: https://supabase.com/

Check in terminal:

```bash
git --version
flutter doctor
node --version
npm --version
```

For Android development, accept Android SDK licences if Flutter asks:

```bash
flutter doctor --android-licenses
```

iOS builds require macOS and Xcode. A Windows/Linux laptop can build and test Android, but cannot produce the final iOS App Store build by itself.

---

# B. Create your Supabase backend

1. Open https://supabase.com/ and create a new project.
2. Choose a strong database password and keep it in a password manager.
3. Open **SQL Editor → New query**.
4. Copy all of `supabase/schema.sql` into the editor and run it.
5. Open **Project Settings → API** (or API Keys).
6. Copy the Project URL and the publishable/anon client key.

Never put the Supabase `service_role` or secret key in Flutter, the browser, `.env.local`, or GitHub.

## Create an admin account

1. Create a user through the Flutter app using the email you intend to use as an admin.
2. In Supabase SQL Editor, run this query after replacing the email:

```sql
insert into public.user_roles (user_id, role)
select id, 'admin'
from auth.users
where lower(email) = lower('founder@example.com')
on conflict (user_id, role) do nothing;
```

Only grant the admin role to trusted founder accounts. The client app does not let users grant themselves admin access.

---

# C. Run the Flutter mobile app

Open a terminal in the repository root:

```bash
cd mobile_app
flutter create . --platforms=android,ios
```

The command creates the native Android/iOS runner folders. It should not overwrite the Dart files in `lib/`.

Copy the example config:

**Windows PowerShell**
```powershell
Copy-Item lib/config.example.dart lib/config.dart
```

**macOS / Linux**
```bash
cp lib/config.example.dart lib/config.dart
```

Open `lib/config.dart` and replace:

```dart
static const supabaseUrl = 'YOUR_SUPABASE_PROJECT_URL';
static const supabaseAnonKey = 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY';
```

Then run:

```bash
flutter pub get
flutter analyze
flutter run
```

Run on an Android emulator or connect an Android phone with USB debugging enabled.

To build an Android APK:

```bash
flutter build apk --release
```

The APK is created under:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Do not upload a debug build to the Play Store.

---

# D. Run the Next.js public website + admin dashboard

Open a second terminal from the repository root:

```bash
cd admin_web
```

Copy environment template:

**Windows PowerShell**
```powershell
Copy-Item .env.local.example .env.local
```

**macOS / Linux**
```bash
cp .env.local.example .env.local
```

Put the same Supabase Project URL and anon/publishable key in `.env.local`.

Install and start:

```bash
npm install
npm run dev
```

Open:
- Public website: http://localhost:3000
- Admin dashboard: http://localhost:3000/admin

The admin page checks the signed-in account's `admin` role. The database policies also limit admin data access. Do not remove those checks.

---

# E. First end-to-end test

1. Start the Flutter app.
2. Create a test account with email/password.
3. Confirm the email if Supabase email confirmation is enabled.
4. Select Mirzapur.
5. Mirzapur will show Coming Soon because the seed data keeps all cities offline initially.
6. Create a test admin user and assign the `admin` role using the SQL in section B.
7. Sign in to `/admin`.
8. Set a future `launch_at` date/time for Mirzapur and activate it from the admin dashboard.
9. In the admin dashboard's City-wise service controls, activate at least one category for Mirzapur.
10. Return to the Flutter app and refresh/restart. Only categories activated for that city will appear as bookable.
11. Create a test booking and verify it appears in My Bookings and the admin dashboard.

For a fast local test, you can set the Mirzapur city live from `/admin`. Do not activate a real city until providers, support and compliance are ready.

---

# F. Three-person GitHub workflow

Create one **private** repository, for example `india-marketplace`.

From the extracted project folder:

```bash
git init
git add .
git commit -m "Initial marketplace starter v2"
git branch -M main
git remote add origin https://github.com/YOUR-ORG/india-marketplace.git
git push -u origin main
```

Suggested ownership:
- Developer 1: Flutter UI and app flows (`mobile_app/`).
- Developer 2: Supabase schema, database policies and booking backend (`supabase/`).
- Developer 3: Website and admin panel (`admin_web/`).

Each person should create a branch instead of editing `main` directly:

```bash
git checkout -b feature/your-feature-name
git add .
git commit -m "Add your feature"
git push -u origin feature/your-feature-name
```

Then open a Pull Request on GitHub and get another teammate to review it before merging.

### Never commit these files

- `mobile_app/lib/config.dart`
- `admin_web/.env.local`
- service-role keys, secret API keys or passwords
- identity documents or real customer data

The provided `.gitignore` excludes local configuration files.

---

# G. What still needs to be built before public launch

This starter does **not** yet implement:
1. Phone OTP and production email/SMS delivery.
2. Provider document upload, consent, verification and approval workflow.
3. Provider search, matching, acceptance/rejection and assignment.
4. Availability calendar and double-booking prevention.
5. Payment gateway, signed webhooks, ledger, refunds and payouts.
6. Cancellation rules, complaints, disputes and support operations.
7. Live location sharing and emergency workflows.
8. Business accounts and bulk labour team booking.
9. Driver/vehicle rental permits, insurance, inspections and legal checks.
10. Data protection notices, retention/deletion, backups, monitoring, load testing and a professional security review.

Before launching in India, take legal advice on applicable privacy/data protection, consumer, labour and transport/aggregator rules for the exact operating model. Keep regulated vehicle-rental/driver features disabled until the legal and insurance requirements are satisfied.

## Free-tier warning

Free plans are useful for development and early testing, but they have limits and may pause or charge as usage grows. Recheck current Supabase, hosting, maps, OTP, email and push-notification terms before production. Google Play and Apple App Store developer publishing accounts also have their own fees.

## Recommended release sequence

Build and test the complete feature set → onboard/verify providers → pilot privately in Mirzapur → fix operational issues → prepare the 15-day public campaign → launch only the city/category combinations that are genuinely ready.

### Standalone HTML landing page
A standalone landing page is included at `admin_web/public/index.html`. When the Next.js site is running, open `http://localhost:3000/index.html` to view it. The main website homepage at `http://localhost:3000/` remains `admin_web/app/page.tsx`; Next.js serves files from `public/` as static assets. The early-access email link in the HTML is a demo and must be replaced with your real contact or registration URL.


## Photo backgrounds
The mobile welcome screen, city launch panel, service cards, and web landing page now use photographic backgrounds from Unsplash image URLs. An internet connection is required to load these photos; the app still has solid-color/gradient fallbacks in several areas. These are decorative photos and do not affect booking or Supabase data.
