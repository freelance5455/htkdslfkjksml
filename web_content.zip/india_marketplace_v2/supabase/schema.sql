-- India Marketplace v2
-- Run once in Supabase SQL Editor.
-- Review policies with a security professional before production.

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- Core identity
-- ------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('customer', 'provider', 'admin')),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

-- Security-definer helper avoids exposing other users' role rows.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.user_roles r
    where r.user_id = (select auth.uid())
      and r.role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

-- ------------------------------------------------------------
-- City and service catalogue
-- ------------------------------------------------------------
create table if not exists public.cities (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  state_name text not null,
  country text not null default 'India',
  is_live boolean not null default false,
  launch_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  icon_name text not null default 'handyman',
  description text,
  is_active boolean not null default true,
  sort_order int not null default 100
);

-- Each city can independently activate only the categories it can fulfil.
create table if not exists public.city_services (
  id uuid primary key default gen_random_uuid(),
  city_id uuid not null references public.cities(id) on delete cascade,
  category_id uuid not null references public.service_categories(id) on delete cascade,
  is_live boolean not null default false,
  launch_at timestamptz,
  created_at timestamptz not null default now(),
  unique (city_id, category_id)
);

create table if not exists public.service_zones (
  id uuid primary key default gen_random_uuid(),
  city_id uuid not null references public.cities(id) on delete cascade,
  name text not null,
  is_active boolean not null default true,
  unique (city_id, name)
);

-- ------------------------------------------------------------
-- Provider applications
-- ------------------------------------------------------------
create table if not exists public.provider_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  city_id uuid not null references public.cities(id),
  full_name text not null,
  phone text not null,
  skills text not null,
  experience_years int not null default 0 check (experience_years between 0 and 60),
  status text not null default 'pending'
    check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  unique (user_id, city_id)
);

-- ------------------------------------------------------------
-- Basic service listings (seeded by trusted admins in this starter)
-- ------------------------------------------------------------
create table if not exists public.service_listings (
  id uuid primary key default gen_random_uuid(),
  city_id uuid not null references public.cities(id) on delete cascade,
  category_id uuid not null references public.service_categories(id),
  title text not null,
  description text,
  indicative_price numeric(12,2) check (indicative_price is null or indicative_price >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (city_id, category_id, title)
);

-- ------------------------------------------------------------
-- Bookings
-- ------------------------------------------------------------
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id),
  city_id uuid not null references public.cities(id),
  category_id uuid not null references public.service_categories(id),
  booking_type text not null
    check (booking_type in ('asap', 'next_day', 'advance')),
  scheduled_at timestamptz,
  address_text text not null check (length(trim(address_text)) >= 5),
  work_details text,
  status text not null default 'requested'
    check (status in ('requested', 'confirmed', 'in_progress', 'completed', 'cancelled', 'disputed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint scheduled_booking_has_time check (
    (booking_type = 'asap' and scheduled_at is null)
    or
    (booking_type in ('next_day', 'advance') and scheduled_at is not null)
  )
);

create index if not exists bookings_customer_created_idx
  on public.bookings(customer_id, created_at desc);
create index if not exists bookings_city_status_idx
  on public.bookings(city_id, status, created_at desc);
create index if not exists listings_city_category_active_idx
  on public.service_listings(city_id, category_id, is_active);
create index if not exists provider_apps_status_created_idx
  on public.provider_applications(status, created_at desc);

-- Do not accept a booking for a city/category that is not live.
create or replace function public.validate_new_booking()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not exists (
    select 1 from public.cities c
    where c.id = new.city_id and c.is_live = true
  ) then
    raise exception 'Bookings are not open in this city yet.';
  end if;

  if not exists (
    select 1
    from public.service_categories sc
    join public.city_services cs on cs.category_id = sc.id
    where sc.id = new.category_id
      and sc.is_active = true
      and cs.city_id = new.city_id
      and cs.is_live = true
  ) then
    raise exception 'This service is not live in the selected city yet.';
  end if;

  if new.booking_type <> 'asap' and new.scheduled_at <= now() then
    raise exception 'Scheduled booking time must be in the future.';
  end if;

  return new;
end;
$$;

drop trigger if exists validate_booking_before_insert on public.bookings;
create trigger validate_booking_before_insert
before insert on public.bookings
for each row execute procedure public.validate_new_booking();

-- Profile/default customer-role creation on signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), '')
  )
  on conflict (id) do nothing;

  insert into public.user_roles (user_id, role)
  values (new.id, 'customer')
  on conflict (user_id, role) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Only an authenticated admin can approve/reject a provider application.
-- Approval grants the provider role; identity and skill verification remain an offline/admin process.
create or replace function public.review_provider_application(
  p_application_id uuid,
  p_new_status text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_user_id uuid;
begin
  if not public.is_admin() then
    raise exception 'Only admins can review provider applications.';
  end if;

  if p_new_status not in ('approved', 'rejected') then
    raise exception 'Invalid application status.';
  end if;

  update public.provider_applications
  set status = p_new_status, reviewed_at = now()
  where id = p_application_id
  returning user_id into target_user_id;

  if target_user_id is null then
    raise exception 'Provider application not found.';
  end if;

  if p_new_status = 'approved' then
    insert into public.user_roles (user_id, role)
    values (target_user_id, 'provider')
    on conflict (user_id, role) do nothing;
  end if;
end;
$$;

revoke all on function public.review_provider_application(uuid, text) from public;
grant execute on function public.review_provider_application(uuid, text) to authenticated;

-- ------------------------------------------------------------
-- Row Level Security
-- ------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.cities enable row level security;
alter table public.service_categories enable row level security;
alter table public.city_services enable row level security;
alter table public.service_zones enable row level security;
alter table public.provider_applications enable row level security;
alter table public.service_listings enable row level security;
alter table public.bookings enable row level security;

-- Public directory
drop policy if exists "Public can read cities" on public.cities;
create policy "Public can read cities"
on public.cities for select
using (true);

drop policy if exists "Admins update cities" on public.cities;
create policy "Admins update cities"
on public.cities for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Public can read active categories" on public.service_categories;
create policy "Public can read active categories"
on public.service_categories for select
using (is_active = true or public.is_admin());

drop policy if exists "Admins manage categories" on public.service_categories;
create policy "Admins manage categories"
on public.service_categories for all to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()));

drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile"
on public.profiles for update to authenticated
using (id = (select auth.uid()))
with check (id = (select auth.uid()));

drop policy if exists "Users read own roles" on public.user_roles;
create policy "Users read own roles"
on public.user_roles for select to authenticated
using (user_id = (select auth.uid()));

-- No client insert/update/delete policy exists on user_roles:
-- role escalation must only happen through a trusted admin process.

drop policy if exists "Users read city service configuration" on public.city_services;
create policy "Users read city service configuration"
on public.city_services for select
using (true);

drop policy if exists "Admins manage city services" on public.city_services;
create policy "Admins manage city services"
on public.city_services for all to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Public reads active zones" on public.service_zones;
create policy "Public reads active zones"
on public.service_zones for select
using (is_active = true or public.is_admin());

drop policy if exists "Admins manage zones" on public.service_zones;
create policy "Admins manage zones"
on public.service_zones for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Provider applications: applicant can create and read own; admin can review.
drop policy if exists "Users create own provider application" on public.provider_applications;
create policy "Users create own provider application"
on public.provider_applications for insert to authenticated
with check (user_id = (select auth.uid()) and status = 'pending');

drop policy if exists "Users read own provider applications" on public.provider_applications;
create policy "Users read own provider applications"
on public.provider_applications for select to authenticated
using (user_id = (select auth.uid()) or public.is_admin());

drop policy if exists "Admins review provider applications" on public.provider_applications;
create policy "Admins review provider applications"
on public.provider_applications for update to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Service catalogue: all active listings readable, admins manage.
drop policy if exists "Users read active listings" on public.service_listings;
create policy "Users read active listings"
on public.service_listings for select
using (is_active = true or public.is_admin());

drop policy if exists "Admins manage service listings" on public.service_listings;
create policy "Admins manage service listings"
on public.service_listings for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Bookings: customers create/read own; admins read/update all.
drop policy if exists "Customers create own bookings" on public.bookings;
create policy "Customers create own bookings"
on public.bookings for insert to authenticated
with check (customer_id = (select auth.uid()));

drop policy if exists "Customers read own bookings" on public.bookings;
create policy "Customers read own bookings"
on public.bookings for select to authenticated
using (customer_id = (select auth.uid()));

drop policy if exists "Admins read all bookings" on public.bookings;
create policy "Admins read all bookings"
on public.bookings for select to authenticated
using (public.is_admin());

drop policy if exists "Admins update bookings" on public.bookings;
create policy "Admins update bookings"
on public.bookings for update to authenticated
using (public.is_admin())
with check (public.is_admin());

-- ------------------------------------------------------------
-- Seed data
-- ------------------------------------------------------------
insert into public.cities (name, state_name, country, is_live, launch_at)
values
  ('Mirzapur', 'Uttar Pradesh', 'India', false, now() + interval '15 days'),
  ('Varanasi', 'Uttar Pradesh', 'India', false, null),
  ('Prayagraj', 'Uttar Pradesh', 'India', false, null)
on conflict (name) do nothing;

insert into public.service_categories (name, icon_name, description, sort_order)
values
  ('Labour', 'groups', 'Daily-wage and skilled labour requests', 1),
  ('Electrician', 'bolt', 'Electrical installation and repair', 2),
  ('Plumber', 'plumbing', 'Plumbing installation and repair', 3),
  ('Carpenter', 'carpenter', 'Furniture and woodwork', 4),
  ('Mechanic', 'car_repair', 'Vehicle repair and maintenance', 5),
  ('AC Technician', 'ac_unit', 'Air conditioner installation and repair', 6),
  ('Driver', 'directions_car', 'Professional driving services', 7),
  ('Vehicle Rental', 'airport_shuttle', 'Eligible vehicle rental services', 8)
on conflict (name) do nothing;

-- Pre-create per-city category switches; keep all OFF until locally ready.
insert into public.city_services (city_id, category_id, is_live)
select c.id, sc.id, false
from public.cities c
cross join public.service_categories sc
on conflict (city_id, category_id) do nothing;
