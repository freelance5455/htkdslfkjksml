'use strict';
const WebSocket = require('ws');
const PORT = Number(process.env.PORT || 8080);
const MAX_PLAYERS = 5;
const wss = new WebSocket.Server({ host: '0.0.0.0', port: PORT, maxPayload: 2048 });
const players = new Map();
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function broadcast(data, except) { const encoded = JSON.stringify(data); for (const client of wss.clients) if (client !== except && client.readyState === WebSocket.OPEN) client.send(encoded); }
function publicPlayer(p) { return { id:p.id, name:p.name, x:p.x, z:p.z, yaw:p.yaw }; }
function count() { return players.size; }
wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (buffer) => {
    let msg; try { msg = JSON.parse(buffer.toString()); } catch { send(ws,{type:'error',message:'Некоректне повідомлення.'}); return; }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'join') {
      if (ws.playerId) return;
      if (players.size >= MAX_PLAYERS) { send(ws,{type:'full'}); ws.close(1008,'Server full'); return; }
      const id = (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`;
      const cleanName = String(msg.name || 'Гравець').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,16) || 'Гравець';
      const p = { id, name:cleanName, x:finite(msg.x,0), z:finite(msg.z,5), yaw:finite(msg.yaw,0) };
      ws.playerId = id; players.set(id,p);
      send(ws,{type:'joined',id,count:count(),players:[...players.values()].map(publicPlayer)});
      broadcast({type:'player-joined',player:publicPlayer(p),count:count()},ws);
      return;
    }
    if (msg.type === 'move' && ws.playerId) {
      const p = players.get(ws.playerId); if (!p) return;
      p.x = clamp(finite(msg.x,p.x),-10000,10000); p.z = clamp(finite(msg.z,p.z),-10000,10000); p.yaw = clamp(finite(msg.yaw,p.yaw),-1000,1000);
      broadcast({type:'player-moved',player:publicPlayer(p)},ws);
    }
  });
  ws.on('close', () => { if (ws.playerId && players.has(ws.playerId)) { const id=ws.playerId; players.delete(id); broadcast({type:'player-left',id,count:count()}); } });
  ws.on('error', () => {});
});
function finite(v, fallback) { const n=Number(v); return Number.isFinite(n) ? n : fallback; }
function clamp(v, min, max) { return Math.max(min, Math.min(max,v)); }
const heartbeat = setInterval(() => { for (const ws of wss.clients) { if (ws.isAlive === false) { ws.terminate(); continue; } ws.isAlive=false; ws.ping(); } }, 30000);
wss.on('close', () => clearInterval(heartbeat));
wss.on('listening', () => console.log(`Rust Mobile multiplayer server listening on port ${PORT} (max ${MAX_PLAYERS} players)`));
