@echo off
set "PATH=%PATH%;%ProgramFiles%\nodejs;%LocalAppData%\Programs\Python\Python312;%LocalAppData%\Programs\Python\Python312\Scripts;%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts;%ProgramFiles%\FFmpeg\bin;%ProgramFiles%\Git\cmd"
cd /d "%~dp0app"
echo ok>..\.prep-ok