نبرد شش مهره — پروژه اندروید

این پوشه سورس آمادهٔ بازکردن در Android Studio است؛ APK کامپایل‌شده نیست.

روش ساخت APK:
1) Android Studio را نصب کنید.
2) از File > Open، همین پوشه NabardSheshMahre-Android را باز کنید.
3) صبر کنید Gradle Sync کامل شود و در صورت درخواست، Android SDK Platform 35 را نصب کنید.
4) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را انتخاب کنید.
5) فایل APK معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

بازی داخل برنامه آفلاین اجرا می‌شود و برای دو نفر روی یک گوشی طراحی شده است.
