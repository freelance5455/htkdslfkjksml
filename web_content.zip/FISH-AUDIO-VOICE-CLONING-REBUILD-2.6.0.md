# Fish Audio Voice Cloning Studio rebuild — 2.6.0

## Implemented
- Added a private persistent voice model creation workflow using the documented Fish Audio `POST /model` multipart API.
- Required voice name, reference audio, private visibility, and explicit ownership/permission consent.
- Added server-side file extension, MIME, size, and signature checks for WAV, MP3, M4A, and OPUS.
- Added optional in-browser recording only when the browser supports Ogg/Opus, a format supported by Fish Audio.
- Added user-owned private voice profile storage with SQLite/MySQL runtime schema and migration 007.
- Added private voice listing and owner-only deletion endpoints.
- Added use-for-speech selection and made private cloned voices available in the AI Agent voice selector.
- Kept speech generation, public voice browsing, playback, history, and existing wallet/idempotency behavior.

## Provider contract
- Persistent clones are created through `POST https://api.fish.audio/model` with multipart `type=tts`, `title`, `description`, `visibility=private`, `train_mode=fast`, and `voices` sample.
- The returned model `_id`/`id` is stored as the reusable `reference_id`.
- Text-to-speech continues through the existing `/v1/tts` service.
- The provider key remains server-side.

## Limitations and safety
- Fish Audio voice cloning is enabled only for samples the user owns or has explicit permission to use. Consent version and timestamp are recorded.
- This app does not attempt automatic format conversion or promise duration inspection where hosting lacks an audio-analysis binary.
- Provider operations still require a valid Fish Audio key, provider account entitlement, outbound HTTPS, PHP cURL, and a deployed HTTPS site.
- Actual live clone creation, voice playback, and deletion remain NOT TESTED here because no user provider credentials or live hosting environment were supplied.

## AI Agent configuration update
- Added provider-documented speaking-language selection (52 language codes), speech model selection (`drama-3` or `s2.1-pro`), speaking speed (0.5–2.0), and expressive mode.
- Agent voice configuration explicitly uses the `fish_tts` engine so selected voice IDs and TTS model settings are not silently overridden by the provider's Live 3 default.
- Editing a published agent now marks its local state as Draft after Fish Audio saves the draft patch; users must publish again before new settings are live.

## WhatsApp Business Calling guidance
- Added an in-app setup guide using Fish Audio's documented console-managed import flow.
- Shows the official callback URL and `calls` webhook subscription requirement.
- Explicitly states that number import and verify-token generation remain in the Fish Audio console; the app does not claim a number is connected.
- Documents inbound-only support and the lack of outbound calls, transfers and keypad input.

## Administration
- Added a real Fish Audio connection-test action that performs an authenticated provider voice-list request.
- The test result is based on an actual API response, not the presence of a saved key alone.

## Optional Anonymoux clone-credit pricing
- Added an administrator-configurable credit cost per private voice clone. It defaults to 0 (disabled) until the platform owner sets a price.
- Clone requests use a user-scoped idempotency record to avoid accidental duplicate provider model creation and duplicate wallet deductions on retries.
- If configured credits cannot be charged after a provider model is created, the app attempts to remove that provider model before reporting failure.
