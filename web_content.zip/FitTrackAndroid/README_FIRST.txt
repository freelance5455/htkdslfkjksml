FITTRACK ANDROID APP PROJECT
============================

This is a real Android Studio project. It wraps the FitTrack app inside a native Android WebView,
so it installs as a normal APK and does NOT depend on Chrome or Add to Home screen.

WHAT IS INCLUDED
- 2500 kcal target
- Food/calorie/protein logging
- 6-day PPL workout plan
- Progressive overload: previous session, current session, best weight, next target
- Exercise history
- Body weight and waist tracking
- Offline local storage
- No floor barbell pullover

BUILD REQUIREMENTS
- Windows/macOS/Linux computer
- Latest Android Studio
- Android SDK Platform 36
- JDK 17 (Android Studio normally supplies/configures this)
- Internet during the first project sync so Gradle/Android Gradle Plugin can be downloaded

BUILD STEPS
1. Install Android Studio from https://developer.android.com/studio
2. Extract this FitTrackAndroid folder.
3. Open Android Studio.
4. Choose File > Open and select the FitTrackAndroid folder.
5. Let Gradle sync finish. If Android Studio asks to download missing SDK/Gradle components, allow it.
6. If SDK 36 is missing: Tools > SDK Manager > SDK Platforms > Android 16 / API 36 > Apply.
7. Connect your Android phone with USB debugging enabled, OR use Build > Build Bundle(s) / APK(s) > Build APK(s).
8. After a successful build, Android Studio will show a notification with 'locate'. The APK will be under:
   app/build/outputs/apk/debug/app-debug.apk
9. Send that APK to your phone and install it.

PHONE INSTALL
- Open the APK on your phone.
- If Android asks permission to install from this source, allow your file manager/browser to install apps.
- Tap Install.
- Open FitTrack from the app drawer.

IMPORTANT
You do NOT need Chrome or Add to Home screen after installing the APK.
Your FitTrack data is stored locally inside the app.

If Android Studio reports a Gradle version issue, use the Gradle version required by the Android Gradle Plugin shown in the error.
This project is configured for Android Gradle Plugin 8.13.2 / Gradle 8.13.
