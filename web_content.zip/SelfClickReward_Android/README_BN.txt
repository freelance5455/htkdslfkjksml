Self Click Reward — Android source project

Start.io App ID: 209203402

এই ZIP-এ Android Studio-তে খোলার মতো source project আছে:
- আগের মতো Points / Banner area / Task 1/40 / START স্ক্রিন
- Start.io SDK dependency
- Android native Banner views (উপরে ও নিচে)
- START চাপলে Interstitial ad load করে; ad load হলে দেখায়

গুরুত্বপূর্ণ:
1) এটি source project, তৈরি APK নয়।
2) ZIP-টি Android Studio-তে খুলে Gradle Sync এবং Build APK করতে হবে।
3) Android Builder যদি custom Gradle/Java SDK integration সমর্থন না করে, এই project সরাসরি সেখানে import করা যাবে না।
4) App ID সঠিক ও Start.io dashboard-এ app active/approved থাকা, network availability এবং SDK initialization দরকার। বিজ্ঞাপন আসা নিশ্চিত নয়।
5) ডেভেলপমেন্টে Start.io test ads ব্যবহার করুন এবং নিজের বিজ্ঞাপনে ক্লিক করবেন না।
6) বিজ্ঞাপন দেখার বিনিময়ে cash বা cash-convertible points দেবেন না; invalid traffic/নীতিভঙ্গের ঝুঁকি আছে।
7) Points এখন শুধু UI placeholder; Firebase persistence বা real reward logic যুক্ত নেই।
