package com.selfclick.reward;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.ads.banner.Banner;

public class MainActivity extends Activity {
    private static final String STARTIO_APP_ID = "209203402";
    private StartAppAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        StartAppSDK.initParams(this, STARTIO_APP_ID)
                .setReturnAdsEnabled(false)
                .setCallback(new Runnable() {
                    @Override public void run() {
                        // SDK is ready for ad requests.
                    }
                })
                .init();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFF101522);

        Banner topBanner = new Banner(this);
        page.addView(topBanner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        WebView webView = new WebView(this);
        webView.setBackgroundColor(0xFF101522);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdBridge(), "AndroidAds");
        webView.loadUrl("file:///android_asset/index.html");
        page.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        Banner bottomBanner = new Banner(this);
        page.addView(bottomBanner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(page);
    }

    private class AdBridge {
        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    interstitialAd = new StartAppAd(MainActivity.this);
                    interstitialAd.loadAd(new AdEventListener() {
                        @Override
                        public void onReceiveAd(@NonNull Ad ad) {
                            interstitialAd.showAd();
                        }

                        @Override
                        public void onFailedToReceiveAd(@Nullable Ad ad) {
                            Toast.makeText(MainActivity.this,
                                    "No ad available right now",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }
    }
}
