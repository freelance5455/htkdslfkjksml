CLICKER UNIVERSE — UPDATE 5.0 INFINITY

Files:
- clicker_universe.html: Owner edition, includes Admin Panel.
- clicker_universe_brother.html: Brother edition, Admin Panel hidden.

New / fixes:
- /givecoins inf and /give coins inf set coins to Infinity.
- Infinite coins persist through save/reload and stay infinite during Rebirth.
- Rebirth limit is 100 by default. The display shows progress as current/maximum.
- Rebirth and MAX Rebirth stop at the cap, including infinite coins.
- Owner/Admin command /setmaxrebirth 250 changes the cap (minimum 100).
- Admin /rebirth, /setrebirth, and /prestige respect the cap.
- Generic section buttons now complete a one-time activity for +250 coins instead of being inert.

Open the HTML file in a browser. These are browser games, not Android APKs.
JS syntax was checked with Node.js; gameplay was not fully browser-tested.
