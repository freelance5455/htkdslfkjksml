package com.my.page;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;

    private static final int FILE_PICKER_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);

        setContentView(webView);

        setupWebView();
    }

    private void setupWebView() {

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        webView.setWebChromeClient(
                new WebChromeClient()
        );

        webView.setWebViewClient(
                new WebViewClient()
        );

        /*
         * JavaScript can use:
         *
         * Android.chooseFile()
         * Android.openStoredFile(...)
         * Android.shareStoredFile(...)
         */
        webView.addJavascriptInterface(
                new AndroidBridge(this),
                "Android"
        );

        /*
         * Load HTML from:
         *
         * app/src/main/assets/index.html
         */
        webView.loadUrl(
                "file:///android_asset/index.html"
        );
    }

    /*
     * =====================================================
     * OPEN ANDROID SYSTEM FILE PICKER
     * =====================================================
     */
    private void openFilePicker() {

        Intent intent =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        intent.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        /*
         * Allow all normal file types.
         */
        intent.setType("*/*");

        /*
         * Tell Android which types are useful.
         */
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{

                        "application/pdf",

                        "image/*",

                        "text/*",

                        "application/msword",

                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",

                        "application/vnd.ms-excel",

                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

                        "application/vnd.ms-powerpoint",

                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",

                        "audio/*",

                        "video/*",

                        "application/zip"
                }
        );

        startActivityForResult(
                intent,
                FILE_PICKER_REQUEST
        );
    }

    /*
     * =====================================================
     * RESULT FROM ANDROID FILE PICKER
     * =====================================================
     */
    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode != FILE_PICKER_REQUEST) {
            return;
        }

        /*
         * User pressed Cancel.
         */
        if (resultCode != RESULT_OK) {
            return;
        }

        if (data == null) {
            return;
        }

        Uri uri =
                data.getData();

        if (uri == null) {
            return;
        }

        /*
         * Try to keep permission for this
         * selected document.
         */
        try {

            int takeFlags =
                    data.getFlags()
                    &
                    (
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                        |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );

            if (takeFlags != 0) {

                try {

                    getContentResolver()
                            .takePersistableUriPermission(
                                    uri,
                                    takeFlags
                            );

                } catch (Exception ignored) {
                }
            }

        } catch (Exception ignored) {
        }

        /*
         * Read the selected file and send it
         * to the HTML page.
         */
        sendSelectedFileToWebView(uri);
    }

    /*
     * =====================================================
     * READ SELECTED FILE
     * =====================================================
     */
    private void sendSelectedFileToWebView(
            Uri uri) {

        try {

            String fileName =
                    getFileName(uri);

            String mimeType =
                    getContentResolver()
                            .getType(uri);

            if (
                    mimeType == null
                    ||
                    mimeType.trim().isEmpty()
            ) {

                mimeType =
                        getMimeType(fileName);
            }

            InputStream input =
                    getContentResolver()
                            .openInputStream(uri);

            if (input == null) {

                throw new IOException(
                        "Unable to open file"
                );
            }

            ByteArrayOutputStream output =
                    new ByteArrayOutputStream();

            byte[] buffer =
                    new byte[8192];

            int length;

            while (
                    (length = input.read(buffer))
                    != -1
            ) {

                output.write(
                        buffer,
                        0,
                        length
                );
            }

            input.close();

            byte[] fileBytes =
                    output.toByteArray();

            /*
             * Convert file to Base64 so it can
             * safely travel from Java to HTML.
             */
            String base64 =
                    android.util.Base64
                            .encodeToString(
                                    fileBytes,
                                    android.util.Base64.NO_WRAP
                            );

            String safeName =
                    escapeJavaScript(
                            fileName
                    );

            String safeMime =
                    escapeJavaScript(
                            mimeType
                    );

            String safeBase64 =
                    escapeJavaScript(
                            base64
                    );

            /*
             * Send file to the HTML page.
             *
             * Your index.html should contain:
             *
             * receiveNativeFile(
             *     fileName,
             *     mimeType,
             *     base64
             * )
             */
            String javascript =
                    "if(typeof window.receiveNativeFile === 'function'){" +
                    "window.receiveNativeFile('" +
                    safeName +
                    "','" +
                    safeMime +
                    "','" +
                    safeBase64 +
                    "');" +
                    "}else{" +
                    "alert('Native file receiver is missing from index.html');" +
                    "}";

            webView.post(
                    () ->
                            webView.evaluateJavascript(
                                    javascript,
                                    null
                            )
            );

        } catch (Exception e) {

            e.printStackTrace();

            Toast.makeText(
                    this,
                    "Could not read selected file",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    /*
     * =====================================================
     * GET ORIGINAL FILE NAME
     * =====================================================
     */
    private String getFileName(Uri uri) {

        String result = null;

        try {

            Cursor cursor =
                    getContentResolver()
                            .query(
                                    uri,
                                    null,
                                    null,
                                    null,
                                    null
                            );

            if (cursor != null) {

                int nameIndex =
                        cursor.getColumnIndex(
                                OpenableColumns.DISPLAY_NAME
                        );

                if (
                        nameIndex >= 0
                        &&
                        cursor.moveToFirst()
                ) {

                    result =
                            cursor.getString(
                                    nameIndex
                            );
                }

                cursor.close();
            }

        } catch (Exception ignored) {
        }

        if (
                result == null
                ||
                result.trim().isEmpty()
        ) {

            result = "file";
        }

        return result;
    }

    /*
     * =====================================================
     * JAVASCRIPT ESCAPING
     * =====================================================
     */
    private String escapeJavaScript(
            String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace(
                        "\\",
                        "\\\\"
                )
                .replace(
                        "'",
                        "\\'"
                )
                .replace(
                        "\n",
                        "\\n"
                )
                .replace(
                        "\r",
                        "\\r"
                )
                .replace(
                        "</",
                        "<\\/"
                );
    }

    /*
     * =====================================================
     * JAVASCRIPT ↔ ANDROID BRIDGE
     * =====================================================
     */
    public class AndroidBridge {

        private final Context context;

        AndroidBridge(Context context) {

            this.context = context;
        }

        /*
         * Called by HTML:
         *
         * Android.chooseFile()
         */
        @JavascriptInterface
        public void chooseFile() {

            runOnUiThread(
                    () -> openFilePicker()
            );
        }

        /*
         * Called by HTML when user taps
         * an already stored file.
         *
         * This opens Android's native
         * "Open with" chooser.
         */
        @JavascriptInterface
        public void openStoredFile(
                String fileName,
                String mimeType,
                String base64Data) {

            runOnUiThread(
                    () -> {

                        try {

                            if (
                                    fileName == null
                                    ||
                                    fileName.trim().isEmpty()
                            ) {

                                fileName = "file";
                            }

                            if (
                                    mimeType == null
                                    ||
                                    mimeType.trim().isEmpty()
                            ) {

                                mimeType =
                                        getMimeType(
                                                fileName
                                        );
                            }

                            byte[] data =
                                    android.util.Base64
                                            .decode(
                                                    base64Data,
                                                    android.util.Base64.DEFAULT
                                            );

                            File shareDirectory =
                                    new File(
                                            getCacheDir(),
                                            "share"
                                    );

                            if (
                                    !shareDirectory.exists()
                            ) {

                                if (
                                        !shareDirectory.mkdirs()
                                ) {

                                    throw new IOException(
                                            "Could not create share directory"
                                    );
                                }
                            }

                            String safeName =
                                    new File(
                                            fileName
                                    ).getName();

                            File outputFile =
                                    new File(
                                            shareDirectory,
                                            safeName
                                    );

                            FileOutputStream output =
                                    new FileOutputStream(
                                            outputFile
                                    );

                            output.write(data);

                            output.flush();

                            output.close();

                            Uri contentUri =
                                    FileProvider
                                            .getUriForFile(
                                                    context,
                                                    getPackageName()
                                                            +
                                                            ".fileprovider",
                                                    outputFile
                                            );

                            Intent intent =
                                    new Intent(
                                            Intent.ACTION_VIEW
                                    );

                            intent.setDataAndType(
                                    contentUri,
                                    mimeType
                            );

                            intent.addFlags(
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            );

                            Intent chooser =
                                    Intent.createChooser(
                                            intent,
                                            "Open with"
                                    );

                            chooser.addFlags(
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            );

                            try {

                                context.startActivity(
                                        chooser
                                );

                            } catch (
                                    ActivityNotFoundException e
                            ) {

                                Toast.makeText(
                                        context,
                                        "No app found to open this file",
                                        Toast.LENGTH_LONG
                                ).show();
                            }

                        } catch (Exception e) {

                            e.printStackTrace();

                            Toast.makeText(
                                    context,
                                    "Could not open file",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );
        }

        /*
         * Native sharing.
         */
        @JavascriptInterface
        public void shareStoredFile(
                String fileName,
                String mimeType,
                String base64Data) {

            runOnUiThread(
                    () -> {

                        try {

                            if (
                                    fileName == null
                                    ||
                                    fileName.trim().isEmpty()
                            ) {

                                fileName = "file";
                            }

                            if (
                                    mimeType == null
                                    ||
                                    mimeType.trim().isEmpty()
                            ) {

                                mimeType =
                                        getMimeType(
                                                fileName
                                        );
                            }

                            byte[] data =
                                    android.util.Base64
                                            .decode(
                                                    base64Data,
                                                    android.util.Base64.DEFAULT
                                            );

                            File shareDirectory =
                                    new File(
                                            getCacheDir(),
                                            "share"
                                    );

                            if (
                                    !shareDirectory.exists()
                            ) {

                                shareDirectory.mkdirs();
                            }

                            String safeName =
                                    new File(
                                            fileName
                                    ).getName();

                            File outputFile =
                                    new File(
                                            shareDirectory,
                                            safeName
                                    );

                            FileOutputStream output =
                                    new FileOutputStream(
                                            outputFile
                                    );

                            output.write(data);

                            output.flush();

                            output.close();

                            Uri contentUri =
                                    FileProvider
                                            .getUriForFile(
                                                    context,
                                                    getPackageName()
                                                            +
                                                            ".fileprovider",
                                                    outputFile
                                            );

                            Intent shareIntent =
                                    new Intent(
                                            Intent.ACTION_SEND
                                    );

                            shareIntent.setType(
                                    mimeType
                            );

                            shareIntent.putExtra(
                                    Intent.EXTRA_STREAM,
                                    contentUri
                            );

                            shareIntent.addFlags(
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            );

                            context.startActivity(
                                    Intent.createChooser(
                                            shareIntent,
                                            "Share file"
                                    )
                            );

                        } catch (Exception e) {

                            e.printStackTrace();

                            Toast.makeText(
                                    context,
                                    "Could not share file",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );
        }
    }

    /*
     * =====================================================
     * MIME TYPE DETECTION
     * =====================================================
     */
    private String getMimeType(
            String fileName) {

        String name =
                fileName.toLowerCase(
                        Locale.US
                );

        if (name.endsWith(".pdf"))
            return "application/pdf";

        if (
                name.endsWith(".jpg")
                ||
                name.endsWith(".jpeg")
        )
            return "image/jpeg";

        if (name.endsWith(".png"))
            return "image/png";

        if (name.endsWith(".gif"))
            return "image/gif";

        if (name.endsWith(".webp"))
            return "image/webp";

        if (name.endsWith(".txt"))
            return "text/plain";

        if (
                name.endsWith(".html")
                ||
                name.endsWith(".htm")
        )
            return "text/html";

        if (name.endsWith(".doc"))
            return "application/msword";

        if (name.endsWith(".docx"))
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

        if (name.endsWith(".xls"))
            return "application/vnd.ms-excel";

        if (name.endsWith(".xlsx"))
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        if (name.endsWith(".ppt"))
            return "application/vnd.ms-powerpoint";

        if (name.endsWith(".pptx"))
            return "application/vnd.openxmlformats-officedocument.presentationml.presentation";

        if (name.endsWith(".zip"))
            return "application/zip";

        if (name.endsWith(".mp3"))
            return "audio/mpeg";

        if (name.endsWith(".mp4"))
            return "video/mp4";

        return "*/*";
    }

    /*
     * =====================================================
     * BACK BUTTON
     * =====================================================
     */
    @Override
    public void onBackPressed() {

        if (
                webView != null
                &&
                webView.canGoBack()
        ) {

            webView.goBack();

        } else {

            super.onBackPressed();
        }
    }

    /*
     * =====================================================
     * CLEAN UP
     * =====================================================
     */
    @Override
    protected void onDestroy() {

        if (webView != null) {

            webView.removeJavascriptInterface(
                    "Android"
            );

            webView.destroy();
        }

        super.onDestroy();
    }
}