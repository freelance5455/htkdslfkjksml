package com.my.page;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;

    private static final int FILE_PICKER_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);

        setContentView(webView);

        setupWebView();
    }

    private void setupWebView() {

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request) {

                return false;
            }
        });

        /*
         * JavaScript → Android bridge
         *
         * JavaScript can call:
         *
         * Android.openStoredFile(filename, mime, base64)
         */
        webView.addJavascriptInterface(
                new AndroidBridge(this),
                "Android"
        );

        webView.loadUrl("file:///android_asset/index.html");
    }

    /*
     * Native Android bridge
     */
    public class AndroidBridge {

        private final Context context;

        AndroidBridge(Context context) {
            this.context = context;
        }

        /*
         * Called from JavaScript.
         *
         * Example:
         *
         * Android.openStoredFile(
         *     "lecture.pdf",
         *     "application/pdf",
         *     "BASE64_DATA"
         * );
         */
        @JavascriptInterface
        public void openStoredFile(
                String fileName,
                String mimeType,
                String base64Data) {

            runOnUiThread(() -> {

                try {

                    if (fileName == null || fileName.trim().isEmpty()) {
                        fileName = "file";
                    }

                    if (mimeType == null || mimeType.trim().isEmpty()) {
                        mimeType = getMimeType(fileName);
                    }

                    byte[] data =
                            android.util.Base64.decode(
                                    base64Data,
                                    android.util.Base64.DEFAULT
                            );

                    File shareDirectory =
                            new File(
                                    getCacheDir(),
                                    "share"
                            );

                    if (!shareDirectory.exists()) {
                        shareDirectory.mkdirs();
                    }

                    /*
                     * Remove dangerous path characters.
                     */
                    String safeName =
                            new File(fileName).getName();

                    File outputFile =
                            new File(
                                    shareDirectory,
                                    safeName
                            );

                    /*
                     * Write actual file bytes.
                     */
                    FileOutputStream output =
                            new FileOutputStream(outputFile);

                    output.write(data);
                    output.flush();
                    output.close();

                    /*
                     * Convert local file into secure
                     * content:// URI.
                     */
                    Uri contentUri =
                            FileProvider.getUriForFile(
                                    context,
                                    getPackageName() +
                                            ".fileprovider",
                                    outputFile
                            );

                    /*
                     * Native Android Open With.
                     */
                    Intent intent =
                            new Intent(Intent.ACTION_VIEW);

                    intent.setDataAndType(
                            contentUri,
                            mimeType
                    );

                    intent.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    intent.addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK
                    );

                    /*
                     * Ask Android to show the
                     * system app chooser.
                     */
                    Intent chooser =
                            Intent.createChooser(
                                    intent,
                                    "Open with"
                            );

                    chooser.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    try {

                        context.startActivity(chooser);

                    } catch (ActivityNotFoundException e) {

                        Toast.makeText(
                                context,
                                "No app found to open this file",
                                Toast.LENGTH_LONG
                        ).show();

                    }

                } catch (Exception e) {

                    e.printStackTrace();

                    Toast.makeText(
                            context,
                            "Could not open file",
                            Toast.LENGTH_LONG
                    ).show();
                }

            });
        }

        /*
         * Optional native Share function.
         */
        @JavascriptInterface
        public void shareStoredFile(
                String fileName,
                String mimeType,
                String base64Data) {

            runOnUiThread(() -> {

                try {

                    if (fileName == null ||
                            fileName.trim().isEmpty()) {

                        fileName = "file";
                    }

                    if (mimeType == null ||
                            mimeType.trim().isEmpty()) {

                        mimeType = getMimeType(fileName);
                    }

                    byte[] data =
                            android.util.Base64.decode(
                                    base64Data,
                                    android.util.Base64.DEFAULT
                            );

                    File shareDirectory =
                            new File(
                                    getCacheDir(),
                                    "share"
                            );

                    if (!shareDirectory.exists()) {
                        shareDirectory.mkdirs();
                    }

                    String safeName =
                            new File(fileName).getName();

                    File outputFile =
                            new File(
                                    shareDirectory,
                                    safeName
                            );

                    FileOutputStream output =
                            new FileOutputStream(outputFile);

                    output.write(data);
                    output.flush();
                    output.close();

                    Uri contentUri =
                            FileProvider.getUriForFile(
                                    context,
                                    getPackageName() +
                                            ".fileprovider",
                                    outputFile
                            );

                    Intent shareIntent =
                            new Intent(
                                    Intent.ACTION_SEND
                            );

                    shareIntent.setType(mimeType);

                    shareIntent.putExtra(
                            Intent.EXTRA_STREAM,
                            contentUri
                    );

                    shareIntent.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    Intent chooser =
                            Intent.createChooser(
                                    shareIntent,
                                    "Share file"
                            );

                    context.startActivity(chooser);

                } catch (Exception e) {

                    e.printStackTrace();

                    Toast.makeText(
                            context,
                            "Could not share file",
                            Toast.LENGTH_LONG
                    ).show();
                }

            });
        }
    }

    /*
     * MIME type detection.
     */
    private String getMimeType(String fileName) {

        String name =
                fileName.toLowerCase(
                        Locale.US
                );

        if (name.endsWith(".pdf")) {
            return "application/pdf";
        }

        if (name.endsWith(".jpg") ||
                name.endsWith(".jpeg")) {

            return "image/jpeg";
        }

        if (name.endsWith(".png")) {
            return "image/png";
        }

        if (name.endsWith(".gif")) {
            return "image/gif";
        }

        if (name.endsWith(".webp")) {
            return "image/webp";
        }

        if (name.endsWith(".txt")) {
            return "text/plain";
        }

        if (name.endsWith(".html") ||
                name.endsWith(".htm")) {

            return "text/html";
        }

        if (name.endsWith(".doc")) {
            return "application/msword";
        }

        if (name.endsWith(".docx")) {
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        }

        if (name.endsWith(".xls")) {
            return "application/vnd.ms-excel";
        }

        if (name.endsWith(".xlsx")) {
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }

        if (name.endsWith(".ppt")) {
            return "application/vnd.ms-powerpoint";
        }

        if (name.endsWith(".pptx")) {
            return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        }

        if (name.endsWith(".zip")) {
            return "application/zip";
        }

        if (name.endsWith(".mp3")) {
            return "audio/mpeg";
        }

        if (name.endsWith(".mp4")) {
            return "video/mp4";
        }

        return "*/*";
    }

    /*
     * Back button:
     * first let the HTML page handle its own
     * navigation/history.
     */
    @Override
    public void onBackPressed() {

        if (webView != null &&
                webView.canGoBack()) {

            webView.goBack();

        } else {

            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {

        if (webView != null) {

            webView.removeJavascriptInterface(
                    "Android"
            );

            webView.destroy();
        }

        super.onDestroy();
    }
}