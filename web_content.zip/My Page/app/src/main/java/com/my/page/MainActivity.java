package com.my.page;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;

    private static final int FILE_PICKER_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        setupWebView();
    }

    private void setupWebView() {

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient());

        webView.addJavascriptInterface(
                new AndroidBridge(this),
                "Android"
        );

        webView.loadUrl("file:///android_asset/index.html");
    }

    /*
     * ============================================
     * OPEN ANDROID FILE PICKER
     * ============================================
     */
    public void openFilePicker() {

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

        intent.addCategory(Intent.CATEGORY_OPENABLE);

        intent.setType("*/*");

        /*
         * Allow multiple types of files:
         * PDF, images, Word, PowerPoint, etc.
         */
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{
                        "application/pdf",
                        "image/*",
                        "text/*",
                        "application/msword",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.ms-excel",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-powerpoint",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        "audio/*",
                        "video/*",
                        "application/zip"
                }
        );

        startActivityForResult(
                intent,
                FILE_PICKER_REQUEST
        );
    }

    /*
     * ============================================
     * RECEIVE SELECTED FILE
     * ============================================
     */
    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode != FILE_PICKER_REQUEST) {
            return;
        }

        /*
         * User pressed Cancel
         */
        if (resultCode != RESULT_OK || data == null) {

            return;
        }

        Uri uri = data.getData();

        if (uri == null) {
            return;
        }

        try {

            /*
             * Keep permission for this URI if Android
             * allows it.
             */
            final int takeFlags =
                    data.getFlags()
                            & (
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            );

            try {

                getContentResolver()
                        .takePersistableUriPermission(
                                uri,
                                takeFlags
                        );

            } catch (Exception ignored) {
                /*
                 * Some providers do not support
                 * persistable permissions.
                 */
            }

            /*
             * Send selected file to JavaScript.
             */
            sendSelectedFileToWebView(uri);

        } catch (Exception e) {

            e.printStackTrace();

            Toast.makeText(
                    this,
                    "Could not select this file",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    /*
     * ============================================
     * READ SELECTED FILE AND SEND TO HTML
     * ============================================
     */
    private void sendSelectedFileToWebView(Uri uri) {

        try {

            String fileName =
                    getFileName(uri);

            String mimeType =
                    getContentResolver()
                            .getType(uri);

            if (mimeType == null ||
                    mimeType.trim().isEmpty()) {

                mimeType =
                        getMimeType(fileName);
            }

            InputStream input =
                    getContentResolver()
                            .openInputStream(uri);

            if (input == null) {
                throw new IOException(
                        "Could not open selected file"
                );
            }

            java.io.ByteArrayOutputStream buffer =
                    new java.io.ByteArrayOutputStream();

            byte[] temp =
                    new byte[8192];

            int length;

            while ((length = input.read(temp)) != -1) {

                buffer.write(
                        temp,
                        0,
                        length
                );
            }

            input.close();

            byte[] bytes =
                    buffer.toByteArray();

            String base64 =
                    android.util.Base64.encodeToString(
                            bytes,
                            android.util.Base64.NO_WRAP
                    );

            /*
             * Escape strings before putting them
             * into JavaScript.
             */
            String safeName =
                    escapeJavaScript(fileName);

            String safeMime =
                    escapeJavaScript(mimeType);

            String safeBase64 =
                    escapeJavaScript(base64);

            String javascript =
                    "window.receiveNativeFile(" +
                    "'" + safeName + "'," +
                    "'" + safeMime + "'," +
                    "'" + safeBase64 + "'" +
                    ");";

            webView.post(() ->
                    webView.evaluateJavascript(
                            javascript,
                            null
                    )
            );

        } catch (Exception e) {

            e.printStackTrace();

            Toast.makeText(
                    this,
                    "Could not read selected file",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    /*
     * ============================================
     * GET REAL FILE NAME
     * ============================================
     */
    private String getFileName(Uri uri) {

        String result = null;

        try {

            android.database.Cursor cursor =
                    getContentResolver()
                            .query(
                                    uri,
                                    null,
                                    null,
                                    null,
                                    null
                            );

            if (cursor != null) {

                int nameIndex =
                        cursor.getColumnIndex(
                                android.provider.OpenableColumns.DISPLAY_NAME
                        );

                if (nameIndex >= 0 &&
                        cursor.moveToFirst()) {

                    result =
                            cursor.getString(
                                    nameIndex
                            );
                }

                cursor.close();
            }

        } catch (Exception ignored) {
        }

        if (result == null ||
                result.trim().isEmpty()) {

            result = "file";
        }

        return result;
    }

    /*
     * ============================================
     * ESCAPE JAVASCRIPT TEXT
     * ============================================
     */
    private String escapeJavaScript(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("</", "<\\/");
    }

    /*
     * ============================================
     * JAVASCRIPT BRIDGE
     * ============================================
     */
    public class AndroidBridge {

        private final Context context;

        AndroidBridge(Context context) {
            this.context = context;
        }

        /*
         * HTML calls this when the user taps
         * an already stored file.
         */
        @JavascriptInterface
        public void openStoredFile(
                String fileName,
                String mimeType,
                String base64Data) {

            runOnUiThread(() -> {

                try {

                    if (fileName == null ||
                            fileName.trim().isEmpty()) {

                        fileName = "file";
                    }

                    if (mimeType == null ||
                            mimeType.trim().isEmpty()) {

                        mimeType =
                                getMimeType(fileName);
                    }

                    byte[] fileData =
                            android.util.Base64.decode(
                                    base64Data,
                                    android.util.Base64.DEFAULT
                            );

                    File shareDirectory =
                            new File(
                                    getCacheDir(),
                                    "share"
                            );

                    if (!shareDirectory.exists()) {

                        shareDirectory.mkdirs();
                    }

                    String safeName =
                            new File(fileName)
                                    .getName();

                    File outputFile =
                            new File(
                                    shareDirectory,
                                    safeName
                            );

                    FileOutputStream output =
                            new FileOutputStream(
                                    outputFile
                            );

                    output.write(fileData);
                    output.flush();
                    output.close();

                    Uri contentUri =
                            FileProvider.getUriForFile(
                                    context,
                                    getPackageName()
                                            + ".fileprovider",
                                    outputFile
                            );

                    Intent intent =
                            new Intent(
                                    Intent.ACTION_VIEW
                            );

                    intent.setDataAndType(
                            contentUri,
                            mimeType
                    );

                    intent.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    Intent chooser =
                            Intent.createChooser(
                                    intent,
                                    "Open with"
                            );

                    chooser.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    try {

                        context.startActivity(
                                chooser
                        );

                    } catch (
                            ActivityNotFoundException e
                    ) {

                        Toast.makeText(
                                context,
                                "No app found to open this file",
                                Toast.LENGTH_LONG
                        ).show();
                    }

                } catch (Exception e) {

                    e.printStackTrace();

                    Toast.makeText(
                            context,
                            "Could not open file",
                            Toast.LENGTH_LONG
                    ).show();
                }

            });
        }

        /*
         * Native share function.
         */
        @JavascriptInterface
        public void shareStoredFile(
                String fileName,
                String mimeType,
                String base64Data) {

            runOnUiThread(() -> {

                try {

                    if (fileName == null ||
                            fileName.trim().isEmpty()) {

                        fileName = "file";
                    }

                    if (mimeType == null ||
                            mimeType.trim().isEmpty()) {

                        mimeType =
                                getMimeType(fileName);
                    }

                    byte[] fileData =
                            android.util.Base64.decode(
                                    base64Data,
                                    android.util.Base64.DEFAULT
                            );

                    File shareDirectory =
                            new File(
                                    getCacheDir(),
                                    "share"
                            );

                    if (!shareDirectory.exists()) {

                        shareDirectory.mkdirs();
                    }

                    String safeName =
                            new File(fileName)
                                    .getName();

                    File outputFile =
                            new File(
                                    shareDirectory,
                                    safeName
                            );

                    FileOutputStream output =
                            new FileOutputStream(
                                    outputFile
                            );

                    output.write(fileData);
                    output.flush();
                    output.close();

                    Uri contentUri =
                            FileProvider.getUriForFile(
                                    context,
                                    getPackageName()
                                            + ".fileprovider",
                                    outputFile
                            );

                    Intent shareIntent =
                            new Intent(
                                    Intent.ACTION_SEND
                            );

                    shareIntent.setType(
                            mimeType
                    );

                    shareIntent.putExtra(
                            Intent.EXTRA_STREAM,
                            contentUri
                    );

                    shareIntent.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    Intent chooser =
                            Intent.createChooser(
                                    shareIntent,
                                    "Share file"
                            );

                    context.startActivity(
                            chooser
                    );

                } catch (Exception e) {

                    e.printStackTrace();

                    Toast.makeText(
                            context,
                            "Could not share file",
                            Toast.LENGTH_LONG
                    ).show();
                }

            });
        }

        /*
         * JavaScript calls this to open
         * Android's file picker.
         */
        @JavascriptInterface
        public void chooseFile() {

            runOnUiThread(() -> {

                openFilePicker();

            });
        }
    }

    /*
     * ============================================
     * MIME TYPE
     * ============================================
     */
    private String getMimeType(String fileName) {

        String name =
                fileName.toLowerCase(
                        Locale.US
                );

        if (name.endsWith(".pdf"))
            return "application/pdf";

        if (name.endsWith(".jpg") ||
                name.endsWith(".jpeg"))
            return "image/jpeg";

        if (name.endsWith(".png"))
            return "image/png";

        if (name.endsWith(".gif"))
            return "image/gif";

        if (name.endsWith(".webp"))
            return "image/webp";

        if (name.endsWith(".txt"))
            return "text/plain";

        if (name.endsWith(".html") ||
                name.endsWith(".htm"))
            return "text/html";

        if (name.endsWith(".doc"))
            return "application/msword";

        if (name.endsWith(".docx"))
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

        if (name.endsWith(".xls"))
            return "application/vnd.ms-excel";

        if (name.endsWith(".xlsx"))
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        if (name.endsWith(".ppt"))
            return "application/vnd.ms-powerpoint";

        if (name.endsWith(".pptx"))
            return "application/vnd.openxmlformats-officedocument.presentationml.presentation";

        if (name.endsWith(".zip"))
            return "application/zip";

        if (name.endsWith(".mp3"))
            return "audio/mpeg";

        if (name.endsWith(".mp4"))
            return "video/mp4";

        return "*/*";
    }

    /*
     * ============================================
     * BACK BUTTON
     * ============================================
     */
    @Override
    public void onBackPressed() {

        if (webView != null &&
                webView.canGoBack()) {

            webView.goBack();

        } else {

            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {

        if (webView != null) {

            webView.removeJavascriptInterface(
                    "Android"
            );

            webView.destroy();
        }

        super.onDestroy();
    }
}

One more important change is needed in "index.html"

Your HTML currently needs to tell Java “open the Android picker.”

Find your existing Add File function. It will probably look something like:

function addFile(){
    document.getElementById("fileInput").click();
}

Change that function to:

function addFile(){

    if(
        window.Android &&
        typeof Android.chooseFile === "function"
    ){
        Android.chooseFile();
        return;
    }

    document.getElementById("fileInput").click();
}

And add this JavaScript function somewhere in your HTML:

function receiveNativeFile(fileName, mimeType, base64){

    try{

        const binary =
            atob(base64);

        const bytes =
            new Uint8Array(
                binary.length
            );

        for(
            let i = 0;
            i < binary.length;
            i++
        ){
            bytes[i] =
                binary.charCodeAt(i);
        }

        const blob =
            new Blob(
                [bytes],
                {
                    type: mimeType || "application/octet-stream"
                }
            );

        const file =
            new File(
                [blob],
                fileName,
                {
                    type: mimeType ||
                        "application/octet-stream"
                }
            );

        /*
         * Pass it into your existing
         * file-saving function.
         *
         * IMPORTANT:
         * If your existing function is named
         * differently, we need to connect this
         * part to that function.
         */
        handleSelectedFile(file);

    }catch(error){

        console.error(error);

        alert(
            "Could not import this file."
        );
    }
}

But don't paste that last function blindly yet if your V13 HTML has a different function name for processing selected files.

The Java side is now ready. The remaining issue is connecting "receiveNativeFile()" to your exact V13 file-saving function, so the selected file gets saved into IndexedDB exactly like your old HTML picker.

If you paste your current V13 "index.html", I can return the complete corrected HTML with this native picker properly connected, without changing your layout.