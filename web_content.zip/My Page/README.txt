MY PAGE - NATIVE ANDROID VERSION
================================

This project contains the My Page Android application.

MAIN FEATURES
-------------

1. Offline HTML application
2. IndexedDB storage
3. Folders/buttons
4. Notes
5. Files
6. Nested pages
7. File colors
8. File rename
9. Backup and restore
10. Native Android Open With
11. Native secure FileProvider
12. Android app chooser
13. PDF opening
14. Image opening
15. DOC/DOCX opening
16. XLS/XLSX opening
17. PPT/PPTX opening
18. Audio/video opening
19. Native sharing support


PROJECT STRUCTURE
-----------------

MyPage/
    settings.gradle
    build.gradle
    gradle.properties

    app/
        build.gradle

        src/main/
            AndroidManifest.xml

            java/com/my/page/
                MainActivity.java

            res/
                values/
                    strings.xml
                    colors.xml
                    styles.xml

                xml/
                    file_paths.xml

            assets/
                index.html


HTML
----

The complete V13 My Page HTML must be placed at:

app/src/main/assets/index.html

The native Android project loads:

file:///android_asset/index.html


OPEN WITH
---------

When a file is tapped, JavaScript calls:

Android.openStoredFile(
    filename,
    mimeType,
    base64Data
)

The Android bridge:

1. Decodes the file
2. Creates a temporary file
3. Places it in the application's cache/share directory
4. Creates a secure content:// URI through FileProvider
5. Creates an Android ACTION_VIEW intent
6. Adds the file MIME type
7. Grants temporary read permission
8. Displays the Android "Open with" chooser


IMPORTANT
---------

The Android application does not replace the My Page HTML interface.

The HTML controls:

- Layout
- Folders
- Notes
- Files
- Colors
- Nested pages
- IndexedDB
- Backup
- Restore

Android controls:

- Native Open With
- Secure file sharing
- External application launching


BACKUP
------

The existing V13 backup/restore system remains in the HTML.

Do not remove or replace the IndexedDB backup system.


FILE PROVIDER
-------------

FileProvider is required because Android does not allow applications
to safely share ordinary file:// URIs with other applications.

The project therefore uses:

content://com.my.page.fileprovider/...


PERMISSIONS
-----------

The application does not request broad storage permission for the
Open With operation.

The temporary file is stored inside the application's private cache
directory and shared using FileProvider.


TESTING
-------

Install the APK on an Android device.

Add a PDF file.

Tap the PDF.

Android should display:

Open with

followed by applications capable of opening PDF files.


If no compatible application is installed, Android may report that no
application is available to open the file.


OFFLINE
-------

The HTML is bundled inside the APK.

No internet connection is required for the My Page application itself.