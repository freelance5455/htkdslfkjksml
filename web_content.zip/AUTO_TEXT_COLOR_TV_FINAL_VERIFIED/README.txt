AUTO TEXT COLOR — FINAL WORKING TV VERSION

উদ্দেশ্য:
- 16:9 TV/TX3 Mini-এর জন্য একই রেফারেন্স ডিজাইন।
- ব্যবহারকারীর দেওয়া নিজের ছবিই user_photo.jpg হিসেবে রাখা হয়েছে।
- উপরের সাদা লেখা ও নিচের রঙিন লেখা আলাদা ঘর।
- Live View-তে পুরো গল্প দেখা ও ↑↓ স্ক্রল।
- ২০টি Settings tile—প্রতিটির আলাদা কার্যকারিতা।
- ৫০টি ব্যাকগ্রাউন্ড এবং ১০০টি রঙের প্যালেট।
- Auto/লাইন/শব্দ/লেটার কালার।
- লেখার আকার, চিকন/মোটা, ইটালিক, alignment ও line spacing।
- History যোগ/ফিরিয়ে আনা/Delete।
- TV/Mobile এবং Day/Night।
- Save, PDF/Print, Share/Copy, File Manager এবং Download।

নোট:
PDF বোতাম ব্রাউজারের Print/Save as PDF ডায়ালগ চালু করে। Share API সব ব্রাউজারে সমানভাবে সমর্থিত নয়; সমর্থন না থাকলে লেখা কপি করার fallback আছে।
