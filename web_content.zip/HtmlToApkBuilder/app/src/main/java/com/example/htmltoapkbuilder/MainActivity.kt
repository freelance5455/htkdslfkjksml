package com.example.htmltoapkbuilder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private lateinit var editor: EditText
    private lateinit var preview: WebView

    private var appName = "My HTML App"
    private var packageNameValue = "com.example.myhtmlapp"
    private var versionName = "1.0"

    private val openHtml = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        contentResolver.openInputStream(uri)?.use { input ->
            val html = BufferedReader(InputStreamReader(input)).readText()
            editor.setText(html)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editor = findViewById(R.id.htmlEditor)
        preview = findViewById(R.id.preview)

        preview.webViewClient = WebViewClient()
        preview.settings.javaScriptEnabled = true
        preview.settings.domStorageEnabled = true
        preview.settings.allowFileAccess = true
        preview.settings.cacheMode = WebSettings.LOAD_DEFAULT

        findViewById<Button>(R.id.importButton).setOnClickListener {
            openHtml.launch(arrayOf("text/html", "text/plain"))
        }

        findViewById<Button>(R.id.editorTab).setOnClickListener {
            editor.visibility = android.view.View.VISIBLE
            preview.visibility = android.view.View.GONE
        }

        findViewById<Button>(R.id.previewTab).setOnClickListener {
            preview.visibility = android.view.View.VISIBLE
            editor.visibility = android.view.View.GONE
            preview.loadDataWithBaseURL(
                "https://localhost/",
                editor.text.toString(),
                "text/html",
                "UTF-8",
                null
            )
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            getPreferences(MODE_PRIVATE).edit()
                .putString("html", editor.text.toString())
                .apply()
            Toast.makeText(this, "Project saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            showSettings()
        }

        findViewById<Button>(R.id.buildButton).setOnClickListener {
            buildApk()
        }

        getPreferences(MODE_PRIVATE).getString("html", null)?.let {
            editor.setText(it)
        }
    }

    private fun showSettings() {
        val box = EditText(this)
        box.setText("$appName\n$packageNameValue\n$versionName")
        box.hint = "App name\\nPackage name\\nVersion"
        AlertDialog.Builder(this)
            .setTitle("Project Settings")
            .setMessage("Enter one value per line:\n1. App name\n2. Package name\n3. Version")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val parts = box.text.toString().lines()
                if (parts.isNotEmpty() && parts[0].isNotBlank()) appName = parts[0].trim()
                if (parts.size > 1 && parts[1].isNotBlank()) packageNameValue = parts[1].trim()
                if (parts.size > 2 && parts[2].isNotBlank()) versionName = parts[2].trim()
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildApk() {
        // MVP workflow: export the HTML project for the build backend.
        // Actual Android APK compilation requires a build toolchain/server.
        val html = editor.text.toString()
        if (html.isBlank()) {
            Toast.makeText(this, "Add HTML first", Toast.LENGTH_SHORT).show()
            return
        }

        getPreferences(MODE_PRIVATE).edit()
            .putString("html", html)
            .putString("appName", appName)
            .putString("packageName", packageNameValue)
            .putString("versionName", versionName)
            .apply()

        AlertDialog.Builder(this)
            .setTitle("Build APK")
            .setMessage(
                "Project is ready for APK compilation. " +
                "This Android client saves the HTML and project settings; " +
                "connect a build backend to compile and return the APK."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
