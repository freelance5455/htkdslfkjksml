# Build backend contract

POST /v1/build
Content-Type: multipart/form-data

Fields:
- project.zip
- appName
- packageName
- versionName

Response:
{
  "jobId": "...",
  "status": "queued"
}

GET /v1/build/{jobId}

Response when complete:
{
  "status": "complete",
  "apkUrl": "https://example.invalid/apk/..."
}

The backend must sandbox uploaded HTML/JS and use a controlled Android build image.
