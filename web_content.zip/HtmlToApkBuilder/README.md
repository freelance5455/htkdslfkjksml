# HTML to APK Builder

Android Studio starter project for:

HTML -> Editor -> Preview -> Project Settings -> Build APK workflow.

## Current MVP
- Paste/edit HTML
- Import an HTML file
- Live WebView preview
- Save project locally
- App name/package/version settings
- Build workflow UI

## APK compilation architecture
The Android client intentionally does not ship a complete Android SDK/Gradle/JDK build
toolchain. The `buildApk()` function is the integration point for a backend.

Recommended production flow:

1. Android app creates a project ZIP containing `index.html` and metadata.
2. Upload ZIP to a build server over HTTPS.
3. Server validates/sandboxes the project.
4. Server creates a temporary Android WebView wrapper.
5. Server runs Gradle and signs the APK with an app-specific signing key.
6. Server returns an APK download URL.
7. Android app downloads the APK and offers the user the Android package installer.

For a fully offline builder, a much larger on-device toolchain is required.
