/* Runs before first paint so the page never flashes the wrong theme. */
(function () {
  try {
    var pref = 'system';
    var raw = localStorage.getItem('tornado.settings');
    if (raw) pref = (JSON.parse(raw) || {}).theme || 'system';
    var dark = pref === 'dark' || (pref !== 'light' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', dark ? '#07161A' : '#F1FBF8');
  } catch (e) { /* storage blocked: keep the default light theme */ }
})();
