import { $, $$, h, uid, debounce, copyText } from './lib/dom.js';
import { hydrateIcons, icon, setIcon } from './lib/icons.js';
import { getSettings, updateSettings, onSettings, applyTheme, resolvedTheme } from './lib/settings.js';
import * as store from './lib/storage.js';
import { streamChat, fetchConfig, ApiError } from './lib/api.js';
import { renderMarkdown, hasMath } from './lib/markdown.js';
import { createStreamRenderer } from './lib/stream-md.js';
import { makeTitle } from './lib/title.js';
import { groupLabel } from './lib/format.js';

applyTheme();
hydrateIcons();

/* --------------------------------------------------------------- app bar height (mobile keyboard safe) */

function setAppHeight() {
  document.documentElement.style.setProperty('--app-h', `${window.innerHeight}px`);
}
setAppHeight();
window.addEventListener('resize', setAppHeight);
if (window.visualViewport) window.visualViewport.addEventListener('resize', setAppHeight);

/* --------------------------------------------------------------------- state */

const els = {
  app: $('#app'),
  sidebar: $('#sidebar'),
  scrim: $('#scrim'),
  chatList: $('#chat-list'),
  search: $('#chat-search'),
  chat: $('#chat'),
  chatInner: $('#chat-inner'),
  jump: $('#jump'),
  composer: $('#composer'),
  prompt: $('#prompt'),
  send: $('#send'),
  stop: $('#stop'),
  charCount: $('#char-count'),
  fineprint: $('#fineprint'),
  brandLogo: $('#brand-logo'),
  themeIcon: $('#theme-icon'),
  toasts: $('#toasts'),
  srStatus: $('#sr-status'),
  settingsDialog: $('#settings-dialog'),
  confirmDialog: $('#confirm-dialog'),
};

let chats = [];                    // metadata rows, newest first
let currentId = null;
const messagesById = new Map();    // chatId -> [{id, role, content, error?}], survives switching chats
let generating = false;            // is a request in flight for the current chat?
let abortCtrl = null;
let genForId = null;               // which chat the in-flight request belongs to
let maxMessageChars = 8000;
let backendReady = true;
let visibleCount = 24;       // messages rendered at once (older ones behind "Show earlier")

const RENDER_STEP = 24;

/* messages of the chat currently on screen (always messagesById.get(currentId)) */
function cm() {
  return messagesById.get(currentId) || [];
}
function setCm(arr) {
  messagesById.set(currentId, arr);
}

/* ------------------------------------------------------------------ toasts */

function toast(message, { type = 'info', timeout = 4000 } = {}) {
  const el = h('div', { class: `toast ${type === 'error' ? 'error' : ''}`.trim() }, message);
  els.toasts.append(el);
  els.srStatus.textContent = message;
  setTimeout(() => {
    el.style.transition = 'opacity .2s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 220);
  }, timeout);
}

/* -------------------------------------------------------------- sidebar UI */

function isMobile() {
  return window.matchMedia('(max-width: 820px)').matches;
}

function setSidebar(open, { persist = true } = {}) {
  els.app.dataset.sidebar = open ? 'open' : 'closed';
  $('#btn-history').setAttribute('aria-expanded', String(open));
  els.scrim.hidden = !(open && isMobile());
  if (persist && !isMobile()) updateSettings({ sidebarOpen: open });
}

$('#btn-history').addEventListener('click', () => setSidebar(els.app.dataset.sidebar !== 'open'));
$('#sidebar-close').addEventListener('click', () => setSidebar(false));
els.scrim.addEventListener('click', () => setSidebar(false));
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && isMobile() && els.app.dataset.sidebar === 'open') setSidebar(false);
});

setSidebar(isMobile() ? false : getSettings().sidebarOpen, { persist: false });

function closeSidebarOnMobileNavigate() {
  if (isMobile()) setSidebar(false);
}

/* ---------------------------------------------------------------- rendering: chat list */

let searchQuery = '';
let searchMatches = null; // Map id->snippet, or null when not searching
let searchToken = 0;

const runSearch = debounce(async (q) => {
  const token = ++searchToken;
  if (!q.trim()) {
    searchMatches = null;
    renderChatList();
    return;
  }
  const matches = await store.searchMessages(q, { isCancelled: () => token !== searchToken });
  if (token !== searchToken) return;
  searchMatches = matches;
  renderChatList();
}, 220);

els.search.addEventListener('input', () => {
  searchQuery = els.search.value;
  runSearch(searchQuery);
});

function matchesTitle(chat, q) {
  return chat.title.toLowerCase().includes(q.toLowerCase());
}

function highlightText(text, q) {
  if (!q) return [text];
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return [text];
  return [text.slice(0, i), h('mark', {}, text.slice(i, i + q.length)), text.slice(i + q.length)];
}

function renderChatList() {
  els.chatList.replaceChildren();
  const q = searchQuery.trim();

  let rows = chats;
  if (q) {
    rows = chats.filter((c) => matchesTitle(c, q) || (searchMatches && searchMatches.has(c.id)));
  }

  if (!rows.length) {
    els.chatList.append(h('p', { class: 'list-empty' }, q ? 'No matching chats.' : 'No chats yet. Say hello!'));
    return;
  }

  if (q) {
    for (const c of rows) els.chatList.append(chatItem(c, q));
    return;
  }

  let lastGroup = null;
  for (const c of rows) {
    const g = groupLabel(c.updatedAt);
    if (g !== lastGroup) {
      els.chatList.append(h('div', { class: 'group-label' }, g));
      lastGroup = g;
    }
    els.chatList.append(chatItem(c, ''));
  }
}

function chatItem(c, q) {
  const isActive = c.id === currentId;
  const isBusy = c.id === genForId && generating;
  const snippet = searchMatches && searchMatches.get(c.id);

  const openBtn = h(
    'button',
    { class: 'chat-open', type: 'button', title: c.title, onClick: () => openChat(c.id) },
    h('span', { class: 'chat-title' }, ...highlightText(c.title, q)),
    (snippet || c.lastMessage) ? h('span', { class: 'chat-snippet' }, ...highlightText(snippet || c.lastMessage, q)) : null
  );

  const item = h(
    'div',
    { class: `chat-item${isActive ? ' active' : ''}`, dataset: { id: c.id } },
    isBusy ? h('span', { class: 'chat-busy', 'aria-hidden': 'true' }) : null,
    openBtn,
    h(
      'div',
      { class: 'chat-actions' },
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': `Rename ${c.title}`, title: 'Rename', onClick: (e) => startRename(item, c, e) }, h('span', { html: icon('pencil') })),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': `Delete ${c.title}`, title: 'Delete', onClick: () => confirmDeleteChat(c) }, h('span', { html: icon('trash') }))
    )
  );
  return item;
}

function startRename(itemEl, chat, evt) {
  evt.stopPropagation();
  const openBtn = $('.chat-open', itemEl);
  const input = h('input', { class: 'rename-input', type: 'text', value: chat.title, maxlength: '80', 'aria-label': 'Chat title' });
  openBtn.replaceWith(input);
  input.focus();
  input.select();

  let done = false;
  const commit = async () => {
    if (done) return;
    done = true;
    const next = input.value.trim().slice(0, 80) || chat.title;
    if (next !== chat.title) {
      chat.title = next;
      chat.updatedAt = Date.now();
      await store.saveMeta(chat);
    }
    renderChatList();
  };
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      input.blur();
    } else if (e.key === 'Escape') {
      done = true;
      renderChatList();
    }
  });
  input.addEventListener('blur', commit);
}

function confirmDeleteChat(chat) {
  openConfirm({
    title: 'Delete this chat?',
    text: `"${chat.title}" will be permanently deleted from this device.`,
    confirmLabel: 'Delete',
    onConfirm: async () => {
      if (chat.id === genForId && generating) stopGenerating();
      await store.deleteChat(chat.id);
      messagesById.delete(chat.id);
      chats = chats.filter((c) => c.id !== chat.id);
      renderChatList();
      if (chat.id === currentId) await startNewChat({ persistPrevious: false });
      toast('Chat deleted.');
    },
  });
}

/* -------------------------------------------------------------- confirm dialog */

let confirmAction = null;

function openConfirm({ title, text, confirmLabel = 'Delete', onConfirm }) {
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  $('#confirm-ok').textContent = confirmLabel;
  confirmAction = onConfirm;
  els.confirmDialog.showModal();
}
$('#confirm-cancel').addEventListener('click', () => els.confirmDialog.close());
$('#confirm-ok').addEventListener('click', async () => {
  const fn = confirmAction;
  els.confirmDialog.close();
  if (fn) await fn();
});
els.confirmDialog.addEventListener('cancel', () => { confirmAction = null; });

/* --------------------------------------------------------------------- new chat / open chat */

function newChatMeta() {
  const now = Date.now();
  return { id: uid('chat'), title: 'New chat', createdAt: now, updatedAt: now, lastMessage: '' };
}

async function startNewChat({ persistPrevious = true, focus = true } = {}) {
  if (persistPrevious) await persistCurrent();
  const meta = newChatMeta();
  currentId = meta.id;
  setCm([]);
  visibleCount = RENDER_STEP;
  renderMessages();
  renderChatList();
  closeSidebarOnMobileNavigate();
  if (focus && !isMobile()) els.prompt.focus();
  updateComposerState();
}

async function persistChat(id, messages) {
  if (!id || !messages.length) return;
  let meta = chats.find((c) => c.id === id);
  if (!meta) {
    meta = newChatMeta();
    meta.id = id;
    chats.unshift(meta);
  }
  const firstUser = messages.find((m) => m.role === 'user');
  if (firstUser && meta.title === 'New chat') meta.title = makeTitle(firstUser.content);
  const lastReal = [...messages].reverse().find((m) => m.content && !m.error);
  meta.lastMessage = lastReal ? lastReal.content.slice(0, 140) : meta.lastMessage;
  meta.updatedAt = Date.now();
  await store.saveChat(meta, stripTransient(messages));
}

async function persistCurrent() {
  if (!currentId) return;
  await persistChat(currentId, cm());
}

function stripTransient(messages) {
  return messages.map(({ id, role, content, error, finishReason }) => ({ id, role, content, error: error || undefined, finishReason: finishReason || undefined }));
}

async function openChat(id) {
  if (id === currentId) {
    closeSidebarOnMobileNavigate();
    return;
  }
  await persistCurrent();
  currentId = id;
  if (!messagesById.has(id)) {
    const loaded = (await store.getMessages(id)).map((m) => ({ ...m, id: m.id || uid('m') }));
    messagesById.set(id, loaded);
  }
  visibleCount = RENDER_STEP;
  renderMessages();
  renderChatList();
  closeSidebarOnMobileNavigate();
  requestAnimationFrame(() => scrollToBottom(false));
}

$('#btn-new').addEventListener('click', () => startNewChat());
$('#sidebar-new').addEventListener('click', () => startNewChat());

/* --------------------------------------------------------------------- message rendering */

const EXAMPLE_PROMPTS = [
  'Explain a difficult topic simply',
  'Help me with mathematics',
  'Write something for me',
  'Help me learn programming',
  'Give me ideas',
];

function renderMessages() {
  els.chatInner.replaceChildren();
  const messages = cm();

  if (!messages.length) {
    els.chatInner.append(welcomeScreen());
    updateComposerState();
    return;
  }

  const total = messages.length;
  const start = Math.max(0, total - visibleCount);
  if (start > 0) {
    els.chatInner.append(
      h('button', { class: 'earlier', type: 'button', onClick: () => { visibleCount += RENDER_STEP; renderMessages(); } }, `Show ${Math.min(RENDER_STEP, start)} earlier messages`)
    );
  }
  for (let i = start; i < total; i++) {
    const m = messages[i];
    els.chatInner.append(m.role === 'user' ? userBubble(m) : aiBubble(m, i === total - 1));
  }
  updateComposerState();
}

function welcomeScreen() {
  return h(
    'div',
    { class: 'welcome' },
    h('img', { class: 'welcome-logo', src: '/assets/logo-96.png', alt: '', width: '88', height: '88' }),
    h('h1', {}, 'Hello! \u{1F44B}'),
    h('p', {}, 'How can I help you today?'),
    h(
      'ul',
      { class: 'chips' },
      ...EXAMPLE_PROMPTS.map((p) => h('li', {}, h('button', { class: 'chip', type: 'button', onClick: () => useExample(p) }, p)))
    )
  );
}

function useExample(text) {
  els.prompt.value = text;
  autoSizePrompt();
  updateComposerState();
  els.prompt.focus();
  const end = els.prompt.value.length;
  els.prompt.setSelectionRange(end, end);
}

function userBubble(m) {
  return h(
    'div',
    { class: 'msg user', dataset: { id: m.id } },
    h('div', { class: 'msg-col' }, h('div', { class: 'bubble user-bubble' }, m.content))
  );
}

function aiBubble(m, isLast) {
  const mdWrap = h('div', { class: 'md' });
  if (m.content) mdWrap.innerHTML = renderMarkdown(m.content);

  if (m.pending) {
    // A full rebuild happened while this message was still streaming (e.g. the
    // page re-rendered after KaTeX finished loading). Show it as "in
    // progress" - no action buttons yet - and let the in-flight stream keep
    // writing into this fresh node (see the remount handling in runGeneration).
    if (!m.content) mdWrap.append(h('span', { class: 'dots', 'aria-label': 'Tornado is thinking' }, h('i'), h('i'), h('i')));
    else mdWrap.append(h('span', { class: 'cursor', 'aria-hidden': 'true' }));
    const col = h('div', { class: 'msg-col' }, mdWrap);
    return h(
      'div',
      { class: `msg ai streaming${isLast ? ' last' : ''}`, dataset: { id: m.id } },
      h('img', { class: 'avatar', src: '/assets/logo-64.png', alt: '', width: '32', height: '32' }),
      col
    );
  }

  const col = h('div', { class: 'msg-col' }, mdWrap);
  if (m.error) col.append(errorBox(m));
  if (!m.error && (m.content || m.finishReason)) col.append(messageActions(m));

  return h(
    'div',
    { class: `msg ai${isLast ? ' last' : ''}`, dataset: { id: m.id } },
    h('img', { class: 'avatar', src: '/assets/logo-64.png', alt: '', width: '32', height: '32' }),
    col
  );
}

function errorBox(m) {
  return h(
    'div',
    { class: 'error-box' },
    h('span', { html: icon('alert') }),
    h('p', {}, m.error),
    h('button', { type: 'button', onClick: () => regenerate(m.id) }, 'Try again')
  );
}

function messageActions(m) {
  const copyIconWrap = h('span', { html: icon('copy') });
  const copyBtn = h(
    'button',
    { class: 'act', type: 'button', title: 'Copy', 'aria-label': 'Copy response' },
    copyIconWrap,
    h('span', { class: 'act-label' }, 'Copy')
  );
  copyBtn.addEventListener('click', async () => {
    const ok = await copyText(m.content);
    if (ok) {
      copyIconWrap.innerHTML = icon('check');
      copyBtn.classList.add('done');
      toast('Copied!');
      setTimeout(() => {
        copyIconWrap.innerHTML = icon('copy');
        copyBtn.classList.remove('done');
      }, 1500);
    } else {
      toast('Could not copy. Please copy manually.', { type: 'error' });
    }
  });

  const regenBtn = h(
    'button',
    { class: 'act', type: 'button', title: 'Regenerate', 'aria-label': 'Regenerate response', onClick: () => regenerate(m.id) },
    h('span', { html: icon('refresh') }),
    h('span', { class: 'act-label' }, 'Regenerate')
  );

  const delBtn = h(
    'button',
    { class: 'act danger', type: 'button', title: 'Delete', 'aria-label': 'Delete response', onClick: () => deleteMessage(m.id) },
    h('span', { html: icon('trash') }),
    h('span', { class: 'act-label' }, 'Delete')
  );

  return h('div', { class: 'actions' }, copyBtn, regenBtn, delBtn);
}

async function deleteMessage(id) {
  const messages = cm();
  const idx = messages.findIndex((m) => m.id === id);
  if (idx < 0) return;
  messages.splice(idx, 1);
  renderMessages();
  await persistCurrent();
}

/* --------------------------------------------------------------------- scrolling */

function nearBottom() {
  return els.chat.scrollHeight - els.chat.scrollTop - els.chat.clientHeight < 80;
}

function scrollToBottom(smooth = true) {
  els.chat.scrollTo({ top: els.chat.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
}

els.chat.addEventListener('scroll', () => {
  els.jump.hidden = nearBottom();
});

els.jump.addEventListener('click', () => scrollToBottom());

/* --------------------------------------------------------------------- composer */

function autoSizePrompt() {
  els.prompt.style.height = 'auto';
  els.prompt.style.height = Math.min(200, els.prompt.scrollHeight) + 'px';
}

function updateComposerState() {
  const len = els.prompt.value.length;
  const over = len > maxMessageChars;
  els.charCount.hidden = len < Math.max(1, maxMessageChars - 400);
  els.charCount.textContent = `${len.toLocaleString()} / ${maxMessageChars.toLocaleString()}`;
  els.charCount.classList.toggle('over', over);
  els.send.disabled = generating || !els.prompt.value.trim() || over;
  els.send.hidden = generating && currentId === genForId;
  els.stop.hidden = !(generating && currentId === genForId);
  els.fineprint.textContent = !backendReady
    ? 'Tornado is not set up yet. Please contact the site owner.'
    : over
      ? 'Your message is too long.'
      : 'Tornado can make mistakes. Check important information.';
}

els.prompt.addEventListener('input', () => {
  autoSizePrompt();
  updateComposerState();
});

els.prompt.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter' || e.isComposing) return;
  const { enterToSend } = getSettings();
  const wantsSend = enterToSend ? !e.shiftKey : e.ctrlKey || e.metaKey;
  if (!wantsSend) return;
  e.preventDefault();
  if (!els.send.disabled) els.composer.requestSubmit();
});

els.composer.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = els.prompt.value.trim();
  if (!text || generating) return;
  els.prompt.value = '';
  autoSizePrompt();
  updateComposerState();
  sendMessage(text);
});

els.stop.addEventListener('click', () => stopGenerating());

/* --------------------------------------------------------------------- send / stream */

async function sendMessage(text) {
  if (!currentId) await startNewChat({ persistPrevious: false, focus: false });
  const userMsg = { id: uid('m'), role: 'user', content: text };
  cm().push(userMsg);
  renderMessages();
  scrollToBottom();
  await runGeneration();
}

async function regenerate(assistantId) {
  if (generating) return;
  const messages = cm();
  const idx = messages.findIndex((m) => m.id === assistantId);
  if (idx < 0) return;
  // Drop this reply and anything after it, then ask again from the same point.
  setCm(messages.slice(0, idx));
  renderMessages();
  await runGeneration();
}

function contextFor(messages) {
  return messages.filter((m) => m.content && !m.error).map(({ role, content }) => ({ role, content }));
}

async function runGeneration() {
  const chatId = currentId;
  const messages = messagesById.get(chatId); // fixed reference: survives the user switching chats mid-stream
  const priorMessages = contextFor(messages);
  const assistantMsg = { id: uid('m'), role: 'assistant', content: '', pending: true };
  messages.push(assistantMsg);

  generating = true;
  genForId = chatId;
  abortCtrl = new AbortController();

  renderMessages();
  scrollToBottom();
  updateComposerState();
  renderChatList();
  setLogoSpin(true);

  let bubbleInfo = mountAssistantBubble(assistantMsg.id);
  let firstToken = true;
  let shown = false;

  try {
    const { finishReason } = await streamChat({
      conversationId: chatId,
      messages: priorMessages,
      signal: abortCtrl.signal,
      onToken: (text) => {
        assistantMsg.content += text;
        if (chatId !== currentId) return; // user switched chats: keep buffering data, skip DOM
        if (!getSettings().streaming) return; // Streaming is off: reveal the full reply only once it's done.
        // The DOM may have been torn down and rebuilt (user switched away and
        // back to this chat while it was still generating) - remount if so.
        if (!bubbleInfo.el || !bubbleInfo.el.isConnected) {
          bubbleInfo = mountAssistantBubble(assistantMsg.id);
          shown = false;
          if (assistantMsg.content) {
            bubbleInfo.showContent();
            shown = true;
            bubbleInfo.renderer.push(assistantMsg.content);
          }
        }
        if (firstToken || !shown) {
          firstToken = false;
          shown = true;
          bubbleInfo.showContent();
        }
        bubbleInfo.renderer.push(text);
        if (nearBottom()) scrollToBottom(false);
      },
    });
    assistantMsg.finishReason = finishReason;
    finalizeAssistantBubble(bubbleInfo, assistantMsg, chatId);
  } catch (err) {
    if (err && err.name === 'AbortError') {
      assistantMsg.stoppedByUser = true;
      finalizeAssistantBubble(bubbleInfo, assistantMsg, chatId, { stopped: true });
    } else {
      const message = err instanceof ApiError ? err.message : 'Something went wrong. Please try again.';
      if (assistantMsg.content) {
        assistantMsg.error = message;
        finalizeAssistantBubble(bubbleInfo, assistantMsg, chatId, { error: message, keepContent: true });
      } else {
        const idx = messages.indexOf(assistantMsg);
        if (idx >= 0) messages.splice(idx, 1);
        const errMsg = { id: uid('m'), role: 'assistant', content: '', error: message };
        messages.push(errMsg);
        if (chatId === currentId) renderMessages();
      }
      toast(message, { type: 'error' });
    }
  } finally {
    generating = false;
    genForId = null;
    abortCtrl = null;
    if (chatId === currentId) {
      setLogoSpin(false);
      updateComposerState();
    }
    await persistChat(chatId, messages);
    renderChatList();
  }
}

function mountAssistantBubble(id) {
  const msgEl = $(`.msg[data-id="${CSS.escape(id)}"]`);
  if (!msgEl) return { renderer: { push() {}, flush: () => '' }, showContent() {} };
  const mdWrap = $('.md', msgEl);
  mdWrap.replaceChildren(); // clear any placeholder (dots/cursor/partial content) from a mid-stream rebuild
  const dots = h('span', { class: 'dots', 'aria-label': 'Tornado is thinking' }, h('i'), h('i'), h('i'));
  mdWrap.append(dots);
  const renderer = createStreamRenderer(mdWrap);
  const cursor = h('span', { class: 'cursor', 'aria-hidden': 'true' });

  return {
    renderer,
    showContent() {
      dots.remove();
      mdWrap.append(cursor);
      msgEl.classList.add('streaming');
    },
    el: msgEl,
    mdWrap,
    cursor,
  };
}

function finalizeAssistantBubble(info, msg, chatId, { stopped = false, error = null, keepContent = false } = {}) {
  delete msg.pending;
  if (chatId !== currentId) return; // nothing on screen to finish
  info.cursor?.remove();
  info.el?.classList.remove('streaming');
  if (info.mdWrap) info.mdWrap.innerHTML = renderMarkdown(msg.content);

  if (error && !keepContent) return;

  const col = info.el ? $('.msg-col', info.el) : null;
  if (!col) return;
  // Defensive: never leave two footers on one message, no matter how we got here.
  col.querySelectorAll('.actions, .error-box, .stopped-note').forEach((n) => n.remove());
  if (stopped && msg.content) {
    col.append(h('p', { class: 'stopped-note' }, 'Generation stopped.'));
  }
  if (error) {
    col.append(errorBox(msg));
  } else if (msg.content) {
    col.append(messageActions(msg));
  }
}

function stopGenerating() {
  if (abortCtrl) abortCtrl.abort();
}

function setLogoSpin(spinning) {
  els.brandLogo.classList.toggle('spin', spinning);
}

/* --------------------------------------------------------------------- theme */

function refreshThemeIcon() {
  setIcon(els.themeIcon, resolvedTheme() === 'dark' ? 'sun' : 'moon');
}

$('#btn-theme').addEventListener('click', () => {
  const next = resolvedTheme() === 'dark' ? 'light' : 'dark';
  updateSettings({ theme: next });
});

onSettings(() => {
  applyTheme();
  refreshThemeIcon();
  syncSettingsDialog();
});
refreshThemeIcon();

/* --------------------------------------------------------------------- settings dialog */

function openSettings() {
  syncSettingsDialog();
  els.settingsDialog.showModal();
  closeSidebarOnMobileNavigate();
}
$('#btn-settings').addEventListener('click', openSettings);
$('#sidebar-settings').addEventListener('click', openSettings);
$('#settings-close').addEventListener('click', () => els.settingsDialog.close());
els.settingsDialog.addEventListener('click', (e) => {
  if (e.target === els.settingsDialog) els.settingsDialog.close();
});

function syncSettingsDialog() {
  const s = getSettings();
  for (const btn of $$('#theme-choice [data-theme-value]')) {
    btn.setAttribute('aria-checked', String(btn.dataset.themeValue === s.theme));
  }
  $('#sw-enter').setAttribute('aria-checked', String(s.enterToSend));
  $('#sw-stream').setAttribute('aria-checked', String(s.streaming));
}

for (const btn of $$('#theme-choice [data-theme-value]')) {
  btn.addEventListener('click', () => updateSettings({ theme: btn.dataset.themeValue }));
}
$('#sw-enter').addEventListener('click', (e) => updateSettings({ enterToSend: e.currentTarget.getAttribute('aria-checked') !== 'true' }));
$('#sw-stream').addEventListener('click', (e) => updateSettings({ streaming: e.currentTarget.getAttribute('aria-checked') !== 'true' }));

$('#btn-clear-all').addEventListener('click', () => {
  openConfirm({
    title: 'Clear all chat history?',
    text: 'This deletes every chat stored in this browser. This cannot be undone.',
    confirmLabel: 'Clear all',
    onConfirm: async () => {
      if (generating) stopGenerating();
      await store.clearAll();
      chats = [];
      messagesById.clear();
      els.settingsDialog.close();
      await startNewChat({ persistPrevious: false });
      toast('All chat history cleared.');
    },
  });
});

/* --------------------------------------------------------------------- keyboard shortcuts */

document.addEventListener('keydown', (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.shiftKey && e.key.toLowerCase() === 'o') {
    e.preventDefault();
    startNewChat();
  }
});

/* --------------------------------------------------------------------- warn before leaving mid-stream */

window.addEventListener('beforeunload', (e) => {
  if (generating) {
    e.preventDefault();
    e.returnValue = '';
  }
});

/* --------------------------------------------------------------------- math (KaTeX), loaded lazily */

let katexPromise = null;
function injectKatex() {
  if (katexPromise) return katexPromise;
  katexPromise = new Promise((resolve) => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = '/vendor/katex/katex.min.css';
    document.head.append(link);
    const script = document.createElement('script');
    script.src = '/vendor/katex/katex.min.js';
    script.onload = () => {
      renderMessages(); // re-render so any math already on screen uses KaTeX
      resolve(true);
    };
    script.onerror = () => resolve(false);
    document.head.append(script);
  });
  return katexPromise;
}

/* --------------------------------------------------------------------- boot */

async function boot() {
  await store.initStorage();
  chats = await store.listChats();
  renderChatList();

  const cfg = await fetchConfig();
  if (cfg) {
    maxMessageChars = cfg.maxMessageChars || maxMessageChars;
    backendReady = cfg.ready !== false;
    if (!backendReady) toast('Tornado is not set up yet. The site owner needs to add a Gemini API key.', { type: 'error', timeout: 8000 });
  }

  if (chats.length) {
    await openChat(chats[0].id);
  } else {
    await startNewChat({ persistPrevious: false, focus: false });
  }
  updateComposerState();

  if (cm().some((m) => m.content && hasMath(m.content))) injectKatex();
}

boot().catch((err) => {
  console.error(err);
  toast('Something went wrong while starting Tornado.', { type: 'error' });
});

// Load KaTeX proactively, quietly, after first paint (cheap and cached), so
// math typed later renders instantly without a mid-stream flash.
window.addEventListener('load', () => setTimeout(() => injectKatex(), 1200));
