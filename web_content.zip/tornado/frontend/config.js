/*
 * Public frontend settings. Nothing secret ever goes in this file.
 *
 * apiBase: leave empty when this frontend is served by the Tornado backend
 * (the default). Only set it if you host the frontend on a different domain,
 * e.g. "https://api.example.com" - then also set CORS_ORIGIN on the backend.
 */
window.TORNADO_CONFIG = { apiBase: '' };
