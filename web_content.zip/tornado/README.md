# Tornado

Tornado is a real, working AI chatbot backed by the Google Gemini API. Visitors
never see an API key field - they just open the app and start chatting. The
Gemini key lives only on the server, set once by whoever deploys Tornado.

```
Browser  --->  Tornado backend (Node.js, no framework)  --->  Google Gemini API
              (holds the API key, rate-limits, streams the reply back)
```

- **Frontend**: plain HTML/CSS/JS (no build step, no framework) in `frontend/`
- **Backend**: a small Node.js HTTP server in `backend/`, using only Node's
  built-in `http` module and the global `fetch` - no Express, no dependencies
  to install, nothing to compile
- **Chat history**: stored in the visitor's own browser (IndexedDB), not on
  the server - there is no database to run

---

## 1. Install

Tornado has **zero npm dependencies** for running the app itself (the test
suite uses only Node's built-in test runner too). You need Node.js 20 or
newer.

```bash
node -v        # should print v20.x or higher
```

That's it - there is nothing to `npm install` to run Tornado.

## 2. Configure your Gemini API key

1. Get a key from [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Copy the example environment file:
   ```bash
   cp .env.example .env
   ```
3. Open `.env` and set:
   ```
   GEMINI_API_KEY=paste-your-real-key-here
   ```

`.env` is listed in `.gitignore` - it will never be committed. The key is
read once, on the server, by `backend/config.js`, and is never sent to the
browser, logged, or exposed in any API response (see [Security](#7-security)).

## 3. Run the backend

```bash
npm start
```

This starts the server (default `http://localhost:3000`) and **also serves
the frontend** - so opening `http://localhost:3000` in your browser gives you
the full chat app. There is no separate frontend server to run.

For local development with auto-restart, use any file watcher you like, e.g.:

```bash
node --watch backend/server.js
```

## 4. Run the frontend

Nothing separate to run - step 3 already serves `frontend/` at `/`. If you
ever want to host the frontend on a different domain (e.g. a static CDN)
instead, see [`SERVE_FRONTEND` and `CORS_ORIGIN`](#6-configure-rate-limits-and-other-options)
in the environment variables below.

## 5. Deploy

Tornado is a single Node.js process with no database, so it runs on almost
any platform that runs Node: Render, Railway, Fly.io, a VPS, a Docker
container, etc.

1. Push this project to your host (or build a container - there's no
   Dockerfile bundled, but a minimal one is just `FROM node:20-slim`, copy the
   repo, `CMD ["node", "backend/server.js"]`).
2. Set `GEMINI_API_KEY` (and any other variables you want to override) as
   **environment variables / secrets in your hosting platform's dashboard** -
   never in a committed file.
3. Set `PORT` if your platform requires a specific port (most platforms set
   this for you automatically).
4. If your platform sits behind a reverse proxy/load balancer (true for
   almost all PaaS hosts), set `TRUST_PROXY_HOPS=1` so rate limiting sees the
   visitor's real IP instead of the proxy's IP.
5. Start command: `npm start` (or `node backend/server.js`).

Tornado uses Node's built-in HTTPS-forwarding awareness only through
`TRUST_PROXY_HOPS`; TLS termination itself is handled by your platform (or by
a reverse proxy like Nginx/Caddy if you're deploying to a bare VPS). Always
run production traffic over HTTPS.

## 6. Configure rate limits and other options

Everything is controlled by environment variables - see the fully-commented
[`​.env.example`](.env.example) for the complete list with explanations.
The most relevant ones:

| Variable | Default | What it does |
|---|---|---|
| `GEMINI_API_KEY` | *(required)* | Your server-side Gemini key. |
| `GEMINI_MODEL` | `gemini-flash-latest` | Which Gemini model to call. `gemini-flash-latest` is a Google-maintained alias that always points at the current Flash model, so you never have to update it as Google ships new versions. Pin an exact name (e.g. `gemini-2.5-flash`) if you need stable behaviour instead. |
| `RATE_LIMIT_MAX_REQUESTS` / `RATE_LIMIT_WINDOW_MS` | 20 / 60s | Per-visitor sliding-window limit. |
| `RATE_LIMIT_DAILY_MAX` | 400 | Per-visitor daily cap. |
| `MAX_CONCURRENT_PER_IP` / `MAX_CONCURRENT_GLOBAL` | 2 / 60 | Caps on simultaneous streams, per visitor and server-wide. |
| `MAX_MESSAGE_CHARS` | 8000 | Longest single message a visitor can send. |
| `CONTEXT_MAX_CHARS` | 48000 | How much conversation history is sent to Gemini per request (older turns are trimmed automatically). |
| `TRUST_PROXY_HOPS` | 0 | Set to `1` behind a typical PaaS load balancer. |
| `CORS_ORIGIN` | *(empty)* | Only needed if the frontend is hosted on a different domain than the backend. |

Since everyone who visits Tornado shares your Gemini quota and your bill, the
defaults are deliberately conservative - raise them if you have your own
higher quota and expect legitimate heavy use.

## 7. Security

- The Gemini API key exists only in `backend/config.js`, loaded from the
  `GEMINI_API_KEY` environment variable. It is attached to Gemini requests via
  an HTTP header (`x-goog-api-key`), never a URL query string, so it can't leak
  through browser history, proxy logs, or the Referer header.
- `/api/config` (the only endpoint the frontend calls to learn about the
  server) returns just `{ appName, maxMessageChars, ready }` - `ready` is a
  boolean, never the key itself.
- Server logs (`backend/utils/logger.js`) redact the key and any
  `AIza...`-shaped string before writing anything out, so it can never end up
  in your log aggregator by accident.
- A strict `Content-Security-Policy` (same-origin scripts only, no
  `unsafe-inline`, no `eval`) is sent on every response, so even a rendering
  bug can't be turned into script execution.
- All Markdown from the model is rendered through a small sanitizing renderer
  (`frontend/lib/markdown.js`) that HTML-escapes everything by construction -
  raw HTML in a reply is shown as text, never executed. `javascript:` links
  are rejected.
- Static file serving blocks path traversal and dotfiles, so `.env` can never
  be served even if it ended up inside `frontend/` by mistake.
- Per-IP and global rate limiting, request size limits, and message length
  limits protect the server (and your Gemini bill) from abuse.
- Run `npm test` any time you change the backend - the test suite includes
  dedicated checks that the API key never appears in any HTTP response,
  header, static file, or log line.

## 8. Change the Gemini model

Set the `GEMINI_MODEL` environment variable - no code changes needed:

```
GEMINI_MODEL=gemini-2.5-flash
```

The default, `gemini-flash-latest`, is a Google-maintained alias for
"whatever the current Flash model is", so most deployments never need to
touch this.

## 9. Configure rate limits

See the table in [step 6](#6-configure-rate-limits-and-other-options) and the
comments in [`.env.example`](.env.example). All limits are plain environment
variables - change them and restart the server, no code changes needed.

---

## Project structure

```
tornado/
├── frontend/               # plain HTML/CSS/JS, no build step
│   ├── index.html
│   ├── app.js               # app entry point
│   ├── config.js            # public, non-secret frontend settings
│   ├── theme-init.js        # runs before first paint (no theme flash)
│   ├── manifest.webmanifest
│   ├── lib/                 # markdown renderer, highlighter, storage, API client...
│   ├── styles/
│   ├── assets/               # logo, favicons
│   └── vendor/katex/          # vendored, self-hosted (no external CDN calls)
│
├── backend/
│   ├── server.js            # HTTP server / router
│   ├── config.js            # reads all environment variables
│   ├── routes/               # /api/chat, /api/config, /api/health, static files
│   ├── services/              # Gemini streaming client, context/history builder
│   ├── middleware/            # security headers, rate limiting, validation, auth stub
│   └── utils/                  # errors, redacting logger, client-IP resolution
│
├── tests/
│   ├── backend.test.js       # integration tests (run with `npm test`)
│   └── mock-gemini.js        # a fake Gemini server used by the tests
│
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## Notable behaviour

- **Streaming**: replies stream token-by-token over Server-Sent Events.
  Pressing **Stop** cancels both the browser request and the upstream Gemini
  request, and keeps whatever text already arrived.
- **Conversation memory**: each request sends recent history to Gemini so it
  remembers earlier turns in the same chat; very long chats are trimmed
  automatically (see `CONTEXT_MAX_CHARS`) while always keeping your latest
  message intact.
- **Chat history**: stored per-browser in IndexedDB (with an in-memory
  fallback for private-browsing modes that block it) - nothing chat-related
  is stored on the server. There's no login by default (see
  `backend/middleware/auth.js` for how to add accounts later; it's written as
  a clear extension point).
- **Markdown & code**: full Markdown rendering (tables, lists, quotes, links),
  syntax-highlighted code blocks with a **Copy code** button, and LaTeX math
  (`$...$` / `$$...$$`) via a vendored copy of KaTeX, loaded only when a
  conversation actually contains math.
- **Accessibility**: keyboard navigable, labelled controls, `aria-live`
  regions for streaming/toasts, and a `prefers-reduced-motion`-aware UI.

## Testing

```bash
npm test
```

Runs the backend integration test suite (`tests/backend.test.js`) against a
mock Gemini server (`tests/mock-gemini.js`), covering: streaming replies,
conversation memory, request validation, rate limiting (per-minute, daily,
and concurrency), Stop/cancellation, timeouts, upstream-error mapping, and -
importantly - that the API key never appears anywhere the browser can see it.

You can also run the mock Gemini server by hand to try Tornado without a real
API key:

```bash
npm run mock-gemini
# in another terminal:
GEMINI_API_KEY=test-secret-key-123 GEMINI_API_BASE=http://localhost:4010/v1beta npm start
```
