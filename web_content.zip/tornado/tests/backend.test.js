'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const { createMock, EXPECTED_KEY } = require('./mock-gemini');

const ROOT = path.resolve(__dirname, '..');

function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer().listen(0, () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

async function startApp(env = {}) {
  const mock = createMock();
  await new Promise((r) => mock.server.listen(0, r));
  const mockPort = mock.server.address().port;
  const port = await freePort();
  const child = spawn(process.execPath, [path.join(ROOT, 'backend', 'server.js')], {
    env: {
      PATH: process.env.PATH,
      PORT: String(port),
      HOST: '127.0.0.1',
      GEMINI_API_KEY: EXPECTED_KEY,
      GEMINI_API_BASE: `http://127.0.0.1:${mockPort}/v1beta`,
      GEMINI_FIRST_BYTE_TIMEOUT_MS: '3000',
      ...env,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let logs = '';
  child.stdout.on('data', (d) => (logs += d));
  child.stderr.on('data', (d) => (logs += d));
  await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('server did not start: ' + logs)), 5000);
    const iv = setInterval(() => {
      if (logs.includes('is running')) {
        clearTimeout(t);
        clearInterval(iv);
        resolve();
      }
    }, 20);
  });
  const base = `http://127.0.0.1:${port}`;
  return {
    base,
    mock,
    getLogs: () => logs,
    async stop() {
      child.kill('SIGTERM');
      await new Promise((r) => child.once('exit', r));
      mock.server.closeAllConnections?.();
      await new Promise((r) => mock.server.close(r));
    },
  };
}

/** POST /api/chat and collect the SSE events. */
async function chat(base, messages, { signal, conversationId = 'conv-1' } = {}) {
  const res = await fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ conversationId, messages }),
    signal,
  });
  const ctype = res.headers.get('content-type') || '';
  if (!ctype.includes('text/event-stream')) {
    return { status: res.status, headers: res.headers, json: await res.json(), text: '', events: [] };
  }
  const events = [];
  let text = '';
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n\n')) !== -1) {
      const raw = buf.slice(0, i);
      buf = buf.slice(i + 2);
      const ev = /^event: (.*)$/m.exec(raw)?.[1];
      const data = /^data: (.*)$/m.exec(raw)?.[1];
      if (!ev) continue;
      const parsed = JSON.parse(data);
      events.push({ event: ev, data: parsed });
      if (ev === 'token') text += parsed.t;
    }
  }
  return { status: res.status, headers: res.headers, events, text };
}

const U = (content) => ({ role: 'user', content });
const A = (content) => ({ role: 'assistant', content });

test('streams a reply and remembers the conversation', async () => {
  const app = await startApp();
  try {
    const r1 = await chat(app.base, [U('Hello')]);
    assert.equal(r1.status, 200);
    assert.match(r1.text, /Hello! I am a mock Gemini/);
    assert.ok(r1.events.filter((e) => e.event === 'token').length > 3, 'should arrive in several chunks');
    assert.equal(r1.events.at(-1).event, 'done');

    // The server key reaches Gemini only in a header, and the model gets the context
    const req = app.mock.state.requests.at(-1);
    assert.equal(req.headers['x-goog-api-key'], EXPECTED_KEY);
    assert.ok(!req.url.includes(EXPECTED_KEY), 'key must not be in the URL');

    const r2 = await chat(app.base, [U('My name is Rahim.'), A('Nice to meet you, Rahim!'), U('What is my name?')]);
    assert.equal(r2.text, 'Your name is Rahim.');
    assert.equal(app.mock.state.lastContents.length, 3);
    assert.equal(app.mock.state.lastContents[1].role, 'model');
  } finally {
    await app.stop();
  }
});

test('the API key is never present in any response or static file', async () => {
  const app = await startApp();
  try {
    const paths = ['/', '/index.html', '/app.js', '/api/config', '/api/health', '/api/nope', '/styles/main.css'];
    for (const p of paths) {
      const res = await fetch(app.base + p);
      const body = await res.text();
      assert.ok(!body.includes(EXPECTED_KEY), `${p} leaked the key`);
      for (const [k, v] of res.headers) assert.ok(!String(v).includes(EXPECTED_KEY), `${p} header ${k} leaked the key`);
    }
    const cfg = await (await fetch(app.base + '/api/config')).json();
    assert.deepEqual(Object.keys(cfg).sort(), ['appName', 'maxMessageChars', 'ready']);

    // The frontend folder must contain no key-shaped strings or key inputs
    const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? (e.name === 'vendor' ? [] : walk(path.join(d, e.name))) : [path.join(d, e.name)]));
    for (const f of walk(path.join(ROOT, 'frontend')).filter((f) => /\.(js|html|css)$/.test(f))) {
      const src = fs.readFileSync(f, 'utf8');
      assert.ok(!/AIza[0-9A-Za-z_-]{20,}/.test(src), `${f} contains a key-shaped string`);
      // The UI may *mention* "API key" in an admin-facing status message (e.g.
      // "not set up yet"), but must never ask the end user to enter one.
      assert.ok(!/enter\s+(your\s+)?(gemini\s+)?api[-_ ]?key/i.test(src), `${f} asks the user to enter an API key`);
      assert.ok(!/type=["']?password["']?[^>]*api/i.test(src) && !/api[^>]*type=["']?password/i.test(src), `${f} has an API key input field`);
    }
    // Logs must not contain the secret either
    assert.ok(!app.getLogs().includes(EXPECTED_KEY));
  } finally {
    await app.stop();
  }
});

test('validates requests', async () => {
  const app = await startApp({ MAX_MESSAGE_CHARS: '500' });
  try {
    const post = (body, headers = { 'Content-Type': 'application/json' }) =>
      fetch(app.base + '/api/chat', { method: 'POST', headers, body });

    assert.equal((await post('{not json')).status, 400);
    assert.equal((await post('{"conversationId":"a b","messages":[]}')).status, 400);
    assert.equal((await post(JSON.stringify({ conversationId: 'ok', messages: [] }))).status, 400);
    assert.equal((await post(JSON.stringify({ conversationId: 'ok', messages: [{ role: 'system', content: 'x' }] }))).status, 400);
    assert.equal((await post(JSON.stringify({ conversationId: 'ok', messages: [A('hi')] }))).status, 400);
    assert.equal((await post(JSON.stringify({ conversationId: 'ok', messages: [U('   ')] }))).status, 400);
    assert.equal((await post('{}', { 'Content-Type': 'text/plain' })).status, 415);

    const tooLong = await post(JSON.stringify({ conversationId: 'ok', messages: [U('x'.repeat(501))] }));
    assert.equal(tooLong.status, 413);
    assert.equal((await tooLong.json()).error.code, 'message_too_long');

    const huge = await post(JSON.stringify({ conversationId: 'ok', messages: [U('hi')], pad: 'x'.repeat(1_100_000) }));
    assert.equal(huge.status, 413);

    const get = await fetch(app.base + '/api/chat');
    assert.equal(get.status, 405);

    // cross-site POSTs are refused
    const evil = await fetch(app.base + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example' },
      body: JSON.stringify({ conversationId: 'ok', messages: [U('hi')] }),
    });
    assert.equal(evil.status, 403);
    assert.equal(app.mock.state.requests.length, 0, 'invalid requests must never reach Gemini');
  } finally {
    await app.stop();
  }
});

test('trims very long history but keeps the newest messages', async () => {
  const app = await startApp({ CONTEXT_MAX_CHARS: '1200' });
  try {
    const msgs = [];
    for (let i = 0; i < 30; i++) msgs.push(U(`question ${i} ` + 'q'.repeat(100)), A(`answer ${i} ` + 'a'.repeat(100)));
    msgs.push(U('final question'));
    const r = await chat(app.base, msgs);
    assert.equal(r.status, 200);
    const sent = app.mock.state.lastContents;
    assert.ok(sent.length < msgs.length && sent.length >= 3);
    assert.equal(sent[0].role, 'user');
    assert.equal(sent.at(-1).parts[0].text, 'final question');
    assert.equal(r.events.at(-1).data.trimmed, true);
  } finally {
    await app.stop();
  }
});

test('friendly errors, no internal details', async () => {
  const app = await startApp();
  try {
    const cases = [
      ['ERR403', 503, 'service_unavailable'],
      ['ERR404', 503, 'model_unavailable'],
      ['ERR429', 503, 'quota_exceeded'],
      ['ERR503', 503, 'busy'],
    ];
    for (const [word, status, code] of cases) {
      const r = await chat(app.base, [U(word)]);
      assert.equal(r.status, status, word);
      assert.equal(r.json.error.code, code, word);
      const s = JSON.stringify(r.json);
      assert.ok(!/secret-detail|simulated|Gemini|API key/i.test(s), 'must not leak upstream details: ' + s);
    }
    // failures that surface after the stream opened arrive as an SSE error event
    for (const [word, code] of [['EMPTY', 'empty_response'], ['BLOCK', 'blocked']]) {
      const r = await chat(app.base, [U(word)]);
      const err = r.events.find((e) => e.event === 'error');
      assert.ok(err, word);
      assert.equal(err.data.code, code);
    }
    assert.ok(!/stack|at Object|node:internal/.test(app.getLogs().split('\n').filter((l) => l.includes('"level":"warn"')).join('')));
  } finally {
    await app.stop();
  }
});

test('a wrong server key gives a generic message and is logged for the owner', async () => {
  const app = await startApp({ GEMINI_API_KEY: 'wrong-key' });
  try {
    const r = await chat(app.base, [U('Hello')]);
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'service_unavailable');
    assert.ok(!JSON.stringify(r.json).includes('wrong-key'));
    assert.ok(app.getLogs().includes('Gemini rejected the server API key'));
    assert.ok(!app.getLogs().includes('wrong-key'), 'key must be redacted from logs');
  } finally {
    await app.stop();
  }
});

test('reports a missing key without crashing', async () => {
  const app = await startApp({ GEMINI_API_KEY: 'YOUR_GEMINI_API_KEY' });
  try {
    const r = await chat(app.base, [U('Hello')]);
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'not_configured');
    const cfg = await (await fetch(app.base + '/api/config')).json();
    assert.equal(cfg.ready, false);
  } finally {
    await app.stop();
  }
});

test('Stop: cancelling the browser request cancels Gemini too', async () => {
  const app = await startApp();
  try {
    const ac = new AbortController();
    const res = await fetch(app.base + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conversationId: 'c', messages: [U('SLOW please')] }),
      signal: ac.signal,
    });
    const reader = res.body.getReader();
    const first = await reader.read();
    assert.ok(first.value.length > 0, 'first chunk arrives quickly');
    ac.abort();
    await reader.read().catch(() => {});
    for (let i = 0; i < 40 && app.mock.state.closedEarly === 0; i++) await new Promise((r) => setTimeout(r, 50));
    assert.equal(app.mock.state.closedEarly, 1, 'upstream Gemini stream should be closed');

    // and the user can chat again right away
    const again = await chat(app.base, [U('Hello')]);
    assert.equal(again.status, 200);
  } finally {
    await app.stop();
  }
});

test('rate limiting: per-minute limit returns 429 with Retry-After', async () => {
  const app = await startApp({ RATE_LIMIT_MAX_REQUESTS: '4', MAX_CONCURRENT_PER_IP: '4' });
  try {
    const statuses = [];
    let last;
    for (let i = 0; i < 6; i++) {
      last = await chat(app.base, [U('Hello')]);
      statuses.push(last.status);
    }
    assert.deepEqual(statuses, [200, 200, 200, 200, 429, 429]);
    assert.ok(Number(last.headers.get('retry-after')) >= 1);
    assert.equal(last.json.error.code, 'rate_limited');
  } finally {
    await app.stop();
  }
});

test('rate limiting: concurrent streams per IP are capped and slots are released', async () => {
  const app = await startApp({ MAX_CONCURRENT_PER_IP: '2' });
  try {
    const acs = [new AbortController(), new AbortController()];
    const open = acs.map((ac) =>
      fetch(app.base + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversationId: 'c', messages: [U('SLOW')] }),
        signal: ac.signal,
      }).then((r) => r.body.getReader().read().then(() => r))
    );
    await Promise.all(open);
    const third = await chat(app.base, [U('Hello')]);
    assert.equal(third.status, 429);
    assert.equal(third.json.error.code, 'busy');
    acs.forEach((a) => a.abort());
    await new Promise((r) => setTimeout(r, 300));
    const after = await chat(app.base, [U('Hello')]);
    assert.equal(after.status, 200);
  } finally {
    await app.stop();
  }
});

test('daily quota per IP', async () => {
  const app = await startApp({ RATE_LIMIT_DAILY_MAX: '2' });
  try {
    assert.equal((await chat(app.base, [U('Hello')])).status, 200);
    assert.equal((await chat(app.base, [U('Hello')])).status, 200);
    const r = await chat(app.base, [U('Hello')]);
    assert.equal(r.status, 429);
    assert.equal(r.json.error.code, 'daily_limit');
  } finally {
    await app.stop();
  }
});

test('upstream timeout produces a friendly timeout error', async () => {
  const app = await startApp({ GEMINI_TOTAL_TIMEOUT_MS: '5000' });
  try {
    // SLOW stream takes ~12s; total timeout of 5s must cut it
    const r = await chat(app.base, [U('SLOW')]);
    const err = r.events.find((e) => e.event === 'error');
    assert.equal(err?.data.code, 'timeout');
    assert.ok(r.text.length > 0, 'partial text was streamed before the timeout');
  } finally {
    await app.stop();
  }
});

test('security headers and static hardening', async () => {
  const app = await startApp();
  try {
    const res = await fetch(app.base + '/');
    assert.equal(res.status, 200);
    const csp = res.headers.get('content-security-policy');
    assert.match(csp, /script-src 'self'/);
    assert.ok(!/script-src[^;]*unsafe/.test(csp));
    assert.match(csp, /frame-ancestors 'none'/);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-powered-by'), null);

    for (const p of ['/../backend/config.js', '/%2e%2e/backend/config.js', '/..%2fbackend%2fconfig.js', '/.env', '/%00', '/vendor/../../.env']) {
      const r = await fetch(app.base + p);
      const body = await r.text();
      assert.ok(r.status >= 400, `${p} -> ${r.status}`);
      assert.ok(!body.includes('GEMINI_API_KEY'), p);
    }
    const etag = (await fetch(app.base + '/app.js')).headers.get('etag');
    const cond = await fetch(app.base + '/app.js', { headers: { 'If-None-Match': etag } });
    assert.equal(cond.status, 304);
  } finally {
    await app.stop();
  }
});
