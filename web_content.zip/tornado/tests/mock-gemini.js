'use strict';

/**
 * A tiny fake of the Gemini streaming endpoint, used by the test-suite and for
 * trying Tornado without a real key:
 *
 *   MOCK_PORT=4010 node tests/mock-gemini.js
 *   GEMINI_API_KEY=test GEMINI_API_BASE=http://localhost:4010/v1beta npm start
 *
 * Magic words in the last user message trigger behaviours:
 *   ERR403 / ERR404 / ERR429 / ERR503  -> upstream HTTP error
 *   EMPTY                              -> stream with no text
 *   BLOCK                              -> safety block
 *   SLOW                               -> very slow stream (to test Stop)
 *   MDTEST                             -> markdown / code / table / math sample
 */
const http = require('node:http');

const EXPECTED_KEY = 'test-secret-key-123';

function sse(res, obj) {
  res.write(`data: ${JSON.stringify(obj)}\r\n\r\n`);
}
const chunkOf = (text, finish) => ({
  candidates: [{ content: { role: 'model', parts: [{ text }] }, ...(finish ? { finishReason: finish } : {}) }],
});
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const MD = `# Markdown demo

Here is **bold**, *italic*, ~~strike~~, \`inline code\` and a [link](https://example.com).

- First item
- Second item
  - Nested item
1. One
2. Two

> A quote from someone wise.

| Language | Typed |
|----------|:-----:|
| Python   | dynamic |
| Java     | static |

\`\`\`python
def greet(name: str) -> str:
    # say hello
    return f"Hello, {name}!"
\`\`\`

\`\`\`javascript
const total = [1, 2, 3].reduce((a, b) => a + b, 0); // 6
console.log(\`total: \${total}\`);
\`\`\`

The quadratic formula is $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$ and

$$\\int_0^1 x^2\\,dx = \\tfrac{1}{3}$$

<script>alert('xss')</script> [bad](javascript:alert(1))
`;

function createMock() {
  const state = { requests: [], closedEarly: 0, lastContents: null };

  const server = http.createServer(async (req, res) => {
    if (req.method !== 'POST' || !/:streamGenerateContent$/.test(req.url.split('?')[0])) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: { code: 404, status: 'NOT_FOUND', message: 'model not found' } }));
    }
    let raw = '';
    for await (const c of req) raw += c;
    const body = JSON.parse(raw);
    state.requests.push({ url: req.url, headers: req.headers, body });
    state.lastContents = body.contents;

    if (req.headers['x-goog-api-key'] !== EXPECTED_KEY) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: { code: 400, status: 'INVALID_ARGUMENT', message: 'API key not valid. Please pass a valid API key.' } }));
    }

    const contents = body.contents;
    const last = contents[contents.length - 1].parts[0].text;
    const fail = /ERR(403|404|429|503)/.exec(last);
    if (fail) {
      const code = Number(fail[1]);
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: { code, status: 'X', message: `simulated ${code} secret-detail-should-not-leak` } }));
    }

    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    let closed = false;
    res.on('close', () => {
      if (!res.writableEnded) {
        closed = true;
        state.closedEarly += 1;
      }
    });

    if (/EMPTY/.test(last)) {
      sse(res, { candidates: [{ finishReason: 'STOP' }] });
      return res.end();
    }
    if (/BLOCK/.test(last)) {
      sse(res, { promptFeedback: { blockReason: 'SAFETY' } });
      return res.end();
    }

    let text;
    if (/MDTEST/.test(last)) {
      text = MD;
    } else if (/SLOW/.test(last)) {
      text = 'slow '.repeat(200);
    } else if (/name/i.test(last)) {
      const earlier = contents.map((c) => c.parts[0].text).join(' ');
      const m = /my name is (\w+)/i.exec(earlier);
      text = m ? `Your name is ${m[1]}.` : "I don't know your name yet.";
    } else if (/hello/i.test(last)) {
      text = 'Hello! I am a mock Gemini. How can I help you today?';
    } else {
      text = `You said: ${last}`;
    }

    // Split into small pieces to mimic token streaming
    const pieces = text.match(/[\s\S]{1,6}/g) || [];
    const delay = /SLOW/.test(last) ? 60 : 8;
    for (let i = 0; i < pieces.length; i++) {
      if (closed) return;
      sse(res, chunkOf(pieces[i], i === pieces.length - 1 ? 'STOP' : undefined));
      await sleep(delay);
    }
    res.end();
  });

  return { server, state };
}

if (require.main === module) {
  const { server } = createMock();
  const port = Number(process.env.MOCK_PORT || 4010);
  server.listen(port, () => console.log(`Mock Gemini on http://localhost:${port}/v1beta  (key: ${EXPECTED_KEY})`));
}

module.exports = { createMock, EXPECTED_KEY };
