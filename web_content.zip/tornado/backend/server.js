'use strict';

const http = require('node:http');
const config = require('./config');
const logger = require('./utils/logger');
const { AppError } = require('./utils/errors');
const { clientIp } = require('./utils/ip');
const { applySecurityHeaders, handleCors } = require('./middleware/security');
const { checkGeneral } = require('./middleware/rateLimit');
const { chatRoute, sendError } = require('./routes/chat');
const { configRoute, healthRoute } = require('./routes/meta');
const { serveStatic } = require('./routes/static');

async function handler(req, res) {
  applySecurityHeaders(req, res);
  if (handleCors(req, res)) return;

  let pathname;
  try {
    pathname = new URL(req.url, 'http://localhost').pathname;
  } catch {
    res.writeHead(400);
    return res.end();
  }

  try {
    if (pathname.startsWith('/api/')) {
      checkGeneral(clientIp(req));
      switch (pathname) {
        case '/api/chat':
          return await chatRoute(req, res);
        case '/api/config':
          return configRoute(req, res);
        case '/api/health':
          return healthRoute(req, res);
        default:
          return sendError(res, new AppError(404, 'not_found'));
      }
    }
    if (!config.server.serveFrontend) {
      return sendError(res, new AppError(404, 'not_found'));
    }
    return await serveStatic(req, res, pathname);
  } catch (err) {
    if (!(err instanceof AppError)) logger.error('Unhandled error', { details: String(err && err.stack ? err.stack : err) });
    if (res.headersSent) return res.end();
    return sendError(res, err instanceof AppError ? err : new AppError(500, 'server_error'));
  }
}

function createServer() {
  const server = http.createServer(handler);
  server.headersTimeout = 20_000;
  server.requestTimeout = 30_000; // time allowed to RECEIVE a request; streaming replies are not affected
  server.keepAliveTimeout = 65_000;
  server.maxHeadersCount = 50;
  return server;
}

function start() {
  const server = createServer();
  server.listen(config.server.port, config.server.host, () => {
    logger.info(`${config.appName} is running`, { url: `http://localhost:${config.server.port}`, env: config.env, model: config.gemini.model });
    if (!config.gemini.apiKey) {
      logger.warn('GEMINI_API_KEY is not set - chat requests will fail until you add it (see .env.example).');
    }
  });

  const shutdown = (signal) => {
    logger.info(`${signal} received, shutting down`);
    server.close(() => process.exit(0));
    server.closeIdleConnections?.();
    setTimeout(() => process.exit(0), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (err) => logger.error('unhandledRejection', { details: String(err && err.stack ? err.stack : err) }));
  process.on('uncaughtException', (err) => logger.error('uncaughtException', { details: String(err && err.stack ? err.stack : err) }));
  return server;
}

if (require.main === module) start();

module.exports = { createServer, start };
