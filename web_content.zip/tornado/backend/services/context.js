'use strict';

const config = require('../config');

/**
 * Turn the client's conversation into the context sent to Gemini.
 *
 * Gemini needs the earlier turns to "remember" things (e.g. the user's name),
 * but very long chats are slow and expensive. This keeps the NEWEST messages
 * that fit inside CONTEXT_MAX_CHARS and drops the oldest ones. The latest user
 * message is always kept (and clipped if it alone exceeds the budget).
 *
 * @returns {{ contents: Array, trimmed: boolean }}
 */
function buildContext(messages, maxChars = config.limits.contextMaxChars) {
  const kept = [];
  let used = 0;

  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    const cost = m.content.length;
    if (kept.length === 0) {
      // newest message: always keep, clip if enormous
      const content = cost > maxChars ? m.content.slice(0, maxChars) : m.content;
      kept.push({ role: m.role, content });
      used += content.length;
      continue;
    }
    if (used + cost > maxChars) break;
    kept.push(m);
    used += cost;
  }
  kept.reverse();

  const trimmed = kept.length < messages.length;

  // Gemini expects the conversation to start with a user turn.
  while (kept.length > 1 && kept[0].role !== 'user') kept.shift();

  // Merge consecutive same-role turns (can happen after skipping empty ones).
  const merged = [];
  for (const m of kept) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content += '\n\n' + m.content;
    else merged.push({ role: m.role, content: m.content });
  }

  const contents = merged.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));

  return { contents, trimmed };
}

module.exports = { buildContext };
