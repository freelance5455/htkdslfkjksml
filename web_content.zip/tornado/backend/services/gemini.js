'use strict';

const config = require('../config');
const logger = require('../utils/logger');
const { AppError } = require('../utils/errors');

const G = config.gemini;

/**
 * Map an upstream Gemini HTTP error to a safe, friendly AppError.
 * The real reason is written to the server log only (with secrets redacted).
 */
function mapUpstreamError(status, bodyText) {
  let apiStatus = '';
  let apiMessage = '';
  try {
    const parsed = JSON.parse(bodyText);
    apiStatus = parsed?.error?.status || '';
    apiMessage = parsed?.error?.message || '';
  } catch {
    apiMessage = String(bodyText || '').slice(0, 300);
  }
  const details = `Gemini HTTP ${status} ${apiStatus} ${apiMessage}`.trim();

  const looksLikeBadKey = /api key|API_KEY|permission|unauthenticated|not valid|expired/i.test(apiMessage + apiStatus);

  if (status === 401 || status === 403 || (status === 400 && looksLikeBadKey)) {
    logger.error('Gemini rejected the server API key or project. Check GEMINI_API_KEY and that the Generative Language API is enabled.', { details });
    return new AppError(503, 'service_unavailable', { details });
  }
  if (status === 404) {
    logger.error('Gemini model not found. Check GEMINI_MODEL.', { model: G.model, details });
    return new AppError(503, 'model_unavailable', { details });
  }
  if (status === 429) {
    logger.warn('Gemini quota or rate limit reached.', { details });
    return new AppError(503, 'quota_exceeded', { details, retryAfter: 30 });
  }
  if (status === 503 || status === 500 || status === 502 || status === 504) {
    logger.warn('Gemini is overloaded or unavailable.', { details });
    return new AppError(503, 'busy', { details, retryAfter: 5 });
  }
  if (status === 400) {
    logger.warn('Gemini rejected the request.', { details });
    return new AppError(502, 'server_error', { details });
  }
  logger.error('Unexpected Gemini error.', { details });
  return new AppError(502, 'server_error', { details });
}

function extractText(chunk) {
  const parts = chunk?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return '';
  let out = '';
  for (const p of parts) {
    if (p && typeof p.text === 'string' && !p.thought) out += p.text;
  }
  return out;
}

/**
 * Stream a chat completion from Gemini.
 *
 * @param {object}   opts
 * @param {Array}    opts.contents   Gemini "contents" array
 * @param {AbortSignal} opts.signal  aborted when the browser cancels / disconnects
 * @param {Function} opts.onOpen     called once Gemini accepted the request
 * @param {Function} opts.onText     async (text) => void, called for every text delta
 * @returns {Promise<{finishReason: string|null, chars: number}>}
 * @throws  {AppError}
 */
async function streamChat({ contents, signal, onOpen, onText }) {
  if (!G.apiKey) throw new AppError(503, 'not_configured');

  const controller = new AbortController();
  let abortedBy = null;
  const abort = (reason) => {
    if (!abortedBy) {
      abortedBy = reason;
      controller.abort();
    }
  };

  if (signal) {
    if (signal.aborted) abort('client');
    else signal.addEventListener('abort', () => abort('client'), { once: true });
  }
  let firstByteTimer = setTimeout(() => abort('timeout'), G.firstByteTimeoutMs);
  const totalTimer = setTimeout(() => abort('timeout'), G.totalTimeoutMs);

  const generationConfig = {
    temperature: G.temperature,
    maxOutputTokens: G.maxOutputTokens,
  };
  if (G.thinkingBudget !== null) generationConfig.thinkingConfig = { thinkingBudget: G.thinkingBudget };

  const body = {
    systemInstruction: { parts: [{ text: G.systemPrompt }] },
    contents,
    generationConfig,
  };

  // The key travels in a header (never in the URL) and never leaves this server.
  const url = `${G.apiBase}/models/${encodeURIComponent(G.model)}:streamGenerateContent?alt=sse`;

  let chars = 0;
  let finishReason = null;
  let blockReason = null;

  try {
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': G.apiKey },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (err) {
      if (abortedBy === 'timeout') throw new AppError(504, 'timeout');
      if (abortedBy === 'client') throw clientGone();
      logger.error('Could not reach Gemini.', { details: err && err.cause ? `${err.message}: ${err.cause.code || err.cause.message}` : err.message });
      throw new AppError(503, 'service_unavailable');
    }

    if (!res.ok) {
      let text = '';
      try {
        text = (await res.text()).slice(0, 2000);
      } catch { /* ignore */ }
      throw mapUpstreamError(res.status, text);
    }

    clearTimeout(firstByteTimer);
    firstByteTimer = null;
    if (onOpen) onOpen();

    const decoder = new TextDecoder('utf-8');
    const reader = res.body.getReader();
    let buffer = '';

    const handleEvent = async (raw) => {
      // An SSE event may contain several lines; only "data:" lines matter.
      let data = '';
      for (const line of raw.split('\n')) {
        if (line.startsWith('data:')) data += line.slice(5).replace(/^ /, '');
      }
      if (!data || data === '[DONE]') return;
      let json;
      try {
        json = JSON.parse(data);
      } catch {
        return; // ignore a malformed keep-alive fragment
      }
      if (json.error) {
        throw mapUpstreamError(Number(json.error.code) || 500, JSON.stringify({ error: json.error }));
      }
      if (json.promptFeedback?.blockReason) blockReason = json.promptFeedback.blockReason;
      const reason = json.candidates?.[0]?.finishReason;
      if (reason) finishReason = reason;
      const text = extractText(json);
      if (text) {
        chars += text.length;
        await onText(text);
      }
    };

    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, '\n');
        let idx;
        while ((idx = buffer.indexOf('\n\n')) !== -1) {
          const raw = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          await handleEvent(raw);
        }
      }
      buffer += decoder.decode().replace(/\r\n/g, '\n');
      if (buffer.trim()) await handleEvent(buffer);
    } catch (err) {
      if (err instanceof AppError) throw err;
      if (abortedBy === 'timeout') throw new AppError(504, 'timeout');
      if (abortedBy === 'client') throw clientGone();
      logger.warn('Gemini stream interrupted.', { details: err.message });
      throw new AppError(chars ? 502 : 503, chars ? 'network' : 'service_unavailable');
    } finally {
      try { reader.releaseLock(); } catch { /* ignore */ }
    }

    if (chars === 0) {
      const blocked = blockReason || ['SAFETY', 'PROHIBITED_CONTENT', 'BLOCKLIST', 'SPII', 'IMAGE_SAFETY'].includes(finishReason);
      if (blocked) {
        logger.info('Gemini blocked a response.', { blockReason, finishReason });
        throw new AppError(422, 'blocked');
      }
      throw new AppError(502, 'empty_response', { details: `finishReason=${finishReason}` });
    }
    return { finishReason, chars };
  } finally {
    if (firstByteTimer) clearTimeout(firstByteTimer);
    clearTimeout(totalTimer);
    // Make sure the upstream connection is torn down if we are leaving early.
    if (!controller.signal.aborted) controller.abort();
  }
}

function clientGone() {
  const e = new AppError(499, 'network');
  e.clientGone = true;
  return e;
}

module.exports = { streamChat, mapUpstreamError };
