'use strict';

/**
 * Tornado - central backend configuration.
 *
 * Every value comes from environment variables (or a local .env file in
 * development). The Gemini API key lives ONLY here, on the server. It is never
 * sent to the browser, never logged, and never included in any API response.
 */

const fs = require('node:fs');
const path = require('node:path');

// Load .env for local development. Hosting platforms inject real environment
// variables, which always win over the file.
const envFile = path.resolve(__dirname, '..', '.env');
if (fs.existsSync(envFile) && typeof process.loadEnvFile === 'function') {
  try {
    process.loadEnvFile(envFile);
  } catch (err) {
    console.warn('[config] Could not read .env file:', err.message);
  }
}

function str(name, fallback = '') {
  const v = process.env[name];
  return v === undefined || v === '' ? fallback : String(v).trim();
}

function int(name, fallback, { min = -Infinity, max = Infinity } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number.parseInt(raw, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function num(name, fallback, { min = -Infinity, max = Infinity } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number.parseFloat(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function bool(name, fallback = false) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(raw).toLowerCase());
}

function list(name) {
  return str(name)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

// The placeholder from .env.example must never be treated as a real key.
const rawKey = str('GEMINI_API_KEY');
const keyIsPlaceholder = /^YOUR[_-]/i.test(rawKey) || /PLACEHOLDER|CHANGE_ME/i.test(rawKey);

const config = Object.freeze({
  appName: 'Tornado',
  env: str('NODE_ENV', 'development'),
  isProduction: str('NODE_ENV', 'development') === 'production',

  server: Object.freeze({
    host: str('HOST', '0.0.0.0'),
    port: int('PORT', 3000, { min: 1, max: 65535 }),
    // Set to the number of reverse proxies in front of the app (Render, Fly,
    // Railway, Nginx ... = 1). Needed so per-IP limits see the real client IP.
    trustProxyHops: int('TRUST_PROXY_HOPS', 0, { min: 0, max: 5 }),
    // Comma-separated list of origins allowed to call /api from another
    // domain. Leave empty when the frontend is served by this same server.
    corsOrigins: list('CORS_ORIGIN'),
    serveFrontend: bool('SERVE_FRONTEND', true),
    hsts: bool('ENABLE_HSTS', str('NODE_ENV', 'development') === 'production'),
  }),

  gemini: Object.freeze({
    apiKey: keyIsPlaceholder ? '' : rawKey,
    // "gemini-flash-latest" is a Google-maintained alias that always points at
    // the newest Flash model. Pin a specific model here if you need stability.
    model: str('GEMINI_MODEL', 'gemini-flash-latest'),
    apiBase: str('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta').replace(/\/+$/, ''),
    temperature: num('GEMINI_TEMPERATURE', 0.8, { min: 0, max: 2 }),
    maxOutputTokens: int('GEMINI_MAX_OUTPUT_TOKENS', 8192, { min: 64, max: 65536 }),
    // Optional. Set to 0 to disable thinking (fastest first token) on models
    // that allow it, or a positive token budget. Leave empty for the default.
    thinkingBudget: process.env.GEMINI_THINKING_BUDGET === undefined || process.env.GEMINI_THINKING_BUDGET === ''
      ? null
      : int('GEMINI_THINKING_BUDGET', 0, { min: -1, max: 32768 }),
    // Give up if Gemini has not produced a first byte after this long.
    firstByteTimeoutMs: int('GEMINI_FIRST_BYTE_TIMEOUT_MS', 30_000, { min: 1_000 }),
    // Hard cap for the whole response.
    totalTimeoutMs: int('GEMINI_TOTAL_TIMEOUT_MS', 120_000, { min: 5_000 }),
    systemPrompt: str(
      'SYSTEM_PROMPT',
      'You are Tornado, a friendly, knowledgeable and concise AI assistant. ' +
        'Answer clearly and accurately. Use Markdown for structure: short headings, lists, tables and fenced code blocks with a language tag when they help. ' +
        'Write math using LaTeX between $...$ (inline) or $$...$$ (display). ' +
        'Reply in the same language the user writes in. If you are unsure, say so instead of guessing.'
    ),
  }),

  limits: Object.freeze({
    // Request validation
    maxBodyBytes: int('MAX_BODY_BYTES', 1_000_000, { min: 1_000 }),
    maxMessageChars: int('MAX_MESSAGE_CHARS', 8_000, { min: 100 }),
    maxAssistantChars: int('MAX_ASSISTANT_CHARS', 60_000, { min: 1_000 }),
    maxMessagesPerRequest: int('MAX_MESSAGES_PER_REQUEST', 100, { min: 1 }),
    // How much conversation history is forwarded to Gemini (older turns are
    // trimmed first, the newest user message is always kept).
    contextMaxChars: int('CONTEXT_MAX_CHARS', 48_000, { min: 1_000 }),

    // Rate limiting (per client IP, in memory)
    rateWindowMs: int('RATE_LIMIT_WINDOW_MS', 60_000, { min: 1_000 }),
    rateMaxRequests: int('RATE_LIMIT_MAX_REQUESTS', 20, { min: 1 }),
    dailyMaxRequests: int('RATE_LIMIT_DAILY_MAX', 400, { min: 1 }),
    maxConcurrentPerIp: int('MAX_CONCURRENT_PER_IP', 2, { min: 1 }),
    maxConcurrentGlobal: int('MAX_CONCURRENT_GLOBAL', 60, { min: 1 }),
    // Cheap protection for every other /api and static request
    generalRateMax: int('GENERAL_RATE_LIMIT_MAX', 300, { min: 10 }),
  }),
});

module.exports = config;
