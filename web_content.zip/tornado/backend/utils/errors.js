'use strict';

/**
 * Error codes shared with the frontend. The frontend maps each code to a
 * friendly message, so nothing technical or sensitive ever leaves the server.
 */
const MESSAGES = {
  bad_request: 'That message could not be processed. Please check it and try again.',
  message_too_long: 'That message is too long. Please shorten it and try again.',
  payload_too_large: 'That request is too large. Please start a new chat or shorten your message.',
  rate_limited: 'You are sending messages too quickly. Please wait a moment and try again.',
  daily_limit: 'You have reached the daily message limit. Please come back tomorrow.',
  busy: 'Tornado is busy right now. Please try again in a moment.',
  not_configured: 'Tornado is not set up yet. Please contact the site owner.',
  service_unavailable: 'Tornado is temporarily unavailable. Please try again later.',
  quota_exceeded: 'Tornado has reached its usage limit for now. Please try again later.',
  model_unavailable: 'Tornado is temporarily unavailable. Please try again later.',
  timeout: 'The response took too long. Please try again.',
  empty_response: 'Tornado did not return an answer. Please try again or rephrase your message.',
  blocked: 'Tornado cannot answer that request. Please try rephrasing it.',
  network: 'Could not reach the server. Check your connection and try again.',
  server_error: 'Something went wrong. Please try again.',
  not_found: 'Not found.',
  method_not_allowed: 'Method not allowed.',
  forbidden: 'Forbidden.',
};

class AppError extends Error {
  constructor(status, code, { retryAfter, details } = {}) {
    super(MESSAGES[code] || MESSAGES.server_error);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.retryAfter = retryAfter;
    // `details` is for server logs only and is never sent to clients.
    this.details = details;
  }
}

function publicMessage(code) {
  return MESSAGES[code] || MESSAGES.server_error;
}

module.exports = { AppError, publicMessage, MESSAGES };
