'use strict';

const net = require('node:net');
const config = require('../config');

/**
 * Determine the client IP.
 * X-Forwarded-For can be forged by clients, so it is only honoured when
 * TRUST_PROXY_HOPS says how many trusted proxies sit in front of the app. The
 * address is then read from the right-hand side, where trusted proxies append.
 */
function clientIp(req) {
  const socketIp = (req.socket && req.socket.remoteAddress) || 'unknown';
  const hops = config.server.trustProxyHops;
  if (hops > 0) {
    const header = req.headers['x-forwarded-for'];
    if (header) {
      const parts = String(header).split(',').map((s) => s.trim()).filter(Boolean);
      const candidate = parts[parts.length - hops];
      if (candidate && net.isIP(candidate)) return normalise(candidate);
    }
  }
  return normalise(socketIp);
}

function normalise(ip) {
  // IPv4-mapped IPv6 -> IPv4
  if (ip.startsWith('::ffff:')) return ip.slice(7);
  // Group IPv6 clients by /64 so rotating the low bits does not bypass limits.
  if (net.isIPv6(ip)) return ip.split(':').slice(0, 4).join(':') + '::/64';
  return ip;
}

module.exports = { clientIp };
