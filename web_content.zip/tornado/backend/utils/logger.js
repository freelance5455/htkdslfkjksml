'use strict';

const config = require('../config');

const key = config.gemini.apiKey;

/** Remove anything that looks like a secret before it reaches the logs. */
function redact(value) {
  let s = typeof value === 'string' ? value : value instanceof Error ? `${value.name}: ${value.message}` : JSON.stringify(value);
  if (!s) return '';
  if (key) s = s.split(key).join('[redacted]');
  s = s.replace(/AIza[0-9A-Za-z_-]{20,}/g, '[redacted]');
  s = s.replace(/([?&]key=)[^&\s"']+/gi, '$1[redacted]');
  return s;
}

function line(level, msg, meta) {
  const out = { t: new Date().toISOString(), level, msg: redact(msg) };
  if (meta) for (const [k, v] of Object.entries(meta)) out[k] = typeof v === 'string' ? redact(v) : v;
  const text = JSON.stringify(out);
  (level === 'error' ? console.error : level === 'warn' ? console.warn : console.log)(text);
}

module.exports = {
  info: (msg, meta) => line('info', msg, meta),
  warn: (msg, meta) => line('warn', msg, meta),
  error: (msg, meta) => line('error', msg, meta),
  redact,
};
