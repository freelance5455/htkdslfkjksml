'use strict';

const config = require('../config');

/**
 * Security headers. The CSP is strict on purpose: only same-origin scripts,
 * no inline scripts, no eval, no framing. Even if a bug let markup through,
 * the browser would refuse to run injected scripts.
 */
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  // KaTeX (math) sets inline style attributes. Attribute-only, no <style> blocks.
  "style-src-attr 'unsafe-inline'",
  "img-src 'self' data:",
  "font-src 'self'",
  "connect-src 'self'",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

function applySecurityHeaders(req, res) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.removeHeader('X-Powered-By');
  if (config.server.hsts) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
}

/**
 * CORS is off unless CORS_ORIGIN lists explicit origins. Returns true when the
 * request was a preflight that has been fully answered.
 */
function handleCors(req, res) {
  const origin = req.headers.origin;
  const allowed = config.server.corsOrigins;
  if (origin && allowed.length && (allowed.includes('*') ? false : allowed.includes(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Expose-Headers', 'Retry-After, RateLimit-Remaining');
    res.setHeader('Access-Control-Max-Age', '600');
  }
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return true;
  }
  return false;
}

/**
 * Cross-site request forgery guard for state-changing calls. Browsers always
 * send Origin on cross-origin POSTs, so a request from an unknown origin is
 * rejected. Same-origin and non-browser clients (no Origin header) pass.
 */
function isOriginAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  if (config.server.corsOrigins.includes(origin)) return true;
  const host = req.headers.host;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

module.exports = { applySecurityHeaders, handleCors, isOriginAllowed };
