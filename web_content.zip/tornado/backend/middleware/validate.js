'use strict';

const config = require('../config');
const { AppError } = require('../utils/errors');

const L = config.limits;

/** Read a JSON body with a hard size limit. Never buffers more than the limit. */
function readJson(req) {
  return new Promise((resolve, reject) => {
    const type = String(req.headers['content-type'] || '');
    if (!type.toLowerCase().startsWith('application/json')) {
      return reject(new AppError(415, 'bad_request'));
    }
    const declared = Number.parseInt(req.headers['content-length'] || '0', 10);
    if (declared > L.maxBodyBytes) {
      req.resume();
      return reject(new AppError(413, 'payload_too_large'));
    }
    const chunks = [];
    let size = 0;
    let failed = false;
    req.on('data', (chunk) => {
      if (failed) return;
      size += chunk.length;
      if (size > L.maxBodyBytes) {
        failed = true;
        chunks.length = 0;
        reject(new AppError(413, 'payload_too_large'));
        req.resume(); // drain and discard the rest
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (failed) return;
      try {
        const text = Buffer.concat(chunks).toString('utf8');
        const parsed = JSON.parse(text);
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
          return reject(new AppError(400, 'bad_request'));
        }
        resolve(parsed);
      } catch {
        reject(new AppError(400, 'bad_request'));
      }
    });
    req.on('error', () => {
      if (!failed) reject(new AppError(400, 'bad_request'));
    });
  });
}

const CONVERSATION_ID = /^[A-Za-z0-9_-]{1,64}$/;

/**
 * Validate the body of POST /api/chat and return a clean, normalised copy.
 * Anything unexpected is rejected - the raw body is never forwarded to Gemini.
 *
 * Expected shape:
 *   { conversationId: "abc", messages: [{ role: "user"|"assistant", content: "..." }] }
 */
function validateChatBody(body) {
  if (typeof body.conversationId !== 'string' || !CONVERSATION_ID.test(body.conversationId)) {
    throw new AppError(400, 'bad_request', { details: 'invalid conversationId' });
  }
  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    throw new AppError(400, 'bad_request', { details: 'messages must be a non-empty array' });
  }
  if (body.messages.length > L.maxMessagesPerRequest) {
    throw new AppError(413, 'payload_too_large', { details: 'too many messages' });
  }

  const messages = [];
  for (const m of body.messages) {
    if (!m || typeof m !== 'object') throw new AppError(400, 'bad_request');
    const role = m.role === 'model' ? 'assistant' : m.role;
    if (role !== 'user' && role !== 'assistant') throw new AppError(400, 'bad_request', { details: 'bad role' });
    if (typeof m.content !== 'string') throw new AppError(400, 'bad_request', { details: 'content must be a string' });

    // Strip NUL / control characters that have no business in chat text.
    // eslint-disable-next-line no-control-regex
    const content = m.content.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
    const limit = role === 'user' ? L.maxMessageChars : L.maxAssistantChars;
    if (content.length > limit) {
      throw new AppError(413, role === 'user' ? 'message_too_long' : 'payload_too_large');
    }
    // Skip empty assistant turns (e.g. a stopped generation with no text),
    // but empty user turns are a client bug.
    if (!content.trim()) {
      if (role === 'assistant') continue;
      throw new AppError(400, 'bad_request', { details: 'empty user message' });
    }
    messages.push({ role, content });
  }

  if (!messages.length || messages[messages.length - 1].role !== 'user') {
    throw new AppError(400, 'bad_request', { details: 'last message must be from the user' });
  }
  return { conversationId: body.conversationId, messages };
}

module.exports = { readJson, validateChatBody };
