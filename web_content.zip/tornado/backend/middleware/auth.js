'use strict';

/**
 * Authentication extension point.
 *
 * Tornado works without login: every visitor is "anonymous" and their chat
 * history lives in their own browser (IndexedDB). To add accounts later:
 *
 *   1. Implement sign-up / login / logout routes in backend/routes/auth.js
 *      (hash passwords with scrypt or argon2 - never store plain text - and
 *      issue an HttpOnly, Secure, SameSite=Lax session cookie).
 *   2. Make `getUser` below read that cookie and return { id, email }.
 *   3. Rate limits already key on `user.id` when it exists (see routes/chat.js),
 *      so signed-in users automatically get their own quota.
 *   4. Move chat storage from IndexedDB to a database table keyed by user.id
 *      and always filter queries by that id, so nobody can read another
 *      user's conversations.
 */
const ANONYMOUS = Object.freeze({ id: null, anonymous: true });

function getUser(_req) {
  return ANONYMOUS;
}

module.exports = { getUser };
