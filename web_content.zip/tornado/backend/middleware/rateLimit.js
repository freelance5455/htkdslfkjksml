'use strict';

const config = require('../config');
const { AppError } = require('../utils/errors');

const L = config.limits;

/**
 * In-memory abuse protection for the Gemini-backed endpoint:
 *  - sliding window per IP          (RATE_LIMIT_WINDOW_MS / RATE_LIMIT_MAX_REQUESTS)
 *  - daily quota per IP             (RATE_LIMIT_DAILY_MAX)
 *  - concurrent streams per IP      (MAX_CONCURRENT_PER_IP)
 *  - concurrent streams overall     (MAX_CONCURRENT_GLOBAL)
 *
 * State is per process. If you run several instances, put the same limits in
 * front (CDN / gateway) or swap this store for Redis - the interface is small.
 */
const hits = new Map(); // ip -> number[] of request timestamps (ms) within window
const daily = new Map(); // ip -> { day: 'YYYY-MM-DD', count }
const active = new Map(); // ip -> number
let activeTotal = 0;

const general = new Map(); // ip -> { start, count } for all other API traffic

function today() {
  return new Date().toISOString().slice(0, 10);
}

function checkGeneral(ip) {
  const now = Date.now();
  let e = general.get(ip);
  if (!e || now - e.start >= 60_000) {
    e = { start: now, count: 0 };
    general.set(ip, e);
  }
  e.count += 1;
  if (e.count > L.generalRateMax) {
    throw new AppError(429, 'rate_limited', { retryAfter: Math.ceil((e.start + 60_000 - now) / 1000) });
  }
}

/**
 * Reserve a slot for one chat request. Returns a release() function that MUST
 * be called exactly once when the request ends (success, error or cancel).
 */
function acquireChatSlot(ip) {
  const now = Date.now();

  // 1) sliding window
  const arr = (hits.get(ip) || []).filter((t) => now - t < L.rateWindowMs);
  if (arr.length >= L.rateMaxRequests) {
    const retryAfter = Math.max(1, Math.ceil((arr[0] + L.rateWindowMs - now) / 1000));
    hits.set(ip, arr);
    throw new AppError(429, 'rate_limited', { retryAfter });
  }

  // 2) daily quota
  const day = today();
  let d = daily.get(ip);
  if (!d || d.day !== day) d = { day, count: 0 };
  if (d.count >= L.dailyMaxRequests) {
    throw new AppError(429, 'daily_limit', { retryAfter: 3600 });
  }

  // 3) concurrency
  const mine = active.get(ip) || 0;
  if (mine >= L.maxConcurrentPerIp) throw new AppError(429, 'busy', { retryAfter: 3 });
  if (activeTotal >= L.maxConcurrentGlobal) throw new AppError(503, 'busy', { retryAfter: 5 });

  // Reserve
  arr.push(now);
  hits.set(ip, arr);
  d.count += 1;
  daily.set(ip, d);
  active.set(ip, mine + 1);
  activeTotal += 1;

  const remaining = Math.max(0, L.rateMaxRequests - arr.length);
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    const n = (active.get(ip) || 1) - 1;
    if (n <= 0) active.delete(ip);
    else active.set(ip, n);
    activeTotal = Math.max(0, activeTotal - 1);
  };
  return { release, remaining };
}

// Periodic cleanup so the maps cannot grow without bound.
const sweeper = setInterval(() => {
  const now = Date.now();
  for (const [ip, arr] of hits) {
    const fresh = arr.filter((t) => now - t < L.rateWindowMs);
    if (fresh.length) hits.set(ip, fresh);
    else hits.delete(ip);
  }
  const day = today();
  for (const [ip, d] of daily) if (d.day !== day) daily.delete(ip);
  for (const [ip, e] of general) if (now - e.start >= 60_000) general.delete(ip);
}, 60_000);
sweeper.unref();

function stats() {
  return { activeStreams: activeTotal, trackedClients: hits.size };
}

module.exports = { acquireChatSlot, checkGeneral, stats };
