'use strict';

const config = require('../config');
const logger = require('../utils/logger');
const { AppError, publicMessage } = require('../utils/errors');
const { clientIp } = require('../utils/ip');
const { getUser } = require('../middleware/auth');
const { isOriginAllowed } = require('../middleware/security');
const { acquireChatSlot } = require('../middleware/rateLimit');
const { readJson, validateChatBody } = require('../middleware/validate');
const { buildContext } = require('../services/context');
const { streamChat } = require('../services/gemini');

function sendJson(res, status, payload, headers = {}) {
  if (res.headersSent) return;
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(body);
}

function sendError(res, err) {
  const status = err.status || 500;
  const code = err.code || 'server_error';
  const headers = err.retryAfter ? { 'Retry-After': String(err.retryAfter) } : {};
  sendJson(res, status, { error: { code, message: publicMessage(code) } }, headers);
}

/** Write one Server-Sent Event, respecting back-pressure from slow clients. */
async function sse(res, event, data) {
  if (res.writableEnded || res.destroyed) return;
  const ok = res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  if (!ok) {
    await new Promise((resolve) => {
      const done = () => {
        res.off('drain', done);
        res.off('close', done);
        resolve();
      };
      res.once('drain', done);
      res.once('close', done);
    });
  }
}

/**
 * POST /api/chat
 *   -> { conversationId, messages: [{ role, content }] }
 *   <- text/event-stream:  token* , then done | error
 */
async function chatRoute(req, res) {
  const startedAt = Date.now();
  const ip = clientIp(req);
  const user = getUser(req);
  const limitKey = user.id ? `user:${user.id}` : ip;

  if (req.method !== 'POST') {
    return sendError(res, new AppError(405, 'method_not_allowed'));
  }
  if (!isOriginAllowed(req)) {
    return sendError(res, new AppError(403, 'forbidden'));
  }
  if (!config.gemini.apiKey) {
    logger.error('GEMINI_API_KEY is not set. Add it to your environment (see .env.example).');
    return sendError(res, new AppError(503, 'not_configured'));
  }

  let slot;
  try {
    const body = await readJson(req);
    const { conversationId, messages } = validateChatBody(body);

    slot = acquireChatSlot(limitKey);
    res.setHeader('RateLimit-Limit', String(config.limits.rateMaxRequests));
    res.setHeader('RateLimit-Remaining', String(slot.remaining));

    const { contents, trimmed } = buildContext(messages);

    // Cancel the Gemini request if the browser hits Stop or disconnects.
    const clientAbort = new AbortController();
    res.on('close', () => {
      if (!res.writableEnded) clientAbort.abort();
    });

    let heartbeat = null;
    let opened = false;
    let chars = 0;

    try {
      const result = await streamChat({
        contents,
        signal: clientAbort.signal,
        onOpen: () => {
          opened = true;
          res.writeHead(200, {
            'Content-Type': 'text/event-stream; charset=utf-8',
            'Cache-Control': 'no-cache, no-transform',
            Connection: 'keep-alive',
            'X-Accel-Buffering': 'no', // tell nginx-style proxies not to buffer
          });
          if (res.socket) res.socket.setNoDelay(true);
          res.write(': tornado\n\n');
          heartbeat = setInterval(() => {
            if (!res.writableEnded) res.write(': ping\n\n');
          }, 15_000);
        },
        onText: async (text) => {
          chars += text.length;
          await sse(res, 'token', { t: text });
        },
      });
      await sse(res, 'done', { finishReason: result.finishReason, trimmed });
      res.end();
      logger.info('chat ok', { conversationId, messages: messages.length, chars: result.chars, ms: Date.now() - startedAt });
    } catch (err) {
      if (err && err.clientGone) {
        logger.info('chat cancelled by client', { conversationId, chars, ms: Date.now() - startedAt });
        if (!res.writableEnded) res.end();
        return;
      }
      const appErr = err instanceof AppError ? err : new AppError(500, 'server_error', { details: String(err && err.message) });
      if (!(err instanceof AppError)) logger.error('Unexpected chat error', { details: String(err && err.stack ? err.stack : err) });
      if (!opened && !res.headersSent) {
        sendError(res, appErr);
      } else {
        await sse(res, 'error', { code: appErr.code, message: publicMessage(appErr.code) });
        if (!res.writableEnded) res.end();
      }
      logger.warn('chat failed', { conversationId, code: appErr.code, ms: Date.now() - startedAt });
    } finally {
      if (heartbeat) clearInterval(heartbeat);
    }
  } catch (err) {
    const appErr = err instanceof AppError ? err : new AppError(500, 'server_error');
    if (!(err instanceof AppError)) logger.error('Unexpected error', { details: String(err && err.stack ? err.stack : err) });
    sendError(res, appErr);
  } finally {
    if (slot) slot.release();
  }
}

module.exports = { chatRoute, sendJson, sendError };
