'use strict';

const config = require('../config');
const { sendJson } = require('./chat');
const { stats } = require('../middleware/rateLimit');

/** Public, non-secret configuration the frontend needs. */
function configRoute(_req, res) {
  sendJson(res, 200, {
    appName: config.appName,
    maxMessageChars: config.limits.maxMessageChars,
    // true/false only - the key itself is never exposed
    ready: Boolean(config.gemini.apiKey),
  });
}

function healthRoute(_req, res) {
  sendJson(res, 200, { ok: true, ready: Boolean(config.gemini.apiKey), ...stats() });
}

module.exports = { configRoute, healthRoute };
