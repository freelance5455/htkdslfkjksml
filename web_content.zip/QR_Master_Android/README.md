# QR Master para Android

## Funciones
- Crear QR desde texto o enlaces sin conexión.
- Previsualizar y descargar como PNG.
- Compartir la imagen cuando el Android WebView lo permita; si no, descarga el PNG.
- Historial local de hasta 30 contenidos recientes.
- Escáner QR con cámara mediante ZXing Embedded; Android solicita permiso de cámara al usarlo.
- Pestaña **Archivos**: seleccionar uno o varios archivos con el selector oficial de Android, conservar una lista reciente y abrirlos con aplicaciones compatibles.
- Explorador de carpetas: elegir una carpeta del almacenamiento interno o tarjeta SD, ver sus elementos y entrar en subcarpetas.
- Compartir archivos desde el explorador o la lista de recientes mediante el menú nativo de Android; puedes elegir Bluetooth o Quick Share si están disponibles.
- La app solo ve archivos y carpetas que el usuario selecciona mediante el selector de Android; no solicita permiso para leer todo el almacenamiento. Compartir abre el menú nativo de Android y la disponibilidad de Bluetooth/Quick Share depende del dispositivo y los servicios instalados o habilitados.
- Diseño oscuro. La generación y el historial son locales; el escaneo usa la cámara del teléfono.

## Importante
La cámara se usa únicamente cuando tocas “Escanear con cámara”. El acceso a archivos usa el selector de documentos de Android (Storage Access Framework), no un escaneo total del teléfono. La dependencia ZXing se descarga al compilar el proyecto. El algoritmo de generación incluido es autocontenido y funciona offline; aun así, verifica los códigos generados con una app lectora antes de distribuir información crítica.

## Compatibilidad
- `minSdk 23` (Android 6.0+), pensado para Android moderno incluido Redmi A5.
- La interfaz se carga desde un archivo local dentro del APK.
- Los datos del historial se guardan en el almacenamiento local de WebView; borrar datos o desinstalar la app elimina el historial.

## Compilar APK
1. Abre la carpeta `QR_Master_Android` en Android Studio.
2. Deja que Android Studio descargue Gradle y el Android SDK necesarios.
3. Elige **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK de depuración: `app/build/outputs/apk/debug/app-debug.apk`.

## Estado de entrega
Se entrega el proyecto fuente y la interfaz HTML. No se afirma que haya un APK compilado: este entorno no dispone de Gradle ni Android SDK para compilar y probar el paquete. Compila con Android Studio para obtener el APK instalable.


## Compartir contenido desde el gestor

La interfaz añade opciones para seleccionar y compartir fotos, vídeos y documentos mediante el menú nativo de Android; elegir un contacto y exportarlo como archivo vCard (.vcf); y listar aplicaciones instaladas con lanzador para compartir una copia de su instalador APK. En el menú de compartir, Bluetooth o Quick Share solo aparecerán si Android y el dispositivo receptor los admiten. Compartir un APK no incluye los datos privados de la aplicación y el receptor podría tener que permitir la instalación desde esa fuente.

Estas funciones requieren compilación y pruebas en un dispositivo real. La selección de fotos/vídeos/archivos utiliza el selector del sistema, pero el gestor propio permanece dentro de QR Master.


## Transferencia directa entre teléfonos

La sección **Transferencia directa de QR Master** implementa un receptor HTTP local protegido por token y un emisor que escanea el QR del receptor y envía archivos seleccionados directamente por la red Wi-Fi. Ambos dispositivos deben tener QR Master instalado y estar en la misma red local; no se requiere Internet ni una app de compartir externa. Los archivos recibidos se guardan en el directorio privado externo de QR Master (`Android/data/com.qrmaster.app/files/Received`) y aparecen en la lista **Archivos recibidos** dentro de la aplicación. Mantén abierta la app receptora durante la transferencia y detén la recepción al terminar. El emisor copia temporalmente cada archivo a la caché para determinar su tamaño antes de transferirlo, por lo que conviene disponer de espacio libre suficiente.

La transferencia directa está añadida al código fuente, pero este entorno no dispone de Android SDK/Gradle para compilar y verificar un APK. Debe probarse en dos teléfonos Android conectados a la misma Wi-Fi antes de distribuirla.

### Exportar códigos QR
Los botones Descargar PNG y Compartir imagen usan el puente nativo de Android dentro de la app: descargar abre el selector de destino de Android y compartir envía un PNG mediante el selector del sistema. Requiere compilar e instalar la app para verificarlo en el dispositivo.

### Acceso al almacenamiento de Android
En la sección **Archivos** se añadió el botón **Permitir acceso a todos los archivos**. En Android 11 o posterior abre la pantalla especial de Ajustes de Android para que el usuario conceda el permiso manualmente. La app no puede concederse este acceso por sí sola. También conserva la opción de elegir una carpeta mediante el selector de documentos de Android, que es la alternativa compatible si no se concede el acceso amplio. La disponibilidad del permiso depende de la versión de Android y de las políticas de distribución de Google Play.
