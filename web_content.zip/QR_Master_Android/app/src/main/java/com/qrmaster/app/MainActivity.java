package com.qrmaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.util.Base64;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.provider.ContactsContract;
import android.database.Cursor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.InputStream;
import java.io.Writer;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;
import androidx.core.content.FileProvider;
import android.webkit.MimeTypeMap;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.CaptureActivity;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQUEST_FILES = 4101;
    private static final int REQUEST_FOLDER = 4102;
    private static final int REQUEST_MEDIA_SHARE = 4103;
    private static final int REQUEST_CONTACT_SHARE = 4104;
    private static final int REQUEST_TRANSFER_FILES = 4105;
    private static final int TRANSFER_PORT = 38383;
    private volatile ServerSocket transferServer;
    private volatile Thread transferThread;
    private volatile String transferToken;
    private volatile String transferTargetHost;
    private volatile int transferTargetPort;
    private volatile String transferTargetToken;
    private WebView webView;
    private Uri selectedTreeUri;
    private Uri currentFolderUri;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(13,15,22));
        getWindow().setNavigationBarColor(Color.rgb(13,15,22));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(13,15,22));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        webView.addJavascriptInterface(new WebAppInterface(), "QRMasterAndroid");
        SharedPreferences prefs = getSharedPreferences("storage", MODE_PRIVATE);
        String savedTree = prefs.getString("tree_uri", null);
        if (savedTree != null) { selectedTreeUri = Uri.parse(savedTree); currentFolderUri = DocumentsContract.buildDocumentUriUsingTree(selectedTreeUri, DocumentsContract.getTreeDocumentId(selectedTreeUri)); }
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class WebAppInterface {
        @JavascriptInterface public void scanQr() {
            runOnUiThread(() -> {
                IntentIntegrator integrator = new IntentIntegrator(MainActivity.this);
                integrator.setCaptureActivity(CaptureActivity.class);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
                integrator.setPrompt("Apunta la cámara al código QR");
                integrator.setBeepEnabled(false);
                integrator.setOrientationLocked(true);
                integrator.setBarcodeImageEnabled(false);
                integrator.initiateScan();
            });
        }
        @JavascriptInterface public void pickFiles() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, REQUEST_FILES);
            });
        }
        @JavascriptInterface public void pickFolder() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, REQUEST_FOLDER);
            });
        }
        @JavascriptInterface public void refreshFolder() {
            runOnUiThread(() -> {
                if (selectedTreeUri == null) {
                    webView.evaluateJavascript("window.onStorageMessage && window.onStorageMessage('Primero elige una carpeta del dispositivo.')", null);
                } else {
                    if (currentFolderUri == null) currentFolderUri = DocumentsContract.buildDocumentUriUsingTree(selectedTreeUri, DocumentsContract.getTreeDocumentId(selectedTreeUri));
                    sendFolderContents(selectedTreeUri, DocumentsContract.getDocumentId(currentFolderUri));
                }
            });
        }
        @JavascriptInterface public void createFolder(String name) {
            runOnUiThread(() -> {
                try {
                    if (currentFolderUri == null) throw new Exception("Primero elige una carpeta raíz.");
                    Uri created = DocumentsContract.createDocument(getContentResolver(), currentFolderUri, DocumentsContract.Document.MIME_TYPE_DIR, name);
                    if (created == null) throw new Exception("Android no pudo crear la carpeta.");
                    sendFolderContents(selectedTreeUri, DocumentsContract.getDocumentId(currentFolderUri));
                    storageMessageNative("Carpeta creada.");
                } catch (Exception e) { storageMessageNative("No se pudo crear la carpeta. Revisa los permisos de esa ubicación."); }
            });
        }
        @JavascriptInterface public void renameStoredItem(String uriText, String newName) {
            runOnUiThread(() -> {
                try {
                    Uri renamed = DocumentsContract.renameDocument(getContentResolver(), Uri.parse(uriText), newName);
                    if (renamed == null) throw new Exception("No se pudo renombrar.");
                    if (currentFolderUri != null) sendFolderContents(selectedTreeUri, DocumentsContract.getDocumentId(currentFolderUri));
                    storageMessageNative("Elemento renombrado.");
                } catch (Exception e) { storageMessageNative("No se pudo renombrar este elemento en esa ubicación."); }
            });
        }
        @JavascriptInterface public void deleteStoredItem(String uriText) {
            runOnUiThread(() -> {
                try {
                    boolean deleted = DocumentsContract.deleteDocument(getContentResolver(), Uri.parse(uriText));
                    if (!deleted) throw new Exception("No se pudo eliminar.");
                    if (currentFolderUri != null) sendFolderContents(selectedTreeUri, DocumentsContract.getDocumentId(currentFolderUri));
                    storageMessageNative("Elemento eliminado.");
                } catch (Exception e) { storageMessageNative("No se pudo eliminar este elemento. Puede que la ubicación lo impida."); }
            });
        }
        @JavascriptInterface public void browseFolder(String uriText) {
            runOnUiThread(() -> {
                try {
                    if (selectedTreeUri != null) {
                        currentFolderUri = Uri.parse(uriText);
                        sendFolderContents(selectedTreeUri, DocumentsContract.getDocumentId(currentFolderUri));
                    }
                } catch (Exception e) { storageMessageNative("No se pudo abrir esa carpeta."); }
            });
        }
        @JavascriptInterface public void browseRoot() {
            runOnUiThread(() -> {
                try {
                    if (selectedTreeUri != null) {
                        currentFolderUri = DocumentsContract.buildDocumentUriUsingTree(selectedTreeUri, DocumentsContract.getTreeDocumentId(selectedTreeUri));
                        sendFolderContents(selectedTreeUri, DocumentsContract.getTreeDocumentId(selectedTreeUri));
                    }
                } catch (Exception e) { storageMessageNative("No se pudo volver a la carpeta raíz."); }
            });
        }
        @JavascriptInterface public void openStoredItem(String uriText, String mime) {
            runOnUiThread(() -> openUri(uriText, mime));
        }
        @JavascriptInterface public void shareStoredItem(String uriText, String name, String mime) {
            runOnUiThread(() -> shareUri(uriText, name, mime));
        }
        @JavascriptInterface public void pickMediaAndShare(String kind) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String type = "image".equals(kind) ? "image/*" : ("video".equals(kind) ? "video/*" : "*/*");
                intent.setType(type);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(intent, REQUEST_MEDIA_SHARE); }
                catch (Exception e) { storageMessageNative("No se pudo abrir el selector de archivos."); }
            });
        }
        @JavascriptInterface public void pickContactAndShare() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                try { startActivityForResult(intent, REQUEST_CONTACT_SHARE); }
                catch (Exception e) { storageMessageNative("No hay una aplicación de contactos disponible."); }
            });
        }
        @JavascriptInterface public void listInstalledApps() {
            runOnUiThread(() -> {
                JSONArray apps = new JSONArray();
                try {
                    PackageManager pm = getPackageManager();
                    List<ApplicationInfo> installed = pm.getInstalledApplications(0);
                    for (ApplicationInfo app : installed) {
                        if (pm.getLaunchIntentForPackage(app.packageName) == null || getPackageName().equals(app.packageName)) continue;
                        JSONObject item = new JSONObject();
                        item.put("name", pm.getApplicationLabel(app).toString());
                        item.put("packageName", app.packageName);
                        apps.put(item);
                    }
                } catch (Exception ignored) {}
                String json = JSONObject.quote(apps.toString());
                webView.evaluateJavascript("window.onInstalledApps && window.onInstalledApps(JSON.parse(" + json + "))", null);
            });
        }
        @JavascriptInterface public void shareInstalledApp(String packageName) {
            runOnUiThread(() -> shareInstalledApk(packageName));
        }
        @JavascriptInterface public void startReceiving() {
            runOnUiThread(() -> startTransferReceiver());
        }
        @JavascriptInterface public void stopReceiving() {
            runOnUiThread(() -> stopTransferReceiver());
        }
        @JavascriptInterface public void chooseTransferTarget(String host, int port, String token) {
            runOnUiThread(() -> {
                if (host == null || host.isEmpty() || port < 1 || port > 65535 || token == null || token.length() < 8) {
                    storageMessageNative("El QR de destino no es válido."); return;
                }
                transferTargetHost = host; transferTargetPort = port; transferTargetToken = token;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(intent, REQUEST_TRANSFER_FILES); }
                catch (Exception e) { storageMessageNative("No se pudo abrir el selector de archivos."); }
            });
        }
        @JavascriptInterface public void sendStoredItemToTarget(String uriText, String host, int port, String token) {
            runOnUiThread(() -> {
                if (uriText == null || host == null || host.isEmpty() || port < 1 || port > 65535 || token == null || token.length() < 8) {
                    storageMessageNative("El QR de destino o el archivo no son válidos."); return;
                }
                try {
                    transferTargetHost = host; transferTargetPort = port; transferTargetToken = token;
                    ArrayList<Uri> files = new ArrayList<>(); files.add(Uri.parse(uriText));
                    uploadTransferFiles(files);
                } catch (Exception e) { storageMessageNative("No se pudo preparar el archivo para enviarlo por QR."); }
            });
        }
        @JavascriptInterface public void listReceivedFiles() {
            runOnUiThread(() -> {
                JSONArray arr = new JSONArray();
                File dir = getExternalFilesDir("Received");
                if (dir != null && dir.exists()) {
                    File[] files = dir.listFiles();
                    if (files != null) for (File f : files) if (f.isFile()) {
                        JSONObject o = new JSONObject();
                        try { o.put("name", f.getName()); o.put("size", f.length()); o.put("path", f.getAbsolutePath()); arr.put(o); } catch (Exception ignored) {}
                    }
                }
                webView.evaluateJavascript("window.onReceivedFiles && window.onReceivedFiles(JSON.parse(" + JSONObject.quote(arr.toString()) + "))", null);
            });
        }
        @JavascriptInterface public void openReceivedFile(String path) {
            runOnUiThread(() -> {
                try {
                    File base = getExternalFilesDir("Received"); File f = new File(path).getCanonicalFile();
                    if (base == null || !f.getParentFile().equals(base.getCanonicalFile()) || !f.isFile()) throw new Exception();
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    Intent view = new Intent(Intent.ACTION_VIEW); view.setDataAndType(uri, getContentResolver().getType(uri));
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(view);
                } catch (Exception e) { storageMessageNative("No se pudo abrir el archivo recibido."); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_FILES) {
            if (resultCode == RESULT_OK && data != null) {
                JSONArray items = new JSONArray();
                try {
                    if (data.getClipData() != null) {
                        ClipData clip = data.getClipData();
                        for (int i = 0; i < clip.getItemCount(); i++) addPickedItem(items, clip.getItemAt(i).getUri());
                    } else if (data.getData() != null) addPickedItem(items, data.getData());
                } catch (Exception ignored) {}
                String json = JSONObject.quote(items.toString());
                webView.evaluateJavascript("window.onPickedFiles && window.onPickedFiles(JSON.parse(" + json + "))", null);
            }
            return;
        }
        if (requestCode == REQUEST_MEDIA_SHARE) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    Intent send;
                    ArrayList<Uri> uris = new ArrayList<>();
                    if (data.getClipData() != null) {
                        ClipData clip = data.getClipData();
                        for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
                    } else if (data.getData() != null) uris.add(data.getData());
                    if (uris.isEmpty()) return;
                    if (uris.size() == 1) {
                        Uri uri = uris.get(0);
                        send = new Intent(Intent.ACTION_SEND);
                        String mime = getContentResolver().getType(uri);
                        send.setType(mime == null ? "*/*" : mime);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.setClipData(ClipData.newUri(getContentResolver(), getDisplayName(uri), uri));
                    } else {
                        send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        send.setType("*/*");
                        send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                        ClipData clip = ClipData.newUri(getContentResolver(), "Archivos seleccionados", uris.get(0));
                        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
                        send.setClipData(clip);
                    }
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Enviar por Bluetooth, Quick Share u otra app");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(chooser);
                    storageMessageNative("Selecciona Bluetooth o Quick Share si aparece disponible.");
                } catch (Exception e) { storageMessageNative("No se pudieron compartir los elementos seleccionados."); }
            }
            return;
        }
        if (requestCode == REQUEST_TRANSFER_FILES) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<Uri> uris = new ArrayList<>();
                if (data.getClipData() != null) { ClipData clip = data.getClipData(); for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri()); }
                else if (data.getData() != null) uris.add(data.getData());
                if (!uris.isEmpty()) uploadTransferFiles(uris);
            }
            return;
        }
        if (requestCode == REQUEST_CONTACT_SHARE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) shareContactAsVCard(data.getData());
            return;
        }
        if (requestCode == REQUEST_FOLDER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                selectedTreeUri = data.getData();
                currentFolderUri = DocumentsContract.buildDocumentUriUsingTree(selectedTreeUri, DocumentsContract.getTreeDocumentId(selectedTreeUri));
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try { getContentResolver().takePersistableUriPermission(selectedTreeUri, flags); } catch (Exception ignored) {}
                getSharedPreferences("storage", MODE_PRIVATE).edit().putString("tree_uri", selectedTreeUri.toString()).apply();
                sendFolderContents(selectedTreeUri, DocumentsContract.getTreeDocumentId(selectedTreeUri));
            }
            return;
        }
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() != null && webView != null) {
                String safe = JSONObject.quote(result.getContents());
                webView.evaluateJavascript("window.onQrScanned && window.onQrScanned(" + safe + ")", null);
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void addPickedItem(JSONArray items, Uri uri) {
        try {
            String name = getDisplayName(uri);
            String mime = getContentResolver().getType(uri);
            JSONObject item = new JSONObject();
            item.put("name", name);
            item.put("uri", uri.toString());
            item.put("mime", mime == null ? "*/*" : mime);
            item.put("folder", false);
            items.put(item);
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
    }

    private String getDisplayName(Uri uri) {
        String name = uri.getLastPathSegment() == null ? "Archivo" : uri.getLastPathSegment();
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {}
        return name;
    }

    private void sendFolderContents(Uri treeUri, String documentId) {
        JSONArray items = new JSONArray();
        String folderName = "Carpeta seleccionada";
        try {
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId);
            Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId);
            folderName = getDisplayName(docUri);
            try (Cursor c = getContentResolver().query(childrenUri,
                    new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE},
                    null, null, DocumentsContract.Document.COLUMN_DISPLAY_NAME + " ASC")) {
                if (c != null) while (c.moveToNext()) {
                    String id = c.getString(0), name = c.getString(1), mime = c.getString(2);
                    JSONObject item = new JSONObject();
                    item.put("name", name == null ? "Elemento" : name);
                    item.put("uri", DocumentsContract.buildDocumentUriUsingTree(treeUri, id).toString());
                    item.put("mime", mime == null ? "*/*" : mime);
                    item.put("folder", DocumentsContract.Document.MIME_TYPE_DIR.equals(mime));
                    int sizeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
                    if (sizeIdx >= 0 && !c.isNull(sizeIdx)) item.put("size", c.getLong(sizeIdx));
                    items.put(item);
                }
            }
        } catch (Exception e) {
            webView.evaluateJavascript("window.onStorageMessage && window.onStorageMessage('No se pudo leer esa carpeta. Prueba con otra ubicación.')", null);
            return;
        }
        String json = JSONObject.quote(items.toString());
        String safeName = JSONObject.quote(folderName);
        String safeUri = JSONObject.quote(DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId).toString());
        boolean isRoot = documentId.equals(DocumentsContract.getTreeDocumentId(treeUri));
        webView.evaluateJavascript("window.onFolderContents && window.onFolderContents(" + safeName + ", JSON.parse(" + json + "), " + safeUri + ", " + isRoot + ")", null);
    }

    private void storageMessageNative(String message) {
        if (webView != null) webView.evaluateJavascript("window.onStorageMessage && window.onStorageMessage(" + JSONObject.quote(message) + ")", null);
    }

    private void openUri(String uriText, String mime) {
        try {
            Uri uri = Uri.parse(uriText);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime == null || mime.isEmpty() ? "*/*" : mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            if (webView != null) webView.evaluateJavascript("window.onStorageMessage && window.onStorageMessage('No hay una app compatible para abrir este elemento.')", null);
        }
    }


    private void startTransferReceiver() {
        if (transferServer != null && !transferServer.isClosed()) { storageMessageNative("La recepción ya está activa."); return; }
        try {
            transferToken = UUID.randomUUID().toString().replace("-", "");
            transferServer = new ServerSocket(TRANSFER_PORT);
            transferThread = new Thread(() -> {
                while (transferServer != null && !transferServer.isClosed()) {
                    try {
                        Socket client = transferServer.accept();
                        new Thread(() -> handleTransferClient(client), "QRMaster-upload").start();
                    } catch (Exception e) { if (transferServer != null && !transferServer.isClosed()) storageMessageNative("La recepción se interrumpió."); break; }
                }
            }, "QRMaster-receiver");
            transferThread.start();
            String ip = getLocalWifiIpv4();
            if (ip == null) { stopTransferReceiver(); throw new Exception("Conecta ambos teléfonos a la misma red Wi-Fi y vuelve a intentarlo."); }
            JSONObject info = new JSONObject(); info.put("host", ip); info.put("port", TRANSFER_PORT); info.put("token", transferToken);
            String payload = "QRM1|" + ip + "|" + TRANSFER_PORT + "|" + transferToken;
            String pngData = makeTransferQrDataUri(payload);
            webView.evaluateJavascript("window.onTransferReceiverStarted && window.onTransferReceiverStarted(" + JSONObject.quote(payload) + "," + JSONObject.quote(pngData) + ")", null);
        } catch (Exception e) { storageMessageNative(e.getMessage() == null ? "No se pudo iniciar la recepción. Comprueba la conexión Wi-Fi." : e.getMessage()); }
    }

    private String makeTransferQrDataUri(String payload) throws Exception {
        BitMatrix matrix = new QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 420, 420);
        Bitmap bitmap = Bitmap.createBitmap(420, 420, Bitmap.Config.ARGB_8888);
        for (int y = 0; y < 420; y++) for (int x = 0; x < 420; x++) bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
        java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes); bitmap.recycle();
        return "data:image/png;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
    }

    private String getLocalWifiIpv4() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<java.net.InetAddress> addresses = ni.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    java.net.InetAddress address = addresses.nextElement();
                    if (address instanceof Inet4Address && !address.isLoopbackAddress() && !address.isLinkLocalAddress()) {
                        String ip = address.getHostAddress();
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.matches("172\\.(1[6-9]|2[0-9]|3[01])\\..*")) return ip;
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void stopTransferReceiver() {
        try { if (transferServer != null) transferServer.close(); } catch (Exception ignored) {}
        transferServer = null; transferToken = null;
        if (webView != null) webView.evaluateJavascript("window.onTransferReceiverStopped && window.onTransferReceiverStopped()", null);
    }

    private void handleTransferClient(Socket client) {
        try (Socket socket = client; BufferedInputStream in = new BufferedInputStream(socket.getInputStream()); BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream())) {
            socket.setSoTimeout(30000);
            String requestLine = readHttpLine(in);
            if (requestLine == null || !requestLine.startsWith("PUT /upload?")) { writeHttpResponse(out, 404, "Not found"); return; }
            String[] first = requestLine.split(" "); if (first.length < 2) { writeHttpResponse(out, 400, "Bad request"); return; }
            String query = first[1].substring(first[1].indexOf('?') + 1);
            String token = null, name = "archivo";
            for (String part : query.split("&")) {
                String[] kv = part.split("=", 2); String k = URLDecoder.decode(kv[0], "UTF-8"); String v = kv.length > 1 ? URLDecoder.decode(kv[1], "UTF-8") : "";
                if ("token".equals(k)) token = v; if ("name".equals(k)) name = v;
            }
            long length = -1;
            String line; while ((line = readHttpLine(in)) != null && !line.isEmpty()) {
                int colon = line.indexOf(':'); if (colon > 0 && "content-length".equalsIgnoreCase(line.substring(0, colon).trim())) length = Long.parseLong(line.substring(colon + 1).trim());
            }
            if (transferToken == null || !transferToken.equals(token)) { writeHttpResponse(out, 403, "Invalid token"); return; }
            if (length < 0 || length > 1024L * 1024L * 1024L) { writeHttpResponse(out, 413, "Invalid file size"); return; }
            String safeName = new File(name).getName().replaceAll("[^A-Za-z0-9._() -]", "_");
            if (safeName.isEmpty() || safeName.equals(".") || safeName.equals("..")) safeName = "archivo";
            File dir = getExternalFilesDir("Received"); if (dir == null) throw new Exception("No hay almacenamiento disponible");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("No se pudo crear la carpeta de recibidos");
            final String receivedName = safeName;
            File target = new File(dir, System.currentTimeMillis() + "_" + receivedName);
            try (FileOutputStream fileOut = new FileOutputStream(target)) {
                byte[] buffer = new byte[32768]; long remaining = length;
                while (remaining > 0) { int n = in.read(buffer, 0, (int)Math.min(buffer.length, remaining)); if (n < 0) throw new Exception("Transferencia incompleta"); fileOut.write(buffer, 0, n); remaining -= n; }
            }
            writeHttpResponse(out, 200, "OK");
            runOnUiThread(() -> { storageMessageNative("Archivo recibido: " + receivedName); webView.evaluateJavascript("window.refreshReceivedFiles && window.refreshReceivedFiles()", null); });
        } catch (Exception e) { try { BufferedOutputStream out = new BufferedOutputStream(client.getOutputStream()); writeHttpResponse(out, 500, "Transfer failed"); } catch (Exception ignored) {} }
    }

    private String readHttpLine(InputStream in) throws Exception {
        StringBuilder b = new StringBuilder(); int prev = -1, c;
        while ((c = in.read()) != -1) { if (prev == '\r' && c == '\n') { if (b.length() > 0) b.setLength(b.length() - 1); return b.toString(); } b.append((char)c); prev = c; if (b.length() > 8192) throw new Exception("HTTP header too large"); }
        return b.length() == 0 ? null : b.toString();
    }

    private void writeHttpResponse(BufferedOutputStream out, int status, String body) throws Exception {
        byte[] bytes = body.getBytes("UTF-8"); String label = status == 200 ? "OK" : (status == 403 ? "Forbidden" : (status == 404 ? "Not Found" : "Bad Request"));
        out.write(("HTTP/1.1 " + status + " " + label + "\r\nConnection: close\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: " + bytes.length + "\r\n\r\n").getBytes("UTF-8")); out.write(bytes); out.flush();
    }

    private void uploadTransferFiles(ArrayList<Uri> uris) {
        final String host = transferTargetHost; final int port = transferTargetPort; final String token = transferTargetToken;
        new Thread(() -> {
            int success = 0;
            for (Uri uri : uris) {
                try {
                    String name = getDisplayName(uri);
                    File temp = new File(getCacheDir(), "qrm-transfer-" + UUID.randomUUID().toString());
                    try (InputStream input = getContentResolver().openInputStream(uri); FileOutputStream tempOut = new FileOutputStream(temp)) {
                        if (input == null) throw new Exception("No se puede leer el archivo"); byte[] buffer = new byte[32768]; int n; while ((n = input.read(buffer)) != -1) tempOut.write(buffer, 0, n);
                    }
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection)new java.net.URL("http://" + host + ":" + port + "/upload?token=" + URLEncoder.encode(token, "UTF-8") + "&name=" + URLEncoder.encode(name, "UTF-8")).openConnection();
                    conn.setRequestMethod("PUT"); conn.setDoOutput(true); conn.setConnectTimeout(12000); conn.setReadTimeout(120000); conn.setFixedLengthStreamingMode(temp.length());
                    try (InputStream input = new FileInputStream(temp); java.io.OutputStream output = conn.getOutputStream()) {
                        byte[] buffer = new byte[32768]; int n; while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
                    }
                    int code = conn.getResponseCode(); if (code == 200) success++; conn.disconnect(); temp.delete();
                } catch (Exception ignored) {}
                final int done = success; runOnUiThread(() -> storageMessageNative("Enviando archivos por Wi-Fi… " + done + "/" + uris.size() + " completados."));
            }
            final int done = success; runOnUiThread(() -> { storageMessageNative("Transferencia terminada: " + done + " de " + uris.size() + " archivo(s) enviados."); });
        }, "QRMaster-sender").start();
    }

    private void shareContactAsVCard(Uri contactUri) {
        try {
            String id = null, name = "Contacto";
            try (Cursor c = getContentResolver().query(contactUri, new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) { id = c.getString(0); name = c.getString(1); }
            }
            if (id == null) throw new Exception("No se encontró el contacto");
            StringBuilder vcard = new StringBuilder("BEGIN:VCARD\nVERSION:3.0\n");
            vcard.append("FN:").append(escapeVCard(name)).append("\n");
            try (Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER}, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?", new String[]{id}, null)) {
                if (c != null) while (c.moveToNext()) vcard.append("TEL:").append(escapeVCard(c.getString(0))).append("\n");
            }
            try (Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Email.ADDRESS}, ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=?", new String[]{id}, null)) {
                if (c != null) while (c.moveToNext()) vcard.append("EMAIL:").append(escapeVCard(c.getString(0))).append("\n");
            }
            vcard.append("END:VCARD\n");
            File dir = new File(getCacheDir(), "shared"); if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "contacto.vcf");
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8")) { writer.write(vcard.toString()); }
            Uri shared = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/vcard"); send.putExtra(Intent.EXTRA_STREAM, shared); send.putExtra(Intent.EXTRA_TITLE, name + ".vcf");
            send.setClipData(ClipData.newUri(getContentResolver(), name + ".vcf", shared)); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "Compartir contacto por Bluetooth u otra app"));
        } catch (Exception e) { storageMessageNative("No se pudo preparar el contacto para compartir."); }
    }

    private String escapeVCard(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n").replace("\r", "");
    }

    private void shareInstalledApk(String packageName) {
        try {
            ApplicationInfo info = getPackageManager().getApplicationInfo(packageName, 0);
            String appName = getPackageManager().getApplicationLabel(info).toString();
            File dir = new File(getCacheDir(), "shared"); if (!dir.exists()) dir.mkdirs();
            ArrayList<String> sourcePaths = new ArrayList<>();
            sourcePaths.add(info.sourceDir);
            if (info.splitSourceDirs != null) for (String split : info.splitSourceDirs) sourcePaths.add(split);
            ArrayList<Uri> sharedUris = new ArrayList<>();
            int index = 0;
            for (String sourcePath : sourcePaths) {
                String suffix = index == 0 ? "base" : "split" + index;
                File apk = new File(dir, packageName.replaceAll("[^A-Za-z0-9._-]", "_") + "_" + suffix + ".apk");
                try (InputStream in = new FileInputStream(sourcePath); FileOutputStream out = new FileOutputStream(apk)) {
                    byte[] buffer = new byte[8192]; int len; while ((len = in.read(buffer)) > 0) out.write(buffer, 0, len);
                }
                sharedUris.add(FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk));
                index++;
            }
            Intent send;
            if (sharedUris.size() == 1) {
                send = new Intent(Intent.ACTION_SEND); send.putExtra(Intent.EXTRA_STREAM, sharedUris.get(0));
                send.setClipData(ClipData.newUri(getContentResolver(), appName + ".apk", sharedUris.get(0)));
            } else {
                send = new Intent(Intent.ACTION_SEND_MULTIPLE); send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, sharedUris);
                ClipData clip = ClipData.newUri(getContentResolver(), appName + " APKs", sharedUris.get(0));
                for (int i = 1; i < sharedUris.size(); i++) clip.addItem(new ClipData.Item(sharedUris.get(i)));
                send.setClipData(clip);
            }
            send.setType("application/vnd.android.package-archive"); send.putExtra(Intent.EXTRA_TITLE, appName + " APK"); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "Compartir instalador APK de " + appName));
            storageMessageNative("Se comparten los APK de instalación disponibles, no los datos privados de la aplicación.");
        } catch (Exception e) { storageMessageNative("No se pudo exportar esa aplicación como APK."); }
    }

    private void shareUri(String uriText, String name, String mime) {
        try {
            Uri uri = Uri.parse(uriText);
            String safeName = (name == null || name.isEmpty()) ? "Archivo" : name;
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime == null || mime.isEmpty() ? "*/*" : mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TITLE, safeName);
            send.setClipData(ClipData.newUri(getContentResolver(), safeName, uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Compartir archivo por Bluetooth u otra app");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
            storageMessageNative("Elige Bluetooth o Quick Share en el menú de compartir de Android, si está disponible.");
        } catch (Exception e) {
            storageMessageNative("No se pudo compartir este archivo. Comprueba que siga disponible y que tenga permisos de lectura.");
        }
    }

    @Override protected void onDestroy() { try { if (transferServer != null) transferServer.close(); } catch (Exception ignored) {} transferServer = null; super.onDestroy(); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
