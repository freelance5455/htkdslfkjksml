"use strict";
/* ===== RateFlow · ядро: хранилище, утилиты, демо-логика =====
   Все данные хранятся в localStorage браузера (это ДЕМО, без сервера). */

const DB_KEY = "rateflow_db_v2", SES_KEY = "rateflow_session_v2";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const nf = (n, d = 0) => Number(n || 0).toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d });
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const rnd = (a, b) => a + Math.random() * (b - a);
const r2 = n => Math.round(n * 100) / 100;
const pick = a => a[Math.floor(Math.random() * a.length)];
const DAY = 864e5;
const ic = (n, c = "") => `<svg class="ic ${c}" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${n}"/></svg>`;

/* ---------- хранилище ---------- */
function loadDB() { try { const v = JSON.parse(localStorage.getItem(DB_KEY)); return v && Array.isArray(v.users) ? v : { users: [] }; } catch (e) { return { users: [] }; } }
let db = loadDB();
let me = null; // текущий пользователь (ссылка на объект внутри db.users)
function saveDB() { try { localStorage.setItem(DB_KEY, JSON.stringify(db)); return true; } catch (e) { return false; } }
function reloadDB() { db = loadDB(); if (me) me = db.users.find(u => u.id === me.id) || null; }

/* ---------- справочники ---------- */
const CONTACTS = [
  { name: "Алишер Каримов", card: "5555666677778888" },
  { name: "Мадина Рахимова", card: "9999888877776666" },
  { name: "Тимур Исмаилов", card: "2222333344445555" }
];
const CATS = {
  food: ["Еда", "#ff8a3d"], transport: ["Транспорт", "#ffc15e"], subs: ["Подписки", "#d9a6ff"],
  shopping: ["Покупки", "#ff6b6b"], fun: ["Развлечения", "#6bd6ff"], health: ["Здоровье", "#5be3b0"],
  bills: ["Счета и связь", "#9aa4b2"], transfer: ["Переводы", "#e8742a"], savings: ["Накопления", "#8be16b"], income: ["Доход", "#4fd18b"], other: ["Другое", "#777"]
};
const TYPE = { deposit: "Пополнение", spend: "Покупка", transfer_out: "Перевод", transfer_in: "Входящий", income: "Доход", goal: "Копилка" };
const ST = { completed: ["Завершён", "ok"], processing: ["В обработке", "wait"], failed: ["Ошибка", "bad"] };
const PLANS = {
  Free: { price: 0, goals: 1, fee: 0.005, forecast: false, scenario: false, export: false },
  Premium: { price: 19900, goals: 10, fee: 0.0025, forecast: true, scenario: true, export: false },
  Pro: { price: 49900, goals: Infinity, fee: 0, forecast: true, scenario: true, export: true }
};
const plan = () => PLANS[(me && me.plan) || "Free"];

/* ---------- администратор ---------- */
const ADMIN_NICK = String(window.ADMIN_NICK || "Diyor").trim().toLowerCase();
const isAdminName = n => String(n || "").trim().toLowerCase() === ADMIN_NICK;
const isAdmin = () => !!(me && me.role === "admin");
function migrateDB() { // старые аккаунты: роли и замена «1111 2222 3333 4444» на случайный номер
  let ch = false;
  db.users.forEach(u => {
    if (!u.role) { u.role = "user"; ch = true; }
    if (u.card.number === "1111222233334444") { u.card.number = "0"; u.card.number = newCardNumber(); ch = true; }
  });
  if (!db.users.some(u => u.role === "admin")) { const a = db.users.find(u => isAdminName(u.name)); if (a) { a.role = "admin"; ch = true; } }
  if (ch) saveDB();
}

/* ---------- курсы валют (API из config.js) ---------- */
const API_KEY = window.API_KEY || "";
const API_URL = API_KEY && !API_KEY.includes("PASTE_") ? `https://v6.exchangerate-api.com/v6/${API_KEY}/latest/USD` : "https://open.er-api.com/v6/latest/USD";
const FALLBACK = { USD: 1, UZS: 12180, EUR: 0.92, RUB: 90 };
let RATES = null, rateStatus = "Ожидание API";
const rt = c => c === "USD" ? 1 : Number((RATES && RATES[c]) || FALLBACK[c]);
const uzs = () => rt("UZS");
const convert = (a, from, to) => a / rt(from) * rt(to);
async function fetchRates() {
  rateStatus = "Загрузка…";
  try {
    const res = await fetch(API_URL, { cache: "no-store" }); const data = await res.json();
    const rates = data.conversion_rates || data.rates;
    if (!res.ok || !rates || !rates.UZS) throw new Error("bad");
    RATES = rates; rateStatus = "API подключён";
  } catch (e) { rateStatus = RATES ? "API недоступен, показан последний курс" : "API недоступен, используется запасной курс"; }
  if (typeof onRates === "function") onRates();
}

/* ---------- отображение денег (всё хранится в USD) ---------- */
const cur = () => (me && me.prefs && me.prefs.cur) || "USD";
const fm = (usd, d = 2) => cur() === "USD" ? "$" + nf(usd, d) : nf(usd * uzs(), 0) + " UZS";
const fsign = (usd, dir, d) => (dir === "in" ? "+" : "−") + fm(Math.abs(usd), d);
const toUsd = v => cur() === "USD" ? v : v / uzs();
const fromUsd = v => cur() === "USD" ? v : v * uzs();
const unit = () => cur() === "USD" ? "$" : "UZS";
const pad2 = n => String(n).padStart(2, "0");
const fdate = ts => { const d = new Date(ts); return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };
function rel(ts) {
  const s = (Date.now() - ts) / 1000;
  if (s < 45) return "только что"; if (s < 3600) return Math.round(s / 60) + " мин назад";
  if (s < 86400) return Math.round(s / 3600) + " ч назад"; if (s < 172800) return "вчера";
  return fdate(ts).slice(0, 10);
}
const maskCard = n => n.slice(0, 4) + " •••• •••• " + n.slice(-4);
const fullCard = n => n.replace(/(.{4})/g, "$1 ").trim();

/* ---------- пользователи ---------- */
async function hashPw(pw, salt) {
  try {
    const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(salt + ":" + pw));
    return [...new Uint8Array(d)].map(x => x.toString(16).padStart(2, "0")).join("");
  } catch (e) { let h = 5381; for (const c of salt + pw) h = ((h * 33) ^ c.charCodeAt(0)) >>> 0; return "x" + h.toString(16); }
}
function newCardNumber() {
  let n;
  do { n = pick(["4", "5"]) + Array.from({ length: 15 }, () => Math.floor(Math.random() * 10)).join(""); }
  while (db.users.some(u => u.card.number === n) || CONTACTS.some(c => c.card === n));
  return n;
}
function seedTx() {
  const out = [], now = Date.now();
  const T = [["food", "Korzinka", 6, 38], ["food", "Evos", 4, 14], ["food", "Кофейня", 2, 7], ["transport", "Yandex Go", 2, 9], ["transport", "Заправка", 12, 35],
    ["shopping", "Uzum Market", 10, 90], ["shopping", "Zara", 25, 120], ["fun", "Кинотеатр", 6, 20], ["health", "Аптека", 5, 40], ["bills", "Мобильная связь", 4, 8]];
  const mk = (ts, dir, type, cat, title, amount, fee = 0, peer = null) => ({ id: uid(), ts, dir, type, cat, title, amount: r2(amount), fee, status: "completed", peer });
  for (let d = 179; d >= 0; d--) {
    const day = new Date(now - d * DAY);
    const at = () => Math.min(now - 60000, new Date(day.getFullYear(), day.getMonth(), day.getDate(), 8 + Math.floor(rnd(0, 14)), Math.floor(rnd(0, 59))).getTime());
    const n = Math.random() < .15 ? 0 : Math.random() < .5 ? 1 : 2;
    for (let i = 0; i < n; i++) { const t = pick(T); out.push(mk(at(), "out", "spend", t[0], t[1], rnd(t[2], t[3]))); }
    const dm = day.getDate();
    if (dm === 1) out.push(mk(at(), "out", "spend", "bills", "Интернет", 12));
    if (dm === 15) out.push(mk(at(), "out", "spend", "subs", "Netflix", 9.99));
    if (dm === 17) out.push(mk(at(), "out", "spend", "subs", "Spotify", 4.99));
    if (dm === 5) out.push(mk(at(), "in", "income", "income", "Зарплата", 1400 + rnd(0, 200)));
    if (dm === 20 && Math.random() < .6) out.push(mk(at(), "in", "income", "income", "Фриланс-проект", rnd(150, 420)));
    if (Math.random() < .04) { const c = pick(CONTACTS), a = rnd(30, 150); out.push(mk(at(), "out", "transfer_out", "transfer", "Перевод: " + c.name, a, r2(Math.max(.1, a * .005)), { name: c.name, card: c.card })); }
    if (Math.random() < .03) { const c = pick(CONTACTS); out.push(mk(at(), "in", "transfer_in", "income", "Перевод от " + c.name, rnd(40, 200), 0, { name: c.name, card: c.card })); }
  }
  return out.sort((a, b) => b.ts - a.ts);
}
function createUser(name, email, salt, hash) {
  const num = newCardNumber(), now = new Date();
  const tx = seedTx();
  const net = tx.reduce((s, t) => s + (t.dir === "in" ? t.amount : -(t.amount + t.fee)), 0);
  const u = {
    id: uid(), name, email, salt, hash, createdAt: Date.now(), role: isAdminName(name) ? "admin" : "user", plan: "Free", prefs: { cur: "USD" },
    card: { number: num, exp: pad2(now.getMonth() + 1) + "/" + String((now.getFullYear() + 4) % 100), cvv: String(100 + Math.floor(Math.random() * 900)), frozen: false },
    balance: r2(600 + net), tx, goals: [], budget: null, chat: [], notifs: [], ref: "RF-" + Math.random().toString(36).slice(2, 7).toUpperCase()
  };
  notify(u, { kind: "info", title: "Добро пожаловать в RateFlow", text: "Аккаунт создан. Это демо: деньги виртуальные, а история операций сгенерирована для примера." });
  db.users.push(u); saveDB(); return u;
}
function notify(u, n) { u.notifs.unshift({ id: uid(), ts: Date.now(), read: false, ...n }); u.notifs.length = Math.min(u.notifs.length, 60); }
const unreadCount = () => me ? me.notifs.filter(n => !n.read).length : 0;

/* ---------- статистика ---------- */
function monthRange(off) {
  const d = new Date(), a = new Date(d.getFullYear(), d.getMonth() + off, 1), b = new Date(d.getFullYear(), d.getMonth() + off + 1, 1);
  return { a: a.getTime(), b: b.getTime(), label: a.toLocaleDateString("ru-RU", { month: "long", year: "numeric" }), short: a.toLocaleDateString("ru-RU", { month: "short" }).replace(".", ""), days: Math.round((b - a) / DAY) };
}
function monthStats(off = 0) {
  const r = monthRange(off), list = me.tx.filter(t => t.ts >= r.a && t.ts < r.b && t.status !== "failed");
  const S = f => list.filter(f).reduce((s, t) => s + t.amount, 0);
  const spent = S(t => t.type === "spend"), sent = S(t => t.type === "transfer_out"), received = S(t => t.type === "transfer_in"),
    income = S(t => t.type === "income" || t.type === "deposit"), saved = S(t => t.type === "goal"), fees = list.reduce((s, t) => s + (t.fee || 0), 0);
  const totalIn = received + income, totalOut = spent + sent + saved + fees;
  return { ...r, list, spent, sent, received, income, saved, fees, totalIn, totalOut, net: totalIn - totalOut };
}
function catBreakdown(list) {
  const m = {};
  list.forEach(t => { if (t.dir !== "out") return; const k = t.type === "transfer_out" ? "transfer" : t.type === "goal" ? "savings" : t.cat; m[k] = (m[k] || 0) + t.amount + (t.fee || 0); });
  return Object.entries(m).map(([k, v]) => ({ k, v, label: (CATS[k] || CATS.other)[0], color: (CATS[k] || CATS.other)[1] })).sort((a, b) => b.v - a.v);
}
function series(days, n, pred) {
  const now = Date.now(), start = now - days * DAY, step = days * DAY / n, out = Array(n).fill(0);
  me.tx.forEach(t => { if (t.status === "failed" || t.ts < start || !pred(t)) return; out[Math.min(n - 1, Math.floor((t.ts - start) / step))] += t.amount; });
  const labels = out.map((_, i) => new Date(start + step * (i + .5)).toLocaleDateString("ru-RU", days > 200 ? { month: "short" } : { day: "numeric", month: "short" }).replace(".", ""));
  return { data: out, labels };
}
function balanceAgo(days) {
  const from = Date.now() - days * DAY;
  return me.balance - me.tx.filter(t => t.ts >= from && t.status !== "failed").reduce((s, t) => s + (t.dir === "in" ? t.amount : -(t.amount + t.fee)), 0);
}

/* ---------- операции ---------- */
const feeFor = usd => { const p = plan().fee; return p ? r2(Math.max(.1, usd * p)) : 0; };
function lookupCard(card) {
  const u = db.users.find(x => x.card.number === card); if (u) return { name: u.name, user: u, kind: "user" };
  const c = CONTACTS.find(x => x.card === card); if (c) return { name: c.name, kind: "contact" };
  return null;
}
function settle(u) { let ch = false; u.tx.forEach(t => { if (t.status === "processing" && Date.now() - t.ts > 4000) { t.status = "completed"; ch = true; } }); return ch; }
function completeLater(userId, txId, ms) {
  setTimeout(() => {
    const u = db.users.find(x => x.id === userId); const t = u && u.tx.find(x => x.id === txId);
    if (t && t.status === "processing") { t.status = "completed"; saveDB(); if (typeof refresh === "function") refresh(); }
  }, ms);
}
function sendTransfer(card, usd, note) {
  const fee = feeFor(usd), total = r2(usd + fee);
  if (me.card.frozen) return { err: "Карта заморожена. Разморозьте её в разделе «Карты»." };
  if (!/^\d{16}$/.test(card)) return { err: "Введите 16 цифр номера карты получателя." };
  if (card === me.card.number) return { err: "Нельзя переводить на собственную карту." };
  if (!(usd > 0)) return { err: "Введите сумму перевода." };
  if (usd > 5000) return { err: "Лимит демо-перевода — $5 000 за операцию." };
  if (total > me.balance) return { err: "Недостаточно средств: с комиссией нужно " + fm(total) + "." };
  const rec = lookupCard(card), peerName = rec ? rec.name : "Карта •••• " + card.slice(-4), now = Date.now(), id = uid();
  me.balance = r2(me.balance - total);
  me.tx.unshift({ id, ts: now, dir: "out", type: "transfer_out", cat: "transfer", title: "Перевод: " + peerName, amount: usd, fee, status: "processing", peer: { name: peerName, card }, note });
  notify(me, { kind: "out", title: "Перевод отправлен", text: "Получатель: " + peerName, amount: usd, peer: peerName });
  if (rec && rec.user) {
    const r = rec.user; r.balance = r2(r.balance + usd);
    r.tx.unshift({ id: uid(), ts: now, dir: "in", type: "transfer_in", cat: "income", title: "Перевод от " + me.name, amount: usd, fee: 0, status: "completed", peer: { name: me.name, card: me.card.number }, note });
    notify(r, { kind: "in", title: "Входящий перевод", text: "От: " + me.name + (note ? " · «" + note + "»" : ""), amount: usd, peer: me.name });
  }
  saveDB(); completeLater(me.id, id, 2200);
  return { ok: true, peerName, fee, total };
}
function simulateIncoming() {
  const c = pick(CONTACTS), usd = r2(rnd(20, 400)), now = Date.now();
  me.balance = r2(me.balance + usd);
  me.tx.unshift({ id: uid(), ts: now, dir: "in", type: "transfer_in", cat: "income", title: "Перевод от " + c.name, amount: usd, fee: 0, status: "completed", peer: { name: c.name, card: c.card } });
  notify(me, { kind: "in", title: "Входящий перевод", text: "От: " + c.name, amount: usd, peer: c.name });
  saveDB(); return { name: c.name, amount: usd };
}
function topUp(usd, method) {
  const id = uid();
  me.balance = r2(me.balance + usd);
  me.tx.unshift({ id, ts: Date.now(), dir: "in", type: "deposit", cat: "income", title: "Пополнение · " + method, amount: usd, fee: 0, status: "processing" });
  notify(me, { kind: "info", title: "Баланс пополнен", text: "Способ: " + method, amount: usd });
  saveDB(); completeLater(me.id, id, 1800);
}
function contribute(goalId, usd) {
  const g = me.goals.find(x => x.id === goalId);
  if (!g) return { err: "Цель не найдена." };
  if (!(usd > 0)) return { err: "Введите сумму взноса." };
  if (usd > me.balance) return { err: "Недостаточно средств на карте." };
  me.balance = r2(me.balance - usd); g.saved = r2(g.saved + usd);
  me.tx.unshift({ id: uid(), ts: Date.now(), dir: "out", type: "goal", cat: "savings", title: "Копилка: " + g.name, amount: usd, fee: 0, status: "completed" });
  if (g.saved >= g.cost) notify(me, { kind: "info", title: "Цель достигнута", text: "«" + g.name + "» накоплена полностью." });
  saveDB(); return { ok: true };
}
function csvExport() {
  const rows = [["Дата", "Тип", "Описание", "Сумма USD", "Комиссия USD", "Статус"]];
  me.tx.forEach(t => rows.push([fdate(t.ts), TYPE[t.type], t.title, (t.dir === "in" ? "" : "-") + t.amount, t.fee, ST[t.status][0]]));
  const csv = "﻿" + rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(";")).join("\n");
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  a.download = "rateflow-report.csv"; document.body.appendChild(a); a.click(); a.remove();
}
