"use strict";
/* ===== RateFlow · экраны (каждый раздел рисуется в свою секцию, без перелистывания) ===== */

const ui = { tool: "rates", balP: 7, chartP: 90, txPage: 1, txFilter: "all", mOff: 0, showNum: false, typing: false };
const ROUTES = {
  dashboard: { t: "Главная", i: "home" }, cards: { t: "Карты", i: "card" }, transfer: { t: "Переводы", i: "send" },
  analytics: { t: "Аналитика", i: "chart" }, tools: { t: "Инструменты", i: "calc" }, assistant: { t: "Помощник", i: "bot" },
  plans: { t: "Тарифы", i: "star" }, faq: { t: "FAQ", i: "help" }, admin: { t: "Админ", i: "shield", admin: true }
};
const greet = () => { const h = new Date().getHours(); return h < 5 ? "Доброй ночи" : h < 12 ? "Доброе утро" : h < 18 ? "Добрый день" : "Добрый вечер"; };
const head = (title, sub, right = "") => `<div class="phead"><div><h1>${title}</h1><p class="sub">${sub}</p></div>${right}</div>`;
const delta = (a, b, invert) => {
  if (!b) return ""; const p = (a - b) / b * 100, good = invert ? p <= 0 : p >= 0;
  return `<span class="chip ${good ? "up" : "down"}">${p >= 0 ? "▲" : "▼"} ${nf(Math.abs(p), 0)}%</span>`;
};
const empty = (t, s) => `<div class="empty"><b>${t}</b><span>${s}</span></div>`;

/* ---------- карта ---------- */
function cardHTML(u, reveal) {
  const n = u.card.number, shown = reveal ? fullCard(n) : n.slice(0, 4) + " **** **** " + n.slice(-4);
  return `<div class="cstack"><div class="ccard ${u.card.frozen ? "frozen" : ""}" data-tilt>
    <div class="cc-shine"></div>
    <div class="cc-top"><span class="cc-brand">RateFlow</span><svg viewBox="0 0 24 24" class="nfc"><path d="M7 6c2.5 3.5 2.5 8.5 0 12M11 4c3.5 4.5 3.5 11.5 0 16M15 2c4.5 5.5 4.5 14.5 0 20"/></svg></div>
    <div class="cc-num">${shown}</div>
    <div class="cc-meta"><div><small>Владелец</small><b>${esc(u.name.slice(0, 22))}</b></div><div><small>Срок</small><b>${u.card.exp}</b></div><div><small>CVV</small><b>${reveal ? u.card.cvv : "•••"}</b></div></div>
    <div class="cc-mc"><i></i><i></i></div>${u.card.frozen ? `<div class="cc-ice">${ic("snow")} Заморожена</div>` : ""}</div></div>`;
}

/* ---------- транзакции ---------- */
function txRow(t) {
  const c = CATS[t.cat] || CATS.other, s = ST[t.status];
  return `<div class="trow"><div class="tc t-time">${fdate(t.ts)}</div><div class="tc t-type"><i style="background:${c[1]}"></i>${TYPE[t.type]}</div>
    <div class="tc t-title">${esc(t.title)}</div><div class="tc t-amt ${t.dir}">${fsign(t.amount, t.dir)}</div>
    <div class="tc t-fee">${t.fee ? fm(t.fee) : "—"}</div><div class="tc t-st"><span class="pill ${s[1]}">${s[0]}</span></div></div>`;
}
function txPanelHTML() {
  const f = { all: () => true, in: t => t.dir === "in", out: t => t.type === "spend", tr: t => t.type.startsWith("transfer") }[ui.txFilter];
  const list = me.tx.filter(f), per = 5, pages = Math.max(1, Math.ceil(list.length / per)); ui.txPage = Math.min(ui.txPage, pages);
  const rows = list.slice((ui.txPage - 1) * per, ui.txPage * per);
  const nums = []; for (let p = 1; p <= pages; p++) if (p === 1 || p === pages || Math.abs(p - ui.txPage) <= 1) nums.push(p); else if (nums[nums.length - 1] !== "…") nums.push("…");
  return `<div class="ptop"><h3>Транзакции</h3><div class="seg">${[["all", "Все"], ["in", "Доходы"], ["out", "Расходы"], ["tr", "Переводы"]].map(([k, l]) => `<button class="${ui.txFilter === k ? "on" : ""}" data-act="txf" data-v="${k}">${l}</button>`).join("")}</div></div>
    <div class="thead trow"><div>Время</div><div>Тип</div><div>Описание</div><div>Сумма</div><div>Комиссия</div><div>Статус</div></div>
    <div class="tbody">${rows.length ? rows.map(txRow).join("") : empty("Операций пока нет", "Сделайте первый перевод или пополните карту.")}</div>
    <div class="pager"><span>Показано ${rows.length} из ${list.length}</span><div>${ui.txPage > 1 ? `<button data-act="txp" data-p="${ui.txPage - 1}" aria-label="Назад">${ic("chevl")}</button>` : ""}${nums.map(p => p === "…" ? "<span>…</span>" : `<button class="${p === ui.txPage ? "on" : ""}" data-act="txp" data-p="${p}">${p}</button>`).join("")}${ui.txPage < pages ? `<button data-act="txp" data-p="${ui.txPage + 1}" aria-label="Вперёд">${ic("chevr")}</button>` : ""}</div></div>`;
}
function balBoxHTML() {
  const days = ui.balP, was = balanceAgo(days), d = me.balance - was, pct = was > 0 ? d / was * 100 : 0;
  const per = [[1, "1д"], [7, "7д"], [30, "1м"], [90, "3м"]];
  return `<div class="ptop"><h3>Текущий баланс</h3></div><div class="seg sm">${per.map(([v, l]) => `<button class="${ui.balP === v ? "on" : ""}" data-act="balp" data-v="${v}">${l}</button>`).join("")}</div>
    <div class="bigno" data-count="${me.balance}">${fm(me.balance)}</div>
    <div class="dl ${d >= 0 ? "up" : "down"}">${d >= 0 ? "▲" : "▼"} ${fm(Math.abs(d))} · ${nf(Math.abs(pct), 1)}%</div>
    <div class="eq"><div><i class="cdot usd">$</i>USD<b>$${nf(me.balance, 2)}</b></div><div><i class="cdot uzs">С</i>UZS<b>${nf(me.balance * uzs())}</b></div><div><i class="cdot eur">€</i>EUR<b>€${nf(convert(me.balance, "USD", "EUR"), 2)}</b></div></div>`;
}
function chartBoxHTML() {
  const d = ui.chartP, n = d <= 7 ? 7 : d <= 30 ? 10 : d <= 90 ? 12 : 12;
  const inc = series(d, n, t => t.dir === "in"), out = series(d, n, t => t.dir === "out");
  const per = [[7, "7д"], [30, "1м"], [90, "3м"], [365, "1г"]];
  return `<div class="ptop"><h3>Доходы и расходы</h3></div><div class="seg sm">${per.map(([v, l]) => `<button class="${ui.chartP === v ? "on" : ""}" data-act="chp" data-v="${v}">${l}</button>`).join("")}</div>
    ${lineChart([{ data: inc.data.map(fromUsd), color: "#ff8a3d", area: true, dot: true }, { data: out.data.map(fromUsd), color: "#d8cfc7", dashed: true }], inc.labels)}
    <div class="legend"><span><i style="background:#ff8a3d"></i>Доходы ${fm(inc.data.reduce((a, b) => a + b, 0), 0)}</span><span><i style="background:#d8cfc7"></i>Расходы ${fm(out.data.reduce((a, b) => a + b, 0), 0)}</span></div>`;
}
function rateBoxHTML() {
  return `<div class="ptop"><h3>Курс сегодня</h3><button class="icb" data-act="rates" aria-label="Обновить курсы">${ic("refresh")}</button></div>
    <div class="bigno sm">${nf(rt("UZS"))}<small> UZS</small></div><div class="muted">за 1 USD</div>
    <div class="eq"><div>EUR<b>${nf(rt("UZS") / rt("EUR"))}</b></div><div>RUB<b>${nf(rt("UZS") / rt("RUB"), 1)}</b></div></div><div class="muted xs" id="rs1">${esc(rateStatus)}</div>`;
}
function goalMiniHTML() {
  const g = me.goals[0];
  if (!g) return `<h3>Финансовая цель</h3><p class="muted">Поставьте цель, и RateFlow посчитает, сколько откладывать каждый месяц.</p><button class="btn" data-act="tool" data-v="goals">${ic("plus")} Создать цель</button>`;
  const p = Math.min(100, g.saved / g.cost * 100);
  return `<h3>${esc(g.name)}</h3><div class="prog"><i style="width:${p}%"></i></div><div class="row between"><span class="muted">${fm(g.saved, 0)} из ${fm(g.cost, 0)}</span><b>${nf(p, 0)}%</b></div>`;
}

/* ---------- Главная ---------- */
function vDashboard() {
  return head(`${greet()}, <i class="serif">${esc(me.name.split(" ")[0])}</i>`, "Полный контроль над финансами: следите, управляйте и переводите деньги.", `<button class="btn primary" data-go="transfer">${ic("send")} Новый перевод</button>`) + `
  <div class="dgrid">
    <div class="dleft">
      <section class="panel"><div class="ptop"><h3>Моя карта</h3><button class="btn xs" data-go="cards">Управлять</button></div>
        ${cardHTML(me, false)}
        <div class="cmeta"><div><span>Баланс</span><b>${fm(me.balance)}</b></div><div><span>Валюта</span><b>${cur() === "USD" ? "USD / Доллар США" : "UZS / Узбекский сум"}</b></div></div>
        <div class="quick"><button class="btn" data-act="rewards">${ic("gift")}<span>Бонусы</span></button><button class="btn" data-act="referral">${ic("users")}<span>Друзья</span></button><button class="btn" data-go="transfer">${ic("history")}<span>История</span></button></div></section>
      <section class="panel" id="goalMini">${goalMiniHTML()}</section>
    </div>
    <div class="dright">
      <div class="trio">
        <section class="panel" id="balBox">${balBoxHTML()}</section>
        <section class="panel" id="chartBox">${chartBoxHTML()}</section>
        <section class="panel" id="rateBox">${rateBoxHTML()}</section>
      </div>
      <section class="panel txp" id="txBox">${txPanelHTML()}</section>
    </div>
  </div>`;
}

/* ---------- Карты ---------- */
function vCards() {
  const m = monthStats(0), cash = m.spent * 0.01;
  return head("Управление картой", "Реквизиты, заморозка, пополнение и лимиты.") + `
  <div class="two">
    <section class="panel center"><div id="bigCard">${cardHTML(me, ui.showNum)}</div>
      <div class="btnrow"><button class="btn" data-act="shownum">${ic("eye")} ${ui.showNum ? "Скрыть" : "Показать"} данные</button><button class="btn" data-act="copycard">${ic("copy")} Копировать номер</button></div>
      <div class="swrow"><div><b>Заморозить карту</b><span>Переводы и платежи будут недоступны</span></div><button class="switch ${me.card.frozen ? "on" : ""}" data-act="freeze" role="switch" aria-checked="${me.card.frozen}" aria-label="Заморозить карту"><i></i></button></div></section>
    <div class="stack">
      <section class="panel"><h3>Баланс карты</h3><div class="bigno" data-count="${me.balance}">${fm(me.balance)}</div><button class="btn primary" data-act="topup">${ic("plus")} Пополнить баланс</button></section>
      <section class="panel"><h3>Условия</h3><ul class="kv"><li><span>Тариф</span><b>${me.plan}</b></li><li><span>Комиссия за перевод</span><b>${plan().fee ? nf(plan().fee * 100, 2) + "%" : "0%"}</b></li><li><span>Лимит перевода</span><b>$5 000</b></li><li><span>Кэшбэк за месяц</span><b>${fm(cash)}</b></li><li><span>Статус</span><b>${me.card.frozen ? "Заморожена" : "Активна"}</b></li></ul></section>
    </div>
  </div>`;
}

/* ---------- Переводы ---------- */
function transferHist() {
  const l = me.tx.filter(t => t.type.startsWith("transfer")).slice(0, 8);
  return l.length ? l.map(t => `<div class="hrow"><i class="av ${t.dir}">${ic(t.dir === "in" ? "down" : "up")}</i><div><b>${esc(t.peer ? t.peer.name : t.title)}</b><span>${fdate(t.ts)} · ${ST[t.status][0]}</span></div><strong class="${t.dir}">${fsign(t.amount, t.dir)}</strong></div>`).join("") : empty("Переводов пока нет", "Отправьте первый перевод слева.");
}
function vTransfer() {
  const recent = [...new Map(me.tx.filter(t => t.type === "transfer_out" && t.peer).map(t => [t.peer.card, t.peer])).values()].slice(0, 3);
  const chips = [...recent, ...CONTACTS.filter(c => !recent.some(r => r.card === c.card))].slice(0, 4);
  return head("Переводы", "Отправляйте деньги на другие карты. Получатель увидит ваше имя и сумму в уведомлениях.") + `
  <div class="two">
    <section class="panel"><h3>Новый перевод</h3>
      <div class="from"><span>С карты</span><b>${maskCard(me.card.number)}</b><em>${fm(me.balance)}</em></div>
      <div class="chips">${chips.map(c => `<button class="btn xs" data-act="pickc" data-v="${c.card}">${esc(c.name.split(" ")[0])} · ${c.card.slice(-4)}</button>`).join("")}</div>
      <label class="fld">Карта получателя<input id="tcard" data-input="tcard" inputmode="numeric" autocomplete="off" placeholder="0000 0000 0000 0000" maxlength="19"></label>
      <div class="rec" id="trec">Введите 16 цифр</div>
      <label class="fld">Сумма, ${unit()}<input id="tamt" data-input="tamt" inputmode="decimal" autocomplete="off" placeholder="0"></label>
      <label class="fld">Комментарий (необязательно)<input id="tnote" maxlength="60" placeholder="Например, за обед"></label>
      <div class="sum" id="tsum"><div><span>Комиссия</span><b>—</b></div><div><span>К списанию</span><b>—</b></div></div>
      <div class="err" id="terr" role="alert"></div>
      <button class="btn primary wide" data-act="tnext">Продолжить ${ic("chevr")}</button></section>
    <div class="stack">
      <section class="panel"><div class="ptop"><h3>История переводов</h3></div><div id="thist">${transferHist()}</div></section>
      <section class="panel"><h3>Ваши реквизиты</h3><div class="cardno">${fullCard(me.card.number)}</div>
        <div class="btnrow"><button class="btn" data-act="copycard">${ic("copy")} Копировать</button><button class="btn" data-act="simin">${ic("down")} Получить тестовый перевод</button></div>
        <p class="muted xs">Демо: создайте второй аккаунт, переведите на его карту — при входе он увидит, от кого и сколько.</p></section>
    </div>
  </div>`;
}

/* ---------- Аналитика ---------- */
function vAnalytics() {
  const m = monthStats(ui.mOff), p = monthStats(ui.mOff - 1), cats = catBreakdown(m.list), tot = cats.reduce((s, c) => s + c.v, 0);
  const months = [-5, -4, -3, -2, -1, 0].map(o => { const s = monthStats(o); return { label: monthRange(o).short, a: s.totalIn, b: s.totalOut }; });
  const now = new Date(), elapsed = ui.mOff === 0 ? now.getDate() : m.days;
  const tips = [];
  if (cats[0]) tips.push(`Больше всего вы тратите на «${cats[0].label}»: ${fm(cats[0].v)} (${nf(cats[0].v / tot * 100, 0)}% расходов).`);
  if (p.totalOut) tips.push(`Расходы ${m.totalOut > p.totalOut ? "выросли" : "снизились"} на ${nf(Math.abs(m.totalOut - p.totalOut) / p.totalOut * 100, 0)}% по сравнению с прошлым месяцем.`);
  if (m.totalOut) tips.push(`В среднем вы тратите ${fm(m.totalOut / elapsed)} в день.`);
  if (m.totalIn) { const r = (m.totalIn - m.totalOut) / m.totalIn * 100; tips.push(r >= 20 ? `Вы откладываете ${nf(r, 0)}% дохода, это хороший результат.` : r >= 0 ? `Остаётся ${nf(r, 0)}% дохода. Ориентир по правилу 50/30/20 — 20%.` : "Расходы превышают доходы месяца: стоит пересмотреть траты."); }
  const big = m.list.filter(t => t.dir === "out").sort((a, b) => b.amount - a.amount)[0];
  if (big) tips.push(`Самая крупная операция: «${big.title}» на ${fm(big.amount)}.`);
  const avgNet = [-1, -2, -3].reduce((s, o) => s + monthStats(o).net, 0) / 3, proj = ui.mOff === 0 ? m.totalOut / elapsed * m.days : 0;
  const unlocked = plan().forecast;
  const forecast = `<div class="fc ${unlocked ? "" : "locked"}"><div class="fcg"><div><span>Прогноз расходов к концу месяца</span><b>${ui.mOff === 0 ? fm(proj, 0) : "—"}</b></div><div><span>Накопления через 6 месяцев</span><b>${fm(me.balance + avgNet * 6, 0)}</b></div></div>
    ${unlocked ? "" : `<div class="lock">${ic("lock")}<b>Прогноз доступен в Premium</b><button class="btn primary xs" data-go="plans">Открыть тарифы</button></div>`}</div>`;
  return head("Аналитика", "Сколько потрачено, переведено и получено — по месяцам.", `<div class="mnav"><button class="icb" data-act="moff" data-v="-1" aria-label="Предыдущий месяц">${ic("chevl")}</button><b>${m.label}</b><button class="icb" data-act="moff" data-v="1" aria-label="Следующий месяц" ${ui.mOff >= 0 ? "disabled" : ""}>${ic("chevr")}</button></div>`) + `
  <div class="stats">
    <div class="panel stat"><span>Потрачено</span><b>${fm(m.spent, 0)}</b>${delta(m.spent, p.spent, true)}</div>
    <div class="panel stat"><span>Переведено</span><b>${fm(m.sent, 0)}</b>${delta(m.sent, p.sent, true)}</div>
    <div class="panel stat"><span>Получено</span><b>${fm(m.totalIn, 0)}</b>${delta(m.totalIn, p.totalIn)}</div>
    <div class="panel stat"><span>Итог месяца</span><b class="${m.net >= 0 ? "pos" : "neg"}">${m.net >= 0 ? "+" : "−"}${fm(Math.abs(m.net), 0)}</b>${m.fees ? `<small class="muted">комиссии ${fm(m.fees)}</small>` : ""}</div>
  </div>
  <div class="two eq2">
    <section class="panel"><h3>Расходы по категориям</h3><div class="dwrap">${donut(cats.map(c => ({ v: fromUsd(c.v), color: c.color })), "Всего", fm(tot, 0))}
      <ul class="cl">${cats.length ? cats.map(c => `<li><i style="background:${c.color}"></i><span>${c.label}</span><b>${fm(c.v, 0)}</b><em>${nf(c.v / tot * 100, 0)}%</em></li>`).join("") : "<li class='muted'>В этом месяце расходов нет</li>"}</ul></div></section>
    <section class="panel"><h3>Доходы и расходы за 6 месяцев</h3>${barChart(months.map(x => ({ ...x, a: fromUsd(x.a), b: fromUsd(x.b) })))}<div class="legend"><span><i style="background:#ff8a3d"></i>Доходы</span><span><i style="background:#d8cfc7"></i>Расходы</span></div></section>
  </div>
  <div class="two eq2">
    <section class="panel"><h3>Выводы</h3>${tips.length ? `<ul class="tips">${tips.map(t => `<li>${t}</li>`).join("")}</ul>` : empty("Пока мало данных", "Выберите другой месяц или сделайте операции.")}</section>
    <section class="panel"><h3>Прогноз</h3>${forecast}${plan().export ? `<button class="btn wide" data-act="export">${ic("download")} Скачать отчёт (CSV)</button>` : `<p class="muted xs">Экспорт отчёта доступен в тарифе Pro.</p>`}</section>
  </div>`;
}

/* ---------- Инструменты ---------- */
function toolRates() {
  return `<div class="ptop"><h3>Курсы и конвертер</h3><span class="pill ${RATES ? "ok" : "wait"}" id="apiStatus">${esc(rateStatus)}</span></div>
    <div class="rates3"><div><span>USD / UZS</span><b>${nf(rt("UZS"))}</b></div><div><span>EUR / UZS</span><b>${nf(rt("UZS") / rt("EUR"))}</b></div><div><span>RUB / UZS</span><b>${nf(rt("UZS") / rt("RUB"), 1)}</b></div></div>
    <div class="conv"><input id="camt" data-input="conv" type="number" inputmode="decimal" value="100" aria-label="Сумма"><select id="cfrom" data-input="conv" aria-label="Из"><option>USD</option><option>EUR</option><option>RUB</option><option>UZS</option></select><span class="arrow">${ic("send")}</span><select id="cto" data-input="conv" aria-label="В"><option>UZS</option><option>USD</option><option>EUR</option><option>RUB</option></select></div>
    <div class="result" id="cres">—</div><button class="btn" data-act="rates">${ic("refresh")} Обновить курсы</button>`;
}
function toolBudget() {
  const m = monthStats(0), b = me.budget || { income: m.totalIn, expenses: m.totalOut };
  return `<h3>Умный бюджет</h3><div class="fgrid"><label class="fld">Доход за месяц, ${unit()}<input id="bi" data-input="budget" type="number" inputmode="decimal" value="${Math.round(fromUsd(b.income))}"></label>
    <label class="fld">Расходы за месяц, ${unit()}<input id="be" data-input="budget" type="number" inputmode="decimal" value="${Math.round(fromUsd(b.expenses))}"></label></div>
    <div class="rates3" id="bres"></div><div class="btnrow"><button class="btn" data-act="budgetfill">Взять из аналитики</button><button class="btn primary" data-act="budgetsave">Сохранить</button></div>`;
}
function budgetCalc() {
  const i = toUsd(Number($("#bi").value) || 0), e = toUsd(Number($("#be").value) || 0), f = i - e, p = i ? f / i * 100 : 0;
  $("#bres").innerHTML = `<div><span>Свободные деньги</span><b class="${f >= 0 ? "pos" : "neg"}">${f < 0 ? "−" : ""}${fm(Math.abs(f), 0)}</b></div><div><span>Накопления</span><b>${nf(p, 1)}%</b></div><div><span>Статус</span><b>${f > 0 ? (p >= 20 ? "Отлично" : "Можно копить") : "Пересмотрите расходы"}</b></div>
  <div class="rule"><span>Правило 50/30/20 для вашего дохода</span><b>${fm(i * .5, 0)} · ${fm(i * .3, 0)} · ${fm(i * .2, 0)}</b></div>`;
}
function toolGoals() {
  const lim = plan().goals, can = me.goals.length < lim;
  return `<div class="ptop"><h3>Финансовые цели</h3><span class="pill">${me.goals.length} / ${lim === Infinity ? "∞" : lim}</span></div>
  <div class="glist">${me.goals.length ? me.goals.map(g => { const p = Math.min(100, g.saved / g.cost * 100), left = Math.max(0, g.cost - g.saved); return `<div class="goal"><div class="row between"><b>${esc(g.name)}</b><button class="icb" data-act="gdel" data-v="${g.id}" aria-label="Удалить цель">${ic("x")}</button></div>
    <div class="prog"><i style="width:${p}%"></i></div><div class="row between"><span class="muted">${fm(g.saved, 0)} из ${fm(g.cost, 0)}</span><b>${nf(p, 0)}%</b></div>
    <div class="row between"><span class="muted">Откладывать в месяц: <b>${fm(left / g.months, 0)}</b></span><button class="btn xs" data-act="gadd" data-v="${g.id}">Пополнить</button></div></div>`; }).join("") : empty("Целей пока нет", "Создайте первую цель ниже.")}</div>
  ${can ? `<div class="fgrid3"><label class="fld">Название<input id="gn" maxlength="30" placeholder="Новый телефон"></label><label class="fld">Стоимость, ${unit()}<input id="gc" type="number" inputmode="decimal" placeholder="${unit() === "$" ? 1200 : 15000000}"></label><label class="fld">Уже накоплено, ${unit()}<input id="gs" type="number" inputmode="decimal" placeholder="0"></label><label class="fld">Срок, месяцев<input id="gm" type="number" inputmode="numeric" placeholder="12"></label></div>
  <div class="err" id="gerr" role="alert"></div><button class="btn primary" data-act="gnew">${ic("plus")} Создать цель</button>` : `<div class="upsell">${ic("lock")}<div><b>Лимит целей на тарифе ${me.plan}</b><span>Premium — до 10 целей, Pro — без ограничений.</span></div><button class="btn primary xs" data-go="plans">Тарифы</button></div>`}`;
}
function toolStress() {
  const m = monthStats(-1), b = me.budget || { income: m.totalIn, expenses: m.totalOut }, free = plan().scenario;
  return `<h3>Стресс-тест бюджета</h3><div class="fgrid"><label class="fld">Доход за месяц, ${unit()}<input id="si" data-input="stress" type="number" inputmode="decimal" value="${Math.round(fromUsd(b.income))}"></label>
    <label class="fld">Расходы за месяц, ${unit()}<input id="se" data-input="stress" type="number" inputmode="decimal" value="${Math.round(fromUsd(b.expenses))}"></label></div>
    <label class="fld">Падение дохода: <b id="spv">20%</b>${free ? "" : " · свой сценарий доступен в Premium"}<input id="sp" data-input="stress" type="range" min="5" max="60" value="20" ${free ? "" : "disabled"}></label>
    <div class="rates3" id="sres"></div>`;
}
function stressCalc() {
  const i = toUsd(Number($("#si").value) || 0), e = toUsd(Number($("#se").value) || 0), p = plan().scenario ? Number($("#sp").value) : 20;
  $("#spv").textContent = p + "%"; const ni = i * (1 - p / 100), f = ni - e, gap = Math.max(0, -f);
  $("#sres").innerHTML = `<div><span>Новый доход</span><b>${fm(ni, 0)}</b></div><div><span>Остаток за месяц</span><b class="${f >= 0 ? "pos" : "neg"}">${f < 0 ? "−" : ""}${fm(Math.abs(f), 0)}</b></div><div><span>${gap ? "Баланса хватит на" : "Статус"}</span><b>${gap ? nf(me.balance / gap, 1) + " мес." : "Бюджет выдерживает"}</b></div>`;
}
function vTools() {
  const tabs = [["rates", "Курсы"], ["budget", "Бюджет"], ["goals", "Цели"], ["stress", "Стресс-тест"]];
  const body = { rates: toolRates, budget: toolBudget, goals: toolGoals, stress: toolStress }[ui.tool]();
  return head("Инструменты", "Курсы валют, бюджет, цели и проверка на прочность.") + `<div class="seg wide-seg">${tabs.map(([k, l]) => `<button class="${ui.tool === k ? "on" : ""}" data-act="tool" data-v="${k}">${l}</button>`).join("")}</div><section class="panel tool" id="toolBody">${body}</section>`;
}
function toolPost() {
  if (ui.tool === "rates") convUpdate(); if (ui.tool === "budget") budgetCalc(); if (ui.tool === "stress") stressCalc();
}
function convUpdate() {
  const el = $("#cres"); if (!el) return;
  const a = Number($("#camt").value) || 0, f = $("#cfrom").value, t = $("#cto").value, v = convert(a, f, t);
  el.textContent = `${nf(v, t === "UZS" ? 0 : 2)} ${t}`;
}

/* ---------- Помощник ---------- */
function chatHTML() {
  const m = me.chat.length ? me.chat : [{ r: "a", t: `${greet()}, ${me.name.split(" ")[0]}! Я помощник RateFlow. Отвечаю только по сервису и финансовым услугам: переводы, карты, курсы, бюджет, накопления, тарифы. Спросите, например, сколько вы потратили за месяц.` }];
  return m.map(x => `<div class="msg ${x.r}"><div class="bub">${fmtMsg(x.t)}</div></div>`).join("") + (ui.typing ? `<div class="msg a"><div class="bub typing"><i></i><i></i><i></i></div></div>` : "");
}
function vAssistant() {
  return head("ИИ-помощник", "Отвечает только о RateFlow и финансовых услугах.") + `<div class="two chat2"><section class="panel chat"><div class="msgs" id="msgs">${chatHTML()}</div>
    <form class="ask" id="askForm" autocomplete="off"><input id="askIn" maxlength="300" placeholder="Спросите о переводах, расходах, курсах…" aria-label="Вопрос помощнику"><button class="btn primary" type="submit" aria-label="Отправить">${ic("send")}</button></form></section>
    <section class="panel"><h3>Что можно спросить</h3><div class="sugg">${SUGGEST.map(q => `<button class="btn" data-act="ask" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div><button class="btn xs ghost" data-act="clearchat">Очистить чат</button></section></div>`;
}

/* ---------- Тарифы ---------- */
function vPlans() {
  const P = [
    ["Free", "START", "Для знакомства и базового контроля денег.", "0", "UZS / навсегда", ["Курсы и конвертер", "Бюджет и аналитика", "1 финансовая цель", "Базовый стресс-тест", "Комиссия за переводы 0,5%"]],
    ["Premium", "SMART", "Для регулярного планирования и анализа.", "19 900", "UZS / месяц", ["Всё из Free", "До 10 целей", "Прогноз накоплений", "Гибкий стресс-тест", "Комиссия за переводы 0,25%"]],
    ["Pro", "PRO", "Для активных пользователей и малого бизнеса.", "49 900", "UZS / месяц", ["Всё из Premium", "Неограниченные цели", "Экспорт отчётов в CSV", "Переводы без комиссии", "Приоритетная поддержка"]]
  ];
  return head("Тарифы", "Начните бесплатно, подключайте больше возможностей по мере роста.") + `<div class="plans">${P.map(p => `<section class="panel plan ${p[0] === "Premium" ? "feat" : ""}">${p[0] === "Premium" ? "<span class='pop'>Популярный</span>" : ""}<small>${p[1]}</small><h3>${p[0]}</h3><p class="muted">${p[2]}</p>
    <div class="price">${p[3]}<small> ${p[4]}</small></div><ul>${p[5].map(x => `<li>${ic("check")}${x}</li>`).join("")}</ul>
    ${me.plan === p[0] ? `<button class="btn wide" disabled>Ваш текущий тариф</button>` : `<button class="btn ${p[0] === "Premium" ? "primary" : ""} wide" data-act="plan" data-v="${p[0]}">${p[0] === "Free" ? "Перейти на Free" : "Подключить " + p[0]}</button>`}</section>`).join("")}</div>
    <p class="muted center xs">Оплата работает в демо-режиме, деньги не списываются. Для реальных платежей нужен договор с Click, Payme или банком.</p>`;
}

/* ---------- FAQ ---------- */
function vFaq() {
  const Q = [["Это настоящий банк?", "Нет. RateFlow — демонстрационный проект: карты, деньги и платежи виртуальные."], ["Где хранятся мои данные?", "В localStorage вашего браузера. Завтра вы сможете войти в тот же аккаунт на этом устройстве и в этом браузере."],
    ["Как проверить уведомление о переводе?", "Создайте второй аккаунт, скопируйте номер его карты и отправьте перевод. Войдя во второй аккаунт, вы увидите, от кого он и на какую сумму. Ещё можно нажать «Получить тестовый перевод» в разделе «Переводы»."],
    ["Откуда берутся курсы валют?", "Из открытого API курсов. Если он недоступен, используется запасной курс. Свой ключ можно добавить в config.js."], ["Что даёт Premium и Pro?", "Прогноз накоплений, до 10 или неограниченное число целей, гибкий стресс-тест, сниженную комиссию, экспорт отчёта."],
    ["Помощник может ответить на любой вопрос?", "Нет, он отвечает только о RateFlow и финансовых услугах и отклоняет остальные темы."]];
  return head("Частые вопросы", "Коротко о главном.") + `<section class="panel faq">${Q.map(q => `<details><summary>${q[0]}</summary><p>${q[1]}</p></details>`).join("")}</section>`;
}

function vAdmin() {
  reloadDB();
  const U = db.users, tot = U.reduce((s, u) => s + u.balance, 0), tr = U.reduce((s, u) => s + u.tx.filter(t => t.type === "transfer_out").length, 0);
  return head("Админ-панель", "Все аккаунты этого браузера: баланс, тариф, заморозка и удаление.") + `
  <div class="stats"><div class="panel stat"><span>Пользователей</span><b>${U.length}</b></div><div class="panel stat"><span>Общий баланс</span><b>${fm(tot, 0)}</b></div>
    <div class="panel stat"><span>Заморожено карт</span><b>${U.filter(u => u.card.frozen).length}</b></div><div class="panel stat"><span>Переводов всего</span><b>${tr}</b></div></div>
  <section class="panel" style="margin-top:16px"><div class="ptop"><h3>Аккаунты</h3></div><div class="alist">${U.map(u => `<div class="arow">
    <div class="ainfo"><b>${esc(u.name)} ${u.role === "admin" ? '<span class="pill ok">админ</span>' : ""}</b><span>${esc(u.email)}</span></div>
    <div class="acard">${fullCard(u.card.number)}</div><div class="abal">${fm(u.balance)}</div>
    <div class="aplan"><span class="pill">${esc(u.plan)}</span>${u.card.frozen ? '<span class="pill bad">заморожена</span>' : ""}</div>
    <div class="aact"><button class="btn xs" data-act="adm_bal" data-v="${u.id}">Баланс</button><button class="btn xs" data-act="adm_plan" data-v="${u.id}">Тариф</button><button class="btn xs" data-act="adm_freeze" data-v="${u.id}">${u.card.frozen ? "Разморозить" : "Заморозить"}</button>${u.role === "admin" ? "" : `<button class="btn xs" data-act="adm_del" data-v="${u.id}">Удалить</button>`}</div></div>`).join("")}</div></section>`;
}

const VIEWS = { admin: vAdmin, dashboard: vDashboard, cards: vCards, transfer: vTransfer, analytics: vAnalytics, tools: vTools, assistant: vAssistant, plans: vPlans, faq: vFaq };
