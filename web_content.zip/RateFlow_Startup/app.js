"use strict";
/* ===== RateFlow · приложение: вход, роутер, события ===== */

let route = "dashboard", pending = null, modalTimer = 0;
const parseAmt = v => Number(String(v || "").replace(/\s/g, "").replace(",", ".")) || 0;
const reduced = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ---------- окна и уведомления ---------- */
function openModal(html, cls = "") {
  clearTimeout(modalTimer);
  const m = $("#modal");
  m.innerHTML = `<div class="mback" data-act="mclose"></div><div class="msheet glass ${cls}" role="dialog" aria-modal="true">${html}</div>`;
  m.hidden = false; requestAnimationFrame(() => m.classList.add("open"));
  const f = $("input,select", $(".msheet", m)); if (f) setTimeout(() => f.focus({ preventScroll: true }), 80);
}
function closeModal() {
  const m = $("#modal"); if (m.hidden) return;
  m.classList.remove("open"); clearTimeout(modalTimer);
  modalTimer = setTimeout(() => { m.hidden = true; m.innerHTML = ""; }, 240);
}
function toast(html, kind = "") {
  const t = document.createElement("div"); t.className = "toast glass " + kind; t.innerHTML = html;
  $("#toasts").appendChild(t); requestAnimationFrame(() => t.classList.add("in"));
  setTimeout(() => { t.classList.remove("in"); setTimeout(() => t.remove(), 400); }, 5000);
}
const toastNotif = n => toast(`<i class="av ${n.kind === "in" ? "in" : n.kind === "out" ? "out" : "info"}">${ic(n.kind === "in" ? "down" : n.kind === "out" ? "up" : "bell")}</i><div><b>${esc(n.title)}</b><span>${esc(n.text || "")}${n.amount ? " · " + (n.kind === "out" ? "−" : "+") + fm(n.amount) : ""}</span></div>`, n.kind);

/* ---------- каркас ---------- */
function renderChrome() {
  $("#nav").innerHTML = Object.entries(ROUTES).filter(([k, r]) => !r.admin || isAdmin()).map(([k, r]) => `<button data-go="${k}">${ic(r.i)}<span>${r.t}</span></button>`).join("");
  const B = [["dashboard", "Главная"], ["transfer", "Переводы"], ["analytics", "Аналитика"], ["assistant", "Помощник"]];
  $("#bnav").innerHTML = B.map(([k, t]) => `<button data-go="${k}">${ic(ROUTES[k].i)}<span>${t}</span></button>`).join("") + `<button data-act="more">${ic("menu")}<span>Ещё</span></button>`;
}
function updateBadge() {
  const n = unreadCount(), b = $("#badge"); b.textContent = n > 9 ? "9+" : n; b.hidden = !n;
}
function updateChrome() {
  $$("[data-go]", $("#shell")).forEach(b => b.classList.toggle("on", b.dataset.go === route));
  const more = $("#bnav [data-act=more]"); if (more) more.classList.toggle("on", !["dashboard", "transfer", "analytics", "assistant"].includes(route));
  $("#avatar").textContent = (me.name[0] || "?").toUpperCase(); $("#curBtn").textContent = cur();
  updateBadge();
}
function render(anim) {
  const v = $("#view"); v.innerHTML = VIEWS[route]();
  v.classList.remove("enter"); if (anim && !reduced()) { void v.offsetWidth; v.classList.add("enter"); }
  if (route === "tools") toolPost();
  if (route === "assistant") { const m = $("#msgs"); if (m) m.scrollTop = m.scrollHeight; }
  countUps();
}
function go(r, push = true) {
  if (!VIEWS[r] || (r === "admin" && !isAdmin())) r = "dashboard";
  closeModal(); route = r;
  try { sessionStorage.setItem("rf_route", r); } catch (e) { }
  if (push) { try { history.pushState({ r }, "", "#" + r); } catch (e) { } }
  updateChrome(); render(true); window.scrollTo({ top: 0, behavior: reduced() ? "auto" : "smooth" });
}
window.addEventListener("popstate", e => { if (me) go((e.state && e.state.r) || "dashboard", false); });
function refresh() { // мягкое обновление: не трогает поля ввода
  if (!me) return; updateBadge();
  if (["dashboard", "cards", "analytics", "plans"].includes(route)) render(false);
  else if (route === "transfer") { const h = $("#thist"); if (h) h.innerHTML = transferHist(); const f = $(".from em"); if (f) f.textContent = fm(me.balance); }
}
function onRates() {
  if (!me) return;
  const as = $("#apiStatus"); if (as) { as.textContent = rateStatus; as.className = "pill " + (RATES ? "ok" : "wait"); }
  if (route === "dashboard") { const rb = $("#rateBox"); if (rb) rb.innerHTML = rateBoxHTML(); }
  if (route === "tools" && ui.tool === "rates") { const g = $(".rates3"); if (g) g.innerHTML = `<div><span>USD / UZS</span><b>${nf(rt("UZS"))}</b></div><div><span>EUR / UZS</span><b>${nf(rt("UZS") / rt("EUR"))}</b></div><div><span>RUB / UZS</span><b>${nf(rt("UZS") / rt("RUB"), 1)}</b></div>`; convUpdate(); }
}
function countUps() {
  if (reduced()) return;
  $$("[data-count]").forEach(el => {
    const v = Number(el.dataset.count), t0 = performance.now();
    const tick = t => { const p = Math.min(1, (t - t0) / 800), e = 1 - Math.pow(1 - p, 3); el.textContent = fm(v * e); if (p < 1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  });
}

/* ---------- вход и регистрация ---------- */
function showAuth(mode = "register") {
  me = null; $("#shell").hidden = true; $("#auth").hidden = false;
  $$("[data-auth]").forEach(b => b.classList.toggle("on", b.dataset.auth === mode));
  $("#loginForm").hidden = mode !== "login"; $("#regForm").hidden = mode !== "register";
  window.scrollTo(0, 0);
}
function enter() {
  $("#auth").hidden = true; $("#shell").hidden = false;
  settle(me); saveDB();
  const h = location.hash.slice(1); route = VIEWS[h] ? h : (sessionStorage.getItem("rf_route") || "dashboard"); if (!VIEWS[route]) route = "dashboard";
  renderChrome(); go(route, false);
  try { history.replaceState({ r: route }, "", "#" + route); } catch (e) { }
  const fresh = me.notifs.filter(n => !n.read && n.kind === "in").slice(0, 3);
  fresh.forEach((n, i) => setTimeout(() => toastNotif(n), 600 + i * 450));
}
function logout() {
  try { localStorage.removeItem(SES_KEY); } catch (e) { }
  closeModal(); me = null; showAuth("login");
}
function startSession(u) {
  me = u; try { localStorage.setItem(SES_KEY, u.id); } catch (e) { } enter();
}
$("#regForm").addEventListener("submit", async e => {
  e.preventDefault(); const err = $("#regErr"); err.textContent = "";
  const name = $("#rn").value.trim().replace(/\s+/g, " "), email = $("#re").value.trim().toLowerCase(), pw = $("#rp").value;
  if (name.length < 2) { err.textContent = "Введите имя: минимум 2 символа."; return; }
  if (!/^\S+@\S+\.\S+$/.test(email)) { err.textContent = "Введите корректный e-mail."; return; }
  if (pw.length < 6) { err.textContent = "Пароль должен быть не короче 6 символов."; return; }
  reloadDB();
  if (isAdminName(name) && db.users.some(u => u.role === "admin")) { err.textContent = "Это имя зарезервировано. Выберите другое."; return; }
  if (db.users.some(u => u.email === email)) { err.textContent = "Аккаунт с таким e-mail уже есть. Перейдите во вкладку «Вход»."; return; }
  const salt = uid(), hash = await hashPw(pw, salt), u = createUser(name, email, salt, hash);
  if (!saveDB()) toast("Браузер не разрешает сохранять данные: аккаунт исчезнет после закрытия вкладки.", "bad");
  startSession(u);
});
$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault(); const err = $("#logErr"); err.textContent = "";
  const email = $("#le").value.trim().toLowerCase(), pw = $("#lp").value; reloadDB();
  const u = db.users.find(x => x.email === email);
  if (!u || (await hashPw(pw, u.salt)) !== u.hash) { err.textContent = "Неверный e-mail или пароль."; return; }
  startSession(u);
});

/* ---------- переводы ---------- */
function checkTransfer(card, usd) {
  const fee = feeFor(usd), total = r2(usd + fee);
  if (me.card.frozen) return "Карта заморожена. Разморозьте её в разделе «Карты».";
  if (!/^\d{16}$/.test(card)) return "Введите 16 цифр номера карты получателя.";
  if (card === me.card.number) return "Нельзя переводить на собственную карту.";
  if (!(usd > 0)) return "Введите сумму перевода.";
  if (usd > 5000) return "Лимит демо-перевода — $5 000 за операцию.";
  if (total > me.balance) return "Недостаточно средств: с комиссией нужно " + fm(total) + ".";
  return "";
}
function sumUpdate() {
  const el = $("#tsum"); if (!el) return;
  const usd = toUsd(parseAmt($("#tamt").value)), fee = feeFor(usd);
  el.innerHTML = `<div><span>Комиссия</span><b>${usd ? fm(fee) : "—"}</b></div><div><span>К списанию</span><b>${usd ? fm(usd + fee) : "—"}</b></div>`;
}
function onInput(el) {
  const k = el.dataset.input;
  if (k === "tcard") {
    const d = el.value.replace(/\D/g, "").slice(0, 16); el.value = d.replace(/(.{4})/g, "$1 ").trim();
    const rec = $("#trec");
    if (d.length === 16 && d === me.card.number) { rec.className = "rec unk"; rec.textContent = "Это ваша карта. Укажите номер карты другого аккаунта"; }
    else if (d.length === 16) { const r = lookupCard(d); rec.className = "rec " + (r ? "ok" : "unk"); rec.textContent = r ? "Получатель: " + r.name : "Карта •••• " + d.slice(-4) + " не найдена в RateFlow: перевод уйдёт как внешний"; }
    else { rec.className = "rec"; rec.textContent = d.length ? "Ещё " + (16 - d.length) + " цифр" : "Введите 16 цифр"; }
  }
  if (k === "tcard" || k === "tamt") sumUpdate();
  if (k === "conv") convUpdate(); if (k === "budget") budgetCalc(); if (k === "stress") stressCalc();
}
document.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.input) onInput(e.target); });
document.addEventListener("change", e => { if (e.target.dataset && e.target.dataset.input === "conv") convUpdate(); });

/* ---------- модальные окна ---------- */
function notifHTML(n) {
  const sign = n.kind === "out" ? "−" : "+";
  return `<div class="nrow ${n.read ? "" : "new"}"><i class="av ${n.kind === "in" ? "in" : n.kind === "out" ? "out" : "info"}">${ic(n.kind === "in" ? "down" : n.kind === "out" ? "up" : "bell")}</i>
    <div><b>${esc(n.title)}</b><span>${esc(n.text || "")}</span><em>${rel(n.ts)}</em></div>${n.amount ? `<strong class="${n.kind === "out" ? "out" : "in"}">${sign}${fm(n.amount)}</strong>` : ""}</div>`;
}
function openNotifs() {
  openModal(`<div class="mh"><h3>Уведомления</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
    <div class="nlist">${me.notifs.length ? me.notifs.map(notifHTML).join("") : empty("Уведомлений нет", "Здесь появятся входящие переводы и события по карте.")}</div>`, "tall");
  me.notifs.forEach(n => n.read = true); saveDB(); updateBadge();
}
function openProfile() {
  openModal(`<div class="mh"><h3>Профиль</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
    <div class="prof"><i class="avatar lg">${esc((me.name[0] || "?").toUpperCase())}</i><div><b>${esc(me.name)}${isAdmin() ? ' <span class="pill ok">админ</span>' : ""}</b><span>${esc(me.email)}</span></div></div>
    <ul class="kv"><li><span>Тариф</span><b>${me.plan}</b></li><li><span>Карта</span><b>${maskCard(me.card.number)}</b></li><li><span>Регистрация</span><b>${fdate(me.createdAt).slice(0, 10)}</b></li><li><span>Валюта отображения</span><b><button class="btn xs" data-act="cur">${cur()} → ${cur() === "USD" ? "UZS" : "USD"}</button></b></li></ul>
    <button class="btn wide" data-act="logout">${ic("logout")} Выйти из аккаунта</button>`);
}
function openMore() {
  openModal(`<div class="mh"><h3>Разделы</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
    <div class="more">${["cards", "tools", "plans", "faq", ...(isAdmin() ? ["admin"] : [])].map(k => `<button class="btn" data-go="${k}">${ic(ROUTES[k].i)}<span>${ROUTES[k].t}</span></button>`).join("")}<button class="btn" data-act="profile">${ic("user")}<span>Профиль</span></button></div>`);
}
function topUpModal() {
  const q = [50, 100, 500];
  openModal(`<div class="mh"><h3>Пополнить баланс</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
    <div class="chips">${q.map(v => `<button class="btn xs" data-act="tq" data-v="${Math.round(fromUsd(v))}">${fm(v, 0)}</button>`).join("")}</div>
    <label class="fld">Сумма, ${unit()}<input id="tuAmt" inputmode="decimal" placeholder="0"></label>
    <label class="fld">Способ<select id="tuMethod"><option>Click</option><option>Payme</option><option>Uzcard / Humo</option></select></label>
    <div class="err" id="tuErr" role="alert"></div>
    <p class="muted xs">Демо: деньги не списываются с реальных карт.</p>
    <button class="btn primary wide" data-act="topupgo">Пополнить</button>`);
}
function goalAddModal(id) {
  const g = me.goals.find(x => x.id === id); if (!g) return;
  openModal(`<div class="mh"><h3>Пополнить цель</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
    <p class="muted">«${esc(g.name)}»: осталось ${fm(Math.max(0, g.cost - g.saved), 0)}. На карте ${fm(me.balance)}.</p>
    <label class="fld">Сумма взноса, ${unit()}<input id="gaAmt" inputmode="decimal" placeholder="0"></label><div class="err" id="gaErr" role="alert"></div>
    <button class="btn primary wide" data-act="gago" data-v="${g.id}">Положить в копилку</button>`);
}
function planModal(name) {
  const p = PLANS[name];
  openModal(`<div class="mh"><h3>Подключить ${name}</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
    <ul class="kv"><li><span>Тариф</span><b>${name}</b></li><li><span>Стоимость</span><b>${nf(p.price)} UZS / месяц</b></li></ul>
    <label class="fld">Имя плательщика<input id="plName" value="${esc(me.name)}"></label>
    <label class="fld">Способ оплаты<select id="plMethod"><option>Click</option><option>Payme</option><option>Uzcard / Humo</option></select></label>
    <p class="muted xs">Демо-режим: оплата не проводится и деньги не списываются.</p>
    <button class="btn primary wide" data-act="plango" data-v="${name}">Подтвердить демо-покупку</button>`);
}

/* ---------- чат ---------- */
function sendAsk(q) {
  q = q.trim(); if (!q || ui.typing) return;
  me.chat.push({ r: "u", t: q }); ui.typing = true;
  const box = () => $("#msgs"), draw = () => { const m = box(); if (m && route === "assistant") { m.innerHTML = chatHTML(); m.scrollTop = m.scrollHeight; } };
  draw();
  setTimeout(() => {
    let a; try { a = answerQuestion(q); } catch (e) { a = "Не удалось обработать вопрос. Спросите о переводах, расходах или курсах валют."; }
    me.chat.push({ r: "a", t: a }); if (me.chat.length > 60) me.chat.splice(0, me.chat.length - 60);
    ui.typing = false; saveDB(); draw();
  }, reduced() ? 50 : 650 + Math.random() * 450);
}
document.addEventListener("submit", e => {
  if (e.target.id === "askForm") { e.preventDefault(); const i = $("#askIn"); const q = i.value; i.value = ""; sendAsk(q); }
});

/* ---------- действия ---------- */
function copyText(t) {
  const done = () => toast("Скопировано: " + esc(t));
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(done, () => toast("Не удалось скопировать", "bad"));
  else { const a = document.createElement("textarea"); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand("copy"); done(); } catch (e) { toast("Не удалось скопировать", "bad"); } a.remove(); }
}
function shake(el, msg) { el.textContent = msg; el.classList.remove("shake"); void el.offsetWidth; el.classList.add("shake"); }

function adminUser(id) { reloadDB(); return isAdmin() ? (db.users.find(u => u.id === id) || null) : null; }
function act(a, v, el) {
  switch (a) {
    case "adm_bal": { const u = adminUser(v); if (!u) break;
      openModal(`<div class="mh"><h3>Баланс: ${esc(u.name)}</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div><p class="muted">Сейчас ${fm(u.balance)}. Положительная сумма пополнит, отрицательная спишет.</p><label class="fld">Сумма, ${unit()}<input id="abAmt" inputmode="decimal" placeholder="например 100 или -50"></label><div class="err" id="abErr" role="alert"></div><button class="btn primary wide" data-act="adm_balgo" data-v="${u.id}">Применить</button>`); break; }
    case "adm_balgo": { const u = adminUser(v); if (!u) break; const usd = toUsd(parseAmt($("#abAmt").value));
      if (!usd) return shake($("#abErr"), "Введите сумму, не равную нулю.");
      if (Math.abs(usd) > 100000) return shake($("#abErr"), "Лимит одной операции — $100 000.");
      if (u.balance + usd < 0) return shake($("#abErr"), "Баланс не может стать отрицательным.");
      const pos = usd > 0; u.balance = r2(u.balance + usd);
      u.tx.unshift({ id: uid(), ts: Date.now(), dir: pos ? "in" : "out", type: pos ? "deposit" : "spend", cat: pos ? "income" : "other", title: pos ? "Пополнение · администратор" : "Списание · администратор", amount: r2(Math.abs(usd)), fee: 0, status: "completed", peer: null });
      notify(u, { kind: pos ? "in" : "out", title: pos ? "Баланс пополнен администратором" : "Списание администратором", text: "Корректировка баланса", amount: r2(Math.abs(usd)) });
      saveDB(); closeModal(); toast("Баланс обновлён"); render(false); updateBadge(); break; }
    case "adm_plan": { const u = adminUser(v); if (!u) break;
      openModal(`<div class="mh"><h3>Тариф: ${esc(u.name)}</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div><label class="fld">Тариф<select id="apSel">${Object.keys(PLANS).map(p => `<option ${p === u.plan ? "selected" : ""}>${p}</option>`).join("")}</select></label><button class="btn primary wide" data-act="adm_plango" data-v="${u.id}">Сохранить</button>`); break; }
    case "adm_plango": { const u = adminUser(v); if (!u) break; const p = $("#apSel").value; if (!PLANS[p]) break;
      u.plan = p; notify(u, { kind: "info", title: "Тариф изменён администратором", text: "Ваш тариф: " + p }); saveDB(); closeModal(); toast("Тариф обновлён"); render(false); updateBadge(); break; }
    case "adm_freeze": { const u = adminUser(v); if (!u) break; u.card.frozen = !u.card.frozen;
      notify(u, { kind: "info", title: u.card.frozen ? "Карта заморожена администратором" : "Карта разморожена администратором", text: "•••• " + u.card.number.slice(-4) }); saveDB(); render(false); updateBadge(); break; }
    case "adm_del": { const u = adminUser(v); if (!u || u.role === "admin") break;
      openModal(`<div class="mh"><h3>Удалить аккаунт?</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div><p class="muted">Аккаунт «${esc(u.name)}» (${esc(u.email)}) и все его данные будут удалены без возможности восстановления.</p><div class="btnrow"><button class="btn" data-act="mclose">Отмена</button><button class="btn primary" data-act="adm_delgo" data-v="${u.id}">Удалить</button></div>`); break; }
    case "adm_delgo": { const u = adminUser(v); if (!u || u.role === "admin") break; db.users = db.users.filter(x => x.id !== u.id); saveDB(); closeModal(); toast("Аккаунт удалён"); render(false); break; }
    case "mclose": closeModal(); break;
    case "notifs": openNotifs(); break;
    case "profile": openProfile(); break;
    case "more": openMore(); break;
    case "logout": logout(); break;
    case "cur": me.prefs.cur = cur() === "USD" ? "UZS" : "USD"; saveDB(); updateChrome(); render(false); if (!$("#modal").hidden && $(".prof")) openProfile(); break;
    case "txf": ui.txFilter = v; ui.txPage = 1; $("#txBox").innerHTML = txPanelHTML(); break;
    case "txp": ui.txPage = Number(el.dataset.p); $("#txBox").innerHTML = txPanelHTML(); break;
    case "balp": ui.balP = Number(v); $("#balBox").innerHTML = balBoxHTML(); countUps(); break;
    case "chp": ui.chartP = Number(v); $("#chartBox").innerHTML = chartBoxHTML(); break;
    case "rates": { const s = $("#apiStatus"); if (s) s.textContent = "Загрузка…"; fetchRates(); break; }
    case "tool": ui.tool = v; if (route !== "tools") go("tools"); else render(true); break;
    case "rewards": { const c = monthStats(0).spent * .01; openModal(`<div class="mh"><h3>Бонусы</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div><p class="muted">Кэшбэк 1% за покупки по карте.</p><div class="bigno sm">${fm(c)}</div><p class="muted xs">Начислено за ${monthRange(0).label}. Демо-расчёт на основе ваших расходов.</p>`); break; }
    case "referral": openModal(`<div class="mh"><h3>Пригласить друзей</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div><p class="muted">Ваш код приглашения:</p><div class="cardno">${me.ref}</div><button class="btn primary wide" data-act="copyref">${ic("copy")} Скопировать код</button><p class="muted xs">Демо: реальных бонусов за приглашения пока нет.</p>`); break;
    case "copyref": copyText(me.ref); break;
    case "shownum": ui.showNum = !ui.showNum; render(false); break;
    case "copycard": copyText(me.card.number); break;
    case "freeze": me.card.frozen = !me.card.frozen; notify(me, { kind: "info", title: me.card.frozen ? "Карта заморожена" : "Карта разморожена", text: "•••• " + me.card.number.slice(-4) }); saveDB(); render(false); updateBadge(); break;
    case "topup": topUpModal(); break;
    case "tq": $("#tuAmt").value = v; break;
    case "topupgo": { const val = parseAmt($("#tuAmt").value), usd = toUsd(val);
      if (!(usd > 0)) return shake($("#tuErr"), "Введите сумму пополнения.");
      if (usd > 10000) return shake($("#tuErr"), "Лимит демо-пополнения — $10 000.");
      topUp(usd, $("#tuMethod").value); closeModal(); toast(`<i class="av in">${ic("down")}</i><div><b>Баланс пополнен</b><span>+${fm(usd)}</span></div>`, "in"); refresh(); break; }
    case "simin": { reloadDB(); const r = simulateIncoming(); toastNotif(me.notifs[0]); refresh(); updateBadge(); break; }
    case "pickc": { const i = $("#tcard"); i.value = v; onInput(i); $("#tamt").focus(); break; }
    case "tnext": {
      const card = $("#tcard").value.replace(/\D/g, ""), usd = toUsd(parseAmt($("#tamt").value)), note = $("#tnote").value.trim();
      const err = checkTransfer(card, usd); if (err) return shake($("#terr"), err);
      $("#terr").textContent = ""; const rec = lookupCard(card), fee = feeFor(usd); pending = { card, usd, note };
      openModal(`<div class="mh"><h3>Подтвердите перевод</h3><button class="icb" data-act="mclose" aria-label="Закрыть">${ic("x")}</button></div>
        <ul class="kv"><li><span>Получатель</span><b>${esc(rec ? rec.name : "Внешняя карта")}</b></li><li><span>Карта</span><b>${fullCard(card)}</b></li><li><span>Сумма</span><b>${fm(usd)}</b></li><li><span>Комиссия</span><b>${fee ? fm(fee) : "0"}</b></li><li><span>К списанию</span><b>${fm(usd + fee)}</b></li>${note ? `<li><span>Комментарий</span><b>${esc(note)}</b></li>` : ""}</ul>
        <div class="btnrow"><button class="btn" data-act="mclose">Отмена</button><button class="btn primary" data-act="tsend">Отправить</button></div>`);
      break; }
    case "tsend": {
      const p = pending; if (!p) return; pending = null; reloadDB();
      const rec = lookupCard(p.card), res = sendTransfer(p.card, p.usd, p.note);
      if (res.err) { closeModal(); toast(esc(res.err), "bad"); break; }
      openModal(`<div class="done"><i class="okmark">${ic("check")}</i><h3>Перевод отправлен</h3><p class="muted">${esc(res.peerName)} получит ${fm(p.usd)}.${rec && rec.user ? " Получатель увидит уведомление с вашим именем и суммой при входе в аккаунт." : ""}</p><button class="btn primary wide" data-act="mclose">Готово</button></div>`);
      updateBadge(); if (route === "transfer") render(false); break; }
    case "moff": ui.mOff = Math.max(-24, Math.min(0, ui.mOff + Number(v))); render(false); break;
    case "export": csvExport(); break;
    case "budgetfill": { const m = monthStats(0); $("#bi").value = Math.round(fromUsd(m.totalIn)); $("#be").value = Math.round(fromUsd(m.totalOut)); budgetCalc(); break; }
    case "budgetsave": me.budget = { income: toUsd(Number($("#bi").value) || 0), expenses: toUsd(Number($("#be").value) || 0) }; saveDB(); toast("Бюджет сохранён"); break;
    case "gnew": {
      const name = $("#gn").value.trim(), cost = toUsd(parseAmt($("#gc").value)), saved = toUsd(parseAmt($("#gs").value)), months = Math.round(Number($("#gm").value));
      if (!name) return shake($("#gerr"), "Введите название цели."); if (!(cost > 0)) return shake($("#gerr"), "Укажите стоимость цели.");
      if (saved < 0 || saved > cost) return shake($("#gerr"), "Накоплено не может быть больше стоимости."); if (!(months >= 1 && months <= 600)) return shake($("#gerr"), "Срок — от 1 до 600 месяцев.");
      if (me.goals.length >= plan().goals) return shake($("#gerr"), "Лимит целей на вашем тарифе исчерпан.");
      me.goals.push({ id: uid(), name, cost: r2(cost), saved: r2(saved), months }); saveDB(); render(false); toast("Цель создана"); break; }
    case "gdel": me.goals = me.goals.filter(g => g.id !== v); saveDB(); render(false); break;
    case "gadd": goalAddModal(v); break;
    case "gago": { const r = contribute(v, toUsd(parseAmt($("#gaAmt").value))); if (r.err) return shake($("#gaErr"), r.err); closeModal(); toast("Взнос добавлен"); updateBadge(); render(false); break; }
    case "ask": go("assistant"); sendAsk(v); break;
    case "clearchat": me.chat = []; saveDB(); render(false); break;
    case "plan": if (v === "Free") { me.plan = "Free"; notify(me, { kind: "info", title: "Тариф изменён", text: "Вы перешли на Free." }); saveDB(); render(false); updateBadge(); toast("Тариф Free"); } else planModal(v); break;
    case "plango": {
      const b = $(".msheet .btn.primary"); b.disabled = true; b.textContent = "Обрабатываем…";
      setTimeout(() => { me.plan = v; notify(me, { kind: "info", title: "Тариф " + v + " подключён", text: "Демо-покупка подтверждена, деньги не списаны." }); saveDB(); closeModal(); updateBadge(); render(false); toast(`<i class="av in">${ic("check")}</i><div><b>Тариф ${v}</b><span>Демо-подключение выполнено</span></div>`, "in"); }, reduced() ? 50 : 900); break; }
  }
}

document.addEventListener("click", e => {
  const au = e.target.closest("[data-auth]"); if (au) { showAuth(au.dataset.auth); return; }
  const g = e.target.closest("[data-go]"); if (g) { go(g.dataset.go); return; }
  const a = e.target.closest("[data-act]"); if (a) act(a.dataset.act, a.dataset.v, a);
});
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

/* стеклянные блики и наклон карты */
document.addEventListener("pointermove", e => {
  if (!e.target.closest) return;
  const t = e.target.closest("[data-tilt]");
  if (t && !reduced()) { const r = t.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; t.style.setProperty("--ry", (x * 14) + "deg"); t.style.setProperty("--rx", (-y * 14) + "deg"); t.style.setProperty("--sx", (x + .5) * 100 + "%"); }
  const g = e.target.closest(".glass,.btn,.panel"); if (g) { const r = g.getBoundingClientRect(); g.style.setProperty("--mx", (e.clientX - r.left) + "px"); g.style.setProperty("--my", (e.clientY - r.top) + "px"); }
});
document.addEventListener("pointerout", e => {
  const t = e.target.closest && e.target.closest("[data-tilt]");
  if (t && !t.contains(e.relatedTarget)) { t.style.setProperty("--rx", "0deg"); t.style.setProperty("--ry", "0deg"); }
});

/* уведомления из другой вкладки (второй аккаунт в этом же браузере) */
window.addEventListener("storage", e => {
  if (e.key !== DB_KEY || !me) return;
  const seen = new Set(me.notifs.map(n => n.id)); reloadDB();
  if (!me) { showAuth("login"); return; }
  me.notifs.filter(n => !seen.has(n.id) && !n.read).slice(0, 3).forEach(toastNotif);
  refresh();
});
setInterval(() => { if (me && settle(me)) { saveDB(); refresh(); } }, 3000);

/* ---------- запуск ---------- */
(function boot() {
  reloadDB(); migrateDB(); let sid = null; try { sid = localStorage.getItem(SES_KEY); } catch (e) { }
  me = db.users.find(u => u.id === sid) || null;
  fetchRates();
  if (me) enter(); else showAuth(db.users.length ? "login" : "register");
})();
