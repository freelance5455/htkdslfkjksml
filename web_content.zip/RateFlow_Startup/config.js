window.API_KEY="PASTE_YOUR_API_KEY_HERE";

window.PAYMENT_PROVIDER="DEMO";

// Имя (ник) администратора: аккаунт с таким именем получает доступ к админ-панели
window.ADMIN_NICK="Diyor";
