"use strict";
/* ===== RateFlow · графики на чистом SVG/HTML ===== */

function smoothPath(pts) {
  if (pts.length < 2) return "";
  let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2, k = 6;
    d += ` C${(p1[0] + (p2[0] - p0[0]) / k).toFixed(1)},${(p1[1] + (p2[1] - p0[1]) / k).toFixed(1)} ${(p2[0] - (p3[0] - p1[0]) / k).toFixed(1)},${(p2[1] - (p3[1] - p1[1]) / k).toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
  }
  return d;
}

/* lines: [{data:[...], color, dashed, area, dot}] */
function lineChart(lines, labels) {
  const W = 360, H = 170, px = 8, top = 14, bot = 22;
  const max = Math.max(1, ...lines.flatMap(l => l.data)) * 1.12, n = lines[0].data.length;
  const X = i => px + i * (W - px * 2) / Math.max(1, n - 1), Y = v => top + (H - top - bot) * (1 - v / max);
  let g = "";
  for (let i = 0; i <= 3; i++) { const y = top + (H - top - bot) * i / 3; g += `<line x1="${px}" x2="${W - px}" y1="${y}" y2="${y}" class="gl"/>`; }
  const li = [0, Math.floor((n - 1) / 2), n - 1].map(i => `<text x="${i === 0 ? px : i === n - 1 ? W - px : X(i)}" y="${H - 5}" text-anchor="${i === 0 ? "start" : i === n - 1 ? "end" : "middle"}" class="gt">${esc(labels[i] || "")}</text>`).join("");
  const paths = lines.map((l, k) => {
    const pts = l.data.map((v, i) => [X(i), Y(v)]), d = smoothPath(pts), last = pts[pts.length - 1];
    const area = l.area ? `<path d="${d} L${last[0]},${H - bot} L${pts[0][0]},${H - bot} Z" fill="url(#ga${k})" class="garea"/>` : "";
    return `<defs><linearGradient id="ga${k}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${l.color}" stop-opacity=".35"/><stop offset="1" stop-color="${l.color}" stop-opacity="0"/></linearGradient></defs>${area}
      <path d="${d}" pathLength="1" class="gline ${l.dashed ? "dashed" : ""}" stroke="${l.color}"/>${l.dot ? `<circle cx="${last[0]}" cy="${last[1]}" r="3.6" fill="${l.color}" class="gdot"/>` : ""}`;
  }).join("");
  return `<svg viewBox="0 0 ${W} ${H}" class="lchart" role="img" aria-label="График">${g}${paths}${li}</svg>`;
}

/* segs: [{v,color,label}] */
function donut(segs, centerTop, centerBottom) {
  const total = segs.reduce((s, x) => s + x.v, 0);
  if (!total) return `<div class="donut empty"><svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="15.9155" class="dtrack"/></svg><div class="dc"><b>—</b><small>нет расходов</small></div></div>`;
  let off = 25, out = "";
  segs.forEach((s, i) => {
    const p = s.v / total * 100, len = Math.max(0.1, p - (segs.length > 1 ? 1 : 0));
    out += `<circle cx="21" cy="21" r="15.9155" fill="none" stroke="${s.color}" stroke-width="4.2" stroke-dasharray="${len} ${100 - len}" stroke-dashoffset="${off}" class="dseg" style="animation-delay:${i * 90}ms"/>`;
    off -= p;
  });
  return `<div class="donut"><svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="15.9155" class="dtrack"/>${out}</svg><div class="dc"><small>${centerTop}</small><b>${centerBottom}</b></div></div>`;
}

/* months: [{label,a,b}] */
function barChart(months) {
  const max = Math.max(1, ...months.flatMap(m => [m.a, m.b]));
  return `<div class="bars">${months.map((m, i) => `<div class="bcol"><div class="bpair">
    <i class="bar in" style="height:${Math.max(2, m.a / max * 100)}%;animation-delay:${i * 70}ms" title="Доходы ${fm(m.a, 0)}"></i>
    <i class="bar out" style="height:${Math.max(2, m.b / max * 100)}%;animation-delay:${i * 70 + 40}ms" title="Расходы ${fm(m.b, 0)}"></i></div><span>${esc(m.label)}</span></div>`).join("")}</div>`;
}
