<?php if (!isset($pageTitle)) $pageTitle = 'Tide'; ?>
<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($pageTitle) ?> — Tide</title><link rel="stylesheet" href="style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php"><span class="brand-mark">t.</span><span>Tide<span class="brand-dot">.</span></span></a>
<nav><a href="index.php">Главная</a><a href="about.php">О проекте</a>
<?php if (is_logged_in()): ?><a href="dashboard.php">Кабинет</a><a class="nav-cta" href="logout.php">Выйти</a>
<?php else: ?><a href="login.php">Вход</a><a class="nav-cta" href="register.php">Регистрация</a><?php endif; ?></nav></header>
<main class="container">