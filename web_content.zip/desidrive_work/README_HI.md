# Desi Drive Android Project

यह Android Studio का source project है। इसमें आपकी HTML गेम `app/src/main/assets/index.html` में रखी गई है और `MainActivity.kt` इसे `file:///android_asset/index.html` से खोलता है।

## Android Studio में APK बनाने के चरण
1. ZIP को Extract करें।
2. Android Studio में `DesiDrive` नाम वाला project folder खोलें (वही folder जिसमें `settings.gradle.kts` है)।
3. Gradle Sync पूरा होने दें। Project को JDK 17 और Android SDK Platform 35 की जरूरत है।
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** चुनें।
5. APK यहाँ बनेगा: `app/build/outputs/apk/debug/app-debug.apk`

## जरूरी जाँच
- HTML का सही स्थान: `app/src/main/assets/index.html`
- ऐप का WebView URL: `file:///android_asset/index.html`
- यह प्रोजेक्ट लोकल HTML गेम चलाता है; गेम के लिए इंटरनेट की जरूरत नहीं है।

## ध्यान दें
यह source project है, पहले से बना हुआ APK नहीं। इस वातावरण में Android SDK/Gradle build और वास्तविक फोन पर परीक्षण नहीं किया गया है। पुराने APK को हटाकर इस project से नया APK बनाकर इंस्टॉल करें।
