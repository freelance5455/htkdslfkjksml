package com.electricityservice.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.PermissionRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 401;
    private static final int APP_PERMISSION_REQUEST = 402;
    private static final int NATIVE_CAMERA_REQUEST = 403;
    private LocationManager locationManager;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setGeolocationEnabled(true);
        webView.addJavascriptInterface(new AndroidGPS(), "AndroidGPS");
        webView.addJavascriptInterface(new AndroidCamera(), "AndroidCamera");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean cameraAllowed = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
                    if (cameraAllowed) request.grant(request.getResources()); else request.deny();
                });
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try { startActivityForResult(Intent.createChooser(intent, "Gallery నుంచి ఫోటో ఎంచుకోండి"), FILE_CHOOSER_REQUEST); }
                catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Gallery తెరవలేకపోయింది. ఫోన్‌లో Photos/Gallery యాప్ ఉందో చూడండి.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean granted = Build.VERSION.SDK_INT < 23 ||
                    (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED);
                callback.invoke(origin, granted, false);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        requestAppPermissions();
    }

    private void requestAppPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            java.util.ArrayList<String> needed = new java.util.ArrayList<>();
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CAMERA);
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), APP_PERMISSION_REQUEST);
        }
    }

    private void openNativeCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(getPackageManager()) != null) startActivityForResult(intent, NATIVE_CAMERA_REQUEST);
            else runJs("onNativeCameraError('ఈ ఫోన్‌లో కెమెరా యాప్ అందుబాటులో లేదు')");
        } catch (Exception e) { runJs("onNativeCameraError('కెమెరా తెరవలేకపోయాం. Camera permission తనిఖీ చేయండి.')"); }
    }

    private void runJs(String js) {
        if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private class AndroidCamera {
        @JavascriptInterface public void openCamera() { runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, APP_PERMISSION_REQUEST);
                Toast.makeText(MainActivity.this, "Camera permission Allow చేసి మళ్లీ నొక్కండి", Toast.LENGTH_LONG).show();
            } else openNativeCamera();
        }); }
    }

    private class AndroidGPS {
        @JavascriptInterface public String getLocation() {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return "PERMISSION_REQUIRED";
            try {
                Location last = null;
                if (checkLocationPermission()) {
                    if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (last == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
                return last == null ? "UNAVAILABLE" : String.format(java.util.Locale.US, "%.6f,%.6f", last.getLatitude(), last.getLongitude());
            } catch (Exception e) { return "UNAVAILABLE"; }
        }
        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, APP_PERMISSION_REQUEST);
                    runJs("onNativeLocationError('Location permission Allow చేసి మళ్లీ GPS నొక్కండి')");
                    return;
                }
                try {
                    Location last = null;
                    if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (last == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (last != null) { sendLocation(last); return; }
                    String provider = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
                    locationManager.requestSingleUpdate(provider, new LocationListener() {
                        @Override public void onLocationChanged(Location loc) { sendLocation(loc); }
                        @Override public void onProviderEnabled(String p) {}
                        @Override public void onProviderDisabled(String p) { runJs("onNativeLocationError('ఫోన్ Settingsలో Location/GPS ON చేయండి')"); }
                        @Override public void onStatusChanged(String p, int status, Bundle extras) {}
                    }, getMainLooper());
                    runJs("onNativeLocationWaiting()");
                } catch (SecurityException e) { runJs("onNativeLocationError('Location permission Allow చేయండి')"); }
                  catch (Exception e) { runJs("onNativeLocationError('GPS స్థానం దొరకలేదు. Location ON చేసి మళ్లీ ప్రయత్నించండి')"); }
            });
        }
    }

    private boolean checkLocationPermission() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void sendLocation(Location loc) {
        String value = String.format(java.util.Locale.US, "%.6f,%.6f", loc.getLatitude(), loc.getLongitude());
        runJs("onNativeLocationSuccess('" + value + "')");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == APP_PERMISSION_REQUEST && webView != null) webView.reload();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if ((results == null || results.length == 0) && resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        } else if (requestCode == NATIVE_CAMERA_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getExtras() != null) {
                Object obj = data.getExtras().get("data");
                if (obj instanceof Bitmap) {
                    Bitmap bitmap = (Bitmap) obj;
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out);
                    String encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                    runJs("onNativePhotoCaptured('data:image/jpeg;base64," + encoded + "')");
                } else runJs("onNativeCameraError('ఫోటో అందలేదు. మళ్లీ ప్రయత్నించండి')");
            } else runJs("onNativeCameraError('ఫోటో తీయడం రద్దు చేశారు')");
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
