var tutorialKind = 'basic';

/* =========================
   页面切换
========================= */

function hideScreens(){
  [
    'menuScreen',
    'settingsScreen',
    'levelScreen',
    'customBattleScreen',
    'shopScreen',
    'codexScreen',
    'guideScreen',
    'guideBasicScreen',
    'guideHateScreen',
    'guideJobsScreen',
    'guideStatusScreen',
    'selectScreen',
    'gameScreen'
  ].forEach(id=>{
    const el=$(id);
    if(el)el.classList.add('hidden');
  });
}

function cancelTimers(){
  if(enemyTimer!==null)clearTimeout(enemyTimer);
  enemyTimer=null;

  if(resultTimer!==null)clearTimeout(resultTimer);
  resultTimer=null;
}

function invalidateBattle(){
  cancelTimers();
  battleToken++;
  if(s)s.done=true;
}

function showMenu(){
  hideTutorialModal();
  tutorialMode=false; tutorialStage=0;
  customBattleActive=false;
  invalidateBattle();
  if(typeof updateCoinDisplay==='function')updateCoinDisplay();
  hideScreens();
  $('menuScreen').classList.remove('hidden');
  $('overlay').classList.remove('show');
}

function showLevels(){
  if(tutorialMode){showGuide();return;}
  customBattleActive=false;
  invalidateBattle();
  if(typeof renderLevelCoins==='function')renderLevelCoins();
  $('overlay').classList.remove('show');
  hideScreens();
  $('levelScreen').classList.remove('hidden');
}


function showShop(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('shopScreen').classList.remove('hidden');
  renderShop();
}
function renderShop(){
  updateCoinDisplay();
  const owned=isCharacterUnlocked('detectiveTuffy');
  const card=$('detectiveTuffyShopCard');
  if(!card)return;
  const button=$('buyDetectiveTuffyBtn');
  if(owned){button.textContent='已购买';button.disabled=true;}
  else if(playerSave.coins<3){button.textContent='需要3金币';button.disabled=true;}
  else{button.textContent='花费3金币购买';button.disabled=false;}
}
function buyDetectiveTuffy(){
  if(isCharacterUnlocked('detectiveTuffy'))return;
  if(playerSave.coins<3){showLocalAlert('金币不足，需要3枚金币才能购买侦探泰菲。');return;}
  showLocalConfirm('确定花费3枚金币购买侦探泰菲吗？',()=>{
    if(playerSave.coins<3){showLocalAlert('金币不足，需要3枚金币才能购买侦探泰菲。');return;}
    playerSave.coins-=3;playerSave.unlockedCharacters.push('detectiveTuffy');persistSave();renderShop();showLocalAlert('购买成功！侦探泰菲已解锁。');
  });
}
function renderLevelCoins(){
  for(let level=1;level<=4;level++){
    const el=$('levelCoin'+level);
    if(!el)continue;
    const cleared=!!(playerSave&&playerSave.clearedLevels.includes(level));
    el.textContent=cleared?'🪙✓':'🪙';
    el.classList.toggle('collected',cleared);
    el.title=cleared?'首次通关金币已领取':'首次通关可获得1枚金币';
  }
}

function showCodex(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('codexScreen').classList.remove('hidden');
  renderCodexUnlockStates();
  switchCodexTab('mice');
}
function switchCodexTab(tab){
  const mice=tab!=='enemies';
  $('codexMicePanel').classList.toggle('hidden',!mice);
  $('codexEnemiesPanel').classList.toggle('hidden',mice);
  $('codexMiceTab').classList.toggle('active',mice);
  $('codexEnemiesTab').classList.toggle('active',!mice);
  $('codexMiceTab').classList.toggle('primary-btn',mice);
  $('codexMiceTab').classList.toggle('secondary-btn',!mice);
  $('codexEnemiesTab').classList.toggle('primary-btn',!mice);
  $('codexEnemiesTab').classList.toggle('secondary-btn',mice);
  $('codexMiceTab').setAttribute('aria-selected',String(mice));
  $('codexEnemiesTab').setAttribute('aria-selected',String(!mice));
}
function renderCodexUnlockStates(){
  document.querySelectorAll('#codexMicePanel [data-character-id]').forEach(card=>{
    const id=card.dataset.characterId;
    const unlocked=isCharacterUnlocked(id);
    let status=card.querySelector('.codex-unlock-status');
    if(!status){status=document.createElement('span');status.className='codex-unlock-status';const heading=card.querySelector('h3');if(heading)heading.insertAdjacentElement('afterend',status);}
    status.textContent=unlocked?'✓ 已解锁':'🔒 未解锁';
    status.classList.toggle('locked',!unlocked);
  });
}

function switchGuideModule(module){
  const info = module !== 'practice';
  const infoPanel = $('guideInfoPanel');
  const practicePanel = $('guidePracticePanel');
  const infoTab = $('guideInfoTab');
  const practiceTab = $('guidePracticeTab');
  if(infoPanel) infoPanel.classList.toggle('hidden', !info);
  if(practicePanel){
    practicePanel.classList.toggle('hidden', info);
    practicePanel.setAttribute('aria-hidden', info ? 'true' : 'false');
  }
  if(infoTab){infoTab.classList.toggle('active', info);infoTab.setAttribute('aria-selected', info ? 'true' : 'false');}
  if(practiceTab){practiceTab.classList.toggle('active', !info);practiceTab.setAttribute('aria-selected', info ? 'false' : 'true');}
}

function showGuide(){
  hideTutorialModal();
  invalidateBattle();
  tutorialMode=false; tutorialStage=0;
  customBattleActive=false;
  setTutorialControls(false,false);
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideScreen').classList.remove('hidden');
}

function setTutorialControls(active,failed){
  const setHidden=(id,hidden)=>{const el=$(id);if(el)el.classList.toggle('hidden',hidden);};
  setHidden('battleChangeTeamBtn',active);
  setHidden('battleBackLevelsBtn',active);
  // 教学进行中不能主动重开；只有失败结算后才显示重开按钮。
  setHidden('battleRestartBtn',active&&!failed);
  setHidden('resultRestartBtn',active&&!failed);
  setHidden('resultChangeTeamBtn',active);
  setHidden('resultBackLevelsBtn',active);
  const forcedFirstVisit = active && typeof firstVisitForcedTutorial!=='undefined' && firstVisitForcedTutorial;
  setHidden('resultBackGuideBtn',!active || forcedFirstVisit);
  const exitBtn=$('battleExitBtn');
  if(exitBtn){
    setHidden('battleExitBtn',forcedFirstVisit);
    exitBtn.textContent=active?'返回新手必看':(customBattleActive?'返回主菜单':'返回选关');
    exitBtn.onclick=active?(forcedFirstVisit?()=>{}:showGuide):(customBattleActive?showMenu:showLevels);
  }
  const resultBackBtn=$('resultBackLevelsBtn');
  if(resultBackBtn){
    resultBackBtn.textContent=customBattleActive?'返回主菜单':'返回选关';
    resultBackBtn.onclick=customBattleActive?showMenu:showLevels;
  }
}

function confirmTutorialStart(){showLocalConfirm('教学关将使用固定阵容：杰瑞对战一只鸭皇，不能更换角色。现在要开始教学吗？',()=>{tutorialKind='basic';startTutorial();});}
function confirmHateTutorialStart(){showLocalConfirm('仇恨教学关将固定使用剑客杰瑞与恶魔杰瑞，对战鸭皇1和鸭皇2，不能更换角色。现在开始吗？',()=>{tutorialKind='hate';startTutorial();});}
function startTutorial(){
  invalidateBattle();
  tutorialMode=true; tutorialStage=0; customBattleActive=false;
  selectedTeam=tutorialKind==='hate'?['swordsman','demon']:['jerry']; selectedLevel=1;
  $('overlay').classList.remove('show'); hideScreens();
  $('gameScreen').classList.remove('hidden');
  setTutorialControls(true,false);
  $('gameTitle').textContent=tutorialKind==='hate'?'教学关：仇恨机制':'教学关：基础战斗';
  $('teamSubtitle').textContent=tutorialKind==='hate'?'固定阵容：剑客杰瑞、恶魔杰瑞 vs 鸭皇1、鸭皇2。教学关不影响通关奖励。':'固定阵容：杰瑞 vs 鸭皇。教学关不影响通关奖励。';
  s=initial();
  $('logList').innerHTML=''; $('fxLayer').innerHTML='';
  log(`教学开始！我方出战：${s.allies.map(a=>a.name).join('、')}。`,'system');
  render();
  if(tutorialKind==='hate'){tutorialStage=0;showTutorialModal('仇恨是中立性效果，既会导致一名角色遭到围攻，也会令其他角色处于相对安全的环境。本期教学我们用恶魔杰瑞作为代表，试着使用三叉戟造成仇恨吧！','开始行动');}
  else showTutorialModal('这是一个回合制游戏。你需要在一轮轮的行动中消灭所有敌方。现在试试杰瑞的大铁锤吧！','开始行动');
}
let tutorialModalUnlockTimer=null;
function showTutorialModal(message,buttonText='下一步'){
  if(!tutorialMode)return;
  if(tutorialModalUnlockTimer!==null){clearInterval(tutorialModalUnlockTimer);tutorialModalUnlockTimer=null;}
  const button=$('tutorialModalButton');
  $('tutorialModalText').textContent=message;
  button.disabled=true;
  let remaining=3;
  button.textContent=`请等待 ${remaining} 秒…`;
  $('tutorialModal').classList.add('show');
  // 每次教学提示都至少等待3秒，避免玩家误触跳过说明。
  tutorialModalUnlockTimer=setInterval(()=>{
    remaining--;
    if(remaining>0){
      button.textContent=`请等待 ${remaining} 秒…`;
      return;
    }
    clearInterval(tutorialModalUnlockTimer);
    tutorialModalUnlockTimer=null;
    button.disabled=false;
    button.textContent=buttonText;
  },1000);
}
function hideTutorialModal(){
  if(tutorialModalUnlockTimer!==null){clearInterval(tutorialModalUnlockTimer);tutorialModalUnlockTimer=null;}
  const button=$('tutorialModalButton');
  if(button)button.disabled=false;
  const modal=$('tutorialModal');
  if(modal)modal.classList.remove('show');
}
function tutorialContinue(){
  if(!tutorialMode||!s||s.done)return;
  hideTutorialModal();
  if(tutorialKind==='hate'){
    if(tutorialStage===1){tutorialStage=1;render();}
    else if(tutorialStage===3){tutorialStage=3;render();}
    else if(tutorialStage===4){tutorialStage=4;render();}
    else if(tutorialStage>=6){
      // 最后一个仇恨教学弹窗关闭后，刷新界面以解除所有技能的教学禁用。
      tutorialStage=6;
      render();
    }
    return;
  }
  if(tutorialStage===1){
    tutorialEnemyHit(2);
  }else if(tutorialStage===2){
    tutorialStage=2;
    render();
  }else if(tutorialStage===3){
    tutorialEnemyHit(4);
  }else if(tutorialStage===4){
    tutorialStage=5;
    render();
  }
}
function tutorialEnemyHit(nextStage){
  if(!tutorialMode||!s||s.done)return;
  const battle=s;
  const token=battle.token;
  battle.phase='enemy';
  render();
  setTimeout(()=>{
    if(!tutorialMode||!validBattle(battle,token)||battle.phase!=='enemy')return;
    const jerry=battle.allies.find(a=>a.id==='jerry'&&a.hp>0);
    const duck=battle.enemies.find(e=>e.id==='tutorial-duck'&&e.hp>0);
    if(jerry&&duck){
      const damageBase=20;
      let damage=damageBase;
      if(jerry.reduction>0){damage=Math.round(damage*.7);jerry.reduction--;}
      playSound('duck');
      skillLabel(duck.id,'🦆 鸭皇攻击！');
      projectile(duck.id,jerry.id,'🦆');
      jerry.hp=Math.max(0,jerry.hp-damage);
      damageFX(jerry.id,damage,'💥');
      // 保持普通战斗记录：这里只记录真实的战斗行为，不写教学说明。
      log(`鸭皇攻击杰瑞，造成${damage}点伤害。`,'bad');
      render();
    }
    if(endCheck())return;
    setTimeout(()=>{
      if(!tutorialMode||!validBattle(battle,token)||battle.phase!=='enemy')return;
      battle.phase='player';
      battle.round++;
      battle.allies.forEach(a=>a.acted=false);
      battle.enemies.forEach(e=>e.acted=false);
      tutorialStage=nextStage;
      render();
      if(nextStage===2){
        showTutorialModal('敌人行动完毕后，会重新回到我方回合。每名角色除了基础攻击手段外，通常还会有一个特殊技能。现在试试杰瑞的团队防护吧！');
      }else if(nextStage===4){
        showTutorialModal('每名角色的特殊技能都不同。杰瑞的团队防护可以减少受到的伤害。已经没什么要教你的了，试着完成这场战斗吧。即便以后出现多人战斗，底层规则也不会变。','开始自由战斗');
      }
    },1050);
  },550);
}

function showGuideBasic(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideBasicScreen').classList.remove('hidden');
}

/* 🔥 仇恨介绍页面 */
function showGuideHate(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideHateScreen').classList.remove('hidden');
}

/* 🎩 职业的区分页面 */
function showGuideJobs(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideJobsScreen').classList.remove('hidden');
}

/* 💫 通用状态介绍页面 */
function showGuideStatus(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('guideStatusScreen').classList.remove('hidden');
}

function exitGame(){
  $('exitMessage').textContent=
    '浏览器通常不允许网页直接关闭用户主动打开的标签页。你可以关闭当前浏览器标签页退出游戏。';
}


/* =========================
   自定义战斗
========================= */
const customEnemyOptions=[
  {id:'duck',name:'鸭皇',icon:'🦆',hp:100,desc:'普通攻击：20伤害'},
  {id:'box',name:'拳头盒子',icon:'🥊',hp:150,desc:'拳头重击：20伤害，可能眩晕'},
  {id:'captain',name:'鸭皇队长',icon:'🚩',hp:200,desc:'蓄力后召唤随从'},
  {id:'mistress',name:'女主人',icon:'👩‍🦰',hp:150,desc:'蓄力后发动群体扫帚攻击'}
];
function showCustomBattle(){
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('customBattleScreen').classList.remove('hidden');
  customBattleActive=false;
  renderCustomBattle();
}
function renderCustomBattle(){
  $('customEnemyGrid').innerHTML=customEnemyOptions.map(e=>{
    const count=customSelectedEnemies.filter(id=>id===e.id).length;
    return `<article class="custom-pick-card ${count?'selected':''}">
      <div class="pick-avatar">${e.icon}</div><h3>${e.name}</h3><p>HP：${e.hp}</p><p>${e.desc}</p>
      <div class="pick-state">已选择 ${count} 名</div>
      <div class="custom-enemy-controls"><button type="button" ${count===0?'disabled':''} onclick="removeCustomEnemy('${e.id}')" aria-label="减少${e.name}">−</button><button type="button" ${customSelectedEnemies.length>=3?'disabled':''} onclick="toggleCustomEnemy('${e.id}')" aria-label="增加${e.name}">＋</button></div>
    </article>`;
  }).join('');
  $('customAllyGrid').innerHTML=Object.values(characterData).map(c=>{
    const unlocked=isCharacterUnlocked(c.id),chosen=customSelectedAllies.includes(c.id);
    return `<article class="custom-pick-card ${chosen?'selected':''} ${unlocked?'':'locked'}" role="button" tabindex="${unlocked?0:-1}" aria-pressed="${chosen}" aria-disabled="${!unlocked}" ${unlocked?`onclick="toggleCustomAlly('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleCustomAlly('${c.id}')}`+'}"':''}>
      <div class="pick-avatar">${c.icon}</div><h3>${c.name}</h3><p>HP：${c.max}</p><p>${c.desc}</p><div class="pick-state">${!unlocked?'🔒 未解锁':chosen?'✓ 已选择':'点击选择'}</div></article>`;
  }).join('');
  const selectedEnemyNames=[...new Set(customSelectedEnemies)].map(id=>{
    const option=customEnemyOptions.find(e=>e.id===id);
    const count=customSelectedEnemies.filter(x=>x===id).length;
    return `${option.name}x${count}`;
  });
  $('customEnemySelectedList').innerHTML=selectedEnemyNames.length
    ?`<strong>已选敌人：</strong>${selectedEnemyNames.map(name=>`<span class="custom-selected-enemy-tag">${name}</span>`).join(' ')}`
    :'<span class="muted">尚未选择敌人</span>';
  $('customEnemyCount').textContent=`已选择 ${customSelectedEnemies.length} / 3`;
  $('customAllyCount').textContent=`已选择 ${customSelectedAllies.length} / 3`;
  const valid=customSelectedEnemies.length>=1&&customSelectedAllies.length>=1;
  $('startCustomBattleBtn').disabled=!valid;
  $('customBattleHint').textContent=valid
    ?`已选择 ${customSelectedAllies.length} 名角色与 ${customSelectedEnemies.length} 名敌人。自定义战斗无法获得金币。`
    :'至少选择1名敌人和1名已解锁角色；两边均最多选择3名。';
}
function toggleCustomEnemy(id){
  if(customSelectedEnemies.length<3)customSelectedEnemies.push(id);
  else $('customBattleHint').textContent='敌人最多选择3名，请先减少一名。';
  renderCustomBattle();
}
function removeCustomEnemy(id){
  const index=customSelectedEnemies.lastIndexOf(id);
  if(index>=0)customSelectedEnemies.splice(index,1);
  renderCustomBattle();
}
function toggleCustomAlly(id){
  if(!isCharacterUnlocked(id))return;
  if(customSelectedAllies.includes(id))customSelectedAllies=customSelectedAllies.filter(x=>x!==id);
  else if(customSelectedAllies.length<3)customSelectedAllies.push(id);
  else $('customBattleHint').textContent='角色最多选择3名，请先取消一名。';
  renderCustomBattle();
}
function startCustomBattle(){
  if(customSelectedEnemies.length<1||customSelectedAllies.length<1)return;
  if(customSelectedAllies.some(id=>!isCharacterUnlocked(id)))return;
  customBattleActive=true;
  setTutorialControls(false,false);
  selectedLevel=0;
  selectedTeam=customSelectedAllies.slice();
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('gameScreen').classList.remove('hidden');
  $('gameTitle').textContent='自定义战斗';
  $('teamSubtitle').textContent=`出战队伍：${selectedTeam.map(id=>characterData[id].name).join('、')}。自定义战斗无法获得金币。`;
  restart();
}

/* =========================
   选关与队伍选择
========================= */

function changeTeam(){
  if(customBattleActive){showCustomBattle();return;}
  invalidateBattle();
  $('overlay').classList.remove('show');
  hideScreens();
  $('selectScreen').classList.remove('hidden');
  renderSelection();
}

function chooseLevel(level){
  customBattleActive=false;
  invalidateBattle();
  selectedLevel=level;
  selectedTeam=[];
  $('overlay').classList.remove('show');
  hideScreens();
  $('selectScreen').classList.remove('hidden');
  renderSelection();
}

function teamSize(){
  return selectedLevel===4?3:2;
}

function renderSelection(){
  const labels={
    1:'见面礼（鸭皇、拳头盒子）',
    2:'鸭皇围攻（三只鸭皇）',
    3:'鸭皇队长（鸭皇、鸭皇队长）',
    4:'全明星阵容（女主人、鸭皇队长、拳头盒子）'
  };

  const required=teamSize();

  $('levelSubtitle').textContent=
    `当前选择：第${selectedLevel}关 · ${labels[selectedLevel]}。请选择${required}名出战角色。`;

  const enemyPreviewData={
    1:[{id:'duck',name:'鸭皇',icon:'🦆',hp:100,skills:'普通攻击：造成20点伤害。'},
       {id:'box',name:'拳头盒子',icon:'🥊',hp:150,skills:'拳头重击：造成20点伤害，首次命中尝试附加眩晕。'}],
    2:[1,2,3].map(n=>({id:'duck'+n,name:'鸭皇'+n,icon:'🦆',hp:100,skills:'普通攻击：造成20点伤害。'})),
    3:[{id:'duck',name:'鸭皇',icon:'🦆',hp:100,skills:'普通攻击：造成20点伤害。'},
       {id:'captain',name:'鸭皇队长',icon:'🚩',hp:200,skills:'蓄力后召唤一只随从鸭皇。'}],
    4:[{id:'mistress',name:'女主人',icon:'👩‍🦰',hp:150,skills:'进行长时间蓄力后发动致命一击。'},
       {id:'captain',name:'鸭皇队长',icon:'🚩',hp:200,skills:'蓄力后召唤一只随从鸭皇。'},
       {id:'box',name:'拳头盒子',icon:'🥊',hp:150,skills:'拳头重击：造成20点伤害，首次命中尝试附加眩晕。'}]
  };
  currentEnemyPreview=enemyPreviewData[selectedLevel];
  $('enemyPreview').innerHTML=currentEnemyPreview.map((e,i)=>`
    <article class="enemy-preview-card">
      <button class="info-button" aria-label="查看${e.name}属性技能" onclick="event.stopPropagation();showEnemyInfoByIndex(${i})">!</button>
      <div class="pick-avatar">${e.icon}</div><h3>${e.name}</h3><p>HP：${e.hp}</p>
    </article>`).join('');

  $('selectGrid').innerHTML=Object.values(characterData).map(c=>{
    const unlocked=isCharacterUnlocked(c.id);
    const chosen=selectedTeam.includes(c.id);

    return `
      <article class="select-card ${chosen?'chosen':''} ${unlocked?'':'locked'}"
        role="button"
        tabindex="0"
        aria-pressed="${chosen}"
        onclick="${unlocked?`toggleCharacter('${c.id}')`:`showLocalAlert('侦探泰菲尚未解锁，请前往商店购买。')`}"
        onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();${unlocked?`toggleCharacter('${c.id}')`:`showLocalAlert('侦探泰菲尚未解锁，请前往商店购买。')`}}">
        <button class="info-button" aria-label="查看${c.name}属性技能" onclick="event.stopPropagation();showCharacterInfo('${c.id}')">!</button>
        <div class="pick-avatar">${c.icon}</div>
        <h3>${c.name}</h3>
        <p>HP：${c.max}</p>
        <p>${c.desc}</p>
        <div class="pick-state">${!unlocked?'🔒 未解锁':chosen?'✓ 已选择':'点击选择'}</div>
      </article>
    `;
  }).join('');

  $('selectionCount').textContent=`已选择 ${selectedTeam.length} / ${required}`;
  $('confirmTeamBtn').disabled=selectedTeam.length!==required;

  $('selectHint').textContent=selectedTeam.length===required
    ?`当前队伍：${selectedTeam.map(id=>characterData[id].name).join('、')}。确认后开始第${selectedLevel}关。`
    :`请选择${required}名角色。`;
}

let currentEnemyPreview=[];
function showEnemyInfoByIndex(index){const e=currentEnemyPreview[index];if(e)showEnemyInfo(e.id,e.name,e.icon,e.hp,e.skills);}
const characterSkillInfo={
  jerry:{skills:['大铁锤：对一名存活敌人造成25点伤害。','团队防护：全体存活队友获得30%减伤，抵挡2次敌方攻击。'],type:'八面玲珑'},
  shirley:{skills:['拳击：随机对一名存活敌人造成20伤害。','爱心花束：为所有存活队友恢复各自最大HP的20%。'],type:'支援'},
  tuffy:{skills:['火箭筒：对所有存活敌人造成20点伤害。','奶酪蛋糕：增加30点最大HP并恢复35点当前HP，效果持续至敌方下一轮全体行动结束。'],type:'八面玲珑'},
  swordsman:{skills:['剑舞：对一名存活敌人造成30点伤害。','格挡：敌方本轮行动结束前免疫控制；受击存活后反击40点伤害，冷却1回合。'],type:'主攻手'},
  demon:{skills:['三叉戟：对一名敌人造成25点伤害，并施加持续一轮的仇恨效果。','诅咒符纸：选择一名我方角色施加诅咒并吸引敌方仇恨；敌人攻击诅咒角色后，其下一次攻击伤害降低30%。技能冷却1回合。'],type:'支援'},
  detectiveTuffy:{skills:['光线攻击：对一名存活敌人造成25点伤害。','分身：创造一个50 HP的分身；分身在创造当回合即可行动，唯一行动是对一名敌人造成20点伤害或空过。分身存在时，侦探泰菲受到的所有单次伤害（包括群体攻击）均转移给分身。分身死亡后立即从场上移除；冷却3回合，且场上已有分身时不可使用。'],type:'八面玲珑'}
};
function showCharacterInfo(id){
  const c=characterData[id], info=characterSkillInfo[id];
  if(!c||!info)return;
  $('characterInfoContent').innerHTML=`<div class="info-hero">${c.icon}</div><h1 id="characterInfoTitle">${c.name}</h1><p class="codex-type">${info.type}</p><p><b>生命值：</b>${c.max} HP</p><h2>技能与属性</h2><ul class="info-skills">${info.skills.map(x=>`<li>${x}</li>`).join('')}</ul>`;
  $('characterInfoScreen').classList.remove('hidden');
}
function showEnemyInfo(id,name,icon,hp,skills){
  $('characterInfoContent').innerHTML=`<div class="info-hero">${icon}</div><h1 id="characterInfoTitle">${name}</h1><p class="codex-type">敌方角色</p><p><b>生命值：</b>${hp} HP</p><h2>属性与技能</h2><ul class="info-skills"><li>${skills}</li></ul>`;
  $('characterInfoScreen').classList.remove('hidden');
}
function closeCharacterInfo(){
  $('characterInfoScreen').classList.add('hidden');
}
function toggleCharacter(id){
  const required=teamSize();

  if(selectedTeam.includes(id)){
    selectedTeam=selectedTeam.filter(x=>x!==id);
  }else{
    if(selectedTeam.length>=required){
      $('selectHint').textContent=
        `已经选满${required}名角色。请先取消一名，再选择其他角色。`;
      return;
    }
    selectedTeam.push(id);
  }

  renderSelection();
}

function confirmTeam(){
  if(selectedTeam.length!==teamSize())return;
  customBattleActive=false;

  hideScreens();
  $('gameScreen').classList.remove('hidden');

  const titles={
    1:'第一关：见面礼',
    2:'第二关：鸭皇围攻',
    3:'第三关：鸭皇队长',
    4:'第四关：全明星阵容'
  };

  $('gameTitle').textContent=titles[selectedLevel];
  $('teamSubtitle').textContent=
    `出战队伍：${selectedTeam.map(id=>characterData[id].name).join('、')}。`;

  restart();
}