/* =========================
   战斗动画
========================= */

function fxZoomFactor(){
  const zoom=parseFloat(getComputedStyle(document.body).zoom);
  return Number.isFinite(zoom)&&zoom>0?zoom:1;
}

function unitCenter(id){
  const el=$('card-'+id);
  const zoom=fxZoomFactor();

  if(!el)return{x:innerWidth/(2*zoom),y:innerHeight/(2*zoom)};

  // getBoundingClientRect() returns on-screen coordinates; fixed FX nodes inside
  // a zoomed body need coordinates in the body's pre-zoom CSS coordinate space.
  const r=el.getBoundingClientRect();
  return{
    x:(r.left+r.width/2)/zoom,
    y:(r.top+r.height/2)/zoom
  };
}

function fxNode(cls,text,x,y,duration=900){
  const el=document.createElement('div');

  el.className='fx '+cls;
  el.textContent=text;
  el.style.left=x+'px';
  el.style.top=y+'px';
  el.style.transform='translate(-50%,-50%)';

  $('fxLayer').appendChild(el);
  setTimeout(()=>el.remove(),duration);

  return el;
}

function projectile(fromId,toId,emoji){
  const a=unitCenter(fromId);
  const b=unitCenter(toId);
  const el=fxNode('projectile',emoji,a.x,a.y,520);

  el.style.setProperty('--dx',(b.x-a.x)+'px');
  el.style.setProperty('--dy',(b.y-a.y)+'px');
}

function damageFX(id,damage,emoji='💥'){
  const p=unitCenter(id);

  fxNode('impact',emoji,p.x,p.y,600);
  fxNode('damage-number','-'+damage,p.x,p.y-15,900);
}

function healFX(fromId,toId,amount){
  const a=unitCenter(fromId);
  const b=unitCenter(toId);

  fxNode('cake-float','🍰',a.x,a.y,900);
  fxNode('heal-glow','',b.x,b.y,950);
  fxNode('impact','💚',b.x,b.y,650);

  if(amount>0){
    fxNode('heal-number','+'+amount,b.x,b.y-12,950);
  }
}

function bouquetFX(id,amount){
  const p=unitCenter(id);

  fxNode('heal-glow','',p.x,p.y,950);
  fxNode('impact','💐',p.x,p.y,650);

  if(amount>0){
    fxNode('heal-number','+'+amount,p.x,p.y-12,950);
  }
}

function shieldFX(id,text='🛡️ 防御！'){
  const p=unitCenter(id);

  fxNode('shield-ring','',p.x,p.y,900);
  fxNode('shield-text',text,p.x,p.y-28,1000);
}
function rocketReadyFX(id){
  const p=unitCenter(id);
  fxNode('rocket-flash','🚀',p.x,p.y,550);
}

function skillLabel(id,text){
  const p=unitCenter(id);
  const extra=window.gameSettings?Number(window.gameSettings.skillFloatExtraSeconds||0)*1000:0;
  fxNode('skill-label',text,p.x,p.y-48,1100+extra);
}

function stunFX(id){
  const p=unitCenter(id);
  fxNode('stun-stars','⭐💫⭐',p.x,p.y-22,1050);
}
