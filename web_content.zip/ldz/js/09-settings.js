(function(){
  const DEFAULT_SETTINGS={screenScale:100};
  let loaded={};
  try{
    loaded=JSON.parse(localStorage.getItem('ldz_user_settings_v1')||'{}')||{};
  }catch(e){
    loaded={};
  }
  window.gameSettings={
    skillFloatExtraSeconds:0,
    screenScale:Math.min(100,Math.max(50,Number(loaded.screenScale)||100))
  };

  function persist(){
    try{
      localStorage.setItem('ldz_user_settings_v1',JSON.stringify(window.gameSettings));
    }catch(e){}
  }

  function applySettings(){
    document.body.style.zoom=(window.gameSettings.screenScale/100).toString();
    const scaleInput=document.getElementById('screenScale');
    const scaleValue=document.getElementById('screenScaleValue');
    if(scaleInput)scaleInput.value=String(window.gameSettings.screenScale);
    if(scaleValue)scaleValue.textContent=window.gameSettings.screenScale+'%';
  }

  window.updateScreenScaleSetting=function(value){
    window.gameSettings.screenScale=Math.min(100,Math.max(50,Number(value)||100));
    applySettings();
    persist();
  };

  window.showSettings=function(){
    if(typeof invalidateBattle==='function')invalidateBattle();
    if(typeof hideScreens==='function')hideScreens();
    const screen=document.getElementById('settingsScreen');
    if(screen)screen.classList.remove('hidden');
    const overlay=document.getElementById('overlay');
    if(overlay)overlay.classList.remove('show');
    applySettings();
  };

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',applySettings,{once:true});
  }else{
    applySettings();
  }
})();
