/* =========================
   敌人蓄力技能
========================= */

function captainStartCharge(captain){
  captain.charge=2;

  log('鸭皇队长开始蓄力！召唤蓄力进入2回合状态，本次不发动攻击。','bad');

  skillLabel('captain','🚩 开始蓄力！');

  render();
}

function captainSummon(battle,captain){
  // 已完成蓄力就必须召唤，不因场上已有其他随从而取消或卡住。
  const follower=makeDuck(
    'follower-'+battle.round+'-'+Date.now(),
    '随从鸭皇',
    true
  );

  battle.enemies.push(follower);

  captain.charge=0;

  playSound('duck');
  skillLabel('captain','🚩 召唤随从！');

  log('鸭皇队长蓄力结束，召唤了一只随从鸭皇！随从将立即发动一次攻击。','bad');

  render();

  return follower;
}

function mistressStartCharge(mistress){
  mistress.charge=3;

  log('女主人开始蓄力！致命扫帚进入3回合蓄力状态，本次不发动攻击。','bad');

  skillLabel('mistress','👩‍🦰 开始蓄力！');

  render();
}
/* =========================
   伤害计算
========================= */

function redirectDamageTarget(target,damage,silentLog=false){
  if(!target||damage<=0||target.id!=='detectiveTuffy')return target;
  const clone=s&&s.allies.find(a=>a.isDetectiveClone&&a.hp>0);
  if(!clone)return target;
  // 只重定向受击目标，不在这里提前扣血或返回 null。
  // 让当前敌人的攻击继续走完统一结算流程，避免分身替伤时提前退出攻击函数，
  // 导致该敌人的附加效果/攻击反馈被跳过，看起来像敌人没有行动。
  if(!silentLog)log(`侦探泰菲被攻击，分身代替其承受本次${damage}点伤害。`,'good');
  return clone;
}

/*
 * 伤害计算顺序：
 * 1. 如果敌人有待触发的攻击力诅咒，攻击力降低30%。
 * 2. 消耗攻击力诅咒。
 * 3. 计算我方减伤。
 * 4. 四舍五入。
 *
 * 攻击力诅咒只会影响下一次实际攻击。
 * 蓄力和没有造成伤害的行为不会消耗它。
 */
function calculateEnemyDamage(enemy,target,baseDamage){
  let damage=baseDamage;
  let curseReduced=false;

  if(enemy.attackCursePending){
    damage=Math.round(damage*.7);
    enemy.attackCursePending=false;
    curseReduced=true;

    log(
      `${enemy.name}受到诅咒影响，本次攻击力降低30%，基础伤害由${baseDamage}降至${damage}。`,
      'good'
    );
  }

  let reductionApplied=false;

  if(target.reduction>0){
    damage=Math.round(damage*.7);
    target.reduction--;
    reductionApplied=true;
    shieldFX(target.id);
  }

  damage=Math.max(0,Math.round(damage));

  return{
    damage,
    curseReduced,
    reductionApplied
  };
}

/*
 * 仇恨只影响敌人的单体攻击目标选择。
 * 群体攻击和蓄力行为不使用这个函数选目标。
 */
function chooseEnemyTarget(enemy,targets){
  if(!targets.length)return null;

  if(enemy.hateTarget&&enemy.hateTurns>0){
    const hated=targets.find(target=>
      target.id===enemy.hateTarget&&target.hp>0
    );

    if(hated){
      log(`${enemy.name}受到仇恨影响，单体攻击只能选择${hated.name}。`,'system');
      return hated;
    }
  }

  return targets[Math.floor(Math.random()*targets.length)];
}

/*
 * 敌人命中诅咒角色后，获得下一次攻击降低30%的效果。
 * 此效果不影响刚刚命中的这次攻击。
 */
function applyCurseFromTarget(enemy,target){
  if(!target.cursed)return;

  enemy.attackCursePending=true;

  log(
    `${enemy.name}攻击了处于诅咒状态的${target.name}，${enemy.name}的下一次攻击将降低30%攻击力。`,
    'good'
  );
}
/* =========================
   女主人群体攻击
========================= */

async function mistressAttack(battle,token,mistress){
  if(!validBattle(battle,token)||mistress.hp<=0)return;

  const targets=alive(battle.allies).slice();

  if(!targets.length){
    finish(false);
    return;
  }

  playSound('explosion');
  skillLabel('mistress','🧹 致命扫帚！');

  log(
    '女主人蓄力完成，发动致命扫帚！对所有存活的我方角色造成80点伤害。',
    'bad'
  );

  /*
   * 群体攻击不受仇恨目标限制。
   * 如果女主人此前已经获得攻击力诅咒，
   * 则这次群体攻击的所有目标都受到降低后的伤害。
   */
  let baseDamage=80;

  if(mistress.attackCursePending){
    baseDamage=Math.round(baseDamage*.7);
    mistress.attackCursePending=false;

    log(
      `女主人受到诅咒影响，致命扫帚攻击力降低30%，每名目标的基础伤害由80降至${baseDamage}。`,
      'good'
    );
  }

  let counterTarget=null;
  let hitCursedTarget=false;
  // 延迟分身死亡处理：即使先替侦探泰菲承受伤害后 HP 已归零，
  // 只要分身在群体攻击开始时存活，它仍必须结算自己作为群体目标的那一击。
  let clonePendingDefeat=null;
  const cloneAtAttackStart=targets.find(target=>target.isDetectiveClone&&target.hp>0)||null;

  // 保证侦探泰菲先结算，分身随后结算自己的群体受击；这样可明确呈现两份伤害。
  targets.sort((a,b)=>{
    if(a.id==='detectiveTuffy'&&b.isDetectiveClone)return -1;
    if(a.isDetectiveClone&&b.id==='detectiveTuffy')return 1;
    return 0;
  });

  for(const target of targets){
    if(!validBattle(battle,token))return;
    // 一般已死亡单位跳过；分身若在本次群攻中先替泰菲承伤而倒下，
    // 仍允许它结算群体攻击原本分配给分身自己的那一击。
    const isPendingCloneHit=target.isDetectiveClone&&clonePendingDefeat===target;
    if(target.hp<=0&&!isPendingCloneHit)continue;

    let damage=baseDamage;

    if(target.reduction>0){
      damage=Math.round(damage*.7);
      target.reduction--;
      shieldFX(target.id);
    }

    damage=Math.max(0,Math.round(damage));

    const redirected=redirectDamageTarget(target,damage,true);
    if(!redirected)continue;
    redirected.hp=Math.max(0,redirected.hp-damage);

    if(redirected.isDetectiveClone&&redirected.hp<=0){
      clonePendingDefeat=redirected;
    }

    // 受击特效与伤害数字落在实际承伤的单位身上。
    damageFX(redirected.id,damage,'💥');

    if(target.id==='detectiveTuffy'&&redirected.isDetectiveClone){
      log(`女主人的致命扫帚命中了侦探泰菲，分身替代其承受了${damage}伤害`,'good');
    }else if(target.isDetectiveClone&&redirected===target){
      log(`女主人的致命扫帚命中了侦探泰菲的分身，分身自身承受了${damage}点伤害。`,'bad');
    }else{
      log(
        `女主人的致命扫帚命中${redirected.name}，造成${damage}点伤害${damage<80?'（经过伤害修正）':''}。`,
        'bad'
      );
    }

    if(redirected.cursed){
      hitCursedTarget=true;

      log(
        `女主人的群体攻击命中了处于诅咒状态的${redirected.name}，女主人下一次攻击将降低30%攻击力。`,
        'good'
      );
    }

    if(redirected.id==='swordsman'&&redirected.guard){
      if(redirected.hp>0){
        counterTarget=redirected;

        log('剑客杰瑞成功格挡住女主人的攻击！准备发动反击。','good');
      }else{
        log('剑客杰瑞被女主人的致命扫帚击倒，无法发动格挡反击。','bad');
      }
    }
  }

  // 只有两种群体伤害都结算完成后，才移除分身并写入击败记录。
  if(cloneAtAttackStart&&cloneAtAttackStart.hp<=0){
    battle.allies=battle.allies.filter(a=>a!==cloneAtAttackStart);
    log('侦探泰菲的分身承受了替本体转移的扫帚伤害，并承受了扫帚对自身造成的伤害后被击败。','bad');
  }

  if(hitCursedTarget){
    mistress.attackCursePending=true;
  }

  mistress.charge=0;

  render();

  if(endCheck())return;

  if(counterTarget){
    log('剑客杰瑞稳住架势，准备反击……','system');

    await sleep(1000);

    if(!validBattle(battle,token))return;

    if(counterTarget.hp>0&&mistress.hp>0){
      playSound('counter');
      skillLabel('swordsman','🗡️ 格挡反击！');
      projectile('swordsman',mistress.id,'🗡️');

      mistress.hp=Math.max(0,mistress.hp-40);

      damageFX(mistress.id,40,'💥');

      log('剑客杰瑞格挡反击，对女主人造成40点伤害。','good');

      render();

      if(endCheck())return;
    }else if(counterTarget.hp<=0){
      log('剑客杰瑞在反击前倒下，反击取消。','bad');
    }else{
      log('女主人已被击败，没有可反击的目标。','system');
    }
  }

  render();
  endCheck();
}
/* =========================
   敌人单体攻击
========================= */

async function enemyAttack(battle,token,enemy,forcedTarget=null){
  if(!validBattle(battle,token)||enemy.hp<=0)return;

  const allAliveTargets=alive(battle.allies);
  const clone=allAliveTargets.find(a=>a.isDetectiveClone&&a.hp>0);
  // 分身默认不参与随机选目标（它本身负责替侦探泰菲承伤），
  // 但如果敌人明确仇恨分身，必须将分身纳入候选目标，才能正常攻击它。
  const explicitlyHatesClone=!!(
    clone && enemy.hateTarget===clone.id && enemy.hateTurns>0
  );
  const targets=allAliveTargets.filter(a=>
    !a.isDetectiveClone || explicitlyHatesClone
  );

  if(!targets.length){
    finish(false);
    return;
  }

  let target;

  if(forcedTarget&&forcedTarget.hp>0){
    target=forcedTarget;
  }else{
    target=chooseEnemyTarget(enemy,targets);
  }

  if(!target)return;

  const damageBase=enemy.type==='captain'?25:20;

  const attackLabel=enemy.type==='captain'
    ?'🚩 队长攻击！'
    :enemy.type==='box'
      ?'🥊 拳头盒子攻击！'
      :enemy.isFollower
        ?'🦆 随从鸭皇攻击！'
        :'🦆 鸭皇攻击！';

  const projectileIcon=enemy.type==='captain'
    ?'🚩'
    :enemy.type==='box'
      ?'🥊'
      :'🦆';

  playSound(
    enemy.type==='captain'
      ?'punch'
      :enemy.type==='box'
        ?'punch'
        :'duck'
  );

  skillLabel(enemy.id,attackLabel);
  projectile(enemy.id,target.id,projectileIcon);

  const result=calculateEnemyDamage(enemy,target,damageBase);
  const damage=result.damage;
  const originalTarget=target;
  const redirected=redirectDamageTarget(target,damage);
  if(!redirected)return;
  target=redirected;
  target.hp=Math.max(0,target.hp-damage);
  if(target.isDetectiveClone&&target.hp<=0){
    s.allies=s.allies.filter(a=>a!==target);
    log('侦探泰菲的分身被击败。','bad');
  }

  if(enemy.type==='box'&&!enemy.first){
    enemy.first=true;

    if(target.id==='swordsman'&&target.guard){
      log(
        `拳头盒子首次攻击造成${damage}点伤害，但格挡成功，眩晕被免疫；首次眩晕机会已永久消耗。`,
        'good'
      );
    }else{
      target.stun=(target.stun||0)+1;

      playSound('stun');
      stunFX(target.id);

      log(
        `拳头盒子首次攻击${target.name}，造成${damage}点伤害并附加眩晕；当前累计影响${target.stun}次行动。`,
        'bad'
      );
    }
  }else if(target.id==='swordsman'&&target.guard){
    log(`${enemy.name}攻击格挡中的剑客杰瑞，造成${damage}点伤害。`,'bad');
  }else{
    let suffix='';

    if(result.curseReduced&&result.reductionApplied){
      suffix='（攻击力降低后再经过减伤）';
    }else if(result.curseReduced){
      suffix='（攻击力降低30%后）';
    }else if(result.reductionApplied){
      suffix='（减伤后四舍五入）';
    }

    log(`${enemy.name}攻击了${target.name}，造成${damage}点伤害${suffix}。`,'bad');
  }

  /*
   * 诅咒角色受到攻击后，攻击者下一次攻击降低30%。
   * 注意：在本次攻击伤害已经结算之后才施加，
   * 所以不会反过来降低刚刚造成的伤害。
   */
  applyCurseFromTarget(enemy,originalTarget);

  const counterPending=
    target.id==='swordsman'&&target.guard&&target.hp>0;

  if(target.id==='swordsman'&&target.guard&&target.hp<=0){
    log('剑客杰瑞倒下，无法发动格挡反击。','bad');
  }

  damageFX(target.id,damage,'💥');

  render();

  if(endCheck())return;

  if(counterPending){
    log('剑客杰瑞稳住架势，准备反击……','system');

    await sleep(1000);

    if(!validBattle(battle,token))return;

    if(target.hp>0&&enemy.hp>0){
      playSound('counter');
      skillLabel('swordsman','🗡️ 格挡反击！');
      projectile('swordsman',enemy.id,'🗡️');

      enemy.hp=Math.max(0,enemy.hp-40);

      damageFX(enemy.id,40,'💥');

      log(`剑客杰瑞格挡反击，对${enemy.name}造成40点伤害。`,'good');

      render();

      if(endCheck())return;
    }else if(target.hp<=0){
      log('剑客杰瑞在反击前倒下，反击取消。','bad');
    }else{
      log(`${enemy.name}已被击败，没有可反击的目标。`,'system');
    }
  }
}
/* =========================
   敌方回合
========================= */

async function enemyPhase(battle,token){
  if(!validBattle(battle,token)||battle.phase!=='enemy')return;

  try{
    const enemiesThisPhase=alive(battle.enemies).slice();

    for(let i=0;i<enemiesThisPhase.length;i++){
      if(!validBattle(battle,token))return;

      const enemy=enemiesThisPhase[i];

      if(enemy.hp<=0)continue;

      /* 女主人：蓄力与群体攻击不受仇恨选目标影响。 */
      if(enemy.type==='mistress'){
        if(enemy.charge===0){
          mistressStartCharge(enemy);

          await sleep(650);

          if(!validBattle(battle,token))return;

          continue;
        }

        if(enemy.charge===3){
          enemy.charge=2;

          log('女主人的致命扫帚蓄力推进：还剩2回合。本次不发动攻击。','bad');

          skillLabel('mistress','👩‍🦰 蓄力中……');

          render();

          await sleep(650);

          if(!validBattle(battle,token))return;

          continue;
        }

        if(enemy.charge===2){
          enemy.charge=1;

          log('女主人的致命扫帚蓄力推进：还剩1回合。本次不发动攻击。','bad');

          skillLabel('mistress','👩‍🦰 蓄力中……');

          render();

          await sleep(650);

          if(!validBattle(battle,token))return;

          continue;
        }

        if(enemy.charge===1){
          enemy.charge=0;

          await mistressAttack(battle,token,enemy);

          if(!validBattle(battle,token))return;
          if(endCheck())return;

          await sleep(500);

          if(!validBattle(battle,token))return;

          continue;
        }
      }

      /* 鸭皇队长：已进入蓄力后必须完成召唤；只有未蓄力且场上没有存活随从时才开始蓄力。 */
      if(enemy.type==='captain'){
        const followerAlive=battle.enemies.some(
          e=>e.isFollower&&e.hp>0
        );

        // 蓄力状态优先处理，不因场上已有随从而中断。
        if(enemy.charge===2){
          enemy.charge=1;

          log('鸭皇队长的召唤蓄力推进：还剩1回合。本次不发动攻击。','bad');

          skillLabel('captain','🚩 蓄力中……');

          render();

          await sleep(650);

          if(!validBattle(battle,token))return;

          continue;
        }

        if(enemy.charge===1){
          const follower=captainSummon(battle,enemy);

          await sleep(350);

          if(!validBattle(battle,token))return;

          if(follower&&follower.hp>0){
            await enemyAttack(battle,token,follower);

            if(!validBattle(battle,token))return;
            if(endCheck())return;
          }

          await sleep(500);

          if(!validBattle(battle,token))return;

          continue;
        }

        // 未处于蓄力状态时，只有没有存活随从才会开始蓄力。
        if(enemy.charge===0&&!followerAlive){
          captainStartCharge(enemy);

          await sleep(650);

          if(!validBattle(battle,token))return;

          continue;
        }
      }

      await enemyAttack(battle,token,enemy);

      if(!validBattle(battle,token))return;
      if(endCheck())return;

      if(
        i<enemiesThisPhase.length-1&&
        enemiesThisPhase.slice(i+1).some(e=>e.hp>0)
      ){
        await sleep(750);

        if(!validBattle(battle,token))return;
      }
    }

    if(!validBattle(battle,token))return;

    /*
     * 所有敌人完成本轮行动：
     * 清除我方诅咒状态。
     * 清除持续一轮的仇恨状态。
     *
     * 敌人身上的 attackCursePending 不在这里清除，
     * 因为它要等到该敌人下一次实际攻击时才消耗。
     */
    battle.allies.forEach(ally=>{
      ally.acted=false;

      if(ally.cursed){
        ally.cursed=false;
        log(`${ally.name}身上的诅咒符纸效果结束。`,'system');
      }

      if(ally.id==='tuffy'){
        if(ally.tempMaxHp>0){
          ally.max-=ally.tempMaxHp;
          ally.tempMaxHp=0;

          if(ally.hp>ally.max){
            const excess=ally.hp-ally.max;
            ally.hp=ally.max;

            log(
              `泰菲的奶酪蛋糕效果结束，最大HP恢复，超出部分的${excess}点HP被移除。`,
              'system'
            );
          }else{
            log('泰菲的奶酪蛋糕效果结束，最大HP恢复原状。','system');
          }
        }

        ally.healUsedThisRound=false;
      }

      if(ally.id==='swordsman'){
        if(ally.guard){
          ally.guard=false;
          log('剑客杰瑞的格挡状态结束。','system');
        }

        if(ally.guardCd>0&&!ally.guardUsedThisRound){
          ally.guardCd--;
          if(ally.guardCd<=0){
            log('剑客杰瑞的格挡技能冷却结束，现在可以再次使用。','good');
          }
        }

        ally.guardUsedThisRound=false;
      }

      if(ally.id==='demon'&&ally.curseCooldownUntilRound){
        const curseRemaining=Math.max(0,ally.curseCooldownUntilRound-(s.round+1));
        if(curseRemaining<=0&&ally.curseCooldownUntilRound===s.round+1){
          log('恶魔杰瑞的诅咒符纸技能冷却结束，现在可以再次使用。','good');
          ally.curseCooldownUntilRound=0;
        }
      }

      if(ally.id==='detectiveTuffy'){
        if(ally.cloneCooldown>0&&!ally.cloneCooldownUsedThisRound){
          ally.cloneCooldown--;
          if(ally.cloneCooldown<=0){
            log('侦探泰菲的分身技能冷却结束。','good');
          }
        }
        ally.cloneCooldownUsedThisRound=false;
      }
    });

    clearEnemyHate();

    battle.enemies.forEach(enemy=>{
      enemy.acted=false;
    });

    if(endCheck())return;

    battle.round++;
    battle.phase='player';

    log(`第${battle.round}轮开始，我方行动。`,'system');

    render();
    // 等待敌方全员行动后的攻击特效、受击反馈和音效播放完毕，再显示教学弹窗。
    // 此处位于敌人行动循环及回合结算之后，确保两只鸭皇都完成行动。
    if(tutorialMode&&tutorialKind==='hate'&&(tutorialStage===2||tutorialStage===5)){
      const completedStage=tutorialStage;
      tutorialStage=completedStage===2?3:6;
      await sleep(1200);
      if(!tutorialMode||!validBattle(battle,token)||battle.phase!=='player')return;
      if(completedStage===2){
        showTutorialModal('发现了没有，遭到仇恨的那只鸭皇攻击了恶魔杰瑞！现在试试恶魔杰瑞的另一个技能，诅咒符纸，可以贴在剑客杰瑞的身上。','知道了');
      }else{
        showTutorialModal('真是完美的一次配合！我想你应该搞清楚仇恨的规则了，尝试完成这场战斗吧。','开始自由战斗');
      }
    }

  }catch(error){
    console.error('敌方回合发生错误：',error);

    if(validBattle(battle,token)){
      log('敌方行动发生错误，请重开本关。可打开浏览器控制台查看具体报错。','bad');
      render();
    }
  }
}
