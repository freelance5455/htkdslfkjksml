/* =========================
   状态显示
========================= */

function status(unit){
  const tags=[];

  if(unit.isDetectiveClone){tags.push('<span class="tag buff">保护侦探泰菲</span>');}

  if(unit.stun>0){
    tags.push(`<span class="tag stun">眩晕：还需跳过${unit.stun}次行动</span>`);
  }

  if(unit.reduction>0){
    tags.push(`<span class="tag buff">减伤30% · ${unit.reduction}次攻击</span>`);
  }

  if(unit.guard){
    tags.push('<span class="tag buff">格挡中：免疫控制，受击反击</span>');
  }

  if(unit.tempMaxHp>0){
    tags.push(`<span class="tag buff">1回合内最大HP +${unit.tempMaxHp}</span>`);
  }

  if(unit.guardCd>0){
    tags.push(`<span class="tag warn">格挡冷却：${unit.guardCd}回合</span>`);
  }

  if(unit.id==='detectiveTuffy'&&unit.cloneCooldown>0){
    tags.push(`<span class="tag warn">分身冷却：${unit.cloneCooldown}回合</span>`);
  }

  if(unit.cursed){
    tags.push('<span class="tag buff">诅咒：1回合</span>');
  }

  if(unit.hateTarget&&unit.hateTurns>0){
    const target=[...(s?.allies||[]),...(s?.enemies||[])]
      .find(u=>u.id===unit.hateTarget);

    if(target&&target.hp>0){
      tags.push(`<span class="tag warn">1回合内仇恨目标：${target.name}</span>`);
    }
  }

  if(unit.attackCursePending){
    tags.push('<span class="tag stun">下次攻击伤害降低30%</span>');
  }

  if(unit.type==='captain'&&unit.charge>0){
    tags.push(`<span class="tag warn">召唤蓄力：${unit.charge}回合</span>`);
  }

  if(unit.type==='mistress'&&unit.charge>0){
    tags.push(`<span class="tag warn">致命扫帚蓄力：${unit.charge}回合</span>`);
  }

  if(tags.length) return tags.join('');

  // 恶魔杰瑞的诅咒符纸处于冷却时，不显示误导性的「状态正常」。
  if(unit.id==='demon'&&unit.curseCooldownUntilRound&&s&&s.round<unit.curseCooldownUntilRound){
    return '';
  }

  return '<span class="tag">状态正常</span>';
}

/* =========================
   单位卡片
========================= */

function enemyCard(unit){
  let desc='普通攻击：20伤害';

  if(unit.type==='box')desc='拳头重击：20伤害，首次命中附加眩晕';
  if(unit.type==='captain')desc='队长攻击：25伤害；蓄力召唤随从';
  if(unit.type==='mistress')desc='蓄力后发动群体攻击';
  if(unit.isFollower)desc='随从鸭皇：20伤害';

  return `
    <article class="unitcard enemy" id="card-${unit.id}">
      <div class="unithead">
        <div class="avatar">${unit.icon}</div>
        <div>
          <div class="name">${unit.name}</div>
          <div class="desc">${desc}</div>
        </div>
      </div>
      ${bar(unit)}
      <div class="status">
        ${unit.hp>0?status(unit):'<span class="tag warn">已被击败</span>'}
      </div>
    </article>
  `;
}

function allyCard(unit){
  const dead=unit.hp<=0;
  const locked=unit.acted||s.phase!=='player'||s.done;
  let skills='';
  const tutorialCanHammer=!tutorialMode||tutorialStage===0||tutorialStage>=5;
  const tutorialCanShield=!tutorialMode||tutorialStage===2||tutorialStage>=5;
  const tutorialCanPass=!tutorialMode||tutorialStage>=5;
  const tutorialWaiting=tutorialMode&&((tutorialStage===1||tutorialStage===3));

  if(unit.id==='jerry'){
    const targets=alive(s.enemies).map(e=>`
      <button class="skill-btn ${tutorialMode&&tutorialStage===0?'tutorial-highlight':''}" ${locked||dead||!tutorialCanHammer||tutorialWaiting?'disabled':''}
        onclick="jerryAttack('${e.id}')">
        <strong>🔨 大铁锤 ${e.name}</strong>
        <small>${tutorialMode&&tutorialStage>0&&tutorialStage<5?'教学禁用':'造成25伤害'}</small>
      </button>
    `).join('');

    skills=`
      <div class="btns">
        ${targets}
        <button class="skill-btn ${tutorialMode&&tutorialStage===2?'tutorial-highlight':''}" ${locked||dead||!tutorialCanShield||tutorialWaiting?'disabled':''} onclick="defend()">
          <strong>🛡️ 团队防护</strong>
          <small>${tutorialMode&&tutorialStage!==2&&tutorialStage<5?'教学禁用':'全体减伤30%，抵挡2次攻击'}</small>
        </button>
      </div>
    `;
  }else if(unit.id==='tuffy'){
    skills=`
      <div class="btns">
        <button class="skill-btn" ${locked||dead?'disabled':''} onclick="rocket()">
          <strong>🚀 火箭筒</strong>
          <small>所有存活敌人受到20伤害</small>
        </button>
        <button class="skill-btn" ${locked||dead?'disabled':''} onclick="heal()">
          <strong>🍰 奶酪蛋糕</strong>
          <small>先增加最大HP30，然后恢复35当前HP</small>
        </button>
      </div>
    `;
  }else if(unit.id==='shirley'){
    skills=`
      <div class="btns">
        <button class="skill-btn" ${locked||dead?'disabled':''} onclick="shirleyPunch()">
          <strong>👊 拳击</strong>
          <small>随机对一名存活敌人造成20伤害</small>
        </button>
        <button class="skill-btn" ${locked||dead?'disabled':''} onclick="loveBouquet()">
          <strong>💐 爱心花束</strong>
          <small>全队恢复各自最大HP的20%</small>
        </button>
      </div>
    `;
  }else if(unit.id==='swordsman'){
    const targets=alive(s.enemies).map(e=>`
      <button class="skill-btn" ${locked||dead||(tutorialMode&&tutorialKind==='hate'&&tutorialStage<6)?'disabled':''}
        onclick="swordDance('${e.id}')">
        <strong>🗡️ 剑舞 ${e.name}</strong>
        <small>${tutorialMode&&tutorialKind==='hate'&&tutorialStage<6?'教学禁用':'造成30伤害'}</small>
      </button>
    `).join('');

    skills=`
      <div class="btns">
        ${targets}
        <button class="skill-btn ${tutorialMode&&tutorialKind==='hate'&&tutorialStage===4?'tutorial-highlight':''}"
          ${locked||dead||unit.guardCd>0||unit.guard||(tutorialMode&&tutorialKind==='hate'&&tutorialStage!==4&&tutorialStage<6)?'disabled':''}
          onclick="swordGuard()">
          <strong>🛡️ 格挡</strong>
          <small>${unit.guard?'格挡生效中':unit.guardCd>0?'冷却中':'持续至敌方行动结束；受击后反击40伤害'}</small>
        </button>
      </div>
    `;
  }else if(unit.isDetectiveClone){
    const targets=alive(s.enemies).map(e=>`
      <button class="skill-btn" ${locked||dead?'disabled':''} onclick="detectiveCloneAttack('${unit.id}','${e.id}')">
        <strong>👤 攻击 ${e.name}</strong><small>造成20伤害</small>
      </button>`).join('');
    skills=`<div class="btns">${targets}</div>`;
  }else if(unit.id==='detectiveTuffy'){
    const targets=alive(s.enemies).map(e=>`
      <button class="skill-btn" ${locked||dead?'disabled':''} onclick="detectiveRay('${e.id}')">
        <strong>✨ 光线攻击 ${e.name}</strong><small>造成25伤害</small>
      </button>`).join('');
    const cloneExists=s.allies.some(a=>a.isDetectiveClone&&a.hp>0);
    const cloneCooling=unit.cloneCooldown>0;
    const remain=cloneCooling?unit.cloneCooldown:0;
    skills=`<div class="btns">${targets}<button class="skill-btn" ${locked||dead||cloneExists||cloneCooling?'disabled':''} onclick="detectiveClone()"><strong>👥 分身</strong><small>${cloneExists?'已有分身在场':cloneCooling?`冷却中`:'创造50 HP分身，替自己承受伤害'}</small></button></div>`;
  }else if(unit.id==='demon'){
    const targets=alive(s.enemies).map(e=>`
      <button class="skill-btn ${tutorialMode&&tutorialKind==='hate'&&tutorialStage===0?'tutorial-highlight':''}" ${locked||dead||(tutorialMode&&tutorialKind==='hate'&&tutorialStage!==0&&tutorialStage<6)?'disabled':''}
        onclick="demonTrident('${e.id}')">
        <strong>🔱 三叉戟 ${e.name}</strong>
        <small>${tutorialMode&&tutorialKind==='hate'&&tutorialStage!==0&&tutorialStage<6?'教学禁用':'造成25伤害，并使其仇恨恶魔杰瑞一轮'}</small>
      </button>
    `).join('');

    const curseCooling=!!(unit.curseCooldownUntilRound && s.round<unit.curseCooldownUntilRound);
    const allies=alive(s.allies).map(a=>`
      <button class="skill-btn ${tutorialMode&&tutorialKind==='hate'&&tutorialStage===3&&a.id==='swordsman'?'tutorial-highlight':''}" ${locked||dead||curseCooling||(tutorialMode&&tutorialKind==='hate'&&(tutorialStage!==3||a.id!=='swordsman')&&tutorialStage<6)?'disabled':''}
        onclick="demonCurse('${a.id}')">
        <strong>📜 诅咒符纸  ${a.name}</strong>
        <small>${curseCooling?'冷却中':(tutorialMode&&tutorialKind==='hate'&&tutorialStage!==3&&tutorialStage<6?'教学禁用':'施加诅咒并令所有敌人仇恨该角色')}</small>
      </button>
    `).join('');

    skills=`
      <div class="actions demon-actions">
        <div class="btns">${targets}${allies}</div>
      </div>
    `;
  }

  const desc={
    jerry:'灵活主力',
    tuffy:'群体攻击',
    shirley:'治疗与攻击支援',
    swordsman:'剑舞攻击与格挡反击',
    demon:'诅咒与仇恨',
    detectiveTuffy:'光线攻击与分身保护'
  }[unit.id] || (unit.isDetectiveClone?'替侦探泰菲承受伤害的分身':'战斗单位');

  return `
    <article class="unitcard" id="card-${unit.id}">
      <div class="unithead">
        <div class="avatar">${unit.icon}</div>
        <div>
          <div class="name">${unit.name}</div>
          <div class="desc">${desc}</div>
        </div>
      </div>
      ${bar(unit)}
      <div class="status">
        ${dead?'<span class="tag warn">已倒下</span>':status(unit)}
        ${!dead&&unit.id==='demon'&&unit.curseCooldownUntilRound&&s.round<unit.curseCooldownUntilRound?'<span class="tag warn">符咒冷却：1回合</span>':''}
      </div>
      ${dead?'':`
        <div class="actions">
          <h3>${unit.acted?'本轮已行动':s.phase==='player'?'选择行动':'等待我方回合'}</h3>
          ${skills}
          <button class="skill-btn pass wide ${tutorialMode&&tutorialKind==='hate'&&unit.id==='swordsman'&&tutorialStage===1?'tutorial-highlight':''}" ${locked||dead||(tutorialMode&&tutorialKind==='hate'?((tutorialStage<6&&!((unit.id==='swordsman'&&tutorialStage===1)) )):(!tutorialCanPass||tutorialWaiting))?'disabled':''}
            onclick="pass('${unit.id}')">
            空过本次行动${tutorialMode&&((tutorialKind==='hate'&&tutorialStage<6&&!(unit.id==='swordsman'&&tutorialStage===1))||(tutorialKind!=='hate'&&tutorialStage<5))?'（教学禁用）':''}
          </button>
        </div>
      `}
    </article>
  `;
}

function render(){
  if(!s)return;

  $('allyUnits').innerHTML=s.allies.map(allyCard).join('');
  $('enemyUnits').innerHTML=s.enemies.filter(enemy=>!(enemy.isFollower&&enemy.hp<=0)).map(enemyCard).join('');

  $('phasePill').textContent=s.done
    ?'战斗结束'
    :`${s.phase==='player'?'我方行动':'敌方行动'} · 第 ${s.round} 轮`;
}
