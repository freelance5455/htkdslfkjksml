/* =========================
   战斗结算
========================= */

function finish(win){
  if(!s||s.done||s.resultPending)return;

  s.resultPending=true;
  s.phase='result';

  const battle=s;
  const token=battle.token;

  log(
    win
      ?'战斗结束：我方胜利！正在结算……'
      :'战斗结束：我方失败！正在结算……',
    'system'
  );

  render();

  resultTimer=setTimeout(()=>{
    resultTimer=null;

    if(s!==battle||battle.token!==token||battle.done)return;

    battle.done=true;
    let earned=false;
    if(win && !customBattleActive && !tutorialMode && typeof awardFirstClear==='function'){
      earned=awardFirstClear(selectedLevel);
      if(earned)log(`首次通关第${selectedLevel}关，获得🪙1枚金币！`,'good');
      else log('由于不是首次通关，无法获得金币。','system');
    }

    render();

    $('resultIcon').textContent=win?'🏆':'💥';
    $('resultTitle').textContent=win
      ?(tutorialMode?'教学完成！':customBattleActive?'自定义战斗胜利！':`第${selectedLevel}关胜利！`)
      :'挑战失败';

    $('resultText').textContent=win
      ?`我方（${battle.allies.map(a=>a.name).join('、')}）成功击败所有敌人！${tutorialMode?' 教学关不影响通关奖励。':customBattleActive?' 自定义战斗无法获得金币。':earned?' 首次通关奖励已计入存档，获得🪙1枚金币。':' 由于不是首次通关，无法获得金币。'}`
      :'我方全员倒下了。尝试调整作战方案或更换队伍，再试一次吧。';

    if(tutorialMode){
      const failed=!win;
      const forcedFirstVisitWin=!failed && typeof firstVisitForcedTutorial!=='undefined' && firstVisitForcedTutorial;
      if(forcedFirstVisitWin){
        try{localStorage.setItem('laoshudazhan_first_visit_flow_v1','done');}catch(e){}
        // 开局问题引导的教学成功后，只提供进入正式游戏的入口。
        ['resultRestartBtn','resultChangeTeamBtn','resultBackLevelsBtn','resultBackGuideBtn'].forEach(id=>{const el=$(id);if(el)el.classList.add('hidden');});
        const formalBtn=$('resultFormalStartBtn');if(formalBtn){formalBtn.classList.remove('hidden');}
      }else{
        const formalBtn=$('resultFormalStartBtn');if(formalBtn)formalBtn.classList.add('hidden');
      }
      if(typeof setTutorialControls==='function')setTutorialControls(true,failed);
    }else{
      const formalBtn=$('resultFormalStartBtn');if(formalBtn)formalBtn.classList.add('hidden');
    }
    $('overlay').classList.add('show');

  },1800);
}
/* =========================
   重开本关
========================= */

function restart(){
  if(tutorialMode){
    const failed=!!(s&&s.done&&s.allies&&s.allies.every(a=>a.hp<=0));
    if(!failed)return;
    tutorialStage=0;
    setTutorialControls(true,false);
  }
  cancelTimers();

  battleToken++;

  s=initial();

  $('logList').innerHTML='';
  $('fxLayer').innerHTML='';
  $('overlay').classList.remove('show');

  log(
    tutorialMode
      ?`教学开始！我方出战：${s.allies.map(a=>a.name).join('、')}。`
      :customBattleActive
        ?`自定义战斗开始！我方出战：${s.allies.map(a=>a.name).join('、')}。本模式无法获得金币。`
        :`第${selectedLevel}关开始！我方出战：${s.allies.map(a=>a.name).join('、')}。`,
    'system'
  );

  if(customBattleActive){
    log(`自定义敌方阵容：${s.enemies.map(e=>e.name).join('、')}。`,'system');
  }

  if(!tutorialMode && !customBattleActive && selectedLevel===1){
    log('敌方阵容：鸭皇、拳头盒子。','system');
  }

  if(!tutorialMode && !customBattleActive && selectedLevel===2){
    log('敌方阵容：鸭皇1、鸭皇2、鸭皇3。','system');
  }

  if(!tutorialMode && !customBattleActive && selectedLevel===3){
    log(
      '敌方阵容：鸭皇、鸭皇队长。队长开局无蓄力状态；轮到自己行动且没有随从时才开始2回合蓄力。',
      'system'
    );
  }

  if(!tutorialMode && !customBattleActive && selectedLevel===4){
    log('敌方阵容：女主人、鸭皇队长、拳头盒子。','system');
  }

  if(!tutorialMode)log('我方先行动。','system');

  render();
  if(tutorialMode)showTutorialModal('这是一个回合制游戏。你需要在一轮轮的行动中消灭所有敌方。现在试试杰瑞的大铁锤吧！','开始行动');
}
/* =========================
   首次进入引导与启动游戏
========================= */
const FIRST_VISIT_KEY = 'laoshudazhan_first_visit_flow_v1';
let firstVisitProgressTimer = null;
let firstVisitForcedTutorial = false;
function initializeFirstVisit(){
  renderSelection();
  let completed=false;
  try{completed=localStorage.getItem(FIRST_VISIT_KEY)==='done';}catch(e){}
  if(completed){showMenu();return;}
  hideScreens();
  $('overlay').classList.remove('show');
  $('firstVisitTutorialDialog').classList.remove('hidden');
}
function finishFirstVisitFlow(){
  // 仅保存在此设备浏览器的 localStorage，不写入账号存档。
  try{localStorage.setItem(FIRST_VISIT_KEY,'done');}catch(e){}
}
function showFirstVisitFriendlyReminder(){
  $('firstVisitFriendlyReminder').classList.remove('hidden');
}
function confirmFirstVisitFriendlyReminder(){
  $('firstVisitFriendlyReminder').classList.add('hidden');
  finishFirstVisitFlow();
  showMenu();
}
function answerTutorialChoice(wantsTutorial){
  $('firstVisitTutorialDialog').classList.add('hidden');
  if(!wantsTutorial){finishFirstVisitFlow();showFirstVisitFriendlyReminder();return;}
  firstVisitForcedTutorial = true;
  finishFirstVisitFlow();
  $('firstVisitLoading').classList.remove('hidden');
  const fill=$('firstVisitProgressFill');
  const label=$('firstVisitProgressText');
  if(fill)fill.style.width='0%';
  if(label)label.textContent='0%';
  const start=Date.now();
  if(firstVisitProgressTimer!==null)clearInterval(firstVisitProgressTimer);
  firstVisitProgressTimer=setInterval(()=>{
    const percent=Math.min(100,Math.floor((Date.now()-start)/1800*100));
    if(fill)fill.style.width=percent+'%';
    if(label)label.textContent=percent+'%';
    if(percent>=100){
      clearInterval(firstVisitProgressTimer);firstVisitProgressTimer=null;
      $('firstVisitLoading').classList.add('hidden');
      tutorialKind='basic';
      startTutorial();
    }
  },30);
}

initializeFirstVisit();
