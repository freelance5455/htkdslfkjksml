/* =========================
   存档系统
   存档结构：已解锁角色、金币、首次通关记录
   实际进度保存在浏览器 localStorage；此文件定义默认存档。
========================= */
const SAVE_KEY = 'laoshudazhan_ch_save_v1';
const DEFAULT_SAVE = {
  unlockedCharacters: ['jerry','shirley','tuffy','demon','swordsman'],
  coins: 0,
  clearedLevels: [],
  playerName: '指挥家'
};

function loadSave(){
  try{
    const raw=localStorage.getItem(SAVE_KEY);
    const parsed=raw?JSON.parse(raw):null;
    const save={
      unlockedCharacters:[...DEFAULT_SAVE.unlockedCharacters],
      coins:0,
      clearedLevels:[],
      playerName:'指挥家',
      ...(parsed&&typeof parsed==='object'?parsed:{})
    };
    save.unlockedCharacters=Array.isArray(save.unlockedCharacters)?save.unlockedCharacters:[...DEFAULT_SAVE.unlockedCharacters];
    save.clearedLevels=Array.isArray(save.clearedLevels)?save.clearedLevels:[];
    save.coins=Number.isFinite(Number(save.coins))?Math.max(0,Number(save.coins)):0;
    save.playerName=typeof save.playerName==='string'&&save.playerName.trim()?save.playerName.trim().slice(0,24):'指挥家';
    return save;
  }catch(e){
    return {...DEFAULT_SAVE,unlockedCharacters:[...DEFAULT_SAVE.unlockedCharacters],clearedLevels:[]};
  }
}
let playerSave=loadSave();

function persistSave(){
  try{localStorage.setItem(SAVE_KEY,JSON.stringify(playerSave));}catch(e){}
  updateCoinDisplay();
  if(typeof updatePlayerWelcome==='function')updatePlayerWelcome();
  if(typeof renderLevelCoins==='function')renderLevelCoins();
}
function updateCoinDisplay(){
  const count=String(playerSave.coins||0);
  const el=document.getElementById('menuCoins');
  if(el)el.textContent=count;
  const shopEl=document.getElementById('shopCoins');
  if(shopEl)shopEl.textContent=count;
}
function awardFirstClear(level){
  const n=Number(level);
  if(n<1||n>4||playerSave.clearedLevels.includes(n))return false;
  playerSave.clearedLevels.push(n);
  playerSave.coins=(Number(playerSave.coins)||0)+1;
  persistSave();
  return true;
}
function isCharacterUnlocked(id){
  return playerSave.unlockedCharacters.includes(id);
}
function updatePlayerWelcome(){const el=document.getElementById('menuWelcomeText');if(el)el.textContent='欢迎！'+(playerSave.playerName||'指挥家')+'！';}
function renamePlayer(){const current=playerSave.playerName||'指挥家';const value=prompt('请输入昵称（最多24个字符）：',current);if(value===null)return;const name=value.trim().slice(0,24);if(!name){alert('昵称不能为空。');return;}playerSave.playerName=name;persistSave();updatePlayerWelcome();}
document.addEventListener('DOMContentLoaded',()=>{updateCoinDisplay();updatePlayerWelcome();if(typeof renderLevelCoins==='function')renderLevelCoins();});

/* =========================
   账号转移：纯文本导出/导入
   通过复制和粘贴存档文本，兼容更多 APK WebView 环境。
   仅转移本地账号进度，不改变游戏战斗与关卡规则。
========================= */
const ACCOUNT_SAVE_FORMAT = 'laoshudazhan-ch-account-save';
const ACCOUNT_SAVE_VERSION = 1;

function buildAccountSavePayload(){
  return {
    format:ACCOUNT_SAVE_FORMAT,
    version:ACCOUNT_SAVE_VERSION,
    exportedAt:new Date().toISOString(),
    save:{
      unlockedCharacters:[...playerSave.unlockedCharacters],
      coins:Number(playerSave.coins)||0,
      clearedLevels:[...playerSave.clearedLevels],
      playerName:playerSave.playerName||'指挥家'
    }
  };
}
function openAccountSaveTextDialog(title,text,helpText){
  const existing=document.getElementById('accountSaveTextDialog');
  if(existing)existing.remove();
  const overlay=document.createElement('div');
  overlay.id='accountSaveTextDialog';
  overlay.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:14px;box-sizing:border-box;';
  const panel=document.createElement('div');
  panel.style.cssText='width:min(720px,100%);max-height:92vh;overflow:auto;background:#172235;color:#fff;border:1px solid #52647e;border-radius:16px;padding:16px;box-sizing:border-box;font-family:system-ui,sans-serif;';
  const heading=document.createElement('h2'); heading.textContent=title; heading.style.cssText='margin:0 0 8px;font-size:20px;';
  const help=document.createElement('p'); help.textContent=helpText; help.style.cssText='font-size:13px;line-height:1.6;color:#c1cee1;';
  const area=document.createElement('textarea'); area.value=text; area.setAttribute('aria-label','账号存档文本'); area.spellcheck=false; area.style.cssText='display:block;width:100%;height:38vh;min-height:180px;box-sizing:border-box;background:#0b1220;color:#e9f2ff;border:1px solid #52647e;border-radius:8px;padding:10px;font:12px/1.5 monospace;';
  const buttons=document.createElement('div'); buttons.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;';
  const makeButton=(label,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='border:0;border-radius:8px;padding:11px 14px;background:#3c72c5;color:white;font-weight:600;';b.addEventListener('click',fn);return b;};
  buttons.appendChild(makeButton('复制全部文本',async()=>{
    try{
      if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(area.value);alert('已复制存档文本。若系统不允许自动复制，请长按文本框并选择“全选→复制”。');}
      else{area.focus();area.select();const ok=document.execCommand&&document.execCommand('copy');alert(ok?'已复制存档文本。':'请长按文本框，选择“全选→复制”。');}
    }catch(e){area.focus();area.select();alert('自动复制不可用，请长按文本框，选择“全选→复制”。');}
  }));
  buttons.appendChild(makeButton('全选文本',()=>{area.focus();area.select();}));
  buttons.appendChild(makeButton('关闭',()=>overlay.remove()));
  panel.append(heading,help,area,buttons); overlay.appendChild(panel);
  overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove();});
  document.body.appendChild(overlay);
  area.focus();
}
// 存档文本混淆：避免直接显示可读 JSON。此方案只是混淆，不是安全加密，不能阻止有经验的玩家逆向修改。
const ACCOUNT_TEXT_PREFIX = 'LDZ2.';
const ACCOUNT_TEXT_KEY = 'm0use-ch-save-obfuscation-v2';
function encodeAccountSaveText(payload){
  const raw=JSON.stringify(payload);
  // 先将 Unicode JSON 转为 UTF-8 字节，避免中文昵称等字符导致 btoa 抛出异常。
  const utf8=unescape(encodeURIComponent(raw));
  let encoded='';
  for(let i=0;i<utf8.length;i++) encoded+=String.fromCharCode(utf8.charCodeAt(i)^ACCOUNT_TEXT_KEY.charCodeAt(i%ACCOUNT_TEXT_KEY.length));
  return ACCOUNT_TEXT_PREFIX+btoa(encoded).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function decodeAccountSaveText(text){
  const clean=String(text||'').trim();
  if(!clean.startsWith(ACCOUNT_TEXT_PREFIX)) throw new Error('存档文本格式不正确或不是新版存档');
  let b64=clean.slice(ACCOUNT_TEXT_PREFIX.length).replace(/-/g,'+').replace(/_/g,'/');
  while(b64.length%4) b64+='=';
  const encoded=atob(b64);
  let utf8='';
  for(let i=0;i<encoded.length;i++) utf8+=String.fromCharCode(encoded.charCodeAt(i)^ACCOUNT_TEXT_KEY.charCodeAt(i%ACCOUNT_TEXT_KEY.length));
  return JSON.parse(decodeURIComponent(escape(utf8)));
}
function showAccountSaveText(){
  const text=encodeAccountSaveText(buildAccountSavePayload());
  openAccountSaveTextDialog('账号存档文本',text,'将全部混淆文本复制后发送给自己或朋友。导入时，在另一台设备主页点击“账号转移：粘贴存档文本”，粘贴完整内容即可。请勿修改文本内容。');
}
function validateAndApplyAccountSave(payload){
  if(!payload||payload.format!==ACCOUNT_SAVE_FORMAT||payload.version!==ACCOUNT_SAVE_VERSION||!payload.save||typeof payload.save!=='object'){
    throw new Error('文件不是兼容的《老鼠大战ch》账号存档');
  }
  const incoming=payload.save;
  const knownCharacters=Object.keys(typeof characterData==='undefined'?{}:characterData);
  if(!Array.isArray(incoming.unlockedCharacters)||!Array.isArray(incoming.clearedLevels))throw new Error('存档数据不完整');
  const unlocked=[...new Set(incoming.unlockedCharacters.filter(id=>typeof id==='string'&&knownCharacters.includes(id)))];
  const cleared=[...new Set(incoming.clearedLevels.map(Number).filter(level=>Number.isInteger(level)&&level>=1&&level<=4))];
  const playerName=typeof incoming.playerName==='string'&&incoming.playerName.trim()?incoming.playerName.trim().slice(0,24):'指挥家';
  const coins=Number(incoming.coins);
  if(!Number.isFinite(coins)||coins<0||coins>1000000000)throw new Error('存档中的金币数据无效');
  if(unlocked.length===0)throw new Error('存档中没有有效的已解锁角色');
  if(!confirm('导入存档会覆盖这台设备当前的游戏进度（金币、角色解锁和首次通关记录）。确定继续吗？'))return false;
  playerSave={unlockedCharacters:unlocked,coins:Math.floor(coins),clearedLevels:cleared,playerName};
  persistSave(); updateCoinDisplay();
  if(typeof renderLevelCoins==='function')renderLevelCoins();
  alert('账号转移成功！当前设备已载入存档中的游戏进度。');
  return true;
}
function importAccountSaveText(){
  const existing=document.getElementById('accountSaveTextDialog'); if(existing)existing.remove();
  const overlay=document.createElement('div');
  overlay.id='accountSaveTextDialog';
  overlay.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:14px;box-sizing:border-box;';
  const panel=document.createElement('div');
  panel.style.cssText='width:min(720px,100%);max-height:92vh;overflow:auto;background:#172235;color:#fff;border:1px solid #52647e;border-radius:16px;padding:16px;box-sizing:border-box;font-family:system-ui,sans-serif;';
  const heading=document.createElement('h2'); heading.textContent='粘贴账号存档文本'; heading.style.cssText='margin:0 0 8px;font-size:20px;';
  const help=document.createElement('p'); help.textContent='请粘贴从“账号转移：显示存档文本”复制的完整存档文本。导入会覆盖当前设备的金币、角色解锁和首次通关记录。'; help.style.cssText='font-size:13px;line-height:1.6;color:#c1cee1;';
  const area=document.createElement('textarea'); area.placeholder='在此粘贴完整的账号存档文本…'; area.setAttribute('aria-label','粘贴账号存档文本'); area.spellcheck=false; area.style.cssText='display:block;width:100%;height:38vh;min-height:180px;box-sizing:border-box;background:#0b1220;color:#e9f2ff;border:1px solid #52647e;border-radius:8px;padding:10px;font:12px/1.5 monospace;';
  const buttons=document.createElement('div'); buttons.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;';
  const makeButton=(label,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='border:0;border-radius:8px;padding:11px 14px;background:#3c72c5;color:white;font-weight:600;';b.addEventListener('click',fn);return b;};
  buttons.appendChild(makeButton('验证并导入',()=>{
    try{
      const raw=area.value.trim();
      if(!raw)throw new Error('请先粘贴存档文本');
      if(raw.length>1024*1024)throw new Error('存档文本过大');
      const payload=decodeAccountSaveText(raw);
      const applied=validateAndApplyAccountSave(payload);
      if(applied)overlay.remove();
    }catch(error){alert('文本导入失败：'+(error&&error.message?error.message:'存档文本无法读取')+'\n请确认复制了完整的存档文本，且没有漏掉开头或结尾。');}
  }));
  buttons.appendChild(makeButton('清空',()=>{area.value='';area.focus();}));
  buttons.appendChild(makeButton('关闭',()=>overlay.remove()));
  panel.append(heading,help,area,buttons); overlay.appendChild(panel);
  overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove();});
  document.body.appendChild(overlay); area.focus();
}
