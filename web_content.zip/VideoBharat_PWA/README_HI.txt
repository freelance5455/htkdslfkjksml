VIDEO BHARAT — INSTALLABLE WEB APP (PWA) DEMO

यह Android APK नहीं है। यह installable PWA का source package है।

इसमें:
- हिंदी mobile UI
- demo feed, search, category chips
- फोन से चुने गए वीडियो का स्थानीय playback (controls के साथ)
- demo likes/subscriptions/profile
- PWA manifest, service worker और app icons

महत्वपूर्ण सीमाएँ:
- वीडियो सर्वर पर अपलोड नहीं होते।
- अकाउंट/लॉगिन, ऑनलाइन comments, real channels, cloud video streaming,
  moderation backend, ads और creator payments जुड़े नहीं हैं।
- कोई वास्तविक आय/भुगतान नहीं है।
- PWA इंस्टॉल करने के लिए इसे HTTPS वाली वेबसाइट पर होस्ट करना होगा।
  ZIP या HTML फ़ाइल सीधे खोलने से Android home-screen install हर बार उपलब्ध नहीं होगा।

होस्ट करने के सामान्य तरीके:
1. ZIP extract करें।
2. index.html, manifest.webmanifest, sw.js और icons फ़ोल्डर को HTTPS static hosting
   (जैसे GitHub Pages/Netlify) पर publish करें।
3. Android Chrome में उस HTTPS URL को खोलें।
4. Chrome menu ⋮ > Install app या Add to Home screen चुनें।

Native APK बनाने के लिए Android Studio/FlutterFlow जैसे tool से अलग Android build करना होगा।
