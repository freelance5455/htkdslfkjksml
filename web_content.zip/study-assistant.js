
import { createAHMADAiChat } from "./ai.js";

// عناصر المساعد الدراسي
const studySection = document.getElementById("studyAssistantSection");
const studySubject = document.getElementById("studySubject");
const studyAction = document.getElementById("studyAction");
const studyLevel = document.getElementById("studyLevel");

const generateStudyBtn = document.getElementById("generateStudyBtn");
const studyStatus = document.getElementById("studyAssistantStatus");
const studyResult = document.getElementById("studyAssistantResult");
const studyOutput = document.getElementById("studyAssistantOutput");
const copyStudyBtn = document.getElementById("copyStudyResultBtn");
// عناصر تصوير ورفع صفحات الدروس
const studyCameraBtn = document.getElementById("studyCameraBtn");
const studyGalleryBtn = document.getElementById("studyGalleryBtn");
const studyCameraInput = document.getElementById("studyCameraInput");
const studyGalleryInput = document.getElementById("studyGalleryInput");
const studyImagePreview = document.getElementById("studyImagePreview");

// الصور المختارة
let studyImages = [];

// فتح الكاميرا
studyCameraBtn?.addEventListener("click", () => {
  studyCameraInput?.click();
});

// فتح المعرض
studyGalleryBtn?.addEventListener("click", () => {
  studyGalleryInput?.click();
});

// استقبال الصور وعرض معاينتها
function handleStudyImages(files) {
  const selectedFiles = Array.from(files).filter(file =>
    file.type.startsWith("image/")
  );

  studyImages.push(...selectedFiles);

  studyImagePreview.replaceChildren();

  studyImages.forEach((file, index) => {
    const item = document.createElement("div");
    item.className = "study-image-item";

    const image = document.createElement("img");
    image.src = URL.createObjectURL(file);
    image.alt = "صفحة من الدرس";

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.textContent = "✕";
    removeButton.title = "حذف الصورة";

    removeButton.addEventListener("click", () => {
      URL.revokeObjectURL(image.src);
      studyImages.splice(index, 1);
      renderStudyImages();
    });

    item.append(image, removeButton);
    studyImagePreview.appendChild(item);
  });
}

// إعادة عرض الصور بعد الحذف
function renderStudyImages() {
  studyImagePreview.replaceChildren();

  studyImages.forEach((file, index) => {
    const item = document.createElement("div");
    item.className = "study-image-item";

    const image = document.createElement("img");
    image.src = URL.createObjectURL(file);
    image.alt = "صفحة من الدرس";

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.textContent = "✕";

    removeButton.addEventListener("click", () => {
      URL.revokeObjectURL(image.src);
      studyImages.splice(index, 1);
      renderStudyImages();
    });

    item.append(image, removeButton);
    studyImagePreview.appendChild(item);
  });
}

studyCameraInput?.addEventListener("change", event => {
  handleStudyImages(event.target.files);
  event.target.value = "";
});

studyGalleryInput?.addEventListener("change", event => {
  handleStudyImages(event.target.files);
  event.target.value = "";
});

// أنواع المهام
const studyActions = {
  explain: "شرح الدرس بالتفصيل وبالتدرج",
  solve: "حل المسألة مع توضيح جميع خطوات الحل",
  summarize: "تلخيص المحتوى مع الحفاظ على المعلومات المهمة",
  quiz: "إنشاء اختبار تدريبي مع الأسئلة والخيارات والإجابات الصحيحة في نهاية الاختبار",
  flashcards: "إنشاء بطاقات حفظ بصيغة سؤال وجواب"
};

// مستويات الشرح
const studyLevels = {
  simple: "مبسّط جداً ومناسب للمبتدئين",
  intermediate: "متوسط مع تفاصيل وأمثلة",
  advanced: "متقدم وعميق مع التفاصيل العلمية"
};
// تنسيق نتائج المساعد الدراسي
function formatStudyResult(text) {
  const escapeHTML = (value) =>
    value.replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[char]);

  let html = escapeHTML(text);

  html = html.replace(/^### (.*)$/gm, "<h4>$1</h4>");
  html = html.replace(/^## (.*)$/gm, "<h3>$1</h3>");
  html = html.replace(/^# (.*)$/gm, "<h2>$1</h2>");

  html = html.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  // تنسيق الأكواد البرمجية متعددة الأسطر
html = html.replace(/```([\s\S]*?)```/g, (match, code) =>
  `<pre class="study-code-box"><code>${code.trim()}</code></pre>`
);

// تنسيق الاقتباسات والملاحظات
html = html.replace(/^&gt; ?(.*)$/gm, '<blockquote class="study-note-box">$1</blockquote>');
  html = html.replace(/\*(.*?)\*/g, "<em>$1</em>");
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");

  html = html.replace(/^\s*[-*] (.*)$/gm, "<li>$1</li>");
  html = html.replace(/(?:<li>.*<\/li>\n?)+/gs, (list) =>
    `<ul>${list}</ul>`
  );

  html = html.replace(/\n/g, "<br>");

  return html;
}
// القراءة الصوتية لنتائج المساعد الدراسي
let studyUtterance = null;
let studySpeechButton = null;

function stopStudySpeech() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }

  if (studySpeechButton) {
    studySpeechButton.textContent = "🔊 استمع";
    studySpeechButton.classList.remove("speaking");
  }

  studyUtterance = null;
  studySpeechButton = null;
}

function speakStudyResult(text, button) {
  if (!("speechSynthesis" in window)) {
    alert("متصفحك لا يدعم القراءة الصوتية.");
    return;
  }

  if (studySpeechButton === button) {
    stopStudySpeech();
    return;
  }

  stopStudySpeech();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "ar-SA";
  utterance.rate = 1;
  utterance.pitch = 1;

  studyUtterance = utterance;
  studySpeechButton = button;

  button.textContent = "⏹ إيقاف";
  button.classList.add("speaking");

  utterance.onend = () => {
    if (studyUtterance === utterance) stopStudySpeech();
  };

  utterance.onerror = () => {
    if (studyUtterance === utterance) stopStudySpeech();
  };

  window.speechSynthesis.speak(utterance);
}

function renderInteractiveQuiz(rawResult) {
  let quiz;

  try {
    const cleanJSON = rawResult
      .replace(/```json/gi, "")
      .replace(/```/g, "")
      .trim();

    quiz = JSON.parse(cleanJSON);
  } catch {
    throw new Error("تعذّر قراءة بيانات الاختبار.");
  }

  if (!Array.isArray(quiz.questions) || quiz.questions.length === 0) {
    throw new Error("لم يتم العثور على أسئلة صالحة.");
  }

  const questions = quiz.questions;

  if (!questions.every(q =>
    typeof q.question === "string" &&
    Array.isArray(q.options) &&
    q.options.length === 4 &&
    Number.isInteger(q.correctAnswer) &&
    q.correctAnswer >= 0 &&
    q.correctAnswer < 4
  )) {
    throw new Error("تنسيق أسئلة الاختبار غير صحيح.");
  }

  studyOutput.replaceChildren();

  const title = document.createElement("h3");
  title.textContent = quiz.title || "اختبار الدرس";
  studyOutput.appendChild(title);

  let current = 0;
let score = 0;
let studyMistakes = [];

  function showQuestion() {
    studyOutput.replaceChildren();

    const q = questions[current];

    const progress = document.createElement("p");
    progress.textContent = `السؤال ${current + 1} من ${questions.length}`;

    const question = document.createElement("h3");
    question.textContent = q.question;

    const optionsBox = document.createElement("div");
    optionsBox.className = "study-quiz-options";

    q.options.forEach((option, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = option;

      button.addEventListener("click", () => {
        const buttons = optionsBox.querySelectorAll("button");

        buttons.forEach((btn, i) => {
          btn.disabled = true;

          if (i === q.correctAnswer) {
            btn.classList.add("correct");
          } else if (i === index) {
            btn.classList.add("wrong");
          }
        });

        const isCorrect = index === q.correctAnswer;

if (isCorrect) {
  score++;
} else {
  studyMistakes.push({
    question: q.question,
    topic: q.topic || "موضوع غير محدد",
    selectedAnswer: q.options[index],
    correctAnswer: q.options[q.correctAnswer],
    explanation: q.explanation || ""
  });
}

        const feedback = document.createElement("p");
        feedback.textContent = isCorrect
          ? "✅ إجابة صحيحة!"
          : "❌ إجابة خاطئة.";

        const explanation = document.createElement("p");
        explanation.textContent = q.explanation || "";

        const next = document.createElement("button");
        next.type = "button";
        next.textContent = current === questions.length - 1
          ? "عرض النتيجة"
          : "السؤال التالي";

        next.addEventListener("click", () => {
          current++;

          if (current < questions.length) {
            showQuestion();
          } else {
            showFinalResult();
          }
        });

        studyOutput.append(feedback, explanation, next);
      });

      optionsBox.appendChild(button);
    });

    studyOutput.append(progress, question, optionsBox);
  }

function showFinalResult() {
  studyOutput.replaceChildren();

  const percentage = Math.round(
    score / questions.length * 100
  );
// تحليل نقاط الضعف حسب المحاور
const weaknessMap = {};

studyMistakes.forEach(item => {
  weaknessMap[item.topic] =
    (weaknessMap[item.topic] || 0) + 1;
});

const weaknessEntries = Object.entries(weaknessMap)
  .sort((a, b) => b[1] - a[1]);
  let evaluation = "";
  let advice = "";

  if (percentage >= 90) {
    evaluation = "🏆 ممتاز";
    advice = "أداء رائع! أنت متقن للدرس.";
  } else if (percentage >= 80) {
    evaluation = "🥇 جيد جداً";
    advice = "نتيجة جميلة! راجع الأخطاء البسيطة.";
  } else if (percentage >= 60) {
    evaluation = "👍 جيد";
    advice = "أنت تتقدم، لكن تحتاج إلى بعض المراجعة.";
  } else {
    evaluation = "📚 تحتاج إلى مراجعة";
    advice = "راجع الدرس وحاول الاختبار مرة أخرى.";
  }

  // حفظ نتيجة الاختبار
  try {
    const quizHistory = JSON.parse(
      localStorage.getItem("ahmadStudyQuizHistory") || "[]"
    );

    quizHistory.unshift({
      title: quiz.title || "اختبار الدرس",
      date: new Date().toLocaleString("ar"),
      score: score,
      total: questions.length,
      wrong: questions.length - score,
      mistakes: studyMistakes,
      percentage: percentage,
      evaluation: evaluation
    });

    localStorage.setItem(
      "ahmadStudyQuizHistory",
      JSON.stringify(quizHistory.slice(0, 100))
    );
  } catch (error) {
    console.error("Quiz History Save Error:", error);
  }

  const heading = document.createElement("h3");
  heading.textContent = "انتهى الاختبار 🎉";

  const result = document.createElement("p");
  result.textContent =
    `نتيجتك: ${score} من ${questions.length} (${percentage}%)`;

  const evaluationText = document.createElement("h3");
  evaluationText.textContent = evaluation;

  const adviceText = document.createElement("p");
  adviceText.textContent = advice;

  const retry = document.createElement("button");
  retry.type = "button";
  retry.textContent = "🔄 إعادة الاختبار";

  retry.addEventListener("click", () => {
    current = 0;
    score = 0;
    showQuestion();
  });

  studyOutput.append(
  heading,
  result,
  evaluationText,
  adviceText
);
if (weaknessEntries.length > 0) {
  const weaknessTitle = document.createElement("h3");
  weaknessTitle.textContent = "🎯 تقرير نقاط الضعف";

  const weaknessList = document.createElement("ul");

  weaknessEntries.forEach(([topic, count]) => {
    const li = document.createElement("li");
    li.textContent = `${topic}: ${count} أخطاء`;
    weaknessList.appendChild(li);
  });

  const detailsTitle = document.createElement("h3");
  detailsTitle.textContent = "📝 تفاصيل الإجابات الخاطئة";

  const detailsBox = document.createElement("div");

  studyMistakes.forEach((item, index) => {
    const card = document.createElement("div");

    const question = document.createElement("p");
    question.textContent = `${index + 1}. ${item.question}`;

    const topic = document.createElement("p");
    topic.textContent = `المحور: ${item.topic}`;

    const selected = document.createElement("p");
    selected.textContent = `إجابتك: ${item.selectedAnswer}`;

    const correct = document.createElement("p");
    correct.textContent = `الإجابة الصحيحة: ${item.correctAnswer}`;

    const explanation = document.createElement("p");
    explanation.textContent = `التفسير: ${item.explanation || "لا يوجد تفسير متاح."}`;

    card.append(
      question,
      topic,
      selected,
      correct,
      explanation
    );

    detailsBox.appendChild(card);
  });

  const weaknessAdvice = document.createElement("p");
  weaknessAdvice.textContent =
    `ابدأ بمراجعة محور "${weaknessEntries[0][0]}" لأنه الأكثر أخطاءً.`;

  studyOutput.append(
    weaknessTitle,
    weaknessList,
    detailsTitle,
    detailsBox,
    weaknessAdvice
  );
} else {
  const perfect = document.createElement("p");
  perfect.textContent = "🌟 رائع! لم تسجل أي إجابات خاطئة.";
  studyOutput.appendChild(perfect);
} 

studyOutput.appendChild(retry);
}

  showQuestion();
}

// إنشاء النتيجة التعليمية
generateStudyBtn?.addEventListener("click", async () => {
  const subject = studySubject?.value.trim();
  const action = studyActions[studyAction?.value];
  const level = studyLevels[studyLevel?.value];

  if (!subject && studyImages.length === 0) {
  studyStatus.hidden = false;
  studyStatus.textContent = "اكتب الموضوع أو صوّر صفحات الدرس أولاً.";
  return;
}

  if (!action || !level) {
    studyStatus.hidden = false;
    studyStatus.textContent = "يرجى اختيار المهمة والمستوى.";
    return;
  }

  generateStudyBtn.disabled = true;
  generateStudyBtn.textContent = "⏳ جارٍ تجهيز النتيجة...";
  studyStatus.hidden = false;
  studyStatus.textContent = "المساعد الدراسي يعمل على طلبك...";
  studyResult.hidden = true;

  try {
    const studyChat = createAHMADAiChat();

    const prompt = `
أنت المساعد التعليمي الرسمي لتطبيق AHMAD AI، واكتب اسم التطبيق دائماً AHMAD AI دون تغيير أو اختصار.

مهمتك:
${action}
${studyAction?.value === "quiz" ? `
تعليمات خاصة بالاختبار التفاعلي:
- أرجع الاختبار بصيغة JSON فقط دون أي كلام قبله أو بعده.
- أنشئ 15 أسئلة من محتوى الدرس.
- لكل سؤال 4 خيارات.
- حدّد إجابة صحيحة واحدة فقط.
- استخدم هذا الهيكل بالضبط:
{
  "title": "عنوان الاختبار",
  "questions": [
    {
      "question": "نص السؤال",
      "topic": "المحور أو المهارة التي يقيسها السؤال",
      "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
      "correctAnswer": 0,
      "explanation": "سبب صحة الإجابة"
    }
  ]
}
- correctAnswer هو رقم الخيار الصحيح ويبدأ من 0.
` : ""}
المادة أو الموضوع:
${subject || "استخرج موضوع الدرس من الصور المرفقة."}

تعليمات الصور:
- اقرأ جميع الصور المرفقة باعتبارها صفحات من الدرس نفسه.
- استخرج النصوص والعناوين والمعادلات والمعلومات المهمة منها.
- رتّب الصفحات وافهم محتواها قبل تنفيذ المهمة.
- اعتمد على محتوى الصور ولا تخترع نصوصاً غير موجودة فيها.
- إذا كانت صورة غير واضحة، أخبر المستخدم بذلك.
مستوى الشرح المطلوب:
${level}

تعليمات مهمة:
- أجب باللغة العربية الواضحة والمنظمة.
- التزم بالموضوع الذي أدخله المستخدم.
- قسّم الشرح إلى عناوين وفقرات واضحة.
- استخدم أمثلة عند الحاجة لتوضيح المعلومات.
- في المسائل الحسابية، اشرح خطوات الحل بالتسلسل وتحقق من النتيجة.
- في التلخيص، لا تحذف الأفكار الأساسية.
- في الاختبارات، اكتب الأسئلة أولاً ثم ضع الإجابات في قسم منفصل في النهاية.
- في بطاقات الحفظ، اجعل كل بطاقة سؤالاً واضحاً وجواباً مختصراً.
- لا تخترع معلومات أو مصادر أو نتائج غير مؤكدة.
- إذا كانت المعلومات المدخلة غير كافية، وضّح ما ينقصك.
- لا تكتب مقدمات طويلة أو كلاماً خارج المهمة المطلوبة.

قدّم النتيجة مباشرة.
`;

    const result = studyImages.length > 0
  ? await studyChat.sendWithImages(prompt, studyImages)
  : await studyChat.send(prompt);

    if (!result || !result.trim()) {
      throw new Error("لم يتم إنشاء نتيجة تعليمية.");
    }

    if (studyAction.value === "quiz") {
  renderInteractiveQuiz(result);
} else {
  studyOutput.innerHTML = formatStudyResult(result);
}

// زر القراءة الصوتية
studyOutput.querySelector(".study-speak-btn")?.remove();

const speakButton = document.createElement("button");
speakButton.type = "button";
speakButton.className = "study-speak-btn";
speakButton.textContent = "🔊 استمع";

speakButton.addEventListener("click", () => {
  speakStudyResult(studyOutput.textContent, speakButton);
});

studyOutput.appendChild(speakButton);
    studyResult.hidden = false;
    studyStatus.textContent = "تم إنجاز المهمة التعليمية بنجاح.";

  } catch (error) {
    console.error("AHMAD AI Study Error:", error);
    studyStatus.textContent = "حدث خطأ: " + error.message;

  } finally {
    generateStudyBtn.disabled = false;
    generateStudyBtn.textContent = "✨ ابدأ التعلم";
  }
});

// نسخ النتيجة
copyStudyBtn?.addEventListener("click", async () => {
  const text = studyOutput?.textContent.trim();

  if (!text) return;

  try {
    await navigator.clipboard.writeText(text);
    studyStatus.hidden = false;
    studyStatus.textContent = "تم نسخ النتيجة بنجاح.";

  } catch (error) {
    studyStatus.hidden = false;
    studyStatus.textContent = "تعذر النسخ. حاول مرة أخرى.";
  }
});
// عرض سجل الاختبارات السابقة
const showStudyQuizHistory = document.getElementById("showStudyQuizHistory");
const studyQuizHistoryList = document.getElementById("studyQuizHistoryList");
const deleteAllStudyQuizHistory = document.getElementById("deleteAllStudyQuizHistory");
deleteAllStudyQuizHistory.classList.add("delete-all-study-results");
deleteAllStudyQuizHistory?.addEventListener("click", () => {
  const history = JSON.parse(
    localStorage.getItem("ahmadStudyQuizHistory") || "[]"
  );

  if (history.length === 0) {
    alert("لا توجد نتائج لحذفها.");
    return;
  }

  if (!confirm("هل أنت متأكد من حذف جميع نتائج الاختبارات؟")) {
    return;
  }

  localStorage.removeItem("ahmadStudyQuizHistory");
  studyQuizHistoryList.replaceChildren();

  const empty = document.createElement("p");
  empty.textContent = "لا توجد اختبارات محفوظة حتى الآن.";
  studyQuizHistoryList.appendChild(empty);

  alert("تم حذف جميع النتائج بنجاح.");
});


showStudyQuizHistory?.addEventListener("click", () => {

  // إغلاق السجل إذا كان مفتوحاً
  if (!studyQuizHistoryList.hidden) {
    studyQuizHistoryList.hidden = true;
    showStudyQuizHistory.textContent = "📊 سجل الاختبارات السابقة";
    return;
  }

  const history = JSON.parse(
    localStorage.getItem("ahmadStudyQuizHistory") || "[]"
  );

  studyQuizHistoryList.replaceChildren();
  studyQuizHistoryList.hidden = false;
  showStudyQuizHistory.textContent = "✖ إغلاق سجل الاختبارات";

  if (history.length === 0) {
    const empty = document.createElement("p");
    empty.textContent = "لا توجد اختبارات محفوظة حتى الآن.";
    studyQuizHistoryList.appendChild(empty);
    return;
  }

  history.forEach((item, index) => {
    const card = document.createElement("div");
    card.className = "study-quiz-history-card";

    const title = document.createElement("h4");
    title.textContent = item.title || `اختبار ${index + 1}`;

    const date = document.createElement("p");
    date.textContent = item.date || "";

    const score = document.createElement("p");
    score.textContent = `النتيجة: ${item.score} من ${item.total}`;

    const percentage = document.createElement("p");
    percentage.textContent = `النسبة: ${item.percentage}%`;

    const evaluation = document.createElement("p");
    evaluation.textContent = `التقييم: ${item.evaluation || "غير محدد"}`;

    const wrong = document.createElement("p");
    wrong.textContent = `الإجابات الخاطئة: ${item.wrong}`;

const deleteButton = document.createElement("button");
deleteButton.type = "button";
deleteButton.textContent = "🗑️ حذف النتيجة";

deleteButton.className = "delete-single-study-result";


deleteButton.addEventListener("click", () => {
  if (!confirm("هل تريد حذف هذه النتيجة؟")) return;

  const history = JSON.parse(
    localStorage.getItem("ahmadStudyQuizHistory") || "[]"
  );

  history.splice(index, 1);

  localStorage.setItem(
    "ahmadStudyQuizHistory",
    JSON.stringify(history)
  );

  showStudyQuizHistory.click();
  showStudyQuizHistory.click();
});




    card.append(title, date, score, percentage, evaluation, wrong, deleteButton);
    studyQuizHistoryList.appendChild(card);
  });
});