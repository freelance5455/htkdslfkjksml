// JAMSHEED AI voice helper - loaded by index.html
(function(){
  const $ = id => document.getElementById(id);
  const input = $('input');
  const mic = $('micBtn');
  const status = $('voiceStatus');
  const voiceToggle = $('voiceToggle');
  const voiceTest = $('voiceTest');
  let rec = null;
  let listening = false;
  let voiceOn = true;

  function setStatus(t){ if(status) status.textContent=t; }
  function stop(){ try{ if(rec) rec.stop(); }catch(e){} listening=false; if(mic){mic.classList.remove('active');mic.textContent='🎤';} if(input) input.placeholder='अपना सवाल लिखो...'; }
  function speak(text){
    if(!voiceOn || !('speechSynthesis' in window)) return;
    try{
      speechSynthesis.cancel();
      const u=new SpeechSynthesisUtterance(text);
      u.lang='hi-IN'; u.rate=0.78; u.pitch=1; u.volume=0.65;
      const vs=speechSynthesis.getVoices();
      const hi=vs.find(v=>/^hi(-|_)/i.test(v.lang));
      if(hi) u.voice=hi;
      u.onstart=()=>setStatus('🔊 जवाब बोल रहा हूँ...');
      u.onend=()=>setStatus('आवाज़ तैयार है');
      speechSynthesis.speak(u);
    }catch(e){}
  }
  window.JAMSHEEDSpeak = speak;

  function start(){
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){ alert('भाई, इस browser में Voice Input उपलब्ध नहीं है। Android Chrome में खोलकर Microphone Permission Allow करो।'); return; }
    if(listening){stop();return;}
    rec=new SR(); rec.lang='hi-IN'; rec.continuous=false; rec.interimResults=false; rec.maxAlternatives=3;
    rec.onstart=()=>{listening=true;if(mic){mic.classList.add('active');mic.textContent='🔴';}if(input)input.placeholder='🎙️ बोलो भाई...';setStatus('🎙️ सुन रहा हूँ... बोलो भाई');};
    rec.onresult=e=>{const t=e.results?.[0]?.[0]?.transcript?.trim();if(t){input.value=t; setTimeout(()=>{const b=$('sendBtn'); if(b)b.click(); else input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));},150);}};
    rec.onerror=e=>{stop(); if(e.error==='not-allowed'||e.error==='service-not-allowed') alert('भाई, Microphone Permission Allow करो। फिर 🎤 दबाकर बोलो।'); else if(e.error==='no-speech') setStatus('आवाज़ नहीं मिली—फिर से 🎤 दबाओ।'); else setStatus('Voice Input में दिक्कत हुई—फिर से कोशिश करो।');};
    rec.onend=()=>{if(listening)stop();};
    try{rec.start();}catch(e){stop();}
  }
  if(mic) mic.onclick=start;
  if(voiceToggle) voiceToggle.onclick=()=>{voiceOn=!voiceOn;voiceToggle.textContent=voiceOn?'🔊 आवाज़: ON':'🔇 आवाज़: OFF';if(!voiceOn&&'speechSynthesis'in window)speechSynthesis.cancel();};
  if(voiceTest) voiceTest.onclick=()=>speak('अस्सलामु अलैकुम जिम्शेद भाई। JAMSHEED AI की आवाज़ टेस्ट हो रही है।');
  if('speechSynthesis'in window) speechSynthesis.onvoiceschanged=()=>speechSynthesis.getVoices();
  window.addEventListener('beforeunload',()=>{try{speechSynthesis.cancel();}catch(e){}});
})();
