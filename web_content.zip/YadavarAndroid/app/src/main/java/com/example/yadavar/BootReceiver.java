package com.example.yadavar;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
   try {
     String raw=c.getSharedPreferences("yadavar_native",Context.MODE_PRIVATE).getString("data_state",null); if(raw==null)return;
     JSONObject data=new JSONObject(raw); JSONArray a=data.optJSONArray("reminders"); if(a==null)return;
     long now=System.currentTimeMillis(),next=Long.MAX_VALUE; String nextId="yadavar_master_alarm_v1";
     for(int x=0;x<a.length();x++){JSONObject r=a.optJSONObject(x);if(r==null||r.optBoolean("acknowledgedAt",false))continue;long t=r.optLong("timestamp",0);if(t>now&&t<next){next=t;nextId="yadavar_master_alarm_v1";}}
     if(next!=Long.MAX_VALUE)AlarmReceiver.schedule(c,nextId,next);
   } catch(Exception ignored){}
 }
}
