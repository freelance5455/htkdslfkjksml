package com.example.yadavar;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.os.PowerManager;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.app.Notification;
import android.graphics.Color;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    public static MainActivity current;
    private WebView webView;
    private static final int REQ_NOTIFICATIONS = 1001;
    private static final String PREFS = "yadavar_native";
    private static final String CH_VIBRATE = "yadavar_alarm_vibrate";
    private static final String CH_SILENT_VIBRATE = "yadavar_alarm_no_vibrate";
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        createChannels();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(13, 18, 32));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(false); s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("try{if(window.AndroidBridge&&window.onYadavarNativeReady)window.onYadavarNativeReady();}catch(e){}", null);
                if (getIntent() != null && getIntent().getBooleanExtra("yadavar_alarm_open", false)) {
                    view.postDelayed(() -> view.evaluateJavascript("try{if(window.onYadavarAlarm)window.onYadavarAlarm();}catch(e){}", null), 450);
                    getIntent().removeExtra("yadavar_alarm_open");
                }
            }
        });
        webView.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume(); current = this;
        if (webView != null) webView.postDelayed(() -> {
            if (getIntent() != null && getIntent().getBooleanExtra("yadavar_alarm_open", false)) {
                webView.evaluateJavascript("try{if(window.onYadavarAlarm)window.onYadavarAlarm();}catch(e){}", null);
                getIntent().removeExtra("yadavar_alarm_open");
            } else webView.evaluateJavascript("try{if(window.onYadavarNativeReady)window.onYadavarNativeReady();}catch(e){}", null);
        }, 300);
    }
    @Override protected void onPause() { if (current == this) current = null; super.onPause(); }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("(function(){var o=document.getElementById('alarmOverlay');if(o&&o.classList.contains('show')){var d=document.getElementById('dismiss');if(d)d.click();return;}var m=document.getElementById('formModal');if(m&&m.classList.contains('show'))return;})()", null);
        super.onBackPressed();
    }

    void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        } else if (Build.VERSION.SDK_INT >= 31) {
            try { AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(am!=null&&!am.canScheduleExactAlarms()) startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); } catch(Exception ignored) {}
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && Build.VERSION.SDK_INT >= 31) {
            try {
                AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())));
                }
            } catch (Exception ignored) {}
        }
    }
    private void createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel a = new NotificationChannel(CH_VIBRATE, "هشدارهای یادآوری با ویبره", NotificationManager.IMPORTANCE_HIGH);
            a.setDescription("اعلان هنگام سررسیدن یادآورها"); a.enableVibration(true); a.setVibrationPattern(new long[]{0,700,250,700}); a.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationChannel b = new NotificationChannel(CH_SILENT_VIBRATE, "هشدارهای یادآوری بدون ویبره", NotificationManager.IMPORTANCE_HIGH);
            b.setDescription("اعلان یادآورها بدون ویبره"); b.enableVibration(false); b.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(a); nm.createNotificationChannel(b);
        }
    }
    void eval(String js) { if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

    public class Bridge {
        private final Context ctx;
        Bridge(Context c) { ctx = c.getApplicationContext(); }
        @JavascriptInterface public String load(String key) { return getSharedPreferences(PREFS, MODE_PRIVATE).getString("data_"+key, null); }
        @JavascriptInterface public void save(String key, String value) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("data_"+key, value).apply(); }
        @JavascriptInterface public void setAlarm(String id, long timestamp, String callback) { AlarmReceiver.schedule(ctx, id, timestamp); }
        @JavascriptInterface public void cancelAlarm(String id) { AlarmReceiver.cancel(ctx, id); }
        @JavascriptInterface public void requestNotificationPermission() { if (current != null) current.runOnUiThread(() -> current.requestNotificationPermissionIfNeeded()); }
        @JavascriptInterface public void postNotification(String id, String title, String body) { AlarmReceiver.showNow(ctx, id, title, body, true); }
        @JavascriptInterface public void vibrate(long[] pattern) {
            try { Vibrator v = (Vibrator)ctx.getSystemService(VIBRATOR_SERVICE); if(v != null && v.hasVibrator()) { if(Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1)); else v.vibrate(pattern, -1); } } catch(Exception ignored){}
        }
        @JavascriptInterface public void stopVibration() { try { Vibrator v=(Vibrator)ctx.getSystemService(VIBRATOR_SERVICE); if(v!=null)v.cancel(); } catch(Exception ignored){} }
        @JavascriptInterface public void setKeepScreenOn(boolean enabled) {
            if (current == null) return;
            current.runOnUiThread(() -> { if(enabled) current.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else current.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); });
        }
        @JavascriptInterface public String getPackageNameValue() { return ctx.getPackageName(); }
        @JavascriptInterface public void launchApp(String pkg) { if(current!=null) current.runOnUiThread(() -> { Intent i=ctx.getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);ctx.startActivity(i);} }); }
        @JavascriptInterface public void openNotificationSettings() {
            if (current == null) return;
            current.runOnUiThread(() -> { if(Build.VERSION.SDK_INT>=26){Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, current.getPackageName());current.startActivity(i);} else { Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+current.getPackageName()));current.startActivity(i);} });
        }
        @JavascriptInterface public boolean hasExactAlarmPermission() { return Build.VERSION.SDK_INT < 31 || ((AlarmManager)ctx.getSystemService(ALARM_SERVICE)).canScheduleExactAlarms(); }
        @JavascriptInterface public void requestExactAlarmPermission() { if(current!=null&&Build.VERSION.SDK_INT>=31) current.runOnUiThread(() -> { try { current.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+current.getPackageName()))); } catch(Exception ignored){} }); }
    }
}
