package com.example.yadavar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.app.TaskStackBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    static final String PREFS = "yadavar_native";
    static final String CH_VIBRATE = "yadavar_alarm_vibrate";
    static final String CH_SILENT_VIBRATE = "yadavar_alarm_no_vibrate";
    static final String EXTRA_ID = "alarm_id";

    static PendingIntent pending(Context c, String id) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction("com.example.yadavar.ALARM."+id).putExtra(EXTRA_ID,id);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }
    public static void schedule(Context c, String id, long when) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi=pending(c,id);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); }
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException e) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_alarm_id",id).putLong("last_alarm_time",when).apply();
    }
    public static void cancel(Context c, String id) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); am.cancel(pending(c,id));
        if (id.equals(c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("last_alarm_id",""))) c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().remove("last_alarm_id").remove("last_alarm_time").apply();
    }
    @Override public void onReceive(Context context, Intent intent) {
        String id=intent.getStringExtra(EXTRA_ID); if(id==null) id="yadavar_master_alarm_v1";
        String title="زمان یادآوری فرا رسیده", body="برای مشاهدهٔ یادآور، برنامه را باز کنید."; boolean vibrate=true;
        try {
            android.content.SharedPreferences prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
            String raw=prefs.getString("data_state",null);
            if(raw!=null){
                JSONObject data=new JSONObject(raw); JSONArray a=data.optJSONArray("reminders");
                if(a==null && raw.trim().startsWith("[")) a=new JSONArray(raw);
                long now=System.currentTimeMillis(); JSONObject best=null; long bestDiff=Long.MAX_VALUE;
                JSONArray pending;
                try { String pr=prefs.getString("data_yadavar_pending_alarm_v4","[]"); pending=new JSONArray(pr); } catch(Exception e){pending=new JSONArray();}
                java.util.HashSet<String> queued=new java.util.HashSet<>();
                for(int j=0;j<pending.length();j++){JSONObject q=pending.optJSONObject(j);if(q!=null)queued.add(q.optString("id")+"|"+q.optLong("timestamp",0));}
                if(a!=null) for(int x=0;x<a.length();x++){
                    JSONObject r=a.optJSONObject(x); if(r==null || (!r.isNull("acknowledgedAt") && r.has("acknowledgedAt"))) continue;
                    long ts=r.optLong("timestamp",0); if(ts<=0 || ts>now+5000) continue;
                    String key=r.optString("id")+"|"+ts; if(queued.contains(key))continue;
                    JSONObject occurrence=new JSONObject(); occurrence.put("id",r.optString("id")); occurrence.put("timestamp",ts); occurrence.put("title",r.optString("title","یادآوری")); occurrence.put("repeatDaily",r.optBoolean("repeatDaily",false)); occurrence.put("dailyPrepared",r.optBoolean("repeatDaily",false)); pending.put(occurrence); queued.add(key);
                    long diff=Math.abs(ts-now); if(diff<bestDiff){bestDiff=diff;best=r;}
                    if(r.optBoolean("repeatDaily",false)) {
                        java.util.Calendar cal=java.util.Calendar.getInstance();cal.setTimeInMillis(ts);cal.add(java.util.Calendar.DAY_OF_YEAR,1);r.put("timestamp",cal.getTimeInMillis());r.put("acknowledgedAt",JSONObject.NULL);
                    } else { r.put("acknowledgedAt",JSONObject.NULL); }
                }
                if(best!=null){title="⏰ "+best.optString("title","یادآوری");body="زمان یادآوری فرا رسیده است";vibrate=best.optBoolean("vibrate",true);}
                if(a!=null) { if(data.has("reminders"))data.put("reminders",a); prefs.edit().putString("data_state",data.toString()).putString("data_yadavar_pending_alarm_v4",pending.toString()).apply(); }
                // پس از ثبت صف، نزدیک‌ترین یادآور آینده برای اجرای مستقل دوباره تنظیم شود.
                if(a!=null){long next=Long.MAX_VALUE;for(int x=0;x<a.length();x++){JSONObject r=a.optJSONObject(x);if(r==null||(!r.isNull("acknowledgedAt")&&r.has("acknowledgedAt")))continue;long t=r.optLong("timestamp",0);if(t>now&&t<next)next=t;}if(next!=Long.MAX_VALUE)schedule(context,"yadavar_master_alarm_v1",next);}
            }
        } catch(Exception ignored){}
        showNow(context,id,title,body,vibrate);
        MainActivity a=MainActivity.current;
        if(a!=null) a.eval("try{if(window.onYadavarAlarm)window.onYadavarAlarm();}catch(e){}");
    }
    public static void showNow(Context c, String id, String title, String body, boolean vibrate) {
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26 && nm.getNotificationChannel(vibrate?CH_VIBRATE:CH_SILENT_VIBRATE)==null){
            NotificationChannel ch=new NotificationChannel(vibrate?CH_VIBRATE:CH_SILENT_VIBRATE, vibrate?"هشدارهای یادآوری با ویبره":"هشدارهای یادآوری بدون ویبره", NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(vibrate);nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("yadavar_alarm_open",true);
        PendingIntent content=PendingIntent.getActivity(c, id.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification.Builder builder;
        if(Build.VERSION.SDK_INT>=26) builder=new Notification.Builder(c,vibrate?CH_VIBRATE:CH_SILENT_VIBRATE);
        else builder=new Notification.Builder(c).setPriority(Notification.PRIORITY_MAX).setDefaults(Notification.DEFAULT_SOUND|(vibrate?Notification.DEFAULT_VIBRATE:0));
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_ALARM).setVisibility(Notification.VISIBILITY_PUBLIC).setOnlyAlertOnce(false);
        nm.notify(id.hashCode(),builder.build());
    }
}
