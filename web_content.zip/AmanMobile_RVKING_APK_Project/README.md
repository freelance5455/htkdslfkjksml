# Aman Mobile — R.V KING

This Android Studio project wraps the supplied `Aman_Mobile_RVKING_DATE_COMPLETE.html` in a local WebView.

The HTML is copied unchanged into `app/src/main/assets/index.html` so the existing UI/data logic is preserved.

## Build APK
Open this folder in Android Studio, let Gradle sync, then choose:
Build > Build APK(s)

The debug APK will be under:
`app/build/outputs/apk/debug/app-debug.apk`
