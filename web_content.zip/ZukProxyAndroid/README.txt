ZUK PROXY v1.0 — PROJETO ANDROID

Projeto-fonte Android que carrega a interface HTML no WebView; não é APK pronto.
A KEY de demonstração é: zukproxy-free
Depois da KEY, a tela pede o código de pareamento e só então mostra o painel.
O campo de pareamento é visual: este protótipo não estabelece uma sessão real de Depuração sem fio.

Para gerar APK: abra a pasta do projeto no Android Studio, sincronize o Gradle e use Build > Build APK(s).
O botão Z flutuante aparece dentro da tela do app após passar pelas telas de acesso.
