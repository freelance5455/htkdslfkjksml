চক্রবর্তী এন্টারপ্রাইজ APK তৈরি করার সহজ নির্দেশনা

এই ZIP-টি Android অ্যাপের সোর্স কোড। এটি নিজে APK নয়। APK বানাতে GitHub Actions ব্যবহার করা হয়েছে।

ফোন দিয়ে:
১. ZIP ডাউনলোড করে Extract করুন।
২. github.com-এ লগইন করে New repository তৈরি করুন (Private রাখতে পারেন)।
৩. Extract করা ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার আপলোড করুন; .github ফোল্ডারও থাকতে হবে।
৪. Repository-এর Actions ট্যাব খুলুন।
৫. “Build Chakraborty Enterprise APK” নির্বাচন করে Run workflow চাপুন।
৬. কাজ শেষ হলে সেই workflow run খুলুন এবং Artifacts থেকে Chakraborty-Enterprise-APK ZIP ডাউনলোড করুন।
৭. ZIP Extract করে app-debug.apk ফাইল খুলে Install চাপুন।

সতর্কতা: APK এই পরিবেশে compile বা ফোনে পরীক্ষা করা হয়নি। প্রথমে শুধু নিজের তৈরি/বিশ্বস্ত ফাইল ইনস্টল করুন।
