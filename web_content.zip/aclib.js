/* Adcash aclib zones — Interstitial + Display banner 300x250
   Requires: <script src="//acscdn.com/script/aclib.js"></script> before this file.
   UNLIMITED: the interstitial fires on EVERY user click (no cooldown / no cap). */
(function () {
  var INTERSTITIAL_ZONE = "12067482";
  var BANNER_ZONE = "12067546";

  function ready(cb, tries) {
    tries = tries || 0;
    if (window.aclib) return cb();
    if (tries > 60) return;
    setTimeout(function () { ready(cb, tries + 1); }, 250);
  }

  function runInterstitial() {
    try { window.aclib.runInterstitial({ zoneId: INTERSTITIAL_ZONE }); return true; } catch (e) { return false; }
  }

  window.OmniAclib = {
    interstitialZone: INTERSTITIAL_ZONE,
    bannerZone: BANNER_ZONE,
    // Fire the interstitial ad immediately (no cooldown)
    interstitial: function () {
      var ok = false;
      if (window.aclib) ok = runInterstitial();
      else ready(function () { ok = runInterstitial(); });
      return ok;
    },
    // Render a 300x250 display banner inside the given container element
    banner: function (host) {
      if (!host || host.getAttribute("data-ad-done") === "1") return;
      host.setAttribute("data-ad-done", "1");
      ready(function () {
        try {
          var s = document.createElement("script");
          s.type = "text/javascript";
          s.text = "aclib.runBanner({ zoneId: '" + BANNER_ZONE + "' });";
          host.appendChild(s);
        } catch (e) {}
      });
    }
  };

  // Interstitial on page load
  ready(runInterstitial);

  // Interstitial on EVERY click/tap — card clicks, Download buttons, links,
  // everything. Unlimited: no frequency cap, no cooldown.
  function bindEveryClick() {
    var fire = function () { runInterstitial(); };
    document.addEventListener("click", fire, true);
    document.addEventListener("touchstart", fire, true);
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) runInterstitial();
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindEveryClick);
  } else {
    bindEveryClick();
  }
})();
