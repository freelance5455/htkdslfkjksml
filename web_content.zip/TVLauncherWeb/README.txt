TV Launcher WebView - Android 4.4 (API 19), ARMv7a
Giao diện HTML (app/src/main/assets/index.html) chạy trong WebView, gọi ứng dụng thật qua cầu nối Java.
- minSdk 19, targetSdk 19, không có mã native, không xin quyền nào.
- Android Studio: Build > Build APK(s)  |  Dòng lệnh: gradle assembleRelease
- Cài: adb install app-release.apk  rồi bấm Home -> chọn "TV Launcher" -> "Luôn luôn".
- Muốn đổi giao diện: chỉ cần sửa index.html.
