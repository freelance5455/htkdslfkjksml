package com.lite.tvlauncher;

import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.text.Collator;
import java.util.*;

public class MainActivity extends Activity {

    private WebView web;

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { callJs("window.reloadApps&&reloadApps()"); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF05080F);
        web.setScrollBarStyle(WebView.SCROLLBARS_INSIDE_OVERLAY);
        web.setVerticalScrollBarEnabled(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.requestFocus();
        web.loadUrl("file:///android_asset/index.html");

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);
    }

    private void callJs(final String js) {
        web.post(new Runnable() { public void run() { web.loadUrl("javascript:" + js); } });
    }

    @Override public void onBackPressed() { callJs("window.goHome&&goHome()"); }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        callJs("window.goHome&&goHome()");
    }

    @Override protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        web.removeJavascriptInterface("Android");
        web.destroy();
        super.onDestroy();
    }

    /** Cầu nối JS <-> Android. Chạy ở luồng riêng của WebView, không chặn giao diện. */
    public class Bridge {
        @JavascriptInterface
        public String getApps() {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN, null);
            q.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            final Collator c = Collator.getInstance();
            final PackageManager fpm = pm;
            Collections.sort(list, new Comparator<ResolveInfo>() {
                public int compare(ResolveInfo x, ResolveInfo y) {
                    return c.compare(String.valueOf(x.loadLabel(fpm)), String.valueOf(y.loadLabel(fpm)));
                }
            });
            JSONArray arr = new JSONArray();
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("n", String.valueOf(ri.loadLabel(pm)));
                    o.put("p", pkg);
                    o.put("c", ri.activityInfo.name);
                    o.put("i", iconToBase64(ri.loadIcon(pm)));
                    arr.put(o);
                } catch (Exception ignored) {}
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void launch(String pkg, String cls) {
            try {
                Intent i = new Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(pkg, cls)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(i);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void info(String pkg) {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) {}
        }
    }

    private static String iconToBase64(Drawable d) {
        int sz = 96;
        Bitmap bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        d.setBounds(0, 0, sz, sz);
        d.draw(cv);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 90, bo);
        bm.recycle();
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }
}
