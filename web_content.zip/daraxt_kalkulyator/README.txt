NAVOIY ECO LABORATORIYA — NOQONUNIY KESILGAN DARAXTLAR ZARAR KALKULYATORI

ISHGA TUSHIRISH
1. ZIP arxivni telefonga yoki kompyuterga yuklab oling va arxivdan chiqaring.
2. index.html faylini Chrome, Edge, Firefox yoki boshqa zamonaviy brauzerda oching.
3. Internet talab qilinmaydi. Hisoblash qurilmaning o'zida bajariladi.
4. Hisobot ma'lumotlarini kiriting, har bir daraxt uchun alohida qator qo'shing.
5. Diametrni santimetrda, to'nka oldidan/yer bilan tutashgan joyidan o'lchang.
6. "Hisoblash" tugmasini bosing. "Hisobotni chop etish / PDF saqlash" orqali PDF yarating.

HISOBLASH ASOSI
- VMQ 464-son, 22.08.2022, 4-ilova: davlat o'rmon fondiga kirmaydigan daraxt va butalarni noqonuniy kesish, kundakov qilish, shikastlantirish yoki yo'q qilish uchun zarar koeffitsiyentlari.
- Diametr toifalari 4 sm gacha, 4.1–8, 8.1–12 ... 60.1–64 sm.
- 64 sm dan ortiq diametrda 64 sm jadval koeffitsiyentiga har bir ortiqcha santimetr uchun 0.5 koeffitsiyent qo'shiladi.
- 100 yoshdan kichik / 100 yosh va undan yuqori hamda kam qiymatli / qimmatbaho ustunlari alohida.
- Qimmatbaho navlarga moratoriy tatbiq etiladigan holatlarda zarar summasi 2 baravar qo'llanadi. Dastur bu tanlovni faqat "qimmatbaho" tur tanlanganda hisobga oladi.
- 2026-yil 1-sentabrdan BHM 440 000 so'm (PF-115, 23.06.2026). BHM maydoni tahrirlanadi.
- VMQ 464-sonning 38-bandi 2026-yilgi o'zgartirishlari bo'yicha noqonuniy kesilgan har bir daraxt uchun 100 tup ko'chat ekish va kamida 3 yil parvarishlash majburiyati ham yuzaga keladi. Dastur buni alohida ko'rsatadi.

MUHIM CHEKLOVLAR
Bu yordamchi dastur. Rasmiy dalolatnoma, ekologiya organining huquqiy xulosasi yoki undirish qarori emas. Daraxtning turi, yoshi, qiymat toifasi, moratoriy tatbiqi, o'rmon fondiga mansubligi va maxsus hudud maqomi vakolatli organ tomonidan aniqlanishi lozim. Davlat o'rmon fondi, Qizil kitob turlari, saksovul va yovvoyi butalar, maxsus muhofaza etiladigan hududlar uchun boshqa maxsus qoidalar qo'llanishi mumkin.

MANBALAR
1. VMQ 464-son, 22.08.2022, amaldagi tahrir: https://lex.uz/uz/acts/-6165732
2. PF-115-son, 23.06.2026 (BHM 440 000 so'm, 01.09.2026 dan): https://lex.uz/docs/-8283656

TARKIB
- index.html — offline ishlaydigan kalkulyator.
- README.txt — o'rnatish va foydalanish yo'riqnomasi.
- HUQUQIY_MANBALAR.txt — huquqiy asos va eslatmalar.
