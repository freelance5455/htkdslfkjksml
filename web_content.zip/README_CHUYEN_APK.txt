HƯỚNG DẪN ĐÓNG GÓI FILE ZIP SANG APK (ANDROID)
==============================================
Danh sách tệp trong gói ZIP:
- index.html                  : File khởi chạy chính cho các công cụ ZIP -> APK
- tycoon_nha_hang_lon_3d.html : Bản sao đầy đủ của game 3 nhà hàng lớn 3D
- icon.png & thư mục icons/   : Bộ icon ứng dụng 3D nhiều kích thước (72px -> 512px)
- manifest.json & sw.js       : Cấu hình Web App toàn màn hình & bộ nhớ đệm offline
- config.xml                  : Cấu hình chuẩn Cordova / VoltBuilder / PhoneGap
- capacitor.config.json       : Cấu hình chuẩn Capacitor Android

Cách chuyển ZIP sang APK nhanh trên điện thoại hoặc PC:
1. Dùng công cụ Website 2 APK Builder / HTML to APK / WebIntoApp / VoltBuilder:
   - Chọn chế độ "Local HTML Website" hoặc "Upload ZIP".
   - Trỏ tới file ZIP này (hoặc thư mục giải nén có chứa index.html).
   - Chọn Icon là file icon.png, chế độ màn hình ngang (Landscape) & Toàn màn hình (Fullscreen).
   - Bấm Build / Create APK để xuất file cài đặt .apk.
