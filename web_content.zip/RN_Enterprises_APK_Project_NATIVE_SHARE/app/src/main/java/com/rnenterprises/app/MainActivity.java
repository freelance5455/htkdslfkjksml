package com.rnenterprises.app;

import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.*;
import android.util.Base64;

public class MainActivity extends AppCompatActivity {
    WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b); web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }
    class AndroidBridge {
        @JavascriptInterface public void sharePdf(String base64, String filename){ new Thread(()->{
            try{ File dir=new File(getCacheDir(),"shared"); dir.mkdirs(); File f=new File(dir, safe(filename));
                try(FileOutputStream o=new FileOutputStream(f)){o.write(Base64.decode(base64, Base64.DEFAULT));}
                Uri u=FileProvider.getUriForFile(MainActivity.this,"com.rnenterprises.app.fileprovider",f);
                Intent i=new Intent(Intent.ACTION_SEND); i.setType("application/pdf"); i.putExtra(Intent.EXTRA_STREAM,u); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(()->startActivity(Intent.createChooser(i,"Share PDF via")));
            }catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF share failed: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        }).start(); }
        @JavascriptInterface public void savePdf(String base64, String filename){ new Thread(()->{
            try{ byte[] data=Base64.decode(base64, Base64.DEFAULT); String name=safe(filename);
                if(Build.VERSION.SDK_INT>=29){ ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/pdf"); v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/RN Enterprises"); Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new IOException("Could not create file"); try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(data);} }
                else { File d=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); File sub=new File(d,"RN Enterprises"); sub.mkdirs(); try(FileOutputStream o=new FileOutputStream(new File(sub,name))){o.write(data);} }
                runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF saved in Downloads/RN Enterprises",Toast.LENGTH_LONG).show());
            }catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF save failed: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        }).start(); }
        private String safe(String n){ return n.replaceAll("[^a-zA-Z0-9._-]","_"); }
    }
}
