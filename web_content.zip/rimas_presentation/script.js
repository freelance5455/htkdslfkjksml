(() => {
  const slides = Array.from(document.querySelectorAll('.slide'));
  const counter = document.getElementById('slideCounter');
  const progress = document.getElementById('progressBar');
  const prev = document.getElementById('prevBtn');
  const next = document.getElementById('nextBtn');
  let current = 0;

  function showSlide(index, updateHash = true) {
    current = Math.max(0, Math.min(index, slides.length - 1));
    slides.forEach((slide, i) => {
      slide.classList.toggle('active', i === current);
      slide.setAttribute('aria-hidden', i === current ? 'false' : 'true');
    });
    counter.textContent = `${String(current + 1).padStart(2, '0')} / ${String(slides.length).padStart(2, '0')}`;
    progress.style.width = `${((current + 1) / slides.length) * 100}%`;
    prev.disabled = current === 0;
    next.disabled = current === slides.length - 1;
    if (updateHash) history.replaceState(null, '', `#slide-${current + 1}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  prev.addEventListener('click', () => showSlide(current - 1));
  next.addEventListener('click', () => showSlide(current + 1));
  document.addEventListener('keydown', event => {
    if (['ArrowLeft', 'ArrowRight', 'PageDown', 'PageUp', ' '].includes(event.key)) {
      if (event.target.matches('a, button, input, textarea')) return;
      event.preventDefault();
      if (event.key === 'ArrowLeft' || event.key === 'PageDown' || event.key === ' ') showSlide(current + 1);
      if (event.key === 'ArrowRight' || event.key === 'PageUp') showSlide(current - 1);
    }
    if (event.key === 'Home') showSlide(0);
    if (event.key === 'End') showSlide(slides.length - 1);
  });

  let touchStartX = 0;
  document.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].screenX; }, { passive: true });
  document.addEventListener('touchend', e => {
    const delta = e.changedTouches[0].screenX - touchStartX;
    if (Math.abs(delta) > 70) showSlide(current + (delta < 0 ? 1 : -1));
  }, { passive: true });

  const initial = Number((location.hash.match(/slide-(\d+)/) || [])[1]) - 1;
  showSlide(Number.isFinite(initial) && initial >= 0 ? initial : 0, false);
})();