// Script principal de inicialización de ControlMax Comercial

document.addEventListener('DOMContentLoaded', () => {
    console.log('ControlMax Comercial cargado correctamente.');
    // Verificar al iniciar si ya existe una licencia guardada en el navegador
    if (typeof verificarLicenciaGuardada === 'function') {
        verificarLicenciaGuardada();
    }
});
