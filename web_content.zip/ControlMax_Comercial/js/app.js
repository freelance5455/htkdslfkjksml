// Script principal

document.addEventListener('DOMContentLoaded', () => {
    console.log('ControlMax Comercial iniciado.');
    if (typeof verificarLicenciaGuardada === 'function') {
        verificarLicenciaGuardada();
    }
});
