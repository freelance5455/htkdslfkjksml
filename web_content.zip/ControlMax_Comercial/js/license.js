// Módulo de Gestión y Validacion de Licencias .dat

function procesarArchivoLicencia() {
    const fileInput = document.getElementById('input-licencia');
    const mensajeBox = document.getElementById('mensaje-estado');

    if (!fileInput.files || fileInput.files.length === 0) {
        mostrarMensaje('Por favor, selecciona un archivo .dat válido.', 'error');
        return;
    }

    const archivo = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        try {
            const contenidoBase64 = e.target.result.trim();
            
            // Decodificar Base64 a string JSON
            const cadenaJSON = atob(contenidoBase64);
            const datosLicencia = JSON.parse(cadenaJSON);

            validarYGuardarLicencia(datosLicencia);
        } catch (err) {
            console.error('Error al decodificar la licencia:', err);
            mostrarMensaje('El archivo .dat no tiene un formato de licencia válido o está dañado.', 'error');
        }
    };

    reader.onerror = function() {
        mostrarMensaje('Ocurrió un error al intentar leer el archivo desde el disco.', 'error');
    };

    // Leer el archivo como texto plano (Base64)
    reader.readAsText(archivo);
}

function validarYGuardarLicencia(licencia) {
    if (!licencia.cliente || !licencia.expira) {
        mostrarMensaje('El archivo .dat no contiene los datos obligatorios de licencia.', 'error');
        return;
    }

    const hoy = new Date().toISOString().slice(0, 10);

    if (licencia.expira < hoy) {
        mostrarMensaje(`Licencia expirada el ${licencia.expira}. Contacte al administrador.`, 'warning');
        return;
    }

    // Guardar estado localmente
    localStorage.setItem('controlmax_licencia', JSON.stringify(licencia));

    mostrarMensaje(`¡Licencia activada con éxito para ${licencia.cliente}! Válida hasta: ${licencia.expira}`, 'success');

    // Actualizar interfaz principal
    mostrarEstadoSistema(licencia);
}

function verificarLicenciaGuardada() {
    const licenciaGuardada = localStorage.getItem('controlmax_licencia');
    if (licenciaGuardada) {
        try {
            const licencia = JSON.parse(licenciaGuardada);
            const hoy = new Date().toISOString().slice(0, 10);
            if (licencia.expira >= hoy) {
                mostrarEstadoSistema(licencia);
                mostrarMensaje(`Licencia activa: ${licencia.cliente} (Expira: ${licencia.expira})`, 'success');
            }
        } catch (e) {
            console.warn('Error leyendo licencia guardada');
        }
    }
}

function mostrarMensaje(texto, tipo) {
    const mensajeBox = document.getElementById('mensaje-estado');
    mensajeBox.className = `status-box status-${tipo}`;
    mensajeBox.innerText = texto;
    mensajeBox.style.display = 'block';
}

function mostrarEstadoSistema(licencia) {
    const appDiv = document.getElementById('app-principal');
    document.getElementById('info-cliente').innerText = `Cliente: ${licencia.cliente}`;
    document.getElementById('info-expiracion').innerText = `Fecha de vencimiento: ${licencia.expira}`;
    appDiv.style.display = 'block';
}
