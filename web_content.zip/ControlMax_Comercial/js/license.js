// Módulo de Validación y Carga Automática de Licencias .dat

function alSeleccionarArchivo(input) {
    const contenedorNombre = document.getElementById('nombre-archivo');
    if (input.files && input.files.length > 0) {
        contenedorNombre.innerText = `Archivo seleccionado: ${input.files[0].name}`;
        procesarArchivoLicencia(input.files[0]);
    }
}

function procesarArchivoLicencia(archivo) {
    if (!archivo) return;

    const reader = new FileReader();

    reader.onload = function(e) {
        try {
            const contenidoBase64 = e.target.result.trim();
            const cadenaJSON = atob(contenidoBase64);
            const datosLicencia = JSON.parse(cadenaJSON);

            validarYGuardarLicencia(datosLicencia);
        } catch (err) {
            console.error('Error al decodificar la licencia:', err);
            mostrarMensaje('El archivo .dat no tiene un formato válido o está dañado.', 'error');
        }
    };

    reader.onerror = function() {
        mostrarMensaje('Error al leer el archivo seleccionado.', 'error');
    };

    reader.readAsText(archivo);
}

function validarYGuardarLicencia(licencia) {
    if (!licencia.cliente || !licencia.expira) {
        mostrarMensaje('El archivo .dat no contiene los campos de licencia requeridos.', 'error');
        return;
    }

    const hoy = new Date().toISOString().slice(0, 10);

    if (licencia.expira < hoy) {
        mostrarMensaje(`Licencia expirada el ${licencia.expira}. Por favor renovar.`, 'warning');
        return;
    }

    localStorage.setItem('controlmax_licencia', JSON.stringify(licencia));
    mostrarMensaje(`¡Licencia activada con éxito para ${licencia.cliente}! Expira: ${licencia.expira}`, 'success');
    mostrarEstadoSistema(licencia);
}

function verificarLicenciaGuardada() {
    const licenciaGuardada = localStorage.setItem ? localStorage.getItem('controlmax_licencia') : null;
    if (licenciaGuardada) {
        try {
            const licencia = JSON.parse(licenciaGuardada);
            const hoy = new Date().toISOString().slice(0, 10);
            if (licencia.expira >= hoy) {
                mostrarEstadoSistema(licencia);
                mostrarMensaje(`Licencia activa: ${licencia.cliente} (Expira: ${licencia.expira})`, 'success');
            }
        } catch (e) {
            console.warn('Error al verificar la licencia guardada');
        }
    }
}

function mostrarMensaje(texto, tipo) {
    const mensajeBox = document.getElementById('mensaje-estado');
    mensajeBox.className = `status-box status-${tipo}`;
    mensajeBox.innerText = texto;
    mensajeBox.style.display = 'block';
}

function mostrarEstadoSistema(licencia) {
    const appDiv = document.getElementById('app-principal');
    document.getElementById('info-cliente').innerText = `Cliente: ${licencia.cliente}`;
    document.getElementById('info-expiracion').innerText = `Fecha de vencimiento: ${licencia.expira}`;
    appDiv.style.display = 'block';
}
