// Base de datos local (IndexedDB / LocalStorage helper)
console.log('Módulo de datos listo.');
