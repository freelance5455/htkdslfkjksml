// Módulo de base de datos local
console.log('Módulo de datos cargado.');
