ControlMax Comercial - Sistema de Punto de Venta e Inventarios
============================================================

Novedades:
- Sistema de validación de licencias mediante archivos .dat.
- Interfaz integrada con selector de archivos para activación offline.
