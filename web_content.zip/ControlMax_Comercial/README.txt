ControlMax Comercial - Sistema de Punto de Venta e Inventarios
============================================================

Novedades de esta versión:
- Botón de interfaz corregido: abre directamente el explorador de archivos para seleccionar el .dat.
- Lectura de licencias codificadas en Base64 mediante la API FileReader.
- Almacenamiento persisitente del estado de licencia en localStorage.
