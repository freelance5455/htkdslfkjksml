VEXORA Clothing Store — lightweight website prototype

Features:
- Product search
- Category filters and price sorting
- Wishlist
- Add to bag, remove items and subtotal
- Delivery details form and payment-method selector
- Responsive mobile layout

Important:
This is a front-end demo. It does not process real payments, submit orders, manage inventory or store customer details. Before launch, replace sample products/prices/contact details, add real product images and legal/store policies, and connect a verified payment gateway using its hosted checkout. Do not collect card details yourself.
