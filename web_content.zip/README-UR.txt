HTML to APK Converter — اردو ہدایات
====================================
اس ZIP میں:
- public/index.html: موبائل کے لیے ڈیش بورڈ
- server.js: Node.js سرور اور ZIP کی بنیادی جانچ
- package.json: ضروری packages

اہم حقیقت:
یہ پروجیکٹ اکیلا کسی عام static website hosting پر حقیقی APK compile نہیں کر سکتا۔
اصل APK build کے لیے Android SDK/Java/Gradle والا سرور یا حقیقی external build-provider API درکار ہے۔
/api/build جان بوجھ کر واضح پیغام دیتا ہے، جعلی APK یا جعلی download لنک نہیں بناتا۔

Node.js 20+ سرور پر چلانے کے لیے:
1. ZIP extract کریں۔
2. اس فولڈر میں terminal کھولیں۔
3. npm install
4. npm start
5. اپنے سرور کا URL براؤزر میں کھولیں۔

صرف index.html static hosting پر اپ لوڈ کرنے سے ڈیزائن نظر آئے گا، مگر server.js کے API routes کام نہیں کریں گے۔
مکمل APK builder کے لیے اصل build backend/provider adapter لازمی ہے۔ Secret API keys کو HTML/browser میں نہ رکھیں۔
ZIP میں root یا www/ فولڈر کے اندر index.html ہونی چاہیے۔
