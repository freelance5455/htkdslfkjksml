package com.example.mrroot

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ProjectAdapter
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        val projects = listOf(
            Project(1, "نظام إدارة الملفات", "تطبيق مشابه لـ Root Explorer",
                    ProjectType.VIDEO, "https://www.youtube.com/watch?v=ABC123"),
            Project(2, "مكتبة تحليل الأكواد", "أداة تحليل ذكية لمطوري أندرويد",
                    ProjectType.CODE, "fun analyzeCode(code: String): AnalysisResult { ... }", "Kotlin"),
            Project(3, "تطبيق حماية", "VPN مدمج مع ميزات الحماية",
                    ProjectType.VIDEO, "https://www.youtube.com/watch?v=XYZ789")
        )
        
        adapter = ProjectAdapter(projects) { project ->
            if (project.type == ProjectType.VIDEO) {
                openVideo(project)
            } else {
                openCode(project)
            }
        }
        
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        binding.tvProjectCount.text = "${projects.size} Projects"
    }
    
    fun addNewProject(view: android.view.View) {
        Toast.makeText(this, "قريباً: إضافة مشروع جديد!", Toast.LENGTH_SHORT).show()
    }
    
    private fun openVideo(project: Project) {
        val intent = Intent(this, VideoActivity::class.java)
        intent.putExtra("video_url", project.content)
        intent.putExtra("title", project.title)
        startActivity(intent)
    }
    
    private fun openCode(project: Project) {
        val intent = Intent(this, CodeActivity::class.java)
        intent.putExtra("code", project.content)
        intent.putExtra("language", project.language ?: "Text")
        intent.putExtra("title", project.title)
        startActivity(intent)
    }
}