package com.example.mrroot

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CodeActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_code)
        
        val title = intent.getStringExtra("title") ?: "كود"
        val code = intent.getStringExtra("code") ?: "// لا يوجد كود"
        val language = intent.getStringExtra("language") ?: "Text"
        
        findViewById<TextView>(R.id.tvCodeTitle).text = title
        findViewById<TextView>(R.id.tvCodeContent).text = code
        findViewById<TextView>(R.id.tvLanguage).text = "لغة: $language"
        
        findViewById<Button>(R.id.btnCopyCode).setOnClickListener {
            copyToClipboard(code)
        }
    }
    
    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("code", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }
}