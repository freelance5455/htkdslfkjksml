package com.example.mrroot

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProjectAdapter(
    private val projects: List<Project>,
    private val onItemClick: (Project) -> Unit
) : RecyclerView.Adapter<ProjectAdapter.ProjectViewHolder>() {
    
    class ProjectViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivIcon: ImageView = itemView.findViewById(R.id.ivIcon)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        val tvType: TextView = itemView.findViewById(R.id.tvType)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProjectViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_project, parent, false)
        return ProjectViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ProjectViewHolder, position: Int) {
        val project = projects[position]
        holder.tvTitle.text = project.title
        holder.tvDescription.text = project.description
        holder.tvType.text = if (project.type == ProjectType.VIDEO) "🎥 فيديو" else "💻 كود"
        
        // تغيير الأيقونة حسب النوع
        holder.ivIcon.setImageResource(
            if (project.type == ProjectType.VIDEO) 
                android.R.drawable.ic_media_play 
            else 
                android.R.drawable.ic_menu_edit
        )
        
        holder.itemView.setOnClickListener { onItemClick(project) }
    }
    
    override fun getItemCount() = projects.size
}