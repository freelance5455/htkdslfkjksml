package com.example.mrroot

data class Project(
    val id: Int,
    val title: String,
    val description: String,
    val type: ProjectType,
    val content: String,
    val language: String? = null
)

enum class ProjectType {
    VIDEO, CODE
}