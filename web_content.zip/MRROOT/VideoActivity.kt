package com.example.mrroot

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class VideoActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        
        val title = intent.getStringExtra("title") ?: "فيديو"
        val videoUrl = intent.getStringExtra("video_url") ?: ""
        
        findViewById<TextView>(R.id.tvVideoTitle).text = title
        
        // هنا يمكن إضافة مشغل فيديو (مثل ExoPlayer أو YouTubePlayer)
        Toast.makeText(this, "سيتم تشغيل الفيديو: $videoUrl", Toast.LENGTH_LONG).show()
    }
}