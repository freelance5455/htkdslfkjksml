# PhysicsVerse X — Android Project ZIP

This is an Android Studio-style Android application project. It wraps the PhysicsVerse X learning interface in a native Android WebView and includes the HTML, CSS, and JavaScript locally under `app/src/main/assets/`.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync complete (Android Gradle Plugin 8.7.3; JDK 17; Android SDK 35).
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).

Expected APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Some online ZIP-to-APK services require their own exact project template or a Gradle wrapper. If a service rejects this archive, check its required ZIP format or share the builder website URL so the project can be adapted to that service.
