Free-Studies — STORED LESSONS + SI CHAT (ToApp)

STUDENT APP
1. Unzip free-studies-stored
2. ToApp entry: index.html
3. Build APK

LESSONS
- Pre-generated interactive lessons in /lessons/*.json
- Mapped by js/lessons-index.js
- Topics without files show "Coming in next batch"

CHAT (optional online)
1. Deploy supabase/functions/chat
2. supabase secrets set OPENAI_API_KEY=sk-your-key
3. APP.chatEndpoint already points at /functions/v1/chat

NEVER put OpenAI secret key in the APK.

Developer: Ebi John Freeman · Opay 9112164008
