import "jsr:@supabase/functions-js/edge-runtime.d.ts";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) return new Response(JSON.stringify({ error: "OPENAI_API_KEY not set" }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
    const { message } = await req.json();
    const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        temperature: 0.5,
        messages: [
          { role: "system", content: "You are Super Intelligence inside Free-Studies, a Nigerian academic companion app (secondary, polytechnic, university, Master's, PhD). Answer study questions clearly and help with app usage. You are not an official WAEC/NECO/JAMB/NUC board. Keep answers concise and educational." },
          { role: "user", content: String(message || "").slice(0, 2000) }
        ]
      })
    });
    const aiJson = await aiRes.json();
    if (!aiRes.ok) return new Response(JSON.stringify({ error: aiJson?.error?.message || "AI error" }), { status: 502, headers: { ...cors, "Content-Type": "application/json" } });
    const reply = aiJson.choices?.[0]?.message?.content || "No reply";
    return new Response(JSON.stringify({ reply }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
