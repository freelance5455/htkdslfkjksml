const SUPABASE_URL = 'https://slxkmeyhjfqrzqduqleb.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_TzzrPwMWh2Dej5WBteoefg_4XiJNsAY';

const APP = {
  name: 'Free-Studies',
  tagline: 'Stored lessons · Super Intelligence chat',
  catchphrase: 'If you cannot find it in class, find it on Free-Studies',
  developer: 'Ebi John Freeman',
  donation: { bank: 'Opay', account: '9112164008', message: 'Please help improve and maintain Free-Studies' },
  fees: { registration: 0, examAccess: 2000, enabled: false },
  /** Chat only — secret OpenAI key stays on Edge Function, never in this file */
  chatEndpoint: '', // optional; on-device SI works without this. Set Edge Function URL for live model.
  build: 'toapp-stored-lessons'
};
