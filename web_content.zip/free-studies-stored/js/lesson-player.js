/**
 * Interactive slideshow player
 */
function renderSlidesToContainer(container, slides) {
  if (!container) return;
  var list = Array.isArray(slides) ? slides : [];
  container.innerHTML = '';
  for (var i = 0; i < list.length; i++) {
    var s = list[i] || {};
    var div = document.createElement('div');
    div.className = 'slide' + (i === 0 ? ' active' : '');
    var media = '';
    if (s.svg) {
      media = '<div class="slide-media">' + s.svg + '</div>';
    } else if (s.image) {
      media = '<div class="slide-media"><img class="slide-img" src="' + s.image + '" alt=""/></div>';
    } else if (s.image_url) {
      media = '<div class="slide-media"><img class="slide-img" src="' + s.image_url + '" alt=""/></div>';
    }
    div.innerHTML =
      (s.heading ? '<h2 class="slide-anim">' + s.heading + '</h2>' : '') +
      media +
      '<div class="slide-body slide-anim delay">' + (s.body || '') + '</div>';
    container.appendChild(div);
  }
}

function bindSlideNav(opts) {
  var current = 0;
  function getSlides() {
    return document.querySelectorAll('#slideContainer .slide');
  }

  function show(i) {
    var nodeList = getSlides();
    var list = Array.prototype.slice.call(nodeList); // NodeList → real Array (fixes list.map)
    if (!list.length) return;
    current = Math.max(0, Math.min(i, list.length - 1));
    for (var n = 0; n < list.length; n++) {
      list[n].classList.remove('active', 'slide-out-left', 'slide-out-right', 'slide-in');
      if (n === current) list[n].classList.add('active', 'slide-in');
    }
    var curEl = document.getElementById('currentSlide');
    var totEl = document.getElementById('totalSlides');
    if (curEl) curEl.textContent = String(current + 1);
    if (totEl) totEl.textContent = String(list.length);
    var prevBtn = document.getElementById('prevBtn');
    var nextBtn = document.getElementById('nextBtn');
    if (prevBtn) prevBtn.disabled = current === 0;
    if (nextBtn) nextBtn.textContent = current === list.length - 1 ? 'Finish' : 'Next →';

    var dots = document.getElementById('slideDots');
    if (dots) {
      var html = '';
      for (var d = 0; d < list.length; d++) {
        html += '<button type="button" class="dot' + (d === current ? ' on' : '') +
          '" data-i="' + d + '" aria-label="Slide ' + (d + 1) + '"></button>';
      }
      dots.innerHTML = html;
      var dotBtns = dots.querySelectorAll('.dot');
      for (var di = 0; di < dotBtns.length; di++) {
        (function (btn) {
          btn.onclick = function () { show(parseInt(btn.getAttribute('data-i'), 10)); };
        })(dotBtns[di]);
      }
    }
  }

  var prevBtn = document.getElementById('prevBtn');
  var nextBtn = document.getElementById('nextBtn');
  if (prevBtn) prevBtn.onclick = function () { show(current - 1); };
  if (nextBtn) {
    nextBtn.onclick = function () {
      if (current >= getSlides().length - 1) {
        if (opts && opts.onFinish) opts.onFinish();
        else history.back();
        return;
      }
      show(current + 1);
    };
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight' || e.key === ' ') {
      e.preventDefault();
      if (nextBtn) nextBtn.click();
    }
    if (e.key === 'ArrowLeft' && prevBtn) prevBtn.click();
  });

  var touchX = null;
  var sc = document.getElementById('slideContainer');
  if (sc) {
    sc.addEventListener('touchstart', function (e) {
      touchX = e.changedTouches[0].screenX;
    }, { passive: true });
    sc.addEventListener('touchend', function (e) {
      if (touchX == null) return;
      var dx = e.changedTouches[0].screenX - touchX;
      if (dx < -50 && nextBtn) nextBtn.click();
      if (dx > 50 && prevBtn) prevBtn.click();
      touchX = null;
    }, { passive: true });
  }

  show(0);
}
