/**
 * Super Intelligence chat
 * 1) Tries online endpoint when available
 * 2) Always falls back to on-device SI helper (no API key in app)
 * Never put OpenAI secret keys in this file.
 */
(function () {
  if (document.getElementById('siChatRoot')) return;

  function localSI(q) {
    var t = (q || '').toLowerCase().trim();
    if (!t) return 'Ask a study question, or type "help" for app guidance.';

    // App help
    if (/\b(help|how (do|to) use|tutorial|guide)\b/.test(t)) {
      return 'How to use Free-Studies:\n1) Open Courses and pick your track.\n2) Open a course outline.\n3) Topics marked Ready open full interactive lessons stored in the app.\n4) Other topics are still being added in later batches.\n5) Use this chat for study tips and app help anytime.';
    }
    if (/\b(ready|not installed|batch|missing lesson)\b/.test(t)) {
      return '“Ready” means a full lesson is stored in this app build. “Not installed yet” means the topic is on the map but the lesson file is not in this batch yet. Try Geography SSS1 → Latitudes and Longitudes → The grid system for a known Ready lesson.';
    }
    if (/\b(donate|opay|support|developer)\b/.test(t)) {
      return 'Free-Studies is developed by Ebi John Freeman. Optional support: Opay 9112164008. Thank you for helping maintain the project.';
    }
    if (/\b(admin|password)\b/.test(t)) {
      return 'Student app has no admin panel. The owner uses a separate Admin APK. Students only use Courses, lessons, and this chat.';
    }

    // Study heuristics
    if (/\b(quadratic|factoris|formula)\b/.test(t)) {
      return 'Quadratics: write as ax²+bx+c=0. Try factorisation first; otherwise x = [-b±√(b²−4ac)]/(2a). Always check roots in the original equation. Open the Ready lesson “Quadratic Equations” under SSS Maths if available.';
    }
    if (/\b(ionic|covalent|bond)\b/.test(t)) {
      return 'Ionic bonding: electron transfer → ions → electrostatic attraction (often metal + non-metal). Covalent: electron sharing (often non-metals). Properties follow structure (e.g. ionic lattices, high melting points). See Ready Chemistry lessons on bonding.';
    }
    if (/\b(newton|force|inertia)\b/.test(t)) {
      return 'Newton 1: inertia (uniform motion/rest unless net force). Newton 2: F=ma. Newton 3: action–reaction on different bodies. Identify the system before applying laws.';
    }
    if (/\b(photosynthesis|cell|mitochond)\b/.test(t)) {
      return 'Plant cells have wall, chloroplasts, large vacuole; animal cells do not. Mitochondria release energy (respiration). Match structure to function in exam answers.';
    }
    if (/\b(demand|supply|inflation|scarcity)\b/.test(t)) {
      return 'Scarcity forces choice; opportunity cost is the next best alternative forgone. Demand usually falls as price rises (ceteris paribus); supply rises with price. Inflation is a sustained rise in the general price level.';
    }
    if (/\b(democracy|constitution|election|citizen)\b/.test(t)) {
      return 'Democracy emphasises consent, accountability, and rights. Constitutions organise powers and rights. Elections should be free and fair. Citizenship brings rights and duties together.';
    }
    if (/\b(essay|comprehension|summary|grammar|concord)\b/.test(t)) {
      return 'Essays: plan, clear thesis, one idea per paragraph. Comprehension: evidence from the passage. Summary: main points only, own words. Concord: subject and verb must agree—watch intervening phrases.';
    }
    if (/\b(latitude|longitude|map|contour)\b/.test(t)) {
      return 'Latitude: N/S of Equator. Longitude: E/W of Greenwich. 15° longitude ≈ 1 hour local time difference. Map scale links map distance to ground; contours join equal heights (close = steep).';
    }
    if (/\b(research|thesis|literature review|methodology|viva|phd|msc)\b/.test(t)) {
      return 'Postgraduate tip: sharpen the research question first. Literature review must synthesise, not only list. Methods must be able to answer the questions. A PhD centres on a defensible contribution to knowledge; the viva tests authorship and understanding.';
    }
    if (/\b(jamb|waec|neco|exam|study plan)\b/.test(t)) {
      return 'Exam strategy: use the official syllabus as a checklist, practise timed past questions, log errors by cause (content, misread, haste), and revise weak topics every week—not only favourites.';
    }
    if (/\b(algorithm|flowchart|programming|database|network)\b/.test(t)) {
      return 'Algorithms are finite clear steps. Flowcharts visualise them. Databases store tables with keys; SQL retrieves data. Networks connect devices (LAN local, WAN wide). Think logic before syntax.';
    }
    if (/\b(hello|hi|hey)\b/.test(t)) {
      return 'Hello — I am Super Intelligence in Free-Studies. Ask about a subject (e.g. “explain ionic bonding”) or type help for app instructions. Stored lessons work offline; live cloud chat needs a deployed endpoint.';
    }

    // Topic search against index titles
    try {
      var idx = window.LESSONS_INDEX || {};
      var hits = [];
      var keys = Object.keys(idx);
      for (var i = 0; i < keys.length && hits.length < 5; i++) {
        var parts = keys[i].split('|');
        var topic = parts[2] || parts[parts.length - 1] || '';
        if (topic && t.split(/\s+/).some(function (w) { return w.length > 3 && topic.toLowerCase().indexOf(w) >= 0; })) {
          if (hits.indexOf(topic) < 0) hits.push(topic);
        }
      }
      if (hits.length) {
        return 'I found related Ready topics in this app:\n• ' + hits.join('\n• ') +
          '\n\nOpen Courses, find that topic marked Ready, and launch the interactive lesson. You asked: “' + q + '”.';
      }
    } catch (e) {}

    return 'Here is a study approach for “' + q + '”:\n' +
      '1) Open Courses and search that subject.\n' +
      '2) If a topic is Ready, open the full slideshow lesson.\n' +
      '3) Write definitions and one worked example in your notebook.\n' +
      '4) Self-test with the lesson checkpoint questions.\n' +
      'Type help for app navigation. (Online model chat is optional when the server endpoint is configured.)';
  }

  var root = document.createElement('div');
  root.id = 'siChatRoot';
  root.innerHTML =
    '<button type="button" id="siChatFab" aria-label="Open chat">SI</button>' +
    '<div id="siChatPanel" class="hidden">' +
    '<div class="si-head"><strong>Super Intelligence</strong><button type="button" id="siChatClose">×</button></div>' +
    '<div id="siChatLog"></div>' +
    '<form id="siChatForm">' +
    '<input id="siChatInput" type="text" placeholder="Ask a subject or type help…" autocomplete="off"/>' +
    '<button type="submit">Send</button></form>' +
    '<p class="si-note">On-device help always works · Online model optional</p></div>';
  document.body.appendChild(root);

  function addMsg(text, who) {
    var log = document.getElementById('siChatLog');
    var d = document.createElement('div');
    d.className = 'si-msg ' + who;
    d.textContent = text;
    log.appendChild(d);
    log.scrollTop = log.scrollHeight;
    return d;
  }

  document.getElementById('siChatFab').onclick = function () {
    document.getElementById('siChatPanel').classList.toggle('hidden');
  };
  document.getElementById('siChatClose').onclick = function () {
    document.getElementById('siChatPanel').classList.add('hidden');
  };

  document.getElementById('siChatForm').onsubmit = function (e) {
    e.preventDefault();
    var input = document.getElementById('siChatInput');
    var q = (input.value || '').trim();
    if (!q) return;
    input.value = '';
    addMsg(q, 'user');
    var thinking = addMsg('Thinking…', 'bot');

    var endpoint = (typeof APP !== 'undefined' && APP.chatEndpoint) ? APP.chatEndpoint : '';
    var anon = (typeof SUPABASE_ANON_KEY !== 'undefined') ? SUPABASE_ANON_KEY : '';

    function finish(text) {
      thinking.textContent = text;
    }

    // Try online briefly; always fall back to local SI (never leave user with Failed to fetch)
    if (endpoint && /^https?:/i.test(location.protocol || 'file:')) {
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 8000);
      fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + anon,
          'apikey': anon
        },
        body: JSON.stringify({ message: q }),
        signal: ctrl ? ctrl.signal : undefined
      }).then(function (res) { return res.json().then(function (data) { return { res: res, data: data }; }); })
        .then(function (pack) {
          clearTimeout(timer);
          if (pack.res.ok && pack.data && pack.data.reply) finish(pack.data.reply);
          else finish(localSI(q));
        })
        .catch(function () {
          clearTimeout(timer);
          finish(localSI(q));
        });
    } else {
      // file:// or no endpoint → local only
      setTimeout(function () { finish(localSI(q)); }, 200);
    }
  };
})();
