/**
 * Free-Studies lesson loader — bundle-first (works with file:// and ToApp)
 */
function resolveLessonId(courseId, unitTitle, topicTitle) {
  var idx = window.LESSONS_INDEX || {};
  if (!courseId && !topicTitle) return null;
  var exact = courseId + '|' + unitTitle + '|' + topicTitle;
  if (idx[exact]) return idx[exact];
  var keys = Object.keys(idx);
  var i, k;
  if (courseId && topicTitle) {
    for (i = 0; i < keys.length; i++) {
      k = keys[i];
      if (k.indexOf(courseId + '|') === 0 && k.slice(-(topicTitle.length + 1)) === '|' + topicTitle) return idx[k];
    }
  }
  if (topicTitle) {
    for (i = 0; i < keys.length; i++) {
      k = keys[i];
      if (k.slice(-(topicTitle.length + 1)) === '|' + topicTitle) return idx[k];
    }
  }
  return null;
}

function loadStoredLesson(lessonId) {
  return new Promise(function (resolve, reject) {
    if (!lessonId) {
      reject(new Error('No lesson id in link'));
      return;
    }
    var bundle = window.LESSONS_BUNDLE;
    if (!bundle || typeof bundle !== 'object') {
      reject(new Error('Lesson data failed to load (js/lessons-bundle.js missing). Open index.html from the free-studies-stored folder, not a single file.'));
      return;
    }
    if (bundle[lessonId]) {
      resolve(bundle[lessonId]);
      return;
    }
    reject(new Error('No stored lesson for id: ' + lessonId));
  });
}

function courseHasAnyLesson(courseId) {
  var idx = window.LESSONS_INDEX || {};
  var prefix = courseId + '|';
  return Object.keys(idx).some(function (k) { return k.indexOf(prefix) === 0; });
}
