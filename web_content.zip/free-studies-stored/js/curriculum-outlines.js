window.CURRICULUM = [
  {
    "id": "geo-sss1",
    "title": "Geography",
    "track": "secondary",
    "level": "SSS 1",
    "subject": "Geography",
    "category": "Science",
    "units": [
      {
        "title": "Introduction to Geography",
        "topics": [
          {
            "title": "Definition of geography"
          },
          {
            "title": "Scope of geography"
          },
          {
            "title": "Value of geography"
          },
          {
            "title": "Relationship of geography with other subjects"
          }
        ]
      },
      {
        "title": "The Solar System & Earth as a Planet",
        "topics": [
          {
            "title": "Shape and size of the Earth"
          },
          {
            "title": "Proofs of the Earth's sphericity"
          },
          {
            "title": "Rotation of the Earth (day and night)"
          },
          {
            "title": "Revolution of the Earth (seasons)"
          }
        ]
      },
      {
        "title": "Latitudes and Longitudes",
        "topics": [
          {
            "title": "The grid system"
          },
          {
            "title": "Calculating local time"
          },
          {
            "title": "Standard time"
          },
          {
            "title": "Calculating distance using latitude and longitude"
          }
        ]
      },
      {
        "title": "The Structure of the Earth",
        "topics": [
          {
            "title": "Internal layers: crust, SIAL, SIMA"
          },
          {
            "title": "Mantle"
          },
          {
            "title": "Core (NIFE)"
          },
          {
            "title": "External spheres: lithosphere, hydrosphere, atmosphere, biosphere"
          }
        ]
      },
      {
        "title": "Rocks",
        "topics": [
          {
            "title": "Igneous rocks and mode of formation"
          },
          {
            "title": "Sedimentary rocks and mode of formation"
          },
          {
            "title": "Metamorphic rocks and mode of formation"
          }
        ]
      },
      {
        "title": "Landforms",
        "topics": [
          {
            "title": "Fold mountains"
          },
          {
            "title": "Block mountains"
          },
          {
            "title": "Volcanic mountains"
          },
          {
            "title": "Residual mountains"
          },
          {
            "title": "Plateaus"
          },
          {
            "title": "Plains"
          }
        ]
      },
      {
        "title": "The Environment & Environmental Hazards",
        "topics": [
          {
            "title": "Meaning of environment"
          },
          {
            "title": "Domains of the environment"
          },
          {
            "title": "Environmental resources"
          },
          {
            "title": "Environmental hazards"
          }
        ]
      },
      {
        "title": "Geography of Nigeria",
        "topics": [
          {
            "title": "Location and position of Nigeria"
          },
          {
            "title": "Size of Nigeria"
          },
          {
            "title": "Physical setting"
          },
          {
            "title": "Relief of Nigeria"
          },
          {
            "title": "Drainage of Nigeria"
          },
          {
            "title": "Climate of Nigeria"
          },
          {
            "title": "Vegetation of Nigeria"
          }
        ]
      },
      {
        "title": "Population Dynamics",
        "topics": [
          {
            "title": "Basic population concepts"
          },
          {
            "title": "Overpopulation"
          },
          {
            "title": "Underpopulation"
          },
          {
            "title": "Optimum population"
          },
          {
            "title": "Migration"
          },
          {
            "title": "Death rates and related concepts"
          }
        ]
      },
      {
        "title": "Basic Map Reading",
        "topics": [
          {
            "title": "Map scale"
          },
          {
            "title": "Direction on maps"
          },
          {
            "title": "Conventional signs"
          },
          {
            "title": "Contour representation"
          }
        ]
      }
    ]
  },
  {
    "id": "geo-sss2",
    "title": "Geography",
    "track": "secondary",
    "level": "SSS 2",
    "subject": "Geography",
    "category": "Science",
    "units": [
      {
        "title": "Weather and Climate",
        "topics": [
          {
            "title": "Elements of weather"
          },
          {
            "title": "Climate factors"
          },
          {
            "title": "Climate classification"
          },
          {
            "title": "Nigeria's climatic regions"
          }
        ]
      },
      {
        "title": "Environmental Issues",
        "topics": [
          {
            "title": "Pollution"
          },
          {
            "title": "Desertification"
          },
          {
            "title": "Flooding"
          },
          {
            "title": "Conservation"
          }
        ]
      },
      {
        "title": "Settlement",
        "topics": [
          {
            "title": "Types of settlement"
          },
          {
            "title": "Urbanisation"
          },
          {
            "title": "Rural settlement patterns"
          }
        ]
      },
      {
        "title": "Transportation & Communication",
        "topics": [
          {
            "title": "Modes of transport in Nigeria"
          },
          {
            "title": "Importance of communication"
          }
        ]
      }
    ]
  },
  {
    "id": "geo-sss3",
    "title": "Geography",
    "track": "secondary",
    "level": "SSS 3",
    "subject": "Geography",
    "category": "Science",
    "units": [
      {
        "title": "Economic Geography",
        "topics": [
          {
            "title": "Agriculture in Nigeria"
          },
          {
            "title": "Mining and minerals"
          },
          {
            "title": "Manufacturing industries"
          },
          {
            "title": "Trade and commerce"
          }
        ]
      },
      {
        "title": "Regional Geography of Africa",
        "topics": [
          {
            "title": "Major physical features"
          },
          {
            "title": "Selected countries overview"
          }
        ]
      },
      {
        "title": "Fieldwork & Practical",
        "topics": [
          {
            "title": "Fieldwork techniques"
          },
          {
            "title": "Data presentation"
          },
          {
            "title": "WAEC practical orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "math-sss1",
    "title": "Mathematics",
    "track": "secondary",
    "level": "SSS 1",
    "subject": "Mathematics",
    "category": "Core",
    "units": [
      {
        "title": "Number and Numeration",
        "topics": [
          {
            "title": "Number bases"
          },
          {
            "title": "Modular arithmetic"
          },
          {
            "title": "Fractions, decimals and percentages"
          },
          {
            "title": "Standard form"
          }
        ]
      },
      {
        "title": "Algebraic Processes",
        "topics": [
          {
            "title": "Simplification"
          },
          {
            "title": "Factorisation"
          },
          {
            "title": "Equations and inequalities"
          },
          {
            "title": "Change of subject"
          }
        ]
      },
      {
        "title": "Mensuration",
        "topics": [
          {
            "title": "Lengths and perimeters"
          },
          {
            "title": "Areas"
          },
          {
            "title": "Volumes"
          },
          {
            "title": "Surface areas"
          }
        ]
      },
      {
        "title": "Geometry",
        "topics": [
          {
            "title": "Angles and triangles"
          },
          {
            "title": "Polygons"
          },
          {
            "title": "Circles \u2014 basic theorems"
          },
          {
            "title": "Constructions"
          }
        ]
      },
      {
        "title": "Statistics & Probability",
        "topics": [
          {
            "title": "Data presentation"
          },
          {
            "title": "Mean, median, mode"
          },
          {
            "title": "Probability basics"
          }
        ]
      }
    ]
  },
  {
    "id": "math-sss2",
    "title": "Mathematics",
    "track": "secondary",
    "level": "SSS 2",
    "subject": "Mathematics",
    "category": "Core",
    "units": [
      {
        "title": "Number and Numeration",
        "topics": [
          {
            "title": "Number bases"
          },
          {
            "title": "Modular arithmetic"
          },
          {
            "title": "Fractions, decimals and percentages"
          },
          {
            "title": "Standard form"
          }
        ]
      },
      {
        "title": "Algebraic Processes",
        "topics": [
          {
            "title": "Simplification"
          },
          {
            "title": "Factorisation"
          },
          {
            "title": "Equations and inequalities"
          },
          {
            "title": "Change of subject"
          }
        ]
      },
      {
        "title": "Mensuration",
        "topics": [
          {
            "title": "Lengths and perimeters"
          },
          {
            "title": "Areas"
          },
          {
            "title": "Volumes"
          },
          {
            "title": "Surface areas"
          }
        ]
      },
      {
        "title": "Geometry",
        "topics": [
          {
            "title": "Angles and triangles"
          },
          {
            "title": "Polygons"
          },
          {
            "title": "Circles \u2014 basic theorems"
          },
          {
            "title": "Constructions"
          }
        ]
      },
      {
        "title": "Statistics & Probability",
        "topics": [
          {
            "title": "Data presentation"
          },
          {
            "title": "Mean, median, mode"
          },
          {
            "title": "Probability basics"
          }
        ]
      },
      {
        "title": "Trigonometry",
        "topics": [
          {
            "title": "Trigonometric ratios"
          },
          {
            "title": "Angles of elevation and depression"
          },
          {
            "title": "Applications"
          }
        ]
      }
    ]
  },
  {
    "id": "math-sss3",
    "title": "Mathematics",
    "track": "secondary",
    "level": "SSS 3",
    "subject": "Mathematics",
    "category": "Core",
    "units": [
      {
        "title": "Number and Numeration",
        "topics": [
          {
            "title": "Number bases"
          },
          {
            "title": "Modular arithmetic"
          },
          {
            "title": "Fractions, decimals and percentages"
          },
          {
            "title": "Standard form"
          }
        ]
      },
      {
        "title": "Algebraic Processes",
        "topics": [
          {
            "title": "Simplification"
          },
          {
            "title": "Factorisation"
          },
          {
            "title": "Equations and inequalities"
          },
          {
            "title": "Change of subject"
          }
        ]
      },
      {
        "title": "Mensuration",
        "topics": [
          {
            "title": "Lengths and perimeters"
          },
          {
            "title": "Areas"
          },
          {
            "title": "Volumes"
          },
          {
            "title": "Surface areas"
          }
        ]
      },
      {
        "title": "Geometry",
        "topics": [
          {
            "title": "Angles and triangles"
          },
          {
            "title": "Polygons"
          },
          {
            "title": "Circles \u2014 basic theorems"
          },
          {
            "title": "Constructions"
          }
        ]
      },
      {
        "title": "Statistics & Probability",
        "topics": [
          {
            "title": "Data presentation"
          },
          {
            "title": "Mean, median, mode"
          },
          {
            "title": "Probability basics"
          }
        ]
      },
      {
        "title": "Trigonometry",
        "topics": [
          {
            "title": "Trigonometric ratios"
          },
          {
            "title": "Angles of elevation and depression"
          },
          {
            "title": "Applications"
          }
        ]
      },
      {
        "title": "Quadratic Equations & Functions",
        "topics": [
          {
            "title": "Factorisation method"
          },
          {
            "title": "Quadratic formula"
          },
          {
            "title": "Graphs of quadratic functions"
          },
          {
            "title": "Word problems"
          }
        ]
      }
    ]
  },
  {
    "id": "eng-sss1",
    "title": "English Language",
    "track": "secondary",
    "level": "SSS 1",
    "subject": "English Language",
    "category": "Core",
    "units": [
      {
        "title": "Essay Writing",
        "topics": [
          {
            "title": "Narrative essays"
          },
          {
            "title": "Descriptive essays"
          },
          {
            "title": "Argumentative essays"
          },
          {
            "title": "Expository essays"
          },
          {
            "title": "Article, speech and letter formats"
          }
        ]
      },
      {
        "title": "Comprehension",
        "topics": [
          {
            "title": "Reading for main ideas"
          },
          {
            "title": "Inference questions"
          },
          {
            "title": "Vocabulary in context"
          }
        ]
      },
      {
        "title": "Summary Writing",
        "topics": [
          {
            "title": "Summary skills"
          },
          {
            "title": "Avoiding irrelevance"
          },
          {
            "title": "Exam summary practice"
          }
        ]
      },
      {
        "title": "Lexis and Structure",
        "topics": [
          {
            "title": "Parts of speech review"
          },
          {
            "title": "Concord"
          },
          {
            "title": "Tenses"
          },
          {
            "title": "Punctuation"
          }
        ]
      },
      {
        "title": "Oral English",
        "topics": [
          {
            "title": "Vowels and consonants"
          },
          {
            "title": "Stress and intonation"
          },
          {
            "title": "Listening comprehension orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "eng-sss2",
    "title": "English Language",
    "track": "secondary",
    "level": "SSS 2",
    "subject": "English Language",
    "category": "Core",
    "units": [
      {
        "title": "Essay Writing",
        "topics": [
          {
            "title": "Narrative essays"
          },
          {
            "title": "Descriptive essays"
          },
          {
            "title": "Argumentative essays"
          },
          {
            "title": "Expository essays"
          },
          {
            "title": "Article, speech and letter formats"
          }
        ]
      },
      {
        "title": "Comprehension",
        "topics": [
          {
            "title": "Reading for main ideas"
          },
          {
            "title": "Inference questions"
          },
          {
            "title": "Vocabulary in context"
          }
        ]
      },
      {
        "title": "Summary Writing",
        "topics": [
          {
            "title": "Summary skills"
          },
          {
            "title": "Avoiding irrelevance"
          },
          {
            "title": "Exam summary practice"
          }
        ]
      },
      {
        "title": "Lexis and Structure",
        "topics": [
          {
            "title": "Parts of speech review"
          },
          {
            "title": "Concord"
          },
          {
            "title": "Tenses"
          },
          {
            "title": "Punctuation"
          }
        ]
      },
      {
        "title": "Oral English",
        "topics": [
          {
            "title": "Vowels and consonants"
          },
          {
            "title": "Stress and intonation"
          },
          {
            "title": "Listening comprehension orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "eng-sss3",
    "title": "English Language",
    "track": "secondary",
    "level": "SSS 3",
    "subject": "English Language",
    "category": "Core",
    "units": [
      {
        "title": "Essay Writing",
        "topics": [
          {
            "title": "Narrative essays"
          },
          {
            "title": "Descriptive essays"
          },
          {
            "title": "Argumentative essays"
          },
          {
            "title": "Expository essays"
          },
          {
            "title": "Article, speech and letter formats"
          }
        ]
      },
      {
        "title": "Comprehension",
        "topics": [
          {
            "title": "Reading for main ideas"
          },
          {
            "title": "Inference questions"
          },
          {
            "title": "Vocabulary in context"
          }
        ]
      },
      {
        "title": "Summary Writing",
        "topics": [
          {
            "title": "Summary skills"
          },
          {
            "title": "Avoiding irrelevance"
          },
          {
            "title": "Exam summary practice"
          }
        ]
      },
      {
        "title": "Lexis and Structure",
        "topics": [
          {
            "title": "Parts of speech review"
          },
          {
            "title": "Concord"
          },
          {
            "title": "Tenses"
          },
          {
            "title": "Punctuation"
          }
        ]
      },
      {
        "title": "Oral English",
        "topics": [
          {
            "title": "Vowels and consonants"
          },
          {
            "title": "Stress and intonation"
          },
          {
            "title": "Listening comprehension orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "phy-sss1",
    "title": "Physics",
    "track": "secondary",
    "level": "SSS 1",
    "subject": "Physics",
    "category": "Science",
    "units": [
      {
        "title": "Mechanics",
        "topics": [
          {
            "title": "Scalars and vectors"
          },
          {
            "title": "Speed, velocity, acceleration"
          },
          {
            "title": "Newton's laws"
          },
          {
            "title": "Work, energy, power"
          }
        ]
      },
      {
        "title": "Heat and Temperature",
        "topics": [
          {
            "title": "Temperature scales"
          },
          {
            "title": "Heat transfer"
          },
          {
            "title": "Expansion"
          }
        ]
      },
      {
        "title": "Waves and Sound",
        "topics": [
          {
            "title": "Wave properties"
          },
          {
            "title": "Sound waves"
          },
          {
            "title": "Applications"
          }
        ]
      },
      {
        "title": "Light",
        "topics": [
          {
            "title": "Reflection"
          },
          {
            "title": "Refraction"
          },
          {
            "title": "Lenses"
          }
        ]
      },
      {
        "title": "Electricity",
        "topics": [
          {
            "title": "Current and voltage"
          },
          {
            "title": "Ohm's law"
          },
          {
            "title": "Circuits"
          },
          {
            "title": "Electrical energy"
          }
        ]
      }
    ]
  },
  {
    "id": "phy-sss2",
    "title": "Physics",
    "track": "secondary",
    "level": "SSS 2",
    "subject": "Physics",
    "category": "Science",
    "units": [
      {
        "title": "Mechanics",
        "topics": [
          {
            "title": "Scalars and vectors"
          },
          {
            "title": "Speed, velocity, acceleration"
          },
          {
            "title": "Newton's laws"
          },
          {
            "title": "Work, energy, power"
          }
        ]
      },
      {
        "title": "Heat and Temperature",
        "topics": [
          {
            "title": "Temperature scales"
          },
          {
            "title": "Heat transfer"
          },
          {
            "title": "Expansion"
          }
        ]
      },
      {
        "title": "Waves and Sound",
        "topics": [
          {
            "title": "Wave properties"
          },
          {
            "title": "Sound waves"
          },
          {
            "title": "Applications"
          }
        ]
      },
      {
        "title": "Light",
        "topics": [
          {
            "title": "Reflection"
          },
          {
            "title": "Refraction"
          },
          {
            "title": "Lenses"
          }
        ]
      },
      {
        "title": "Electricity",
        "topics": [
          {
            "title": "Current and voltage"
          },
          {
            "title": "Ohm's law"
          },
          {
            "title": "Circuits"
          },
          {
            "title": "Electrical energy"
          }
        ]
      }
    ]
  },
  {
    "id": "phy-sss3",
    "title": "Physics",
    "track": "secondary",
    "level": "SSS 3",
    "subject": "Physics",
    "category": "Science",
    "units": [
      {
        "title": "Mechanics",
        "topics": [
          {
            "title": "Scalars and vectors"
          },
          {
            "title": "Speed, velocity, acceleration"
          },
          {
            "title": "Newton's laws"
          },
          {
            "title": "Work, energy, power"
          }
        ]
      },
      {
        "title": "Heat and Temperature",
        "topics": [
          {
            "title": "Temperature scales"
          },
          {
            "title": "Heat transfer"
          },
          {
            "title": "Expansion"
          }
        ]
      },
      {
        "title": "Waves and Sound",
        "topics": [
          {
            "title": "Wave properties"
          },
          {
            "title": "Sound waves"
          },
          {
            "title": "Applications"
          }
        ]
      },
      {
        "title": "Light",
        "topics": [
          {
            "title": "Reflection"
          },
          {
            "title": "Refraction"
          },
          {
            "title": "Lenses"
          }
        ]
      },
      {
        "title": "Electricity",
        "topics": [
          {
            "title": "Current and voltage"
          },
          {
            "title": "Ohm's law"
          },
          {
            "title": "Circuits"
          },
          {
            "title": "Electrical energy"
          }
        ]
      }
    ]
  },
  {
    "id": "chem-sss1",
    "title": "Chemistry",
    "track": "secondary",
    "level": "SSS 1",
    "subject": "Chemistry",
    "category": "Science",
    "units": [
      {
        "title": "Particulate Nature of Matter",
        "topics": [
          {
            "title": "Atoms and molecules"
          },
          {
            "title": "Atomic structure"
          },
          {
            "title": "Isotopes"
          }
        ]
      },
      {
        "title": "Chemical Combination",
        "topics": [
          {
            "title": "Ionic bonding"
          },
          {
            "title": "Covalent bonding"
          },
          {
            "title": "Formulae and equations"
          }
        ]
      },
      {
        "title": "States of Matter & Gas Laws",
        "topics": [
          {
            "title": "Solids, liquids, gases"
          },
          {
            "title": "Gas laws overview"
          }
        ]
      },
      {
        "title": "Acids, Bases and Salts",
        "topics": [
          {
            "title": "Properties of acids and bases"
          },
          {
            "title": "pH"
          },
          {
            "title": "Salts preparation"
          }
        ]
      },
      {
        "title": "Organic Chemistry Intro",
        "topics": [
          {
            "title": "Hydrocarbons overview"
          },
          {
            "title": "Crude oil and petroleum"
          }
        ]
      }
    ]
  },
  {
    "id": "chem-sss2",
    "title": "Chemistry",
    "track": "secondary",
    "level": "SSS 2",
    "subject": "Chemistry",
    "category": "Science",
    "units": [
      {
        "title": "Particulate Nature of Matter",
        "topics": [
          {
            "title": "Atoms and molecules"
          },
          {
            "title": "Atomic structure"
          },
          {
            "title": "Isotopes"
          }
        ]
      },
      {
        "title": "Chemical Combination",
        "topics": [
          {
            "title": "Ionic bonding"
          },
          {
            "title": "Covalent bonding"
          },
          {
            "title": "Formulae and equations"
          }
        ]
      },
      {
        "title": "States of Matter & Gas Laws",
        "topics": [
          {
            "title": "Solids, liquids, gases"
          },
          {
            "title": "Gas laws overview"
          }
        ]
      },
      {
        "title": "Acids, Bases and Salts",
        "topics": [
          {
            "title": "Properties of acids and bases"
          },
          {
            "title": "pH"
          },
          {
            "title": "Salts preparation"
          }
        ]
      },
      {
        "title": "Organic Chemistry Intro",
        "topics": [
          {
            "title": "Hydrocarbons overview"
          },
          {
            "title": "Crude oil and petroleum"
          }
        ]
      }
    ]
  },
  {
    "id": "chem-sss3",
    "title": "Chemistry",
    "track": "secondary",
    "level": "SSS 3",
    "subject": "Chemistry",
    "category": "Science",
    "units": [
      {
        "title": "Particulate Nature of Matter",
        "topics": [
          {
            "title": "Atoms and molecules"
          },
          {
            "title": "Atomic structure"
          },
          {
            "title": "Isotopes"
          }
        ]
      },
      {
        "title": "Chemical Combination",
        "topics": [
          {
            "title": "Ionic bonding"
          },
          {
            "title": "Covalent bonding"
          },
          {
            "title": "Formulae and equations"
          }
        ]
      },
      {
        "title": "States of Matter & Gas Laws",
        "topics": [
          {
            "title": "Solids, liquids, gases"
          },
          {
            "title": "Gas laws overview"
          }
        ]
      },
      {
        "title": "Acids, Bases and Salts",
        "topics": [
          {
            "title": "Properties of acids and bases"
          },
          {
            "title": "pH"
          },
          {
            "title": "Salts preparation"
          }
        ]
      },
      {
        "title": "Organic Chemistry Intro",
        "topics": [
          {
            "title": "Hydrocarbons overview"
          },
          {
            "title": "Crude oil and petroleum"
          }
        ]
      }
    ]
  },
  {
    "id": "bio-sss1",
    "title": "Biology",
    "track": "secondary",
    "level": "SSS 1",
    "subject": "Biology",
    "category": "Science",
    "units": [
      {
        "title": "Cell Biology",
        "topics": [
          {
            "title": "Plant and animal cells"
          },
          {
            "title": "Organelles"
          },
          {
            "title": "Cell theory"
          }
        ]
      },
      {
        "title": "Genetics",
        "topics": [
          {
            "title": "Mendelian genetics basics"
          },
          {
            "title": "Chromosomes"
          },
          {
            "title": "Variation"
          }
        ]
      },
      {
        "title": "Ecology",
        "topics": [
          {
            "title": "Ecosystems"
          },
          {
            "title": "Food chains and webs"
          },
          {
            "title": "Adaptation"
          }
        ]
      },
      {
        "title": "Physiology",
        "topics": [
          {
            "title": "Nutrition"
          },
          {
            "title": "Respiration"
          },
          {
            "title": "Transport systems"
          },
          {
            "title": "Excretion"
          }
        ]
      },
      {
        "title": "Reproduction",
        "topics": [
          {
            "title": "Asexual reproduction"
          },
          {
            "title": "Sexual reproduction in plants and animals"
          }
        ]
      }
    ]
  },
  {
    "id": "bio-sss2",
    "title": "Biology",
    "track": "secondary",
    "level": "SSS 2",
    "subject": "Biology",
    "category": "Science",
    "units": [
      {
        "title": "Cell Biology",
        "topics": [
          {
            "title": "Plant and animal cells"
          },
          {
            "title": "Organelles"
          },
          {
            "title": "Cell theory"
          }
        ]
      },
      {
        "title": "Genetics",
        "topics": [
          {
            "title": "Mendelian genetics basics"
          },
          {
            "title": "Chromosomes"
          },
          {
            "title": "Variation"
          }
        ]
      },
      {
        "title": "Ecology",
        "topics": [
          {
            "title": "Ecosystems"
          },
          {
            "title": "Food chains and webs"
          },
          {
            "title": "Adaptation"
          }
        ]
      },
      {
        "title": "Physiology",
        "topics": [
          {
            "title": "Nutrition"
          },
          {
            "title": "Respiration"
          },
          {
            "title": "Transport systems"
          },
          {
            "title": "Excretion"
          }
        ]
      },
      {
        "title": "Reproduction",
        "topics": [
          {
            "title": "Asexual reproduction"
          },
          {
            "title": "Sexual reproduction in plants and animals"
          }
        ]
      }
    ]
  },
  {
    "id": "bio-sss3",
    "title": "Biology",
    "track": "secondary",
    "level": "SSS 3",
    "subject": "Biology",
    "category": "Science",
    "units": [
      {
        "title": "Cell Biology",
        "topics": [
          {
            "title": "Plant and animal cells"
          },
          {
            "title": "Organelles"
          },
          {
            "title": "Cell theory"
          }
        ]
      },
      {
        "title": "Genetics",
        "topics": [
          {
            "title": "Mendelian genetics basics"
          },
          {
            "title": "Chromosomes"
          },
          {
            "title": "Variation"
          }
        ]
      },
      {
        "title": "Ecology",
        "topics": [
          {
            "title": "Ecosystems"
          },
          {
            "title": "Food chains and webs"
          },
          {
            "title": "Adaptation"
          }
        ]
      },
      {
        "title": "Physiology",
        "topics": [
          {
            "title": "Nutrition"
          },
          {
            "title": "Respiration"
          },
          {
            "title": "Transport systems"
          },
          {
            "title": "Excretion"
          }
        ]
      },
      {
        "title": "Reproduction",
        "topics": [
          {
            "title": "Asexual reproduction"
          },
          {
            "title": "Sexual reproduction in plants and animals"
          }
        ]
      }
    ]
  },
  {
    "id": "gov-sss",
    "title": "Government",
    "track": "secondary",
    "level": "SSS 1\u20133",
    "subject": "Government",
    "category": "Humanities",
    "units": [
      {
        "title": "Basic Concepts of Government",
        "topics": [
          {
            "title": "Power, authority, legitimacy"
          },
          {
            "title": "Sovereignty"
          },
          {
            "title": "Democracy and other systems"
          }
        ]
      },
      {
        "title": "Organs of Government",
        "topics": [
          {
            "title": "Executive"
          },
          {
            "title": "Legislature"
          },
          {
            "title": "Judiciary"
          },
          {
            "title": "Separation of powers"
          }
        ]
      },
      {
        "title": "Nigerian Constitutional Development",
        "topics": [
          {
            "title": "Colonial administration overview"
          },
          {
            "title": "Independence and republican constitutions"
          },
          {
            "title": "Key constitutional features"
          }
        ]
      },
      {
        "title": "Citizenship and Rights",
        "topics": [
          {
            "title": "Citizenship"
          },
          {
            "title": "Fundamental rights"
          },
          {
            "title": "Duties of citizens"
          }
        ]
      },
      {
        "title": "Electoral Process",
        "topics": [
          {
            "title": "Electoral systems"
          },
          {
            "title": "Political parties"
          },
          {
            "title": "Electoral commission orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "eco-sss",
    "title": "Economics",
    "track": "secondary",
    "level": "SSS 1\u20133",
    "subject": "Economics",
    "category": "Business",
    "units": [
      {
        "title": "Basic Economic Concepts",
        "topics": [
          {
            "title": "Scarcity and choice"
          },
          {
            "title": "Opportunity cost"
          },
          {
            "title": "Factors of production"
          }
        ]
      },
      {
        "title": "Demand and Supply",
        "topics": [
          {
            "title": "Law of demand"
          },
          {
            "title": "Law of supply"
          },
          {
            "title": "Equilibrium price"
          }
        ]
      },
      {
        "title": "Production",
        "topics": [
          {
            "title": "Types of production"
          },
          {
            "title": "Division of labour"
          },
          {
            "title": "Scale of production"
          }
        ]
      },
      {
        "title": "Money and Finance",
        "topics": [
          {
            "title": "Functions of money"
          },
          {
            "title": "Banks"
          },
          {
            "title": "Inflation overview"
          }
        ]
      },
      {
        "title": "National Income & Development",
        "topics": [
          {
            "title": "Basic national income ideas"
          },
          {
            "title": "Economic growth vs development"
          },
          {
            "title": "Nigeria economic issues orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "lit-sss",
    "title": "Literature in English",
    "track": "secondary",
    "level": "SSS 1\u20133",
    "subject": "Literature in English",
    "category": "Humanities",
    "units": [
      {
        "title": "Literary Appreciation",
        "topics": [
          {
            "title": "Prose, drama, poetry"
          },
          {
            "title": "Figures of speech"
          },
          {
            "title": "Themes and characterisation"
          }
        ]
      },
      {
        "title": "Drama",
        "topics": [
          {
            "title": "Elements of drama"
          },
          {
            "title": "Reading and analysing plays"
          }
        ]
      },
      {
        "title": "Prose",
        "topics": [
          {
            "title": "Elements of the novel/short story"
          },
          {
            "title": "Plot and narrative techniques"
          }
        ]
      },
      {
        "title": "Poetry",
        "topics": [
          {
            "title": "Poetic devices"
          },
          {
            "title": "Appreciation of selected poems"
          }
        ]
      }
    ]
  },
  {
    "id": "acc-sss",
    "title": "Accounting",
    "track": "secondary",
    "level": "SSS 1\u20133",
    "subject": "Accounting",
    "category": "Business",
    "units": [
      {
        "title": "Introduction to Bookkeeping",
        "topics": [
          {
            "title": "Purpose of bookkeeping"
          },
          {
            "title": "Source documents"
          },
          {
            "title": "Books of original entry"
          }
        ]
      },
      {
        "title": "Ledger and Trial Balance",
        "topics": [
          {
            "title": "Double entry"
          },
          {
            "title": "Ledger accounts"
          },
          {
            "title": "Trial balance"
          }
        ]
      },
      {
        "title": "Final Accounts",
        "topics": [
          {
            "title": "Trading account"
          },
          {
            "title": "Profit and loss"
          },
          {
            "title": "Balance sheet orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "jss-math",
    "title": "Mathematics",
    "track": "secondary",
    "level": "JSS 1\u20133",
    "subject": "Mathematics",
    "category": "Core",
    "units": [
      {
        "title": "Numbers",
        "topics": [
          {
            "title": "Whole numbers"
          },
          {
            "title": "Fractions"
          },
          {
            "title": "Decimals"
          },
          {
            "title": "Percentages"
          }
        ]
      },
      {
        "title": "Basic Algebra",
        "topics": [
          {
            "title": "Symbols and expressions"
          },
          {
            "title": "Simple equations"
          }
        ]
      },
      {
        "title": "Geometry & Mensuration",
        "topics": [
          {
            "title": "Plane shapes"
          },
          {
            "title": "Perimeter and area"
          },
          {
            "title": "Basic solids"
          }
        ]
      },
      {
        "title": "Statistics",
        "topics": [
          {
            "title": "Collection of data"
          },
          {
            "title": "Pictograms and bar charts"
          },
          {
            "title": "Averages"
          }
        ]
      }
    ]
  },
  {
    "id": "jss-eng",
    "title": "English Studies",
    "track": "secondary",
    "level": "JSS 1\u20133",
    "subject": "English Studies",
    "category": "Core",
    "units": [
      {
        "title": "Reading and Comprehension",
        "topics": [
          {
            "title": "Main ideas"
          },
          {
            "title": "Vocabulary development"
          }
        ]
      },
      {
        "title": "Writing",
        "topics": [
          {
            "title": "Paragraph writing"
          },
          {
            "title": "Informal and formal letters"
          },
          {
            "title": "Narrative writing"
          }
        ]
      },
      {
        "title": "Grammar",
        "topics": [
          {
            "title": "Parts of speech"
          },
          {
            "title": "Tenses"
          },
          {
            "title": "Punctuation"
          }
        ]
      },
      {
        "title": "Literature in English (JSS)",
        "topics": [
          {
            "title": "Folktales"
          },
          {
            "title": "Simple poetry"
          },
          {
            "title": "Drama exposure"
          }
        ]
      }
    ]
  },
  {
    "id": "trade-solar",
    "title": "Solar PV Installation & Maintenance",
    "track": "secondary",
    "level": "SSS Trade",
    "subject": "Trade",
    "category": "Trade",
    "units": [
      {
        "title": "Solar Energy Basics",
        "topics": [
          {
            "title": "Solar radiation"
          },
          {
            "title": "PV principle"
          },
          {
            "title": "System components"
          }
        ]
      },
      {
        "title": "Installation Practices",
        "topics": [
          {
            "title": "Site assessment"
          },
          {
            "title": "Mounting"
          },
          {
            "title": "Wiring orientation"
          },
          {
            "title": "Safety"
          }
        ]
      },
      {
        "title": "Maintenance",
        "topics": [
          {
            "title": "Inspection"
          },
          {
            "title": "Common faults"
          },
          {
            "title": "Basic troubleshooting"
          }
        ]
      }
    ]
  },
  {
    "id": "nd-bam",
    "title": "Business Administration",
    "track": "polytechnic",
    "level": "ND",
    "subject": "Business Administration",
    "category": "Business",
    "units": [
      {
        "title": "Principles of Management",
        "topics": [
          {
            "title": "Planning"
          },
          {
            "title": "Organising"
          },
          {
            "title": "Leading"
          },
          {
            "title": "Controlling"
          },
          {
            "title": "Levels of management"
          }
        ]
      },
      {
        "title": "Business Law Orientation",
        "topics": [
          {
            "title": "Contracts basics"
          },
          {
            "title": "Agency"
          },
          {
            "title": "Business organisations"
          }
        ]
      },
      {
        "title": "Marketing Fundamentals",
        "topics": [
          {
            "title": "Marketing mix"
          },
          {
            "title": "Consumer behaviour orientation"
          }
        ]
      },
      {
        "title": "Business Communication",
        "topics": [
          {
            "title": "Official correspondence"
          },
          {
            "title": "Meetings and reports"
          }
        ]
      }
    ]
  },
  {
    "id": "nd-csc",
    "title": "Computer Science",
    "track": "polytechnic",
    "level": "ND",
    "subject": "Computer Science",
    "category": "Science",
    "units": [
      {
        "title": "Computer Fundamentals",
        "topics": [
          {
            "title": "Hardware and software"
          },
          {
            "title": "Number systems"
          },
          {
            "title": "Data representation"
          }
        ]
      },
      {
        "title": "Programming Fundamentals",
        "topics": [
          {
            "title": "Algorithms"
          },
          {
            "title": "Flowcharts"
          },
          {
            "title": "Variables and control structures"
          },
          {
            "title": "Functions"
          }
        ]
      },
      {
        "title": "Databases",
        "topics": [
          {
            "title": "Introduction to DBMS"
          },
          {
            "title": "Tables and keys"
          },
          {
            "title": "Basic SQL orientation"
          }
        ]
      },
      {
        "title": "Networking Basics",
        "topics": [
          {
            "title": "LAN/WAN"
          },
          {
            "title": "Internet basics"
          },
          {
            "title": "Network devices orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "hnd-csc",
    "title": "Computer Science",
    "track": "polytechnic",
    "level": "HND",
    "subject": "Computer Science",
    "category": "Science",
    "units": [
      {
        "title": "Advanced Programming Concepts",
        "topics": [
          {
            "title": "Modular design"
          },
          {
            "title": "Data structures orientation"
          },
          {
            "title": "File handling concepts"
          }
        ]
      },
      {
        "title": "Software Engineering Basics",
        "topics": [
          {
            "title": "SDLC"
          },
          {
            "title": "Requirements"
          },
          {
            "title": "Testing orientation"
          }
        ]
      },
      {
        "title": "Systems Analysis",
        "topics": [
          {
            "title": "Feasibility"
          },
          {
            "title": "DFD orientation"
          },
          {
            "title": "Documentation"
          }
        ]
      }
    ]
  },
  {
    "id": "gst-english",
    "title": "Use of English (GST)",
    "track": "university",
    "level": "100L",
    "subject": "GST",
    "category": "General Studies",
    "units": [
      {
        "title": "Reading and Comprehension",
        "topics": [
          {
            "title": "Academic texts"
          },
          {
            "title": "Note-making"
          }
        ]
      },
      {
        "title": "Summary and Paraphrase",
        "topics": [
          {
            "title": "Summary skills"
          },
          {
            "title": "Avoiding plagiarism orientation"
          }
        ]
      },
      {
        "title": "Academic Writing",
        "topics": [
          {
            "title": "Paragraph unity"
          },
          {
            "title": "Essay structure"
          },
          {
            "title": "Formal register"
          }
        ]
      },
      {
        "title": "Grammar for Academic Use",
        "topics": [
          {
            "title": "Concord"
          },
          {
            "title": "Effective sentences"
          },
          {
            "title": "Punctuation"
          }
        ]
      }
    ]
  },
  {
    "id": "csc101",
    "title": "Introduction to Computer Science",
    "track": "university",
    "level": "100L",
    "subject": "Computer Science",
    "category": "Computing",
    "units": [
      {
        "title": "Computing Overview",
        "topics": [
          {
            "title": "History of computing"
          },
          {
            "title": "Hardware vs software"
          },
          {
            "title": "IPO model"
          }
        ]
      },
      {
        "title": "Problem Solving",
        "topics": [
          {
            "title": "Algorithms"
          },
          {
            "title": "Flowcharts"
          },
          {
            "title": "Pseudocode"
          }
        ]
      },
      {
        "title": "Computer Systems",
        "topics": [
          {
            "title": "CPU and memory"
          },
          {
            "title": "Storage"
          },
          {
            "title": "Input/output"
          }
        ]
      },
      {
        "title": "Applications & Society",
        "topics": [
          {
            "title": "Application software"
          },
          {
            "title": "ICT and society"
          },
          {
            "title": "Ethics orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "eco101",
    "title": "Principles of Economics",
    "track": "university",
    "level": "100L\u2013200L",
    "subject": "Economics",
    "category": "Social Sciences",
    "units": [
      {
        "title": "Introduction to Economics",
        "topics": [
          {
            "title": "Scarcity"
          },
          {
            "title": "Choice"
          },
          {
            "title": "Opportunity cost"
          }
        ]
      },
      {
        "title": "Microeconomics Basics",
        "topics": [
          {
            "title": "Demand"
          },
          {
            "title": "Supply"
          },
          {
            "title": "Elasticity orientation"
          },
          {
            "title": "Market structures overview"
          }
        ]
      },
      {
        "title": "Macroeconomics Basics",
        "topics": [
          {
            "title": "National income concepts"
          },
          {
            "title": "Inflation"
          },
          {
            "title": "Unemployment orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "law-llb",
    "title": "Law (LL.B Companion)",
    "track": "university",
    "level": "LL.B",
    "subject": "Law",
    "category": "Law",
    "units": [
      {
        "title": "Introduction to Law",
        "topics": [
          {
            "title": "Meaning and sources of law"
          },
          {
            "title": "Classifications of law"
          }
        ]
      },
      {
        "title": "Constitutional Law Orientation",
        "topics": [
          {
            "title": "Supremacy of the constitution"
          },
          {
            "title": "Separation of powers"
          },
          {
            "title": "Fundamental rights"
          }
        ]
      },
      {
        "title": "Legal Method",
        "topics": [
          {
            "title": "Case reading orientation"
          },
          {
            "title": "Legal reasoning basics"
          }
        ]
      }
    ]
  },
  {
    "id": "pg-research",
    "title": "Research Methods",
    "track": "postgraduate",
    "level": "MSc/PhD",
    "subject": "Research Methods",
    "category": "Core",
    "units": [
      {
        "title": "Research Foundations",
        "topics": [
          {
            "title": "Research questions and objectives"
          },
          {
            "title": "Hypotheses"
          },
          {
            "title": "Research philosophy orientation"
          }
        ]
      },
      {
        "title": "Literature Review",
        "topics": [
          {
            "title": "Searching literature"
          },
          {
            "title": "Synthesising sources"
          },
          {
            "title": "Avoiding plagiarism"
          }
        ]
      },
      {
        "title": "Research Design",
        "topics": [
          {
            "title": "Qualitative designs"
          },
          {
            "title": "Quantitative designs"
          },
          {
            "title": "Mixed methods overview"
          }
        ]
      },
      {
        "title": "Data & Ethics",
        "topics": [
          {
            "title": "Sampling orientation"
          },
          {
            "title": "Data collection tools"
          },
          {
            "title": "Research ethics and integrity"
          }
        ]
      },
      {
        "title": "Thesis & Publication",
        "topics": [
          {
            "title": "Thesis structure"
          },
          {
            "title": "Proposal writing"
          },
          {
            "title": "Academic publication basics"
          }
        ]
      }
    ]
  },
  {
    "id": "pg-writing",
    "title": "Academic Writing for Postgraduates",
    "track": "postgraduate",
    "level": "MSc/PhD",
    "subject": "Academic Writing",
    "category": "Core",
    "units": [
      {
        "title": "Style and Voice",
        "topics": [
          {
            "title": "Formal academic style"
          },
          {
            "title": "Clarity and precision"
          }
        ]
      },
      {
        "title": "Structure",
        "topics": [
          {
            "title": "Abstracts"
          },
          {
            "title": "Chapters"
          },
          {
            "title": "Coherence and cohesion"
          }
        ]
      },
      {
        "title": "Citation",
        "topics": [
          {
            "title": "Referencing systems orientation"
          },
          {
            "title": "Paraphrasing vs quoting"
          }
        ]
      }
    ]
  },
  {
    "id": "exam-jamb",
    "title": "JAMB UTME Companion",
    "track": "secondary",
    "level": "Exam",
    "subject": "JAMB",
    "category": "Exams",
    "units": [
      {
        "title": "Use of English",
        "topics": [
          {
            "title": "Comprehension strategies"
          },
          {
            "title": "Lexis and structure"
          },
          {
            "title": "Oral forms orientation"
          }
        ]
      },
      {
        "title": "Sciences Combo Practice",
        "topics": [
          {
            "title": "Physics high-yield topics"
          },
          {
            "title": "Chemistry high-yield topics"
          },
          {
            "title": "Biology high-yield topics"
          }
        ]
      },
      {
        "title": "Arts / Social Sciences Combo",
        "topics": [
          {
            "title": "Government"
          },
          {
            "title": "Economics"
          },
          {
            "title": "Literature orientation"
          }
        ]
      },
      {
        "title": "Exam Strategy",
        "topics": [
          {
            "title": "Time management"
          },
          {
            "title": "Question interpretation"
          },
          {
            "title": "Common pitfalls"
          }
        ]
      }
    ]
  },
  {
    "id": "exam-waec",
    "title": "WAEC WASSCE Companion",
    "track": "secondary",
    "level": "Exam",
    "subject": "WAEC",
    "category": "Exams",
    "units": [
      {
        "title": "Core Subjects Strategy",
        "topics": [
          {
            "title": "English Language papers"
          },
          {
            "title": "General Mathematics papers"
          }
        ]
      },
      {
        "title": "Science Papers",
        "topics": [
          {
            "title": "Physics"
          },
          {
            "title": "Chemistry"
          },
          {
            "title": "Biology practical orientation"
          }
        ]
      },
      {
        "title": "Revision Planning",
        "topics": [
          {
            "title": "Syllabus checklist method"
          },
          {
            "title": "Timed practice"
          }
        ]
      }
    ]
  },
  {
    "id": "crs-sss",
    "title": "Christian Religious Studies",
    "track": "secondary",
    "level": "SSS 1\u20133",
    "subject": "CRS",
    "category": "Humanities",
    "units": [
      {
        "title": "Old Testament Themes",
        "topics": [
          {
            "title": "Selected narratives"
          },
          {
            "title": "Leadership and covenant themes"
          }
        ]
      },
      {
        "title": "New Testament Themes",
        "topics": [
          {
            "title": "Gospels orientation"
          },
          {
            "title": "Early church themes"
          }
        ]
      },
      {
        "title": "Christian Living",
        "topics": [
          {
            "title": "Faith and conduct"
          },
          {
            "title": "Society and morality orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "irs-sss",
    "title": "Islamic Studies",
    "track": "secondary",
    "level": "SSS 1\u20133",
    "subject": "Islamic Studies",
    "category": "Humanities",
    "units": [
      {
        "title": "Qur'anic Studies Orientation",
        "topics": [
          {
            "title": "Selected passages appreciation"
          },
          {
            "title": "Themes of guidance"
          }
        ]
      },
      {
        "title": "Hadith and Sunnah Orientation",
        "topics": [
          {
            "title": "Importance of Hadith"
          },
          {
            "title": "Selected themes"
          }
        ]
      },
      {
        "title": "Islamic History & Society",
        "topics": [
          {
            "title": "Early Islamic history overview"
          },
          {
            "title": "Ethics and society"
          }
        ]
      }
    ]
  },
  {
    "id": "further-math",
    "title": "Further Mathematics",
    "track": "secondary",
    "level": "SSS 2\u20133",
    "subject": "Further Mathematics",
    "category": "Science",
    "units": [
      {
        "title": "Pure Maths Topics",
        "topics": [
          {
            "title": "Polynomials"
          },
          {
            "title": "Coordinate geometry orientation"
          },
          {
            "title": "Calculus intro orientation"
          }
        ]
      },
      {
        "title": "Mechanics Orientation",
        "topics": [
          {
            "title": "Vectors"
          },
          {
            "title": "Motion under constant acceleration"
          }
        ]
      },
      {
        "title": "Statistics Orientation",
        "topics": [
          {
            "title": "Probability distributions intro"
          },
          {
            "title": "Correlation orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-research",
    "title": "Research Methods (MSc)",
    "track": "postgraduate",
    "level": "MSc",
    "subject": "Research Methods",
    "category": "Core",
    "units": [
      {
        "title": "Research Foundations",
        "topics": [
          {
            "title": "Research questions and objectives"
          },
          {
            "title": "Hypotheses and propositions"
          },
          {
            "title": "Ontology and epistemology orientation"
          },
          {
            "title": "Positioning a study in the literature"
          }
        ]
      },
      {
        "title": "Literature Review",
        "topics": [
          {
            "title": "Search strategy"
          },
          {
            "title": "Critical synthesis"
          },
          {
            "title": "Theoretical frameworks"
          },
          {
            "title": "Identifying the gap"
          }
        ]
      },
      {
        "title": "Research Design",
        "topics": [
          {
            "title": "Quantitative designs"
          },
          {
            "title": "Qualitative designs"
          },
          {
            "title": "Mixed methods overview"
          },
          {
            "title": "Validity and reliability orientation"
          }
        ]
      },
      {
        "title": "Data Collection & Analysis",
        "topics": [
          {
            "title": "Sampling strategies"
          },
          {
            "title": "Surveys and interviews"
          },
          {
            "title": "Basic statistical reasoning"
          },
          {
            "title": "Qualitative coding orientation"
          }
        ]
      },
      {
        "title": "Ethics & Integrity",
        "topics": [
          {
            "title": "Informed consent"
          },
          {
            "title": "Plagiarism and originality"
          },
          {
            "title": "Data protection basics"
          }
        ]
      },
      {
        "title": "Dissertation Writing",
        "topics": [
          {
            "title": "Chapter architecture"
          },
          {
            "title": "Argumentation"
          },
          {
            "title": "Referencing excellence"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-mba",
    "title": "Master of Business Administration (MBA Companion)",
    "track": "postgraduate",
    "level": "MSc/MBA",
    "subject": "Business Administration",
    "category": "Business",
    "units": [
      {
        "title": "Strategic Management",
        "topics": [
          {
            "title": "Strategy process"
          },
          {
            "title": "Competitive analysis"
          },
          {
            "title": "Corporate strategy"
          }
        ]
      },
      {
        "title": "Organisational Behaviour",
        "topics": [
          {
            "title": "Motivation"
          },
          {
            "title": "Leadership"
          },
          {
            "title": "Culture and change"
          }
        ]
      },
      {
        "title": "Marketing Management",
        "topics": [
          {
            "title": "Marketing strategy"
          },
          {
            "title": "Consumer insights"
          },
          {
            "title": "Brand management orientation"
          }
        ]
      },
      {
        "title": "Financial Decision Making",
        "topics": [
          {
            "title": "Financial statements orientation"
          },
          {
            "title": "Investment appraisal ideas"
          },
          {
            "title": "Risk and return"
          }
        ]
      },
      {
        "title": "Operations & Project Management",
        "topics": [
          {
            "title": "Process improvement"
          },
          {
            "title": "Project lifecycle"
          },
          {
            "title": "Quality orientation"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-csc",
    "title": "MSc Computer Science Companion",
    "track": "postgraduate",
    "level": "MSc",
    "subject": "Computer Science",
    "category": "Computing",
    "units": [
      {
        "title": "Advanced Algorithms Orientation",
        "topics": [
          {
            "title": "Complexity thinking"
          },
          {
            "title": "Core algorithm families"
          },
          {
            "title": "Research problems in computing"
          }
        ]
      },
      {
        "title": "Machine Learning Foundations",
        "topics": [
          {
            "title": "Supervised vs unsupervised"
          },
          {
            "title": "Model evaluation ideas"
          },
          {
            "title": "Ethics of automated systems"
          }
        ]
      },
      {
        "title": "Distributed Systems Orientation",
        "topics": [
          {
            "title": "Concurrency challenges"
          },
          {
            "title": "Consistency ideas"
          },
          {
            "title": "Cloud architectures overview"
          }
        ]
      },
      {
        "title": "Research in Computing",
        "topics": [
          {
            "title": "Reading papers"
          },
          {
            "title": "Reproducibility"
          },
          {
            "title": "Experiment design for systems"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-edu",
    "title": "MSc Education Companion",
    "track": "postgraduate",
    "level": "MSc",
    "subject": "Education",
    "category": "Education",
    "units": [
      {
        "title": "Learning Theories",
        "topics": [
          {
            "title": "Behaviourism to constructivism"
          },
          {
            "title": "Motivation in learning"
          },
          {
            "title": "Inclusive pedagogy orientation"
          }
        ]
      },
      {
        "title": "Curriculum Studies",
        "topics": [
          {
            "title": "Curriculum models"
          },
          {
            "title": "Assessment for learning"
          },
          {
            "title": "Policy and practice"
          }
        ]
      },
      {
        "title": "Educational Research",
        "topics": [
          {
            "title": "Classroom inquiry"
          },
          {
            "title": "Mixed methods in education"
          },
          {
            "title": "Ethics with learners"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-ph",
    "title": "MSc Public Health Companion",
    "track": "postgraduate",
    "level": "MSc",
    "subject": "Public Health",
    "category": "Health",
    "units": [
      {
        "title": "Epidemiology Basics",
        "topics": [
          {
            "title": "Measures of frequency"
          },
          {
            "title": "Study designs overview"
          },
          {
            "title": "Bias and confounding orientation"
          }
        ]
      },
      {
        "title": "Health Systems",
        "topics": [
          {
            "title": "Primary health care"
          },
          {
            "title": "Health policy orientation"
          },
          {
            "title": "Determinants of health"
          }
        ]
      },
      {
        "title": "Health Promotion",
        "topics": [
          {
            "title": "Behaviour change models"
          },
          {
            "title": "Community interventions"
          },
          {
            "title": "Evaluation ideas"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-eng",
    "title": "MSc Engineering Companion",
    "track": "postgraduate",
    "level": "MSc",
    "subject": "Engineering",
    "category": "Engineering",
    "units": [
      {
        "title": "Engineering Research Methods",
        "topics": [
          {
            "title": "Problem definition"
          },
          {
            "title": "Modelling and simulation orientation"
          },
          {
            "title": "Experimental design"
          }
        ]
      },
      {
        "title": "Project & Risk Management",
        "topics": [
          {
            "title": "Engineering project phases"
          },
          {
            "title": "Risk identification"
          },
          {
            "title": "Standards and safety culture"
          }
        ]
      },
      {
        "title": "Technical Communication",
        "topics": [
          {
            "title": "Design reports"
          },
          {
            "title": "Literature in engineering"
          },
          {
            "title": "Presentation of results"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-law",
    "title": "LLM / MSc Law Companion",
    "track": "postgraduate",
    "level": "LLM/MSc",
    "subject": "Law",
    "category": "Law",
    "units": [
      {
        "title": "Advanced Legal Research",
        "topics": [
          {
            "title": "Case analysis depth"
          },
          {
            "title": "Statutory interpretation orientation"
          },
          {
            "title": "Comparative method"
          }
        ]
      },
      {
        "title": "Dissertation in Law",
        "topics": [
          {
            "title": "Doctrinal vs socio-legal"
          },
          {
            "title": "Structuring legal arguments"
          },
          {
            "title": "Citation discipline"
          }
        ]
      }
    ]
  },
  {
    "id": "msc-econ",
    "title": "MSc Economics Companion",
    "track": "postgraduate",
    "level": "MSc",
    "subject": "Economics",
    "category": "Social Sciences",
    "units": [
      {
        "title": "Applied Microeconomics Orientation",
        "topics": [
          {
            "title": "Consumer and firm theory refresh"
          },
          {
            "title": "Market structures"
          },
          {
            "title": "Welfare ideas"
          }
        ]
      },
      {
        "title": "Applied Macro & Policy",
        "topics": [
          {
            "title": "Growth debates"
          },
          {
            "title": "Inflation and unemployment"
          },
          {
            "title": "Policy evaluation orientation"
          }
        ]
      },
      {
        "title": "Econometrics Orientation",
        "topics": [
          {
            "title": "Regression thinking"
          },
          {
            "title": "Causality challenges"
          },
          {
            "title": "Reading empirical papers"
          }
        ]
      }
    ]
  },
  {
    "id": "phd-thesis",
    "title": "Doctoral Studies & Thesis",
    "track": "postgraduate",
    "level": "PhD",
    "subject": "Doctoral Research",
    "category": "Core",
    "units": [
      {
        "title": "Doctoral Research",
        "topics": [
          {
            "title": "Contribution to knowledge"
          },
          {
            "title": "Originality and significance"
          },
          {
            "title": "Thesis structure"
          },
          {
            "title": "The viva voce orientation"
          }
        ]
      },
      {
        "title": "Literature at Doctoral Level",
        "topics": [
          {
            "title": "Field mapping"
          },
          {
            "title": "Theoretical contribution"
          },
          {
            "title": "Critical voice"
          }
        ]
      },
      {
        "title": "Methodology at Scale",
        "topics": [
          {
            "title": "Design justification"
          },
          {
            "title": "Limitations and delimitations"
          },
          {
            "title": "Ethics boards and integrity"
          }
        ]
      },
      {
        "title": "Publication & Career",
        "topics": [
          {
            "title": "Publishing from the thesis"
          },
          {
            "title": "Conference strategy"
          },
          {
            "title": "Academic identity"
          }
        ]
      }
    ]
  },
  {
    "id": "phd-stem",
    "title": "PhD STEM Research Companion",
    "track": "postgraduate",
    "level": "PhD",
    "subject": "STEM Research",
    "category": "Science",
    "units": [
      {
        "title": "Scientific Contribution",
        "topics": [
          {
            "title": "Hypothesis-driven vs design science"
          },
          {
            "title": "Replication and open science"
          },
          {
            "title": "Lab and field constraints"
          }
        ]
      },
      {
        "title": "Technical Depth",
        "topics": [
          {
            "title": "Methods transparency"
          },
          {
            "title": "Data management plans"
          },
          {
            "title": "Negative results"
          }
        ]
      }
    ]
  },
  {
    "id": "phd-ssh",
    "title": "PhD Social Sciences & Humanities",
    "track": "postgraduate",
    "level": "PhD",
    "subject": "SSH Research",
    "category": "Humanities",
    "units": [
      {
        "title": "Theoretical Contribution",
        "topics": [
          {
            "title": "Concept building"
          },
          {
            "title": "Critical traditions"
          },
          {
            "title": "Positionality"
          }
        ]
      },
      {
        "title": "Qualitative & Archival Depth",
        "topics": [
          {
            "title": "Field access"
          },
          {
            "title": "Interpretation"
          },
          {
            "title": "Writing as argument"
          }
        ]
      }
    ]
  },
  {
    "id": "phd-prof",
    "title": "Professional Doctorates Orientation",
    "track": "postgraduate",
    "level": "ProfDoc/DBA/EdD",
    "subject": "Professional Doctorate",
    "category": "Professional",
    "units": [
      {
        "title": "Practice-Based Contribution",
        "topics": [
          {
            "title": "Workplace problems as research"
          },
          {
            "title": "Stakeholder engagement"
          },
          {
            "title": "Impact narrative"
          }
        ]
      },
      {
        "title": "Portfolio & Thesis Routes",
        "topics": [
          {
            "title": "Evidence of practice"
          },
          {
            "title": "Reflective analysis"
          },
          {
            "title": "Assessing impact"
          }
        ]
      }
    ]
  }
];


function getCourse(id) {
  return (window.CURRICULUM || []).find(c => c.id === id) || null;
}
function allCourses() { return window.CURRICULUM || []; }
function countTopics(course) {
  return (course.units || []).reduce((n, u) => n + (u.topics || []).length, 0);
}
function topicKey(courseId, unitTitle, topicTitle) {
  return courseId + '|' + unitTitle + '|' + topicTitle;
}
