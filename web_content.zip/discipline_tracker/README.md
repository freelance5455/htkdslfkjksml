# Discipline OS — Android habit tracker

Dark, modern, grid-first habit tracker inspired by the reference screenshot.

## Features
- Bilingual interface: English / Persian (RTL and LTR layouts).
- 22 starter habits, with custom add/edit/delete, icon/emoji and category.
- Monthly grid with per-day check-ins, month/year navigation and date range settings.
- Daily completion chart, habit performance bars, monthly completion, streak and today's score.
- Accent color selection (mint, blue, violet, amber).
- Local on-device storage; JSON export/import backup; no account required.

## Build APK with GitHub Actions
This environment does not have the Android SDK or Gradle installed, so it cannot compile an APK directly here. The project includes a GitHub Actions workflow that builds the debug APK automatically.

1. Create a new repository on GitHub.
2. Upload the contents of this folder to the repository's `main` branch (not the enclosing folder itself).
3. Open **Actions** and select **Build Android APK**. Press **Run workflow** (or push a commit).
4. When the run finishes, open it and download the `discipline-os-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

You can also open this project in Android Studio and run `assembleDebug`.
