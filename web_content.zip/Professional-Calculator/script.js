(() => {
  const display = document.getElementById('display');
  const buttons = document.querySelectorAll('.buttons button');
  let expression = '';
  let justEvaluated = false;

  function render() { display.value = expression || '0'; }
  function calculate() {
    const normalized = expression.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
    if (!normalized || !/^[0-9+\-*/%.() ]+$/.test(normalized)) return;
    try {
      const result = Function('"use strict"; return (' + normalized + ')')();
      if (!Number.isFinite(result)) throw new Error('Invalid');
      expression = String(Number.parseFloat(result.toPrecision(12)));
      justEvaluated = true;
    } catch {
      display.value = 'Error';
      expression = '';
      justEvaluated = false;
      return;
    }
    render();
  }

  buttons.forEach(button => button.addEventListener('click', () => {
    const value = button.textContent.trim();
    if (value === 'AC') {
      expression = '';
      justEvaluated = false;
    } else if (value === 'DEL') {
      expression = expression.slice(0, -1);
      justEvaluated = false;
    } else if (value === '=') {
      calculate();
      return;
    } else {
      if (justEvaluated && /[0-9.]/.test(value)) expression = '';
      justEvaluated = false;
      if (value === '.') {
        const current = expression.split(/[+\-×÷%]/).pop();
        if (current.includes('.')) return;
      }
      expression += value;
    }
    render();
  }));
  render();
})();