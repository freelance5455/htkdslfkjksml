# Professional Calculator

## Acode-এ চালানোর নিয়ম
1. ZIP ফাইলটি Extract করুন।
2. `Professional-Calculator` ফোল্ডারটি Acode-এ Open Folder দিয়ে খুলুন।
3. `index.html` ফাইলটি Preview/Browser-এ চালান।

## Android APK
এই ZIP-এ HTML/CSS/JavaScript ওয়েব অ্যাপের ফাইল আছে; এটি নিজে APK নয়।
APK বানাতে Android WebView wrapper বা কোনো বিশ্বস্ত HTML-to-APK builder ব্যবহার করতে হবে।
