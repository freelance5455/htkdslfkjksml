Daily Budget APK source bundle

මෙම ZIP එක HTML-to-APK builder එකකට upload කිරීමට සකස් කර ඇත.
App name: Daily Budget
Entry file: index.html

මෙය APK ගොනුව නොවේ. APK එකක් ලබාගැනීමට HTML-to-APK builder වෙත ZIP එක upload කර build කරන්න.
දත්ත local browser/WebView storage තුළ තබාගනී. APK එකේ storage support/backup පරීක්ෂා කරන්න.
