CryptoPulse V101.5 - History Time Fix
The LBank 1-minute history request now uses the current Unix timestamp as the kline `time` reference/end time, rather than a timestamp 2000 minutes in the past. This fixes the chart showing only a few candles while live price continues to work. Live data remains LBank-only; no Binance/demo candle data was added.
