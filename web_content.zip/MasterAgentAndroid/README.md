# Master & Agent Android WebView Project

This is an Android Studio project wrapping the supplied safe offline HTML prototypes.

## Open and build
1. Install Android Studio with Android SDK 35 and a compatible JDK (17 recommended).
2. Open this `MasterAgentAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Run on an Android device/emulator, or use **Build > Build APK(s)**.

## Included
- `master.html`: Master workspace prototype
- `agent.html`: Agent workspace prototype
- `Calendar.xlsx`: original workbook copied into app assets
- `index.html`: in-app page selector

## Limitations and safety
- Offline-only; there is no live Master/Agent sync or remote database.
- Login passwords in the HTML prototype are demonstration-only and are not secure server authentication.
- Data is stored in WebView local storage. Export JSON backups before clearing app data or uninstalling.
- No betting intake, blocked-number controls, payout odds, or betting profit/loss features are included.
- Calendar values are embedded in the HTML prototype from the supplied workbook; the XLSX asset is preserved as a separate file. Updating the workbook does not automatically update the embedded calendar values.

This project is a source project, not a prebuilt APK. Android Studio is required to compile it.
