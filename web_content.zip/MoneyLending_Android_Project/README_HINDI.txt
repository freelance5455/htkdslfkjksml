Money Lending Advance Management System — Android Studio Project

महत्वपूर्ण:
1. यह Android Studio SOURCE PROJECT है, तैयार APK नहीं। इसे Android Studio में खोलकर Build > Build APK(s) करें।
2. HTML के अंदर “Send Full APK + Data Backup” बटन अब Android native bridge को कॉल करता है। तैयार APK इंस्टॉल होने पर यह इंस्टॉल की गई APK फाइल और ग्राहक/लोन डेटा की JSON बैकअप फाइल शेयर शीट में साथ भेजने का प्रयास करेगा।
3. HTML फाइल को अकेले ब्राउज़र/HTML-to-APK कन्वर्टर में खोलने पर यह native APK-share सुविधा काम नहीं करेगी।
4. यह प्रोजेक्ट इस वातावरण में Android SDK के साथ build/run करके सत्यापित नहीं किया गया है। वास्तविक APK बनाकर बटन को फोन पर टेस्ट करना जरूरी है।
5. APK और JSON बैकअप में ग्राहक की संवेदनशील जानकारी हो सकती है; केवल सुरक्षित व्यक्ति/स्थान पर साझा करें।
6. HTML बैकअप बटन अलग है और HTML + डेटा की फाइल बनाता है।
