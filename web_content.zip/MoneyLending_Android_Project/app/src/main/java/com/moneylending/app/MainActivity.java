package com.moneylending.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.pm.ApplicationInfo;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import android.widget.Toast;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Build;
import android.os.Environment;
import androidx.core.content.FileProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraImageUri;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int CAMERA_PERMISSION_REQUEST = 1002;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUrl(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(url);
            }
        });
        webView.addJavascriptInterface(new AndroidBackupBridge(), "AndroidBackup");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                launchFileChooser();
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }


    private class AndroidBackupBridge {
        @JavascriptInterface
        public void shareApkAndData(String jsonData) {
            runOnUiThread(() -> {
                try {
                    File dir = new File(getCacheDir(), "share_backup");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Backup folder could not be created");
                    File apkFile = new File(dir, "MoneyLending.apk");
                    File dataFile = new File(dir, "MoneyLending_DataBackup.json");
                    ApplicationInfo info = getApplicationInfo();
                    try (InputStream in = new FileInputStream(info.sourceDir); OutputStream out = new FileOutputStream(apkFile)) {
                        byte[] buffer = new byte[8192]; int count;
                        while ((count = in.read(buffer)) > 0) out.write(buffer, 0, count);
                    }
                    try (OutputStream out = new FileOutputStream(dataFile)) {
                        out.write(jsonData.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    }
                    Uri apkUri = FileProvider.getUriForFile(MainActivity.this, "com.moneylending.app.fileprovider", apkFile);
                    Uri dataUri = FileProvider.getUriForFile(MainActivity.this, "com.moneylending.app.fileprovider", dataFile);
                    Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    share.setType("*/*");
                    ArrayList<Uri> files = new ArrayList<>(); files.add(apkUri); files.add(dataUri);
                    share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files);
                    share.putExtra(Intent.EXTRA_SUBJECT, "Money Lending APK + Data Backup");
                    share.putExtra(Intent.EXTRA_TEXT, "Money Lending ऐप की APK और ग्राहक/लोन डेटा बैकअप फाइल संलग्न है। APK केवल भरोसेमंद व्यक्ति को साझा करें। डेटा बैकअप में संवेदनशील ग्राहक जानकारी हो सकती है।");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "APK + डेटा बैकअप शेयर करें"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "APK + डेटा बैकअप तैयार नहीं हुआ: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private boolean handleExternalUrl(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (url.startsWith("file:") || url.startsWith("about:") || url.startsWith("javascript:")) return false;
        if (scheme.equals("http") || scheme.equals("https")) {
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (host.contains("wa.me") || host.contains("whatsapp.com") || host.contains("api.whatsapp.com") || host.contains("mailto:") || host.contains("tel:")) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                catch (ActivityNotFoundException e) { return false; }
            }
            return false;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "इस लिंक को खोलने के लिए संबंधित ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show(); return true; }
    }

    private void launchFileChooser() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) != null) {
            try {
                File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                if (dir != null && !dir.exists()) dir.mkdirs();
                File photo = new File(dir, "security_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg");
                cameraImageUri = FileProvider.getUriForFile(this, "com.moneylending.app.fileprovider", photo);
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
                camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception e) { camera = null; cameraImageUri = null; }
        } else camera = null;
        Intent chooser = Intent.createChooser(pick, "सिक्योरिटी आइटम की फोटो चुनें या कैमरा खोलें");
        if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
        try { startActivityForResult(chooser, FILE_CHOOSER_REQUEST); }
        catch (ActivityNotFoundException e) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = null;
            Toast.makeText(this, "कैमरा/फोटो ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK) {
                if (data != null && data.getData() != null) results = new Uri[]{data.getData()};
                else if (cameraImageUri != null) results = new Uri[]{cameraImageUri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            cameraImageUri = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
