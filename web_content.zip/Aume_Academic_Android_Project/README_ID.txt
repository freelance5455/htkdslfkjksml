AUME ACADEMIC — PAKET ANDROID

Isi:
1. app/ : project Android Studio (aplikasi WebView offline; game HTML ditanam di dalam APK).
2. PWA_Installable/ : versi web installable, dengan manifest dan service worker.

CARA MEMBUAT APK:
1. Ekstrak ZIP ini di komputer/laptop.
2. Install Android Studio dari situs resmi Android Developers.
3. Buka Android Studio > Open > pilih folder Aume_Academic_Android_Project.
4. Tunggu Gradle Sync dan install Android SDK Platform 35 jika diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik "locate" untuk menemukan app-debug.apk.
7. Pindahkan APK ke Android, buka file, lalu izinkan instalasi dari sumber tersebut jika Android meminta.

Catatan:
- APK binary belum dibuat di lingkungan ini karena Android SDK/Gradle build tools tidak tersedia.
- Project ini membungkus game HTML yang sudah ada, sehingga konsep/isi game dipertahankan dan bisa berjalan offline.
- PWA_Installable bisa dipasang dari Chrome Android setelah foldernya diunggah ke hosting HTTPS. File lokal saja tidak akan menampilkan opsi Install.
