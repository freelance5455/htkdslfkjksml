(() => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const STORAGE = {
    key: "fitmind_openrouter_key_v1",
    model: "fitmind_model_v1",
    remember: "fitmind_remember_key_v1",
    messages: "fitmind_messages_v1",
    workouts: "fitmind_workouts_v1"
  };

  const SYSTEM_PROMPT = `Ты — осторожный, дружелюбный ИИ-тренер по общей физической подготовке. Отвечай на русском языке, понятно и практично.
Помогай собирать планы под цель, опыт, доступное оборудование, время и частоту тренировок. Если данных недостаточно, сначала задай до 4 коротких уточняющих вопросов.
Когда составляешь план, используй понятную структуру: цель, частота, разминка, упражнения с подходами/повторениями или временем, отдых, заминка, прогрессия и восстановление. Предпочитай реалистичный постепенный прогресс и правильную технику. Не обещай конкретные результаты.
Безопасность: не диагностируй заболевания, не назначай лечение, не советуй тренироваться через боль. Учитывай ограничения пользователя; при травмах, беременности, хронических заболеваниях или тревожных симптомах рекомендуй обсудить нагрузку с медицинским специалистом. При острой боли в груди, обмороке или выраженной одышке нужно прекратить тренировку и обратиться за срочной помощью.
Не притворяйся врачом. Не делай опасных максимальных нагрузок и не поощряй экстремальные диеты, обезвоживание или тренировки в наказание.
Если пользователь просит программу, в конце добавь строку: «Название плана: …» с коротким подходящим названием. Не используй HTML.`;

  const state = {
    messages: [],
    workouts: [],
    busy: false,
    activeWorkoutId: null
  };

  const messagesEl = $("#messages");
  const inputEl = $("#messageInput");
  const sendButton = $("#sendButton");
  const settingsDialog = $("#settingsDialog");
  const workoutDialog = $("#workoutDialog");

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch {
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      showToast("Не удалось сохранить данные. Возможно, память браузера заполнена.");
    }
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  function formatText(text) {
    // Safe, lightweight formatting: escape HTML first, then preserve line breaks.
    return escapeHTML(text).replace(/\n/g, "<br>");
  }

  function nowLabel() {
    return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date());
  }

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
  }

  function setStatus(connected, label) {
    const pill = $(".status-pill");
    pill.classList.toggle("connected", connected);
    $("#statusText").textContent = label;
  }

  function getKey() {
    return ($("#apiKey").value || "").trim() || localStorage.getItem(STORAGE.key) || "";
  }

  function loadSettings() {
    $("#apiKey").value = localStorage.getItem(STORAGE.key) || "";
    $("#modelName").value = localStorage.getItem(STORAGE.model) || "openrouter/free";
    $("#rememberKey").checked = localStorage.getItem(STORAGE.remember) !== "false";
    setStatus(Boolean(getKey()), getKey() ? "Ключ добавлен" : "Нужен API-ключ");
  }

  function saveSettings(showMessage = true) {
    const key = ($("#apiKey").value || "").trim();
    const model = ($("#modelName").value || "openrouter/free").trim();
    if (!model) {
      $("#settingsFeedback").textContent = "Укажи идентификатор модели.";
      $("#settingsFeedback").classList.add("error");
      return false;
    }
    localStorage.setItem(STORAGE.model, model);
    localStorage.setItem(STORAGE.remember, String($("#rememberKey").checked));
    if ($("#rememberKey").checked && key) localStorage.setItem(STORAGE.key, key);
    else localStorage.removeItem(STORAGE.key);
    $("#settingsFeedback").classList.remove("error");
    $("#settingsFeedback").textContent = "Настройки сохранены.";
    setStatus(Boolean(key), key ? "Ключ добавлен" : "Нужен API-ключ");
    if (showMessage) showToast("Настройки сохранены");
    return true;
  }

  function currentModel() {
    return (localStorage.getItem(STORAGE.model) || "openrouter/free").trim();
  }

  function addMessage(role, content, options = {}) {
    const item = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      role,
      content: String(content),
      time: nowLabel()
    };
    state.messages.push(item);
    if (state.messages.length > 50) state.messages = state.messages.slice(-50);
    renderMessage(item, options);
    saveJSON(STORAGE.messages, state.messages);
    return item;
  }

  function renderMessage(item, options = {}) {
    const isUser = item.role === "user";
    const row = document.createElement("div");
    row.className = `message ${isUser ? "user-message" : "assistant-message"}`;
    row.dataset.messageId = item.id;
    const avatar = document.createElement("div");
    avatar.className = "message-avatar";
    avatar.textContent = isUser ? "Я" : "✦";
    const wrap = document.createElement("div");
    wrap.className = "bubble-wrap";
    const author = document.createElement("div");
    author.className = "message-author";
    author.innerHTML = `${isUser ? "ТЫ" : "FITMIND"} <time>${escapeHTML(item.time || nowLabel())}</time>`;
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.innerHTML = formatText(item.content);
    wrap.append(author, bubble);
    if (!isUser && options.showSave !== false && looksLikePlan(item.content)) {
      const tools = document.createElement("div");
      tools.className = "message-tools";
      const saveBtn = document.createElement("button");
      saveBtn.className = "tiny-action";
      saveBtn.textContent = "＋ Сохранить план";
      saveBtn.addEventListener("click", () => saveWorkout(item.content));
      tools.append(saveBtn);
      wrap.append(tools);
    }
    row.append(avatar, wrap);
    messagesEl.append(row);
  }

  function looksLikePlan(text) {
    return /Название плана\s*:/i.test(text) ||
      (/разминк/i.test(text) && /упражнен/i.test(text) && /(подход|повтор|секунд|min|минут)/i.test(text));
  }

  function renderAllMessages() {
    messagesEl.innerHTML = "";
    if (!state.messages.length) {
      const welcome = {
        id: "welcome", role: "assistant", time: "СЕЙЧАС",
        content: "Привет! Я помогу составить тренировочный план под твои цели и возможности. 💪\n\nДля начала расскажи:\n• какая у тебя цель — сила, выносливость, рельеф или общее здоровье;\n• какой у тебя опыт тренировок;\n• где тренируешься и какое есть оборудование;\n• сколько дней в неделю готов заниматься."
      };
      renderMessage(welcome, { showSave: false });
      return;
    }
    state.messages.forEach(item => renderMessage(item));
  }

  function setBusy(busy) {
    state.busy = busy;
    sendButton.disabled = busy;
    inputEl.disabled = busy;
    sendButton.textContent = busy ? "…" : "➤";
    sendButton.setAttribute("aria-label", busy ? "Ответ генерируется" : "Отправить сообщение");
  }

  function addTyping() {
    const row = document.createElement("div");
    row.className = "message assistant-message typing";
    row.id = "typingIndicator";
    row.innerHTML = '<div class="message-avatar">✦</div><div class="bubble-wrap"><div class="message-author">FITMIND</div><div class="bubble">Тренер думает…</div></div>';
    messagesEl.append(row);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function removeTyping() {
    $("#typingIndicator")?.remove();
  }

  async function sendToOpenRouter(userText) {
    const key = getKey();
    if (!key) {
      settingsDialog.showModal();
      $("#settingsFeedback").textContent = "Добавь API-ключ OpenRouter, чтобы начать диалог.";
      $("#settingsFeedback").classList.add("error");
      throw new Error("NO_API_KEY");
    }
    const model = currentModel();
    const history = state.messages
      .filter(item => item.id !== "welcome")
      .slice(-16)
      .map(item => ({ role: item.role, content: item.content }));

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json",
        "X-OpenRouter-Title": "FITMIND AI Fitness Coach"
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...history,
          { role: "user", content: userText }
        ],
        temperature: 0.65,
        max_tokens: 1200
      })
    });

    let data;
    try { data = await response.json(); }
    catch { throw new Error(`Сервер вернул некорректный ответ (HTTP ${response.status}).`); }

    if (!response.ok) {
      const apiMessage = data?.error?.message || `HTTP ${response.status}`;
      if (response.status === 401) throw new Error("API-ключ не принят. Проверь его в настройках OpenRouter.");
      if (response.status === 402) throw new Error("Провайдер сообщил о нехватке кредитов или недоступности бесплатного доступа. Проверь тариф и выбранную модель; не пополняй баланс, если хочешь сохранить режим $0.");
      if (response.status === 429) throw new Error("Лимит запросов исчерпан или модель перегружена. Попробуй позже.");
      throw new Error(`Ошибка OpenRouter: ${apiMessage}`);
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== "string" || !content.trim()) {
      throw new Error("Модель вернула пустой ответ. Попробуй другую бесплатную модель.");
    }
    return content.trim();
  }

  async function handleSend(text) {
    const message = text.trim();
    if (!message || state.busy) return;
    inputEl.value = "";
    updateCharCount();
    addMessage("user", message);
    setBusy(true);
    addTyping();
    try {
      const answer = await sendToOpenRouter(message);
      removeTyping();
      addMessage("assistant", answer);
    } catch (error) {
      removeTyping();
      if (error.message !== "NO_API_KEY") {
        addMessage("assistant", `Не получилось получить ответ.\n\n${error.message}\n\nПроверь подключение и настройки модели, затем попробуй ещё раз.`);
      }
    } finally {
      setBusy(false);
      inputEl.focus();
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }
  }

  function getPlanTitle(content) {
    const match = content.match(/Название плана\s*:\s*([^\n\r]+)/i);
    if (match) return match[1].replace(/[.*_#]/g, "").trim().slice(0, 70);
    const first = content.split(/\n/).map(line => line.trim()).find(line => line.length > 4);
    return (first || "Моя тренировка").replace(/^[#*\-\d.\s]+/, "").slice(0, 60) || "Моя тренировка";
  }

  function saveWorkout(content) {
    const title = getPlanTitle(content);
    const duplicate = state.workouts.some(w => w.content === content);
    if (duplicate) { showToast("Этот план уже сохранён"); return; }
    state.workouts.unshift({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title,
      content,
      createdAt: new Date().toISOString()
    });
    saveJSON(STORAGE.workouts, state.workouts);
    renderWorkouts();
    showToast("План сохранён в «Мои тренировки»");
  }

  function renderWorkouts() {
    const list = $("#workoutList");
    list.innerHTML = "";
    $("#workoutCount").textContent = String(state.workouts.length);
    $("#emptyWorkouts").classList.toggle("visible", state.workouts.length === 0);
    state.workouts.forEach(workout => {
      const card = document.createElement("article");
      card.className = "workout-card";
      const date = new Date(workout.createdAt);
      const dateText = Number.isNaN(date.getTime()) ? "" : new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", year: "numeric" }).format(date);
      card.innerHTML = `
        <div class="workout-card-top"><span class="workout-badge">ПЛАН ТРЕНИРОВОК</span><span class="workout-date">${escapeHTML(dateText)}</span></div>
        <h3>${escapeHTML(workout.title)}</h3>
        <p>${escapeHTML(workout.content)}</p>
        <div class="workout-card-footer"><button class="secondary-button open-workout">Открыть план</button><button class="secondary-button delete-workout" aria-label="Удалить план">✕</button></div>`;
      card.querySelector(".open-workout").addEventListener("click", () => openWorkout(workout.id));
      card.querySelector(".delete-workout").addEventListener("click", () => {
        state.workouts = state.workouts.filter(w => w.id !== workout.id);
        saveJSON(STORAGE.workouts, state.workouts);
        renderWorkouts();
        showToast("План удалён");
      });
      list.append(card);
    });
  }

  function openWorkout(id) {
    const workout = state.workouts.find(w => w.id === id);
    if (!workout) return;
    state.activeWorkoutId = id;
    $("#workoutDialogTitle").textContent = workout.title;
    $("#workoutDetail").textContent = workout.content;
    workoutDialog.showModal();
  }

  function updateCharCount() {
    $("#charCount").textContent = `${inputEl.value.length} / 5000`;
    inputEl.style.height = "auto";
    inputEl.style.height = `${Math.min(inputEl.scrollHeight, 130)}px`;
  }

  async function testConnection() {
    const feedback = $("#settingsFeedback");
    feedback.classList.remove("error");
    const key = ($("#apiKey").value || "").trim() || localStorage.getItem(STORAGE.key) || "";
    const model = ($("#modelName").value || "openrouter/free").trim();
    if (!key) {
      feedback.textContent = "Сначала введи API-ключ.";
      feedback.classList.add("error");
      return;
    }
    feedback.textContent = "Проверяем подключение…";
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json", "X-OpenRouter-Title": "FITMIND AI Fitness Coach" },
        body: JSON.stringify({
          model,
          messages: [{ role: "user", content: "Ответь одним словом: OK" }],
          max_tokens: 10,
          temperature: 0
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error?.message || `HTTP ${response.status}`);
      feedback.textContent = "Подключение успешно. Ответ модели получен.";
      if ($("#rememberKey").checked) localStorage.setItem(STORAGE.key, key);
      setStatus(true, "Подключено");
    } catch (error) {
      feedback.textContent = `Ошибка: ${error.message || "не удалось подключиться"}`;
      feedback.classList.add("error");
    }
  }

  function activateTab(tabName) {
    document.querySelectorAll(".tab").forEach(tab => tab.classList.toggle("active", tab.dataset.tab === tabName));
    $("#chatPanel").classList.toggle("active", tabName === "chat");
    $("#workoutsPanel").classList.toggle("active", tabName === "workouts");
  }

  $("#chatForm").addEventListener("submit", event => {
    event.preventDefault();
    handleSend(inputEl.value);
  });
  inputEl.addEventListener("input", updateCharCount);
  inputEl.addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      $("#chatForm").requestSubmit();
    }
  });
  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => activateTab(tab.dataset.tab)));
  document.querySelectorAll(".prompt-chip").forEach(button => button.addEventListener("click", () => {
    activateTab("chat");
    handleSend(button.dataset.prompt);
  }));
  $("#clearChat").addEventListener("click", () => {
    if (!confirm("Очистить историю чата? Сохранённые тренировки не будут удалены.")) return;
    state.messages = [];
    saveJSON(STORAGE.messages, state.messages);
    renderAllMessages();
    showToast("История чата очищена");
  });
  $("#openSettings").addEventListener("click", () => {
    loadSettings();
    settingsDialog.showModal();
  });
  $("#saveSettings").addEventListener("click", () => {
    if (saveSettings()) settingsDialog.close();
  });
  $("#toggleKey").addEventListener("click", () => {
    const input = $("#apiKey");
    const visible = input.type === "text";
    input.type = visible ? "password" : "text";
    $("#toggleKey").textContent = visible ? "Показать" : "Скрыть";
  });
  $("#testConnection").addEventListener("click", testConnection);
  $("#newWorkoutPrompt").addEventListener("click", () => {
    activateTab("chat");
    inputEl.value = "Задай мне вопросы, чтобы составить персональную программу тренировок.";
    updateCharCount();
    inputEl.focus();
  });
  $("#goToChat").addEventListener("click", () => activateTab("chat"));
  $("#closeWorkout").addEventListener("click", () => workoutDialog.close());
  $("#deleteWorkout").addEventListener("click", () => {
    state.workouts = state.workouts.filter(w => w.id !== state.activeWorkoutId);
    saveJSON(STORAGE.workouts, state.workouts);
    renderWorkouts();
    workoutDialog.close();
    showToast("План удалён");
  });

  state.messages = readJSON(STORAGE.messages, []);
  state.workouts = readJSON(STORAGE.workouts, []);
  loadSettings();
  renderAllMessages();
  renderWorkouts();
  updateCharCount();
})();