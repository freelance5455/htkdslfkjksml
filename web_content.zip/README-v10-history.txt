LOONIE ACADEMY v10 — KNOWLEDGE KINGDOM (PHASE 4)
2026-11-15 | Complete offline-first HTML/PWA package

SOURCE / PRESERVATION
---------------------
Built directly from the v9 Interactive Inquiry ZIP the user uploaded:
Loonie_Academy_v9_Interactive_Inquiry(1).zip
The original ZIP was not overwritten or modified. The original v6/v7 curricula,
university-v8.js/.css, and inquiry-v9.js/.css are included unchanged. This is a
COMPLETE v10 APP, not a small update patch.

WHAT IS NEW IN v10
------------------
A. KNOWLEDGE KINGDOM
- Interactive stylized kingdom map with six regions and accessible region lists:
  1. Lantern Library: Accounting and Excel & Data
  2. Foundry Fields: Carpentry and Electrical
  3. Market Harbor: Business/Tax and Money/Investing
  4. Algorithm Grove: Coding and AI/Tech
  5. Compass Highlands: Career Skills and Law/Rights
  6. Discovery Frontier: Aviation and Design/3D
- Original regional stories and character-driven guardian encounters.
- A new Kingdom entry in the original visual Campus (World tab), with quick
  links on Learn and a saved expedition journal on Me.
- The ORIGINAL 15-building visual Campus, collectibles, markets, boss arena,
  passports and other worlds have NOT been removed or replaced.

B. TWELVE LINKED LEARNING QUESTS
- Exactly two chapter missions per region, each linked to an existing lesson.
- The learner completes that lesson using the EXISTING real lesson/quiz system.
- Then three objective checks sourced from the original lesson are answered.
- At least 2/3 correct to complete the chapter; wrong answers display original
  explanations for learning; retries are unlimited.
- Chapter 2 requires Chapter 1; old completed lessons count automatically.
- Each chapter awards 30 XP, 25 coins, and 1 Kingdom Spark ONCE only.

C. SIX GUARDIAN TRIALS & SIX RELICS
- A unique guardian for each region, unlocked after both region chapters.
- Five original knowledge checks drawn from BOTH of the chapter lessons.
- At least 4/5 correct to win; retry indefinitely with original explanations.
- Each first victory awards 80 XP, 60 coins, 2 Kingdom Sparks, a relic and
  another saved story chapter. Later replays are practice-only (no extra XP).
- Defeating all six unlocks the Royal Scholar IN-APP achievement and story ending.

D. EIGHTEEN VISIBLE LANDMARK UPGRADES
- One landmark per region, each with levels 0 → 1 → 2 → 3.
- Level 1 requires Chapter 1 and 1 Spark; level 2 requires Chapter 2 and 1 Spark;
  level 3 requires the guardian victory and 2 Sparks.
- Sparks are a NEW dedicated, persistent in-app resource; original coins and
  purchases remain intact. Complete all chapters and guardians to earn exactly
  the 24 Sparks needed for all 18 upgrades.
- Landmark changes are visible on the region screen and in the journal.

E. JOURNAL, RESEARCH NOTES, DAILY REVIEW & ACHIEVEMENTS
- Private region field notes, saved on input, up to 1,200 characters each.
- Expedition journal shows chapter progress, unlocked stories, relics,
  region notes, and landmark levels.
- Daily Kingdom Dispatch offers three original questions from completed
  lessons, requiring 2/3 to pass. First completion per local calendar day
  rewards 15 XP and 10 coins; subsequent replays that day pay no reward.
  Dispatch requires enough completed lesson questions to create a quiz.
- Six new Loonie achievement badges; older badges remain.
- Existing app-wide backup includes the full `kingdomV10` saved progress.

WHAT IS PRESERVED FROM v9
-------------------------
- 384 existing lessons, 37 subjects, and 2,022 original quiz questions.
- All 9 interactive experimental labs and 6 evidence investigations.
- All 3 Teach Lou Plus modes and the original Teach Lou.
- Personal University (4 pathways, 4 semesters each; assignments, exams,
  projects, saved gradebooks and unofficial transcript exports).
- Past lesson results, stars, notes, bookmarks, XP, coins, purchases, streaks,
  original campus, achievements, review scheduler, SRS, missions, simulators,
  previous backups and research notes.

SAFE UPGRADE INSTRUCTIONS
-------------------------
1. Before upgrading, open your CURRENT Loonie Academy v9 installation.
   Go to Me → Backup & Restore → Download backup. Save a second copy elsewhere
   (such as a computer folder or Drive), and keep your old v9 ZIP intact.
2. Extract the ENTIRE new v10 ZIP, not just index.html. Keep all .js, .css,
   icons, webmanifest, and sw.js in the same directory as index.html.
3. If your current app is on HTTPS hosting, upload/replace the app assets
   at the EXACT SAME origin and path. Don't uninstall your installed PWA.
   Changing a domain, scheme, port or local file context can disconnect it
   from its existing browser local-storage database.
4. Refresh the existing app while online; installed PWA cache changes may
   require closing/reopening it once. Verify World → Knowledge Kingdom.
5. Check old completed lessons, university semesters, inquiry notebooks,
   existing XP/coins, and backups. Try the first quest and write a field note.
6. Verify Android installed-app airplane-mode reopening ON YOUR OWN PHONE.
   Actual Android hardware testing was not possible here. The test environment
   runs browser module tests and simulates the service worker cache logic.
7. If your progress is missing, first check that you are still on the same
   hosting origin. If needed, restore your pre-upgrade progress from the
   old downloaded backup in Me → Backup & Restore.

RUNNING LOCALLY
---------------
- The app can open as a static HTML site on a desktop, with browser storage
  restrictions varying by browser. For install/offline service worker support,
  use HTTPS or localhost; opening index.html directly via file:// is not an
  adequate service-worker installation test.
- No account, internet AI API, subscription or paid server is required for the
  Knowledge Kingdom features. The app's decorative Google Fonts and optional
  Python playground runtime may require an initial internet connection.

QUALITY ASSURANCE
-----------------
See QA-v10.txt. Developer checks (Python 3, playwright, Chromium, Node):
  python qa-phase4.py
  python qa-phase3-v10.py
  python qa-phase2-v10.py
  node qa-sw-v10.js
All checks above passed on the generated package. The automated browser
runner tests in isolated mock localStorage because the test environment blocks
localhost HTTP navigation. It does not modify actual user progress.

HONEST LIMITATIONS
------------------
- A guardian's correct answers are from the original lesson question bank;
  written region notes are NOT automatically semantically graded.
- Knowledge Kingdom achievements are entertainment/game badges, not real
  educational credentials, university credit, trade certification or licensing.
- Daily rewards use the device's local calendar date, not a remote verified
  time server. This is an offline-first personal application, not anti-cheat.
- Real Android install/offline/low-storage behavior, real browsers on every
  device, and every legacy simulation have NOT been physically tested.
- Preserve your original app and backup until you confirm the upgrade.

NEXT ROADMAP PHASE (NOT INCLUDED): PHASE 5, CAREER PATHWAYS & PORTFOLIOS.
