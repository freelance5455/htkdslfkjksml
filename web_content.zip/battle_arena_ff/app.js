const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "battleArenaFF_demo_v1";
const ADMIN_PIN = "2468"; // DEMO ONLY — not secure for a real app.
const seed = {
  profile: null,
  tournaments: [
    {id:"t1",name:"Weekend Solo Clash",mode:"Solo",date:new Date(Date.now()+86400000).toISOString(),fee:0,prize:500,max:48,entries:[],status:"Upcoming",roomId:"",roomPassword:""},
    {id:"t2",name:"Duo Knockout",mode:"Duo",date:new Date(Date.now()+172800000).toISOString(),fee:10,prize:1000,max:24,entries:[],status:"Upcoming",roomId:"",roomPassword:""},
    {id:"t3",name:"Squad Championship",mode:"Squad",date:new Date(Date.now()+259200000).toISOString(),fee:20,prize:3000,max:12,entries:[],status:"Upcoming",roomId:"",roomPassword:""}
  ],
  results: [
    {player:"ShadowX",mode:"Solo",kills:8,points:18,note:"Demo result"},
    {player:"FireStorm",mode:"Duo",kills:6,points:15,note:"Demo result"},
    {player:"Team Phoenix",mode:"Squad",kills:12,points:27,note:"Demo result"}
  ]
};
let data;
try { data = JSON.parse(localStorage.getItem(STORAGE_KEY)) || structuredClone(seed); } catch { data = structuredClone(seed); }
let adminUnlocked = false;
let activeRoomTournament = null;
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data));}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function money(n){return "₹"+Number(n||0).toLocaleString("en-IN");}
function fmtDate(s){const d=new Date(s);return Number.isNaN(+d)?"Date to be announced":d.toLocaleString("en-IN",{day:"numeric",month:"short",hour:"numeric",minute:"2-digit"});}
function toast(msg){$("toast").textContent=msg;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),2600);}
function render(){
  const mode=$("modeFilter").value;
  const list=data.tournaments.filter(t=>mode==="All Modes"||t.mode===mode);
  $("tournamentList").innerHTML=list.length?list.map(t=>`<article class="t-card"><span class="tag ${t.status==="Live"?"live":""}">${esc(t.status.toUpperCase())}</span><h3>${esc(t.name)}</h3><p class="muted">${esc(t.mode)} • ${fmtDate(t.date)}</p><div class="meta"><div><small>ENTRY FEE</small><b>${t.fee===0?"FREE":money(t.fee)}</b></div><div><small>PRIZE POOL</small><b>${money(t.prize)}</b></div><div><small>ENTRIES</small><b>${t.entries.length}/${t.max}</b></div><div><small>FORMAT</small><b>${esc(t.mode)}</b></div></div><button class="primary" data-join="${esc(t.id)}" ${t.status==="Completed"||t.entries.length>=t.max?"disabled":""}>${t.entries.length>=t.max?"Full":t.status==="Completed"?"Completed":"Join tournament"}</button>${t.entries.some(e=>data.profile&&e.email===data.profile.email)?`<button class="secondary room-open" data-room="${esc(t.id)}" style="width:100%;margin-top:8px">View room details</button>`:""}</article>`).join(""):'<div class="empty">No tournaments for this mode yet.</div>';
  $("statTournaments").textContent=data.tournaments.length;
  $("statPlayers").textContent=data.tournaments.reduce((n,t)=>n+t.entries.length,0);
  $("statPrize").textContent=money(data.tournaments.reduce((n,t)=>n+Number(t.prize||0),0));
  const sorted=[...data.results].sort((a,b)=>b.points-a.points||b.kills-a.kills);
  $("leaderboard").innerHTML=sorted.length?sorted.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.player)}</td><td>${esc(r.mode)}</td><td>${r.kills}</td><td>${r.points}</td></tr>`).join(""):'<tr><td colspan="5">No results published yet.</td></tr>';
  $("resultsList").innerHTML=sorted.length?sorted.map(r=>`<article class="panel result-card"><div class="result-icon">🏆</div><div><h3>${esc(r.player)}</h3><p>${esc(r.mode)} • ${r.kills} kills • ${esc(r.note||"Match result")}</p></div><div class="result-points">${r.points} pts</div></article>`).join(""):'<div class="empty">Results will appear here.</div>';
  if(adminUnlocked) renderManage();
}
function renderManage(){
  const selected=$("manageSelect").value||data.tournaments[0]?.id;
  $("manageSelect").innerHTML=data.tournaments.map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join("");
  if(selected&&data.tournaments.some(t=>t.id===selected)) $("manageSelect").value=selected;
  const t=data.tournaments.find(x=>x.id===$("manageSelect").value);
  if(t){$("roomId").value=t.roomId||"";$("roomPassword").value=t.roomPassword||"";$("matchStatus").value=t.status;}
  $("entriesList").innerHTML=t&&t.entries.length?t.entries.map(e=>`<div class="entry"><span>${esc(e.ign)} <span class="muted">(${esc(e.mode)})</span></span><span>${esc(e.email)}</span></div>`).join(""):'<div class="empty">No registered entries for this tournament.</div>';
}
function showAccount(){ $("accountPanel").classList.remove("hidden"); if(data.profile){$("email").value=data.profile.email;$("ign").value=data.profile.ign;$("uid").value=data.profile.uid;} }
$("profileBtn").addEventListener("click",showAccount);
$("closeAccount").addEventListener("click",()=>$("accountPanel").classList.add("hidden"));
$("loginForm").addEventListener("submit",e=>{e.preventDefault();data.profile={email:$("email").value.trim().toLowerCase(),ign:$("ign").value.trim(),uid:$("uid").value.trim()};save();$("accountStatus").textContent="Demo profile saved on this device.";render();toast("Demo profile saved");});
$("modeFilter").addEventListener("change",render);
$("tournamentList").addEventListener("click",e=>{
 const join=e.target.closest("[data-join]"); const room=e.target.closest("[data-room]");
 if(join){if(!data.profile){showAccount();toast("Create your demo profile first");return;}
  const t=data.tournaments.find(x=>x.id===join.dataset.join);if(!t)return;
  if(t.entries.some(x=>x.email===data.profile.email)){toast("You already joined this tournament");return;}
  if(t.entries.length>=t.max){toast("Tournament is full");return;}
  t.entries.push({...data.profile,mode:t.mode,joinedAt:new Date().toISOString()});save();render();toast("Tournament registration saved on this device");}
 if(room) openRoom(room.dataset.room);
});
function openRoom(id){const t=data.tournaments.find(x=>x.id===id);if(!t)return;activeRoomTournament=id;$("roomPanel").classList.remove("hidden");$("roomDetails").innerHTML=`<h3>${esc(t.name)}</h3><p class="muted">${esc(t.status)} • ${fmtDate(t.date)}</p><div class="room-box"><p>Room ID: <b>${esc(t.roomId||"Not published yet")}</b></p><p>Room password: <b>${esc(t.roomPassword||"Not published yet")}</b></p></div><p class="muted">Only share room details with registered players. This demo does not enforce secure access.</p>`;$("roomPanel").scrollIntoView({behavior:"smooth",block:"center"});}
$("closeRoom").addEventListener("click",()=>$("roomPanel").classList.add("hidden"));
$("adminLoginForm").addEventListener("submit",e=>{e.preventDefault();if($("adminPin").value===ADMIN_PIN){adminUnlocked=true;$("adminPanel").classList.remove("hidden");$("adminStatus").textContent="Admin demo unlocked. Changes are stored only on this device.";renderManage();}else{$("adminStatus").textContent="Incorrect demo PIN."; }});
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));$("createForm").classList.toggle("hidden",btn.dataset.tab!=="create");$("managePanel").classList.toggle("hidden",btn.dataset.tab!=="manage");}));
$("createForm").addEventListener("submit",e=>{e.preventDefault();const t={id:"t"+Date.now(),name:$("tName").value.trim(),mode:$("tMode").value,date:new Date($("tDate").value).toISOString(),fee:Number($("tFee").value),prize:Number($("tPrize").value),max:Number($("tMax").value),entries:[],status:"Upcoming",roomId:"",roomPassword:""};data.tournaments.unshift(t);save();e.target.reset();$("tFee").value=0;$("tPrize").value=0;$("tMax").value=48;render();toast("Tournament created in demo");});
$("manageSelect").addEventListener("change",renderManage);
$("roomForm").addEventListener("submit",e=>{e.preventDefault();const t=data.tournaments.find(x=>x.id===$("manageSelect").value);if(!t)return;t.roomId=$("roomId").value.trim();t.roomPassword=$("roomPassword").value.trim();t.status=$("matchStatus").value;save();render();$("adminStatus").textContent="Room details and status saved locally.";});
$("resultForm").addEventListener("submit",e=>{e.preventDefault();data.results.push({player:$("rPlayer").value.trim(),mode:$("rMode").value,kills:Number($("rKills").value),points:Number($("rPoints").value),note:$("rNote").value.trim()||"Match result"});save();e.target.reset();$("rKills").value=0;$("rPoints").value=0;render();toast("Result published in demo");});
render();
