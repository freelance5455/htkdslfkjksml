# Milk Counter Android APK project

This project packages the supplied Milk Counter PWA into an Android app using a local WebView. The app UI and data run on-device; milk records are stored in the app's local WebView storage. The Progressier remote script was removed from the packaged copy.

## Build an APK (free via GitHub Actions)
1. Create a new GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Select **Build Milk Counter APK** → **Run workflow**.
4. When it finishes, open the run and download the `milk-counter-apk` artifact. It contains `app-debug.apk`.
5. Extract the downloaded artifact ZIP on your Android phone, tap `app-debug.apk`, and follow Android's install prompts. Only install APKs from sources you trust.

This is a debug-signed APK for direct testing/distribution, not a Play Store release. For Play Store publication, create a properly signed release and follow current Google Play requirements.

## Build locally
Install Android Studio / Android SDK, then run `gradle assembleDebug` from this project root with Gradle 8.9 and JDK 17. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is a WebView-based Android package, not a full native UI rewrite.
- The app should be tested on a real Android phone, especially backup/restore and date calculations, before public distribution.
- Keep a copy of any signing key if you later make a release build; the same signing identity is needed for seamless updates.
