package com.example.missionapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_CSV_FILE = 4104;
    private WebView webView;
    private byte[] pendingCsv;
    private String pendingFilename = "Mission.csv";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new MissionBridge(), "MissionAndroid");
        webView.loadUrl("file:///android_asset/Mission_v4.html");
    }

    private class MissionBridge {
        @JavascriptInterface public void saveCsv(String filename, String content) {
            pendingFilename = (filename == null || filename.trim().isEmpty()) ? "Mission.csv" : filename;
            pendingCsv = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/csv");
                intent.putExtra(Intent.EXTRA_TITLE, pendingFilename);
                startActivityForResult(intent, CREATE_CSV_FILE);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingCsv != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Cannot open destination");
                    out.write(pendingCsv);
                    out.flush();
                    Toast.makeText(this, "فایل CSV ذخیره شد", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show();
                }
            }
            pendingCsv = null;
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("(function(){var active=document.querySelector('.page.active');if(active&&active.id!=='home'){document.querySelectorAll('.page').forEach(function(p){p.classList.toggle('active',p.id==='home')});return 'home'}return 'exit'})()", result -> {
            if ("\"exit\"".equals(result)) finish();
        });
    }
}
