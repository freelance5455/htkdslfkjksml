# EREX EDITOR — Android starter project

An Android Studio project for an early-stage mobile video editor. The app is a native Android shell containing a local HTML/JavaScript editing UI.

## Included
- Android video picker
- Video preview, play/pause and seek
- Transform controls: zoom, X/Y position and rotation
- Anime-edit style controls: shake, blur, speed setting (UI state), brightness, contrast, saturation, hue and glow
- Text overlay
- Manual keyframe capture and interpolation for transform/motion values
- Aspect-ratio and quality target selectors
- Experimental real-time WebM preview export where the device WebView supports MediaRecorder

## Important limitations
This is a working starter project, not a finished CapCut replacement.
- The current preview applies visual effects; speed control is a control value only and is not yet applied to playback.
- The experimental export does not preserve the original audio and may not work on all Android WebView versions.
- Export is not a production-grade render pipeline; it does not guarantee 1080p/1440p encoded output, hardware acceleration, or full timeline compositing.
- For production export, integrate Android Media3 Transformer or FFmpeg-based rendering and implement audio mixing, clip trimming, multi-track composition, project persistence and proper keyframe animation.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `EREX_EDITOR` folder as a project.
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible Android Gradle Plugin.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio shows a notification with **Locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it. If Android blocks installation, allow installs from that file manager for this one installation.

## Requirements
- Android Studio with JDK 17
- Android SDK Platform 35
- Internet is needed for the first Gradle dependency sync.

## App identity
- Name: EREX EDITOR
- Package: `com.erex.editor`
- Minimum Android: Android 8.0 (API 26)
