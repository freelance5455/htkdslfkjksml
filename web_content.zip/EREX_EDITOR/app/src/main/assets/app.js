const $=id=>document.getElementById(id);
const video=$('video'), fileInput=$('videoFile'), stage=$('stage');
let activePanel='transform', keyframes=[], objectUrl=null, shakeTimer=null;
const state={zoom:100,rotation:0,x:0,y:0,shake:0,blur:0,velocity:100,brightness:100,contrast:100,saturation:100,hue:0,glow:0,text:'EREX',textSize:28,textOpacity:100};
const panels={
 transform:[['zoom','Zoom',50,200,1,'%'],['x','Position X',-100,100,1,'%'],['y','Position Y',-100,100,1,'%'],['rotation','Rotation',-180,180,1,'°']],
 motion:[['shake','Shake intensity',0,30,1,''],['blur','Motion blur',0,20,1,'px'],['velocity','Speed',25,300,5,'%']],
 color:[['brightness','Brightness',50,160,1,'%'],['contrast','Contrast',50,200,1,'%'],['saturation','Saturation',0,250,1,'%'],['hue','Hue shift',0,360,1,'°'],['glow','Glow',0,20,1,'px']],
 text:[['textSize','Text size',12,72,1,'px'],['textOpacity','Text opacity',0,100,1,'%']]
};
function renderControls(){
 const controls=$('controls'); controls.innerHTML='';
 if(activePanel==='text'){
  const wrap=document.createElement('div');wrap.className='control';
  wrap.innerHTML='<div class="control-head"><span>Overlay text</span></div><input id="textValue" type="text" maxlength="24" value="'+state.text+'" style="width:100%;padding:10px;border-radius:8px;background:#171f2c;border:1px solid #263244;color:#edf4ff"><div class="control-row" style="margin-top:10px"><button class="reset" id="showText">Show / hide text</button><button class="reset" id="resetPanel">Reset text</button></div>';
  controls.appendChild(wrap);
  wrap.querySelector('#textValue').addEventListener('input',e=>{state.text=e.target.value;$('overlayText').textContent=state.text});
  wrap.querySelector('#showText').onclick=()=>{$('overlayText').style.display=$('overlayText').style.display==='block'?'none':'block'};
  wrap.querySelector('#resetPanel').onclick=()=>{state.text='EREX';state.textSize=28;state.textOpacity=100;renderControls();applyEffects()};
 } else {
  (panels[activePanel]||[]).forEach(([key,label,min,max,step,unit])=>{
   const wrap=document.createElement('div');wrap.className='control';
   wrap.innerHTML=`<div class="control-head"><label for="${key}">${label}</label><output id="${key}Out">${state[key]}${unit}</output></div><input type="range" id="${key}" min="${min}" max="${max}" step="${step}" value="${state[key]}">`;
   controls.appendChild(wrap);
   wrap.querySelector('input').addEventListener('input',e=>{state[key]=Number(e.target.value);wrap.querySelector('output').textContent=state[key]+unit;applyEffects()});
  });
  const reset=document.createElement('button');reset.className='reset';reset.textContent='Reset this section';reset.onclick=()=>{(panels[activePanel]||[]).forEach(([k])=>state[k]=({zoom:100,rotation:0,x:0,y:0,shake:0,blur:0,velocity:100,brightness:100,contrast:100,saturation:100,hue:0,glow:0})[k]);renderControls();applyEffects()};controls.appendChild(reset);
 }
}
function applyEffects(){
 const shake=state.shake?Math.sin(performance.now()/45)*state.shake:0;
 video.style.transform=`translate(${state.x+shake}px,${state.y+Math.cos(performance.now()/52)*state.shake}px) scale(${state.zoom/100}) rotate(${state.rotation}deg)`;
 video.style.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) hue-rotate(${state.hue}deg) blur(${state.blur}px) drop-shadow(0 0 ${state.glow}px #9bff4d)`;
 $('overlayText').style.fontSize=state.textSize+'px';$('overlayText').style.opacity=state.textOpacity/100;
 if(state.shake){if(!shakeTimer)shakeTimer=setInterval(()=>{if(!video.paused)applyEffects();else{clearInterval(shakeTimer);shakeTimer=null}},50)}else if(shakeTimer){clearInterval(shakeTimer);shakeTimer=null}
}
document.querySelectorAll('.tool').forEach(btn=>btn.onclick=()=>{document.querySelectorAll('.tool').forEach(b=>b.classList.remove('active'));btn.classList.add('active');activePanel=btn.dataset.panel;renderControls()});
$('importBtn').onclick=()=>fileInput.click();
fileInput.addEventListener('change',()=>{
 const file=fileInput.files&&fileInput.files[0];if(!file)return;
 if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl=URL.createObjectURL(file);video.src=objectUrl;video.style.display='block';$('placeholder').style.display='none';video.load();
 video.onloadedmetadata=()=>{$('duration').textContent=fmt(video.duration);$('videoTrack').classList.add('clip');$('videoTrack').textContent=file.name+' • '+fmt(video.duration);$('keyTrack').innerHTML='<span>No keyframes yet</span>';};
});
function fmt(s){if(!Number.isFinite(s))return '00:00';let m=Math.floor(s/60),sec=Math.floor(s%60);return String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0')}
$('playBtn').onclick=()=>{if(!video.src)return;if(video.paused){video.play();$('playBtn').textContent='Ⅱ'}else{video.pause();$('playBtn').textContent='▶'}};
video.addEventListener('timeupdate',()=>{if(video.duration){$('seek').value=video.currentTime/video.duration*1000;$('currentTime').textContent=fmt(video.currentTime)+'.'+String(Math.floor(video.currentTime%1*100)).padStart(2,'0')}});
$('seek').addEventListener('input',()=>{if(video.duration)video.currentTime=Number($('seek').value)/1000*video.duration});
$('addKey').onclick=()=>{
 if(!video.src){$('keyList').textContent='Import a video before adding keyframes.';return}
 keyframes.push({time:video.currentTime,zoom:state.zoom,x:state.x,y:state.y,rotation:state.rotation,shake:state.shake,blur:state.blur});
 keyframes.sort((a,b)=>a.time-b.time);
 $('keyTrack').innerHTML=keyframes.map(k=>`<span class="key-diamond" title="${fmt(k.time)}">◆</span>`).join('')||'<span>No keyframes yet</span>';
 $('keyList').textContent=keyframes.length+' keyframe(s): '+keyframes.map(k=>fmt(k.time)+' zoom '+k.zoom+'%').join(' • ');
};
video.addEventListener('timeupdate',()=>{
 if(keyframes.length<2)return;
 let a=null,b=null;for(const k of keyframes){if(k.time<=video.currentTime)a=k;if(k.time>=video.currentTime){b=k;break}}
 if(!a||!b||a===b)return;const t=(video.currentTime-a.time)/(b.time-a.time);
 ['zoom','x','y','rotation','shake','blur'].forEach(k=>state[k]=a[k]+(b[k]-a[k])*t);
 applyEffects();
});
$('ratio').onchange=()=>{const r=$('ratio').value;const [w,h]=r.split(':').map(Number);stage.style.aspectRatio=w+'/'+h;stage.style.height='auto';stage.style.minHeight='260px';$('ratioLabel').textContent=r+' • '+$('quality').value+'p target'};
$('quality').onchange=()=>{$('ratioLabel').textContent=$('ratio').value+' • '+$('quality').value+'p target'};
$('exportBtn').onclick=async()=>{
 if(!video.src){$('exportStatus').textContent='Please import a video first.';return}
 if(!window.MediaRecorder||!HTMLCanvasElement.prototype.captureStream){$('exportStatus').textContent='This Android WebView does not support preview export. Use Android Studio build on a recent device or export via a full video-rendering engine.';return}
 try{
  const canvas=document.createElement('canvas'),r=$('ratio').value.split(':').map(Number),q=Number($('quality').value);
  canvas.width=r[0]>=r[1]?q:Math.round(q*r[0]/r[1]);canvas.height=r[1]>r[0]?q:Math.round(q*r[1]/r[0]);
  const ctx=canvas.getContext('2d'),stream=canvas.captureStream(30);
  const recorder=new MediaRecorder(stream,{mimeType:MediaRecorder.isTypeSupported('video/webm;codecs=vp9')?'video/webm;codecs=vp9':'video/webm'});
  const chunks=[];recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onstop=()=>{const blob=new Blob(chunks,{type:recorder.mimeType});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='EREX_EDITOR_preview.webm';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);$('exportStatus').textContent='Preview export finished. Note: this experimental export does not include the source audio and may not be supported on every device.';video.pause();};
  const draw=()=>{if(recorder.state!=='recording')return;ctx.fillStyle='#000';ctx.fillRect(0,0,canvas.width,canvas.height);try{const vw=video.videoWidth,vh=video.videoHeight;if(vw&&vh){const scale=Math.min(canvas.width/vw,canvas.height/vh)*state.zoom/100;ctx.save();ctx.translate(canvas.width/2+state.x,canvas.height/2+state.y);ctx.rotate(state.rotation*Math.PI/180);ctx.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) hue-rotate(${state.hue}deg) blur(${state.blur}px)`;ctx.drawImage(video,-vw*scale/2,-vh*scale/2,vw*scale,vh*scale);ctx.restore();if($('overlayText').style.display==='block'){ctx.globalAlpha=state.textOpacity/100;ctx.fillStyle='#fff';ctx.font=`bold ${state.textSize}px sans-serif`;ctx.textAlign='center';ctx.fillText(state.text,canvas.width/2,canvas.height/2);ctx.globalAlpha=1}}}catch(e){}requestAnimationFrame(draw)};
  $('exportStatus').textContent='Recording a preview in real time… Keep the app open until it finishes.';
  video.currentTime=0;await video.play();recorder.start();draw();video.onended=()=>{if(recorder.state==='recording')recorder.stop()};
 }catch(e){$('exportStatus').textContent='Export failed on this device. This starter build needs a compatible WebView for WebM preview export.'}
};
renderControls();
