JEYAN — WHOOP-inspired interactive app prototype

HOW TO OPEN ON ANDROID
1. Extract JEYAN_WHOOP_App.zip using your phone's Files app or ZArchiver.
2. Open the extracted folder.
3. Tap index.html and choose Chrome (or another browser).
4. For an app-like full-screen experience, in Chrome tap ⋮ > Add to Home screen.

WHAT WORKS
- Home, Strain/Stats, Recovery, Sleep, More and Settings navigation
- Interactive Day / Week / Month / Year selectors
- Responsive dark interface and JEYAN profile branding
- Settings toggles, demo reset, and tap feedback

IMPORTANT
This is a functional standalone HTML prototype. The displayed health values are sample/demo values.
Live watch readings, Bluetooth pairing, account sync, notifications and cloud storage require integration
with a supported device/API and are not included in this offline prototype.
