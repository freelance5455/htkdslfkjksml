# VidSnap 2

Node.js 20+ required.

```sh
node setup.js
```

Android phone with no computer: install Termux from F-Droid, unzip this project into it and run `sh termux.sh`, then open http://localhost:5173.

Open http://localhost:5173. The server must remain running. On a phone, use the computer's LAN address; for PWA installation, deploy with HTTPS. The workspace preview is temporary, not permanent hosting.

Windows: open `start.cmd`. Linux/macOS: `sh start.sh`.

Video extraction and merging: yt-dlp + ffmpeg. Quality selection, video/audio, MP3/M4A/Opus/FLAC/WAV conversion, subtitles, metadata, clip trimming, playlists, queue, cancel/retry, SSE with polling fallback, native device saving and Range delivery. Site availability, login and regional restrictions still apply. Use only content you are authorized to download.

`node setup.js` installs missing dependencies and attempts engine installation. `npm start` starts an already-installed project. Linux x64 static ffmpeg, macOS Homebrew and Windows winget are supported by setup; other environments may require manual engine installation.

Configuration: copy `.env.example` to `.env`. `COOKIES_FILE` is an optional path to your own Netscape-format cookies. Protect that file; never include it in an archive. `MAX_CONCURRENT` controls the server worker pool. `JOB_TTL_MINUTES` controls finished-job retention. Jobs are temporary and are not preserved on server restart. Private-network source URLs are blocked.

Tests:
```sh
npm install --include=dev
npx playwright install --with-deps chromium
npm test
npm run verify
npm run ui
```

Docker:
```sh
docker build -t vidsnap .
docker run --rm -p 5173:5173 vidsnap
```
