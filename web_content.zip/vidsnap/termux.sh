#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || pkg install -y nodejs-lts
command -v ffmpeg >/dev/null 2>&1 || pkg install -y ffmpeg
command -v yt-dlp >/dev/null 2>&1 || pkg install -y yt-dlp || python3 -m pip install -U --user yt-dlp
[ -d node_modules/express ] || npm install --omit=dev --no-audit --no-fund
printf 'YTDLP_BIN=%s\nFFMPEG_LOCATION=%s\nPORT=%s\n' "$(command -v yt-dlp)" "$(command -v ffmpeg)" "${PORT:-5173}" > .env
exec node server/index.js
