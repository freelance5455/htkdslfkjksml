const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const KEY = 'vidsnap.v2';
const SESSION = (() => {
  let id = localStorage.getItem(`${KEY}.session`);
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(id || '')) {
    id = crypto.randomUUID().replace(/-/g, '');
    localStorage.setItem(`${KEY}.session`, id);
  }
  return id;
})();

const prefs = Object.assign({ tap: 'open', autocopy: true, autodl: false }, JSON.parse(localStorage.getItem(`${KEY}.prefs`) || '{}'));
const savePrefs = () => localStorage.setItem(`${KEY}.prefs`, JSON.stringify(prefs));

const state = {
  health: null,
  info: null,
  view: 'video',
  pick: null,
  jobs: new Map(),
  selected: new Set(),
  busy: false,
};

const el = {
  boot: $('#boot'),
  bootMsg: $('#boot-msg'),
  app: $('#app'),
  engine: $('#engine-pill'),
  form: $('#fetch-form'),
  url: $('#url'),
  paste: $('#paste'),
  go: $('#go'),
  featured: $('#featured'),
  panel: $('#panel'),
  thumb: $('#thumb'),
  thumbWrap: $('#thumb-wrap'),
  title: $('#title'),
  meta: $('#meta'),
  videoList: $('#quality-list'),
  audioList: $('#audio-list'),
  playlistList: $('#playlist-list'),
  playlistCount: $('#playlist-count'),
  tasks: $('#tasks'),
  tasksEmpty: $('#tasks-empty'),
  activeCount: $('#active-count'),
  summary: $('#pick-summary'),
  download: $('#download'),
  toasts: $('#toasts'),
  sheet: $('#sheet'),
  install: $('#install'),
  about: $('#about-text'),
  opts: {
    container: $('#opt-container'),
    subs: $('#opt-subs'),
    sublang: $('#opt-sublang'),
    start: $('#opt-start'),
    end: $('#opt-end'),
    cover: $('#opt-cover'),
    meta: $('#opt-meta'),
    sponsor: $('#opt-sponsor'),
    instant: $('#opt-instant'),
  },
};

function toast(message, kind = '') {
  const node = document.createElement('div');
  node.className = `toast ${kind}`;
  node.textContent = message;
  el.toasts.append(node);
  setTimeout(() => {
    node.style.opacity = '0';
    setTimeout(() => node.remove(), 300);
  }, kind === 'bad' ? 6000 : 3200);
}

async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    method: options.method || 'GET',
    headers: { 'x-session-id': SESSION, ...(options.body ? { 'content-type': 'application/json' } : {}) },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!response.ok) {
    const error = new Error(data?.error || `Request failed (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}

const bytes = (value) => {
  if (!Number.isFinite(value) || value <= 0) return '';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let index = 0;
  let size = value;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${size >= 100 || index === 0 ? Math.round(size) : size.toFixed(1)} ${units[index]}`;
};

const clock = (value) => {
  if (!Number.isFinite(value) || value <= 0) return '';
  const total = Math.round(value);
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return [hours, minutes, seconds].map((part) => String(part).padStart(2, '0')).join(':').replace(/^00:/, '');
};

const proj = (source) => {
  if (!source) return null;
  const url = new URL(source, location.origin);
  return url.href;
};

function banner(message, action) {
  const existing = $('#banner');
  if (existing) existing.remove();
  if (!message) return;
  const node = document.createElement('div');
  node.id = 'banner';
  node.className = 'card';
  node.style.borderColor = 'rgba(255,180,84,.45)';
  node.style.marginTop = '18px';
  const text = document.createElement('span');
  text.textContent = message;
  node.append(text);
  if (action) {
    const button = document.createElement('button');
    button.className = 'ghost small';
    button.type = 'button';
    button.textContent = action.label;
    button.style.marginLeft = '10px';
    button.addEventListener('click', action.run);
    node.append(button);
  }
  $('.hero').before(node);
}

function renderFeatured() {
  const names = state.health?.sites || [];
  el.featured.innerHTML = '';
  for (const host of names.slice(0, 12)) {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'chip';
    chip.textContent = host.replace(/^www\./, '').replace(/\.(com|tv|be|me)$/, '');
    chip.addEventListener('click', () => {
      el.url.value = `https://${host}/`;
      el.url.focus();
    });
    el.featured.append(chip);
  }
}

function setEngine(pillText, kind) {
  el.engine.textContent = pillText;
  el.engine.className = `pill ${kind}`;
}

async function checkEngine(force = true) {
  try {
    const health = await api(`/health?session=${SESSION}${force ? '&refresh=1' : ''}`);
    state.health = health;
    const engine = health.engine?.engine;
    const ffmpeg = health.engine?.ffmpeg;
    if (engine?.ok) {
      setEngine(ffmpeg?.ok ? `yt-dlp ${String(engine.version).split('.')[0]} · ffmpeg` : 'yt-dlp ready', '');
      if (!ffmpeg?.ok) banner('ffmpeg is missing, so merged quality, MP3 and subtitles are unavailable. Run: npm run setup', { label: 'Recheck', run: () => checkEngine(true) });
      else banner('');
    } else {
      setEngine('engine missing', 'warn');
      banner('yt-dlp is not installed. Run “npm run setup” once in the project folder, then press Recheck.', { label: 'Recheck', run: () => checkEngine(true) });
    }
    renderFeatured();
  } catch (error) {
    setEngine('offline', 'warn');
    banner(`Cannot reach the server (${error.message}).`);
  }
}

function renderInfoCard() {
  const info = state.info;
  el.title.textContent = info.title || 'Untitled';
  el.thumbWrap.hidden = !info.thumbnail;
  if (info.thumbnail) el.thumb.src = proj(`/api/thumb?url=${encodeURIComponent(info.thumbnail)}`);
  el.meta.innerHTML = '';
  const bits = [
    info.uploader,
    info.duration ? clock(info.duration) : null,
    info.viewCount ? `${new Intl.NumberFormat().format(info.viewCount)} views` : null,
    info.extractorName,
    info.fps ? `${info.fps} fps` : null,
  ].filter(Boolean);
  for (const bit of bits) {
    const tag = document.createElement('i');
    tag.textContent = bit;
    el.meta.append(tag);
  }
  const isPlaylist = info.type === 'playlist';
  $('#menu-playlist').hidden = !isPlaylist;
  $('#menu-video').hidden = isPlaylist;
  $('#menu-audio').hidden = isPlaylist;
  $('#menu-advanced').hidden = isPlaylist;
  if (isPlaylist) {
    state.view = 'playlist';
    state.selected = new Set(info.entries.map((entry) => entry.url));
    renderPlaylist();
  } else {
    state.view = 'video';
    state.pick = null;
    renderQualities();
  }
  setView(state.view);
}

function sizeOf(tier) {
  const parts = [];
  if (tier.filesize) parts.push(bytes(tier.filesize));
  return parts.join(' · ');
}

function qualityRow(tier) {
  const row = document.createElement('button');
  row.type = 'button';
  row.className = 'item';
  row.dataset.height = tier.height ?? '';
  row.dataset.kind = tier.kind;

  const q = document.createElement('span');
  q.className = 'q';
  q.textContent = tier.label;

  const sub = document.createElement('span');
  sub.className = 'sub';
  const codecs = [tier.ext?.toUpperCase(), tier.vcodec, tier.acodec ? `+${tier.acodec}` : null].filter(Boolean);
  sub.textContent = codecs.join(' ');

  const tags = document.createElement('span');
  tags.className = 'row';
  if (tier.kind === 'video') {
    const badge = document.createElement('span');
    badge.className = `tag ${tier.needsMerge ? 'warn' : ''}`;
    badge.textContent = tier.needsMerge ? 'merge' : 'ready';
    tags.append(badge);
  }

  const size = document.createElement('span');
  size.className = 'size';
  size.textContent = sizeOf(tier);

  const tick = document.createElement('span');
  tick.className = 'tick';
  tick.innerHTML = '<svg viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>';

  row.append(q, sub, tags, size, tick);
  row.addEventListener('click', () => {
    for (const node of $$('.item.sel', row.parentElement)) node.classList.remove('sel');
    row.classList.add('sel');
    state.pick = tier;
    updateSummary();
  });
  return row;
}

function renderQualities() {
  const info = state.info;
  el.videoList.innerHTML = '';
  el.audioList.innerHTML = '';
  for (const tier of info.formats?.video || []) el.videoList.append(qualityRow(tier));
  for (const tier of info.formats?.audio || []) el.audioList.append(qualityRow(tier));
  if (!el.videoList.children.length) el.videoList.innerHTML = '<p class="empty">No video track was offered for this link.</p>';
  if (!el.audioList.children.length) el.audioList.innerHTML = '<p class="empty">No audio track was offered for this link.</p>';
  updateSummary();
}

function renderPlaylist() {
  el.playlistList.innerHTML = '';
  const info = state.info;
  info.entries.forEach((entry, index) => {
    const row = document.createElement('label');
    row.className = 'item';
    const box = document.createElement('input');
    box.type = 'checkbox';
    box.checked = state.selected.has(entry.url);
    box.addEventListener('change', () => {
      if (box.checked) state.selected.add(entry.url);
      else state.selected.delete(entry.url);
      row.classList.toggle('sel', box.checked);
      renderPlaylistCount();
    });
    const q = document.createElement('span');
    q.className = 'q';
    q.textContent = String(index + 1);
    const sub = document.createElement('span');
    sub.className = 'sub';
    sub.textContent = entry.title;
    const size = document.createElement('span');
    size.className = 'size';
    size.textContent = entry.duration ? clock(entry.duration) : '';
    row.classList.toggle('sel', box.checked);
    row.append(box, q, sub, size);
    el.playlistList.append(row);
  });
  renderPlaylistCount();
}

function renderPlaylistCount() {
  el.playlistCount.textContent = `${state.selected.size} of ${state.info.entries.length} selected · ${state.info.truncated ? `first ${state.info.entries.length} episodes` : 'full playlist'}`;
  updateSummary();
}

function updateSummary() {
  const options = readOptions();
  if (state.info?.type === 'playlist') {
    el.summary.textContent = state.selected.size ? `${state.selected.size} downloads queued at the best quality` : 'Select at least one episode';
    el.download.disabled = state.selected.size === 0 || options.blocked;
    el.download.textContent = `Download ${state.selected.size || ''}`.trim();
    return;
  }
  if (!state.pick) {
    el.summary.textContent = 'Pick a quality';
    el.download.disabled = true;
    el.download.textContent = 'Download';
    return;
  }
  const tier = state.pick;
  const parts = [tier.label, tier.ext?.toUpperCase(), sizeOf(tier), tier.kind === 'audio' ? 'audio only' : tier.needsMerge ? 'video + audio merged' : 'single file'];
  el.summary.textContent = parts.filter(Boolean).join(' · ');
  el.download.disabled = Boolean(options.blocked);
  el.download.textContent = options.blocked ? options.blocked : 'Download';
}

function readOptions() {
  const container = el.opts.container.value;
  const audioContainer = ['mp3', 'm4a', 'opus', 'flac', 'wav'].includes(container) ? container : null;
  if (audioContainer && state.pick && state.pick.kind !== 'audio' && state.info?.type !== 'playlist') {
    return { blocked: 'Pick Audio tab', container: null, subtitles: false };
  }
  const start = el.opts.start.value.trim();
  const end = el.opts.end.value.trim();
  const section = start && end && /^\d{1,2}(:\d{1,2}){0,2}$/.test(start) && /^\d{1,2}(:\d{1,2}){0,2}$/.test(end) ? `${start}-${end}` : null;
  if ((start || end) && !section) return { blocked: 'Bad clip range', container: null, subtitles: false };
  const instant = el.opts.instant.checked;
  const extras = el.opts.subs.value === 'on' || el.opts.sponsor.checked || Boolean(section);
  return {
    blocked: null,
    container: audioContainer || (container === 'auto' ? null : container),
    instant: instant && !extras,
    section,
    options: {
      subtitles: el.opts.subs.value === 'on',
      subtitleLangs: el.opts.sublang.value.trim() || 'en,en-orig',
      embedThumbnail: el.opts.cover.checked,
      embedMetadata: el.opts.meta.checked,
      sponsorblock: el.opts.sponsor.checked,
      section,
    },
  };
}

function setView(view) {
  state.view = view;
  for (const name of ['video', 'audio', 'playlist', 'advanced']) {
    $(`#view-${name}`).hidden = name !== view;
    const tab = $(`#menu-${name}`);
    if (tab) tab.classList.toggle('active', name === view);
  }
  $('.panel-foot').hidden = view === 'advanced';
}

async function fetchInfo(raw) {
  const value = String(raw ?? el.url.value).trim();
  if (!value) {
    toast('Paste a link first', 'bad');
    return;
  }
  el.url.value = value;
  el.go.disabled = true;
  el.go.textContent = '…';
  try {
    const data = await api(`/info?url=${encodeURIComponent(value)}`);
    state.info = data;
    el.panel.hidden = false;
    renderInfoCard();
    el.panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const options = readOptions();
    if (prefs.autodl && data.type === 'video' && !options.blocked) {
      const tiers = data.formats?.video || [];
      if (tiers.length) {
        const index = tiers.indexOf(tiers.find((tier) => tier.height && tier.height <= 1080) || tiers[0]);
        el.videoList.children[index]?.click();
        await startDownload();
      }
    }
  } catch (error) {
    toast(error.message, 'bad');
    const existing = $('#banner');
    if (existing) existing.remove();
    banner(error.message);
  } finally {
    el.go.disabled = false;
    el.go.textContent = 'Fetch';
  }
}

async function startDownload() {
  if (state.busy) return;
  const options = readOptions();
  if (options.blocked) {
    toast(options.blocked, 'bad');
    return;
  }
  state.busy = true;
  el.download.disabled = true;
  try {
    if (state.info.type === 'playlist') {
      const chosen = playlistQuality();
      let sent = 0;
      for (const entry of state.info.entries) {
        if (!state.selected.has(entry.url)) continue;
        await api('/download', {
          method: 'POST',
          body: { url: entry.url, mode: 'process', quality: chosen, options: { ...options.options, section: null } },
        });
        sent += 1;
      }
      toast(`${sent} episode${sent === 1 ? '' : 's'} added`, 'good');
    } else {
      const tier = state.pick;
      const mode = options.instant && !tier.needsMerge && !options.container ? 'stream' : 'process';
      const quality = {
        kind: tier.kind,
        height: tier.height ?? null,
        fps: tier.fps ?? null,
        abr: tier.abr ?? null,
        container: options.container || (tier.kind === 'audio' ? defaultAudioContainer(tier) : null),
        label: tier.label,
        formatId: tier.formatId || null,
        audioFormatId: tier.audioFormatId || null,
      };
      const body = { url: state.info.webpageUrl || el.url.value.trim(), quality, options: options.options };
      if (mode === 'stream') body.mode = 'stream';
      await api('/download', { method: 'POST', body });
      toast(mode === 'stream' ? 'Ready — stream and save it below' : 'Added to the queue', 'good');
    }
  } catch (error) {
    toast(error.message, 'bad');
  } finally {
    state.busy = false;
    updateSummary();
    $('#tasks-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function defaultAudioContainer(tier) {
  if (tier.ext === 'm4a' || tier.ext === 'mp4') return 'm4a';
  if (tier.ext === 'opus' || tier.ext === 'webm') return 'opus';
  return null;
}

function playlistQuality() {
  return { kind: 'video', height: 1080, fps: null, abr: null, container: null, label: 'up to 1080p', formatId: null, audioFormatId: null };
}

function jobRow(job) {
  const node = document.createElement('div');
  node.className = `task ${job.status === 'completed' ? 'done' : job.status === 'failed' ? 'error' : ''}`;
  node.dataset.id = job.id;

  const head = document.createElement('div');
  head.className = 'task-head';
  const name = document.createElement('b');
  const label = job.quality?.kind === 'audio' ? 'Audio' : job.quality?.label || '';
  name.textContent = `${job.title || 'Video'}${label ? ` · ${label}` : ''}`;
  head.append(name);

  const percent = Math.max(0, Math.min(100, job.status === 'completed' ? 100 : job.progress?.percent ?? 0));
  const bar = document.createElement('div');
  bar.className = 'bar';
  const fill = document.createElement('i');
  fill.style.width = `${percent}%`;
  bar.append(fill);

  const foot = document.createElement('div');
  foot.className = 'task-foot';
  const detail = document.createElement('span');
  const pieces = [];
  pieces.push(job.status === 'completed' ? (job.file?.size ? bytes(job.file.size) : 'ready') : job.stage || job.status);
  if (job.status !== 'completed' && job.progress?.percent != null) pieces.push(`${percent.toFixed(0)}%`);
  if (job.progress?.speed) pieces.push(`${bytes(job.progress.speed)}/s`);
  if (job.progress?.eta) pieces.push(`${clock(job.progress.eta)} left`);
  if (job.status !== 'completed' && !job.progress?.percent && job.progress?.downloadedBytes) pieces.push(bytes(job.progress.downloadedBytes));
  detail.textContent = pieces.filter(Boolean).join(' · ');
  if (job.status === 'failed' && job.error) {
    detail.className = 'msg';
    detail.textContent = job.error;
  }
  if (job.warning && job.status === 'completed') detail.textContent = job.warning;
  foot.append(detail);

  const actions = document.createElement('div');
  actions.className = 'task-actions';

  if (job.status === 'completed') {
    const open = document.createElement('button');
    open.type = 'button';
    open.className = 'ghost small';
    open.textContent = prefs.tap === 'save' ? 'Save' : 'Open';
    open.addEventListener('click', () => {
      if (prefs.tap === 'save') downloadFile(job);
      else window.open(job.downloadUrl, '_blank', 'noopener');
    });
    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'ghost small';
    save.textContent = 'Save';
    save.addEventListener('click', () => downloadFile(job));
    const player = document.createElement('button');
    player.type = 'button';
    player.className = 'ghost small';
    player.textContent = 'Play';
    player.addEventListener('click', () => {
      const holder = document.createElement('div');
      const video = document.createElement('video');
      video.controls = true;
      video.playsInline = true;
      video.src = `${job.downloadUrl}?download=0`;
      holder.append(video);
      node.insertBefore(holder, node.lastElementChild);
      player.remove();
      video.play().catch(() => {});
    });
    actions.append(open, save, player);
  }

  if (['queued', 'starting', 'downloading', 'processing'].includes(job.status)) {
    const spinner = document.createElement('span');
    spinner.className = 'spin-mini';
    head.append(spinner);
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'ghost small';
    cancel.textContent = 'Cancel';
    cancel.addEventListener('click', async () => {
      try {
        await api(`/jobs/${job.id}/cancel`, { method: 'POST' });
      } catch (error) {
        toast(error.message, 'bad');
      }
    });
    actions.append(cancel);
  }

  if (job.status === 'failed') {
    const retry = document.createElement('button');
    retry.type = 'button';
    retry.className = 'ghost small';
    retry.textContent = 'Retry';
    retry.addEventListener('click', async () => {
      try {
        await api('/download', { method: 'POST', body: { url: job.url, quality: job.quality, options: job.options, mode: job.mode } });
        await api(`/jobs/${job.id}`, { method: 'DELETE' });
      } catch (error) {
        toast(error.message, 'bad');
      }
    });
    actions.append(retry);
  }

  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'ghost small';
  remove.textContent = '✕';
  remove.setAttribute('aria-label', 'Remove');
  remove.addEventListener('click', async () => {
    try {
      await api(`/jobs/${job.id}`, { method: 'DELETE' });
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
  actions.append(remove);

  foot.append(actions);
  node.append(head, bar, foot);
  return node;
}

function downloadFile(job) {
  const link = document.createElement('a');
  link.href = job.downloadUrl;
  link.download = job.file?.name || '';
  link.rel = 'noopener';
  document.body.append(link);
  link.click();
  link.remove();
  toast('Saving to your device…', 'good');
}

function renderJobs() {
  const list = [...state.jobs.values()].sort((a, b) => b.seq - a.seq);
  el.tasks.innerHTML = '';
  for (const job of list) el.tasks.append(jobRow(job));
  el.tasksEmpty.hidden = list.length > 0;
  const live = list.filter((job) => ['queued', 'starting', 'downloading', 'processing'].includes(job.status)).length;
  el.activeCount.textContent = String(live);
  el.activeCount.className = `pill${live ? '' : ' muted'}`;
}

function applyJob(job) {
  const previous = state.jobs.get(job.id);
  state.jobs.set(job.id, job);
  if (previous?.status !== 'completed' && job.status === 'completed') {
    toast(`${job.title || 'File'} is ready`, 'good');
    if (prefs.tap === 'save' || prefs.autodl) downloadFile(job);
  }
  renderJobs();
}

function connect() {
  const stream = new EventSource(`/api/events?session=${SESSION}`);
  stream.addEventListener('snapshot', (event) => {
    const data = JSON.parse(event.data);
    state.jobs = new Map(data.jobs.map((job) => [job.id, job]));
    renderJobs();
  });
  stream.addEventListener('job', (event) => applyJob(JSON.parse(event.data)));
  stream.addEventListener('removed', (event) => {
    const data = JSON.parse(event.data);
    if (data.id) state.jobs.delete(data.id);
    if (data.all) state.jobs.clear();
    renderJobs();
  });
  stream.addEventListener('error', () => {
    setEngine('reconnecting', 'warn');
  });
  stream.addEventListener('open', () => checkEngine(false));
  return stream;
}

async function clearJobs(all) {
  try {
    const result = await api('/jobs/clear', { method: 'POST', body: { all } });
    toast(`${result.removed} removed`);
  } catch (error) {
    toast(error.message, 'bad');
  }
}

async function readClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    if (/^https?:\/\//i.test(text.trim())) {
      el.url.value = text.trim();
      return true;
    }
  } catch {
    return false;
  }
  return false;
}

function wire() {
  el.form.addEventListener('submit', (event) => {
    event.preventDefault();
    fetchInfo();
  });

  el.paste.addEventListener('click', async () => {
    if (!(await readClipboard())) toast('Clipboard is empty or blocked — paste manually', 'bad');
    else fetchInfo();
  });

  el.url.addEventListener('focus', async () => {
    if (!prefs.autocopy || el.url.value) return;
    if (await readClipboard()) toast('Pasted from clipboard');
  });

  for (const name of ['video', 'audio', 'playlist', 'advanced']) $(`#menu-${name}`).addEventListener('click', () => setView(name));

  el.download.addEventListener('click', startDownload);
  $('#playlist-all').addEventListener('click', () => {
    state.selected = new Set(state.info.entries.map((entry) => entry.url));
    renderPlaylist();
  });
  $('#playlist-none').addEventListener('click', () => {
    state.selected = new Set();
    renderPlaylist();
  });

  $('#clear-done').addEventListener('click', () => clearJobs(false));
  $('#clear-all').addEventListener('click', () => clearJobs(true));

  for (const node of $$('.nav')) {
    node.addEventListener('click', () => {
      for (const other of $$('.nav')) other.classList.toggle('active', other === node);
      const jump = node.dataset.jump;
      if (jump === 'settings-btn') $('#settings-btn').click();
      else $(`#${jump}`).scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  const sheet = () => {
    el.sheet.hidden = !el.sheet.hidden;
  };
  $('#settings-btn').addEventListener('click', () => {
    $('#set-tap').value = prefs.tap;
    $('#set-autocopy').checked = prefs.autocopy;
    $('#set-autodl').checked = prefs.autodl;
    sheet();
  });
  $('#set-close').addEventListener('click', sheet);
  el.sheet.addEventListener('click', (event) => {
    if (event.target === el.sheet) sheet();
  });
  $('#set-tap').addEventListener('change', (event) => {
    prefs.tap = event.target.value;
    savePrefs();
  });
  $('#set-autocopy').addEventListener('change', (event) => {
    prefs.autocopy = event.target.checked;
    savePrefs();
  });
  $('#set-autodl').addEventListener('change', (event) => {
    prefs.autodl = event.target.checked;
    savePrefs();
  });

  for (const node of $$('.field input, .field select', $('#view-advanced'))) node.addEventListener('change', updateSummary);

  window.addEventListener('online', () => {
    toast('Back online', 'good');
    checkEngine(true);
  });
  window.addEventListener('offline', () => toast('You are offline — the app works, downloads need a connection', 'bad'));

  let deferred = null;
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferred = event;
    el.install.hidden = false;
  });
  el.install.addEventListener('click', async () => {
    el.install.hidden = true;
    await deferred?.prompt();
    deferred = null;
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') el.sheet.hidden = true;
  });
}

async function boot() {
  wire();
  if (state.health === null) await checkEngine(true);
  connect();
  el.about.textContent = state.health?.engine?.engine?.ok
    ? `yt-dlp ${state.health.engine.engine.version} · ffmpeg ${state.health.engine.ffmpeg.version || 'missing'} · ${state.health.engine.limits?.concurrency || 3} parallel downloads`
    : 'Engine missing — run npm run setup.';
  el.app.hidden = false;
  el.bootMsg.textContent = '';
  el.boot.style.opacity = '0';
  setTimeout(() => el.boot.remove(), 300);
  if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  try {
    const last = JSON.parse(localStorage.getItem(`${KEY}.url`) || 'null');
    if (last && !el.url.value) el.url.value = last;
  } catch {
    localStorage.removeItem(`${KEY}.url`);
  }
  el.form.addEventListener('submit', () => localStorage.setItem(`${KEY}.url`, JSON.stringify(el.url.value)), { once: true });
}

boot();
