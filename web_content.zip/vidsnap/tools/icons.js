import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = path.join(ROOT, 'public', 'icons');

const SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#5b8cff"/>
      <stop offset="1" stop-color="#22d3a6"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="112" fill="url(#g)"/>
  <path d="M256 118v168" stroke="#0b0d12" stroke-width="42" stroke-linecap="round"/>
  <path d="M188 226l68 68 68-68" fill="none" stroke="#0b0d12" stroke-width="42" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M154 392h204" stroke="#0b0d12" stroke-width="42" stroke-linecap="round"/>
</svg>
`;

const CRC = (() => {
  const table = new Int32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let value = i;
    for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    table[i] = value;
  }
  return (buffer) => {
    let crc = -1;
    for (let i = 0; i < buffer.length; i += 1) crc = table[(crc ^ buffer[i]) & 0xff] ^ (crc >>> 8);
    return (crc ^ -1) >>> 0;
  };
})();

function chunk(type, data) {
  const head = Buffer.alloc(8);
  head.writeUInt32BE(data.length, 0);
  head.write(type, 4, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(CRC(Buffer.concat([head.subarray(4), data])), 0);
  return Buffer.concat([head, data, crc]);
}

function png(width, height, rgba) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y += 1) {
    raw[y * (width * 4 + 1)] = 0;
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

const insideRound = (x, y, size, radius) => {
  const inset = radius;
  const clampedX = Math.min(Math.max(x, inset), size - inset);
  const clampedY = Math.min(Math.max(y, inset), size - inset);
  const dx = x - clampedX;
  const dy = y - clampedY;
  return dx * dx + dy * dy <= radius * radius;
};

const insideTriangle = (x, y, ax, ay, bx, by, cx, cy) => {
  const sign = (px, py, qx, qy, rx, ry) => (px - rx) * (qy - ry) - (qx - rx) * (py - ry);
  const d1 = sign(x, y, ax, ay, bx, by);
  const d2 = sign(x, y, bx, by, cx, cy);
  const d3 = sign(x, y, cx, cy, ax, ay);
  const negative = d1 < 0 || d2 < 0 || d3 < 0;
  const positive = d1 > 0 || d2 > 0 || d3 > 0;
  return !(negative && positive);
};

function render(size, { maskable = false } = {}) {
  const scale = 3;
  const buffer = Buffer.alloc(size * size * 4);
  const radius = maskable ? 0 : size * 0.219;
  const glyph = maskable ? 0.68 : 1;
  const offset = (1 - glyph) / 2;

  const unit = (value) => (offset + value * glyph) * size;
  const bar = { left: unit(0.30), right: unit(0.70), top: unit(0.79), bottom: unit(0.855) };
  const barRadius = (bar.bottom - bar.top) / 2;
  const shaft = { left: unit(0.456), right: unit(0.544), top: unit(0.23), bottom: unit(0.60) };
  const head = [unit(0.365), unit(0.545), unit(0.635), unit(0.545), unit(0.5), unit(0.755)];

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      let cornerCoverage = 0;
      let glyphCoverage = 0;
      for (let sy = 0; sy < scale; sy += 1) {
        for (let sx = 0; sx < scale; sx += 1) {
          const px = x + (sx + 0.5) / scale;
          const py = y + (sy + 0.5) / scale;
          if (insideRound(px, py, size, radius)) cornerCoverage += 1;
          const inBar =
            px >= bar.left && px <= bar.right && py >= bar.top && py <= bar.bottom ||
            insideTriangle(px, py, bar.left + barRadius, bar.top, bar.right - barRadius, bar.top, bar.right - barRadius, bar.bottom) ||
            insideTriangle(px, py, bar.left + barRadius, bar.top, bar.left + barRadius, bar.bottom, bar.right - barRadius, bar.bottom);
          const inShaft = px >= shaft.left && px <= shaft.right && py >= shaft.top && py <= shaft.bottom;
          const inHead = insideTriangle(px, py, head[0], head[1], head[2], head[3], head[4], head[5]);
          if (inBar || inShaft || inHead) glyphCoverage += 1;
        }
      }
      const samples = scale * scale;
      const alpha = cornerCoverage / samples;
      const ink = glyphCoverage / samples;
      const t = (x / size + y / size) / 2;
      const base = [91 + (34 - 91) * t, 140 + (211 - 140) * t, 255 + (166 - 255) * t];
      const rgb = base.map((channel) => Math.round(channel * (1 - ink) + 11 * ink));
      const index = (y * size + x) * 4;
      buffer[index] = rgb[0];
      buffer[index + 1] = rgb[1];
      buffer[index + 2] = rgb[2];
      buffer[index + 3] = Math.round(alpha * 255);
    }
  }
  return png(size, size, buffer);
}

fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'icon.svg'), SVG);
fs.writeFileSync(path.join(OUT, 'icon-192.png'), render(192));
fs.writeFileSync(path.join(OUT, 'icon-512.png'), render(512));
fs.writeFileSync(path.join(OUT, 'icon-maskable-512.png'), render(512, { maskable: true }));
console.log('icons written to public/icons');
