import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { config, log, debug } from './config.js';
import {
  downloadArgs, EngineError, explain, output, probe, progress, removeDir, direct, run, stripPrefix,
} from './engine.js';
import { mimeFor, safeName } from './http.js';

const jobs = new Map();
const queue = [];
const running = new Map();
const listeners = new Map();
const lastEmit = new Map();

let active = 0;
let seq = 0;

const LIVE = new Set(['queued', 'starting', 'downloading', 'processing']);

export const get = (id) => jobs.get(id) || null;

export const list = (session) =>
  [...jobs.values()].filter((job) => job.session === session).sort((a, b) => b.createdAt - a.createdAt);

export const busy = (session) => [...jobs.values()].filter((job) => job.session === session && LIVE.has(job.status)).length;

export function publicJob(job) {
  return {
    id: job.id,
    seq: job.seq,
    revision: job.revision || 0,
    url: job.url,
    title: job.title,
    thumbnail: job.thumbnail,
    duration: job.duration,
    extractor: job.extractor,
    quality: job.quality,
    options: job.options,
    mode: job.mode,
    status: job.status,
    stage: job.stage,
    progress: job.progress,
    file: job.file ? { name: job.file.name, size: job.file.size, ext: job.file.ext, mime: job.file.mime } : null,
    error: job.error,
    warning: job.warning,
    createdAt: job.createdAt,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    downloadUrl: job.status === 'completed' ? (job.mode === 'stream' ? `/api/stream/${job.id}` : `/api/file/${job.id}`) : null,
  };
}

export function subscribe(session, res) {
  if (!listeners.has(session)) listeners.set(session, new Set());
  listeners.get(session).add(res);
  res.on('close', () => {
    const set = listeners.get(session);
    if (!set) return;
    set.delete(res);
    if (!set.size) listeners.delete(session);
  });
  send(res, 'snapshot', { jobs: list(session).map(publicJob) });
}

function send(res, event, data) {
  try {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  } catch {
    return;
  }
}

function publish(session, event, data) {
  const set = listeners.get(session);
  if (!set) return;
  for (const res of set) send(res, event, data);
}

setInterval(() => {
  for (const set of listeners.values()) {
    for (const res of set) {
      try {
        res.write(': ping\n\n');
      } catch {
        continue;
      }
    }
  }
}, 25000).unref();

function emit(job, force = false) {
  const now = Date.now();
  if (!force && now - (lastEmit.get(job.id) || 0) < 200) return;
  lastEmit.set(job.id, now);
  job.revision = (job.revision || 0) + 1;
  publish(job.session, 'job', publicJob(job));
}

function make({ session, url, quality, options, mode, meta }) {
  seq += 1;
  const id = crypto.randomUUID().replace(/-/g, '').slice(0, 24);
  return {
    id,
    seq,
    session,
    url,
    quality,
    options,
    mode: mode === 'stream' ? 'stream' : 'process',
    title: meta.title || null,
    thumbnail: meta.thumbnail || null,
    duration: meta.duration ?? null,
    extractor: meta.extractor || null,
    status: 'queued',
    stage: 'Waiting for a slot',
    progress: { percent: null, downloadedBytes: 0, totalBytes: null, speed: null, eta: null, fragment: null, fragments: null },
    phases: [],
    streamInfo: null,
    file: null,
    error: null,
    warning: null,
    dir: path.join(config.jobsDir, id),
    outputTemplate: '',
    ownsDir: false,
    withVideo: true,
    withAudio: true,
    createdAt: Date.now(),
    startedAt: null,
    finishedAt: null,
  };
}

function applyProgress(job, event) {
  if (event.kind === 'post') {
    if (event.state === 'started') {
      job.status = 'processing';
      job.stage = event.tool ? `Running ${event.tool}` : 'Post-processing';
      emit(job);
    }
    return;
  }

  const done = event.done ?? 0;
  let phase = job.phases[job.phases.length - 1];
  const isNew = !phase || phase.done || (phase.done_bytes > 0 && done < phase.done_bytes * 0.4) || (phase.total && done > phase.total * 1.05);
  if (isNew) {
    if (phase) phase.done = true;
    phase = { done_bytes: 0, total: event.all ?? null, done: false };
    job.phases.push(phase);
    if (job.phases.length > 8) job.phases.shift();
  }

  phase.done_bytes = Math.max(phase.done_bytes, done);
  if (event.all) phase.total = Math.max(phase.total || 0, event.all);

  const everyKnown = job.phases.every((p) => p.total);
  const totalKnown = job.phases.reduce((sum, p) => sum + (p.total || 0), 0);
  const seen = job.phases.reduce((sum, p) => sum + p.done_bytes, 0);

  job.progress.downloadedBytes = seen;
  job.progress.totalBytes = everyKnown && totalKnown > 0 ? totalKnown : null;
  job.progress.percent = everyKnown && totalKnown > 0 ? Math.min(100, (seen / totalKnown) * 100) : null;
  job.progress.speed = event.speed ?? null;
  job.progress.eta = event.eta ?? null;
  job.progress.fragment = event.fragment ?? null;
  job.progress.fragments = event.fragments ?? null;

  if (event.state === 'finished' || event.state === 'processing') {
    job.status = 'processing';
    job.stage = 'Merging with ffmpeg';
    phase.done = true;
  } else {
    job.status = 'downloading';
    job.stage = job.phases.length > 1 ? 'Downloading video + audio' : job.quality.kind === 'audio' ? 'Downloading audio' : 'Downloading video';
  }
  job.startedAt = job.startedAt || Date.now();
  emit(job);
}

function sidecarWarning(stderr) {
  const lines = String(stderr || '').split('\n').filter((line) => line.startsWith('ERROR:'));
  if (!lines.length) return 'Some optional extras could not be fetched.';
  const raw = stripPrefix(lines[lines.length - 1].replace(/^ERROR:\s*/, ''));
  const short = raw.length > 120 ? `${raw.slice(0, 117)}…` : raw;
  if (/subtitle/i.test(raw)) return `Saved, but subtitles were skipped — ${short}`;
  if (/thumbnail|cover art/i.test(raw)) return `Saved, but the thumbnail was skipped — ${short}`;
  if (/429|Too Many Requests/i.test(raw)) return `Saved, but an extra step was rate-limited — ${short}`;
  return `Saved, but one extra step failed — ${short}`;
}

async function processJob(job, signal) {
  job.ownsDir = true;
  await fsp.mkdir(job.dir, { recursive: true });
  job.outputTemplate = path.join(job.dir, 'media.%(ext)s');

  const info = await probe(job.url, { signal }).catch(() => null);
  if (signal.aborted) return;
  if (info) {
    const formats = (info.formats || []).filter((f) => f.url);
    job.withVideo = formats.some((f) => f.vcodec && f.vcodec !== 'none');
    job.withAudio = formats.some((f) => f.acodec && f.acodec !== 'none');
    const known = new Set(formats.map((f) => f.format_id));
    if (job.quality.formatId && !known.has(job.quality.formatId)) job.quality.formatId = null;
    if (job.quality.audioFormatId && !known.has(job.quality.audioFormatId)) job.quality.audioFormatId = null;
  }

  const args = downloadArgs(job);
  debug('download', args.join(' '));

  const result = await run(args, {
    signal,
    onLine: (line) => {
      const event = progress(line);
      if (event) applyProgress(job, event);
    },
  });

  if (result.killed || signal.aborted) {
    await removeDir(job.dir);
    job.status = 'canceled';
    job.stage = 'Cancelled';
    return;
  }

  const file = await output(job.dir);
  if (!file || (result.code !== 0 && !/subtitle|thumbnail|cover art/i.test(result.stderr))) throw new EngineError(explain(result.stderr || result.stdout), 502);
  if (result.code !== 0) {
    job.warning = sidecarWarning(result.stderr);
    log('job', job.id, 'finished with a warning:', job.warning);
  }

  job.file = {
    name: `${safeName(job.title || 'video')}.${file.ext}`,
    size: file.size,
    ext: file.ext,
    mime: mimeFor(file.ext),
    path: file.path,
  };
  job.status = 'completed';
  job.stage = 'Ready';
  job.progress.percent = 100;
  job.progress.downloadedBytes = file.size;
  job.progress.totalBytes = file.size;
  job.progress.speed = null;
  job.progress.eta = null;
  job.finishedAt = Date.now();
}

async function streamJob(job) {
  const info = await probe(job.url);
  const picked = direct(info, job.quality);
  if (!picked) return null;

  job.streamInfo = picked;
  job.status = 'completed';
  job.stage = 'Ready to save';
  job.file = {
    name: `${safeName(job.title || 'video')}.${picked.ext}`,
    size: picked.filesize ?? null,
    ext: picked.ext,
    mime: mimeFor(picked.ext),
  };
  job.progress.totalBytes = picked.filesize ?? null;
  job.finishedAt = Date.now();
  return picked;
}

async function execute(job) {
  const controller = new AbortController();
  running.set(job.id, controller);
  job.status = 'starting';
  job.stage = 'Starting engine';
  emit(job, true);

  try {
    if (job.mode === 'stream') {
      const picked = await streamJob(job);
      if (controller.signal.aborted) { job.status = 'canceled'; job.stage = 'Cancelled'; return; }
      if (!picked) {
        job.mode = 'process';
        job.warning = 'No ready-made file existed at that quality, so it was merged with ffmpeg instead.';
        job.status = 'starting';
        job.stage = 'Switching to a merged download';
        emit(job, true);
        await processJob(job, controller.signal);
      }
    } else {
      await processJob(job, controller.signal);
    }
  } catch (error) {
    if (job.status !== 'canceled') {
      job.status = 'failed';
      job.stage = 'Failed';
      job.error = error.message || 'Unknown error';
      job.finishedAt = Date.now();
      log('job failed', job.id, job.error);
    }
    if (job.ownsDir) await removeDir(job.dir);
  } finally {
    running.delete(job.id);
    active = Math.max(0, active - 1);
    emit(job, true);
    pump();
  }
}

function pump() {
  while (active < config.concurrency && queue.length) {
    const id = queue.shift();
    const job = jobs.get(id);
    if (!job || job.status !== 'queued') continue;
    active += 1;
    execute(job);
  }
}

export function create({ session, url, quality, options, mode, meta }) {
  if (busy(session) >= config.sessionLimit) {
    throw new EngineError(`You already have ${config.sessionLimit} downloads in flight. Let some finish first.`, 429);
  }
  const job = make({ session, url, quality, options, mode, meta });
  jobs.set(job.id, job);
  queue.push(job.id);
  emit(job, true);
  pump();
  return job;
}

export function cancel(id) {
  const job = jobs.get(id);
  if (!job || !LIVE.has(job.status)) return false;
  running.get(id)?.abort();
  const at = queue.indexOf(id);
  if (at !== -1) queue.splice(at, 1);
  job.status = 'canceled';
  job.stage = 'Cancelled';
  job.finishedAt = Date.now();
  job.progress.speed = null;
  job.progress.eta = null;
  emit(job, true);
  return true;
}

export async function remove(id) {
  const job = jobs.get(id);
  if (!job) return false;
  cancel(id);
  if (job.ownsDir) await removeDir(job.dir);
  lastEmit.delete(id);
  jobs.delete(id);
  publish(job.session, 'removed', { id });
  return true;
}

export async function clear(session, onlyFinished = true) {
  const targets = list(session).filter((job) => !onlyFinished || !LIVE.has(job.status));
  await Promise.all(targets.map((job) => remove(job.id)));
  return targets.length;
}

setInterval(() => {
  const now = Date.now();
  for (const [id, job] of jobs) {
    if (LIVE.has(job.status)) continue;
    if (now - (job.finishedAt || job.createdAt) < config.jobTtl) continue;
    remove(id);
  }
}, 60000).unref();

export async function usage() {
  let total = 0;
  let count = 0;
  try {
    for (const entry of await fsp.readdir(config.jobsDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      count += 1;
      for (const name of await fsp.readdir(path.join(config.jobsDir, entry.name)).catch(() => [])) {
        const stat = await fsp.stat(path.join(config.jobsDir, entry.name, name)).catch(() => null);
        if (stat?.isFile()) total += stat.size;
      }
    }
  } catch {
    return { total: 0, count: 0 };
  }
  return { total, count };
}

export function runtime() {
  return {
    active,
    queued: queue.length,
    total: jobs.size,
    clients: [...listeners.values()].reduce((sum, set) => sum + set.size, 0),
    concurrency: config.concurrency,
    uptime: Math.round(process.uptime()),
  };
}

export async function shutdown() {
  for (const id of [...running.keys()]) cancel(id);
  await removeDir(config.jobsDir);
}
