export class Future {
  constructor(max, ttlMs) {
    this.max = max;
    this.ttlMs = ttlMs;
    this.entries = new Map();
    this.hits = 0;
    this.misses = 0;
  }

  get(key) {
    const entry = this.entries.get(key);
    if (!entry) {
      this.misses += 1;
      return undefined;
    }
    if (entry.expires <= Date.now()) {
      this.entries.delete(key);
      this.misses += 1;
      return undefined;
    }
    this.entries.delete(key);
    this.entries.set(key, entry);
    this.hits += 1;
    return entry.value;
  }

  set(key, value, ttlMs = this.ttlMs) {
    this.entries.delete(key);
    this.entries.set(key, { value, expires: Date.now() + ttlMs });
    while (this.entries.size > this.max) this.entries.delete(this.entries.keys().next().value);
    return value;
  }

  drop(key) {
    return this.entries.delete(key);
  }

  clear() {
    this.entries.clear();
  }

  stats() {
    const total = this.hits + this.misses;
    return {
      size: this.entries.size,
      hits: this.hits,
      misses: this.misses,
      hitRate: total ? Number((this.hits / total).toFixed(3)) : 0,
    };
  }
}

export class Dedupe {
  constructor() {
    this.pending = new Map();
  }

  run(key, task) {
    const running = this.pending.get(key);
    if (running) return running;
    const promise = (async () => {
      try {
        return await task();
      } finally {
        this.pending.delete(key);
      }
    })();
    this.pending.set(key, promise);
    return promise;
  }

  get size() {
    return this.pending.size;
  }
}
