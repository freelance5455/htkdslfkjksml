import { execFile, spawn } from 'node:child_process';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { config, debug } from './config.js';
import { Future, Dedupe } from './cache.js';

class Lines {
  constructor(onLine, maxLine = 64 * 1024 * 1024) {
    this.onLine = onLine;
    this.maxLine = maxLine;
    this.buffer = '';
    this.overflowed = false;
  }

  push(text) {
    if (this.overflowed) return;
    this.buffer += text;
    let at;
    while ((at = this.buffer.indexOf('\n')) !== -1) {
      const line = this.buffer.slice(0, at).replace(/\r$/, '');
      this.buffer = this.buffer.slice(at + 1);
      if (line) this.onLine(line);
    }
    if (this.buffer.length > this.maxLine) {
      this.overflowed = true;
      this.buffer = '';
    }
  }

  flush() {
    if (this.overflowed || !this.buffer) return;
    this.onLine(this.buffer);
    this.buffer = '';
  }
}

export function run(args, { onLine, signal, timeoutMs, maxBuffer = 256 * 1024 * 1024 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(config.engine, args, {
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
      env: { ...process.env, PYTHONUNBUFFERED: '1' },
    });

    let stdout = '';
    let stderr = '';
    let killed = false;
    let overflowed = false;
    let settled = false;

    const out = new Lines((line) => {
      if (!overflowed) {
        stdout += `${line}\n`;
        if (stdout.length > maxBuffer) {
          overflowed = true;
          stdout = '';
        }
      }
      onLine?.(line);
    });
    const err = new Lines(() => {});

    const timer = timeoutMs
      ? setTimeout(() => {
          killed = true;
          child.kill('SIGKILL');
        }, timeoutMs)
      : null;

    const abort = () => {
      killed = true;
      child.kill('SIGTERM');
      setTimeout(() => child.kill('SIGKILL'), 4000).unref?.();
    };
    if (signal) {
      if (signal.aborted) abort();
      else signal.addEventListener('abort', abort, { once: true });
    }

    child.stdout.on('data', (chunk) => out.push(chunk.toString('utf8')));
    child.stderr.on('data', (chunk) => {
      const text = chunk.toString('utf8');
      if (stderr.length < 65536) stderr += text;
      err.push(text);
    });

    const done = () => {
      if (timer) clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', abort);
    };

    child.on('error', (error) => {
      if (settled) return;
      settled = true;
      done();
      if (error.code === 'ENOENT') {
        const missing = new Error(`Engine "${config.engine}" not found. Run: npm run setup`);
        missing.status = 503;
        missing.code = 'NO_ENGINE';
        return reject(missing);
      }
      reject(error);
    });

    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      done();
      out.flush();
      resolve({ code: code ?? 0, stdout, stderr, killed });
    });
  });
}

const exec = (bin, args, timeout = 12000) =>
  new Promise((resolve) => {
    execFile(bin, args, { timeout, windowsHide: true }, (error, stdout, stderr) =>
      resolve({ ok: !error, out: String(stdout || '').trim(), err: String(stderr || '').trim().split('\n').pop() || '' }));
  });

function baseArgs() {
  const args = ['--no-warnings', '--no-colors', '--ignore-config'];
  if (config.cookies && fs.existsSync(config.cookies)) args.push('--cookies', config.cookies);
  if (config.proxy) args.push('--proxy', config.proxy);
  if (config.ffmpegLocation) args.push('--ffmpeg-location', config.ffmpegLocation);
  args.push(...config.extraArgs);
  return args;
}

let statusCache = null;

export async function status(force = false) {
  if (statusCache && !force) return statusCache;
  const [engine, ffmpeg] = await Promise.all([
    exec(config.engine, ['--version']),
    exec(config.ffmpegLocation && fs.existsSync(config.ffmpegLocation) && fs.statSync(config.ffmpegLocation).isDirectory() ? path.join(config.ffmpegLocation, process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg') : config.ffmpegLocation || 'ffmpeg', ['-version']),
  ]);
  statusCache = {
    engine: { ok: engine.ok, version: engine.ok ? engine.out.split('\n')[0] : null, error: engine.ok ? null : engine.err },
    ffmpeg: {
      ok: ffmpeg.ok,
      version: ffmpeg.ok ? ffmpeg.out.match(/ffmpeg version (\S+)/)?.[1] ?? 'unknown' : null,
      error: ffmpeg.ok ? null : 'not found',
    },
    limits: {
      concurrency: config.concurrency,
      playlistLimit: config.playlistLimit,
      maxDuration: config.maxDuration,
      allowedHosts: config.allowedHosts,
    },
  };
  return statusCache;
}

export class EngineError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.status = statusCode;
  }
}

const FRIENDLY = [
  [/Sign in to confirm|not a bot|cookies/i, 'This site wants a signed-in session. Add a cookies file to .env to unlock it.'],
  [/age.?restricted|confirm your age|inappropriate for some users/i, 'That video is age-restricted. Add a cookies file to unlock it.'],
  [/private video|this video is private/i, 'That video is private.'],
  [/video (?:is )?unavailable|removed by the uploader|no longer available/i, 'That video is unavailable — it may have been deleted or made private.'],
  [/copyright/i, 'That video was removed after a copyright claim.'],
  [/members-only|Join this channel|paid|subscri/i, 'That content needs a paid membership.'],
  [/geo.?restrict|not available in your country|blocked in your/i, 'That video is region-locked and cannot be fetched from this server.'],
  [/Unsupported URL|no suitable extractor/i, 'That site is not supported.'],
  [/is not a valid URL|Invalid URL/i, 'That link does not look valid.'],
  [/Unable to download webpage|Failed to resolve|getaddrinfo|Temporary failure in name resolution/i, 'Could not reach that site. Check the link and your connection.'],
  [/Could not copy|Permission denied|No space left/i, 'The server ran out of disk space or permissions.'],
  [/HTTP Error 429|Too Many Requests/i, 'The site is rate-limiting this server. Wait a minute and try again.'],
  [/HTTP Error 40[13]|Forbidden/i, 'The site refused the request. It may be blocking this server or region.'],
];

export const stripPrefix = (line) =>
  String(line || '')
    .replace(/^\[[^\]]{1,40}\]\s*/, '')
    .replace(/^[A-Za-z0-9_-]{4,20}:\s+(?=[A-Z"'])/, '')
    .trim();

export function explain(stderr) {
  const text = String(stderr || '').trim();
  if (!text) return 'The download engine failed for an unknown reason.';
  const known = FRIENDLY.find(([re]) => re.test(text));
  if (known) return known[1];
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const errors = lines.filter((l) => l.startsWith('ERROR:'));
  const source = (errors.length ? errors : lines).map((l) => l.replace(/^ERROR:\s*/, ''));
  const last = stripPrefix(source[source.length - 1] || '');
  if (!last) return 'The download engine failed for an unknown reason.';
  return last.length > 240 ? `${last.slice(0, 237)}…` : last;
}

const infoCache = new Future(config.cacheSize, config.cacheTtl);
const dedupe = new Dedupe();

export const cacheStats = () => ({ info: infoCache.stats(), pending: dedupe.size });

export async function probe(url, { signal, fresh = false } = {}) {
  if (fresh) infoCache.drop(url);
  else {
    const hit = infoCache.get(url);
    if (hit) return hit;
  }

  return dedupe.run(url, async () => {
    const args = [
      ...baseArgs(),
      '--dump-single-json', '--flat-playlist', '--skip-download', '--no-progress',
      '--socket-timeout', '20', '--retries', '3', '--extractor-retries', '2',
      url,
    ];
    debug('probe', args.join(' '));
    const { code, stdout, stderr, killed } = await run(args, { signal, timeoutMs: config.probeTimeout });

    if (killed) throw new EngineError(signal?.aborted ? 'Lookup cancelled.' : 'The lookup timed out.', signal?.aborted ? 499 : 504);
    if (code !== 0 || !stdout.trim()) throw new EngineError(explain(stderr), 422);

    let info;
    try {
      info = JSON.parse(stdout);
    } catch {
      throw new EngineError('The site returned something we could not read.', 502);
    }

    trim(info);
    infoCache.set(url, info, config.cacheTtl);
    return info;
  });
}

function trim(info) {
  delete info.heatmap;
  delete info.requested_formats;
  if (Array.isArray(info.chapters)) info.chapters = info.chapters.slice(0, 200);
  if (Array.isArray(info.formats)) {
    info.formats = info.formats.map((f) => ({
      format_id: f.format_id, ext: f.ext, vcodec: f.vcodec, acodec: f.acodec,
      height: f.height, width: f.width, fps: f.fps, abr: f.abr, tbr: f.tbr,
      asr: f.asr, audio_channels: f.audio_channels, filesize: f.filesize,
      filesize_approx: f.filesize_approx, format_note: f.format_note, protocol: f.protocol,
      url: f.url, http_headers: f.http_headers, language: f.language,
    }));
  }
  if (Array.isArray(info.entries)) info.entries = info.entries.slice(0, config.playlistLimit);
  return info;
}

const hasVideo = (f) => Boolean(f.vcodec) && f.vcodec !== 'none';
const hasAudio = (f) => Boolean(f.acodec) && f.acodec !== 'none';
const muxed = (f) => hasVideo(f) && hasAudio(f);
const opaque = (f) => !f.vcodec && !f.acodec;
const whole = (f) => muxed(f) || opaque(f);
const sizeOf = (f) => f.filesize ?? f.filesize_approx ?? null;

const containerRank = (f) => (f.ext === 'mp4' ? 0 : f.ext === 'webm' ? 1 : 2);
const codecRank = (f) => {
  const v = String(f.vcodec || '');
  if (v.startsWith('avc1') || v.startsWith('h264')) return 0;
  if (v.startsWith('vp9') || v.startsWith('vp09')) return 2;
  if (v.startsWith('av01')) return 3;
  return 1;
};

function best(list) {
  return list.slice().sort((a, b) => {
    if (containerRank(a) !== containerRank(b)) return containerRank(a) - containerRank(b);
    if (whole(a) !== whole(b)) return whole(a) ? -1 : 1;
    if (codecRank(a) !== codecRank(b)) return codecRank(a) - codecRank(b);
    const sa = sizeOf(a) ?? (a.tbr ?? 0) * 1000;
    const sb = sizeOf(b) ?? (b.tbr ?? 0) * 1000;
    return sb - sa;
  })[0];
}

const AUDIO_ORDER = { mp4: ['m4a', 'mp4', 'aac', 'mp3'], webm: ['webm', 'ogg', 'opus'] };

function tiers(formats = []) {
  const usable = formats.filter((f) => f.url);
  const audioOnly = usable.filter((f) => hasAudio(f) && !hasVideo(f));
  const pickAudio = (videoExt) => {
    for (const ext of AUDIO_ORDER[videoExt] || []) {
      const matches = audioOnly.filter((f) => f.ext === ext);
      if (matches.length) return best(matches);
    }
    return best(audioOnly) || null;
  };

  const byHeight = new Map();
  for (const f of usable) {
    if (!hasVideo(f) || !f.height) continue;
    if (!byHeight.has(f.height)) byHeight.set(f.height, []);
    byHeight.get(f.height).push(f);
  }

  const video = [...byHeight.entries()]
    .sort((a, b) => b[0] - a[0])
    .map(([height, group]) => {
      const chosen = best(group);
      const streaming = best(group.filter(whole)) || null;
      const audio = muxed(chosen) ? null : pickAudio(chosen.ext);
      const fps = Math.max(...group.map((f) => f.fps || 0));
      const base = sizeOf(chosen);
      const audioSize = audio ? sizeOf(audio) : null;
      const total = base && audioSize && !muxed(chosen) ? base + audioSize : base;
      return {
        kind: 'video',
        height,
        label: `${height}p${fps >= 50 ? '60' : ''}`,
        fps: fps || null,
        ext: chosen.ext,
        vcodec: (chosen.vcodec || '').split('.')[0],
        acodec: audio ? (audio.acodec || '').split('.')[0] : null,
        needsMerge: !muxed(chosen) && Boolean(audio),
        stream: streaming ? { formatId: streaming.format_id, ext: streaming.ext, filesize: sizeOf(streaming) } : null,
        filesize: total,
        formatId: chosen.format_id,
        audioFormatId: audio?.format_id ?? null,
      };
    });

  if (!video.length && !audioOnly.length) {
    const single = best(usable.filter(whole)) || best(usable);
    if (single) {
      video.push({
        kind: 'video', height: null, label: 'Original', fps: null,
        ext: single.ext || 'mp4',
        vcodec: (single.vcodec || 'unknown').split('.')[0],
        acodec: (single.acodec || 'unknown').split('.')[0],
        needsMerge: false,
        stream: { formatId: single.format_id, ext: single.ext, filesize: sizeOf(single) },
        filesize: sizeOf(single),
        formatId: single.format_id,
        audioFormatId: null,
      });
    }
  }

  const buckets = new Map();
  for (const f of audioOnly) {
    const abr = Math.round(f.abr || f.tbr || 0);
    if (!abr) continue;
    const bucket = abr >= 200 ? 256 : abr >= 150 ? 160 : abr >= 110 ? 128 : abr >= 80 ? 96 : 64;
    if (!buckets.has(bucket)) buckets.set(bucket, []);
    buckets.get(bucket).push(f);
  }

  const audio = [...buckets.entries()]
    .sort((a, b) => b[0] - a[0])
    .map(([bucket, group]) => {
      const chosen = best(group);
      return {
        kind: 'audio', abr: bucket, label: `${bucket} kbps`, ext: chosen.ext,
        acodec: (chosen.acodec || '').split('.')[0], channels: chosen.audio_channels || null,
        filesize: sizeOf(chosen), formatId: chosen.format_id,
        stream: { formatId: chosen.format_id, ext: chosen.ext, filesize: sizeOf(chosen) },
      };
    });

  return { video, audio };
}

function thumbnail(info) {
  const list = (info.thumbnails || []).filter((t) => t.url);
  if (!list.length) return info.thumbnail || null;
  const sorted = list.slice().sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0));
  return (sorted.find((t) => (t.width || 0) <= 1280) || sorted[0]).url;
}

export function present(info, sourceUrl) {
  const base = {
    sourceUrl,
    extractor: info.extractor_key || info.extractor || null,
    extractorName: info.extractor || null,
    webpageUrl: info.webpage_url || sourceUrl,
  };

  const isPlaylist = info._type === 'playlist' || (Array.isArray(info.entries) && info.entries.length > 1 && !info.formats);

  if (isPlaylist) {
    const entries = (info.entries || [])
      .filter(Boolean)
      .map((entry) => ({
        id: entry.id,
        title: entry.title || 'Untitled',
        url: entry.url || entry.webpage_url,
        duration: entry.duration ?? null,
        thumbnail: entry.thumbnail || null,
        uploader: entry.uploader || entry.channel || null,
      }))
      .filter((entry) => entry.url);

    return {
      ...base,
      type: 'playlist',
      id: info.id,
      title: info.title || 'Playlist',
      uploader: info.uploader || info.channel || null,
      thumbnail: thumbnail(info) || entries[0]?.thumbnail || null,
      entryCount: info.playlist_count ?? entries.length,
      truncated: (info.playlist_count ?? entries.length) > entries.length,
      entries,
    };
  }

  const list = tiers(info.formats || []);
  return {
    ...base,
    type: 'video',
    id: info.id,
    title: info.title || 'Untitled',
    uploader: info.uploader || info.channel || null,
    uploaderUrl: info.uploader_url || info.channel_url || null,
    duration: info.duration ?? null,
    viewCount: info.view_count ?? null,
    likeCount: info.like_count ?? null,
    uploadDate: info.upload_date ?? null,
    description: (info.description || '').slice(0, 600) || null,
    thumbnail: thumbnail(info),
    isLive: Boolean(info.is_live),
    ageLimit: info.age_limit ?? null,
    formats: list,
    subtitles: Object.keys(info.subtitles || {}).slice(0, 40),
    autoCaptions: Object.keys(info.automatic_captions || {}).slice(0, 40),
    hasChapters: Array.isArray(info.chapters) && info.chapters.length > 0,
  };
}

const MIN_RATIO = 0.7;

export function direct(info, quality = {}) {
  const formats = (info.formats || []).filter((f) => f.url);
  if (!formats.length) return null;

  const wrap = (f) => ({
    url: f.url,
    headers: f.http_headers || info.http_headers || {},
    ext: f.ext,
    filesize: sizeOf(f),
    formatId: f.format_id,
    height: f.height ?? null,
  });

  if (quality.kind === 'audio') {
    const audioOnly = formats.filter((f) => hasAudio(f) && !hasVideo(f));
    if (!audioOnly.length) return null;
    const want = quality.abr || Infinity;
    const ceiling = want === Infinity ? Infinity : want * 1.1 + 1;
    const within = audioOnly.filter((f) => (f.abr || 0) <= ceiling);
    const pool = within.length ? within : audioOnly;
    const chosen = pool.slice().sort((a, b) => {
      const da = Math.abs((a.abr || 0) - want);
      const db = Math.abs((b.abr || 0) - want);
      if (da !== db) return da - db;
      if (containerRank(a) !== containerRank(b)) return containerRank(a) - containerRank(b);
      return (b.abr || 0) - (a.abr || 0);
    })[0];
    return chosen ? wrap(chosen) : null;
  }

  const requested = quality.height || null;
  const wanted = requested || Infinity;
  const fps = quality.fps || 0;
  let candidates = formats.filter((f) => muxed(f) && (f.height || 0) <= wanted && (f.fps || 0) >= fps);
  if (!candidates.length && !formats.some(hasVideo)) candidates = formats.filter(opaque);
  if (!candidates.length) return null;

  if (requested && candidates[0]?.height != null) {
    const top = candidates.reduce((max, f) => Math.max(max, f.height || 0), 0);
    if (top < requested * MIN_RATIO) return null;
  }

  const chosen = candidates.slice().sort((a, b) => {
    if ((b.height || 0) !== (a.height || 0)) return (b.height || 0) - (a.height || 0);
    if ((b.fps || 0) !== (a.fps || 0)) return (b.fps || 0) - (a.fps || 0);
    if (containerRank(a) !== containerRank(b)) return containerRank(a) - containerRank(b);
    return (b.tbr || 0) - (a.tbr || 0);
  })[0];

  return wrap(chosen);
}

export function selector(quality = {}, { withVideo = true, withAudio = true } = {}) {
  const pin = (value) => (/^[\w.+-]{1,64}$/.test(String(value || '')) ? String(value) : null);

  if (quality.kind === 'audio') {
    const id = pin(quality.formatId);
    if (id) return `${id}/ba/b`;
    const ext = quality.container && quality.container !== 'best' ? String(quality.container) : null;
    return ext ? `ba[ext=${ext}]/ba[ext=${ext}][abr<=400]/ba/b` : 'ba/b';
  }

  const videoId = pin(quality.formatId);
  if (videoId) {
    const audioId = pin(quality.audioFormatId);
    if (!withVideo) return audioId ? `${videoId}+${audioId}/${videoId}/b` : `${videoId}/b`;
    if (audioId && withAudio) return `${videoId}+${audioId}`;
    if (audioId && !withAudio) return videoId;
    return withAudio ? `${videoId}+ba/${videoId}` : videoId;
  }

  const height = Number.isFinite(quality.height) && quality.height > 0 ? Math.round(quality.height) : null;
  const fps = Number.isFinite(quality.fps) && quality.fps >= 24 ? Math.round(quality.fps) : null;
  const ext = /^[a-z0-9]{2,5}$/.test(quality.container || '') ? quality.container : null;
  const h = height ? `[height<=${height}]` : '';
  const f = fps ? `[fps>=${Math.max(24, fps - 5)}]` : '';
  const c = ext ? `[ext=${ext}]` : '';

  if (!height && !ext) return 'bv*+ba/b';
  const chain = [];
  if (height) chain.push(`bv*${h}${f}${c}+ba[ext=m4a]`, `bv*${h}${f}${c}+ba`);
  chain.push(`b${h}${f}${c}`, `b${h}${f}`);
  if (height) chain.push(`bv*${h}${f}+ba/b${h}${f}`, `bv*${h}+ba`);
  chain.push('bv*+ba/b');
  return chain.join('/');
}

export function section(value) {
  if (typeof value !== 'string') return null;
  const match = value.trim().match(/^(\d{1,2}(?::\d{1,2}){0,2})\s*-\s*(\d{1,2}(?::\d{1,2}){0,2})$/);
  if (!match) return null;
  const seconds = (text) => text.split(':').map(Number).reduce((acc, part) => acc * 60 + part, 0);
  const from = seconds(match[1]);
  const to = seconds(match[2]);
  if (!(to > from)) return null;
  const pad = (total) =>
    [Math.floor(total / 3600), Math.floor((total % 3600) / 60), Math.floor(total % 60)]
      .map((n) => String(n).padStart(2, '0'))
      .join(':');
  return `*${pad(from)}-${pad(to)}`;
}

export function downloadArgs(job) {
  const { quality = {}, options = {} } = job;
  const args = [...baseArgs(), '--newline', '--no-playlist', '--progress'];
  args.push(
    '--progress-template',
    'download:PROG|%(progress.status)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|' +
      '%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s|' +
      '%(progress.fragment_index)s|%(progress.fragment_count)s',
  );
  args.push('--progress-template', 'postprocess:POST|%(progress.status)s|%(progress.postprocessor)s');
  args.push('--retries', '10', '--fragment-retries', '10', '--socket-timeout', '20', '--concurrent-fragments', '4');

  const audioOnly = options.audioOnly === true || quality.kind === 'audio';
  args.push('-f', selector(quality, { withVideo: job.withVideo !== false, withAudio: job.withAudio !== false }));

  if (audioOnly) {
    const container = quality.container || 'mp3';
    if (container !== 'best') {
      args.push('-x', '--audio-format', container === 'm4a' ? 'm4a' : container);
      if (container === 'mp3') {
        args.push('--audio-quality', quality.abr && quality.abr <= 128 ? '5' : quality.abr && quality.abr <= 192 ? '2' : '0');
      }
    }
  } else {
    const container = ['mp4', 'mkv', 'webm'].includes(quality.container) ? quality.container : 'mp4';
    args.push('--merge-output-format', container);
    if (quality.container) args.push('--remux-video', container);
  }

  if (options.subtitles) {
    args.push('--write-subs', '--write-auto-subs', '--sub-langs', options.subtitleLangs || 'en,en-orig',
      '--embed-subs', '--convert-subs', 'srt', '--sleep-requests', '0.4');
  }
  if (options.embedThumbnail) args.push('--embed-thumbnail');
  if (options.embedMetadata) args.push('--embed-metadata', '--embed-chapters');
  if (options.sponsorblock) {
    args.push('--sponsorblock-remove', options.sponsorblockCategories || 'sponsor,selfpromo,interaction');
  }

  const range = section(options.section);
  if (range) args.push('--download-sections', range, '--force-keyframes-at-cuts');

  if (!job.outputTemplate) throw new EngineError('Download output path is missing.');
  args.push('--no-mtime', '--trim-filenames', '120', '-o', job.outputTemplate, '--', job.url);
  return args;
}

const numOrNull = (value) => {
  const text = String(value ?? '').trim();
  if (!text || text === 'NA' || text === 'None') return null;
  const n = Number.parseFloat(text);
  return Number.isFinite(n) ? Math.round(n) : null;
};

export function progress(line) {
  if (line.startsWith('PROG|')) {
    const [, state, got, total, estimate, speed, eta, index, count] = line.split('|');
    const done = numOrNull(got);
    const all = numOrNull(total) ?? numOrNull(estimate);
    return {
      kind: 'download',
      state,
      done,
      all,
      percent: done != null && all ? Math.min(100, (done / all) * 100) : null,
      speed: numOrNull(speed),
      eta: numOrNull(eta),
      fragment: numOrNull(index),
      fragments: numOrNull(count),
    };
  }
  if (line.startsWith('POST|')) {
    const [, state, tool] = line.split('|');
    return { kind: 'post', state, tool };
  }
  return null;
}

const JUNK = /\.(part|ytdl|temp|tmp|jpg|jpeg|png|webp|ass|vtt|srt|description|info\.json)$/i;

export async function output(dir) {
  let names;
  try {
    names = await fsp.readdir(dir);
  } catch {
    return null;
  }

  const files = [];
  for (const name of names) {
    if (JUNK.test(name) || name.endsWith('.info.json') || /\.f[\w-]+\./.test(name)) continue;
    const full = path.join(dir, name);
    try {
      const stat = await fsp.stat(full);
      if (!stat.isFile() || !stat.size) continue;
      files.push({ path: full, name, size: stat.size, ext: path.extname(name).slice(1).toLowerCase() || 'bin' });
    } catch {
      continue;
    }
  }
  return files.sort((a, b) => b.size - a.size)[0] || null;
}

export const removeDir = (dir) => fsp.rm(dir, { recursive: true, force: true }).catch(() => {});
