import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const envFile = path.join(ROOT, '.env');
if (fs.existsSync(envFile)) {
  for (const raw of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const at = line.indexOf('=');
    if (at < 1) continue;
    const key = line.slice(0, at).trim();
    let value = line.slice(at + 1).trim();
    if (value.length > 1 && (value.startsWith('"') || value.startsWith("'"))) value = value.slice(1, -1);
    if (!(key in process.env)) process.env[key] = value;
  }
}

const int = (value, fallback) => {
  const n = Number.parseInt(value ?? '', 10);
  return Number.isFinite(n) ? n : fallback;
};
const flag = (value, fallback = false) =>
  value === undefined || value === '' ? fallback : /^(1|true|yes|on)$/i.test(String(value));
const csv = (value) =>
  String(value ?? '')
    .split(',')
    .map((entry) => entry.trim().toLowerCase())
    .filter(Boolean);

export const config = {
  root: ROOT,
  publicDir: path.join(ROOT, 'public'),
  port: int(process.env.PORT, 5173),
  host: process.env.HOST || '0.0.0.0',
  engine: process.env.YTDLP_BIN || 'yt-dlp',
  ffmpegLocation: process.env.FFMPEG_LOCATION || '',
  cors: csv(process.env.CORS_ORIGIN),
  cookies: process.env.COOKIES_FILE || '',
  proxy: process.env.PROXY || '',
  extraArgs:
    (process.env.YTDLP_EXTRA_ARGS || '').match(/(?:[^\s"]+|"[^"]*")+/g)?.map((a) => a.replace(/^"|"$/g, '')) || [],
  concurrency: Math.max(1, Math.min(16, int(process.env.MAX_CONCURRENT, 3))),
  cacheTtl: Math.max(0, int(process.env.META_CACHE_TTL, 900)) * 1000,
  cacheSize: Math.max(10, int(process.env.META_CACHE_SIZE, 250)),
  probeTimeout: Math.max(5, int(process.env.PROBE_TIMEOUT, 45)) * 1000,
  jobTtl: Math.max(1, int(process.env.JOB_TTL_MINUTES, 45)) * 60000,
  maxTemp: Math.max(256, int(process.env.MAX_TEMP_MB, 4096)) * 1048576,
  sessionLimit: Math.max(1, int(process.env.MAX_JOBS_PER_SESSION, 25)),
  playlistLimit: Math.max(1, int(process.env.MAX_PLAYLIST_ITEMS, 200)),
  rateLimit: Math.max(0, int(process.env.RATE_LIMIT_PER_MIN, 120)),
  allowedHosts: csv(process.env.ALLOWED_HOSTS),
  maxDuration: Math.max(0, int(process.env.MAX_DURATION_MINUTES, 0)) * 60,
  verbose: flag(process.env.VERBOSE),
  tmpDir: process.env.VS_TMP_DIR ? path.resolve(process.env.VS_TMP_DIR) : path.join(os.tmpdir(), 'vidsnap'),
};

config.jobsDir = path.join(config.tmpDir, 'jobs');

export const log = (...args) => console.log('[vidsnap]', ...args);
export const debug = (...args) => {
  if (config.verbose) console.log('[vidsnap:debug]', ...args);
};
