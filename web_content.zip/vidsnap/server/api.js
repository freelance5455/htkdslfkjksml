import express from 'express';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { config, log } from './config.js';
import { cacheStats, probe, present, direct, status, EngineError } from './engine.js';
import { disposition, parseRange } from './http.js';
import * as jobs from './jobs.js';
import { pipe } from './transfer.js';
import { BadRequest, checkUrl, featured, rateLimit, SITES, validId } from './security.js';

export const router = express.Router();

const wrap = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

function session(req) {
  const id = req.get('x-session-id') || req.query.session;
  if (!validId(id)) throw new BadRequest('Missing or malformed session id.');
  return id;
}

function engineReady(info) {
  if (!info.engine.ok) throw new EngineError('The yt-dlp engine is not installed. Run: npm run setup', 503);
}

export async function health(req, res) {
  const info = await status(req.query.refresh === '1');
  res.json({
    ok: info.engine.ok,
    engine: info,
    runtime: jobs.runtime(),
    cache: cacheStats(),
    disk: await jobs.usage(),
    sites: SITES,
    session: validId(req.query.session) ? req.query.session : null,
  });
}

export async function info(req, res) {
  engineReady(await status());
  const { url, hostname } = await checkUrl(req.query.url);
  const started = Date.now();
  const raw = await probe(url.toString(), { fresh: req.query.fresh === '1' });
  const data = present(raw, url.toString());

  if (config.maxDuration && data.type === 'video' && data.duration > config.maxDuration) {
    throw new BadRequest(`That video is longer than the ${Math.round(config.maxDuration / 60)} minute limit.`, 413);
  }

  res.json({ ...data, hostname, featured: featured(hostname), probeMs: Date.now() - started });
}

function cleanQuality(input) {
  const source = input && typeof input === 'object' ? input : {};
  const kind = source.kind === 'audio' ? 'audio' : 'video';
  const number = (value, min, max) => {
    const n = Number.parseInt(value, 10);
    return Number.isFinite(n) && n >= min && n <= max ? n : null;
  };
  const id = (value) => (/^[\w.+-]{1,64}$/.test(String(value || '')) ? String(value) : null);
  return {
    kind,
    height: kind === 'video' ? number(source.height, 144, 4320) : null,
    fps: kind === 'video' ? number(source.fps, 0, 240) : null,
    abr: kind === 'audio' ? number(source.abr, 32, 512) : null,
    container: /^[a-z0-9]{2,5}$/.test(String(source.container || '')) ? String(source.container) : null,
    label: typeof source.label === 'string' ? source.label.slice(0, 40) : null,
    formatId: id(source.formatId),
    audioFormatId: id(source.audioFormatId),
  };
}

function cleanOptions(input) {
  const source = input && typeof input === 'object' ? input : {};
  return {
    subtitles: source.subtitles === true,
    subtitleLangs: /^[a-zA-Z0-9.,*_-]{1,60}$/.test(String(source.subtitleLangs || '')) ? source.subtitleLangs : 'en,en-orig',
    embedThumbnail: source.embedThumbnail === true,
    embedMetadata: source.embedMetadata === true,
    sponsorblock: source.sponsorblock === true,
    section: typeof source.section === 'string' && /^\d{1,2}(:\d{1,2}){0,2}\s*-\s*\d{1,2}(:\d{1,2}){0,2}$/.test(source.section.trim())
      ? source.section.trim()
      : null,
  };
}

export async function start(req, res) {
  const sessionId = session(req);
  engineReady(await status());

  const { url, hostname } = await checkUrl(req.body?.url);
  const quality = cleanQuality(req.body?.quality);
  const options = cleanOptions(req.body?.options);
  const mode = req.body?.mode === 'stream' ? 'stream' : 'process';

  if (mode === 'stream' && options.subtitles) throw new BadRequest('Subtitles need a merged download. Turn off instant mode.');

  const raw = await probe(url.toString());
  const meta = {
    title: raw?.title || hostname,
    thumbnail: raw?.thumbnail || null,
    duration: raw?.duration ?? null,
    extractor: raw?.extractor_key || null,
  };

  if (config.maxDuration && meta.duration && meta.duration > config.maxDuration) {
    throw new BadRequest('That video is longer than this server allows.', 413);
  }

  const job = jobs.create({ session: sessionId, url: url.toString(), quality, options, mode, meta });
  res.status(201).json({ job: jobs.publicJob(job) });
}

export function listJobs(req, res) {
  const sessionId = session(req);
  res.json({ jobs: jobs.list(sessionId).map(jobs.publicJob), runtime: jobs.runtime() });
}

export function oneJob(req, res) {
  if (!validId(req.params.id)) throw new BadRequest('Bad job id.');
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'That job no longer exists.' });
  if (job.session !== session(req)) throw new BadRequest('Not authorized for this job.', 403);
  res.json({ job: jobs.publicJob(job) });
}

export function cancelJob(req, res) {
  if (!validId(req.params.id)) throw new BadRequest('Bad job id.');
  const job = jobs.get(req.params.id);
  if (job && job.session !== session(req)) throw new BadRequest('Not authorized for this job.', 403);
  res.json({ ok: jobs.cancel(req.params.id) });
}

export async function deleteJob(req, res) {
  if (!validId(req.params.id)) throw new BadRequest('Bad job id.');
  const job = jobs.get(req.params.id);
  if (job && job.session !== session(req)) throw new BadRequest('Not authorized for this job.', 403);
  res.json({ ok: await jobs.remove(req.params.id) });
}

export async function clearJobs(req, res) {
  const sessionId = session(req);
  res.json({ removed: await jobs.clear(sessionId, req.body?.all !== true) });
}

export function events(req, res) {
  let sessionId;
  try {
    sessionId = session(req);
  } catch {
    return res.status(400).end();
  }
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write('retry: 3000\n\n');
  jobs.subscribe(sessionId, res);
  return undefined;
}

export async function stream(req, res) {
  if (!validId(req.params.id)) throw new BadRequest('Bad job id.');
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'That job no longer exists.' });
  if (job.mode !== 'stream') return res.status(409).json({ error: 'Use /api/file for this job.' });
  if (job.status !== 'completed' || !job.streamInfo) return res.status(409).json({ error: 'This job is not ready yet.' });

  const refresh = async (reason) => {
    log('re-resolving media url for', job.id, `(${reason})`);
    try {
      const raw = await probe(job.url, { fresh: true });
      const picked = direct(raw, job.quality);
      if (!picked) return null;
      job.streamInfo = picked;
      return { url: picked.url, headers: picked.headers };
    } catch (error) {
      log('refresh failed', error.message);
      return null;
    }
  };

  const attach = req.query.download !== '0';
  return pipe({
    req,
    res,
    url: job.streamInfo.url,
    headers: job.streamInfo.headers,
    refresh,
    filename: attach ? job.file?.name : undefined,
    mime: job.file?.mime,
  });
}

export async function file(req, res) {
  if (!validId(req.params.id)) throw new BadRequest('Bad job id.');
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'That job no longer exists.' });
  if (job.mode === 'stream') return res.redirect(302, `/api/stream/${job.id}`);
  if (job.status !== 'completed' || !job.file?.path) return res.status(409).json({ error: 'This file is not ready yet.' });

  const stat = await fsp.stat(job.file.path).catch(() => null);
  if (!stat) {
    job.status = 'failed';
    job.error = 'The temporary file expired. Download it again.';
    return res.status(410).json({ error: job.error });
  }

  res.setHeader('Content-Type', job.file.mime);
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Disposition', disposition(job.file.name, req.query.download === '0'));

  const range = parseRange(req.headers.range, stat.size);
  if (range === 'invalid') {
    res.status(416).setHeader('Content-Range', `bytes */${stat.size}`);
    return res.end();
  }
  if (range) {
    res.status(206);
    res.setHeader('Content-Range', `bytes ${range.start}-${range.end}/${stat.size}`);
    res.setHeader('Content-Length', String(range.end - range.start + 1));
    return fs.createReadStream(job.file.path, { start: range.start, end: range.end }).pipe(res);
  }

  res.setHeader('Content-Length', String(stat.size));
  return fs.createReadStream(job.file.path).pipe(res);
}

export async function thumb(req, res) {
  const target = String(req.query.url || '');
  if (!/^https?:\/\//i.test(target)) return res.status(400).end();
  try {
    let nextUrl = (await checkUrl(target)).url.toString();
    let upstream;
    for (let i = 0; i < 5; i++) {
      upstream = await fetch(nextUrl, { redirect: 'manual', signal: AbortSignal.timeout(15000), headers: { 'user-agent': 'Mozilla/5.0 VidSnap' } });
      if (upstream.status < 300 || upstream.status >= 400) break;
      const redirect = upstream.headers.get('location');
      await upstream.body?.cancel();
      if (!redirect) return res.status(502).end();
      nextUrl = (await checkUrl(new URL(redirect, nextUrl).href)).url.toString();
    }
    if (!/^image\//.test(upstream.headers.get('content-type') || '')) { await upstream.body?.cancel(); return res.status(415).end(); }
    if (!upstream.ok || !upstream.body) return res.status(502).end();
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400, immutable');
    res.setHeader('Cross-Origin-Resource-Policy', config.cors.length ? 'cross-origin' : 'same-origin');
    const { Readable } = await import('node:stream');
    Readable.fromWeb(upstream.body).pipe(res);
    return undefined;
  } catch {
    return res.status(502).end();
  }
}

router.use(rateLimit);
router.get('/health', wrap(health));
router.get('/info', wrap(info));
router.post('/download', wrap(start));
router.get('/jobs', wrap(listJobs));
router.post('/jobs/clear', wrap(clearJobs));
router.get('/jobs/:id', wrap(oneJob));
router.post('/jobs/:id/cancel', wrap(cancelJob));
router.delete('/jobs/:id', wrap(deleteJob));
router.get('/events', events);
router.get('/stream/:id', wrap(stream));
router.get('/file/:id', wrap(file));
router.get('/thumb', wrap(thumb));
