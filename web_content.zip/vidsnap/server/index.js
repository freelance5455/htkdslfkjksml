import compression from 'compression';
import express from 'express';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { config, log } from './config.js';
import { status } from './engine.js';
import * as api from './api.js';
import * as jobs from './jobs.js';
import { BadRequest } from './security.js';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

app.use((req, res, next) => {
  const allowed = config.cors;
  if (!allowed.length) return next();
  const origin = req.get('origin');
  const wildcard = allowed.includes('*');
  if (origin && (wildcard || allowed.includes(origin.toLowerCase()))) {
    res.setHeader('Access-Control-Allow-Origin', wildcard ? '*' : origin);
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length, RateLimit-Limit, RateLimit-Remaining');
    if (!wildcard) res.setHeader('Vary', 'Origin');
  }
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'content-type, x-session-id');
    res.setHeader('Access-Control-Max-Age', '86400');
    return res.status(204).end();
  }
  return next();
});

app.use(
  compression({
    threshold: 1024,
    filter: (req, res) =>
      req.path === '/api/events' || req.path.startsWith('/api/stream/') || req.path.startsWith('/api/file/') ? false : compression.filter(req, res),
  }),
);
app.use(express.json({ limit: '128kb' }));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https:",
      "media-src 'self' blob: https:",
      "connect-src 'self'",
      "font-src 'self' data:",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors *",
    ].join('; '),
  );
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
});

app.use('/api', api.router);

const TTL = { '.html': 0, '.css': 3600, '.js': 3600, '.json': 300, '.png': 604800, '.svg': 604800, '.webmanifest': 3600 };

app.use(
  express.static(config.publicDir, {
    etag: true,
    lastModified: true,
    setHeaders(res, filePath) {
      const ext = path.extname(filePath);
      const ttl = TTL[ext];
      if (!ttl) res.setHeader('Cache-Control', 'no-cache');
      else res.setHeader('Cache-Control', `public, max-age=${ttl}${ttl > 86400 ? ', immutable' : ''}`);
    },
  }),
);

app.get('/offline', (req, res) => res.sendFile(path.join(config.publicDir, 'offline.html')));

const ASSET = /\.(css|js|mjs|json|webmanifest|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|mp4|webm|mkv|mp3|m4a|opus|ogg|wav|flac|xml|txt|map)$/i;

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Unknown endpoint.' });
  const navigates = ['GET', 'HEAD'].includes(req.method) && /text\/html|application\/xhtml\+xml/.test(req.headers.accept || '');
  if (navigates && !ASSET.test(req.path)) return res.sendFile(path.join(config.publicDir, 'index.html'));
  return res.status(404).sendFile(path.join(config.publicDir, '404.html'), (error) => {
    if (error) res.type('text').send('Not found');
  });
});

app.use((error, req, res, next) => {
  void next;
  const statusCode = error.status && Number.isInteger(error.status) ? error.status : 500;
  if (statusCode >= 500) log('error:', error.message);
  if (res.headersSent) return res.end();
  res.status(statusCode).json({ error: error.message || 'Something went wrong.' });
});

async function boot() {
  await fsp.mkdir(config.jobsDir, { recursive: true });
  const info = await status();

  const server = app.listen(config.port, config.host, () => {
    console.log('');
    console.log('  VidSnap');
    console.log('  ────────────────────────────────────────────');
    console.log(`  App        http://localhost:${config.port}`);
    console.log(`  yt-dlp     ${info.engine.ok ? info.engine.version : 'NOT INSTALLED'}`);
    console.log(`  ffmpeg     ${info.ffmpeg.ok ? info.ffmpeg.version : 'not installed'}`);
    console.log(`  Parallel   ${config.concurrency}`);
    console.log('  ────────────────────────────────────────────');
    console.log('');
    if (!info.engine.ok) log('run: npm run setup');
    else if (!info.ffmpeg.ok) log('ffmpeg missing: merges, MP3, subtitles and trimming are unavailable');
  });

  server.headersTimeout = 0;
  server.requestTimeout = 0;
  server.keepAliveTimeout = 65000;

  const stop = async () => {
    log('shutting down');
    await jobs.shutdown();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

boot().catch((error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`\nPort ${config.port} is already in use. Try: PORT=${config.port + 1} npm start\n`);
    process.exit(1);
  }
  if (error instanceof BadRequest) {
    console.error(error.message);
    process.exit(1);
  }
  console.error('Failed to start:', error);
  process.exit(1);
});
