import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { disposition } from './http.js';

export class TransferError extends Error {
  constructor(message, status = 502) {
    super(message);
    this.status = status;
  }
}

export async function pipe({ req, res, url, headers, refresh, filename, mime }) {
  const controller = new AbortController();
  const stop = () => { if (!res.writableFinished) controller.abort(); };
  res.once('close', stop);
  const range = req.headers.range;
  const clean = (source) => {
    const output = { 'accept-encoding': 'identity' };
    for (const [key, value] of Object.entries(source || {})) {
      if (!/^(host|connection|content-length|accept-encoding|transfer-encoding|cookie|authorization)$/i.test(key) && typeof value === 'string') output[key] = value;
    }
    if (range) output.Range = range;
    return output;
  };
  let response;
  let timer = setTimeout(() => controller.abort(), 60000);
  try {
    for (let attempt = 0; attempt < 2; attempt++) {
      response = await fetch(url, { headers: clean(headers), signal: controller.signal });
      if (response.ok || response.status === 206) break;
      await response.body?.cancel();
      if (attempt === 0 && refresh && [401, 403, 404, 410].includes(response.status)) {
        const fresh = await refresh(`HTTP ${response.status}`);
        if (fresh) { url = fresh.url; headers = fresh.headers; continue; }
      }
      throw new TransferError(`Media server returned HTTP ${response.status}. Retry the download.`);
    }
    if (!response.body) throw new TransferError('The media server returned no data.');
    res.status(response.status === 206 ? 206 : 200);
    res.setHeader('Content-Type', mime || response.headers.get('content-type') || 'application/octet-stream');
    for (const name of ['content-length', 'content-range', 'accept-ranges']) {
      const value = response.headers.get(name);
      if (value) res.setHeader(name, value);
    }
    res.setHeader('Cache-Control', 'no-store');
    if (filename) res.setHeader('Content-Disposition', disposition(filename));
    const body = Readable.fromWeb(response.body);
    body.on('data', () => { clearTimeout(timer); timer = setTimeout(() => controller.abort(), 60000); });
    await pipeline(body, res);
  } catch (error) {
    if (res.destroyed) return;
    if (res.headersSent) { res.destroy(error); return; }
    throw error;
  } finally {
    clearTimeout(timer);
    controller.abort();
    res.off('close', stop);
  }
}
