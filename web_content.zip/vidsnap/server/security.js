import dns from 'node:dns/promises';
import net from 'node:net';
import { config } from './config.js';

export const SITES = [
  'youtube.com', 'youtu.be', 'm.youtube.com', 'music.youtube.com',
  'tiktok.com', 'instagram.com', 'facebook.com', 'fb.watch',
  'x.com', 'twitter.com', 'vimeo.com', 'dailymotion.com',
  'reddit.com', 'redd.it', 'twitch.tv', 'soundcloud.com',
  'bilibili.com', 'linkedin.com', 'pinterest.com', 'snapchat.com',
  'threads.net', 'rumble.com', 'odysee.com', 'imgur.com', 'giphy.com',
];

const BLOCKED_RANGES = [
  /^0\./,
  /^10\./,
  /^127\./,
  /^169\.254\./,
  /^172\.(1[6-9]|2\d|3[01])\./,
  /^192\.0\.0\./,
  /^192\.168\./,
  /^198\.1[89]\./,
  /^22[4-9]\.|^23\d\.|^24\d\.|^25[0-5]\./,
];

const BLOCKED_NAME = /^(localhost|.*\.localhost|.*\.local|.*\.internal|.*\.lan|metadata\.google\.internal)$/i;

function isPrivate(address) {
  const version = net.isIP(address);
  if (version === 4) return BLOCKED_RANGES.some((re) => re.test(address));
  if (version === 6) {
    const value = address.toLowerCase();
    if (value === '::' || value === '::1' || value.startsWith('fe80')) return true;
    if (/^f[cd]/.test(value)) return true;
    if (value.startsWith('::ffff:')) return isPrivate(value.slice(7));
    return false;
  }
  return true;
}

export class BadRequest extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

export async function checkUrl(raw) {
  let url;
  try {
    url = new URL(String(raw ?? '').trim());
  } catch {
    throw new BadRequest('That is not a valid link.');
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new BadRequest('Only http and https links are supported.');
  if (url.username || url.password) throw new BadRequest('Links with embedded credentials are not allowed.');

  const rawHost = url.hostname.toLowerCase().replace(/\.$/, '');
  const hostname = rawHost.startsWith('[') && rawHost.endsWith(']') ? rawHost.slice(1, -1) : rawHost;

  if (BLOCKED_NAME.test(hostname)) throw new BadRequest('That host is not reachable from this server.');

  if (config.allowedHosts.length && !config.allowedHosts.some((h) => hostname === h || hostname.endsWith(`.${h}`))) {
    throw new BadRequest(`Only these hosts are allowed: ${config.allowedHosts.join(', ')}`);
  }

  let addresses = [];
  if (net.isIP(hostname)) {
    addresses = [hostname];
  } else {
    try {
      addresses = (await dns.lookup(hostname, { all: true, verbatim: true })).map((r) => r.address);
    } catch {
      throw new BadRequest(`Could not resolve ${hostname}.`, 502);
    }
  }

  if (!addresses.length || addresses.some(isPrivate)) {
    throw new BadRequest('Links pointing at private or local network addresses are blocked.');
  }

  return { url, hostname, addresses };
}

const buckets = new Map();

export function rateLimit(req, res, next) {
  if (!config.rateLimit) return next();
  const ip = req.ip || req.socket?.remoteAddress || 'unknown';
  const now = Date.now();
  let bucket = buckets.get(ip);
  if (!bucket || now - bucket.start > 60000) {
    bucket = { start: now, count: 0 };
    buckets.set(ip, bucket);
  }
  bucket.count += 1;
  const left = Math.max(0, config.rateLimit - bucket.count);
  res.setHeader('RateLimit-Limit', String(config.rateLimit));
  res.setHeader('RateLimit-Remaining', String(left));
  if (bucket.count > config.rateLimit) {
    res.setHeader('Retry-After', String(Math.ceil((bucket.start + 60000 - now) / 1000)));
    return res.status(429).json({ error: 'Too many requests. Slow down a moment.' });
  }
  return next();
}

setInterval(() => {
  const cutoff = Date.now() - 120000;
  for (const [ip, bucket] of buckets) if (bucket.start < cutoff) buckets.delete(ip);
}, 120000).unref();

export const validId = (value) => typeof value === 'string' && /^[A-Za-z0-9_-]{6,64}$/.test(value);

export const featured = (host) => {
  const value = String(host || '').toLowerCase();
  return SITES.some((site) => value === site || value.endsWith(`.${site}`));
};
