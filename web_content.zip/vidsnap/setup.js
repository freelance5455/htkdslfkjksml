#!/usr/bin/env node
import { execFile, spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const only = args.includes('--check');
const skipFfmpeg = args.includes('--no-ffmpeg');

const C = { r: '\x1b[0m', b: '\x1b[1m', d: '\x1b[2m', g: '\x1b[32m', y: '\x1b[33m', e: '\x1b[31m' };
const ok = (s) => console.log(`  ${C.g}\u2713${C.r} ${s}`);
const warn = (s) => console.log(`  ${C.y}!${C.r} ${s}`);
const bad = (s) => console.log(`  ${C.e}\u2717${C.r} ${s}`);

const run = (cmd, argv, opts = {}) =>
  new Promise((resolve) => {
    execFile(cmd, argv, { timeout: opts.timeout || 600000, windowsHide: true }, (error, stdout, stderr) =>
      resolve({ ok: !error, out: String(stdout || '').trim(), err: String(stderr || '').trim(), raw: error }));
  });

const live = (cmd, argv) =>
  new Promise((resolve) => {
    const child = spawn(cmd, argv, { stdio: 'inherit', windowsHide: true });
    child.on('error', () => resolve(false));
    child.on('close', (code) => resolve(code === 0));
  });


async function findYtDlp() {
  for (const candidate of [path.join(ROOT, 'bin', process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp'), 'yt-dlp', path.join(os.homedir(), '.local', 'bin', 'yt-dlp'), 'yt-dlp.exe']) {
    const probe = await run(candidate, ['--version'], { timeout: 20000 });
    if (probe.ok) return { bin: candidate, version: probe.out.split('\n')[0] };
  }
  return null;
}

async function findFfmpeg() {
  const local = path.join(ROOT, 'bin', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
  for (const candidate of [local, 'ffmpeg']) {
    const probe = await run(candidate, ['-version'], { timeout: 20000 });
    if (probe.ok) return { bin: candidate, version: probe.out.match(/ffmpeg version (\S+)/)?.[1] || 'ok' };
  }
  return null;
}

async function installYtDlp() {
  console.log(`\n${C.b}Installing yt-dlp${C.r}`);
  const binDir = path.join(ROOT, 'bin');
  fs.mkdirSync(binDir, { recursive: true });
  const target = path.join(binDir, process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
  const url =
    process.platform === 'win32'
      ? 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe'
      : process.platform === 'darwin'
        ? 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos'
        : 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux';

  try {
    const response = await fetch(url, { redirect: 'follow' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length < 1000000) throw new Error('download looks truncated');
    fs.writeFileSync(target, buffer);
    fs.chmodSync(target, 0o755);
    ok(`downloaded yt-dlp → bin/yt-dlp (${(buffer.length / 1e6).toFixed(1)} MB)`);
    return true;
  } catch (error) {
    warn(`could not download the binary (${error.message})`);
  }

  for (const [cmd, argv] of [
    ['python3', ['-m', 'pip', 'install', '-U', '--user', 'yt-dlp']],
    ['python', ['-m', 'pip', 'install', '-U', '--user', 'yt-dlp']],
    ['pip3', ['install', '-U', '--user', 'yt-dlp']],
  ]) {
    console.log(`${C.d}  trying ${cmd} -m pip install -U yt-dlp${C.r}`);
    if (await live(cmd, argv)) {
      ok('installed through pip');
      return true;
    }
  }
  return false;
}

async function installFfmpeg() {
  console.log(`\n${C.b}Installing ffmpeg${C.r}`);
  const binDir = path.join(ROOT, 'bin');
  fs.mkdirSync(binDir, { recursive: true });

  if (process.platform === 'darwin') {
    if (await run('brew', ['--version'], { timeout: 15000 }).then((r) => r.ok)) {
      if (await live('brew', ['install', 'ffmpeg'])) {
        ok('installed through Homebrew');
        return true;
      }
    }
  }

  if (process.platform === 'linux' && os.arch() !== 'x64') {
    for (const [cmd, argv] of [
      ['sudo', ['apt-get', 'install', '-y', 'ffmpeg']],
      ['apt-get', ['install', '-y', 'ffmpeg']],
      ['dnf', ['install', '-y', 'ffmpeg']],
      ['apk', ['add', 'ffmpeg']],
    ]) {
      console.log(`${C.d}  trying ${cmd} ${argv.join(' ')}${C.r}`);
      if (await live(cmd, argv)) {
        ok(`installed through ${cmd}`);
        return true;
      }
    }
  }

  if (process.platform === 'linux' && os.arch() === 'x64') {
    console.log(`${C.d}  fetching a static build${C.r}`);
    try {
      const response = await fetch('https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz');
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const archive = path.join(os.tmpdir(), 'ffmpeg.tar.xz');
      fs.writeFileSync(archive, Buffer.from(await response.arrayBuffer()));
      const dir = path.join(os.tmpdir(), 'ffmpeg-unpack');
      fs.rmSync(dir, { recursive: true, force: true });
      fs.mkdirSync(dir, { recursive: true });
      if (await live('tar', ['-xf', archive, '-C', dir])) {
        const inner = fs.readdirSync(dir).find((name) => name.startsWith('ffmpeg-'));
        if (inner) {
          for (const name of ['ffmpeg', 'ffprobe']) {
            const from = path.join(dir, inner, name);
            if (fs.existsSync(from)) {
              fs.copyFileSync(from, path.join(binDir, name));
              fs.chmodSync(path.join(binDir, name), 0o755);
            }
          }
          ok('extracted ffmpeg → bin/');
          return true;
        }
      }
    } catch (error) {
      warn(`static build failed (${error.message})`);
    }
  }

  if (process.platform === 'win32') {
    console.log(`${C.d}  trying winget${C.r}`);
    if (await live('winget', ['install', '--id', 'Gyan.FFmpeg', '-e', '--accept-source-agreements', '--accept-package-agreements'])) {
      ok('installed through winget');
      return true;
    }
  }

  return false;
}

async function main() {
  console.log(`\n${C.b}VidSnap setup${C.r}\n`);

  const major = Number(process.versions.node.split('.')[0]);
  if (major < 18) {
    bad(`Node ${process.versions.node} is too old — install Node 18.17 or newer`);
    process.exit(1);
  }
  ok(`Node ${process.versions.node}`);

  if (!fs.existsSync(path.join(ROOT, 'node_modules', 'express'))) {
    console.log(`\n${C.b}Installing dependencies${C.r}`);
    if (!(await live(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', '--omit=dev', '--no-audit', '--no-fund', '--ignore-scripts']))) {
      bad('npm install failed');
      process.exit(1);
    }
    ok('dependencies installed');
  } else {
    ok('dependencies present');
  }

  console.log(`\n${C.b}Checking the engine${C.r}`);
  let engine = await findYtDlp();
  if (engine) ok(`yt-dlp ${engine.version} ${C.d}(${engine.bin})${C.r}`);
  else {
    warn('yt-dlp not found');
    if (only) bad('cannot continue without yt-dlp');
    else engine = (await installYtDlp()) ? await findYtDlp() : null;
  }

  let ff = await findFfmpeg();
  if (ff) ok(`ffmpeg ${ff.version} ${C.d}(${ff.bin})${C.r}`);
  else if (skipFfmpeg) warn('ffmpeg skipped');
  else if (only) warn('ffmpeg not found');
  else {
    warn('ffmpeg not found');
    ff = (await installFfmpeg()) ? await findFfmpeg() : null;
    if (ff) ok(`ffmpeg ${ff.version}`);
  }

  const envPath = path.join(ROOT, '.env');
  const binDir = path.join(ROOT, 'bin');
  const lines = [];
  if (engine && !engine.bin.includes('/') && !engine.bin.includes('\\')) lines.push(`YTDLP_BIN=${engine.bin}`);
  if (engine && engine.bin.includes(path.sep)) lines.push(`YTDLP_BIN=${engine.bin}`);
  if (ff) lines.push(`FFMPEG_LOCATION=${ff.bin.includes(path.sep) ? ff.bin : ''}`);

  if (lines.length) {
    const existing = fs.existsSync(envPath) ? fs.readFileSync(envPath, 'utf8') : '';
    const kept = existing
      .split('\n')
      .filter((line) => line.trim() && !/^(YTDLP_BIN|FFMPEG_LOCATION)=/.test(line.trim()));
    fs.writeFileSync(envPath, [...kept, ...lines, ''].join('\n'));
    ok(`wrote ${path.relative(ROOT, envPath)}`);
  }

  console.log('');
  if (!engine) {
    bad('yt-dlp is still missing — install Python and run: python3 -m pip install -U yt-dlp');
    process.exit(1);
  }
  if (!ff) {
    warn('without ffmpeg you only get ready-made files (usually up to 360-720p), no MP3 and no subtitles');
  }

  if (only) {
    console.log(`\n${C.g}Ready.${C.r} Start with: npm start\n`);
    return;
  }

  console.log(`${C.g}Everything is ready.${C.r}\n`);
  console.log('  Starting the server…\n');
  await import('./server/index.js');
}

main().catch((error) => {
  console.error(`\n${C.e}Setup failed:${C.r}`, error.message);
  process.exit(1);
});
