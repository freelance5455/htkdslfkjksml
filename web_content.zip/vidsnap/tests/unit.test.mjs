import assert from 'node:assert/strict';
import test from 'node:test';
import { Dedupe, Future } from '../server/cache.js';
import { present, progress, selector } from '../server/engine.js';
import { disposition, mimeFor, parseRange, safeName } from '../server/http.js';
import { BadRequest, checkUrl, featured, validId } from '../server/security.js';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

test('Future stores, expires and evicts', async () => {
  const cache = new Future(2, 40);
  cache.set('a', 1);
  assert.equal(cache.get('a'), 1);
  cache.set('b', 2);
  cache.set('c', 3);
  assert.equal(cache.get('a'), undefined, 'oldest entry evicted by the LRU cap');
  assert.equal(cache.get('c'), 3);
  await sleep(60);
  assert.equal(cache.get('b'), undefined, 'entry expired by ttl');
  assert.equal(cache.stats().size, 1);
  assert.ok(cache.stats().hits >= 1);
});

test('Dedupe runs one task for concurrent callers', async () => {
  const dedupe = new Dedupe();
  let calls = 0;
  const task = async () => {
    calls += 1;
    await sleep(25);
    return 'value';
  };
  const [first, second, third] = await Promise.all([dedupe.run('k', task), dedupe.run('k', task), dedupe.run('k', task)]);
  assert.deepEqual([first, second, third], ['value', 'value', 'value']);
  assert.equal(calls, 1);
  await dedupe.run('k', task);
  assert.equal(calls, 2, 'key is released once settled');
});

test('parseRange understands the header forms browsers send', () => {
  assert.equal(parseRange(undefined, 100), null);
  assert.equal(parseRange('bytes=0-', 100).end, 99);
  assert.deepEqual(parseRange('bytes=10-19', 100), { start: 10, end: 19 });
  assert.deepEqual(parseRange('bytes=-20', 100), { start: 80, end: 99 });
  assert.deepEqual(parseRange('bytes=0-999', 100), { start: 0, end: 99 });
  assert.equal(parseRange('bytes=500-600', 100), 'invalid');
  assert.equal(parseRange('bytes=50-10', 100), 'invalid');
  assert.equal(parseRange('items=0-1', 100), 'invalid');
  assert.equal(parseRange('bytes=0-1,5-6', 100), null, 'multi-range is ignored, not corrupted');
});

test('safeName strips path separators and control characters', () => {
  assert.equal(safeName('a/b\\c:d*e?"f<g>h|i'), 'a b c d e f g h i');
  assert.equal(safeName('   ...name...   '), 'name');
  assert.equal(safeName(''), 'download');
  assert.equal(safeName('x'.repeat(200)).length, 120);
});

test('mimeFor maps containers', () => {
  assert.equal(mimeFor('MP4'), 'video/mp4');
  assert.equal(mimeFor('mp3'), 'audio/mpeg');
  assert.equal(mimeFor('webm'), 'video/webm');
  assert.equal(mimeFor('weird'), 'application/octet-stream');
});

test('disposition escapes quotes and keeps the unicode name', () => {
  const header = disposition('music "mix".mp3');
  assert.match(header, /^attachment; filename="music mix.mp3"/);
  assert.match(header, /filename\*=UTF-8''music%20%22mix%22\.mp3/);
  assert.match(disposition('x.mp4', true), /^inline;/);
});

test('checkUrl blocks everything that is not a public http link', async () => {
  const rejects = [
    'file:///etc/passwd',
    'ftp://example.com/x',
    'javascript:alert(1)',
    'http://user:pass@example.com/x',
    'http://localhost:5173/x',
    'http://127.0.0.1/x',
    'http://169.254.169.254/latest/meta-data/',
    'http://192.168.0.10/x',
    'http://10.1.2.3/x',
    'http://[::1]/x',
    'not a url',
    '',
  ];
  for (const value of rejects) {
    await assert.rejects(() => checkUrl(value), BadRequest, `expected ${value} to be rejected`);
  }
});

test('validId only accepts opaque tokens', () => {
  assert.ok(validId('abcdef'));
  assert.ok(validId('a-b_c-1234567'));
  assert.equal(validId('short'), false);
  assert.equal(validId('has space'), false);
  assert.equal(validId('../etc/passwd'), false);
  assert.equal(validId(undefined), false);
});

test('featured recognises the supported sites', () => {
  assert.equal(featured('youtu.be'), true);
  assert.equal(featured('www.youtube.com'), true);
  assert.equal(featured('example.com'), false);
});

test('progress parses yt-dlp template lines', () => {
  const download = progress('PROG|downloading|500000|2000000|NA|250000|6.2|3|17');
  assert.equal(download.kind, 'download');
  assert.equal(download.done, 500000);
  assert.equal(download.all, 2000000);
  assert.equal(download.percent, 25);
  assert.equal(download.speed, 250000);
  assert.equal(download.fragment, 3);
  assert.equal(progress('POST|started|Merger').kind, 'post');
  assert.equal(progress('[download] Destination: x'), null);
  assert.equal(progress('PROG|downloading|NA|NA|NA|NA|NA|NA|NA').percent, null);
});

test('selector builds a fallback chain, never a raw injection', () => {
  assert.equal(selector({ kind: 'video' }), 'bv*+ba/b');
  const chain = selector({ kind: 'video', height: 1080, fps: 60 }).split('/');
  assert.equal(chain[0], 'bv*[height<=1080][fps>=55]+ba[ext=m4a]');
  assert.ok(chain.includes('b[height<=1080][fps>=55]'), 'a ready-made stream is tried before merging');
  assert.ok(selector({ kind: 'video', height: 1080, fps: 60 }).endsWith('bv*+ba/b'), 'the chain always ends with a safe fallback');
  assert.equal(selector({ kind: 'video', formatId: '137', audioFormatId: '140' }), '137+140');
  assert.equal(selector({ kind: 'audio' }), 'ba/b');
  assert.equal(selector({ kind: 'audio', container: 'mp3' }), 'ba[ext=mp3]/ba[ext=mp3][abr<=400]/ba/b');
  assert.equal(selector({ kind: 'video', formatId: '$(whoami)' }), 'bv*+ba/b', 'malformed format ids are dropped');
  assert.equal(selector({ kind: 'video', formatId: '137', audioFormatId: '140' }, { withAudio: false }), '137');
});

const INFO = {
  id: 'abc',
  title: 'Sample clip',
  extractor: 'youtube',
  extractor_key: 'Youtube',
  duration: 42,
  uploader: 'Someone',
  thumbnail: 'https://example.com/t.jpg',
  formats: [
    { format_id: '137', ext: 'mp4', height: 1080, fps: 30, vcodec: 'avc1.640028', acodec: 'none', filesize: 40_000_000, url: 'https://cdn/a' },
    { format_id: '248', ext: 'webm', height: 1080, fps: 30, vcodec: 'vp9', acodec: 'none', filesize: 30_000_000, url: 'https://cdn/b' },
    { format_id: '136', ext: 'mp4', height: 720, fps: 30, vcodec: 'avc1.4d401f', acodec: 'none', filesize: 20_000_000, url: 'https://cdn/c' },
    { format_id: '18', ext: 'mp4', height: 360, vcodec: 'avc1.42001E', acodec: 'mp4a.40.2', filesize: 5_000_000, url: 'https://cdn/d', vcodec_note: 'muxed' },
    { format_id: '140', ext: 'm4a', vcodec: 'none', acodec: 'mp4a.40.2', abr: 128, filesize: 700_000, url: 'https://cdn/e' },
    { format_id: '251', ext: 'webm', vcodec: 'none', acodec: 'opus', abr: 160, filesize: 900_000, url: 'https://cdn/f' },
  ],
};

test('present groups formats into quality tiers', () => {
  const data = present(INFO, 'https://youtu.be/abc');
  assert.equal(data.type, 'video');
  assert.equal(data.title, 'Sample clip');

  const heights = data.formats.video.map((tier) => tier.height);
  assert.deepEqual(heights, [1080, 720, 360], 'tiers come back highest first, one row per height');

  const best = data.formats.video[0];
  assert.equal(best.ext, 'mp4', 'mp4 wins over webm for the same height');
  assert.equal(best.vcodec, 'avc1', 'h264 wins over vp9');
  assert.equal(best.needsMerge, true);
  assert.equal(best.audioFormatId, '140', 'an m4a audio track is attached');
  assert.equal(best.filesize, 40_700_000, 'size includes the audio track');
  assert.equal(best.stream, null, '1080p has no ready-made file');

  const low = data.formats.video[2];
  assert.equal(low.needsMerge, false, 'the muxed 360p file needs no merge');
  assert.ok(low.stream?.formatId === '18');

  const kbps = data.formats.audio.map((tier) => tier.abr);
  assert.deepEqual(kbps, [160, 128]);
  assert.equal(data.formats.audio[0].ext, 'webm');
});

test('present handles a bare direct link with no metadata', () => {
  const data = present(
    { id: 'v', title: 'movie.mp4', formats: [{ format_id: '0', ext: 'mp4', url: 'https://cdn/x', filesize: 788493 }] },
    'https://example.com/movie.mp4',
  );
  assert.equal(data.type, 'video');
  assert.equal(data.formats.video.length, 1);
  assert.equal(data.formats.video[0].label, 'Original');
  assert.equal(data.formats.video[0].needsMerge, false);
  assert.equal(data.formats.video[0].stream.formatId, '0');
});

test('present marks a playlist and keeps its entries', () => {
  const data = present(
    { _type: 'playlist', id: 'PL', title: 'Mix', playlist_count: 3, entries: [{ id: '1', title: 'One', url: 'https://x/1', duration: 10 }, null, { id: '2', title: 'Two', url: 'https://x/2' }] },
    'https://youtube.com/playlist?list=PL',
  );
  assert.equal(data.type, 'playlist');
  assert.equal(data.entryCount, 3);
  assert.equal(data.entries.length, 2, 'null entries are dropped');
  assert.equal(data.entries[0].title, 'One');
});

test('downloadArgs requires a real output path', async () => {
  const { downloadArgs } = await import('../server/engine.js');
  assert.throws(() => downloadArgs({ quality: {}, url: 'https://example.com/video.mp4' }), /output path/);
  const args = downloadArgs({ quality: { kind: 'video', height: 720 }, options: {}, outputTemplate: '/tmp/test/media.%(ext)s', url: 'https://example.com/video.mp4' });
  assert.equal(args[args.indexOf('-o') + 1], '/tmp/test/media.%(ext)s');
  assert.equal(args.at(-2), '--');
  assert.ok(args.includes('download:PROG|%(progress.status)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s|%(progress.fragment_index)s|%(progress.fragment_count)s'));
});
