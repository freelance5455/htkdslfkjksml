#!/usr/bin/env node
const BASE = process.env.BASE || `http://127.0.0.1:${process.env.PORT || 5173}`;
const SESSION = 'verify' + Math.random().toString(36).slice(2, 10);
const ARG = process.argv[2];

let passed = 0;
let failed = 0;

const ok = (name, extra = '') => {
  passed += 1;
  console.log(`  \u2713 ${name}${extra ? ` ${extra}` : ''}`);
};
const bad = (name, error) => {
  failed += 1;
  console.log(`  \u2717 ${name}\n      ${error}`);
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const call = async (path, options = {}) => {
  const response = await fetch(`${BASE}/api${path}`, {
    method: options.method || 'GET',
    headers: { 'x-session-id': SESSION, ...(options.body ? { 'content-type': 'application/json' } : {}), ...(options.headers || {}) },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const type = response.headers.get('content-type') || '';
  const payload = type.includes('json') ? await response.json() : await response.arrayBuffer();
  return { status: response.status, headers: response.headers, payload };
};

async function check(name, task) {
  try {
    const extra = await task();
    ok(name, typeof extra === 'string' ? extra : '');
    return true;
  } catch (error) {
    bad(name, error.message);
    return false;
  }
}

const expect = (condition, message) => {
  if (!condition) throw new Error(message);
};

async function main() {
  console.log(`\nVerify ${BASE}\n`);

  let engineReady = false;
  await check('the server answers /api/health', async () => {
    const { status, payload } = await call('/health?refresh=1');
    expect(status === 200, `status ${status}`);
    expect(payload.engine, 'no engine block');
    engineReady = Boolean(payload.engine.engine?.ok);
    expect(engineReady, 'yt-dlp is not installed — run npm run setup');
    return `yt-dlp ${payload.engine.engine.version}${payload.engine.ffmpeg?.ok ? ', ffmpeg ok' : ', ffmpeg MISSING'}`;
  });

  if (!engineReady) {
    console.log(`\n${failed} failed, ${passed} passed — install the engine first.\n`);
    process.exit(1);
  }

  await check('bad links are refused with a readable message', async () => {
    const { status, payload } = await call('/info?url=http%3A%2F%2F127.0.0.1%2Fsecret');
    expect(status === 400, `status ${status}`);
    expect(/private|reachable/i.test(payload.error), payload.error);
    return `"${payload.error}"`;
  });

  const fixture = ARG || 'https://www.w3schools.com/html/mov_bbb.mp4';
  let info = null;

  const gotInfo = await check(`metadata for ${fixture}`, async () => {
    const { status, payload } = await call(`/info?url=${encodeURIComponent(fixture)}`);
    expect(status === 200, `status ${status} ${payload?.error || ''}`);
    expect(payload.formats, 'no formats returned');
    info = payload;
    const rows = (payload.formats.video || []).map((tier) => tier.label).join(', ');
    return `${payload.type} · ${payload.formats.video?.length || 0} video tiers (${rows})`;
  });

  if (!gotInfo) {
    console.log(`\n${failed} failed, ${passed} passed\n`);
    process.exit(1);
  }

  const tier = (info.formats.video || [])[0];
  expect(tier, 'no video tier to download');

  let job = null;
  await check('a download job is accepted', async () => {
    const { status, payload } = await call('/download', {
      method: 'POST',
      body: {
        url: info.webpageUrl || fixture,
        quality: { kind: tier.kind, height: tier.height, abr: tier.abr ?? null, label: tier.label, formatId: tier.formatId, audioFormatId: tier.audioFormatId, container: null },
        options: {},
      },
    });
    expect(status === 201, `status ${status} ${payload?.error || ''}`);
    job = payload.job;
    expect(job?.id, 'job has no id');
    return `job ${job.id.slice(0, 6)} (${job.mode})`;
  });

  if (!job) {
    console.log(`\n${failed} failed, ${passed} passed\n`);
    process.exit(1);
  }

  await check('progress is reported until the job finishes', async () => {
    const deadline = Date.now() + 240000;
    let last = null;
    while (Date.now() < deadline) {
      const { payload } = await call(`/jobs/${job.id}`);
      last = payload.job;
      if (last.status === 'completed') return `${last.file?.size ? (last.file.size / 1048576).toFixed(2) + ' MB' : 'ready'} as ${last.file?.name}`;
      if (last.status === 'failed' || last.status === 'canceled') throw new Error(`${last.status}: ${last.error || ''}`);
      await sleep(700);
    }
    throw new Error(`timed out at ${last?.progress?.percent ?? 0}% (${last?.stage})`);
  });

  await check('the file streams back with byte ranges', async () => {
    const current = await call(`/jobs/${job.id}`);
    const url = current.payload.job.downloadUrl;
    const response = await fetch(`${BASE}${url}`, { headers: { Range: 'bytes=0-4095' } });
    expect(response.status === 206 || response.status === 200, `status ${response.status}`);
    const body = await response.arrayBuffer();
    expect(body.byteLength > 0, 'empty body');
    const disposition = response.headers.get('content-disposition') || '';
    expect(/attachment/.test(disposition), `disposition was "${disposition}"`);
    return `${body.byteLength} bytes (${response.status}), ${response.headers.get('content-type')}`;
  });

  await check('the job can be removed again', async () => {
    const { status, payload } = await call(`/jobs/${job.id}`, { method: 'DELETE' });
    expect(status === 200 && payload.ok, `status ${status}`);
    const after = await call(`/jobs/${job.id}`);
    expect(after.status === 404, 'the job survived deletion');
  });

  console.log(`\n${failed ? `${failed} failed, ` : ''}${passed} passed\n`);
  process.exit(failed ? 1 : 0);
}

main().catch((error) => {
  console.error(`\nverify crashed: ${error.message}\n`);
  process.exit(1);
});
