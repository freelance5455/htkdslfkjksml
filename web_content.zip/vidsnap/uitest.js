#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright';

const BASE = process.env.BASE || `http://127.0.0.1:${process.env.PORT || 5173}`;
const FIXTURE = process.env.FIXTURE || 'https://www.w3schools.com/html/mov_bbb.mp4';
const OUT = path.resolve('screenshots');

let passed = 0;
let failed = 0;
const ok = (name, extra = '') => {
  passed += 1;
  console.log(`  \u2713 ${name}${extra ? ` ${extra}` : ''}`);
};
const bad = (name, error) => {
  failed += 1;
  console.log(`  \u2717 ${name}\n      ${error}`);
};

async function step(name, task) {
  try {
    const extra = await task();
    ok(name, typeof extra === 'string' ? extra : '');
    return true;
  } catch (error) {
    bad(name, error.message.split('\n')[0]);
    return false;
  }
}

const expect = (value, message) => {
  if (!value) throw new Error(message);
};

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    deviceScaleFactor: 2,
    isMobile: true,
    hasTouch: true,
    permissions: [],
  });
  const page = await context.newPage();
  const consoleErrors = [];
  let intentionalFailure = false;
  page.on('console', (message) => {
    if (message.type() === 'error' && !intentionalFailure) consoleErrors.push(message.text());
  });
  page.on('pageerror', (error) => consoleErrors.push(String(error)));

  console.log(`\nUI ${BASE}\n`);

  await step('the app boots and hides the splash screen', async () => {
    await page.goto(BASE, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('#app:not([hidden])', { timeout: 20000 });
    await page.waitForSelector('#boot', { state: 'detached', timeout: 10000 });
    return 'shell painted';
  });

  await step('the engine is reported as ready', async () => {
    await page.waitForFunction(() => /yt-dlp/.test(document.querySelector('#engine-pill')?.textContent || ''), null, { timeout: 20000 });
    return await page.textContent('#engine-pill');
  });

  await step('no error banner is shown', async () => {
    expect(!(await page.$('#banner')), 'a warning banner is visible on a healthy server');
    return 'clean';
  });

  await step('featured sites are rendered as chips', async () => {
    const chips = await page.$$eval('#featured .chip', (nodes) => nodes.map((node) => node.textContent));
    expect(chips.length >= 8, `only ${chips.length} chips`);
    return chips.slice(0, 5).join(', ');
  });

  await step('a link can be fetched and quality tiers are listed', async () => {
    await page.fill('#url', FIXTURE);
    await page.click('#go');
    await page.waitForSelector('#panel:not([hidden])', { timeout: 60000 });
    await page.waitForSelector('#quality-list .item', { timeout: 60000 });
    const rows = await page.$$eval('#quality-list .item .q', (nodes) => nodes.map((node) => node.textContent));
    expect(rows.length > 0, 'no quality rows');
    return rows.join(' / ');
  });

  await step('the first tier can be selected', async () => {
    await page.locator('#quality-list .item').last().click();
    await page.waitForFunction(() => !document.querySelector('#download').disabled);
    return (await page.textContent('#pick-summary')).trim();
  });

  let downloadUrl = null;
  await step('the download button creates a job that reaches 100%', async () => {
    await page.click('#download');
    await page.waitForSelector('#tasks .task', { timeout: 30000 });
    const title = await page.textContent('#tasks .task .task-head b');
    await page.waitForFunction(
      () => document.querySelector('#tasks .task')?.classList.contains('done'),
      null,
      { timeout: 240000 },
    );
    downloadUrl = await page.evaluate(async (session) => {
      const response = await fetch('/api/jobs?session=' + session, { headers: { 'x-session-id': session } });
      const data = await response.json();
      return data.jobs[0]?.downloadUrl || null;
    }, await page.evaluate(() => localStorage.getItem('vidsnap.v2.session')));
    expect(downloadUrl, 'the finished job has no download url');
    return title;
  });

  await step('the finished job really serves bytes', async () => {
    const result = await page.evaluate(async (url) => {
      const response = await fetch(url, { headers: { Range: 'bytes=0-2047' } });
      const buffer = await response.arrayBuffer();
      return { status: response.status, bytes: buffer.byteLength, disposition: response.headers.get('content-disposition') };
    }, downloadUrl);
    expect(result.bytes >= 2048, `only ${result.bytes} bytes came back`);
    expect(/attachment/.test(result.disposition || ''), 'missing attachment disposition');
    return `${result.status} · ${result.bytes} bytes`;
  });

  await step('a finished job plays inside the app', async () => {
    await page.click('#tasks .task button:has-text("Play")');
    await page.waitForSelector('#tasks video', { timeout: 10000 });
    await page.waitForFunction(() => {
      const video = document.querySelector('#tasks video');
      return video && video.readyState >= 2;
    }, null, { timeout: 30000 });
    const state = await page.evaluate(() => {
      const video = document.querySelector('#tasks video');
      return { duration: video.duration, ready: video.readyState };
    });
    expect(state.ready >= 2, 'the video element never became ready');
    return `readyState ${state.ready}, duration ${Number(state.duration || 0).toFixed(1)}s`;
  });

  await step('settings persist to local storage', async () => {
    await page.click('#settings-btn');
    await page.waitForSelector('#sheet:not([hidden])');
    await page.selectOption('#set-tap', 'save');
    await page.click('#set-close');
    const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('vidsnap.v2.prefs')));
    expect(stored.tap === 'save', 'preference was not stored');
    await page.click('#settings-btn');
    await page.selectOption('#set-tap', 'open');
    await page.click('#set-close');
    return 'round-trip ok';
  });

  await step('the manifest and service worker are served', async () => {
    const manifest = await page.evaluate(() => fetch('/manifest.webmanifest').then((r) => r.json()));
    expect(manifest.icons?.length >= 4, 'manifest has no icons');
    const worker = await page.evaluate(async () => {
      const response = await fetch('/sw.js');
      const text = await response.text();
      return { ok: response.ok, hasInstall: /addEventListener\('install'/.test(text) };
    });
    expect(worker.ok && worker.hasInstall, 'service worker looks broken');
    return `${manifest.icons.length} icons, sw active`;
  });

  await step('the API rejects a private address', async () => {
    intentionalFailure = true;
    const status = await page.evaluate(async () => {
      const response = await fetch('/api/info?url=' + encodeURIComponent('http://192.168.1.1/x'));
      return response.status;
    });
    await page.waitForTimeout(250);
    intentionalFailure = false;
    expect(status === 400, `status ${status}`);
    return 'blocked as expected';
  });

  await step('the layout does not scroll sideways', async () => {
    await page.setViewportSize({ width: 360, height: 800 });
    await page.waitForTimeout(250);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(overflow <= 1, `content is ${overflow}px wider than the viewport`);
    return 'fits 360px';
  });

  await step('screenshots are taken', async () => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(OUT, 'mobile.png'), fullPage: true });
    await page.setViewportSize({ width: 1280, height: 900 });
    await page.waitForTimeout(400);
    await page.screenshot({ path: path.join(OUT, 'desktop.png'), fullPage: true });
    return path.relative(process.cwd(), OUT);
  });

  await step('the console stays clean', async () => {
    const real = consoleErrors.filter((line) => !/favicon|ResizeObserver/.test(line));
    expect(real.length === 0, real.slice(0, 3).join(' | '));
    return 'no errors';
  });

  await browser.close();
  console.log(`\n${failed ? `${failed} failed, ` : ''}${passed} passed\n`);
  process.exit(failed ? 1 : 0);
}

main().catch((error) => {
  console.error(`\nuitest crashed: ${error.message}\n`);
  process.exit(1);
});
