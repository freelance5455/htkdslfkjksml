SNAKE — versione mobile

CONTENUTO
- index.html: gioco completo in un unico file, senza librerie esterne.

PROVA RAPIDA
1. Estrai snake_mobile.zip.
2. Apri index.html con un browser moderno (Chrome consigliato).
3. Su telefono puoi aprire il file con il browser; per distribuirlo come app è meglio inserirlo in un progetto Android.

PER CREARE UN APK
Puoi usare Capacitor (consigliato) oppure un progetto Android Studio con una WebView che carichi index.html.
Con Capacitor, in sintesi:
1. Installa Node.js e Android Studio.
2. Crea un progetto Capacitor e copia index.html nella cartella web (spesso www/).
3. Aggiungi la piattaforma Android e apri il progetto in Android Studio.
4. Genera l'APK da Build > Build Bundle(s) / APK(s) > Build APK(s).

Nota: questo pacchetto contiene il gioco web sorgente, non un APK già compilato.
