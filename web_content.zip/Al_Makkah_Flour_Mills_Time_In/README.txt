AL MAKKAH FLOUR MILLS TIME IN — STARTER PACKAGE

Included:
- index.html: one-file offline-capable attendance web app.
- Features: employee add/rename/delete, Time In, history filters, printable daily/monthly/all-history reports, JSON backup/restore, theme selection.
- Data is saved in the current browser/device using localStorage.

IMPORTANT LIMITATIONS:
1. This ZIP is a working web-app starter, NOT a compiled APK or MIT .aia project.
2. PDF output uses the browser's Print dialog. Choose "Save as PDF". It does not silently write a PDF directly into Android Downloads.
3. Data stays on one device/browser. Multiple phones do NOT sync automatically; that needs a server/cloud database or manual backup/restore.
4. Admin password is a basic UI lock and is not strong security. Protect the device and backup files.
5. For APK, package this web app with a suitable Android wrapper/build environment, or rebuild the screens/logic in MIT App Inventor/Kodular.

QUICK START:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Add an employee and test Time In.
4. Open History -> select report -> Save / Print PDF -> choose Save as PDF.
5. Open Admin & Backup to download a JSON backup.
