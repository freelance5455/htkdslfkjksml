# Como gerar o arquivo .apk do GK Painel (Android 5.0 a 15+)

Este pacote contém o projeto nativo Android Studio (Kotlin + WebView + suporte a `ws://127.0.0.1:5732` para Termux/Shizuku) já com os arquivos compilados do app embutidos em `app/src/main/assets/`.

## Opção 1 — Pelo próprio celular usando GitHub (Sem PC)

1. Crie um repositório gratuito no GitHub e envie os arquivos desta pasta.
2. Abra a aba **Actions** no GitHub e clique em **Gerar APK Android -> Run workflow**.
3. Aguarde ~2 minutos e baixe o arquivo `gk-painel-apk` (`app-debug.apk`) pronto para instalar no seu celular!

## Opção 2 — Pelo Android Studio no PC

1. Abra esta pasta no Android Studio.
2. Clique em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. O APK final será salvo em `app/build/outputs/apk/debug/app-debug.apk`.
