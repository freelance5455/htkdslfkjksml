#!/bin/bash
# DragonBoost 2.8 - Comandos limpos com 2>/dev/null || true
echo "Aplicando DragonBoost..."

setprop debug.composition.type gpu 2>/dev/null || true
setprop debug.enabletr true 2>/dev/null || true
setprop debug.overlayui.enable 1 2>/dev/null || true
setprop debug.performance.tuning 1 2>/dev/null || true
setprop hw3d.force 1 2>/dev/null || true
setprop hwui.disable_vsync true 2>/dev/null || true
setprop hwui.render_dirty_regions false 2>/dev/null || true
setprop persist.sys.composition.type gpu 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
setprop ro.config.enable.hw_accel true 2>/dev/null || true
setprop ro.product.gpu.driver 1 2>/dev/null || true
setprop ro.fb.mode 1 2>/dev/null || true
setprop ro.sf.compbypass.enable 0 2>/dev/null || true
setprop video.accelerate.hw 1 2>/dev/null || true
setprop debug.egl.hw 0 2>/dev/null || true
setprop debug.gralloc.gfx_ubwc_disable 0 2>/dev/null || true
setprop debug.mdpcomp.logs 0 2>/dev/null || true
setprop persist.vendor.color.matrix 2 2>/dev/null || true
setprop vendor.gralloc.disable_ubwc 0 2>/dev/null || true
setprop ro.vendor.qti.sys.fw.bg_apps_limit 120 2>/dev/null || true
setprop ro.vendor.qti.sys.fw.bservice_enable true 2>/dev/null || true
setprop ro.vendor.qti.core.ctl_max_cpu 4 2>/dev/null || true
setprop ro.vendor.qti.core.ctl_min_cpu 2 2>/dev/null || true

echo "DragonBoost aplicado!"
