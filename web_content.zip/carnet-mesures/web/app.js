// ============================================================
// VERSION
// ============================================================
const APP_VERSION = '0.4.0';

// ============================================================
// GESTION DES LIMITES ET ABONNEMENT (Freemium)
// ============================================================
const LIMITS = {
  MAX_FREE_CLIENTS: 10,
  MAX_FREE_MESURES: 3,
  AD_REWARD_CLIENTS: 5
};

function getLicense() {
  try {
    return JSON.parse(localStorage.getItem('app-license')) || { isPremium: false, extraClients: 0 };
  } catch {
    return { isPremium: false, extraClients: 0 };
  }
}

function setLicense(license) {
  localStorage.setItem('app-license', JSON.stringify(license));
}

function isPremium() {
  return getLicense().isPremium;
}

function getMaxClients() {
  if (isPremium()) return Infinity;
  return LIMITS.MAX_FREE_CLIENTS + (getLicense().extraClients || 0);
}

// ============================================================
// BASE DE DONNÉES
// ============================================================
const DB_NAME = 'carnet-mesures';
const DB_VERSION = 2;
let db;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('clients')) {
        db.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
      }
      if (!db.objectStoreNames.contains('mesures')) {
        const store = db.createObjectStore('mesures', { keyPath: 'id', autoIncrement: true });
        store.createIndex('clientId', 'clientId', { unique: false });
      }
    };
    req.onsuccess = (e) => { db = e.target.result; resolve(db); };
    req.onerror = (e) => reject(e.target.error);
  });
}
function dbAdd(store, item) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).add(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbPut(store, item) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).put(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbGet(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbGetAll(store) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbDelete(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
function dbClear(store) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
function getMesuresForClient(clientId) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('mesures', 'readonly');
    const index = tx.objectStore('mesures').index('clientId');
    const req = index.getAll(clientId);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// ============================================================
// PROFIL TAILLEUR (localStorage)
// ============================================================
const PROFILE_KEY = 'atelier-profile';
const DEFAULT_PROFILE = {
  nom: '', prenom: '', telephone: '', atelier: '', adresse: '', devise: 'FCFA'
};

function getProfile() {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return { ...DEFAULT_PROFILE };
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_PROFILE };
  }
}

function setProfile(profile) {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}

function getDevise() {
  return getProfile().devise || 'FCFA';
}

function formatMontant(value) {
  if (value === '' || value === null || value === undefined) return '—';
  const num = Number(value);
  if (isNaN(num)) return '—';
  const dev = getDevise();
  const suffix = dev === '€' || dev === '$' ? ' ' + dev : ' ' + dev;
  return num.toLocaleString('fr-FR') + suffix;
}

// ============================================================
// ICÔNES SVG
// ============================================================
const SVG_ICONS = {
  poitrine: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M7 4v16M17 4v16"/><path d="M3 9h18"/><path d="M3 9l2-1.5M3 9l2 1.5M21 9l-2-1.5M21 9l-2 1.5"/></svg>',
  taille: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M7 3v5c0 3 2 4 5 4s5-1 5-4V3"/><path d="M3 12h18"/><path d="M3 12l2-1.5M3 12l2 1.5M21 12l-2-1.5M21 12l-2 1.5"/></svg>',
  hanches: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M7 4v6c0 5 2 8 5 8s5-3 5-8V4"/><path d="M3 12h18"/><path d="M3 12l2-1.5M3 12l2 1.5M21 12l-2-1.5M21 12l-2 1.5"/></svg>',
  cou: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="12" cy="8" r="3"/><path d="M9 11v9M15 11v9"/><path d="M9 17h6"/></svg>',
  epaules: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M5 12c0-4 3-6 7-6s7 2 7 6"/><circle cx="5" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/><path d="M9 15h6"/></svg>',
  manche: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M8 4h8v12l-2 4h-4l-2-4V4z"/><path d="M10 10h4"/></svg>',
  biceps: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M8 6c-2 4-2 8 0 12"/><path d="M8 6c4-2 8 0 8 4s-2 8-8 8"/><path d="M8 12h8"/></svg>',
  poignet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><rect x="7" y="9" width="10" height="6"/><path d="M12 9v-3M10 15v3M14 15v3"/></svg>',
  dos: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M7 3v18M17 3v18"/><path d="M12 3v18"/><path d="M7 8h10"/><path d="M7 14h10"/></svg>',
  longueur: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M12 3v18"/><path d="M9 6l3-3 3 3"/><path d="M9 18l3 3 3-3"/></svg>',
  longueur_totale: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M8 3v18M16 3v18"/><path d="M8 3h8M8 21h8"/><path d="M12 6v12"/></svg>',
  jupe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M9 3h6l5 18H4L9 3z"/><path d="M9 3l3 18M15 3l-3 18"/></svg>',
  bras: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M8 3v18M16 3v18"/><path d="M8 3h8M8 21h8"/></svg>',
  cuisse: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M9 4c0 6 1 12 3 16M15 4c0 6-1 12-3 16"/><path d="M6 10h12"/></svg>',
  genou: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M10 3v18M14 3v18"/><circle cx="12" cy="12" r="2"/></svg>',
  cheville: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M10 3v12c0 3 2 6 4 6M14 3v12"/><path d="M7 18h10"/></svg>',
  entrejambe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M12 3v9"/><path d="M12 12L7 21M12 12l5 9"/><circle cx="12" cy="12" r="1"/></svg>',
  jambe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M10 3v18M14 3v18"/><path d="M10 12h4"/></svg>'
};

const TYPE_ICONS = {
  haut: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="m8 4-5 3 3 5 3-2v10h10V10l3 2 3-5-5-3-4 3h-4z"/></svg>',
  bas: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3h8v4l-1 5h-6l-1-5z"/><path d="M9 12v9M15 12v9M8 21h8"/></svg>',
  robe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3 6 6l-3 2 4 3-1 10h12l-1-10 4-3-3-2-3-3-3 2z"/><path d="m9 3 3 2 3-2"/></svg>',
  complet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3h8l2 4-2 3 2 11h-5l-1-8-1 8H6l2-11-2-3z"/></svg>'
};

// ============================================================
// TEMPLATES
// ============================================================
const TEMPLATES = {
  haut: {
    label: 'Haut',
    description: 'Chemise, boubou, kaftan, dashiki',
    champs: [
      { key: 'poitrine', label: 'Poitrine' },
      { key: 'taille', label: 'Taille' },
      { key: 'epaules', label: 'Épaules' },
      { key: 'manche', label: 'Manche' },
      { key: 'cou', label: 'Cou' },
      { key: 'longueur', label: 'Longueur' },
      { key: 'biceps', label: 'Biceps' },
      { key: 'poignet', label: 'Poignet' },
      { key: 'dos', label: 'Dos' }
    ]
  },
  bas: {
    label: 'Bas',
    description: 'Pantalon, jupe, pagne, short',
    champs: [
      { key: 'taille', label: 'Taille' },
      { key: 'hanches', label: 'Hanches' },
      { key: 'jambe', label: 'Jambe' },
      { key: 'entrejambe', label: 'Entrejambe' },
      { key: 'cuisse', label: 'Cuisse' },
      { key: 'genou', label: 'Genou' },
      { key: 'cheville', label: 'Cheville' }
    ]
  },
  robe: {
    label: 'Robe',
    description: 'Robe, boubou long',
    champs: [
      { key: 'poitrine', label: 'Poitrine' },
      { key: 'taille', label: 'Taille' },
      { key: 'hanches', label: 'Hanches' },
      { key: 'longueur_totale', label: 'Longueur totale' },
      { key: 'jupe', label: 'Jupe' },
      { key: 'bras', label: 'Bras' },
      { key: 'epaules', label: 'Épaules' }
    ]
  },
  complet: {
    label: 'Complet',
    description: 'Ensemble, complet, 2 pièces',
    champs: [
      { key: 'poitrine', label: 'Poitrine', section: 'Haut' },
      { key: 'taille', label: 'Taille', section: 'Haut' },
      { key: 'epaules', label: 'Épaules', section: 'Haut' },
      { key: 'manche', label: 'Manche', section: 'Haut' },
      { key: 'cou', label: 'Cou', section: 'Haut' },
      { key: 'longueur', label: 'Longueur haut', section: 'Haut' },
      { key: 'biceps', label: 'Biceps', section: 'Haut' },
      { key: 'poignet', label: 'Poignet', section: 'Haut' },
      { key: 'hanches', label: 'Hanches', section: 'Bas' },
      { key: 'jambe', label: 'Jambe', section: 'Bas' },
      { key: 'entrejambe', label: 'Entrejambe', section: 'Bas' },
      { key: 'cuisse', label: 'Cuisse', section: 'Bas' },
      { key: 'genou', label: 'Genou', section: 'Bas' },
      { key: 'cheville', label: 'Cheville', section: 'Bas' }
    ]
  }
};

const STATUT_LABELS = {
  en_cours: 'En cours',
  pret: 'Prêt',
  livre: 'Livré',
  annule: 'Annulé'
};

// ============================================================
// ÉTAT GLOBAL
// ============================================================
let currentClientDetailId = null;
let currentClientId = null;
let currentGenre = null;
let currentMesureId = null;
let currentMesureClientId = null;
let currentType = null;
let currentChamps = {};
let currentCustom = [];
let currentLabels = {};
let currentCreatedAt = null;
let currentCommande = { montantNet: '', avance: '', dateLivraison: '', statut: 'en_cours' };
let autosaveTimeout = null;
let saveTimer = null;
let filterUrgent = false;

// ============================================================
// NAVIGATION
// ============================================================
function goTo(screenId, data = {}) {
  history.pushState({ screen: screenId, data }, '');
  renderScreen(screenId, data);
}
function goBack() { history.back(); }

window.addEventListener('popstate', (e) => {
  const state = e.state;
  if (state) renderScreen(state.screen, state.data);
  else renderScreen('screen-clients', {});
});

function renderScreen(screenId, data) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(screenId).classList.add('active');
  window.scrollTo(0, 0);
  updateBottomNav(screenId);
  switch (screenId) {
    case 'screen-clients': renderClientsList(document.getElementById('search').value); break;
    case 'screen-client': renderClientDetail(data.clientId); break;
    case 'screen-client-form': renderClientForm(data.clientId); break;
    case 'screen-mesure': renderMesureForm(data.clientId, data.mesureId); break;
    case 'screen-settings': renderSettings(); break;
    case 'screen-guide': break;
  }
}

function updateBottomNav(screenId) {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.nav === screenId);
  });
}

function renderTodayDate() {
  const el = document.getElementById('today-date');
  if (!el) return;
  const date = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long', day: 'numeric', month: 'short'
  });
  el.textContent = date.toUpperCase();
}

// ============================================================
// URGENCE COMMANDES
// ============================================================
function isCommandeActive(m) {
  const s = m.commande?.statut || 'en_cours';
  return s !== 'livre' && s !== 'annule';
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const target = new Date(dateStr + 'T00:00:00');
  return Math.round((target - today) / (1000 * 60 * 60 * 24));
}

function getUrgenceLevel(m) {
  if (!isCommandeActive(m)) return null;
  const d = daysUntil(m.commande?.dateLivraison);
  if (d === null) return null;
  if (d < 0) return 'retard';
  if (d <= 3) return 'urgent';
  return null;
}

function computeReste(m) {
  const net = Number(m.commande?.montantNet) || 0;
  const av = Number(m.commande?.avance) || 0;
  if (!m.commande?.montantNet && !m.commande?.avance) return null;
  return Math.max(0, net - av);
}

async function getUrgenceSummary() {
  const mesures = await dbGetAll('mesures');
  const enRetard = mesures.filter(m => getUrgenceLevel(m) === 'retard');
  const urgentes = mesures.filter(m => getUrgenceLevel(m) === 'urgent');
  return { enRetard: enRetard.length, urgentes: urgentes.length, total: enRetard.length + urgentes.length };
}

// ============================================================
// ÉCRAN 1 : LISTE CLIENTS
// ============================================================
async function renderClientsList(filter = '') {
  const clients = await dbGetAll('clients');
  const allMesures = await dbGetAll('mesures');

  const countByClient = {};
  const mesuresByClient = {};
  for (const m of allMesures) {
    countByClient[m.clientId] = (countByClient[m.clientId] || 0) + 1;
    if (!mesuresByClient[m.clientId]) mesuresByClient[m.clientId] = [];
    mesuresByClient[m.clientId].push(m);
  }

  const clientsCountEl = document.getElementById('clients-count');
  const mesuresCountEl = document.getElementById('mesures-count');
  if (clientsCountEl) clientsCountEl.textContent = `${clients.length} client${clients.length > 1 ? 's' : ''}`;
  if (mesuresCountEl) mesuresCountEl.textContent = `${allMesures.length} mesure${allMesures.length > 1 ? 's' : ''}`;

  const { enRetard, urgentes, total } = await getUrgenceSummary();
  const banner = document.getElementById('urgent-banner');
  const bannerText = document.getElementById('urgent-text');
  const urgentBtn = document.getElementById('urgent-action');
  if (banner && bannerText) {
    if (total > 0) {
      const parts = [];
      if (enRetard > 0) parts.push(`${enRetard} en retard`);
      if (urgentes > 0) parts.push(`${urgentes} à livrer bientôt`);
      bannerText.textContent = parts.join(' · ');
      banner.style.display = 'flex';
      banner.classList.toggle('filter-on', filterUrgent);
      if (urgentBtn) urgentBtn.textContent = filterUrgent ? 'Tout voir' : 'Voir';
    } else {
      banner.style.display = 'none';
      if (filterUrgent) {
        filterUrgent = false;
        banner.classList.remove('filter-on');
      }
    }
  }

  const listHeadLabel = document.getElementById('list-head-label');
  if (listHeadLabel) {
    listHeadLabel.textContent = filterUrgent ? 'Commandes urgentes' : 'Nom / contact';
  }

  const list = document.getElementById('clients-list');
  let filtered = clients.filter(c =>
    (c.name || '').toLowerCase().includes(filter.toLowerCase()) ||
    (c.phone || '').includes(filter)
  );

  if (filterUrgent) {
    filtered = filtered.filter(c => {
      const cm = mesuresByClient[c.id] || [];
      return cm.some(m => getUrgenceLevel(m) !== null);
    });
  }

  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty">' +
      (filterUrgent
        ? 'Aucune commande urgente en cours.<br>Bonne nouvelle.'
        : (filter
          ? 'Aucun client ne correspond à cette recherche.<br>Essayez un autre nom ou numéro.'
          : 'Aucun client pour l\'instant.<br>Appuyez sur + pour ajouter.')) +
      '</div>';
    return;
  }

  list.innerHTML = filtered.map(c => {
    const count = countByClient[c.id] || 0;
    const initials = (c.name || '?').trim().split(/\s+/).slice(0, 2)
      .map(p => p[0] || '').join('').toUpperCase() || '?';
    const cliMesures = mesuresByClient[c.id] || [];
    const hasRetard = cliMesures.some(m => getUrgenceLevel(m) === 'retard');
    const hasUrgent = cliMesures.some(m => getUrgenceLevel(m) === 'urgent');
    const urgentClass = hasRetard ? ' retard-client' : (hasUrgent ? ' urgent-client' : '');

    return `
      <button class="client-row${urgentClass}" data-id="${c.id}" type="button">
        <span class="avatar" aria-hidden="true">${escapeHtml(initials)}</span>
        <span class="client-main">
          <span class="client-name">${escapeHtml(c.name || 'Sans nom')}</span>
          <span class="client-meta">${escapeHtml(c.phone || 'Téléphone non renseigné')}</span>
        </span>
        ${count > 0 ? `<span class="count">${String(count).padStart(2, '0')}</span>` : ''}
      </button>
    `;
  }).join('');

  list.querySelectorAll('.client-row').forEach(row => {
    row.addEventListener('click', () => {
      goTo('screen-client', { clientId: parseInt(row.dataset.id) });
    });
  });
}

// ============================================================
// ÉCRAN 2 : FICHE CLIENT
// ============================================================
async function renderClientDetail(clientId) {
  currentClientDetailId = clientId;
  const client = await dbGet('clients', clientId);
  if (!client) return;

  const parts = (client.name || 'Client').trim().split(/\s+/);
  const first = parts.shift() || '';
  const rest = parts.join(' ');
  document.getElementById('client-header-name').innerHTML =
    `${escapeHtml(first)}${rest ? ` <em>${escapeHtml(rest)}</em>` : ''}`;

  const info = document.getElementById('client-info');
  const genreLabel = client.genre === 'homme' ? 'Homme'
    : client.genre === 'femme' ? 'Femme' : 'Non renseigné';
  info.innerHTML = `
    <div>
      <span class="contact-label">Téléphone</span>
      <span class="contact-value">${escapeHtml(client.phone || 'Non renseigné')}</span>
    </div>
    <div>
      <span class="contact-label">Genre</span>
      <span class="contact-value">${genreLabel}</span>
    </div>
  `;

  const mesures = await getMesuresForClient(clientId);
  mesures.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  const list = document.getElementById('mesures-list');
  if (mesures.length === 0) {
    list.innerHTML = '<div class="empty">Aucune mesure.<br>Ajoutez la première mesure.</div>';
  } else {
    list.innerHTML = mesures.map(m => renderMesureRow(m)).join('');
    list.querySelectorAll('.measure-row').forEach(row => {
      row.addEventListener('click', () => {
        goTo('screen-mesure', { clientId, mesureId: parseInt(row.dataset.id) });
      });
    });
  }
}

function renderMesureRow(m) {
  const t = TEMPLATES[m.type];
  const typeLabel = t ? t.label : 'Mesure';
  const date = m.updatedAt
    ? new Date(m.updatedAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
    : '';
  const icon = TYPE_ICONS[m.type] || TYPE_ICONS.haut;
  const urgence = getUrgenceLevel(m);
  const rowClass = urgence === 'retard' ? ' retard' : (urgence === 'urgent' ? ' urgent' : '');

  const reste = computeReste(m);
  const statut = m.commande?.statut || 'en_cours';
  const hasCommande = m.commande && (m.commande.montantNet || m.commande.dateLivraison);
  const days = daysUntil(m.commande?.dateLivraison);

  let summary = '';
  if (hasCommande) {
    const parts = [];
    if (reste !== null && reste > 0) parts.push(`<span class="reste">Reste ${formatMontant(reste)}</span>`);
    else if (reste === 0) parts.push(`<span class="reste zero">Payé</span>`);
    if (m.commande.dateLivraison) {
      let dateLabel = '';
      if (days === null) dateLabel = new Date(m.commande.dateLivraison + 'T00:00:00').toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
      else if (days < 0) dateLabel = `Retard ${Math.abs(days)}j`;
      else if (days === 0) dateLabel = `Aujourd'hui`;
      else if (days === 1) dateLabel = `Demain`;
      else dateLabel = `Dans ${days}j`;
      parts.push(`<span class="${urgence === 'retard' ? 'reste retard' : ''}">${dateLabel}</span>`);
    }
    parts.push(`<span class="statut-mini ${statut}">${STATUT_LABELS[statut]}</span>`);
    summary = `<span class="measure-summary">${parts.join('<span class="dot">·</span>')}</span>`;
  } else {
    const fieldCount = Object.values(m.champs || {}).filter(v => v && v !== '').length;
    summary = `<span class="measure-date">${date}${fieldCount ? ` · ${fieldCount} mesure${fieldCount > 1 ? 's' : ''}` : ''}</span>`;
  }

  return `
    <button class="measure-row${rowClass}" data-id="${m.id}" type="button">
      <span class="measure-symbol" aria-hidden="true">${icon}</span>
      <span class="measure-info">
        <span class="measure-name">${escapeHtml(typeLabel)}</span>
        ${summary}
      </span>
      <span class="chevron" aria-hidden="true">›</span>
    </button>
  `;
}

// ============================================================
// ÉCRAN 3 : FORMULAIRE CLIENT
// ============================================================
async function renderClientForm(clientId) {
  const isEdit = clientId !== undefined && clientId !== null;
  const client = isEdit ? await dbGet('clients', clientId) : null;

  currentClientId = isEdit ? clientId : null;
  currentGenre = client?.genre || null;

  document.getElementById('client-form-title').innerHTML = isEdit
    ? 'Modifier le <em>client</em>'
    : 'Nouveau <em>client</em>';
  document.getElementById('form-client-name').value = client?.name || '';
  document.getElementById('form-client-phone').value = client?.phone || '';

  document.querySelectorAll('.genre-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.genre === currentGenre);
  });
}

async function saveClient() {
  const name = document.getElementById('form-client-name').value.trim();
  const phone = document.getElementById('form-client-phone').value.trim();

  if (!name && !phone) {
    await uiAlert('Entrez au moins un nom ou un téléphone.', 'Champ manquant');
    return;
  }

  // ✅ Vérification de la limite de clients
  if (!currentClientId && !isPremium()) {
    const clients = await dbGetAll('clients');
    if (clients.length >= getMaxClients()) {
      const action = await uiConfirm(
        `Vous avez atteint la limite de ${getMaxClients()} clients.\n\n` +
        `Regardez une courte publicité pour obtenir +5 clients, ou passez Premium pour ne plus avoir de limites.`,
        'Limite atteinte',
        'Regarder une pub'
      );
      if (action) showAdModal();
      return;
    }
  }

  if (currentClientId) {
    const client = await dbGet('clients', currentClientId);
    client.name = name;
    client.phone = phone;
    client.genre = currentGenre;
    client.updatedAt = Date.now();
    await dbPut('clients', client);
    goBack();
  } else {
    const newId = await dbAdd('clients', {
      name, phone, genre: currentGenre,
      createdAt: Date.now(), updatedAt: Date.now()
    });
    history.replaceState({ screen: 'screen-client', data: { clientId: newId } }, '');
    renderScreen('screen-client', { clientId: newId });
  }
}

// ============================================================
// ÉCRAN 4 : FORMULAIRE MESURE
// ============================================================
async function renderMesureForm(clientId, mesureId) {
  currentMesureClientId = clientId;
  currentMesureId = mesureId || null;
  currentType = null;
  currentChamps = {};
  currentCustom = [];
  currentLabels = {};
  currentCreatedAt = null;
  currentCommande = { montantNet: '', avance: '', dateLivraison: '', statut: 'en_cours' };

  const isEdit = mesureId !== undefined && mesureId !== null;

  const client = await dbGet('clients', clientId);
  const clientName = (client?.name || 'Client').toUpperCase();
  const today = new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase();
  document.getElementById('mesure-sub').textContent = `${clientName} · ${today}`;

  if (isEdit) {
    const m = await dbGet('mesures', mesureId);
    if (m) {
      currentType = m.type;
      currentChamps = { ...(m.champs || {}) };
      currentCustom = [...(m.custom || [])];
      currentLabels = { ...(m.labels || {}) };
      currentCreatedAt = m.createdAt || Date.now();
      if (m.commande) currentCommande = { ...currentCommande, ...m.commande };
    }
  }

  document.getElementById('mesure-title').innerHTML = isEdit
    ? 'Modifier la <em>mesure</em>'
    : 'Nouvelle <em>mesure</em>';
  document.getElementById('btn-delete-mesure').style.display = isEdit ? 'block' : 'none';

  const printBtn = document.getElementById('btn-print-mesure');
  if (printBtn) printBtn.style.display = isEdit ? 'flex' : 'none';

  const infoList = document.getElementById('type-info-list');
  infoList.innerHTML = Object.entries(TEMPLATES).map(([key, t]) => `
    <li><strong>${t.label}</strong> → ${t.description}</li>
  `).join('');

  applyInfoPanelState();
  renderTypeButtons();

  if (currentType) renderMesureFields();
  else document.getElementById('mesures-fields').innerHTML = '';

  renderCustomList();

  updateCommandeSection();
  bindCommandeInputs();
}

function updateCommandeSection() {
  const section = document.getElementById('commande-section');
  if (!section) return;
  section.style.display = currentType ? 'block' : 'none';

  document.getElementById('cmd-montant').value = currentCommande.montantNet || '';
  document.getElementById('cmd-avance').value = currentCommande.avance || '';
  document.getElementById('cmd-date').value = currentCommande.dateLivraison || '';

  updateResteDisplay();
  updateStatutButtons();
  updateStatutBadge();
}

function updateResteDisplay() {
  const el = document.getElementById('cmd-reste');
  if (!el) return;
  const net = Number(currentCommande.montantNet) || 0;
  const av = Number(currentCommande.avance) || 0;

  if (!currentCommande.montantNet && !currentCommande.avance) {
    el.textContent = '—';
    el.className = 'computed-value empty';
    return;
  }
  const reste = Math.max(0, net - av);
  el.textContent = formatMontant(reste);
  el.className = 'computed-value' + (reste === 0 ? ' zero' : '');
}

function updateStatutButtons() {
  document.querySelectorAll('.statut-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.statut === currentCommande.statut);
  });
}

function updateStatutBadge() {
  const badge = document.getElementById('commande-statut-badge');
  if (!badge) return;
  badge.textContent = STATUT_LABELS[currentCommande.statut] || 'En cours';
  badge.className = 'statut-badge ' + currentCommande.statut;
}

function bindCommandeInputs() {
  const montant = document.getElementById('cmd-montant');
  const avance = document.getElementById('cmd-avance');
  const date = document.getElementById('cmd-date');
  if (!montant || montant._bound) return;
  montant._bound = true;

  montant.addEventListener('input', () => {
    currentCommande.montantNet = montant.value;
    updateResteDisplay();
    scheduleSave();
  });
  avance.addEventListener('input', () => {
    currentCommande.avance = avance.value;
    updateResteDisplay();
    scheduleSave();
  });
  date.addEventListener('change', () => {
    currentCommande.dateLivraison = date.value;
    scheduleSave();
  });
  document.querySelectorAll('.statut-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      currentCommande.statut = btn.dataset.statut;
      updateStatutButtons();
      updateStatutBadge();
      scheduleSave();
    });
  });
}

function renderTypeButtons() {
  dbGet('clients', currentMesureClientId).then(client => {
    const genre = client?.genre;
    const hiddenForHomme = ['robe'];
    const allTypes = Object.keys(TEMPLATES);
    const types = (genre === 'homme')
      ? allTypes.filter(t => !hiddenForHomme.includes(t))
      : allTypes;

    const container = document.getElementById('type-buttons');
    container.innerHTML = types.map(key => {
      const t = TEMPLATES[key];
      const active = key === currentType ? ' active' : '';
      return `
        <button class="type-btn${active}" data-type="${key}" type="button">
          <span class="type-label">${t.label}</span>
          <span class="type-desc">${t.description}</span>
        </button>
      `;
    }).join('');

    container.querySelectorAll('.type-btn').forEach(btn => {
      btn.addEventListener('click', () => onTypeChange(btn.dataset.type));
    });
  });
}

async function onTypeChange(newType) {
  if (newType === currentType) return;

  const hasData = Object.values(currentChamps).some(v => v && v !== '')
    || currentCustom.some(c => c.label || c.value)
    || Object.keys(currentLabels).length > 0;

  if (hasData && currentType !== null) {
    const confirmed = await uiConfirm(
      `Vous avez déjà rempli « ${TEMPLATES[currentType].label} ».\n\n` +
      `Changer pour « ${TEMPLATES[newType].label} » effacera les champs incompatibles.\n\n` +
      `Pour un ensemble, choisissez « Complet ».\n` +
      `Pour deux vêtements séparés, créez deux mesures.`,
      'Changer de type ?',
      'Changer'
    );
    if (!confirmed) return;
  }

  const newKeys = TEMPLATES[newType].champs.map(f => f.key);
  const kept = {};
  const keptLabels = {};
  for (const key of newKeys) {
    if (currentChamps[key] !== undefined) kept[key] = currentChamps[key];
    if (currentLabels[key] !== undefined) keptLabels[key] = currentLabels[key];
  }
  currentChamps = kept;
  currentLabels = keptLabels;
  currentType = newType;

  document.querySelectorAll('.type-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.type === newType);
  });

  renderMesureFields();
  updateCommandeSection();
  scheduleSave();
}

function renderMesureFields() {
  if (!currentType) return;
  const t = TEMPLATES[currentType];
  const container = document.getElementById('mesures-fields');

  const hasSections = t.champs.some(f => f.section);
  let html = '';

  if (hasSections) {
    const sections = {};
    for (const f of t.champs) {
      const s = f.section || 'Autres';
      if (!sections[s]) sections[s] = [];
      sections[s].push(f);
    }
    for (const [section, fields] of Object.entries(sections)) {
      html += `<div class="mesure-section-title">— ${section}</div>`;
      html += fields.map(f => renderField(f)).join('');
    }
  } else {
    html = t.champs.map(f => renderField(f)).join('');
  }

  container.innerHTML = html;

  container.querySelectorAll('input[data-key]').forEach(input => {
    input.addEventListener('input', () => {
      currentChamps[input.dataset.key] = input.value;
      scheduleSave();
    });
  });

  container.querySelectorAll('.field-rename').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      renameField(btn.dataset.key);
    });
  });
}

function renderField(field) {
  const val = currentChamps[field.key] || '';
  const label = currentLabels[field.key] || field.label;
  const iconSvg = SVG_ICONS[field.key] || SVG_ICONS.longueur;
  return `
    <div class="mesure-field">
      <span class="field-icon">${iconSvg}</span>
      <div class="field-left">
        <label>${escapeHtml(label)}</label>
        <button class="field-rename" data-key="${field.key}" type="button" title="Renommer">✎</button>
      </div>
      <input type="number" inputmode="decimal" data-key="${field.key}" value="${val}" placeholder="0">
      <span class="unit">cm</span>
    </div>
  `;
}

async function renameField(key) {
  const t = TEMPLATES[currentType];
  const field = t.champs.find(f => f.key === key);
  if (!field) return;
  const currentLabel = currentLabels[key] || field.label;
  const newLabel = await uiPrompt(`Nom affiché pour « ${field.label} »`, currentLabel, 'Renommer le champ');
  if (newLabel === null) return;
  const trimmed = newLabel.trim();
  if (!trimmed) delete currentLabels[key];
  else currentLabels[key] = trimmed;
  renderMesureFields();
  scheduleSave();
}

// ============================================================
// MESURES PERSONNALISÉES
// ============================================================
function renderCustomList() {
  const container = document.getElementById('custom-list');
  container.innerHTML = currentCustom.map((c, i) => `
    <div class="custom-row" data-index="${i}">
      <input type="text" class="custom-name" placeholder="Nom de la mesure" value="${escapeHtml(c.label || '')}">
      <input type="number" class="custom-value" placeholder="0" value="${c.value || ''}">
      <button class="btn-remove" data-remove="${i}" type="button">×</button>
    </div>
  `).join('');

  container.querySelectorAll('.custom-row').forEach(row => {
    const i = parseInt(row.dataset.index);
    row.querySelector('.custom-name').addEventListener('input', (e) => {
      currentCustom[i].label = e.target.value;
      scheduleSave();
    });
    row.querySelector('.custom-value').addEventListener('input', (e) => {
      currentCustom[i].value = e.target.value;
      scheduleSave();
    });
    row.querySelector('.btn-remove').addEventListener('click', () => {
      currentCustom.splice(i, 1);
      renderCustomList();
      scheduleSave();
    });
  });
}

function addCustomMesure() {
  currentCustom.push({ label: '', value: '' });
  renderCustomList();
  const rows = document.querySelectorAll('.custom-row');
  const last = rows[rows.length - 1];
  if (last) last.querySelector('.custom-name').focus();
}

// ============================================================
// SAUVEGARDE
// ============================================================
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveMesure, 400);
}

async function saveMesure() {
  if (!currentType) return;

  // ✅ Vérification de la limite de mesures
  if (!currentMesureId && !isPremium()) {
    const mesures = await getMesuresForClient(currentMesureClientId);
    if (mesures.length >= LIMITS.MAX_FREE_MESURES) {
      const action = await uiConfirm(
        `Ce client a déjà ${LIMITS.MAX_FREE_MESURES} mesures (limite gratuite).\n\n` +
        `Passez Premium pour ajouter des mesures illimitées.`,
        'Limite atteinte',
        'Passer Premium'
      );
      if (action) goTo('screen-settings', {});
      return;
    }
  }

  const data = {
    clientId: currentMesureClientId,
    type: currentType,
    champs: { ...currentChamps },
    custom: [...currentCustom],
    labels: { ...currentLabels },
    commande: { ...currentCommande },
    updatedAt: Date.now()
  };

  if (currentMesureId) {
    data.id = currentMesureId;
    data.createdAt = currentCreatedAt;
    await dbPut('mesures', data);
  } else {
    data.createdAt = Date.now();
    currentMesureId = await dbAdd('mesures', data);
    currentCreatedAt = data.createdAt;
    document.getElementById('btn-delete-mesure').style.display = 'block';
    const printBtn = document.getElementById('btn-print-mesure');
    if (printBtn) printBtn.style.display = 'flex';
  }

  showAutosaveIndicator();
}

function showAutosaveIndicator() {
  const el = document.getElementById('autosave-status');
  if (!el) return;
  el.classList.add('show');
  clearTimeout(autosaveTimeout);
  autosaveTimeout = setTimeout(() => el.classList.remove('show'), 1500);
}

async function saveAndClose() {
  if (!currentType) {
    await uiAlert('Choisissez d\'abord un type de vêtement.', 'Type manquant');
    return;
  }
  await saveMesure();
  showToast('Mesure enregistrée');
  setTimeout(() => goBack(), 500);
}

function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2000);
}

// ============================================================
// GÉNÉRATION PDF
// ============================================================
async function generatePDF() {
  if (!isPremium()) {
    const action = await uiConfirm(
      `L'export PDF est réservé aux membres Premium.\n\nPassez Premium pour 500 FCFA/mois pour débloquer cette fonctionnalité.`,
      'Fonctionnalité Premium',
      'Découvrir Premium'
    );
    if (action) goTo('screen-settings', {});
    return;
  }

  if (!currentMesureId) {
    await uiAlert('Enregistrez la mesure d\'abord.', 'PDF');
    return;
  }

  const mesure = await dbGet('mesures', currentMesureId);
  const client = await dbGet('clients', currentMesureClientId);
  if (!mesure || !client) {
    await uiAlert('Impossible de charger les données.', 'PDF');
    return;
  }

  const profile = getProfile();
  const t = TEMPLATES[mesure.type];
  const typeLabel = t ? t.label : 'Mesure';

  const atelierName = [profile.prenom, profile.nom].filter(Boolean).join(' ') || profile.atelier || 'Mon atelier';
  const atelierInfoParts = [];
  if (profile.atelier && atelierName !== profile.atelier) atelierInfoParts.push(profile.atelier);
  if (profile.adresse) atelierInfoParts.push(profile.adresse);
  if (profile.telephone) atelierInfoParts.push('Tél. ' + profile.telephone);

  const champs = t ? t.champs : [];
  const champsRows = champs.map(f => {
    const val = mesure.champs?.[f.key];
    if (!val) return '';
    const label = mesure.labels?.[f.key] || f.label;
    return `<tr><td>${escapeHtml(label)}</td><td class="value">${escapeHtml(val)} cm</td></tr>`;
  }).filter(Boolean).join('');

  const customRows = (mesure.custom || []).filter(c => c.label && c.value).map(c =>
    `<tr><td>${escapeHtml(c.label)}</td><td class="value">${escapeHtml(c.value)} cm</td></tr>`
  ).join('');

  const cmd = mesure.commande || {};
  const hasCommande = cmd.montantNet || cmd.dateLivraison;
  let commandeHTML = '';
  if (hasCommande) {
    const net = Number(cmd.montantNet) || 0;
    const av = Number(cmd.avance) || 0;
    const reste = Math.max(0, net - av);
    const devise = profile.devise || 'FCFA';

    commandeHTML = `
      <div class="pdf-commande">
        <div class="pdf-commande-title">Détails de la commande</div>
        ${net > 0 ? `<div class="pdf-commande-line"><span>Montant net</span><span>${net.toLocaleString('fr-FR')} ${devise}</span></div>` : ''}
        ${av > 0 ? `<div class="pdf-commande-line"><span>Avance</span><span>${av.toLocaleString('fr-FR')} ${devise}</span></div>` : ''}
        ${net > 0 ? `<div class="pdf-commande-line total"><span>Reste à payer</span><span>${reste.toLocaleString('fr-FR')} ${devise}</span></div>` : ''}
        ${cmd.dateLivraison ? `<div class="pdf-commande-line"><span>Date de livraison</span><span>${new Date(cmd.dateLivraison + 'T00:00:00').toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}</span></div>` : ''}
        ${cmd.statut ? `<div class="pdf-commande-line"><span>Statut</span><span>${STATUT_LABELS[cmd.statut] || cmd.statut}</span></div>` : ''}
      </div>
    `;
  }

  const dateDoc = new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });

  document.getElementById('print-area').innerHTML = `
    <div class="pdf-doc">
      <div class="pdf-header">
        <div class="pdf-atelier-name">${escapeHtml(atelierName)}</div>
        ${atelierInfoParts.length ? `<div class="pdf-atelier-info">${atelierInfoParts.map(escapeHtml).join(' · ')}</div>` : ''}
      </div>

      <div class="pdf-meta-row">
        <div class="pdf-meta-block">
          <div class="pdf-meta-label">Client</div>
          <div class="pdf-meta-value">${escapeHtml(client.name || '—')}</div>
          ${client.phone ? `<div class="pdf-atelier-info">${escapeHtml(client.phone)}</div>` : ''}
        </div>
        <div class="pdf-meta-block" style="text-align: right;">
          <div class="pdf-meta-label">Date</div>
          <div class="pdf-meta-value">${dateDoc}</div>
        </div>
      </div>

      <div class="pdf-title">Mesures — ${escapeHtml(typeLabel)}</div>
      <div class="pdf-subtitle">Relevé de mesures</div>

      <table class="pdf-table">
        <thead>
          <tr><th>Mesure</th><th style="text-align:right;">Valeur</th></tr>
        </thead>
        <tbody>
          ${champsRows || customRows ? (champsRows + customRows) : '<tr><td colspan="2" style="text-align:center;color:#888;">Aucune mesure renseignée.</td></tr>'}
        </tbody>
      </table>

      ${commandeHTML}

      <div class="pdf-footer">
        Document généré par Carnet — ${dateDoc}<br>
        Merci de votre confiance.
      </div>
    </div>
  `;

  await new Promise(r => setTimeout(r, 100));
  window.print();
}

// ============================================================
// PANNEAU INFO
// ============================================================
function applyInfoPanelState() {
  const open = localStorage.getItem('info-type-open') !== 'false';
  const panel = document.getElementById('type-info');
  const btn = document.getElementById('toggle-type-btn');
  if (!panel || !btn) return;
  if (open) { panel.classList.remove('hidden'); btn.textContent = 'Guide ▾'; }
  else { panel.classList.add('hidden'); btn.textContent = 'Guide ▸'; }
}

function toggleInfoPanel() {
  const panel = document.getElementById('type-info');
  const btn = document.getElementById('toggle-type-btn');
  if (!panel || !btn) return;
  const isOpen = !panel.classList.contains('hidden');
  if (isOpen) {
    panel.classList.add('hidden');
    btn.textContent = 'Guide ▸';
    localStorage.setItem('info-type-open', 'false');
  } else {
    panel.classList.remove('hidden');
    btn.textContent = 'Guide ▾';
    localStorage.setItem('info-type-open', 'true');
  }
}

// ============================================================
// SUPPRESSION
// ============================================================
async function deleteMesure() {
  if (!currentMesureId) return;
  const ok = await uiConfirm('Cette mesure sera définitivement supprimée.', 'Supprimer la mesure ?', 'Supprimer', true);
  if (!ok) return;
  await dbDelete('mesures', currentMesureId);
  goBack();
}

async function deleteClient() {
  if (!currentClientDetailId) return;
  const mesures = await getMesuresForClient(currentClientDetailId);
  const client = await dbGet('clients', currentClientDetailId);
  const count = mesures.length;
  const msg = count > 0
    ? `Le client « ${client.name} » et ses ${count} mesure${count > 1 ? 's' : ''} seront définitivement supprimés.`
    : `Le client « ${client.name} » sera définitivement supprimé.`;
  const ok = await uiConfirm(msg, 'Supprimer le client ?', 'Supprimer', true);
  if (!ok) return;
  for (const m of mesures) await dbDelete('mesures', m.id);
  await dbDelete('clients', currentClientDetailId);
  goBack();
}

// ============================================================
// ÉCRAN 5 : PARAMÈTRES
// ============================================================
async function renderSettings() {
  document.getElementById('app-version').textContent = APP_VERSION;

  const profile = getProfile();
  document.getElementById('profile-nom').value = profile.nom || '';
  document.getElementById('profile-prenom').value = profile.prenom || '';
  document.getElementById('profile-telephone').value = profile.telephone || '';
  document.getElementById('profile-atelier').value = profile.atelier || '';
  document.getElementById('profile-adresse').value = profile.adresse || '';
  document.getElementById('profile-devise').value = profile.devise || 'FCFA';

  // Mise à jour de l'UI Premium
  const license = getLicense();
  const badge = document.getElementById('premium-badge');
  const desc = document.getElementById('premium-desc');
  const btnUpgrade = document.getElementById('btn-upgrade');

  if (license.isPremium) {
    badge.textContent = 'PREMIUM';
    badge.classList.add('active');
    desc.textContent = 'Merci de votre soutien !';
    btnUpgrade.textContent = 'Gérer l\'abonnement';
    btnUpgrade.onclick = async () => {
      const reset = await uiConfirm("Voulez-vous annuler votre abonnement Premium (pour tester) ?", "Abonnement", "Oui, annuler");
      if (reset) {
        const l = getLicense(); l.isPremium = false; setLicense(l); renderSettings();
      }
    };
  } else {
    badge.textContent = 'GRATUIT';
    badge.classList.remove('active');
    desc.textContent = `Limité à ${getMaxClients()} clients et ${LIMITS.MAX_FREE_MESURES} mesures/client`;
    btnUpgrade.textContent = 'Passer Premium (500 F/mois)';
    btnUpgrade.onclick = simulateUpgrade;
  }

  const clients = await dbGetAll('clients');
  const mesures = await dbGetAll('mesures');

  const commandesActives = mesures.filter(m =>
    m.commande &&
    (m.commande.montantNet || m.commande.dateLivraison) &&
    m.commande.statut !== 'annule'
  );

  const commandesEnRetard = commandesActives.filter(m => getUrgenceLevel(m) === 'retard');

  const resteTotal = commandesActives.reduce((sum, m) => sum + (computeReste(m) || 0), 0);
  const resteEnRetard = commandesEnRetard.reduce((sum, m) => sum + (computeReste(m) || 0), 0);

  document.getElementById('stats-clients').textContent = clients.length;
  document.getElementById('stats-mesures').textContent = mesures.length;
  document.getElementById('stats-commandes').textContent = commandesActives.length;

  const resteEl = document.getElementById('stats-reste');
  resteEl.textContent = resteTotal > 0 ? resteTotal.toLocaleString('fr-FR') : '0';

  const subEl = document.getElementById('stats-reste-sub');
  if (subEl) {
    if (resteEnRetard > 0) {
      subEl.textContent = `⚠ ${resteEnRetard.toLocaleString('fr-FR')} en retard`;
      subEl.style.display = 'inline-block';
      subEl.className = 'stat-sub danger';
    } else {
      subEl.style.display = 'none';
    }
  }
}

function saveProfile() {
  const profile = {
    nom: document.getElementById('profile-nom').value.trim(),
    prenom: document.getElementById('profile-prenom').value.trim(),
    telephone: document.getElementById('profile-telephone').value.trim(),
    atelier: document.getElementById('profile-atelier').value.trim(),
    adresse: document.getElementById('profile-adresse').value.trim(),
    devise: document.getElementById('profile-devise').value
  };
  setProfile(profile);
  showToast('Profil enregistré');
}

// ============================================================
// SIMULATION PREMIUM (Temporaire)
// ============================================================
async function simulateUpgrade() {
  const confirm = await uiConfirm(
    "Ceci est une simulation de paiement.\nEn production, cela ouvrira la page de paiement Mobile Money.\n\nActiver Premium pour ce téléphone ?",
    "Passer Premium",
    "Simuler l'achat"
  );
  if (!confirm) return;

  const license = getLicense();
  license.isPremium = true;
  setLicense(license);
  
  await uiAlert("Vous êtes maintenant Premium !\nToutes les limites sont levées.", "Bienvenue !");
  renderSettings();
  renderClientsList();
}

// ============================================================
// MODALE PUBLICITÉ (Rewarded Ad)
// ============================================================
function showAdModal() {
  const modal = document.getElementById('ad-modal');
  const timerEl = document.getElementById('ad-timer');
  const btnClaim = document.getElementById('btn-ad-claim');
  const btnCancel = document.getElementById('btn-ad-cancel');
  
  modal.style.display = 'flex';
  btnClaim.style.display = 'none';
  btnCancel.style.display = 'block';
  let timeLeft = 3;
  timerEl.textContent = timeLeft;

  // ⚠️ TODO POUR LA MONÉTISATION RÉELLE :
  // Remplacer ce setInterval par l'appel au SDK AdMob (Rewarded Ad).
  // Exemple (Capacitor AdMob) :
  // AdMob.showRewardVideoAd().then(() => { ... });

  const interval = setInterval(() => {
    timeLeft--;
    timerEl.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(interval);
      timerEl.textContent = '✓';
      btnCancel.style.display = 'none';
      btnClaim.style.display = 'block';
    }
  }, 1000);

  modal._cleanupAd = () => clearInterval(interval);
}

function closeAdModal(claim) {
  const modal = document.getElementById('ad-modal');
  if (modal._cleanupAd) modal._cleanupAd();
  modal.style.display = 'none';

  if (claim) {
    const license = getLicense();
    license.extraClients = (license.extraClients || 0) + LIMITS.AD_REWARD_CLIENTS;
    setLicense(license);
    showToast(`+${LIMITS.AD_REWARD_CLIENTS} clients débloqués !`);
    renderScreen('screen-clients', {});
    if (document.getElementById('screen-settings').classList.contains('active')) {
      renderSettings();
    }
  }
}

// ============================================================
// EXPORT / IMPORT
// ============================================================
async function exportData() {
  const clients = await dbGetAll('clients');
  const mesures = await dbGetAll('mesures');
  const profile = getProfile();

  const data = {
    app: 'carnet-mesures',
    version: APP_VERSION,
    exportedAt: new Date().toISOString(),
    profile,
    clients,
    mesures
  };

  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const filename = `carnet-mesures-${new Date().toISOString().slice(0, 10)}.json`;

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  markExportDone();
  showToast('Données exportées');
}

async function shareExport() {
  const clients = await dbGetAll('clients');
  const mesures = await dbGetAll('mesures');
  const profile = getProfile();

  const data = {
    app: 'carnet-mesures',
    version: APP_VERSION,
    exportedAt: new Date().toISOString(),
    profile, clients, mesures
  };

  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const filename = `carnet-mesures-${new Date().toISOString().slice(0, 10)}.json`;
  const file = new File([blob], filename, { type: 'application/json' });

  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({
        files: [file],
        title: 'Sauvegarde Carnet Mesures',
        text: 'Voici ma sauvegarde de données.'
      });
      markExportDone();
    } catch (err) {
      if (err.name !== 'AbortError') await uiAlert('Partage annulé ou impossible.', 'Partage');
    }
  } else {
    await uiAlert('Le partage direct n\'est pas disponible sur ce téléphone. Utilisez « Exporter mes données » à la place.', 'Partage indisponible');
  }
}

async function importData(file) {
  try {
    const text = await file.text();
    const data = JSON.parse(text);

    if (!data.clients || !data.mesures) {
      await uiAlert('Fichier invalide. Il manque des données.', 'Erreur');
      return;
    }

    const ok = await uiConfirm(
      `Ce fichier contient ${data.clients.length} client(s) et ${data.mesures.length} mesure(s).\n\nToutes vos données actuelles seront REMPLACÉES.`,
      'Importer des données ?',
      'Importer'
    );
    if (!ok) return;

    await dbClear('clients');
    await dbClear('mesures');

    for (const c of data.clients) await dbPut('clients', c);
    for (const m of data.mesures) await dbPut('mesures', m);
    if (data.profile) setProfile({ ...getProfile(), ...data.profile });

    await uiAlert('Import réussi.', 'Terminé');
    await renderSettings();
    showToast('Import réussi');
  } catch (err) {
    await uiAlert('Erreur lors de l\'import : ' + err.message, 'Erreur');
  }
}

// ============================================================
// RAPPEL DE SAUVEGARDE
// ============================================================
const LAST_EXPORT_KEY = 'last-export-date';
const BACKUP_DISMISS_KEY = 'backup-dismissed-until';
const BACKUP_REMINDER_DAYS = 7;
const BACKUP_DISMISS_DAYS = 3;

async function checkBackupReminder() {
  const clients = await dbGetAll('clients');
  if (clients.length === 0) return;

  const lastExport = localStorage.getItem(LAST_EXPORT_KEY);
  const dismissedUntil = localStorage.getItem(BACKUP_DISMISS_KEY);
  if (dismissedUntil && Date.now() < parseInt(dismissedUntil)) return;

  let shouldShow = false, daysText = '';
  if (!lastExport) {
    shouldShow = true;
    daysText = 'Aucune sauvegarde effectuée.';
  } else {
    const daysSince = Math.floor((Date.now() - parseInt(lastExport)) / (1000 * 60 * 60 * 24));
    if (daysSince >= BACKUP_REMINDER_DAYS) {
      shouldShow = true;
      daysText = `Dernière sauvegarde : ${daysSince} jours.`;
    }
  }
  if (shouldShow) {
    document.getElementById('backup-banner-text').textContent = daysText;
    document.getElementById('backup-banner').style.display = 'flex';
  }
}

function dismissBackupReminder() {
  const until = Date.now() + (BACKUP_DISMISS_DAYS * 24 * 60 * 60 * 1000);
  localStorage.setItem(BACKUP_DISMISS_KEY, until.toString());
  document.getElementById('backup-banner').style.display = 'none';
}

function markExportDone() {
  localStorage.setItem(LAST_EXPORT_KEY, Date.now().toString());
  localStorage.removeItem(BACKUP_DISMISS_KEY);
  const banner = document.getElementById('backup-banner');
  if (banner) banner.style.display = 'none';
}

// ============================================================
// SERVICE WORKER
// ============================================================
function setupServiceWorkerUpdate() {
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.register('sw.js').then((registration) => {
    setInterval(() => registration.update(), 60 * 60 * 1000);
    registration.addEventListener('updatefound', () => {
      const newWorker = registration.installing;
      if (!newWorker) return;
      newWorker.addEventListener('statechange', () => {
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          document.getElementById('update-banner').style.display = 'flex';
        }
      });
    });
  }).catch(() => {});

  // document.getElementById('update-banner-action').addEventListener('click', () => {
  //   if (navigator.serviceWorker.controller) {
  //     navigator.serviceWorker.getRegistration().then(reg => {
  //       if (reg && reg.waiting) reg.waiting.postMessage({ type: 'SKIP_WAITING' });
  //     });
  //     setTimeout(() => window.location.reload(), 300);
  //   }
  // });
}

// ============================================================
// MODALES
// ============================================================
function uiAlert(message, title = 'Information') {
  return new Promise((resolve) => {
    showModal({
      title, message,
      buttons: [{ label: 'OK', type: 'confirm', action: () => { hideModal(); resolve(); } }]
    });
  });
}
function uiConfirm(message, title = 'Confirmation', confirmLabel = 'Confirmer', danger = false) {
  return new Promise((resolve) => {
    showModal({
      title, message,
      buttons: [
        { label: 'Annuler', type: 'cancel', action: () => { hideModal(); resolve(false); } },
        { label: confirmLabel, type: danger ? 'danger' : 'confirm', action: () => { hideModal(); resolve(true); } }
      ]
    });
  });
}
function uiPrompt(message, defaultValue = '', title = 'Modifier') {
  return new Promise((resolve) => {
    showModal({
      title, message,
      input: { value: defaultValue, placeholder: '' },
      buttons: [
        { label: 'Annuler', type: 'cancel', action: () => { hideModal(); resolve(null); } },
        { label: 'Valider', type: 'confirm', action: (inputValue) => { hideModal(); resolve(inputValue); } }
      ]
    });
  });
}

function showModal({ title, message, input, buttons }) {
  const overlay = document.getElementById('modal-overlay');
  document.getElementById('modal-title').textContent = title || '';
  document.getElementById('modal-message').textContent = message || '';

  const inputEl = document.getElementById('modal-input');
  if (input) {
    inputEl.style.display = 'block';
    inputEl.value = input.value || '';
    inputEl.placeholder = input.placeholder || '';
    setTimeout(() => { inputEl.focus(); inputEl.select(); }, 100);
  } else {
    inputEl.style.display = 'none';
    inputEl.value = '';
  }

  const actionsEl = document.getElementById('modal-actions');
  actionsEl.innerHTML = '';
  buttons.forEach(btn => {
    const b = document.createElement('button');
    b.textContent = btn.label;
    b.className = 'modal-btn-' + btn.type;
    b.type = 'button';
    b.addEventListener('click', () => {
      const val = input ? inputEl.value : undefined;
      btn.action(val);
    });
    actionsEl.appendChild(b);
  });

  overlay.style.display = 'flex';
  overlay.classList.add('open');

  const handleKey = (e) => {
    if (e.key === 'Enter' && input) {
      const confirmBtn = actionsEl.querySelector('.modal-btn-confirm');
      if (confirmBtn) confirmBtn.click();
    }
    if (e.key === 'Escape') {
      const cancelBtn = actionsEl.querySelector('.modal-btn-cancel');
      if (cancelBtn) cancelBtn.click();
    }
  };
  document.addEventListener('keydown', handleKey);
  overlay._cleanup = () => document.removeEventListener('keydown', handleKey);
}

function hideModal() {
  const overlay = document.getElementById('modal-overlay');
  if (overlay._cleanup) overlay._cleanup();
  overlay.style.display = 'none';
  overlay.classList.remove('open');
}

// ============================================================
// UTILITAIRES
// ============================================================
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}

// ============================================================
// MISE À JOUR FORCÉE
// ============================================================
const UPDATE_CHECK_URL = 'https://raw.githubusercontent.com/Shpeace/carnet-mesures/main/version.json';

async function checkForForcedUpdate() {
  try {
    if (!navigator.onLine) return;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(UPDATE_CHECK_URL + '?t=' + Date.now(), {
      signal: controller.signal,
      cache: 'no-store'
    });
    clearTimeout(timeout);

    if (!response.ok) return;

    const config = await response.json();

    if (config.force_update && isVersionLower(APP_VERSION, config.min_version)) {
      showForceUpdateScreen(config.message || 'Mise à jour requise.', config.update_url);
    }
  } catch (err) {
    console.log('Vérification de mise à jour ignorée :', err.message);
  }
}

function isVersionLower(current, required) {
  if (!current || !required) return false;
  const c = String(current).split('.').map(n => parseInt(n, 10) || 0);
  const r = String(required).split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(c.length, r.length);
  for (let i = 0; i < len; i++) {
    const cv = c[i] || 0;
    const rv = r[i] || 0;
    if (cv < rv) return true;
    if (cv > rv) return false;
  }
  return false;
}

function showForceUpdateScreen(message, url) {
  document.body.innerHTML = `
    <div class="force-update">
      <div class="force-update-card">
        <div class="force-update-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
          </svg>
        </div>
        <h1>Mise à jour requise</h1>
        <p>${escapeHtml(message)}</p>
        <a href="${escapeHtml(url)}" target="_blank" rel="noopener" class="force-update-btn">
          Télécharger la nouvelle version
        </a>
        <p class="force-update-hint">
          Vos données restent sur ce téléphone.<br>
          Exportez-les avant si nécessaire.
        </p>
      </div>
    </div>
  `;
}

// ============================================================
// INIT
// ============================================================
async function init() {
  await openDB();
  history.replaceState({ screen: 'screen-clients', data: {} }, '');

  renderTodayDate();

  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => goTo(item.dataset.nav, {}));
  });

  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => goBack());
  });

  document.getElementById('search').addEventListener('input', (e) => {
    renderClientsList(e.target.value);
  });

  document.getElementById('btn-add-client').addEventListener('click', () => {
    goTo('screen-client-form', {});
  });

  document.getElementById('btn-add-mesure').addEventListener('click', () => {
    goTo('screen-mesure', { clientId: currentClientDetailId });
  });

  const btnTop = document.getElementById('btn-add-mesure-top');
  if (btnTop) {
    btnTop.addEventListener('click', () => {
      goTo('screen-mesure', { clientId: currentClientDetailId });
    });
  }

  document.querySelectorAll('.genre-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      currentGenre = btn.dataset.genre;
      document.querySelectorAll('.genre-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.genre === currentGenre);
      });
    });
  });

  document.getElementById('btn-save-client').addEventListener('click', saveClient);

  document.getElementById('btn-edit-client').addEventListener('click', () => {
    goTo('screen-client-form', { clientId: currentClientDetailId });
  });

  document.getElementById('btn-save-mesure').addEventListener('click', saveAndClose);
  document.getElementById('btn-delete-client').addEventListener('click', deleteClient);
  document.getElementById('btn-delete-mesure').addEventListener('click', deleteMesure);
  document.getElementById('btn-add-custom').addEventListener('click', addCustomMesure);
  document.getElementById('toggle-type-btn').addEventListener('click', toggleInfoPanel);

  const printBtn = document.getElementById('btn-print-mesure');
  if (printBtn) printBtn.addEventListener('click', generatePDF);

  document.getElementById('btn-export').addEventListener('click', exportData);
  document.getElementById('btn-share-export').addEventListener('click', shareExport);
  document.getElementById('btn-import').addEventListener('click', () => {
    document.getElementById('import-file').click();
  });
  document.getElementById('import-file').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) importData(file);
    e.target.value = '';
  });

  document.getElementById('btn-save-profile').addEventListener('click', saveProfile);

  document.getElementById('backup-banner-action').addEventListener('click', () => {
    goTo('screen-settings', {});
    document.getElementById('backup-banner').style.display = 'none';
  });
  document.getElementById('backup-banner-close').addEventListener('click', dismissBackupReminder);

  const urgentBtn = document.getElementById('urgent-action');
  if (urgentBtn) {
    urgentBtn.addEventListener('click', () => {
      filterUrgent = !filterUrgent;
      renderClientsList(document.getElementById('search').value);
    });
  }

  // Écouteurs de la modale Pub
  document.getElementById('btn-ad-cancel').addEventListener('click', () => closeAdModal(false));
  document.getElementById('btn-ad-claim').addEventListener('click', () => closeAdModal(true));

  checkForForcedUpdate();
  renderScreen('screen-clients', {});
  setupServiceWorkerUpdate();
  checkBackupReminder();
}

init();