// ============================================================
// BASE DE DONNÉES (IndexedDB)
// ============================================================
const DB_NAME = 'carnet-mesures';
const DB_VERSION = 2;
let db;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('clients')) {
        db.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
      }
      if (!db.objectStoreNames.contains('mesures')) {
        const store = db.createObjectStore('mesures', { keyPath: 'id', autoIncrement: true });
        store.createIndex('clientId', 'clientId', { unique: false });
      }
    };
    req.onsuccess = (e) => { db = e.target.result; resolve(db); };
    req.onerror = (e) => reject(e.target.error);
  });
}

function dbAdd(store, item) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).add(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbPut(store, item) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).put(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbGet(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbGetAll(store) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function dbDelete(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
function getMesuresForClient(clientId) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('mesures', 'readonly');
    const index = tx.objectStore('mesures').index('clientId');
    const req = index.getAll(clientId);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// ============================================================
// TEMPLATES DE MESURES (par zone du corps)
// ============================================================
const TEMPLATES = {
  haut: {
    label: 'Haut',
    description: 'Chemise, boubou, kaftan, dashiki',
    champs: [
      { key: 'poitrine', label: 'Poitrine', icon: '👕' },
      { key: 'taille', label: 'Taille', icon: '📏' },
      { key: 'epaules', label: 'Épaules', icon: '🔱' },
      { key: 'manche', label: 'Manche', icon: '💪' },
      { key: 'cou', label: 'Cou', icon: '👔' },
      { key: 'longueur', label: 'Longueur', icon: '📐' },
      { key: 'biceps', label: 'Biceps', icon: '💪' },
      { key: 'poignet', label: 'Poignet', icon: '⌚' },
      { key: 'dos', label: 'Dos', icon: '🔙' }
    ]
  },
  bas: {
    label: 'Bas',
    description: 'Pantalon, jupe, pagne, short',
    champs: [
      { key: 'taille', label: 'Taille', icon: '📏' },
      { key: 'hanches', label: 'Hanches', icon: '🍑' },
      { key: 'jambe', label: 'Jambe', icon: '🦵' },
      { key: 'entrejambe', label: 'Entrejambe', icon: '⬇️' },
      { key: 'cuisse', label: 'Cuisse', icon: '🦵' },
      { key: 'genou', label: 'Genou', icon: '🦵' },
      { key: 'cheville', label: 'Cheville', icon: '🦶' }
    ]
  },
  robe: {
    label: 'Robe',
    description: 'Robe, boubou long',
    champs: [
      { key: 'poitrine', label: 'Poitrine', icon: '👕' },
      { key: 'taille', label: 'Taille', icon: '📏' },
      { key: 'hanches', label: 'Hanches', icon: '🍑' },
      { key: 'longueur_totale', label: 'Longueur totale', icon: '📐' },
      { key: 'jupe', label: 'Jupe', icon: '👗' },
      { key: 'bras', label: 'Bras', icon: '💪' },
      { key: 'epaules', label: 'Épaules', icon: '🔱' }
    ]
  },
  complet: {
    label: 'Complet',
    description: 'Ensemble, complet, 2 pièces',
    champs: [
      { key: 'poitrine', label: 'Poitrine', icon: '👕', section: 'Haut' },
      { key: 'taille', label: 'Taille', icon: '📏', section: 'Haut' },
      { key: 'epaules', label: 'Épaules', icon: '🔱', section: 'Haut' },
      { key: 'manche', label: 'Manche', icon: '💪', section: 'Haut' },
      { key: 'cou', label: 'Cou', icon: '👔', section: 'Haut' },
      { key: 'longueur', label: 'Longueur haut', icon: '📐', section: 'Haut' },
      { key: 'biceps', label: 'Biceps', icon: '💪', section: 'Haut' },
      { key: 'poignet', label: 'Poignet', icon: '⌚', section: 'Haut' },
      { key: 'hanches', label: 'Hanches', icon: '🍑', section: 'Bas' },
      { key: 'jambe', label: 'Jambe', icon: '🦵', section: 'Bas' },
      { key: 'entrejambe', label: 'Entrejambe', icon: '⬇️', section: 'Bas' },
      { key: 'cuisse', label: 'Cuisse', icon: '🦵', section: 'Bas' },
      { key: 'genou', label: 'Genou', icon: '🦵', section: 'Bas' },
      { key: 'cheville', label: 'Cheville', icon: '🦶', section: 'Bas' }
    ]
  }
};

// ============================================================
// NAVIGATION (avec gestion du bouton retour physique)
// ============================================================
function goTo(screenId, data = {}) {
  history.pushState({ screen: screenId, data }, '');
  renderScreen(screenId, data);
}

function goBack() {
  history.back();
}

window.addEventListener('popstate', (e) => {
  const state = e.state;
  if (state) {
    renderScreen(state.screen, state.data);
  } else {
    renderScreen('screen-clients', {});
  }
});

function renderScreen(screenId, data) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(screenId).classList.add('active');
  window.scrollTo(0, 0);

  switch (screenId) {
    case 'screen-clients':
      renderClientsList();
      break;
    case 'screen-client':
      renderClientDetail(data.clientId);
      break;
    case 'screen-client-form':
      renderClientForm(data.clientId);
      break;
    case 'screen-mesure':
      renderMesureForm(data.clientId, data.mesureId);
      break;
  }
}

// ============================================================
// ÉCRAN 1 : LISTE CLIENTS
// ============================================================
async function renderClientsList(filter = '') {
  const clients = await dbGetAll('clients');
  const allMesures = await dbGetAll('mesures');

  // Compter les mesures par client
  const countByClient = {};
  for (const m of allMesures) {
    countByClient[m.clientId] = (countByClient[m.clientId] || 0) + 1;
  }

  const list = document.getElementById('clients-list');
  const filtered = clients.filter(c =>
    (c.name || '').toLowerCase().includes(filter.toLowerCase()) ||
    (c.phone || '').includes(filter)
  );

  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty">Aucun client.<br>Appuyez sur + pour ajouter.</div>';
    return;
  }

  list.innerHTML = filtered.map(c => {
    const count = countByClient[c.id] || 0;
    return `
      <div class="client-card" data-id="${c.id}">
        <div>
          <div class="name">${escapeHtml(c.name || 'Sans nom')}</div>
          <div class="phone">${escapeHtml(c.phone || '')}</div>
        </div>
        ${count > 0 ? `<div class="count">${count} mesure${count > 1 ? 's' : ''}</div>` : ''}
      </div>
    `;
  }).join('');

  list.querySelectorAll('.client-card').forEach(card => {
    card.addEventListener('click', () => {
      goTo('screen-client', { clientId: parseInt(card.dataset.id) });
    });
  });
}

// ============================================================
// ÉCRAN 2 : FICHE CLIENT
// ============================================================
async function renderClientDetail(clientId) {
  const client = await dbGet('clients', clientId);
  if (!client) return;

  document.getElementById('client-header-name').textContent = client.name || 'Client';

  // Infos client
  const info = document.getElementById('client-info');
  const genreLabel = client.genre === 'homme' ? 'Homme' : client.genre === 'femme' ? 'Femme' : '—';
  info.innerHTML = `
    <div class="info-line">
      <span class="key">Téléphone</span>
      <span class="val">${escapeHtml(client.phone || '—')}</span>
    </div>
    <div class="info-line">
      <span class="key">Genre</span>
      <span class="val">${genreLabel}</span>
    </div>
  `;

  // Liste des mesures
  const mesures = await getMesuresForClient(clientId);
  mesures.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  const list = document.getElementById('mesures-list');
  if (mesures.length === 0) {
    list.innerHTML = '<div class="empty">Aucune mesure.<br>Ajoutez la première mesure.</div>';
  } else {
    list.innerHTML = mesures.map(m => {
      const t = TEMPLATES[m.type];
      const date = m.updatedAt ? new Date(m.updatedAt).toLocaleDateString('fr-FR') : '';
      return `
        <div class="mesure-card" data-id="${m.id}">
          <div>
            <div class="label">${t ? t.label : 'Mesure'}</div>
            <div class="date">${date}</div>
          </div>
          <div class="arrow">›</div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.mesure-card').forEach(card => {
      card.addEventListener('click', () => {
        goTo('screen-mesure', {
          clientId,
          mesureId: parseInt(card.dataset.id)
        });
      });
    });
  }
}

// ============================================================
// ÉCRAN 3 : FORMULAIRE CLIENT
// ============================================================
let currentClientId = null;
let currentGenre = null;

async function renderClientForm(clientId) {
  const isEdit = clientId !== undefined && clientId !== null;
  const client = isEdit ? await dbGet('clients', clientId) : null;

  currentClientId = isEdit ? clientId : null;
  currentGenre = client?.genre || null;

  document.getElementById('client-form-title').textContent = isEdit ? 'Modifier le client' : 'Nouveau client';
  document.getElementById('form-client-name').value = client?.name || '';
  document.getElementById('form-client-phone').value = client?.phone || '';

  // État du genre
  document.querySelectorAll('.genre-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.genre === currentGenre);
  });
}

async function saveClient() {
  const name = document.getElementById('form-client-name').value.trim();
  const phone = document.getElementById('form-client-phone').value.trim();

  if (!name && !phone) {
    alert('Entrez au moins un nom ou un téléphone.');
    return;
  }

  if (currentClientId) {
    // Édition
    const client = await dbGet('clients', currentClientId);
    client.name = name;
    client.phone = phone;
    client.genre = currentGenre;
    client.updatedAt = Date.now();
    await dbPut('clients', client);
    goBack();
  } else {
    // Création
    const newId = await dbAdd('clients', {
      name, phone,
      genre: currentGenre,
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
    // Remplacer l'écran actuel par la fiche du nouveau client
    history.replaceState({ screen: 'screen-client', data: { clientId: newId } }, '');
    renderScreen('screen-client', { clientId: newId });
  }
}

// ============================================================
// ÉCRAN 4 : FORMULAIRE MESURE
// ============================================================
let currentMesureId = null;
let currentMesureClientId = null;
let currentType = null;
let currentChamps = {};
let currentCustom = [];
let currentCreatedAt = null;
let autosaveTimeout = null;
let saveTimer = null;

async function renderMesureForm(clientId, mesureId) {
  currentMesureClientId = clientId;
  currentMesureId = mesureId || null;
  currentType = null;
  currentChamps = {};
  currentCustom = [];
  currentCreatedAt = null;

  const isEdit = mesureId !== undefined && mesureId !== null;

  if (isEdit) {
    const m = await dbGet('mesures', mesureId);
    if (m) {
      currentType = m.type;
      currentChamps = { ...(m.champs || {}) };
      currentCustom = [...(m.custom || [])];
      currentCreatedAt = m.createdAt || Date.now();
    }
  }

  document.getElementById('mesure-title').textContent = isEdit ? 'Modifier la mesure' : 'Nouvelle mesure';
  document.getElementById('btn-delete-mesure').style.display = isEdit ? 'block' : 'none';

  // Info panel : liste des types (généré dynamiquement)
  const infoList = document.getElementById('type-info-list');
  infoList.innerHTML = Object.entries(TEMPLATES).map(([key, t]) => `
    <li><strong>${t.label}</strong> → ${t.description}</li>
  `).join('');

  // État du panneau info (mémorisé)
  applyInfoPanelState();

  // Boutons type
  renderTypeButtons();

  // Champs si type déjà choisi
  if (currentType) {
    renderMesureFields();
  } else {
    document.getElementById('mesures-fields').innerHTML = '';
  }

  // Mesures personnalisées
  renderCustomList();
}

function renderTypeButtons() {
  const client = null; // on n'a pas le client ici, mais on peut lire le genre
  // Récupérer le genre du client (asynchrone — on utilise une variable temporaire)
  dbGet('clients', currentMesureClientId).then(client => {
    const genre = client?.genre;
    const hiddenForHomme = ['robe'];
    const allTypes = Object.keys(TEMPLATES);
    const types = (genre === 'homme')
      ? allTypes.filter(t => !hiddenForHomme.includes(t))
      : allTypes;

    const container = document.getElementById('type-buttons');
    container.innerHTML = types.map(key => {
      const t = TEMPLATES[key];
      const active = key === currentType ? ' active' : '';
      return `
        <button class="type-btn${active}" data-type="${key}">
          <span class="type-label">${t.label}</span>
          <span class="type-desc">${t.description}</span>
        </button>
      `;
    }).join('');

    container.querySelectorAll('.type-btn').forEach(btn => {
      btn.addEventListener('click', () => onTypeChange(btn.dataset.type));
    });
  });
}

function onTypeChange(newType) {
  if (newType === currentType) return;

  // Conserver les valeurs communes aux deux types
  const newKeys = TEMPLATES[newType].champs.map(f => f.key);
  const kept = {};
  for (const key of newKeys) {
    if (currentChamps[key] !== undefined) {
      kept[key] = currentChamps[key];
    }
  }
  currentChamps = kept;
  currentType = newType;

  document.querySelectorAll('.type-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.type === newType);
  });

  renderMesureFields();
  scheduleSave();
}

function renderMesureFields() {
  if (!currentType) return;
  const t = TEMPLATES[currentType];
  const container = document.getElementById('mesures-fields');

  // Grouper par section si nécessaire
  const hasSections = t.champs.some(f => f.section);
  let html = '';

  if (hasSections) {
    const sections = {};
    for (const f of t.champs) {
      const s = f.section || 'Autres';
      if (!sections[s]) sections[s] = [];
      sections[s].push(f);
    }
    for (const [section, fields] of Object.entries(sections)) {
      html += `<div class="mesure-section-title">${section}</div>`;
      html += fields.map(f => renderField(f)).join('');
    }
  } else {
    html = t.champs.map(f => renderField(f)).join('');
  }

  container.innerHTML = html;

  container.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', () => {
      currentChamps[input.dataset.key] = input.value;
      scheduleSave();
    });
  });
}

function renderField(field) {
  const val = currentChamps[field.key] || '';
  return `
    <div class="mesure-field">
      <div class="field-left">
        <span class="field-icon">${field.icon}</span>
        <label>${field.label}</label>
      </div>
      <input type="number" inputmode="decimal" data-key="${field.key}" value="${val}" placeholder="0">
      <span class="unit">cm</span>
    </div>
  `;
}

// ============================================================
// MESURES PERSONNALISÉES
// ============================================================
function renderCustomList() {
  const container = document.getElementById('custom-list');
  container.innerHTML = currentCustom.map((c, i) => `
    <div class="custom-row" data-index="${i}">
      <input type="text" class="custom-name" placeholder="Nom de la mesure" value="${escapeHtml(c.label || '')}">
      <input type="number" class="custom-value" placeholder="0" value="${c.value || ''}">
      <button class="btn-remove" data-remove="${i}">×</button>
    </div>
  `).join('');

  container.querySelectorAll('.custom-row').forEach(row => {
    const i = parseInt(row.dataset.index);
    row.querySelector('.custom-name').addEventListener('input', (e) => {
      currentCustom[i].label = e.target.value;
      scheduleSave();
    });
    row.querySelector('.custom-value').addEventListener('input', (e) => {
      currentCustom[i].value = e.target.value;
      scheduleSave();
    });
    row.querySelector('.btn-remove').addEventListener('click', () => {
      currentCustom.splice(i, 1);
      renderCustomList();
      scheduleSave();
    });
  });
}

function addCustomMesure() {
  currentCustom.push({ label: '', value: '' });
  renderCustomList();
  // Focus sur le dernier champ
  const rows = document.querySelectorAll('.custom-row');
  const last = rows[rows.length - 1];
  if (last) last.querySelector('.custom-name').focus();
}

// ============================================================
// SAUVEGARDE AUTOMATIQUE
// ============================================================
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveMesure, 400);
}

async function saveMesure() {
  if (!currentType) return; // Rien à sauvegarder tant qu'aucun type n'est choisi

  const data = {
    clientId: currentMesureClientId,
    type: currentType,
    champs: { ...currentChamps },
    custom: [...currentCustom],
    updatedAt: Date.now()
  };

  if (currentMesureId) {
    data.id = currentMesureId;
    data.createdAt = currentCreatedAt;
    await dbPut('mesures', data);
  } else {
    data.createdAt = Date.now();
    currentMesureId = await dbAdd('mesures', data);
    currentCreatedAt = data.createdAt;
    // Afficher le bouton supprimer puisqu'on a maintenant une mesure
    document.getElementById('btn-delete-mesure').style.display = 'block';
  }

  // Feedback visuel + vibration
  showAutosaveIndicator();
  if (navigator.vibrate) navigator.vibrate(8);
}

function showAutosaveIndicator() {
  const el = document.getElementById('autosave-status');
  el.textContent = '✓ Enregistré';
  el.classList.add('show');
  clearTimeout(autosaveTimeout);
  autosaveTimeout = setTimeout(() => {
    el.classList.remove('show');
  }, 1500);
}

// ============================================================
// PANNEAU INFO (mémorisation de l'état)
// ============================================================
function applyInfoPanelState() {
  const open = localStorage.getItem('info-type-open') !== 'false';
  const panel = document.getElementById('type-info');
  const btn = document.getElementById('toggle-type-btn');
  if (open) {
    panel.classList.remove('hidden');
    btn.classList.remove('closed');
  } else {
    panel.classList.add('hidden');
    btn.classList.add('closed');
  }
}

function toggleInfoPanel() {
  const panel = document.getElementById('type-info');
  const btn = document.getElementById('toggle-type-btn');
  const isOpen = !panel.classList.contains('hidden');
  if (isOpen) {
    panel.classList.add('hidden');
    btn.classList.add('closed');
    localStorage.setItem('info-type-open', 'false');
  } else {
    panel.classList.remove('hidden');
    btn.classList.remove('closed');
    localStorage.setItem('info-type-open', 'true');
  }
}

// ============================================================
// SUPPRESSION
// ============================================================
async function deleteMesure() {
  if (!currentMesureId) return;
  if (!confirm('Supprimer cette mesure ?')) return;
  await dbDelete('mesures', currentMesureId);
  goBack();
}

async function deleteClient() {
  if (!confirm('Supprimer ce client et toutes ses mesures ?')) return;
  const clientId = currentMesureClientId;
  // Récupérer depuis l'écran client en cours
  const headerName = document.getElementById('client-header-name').textContent;
  // On doit trouver l'ID depuis l'état précédent
  // Simplification : on utilise l'ID passé en argument via un stockage global
  const id = window.__currentClientDetailId;
  if (!id) return;
  const mesures = await getMesuresForClient(id);
  for (const m of mesures) await dbDelete('mesures', m.id);
  await dbDelete('clients', id);
  goBack();
}

// ============================================================
// UTILITAIRES
// ============================================================
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ============================================================
// INITIALISATION
// ============================================================
async function init() {
  await openDB();

  // État initial de l'historique
  history.replaceState({ screen: 'screen-clients', data: {} }, '');

  // Boutons de retour dans l'interface
  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => goBack());
  });

  // Recherche
  document.getElementById('search').addEventListener('input', (e) => {
    renderClientsList(e.target.value);
  });

  // Bouton "+" clients
  document.getElementById('btn-add-client').addEventListener('click', () => {
    goTo('screen-client-form', {});
  });

  // Bouton "+" mesures
  document.getElementById('btn-add-mesure').addEventListener('click', () => {
    goTo('screen-mesure', { clientId: window.__currentClientDetailId });
  });

  // Genre (formulaire client)
  document.querySelectorAll('.genre-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      currentGenre = btn.dataset.genre;
      document.querySelectorAll('.genre-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.genre === currentGenre);
      });
    });
  });

  // Sauvegarde client
  document.getElementById('btn-save-client').addEventListener('click', saveClient);

  // Édition client
  document.getElementById('btn-edit-client').addEventListener('click', () => {
    goTo('screen-client-form', { clientId: window.__currentClientDetailId });
  });

  // Suppression client
  document.getElementById('btn-delete-client').addEventListener('click', deleteClient);

  // Suppression mesure
  document.getElementById('btn-delete-mesure').addEventListener('click', deleteMesure);

  // Ajout mesure personnalisée
  document.getElementById('btn-add-custom').addEventListener('click', addCustomMesure);

  // Toggle panneau info
  document.getElementById('toggle-type-btn').addEventListener('click', toggleInfoPanel);

  // Affichage initial
  renderScreen('screen-clients', {});

  // Service Worker
//   if ('serviceWorker' in navigator) {
//     navigator.serviceWorker.register('sw.js').catch(() => {});
//   }
}

// Patch : stocker l'ID du client en cours pour les écrans suivants
const _origRenderClientDetail = renderClientDetail;
renderClientDetail = async function(clientId) {
  window.__currentClientDetailId = clientId;
  return _origRenderClientDetail(clientId);
};

init();