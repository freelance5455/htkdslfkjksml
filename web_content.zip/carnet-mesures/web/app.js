// ===== BASE DE DONNÉES INDEXEDDB =====
const DB_NAME = 'carnet-mesures';
const DB_VERSION = 1;
let db;

function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains('clients')) {
                db.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
            }
        };
        req.onsuccess = (e) => { db = e.target.result; resolve(db); };
        req.onerror = (e) => reject(e.target.error);
    });
}

function dbAdd(client) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction('clients', 'readwrite');
        const req = tx.objectStore('clients').add(client);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

function dbPut(client) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction('clients', 'readwrite');
        const req = tx.objectStore('clients').put(client);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

function dbGetAll() {
    return new Promise((resolve, reject) => {
        const tx = db.transaction('clients', 'readonly');
        const req = tx.objectStore('clients').getAll();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

function dbGet(id) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction('clients', 'readonly');
        const req = tx.objectStore('clients').get(id);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

function dbDelete(id) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction('clients', 'readwrite');
        const req = tx.objectStore('clients').delete(id);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
    });
}

// ===== TEMPLATES DE MESURES =====
const TEMPLATES = {
    chemise: {
        label: 'Chemise',
        champs: [
            { key: 'poitrine', label: 'Poitrine' },
            { key: 'taille', label: 'Taille' },
            { key: 'epaules', label: 'Épaules' },
            { key: 'manche', label: 'Manche' },
            { key: 'cou', label: 'Cou' },
            { key: 'longueur', label: 'Longueur' },
            { key: 'biceps', label: 'Biceps' },
            { key: 'poignet', label: 'Poignet' },
            { key: 'dos', label: 'Dos' }
        ]
    },
    pantalon: {
        label: 'Pantalon',
        champs: [
            { key: 'taille', label: 'Taille' },
            { key: 'hanches', label: 'Hanches' },
            { key: 'jambe', label: 'Jambe' },
            { key: 'entrejambe', label: 'Entrejambe' },
            { key: 'cuisse', label: 'Cuisse' },
            { key: 'genou', label: 'Genou' },
            { key: 'cheville', label: 'Cheville' }
        ]
    },
    robe: {
        label: 'Robe',
        champs: [
            { key: 'poitrine', label: 'Poitrine' },
            { key: 'taille', label: 'Taille' },
            { key: 'hanches', label: 'Hanches' },
            { key: 'longueur_totale', label: 'Longueur totale' },
            { key: 'jupe', label: 'Jupe' },
            { key: 'bras', label: 'Bras' },
            { key: 'epaules', label: 'Épaules' }
        ]
    }
};

// ===== ÉTAT =====
let currentClient = null;
let currentType = null;
let currentMesures = {};

// ===== NAVIGATION =====
function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    window.scrollTo(0, 0);
}

// ===== ÉCRAN CLIENTS =====
async function renderClients(filter = '') {
    const clients = await dbGetAll();
    const list = document.getElementById('clients-list');
    const filtered = clients.filter(c =>
        (c.name || '').toLowerCase().includes(filter.toLowerCase()) ||
        (c.phone || '').includes(filter)
    );

    if (filtered.length === 0) {
        list.innerHTML = '<div class="empty">Aucun client.<br>Appuyez sur + pour ajouter.</div>';
        return;
    }

    list.innerHTML = filtered.map(c => `
    <div class="client-card" data-id="${c.id}">
      <div>
        <div class="name">${escapeHtml(c.name || 'Sans nom')}</div>
        <div class="phone">${escapeHtml(c.phone || '')}</div>
      </div>
      <div class="count">${c.type ? TEMPLATES[c.type]?.label || '' : ''}</div>
    </div>
  `).join('');

    list.querySelectorAll('.client-card').forEach(card => {
        card.addEventListener('click', () => openView(parseInt(card.dataset.id)));
    });
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ===== ÉCRAN FORMULAIRE =====
function renderTypeButtons() {
    const container = document.getElementById('type-buttons');
    container.innerHTML = Object.entries(TEMPLATES).map(([key, t]) => `
    <button class="type-btn" data-type="${key}">${t.label}</button>
  `).join('');

    container.querySelectorAll('.type-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            currentType = btn.dataset.type;
            document.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderMesureFields();
        });
    });
}

function renderMesureFields() {
    if (!currentType) return;
    const container = document.getElementById('mesures-fields');
    const t = TEMPLATES[currentType];

    container.innerHTML = t.champs.map(champ => `
    <div class="mesure-field">
      <label>${champ.label}</label>
      <input type="number" inputmode="decimal" data-key="${champ.key}" value="${currentMesures[champ.key] || ''}" placeholder="0">
      <span class="unit">cm</span>
    </div>
  `).join('');

    container.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', () => {
            currentMesures[input.dataset.key] = input.value;
        });
    });
}

function openForm(client = null) {
    currentClient = client;
    currentType = client?.type || null;
    currentMesures = client?.mesures ? { ...client.mesures } : {};

    document.getElementById('form-title').textContent = client ? 'Modifier' : 'Nouveau client';
    document.getElementById('client-name').value = client?.name || '';
    document.getElementById('client-phone').value = client?.phone || '';

    renderTypeButtons();
    if (currentType) {
        document.querySelectorAll('.type-btn').forEach(b => {
            if (b.dataset.type === currentType) b.classList.add('active');
        });
        renderMesureFields();
    } else {
        document.getElementById('mesures-fields').innerHTML = '';
    }

    showScreen('screen-form');
}

async function saveClient() {
    const name = document.getElementById('client-name').value.trim();
    const phone = document.getElementById('client-phone').value.trim();

    if (!name && !phone) {
        alert('Entrez au moins un nom ou un téléphone.');
        return;
    }
    if (!currentType) {
        alert('Choisissez un type de vêtement.');
        return;
    }

    const client = {
        name, phone,
        type: currentType,
        mesures: { ...currentMesures },
        updatedAt: Date.now()
    };

    if (currentClient) {
        client.id = currentClient.id;
        await dbPut(client);
    } else {
        client.createdAt = Date.now();
        await dbAdd(client);
    }

    await renderClients();
    showScreen('screen-clients');
}

// ===== ÉCRAN CONSULTATION =====
async function openView(id) {
    const client = await dbGet(id);
    if (!client) return;
    currentClient = client;

    document.getElementById('view-name').textContent = client.name || 'Sans nom';
    const t = TEMPLATES[client.type];
    const container = document.getElementById('view-mesures');

    if (!t) {
        container.innerHTML = '<div class="empty">Aucune mesure.</div>';
    } else {
        container.innerHTML = t.champs.map(champ => {
            const val = client.mesures?.[champ.key];
            if (!val) return '';
            return `
        <div class="view-mesure">
          <span class="label">${champ.label}</span>
          <span><span class="value">${val}</span><span class="unit">cm</span></span>
        </div>
      `;
        }).join('');
    }

    showScreen('screen-view');
}

// ===== INIT =====
async function init() {
    await openDB();
    await renderClients();

    document.getElementById('search').addEventListener('input', (e) => {
        renderClients(e.target.value);
    });

    document.getElementById('btn-add-client').addEventListener('click', () => openForm());
    document.getElementById('btn-save').addEventListener('click', saveClient);

    document.getElementById('btn-edit').addEventListener('click', () => openForm(currentClient));

    document.getElementById('btn-delete').addEventListener('click', async () => {
        if (confirm('Supprimer ce client ?')) {
            await dbDelete(currentClient.id);
            currentClient = null;
            await renderClients();
            showScreen('screen-clients');
        }
    });

    document.querySelectorAll('[data-back]').forEach(btn => {
        btn.addEventListener('click', async () => {
            await renderClients();
            showScreen('screen-clients');
        });
    });
}

init();