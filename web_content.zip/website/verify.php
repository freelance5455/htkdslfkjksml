<?php
require __DIR__.'/config.php';
date_default_timezone_set('Asia/Kolkata');
header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store, max-age=0');header('X-Robots-Tag: noindex');
$id=trim((string)($_GET['e']??$_GET['i']??''));
$e=function($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');};
$w=null;$bad='';
try{
 $p=db();$p->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 // light rate limit per IP (60 scans/min) to stop ID guessing
 $p->exec("CREATE TABLE IF NOT EXISTS sk_vhits(ip VARCHAR(64) NOT NULL PRIMARY KEY,n INT NOT NULL,ts BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $ip=substr($_SERVER['REMOTE_ADDR']??'?',0,64);$now=time();
 $s=$p->prepare('SELECT n,ts FROM sk_vhits WHERE ip=?');$s->execute([$ip]);$h=$s->fetch(PDO::FETCH_ASSOC);
 if($h&&$now-$h['ts']<60){$n=$h['n']+1;$p->prepare('UPDATE sk_vhits SET n=? WHERE ip=?')->execute([$n,$ip]);if($n>60){http_response_code(429);$bad='Too many requests. Please wait a minute and scan again.';}}
 else{$p->prepare('REPLACE INTO sk_vhits(ip,n,ts) VALUES(?,?,?)')->execute([$ip,1,$now]);}
 if($bad===''){
  $g=function($k)use($p){$s=$p->prepare('SELECT v FROM sk_kv WHERE k=?');$s->execute([$k]);$v=$s->fetchColumn();$d=$v?json_decode($v,true):[];return is_array($d)?$d:[];};
  $W=$g('sk_workers_v1');$R=$g('sk_revoked');
  if($id!==''){foreach($W as $x){if(is_array($x)&&(string)($x['empId']??'')===$id){$w=$x;break;}}}
  if($w){
   if(!empty($w['noCard']))$bad='This ID card has been cancelled by S K Enterprises.';
   elseif(!empty($w['leave'])){$lv=strtotime((string)$w['leave']);if($lv!==false&&date('Y-m-d',$lv)<date('Y-m-d'))$bad='This employee no longer works with S K Enterprises (left on '.$w['leave'].').';}
  }else{
   $rv=false;foreach($R as $r){if(is_array($r)&&(string)($r['i']??'')===$id)$rv=true;}
   $bad=$rv?'This ID card has been deleted by S K Enterprises. The employee record has been removed.':'This ID card was not found in the S K Enterprises records.';
  }
 }
}catch(Throwable $x){error_log('sk verify: '.$x->getMessage());$w=null;$bad='Verification is temporarily unavailable. Do not accept this card until it is verified.';}
$ph=$e(defined('COMPANY_PHONE')?COMPANY_PHONE:'');$ph0=($w&&!$bad&&!empty($w['photo'])&&preg_match('~^data:image/(jpeg|jpg|png|webp|gif);base64,~i',$w['photo']))?$w['photo']:'';
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="<?=$bad?'#b91c1c':'#059669'?>"><title>ID Verification</title>
<style>*{box-sizing:border-box}html,body{margin:0;padding:0;width:100%;height:100%}
body{height:100vh;height:100dvh;display:flex;align-items:center;justify-content:center;padding:2vh 4vw 7vh;font-family:Roboto,Arial,Helvetica,sans-serif;background:<?=$bad?'linear-gradient(160deg,#0f172a,#334155 60%,#7f1d1d)':'linear-gradient(160deg,#064e3b,#059669 55%,#22d3ee)'?>;background-attachment:fixed;overflow:hidden;-webkit-text-size-adjust:100%}
.c{font-size:clamp(14px,4.6vw,40px);background:#111;color:#fff;border-radius:1.4em;width:min(92vw,23em);max-height:100%;overflow:auto;text-align:center;box-shadow:0 22px 60px rgba(0,0,0,.45);margin:0 auto}
.co{padding:.8em;background:#0b1b36;color:#fbbf24;font-weight:800;letter-spacing:.1em;font-size:.95em}
.big{padding:1.1em .8em;color:#fff;background:<?=$bad?'#991b1b':'linear-gradient(135deg,#16a34a,#059669)'?>}
.big span{font-size:3.2em;display:block;line-height:1;animation:p 1.1s infinite alternate}.big b{display:block;margin-top:.3em;font-size:1.5em;letter-spacing:.05em}
@keyframes p{to{transform:scale(1.08)}}.t{padding:1.1em 1.4em 1.3em}
.ph{width:7.6em;height:7.6em;border-radius:50%;object-fit:cover;object-position:center top;border:.2em solid #16a34a;margin:0 auto .6em;display:block;background:#fff}
dl{text-align:left;margin:0}dt{color:#94a3b8;font-size:.8em;margin-top:.7em}dd{margin:.15em 0 0;font-weight:700;font-size:1.2em;color:#fff;overflow-wrap:anywhere}
.st{display:inline-block;margin-top:1em;padding:.55em .9em;border-radius:99px;background:#052e1a;color:#4ade80;font-weight:700;font-size:.8em}
.w{color:#fff;font-weight:700;font-size:1.1em;line-height:1.45;margin:.4em 0 .9em}.n{background:#1e293b;border:1px solid #475569;color:#e2e8f0;padding:.8em;border-radius:.8em;font-weight:600;font-size:.95em;line-height:1.5}small{color:#cbd5e1;display:block;margin-top:.9em;font-size:.9em}
@media(max-height:680px){.c{font-size:clamp(12px,3.6vw,18px)}.ph{width:5em;height:5em}}</style>
</head><body><div class="c"><div class="co">S K ENTERPRISES</div>
<?php if($bad): ?><div class="big"><span>&#9940;</span><b>ID CARD NOT VALID</b></div><div class="t"><p class="w"><?=$e($bad)?></p><div class="n">Do not accept this card as proof of identity or employment. Please contact the company owner.</div><small>Contact S K Enterprises: <?=$ph?></small></div>
<?php else: ?><div class="big"><span>&#10004;</span><b>VALID CARD</b></div><div class="t"><?php if($ph0): ?><img class="ph" src="<?=$e($ph0)?>" alt=""><?php endif; ?><dl><dt>Name</dt><dd><?=$e($w['name']??'')?></dd><dt>Employee ID</dt><dd><?=$e($w['empId']??'')?></dd><dt>Designation</dt><dd><?=$e($w['role']??'')?></dd><dt>Joining Date</dt><dd><?=$e($w['join']??'')?></dd></dl><div class="st">&#10004; Currently working with S K Enterprises</div></div><?php endif; ?>
</div></body></html>
