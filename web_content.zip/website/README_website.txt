WEBSITE FILES (hosting par upload karne ke liye)
-------------------------------------------------
index.html  -> sabse nayi website (balance, calendar, slip, letter pad, ID card sab fix ke saath)
verify.php  -> QR scan wala verification page (photo fix ke saath)

Hosting File Manager (htdocs) me in dono ko purani files ki jagah upload karo.
api.php, config.php, setup.php, .htaccess aapki hosting par pehle se hain - unko mat badalna.
Upload ke baad browser me Ctrl+F5 dabao.
