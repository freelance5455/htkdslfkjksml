/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  AppView, 
  Language, 
  Store, 
  Product, 
  Order, 
  Customer, 
  CartItem, 
  StoreTheme,
  OrderStatus,
  MerchantUser,
  PaymentGatewayConfig,
  SubscriptionPayment,
  PaymentGatewayProvider
} from './types';
import { 
  initialStores, 
  initialProducts, 
  initialOrders, 
  initialCustomers,
  initialMerchantUsers,
  initialPaymentGateways,
  initialSubscriptionPayments
} from './data/initialData';
import { Navbar } from './components/Navbar';
import { SaaSMarketing } from './components/marketing/SaaSMarketing';
import { MerchantDashboard } from './components/dashboard/MerchantDashboard';
import { LiveStorefront } from './components/storefront/LiveStorefront';
import { AdminPanel } from './components/admin/AdminPanel';
import { CreateStoreWizardModal } from './components/modals/CreateStoreWizardModal';
import { ExportProjectModal } from './components/modals/ExportProjectModal';
import { saveSafeLocalStorage, saveToIndexedDB, loadFromIndexedDB } from './utils/storage';

export default function App() {
  // Navigation & Localization
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [language, setLanguage] = useState<Language>('bn'); // Bengali by default since prompt was in Bengali
  const [isCreateStoreWizardOpen, setIsCreateStoreWizardOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Multi-tenant Stores state
  const [stores, setStores] = useState<Store[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_stores');
      return saved ? JSON.parse(saved) : initialStores;
    } catch {
      return initialStores;
    }
  });

  const [activeStoreId, setActiveStoreId] = useState<string>(stores[0]?.id || 'store-1');

  // Products state
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_products');
      return saved ? JSON.parse(saved) : initialProducts;
    } catch {
      return initialProducts;
    }
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_orders');
      return saved ? JSON.parse(saved) : initialOrders;
    } catch {
      return initialOrders;
    }
  });

  // Customers state
  const [customers, setCustomers] = useState<Customer[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_customers');
      return saved ? JSON.parse(saved) : initialCustomers;
    } catch {
      return initialCustomers;
    }
  });

  // SaaS Merchant Users state (Admin Panel)
  const [merchantUsers, setMerchantUsers] = useState<MerchantUser[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_merchant_users');
      return saved ? JSON.parse(saved) : initialMerchantUsers;
    } catch {
      return initialMerchantUsers;
    }
  });

  // Platform Payment Gateways Config (AamarPay, Shohoz Pay, ShurjoPay)
  const [paymentGateways, setPaymentGateways] = useState<PaymentGatewayConfig[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_payment_gateways');
      return saved ? JSON.parse(saved) : initialPaymentGateways;
    } catch {
      return initialPaymentGateways;
    }
  });

  // Subscription Payments Ledger
  const [subscriptionPayments, setSubscriptionPayments] = useState<SubscriptionPayment[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_subscription_payments');
      return saved ? JSON.parse(saved) : initialSubscriptionPayments;
    } catch {
      return initialSubscriptionPayments;
    }
  });

  // Shopping Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Hydrate full products from IndexedDB on mount if available (supports large media without quota limits)
  useEffect(() => {
    let isMounted = true;
    loadFromIndexedDB<Product[]>('shopforge_products').then((dbProducts) => {
      if (isMounted && dbProducts && Array.isArray(dbProducts) && dbProducts.length > 0) {
        setProducts(dbProducts);
      }
    }).catch(() => {
      // Ignore fallback
    });

    return () => {
      isMounted = false;
    };
  }, []);

  // Safe Persistence (IndexedDB for unbounded media storage + safe localStorage fallback)
  useEffect(() => {
    saveSafeLocalStorage('shopforge_stores', stores);
    saveToIndexedDB('shopforge_stores', stores).catch(() => {});
  }, [stores]);

  useEffect(() => {
    saveSafeLocalStorage('shopforge_products', products);
    saveToIndexedDB('shopforge_products', products).catch(() => {});
  }, [products]);

  useEffect(() => {
    saveSafeLocalStorage('shopforge_orders', orders);
    saveToIndexedDB('shopforge_orders', orders).catch(() => {});
  }, [orders]);

  useEffect(() => {
    saveSafeLocalStorage('shanju_merchant_users', merchantUsers);
  }, [merchantUsers]);

  useEffect(() => {
    saveSafeLocalStorage('shanju_payment_gateways', paymentGateways);
  }, [paymentGateways]);

  useEffect(() => {
    saveSafeLocalStorage('shanju_subscription_payments', subscriptionPayments);
  }, [subscriptionPayments]);

  // Find active store object
  const activeStore = stores.find((s) => s.id === activeStoreId) || stores[0];

  // Actions
  const handleCreateStore = (name: string, category: string) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newStore: Store = {
      id: `store-${Date.now()}`,
      name,
      slug,
      logo: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=160&q=80',
      category,
      currency: 'BDT',
      currencySymbol: '৳',
      status: 'active',
      plan: 'starter',
      createdAt: new Date().toISOString().split('T')[0],
      theme: {
        primaryColor: '#059669',
        accentColor: '#10b981',
        fontFamily: 'Plus Jakarta Sans',
        announcementText: '🎉 Welcome to our brand new store! Get 10% off your first order.',
        announcementTextBn: '🎉 আমাদের নতুন অনলাইন স্টোরে স্বাগতম! প্রথম অর্ডারে পান ১০% ছাড়।',
        showAnnouncement: true,
        heroHeadline: `Welcome to ${name}`,
        heroHeadlineBn: `${name}-এ আপনাকে স্বাগতম`,
        heroSubheadline: 'Curated premium products delivered right to your door with fast delivery.',
        heroSubheadlineBn: 'সেরা মানের পণ্য এবং দ্রুততম হোম ডেলিভারি সেবা।',
        heroBannerImage: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
        layoutStyle: 'modern',
      },
    };

    setStores((prev) => [newStore, ...prev]);
    setActiveStoreId(newStore.id);
    setCurrentView('dashboard');
  };

  const handleWizardStoreCreated = (newStore: Store, starterProducts: Product[]) => {
    setStores((prev) => [newStore, ...prev]);
    if (starterProducts && starterProducts.length > 0) {
      setProducts((prev) => [...starterProducts, ...prev]);
    }
    setActiveStoreId(newStore.id);
  };

  const handleAddProduct = (newProdData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...newProdData,
      id: `prod-${Date.now()}`,
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const handleUpdateProduct = (updatedProd: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updatedProd.id ? updatedProd : p)));
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, orderStatus: status } : o))
    );
  };

  const handleUpdateStoreTheme = (
    storeId: string,
    updatedTheme: Partial<StoreTheme>,
    storeName?: string
  ) => {
    setStores((prev) =>
      prev.map((s) => {
        if (s.id === storeId) {
          return {
            ...s,
            name: storeName || s.name,
            theme: {
              ...s.theme,
              ...updatedTheme,
            },
          };
        }
        return s;
      })
    );
  };

  const handleUpdateStorePlan = (
    storeId: string,
    newPlan: 'starter' | 'growth' | 'enterprise'
  ) => {
    setStores((prev) =>
      prev.map((s) => (s.id === storeId ? { ...s, plan: newPlan } : s))
    );
    setMerchantUsers((prev) =>
      prev.map((u) => (u.storeId === storeId ? { ...u, plan: newPlan } : u))
    );
  };

  // Subscription payment completion handler
  const handleAddSubscriptionPayment = (payment: SubscriptionPayment) => {
    setSubscriptionPayments((prev) => [payment, ...prev]);
    // Also sync the store and user's tier
    setStores((prev) =>
      prev.map((s) => (s.id === payment.storeId ? { ...s, plan: payment.planId } : s))
    );
    setMerchantUsers((prev) =>
      prev.map((u) => (u.storeId === payment.storeId ? { ...u, plan: payment.planId } : u))
    );
  };

  // Admin Panel merchant user handlers
  const handleAddUser = (newUser: Omit<MerchantUser, 'id'>) => {
    const createdUser: MerchantUser = {
      ...newUser,
      id: `usr-${Date.now()}`,
    };
    setMerchantUsers((prev) => [createdUser, ...prev]);
  };

  const handleUpdateUser = (updatedUser: MerchantUser) => {
    setMerchantUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );
    // If the user's plan was updated, also sync their store's plan
    setStores((prev) =>
      prev.map((s) => (s.id === updatedUser.storeId ? { ...s, plan: updatedUser.plan } : s))
    );
  };

  const handleDeleteUser = (userId: string) => {
    setMerchantUsers((prev) => prev.filter((u) => u.id !== userId));
  };

  // Admin Payment Gateways Setup handlers
  const handleUpdateGateway = (updatedGateway: PaymentGatewayConfig) => {
    setPaymentGateways((prev) =>
      prev.map((g) => (g.id === updatedGateway.id ? updatedGateway : g))
    );
  };

  const handleToggleGateway = (gatewayId: PaymentGatewayProvider) => {
    setPaymentGateways((prev) =>
      prev.map((g) => (g.id === gatewayId ? { ...g, isEnabled: !g.isEnabled } : g))
    );
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.product.id !== productId));
    } else {
      setCart((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      );
    }
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleCreateOrder = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    // Also record customer if new
    setCustomers((prev) => {
      const existing = prev.find((c) => c.phone === newOrder.customerPhone);
      if (existing) {
        return prev.map((c) =>
          c.id === existing.id
            ? {
                ...c,
                totalOrders: c.totalOrders + 1,
                totalSpent: c.totalSpent + newOrder.totalAmount,
                lastOrderDate: new Date().toISOString().split('T')[0],
              }
            : c
        );
      } else {
        return [
          {
            id: `cust-${Date.now()}`,
            storeId: activeStore.id,
            name: newOrder.customerName,
            email: newOrder.customerEmail,
            phone: newOrder.customerPhone,
            city: newOrder.city,
            totalOrders: 1,
            totalSpent: newOrder.totalAmount,
            lastOrderDate: new Date().toISOString().split('T')[0],
            status: 'new',
          },
          ...prev,
        ];
      }
    });
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-100/50">
      {/* Global Navigation Header */}
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        language={language}
        setLanguage={setLanguage}
        stores={stores}
        activeStore={activeStore}
        setActiveStoreId={setActiveStoreId}
        onOpenCreateStoreWizard={() => setIsCreateStoreWizardOpen(true)}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {currentView === 'landing' && (
          <SaaSMarketing
            language={language}
            onEnterDashboard={() => setCurrentView('dashboard')}
            onExploreStorefront={() => setCurrentView('storefront')}
            onOpenCreateStoreWizard={() => setIsCreateStoreWizardOpen(true)}
          />
        )}

        {currentView === 'dashboard' && (
          <MerchantDashboard
            activeStore={activeStore}
            products={products}
            orders={orders}
            customers={customers}
            language={language}
            gateways={paymentGateways}
            onOpenStorefront={() => setCurrentView('storefront')}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onUpdateStoreTheme={handleUpdateStoreTheme}
            onUpdateStorePlan={handleUpdateStorePlan}
            onAddSubscriptionPayment={handleAddSubscriptionPayment}
          />
        )}

        {currentView === 'storefront' && (
          <LiveStorefront
            activeStore={activeStore}
            products={products}
            language={language}
            cart={cart}
            isCartOpen={isCartOpen}
            onCloseCart={() => setIsCartOpen(false)}
            onAddToCart={handleAddToCart}
            onUpdateCartQuantity={handleUpdateCartQuantity}
            onClearCart={handleClearCart}
            onCreateOrder={handleCreateOrder}
            onBackToDashboard={() => setCurrentView('dashboard')}
          />
        )}

        {currentView === 'admin' && (
          <AdminPanel
            language={language}
            users={merchantUsers}
            stores={stores}
            gateways={paymentGateways}
            payments={subscriptionPayments}
            onUpdateUser={handleUpdateUser}
            onAddUser={handleAddUser}
            onDeleteUser={handleDeleteUser}
            onUpdateGateway={handleUpdateGateway}
            onToggleGateway={handleToggleGateway}
            onOpenExportModal={() => setIsExportModalOpen(true)}
            onSwitchToMerchantStore={(storeId: string) => {
              setActiveStoreId(storeId);
              setCurrentView('dashboard');
            }}
          />
        )}
      </main>

      {/* Self-Service Multi-Step Store Creation Wizard */}
      <CreateStoreWizardModal
        isOpen={isCreateStoreWizardOpen}
        onClose={() => setIsCreateStoreWizardOpen(false)}
        language={language}
        onStoreCreated={handleWizardStoreCreated}
        onViewStorefront={() => {
          setIsCreateStoreWizardOpen(false);
          setCurrentView('storefront');
        }}
      />

      {/* Export Project Source Code (ZIP) Modal */}
      <ExportProjectModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        language={language}
      />
    </div>
  );
}
