import React, { useState } from 'react';
import { 
  Users, 
  Shield, 
  CreditCard, 
  Key, 
  Eye, 
  EyeOff, 
  Search, 
  Plus, 
  Filter, 
  Check, 
  X, 
  AlertCircle, 
  RefreshCw, 
  Smartphone, 
  Mail, 
  Store as StoreIcon, 
  Lock, 
  CheckCircle2, 
  Copy, 
  Trash2, 
  Edit3, 
  DollarSign, 
  Calendar, 
  Sliders, 
  ExternalLink, 
  Zap, 
  Sun, 
  ShieldCheck,
  TrendingUp,
  HelpCircle,
  Download,
  FolderArchive,
  HardDriveDownload,
  Terminal,
  Rocket
} from 'lucide-react';
import { 
  Language, 
  MerchantUser, 
  PaymentGatewayConfig, 
  PaymentGatewayProvider, 
  SubscriptionPayment,
  Store 
} from '../../types';

interface AdminPanelProps {
  language: Language;
  users: MerchantUser[];
  stores: Store[];
  gateways: PaymentGatewayConfig[];
  payments: SubscriptionPayment[];
  onUpdateUser: (updatedUser: MerchantUser) => void;
  onAddUser: (newUser: Omit<MerchantUser, 'id'>) => void;
  onDeleteUser: (userId: string) => void;
  onUpdateGateway: (updatedGateway: PaymentGatewayConfig) => void;
  onToggleGateway?: (gatewayId: PaymentGatewayProvider) => void;
  onSwitchToMerchantStore?: (storeId: string) => void;
  onNavigateToMerchantConsole?: () => void;
  onOpenExportModal?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  language,
  users,
  stores,
  gateways,
  payments,
  onUpdateUser,
  onAddUser,
  onDeleteUser,
  onUpdateGateway,
  onToggleGateway,
  onSwitchToMerchantStore,
  onNavigateToMerchantConsole,
  onOpenExportModal,
}) => {
  const isBn = language === 'bn';
  const [activeAdminTab, setActiveAdminTab] = useState<'users' | 'gateways' | 'transactions' | 'export'>('users');
  
  // User search & filters
  const [searchQuery, setSearchQuery] = useState('');
  const [planFilter, setPlanFilter] = useState<'all' | 'starter' | 'growth' | 'enterprise'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  
  // Revealed passwords state map (userId -> boolean)
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Edit / Add User Modal States
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<MerchantUser | null>(null);
  const [newUserForm, setNewUserForm] = useState({
    name: '',
    phone: '',
    email: '',
    password: '',
    storeName: '',
    plan: 'starter' as 'starter' | 'growth' | 'enterprise',
  });

  // Gateway Testing / Edit State
  const [testingGatewayId, setTestingGatewayId] = useState<string | null>(null);
  const [testSuccessId, setTestSuccessId] = useState<string | null>(null);
  const [savedGatewayId, setSavedGatewayId] = useState<string | null>(null);

  // Local editing copy for gateways
  const [gatewayConfigs, setGatewayConfigs] = useState<PaymentGatewayConfig[]>(gateways);

  // Synchronize if prop changes
  React.useEffect(() => {
    setGatewayConfigs(gateways);
  }, [gateways]);

  // Calculations for Admin Metrics
  const totalUsersCount = users.length;
  const starterUsersCount = users.filter((u) => u.plan === 'starter').length;
  const growthUsersCount = users.filter((u) => u.plan === 'growth').length;
  const enterpriseUsersCount = users.filter((u) => u.plan === 'enterprise').length;

  const totalPlatformRevenue = payments.reduce((acc, p) => acc + p.amount, 0);
  const activeStoresCount = stores.length;

  // Filtered users list
  const filteredUsers = users.filter((u) => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.storeName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesPlan = planFilter === 'all' || u.plan === planFilter;
    const matchesStatus = statusFilter === 'all' || u.status === statusFilter;

    return matchesSearch && matchesPlan && matchesStatus;
  });

  const togglePasswordVisibility = (userId: string) => {
    setRevealedPasswords((prev) => ({
      ...prev,
      [userId]: !prev[userId],
    }));
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserForm.name || !newUserForm.phone || !newUserForm.password) return;

    onAddUser({
      name: newUserForm.name,
      phone: newUserForm.phone,
      email: newUserForm.email || `${newUserForm.phone.replace(/[^0-9]/g, '')}@shanju.cloud`,
      password: newUserForm.password,
      storeId: `store-${Date.now()}`,
      storeName: newUserForm.storeName || `${newUserForm.name}'s Store`,
      plan: newUserForm.plan,
      status: 'active',
      joinedDate: new Date().toISOString().split('T')[0],
      lastLogin: 'Just now',
      trialDaysLeft: newUserForm.plan === 'starter' ? 30 : undefined,
      totalPaidBDT: newUserForm.plan === 'growth' ? 500 : newUserForm.plan === 'enterprise' ? 999 : 0,
    });

    setNewUserForm({
      name: '',
      phone: '',
      email: '',
      password: '',
      storeName: '',
      plan: 'starter',
    });
    setIsAddUserModalOpen(false);
  };

  const handleSaveEditUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    onUpdateUser(editingUser);
    setEditingUser(null);
  };

  const handleQuickPlanChange = (userId: string, newPlan: 'starter' | 'growth' | 'enterprise') => {
    const targetUser = users.find((u) => u.id === userId);
    if (!targetUser) return;
    onUpdateUser({
      ...targetUser,
      plan: newPlan,
      trialDaysLeft: newPlan === 'starter' ? 30 : undefined,
    });
  };

  const handleToggleUserStatus = (userId: string) => {
    const targetUser = users.find((u) => u.id === userId);
    if (!targetUser) return;
    onUpdateUser({
      ...targetUser,
      status: targetUser.status === 'active' ? 'suspended' : 'active',
    });
  };

  const handleGatewayFieldChange = (
    gatewayId: PaymentGatewayProvider,
    field: keyof PaymentGatewayConfig,
    value: any
  ) => {
    setGatewayConfigs((prev) =>
      prev.map((g) => (g.id === gatewayId ? { ...g, [field]: value } : g))
    );
  };

  const handleSaveGateway = (gateway: PaymentGatewayConfig) => {
    onUpdateGateway(gateway);
    setSavedGatewayId(gateway.id);
    setTimeout(() => setSavedGatewayId(null), 2500);
  };

  const handleTestGateway = (gatewayId: string) => {
    setTestingGatewayId(gatewayId);
    setTestSuccessId(null);
    setTimeout(() => {
      setTestingGatewayId(null);
      setTestSuccessId(gatewayId);
      setTimeout(() => setTestSuccessId(null), 3500);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 pb-20">
      {/* Top Banner & Header */}
      <div className="bg-slate-950 border-b border-slate-800 sticky top-16 z-20 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                      {isBn ? 'শানজু সুপার অ্যাডমিন প্যানেল' : 'Shanju SaaS Super Admin'}
                    </h1>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-bold border border-emerald-500/30">
                      Platform Root
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isBn 
                      ? 'সকল মার্চেন্ট ইউজার, সাবস্ক্রিপশন প্ল্যান ও পেমেন্ট গেটওয়ে সেন্ট্রাল কনফিগারেশন' 
                      : 'Central control room for merchant accounts, subscription tiers & payment gateway APIs'}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Action / View Switcher */}
            <div className="flex items-center gap-3">
              {onNavigateToMerchantConsole && (
                <button
                  type="button"
                  id="admin-to-merchant-btn"
                  onClick={onNavigateToMerchantConsole}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                >
                  <StoreIcon className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{isBn ? 'মার্চেন্ট ড্যাশবোর্ডে ফিরে যান' : 'Back to Merchant Console'}</span>
                </button>
              )}

              <button
                type="button"
                id="admin-add-merchant-btn"
                onClick={() => setIsAddUserModalOpen(true)}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-500/20 transition-all transform active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? '+ নতুন মার্চেন্ট ইউজার যোগ করুন' : '+ Add Merchant User'}</span>
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 mt-5 border-t border-slate-800/80 pt-3">
            <button
              id="admin-tab-users"
              onClick={() => setActiveAdminTab('users')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeAdminTab === 'users'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>{isBn ? 'ইউজার ও অ্যাকাউন্টস' : 'Merchants & Users'}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-white text-[10px]">
                {users.length}
              </span>
            </button>

            <button
              id="admin-tab-gateways"
              onClick={() => setActiveAdminTab('gateways')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeAdminTab === 'gateways'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>{isBn ? 'পেমেন্ট গেটওয়ে সেটআপ' : 'Payment Gateways'}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px]">
                AamarPay • Shohoz • Shurjo
              </span>
            </button>

            <button
              id="admin-tab-transactions"
              onClick={() => setActiveAdminTab('transactions')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeAdminTab === 'transactions'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>{isBn ? 'প্ল্যান পেমেন্ট হিস্ট্রি' : 'Subscription Ledger'}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-emerald-400 text-[10px] font-mono">
                ৳{totalPlatformRevenue.toLocaleString()}
              </span>
            </button>

            <button
              id="admin-tab-export"
              onClick={() => setActiveAdminTab('export')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeAdminTab === 'export'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FolderArchive className="w-4 h-4 text-emerald-400" />
              <span>{isBn ? 'কোড ও হোস্টিং এক্সপোর্ট (ZIP)' : 'Export Project ZIP'}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono">
                ZIP Ready
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Metric Cards (Visible across all tabs for executive overview) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>{isBn ? 'মোট রেজিস্টার্ড ইউজার' : 'Total Merchants'}</span>
              <Users className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="mt-2 text-2xl font-black text-white">{totalUsersCount}</div>
            <div className="mt-1 text-[11px] text-slate-400 flex items-center gap-1">
              <span className="text-emerald-400 font-bold">100%</span> {isBn ? 'সক্রিয় ক্লাউড অ্যাকাউন্ট' : 'active cloud access'}
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>{isBn ? '১ মাস ফ্রি ট্রায়াল ইউজার' : 'Free 1-Mo Trial (৳০)'}</span>
              <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">
                Starter
              </span>
            </div>
            <div className="mt-2 text-2xl font-black text-white">{starterUsersCount}</div>
            <div className="mt-1 text-[11px] text-amber-400">
              {isBn ? '৫০টি প্রোডাক্ট ও ফ্রি সাবডোমেন' : 'Up to 50 products catalog'}
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>{isBn ? 'গ্রোথ প্ল্যান (৳৫০০/মাস)' : 'Growth Tier (৳500/mo)'}</span>
              <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold">
                Growth
              </span>
            </div>
            <div className="mt-2 text-2xl font-black text-blue-400">{growthUsersCount}</div>
            <div className="mt-1 text-[11px] text-slate-400">
              {isBn ? '৯AM-১১PM লাইভ চ্যাট সাপোর্ট' : '9AM-11PM live chat support'}
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>{isBn ? 'প্রো এন্টারপ্রাইজ (৳৯৯৯/মাস)' : 'Pro Enterprise (৳999/mo)'}</span>
              <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px] font-bold">
                Enterprise
              </span>
            </div>
            <div className="mt-2 text-2xl font-black text-purple-400">{enterpriseUsersCount}</div>
            <div className="mt-1 text-[11px] text-slate-400">
              {isBn ? 'আনলিমিটেড প্রোডাক্ট ও কাস্টম ডোমেন' : 'Unlimited & Custom domain'}
            </div>
          </div>
        </div>

        {/* TAB 1: USERS & ACCOUNTS */}
        {activeAdminTab === 'users' && (
          <div className="space-y-4">
            {/* Search & Filter Toolbar */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  id="admin-search-users-input"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={isBn ? 'নাম, ফোন নম্বর, ইমেইল বা স্টোর...' : 'Search by name, phone, email, store...'}
                  className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
                  <span className="text-[11px] text-slate-400 px-2 flex items-center gap-1">
                    <Filter className="w-3 h-3" /> {isBn ? 'প্ল্যান:' : 'Plan:'}
                  </span>
                  <button
                    onClick={() => setPlanFilter('all')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                      planFilter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {isBn ? 'সকল' : 'All'}
                  </button>
                  <button
                    onClick={() => setPlanFilter('starter')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                      planFilter === 'starter' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {isBn ? 'ফ্রি (১ মাস)' : 'Free'}
                  </button>
                  <button
                    onClick={() => setPlanFilter('growth')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                      planFilter === 'growth' ? 'bg-blue-600/30 text-blue-300' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {isBn ? 'গ্রোথ (৳৫০০)' : 'Growth (500)'}
                  </button>
                  <button
                    onClick={() => setPlanFilter('enterprise')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                      planFilter === 'enterprise' ? 'bg-purple-600/30 text-purple-300' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {isBn ? 'প্রো (৳৯৯৯)' : 'Pro (999)'}
                  </button>
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="bg-slate-900 border border-slate-800 text-xs text-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">{isBn ? 'সকল স্ট্যাটাস' : 'All Status'}</option>
                  <option value="active">{isBn ? 'সক্রিয় (Active)' : 'Active'}</option>
                  <option value="suspended">{isBn ? 'স্থগিত (Suspended)' : 'Suspended'}</option>
                </select>
              </div>
            </div>

            {/* Users Accounts Table */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                      <th className="py-3.5 px-4">{isBn ? 'ইউজার নাম ও যোগাযোগ' : 'Merchant Name & Contact'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'ফোন নম্বর' : 'Phone Number'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'অ্যাকাউন্ট পাসওয়ার্ড' : 'Password Credentials'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'স্টোর ও সাবডোমেন' : 'Store & Subdomain'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'বর্তমান প্ল্যান (পরিবর্তন)' : 'Active Plan (Tier)'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                      <th className="py-3.5 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Actions'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredUsers.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-slate-500">
                          <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
                          <p>{isBn ? 'কোনো ইউজার পাওয়া যায়নি' : 'No merchant accounts match your search filters'}</p>
                        </td>
                      </tr>
                    ) : (
                      filteredUsers.map((user) => {
                        const isPasswordRevealed = !!revealedPasswords[user.id];

                        return (
                          <tr key={user.id} className="hover:bg-slate-900/50 transition-colors">
                            {/* User Name & Email */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center font-bold text-slate-950 text-xs shrink-0 shadow-xs">
                                  {user.name.charAt(0)}
                                </div>
                                <div className="min-w-0">
                                  <div className="font-bold text-slate-100 truncate flex items-center gap-1.5">
                                    <span>{user.name}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-400 truncate flex items-center gap-1">
                                    <Mail className="w-3 h-3 text-slate-500 shrink-0" />
                                    <span>{user.email}</span>
                                  </div>
                                </div>
                              </div>
                            </td>

                            {/* Phone Number */}
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <div className="flex items-center gap-1.5 font-mono text-emerald-400 font-bold bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 w-fit">
                                <Smartphone className="w-3 h-3 text-slate-400" />
                                <span>{user.phone}</span>
                                <button
                                  type="button"
                                  onClick={() => handleCopyText(user.phone, `phone-${user.id}`)}
                                  className="text-slate-500 hover:text-slate-300 ml-1"
                                  title="Copy Phone"
                                >
                                  {copiedId === `phone-${user.id}` ? (
                                    <Check className="w-3 h-3 text-emerald-400" />
                                  ) : (
                                    <Copy className="w-3 h-3" />
                                  )}
                                </button>
                              </div>
                            </td>

                            {/* Password Credentials */}
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 rounded-lg px-2.5 py-1 w-fit">
                                <Lock className="w-3 h-3 text-amber-400 shrink-0" />
                                <span className="font-mono text-xs font-semibold text-slate-200">
                                  {isPasswordRevealed ? user.password : '••••••••••••'}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => togglePasswordVisibility(user.id)}
                                  className="p-1 text-slate-400 hover:text-white rounded transition-colors ml-1"
                                  title={isPasswordRevealed ? 'Hide Password' : 'Show Password'}
                                >
                                  {isPasswordRevealed ? (
                                    <EyeOff className="w-3.5 h-3.5" />
                                  ) : (
                                    <Eye className="w-3.5 h-3.5" />
                                  )}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleCopyText(user.password, `pass-${user.id}`)}
                                  className="p-1 text-slate-400 hover:text-white rounded transition-colors"
                                  title="Copy Password"
                                >
                                  {copiedId === `pass-${user.id}` ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                            </td>

                            {/* Store Name & Subdomain */}
                            <td className="py-3.5 px-4">
                              <div className="font-semibold text-slate-200 truncate">{user.storeName}</div>
                              <div className="text-[11px] font-mono text-slate-400 truncate">
                                {user.storeName.toLowerCase().replace(/[^a-z0-9]/g, '-')}.shanju.cloud
                              </div>
                            </td>

                            {/* Plan with inline switcher */}
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <select
                                  value={user.plan}
                                  onChange={(e) => handleQuickPlanChange(user.id, e.target.value as any)}
                                  className={`text-xs font-bold px-2.5 py-1 rounded-lg border focus:outline-none transition-colors ${
                                    user.plan === 'starter'
                                      ? 'bg-slate-900 border-slate-700 text-slate-300'
                                      : user.plan === 'growth'
                                      ? 'bg-blue-950/80 border-blue-600/40 text-blue-300'
                                      : 'bg-purple-950/80 border-purple-600/40 text-purple-300'
                                  }`}
                                >
                                  <option value="starter">
                                    {isBn ? 'ফ্রি ১ মাস (Starter - ৳০)' : 'Starter (Free 1-Mo)'}
                                  </option>
                                  <option value="growth">
                                    {isBn ? 'গ্রোথ (Growth - ৳৫০০/মাস)' : 'Growth (৳500/mo)'}
                                  </option>
                                  <option value="enterprise">
                                    {isBn ? 'প্রো (Enterprise - ৳৯৯৯/মাস)' : 'Pro Enterprise (৳999/mo)'}
                                  </option>
                                </select>
                                {user.plan === 'starter' && user.trialDaysLeft && (
                                  <span className="text-[10px] text-amber-400 font-semibold">
                                    {user.trialDaysLeft}d left
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Status */}
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <button
                                type="button"
                                onClick={() => handleToggleUserStatus(user.id)}
                                className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border transition-colors ${
                                  user.status === 'active'
                                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                                    : 'bg-rose-500/10 text-rose-400 border-rose-500/30 hover:bg-rose-500/20'
                                }`}
                                title={isBn ? 'স্ট্যাটাস টগল করতে ক্লিক করুন' : 'Click to toggle status'}
                              >
                                <span className={`w-1.5 h-1.5 rounded-full ${user.status === 'active' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                                <span className="capitalize">{user.status}</span>
                              </button>
                            </td>

                            {/* Actions */}
                            <td className="py-3.5 px-4 whitespace-nowrap text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => setEditingUser(user)}
                                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                                  title={isBn ? 'ইউজার তথ্য সম্পাদনা করুন' : 'Edit User Credentials'}
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(isBn ? `আপনি কি নিশ্চিত যে ${user.name} ইউজারটি মুছে ফেলতে চান?` : `Are you sure you want to delete ${user.name}?`)) {
                                      onDeleteUser(user.id);
                                    }
                                  }}
                                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors"
                                  title={isBn ? 'মুছে ফেলুন' : 'Delete User'}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PAYMENT GATEWAY PROVIDER SETUP */}
        {activeAdminTab === 'gateways' && (
          <div className="space-y-6">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-emerald-400" />
                    <span>{isBn ? 'প্ল্যাটফর্ম সাবস্ক্রিপশন পেমেন্ট গেটওয়ে কনফিগারেশন' : 'SaaS Subscription Payment Gateway Providers'}</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    {isBn
                      ? 'মার্চেন্টরা যখন গ্রোথ (৳৫০০) বা প্রো এন্টারপ্রাইজ (৳৯৯৯) প্ল্যান কিনবে, তখন এই সক্রিয় গেটওয়েগুলোর মাধ্যমে পেমেন্ট করতে পারবে।'
                      : 'Configure API credentials for AamarPay, Shohoz Pay, and ShurjoPay. Enabled gateways will be presented to merchants during plan checkout.'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 font-mono border border-emerald-500/20 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Live Ready & Sandbox Enabled</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Gateways Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {gatewayConfigs.map((gateway) => {
                const isTesting = testingGatewayId === gateway.id;
                const isTestSuccess = testSuccessId === gateway.id;
                const isSaved = savedGatewayId === gateway.id;

                return (
                  <div
                    key={gateway.id}
                    id={`gateway-card-${gateway.id}`}
                    className={`bg-slate-950 border rounded-2xl p-6 transition-all shadow-xl ${
                      gateway.isEnabled
                        ? 'border-slate-800 hover:border-slate-700'
                        : 'border-slate-800/50 opacity-80'
                    }`}
                  >
                    {/* Gateway Header */}
                    <div className="flex items-start justify-between pb-4 border-b border-slate-800/80">
                      <div className="flex items-center gap-3">
                        <div className="text-2xl p-2.5 rounded-xl bg-slate-900 border border-slate-800 shadow-inner">
                          {gateway.logo}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-base text-white">
                              {isBn ? gateway.nameBn : gateway.name}
                            </h3>
                            {gateway.id === 'aamarpay' && (
                              <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-500/30">
                                Recommended
                              </span>
                            )}
                            {gateway.id === 'shohozpay' && (
                              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                                Zero-Redirect
                              </span>
                            )}
                            {gateway.id === 'shurjopay' && (
                              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                                Central PSO
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-400 mt-1 max-w-sm leading-relaxed">
                            {isBn ? gateway.descriptionBn : gateway.description}
                          </p>
                        </div>
                      </div>

                      {/* Enable/Disable Toggle */}
                      <div className="flex flex-col items-end gap-1.5 shrink-0">
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={gateway.isEnabled}
                            onChange={(e) =>
                              handleGatewayFieldChange(gateway.id, 'isEnabled', e.target.checked)
                            }
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                        </label>
                        <span className="text-[10px] font-bold text-slate-400">
                          {gateway.isEnabled ? (isBn ? 'সক্রিয়' : 'Enabled') : (isBn ? 'নিষ্ক্রিয়' : 'Disabled')}
                        </span>
                      </div>
                    </div>

                    {/* Configuration Form Inputs */}
                    <div className="mt-5 space-y-4">
                      {/* Environment Mode Selection */}
                      <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                        <div>
                          <span className="text-xs font-bold text-slate-200 block">
                            {isBn ? 'গেটওয়ে রানটাইম মোড' : 'Runtime Environment'}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            {gateway.isLiveMode 
                              ? (isBn ? '🔴 লাইভ প্রোডাকশন এপিআই' : '🔴 Live Production Real Transactions') 
                              : (isBn ? '🟢 স্যান্ডবক্স টেস্ট মোড (কোনো আসল টাকা কাটবে না)' : '🟢 Sandbox Test Mode (Zero real charge)')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                          <button
                            type="button"
                            onClick={() => handleGatewayFieldChange(gateway.id, 'isLiveMode', false)}
                            className={`px-2.5 py-1 rounded-md font-bold text-[11px] transition-colors ${
                              !gateway.isLiveMode
                                ? 'bg-emerald-600 text-white'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            Sandbox
                          </button>
                          <button
                            type="button"
                            onClick={() => handleGatewayFieldChange(gateway.id, 'isLiveMode', true)}
                            className={`px-2.5 py-1 rounded-md font-bold text-[11px] transition-colors ${
                              gateway.isLiveMode
                                ? 'bg-rose-600 text-white'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            Live
                          </button>
                        </div>
                      </div>

                      {/* Store / Merchant ID */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          {gateway.id === 'aamarpay' 
                            ? (isBn ? 'আমার পে স্টোর আইডি (Store ID / Merchant ID)' : 'AamarPay Store ID')
                            : gateway.id === 'shohozpay'
                            ? (isBn ? 'সহজ পে মার্চেন্ট আইডি (Merchant ID)' : 'Shohoz Pay Merchant ID')
                            : (isBn ? 'সূর্য পে ইউজারনেম / মার্চেন্ট আইডি' : 'ShurjoPay Merchant ID')}
                        </label>
                        <input
                          type="text"
                          value={gateway.storeIdOrMerchantId}
                          onChange={(e) =>
                            handleGatewayFieldChange(gateway.id, 'storeIdOrMerchantId', e.target.value)
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                          placeholder="e.g. your_store_id"
                        />
                      </div>

                      {/* Signature / Secret Key */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          {gateway.id === 'aamarpay' 
                            ? (isBn ? 'সিগনেচার কী (Signature Key)' : 'Signature Key')
                            : gateway.id === 'shohozpay'
                            ? (isBn ? 'মার্চেন্ট সিক্রেট কী (Secret Key)' : 'Merchant Secret Key')
                            : (isBn ? 'মার্চেন্ট পাসওয়ার্ড / সিক্রেট টোকেন' : 'Merchant Secret Password / Token')}
                        </label>
                        <div className="relative">
                          <input
                            type="password"
                            value={gateway.signatureOrSecretKey}
                            onChange={(e) =>
                              handleGatewayFieldChange(gateway.id, 'signatureOrSecretKey', e.target.value)
                            }
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500 pr-10"
                            placeholder="Enter gateway secret key"
                          />
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">
                            <Key className="w-3.5 h-3.5" />
                          </div>
                        </div>
                      </div>

                      {/* App Key or Password if present */}
                      {gateway.appKeyOrPassword !== undefined && (
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                            {gateway.id === 'shohozpay' 
                              ? (isBn ? 'সহজ পে অ্যাপ সিক্রেট (App Secret)' : 'App Secret') 
                              : (isBn ? 'এপিআই পাসওয়ার্ড / কী' : 'API Password / Key')}
                          </label>
                          <input
                            type="password"
                            value={gateway.appKeyOrPassword}
                            onChange={(e) =>
                              handleGatewayFieldChange(gateway.id, 'appKeyOrPassword', e.target.value)
                            }
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                      )}

                      {/* Webhook URL with Copy */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          {isBn ? 'আইপিএন ওয়েবহুক ইউআরএল (Webhook / Callback URL)' : 'Instant Payment Notification (IPN) Webhook'}
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            readOnly
                            value={gateway.webhookUrl}
                            className="w-full px-3 py-1.5 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-400 font-mono select-all focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleCopyText(gateway.webhookUrl, `webhook-${gateway.id}`)}
                            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs shrink-0 transition-colors"
                            title="Copy Webhook"
                          >
                            {copiedId === `webhook-${gateway.id}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Action buttons: Test Connection & Save */}
                      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
                        <button
                          type="button"
                          id={`test-gateway-${gateway.id}`}
                          onClick={() => handleTestGateway(gateway.id)}
                          disabled={isTesting}
                          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-colors"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin text-amber-400' : 'text-slate-400'}`} />
                          <span>
                            {isTesting
                              ? (isBn ? 'পিংকানেকশন যাচাই হচ্ছে...' : 'Pinging Gateway...')
                              : (isBn ? 'কানেকশন টেস্ট করুন' : 'Test API Ping')}
                          </span>
                        </button>

                        <button
                          type="button"
                          id={`save-gateway-${gateway.id}`}
                          onClick={() => handleSaveGateway(gateway)}
                          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                            isSaved
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-800 hover:bg-slate-700 text-white'
                          }`}
                        >
                          {isSaved ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>{isBn ? 'সংরক্ষিত হয়েছে!' : 'Saved!'}</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>{isBn ? 'সেটিংস সেভ করুন' : 'Save Config'}</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* Ping Result Alert */}
                      {isTestSuccess && (
                        <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] flex items-center gap-2 animate-in fade-in">
                          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                          <span>
                            {isBn
                              ? 'API কানেকশন সফল! হ্যান্ডশেক রেসপন্স: 200 OK (Latency: 72ms)।'
                              : 'Gateway API Connected! Handshake Response: 200 OK (Latency: 72ms).'}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: SUBSCRIPTION PAYMENT TRANSACTIONS LEDGER */}
        {activeAdminTab === 'transactions' && (
          <div className="space-y-4">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <span>{isBn ? 'মার্চেন্ট প্ল্যান সাবস্ক্রিপশন পেমেন্ট হিস্ট্রি ও লেজার' : 'Subscription Revenue Transactions Ledger'}</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {isBn
                    ? 'AamarPay, Shohoz Pay ও ShurjoPay এর মাধ্যমে পরিশোধিত সকল স্টোর প্ল্যান পেমেন্ট লগ।'
                    : 'Real-time transaction logs collected through configured payment gateway providers.'}
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block">{isBn ? 'মোট সংগৃহীত রেভিনিউ' : 'Total Collected Revenue'}</span>
                <span className="text-xl font-black text-emerald-400 font-mono">
                  ৳{totalPlatformRevenue.toLocaleString()} BDT
                </span>
              </div>
            </div>

            {/* Transactions Table */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                      <th className="py-3.5 px-4">{isBn ? 'ট্রানজেকশন আইডি' : 'Trx ID & Invoice'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'মার্চেন্ট ও স্টোর' : 'Merchant & Store'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'প্ল্যান' : 'Plan Tier'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'টাকার পরিমাণ' : 'Amount'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'পেমেন্ট গেটওয়ে' : 'Gateway Provider'}</th>
                      <th className="py-3.5 px-4">{isBn ? 'তারিখ' : 'Date & Time'}</th>
                      <th className="py-3.5 px-4 text-right">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {payments.map((trx) => (
                      <tr key={trx.id} className="hover:bg-slate-900/50 transition-colors">
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="font-mono text-emerald-400 font-bold">{trx.transactionId}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{trx.id}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-200">{trx.userName}</div>
                          <div className="text-[11px] text-slate-400">{trx.storeName} ({trx.userPhone})</div>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                            trx.planId === 'growth'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          }`}>
                            {trx.planName}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="font-mono text-white font-black text-sm">
                            ৳{trx.amount.toLocaleString()}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="capitalize font-semibold text-slate-300 px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px]">
                            {trx.gateway === 'aamarpay' ? '💳 AamarPay' : trx.gateway === 'shohozpay' ? '⚡ Shohoz Pay' : trx.gateway === 'shurjopay' ? '☀️ ShurjoPay' : trx.gateway}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap text-slate-400 text-[11px]">
                          {trx.date}
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap text-right">
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[11px] font-bold border border-emerald-500/30">
                            ✓ {isBn ? 'সফল' : 'Completed'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: EXPORT PROJECT & HOSTING PACK */}
        {activeAdminTab === 'export' && (
          <div className="space-y-6">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                    <FolderArchive className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-white">
                        {isBn ? 'প্রজেক্ট সোর্স কোড ও হোস্টিং এক্সপোর্ট সেন্টার' : 'Project Source Code & Export Center'}
                      </h3>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        ZIP Ready
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      {isBn
                        ? 'আপনার ওয়েবসাইটের সম্পূর্ণ কোড জিপ ফাইল আকারে ডাউনলোড করে সরাসরি সিপ্যানেল বা যেকোনো সার্ভারে লাইভ করুন'
                        : 'Download full source code ZIP files and deploy directly to cPanel, Vercel, Netlify, or VPS'}
                    </p>
                  </div>
                </div>

                {onOpenExportModal && (
                  <button
                    onClick={onOpenExportModal}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30 transition-all"
                  >
                    <HardDriveDownload className="w-4 h-4" />
                    <span>{isBn ? 'এক্সপোর্ট পপআপ খুলুন' : 'Open Export Modal'}</span>
                  </button>
                )}
              </div>

              {/* Two Main Download Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                {/* 1. Full Source Code ZIP */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                        {isBn ? 'সোর্স কোড' : 'Source Code'}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">~150 KB (.ZIP)</span>
                    </div>
                    <h4 className="text-base font-bold text-white">
                      {isBn ? 'সম্পূর্ণ সোর্স কোড প্যাকেজ' : 'Full Source Code Package'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {isBn
                        ? 'React 19, TypeScript, Vite, Tailwind CSS, কম্পোনেন্টসমূহ ও কনফিগারেশন ফাইল অন্তর্ভুক্ত। VS Code এ ওপেন ও লোকাল রান করার জন্য পারফেক্ট।'
                        : 'Contains all raw React components, TypeScript files, Tailwind config, and package.json for local development.'}
                    </p>

                    <div className="mt-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5 text-xs text-slate-300">
                      <div className="text-slate-400 font-mono text-[11px]">$ npm install</div>
                      <div className="text-slate-400 font-mono text-[11px]">$ npm run dev</div>
                    </div>
                  </div>

                  <div className="mt-5 space-y-2">
                    <a
                      href="/shanju-source-code.zip"
                      download="shanju-source-code.zip"
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30 transition-all"
                    >
                      <Download className="w-4 h-4" />
                      <span>{isBn ? 'সোর্স কোড ZIP ডাউনলোড (১-ক্লিক)' : 'Download Source ZIP'}</span>
                    </a>
                  </div>
                </div>

                {/* 2. Ready-to-deploy Production Dist ZIP */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                        {isBn ? 'প্রোডাকশন বিল্ড' : 'Production Build'}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">~235 KB (.ZIP)</span>
                    </div>
                    <h4 className="text-base font-bold text-white">
                      {isBn ? 'হোস্টিং ডিপ্লয় বিল্ড (dist)' : 'Hosting Deploy Build (dist)'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {isBn
                        ? 'কম্পাইল্ড অপ্টিমাইজড HTML, CSS, JavaScript ও .htaccess ফাইল। কোনো টার্মিনাল কমান্ড ছাড়াই cPanel public_html-এ আপলোড ও আনজিপ করলেই সাইট লাইভ হয়ে যাবে।'
                        : 'Pre-compiled minified web assets with .htaccess ready for cPanel public_html, Netlify, or Hostinger.'}
                    </p>

                    <div className="mt-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5 text-xs text-slate-300">
                      <div className="text-emerald-400 text-[11px]">✓ No Node.js or build required on hosting</div>
                      <div className="text-emerald-400 text-[11px]">✓ Works on any Shared Hosting / cPanel</div>
                    </div>
                  </div>

                  <div className="mt-5 space-y-2">
                    <a
                      href="/shanju-production-dist.zip"
                      download="shanju-production-dist.zip"
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md shadow-teal-600/30 transition-all"
                    >
                      <Rocket className="w-4 h-4" />
                      <span>{isBn ? 'ডিপ্লয় বিল্ড ZIP ডাউনলোড (১-ক্লিক)' : 'Download Production Dist ZIP'}</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* cPanel Quick Steps */}
              <div className="mt-8 pt-6 border-t border-slate-800">
                <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'cPanel-এ ওয়েবসাইট লাইভ করার ৪টি সহজ ধাপ:' : '4 Simple Steps to Deploy on cPanel:'}</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="font-bold text-emerald-400">১. ডাউনলোড:</span>
                    <p className="text-slate-400 mt-1">উপরে থাকা "ডিপ্লয় বিল্ড ZIP" ফাইলটি ডাউনলোড করুন।</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="font-bold text-emerald-400">২. ফাইল ম্যানেজার:</span>
                    <p className="text-slate-400 mt-1">cPanel-এ লগইন করে File Manager-এর public_html ফোল্ডারে যান।</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="font-bold text-emerald-400">৩. আনজিপ করুন:</span>
                    <p className="text-slate-400 mt-1">ফাইলটি আপলোড করে রাইট ক্লিক করে "Extract" করুন।</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="font-bold text-emerald-400">৪. ব্রাউজ করুন:</span>
                    <p className="text-slate-400 mt-1">আপনার ডোমেন ব্রাউজারে লিখলেই সাথে সাথে ওয়েবসাইট লাইভ দেখতে পাবেন!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* MODAL: ADD NEW MERCHANT USER */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'নতুন মার্চেন্ট ইউজার অ্যাকাউন্ট তৈরি' : 'Create Merchant Account'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddUserModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'মার্চেন্টের নাম *' : 'Merchant Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUserForm.name}
                  onChange={(e) => setNewUserForm({ ...newUserForm, name: e.target.value })}
                  placeholder="e.g. সাদিয়া ইসলাম"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ফোন নম্বর *' : 'Phone Number *'}
                </label>
                <input
                  type="tel"
                  required
                  value={newUserForm.phone}
                  onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                  placeholder="e.g. 01711-223344"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ইমেইল অ্যাড্রেস' : 'Email Address'}
                </label>
                <input
                  type="email"
                  value={newUserForm.email}
                  onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                  placeholder="e.g. merchant@shanju.cloud"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'পাসওয়ার্ড *' : 'Password *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUserForm.password}
                  onChange={(e) => setNewUserForm({ ...newUserForm, password: e.target.value })}
                  placeholder="Set account password"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'স্টোরের নাম' : 'Store Name'}
                </label>
                <input
                  type="text"
                  value={newUserForm.storeName}
                  onChange={(e) => setNewUserForm({ ...newUserForm, storeName: e.target.value })}
                  placeholder="e.g. Dhaka Closet"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'প্ল্যান নির্বাচন করুন' : 'Assign Plan'}
                </label>
                <select
                  value={newUserForm.plan}
                  onChange={(e) => setNewUserForm({ ...newUserForm, plan: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="starter">{isBn ? '১ মাস ফ্রি ট্রায়াল (৳০)' : 'Starter (Free 1-Month)'}</option>
                  <option value="growth">{isBn ? 'গ্রোথ প্ল্যান (৳৫০০ / মাস)' : 'Growth Tier (৳500 / month)'}</option>
                  <option value="enterprise">{isBn ? 'প্রো এন্টারপ্রাইজ (৳৯৯৯ / মাস)' : 'Pro Enterprise (৳999 / month)'}</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30"
                >
                  {isBn ? 'অ্যাকাউন্ট তৈরি করুন' : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT USER & CREDENTIALS */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'ইউজার তথ্য ও পাসওয়ার্ড সম্পাদনা' : 'Edit Merchant Credentials'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditUser} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'মার্চেন্টের নাম' : 'Merchant Name'}
                </label>
                <input
                  type="text"
                  required
                  value={editingUser.name}
                  onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ফোন নম্বর' : 'Phone Number'}
                </label>
                <input
                  type="tel"
                  required
                  value={editingUser.phone}
                  onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ইমেইল অ্যাড্রেস' : 'Email Address'}
                </label>
                <input
                  type="email"
                  value={editingUser.email}
                  onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'অ্যাকাউন্ট পাসওয়ার্ড' : 'Account Password'}
                </label>
                <input
                  type="text"
                  required
                  value={editingUser.password}
                  onChange={(e) => setEditingUser({ ...editingUser, password: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'প্ল্যান' : 'Subscription Plan'}
                </label>
                <select
                  value={editingUser.plan}
                  onChange={(e) => setEditingUser({ ...editingUser, plan: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="starter">{isBn ? '১ মাস ফ্রি ট্রায়াল (৳০)' : 'Starter (Free 1-Month)'}</option>
                  <option value="growth">{isBn ? 'গ্রোথ প্ল্যান (৳৫০০ / মাস)' : 'Growth Tier (৳500 / month)'}</option>
                  <option value="enterprise">{isBn ? 'প্রো এন্টারপ্রাইজ (৳৯৯৯ / মাস)' : 'Pro Enterprise (৳999 / month)'}</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30"
                >
                  {isBn ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
