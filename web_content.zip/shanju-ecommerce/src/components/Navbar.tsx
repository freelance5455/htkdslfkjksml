import React, { useState } from 'react';
import { 
  Store as StoreIcon, 
  ShoppingBag, 
  LayoutDashboard, 
  Globe, 
  ChevronDown, 
  Plus, 
  Bell, 
  ExternalLink,
  Sparkles,
  ArrowRight,
  X,
  ShieldCheck,
  Download,
  FolderArchive
} from 'lucide-react';
import { AppView, Language, Store } from '../types';
import { platformTranslations } from '../data/initialData';

interface NavbarProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  stores: Store[];
  activeStore: Store;
  setActiveStoreId: (id: string) => void;
  onOpenCreateStoreWizard: () => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenExportModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  language,
  setLanguage,
  stores,
  activeStore,
  setActiveStoreId,
  onOpenCreateStoreWizard,
  cartCount,
  onOpenCart,
  onOpenExportModal,
}) => {
  const [isStoreMenuOpen, setIsStoreMenuOpen] = useState(false);
  const [showNotificationPopup, setShowNotificationPopup] = useState(false);

  const t = platformTranslations[language];

  return (
    <>
      {/* Top Notification Announcement */}
      <header className="sticky top-0 z-40 bg-slate-900 text-white border-b border-slate-800 backdrop-blur-md bg-opacity-95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Brand / Logo */}
            <div className="flex items-center gap-6">
              <button 
                id="brand-logo-btn"
                onClick={() => setCurrentView('landing')}
                className="flex items-center gap-2.5 group text-left focus:outline-none"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                  <StoreIcon className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-xl tracking-tight text-white font-sans">
                      Shanju
                    </span>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Commerce
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                    {language === 'bn' ? 'মাল্টি-স্টোর কমার্স ক্লাউড' : 'Cloud Commerce Engine'}
                  </p>
                </div>
              </button>

              {/* View Switcher Tabs */}
              <nav className="hidden md:flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
                <button
                  id="nav-tab-landing"
                  onClick={() => setCurrentView('landing')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    currentView === 'landing'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5" />
                  {language === 'bn' ? 'প্ল্যাটফর্ম ফিচার্স' : 'SaaS Platform'}
                </button>

                <button
                  id="nav-tab-dashboard"
                  onClick={() => setCurrentView('dashboard')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    currentView === 'dashboard'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  {language === 'bn' ? 'মার্চেন্ট কনসোল' : 'Merchant Dashboard'}
                </button>

                <button
                  id="nav-tab-storefront"
                  onClick={() => setCurrentView('storefront')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    currentView === 'storefront'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  {language === 'bn' ? 'লাইভ স্টোরফ্রন্ট' : 'Live Storefront'}
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                </button>

                <button
                  id="nav-tab-admin"
                  onClick={() => setCurrentView('admin')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    currentView === 'admin'
                      ? 'bg-emerald-600 text-white shadow-sm ring-1 ring-emerald-400/50'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  {language === 'bn' ? 'সুপার অ্যাডমিন' : 'Admin Panel'}
                  <span className="text-[10px] bg-slate-900 px-1.5 py-0.2 rounded text-emerald-400 font-mono">
                    PRO
                  </span>
                </button>
              </nav>
            </div>

            {/* Right Action Controls */}
            <div className="flex items-center gap-3">
              {/* Store Switcher Dropdown */}
              <div className="relative">
                <button
                  id="store-switcher-btn"
                  onClick={() => setIsStoreMenuOpen(!isStoreMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700/80 border border-slate-700 rounded-lg text-xs font-medium text-slate-200 transition-colors"
                >
                  <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
                  <span className="max-w-[120px] sm:max-w-[150px] truncate font-semibold">
                    {activeStore.name}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {isStoreMenuOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="px-2 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {language === 'bn' ? 'আপনার স্টোরসমূহ' : 'Your Managed Stores'}
                    </div>
                    <div className="space-y-1 my-1">
                      {stores.map((store) => (
                        <button
                          key={store.id}
                          id={`select-store-${store.id}`}
                          onClick={() => {
                            setActiveStoreId(store.id);
                            setIsStoreMenuOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-colors ${
                            store.id === activeStore.id
                              ? 'bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30'
                              : 'text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                            <span className="truncate">{store.name}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 capitalize">
                            {store.plan}
                          </span>
                        </button>
                      ))}
                    </div>

                    <div className="pt-2 border-t border-slate-800">
                      <button
                        id="open-create-store-modal"
                        onClick={() => {
                          setIsStoreMenuOpen(false);
                          onOpenCreateStoreWizard();
                        }}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-md shadow-emerald-600/30"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        {language === 'bn' ? '+ নতুন ওয়েবসাইট তৈরি করুন' : '+ Create New Store'}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Direct Quick Create Website Button */}
              <button
                id="nav-quick-create-store-btn"
                onClick={onOpenCreateStoreWizard}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 transition-all transform hover:scale-105 active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                <span>{language === 'bn' ? '+ ওয়েবসাইট তৈরি করুন' : '+ Create Store'}</span>
              </button>

              {/* Export Project Source Code (ZIP) Button */}
              {onOpenExportModal && (
                <button
                  id="nav-export-project-zip-btn"
                  onClick={onOpenExportModal}
                  className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 hover:border-emerald-500/60 text-xs font-semibold transition-all shadow-sm group hover:text-white"
                  title={language === 'bn' ? 'সোর্স কোড ZIP ডাউনলোড করুন' : 'Export Full Project ZIP'}
                >
                  <FolderArchive className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
                  <span className="hidden md:inline">{language === 'bn' ? 'কোড ZIP ডাউনলোড' : 'Export ZIP'}</span>
                  <span className="md:hidden">ZIP</span>
                </button>
              )}

              {/* Language Switcher */}
              <button
                id="language-toggle-btn"
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
                title="Toggle Language"
              >
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
              </button>

              {/* Cart Drawer Trigger when on Storefront */}
              {currentView === 'storefront' && (
                <button
                  id="storefront-cart-btn"
                  onClick={onOpenCart}
                  className="relative p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
                  title="Cart"
                >
                  <ShoppingBag className="w-4 h-4" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[11px] font-bold flex items-center justify-center border-2 border-slate-900">
                      {cartCount}
                    </span>
                  )}
                </button>
              )}

              {/* Notification Bell */}
              <div className="relative">
                <button
                  id="notifications-bell-btn"
                  onClick={() => setShowNotificationPopup(!showNotificationPopup)}
                  className="relative p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700"
                >
                  <Bell className="w-4 h-4" />
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-400"></span>
                </button>

                {showNotificationPopup && (
                  <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-3 z-50">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <span className="text-xs font-bold text-white">
                        {language === 'bn' ? 'সাম্প্রতিক অ্যালার্ট' : 'Platform Alerts'}
                      </span>
                      <span className="text-[10px] text-emerald-400 font-semibold">
                        3 New
                      </span>
                    </div>
                    <div className="space-y-2 mt-2">
                      <div className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/50 text-xs">
                        <p className="font-medium text-slate-200">
                          {language === 'bn' ? 'নতুন বিকাশ অর্ডার গৃহীত হয়েছে (৳৪,৪৮০)' : 'New bKash Order Placed (৳4,480)'}
                        </p>
                        <span className="text-[10px] text-slate-400">10 mins ago • Aura Lifestyle</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/50 text-xs">
                        <p className="font-medium text-slate-200">
                          {language === 'bn' ? 'স্টক অ্যালার্ট: আর্টিসান সিল্ক পাঞ্জাবি (১২ পিস বাকি)' : 'Stock Alert: Silk Panjabi (12 left)'}
                        </p>
                        <span className="text-[10px] text-amber-400">Inventory Alert</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Primary Call to Action Button */}
              {currentView === 'landing' ? (
                <button
                  id="cta-enter-dashboard"
                  onClick={() => setCurrentView('dashboard')}
                  className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 transition-all hover:scale-[1.02]"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  {language === 'bn' ? 'মার্চেন্ট পোর্টাল' : 'Merchant Portal'}
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  id="cta-preview-store"
                  onClick={() => setCurrentView('storefront')}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  {language === 'bn' ? 'লাইভ স্টোর ভিউ' : 'Live Storefront'}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Sub Navigation bar */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-800 bg-slate-900/90 text-xs">
          <button
            onClick={() => setCurrentView('landing')}
            className={`flex items-center gap-1 py-1 px-2.5 rounded ${
              currentView === 'landing' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            {language === 'bn' ? 'প্ল্যাটফর্ম' : 'Platform'}
          </button>
          <button
            onClick={() => setCurrentView('dashboard')}
            className={`flex items-center gap-1 py-1 px-2.5 rounded ${
              currentView === 'dashboard' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            {language === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard'}
          </button>
          <button
            onClick={() => setCurrentView('storefront')}
            className={`flex items-center gap-1 py-1 px-2.5 rounded ${
              currentView === 'storefront' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            {language === 'bn' ? 'স্টোরফ্রন্ট' : 'Store'}
          </button>
          <button
            onClick={() => setCurrentView('admin')}
            className={`flex items-center gap-1 py-1 px-2.5 rounded ${
              currentView === 'admin' ? 'text-emerald-400 font-bold bg-slate-800' : 'text-slate-400'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            {language === 'bn' ? 'অ্যাডমিন' : 'Admin'}
          </button>
        </div>
      </header>
    </>
  );
};
