import React, { useState } from 'react';
import { 
  X, 
  Check, 
  ShieldCheck, 
  CreditCard, 
  Lock, 
  ArrowRight, 
  Sparkles, 
  Smartphone, 
  CheckCircle2, 
  Download, 
  AlertCircle,
  Clock,
  Building,
  Zap,
  Sun
} from 'lucide-react';
import { 
  Language, 
  PricingPlan, 
  PaymentGatewayConfig, 
  SubscriptionPayment, 
  Store,
  PaymentGatewayProvider
} from '../../types';

interface PlanCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  plan: PricingPlan;
  store: Store;
  gateways: PaymentGatewayConfig[];
  billingCycle: 'monthly' | 'yearly';
  onPaymentSuccess: (payment: SubscriptionPayment) => void;
}

export const PlanCheckoutModal: React.FC<PlanCheckoutModalProps> = ({
  isOpen,
  onClose,
  language,
  plan,
  store,
  gateways,
  billingCycle,
  onPaymentSuccess,
}) => {
  const isBn = language === 'bn';

  // Only consider gateways that are enabled
  const activeGateways = gateways.filter((g) => g.isEnabled);

  const [selectedGatewayId, setSelectedGatewayId] = useState<PaymentGatewayProvider>(
    activeGateways[0]?.id || 'aamarpay'
  );

  // Sub-payment method inside gateway (e.g. 'bkash' | 'nagad' | 'card')
  const [subMethod, setSubMethod] = useState<'bkash' | 'nagad' | 'card'>('bkash');
  const [customerPhone, setCustomerPhone] = useState('01712-345678');
  const [customerPin, setCustomerPin] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [checkoutStep, setCheckoutStep] = useState<'details' | 'otp' | 'processing' | 'success'>('details');
  const [confirmedTrx, setConfirmedTrx] = useState<SubscriptionPayment | null>(null);

  if (!isOpen) return null;

  const rawPrice = billingCycle === 'monthly' ? plan.priceMonthly : plan.priceYearly;
  const isFreePlan = rawPrice === 0;

  const currentGateway = gateways.find((g) => g.id === selectedGatewayId) || gateways[0];

  const handleStartPayment = (e: React.FormEvent) => {
    e.preventDefault();

    if (isFreePlan) {
      // Free plan requires no gateway verification
      finalizePayment('FREE-TRIAL-' + Math.floor(100000 + Math.random() * 900000));
      return;
    }

    // Advance to simulated OTP verification
    setCheckoutStep('otp');
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutStep('processing');

    const prefix = 
      selectedGatewayId === 'aamarpay' ? 'AAMAR' :
      selectedGatewayId === 'shohozpay' ? 'SHOHOZ' :
      selectedGatewayId === 'shurjopay' ? 'SHURJO' : 'BKASH';

    const randomTrxNumber = Math.floor(100000 + Math.random() * 900000);
    const trxId = `${prefix}-${new Date().getFullYear()}-${randomTrxNumber}`;

    setTimeout(() => {
      finalizePayment(trxId);
    }, 1500);
  };

  const finalizePayment = (trxId: string) => {
    const paymentRecord: SubscriptionPayment = {
      id: `SUB-PAY-${Date.now().toString().slice(-6)}`,
      storeId: store.id,
      storeName: store.name,
      userName: store.name + ' Merchant',
      userPhone: customerPhone,
      planId: plan.id as any,
      planName: isBn ? plan.nameBn : plan.name,
      amount: rawPrice,
      billingCycle,
      gateway: selectedGatewayId,
      transactionId: trxId,
      status: 'completed',
      date: new Date().toLocaleString('en-US', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
      notes: `${plan.name} subscription via ${currentGateway.name}`,
    };

    setConfirmedTrx(paymentRecord);
    setCheckoutStep('success');
    onPaymentSuccess(paymentRecord);
  };

  const handleCloseAndReset = () => {
    setCheckoutStep('details');
    setConfirmedTrx(null);
    setOtpCode('');
    setCustomerPin('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-950 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-white">
                {isBn ? 'সাবস্ক্রিপশন প্ল্যান পেমেন্ট চেকআউট' : 'Subscription Checkout'}
              </h3>
              <p className="text-xs text-slate-400">
                {isBn 
                  ? `${store.name} এর জন্য ${plan.nameBn} অ্যাক্টিভেশন` 
                  : `Activating ${plan.name} for ${store.name}`}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleCloseAndReset}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: PLAN SUMMARY & GATEWAY SELECTION */}
        {checkoutStep === 'details' && (
          <form onSubmit={handleStartPayment} className="p-5 sm:p-6 space-y-5">
            {/* Plan Invoice Summary Box */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block">
                  {isBn ? 'নির্বাচিত প্ল্যান' : 'Selected Tier'}
                </span>
                <h4 className="font-black text-lg text-white mt-0.5">
                  {isBn ? plan.nameBn : plan.name}
                </h4>
                <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                  <span className="capitalize">{billingCycle} billing</span>
                  <span>•</span>
                  <span className="font-mono text-emerald-400">{store.slug}.shanju.cloud</span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] text-slate-400 block">
                  {isBn ? 'মোট প্রদেয় টাকা' : 'Total Due'}
                </span>
                <span className="text-2xl font-black text-white font-mono">
                  {isFreePlan ? (isBn ? 'ফ্রি ৳০' : '৳0 Free') : `৳${rawPrice.toLocaleString()}`}
                </span>
                <span className="text-[10px] text-slate-500 block">BDT</span>
              </div>
            </div>

            {/* Gateway Providers Selection */}
            {!isFreePlan && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2.5">
                  {isBn ? 'পেমেন্ট গেটওয়ে নির্বাচন করুন *' : 'Select Payment Gateway Provider *'}
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {activeGateways.map((gw) => (
                    <button
                      key={gw.id}
                      type="button"
                      onClick={() => setSelectedGatewayId(gw.id)}
                      className={`p-3 rounded-2xl border text-left transition-all relative ${
                        selectedGatewayId === gw.id
                          ? 'bg-emerald-500/10 border-emerald-500 text-white shadow-lg shadow-emerald-500/10'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xl">{gw.logo}</span>
                        {selectedGatewayId === gw.id && (
                          <div className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-[10px]">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>
                      <div className="font-bold text-xs text-slate-100">{gw.name}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                        {gw.id === 'aamarpay' ? 'Cards & MFS' : gw.id === 'shohozpay' ? '1-Click Pay' : 'National PSO'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Sub-methods (Cards / Mobile Banking) for simulated payment */}
            {!isFreePlan && (
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span className="font-semibold">
                    {isBn ? `${currentGateway.name} পেমেন্ট চ্যানেল:` : `${currentGateway.name} Channel:`}
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> 256-Bit SSL Encrypted
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setSubMethod('bkash')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold text-center transition-colors ${
                      subMethod === 'bkash'
                        ? 'bg-pink-950/40 border-pink-500 text-pink-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    bKash বিকাশ
                  </button>
                  <button
                    type="button"
                    onClick={() => setSubMethod('nagad')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold text-center transition-colors ${
                      subMethod === 'nagad'
                        ? 'bg-amber-950/40 border-amber-500 text-amber-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    Nagad নগদ
                  </button>
                  <button
                    type="button"
                    onClick={() => setSubMethod('card')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold text-center transition-colors ${
                      subMethod === 'card'
                        ? 'bg-blue-950/40 border-blue-500 text-blue-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    Visa / Master
                  </button>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    {subMethod === 'card' 
                      ? (isBn ? 'কার্ড নম্বর / নাম' : 'Card Details') 
                      : (isBn ? 'মোবাইল অ্যাকাউন্ট নম্বর' : 'Account Mobile Number')}
                  </label>
                  <input
                    type="text"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder={subMethod === 'card' ? '4111 2222 3333 4444' : '01712-345678'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            )}

            {/* CTA Button */}
            <div className="pt-2">
              <button
                type="submit"
                id="proceed-to-pay-btn"
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-98"
              >
                <span>
                  {isFreePlan
                    ? (isBn ? '১ মাস ফ্রি ট্রায়াল অ্যাক্টিভ করুন' : 'Activate 1-Month Free Trial')
                    : (isBn ? `৳${rawPrice.toLocaleString()} পে করুন (${currentGateway.name})` : `Pay ৳${rawPrice.toLocaleString()} via ${currentGateway.name}`)}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: GATEWAY SIMULATED OTP & PIN VERIFICATION */}
        {checkoutStep === 'otp' && (
          <form onSubmit={handleVerifyOtp} className="p-6 space-y-5">
            <div className="text-center py-2">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-3">
                <Smartphone className="w-6 h-6" />
              </div>
              <h4 className="font-extrabold text-lg text-white">
                {isBn ? `${currentGateway.name} ওটিপি ভেরিফিকেশন` : `${currentGateway.name} Verification`}
              </h4>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                {isBn
                  ? `আপনার ফোন নম্বর ${customerPhone} এ একটি ৬ ডিজিটের ওটিপি কোড পাঠানো হয়েছে (টেস্ট কোড: 123456)`
                  : `A 6-digit OTP code was sent to ${customerPhone} (Test code: 123456)`}
              </p>
            </div>

            <div className="space-y-4 max-w-sm mx-auto">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ওটিপি কোড (OTP Code) *' : 'Enter OTP Code *'}
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="123456"
                  className="w-full text-center tracking-widest text-lg font-mono font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'পিন নম্বর (PIN / Password)' : 'Wallet PIN / CVV'}
                </label>
                <input
                  type="password"
                  required
                  maxLength={5}
                  value={customerPin}
                  onChange={(e) => setCustomerPin(e.target.value)}
                  placeholder="••••"
                  className="w-full text-center tracking-widest text-lg font-mono px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                id="confirm-otp-btn"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 transition-all"
              >
                {isBn ? 'পেমেন্ট নিশ্চিত করুন' : 'Confirm & Complete Payment'}
              </button>

              <button
                type="button"
                onClick={() => setCheckoutStep('details')}
                className="w-full text-center text-xs text-slate-400 hover:text-white"
              >
                {isBn ? 'গেটওয়ে পরিবর্তন করতে পেছনে যান' : 'Back to Gateway Selection'}
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: PROCESSING */}
        {checkoutStep === 'processing' && (
          <div className="p-10 text-center space-y-4">
            <div className="w-14 h-14 rounded-full border-4 border-emerald-500/20 border-t-emerald-500 animate-spin mx-auto" />
            <h4 className="text-base font-bold text-white">
              {isBn ? `${currentGateway.name} এর সাথে ট্রানজেকশন প্রসেস হচ্ছে...` : `Processing payment with ${currentGateway.name}...`}
            </h4>
            <p className="text-xs text-slate-400">
              {isBn ? 'অনুগ্রহ করে অপেক্ষা করুন, পেইজটি রিফ্রেশ করবেন না।' : 'Please hold on, verifying tokenized webhook response.'}
            </p>
          </div>
        )}

        {/* STEP 4: SUCCESS CONFIRMATION */}
        {checkoutStep === 'success' && confirmedTrx && (
          <div className="p-6 sm:p-8 text-center space-y-5">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                ✓ {isBn ? 'পেমেন্ট ও প্ল্যান সফলভাবে অ্যাক্টিভ হয়েছে!' : 'Payment & Plan Activated!'}
              </span>
              <h3 className="text-xl font-black text-white mt-3">
                {isBn ? 'অভিনন্দন! আপনার স্টোর আপগ্রেড সম্পন্ন' : 'Congratulations! Store Upgraded'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {isBn
                  ? `${confirmedTrx.planName} এর সকল প্রিমিয়াম ফিচার্স এখন আপনার স্টোরে লাইভ।`
                  : `All ${confirmedTrx.planName} capabilities are now fully operational on your store.`}
              </p>
            </div>

            {/* Receipt Card */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-left space-y-2 text-xs">
              <div className="flex justify-between text-slate-400 pb-2 border-b border-slate-800/80">
                <span>{isBn ? 'ট্রানজেকশন আইডি:' : 'Trx ID:'}</span>
                <span className="font-mono text-emerald-400 font-bold">{confirmedTrx.transactionId}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{isBn ? 'ইনভয়েস নম্বর:' : 'Invoice ID:'}</span>
                <span className="font-mono text-slate-200">{confirmedTrx.id}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{isBn ? 'পরিশোধিত অর্থ:' : 'Amount Paid:'}</span>
                <span className="font-bold text-white">৳{confirmedTrx.amount.toLocaleString()} BDT</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{isBn ? 'পেমেন্ট মাধ্যম:' : 'Payment Gateway:'}</span>
                <span className="capitalize font-semibold text-slate-200">
                  {confirmedTrx.gateway}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 pt-2 border-t border-slate-800/80">
                <span>{isBn ? 'তারিখ ও সময়:' : 'Timestamp:'}</span>
                <span className="text-slate-300">{confirmedTrx.date}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                id="checkout-done-btn"
                onClick={handleCloseAndReset}
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 transition-all"
              >
                {isBn ? 'মার্চেন্ট ড্যাশবোর্ডে প্রবেশ করুন' : 'Return to Merchant Dashboard'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
