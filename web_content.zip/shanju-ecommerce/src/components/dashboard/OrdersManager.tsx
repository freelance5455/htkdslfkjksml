import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Filter, 
  Eye, 
  CheckCircle2, 
  Truck, 
  Clock, 
  X, 
  Printer, 
  ChevronRight,
  CreditCard,
  User,
  MapPin,
  Phone,
  Mail
} from 'lucide-react';
import { Order, Store, Language, OrderStatus } from '../../types';

interface OrdersManagerProps {
  activeStore: Store;
  orders: Order[];
  language: Language;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
}

export const OrdersManager: React.FC<OrdersManagerProps> = ({
  activeStore,
  orders,
  language,
  onUpdateOrderStatus,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const isBn = language === 'bn';
  const storeOrders = orders.filter((o) => o.storeId === activeStore.id);

  const filteredOrders = storeOrders.filter((o) => {
    const matchesFilter = statusFilter === 'all' || o.orderStatus === statusFilter;
    const matchesSearch = 
      o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerPhone.includes(searchQuery) ||
      o.city.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">Pending</span>;
      case 'processing':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">Processing</span>;
      case 'shipped':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">Shipped</span>;
      case 'delivered':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">Delivered</span>;
      case 'cancelled':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">Cancelled</span>;
      default:
        return null;
    }
  };

  const getPaymentMethodBadge = (method: Order['paymentMethod']) => {
    switch (method) {
      case 'bkash':
        return <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-pink-50 text-pink-700 border border-pink-200">bKash</span>;
      case 'nagad':
        return <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-orange-50 text-orange-700 border border-orange-200">Nagad</span>;
      case 'card':
        return <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-blue-50 text-blue-700 border border-blue-200">Visa / Card</span>;
      case 'cod':
        return <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-slate-100 text-slate-700 border border-slate-200">Cash on Delivery</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
            {isBn ? 'অর্ডার ও ডেলিভারি ফুলফিলমেন্ট' : 'Orders & Courier Fulfillment'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'সকল গ্রাহকের অর্ডার ট্র্যাক করুন, পেমেন্ট যাচাই করুন এবং কুরিয়ার ডেলিভারি কনফার্ম করুন।' 
              : 'Track incoming customer orders, verify payment gateways, and advance courier dispatch status.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500">
            {isBn ? 'মোট অর্ডার:' : 'Total Orders:'}
          </span>
          <span className="px-2.5 py-1 rounded-xl bg-slate-900 text-white font-bold text-xs">
            {storeOrders.length}
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="order-search-input"
            type="text"
            placeholder={isBn ? 'অর্ডার নম্বর, ফোন বা নাম দিয়ে খুঁজুন...' : 'Search by order #, phone, or name...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {['all', 'pending', 'processing', 'shipped', 'delivered', 'cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider text-[10px] transition-colors ${
                statusFilter === status
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3.5 px-4">{isBn ? 'অর্ডার নম্বর' : 'Order ID'}</th>
                <th className="py-3.5 px-4">{isBn ? 'গ্রাহক' : 'Customer'}</th>
                <th className="py-3.5 px-4">{isBn ? 'পণ্য' : 'Items'}</th>
                <th className="py-3.5 px-4">{isBn ? 'পেমেন্ট' : 'Payment'}</th>
                <th className="py-3.5 px-4">{isBn ? 'মোট টাকা' : 'Total'}</th>
                <th className="py-3.5 px-4">{isBn ? 'স্ট্যাটাস' : 'Fulfillment Status'}</th>
                <th className="py-3.5 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    {isBn ? 'কোন অর্ডার পাওয়া যায়নি।' : 'No orders found matching your criteria.'}
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      {order.orderNumber}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{order.customerName}</div>
                      <div className="text-[11px] text-slate-500">{order.customerPhone}</div>
                      <div className="text-[10px] text-slate-400">{order.city}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-800">
                        {order.items.reduce((acc, i) => acc + i.quantity, 0)} {isBn ? 'টি আইটেম' : 'items'}
                      </span>
                      <div className="text-[11px] text-slate-400 truncate max-w-[150px]">
                        {order.items.map((i) => i.name).join(', ')}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex flex-col gap-1">
                        {getPaymentMethodBadge(order.paymentMethod)}
                        <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">
                          {order.paymentStatus}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-black text-slate-900 text-sm">
                        ৳{order.totalAmount.toLocaleString()}
                      </div>
                      {order.discount > 0 && (
                        <div className="text-[10px] text-emerald-600">
                          -৳{order.discount} promo
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        {getStatusBadge(order.orderStatus)}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {/* Advance Order Status Button */}
                        {order.orderStatus === 'pending' && (
                          <button
                            id={`advance-order-${order.id}`}
                            onClick={() => onUpdateOrderStatus(order.id, 'processing')}
                            className="px-2.5 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg text-[11px] font-bold border border-blue-200 transition-colors"
                          >
                            {isBn ? 'প্রসেস শুরু' : 'Process'}
                          </button>
                        )}
                        {order.orderStatus === 'processing' && (
                          <button
                            id={`ship-order-${order.id}`}
                            onClick={() => onUpdateOrderStatus(order.id, 'shipped')}
                            className="px-2.5 py-1 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-[11px] font-bold border border-indigo-200 transition-colors"
                          >
                            {isBn ? 'কুরিয়ারে পাঠান' : 'Ship'}
                          </button>
                        )}
                        {order.orderStatus === 'shipped' && (
                          <button
                            id={`deliver-order-${order.id}`}
                            onClick={() => onUpdateOrderStatus(order.id, 'delivered')}
                            className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg text-[11px] font-bold border border-emerald-200 transition-colors"
                          >
                            {isBn ? 'ডেলিভারি সম্পন্ন' : 'Deliver'}
                          </button>
                        )}

                        {/* View Details / Invoice */}
                        <button
                          id={`view-order-details-${order.id}`}
                          onClick={() => setSelectedOrder(order)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                          title="View Invoice"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice & Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base text-slate-900">
                  {selectedOrder.orderNumber}
                </span>
                {getStatusBadge(selectedOrder.orderStatus)}
              </div>
              <button 
                onClick={() => setSelectedOrder(null)} 
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Receipt Content */}
            <div className="mt-4 space-y-4 text-xs">
              {/* Customer Info */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  <span>{selectedOrder.customerName}</span>
                </div>
                <div className="text-slate-600 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-500" />
                  <span>{selectedOrder.customerPhone}</span>
                </div>
                <div className="text-slate-600 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  <span>{selectedOrder.deliveryAddress}, {selectedOrder.city}</span>
                </div>
                {selectedOrder.notes && (
                  <div className="text-[11px] text-slate-500 italic mt-1">
                    Note: &quot;{selectedOrder.notes}&quot;
                  </div>
                )}
              </div>

              {/* Items List */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 font-bold text-slate-700 text-[11px]">
                  Ordered Products ({selectedOrder.items.length})
                </div>
                <div className="divide-y divide-slate-100">
                  {selectedOrder.items.map((item, idx) => (
                    <div key={idx} className="p-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          className="w-10 h-10 rounded-lg object-cover border border-slate-200"
                        />
                        <div>
                          <div className="font-bold text-slate-900">{item.name}</div>
                          <div className="text-[11px] text-slate-500">
                            ৳{item.price.toLocaleString()} × {item.quantity}
                          </div>
                        </div>
                      </div>
                      <div className="font-bold text-slate-900">
                        ৳{(item.price * item.quantity).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing Breakdown */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100 text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-slate-900">৳{selectedOrder.subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping Fee:</span>
                  <span className="font-semibold text-slate-900">৳{selectedOrder.shippingFee}</span>
                </div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>Discount:</span>
                    <span>-৳{selectedOrder.discount}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-slate-200">
                  <span>Total Amount:</span>
                  <span>৳{selectedOrder.totalAmount.toLocaleString()}</span>
                </div>
              </div>

              {/* Payment & Courier Metadata */}
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-emerald-800 block">Payment Method</span>
                  <span className="font-bold text-slate-900 capitalize">{selectedOrder.paymentMethod} (Verified)</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-emerald-800 block">Dispatch Status</span>
                  <span className="font-bold text-emerald-700 capitalize">{selectedOrder.orderStatus}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-between items-center pt-4 border-t border-slate-200 mt-5">
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>{isBn ? 'ইনভয়েস প্রিন্ট করুন' : 'Print Invoice'}</span>
              </button>

              <button
                onClick={() => setSelectedOrder(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
              >
                {isBn ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
