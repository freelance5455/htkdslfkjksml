import React, { useState, useRef } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Sparkles, 
  Edit3, 
  Trash2, 
  Star, 
  Package, 
  Check, 
  X, 
  Layers,
  ArrowUpDown,
  Upload,
  Film,
  Image as ImageIcon,
  Play,
  Eye,
  Video,
  FileVideo,
  AlertCircle,
  Smartphone,
  CheckCircle2
} from 'lucide-react';
import { Product, Store, Language } from '../../types';
import { compressImageFile } from '../../utils/storage';

interface ProductsManagerProps {
  activeStore: Store;
  products: Product[];
  language: Language;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
}

const PRESET_IMAGES = [
  { label: 'Panjabi / Ethnic', url: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=600&q=80' },
  { label: 'Saree / Traditional', url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80' },
  { label: 'Casual Shirt', url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=600&q=80' },
  { label: 'Headphones / Audio', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80' },
  { label: 'Smartwatch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80' },
  { label: 'Organic Honey', url: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80' },
  { label: 'Pure Oil', url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80' },
];

export const ProductsManager: React.FC<ProductsManagerProps> = ({
  activeStore,
  products,
  language,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formNameBn, setFormNameBn] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formCategory, setFormCategory] = useState('Menswear');
  const [formPrice, setFormPrice] = useState<number>(1500);
  const [formComparePrice, setFormComparePrice] = useState<number>(1950);
  const [formStock, setFormStock] = useState<number>(30);
  const [formImage, setFormImage] = useState(PRESET_IMAGES[0].url);
  const [formVideoUrl, setFormVideoUrl] = useState<string>('');
  const [formMediaType, setFormMediaType] = useState<'image' | 'video'>('image');
  const [activePreviewType, setActivePreviewType] = useState<'image' | 'video'>('image');
  const [uploadedImageName, setUploadedImageName] = useState<string | null>(null);
  const [uploadedVideoName, setUploadedVideoName] = useState<string | null>(null);
  const [uploadedFileSize, setUploadedFileSize] = useState<string | null>(null);
  const [mediaSourceTab, setMediaSourceTab] = useState<'device' | 'presets' | 'url'>('device');
  const [isDragging, setIsDragging] = useState(false);
  const [isReadingFile, setIsReadingFile] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Quick media preview modal for table row
  const [previewMediaProduct, setPreviewMediaProduct] = useState<Product | null>(null);

  // File input refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const [formDescription, setFormDescription] = useState('');
  const [formDescriptionBn, setFormDescriptionBn] = useState('');
  const [formIsFeatured, setFormIsFeatured] = useState(false);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  const isBn = language === 'bn';
  const storeProducts = products.filter((p) => p.storeId === activeStore.id);

  // Extract unique categories
  const categories = ['All', ...Array.from(new Set(storeProducts.map((p) => p.category)))];

  const filteredProducts = storeProducts.filter((p) => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.nameBn.includes(searchTerm) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const processUploadedFile = async (file: File) => {
    setUploadError(null);
    const MAX_SIZE = 60 * 1024 * 1024; // 60MB limit for browser in-memory handling
    if (file.size > MAX_SIZE) {
      setUploadError(
        isBn 
          ? 'ফাইলের সাইজ খুব বড়! সর্বোচ্চ ৬০ মেগাবাইট পর্যন্ত আপলোড করতে পারবেন।' 
          : 'File size exceeds the 60MB limit.'
      );
      return;
    }

    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');

    if (!isImage && !isVideo) {
      setUploadError(
        isBn 
          ? 'অনুগ্রহ করে একটি ছবি (JPG, PNG, WebP) অথবা ভিডিও (MP4, WebM) ফাইল নির্বাচন করুন।' 
          : 'Please select a valid image or video file.'
      );
      return;
    }

    setIsReadingFile(true);

    if (isImage) {
      try {
        // High quality client-side canvas compression: turns 12MB photos into ~120KB
        const { dataUrl, sizeString } = await compressImageFile(file, 1200, 1200, 0.85);
        setFormImage(dataUrl);
        setFormMediaType('image');
        setActivePreviewType('image');
        setUploadedImageName(file.name);
        setUploadedFileSize(sizeString);
      } catch {
        // Fallback to direct read
        const reader = new FileReader();
        reader.onload = (e) => {
          const res = e.target?.result as string;
          setFormImage(res);
          setFormMediaType('image');
          setActivePreviewType('image');
          setUploadedImageName(file.name);
          setUploadedFileSize(`${Math.round(file.size / 1024)} KB`);
        };
        reader.readAsDataURL(file);
      } finally {
        setIsReadingFile(false);
      }
    } else if (isVideo) {
      const reader = new FileReader();
      const sizeStr = file.size > 1024 * 1024 
        ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` 
        : `${Math.round(file.size / 1024)} KB`;

      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        setFormVideoUrl(dataUrl);
        setFormMediaType('video');
        setActivePreviewType('video');
        setUploadedVideoName(file.name);
        setUploadedFileSize(sizeStr);
        setIsReadingFile(false);
      };

      reader.onerror = () => {
        setIsReadingFile(false);
        setUploadError(isBn ? 'ডিভাইস থেকে ভিডিও লোড করতে সমস্যা হয়েছে।' : 'Error reading video from device.');
      };

      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const handleOpenAdd = () => {
    setEditingProductId(null);
    setFormName('');
    setFormNameBn('');
    setFormSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setFormCategory('Menswear');
    setFormPrice(1500);
    setFormComparePrice(1900);
    setFormStock(25);
    setFormImage(PRESET_IMAGES[0].url);
    setFormVideoUrl('');
    setFormMediaType('image');
    setActivePreviewType('image');
    setUploadedImageName(null);
    setUploadedVideoName(null);
    setUploadedFileSize(null);
    setUploadError(null);
    setMediaSourceTab('device');
    setFormDescription('High-quality premium craftsmanship designed for comfort and everyday luxury.');
    setFormDescriptionBn('দৈনন্দিন আভিজাত্য ও আরামের জন্য প্রিমিয়াম কোয়ালিটিতে তৈরি।');
    setFormIsFeatured(false);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProductId(p.id);
    setFormName(p.name);
    setFormNameBn(p.nameBn);
    setFormSku(p.sku);
    setFormCategory(p.category);
    setFormPrice(p.price);
    setFormComparePrice(p.compareAtPrice || 0);
    setFormStock(p.stock);
    setFormImage(p.image);
    setFormVideoUrl(p.videoUrl || '');
    setFormMediaType(p.mediaType || (p.videoUrl ? 'video' : 'image'));
    setActivePreviewType(p.videoUrl ? 'video' : 'image');
    setUploadedImageName(null);
    setUploadedVideoName(null);
    setUploadedFileSize(null);
    setUploadError(null);
    setMediaSourceTab(p.videoUrl ? 'device' : 'device');
    setFormDescription(p.description);
    setFormDescriptionBn(p.descriptionBn);
    setFormIsFeatured(p.isFeatured);
    setIsModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (editingProductId) {
      const existing = storeProducts.find((p) => p.id === editingProductId);
      if (existing) {
        onUpdateProduct({
          ...existing,
          name: formName,
          nameBn: formNameBn || formName,
          sku: formSku,
          category: formCategory,
          categoryBn: formCategory,
          price: formPrice,
          compareAtPrice: formComparePrice > 0 ? formComparePrice : undefined,
          stock: formStock,
          image: formImage,
          videoUrl: formVideoUrl.trim() ? formVideoUrl.trim() : undefined,
          mediaType: formMediaType,
          description: formDescription,
          descriptionBn: formDescriptionBn || formDescription,
          isFeatured: formIsFeatured,
        });
      }
    } else {
      onAddProduct({
        storeId: activeStore.id,
        name: formName,
        nameBn: formNameBn || formName,
        sku: formSku,
        category: formCategory,
        categoryBn: formCategory,
        price: formPrice,
        compareAtPrice: formComparePrice > 0 ? formComparePrice : undefined,
        stock: formStock,
        image: formImage,
        videoUrl: formVideoUrl.trim() ? formVideoUrl.trim() : undefined,
        mediaType: formMediaType,
        rating: 5.0,
        reviewsCount: 1,
        description: formDescription,
        descriptionBn: formDescriptionBn || formDescription,
        isFeatured: formIsFeatured,
        tags: ['New', formCategory],
      });
    }
    setIsModalOpen(false);
  };

  // AI Description Generator Simulator
  const handleGenerateAiDescription = () => {
    setIsGeneratingAi(true);
    setTimeout(() => {
      const title = formName || 'Premium Quality Product';
      setFormDescription(
        `Crafted with superior attention to detail, this authentic ${title} blends timeless aesthetics with modern durability. Engineered for style-conscious buyers who appreciate uncompromised luxury.`
      );
      setFormDescriptionBn(
        `নিখুঁত ফিনিশিং এবং দীর্ঘস্থায়িত্বের নিশ্চয়তা দিয়ে তৈরি এই ${formNameBn || title}। যারা আভিজাত্য এবং সর্বোচ্চ আরামের নিখুঁত সমন্বয় চান, তাদের জন্য এটি সেরা পছন্দ।`
      );
      setIsGeneratingAi(false);
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
            {isBn ? 'পণ্য ও ইনভেন্টরি ক্যাটালগ' : 'Product & Inventory Catalog'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? `মোট ${storeProducts.length}টি পণ্য এই স্টোরের লাইভ ক্যাটালগে প্রদর্শিত হচ্ছে।` 
              : `Manage pricing, stock count, categories, and AI descriptions for ${storeProducts.length} items.`}
          </p>
        </div>

        <button
          id="add-new-product-header-btn"
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>{isBn ? 'নতুন পণ্য যোগ করুন' : 'Add New Product'}</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="product-search-input"
            type="text"
            placeholder={isBn ? 'পণ্যের নাম বা এসকেইউ (SKU) দিয়ে খুঁজুন...' : 'Search by title or SKU...'}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3.5 px-4">{isBn ? 'পণ্য' : 'Product'}</th>
                <th className="py-3.5 px-4">{isBn ? 'ক্যাটাগরি' : 'Category'}</th>
                <th className="py-3.5 px-4">{isBn ? 'মূল্য (Price)' : 'Price'}</th>
                <th className="py-3.5 px-4">{isBn ? 'স্টক' : 'Inventory'}</th>
                <th className="py-3.5 px-4">{isBn ? 'স্ট্যাটাস' : 'Featured'}</th>
                <th className="py-3.5 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 text-xs">
                    {isBn ? 'কোন পণ্য খুঁজে পাওয়া যায়নি।' : 'No products match your search or filter.'}
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div 
                          onClick={() => setPreviewMediaProduct(product)}
                          className="relative w-12 h-12 rounded-xl overflow-hidden border border-slate-200 shrink-0 bg-slate-100 cursor-pointer group/thumb"
                        >
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover/thumb:scale-110 transition-transform"
                          />
                          {product.videoUrl && (
                            <span className="absolute inset-0 bg-slate-950/40 flex items-center justify-center text-white">
                              <Play className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
                            </span>
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 truncate max-w-[200px] sm:max-w-xs flex items-center gap-1.5">
                            <span>{isBn ? product.nameBn : product.name}</span>
                            {product.videoUrl && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-100 text-purple-700">
                                <Film className="w-2.5 h-2.5" />
                                <span>Video</span>
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                            {product.sku}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium">
                        {isBn ? product.categoryBn : product.category}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">
                        ৳{product.price.toLocaleString()}
                      </div>
                      {product.compareAtPrice && (
                        <div className="text-[10px] text-slate-400 line-through">
                          ৳{product.compareAtPrice.toLocaleString()}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-bold ${
                            product.stock <= 15 ? 'text-amber-600' : 'text-slate-800'
                          }`}
                        >
                          {product.stock} in stock
                        </span>
                        {product.stock <= 15 && (
                          <span className="px-1.5 py-0.2 text-[10px] rounded bg-amber-50 text-amber-700 font-bold border border-amber-200">
                            Low
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      {product.isFeatured ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                          Featured
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">Regular</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          id={`view-media-product-${product.id}`}
                          onClick={() => setPreviewMediaProduct(product)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 transition-colors"
                          title={product.videoUrl ? (isBn ? 'ভিডিও ও ছবি দেখুন' : 'Preview Video & Photo') : (isBn ? 'ছবি প্রিভিউ' : 'Preview Media')}
                        >
                          {product.videoUrl ? <Play className="w-4 h-4 text-purple-600" /> : <Eye className="w-4 h-4" />}
                        </button>
                        <button
                          id={`edit-product-${product.id}`}
                          onClick={() => handleOpenEdit(product)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                          title="Edit Product"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          id={`delete-product-${product.id}`}
                          onClick={() => {
                            if (window.confirm(isBn ? 'আপনি কি এই পণ্যটি মুছে ফেলতে নিশ্চিত?' : 'Are you sure you want to delete this product?')) {
                              onDeleteProduct(product.id);
                            }
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete Product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">
                {editingProductId 
                  ? (isBn ? 'পণ্য সম্পাদনা করুন' : 'Edit Product Details') 
                  : (isBn ? 'নতুন পণ্য যুক্ত করুন' : 'Add New Product')}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-700 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'পণ্যের নাম (English)' : 'Product Title (English)'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'পণ্যের নাম (বাংলা)' : 'Product Title (Bengali)'}
                  </label>
                  <input
                    type="text"
                    value={formNameBn}
                    onChange={(e) => setFormNameBn(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'বিক্রয় মূল্য (৳)' : 'Price (৳)'}
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'মূল্য ছাড় / Compare Price (৳)' : 'Compare Price (৳)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formComparePrice}
                    onChange={(e) => setFormComparePrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'ইনভেন্টরি স্টক (Stock)' : 'Available Stock'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formStock}
                    onChange={(e) => setFormStock(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
                  >
                    <option value="Menswear">Menswear / পুরুষদের পোশাক</option>
                    <option value="Womenswear">Womenswear / নারীদের পোশাক</option>
                    <option value="Accessories">Accessories / এক্সেসরিজ</option>
                    <option value="Audio">Audio & Sound / অডিও</option>
                    <option value="Wearables">Wearables / স্মার্ট ওয়াচ</option>
                    <option value="Superfoods">Superfoods / সুপারফুড</option>
                    <option value="Pantry">Pantry / রান্নার সামগ্রী</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    SKU Code
                  </label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Product Media (Photo & Video) Device Upload Section */}
              <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div>
                    <label className="block text-xs font-black text-slate-800">
                      {isBn ? 'পণ্যের ফটো ও ভিডিও আপলোড (Media)' : 'Product Media (Photo & Video)'}
                    </label>
                    <p className="text-[11px] text-slate-500">
                      {isBn 
                        ? 'মোবাইল বা পিসি থেকে সরাসরি ফটো অথবা ভিডিও ফাইল আপলোড করুন' 
                        : 'Upload product photos or MP4/WebM product video reels from device'}
                    </p>
                  </div>

                  {/* Source Switcher Tabs */}
                  <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setMediaSourceTab('device')}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                        mediaSourceTab === 'device' 
                          ? 'bg-emerald-600 text-white shadow-xs' 
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Smartphone className="w-3 h-3" />
                      <span>{isBn ? 'ডিভাইস আপলোড' : 'Device'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMediaSourceTab('presets')}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                        mediaSourceTab === 'presets' 
                          ? 'bg-emerald-600 text-white shadow-xs' 
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <ImageIcon className="w-3 h-3" />
                      <span>{isBn ? 'প্রিসেট' : 'Presets'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMediaSourceTab('url')}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                        mediaSourceTab === 'url' 
                          ? 'bg-emerald-600 text-white shadow-xs' 
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <span>URL</span>
                    </button>
                  </div>
                </div>

                {/* Hidden Device File Inputs */}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  accept="image/*,video/*" 
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      processUploadedFile(e.target.files[0]);
                    }
                  }} 
                  className="hidden" 
                />
                <input 
                  type="file" 
                  ref={photoInputRef} 
                  accept="image/*" 
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      processUploadedFile(e.target.files[0]);
                    }
                  }} 
                  className="hidden" 
                />
                <input 
                  type="file" 
                  ref={videoInputRef} 
                  accept="video/*" 
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      processUploadedFile(e.target.files[0]);
                    }
                  }} 
                  className="hidden" 
                />

                {/* Error Alert */}
                {uploadError && (
                  <div className="mb-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{uploadError}</span>
                  </div>
                )}

                {/* Tab 1: Device Upload (Default) */}
                {mediaSourceTab === 'device' && (
                  <div className="space-y-3">
                    {/* Drag & Drop Area */}
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition-all ${
                        isDragging 
                          ? 'border-emerald-500 bg-emerald-50/60 scale-[1.01]' 
                          : 'border-slate-300 hover:border-emerald-500 bg-white hover:bg-emerald-50/20'
                      }`}
                    >
                      <div className="w-11 h-11 mx-auto rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2 shadow-xs">
                        <Upload className="w-5 h-5 animate-pulse" />
                      </div>
                      <p className="text-xs font-bold text-slate-800">
                        {isBn 
                          ? 'ফটো বা ভিডিও টেনে এনে ড্রপ করুন অথবা ক্লিক করে সিলেক্ট করুন' 
                          : 'Drag & drop image or video here, or click to browse'}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        {isBn 
                          ? 'সাপোর্ট: JPG, PNG, WebP, GIF, MP4, WebM (সর্বোচ্চ ১০০ মেগাবাইট)' 
                          : 'Supports: JPG, PNG, WEBP, GIF, MP4, WebM (Up to 100MB)'}
                      </p>

                      {/* Quick Action Selector Buttons */}
                      <div className="mt-3 flex items-center justify-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          id="select-photo-from-device-btn"
                          onClick={() => photoInputRef.current?.click()}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 text-xs font-bold transition-colors border border-slate-200"
                        >
                          <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{isBn ? 'ডিভাইস থেকে ফটো' : 'Select Photo'}</span>
                        </button>
                        <button
                          type="button"
                          id="select-video-from-device-btn"
                          onClick={() => videoInputRef.current?.click()}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs font-bold transition-colors border border-purple-200"
                        >
                          <Film className="w-3.5 h-3.5 text-purple-600" />
                          <span>{isBn ? 'ডিভাইস থেকে ভিডিও' : 'Select Video'}</span>
                        </button>
                      </div>

                      {isReadingFile && (
                        <div className="mt-3 text-xs font-bold text-emerald-600 flex items-center justify-center gap-2">
                          <span className="w-3.5 h-3.5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                          <span>{isBn ? 'ডিভাইস থেকে আপলোড করা হচ্ছে...' : 'Uploading from device...'}</span>
                        </div>
                      )}
                    </div>

                    {/* Live Preview of Uploaded Media */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{isBn ? 'মিডিয়া প্রিভিউ' : 'Active Media Preview'}</span>
                        </span>

                        {/* If both video and image are present, allow toggling active preview */}
                        {formVideoUrl && (
                          <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-[10px] font-bold">
                            <button
                              type="button"
                              onClick={() => setActivePreviewType('image')}
                              className={`px-2 py-0.5 rounded ${activePreviewType === 'image' ? 'bg-white shadow-xs text-slate-900' : 'text-slate-500'}`}
                            >
                              Photo
                            </button>
                            <button
                              type="button"
                              onClick={() => setActivePreviewType('video')}
                              className={`px-2 py-0.5 rounded ${activePreviewType === 'video' ? 'bg-purple-600 text-white' : 'text-slate-500'}`}
                            >
                              Video
                            </button>
                          </div>
                        )}
                      </div>

                      {activePreviewType === 'video' && formVideoUrl ? (
                        <div className="space-y-2">
                          <div className="relative rounded-xl overflow-hidden bg-black aspect-video max-h-52 flex items-center justify-center">
                            <video
                              src={formVideoUrl}
                              controls
                              playsInline
                              className="w-full h-full object-contain"
                            />
                            <span className="absolute top-2 right-2 px-2 py-0.5 rounded bg-purple-600 text-white font-bold text-[10px] shadow">
                              HD Video
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-xs pt-1">
                            <div className="truncate text-slate-600 max-w-[200px]">
                              <span className="font-semibold text-slate-800">Video: </span>
                              {uploadedVideoName || 'Uploaded Video File'}
                              {uploadedFileSize && ` (${uploadedFileSize})`}
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => videoInputRef.current?.click()}
                                className="text-purple-600 hover:text-purple-700 font-bold text-[11px]"
                              >
                                {isBn ? 'ভিডিও পরিবর্তন' : 'Change Video'}
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setFormVideoUrl('');
                                  setFormMediaType('image');
                                  setActivePreviewType('image');
                                  setUploadedVideoName(null);
                                }}
                                className="text-rose-600 hover:text-rose-700 font-bold text-[11px] flex items-center gap-1"
                              >
                                <Trash2 className="w-3 h-3" />
                                <span>{isBn ? 'মুছুন' : 'Remove'}</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="relative rounded-xl overflow-hidden bg-slate-100 aspect-video max-h-48 flex items-center justify-center border border-slate-100">
                            <img
                              src={formImage}
                              alt="Product Preview"
                              className="w-full h-full object-cover"
                            />
                            {formVideoUrl && (
                              <button
                                type="button"
                                onClick={() => setActivePreviewType('video')}
                                className="absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-slate-950/80 hover:bg-slate-900 text-white text-[10px] font-bold flex items-center gap-1 shadow backdrop-blur-xs"
                              >
                                <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                                <span>{isBn ? 'ভিডিও দেখুন' : 'Switch to Video'}</span>
                              </button>
                            )}
                          </div>
                          <div className="flex items-center justify-between text-xs pt-1">
                            <div className="truncate text-slate-600 max-w-[200px]">
                              <span className="font-semibold text-slate-800">Photo: </span>
                              {uploadedImageName || 'Current Product Image'}
                              {uploadedImageName && uploadedFileSize && ` (${uploadedFileSize})`}
                            </div>
                            <button
                              type="button"
                              onClick={() => photoInputRef.current?.click()}
                              className="text-emerald-600 hover:text-emerald-700 font-bold text-[11px] flex items-center gap-1"
                            >
                              <Upload className="w-3 h-3" />
                              <span>{isBn ? 'ফটো পরিবর্তন' : 'Change Photo'}</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Tab 2: Presets */}
                {mediaSourceTab === 'presets' && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1">
                      {PRESET_IMAGES.map((img, idx) => (
                        <button
                          type="button"
                          key={idx}
                          onClick={() => {
                            setFormImage(img.url);
                            setActivePreviewType('image');
                            setUploadedImageName(null);
                          }}
                          className={`relative w-16 h-16 rounded-xl overflow-hidden shrink-0 border-2 transition-transform ${
                            formImage === img.url && activePreviewType === 'image' ? 'border-emerald-500 scale-105 shadow-sm' : 'border-slate-200'
                          }`}
                        >
                          <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {isBn ? 'বাছাই করা মানসম্মত ক্যাটালগ প্রিসেট ছবি' : 'Curated high-resolution demo images'}
                    </p>
                  </div>
                )}

                {/* Tab 3: URL */}
                {mediaSourceTab === 'url' && (
                  <div className="space-y-3 pt-1">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {isBn ? 'ছবির ওয়েব লিংক (Image URL)' : 'Image URL'}
                      </label>
                      <input
                        type="url"
                        placeholder="https://images.unsplash.com/photo-..."
                        value={formImage}
                        onChange={(e) => setFormImage(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {isBn ? 'ভিডিও ওয়েব লিংক (MP4/WebM Video URL)' : 'Video Stream / MP4 URL'}
                      </label>
                      <input
                        type="url"
                        placeholder="https://example.com/demo-video.mp4"
                        value={formVideoUrl}
                        onChange={(e) => {
                          setFormVideoUrl(e.target.value);
                          if (e.target.value) {
                            setFormMediaType('video');
                            setActivePreviewType('video');
                          }
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* AI Powered Description Writer */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">
                    {isBn ? 'পণ্যের আকর্ষণীয় বিবরণ (Description)' : 'Product Description'}
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateAiDescription}
                    disabled={isGeneratingAi}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[11px] font-bold border border-emerald-200 transition-colors"
                  >
                    <Sparkles className="w-3 h-3 text-emerald-600" />
                    <span>{isGeneratingAi ? (isBn ? 'লেখা হচ্ছে...' : 'Generating...') : (isBn ? 'এআই দিয়ে লিখুন' : 'AI Description')}</span>
                  </button>
                </div>
                <textarea
                  rows={3}
                  value={isBn ? formDescriptionBn : formDescription}
                  onChange={(e) => {
                    if (isBn) setFormDescriptionBn(e.target.value);
                    else setFormDescription(e.target.value);
                  }}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              {/* Featured checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  id="featured-product-checkbox"
                  type="checkbox"
                  checked={formIsFeatured}
                  onChange={(e) => setFormIsFeatured(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <label htmlFor="featured-product-checkbox" className="text-xs font-semibold text-slate-700">
                  {isBn ? 'হোমপেজে ফিচার্ড পণ্য হিসেবে প্রদর্শন করুন' : 'Pin to Homepage as Featured Product'}
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  id="save-product-submit-btn"
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-colors"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Media Viewer Modal */}
      {previewMediaProduct && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  {previewMediaProduct.videoUrl ? <Film className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 truncate max-w-[260px]">
                    {isBn ? previewMediaProduct.nameBn : previewMediaProduct.name}
                  </h4>
                  <p className="text-[10px] text-slate-400 font-mono">{previewMediaProduct.sku}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPreviewMediaProduct(null)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[280px] max-h-[380px] overflow-hidden">
              {previewMediaProduct.videoUrl ? (
                <video
                  src={previewMediaProduct.videoUrl}
                  controls
                  autoPlay
                  playsInline
                  className="max-h-[360px] w-full object-contain rounded-xl"
                />
              ) : (
                <img
                  src={previewMediaProduct.image}
                  alt={previewMediaProduct.name}
                  className="max-h-[360px] w-full object-contain rounded-xl"
                />
              )}
            </div>

            <div className="p-4 bg-slate-50 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-900">৳{previewMediaProduct.price.toLocaleString()}</span>
                <span className="text-slate-400 ml-2">({previewMediaProduct.stock} in stock)</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const prod = previewMediaProduct;
                    setPreviewMediaProduct(null);
                    handleOpenEdit(prod);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সম্পাদনা করুন' : 'Edit Product'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewMediaProduct(null)}
                  className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-colors"
                >
                  {isBn ? 'বন্ধ করুন' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
