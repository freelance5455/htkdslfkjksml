import React from 'react';
import { 
  TrendingUp, 
  ShoppingBag, 
  DollarSign, 
  Users, 
  ArrowUpRight, 
  Package, 
  AlertTriangle, 
  ExternalLink, 
  Sliders, 
  Plus, 
  Clock, 
  CheckCircle2, 
  Truck,
  Sparkles
} from 'lucide-react';
import { Store, Product, Order, Language, DashboardTab } from '../../types';

interface DashboardOverviewProps {
  activeStore: Store;
  products: Product[];
  orders: Order[];
  language: Language;
  onNavigateTab: (tab: DashboardTab) => void;
  onOpenStorefront: () => void;
  onOpenAddProduct: () => void;
  onUpdateOrderStatus: (orderId: string, status: Order['orderStatus']) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  activeStore,
  products,
  orders,
  language,
  onNavigateTab,
  onOpenStorefront,
  onOpenAddProduct,
  onUpdateOrderStatus,
}) => {
  const isBn = language === 'bn';

  // Store-specific metrics
  const storeOrders = orders.filter((o) => o.storeId === activeStore.id);
  const storeProducts = products.filter((p) => p.storeId === activeStore.id);

  const totalRevenue = storeOrders.reduce((sum, o) => sum + (o.paymentStatus === 'paid' ? o.totalAmount : 0), 0);
  const totalOrdersCount = storeOrders.length;
  const avgOrderValue = totalOrdersCount > 0 ? Math.round(totalRevenue / totalOrdersCount) : 0;
  const lowStockProducts = storeProducts.filter((p) => p.stock <= 15);

  const pendingOrders = storeOrders.filter((o) => o.orderStatus === 'pending');

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Action Bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
              {isBn ? `${activeStore.name} — ওভারভিউ` : `${activeStore.name} — Overview`}
            </h1>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              Live Cloud Store
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'আপনার স্টোরের আজকের সেলস পারফরম্যান্স, অর্ডার ফুলফিলমেন্ট ও স্টক সামারি।' 
              : 'Real-time sales performance, fulfillment pipeline, and inventory status.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            id="quick-add-product-btn"
            onClick={onOpenAddProduct}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isBn ? 'পণ্য যোগ করুন' : 'Add Product'}</span>
          </button>

          <button
            id="quick-customize-btn"
            onClick={() => onNavigateTab('customizer')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span>{isBn ? 'স্টোর ডিজাইন' : 'Customize Theme'}</span>
          </button>

          <button
            id="quick-view-storefront-btn"
            onClick={onOpenStorefront}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>{isBn ? 'লাইভ স্টোর দেখুন' : 'Live Storefront'}</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total GMV Revenue */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>{isBn ? 'মোট সংগৃহীত বিক্রয় (GMV)' : 'Total Paid Volume'}</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-sm">
              ৳
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              ৳{totalRevenue.toLocaleString()}
            </div>
            <div className="flex items-center text-[11px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
              <ArrowUpRight className="w-3 h-3" />
              +18.4%
            </div>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {isBn ? 'গত ৩০ দিনের তুলনায় উর্ধ্বমুখী' : 'vs. previous 30-day period'}
          </div>
        </div>

        {/* Total Orders */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>{isBn ? 'মোট প্রক্রিয়াজাত অর্ডার' : 'Completed Orders'}</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {totalOrdersCount}
            </div>
            <div className="flex items-center text-[11px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
              <ArrowUpRight className="w-3 h-3" />
              +12.1%
            </div>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {pendingOrders.length > 0 ? (
              <span className="text-amber-600 font-semibold">
                {pendingOrders.length} {isBn ? 'টি নতুন অর্ডার অপেক্ষারত' : 'pending dispatch'}
              </span>
            ) : (
              <span>{isBn ? 'সব অর্ডার প্রক্রিয়াজাত' : 'All orders fulfilled'}</span>
            )}
          </div>
        </div>

        {/* Average Order Value */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>{isBn ? 'গড় অর্ডার মূল্য (AOV)' : 'Avg Order Value'}</span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              ৳{avgOrderValue.toLocaleString()}
            </div>
            <div className="flex items-center text-[11px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
              <ArrowUpRight className="w-3 h-3" />
              +5.8%
            </div>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {isBn ? 'উচ্চমূল্যের অর্ডারের হার বৃদ্ধি' : 'Healthy basket size ratio'}
          </div>
        </div>

        {/* Conversion Rate */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>{isBn ? 'চেকআউট কনভার্সন রেট' : 'Storefront Conversion'}</span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              3.85%
            </div>
            <div className="flex items-center text-[11px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
              <ArrowUpRight className="w-3 h-3" />
              +0.9%
            </div>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {isBn ? 'ইন্ডাস্ট্রি গড়ের চেয়ে ১.৪% বেশি' : 'Above regional e-commerce avg'}
          </div>
        </div>
      </div>

      {/* Low Stock Notification Alert if any */}
      {lowStockProducts.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-amber-900">
                {isBn 
                  ? `${lowStockProducts.length}টি পণ্যের স্টক শেষ হওয়ার পথে!` 
                  : `${lowStockProducts.length} Products Have Low Inventory (<15 units)`}
              </h3>
              <p className="text-[11px] text-amber-700 mt-0.5">
                {lowStockProducts.map((p) => p.name).join(', ')}
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('products')}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold shrink-0 transition-colors"
          >
            {isBn ? 'স্টক রিফিল করুন' : 'Restock Catalog'}
          </button>
        </div>
      )}

      {/* Grid: Sales Breakdown & Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sales Channels Breakdown (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">
              {isBn ? 'বিক্রয় মাধ্যম ও চ্যানেল' : 'Sales by Channel'}
            </h2>
            <span className="text-[11px] text-slate-400 font-medium">Real-time</span>
          </div>

          <div className="mt-4 space-y-3.5">
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>{isBn ? 'অনলাইন ওয়েব স্টোরফ্রন্ট' : 'Web Storefront'}</span>
                <span className="font-bold text-slate-900">65% (৳{(totalRevenue * 0.65).toFixed(0)})</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full w-[65%]"></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>{isBn ? 'ফেসবুক ও সোশ্যাল শপিং' : 'Social & WhatsApp Commerce'}</span>
                <span className="font-bold text-slate-900">25% (৳{(totalRevenue * 0.25).toFixed(0)})</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full w-[25%]"></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>{isBn ? 'ইন-স্টোর পিওএস (POS)' : 'Physical POS / Pop-up'}</span>
                <span className="font-bold text-slate-900">10% (৳{(totalRevenue * 0.10).toFixed(0)})</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full w-[10%]"></div>
              </div>
            </div>
          </div>

          {/* Payment Gateway Distribution */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold text-slate-700 mb-2.5">
              {isBn ? 'পেমেন্ট গেটওয়ে শেয়ার' : 'Payment Methods Settled'}
            </h3>
            <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
              <div className="p-2 rounded-xl bg-pink-50 border border-pink-100">
                <span className="font-bold text-pink-700 block">bKash</span>
                <span className="text-slate-600 font-semibold">54%</span>
              </div>
              <div className="p-2 rounded-xl bg-orange-50 border border-orange-100">
                <span className="font-bold text-orange-700 block">Nagad</span>
                <span className="text-slate-600 font-semibold">22%</span>
              </div>
              <div className="p-2 rounded-xl bg-blue-50 border border-blue-100">
                <span className="font-bold text-blue-700 block">Cards</span>
                <span className="text-slate-600 font-semibold">14%</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-700 block">COD</span>
                <span className="text-slate-600 font-semibold">10%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Orders Stream (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-slate-900">
                  {isBn ? 'সাম্প্রতিক লাইভ অর্ডারসমূহ' : 'Recent Live Orders'}
                </h2>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {storeOrders.length}
                </span>
              </div>
              <button
                onClick={() => onNavigateTab('orders')}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 transition-colors"
              >
                {isBn ? 'সকল অর্ডার দেখুন' : 'Manage All'} →
              </button>
            </div>

            <div className="mt-3 divide-y divide-slate-100">
              {storeOrders.slice(0, 4).map((order) => {
                const statusColors = {
                  pending: 'bg-amber-50 text-amber-700 border-amber-200',
                  processing: 'bg-blue-50 text-blue-700 border-blue-200',
                  shipped: 'bg-indigo-50 text-indigo-700 border-indigo-200',
                  delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                  cancelled: 'bg-rose-50 text-rose-700 border-rose-200',
                };

                return (
                  <div key={order.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">
                          {order.orderNumber}
                        </span>
                        <span className={`text-[10px] uppercase font-bold px-1.5 py-0.2 rounded border ${statusColors[order.orderStatus]}`}>
                          {order.orderStatus}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate mt-0.5">
                        {order.customerName} • {order.items.length} {order.items.length === 1 ? 'item' : 'items'} • {order.city}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-xs font-black text-slate-900">
                        ৳{order.totalAmount.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-slate-400 capitalize">
                        via {order.paymentMethod}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>{isBn ? 'কুরিয়ার অটোমেশন সক্রিয়' : 'Courier API synced with Steadfast & Pathao'}</span>
            <button
              onClick={() => onNavigateTab('copilot')}
              className="inline-flex items-center gap-1 text-emerald-600 font-bold hover:underline"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isBn ? 'এআই সহকারীর পরামর্শ' : 'Ask AI Copilot'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
