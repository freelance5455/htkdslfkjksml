import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  Sliders, 
  Bot, 
  Users, 
  CreditCard, 
  ExternalLink,
  ChevronRight,
  Sparkles,
  Headphones,
  MessageSquare
} from 'lucide-react';
import { 
  Store, 
  Product, 
  Order, 
  Customer, 
  Language, 
  DashboardTab, 
  StoreTheme,
  PaymentGatewayConfig,
  SubscriptionPayment
} from '../../types';
import { DashboardOverview } from './DashboardOverview';
import { ProductsManager } from './ProductsManager';
import { OrdersManager } from './OrdersManager';
import { StoreCustomizer } from './StoreCustomizer';
import { AICopilot } from './AICopilot';
import { CustomersManager } from './CustomersManager';
import { SubscriptionBilling } from './SubscriptionBilling';
import { LiveSupportChat } from '../support/LiveSupportChat';

interface MerchantDashboardProps {
  activeStore: Store;
  products: Product[];
  orders: Order[];
  customers: Customer[];
  language: Language;
  gateways?: PaymentGatewayConfig[];
  onOpenStorefront: () => void;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onUpdateOrderStatus: (orderId: string, status: Order['orderStatus']) => void;
  onUpdateStoreTheme: (storeId: string, updatedTheme: Partial<StoreTheme>, storeName?: string) => void;
  onUpdateStorePlan?: (storeId: string, newPlan: 'starter' | 'growth' | 'enterprise') => void;
  onAddSubscriptionPayment?: (payment: SubscriptionPayment) => void;
}

export const MerchantDashboard: React.FC<MerchantDashboardProps> = ({
  activeStore,
  products,
  orders,
  customers,
  language,
  gateways,
  onOpenStorefront,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onUpdateOrderStatus,
  onUpdateStoreTheme,
  onUpdateStorePlan,
  onAddSubscriptionPayment,
}) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [isSupportChatOpen, setIsSupportChatOpen] = useState<boolean>(false);
  const isBn = language === 'bn';

  const navItems: { id: DashboardTab; labelEn: string; labelBn: string; icon: React.ElementType }[] = [
    { id: 'overview', labelEn: 'Overview', labelBn: 'ওভারভিউ', icon: LayoutDashboard },
    { id: 'products', labelEn: 'Products', labelBn: 'পণ্যসমূহ', icon: Package },
    { id: 'orders', labelEn: 'Orders', labelBn: 'অর্ডার ট্র্যাকিং', icon: ShoppingBag },
    { id: 'customizer', labelEn: 'Store Customizer', labelBn: 'থিম কাস্টমাইজার', icon: Sliders },
    { id: 'copilot', labelEn: 'AI Copilot', labelBn: 'এআই সহকারী', icon: Bot },
    { id: 'customers', labelEn: 'Customers', labelBn: 'গ্রাহক তালিকা', icon: Users },
    { id: 'billing', labelEn: 'Plans & Billing', labelBn: 'প্ল্যান ও বিলিং', icon: CreditCard },
  ];

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 pb-16">
      {/* Sub-header Navigation */}
      <div className="bg-white border-b border-slate-200/80 sticky top-16 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between overflow-x-auto py-2.5 gap-2 no-scrollbar">
            <div className="flex items-center gap-1 sm:gap-1.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    id={`dashboard-tab-${item.id}`}
                    onClick={() => setActiveTab(item.id)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{isBn ? item.labelBn : item.labelEn}</span>
                    {item.id === 'copilot' && (
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Direct Support Chat Button in Sub-header */}
              <button
                type="button"
                id="merchant-header-support-btn"
                onClick={() => setIsSupportChatOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 shadow-xs transition-colors"
                title={isBn ? 'সাপোর্ট চ্যাট: সকাল ৯:০০ - রাত ১১:০০' : 'Customer Support: 9:00 AM - 11:00 PM'}
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">
                  {isBn ? 'সাপোর্ট চ্যাট (৯AM-১১PM)' : 'Support Chat (9AM-11PM)'}
                </span>
                <span className="sm:hidden">
                  {isBn ? 'সাপোর্ট' : 'Support'}
                </span>
              </button>

              <button
                onClick={onOpenStorefront}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                <span>{isBn ? 'পাবলিক স্টোর' : 'View Storefront'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'overview' && (
          <DashboardOverview
            activeStore={activeStore}
            products={products}
            orders={orders}
            language={language}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onOpenStorefront={onOpenStorefront}
            onOpenAddProduct={() => setActiveTab('products')}
            onUpdateOrderStatus={onUpdateOrderStatus}
          />
        )}

        {activeTab === 'products' && (
          <ProductsManager
            activeStore={activeStore}
            products={products}
            language={language}
            onAddProduct={onAddProduct}
            onUpdateProduct={onUpdateProduct}
            onDeleteProduct={onDeleteProduct}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersManager
            activeStore={activeStore}
            orders={orders}
            language={language}
            onUpdateOrderStatus={onUpdateOrderStatus}
          />
        )}

        {activeTab === 'customizer' && (
          <StoreCustomizer
            activeStore={activeStore}
            language={language}
            onUpdateStoreTheme={onUpdateStoreTheme}
            onOpenStorefront={onOpenStorefront}
          />
        )}

        {activeTab === 'copilot' && (
          <AICopilot
            activeStore={activeStore}
            language={language}
          />
        )}

        {activeTab === 'customers' && (
          <CustomersManager
            activeStore={activeStore}
            customers={customers}
            language={language}
          />
        )}

        {activeTab === 'billing' && (
          <SubscriptionBilling
            activeStore={activeStore}
            language={language}
            gateways={gateways}
            onUpdatePlan={(newPlan) => onUpdateStorePlan?.(activeStore.id, newPlan)}
            onAddSubscriptionPayment={onAddSubscriptionPayment}
            onOpenSupportChat={() => setIsSupportChatOpen(true)}
          />
        )}
      </div>

      {/* Live Support Chat Floating Widget */}
      <LiveSupportChat
        activeStore={activeStore}
        language={language}
        isOpen={isSupportChatOpen}
        onClose={() => setIsSupportChatOpen(false)}
        onToggle={() => setIsSupportChatOpen(!isSupportChatOpen)}
      />
    </div>
  );
};
