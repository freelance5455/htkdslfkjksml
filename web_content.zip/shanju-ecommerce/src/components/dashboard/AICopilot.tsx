import React, { useState } from 'react';
import { 
  Bot, 
  Sparkles, 
  Copy, 
  Check, 
  Send, 
  Share2, 
  MessageSquare, 
  Megaphone, 
  RefreshCw,
  ShoppingBag
} from 'lucide-react';
import { Language, Store } from '../../types';

interface AICopilotProps {
  activeStore: Store;
  language: Language;
}

export const AICopilot: React.FC<AICopilotProps> = ({
  activeStore,
  language,
}) => {
  const isBn = language === 'bn';
  const [activeTask, setActiveTask] = useState<'product' | 'ad' | 'sms' | 'support'>('product');
  const [promptInput, setPromptInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [aiOutput, setAiOutput] = useState<string>(
    isBn
      ? `✨ **প্রোডাক্ট ডেসক্রিপশন প্রপোজাল:**\n\n**আর্টিসান সুতি এমব্রয়ডারি সিল্ক পাঞ্জাবি (Artisan Silk Panjabi)**\n\nউৎসব কিংবা বিশেষ দিনে নিজের ব্যক্তিত্বকে অনন্য উচ্চতায় নিয়ে যেতে বেছে নিন আমাদের এই প্রিমিয়াম জ্যাকার্ড সিল্ক পাঞ্জাবি। সূক্ষ্ম কারুকার্যখচিত কলার এবং আরামদায়ক প্রিমিয়াম ফেব্রিক দেবে শতভাগ আভিজাত্যের অনুভূতি।\n\n**মূল বৈশিষ্ট্য:**\n• ১০০% পিওর লাক্সারি জ্যাকার্ড ফেব্রিক\n• নিখুঁত মেটালিক বাটন ও কলার এমব্রয়ডারি\n• ট্রপিক্যাল আবহাওয়ার সাথে সামঞ্জস্যপূর্ণ আরামদায়ক ফিটিং\n• সারা বাংলাদেশে ক্যাশ অন ডেলিভারি এবং দ্রুততম কুরিয়ার শিপিং।`
      : `✨ **Generated Product Description:**\n\n**Aura Artisan Embroidered Silk Panjabi**\n\nRedefine festive sophistication with this masterfully tailored Jacquard Silk Panjabi. Featuring subtle mandarin embroidery, mother-of-pearl accent buttons, and a silhouette engineered for effortless posture and breathability.\n\n**Key Highlights:**\n• 100% Breathable Jacquard Weave\n• Hand-inspected artisan craftsmanship\n• Tailored contemporary fit\n• Free shipping & doorstep exchange available.`
  );

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      if (activeTask === 'product') {
        setAiOutput(
          isBn
            ? `✨ **প্রোডাক্ট ডেসক্রিপশন:**\n\n**${promptInput || 'প্রিমিয়াম কালেকশন'}**\n\nপ্রিমিয়াম কোয়ালিটি এবং আধুনিক ডিজাইনের এক অনবদ্য মেলবন্ধন। দৈনন্দিন ব্যবহার কিংবা বিশেষ অনুষ্ঠানের জন্য এটি তৈরি করা হয়েছে সর্বোচ্চ যত্ন ও নিখুঁত ফিনিশিং দিয়ে।\n\n• দীর্ঘস্থায়ী ও টেকসই ম্যাটেরিয়াল\n• ১০০% আরামদায়ক অভিজ্ঞতা\n• মানসম্মত প্যাকেজিং সহ দ্রুততম হোম ডেলিভারি!`
            : `✨ **Generated Product Copy:**\n\n**${promptInput || 'Signature Artisan Release'}**\n\nEngineered for modern discerning tastemakers. Seamlessly blends heritage detailing with clean silhouettes, elevating your everyday presence with uncompromised comfort.\n\n• Certified premium-grade fabrication\n• Stress-tested for all-day wearability\n• Express tracked courier dispatch.`
        );
      } else if (activeTask === 'ad') {
        setAiOutput(
          isBn
            ? `📱 **ফেসবুক ও ইনস্টাগ্রাম হাই-কনভার্টিং অ্যাড কপি:**\n\n🔥 নতুন স্টক এসে গেছে! [সীমিত কালেকশন]\n\nআপনার পছন্দের প্রিমিয়াম আইটেমটি এখন পাচ্ছেন বিশেষ ২০% ছাড়ে! আর নয় অপেক্ষার ঝামেলা, সরাসরি অর্ডার করুন আমাদের ভেরিফাইড ওয়েব স্টোর থেকে।\n\n✅ বিকাশ ও নগদে ইনস্ট্যান্ট পেমেন্ট অথবা ক্যাশ অন ডেলিভারি\n✅ সারা দেশে ৪৮ ঘণ্টার মধ্যে সুপারফাস্ট ডেলিভারি\n\n👉 অফারটি পেতে এখনই 'Shop Now' বাটনে ক্লিক করুন!`
            : `📱 **High-Converting Social Ad Copy (Meta / TikTok):**\n\nHeadline: Turn Heads Wherever You Go — Without The Luxury Markup.\n\nMeet our top-rated essentials. 12,000+ happy buyers, 4.9★ verified reviews, and guaranteed satisfaction.\n\n⚡ Flash Launch: Get 15% OFF today with code AURA15.\n📦 Express 48-Hour delivery with full tracking.\n\n👉 Tap 'Shop Now' before sizes run out!`
        );
      } else if (activeTask === 'sms') {
        setAiOutput(
          isBn
            ? `💬 **অটোমেটেড এসএমএস ও হোয়াটসঅ্যাপ ব্রডকাস্ট:**\n\n"প্রিয় গ্রাহক, ${activeStore.name}-এ ঈদ স্পেশাল ফ্ল্যাশ সেল শুরু হয়েছে! আপনার কার্টের পণ্য কিনুন অতিরিক্ত ১৫% ছাড়ে। কুপন কোড: EID15। স্টক সীমিত! ভিজিট করুন: ${activeStore.slug}.shanju.cloud"`
            : `💬 **SMS / WhatsApp Promo Broadcast:**\n\n"${activeStore.name} Flash Alert! Weekend VIP Sale is now live. Enjoy 15% OFF your next order with code VIP15. Shop verified: ${activeStore.slug}.shanju.cloud - Reply STOP to opt out."`
        );
      } else if (activeTask === 'support') {
        setAiOutput(
          isBn
            ? `🤝 **কাস্টমার সাপোর্ট রেসপন্স:**\n\n"আসসালামু আলাইকুম! ${activeStore.name}-এ যোগাযোগ করার জন্য ধন্যবাদ। আপনার অর্ডারটি বর্তমানে কুরিয়ার সার্ভিসে হ্যান্ডওভার করা হয়েছে। ট্র্যাকিং আইডি দিয়ে আপনি সরাসরি পার্সেল ট্র্যাক করতে পারেন। কোনো প্রয়োজনে আমরা সবসময় আপনার পাশে আছি!"`
            : `🤝 **Polite Support Resolution:**\n\n"Hello! Thank you for reaching out to ${activeStore.name}. Your order has been securely packed and dispatched with our courier partner. You can track your parcel in real-time using your order number. Please let us know if we can assist you with anything else!"`
        );
      }
      setIsGenerating(false);
    }, 600);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(aiOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-600 flex items-center justify-center font-bold">
              <Bot className="w-4 h-4" />
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
              {isBn ? 'এআই কমার্স সহকারী (Commerce Copilot)' : 'AI Commerce Copilot'}
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'পণ্য বিবরণী, ফেসবুক অ্যাড কপি, প্রচারণামূলক এসএমএস ও গ্রাহক সেবা বার্তা স্বয়ংক্রিয়ভাবে তৈরি করুন।' 
              : 'Generate persuasive marketing copy, Facebook ad angles, and customer responses in seconds.'}
          </p>
        </div>

        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5 self-start sm:self-auto">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>Gemini AI Engine Active</span>
        </span>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Control Panel (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              {isBn ? 'কী ধরনের কনটেন্ট তৈরি করতে চান?' : 'Select Content Mode'}
            </h2>

            {/* Task Selector */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setActiveTask('product')}
                className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                  activeTask === 'product'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <ShoppingBag className="w-4 h-4 text-emerald-600 mb-1" />
                <span>{isBn ? 'পণ্য বিবরণী (Description)' : 'Product Description'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTask('ad')}
                className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                  activeTask === 'ad'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Megaphone className="w-4 h-4 text-blue-600 mb-1" />
                <span>{isBn ? 'ফেসবুক ও সোশ্যাল অ্যাড' : 'Social Ad Copy'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTask('sms')}
                className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                  activeTask === 'sms'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Share2 className="w-4 h-4 text-purple-600 mb-1" />
                <span>{isBn ? 'এসএমএস / WhatsApp মেসেজ' : 'SMS / WhatsApp Promo'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTask('support')}
                className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                  activeTask === 'support'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-amber-600 mb-1" />
                <span>{isBn ? 'কাস্টমার সাপোর্ট রিপ্লাই' : 'Customer Support'}</span>
              </button>
            </div>

            {/* Input Prompt */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {isBn ? 'পণ্যের নাম বা মূল কি-ওয়ার্ড লিখুন:' : 'Product name or topic keywords:'}
              </label>
              <textarea
                rows={3}
                placeholder={
                  isBn
                    ? 'যেমন: ঢাকাই জামদানি শাড়ি, ১০০% সুতি ফেব্রিক, লাল পাড়, ক্যাজুয়াল ওয়্যার...'
                    : 'e.g. Wireless ANC headphones, 40h battery, deep bass, waterproof...'
                }
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white"
              />
            </div>

            <button
              id="generate-ai-copy-btn"
              type="button"
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{isBn ? 'এআই চিন্তা করছে...' : 'Writing with AI...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{isBn ? 'কনটেন্ট তৈরি করুন' : 'Generate Content'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Output Display (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                <span>{isBn ? 'উৎপাদিত কনটেন্ট আউটপুট' : 'Generated Result'}</span>
              </div>

              <button
                id="copy-ai-output-btn"
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">{isBn ? 'কপি হয়েছে!' : 'Copied!'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    <span>{isBn ? 'কপি করুন' : 'Copy'}</span>
                  </>
                )}
              </button>
            </div>

            <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 font-sans text-xs text-slate-800 leading-relaxed whitespace-pre-line min-h-[220px]">
              {aiOutput}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
            <span>{isBn ? 'প্রয়োজনে এডিট করে আপনার ক্যাটালগ বা পেইজে ব্যবহার করুন' : 'Ready to paste into your product descriptions or social manager'}</span>
            <span className="text-emerald-600 font-semibold">{isBn ? 'বাংলা ও ইংরেজি সমর্থিত' : 'Bengali & English supported'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
