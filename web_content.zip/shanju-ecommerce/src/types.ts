export type Language = 'en' | 'bn';

export type AppView = 'landing' | 'dashboard' | 'storefront' | 'admin';

export type DashboardTab = 
  | 'overview' 
  | 'products' 
  | 'orders' 
  | 'customizer' 
  | 'customers' 
  | 'copilot' 
  | 'billing';

export interface StoreTheme {
  primaryColor: string; // hex or tailwind class identifier
  accentColor: string;
  fontFamily: string;
  announcementText: string;
  announcementTextBn: string;
  showAnnouncement: boolean;
  heroHeadline: string;
  heroHeadlineBn: string;
  heroSubheadline: string;
  heroSubheadlineBn: string;
  heroBannerImage: string;
  layoutStyle: 'modern' | 'minimal' | 'bold';
}

export interface Store {
  id: string;
  name: string;
  slug: string;
  logo: string;
  category: string;
  currency: 'BDT' | 'USD' | 'EUR';
  currencySymbol: string;
  status: 'active' | 'paused' | 'setup';
  plan: 'starter' | 'growth' | 'enterprise';
  customDomain?: string;
  theme: StoreTheme;
  createdAt: string;
}

export interface Product {
  id: string;
  storeId: string;
  name: string;
  nameBn: string;
  sku: string;
  category: string;
  categoryBn: string;
  price: number;
  compareAtPrice?: number;
  stock: number;
  image: string;
  videoUrl?: string;
  mediaType?: 'image' | 'video';
  additionalMedia?: Array<{ url: string; type: 'image' | 'video'; name?: string }>;
  rating: number;
  reviewsCount: number;
  description: string;
  descriptionBn: string;
  isFeatured: boolean;
  tags: string[];
}

export type PaymentMethod = 'bkash' | 'nagad' | 'card' | 'cod';
export type PaymentStatus = 'paid' | 'pending' | 'failed' | 'refunded';
export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  storeId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  deliveryAddress: string;
  city: string;
  createdAt: string;
  notes?: string;
}

export interface Customer {
  id: string;
  storeId: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: string;
  status: 'active' | 'vip' | 'new';
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface PricingPlan {
  id: string;
  name: string;
  nameBn: string;
  tagline: string;
  taglineBn: string;
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  popular?: boolean;
  features: string[];
  featuresBn: string[];
  limits: {
    products: string;
    stores: number;
    transactionFee: string;
    customDomain: boolean;
    aiAssistant: boolean;
  };
}

export interface MerchantUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  password: string;
  storeId: string;
  storeName: string;
  plan: 'starter' | 'growth' | 'enterprise';
  status: 'active' | 'suspended' | 'pending';
  joinedDate: string;
  lastLogin: string;
  trialDaysLeft?: number;
  totalPaidBDT: number;
}

export type PaymentGatewayProvider = 'aamarpay' | 'shohozpay' | 'shurjopay' | 'bkash_direct' | 'nagad_direct';

export interface PaymentGatewayConfig {
  id: PaymentGatewayProvider;
  name: string;
  nameBn: string;
  logo: string;
  description: string;
  descriptionBn: string;
  isEnabled: boolean;
  isLiveMode: boolean; // false = Sandbox / Test Mode, true = Live Production
  storeIdOrMerchantId: string;
  signatureOrSecretKey: string;
  appKeyOrPassword?: string;
  webhookUrl: string;
  transactionFeePercent: number;
  supportedCurrencies: string[];
}

export interface SubscriptionPayment {
  id: string;
  storeId: string;
  storeName: string;
  userName: string;
  userPhone: string;
  planId: 'starter' | 'growth' | 'enterprise';
  planName: string;
  amount: number;
  billingCycle: 'monthly' | 'yearly';
  gateway: PaymentGatewayProvider;
  transactionId: string;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  notes?: string;
}

