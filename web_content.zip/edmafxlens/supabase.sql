create table journal (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  symbol text not null, side text not null, lots numeric, result numeric, note text,
  created_at timestamptz default now()
);
create table messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid default auth.uid(), email text, body text not null,
  created_at timestamptz default now()
);
alter table journal enable row level security;
alter table messages enable row level security;
create policy "own journal" on journal for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "send message" on messages for insert to authenticated with check (auth.uid() = user_id);

-- Broker connections: only the MetaApi account id is stored, never the broker password.
create table broker_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  metaapi_id text not null, label text, platform text, login text, server text,
  created_at timestamptz default now()
);
alter table broker_accounts enable row level security;
create policy "own brokers" on broker_accounts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
