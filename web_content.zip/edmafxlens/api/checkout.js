import Stripe from 'stripe';
import { requireUser } from './_auth.js';

export default async function handler(req, res) {
  const auth = await requireUser(req, res);
  if (!auth) return;
  const user = auth.user;
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      customer_email: user.email,
      client_reference_id: user.id,
      success_url: process.env.SITE_URL + '/?paid=1',
      cancel_url: process.env.SITE_URL + '/',
    });
    res.status(200).json({ url: session.url });
  } catch (e) {
    res.status(500).json({ error: 'Checkout failed: ' + e.message });
  }
}
