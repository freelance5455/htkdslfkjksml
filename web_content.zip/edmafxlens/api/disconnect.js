import MetaApi from 'metaapi.cloud-sdk/esm-node';
import { requireUser } from './_auth.js';

export default async function handler(req, res) {
  const auth = await requireUser(req, res);
  if (!auth) return;
  const { data } = await auth.db.from('broker_accounts').select('metaapi_id').eq('id', (req.body || {}).id);
  if (!data?.length) return res.status(404).json({ error: 'Account not found.' });
  try {
    const api = new MetaApi(process.env.METAAPI_TOKEN);
    const account = await api.metatraderAccountApi.getAccount(data[0].metaapi_id);
    await account.remove(); // frees the MetaApi slot and deletes the stored credentials there
    await auth.db.from('broker_accounts').delete().eq('id', req.body.id);
    res.status(200).json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Could not disconnect: ' + e.message });
  }
}
