import MetaApi from 'metaapi.cloud-sdk/esm-node';
import { requireUser } from './_auth.js';

export default async function handler(req, res) {
  const auth = await requireUser(req, res);
  if (!auth) return;
  const { login, password, server, platform = 'mt5', label } = req.body || {};
  if (!login || !password || !server) return res.status(400).json({ error: 'Enter login, password and server.' });
  if (!['mt4', 'mt5'].includes(platform)) return res.status(400).json({ error: 'Platform must be MT4 or MT5.' });

  const { count } = await auth.db.from('broker_accounts').select('id', { count: 'exact', head: true });
  if (count >= 3) return res.status(400).json({ error: 'You can connect up to 3 accounts.' });

  try {
    // The password goes straight to MetaApi and is never saved or logged here.
    const api = new MetaApi(process.env.METAAPI_TOKEN);
    const account = await api.metatraderAccountApi.createAccount({
      name: `${auth.user.id.slice(0, 8)}-${login}`, type: 'cloud', platform,
      login: String(login), password, server, magic: 0, application: 'MetaApi',
    });
    await auth.db.from('broker_accounts').insert({
      metaapi_id: account.id, label: label || server, platform, login: String(login), server });
    res.status(200).json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: 'Could not connect: ' + e.message });
  }
}
