import { createClient } from '@supabase/supabase-js';
// Returns { user, db }. `db` is a Supabase client acting as the signed-in user, so row-level security applies.
export async function requireUser(req, res) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const db = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: 'Bearer ' + token } } });
  const { data, error } = await db.auth.getUser(token);
  if (error || !data.user) { res.status(401).json({ error: 'Please sign in again.' }); return null; }
  return { user: data.user, db };
}
