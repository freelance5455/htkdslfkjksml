import MetaApi from 'metaapi.cloud-sdk/esm-node';
import { requireUser } from './_auth.js';

export default async function handler(req, res) {
  const auth = await requireUser(req, res);
  if (!auth) return;
  try {
    // RLS guarantees a user can only look up their own broker rows.
    let q = auth.db.from('broker_accounts').select('metaapi_id');
    q = req.query.id ? q.eq('id', req.query.id) : q.order('created_at').limit(1);
    const { data } = await q;
    if (!data?.length) return res.status(404).json({ error: 'No broker connected yet. Add one in the Brokers tab.' });

    const api = new MetaApi(process.env.METAAPI_TOKEN);
    const account = await api.metatraderAccountApi.getAccount(data[0].metaapi_id);
    const conn = account.getRPCConnection();
    await conn.connect();
    await conn.waitSynchronized();
    const [info, positions] = await Promise.all([conn.getAccountInformation(), conn.getPositions()]);
    res.status(200).json({ info, positions });
  } catch (e) {
    res.status(500).json({ error: 'Could not reach your broker: ' + e.message });
  }
}
