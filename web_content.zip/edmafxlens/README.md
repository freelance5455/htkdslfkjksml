# Edmafxlens

Web app + backend + Android APK wrapper.

## 1. Supabase (login + database)
1. Create a project at supabase.com. Run `supabase.sql` in the SQL editor.
2. Put the Project URL and anon key in `public/index.html` (top of the script) and in the env vars below.

## 2. Stripe (payments)
Create a subscription product, copy its Price ID into `STRIPE_PRICE_ID`.

## 3. MetaApi (broker connections)
Create an account at app.metaapi.cloud and copy your API token into `METAAPI_TOKEN`. Users connect their own brokers in the Brokers tab; `METAAPI_ACCOUNT_ID` is no longer needed.

## 4. Deploy to Vercel
`npm i -g vercel && npm install && vercel`
Add every variable from `.env.example` in the Vercel dashboard, then `vercel --prod`.

## 5. Build the APK
1. Set `server.url` in `capacitor.config.json` to your Vercel URL.
2. `npm install && npm run apk:init && npm run apk:sync && npm run apk:open`
3. In Android Studio: Build > Build APK(s). The file is in `android/app/build/outputs/apk/`.
