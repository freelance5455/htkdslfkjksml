import os, re, hashlib
from typing import Optional, List
from datetime import datetime, timezone
import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="ShikarChi Machine API", version="0.1.0")
DIVAR_URL = "https://open-api.divar.ir/v2/open-platform/finder/post"

class HuntRequest(BaseModel):
    city: str = Field(default="tehran", description="Divar city slug; one city per request")
    query_text: Optional[str] = None
    brand_model: List[str] = []
    min_year: Optional[int] = None
    max_year: Optional[int] = None
    min_usage: Optional[int] = None
    max_usage: Optional[int] = None
    min_price: Optional[int] = None
    max_price: Optional[int] = None

def require_app_token(token: Optional[str]):
    expected = os.getenv("APP_API_TOKEN")
    if not expected:
        raise HTTPException(503, "APP_API_TOKEN is not configured on server")
    if token != expected:
        raise HTTPException(401, "Unauthorized")

def build_divar_payload(req: HuntRequest):
    query = {}
    if req.brand_model:
        query["brand_model"] = req.brand_model
    if req.min_year is not None or req.max_year is not None:
        query["production_year"] = {
            k:v for k,v in {"min":req.min_year, "max":req.max_year}.items() if v is not None
        }
    if req.min_usage is not None or req.max_usage is not None:
        query["usage"] = {
            k:v for k,v in {"min":req.min_usage, "max":req.max_usage}.items() if v is not None
        }
    if req.min_price is not None or req.max_price is not None:
        query["price"] = {
            k:v for k,v in {"min":req.min_price, "max":req.max_price}.items() if v is not None
        }
    body = {"category":"light", "city":req.city, "query":query}
    if req.query_text:
        body["query_text"] = req.query_text[:128]
    return body

def normalize(post):
    price_obj = post.get("price") or {}
    price = int(price_obj.get("value") or 0)
    token = post.get("token","")
    title = post.get("title") or post.get("custom_post_subtitle") or "بدون عنوان"
    return {
        "source":"divar",
        "source_id":token,
        "dedupe_key":hashlib.sha256(f"divar:{token}".encode()).hexdigest(),
        "title":title,
        "city":post.get("city"),
        "price_toman":price,
        "year":(post.get("vehicles_fields") or {}).get("year"),
        "usage_km":(post.get("vehicles_fields") or {}).get("usage"),
        "last_modified_at":post.get("last_modified_at"),
        "url":f"https://divar.ir/v/{token}" if token else None,
        "retrieved_at":datetime.now(timezone.utc).isoformat()
    }

@app.get("/health")
def health():
    return {"ok":True, "service":"shikarchi-machine", "time":datetime.now(timezone.utc).isoformat()}

@app.post("/v1/hunt/divar")
async def hunt_divar(req: HuntRequest, x_app_token: Optional[str] = Header(default=None)):
    require_app_token(x_app_token)
    api_key = os.getenv("DIVAR_API_KEY")
    if not api_key:
        raise HTTPException(503, "Divar API key not configured. Obtain approved SEARCH_POST access first.")
    payload = build_divar_payload(req)
    async with httpx.AsyncClient(timeout=25) as client:
        response = await client.post(DIVAR_URL, json=payload, headers={
            "x-api-key":api_key, "Content-Type":"application/json"
        })
    if response.status_code == 429:
        raise HTTPException(429, "Divar quota/rate limit reached")
    if response.status_code >= 400:
        raise HTTPException(response.status_code, "Divar API request failed; verify approved access and request fields")
    data = response.json()
    posts = data.get("posts", [])
    normalized = [normalize(p) for p in posts]
    # The Divar search endpoint is city-scoped; nationwide coverage requires
    # separately approved calls for a controlled list of cities and quota budgeting.
    return {"source":"divar", "city":req.city, "count":len(normalized),
            "posts":normalized, "note":"Only the approved Divar endpoint was queried."}

@app.get("/v1/sources")
def sources():
    return [
      {"id":"divar","name":"دیوار","status":"adapter_ready_requires_approved_api_key"},
      {"id":"sheypoor","name":"شیپور","status":"not_connected_access_review_required"},
      {"id":"bama","name":"باما","status":"not_connected_access_review_required"},
      {"id":"karnameh","name":"کارنامه","status":"not_connected_access_review_required"},
      {"id":"hamrah_mechanic","name":"همراه مکانیک","status":"not_connected_access_review_required"},
      {"id":"khodro45","name":"خودرو۴۵","status":"not_connected_access_review_required"}
    ]
