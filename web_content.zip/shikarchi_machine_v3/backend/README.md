# Backend starter

This is a secure server-side adapter skeleton, not a deployed server.

## Run
1. Python 3.10+
2. `python -m venv .venv`
3. Activate it, then `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and set:
   - `APP_API_TOKEN` to a long random secret
   - `DIVAR_API_KEY` only after approval for `SEARCH_POST`
5. `uvicorn app.main:app --host 0.0.0.0 --port 8000`

## Endpoint
`POST /v1/hunt/divar` with header `X-App-Token`.

Example JSON:
```json
{
  "city": "tehran",
  "query_text": "پژو ۲۰۷",
  "min_year": 1400,
  "max_year": 1403,
  "max_usage": 100000,
  "min_price": 300000000,
  "max_price": 1000000000
}
```

Important:
- Keep both keys on the server. Never embed them in the APK or send them in chat.
- Divar search is city-scoped; nationwide coverage needs controlled per-city calls.
- Divar documentation currently warns that the search endpoint has a very small total quota (100 calls) and no pagination. Do not schedule frequent polling against it.
- Other source adapters are intentionally marked unconnected until their terms/access methods are confirmed.
- This starter does not estimate market price from live transaction data; that requires a verified pricing dataset.
