@echo off
setlocal
call "%~dp0gradlew.bat" :app:assembleRelease
exit /b %ERRORLEVEL%
