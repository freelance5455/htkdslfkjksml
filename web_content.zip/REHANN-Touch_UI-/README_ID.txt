# REHANN - Touch UI - (Android Native)

Proyek Android native sederhana berbasis Java/XML-free UI untuk dikerjakan langsung dari HP.

## Yang sudah disiapkan
- Login lokal (demo; bukan keamanan akun sungguhan).
- Dashboard ungu gelap/neon.
- Membaca mode refresh rate yang dilaporkan layar.
- Tombol membuka pengaturan layar, aksesibilitas, dan WhatsApp.
- Penjelasan batas FPS, DPI, resolusi, dan density Android.

## Batasan penting
Aplikasi biasa tanpa root/ADB tidak boleh mengubah paksa refresh rate, FPS game, resolusi, atau density global. Tombol mengarahkan pengguna ke pengaturan Android resmi. Ini disengaja agar aman dan tidak menampilkan kontrol palsu.

## Build langsung dari HP
1. Ekstrak ZIP ke folder penyimpanan HP.
2. Buka proyek dengan AndroidIDE yang mendukung proyek Gradle Android, atau IDE Android lain.
3. Pastikan tersedia JDK 17 dan Android SDK Platform 35 (atau sesuaikan compileSdk jika IDE belum mendukung).
4. Jalankan task Gradle `:app:assembleDebug`.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Instal APK dan izinkan instalasi dari sumber yang dipilih bila Android memintanya.

Jika AndroidIDE tidak kompatibel dengan versi Gradle/AGP ini, gunakan versi Android Gradle Plugin dan Gradle wrapper yang direkomendasikan oleh IDE. File Gradle wrapper tidak disertakan karena perlu dihasilkan oleh IDE/Gradle lokal.

## Login demo
Username: `Rehann Parker 🙌`
Password: `Rehann140409`

Kredensial tertanam di source code dan mudah dibaca. Jangan gunakan untuk melindungi data pribadi atau layanan sungguhan.
