package com.rehann.touchui;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.provider.Settings;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import android.graphics.Typeface;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=0xff07000e, PANEL=0xff13091e, PURPLE=0xff9b19ff, LIGHT=0xffcda5f5, WHITE=0xfffaf7ff;
    LinearLayout page; float density;
    int d(float v){return (int)(v*density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);density=getResources().getDisplayMetrics().density;
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(0);login();}
    GradientDrawable shape(int fill,int stroke,int radius){GradientDrawable x=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{fill,0xff100719});x.setCornerRadius(d(radius));x.setStroke(d(1.3f),stroke);return x;}
    TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void base(){ScrollView sc=new ScrollView(this);sc.setFillViewport(true);page=col();page.setPadding(d(25),d(25),d(25),d(35));page.setBackground(new StripeDrawable());sc.addView(page);setContentView(sc);}
    class StripeDrawable extends android.graphics.drawable.Drawable{
        Paint p=new Paint(3); public void draw(Canvas c){Rect b=getBounds();p.setShader(new LinearGradient(0,0,b.width(),b.height(),new int[]{0xff10001e,BG,BG,0xff10001e},null,Shader.TileMode.CLAMP));c.drawRect(b,p);p.setShader(null);p.setColor(0xff4300a0);p.setStrokeWidth(d(5));for(int i=-500;i<b.width()+500;i+=d(210))c.drawLine(i,b.height(),i+d(450),0,p);p.setColor(0xff21003f);p.setStrokeWidth(d(2));for(int i=-500;i<b.width()+500;i+=d(210))c.drawLine(i+d(14),b.height(),i+d(464),0,p);}
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return -1;}
    }
    void space(int h){page.addView(new Space(this),new LinearLayout.LayoutParams(1,d(h)));}
    EditText input(String hint,boolean password){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(WHITE);e.setHintTextColor(LIGHT);e.setHint(hint);e.setTextSize(18);e.setPadding(d(20),0,d(18),0);e.setBackground(shape(PANEL,0xff7133a2,24));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    void login(){base();space(105);TextView logo=txt("◢R",92,PURPLE,true);logo.setGravity(Gravity.CENTER);page.addView(logo);TextView name=txt("REHANN",40,WHITE,true);name.setGravity(Gravity.CENTER);page.addView(name);TextView sub=txt("- Touch UI -",27,PURPLE,true);sub.setGravity(Gravity.CENTER);page.addView(sub);space(55);
        page.addView(txt("Masuk ke akun Anda",24,LIGHT,true));page.addView(txt("Untuk melanjutkan ke aplikasi",17,LIGHT,false));space(35);
        EditText u=input("      Username",false);page.addView(u,new LinearLayout.LayoutParams(-1,d(70)));
        space(18);EditText p=input("      Password",true);page.addView(p,new LinearLayout.LayoutParams(-1,d(70)));
        space(28);Button go=button("Masuk     ❯",true);page.addView(go,new LinearLayout.LayoutParams(-1,d(70)));TextView err=txt("",14,0xffff7777,false);err.setGravity(Gravity.CENTER);page.addView(err);
        go.setOnClickListener(v->{if(u.getText().toString().trim().equals("Rehann Parker 🙌")&&p.getText().toString().equals("Rehann140409"))dashboard();else err.setText("Username atau password salah.");});
    }
    Button button(String s,boolean bright){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setTextSize(17);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,bright?new int[]{0xff4c00c7,0xffa000ff,0xff5700c9}:new int[]{0xff321044,0xff6810b9}));return b;}
    void open(String action){try{startActivity(new Intent(action));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}}
    void banner(){LinearLayout c=col();c.setPadding(d(16),d(15),d(16),d(15));c.setBackground(shape(0xff210d35,0xff663099,20));c.addView(txt("ϟ  Optimasi Performa & Touch Responsif",17,WHITE,true));c.addView(txt("Lebih Lancar • Lebih Responsif • Lebih Maksimal",13,LIGHT,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,d(24),0,d(22));page.addView(c,lp);}
    void header(String title,String desc,String symbol,String action,String intent){LinearLayout c=col();c.setPadding(d(15),d(14),d(15),d(14));c.setBackground(shape(PANEL,0xff42245a,20));LinearLayout top=row();TextView ico=txt(symbol,35,PURPLE,true);ico.setGravity(Gravity.CENTER);top.addView(ico,new LinearLayout.LayoutParams(d(65),d(58)));LinearLayout words=col();words.addView(txt(title,19,WHITE,true));TextView detail=txt(desc,14,LIGHT,false);detail.setPadding(0,d(3),0,0);words.addView(detail);top.addView(words,new LinearLayout.LayoutParams(0,-2,1));c.addView(top);if(action!=null){Button b=button(action,false);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,d(44));ap.topMargin=d(10);c.addView(b,ap);b.setOnClickListener(v->open(intent));}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=d(14);page.addView(c,lp);}
    void choiceCard(String title,String desc,String icon,String[] opts,String selected,Runnable info){LinearLayout c=col();c.setPadding(d(15),d(14),d(15),d(14));c.setBackground(shape(PANEL,0xff42245a,20));LinearLayout top=row();TextView i=txt(icon,31,PURPLE,true);i.setGravity(Gravity.CENTER);top.addView(i,new LinearLayout.LayoutParams(d(65),d(58)));LinearLayout w=col();w.addView(txt(title,19,WHITE,true));w.addView(txt(desc,14,LIGHT,false));top.addView(w,new LinearLayout.LayoutParams(0,-2,1));c.addView(top);
        LinearLayout buttons=row();for(String s:opts){Button b=button(s,s.equals(selected));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,d(48),1);bp.setMargins(d(3),d(12),d(3),0);buttons.addView(b,bp);b.setOnClickListener(v->{new AlertDialog.Builder(this).setMessage("Pilihan "+s+" hanya dapat diterapkan jika didukung perangkat. Buka Pengaturan layar untuk memilih mode resmi Android.").setPositiveButton("Buka pengaturan", (a,z)->open(Settings.ACTION_DISPLAY_SETTINGS)).setNegativeButton("Tutup",null).show();});}c.addView(buttons);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=d(14);page.addView(c,lp);
    }
    void dashboard(){base();LinearLayout brand=row();TextView mark=txt("◢R",53,PURPLE,true);brand.addView(mark);LinearLayout labels=col();labels.addView(txt("REHANN",30,WHITE,true));labels.addView(txt("- Touch UI -",20,PURPLE,true));brand.addView(labels);page.addView(brand);banner();
        choiceCard("Refresh Rate","Atur layar refresh rate untuk pengalaman lebih mulus.","▣",new String[]{"60 Hz","90 Hz","120 Hz"},"120 Hz",null);
        choiceCard("FPS Target","Atur batas FPS agar lebih stabil.","▣",new String[]{"60 FPS","90 FPS","120 FPS"},"120 FPS",null);
        header("Kursor Besar","Perbesar atau ubah kursor melalui pengaturan aksesibilitas.","➤","Buka Aksesibilitas",Settings.ACTION_ACCESSIBILITY_SETTINGS);
        header("Atur DPI","Ukuran tampilan sistem dikelola oleh Android.","DPI","Atur ukuran tampilan",Settings.ACTION_DISPLAY_SETTINGS);
        Button dpi=button("Buka pengaturan tampilan",false);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,d(46));dp.bottomMargin=d(14);page.addView(dpi,dp);dpi.setOnClickListener(v->open(Settings.ACTION_DISPLAY_SETTINGS));
        header("Atasi Resolusi & Density","Perangkat tidak selalu mengizinkan aplikasi mengubah resolusi atau density.","⛶","Buka pengaturan",Settings.ACTION_DISPLAY_SETTINGS);
        Button display=button("Buka Pengaturan",false);page.addView(display,new LinearLayout.LayoutParams(-1,d(46)));display.setOnClickListener(v->open(Settings.ACTION_DISPLAY_SETTINGS));
        LinearLayout channel=col();channel.setPadding(d(16),d(14),d(16),d(14));channel.setBackground(shape(0xff21052f,0xff9b19ff,20));channel.addView(txt("➤  Ikuti Saluran",19,WHITE,true));channel.addView(txt("Dapatkan update terbaru, tips & trik, serta fitur eksklusif dari Rehann!",14,LIGHT,false));Button join=button("Gabung  ❯",true);channel.addView(join,new LinearLayout.LayoutParams(-1,d(46)));join.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://whatsapp.com/channel/0029VbDmUySHwXbHy5qDiP2l"))));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=d(12);page.addView(channel,cp);
        TextView note=txt("Mode aman tanpa root. Tombol pengaturan membuka menu resmi Android; nilai Hz/FPS/DPI tidak dipaksakan oleh aplikasi.",12,LIGHT,false);note.setPadding(d(4),d(14),d(4),0);page.addView(note);
    }
}
