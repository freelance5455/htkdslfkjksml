# DuelScan v5 — All Summon Types, Spell/Trap Categories & Camera Workflow

This is a browser-based prototype/source package, not an APK and not yet a complete or tournament-accurate Yu-Gi-Oh! simulator.

## Added in v5
- Summon method selector: Normal, Tribute, Ritual, Fusion, Synchro, Xyz, Pendulum, Link, effect-based Special, and Flip Summon.
- Basic Normal/Tribute Summon checks, phase checks, one Normal Summon/Set per turn, Tribute selection, and available zones.
- Demo card entries for Ritual/Fusion/Synchro/Xyz/Pendulum/Link monster types.
- Spell/Trap categories: Normal, Quick-Play, Continuous, Equip, Field, Ritual Spells; Normal, Continuous, Counter Traps.
- Face-down monster Set and face-down Spell/Trap Set flows; the field hides face-down card identity. Face-down placement does not require a camera scan.
- Camera preview and photo capture/upload, plus a manual identity-confirmation fallback.
- Explicit validation messages where material checks/effect logic are not implemented, instead of silently allowing unsupported Summons.

## Important limitations (do not mistake this for finished functionality)
- Card examples are demo entries, not a full/current official card database.
- Ritual/Fusion/Synchro/Xyz/Link/Pendulum Summon requirements are not fully calculated. The prototype blocks unsupported cases rather than pretending to validate all materials.
- Card-specific effects, chains, costs, targets, negation, official rulings, and complete battle/zone restrictions remain incomplete.
- Camera recognition is **not automatic**. This prototype lets the user load a photo and manually confirm a card. Real recognition needs a card-image dataset/model or reliable card database matching, confidence thresholds, glare/blur handling, and device testing.
- AR tracking and anchored 3D models are **not implemented**; these need an AR SDK (e.g. ARCore on supported Android devices), tracking logic, and 3D assets.
- Data is in-memory and is not permanently saved.
- This is HTML/CSS/JavaScript, not a signed APK. Import/build steps depend on what ApkForge accepts.

## Run
Open `index.html` in a modern browser. Camera access typically requires HTTPS or localhost and user permission.
