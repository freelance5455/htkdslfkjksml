Photo Hdase Digital Studio — Android Studio Project

እዚ ZIP ብቐጥታ APK ኣይኮነን። ናብ APK ንምቕያር Windows 10 ኮምፒዩተርን Android Studioን የድሊ።

1. እዚ ZIP ኣብ Windows 10 ኣውርድካ Extract All ግበር።
2. Android Studio ካብ https://developer.android.com/studio ኣውርድካ ጽዓን።
3. Android Studio ክፈት > Open > እቲ PhotoHdaseAndroidProject ፎልደር ምረጽ።
4. Gradle sync ክሳብ ዝውዳእ ተጸበ። ኢንተርነት ክደሊ ይኽእል።
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ምረጽ።
6. APK ኣብ app/build/outputs/apk/debug/ ክርከብ እዩ።
7. APK ናብ Android ሞባይልካ ስደዶ፣ ክፈቶ፣ እንተተሓቲትካ Allow from this source ፍቐድ፣ Install ግበር።

ማስታወሻ:
- እዚ ስሪት ኣብ ሓደ መሳርሒ ዳታ ይዕቅብ። ኦፍላይን ይሰርሕ።
- ኦንላይን ምውህሃድ ኣብ ብዙሕ መሳርሒታት ንምስራሕ ክላውድ ዳታቤዝን ምርግጋጽ መእተዊን ክውሰኽ ኣለዎ።
- ፎቶታት ኣብ ኣፕ ውሽጢ ዝተዓቀቡ ዳታ ክውስኹ ስለዝኽእሉ ባክኣፕ ብተደጋጋሚ ግበር።
