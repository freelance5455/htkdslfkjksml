#!/usr/bin/env bash
# يجهّز مجلد android تلقائيًا (إن لم يكن موجودًا) ويضيف الأذونات ويرفع minSdk.
set -euo pipefail

if [ ! -d android ]; then
  flutter create --org dz.ousim --project-name ousimdz --platforms=android /tmp/scaffold
  cp -r /tmp/scaffold/android ./android
fi

python3 - <<'PY'
import re, pathlib

manifest = pathlib.Path('android/app/src/main/AndroidManifest.xml')
text = manifest.read_text()
perms = ['INTERNET', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS',
         'ACCESS_NETWORK_STATE', 'BLUETOOTH', 'POST_NOTIFICATIONS']
add = ''.join(
    f'\n    <uses-permission android:name="android.permission.{p}"/>'
    for p in perms if f'android.permission.{p}"' not in text)
if add:
    text = re.sub(r'(<manifest[^>]*>)', lambda m: m.group(1) + add, text, count=1)
    manifest.write_text(text)

# اسم التطبيق تحت الأيقونة
text = manifest.read_text()
text = re.sub(r'android:label="[^"]*"', 'android:label="OUSIMDZ"', text, count=1)
manifest.write_text(text)

# تقوية الأمان: منع النسخ الاحتياطي واتصالات HTTP غير المشفّرة
text = manifest.read_text()
for attr in ('android:allowBackup="false"', 'android:usesCleartextTraffic="false"'):
    key = attr.split('=')[0]
    if key not in text:
        text = text.replace('<application', '<application\n        ' + attr, 1)
manifest.write_text(text)

KTS_SIGNING = """    signingConfigs {
        create("release") {
            val ksPath = System.getenv("RELEASE_KEYSTORE_PATH")
            if (ksPath != null) {
                storeFile = file(ksPath)
                storePassword = System.getenv("RELEASE_STORE_PASSWORD")
                keyAlias = System.getenv("RELEASE_KEY_ALIAS")
                keyPassword = System.getenv("RELEASE_KEY_PASSWORD")
            }
        }
    }

"""
GROOVY_SIGNING = """    signingConfigs {
        release {
            def ksPath = System.getenv("RELEASE_KEYSTORE_PATH")
            if (ksPath != null) {
                storeFile file(ksPath)
                storePassword System.getenv("RELEASE_STORE_PASSWORD")
                keyAlias System.getenv("RELEASE_KEY_ALIAS")
                keyPassword System.getenv("RELEASE_KEY_PASSWORD")
            }
        }
    }

"""
for name in ('android/app/build.gradle', 'android/app/build.gradle.kts'):
    p = pathlib.Path(name)
    if not p.exists():
        continue
    s = p.read_text().replace('flutter.minSdkVersion', '23')
    if 'RELEASE_KEYSTORE_PATH' not in s:
        if name.endswith('.kts'):
            s = s.replace('    buildTypes {', KTS_SIGNING + '    buildTypes {', 1)
            s = s.replace('signingConfig = signingConfigs.getByName("debug")',
                'signingConfig = if (System.getenv("RELEASE_KEYSTORE_PATH") != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")')
        else:
            s = s.replace('    buildTypes {', GROOVY_SIGNING + '    buildTypes {', 1)
            s = s.replace('signingConfig signingConfigs.debug',
                'signingConfig System.getenv("RELEASE_KEYSTORE_PATH") != null ? signingConfigs.release : signingConfigs.debug')
    p.write_text(s)
print('android prepared')
PY
