#!/usr/bin/env bash
# ينشر خادم OUSIMDZ (الدوال + قواعد الأمان + صفحات الخصوصية) بخطوات مبسّطة.
# الأسهل: افتحه من Google Cloud Shell:  https://shell.cloud.google.com
# (متصفح فقط، بدون تثبيت أي شيء على جهازك)
set -e
cd "$(dirname "$0")/.."

echo "=============================="
echo " OUSIMDZ — نشر الخادم"
echo "=============================="

if ! command -v firebase >/dev/null 2>&1; then
  echo "• تثبيت أداة Firebase..."
  npm install -g firebase-tools
fi

if ! firebase projects:list >/dev/null 2>&1; then
  echo "• تسجيل الدخول إلى Firebase (سيعطيك رابطًا، افتحه وانسخ الرمز هنا)"
  firebase login --no-localhost
fi

read -r -p "اكتب معرّف مشروع Firebase (Project ID): " PROJECT
firebase use "$PROJECT"

echo
echo "• مفاتيح Agora (من console.agora.io ← مشروعك)"
read -r -p "Agora App ID: " APPID
read -r -s -p "Agora App Certificate (لن يظهر ما تكتبه): " CERT
echo
printf %s "$APPID" | firebase functions:secrets:set AGORA_APP_ID --data-file -
printf %s "$CERT" | firebase functions:secrets:set AGORA_APP_CERT --data-file -

[ -f functions/.env ] || cp functions/.env.example functions/.env

echo "• تثبيت حزم الخادم..."
(cd functions && npm install)

echo "• النشر (قد يستغرق عدة دقائق، وقد يسألك عن تفعيل خدمات Google، اكتب Y)"
firebase deploy --only functions,firestore,hosting

echo
echo "تم النشر ✅"
echo "صفحة الخصوصية:      https://$PROJECT.web.app/privacy.html"
echo "صفحة حذف الحساب:    https://$PROJECT.web.app/delete-account.html"
