import 'package:flutter_test/flutter_test.dart';
import 'package:ousimdz/achievements.dart';
import 'package:ousimdz/format.dart';
import 'package:ousimdz/safety.dart';

void main() {
  group('format', () {
    test('fmtCount', () {
      expect(fmtCount(950), '950');
      expect(fmtCount(1500), '1.5K');
      expect(fmtCount(2500000), '2.5M');
    });

    test('مستويات الخبرة تطابق معادلة الخادم', () {
      expect(xpForLevel(1), 0);
      expect(xpForLevel(2), 100);
      expect(xpForLevel(3), 400);
      expect(levelProgress(50, 1), 0.5);
      expect(levelProgress(400, 2), 1.0);
    });
  });

  group('safety', () {
    test('يمنع الروابط وأرقام الهواتف', () {
      expect(unsafeReason('زوروا www.example.com'), isNotNull);
      expect(unsafeReason('https://evil.site/app.apk'), isNotNull);
      expect(unsafeReason('كلمني على 0555123456'), isNotNull);
      expect(unsafeReason('t.me/somegroup'), isNotNull);
    });

    test('يسمح بالكلام العادي', () {
      expect(unsafeReason('مرحبا كيف حالكم؟'), isNull);
      expect(unsafeReason('عندي 3 قطط و 12 سمكة'), isNull);
    });
  });

  group('achievements', () {
    test('المعرّفات فريدة', () {
      final ids = achievementCatalog.map((a) => a.id).toList();
      expect(ids.toSet().length, ids.length);
    });
  });
}
