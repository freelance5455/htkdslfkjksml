const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentWritten, onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const logger = require("firebase-functions/logger");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");
const { RtcTokenBuilder, RtcRole } = require("agora-token");

admin.initializeApp();
const REGION = "europe-west1";
const db = () => admin.firestore();

// فعّل التحقق من التطبيق بوضع ENFORCE_APPCHECK=true في functions/.env
// (يعمل فقط للتطبيق المنشور على Google Play، فلا تفعّله لملف APK مباشر).
const CALL = { region: REGION, enforceAppCheck: process.env.ENFORCE_APPCHECK === "true" };

// حدّ الطلبات لكل مستخدم: يمنع الإغراق والتجريب الآلي.
// الإيقاف العام من الإدارة
async function assertNotGloballyBanned(uid) {
  const b = await db().doc(`globalBans/${uid}`).get();
  if (b.exists && (b.get("permanent") || (b.get("until") && b.get("until").toMillis() > Date.now()))) {
    throw new HttpsError("permission-denied", "حسابك موقوف من الإدارة.");
  }
}

async function assertAdmin(uid) {
  const a = await db().doc(`admins/${uid}`).get();
  if (!a.exists) throw new HttpsError("permission-denied", "هذه الصلاحية للإدارة فقط");
}

async function rateLimit(uid, key, max, windowSec) {
  const ref = db().doc(`rateLimits/${uid}__${key}`);
  await db().runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const now = Date.now();
    const d = snap.exists ? snap.data() : null;
    if (d && now - d.windowStart < windowSec * 1000) {
      if (d.count >= max) {
        throw new HttpsError("resource-exhausted", "طلبات كثيرة. انتظر قليلًا ثم حاول مجددًا.");
      }
      tx.update(ref, { count: d.count + 1 });
    } else {
      tx.set(ref, { count: 1, windowStart: now });
    }
  });
}

const APP_ID = defineSecret("AGORA_APP_ID");
const APP_CERT = defineSecret("AGORA_APP_CERT");

const clearSeat = {
  userId: null,
  name: null,
  photo: null,
  agoraUid: null,
};

async function releaseSeats(roomRef, uid) {
  const seats = await roomRef.collection("seats").where("userId", "==", uid).get();
  await Promise.all(seats.docs.map((d) => d.ref.update(clearSeat)));
}

// ---------------------------------------------------------------
// توكن الصوت (يرفض المحظورين)
// ---------------------------------------------------------------
exports.agoraToken = onCall(
  { ...CALL, secrets: [APP_ID, APP_CERT] },
  async (req) => {
    if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
    const roomId = req.data && req.data.roomId;
    if (typeof roomId !== "string" || !roomId) {
      throw new HttpsError("invalid-argument", "roomId مطلوب");
    }

    const roomRef = db().doc(`rooms/${roomId}`);
    const [room, user, restr] = await Promise.all([
      roomRef.get(),
      db().doc(`users/${req.auth.uid}`).get(),
      roomRef.collection("restrictions").doc(req.auth.uid).get(),
    ]);
    if (!room.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");
    await assertNotGloballyBanned(req.auth.uid);
    if (room.get("hasPassword") && room.get("ownerId") !== req.auth.uid) {
      const allowed = await roomRef.collection("allowed").doc(req.auth.uid).get();
      if (!allowed.exists) throw new HttpsError("permission-denied", "هذه غرفة خاصة بكلمة مرور");
    }

    const banUntil = restr.exists ? restr.get("banUntil") : null;
    if (banUntil && banUntil.toMillis() > Date.now()) {
      throw new HttpsError("permission-denied", "أنت محظور من هذه الغرفة حاليًا");
    }

    const uid = user.get("agoraUid");
    if (!uid) throw new HttpsError("failed-precondition", "الملف الشخصي غير مكتمل");

    const ttl = 3600;
    const token = RtcTokenBuilder.buildTokenWithUid(
      APP_ID.value(), APP_CERT.value(), roomId, uid, RtcRole.PUBLISHER, ttl, ttl
    );
    return { token, appId: APP_ID.value(), uid };
  }
);

// ---------------------------------------------------------------
// الإشراف: كتم، إنزال، طرد، قفل مقعد، تعيين مشرف
// ---------------------------------------------------------------
exports.moderate = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  await rateLimit(req.auth.uid, "mod", 30, 60);

  const { roomId, action, targetUid, seatIndex } = req.data || {};
  if (typeof roomId !== "string" || !roomId || typeof action !== "string") {
    throw new HttpsError("invalid-argument", "طلب غير صالح");
  }

  const roomRef = db().doc(`rooms/${roomId}`);
  const roomSnap = await roomRef.get();
  if (!roomSnap.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");

  const room = roomSnap.data();
  const caller = req.auth.uid;
  const admins = room.admins || [];
  const isOwner = room.ownerId === caller;
  const isAdmin = admins.includes(caller);
  if (!isOwner && !isAdmin) {
    throw new HttpsError("permission-denied", "ليست لديك صلاحية الإشراف");
  }

  const checkTarget = (uid) => {
    if (typeof uid !== "string" || !uid) {
      throw new HttpsError("invalid-argument", "المستخدم المستهدف مطلوب");
    }
    if (uid === caller) {
      throw new HttpsError("invalid-argument", "لا يمكنك تنفيذ هذا الإجراء على نفسك");
    }
    if (uid === room.ownerId) {
      throw new HttpsError("permission-denied", "لا يمكن تنفيذ إجراء على صاحب الغرفة");
    }
    if (!isOwner && admins.includes(uid)) {
      throw new HttpsError("permission-denied", "المشرف لا يستطيع التصرف على مشرف آخر");
    }
  };
  const restrRef = (uid) => roomRef.collection("restrictions").doc(uid);

  switch (action) {
    case "kickSeat":
      checkTarget(targetUid);
      await releaseSeats(roomRef, targetUid);
      break;

    case "mute":
    case "unmute":
      checkTarget(targetUid);
      await restrRef(targetUid).set({ muted: action === "mute" }, { merge: true });
      break;

    case "ban": {
      checkTarget(targetUid);
      const minutes = Math.min(Math.max(Number(req.data.minutes) || 60, 1), 1440);
      await restrRef(targetUid).set(
        { banUntil: admin.firestore.Timestamp.fromMillis(Date.now() + minutes * 60000) },
        { merge: true }
      );
      // حذف وثيقة العضو يطلق دالة تحرير المقعد وتحديث العدّاد
      await roomRef.collection("members").doc(targetUid).delete();
      break;
    }

    case "unban":
      checkTarget(targetUid);
      await restrRef(targetUid).set(
        { banUntil: admin.firestore.FieldValue.delete() },
        { merge: true }
      );
      break;

    case "lockSeat":
    case "unlockSeat": {
      const i = Number(seatIndex);
      if (!Number.isInteger(i) || i < 1 || i > 12) {
        throw new HttpsError("invalid-argument", "رقم المقعد غير صالح");
      }
      const ref = roomRef.collection("seats").doc(String(i));
      const seat = await ref.get();
      if (!seat.exists) throw new HttpsError("not-found", "المقعد غير موجود");
      if (action === "lockSeat") {
        const occupant = seat.get("userId");
        if (occupant && occupant !== caller) checkTarget(occupant);
        await ref.update({ locked: true, ...clearSeat });
      } else {
        await ref.update({ locked: false });
      }
      break;
    }

    case "setAdmin": {
      if (!isOwner) {
        throw new HttpsError("permission-denied", "تعيين المشرفين لصاحب الغرفة فقط");
      }
      checkTarget(targetUid);
      await roomRef.update({
        admins: req.data.value
          ? admin.firestore.FieldValue.arrayUnion(targetUid)
          : admin.firestore.FieldValue.arrayRemove(targetUid),
      });
      if (req.data.value) {
        await db().collection(`users/${targetUid}/notifications`).add({
          type: "admin",
          title: "تمت ترقيتك",
          body: `عيّنك صاحب الغرفة "${room.name}" مشرفًا`,
          read: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      }
      break;
    }

    default:
      throw new HttpsError("invalid-argument", "إجراء غير معروف");
  }
  return { ok: true };
});

// ---------------------------------------------------------------
// الحضور: عدّاد المتواجدين وتحرير المقعد عند الخروج أو الانقطاع
// ---------------------------------------------------------------
exports.onMemberChange = onDocumentWritten(
  { document: "rooms/{roomId}/members/{uid}", region: REGION },
  async (event) => {
    const { roomId, uid } = event.params;
    const roomRef = db().doc(`rooms/${roomId}`);
    const room = await roomRef.get();
    if (!room.exists) return;

    // تحديث lastSeen لا يغيّر العدد، فلا داعي لإعادة الحساب
    const before = event.data.before.exists;
    const after = event.data.after.exists;
    if (before && after) return;

    const agg = await roomRef.collection("members").count().get();
    await roomRef.update({ memberCount: agg.data().count });
    if (!after) await releaseSeats(roomRef, uid);
  }
);

// من لم يرسل نبضة منذ 90 ثانية يُعتبر خارج الغرفة
exports.cleanStaleMembers = onSchedule(
  { schedule: "every 1 minutes", region: REGION },
  async () => {
    const cutoff = admin.firestore.Timestamp.fromMillis(Date.now() - 90 * 1000);
    const stale = await db()
      .collectionGroup("members")
      .where("lastSeen", "<", cutoff)
      .limit(200)
      .get();
    await Promise.all(stale.docs.map((d) => d.ref.delete()));
  }
);

// ---------------------------------------------------------------
// الاقتصاد: الملف الشخصي، الهدية اليومية، إرسال الهدايا
// كل الأرصدة تُعدَّل من هنا فقط. قواعد Firestore تمنع التطبيق من لمسها.
// ---------------------------------------------------------------
const START_COINS = 100;
const DAILY_COINS = 50;
const DAILY_XP = 10;
const DAILY_COOLDOWN_MS = 20 * 3600 * 1000;

// يجب أن تطابق lib/gifts.dart
const GIFTS = {
  rose: { name: "وردة", emoji: "🌹", price: 10 },
  heart: { name: "قلب", emoji: "❤️", price: 20 },
  coffee: { name: "قهوة", emoji: "☕", price: 30 },
  crown: { name: "تاج", emoji: "👑", price: 200 },
  rocket: { name: "صاروخ", emoji: "🚀", price: 500 },
  car: { name: "سيارة سباق", emoji: "🏎️", price: 800 },
  castle: { name: "قلعة", emoji: "🏰", price: 1500 },
  lion: { name: "أسد", emoji: "🦁", price: 3000 },
};

// المستوى = floor(sqrt(xp / 100)) + 1  (يطابق lib/format.dart)
const levelOf = (xp) => Math.min(100, Math.floor(Math.sqrt(xp / 100)) + 1);
const newAgoraUid = () => crypto.randomInt(1, 2000000000);

exports.ensureProfile = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await assertNotGloballyBanned(uid);
  const userRef = db().doc(`users/${uid}`);
  const walletRef = db().doc(`wallets/${uid}`);
  const now = admin.firestore.FieldValue.serverTimestamp();

  await db().runTransaction(async (tx) => {
    const [u, w] = await Promise.all([tx.get(userRef), tx.get(walletRef)]);
    if (!u.exists) {
      tx.set(userRef, {
        name: req.auth.token.name || "مستخدم",
        photo: req.auth.token.picture || null,
        level: 1,
        xp: 0,
        charm: 0,
        agoraUid: newAgoraUid(),
        createdAt: now,
      });
    } else {
      // ترقية حسابات المرحلتين 1 و2
      const d = u.data();
      const patch = {};
      if (d.xp === undefined) patch.xp = 0;
      if (d.charm === undefined) patch.charm = 0;
      if (d.level === undefined) patch.level = 1;
      if (!d.agoraUid) patch.agoraUid = newAgoraUid();
      if (Object.keys(patch).length) tx.update(userRef, patch);
    }
    if (!w.exists) tx.set(walletRef, { coins: START_COINS, createdAt: now });
  });
  return { ok: true };
});

exports.claimDaily = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  await rateLimit(req.auth.uid, "daily", 5, 60);
  const uid = req.auth.uid;
  const userRef = db().doc(`users/${uid}`);
  const walletRef = db().doc(`wallets/${uid}`);

  await db().runTransaction(async (tx) => {
    const [u, w] = await Promise.all([tx.get(userRef), tx.get(walletRef)]);
    if (!u.exists) throw new HttpsError("failed-precondition", "الملف الشخصي غير مكتمل");
    const last = w.exists ? w.get("lastDaily") : null;
    if (last && Date.now() - last.toMillis() < DAILY_COOLDOWN_MS) {
      throw new HttpsError("failed-precondition", "استلمت هديتك اليومية. عد لاحقًا.");
    }
    const xp = (u.get("xp") || 0) + DAILY_XP;
    tx.set(
      walletRef,
      {
        coins: admin.firestore.FieldValue.increment(DAILY_COINS),
        lastDaily: admin.firestore.Timestamp.now(),
      },
      { merge: true }
    );
    tx.update(userRef, { xp, level: levelOf(xp), "stats.dailyClaims": admin.firestore.FieldValue.increment(1) });
  });
  return { coins: DAILY_COINS };
});

exports.sendGift = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  await rateLimit(req.auth.uid, "gift", 30, 60);
  await assertNotGloballyBanned(req.auth.uid);
  const caller = req.auth.uid;
  const { roomId, giftId, targetUid } = req.data || {};

  const gift = GIFTS[giftId];
  if (!gift) throw new HttpsError("invalid-argument", "هدية غير معروفة");
  if (typeof roomId !== "string" || !roomId) {
    throw new HttpsError("invalid-argument", "الغرفة مطلوبة");
  }
  if (typeof targetUid !== "string" || !targetUid || targetUid === caller) {
    throw new HttpsError("invalid-argument", "اختر شخصًا آخر لتهديه");
  }
  const qty = Math.min(Math.max(Math.floor(Number(req.data.qty) || 1), 1), 99);
  const total = gift.price * qty;

  const roomRef = db().doc(`rooms/${roomId}`);
  const senderRef = db().doc(`users/${caller}`);
  const walletRef = db().doc(`wallets/${caller}`);
  const targetRef = db().doc(`users/${targetUid}`);
  const now = admin.firestore.FieldValue.serverTimestamp();
  const inc = admin.firestore.FieldValue.increment;

  const result = await db().runTransaction(async (tx) => {
    const [room, senderMember, targetMember, sender, wallet, target] = await Promise.all([
      tx.get(roomRef),
      tx.get(roomRef.collection("members").doc(caller)),
      tx.get(roomRef.collection("members").doc(targetUid)),
      tx.get(senderRef),
      tx.get(walletRef),
      tx.get(targetRef),
    ]);
    if (!room.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");
    if (!senderMember.exists) throw new HttpsError("failed-precondition", "يجب أن تكون داخل الغرفة");
    if (!targetMember.exists) throw new HttpsError("failed-precondition", "هذا الشخص غادر الغرفة");
    if (!sender.exists || !target.exists) throw new HttpsError("not-found", "المستخدم غير موجود");

    const coins = wallet.exists ? wallet.get("coins") || 0 : 0;
    if (coins < total) throw new HttpsError("failed-precondition", "رصيدك غير كافٍ");

    const xp = (sender.get("xp") || 0) + total;
    const level = levelOf(xp);
    const fromName = sender.get("name") || "مستخدم";
    const toName = target.get("name") || "مستخدم";

    tx.update(walletRef, { coins: inc(-total) });
    tx.update(senderRef, { xp, level, "stats.giftsSent": inc(qty), "stats.coinsSpent": inc(total) });
    tx.update(targetRef, { charm: inc(total), "stats.giftsReceived": inc(qty) });
    tx.update(roomRef, { points: inc(total) });

    tx.set(roomRef.collection("gifts").doc(), {
      giftId,
      qty,
      total,
      fromUid: caller,
      fromName,
      fromPhoto: sender.get("photo") || null,
      toUid: targetUid,
      toName,
      createdAt: now,
    });
    tx.set(roomRef.collection("messages").doc(), {
      type: "system",
      uid: caller,
      name: fromName,
      level,
      text: `${gift.emoji} ${fromName} أهدى ${toName} ${gift.name}${qty > 1 ? ` ×${qty}` : ""}`,
      createdAt: now,
    });
    tx.set(db().collection(`users/${targetUid}/notifications`).doc(), {
      type: "gift",
      title: "وصلتك هدية",
      body: `${fromName} أهداك ${gift.emoji} ${gift.name}${qty > 1 ? ` ×${qty}` : ""}`,
      read: false,
      createdAt: now,
    });
    return { coins: coins - total, level, gid: sender.get("groupId") || null };
  });
  if (result.gid) {
    await db()
      .doc(`groups/${result.gid}`)
      .update({ points: admin.firestore.FieldValue.increment(total) })
      .catch(() => {});
  }
  return { coins: result.coins, level: result.level };
});

// ---------------------------------------------------------------
// الألعاب
// ---------------------------------------------------------------
const TRIVIA_SECONDS = 20;
const TRIVIA_REWARD = 20;
const TRIVIA_XP = 5;
const TRIVIA_DAILY_CAP = 200; // أقصى عملات يكسبها اللاعب يوميًا من الأسئلة

// [نص السؤال، الخيارات، رقم الإجابة الصحيحة]
const TRIVIA = [
  { q: "ما عاصمة الجزائر؟", o: ["الجزائر العاصمة", "وهران", "قسنطينة", "عنابة"], a: 0 },
  { q: "ما أكبر كوكب في المجموعة الشمسية؟", o: ["زحل", "المشتري", "نبتون", "الأرض"], a: 1 },
  { q: "كم يومًا في السنة الكبيسة؟", o: ["365", "364", "366", "367"], a: 2 },
  { q: "ما أطول نهر في أفريقيا؟", o: ["النيل", "الكونغو", "النيجر", "زامبيزي"], a: 0 },
  { q: "في أي عام استقلت الجزائر؟", o: ["1954", "1962", "1958", "1965"], a: 1 },
  { q: "ما عاصمة اليابان؟", o: ["أوساكا", "كيوتو", "طوكيو", "ناغويا"], a: 2 },
  { q: "كم لاعبًا في فريق كرة القدم داخل الملعب؟", o: ["9", "10", "11", "12"], a: 2 },
  { q: "ما الغاز الذي يحتاجه الإنسان ليتنفس؟", o: ["الأكسجين", "النيتروجين", "الهيدروجين", "الهيليوم"], a: 0 },
  { q: "ما أكبر محيط في العالم؟", o: ["الأطلسي", "الهندي", "المتجمد الشمالي", "الهادئ"], a: 3 },
  { q: "كم عدد القارات حسب التقسيم الأشهر؟", o: ["5", "6", "7", "8"], a: 2 },
  { q: "ما أسرع حيوان بري؟", o: ["الأسد", "الفهد", "الحصان", "النمر"], a: 1 },
  { q: "ما عاصمة مصر؟", o: ["الإسكندرية", "القاهرة", "الجيزة", "أسوان"], a: 1 },
  { q: "ما أكبر دولة في العالم مساحة؟", o: ["الصين", "كندا", "روسيا", "الولايات المتحدة"], a: 2 },
  { q: "كم يساوي 12 × 12؟", o: ["124", "144", "134", "154"], a: 1 },
  { q: "ما أصغر عدد أولي؟", o: ["0", "1", "2", "3"], a: 2 },
  { q: "أي كوكب يُعرف بالكوكب الأحمر؟", o: ["المريخ", "الزهرة", "عطارد", "أورانوس"], a: 0 },
  { q: "ما اللغة الرسمية في البرازيل؟", o: ["الإسبانية", "البرتغالية", "الإنجليزية", "الفرنسية"], a: 1 },
  { q: "كم شهرًا في السنة الهجرية؟", o: ["10", "11", "12", "13"], a: 2 },
  { q: "ما أعلى جبل في العالم؟", o: ["كليمنجارو", "إيفرست", "مون بلان", "الأطلس"], a: 1 },
  { q: "ما العملة الرسمية في الجزائر؟", o: ["الدينار", "الدرهم", "الريال", "الجنيه"], a: 0 },
  { q: "ما أكبر عضو في جسم الإنسان؟", o: ["الكبد", "الجلد", "الرئتان", "القلب"], a: 1 },
  { q: "كم ضلعًا للمسدس؟", o: ["5", "6", "7", "8"], a: 1 },
  { q: "ما عاصمة المغرب؟", o: ["الدار البيضاء", "مراكش", "الرباط", "فاس"], a: 2 },
  { q: "ما أصغر قارة مساحة؟", o: ["أوروبا", "أستراليا", "أنتاركتيكا", "أمريكا الجنوبية"], a: 1 },
  { q: "ما أكبر صحراء حارة في العالم؟", o: ["الربع الخالي", "الصحراء الكبرى", "غوبي", "كالاهاري"], a: 1 },
  { q: "في أي دولة يقع برج إيفل؟", o: ["إيطاليا", "إسبانيا", "فرنسا", "ألمانيا"], a: 2 },
  { q: "كم ثانية في الدقيقة؟", o: ["30", "60", "100", "120"], a: 1 },
  { q: "أي حيوان يلقّب بسفينة الصحراء؟", o: ["الحصان", "الجمل", "الفيل", "الحمار"], a: 1 },
  { q: "ما عاصمة تونس؟", o: ["صفاقس", "سوسة", "تونس", "القيروان"], a: 2 },
  { q: "ما ناتج 7 × 8؟", o: ["54", "56", "58", "64"], a: 1 },
];

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const isStaff = (room, uid) => room.ownerId === uid || (room.admins || []).includes(uid);

exports.startTrivia = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "trivia-start", 6, 60);

  const roomId = req.data && req.data.roomId;
  if (typeof roomId !== "string" || !roomId) throw new HttpsError("invalid-argument", "الغرفة مطلوبة");
  const roomRef = db().doc(`rooms/${roomId}`);
  const room = await roomRef.get();
  if (!room.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");
  if (!isStaff(room.data(), uid)) {
    throw new HttpsError("permission-denied", "بدء الجولات لصاحب الغرفة والمشرفين فقط");
  }

  const gameRef = roomRef.collection("games").doc("current");
  const secretRef = roomRef.collection("gameSecrets").doc("current");
  await db().runTransaction(async (tx) => {
    const [g, s] = await Promise.all([tx.get(gameRef), tx.get(secretRef)]);
    if (g.exists && g.get("status") === "open" && g.get("endsAtMs") > Date.now()) {
      throw new HttpsError("failed-precondition", "هناك سؤال جارٍ الآن.");
    }
    const last = s.exists ? s.get("lastQ") : -1;
    let qi;
    do {
      qi = crypto.randomInt(0, TRIVIA.length);
    } while (qi === last);
    const q = TRIVIA[qi];
    const order = shuffle([0, 1, 2, 3]);
    tx.set(gameRef, {
      round: crypto.randomUUID(),
      type: "trivia",
      status: "open",
      question: q.q,
      options: order.map((i) => q.o[i]),
      durationSec: TRIVIA_SECONDS,
      endsAtMs: Date.now() + (TRIVIA_SECONDS + 3) * 1000, // مهلة بسيطة للشبكة
      startedBy: uid,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    tx.set(secretRef, { answer: order.indexOf(q.a), lastQ: qi });
  });
  return { ok: true };
});

exports.answerTrivia = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "trivia-answer", 20, 60);

  const { roomId } = req.data || {};
  const choice = Number(req.data && req.data.choice);
  if (typeof roomId !== "string" || !roomId || !Number.isInteger(choice) || choice < 0 || choice > 3) {
    throw new HttpsError("invalid-argument", "طلب غير صالح");
  }

  const roomRef = db().doc(`rooms/${roomId}`);
  const gameRef = roomRef.collection("games").doc("current");
  const secretRef = roomRef.collection("gameSecrets").doc("current");
  const walletRef = db().doc(`wallets/${uid}`);
  const userRef = db().doc(`users/${uid}`);
  const now = admin.firestore.FieldValue.serverTimestamp();
  const inc = admin.firestore.FieldValue.increment;

  return db().runTransaction(async (tx) => {
    const game = await tx.get(gameRef);
    if (!game.exists || game.get("status") !== "open") {
      throw new HttpsError("failed-precondition", "انتهت الجولة.");
    }
    if (Date.now() > game.get("endsAtMs")) {
      throw new HttpsError("failed-precondition", "انتهى الوقت.");
    }
    const ansRef = roomRef.collection("gameAnswers").doc(`${game.get("round")}_${uid}`);
    const [secret, ans, member, user, wallet] = await Promise.all([
      tx.get(secretRef),
      tx.get(ansRef),
      tx.get(roomRef.collection("members").doc(uid)),
      tx.get(userRef),
      tx.get(walletRef),
    ]);
    if (!member.exists) throw new HttpsError("failed-precondition", "يجب أن تكون داخل الغرفة");
    if (ans.exists) throw new HttpsError("failed-precondition", "أجبت على هذا السؤال من قبل.");

    const correctIdx = secret.get("answer");
    const correct = choice === correctIdx;
    tx.set(ansRef, { choice, correct, createdAt: now });
    if (!correct) return { correct: false, won: false, reward: 0 };

    // أول إجابة صحيحة تفوز وتغلق الجولة
    const day = new Date().toISOString().slice(0, 10);
    const earned = wallet.get("triviaDay") === day ? wallet.get("triviaToday") || 0 : 0;
    const reward = earned + TRIVIA_REWARD <= TRIVIA_DAILY_CAP ? TRIVIA_REWARD : 0;
    const xp = (user.get("xp") || 0) + TRIVIA_XP;
    const level = levelOf(xp);
    const name = user.get("name") || "مستخدم";

    tx.update(gameRef, { status: "done", winnerUid: uid, winnerName: name, answer: correctIdx });
    tx.set(walletRef, { coins: inc(reward), triviaDay: day, triviaToday: earned + reward }, { merge: true });
    tx.update(userRef, { xp, level, "stats.triviaWins": inc(1) });
    tx.set(roomRef.collection("messages").doc(), {
      type: "system",
      uid,
      name,
      level,
      text: reward > 0 ? `🏆 ${name} أجاب أولًا وربح ${reward} عملة` : `🏆 ${name} أجاب أولًا`,
      createdAt: now,
    });
    return { correct: true, won: true, reward };
  });
});

// عجلة الحظ المجانية: لا رهان ولا شراء. دورة واحدة كل يوم لكل مستخدم.
const WHEEL_PRIZES = [5, 10, 15, 20, 30, 50, 80, 150]; // تطابق lib/widgets/lucky_wheel.dart
const WHEEL_WEIGHTS = [30, 25, 15, 12, 8, 6, 3, 1]; // المجموع 100

exports.spinWheel = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "wheel", 5, 60);

  const walletRef = db().doc(`wallets/${uid}`);
  const userRef = db().doc(`users/${uid}`);
  return db().runTransaction(async (tx) => {
    const [w, u] = await Promise.all([tx.get(walletRef), tx.get(userRef)]);
    if (!u.exists) throw new HttpsError("failed-precondition", "الملف الشخصي غير مكتمل");
    const last = w.exists ? w.get("lastSpin") : null;
    if (last && Date.now() - last.toMillis() < DAILY_COOLDOWN_MS) {
      throw new HttpsError("failed-precondition", "دُرتَ العجلة اليوم. عد لاحقًا.");
    }
    let r = crypto.randomInt(0, 100);
    let index = 0;
    for (let i = 0; i < WHEEL_WEIGHTS.length; i++) {
      if (r < WHEEL_WEIGHTS[i]) { index = i; break; }
      r -= WHEEL_WEIGHTS[i];
    }
    const coins = WHEEL_PRIZES[index];
    const xp = (u.get("xp") || 0) + 5;
    tx.set(
      walletRef,
      { coins: admin.firestore.FieldValue.increment(coins), lastSpin: admin.firestore.Timestamp.now() },
      { merge: true }
    );
    tx.update(userRef, { xp, level: levelOf(xp), "stats.wheelSpins": admin.firestore.FieldValue.increment(1) });
    return { index, coins };
  });
});

// ---------------------------------------------------------------
// البلاغات: تُحفظ للمراجعة في مجموعة reports من لوحة Firebase
// ---------------------------------------------------------------
const REPORT_REASONS = ["spam", "abuse", "inappropriate", "scam"];

exports.reportUser = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "report", 5, 300);
  const { roomId, targetUid, reason } = req.data || {};
  if (typeof roomId !== "string" || typeof targetUid !== "string" || !REPORT_REASONS.includes(reason)) {
    throw new HttpsError("invalid-argument", "بلاغ غير صالح");
  }
  if (targetUid === uid) throw new HttpsError("invalid-argument", "لا يمكنك الإبلاغ عن نفسك");
  const [rep, tgt, msgs] = await Promise.all([
    db().doc(`users/${uid}`).get(),
    db().doc(`users/${targetUid}`).get(),
    db().collection(`rooms/${roomId}/messages`).orderBy("createdAt", "desc").limit(50).get(),
  ]);
  // آخر رسائل المُبلَّغ عنه كدليل للمراجعة
  const evidence = msgs.docs
    .map((d) => d.data())
    .filter((m) => m.uid === targetUid && m.type !== "system")
    .slice(0, 5)
    .map((m) => String(m.text || "").slice(0, 200));
  await db().collection("reports").add({
    roomId,
    targetUid,
    targetName: tgt.exists ? tgt.get("name") || "مستخدم" : "مستخدم",
    reporterUid: uid,
    reporterName: rep.exists ? rep.get("name") || "مستخدم" : "مستخدم",
    reason,
    evidence,
    status: "new",
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return { ok: true };
});

// ---------------------------------------------------------------
// إشعارات خارجية (FCM) عند إنشاء إشعار داخل التطبيق
// ---------------------------------------------------------------
exports.pushOnNotification = onDocumentCreated(
  { document: "users/{uid}/notifications/{nid}", region: REGION },
  async (event) => {
    const n = event.data && event.data.data();
    if (!n) return;
    const dev = await db().doc(`devices/${event.params.uid}`).get();
    const tokens = (dev.exists && dev.get("tokens")) || [];
    if (!tokens.length) return;

    const res = await admin.messaging().sendEachForMulticast({
      tokens,
      notification: { title: n.title, body: n.body },
      android: { priority: "high" },
    });
    const dead = [];
    res.responses.forEach((r, i) => {
      const code = r.error && r.error.code;
      if (!r.success && (code === "messaging/registration-token-not-registered" ||
                         code === "messaging/invalid-registration-token")) {
        dead.push(tokens[i]);
      }
    });
    if (dead.length) {
      await dev.ref.update({ tokens: admin.firestore.FieldValue.arrayRemove(...dead) });
    }
  }
);

// ---------------------------------------------------------------
// الإنجازات والشارات: تُمنح تلقائيًا من الخادم عند تغيّر إحصائيات المستخدم
// ---------------------------------------------------------------
// يجب أن تطابق lib/achievements.dart
const ACHIEVEMENTS = [
  { id: "room_1", stat: "roomsCreated", target: 1, reward: 20, title: "صاحب البيت" },
  { id: "gift_1", stat: "giftsSent", target: 1, reward: 20, title: "المهدي الأول" },
  { id: "gift_50", stat: "giftsSent", target: 50, reward: 100, title: "كريم" },
  { id: "spender_1000", stat: "coinsSpent", target: 1000, reward: 150, title: "سخي" },
  { id: "loved_1", stat: "giftsReceived", target: 1, reward: 20, title: "محبوب" },
  { id: "loved_50", stat: "giftsReceived", target: 50, reward: 100, title: "نجم الغرفة" },
  { id: "level_5", stat: "level", target: 5, reward: 50, title: "مستوى 5" },
  { id: "level_10", stat: "level", target: 10, reward: 100, title: "مستوى 10" },
  { id: "level_25", stat: "level", target: 25, reward: 300, title: "مستوى 25" },
  { id: "trivia_1", stat: "triviaWins", target: 1, reward: 20, title: "الذكي" },
  { id: "trivia_10", stat: "triviaWins", target: 10, reward: 150, title: "العبقري" },
  { id: "wheel_7", stat: "wheelSpins", target: 7, reward: 50, title: "المثابر" },
  { id: "daily_7", stat: "dailyClaims", target: 7, reward: 70, title: "وفيّ" },
  { id: "daily_30", stat: "dailyClaims", target: 30, reward: 300, title: "لا ينقطع" },
];
const statOf = (u, stat) => (stat === "level" ? u.level || 1 : (u.stats || {})[stat] || 0);
const earnable = (u) => ACHIEVEMENTS.filter((a) => !(u.achievements || {})[a.id] && statOf(u, a.stat) >= a.target);

exports.onUserUpdated = onDocumentUpdated(
  { document: "users/{uid}", region: REGION },
  async (event) => {
    const after = event.data && event.data.after.data();
    if (!after || !earnable(after).length) return;
    const uid = event.params.uid;
    const userRef = db().doc(`users/${uid}`);
    const walletRef = db().doc(`wallets/${uid}`);
    await db().runTransaction(async (tx) => {
      const snap = await tx.get(userRef);
      const fresh = earnable(snap.data() || {});
      if (!fresh.length) return;
      const patch = {};
      let coins = 0;
      for (const a of fresh) {
        patch[`achievements.${a.id}`] = admin.firestore.Timestamp.now();
        coins += a.reward;
      }
      tx.update(userRef, patch);
      tx.set(walletRef, { coins: admin.firestore.FieldValue.increment(coins) }, { merge: true });
      for (const a of fresh) {
        tx.set(db().collection(`users/${uid}/notifications`).doc(), {
          type: "game",
          title: "إنجاز جديد 🏅",
          body: `${a.title}: +${a.reward} عملة`,
          read: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      }
    });
  }
);

exports.onRoomCreated = onDocumentCreated(
  { document: "rooms/{roomId}", region: REGION },
  async (event) => {
    const ownerId = event.data && event.data.get("ownerId");
    if (!ownerId) return;
    await db()
      .doc(`users/${ownerId}`)
      .update({ "stats.roomsCreated": admin.firestore.FieldValue.increment(1) })
      .catch(() => {});
  }
);

// ---------------------------------------------------------------
// المحادثات الخاصة
// ---------------------------------------------------------------
const LINK_RE = /(https?:\/\/|www\.|t\.me|wa\.me|bit\.ly|[a-z0-9-]+\.(com|net|org|io|me|co|ly|gl|xyz|app|dz|info|tk|ru|cc|tv|apk)\b)/i;
const PHONE_RE = /(?:[\d٠-٩][\s\-.]?){9,}/;

exports.sendDm = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "dm", 20, 60);
  await assertNotGloballyBanned(uid);

  const toUid = req.data && req.data.toUid;
  const text = typeof (req.data && req.data.text) === "string" ? req.data.text.trim() : "";
  if (typeof toUid !== "string" || !toUid || toUid === uid) {
    throw new HttpsError("invalid-argument", "مستلم غير صالح");
  }
  if (!text || text.length > 500) throw new HttpsError("invalid-argument", "الرسالة فارغة أو طويلة جدًا");
  if (LINK_RE.test(text) || PHONE_RE.test(text)) {
    throw new HttpsError("invalid-argument", "الروابط وأرقام الهواتف غير مسموحة.");
  }

  const [me, peer, blockedByPeer, blockedByMe, peerInbox] = await Promise.all([
    db().doc(`users/${uid}`).get(),
    db().doc(`users/${toUid}`).get(),
    db().doc(`users/${toUid}/blocked/${uid}`).get(),
    db().doc(`users/${uid}/blocked/${toUid}`).get(),
    db().doc(`users/${toUid}/inbox/${uid}`).get(),
  ]);
  if (!me.exists || !peer.exists) throw new HttpsError("not-found", "المستخدم غير موجود");
  if (blockedByMe.exists) throw new HttpsError("failed-precondition", "لقد حظرت هذا المستخدم. ألغِ الحظر لمراسلته.");
  if (blockedByPeer.exists) throw new HttpsError("failed-precondition", "لا يمكن إرسال الرسالة إلى هذا المستخدم.");

  const chatId = [uid, toUid].sort().join("_");
  const now = admin.firestore.FieldValue.serverTimestamp();
  const preview = text.slice(0, 80);
  const batch = db().batch();
  batch.set(db().collection(`chats/${chatId}/messages`).doc(), { from: uid, to: toUid, text, createdAt: now });
  batch.set(
    db().doc(`users/${uid}/inbox/${toUid}`),
    { peerName: peer.get("name") || "مستخدم", peerPhoto: peer.get("photo") || null, lastText: preview, lastAt: now, unread: 0 },
    { merge: true }
  );
  batch.set(
    db().doc(`users/${toUid}/inbox/${uid}`),
    {
      peerName: me.get("name") || "مستخدم",
      peerPhoto: me.get("photo") || null,
      lastText: preview,
      lastAt: now,
      unread: admin.firestore.FieldValue.increment(1),
    },
    { merge: true }
  );
  // إشعار واحد فقط عند بدء سلسلة رسائل غير مقروءة، حتى لا نغرق المستلم
  const unread = peerInbox.exists ? peerInbox.get("unread") || 0 : 0;
  if (unread === 0) {
    batch.set(db().collection(`users/${toUid}/notifications`).doc(), {
      type: "dm",
      title: `رسالة من ${me.get("name") || "مستخدم"}`,
      body: preview,
      read: false,
      createdAt: now,
    });
  }
  await batch.commit();
  return { ok: true };
});

// ---------------------------------------------------------------
// حذف الحساب (مطلوب في سياسات Google Play)
// ---------------------------------------------------------------
exports.deleteAccount = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "delete", 2, 3600);
  const d = db();

  await leaveGroupInternal(uid);

  // الغرف التي يملكها
  const rooms = await d.collection("rooms").where("ownerId", "==", uid).get();
  for (const r of rooms.docs) await d.recursiveDelete(r.ref);

  // المحادثات الخاصة (تُحذف من الطرفين) وصندوق الطرف الآخر
  const inbox = await d.collection(`users/${uid}/inbox`).get();
  for (const i of inbox.docs) {
    const chatId = [uid, i.id].sort().join("_");
    await d.recursiveDelete(d.doc(`chats/${chatId}`));
    await d.doc(`users/${i.id}/inbox/${uid}`).delete().catch(() => {});
  }

  // الملف (يشمل الإشعارات والصندوق وقائمة الحظر) والمحفظة والجهاز
  await d.recursiveDelete(d.doc(`users/${uid}`));
  await d.doc(`wallets/${uid}`).delete();
  await d.doc(`devices/${uid}`).delete();
  await d.recursiveDelete(d.doc(`rateLimits/${uid}__delete`)).catch(() => {});
  // سجلات الشراء والبلاغات تبقى للمحاسبة ومنع الاحتيال (مذكورة في سياسة الخصوصية)
  await admin.auth().deleteUser(uid);
  return { ok: true };
});

// ---------------------------------------------------------------
// الشراء بالمال الحقيقي عبر Google Play Billing
// ---------------------------------------------------------------
const PLAY_PACKAGE = process.env.PLAY_PACKAGE_NAME || "dz.ousim.ousimdz";
// يجب أن تطابق coinPacks في lib/services/purchase_service.dart
const COIN_PACKS = { coins_100: 100, coins_550: 550, coins_1200: 1200, coins_3000: 3000, coins_7000: 7000 };
const sha256 = (s) => crypto.createHash("sha256").update(s).digest("hex");

function playPublisher() {
  const { google } = require("googleapis");
  const auth = new google.auth.GoogleAuth({ scopes: ["https://www.googleapis.com/auth/androidpublisher"] });
  return google.androidpublisher({ version: "v3", auth });
}

exports.verifyPurchase = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "iap", 10, 60);

  const { productId, token } = req.data || {};
  const coins = COIN_PACKS[productId];
  if (!coins || typeof token !== "string" || token.length < 20) {
    throw new HttpsError("invalid-argument", "عملية شراء غير صالحة");
  }

  const purRef = db().doc(`purchases/${sha256(token)}`);
  const existing = await purRef.get();
  if (existing.exists) {
    if (existing.get("uid") !== uid) throw new HttpsError("permission-denied", "هذه العملية تخص حسابًا آخر");
    return { granted: false, already: true };
  }

  // التحقق لدى Google أن العملية حقيقية ومكتملة
  const publisher = playPublisher();
  let p;
  try {
    const res = await publisher.purchases.products.get({ packageName: PLAY_PACKAGE, productId, token });
    p = res.data;
  } catch (e) {
    logger.error("play verify failed", e && e.message);
    throw new HttpsError("failed-precondition", "تعذّر التحقق من عملية الشراء. حاول لاحقًا.");
  }
  if (p.purchaseState !== 0) throw new HttpsError("failed-precondition", "عملية الشراء غير مكتملة بعد");
  if (p.obfuscatedExternalAccountId !== uid) {
    throw new HttpsError("permission-denied", "هذه العملية لا تخص حسابك");
  }

  await db().runTransaction(async (tx) => {
    const again = await tx.get(purRef);
    if (again.exists) return;
    tx.set(purRef, {
      uid,
      productId,
      coins,
      orderId: p.orderId || null,
      test: p.purchaseType === 0,
      voided: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    tx.set(db().doc(`wallets/${uid}`), { coins: admin.firestore.FieldValue.increment(coins) }, { merge: true });
    tx.set(db().collection(`users/${uid}/notifications`).doc(), {
      type: "wallet",
      title: "تم شحن رصيدك",
      body: `أُضيفت ${coins} عملة إلى رصيدك`,
      read: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

  if (p.acknowledgementState === 0) {
    try {
      await publisher.purchases.products.acknowledge({ packageName: PLAY_PACKAGE, productId, token, requestBody: {} });
    } catch (e) {
      logger.warn("acknowledge failed (client will consume)", e && e.message);
    }
  }
  return { granted: true, coins };
});

// استرداد المشتريات الملغاة: يخصم العملات تلقائيًا (قد يصبح الرصيد سالبًا فيمنع الإنفاق)
exports.reconcileVoided = onSchedule({ schedule: "every 60 minutes", region: REGION }, async () => {
  try {
    const publisher = playPublisher();
    const res = await publisher.purchases.voidedpurchases.list({
      packageName: PLAY_PACKAGE,
      startTime: String(Date.now() - 3 * 24 * 3600 * 1000),
      maxResults: 100,
    });
    for (const v of res.data.voidedPurchases || []) {
      const ref = db().doc(`purchases/${sha256(v.purchaseToken)}`);
      await db().runTransaction(async (tx) => {
        const s = await tx.get(ref);
        if (!s.exists || s.get("voided")) return;
        const uid = s.get("uid");
        tx.update(ref, { voided: true, voidedAt: admin.firestore.FieldValue.serverTimestamp() });
        tx.set(db().doc(`wallets/${uid}`), { coins: admin.firestore.FieldValue.increment(-s.get("coins")) }, { merge: true });
        tx.set(db().collection(`users/${uid}/notifications`).doc(), {
          type: "wallet",
          title: "تم استرداد عملية شراء",
          body: "خُصمت العملات المرتبطة بالعملية المستردة",
          read: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      });
    }
  } catch (e) {
    logger.error("reconcileVoided failed", e && e.message);
  }
});

// ---------------------------------------------------------------
// الغرف الخاصة بكلمة مرور
// ---------------------------------------------------------------
const hashPassword = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString("hex");

exports.setRoomPassword = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "roompw", 10, 60);
  const roomId = req.data && req.data.roomId;
  const pw = typeof (req.data && req.data.password) === "string" ? req.data.password.trim() : "";
  if (typeof roomId !== "string" || !roomId) throw new HttpsError("invalid-argument", "الغرفة مطلوبة");
  if (pw && (pw.length < 4 || pw.length > 32)) {
    throw new HttpsError("invalid-argument", "كلمة المرور من 4 إلى 32 حرفًا");
  }

  const roomRef = db().doc(`rooms/${roomId}`);
  const room = await roomRef.get();
  if (!room.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");
  if (room.get("ownerId") !== uid) throw new HttpsError("permission-denied", "لصاحب الغرفة فقط");

  const secretRef = db().doc(`roomSecrets/${roomId}`);
  if (!pw) {
    await secretRef.delete();
    await roomRef.update({ hasPassword: false });
  } else {
    const salt = crypto.randomBytes(16).toString("hex");
    await secretRef.set({ salt, hash: hashPassword(pw, salt) });
    await roomRef.update({ hasPassword: true });
  }

  // تُلغى كل الأذونات السابقة، ويبقى الموجودون حاليًا في الغرفة مسموحًا لهم
  await db().recursiveDelete(roomRef.collection("allowed"));
  if (pw) {
    const members = await roomRef.collection("members").get();
    await Promise.all(
      members.docs.map((m) =>
        roomRef.collection("allowed").doc(m.id).set({ createdAt: admin.firestore.FieldValue.serverTimestamp() })
      )
    );
  }
  return { ok: true, hasPassword: !!pw };
});

exports.unlockRoom = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  const roomId = req.data && req.data.roomId;
  const pw = typeof (req.data && req.data.password) === "string" ? req.data.password.trim() : "";
  if (typeof roomId !== "string" || !roomId) throw new HttpsError("invalid-argument", "الغرفة مطلوبة");
  // 5 محاولات كل 5 دقائق لكل غرفة: يمنع تخمين كلمة المرور
  await rateLimit(uid, `pw_${roomId}`, 5, 300);
  await assertNotGloballyBanned(uid);

  const roomRef = db().doc(`rooms/${roomId}`);
  const room = await roomRef.get();
  if (!room.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");
  if (!room.get("hasPassword") || room.get("ownerId") === uid) return { ok: true };

  const [secret, restr] = await Promise.all([
    db().doc(`roomSecrets/${roomId}`).get(),
    roomRef.collection("restrictions").doc(uid).get(),
  ]);
  const banUntil = restr.exists ? restr.get("banUntil") : null;
  if (banUntil && banUntil.toMillis() > Date.now()) {
    throw new HttpsError("permission-denied", "أنت محظور من هذه الغرفة حاليًا");
  }
  if (!secret.exists) throw new HttpsError("failed-precondition", "الغرفة غير مهيأة");

  const expected = Buffer.from(secret.get("hash"), "hex");
  const given = Buffer.from(hashPassword(pw, secret.get("salt")), "hex");
  if (expected.length !== given.length || !crypto.timingSafeEqual(expected, given)) {
    throw new HttpsError("permission-denied", "كلمة المرور غير صحيحة");
  }
  await roomRef.collection("allowed").doc(uid).set({ createdAt: admin.firestore.FieldValue.serverTimestamp() });
  return { ok: true };
});

// ---------------------------------------------------------------
// المجموعات
// ---------------------------------------------------------------
const MAX_GROUP_MEMBERS = 50;
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // بدون أحرف متشابهة
const newCode = () => Array.from({ length: 6 }, () => CODE_ALPHABET[crypto.randomInt(0, CODE_ALPHABET.length)]).join("");

async function dissolveGroup(gid) {
  const gref = db().doc(`groups/${gid}`);
  const members = await gref.collection("members").get();
  await Promise.all(
    members.docs.map((m) =>
      db().doc(`users/${m.id}`).update({ groupId: admin.firestore.FieldValue.delete() }).catch(() => {})
    )
  );
  await db().doc(`groupCodes/${gid}`).delete().catch(() => {});
  await db().recursiveDelete(gref);
}

async function leaveGroupInternal(uid) {
  const userRef = db().doc(`users/${uid}`);
  const u = await userRef.get();
  const gid = u.exists && u.get("groupId");
  if (!gid) return;
  const gref = db().doc(`groups/${gid}`);
  const g = await gref.get();
  if (!g.exists) {
    await userRef.update({ groupId: admin.firestore.FieldValue.delete() });
    return;
  }
  if (g.get("ownerId") === uid) return dissolveGroup(gid);
  const batch = db().batch();
  batch.delete(gref.collection("members").doc(uid));
  batch.update(gref, { memberCount: admin.firestore.FieldValue.increment(-1) });
  batch.update(userRef, { groupId: admin.firestore.FieldValue.delete() });
  await batch.commit();
}

exports.createGroup = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "group", 5, 3600);
  await assertNotGloballyBanned(uid);
  const name = typeof (req.data && req.data.name) === "string" ? req.data.name.trim() : "";
  let emoji = typeof (req.data && req.data.emoji) === "string" ? req.data.emoji.trim() : "";
  if (name.length < 3 || name.length > 24) throw new HttpsError("invalid-argument", "اسم المجموعة من 3 إلى 24 حرفًا");
  if (LINK_RE.test(name) || PHONE_RE.test(name)) throw new HttpsError("invalid-argument", "الروابط وأرقام الهواتف غير مسموحة");
  if (!emoji || emoji.length > 8) emoji = "🛡️";

  const userRef = db().doc(`users/${uid}`);
  const user = await userRef.get();
  if (!user.exists) throw new HttpsError("failed-precondition", "الملف الشخصي غير مكتمل");
  if (user.get("groupId")) throw new HttpsError("failed-precondition", "أنت عضو في مجموعة بالفعل");

  let code = newCode();
  for (let i = 0; i < 5; i++) {
    const clash = await db().collection("groupCodes").where("code", "==", code).limit(1).get();
    if (clash.empty) break;
    code = newCode();
  }

  const gref = db().collection("groups").doc();
  const now = admin.firestore.FieldValue.serverTimestamp();
  const batch = db().batch();
  batch.set(gref, { name, emoji, ownerId: uid, memberCount: 1, points: 0, createdAt: now });
  batch.set(gref.collection("members").doc(uid), {
    name: user.get("name") || "مستخدم",
    photo: user.get("photo") || null,
    level: user.get("level") || 1,
    role: "owner",
    joinedAt: now,
  });
  batch.set(db().doc(`groupCodes/${gref.id}`), { code });
  batch.update(userRef, { groupId: gref.id });
  await batch.commit();
  return { groupId: gref.id, code };
});

exports.joinGroup = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "join-group", 10, 300);
  await assertNotGloballyBanned(uid);
  const code = typeof (req.data && req.data.code) === "string" ? req.data.code.trim().toUpperCase() : "";
  if (code.length !== 6) throw new HttpsError("invalid-argument", "الكود من 6 أحرف");

  const found = await db().collection("groupCodes").where("code", "==", code).limit(1).get();
  if (found.empty) throw new HttpsError("not-found", "كود الدعوة غير صحيح");
  const gid = found.docs[0].id;

  const userRef = db().doc(`users/${uid}`);
  const gref = db().doc(`groups/${gid}`);
  await db().runTransaction(async (tx) => {
    const [u, g] = await Promise.all([tx.get(userRef), tx.get(gref)]);
    if (!u.exists) throw new HttpsError("failed-precondition", "الملف الشخصي غير مكتمل");
    if (u.get("groupId")) throw new HttpsError("failed-precondition", "أنت عضو في مجموعة بالفعل");
    if (!g.exists) throw new HttpsError("not-found", "المجموعة غير موجودة");
    if ((g.get("memberCount") || 0) >= MAX_GROUP_MEMBERS) {
      throw new HttpsError("failed-precondition", "المجموعة مكتملة العدد");
    }
    tx.set(gref.collection("members").doc(uid), {
      name: u.get("name") || "مستخدم",
      photo: u.get("photo") || null,
      level: u.get("level") || 1,
      role: "member",
      joinedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    tx.update(gref, { memberCount: admin.firestore.FieldValue.increment(1) });
    tx.update(userRef, { groupId: gid });
  });
  return { groupId: gid };
});

exports.leaveGroup = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  await rateLimit(req.auth.uid, "leave-group", 10, 300);
  await leaveGroupInternal(req.auth.uid);
  return { ok: true };
});

exports.kickGroupMember = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "kick-group", 20, 60);
  const target = req.data && req.data.targetUid;
  if (typeof target !== "string" || !target || target === uid) throw new HttpsError("invalid-argument", "مستخدم غير صالح");
  const me = await db().doc(`users/${uid}`).get();
  const gid = me.exists && me.get("groupId");
  if (!gid) throw new HttpsError("failed-precondition", "لست في مجموعة");
  const gref = db().doc(`groups/${gid}`);
  const g = await gref.get();
  if (!g.exists || g.get("ownerId") !== uid) throw new HttpsError("permission-denied", "لمالك المجموعة فقط");
  const member = await gref.collection("members").doc(target).get();
  if (!member.exists) throw new HttpsError("not-found", "ليس عضوًا في المجموعة");
  const batch = db().batch();
  batch.delete(member.ref);
  batch.update(gref, { memberCount: admin.firestore.FieldValue.increment(-1) });
  batch.update(db().doc(`users/${target}`), { groupId: admin.firestore.FieldValue.delete() });
  await batch.commit();
  return { ok: true };
});

// ---------------------------------------------------------------
// جدولة الأحداث
// ---------------------------------------------------------------
exports.createEvent = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "event", 5, 300);
  await assertNotGloballyBanned(uid);
  const { roomId } = req.data || {};
  const title = typeof (req.data && req.data.title) === "string" ? req.data.title.trim() : "";
  const description = typeof (req.data && req.data.description) === "string" ? req.data.description.trim() : "";
  const start = Number(req.data && req.data.startsAtMs);
  if (typeof roomId !== "string" || !roomId) throw new HttpsError("invalid-argument", "الغرفة مطلوبة");
  if (title.length < 3 || title.length > 50 || description.length > 200) {
    throw new HttpsError("invalid-argument", "العنوان من 3 إلى 50 حرفًا والوصف حتى 200");
  }
  if (LINK_RE.test(title + " " + description) || PHONE_RE.test(title + " " + description)) {
    throw new HttpsError("invalid-argument", "الروابط وأرقام الهواتف غير مسموحة");
  }
  const now = Date.now();
  if (!Number.isFinite(start) || start < now + 5 * 60 * 1000 || start > now + 30 * 24 * 3600 * 1000) {
    throw new HttpsError("invalid-argument", "اختر موعدًا بين 5 دقائق و30 يومًا من الآن");
  }

  const room = await db().doc(`rooms/${roomId}`).get();
  if (!room.exists) throw new HttpsError("not-found", "الغرفة غير موجودة");
  if (!isStaff(room.data(), uid)) throw new HttpsError("permission-denied", "لصاحب الغرفة والمشرفين فقط");

  const existing = await db().collection("events").where("roomId", "==", roomId).limit(30).get();
  const upcoming = existing.docs.filter((d) => d.get("startsAt").toMillis() > now).length;
  if (upcoming >= 5) throw new HttpsError("failed-precondition", "الحد الأقصى 5 أحداث قادمة لكل غرفة");

  const host = await db().doc(`users/${uid}`).get();
  const ref = await db().collection("events").add({
    roomId,
    roomName: room.get("name"),
    title,
    description,
    startsAt: admin.firestore.Timestamp.fromMillis(start),
    hostId: uid,
    hostName: host.exists ? host.get("name") || "مستخدم" : "مستخدم",
    rsvpCount: 0,
    notified: false,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return { id: ref.id };
});

exports.deleteEvent = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await rateLimit(uid, "event-del", 20, 60);
  const eventId = req.data && req.data.eventId;
  if (typeof eventId !== "string" || !eventId) throw new HttpsError("invalid-argument", "حدث غير صالح");
  const ref = db().doc(`events/${eventId}`);
  const ev = await ref.get();
  if (!ev.exists) return { ok: true };
  const room = await db().doc(`rooms/${ev.get("roomId")}`).get();
  const isRoomOwner = room.exists && room.get("ownerId") === uid;
  if (ev.get("hostId") !== uid && !isRoomOwner) throw new HttpsError("permission-denied", "ليست لديك صلاحية");
  await db().recursiveDelete(ref);
  return { ok: true };
});

// عدّاد المهتمين
exports.onRsvpWrite = onDocumentWritten(
  { document: "events/{eid}/rsvps/{uid}", region: REGION },
  async (event) => {
    if (event.data.before.exists && event.data.after.exists) return;
    const ref = db().doc(`events/${event.params.eid}`);
    const snap = await ref.get();
    if (!snap.exists) return;
    const agg = await ref.collection("rsvps").count().get();
    await ref.update({ rsvpCount: agg.data().count });
  }
);

// كل 5 دقائق: تذكير بالأحداث التي ستبدأ خلال 10 دقائق، وتنظيف الأحداث القديمة
exports.eventReminders = onSchedule({ schedule: "every 5 minutes", region: REGION }, async () => {
  const now = Date.now();
  const soon = await db()
    .collection("events")
    .where("startsAt", "<=", admin.firestore.Timestamp.fromMillis(now + 10 * 60 * 1000))
    .where("startsAt", ">", admin.firestore.Timestamp.fromMillis(now - 60 * 60 * 1000))
    .get();
  for (const ev of soon.docs) {
    if (ev.get("notified")) continue;
    await ev.ref.update({ notified: true });
    const rsvps = await ev.ref.collection("rsvps").limit(400).get();
    const targets = new Set(rsvps.docs.map((r) => r.id));
    targets.add(ev.get("hostId"));
    const batch = db().batch();
    for (const uid of targets) {
      batch.set(db().collection(`users/${uid}/notifications`).doc(), {
        type: "game",
        title: "حدث يبدأ قريبًا ⏰",
        body: `${ev.get("title")} في غرفة ${ev.get("roomName")}`,
        read: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  }
  const old = await db()
    .collection("events")
    .where("startsAt", "<", admin.firestore.Timestamp.fromMillis(now - 24 * 3600 * 1000))
    .limit(50)
    .get();
  for (const ev of old.docs) await db().recursiveDelete(ev.ref);
});

// ---------------------------------------------------------------
// لوحة الإدارة: معالجة البلاغات
// ---------------------------------------------------------------
exports.adminAction = onCall(CALL, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid;
  await assertAdmin(uid);
  await rateLimit(uid, "admin", 60, 60);

  const { reportId, action } = req.data || {};
  const ACTIONS = ["dismiss", "warn", "ban1d", "ban7d", "banPerm", "unban"];
  if (typeof reportId !== "string" || !ACTIONS.includes(action)) throw new HttpsError("invalid-argument", "طلب غير صالح");

  const reportRef = db().doc(`reports/${reportId}`);
  const report = await reportRef.get();
  if (!report.exists) throw new HttpsError("not-found", "البلاغ غير موجود");
  const target = report.get("targetUid");
  if (target === uid) throw new HttpsError("invalid-argument", "لا يمكنك تنفيذ إجراء على نفسك");
  const isTargetAdmin = (await db().doc(`admins/${target}`).get()).exists;
  if (isTargetAdmin && action !== "dismiss") throw new HttpsError("permission-denied", "لا يمكن تنفيذ إجراء على مدير");

  const now = admin.firestore.FieldValue.serverTimestamp();
  const notify = (title, body) =>
    db().collection(`users/${target}/notifications`).add({ type: "game", title, body, read: false, createdAt: now });

  if (action === "warn") {
    await notify("تحذير من الإدارة ⚠️", "وصلنا بلاغ عن سلوكك. يرجى الالتزام بشروط الاستخدام وإلا يُوقف حسابك.");
  } else if (action === "unban") {
    await db().doc(`globalBans/${target}`).delete();
    await notify("رُفع الإيقاف عن حسابك", "يمكنك استخدام التطبيق من جديد.");
  } else if (action.startsWith("ban")) {
    const days = action === "ban1d" ? 1 : action === "ban7d" ? 7 : 0;
    await db().doc(`globalBans/${target}`).set({
      permanent: days === 0,
      until: days ? admin.firestore.Timestamp.fromMillis(Date.now() + days * 24 * 3600 * 1000) : null,
      reason: report.get("reason") || "",
      bannedBy: uid,
      createdAt: now,
    });
    // إخراجه فورًا من أي غرفة هو فيها (يحرّر مقعده ويحدّث العدّاد)
    const live = await db().collectionGroup("members").where("uid", "==", target).get();
    await Promise.all(live.docs.map((d) => d.ref.delete()));
  }
  await reportRef.update({ status: "resolved", action, handledBy: uid, handledAt: now });
  return { ok: true };
});
