# قائمة النشر على Google Play — OUSIMDZ

> أنا لست محاميًا. راجع سياسة الخصوصية والشروط وقوانين بلدك قبل استقبال أموال حقيقية.

## 0) قبل كل شيء: نوع حساب المطور
- **حساب شخصي أُنشئ بعد 13 نوفمبر 2023**: يجب تشغيل **اختبار مغلق** بـ **12 مختبرًا على الأقل لمدة 14 يومًا متواصلة** قبل طلب الإنتاج. حساب **المؤسسة** معفى من هذا الشرط لكنه يحتاج توثيقًا (D-U-N-S). خطّط لنحو 3 أسابيع للإطلاق الأول.
- لقبول **مدفوعات** (شراء العملات) يجب إعداد **ملف مدفوعات (Merchant)** في بلد مدعوم. تحقق من قائمة البلدان المدعومة في مركز مساعدة Google Play قبل أن تبني خطتك على الأرباح.
- **ملف APK المباشر**: بدأ Google فرض **توثيق هوية المطور** على الأجهزة المعتمدة في البرازيل وإندونيسيا وسنغافورة وتايلاند من 30 سبتمبر 2026، وسيمتد عالميًا في 2027. سجّل في Android Developer Console، أو وزّع عبر Google Play.

## 1) الإعداد التقني (مرة واحدة)
1. أنشئ **مفتاح الرفع** (Upload key):
   `keytool -genkey -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`
   احفظ الملف وكلمات المرور في مكانين آمنين. فقدانه يعقّد التحديثات.
2. حوّله إلى base64: `base64 -w0 upload.jks` وضعه في أسرار GitHub:
   `RELEASE_KEYSTORE_BASE64`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`.
3. شغّل Build في GitHub Actions. ستجد **app-release.aab** في Artifacts. هذا ما ترفعه إلى Google Play.
4. **تسجيل Google**: أضف في Firebase بصمتين إضافيتين غير بصمة CI:
   - بصمة **مفتاح الرفع** (SHA-1 من `keytool -list -v -keystore upload.jks`).
   - بصمة **Play App Signing** (من Play Console ← Test and release ← App signing).
   ثم نزّل `google-services.json` جديدًا إن لزم.
5. استضف صفحات الخصوصية: عدّل `docs/*.html` (اسمك وبريدك) ثم `firebase deploy --only hosting`.
   الروابط: `https://<مشروعك>.web.app/privacy.html` و`/delete-account.html`.
6. عدّل `lib/legal.dart` بنفس الاسم والبريد.

## 1.5) منتجات الشراء (Play Console ← Monetize ← In-app products)
أنشئ 5 منتجات **استهلاكية** بهذه المعرّفات تمامًا (الأسعار تحددها أنت):
| المعرّف | العملات | سعر مقترح |
|---|---|---|
| coins_100 | 100 | 0.99$ |
| coins_550 | 550 | 4.99$ |
| coins_1200 | 1200 | 9.99$ |
| coins_3000 | 3000 | 24.99$ |
| coins_7000 | 7000 | 49.99$ |

**التحقق من الخادم** (إلزامي):
1. Play Console ← Users and permissions ← Invite new users: ادعُ حساب خدمة دوال Firebase (`<رقم المشروع>-compute@developer.gserviceaccount.com`، أو الحساب الظاهر في Cloud Functions ← الدالة ← Service account).
2. امنحه صلاحيتي **View financial data** و**Manage orders and subscriptions** على تطبيقك.
3. فعّل **Google Play Android Developer API** في Google Cloud Console لنفس المشروع.
4. قد تتأخر الصلاحيات حتى 24 ساعة.

**اختبار الشراء**: أضف بريدك في Play Console ← Settings ← License testing، وثبّت التطبيق من مسار الاختبار الداخلي. الشراء حينها بلا خصم حقيقي.

## 2) ملف المتجر (Store listing)
- النصوص جاهزة في `store/listing_ar.md`.
- الصور: أيقونة 512×512، صورة مميزة 1024×500، لقطتان على الأقل. صوّرها من التطبيق الفعلي.
- **الجمهور المستهدف**: 18+ (لا تختر فئات الأطفال).
- **تصنيف المحتوى**: أجب بصدق: محتوى يولّده المستخدمون ✔، تواصل بين المستخدمين ✔، مشتريات داخل التطبيق ✔، لا قمار ولا رهان.
- **Data safety**: استخدم `store/data_safety_ar.md`.
- **حذف الحساب**: أدخل رابط `delete-account.html` في نموذج Data safety.
- **سياسة المحتوى الذي ينشئه المستخدمون**: مغطاة بالإبلاغ والحظر والكتم والطرد وحذف الحساب داخل التطبيق.

## 3) مسار الإطلاق
1. **Internal testing**: ارفع AAB وجرّب الشراء مع License testers.
2. **Closed testing**: 12+ مختبرًا × 14 يومًا (للحسابات الشخصية الجديدة).
3. اطلب **Production access**، ثم أنشئ إصدار الإنتاج.
4. بعد النشر: فعّل App Check (`ENFORCE_APPCHECK=true` في `functions/.env` وسر `APP_CHECK=true`).
5. كل تحديث: يزيد رقم البناء تلقائيًا (`--build-number` = رقم تشغيل GitHub).

## 4) قبل أن تفتح الدفع للجميع
- جرّب شراء + استرداد حقيقيين (يخصم `reconcileVoided` العملات خلال ساعة).
- راجع الضرائب وشروط بلدك في ملف المدفوعات.
- تأكد أن الأرصدة لا يمكن سحبها نقدًا (الشروط تنص على ذلك). لا تضف أي ميزة تحويل العملات لأموال دون استشارة قانونية.
