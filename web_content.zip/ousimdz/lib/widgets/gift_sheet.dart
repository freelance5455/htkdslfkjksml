import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../gifts.dart';
import '../models.dart';
import '../services/economy_service.dart';
import '../theme.dart';
import 'avatar.dart';

class GiftSheet extends StatefulWidget {
  const GiftSheet({
    super.key,
    required this.me,
    required this.recipients,
    required this.initialUid,
    required this.ownerId,
    required this.onSend,
  });
  final ValueListenable<AppUser> me;
  final List<Member> recipients;
  final String initialUid;
  final String ownerId;
  final Future<void> Function(String giftId, String toUid, int qty) onSend;

  @override
  State<GiftSheet> createState() => _GiftSheetState();
}

class _GiftSheetState extends State<GiftSheet> {
  late String _to = widget.initialUid;
  GiftItem _gift = giftCatalog.first;
  int _qty = 1;
  bool _busy = false;
  String? _error;

  Future<void> _send() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.onSend(_gift.id, _to, _qty);
      if (mounted) Navigator.of(context).pop();
    } on EconomyException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذّر الإرسال. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _recipient(Member m) {
    final selected = m.uid == _to;
    return GestureDetector(
      onTap: () => setState(() => _to = m.uid),
      child: Container(
        width: 62,
        margin: const EdgeInsetsDirectional.only(end: 8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: selected ? AppColors.gold : Colors.transparent,
                    width: 2),
              ),
              child: Avatar(url: m.photo, name: m.name, size: 40),
            ),
            const SizedBox(height: 2),
            Text(m.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 11,
                    color: selected ? AppColors.gold : Colors.white70)),
          ],
        ),
      ),
    );
  }

  Widget _giftTile(GiftItem g) {
    final selected = g.id == _gift.id;
    return GestureDetector(
      onTap: () => setState(() => _gift = g),
      child: Container(
        decoration: BoxDecoration(
          color: selected ? AppColors.gold.withAlpha(40) : AppColors.glass,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: selected ? AppColors.gold : Colors.transparent, width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(g.emoji, style: const TextStyle(fontSize: 30)),
            const SizedBox(height: 2),
            Text(g.name, style: const TextStyle(fontSize: 12)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.monetization_on_rounded,
                    size: 12, color: AppColors.gold),
                const SizedBox(width: 2),
                Text('${g.price}',
                    style: const TextStyle(
                        fontSize: 11, color: AppColors.gold)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: ValueListenableBuilder<AppUser>(
          valueListenable: widget.me,
          builder: (context, me, _) {
            final total = _gift.price * _qty;
            final enough = me.coins >= total;
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('إرسال هدية',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w800)),
                    const Spacer(),
                    const Icon(Icons.monetization_on_rounded,
                        size: 18, color: AppColors.gold),
                    const SizedBox(width: 4),
                    Text('${me.coins}',
                        style: const TextStyle(
                            color: AppColors.gold,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 74,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [for (final m in widget.recipients) _recipient(m)],
                  ),
                ),
                const SizedBox(height: 8),
                GridView.count(
                  crossAxisCount: 4,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: .88,
                  children: [for (final g in giftCatalog) _giftTile(g)],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final q in const [1, 5, 10, 20])
                      ChoiceChip(
                        label: Text('×$q'),
                        selected: _qty == q,
                        onSelected: (_) => setState(() => _qty = q),
                      ),
                  ],
                ),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(_error!,
                        style: const TextStyle(color: Color(0xFFFF6B6B))),
                  ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    onPressed: (_busy || !enough) ? null : _send,
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.gold,
                      foregroundColor: AppColors.night,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(26)),
                    ),
                    child: _busy
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(
                            enough ? 'إرسال  ($total عملة)' : 'رصيدك غير كافٍ',
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 16)),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
