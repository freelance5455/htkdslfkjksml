import 'package:flutter/material.dart';
import '../theme.dart';

class Avatar extends StatelessWidget {
  const Avatar({super.key, this.url, required this.name, this.size = 40});
  final String? url;
  final String name;
  final double size;

  Widget _fallback() => Container(
        color: AppColors.indigo,
        alignment: Alignment.center,
        child: Text(
          name.isEmpty ? '؟' : String.fromCharCode(name.runes.first),
          style: TextStyle(fontSize: size * .42, fontWeight: FontWeight.w700),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final hasUrl = url != null && url!.isNotEmpty;
    return ClipOval(
      child: SizedBox(
        width: size,
        height: size,
        child: hasUrl
            ? Image.network(url!,
                fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback())
            : _fallback(),
      ),
    );
  }
}
