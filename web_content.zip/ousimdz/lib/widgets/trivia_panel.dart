import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/economy_service.dart' show EconomyException;
import '../services/games_service.dart';
import '../theme.dart';

/// لوحة السؤال والجواب داخل الغرفة. المؤقت يبدأ من لحظة ظهور السؤال لدى
/// اللاعب (لا يعتمد على ساعة الهاتف)، والخادم هو الذي يقرر الفائز.
class TriviaPanel extends StatefulWidget {
  const TriviaPanel({super.key, required this.stream, required this.onAnswer});
  final Stream<TriviaGame?> stream;
  final Future<TriviaResult> Function(int choice) onAnswer;

  @override
  State<TriviaPanel> createState() => _TriviaPanelState();
}

class _TriviaPanelState extends State<TriviaPanel> {
  StreamSubscription<TriviaGame?>? _sub;
  Timer? _tick;
  TriviaGame? _game;
  String? _round;
  DateTime _seenAt = DateTime.now();
  bool _sawOpen = false;
  DateTime? _doneAt;
  int? _picked;
  bool? _correct;

  @override
  void initState() {
    super.initState();
    _sub = widget.stream.listen(_onGame, onError: (_) {});
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _game != null) setState(() {});
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _tick?.cancel();
    super.dispose();
  }

  void _onGame(TriviaGame? g) {
    if (!mounted) return;
    if (g == null) {
      setState(() => _game = null);
      return;
    }
    if (g.round != _round) {
      _round = g.round;
      _seenAt = DateTime.now();
      _sawOpen = false;
      _doneAt = null;
      _picked = null;
      _correct = null;
    }
    if (g.status == 'open') _sawOpen = true;
    if (g.status == 'done' && _doneAt == null) _doneAt = DateTime.now();
    setState(() => _game = g);
  }

  int get _left {
    final g = _game;
    if (g == null) return 0;
    return g.durationSec - DateTime.now().difference(_seenAt).inSeconds;
  }

  Future<void> _answer(int i) async {
    if (_picked != null) return;
    setState(() => _picked = i);
    try {
      final r = await widget.onAnswer(i);
      if (mounted) setState(() => _correct = r.correct);
    } on EconomyException catch (e) {
      if (!mounted) return;
      setState(() => _picked = null);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } catch (_) {
      if (mounted) setState(() => _picked = null);
    }
  }

  Color _optionColor(int i, TriviaGame g) {
    if (g.status == 'done' && g.answer == i) return const Color(0xFF2E9E5B);
    if (_picked == i) {
      if (_correct == true) return const Color(0xFF2E9E5B);
      if (_correct == false) return const Color(0xFFE5484D);
      return AppColors.gold.withAlpha(90);
    }
    return AppColors.glass;
  }

  @override
  Widget build(BuildContext context) {
    final g = _game;
    if (g == null) return const SizedBox.shrink();

    if (g.status == 'done') {
      final fresh = _sawOpen &&
          _doneAt != null &&
          DateTime.now().difference(_doneAt!).inSeconds < 6;
      if (!fresh) return const SizedBox.shrink();
      return _shell(Row(
        children: [
          const Text('🏆', style: TextStyle(fontSize: 26)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              g.winnerName == null
                  ? 'انتهت الجولة'
                  : 'الفائز: ${g.winnerName}',
              style: const TextStyle(
                  fontWeight: FontWeight.w800, color: AppColors.gold),
            ),
          ),
        ],
      ));
    }

    final left = _left;
    if (left <= 0) return const SizedBox.shrink();
    final locked = _picked != null;

    return _shell(Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('❓', style: TextStyle(fontSize: 18)),
            const SizedBox(width: 6),
            Expanded(
              child: Text(g.question,
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, height: 1.35)),
            ),
            const SizedBox(width: 8),
            Text('$left',
                style: const TextStyle(
                    color: AppColors.gold,
                    fontWeight: FontWeight.w900,
                    fontSize: 18)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            minHeight: 4,
            value: (left / g.durationSec).clamp(0.0, 1.0).toDouble(),
            backgroundColor: Colors.white12,
            color: AppColors.mint,
          ),
        ),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 6,
          crossAxisSpacing: 6,
          childAspectRatio: 4.2,
          children: [
            for (var i = 0; i < g.options.length; i++)
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: locked ? null : () => _answer(i),
                child: Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  decoration: BoxDecoration(
                    color: _optionColor(i, g),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(g.options[i],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13)),
                ),
              ),
          ],
        ),
      ],
    ));
  }

  Widget _shell(Widget child) => Container(
        margin: const EdgeInsets.fromLTRB(12, 6, 12, 2),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.black.withAlpha(90),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.mint.withAlpha(110)),
        ),
        child: child,
      );
}
