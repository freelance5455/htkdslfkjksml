import 'dart:math';
import 'package:flutter/material.dart';

class StarField extends StatelessWidget {
  const StarField({super.key, this.count = 70});
  final int count;

  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: CustomPaint(painter: _StarPainter(count), size: Size.infinite),
      );
}

class _StarPainter extends CustomPainter {
  _StarPainter(this.count);
  final int count;

  @override
  void paint(Canvas canvas, Size size) {
    final r = Random(7);
    final p = Paint();
    for (var i = 0; i < count; i++) {
      p.color = Colors.white.withAlpha((70 + r.nextInt(150)));
      canvas.drawCircle(
        Offset(r.nextDouble() * size.width, r.nextDouble() * size.height * .75),
        .5 + r.nextDouble() * 1.4,
        p,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _StarPainter old) => old.count != count;
}
