import 'package:flutter/material.dart';
import '../theme.dart';

class RoomBottomBar extends StatelessWidget {
  const RoomBottomBar({
    super.key,
    required this.seated,
    required this.micMuted,
    required this.speakerOn,
    required this.onMic,
    required this.onSpeaker,
    required this.onChat,
    required this.onMenu,
    required this.onGift,
    required this.onEmoji,
    required this.onGames,
    required this.onBell,
  });
  final bool seated;
  final bool micMuted;
  final bool speakerOn;
  final VoidCallback onMic;
  final VoidCallback onSpeaker;
  final VoidCallback onChat;
  final VoidCallback onMenu;
  final VoidCallback onGift;
  final VoidCallback onEmoji;
  final VoidCallback onGames;
  final VoidCallback onBell;

  @override
  Widget build(BuildContext context) {
    final micActive = seated && !micMuted;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _Btn(Icons.card_giftcard_rounded, onGift, color: AppColors.gold),
          _Btn(Icons.sports_esports_rounded, onGames),
          _Btn(Icons.apps_rounded, onMenu),
          _Btn(Icons.notifications_rounded, onBell),
          _Btn(Icons.emoji_emotions_outlined, onEmoji),
          _Btn(
            micActive ? Icons.mic_rounded : Icons.mic_off_rounded,
            onMic,
            color: micActive ? AppColors.mint : Colors.white54,
          ),
          _Btn(
            speakerOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
            onSpeaker,
            color: speakerOn ? Colors.white : Colors.white54,
          ),
          _Btn(Icons.chat_bubble_rounded, onChat, color: AppColors.mint),
        ],
      ),
    );
  }
}

class _Btn extends StatelessWidget {
  const _Btn(this.icon, this.onTap, {this.color = Colors.white});
  final IconData icon;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) => InkResponse(
        onTap: onTap,
        radius: 26,
        child: Container(
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
              shape: BoxShape.circle, color: AppColors.glass),
          child: Icon(icon, color: color, size: 22),
        ),
      );
}
