import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';
import 'avatar.dart';

class SeatTile extends StatelessWidget {
  const SeatTile({
    super.key,
    required this.seat,
    required this.speaking,
    required this.onTap,
    this.muted = false,
  });
  final Seat seat;
  final bool speaking;
  final bool muted;
  final VoidCallback onTap;

  Widget _inner() {
    if (seat.occupied) {
      return Avatar(url: seat.photo, name: seat.name ?? '', size: 64);
    }
    if (seat.locked) {
      return const Icon(Icons.lock_rounded, color: Colors.white54, size: 26);
    }
    return const Icon(Icons.mic_rounded, color: Colors.white70, size: 30);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 64,
            height: 64,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.glass,
                    border: Border.all(
                      color: speaking ? AppColors.gold : Colors.transparent,
                      width: 3,
                    ),
                    boxShadow: speaking
                        ? [
                            BoxShadow(
                                color: AppColors.gold.withAlpha(120),
                                blurRadius: 14)
                          ]
                        : const [],
                  ),
                  child: ClipOval(child: Center(child: _inner())),
                ),
                if (seat.occupied && muted)
                  Positioned(
                    bottom: -2,
                    right: -2,
                    child: Container(
                      padding: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: Color(0xFFE5484D)),
                      child: const Icon(Icons.mic_off_rounded,
                          size: 12, color: Colors.white),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: 72,
            child: Text(
              seat.occupied ? (seat.name ?? '') : '${seat.index}',
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                color: seat.occupied ? Colors.white : Colors.white60,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
