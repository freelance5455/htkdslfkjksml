import 'package:flutter/material.dart';

import '../achievements.dart';
import '../models.dart';
import '../services/feed_service.dart';
import '../theme.dart';
import 'avatar.dart';
import 'chat_list.dart' show LevelBadge;

/// ملف شخصي مختصر لأي مستخدم: المستوى، الشارات، مراسلة، حظر.
class UserProfileSheet extends StatefulWidget {
  const UserProfileSheet({
    super.key,
    required this.feed,
    required this.meUid,
    required this.uid,
    required this.name,
    this.photo,
    required this.onMessage,
  });
  final FeedService feed;
  final String meUid;
  final String uid;
  final String name;
  final String? photo;
  final VoidCallback onMessage;

  @override
  State<UserProfileSheet> createState() => _UserProfileSheetState();
}

class _UserProfileSheetState extends State<UserProfileSheet> {
  late final Future<PublicProfile?> _profile =
      widget.feed.publicProfile(widget.uid);
  late final Stream<Set<String>> _blocked = widget.feed.blockedUids(widget.meUid);

  Future<void> _toggleBlock(bool isBlocked) async {
    try {
      if (isBlocked) {
        await widget.feed.unblock(widget.meUid, widget.uid);
      } else {
        await widget.feed.block(widget.meUid, widget.uid);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تعذّر تنفيذ العملية.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final self = widget.uid == widget.meUid;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
        child: FutureBuilder<PublicProfile?>(
          future: _profile,
          builder: (context, snap) {
            final p = snap.data;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Avatar(url: widget.photo, name: widget.name, size: 72),
                const SizedBox(height: 8),
                Text(widget.name,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                if (p != null) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      LevelBadge(level: p.level),
                      const SizedBox(width: 12),
                      const Icon(Icons.favorite_rounded,
                          size: 16, color: AppColors.mint),
                      const SizedBox(width: 4),
                      Text('${p.charm}',
                          style: const TextStyle(color: AppColors.mint)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (p.achievements.isEmpty)
                    const Text('لا توجد شارات بعد',
                        style: TextStyle(color: Colors.white54, fontSize: 12))
                  else
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      alignment: WrapAlignment.center,
                      children: [
                        for (final a in achievementCatalog)
                          if (p.achievements.contains(a.id))
                            Tooltip(
                              message: a.title,
                              child: Text(a.emoji,
                                  style: const TextStyle(fontSize: 26)),
                            ),
                      ],
                    ),
                ] else if (snap.connectionState != ConnectionState.done)
                  const Padding(
                    padding: EdgeInsets.all(12),
                    child: CircularProgressIndicator(color: AppColors.gold),
                  ),
                const SizedBox(height: 16),
                if (!self)
                  StreamBuilder<Set<String>>(
                    stream: _blocked,
                    builder: (context, b) {
                      final isBlocked = b.data?.contains(widget.uid) ?? false;
                      return Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: isBlocked
                                  ? null
                                  : () {
                                      Navigator.of(context).pop();
                                      widget.onMessage();
                                    },
                              style: FilledButton.styleFrom(
                                  backgroundColor: AppColors.gold,
                                  foregroundColor: AppColors.night),
                              icon: const Icon(Icons.chat_rounded),
                              label: const Text('مراسلة'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () => _toggleBlock(isBlocked),
                              icon: Icon(isBlocked
                                  ? Icons.lock_open_rounded
                                  : Icons.block_rounded),
                              label: Text(isBlocked ? 'إلغاء الحظر' : 'حظر'),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
