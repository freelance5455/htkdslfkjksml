import 'dart:async';
import 'dart:collection';
import 'dart:math';

import 'package:flutter/material.dart';

import '../gifts.dart';
import '../theme.dart';

/// يعرض تأثيرات الهدايا فوق الغرفة:
/// الهدايا الصغيرة تطفو للأعلى، والكبيرة (500 عملة فأكثر) بتأثير ملء الشاشة.
class GiftOverlay extends StatefulWidget {
  const GiftOverlay({super.key, required this.events});
  final Stream<GiftEvent> events;

  @override
  State<GiftOverlay> createState() => _GiftOverlayState();
}

class _Floating {
  _Floating(this.id, this.event, this.gift, this.seed);
  final int id;
  final GiftEvent event;
  final GiftItem gift;
  final double seed;
}

class _GiftOverlayState extends State<GiftOverlay> {
  StreamSubscription<GiftEvent>? _sub;
  final List<_Floating> _small = [];
  final Queue<GiftEvent> _bigQueue = Queue();
  GiftEvent? _bigNow;
  int _seq = 0;
  final _rnd = Random();

  @override
  void initState() {
    super.initState();
    _sub = widget.events.listen(_onEvent, onError: (_) {});
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _onEvent(GiftEvent e) {
    final gift = giftById(e.giftId);
    if (gift == null || !mounted) return;
    setState(() {
      if (gift.big) {
        if (_bigNow == null) {
          _bigNow = e;
        } else {
          _bigQueue.add(e);
        }
      } else {
        _small.add(_Floating(_seq++, e, gift, _rnd.nextDouble() * 6.28));
      }
    });
  }

  void _bigDone() {
    if (!mounted) return;
    setState(() => _bigNow = _bigQueue.isEmpty ? null : _bigQueue.removeFirst());
  }

  @override
  Widget build(BuildContext context) {
    final big = _bigNow;
    return IgnorePointer(
      child: Stack(
        children: [
          for (final f in _small)
            _FloatingGift(
              key: ValueKey('s${f.id}'),
              item: f,
              onDone: () {
                if (mounted) setState(() => _small.remove(f));
              },
            ),
          if (big != null)
            _BigGift(
              key: ValueKey('b${big.id}'),
              event: big,
              gift: giftById(big.giftId)!,
              onDone: _bigDone,
            ),
        ],
      ),
    );
  }
}

String _caption(GiftEvent e) =>
    '${e.fromName} ← ${e.toName}${e.qty > 1 ? '  ×${e.qty}' : ''}';

class _FloatingGift extends StatelessWidget {
  const _FloatingGift({super.key, required this.item, required this.onDone});
  final _Floating item;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 2800),
      onEnd: onDone,
      builder: (context, t, _) {
        final dx = sin(t * pi * 2 + item.seed) * 26;
        final opacity = t < .12 ? t / .12 : (t > .75 ? (1 - t) / .25 : 1.0);
        final scale = .7 + .5 * Curves.easeOut.transform(min(1.0, t * 3));
        return Positioned(
          left: w / 2 + dx - 70,
          bottom: 110 + t * 330,
          width: 140,
          child: Opacity(
            opacity: opacity.clamp(0.0, 1.0).toDouble(),
            child: Transform.scale(
              scale: scale,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(item.gift.emoji, style: const TextStyle(fontSize: 48)),
                  const SizedBox(height: 4),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withAlpha(110),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(_caption(item.event),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11)),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _BigGift extends StatelessWidget {
  const _BigGift({
    super.key,
    required this.event,
    required this.gift,
    required this.onDone,
  });
  final GiftEvent event;
  final GiftItem gift;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: const Duration(milliseconds: 3600),
        onEnd: onDone,
        builder: (context, t, _) {
          final fade = t < .1 ? t / .1 : (t > .85 ? (1 - t) / .15 : 1.0);
          final pop = Curves.elasticOut.transform(min(1.0, t / .32));
          final float = sin(t * pi * 3) * 6;
          return Opacity(
            opacity: fade.clamp(0.0, 1.0).toDouble(),
            child: Stack(
              children: [
                Positioned.fill(
                  child: ColoredBox(color: Colors.black.withAlpha(95)),
                ),
                Positioned.fill(
                  child: CustomPaint(painter: _BurstPainter(t)),
                ),
                Center(
                  child: Transform.translate(
                    offset: Offset(0, float),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 230,
                          height: 230,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(colors: [
                              AppColors.gold.withAlpha(150),
                              AppColors.gold.withAlpha(0),
                            ]),
                          ),
                          child: Transform.scale(
                            scale: .2 + .95 * pop,
                            child: Text(gift.emoji,
                                style: const TextStyle(fontSize: 120)),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(gift.name,
                            style: const TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                color: AppColors.gold)),
                        const SizedBox(height: 6),
                        Text(_caption(event),
                            style: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _BurstPainter extends CustomPainter {
  _BurstPainter(this.t);
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final p = Paint();
    const n = 30;
    for (var i = 0; i < n; i++) {
      final a = i * 2 * pi / n + t * .6;
      final speed = .55 + .45 * ((i % 4) / 3);
      final d = Curves.easeOut.transform(min(1.0, t * 1.6)) * 230 * speed;
      final alpha = ((1 - t) * 230).clamp(0, 255).toInt();
      p.color = (i.isEven ? AppColors.gold : AppColors.mint).withAlpha(alpha);
      canvas.drawCircle(c + Offset(cos(a) * d, sin(a) * d), 2.5 + (i % 3), p);
    }
  }

  @override
  bool shouldRepaint(covariant _BurstPainter old) => old.t != t;
}
