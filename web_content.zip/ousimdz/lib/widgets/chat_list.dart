import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';

class ChatList extends StatelessWidget {
  const ChatList({
    super.key,
    required this.stream,
    required this.room,
    this.hidden = const <String>{},
  });
  final Stream<List<ChatMessage>> stream;
  final Room room;
  final Set<String> hidden;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ChatMessage>>(
      stream: stream,
      builder: (context, snap) {
        final msgs = (snap.data ?? const <ChatMessage>[])
            .where((m) => m.type == 'system' || !hidden.contains(m.uid))
            .toList();
        return ListView.builder(
          reverse: true, // الأحدث في الأسفل
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          itemCount: msgs.length + 1,
          itemBuilder: (context, i) {
            if (i == msgs.length) return _Header(room: room);
            final m = msgs[i];
            return m.type == 'system' ? _SystemLine(m: m) : _Bubble(m: m);
          },
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.room});
  final Room room;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _card(const Text(
          'مرحبًا بكم في OUSIMDZ. يرجى احترام بعضكم البعض والدردشة بأدب.',
          style: TextStyle(color: AppColors.mint, height: 1.5),
        )),
        if (room.announcement.isNotEmpty)
          _card(Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('إعلان الغرفة:',
                  style: TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(room.announcement,
                  style: const TextStyle(color: AppColors.mint, height: 1.5)),
            ],
          )),
      ],
    );
  }

  Widget _card(Widget child) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.glass,
          borderRadius: BorderRadius.circular(14),
        ),
        child: child,
      );
}

class _SystemLine extends StatelessWidget {
  const _SystemLine({required this.m});
  final ChatMessage m;

  @override
  Widget build(BuildContext context) => Align(
        alignment: AlignmentDirectional.centerStart,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.black.withAlpha(60),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(m.text,
              style: const TextStyle(color: AppColors.mint, fontSize: 13)),
        ),
      );
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.m});
  final ChatMessage m;

  @override
  Widget build(BuildContext context) => Align(
        alignment: AlignmentDirectional.centerStart,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 290),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.glass,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LevelBadge(level: m.level),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(m.name,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: AppColors.gold,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(m.text,
                    style: TextStyle(
                        height: 1.4, fontSize: m.type == 'emoji' ? 32 : null)),
              ],
            ),
          ),
        ),
      );
}

class LevelBadge extends StatelessWidget {
  const LevelBadge({super.key, required this.level});
  final int level;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [AppColors.gold, Color(0xFFFF8A3D)]),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text('LV.$level',
            textDirection: TextDirection.ltr,
            style: const TextStyle(
                color: AppColors.night,
                fontSize: 10,
                fontWeight: FontWeight.w800)),
      );
}

/// فقاعة رسالة قابلة لإعادة الاستخدام (دردشة المجموعات).
class MessageBubble extends StatelessWidget {
  const MessageBubble({super.key, required this.m});
  final ChatMessage m;

  @override
  Widget build(BuildContext context) =>
      m.type == 'system' ? _SystemLine(m: m) : _Bubble(m: m);
}
