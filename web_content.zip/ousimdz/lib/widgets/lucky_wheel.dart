import 'dart:math';

import 'package:flutter/material.dart';

import '../services/economy_service.dart' show EconomyException;
import '../services/games_service.dart';
import '../theme.dart';

/// يجب أن تطابق القائمة WHEEL_PRIZES في functions/index.js (نفس الترتيب).
const wheelPrizes = <int>[5, 10, 15, 20, 30, 50, 80, 150];

class LuckyWheelDialog extends StatefulWidget {
  const LuckyWheelDialog({super.key, required this.onSpin});
  final Future<WheelResult> Function() onSpin;

  @override
  State<LuckyWheelDialog> createState() => _LuckyWheelDialogState();
}

class _LuckyWheelDialogState extends State<LuckyWheelDialog>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  Animation<double> _rot = const AlwaysStoppedAnimation<double>(0);
  bool _spinning = false;
  bool _done = false;
  int? _won;
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _spin() async {
    setState(() {
      _spinning = true;
      _error = null;
    });
    try {
      final r = await widget.onSpin();
      const seg = 2 * pi / 8;
      final target = 2 * pi * 5 - (r.index + .5) * seg;
      _rot = Tween<double>(begin: 0, end: target)
          .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
      await _c.forward(from: 0);
      if (mounted) {
        setState(() {
          _won = r.coins;
          _spinning = false;
          _done = true;
        });
      }
    } on EconomyException catch (e) {
      if (mounted) {
        setState(() {
          _error = e.message;
          _spinning = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _error = 'تعذّر تشغيل العجلة. حاول مرة أخرى.';
          _spinning = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.night,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('عجلة الحظ اليومية',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('مجانية، دورة واحدة كل يوم',
                style: TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 10),
            const Icon(Icons.arrow_drop_down_rounded,
                color: AppColors.gold, size: 44),
            Transform.translate(
              offset: const Offset(0, -12),
              child: AnimatedBuilder(
                animation: _c,
                builder: (_, __) => Transform.rotate(
                  angle: _rot.value,
                  child: const CustomPaint(
                      size: Size(250, 250), painter: _WheelPainter()),
                ),
              ),
            ),
            if (_done)
              Text('ربحت $_won عملة 🎉',
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: AppColors.gold)),
            if (_error != null)
              Text(_error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFFFF6B6B))),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: FilledButton(
                onPressed: _spinning
                    ? null
                    : (_done ? () => Navigator.of(context).pop() : _spin),
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.gold,
                  foregroundColor: AppColors.night,
                ),
                child: Text(_done ? 'تم' : 'أدر العجلة',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WheelPainter extends CustomPainter {
  const _WheelPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    const seg = 2 * pi / 8;
    final fill = Paint();
    for (var i = 0; i < 8; i++) {
      fill.color = i.isEven ? const Color(0xFF1B2A78) : const Color(0xFF0F8C93);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), -pi / 2 + i * seg,
          seg, true, fill);

      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(-pi / 2 + (i + .5) * seg);
      final tp = TextPainter(
        text: TextSpan(
          text: '${wheelPrizes[i]}',
          style: const TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(r * .58 - tp.width / 2, -tp.height / 2));
      canvas.restore();
    }
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..color = AppColors.gold,
    );
    canvas.drawCircle(c, 14, Paint()..color = AppColors.gold);
  }

  @override
  bool shouldRepaint(covariant _WheelPainter old) => false;
}
