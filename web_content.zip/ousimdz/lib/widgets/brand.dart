import 'package:flutter/material.dart';
import '../theme.dart';

/// شعار OUSIMDZ: دائرة متدرجة فيها مايك. (تصميم أصلي، غيّره بشعارك لاحقًا)
class OusimMark extends StatelessWidget {
  const OusimMark({super.key, this.size = 72});
  final double size;

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [AppColors.gold, Color(0xFFFF7A59)],
          ),
          boxShadow: [
            BoxShadow(color: AppColors.gold.withAlpha(90), blurRadius: 24),
          ],
        ),
        child: Icon(Icons.mic_rounded, color: AppColors.night, size: size * .5),
      );
}

class OusimWordmark extends StatelessWidget {
  const OusimWordmark({super.key, this.fontSize = 22});
  final double fontSize;

  @override
  Widget build(BuildContext context) => Text(
        'OUSIMDZ',
        textDirection: TextDirection.ltr,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
          letterSpacing: 2,
          color: Colors.white,
        ),
      );
}
