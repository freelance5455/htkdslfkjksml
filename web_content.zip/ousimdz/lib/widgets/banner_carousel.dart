import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/feed_service.dart';
import '../theme.dart';

/// بانرات إعلانية داخلية تُدار من Firestore (مجموعة banners).
/// نصية فقط وبلا روابط، فلا تحمل أي خطر على المستخدم.
class BannerCarousel extends StatefulWidget {
  const BannerCarousel({super.key, required this.feed});
  final FeedService feed;

  @override
  State<BannerCarousel> createState() => _BannerCarouselState();
}

class _BannerCarouselState extends State<BannerCarousel> {
  late final Stream<List<AppBanner>> _stream = widget.feed.banners();
  final _page = PageController();
  Timer? _timer;
  int _count = 0;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (_count < 2 || !_page.hasClients) return;
      _page.animateToPage((_index + 1) % _count,
          duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<AppBanner>>(
      stream: _stream,
      builder: (context, snap) {
        final list = (snap.data ?? const <AppBanner>[])
            .where((b) => b.text.isNotEmpty)
            .toList();
        _count = list.length;
        if (list.isEmpty) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Column(
            children: [
              SizedBox(
                height: 64,
                child: PageView.builder(
                  controller: _page,
                  itemCount: list.length,
                  onPageChanged: (i) => setState(() => _index = i),
                  itemBuilder: (_, i) => _BannerCard(banner: list[i]),
                ),
              ),
              if (list.length > 1)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (var i = 0; i < list.length; i++)
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          width: i == _index ? 16 : 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: i == _index
                                ? AppColors.gold
                                : Colors.white30,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _BannerCard extends StatelessWidget {
  const _BannerCard({required this.banner});
  final AppBanner banner;

  @override
  Widget build(BuildContext context) {
    final base = banner.color != null ? Color(banner.color!) : AppColors.indigo;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: [base, Color.alphaBlend(Colors.black.withAlpha(70), base)],
        ),
        border: Border.all(color: AppColors.gold.withAlpha(120)),
      ),
      child: Row(
        children: [
          Text(banner.emoji, style: const TextStyle(fontSize: 26)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              banner.text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700, height: 1.35),
            ),
          ),
        ],
      ),
    );
  }
}
