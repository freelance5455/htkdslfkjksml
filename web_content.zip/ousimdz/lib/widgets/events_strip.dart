import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../screens/room_access.dart';
import '../services/economy_service.dart' show EconomyException;
import '../services/event_service.dart';
import '../theme.dart';

/// شريط الأحداث القادمة في الشاشة الرئيسية.
class EventsStrip extends StatefulWidget {
  const EventsStrip({super.key, required this.me});
  final AppUser me;

  @override
  State<EventsStrip> createState() => _EventsStripState();
}

class _EventsStripState extends State<EventsStrip> {
  final _svc = EventService();
  late final Stream<List<AppEvent>> _stream = _svc.upcoming();

  void _open(AppEvent e) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.night,
      isScrollControlled: true,
      builder: (_) => _EventSheet(event: e, me: widget.me, svc: _svc),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<AppEvent>>(
      stream: _stream,
      builder: (context, snap) {
        final list = snap.data ?? const <AppEvent>[];
        if (list.isEmpty) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 14, 16, 6),
              child: Text('الأحداث القادمة',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            SizedBox(
              height: 86,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  final e = list[i];
                  final live = e.startsAt.isBefore(DateTime.now());
                  return InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => _open(e),
                    child: Container(
                      width: 210,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.glass,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: live
                                ? AppColors.mint
                                : AppColors.gold.withAlpha(90)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(e.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text(e.roomName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 12)),
                          const Spacer(),
                          Row(
                            children: [
                              Icon(live ? Icons.sensors_rounded : Icons.schedule_rounded,
                                  size: 14,
                                  color: live ? AppColors.mint : AppColors.gold),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                    live ? 'جارٍ الآن' : fmtEventTime(e.startsAt),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: live
                                            ? AppColors.mint
                                            : AppColors.gold)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class _EventSheet extends StatelessWidget {
  const _EventSheet({required this.event, required this.me, required this.svc});
  final AppEvent event;
  final AppUser me;
  final EventService svc;

  @override
  Widget build(BuildContext context) {
    final e = event;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(e.title,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('${fmtEventTime(e.startsAt)}  •  ${e.roomName}',
                style: const TextStyle(color: AppColors.gold)),
            Text('المضيف: ${e.hostName}',
                style: const TextStyle(color: Colors.white70, fontSize: 13)),
            if (e.description.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(e.description, style: const TextStyle(height: 1.5)),
            ],
            const SizedBox(height: 6),
            Text('مهتمون: ${e.rsvpCount}',
                style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 14),
            StreamBuilder<bool>(
              stream: svc.isGoing(e.id, me.uid),
              builder: (context, snap) {
                final going = snap.data ?? false;
                return Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => svc.setGoing(e.id, me.uid, !going),
                        style: FilledButton.styleFrom(
                          backgroundColor:
                              going ? AppColors.glass : AppColors.gold,
                          foregroundColor:
                              going ? Colors.white : AppColors.night,
                        ),
                        icon: Icon(going
                            ? Icons.notifications_active_rounded
                            : Icons.notifications_none_rounded),
                        label: Text(going ? 'سأحضر (إلغاء)' : 'ذكّرني'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final nav = Navigator.of(context);
                          final room = await svc.getRoom(e.roomId);
                          if (room == null) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text('هذه الغرفة لم تعد موجودة.')));
                            }
                            return;
                          }
                          nav.pop();
                          if (context.mounted) {
                            await openRoomWithAccess(context, room, me);
                          }
                        },
                        icon: const Icon(Icons.login_rounded),
                        label: const Text('ادخل الغرفة'),
                      ),
                    ),
                  ],
                );
              },
            ),
            if (e.hostId == me.uid)
              TextButton.icon(
                onPressed: () async {
                  try {
                    await svc.delete(e.id);
                    if (context.mounted) Navigator.of(context).pop();
                  } on EconomyException catch (x) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(SnackBar(content: Text(x.message)));
                    }
                  }
                },
                icon: const Icon(Icons.delete_outline_rounded,
                    color: Color(0xFFFF6B6B)),
                label: const Text('حذف الحدث',
                    style: TextStyle(color: Color(0xFFFF6B6B))),
              ),
          ],
        ),
      ),
    );
  }
}
