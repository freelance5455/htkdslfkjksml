import 'package:flutter/material.dart';

import '../format.dart';
import '../theme.dart';

class EventDraft {
  final String title;
  final String description;
  final DateTime at;
  const EventDraft(this.title, this.description, this.at);
}

/// نافذة جدولة حدث: عنوان، وصف، وموعد.
class ScheduleDialog extends StatefulWidget {
  const ScheduleDialog({super.key});

  @override
  State<ScheduleDialog> createState() => _ScheduleDialogState();
}

class _ScheduleDialogState extends State<ScheduleDialog> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  DateTime? _at;

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 30)),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
        context: context, initialTime: const TimeOfDay(hour: 20, minute: 0));
    if (t == null) return;
    setState(() => _at = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  @override
  Widget build(BuildContext context) {
    final ok = _title.text.trim().length >= 3 && _at != null;
    return AlertDialog(
      backgroundColor: AppColors.night,
      title: const Text('جدولة حدث'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _title,
              maxLength: 50,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'عنوان الحدث'),
            ),
            TextField(
              controller: _desc,
              maxLength: 200,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'وصف (اختياري)'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _pick,
              icon: const Icon(Icons.event_rounded),
              label: Text(_at == null ? 'اختر الموعد' : fmtEventTime(_at!)),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء')),
        FilledButton(
          onPressed: ok
              ? () => Navigator.pop(
                  context, EventDraft(_title.text.trim(), _desc.text.trim(), _at!))
              : null,
          child: const Text('جدولة'),
        ),
      ],
    );
  }
}
