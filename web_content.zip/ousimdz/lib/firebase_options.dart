// الطريقة الأولى (لمن عنده كمبيوتر): نفّذ  flutterfire configure  وسيستبدل هذا الملف.
// الطريقة الثانية: الصق قيمك من ملف google-services.json مكان كلمة PASTE:
//   apiKey            = client[0].api_key[0].current_key
//   appId             = client[0].client_info.mobilesdk_app_id
//   messagingSenderId = project_info.project_number
//   projectId         = project_info.project_id
//   storageBucket     = project_info.storage_bucket
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'PASTE',
    appId: 'PASTE',
    messagingSenderId: 'PASTE',
    projectId: 'PASTE',
    storageBucket: 'PASTE',
  );
}
