import 'package:cloud_firestore/cloud_firestore.dart';

class GiftItem {
  final String id;
  final String name;
  final String emoji;
  final int price;
  const GiftItem(this.id, this.name, this.emoji, this.price);

  /// الهدايا الكبيرة تُعرض بتأثير ملء الشاشة.
  bool get big => price >= 500;
}

/// يجب أن تطابق الأسعار والمعرّفات قائمة GIFTS في functions/index.js.
const giftCatalog = <GiftItem>[
  GiftItem('rose', 'وردة', '🌹', 10),
  GiftItem('heart', 'قلب', '❤️', 20),
  GiftItem('coffee', 'قهوة', '☕', 30),
  GiftItem('crown', 'تاج', '👑', 200),
  GiftItem('rocket', 'صاروخ', '🚀', 500),
  GiftItem('car', 'سيارة سباق', '🏎️', 800),
  GiftItem('castle', 'قلعة', '🏰', 1500),
  GiftItem('lion', 'أسد', '🦁', 3000),
];

GiftItem? giftById(String id) {
  for (final g in giftCatalog) {
    if (g.id == id) return g;
  }
  return null;
}

class GiftEvent {
  final String id;
  final String giftId;
  final int qty;
  final String fromName;
  final String? fromPhoto;
  final String toName;
  const GiftEvent({
    required this.id,
    required this.giftId,
    required this.qty,
    required this.fromName,
    this.fromPhoto,
    required this.toName,
  });

  factory GiftEvent.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return GiftEvent(
      id: d.id,
      giftId: (m['giftId'] as String?) ?? '',
      qty: (m['qty'] as num?)?.toInt() ?? 1,
      fromName: (m['fromName'] as String?) ?? '',
      fromPhoto: m['fromPhoto'] as String?,
      toName: (m['toName'] as String?) ?? '',
    );
  }
}
