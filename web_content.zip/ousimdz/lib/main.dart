import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'firebase_options.dart';
import 'screens/auth_gate.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // يعمل مع التطبيق المنشور على Google Play فقط (Play Integrity).
  // فعّله بـ --dart-define=APP_CHECK=true بعد النشر على المتجر.
  const appCheck = bool.fromEnvironment('APP_CHECK');
  if (appCheck) {
    await FirebaseAppCheck.instance
        .activate(androidProvider: AndroidProvider.playIntegrity);
  }
  runApp(const OusimApp());
}

class OusimApp extends StatelessWidget {
  const OusimApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OUSIMDZ',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const AuthGate(),
    );
  }
}
