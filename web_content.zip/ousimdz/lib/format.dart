String fmtCount(int n) {
  if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
  if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
  return '$n';
}

/// الخبرة اللازمة لبلوغ مستوى معيّن. تطابق دالة الخادم:
/// المستوى = floor(sqrt(xp / 100)) + 1
int xpForLevel(int level) => 100 * (level - 1) * (level - 1);

double levelProgress(int xp, int level) {
  final a = xpForLevel(level);
  final b = xpForLevel(level + 1);
  if (b <= a) return 1;
  return ((xp - a) / (b - a)).clamp(0.0, 1.0).toDouble();
}

String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'الآن';
  if (d.inMinutes < 60) return 'منذ ${d.inMinutes} د';
  if (d.inHours < 24) return 'منذ ${d.inHours} س';
  return 'منذ ${d.inDays} يوم';
}

const _weekdays = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];

/// مثال: الخميس 15/10 — 18:30
String fmtEventTime(DateTime t) {
  final l = t.toLocal();
  final hh = l.hour.toString().padLeft(2, '0');
  final mm = l.minute.toString().padLeft(2, '0');
  return '${_weekdays[l.weekday - 1]} ${l.day}/${l.month} — $hh:$mm';
}
