/// حماية من الاحتيال والروابط الخبيثة: لا نسمح بالروابط أو أرقام الهواتف
/// في الدردشة وأسماء الغرف. ولا يوجد أي رابط قابل للضغط في التطبيق أصلًا.
final _linkRe = RegExp(
  r'(https?:\/\/|www\.|t\.me|wa\.me|bit\.ly|[a-z0-9\-]+\.(com|net|org|io|me|co|ly|gl|xyz|app|dz|info|tk|ru|cc|tv|apk)\b)',
  caseSensitive: false,
);
final _phoneRe = RegExp(r'(?:[\d٠-٩][\s\-.]?){9,}');

bool containsLink(String s) => _linkRe.hasMatch(s);
bool containsPhone(String s) => _phoneRe.hasMatch(s);

/// يرجع سبب المنع، أو null إذا كان النص سليمًا.
String? unsafeReason(String s) {
  if (containsLink(s)) {
    return 'الروابط غير مسموحة لحمايتك من الاحتيال والبرمجيات الخبيثة.';
  }
  if (containsPhone(s)) return 'لا تشارك أرقام الهواتف في الغرفة.';
  return null;
}
