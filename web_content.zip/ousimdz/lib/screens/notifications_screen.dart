import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../services/feed_service.dart';
import '../theme.dart';
import '../widgets/stars.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key, required this.feed, required this.uid});
  final FeedService feed;
  final String uid;

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late final Stream<List<AppNotification>> _stream =
      widget.feed.notifications(widget.uid);

  @override
  void initState() {
    super.initState();
    // علّمها مقروءة بعد أن يراها المستخدم.
    Future.delayed(const Duration(seconds: 2), () {
      widget.feed.markAllRead(widget.uid).catchError((_) {});
    });
  }

  IconData _icon(String type) {
    switch (type) {
      case 'gift':
        return Icons.card_giftcard_rounded;
      case 'admin':
        return Icons.shield_rounded;
      case 'game':
        return Icons.emoji_events_rounded;
      default:
        return Icons.notifications_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                      const Text('الإشعارات',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800)),
                    ],
                  ),
                  Expanded(
                    child: StreamBuilder<List<AppNotification>>(
                      stream: _stream,
                      builder: (context, snap) {
                        if (snap.hasError) {
                          return const Center(
                              child: Text('تعذّر تحميل الإشعارات.'));
                        }
                        if (!snap.hasData) {
                          return const Center(
                              child: CircularProgressIndicator(
                                  color: AppColors.gold));
                        }
                        final list = snap.data!;
                        if (list.isEmpty) {
                          return const Center(
                              child: Text('لا توجد إشعارات بعد.',
                                  style: TextStyle(color: Colors.white70)));
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                          itemCount: list.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (_, i) {
                            final n = list[i];
                            return Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: n.read
                                    ? AppColors.glass
                                    : AppColors.gold.withAlpha(45),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                children: [
                                  Icon(_icon(n.type), color: AppColors.gold),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(n.title,
                                            style: const TextStyle(
                                                fontWeight: FontWeight.w800)),
                                        const SizedBox(height: 2),
                                        Text(n.body,
                                            style: const TextStyle(
                                                color: Colors.white70,
                                                height: 1.35)),
                                      ],
                                    ),
                                  ),
                                  if (n.createdAt != null)
                                    Text(timeAgo(n.createdAt!),
                                        style: const TextStyle(
                                            color: Colors.white54,
                                            fontSize: 11)),
                                ],
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
