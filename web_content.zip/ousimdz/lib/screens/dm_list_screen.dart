import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../services/dm_service.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/stars.dart';
import 'dm_chat_screen.dart';

class DmListScreen extends StatefulWidget {
  const DmListScreen({super.key, required this.me});
  final AppUser me;

  @override
  State<DmListScreen> createState() => _DmListScreenState();
}

class _DmListScreenState extends State<DmListScreen> {
  final _dm = DmService();
  late final Stream<List<DmInboxEntry>> _stream = _dm.inbox(widget.me.uid);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                      const Text('الرسائل',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800)),
                    ],
                  ),
                  Expanded(
                    child: StreamBuilder<List<DmInboxEntry>>(
                      stream: _stream,
                      builder: (context, snap) {
                        if (snap.hasError) {
                          return const Center(
                              child: Text('تعذّر تحميل الرسائل.'));
                        }
                        if (!snap.hasData) {
                          return const Center(
                              child: CircularProgressIndicator(
                                  color: AppColors.gold));
                        }
                        final list = snap.data!;
                        if (list.isEmpty) {
                          return const Center(
                            child: Padding(
                              padding: EdgeInsets.all(32),
                              child: Text(
                                  'لا توجد محادثات بعد.\nاضغط على أي شخص في الغرفة ثم "الملف الشخصي" ← "مراسلة".',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.white70, height: 1.6)),
                            ),
                          );
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                          itemCount: list.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (_, i) {
                            final e = list[i];
                            return InkWell(
                              borderRadius: BorderRadius.circular(16),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => DmChatScreen(
                                    me: widget.me,
                                    peerUid: e.peerUid,
                                    peerName: e.peerName,
                                    peerPhoto: e.peerPhoto,
                                  ),
                                ),
                              ),
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: e.unread > 0
                                      ? AppColors.gold.withAlpha(45)
                                      : AppColors.glass,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Row(
                                  children: [
                                    Avatar(
                                        url: e.peerPhoto,
                                        name: e.peerName,
                                        size: 46),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(e.peerName,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.w800)),
                                          const SizedBox(height: 2),
                                          Text(e.lastText,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                  color: Colors.white70,
                                                  fontSize: 13)),
                                        ],
                                      ),
                                    ),
                                    Column(
                                      children: [
                                        if (e.lastAt != null)
                                          Text(timeAgo(e.lastAt!),
                                              style: const TextStyle(
                                                  color: Colors.white54,
                                                  fontSize: 11)),
                                        if (e.unread > 0)
                                          Container(
                                            margin:
                                                const EdgeInsets.only(top: 4),
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 7, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFE5484D),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Text(
                                                e.unread > 9
                                                    ? '9+'
                                                    : '${e.unread}',
                                                style: const TextStyle(
                                                    fontSize: 11,
                                                    fontWeight:
                                                        FontWeight.w800)),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
