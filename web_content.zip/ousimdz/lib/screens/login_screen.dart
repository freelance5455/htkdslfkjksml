import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../legal.dart';
import '../services/auth_service.dart';
import '../theme.dart';
import '../widgets/brand.dart';
import '../widgets/stars.dart';
import 'legal_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.auth});
  final AuthService auth;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _busy = false;
  bool _agreed = false;

  /// يشرح سبب فشل تسجيل Google بلغة مفهومة.
  String _explain(Object e) {
    if (e is StateError) {
      return 'إعداد Google ناقص: لم يصل رمز الهوية. تأكد من إضافة GOOGLE_WEB_CLIENT_ID عند البناء.';
    }
    final t = e is PlatformException ? '${e.code} ${e.message} ${e.details}' : '$e';
    if (RegExp(r'ApiException:\s*10\b').hasMatch(t)) {
      return 'بصمة SHA-1 لهذا التطبيق غير مسجلة في Firebase. أضفها ثم أعد المحاولة (راجع الدليل).';
    }
    if (t.contains('12500')) {
      return 'فشل إعداد تسجيل Google. فعّل Google في Firebase Authentication وحدّد بريد الدعم للمشروع.';
    }
    if (t.contains('network_error') || RegExp(r'ApiException:\s*7\b').hasMatch(t)) {
      return 'لا يوجد اتصال بالإنترنت.';
    }
    return 'تعذّر تسجيل الدخول. حاول مرة أخرى.';
  }

  Future<void> _signIn() async {
    setState(() => _busy = true);
    try {
      await widget.auth.signInWithGoogle();
    } catch (e) {
      if (!mounted) return;
      final msg = _explain(e);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField(count: 90)),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  children: [
                    const Spacer(flex: 3),
                    const OusimMark(size: 96),
                    const SizedBox(height: 20),
                    const OusimWordmark(fontSize: 34),
                    const SizedBox(height: 10),
                    const Text(
                      'غرف صوتية عربية. اجلس على مقعد وتحدّث.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 15),
                    ),
                    const Spacer(flex: 4),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Checkbox(
                          value: _agreed,
                          activeColor: AppColors.gold,
                          checkColor: AppColors.night,
                          onChanged: (v) => setState(() => _agreed = v ?? false),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                const Text('أؤكد أن عمري 18 سنة فأكثر وأوافق على ',
                                    style: TextStyle(fontSize: 13)),
                                GestureDetector(
                                  onTap: () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (_) => const LegalScreen(
                                              title: 'شروط الاستخدام',
                                              body: termsText))),
                                  child: const Text('الشروط',
                                      style: TextStyle(
                                          fontSize: 13,
                                          color: AppColors.gold,
                                          decoration: TextDecoration.underline)),
                                ),
                                const Text(' و', style: TextStyle(fontSize: 13)),
                                GestureDetector(
                                  onTap: () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (_) => const LegalScreen(
                                              title: 'سياسة الخصوصية',
                                              body: privacyText))),
                                  child: const Text('سياسة الخصوصية',
                                      style: TextStyle(
                                          fontSize: 13,
                                          color: AppColors.gold,
                                          decoration: TextDecoration.underline)),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton.icon(
                        onPressed: (_busy || !_agreed) ? null : _signIn,
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: AppColors.night,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(28)),
                        ),
                        icon: _busy
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.login_rounded),
                        label: const Text('تسجيل الدخول عبر Gmail',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700)),
                      ),
                    ),
                    const SizedBox(height: 28),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
