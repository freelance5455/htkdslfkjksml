import 'package:flutter/material.dart';

import '../format.dart';
import '../legal.dart';
import '../models.dart';
import '../safety.dart';
import '../services/auth_service.dart';
import '../services/dm_service.dart';
import '../services/economy_service.dart' show EconomyException;
import '../services/feed_service.dart';
import '../services/room_service.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/banner_carousel.dart';
import '../widgets/brand.dart';
import '../widgets/stars.dart';
import 'achievements_screen.dart';
import 'dm_list_screen.dart';
import 'legal_screen.dart';
import 'leaderboard_screen.dart';
import 'notifications_screen.dart';
import 'room_screen.dart';
import 'wallet_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.me, required this.auth});
  final AppUser me;
  final AuthService auth;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _rooms = RoomService();
  final _feed = FeedService();
  final _dm = DmService();
  late final Stream<List<Room>> _roomsStream = _rooms.rooms();

  AppUser get me => widget.me;

  void _push(Widget page) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

  void _open(Room room) => _push(RoomScreen(room: room, me: me));

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _create() async {
    final name = TextEditingController();
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('غرفة جديدة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              maxLength: 30,
              decoration: const InputDecoration(labelText: 'اسم الغرفة'),
            ),
            TextField(
              controller: note,
              maxLength: 120,
              maxLines: 2,
              decoration:
                  const InputDecoration(labelText: 'إعلان الغرفة (اختياري)'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('إنشاء الغرفة')),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    final why = unsafeReason('${name.text} ${note.text}');
    if (why != null) return _snack(why);
    try {
      final room = await _rooms.createRoom(
        owner: me,
        name: name.text.trim(),
        announcement: note.text.trim(),
      );
      if (mounted) _open(room);
    } catch (_) {
      _snack('تعذّر إنشاء الغرفة. حاول مرة أخرى.');
    }
  }

  void _onMenu(String v) {
    switch (v) {
      case 'achievements':
        _push(AchievementsScreen(auth: widget.auth, me: me));
        break;
      case 'leaders':
        _push(LeaderboardScreen(feed: _feed, me: me));
        break;
      case 'privacy':
        _push(const LegalScreen(title: 'سياسة الخصوصية', body: privacyText));
        break;
      case 'terms':
        _push(const LegalScreen(title: 'شروط الاستخدام', body: termsText));
        break;
      case 'delete':
        _confirmDelete();
        break;
      default:
        widget.auth.signOut();
    }
  }

  Future<void> _confirmDelete() async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('حذف الحساب نهائيًا'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
                'سيُحذف حسابك ورصيدك وإنجازاتك ورسائلك والغرف التي أنشأتها، ولا يمكن التراجع. اكتب كلمة "حذف" للتأكيد.',
                style: TextStyle(height: 1.5)),
            TextField(controller: ctl),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctl.text.trim() == 'حذف'),
              style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFE5484D)),
              child: const Text('حذف نهائيًا')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _feed.deleteAccount();
      await widget.auth.signOut();
    } on EconomyException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('تعذّر حذف الحساب. حاول مرة أخرى.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.night,
        icon: const Icon(Icons.add_rounded),
        label: const Text('غرفة جديدة',
            style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: Row(
                      children: [
                        const OusimWordmark(fontSize: 20),
                        const Spacer(),
                        _ChatButton(
                          dm: _dm,
                          uid: me.uid,
                          onTap: () => _push(DmListScreen(me: me)),
                        ),
                        _BellButton(
                          feed: _feed,
                          uid: me.uid,
                          onTap: () => _push(
                              NotificationsScreen(feed: _feed, uid: me.uid)),
                        ),
                        const SizedBox(width: 6),
                        _WalletChip(
                          me: me,
                          onTap: () =>
                              _push(WalletScreen(auth: widget.auth, me: me)),
                        ),
                        const SizedBox(width: 10),
                        PopupMenuButton<String>(
                          color: AppColors.night,
                          onSelected: _onMenu,
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                                value: 'achievements',
                                child: Text('الإنجازات والشارات')),
                            PopupMenuItem(
                                value: 'leaders', child: Text('المتصدرون')),
                            PopupMenuItem(
                                value: 'privacy',
                                child: Text('سياسة الخصوصية')),
                            PopupMenuItem(
                                value: 'terms', child: Text('شروط الاستخدام')),
                            PopupMenuItem(
                                value: 'out', child: Text('تسجيل الخروج')),
                            PopupMenuItem(
                                value: 'delete',
                                child: Text('حذف الحساب',
                                    style: TextStyle(color: Color(0xFFFF6B6B)))),
                          ],
                          child: Avatar(url: me.photo, name: me.name, size: 36),
                        ),
                      ],
                    ),
                  ),
                  BannerCarousel(feed: _feed),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text('الغرف المباشرة',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800)),
                    ),
                  ),
                  Expanded(
                    child: StreamBuilder<List<Room>>(
                      stream: _roomsStream,
                      builder: (context, snap) {
                        if (snap.hasError) {
                          return const Center(
                              child: Text('تعذّر تحميل الغرف. تحقق من الاتصال.'));
                        }
                        if (!snap.hasData) {
                          return const Center(
                              child: CircularProgressIndicator(
                                  color: AppColors.gold));
                        }
                        final rooms = snap.data!;
                        if (rooms.isEmpty) {
                          return const Center(
                            child: Text('لا توجد غرف بعد. أنشئ أول غرفة.',
                                style: TextStyle(color: Colors.white70)),
                          );
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                          itemCount: rooms.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (_, i) => _RoomCard(
                            room: rooms[i],
                            onTap: () => _open(rooms[i]),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoomCard extends StatelessWidget {
  const _RoomCard({required this.room, required this.onTap});
  final Room room;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.glass,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            children: [
              Avatar(url: room.ownerPhoto, name: room.ownerName, size: 52),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(room.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(
                        room.announcement.isEmpty
                            ? room.ownerName
                            : room.announcement,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 13)),
                  ],
                ),
              ),
              const Icon(Icons.emoji_events_rounded,
                  size: 18, color: AppColors.gold),
              const SizedBox(width: 4),
              Text(fmtCount(room.points),
                  style: const TextStyle(color: AppColors.gold)),
              const SizedBox(width: 12),
              const Icon(Icons.headphones_rounded,
                  size: 18, color: AppColors.mint),
              const SizedBox(width: 4),
              Text('${room.memberCount < 0 ? 0 : room.memberCount}',
                  style: const TextStyle(color: AppColors.mint)),
            ],
          ),
        ),
      );
}

class _WalletChip extends StatelessWidget {
  const _WalletChip({required this.me, required this.onTap});
  final AppUser me;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.glass,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            children: [
              const Icon(Icons.monetization_on_rounded,
                  size: 18, color: AppColors.gold),
              const SizedBox(width: 4),
              Text(fmtCount(me.coins),
                  style: const TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      );
}

class _BellButton extends StatefulWidget {
  const _BellButton(
      {required this.feed, required this.uid, required this.onTap});
  final FeedService feed;
  final String uid;
  final VoidCallback onTap;

  @override
  State<_BellButton> createState() => _BellButtonState();
}

class _BellButtonState extends State<_BellButton> {
  late final Stream<int> _unread = widget.feed.unreadCount(widget.uid);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: _unread,
      builder: (context, snap) {
        final n = snap.data ?? 0;
        return IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: 'الإشعارات',
          onPressed: widget.onTap,
          icon: Stack(
            clipBehavior: Clip.none,
            children: [
              const Icon(Icons.notifications_rounded, color: Colors.white),
              if (n > 0)
                Positioned(
                  top: -4,
                  right: -4,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                    decoration: BoxDecoration(
                        color: const Color(0xFFE5484D),
                        borderRadius: BorderRadius.circular(8)),
                    child: Text(n > 9 ? '9+' : '$n',
                        style: const TextStyle(
                            fontSize: 9, fontWeight: FontWeight.w800)),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ChatButton extends StatefulWidget {
  const _ChatButton({required this.dm, required this.uid, required this.onTap});
  final DmService dm;
  final String uid;
  final VoidCallback onTap;

  @override
  State<_ChatButton> createState() => _ChatButtonState();
}

class _ChatButtonState extends State<_ChatButton> {
  late final Stream<int> _unread = widget.dm.unreadChats(widget.uid);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: _unread,
      builder: (context, snap) {
        final n = snap.data ?? 0;
        return IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: 'الرسائل',
          onPressed: widget.onTap,
          icon: Stack(
            clipBehavior: Clip.none,
            children: [
              const Icon(Icons.chat_rounded, color: AppColors.mint),
              if (n > 0)
                Positioned(
                  top: -4,
                  right: -4,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                    decoration: BoxDecoration(
                        color: const Color(0xFFE5484D),
                        borderRadius: BorderRadius.circular(8)),
                    child: Text(n > 9 ? '9+' : '$n',
                        style: const TextStyle(
                            fontSize: 9, fontWeight: FontWeight.w800)),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
