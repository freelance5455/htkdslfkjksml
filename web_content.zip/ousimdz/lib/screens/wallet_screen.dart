import 'dart:async';

import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

import '../achievements.dart';
import '../format.dart';
import '../models.dart';
import '../services/auth_service.dart';
import '../services/economy_service.dart';
import '../services/purchase_service.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/chat_list.dart' show LevelBadge;
import '../widgets/stars.dart';
import 'achievements_screen.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key, required this.auth, required this.me});
  final AuthService auth;
  final AppUser me;

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  static const dailyCoins = 50;
  final _eco = EconomyService();
  late final Stream<AppUser> _stream = widget.auth.profile(widget.me.uid);
  bool _busy = false;
  late final Future<List<ProductDetails>> _products =
      PurchaseService.instance.loadProducts();
  StreamSubscription<String>? _purchaseSub;

  @override
  void initState() {
    super.initState();
    _purchaseSub = PurchaseService.instance.messages.listen((m) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    });
  }

  @override
  void dispose() {
    _purchaseSub?.cancel();
    super.dispose();
  }

  Widget _store() {
    return FutureBuilder<List<ProductDetails>>(
      future: _products,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Padding(
            padding: EdgeInsets.all(16),
            child: Center(
                child: CircularProgressIndicator(color: AppColors.gold)),
          );
        }
        final list = snap.data ?? const <ProductDetails>[];
        if (list.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: AppColors.glass,
                borderRadius: BorderRadius.circular(16)),
            child: const Text(
                'شحن العملات غير متاح حاليًا. يعمل عند تثبيت التطبيق من Google Play بعد إضافة المنتجات.',
                style: TextStyle(color: Colors.white70, height: 1.5)),
          );
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text('اشحن العملات',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            for (final p in list)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                    color: AppColors.glass,
                    borderRadius: BorderRadius.circular(16)),
                child: Row(
                  children: [
                    const Icon(Icons.monetization_on_rounded,
                        color: AppColors.gold),
                    const SizedBox(width: 8),
                    Text('${coinPacks[p.id] ?? 0} عملة',
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 16)),
                    const Spacer(),
                    FilledButton(
                      onPressed: () => PurchaseService.instance.buy(p),
                      style: FilledButton.styleFrom(
                          backgroundColor: AppColors.gold,
                          foregroundColor: AppColors.night),
                      child: Text(p.price,
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }

  Future<void> _claim() async {
    setState(() => _busy = true);
    String msg;
    try {
      final c = await _eco.claimDaily();
      msg = 'حصلت على $c عملة. عد غدًا للمزيد.';
    } on EconomyException catch (e) {
      msg = e.message;
    } catch (_) {
      msg = 'تعذّر استلام الهدية. حاول مرة أخرى.';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: StreamBuilder<AppUser>(
                initialData: widget.me,
                stream: _stream,
                builder: (context, snap) {
                  final u = snap.data ?? widget.me;
                  return ListView(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                    children: [
                      Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_forward_rounded),
                        ),
                      ),
                      Center(child: Avatar(url: u.photo, name: u.name, size: 84)),
                      const SizedBox(height: 10),
                      Center(
                        child: Text(u.name,
                            style: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(height: 6),
                      Center(child: LevelBadge(level: u.level)),
                      const SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          minHeight: 10,
                          value: levelProgress(u.xp, u.level),
                          backgroundColor: AppColors.glass,
                          color: AppColors.mint,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Center(
                        child: Text(
                          '${u.xp} / ${xpForLevel(u.level + 1)} خبرة للمستوى ${u.level + 1}',
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 12),
                        ),
                      ),
                      const SizedBox(height: 22),
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: AppColors.glass,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          children: [
                            const Text('رصيدك',
                                style: TextStyle(color: Colors.white70)),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.monetization_on_rounded,
                                    color: AppColors.gold, size: 34),
                                const SizedBox(width: 8),
                                Text('${u.coins}',
                                    style: const TextStyle(
                                        fontSize: 38,
                                        fontWeight: FontWeight.w900,
                                        color: AppColors.gold)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 52,
                        child: FilledButton.icon(
                          onPressed: (_busy || !u.canClaimDaily) ? null : _claim,
                          style: FilledButton.styleFrom(
                            backgroundColor: AppColors.gold,
                            foregroundColor: AppColors.night,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(26)),
                          ),
                          icon: const Icon(Icons.card_giftcard_rounded),
                          label: Text(
                            u.canClaimDaily
                                ? 'استلم هديتك اليومية (+$dailyCoins)'
                                : 'استلمت هديتك اليوم',
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 15),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      _store(),
                      const SizedBox(height: 6),
                      OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => AchievementsScreen(
                                  auth: widget.auth, me: u)),
                        ),
                        icon: const Icon(Icons.emoji_events_rounded),
                        label: Text(
                            'الإنجازات والشارات (${u.achievements.length}/${achievementCatalog.length})'),
                      ),
                      const SizedBox(height: 22),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.favorite_rounded,
                              color: AppColors.mint, size: 18),
                          const SizedBox(width: 6),
                          Text('هدايا استلمتها: ${fmtCount(u.charm)}',
                              style: const TextStyle(color: Colors.white70)),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
