import 'package:flutter/material.dart';

import '../achievements.dart';
import '../models.dart';
import '../services/auth_service.dart';
import '../theme.dart';
import '../widgets/stars.dart';

class AchievementsScreen extends StatefulWidget {
  const AchievementsScreen({super.key, required this.auth, required this.me});
  final AuthService auth;
  final AppUser me;

  @override
  State<AchievementsScreen> createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen> {
  late final Stream<AppUser> _stream = widget.auth.profile(widget.me.uid);

  Widget _card(AppUser u, Achievement a) {
    final done = u.achievements.contains(a.id);
    final p = achievementProgress(u, a).clamp(0, a.target);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: done ? AppColors.gold.withAlpha(45) : AppColors.glass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: done ? AppColors.gold : Colors.transparent, width: 1.2),
      ),
      child: Row(
        children: [
          Opacity(
            opacity: done ? 1 : .35,
            child: Text(a.emoji, style: const TextStyle(fontSize: 34)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(a.title,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                const SizedBox(height: 2),
                Text(a.desc,
                    style:
                        const TextStyle(color: Colors.white70, fontSize: 12)),
                if (!done) ...[
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      minHeight: 5,
                      value: p / a.target,
                      backgroundColor: Colors.white12,
                      color: AppColors.mint,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (done)
                const Icon(Icons.check_circle_rounded, color: AppColors.gold)
              else
                Text('$p/${a.target}',
                    style: const TextStyle(
                        color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 2),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.monetization_on_rounded,
                      size: 12, color: AppColors.gold),
                  const SizedBox(width: 2),
                  Text('${a.reward}',
                      style: const TextStyle(
                          color: AppColors.gold, fontSize: 12)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: StreamBuilder<AppUser>(
                initialData: widget.me,
                stream: _stream,
                builder: (context, snap) {
                  final u = snap.data ?? widget.me;
                  return Column(
                    children: [
                      Row(
                        children: [
                          IconButton(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(Icons.arrow_forward_rounded),
                          ),
                          const Text('الإنجازات والشارات',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.w800)),
                          const Spacer(),
                          Padding(
                            padding: const EdgeInsets.only(left: 16),
                            child: Text(
                                '${u.achievements.length}/${achievementCatalog.length}',
                                style: const TextStyle(
                                    color: AppColors.gold,
                                    fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                      Expanded(
                        child: ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                          itemCount: achievementCatalog.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (_, i) => _card(u, achievementCatalog[i]),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
