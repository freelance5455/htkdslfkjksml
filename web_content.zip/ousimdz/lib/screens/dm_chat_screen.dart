import 'dart:async';

import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../safety.dart';
import '../services/dm_service.dart';
import '../services/economy_service.dart' show EconomyException;
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/stars.dart';

class DmChatScreen extends StatefulWidget {
  const DmChatScreen({
    super.key,
    required this.me,
    required this.peerUid,
    required this.peerName,
    this.peerPhoto,
  });
  final AppUser me;
  final String peerUid;
  final String peerName;
  final String? peerPhoto;

  @override
  State<DmChatScreen> createState() => _DmChatScreenState();
}

class _DmChatScreenState extends State<DmChatScreen> {
  final _dm = DmService();
  final _input = TextEditingController();
  StreamSubscription<List<DmMessage>>? _sub;
  List<DmMessage> _msgs = const [];
  bool _sending = false;
  bool _failed = false;
  DateTime _lastSend = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _dm.markRead(widget.me.uid, widget.peerUid);
    _sub = _dm.messages(widget.me.uid, widget.peerUid).listen((m) {
      if (!mounted) return;
      setState(() {
        _msgs = m;
        _failed = false;
      });
      if (m.isNotEmpty && m.first.from != widget.me.uid) {
        _dm.markRead(widget.me.uid, widget.peerUid);
      }
    }, onError: (_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _input.dispose();
    super.dispose();
  }

  void _toast(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _send() async {
    final t = _input.text.trim();
    if (t.isEmpty || _sending) return;
    final why = unsafeReason(t);
    if (why != null) return _toast(why);
    if (DateTime.now().difference(_lastSend) <
        const Duration(milliseconds: 1200)) {
      return _toast('تمهّل قليلًا قبل إرسال رسالة أخرى.');
    }
    setState(() => _sending = true);
    try {
      await _dm.send(widget.peerUid, t);
      _lastSend = DateTime.now();
      _input.clear();
    } on EconomyException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('تعذّر إرسال الرسالة.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                      Avatar(
                          url: widget.peerPhoto,
                          name: widget.peerName,
                          size: 36),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(widget.peerName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                  Expanded(
                    child: _failed
                        ? const Center(child: Text('تعذّر تحميل المحادثة.'))
                        : _msgs.isEmpty
                            ? const Center(
                                child: Text('ابدأ المحادثة بالسلام 👋',
                                    style: TextStyle(color: Colors.white70)))
                            : ListView.builder(
                                reverse: true,
                                padding:
                                    const EdgeInsets.fromLTRB(12, 8, 12, 8),
                                itemCount: _msgs.length,
                                itemBuilder: (_, i) {
                                  final m = _msgs[i];
                                  final mine = m.from == widget.me.uid;
                                  return Align(
                                    alignment: mine
                                        ? AlignmentDirectional.centerEnd
                                        : AlignmentDirectional.centerStart,
                                    child: ConstrainedBox(
                                      constraints:
                                          const BoxConstraints(maxWidth: 280),
                                      child: Container(
                                        margin: const EdgeInsets.symmetric(
                                            vertical: 3),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12, vertical: 8),
                                        decoration: BoxDecoration(
                                          color: mine
                                              ? AppColors.gold.withAlpha(70)
                                              : AppColors.glass,
                                          borderRadius:
                                              BorderRadius.circular(16),
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(m.text,
                                                style: const TextStyle(
                                                    height: 1.4)),
                                            if (m.createdAt != null)
                                              Text(timeAgo(m.createdAt!),
                                                  style: const TextStyle(
                                                      fontSize: 10,
                                                      color: Colors.white54)),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 8, 8),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _input,
                            maxLength: 500,
                            onSubmitted: (_) => _send(),
                            decoration: InputDecoration(
                              counterText: '',
                              hintText: 'اكتب رسالة...',
                              filled: true,
                              fillColor: AppColors.glass,
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 10),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(24),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: _sending ? null : _send,
                          icon: const Icon(Icons.send_rounded,
                              color: AppColors.gold),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
