import 'dart:async';

import 'package:firebase_core/firebase_core.dart' show FirebaseException;
import 'package:flutter/material.dart';

import '../format.dart';
import '../gifts.dart';
import '../models.dart';
import '../safety.dart';
import '../services/access_service.dart';
import '../services/auth_service.dart';
import '../services/economy_service.dart';
import '../services/event_service.dart';
import '../services/feed_service.dart';
import '../services/games_service.dart';
import '../services/moderation_service.dart';
import '../services/room_service.dart';
import '../services/voice_service.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/bottom_bar.dart';
import '../widgets/chat_list.dart';
import '../widgets/gift_overlay.dart';
import '../widgets/gift_sheet.dart';
import '../widgets/lucky_wheel.dart';
import '../widgets/profile_sheet.dart';
import '../widgets/schedule_dialog.dart';
import '../widgets/trivia_panel.dart';
import '../widgets/seat_tile.dart';
import '../widgets/stars.dart';
import 'dm_chat_screen.dart';
import 'notifications_screen.dart';

class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key, required this.room, required this.me});
  final Room room;
  final AppUser me;

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  final _svc = RoomService();
  final _mod = ModerationService();
  final _voice = VoiceService();
  final _eco = EconomyService();
  final _games = GamesService();
  final _feed = FeedService();
  late final Stream<TriviaGame?> _triviaStream =
      _games.triviaStream(widget.room.id);
  DateTime _lastSend = DateTime.fromMillisecondsSinceEpoch(0);
  late final Stream<List<ChatMessage>> _chatStream =
      _svc.messages(widget.room.id);
  Set<String> _blocked = const <String>{};
  final _auth = AuthService();
  late final ValueNotifier<AppUser> _meN = ValueNotifier<AppUser>(widget.me);
  late final Stream<GiftEvent> _giftStream = _svc.giftEvents(widget.room.id);
  final _input = TextEditingController();
  final List<StreamSubscription<dynamic>> _subs = [];
  Timer? _beat;

  late Room _room = widget.room;
  List<Seat> _seats = const [];
  List<Member> _members = const [];
  Map<String, Restriction> _restr = const {};
  int? _mySeat;

  bool _typing = false;
  bool _micMuted = false;
  bool _speakerOn = true;
  bool _voiceReady = false;
  bool _joined = false;
  bool _leaving = false;

  AppUser get me => _meN.value;
  bool get _isOwner => _room.ownerId == me.uid;
  bool get _isAdmin => _room.admins.contains(me.uid);
  bool get _canModerate => _isOwner || _isAdmin;
  bool get _adminMuted => _restr[me.uid]?.muted ?? false;

  /// هل يحق لي اتخاذ إجراء على هذا المستخدم؟
  bool _canActOn(String uid) =>
      uid != me.uid &&
      uid != _room.ownerId &&
      (_isOwner || (_isAdmin && !_room.admins.contains(uid)));

  @override
  void initState() {
    super.initState();
    _subs.addAll([
      _svc.roomStream(_room.id).listen((r) {
        if (r == null) {
          _kickOut('تم حذف الغرفة.');
        } else if (mounted) {
          setState(() => _room = r);
        }
      }),
      _svc.seats(_room.id).listen(_onSeats),
      _svc.members(_room.id).listen((m) {
        if (mounted) setState(() => _members = m);
      }),
      _svc.restrictions(_room.id).listen(_onRestrictions),
      _auth.profile(widget.me.uid).listen((u) => _meN.value = u,
          onError: (_) {}),
      _feed.blockedUids(widget.me.uid).listen((s) {
        if (mounted) setState(() => _blocked = s);
      }, onError: (_) {}),
    ]);
    _enter();
  }

  void _onSeats(List<Seat> list) {
    final mine = list.where((s) => s.userId == me.uid).toList();
    final idx = mine.isEmpty ? null : mine.first.index;
    // أُزيل من المقعد (نزل أو أنزله مشرف): أوقف البث.
    if (idx == null && _mySeat != null) _voice.stopSpeaking();
    if (!mounted) return;
    setState(() {
      _seats = list;
      _mySeat = idx;
    });
  }

  void _onRestrictions(Map<String, Restriction> map) {
    final wasMuted = _adminMuted;
    final mine = map[me.uid];
    if (mine?.banned == true) {
      _kickOut('تم طردك من الغرفة.');
      return;
    }
    if (!mounted) return;
    setState(() => _restr = map);
    final nowMuted = mine?.muted ?? false;
    if (nowMuted) {
      if (!_micMuted) setState(() => _micMuted = true);
      _voice.setMicMuted(true);
      if (!wasMuted) _toast('كتمك المشرف.');
    } else if (wasMuted) {
      _toast('أُلغي كتمك. يمكنك التحدث الآن.');
    }
  }

  Future<void> _enter() async {
    try {
      await _svc.enterRoom(_room.id, me);
      _joined = true;
      _beat = Timer.periodic(const Duration(seconds: 30),
          (_) => _svc.heartbeat(_room.id, me).catchError((_) {}));
    } on FirebaseException catch (e) {
      _kickOut(e.code == 'permission-denied'
          ? 'أنت محظور من هذه الغرفة حاليًا.'
          : 'تعذّر دخول الغرفة.');
      return;
    }
    try {
      await _voice.join(_room.id);
      if (mounted) setState(() => _voiceReady = true);
    } catch (_) {
      _toast('تعذّر الاتصال بالصوت. يمكنك استخدام الدردشة النصية.');
    }
  }

  void _kickOut(String msg) {
    if (_leaving) return;
    _leaving = true;
    _toast(msg);
    if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  void dispose() {
    _beat?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    if (_joined) _svc.exitRoom(_room.id, me.uid, _mySeat);
    _voice.dispose();
    _input.dispose();
    _meN.dispose();
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _run(Future<void> Function() f, {String? ok}) async {
    try {
      await f();
      if (ok != null) _toast(ok);
    } on ModerationException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('تعذّر تنفيذ الإجراء. حاول مرة أخرى.');
    }
  }

  // ---------- المقاعد ----------

  Future<void> _onSeatTap(Seat seat) async {
    if (seat.userId == me.uid) return _mySeatSheet(seat);

    if (seat.occupied) {
      _userSheet(seat.userId!, seat.name ?? '');
      return;
    }

    if (_canModerate) return _emptySeatSheet(seat);
    if (seat.locked) return _toast('هذا المقعد مقفل.');
    await _sit(seat);
  }

  Future<void> _sit(Seat seat) async {
    if (!_voiceReady) return _toast('الصوت غير جاهز بعد. انتظر لحظة.');
    if (_mySeat != null) await _svc.leaveSeat(_room.id, _mySeat!);
    final ok = await _svc.takeSeat(_room.id, seat.index, me);
    if (!ok) return _toast('هذا المقعد لم يعد متاحًا.');
    final granted = await _voice.startSpeaking();
    if (!granted) {
      await _svc.leaveSeat(_room.id, seat.index);
      return _toast('فعّل إذن المايك من إعدادات الهاتف لتتحدث.');
    }
    if (_adminMuted) {
      _voice.setMicMuted(true);
      setState(() => _micMuted = true);
    } else {
      setState(() => _micMuted = false);
    }
  }

  void _toggleMic() {
    if (_mySeat == null) return _toast('اجلس على مقعد أولًا لتتحدث.');
    if (_adminMuted) return _toast('أنت مكتوم من قِبل المشرف.');
    setState(() => _micMuted = !_micMuted);
    _voice.setMicMuted(_micMuted);
  }

  void _toggleSpeaker() {
    setState(() => _speakerOn = !_speakerOn);
    _voice.setSpeakerOn(_speakerOn);
  }

  // ---------- القوائم السفلية ----------

  Widget _tile(IconData icon, String title, VoidCallback onTap,
          {Color? color}) =>
      ListTile(
        leading: Icon(icon, color: color),
        title: Text(title, style: TextStyle(color: color)),
        onTap: () {
          Navigator.of(context).pop();
          onTap();
        },
      );

  void _sheet(String? title, List<Widget> children) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.night,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (title != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: Text(title,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
            ...children,
          ],
        ),
      ),
    );
  }

  void _mySeatSheet(Seat seat) => _sheet(null, [
        _tile(_micMuted ? Icons.mic_rounded : Icons.mic_off_rounded,
            _micMuted ? 'تشغيل المايك' : 'كتم المايك', _toggleMic),
        _tile(Icons.event_seat_rounded, 'النزول من المقعد',
            () => _svc.leaveSeat(_room.id, seat.index)),
      ]);

  void _emptySeatSheet(Seat seat) => _sheet('مقعد ${seat.index}', [
        if (!seat.locked)
          _tile(Icons.event_seat_rounded, 'الجلوس هنا', () => _sit(seat)),
        _tile(
          seat.locked ? Icons.lock_open_rounded : Icons.lock_rounded,
          seat.locked ? 'فتح المقعد' : 'قفل المقعد',
          () => _run(() => _mod.lockSeat(_room.id, seat.index, !seat.locked)),
        ),
      ]);

  void _userSheet(String uid, String name) {
    final seated = _seats.any((s) => s.userId == uid);
    final muted = _restr[uid]?.muted == true;
    final isAdm = _room.admins.contains(uid);
    final canAct = _canActOn(uid);
    _sheet(name, [
      _tile(Icons.person_rounded, 'الملف الشخصي والمراسلة',
          () => _openProfile(uid, name)),
      _tile(Icons.card_giftcard_rounded, 'إرسال هدية',
          () => _openGifts(toUid: uid),
          color: AppColors.gold),
      _tile(Icons.flag_rounded, 'إبلاغ عن مستخدم', () => _reportSheet(uid, name)),
      if (canAct) ...[
        _tile(
          muted ? Icons.mic_rounded : Icons.mic_off_rounded,
          muted ? 'إلغاء الكتم' : 'كتم',
          () => _run(() => _mod.setMuted(_room.id, uid, !muted),
              ok: muted ? 'أُلغي الكتم.' : 'تم الكتم.'),
        ),
        if (seated)
          _tile(Icons.event_seat_rounded, 'إنزال من المقعد',
              () => _run(() => _mod.kickFromSeat(_room.id, uid))),
        if (_isOwner)
          _tile(
            Icons.shield_rounded,
            isAdm ? 'إزالة الإشراف' : 'تعيين مشرف',
            () => _run(() => _mod.setAdmin(_room.id, uid, !isAdm),
                ok: isAdm ? 'أُزيل الإشراف.' : 'تم تعيين المشرف.'),
          ),
        _tile(Icons.block_rounded, 'طرد من الغرفة (ساعة)',
            () => _confirmBan(uid, name),
            color: const Color(0xFFFF6B6B)),
      ],
    ]);
  }

  Future<void> _confirmBan(String uid, String name) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: Text('طرد $name؟'),
        content: const Text('لن يستطيع دخول الغرفة لمدة ساعة.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('طرد')),
        ],
      ),
    );
    if (yes == true) {
      await _run(() => _mod.ban(_room.id, uid), ok: 'تم الطرد.');
    }
  }

  void _menuSheet() => _sheet(null, [
        _tile(Icons.groups_rounded, 'المتواجدون (${_members.length})',
            _membersSheet),
        if (_isOwner)
          _tile(Icons.settings_rounded, 'إعدادات الغرفة', _editRoom),
        if (_isOwner)
          _tile(
            _room.hasPassword ? Icons.lock_rounded : Icons.lock_open_rounded,
            _room.hasPassword ? 'تغيير كلمة مرور الغرفة' : 'جعل الغرفة خاصة بكلمة مرور',
            _passwordDialog,
          ),
        if (_canModerate)
          _tile(Icons.event_rounded, 'جدولة حدث في هذه الغرفة', _scheduleEvent),
      ]);

  void _membersSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.night,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .6,
        maxChildSize: .9,
        builder: (ctx, scroll) => StreamBuilder<List<Member>>(
          initialData: _members,
          stream: _svc.members(_room.id),
          builder: (ctx, snap) {
            final list = snap.data ?? const <Member>[];
            return ListView.builder(
              controller: scroll,
              itemCount: list.length,
              itemBuilder: (_, i) {
                final m = list[i];
                final owner = m.uid == _room.ownerId;
                final adm = _room.admins.contains(m.uid);
                final muted = _restr[m.uid]?.muted == true;
                return ListTile(
                  leading: Avatar(url: m.photo, name: m.name, size: 40),
                  title: Row(children: [
                    Flexible(
                        child: Text(m.name, overflow: TextOverflow.ellipsis)),
                    const SizedBox(width: 6),
                    LevelBadge(level: m.level),
                    if (owner)
                      const Padding(
                        padding: EdgeInsetsDirectional.only(start: 6),
                        child: Icon(Icons.workspace_premium_rounded,
                            size: 18, color: AppColors.gold),
                      ),
                    if (adm)
                      const Padding(
                        padding: EdgeInsetsDirectional.only(start: 6),
                        child: Icon(Icons.shield_rounded,
                            size: 16, color: AppColors.mint),
                      ),
                    if (muted)
                      const Padding(
                        padding: EdgeInsetsDirectional.only(start: 6),
                        child: Icon(Icons.mic_off_rounded,
                            size: 16, color: Color(0xFFFF6B6B)),
                      ),
                  ]),
                  onTap: m.uid != me.uid
                      ? () {
                          Navigator.of(ctx).pop();
                          _userSheet(m.uid, m.name);
                        }
                      : null,
                );
              },
            );
          },
        ),
      ),
    );
  }

  Future<void> _editRoom() async {
    final name = TextEditingController(text: _room.name);
    final note = TextEditingController(text: _room.announcement);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('إعدادات الغرفة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              maxLength: 30,
              decoration: const InputDecoration(labelText: 'اسم الغرفة'),
            ),
            TextField(
              controller: note,
              maxLength: 120,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'إعلان الغرفة'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      final why = unsafeReason('${name.text} ${note.text}');
      if (why != null) return _toast(why);
      await _run(
        () => _svc.updateRoomInfo(
            _room.id, name.text.trim(), note.text.trim()),
        ok: 'تم حفظ الإعدادات.',
      );
    }
  }

  // ---------- كلمة المرور والأحداث ----------

  Future<void> _passwordDialog() async {
    final ctl = TextEditingController();
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('كلمة مرور الغرفة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
                _room.hasPassword
                    ? 'اكتب كلمة مرور جديدة، أو اتركها فارغة لإزالة الحماية. سيحتاج الداخلون إلى الكلمة الجديدة عند إعادة الدخول.'
                    : 'من 4 إلى 32 حرفًا. لن يدخل الغرفة غيرك إلا من يعرفها.',
                style: const TextStyle(height: 1.5, fontSize: 13)),
            TextField(
              controller: ctl,
              obscureText: true,
              maxLength: 32,
              decoration: const InputDecoration(labelText: 'كلمة المرور'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctl.text.trim()),
              child: const Text('حفظ')),
        ],
      ),
    );
    if (res == null) return;
    if (res.isNotEmpty && res.length < 4) {
      return _toast('كلمة المرور من 4 أحرف على الأقل.');
    }
    await _run(() => AccessService().setRoomPassword(_room.id, res),
        ok: res.isEmpty ? 'أُزيلت الحماية. الغرفة عامة الآن.' : 'تم حفظ كلمة المرور.');
  }

  Future<void> _scheduleEvent() async {
    final draft = await showDialog<EventDraft>(
      context: context,
      builder: (_) => const ScheduleDialog(),
    );
    if (draft == null) return;
    final why = unsafeReason('${draft.title} ${draft.description}');
    if (why != null) return _toast(why);
    await _run(
      () => EventService().create(
        roomId: _room.id,
        title: draft.title,
        description: draft.description,
        startsAt: draft.at,
      ),
      ok: 'تمت جدولة الحدث. سيظهر في الشاشة الرئيسية.',
    );
  }

  // ---------- الملف الشخصي والمراسلة ----------

  void _openProfile(String uid, String name) {
    String? photo;
    for (final m in _members) {
      if (m.uid == uid) photo = m.photo;
    }
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.night,
      builder: (_) => UserProfileSheet(
        feed: _feed,
        meUid: me.uid,
        uid: uid,
        name: name,
        photo: photo,
        onMessage: () {
          if (!mounted) return;
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => DmChatScreen(
              me: me,
              peerUid: uid,
              peerName: name,
              peerPhoto: photo,
            ),
          ));
        },
      ),
    );
  }

  // ---------- الألعاب والإشعارات والبلاغات ----------

  void _gamesSheet() => _sheet('الألعاب', [
        _tile(
          Icons.quiz_rounded,
          _canModerate ? 'ابدأ جولة سؤال وجواب' : 'سؤال وجواب (يبدؤه المشرف)',
          () {
            if (!_canModerate) {
              _toast('يبدأ المشرف أو صاحب الغرفة الجولات، وأنت أجب أسرع الجميع.');
              return;
            }
            _run(() => _games.startTrivia(_room.id));
          },
        ),
        _tile(Icons.casino_rounded, 'عجلة الحظ اليومية (مجانية)', _openWheel,
            color: AppColors.gold),
      ]);

  void _openWheel() {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => LuckyWheelDialog(onSpin: _games.spinWheel),
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => NotificationsScreen(feed: _feed, uid: me.uid)));
  }

  void _reportSheet(String uid, String name) {
    const reasons = {
      'spam': 'إزعاج أو رسائل مكررة',
      'abuse': 'إساءة أو شتائم',
      'inappropriate': 'محتوى غير لائق',
      'scam': 'احتيال أو روابط مشبوهة',
    };
    _sheet('إبلاغ عن $name', [
      for (final e in reasons.entries)
        _tile(Icons.flag_outlined, e.value, () async {
          try {
            await _feed.report(_room.id, uid, e.key);
            _toast('وصلنا بلاغك. شكرًا لحمايتك المجتمع.');
          } on EconomyException catch (x) {
            _toast(x.message);
          } catch (_) {
            _toast('تعذّر إرسال البلاغ.');
          }
        }),
    ]);
  }

  // ---------- الهدايا والإيموجي ----------

  Widget _chip(IconData icon, String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
            color: AppColors.glass, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 4),
          Text(text, style: TextStyle(color: color)),
        ]),
      );

  void _openGifts({String? toUid}) {
    final others = _members.where((m) => m.uid != me.uid).toList();
    if (others.isEmpty) {
      _toast('لا يوجد أحد آخر في الغرفة لتهديه.');
      return;
    }
    String initial = toUid ?? others.first.uid;
    if (toUid == null && others.any((m) => m.uid == _room.ownerId)) {
      initial = _room.ownerId;
    }
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.night,
      builder: (_) => GiftSheet(
        me: _meN,
        recipients: others,
        initialUid: initial,
        ownerId: _room.ownerId,
        onSend: (giftId, uid, qty) =>
            _eco.sendGift(_room.id, giftId, uid, qty),
      ),
    );
  }

  static const _emojis = [
    '😀', '😂', '😍', '🥰', '😎', '🤩', '😢', '😡',
    '👍', '👏', '🙏', '🔥', '❤️', '🎉', '💯', '🤝',
  ];

  void _emojiSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.night,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GridView.count(
            shrinkWrap: true,
            crossAxisCount: 8,
            children: [
              for (final e in _emojis)
                InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _svc.sendEmoji(_room.id, me, e).catchError(
                        (_) => _toast('تعذّر إرسال الإيموجي.'));
                  },
                  child: Center(
                      child: Text(e, style: const TextStyle(fontSize: 26))),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------- الدردشة ----------

  Future<void> _send() async {
    final t = _input.text.trim();
    if (t.isEmpty) return;
    final why = unsafeReason(t);
    if (why != null) return _toast(why);
    final now = DateTime.now();
    if (now.difference(_lastSend) < const Duration(milliseconds: 1200)) {
      return _toast('تمهّل قليلًا قبل إرسال رسالة أخرى.');
    }
    _lastSend = now;
    _input.clear();
    try {
      await _svc.sendMessage(_room.id, me, t);
    } catch (_) {
      _toast('تعذّر إرسال الرسالة.');
    }
  }

  Future<void> _confirmLeave() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('مغادرة الغرفة؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('البقاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('مغادرة')),
        ],
      ),
    );
    if (leave == true && mounted) {
      _leaving = true;
      Navigator.of(context).pop();
    }
  }

  // ---------- الواجهة ----------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField(count: 80)),
            SafeArea(
              child: Column(
                children: [
                  _topBar(),
                  _ownerBlock(),
                  _seatGrid(),
                  TriviaPanel(
                    stream: _triviaStream,
                    onAnswer: (choice) =>
                        _games.answerTrivia(_room.id, choice),
                  ),
                  Expanded(
                    child:
                        ChatList(stream: _chatStream, room: _room, hidden: _blocked),
                  ),
                  _typing ? _inputBar() : _bottomBar(),
                ],
              ),
            ),
            Positioned.fill(child: GiftOverlay(events: _giftStream)),
          ],
        ),
      ),
    );
  }

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 12, 0),
        child: Row(
          children: [
            IconButton(
              onPressed: _confirmLeave,
              icon: const Icon(Icons.power_settings_new_rounded,
                  color: AppColors.gold),
              tooltip: 'مغادرة الغرفة',
            ),
            Expanded(
              child: Text(_room.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
            ),
            _chip(Icons.emoji_events_rounded, fmtCount(_room.points),
                AppColors.gold),
            const SizedBox(width: 6),
            _chip(Icons.headphones_rounded, '${_members.length}',
                AppColors.mint),
          ],
        ),
      );

  Widget _ownerBlock() => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 10),
        child: Column(
          children: [
            Avatar(url: _room.ownerPhoto, name: _room.ownerName, size: 64),
            const SizedBox(height: 4),
            Text(_room.ownerName, style: const TextStyle(fontSize: 13)),
          ],
        ),
      );

  Widget _seatGrid() {
    final seats = _seats.isEmpty
        ? List.generate(RoomService.seatCount, (i) => Seat(index: i + 1))
        : _seats;
    return ValueListenableBuilder<Set<int>>(
      valueListenable: _voice.speaking,
      builder: (context, speaking, _) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: GridView.count(
          crossAxisCount: 4,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          childAspectRatio: .86,
          children: [
            for (final s in seats)
              SeatTile(
                seat: s,
                muted: s.userId == me.uid
                    ? (_micMuted || _adminMuted)
                    : (_restr[s.userId]?.muted ?? false),
                speaking: s.agoraUid != null &&
                    speaking.contains(s.agoraUid) &&
                    !(s.userId == me.uid && (_micMuted || _adminMuted)),
                onTap: () => _onSeatTap(s),
              ),
          ],
        ),
      ),
    );
  }

  Widget _bottomBar() => RoomBottomBar(
        seated: _mySeat != null,
        micMuted: _micMuted || _adminMuted,
        speakerOn: _speakerOn,
        onMic: _toggleMic,
        onSpeaker: _toggleSpeaker,
        onChat: () => setState(() => _typing = true),
        onMenu: _menuSheet,
        onGift: () => _openGifts(),
        onEmoji: _emojiSheet,
        onGames: _gamesSheet,
        onBell: _openNotifications,
      );

  Widget _inputBar() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
        child: Row(
          children: [
            IconButton(
              onPressed: () => setState(() => _typing = false),
              icon: const Icon(Icons.close_rounded),
            ),
            Expanded(
              child: TextField(
                controller: _input,
                autofocus: true,
                maxLength: 200,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  counterText: '',
                  hintText: 'اكتب رسالة...',
                  filled: true,
                  fillColor: AppColors.glass,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            IconButton(
              onPressed: _send,
              icon: const Icon(Icons.send_rounded, color: AppColors.gold),
            ),
          ],
        ),
      );
}
