import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../safety.dart';
import '../services/auth_service.dart';
import '../services/economy_service.dart' show EconomyException;
import '../services/group_service.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/chat_list.dart' show LevelBadge, MessageBubble;
import '../widgets/stars.dart';

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key, required this.auth, required this.me});
  final AuthService auth;
  final AppUser me;

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  final _svc = GroupService();
  late final Stream<AppUser> _profile = widget.auth.profile(widget.me.uid);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                      const Text('مجموعتي',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800)),
                    ],
                  ),
                  Expanded(
                    child: StreamBuilder<AppUser>(
                      initialData: widget.me,
                      stream: _profile,
                      builder: (context, snap) {
                        final u = snap.data ?? widget.me;
                        final gid = u.groupId;
                        if (gid == null) return _NoGroup(svc: _svc);
                        return _GroupView(key: ValueKey(gid), gid: gid, me: u, svc: _svc);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void _snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class _NoGroup extends StatelessWidget {
  const _NoGroup({required this.svc});
  final GroupService svc;

  Future<void> _create(BuildContext context) async {
    final name = TextEditingController();
    final emoji = TextEditingController(text: '🛡️');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('إنشاء مجموعة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
                controller: name,
                maxLength: 24,
                decoration: const InputDecoration(labelText: 'اسم المجموعة')),
            TextField(
                controller: emoji,
                maxLength: 2,
                decoration: const InputDecoration(labelText: 'رمز (إيموجي)')),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('إنشاء')),
        ],
      ),
    );
    if (ok != true || name.text.trim().length < 3) return;
    final why = unsafeReason(name.text);
    if (why != null && context.mounted) return _snack(context, why);
    try {
      await svc.create(name.text.trim(), emoji.text.trim());
    } on EconomyException catch (e) {
      if (context.mounted) _snack(context, e.message);
    }
  }

  Future<void> _join(BuildContext context) async {
    final code = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: const Text('الانضمام بكود'),
        content: TextField(
          controller: code,
          maxLength: 6,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'كود الدعوة (6 أحرف)'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('انضمام')),
        ],
      ),
    );
    if (ok != true || code.text.trim().isEmpty) return;
    try {
      await svc.join(code.text.trim());
    } on EconomyException catch (e) {
      if (context.mounted) _snack(context, e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🛡️', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 10),
            const Text('أنشئ مجموعتك أو انضم لمجموعة صديق',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text(
                'للمجموعة دردشة خاصة، وتتراكم نقاطها من هدايا أعضائها وتتنافس في لوحة المتصدرين.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, height: 1.5)),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(
                onPressed: () => _create(context),
                style: FilledButton.styleFrom(
                    backgroundColor: AppColors.gold,
                    foregroundColor: AppColors.night),
                child: const Text('إنشاء مجموعة',
                    style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton(
                onPressed: () => _join(context),
                child: const Text('لدي كود دعوة'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GroupView extends StatefulWidget {
  const _GroupView({super.key, required this.gid, required this.me, required this.svc});
  final String gid;
  final AppUser me;
  final GroupService svc;

  @override
  State<_GroupView> createState() => _GroupViewState();
}

class _GroupViewState extends State<_GroupView> {
  late final Stream<AppGroup?> _group = widget.svc.group(widget.gid);
  late final Stream<List<GroupMember>> _members = widget.svc.members(widget.gid);
  late final Stream<List<ChatMessage>> _messages = widget.svc.messages(widget.gid);
  late final Future<String?> _code = widget.svc.code(widget.gid);
  final _input = TextEditingController();
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final t = _input.text.trim();
    if (t.isEmpty) return;
    final why = unsafeReason(t);
    if (why != null) return _snack(context, why);
    if (DateTime.now().difference(_last) < const Duration(milliseconds: 1200)) {
      return _snack(context, 'تمهّل قليلًا قبل إرسال رسالة أخرى.');
    }
    _last = DateTime.now();
    _input.clear();
    try {
      await widget.svc.send(widget.gid, widget.me, t);
    } catch (_) {
      if (mounted) _snack(context, 'تعذّر إرسال الرسالة.');
    }
  }

  Future<void> _leave(bool isOwner) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.night,
        title: Text(isOwner ? 'حل المجموعة؟' : 'مغادرة المجموعة؟'),
        content: Text(isOwner
            ? 'أنت المالك، ومغادرتك تحذف المجموعة بكل رسائلها لجميع الأعضاء.'
            : 'يمكنك الانضمام مجددًا بكود الدعوة.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(isOwner ? 'حل المجموعة' : 'مغادرة')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.svc.leave();
    } on EconomyException catch (e) {
      if (mounted) _snack(context, e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AppGroup?>(
      stream: _group,
      builder: (context, gs) {
        final g = gs.data;
        if (g == null) {
          return const Center(
              child: CircularProgressIndicator(color: AppColors.gold));
        }
        final isOwner = g.ownerId == widget.me.uid;
        return DefaultTabController(
          length: 2,
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    color: AppColors.glass,
                    borderRadius: BorderRadius.circular(18)),
                child: Row(
                  children: [
                    Text(g.emoji, style: const TextStyle(fontSize: 40)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(g.name,
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w900)),
                          Row(
                            children: [
                              const Icon(Icons.emoji_events_rounded,
                                  size: 15, color: AppColors.gold),
                              const SizedBox(width: 3),
                              Text('${g.points}',
                                  style: const TextStyle(color: AppColors.gold)),
                              const SizedBox(width: 12),
                              const Icon(Icons.group_rounded,
                                  size: 15, color: AppColors.mint),
                              const SizedBox(width: 3),
                              Text('${g.memberCount}',
                                  style: const TextStyle(color: AppColors.mint)),
                            ],
                          ),
                          FutureBuilder<String?>(
                            future: _code,
                            builder: (context, c) {
                              final code = c.data;
                              if (code == null) return const SizedBox.shrink();
                              return InkWell(
                                onTap: () {
                                  Clipboard.setData(ClipboardData(text: code));
                                  _snack(context, 'نُسخ كود الدعوة');
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 4),
                                  child: Text('كود الدعوة: $code  (اضغط للنسخ)',
                                      style: const TextStyle(
                                          fontSize: 12, color: Colors.white70)),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => _leave(isOwner),
                      tooltip: isOwner ? 'حل المجموعة' : 'مغادرة',
                      icon: const Icon(Icons.exit_to_app_rounded,
                          color: Color(0xFFFF6B6B)),
                    ),
                  ],
                ),
              ),
              const TabBar(
                indicatorColor: AppColors.gold,
                labelColor: AppColors.gold,
                unselectedLabelColor: Colors.white70,
                tabs: [Tab(text: 'الدردشة'), Tab(text: 'الأعضاء')],
              ),
              Expanded(
                child: TabBarView(
                  children: [_chat(), _membersTab(isOwner)],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _chat() => Column(
        children: [
          Expanded(
            child: StreamBuilder<List<ChatMessage>>(
              stream: _messages,
              builder: (context, snap) {
                final msgs = snap.data ?? const <ChatMessage>[];
                if (msgs.isEmpty) {
                  return const Center(
                      child: Text('ابدأ الدردشة مع مجموعتك 👋',
                          style: TextStyle(color: Colors.white70)));
                }
                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) => MessageBubble(m: msgs[i]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 8, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _input,
                    maxLength: 200,
                    onSubmitted: (_) => _send(),
                    decoration: InputDecoration(
                      counterText: '',
                      hintText: 'اكتب رسالة...',
                      filled: true,
                      fillColor: AppColors.glass,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _send,
                  icon: const Icon(Icons.send_rounded, color: AppColors.gold),
                ),
              ],
            ),
          ),
        ],
      );

  Widget _membersTab(bool isOwner) => StreamBuilder<List<GroupMember>>(
        stream: _members,
        builder: (context, snap) {
          final list = snap.data ?? const <GroupMember>[];
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final m = list[i];
              return Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: AppColors.glass,
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    Avatar(url: m.photo, name: m.name, size: 40),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Row(
                        children: [
                          Flexible(
                              child: Text(m.name,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700))),
                          const SizedBox(width: 6),
                          LevelBadge(level: m.level),
                          if (m.role == 'owner')
                            const Padding(
                              padding: EdgeInsetsDirectional.only(start: 6),
                              child: Icon(Icons.workspace_premium_rounded,
                                  size: 18, color: AppColors.gold),
                            ),
                        ],
                      ),
                    ),
                    if (isOwner && m.uid != widget.me.uid)
                      IconButton(
                        tooltip: 'إخراج',
                        onPressed: () async {
                          try {
                            await widget.svc.kick(m.uid);
                          } on EconomyException catch (e) {
                            if (context.mounted) _snack(context, e.message);
                          }
                        },
                        icon: const Icon(Icons.person_remove_rounded,
                            color: Color(0xFFFF6B6B)),
                      ),
                  ],
                ),
              );
            },
          );
        },
      );
}
