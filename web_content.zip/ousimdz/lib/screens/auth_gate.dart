import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models.dart';
import '../services/auth_service.dart';
import '../services/purchase_service.dart';
import '../services/push_service.dart';
import '../theme.dart';
import 'home_screen.dart';
import 'login_screen.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final _auth = AuthService();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: _auth.authState,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const _Loading();
        }
        final user = snap.data;
        if (user == null) return LoginScreen(auth: _auth);
        return _ProfileGate(key: ValueKey(user.uid), auth: _auth, user: user);
      },
    );
  }
}

/// يتأكد من وجود الملف والمحفظة ثم يتابع بيانات المستخدم لحظيًا.
class _ProfileGate extends StatefulWidget {
  const _ProfileGate({super.key, required this.auth, required this.user});
  final AuthService auth;
  final User user;

  @override
  State<_ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<_ProfileGate> {
  late Future<void> _ensure = widget.auth.ensureProfile();
  late final Stream<AppUser> _profile = widget.auth.profile(widget.user.uid);

  @override
  void initState() {
    super.initState();
    _ensure.then((_) => PushService().init(widget.user.uid)).catchError((_) {});
    PurchaseService.instance.start(widget.user.uid);
  }

  @override
  void dispose() {
    PurchaseService.instance.stop();
    super.dispose();
  }

  Widget _error(String text) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(text, textAlign: TextAlign.center),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () =>
                      setState(() => _ensure = widget.auth.ensureProfile()),
                  child: const Text('إعادة المحاولة'),
                ),
                TextButton(
                    onPressed: widget.auth.signOut,
                    child: const Text('تسجيل الخروج')),
              ],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _ensure,
      builder: (context, f) {
        if (f.hasError) {
          return _error('تعذّر إعداد حسابك. تحقق من الاتصال وحاول مرة أخرى.');
        }
        if (f.connectionState != ConnectionState.done) {
          return const _Loading();
        }
        return StreamBuilder<AppUser>(
          stream: _profile,
          builder: (context, p) {
            if (p.hasError) return _error('تعذّر تحميل ملفك الشخصي.');
            if (!p.hasData) return const _Loading();
            return HomeScreen(me: p.data!, auth: widget.auth);
          },
        );
      },
    );
  }
}

class _Loading extends StatelessWidget {
  const _Loading();
  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(child: CircularProgressIndicator(color: AppColors.gold)),
      );
}
