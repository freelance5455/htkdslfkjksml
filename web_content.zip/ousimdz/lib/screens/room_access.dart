import 'package:flutter/material.dart';

import '../models.dart';
import '../services/access_service.dart';
import '../services/economy_service.dart' show EconomyException;
import '../theme.dart';
import 'room_screen.dart';

/// يفتح الغرفة. إن كانت محمية بكلمة مرور يطلبها أولًا ويتحقق منها الخادم.
Future<void> openRoomWithAccess(
    BuildContext context, Room room, AppUser me) async {
  if (room.hasPassword && room.ownerId != me.uid) {
    final pw = await _askPassword(context, room.name);
    if (pw == null || pw.isEmpty) return;
    try {
      await AccessService().unlockRoom(room.id, pw);
    } on EconomyException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
      return;
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تعذّر التحقق من كلمة المرور.')));
      }
      return;
    }
  }
  if (!context.mounted) return;
  await Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => RoomScreen(room: room, me: me)),
  );
}

Future<String?> _askPassword(BuildContext context, String roomName) {
  final ctl = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.night,
      title: Text('غرفة خاصة: $roomName'),
      content: TextField(
        controller: ctl,
        obscureText: true,
        autofocus: true,
        decoration: const InputDecoration(labelText: 'كلمة المرور'),
        onSubmitted: (v) => Navigator.pop(ctx, v.trim()),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, ctl.text.trim()),
            child: const Text('دخول')),
      ],
    ),
  );
}
