import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../services/admin_service.dart';
import '../services/economy_service.dart' show EconomyException;
import '../theme.dart';
import '../widgets/stars.dart';

const _reasonLabels = {
  'spam': 'إزعاج أو رسائل مكررة',
  'abuse': 'إساءة أو شتائم',
  'inappropriate': 'محتوى غير لائق',
  'scam': 'احتيال أو روابط مشبوهة',
};

const _actionLabels = {
  'dismiss': 'تجاهل البلاغ',
  'warn': 'إرسال تحذير',
  'ban1d': 'إيقاف يوم',
  'ban7d': 'إيقاف 7 أيام',
  'banPerm': 'إيقاف دائم',
  'unban': 'رفع الإيقاف',
};

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _svc = AdminService();
  late final Stream<List<ReportItem>> _stream = _svc.reports();
  bool _showResolved = false;

  Future<void> _act(ReportItem r, String action) async {
    if (action.startsWith('ban')) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppColors.night,
          title: Text('${_actionLabels[action]}: ${r.targetName}؟'),
          content: const Text('سيُخرَج من أي غرفة هو فيها ولن يستطيع استخدام التطبيق.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('إلغاء')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFE5484D)),
                child: const Text('تأكيد')),
          ],
        ),
      );
      if (ok != true) return;
    }
    try {
      await _svc.act(r.id, action);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('تم: ${_actionLabels[action]}')));
      }
    } on EconomyException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    }
  }

  Widget _card(ReportItem r) {
    final resolved = r.status == 'resolved';
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: resolved ? AppColors.glass : AppColors.gold.withAlpha(35),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(r.targetName,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                    color: const Color(0xFFE5484D).withAlpha(70),
                    borderRadius: BorderRadius.circular(10)),
                child: Text(_reasonLabels[r.reason] ?? r.reason,
                    style: const TextStyle(fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
              'بلّغ: ${r.reporterName}${r.createdAt != null ? '  •  ${timeAgo(r.createdAt!)}' : ''}',
              style: const TextStyle(color: Colors.white60, fontSize: 12)),
          if (r.evidence.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Text('آخر رسائله في الغرفة:',
                style: TextStyle(color: Colors.white70, fontSize: 12)),
            for (final e in r.evidence)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text('• $e', style: const TextStyle(fontSize: 13)),
              ),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              if (resolved)
                Text('أُغلق: ${_actionLabels[r.action] ?? r.action ?? ''}',
                    style: const TextStyle(color: AppColors.mint, fontSize: 12)),
              const Spacer(),
              PopupMenuButton<String>(
                color: AppColors.night,
                onSelected: (a) => _act(r, a),
                itemBuilder: (_) => [
                  for (final e in _actionLabels.entries)
                    PopupMenuItem(value: e.key, child: Text(e.value)),
                ],
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                      color: AppColors.gold,
                      borderRadius: BorderRadius.circular(14)),
                  child: const Text('إجراء',
                      style: TextStyle(
                          color: AppColors.night, fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: skyGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: StarField()),
            SafeArea(
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                      const Text('لوحة الإدارة — البلاغات',
                          style: TextStyle(
                              fontSize: 19, fontWeight: FontWeight.w800)),
                      const Spacer(),
                      Switch(
                        value: _showResolved,
                        activeColor: AppColors.gold,
                        onChanged: (v) => setState(() => _showResolved = v),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 12),
                        child: Text('المغلقة', style: TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                  Expanded(
                    child: StreamBuilder<List<ReportItem>>(
                      stream: _stream,
                      builder: (context, snap) {
                        if (snap.hasError) {
                          return const Center(
                              child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                                'لا تملك صلاحية الإدارة. أضف وثيقتك في مجموعة admins من لوحة Firebase.',
                                textAlign: TextAlign.center),
                          ));
                        }
                        if (!snap.hasData) {
                          return const Center(
                              child: CircularProgressIndicator(
                                  color: AppColors.gold));
                        }
                        final list = snap.data!
                            .where((r) => _showResolved || r.status == 'new')
                            .toList();
                        if (list.isEmpty) {
                          return const Center(
                              child: Text('لا توجد بلاغات جديدة 🎉',
                                  style: TextStyle(color: Colors.white70)));
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (_, i) => _card(list[i]),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
