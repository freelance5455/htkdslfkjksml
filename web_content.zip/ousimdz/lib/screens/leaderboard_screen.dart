import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../services/feed_service.dart';
import '../services/group_service.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/chat_list.dart' show LevelBadge;
import '../widgets/stars.dart';
import 'room_access.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key, required this.feed, required this.me});
  final FeedService feed;
  final AppUser me;

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  late final Stream<List<LeaderEntry>> _charm = widget.feed.topUsers('charm');
  late final Stream<List<LeaderEntry>> _xp = widget.feed.topUsers('xp');
  late final Stream<List<Room>> _rooms = widget.feed.topRooms();
  late final Stream<List<AppGroup>> _groups = GroupService().top();

  static const _medals = ['🥇', '🥈', '🥉'];

  Widget _rank(int i) => SizedBox(
        width: 36,
        child: Text(i < 3 ? _medals[i] : '${i + 1}',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: i < 3 ? 24 : 15,
                fontWeight: FontWeight.w800,
                color: Colors.white70)),
      );

  Widget _row(int i, Widget avatar, String name, Widget? badge, String value,
      {VoidCallback? onTap, bool highlight = false}) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: highlight ? AppColors.gold.withAlpha(45) : AppColors.glass,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            _rank(i),
            avatar,
            const SizedBox(width: 10),
            Expanded(
              child: Row(
                children: [
                  Flexible(
                    child: Text(name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  if (badge != null) ...[const SizedBox(width: 6), badge],
                ],
              ),
            ),
            Text(value,
                style: const TextStyle(
                    color: AppColors.gold, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }

  Widget _users(Stream<List<LeaderEntry>> stream, String unit) {
    return StreamBuilder<List<LeaderEntry>>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('تعذّر تحميل القائمة.'));
        if (!snap.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: AppColors.gold));
        }
        final list = snap.data!.where((e) => e.value > 0).toList();
        if (list.isEmpty) {
          return const Center(
              child: Text('لا يوجد متصدرون بعد. كن الأول!',
                  style: TextStyle(color: Colors.white70)));
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (_, i) {
            final e = list[i];
            return _row(
              i,
              Avatar(url: e.photo, name: e.name, size: 42),
              e.name,
              LevelBadge(level: e.level),
              '${fmtCount(e.value)} $unit',
              highlight: e.uid == widget.me.uid,
            );
          },
        );
      },
    );
  }

  Widget _roomsTab() {
    return StreamBuilder<List<Room>>(
      stream: _rooms,
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('تعذّر تحميل القائمة.'));
        if (!snap.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: AppColors.gold));
        }
        final list = snap.data!.where((r) => r.points > 0).toList();
        if (list.isEmpty) {
          return const Center(
              child: Text('لا توجد غرف متصدرة بعد.',
                  style: TextStyle(color: Colors.white70)));
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (_, i) {
            final r = list[i];
            return _row(
              i,
              Avatar(url: r.ownerPhoto, name: r.ownerName, size: 42),
              r.name,
              null,
              fmtCount(r.points),
              onTap: () => openRoomWithAccess(context, r, widget.me),
            );
          },
        );
      },
    );
  }

  Widget _groupsTab() {
    return StreamBuilder<List<AppGroup>>(
      stream: _groups,
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('تعذّر تحميل القائمة.'));
        if (!snap.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: AppColors.gold));
        }
        final list = snap.data!.where((g) => g.points > 0).toList();
        if (list.isEmpty) {
          return const Center(
              child: Text('لا توجد مجموعات متصدرة بعد.',
                  style: TextStyle(color: Colors.white70)));
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (_, i) {
            final g = list[i];
            return _row(
              i,
              Text(g.emoji, style: const TextStyle(fontSize: 34)),
              g.name,
              Text('${g.memberCount} عضو',
                  style: const TextStyle(color: Colors.white60, fontSize: 11)),
              fmtCount(g.points),
              highlight: g.id == widget.me.groupId,
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: skyGradient),
          child: Stack(
            children: [
              const Positioned.fill(child: StarField()),
              SafeArea(
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_forward_rounded),
                        ),
                        const Text('المتصدرون',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w800)),
                      ],
                    ),
                    const TabBar(
                      isScrollable: true,
                      indicatorColor: AppColors.gold,
                      labelColor: AppColors.gold,
                      unselectedLabelColor: Colors.white70,
                      tabs: [
                        Tab(text: 'الأكثر هدايا'),
                        Tab(text: 'الأعلى مستوى'),
                        Tab(text: 'أنشط الغرف'),
                        Tab(text: 'أقوى المجموعات'),
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          _users(_charm, 'هدية'),
                          _users(_xp, 'خبرة'),
                          _roomsTab(),
                          _groupsTab(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
