import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const night = Color(0xFF0A0F2E);
  static const indigo = Color(0xFF1B2A78);
  static const lagoon = Color(0xFF0F8C93);
  static const gold = Color(0xFFFFC145);
  static const mint = Color(0xFF7FE3D2);
  static const glass = Color(0x26FFFFFF);
}

const skyGradient = LinearGradient(
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
  colors: [AppColors.night, AppColors.indigo, AppColors.lagoon],
  stops: [0, 0.62, 1],
);

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.night,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.gold,
      secondary: AppColors.mint,
      surface: AppColors.night,
    ),
    textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
  );
}
