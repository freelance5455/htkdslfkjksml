import 'package:cloud_firestore/cloud_firestore.dart';

class AppUser {
  final String uid;
  final String name;
  final String? photo;
  final int level;
  final int xp;
  final int charm;
  final int coins;
  final int agoraUid;
  final DateTime? lastDaily;
  final Map<String, int> stats;
  final Set<String> achievements;
  const AppUser({
    required this.uid,
    required this.name,
    this.photo,
    required this.level,
    this.xp = 0,
    this.charm = 0,
    this.coins = 0,
    required this.agoraUid,
    this.lastDaily,
    this.stats = const <String, int>{},
    this.achievements = const <String>{},
  });

  bool get canClaimDaily =>
      lastDaily == null ||
      DateTime.now().difference(lastDaily!) >= const Duration(hours: 20);

  /// الملف العام (users) + المحفظة الخاصة (wallets).
  factory AppUser.fromMaps(
      String uid, Map<String, dynamic> u, Map<String, dynamic> w) {
    return AppUser(
      uid: uid,
      name: (u['name'] as String?) ?? 'مستخدم',
      photo: u['photo'] as String?,
      level: (u['level'] as num?)?.toInt() ?? 1,
      xp: (u['xp'] as num?)?.toInt() ?? 0,
      charm: (u['charm'] as num?)?.toInt() ?? 0,
      coins: (w['coins'] as num?)?.toInt() ?? 0,
      agoraUid: (u['agoraUid'] as num?)?.toInt() ?? 0,
      lastDaily: (w['lastDaily'] as Timestamp?)?.toDate(),
      stats: {
        for (final e in ((u['stats'] as Map?) ?? const {}).entries)
          e.key as String: (e.value as num).toInt()
      },
      achievements: {
        for (final k in ((u['achievements'] as Map?) ?? const {}).keys)
          k as String
      },
    );
  }
}

class Room {
  final String id;
  final String name;
  final String announcement;
  final String ownerId;
  final String ownerName;
  final String? ownerPhoto;
  final int memberCount;
  final int points;
  final List<String> admins;
  const Room({
    required this.id,
    required this.name,
    required this.announcement,
    required this.ownerId,
    required this.ownerName,
    this.ownerPhoto,
    this.memberCount = 0,
    this.points = 0,
    this.admins = const [],
  });

  factory Room.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Room(
      id: d.id,
      name: (m['name'] as String?) ?? '',
      announcement: (m['announcement'] as String?) ?? '',
      ownerId: (m['ownerId'] as String?) ?? '',
      ownerName: (m['ownerName'] as String?) ?? '',
      ownerPhoto: m['ownerPhoto'] as String?,
      memberCount: (m['memberCount'] as num?)?.toInt() ?? 0,
      points: (m['points'] as num?)?.toInt() ?? 0,
      admins: List<String>.from((m['admins'] as List?) ?? const []),
    );
  }
}

class Seat {
  final int index;
  final String? userId;
  final String? name;
  final String? photo;
  final int? agoraUid;
  final bool locked;
  const Seat({
    required this.index,
    this.userId,
    this.name,
    this.photo,
    this.agoraUid,
    this.locked = false,
  });

  bool get occupied => userId != null;

  factory Seat.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Seat(
      index: (m['index'] as num?)?.toInt() ?? 0,
      userId: m['userId'] as String?,
      name: m['name'] as String?,
      photo: m['photo'] as String?,
      agoraUid: (m['agoraUid'] as num?)?.toInt(),
      locked: (m['locked'] as bool?) ?? false,
    );
  }
}

class ChatMessage {
  final String id;
  final String type; // text | system | emoji
  final String uid;
  final String name;
  final String text;
  final int level;
  const ChatMessage({
    required this.id,
    required this.type,
    this.uid = '',
    required this.name,
    required this.text,
    required this.level,
  });

  factory ChatMessage.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return ChatMessage(
      id: d.id,
      type: (m['type'] as String?) ?? 'text',
      uid: (m['uid'] as String?) ?? '',
      name: (m['name'] as String?) ?? '',
      text: (m['text'] as String?) ?? '',
      level: (m['level'] as num?)?.toInt() ?? 1,
    );
  }
}

class Member {
  final String uid;
  final String name;
  final String? photo;
  final int level;
  const Member({
    required this.uid,
    required this.name,
    this.photo,
    required this.level,
  });

  factory Member.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Member(
      uid: d.id,
      name: (m['name'] as String?) ?? '',
      photo: m['photo'] as String?,
      level: (m['level'] as num?)?.toInt() ?? 1,
    );
  }
}

/// قيود يضعها المشرفون: كتم أو حظر مؤقت. تُكتب من الخادم فقط.
class Restriction {
  final String uid;
  final bool muted;
  final DateTime? banUntil;
  const Restriction({required this.uid, this.muted = false, this.banUntil});

  bool get banned => banUntil != null && banUntil!.isAfter(DateTime.now());

  factory Restriction.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Restriction(
      uid: d.id,
      muted: (m['muted'] as bool?) ?? false,
      banUntil: (m['banUntil'] as Timestamp?)?.toDate(),
    );
  }
}

class AppBanner {
  final String id;
  final String text;
  final String emoji;
  final int? color; // ARGB اختياري
  final bool active;
  const AppBanner({
    required this.id,
    required this.text,
    this.emoji = '📢',
    this.color,
    this.active = true,
  });

  factory AppBanner.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return AppBanner(
      id: d.id,
      text: (m['text'] as String?) ?? '',
      emoji: (m['emoji'] as String?) ?? '📢',
      color: (m['color'] as num?)?.toInt(),
      active: (m['active'] as bool?) ?? true,
    );
  }
}

class AppNotification {
  final String id;
  final String type;
  final String title;
  final String body;
  final bool read;
  final DateTime? createdAt;
  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.read,
    this.createdAt,
  });

  factory AppNotification.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return AppNotification(
      id: d.id,
      type: (m['type'] as String?) ?? '',
      title: (m['title'] as String?) ?? '',
      body: (m['body'] as String?) ?? '',
      read: (m['read'] as bool?) ?? false,
      createdAt: (m['createdAt'] as Timestamp?)?.toDate(),
    );
  }
}

class TriviaGame {
  final String round;
  final String status; // open | done
  final String question;
  final List<String> options;
  final int durationSec;
  final String? winnerName;
  final int? answer; // يظهر عند انتهاء الجولة فقط
  const TriviaGame({
    required this.round,
    required this.status,
    required this.question,
    required this.options,
    required this.durationSec,
    this.winnerName,
    this.answer,
  });

  factory TriviaGame.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return TriviaGame(
      round: (m['round'] as String?) ?? '',
      status: (m['status'] as String?) ?? 'done',
      question: (m['question'] as String?) ?? '',
      options: List<String>.from((m['options'] as List?) ?? const []),
      durationSec: (m['durationSec'] as num?)?.toInt() ?? 20,
      winnerName: m['winnerName'] as String?,
      answer: (m['answer'] as num?)?.toInt(),
    );
  }
}

class LeaderEntry {
  final String uid;
  final String name;
  final String? photo;
  final int level;
  final int value;
  const LeaderEntry({
    required this.uid,
    required this.name,
    this.photo,
    required this.level,
    required this.value,
  });
}

class DmInboxEntry {
  final String peerUid;
  final String peerName;
  final String? peerPhoto;
  final String lastText;
  final DateTime? lastAt;
  final int unread;
  const DmInboxEntry({
    required this.peerUid,
    required this.peerName,
    this.peerPhoto,
    required this.lastText,
    this.lastAt,
    required this.unread,
  });

  factory DmInboxEntry.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return DmInboxEntry(
      peerUid: d.id,
      peerName: (m['peerName'] as String?) ?? 'مستخدم',
      peerPhoto: m['peerPhoto'] as String?,
      lastText: (m['lastText'] as String?) ?? '',
      lastAt: (m['lastAt'] as Timestamp?)?.toDate(),
      unread: (m['unread'] as num?)?.toInt() ?? 0,
    );
  }
}

class DmMessage {
  final String id;
  final String from;
  final String text;
  final DateTime? createdAt;
  const DmMessage({
    required this.id,
    required this.from,
    required this.text,
    this.createdAt,
  });

  factory DmMessage.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return DmMessage(
      id: d.id,
      from: (m['from'] as String?) ?? '',
      text: (m['text'] as String?) ?? '',
      createdAt: (m['createdAt'] as Timestamp?)?.toDate(),
    );
  }
}

/// ما يراه الآخرون من ملفك (بدون الرصيد).
class PublicProfile {
  final String uid;
  final String name;
  final String? photo;
  final int level;
  final int charm;
  final Set<String> achievements;
  const PublicProfile({
    required this.uid,
    required this.name,
    this.photo,
    required this.level,
    required this.charm,
    required this.achievements,
  });
}
