import 'models.dart';

class Achievement {
  final String id;
  final String emoji;
  final String title;
  final String desc;
  final String stat; // 'level' أو مفتاح داخل stats
  final int target;
  final int reward;
  const Achievement(
      this.id, this.emoji, this.title, this.desc, this.stat, this.target, this.reward);
}

/// يجب أن تطابق ACHIEVEMENTS في functions/index.js (المعرّفات والأهداف والمكافآت).
const achievementCatalog = <Achievement>[
  Achievement('room_1', '🏠', 'صاحب البيت', 'أنشئ غرفتك الأولى', 'roomsCreated', 1, 20),
  Achievement('gift_1', '🎁', 'المهدي الأول', 'أرسل أول هدية', 'giftsSent', 1, 20),
  Achievement('gift_50', '💝', 'كريم', 'أرسل 50 هدية', 'giftsSent', 50, 100),
  Achievement('spender_1000', '💎', 'سخي', 'أنفق 1000 عملة على الهدايا', 'coinsSpent', 1000, 150),
  Achievement('loved_1', '💌', 'محبوب', 'استلم أول هدية', 'giftsReceived', 1, 20),
  Achievement('loved_50', '🌟', 'نجم الغرفة', 'استلم 50 هدية', 'giftsReceived', 50, 100),
  Achievement('level_5', '⭐', 'مستوى 5', 'ابلغ المستوى 5', 'level', 5, 50),
  Achievement('level_10', '🏅', 'مستوى 10', 'ابلغ المستوى 10', 'level', 10, 100),
  Achievement('level_25', '🏆', 'مستوى 25', 'ابلغ المستوى 25', 'level', 25, 300),
  Achievement('trivia_1', '🧠', 'الذكي', 'افز بأول جولة سؤال وجواب', 'triviaWins', 1, 20),
  Achievement('trivia_10', '🎓', 'العبقري', 'افز بعشر جولات', 'triviaWins', 10, 150),
  Achievement('wheel_7', '🎡', 'المثابر', 'أدر عجلة الحظ 7 مرات', 'wheelSpins', 7, 50),
  Achievement('daily_7', '📅', 'وفيّ', 'استلم الهدية اليومية 7 مرات', 'dailyClaims', 7, 70),
  Achievement('daily_30', '🔥', 'لا ينقطع', 'استلم الهدية اليومية 30 مرة', 'dailyClaims', 30, 300),
];

int achievementProgress(AppUser u, Achievement a) =>
    a.stat == 'level' ? u.level : (u.stats[a.stat] ?? 0);
