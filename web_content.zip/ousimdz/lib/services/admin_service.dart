import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models.dart';
import 'economy_service.dart' show EconomyException;

/// لوحة الإدارة: متاحة فقط لمن لديه وثيقة في مجموعة admins (تُنشأ من لوحة Firebase).
class AdminService {
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Stream<bool> isAdmin(String uid) =>
      _db.collection('admins').doc(uid).snapshots().map((d) => d.exists);

  /// حالة الإيقاف العام لحسابي (إن وُجدت).
  Stream<GlobalBan?> banStatus(String uid) => _db
      .collection('globalBans')
      .doc(uid)
      .snapshots()
      .map((d) => d.exists ? GlobalBan.fromDoc(d) : null);

  Stream<List<ReportItem>> reports() => _db
      .collection('reports')
      .orderBy('createdAt', descending: true)
      .limit(60)
      .snapshots()
      .map((s) => s.docs.map(ReportItem.fromDoc).toList());

  /// action: dismiss | warn | ban1d | ban7d | banPerm | unban
  Future<void> act(String reportId, String action) async {
    try {
      await _fn
          .httpsCallable('adminAction')
          .call({'reportId': reportId, 'action': action});
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر تنفيذ الإجراء.');
    }
  }
}
