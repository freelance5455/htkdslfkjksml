import 'package:cloud_functions/cloud_functions.dart';

class EconomyException implements Exception {
  final String message;
  EconomyException(this.message);
  @override
  String toString() => message;
}

/// كل العمليات المالية تتم على الخادم. التطبيق لا يعدّل الرصيد أبدًا.
class EconomyService {
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Future<Map<String, dynamic>> _call(
      String name, Map<String, dynamic> data) async {
    try {
      final r = await _fn.httpsCallable(name).call(data);
      return Map<String, dynamic>.from(r.data as Map);
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر تنفيذ العملية.');
    }
  }

  /// يرجع عدد العملات المستلمة.
  Future<int> claimDaily() async {
    final r = await _call('claimDaily', {});
    return (r['coins'] as num).toInt();
  }

  Future<void> sendGift(
          String roomId, String giftId, String toUid, int qty) =>
      _call('sendGift', {
        'roomId': roomId,
        'giftId': giftId,
        'targetUid': toUid,
        'qty': qty,
      });
}
