import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models.dart';
import 'economy_service.dart' show EconomyException;

/// المحادثات الخاصة. الإرسال عبر الخادم (يتحقق من الحظر والروابط ويحدّ المعدل).
class DmService {
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  static String chatId(String a, String b) =>
      a.compareTo(b) < 0 ? '${a}_$b' : '${b}_$a';

  CollectionReference<Map<String, dynamic>> _inbox(String uid) =>
      _db.collection('users').doc(uid).collection('inbox');

  Stream<List<DmInboxEntry>> inbox(String uid) => _inbox(uid)
      .orderBy('lastAt', descending: true)
      .limit(50)
      .snapshots()
      .map((s) => s.docs.map(DmInboxEntry.fromDoc).toList());

  Stream<int> unreadChats(String uid) => _inbox(uid)
      .where('unread', isGreaterThan: 0)
      .limit(20)
      .snapshots()
      .map((s) => s.size);

  Stream<List<DmMessage>> messages(String uid, String peer) => _db
      .collection('chats')
      .doc(chatId(uid, peer))
      .collection('messages')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots()
      .map((s) => s.docs.map(DmMessage.fromDoc).toList());

  Future<void> send(String toUid, String text) async {
    try {
      await _fn.httpsCallable('sendDm').call({'toUid': toUid, 'text': text});
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر إرسال الرسالة.');
    }
  }

  Future<void> markRead(String uid, String peer) async {
    try {
      await _inbox(uid).doc(peer).update({'unread': 0});
    } catch (_) {}
  }
}
