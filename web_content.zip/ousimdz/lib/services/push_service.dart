import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

/// يسجّل رمز الإشعارات لهذا الجهاز. أي فشل هنا لا يمنع التطبيق من العمل،
/// فالإشعارات داخل التطبيق تعمل دائمًا حتى بدون الإشعارات الخارجية.
class PushService {
  final _db = FirebaseFirestore.instance;

  Future<void> init(String uid) async {
    try {
      final m = FirebaseMessaging.instance;
      await m.requestPermission();
      final token = await m.getToken();
      if (token != null) await _save(uid, token);
      m.onTokenRefresh.listen((t) => _save(uid, t).catchError((_) {}));
    } catch (_) {}
  }

  Future<void> _save(String uid, String token) =>
      _db.collection('devices').doc(uid).set({
        'tokens': FieldValue.arrayUnion([token]),
      }, SetOptions(merge: true));
}
