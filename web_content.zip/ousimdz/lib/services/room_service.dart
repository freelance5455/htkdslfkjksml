import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart' show FirebaseException;

import '../gifts.dart';
import '../models.dart';

class RoomService {
  static const seatCount = 12;
  final _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _rooms =>
      _db.collection('rooms');

  Stream<List<Room>> rooms() => _rooms
      .orderBy('memberCount', descending: true)
      .limit(50)
      .snapshots()
      .map((s) => s.docs.map(Room.fromDoc).toList());

  Stream<Room?> roomStream(String roomId) => _rooms
      .doc(roomId)
      .snapshots()
      .map((d) => d.exists ? Room.fromDoc(d) : null);

  Future<Room> createRoom({
    required AppUser owner,
    required String name,
    String announcement = '',
  }) async {
    final ref = _rooms.doc();
    final batch = _db.batch();
    batch.set(ref, {
      'name': name,
      'announcement': announcement,
      'ownerId': owner.uid,
      'ownerName': owner.name,
      'ownerPhoto': owner.photo,
      'admins': <String>[],
      'memberCount': 0,
      'points': 0,
      'hasPassword': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
    for (var i = 1; i <= seatCount; i++) {
      batch.set(ref.collection('seats').doc('$i'), {
        'index': i,
        'userId': null,
        'name': null,
        'photo': null,
        'agoraUid': null,
        'locked': false,
      });
    }
    await batch.commit();
    return Room(
      id: ref.id,
      name: name,
      announcement: announcement,
      ownerId: owner.uid,
      ownerName: owner.name,
      ownerPhoto: owner.photo,
    );
  }

  Future<void> updateRoomInfo(String roomId, String name, String announcement) =>
      _rooms.doc(roomId).update({'name': name, 'announcement': announcement});

  Stream<List<Seat>> seats(String roomId) => _rooms
      .doc(roomId)
      .collection('seats')
      .orderBy('index')
      .snapshots()
      .map((s) => s.docs.map(Seat.fromDoc).toList());

  Stream<List<Member>> members(String roomId) => _rooms
      .doc(roomId)
      .collection('members')
      .snapshots()
      .map((s) => s.docs.map(Member.fromDoc).toList());

  Stream<Map<String, Restriction>> restrictions(String roomId) => _rooms
      .doc(roomId)
      .collection('restrictions')
      .snapshots()
      .map((s) => {for (final d in s.docs) d.id: Restriction.fromDoc(d)});

  Stream<List<ChatMessage>> messages(String roomId) => _rooms
      .doc(roomId)
      .collection('messages')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots()
      .map((s) => s.docs.map(ChatMessage.fromDoc).toList());

  // ---------- الحضور ----------
  // العدّاد والمقاعد تديرهما دوال الخادم بناءً على وثيقة العضو،
  // فلا يبقى أحد "عالقًا" إذا أُغلق التطبيق فجأة.

  Future<void> enterRoom(String roomId, AppUser me) async {
    await _memberRef(roomId, me.uid).set(_memberData(me, joined: true));
    await sendSystem(roomId, me, 'انضم ${me.name} إلى الغرفة');
  }

  Map<String, dynamic> _memberData(AppUser me, {bool joined = false}) => {
        'uid': me.uid,
        'name': me.name,
        'photo': me.photo,
        'level': me.level,
        'joinedAt': FieldValue.serverTimestamp(),
        'lastSeen': FieldValue.serverTimestamp(),
      };

  DocumentReference<Map<String, dynamic>> _memberRef(String roomId, String uid) =>
      _rooms.doc(roomId).collection('members').doc(uid);

  Future<void> heartbeat(String roomId, AppUser me) async {
    try {
      await _memberRef(roomId, me.uid)
          .update({'lastSeen': FieldValue.serverTimestamp()});
    } on FirebaseException catch (e) {
      // حذفه الخادم بسبب انقطاع طويل: أعد تسجيل حضوره.
      if (e.code == 'not-found') {
        await _memberRef(roomId, me.uid).set(_memberData(me));
      }
    }
  }

  Future<void> exitRoom(String roomId, String uid, int? seatIndex) async {
    if (seatIndex != null) {
      try {
        await leaveSeat(roomId, seatIndex);
      } catch (_) {}
    }
    await _memberRef(roomId, uid).delete();
  }

  // ---------- المقاعد ----------

  /// يحجز المقعد داخل معاملة حتى لا يجلس شخصان على المقعد نفسه.
  Future<bool> takeSeat(String roomId, int index, AppUser me) {
    final ref = _rooms.doc(roomId).collection('seats').doc('$index');
    return _db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      final d = snap.data();
      if (d == null || d['userId'] != null || d['locked'] == true) {
        return false;
      }
      tx.update(ref, {
        'userId': me.uid,
        'name': me.name,
        'photo': me.photo,
        'agoraUid': me.agoraUid,
      });
      return true;
    });
  }

  Future<void> leaveSeat(String roomId, int index) {
    return _rooms.doc(roomId).collection('seats').doc('$index').update({
      'userId': null,
      'name': null,
      'photo': null,
      'agoraUid': null,
    });
  }

  // ---------- الهدايا ----------

  /// أحداث الهدايا الجديدة فقط (تُكتب من الخادم) لتشغيل التأثيرات.
  Stream<GiftEvent> giftEvents(String roomId) async* {
    final since =
        Timestamp.fromMillis(DateTime.now().millisecondsSinceEpoch - 2000);
    final seen = <String>{};
    final q = _rooms
        .doc(roomId)
        .collection('gifts')
        .where('createdAt', isGreaterThan: since)
        .orderBy('createdAt');
    await for (final snap in q.snapshots()) {
      for (final c in snap.docChanges) {
        if (c.type == DocumentChangeType.added && seen.add(c.doc.id)) {
          yield GiftEvent.fromDoc(c.doc);
        }
      }
    }
  }

  Future<void> sendEmoji(String roomId, AppUser me, String emoji) =>
      _add(roomId, me, 'emoji', emoji);

  // ---------- الدردشة ----------

  Future<void> sendMessage(String roomId, AppUser me, String text) =>
      _add(roomId, me, 'text', text);

  Future<void> sendSystem(String roomId, AppUser me, String text) =>
      _add(roomId, me, 'system', text);

  Future<void> _add(String roomId, AppUser me, String type, String text) {
    return _rooms.doc(roomId).collection('messages').add({
      'type': type,
      'uid': me.uid,
      'name': me.name,
      'level': me.level,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
