import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models.dart';
import 'economy_service.dart' show EconomyException;

/// البانرات، الإشعارات، المتصدرون، والبلاغات.
class FeedService {
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Stream<List<AppBanner>> banners() => _db
      .collection('banners')
      .orderBy('order')
      .limit(10)
      .snapshots()
      .map((s) =>
          s.docs.map(AppBanner.fromDoc).where((b) => b.active).toList());

  CollectionReference<Map<String, dynamic>> _notifs(String uid) =>
      _db.collection('users').doc(uid).collection('notifications');

  Stream<int> unreadCount(String uid) => _notifs(uid)
      .where('read', isEqualTo: false)
      .limit(20)
      .snapshots()
      .map((s) => s.size);

  Stream<List<AppNotification>> notifications(String uid) => _notifs(uid)
      .orderBy('createdAt', descending: true)
      .limit(50)
      .snapshots()
      .map((s) => s.docs.map(AppNotification.fromDoc).toList());

  Future<void> markAllRead(String uid) async {
    final snap = await _notifs(uid).where('read', isEqualTo: false).limit(50).get();
    if (snap.docs.isEmpty) return;
    final batch = _db.batch();
    for (final d in snap.docs) {
      batch.update(d.reference, {'read': true});
    }
    await batch.commit();
  }

  /// field: 'charm' (الأكثر استلامًا للهدايا) أو 'xp' (الأعلى مستوى).
  Stream<List<LeaderEntry>> topUsers(String field) => _db
      .collection('users')
      .orderBy(field, descending: true)
      .limit(20)
      .snapshots()
      .map((s) => s.docs.map((d) {
            final m = d.data();
            return LeaderEntry(
              uid: d.id,
              name: (m['name'] as String?) ?? 'مستخدم',
              photo: m['photo'] as String?,
              level: (m['level'] as num?)?.toInt() ?? 1,
              value: (m[field] as num?)?.toInt() ?? 0,
            );
          }).toList());

  Stream<List<Room>> topRooms() => _db
      .collection('rooms')
      .orderBy('points', descending: true)
      .limit(20)
      .snapshots()
      .map((s) => s.docs.map(Room.fromDoc).toList());

  Future<PublicProfile?> publicProfile(String uid) async {
    final d = await _db.collection('users').doc(uid).get();
    final m = d.data();
    if (m == null) return null;
    return PublicProfile(
      uid: uid,
      name: (m['name'] as String?) ?? 'مستخدم',
      photo: m['photo'] as String?,
      level: (m['level'] as num?)?.toInt() ?? 1,
      charm: (m['charm'] as num?)?.toInt() ?? 0,
      achievements: {
        for (final k in ((m['achievements'] as Map?) ?? const {}).keys)
          k as String
      },
    );
  }

  CollectionReference<Map<String, dynamic>> _blocked(String uid) =>
      _db.collection('users').doc(uid).collection('blocked');

  Stream<Set<String>> blockedUids(String uid) => _blocked(uid)
      .snapshots()
      .map((s) => s.docs.map((d) => d.id).toSet());

  Future<void> block(String uid, String peer) =>
      _blocked(uid).doc(peer).set({'createdAt': FieldValue.serverTimestamp()});

  Future<void> unblock(String uid, String peer) =>
      _blocked(uid).doc(peer).delete();

  /// حذف الحساب وبياناته نهائيًا (مطلوب في سياسات Google Play).
  Future<void> deleteAccount() async {
    try {
      await _fn.httpsCallable('deleteAccount').call();
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر حذف الحساب.');
    }
  }

  Future<void> report(String roomId, String targetUid, String reason) async {
    try {
      await _fn.httpsCallable('reportUser').call({
        'roomId': roomId,
        'targetUid': targetUid,
        'reason': reason,
      });
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر إرسال البلاغ.');
    }
  }
}
