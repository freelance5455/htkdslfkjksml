import 'package:cloud_functions/cloud_functions.dart';

import 'economy_service.dart' show EconomyException;

/// الغرف الخاصة بكلمة مرور. كلمة المرور لا تُخزَّن إلا مشفّرة على الخادم.
class AccessService {
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Future<void> _call(String name, Map<String, dynamic> data) async {
    try {
      await _fn.httpsCallable(name).call(data);
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر تنفيذ العملية.');
    }
  }

  Future<void> unlockRoom(String roomId, String password) =>
      _call('unlockRoom', {'roomId': roomId, 'password': password});

  /// كلمة مرور فارغة = إزالة الحماية.
  Future<void> setRoomPassword(String roomId, String password) =>
      _call('setRoomPassword', {'roomId': roomId, 'password': password});
}
