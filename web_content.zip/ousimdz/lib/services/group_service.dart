import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models.dart';
import 'economy_service.dart' show EconomyException;

/// المجموعات (العائلات): دردشة خاصة، رمز دعوة، ونقاط تتراكم من هدايا الأعضاء.
class GroupService {
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  DocumentReference<Map<String, dynamic>> _g(String gid) =>
      _db.collection('groups').doc(gid);

  Future<Map<String, dynamic>> _call(
      String name, Map<String, dynamic> data) async {
    try {
      final r = await _fn.httpsCallable(name).call(data);
      return Map<String, dynamic>.from(r.data as Map);
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر تنفيذ العملية.');
    }
  }

  Stream<AppGroup?> group(String gid) =>
      _g(gid).snapshots().map((d) => d.exists ? AppGroup.fromDoc(d) : null);

  Stream<List<GroupMember>> members(String gid) => _g(gid)
      .collection('members')
      .snapshots()
      .map((s) => s.docs.map(GroupMember.fromDoc).toList()
        ..sort((a, b) => a.role == b.role
            ? b.level.compareTo(a.level)
            : (a.role == 'owner' ? -1 : 1)));

  Stream<List<ChatMessage>> messages(String gid) => _g(gid)
      .collection('messages')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots()
      .map((s) => s.docs.map(ChatMessage.fromDoc).toList());

  Stream<List<AppGroup>> top() => _db
      .collection('groups')
      .orderBy('points', descending: true)
      .limit(20)
      .snapshots()
      .map((s) => s.docs.map(AppGroup.fromDoc).toList());

  Future<String?> code(String gid) async {
    final d = await _db.collection('groupCodes').doc(gid).get();
    return d.data()?['code'] as String?;
  }

  Future<void> send(String gid, AppUser me, String text) =>
      _g(gid).collection('messages').add({
        'type': 'text',
        'uid': me.uid,
        'name': me.name,
        'level': me.level,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });

  Future<void> create(String name, String emoji) =>
      _call('createGroup', {'name': name, 'emoji': emoji});

  Future<void> join(String code) => _call('joinGroup', {'code': code});

  Future<void> leave() => _call('leaveGroup', {});

  Future<void> kick(String uid) => _call('kickGroupMember', {'targetUid': uid});
}
