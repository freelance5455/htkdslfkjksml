import 'package:cloud_functions/cloud_functions.dart';

class ModerationException implements Exception {
  final String message;
  ModerationException(this.message);
  @override
  String toString() => message;
}

/// كل إجراءات الإشراف تمر عبر دالة الخادم `moderate` التي تتحقق من الصلاحية.
class ModerationService {
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Future<void> _call(Map<String, dynamic> data) async {
    try {
      await _fn.httpsCallable('moderate').call(data);
    } on FirebaseFunctionsException catch (e) {
      throw ModerationException(e.message ?? 'تعذّر تنفيذ الإجراء.');
    }
  }

  Future<void> kickFromSeat(String roomId, String uid) =>
      _call({'roomId': roomId, 'action': 'kickSeat', 'targetUid': uid});

  Future<void> setMuted(String roomId, String uid, bool muted) => _call({
        'roomId': roomId,
        'action': muted ? 'mute' : 'unmute',
        'targetUid': uid,
      });

  Future<void> ban(String roomId, String uid, {int minutes = 60}) => _call({
        'roomId': roomId,
        'action': 'ban',
        'targetUid': uid,
        'minutes': minutes,
      });

  Future<void> lockSeat(String roomId, int index, bool lock) => _call({
        'roomId': roomId,
        'action': lock ? 'lockSeat' : 'unlockSeat',
        'seatIndex': index,
      });

  Future<void> deleteRoom(String roomId) =>
      _call({'roomId': roomId, 'action': 'deleteRoom'});

  Future<void> setAdmin(String roomId, String uid, bool value) => _call({
        'roomId': roomId,
        'action': 'setAdmin',
        'targetUid': uid,
        'value': value,
      });
}
