import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

/// يدير الاتصال الصوتي عبر Agora.
/// المستمع = audience، وصاحب المقعد = broadcaster.
class VoiceService {
  RtcEngine? _engine;
  String _roomId = '';
  int _myUid = 0;

  /// معرّفات Agora للأشخاص الذين يتحدثون الآن (لإضاءة حلقة المقعد).
  final ValueNotifier<Set<int>> speaking = ValueNotifier({});

  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Future<Map<String, dynamic>> _fetchToken(String roomId) async {
    final res = await _fn.httpsCallable('agoraToken').call({'roomId': roomId});
    return Map<String, dynamic>.from(res.data as Map);
  }

  Future<void> join(String roomId) async {
    _roomId = roomId;
    final data = await _fetchToken(roomId);
    _myUid = (data['uid'] as num).toInt();

    final engine = createAgoraRtcEngine();
    _engine = engine;
    await engine.initialize(RtcEngineContext(
      appId: data['appId'] as String,
      channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
    ));

    engine.registerEventHandler(RtcEngineEventHandler(
      onAudioVolumeIndication: (conn, speakers, n, total) {
        final s = <int>{};
        for (final x in speakers) {
          if ((x.volume ?? 0) > 20) {
            final uid = x.uid ?? 0;
            s.add(uid == 0 ? _myUid : uid);
          }
        }
        speaking.value = s;
      },
      onTokenPrivilegeWillExpire: (conn, token) async {
        final d = await _fetchToken(_roomId);
        await engine.renewToken(d['token'] as String);
      },
    ));

    await engine.enableAudio();
    // الصوت من السماعة الخارجية افتراضيًا (وليس سماعة الأذن)
    await engine.setDefaultAudioRouteToSpeakerphone(true);
    await engine.setAudioProfile(
      profile: AudioProfileType.audioProfileDefault,
      scenario: AudioScenarioType.audioScenarioGameStreaming,
    );
    await engine.enableAudioVolumeIndication(
        interval: 300, smooth: 3, reportVad: true);

    await engine.joinChannel(
      token: data['token'] as String,
      channelId: roomId,
      uid: _myUid,
      options: const ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleAudience,
        channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
        autoSubscribeAudio: true,
        publishMicrophoneTrack: false,
      ),
    );
  }

  /// يطلب إذن المايك ثم يبدأ البث. يرجع false إذا رُفض الإذن.
  Future<bool> startSpeaking() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) return false;
    await _engine?.updateChannelMediaOptions(const ChannelMediaOptions(
      clientRoleType: ClientRoleType.clientRoleBroadcaster,
      publishMicrophoneTrack: true,
    ));
    await _engine?.muteLocalAudioStream(false);
    return true;
  }

  Future<void> stopSpeaking() async {
    await _engine?.updateChannelMediaOptions(const ChannelMediaOptions(
      clientRoleType: ClientRoleType.clientRoleAudience,
      publishMicrophoneTrack: false,
    ));
  }

  Future<void> setMicMuted(bool muted) async =>
      _engine?.muteLocalAudioStream(muted);

  Future<void> setSpeakerOn(bool on) async =>
      _engine?.muteAllRemoteAudioStreams(!on);

  Future<void> dispose() async {
    final e = _engine;
    _engine = null;
    if (e != null) {
      await e.leaveChannel();
      await e.release();
    }
    speaking.dispose();
  }
}
