import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../models.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');
  static const _webClientId = String.fromEnvironment('GOOGLE_WEB_CLIENT_ID');
  final _google = GoogleSignIn(
      serverClientId: _webClientId.isEmpty ? null : _webClientId);

  Stream<User?> get authState => _auth.authStateChanges();

  Future<void> signInWithGoogle() async {
    final account = await _google.signIn();
    if (account == null) return; // المستخدم ألغى
    final tokens = await account.authentication;
    if (tokens.idToken == null) {
      throw StateError('missing idToken');
    }
    final cred = GoogleAuthProvider.credential(
      accessToken: tokens.accessToken,
      idToken: tokens.idToken,
    );
    await _auth.signInWithCredential(cred);
  }

  /// ينشئ الملف الشخصي والمحفظة من الخادم (الرصيد لا يُنشأ من التطبيق).
  Future<void> ensureProfile() => _fn.httpsCallable('ensureProfile').call();

  /// يدمج الملف العام مع المحفظة الخاصة في كائن واحد حيّ.
  Stream<AppUser> profile(String uid) {
    late StreamController<AppUser> c;
    StreamSubscription<dynamic>? a;
    StreamSubscription<dynamic>? b;
    Map<String, dynamic>? u;
    Map<String, dynamic>? w;

    void emit() {
      if (u != null && w != null) c.add(AppUser.fromMaps(uid, u!, w!));
    }

    c = StreamController<AppUser>(
      onListen: () {
        a = _db.collection('users').doc(uid).snapshots().listen((s) {
          final d = s.data();
          if (d != null) {
            u = d;
            emit();
          }
        }, onError: c.addError);
        b = _db.collection('wallets').doc(uid).snapshots().listen((s) {
          w = s.data() ?? <String, dynamic>{};
          emit();
        }, onError: c.addError);
      },
      onCancel: () async {
        await a?.cancel();
        await b?.cancel();
      },
    );
    return c.stream;
  }

  Future<void> updateName(String uid, String name) =>
      _db.collection('users').doc(uid).update({'name': name});

  Future<void> signOut() async {
    await _google.signOut();
    await _auth.signOut();
  }
}
