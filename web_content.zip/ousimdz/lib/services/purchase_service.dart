import 'dart:async';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';

/// معرّفات المنتجات في Google Play Console وعدد العملات لكل منها.
/// يجب أن تطابق COIN_PACKS في functions/index.js.
const coinPacks = <String, int>{
  'coins_100': 100,
  'coins_550': 550,
  'coins_1200': 1200,
  'coins_3000': 3000,
  'coins_7000': 7000,
};

/// شحن العملات بالمال الحقيقي عبر Google Play Billing.
/// التطبيق لا يمنح العملات أبدًا. الخادم يتحقق من الشراء لدى Google أولًا.
class PurchaseService {
  PurchaseService._();
  static final PurchaseService instance = PurchaseService._();

  final _iap = InAppPurchase.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');
  final _inFlight = <String>{};
  final _messages = StreamController<String>.broadcast();
  StreamSubscription<List<PurchaseDetails>>? _sub;
  String? _uid;

  Stream<String> get messages => _messages.stream;

  /// يبدأ الاستماع من لحظة تسجيل الدخول لمعالجة أي عملية معلّقة.
  void start(String uid) {
    _uid = uid;
    _sub ??= _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    _uid = null;
  }

  Future<List<ProductDetails>> loadProducts() async {
    try {
      if (!await _iap.isAvailable()) return [];
      final r = await _iap.queryProductDetails(coinPacks.keys.toSet());
      final list = r.productDetails.toList()
        ..sort((a, b) =>
            (coinPacks[a.id] ?? 0).compareTo(coinPacks[b.id] ?? 0));
      return list;
    } catch (_) {
      return [];
    }
  }

  Future<void> buy(ProductDetails p) async {
    final uid = _uid;
    if (uid == null) return;
    try {
      // applicationUserName يُربط بالشراء ويتحقق منه الخادم لمنع إعادة استخدام الرموز.
      await _iap.buyConsumable(
        purchaseParam: PurchaseParam(productDetails: p, applicationUserName: uid),
        autoConsume: false,
      );
    } catch (_) {
      _messages.add('تعذّر بدء عملية الشراء.');
    }
  }

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final p in list) {
      switch (p.status) {
        case PurchaseStatus.pending:
          _messages.add('عملية الشراء قيد المعالجة...');
          break;
        case PurchaseStatus.error:
          _messages.add('فشلت عملية الشراء.');
          await _complete(p);
          break;
        case PurchaseStatus.canceled:
          _messages.add('أُلغيت عملية الشراء.');
          break;
        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          await _verify(p);
          break;
      }
    }
  }

  Future<void> _verify(PurchaseDetails p) async {
    final token = p.verificationData.serverVerificationData;
    if (!_inFlight.add(token)) return;
    try {
      final r = await _fn
          .httpsCallable('verifyPurchase')
          .call({'productId': p.productID, 'token': token});
      final data = Map<String, dynamic>.from(r.data as Map);
      await _consume(p);
      await _complete(p);
      _messages.add(data['granted'] == true
          ? 'تمت إضافة ${data['coins']} عملة إلى رصيدك 🎉'
          : 'تمت معالجة هذه العملية سابقًا.');
    } on FirebaseFunctionsException catch (e) {
      // لا نستهلك الشراء، فيُعاد التحقق منه تلقائيًا عند التشغيل القادم.
      _messages.add(e.message ?? 'تعذّر التحقق من الشراء.');
    } catch (_) {
      _messages.add('تعذّر التحقق من الشراء. ستُعاد المحاولة تلقائيًا.');
    } finally {
      _inFlight.remove(token);
    }
  }

  Future<void> _consume(PurchaseDetails p) async {
    try {
      final android =
          _iap.getPlatformAddition<InAppPurchaseAndroidPlatformAddition>();
      await android.consumePurchase(p as GooglePlayPurchaseDetails);
    } catch (_) {}
  }

  Future<void> _complete(PurchaseDetails p) async {
    try {
      if (p.pendingCompletePurchase) await _iap.completePurchase(p);
    } catch (_) {}
  }
}
