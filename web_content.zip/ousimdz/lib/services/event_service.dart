import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models.dart';
import 'economy_service.dart' show EconomyException;

/// جدولة الأحداث داخل الغرف، مع "ذكّرني" وتنبيه قبل البدء بنحو 10 دقائق.
class EventService {
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  /// الأحداث القادمة، مع الأحداث التي بدأت قبل أقل من ساعتين.
  Stream<List<AppEvent>> upcoming() {
    final since = Timestamp.fromMillis(
        DateTime.now().millisecondsSinceEpoch - 2 * 3600 * 1000);
    return _db
        .collection('events')
        .where('startsAt', isGreaterThan: since)
        .orderBy('startsAt')
        .limit(20)
        .snapshots()
        .map((s) => s.docs.map(AppEvent.fromDoc).toList());
  }

  DocumentReference<Map<String, dynamic>> _rsvp(String eid, String uid) =>
      _db.collection('events').doc(eid).collection('rsvps').doc(uid);

  Stream<bool> isGoing(String eid, String uid) =>
      _rsvp(eid, uid).snapshots().map((d) => d.exists);

  Future<void> setGoing(String eid, String uid, bool going) => going
      ? _rsvp(eid, uid).set({'createdAt': FieldValue.serverTimestamp()})
      : _rsvp(eid, uid).delete();

  Future<void> create({
    required String roomId,
    required String title,
    required String description,
    required DateTime startsAt,
  }) async {
    try {
      await _fn.httpsCallable('createEvent').call({
        'roomId': roomId,
        'title': title,
        'description': description,
        'startsAtMs': startsAt.millisecondsSinceEpoch,
      });
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر إنشاء الحدث.');
    }
  }

  Future<void> delete(String eid) async {
    try {
      await _fn.httpsCallable('deleteEvent').call({'eventId': eid});
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر حذف الحدث.');
    }
  }

  Future<Room?> getRoom(String roomId) async {
    final d = await _db.collection('rooms').doc(roomId).get();
    return d.exists ? Room.fromDoc(d) : null;
  }
}
