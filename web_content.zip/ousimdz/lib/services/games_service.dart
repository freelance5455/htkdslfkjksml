import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models.dart';
import 'economy_service.dart' show EconomyException;

class TriviaResult {
  final bool correct;
  final bool won;
  final int reward;
  const TriviaResult(this.correct, this.won, this.reward);
}

class WheelResult {
  final int index;
  final int coins;
  const WheelResult(this.index, this.coins);
}

/// الألعاب: السؤال والجواب داخل الغرفة، وعجلة الحظ اليومية.
/// الإجابة الصحيحة والنتائج تُحسب على الخادم فقط.
class GamesService {
  final _db = FirebaseFirestore.instance;
  final _fn = FirebaseFunctions.instanceFor(region: 'europe-west1');

  Future<Map<String, dynamic>> _call(
      String name, Map<String, dynamic> data) async {
    try {
      final r = await _fn.httpsCallable(name).call(data);
      return Map<String, dynamic>.from(r.data as Map);
    } on FirebaseFunctionsException catch (e) {
      throw EconomyException(e.message ?? 'تعذّر تنفيذ العملية.');
    }
  }

  Stream<TriviaGame?> triviaStream(String roomId) => _db
      .collection('rooms')
      .doc(roomId)
      .collection('games')
      .doc('current')
      .snapshots()
      .map((d) => d.exists ? TriviaGame.fromDoc(d) : null);

  Future<void> startTrivia(String roomId) =>
      _call('startTrivia', {'roomId': roomId});

  Future<TriviaResult> answerTrivia(String roomId, int choice) async {
    final r = await _call('answerTrivia', {'roomId': roomId, 'choice': choice});
    return TriviaResult(
      r['correct'] == true,
      r['won'] == true,
      (r['reward'] as num?)?.toInt() ?? 0,
    );
  }

  Future<WheelResult> spinWheel() async {
    final r = await _call('spinWheel', {});
    return WheelResult((r['index'] as num).toInt(), (r['coins'] as num).toInt());
  }
}
