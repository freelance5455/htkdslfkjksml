const KEY='whiteRoomHunterDataV1';
const defaults=[
 {id:1,name:'Study Mathematics for 30 minutes',category:'study',xp:30,done:false},
 {id:2,name:'Revise one Science topic',category:'study',xp:30,done:false},
 {id:3,name:'Complete today’s homework',category:'study',xp:30,done:false},
 {id:4,name:'Practice drawing for 20 minutes',category:'creative',xp:15,done:false},
 {id:5,name:'Complete a light activity break',category:'fitness',xp:15,done:false}
];
let data=load();
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{xp:0,level:1,streak:0,lastDate:'',quests:defaults,stats:{study:1,fitness:1,sports:1,creative:1}}}catch(e){return {xp:0,level:1,streak:0,lastDate:'',quests:defaults,stats:{study:1,fitness:1,sports:1,creative:1}}}}
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function rank(){let l=data.level;return l>=76?'S':l>=51?'A':l>=36?'B':l>=21?'C':l>=11?'D':l>=6?'E':'F'}
function title(){return ({F:'Newly Awakened Hunter',E:'Rookie Hunter',D:'Experienced Hunter',C:'Skilled Hunter',B:'Elite Hunter',A:'High-Rank Hunter',S:'Shadow Monarch'})[rank()]}
function render(){
 const r=rank(),inLevel=(data.xp%100),total=data.xp;
 document.getElementById('rankIcon').textContent=r;
 document.getElementById('levelRank').textContent=`Level ${data.level} · ${r}-Rank`;
 document.getElementById('totalXp').textContent=total.toLocaleString();
 document.getElementById('xpProgressText').textContent=`${inLevel} / 100`;
 document.getElementById('xpProgress').style.width=inLevel+'%';
 document.getElementById('rankTitle').textContent=title();
 document.getElementById('streak').textContent=data.streak;
 document.getElementById('bigRank').textContent=r+'-RANK';
 document.getElementById('rankSubtitle').textContent=title();
 document.querySelectorAll('.rank-track span').forEach(s=>s.classList.toggle('current',s.textContent===r));
 const list=document.getElementById('questList');list.innerHTML='';
 data.quests.forEach(q=>{let el=document.createElement('article');el.className='quest'+(q.done?' done':'');el.innerHTML=`<button class="quest-check" aria-label="Complete quest">${q.done?'✓':''}</button><div class="quest-info"><div class="quest-name"></div><div class="quest-category"></div></div><div class="quest-xp">+${q.xp} XP</div>`;el.querySelector('.quest-name').textContent=q.name;el.querySelector('.quest-category').textContent=q.category.toUpperCase();el.querySelector('button').addEventListener('click',()=>toggle(q.id));list.appendChild(el)});
 ['study','fitness','sports','creative'].forEach(k=>{let v=data.stats[k]||1;document.getElementById(({study:'int',fitness:'str',sports:'agi',creative:'per'})[k]+'Val').textContent=v;document.getElementById(({study:'int',fitness:'str',sports:'agi',creative:'per'})[k]+'Bar').style.width=Math.min(100,v*4)+'%'});
 let achievements=[['✦','First Awakening','Complete your first quest',data.quests.some(q=>q.done)],['📘','Scholar','Earn 100 XP from study quests',data.xp>=100],['⚡','Consistent','Reach level 5',data.level>=5],['👑','Rising Hunter','Reach C-Rank',data.level>=21]];
 document.getElementById('achievements').innerHTML=achievements.map(a=>`<div class="achievement ${a[3]?'':'locked'}"><span class="medal">${a[0]}</span><b>${a[1]}</b><small>${a[2]}</small></div>`).join('');
 save();
}
function toggle(id){let q=data.quests.find(x=>x.id===id);if(!q||q.done)return;q.done=true;data.xp+=q.xp;data.level=1+Math.floor(data.xp/100);let key=q.category==='study'?'study':q.category==='fitness'?'fitness':q.category==='sports'?'sports':q.category==='creative'?'creative':null;if(key)data.stats[key]=(data.stats[key]||1)+1;render();toast(`QUEST CLEARED  +${q.xp} XP`);if(data.xp%100<q.xp)toast('LEVEL UP! YOU GREW STRONGER');}
function toast(msg){let t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),2200)}
document.getElementById('addQuestBtn').addEventListener('click',()=>document.getElementById('questDialog').showModal());
document.getElementById('questForm').addEventListener('submit',e=>{if(e.submitter?.value!=='save')return;e.preventDefault();let name=document.getElementById('questName').value.trim();if(!name)return;data.quests.push({id:Date.now(),name,category:document.getElementById('questCategory').value,xp:+document.getElementById('questReward').value,done:false});document.getElementById('questDialog').close();document.getElementById('questName').value='';render();toast('NEW QUEST ADDED')});
document.getElementById('awakenBtn').addEventListener('click',()=>toast('SYSTEM ONLINE · YOUR JOURNEY BEGINS'));
document.getElementById('menuBtn').addEventListener('click',()=>toast('WHITE ROOM HUNTER SYSTEM'));
document.querySelectorAll('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.bottom-nav button').forEach(x=>x.classList.remove('active'));b.classList.add('active');let target=b.dataset.target;let el=target==='home'?document.querySelector('.system-pill'):target==='quests'?document.querySelector('.section-head'):target==='status'?document.querySelector('.attributes'):document.querySelector('.achievements');el.scrollIntoView({behavior:'smooth',block:'start'})}));
render();
