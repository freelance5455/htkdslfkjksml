# WHITE ROOM — Hunter System (HTML Edition)

A mobile-first, offline-capable habit and quest tracker inspired by futuristic RPG system interfaces.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a browser, or open the folder in Acode and preview `index.html`.
3. No build tools or account are required.

## Files
- `index.html` — app layout
- `style.css` — responsive dark holographic interface
- `app.js` — quests, XP, levels, ranks, achievements and local saving

## Notes
- Progress is saved in the browser using localStorage on the device.
- This is an HTML web app project, not a compiled Android APK.
- Google Fonts are optional; an internet connection is needed to load them. The app itself works offline with fallback fonts.
- Use the same browser on the same device to keep the saved progress.
