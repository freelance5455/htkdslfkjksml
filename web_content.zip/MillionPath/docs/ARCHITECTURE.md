# Architecture Technique – MillionPath

## Stack recommandée

### MVP (actuel)
- **Frontend** : HTML5 + CSS3 + JavaScript vanilla (aucun framework)
- **Stockage** : localStorage
- **Graphiques** : Chart.js (CDN)
- **Style** : CSS custom moderne + variables CSS
- **Déploiement** : N’importe quel hébergeur statique (Netlify, Vercel, GitHub Pages)

### Version production future
| Couche | Technologie | Justification |
|--------|-------------|---------------|
| Frontend | React Native (Expo) ou Flutter | Une seule codebase iOS + Android |
| Backend | Supabase | Auth + DB + Realtime très simple |
| Base de données | PostgreSQL (via Supabase) | Robuste et gratuit jusqu’à un certain volume |
| Auth | Supabase Auth | Email / Google / Apple |
| Stockage fichiers | Supabase Storage | Export CSV, etc. |
| Notifications | Firebase Cloud Messaging | Rappels d’épargne |
| Analytics | Plausible ou PostHog | Respect de la vie privée |

## Structure des données (localStorage / futur DB)

```json
{
  "profile": {
    "age": 30,
    "objectif": 1000000,
    "horizon": 25,
    "profilRisque": "equilibre",
    "createdAt": "2026-10-18"
  },
  "finances": {
    "capitalActuel": 15000,
    "epargneMensuelle": 400,
    "tauxAnnuel": 0.07,
    "dettes": 5000,
    "valeurNette": 10000
  },
  "transactions": [
    {
      "id": "uuid",
      "date": "2026-10-15",
      "type": "revenu|depense|investissement",
      "montant": 2200,
      "categorie": "salaire",
      "note": ""
    }
  ],
  "historiqueValeurNette": [
    { "date": "2026-09-01", "valeur": 9500 },
    { "date": "2026-10-01", "valeur": 10000 }
  ],
  "actionsCompletees": ["ouvrir-pea", "virement-auto"]
}
```

## Sécurité & Vie privée
- Aucune donnée envoyée à un serveur dans le MVP
- Chiffrement possible côté client pour les données sensibles (future)
- Export/Import JSON pour sauvegarde
