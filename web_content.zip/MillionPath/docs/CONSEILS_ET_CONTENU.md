# Bibliothèque de Conseils – MillionPath

## Conseils par catégorie

### 1. Épargne & Discipline
- Automatise un virement le jour de ton salaire. Ce que tu ne vois pas, tu ne le dépenses pas.
- Commence par 10 % de ton revenu net. Augmente de 1 % tous les 3 mois.
- Applique la règle des 24 heures avant tout achat > 50 €.
- Crée un compte « Liberté » séparé de ton compte courant.
- Suis la règle 50/30/20 : 50 % besoins, 30 % envies, 20 % épargne/investissement.

### 2. Investissement
- Ouvre un PEA dès que possible (avantage fiscal après 5 ans).
- Privilégie les ETF world (ex : CW8, EWLD) pour commencer simplement.
- Investis régulièrement (DCA – Dollar Cost Averaging) plutôt que d’attendre le « bon moment ».
- Ne mets jamais d’argent dont tu auras besoin dans moins de 5 ans en bourse.
- Diversifie : actions + obligations + liquidités selon ton âge et ton horizon.

### 3. Mentalité & Long terme
- Le temps est ton plus grand allié. Commencer à 25 ans ou à 35 ans change tout.
- Les millionnaires ne deviennent pas riches en un jour. Ils deviennent riches un jour après l’autre.
- Compare-toi à ta version d’hier, pas aux autres.
- Accepte que la bourse baisse. C’est normal et même souhaitable si tu achètes régulièrement.
- La patience bat le talent en finance personnelle.

### 4. Fiscalité & Optimisation (France)
- Utilise le PEA et l’assurance-vie en priorité.
- Le PER peut être intéressant si tu es fortement imposé.
- Déclare correctement tes plus-values (abattement après 5 ans sur PEA).
- Évite les produits complexes avec des frais élevés.

### 5. Anti-gaspi
- Annule les abonnements que tu n’utilises plus (vérifie tous les 3 mois).
- Cuisine plus souvent : l’écart avec les livraisons est énorme sur un an.
- Compare les assurances (auto, habitation, mutuelle) chaque année.
- Négocie ton forfait mobile et internet.

---

## Messages motivants (à afficher aléatoirement)

- « Chaque euro investi aujourd’hui travaille pour toi demain. »
- « Tu n’as pas besoin d’être parfait. Tu as besoin d’être constant. »
- « Le meilleur moment pour commencer c’était hier. Le deuxième meilleur moment c’est maintenant. »
- « Ta future version te remerciera pour les efforts d’aujourd’hui. »
- « Les intérêts composés sont la huitième merveille du monde. Celui qui les comprend les gagne, celui qui ne les comprend pas les paie. » – Attribué à Einstein

---

## Paliers de progression (exemples)

| Palier | Montant | Message |
|--------|---------|---------|
| 1 | 1 000 € | « Première victoire ! Tu as prouvé que tu peux épargner. » |
| 2 | 5 000 € | « Tu as un vrai matelas de sécurité. Continue. » |
| 3 | 10 000 € | « Tu entres dans le club des épargnants sérieux. » |
| 4 | 25 000 € | « Ton argent commence vraiment à travailler. » |
| 5 | 50 000 € | « Tu as atteint un cap important. Félicitations. » |
| 6 | 100 000 € | « Six chiffres. Beaucoup abandonnent avant. Pas toi. » |
| 7 | 250 000 € | « Tu es sur la bonne trajectoire. » |
| 8 | 500 000 € | « La moitié du chemin vers le million. » |
| 9 | 1 000 000 € | « Objectif atteint. Tu es millionnaire. » |
