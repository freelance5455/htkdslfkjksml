# Cahier des Charges – MillionPath

**Version** : 1.0  
**Date** : 18 octobre 2026  
**Objectif** : Application simple et motivante pour faire fructifier son portefeuille et progresser vers l’indépendance financière / devenir millionnaire de façon réaliste.

---

## 1. Vision produit

MillionPath est une application mobile/web progressive qui aide l’utilisateur à :
- Visualiser clairement sa situation financière
- Comprendre la puissance des intérêts composés
- Se fixer des objectifs concrets et progressifs
- Recevoir des conseils actionnables
- Suivre sa progression dans le temps

**Positionnement** : Honnête, pédagogique, sans promesse de richesse rapide.

---

## 2. Personas principaux

| Persona | Description | Besoin principal |
|---------|-------------|------------------|
| **Thomas, 28 ans** | Salarié, 2200 € net, veut sortir de l’endettement et commencer à investir | Comprendre par où commencer |
| **Sophie, 35 ans** | Couple, 2 enfants, veut préparer la retraite et un apport immobilier | Suivre un plan long terme |
| **Karim, 42 ans** | Entrepreneur, a déjà un patrimoine, veut l’optimiser | Projection et allocation |

---

## 3. User Stories prioritaires (MVP)

### Must Have (P0)
- En tant qu’utilisateur, je peux renseigner mon âge, mon capital actuel et mon épargne mensuelle pour obtenir une projection.
- En tant qu’utilisateur, je vois un graphique d’évolution de mon patrimoine sur 10/20/30 ans.
- En tant qu’utilisateur, je peux définir un objectif (ex : 1 000 000 €) et voir le temps estimé pour l’atteindre.
- En tant qu’utilisateur, je peux suivre ma valeur nette (actifs – dettes).
- En tant qu’utilisateur, je reçois des conseils simples et actionnables.

### Should Have (P1)
- Suivi des dépenses par catégorie (50/30/20).
- Journal de progression (historique de la valeur nette).
- Mode « Anti-gaspi » avec suggestions.
- Export des données (CSV).

### Could Have (P2)
- Connexion bancaire (PSD2) – hors MVP.
- Suivi de portefeuille boursier en temps réel.
- Communauté / défis entre utilisateurs.

---

## 4. Fonctionnalités détaillées

### 4.1 Onboarding
1. Bienvenue + ton objectif principal
2. Âge actuel
3. Capital de départ
4. Capacité d’épargne mensuelle
5. Horizon (10 / 15 / 20 / 25 / 30 ans)
6. Profil de risque (conservateur / équilibré / dynamique)

### 4.2 Dashboard
- Valeur nette actuelle
- Projection à l’horizon choisi
- Progression vers le prochain palier (10k → 25k → 50k → 100k → 250k → 500k → 1M)
- Graphique d’évolution
- Conseil du jour

### 4.3 Simulateur d’intérêts composés
- Inputs : capital initial, versement mensuel, taux annuel, durée
- Résultat : capital final, intérêts gagnés, graphique
- Comparaison « avec » vs « sans » versements réguliers

### 4.4 Objectifs & Paliers
- Objectif principal personnalisable
- Découpage automatique en paliers
- Pourcentage de progression + temps restant estimé

### 4.5 Conseils & Actions
- Bibliothèque de conseils classés par thème (épargne, investissement, mentalité, fiscalité France)
- Checklist d’actions concrètes
- Score de santé financière (0-100)

### 4.6 Suivi
- Ajout manuel de transactions (revenu / dépense / investissement)
- Catégories simples
- Historique

---

## 5. Règles métier importantes

- Taux de rendement proposés :
  - Conservateur : 3-4 %
  - Équilibré : 5-7 %
  - Dynamique : 7-9 %
- Toujours rappeler que les performances passées ne préjugent pas des performances futures.
- Formule des intérêts composés avec versements mensuels :
  \[ A = P(1+r)^n + M \times \frac{(1+r)^n - 1}{r} \]
  où \( r \) = taux mensuel, \( n \) = nombre de mois, \( M \) = versement mensuel.

---

## 6. Contraintes techniques

- Fonctionne offline (données locales)
- Responsive (mobile first)
- Accessible (contraste, taille de police)
- RGPD : données stockées localement par défaut
- Langue : Français

---

## 7. Critères de succès MVP

- L’utilisateur comprend en moins de 2 minutes sa trajectoire
- Le simulateur est précis et clair
- Les conseils sont actionnables et non culpabilisants
- L’application donne envie de revenir régulièrement
