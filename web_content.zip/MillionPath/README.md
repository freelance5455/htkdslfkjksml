# MillionPath – Application de fructification de patrimoine

Application simple, pédagogique et honnête pour aider à faire grandir son portefeuille et progresser vers l’indépendance financière.

## Contenu du projet

```
MillionPath/
├── docs/
│   ├── CAHIER_DES_CHARGES.md     # Vision, user stories, fonctionnalités
│   ├── ARCHITECTURE.md           # Stack technique & structure de données
│   └── CONSEILS_ET_CONTENU.md    # Bibliothèque de conseils & messages
├── public/
│   └── index.html                # MVP fonctionnel complet (à ouvrir dans un navigateur)
└── README.md
```

## Lancer le MVP immédiatement

1. Ouvre le fichier `public/index.html` dans ton navigateur (Chrome, Firefox, Safari, Edge…).
2. Ou lance un serveur local :
   ```bash
   cd public
   python3 -m http.server 8080
   ```
   Puis va sur http://localhost:8080

## Fonctionnalités du MVP

- **Onboarding** guidé (âge, capital, épargne, horizon, profil de risque)
- **Dashboard** avec :
  - Valeur nette
  - Projection à long terme
  - Progression vers le prochain palier
  - Graphique d’évolution
  - Conseil du jour
- **Simulateur d’intérêts composés** interactif avec graphique
- **Objectifs & Paliers** (1k → 5k → 10k → … → 1M)
- **Conseils & Checklist** d’actions concrètes (PEA, virement auto, etc.)
- **Suivi** : modification des paramètres + sauvegarde locale
- Données stockées uniquement dans le navigateur (localStorage) – aucune donnée envoyée à un serveur

## Prochaines étapes possibles (version production)

1. Passer en React Native (Expo) ou Flutter pour iOS + Android
2. Ajouter Supabase pour authentification et synchronisation multi-appareils
3. Connexion bancaire (PSD2) pour import automatique des soldes
4. Notifications de rappel d’épargne
5. Mode sombre/clair + personnalisation

## Avertissement important

Cette application est un **outil pédagogique**.  
Les projections sont des estimations basées sur des hypothèses de rendement.  
Les performances passées ne préjugent pas des performances futures.  
Ce n’est pas un conseil en investissement. Fais toujours tes propres recherches et, si besoin, consulte un professionnel.

---

Créé avec ❤️ pour t’aider à prendre le contrôle de ton avenir financier.
