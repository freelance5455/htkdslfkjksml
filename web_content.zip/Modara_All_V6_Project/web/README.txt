Open index.html in Chrome. Offline app; data stored in browser localStorage. Use module Backup/Restore and Settings Full Backup/Restore.
