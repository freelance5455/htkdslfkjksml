MODARA ALL V6.1 - WORKING SOURCE ZIP

Base source: Modara_All_V6_Complete_Project_UPDATED-1.zip

Changes made in this working pass:
- Bill Data Add initializes the first item row without requiring Add Item.
- First/default item row no longer displays a Remove button.
- Added item rows retain a Remove button.
- Entry navigation ensures the initial row exists when the form is empty.
- Editing an existing bill item uses a non-removable first row.
- Updated the web source and Android assets copy together.

Preserved original modules, files, categories, database schema, and existing records logic.

Testing:
- JavaScript syntax check (Node.js --check): passed.
- Android Gradle build: not run in this environment.
- Functional tests, PDF/print, database persistence, Android device behavior: not yet tested.

This ZIP is a working modification pass for later testing and review, not a verified release.
