MODARA ALL V6 – Project ZIP

මෙහි Android Studio Project එක සහ Offline Web App එක ඇතුළත්.

APK එක හදන විදිහ (Windows PC):
1. ZIP එක Download කර Extract කරන්න.
2. Android Studio Install කර Open කරන්න.
3. Android Studio → Open → Extract කළ folder එකේ android folder එක තෝරන්න.
4. Gradle Sync අවසන් වෙනකම් ඉන්න. SDK Platform 35 ඉල්ලුවොත් Install කරන්න.
5. Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK එක ලැබෙන්නේ android/app/build/outputs/apk/debug/ තුළ.
7. APK එක Phone එකට copy කර Install කරන්න. Emulator එකක් හදන්න අවශ්‍ය නැහැ.

Web version:
web/index.html Chrome වලින් Open කරන්න. දත්ත browser එකේ local storage තුළ save වේ.

Password:
V5 prototype එකේ තිබුණු password lock එක V6 එකට carry කර ඇත. පළමු unlock සාර්ථක වූ පසු ඒ device එකේ නැවත නැවත password ඉල්ලන්නේ නැත. වෙනත් device එකකට අලුතින් install කළ විට පළමු වර password ඉල්ලයි.

Data:
දත්ත device-local. Module එක ඇතුළේ Backup/Restore සහ Settings හි Full Backup/Restore භාවිත කරන්න. Backup file එක ආරක්ෂිතව තබාගන්න.

මෙය Android Studio source project ZIP එකයි; pre-built APK එකක් නොවේ. Android Studio එකෙන් build කළ යුතුයි.
