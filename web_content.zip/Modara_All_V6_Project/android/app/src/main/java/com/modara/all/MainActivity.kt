package com.modara.all

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import java.io.OutputStreamWriter

class MainActivity : androidx.activity.ComponentActivity() {
    private lateinit var web: WebView
    private var pendingFileChooser: ValueCallback<Array<Uri>>? = null
    private var pendingText: String = ""
    private var pendingName: String = "backup.json"
    private val saveFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) contentResolver.openOutputStream(uri)?.use { it.write(pendingText.toByteArray(Charsets.UTF_8)) }
        else Toast.makeText(this, "Backup save cancelled", Toast.LENGTH_SHORT).show()
    }
    private val openFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pendingFileChooser?.onReceiveValue(if (uri != null) arrayOf(uri) else null); pendingFileChooser = null
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        web = WebView(this); setContentView(web); web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true; web.settings.allowFileAccess = true; web.settings.allowContentAccess = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = object : WebChromeClient() { override fun onShowFileChooser(view: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean { pendingFileChooser = filePathCallback; openFile.launch("application/json"); return true } }
        web.webViewClient = WebViewClient(); web.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge { @JavascriptInterface fun saveTextFile(name: String, text: String) { runOnUiThread { pendingName=name; pendingText=text; saveFile.launch(name) } } @JavascriptInterface fun printApp() { runOnUiThread { val pm=getSystemService(PRINT_SERVICE) as android.print.PrintManager; val adapter=web.createPrintDocumentAdapter("Modara All V6"); pm.print("Modara All V6",adapter,android.print.PrintAttributes.Builder().build()) } } }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
