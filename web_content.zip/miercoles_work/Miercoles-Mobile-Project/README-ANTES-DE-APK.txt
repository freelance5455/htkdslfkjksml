MIÉRCOLES — PAQUETE MÓVIL CON CUENTAS
====================================

Este ZIP contiene el proyecto web móvil para importarlo en un creador de APK que admita cargar una carpeta/proyecto web.
No es un APK compilado.

QUÉ YA ESTÁ IMPLEMENTADO
- Pantalla obligatoria de acceso con correo y contraseña de Miércoles.
- Alternar entre iniciar sesión y crear cuenta.
- Sesión de usuario mediante Supabase Auth.
- Guardado automático de conversaciones en la nube.
- Recuperación de conversaciones al volver a iniciar sesión.
- Sala de voz con orbe futurista y murciélago.
- Identidad de Miércoles y crédito de creador: Abisai.

PASO ÚNICO PENDIENTE PARA QUE LAS CUENTAS FUNCIONEN
La app necesita un proyecto de Supabase. No es seguro ni posible inventar las credenciales del proyecto: deben pertenecer al propietario de la app.
1. Crea un proyecto en https://supabase.com (plan gratuito disponible).
2. En SQL Editor ejecuta el contenido de SUPABASE-SETUP.sql.
3. En Project Settings > API copia Project URL y la clave publicable (anon/publishable).
4. Pega esos dos valores en assets-web/supabase-config.js, reemplazando PON_AQUI_TU_SUPABASE_URL y PON_AQUI_TU_SUPABASE_ANON_KEY.
5. Publica assets-web en un sitio HTTPS y configura la URL autorizada en Authentication > URL Configuration.
6. Prueba crear cuenta, iniciar sesión, enviar un chat, cerrar sesión y entrar desde otro dispositivo.

IMPORTANTE PARA CONVERTIR A APK
- Usa assets-web como carpeta de contenido web y assets-web/index.html como página inicial.
- Asegúrate de que el empaquetador incluya todos los archivos de assets-web y permita acceso HTTPS a Supabase.
- No pruebes las cuentas abriendo index.html como archivo local: Supabase requiere un origen web válido.
- Después de compilar, prueba el APK en Android real.

SEGURIDAD
- Nunca incluyas una clave service_role/secret de Supabase en la app. Solo la clave publicable.
- La clave de Groq incluida en una app cliente puede extraerse. Para distribuir Miércoles públicamente, mueve las llamadas a Groq a un backend y aplica límites por usuario.
- No distribuyas credenciales personales dentro del ZIP.

No se afirma que el APK esté compilado ni que la nube esté activa hasta completar la configuración y probarla.
