/* CONFIGURACIÓN DE CUENTAS DE MIÉRCOLES
   Copia aquí la URL del proyecto Supabase y la clave publicable (anon).
   NUNCA pongas aquí la service_role ni una contraseña privada.
*/
window.MIERCOLES_SUPABASE_URL = "PON_AQUI_TU_SUPABASE_URL";
window.MIERCOLES_SUPABASE_ANON_KEY = "PON_AQUI_TU_SUPABASE_ANON_KEY";
