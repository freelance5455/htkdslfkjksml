# Miércoles Mobile — Proyecto móvil

Proyecto web móvil actualizado a partir de los recursos del APK proporcionado.

## Cambios
- Interfaz móvil oscura con acentos violeta y cian.
- Identidad de creador: Abisai.
- Sala de voz con orbe futurista y murciélago luminoso en el centro (sin inicial M).
- Animación del orbe al escuchar y al hablar.
- Conversación manos libres: reconocimiento de voz en español y lectura automática de respuestas.
- Preferencia por voz masculina cuando Android/navegador ofrece una voz masculina en español.
- Conexión directa del cliente a Groq Chat Completions, sin servidor intermediario.
- Clave API introducida y guardada localmente desde Ajustes.

## Uso
1. Descomprime el ZIP y sirve `assets-web` desde HTTPS o localhost.
2. Abre `index.html` en Chrome Android.
3. En Ajustes, introduce una clave nueva de Groq (`gsk_...`).
4. Permite el micrófono y abre **Voz**.

## Seguridad y limitaciones
La clave se almacena localmente en el perfil del navegador y se envía directamente a `https://api.groq.com/openai/v1/chat/completions`. No hay backend propio ni servidor intermediario. Una clave guardada en una app cliente puede extraerse del dispositivo; no compartas el ZIP/APK con una clave real incorporada. La clave expuesta anteriormente debe revocarse y reemplazarse.

El paquete es un proyecto web, no un APK recompilado. La voz masculina depende de las voces instaladas en Android. No se ha validado en un teléfono físico.
