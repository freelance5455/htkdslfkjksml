create table if not exists public.miercoles_chats (
  user_id uuid primary key references auth.users(id) on delete cascade,
  chats jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.miercoles_chats enable row level security;

drop policy if exists "Cada usuario lee sus chats" on public.miercoles_chats;
create policy "Cada usuario lee sus chats"
on public.miercoles_chats for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Cada usuario crea sus chats" on public.miercoles_chats;
create policy "Cada usuario crea sus chats"
on public.miercoles_chats for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Cada usuario actualiza sus chats" on public.miercoles_chats;
create policy "Cada usuario actualiza sus chats"
on public.miercoles_chats for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
