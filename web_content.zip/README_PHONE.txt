NEXUS TAEKWONDO - CUSTOMER PHONE APP

1. Connect the phone to the same Wi-Fi as the NEXUS PC.
2. Open CustomerApp.html in a browser or package it as an Android app.
3. Enter the 6-digit pairing code from the PC only the first time.
4. The app remembers the pairing on that phone.
5. Future visits do not require the pairing code again unless pairing is forgotten/reset.
