import { useEffect, useMemo, useState } from 'react'
import {
  BookOpen, Search, Plus, Pin, Star, Trash2, Folder, Settings, Moon, Sun,
  LayoutDashboard, FileText, CalendarDays, ChevronRight, ArrowLeft, MoreHorizontal,
  Download, Languages, ShieldCheck, Crown, Feather, X, Check, RotateCcw
} from 'lucide-react'

type Note = {
  id: string; title: string; body: string; folder: string; tags: string[];
  pinned: boolean; favorite: boolean; deleted: boolean; updatedAt: number
}
type Page = 'dashboard' | 'notes' | 'favorites' | 'trash' | 'folders' | 'settings'
const starter: Note[] = [
  { id: 'welcome', title: 'Welcome to your legacy', body: 'Every great idea starts with a single note.\\n\\nCapture your thoughts, organize your plans, and keep your best ideas close.', folder: 'Personal', tags: ['Welcome'], pinned: true, favorite: true, deleted: false, updatedAt: Date.now() },
  { id: 'ideas', title: 'Ideas worth remembering', body: 'A quiet place for your next big idea.\\n\\n• Think boldly\\n• Write it down\\n• Make it happen', folder: 'Ideas', tags: ['Inspiration'], pinned: false, favorite: false, deleted: false, updatedAt: Date.now() - 3600000 }
]
const loadNotes = (): Note[] => {
  try { const raw = localStorage.getItem('dd-notes-v1'); return raw ? JSON.parse(raw) : starter } catch { return starter }
}
const fmt = (n: number) => new Date(n).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })

export default function App() {
  const [notes, setNotes] = useState<Note[]>(loadNotes)
  const [page, setPage] = useState<Page>('dashboard')
  const [active, setActive] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [dark, setDark] = useState(() => localStorage.getItem('dd-dark') === 'true')
  const [lang, setLang] = useState<'en'|'bn'>(() => (localStorage.getItem('dd-lang') as 'en'|'bn') || 'en')
  const [folderFilter, setFolderFilter] = useState('')
  const [toast, setToast] = useState('')
  useEffect(() => { localStorage.setItem('dd-notes-v1', JSON.stringify(notes)) }, [notes])
  useEffect(() => { localStorage.setItem('dd-dark', String(dark)) }, [dark])
  useEffect(() => { localStorage.setItem('dd-lang', lang) }, [lang])
  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(''), 2200); return () => clearTimeout(t) } }, [toast])
  const current = notes.find(n => n.id === active)
  const folders = useMemo(() => Array.from(new Set(notes.filter(n => !n.deleted).map(n => n.folder).filter(Boolean))), [notes])
  const visible = useMemo(() => {
    let list = notes.filter(n => !n.deleted)
    if (page === 'favorites') list = list.filter(n => n.favorite)
    if (page === 'folders' && folderFilter) list = list.filter(n => n.folder === folderFilter)
    if (query.trim()) { const q = query.toLowerCase(); list = list.filter(n => (n.title + ' ' + n.body + ' ' + n.tags.join(' ')).toLowerCase().includes(q)) }
    return list.sort((a,b) => Number(b.pinned)-Number(a.pinned) || b.updatedAt-a.updatedAt)
  }, [notes, page, query, folderFilter])
  const tr = (en: string, bn: string) => lang === 'bn' ? bn : en
  const create = () => {
    const n: Note = { id: crypto.randomUUID(), title: '', body: '', folder: 'Personal', tags: [], pinned: false, favorite: false, deleted: false, updatedAt: Date.now() }
    setNotes(v => [n, ...v]); setActive(n.id)
  }
  const patch = (id: string, data: Partial<Note>) => setNotes(v => v.map(n => n.id === id ? { ...n, ...data, updatedAt: Date.now() } : n))
  const go = (p: Page) => { setPage(p); setActive(null); setQuery(''); setFolderFilter('') }
  const exportNotes = () => {
    const blob = new Blob([JSON.stringify(notes.filter(n => !n.deleted), null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'doze-dynasty-notes.json'; a.click(); URL.revokeObjectURL(url)
    setToast(tr('Backup downloaded', 'ব্যাকআপ ডাউনলোড হয়েছে'))
  }
  const restore = (id: string) => patch(id, { deleted: false })
  const deleteNote = (id: string) => patch(id, { deleted: true })
  const nav = [
    { id: 'dashboard' as Page, label: tr('Home','হোম'), icon: LayoutDashboard },
    { id: 'notes' as Page, label: tr('Notes','নোট'), icon: FileText },
    { id: 'favorites' as Page, label: tr('Saved','প্রিয়'), icon: Star },
    { id: 'folders' as Page, label: tr('Folders','ফোল্ডার'), icon: Folder },
    { id: 'trash' as Page, label: tr('Trash','ট্র্যাশ'), icon: Trash2 },
    { id: 'settings' as Page, label: tr('Settings','সেটিংস'), icon: Settings }
  ]
  return <div className={dark ? 'app dark' : 'app'}>
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Crown size={17}/><BookOpen size={22}/></div><div><b>DOZE & DYNASTY</b><small>YOUR THOUGHTS, YOUR LEGACY.</small></div></div>
      <div className="side-label">{tr('WORKSPACE','কর্মক্ষেত্র')}</div>
      {nav.map(item => <button key={item.id} className={'nav-item '+(page===item.id?'selected':'')} onClick={()=>go(item.id)}><item.icon size={18}/><span>{item.label}</span>{item.id==='notes'&&<em>{notes.filter(n=>!n.deleted).length}</em>}</button>)}
      <div className="side-bottom"><div className="mini-crown"><Crown size={16}/><span>Make every thought count.</span></div><small>DOZE & DYNASTY · 1.0</small></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="mobile-brand"><Crown size={19}/> DOZE & DYNASTY</div><div className="crumb">{current ? <><button onClick={()=>setActive(null)}><ArrowLeft size={16}/></button> {tr('Editing note','নোট সম্পাদনা')}</> : page==='dashboard' ? tr('Your private workspace','আপনার ব্যক্তিগত নোটবুক') : nav.find(n=>n.id===page)?.label}</div><div className="top-actions"><button className="icon-btn" title="Toggle theme" onClick={()=>setDark(!dark)}>{dark?<Sun size={18}/>:<Moon size={18}/>}</button><div className="avatar">D</div></div></header>
      {current ? <section className="editor">
        <div className="editor-head"><span className="eyebrow">{tr('NOTE EDITOR','নোট এডিটর')}</span><div className="editor-actions"><button className={current.pinned?'tiny-action active':''} onClick={()=>patch(current.id,{pinned:!current.pinned})}><Pin size={16}/></button><button className={current.favorite?'tiny-action active':''} onClick={()=>patch(current.id,{favorite:!current.favorite})}><Star size={16}/></button><button className="tiny-action danger" onClick={()=>{deleteNote(current.id);setActive(null)}}><Trash2 size={16}/></button></div></div>
        <input className="title-input" placeholder={tr('Untitled note','শিরোনাম লিখুন')} value={current.title} onChange={e=>patch(current.id,{title:e.target.value})}/>
        <div className="meta-row"><select value={current.folder} onChange={e=>patch(current.id,{folder:e.target.value})}>{[...folders,'Personal','Work','Ideas','Journal'].filter((v,i,a)=>a.indexOf(v)===i).map(f=><option key={f}>{f}</option>)}</select><span>·</span><span>{tr('Edited','সম্পাদিত')} {fmt(current.updatedAt)}</span><span className="saved"><Check size={13}/> {tr('Saved on this device','এই ডিভাইসে সেভ')}</span></div>
        <textarea className="body-input" placeholder={tr('Start writing your thoughts...','আপনার ভাবনা লিখতে শুরু করুন...')} value={current.body} onChange={e=>patch(current.id,{body:e.target.value})}/>
        <div className="editor-footer"><Feather size={15}/> {tr('Your ideas deserve a beautiful home.','আপনার আইডিয়ার জন্য সুন্দর একটি ঠিকানা।')}</div>
      </section> : page==='settings' ? <section className="content"><div className="page-heading"><span className="eyebrow">PREFERENCES</span><h1>{tr('Settings','সেটিংস')}</h1><p>{tr('Make your workspace feel like yours.','নিজের মতো করে সাজিয়ে নিন।')}</p></div>
        <div className="settings-card"><div className="setting-icon"><Moon size={19}/></div><div className="setting-copy"><b>{tr('Appearance','চেহারা')}</b><small>{tr('Choose your workspace theme','থিম নির্বাচন করুন')}</small></div><button className="pill" onClick={()=>setDark(!dark)}>{dark?'Midnight Glow':'White Theme'}</button></div>
        <div className="settings-card"><div className="setting-icon"><Languages size={19}/></div><div className="setting-copy"><b>{tr('Language','ভাষা')}</b><small>{tr('Choose app language','অ্যাপের ভাষা নির্বাচন করুন')}</small></div><button className="pill" onClick={()=>setLang(lang==='en'?'bn':'en')}>{lang==='en'?'English':'বাংলা'}</button></div>
        <div className="settings-card"><div className="setting-icon"><Download size={19}/></div><div className="setting-copy"><b>{tr('Export backup','ব্যাকআপ')}</b><small>{tr('Download your notes as a JSON file','নোটগুলো JSON ফাইলে ডাউনলোড করুন')}</small></div><button className="pill" onClick={exportNotes}>{tr('Export','ডাউনলোড')}</button></div>
        <div className="settings-card"><div className="setting-icon"><ShieldCheck size={19}/></div><div className="setting-copy"><b>{tr('Your privacy','আপনার গোপনীয়তা')}</b><small>{tr('Notes are currently stored on this device only. Cloud sync is not connected yet.','নোট এখন শুধু এই ডিভাইসে থাকে। ক্লাউড সিঙ্ক এখনো যুক্ত হয়নি।')}</small></div></div>
        <div className="about"><Crown size={19}/> <b>Doze & Dynasty Notepad</b><span>Your Thoughts, Your Legacy.</span><small>Version 1.0.0 · Crafted for your ideas</small></div>
      </section> : page==='trash' ? <section className="content"><div className="page-heading"><span className="eyebrow">RECYCLE BIN</span><h1>{tr('Recently deleted','মুছে ফেলা নোট')}</h1><p>{tr('Restore notes you still need.','প্রয়োজনীয় নোট ফিরিয়ে আনুন।')}</p></div><div className="notes-grid">{notes.filter(n=>n.deleted).map(n=><article className="note-card" key={n.id}><h3>{n.title||'Untitled note'}</h3><p>{n.body.slice(0,110)}</p><button className="text-button" onClick={()=>restore(n.id)}><RotateCcw size={14}/> {tr('Restore','ফিরিয়ে আনুন')}</button></article>)}</div>{!notes.some(n=>n.deleted)&&<div className="empty"><Trash2 size={30}/><b>{tr('Trash is empty','ট্র্যাশ খালি')}</b></div>}</section> : <section className="content">
        <div className="hero"><div className="hero-glow"></div><div className="hero-copy"><span className="eyebrow light"><Crown size={13}/> YOUR PERSONAL SPACE</span><h1>{page==='dashboard'?tr('Ideas become\\nlegacy.','ভাবনা থেকেই\\nউত্তরাধিকার।'):page==='favorites'?tr('Your saved thoughts','আপনার প্রিয় নোট'):page==='folders'?tr('Organize your world','গুছিয়ে রাখুন') : tr('All your notes','সব নোট')}</h1><p>{tr('A calmer space for everything on your mind.','আপনার সব ভাবনার জন্য শান্ত, সুন্দর একটি জায়গা।')}</p><button className="hero-cta" onClick={create}><Plus size={17}/> {tr('Create a note','নতুন নোট')}</button></div><div className="hero-art"><div className="art-circle"><BookOpen size={54}/><Crown size={25}/></div><div className="art-spark">✦</div></div></div>
        <div className="stats"><div className="stat"><span>{tr('TOTAL NOTES','মোট নোট')}</span><b>{notes.filter(n=>!n.deleted).length.toString().padStart(2,'0')}</b></div><div className="stat"><span>{tr('PINNED','পিন করা')}</span><b>{notes.filter(n=>n.pinned&&!n.deleted).length.toString().padStart(2,'0')}</b></div><div className="stat"><span>{tr('FAVORITES','প্রিয়')}</span><b>{notes.filter(n=>n.favorite&&!n.deleted).length.toString().padStart(2,'0')}</b></div></div>
        <div className="section-head"><div><span className="eyebrow">{page==='dashboard'?'YOUR COLLECTION':'COLLECTION'}</span><h2>{page==='dashboard'?tr('Recent notes','সাম্প্রতিক নোট'):page==='favorites'?tr('Favorite notes','প্রিয় নোট'):page==='folders'?(folderFilter||tr('Your folders','আপনার ফোল্ডার')):tr('All notes','সব নোট')}</h2></div><div className="searchbox"><Search size={16}/><input placeholder={tr('Search notes...','নোট খুঁজুন...')} value={query} onChange={e=>setQuery(e.target.value)}/></div></div>
        {page==='folders'&&!folderFilter&&<div className="folder-list">{folders.map(f=><button key={f} className="folder-chip" onClick={()=>setFolderFilter(f)}><Folder size={17}/>{f}<ChevronRight size={15}/></button>)}</div>}
        <div className="notes-grid">{visible.filter(n=>page!=='folders'||!folderFilter||n.folder===folderFilter).map(n=><article className="note-card" key={n.id} onClick={()=>setActive(n.id)}><div className="note-top"><span className="folder-tag"><Folder size={12}/>{n.folder}</span><div>{n.pinned&&<Pin size={14}/>} {n.favorite&&<Star size={14}/>}</div></div><h3>{n.title||tr('Untitled note','শিরোনামহীন নোট')}</h3><p>{n.body||tr('No additional text yet. Open to start writing...','এখনো কিছু লেখা হয়নি। লিখতে খুলুন...')}</p><div className="note-bottom"><span>{fmt(n.updatedAt)}</span><button onClick={e=>{e.stopPropagation();patch(n.id,{pinned:!n.pinned})}}><Pin size={14}/></button><button onClick={e=>{e.stopPropagation();patch(n.id,{favorite:!n.favorite})}}><Star size={14}/></button></div></article>)}
          <button className="add-card" onClick={create}><span><Plus size={22}/></span><b>{tr('Create a new note','নতুন নোট তৈরি করুন')}</b><small>{tr('Capture a thought before it fades.','ভাবনাটি হারিয়ে যাওয়ার আগে লিখে রাখুন।')}</small></button>
        </div>
        {visible.length===0&&<div className="empty"><FileText size={30}/><b>{tr('No notes found','কোনো নোট পাওয়া যায়নি')}</b><span>{tr('Create your first note to get started.','শুরু করতে প্রথম নোটটি তৈরি করুন।')}</span></div>}
      </section>}
    </main>
    <button className="mobile-fab" onClick={create}><Plus size={24}/></button>
    <nav className="mobile-nav">{nav.slice(0,5).map(item=><button key={item.id} className={page===item.id?'active':''} onClick={()=>go(item.id)}><item.icon size={18}/><small>{item.label}</small></button>)}</nav>
    {toast&&<div className="toast">{toast}</div>}
  </div>
}