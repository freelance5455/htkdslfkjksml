# এক জায়গায় APK বানানোর ফাইল

এই ZIP-এ GitHub Actions-এর স্বয়ংক্রিয় Android APK build workflow যোগ করা হয়েছে।

আপলোড করার পর GitHub repository-তে:
1. Actions tab খুলুন।
2. "Build Doze & Dynasty Android APK" workflow নির্বাচন করুন।
3. Run workflow চাপুন।
4. কাজ শেষ হলে workflow run-এর Artifacts অংশ থেকে `Doze-Dynasty-Notepad-debug-APK` ডাউনলোড করুন।

এটি debug APK। Play Store-এ প্রকাশের জন্য পরে আলাদা signed release build লাগবে।

গুরুত্বপূর্ণ: অ্যাপের বর্তমান নোটগুলো ফোন/ব্রাউজারের local storage-এ থাকে। Cloud sync এখনো সংযুক্ত নয়।
