# Doze & Dynasty Notepad

**Tagline:** Your Thoughts, Your Legacy.

এটি একটি সম্পূর্ণ React + Vite ভিত্তিক নোটপ্যাড অ্যাপের সোর্স প্রজেক্ট। মোবাইল ও ডেস্কটপ—দুই জায়গাতেই ব্যবহারযোগ্য responsive UI আছে।

## এখন যা কাজ করে
- নোট তৈরি, সম্পাদনা এবং স্বয়ংক্রিয়ভাবে এই ডিভাইসে সেভ
- পিন, ফেভারিট, ফোল্ডার, সার্চ
- Trash থেকে নোট ফিরিয়ে আনা
- White ও Midnight Glow থিম
- বাংলা/English UI switch
- JSON ব্যাকআপ ডাউনলোড
- Capacitor Android wrapper-এর প্রাথমিক কনফিগারেশন

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই প্রথম সংস্করণে নোট `localStorage`-এ থাকে—অর্থাৎ একই ব্রাউজার/ডিভাইসে। Google login, Supabase cloud sync, biometric lock, AI API এবং voice/attachment storage এখনো সংযুক্ত নয়। এগুলো চালু করতে আলাদা cloud project, credentials এবং নিরাপদ server-side setup লাগবে। কোনো secret key কখনো frontend-এ বসাবেন না।

## Cloud build করার সাধারণ ধাপ
1. ZIP extract করে পুরো `doze-dynasty-notepad` ফোল্ডার GitHub repository-তে upload করুন।
2. Cloud build environment-এ Node.js 20 বা তার নতুন সংস্করণ ব্যবহার করুন।
3. চালান: `npm install`
4. চালান: `npm run build`
5. ওয়েব preview-এর জন্য `npm run dev` ব্যবহার করুন।
6. Android APK বানাতে Capacitor Android project তৈরি করে Android SDK/Gradle-সহ cloud Android build workflow লাগবে। শুধু ZIP আপলোড করলেই APK তৈরি হয় না।

## Android project commands
`npm run android:add` (প্রথমবার)
`npm run android:sync`
এরপর Android Studio/Android SDK সহ build environment-এ APK build করতে হবে।

## Brand
- App: Doze & Dynasty Notepad
- Tagline: Your Thoughts, Your Legacy.
- White: #FFFFFF
- Electric Blue: #145BFF
- Soft Blue: #EAF1FF
- Midnight Navy: #0A1B4D
- Text: #172033
