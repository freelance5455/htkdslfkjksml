# Cloud sync setup (পরবর্তী ধাপ)

Supabase project তৈরি না করা পর্যন্ত cloud sync চালু হবে না। প্রথমে local notes app কাজ করবে।

পরবর্তী ধাপে প্রয়োজন হবে:
- Supabase Project URL
- Supabase anon/public key (frontend-এ ব্যবহারের জন্য)
- Postgres table ও Row Level Security policies
- Auth provider configuration

**কখনোই Supabase service_role key বা AI secret key browser/frontend-এ দেবেন না।**