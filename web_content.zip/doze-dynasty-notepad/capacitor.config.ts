import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = {
  appId: 'com.dozeanddynasty.notepad',
  appName: 'Doze & Dynasty Notepad',
  webDir: 'dist',
  bundledWebRuntime: false
}
export default config