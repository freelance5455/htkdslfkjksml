# Generator Log & Report Manager — Android project (Alpha 0.1)

এই Android Studio source project-এ আগের HTML অ্যাপটি WebView-এর ভিতরে চলে। Android Storage Access Framework ব্যবহার করে ফোন থেকে `.xlsx` workbook নির্বাচন করা যায়; নির্বাচিত ফাইলের read/write permission ধরে রাখার চেষ্টা করা হয় এবং মূল ফাইলের একটি backup copy app-specific external storage-এ তৈরি করা যায়।

## বর্তমান অবস্থান

**এটি এখনো সম্পূর্ণ দুই-মুখী Excel Sync build নয় এবং APK build/test করা হয়নি।**

যা আছে:
- HTML অ্যাপ `app/src/main/assets/index.html` হিসেবে যুক্ত।
- Android WebView shell এবং JavaScript bridge যুক্ত।
- ফোনের স্টোরেজ থেকে `.xlsx` ফাইল বেছে নেওয়ার ব্যবস্থা যুক্ত।
- নির্বাচিত workbook-এর permission সংরক্ষণের ব্যবস্থা যুক্ত।
- Sync-এর আগে ব্যাকআপ নেওয়ার প্রাথমিক ব্যবস্থা যুক্ত।

যা এখনো বাকি:
- `Sheet3` ও `Sheet1`-এর জন্য XLSX read/write engine।
- Excel থেকে records import এবং App-এর records Excel-এ export।
- দুই জায়গায় একই তারিখে edit হলে conflict resolution।
- Formula recalculation/Excel compatibility পরীক্ষা।
- Android Studio/Gradle দিয়ে APK build এবং বাস্তব ফোনে পরীক্ষা।

## Workbook mapping (পরিকল্পিত)

- `Sheet3`: Row 3 তারিখ; Rows 4–9 ছয় Generator-এর meter reading; Row 32 Gas meter; Row 43 Production।
- `Sheet1`: Column A তারিখ, B Gen#01 meter reading, F Run Hour; C–E formula-driven Generation/Cumulative/Efficiency।
- নমুনা workbook-এর পুরোনো ডেটা প্রথমবার অ্যাপে নিজে থেকে import করা হবে না।
- অ্যাপের monthly energy cumulative reset নীতি আলাদা; Excel-এর continuous cumulative formulas অক্ষত রাখার পরিকল্পনা।

## Build

Android Studio-তে এই folder open করুন। Gradle sync করে Android SDK 35 ইনস্টল থাকা নিশ্চিত করুন, তারপর Build > Build Bundle(s) / APK(s) > Build APK(s)।

এই সোর্সে এখনো `syncFromExcel()` ও `syncToExcel()` ইচ্ছাকৃতভাবে `ENGINE_PENDING` ফেরত দেয়—অর্থাৎ Sync engine না হওয়া পর্যন্ত বোতাম/ফাংশনকে সফল দেখানো হচ্ছে না।
