package com.badsha.generatorlog

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pickWorkbook = 4101
    private var workbookUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AndroidExcel")
        web.loadUrl("file:///android_asset/index.html")
        val saved = getSharedPreferences("excel_link", MODE_PRIVATE).getString("uri", null)
        if (saved != null) {
            workbookUri = Uri.parse(saved)
            try { contentResolver.takePersistableUriPermission(workbookUri!!, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
        }
    }

    inner class Bridge {
        @JavascriptInterface fun chooseWorkbook() { runOnUiThread { openPicker() } }
        @JavascriptInterface fun hasWorkbook(): Boolean = workbookUri != null
        @JavascriptInterface fun workbookName(): String = workbookUri?.lastPathSegment ?: ""
        @JavascriptInterface fun getWorkbookState(): String = JSONObject().apply {
            put("connected", workbookUri != null)
            put("name", workbookUri?.lastPathSegment ?: "")
            put("stage", "picker-ready")
        }.toString()
        @JavascriptInterface fun backupWorkbook(): String {
            val uri = workbookUri ?: return "NO_WORKBOOK"
            return try {
                val dir = File(getExternalFilesDir(null), "ExcelBackups").apply { mkdirs() }
                val out = File(dir, "workbook_backup_${System.currentTimeMillis()}.xlsx")
                contentResolver.openInputStream(uri).use { input -> FileOutputStream(out).use { output -> input!!.copyTo(output) } }
                out.absolutePath
            } catch (e: Exception) { "ERROR:${e.message}" }
        }
        @JavascriptInterface fun syncFromExcel(): String = "ENGINE_PENDING"
        @JavascriptInterface fun syncToExcel(json: String): String = "ENGINE_PENDING"
    }

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, pickWorkbook)
    }

    @Deprecated("Deprecated in Android API but retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickWorkbook && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
            workbookUri = uri
            getSharedPreferences("excel_link", MODE_PRIVATE).edit().putString("uri", uri.toString()).apply()
            Toast.makeText(this, "Excel workbook connected", Toast.LENGTH_SHORT).show()
            web.evaluateJavascript("window.onExcelWorkbookConnected && window.onExcelWorkbookConnected()", null)
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
