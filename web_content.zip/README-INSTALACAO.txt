WBS MOBI — PACOTE DE SERVIDOR E BANCO DE DADOS
================================================
O que acompanha:
- API Node.js do projeto recebido
- PostgreSQL 16
- Docker Compose para subir banco + API
- Banco persistente em volume Docker
- Painel administrativo servido pela API em /admin.html

IMPORTANTE
Este pacote não inclui o aplicativo Android/cliente visual de passageiro e motorista.
Também não publica automaticamente na internet: é necessário um servidor VPS/Cloud e domínio/HTTPS.

INSTALAÇÃO EM SERVIDOR COM DOCKER
1. Envie e extraia esta pasta no servidor.
2. Copie .env.example para .env
3. Edite .env: defina POSTGRES_PASSWORD, DATABASE_URL com a MESMA senha,
   JWT_SECRET longo e ADMIN_PASSWORD forte. Não compartilhe o .env.
4. Execute: docker compose up -d --build
5. Inicialize o banco e o primeiro administrador:
   docker compose exec api npm run db:init
6. Teste: http://IP-DO-SERVIDOR:3000/api/health
7. Painel: http://IP-DO-SERVIDOR:3000/admin.html

Para produção, NÃO deixe a porta 3000 exposta publicamente sem HTTPS/reverse proxy.
Configure domínio + proxy TLS (ex.: Caddy/Nginx), firewall permitindo apenas SSH e 80/443,
backups PostgreSQL e monitoramento. Não use credenciais padrão.

BANCO
O script server/src/init-db.js cria users, driver_profiles e rides e cria o administrador
indicado em ADMIN_EMAIL/ADMIN_PASSWORD. A API calcula comissão de 15% no servidor.
O banco fica no volume wbs_pgdata; apagar o volume apaga os dados.

ENDPOINTS PRINCIPAIS
POST /api/auth/register
POST /api/auth/login
GET  /api/me (Bearer JWT)
GET  /api/admin/summary (admin)
GET  /api/admin/drivers (admin)
PATCH /api/admin/drivers/:id/approve (admin)
PATCH /api/admin/drivers/:id/reject (admin)
POST /api/driver/online|offline|location (driver)
POST /api/rides (passenger)
POST /api/rides/:id/accept (driver)
POST /api/rides/:id/complete (driver)
GET /api/rides/:id (participantes/admin)

ANTES DE OPERAR COM CLIENTES
É um MVP técnico, não um serviço de transporte pronto para operação.
Faltam app Android completo, mapas/rotas e preço real, pagamentos/Pix e conciliação,
push notifications, upload seguro e validação documental, termos/privacidade/LGPD,
testes de segurança/carga e procedimentos operacionais. A localização só deve ser coletada
com consentimento e controles claros.
