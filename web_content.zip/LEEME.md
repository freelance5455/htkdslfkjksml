# FanRadar — proyecto Android nativo

Proyecto Android (Java + WebView) que ya incluye la app compilada en `app/src/main/assets/www`. No necesita servidor ni Node para compilarse.

## En newly.app (u otro compilador de proyectos Android)
- Sube este zip tal cual (tiene `settings.gradle`, `gradlew` y el módulo `app` en la raíz).
- Bundle Identifier: usa **com.crowd.fanradar** (todo en minúsculas; coincide con el `applicationId` del proyecto).
- Requisitos del proyecto: JDK 17+, Gradle 8.11.1 (lo descarga `gradlew`), Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 24.

## Alternativa: GitHub
Sube el contenido a un repo, pestaña Actions → "Compilar APK de Android" → Run workflow. El APK queda en Releases.

## Uso
1. **Ajustes → Cuentas**: inicia sesión con Google y/o Reddit (pasos abajo). Alternativa para solo buscar en YouTube: pega una clave de API en "Clave de YouTube".
2. **Buscar**: 3 a 6 bandas parecidas. Con sesión, la búsqueda usa tu cuenta (Reddit ya no depende del JSON público).
3. **Fans**: filtra por estado. **Responder en YouTube** publica una respuesta *pública* a su comentario (50 unidades de cuota); **Mensaje en Reddit** manda un mensaje privado. Cada envío es uno por uno, editable y con confirmación; al enviar pasa a *Contactado*. *Copiar mensaje* sigue disponible.

## Crear las credenciales (una sola vez)
**Google (YouTube)** — usa el flujo de dispositivos: la app muestra un código y lo escribes en google.com/device.
1. console.cloud.google.com → crea un proyecto → activa **YouTube Data API v3**.
2. Pantalla de consentimiento OAuth: tipo **Externo**; en *Usuarios de prueba* agrega tu correo.
3. Credenciales → Crear credenciales → ID de cliente de OAuth → tipo **TVs y dispositivos de entrada limitada**.
4. Pega Client ID y Client secret en Ajustes → Cuentas. En modo "Prueba" la sesión caduca a los 7 días (vuelves a iniciar). La cuenta necesita tener un canal de YouTube para comentar.

**Reddit**
1. reddit.com/prefs/apps → *create another app* → tipo **installed app**.
2. Redirect uri: `fanradar://reddit`
3. Pega el ID (bajo el nombre de la app) en Ajustes → Cuentas → Reddit Client ID.

Los tokens se guardan solo en este teléfono. "Cerrar sesión" los borra (Google además los revoca).

## Instagram, Facebook y TikTok
Estas redes **no permiten buscar fans en publicaciones de terceros por API** (TikTok solo da comentarios a investigadores aprobados; Instagram/Facebook solo a quienes comentan en *tus* publicaciones). Por eso hay tres vías:
- **Tu audiencia (Instagram y Facebook, por API oficial de Meta):** Buscar → marca *Instagram (tu cuenta)* / *Facebook (tu Página)*. Lee a quienes comentan tus últimas 10 publicaciones (y quienes te etiquetan en Instagram) y puedes **responder** su comentario desde la app (respuesta pública). No exige bandas parecidas.
- **Alta manual (cualquier red, incluido TikTok):** Fans → *＋ Agregar fan manual*: pega `@usuario` o el enlace de su perfil (Instagram, TikTok, Facebook, YouTube, Reddit), con nota y enlace a su comentario. Entra al mismo flujo de estados y mensajes; en redes sin API el botón es *Abrir perfil* + *Copiar mensaje*.
- **Atajos de exploración:** Buscar → *Explorar en Instagram, TikTok y Facebook*: por cada banda, género y hashtag abre la búsqueda en cada red para que encuentres gente y la agregues a mano.

**Conectar Meta (una sola vez):**
1. Tu Instagram debe ser cuenta profesional (Creador o Empresa) y estar ligada a tu Página de Facebook.
2. developers.facebook.com → Mis apps → Crear app. Copia el **App ID** y el **App secret** (Configuración → Básica). Debes ser administrador de la app y de la Página (modo desarrollo: no requiere revisión de Meta).
3. Explorador de la Graph API → elige tu app → *Generar token de acceso de usuario* con: `pages_show_list`, `pages_read_engagement`, `pages_read_user_content`, `pages_manage_engagement`, `instagram_basic`, `instagram_manage_comments` (y `business_management` si tu Página está en Business Manager).
4. Pega App ID, App secret y el token en Ajustes → Cuentas → *Conectar Meta*. La app lo cambia por un token de Página que no caduca y borra el token corto.
Si algún día Meta responde "sesión caducada" o falla por versión, vuelve a conectar; la versión de la Graph API (`v23.0`) está en `web-src/src/core/meta.ts`.

Limitaciones: Facebook no entrega un enlace al perfil de quien comenta (se abre su comentario); los mensajes privados de Instagram/Facebook no están (Meta solo los permite como respuesta a un mensaje previo del usuario).

## Avisos
- YouTube y Reddit penalizan los mensajes no solicitados en masa y pueden suspender cuentas. Envía pocos, personalizados y con un solo enlace.
- Revisa los términos de cada red antes de contactar a alguien: nada de envíos masivos.

## Estructura
- `app/src/main/java/com/fanradar/app/` — MainActivity (WebView; recibe `fanradar://reddit`) y NativeBridge (HTTPS sin CORS, portapapeles y abrir el navegador; solo hosts de Google y Reddit).
- `app/src/main/assets/www/` — interfaz ya compilada.
- `web-src/` — código fuente de la interfaz (TypeScript). Para regenerarla: `cd web-src && npm install && npm test && npm run build`.

Versión 1.2.0. Las pruebas usan respuestas simuladas: el inicio de sesión y los envíos reales aún no se han probado en un teléfono.
