FAST & FLUFFY — Android-installable Progressive Web App (PWA)

This is a functional Android-friendly web app, NOT a compiled APK.

To run locally on a computer:
  python3 -m http.server 8080
Then visit http://localhost:8080

To install on Android:
1. Upload this folder's contents to an HTTPS web host (e.g. GitHub Pages, Netlify).
2. Visit the HTTPS address in Android Chrome.
3. Open Chrome menu > Add to Home screen / Install app.

An HTTPS host is needed for installability on another phone. Opening index.html directly may display the interface, but offline installation and external food search may not function.

Features: saved fasting countdown (12/14/16/18/20 h), water goals and daily sip history, food meal planner, built-in offline foods, Open Food Facts online packaged-food search, nutrition totals, custom food entry, research-based drink guidance.

Limitations: no reliable background end-of-fast alarm; countdown uses end timestamp and catches up on reopening. Does not sync between devices. Online food API availability depends on Open Food Facts / CORS. This version is a PWA rather than a native APK.
