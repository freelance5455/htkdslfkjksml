package com.mpediting.manager.data

import android.util.Patterns
import kotlinx.coroutines.flow.Flow

class MpRepository(private val dao: AppDao) {
    val customers: Flow<List<CustomerEntity>> = dao.observeCustomers()
    val orders: Flow<List<OrderEntity>> = dao.observeOrders()
    val payments: Flow<List<PaymentEntity>> = dao.observeAllPayments()
    val revisions: Flow<List<RevisionEntity>> = dao.observeAllRevisions()
    val services: Flow<List<ServiceEntity>> = dao.observeServices()
    val expenses: Flow<List<ExpenseEntity>> = dao.observeExpenses()
    val portfolio: Flow<List<PortfolioItemEntity>> = dao.observePortfolio()
    val reminders: Flow<List<ReminderEntity>> = dao.observeReminders()
    val settings: Flow<AppSettingsEntity?> = dao.observeSettings()

    fun isValidUrl(url: String): Boolean {
        if (url.isBlank()) return true
        return Patterns.WEB_URL.matcher(url.trim()).matches() &&
            (url.startsWith("https://") || url.startsWith("http://"))
    }

    suspend fun saveCustomer(customer: CustomerEntity): Result<Unit> {
        val existing = dao.findCustomerByMobile(customer.mobile)
        if (existing != null && existing.id != customer.id) {
            return Result.failure(IllegalArgumentException("Duplicate mobile number: ${customer.mobile}"))
        }
        dao.upsertCustomer(customer)
        return Result.success(Unit)
    }

    suspend fun deleteCustomer(customer: CustomerEntity) = dao.deleteCustomer(customer)
    suspend fun saveOrder(order: OrderEntity) = dao.upsertOrder(order)
    suspend fun deleteOrder(order: OrderEntity) = dao.deleteOrder(order)
    suspend fun addPayment(payment: PaymentEntity) = dao.insertPayment(payment)
    suspend fun deletePayment(payment: PaymentEntity) = dao.deletePayment(payment)
    suspend fun saveRevision(revision: RevisionEntity) = dao.upsertRevision(revision)
    suspend fun saveService(service: ServiceEntity) = dao.upsertService(service)
    suspend fun deleteService(service: ServiceEntity) = dao.deleteService(service)
    suspend fun saveExpense(expense: ExpenseEntity) = dao.upsertExpense(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = dao.deleteExpense(expense)
    suspend fun savePortfolioItem(item: PortfolioItemEntity) = dao.upsertPortfolioItem(item)
    suspend fun deletePortfolioItem(item: PortfolioItemEntity) = dao.deletePortfolioItem(item)
    suspend fun saveReminder(reminder: ReminderEntity) = dao.upsertReminder(reminder)
    suspend fun deleteReminder(reminder: ReminderEntity) = dao.deleteReminder(reminder)
    suspend fun saveSettings(settings: AppSettingsEntity) = dao.saveSettings(settings)
}
