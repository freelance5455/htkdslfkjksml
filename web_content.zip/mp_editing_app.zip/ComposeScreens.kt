package com.mpediting.manager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mpediting.manager.data.OrderEntity
import com.mpediting.manager.ui.DashboardMetrics
import com.mpediting.manager.ui.theme.*

@Composable
fun NativeDashboardScreen(
    metrics: DashboardMetrics,
    recentOrders: List<OrderEntity>,
    onQuickAddOrder: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("MP Editing Manager", color = PrimaryPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("फोटो और वीडियो एडिटिंग डैशबोर्ड", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onQuickAddOrder,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("+ नया ऑर्डर जोड़ें (Quick Add Order)", color = MainText)
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("1. Total Orders", "${metrics.totalOrders}", Modifier.weight(1f))
                StatCard("2. New Orders", "${metrics.newOrders}", Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("3. Active Orders", "${metrics.activeOrders}", Modifier.weight(1f))
                StatCard("4. Completed", "${metrics.completedOrders}", Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("5. Delivered", "${metrics.deliveredOrders}", Modifier.weight(1f))
                StatCard("6. Business Value", "₹${metrics.totalBusinessValue.toInt()}", Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("7. Received", "₹${metrics.totalReceivedPayment.toInt()}", Modifier.weight(1f))
                StatCard("8. Outstanding", "₹${metrics.outstandingPayments.toInt()}", Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("9. Today's Delivery", "${metrics.todayDeliveries}", Modifier.weight(1f))
                StatCard("10. Overdue", "${metrics.overdueOrders}", Modifier.weight(1f))
            }
        }

        item {
            Text("हाल के ऑर्डर (Recent Orders)", color = MainText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        items(recentOrders) { ord ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("${ord.orderId} • ${ord.customerName}", color = MainText, fontWeight = FontWeight.Bold)
                        Text("${ord.editingCategory} • ${ord.editingService}", color = SecondaryText, fontSize = 12.sp)
                        Text("Deadline: ${ord.deliveryDeadline} | Status: ${ord.status}", color = PrimaryPurple, fontSize = 12.sp)
                    }
                    Text("₹${ord.totalPrice.toInt()}", color = StatusSuccess, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, color = SecondaryText, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = MainText, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
