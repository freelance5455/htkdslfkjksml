package com.mpediting.manager.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "customers",
    indices = [Index(value = ["mobile"], unique = true)]
)
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val mobile: String,
    val whatsapp: String,
    val email: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId"), Index("status"), Index("orderDate"), Index("deliveryDeadline")]
)
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val customerId: String,
    val customerName: String,
    val customerMobile: String,
    val orderDate: String,          // YYYY-MM-DD
    val deliveryDeadline: String,   // YYYY-MM-DD
    val editingCategory: String,    // PHOTO EDITING / VIDEO EDITING / Custom
    val editingService: String,
    val description: String = "",
    val specialInstructions: String = "",
    val totalPrice: Double,         // Agreed price preserved even if default price changes
    val fileReference: String = "",
    val deliveryLink: String = "",
    val deliveryDate: String = "",
    val deliveryConfirmed: Boolean = false,
    val internalNotes: String = "",
    val status: String = "New Order",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = OrderEntity::class,
            parentColumns = ["orderId"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("orderId"), Index("paymentDate")]
)
data class PaymentEntity(
    @PrimaryKey val paymentId: String,
    val orderId: String,
    val amount: Double,
    val method: String,             // Cash, UPI, Bank Transfer, Other
    val paymentDate: String,        // YYYY-MM-DD
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "revisions",
    foreignKeys = [
        ForeignKey(
            entity = OrderEntity::class,
            parentColumns = ["orderId"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("orderId")]
)
data class RevisionEntity(
    @PrimaryKey val revisionId: String,
    val orderId: String,
    val revisionNumber: Int,
    val request: String,
    val requestDate: String,
    val notes: String = "",
    val status: String = "Pending", // Pending, In Progress, Completed
    val completionDate: String = ""
)

@Entity(tableName = "services")
data class ServiceEntity(
    @PrimaryKey val serviceId: String,
    val category: String,           // PHOTO EDITING / VIDEO EDITING / CUSTOM
    val serviceName: String,
    val defaultPrice: Double
)

@Entity(tableName = "expenses", indices = [Index("date")])
data class ExpenseEntity(
    @PrimaryKey val expenseId: String,
    val name: String,
    val amount: Double,
    val category: String,           // Internet, Software Subscription, Storage, Equipment, Other
    val date: String,               // YYYY-MM-DD
    val description: String = ""
)

@Entity(tableName = "portfolio_items")
data class PortfolioItemEntity(
    @PrimaryKey val itemId: String,
    val title: String,
    val category: String,           // Photo Editing, Video Editing, Cinematic, Posters, Before and After, Other
    val mediaType: String,          // IMAGE, VIDEO
    val fileUri: String,
    val description: String = "",
    val tagsCsv: String = "",
    val isFavorite: Boolean = false
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val reminderId: String,
    val title: String,
    val date: String,
    val type: String,               // Upcoming Delivery, Overdue Orders, Pending Payments, Revision Requests, Important Tasks
    val isCompleted: Boolean = false
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val appName: String = "MP Editing Manager",
    val businessName: String = "MP Photo & Video Editing Studio",
    val ownerInfo: String = "",
    val primaryLanguage: String = "HI_EN",
    val currency: String = "INR (₹)",
    val defaultDeliveryDays: Int = 3,
    val notifyDelivery: Boolean = true,
    val notifyPayment: Boolean = true,
    val notifyRevision: Boolean = true,
    val pinLockEnabled: Boolean = false,
    val pinCode: String = "1234",
    val biometricEnabled: Boolean = false
)
