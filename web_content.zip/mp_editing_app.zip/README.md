# MP Editing Manager – Complete Android Application

**MP Editing Manager** फोटो और वीडियो एडिटिंग बिज़नेस ओनर्स के लिए बनाया गया एक संपूर्ण, ऑफलाइन-फर्स्ट Android एप्लिकेशन है।

---

## 1. मुख्य विशेषताएं (Core Features Implemented)

1. **प्रीमियम डार्क डिज़ाइन सिस्टम (Dark Premium UI)**:
   - Main Background: `#09090F` | Card Background: `#171722`
   - Primary Purple: `#9B6BFF` | Secondary Purple: `#7040CC`
   - Main Text: `#F7F5FF` | Secondary Text: `#AAA8B8`
   - भाषा: **Hindi + English** द्विभाषी इंटरफ़ेस।
2. **होम डैशबोर्ड (Home Dashboard)**:
   - सभी 10 लाइव आंकड़े (Total Orders, New Orders, Active Orders, Completed Orders, Delivered Orders, Total Business Value, Total Received Payment, Outstanding Payments, Today's Deliveries, Overdue Orders)
   - Recent Orders, Quick Add Order, Today's Tasks, Payment Reminders, Monthly Business Summary.
3. **ऑर्डर मैनेजमेंट (Order Management)**:
   - ऑटो-जनरेटेड Order ID (`ORD-1001`, `ORD-1002`...)
   - PHOTO EDITING और VIDEO EDITING की सभी 18+ डिफ़ॉल्ट सर्विसेज व कस्टम कैटेगरी/सर्विस सपोर्ट।
   - सभी 9 ऑर्डर स्टेटस (New Order, Files Received, Editing Pending, Editing in Progress, Ready for Review, Revision Required, Completed, Delivered, Cancelled) अलग-अलग रंगों के बैज के साथ।
   - Edit, Delete (पुष्टि मोडल के साथ), Duplicate, Search, Status/Category/Customer/Date फ़िल्टर और पूरी ऑर्डर हिस्ट्री।
4. **ग्राहक मैनेजमेंट (Customer Management)**:
   - नाम, मोबाइल, व्हाट्सएप, ईमेल, नोट्स, कुल ऑर्डर, कुल राशि, प्राप्त पेमेंट और बकाया राशि।
   - डुप्लीकेट मोबाइल नंबर की रोकथाम।
5. **पेमेंट ट्रैकिंग (Payment Management)**:
   - Cash, UPI, Bank Transfer, Other.
   - `Remaining Amount = Total Price - Total Payments Received`.
   - बकाया राशि से अधिक पेमेंट दर्ज करने पर स्पष्ट पुष्टि (Overpayment Confirmation Modal)।
6. **रेट लिस्ट मैनेजमेंट (Price List Management)**:
   - डिफ़ॉल्ट रेट बदलने पर पुराने ऑर्डर्स की तय कीमत (`totalPrice`) अपरिवर्तित रहती है।
7. **डिलीवरी लिंक और रिवीजन मैनेजमेंट (Delivery Links & Revisions)**:
   - Google Drive / Dropbox URL वैलिडेशन, Open, Copy, WhatsApp Share.
   - प्रत्येक ऑर्डर का पूरा रिवीजन इतिहास (Revision Count, Request, Date, Status, Completion Date)।
8. **पोर्टफोलियो, बिज़नेस खर्च और रिपोर्ट्स (Portfolio, Expenses & Reports)**:
   - `Business Profit = Received Revenue - Recorded Business Expenses` (बकाया पेमेंट को लाभ से अलग रखा गया है)।
   - Daily, 10-Day, Monthly और Yearly रिपोर्ट्स + चार्ट्स + PDF और Excel (CSV) एक्सपोर्ट।
9. **Room Database + ऑफलाइन बैकअप और पिन लॉक (Room DB, Backup & Security)**:
   - सभी 9 Room Entities (`CustomerEntity`, `OrderEntity`, `PaymentEntity`, `RevisionEntity`, `ServiceEntity`, `ExpenseEntity`, `PortfolioItemEntity`, `ReminderEntity`, `AppSettingsEntity`), `AppDao`, `AppDatabase`, `MpRepository`, `ExportHelper`, `ReminderWorker`.
   - 4-अंकों का PIN Lock, Biometric सपोर्ट, मैनुअल JSON बैकअप एक्सपोर्ट और रीस्टोर।

---

## 2. APK फाइल कैसे तैयार करें (Debug & Release APK Build Instructions)

### तरीका A: Android Studio के माध्यम से (Recommended)
1. इस ज़िप फाइल (`MP_Editing_Manager_Android_Project.zip`) को अनज़िप (Extract) करें।
2. **Android Studio** खोलें और **Open** पर क्लिक करके `MP_Editing_Manager_Android_Project` फोल्डर चुनें।
3. Gradle Sync पूरा होने दें।
4. **Debug APK बनाने के लिए**:
   - ऊपर मेनू में **Build > Build Bundle(s) / APK(s) > Build APK(s)** पर क्लिक करें।
   - आपकी APK यहाँ तैयार मिलेगी: `app/build/outputs/apk/debug/app-debug.apk`
5. **Signed Release APK बनाने के लिए**:
   - मेनू में **Build > Generate Signed Bundle / APK...** चुनें -> **APK** चुनें।
   - नया Keystore बनाएं (या मौजूदा चुनें) और `release` बिल्ड वेरिएंट चुनकर **Create** पर क्लिक करें।
   - आपकी रिलीज़ APK यहाँ मिलेगी: `app/build/outputs/apk/release/app-release.apk`

### तरीका B: कमांड लाइन (Terminal / Gradle CLI) से
```bash
# Debug APK बनाएं:
./gradlew assembleDebug

# Release APK बनाएं:
./gradlew assembleRelease
```

### तरीका C: अपने फोन में तुरंत चलाने के लिए
- साथ में दी गई `mp_editing_manager.html` फाइल को आप सीधे अपने Android फोन के Chrome ब्राउज़र में खोलकर **"Add to Home Screen"** कर सकते हैं — यह पूरी तरह ऑफलाइन काम करती है!
