package com.mpediting.manager.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.mpediting.manager.data.ExpenseEntity
import com.mpediting.manager.data.OrderEntity
import com.mpediting.manager.data.PaymentEntity
import java.io.File
import java.io.FileOutputStream

object ExportHelper {

    fun exportOrdersToCsv(
        context: Context,
        orders: List<OrderEntity>,
        paymentsByOrder: Map<String, Double>
    ): File {
        val file = File(context.cacheDir, "MP_Editing_Manager_Report.csv")
        val sb = StringBuilder()
        sb.append("﻿") // UTF-8 BOM for Excel Hindi support
        sb.append("Order ID,Customer Name,Mobile,Order Date,Deadline,Category,Service,Status,Total Price (INR),Received (INR),Remaining (INR),Delivery Link
")
        for (o in orders) {
            val paid = paymentsByOrder[o.orderId] ?: 0.0
            val rem = (o.totalPrice - paid).coerceAtLeast(0.0)
            sb.append("${o.orderId},"${o.customerName}",${o.customerMobile},${o.orderDate},${o.deliveryDeadline},${o.editingCategory},"${o.editingService}",${o.status},${o.totalPrice},$paid,$rem,"${o.deliveryLink}"
")
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    fun exportSummaryToPdf(
        context: Context,
        businessName: String,
        orders: List<OrderEntity>,
        payments: List<PaymentEntity>,
        expenses: List<ExpenseEntity>
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.rgb(112, 64, 204)
            textSize = 18f
            isFakeBoldText = true
        }
        val bodyPaint = Paint().apply {
            color = Color.BLACK
            textSize = 11f
        }

        val validOrders = orders.filter { it.status != "Cancelled" }
        val totalBusinessValue = validOrders.sumOf { it.totalPrice }
        val totalReceived = payments.sumOf { it.amount }
        val totalExpenses = expenses.sumOf { it.amount }
        val netProfit = totalReceived - totalExpenses
        val pendingAmount = (totalBusinessValue - totalReceived).coerceAtLeast(0.0)

        var y = 45f
        canvas.drawText("$businessName - Business Report", 36f, y, titlePaint)
        y += 28f
        canvas.drawText("Total Orders: ${orders.size} | Completed/Delivered: ${orders.count { it.status == "Completed" || it.status == "Delivered" }}", 36f, y, bodyPaint)
        y += 18f
        canvas.drawText("Total Business Value: INR $totalBusinessValue", 36f, y, bodyPaint)
        y += 18f
        canvas.drawText("Received Revenue: INR $totalReceived | Outstanding Pending: INR $pendingAmount", 36f, y, bodyPaint)
        y += 18f
        canvas.drawText("Recorded Business Expenses: INR $totalExpenses", 36f, y, bodyPaint)
        y += 18f
        canvas.drawText("Net Recorded Profit (Received - Expenses): INR $netProfit", 36f, y, titlePaint)
        y += 30f

        for (o in orders.take(25)) {
            if (y > 790f) break
            canvas.drawText("${o.orderId} | ${o.customerName} | ${o.editingService} | ${o.status} | INR ${o.totalPrice}", 36f, y, bodyPaint)
            y += 16f
        }

        doc.finishPage(page)
        val pdfFile = File(context.cacheDir, "MP_Editing_Business_Report.pdf")
        FileOutputStream(pdfFile).use { doc.writeTo(it) }
        doc.close()
        return pdfFile
    }
}
