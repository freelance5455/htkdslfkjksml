package com.mpediting.manager.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mpediting.manager.data.AppDatabase
import kotlinx.coroutines.flow.first
import java.time.LocalDate

class ReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val dao = AppDatabase.getInstance(applicationContext).appDao()
        val orders = dao.observeOrders().first()
        val today = LocalDate.now().toString()

        val dueTodayCount = orders.count {
            it.deliveryDeadline == today && it.status != "Delivered" && it.status != "Cancelled"
        }
        val overdueCount = orders.count {
            it.deliveryDeadline < today && it.status != "Completed" && it.status != "Delivered" && it.status != "Cancelled"
        }

        if (dueTodayCount > 0 || overdueCount > 0) {
            showNotification(
                title = "MP Editing Manager डिलीवरी अलर्ट",
                message = "आज की डिलीवरी: $dueTodayCount | ओवरड्यू ऑर्डर: $overdueCount"
            )
        }
        return Result.success()
    }

    private fun showNotification(title: String, message: String) {
        val channelId = "mp_editing_reminders"
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Editing Deadlines & Payment Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        manager.notify(1001, notification)
    }
}
