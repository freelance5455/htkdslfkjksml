package com.mpediting.manager.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Section 2: Design System Colors
val MainBackground = Color(0xFF09090F)
val CardBackground = Color(0xFF171722)
val ElevatedCard = Color(0xFF212132)
val PrimaryPurple = Color(0xFF9B6BFF)
val SecondaryPurple = Color(0xFF7040CC)
val MainText = Color(0xFFF7F5FF)
val SecondaryText = Color(0xFFAAA8B8)
val StatusSuccess = Color(0xFF22C55E)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)

private val MpDarkColorScheme = darkColorScheme(
    primary = PrimaryPurple,
    onPrimary = Color.White,
    secondary = SecondaryPurple,
    onSecondary = Color.White,
    background = MainBackground,
    onBackground = MainText,
    surface = CardBackground,
    onSurface = MainText,
    surfaceVariant = ElevatedCard,
    onSurfaceVariant = SecondaryText,
    error = StatusError,
    onError = Color.White
)

@Composable
fun MPEditingManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MpDarkColorScheme,
        content = content
    )
}
