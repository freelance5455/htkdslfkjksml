package com.mpediting.manager.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mpediting.manager.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

data class DashboardMetrics(
    val totalOrders: Int = 0,
    val newOrders: Int = 0,
    val activeOrders: Int = 0,
    val completedOrders: Int = 0,
    val deliveredOrders: Int = 0,
    val totalBusinessValue: Double = 0.0,
    val totalReceivedPayment: Double = 0.0,
    val outstandingPayments: Double = 0.0,
    val todayDeliveries: Int = 0,
    val overdueOrders: Int = 0,
    val monthlyExpenses: Double = 0.0,
    val netRecordedProfit: Double = 0.0
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getInstance(application).appDao()
    val repository = MpRepository(dao)

    val customers = repository.customers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val orders = repository.orders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payments = repository.payments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val revisions = repository.revisions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val services = repository.services.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val expenses = repository.expenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val portfolio = repository.portfolio.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reminders = repository.reminders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val settings = repository.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingsEntity())

    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(orders, payments, expenses) { ordList, payList, expList ->
        val today = LocalDate.now().toString()
        val activeSet = setOf("Files Received", "Editing Pending", "Editing in Progress", "Ready for Review", "Revision Required")
        val validOrders = ordList.filter { it.status != "Cancelled" }
        val totalVal = validOrders.sumOf { it.totalPrice }
        val receivedVal = payList.sumOf { it.amount }
        val totalExp = expList.sumOf { it.amount }
        val outstanding = (totalVal - receivedVal).coerceAtLeast(0.0)

        DashboardMetrics(
            totalOrders = ordList.size,
            newOrders = ordList.count { it.status == "New Order" },
            activeOrders = ordList.count { it.status in activeSet },
            completedOrders = ordList.count { it.status == "Completed" },
            deliveredOrders = ordList.count { it.status == "Delivered" },
            totalBusinessValue = totalVal,
            totalReceivedPayment = receivedVal,
            outstandingPayments = outstanding,
            todayDeliveries = validOrders.count { it.deliveryDeadline == today && it.status != "Delivered" },
            overdueOrders = validOrders.count { it.deliveryDeadline < today && it.status != "Completed" && it.status != "Delivered" },
            monthlyExpenses = totalExp,
            netRecordedProfit = receivedVal - totalExp
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    fun saveOrderWithOptionalAdvance(order: OrderEntity, advanceAmount: Double, paymentMethod: String) {
        viewModelScope.launch {
            repository.saveOrder(order)
            if (advanceAmount > 0) {
                repository.addPayment(
                    PaymentEntity(
                        paymentId = "PAY-${System.currentTimeMillis()}",
                        orderId = order.orderId,
                        amount = advanceAmount,
                        method = paymentMethod,
                        paymentDate = order.orderDate,
                        notes = "Advance Payment"
                    )
                )
            }
        }
    }
}
