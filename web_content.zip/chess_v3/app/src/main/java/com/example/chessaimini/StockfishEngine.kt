package com.example.chessaimini

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Small, thread-safe UCI controller for the bundled Stockfish Android binary. */
data class EngineLine(
    val multipv: Int,
    val depth: Int,
    val score: String,
    val nodes: String,
    val nps: String,
    val pv: String
)

data class EngineAnalysis(val lines: List<EngineLine>, val bestMove: String, val raw: List<String>)

class StockfishEngine(private val context: Context) {
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var readerThread: Thread? = null
    private val output = LinkedBlockingQueue<String>()
    @Volatile private var running = false

    /** Copy the bundled executable from APK assets to app-private storage before launching it. */
    fun bundledEngineFile(): File {
        val target = File(context.filesDir, "engine/stockfish")
        if (!target.exists() || target.length() < 1_000_000L) {
            target.parentFile?.mkdirs()
            context.assets.open("stockfish/stockfish").use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
        }
        target.setReadable(true, true)
        target.setWritable(true, true)
        target.setExecutable(true, true)
        return target
    }

    @Synchronized
    fun startBundled(): Boolean = try {
        start(bundledEngineFile())
    } catch (_: Exception) {
        false
    }

    @Synchronized
    fun start(engineFile: File): Boolean {
        stop()
        if (!engineFile.exists()) return false
        if (!engineFile.canExecute()) engineFile.setExecutable(true, true)
        if (!engineFile.canExecute()) return false
        return try {
            process = ProcessBuilder(engineFile.absolutePath)
                .directory(context.filesDir)
                .redirectErrorStream(true)
                .start()
            writer = process!!.outputStream.bufferedWriter()
            val reader = BufferedReader(InputStreamReader(process!!.inputStream))
            running = true
            readerThread = Thread {
                try {
                    while (running) {
                        val line = reader.readLine() ?: break
                        output.offer(line)
                    }
                } catch (_: Exception) { }
            }.apply { name = "Stockfish-UCI-reader"; isDaemon = true; start() }
            send("uci")
            if (!waitFor("uciok", 15)) { stop(); return false }
            send("isready")
            if (!waitFor("readyok", 10)) { stop(); return false }
            true
        } catch (_: Exception) {
            stop(); false
        }
    }

    @Synchronized
    fun configure(threads: Int = 2, hashMb: Int = 64, multiPv: Int = 3) {
        send("setoption name Threads value ${threads.coerceIn(1, 3)}")
        send("setoption name Hash value ${hashMb.coerceIn(16, 128)}")
        send("setoption name MultiPV value ${multiPv.coerceIn(1, 5)}")
        send("setoption name Move Overhead value 80")
        send("isready")
        waitFor("readyok", 10)
    }

    @Synchronized
    fun analyzeFen(fen: String, depth: Int = 17, movetimeMs: Int = 2200, multiPv: Int = 3): EngineAnalysis {
        require(isValidFenShape(fen)) { "Некоректний FEN. Перевір 6 частин запису позиції." }
        check(process?.isAlive == true) { "Stockfish ще не запущений." }
        while (output.poll() != null) { }
        send("setoption name MultiPV value ${multiPv.coerceIn(1, 5)}")
        send("ucinewgame")
        send("position fen ${fen.trim()}")
        send("go depth ${depth.coerceIn(8, 22)} movetime ${movetimeMs.coerceIn(500, 10000)}")
        val raw = mutableListOf<String>()
        val latest = linkedMapOf<Int, EngineLine>()
        var bestMove = "—"
        val limit = movetimeMs.coerceIn(500, 10000) + 15000L
        val deadline = System.currentTimeMillis() + limit
        while (System.currentTimeMillis() < deadline) {
            val line = output.poll(300, TimeUnit.MILLISECONDS) ?: continue
            raw += line
            if (line.startsWith("info ")) parseInfo(line)?.let { latest[it.multipv] = it }
            if (line.startsWith("bestmove ")) {
                bestMove = line.split(Regex("\\s+")).getOrNull(1) ?: "—"
                break
            }
        }
        if (bestMove == "—") throw IllegalStateException("Stockfish не відповів bestmove за відведений час. Спробуй меншу глибину або довший час.")
        return EngineAnalysis(latest.values.sortedBy { it.multipv }, bestMove, raw)
    }

    private fun isValidFenShape(fen: String): Boolean {
        val p = fen.trim().split(Regex("\\s+"))
        if (p.size != 6) return false
        if (p[1] !in listOf("w", "b")) return false
        if (p[0].length > 71) return false
        if (p[2] != "-" && !p[2].matches(Regex("[KQkq]+"))) return false
        if (p[3] != "-" && !p[3].matches(Regex("[a-h][36]"))) return false
        if (p[4].toIntOrNull() == null || p[4].toInt() < 0) return false
        if (p[5].toIntOrNull() == null || p[5].toInt() < 1) return false
        val ranks = p[0].split("/")
        if (ranks.size != 8) return false
        if (p[0].contains("/" ).not()) return false
        return ranks.all { rank ->
            var count = 0
            for (c in rank) {
                if (c in '1'..'8') count += c.digitToInt()
                else if (c in "prnbqkPRNBQK") count++ else return@all false
            }
            count == 8
        }
    }

    private fun parseInfo(line: String): EngineLine? {
        val t = line.trim().split(Regex("\\s+"))
        val pvIndex = t.indexOf("pv")
        if (pvIndex < 0) return null
        fun value(key: String, fallback: String) = t.indexOf(key).let { if (it >= 0 && it + 1 < t.size) t[it + 1] else fallback }
        val scoreIndex = t.indexOf("score")
        val score = if (scoreIndex >= 0 && scoreIndex + 2 < t.size) {
            val kind = t[scoreIndex + 1]
            val amount = t[scoreIndex + 2]
            when (kind) {
                "cp" -> String.format(java.util.Locale.US, "%+.2f", (amount.toIntOrNull() ?: 0) / 100.0)
                "mate" -> "M$amount"
                else -> "?"
            }
        } else "?"
        return EngineLine(
            value("multipv", "1").toIntOrNull() ?: 1,
            value("depth", "0").toIntOrNull() ?: 0,
            score,
            value("nodes", "—"),
            value("nps", "—"),
            t.drop(pvIndex + 1).take(14).joinToString(" ")
        )
    }

    private fun send(command: String) {
        writer?.apply { write(command); newLine(); flush() }
    }

    private fun waitFor(token: String, seconds: Long): Boolean {
        val end = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(seconds)
        while (System.currentTimeMillis() < end) {
            val line = output.poll(250, TimeUnit.MILLISECONDS) ?: continue
            if (line.contains(token)) return true
        }
        return false
    }

    @Synchronized
    fun stop() {
        try { send("quit") } catch (_: Exception) { }
        running = false
        try { process?.destroy() } catch (_: Exception) { }
        try { if (process?.isAlive == true) process?.destroyForcibly() } catch (_: Exception) { }
        process = null
        writer = null
        readerThread = null
        output.clear()
    }
}
