package com.example.chessaimini

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Square

/** A real 8x8 board view. The chess rules and legal moves come from chesslib. */
class ChessBoardView(context: Context) : View(context) {
    private val light = 0xFFF0D9B5.toInt()
    private val dark = 0xFFB58863.toInt()
    private val selectedColor = 0x99FACC15.toInt()
    private val lastColor = 0x887DB7FF.toInt()
    private val dotColor = 0xAA166534.toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var board: Board? = null
    private var selected: String? = null
    private var legalTargets: Set<String> = emptySet()
    private var lastMove: Pair<String, String>? = null
    private var flipped = false
    private var engineHint: Pair<String, String>? = null
    var onSquareTap: ((String) -> Unit)? = null

    fun setFlipped(value: Boolean) { flipped = value; invalidate() }
    fun setEngineHint(uci: String?) {
        engineHint = if (uci != null && Regex("^[a-h][1-8][a-h][1-8][qrbn]?$", RegexOption.IGNORE_CASE).matches(uci))
            uci.substring(0, 2) to uci.substring(2, 4) else null
        invalidate()
    }

    fun render(position: Board, selectedSquare: String?, targets: Set<String>, previousMove: Pair<String, String>?) {
        board = position
        selected = selectedSquare
        legalTargets = targets
        lastMove = previousMove
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val desired = width.coerceAtMost(MeasureSpec.getSize(heightMeasureSpec).takeIf { it > 0 } ?: width)
        setMeasuredDimension(width, desired)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = board ?: return
        val size = minOf(width.toFloat(), height.toFloat())
        val left = (width - size) / 2f
        val top = (height - size) / 2f
        val cell = size / 8f
        val whiteGlyphs = mapOf("KING" to "♔", "QUEEN" to "♕", "ROOK" to "♖", "BISHOP" to "♗", "KNIGHT" to "♘", "PAWN" to "♙")
        val blackGlyphs = mapOf("KING" to "♚", "QUEEN" to "♛", "ROOK" to "♜", "BISHOP" to "♝", "KNIGHT" to "♞", "PAWN" to "♟︎")
        for (row in 0..7) for (col in 0..7) {
            val file = if (flipped) 7 - col else col
            val rank = if (flipped) row + 1 else 8 - row
            val square = "${'a' + file}$rank"
            val x = left + col * cell
            val y = top + row * cell
            paint.color = if ((row + col) % 2 == 0) light else dark
            canvas.drawRect(x, y, x + cell, y + cell, paint)
            if (lastMove?.let { square == it.first || square == it.second } == true) {
                paint.color = lastColor
                canvas.drawRect(x, y, x + cell, y + cell, paint)
            }
            if (engineHint?.let { square == it.first || square == it.second } == true) {
                paint.color = 0x8878D69A.toInt()
                canvas.drawRect(x, y, x + cell, y + cell, paint)
            }
            if (selected == square) {
                paint.color = selectedColor
                canvas.drawRect(x, y, x + cell, y + cell, paint)
            }
            if (square in legalTargets) {
                val piece = pieceName(b, square)
                paint.color = dotColor
                if (piece == "NONE") canvas.drawCircle(x + cell / 2, y + cell / 2, cell * .13f, paint)
                else {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = cell * .055f
                    canvas.drawCircle(x + cell / 2, y + cell / 2, cell * .43f, paint)
                    paint.style = Paint.Style.FILL
                }
            }
            val name = pieceName(b, square)
            if (name != "NONE") {
                val side = if (name.startsWith("WHITE")) "WHITE" else "BLACK"
                val type = name.substringAfter('_')
                paint.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.NORMAL)
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = cell * .76f
                val fill = if (side == "WHITE") 0xFFFFFCF2.toInt() else 0xFF171717.toInt()
                val outline = if (side == "WHITE") 0xFF292929.toInt() else 0xFFE8E0D2.toInt()
                val glyph = (if (side == "WHITE") whiteGlyphs else blackGlyphs)[type] ?: "?"
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = cell * .035f
                paint.color = outline
                canvas.drawText(glyph, x + cell / 2, y + cell * .78f, paint)
                paint.style = Paint.Style.FILL
                paint.color = fill
                canvas.drawText(glyph, x + cell / 2, y + cell * .78f, paint)
            }
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.textSize = cell * .14f
            paint.color = if ((row + col) % 2 == 0) dark else light
            if (col == 0) canvas.drawText(rank.toString(), x + cell * .04f, y + cell * .16f, paint)
            if (row == 7) canvas.drawText(('a' + file).toString(), x + cell * .82f, y + cell * .96f, paint)
        }
    }

    private fun pieceName(b: Board, square: String): String = try {
        b.getPiece(Square.valueOf(square.uppercase())).name
    } catch (_: Exception) { "NONE" }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val size = minOf(width.toFloat(), height.toFloat())
        val left = (width - size) / 2f
        val top = (height - size) / 2f
        val col = ((event.x - left) / (size / 8f)).toInt()
        val row = ((event.y - top) / (size / 8f)).toInt()
        if (col in 0..7 && row in 0..7) {
            val file = if (flipped) 7 - col else col
            val rank = if (flipped) row + 1 else 8 - row
            onSquareTap?.invoke("${'a' + file}$rank")
        }
        return true
    }
}
