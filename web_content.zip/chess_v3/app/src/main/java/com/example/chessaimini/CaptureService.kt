package com.example.chessaimini

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Draggable overlay for the last manually analysed position. It does not capture the screen. */
class CaptureService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: View? = null
    private var stateText: TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "SHOW" -> {
                val fen = intent.getStringExtra("fen") ?: "Позицію не передано"
                val summary = intent.getStringExtra("summary") ?: "Аналіз ще не запускався."
                if (panel == null) showPanel(fen, summary) else updatePanel(fen, summary)
            }
            "UPDATE" -> updatePanel(intent.getStringExtra("fen") ?: "", intent.getStringExtra("summary") ?: "")
            "HIDE" -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun showPanel(fen: String, summary: String) {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(23, 28, 37))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = TextView(this).apply {
            text = "CHESS AI MINI  ⋮"; textSize = 13f; setTextColor(Color.WHITE)
        }
        val close = TextView(this).apply {
            text = "  ×  "; textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setOnClickListener { stopSelf() }
        }
        header.addView(heading, LinearLayout.LayoutParams(0, dp(32), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(36), dp(32)))
        stateText = TextView(this).apply {
            textSize = 11f; setTextColor(Color.LTGRAY); setPadding(0, dp(8), 0, 0)
            maxLines = 8
        }
        box.addView(header)
        box.addView(stateText)
        updatePanel(fen, summary)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(290), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(14); y = dp(120) }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        heading.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager?.updateViewLayout(box, params); true
                }
                else -> false
            }
        }
        windowManager?.addView(box, params)
        panel = box
    }

    private fun updatePanel(fen: String, summary: String) {
        stateText?.text = "$summary\n\nFEN: $fen"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) { } }
        panel = null; stateText = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
