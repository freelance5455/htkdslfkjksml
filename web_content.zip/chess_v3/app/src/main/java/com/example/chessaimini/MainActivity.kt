package com.example.chessaimini

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Move
import com.github.bhlangonijr.chesslib.Square
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var fenInput: EditText
    private lateinit var analyzeButton: Button
    private lateinit var multipvSpinner: Spinner
    private lateinit var timeSpinner: Spinner
    private lateinit var depthSpinner: Spinner
    private lateinit var boardView: ChessBoardView
    private lateinit var turnLabel: TextView
    private lateinit var moveList: TextView
    private lateinit var fenLabel: TextView
    private var chess = Board()
    private var selectedSquare: String? = null
    private var lastMove: Pair<String, String>? = null
    private var boardFlipped = false
    private var latestOverlayText = "Аналіз ще не запускався."
    private var engineHintUci: String? = null
    private val playedMoves = mutableListOf<String>()
    private var legalMoves: List<Move> = emptyList()
    private val engine by lazy { StockfishEngine(this) }
    @Volatile private var engineReady = false
    @Volatile private var analysisRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshBoard()
        initializeEngine()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(22))
            setBackgroundColor(Color.rgb(13, 18, 27))
        }
        fun label(value: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
        }
        root.addView(label("CHESS AI MINI", 25f).apply { setTypeface(null, Typeface.BOLD) })
        root.addView(label("STOCKFISH 19  •  ANALYSIS BOARD", 11f, Color.rgb(127, 168, 255)).apply {
            setPadding(0, dp(3), 0, dp(12)); setTypeface(null, Typeface.BOLD)
        })
        status = label("Запускаю Stockfish…", 12f, Color.LTGRAY)
        status.setPadding(dp(11), dp(10), dp(11), dp(10))
        status.setBackgroundColor(Color.rgb(28, 37, 51))
        root.addView(status)

        turnLabel = label("Білі ходять", 14f).apply {
            setPadding(0, dp(12), 0, dp(5)); setTypeface(null, Typeface.BOLD)
        }
        root.addView(turnLabel)
        boardView = ChessBoardView(this).apply {
            setBackgroundColor(Color.rgb(13, 18, 27))
            onSquareTap = { onBoardTap(it) }
        }
        val boardSide = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt() - 32
        root.addView(boardView, LinearLayout.LayoutParams(-1, dp(boardSide.coerceIn(250, 420))))

        val boardActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        boardActions.addView(actionButton("↶  НАЗАД") { undoMove() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        boardActions.addView(actionButton("ЗАНОВО") { resetBoard() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        boardActions.addView(actionButton("ПОВЕРНУТИ") { boardFlipped = !boardFlipped; boardView.setFlipped(boardFlipped) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(boardActions)

        moveList = label("Ходи: ще немає", 12f, Color.LTGRAY).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10)); setBackgroundColor(Color.rgb(23, 30, 42))
        }
        root.addView(moveList, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        fenLabel = label("FEN: стартова позиція", 10f, Color.GRAY).apply { setPadding(0, dp(7), 0, dp(4)) }
        fenLabel.setTextIsSelectable(true)
        root.addView(fenLabel)
        val utilityRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 2f }
        utilityRow.addView(actionButton("КОПІЮВАТИ FEN") { copyText("FEN", chess.getFen()) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        utilityRow.addView(actionButton("КОПІЮВАТИ ХОДИ") { copyText("Ходи", playedMoves.joinToString(" ")) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(utilityRow)

        val fenHeading = label("ЗАВАНТАЖИТИ ПОЗИЦІЮ З FEN", 12f, Color.rgb(127, 168, 255)).apply {
            setPadding(0, dp(13), 0, dp(6)); setTypeface(null, Typeface.BOLD)
        }
        root.addView(fenHeading)
        fenInput = EditText(this).apply {
            hint = "Встав FEN позиції"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 11f
            setSingleLine(false); minLines = 2; maxLines = 3
            setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(Color.rgb(29, 37, 50))
        }
        root.addView(fenInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(actionButton("ЗАВАНТАЖИТИ FEN") { loadFen() }, LinearLayout.LayoutParams(-1, dp(44)))

        root.addView(label("НАЛАШТУВАННЯ АНАЛІЗУ", 12f, Color.rgb(127, 168, 255)).apply {
            setPadding(0, dp(18), 0, dp(6)); setTypeface(null, Typeface.BOLD)
        })
        multipvSpinner = addSpinner(root, "Альтернативні лінії", listOf("2 варіанти", "3 варіанти", "4 варіанти", "5 варіантів"), 1)
        timeSpinner = addSpinner(root, "Час аналізу", listOf("1 секунда", "2 секунди", "3 секунди", "5 секунд"), 1)
        depthSpinner = addSpinner(root, "Глибина пошуку (максимум) ", listOf("12", "15", "17", "19", "21"), 2)
        analyzeButton = actionButton("АНАЛІЗУВАТИ ЦЮ ПОЗИЦІЮ") { runAnalysis() }.apply { isEnabled = false }
        root.addView(analyzeButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        result = label("Тут з'являться оцінка позиції, найкращий хід та альтернативні варіанти.", 12f, Color.LTGRAY)
        result.setPadding(dp(12), dp(12), dp(12), dp(12)); result.setBackgroundColor(Color.rgb(23, 30, 42))
        root.addView(result, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        root.addView(actionButton("ВІДКРИТИ ПЛАВАЮЧУ ПАНЕЛЬ") {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else startService(Intent(this, CaptureService::class.java).setAction("SHOW")
                .putExtra("fen", chess.getFen()).putExtra("summary", latestOverlayText))
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(14) })
        root.addView(label("Локальний аналіз власних завершених партій. Ходи на дошці перевіряються за шаховими правилами.", 10f, Color.GRAY).apply {
            setPadding(0, dp(10), 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun actionButton(title: String, action: () -> Unit): Button = Button(this).apply {
        text = title; textSize = 11f; setOnClickListener { action() }
    }

    private fun addSpinner(root: LinearLayout, heading: String, values: List<String>, selected: Int): Spinner {
        root.addView(TextView(this).apply { text = heading; textSize = 11f; setTextColor(Color.LTGRAY); setPadding(0, dp(4), 0, dp(2)) })
        return Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, values)
            setSelection(selected)
            root.addView(this, LinearLayout.LayoutParams(-1, dp(40)))
        }
    }

    private fun refreshBoard() {
        legalMoves = chess.legalMoves()
        val targets = selectedSquare?.let { from -> legalMoves.filter { chess.toUci(it).startsWith(from) }.map { chess.toUci(it).substring(2, 4) }.toSet() } ?: emptySet()
        boardView.render(chess, selectedSquare, targets, lastMove)
        boardView.setEngineHint(engineHintUci)
        turnLabel.text = when {
            chess.isMated() -> "Шах і мат"
            chess.isStaleMate() -> "Пат — нічия"
            chess.isKingAttacked() -> if (chess.getSideToMove().name == "WHITE") "Білі під шахом" else "Чорні під шахом"
            chess.getSideToMove().name == "WHITE" -> "Хід білих"
            else -> "Хід чорних"
        }
        moveList.text = if (playedMoves.isEmpty()) "Ходи: ще немає" else "Ходи (UCI): " + buildString {
            playedMoves.forEachIndexed { index, move ->
                if (index % 2 == 0) append("${index / 2 + 1}. ")
                append(move)
                if (index != playedMoves.lastIndex) append("  ")
            }
        }
        fenLabel.text = "FEN: ${chess.getFen()}"
    }

    private fun onBoardTap(square: String) {
        if (analysisRunning) {
            Toast.makeText(this, "Дочекайся завершення аналізу", Toast.LENGTH_SHORT).show()
            return
        }
        val selected = selectedSquare
        if (selected == null) {
            val piece = chess.getPiece(Square.valueOf(square.uppercase(Locale.ROOT)))
            if (piece.name == "NONE") return
            val isWhitePiece = piece.name.startsWith("WHITE_")
            if ((chess.getSideToMove().name == "WHITE") != isWhitePiece) return
            selectedSquare = square
            refreshBoard()
            return
        }
        if (selected == square) { selectedSquare = null; refreshBoard(); return }
        val candidates = legalMoves.filter {
            val uci = chess.toUci(it)
            uci.substring(0, 2) == selected && uci.substring(2, 4) == square
        }
        if (candidates.isEmpty()) {
            val piece = chess.getPiece(Square.valueOf(square.uppercase(Locale.ROOT)))
            selectedSquare = if (piece.name != "NONE" && piece.name.startsWith(if (chess.getSideToMove().name == "WHITE") "WHITE_" else "BLACK_")) square else null
            refreshBoard()
            return
        }
        if (candidates.size == 1) makeMove(candidates.first()) else choosePromotion(candidates)
    }

    private fun choosePromotion(options: List<Move>) {
        val labels = options.map { move ->
            when (move.getPromotion().name.substringAfterLast('_')) {
                "QUEEN" -> "Ферзь ♕"; "ROOK" -> "Тура ♖"; "BISHOP" -> "Слон ♗"; "KNIGHT" -> "Кінь ♘"; else -> move.getPromotion().name
            }
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Перетворення пішака").setItems(labels) { _, which -> makeMove(options[which]) }.setNegativeButton("Скасувати", null).show()
    }

    private fun makeMove(move: Move) {
        val uci = chess.toUci(move)
        try {
            chess.doMove(move)
            playedMoves += uci
            lastMove = uci.substring(0, 2) to uci.substring(2, 4)
            selectedSquare = null
            engineHintUci = null
            result.text = "Позицію оновлено. Натисни «АНАЛІЗУВАТИ ЦЮ ПОЗИЦІЮ», щоб отримати оцінку Stockfish."
            refreshBoard()
        } catch (e: Exception) { Toast.makeText(this, "Не вдалося виконати хід: ${e.message}", Toast.LENGTH_SHORT).show() }
    }

    private fun undoMove() {
        if (playedMoves.isEmpty()) return
        chess.undoMove(); playedMoves.removeAt(playedMoves.lastIndex)
        lastMove = playedMoves.lastOrNull()?.let { it.substring(0, 2) to it.substring(2, 4) }
        selectedSquare = null; engineHintUci = null; refreshBoard()
    }

    private fun resetBoard() {
        chess = Board(); playedMoves.clear(); selectedSquare = null; lastMove = null; engineHintUci = null
        result.text = "Нова партія. Зроби хід або завантаж FEN."
        refreshBoard()
    }

    private fun loadFen() {
        val value = fenInput.text.toString().trim()
        if (value.isBlank()) { Toast.makeText(this, "Встав FEN у поле", Toast.LENGTH_SHORT).show(); return }
        try {
            val next = Board()
            next.loadFromFen(value)
            chess = next; playedMoves.clear(); selectedSquare = null; lastMove = null; engineHintUci = null
            result.text = "FEN успішно завантажено. Тепер можна аналізувати позицію."
            refreshBoard()
        } catch (e: Exception) { Toast.makeText(this, "Некоректний FEN: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun initializeEngine() {
        thread(name = "Stockfish-startup") {
            val ok = engine.startBundled()
            if (ok) engine.configure(threads = 2, hashMb = 64, multiPv = 3)
            engineReady = ok
            runOnUiThread {
                status.text = if (ok) "Stockfish 19 готовий • ARM64 • локально" else "Stockfish не запустився. Перевір, чи binary додався під час збірки."
                analyzeButton.isEnabled = ok
            }
        }
    }

    private fun runAnalysis() {
        if (!engineReady || analysisRunning) return
        val fen = chess.getFen()
        analysisRunning = true
        val multipv = multipvSpinner.selectedItemPosition + 2
        val timeMs = listOf(1000, 2000, 3000, 5000)[timeSpinner.selectedItemPosition]
        val depth = listOf(12, 15, 17, 19, 21)[depthSpinner.selectedItemPosition]
        analyzeButton.isEnabled = false
        status.text = "Stockfish аналізує поточну позицію…"
        result.text = "Розрахунок кількох варіантів."
        thread(name = "Stockfish-analysis") {
            try {
                engine.configure(threads = 2, hashMb = 64, multiPv = multipv)
                val analysis = engine.analyzeFen(fen, depth = depth, movetimeMs = timeMs, multiPv = multipv)
                val formatted = buildString {
                    appendLine("НАЙКРАЩИЙ ХІД: ${analysis.bestMove}")
                    appendLine("────────────────────────")
                    if (analysis.lines.isEmpty()) appendLine("Stockfish не повернув ліній для цієї позиції.")
                    analysis.lines.forEach { line ->
                        appendLine("ВАРІАНТ ${line.multipv}  •  ${line.score} піш.  •  depth ${line.depth}")
                        appendLine(line.pv)
                        appendLine("Nodes: ${line.nodes}  •  NPS: ${line.nps}")
                        appendLine()
                    }
                    appendLine("Оцінка з погляду сторони, яка ходить. Ходи у варіантах — UCI-нотація.")
                }
                latestOverlayText = "Найкращий хід: ${analysis.bestMove}\n" + analysis.lines.take(3).joinToString("\n") { "${it.multipv}. ${it.score} піш. · ${it.pv}" }
                runOnUiThread {
                    if (chess.getFen() == fen) {
                        engineHintUci = analysis.bestMove
                        boardView.setEngineHint(engineHintUci)
                        status.text = "Аналіз завершено"; result.text = formatted
                    } else {
                        status.text = "Аналіз завершився, але позиція вже змінилася"
                        result.text = "Результат не застосовано, бо дошка змінилася під час розрахунку. Запусти аналіз ще раз для поточної позиції."
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Помилка аналізу"; result.text = e.message ?: "Невідома помилка" }
            } finally { runOnUiThread { analysisRunning = false; analyzeButton.isEnabled = engineReady } }
        }
    }

    private fun copyText(label: String, value: String) {
        if (value.isBlank()) {
            Toast.makeText(this, "Немає даних для копіювання", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
        Toast.makeText(this, "$label скопійовано", Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() { engine.stop(); super.onDestroy() }
}
