plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val stockfishArchive = layout.buildDirectory.file("downloads/stockfish-android-arm64-universal.tar.gz")
val stockfishAsset = layout.projectDirectory.file("src/main/assets/stockfish/stockfish")
val stockfishLicense = layout.projectDirectory.file("src/main/assets/stockfish/COPYING.txt")

val prepareStockfish by tasks.registering {
    outputs.files(stockfishAsset, stockfishLicense)
    doLast {
        val archive = stockfishArchive.get().asFile
        val target = stockfishAsset.asFile
        if (!target.exists() || target.length() < 1_000_000L) {
            archive.parentFile.mkdirs()
            if (!archive.exists() || archive.length() < 1_000_000L) {
                logger.lifecycle("Downloading official Stockfish Android ARM64 universal binary…")
                val url = java.net.URL("https://github.com/official-stockfish/Stockfish/releases/latest/download/stockfish-android-arm64-universal.tar.gz")
                val connection = url.openConnection().apply {
                    connectTimeout = 30_000
                    readTimeout = 240_000
                    setRequestProperty("User-Agent", "ChessAIMini-Android-Build")
                }
                connection.getInputStream().use { input -> archive.outputStream().use { output -> input.copyTo(output) } }
            }
            if (archive.length() < 1_000_000L) throw GradleException("Stockfish archive download is incomplete")
            val extractDir = File(archive.parentFile, "stockfish-extract")
            extractDir.deleteRecursively()
            extractDir.mkdirs()
            ant.withGroovyBuilder {
                "untar"("src" to archive, "dest" to extractDir, "compression" to "gzip")
            }
            val executable = extractDir.walkTopDown().firstOrNull {
                it.isFile && (it.name == "stockfish" || it.name.startsWith("stockfish-android-armv8"))
            } ?: extractDir.walkTopDown().firstOrNull {
                it.isFile && it.name.startsWith("stockfish-android-")
            } ?: throw GradleException("Official archive does not contain an Android ARM64 Stockfish executable")
            target.parentFile.mkdirs()
            executable.copyTo(target, overwrite = true)
            val license = extractDir.walkTopDown().firstOrNull { it.isFile && it.name.equals("Copying.txt", true) }
            if (license != null) license.copyTo(stockfishLicense.asFile, overwrite = true)
            if (target.length() < 1_000_000L) throw GradleException("Stockfish executable looks incomplete")
            logger.lifecycle("Bundled Stockfish ARM64 asset: ${target.length()} bytes")
        }
    }
}

android {
    namespace = "com.example.chessaimini"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.chessaimini"
        minSdk = 26
        targetSdk = 35
        ndk { abiFilters += listOf("arm64-v8a") }
        versionCode = 5
        versionName = "0.6"
    }
}

tasks.named("preBuild").configure { dependsOn(prepareStockfish) }


dependencies {
    // Legal move generation, FEN handling, castling, en passant and promotions.
    implementation("com.github.bhlangonijr:chesslib:1.3.7")
}
