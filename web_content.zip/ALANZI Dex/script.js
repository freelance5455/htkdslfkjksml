/* ALANZI Dex - script.js (v6.3 - إصلاحات كاملة) */
(() => {
'use strict';

const DEF = { lang:'ar',dark:true,wall:1,accent:0,fs:1, wifi:true,bt:true,dnd:false,night:false,airplane:false,mobileData:true,hotspot:false, bright:100,pct:true,h24:false,autoBright:false, mode:'touch',sens:1.8,csize:1,natural:true,labels:true,icons:true, mediaVol:70,ringVol:80,notifVol:60,alarmVol:90,vibrate:true, notifPreview:true,dndSchedule:false,notifLight:true, batterySaver:false,adaptiveBattery:true, done:false,pinh:'',devName:'ALANZI Dex', notes:[{t:'مرحبًا',b:'أهلاً بك في ALANZI Dex.'}], notifs:[{id:1, app:'store', title:'المتجر', body:'تحديثات جديدة متاحة', time:'الآن', read:false},{id:2, app:'settings', title:'النظام', body:'تم تفعيل النظام. أهلاً بك!', time:'قبل 3 د', read:false}] };
const S = Object.assign({}, DEF);
try { Object.assign(S, JSON.parse(localStorage.getItem('azdex.state') || '{}')); } catch (e) {}
if (!S.notifs) S.notifs = [...DEF.notifs];
const save = () => { try { localStorage.setItem('azdex.state', JSON.stringify(S)); } catch (e) {} };
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const L = (a, e) => S.lang === 'ar' ? a : e;
const wait = ms => new Promise(r => setTimeout(r, ms));
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const hash = s => { let h = 5381; for (const ch of 'azdex' + s) h = ((h << 5) + h + ch.charCodeAt(0)) | 0; return String(h); };
const pad = n => String(n).padStart(2, '0');
const LOC = () => S.lang === 'ar' ? 'ar-SA-u-nu-latn-ca-gregory' : 'en-US';
const fmtT = d => { let h = d.getHours(); if (!S.h24) h = h % 12 || 12; return (S.h24 ? pad(h) : h) + ':' + pad(d.getMinutes()); };
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t.t); t.t = setTimeout(() => t.classList.remove('show'), 1900); }
function dlg(h) { const d = $('#dialog'); d.innerHTML = `<div class="dlg">${h}</div>`; d.classList.remove('hidden'); d.onclick = e => { if (e.target === d) closeDlg(); }; return d; }
function closeDlg() { $('#dialog').classList.add('hidden'); }
let batt = '87%';

/* التكبير الذكي (الهوامش السوداء) */
function fit() {
  const scale = Math.min(innerWidth / 1280, innerHeight / 720);
  document.documentElement.style.setProperty('--sc', scale);
}
addEventListener('resize', fit); fit();

const P = {
 settings:'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.49.49 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
 globe:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z',
 clock:'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z',
 calc:'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM7.5 17.5H6V16h1.5v1.5zM9 9.5H6V8h3v1.5zm5 8h-4V16h4v1.5zm4 0h-2.5V16H18v1.5zm0-3H6V13h12v1.5zM18 9.5h-3V8h3v1.5z',
 notes:'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
 folder:'M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z',
 term:'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8h16v10zm-2-1h-6v-2h6v2zM7.5 17l-1.41-1.41L8.67 13l-2.58-2.59L7.5 9l4 4-4 4z',
 wifi:'M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9zm8 8l3 3 3-3a4.24 4.24 0 00-6 0zm-4-4l2 2a7.07 7.07 0 0110 0l2-2C15.14 9.14 8.87 9.14 5 13z',
 bt:'M17.71 7.71L12 2h-1v7.59L6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 11 14.41V22h1l5.71-5.71-4.3-4.29 4.3-4.29zM13 5.83l1.88 1.88L13 9.59V5.83zm1.88 10.46L13 18.17v-3.76l1.88 1.88z',
 dnd:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7 13v-2h10v2H7z',
 plane:'M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z',
 batt:'M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4z',
 moon:'M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 01-4.4 2.26 5.403 5.403 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z',
 display:'M20 15.31L23.31 12 20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69zM12 18V6c3.31 0 6 2.69 6 6s-2.69 6-6 6z',
 sun:'M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z',
 power:'M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A6.92 6.92 0 0119 12c0 3.87-3.13 7-7 7A6.995 6.995 0 018.59 6.58L7.17 5.17A8.932 8.932 0 003 12a9 9 0 0018 0c0-2.74-1.23-5.18-3.17-6.83z',
 restart:'M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
 lock:'M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z',
 apps:'M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z',
 touch:'M9 11.24V7.5a2.5 2.5 0 015 0v3.74c1.21-.81 2-2.18 2-3.74C16 5.01 13.99 3 11.5 3S7 5.01 7 7.5c0 1.56.79 2.93 2 3.74zm9.84 4.63l-4.54-2.26c-.17-.07-.35-.11-.54-.11H13v-6c0-.83-.67-1.5-1.5-1.5S10 6.67 10 7.5v10.74l-3.43-.72c-.08-.01-.15-.03-.24-.03-.31 0-.59.13-.79.33l-.79.8 4.94 4.94c.27.27.65.44 1.06.44h6.79c.75 0 1.33-.55 1.44-1.28l.75-5.27c.01-.07.02-.14.02-.2 0-.62-.38-1.16-.91-1.38z',
 mouse:'M13 1.07V9h7c0-4.08-3.05-7.44-7-7.93zM4 15c0 4.42 3.58 8 8 8s8-3.58 8-8v-4H4v4zm7-13.93C7.05 1.56 4 4.92 4 9h7V1.07z',
 up:'M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z',
 yt:'M23.5 6.19a3.02 3.02 0 00-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 00.5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 002.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 002.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81zM9.55 15.57V8.43L15.82 12l-6.27 3.57z',
 store:'M20 4H4v2h16V4zm1 10v-2l-1-5H4l-1 5v2h1v6h10v-6h4v6h2v-6h1zm-9 4H6v-4h6v4z',
 gallery:'M22 16V4c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2zm-11-4l2.03 2.71L16 11l4 5H8l3-4zM2 6v14c0 1.1.9 2 2 2h14v-2H4V6H2z',
 camera:'M12 15.2a3.2 3.2 0 100-6.4 3.2 3.2 0 000 6.4zM9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z',
 music:'M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z',
 weather:'M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z',
 cal:'M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z',
 chat:'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z',
 mail:'M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z',
 map:'M20.5 3l-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5zM15 19l-6-2.11V5l6 2.11V19z',
 bell:'M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z',
 vol:'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z'
};
const LOGO = `<svg viewBox="0 0 64 64" style="width:100%;height:100%;padding:4px"><defs><linearGradient id="lgd" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#A8C7FA"/><stop offset="100%" stop-color="#4A7CBF"/></linearGradient></defs><rect x="2" y="2" width="60" height="60" rx="14" fill="#0F1419"/><path d="M19 47 L32 14 L45 47 M25 37 H39" fill="none" stroke="url(#lgd)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const ic = (p, c = 'i') => `<svg class="${c}" viewBox="0 0 24 24"><path d="${p}"/></svg>`;
const APPS = [
 {id:'files',ar:'الملفات',en:'Files',c:'#fbc02d',p:P.folder,w:780,h:480},
 {id:'browser',ar:'المتصفح',en:'Browser',c:'#4285f4',p:P.globe,w:860,h:500},
 {id:'notes',ar:'الملاحظات',en:'Notes',c:'#f9a825',p:P.notes,w:760,h:460},
 {id:'calc',ar:'الحاسبة',en:'Calculator',c:'#546e7a',p:P.calc,w:310,h:440},
 {id:'clock',ar:'الساعة',en:'Clock',c:'#ef6c00',p:P.clock,w:360,h:380},
 {id:'term',ar:'الطرفية',en:'Terminal',c:'#37474f',p:P.term,w:660,h:400},
 {id:'camera',ar:'الكاميرا',en:'Camera',c:'#37474f',p:P.camera,w:640,h:520},
 {id:'music',ar:'الموسيقى',en:'Music',c:'#e91e63',p:P.music,w:640,h:460},
 {id:'gallery',ar:'معرض الصور',en:'Gallery',c:'#ff9800',p:P.gallery,w:720,h:500},
 {id:'weather',ar:'الطقس',en:'Weather',c:'#03a9f4',p:P.weather,w:560,h:520},
 {id:'calendar',ar:'التقويم',en:'Calendar',c:'#e53935',p:P.cal,w:760,h:520},
 {id:'store',ar:'المتجر',en:'App Store',c:'#00bfa5',p:P.store,w:880,h:560},
 {id:'settings',ar:'الإعدادات',en:'Settings',c:'#00897b',p:P.settings,w:920,h:540}
];
const REAL_APPS = {
 youtube:   {ar:'يوتيوب', en:'YouTube', c:'#ff0000', p:P.yt, url:'https://m.youtube.com'},
 instagram: {ar:'إنستغرام', en:'Instagram', c:'#e1306c', p:P.camera, url:'https://www.instagram.com'},
 whatsapp:  {ar:'واتساب', en:'WhatsApp', c:'#25d366', p:P.chat, url:'https://web.whatsapp.com'},
 telegram:  {ar:'تيليجرام', en:'Telegram', c:'#29a9eb', p:P.chat, url:'https://web.telegram.org'},
 facebook:  {ar:'فيسبوك', en:'Facebook', c:'#1877f2', p:P.globe, url:'https://m.facebook.com'},
 twitter:   {ar:'X', en:'X', c:'#000000', p:P.globe, url:'https://x.com'},
 tiktok:    {ar:'تيك توك', en:'TikTok', c:'#000000', p:P.music, url:'https://www.tiktok.com'},
 netflix:   {ar:'نتفليكس', en:'Netflix', c:'#e50914', p:P.yt, url:'https://www.netflix.com'},
 spotify:   {ar:'سبوتيفاي', en:'Spotify', c:'#1db954', p:P.music, url:'https://open.spotify.com'},
 gmail:     {ar:'جيميل', en:'Gmail', c:'#ea4335', p:P.mail, url:'https://mail.google.com'},
 drive:     {ar:'درايف', en:'Drive', c:'#0f9d58', p:P.folder, url:'https://drive.google.com'},
 maps:      {ar:'الخرائط', en:'Maps', c:'#1a73e8', p:P.map, url:'https://maps.google.com'}
};
const byId = id => APPS.find(a => a.id === id) || (REAL_APPS[id] ? {id, ...REAL_APPS[id]} : null), nm = a => L(a.ar, a.en);
const grad = c => { const n = parseInt(c.slice(1), 16), m = v => Math.round(v + (255 - v) * .22); return `linear-gradient(160deg,rgb(${m(n >> 16)},${m((n >> 8) & 255)},${m(n & 255)}),${c})`; };
const bx = (a, s) => `<div class="bx ${s ? 's' : ''}" style="background:${grad(a.c)}"><svg viewBox="0 0 24 24"><path fill="#fff" d="${a.p}"/></svg></div>`;
const ACC = [['#00C2FF','#0090b8',['سماوي','Cyan']],['#00BFA5','#00897b',['تيل','Teal']],['#4285f4','#1a73e8',['أزرق','Blue']],['#9c6bff','#7c4dff',['بنفسجي','Purple']],['#ff6e9e','#e0457b',['وردي','Pink']],['#ff9800','#e65100',['برتقالي','Orange']]];
const WALLS = [
 ['#002b28',[['#009688',10,10,25],['#00bfa5',90,40,15],['#00695c',20,85,30],['#009688',85,90,18],['#00897b',50,5,12]]],
 ['#07121f',[['#00C2FF',12,12,24],['#0b6e99',88,38,16],['#0a4a6e',20,86,30],['#00C2FF',86,92,14],['#08577c',50,4,12]]],
 ['#3a1230',[['#e8a2c3',12,10,22],['#c94b87',90,45,16],['#7b2a6b',20,86,30],['#f0a25a',85,92,16],['#a63a7a',50,5,12]]],
 ['#1a1030',[['#7e57c2',10,12,24],['#b39ddb',90,42,14],['#4527a0',20,86,30],['#9575cd',85,92,16],['#5e35b1',50,5,12]]],
 ['#111418',[['#2b3038',10,10,26],['#3a414c',90,40,15],['#1d2127',20,85,30],['#2b3038',85,90,18],['#353b45',50,5,12]]],
 ['#0b2a12',[['#2e7d32',10,10,25],['#9ccc65',90,40,14],['#1b5e20',20,85,30],['#66bb6a',85,90,16],['#388e3c',50,5,12]]]];
const wallImg = w => w[1].map(([c, x, y, r]) => `radial-gradient(circle at ${x}% ${y}%,${c} 0,${c} ${r}%,transparent ${r + .1}%)`).join(',');
const NAVSVG = {home:'<svg viewBox="0 0 22 22"><circle cx="11" cy="11" r="8" fill="none" stroke="#fff" stroke-width="2.4"/></svg>', rec:'<svg viewBox="0 0 20 20"><rect x="3" y="3" width="14" height="14" rx="3" fill="none" stroke="#fff" stroke-width="2.4"/></svg>', back:'<svg viewBox="0 0 22 22"><path d="M17 3L5 11l12 8z" fill="#fff"/></svg>'};

const cur = $('#cursor'); let cx = innerWidth / 2, cy = innerHeight / 2, hv = null, lastClick = {t: 0, x: 0, y: 0};
function setCur(x, y) { cx = Math.max(0, Math.min(innerWidth - 1, x)); cy = Math.max(0, Math.min(innerHeight - 1, y)); cur.style.transform = `translate(${cx}px,${cy}px)`; hover(); }
function hover() { if (S.mode !== 'mouse') return; const el = document.elementFromPoint(cx, cy), t = el && el.closest('button,.tk,.ic,.mi,.row,.tile,.fi,.key,.n,.notif,.st-app'); if (t !== hv) { hv && hv.classList.remove('hv'); hv = t; hv && hv.classList.add('hv'); } }
function setMode(m, quiet) {
  S.mode = m; save(); cur.classList.toggle('hidden', m !== 'mouse'); cur.style.setProperty('--cs', S.csize);
  $('#m-touch').classList.toggle('on', m === 'touch'); $('#m-mouse').classList.toggle('on', m === 'mouse');
  if (hv) { hv.classList.remove('hv'); hv = null; }
  if (m === 'mouse') { setCur(innerWidth / 2, innerHeight / 2); if (!quiet) toast(L('وضع الفأرة: اسحب بإصبعك لتحريك المؤشر، اضغط للنقر', 'Mouse mode: drag to move, tap to click')); }
  else if (!quiet) toast(L('وضع اللمس', 'Touch mode'));
}
function fire(type, el) {
  el = el || document.elementFromPoint(cx, cy) || document.body;
  const ev = new PointerEvent(type, {bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 7, pointerType: 'mouse', isPrimary: true, button: 0, buttons: type === 'pointerup' ? 0 : 1, view: window});
  (type === 'pointermove' ? document : el).dispatchEvent(ev);
}
function clickAt() {
  const el = document.elementFromPoint(cx, cy); if (!el) return;
  fire('pointerdown', el); fire('pointerup', el);
  el.dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true, clientX: cx, clientY: cy, view: window, detail: 1}));
  const f = el.closest('input,textarea'); if (f) f.focus(); else if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur();
  const n = Date.now();
  if (n - lastClick.t < 380 && Math.hypot(cx - lastClick.x, cy - lastClick.y) < 14) { el.dispatchEvent(new MouseEvent('dblclick', {bubbles: true, cancelable: true, clientX: cx, clientY: cy, view: window, detail: 2})); lastClick.t = 0; }
  else lastClick = {t: n, x: cx, y: cy};
}
function scrollAt(dx, dy) {
  let el = document.elementFromPoint(cx, cy); const k = S.natural ? 1 : -1;
  while (el && el !== document.body) { const o = getComputedStyle(el).overflowY; if ((o === 'auto' || o === 'scroll') && el.scrollHeight > el.clientHeight) { el.scrollTop += dy * k; break; } el = el.parentElement; }
}
let T = null;
document.addEventListener('touchstart', e => {
  if (S.mode !== 'mouse' || e.target.closest('.modeb')) return; e.preventDefault();
  const t = e.touches;
  if (t.length >= 2) { if (T) clearTimeout(T.h); T = {two: true, y: (t[0].clientY + t[1].clientY) / 2, moved: 0}; return; }
  T = {x: t[0].clientX, y: t[0].clientY, t0: Date.now(), moved: 0, drag: false};
  T.h = setTimeout(() => { if (T && !T.two && T.moved < 8) { T.drag = true; if (navigator.vibrate) navigator.vibrate(15); fire('pointerdown'); } }, 420);
}, {passive: false, capture: true});
document.addEventListener('touchmove', e => {
  if (S.mode !== 'mouse' || !T) return; e.preventDefault(); const t = e.touches;
  if (T.two) { if (t.length >= 2) { const y = (t[0].clientY + t[1].clientY) / 2; scrollAt(0, T.y - y); T.y = y; T.moved = 1; } return; }
  const dx = t[0].clientX - T.x, dy = t[0].clientY - T.y; T.x = t[0].clientX; T.y = t[0].clientY; T.moved += Math.abs(dx) + Math.abs(dy);
  setCur(cx + dx * S.sens, cy + dy * S.sens); if (T.drag) fire('pointermove');
}, {passive: false, capture: true});
document.addEventListener('touchend', e => {
  if (S.mode !== 'mouse' || !T) return; if (e.target.closest && e.target.closest('.modeb')) return; e.preventDefault(); clearTimeout(T.h);
  if (T.two) { if (!e.touches.length) T = null; return; }
  if (T.drag) fire('pointerup'); else if (T.moved < 10 && Date.now() - T.t0 < 320) clickAt();
  T = null;
}, {passive: false, capture: true});
document.addEventListener('pointerdown', e => {
  const r = e.target; if (e.isTrusted || !r.matches || !r.matches('input[type=range]')) return;
  const set = ev => { const b = r.getBoundingClientRect(), f = Math.max(0, Math.min(1, (ev.clientX - b.left) / b.width)), mn = +r.min, mx = +r.max, st = +r.step || 1; r.value = Math.round((mn + (mx - mn) * f) / st) * st; r.dispatchEvent(new Event('input', {bubbles: true})); };
  set(e); const up = () => { document.removeEventListener('pointermove', set); document.removeEventListener('pointerup', up); };
  document.addEventListener('pointermove', set); document.addEventListener('pointerup', up);
});
document.addEventListener('contextmenu', e => e.preventDefault());

const wins = {}; let z = 10, cas = 0;
function openApp(id, arg) {
  closeMenu(); closeQP(); const a = byId(id); if (!a) return;
  if (a.url) {
    toast(L('جاري فتح الموقع...', 'Opening site...'));
    setTimeout(() => {
      try {
        const w = window.open(a.url, '_blank');
        if (!w) throw new Error('Popup blocked');
      } catch(e) {
        const link = document.createElement('a');
        link.href = a.url; link.target = '_blank'; link.rel = 'noopener noreferrer';
        document.body.appendChild(link); link.click(); link.remove();
      }
    }, 50);
    return;
  }
  if (wins[id]) { wins[id].arg = arg; renderWin(id); return focus(id); }
  const w = document.createElement('div'); w.className = 'win';
  w.innerHTML = `<div class="wh">${bx(a, 1)}<b class="wt"></b><span class="wb"><button data-a="min">–</button><button data-a="max">▢</button><button data-a="x">✕</button></span></div><div class="wc"></div><i class="rs"></i>`;
  
  const maxW = Math.max(320, 1280 - 20), maxH = Math.max(240, 720 - 60);
  const winW = Math.min(a.w || 600, maxW);
  const winH = Math.min(a.h || 400, maxH);
  w.style.width = winW + 'px';
  w.style.height = winH + 'px';
  w.style.left = Math.max(8, Math.min(110 + (cas * 34) % 260, 1280 - winW - 20)) + 'px';
  w.style.top = Math.max(8, Math.min(24 + (cas * 28) % 140, 720 - winH - 60)) + 'px';
  
  cas++;
  $('#wins').append(w);
  const o = wins[id] = {w, clean: [], arg, back: null};
  w.addEventListener('pointerdown', () => focus(id));
  $('.wb', w).onclick = e => { const x = e.target.dataset.a; if (x === 'x') closeWin(id); else if (x === 'min') { w.style.display = 'none'; tasks(); } else if (x === 'max') w.classList.toggle('max'); };
  $('.wh', w).ondblclick = e => { if (!e.target.closest('button')) w.classList.toggle('max'); };
  drag(w, $('.wh', w)); resize(w, $('.rs', w)); renderWin(id); focus(id);
}
function renderWin(id) {
  const o = wins[id]; if (!o) return; o.clean.forEach(f => f()); o.clean = []; o.back = null;
  const a = byId(id), c = $('.wc', o.w); $('.wt', o.w).textContent = nm(a); c.innerHTML = ''; c.className = 'wc'; APP_FN[id](c, o);
}
function focus(id) { const o = wins[id]; if (!o) return; o.w.style.display = ''; o.w.style.zIndex = ++z; o.front = z; Object.keys(wins).forEach(k => wins[k].w.classList.toggle('act', k === id)); tasks(); }
function closeWin(id) { const o = wins[id]; if (!o) return; o.clean.forEach(f => f()); o.w.remove(); delete wins[id]; tasks(); }
function topWin() { return Object.keys(wins).filter(k => wins[k].w.style.display !== 'none').sort((a, b) => wins[b].front - wins[a].front)[0]; }
function tasks() {
  const top = topWin();
  $('#tasks').innerHTML = Object.keys(wins).map(k => `<div class="tk ${k === top ? 'on' : ''}" data-t="${k}">${bx(byId(k), 1)}<span>${nm(byId(k))}</span></div>`).join('');
  $$('#tasks [data-t]').forEach(e => e.onclick = () => { const k = e.dataset.t, o = wins[k]; if (o.w.style.display !== 'none' && k === topWin()) { o.w.style.display = 'none'; tasks(); } else focus(k); });
}
function drag(w, h) {
  h.addEventListener('pointerdown', e => {
    if (e.target.closest('button') || w.classList.contains('max')) return;
    const sx = e.clientX, sy = e.clientY, ox = w.offsetLeft, oy = w.offsetTop;
    const scale = Math.min(innerWidth / 1280, innerHeight / 720);
    const mv = ev => { w.style.left = Math.max(-w.offsetWidth + 80, Math.min(1280 - 80, ox + (ev.clientX - sx) / scale)) + 'px'; w.style.top = Math.max(0, Math.min(720 - 100, oy + (ev.clientY - sy) / scale)) + 'px'; };
    const up = () => { document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); };
    document.addEventListener('pointermove', mv); document.addEventListener('pointerup', up);
  });
}
function resize(w, h) {
  h.addEventListener('pointerdown', e => {
    e.stopPropagation(); const sx = e.clientX, sy = e.clientY, ow = w.offsetWidth, oh = w.offsetHeight; focus(Object.keys(wins).find(i => wins[i].w === w));
    const scale = Math.min(innerWidth / 1280, innerHeight / 720);
    const mv = ev => { w.style.width = Math.max(300, Math.min(1280 - 10, ow + (ev.clientX - sx) / scale)) + 'px'; w.style.height = Math.max(200, Math.min(720 - 80, oh + (ev.clientY - sy) / scale)) + 'px'; };
    const up = () => { document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); };
    document.addEventListener('pointermove', mv); document.addEventListener('pointerup', up);
  });
}
$('#b-apps').innerHTML = LOGO;
$('#b-back').innerHTML = NAVSVG.back; $('#b-home').innerHTML = NAVSVG.home; $('#b-rec').innerHTML = NAVSVG.rec; $('#t-set').innerHTML = ic(P.settings);
$('#m-touch').innerHTML = ic(P.touch); $('#m-mouse').innerHTML = ic(P.mouse);
$('#m-touch').onclick = () => setMode('touch'); $('#m-mouse').onclick = () => setMode('mouse');
$('#b-home').onclick = () => { closeMenu(); closeQP(); const vis = Object.keys(wins).filter(k => wins[k].w.style.display !== 'none'); if (vis.length) vis.forEach(k => wins[k].w.style.display = 'none'); else Object.keys(wins).forEach(k => wins[k].w.style.display = ''); tasks(); };
$('#b-back').onclick = () => { if (!$('#dialog').classList.contains('hidden')) return closeDlg(); if (!$('#menu').classList.contains('hidden')) return closeMenu(); if (!$('#qp').classList.contains('hidden')) return closeQP(); const t = topWin(); if (t && wins[t].back) wins[t].back(); };
$('#b-rec').onclick = () => { const k = Object.keys(wins); if (!k.length) return toast(L('لا توجد نوافذ مفتوحة', 'No open windows')); const d = dlg(`<h3>${L('النوافذ المفتوحة', 'Recent windows')}</h3>${k.map(i => `<div class="fi" data-w="${i}">${bx(byId(i), 1)}<span>${nm(byId(i))}</span></div>`).join('')}<div class="btns"><button class="flat" id="rx">${L('إغلاق', 'Close')}</button></div>`); $('#rx', d).onclick = closeDlg; $$('[data-w]', d).forEach(e => e.onclick = () => { closeDlg(); focus(e.dataset.w); }); };
function refresh(light) {
  const r = document.documentElement, a = ACC[S.accent] || ACC[0], w = WALLS[S.wall];
  r.dataset.theme = S.dark ? 'dark' : 'light'; r.style.setProperty('--p', a[0]); r.style.setProperty('--pd', S.dark ? a[0] : a[1]); r.style.setProperty('--fs', S.fs); cur.style.setProperty('--cs', S.csize);
  $('#dim').style.opacity = (100 - S.bright) / 100 * .7; $('#night').style.display = S.night ? 'block' : 'none';
  $('#wall').style.backgroundColor = w[0]; $('#wall').style.backgroundImage = wallImg(w);
  $('#icons').classList.toggle('hidden', !S.icons); $('#bar').classList.toggle('nolab', !S.labels);
  $('#t-sig').innerHTML = [S.wifi && P.wifi, S.bt && P.bt, S.dnd && P.dnd, S.airplane && P.plane].filter(Boolean).map(p => ic(p)).join('');
  $('#t-bat').innerHTML = ic(P.batt) + (S.pct ? `<span>${batt}</span>` : '');
  $('#m-touch').classList.toggle('on', S.mode === 'touch'); $('#m-mouse').classList.toggle('on', S.mode === 'mouse');
  tick(); if (!light && !$('#qp').classList.contains('hidden')) qpRender();
}
if (navigator.getBattery) navigator.getBattery().then(b => { const u = () => { batt = Math.round(b.level * 100) + '%'; refresh(true); }; u(); b.onlevelchange = u; }).catch(() => {});
function tick() { const d = new Date(), t = fmtT(d); $('#t-clock').textContent = t; $('#lk-time').textContent = t; $('#lk-date').textContent = d.toLocaleDateString(LOC(), {weekday: 'long', day: 'numeric', month: 'long'}); }
setInterval(tick, 5000);
function setKey(k, v) {
  S[k] = v; if (k === 'airplane' && v) { S.wifi = false; S.bt = false; } if ((k === 'wifi' || k === 'bt') && v) S.airplane = false;
  save(); if (k === 'mode') setMode(v); if (k === 'lang') applyLang(); refresh();
}
function renderIcons() {
  const dl = JSON.parse(localStorage.getItem('azdex.downloaded') || '[]');
  const all = [...APPS, ...dl.map(id => REAL_APPS[id] ? {id, ...REAL_APPS[id]} : null).filter(Boolean)];
  $('#icons').innerHTML = all.map(a => `<div class="ic" data-app="${a.id}">${bx(a)}${nm(a)}</div>`).join('');
  $$('#icons .ic').forEach(e => { e.onclick = () => { if (S.mode === 'touch') openApp(e.dataset.app); else { $$('#icons .ic').forEach(x => x.classList.toggle('sel', x === e)); } }; e.ondblclick = () => openApp(e.dataset.app); });
}
function menuRender(q = '') {
  const dl = JSON.parse(localStorage.getItem('azdex.downloaded') || '[]');
  const all = [...APPS, ...dl.map(id => REAL_APPS[id] ? {id, ...REAL_APPS[id]} : null).filter(Boolean)];
  $('#mgrid').innerHTML = all.filter(a => (a.ar + a.en).toLowerCase().includes(q.toLowerCase())).map(a => `<div class="mi" data-app="${a.id}">${bx(a)}<span>${nm(a)}</span></div>`).join('');
  $$('#mgrid [data-app]').forEach(e => e.onclick = () => openApp(e.dataset.app));
}
function closeMenu() { $('#menu').classList.add('hidden'); } function closeQP() { $('#qp').classList.add('hidden'); }
$('#b-apps').onclick = () => { closeQP(); if ($('#menu').classList.contains('hidden')) { menuRender(); $('#msearch').value = ''; $('#menu').classList.remove('hidden'); } else closeMenu(); };
$('#t-set').onclick = () => { closeMenu(); if ($('#qp').classList.contains('hidden')) { qpRender(); $('#qp').classList.remove('hidden'); } else closeQP(); };
$('#msearch').oninput = e => menuRender(e.target.value);
$('#mlock').onclick = () => { closeMenu(); $('#lock').classList.remove('hidden'); tick(); }; $('#moff').onclick = () => { closeMenu(); powerMenu(); };
// التعديل: استخدام click بدل pointerdown عشان القائمة ما تختفي مع الفأرة
document.addEventListener('click', e => { if (!e.target.closest('#menu,#b-apps')) closeMenu(); if (!e.target.closest('#qp,#t-set')) closeQP(); });

const TL = [['wifi',P.wifi,'Wi-Fi'],['bt',P.bt,'Bluetooth'],['dnd',P.dnd,['عدم الإزعاج','Do not disturb']],['airplane',P.plane,['وضع الطائرة','Airplane']],['dark',P.moon,['الوضع الداكن','Dark mode']],['night',P.display,['إضاءة ليلية','Night light']]];
function qpRender() {
  const q = $('#qp');
  const unread = S.notifs.filter(n => !n.read).length;
  q.innerHTML = `<div class="tiles">${TL.map(([k, p, l]) => `<div class="tile ${S[k] ? 'on' : ''}" data-k="${k}"><i>${ic(p)}</i>${Array.isArray(l) ? L(l[0], l[1]) : l}</div>`).join('')}</div>
   <div class="sl">${ic(P.sun)}<input type="range" id="qb" min="20" max="100" value="${S.bright}"></div>
   <div class="sl">${ic(P.vol)}<input type="range" id="qv" min="0" max="100" value="${S.mediaVol}"></div>
   <div class="qs">${L('وضع التحكم', 'Control mode')}</div><div class="seg" id="qm"><button data-m="touch" class="${S.mode === 'touch' ? 'on' : ''}">${L('لمس', 'Touch')}</button><button data-m="mouse" class="${S.mode === 'mouse' ? 'on' : ''}">${L('فأرة', 'Mouse')}</button></div>
   <div class="qs">${L('سرعة المؤشر', 'Pointer speed')}</div><div class="sl"><input type="range" id="qs" min="0.8" max="4" step="0.1" value="${S.sens}"></div>
   <div class="nhead"><span>${L('الإشعارات', 'Notifications')}${unread ? ` (${unread})` : ''}</span>${S.notifs.length ? `<button id="nclear">${L('مسح', 'Clear')}</button>` : ''}</div>
   ${S.notifs.length ? S.notifs.map(n => {
     const a = byId(n.app) || {c:'#4A7CBF',p:P.bell};
     return `<div class="notif" data-id="${n.id}"><div class="ni">${bx(a,1)}</div><div class="nb"><div class="ntit">${esc(n.title)}</div><div class="nbody">${esc(n.body)}</div><div class="ntime">${esc(n.time)}</div></div><div class="nx" data-x="${n.id}">✕</div></div>`;
   }).join('') : `<p class="muted" style="text-align:center;padding:20px 0;font-size:12.5px">${L('لا توجد إشعارات', 'No notifications')}</p>`}
   <button class="qbtn" id="qo">${L('فتح الإعدادات', 'Open Settings')}</button>`;
  $$('.tile', q).forEach(t => t.onclick = () => {
    const k = t.dataset.k;
    S[k] = !S[k];
    if (k === 'airplane' && S.airplane) { S.wifi = false; S.bt = false; }
    if ((k === 'wifi' || k === 'bt') && S[k]) S.airplane = false;
    if (k === 'dark' || k === 'night') applyDark();
    save(); refresh(true);
  });
  $('#qb', q).oninput = e => { S.bright = +e.target.value; save(); refresh(true); };
  $('#qv', q).oninput = e => { S.mediaVol = +e.target.value; save(); };
  $('#qs', q).oninput = e => { S.sens = +e.target.value; save(); };
  $$('#qm button', q).forEach(b => b.onclick = () => { setKey('mode', b.dataset.m); $$('#qm button', q).forEach(x => x.classList.toggle('on', x.dataset.m === b.dataset.m)); });
  $('#qo', q).onclick = () => openApp('settings');
  const clr = $('#nclear', q); if (clr) clr.onclick = () => { S.notifs = []; save(); qpRender(); refresh(true); };
  $$('.notif', q).forEach(n => n.onclick = e => { if (e.target.closest('[data-x]')) return; const item = S.notifs.find(x => x.id == n.dataset.id); if (item) { item.read = true; n.style.opacity = .55; } save(); refresh(true); });
  $$('[data-x]', q).forEach(x => x.onclick = e => { e.stopPropagation(); S.notifs = S.notifs.filter(n => n.id != x.dataset.x); save(); qpRender(); refresh(true); });
}
function applyDark() {
  document.documentElement.dataset.theme = S.dark ? 'dark' : 'light';
  const a = ACC[S.accent] || ACC[0];
  document.documentElement.style.setProperty('--sa', S.dark ? a[0] : a[1]);
  Object.keys(wins).forEach(renderWin);
}
function pinEntry(title, cb) {
  let v = '';
  const d = dlg(`<h3 style="text-align:center">${title}</h3><div class="dots" id="pd"><i></i><i></i><i></i><i></i></div><div class="err" id="pe"></div><div class="keys">${[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k => `<div class="key" data-k="${k}">${k}</div>`).join('')}</div><div class="btns"><button class="flat" id="px">${L('إلغاء', 'Cancel')}</button></div>`);
  const draw = () => $$('#pd i', d).forEach((x, i) => x.classList.toggle('on', i < v.length));
  $('#px', d).onclick = closeDlg;
  $$('.key', d).forEach(k => k.onclick = async () => { const x = k.dataset.k; if (x === '') return; if (x === '⌫') v = v.slice(0, -1); else if (v.length < 4) v += x; draw();
    if (v.length === 4) { const r = await cb(v); if (r === false) { v = ''; draw(); $('#pe', d).textContent = L('رمز غير صحيح', 'Wrong PIN'); const b = $('.dlg', d); b.classList.add('shake'); setTimeout(() => b.classList.remove('shake'), 400); } else if (r !== 'keep') closeDlg(); } });
}
function setLock() {
  if (S.pinh) return pinEntry(L('أدخل رمز PIN الحالي', 'Enter current PIN'), p => { if (hash(p) !== S.pinh) return false; S.pinh = ''; save(); toast(L('تم إلغاء القفل', 'Screen lock removed')); rerenderSettings(); return true; });
  pinEntry(L('اختر رمز PIN جديد', 'Choose a new PIN'), p1 => { pinEntry(L('أكّد رمز PIN', 'Confirm PIN'), p2 => { if (p1 !== p2) { toast(L('الرمزان غير متطابقين', "PINs don't match")); return; } S.pinh = hash(p2); save(); toast(L('تم تفعيل قفل PIN', 'PIN lock enabled')); rerenderSettings(); }); return 'keep'; });
}
$('#lock').onclick = () => { if (!S.pinh) return $('#lock').classList.add('hidden'); pinEntry(L('أدخل رمز PIN', 'Enter your PIN'), p => { if (hash(p) === S.pinh) { $('#lock').classList.add('hidden'); return true; } return false; }); };
function powerMenu() {
  const d = dlg(`<h3>${L('الطاقة', 'Power')}</h3><div class="fi" id="pr">${ic(P.restart)}<span>${L('إعادة التشغيل', 'Restart')}</span></div><div class="fi" id="po">${ic(P.power)}<span>${L('إطفاء', 'Power off')}</span></div><div class="btns"><button class="flat" id="pc">${L('إلغاء', 'Cancel')}</button></div>`);
  $('#pc', d).onclick = closeDlg; $('#pr', d).onclick = () => { closeDlg(); shutdown(true); }; $('#po', d).onclick = () => { closeDlg(); shutdown(false); };
}
async function shutdown(restart) {
  Object.keys(wins).forEach(closeWin); const off = $('#off'); off.classList.remove('hidden'); $('#off-btn').classList.add('hidden');
  $('#off-msg').innerHTML = `<div class="spin"></div><p>${restart ? L('جارٍ إعادة التشغيل…', 'Restarting…') : L('جارٍ الإيقاف…', 'Shutting down…')}</p>`;
  await wait(1500); $('#os').classList.add('hidden');
  if (restart) { off.classList.add('hidden'); return bootSeq(); }
  $('#off-msg').innerHTML = `<p style="font-size:14px">${L('اضغط زر التشغيل', 'Press the power button')}</p>`; $('#off-btn').innerHTML = ic(P.power); $('#off-btn').classList.remove('hidden');
}
$('#off-btn').onclick = () => { $('#off').classList.add('hidden'); bootSeq(); };
function applyLang() {
  document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'ar' ? 'rtl' : 'ltr';
  $('#msearch').placeholder = L('بحث في التطبيقات', 'Search apps'); $('#mlock').textContent = L('قفل', 'Lock'); $('#moff').textContent = L('الطاقة', 'Power'); $('#lk-h').textContent = L('اضغط لفتح القفل', 'Click to unlock');
  renderIcons(); menuRender(); Object.keys(wins).forEach(renderWin); tasks(); refresh();
}
const askText = (title, val, cb) => { const d = dlg(`<h3>${title}</h3><input class="in" id="tx" value="${esc(val)}"><div class="btns"><button class="flat" id="tc">${L('إلغاء', 'Cancel')}</button><button class="flat" id="to">${L('حفظ', 'Save')}</button></div>`); $('#tc', d).onclick = closeDlg; $('#to', d).onclick = () => { const v = $('#tx', d).value.trim(); if (v) { closeDlg(); cb(v); } }; };
function resetDlg() { const d = dlg(`<h3>${L('إعادة ضبط المصنع؟', 'Factory reset?')}</h3><p class="muted" style="margin-bottom:14px">${L('سيتم مسح كل الإعدادات والملاحظات والتطبيقات المحملة.', 'All settings, notes, and downloaded apps will be erased.')}</p><div class="btns"><button class="flat" id="rn">${L('إلغاء', 'Cancel')}</button><button class="flat" id="ry">${L('مسح كل شيء', 'Erase everything')}</button></div>`); $('#rn', d).onclick = closeDlg; $('#ry', d).onclick = () => { localStorage.removeItem('azdex.state'); localStorage.removeItem('azdex.downloaded'); location.reload(); }; }
let rerenderSettings = () => {};
const PAGES = {
 network: () => [['sw','wifi','Wi-Fi',''],...(S.wifi ? [['net','ALANZI HOME']] : []),['sw','bt','Bluetooth',''],['sep'],['sw','airplane', L('وضع الطائرة','Airplane mode'), ''],['sw','mobileData', L('بيانات الجوال','Mobile data'), ''],['sw','hotspot', L('نقطة اتصال','Hotspot'), '']],
 display: () => [['rg','bright', L('السطوع','Brightness'), 20, 100, 1],['sw','autoBright', L('سطوع تلقائي','Auto brightness'), ''],['seg','fs', L('حجم الخط','Font size'), [[.9,L('صغير','Small')],[1,L('افتراضي','Default')],[1.15,L('كبير','Large')],[1.3,L('الأكبر','Largest')]]],['sep'],['sw','dark', L('الوضع الداكن','Dark mode'), ''],['sw','night', L('إضاءة ليلية','Night light'), ''],['seg','accent', L('لون التمييز','Accent'), ACC.map((a,i)=>[i, L(a[2][0],a[2][1])])],['wall']],
 sound: () => [['rg','mediaVol', L('الوسائط','Media'), 0, 100, 1],['rg','ringVol', L('الرنين','Ring'), 0, 100, 1],['rg','notifVol', L('الإشعارات','Notifications'), 0, 100, 1],['rg','alarmVol', L('المنبه','Alarm'), 0, 100, 1],['sep'],['sw','vibrate', L('الاهتزاز','Vibrate'), ''],['sw','dnd', L('عدم الإزعاج','Do not disturb'), '']],
 notifications: () => [['sw','notifLight', L('إضاءة الإشعارات','Notification LED'), ''],['sw','notifPreview', L('إظهار المحتوى','Show content'), ''],['sw','dndSchedule', L('جدولة عدم الإزعاج','Schedule DND'), ''],['act', L('مسح كل الإشعارات','Clear all notifications'), ()=>{ S.notifs=[]; save(); refresh(); toast(L('تم','Done')); }]],
 dex: () => [['seg','mode', L('وضع التحكم','Control mode'), [['touch',L('لمس','Touch')],['mouse',L('فأرة','Mouse')]]],['rg','sens', L('سرعة المؤشر','Pointer speed'), .8, 4, .1],['seg','csize', L('حجم المؤشر','Pointer size'), [[0.75,L('صغير','Small')],[1,L('عادي','Default')],[1.3,L('كبير','Large')],[1.6,L('الأكبر','Largest')]]],['sw','natural', L('التمرير الطبيعي','Natural scrolling'), ''],['sw','labels', L('أسماء في شريط المهام','Taskbar labels'), ''],['sw','icons', L('أيقونات سطح المكتب','Desktop icons'), '']],
 apps: () => { const dl = JSON.parse(localStorage.getItem('azdex.downloaded')||'[]'); return [...dl.map(id => { const a = REAL_APPS[id]; return a ? ['act-uninstall', L(a.ar,a.en), id] : null; }).filter(Boolean), ...APPS.map(a => ['info', L(a.ar,a.en), L('نظام','System')])]; },
 storage: () => [['info', L('المستخدم','Used'), '32.4 GB'],['info', L('متاح','Available'), '95.6 GB'],['info', L('الإجمالي','Total'), '128 GB']],
 battery: () => [['info', L('المستوى','Level'), batt],['sw','batterySaver', L('موفّر البطارية','Battery saver'), ''],['sw','adaptiveBattery', L('بطارية تكيّفية','Adaptive'), '']],
 security: () => [['info', L('قفل الشاشة','Lock'), S.pinh ? 'PIN' : L('لا يوجد','None')],['btn', S.pinh ? L('إزالة PIN','Remove PIN') : L('تعيين PIN','Set PIN'), setLock]],
 system: () => [['seg','lang', L('اللغة','Language'), [['ar','العربية'],['en','English']]],['sw','h24', L('نظام 24 ساعة','24-hour'), ''],['sw','pct', L('نسبة البطارية','Battery %'), ''],['btn', L('إعادة ضبط','Reset'), resetDlg]],
 about: () => [['btn', L('اسم الجهاز: ','Device: ') + S.devName, ()=>askText(L('اسم الجهاز','Device'), S.devName, v=>{ S.devName=v; save(); rerenderSettings(); })],['info', L('النظام','System'), 'ALANZI Dex 6.3'],['info', L('الطراز','Model'), 'ALANZI Dex Station'],['info', L('الأساس','Base'), 'AOSP 9'],['info', L('النواة','Kernel'), '4.14.186-alanzi']]
};
const APP_FN = {
 settings(c, o) {
   const NAV = [['network',L('الشبكة','Network')],['display',L('الشاشة','Display')],['sound',L('الصوت','Sound')],['notifications',L('الإشعارات','Notifications')],['dex','Dex'],['apps',L('التطبيقات','Apps')],['storage',L('التخزين','Storage')],['battery',L('البطارية','Battery')],['security',L('الأمان','Security')],['system',L('النظام','System')],['about',L('لمحة','About')]];
   const draw = () => {
     const page = o.page || 'network', rows = PAGES[page](), y = $('.main', c) ? $('.main', c).scrollTop : 0;
     const html = rows.map((r, i) => {
       if (r[0] === 'sw') return `<div class="row" data-i="${i}"><div><b>${r[2]}</b>${r[3] ? `<small>${r[3]}</small>` : ''}</div><i class="sw ${S[r[1]] ? 'on' : ''}"></i></div>`;
       if (r[0] === 'seg') return `<div class="row col"><b>${r[2]}</b><div class="seg" style="margin-top:10px">${r[3].map((x, j) => `<button data-s="${i}:${j}" class="${S[r[1]] === x[0] ? 'on' : ''}">${x[1]}</button>`).join('')}</div></div>`;
       if (r[0] === 'rg') return `<div class="row col"><b>${r[2]} <small style="display:inline">${S[r[1]]}</small></b><input type="range" min="${r[3]}" max="${r[4]}" step="${r[5]}" value="${S[r[1]]}" data-r="${i}" style="margin-top:12px"></div>`;
       if (r[0] === 'info') return `<div class="row"><b>${r[1]}</b><small style="margin:0">${esc(r[2])}</small></div>`;
       if (r[0] === 'btn') return `<div class="row" data-i="${i}"><b style="color:var(--pd)">${r[1]}</b></div>`;
       if (r[0] === 'act') return `<div class="row" data-i="${i}"><b>${r[1]}</b><span style="color:var(--mut)">›</span></div>`;
       if (r[0] === 'act-uninstall') return `<div class="row" data-un="${r[2]}"><b>${r[1]}</b><small style="margin:0;color:#e53935">${L('إلغاء التثبيت','Uninstall')}</small></div>`;
       if (r[0] === 'net') return `<div class="row"><b>${ic(P.wifi)} ${r[1]}</b><small style="margin:0;color:var(--pd)">${L('متصل','Connected')}</small></div>`;
       if (r[0] === 'wall') return `<div class="row col"><b>${L('الخلفية','Wallpaper')}</b><div class="walls">${WALLS.map((w, j) => `<div data-w="${j}" class="${S.wall === j ? 'on' : ''}" style="background-color:${w[0]};background-image:${wallImg(w)}"></div>`).join('')}</div></div>`;
       return '';
     }).join('');
     c.innerHTML = `<div class="side"><nav>${NAV.map(n => `<button data-p="${n[0]}" class="${page === n[0] ? 'on' : ''}">${n[1]}</button>`).join('')}</nav><div class="main">${html}</div></div>`;
     $('.main', c).scrollTop = y;
     $$('[data-p]', c).forEach(b => b.onclick = () => { o.page = b.dataset.p; draw(); });
     $$('[data-i]', c).forEach(e => e.onclick = () => { const r = rows[+e.dataset.i]; if (!r) return; if (r[0] === 'sw') { setKey(r[1], !S[r[1]]); draw(); } else if (r[0] === 'btn' || r[0] === 'act') r[2](); });
     $$('[data-un]', c).forEach(e => e.onclick = () => { const id = e.dataset.un; let dl = JSON.parse(localStorage.getItem('azdex.downloaded')||'[]'); dl = dl.filter(x => x !== id); localStorage.setItem('azdex.downloaded', JSON.stringify(dl)); renderIcons(); draw(); toast(L('تم الإلغاء','Removed')); });
     $$('[data-s]', c).forEach(b => b.onclick = () => { const [i, j] = b.dataset.s.split(':').map(Number), r = rows[i]; if (!r || r[0] !== 'seg') return; setKey(r[1], r[3][j][0]); draw(); });
     $$('[data-r]', c).forEach(e => e.oninput = () => { const r = rows[+e.dataset.r]; if (!r || r[0] !== 'rg') return; S[r[1]] = +e.value; save(); refresh(true); const s = e.parentElement.querySelector('small'); if (s) s.textContent = e.value; });
     $$('[data-w]', c).forEach(e => e.onclick = () => { S.wall = +e.dataset.w; save(); refresh(true); draw(); });
   };
   rerenderSettings = () => { if (wins.settings) draw(); }; draw();
 },
 files(c, o) {
   const path = o.path = o.path || [];
   const items = () => { const p = path[0];
     if (!p) return ['Documents','Pictures','Downloads','Music'].map(n => ({n, dir: 1}));
     if (p === 'Documents') return [...S.notes.map((n, i) => ({n: (n.t || L('بدون عنوان', 'Untitled')) + '.txt', note: i})), {n: 'readme.txt', info: 1}];
     if (p === 'Pictures') return WALLS.map((w, i) => ({n: `wallpaper_${i + 1}.png`, wall: i}));
     return []; };
   const draw = () => {
     const it = items();
     c.innerHTML = `<div class="pb"><button id="fu">${ic(P.up)}</button><span>/ ${path.join(' / ')}</span></div><div class="fl">${it.length ? it.map((x, i) => `<div class="fi" data-i="${i}"><svg viewBox="0 0 24 24" style="fill:${x.dir ? '#fbc02d' : x.wall != null ? '#4285f4' : 'var(--mut)'}"><path d="${x.dir ? P.folder : x.wall != null ? P.display : P.notes}"/></svg><span>${esc(x.n)}</span>${x.dir ? '' : '<small>' + (x.wall != null ? 'PNG' : 'TXT') + '</small>'}</div>`).join('') : `<p class="muted c">${L('المجلد فارغ', 'This folder is empty')}</p>`}</div>`;
     $('#fu', c).onclick = o.back = () => { if (path.length) { path.pop(); draw(); } };
     $$('.fi', c).forEach(e => e.onclick = () => { const x = it[+e.dataset.i]; if (x.dir) { path.push(x.n); draw(); } else if (x.note != null) openApp('notes', x.note); else if (x.wall != null) { S.wall = x.wall; save(); refresh(true); toast(L('تم تعيين الخلفية', 'Wallpaper set')); } else toast(L('ALANZI Dex — ملف تجريبي', 'ALANZI Dex — demo file')); });
   };
   o.back = () => { if (path.length) { path.pop(); draw(); } }; draw();
 },
 notes(c, o) {
   let sel = typeof o.arg === 'number' ? o.arg : 0; if (sel >= S.notes.length) sel = 0;
   const draw = () => {
     const n = S.notes[sel];
     c.innerHTML = `<div class="nt"><aside><div class="l">${S.notes.map((x, i) => `<div class="n ${i === sel ? 'on' : ''}" data-n="${i}"><b>${esc(x.t) || L('بدون عنوان', 'Untitled')}</b><small>${esc((x.b || '').slice(0, 40))}</small></div>`).join('')}</div><button id="nn">+ ${L('ملاحظة جديدة', 'New note')}</button></aside>
      <main>${n ? `<input id="nt" placeholder="${L('العنوان', 'Title')}" value="${esc(n.t)}"><textarea id="nb" placeholder="${L('اكتب هنا…', 'Write here…')}">${esc(n.b)}</textarea><button class="flat" id="nd" style="align-self:flex-end;color:#e53935">${L('حذف', 'Delete')}</button>` : `<p class="muted c">${L('لا توجد ملاحظات', 'No notes')}</p>`}</main></div>`;
     $$('[data-n]', c).forEach(e => e.onclick = () => { sel = +e.dataset.n; draw(); });
     $('#nn', c).onclick = () => { S.notes.unshift({t: '', b: ''}); sel = 0; save(); draw(); };
     if (n) { $('#nt', c).oninput = e => { n.t = e.target.value; save(); const b = $$('[data-n] b', c)[sel]; if (b) b.textContent = n.t || L('بدون عنوان', 'Untitled'); }; $('#nb', c).oninput = e => { n.b = e.target.value; save(); }; $('#nd', c).onclick = () => { S.notes.splice(sel, 1); sel = 0; save(); draw(); }; }
   };
   draw();
 },
 calc(c) {
   let e = '';
   c.innerHTML = `<div class="calc"><div class="d">0</div>${['AC','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','00','0','.','='].map(k => `<button class="${'÷×−+='.includes(k) ? 'o' : ''}" data-k="${k}">${k}</button>`).join('')}</div>`;
   $$('button', c).forEach(b => b.onclick = () => { const k = b.dataset.k;
     if (k === 'AC') e = ''; else if (k === '⌫') e = e.slice(0, -1);
     else if (k === '=') { try { const x = e.replace(/÷/g, '/').replace(/×/g, '*').replace(/−/g, '-').replace(/%/g, '/100'); e = /^[0-9+\-*/.() ]+$/.test(x) && x ? String(+Function('return ' + x)().toFixed(8)) : ''; } catch (_) { e = ''; toast(L('خطأ', 'Error')); } }
     else e += k; $('.d', c).textContent = e || '0'; });
 },
 clock(c, o) {
   const ticks = Array.from({length: 12}, (_, i) => `<line class="tk2" x1="100" y1="12" x2="100" y2="${i % 3 ? 20 : 26}" transform="rotate(${i * 30} 100 100)"/>`).join('');
   c.innerHTML = `<svg viewBox="0 0 200 200" class="analog"><circle class="face" cx="100" cy="100" r="92"/>${ticks}<line class="hh" id="hh" x1="100" y1="100" x2="100" y2="55"/><line class="mh" id="mh" x1="100" y1="100" x2="100" y2="35"/><line class="sh2" id="sh" x1="100" y1="112" x2="100" y2="28"/><circle cx="100" cy="100" r="5" fill="var(--p)"/></svg><div class="big" id="ct"></div><p class="muted" id="cd" style="text-align:center"></p>`;
   const up = () => { const d = new Date(), s = d.getSeconds(), m = d.getMinutes() + s / 60, h = (d.getHours() % 12) + m / 60;
     $('#hh', c).setAttribute('transform', `rotate(${h * 30} 100 100)`); $('#mh', c).setAttribute('transform', `rotate(${m * 6} 100 100)`); $('#sh', c).setAttribute('transform', `rotate(${s * 6} 100 100)`);
     $('#ct', c).textContent = fmtT(d) + ':' + pad(s); $('#cd', c).textContent = d.toLocaleDateString(LOC(), {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'}); };
   up(); const t = setInterval(up, 1000); o.clean.push(() => clearInterval(t));
 },
 browser(c) {
   const HOME = 'https://www.google.com';
   c.innerHTML = `<div style="display:flex;flex-direction:column;height:100%"><div class="pb" style="direction:ltr"><div class="field" style="flex:1;height:34px"><input value="${HOME}" readonly style="direction:ltr;font-size:14px"></div></div><div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;text-align:center"><div style="font-size:64px;font-weight:500;letter-spacing:-2px">Google</div><p class="muted">${L('سيتم فتح Google الرسمي في تبويب جديد.', 'The official Google will open in a new tab.')}</p><button class="btn" id="go" style="max-width:260px">${L('افتح Google', 'Open Google')}</button></div></div>`;
   $('#go', c).onclick = () => { try { window.open(HOME, '_blank', 'noopener'); } catch (e) { toast(L('تعذّر الفتح', 'Could not open')); } };
 },
 term(c, o) {
   c.classList.add('tm'); c.innerHTML = `<div class="to"></div><div class="ti"><span>alanzi@dex:~$</span><input autocomplete="off" autocapitalize="off" spellcheck="false"></div>`;
   const out = $('.to', c), inp = $('input', c), t0 = Date.now();
   const say = s => { out.textContent += s + '\n'; c.scrollTop = c.scrollHeight; };
   say('ALANZI Dex terminal — help'); const CMD = {
     help: () => 'help clear date whoami uname pwd ls echo uptime neofetch',
     date: () => new Date().toString(), whoami: () => 'alanzi', pwd: () => '/home/alanzi', ls: () => 'Documents  Pictures  Downloads  Music',
     uname: () => 'ALANZI-Dex 4.14.186-alanzi aarch64 (Android 9 / AOSP)', uptime: () => 'up ' + Math.round((Date.now() - t0) / 1000) + 's',
     neofetch: () => `alanzi@dex\nOS: ALANZI Dex 6.3\nShell: ash\nResolution: 1280x720\nBattery: ${batt}\nControl: ${S.mode}`};
   inp.onkeydown = e => { if (e.key !== 'Enter') return; const v = inp.value.trim(); inp.value = ''; say('alanzi@dex:~$ ' + v); if (!v) return; const [cmd, ...a] = v.split(/\s+/);
     if (cmd === 'clear') out.textContent = ''; else if (cmd === 'echo') say(a.join(' ')); else if (CMD[cmd]) say(CMD[cmd]()); else say(cmd + ': command not found'); };
   o.clean.push(() => {});
 },
 camera(c, o) {
   c.innerHTML = `
     <div style="height:100%;background:#000;display:flex;flex-direction:column;position:relative;color:#fff">
       <div style="flex:1;position:relative;overflow:hidden;background:#000;display:grid;place-items:center">
         <video id="cam-vid" autoplay playsinline muted style="width:100%;height:100%;object-fit:cover;display:none"></video>
         <div id="cam-overlay" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(15,20,25,.9);padding:24px;text-align:center">
           <div style="width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,.1);display:grid;place-items:center;margin-bottom:16px">
             <svg viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="${P.camera}"/></svg>
           </div>
           <p style="font-size:15px;margin-bottom:6px;font-weight:500">${L('الكاميرا تحتاج إذن','Camera requires permission')}</p>
           <p style="font-size:12.5px;color:#999;margin-bottom:16px;max-width:280px;line-height:1.5">${L('اضغط للسماح بالوصول للكاميرا.','Click to allow camera access.')}</p>
           <button id="cam-start" style="padding:10px 28px;border-radius:20px;background:var(--p);color:var(--ink);font-weight:600;font-size:14px;border:0;cursor:pointer">${L('السماح','Allow')}</button>
           <p id="cam-err" style="font-size:11px;color:#f87171;margin-top:12px;max-width:280px"></p>
         </div>
         <div style="position:absolute;top:12px;inset-inline-start:12px;background:rgba(0,0,0,.55);padding:6px 12px;border-radius:14px;font-size:12px;display:flex;align-items:center;gap:6px">
           <span style="width:8px;height:8px;border-radius:50%;background:#e53935;animation:fin 1s infinite alternate"></span>
           ${L('كاميرا','Camera')}
         </div>
       </div>
       <div style="height:110px;background:#0a0a0a;display:flex;align-items:center;justify-content:space-around;padding:0 20px">
         <div style="width:48px;height:48px;border-radius:10px;background:#222;display:grid;place-items:center;color:#666">
           <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="${P.gallery}"/></svg>
         </div>
         <button id="cam-shoot" style="width:72px;height:72px;border-radius:50%;background:#fff;border:4px solid #444;cursor:pointer;position:relative" aria-label="shoot">
           <span style="position:absolute;inset:6px;border-radius:50%;background:#fff"></span>
         </button>
         <div style="width:48px;height:48px;border-radius:50%;background:#222;display:grid;place-items:center;color:#666">
           <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="${P.restart}"/></svg>
         </div>
       </div>
     </div>`;
   const vid = $('#cam-vid', c), overlay = $('#cam-overlay', c), err = $('#cam-err', c);
   let stream = null;
   const start = async () => {
     try {
       stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: {ideal: 1280} }, audio: false });
       vid.srcObject = stream;
       vid.style.display = 'block';
       await vid.play();
       overlay.style.display = 'none';
     } catch (e) {
       err.textContent = e.message || e.name || L('تعذر الوصول للكاميرا','Cannot access camera');
     }
   };
   $('#cam-start', c).onclick = start;
   start();
   $('#cam-shoot', c).onclick = () => {
     if (!stream){ toast(L('الكاميرا غير جاهزة','Camera not ready')); return; }
     const flash = document.createElement('div');
     flash.style.cssText = 'position:absolute;inset:0;background:#fff;animation:fin .3s;pointer-events:none;z-index:3';
     c.appendChild(flash); setTimeout(() => flash.remove(), 320);
     toast(L('📸 تم التقاط الصورة','📸 Photo captured'));
   };
   o.clean.push(() => { if (stream) stream.getTracks().forEach(t => t.stop()); });
 },
 music(c, o) {
   c.innerHTML = `
     <div style="padding:24px;display:flex;flex-direction:column;align-items:center;gap:16px;text-align:center;height:100%">
       <div style="width:180px;height:180px;border-radius:20px;background:var(--bg);display:grid;place-items:center;border:1px solid var(--line)">
         <svg viewBox="0 0 24 24" width="64" height="64" fill="var(--mut)"><path d="${P.music}"/></svg>
       </div>
       <div><b style="font-size:16px" id="mus-title">${L('لم يتم اختيار ملف','No file selected')}</b></div>
       <input type="file" id="mus-file" accept="audio/*" style="display:none">
       <button id="mus-pick" style="padding:10px 20px;border-radius:20px;background:var(--p);color:var(--ink);font-weight:600;font-size:14px;border:0;cursor:pointer">${L('اختيار ملف صوتي','Choose Audio File')}</button>
       <audio id="mus-player" style="width:100%;max-width:300px;margin-top:10px;display:none" controls></audio>
     </div>`;
   const fileInput = $('#mus-file', c), pickBtn = $('#mus-pick', c), player = $('#mus-player', c), title = $('#mus-title', c);
   pickBtn.onclick = () => fileInput.click();
   fileInput.onchange = (e) => {
     const file = e.target.files[0];
     if (file) {
       const url = URL.createObjectURL(file);
       player.src = url;
       player.style.display = 'block';
       title.textContent = file.name;
       player.play();
       o.clean.push(() => URL.revokeObjectURL(url));
     }
   };
 },
 gallery(c) {
   c.innerHTML = `<div class="gal">${WALLS.map((w,i)=>`<div data-w="${i}" style="background-color:${w[0]};background-image:${wallImg(w)}"></div>`).join('')}${Array.from({length:6},(_,i)=>`<div style="background:linear-gradient(135deg,hsl(${i*60},60%,40%),hsl(${i*60+40},60%,20%))"></div>`).join('')}</div>`;
   $$('.gal [data-w]', c).forEach(e => e.onclick = () => { S.wall = +e.dataset.w; save(); refresh(true); toast(L('تم','Set')); });
 },
 weather(c) {
   c.innerHTML = `<div style="padding:24px;text-align:center"><div style="font-size:56px;display:flex;justify-content:center;margin-bottom:10px;"><svg viewBox="0 0 24 24" width="64" height="64" fill="#FFC107"><path d="${P.sun}"/></svg></div><div style="font-size:44px;font-weight:200;margin:6px 0;letter-spacing:-.02em">28°</div><div style="color:var(--mut);font-size:14px">${L('الرياض','Riyadh')}</div></div>`;
 },
 calendar(c) {
   const now = new Date(), m = now.getMonth(), y = now.getFullYear();
   const first = new Date(y, m, 1).getDay(), days = new Date(y, m+1, 0).getDate();
   c.innerHTML = `<div style="padding:16px"><h3 style="font-size:18px;margin-bottom:12px;font-weight:500">${now.toLocaleDateString(LOC(),{month:'long',year:'numeric'})}</h3><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;text-align:center;font-size:12px"><b style="color:var(--mut);font-weight:400">ح</b><b style="color:var(--mut);font-weight:400">ن</b><b style="color:var(--mut);font-weight:400">ث</b><b style="color:var(--mut);font-weight:400">ر</b><b style="color:var(--mut);font-weight:400">خ</b><b style="color:var(--mut);font-weight:400">ج</b><b style="color:var(--mut);font-weight:400">س</b>${Array(first).fill('<span></span>').join('')}${Array(days).fill(0).map((_,i)=>`<div style="padding:7px;border-radius:8px;${i+1===now.getDate()?'background:var(--p);color:var(--ink);font-weight:600':''}">${i+1}</div>`).join('')}</div></div>`;
 },
 store(c, o) {
   let cat = o.cat || 'all';
   let q = '';
   const draw = () => {
     const dl = JSON.parse(localStorage.getItem('azdex.downloaded') || '[]');
     const list = Object.entries(REAL_APPS).map(([id,a])=>({id, ...a})).filter(a => (cat==='all'||a.cat===cat) && ((a.ar+' '+a.en).toLowerCase().includes(q.toLowerCase())));
     c.innerHTML = `<div class="st-head">${bx({c:'#00bfa5',p:P.store},1)}<input id="st-q" placeholder="${L('ابحث في المتجر','Search store')}" value="${esc(q)}"></div>
       <div class="st-cats">${[['all',L('الكل','All')],['social',L('تواصل','Social')],['entertainment',L('ترفيه','Entertainment')],['tools',L('أدوات','Tools')]].map(([k,l])=>`<button data-c="${k}" class="${cat===k?'on':''}">${l}</button>`).join('')}</div>
       <div class="st-grid">${list.map(a=>{
         const isDl = dl.includes(a.id);
         return `<div class="st-app">${bx(a,1)}<div class="info"><b>${L(a.ar,a.en)}</b><small>${L('تطبيق خارجي','External App')}</small></div><button class="inst ${isDl?'done':''}" data-i="${a.id}">${isDl?L('فتح','Open'):L('تثبيت','Install')}</button></div>`;
       }).join('')}</div>`;
     $('#st-q', c).oninput = e => { q = e.target.value; const pos = e.target.selectionStart; draw(); const nn = $('#st-q', c); nn.focus(); nn.setSelectionRange(pos,pos); };
     $$('.st-cats button', c).forEach(b=>b.onclick=()=>{ cat=b.dataset.c; draw(); });
     $$('.inst', c).forEach(b=>b.onclick=()=>{
       const id = b.dataset.i;
       const dl = JSON.parse(localStorage.getItem('azdex.downloaded') || '[]');
       if (dl.includes(id)) { openApp(id); return; }
       b.textContent = L('جارٍ…','Installing…'); b.disabled = true;
       setTimeout(()=>{
         dl.push(id); localStorage.setItem('azdex.downloaded', JSON.stringify(dl));
         renderIcons();
         S.notifs.unshift({id:Date.now(), app:id, title:L('تم التثبيت','Installed'), body:L('تم تثبيت التطبيق بنجاح','App installed successfully'), time:L('الآن','Now'), read:false});
         save(); refresh(true); draw(); toast(L('تم التثبيت ✓','Installed ✓'));
       }, 800);
     });
   };
   draw();
 }
};
let busy = false;
function setupStep(i) {
  if (busy) return; busy = true; const box = $('#step'); box.style.opacity = 0;
  setTimeout(() => {
    const next = () => setupStep(i + 1);
    if (i === 0) {
      box.innerHTML = `<h2 class="stitle">${L('مرحبًا بك في', 'Welcome to')}<br><b>ALANZI Dex</b></h2><p class="sdesc">${L('سطح مكتب كامل لهاتفك.', 'A full desktop for your phone.')}</p><div class="seg">${[['ar','العربية'],['en','English']].map(l => `<button data-l="${l[0]}" class="${S.lang === l[0] ? 'on' : ''}">${l[1]}</button>`).join('')}</div><button class="snext" id="sn">${L('البداية', 'Start')}</button>`;
      $$('[data-l]', box).forEach(b => b.onclick = () => { S.lang = b.dataset.l; save(); applyLang(); busy = false; setupStep(0); });
      $('#sn', box).onclick = next;
    } else if (i === 1) {
      box.innerHTML = `<h2 class="stitle">Wi-Fi</h2><p class="sdesc">${L('اختر شبكة للاتصال.', 'Pick a network to connect.')}</p><div class="srow"><div class="t">ALANZI HOME<small>${L('متصل', 'Connected')}</small></div><svg class="chk" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="currentColor"/><path d="M7.5 12.5l3 3 6-6.5" fill="none" stroke="#00222c" stroke-width="2.2" stroke-linecap="round"/></svg></div><button class="snext" id="sn">${L('التالي', 'Next')}</button>`;
      $('#sn', box).onclick = next;
    } else if (i === 2) {
      const opt = (m, t, d) => `<div class="srow" data-m="${m}"><i class="rad ${S.mode === m ? 'on' : ''}"></i><div class="t">${t}<small>${d}</small></div></div>`;
      box.innerHTML = `<h2 class="stitle">${L('وضع التحكم', 'Control mode')}</h2><p class="sdesc">${L('تقدر تغيّره بعدين من شريط المهام.', 'You can change it later from the taskbar.')}</p>${opt('touch', L('لمس', 'Touch'), L('المس العناصر مباشرة.', 'Tap items directly.'))}${opt('mouse', L('فأرة', 'Mouse'), L('الشاشة تصير لوحة لمس: اسحب لتحريك المؤشر، اضغط للنقر.', 'The screen becomes a touchpad: drag to move, tap to click.'))}<button class="snext" id="sn">${L('التالي', 'Next')}</button>`;
      $$('[data-m]', box).forEach(e => e.onclick = () => { S.mode = e.dataset.m; save(); $$('[data-m] .rad', box).forEach(r => r.classList.toggle('on', r.parentElement === e)); });
      $('#sn', box).onclick = next;
    } else if (i === 3) {
      box.innerHTML = `<h2 class="stitle">${L('احمِ جهازك', 'Protect your device')}</h2><p class="sdesc">${L('عيّن رمز PIN لقفل الشاشة.', 'Set a PIN for the lock screen.')}</p><div class="srow" id="sp"><div class="t">PIN</div>${ic(P.lock)}</div><button class="snext" id="sn" style="background:transparent;color:var(--sa)">${L('ليس الآن', 'Not now')}</button>`;
      $('#sp', box).onclick = () => { $('#os').classList.remove('hidden'); setLock(); }; $('#sn', box).onclick = next;
    } else {
      box.innerHTML = `<h2 class="stitle">${L('كل شيء جاهز', 'All set')}</h2><p class="sdesc">${L('تم إعداد ALANZI Dex.', 'ALANZI Dex is ready.')}</p><button class="snext" id="sn">${L('ابدأ', 'Start')}</button>`;
      $('#sn', box).onclick = () => { S.done = true; save(); $('#setup').classList.add('hidden'); $('#os').classList.remove('hidden'); setMode(S.mode, true); refresh(); toast(L('أهلاً بك في ALANZI Dex', 'Welcome to ALANZI Dex')); };
    }
    box.style.opacity = 1; setTimeout(() => { busy = false; }, 230);
  }, 220);
}
async function bootAnim() {
  const saturn = $('#saturn'), wm = $('#wm'), planet = $('.planet', saturn);
  const dot = $('.wm-dot', wm);
  wm.classList.remove('show'); dot.classList.remove('on');
  await wait(1300);
  $$('.ring-a,.ring-b,.ring-front', saturn).forEach(el => el.classList.add('out'));
  wm.classList.add('show');
  await wait(800);
  const pR = planet.getBoundingClientRect();
  const wrapR = dot.parentElement.getBoundingClientRect();
  const dotTop = parseFloat(getComputedStyle(dot).top) || 0;
  const dotW = dot.offsetWidth || 10;
  const dotH = dot.offsetHeight || 10;
  const dcx = wrapR.left + wrapR.width/2;
  const dcy = wrapR.top + dotTop + dotH/2;
  planet.style.opacity = '0';
  const fly = document.createElement('div');
  fly.style.cssText = `position:fixed;z-index:99999;pointer-events:none;border-radius:50%;background:#fff;box-shadow:0 0 24px rgba(255,255,255,.8),0 0 60px rgba(255,255,255,.4);left:${pR.left}px;top:${pR.top}px;width:${pR.width}px;height:${pR.height}px;transition:left .7s cubic-bezier(.65,0,.35,1),top .7s cubic-bezier(.65,0,.35,1),width .7s cubic-bezier(.65,0,.35,1),height .7s cubic-bezier(.65,0,.35,1),opacity .3s`;
  document.body.appendChild(fly);
  await new Promise(r => requestAnimationFrame(r));
  fly.style.left = (dcx - dotW/2) + 'px';
  fly.style.top = (dcy - dotH/2) + 'px';
  fly.style.width = dotW + 'px';
  fly.style.height = dotH + 'px';
  await wait(720);
  dot.classList.add('on');
  fly.style.opacity = '0';
  await wait(280);
  fly.remove();
}
async function bootSeq() {
  const b = $('#boot'); b.classList.remove('hidden'); b.style.opacity = '';
  $('#os').classList.add('hidden'); $('#setup').classList.add('hidden');
  applyLang(); await bootAnim(); await wait(300);
  b.style.opacity = 0; await wait(450); b.classList.add('hidden'); b.style.opacity = '';
  if (S.done) { $('#os').classList.remove('hidden'); setMode(S.mode, true); refresh(); } else { $('#setup').classList.remove('hidden'); setupStep(0); }
}
applyLang(); bootSeq();
})();