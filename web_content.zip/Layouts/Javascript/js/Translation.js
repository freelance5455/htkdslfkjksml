// Translation.js - كود صفحة اللغات
const cards = Array.from(document.querySelectorAll('.lang-card'));
  const input = document.getElementById('searchInput');
  const empty = document.getElementById('emptyState');
  let lastScrollY = window.scrollY;
  let shown = new Set();
  let ticking = false;
  function stairIn(card, order){
    if(shown.has(card)) return;
    shown.add(card);
    const step = order % 3;
    card.classList.remove('stair-0','stair-1','stair-2');
    card.classList.add('stair-' + step);
    card.style.transitionDelay = (step * 150) + 'ms';
    requestAnimationFrame(()=>{
      setTimeout(()=>{ card.classList.add('show'); }, step * 150);
    });
  }
  function onScrollDown(){
    const y = window.scrollY;
    const goingDown = y > lastScrollY;
    lastScrollY = y;
    if(!goingDown) return;
    const vh = window.innerHeight;
    let order = 0;
    cards.forEach((c)=>{
      if(c.style.display === 'none') return;
      if(shown.has(c)) return;
      const r = c.getBoundingClientRect();
      if(r.top < vh && r.bottom > 0){
        stairIn(c, order);
        order++;
      }
    });
  }
  function resetStairs(list){
    shown.clear();
    list.forEach((c)=>{
      c.classList.remove('show','stair-0','stair-1','stair-2');
      c.style.transitionDelay = '0ms';
    });
    requestAnimationFrame(()=>{
      list.forEach((c,i)=>{
        const step = i % 3;
        c.classList.add('stair-' + step);
        c.style.transitionDelay = (step * 150) + 'ms';
        setTimeout(()=>{ c.classList.add('show'); shown.add(c); }, 50 + step * 150);
      });
    });
  }
  window.addEventListener('load', ()=>{ resetStairs(cards); });
  setTimeout(()=>{ resetStairs(cards); }, 80);
  window.addEventListener('scroll', ()=>{
    if(!ticking){
      ticking = true;
      requestAnimationFrame(()=>{ onScrollDown(); ticking = false; });
    }
  }, { passive: true });
  function selectLang(el){
    document.querySelectorAll('.lang-card').forEach(c => {
      c.classList.remove('active');
      c.querySelector('.lang-check').textContent = '';
    });
    el.classList.add('active');
    el.querySelector('.lang-check').textContent = 'X';
  }
  function showAll(){
    empty.classList.remove('show');
    cards.forEach(c=>{ c.style.display = 'flex'; });
    resetStairs(cards);
  }
  function filterLang(){
    const q = input.value.toLowerCase().trim();
    if(q === ''){ showAll(); return; }
    let visible = [];
    cards.forEach(c=>{
      const name = c.getAttribute('data-name').toLowerCase();
      const match = name.includes(q);
      c.style.display = match ? 'flex' : 'none';
      if(match) visible.push(c);
    });
    if(visible.length === 0){
      empty.classList.remove('show');
      void empty.offsetWidth;
      empty.classList.add('show');
    } else {
      empty.classList.remove('show');
      resetStairs(visible);
    }
  }
  input.addEventListener('input', ()=>{
    if(input.value.trim() === '') showAll();
  });
