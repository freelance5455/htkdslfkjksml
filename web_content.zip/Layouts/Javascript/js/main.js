// main.js - تسلسل شاشة البداية + مشاهد الانيميشن + زر Get started
// (حركات القلب في heart.js | فتح الصفحات في router.js)
(function () {
  var KEY = 'qulife_intro_done';            // علامة: حركة البداية اتعرضت مرة واحدة في الجلسة
  var $ = function (id) { return document.getElementById(id); };
  var seen = false;
  try { seen = sessionStorage.getItem(KEY) === '1'; } catch (e) {}

  if (seen) {
    // ===== الحركة اتشافت قبل كده: نعرض الصفحة الرئيسية فورا بدون اعادة البداية =====
    $('splash').classList.add('hide');
    $('main').classList.add('show');
    $('pre-heart').classList.add('done');
    QulifeHeart.showNow();
  } else {
    // ===== 1 - شاشة البداية ثم المشاهد العشرة ثم القلب =====
    setTimeout(function () {
      $('splash').classList.add('hide');
      setTimeout(function () {
        $('main').classList.add('show');
        try { sessionStorage.setItem(KEY, '1'); } catch (e) {}
        var scenes = [].slice.call(document.querySelectorAll('.scene'));
        var s = 0;
        function showScene(i) { scenes.forEach(function (el, k) { el.classList.toggle('active', k === i); }); }
        showScene(0);
        var timer = setInterval(function () {
          s++;
          if (s < scenes.length) { showScene(s); }
          else { clearInterval(timer); $('pre-heart').classList.add('done'); QulifeHeart.drop(); }
        }, 1000);
      }, 600);
    }, 3000);
  }

  // ===== 2 - زر Get started =====
  $('startBtn').onclick = function (e) { e.currentTarget.blur(); alert('Welcome to Qulife!'); };
})();
