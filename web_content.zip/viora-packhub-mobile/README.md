# Viora PackHub Mobile

Orijinal Windows Viora PackHub uygulamasının mobil versiyonu.

## Özellikler
- Resource Pack, Shader, Mod ve Modpack arama (Modrinth API)
- Kategori filtreleri
- Arama
- Seçilen paketin son sürümünü doğrudan indir
- Modrinth sayfasına yönlendirme
- Modern koyu tema (orijinal stile yakın)

## Nasıl Kullanılır
1. Bu klasördeki `index.html` dosyasını telefon tarayıcısında aç.
2. Veya PWA olarak "Ana Ekrana Ekle".

## APK Yapmak İçin (Kolay Yöntem)
Çünkü ortamda Android SDK yok, APK'yı şu ücretsiz online araçlarla yapabilirsin:

1. Bu klasörü ZIP olarak sıkıştır (index.html, icon.png, manifest.json içinde olsun).
2. Şu sitelerden birine yükle:
   - https://www.htmltoapk.com
   - https://www.apkmaker.dev
   - Google Play'de "HTML to APK" aratıp uygulamaları kullan
3. Uygulama adı: **Viora PackHub**
4. Paket adı örneği: `com.viora.packhub`
5. İkon olarak `icon.png` kullan.

### Alternatif: Android Studio ile
1. Yeni bir Empty Activity projesi oluştur.
2. `assets` klasörüne bu dosyaları koy.
3. MainActivity'de WebView ile `file:///android_asset/index.html` yükle.
4. AndroidManifest'e INTERNET izni ekle.
5. Build > Build APK.

## Notlar
- Bu sürüm **Modrinth** üzerinden Java Edition paketlerini gösterir.
- Mobil Minecraft (Bedrock) için bazı paketler uyumlu olmayabilir; genellikle Java içindir.
- İndirilen .zip dosyalarını Minecraft'ın resourcepacks klasörüne koy.
- Orijinal uygulama kapalı kaynak olduğu için bu bağımsız bir yeniden yapılandırmadır.

Geliştirici: Topluluk sürümü (orijinal Wraith / VioraLand'dan esinlenilmiştir)
