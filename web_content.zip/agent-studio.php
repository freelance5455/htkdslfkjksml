<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
workspace_legacy_redirect('agents/');
require_once __DIR__.'/app/agent.php';
$user=auth_require_user();
agent_schema();
$pageTitle='AI Agent Studio';
require __DIR__.'/app/platform_header.php';
?>
<link rel="stylesheet" href="assets/agent-studio.css?v=1.3.1">
<?php require __DIR__.'/app/agent_workspace.php'; ?>
<script src="assets/agent-studio.js?v=1.3.1" defer></script>
<?php require __DIR__.'/app/platform_footer.php'; ?>
