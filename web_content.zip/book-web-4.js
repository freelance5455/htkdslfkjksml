/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : WEB-3-1-1 */
registerLessonDetail(3, 3, "web-3-1-1", {
  title: "Leçon 1 : Architecture API REST, JWT et Applications Multiplateformes (PWA)",
  duration: "55 min (Manuel universitaire complet)",
  objectives: [
    "Comprendre la séparation Front-end / Back-end et le principe « Sans État » (Stateless) d'une API REST.",
    "Maîtriser les verbes HTTP, l'idempotence et les grandes familles de codes de statut (2xx, 4xx, 5xx).",
    "Expliquer l'authentification par jetons JWT et les règles de sécurité (HTTPS, CORS, clés API).",
    "Concevoir une Progressive Web App (PWA) avec manifest.json et Service Worker pour fonctionner hors ligne."
  ],
  prerequisites: ["Niveau 2 Web (JavaScript, fetch, JSON) et notions de réseaux."],
  sections: [
    {
      type: "theory",
      title: "1. Séparation Client / Serveur et Philosophie REST",
      text: "Autrefois, un serveur Web fabriquait une page HTML complète à chaque clic. Aujourd'hui, pour alimenter simultanément un Site Web, une Application Web PC et une Application Mobile Android/iOS sans réécrire la logique métier 3 fois, on sépare strictement deux mondes :\n• Le Front-end (Client) : gère uniquement l'affichage et l'expérience utilisateur.\n• Le Back-end (Serveur + Base de données) : protège les données, vérifie les droits et expose une API.\n\nDéfinie par Roy Fielding dans sa thèse de 2000, l'architecture REST (Representational State Transfer) repose sur le protocole HTTP standard et impose une contrainte clé : le caractère « Sans État » (Stateless). Le serveur ne garde pas en mémoire RAM qui est connecté entre deux clics : chaque requête envoyée par votre téléphone doit contenir toutes les informations nécessaires pour l'identifier."
    },
    {
      type: "table",
      title: "2. Verbes HTTP, Opérations CRUD et Idempotence",
      headers: ["Verbe HTTP", "Opération CRUD", "Idempotent ?", "Codes de réponse typiques"],
      rows: [
        ["GET", "Read (Lire une ressource)", "Oui (ne modifie rien)", "200 OK | 404 Not Found"],
        ["POST", "Create (Créer / Soumettre)", "Non (répéter crée 2 fois)", "201 Created | 400 Bad Request"],
        ["PUT / PATCH", "Update (Remplacer / Modifier)", "Oui (PUT) / Variable", "200 OK | 403 Forbidden"],
        ["DELETE", "Delete (Supprimer)", "Oui (état final identique)", "204 No Content | 401 Unauthorized"]
      ]
    },
    {
      type: "definition",
      term: "Authentification par Jeton JWT (JSON Web Token)",
      text: "Comme une API REST est sans état (Stateless), comment prouver à chaque requête que vous êtes bien l'étudiant connecté ou l'administrateur ?\nLors de la connexion (POST /login), le serveur vérifie votre mot de passe (haché) puis vous délivre un jeton signé cryptographiquement : le JWT, composé de 3 parties séparées par des points (Header.Payload.Signature).\n\nVotre téléphone conserve ce JWT et l'envoie dans l'en-tête HTTP « Authorization: Bearer <jeton> ». Grâce à la signature mathématique secrète du serveur, si un pirate modifie ne serait-ce qu'une lettre du jeton (ex: changer role:'student' en role:'admin'), la signature devient invalide et le serveur rejette immédiatement la requête !"
    },
    {
      type: "theory",
      title: "3. Multiplateforme : PWA, Hybride (Capacitor) et Service Workers",
      text: "Pour déployer JOSTECH sur Web, Android et iOS depuis une seule base de code HTML/CSS/JS, deux briques technologiques entrent en jeu :\n1) La PWA (Progressive Web App) s'appuie sur un fichier « manifest.json » (nom, icône, couleurs, mode plein écran) et un « Service Worker » (script tournant en arrière-plan entre l'application et Internet). Le Service Worker met en cache les cours pour permettre une lecture fluide même sans connexion.\n2) L'empaquetage Natif Hybride (comme Capacitor) place cette application Web optimisée dans un conteneur Android/iOS capable de générer un véritable fichier .apk pour le Google Play Store tout en accédant aux capteurs du téléphone."
    },
    {
      type: "code",
      lang: "PWA — Exemple de manifest.json et stratégie Cache-First",
      code: [
        "// 1. Extrait de manifest.json (Installation sur écran d'accueil Android)",
        "{",
        "  \"name\": \"JOSTECH Université Numérique\",",
        "  \"short_name\": \"JOSTECH\",",
        "  \"start_url\": \"/index.html\",",
        "  \"display\": \"standalone\",",
        "  \"background_color\": \"#07090d\",",
        "  \"theme_color\": \"#07090d\"",
        "}",
        "",
        "// 2. Logique d'un Service Worker (Cache-First pour les cours)",
        "self.addEventListener('fetch', event => {",
        "  event.respondWith(",
        "    caches.match(event.request).then(cached => cached || fetch(event.request))",
        "  );",
        "});"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Sécurité API et erreurs critiques d'architecture",
      text: "1) Distinguez 401 vs 403 : 401 Unauthorized signifie « Je ne sais pas qui vous êtes (connectez-vous) » ; 403 Forbidden signifie « Je sais qui vous êtes, mais vous n'avez pas la permission (ex: étudiant tentant de supprimer un cours) ».\n2) Ne mettez JAMAIS une clé secrète (clé d'IA payante, mot de passe base de données) dans le code JavaScript du téléphone ! Tout code Front-end peut être lu par l'utilisateur. Les clés secrètes doivent rester exclusivement côté serveur (ou Edge Functions).\n3) CORS (Cross-Origin Resource Sharing) : mécanisme de sécurité du navigateur empêchant un site pirate inconnu d'interroger votre API à la place de votre domaine officiel."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Conception d'endpoints RESTful",
      question: "Vous concevez l'API de JOSTECH pour gérer les « quiz ». Quelle méthode HTTP et quelle URL propre (sans verbe dans l'URL !) utilisez-vous pour :\n1) Récupérer la liste de tous les quiz.\n2) Créer un nouveau quiz.\n3) Supprimer le quiz numéro 42.",
      solution: "En REST, les URLs désignent des noms (ressources) et les verbes HTTP portent l'action :\n1) GET /api/quizzes\n2) POST /api/quizzes\n3) DELETE /api/quizzes/42"
    },
    {
      title: "Exercice 2 — Diagnostic de codes HTTP et sécurité",
      question: "Un étudiant connecté tente d'envoyer une requête POST /api/admin/cours pour publier une fausse leçon, mais le serveur bloque. Quel code HTTP exact le serveur doit-il renvoyer : 401, 403, 404 ou 500 ? Et pourquoi un attaquant ne peut-il pas falsifier son rôle dans un JWT ?",
      solution: "1) Le serveur doit renvoyer 403 Forbidden (il est bien authentifié, mais n'a pas le rôle administrateur requis).\n2) Parce que la 3e partie du JWT (la Signature) est calculée cryptographiquement avec une clé secrète connue uniquement du serveur : toute modification du Payload invalide la signature."
    },
    {
      title: "Exercice 3 — Stratégie Hors Connexion PWA",
      question: "Pour JOSTECH, quelle stratégie de Service Worker convient le mieux pour :\nA) Les images du logo et les cours déjà téléchargés (qui changent peu).\nB) Les résultats officiels d'un examen en ligne.\nChoisissez entre « Cache-First » et « Network-Only / Network-First ».",
      solution: "A) Cache-First : lecture instantanée même sans réseau 4G, avec économie maximale de données mobiles.\nB) Network-Only (connexion requise) : conforme au cahier des charges pour garantir l'intégrité et la validation sécurisée de la note sur le serveur."
    }
  ],
  summary: "L'architecture REST découple proprement l'interface de la base de données via HTTP/JSON sans état, sécurisée par HTTPS, CORS et jetons JWT. En y associant manifest.json et Service Workers, une application Web devient une PWA installable, rapide et résiliente hors ligne sur Android, iOS et PC.",
  references: [
    "Fielding, R. T. (2000) — Architectural Styles and the Design of Network-based Software Architectures (REST).",
    "RFC 7519 — JSON Web Token (JWT) Specification.",
    "Google Web.dev & MDN — Progressive Web Apps and Service Workers."
  ]
});