# Stage 1133 — Candle Time/Gap Safety

- Hardens sampled-price candle construction against future timestamps and invalid samples.
- Keeps deterministic chronological ordering before aggregation.
- Normalizes each sample into the exact timeframe bucket.
- Preserves the last observed timestamp for the live candle without allowing it to exceed the current time.
- Tracks sample count internally for candle integrity diagnostics without changing the chart API.
- Existing zoom/pan/live continuity behavior remains intact.
- Source ZIP only; APK build was not performed.
