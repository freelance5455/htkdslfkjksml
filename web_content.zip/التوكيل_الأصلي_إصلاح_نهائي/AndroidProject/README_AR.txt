التوكيل الأصلي — نسخة Android WebView مع حل خطأ واتساب
=======================================================

تم تضمين واجهة التوكيل الأصلي (HTML/CSS/JavaScript) داخل مشروع Android في:
AndroidProject/app/src/main/assets/

إصلاح المشكلة:
- روابط whatsapp:// يتم فتحها عبر Intent خارج WebView.
- روابط https://wa.me/ تفتح خارج التطبيق في التطبيق/المتصفح المناسب.
- روابط tel: وmailto: وsms: تفتح عبر Intent.
- روابط intent:// يتم تحليلها باستخدام Intent.parseUri.
- لا يحاول WebView تحميل مخططات غير معروفة.

طريقة البناء:
1. فك ضغط ZIP.
2. افتح مجلد AndroidProject في Android Studio.
3. انتظر Gradle Sync.
4. اختر Build > Build APK(s).

ملاحظة:
هذا مشروع Android Studio وليس APK جاهزًا. يلزم Android Studio وAndroid SDK 35 لبناء APK.


تحديث الإصلاح النهائي:
- تمت معالجة روابط HTTP/HTTPS وروابط whatsapp:// وtel: وintent:// في WebViewClient.
- تم تعديل أزرار الاستفسار لتفتح رابط wa.me في نفس النافذة بدل window.open، لتجنب ERR_UNKNOWN_URL_SCHEME ومشكلة النوافذ الجديدة.
- هذا ملف مشروع Android Studio المصدر، وليس APK جاهزًا. افتح مجلد AndroidProject في Android Studio ثم Build > Build APK(s).
