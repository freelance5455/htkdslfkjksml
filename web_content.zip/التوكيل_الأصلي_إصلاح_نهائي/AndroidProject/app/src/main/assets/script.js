document.addEventListener("DOMContentLoaded", () => {
  const whatsappNumber = "201274847048";
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  document.querySelectorAll(".inquire").forEach((button) => {
    button.addEventListener("click", () => {
      const product = button.dataset.product || "المنتجات";
      const message = `السلام عليكم، أريد الاستفسار عن: ${product} من التوكيل الأصلي لمستلزمات الورش والمصانع.`;
      const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
      // افتح الرابط في نفس النافذة حتى يلتقطه WebViewClient ويوجهه للتطبيق المناسب.
      window.location.href = url;
    });
  });

  // إزالة target=_blank حتى لا يعتمد فتح واتساب على نافذة WebView جديدة.
  document.querySelectorAll('a[href^="https://wa.me/"], a[href^="tel:"]').forEach((link) => {
    link.removeAttribute("target");
  });
});
