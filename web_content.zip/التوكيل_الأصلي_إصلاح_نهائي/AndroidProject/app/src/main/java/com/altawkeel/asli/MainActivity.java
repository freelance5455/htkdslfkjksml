package com.altawkeel.asli;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl().toString());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean routeUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return true;
        Uri uri = Uri.parse(rawUrl);
        String scheme = uri.getScheme();
        if (scheme == null) return true;

        if ("file".equalsIgnoreCase(scheme)
                || "about".equalsIgnoreCase(scheme)
                || "javascript".equalsIgnoreCase(scheme)) {
            return false;
        }

        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            String host = uri.getHost();
            if (host == null || host.equalsIgnoreCase("localhost")
                    || host.equalsIgnoreCase("127.0.0.1")) {
                return false;
            }
            openExternal(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        }

        if ("intent".equalsIgnoreCase(scheme)) {
            openIntentUrl(rawUrl);
            return true;
        }

        if ("whatsapp".equalsIgnoreCase(scheme)
                || "tel".equalsIgnoreCase(scheme)
                || "mailto".equalsIgnoreCase(scheme)
                || "sms".equalsIgnoreCase(scheme)
                || "geo".equalsIgnoreCase(scheme)
                || "market".equalsIgnoreCase(scheme)) {
            openExternal(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        }

        // امنع WebView من تحميل schemes غير مدعومة داخليًا.
        return true;
    }

    private void openIntentUrl(String rawUrl) {
        try {
            Intent intent = Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME);
            try {
                startActivity(intent);
                return;
            } catch (ActivityNotFoundException ignored) {
                String fallback = intent.getStringExtra("browser_fallback_url");
                if (fallback != null && !fallback.isEmpty()) {
                    openExternal(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                } else if (intent.getData() != null) {
                    openExternal(new Intent(Intent.ACTION_VIEW, intent.getData()));
                } else {
                    showOpenError();
                }
            }
        } catch (Exception e) {
            showOpenError();
        }
    }

    private void openExternal(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            showOpenError();
        }
    }

    private void showOpenError() {
        Toast.makeText(this,
                "تعذر فتح الرابط. تأكد من تثبيت واتساب أو وجود متصفح على الهاتف.",
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
