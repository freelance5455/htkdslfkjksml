# Rozprávajme – Android (APK)

## Čo potrebuješ
- Node.js 20 alebo novší (nodejs.org)
- Android Studio (developer.android.com/studio) – pri inštalácii nechaj zaškrtnutý Android SDK

## Postup
1. Rozbaľ priečinok a otvor v ňom terminál.
2. `npm install`
3. `npm run setup` (vytvorí Android projekt, pridá povolenie na vibráciu a zosynchronizuje)
4. `npx cap open android` – otvorí sa Android Studio.
5. Počkaj na „Gradle sync“ a potom **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Hotový súbor: `android/app/build/outputs/apk/debug/app-debug.apk`. Pošli si ho do mobilu a nainštaluj.

## Haptika (vibrácia)
- Balík `@capacitor/haptics` je v `package.json`, nainštaluje sa s `npm install` a pridá povolenie na vibráciu. Aplikácia ho použije automaticky.
- `npm run setup` pridá povolenie VIBRATE do `AndroidManifest.xml` automaticky. Ak si projekt vytvoril staršou verziou, spusti znova `npm install` a `npm run setup`.
- V Menu → Haptika ťukni na **Vyskúšať**, aplikácia ukáže, ktorý spôsob použila (natívna / webová / iOS). Skontroluj aj to, či nemáš v telefóne vypnutú vibráciu pri dotykoch.

## Zmeny v aplikácii
Celá aplikácia je v `www/index.html`. Po úprave spusti `npx cap sync android` a zostav APK znova.

## Do Google Play
Použi **Build → Generate Signed Bundle / APK** (formát AAB), vlastný podpisový kľúč a vývojársky účet Google Play.

## Poznámky
- Písmo Bricolage Grotesque sa sťahuje z internetu; bez pripojenia sa použije systémové písmo. Obľúbené otázky sa ukladajú v zariadení.
- Ikonu aplikácie zmeníš v Android Studiu: pravý klik na `res` → New → Image Asset.
- Názov balíka (`sk.rozpravajme.app`) zmeň v `capacitor.config.json` pred príkazom `npx cap add android`.
