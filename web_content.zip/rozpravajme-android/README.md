# Rozprávajme – Android (APK)

## Čo potrebuješ
- Node.js 20 alebo novší (nodejs.org)
- Android Studio (developer.android.com/studio) – pri inštalácii nechaj zaškrtnutý Android SDK

## Postup
1. Rozbaľ priečinok a otvor v ňom terminál.
2. `npm install`
3. `npx cap add android`
4. `npx cap sync android`
5. `npx cap open android` – otvorí sa Android Studio.
6. Počkaj, kým skončí „Gradle sync“ (dole vpravo).
7. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Hotový súbor nájdeš v `android/app/build/outputs/apk/debug/app-debug.apk`. Pošli si ho do mobilu a nainštaluj (povoľ inštaláciu z neznámych zdrojov).

## Haptika (vibrácia)
- Balík `@capacitor/haptics` je v `package.json`, nainštaluje sa s `npm install` a pridá povolenie na vibráciu. Aplikácia ho použije automaticky.
- Ak si projekt `android` vytvoril ešte pred touto verziou, spusti `npm install` a potom `npx cap sync android`.
- Ak by vibrácia stále nešla, pridaj do `android/app/src/main/AndroidManifest.xml` (nad `<application>`): `<uses-permission android:name="android.permission.VIBRATE" />`
- V Menu → Haptika ťukni na **Vyskúšať**, aplikácia ukáže, ktorý spôsob použila (natívna / webová / iOS). Skontroluj aj to, či nemáš v telefóne vypnutú vibráciu pri dotykoch.

## Zmeny v aplikácii
Celá aplikácia je v `www/index.html`. Po úprave spusti `npx cap sync android` a zostav APK znova.

## Do Google Play
Použi **Build → Generate Signed Bundle / APK** (formát AAB), vlastný podpisový kľúč a vývojársky účet Google Play.

## Poznámky
- Písmo Bricolage Grotesque sa sťahuje z internetu; bez pripojenia sa použije systémové písmo. Obľúbené otázky sa ukladajú v zariadení.
- Ikonu aplikácie zmeníš v Android Studiu: pravý klik na `res` → New → Image Asset.
- Názov balíka (`sk.rozpravajme.app`) zmeň v `capacitor.config.json` pred príkazom `npx cap add android`.
