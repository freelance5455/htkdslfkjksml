// Jednoduché nastavenie Android projektu: vytvorí ho, pridá povolenie na vibráciu a zosynchronizuje.
const { execSync } = require("child_process"), fs = require("fs");
const MANIFEST = "android/app/src/main/AndroidManifest.xml";
const run = c => execSync(c, { stdio: "inherit" });
function addVibrate(xml) {
  if (xml.includes("android.permission.VIBRATE")) return xml;
  return xml.replace("</manifest>", '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
}
module.exports = { addVibrate };
if (require.main === module) {
  if (!fs.existsSync("android")) run("npx cap add android");
  fs.writeFileSync(MANIFEST, addVibrate(fs.readFileSync(MANIFEST, "utf8")));
  run("npx cap sync android");
  console.log("Hotovo. Teraz spusti: npx cap open android");
}
