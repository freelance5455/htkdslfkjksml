OʻZBEK DRIFT SHAHRI — ONLAYN
============================

ENG OSON YOʻL (server shart emas)
  1) index.html faylini doʻstlaringizga yuboring (Telegram/WhatsApp).
  2) Har kim uni telefonida brauzerda ochadi (Chrome tavsiya etiladi). Internet kerak.
  3) Menyuda "Onlayn drift" ni bosing, bir xil XONA KODINI kiriting (masalan: alisher77) va "Qoʻshilish".
  Oʻyin ochiq umumiy MQTT serverlar (HiveMQ, EMQX, Mosquitto) orqali ulanadi, birinchisi ishlamasa keyingisiga oʻtadi.
  Eslatma: xona kodi ochiq, shuning uchun noyob kod tanlang. Bu uchinchi tomon xizmatlari, ularning ishlashi kafolatlanmagan.

OʻZ SERVERINGIZ (eng ishonchli)
  Node.js (nodejs.org) oʻrnating, shu papkada:   node server.js
  U chiqargan manzilni (masalan http://192.168.1.15:3000) doʻstlar bir Wi-Fi da ochadi.
  Internet orqali:  npx cloudflared tunnel --url http://localhost:3000   — chiqqan https manzilni yuboring.
  Hostingga (Render, Railway, Fly.io...) shu papkani joylashingiz mumkin: ishga tushirish buyrugʻi  node server.js
  Agar index.html boshqa joyda boʻlsa, lobbidagi "Server manzili" maydoniga wss://sizning-server/ws yozing.

CLAUDE ICHIDA
  Claude havolasi ichida onlayn faqat Claude hisobiga kirgan, havolaga ruxsati bor kishilar uchun ishlaydi.

OʻYIN
  Markazda dumaloq DRIFT ZONA (rampalar bilan), atrofida 4 fasl bir vaqtda: kuz (shimoli-gʻarb), qish (shimoli-sharq),
  bahor (janubi-gʻarb), yoz (janubi-sharq). Shosselar, poyga yoʻli, test shossesi (sharqda), koʻllar, landmarklar.
  Oʻyinda 📍 tugmasi bilan joylarga oʻtasiz. Tangalar va rekordlar har bir telefonning oʻz xotirasida saqlanadi.
