// Oʻzbek Drift — onlayn server (hech qanday paket oʻrnatish shart emas, faqat Node.js 16+)
// Ishga tushirish:  node server.js     (port: PORT oʻzgaruvchisi, standart 3000)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),os=require('os');
const PORT=+process.env.PORT||3000,MAXROOM=16,GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const srv=http.createServer((q,r)=>{
  const u=q.url.split('?')[0];
  if(u==='/'||u==='/index.html'){try{const h=fs.readFileSync(path.join(__dirname,'index.html'));r.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});r.end(h)}catch(e){r.writeHead(500);r.end('index.html topilmadi')}}
  else if(u==='/health'){r.writeHead(200);r.end('ok')}
  else{r.writeHead(404);r.end('404')}
});
const rooms=new Map();let nid=1;
const frame=(op,p)=>{const n=p.length;let h;if(n<126)h=Buffer.from([0x80|op,n]);else if(n<65536){h=Buffer.alloc(4);h[0]=0x80|op;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=0x80|op;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}return Buffer.concat([h,p])};
const send=(c,o)=>{try{c.sock.write(frame(1,Buffer.from(JSON.stringify(o))))}catch(e){}};
const others=(c,o)=>{const R=rooms.get(c.room);if(R)for(const x of R.values())if(x!==c)send(x,o)};
function drop(c){if(c.gone)return;c.gone=true;if(c.room){const R=rooms.get(c.room);if(R){R.delete(c.id);others(c,{t:'l',id:c.id});if(!R.size)rooms.delete(c.room)}}}
function onMsg(c,s){
  const now=Date.now();if(now-c.t0>1000){c.t0=now;c.cnt=0}if(++c.cnt>60)return;c.alive=now;
  let m;try{m=JSON.parse(s)}catch(e){return}
  if(m.t==='join'&&!c.room){
    const name=String(m.room||'');if(!/^[a-z0-9][a-z0-9_.-]{0,47}$/.test(name)){c.sock.destroy();return}
    let R=rooms.get(name);if(!R){R=new Map();rooms.set(name,R)}
    if(R.size>=MAXROOM){send(c,{t:'full'});c.sock.destroy();return}
    c.room=name;R.set(c.id,c);
    send(c,{t:'w',id:c.id,peers:[...R.values()].filter(x=>x!==c&&x.pres).map(x=>({id:x.id,d:x.pres}))});
  }else if(m.t==='p'&&c.room&&m.d&&typeof m.d==='object'){
    const j=JSON.stringify(m.d);if(j.length>4096)return;c.pres=m.d;others(c,{t:'p',id:c.id,d:m.d});
  }
}
function parse(c){
  for(;;){
    const b=c.buf;if(b.length<2)return;
    const op=b[0]&15,fin=b[0]&128,mask=b[1]&128;let len=b[1]&127,off=2;
    if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}
    else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10}
    if(!mask||len>8192){c.sock.destroy();return}
    if(b.length<off+4+len)return;
    const k=b.subarray(off,off+4),p=Buffer.from(b.subarray(off+4,off+4+len));for(let i=0;i<len;i++)p[i]^=k[i&3];
    c.buf=b.subarray(off+4+len);
    if(op===8){try{c.sock.end(frame(8,Buffer.alloc(0)))}catch(e){}c.sock.destroy();return}
    if(op===9){c.sock.write(frame(10,p));continue}
    if(op===10){c.alive=Date.now();continue}
    if(op===1)c.frag=[p];else if(op===0&&c.frag)c.frag.push(p);else continue;
    if(fin&&c.frag){const s=Buffer.concat(c.frag).toString('utf8');c.frag=null;onMsg(c,s)}
  }
}
srv.on('upgrade',(q,sock)=>{
  const key=q.headers['sec-websocket-key'];
  if(!q.url.startsWith('/ws')||String(q.headers.upgrade).toLowerCase()!=='websocket'||!key){sock.destroy();return}
  const acc=crypto.createHash('sha1').update(key+GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');
  const c={sock,id:'p'+(nid++),room:null,pres:null,buf:Buffer.alloc(0),cnt:0,t0:Date.now(),alive:Date.now(),frag:null,gone:false};
  sock.setNoDelay(true);
  sock.on('data',d=>{c.buf=Buffer.concat([c.buf,d]);if(c.buf.length>65536){sock.destroy();return}parse(c)});
  sock.on('close',()=>drop(c));sock.on('error',()=>sock.destroy());
});
setInterval(()=>{const now=Date.now();for(const R of rooms.values())for(const c of R.values()){if(now-c.alive>60000){c.sock.destroy();continue}try{c.sock.write(frame(9,Buffer.alloc(0)))}catch(e){}}},15000);
srv.listen(PORT,'0.0.0.0',()=>{
  console.log('Oʻzbek Drift serveri ishga tushdi. Port: '+PORT);
  console.log('  Shu kompyuterda:   http://localhost:'+PORT);
  for(const l of Object.values(os.networkInterfaces()))for(const a of l)if(a.family==='IPv4'&&!a.internal)console.log('  Bir Wi-Fi dagi doʻstlar: http://'+a.address+':'+PORT);
});
