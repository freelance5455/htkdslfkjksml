# TPH X — Private Search (starter PWA)

This is a downloadable, installable web-app starter for TPH X.

## What works
- Responsive mobile-first TPH X interface
- Local library with add/edit-by-delete-and-readd workflow
- Search across saved text and notes
- Import `.txt`, `.md`, `.html` and `.csv` files
- Bookmarks, local history controls and JSON export
- Offline app-shell caching after first visit

## What this version does not do
- It does not crawl the public internet.
- It does not yet search live web pages.
- It does not provide a VPN, anonymity, encrypted vault or multi-device sync.
- It does not fetch arbitrary URLs directly; browser CORS and server-side crawling constraints require a backend.

Search queries and library content are stored in browser `localStorage` on this device. This is convenient local storage, not encrypted storage. Do not save passwords or highly sensitive material here. Browser site-data deletion can erase the library.

## Run locally
For a quick desktop test, serve this folder over HTTP (service workers require localhost or HTTPS):

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Install on Android
1. Deploy the folder to a website served over HTTPS (or use a local HTTPS development host).
2. Open the HTTPS address in Chrome on Android.
3. Open the browser menu and choose **Install app** or **Add to Home screen**.
4. Launch TPH X from the home screen.

A PWA is not an APK. A compiled Android APK would require a separate Android/Flutter packaging and signing step.

## Next development stage: independent web search
Add a self-hosted backend, for example:
- Python + FastAPI
- SQLite + FTS5
- A respectful crawler that honours robots.txt, site terms and rate limits
- A search API returning ranked results

Then connect the PWA search form to that backend. Until that backend exists, results are limited to content saved in the local library.
