const DB_KEY = "tphx_library_v1";
const HISTORY_KEY = "tphx_history_v1";
const HISTORY_ENABLED_KEY = "tphx_history_enabled";
let items = loadItems();
let currentQuery = "";

const $ = id => document.getElementById(id);
function loadItems(){try{return JSON.parse(localStorage.getItem(DB_KEY)||"[]")}catch{return []}}
function persist(){localStorage.setItem(DB_KEY,JSON.stringify(items));renderLibrary();renderBookmarks();$("libraryCount").textContent=items.length}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200)}
function showView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));
  $(name+"View").classList.remove("hidden");
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  if(name==="library")renderLibrary();if(name==="bookmarks")renderBookmarks();
}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
function openAdd(){ $("addDialog").showModal(); }
document.querySelectorAll("[data-open-add]").forEach(b=>b.addEventListener("click",openAdd));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$(b.dataset.close).close()));
$("settingsBtn").addEventListener("click",()=>{$("historyToggle").checked=localStorage.getItem(HISTORY_ENABLED_KEY)!=="false";$("settingsDialog").showModal()});
$("addForm").addEventListener("submit",e=>{
  e.preventDefault();
  const title=$("itemTitle").value.trim(),url=$("itemUrl").value.trim(),content=$("itemContent").value.trim();
  if(!title||!content)return;
  items.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),title,url,content,created:new Date().toISOString(),bookmarked:false});
  persist();$("addForm").reset();$("addDialog").close();showView("library");toast("Saved to your private index");
});
function snippet(text,q){const clean=text.replace(/\s+/g," ").trim();const i=clean.toLowerCase().indexOf(q.toLowerCase());if(i<0)return clean.slice(0,190)+(clean.length>190?"…":"");return (i>65?"…":"")+clean.slice(Math.max(0,i-65),Math.min(clean.length,i+q.length+125))+(i+q.length+125<clean.length?"…":"")}
function search(q){
  currentQuery=q.trim();if(!currentQuery)return;
  if(localStorage.getItem(HISTORY_ENABLED_KEY)!=="false"){let h=[];try{h=JSON.parse(localStorage.getItem(HISTORY_KEY)||"[]")}catch{};h=[currentQuery,...h.filter(x=>x!==currentQuery)].slice(0,30);localStorage.setItem(HISTORY_KEY,JSON.stringify(h))}
  const terms=currentQuery.toLowerCase().split(/\s+/).filter(Boolean);
  const ranked=items.map(item=>{
    const hay=(item.title+" "+item.url+" "+item.content).toLowerCase();
    const score=terms.reduce((n,t)=>n+(hay.includes(t)?(item.title.toLowerCase().includes(t)?4:1):0),0);
    return {item,score};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
  $("resultsTitle").textContent=`Results for “${currentQuery}”`;
  $("resultCount").textContent=`${ranked.length} FOUND`;
  const results=$("results");
  if(!ranked.length){results.innerHTML=`<div class="empty-state"><div class="empty-icon">⌕</div><h3>No matches in your index</h3><p>Try another phrase or add more pages and notes to your library.</p><button class="outline-btn" data-open-add>Add content</button></div>`;results.querySelector("[data-open-add]")?.addEventListener("click",openAdd);return}
  results.innerHTML=ranked.map(({item})=>`<article class="result-card"><div class="result-url">${escapeHtml(item.url||"LOCAL NOTE")}</div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(snippet(item.content,currentQuery))}</p><div class="card-actions"><button class="outline-btn" data-bookmark="${escapeHtml(item.id)}">${item.bookmarked?"SAVED ✓":"SAVE RESULT"}</button>${item.url?`<button class="outline-btn" data-open-url="${escapeHtml(item.id)}">OPEN SOURCE ↗</button>`:""}</div></article>`).join("");
  results.querySelectorAll("[data-bookmark]").forEach(b=>b.addEventListener("click",()=>toggleBookmark(b.dataset.bookmark)));
  results.querySelectorAll("[data-open-url]").forEach(b=>b.addEventListener("click",()=>{const it=items.find(x=>x.id===b.dataset.openUrl);if(it?.url)window.open(it.url,"_blank","noopener,noreferrer")}));
}
$("searchForm").addEventListener("submit",e=>{e.preventDefault();search($("query").value);showView("search")});
function toggleBookmark(id){const it=items.find(x=>x.id===id);if(it){it.bookmarked=!it.bookmarked;persist();if(currentQuery)search(currentQuery);toast(it.bookmarked?"Saved":"Removed from saved")}}
function renderLibrary(filter=""){
  const list=$("libraryList"),q=filter.toLowerCase();
  const found=items.filter(x=>(x.title+" "+x.url+" "+x.content).toLowerCase().includes(q));
  list.innerHTML=found.length?found.map(x=>`<article class="item-card"><div class="item-meta">${new Date(x.created).toLocaleDateString()} · ${x.bookmarked?"BOOKMARKED":"INDEXED"}</div><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(snippet(x.content,""))}</p><div class="card-actions"><button class="outline-btn" data-use="${escapeHtml(x.id)}">SEARCH THIS</button><button class="outline-btn" data-bm="${escapeHtml(x.id)}">${x.bookmarked?"UNSAVE":"SAVE"}</button><button class="outline-btn danger" data-del="${escapeHtml(x.id)}">DELETE</button></div></article>`).join(""):`<div class="empty-state"><h3>Your library is empty</h3><p>Add notes or import text files to build your private index.</p><button class="outline-btn" data-open-add>Add first item</button></div>`;
  list.querySelector("[data-open-add]")?.addEventListener("click",openAdd);
  list.querySelectorAll("[data-use]").forEach(b=>b.addEventListener("click",()=>{const x=items.find(i=>i.id===b.dataset.use);$("query").value=x.title;search(x.title);showView("search")}));
  list.querySelectorAll("[data-bm]").forEach(b=>b.addEventListener("click",()=>toggleBookmark(b.dataset.bm)));
  list.querySelectorAll("[data-del]").forEach(b=>b.addEventListener("click",()=>{if(confirm("Delete this item from your local index?")){items=items.filter(i=>i.id!==b.dataset.del);persist();toast("Item deleted")}}));
}
function renderBookmarks(){
  const list=$("bookmarkList"),found=items.filter(x=>x.bookmarked);
  list.innerHTML=found.length?found.map(x=>`<article class="item-card"><div class="item-meta">SAVED RESULT</div><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(snippet(x.content,""))}</p><div class="card-actions"><button class="outline-btn" data-un="${escapeHtml(x.id)}">REMOVE SAVED</button></div></article>`).join(""):`<div class="empty-state"><h3>No saved results yet</h3><p>Save useful items from your search results for quick access.</p></div>`;
  list.querySelectorAll("[data-un]").forEach(b=>b.addEventListener("click",()=>toggleBookmark(b.dataset.un)));
}
$("libraryFilter").addEventListener("input",e=>renderLibrary(e.target.value));
$("importBtn").addEventListener("click",()=>$("fileInput").click());
$("fileInput").addEventListener("change",async e=>{
  for(const file of e.target.files){const text=await file.text();items.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random()),title:file.name,url:"",content:text,created:new Date().toISOString(),bookmarked:false})}
  persist();e.target.value="";toast("Files imported into your local index");
});
$("historyToggle").addEventListener("change",e=>localStorage.setItem(HISTORY_ENABLED_KEY,String(e.target.checked)));
$("clearHistoryBtn").addEventListener("click",()=>{localStorage.removeItem(HISTORY_KEY);toast("Search history cleared")});
$("clearDataBtn").addEventListener("click",()=>{if(confirm("Permanently delete all TPH X library items on this device?")){items=[];persist();toast("Local library deleted")}});
$("exportBtn").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify({app:"TPH X",version:1,exported:new Date().toISOString(),items},null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="tph-x-library-backup.json";a.click();URL.revokeObjectURL(a.href);
});
$("libraryCount").textContent=items.length;
renderLibrary();renderBookmarks();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
