HAFIZ GRAIN SHOP MUSA KHEL - MOBILE PROFESSIONAL

Proprietor: Abid Nawaz

=== موبائل پر کیسے انسٹال کریں ===

طریقہ 1 (سب سے آسان - Android):
1. ان فائلوں کو موبائل پر کاپی کریں (یا کمپیوٹر پر لوکل سرور چلائیں)
2. Chrome میں index.html کھولیں
3. مینو (⋮) → "Add to Home screen" / "Install app"
4. اب ہوم اسکرین پر آئیکن آ جائے گا — ایپ کی طرح کھلے گی

طریقہ 2 (کمپیوٹر سے موبائل):
1. کمپیوٹر پر اس فولڈر میں جائیں
2. Command Prompt میں لکھیں:  npx serve -p 3000
3. موبائل اور کمپیوٹر ایک ہی WiFi پر ہوں
4. موبائل Chrome میں کھولیں: http://آپ-کا-کمپیوٹر-IP:3000
5. Add to Home Screen کریں

نوٹ: ڈیٹا موبائل کے براؤزر میں محفوظ رہتا ہے۔ Backup ضرور لیں۔
