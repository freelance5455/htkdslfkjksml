(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  // Token lives in sessionStorage only: cleared when the tab closes.
  const store = {
    get() { try { return sessionStorage.getItem("phuy_admin"); } catch (e) { return null; } },
    set(v) { try { sessionStorage.setItem("phuy_admin", v); } catch (e) { /* ignore */ } },
    clear() { try { sessionStorage.removeItem("phuy_admin"); } catch (e) { /* ignore */ } },
  };
  function say(el, t, k) { el.textContent = t; el.className = "msg " + (k || ""); }

  async function api(path, method, body) {
    const headers = { "Content-Type": "application/json" };
    const t = store.get();
    if (t) headers.Authorization = "Bearer " + t;
    let res;
    try { res = await fetch(path, { method: method, headers: headers, body: body ? JSON.stringify(body) : undefined }); }
    catch (e) { throw new Error("Không kết nối được máy chủ."); }
    let data = {};
    try { data = await res.json(); } catch (e) { /* ignore */ }
    if (res.status === 401 && t) { store.clear(); show(false); }
    if (!res.ok) throw new Error(data.message || ("Lỗi " + res.status));
    return data;
  }

  function show(loggedIn) {
    $("loginCard").classList.toggle("hidden", loggedIn);
    $("panel").classList.toggle("hidden", !loggedIn);
  }

  async function refresh() {
    try {
      const r = await api("/api/admin/keys", "GET");
      const rows = $("rows");
      rows.replaceChildren();
      r.keys.forEach((k) => {
        const tr = document.createElement("tr");
        const a = document.createElement("td"); a.textContent = k.key;
        const b = document.createElement("td");
        const badge = document.createElement("span"); badge.className = "badge " + k.status; badge.textContent = k.status;
        b.appendChild(badge);
        const c = document.createElement("td"); c.textContent = new Date(k.expires_at * 1000).toLocaleString("vi-VN");
        a.style.cursor = "pointer"; a.addEventListener("click", () => { $("target").value = k.key; });
        tr.append(a, b, c); rows.appendChild(tr);
      });
    } catch (e) { say($("msgAdmin"), e.message, "err"); }
  }

  $("btnLogin").addEventListener("click", async () => {
    say($("msgLogin"), "Đang đăng nhập...");
    try {
      const r = await api("/api/admin/login", "POST", { username: $("user").value, password: $("pass").value });
      store.set(r.token); $("pass").value = ""; say($("msgLogin"), "", ""); show(true); refresh();
    } catch (e) { say($("msgLogin"), e.message, "err"); }
  });

  async function act(path, label) {
    const key = $("target").value.trim();
    if (!key) return say($("msgAdmin"), "Nhập key.", "err");
    try {
      const r = await api(path, "POST", { key: key, reason: $("reason").value });
      say($("msgAdmin"), label + (r.key && r.key !== key ? " Key mới: " + r.key : " Thành công."), "ok");
      refresh();
    } catch (e) { say($("msgAdmin"), e.message, "err"); }
  }
  $("btnRevoke").addEventListener("click", () => act("/api/keys/revoke", "Đã thu hồi."));
  $("btnAdminReset").addEventListener("click", () => act("/api/keys/reset", "Đã vô hiệu hóa key cũ."));
  $("btnRefresh").addEventListener("click", refresh);
  $("btnLogout").addEventListener("click", async () => { try { await api("/api/admin/logout", "POST"); } catch (e) { /* ignore */ } store.clear(); show(false); });
  $("btnLogoutAll").addEventListener("click", async () => { try { await api("/api/admin/logout-all", "POST"); } catch (e) { /* ignore */ } store.clear(); show(false); });

  if (store.get()) { show(true); refresh(); }
})();
