(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);

  async function api(path, opts) {
    let res;
    try {
      res = await fetch(path, opts);
    } catch (e) {
      throw new Error("Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.");
    }
    let data = {};
    try { data = await res.json(); } catch (e) { /* non-JSON error page */ }
    if (!res.ok) throw new Error(data.message || ("Lỗi " + res.status));
    return data;
  }
  const post = (p, body) => api(p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

  function say(el, text, kind) { el.textContent = text; el.className = "msg " + (kind || ""); }
  async function busy(btn, fn) { btn.disabled = true; try { await fn(); } finally { btn.disabled = false; } }

  function fmtLeft(s) {
    if (s <= 0) return "0";
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    return (d ? d + " ngày " : "") + h + " giờ " + m + " phút";
  }
  function fmtDate(ts) { return new Date(ts * 1000).toLocaleString("vi-VN"); }

  async function copy(text, msgEl) {
    try { await navigator.clipboard.writeText(text); say(msgEl, "Đã sao chép.", "ok"); }
    catch (e) { say(msgEl, "Không thể tự sao chép, hãy chọn và sao chép thủ công.", "err"); }
  }

  $("btnGet").addEventListener("click", () => busy($("btnGet"), async () => {
    say($("msgGet"), "Đang tạo key...");
    try {
      const r = await post("/api/keys/create", { duration_days: parseInt($("days").value, 10) });
      $("keyText").textContent = r.key;
      $("tokenText").textContent = r.reset_token;
      $("newKey").classList.remove("hidden");
      $("checkInput").value = r.key;
      $("resetKey").value = r.key;
      say($("msgGet"), "Tạo key thành công. Hết hạn: " + fmtDate(r.expires_at), "ok");
    } catch (e) { say($("msgGet"), e.message, "err"); }
  }));
  $("copyKey").addEventListener("click", () => copy($("keyText").textContent, $("msgGet")));
  $("copyToken").addEventListener("click", () => copy($("tokenText").textContent, $("msgGet")));

  $("btnCheck").addEventListener("click", () => busy($("btnCheck"), async () => {
    const key = $("checkInput").value.trim();
    $("checkResult").classList.add("hidden");
    if (!key) return say($("msgCheck"), "Nhập key cần kiểm tra.", "err");
    say($("msgCheck"), "Đang kiểm tra...");
    try {
      const r = await api("/api/keys/status?key=" + encodeURIComponent(key));
      const b = document.createElement("span");
      b.className = "badge " + r.status; b.textContent = r.status;
      $("rStatus").replaceChildren(b);
      $("rExp").textContent = fmtDate(r.expires_at);
      $("rLeft").textContent = fmtLeft(r.seconds_left);
      $("rResets").textContent = String(r.resets_left);
      $("checkResult").classList.remove("hidden");
      say($("msgCheck"), "", "");
    } catch (e) { say($("msgCheck"), e.message, "err"); }
  }));

  $("btnReset").addEventListener("click", () => busy($("btnReset"), async () => {
    const key = $("resetKey").value.trim(), token = $("resetToken").value.trim();
    $("resetOut").classList.add("hidden");
    if (!key || !token) return say($("msgReset"), "Cần nhập cả key và mã khôi phục.", "err");
    say($("msgReset"), "Đang reset...");
    try {
      const r = await post("/api/keys/reset", { key: key, reset_token: token, reason: "user request" });
      $("resetNewKey").textContent = r.key;
      $("resetOut").classList.remove("hidden");
      say($("msgReset"), "Reset thành công. Key cũ đã bị vô hiệu hóa. Hết hạn: " + fmtDate(r.expires_at), "ok");
    } catch (e) { say($("msgReset"), e.message, "err"); }
  }));
  $("copyReset").addEventListener("click", () => copy($("resetNewKey").textContent, $("msgReset")));
})();
