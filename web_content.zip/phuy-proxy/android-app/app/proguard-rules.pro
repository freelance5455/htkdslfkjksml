# Keep service classes referenced from the manifest.
-keep class com.phuy.proxy.vpn.PhuyVpnService { *; }
-keep class com.phuy.proxy.overlay.FloatingButtonService { *; }
