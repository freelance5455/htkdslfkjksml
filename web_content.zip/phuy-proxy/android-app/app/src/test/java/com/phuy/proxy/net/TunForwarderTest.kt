package com.phuy.proxy.net

import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.Socket

class TunForwarderTest {
    private val client = (10 shl 24) or (77 shl 16) or 2
    private val dst = loopback()
    private val cport = 41000
    private val toClose = mutableListOf<AutoCloseable>()
    private var fwd: TunForwarder? = null

    @After fun tearDown() { fwd?.stop(); toClose.forEach { runCatching { it.close() } } }

    private fun <T : AutoCloseable> T.track(): T = also { toClose.add(it) }

    private fun parse(p: ByteArray) = TcpView(Ipv4View(p, p.size))

    private fun checksumOk(p: ByteArray): Boolean {
        val ip = Ipv4View(p, p.size)
        val s = Checksum.sum(p, ip.l4Off, ip.l4Len, Checksum.pseudo(ip.src, ip.dst, ip.protocol, ip.l4Len))
        return Checksum.fold(s) == 0 && Checksum.fold(Checksum.sum(p, 0, 20)) == 0
    }

    private fun start(tun: FakeTun, up: UpstreamConnector): TunForwarder = TunForwarder(tun, up).also { it.start(); fwd = it }

    private fun socksTo(proxy: FakeSocks5) =
        ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, InetAddress.getByName("127.0.0.1"), proxy.port))

    /** Reads packets until one with the wanted flag mask appears. Collects payload bytes seen. */
    private fun collect(tun: FakeTun, until: (TcpView, ByteArray) -> Boolean): ByteArray {
        val data = ByteArrayOutputStream()
        while (true) {
            val p = tun.next() ?: error("timeout waiting for packet")
            assertTrue("bad checksum", checksumOk(p))
            val t = parse(p)
            if (t.payloadLen > 0) data.write(p, t.payloadOff, t.payloadLen)
            if (until(t, p)) return data.toByteArray()
        }
    }

    @Test fun tcpSessionEchoesThroughProxy() {
        val echo = EchoServer().track(); val proxy = FakeSocks5().track()
        val tun = FakeTun(); start(tun, socksTo(proxy))

        // 1. SYN -> SYN-ACK
        val isn = 1000L
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn, 0, TcpFlags.SYN, 65535, null, mss = 1400))
        val synAckPkt = tun.next()!!; assertTrue(checksumOk(synAckPkt))
        val synAck = parse(synAckPkt)
        assertEquals(TcpFlags.SYN or TcpFlags.ACK, synAck.flags and (TcpFlags.SYN or TcpFlags.ACK))
        assertEquals(isn + 1, synAck.ack)
        val serverNext = Seq.add(synAck.seq, 1)
        assertEquals("127.0.0.1:${echo.port}", proxy.lastTarget)

        // 2. ACK + data -> pure ACK, then echoed data
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn + 1, serverNext, TcpFlags.ACK, 65535, null))
        val msg = "hello through the proxy".toByteArray()
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn + 1, serverNext, TcpFlags.ACK or TcpFlags.PSH, 65535, msg, 0, msg.size))
        // read until the echo has fully arrived
        val got = ByteArrayOutputStream()
        var ackSeen = false
        var last: TcpView? = null
        while (got.size() < msg.size) {
            val p = tun.next() ?: error("timeout waiting for echo")
            assertTrue(checksumOk(p))
            val t = parse(p); last = t
            if (t.payloadLen == 0 && t.ack == isn + 1 + msg.size) ackSeen = true
            if (t.payloadLen > 0) got.write(p, t.payloadOff, t.payloadLen)
        }
        assertArrayEquals(msg, got.toByteArray())
        assertTrue("forwarder must ACK client data", ackSeen || last!!.ack == isn + 1 + msg.size)
        assertEquals(msg.size.toLong(), fwd!!.txBytes.get())
        assertEquals(msg.size.toLong(), fwd!!.rxBytes.get())

        // 3. client FIN -> ACK, then server FIN once the echo server closes
        val clientNext = isn + 1 + msg.size
        val serverSeqNow = Seq.add(serverNext, msg.size)
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, clientNext, serverSeqNow, TcpFlags.ACK or TcpFlags.FIN, 65535, null))
        var sawFin = false
        while (!sawFin) {
            val t = parse(tun.next() ?: error("timeout waiting for FIN"))
            if ((t.flags and TcpFlags.FIN) != 0) sawFin = true
        }
        assertTrue(sawFin)
    }

    @Test fun largeTransferIsSegmentedAndComplete() {
        val echo = EchoServer().track(); val proxy = FakeSocks5().track()
        val tun = FakeTun(); start(tun, socksTo(proxy))
        val isn = 5L
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn, 0, TcpFlags.SYN, 65535, null))
        val sa = parse(tun.next()!!); val sNext = Seq.add(sa.seq, 1)
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn + 1, sNext, TcpFlags.ACK, 65535, null))

        val payload = ByteArray(20_000) { (it * 31).toByte() }
        var sent = 0L
        var ack = sNext
        val got = ByteArrayOutputStream()
        while (sent < payload.size) {
            val n = minOf(1200, payload.size - sent.toInt())
            tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn + 1 + sent, ack, TcpFlags.ACK or TcpFlags.PSH, 65535, payload, sent.toInt(), n))
            sent += n
        }
        var lastServerSeq = sNext
        while (got.size() < payload.size) {
            val p = tun.next() ?: error("timeout, got ${got.size()} of ${payload.size}")
            assertTrue(checksumOk(p))
            val t = parse(p)
            if (t.payloadLen > 0) {
                assertTrue("segment must fit MSS", t.payloadLen <= TunForwarder.MSS)
                assertEquals("server data must be in order", lastServerSeq, t.seq)
                got.write(p, t.payloadOff, t.payloadLen)
                lastServerSeq = Seq.add(lastServerSeq, t.payloadLen)
                // client acknowledges what it received (keeps the window open)
                tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn + 1 + sent, lastServerSeq, TcpFlags.ACK, 65535, null))
            }
        }
        assertArrayEquals(payload, got.toByteArray())
    }

    @Test fun duplicateClientSegmentIsNotDeliveredTwice() {
        val echo = EchoServer().track(); val proxy = FakeSocks5().track()
        val tun = FakeTun(); start(tun, socksTo(proxy))
        val isn = 77L
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, isn, 0, TcpFlags.SYN, 65535, null))
        val sNext = Seq.add(parse(tun.next()!!).seq, 1)
        val m = "abc".toByteArray()
        val seg = PacketBuilder.tcp(client, dst, cport, echo.port, isn + 1, sNext, TcpFlags.ACK or TcpFlags.PSH, 65535, m, 0, m.size)
        tun.inject(seg); tun.inject(seg.copyOf())      // retransmission
        Thread.sleep(500)
        assertEquals(3L, fwd!!.txBytes.get())
    }

    @Test fun proxyDownMakesClientGetRstAndNeverConnects() {
        val echo = EchoServer().track()
        val tun = FakeTun()
        val dead = java.net.ServerSocket(0).use { it.localPort }
        start(tun, ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, InetAddress.getByName("127.0.0.1"), dead), timeoutMs = 1500))
        tun.inject(PacketBuilder.tcp(client, dst, cport, echo.port, 1, 0, TcpFlags.SYN, 65535, null))
        val rst = parse(tun.next()!!)
        assertTrue((rst.flags and TcpFlags.RST) != 0)
        assertTrue((rst.flags and TcpFlags.SYN) == 0)
        assertEquals(0L, fwd!!.upstreamSuccesses.get())
        assertTrue(fwd!!.consecutiveUpstreamFailures.get() >= 1)
    }

    @Test fun dnsQueryIsAnsweredOverTcpThroughUpstream() {
        // Fake DNS-over-TCP server: replies with query bytes reversed so we can recognise it.
        val dnsServer = java.net.ServerSocket(0, 10, InetAddress.getByName("127.0.0.1")).track()
        Thread {
            try {
                while (true) {
                    val c = dnsServer.accept()
                    val i = c.getInputStream()
                    val len = (i.read() shl 8) or i.read()
                    val q = ByteArray(len); var r = 0
                    while (r < len) r += i.read(q, r, len - r)
                    val resp = q.reversedArray()
                    c.getOutputStream().write(byteArrayOf((resp.size shr 8).toByte(), resp.size.toByte()))
                    c.getOutputStream().write(resp); c.close()
                }
            } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()

        val tun = FakeTun()
        start(tun) { host, port -> Socket("127.0.0.1", if (port == 53) dnsServer.localPort else port) }
        val q = byteArrayOf(0x12, 0x34, 1, 0, 0, 1)
        tun.inject(PacketBuilder.udp(client, (1 shl 24) or (1 shl 16) or (1 shl 8) or 1, 5353, 53, q, 0, q.size))
        val reply = tun.next()!!
        assertTrue(checksumOk(reply))
        val ip = Ipv4View(reply, reply.size); val u = UdpView(ip)
        assertEquals(53, u.srcPort); assertEquals(5353, u.dstPort); assertEquals(client, ip.dst)
        assertArrayEquals(q.reversedArray(), reply.copyOfRange(u.payloadOff, u.payloadOff + u.payloadLen))
    }

    @Test fun nonDnsUdpAndIpv6AreDroppedNotForwarded() {
        val tun = FakeTun(); val f = start(tun) { _, _ -> error("must not connect") }
        val q = byteArrayOf(1, 2, 3)
        tun.inject(PacketBuilder.udp(client, dst, 40000, 27015, q, 0, q.size))      // game-style UDP
        val v6 = ByteArray(40); v6[0] = 0x60; tun.inject(v6)
        Thread.sleep(300)
        assertEquals(2L, f.droppedPackets.get())
        assertNotNull(f)
    }
}
