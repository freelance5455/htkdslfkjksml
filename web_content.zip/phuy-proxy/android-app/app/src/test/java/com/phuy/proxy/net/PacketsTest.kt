package com.phuy.proxy.net

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PacketsTest {
    private val client = (10 shl 24) or (77 shl 16) or 2
    private val server = (93 shl 24) or (184 shl 16) or (216 shl 8) or 34

    /** A correct IPv4/TCP/UDP checksum makes the one's-complement sum over the data equal 0xFFFF. */
    private fun ipChecksumOk(p: ByteArray) = Checksum.fold(Checksum.sum(p, 0, 20)) == 0

    private fun l4ChecksumOk(p: ByteArray, proto: Int): Boolean {
        val ip = Ipv4View(p, p.size)
        val s = Checksum.sum(p, ip.l4Off, ip.l4Len, Checksum.pseudo(ip.src, ip.dst, proto, ip.l4Len))
        return Checksum.fold(s) == 0
    }

    @Test fun tcpRoundTripAndChecksums() {
        val data = "hello world".toByteArray()
        val p = PacketBuilder.tcp(client, server, 40000, 443, 0xFFFFFFF0L, 12345, TcpFlags.PSH or TcpFlags.ACK, 65535, data, 0, data.size)
        assertTrue(ipChecksumOk(p)); assertTrue(l4ChecksumOk(p, Proto.TCP))
        val ip = Ipv4View(p, p.size); assertTrue(ip.valid); assertFalse(ip.fragmented)
        assertEquals(client, ip.src); assertEquals(server, ip.dst)
        val t = TcpView(ip); assertTrue(t.valid)
        assertEquals(40000, t.srcPort); assertEquals(443, t.dstPort)
        assertEquals(0xFFFFFFF0L, t.seq); assertEquals(12345L, t.ack)
        assertEquals(data.size, t.payloadLen)
        assertArrayEquals(data, p.copyOfRange(t.payloadOff, t.payloadOff + t.payloadLen))
    }

    @Test fun synAckCarriesMssOption() {
        val p = PacketBuilder.tcp(server, client, 443, 40000, 1, 2, TcpFlags.SYN or TcpFlags.ACK, 65535, null, mss = 1360)
        val t = TcpView(Ipv4View(p, p.size))
        assertEquals(24, t.headerLen); assertEquals(0, t.payloadLen)
        assertTrue(l4ChecksumOk(p, Proto.TCP))
        assertEquals(1360, p.u16(20 + 22))
    }

    @Test fun udpRoundTrip() {
        val q = byteArrayOf(1, 2, 3, 4, 5)   // odd length exercises checksum padding
        val p = PacketBuilder.udp(server, client, 53, 5353, q, 0, q.size)
        assertTrue(ipChecksumOk(p)); assertTrue(l4ChecksumOk(p, Proto.UDP))
        val u = UdpView(Ipv4View(p, p.size))
        assertEquals(53, u.srcPort); assertEquals(5353, u.dstPort); assertEquals(5, u.payloadLen)
    }

    @Test fun rejectsGarbageAndFragments() {
        assertFalse(Ipv4View(ByteArray(10), 10).valid)
        val v6 = ByteArray(40); v6[0] = 0x60
        assertFalse(Ipv4View(v6, 40).valid)
        val p = PacketBuilder.tcp(client, server, 1, 2, 0, 0, TcpFlags.SYN, 100, null)
        p.put16(6, 0x2000)                    // More-Fragments
        assertTrue(Ipv4View(p, p.size).fragmented)
    }

    @Test fun sequenceArithmeticWraps() {
        assertEquals(5L, Seq.add(0xFFFFFFFBL, 10))
        assertEquals(10, Seq.diff(5L, 0xFFFFFFFBL))
        assertEquals(-10, Seq.diff(0xFFFFFFFBL, 5L))
    }

    @Test fun parseIpv4() {
        assertArrayEquals(byteArrayOf(1, 2, 3, 4), ProxyConnector.parseIpv4("1.2.3.4"))
        assertEquals(null, ProxyConnector.parseIpv4("example.com"))
        assertEquals(null, ProxyConnector.parseIpv4("256.1.1.1"))
    }
}
