package com.phuy.proxy.net

import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** TCP echo server on loopback. Echoes until the client half-closes, then closes. */
class EchoServer : AutoCloseable {
    val server = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
    val port get() = server.localPort
    init {
        thread(isDaemon = true) {
            while (!server.isClosed) {
                val s = try { server.accept() } catch (e: Exception) { return@thread }
                thread(isDaemon = true) {
                    try {
                        val i = s.getInputStream(); val o = s.getOutputStream()
                        val b = ByteArray(4096)
                        while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() }
                        s.close()
                    } catch (_: Exception) {}
                }
            }
        }
    }
    override fun close() { server.close() }
}

/** Minimal SOCKS5 server (no-auth or user/pass) that connects to the requested target. */
class FakeSocks5(private val user: String? = null, private val pass: String? = null) : AutoCloseable {
    val server = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
    val port get() = server.localPort
    @Volatile var lastTarget: String? = null

    init {
        thread(isDaemon = true) {
            while (!server.isClosed) {
                val c = try { server.accept() } catch (e: Exception) { return@thread }
                thread(isDaemon = true) { try { serve(c) } catch (_: Exception) { try { c.close() } catch (_: Exception) {} } }
            }
        }
    }

    private fun readN(i: InputStream, n: Int): ByteArray {
        val b = ByteArray(n); var r = 0
        while (r < n) { val k = i.read(b, r, n - r); if (k < 0) throw java.io.IOException("eof"); r += k }
        return b
    }

    private fun serve(c: Socket) {
        val i = c.getInputStream(); val o = c.getOutputStream()
        val g = readN(i, 2); val methods = readN(i, g[1].toInt())
        if (user != null) {
            if (!methods.contains(2)) { o.write(byteArrayOf(5, 0xFF.toByte())); c.close(); return }
            o.write(byteArrayOf(5, 2)); o.flush()
            readN(i, 1)
            val u = String(readN(i, readN(i, 1)[0].toInt() and 0xFF))
            val p = String(readN(i, readN(i, 1)[0].toInt() and 0xFF))
            if (u != user || p != pass) { o.write(byteArrayOf(1, 1)); c.close(); return }
            o.write(byteArrayOf(1, 0))
        } else {
            o.write(byteArrayOf(5, 0))
        }
        o.flush()
        val h = readN(i, 4)
        val host = when (h[3].toInt()) {
            1 -> readN(i, 4).joinToString(".") { (it.toInt() and 0xFF).toString() }
            3 -> String(readN(i, readN(i, 1)[0].toInt() and 0xFF))
            else -> throw java.io.IOException("atyp")
        }
        val pb = readN(i, 2)
        val port = ((pb[0].toInt() and 0xFF) shl 8) or (pb[1].toInt() and 0xFF)
        lastTarget = "$host:$port"
        val t = try { Socket(host, port) } catch (e: Exception) {
            o.write(byteArrayOf(5, 5, 0, 1, 0, 0, 0, 0, 0, 0)); c.close(); return
        }
        o.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); o.flush()
        thread(isDaemon = true) { pipe(t.getInputStream(), c, t) }
        pipe(i, t, c)
    }

    private fun pipe(from: InputStream, to: Socket, other: Socket) {
        try {
            val b = ByteArray(4096)
            while (true) { val n = from.read(b); if (n < 0) break; to.getOutputStream().write(b, 0, n); to.getOutputStream().flush() }
        } catch (_: Exception) {}
        try { to.shutdownOutput() } catch (_: Exception) {}
    }

    override fun close() { server.close() }
}

/** HTTP proxy that answers CONNECT; replies with [status] (e.g. 200 or 407). */
class FakeHttpProxy(private val status: Int = 200) : AutoCloseable {
    val server = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
    val port get() = server.localPort
    @Volatile var lastRequest: String = ""
    init {
        thread(isDaemon = true) {
            while (!server.isClosed) {
                val c = try { server.accept() } catch (e: Exception) { return@thread }
                thread(isDaemon = true) {
                    try {
                        val i = c.getInputStream(); val sb = StringBuilder()
                        while (!sb.endsWith("\r\n\r\n")) { val x = i.read(); if (x < 0) return@thread; sb.append(x.toChar()) }
                        lastRequest = sb.toString()
                        val target = sb.lines().first().split(' ')[1]
                        if (status != 200) {
                            c.getOutputStream().write("HTTP/1.1 $status X\r\nContent-Length: 0\r\n\r\n".toByteArray()); c.close(); return@thread
                        }
                        val t = Socket(target.substringBeforeLast(':'), target.substringAfterLast(':').toInt())
                        c.getOutputStream().write("HTTP/1.1 200 Connection established\r\n\r\n".toByteArray())
                        thread(isDaemon = true) { try { t.getInputStream().copyTo(c.getOutputStream()) } catch (_: Exception) {} ; try { c.shutdownOutput() } catch (_: Exception) {} }
                        try { i.copyTo(t.getOutputStream()) } catch (_: Exception) {}
                        try { t.shutdownOutput() } catch (_: Exception) {}
                    } catch (_: Exception) {}
                }
            }
        }
    }
    override fun close() { server.close() }
}

/** In-memory TUN: tests push packets with [inject] and read what the forwarder wrote with [next]. */
class FakeTun : TunIO {
    private val inbound = LinkedBlockingQueue<ByteArray>()
    private val outbound = LinkedBlockingQueue<ByteArray>()
    private val closed = ByteArray(0)

    fun inject(p: ByteArray) { inbound.put(p) }
    fun next(timeoutMs: Long = 5000): ByteArray? = outbound.poll(timeoutMs, TimeUnit.MILLISECONDS)
    fun close() { inbound.put(closed) }

    override fun read(buf: ByteArray): Int {
        val p = inbound.take()
        if (p === closed) return -1
        System.arraycopy(p, 0, buf, 0, p.size)
        return p.size
    }
    override fun write(buf: ByteArray, off: Int, len: Int) { outbound.put(buf.copyOfRange(off, off + len)) }
}

fun loopback(): Int = (127 shl 24) or 1
