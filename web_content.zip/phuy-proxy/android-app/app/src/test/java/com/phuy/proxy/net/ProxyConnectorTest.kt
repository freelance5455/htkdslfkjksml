package com.phuy.proxy.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.InetAddress
import java.net.ServerSocket

class ProxyConnectorTest {
    private val lo = InetAddress.getByName("127.0.0.1")

    private fun roundTrip(c: UpstreamConnector, port: Int) {
        val s = c.connect("127.0.0.1", port)
        s.getOutputStream().write("ping".toByteArray()); s.getOutputStream().flush()
        val buf = ByteArray(4); var r = 0
        while (r < 4) r += s.getInputStream().read(buf, r, 4 - r)
        assertEquals("ping", String(buf)); s.close()
    }

    @Test fun socks5NoAuth() {
        EchoServer().use { echo -> FakeSocks5().use { p ->
            roundTrip(ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, lo, p.port)), echo.port)
            assertEquals("127.0.0.1:${echo.port}", p.lastTarget)
        } }
    }

    @Test fun socks5WithCorrectCredentials() {
        EchoServer().use { echo -> FakeSocks5("u", "p").use { p ->
            roundTrip(ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, lo, p.port, "u", "p")), echo.port)
        } }
    }

    @Test fun socks5WrongCredentialsFailsClearly() {
        FakeSocks5("u", "p").use { p ->
            try { ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, lo, p.port, "u", "bad")).connect("127.0.0.1", 9); fail() }
            catch (e: ProxyException) { assertTrue(e.message!!.contains("Sai tài khoản")) }
        }
    }

    @Test fun socks5TargetRefusedIsReported() {
        val closedPort = ServerSocket(0).use { it.localPort }
        FakeSocks5().use { p ->
            try { ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, lo, p.port)).connect("127.0.0.1", closedPort); fail() }
            catch (e: ProxyException) { assertTrue(e.message!!.contains("từ chối")) }
        }
    }

    @Test fun proxyServerDownIsReportedNotFaked() {
        val deadPort = ServerSocket(0).use { it.localPort }   // nothing listens here any more
        try { ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, lo, deadPort), timeoutMs = 2000).connect("127.0.0.1", 80); fail() }
        catch (e: ProxyException) { assertTrue(e.message!!.contains("Không kết nối được máy chủ proxy")) }
    }

    @Test fun httpConnectWorksAndSendsBasicAuth() {
        EchoServer().use { echo -> FakeHttpProxy().use { p ->
            roundTrip(ProxyConnector(ProxyEndpoint(ProxyProtocol.HTTP, lo, p.port, "u", "p")), echo.port)
            assertTrue(p.lastRequest.startsWith("CONNECT 127.0.0.1:${echo.port} HTTP/1.1"))
            assertTrue(p.lastRequest.contains("Proxy-Authorization: Basic dTpw"))   // base64("u:p")
        } }
    }

    @Test fun httpConnect407() {
        FakeHttpProxy(407).use { p ->
            try { ProxyConnector(ProxyEndpoint(ProxyProtocol.HTTP, lo, p.port)).connect("127.0.0.1", 9); fail() }
            catch (e: ProxyException) { assertTrue(e.message!!.contains("407")) }
        }
    }

    @Test fun probeMeasuresLatency() {
        EchoServer().use { echo -> FakeSocks5().use { p ->
            val ms = ProxyProbe.latencyMs(ProxyConnector(ProxyEndpoint(ProxyProtocol.SOCKS5, lo, p.port)), "127.0.0.1", echo.port)
            assertTrue(ms in 0..5000)
        } }
    }
}
