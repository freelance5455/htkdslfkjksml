package com.phuy.proxy.data

import com.phuy.proxy.net.ProxyProtocol

/** MAIN is the general connection; FFTH and FFMAX are two separately configured UI sections.
 *  They are only names until the target apps and their network compatibility are confirmed:
 *  no app-specific API or protocol is assumed. */
enum class ProfileId(val label: String) {
    MAIN("P.HUY"), FFTH("FFTH"), FFMAX("FFMAX")
}

data class ProxyProfile(
    val id: ProfileId,
    val host: String = "",
    val port: Int = 0,
    val protocol: ProxyProtocol = ProxyProtocol.SOCKS5,
    val username: String = "",
    val password: String = "",
    /** Optional Android package name. Empty = route the whole device through the proxy. */
    val targetPackage: String = "",
    val dnsServer: String = "1.1.1.1",
) {
    val isConfigured: Boolean get() = host.isNotBlank() && port in 1..65535
    val serverLabel: String get() = if (isConfigured) "${protocol.name.lowercase()}://$host:$port" else "Chưa cấu hình"
}

enum class ConnStatus { DISCONNECTED, CONNECTING, CONNECTED }

data class ConnState(
    val status: ConnStatus = ConnStatus.DISCONNECTED,
    val profile: ProfileId? = null,
    val server: String = "",
    val error: String? = null,
    val connectedAtMs: Long = 0L,
    val latencyMs: Long? = null,
    val txBytes: Long = 0L,
    val rxBytes: Long = 0L,
)
