package com.phuy.proxy.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Single source of truth for connection state, written only by PhuyVpnService. */
object ConnectionStore {
    private val _state = MutableStateFlow(ConnState())
    val state: StateFlow<ConnState> = _state.asStateFlow()

    fun set(s: ConnState) { _state.value = s }
    fun update(f: (ConnState) -> ConnState) = _state.update(f)
}
