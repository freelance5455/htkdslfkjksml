package com.phuy.proxy.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.phuy.proxy.MainActivity
import com.phuy.proxy.PhuyApp
import com.phuy.proxy.data.ConnStatus
import com.phuy.proxy.data.ConnectionStore
import com.phuy.proxy.data.ProfileId
import com.phuy.proxy.vpn.PhuyVpnService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Draggable P.HUY button drawn over other apps (SYSTEM_ALERT_WINDOW, granted by the user in
 * Android Settings). It only shows status and sends CONNECT / DISCONNECT to PhuyVpnService.
 * It never reads other apps' content and never injects input.
 */
class FloatingButtonService : Service() {

    private lateinit var wm: WindowManager
    private var button: TextView? = null
    private var panel: LinearLayout? = null
    private var statusView: TextView? = null
    private var btnLp: WindowManager.LayoutParams? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var observer: Job? = null
    private val size get() = dp(56)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (!Settings.canDrawOverlays(this)) {      // permission missing or revoked: do nothing
            stopSelf(); return START_NOT_STICKY
        }
        if (button == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            addButton()
            observer = scope.launch {
                ConnectionStore.state.collect { s ->
                    val (text, color) = when (s.status) {
                        ConnStatus.CONNECTED -> "CONNECTED" to Color.parseColor("#4ADE80")
                        ConnStatus.CONNECTING -> "CONNECTING..." to Color.parseColor("#FBBF24")
                        ConnStatus.DISCONNECTED -> (s.error ?: "DISCONNECTED") to Color.parseColor("#FF5C7A")
                    }
                    statusView?.text = text
                    statusView?.setTextColor(color)
                    (button?.background as? GradientDrawable)?.setStroke(dp(2),
                        if (s.status == ConnStatus.CONNECTED) Color.parseColor("#4ADE80") else Color.parseColor("#B45CFF"))
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotation: keep the button and panel fully on-screen in the new geometry.
        btnLp?.let { clamp(it); button?.let { v -> safeUpdate(v, it) } }
        if (panel != null) positionPanel()
    }

    override fun onDestroy() {
        observer?.cancel()
        scope.cancel()
        removeSafely(panel); removeSafely(button)
        panel = null; button = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ views

    private fun addButton() {
        val settings = PhuyApp.instance.settings
        val v = TextView(this).apply {
            text = "P"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            contentDescription = "Nút nổi P.HUY"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1A0B33"))
                setStroke(dp(2), Color.parseColor("#B45CFF"))
            }
            alpha = 0.92f
        }
        val lp = overlayParams(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = settings.floatX
            y = settings.floatY
        }
        clamp(lp)
        v.setOnTouchListener(DragListener(lp))
        wm.addView(v, lp)
        button = v; btnLp = lp
    }

    private inner class DragListener(private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f
        private var startX = 0; private var startY = 0
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        clamp(lp); safeUpdate(v, lp)
                        if (panel != null) positionPanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        PhuyApp.instance.settings.floatX = lp.x
                        PhuyApp.instance.settings.floatY = lp.y
                    } else {
                        v.performClick()
                        togglePanel()
                    }
                }
            }
            return true
        }
    }

    private fun togglePanel() { if (panel == null) showPanel() else hidePanel() }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#120A22"))
                setStroke(dp(1), Color.parseColor("#B45CFF"))
            }
        }
        val title = TextView(this).apply {
            text = "P.HUY PROXY"; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 14f
        }
        val st = TextView(this).apply { textSize = 13f; setPadding(0, dp(4), 0, dp(8)); maxWidth = dp(200) }
        statusView = st
        card.addView(title); card.addView(st)
        card.addView(actionButton("CONNECT") { connect() })
        card.addView(actionButton("DISCONNECT") { PhuyVpnService.disconnect(this) })
        card.addView(actionButton("ĐÓNG") { hidePanel() })

        val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.TOP or Gravity.START }
        panel = card; panelLp = lp
        wm.addView(card, lp)
        positionPanel()
        // Initialise status text immediately.
        val s = ConnectionStore.state.value
        st.text = when (s.status) {
            ConnStatus.CONNECTED -> "CONNECTED"
            ConnStatus.CONNECTING -> "CONNECTING..."
            ConnStatus.DISCONNECTED -> s.error ?: "DISCONNECTED"
        }
    }

    private fun hidePanel() {
        removeSafely(panel); panel = null; statusView = null
    }

    private fun actionButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        textSize = 13f
        minHeight = dp(44)                       // comfortable one-handed touch target
        minWidth = dp(150)
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#2A1259"))
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        layoutParams = lp
        setOnClickListener { onClick() }
    }

    /** Starts the VPN if the system VPN consent is already granted; otherwise opens the app to ask. */
    private fun connect() {
        if (VpnService.prepare(this) != null) {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_REQUEST_VPN, ProfileId.MAIN.name))
        } else {
            PhuyVpnService.connect(this, ProfileId.MAIN)
        }
    }

    /** Places the panel beside the button, flipping sides so it never leaves the screen. */
    private fun positionPanel() {
        val p = panel ?: return
        val lp = panelLp ?: return
        val b = btnLp ?: return
        p.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val (sw, sh) = screenSize()
        val pw = p.measuredWidth; val ph = p.measuredHeight
        lp.x = if (b.x + size + dp(8) + pw <= sw) b.x + size + dp(8) else (b.x - dp(8) - pw).coerceAtLeast(0)
        lp.y = b.y.coerceIn(0, (sh - ph).coerceAtLeast(0))
        safeUpdate(p, lp)
    }

    // ------------------------------------------------------------------ helpers

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT,
    )

    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds; b.width() to b.height()
        } else {
            @Suppress("DEPRECATION")
            val m = android.util.DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
            m.widthPixels to m.heightPixels
        }

    private fun clamp(lp: WindowManager.LayoutParams) {
        val (sw, sh) = screenSize()
        lp.x = lp.x.coerceIn(0, (sw - size).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (sh - size).coerceAtLeast(0))
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (_: IllegalArgumentException) {}
    }

    private fun removeSafely(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: IllegalArgumentException) {}
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Nút nổi", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("P.HUY nút nổi đang bật")
            .setContentText("Tắt trong Cài đặt của ứng dụng")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
    }

    companion object {
        private const val CHANNEL = "phuy_float"
        private const val NOTIF_ID = 78

        fun start(context: Context) { context.startForegroundService(Intent(context, FloatingButtonService::class.java)) }
        fun stop(context: Context) { context.stopService(Intent(context, FloatingButtonService::class.java)) }
    }
}
