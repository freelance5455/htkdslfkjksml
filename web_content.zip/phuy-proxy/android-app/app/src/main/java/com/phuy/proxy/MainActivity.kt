package com.phuy.proxy

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.phuy.proxy.data.ConnState
import com.phuy.proxy.data.ConnStatus
import com.phuy.proxy.data.ConnectionStore
import com.phuy.proxy.data.ProfileId
import com.phuy.proxy.overlay.FloatingButtonService
import com.phuy.proxy.ui.Actions
import com.phuy.proxy.ui.GetKeyScreen
import com.phuy.proxy.ui.HomeScreen
import com.phuy.proxy.ui.PhuyColors
import com.phuy.proxy.ui.PhuyTheme
import com.phuy.proxy.ui.ProfileScreen
import com.phuy.proxy.ui.Screen
import com.phuy.proxy.ui.SettingsScreen
import com.phuy.proxy.vpn.PhuyVpnService

class MainActivity : ComponentActivity(), Actions {

    private var screen: Screen by mutableStateOf(Screen.Home)
    private var pendingProfile: ProfileId = ProfileId.MAIN
    private var wantFloating = false

    private val vpnConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            PhuyVpnService.connect(this, pendingProfile)
        } else {
            // User declined the system VPN dialog: report it, never pretend to connect.
            ConnectionStore.set(ConnState(ConnStatus.DISCONNECTED, pendingProfile, "", "Bạn đã từ chối quyền VPN của hệ thống"))
        }
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            PhuyTheme {
                Box(Modifier.fillMaxSize().background(PhuyColors.Bg)) {
                    when (val s = screen) {
                        Screen.Home -> HomeScreen(this@MainActivity) { screen = it }
                        is Screen.Profile -> ProfileScreen(s.id) { screen = Screen.Home }
                        Screen.GetKey -> GetKeyScreen { screen = Screen.Home }
                        Screen.Settings -> SettingsScreen(this@MainActivity) { screen = Screen.Home }
                    }
                }
            }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val id = i?.getStringExtra(EXTRA_REQUEST_VPN) ?: return
        i.removeExtra(EXTRA_REQUEST_VPN)
        connect(runCatching { ProfileId.valueOf(id) }.getOrDefault(ProfileId.MAIN))
    }

    override fun onResume() {
        super.onResume()
        // Returned from Android's overlay-permission screen?
        if (wantFloating && Settings.canDrawOverlays(this)) {
            wantFloating = false
            PhuyApp.instance.settings.floatingEnabled = true
            FloatingButtonService.start(this)
        }
        // Honour the saved preference if the permission is still there.
        if (PhuyApp.instance.settings.floatingEnabled && !Settings.canDrawOverlays(this)) {
            PhuyApp.instance.settings.floatingEnabled = false     // permission was revoked in Settings
        }
    }

    // ---- Actions ---------------------------------------------------------------------

    override fun connect(id: ProfileId) {
        pendingProfile = id
        val intent = VpnService.prepare(this)
        if (intent != null) vpnConsent.launch(intent) else PhuyVpnService.connect(this, id)
    }

    override fun disconnect() = PhuyVpnService.disconnect(this)

    override fun floatingGranted(): Boolean = Settings.canDrawOverlays(this)

    override fun setFloating(enabled: Boolean) {
        val store = PhuyApp.instance.settings
        if (!enabled) {
            wantFloating = false
            store.floatingEnabled = false
            FloatingButtonService.stop(this)
            return
        }
        if (Settings.canDrawOverlays(this)) {
            store.floatingEnabled = true
            FloatingButtonService.start(this)
            return
        }
        // Explain why, then let the USER grant it in Android Settings. We cannot and do not grant it ourselves.
        AlertDialog.Builder(this)
            .setTitle("Cần quyền hiển thị trên ứng dụng khác")
            .setMessage("Nút nổi P.HUY được vẽ phía trên các ứng dụng khác nên Android yêu cầu quyền này. " +
                "Bấm \"Mở cài đặt\", bật quyền cho P.HUY PROXY rồi quay lại ứng dụng. " +
                "Nếu bạn từ chối, nút nổi sẽ không bật; các chức năng khác vẫn dùng bình thường.")
            .setPositiveButton("Mở cài đặt") { _, _ ->
                wantFloating = true
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Không") { _, _ -> wantFloating = false }
            .show()
    }

    companion object {
        const val EXTRA_REQUEST_VPN = "request_vpn_profile"
    }
}
