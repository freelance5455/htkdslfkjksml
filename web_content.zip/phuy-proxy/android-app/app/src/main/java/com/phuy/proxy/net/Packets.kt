package com.phuy.proxy.net

/** IPv4 / TCP / UDP packet helpers. Pure Kotlin, no Android dependency. */
object Proto {
    const val TCP = 6
    const val UDP = 17
}

object TcpFlags {
    const val FIN = 0x01
    const val SYN = 0x02
    const val RST = 0x04
    const val PSH = 0x08
    const val ACK = 0x10
}

object Checksum {
    fun sum(data: ByteArray, off: Int, len: Int, initial: Long = 0L): Long {
        var s = initial
        var i = off
        val end = off + len
        while (i + 1 < end) {
            s += (((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < end) s += ((data[i].toInt() and 0xFF) shl 8).toLong()
        return s
    }

    fun fold(sum: Long): Int {
        var s = sum
        while ((s shr 16) != 0L) s = (s and 0xFFFF) + (s shr 16)
        return (s.inv() and 0xFFFF).toInt()
    }

    /** Pseudo-header sum for TCP/UDP over IPv4. */
    fun pseudo(src: Int, dst: Int, proto: Int, l4Len: Int): Long {
        var s = 0L
        s += ((src ushr 16) and 0xFFFF).toLong() + (src and 0xFFFF).toLong()
        s += ((dst ushr 16) and 0xFFFF).toLong() + (dst and 0xFFFF).toLong()
        s += proto.toLong()
        s += l4Len.toLong()
        return s
    }
}

fun ByteArray.u8(i: Int): Int = this[i].toInt() and 0xFF
fun ByteArray.u16(i: Int): Int = (u8(i) shl 8) or u8(i + 1)
fun ByteArray.i32(i: Int): Int = (u8(i) shl 24) or (u8(i + 1) shl 16) or (u8(i + 2) shl 8) or u8(i + 3)
fun ByteArray.u32(i: Int): Long = i32(i).toLong() and 0xFFFFFFFFL
fun ByteArray.put16(i: Int, v: Int) { this[i] = (v ushr 8).toByte(); this[i + 1] = v.toByte() }
fun ByteArray.put32(i: Int, v: Int) {
    this[i] = (v ushr 24).toByte(); this[i + 1] = (v ushr 16).toByte()
    this[i + 2] = (v ushr 8).toByte(); this[i + 3] = v.toByte()
}

fun ipToString(ip: Int): String = "${(ip ushr 24) and 0xFF}.${(ip ushr 16) and 0xFF}.${(ip ushr 8) and 0xFF}.${ip and 0xFF}"

/** TCP sequence arithmetic with 32-bit wrap-around. */
object Seq {
    const val MASK = 0xFFFFFFFFL
    fun add(a: Long, n: Int): Long = (a + n) and MASK
    /** Signed distance a - b, correct across wrap-around. */
    fun diff(a: Long, b: Long): Int = (a - b).toInt()
}

/** A parsed view over an IPv4 packet held in [buf] (not copied). */
class Ipv4View(val buf: ByteArray, val len: Int) {
    val valid: Boolean
    val ihl: Int
    val protocol: Int
    val src: Int
    val dst: Int
    val totalLen: Int
    val fragmented: Boolean

    init {
        if (len < 20 || (buf.u8(0) shr 4) != 4) {
            valid = false; ihl = 0; protocol = 0; src = 0; dst = 0; totalLen = 0; fragmented = false
        } else {
            ihl = (buf.u8(0) and 0x0F) * 4
            totalLen = buf.u16(2)
            protocol = buf.u8(9)
            src = buf.i32(12)
            dst = buf.i32(16)
            val frag = buf.u16(6)
            fragmented = (frag and 0x3FFF) != 0   // MF flag or fragment offset
            valid = ihl >= 20 && totalLen <= len && totalLen >= ihl
        }
    }

    val l4Off: Int get() = ihl
    val l4Len: Int get() = totalLen - ihl
}

class TcpView(val ip: Ipv4View) {
    private val b = ip.buf
    private val o = ip.l4Off
    val valid: Boolean = ip.l4Len >= 20 && (ip.l4Len >= ((ip.buf.u8(ip.l4Off + 12) shr 4) * 4)) && ((ip.buf.u8(ip.l4Off + 12) shr 4) * 4) >= 20
    val srcPort: Int get() = b.u16(o)
    val dstPort: Int get() = b.u16(o + 2)
    val seq: Long get() = b.u32(o + 4)
    val ack: Long get() = b.u32(o + 8)
    val headerLen: Int get() = (b.u8(o + 12) shr 4) * 4
    val flags: Int get() = b.u8(o + 13)
    val window: Int get() = b.u16(o + 14)
    val payloadOff: Int get() = o + headerLen
    val payloadLen: Int get() = ip.l4Len - headerLen
}

class UdpView(val ip: Ipv4View) {
    private val b = ip.buf
    private val o = ip.l4Off
    val valid: Boolean = ip.l4Len >= 8
    val srcPort: Int get() = b.u16(o)
    val dstPort: Int get() = b.u16(o + 2)
    val payloadOff: Int get() = o + 8
    val payloadLen: Int get() = minOf(b.u16(o + 4), ip.l4Len) - 8
}

object PacketBuilder {
    private var ipId = 0

    private fun writeIpHeader(p: ByteArray, total: Int, proto: Int, src: Int, dst: Int) {
        p[0] = 0x45.toByte()
        p[1] = 0
        p.put16(2, total)
        synchronized(this) { ipId = (ipId + 1) and 0xFFFF; p.put16(4, ipId) }
        p.put16(6, 0x4000)            // Don't Fragment
        p[8] = 64                      // TTL
        p[9] = proto.toByte()
        p.put16(10, 0)
        p.put32(12, src)
        p.put32(16, dst)
        p.put16(10, Checksum.fold(Checksum.sum(p, 0, 20)))
    }

    /** Builds a TCP segment wrapped in IPv4. If [mss] > 0 an MSS option is added (use on SYN/SYN-ACK). */
    fun tcp(
        src: Int, dst: Int, srcPort: Int, dstPort: Int,
        seq: Long, ack: Long, flags: Int, window: Int,
        payload: ByteArray?, payloadOff: Int = 0, payloadLen: Int = 0, mss: Int = 0,
    ): ByteArray {
        val opt = if (mss > 0) 4 else 0
        val tcpLen = 20 + opt + payloadLen
        val total = 20 + tcpLen
        val p = ByteArray(total)
        writeIpHeader(p, total, Proto.TCP, src, dst)
        val o = 20
        p.put16(o, srcPort)
        p.put16(o + 2, dstPort)
        p.put32(o + 4, seq.toInt())
        p.put32(o + 8, ack.toInt())
        p[o + 12] = (((20 + opt) / 4) shl 4).toByte()
        p[o + 13] = flags.toByte()
        p.put16(o + 14, window.coerceIn(0, 0xFFFF))
        if (mss > 0) {
            p[o + 20] = 2; p[o + 21] = 4; p.put16(o + 22, mss)
        }
        if (payloadLen > 0 && payload != null) System.arraycopy(payload, payloadOff, p, o + 20 + opt, payloadLen)
        val s = Checksum.sum(p, o, tcpLen, Checksum.pseudo(src, dst, Proto.TCP, tcpLen))
        p.put16(o + 16, Checksum.fold(s))
        return p
    }

    fun udp(src: Int, dst: Int, srcPort: Int, dstPort: Int, payload: ByteArray, off: Int, len: Int): ByteArray {
        val udpLen = 8 + len
        val total = 20 + udpLen
        val p = ByteArray(total)
        writeIpHeader(p, total, Proto.UDP, src, dst)
        val o = 20
        p.put16(o, srcPort)
        p.put16(o + 2, dstPort)
        p.put16(o + 4, udpLen)
        System.arraycopy(payload, off, p, o + 8, len)
        var c = Checksum.fold(Checksum.sum(p, o, udpLen, Checksum.pseudo(src, dst, Proto.UDP, udpLen)))
        if (c == 0) c = 0xFFFF
        p.put16(o + 6, c)
        return p
    }
}
