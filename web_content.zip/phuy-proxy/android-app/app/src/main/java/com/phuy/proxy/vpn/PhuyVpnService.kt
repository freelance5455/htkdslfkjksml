package com.phuy.proxy.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import com.phuy.proxy.MainActivity
import com.phuy.proxy.PhuyApp
import com.phuy.proxy.api.KeyCheck
import com.phuy.proxy.data.ConnState
import com.phuy.proxy.data.ConnStatus
import com.phuy.proxy.data.ConnectionStore
import com.phuy.proxy.data.ProfileId
import com.phuy.proxy.net.ProxyConnector
import com.phuy.proxy.net.ProxyEndpoint
import com.phuy.proxy.net.ProxyProbe
import com.phuy.proxy.net.TunForwarder
import com.phuy.proxy.net.TunIO
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetAddress

/**
 * Real VPN: the TUN device is read by [TunForwarder], which relays every TCP connection (and DNS)
 * through the configured SOCKS5 / HTTP CONNECT proxy. The state only becomes CONNECTED after
 * (1) the key was validated server-side, (2) the proxy answered a real handshake, and
 * (3) the VPN interface was established.
 *
 * Log policy: only state transitions and error classes are logged; never traffic, credentials or keys.
 */
class PhuyVpnService : VpnService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var tunFd: ParcelFileDescriptor? = null
    private var forwarder: TunForwarder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> { disconnect(null); stopSelf() }
            ACTION_CONNECT -> {
                val id = runCatching { ProfileId.valueOf(intent.getStringExtra(EXTRA_PROFILE) ?: "") }
                    .getOrDefault(ProfileId.MAIN)
                startForegroundCompat("Đang kết nối...")
                job?.cancel()
                job = scope.launch { connect(id) }
            }
        }
        return START_NOT_STICKY
    }

    /** User switched the VPN off (or another VPN took over) from Android settings. */
    override fun onRevoke() {
        disconnect("VPN đã bị tắt từ hệ thống")
        stopSelf()
    }

    override fun onDestroy() {
        disconnect(null)
        scope.cancel()
        super.onDestroy()
    }

    // ----------------------------------------------------------------------------------

    private suspend fun connect(id: ProfileId) {
        val app = PhuyApp.instance
        val profile = app.settings.profile(id)
        publish(ConnState(ConnStatus.CONNECTING, id, profile.serverLabel))

        if (!profile.isConfigured) return fail(id, "Chưa cấu hình máy chủ proxy")

        // 1) licence key, checked by the server
        val key = app.settings.licenseKey
        if (key.isBlank()) return fail(id, "Chưa nhập key. Vào trang GetKey để lấy và nhập key.")
        when (val c = app.api.validateKey(key)) {
            is KeyCheck.Unavailable -> return fail(id, c.reason)
            is KeyCheck.Ok -> if (!c.valid) return fail(id, "Key không dùng được (${c.status})")
        }

        // 2) resolve + really talk to the proxy BEFORE the VPN exists (uses the normal network)
        val addr = try {
            withContext(Dispatchers.IO) { InetAddress.getByName(profile.host) }
        } catch (e: IOException) {
            return fail(id, "Không phân giải được địa chỉ máy chủ proxy (kiểm tra mạng và DNS)")
        }
        val endpoint = ProxyEndpoint(profile.protocol, addr, profile.port, profile.username, profile.password)
        val latency = try {
            ProxyProbe.latencyMs(ProxyConnector(endpoint), profile.dnsServer, 53)
        } catch (e: IOException) {
            return fail(id, e.message ?: "Máy chủ proxy không hoạt động")
        }

        // 3) establish the VPN interface
        val builder = Builder()
            .setSession("P.HUY PROXY")
            .setMtu(1500)
            .addAddress("10.77.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(profile.dnsServer)
            // IPv6 is captured and dropped so it cannot leak around the proxy.
            .addAddress("fd77:77:77::2", 128)
            .addRoute("::", 0)
        try {
            if (profile.targetPackage.isNotBlank()) builder.addAllowedApplication(profile.targetPackage)
            else builder.addDisallowedApplication(packageName)   // our own API calls stay outside the tunnel
        } catch (e: PackageManager.NameNotFoundException) {
            return fail(id, "Không tìm thấy ứng dụng đích: ${profile.targetPackage}")
        }
        val fd = try { builder.establish() } catch (e: Exception) { null }
            ?: return fail(id, "Không tạo được VPN (quyền VPN chưa được cấp hoặc đã bị thu hồi)")
        tunFd = fd

        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val io = object : TunIO {
            override fun read(buf: ByteArray): Int = try { input.read(buf) } catch (e: IOException) { -1 }
            override fun write(buf: ByteArray, off: Int, len: Int) { output.write(buf, off, len) }
        }
        val connector = ProxyConnector(endpoint, protect = { s -> protect(s) })
        val fwd = TunForwarder(io, connector)
        forwarder = fwd
        fwd.start()

        val startedAt = System.currentTimeMillis()
        publish(ConnState(ConnStatus.CONNECTED, id, endpoint.display, null, startedAt, latency))
        updateNotification("Đã kết nối · ${profile.serverLabel}")
        Log.i(TAG, "connected profile=${id.name}")

        monitor(id, endpoint, fwd, startedAt, latency)
    }

    /** Updates stats and ends the session if the proxy dies or the key stops being valid. */
    private suspend fun monitor(id: ProfileId, endpoint: ProxyEndpoint, fwd: TunForwarder, startedAt: Long, latency: Long) {
        val app = PhuyApp.instance
        var sinceKeyCheck = 0
        while (scope.isActive) {
            delay(1000)
            if (forwarder !== fwd) return
            ConnectionStore.update { it.copy(txBytes = fwd.txBytes.get(), rxBytes = fwd.rxBytes.get()) }

            if (fwd.consecutiveUpstreamFailures.get() >= 5) {
                disconnect("Mất kết nối tới máy chủ proxy hoặc mất mạng: ${fwd.lastError ?: "không rõ lỗi"}")
                stopSelf(); return
            }
            sinceKeyCheck++
            if (sinceKeyCheck >= 300) {                       // every 5 minutes
                sinceKeyCheck = 0
                val c = app.api.validateKey(app.settings.licenseKey)
                if (c is KeyCheck.Ok && !c.valid) {
                    disconnect("Key đã hết hạn hoặc bị thu hồi (${c.status})")
                    stopSelf(); return
                }
                // KeyCheck.Unavailable: keep the tunnel up; a backend outage must not drop users.
            }
        }
    }

    private fun fail(id: ProfileId, message: String) {
        Log.w(TAG, "connect failed profile=${id.name}")
        publish(ConnState(ConnStatus.DISCONNECTED, id, "", message))
        disconnect(message)
        stopSelf()
    }

    private fun disconnect(error: String?) {
        job?.cancel()
        forwarder?.stop(); forwarder = null
        try { tunFd?.close() } catch (_: IOException) {}
        tunFd = null
        val prev = ConnectionStore.state.value
        ConnectionStore.set(ConnState(ConnStatus.DISCONNECTED, prev.profile, "", error ?: prev.error.takeIf { prev.status == ConnStatus.DISCONNECTED }))
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun publish(s: ConnState) = ConnectionStore.set(s)

    // ---- notification -------------------------------------------------------------------

    private fun startForegroundCompat(text: String) {
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Trạng thái kết nối", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, PhuyVpnService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("P.HUY PROXY")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Ngắt kết nối", stop).build())
            .build()
    }

    companion object {
        private const val TAG = "PhuyVpn"
        private const val CHANNEL = "phuy_vpn"
        private const val NOTIF_ID = 77
        const val ACTION_CONNECT = "com.phuy.proxy.CONNECT"
        const val ACTION_DISCONNECT = "com.phuy.proxy.DISCONNECT"
        const val EXTRA_PROFILE = "profile"

        fun connect(context: Context, id: ProfileId) {
            val i = Intent(context, PhuyVpnService::class.java).setAction(ACTION_CONNECT).putExtra(EXTRA_PROFILE, id.name)
            context.startForegroundService(i)
        }

        fun disconnect(context: Context) {
            context.startService(Intent(context, PhuyVpnService::class.java).setAction(ACTION_DISCONNECT))
        }
    }
}
