package com.phuy.proxy.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.phuy.proxy.net.ProxyProtocol

/**
 * Plain prefs: non-secret UI settings. Encrypted prefs (Android Keystore): the license key,
 * proxy username and password. Nothing sensitive is compiled into the APK.
 */
class SettingsStore(private val context: Context) {
    private val plain: SharedPreferences = context.getSharedPreferences("phuy_settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences by lazy { openSecure() }

    private fun openSecure(): SharedPreferences {
        fun create(): SharedPreferences {
            val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, "phuy_secure", master,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        }
        return try {
            create()
        } catch (e: Exception) {
            // Keystore invalidated (e.g. restored device): start clean rather than crash.
            context.deleteSharedPreferences("phuy_secure")
            create()
        }
    }

    // ---- backend + key -------------------------------------------------------------
    var backendUrl: String
        get() = plain.getString("backend_url", "") ?: ""
        set(v) = plain.edit().putString("backend_url", v.trim().trimEnd('/')).apply()

    var licenseKey: String
        get() = secure.getString("license_key", "") ?: ""
        set(v) = secure.edit().putString("license_key", v.trim()).apply()

    // ---- floating button -------------------------------------------------------------
    var floatingEnabled: Boolean
        get() = plain.getBoolean("floating_enabled", false)
        set(v) = plain.edit().putBoolean("floating_enabled", v).apply()

    var floatX: Int
        get() = plain.getInt("float_x", 0)
        set(v) = plain.edit().putInt("float_x", v).apply()

    var floatY: Int
        get() = plain.getInt("float_y", 300)
        set(v) = plain.edit().putInt("float_y", v).apply()

    // ---- proxy profiles -------------------------------------------------------------
    fun profile(id: ProfileId): ProxyProfile {
        val p = "p_${id.name}_"
        return ProxyProfile(
            id = id,
            host = plain.getString(p + "host", "") ?: "",
            port = plain.getInt(p + "port", 0),
            protocol = runCatching { ProxyProtocol.valueOf(plain.getString(p + "proto", "SOCKS5")!!) }
                .getOrDefault(ProxyProtocol.SOCKS5),
            username = secure.getString(p + "user", "") ?: "",
            password = secure.getString(p + "pass", "") ?: "",
            targetPackage = plain.getString(p + "pkg", "") ?: "",
            dnsServer = plain.getString(p + "dns", "1.1.1.1") ?: "1.1.1.1",
        )
    }

    fun saveProfile(pr: ProxyProfile) {
        val p = "p_${pr.id.name}_"
        plain.edit()
            .putString(p + "host", pr.host.trim())
            .putInt(p + "port", pr.port)
            .putString(p + "proto", pr.protocol.name)
            .putString(p + "pkg", pr.targetPackage.trim())
            .putString(p + "dns", pr.dnsServer.trim())
            .apply()
        secure.edit().putString(p + "user", pr.username).putString(p + "pass", pr.password).apply()
    }
}
