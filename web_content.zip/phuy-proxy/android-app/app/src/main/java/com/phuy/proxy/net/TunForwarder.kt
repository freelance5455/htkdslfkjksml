package com.phuy.proxy.net

import java.io.IOException
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

interface TunIO {
    /** Blocking read of one IP packet; returns length, or -1 when the interface is closed. */
    fun read(buf: ByteArray): Int
    fun write(buf: ByteArray, off: Int, len: Int)
}

/**
 * Minimal user-space "tun2proxy": terminates TCP connections coming out of the TUN device and
 * relays each one through an [UpstreamConnector] (SOCKS5 / HTTP CONNECT). DNS queries (UDP/53)
 * are resolved over TCP through the same proxy.
 *
 * Supported: IPv4 TCP, IPv4 UDP port 53.
 * NOT supported (dropped): IPv6, ICMP, other UDP (including game UDP traffic), IP fragments.
 * Limitations: no TCP retransmission buffer (the TUN link is local and lossless; flow control
 * honours the client's advertised window), TCP window-scale option is ignored (conservative).
 */
class TunForwarder(
    private val tun: TunIO,
    private val upstream: UpstreamConnector,
    private val idleTimeoutMs: Long = 5 * 60_000L,
) {
    private enum class St { CONNECTING, ESTABLISHED, CLOSED }

    private data class Key(val cIp: Int, val cPort: Int, val dIp: Int, val dPort: Int)

    private class Session(val key: Key, @Volatile var clientNext: Long, @Volatile var serverSeq: Long) {
        @Volatile var state = St.CONNECTING
        @Volatile var clientAck: Long = serverSeq
        @Volatile var clientWindow: Int = 65535
        @Volatile var lastActive = System.currentTimeMillis()
        @Volatile var socket: Socket? = null
        @Volatile var serverFinSent = false
        @Volatile var clientFinSeen = false
        val outQueue = LinkedBlockingQueue<ByteArray>()
        val lock = Object()
    }

    private val sessions = ConcurrentHashMap<Key, Session>()
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "phuy-fwd").apply { isDaemon = true } }
    private val timer: ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "phuy-gc").apply { isDaemon = true } }
    private val tunWriteLock = Any()

    @Volatile private var running = false
    val txBytes = AtomicLong()               // device -> proxy
    val rxBytes = AtomicLong()               // proxy -> device
    val droppedPackets = AtomicLong()
    val consecutiveUpstreamFailures = AtomicInteger()
    val upstreamSuccesses = AtomicLong()
    @Volatile var lastError: String? = null
        private set

    fun start() {
        running = true
        pool.execute { readLoop() }
        timer.scheduleWithFixedDelay({ sweep() }, 30, 30, TimeUnit.SECONDS)
    }

    fun stop() {
        running = false
        timer.shutdownNow()
        for (s in sessions.values) closeSession(s)
        sessions.clear()
        pool.shutdownNow()
    }

    val activeSessions: Int get() = sessions.size

    // ------------------------------------------------------------------ TUN -> proxy

    private fun readLoop() {
        val buf = ByteArray(65535)
        while (running) {
            val n = try { tun.read(buf) } catch (e: IOException) { -1 }
            if (n < 0) break
            if (n == 0) continue
            try { handlePacket(buf, n) } catch (e: Exception) { droppedPackets.incrementAndGet() }
        }
    }

    internal fun handlePacket(buf: ByteArray, n: Int) {
        val ip = Ipv4View(buf, n)
        if (!ip.valid || ip.fragmented) { droppedPackets.incrementAndGet(); return }
        when (ip.protocol) {
            Proto.TCP -> handleTcp(ip)
            Proto.UDP -> handleUdp(ip)
            else -> droppedPackets.incrementAndGet()
        }
    }

    private fun handleTcp(ip: Ipv4View) {
        val t = TcpView(ip)
        if (!t.valid) { droppedPackets.incrementAndGet(); return }
        val key = Key(ip.src, t.srcPort, ip.dst, t.dstPort)
        val flags = t.flags

        if ((flags and TcpFlags.SYN) != 0 && (flags and TcpFlags.ACK) == 0) {
            if (sessions.containsKey(key)) return           // retransmitted SYN
            val s = Session(key, Seq.add(t.seq, 1), Random.nextLong(0, Seq.MASK))
            s.clientWindow = t.window
            sessions[key] = s
            pool.execute { connectUpstream(s) }
            return
        }

        val s = sessions[key]
        if (s == null) {
            if ((flags and TcpFlags.RST) == 0 && t.payloadLen > 0) sendRstFor(ip, t)
            return
        }
        s.lastActive = System.currentTimeMillis()
        if ((flags and TcpFlags.RST) != 0) { closeSession(s); sessions.remove(key); return }
        if (s.state != St.ESTABLISHED) return

        s.clientWindow = t.window
        if ((flags and TcpFlags.ACK) != 0 && Seq.diff(t.ack, s.clientAck) > 0) s.clientAck = t.ack

        val len = t.payloadLen
        if (len > 0) {
            val d = Seq.diff(t.seq, s.clientNext)
            if (d == 0) {
                val copy = ByteArray(len)
                System.arraycopy(ip.buf, t.payloadOff, copy, 0, len)
                s.clientNext = Seq.add(s.clientNext, len)
                s.outQueue.offer(copy)
                txBytes.addAndGet(len.toLong())
            }
            // In-order, duplicate or out-of-order: always (re)state what we expect next.
            sendTcp(s, TcpFlags.ACK, null, 0, 0)
        }
        if ((flags and TcpFlags.FIN) != 0 && Seq.diff(Seq.add(t.seq, maxOf(len, 0)), s.clientNext) == 0 && !s.clientFinSeen) {
            s.clientFinSeen = true
            s.clientNext = Seq.add(s.clientNext, 1)
            sendTcp(s, TcpFlags.ACK, null, 0, 0)
            s.outQueue.offer(FIN_MARK)
        }
        synchronized(s.lock) { s.lock.notifyAll() }
        if (s.clientFinSeen && s.serverFinSent) scheduleRemoval(s)
    }

    private fun connectUpstream(s: Session) {
        val k = s.key
        val sock: Socket
        try {
            sock = upstream.connect(ipToString(k.dIp), k.dPort)
        } catch (e: Exception) {
            lastError = e.message
            consecutiveUpstreamFailures.incrementAndGet()
            // RST|ACK in reply to SYN
            val rst = PacketBuilder.tcp(k.dIp, k.cIp, k.dPort, k.cPort, 0, s.clientNext,
                TcpFlags.RST or TcpFlags.ACK, 0, null)
            writeTun(rst)
            sessions.remove(k)
            return
        }
        consecutiveUpstreamFailures.set(0)
        upstreamSuccesses.incrementAndGet()
        if (!running) { try { sock.close() } catch (_: IOException) {}; return }
        s.socket = sock

        // SYN-ACK completes the client's handshake.
        val synAck = PacketBuilder.tcp(k.dIp, k.cIp, k.dPort, k.cPort, s.serverSeq, s.clientNext,
            TcpFlags.SYN or TcpFlags.ACK, 65535, null, mss = MSS)
        s.serverSeq = Seq.add(s.serverSeq, 1)
        s.clientAck = s.serverSeq
        s.state = St.ESTABLISHED
        writeTun(synAck)

        pool.execute { writerLoop(s, sock) }
        readerLoop(s, sock)
    }

    private fun writerLoop(s: Session, sock: Socket) {
        try {
            val out = sock.getOutputStream()
            while (s.state != St.CLOSED) {
                val chunk = s.outQueue.poll(1, TimeUnit.SECONDS) ?: continue
                if (chunk === FIN_MARK) {
                    try { sock.shutdownOutput() } catch (_: IOException) {}
                    return
                }
                out.write(chunk)
                out.flush()
            }
        } catch (e: Exception) {
            abort(s)
        }
    }

    // ------------------------------------------------------------------ proxy -> TUN

    private fun readerLoop(s: Session, sock: Socket) {
        val buf = ByteArray(MSS)
        try {
            val inp = sock.getInputStream()
            while (s.state != St.CLOSED) {
                val n = inp.read(buf)
                if (n < 0) break
                if (!waitForWindow(s, n)) { abort(s); return }
                sendTcp(s, TcpFlags.ACK or TcpFlags.PSH, buf, 0, n)
                s.serverSeq = Seq.add(s.serverSeq, n)
                rxBytes.addAndGet(n.toLong())
                s.lastActive = System.currentTimeMillis()
            }
            if (s.state != St.CLOSED) {
                sendTcp(s, TcpFlags.ACK or TcpFlags.FIN, null, 0, 0)
                s.serverSeq = Seq.add(s.serverSeq, 1)
                s.serverFinSent = true
                if (s.clientFinSeen) scheduleRemoval(s)
            }
        } catch (e: Exception) {
            abort(s)
        }
    }

    /** Blocks until sending [n] more bytes stays inside the client's receive window. */
    private fun waitForWindow(s: Session, n: Int): Boolean {
        val deadline = System.currentTimeMillis() + 60_000
        while (s.state != St.CLOSED) {
            val inflight = Seq.diff(s.serverSeq, s.clientAck)
            val win = if (s.clientWindow <= 0) 1 else s.clientWindow
            if (inflight + n <= win) return true
            if (System.currentTimeMillis() > deadline) return false
            synchronized(s.lock) { s.lock.wait(100) }
        }
        return false
    }

    // ------------------------------------------------------------------ UDP / DNS

    private fun handleUdp(ip: Ipv4View) {
        val u = UdpView(ip)
        if (!u.valid || u.dstPort != 53 || u.payloadLen <= 0 || u.payloadLen > 4096) {
            droppedPackets.incrementAndGet(); return
        }
        val query = ByteArray(u.payloadLen)
        System.arraycopy(ip.buf, u.payloadOff, query, 0, query.size)
        val cIp = ip.src; val cPort = u.srcPort; val dIp = ip.dst
        pool.execute {
            try {
                val sock = upstream.connect(ipToString(dIp), 53)
                try {
                    sock.soTimeout = 5000
                    val out = sock.getOutputStream()
                    out.write(byteArrayOf((query.size ushr 8).toByte(), query.size.toByte()))
                    out.write(query); out.flush()
                    val inp = sock.getInputStream()
                    val hdr = readN(inp, 2)
                    val rlen = ((hdr[0].toInt() and 0xFF) shl 8) or (hdr[1].toInt() and 0xFF)
                    val resp = readN(inp, rlen)
                    writeTun(PacketBuilder.udp(dIp, cIp, 53, cPort, resp, 0, resp.size))
                    consecutiveUpstreamFailures.set(0)
                } finally {
                    try { sock.close() } catch (_: IOException) {}
                }
            } catch (e: Exception) {
                lastError = e.message
                consecutiveUpstreamFailures.incrementAndGet()
            }
        }
    }

    private fun readN(inp: java.io.InputStream, n: Int): ByteArray {
        val b = ByteArray(n)
        var r = 0
        while (r < n) {
            val k = inp.read(b, r, n - r)
            if (k < 0) throw IOException("DNS: kết nối đóng sớm")
            r += k
        }
        return b
    }

    // ------------------------------------------------------------------ helpers

    private fun sendTcp(s: Session, flags: Int, data: ByteArray?, off: Int, len: Int) {
        val k = s.key
        val p = PacketBuilder.tcp(k.dIp, k.cIp, k.dPort, k.cPort, s.serverSeq, s.clientNext,
            flags, 65535, data, off, len)
        writeTun(p)
    }

    private fun sendRstFor(ip: Ipv4View, t: TcpView) {
        val ackNum = Seq.add(t.seq, t.payloadLen)
        writeTun(PacketBuilder.tcp(ip.dst, ip.src, t.dstPort, t.srcPort, t.ack, ackNum,
            TcpFlags.RST or TcpFlags.ACK, 0, null))
    }

    private fun writeTun(p: ByteArray) {
        synchronized(tunWriteLock) {
            try { tun.write(p, 0, p.size) } catch (_: IOException) {}
        }
    }

    private fun abort(s: Session) {
        if (s.state == St.CLOSED) return
        val k = s.key
        writeTun(PacketBuilder.tcp(k.dIp, k.cIp, k.dPort, k.cPort, s.serverSeq, s.clientNext,
            TcpFlags.RST or TcpFlags.ACK, 0, null))
        closeSession(s)
        sessions.remove(k)
    }

    private fun closeSession(s: Session) {
        s.state = St.CLOSED
        try { s.socket?.close() } catch (_: IOException) {}
        synchronized(s.lock) { s.lock.notifyAll() }
    }

    private fun scheduleRemoval(s: Session) {
        if (timer.isShutdown) return
        timer.schedule({ closeSession(s); sessions.remove(s.key) }, 10, TimeUnit.SECONDS)
    }

    private fun sweep() {
        val now = System.currentTimeMillis()
        for (s in sessions.values) {
            if (now - s.lastActive > idleTimeoutMs) abort(s)
        }
    }

    companion object {
        const val MSS = 1360
        private val FIN_MARK = ByteArray(0)
    }
}
