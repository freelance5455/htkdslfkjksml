package com.phuy.proxy.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.phuy.proxy.PhuyApp
import com.phuy.proxy.api.KeyCheck
import com.phuy.proxy.data.ConnState
import com.phuy.proxy.data.ConnStatus
import com.phuy.proxy.data.ConnectionStore
import com.phuy.proxy.data.ProfileId
import com.phuy.proxy.data.ProxyProfile
import com.phuy.proxy.net.ProxyConnector
import com.phuy.proxy.net.ProxyEndpoint
import com.phuy.proxy.net.ProxyProbe
import com.phuy.proxy.net.ProxyProtocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

sealed class Screen {
    object Home : Screen()
    data class Profile(val id: ProfileId) : Screen()
    object GetKey : Screen()
    object Settings : Screen()
}

interface Actions {
    fun connect(id: ProfileId)
    fun disconnect()
    fun setFloating(enabled: Boolean)
    fun floatingGranted(): Boolean
}

@Composable
private fun Page(title: String, onBack: (() -> Unit)?, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (onBack != null) BigButton("← QUAY LẠI", filled = false, onClick = onBack)
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        content()
        Spacer(Modifier.height(24.dp))
    }
}

private fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

private fun fmtBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
    else -> "%.1f MB".format(b / 1048576.0)
}

private suspend fun probeProfile(p: ProxyProfile): String = withContext(Dispatchers.IO) {
    if (!p.isConfigured) return@withContext "Chưa cấu hình máy chủ proxy"
    try {
        val addr = InetAddress.getByName(p.host)
        val ep = ProxyEndpoint(p.protocol, addr, p.port, p.username, p.password)
        val ms = ProxyProbe.latencyMs(ProxyConnector(ep), p.dnsServer, 53)
        "OK · độ trễ qua proxy: $ms ms"
    } catch (e: Exception) {
        "Lỗi: ${e.message ?: e.javaClass.simpleName}"
    }
}

// ============================================================================ HOME

@Composable
fun HomeScreen(actions: Actions, go: (Screen) -> Unit) {
    val state by ConnectionStore.state.collectAsStateWithLifecycle()
    val settings = PhuyApp.instance.settings
    val scope = rememberCoroutineScope()
    var checkMsg by remember { mutableStateOf("") }
    var checking by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.status) { while (state.status == ConnStatus.CONNECTED) { now = System.currentTimeMillis(); delay(1000) } }

    Page("P.HUY PROXY", null) {
        // main status
        NeonCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val (label, color) = when (state.status) {
                    ConnStatus.CONNECTED -> "CONNECTED" to PhuyColors.Ok
                    ConnStatus.CONNECTING -> "CONNECTING..." to PhuyColors.Warn
                    ConnStatus.DISCONNECTED -> "DISCONNECTED" to PhuyColors.Bad
                }
                Text(label, color = color, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                val server = if (state.status == ConnStatus.DISCONNECTED) settings.profile(ProfileId.MAIN).serverLabel else state.server
                Text("Máy chủ: $server", color = PhuyColors.Muted, fontSize = 13.sp)
                state.error?.let { Text(it, color = PhuyColors.Bad, fontSize = 13.sp) }
                if (state.status == ConnStatus.CONNECTED) {
                    Text("Thời gian: ${fmtDuration(now - state.connectedAtMs)}", fontSize = 14.sp)
                    Text("Độ trễ đo được: ${state.latencyMs ?: "-"} ms", fontSize = 14.sp)
                    Text("↑ ${fmtBytes(state.txBytes)}   ↓ ${fmtBytes(state.rxBytes)}", fontSize = 14.sp)
                }
            }
        }
        BigButton("CONNECT", enabled = state.status == ConnStatus.DISCONNECTED, onClick = { actions.connect(ProfileId.MAIN) })
        BigButton("DISCONNECT", enabled = state.status != ConnStatus.DISCONNECTED, filled = false, onClick = { actions.disconnect() })
        BigButton(if (checking) "ĐANG KIỂM TRA..." else "KIỂM TRA KẾT NỐI", enabled = !checking, filled = false, onClick = {
            checking = true; checkMsg = ""
            scope.launch { checkMsg = probeProfile(settings.profile(ProfileId.MAIN)); checking = false }
        })
        if (checkMsg.isNotEmpty()) Text(checkMsg, color = if (checkMsg.startsWith("OK")) PhuyColors.Ok else PhuyColors.Bad, fontSize = 13.sp)
        BigButton("CẤU HÌNH PROXY CHUNG", filled = false, onClick = { go(Screen.Profile(ProfileId.MAIN)) })

        ProfileCard(ProfileId.FFTH, state, actions, go)
        ProfileCard(ProfileId.FFMAX, state, actions, go)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("GETKEY", filled = false, onClick = { go(Screen.GetKey) }, modifier = Modifier.weight(1f))
            BigButton("CÀI ĐẶT", filled = false, onClick = { go(Screen.Settings) }, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun ProfileCard(id: ProfileId, state: ConnState, actions: Actions, go: (Screen) -> Unit) {
    val p = PhuyApp.instance.settings.profile(id)
    val mine = state.profile == id
    val st = if (mine) state.status else ConnStatus.DISCONNECTED
    NeonCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(id.label, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = PhuyColors.Neon)
                Text(st.name, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    color = when (st) { ConnStatus.CONNECTED -> PhuyColors.Ok; ConnStatus.CONNECTING -> PhuyColors.Warn; else -> PhuyColors.Bad })
            }
            Text(p.serverLabel, color = PhuyColors.Muted, fontSize = 13.sp)
            if (mine && state.error != null) Text(state.error, color = PhuyColors.Bad, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("CÀI ĐẶT $id", filled = false, onClick = { go(Screen.Profile(id)) }, modifier = Modifier.weight(1f))
                if (st == ConnStatus.DISCONNECTED)
                    BigButton("KẾT NỐI", enabled = state.status == ConnStatus.DISCONNECTED, onClick = { actions.connect(id) }, modifier = Modifier.weight(1f))
                else
                    BigButton("NGẮT", onClick = { actions.disconnect() }, modifier = Modifier.weight(1f))
            }
        }
    }
}

// ============================================================================ PROFILE SETTINGS

@Composable
fun ProfileScreen(id: ProfileId, back: () -> Unit) {
    val store = PhuyApp.instance.settings
    val initial = remember(id) { store.profile(id) }
    var host by remember { mutableStateOf(initial.host) }
    var port by remember { mutableStateOf(if (initial.port > 0) initial.port.toString() else "") }
    var proto by remember { mutableStateOf(initial.protocol) }
    var user by remember { mutableStateOf(initial.username) }
    var pass by remember { mutableStateOf(initial.password) }
    var pkg by remember { mutableStateOf(initial.targetPackage) }
    var dns by remember { mutableStateOf(initial.dnsServer) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun current() = ProxyProfile(id, host.trim(), port.toIntOrNull() ?: 0, proto, user, pass, pkg.trim(), dns.trim().ifBlank { "1.1.1.1" })

    Page("Cài đặt ${id.label}", back) {
        if (id != ProfileId.MAIN) Text(
            "${id.label} hiện chỉ là tên một mục giao diện. Ứng dụng không giả định API hay giao thức riêng của trò chơi; " +
                "nó chỉ chuyển tiếp lưu lượng TCP qua máy chủ proxy bạn nhập. Chưa có kết luận nào về ping hay hiệu suất.",
            color = PhuyColors.Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProxyProtocol.values().forEach { p ->
                FilterChip(selected = proto == p, onClick = { proto = p }, label = { Text(if (p == ProxyProtocol.SOCKS5) "SOCKS5" else "HTTP CONNECT") })
            }
        }
        OutlinedTextField(host, { host = it }, label = { Text("Địa chỉ máy chủ proxy") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, label = { Text("Cổng") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("Tài khoản (nếu có)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Mật khẩu (nếu có)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pkg, { pkg = it }, label = { Text("Package ứng dụng đích (để trống = cả thiết bị)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dns, { dns = it }, label = { Text("Máy chủ DNS (truy vấn đi qua proxy)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        BigButton("LƯU", onClick = {
            val c = current()
            msg = when {
                c.host.isBlank() -> "Nhập địa chỉ máy chủ proxy."
                c.port !in 1..65535 -> "Cổng phải từ 1 đến 65535."
                else -> { store.saveProfile(c); "Đã lưu." }
            }
        })
        BigButton(if (busy) "ĐANG KIỂM TRA..." else "KIỂM TRA MÁY CHỦ PROXY", enabled = !busy, filled = false, onClick = {
            busy = true; msg = ""
            scope.launch { msg = probeProfile(current()); busy = false }
        })
        if (msg.isNotEmpty()) Text(msg, color = if (msg.startsWith("Lỗi") || msg.startsWith("Nhập") || msg.startsWith("Cổng") || msg.startsWith("Chưa")) PhuyColors.Bad else PhuyColors.Ok, fontSize = 13.sp)
    }
}

// ============================================================================ GETKEY

@Composable
fun GetKeyScreen(back: () -> Unit) {
    val app = PhuyApp.instance
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(app.settings.licenseKey) }
    var msg by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Page("GetKey", back) {
        Text("1. Mở trang GetKey, bấm GET KEY và sao chép key.\n2. Dán key vào ô bên dưới.\n3. Bấm XÁC THỰC KEY. Key hợp lệ sẽ được lưu.",
            color = PhuyColors.Muted, fontSize = 13.sp)
        BigButton("MỞ TRANG GETKEY", filled = false, onClick = {
            val base = app.settings.backendUrl
            if (base.startsWith("https://")) ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(base)))
            else { ok = false; msg = "Chưa cấu hình địa chỉ máy chủ GetKey (HTTPS) trong Cài đặt." }
        })
        OutlinedTextField(key, { key = it.trim() }, label = { Text("Key (P.huy-...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        BigButton(if (busy) "ĐANG XÁC THỰC..." else "XÁC THỰC KEY", enabled = !busy && key.isNotBlank(), onClick = {
            busy = true; msg = ""
            scope.launch {
                when (val r = app.api.validateKey(key)) {
                    is KeyCheck.Unavailable -> { ok = false; msg = r.reason }
                    is KeyCheck.Ok -> if (r.valid) {
                        app.settings.licenseKey = key; ok = true
                        msg = "Key hợp lệ (${r.status}). Còn ${r.secondsLeft / 3600} giờ."
                    } else { ok = false; msg = "Key không dùng được: ${r.status}" }
                }
                busy = false
            }
        })
        if (msg.isNotEmpty()) Text(msg, color = if (ok) PhuyColors.Ok else PhuyColors.Bad, fontSize = 13.sp)
    }
}

// ============================================================================ SETTINGS

@Composable
fun SettingsScreen(actions: Actions, back: () -> Unit) {
    val store = PhuyApp.instance.settings
    var url by remember { mutableStateOf(store.backendUrl) }
    var msg by remember { mutableStateOf("") }
    var floating by remember { mutableStateOf(store.floatingEnabled && actions.floatingGranted()) }

    Page("Cài đặt", back) {
        OutlinedTextField(url, { url = it }, label = { Text("Địa chỉ máy chủ GetKey (https://...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        BigButton("LƯU ĐỊA CHỈ", onClick = {
            if (url.trim().startsWith("https://")) { store.backendUrl = url; msg = "Đã lưu." } else msg = "Địa chỉ phải bắt đầu bằng https://"
        })
        if (msg.isNotEmpty()) Text(msg, color = if (msg == "Đã lưu.") PhuyColors.Ok else PhuyColors.Bad, fontSize = 13.sp)

        NeonCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Nút nổi P.HUY", fontWeight = FontWeight.Bold)
                    Switch(checked = floating, onCheckedChange = { want -> actions.setFloating(want); floating = want && actions.floatingGranted() })
                }
                Text("Nút nổi cần quyền \"Hiển thị trên ứng dụng khác\". Ứng dụng không tự cấp quyền: bạn sẽ được đưa tới Cài đặt Android để tự bật. " +
                    "Nút chỉ hiển thị trạng thái và gửi lệnh CONNECT/DISCONNECT, không đọc nội dung hay thao tác thay bạn trong ứng dụng khác.",
                    color = PhuyColors.Muted, fontSize = 12.sp)
            }
        }
        NeonCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Quyền riêng tư", fontWeight = FontWeight.Bold)
                Text("• Lưu trên máy: key, cấu hình proxy (mật khẩu được mã hóa bằng Android Keystore).\n" +
                    "• Gửi tới máy chủ GetKey: chỉ chuỗi key để xác thực.\n" +
                    "• Lưu lượng TCP và truy vấn DNS của ứng dụng được chọn đi qua máy chủ proxy bạn nhập; chủ máy chủ đó có thể thấy địa chỉ đích. Chỉ dùng proxy bạn tin tưởng.\n" +
                    "• Không ghi nội dung lưu lượng, mật khẩu hay key vào log.",
                    color = PhuyColors.Muted, fontSize = 12.sp)
            }
        }
        NeonCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Giới hạn kỹ thuật", fontWeight = FontWeight.Bold)
                Text("• Chỉ chuyển tiếp IPv4 TCP và DNS. UDP khác (nhiều trò chơi dùng UDP), ICMP và IPv6 bị chặn, không đi qua proxy.\n" +
                    "• Android chỉ cho một VPN hoạt động tại một thời điểm.\n" +
                    "• Ứng dụng không cam kết giảm ping hay tăng hiệu suất; hãy tự đo.",
                    color = PhuyColors.Muted, fontSize = 12.sp)
            }
        }
    }
}
