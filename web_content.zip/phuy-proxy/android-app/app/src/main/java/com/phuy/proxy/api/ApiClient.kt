package com.phuy.proxy.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Result of asking the GETKEY backend about a key. */
sealed class KeyCheck {
    data class Ok(val valid: Boolean, val status: String, val secondsLeft: Long, val expiresAt: Long) : KeyCheck()
    /** The backend could not be reached or answered with an error. Says nothing about the key. */
    data class Unavailable(val reason: String) : KeyCheck()
}

class ApiClient(private val baseUrl: () -> String) {

    suspend fun validateKey(key: String): KeyCheck = withContext(Dispatchers.IO) {
        val base = baseUrl()
        if (base.isBlank()) return@withContext KeyCheck.Unavailable("Chưa cấu hình địa chỉ máy chủ GetKey")
        if (!base.startsWith("https://")) return@withContext KeyCheck.Unavailable("Địa chỉ máy chủ GetKey phải dùng HTTPS")
        try {
            val body = JSONObject().put("key", key).toString()
            val conn = (URL("$base/api/keys/validate").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            try {
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                if (code == 429) return@withContext KeyCheck.Unavailable("Quá nhiều yêu cầu, thử lại sau")
                if (code !in 200..299) return@withContext KeyCheck.Unavailable("Máy chủ GetKey trả về lỗi $code")
                val j = JSONObject(text)
                KeyCheck.Ok(
                    valid = j.optBoolean("valid", false),
                    status = j.optString("status", "INVALID"),
                    secondsLeft = j.optLong("seconds_left", 0),
                    expiresAt = j.optLong("expires_at", 0),
                )
            } finally {
                conn.disconnect()
            }
        } catch (e: IOException) {
            KeyCheck.Unavailable("Backend không khả dụng: ${e.message ?: e.javaClass.simpleName}")
        } catch (e: org.json.JSONException) {
            KeyCheck.Unavailable("Phản hồi từ máy chủ GetKey không hợp lệ")
        }
    }
}
