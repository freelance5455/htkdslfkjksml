package com.phuy.proxy.net

import java.io.IOException
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64

enum class ProxyProtocol { SOCKS5, HTTP }

/** Resolved upstream proxy. Credentials are held in memory only for the life of a connection. */
class ProxyEndpoint(
    val protocol: ProxyProtocol,
    val address: InetAddress,
    val port: Int,
    val username: String = "",
    val password: String = "",
) {
    val display: String get() = "${protocol.name.lowercase()}://${address.hostAddress}:$port"
}

class ProxyException(message: String, cause: Throwable? = null) : IOException(message, cause)

/** Opens a TCP tunnel to host:port through some upstream. */
fun interface UpstreamConnector {
    @Throws(IOException::class)
    fun connect(host: String, port: Int): Socket
}

/**
 * Connects to the proxy (via [protect] so the socket bypasses the VPN) and performs the
 * SOCKS5 or HTTP CONNECT handshake. The returned socket carries raw bytes to the target.
 */
class ProxyConnector(
    private val endpoint: ProxyEndpoint,
    private val timeoutMs: Int = 8000,
    private val protect: (Socket) -> Unit = {},
) : UpstreamConnector {

    override fun connect(host: String, port: Int): Socket {
        val s = Socket()
        try {
            protect(s)
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(endpoint.address, endpoint.port), timeoutMs)
            s.soTimeout = timeoutMs
            when (endpoint.protocol) {
                ProxyProtocol.SOCKS5 -> socks5(s, host, port)
                ProxyProtocol.HTTP -> httpConnect(s, host, port)
            }
            s.soTimeout = 0
            return s
        } catch (t: Throwable) {
            try { s.close() } catch (_: IOException) {}
            if (t is ProxyException) throw t
            throw ProxyException("Không kết nối được máy chủ proxy: ${t.message ?: t.javaClass.simpleName}", t)
        }
    }

    private fun readFully(i: InputStream, n: Int): ByteArray {
        val b = ByteArray(n)
        var r = 0
        while (r < n) {
            val k = i.read(b, r, n - r)
            if (k < 0) throw ProxyException("Máy chủ proxy đóng kết nối đột ngột")
            r += k
        }
        return b
    }

    private fun socks5(s: Socket, host: String, port: Int) {
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        val useAuth = endpoint.username.isNotEmpty()
        out.write(if (useAuth) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0))
        out.flush()
        val choice = readFully(inp, 2)
        if (choice[0].toInt() != 5) throw ProxyException("Máy chủ không phải SOCKS5")
        when (choice[1].toInt() and 0xFF) {
            0x00 -> {}
            0x02 -> {
                if (!useAuth) throw ProxyException("Máy chủ yêu cầu tài khoản SOCKS5")
                val u = endpoint.username.toByteArray(Charsets.UTF_8)
                val p = endpoint.password.toByteArray(Charsets.UTF_8)
                if (u.size > 255 || p.size > 255) throw ProxyException("Tài khoản hoặc mật khẩu proxy quá dài")
                val msg = ByteArray(3 + u.size + p.size)
                msg[0] = 1; msg[1] = u.size.toByte()
                System.arraycopy(u, 0, msg, 2, u.size)
                msg[2 + u.size] = p.size.toByte()
                System.arraycopy(p, 0, msg, 3 + u.size, p.size)
                out.write(msg); out.flush()
                val auth = readFully(inp, 2)
                if (auth[1].toInt() != 0) throw ProxyException("Sai tài khoản hoặc mật khẩu proxy")
            }
            0xFF -> throw ProxyException("Máy chủ proxy từ chối phương thức xác thực")
            else -> throw ProxyException("Phương thức xác thực SOCKS5 không hỗ trợ")
        }

        val v4 = parseIpv4(host)
        val req: ByteArray = if (v4 != null) {
            byteArrayOf(5, 1, 0, 1, v4[0], v4[1], v4[2], v4[3], (port ushr 8).toByte(), port.toByte())
        } else {
            val h = host.toByteArray(Charsets.UTF_8)
            if (h.size > 255) throw ProxyException("Tên miền quá dài")
            val r = ByteArray(7 + h.size)
            r[0] = 5; r[1] = 1; r[2] = 0; r[3] = 3; r[4] = h.size.toByte()
            System.arraycopy(h, 0, r, 5, h.size)
            r[5 + h.size] = (port ushr 8).toByte(); r[6 + h.size] = port.toByte()
            r
        }
        out.write(req); out.flush()
        val head = readFully(inp, 4)
        val rep = head[1].toInt() and 0xFF
        if (rep != 0) throw ProxyException("Proxy từ chối kết nối tới đích: ${socksError(rep)}")
        when (head[3].toInt() and 0xFF) {
            1 -> readFully(inp, 4 + 2)
            4 -> readFully(inp, 16 + 2)
            3 -> { val l = readFully(inp, 1)[0].toInt() and 0xFF; readFully(inp, l + 2) }
            else -> throw ProxyException("Phản hồi SOCKS5 không hợp lệ")
        }
    }

    private fun httpConnect(s: Socket, host: String, port: Int) {
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        val sb = StringBuilder()
        sb.append("CONNECT ").append(host).append(':').append(port).append(" HTTP/1.1\r\n")
        sb.append("Host: ").append(host).append(':').append(port).append("\r\n")
        if (endpoint.username.isNotEmpty()) {
            val cred = Base64.getEncoder().encodeToString(
                "${endpoint.username}:${endpoint.password}".toByteArray(Charsets.UTF_8))
            sb.append("Proxy-Authorization: Basic ").append(cred).append("\r\n")
        }
        sb.append("Proxy-Connection: keep-alive\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.US_ASCII)); out.flush()

        // Read byte-by-byte so no tunnel payload is consumed along with the headers.
        val head = StringBuilder()
        var state = 0
        while (head.length < 8192) {
            val c = inp.read()
            if (c < 0) throw ProxyException("Máy chủ proxy đóng kết nối đột ngột")
            head.append(c.toChar())
            state = when {
                c == '\r'.code && (state == 0 || state == 2) -> state + 1
                c == '\n'.code && (state == 1 || state == 3) -> state + 1
                else -> 0
            }
            if (state == 4) break
        }
        if (state != 4) throw ProxyException("Phản hồi HTTP của proxy quá dài hoặc sai định dạng")
        val statusLine = head.lineSequence().first()
        val code = statusLine.split(' ').getOrNull(1)?.toIntOrNull()
            ?: throw ProxyException("Phản hồi HTTP của proxy không hợp lệ")
        when (code) {
            200 -> {}
            407 -> throw ProxyException("Sai tài khoản hoặc mật khẩu proxy (407)")
            else -> throw ProxyException("Proxy từ chối kết nối (HTTP $code)")
        }
    }

    private fun socksError(code: Int) = when (code) {
        1 -> "lỗi máy chủ SOCKS"
        2 -> "bị chặn bởi quy tắc của proxy"
        3 -> "mạng không tới được"
        4 -> "máy đích không tới được"
        5 -> "đích từ chối kết nối"
        6 -> "TTL hết hạn"
        7 -> "lệnh không hỗ trợ"
        8 -> "kiểu địa chỉ không hỗ trợ"
        else -> "mã $code"
    }

    companion object {
        fun parseIpv4(s: String): ByteArray? {
            val parts = s.split('.')
            if (parts.size != 4) return null
            val out = ByteArray(4)
            for (i in 0..3) {
                val v = parts[i].toIntOrNull() ?: return null
                if (v !in 0..255 || parts[i].length > 3) return null
                out[i] = v.toByte()
            }
            return out
        }
    }
}

object ProxyProbe {
    /** Opens a tunnel to [host]:[port] through the proxy and returns the elapsed milliseconds. */
    fun latencyMs(connector: UpstreamConnector, host: String, port: Int): Long {
        val t0 = System.nanoTime()
        val s = connector.connect(host, port)
        val ms = (System.nanoTime() - t0) / 1_000_000
        try { s.close() } catch (_: IOException) {}
        return ms
    }
}
