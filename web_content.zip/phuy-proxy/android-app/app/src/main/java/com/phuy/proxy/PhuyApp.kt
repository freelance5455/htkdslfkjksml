package com.phuy.proxy

import android.app.Application
import com.phuy.proxy.api.ApiClient
import com.phuy.proxy.data.SettingsStore

class PhuyApp : Application() {
    lateinit var settings: SettingsStore
        private set
    lateinit var api: ApiClient
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = SettingsStore(this)
        api = ApiClient { settings.backendUrl }
    }

    companion object {
        lateinit var instance: PhuyApp
            private set
    }
}
