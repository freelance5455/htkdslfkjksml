package com.phuy.proxy.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

object PhuyColors {
    val Bg = Color(0xFF07040F)
    val Card = Color(0xFF120A22)
    val Line = Color(0xFF3B1D6E)
    val Neon = Color(0xFFB45CFF)
    val Neon2 = Color(0xFF7A2CFF)
    val Ok = Color(0xFF4ADE80)
    val Bad = Color(0xFFFF5C7A)
    val Warn = Color(0xFFFBBF24)
    val Muted = Color(0xFFA89CC4)
}

@Composable
fun PhuyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PhuyColors.Neon, onPrimary = Color.White,
            background = PhuyColors.Bg, onBackground = Color.White,
            surface = PhuyColors.Card, onSurface = Color.White,
            error = PhuyColors.Bad,
        ),
        content = content,
    )
}

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PhuyColors.Card),
        border = BorderStroke(1.dp, PhuyColors.Line),
    ) { content() }
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, filled: Boolean = true, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val m = modifier.fillMaxWidth().heightIn(min = 52.dp)
    if (filled) {
        Button(onClick = onClick, enabled = enabled, modifier = m, shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PhuyColors.Neon2)) {
            Text(text, fontWeight = FontWeight.ExtraBold)
        }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = m, shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, if (enabled) PhuyColors.Neon else PhuyColors.Line)) {
            Text(text, fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color.White)
        }
    }
}
