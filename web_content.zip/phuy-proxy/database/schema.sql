-- P.HUY GETKEY schema (SQLite for development; types map 1:1 to PostgreSQL).
-- Migration 001 — initial schema.

CREATE TABLE IF NOT EXISTS schema_migrations (
    version     INTEGER PRIMARY KEY,
    applied_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS keys (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    key_value        TEXT    NOT NULL UNIQUE,            -- e.g. P.huy-xxxxxxxxxx
    owner_token_hash TEXT    NOT NULL,                   -- sha256 of the secret returned once at creation
    duration_days    INTEGER NOT NULL CHECK (duration_days IN (1, 7, 30)),
    status           TEXT    NOT NULL DEFAULT 'ACTIVE'
                             CHECK (status IN ('ACTIVE', 'EXPIRED', 'REVOKED')),
    created_at       INTEGER NOT NULL,                   -- unix seconds (UTC)
    expires_at       INTEGER NOT NULL,
    reset_count      INTEGER NOT NULL DEFAULT 0,         -- resets already used by this key lineage
    max_resets       INTEGER NOT NULL DEFAULT 3,
    replaced_by      INTEGER REFERENCES keys(id),        -- set when this key was reset
    revoked_reason   TEXT,
    created_ip_hash  TEXT                                -- salted hash only, never the raw IP
);
CREATE INDEX IF NOT EXISTS idx_keys_status  ON keys(status);
CREATE INDEX IF NOT EXISTS idx_keys_expires ON keys(expires_at);

CREATE TABLE IF NOT EXISTS key_events (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    key_id    INTEGER NOT NULL REFERENCES keys(id),
    event     TEXT    NOT NULL,                          -- CREATED | RESET | REVOKED | EXPIRED
    reason    TEXT,
    actor     TEXT    NOT NULL,                          -- 'user' | 'admin:<name>' | 'system'
    at        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_key ON key_events(key_id);

CREATE TABLE IF NOT EXISTS admins (
    username      TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,                         -- scrypt$n$r$p$salt$hash, never plain text
    created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_sessions (
    token_hash TEXT PRIMARY KEY,                         -- sha256 of bearer token
    username   TEXT    NOT NULL REFERENCES admins(username),
    expires_at INTEGER NOT NULL,
    revoked    INTEGER NOT NULL DEFAULT 0
);

INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (1, strftime('%s','now'));
