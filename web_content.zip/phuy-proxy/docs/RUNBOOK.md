# Hướng dẫn vận hành

## 1. Chạy backend

Yêu cầu: Python 3.11+.

```bash
cd phuy-proxy
pip install -r backend/requirements.txt

export PHUY_DB_PATH=/var/lib/phuy/phuy.db      # thư mục phải tồn tại và ghi được
export PHUY_ADMIN_USER=admin
export PHUY_ADMIN_PASSWORD='<mật khẩu mạnh của bạn>'
export PHUY_IP_SALT="$(python3 -c 'import secrets;print(secrets.token_hex(16))')"

python3 -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 \
        --proxy-headers --forwarded-allow-ips=127.0.0.1
```

- Tài khoản admin được tạo (mật khẩu băm scrypt) ở lần chạy đầu nếu cả hai biến `PHUY_ADMIN_*` được đặt. Không đặt thì không có admin nào.
- **HTTPS**: đặt sau reverse proxy có chứng chỉ (ví dụ Caddy: `example.com { reverse_proxy 127.0.0.1:8000 }`) hoặc thêm `--ssl-keyfile/--ssl-certfile` cho uvicorn. App Android chỉ chấp nhận `https://`.
- `--proxy-headers` bắt buộc khi đứng sau reverse proxy, nếu không rate limit sẽ tính mọi người là cùng một IP.
- Website: `https://<domain>/` (GETKEY), `https://<domain>/admin` (quản trị).
- Rate limit hiện lưu trong bộ nhớ một tiến trình. Chạy nhiều worker thì chuyển sang Redis.
- PostgreSQL: `database/schema.sql` dùng kiểu dữ liệu tương thích; cần thay lớp `db.py` (hiện dùng `sqlite3`).

### Biến môi trường (xem `backend/.env.example`)
`PHUY_DB_PATH`, `PHUY_ADMIN_USER`, `PHUY_ADMIN_PASSWORD`, `PHUY_IP_SALT`, `PHUY_CORS_ORIGINS` (tùy chọn).

### Sao lưu và xử lý sự cố
- Sao lưu: `sqlite3 "$PHUY_DB_PATH" ".backup '/backup/phuy-$(date +%F).db'"` (an toàn khi đang chạy, WAL bật). Chạy hằng ngày bằng cron, giữ ≥ 7 bản.
- Khôi phục: dừng backend, chép bản sao lưu đè lên `PHUY_DB_PATH`, chạy lại.
- Quên mật khẩu admin: xóa dòng trong bảng `admins`, đặt lại `PHUY_ADMIN_PASSWORD`, khởi động lại.
- Key bị lộ: đăng nhập `/admin`, THU HỒI key; dùng "ĐĂNG XUẤT MỌI THIẾT BỊ" nếu nghi lộ phiên admin.
- Xem lịch sử một key: `GET /api/admin/history?key=...` (cần Bearer token admin).

## 2. Build APK trong Android Studio

1. Cài Android Studio (Koala trở lên) và JDK 17.
2. `File ▸ Open` thư mục `android-app/`. Chờ Gradle sync (cần internet để tải thư viện từ Google/Maven).
3. Chọn thiết bị thật hoặc emulator (Android 8.0 / API 26 trở lên). **Nên dùng thiết bị thật** để thử VPN và nút nổi.
4. `Run ▸ Run 'app'`, hoặc `Build ▸ Build APK(s)` để lấy file `app/build/outputs/apk/debug/app-debug.apk`.
5. Chạy unit test lõi mạng: `./gradlew :app:testDebugUnitTest`.

> Bản giao này **chưa được build và chưa chạy trên thiết bị** (xem `STATUS.md`). Lần sync/build đầu có thể báo lỗi biên dịch nhỏ cần sửa.

## 3. Cấu hình máy chủ proxy

App không kèm sẵn máy chủ proxy nào. Bạn cần một proxy do chính bạn hoặc nhà cung cấp bạn tin tưởng vận hành, hỗ trợ **SOCKS5** (có hoặc không user/pass) hoặc **HTTP CONNECT**.

1. Mở app ▸ `CẤU HÌNH PROXY CHUNG` (hoặc `CÀI ĐẶT FFTH` / `CÀI ĐẶT FFMAX`).
2. Chọn giao thức, nhập địa chỉ, cổng, tài khoản/mật khẩu (nếu có).
3. (Tùy chọn) nhập *package name* của ứng dụng đích để chỉ định tuyến ứng dụng đó; để trống = cả thiết bị.
4. DNS: truy vấn DNS đi qua proxy tới máy chủ DNS bạn chọn (mặc định `1.1.1.1`).
5. Bấm `KIỂM TRA MÁY CHỦ PROXY`: app thực sự mở một kết nối qua proxy và báo độ trễ hoặc lỗi cụ thể. Chưa cấu hình thì app hiện "Chưa cấu hình", không giả vờ kết nối.

Lưu ý quyền riêng tư: chủ máy chủ proxy thấy địa chỉ đích của lưu lượng TCP và các truy vấn DNS. Chỉ dùng proxy bạn tin tưởng.

## 4. Cấp quyền nút nổi

1. App ▸ `CÀI ĐẶT` ▸ bật công tắc "Nút nổi P.HUY".
2. App giải thích lý do và mở màn hình Cài đặt của Android. **Bạn tự bật** quyền "Hiển thị trên ứng dụng khác" cho P.HUY PROXY. App không tự cấp và không vượt quyền.
3. Quay lại app: nút tròn "P" xuất hiện. Kéo để di chuyển, chạm để mở bảng điều khiển (CONNECT / DISCONNECT / ĐÓNG).
4. Tắt: công tắc trong Cài đặt. Nếu bạn từ chối quyền, nút nổi không bật, phần còn lại vẫn chạy.
5. Lần CONNECT đầu tiên Android sẽ hiện hộp thoại xin quyền VPN; nếu bấm từ nút nổi, app sẽ mở lên để hiện hộp thoại đó.

## 5. Kiểm thử từng chức năng

**Backend (tự động, đã chạy):** `python3 -m unittest tests.test_backend -v` (23 test).

**Lõi mạng Android (đã viết, chưa chạy):** `./gradlew :app:testDebugUnitTest` — gói tin/checksum, SOCKS5 (có/không xác thực, sai mật khẩu, đích từ chối), HTTP CONNECT (Basic auth, 407), proxy tắt, TCP echo qua TunForwarder, truyền 20 KB, segment trùng lặp, DNS-over-TCP, UDP/IPv6 bị chặn.

**Thủ công trên thiết bị (bắt buộc trước khi tin vào bản build):**

| Kịch bản | Cách thử | Kết quả mong đợi |
|---|---|---|
| Luồng đầu-cuối | GET KEY trên web → dán vào GetKey → cấu hình proxy → CONNECT → mở trang IP-check trong trình duyệt → DISCONNECT | IP hiển thị là IP của proxy khi CONNECTED, trở lại IP cũ sau DISCONNECT |
| Key hết hạn / thu hồi | Thu hồi key ở `/admin`, bấm CONNECT; hoặc đang CONNECTED chờ ≤ 5 phút | Báo "Key không dùng được/đã bị thu hồi", ngắt kết nối |
| Proxy không hoạt động | Nhập cổng sai, CONNECT | Báo lỗi cụ thể, trạng thái DISCONNECTED |
| Mất mạng | Bật chế độ máy bay khi CONNECTING / CONNECTED | Lỗi rõ ràng; sau 5 lần thất bại liên tiếp tự ngắt và báo "mất kết nối" |
| Từ chối quyền VPN | Bấm "Hủy" ở hộp thoại VPN | "Bạn đã từ chối quyền VPN", không hiện CONNECTED |
| Tắt VPN từ hệ thống | Cài đặt Android ▸ VPN ▸ ngắt | App về DISCONNECTED, thông báo "VPN đã bị tắt từ hệ thống" |
| Từ chối quyền overlay | Không bật quyền ở màn hình Cài đặt Android | Nút nổi không bật, app vẫn dùng được |
| Xoay màn hình | Bật nút nổi và mở bảng điều khiển, xoay ngang/dọc | Nút và bảng vẫn nằm trọn trong màn hình, không thoát service |
| Backend không khả dụng | Tắt backend, bấm XÁC THỰC KEY / CONNECT | "Backend không khả dụng…"; không báo key sai |
| Đăng nhập admin sai | Nhập sai ở `/admin` | "Invalid credentials"; sau 5 lần bị khóa 15 phút |
