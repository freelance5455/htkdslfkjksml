# P.HUY PROXY — Kiến trúc

```
phuy-proxy/
├── android-app/        App Android (Kotlin, Compose, VpnService)
├── backend/            API GetKey (Starlette + SQLite)
├── getkey-website/     Website GETKEY + trang quản trị (HTML/JS thuần, phục vụ bởi backend)
├── database/           schema.sql (migration 001)
├── docs/               Tài liệu này, RUNBOOK.md, STATUS.md
└── tests/              Kiểm thử backend (unittest)
```

## Luồng đầu-cuối

```
GETKEY web ──create──▶ backend ──▶ SQLite (keys UNIQUE)
     │ key + reset_token (hiện 1 lần)
     ▼
App: nhập key ──validate──▶ backend (kiểm tra trạng thái + hạn ở server)
     ▼
App: cấu hình proxy (SOCKS5 / HTTP CONNECT do người dùng nhập)
     ▼  CONNECT
PhuyVpnService: validate key → bắt tay thật với proxy → establish VPN → TunForwarder
     ▼
Nút nổi (FloatingButtonService) gửi CONNECT/DISCONNECT tới cùng service
```

Trạng thái CONNECTED chỉ được đặt sau khi cả ba bước (key hợp lệ, proxy trả lời bắt tay thật, VPN được tạo) thành công.

## Backend (`backend/app`)

| Module | Vai trò |
|---|---|
| `main.py` | Route, xác thực admin, rate limit, header bảo mật, xử lý lỗi (không lộ stack trace) |
| `keys.py` | Vòng đời key: create / validate / reset / revoke. Reset là một giao dịch `BEGIN IMMEDIATE` |
| `security.py` | Sinh key bằng `secrets`, băm mật khẩu scrypt, băm token/IP |
| `ratelimit.py` | Cửa sổ trượt theo IP; khóa đăng nhập admin sau 5 lần sai |
| `db.py` | Kết nối SQLite, giao dịch ghi tuần tự hóa |
| `config.py` | Toàn bộ bí mật lấy từ biến môi trường |

Quy tắc chính: key `P.huy-` + 10 ký tự `[a-z0-9]`; cột `key_value` có `UNIQUE`, trùng thì sinh lại; trạng thái `ACTIVE/EXPIRED/REVOKED`; hạn 1/7/30 ngày; reset cần `reset_token` (chỉ lưu hash) hoặc phiên admin — biết chuỗi key là không đủ; tối đa 3 lần reset mỗi chuỗi key; mọi sự kiện ghi vào `key_events`.

## Android (`android-app/app/src/main/java/com/phuy/proxy`)

| Package | Nội dung |
|---|---|
| `ui` | Compose: Home, Profile (FFTH/FFMAX/chung), GetKey, Settings |
| `data` | `SettingsStore` (EncryptedSharedPreferences cho key/mật khẩu), `ConnectionStore`, models |
| `api` | `ApiClient` — chỉ HTTPS, phân biệt "key không hợp lệ" với "backend không khả dụng" |
| `net` | **Thuần Kotlin, không phụ thuộc Android**: `ProxyConnector` (SOCKS5 + HTTP CONNECT), `TunForwarder` (TCP + DNS qua proxy), `Packets` |
| `vpn` | `PhuyVpnService` — foreground service, VpnService, giám sát |
| `overlay` | `FloatingButtonService` — nút nổi kéo được + bảng điều khiển |

### Phần vận chuyển lưu lượng (TunForwarder)
Đọc gói IPv4 từ TUN, tự kết thúc từng kết nối TCP (bắt tay SYN/SYN-ACK, ACK, FIN, RST, kiểm soát cửa sổ theo `window` của client), rồi chuyển byte qua `ProxyConnector`. DNS (UDP/53) được đổi sang DNS-over-TCP qua cùng proxy. Socket tới proxy được `protect()` để không lặp vào VPN.

Giới hạn đã biết (cũng hiện trong màn hình Cài đặt của app): chỉ IPv4 TCP + DNS; UDP khác, ICMP, IPv6 bị chặn (không rò rỉ nhưng cũng không đi qua proxy); không có bộ đệm truyền lại TCP (đường TUN cục bộ, không mất gói); bỏ qua window-scale; Android chỉ cho một VPN tại một thời điểm.

### FFTH / FFMAX
Hai thẻ giao diện, mỗi thẻ có cấu hình proxy riêng, trạng thái riêng và trường "package ứng dụng đích" tùy chọn (`addAllowedApplication`). Không giả định API hay giao thức riêng của trò chơi, không đụng tới dữ liệu hay bộ nhớ của trò chơi.

## Bảo mật
HTTPS-only cho API (network security config chặn cleartext); không có bí mật nào trong APK; admin cần đăng nhập, mật khẩu băm scrypt, phiên thu hồi được (`logout`, `logout-all`); rate limit tạo key / validate / reset / đăng nhập; kiểm tra đầu vào ở backend; log không chứa key, mật khẩu hay nội dung lưu lượng.
