# Trạng thái thực tế (không tô vẽ)

Ngày: 2026-10-09. Môi trường tạo bản này: không có Android SDK, không có trình biên dịch Kotlin, không tải được Google Maven và PyPI (chính sách mạng của sandbox). Vì vậy:

## Đã chạy và kiểm chứng thực tế
| Hạng mục | Bằng chứng |
|---|---|
| Backend: tạo key, validate, reset, revoke, status, admin, rate limit, khóa brute-force | 23/23 test `unittest` đạt (`tests/test_backend.py`) |
| Key không trùng (300 key), UNIQUE buộc sinh lại khi trùng | test đạt |
| Reset đồng thời: 8 luồng, đúng 1 thắng, 7 nhận 409, chỉ còn 1 key ACTIVE | test đạt |
| Người lạ biết chuỗi key không reset được (401/403) | test đạt |
| Key hết hạn (đồng hồ giả lập), key bị thu hồi | test đạt |
| Đăng nhập admin sai, khóa sau 5 lần, phiên hết hạn, đăng xuất từ xa | test đạt |
| Mật khẩu admin chỉ lưu dạng scrypt | test đạt |
| Chạy thật bằng uvicorn + curl: create → validate → reset → key cũ REVOKED; `/`, `/admin`, `/static/*` trả 200 | đã chạy một lần |
| JS của website qua `node --check` | đạt (cú pháp) |

## Đã viết nhưng CHƯA build, CHƯA chạy
| Hạng mục | Ghi chú |
|---|---|
| Toàn bộ app Android (UI, VpnService, nút nổi, lưu trữ, API client) | Chưa biên dịch lần nào. Có thể có lỗi biên dịch/runtime |
| `TunForwarder` / `ProxyConnector` và bộ test JVM của chúng | Test đã viết, **chưa chạy** |
| Giao diện website trên trình duyệt thật | Mới kiểm tra route và cú pháp JS; chưa xem bằng mắt, chưa thử trên điện thoại |
| Kiểu foreground service `systemExempted` cho VPN trên Android 14 | Cần xác nhận trên thiết bị Android 14+ |
| Không có APK. Không tuyên bố build thành công | |

## Chưa làm / giới hạn
- UDP không phải DNS không đi qua proxy (bị chặn). Nhiều trò chơi dùng UDP, nên **chưa thể nói** FFTH/FFMAX chạy được qua proxy; cần SOCKS5 UDP ASSOCIATE nếu muốn hỗ trợ.
- IPv6 bị chặn thay vì chuyển tiếp.
- Không có tính năng "chọn vị trí máy chủ" (mỗi cấu hình một máy chủ).
- Không có bộ nhớ đệm truyền lại TCP; bỏ qua TCP window-scale.
- Rate limit trong bộ nhớ (một tiến trình). Backend dùng SQLite; chưa có lớp PostgreSQL.
- Kiểm thử Android cho overlay, xoay màn hình, từ chối quyền, tắt VPN, mất mạng mới là kịch bản thủ công (`RUNBOOK.md` §5), chưa chạy.
- Thay vì FastAPI, backend dùng Starlette (nền tảng của FastAPI) vì không cài được `fastapi` trong sandbox. Cách đặt route và logic tương thích, chuyển sang FastAPI chỉ là đổi lớp vỏ.
- Chưa đo ping hay hiệu suất; không có tuyên bố nào về giảm ping/giảm tâm.
- Không có máy chủ proxy kèm theo; người dùng phải tự cung cấp.
