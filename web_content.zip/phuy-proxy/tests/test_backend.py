import os
import sys
import tempfile
import threading
import unittest

os.environ["PHUY_AUTOSTART"] = "0"
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from starlette.testclient import TestClient  # noqa: E402

from backend.app.config import Settings  # noqa: E402
from backend.app.main import create_app  # noqa: E402

ADMIN_PW = "test-only-password-123"


class Clock:
    def __init__(self):
        self.t = 1_800_000_000.0

    def __call__(self):
        return self.t


def make(**over):
    tmp = tempfile.mkdtemp()
    s = Settings(db_path=os.path.join(tmp, "t.db"), admin_username="root", admin_password=ADMIN_PW,
                 ip_salt="test-salt")
    for k, v in over.items():
        setattr(s, k, v)
    clock = Clock()
    app = create_app(s, clock=clock)
    return TestClient(app), clock


def admin_token(c):
    r = c.post("/api/admin/login", json={"username": "root", "password": ADMIN_PW})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


class KeyTests(unittest.TestCase):
    def test_many_keys_are_unique_and_formatted(self):
        c, _ = make(create_limit=(500, 3600))
        seen = set()
        for _ in range(300):
            r = c.post("/api/keys/create", json={"duration_days": 1})
            self.assertEqual(r.status_code, 201)
            k = r.json()["key"]
            self.assertRegex(k, r"^P\.huy-[a-z0-9]{10}$")
            seen.add(k)
        self.assertEqual(len(seen), 300)

    def test_unique_constraint_forces_regeneration(self):
        # Force the generator to return a duplicate first, then a fresh value.
        from backend.app import keys as keys_mod
        c, _ = make(create_limit=(50, 3600))
        first = c.post("/api/keys/create", json={"duration_days": 7}).json()["key"]
        real = keys_mod.generate_key
        seq = iter([first, first, "P.huy-zzzzzzzzzz"])
        keys_mod.generate_key = lambda: next(seq)
        try:
            second = c.post("/api/keys/create", json={"duration_days": 7}).json()["key"]
        finally:
            keys_mod.generate_key = real
        self.assertEqual(second, "P.huy-zzzzzzzzzz")

    def test_invalid_duration_rejected(self):
        c, _ = make(create_limit=(100, 3600))
        for bad in (2, 0, -1, "7", True, None):
            r = c.post("/api/keys/create", json={"duration_days": bad})
            self.assertEqual(r.status_code, 400, bad)

    def test_create_rate_limited(self):
        c, clock = make()
        codes = [c.post("/api/keys/create", json={"duration_days": 1}).status_code for _ in range(5)]
        self.assertEqual(codes, [201, 201, 201, 429, 429])
        clock.t += 3601
        self.assertEqual(c.post("/api/keys/create", json={"duration_days": 1}).status_code, 201)

    def test_validate_active_then_expired(self):
        c, clock = make()
        k = c.post("/api/keys/create", json={"duration_days": 1}).json()["key"]
        self.assertTrue(c.post("/api/keys/validate", json={"key": k}).json()["valid"])
        clock.t += 86400 + 1
        v = c.post("/api/keys/validate", json={"key": k}).json()
        self.assertFalse(v["valid"])
        self.assertEqual(v["status"], "EXPIRED")
        self.assertEqual(c.get("/api/keys/status", params={"key": k}).json()["status"], "EXPIRED")

    def test_validate_unknown_and_malformed(self):
        c, _ = make()
        self.assertFalse(c.post("/api/keys/validate", json={"key": "P.huy-0000000000"}).json()["valid"])
        self.assertFalse(c.post("/api/keys/validate", json={"key": "garbage"}).json()["valid"])
        self.assertEqual(c.post("/api/keys/validate", content=b"not json").status_code, 400)

    def test_revoked_key_invalid(self):
        c, _ = make()
        k = c.post("/api/keys/create", json={"duration_days": 30}).json()["key"]
        h = admin_token(c)
        r = c.post("/api/keys/revoke", json={"key": k, "reason": "abuse"}, headers=h)
        self.assertEqual(r.json()["status"], "REVOKED")
        v = c.post("/api/keys/validate", json={"key": k}).json()
        self.assertEqual((v["valid"], v["status"]), (False, "REVOKED"))

    def test_revoke_requires_admin(self):
        c, _ = make()
        k = c.post("/api/keys/create", json={"duration_days": 1}).json()["key"]
        self.assertEqual(c.post("/api/keys/revoke", json={"key": k}).status_code, 401)
        self.assertEqual(c.post("/api/keys/revoke", json={"key": k},
                                headers={"Authorization": "Bearer forged"}).status_code, 401)
        self.assertTrue(c.post("/api/keys/validate", json={"key": k}).json()["valid"])


class ResetTests(unittest.TestCase):
    def setUp(self):
        self.c, self.clock = make(create_limit=(100, 3600), reset_limit=(100, 3600))
        r = self.c.post("/api/keys/create", json={"duration_days": 7}).json()
        self.key, self.token = r["key"], r["reset_token"]

    def test_owner_reset_replaces_key(self):
        r = self.c.post("/api/keys/reset", json={"key": self.key, "reset_token": self.token, "reason": "lost"})
        self.assertEqual(r.status_code, 200, r.text)
        new = r.json()["key"]
        self.assertNotEqual(new, self.key)
        self.assertEqual(r.json()["resets_used"], 1)
        self.assertFalse(self.c.post("/api/keys/validate", json={"key": self.key}).json()["valid"])
        self.assertTrue(self.c.post("/api/keys/validate", json={"key": new}).json()["valid"])

    def test_stranger_cannot_reset_with_key_only(self):
        r = self.c.post("/api/keys/reset", json={"key": self.key})
        self.assertEqual(r.status_code, 401)
        r = self.c.post("/api/keys/reset", json={"key": self.key, "reset_token": "wrong"})
        self.assertEqual(r.status_code, 403)
        self.assertTrue(self.c.post("/api/keys/validate", json={"key": self.key}).json()["valid"])

    def test_other_users_token_cannot_reset(self):
        other = self.c.post("/api/keys/create", json={"duration_days": 1}).json()
        r = self.c.post("/api/keys/reset", json={"key": self.key, "reset_token": other["reset_token"]})
        self.assertEqual(r.status_code, 403)

    def test_reset_limit(self):
        key, token = self.key, self.token
        for i in range(3):
            r = self.c.post("/api/keys/reset", json={"key": key, "reset_token": token})
            self.assertEqual(r.status_code, 200, r.text)
            key = r.json()["key"]
        r = self.c.post("/api/keys/reset", json={"key": key, "reset_token": token})
        self.assertEqual(r.status_code, 429)
        self.assertTrue(self.c.post("/api/keys/validate", json={"key": key}).json()["valid"])

    def test_old_key_cannot_be_reset_again(self):
        self.c.post("/api/keys/reset", json={"key": self.key, "reset_token": self.token})
        r = self.c.post("/api/keys/reset", json={"key": self.key, "reset_token": self.token})
        self.assertEqual(r.status_code, 409)

    def test_concurrent_resets_only_one_wins(self):
        results = []

        def worker():
            r = self.c.post("/api/keys/reset", json={"key": self.key, "reset_token": self.token})
            results.append(r.status_code)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(results.count(200), 1, results)
        self.assertEqual(results.count(409), 7, results)
        h = admin_token(self.c)
        active = [k for k in self.c.get("/api/admin/keys", headers=h).json()["keys"] if k["status"] == "ACTIVE"]
        self.assertEqual(len(active), 1)

    def test_admin_reset_without_token_and_history(self):
        h = admin_token(self.c)
        r = self.c.post("/api/keys/reset", json={"key": self.key, "reason": "support"}, headers=h)
        self.assertEqual(r.status_code, 200, r.text)
        ev = self.c.get("/api/admin/history", params={"key": self.key}, headers=h).json()["events"]
        self.assertEqual([e["event"] for e in ev], ["CREATED", "RESET"])
        self.assertEqual(ev[1]["reason"], "support")
        self.assertEqual(ev[1]["actor"], "admin:root")


class AdminTests(unittest.TestCase):
    def test_invalid_login(self):
        c, _ = make()
        for body in ({"username": "root", "password": "nope"}, {"username": "ghost", "password": "x"},
                     {"username": "", "password": ""}, {"username": 1, "password": 2}):
            self.assertEqual(c.post("/api/admin/login", json=body).status_code, 401, body)

    def test_brute_force_lockout(self):
        c, clock = make()
        codes = [c.post("/api/admin/login", json={"username": "root", "password": f"bad{i}"}).status_code
                 for i in range(7)]
        self.assertEqual(codes[:5], [401] * 5)
        self.assertEqual(codes[5:], [429, 429])
        # even the correct password is refused while locked
        self.assertEqual(c.post("/api/admin/login", json={"username": "root", "password": ADMIN_PW}).status_code, 429)
        clock.t += 901
        self.assertEqual(c.post("/api/admin/login", json={"username": "root", "password": ADMIN_PW}).status_code, 200)

    def test_logout_and_remote_logout_invalidate_sessions(self):
        c, _ = make()
        h1, h2 = admin_token(c), admin_token(c)
        c.post("/api/admin/logout", headers=h1)
        self.assertEqual(c.get("/api/admin/keys", headers=h1).status_code, 401)
        self.assertEqual(c.get("/api/admin/keys", headers=h2).status_code, 200)
        c.post("/api/admin/logout-all", headers=h2)
        self.assertEqual(c.get("/api/admin/keys", headers=h2).status_code, 401)

    def test_session_expiry(self):
        c, clock = make()
        h = admin_token(c)
        clock.t += 8 * 3600 + 1
        self.assertEqual(c.get("/api/admin/keys", headers=h).status_code, 401)

    def test_password_not_stored_in_plain_text(self):
        c, _ = make()
        import sqlite3
        path = c.app.state.settings.db_path
        row = sqlite3.connect(path).execute("SELECT password_hash FROM admins").fetchone()[0]
        self.assertTrue(row.startswith("scrypt$"))
        self.assertNotIn(ADMIN_PW, row)

    def test_no_admin_when_env_missing(self):
        c, _ = make(admin_username="", admin_password="")
        self.assertEqual(c.post("/api/admin/login", json={"username": "root", "password": ADMIN_PW}).status_code, 401)

    def test_website_pages_and_static_served(self):
        c, _ = make()
        for path in ("/", "/admin", "/static/app.js", "/static/admin.js", "/static/style.css"):
            self.assertEqual(c.get(path).status_code, 200, path)
        self.assertIn("P<span>.</span>HUY", c.get("/").text)

    def test_security_headers_and_health(self):
        c, _ = make()
        r = c.get("/health")
        self.assertEqual(r.headers["x-content-type-options"], "nosniff")
        self.assertEqual(r.headers["x-frame-options"], "DENY")


if __name__ == "__main__":
    unittest.main(verbosity=2)
