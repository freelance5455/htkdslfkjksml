# P.HUY PROXY

Backend GetKey + website + app Android (VpnService, SOCKS5 / HTTP CONNECT, nút nổi).

- Đọc `docs/STATUS.md` trước: phần nào đã chạy thật, phần nào chưa build/chưa thử.
- Kiến trúc: `docs/ARCHITECTURE.md`. Chạy, build, cấu hình, kiểm thử: `docs/RUNBOOK.md`.
- Chạy test backend: `python3 -m unittest tests.test_backend -v`
