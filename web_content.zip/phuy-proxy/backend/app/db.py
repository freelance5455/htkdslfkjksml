import sqlite3
from contextlib import contextmanager


def connect(path: str) -> sqlite3.Connection:
    # isolation_level=None -> we control transactions explicitly (BEGIN IMMEDIATE).
    conn = sqlite3.connect(path, timeout=15, isolation_level=None, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db(path: str, schema_path: str) -> None:
    conn = connect(path)
    try:
        with open(schema_path, encoding="utf-8") as f:
            conn.executescript(f.read())
    finally:
        conn.close()


@contextmanager
def transaction(path: str):
    """Write transaction. BEGIN IMMEDIATE takes the write lock up front,
    so concurrent writers are serialised and read-then-write checks are race-free."""
    conn = connect(path)
    try:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        else:
            conn.execute("COMMIT")
    finally:
        conn.close()


@contextmanager
def reader(path: str):
    conn = connect(path)
    try:
        yield conn
    finally:
        conn.close()
