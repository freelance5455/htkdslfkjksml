"""P.HUY GETKEY backend (Starlette + SQLite). Run: uvicorn backend.app.main:app"""
import logging
import os
import time

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import db, keys
from .config import Settings
from .ratelimit import LoginGuard, RateLimiter
from .security import (hash_ip, hash_password, new_secret_token, sha256_hex,
                       valid_key_format, verify_password)

log = logging.getLogger("phuy")


def create_app(settings: Settings | None = None, clock=time.time) -> Starlette:
    s = settings or Settings()
    now = lambda: int(clock())
    limiter = RateLimiter(clock)
    guard = LoginGuard(clock, s.login_max_failures, s.login_lockout_seconds)
    db.init_db(s.db_path, s.schema_path)
    _bootstrap_admin(s, now())

    def err(code, message, http):
        return JSONResponse({"ok": False, "error": code, "message": message}, status_code=http)

    def ip_of(request: Request) -> str:
        return request.client.host if request.client else "unknown"

    async def body(request: Request) -> dict:
        try:
            data = await request.json()
        except Exception:
            raise keys.KeyError_("bad_json", "Body must be valid JSON", 400)
        if not isinstance(data, dict):
            raise keys.KeyError_("bad_json", "Body must be a JSON object", 400)
        return data

    def need_key(data: dict) -> str:
        k = data.get("key")
        if not valid_key_format(k):
            raise keys.KeyError_("invalid_key_format", "Invalid key format", 400)
        return k

    def admin_user(request: Request):
        auth = request.headers.get("authorization", "")
        if not auth.lower().startswith("bearer "):
            return None
        th = sha256_hex(auth[7:].strip())
        with db.reader(s.db_path) as conn:
            row = conn.execute("SELECT username, expires_at, revoked FROM admin_sessions WHERE token_hash=?",
                               (th,)).fetchone()
        if not row or row["revoked"] or row["expires_at"] <= now():
            return None
        return row["username"]

    def guarded(handler):
        """Wrap endpoint: consistent error handling, no stack traces to clients."""
        async def wrapper(request: Request):
            try:
                return await handler(request)
            except keys.KeyError_ as e:
                return err(e.code, e.message, e.http)
            except Exception:
                log.exception("unhandled error on %s", request.url.path)  # no request bodies logged
                return err("server_error", "Internal server error", 500)
        return wrapper

    # ---- public key endpoints -------------------------------------------------
    @guarded
    async def create(request: Request):
        if not limiter.allow("create", ip_of(request), s.create_limit):
            return err("rate_limited", "Too many keys requested, try later", 429)
        data = await body(request)
        days = data.get("duration_days", 1)
        if not isinstance(days, int) or isinstance(days, bool):
            return err("invalid_duration", "duration_days must be 1, 7 or 30", 400)
        out = keys.create_key(s.db_path, now(), days, s.max_resets, hash_ip(ip_of(request), s.ip_salt))
        return JSONResponse({"ok": True, **out}, status_code=201)

    @guarded
    async def validate(request: Request):
        if not limiter.allow("validate", ip_of(request), s.validate_limit):
            return err("rate_limited", "Too many requests", 429)
        data = await body(request)
        k = data.get("key")
        if not valid_key_format(k):
            return JSONResponse({"ok": True, "valid": False, "status": "INVALID"})
        return JSONResponse({"ok": True, **keys.validate(s.db_path, now(), k)})

    @guarded
    async def status(request: Request):
        if not limiter.allow("validate", ip_of(request), s.validate_limit):
            return err("rate_limited", "Too many requests", 429)
        k = request.query_params.get("key", "")
        if not valid_key_format(k):
            return err("invalid_key_format", "Invalid key format", 400)
        return JSONResponse({"ok": True, **keys.get_status(s.db_path, now(), k)})

    @guarded
    async def reset(request: Request):
        if not limiter.allow("reset", ip_of(request), s.reset_limit):
            return err("rate_limited", "Too many reset attempts", 429)
        data = await body(request)
        k = need_key(data)
        admin = admin_user(request)
        token = data.get("reset_token")
        if admin is None and not (isinstance(token, str) and token):
            return err("unauthorized", "reset_token or admin login required", 401)
        days = data.get("duration_days")
        out = keys.reset(s.db_path, now(), k, owner_token=token, admin=admin,
                         reason=str(data.get("reason", "")), days=days if isinstance(days, int) else None,
                         ip_hash=hash_ip(ip_of(request), s.ip_salt))
        return JSONResponse({"ok": True, **out})

    # ---- admin ----------------------------------------------------------------
    @guarded
    async def admin_login(request: Request):
        ip = ip_of(request)
        if not limiter.allow("login", ip, s.login_limit):
            return err("rate_limited", "Too many login attempts", 429)
        data = await body(request)
        user, pw = data.get("username"), data.get("password")
        if not isinstance(user, str) or not isinstance(pw, str) or not user or len(pw) > 256:
            return err("invalid_credentials", "Invalid credentials", 401)
        ident = f"{ip}|{user.lower()}"
        if guard.is_locked(ident):
            return err("locked", "Too many failures, account temporarily locked", 429)
        with db.reader(s.db_path) as conn:
            row = conn.execute("SELECT * FROM admins WHERE username=?", (user,)).fetchone()
        # verify against a dummy hash when the user is unknown, to keep timing similar
        stored = row["password_hash"] if row else hash_password("dummy-password")
        ok = verify_password(pw, stored) and row is not None
        if not ok:
            guard.failure(ident)
            log.warning("admin login failed for user=%r", user[:32])
            return err("invalid_credentials", "Invalid credentials", 401)
        guard.success(ident)
        token = new_secret_token()
        with db.transaction(s.db_path) as conn:
            conn.execute("INSERT INTO admin_sessions(token_hash,username,expires_at) VALUES (?,?,?)",
                         (sha256_hex(token), user, now() + s.session_ttl))
        return JSONResponse({"ok": True, "token": token, "expires_in": s.session_ttl})

    @guarded
    async def admin_logout(request: Request):
        auth = request.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            with db.transaction(s.db_path) as conn:
                conn.execute("UPDATE admin_sessions SET revoked=1 WHERE token_hash=?",
                             (sha256_hex(auth[7:].strip()),))
        return JSONResponse({"ok": True})

    @guarded
    async def admin_logout_all(request: Request):
        user = admin_user(request)
        if not user:
            return err("unauthorized", "Admin login required", 401)
        with db.transaction(s.db_path) as conn:
            conn.execute("UPDATE admin_sessions SET revoked=1 WHERE username=?", (user,))
        return JSONResponse({"ok": True})

    @guarded
    async def revoke(request: Request):
        user = admin_user(request)
        if not user:
            return err("unauthorized", "Admin login required", 401)
        data = await body(request)
        out = keys.revoke(s.db_path, now(), need_key(data), user, str(data.get("reason", "")))
        return JSONResponse({"ok": True, **out})

    @guarded
    async def admin_keys(request: Request):
        if not admin_user(request):
            return err("unauthorized", "Admin login required", 401)
        return JSONResponse({"ok": True, "keys": keys.list_keys(s.db_path, now())})

    @guarded
    async def admin_history(request: Request):
        if not admin_user(request):
            return err("unauthorized", "Admin login required", 401)
        k = request.query_params.get("key", "")
        if not valid_key_format(k):
            return err("invalid_key_format", "Invalid key format", 400)
        return JSONResponse({"ok": True, "events": keys.history(s.db_path, k)})

    async def health(request: Request):
        return JSONResponse({"ok": True})

    async def index(request: Request):
        return FileResponse(os.path.join(s.website_dir, "index.html"))

    async def admin_page(request: Request):
        return FileResponse(os.path.join(s.website_dir, "admin.html"))

    async def security_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:")
        return resp

    from starlette.middleware.base import BaseHTTPMiddleware
    middleware = [Middleware(BaseHTTPMiddleware, dispatch=security_headers)]
    if s.cors_origins:
        middleware.append(Middleware(CORSMiddleware, allow_origins=s.cors_origins,
                                     allow_methods=["GET", "POST"], allow_headers=["authorization", "content-type"]))

    routes = [
        Route("/", index), Route("/admin", admin_page), Route("/health", health),
        Mount("/static", StaticFiles(directory=s.website_dir), name="static"),
        Route("/api/keys/create", create, methods=["POST"]),
        Route("/api/keys/validate", validate, methods=["POST"]),
        Route("/api/keys/reset", reset, methods=["POST"]),
        Route("/api/keys/revoke", revoke, methods=["POST"]),
        Route("/api/keys/status", status, methods=["GET"]),
        Route("/api/admin/login", admin_login, methods=["POST"]),
        Route("/api/admin/logout", admin_logout, methods=["POST"]),
        Route("/api/admin/logout-all", admin_logout_all, methods=["POST"]),
        Route("/api/admin/keys", admin_keys, methods=["GET"]),
        Route("/api/admin/history", admin_history, methods=["GET"]),
    ]
    app = Starlette(routes=routes, middleware=middleware)
    app.state.settings = s
    return app


def _bootstrap_admin(s: Settings, ts: int) -> None:
    if not s.admin_username or not s.admin_password:
        log.warning("PHUY_ADMIN_USER/PHUY_ADMIN_PASSWORD not set: no admin account will be created")
        return
    with db.transaction(s.db_path) as conn:
        exists = conn.execute("SELECT 1 FROM admins WHERE username=?", (s.admin_username,)).fetchone()
        if not exists:
            conn.execute("INSERT INTO admins(username,password_hash,created_at) VALUES (?,?,?)",
                         (s.admin_username, hash_password(s.admin_password), ts))


def _default_app():
    return create_app()


app = None
if os.environ.get("PHUY_AUTOSTART", "1") == "1" and __name__ != "__main__":
    try:
        app = _default_app()
    except Exception:  # keeps imports in tests/tools from failing when env is incomplete
        logging.getLogger("phuy").exception("failed to create default app")
