"""Hashing, token and key generation helpers (stdlib only)."""
import hashlib
import hmac
import secrets

KEY_PREFIX = "P.huy-"
_ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789"
KEY_BODY_LEN = 10


def generate_key() -> str:
    """Cryptographically secure random key, e.g. P.huy-k3j9x0ab12 (format example only)."""
    return KEY_PREFIX + "".join(secrets.choice(_ALPHABET) for _ in range(KEY_BODY_LEN))


def valid_key_format(value: str) -> bool:
    if not isinstance(value, str) or not value.startswith(KEY_PREFIX):
        return False
    body = value[len(KEY_PREFIX):]
    return len(body) == KEY_BODY_LEN and all(c in _ALPHABET for c in body)


def new_secret_token() -> str:
    return secrets.token_urlsafe(32)


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def hash_ip(ip: str, salt: str) -> str:
    return hashlib.sha256((salt + "|" + ip).encode()).hexdigest()[:32]


def hash_password(password: str) -> str:
    n, r, p = 2 ** 14, 8, 1
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=n, r=r, p=p, dklen=32)
    return f"scrypt${n}${r}${p}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_hex, hash_hex = stored.split("$")
        if scheme != "scrypt":
            return False
        digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex),
                                n=int(n), r=int(r), p=int(p), dklen=32)
        return hmac.compare_digest(digest.hex(), hash_hex)
    except (ValueError, TypeError):
        return False
