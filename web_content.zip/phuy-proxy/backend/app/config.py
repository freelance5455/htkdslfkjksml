"""Runtime settings. Every secret comes from the environment, never from source."""
import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


@dataclass
class Settings:
    db_path: str = field(default_factory=lambda: os.environ.get("PHUY_DB_PATH", str(ROOT / "phuy.db")))
    schema_path: str = field(default_factory=lambda: str(ROOT / "database" / "schema.sql"))
    # Admin bootstrap: if both are set and the admin does not exist, it is created with a hashed password.
    admin_username: str = field(default_factory=lambda: os.environ.get("PHUY_ADMIN_USER", ""))
    admin_password: str = field(default_factory=lambda: os.environ.get("PHUY_ADMIN_PASSWORD", ""))
    # Secret mixed into stored IP hashes.
    ip_salt: str = field(default_factory=lambda: os.environ.get("PHUY_IP_SALT", "change-me"))
    # Rate limits: (max requests, window seconds)
    create_limit: tuple = (3, 3600)      # key creations per IP per hour
    validate_limit: tuple = (60, 60)
    reset_limit: tuple = (5, 3600)
    login_limit: tuple = (10, 900)
    login_max_failures: int = 5          # failures before lockout
    login_lockout_seconds: int = 900
    max_resets: int = 3
    session_ttl: int = 8 * 3600
    website_dir: str = field(default_factory=lambda: str(ROOT / "getkey-website"))
    cors_origins: list = field(default_factory=lambda: [
        o for o in os.environ.get("PHUY_CORS_ORIGINS", "").split(",") if o])
