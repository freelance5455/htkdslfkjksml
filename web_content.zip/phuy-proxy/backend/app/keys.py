"""Key lifecycle: create, validate, reset, revoke. All rules are enforced server-side."""
import sqlite3

from . import db
from .security import generate_key, new_secret_token, sha256_hex

DAY = 86400
ALLOWED_DAYS = (1, 7, 30)


class KeyError_(Exception):
    def __init__(self, code: str, message: str, http: int = 400):
        super().__init__(message)
        self.code, self.message, self.http = code, message, http


def _effective_status(row, now: int) -> str:
    if row["status"] == "REVOKED":
        return "REVOKED"
    if row["status"] == "EXPIRED" or row["expires_at"] <= now:
        return "EXPIRED"
    return "ACTIVE"


def _public(row, now: int) -> dict:
    return {
        "key": row["key_value"],
        "status": _effective_status(row, now),
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
        "seconds_left": max(0, row["expires_at"] - now),
        "duration_days": row["duration_days"],
        "resets_used": row["reset_count"],
        "resets_left": max(0, row["max_resets"] - row["reset_count"]),
    }


def _insert_unique_key(conn, now, owner_hash, days, reset_count, max_resets, ip_hash) -> int:
    # UNIQUE constraint is the real guard; on collision we simply generate again.
    for _ in range(20):
        value = generate_key()
        try:
            cur = conn.execute(
                "INSERT INTO keys(key_value, owner_token_hash, duration_days, status, created_at,"
                " expires_at, reset_count, max_resets, created_ip_hash)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (value, owner_hash, days, "ACTIVE", now, now + days * DAY, reset_count, max_resets, ip_hash))
            return cur.lastrowid
        except sqlite3.IntegrityError:
            continue
    raise KeyError_("key_generation_failed", "Could not generate a unique key", 500)


def create_key(path, now, days, max_resets, ip_hash):
    if days not in ALLOWED_DAYS:
        raise KeyError_("invalid_duration", "duration_days must be 1, 7 or 30")
    owner_token = new_secret_token()
    with db.transaction(path) as conn:
        key_id = _insert_unique_key(conn, now, sha256_hex(owner_token), days, 0, max_resets, ip_hash)
        conn.execute("INSERT INTO key_events(key_id,event,reason,actor,at) VALUES (?,?,?,?,?)",
                     (key_id, "CREATED", None, "user", now))
        row = conn.execute("SELECT * FROM keys WHERE id=?", (key_id,)).fetchone()
    out = _public(row, now)
    out["reset_token"] = owner_token   # shown ONCE; only its hash is stored
    return out


def _mark_expired(conn, row, now):
    if row["status"] == "ACTIVE" and row["expires_at"] <= now:
        conn.execute("UPDATE keys SET status='EXPIRED' WHERE id=? AND status='ACTIVE'", (row["id"],))
        conn.execute("INSERT INTO key_events(key_id,event,reason,actor,at) VALUES (?,?,?,?,?)",
                     (row["id"], "EXPIRED", "time", "system", now))


def get_status(path, now, key_value):
    with db.transaction(path) as conn:
        row = conn.execute("SELECT * FROM keys WHERE key_value=?", (key_value,)).fetchone()
        if not row:
            raise KeyError_("not_found", "Key not found", 404)
        _mark_expired(conn, row, now)
        row = conn.execute("SELECT * FROM keys WHERE id=?", (row["id"],)).fetchone()
    return _public(row, now)


def validate(path, now, key_value):
    try:
        info = get_status(path, now, key_value)
    except KeyError_ as e:
        if e.code == "not_found":
            return {"valid": False, "status": "INVALID"}
        raise
    return {"valid": info["status"] == "ACTIVE", "status": info["status"],
            "expires_at": info["expires_at"], "seconds_left": info["seconds_left"]}


def reset(path, now, key_value, *, owner_token=None, admin=None, reason="", days=None, ip_hash=None):
    """Replace a key with a fresh one inside one transaction.
    Authorisation: the owner secret issued at creation, OR an authenticated admin.
    Knowing the key string alone is never enough."""
    reason = (reason or "").strip()[:200]
    with db.transaction(path) as conn:
        row = conn.execute("SELECT * FROM keys WHERE key_value=?", (key_value,)).fetchone()
        if not row:
            raise KeyError_("not_found", "Key not found", 404)
        if admin is None:
            if not owner_token or sha256_hex(owner_token) != row["owner_token_hash"]:
                raise KeyError_("forbidden", "Not allowed to reset this key", 403)
        if row["status"] == "REVOKED":
            raise KeyError_("revoked", "Key was revoked or already reset", 409)
        if admin is None and row["reset_count"] >= row["max_resets"]:
            raise KeyError_("reset_limit", "Reset limit reached", 429)
        new_days = days if days in ALLOWED_DAYS else row["duration_days"]
        # 1) old key is disabled first ...
        conn.execute("UPDATE keys SET status='REVOKED', revoked_reason=? WHERE id=?",
                     ("RESET: " + reason if reason else "RESET", row["id"]))
        # 2) ... then the new key is created (same transaction, so both or neither)
        new_id = _insert_unique_key(conn, now, row["owner_token_hash"], new_days,
                                    row["reset_count"] + 1, row["max_resets"], ip_hash)
        conn.execute("UPDATE keys SET replaced_by=? WHERE id=?", (new_id, row["id"]))
        actor = f"admin:{admin}" if admin else "user"
        conn.execute("INSERT INTO key_events(key_id,event,reason,actor,at) VALUES (?,?,?,?,?)",
                     (row["id"], "RESET", reason or None, actor, now))
        conn.execute("INSERT INTO key_events(key_id,event,reason,actor,at) VALUES (?,?,?,?,?)",
                     (new_id, "CREATED", "reset", actor, now))
        new_row = conn.execute("SELECT * FROM keys WHERE id=?", (new_id,)).fetchone()
    return _public(new_row, now)


def revoke(path, now, key_value, admin, reason=""):
    reason = (reason or "").strip()[:200]
    with db.transaction(path) as conn:
        row = conn.execute("SELECT * FROM keys WHERE key_value=?", (key_value,)).fetchone()
        if not row:
            raise KeyError_("not_found", "Key not found", 404)
        if row["status"] == "REVOKED":
            return _public(row, now)
        conn.execute("UPDATE keys SET status='REVOKED', revoked_reason=? WHERE id=?",
                     (reason or "admin", row["id"]))
        conn.execute("INSERT INTO key_events(key_id,event,reason,actor,at) VALUES (?,?,?,?,?)",
                     (row["id"], "REVOKED", reason or None, f"admin:{admin}", now))
        row = conn.execute("SELECT * FROM keys WHERE id=?", (row["id"],)).fetchone()
    return _public(row, now)


def list_keys(path, now, limit=200):
    with db.reader(path) as conn:
        rows = conn.execute("SELECT * FROM keys ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [_public(r, now) for r in rows]


def history(path, key_value):
    with db.reader(path) as conn:
        row = conn.execute("SELECT id FROM keys WHERE key_value=?", (key_value,)).fetchone()
        if not row:
            raise KeyError_("not_found", "Key not found", 404)
        rows = conn.execute("SELECT event,reason,actor,at FROM key_events WHERE key_id=? ORDER BY id",
                            (row["id"],)).fetchall()
    return [dict(r) for r in rows]
