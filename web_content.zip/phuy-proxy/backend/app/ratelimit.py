"""In-memory sliding-window rate limiter and login lockout.

For multi-process deployments, move this state to Redis or the database.
"""
import threading
from collections import defaultdict, deque


class RateLimiter:
    def __init__(self, clock):
        self._clock = clock
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, bucket: str, ident: str, limit: tuple) -> bool:
        max_requests, window = limit
        now = self._clock()
        key = f"{bucket}:{ident}"
        with self._lock:
            q = self._hits[key]
            while q and q[0] <= now - window:
                q.popleft()
            if len(q) >= max_requests:
                return False
            q.append(now)
            return True


class LoginGuard:
    """Locks an (ip, username) pair after repeated failed admin logins."""

    def __init__(self, clock, max_failures: int, lockout_seconds: int):
        self._clock = clock
        self._max = max_failures
        self._lockout = lockout_seconds
        self._fails = {}
        self._lock = threading.Lock()

    def is_locked(self, ident: str) -> bool:
        with self._lock:
            entry = self._fails.get(ident)
            if not entry:
                return False
            count, until = entry
            if until and self._clock() < until:
                return True
            if until and self._clock() >= until:
                del self._fails[ident]
            return False

    def failure(self, ident: str) -> None:
        with self._lock:
            count, until = self._fails.get(ident, (0, 0))
            count += 1
            until = self._clock() + self._lockout if count >= self._max else until
            self._fails[ident] = (count, until)

    def success(self, ident: str) -> None:
        with self._lock:
            self._fails.pop(ident, None)
