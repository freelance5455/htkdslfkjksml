TAMU CATERERS ROYAL FOODS & EVENTS — WEBSITE PROTOTYPE

Files:
- index.html: mobile-friendly interactive prototype.

How to use:
1. Open index.html in Chrome or another modern browser.
2. Browse menu items, add food to the cart, change quantities, and create a food order request.
3. Use the booking form to request event catering or a custom quote.
4. Food orders and booking forms open WhatsApp with a pre-filled message to Tamu's first contact number.

Important:
- This is a prototype, not yet a published Android app or live business website.
- Menu and package prices are sample values and should be confirmed/edited before public launch.
- It does not process payments, save orders to a database, or provide an admin dashboard.
- The website uses an online Unsplash hero image; the rest of the interface works without a backend.
- The WhatsApp request links use 0713 057 857 (international format 254713057857).
- Before launch, verify contact numbers, menu prices, service availability, privacy terms, domain, hosting and Google Play requirements.
