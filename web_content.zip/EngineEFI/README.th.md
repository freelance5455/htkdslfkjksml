# EngineEFI (แพ็กเป็น APK / XAPK)

หน้าเว็บแอปหัวฉีด/ออกแบบเครื่อง (`app/src/main/assets/index.html`) ห่อด้วย WebView

## สร้างไฟล์ติดตั้ง (เลือกอย่างใดอย่างหนึ่ง)
1. **GitHub Actions (ง่ายสุด):** อัปโหลดโฟลเดอร์นี้ขึ้น GitHub repo → แท็บ Actions → Build APK + XAPK → ดาวน์โหลด artifact `EngineEFI` (ได้ `app-debug.apk` และ `EngineEFI.xapk`)
2. **Android Studio:** เปิดโฟลเดอร์นี้ → Build → Build APK(s) → ไฟล์อยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`
   แล้วรัน `python3 tools/make_xapk.py app-debug.apk EngineEFI.xapk` ถ้าต้องการ XAPK

แอปนี้มี APK เดียว ติดตั้ง `.apk` ตรง ๆ ได้เลย ไม่จำเป็นต้องใช้ XAPK (XAPK ใช้กับแอปที่แยกหลายไฟล์ เช่น KIRI Engine)

## ข้อจำกัดใน WebView
- USB Serial / Web Bluetooth (แท็บ “เชื่อมต่อ”, ปุ่มเชื่อมบอร์ด CYD) **ใช้ไม่ได้ในแอปนี้** ต้องเปิด `index.html` ใน Chrome แทน
- เลือกไฟล์โมเดล 3D (KIRI Engine / Zephyr) ใช้ได้ · ปุ่มดาวน์โหลดไฟล์ (เช่น CSV) อาจไม่ทำงาน
- ยังไม่ได้ทดสอบ build บนเครื่องจริง
