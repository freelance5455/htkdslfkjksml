#!/usr/bin/env python3
"""python3 make_xapk.py <app.apk> <out.xapk>  — wraps one APK in the APKPure/XAPK layout."""
import json, sys, zipfile
apk, out = sys.argv[1], sys.argv[2]
man = {"xapk_version": 2, "package_name": "th.mood.efi", "name": "ระบบหัวฉีด MOOD",
       "version_code": "1", "version_name": "1.0", "min_sdk_version": "24", "target_sdk_version": "34",
       "permissions": ["android.permission.INTERNET"],
       "split_apks": [{"file": "th.mood.efi.apk", "id": "base"}]}
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("manifest.json", json.dumps(man, ensure_ascii=False))
    z.write(apk, "th.mood.efi.apk")
print("wrote", out)
