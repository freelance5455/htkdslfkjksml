STAR DEFENDER — D3R CYBERTECH — VERSIONE 3
Correzione avanzamento livelli

COME AGGIORNARE
1. Scarica questo ZIP.
2. Estrai la cartella in una nuova posizione.
3. Apri index.html nel browser.
   Non aprire la vecchia copia: usa il file di questa versione.

CORREZIONE
L'avanzamento dei livelli non aspetta più che tutti i nemici siano spariti dallo schermo.
Quando raggiungi il punteggio obiettivo del livello, passa al successivo. Il boss continua a comparire ogni 4 livelli.

COMANDI
- Frecce o WASD: movimento
- SPAZIO: sparo
- ESC: pausa

FUNZIONI
Boss ogni 4 livelli con barra energia, raggio traente, doppio colpo, potenziamenti,
vite bonus, vita extra ogni 10.000 punti, esplosioni, classifica locale top 10,
schermata iniziale anni '80 e comandi touch su dispositivi compatibili.
