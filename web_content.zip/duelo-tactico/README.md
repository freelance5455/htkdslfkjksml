# Duelo Táctico (paquete para convertir a APK)

Contenido:
- www/index.html : el juego completo (un solo archivo).
- package.json y capacitor.config.json : para compilar el APK en una computadora.

## Paso 1 (recomendado): que funcione sin internet
El juego usa el motor 3D three.js versión r128. Descarga este archivo y guárdalo dentro de la carpeta www, junto a index.html, con el nombre three.min.js:

https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js

Si el archivo no está, el juego intenta bajarlo de internet al abrirse. Con el archivo puesto, la app funciona sin conexión.
(La fuente Teko se descarga de Google Fonts; sin internet se usa una fuente de respaldo y todo sigue funcionando.)

## Opción A: desde el celular, con un convertidor web
Servicios como WebIntoApp o Appsgeyser convierten una página web en APK. Algunos aceptan un archivo HTML o ZIP y otros piden una dirección web. Si piden dirección, sube la carpeta www a un hosting gratuito (por ejemplo Netlify Drop o GitHub Pages) y usa ese enlace. Elige orientación horizontal si te lo piden.

## Opción B: en una computadora con Android Studio
1. Instala Node.js y Android Studio.
2. Abre una terminal en esta carpeta y ejecuta:
   npm install
   npx cap add android
3. Para fijar la pantalla en horizontal, en android/app/src/main/AndroidManifest.xml agrega a la etiqueta <activity> el atributo:
   android:screenOrientation="sensorLandscape"
4. Ejecuta:
   npx cap sync
   npx cap open android
5. En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
   El APK queda en android/app/build/outputs/apk/debug/.

Para instalar el APK en tu teléfono, activa "instalar apps de origen desconocido" cuando Android lo pida.
