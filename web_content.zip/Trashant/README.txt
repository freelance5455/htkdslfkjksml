Trashant Shopping App
यह Amazon/Flipkart-style shopping prototype है।
Features: product search, Hindi voice search, cart, quantity controls और demo checkout.
