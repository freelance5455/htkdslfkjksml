WINDOWS PC INSTALLER BUILD INSTRUCTIONS

This package builds a Windows Setup .exe installer (not an APK). Use Windows 10/11 with Node.js 20+ and internet access for npm packages.

1. Extract this ZIP on a Windows PC.
2. Open PowerShell in the extracted folder.
3. Run: npm install
4. Run: npm run dist
5. Find the installer in the dist folder: Conversion-Feeds-INTRACO-Setup-1.0.0.exe
6. Run the installer and follow the prompts.

For a quick preview, run npm start after npm install. The app content is bundled locally and can work offline.
