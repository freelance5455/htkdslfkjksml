# LUZ — cómo generar el APK desde el móvil (sin ordenador)

## 1. Crea una cuenta en GitHub (gratis)
Desde el navegador del móvil: github.com → Sign up.

## 2. Crea un repositorio PRIVADO
- Botón "+" → "New repository".
- Nombre: `luz-app`.
- Marca **Private** (así solo tú tienes acceso).
- Create repository.

## 3. Sube estos archivos
- Dentro del repo, "Add file" → "Upload files".
- Arrastra/selecciona TODA la carpeta `LuzApp` que te he dado (todos los archivos y subcarpetas, incluida `.github`).
- Commit changes.

## 4. Que compile solo
- Ve a la pestaña "Actions" del repositorio.
- Debería aparecer un flujo llamado "Compilar LUZ APK" ejecutándose solo.
- Si no arranca, entra en él y pulsa "Run workflow".
- Espera unos 3-5 minutos.

## 5. Descarga el APK
- Cuando termine (check verde ✅), entra en esa ejecución.
- Abajo, en "Artifacts", descarga **LUZ-app** (es un .zip con el .apk dentro).
- Descomprímelo en el móvil (con cualquier app de archivos) y pulsa el .apk.

## 6. Instalar
- Android te pedirá activar "Instalar apps de fuentes desconocidas" para tu
  navegador o gestor de archivos. Actívalo solo para esa app.
- Instala. Al abrir LUZ, te pedirá los permisos (micrófono, SMS, contactos,
  notificaciones): acéptalos todos.

## Importante, léelo antes de usarla
- Esta es una PRIMERA VERSIÓN de prueba, no un producto terminado. Es normal
  que algo falle a la primera; vamos ajustándolo juntos.
- El envío de SMS SIEMPRE te pide confirmación en una ventana antes de mandar
  nada. No se envía nada solo.
- El reconocimiento de "LUZ" en segundo plano (con la pantalla apagada o
  usando otra app) no está incluido en esta versión: requiere un servicio de
  activación por voz mucho más elaborado. Se puede añadir en una siguiente
  vuelta si quieres.
- Repositorio privado = solo tú puedes verlo y descargarlo.
