package com.laachir.luz

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.PermissionRequest
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * LUZ - Actividad principal.
 * Carga la interfaz (assets/luz.html) dentro de un WebView y expone un puente
 * para que la interfaz pueda: pedir permisos, mandar SMS (SIEMPRE con tu
 * confirmación en pantalla), compartir por WhatsApp y hablar por voz nativa.
 *
 * IMPORTANTE: Android obliga a que el usuario acepte cada permiso peligroso a
 * mano. No existe forma de "dar acceso completo" sin que el sistema pregunte;
 * esta app simplemente los pide todos juntos al abrir para ir rápido.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null

    private val permisos: Array<String> by lazy {
        val base = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) base.add(Manifest.permission.POST_NOTIFICATIONS)
        base.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // Concede el micrófono dentro del propio WebView (getUserMedia)
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("es", "ES")
        }

        pedirPermisos()
        web.loadUrl("file:///android_asset/luz.html")
    }

    private fun pedirPermisos() {
        val faltan = permisos.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (faltan.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, faltan.toTypedArray(), 100)
        }
    }

    /** Puente que la interfaz web (luz.html) puede llamar con Android.xxx(...) */
    inner class Bridge {

        @JavascriptInterface
        fun hablarNativo(texto: String) {
            runOnUiThread { tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "luz") }
        }

        @JavascriptInterface
        fun compartirWhatsApp(texto: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.setPackage("com.whatsapp")
                i.putExtra(Intent.EXTRA_TEXT, texto)
                try {
                    startActivity(i)
                } catch (e: Exception) {
                    // WhatsApp no instalado: usamos el selector genérico de compartir
                    val generico = Intent(Intent.ACTION_SEND)
                    generico.type = "text/plain"
                    generico.putExtra(Intent.EXTRA_TEXT, texto)
                    startActivity(Intent.createChooser(generico, "Compartir vía"))
                }
            }
        }

        /**
         * Envía un SMS, pero SIEMPRE pide confirmación en una ventana nativa
         * antes de mandarlo. Nunca se envía nada sin que tú pulses "Enviar".
         */
        @JavascriptInterface
        fun enviarSMS(numero: String, mensaje: String) {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("LUZ quiere enviar un mensaje")
                    .setMessage("Para: $numero\n\n\"$mensaje\"")
                    .setPositiveButton("Enviar") { _, _ ->
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.SEND_SMS)
                            == PackageManager.PERMISSION_GRANTED) {
                            try {
                                SmsManager.getDefault().sendTextMessage(numero, null, mensaje, null, null)
                                Toast.makeText(this@MainActivity, "Mensaje enviado", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(this@MainActivity, "No se pudo enviar", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            pedirPermisos()
                        }
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }


        /**
         * Abre una app instalada por su nombre (ej: "whatsapp", "camara",
         * "youtube", "spotify"...). Busca entre las apps instaladas la que
         * más se parezca al nombre dicho, y la abre. Si no la encuentra,
         * devuelve false y la interfaz avisa de que no la tiene.
         */
        @JavascriptInterface
        fun abrirApp(nombre: String): Boolean {
            val pm = packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val objetivo = normaliza(nombre)

            // 1) coincidencia exacta o que empiece igual
            var elegido = apps.firstOrNull { normaliza(pm.getApplicationLabel(it).toString()) == objetivo }
                ?: apps.firstOrNull { normaliza(pm.getApplicationLabel(it).toString()).startsWith(objetivo) }
                ?: apps.firstOrNull { normaliza(pm.getApplicationLabel(it).toString()).contains(objetivo) }

            if (elegido == null) return false

            val intent = pm.getLaunchIntentForPackage(elegido.packageName) ?: return false
            runOnUiThread { startActivity(intent) }
            return true
        }


        /** Abre la ficha de la app en Play Store para instalarla (tú pulsas "Instalar"). */
        @JavascriptInterface
        fun instalarDePlayStore(nombre: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$nombre"))
                    startActivity(i)
                } catch (e: Exception) {
                    val i2 = Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/search?q=$nombre"))
                    startActivity(i2)
                }
            }
        }

        /** Pide desinstalar una app. Android SIEMPRE muestra su propia ventana de confirmación. */
        @JavascriptInterface
        fun desinstalarApp(nombre: String): Boolean {
            val pm = packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val objetivo = normaliza(nombre)
            val elegido = apps.firstOrNull { normaliza(pm.getApplicationLabel(it).toString()) == objetivo }
                ?: apps.firstOrNull { normaliza(pm.getApplicationLabel(it).toString()).contains(objetivo) }
                ?: return false
            runOnUiThread {
                val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:${elegido.packageName}"))
                startActivity(i)
            }
            return true
        }

        /** Abre el selector de archivos del sistema para que TÚ elijas y borres un archivo. */
        @JavascriptInterface
        fun borrarArchivo() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.type = "*/*"
                i.addCategory(Intent.CATEGORY_OPENABLE)
                startActivityForResult(i, 200)
            }
        }

        private fun normaliza(t: String): String =
            java.text.Normalizer.normalize(t.lowercase(), java.text.Normalizer.Form.NFD)
                .replace(Regex("\\p{Mn}+"), "")

        @JavascriptInterface
        fun tienePermiso(nombre: String): Boolean {
            val perm = when (nombre) {
                "microfono" -> Manifest.permission.RECORD_AUDIO
                "sms" -> Manifest.permission.SEND_SMS
                "contactos" -> Manifest.permission.READ_CONTACTS
                else -> return false
            }
            return ContextCompat.checkSelfPermission(this@MainActivity, perm) == PackageManager.PERMISSION_GRANTED
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 200 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            AlertDialog.Builder(this)
                .setTitle("LUZ quiere borrar este archivo")
                .setMessage(uri.lastPathSegment ?: uri.toString())
                .setPositiveButton("Borrar") { _, _ ->
                    try {
                        val ok = android.provider.DocumentsContract.deleteDocument(contentResolver, uri)
                        Toast.makeText(this, if (ok) "Archivo borrado" else "No se pudo borrar", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "No se pudo borrar", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
