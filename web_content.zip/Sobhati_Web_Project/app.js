const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const svg=p=>`<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
const IC={
  sun:svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>'),
  moon:svg('<path d="M20 14A8 8 0 1 1 10 4a7 7 0 0 0 10 10z"/>'),
  vol:svg('<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6"/>'),
  mute:svg('<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l4 6M21 9l-4 6"/>')
};
const CAT={tasbih:'تسبيح',morning:'الصباح والمساء',sleep:'النوم',prayer:'بعد الصلاة',dua:'أدعية'};
// [النص، التصنيف، التكرار (0 = حسب طول الدورة)، المصدر، الذكر التالي]
const D=[
['سُبْحَانَ اللَّهِ','tasbih',0,'ذكر مطلق'],
['الْحَمْدُ لِلَّهِ','tasbih',0,'ذكر مطلق'],
['اللَّهُ أَكْبَرُ','tasbih',0,'ذكر مطلق'],
['لَا إِلَهَ إِلَّا اللَّهُ','tasbih',0,'ذكر مطلق'],
['أَسْتَغْفِرُ اللَّهَ','tasbih',0,'استغفار'],
['لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ','tasbih',0,'متفق عليه'],
['سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ','tasbih',0,'متفق عليه'],
['اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ','tasbih',0,'الصلاة على النبي ﷺ'],
['سُبْحَانَ اللَّهِ','prayer',33,'تسبيح ما بعد الصلاة — رواه مسلم',9],
['الْحَمْدُ لِلَّهِ','prayer',33,'تسبيح ما بعد الصلاة — رواه مسلم',10],
['اللَّهُ أَكْبَرُ','prayer',34,'تسبيح ما بعد الصلاة — رواه مسلم'],
['أَسْتَغْفِرُ اللَّهَ','prayer',3,'عقب السلام — رواه مسلم',12],
['اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ','prayer',1,'رواه مسلم'],
['اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ، لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ، لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ، مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ، يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ، وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ، وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ، وَلَا يَئُودُهُ حِفْظُهُمَا، وَهُوَ الْعَلِيُّ الْعَظِيمُ','morning',1,'آية الكرسي — البقرة: 255'],
['أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ','morning',1,'ذكر الصباح — رواه مسلم'],
['اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ','morning',1,'سيد الاستغفار — رواه البخاري'],
['بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ','morning',3,'رواه أبو داود والترمذي'],
['سُبْحَانَ اللَّهِ وَبِحَمْدِهِ','morning',100,'رواه مسلم'],
['أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ','morning',3,'ذكر المساء — رواه مسلم'],
['بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا','sleep',1,'رواه البخاري'],
['اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ','sleep',3,'رواه أبو داود'],
['رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ','dua',1,'البقرة: 201'],
['رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي','dua',1,'طه: 25–26'],
['لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ','dua',1,'الأنبياء: 87'],
['اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ','dua',1,'رواه أبو داود وابن ماجه']
];
const dhikrs=D.map(([text,cat,rep,source,next],id)=>({id,text,cat,rep,source,next}));
const strip=s=>s.replace(/[\u064B-\u0652\u0670]/g,'');
const key=d=>d.toLocaleDateString('en-CA');
const todayKey=()=>key(new Date());
const DEFAULTS={counts:{},days:{},total:0,goal:100,beads:33,sound:true,vibrate:false,theme:'dark',dhikr:0,autoNext:true,sessions:[],sessionTotal:0,goalDate:''};
function loadState(){let s={};try{s=JSON.parse(localStorage.getItem('sobhati-state')||'{}')||{}}catch(e){}return migrate(s)}
function migrate(s){
  s={...DEFAULTS,...s};
  if(typeof s.dhikr==='string'){const f=dhikrs.find(d=>strip(d.text)===strip(s.dhikr));s.dhikr=f?f.id:0}
  if(!dhikrs[s.dhikr])s.dhikr=0;
  if(s.count&&!Object.keys(s.counts||{}).length)s.counts={[s.dhikr]:s.count};
  if(s.today&&s.date&&!Object.keys(s.days||{}).length)s.days={[s.date]:s.today};
  if(typeof s.counts!=='object'||!s.counts)s.counts={};
  if(typeof s.days!=='object'||!s.days)s.days={};
  if(!Array.isArray(s.sessions))s.sessions=[];
  s.sessionTotal=Math.max(s.sessionTotal||0,s.sessions.length);
  delete s.count;delete s.today;delete s.date;
  return s;
}
let state=loadState();
const taps=[];
const save=()=>{try{localStorage.setItem('sobhati-state',JSON.stringify(state))}catch(e){}};
const curD=()=>dhikrs[state.dhikr]||dhikrs[0];
const cycle=d=>d.cat==='tasbih'||!d.rep?state.beads:d.rep;
const today=()=>state.days[todayKey()]||0;
const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const short=(s,n=34)=>s.length>n?s.slice(0,n)+'…':s;

function showToast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove('show'),2000)}
function ask(msg){return new Promise(r=>{const dlg=$('#confirmDialog');$('#confirmMsg').textContent=msg;dlg.onclose=()=>r(false);const end=v=>{dlg.onclose=null;dlg.close();r(v)};$('#confirmYes').onclick=()=>end(true);$('#confirmNo').onclick=()=>end(false);dlg.showModal()})}

function streak(){let n=0;const d=new Date();if(!state.days[key(d)])d.setDate(d.getDate()-1);while(state.days[key(d)]>0){n++;d.setDate(d.getDate()-1)}return n}

function renderBeads(n,lit){
  const loop=$('#beadLoop'),v=n<11?33:Math.min(n,99);
  if(loop.children.length!==v){loop.innerHTML='';for(let i=0;i<v;i++){const b=document.createElement('i');b.className='bead';const a=(i/v)*Math.PI*2-Math.PI/2;b.style.left=(50+47*Math.cos(a))+'%';b.style.top=(50+43*Math.sin(a))+'%';b.style.width=b.style.height=(v>66?'15px':'18px');loop.appendChild(b)}}
  const on=Math.round(lit/n*v);
  [...loop.children].forEach((b,i)=>b.classList.toggle('on',i<on));
}
function renderWeek(){
  const vals=[],now=new Date();
  for(let i=6;i>=0;i--){const d=new Date(now);d.setDate(d.getDate()-i);vals.push([state.days[key(d)]||0,d.toLocaleDateString('ar-EG',{weekday:'short'})])}
  const max=Math.max(1,...vals.map(v=>v[0]));
  $('#weekChart').innerHTML=vals.map(([v,l])=>`<div class="${v?'':'zero'}"><span>${v||''}</span><i style="height:${Math.max(3,Math.round(v/max*70))}px"></i><span>${l}</span></div>`).join('');
}
function renderHistory(){
  const box=$('#historyList');
  if(!state.sessions.length){box.innerHTML='<p class="empty-state">ابدأ التسبيح وسيظهر سجلك هنا.</p>';return}
  box.innerHTML=state.sessions.slice(0,12).map(s=>`<div class="history-item"><div><strong>${escapeHtml(short(s.dhikr||'تسبيح'))}</strong><br><span>${new Date(s.end||s.date).toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'short'})}</span></div><strong>+${s.count||1}</strong></div>`).join('');
}
function render(){
  const d=curD(),n=cycle(d),c=state.counts[d.id]||0,t=today(),lit=c?((c-1)%n)+1:0;
  const pct=Math.min(100,Math.round(t/state.goal*100));
  $('#count').textContent=c;
  $('#selectedDhikr').textContent=d.text;
  $('#caption').textContent=`${lit} / ${n}`+(c>=n?` · ${Math.floor(c/n)} دورة مكتملة`:'');
  $('#progressCount').textContent=t;$('#goalLabel').textContent=state.goal;
  $('#progressBar').style.width=Math.min(100,t/state.goal*100)+'%';
  $('#goalDone').textContent=t;$('#goalCurrent').textContent=state.goal;$('#goalPercent').textContent=pct+'%';
  $('#goalRing').style.background=`conic-gradient(var(--gold) ${pct*3.6}deg,rgba(216,181,107,.14) 0deg)`;
  $('#totalCount').textContent=state.total.toLocaleString('en-US');
  $('#todayCount').textContent=t.toLocaleString('en-US');
  $('#streak').textContent=streak();
  $('#soundLabel').textContent=state.sound?'صوت':'صامت';
  $('#soundIcon').innerHTML=state.sound?IC.vol:IC.mute;
  $('#soundBtn').classList.toggle('sound-on',state.sound);
  $('#vibrateBtn').classList.toggle('sound-on',state.vibrate);
  $('#soundToggle').checked=state.sound;$('#vibrateToggle').checked=state.vibrate;$('#autoNextToggle').checked=state.autoNext;
  $('#themeSelect').value=state.theme;
  const preset=['33','66','99'].includes(String(state.beads));
  $('#beadCount').value=preset?String(state.beads):'custom';
  $('#customBeadRow').hidden=preset;
  if(document.activeElement!==$('#customBeadCount'))$('#customBeadCount').value=state.beads;
  $$('[data-goal]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.goal)===Number(state.goal)));
  renderBeads(n,lit);renderWeek();renderHistory();
}

function click(f,vol){
  try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const ctx=click.ctx||(click.ctx=new C());if(ctx.state==='suspended')ctx.resume();
  const now=ctx.currentTime,o=ctx.createOscillator(),g=ctx.createGain(),h=ctx.createBiquadFilter();
  o.type='triangle';o.frequency.setValueAtTime(f,now);o.frequency.exponentialRampToValueAtTime(620,now+.035);
  h.type='highpass';h.frequency.value=650;g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(vol,now+.003);g.gain.exponentialRampToValueAtTime(.0001,now+.055);
  o.connect(h);h.connect(g);g.connect(ctx.destination);o.start(now);o.stop(now+.06)}catch(e){}
}
function feedback(done){
  if(state.sound){click(1750+Math.random()*500,.11);if(done)setTimeout(()=>click(1100,.16),110)}
  if(state.vibrate&&navigator.vibrate)navigator.vibrate(done?[40,60,90]:12);
}
let wl=null,wantWake=false;
async function keepAwake(){wantWake=true;try{if(!wl&&navigator.wakeLock){wl=await navigator.wakeLock.request('screen');wl.addEventListener('release',()=>wl=null)}}catch(e){}}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&wantWake)keepAwake()});

function logSession(d){
  const now=new Date(),s=state.sessions[0];
  if(s&&s.id===d.id&&now-new Date(s.end)<10*60*1000){s.count++;s.end=now.toISOString()}
  else{state.sessions.unshift({id:d.id,dhikr:d.text,start:now.toISOString(),end:now.toISOString(),count:1});state.sessionTotal++;if(state.sessions.length>60)state.sessions.length=60}
}
function tap(){
  const d=curD(),n=cycle(d),k=todayKey(),c=(state.counts[d.id]||0)+1;
  state.counts[d.id]=c;state.total++;state.days[k]=(state.days[k]||0)+1;logSession(d);
  taps.push({id:d.id,k});if(taps.length>200)taps.shift();
  const done=c%n===0;
  feedback(done);keepAwake();
  $('#tasbihBtn').classList.add('pulse');setTimeout(()=>$('#tasbihBtn').classList.remove('pulse'),90);
  if(state.days[k]===state.goal&&state.goalDate!==k){state.goalDate=k;showToast('ما شاء الله، أتممت هدفك اليوم!')}
  else if(done)showToast('أتممت دورة: '+n);
  save();render();
  if(done&&state.autoNext&&d.next!=null)setTimeout(()=>{state.dhikr=d.next;save();render();showToast('التالي: '+short(dhikrs[d.next].text,24))},900);
}
function undo(){
  const t=taps.pop();if(!t)return showToast('لا يوجد ما يمكن التراجع عنه');
  if((state.counts[t.id]||0)>0)state.counts[t.id]--;
  state.total=Math.max(0,state.total-1);state.days[t.k]=Math.max(0,(state.days[t.k]||0)-1);
  const s=state.sessions[0];if(s&&s.id===t.id){s.count--;if(s.count<=0){state.sessions.shift();state.sessionTotal=Math.max(0,state.sessionTotal-1)}}
  if(state.dhikr!==t.id)state.dhikr=t.id;
  save();render();showToast('تم التراجع');
}

function renderAdhkar(filter='all'){
  $('#adhkarList').innerHTML=dhikrs.filter(d=>filter==='all'||d.cat===filter).map(d=>`<article class="dhikr-card"><p>${escapeHtml(d.text)}</p><div class="dhikr-meta"><span>${escapeHtml(d.source)}${d.cat!=='tasbih'?' · التكرار: '+d.rep:''}</span><button data-pick="${d.id}">ابدأ العدّ</button></div></article>`).join('');
  $$('[data-pick]').forEach(b=>b.addEventListener('click',()=>{state.dhikr=+b.dataset.pick;save();render();navigate('home');showToast('تم اختيار الذكر')}));
}
function renderChoose(){
  $('#chooseList').innerHTML=dhikrs.map(d=>`<button class="choose-item" data-choose="${d.id}">${escapeHtml(short(d.text,60))} <small>${CAT[d.cat]}</small></button>`).join('');
  $$('[data-choose]').forEach(b=>b.onclick=()=>{state.dhikr=+b.dataset.choose;save();render();$('#chooseDialog').close()});
}
function navigate(name){
  $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+name));
  $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.nav===name));
  window.scrollTo({top:0,behavior:'smooth'});
}
function applyTheme(){
  const t=state.theme==='system'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):state.theme;
  document.body.classList.toggle('light',t==='light');$('#themeBtn').innerHTML=t==='light'?IC.moon:IC.sun;
}

$$('[data-nav]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.nav)));
$('#beadsStage').addEventListener('pointerdown',e=>{e.preventDefault();tap()});
$('#tasbihBtn').addEventListener('click',e=>{if(e.detail===0)tap()});
$('#undoBtn').addEventListener('click',undo);
$('#resetBtn').addEventListener('click',async()=>{const d=curD();if(await ask('تصفير عدّاد «'+short(d.text,28)+'»؟ تبقى إحصائياتك كما هي.')){state.counts[d.id]=0;save();render();showToast('تم التصفير')}});
$('#soundBtn').addEventListener('click',()=>{state.sound=!state.sound;save();render();if(state.sound)click(1800,.11)});
$('#vibrateBtn').addEventListener('click',()=>{state.vibrate=!state.vibrate;save();render();if(state.vibrate&&navigator.vibrate)navigator.vibrate(20);showToast(state.vibrate?'تم تشغيل الاهتزاز':'تم إيقاف الاهتزاز')});
$('#chooseDhikr').addEventListener('click',()=>{renderChoose();$('#chooseDialog').showModal()});
$('#themeBtn').addEventListener('click',()=>{state.theme=document.body.classList.contains('light')?'dark':'light';applyTheme();save();render()});
matchMedia('(prefers-color-scheme: light)').addEventListener?.('change',()=>{if(state.theme==='system')applyTheme()});
$('#themeSelect').addEventListener('change',e=>{state.theme=e.target.value;applyTheme();save()});
$('#soundToggle').addEventListener('change',e=>{state.sound=e.target.checked;save();render()});
$('#vibrateToggle').addEventListener('change',e=>{state.vibrate=e.target.checked;save();render()});
$('#autoNextToggle').addEventListener('change',e=>{state.autoNext=e.target.checked;save()});
$('#beadCount').addEventListener('change',e=>{const v=e.target.value;state.beads=v==='custom'?Math.max(11,Math.min(199,Number($('#customBeadCount').value)||45)):Number(v);save();render()});
$('#customBeadCount').addEventListener('change',e=>{state.beads=Math.max(11,Math.min(199,Math.round(Number(e.target.value))||45));save();render()});
$$('[data-goal]').forEach(b=>b.addEventListener('click',()=>{state.goal=Number(b.dataset.goal);save();render()}));
$('#saveGoal').addEventListener('click',()=>{const n=Number($('#customGoal').value);if(!Number.isInteger(n)||n<1||n>100000)return showToast('اكتب هدفًا بين 1 و100000');state.goal=n;$('#customGoal').value='';save();render();showToast('تم حفظ الهدف')});
$$('#adhkarTabs .tab').forEach(b=>b.addEventListener('click',()=>{$$('#adhkarTabs .tab').forEach(x=>x.classList.toggle('active',x===b));renderAdhkar(b.dataset.filter)}));
$('#clearHistory').addEventListener('click',async()=>{if(await ask('مسح سجل الجلسات؟ لن يتأثر إجمالي تسبيحاتك.')){state.sessions=[];save();render();showToast('تم مسح السجل')}});
$('#exportBtn').addEventListener('click',()=>{
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state)],{type:'application/json'}));
  a.download='sobhati-backup-'+todayKey()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);showToast('تم تجهيز النسخة الاحتياطية');
});
$('#importFile').addEventListener('change',e=>{
  const f=e.target.files[0];if(!f)return;const r=new FileReader();
  r.onload=async()=>{try{const o=JSON.parse(r.result);if(!o||typeof o.total!=='number')throw 0;
    if(await ask('استبدال بياناتك الحالية بالنسخة المستوردة؟')){state=migrate(o);save();applyTheme();render();showToast('تم استيراد النسخة')}}
    catch(err){showToast('الملف غير صالح')}e.target.value=''};
  r.readAsText(f);
});
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
applyTheme();render();renderAdhkar();
