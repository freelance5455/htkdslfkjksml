// Run after "npx cap add android": sets minSdkVersion to 24 (Android 7.0+)
const fs = require('fs');
const f = 'android/variables.gradle';
let t = fs.readFileSync(f, 'utf8');
t = t.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 24');
fs.writeFileSync(f, t);
console.log('minSdkVersion set to 24');
