# Arrow Escape: Play Store build guide

The game lives in `www/index.html`. It is a single file, and Capacitor wraps it into an Android app.

## 1. Install (once)
- Node.js 18+ and Android Studio (https://developer.android.com/studio)

## 2. Build the Android project
```
npm install
npm run setup   # adds Android and sets minSdkVersion to 24
npm run open
```
Before this, change `appId` in `capacitor.config.json` to your own unique id (for example `com.yourname.arrowescape`). It cannot be changed after you publish.

## 3. Fonts offline
`index.html` loads the Fredoka font from Google Fonts. Without internet it falls back to the system font, and the game still works.

## 4. Full screen
In Android Studio open `android/app/src/main/res/values/styles.xml`. Inside `AppTheme.NoActionBar` add:
`<item name="android:windowFullscreen">true</item>`
Also add `android:screenOrientation="portrait"` to the `<activity>` tag in `AndroidManifest.xml`.

## 5. Icon
Use Android Studio: right-click `res` > New > Image Asset, then pick `www/icon-512.png`.

## 6. Make the signed AAB
Android Studio > Build > Generate Signed Bundle / APK > Android App Bundle. Create a keystore and **back it up safely**. Google Play requires the `.aab` file.

## 7. Upload
1. Create a Play Console developer account (one-time $25 fee).
2. Create app > upload the `.aab` to a Production or Testing track.
3. Fill in the store listing: a 512x512 icon, a 1024x500 feature graphic, at least 2 phone screenshots, a description, and a privacy policy URL (required).
4. Complete Content rating, Data safety (the game collects no data) and Target audience.
5. New personal accounts must run a closed test with 12+ testers for 14 days before Production.

Set `targetSdkVersion` to the level Play Console currently requires (check the Play Console message).
