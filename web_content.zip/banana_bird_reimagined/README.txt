BANANA BIRD: NIGHT TERRORS

To play on your Android/Infinix phone:
1. Extract the ZIP.
2. Open index.html with your browser (Chrome works well).

New in this version:
- Title screen with PLAY and BIRD SKIN SHOP buttons.
- Separate scrollable shop with a preview icon, price, and BUY/SELECT action for each bird.
- Play screen lets you choose skins you already own.
- ATTACK button fires feather-energy shots; keyboard X or F also attacks.
- Defeating monsters earns 5 Banana Bux. Collecting tapes earns 10 Bux; clearing a level earns 25 Bux.
- Seven bird skins and 30 levels remain included.

Wallet and owned skins are saved in your browser's local storage. The game is a browser game, not an APK.
Controls: ◀ ▶ to move, JUMP to jump, ATTACK to shoot. Keyboard: A/D or arrows, Space to jump, X/F to attack.
