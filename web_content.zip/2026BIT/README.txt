2026BIT — HTML prototype
=========================

FILES
- index.html: the 2026BIT student community prototype.
- README.txt: this guide.

HOW TO OPEN
1. Extract 2026BIT.zip on your phone or computer.
2. Open index.html in a modern browser (Chrome recommended).
3. Create an account and explore the pages.

INCLUDED IN THIS PROTOTYPE
- Registration and login (local demo accounts)
- Six module cards and module-specific posts
- Community feed with posts, likes, comments, and attachments
- Chats, group chat rooms, and local message history
- Notifications and announcement form using the requested demo password 0987
- Profile editing and photo, password change, data export, and logout
- Search for users and posts
- Responsive mobile-first dark interface with blue, black, yellow, white, and gold accents

IMPORTANT LIMITATIONS
This is a front-end prototype, not a live online messaging service. Data is stored in the current browser's local storage and is not synced between phones or users. Chats and module groups are local demonstrations. Attachments are limited to 1.5 MB in this demo and browser storage may fill up.

The announcement password 0987 is included for demonstration only. It is visible in the HTML/JavaScript and is NOT secure. Before public release, connect a backend (for example Firebase Authentication, Firestore, Storage, and server-side admin authorization), add appropriate security rules, and configure push notifications.

For Android APK packaging, the project can later be wrapped with Capacitor and built using Android Studio.
