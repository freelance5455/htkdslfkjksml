package com.foccusluan.panel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    companion object {
        const val ACTION_STOP = "com.foccusluan.panel.STOP_FLOATING"
        private const val CHANNEL_ID = "foccus_floating"
        private const val NOTIFICATION_ID = 701
    }

    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelVisible = false
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startAsForeground()
        createBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) createBubble()
        return START_STICKY
    }

    private fun startAsForeground() {
        val stopIntent = Intent(this, FloatingService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 10, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("FOCCUS LUAN ativo")
                .setContentText("O botão flutuante está disponível.")
                .setOngoing(true)
                .addAction(Notification.Action.Builder(null, "Parar flutuante", stopPending).build())
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("FOCCUS LUAN ativo")
                .setContentText("O botão flutuante está disponível.")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopPending)
                .build()
        }

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "FOCCUS LUAN — flutuante",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun overlayParams(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    private fun createBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "FL"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(24, 24, 24), dp(30), Color.rgb(37, 214, 173), dp(2))
            elevation = dp(8).toFloat()
        }
        bubbleParams = overlayParams(dp(58), dp(58)).apply {
            x = dp(14)
            y = dp(220)
        }
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > dp(4) || kotlin.math.abs(dy) > dp(4)) dragged = true
                    if (dragged) {
                        bubbleParams.x = (startX + dx).coerceAtLeast(0)
                        bubbleParams.y = (startY + dy).coerceAtLeast(0)
                        try { windowManager.updateViewLayout(view, bubbleParams) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) togglePanel()
                    true
                }
                else -> true
            }
        }
        bubble = view
        try {
            windowManager.addView(view, bubbleParams)
        } catch (_: Exception) {
            bubble = null
            stopSelf()
        }
    }

    private fun togglePanel() {
        if (panelVisible) removePanel() else showPanel()
    }

    private fun showPanel() {
        if (panelVisible) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = rounded(Color.rgb(16, 16, 16), dp(12), Color.rgb(65, 65, 65), dp(1))
            elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "FOCCUS LUAN"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val close = Button(this).apply {
            text = "×"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { removePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(38), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(38)))
        box.addView(header)
        addDivider(box)

        addToggle(box, "Magic Aim • indicador", false)
        addToggle(box, "Scope Lock • indicador", false)
        addToggle(box, "Lock Fire • indicador", false)
        addToggle(box, "Desativar todos", false)
        addDivider(box)

        val info = TextView(this).apply {
            text = "Controles demonstrativos. Não modificam o jogo nem automatizam mira ou disparos."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(info)

        val open = Button(this).apply {
            text = "Abrir criador de sensibilidade"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(170, 15, 24), dp(8))
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                if (launch != null) startActivity(launch)
                removePanel()
            }
        }
        box.addView(open, LinearLayout.LayoutParams(-1, dp(46)))

        val stop = Button(this).apply {
            text = "Desligar botão flutuante"
            setTextColor(Color.LTGRAY)
            background = rounded(Color.rgb(38, 38, 38), dp(8))
            setOnClickListener { stopSelf() }
        }
        val stopLp = LinearLayout.LayoutParams(-1, dp(42))
        stopLp.topMargin = dp(7)
        box.addView(stop, stopLp)

        val params = overlayParams(dp(300), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            val metrics = resources.displayMetrics
            x = (metrics.widthPixels - dp(314)).coerceAtLeast(0)
            y = (bubbleParams.y - dp(100)).coerceAtLeast(dp(12))
        }
        panel = box
        panelParams = params
        try {
            windowManager.addView(box, params)
            panelVisible = true
        } catch (_: Exception) {
            panel = null
            panelVisible = false
            Toast.makeText(this, "Não foi possível abrir o painel flutuante.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addToggle(parent: LinearLayout, label: String, initial: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(2), dp(8))
        }
        val text = TextView(this).apply {
            this.text = label
            textSize = 13f
            setTextColor(Color.WHITE)
        }
        val toggle = Switch(this).apply {
            isChecked = initial
            buttonTintList = null
        }
        row.addView(text, LinearLayout.LayoutParams(0, dp(38), 1f))
        row.addView(toggle, LinearLayout.LayoutParams(dp(54), dp(38)))
        parent.addView(row)
    }

    private fun addDivider(parent: LinearLayout) {
        val line = View(this).apply { setBackgroundColor(Color.rgb(48, 48, 48)) }
        parent.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun removePanel() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        panelParams = null
        panelVisible = false
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int? = null, strokeWidth: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != null) setStroke(strokeWidth, strokeColor)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removePanel()
        bubble?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
