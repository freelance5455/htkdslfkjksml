# CPLS V2 — Stage 1148

## Feed Health Telemetry
- Adds a deterministic feed-health state derived from existing candle gaps, freshness, sample density, and cadence confidence.
- Exposes `window.__cpFuturesTelemetry` for diagnostics without changing the price source or fabricating candles.
- Tracks HEALTHY / FAIR / UNSTABLE / THIN / GAPPED / STALE states and cadence score/age metrics.
- Keeps the existing LBank REST Futures feed, candle integrity, live continuity, zoom/pan, and WebSocket diagnostic behavior unchanged.
- Stores telemetry in the page only; no private keys or trading credentials are involved.

Source ZIP stage only; APK build not performed.
