ARMAN WALLET HTML VERSION

1. index.html ko phone/computer ke browser mein open karke demo chala sakte ho.
2. ZIP ko extract karke index.html file kholo.
3. Camera QR scanner ke liye modern browser aur camera permission chahiye; localhost ya HTTPS par behtar chalega.
4. Add/Withdraw sirf demo balance badalte hain. Receive QR bhi sample hai.
5. Is file mein real UPI payment, bank transfer ya real wallet balance nahi hai.
6. Android APK banane ke liye is HTML ko Android Studio WebView project ya kisi trusted HTML-to-APK wrapper mein package karna hoga. Kisi unknown website par personal/bank details mat dena.
