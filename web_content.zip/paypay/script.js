const app=document.getElementById("app"),toastEl=document.getElementById("toast");
let logged=false, isAdmin=false, user={name:"Demo User",mobile:"9876543210",password:"123456",wallet:5000},tx=[];
const ADMIN_MOBILE="7488053580", ADMIN_PASSWORD="sahiltoppo03@";

const esc=x=>String(x).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const money=x=>"₹"+Number(x).toFixed(2);
function toast(x){toastEl.textContent=x;toastEl.classList.add("show");clearTimeout(window.t);window.t=setTimeout(()=>toastEl.classList.remove("show"),2200)}
function addTx(type,to,amount){tx.unshift({type,to,amount,id:"PP"+Date.now(),date:new Date().toLocaleString()})}

function loginPage(){logged=false;app.innerHTML=`<div class="auth"><div class="card">
<div class="logo"><b>P</b><h1>PayPay</h1></div><h2>Welcome Back</h2><p>Login to your PayPay account</p>
<form id="lf"><label>Mobile Number</label><input id="lm" type="tel" maxlength="10" required>
<label>Password</label><input id="lp" type="password" required><button class="primary">Login</button></form>
<div class="or">OR</div><button class="secondary" id="reg">Not registered? Register</button>
<small>User demo: 9876543210 / 123456</small>
<small>Admin demo: 7488053580 / sahiltoppo03@</small></div></div>`;
document.getElementById("lf").onsubmit=e=>{e.preventDefault();let m=lm.value.trim(),p=lp.value;if(!/^[0-9]{10}$/.test(m))return toast("Enter valid 10-digit number");
if(m===ADMIN_MOBILE&&p===ADMIN_PASSWORD){logged=true;isAdmin=true;toast("Admin login successful");setTimeout(adminPage,300);return}
if((m==="9876543210"&&p==="123456")||(m===user.mobile&&p===user.password)){logged=true;isAdmin=false;if(m==="9876543210")user={name:"Demo User",mobile:m,password:p,wallet:5000};toast("Login successful");setTimeout(home,300)}else toast("Invalid mobile number or password")};document.getElementById("reg").onclick=registerPage}

function adminPage(){if(!logged||!isAdmin)return loginPage();app.innerHTML=`<div class="page"><header><h2>PayPay Admin</h2><button id="bell">🔔</button></header><main>
<section class="welcome"><p>Administrator access</p><h2>Admin Dashboard</h2><p>Signed in as +91 ${ADMIN_MOBILE}</p></section>
<section class="cardform"><h3>Admin Controls</h3><button class="primary" id="users">👥 User Management</button><button class="secondary" id="reports">📊 Reports</button><button class="secondary" id="settings">⚙️ App Settings</button><button class="danger" id="logout">🚪 Logout</button></section>
</main></div>`;
document.getElementById("bell").onclick=()=>toast("No new notifications");
document.getElementById("users").onclick=()=>toast("User management demo");
document.getElementById("reports").onclick=()=>toast("Reports demo");
document.getElementById("settings").onclick=()=>toast("App settings demo");
document.getElementById("logout").onclick=logout} 

function registerPage(){app.innerHTML=`<div class="auth"><div class="card"><div class="logo"><b>P</b><h1>PayPay</h1></div><h2>Create Account</h2>
<form id="rf"><label>Full Name</label><input id="rn" required><label>Mobile Number</label><input id="rm" maxlength="10" required>
<label>Password</label><input id="rp" type="password" required><label>Confirm Password</label><input id="rc" type="password" required>
<button class="primary">Register</button></form><button class="secondary" id="back">Already registered? Login</button></div></div>`;
document.getElementById("back").onclick=loginPage;document.getElementById("rf").onsubmit=e=>{e.preventDefault();if(!/^[0-9]{10}$/.test(rm.value))return toast("Enter valid mobile");if(rp.value.length<6)return toast("Password needs 6 characters");if(rp.value!==rc.value)return toast("Passwords do not match");user={name:rn.value.trim(),mobile:rm.value.trim(),password:rp.value,wallet:5000};toast("Registration successful");setTimeout(loginPage,500)}}

function shell(content){if(!logged)return loginPage();app.innerHTML=`<div class="page"><header><button id="menu">☰</button><h2>PayPay</h2><button id="bell">🔔</button></header><main>${content}</main>
<nav><button data-n="home">🏠<span>Home</span></button><button data-n="wallet">💰<span>Wallet</span></button><button data-n="scan">📷<span>Scan</span></button><button data-n="transactions">📄<span>Transactions</span></button><button data-n="profile">👤<span>Profile</span></button></nav>
<div id="drawer"><aside><div class="dh"><b>PayPay</b><button id="close">✕</button></div>
<button data-p="profile">👤 Profile</button><button data-p="wallet">💰 Wallet</button><button data-p="scan">📷 Scan & Pay</button><button data-p="transactions">📄 Transactions</button><button data-p="bank">🏦 Bank Account</button><button data-p="cards">💳 Cards</button><button data-p="security">🔐 Security</button><button data-p="help">❓ Help</button><button data-p="about">ℹ️ About</button><button id="logout" class="danger">🚪 Logout</button></aside></div></div>`;
document.getElementById("menu").onclick=()=>drawer.classList.add("open");document.getElementById("close").onclick=()=>drawer.classList.remove("open");document.getElementById("bell").onclick=()=>toast("No new notifications");document.getElementById("logout").onclick=logout;
document.querySelectorAll("[data-n]").forEach(b=>b.onclick=()=>go(b.dataset.n));document.querySelectorAll("[data-p]").forEach(b=>b.onclick=()=>{drawer.classList.remove("open");go(b.dataset.p)})}

const svc=(i,n,r)=>`<button class="svc" data-r="${r}"><b>${i}</b><span>${n}</span></button>`;
function home(){shell(`<section class="welcome"><p>Welcome back</p><h2>${esc(user.name)}</h2><p>+91 ${esc(user.mobile)}</p><small>PayPay ID: PP-${esc(user.mobile)}</small></section>
<section class="wallet"><p>Wallet Balance</p><h1>${money(user.wallet)}</h1><button id="openWallet">Open Wallet</button></section><h3>Services</h3><section class="grid">
${svc("📱","Mobile Pay","send")}${svc("💳","UPI Pay","upi")}${svc("💰","Self Pay","self")}${svc("🏦","Add Bank","bank")}${svc("🎁","Redeem","redeem")}${svc("📷","QR Scanner","scan")}${svc("🔄","Auto Pay","autopay")}${svc("📱","Recharge","recharge")}${svc("💸","Send Money","send")}${svc("💵","Receive","receive")}${svc("🔳","Scan & Pay","scan")}${svc("🏦","Bank Transfer","transfer")}${svc("🧾","Bills","bills")}${svc("⚡","Electricity","bills")}${svc("📺","DTH","bills")}${svc("🌐","Broadband","bills")}${svc("🚗","FASTag","bills")}${svc("🛡️","Insurance","bills")}${svc("🎓","Education","bills")}${svc("🎁","Gift Cards","offers")}${svc("📄","Transactions","transactions")}${svc("🔥","Offers","offers")}${svc("❓","Help","help")}</section>`);
document.getElementById("openWallet").onclick=()=>go("wallet");document.querySelectorAll(".svc").forEach(b=>b.onclick=()=>go(b.dataset.r))}

function back(){home()}
function wallet(){shell(`<button class="back" id="b">← Back</button><h2>Wallet</h2><section class="wallet"><p>Available Balance</p><h1>${money(user.wallet)}</h1></section><div class="actions"><button id="add">➕ Add Money</button><button id="send">💸 Send</button><button id="receive">💵 Receive</button></div><h3>History</h3>${tx.length?tx.map(row).join(""):empty("No transactions yet")}`);b.onclick=back;add.onclick=()=>toast("Demo Add Money selected");send.onclick=()=>go("send");receive.onclick=()=>go("receive")}

function send(){shell(`<button class="back" id="b">← Back</button><h2>Send Money</h2><form class="cardform" id="f"><label>Receiver Mobile</label><input id="r" maxlength="10" required><label>Receiver Name</label><input id="n" required><label>Amount</label><input id="a" type="number" min="1" required><label>Note</label><input><button class="primary">Continue</button></form>`);b.onclick=back;f.onsubmit=e=>{e.preventDefault();let a=+document.getElementById("a").value;if(!/^[0-9]{10}$/.test(r.value))return toast("Enter valid receiver number");if(a<=0)return toast("Enter valid amount");if(a>user.wallet)return toast("Insufficient balance");if(r.value===user.mobile)return toast("Cannot pay yourself");if(confirm(`Send ${money(a)} to ${n.value}?`)){user.wallet-=a;addTx("Money Sent",`${n.value} (${r.value})`,a);toast("Payment successful");setTimeout(home,400)}}}

function upi(){shell(`<button class="back" id="b">← Back</button><h2>UPI Number Pay</h2><form class="cardform" id="f"><label>UPI Number</label><input id="u" maxlength="10" required><label>Amount</label><input id="a" type="number" min="1" required><button class="primary">Continue</button></form>`);b.onclick=back;f.onsubmit=e=>{e.preventDefault();let a=+document.getElementById("a").value;if(a>user.wallet)return toast("Insufficient balance");if(a<=0)return toast("Enter valid amount");if(confirm(`Pay ${money(a)}?`)){user.wallet-=a;addTx("UPI Payment",u.value,a);toast("UPI payment successful");setTimeout(home,400)}}}

function receive(){shell(`<button class="back" id="b">← Back</button><h2>Receive Money</h2><section class="cardform"><h3>${esc(user.name)}</h3><h2>PP-${esc(user.mobile)}</h2><p>+91 ${esc(user.mobile)}</p><button class="primary" id="share">Share Payment ID</button></section>`);b.onclick=back;share.onclick=()=>toast("Payment ID copied for demo")}
function selfPay(){shell(`<button class="back" id="b">← Back</button><h2>Self Payment</h2><section class="cardform"><label>Amount</label><input id="a" type="number"><button class="primary" id="go">Continue</button></section>`);b.onclick=back;go.onclick=()=>toast(+a.value>0?"Self payment demo completed":"Enter valid amount")}
function bank(){simpleForm("Add Bank Account",["Bank Name","Account Holder","Account Number","IFSC"],"Verify Bank")}
function cards(){simpleForm("Debit / Credit Card",["Card Number","Card Holder","Expiry"],"Add Card")}
function simpleForm(title,fields,button){shell(`<button class="back" id="b">← Back</button><h2>${title}</h2><form class="cardform" id="f">${fields.map(x=>`<label>${x}</label><input ${x==="Account Number"?"type=password":""} required>`).join("")}<button class="primary">${button}</button><small>Demo only; sensitive financial credentials are not connected.</small></form>`);b.onclick=back;f.onsubmit=e=>{e.preventDefault();toast(button+" demo successful")}}
function scan(){shell(`<button class="back" id="b">← Back</button><h2>Scan & Pay</h2><section class="cardform"><div class="camera">📷</div><button class="primary" id="cam">Start Scanner</button><button class="secondary" id="manual">Enter PayPay ID</button></section>`);b.onclick=back;cam.onclick=()=>toast("Camera scanner demo started");manual.onclick=()=>{let x=prompt("Enter PayPay ID");if(x)toast("Receiver: "+x)}}
function recharge(){shell(`<button class="back" id="b">← Back</button><h2>Mobile Recharge</h2><form class="cardform" id="f"><label>Mobile</label><input maxlength="10" required><label>Operator</label><select><option>Jio</option><option>Airtel</option><option>Vi</option><option>BSNL</option></select><label>Amount</label><input type="number" min="1" required><button class="primary">Recharge</button></form>`);b.onclick=back;f.onsubmit=e=>{e.preventDefault();toast("Demo recharge successful")}}
function transactions(){shell(`<button class="back" id="b">← Back</button><h2>Transactions</h2>${tx.length?tx.map(row).join(""):empty("No transactions found")}`);b.onclick=back}
function row(t){return `<div class="tx"><div><b>${esc(t.type)}</b><small>${esc(t.to)}</small><small>${esc(t.date)}</small><small>${esc(t.id)}</small></div><b>${money(t.amount)}</b></div>`}
function profile(){shell(`<button class="back" id="b">← Back</button><h2>Profile</h2><section class="cardform"><h3>${esc(user.name)}</h3><p>+91 ${esc(user.mobile)}</p><p>PP-${esc(user.mobile)}</p><button class="primary" id="kyc">KYC Application</button><button class="secondary" id="sec">Security</button></section>`);b.onclick=back;kyc.onclick=()=>toast("KYC demo screen");sec.onclick=()=>go("security")}
function security(){shell(`<button class="back" id="b">← Back</button><h2>Security</h2><section class="cardform">${["🔐 Change Security PIN","🔑 Change UPI PIN","📱 Device Management","⏱️ Session Timeout"].map(x=>`<button class="option">${x}</button>`).join("")}</section>`);b.onclick=back;document.querySelectorAll(".option").forEach(x=>x.onclick=()=>toast(x.textContent.trim()))}
function bills(){shell(`<button class="back" id="b">← Back</button><h2>Bills & Payments</h2><div class="actions">${["⚡ Electricity","📺 DTH","🌐 Broadband","🚗 FASTag","🛡️ Insurance","🎓 Education"].map(x=>`<button>${x}</button>`).join("")}</div>`);b.onclick=back;document.querySelectorAll(".actions button").forEach(x=>x.onclick=()=>toast(x.textContent.trim()+" demo selected"))}
function offers(){shell(`<button class="back" id="b">← Back</button><h2>Offers</h2><section class="cardform"><h3>🎁 PayPay Offers</h3><p>Demo offers and gift cards.</p><button class="primary" id="gift">Gift Cards</button></section>`);b.onclick=back;gift.onclick=()=>toast("Gift Cards demo opened")}
function autopay(){simpleForm("Auto Pay",["Service","Amount","Frequency"],"Create Auto Pay")}
function redeem(){simpleForm("Play Store Redeem Code",["Redeem Code"],"Validate Code")}
function transfer(){simpleForm("Bank Transfer",["Account Number","IFSC","Amount"],"Continue")}
function help(){shell(`<button class="back" id="b">← Back</button><h2>Help & Support</h2><section class="cardform">${["📞 Contact Support","❓ FAQs","🔒 Security Help","💳 Payment Help"].map(x=>`<button class="option">${x}</button>`).join("")}</section>`);b.onclick=back;document.querySelectorAll(".option").forEach(x=>x.onclick=()=>toast(x.textContent.trim()))}
function about(){shell(`<button class="back" id="b">← Back</button><h2>About PayPay</h2><section class="cardform"><h3>PayPay Demo</h3><p>Version 1.0.0</p><p>Demo wallet interface only. No real money or payment network is connected.</p></section>`);b.onclick=back}
function empty(x){return `<div class="cardform center">${esc(x)}</div>`}
function go(p){if(!logged)return loginPage();({home,wallet,send,upi,self:selfPay,receive,bank,scan,recharge,transactions,profile,security,cards,bills,offers,autopay,redeem,transfer,help,about}[p]||home)()}
function logout(){logged=false;isAdmin=false;toast("Logged out");setTimeout(loginPage,300)}
loginPage();