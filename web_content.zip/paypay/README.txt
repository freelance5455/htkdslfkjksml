PayPay Fixed Interactive Demo
==============================
User demo login: 9876543210 / 123456
Admin demo login: 7488053580 / sahiltoppo03@

Open index.html in a browser. This is a front-end demo only and does not process real money, UPI, banking, cards, KYC or Google Play transactions.

Important: The admin password is stored in client-side JavaScript because this is a static front-end demo. Do not use this credential or this authentication pattern for a real production app. A production admin login should use a server-side authentication system and hashed credentials.
