# یادآور دارو (MedRe)

پوستهٔ WebView اندروید با آلارم بومی (AlarmManager). صفحهٔ برنامه در `app/src/main/assets/index.html` است.

## ساخت APK با GitHub Actions
1. پوشهٔ پروژه را در مخزن خصوصی `medre` پوش کنید.
2. تب Actions → Build APK → Run workflow.
3. فایل APK را از Artifacts دانلود کنید (`debug` برای تست، `release` برای انتشار).

## امضای نسخهٔ انتشار (برای کافه‌بازار و مایکت)
یک keystore بسازید و به‌صورت base64 در Secrets بگذارید:
`KEYSTORE_B64`, `KS_PASS`, `KEY_ALIAS`, `KEY_PASS`
(`base64 -w0 my.jks` برای ساخت مقدار اول). بدون این‌ها APK انتشار امضا نمی‌شود.

## یا با Android Studio
پوشه را باز کنید و Build → Build APK(s).

## نکته‌ها
- آلارم بومی فقط برای پروفایل فعال همگام می‌شود و با باز شدن برنامه یا ثبت مصرف به‌روز می‌شود.
- هوش مصنوعی واقعی داخل APK کار نمی‌کند؛ در آن‌جا دستیار با قواعد داخلی پاسخ می‌دهد.
