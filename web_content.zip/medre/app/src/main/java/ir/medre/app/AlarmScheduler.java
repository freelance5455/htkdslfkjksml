package ir.medre.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

class AlarmScheduler {
    static final String CH = "meds";

    static void channel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(CH, "یادآور دارو", NotificationManager.IMPORTANCE_HIGH);
        AudioAttributes a = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), a);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 500, 300, 500, 300, 500});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    static PendingIntent pi(Context c, String id, String t, String b) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction("med." + id)
                .putExtra("t", t).putExtra("b", b).putExtra("n", id.hashCode());
        return PendingIntent.getBroadcast(c, id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void sync(Context c, String json) {
        SharedPreferences p = c.getSharedPreferences("s", 0);
        AlarmManager am = c.getSystemService(AlarmManager.class);
        try {
            JSONArray old = new JSONArray(p.getString("ids", "[]"));
            for (int i = 0; i < old.length(); i++) am.cancel(pi(c, old.getString(i), "", ""));
        } catch (Exception ignored) {}
        JSONArray ids = new JSONArray();
        try {
            JSONArray a = new JSONArray(json);
            long now = System.currentTimeMillis();
            PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_IMMUTABLE);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long at = o.getLong("at");
                if (at <= now) continue;
                String id = o.getString("id");
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show),
                        pi(c, id, o.getString("t"), o.optString("b")));
                ids.put(id);
            }
        } catch (Exception ignored) {}
        p.edit().putString("ids", ids.toString()).putString("json", json).apply();
    }
}
