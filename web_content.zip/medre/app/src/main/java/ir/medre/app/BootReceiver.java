package ir.medre.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        AlarmScheduler.channel(c);
        AlarmScheduler.sync(c, c.getSharedPreferences("s", 0).getString("json", "[]"));
    }
}
