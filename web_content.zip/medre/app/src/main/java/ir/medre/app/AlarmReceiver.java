package ir.medre.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        AlarmScheduler.channel(c);
        String t = i.getStringExtra("t"), b = i.getStringExtra("b");
        int n = i.getIntExtra("n", 0);
        Intent oi = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent open = PendingIntent.getActivity(c, n, oi,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, AlarmScheduler.CH) : new Notification.Builder(c);
        nb.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(t).setContentText(b)
                .setContentIntent(open).setFullScreenIntent(open, true)
                .setAutoCancel(true).setCategory(Notification.CATEGORY_ALARM);
        if (Build.VERSION.SDK_INT < 26) {
            nb.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                    .setVibrate(new long[]{0, 500, 300, 500})
                    .setPriority(Notification.PRIORITY_MAX);
        }
        c.getSystemService(NotificationManager.class).notify(n, nb.build());
    }
}
