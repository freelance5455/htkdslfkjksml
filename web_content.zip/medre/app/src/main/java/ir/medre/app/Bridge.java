package ir.medre.app;

import android.content.Context;
import android.webkit.JavascriptInterface;

public class Bridge {
    private final Context c;
    Bridge(Context c) { this.c = c.getApplicationContext(); }

    @JavascriptInterface
    public void sync(String json) { AlarmScheduler.sync(c, json); }
}
