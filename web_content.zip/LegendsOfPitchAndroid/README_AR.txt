أساطير الملاعب - مشروع تطبيق أندرويد

هذا مشروع Android Studio يحزم نسخة HTML الحالية داخل تطبيق WebView ويعمل دون الحاجة إلى اتصال إنترنت بعد التثبيت.
لم يتم إنتاج ملف APK داخل هذه البيئة؛ يلزم فتح المشروع في Android Studio وبناؤه.

طريقة إنشاء APK:
1) فك ضغط الملف LegendsOfPitchAndroid.zip.
2) افتح Android Studio واختر Open ثم مجلد LegendsOfPitchAndroid.
3) انتظر مزامنة Gradle وتثبيت مكونات Android المطلوبة إذا طلب البرنامج ذلك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) اضغط Locate في رسالة نجاح البناء للعثور على ملف APK.

اسم التطبيق: أساطير الملاعب
معرّف التطبيق: com.legendsofthepitch.game
