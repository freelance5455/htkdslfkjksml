حِصن منه
=========

محتويات المجلد
--------------
www/index.html           التطبيق كاملًا (HTML + CSS + JavaScript في ملف واحد)
assets/icon.svg          أيقونة التطبيق (متجهة)
assets/icon-1024.png     أيقونة التطبيق 1024
assets/icon-512.png      أيقونة التطبيق 512
assets/logo-transparent.svg   الشعار بخلفية شفافة

تجربة التطبيق
-------------
افتح www/index.html في متصفح كروم، ويفضّل وضع عرض الجوال.

تعديل المحتوى (داخل www/index.html)
------------------------------------
const NAME = 'منه'     الاسم الذي يظهر بعد التحية وفي الورد والدعاء
const MSGS = [ ... ]   رسائل ممدوح اليومية، تظهر واحدة كل يوم بالترتيب، أضف أو عدّل ما شئت
wird: { ... }          بنود الورد اليومي وأعدادها
ACH = [ ... ]          الإنجازات وشروطها

التحويل إلى تطبيق أندرويد (Capacitor)
-------------------------------------
المتطلبات: Node.js و Android Studio

1) داخل مجلد hisn-minna نفّذ:
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "حِصن منه" com.mamdouh.hisnminna --web-dir=www
   npx cap add android

2) لجعل الخطوط تعمل دون إنترنت: نزّل خطي Amiri و IBM Plex Sans Arabic،
   وضعهما في www/fonts، ثم استبدل رابط Google Fonts في index.html بقواعد @font-face.

3) الأيقونة: في Android Studio افتح Image Asset ثم New Image Asset،
   وارفع assets/icon.svg، وإن اخترت أيقونة تكيّفية فاجعل لون الخلفية #0B1626.

4) بعد أي تعديل على index.html نفّذ:
   npx cap sync android
   npx cap open android
   ثم شغّله على الجهاز أو أنشئ ملف APK من قائمة Build.

إضافات مفيدة لاحقًا
-------------------
@capacitor/share            مشاركة الأذكار
@capacitor/haptics          اهتزاز أدق
@capacitor/local-notifications   تنبيهات الأذكار والورد
@capacitor/app              التحكم في زر الرجوع

ملاحظة
------
تُحفظ بيانات التقدم والإنجازات على الجهاز (localStorage) ولا تُرسل لأي مكان.
