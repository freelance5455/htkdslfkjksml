import jwt from "jsonwebtoken";
import { prisma } from "./db.js";

export const signToken = u => jwt.sign({ sub: u.id, role: u.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "2h" });

export function requireAuth(req, res, next) {
  const h = req.headers.authorization || "";
  const t = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!t) return res.status(401).json({ error: "Authentification requise." });
  try { req.user = jwt.verify(t, process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: "Session expirée." }); }
}

// Le rôle est relu en base : une rétrogradation ADMIN prend effet sans attendre l'expiration du JWT.
export async function requireAdmin(req, res, next) {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user?.sub }, select: { role: true } });
    if (user?.role !== "ADMIN") return res.status(403).json({ error: "Accès réservé à l'administrateur." });
    next();
  } catch {
    res.status(503).json({ error: "Vérification des autorisations indisponible." });
  }
}
