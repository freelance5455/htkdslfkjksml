import "dotenv/config";
import express from "express"; import cors from "cors"; import helmet from "helmet"; import rateLimit from "express-rate-limit"; import bcrypt from "bcryptjs"; import {z} from "zod";
import {prisma} from "./db.js"; import {signToken,requireAuth,requireAdmin} from "./auth.js"; import {createPayment,paymentStatus,paymentLink} from "./campay.js"; import {lessonPdf} from "./pdf.js";
import {LEVELS,SUBJECTS,UNITS,defaultCompetencies,makeIntegrationSituation} from "./data/curriculum.js";
import {generateLessonContent,STAGE_NAMES} from "./data/pedagogy.js";

const app=express(); app.use(helmet()); app.use(cors({origin:process.env.FRONTEND_URL||"http://localhost:5500"})); app.use(express.json({limit:"1mb"}));
app.use("/api",rateLimit({windowMs:15*60*1000,limit:300}));
const cleanUser=u=>({id:u.id,name:u.name,email:u.email,phone:u.phone,points:u.points,role:u.role});

app.get("/api/health",(_,r)=>r.json({ok:true,service:"METONGO Education API V11",pedagogicalStages:STAGE_NAMES.length}));

app.post("/api/auth/register",async(req,res)=>{
 try{const x=z.object({name:z.string().min(2),phone:z.string().min(9).max(20),email:z.string().email(),password:z.string().min(8)}).parse(req.body);
 const old=await prisma.user.findFirst({where:{OR:[{email:x.email},{phone:x.phone}]}}); if(old)return res.status(409).json({error:"E-mail ou téléphone déjà utilisé."});
 const u=await prisma.user.create({data:{name:x.name,phone:x.phone,email:x.email,passwordHash:await bcrypt.hash(x.password,12),points:5,pointLedger:{create:{amount:5,type:"WELCOME",description:"5 points de bienvenue"}}}});
 res.status(201).json({token:signToken(u),user:cleanUser(u)});
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||"Inscription invalide."})}
});
app.post("/api/auth/login",async(req,res)=>{
 try{const x=z.object({email:z.string().email(),password:z.string()}).parse(req.body);const u=await prisma.user.findUnique({where:{email:x.email}});
 if(!u||!(await bcrypt.compare(x.password,u.passwordHash)))return res.status(401).json({error:"Identifiants incorrects."});
 res.json({token:signToken(u),user:cleanUser(u)});
 }catch{res.status(400).json({error:"Données invalides."})}
});
app.get("/api/me",requireAuth,async(req,res)=>{const u=await prisma.user.findUnique({where:{id:req.user.sub}});if(!u)return res.status(404).json({error:"Utilisateur introuvable."});res.json(cleanUser(u))});

app.get("/api/teacher/dashboard",requireAuth,async(req,res)=>{
 const [user,downloads,lessonsCount]=await Promise.all([
  prisma.user.findUnique({where:{id:req.user.sub},select:{id:true,name:true,email:true,phone:true,points:true,role:true}}),
  prisma.download.findMany({where:{userId:req.user.sub},take:12,orderBy:{createdAt:'desc'},include:{lesson:{select:{id:true,title:true,level:true,subject:true,unit:true}}}}),
  prisma.lesson.count({where:{published:true}})
 ]);
 if(!user)return res.status(404).json({error:'Utilisateur introuvable.'});
 res.json({user,downloads,lessonsCount});
});
app.get("/api/teacher/planning",requireAuth,async(req,res)=>{
 const year=await prisma.academicYear.findFirst({
  where:{active:true},orderBy:{updatedAt:'desc'},
  include:{terms:{orderBy:{order:'asc'},include:{weeks:{orderBy:{number:'asc'},include:{sequences:{orderBy:{order:'asc'},include:{lessons:{orderBy:{order:'asc'},include:{lesson:{select:{id:true,title:true,level:true,subject:true,unit:true}}}}}}}}}}}
 });
 res.json(year||null);
});


// V9 — espace personnel de l’enseignant
const ownerId=req=>req.user.sub;
app.get("/api/teacher/profile",requireAuth,async(req,res)=>{
  const [classes,subjects,schedule,personalLessons,records]=await Promise.all([
    prisma.teacherClass.findMany({where:{userId:ownerId(req)},include:{_count:{select:{students:true}}},orderBy:{name:"asc"}}),
    prisma.teacherSubject.findMany({where:{userId:ownerId(req),active:true},orderBy:{name:"asc"}}),
    prisma.scheduleEntry.findMany({where:{userId:ownerId(req)},include:{class:true,subject:true},orderBy:[{dayOfWeek:"asc"},{startTime:"asc"}]}),
    prisma.personalLesson.findMany({where:{userId:ownerId(req),archived:false},orderBy:{updatedAt:"desc"}}),
    prisma.lessonRecord.findMany({where:{userId:ownerId(req)},include:{class:true,personalLesson:true,lesson:true},orderBy:{date:"desc"},take:30})
  ]);
  res.json({classes,subjects,schedule,personalLessons,records});
});
app.post("/api/teacher/classes",requireAuth,async(req,res)=>{
 try{const x=z.object({name:z.string().min(1),level:z.string().min(1),schoolYear:z.string().optional(),room:z.string().optional(),notes:z.string().optional()}).parse(req.body);
 const c=await prisma.teacherClass.create({data:{...x,userId:ownerId(req)}});res.status(201).json(c)
 }catch{res.status(400).json({error:"Classe invalide."})}
});
app.patch("/api/teacher/classes/:id",requireAuth,async(req,res)=>{
 try{const x=z.object({name:z.string().min(1),level:z.string().min(1),schoolYear:z.string().optional(),room:z.string().optional(),notes:z.string().optional()}).parse(req.body);
 const c=await prisma.teacherClass.updateMany({where:{id:req.params.id,userId:ownerId(req)},data:x});if(!c.count)return res.status(404).json({error:"Classe introuvable."});res.json(await prisma.teacherClass.findUnique({where:{id:req.params.id},include:{_count:{select:{students:true}}}}))
 }catch{res.status(400).json({error:"Modification impossible."})}
});
app.delete("/api/teacher/classes/:id",requireAuth,async(req,res)=>{const x=await prisma.teacherClass.deleteMany({where:{id:req.params.id,userId:ownerId(req)} });if(!x.count)return res.status(404).json({error:"Classe introuvable."});res.json({ok:true})});
app.post("/api/teacher/classes/:id/students",requireAuth,async(req,res)=>{
 try{const x=z.object({name:z.string().min(1),gender:z.string().optional(),birthDate:z.string().optional(),notes:z.string().optional()}).parse(req.body);
 const c=await prisma.teacherClass.findFirst({where:{id:req.params.id,userId:ownerId(req)}});if(!c)return res.status(404).json({error:"Classe introuvable."});
 res.status(201).json(await prisma.student.create({data:{...x,classId:c.id,birthDate:x.birthDate?new Date(x.birthDate):undefined}}))
 }catch{res.status(400).json({error:"Élève invalide."})}
});
app.delete("/api/teacher/students/:id",requireAuth,async(req,res)=>{
 const st=await prisma.student.findFirst({where:{id:req.params.id,class:{userId:ownerId(req)}}});if(!st)return res.status(404).json({error:"Élève introuvable."});
 await prisma.student.delete({where:{id:st.id}});res.json({ok:true})
});
app.get("/api/teacher/classes/:id/students",requireAuth,async(req,res)=>{
 const c=await prisma.teacherClass.findFirst({where:{id:req.params.id,userId:ownerId(req)}});if(!c)return res.status(404).json({error:"Classe introuvable."});
 res.json(await prisma.student.findMany({where:{classId:c.id},orderBy:{name:"asc"}}))
});
app.post("/api/teacher/subjects",requireAuth,async(req,res)=>{
 try{const x=z.object({name:z.string().min(1),level:z.string().optional()}).parse(req.body);
 res.status(201).json(await prisma.teacherSubject.create({data:{...x,userId:ownerId(req)}}))
 }catch{res.status(400).json({error:"Matière déjà enregistrée ou invalide."})}
});
app.delete("/api/teacher/subjects/:id",requireAuth,async(req,res)=>{const x=await prisma.teacherSubject.deleteMany({where:{id:req.params.id,userId:ownerId(req)}});if(!x.count)return res.status(404).json({error:"Matière introuvable."});res.json({ok:true})});
app.post("/api/teacher/schedule",requireAuth,async(req,res)=>{
 try{const x=z.object({classId:z.string(),subjectId:z.string().optional(),dayOfWeek:z.coerce.number().int().min(1).max(6),startTime:z.string(),endTime:z.string(),room:z.string().optional(),notes:z.string().optional()}).parse(req.body);
 const c=await prisma.teacherClass.findFirst({where:{id:x.classId,userId:ownerId(req)}});if(!c)return res.status(403).json({error:"Classe non autorisée."});
 if(x.subjectId){const s=await prisma.teacherSubject.findFirst({where:{id:x.subjectId,userId:ownerId(req)}});if(!s)return res.status(403).json({error:"Matière non autorisée."})}
 res.status(201).json(await prisma.scheduleEntry.create({data:{...x,userId:ownerId(req)}}))
 }catch{res.status(400).json({error:"Créneau invalide."})}
});
app.delete("/api/teacher/schedule/:id",requireAuth,async(req,res)=>{const x=await prisma.scheduleEntry.deleteMany({where:{id:req.params.id,userId:ownerId(req)}});if(!x.count)return res.status(404).json({error:"Créneau introuvable."});res.json({ok:true})});
app.get("/api/teacher/today",requireAuth,async(req,res)=>{
 const now=new Date(), day=((now.getDay()+6)%7)+1;
 const entries=await prisma.scheduleEntry.findMany({where:{userId:ownerId(req),dayOfWeek:day},include:{class:{include:{_count:{select:{students:true}}}},subject:true},orderBy:{startTime:"asc"}});
 const records=await prisma.lessonRecord.findMany({where:{userId:ownerId(req),date:{gte:new Date(now.getFullYear(),now.getMonth(),now.getDate()),lt:new Date(now.getFullYear(),now.getMonth(),now.getDate()+1)}},include:{class:true,personalLesson:true,lesson:true}});
 res.json({day,entries,records})
});
app.post("/api/teacher/personal-lessons",requireAuth,async(req,res)=>{
 try{const x=z.object({level:z.string(),subject:z.string(),unit:z.string(),title:z.string(),competency:z.string(),situation:z.string(),objective:z.string(),material:z.string().optional(),contentJson:z.any()}).parse(req.body);
 res.status(201).json(await prisma.personalLesson.create({data:{...x,userId:ownerId(req)}}))
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||"Fiche personnelle invalide."})}
});
app.get("/api/teacher/personal-lessons/:id",requireAuth,async(req,res)=>{const l=await prisma.personalLesson.findFirst({where:{id:req.params.id,userId:ownerId(req)}});if(!l)return res.status(404).json({error:"Fiche personnelle introuvable."});res.json(l)});
app.patch("/api/teacher/personal-lessons/:id",requireAuth,async(req,res)=>{
 try{const x=z.object({level:z.string(),subject:z.string(),unit:z.string(),title:z.string(),competency:z.string(),situation:z.string(),objective:z.string(),material:z.string().optional(),contentJson:z.any()}).parse(req.body);
 const old=await prisma.personalLesson.findFirst({where:{id:req.params.id,userId:ownerId(req)}});if(!old)return res.status(404).json({error:"Fiche personnelle introuvable."});
 res.json(await prisma.personalLesson.update({where:{id:old.id},data:x}))
 }catch{res.status(400).json({error:"Modification de la fiche impossible."})}
});
app.delete("/api/teacher/personal-lessons/:id",requireAuth,async(req,res)=>{const x=await prisma.personalLesson.deleteMany({where:{id:req.params.id,userId:ownerId(req)}});if(!x.count)return res.status(404).json({error:"Fiche personnelle introuvable."});res.json({ok:true})});
app.post("/api/teacher/records",requireAuth,async(req,res)=>{
 try{const x=z.object({classId:z.string(),personalLessonId:z.string().optional(),lessonId:z.string().optional(),date:z.string().optional(),status:z.enum(["DONE","PLANNED","MISSED"]).default("DONE"),notes:z.string().optional()}).parse(req.body);
 const c=await prisma.teacherClass.findFirst({where:{id:x.classId,userId:ownerId(req)}});if(!c)return res.status(403).json({error:"Classe non autorisée."});
 if(x.personalLessonId){const l=await prisma.personalLesson.findFirst({where:{id:x.personalLessonId,userId:ownerId(req)}});if(!l)return res.status(403).json({error:"Fiche personnelle non autorisée."})}
 res.status(201).json(await prisma.lessonRecord.create({data:{...x,userId:ownerId(req),date:x.date?new Date(x.date):new Date()}}))
 }catch{res.status(400).json({error:"Suivi de leçon invalide."})}
});
app.patch("/api/teacher/records/:id",requireAuth,async(req,res)=>{
 try{const x=z.object({status:z.enum(["DONE","PLANNED","MISSED"]),notes:z.string().optional()}).parse(req.body);
 const r=await prisma.lessonRecord.updateMany({where:{id:req.params.id,userId:ownerId(req)},data:x});if(!r.count)return res.status(404).json({error:"Suivi introuvable."});res.json(await prisma.lessonRecord.findUnique({where:{id:req.params.id},include:{class:true,personalLesson:true,lesson:true}}))
 }catch{res.status(400).json({error:"Mise à jour impossible."})}
});


// ---------------- V10 — carnet de bord enseignant ----------------
const dayStart = value => { const d=value?new Date(value):new Date(); return new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate())); };
const dayEnd = value => new Date(dayStart(value).getTime()+86400000);
async function ownedClass(req,id){ return prisma.teacherClass.findFirst({where:{id,userId:ownerId(req)}}); }
async function ownedStudent(req,id){ return prisma.student.findFirst({where:{id,class:{userId:ownerId(req)}}}); }

app.get('/api/teacher/board',requireAuth,async(req,res)=>{
  const uid=ownerId(req); const from=new Date(); from.setUTCDate(from.getUTCDate()-29); const today=dayStart();
  const [classes,students,records,attendance,assessments,observations,diary,scheduledToday,upcoming]=await Promise.all([
    prisma.teacherClass.count({where:{userId:uid}}),
    prisma.student.count({where:{class:{userId:uid}}}),
    prisma.lessonRecord.count({where:{userId:uid,date:{gte:from}}}),
    prisma.attendance.findMany({where:{userId:uid,date:{gte:from}},select:{status:true}}),
    prisma.assessment.findMany({where:{userId:uid,date:{gte:from}},include:{scores:true},orderBy:{date:'desc'},take:50}),
    prisma.observation.count({where:{userId:uid,date:{gte:from}}}),
    prisma.diaryEntry.count({where:{userId:uid,date:{gte:from}}}),
    prisma.scheduleEntry.count({where:{userId:uid,dayOfWeek:((new Date().getDay()+6)%7)+1}}),
    prisma.lessonRecord.findMany({where:{userId:uid,date:{gte:today}},include:{class:true,personalLesson:true,lesson:true},orderBy:{date:'desc'},take:8})
  ]);
  const present=attendance.filter(x=>x.status==='PRESENT').length, totalAttendance=attendance.length;
  const avgScores=assessments.flatMap(a=>a.scores.map(s=>({score:s.score,max:a.maxScore}))); const avg=avgScores.length?avgScores.reduce((n,x)=>n+(x.score/x.max)*20,0)/avgScores.length:null;
  res.json({periodDays:30,counts:{classes,students,lessonsRealized:records,observations,diaryEntries,scheduledToday},attendance:{present,total:totalAttendance,rate:totalAttendance?Math.round(present*100/totalAttendance):null},assessmentAverage:avg===null?null:Number(avg.toFixed(2)),recentRecords:upcoming});
});

app.get('/api/teacher/attendance',requireAuth,async(req,res)=>{
  const c=await ownedClass(req,String(req.query.classId||'')); if(!c)return res.status(403).json({error:'Classe non autorisée.'});
  const date=dayStart(req.query.date); const students=await prisma.student.findMany({where:{classId:c.id},orderBy:{name:'asc'}});
  const marks=await prisma.attendance.findMany({where:{classId:c.id,date}}); const map=new Map(marks.map(x=>[x.studentId,x]));
  res.json(students.map(s=>({student:s,attendance:map.get(s.id)||null})));
});
app.post('/api/teacher/attendance/bulk',requireAuth,async(req,res)=>{
 try{
  const x=z.object({classId:z.string(),date:z.string(),items:z.array(z.object({studentId:z.string(),status:z.enum(['PRESENT','ABSENT','LATE','EXCUSED']),note:z.string().optional()})).min(1)}).parse(req.body);
  const c=await ownedClass(req,x.classId); if(!c)return res.status(403).json({error:'Classe non autorisée.'}); const date=dayStart(x.date);
  for(const item of x.items){const st=await ownedStudent(req,item.studentId);if(!st||st.classId!==c.id)continue; await prisma.attendance.upsert({where:{studentId_date:{studentId:item.studentId,date}},create:{userId:ownerId(req),classId:c.id,studentId:item.studentId,date,status:item.status,note:item.note},update:{status:item.status,note:item.note}})}
  res.json({ok:true,date});
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Présence invalide.'})}
});
app.get('/api/teacher/attendance/summary',requireAuth,async(req,res)=>{
 const uid=ownerId(req), where={userId:uid}; const classId=String(req.query.classId||''); if(classId){const c=await ownedClass(req,classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});where.classId=c.id}
 const rows=await prisma.attendance.groupBy({by:['status'],where,_count:{_all:true}}); res.json(rows.reduce((o,x)=>(o[x.status]=x._count._all,o),{}));
});

app.get('/api/teacher/assessments',requireAuth,async(req,res)=>{
 const where={userId:ownerId(req)}; if(req.query.classId){const c=await ownedClass(req,String(req.query.classId));if(!c)return res.status(403).json({error:'Classe non autorisée.'});where.classId=c.id}
 res.json(await prisma.assessment.findMany({where,include:{class:true,scores:{include:{student:true},orderBy:{student:{name:'asc'}}}},orderBy:{date:'desc'},take:100}));
});
app.post('/api/teacher/assessments',requireAuth,async(req,res)=>{
 try{const x=z.object({classId:z.string(),title:z.string().min(2),subject:z.string().min(1),date:z.string().optional(),maxScore:z.coerce.number().positive().max(100),competency:z.string().optional(),notes:z.string().optional(),scores:z.array(z.object({studentId:z.string(),score:z.coerce.number().min(0),comment:z.string().optional()})).optional()}).parse(req.body);
 const c=await ownedClass(req,x.classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});
 const students=await prisma.student.findMany({where:{classId:c.id},select:{id:true}});const allowed=new Set(students.map(s=>s.id));const scores=(x.scores||[]).filter(s=>allowed.has(s.studentId)&&s.score<=x.maxScore);
 const a=await prisma.assessment.create({data:{userId:ownerId(req),classId:c.id,title:x.title,subject:x.subject,date:x.date?new Date(x.date):new Date(),maxScore:x.maxScore,competency:x.competency,notes:x.notes,scores:{create:scores}} ,include:{class:true,scores:{include:{student:true}}}});res.status(201).json(a);
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Évaluation invalide.'})}
});
app.patch('/api/teacher/assessments/:id',requireAuth,async(req,res)=>{
 try{const x=z.object({title:z.string().min(2).optional(),subject:z.string().min(1).optional(),maxScore:z.coerce.number().positive().max(100).optional(),competency:z.string().optional(),notes:z.string().optional(),scores:z.array(z.object({studentId:z.string(),score:z.coerce.number().min(0),comment:z.string().optional()})).optional()}).parse(req.body);const a=await prisma.assessment.findFirst({where:{id:req.params.id,userId:ownerId(req)}});if(!a)return res.status(404).json({error:'Évaluation introuvable.'});
  const max=x.maxScore??a.maxScore;if(x.scores){const students=await prisma.student.findMany({where:{classId:a.classId},select:{id:true}});const allowed=new Set(students.map(s=>s.id));for(const sc of x.scores.filter(s=>allowed.has(s.studentId)&&s.score<=max)){await prisma.assessmentScore.upsert({where:{assessmentId_studentId:{assessmentId:a.id,studentId:sc.studentId}},create:{assessmentId:a.id,studentId:sc.studentId,score:sc.score,comment:sc.comment},update:{score:sc.score,comment:sc.comment}})}}
  res.json(await prisma.assessment.findUnique({where:{id:a.id},include:{class:true,scores:{include:{student:true}}}}));
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Modification impossible.'})}
});
app.delete('/api/teacher/assessments/:id',requireAuth,async(req,res)=>{const x=await prisma.assessment.deleteMany({where:{id:req.params.id,userId:ownerId(req)}});if(!x.count)return res.status(404).json({error:'Évaluation introuvable.'});res.json({ok:true})});

app.get('/api/teacher/observations',requireAuth,async(req,res)=>{res.json(await prisma.observation.findMany({where:{userId:ownerId(req),...(req.query.classId?{classId:String(req.query.classId)}:{})},include:{class:true,student:true},orderBy:{date:'desc'},take:100}));});
app.post('/api/teacher/observations',requireAuth,async(req,res)=>{try{const x=z.object({classId:z.string(),studentId:z.string().optional(),category:z.string().default('PEDAGOGIQUE'),text:z.string().min(2),date:z.string().optional()}).parse(req.body);const c=await ownedClass(req,x.classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});if(x.studentId){const st=await ownedStudent(req,x.studentId);if(!st||st.classId!==c.id)return res.status(403).json({error:'Élève non autorisé.'})}res.status(201).json(await prisma.observation.create({data:{userId:ownerId(req),classId:c.id,studentId:x.studentId||null,category:x.category,text:x.text,date:x.date?new Date(x.date):new Date()},include:{class:true,student:true}}))}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Observation invalide.'})}});
app.delete('/api/teacher/observations/:id',requireAuth,async(req,res)=>{const x=await prisma.observation.deleteMany({where:{id:req.params.id,userId:ownerId(req)}});if(!x.count)return res.status(404).json({error:'Observation introuvable.'});res.json({ok:true})});

app.get('/api/teacher/diary',requireAuth,async(req,res)=>{res.json(await prisma.diaryEntry.findMany({where:{userId:ownerId(req),...(req.query.classId?{classId:String(req.query.classId)}:{})},include:{class:true},orderBy:{date:'desc'},take:100}));});
app.post('/api/teacher/diary',requireAuth,async(req,res)=>{try{const x=z.object({classId:z.string(),subject:z.string().min(1),title:z.string().min(2),content:z.string().min(2),homework:z.string().optional(),competency:z.string().optional(),date:z.string().optional()}).parse(req.body);const c=await ownedClass(req,x.classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});res.status(201).json(await prisma.diaryEntry.create({data:{...x,userId:ownerId(req),date:x.date?new Date(x.date):new Date()},include:{class:true}}))}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Entrée du cahier invalide.'})}});
app.delete('/api/teacher/diary/:id',requireAuth,async(req,res)=>{const x=await prisma.diaryEntry.deleteMany({where:{id:req.params.id,userId:ownerId(req)}});if(!x.count)return res.status(404).json({error:'Entrée introuvable.'});res.json({ok:true})});

app.get('/api/teacher/progress',requireAuth,async(req,res)=>{
 const uid=ownerId(req);const classes=await prisma.teacherClass.findMany({where:{userId:uid},select:{id:true,name:true,level:true}});const out=[];
 for(const c of classes){const [planned,done,missed,ass]=await Promise.all([prisma.lessonRecord.count({where:{userId:uid,classId:c.id,status:'PLANNED'}}),prisma.lessonRecord.count({where:{userId:uid,classId:c.id,status:'DONE'}}),prisma.lessonRecord.count({where:{userId:uid,classId:c.id,status:'MISSED'}}),prisma.assessment.findMany({where:{userId:uid,classId:c.id},include:{scores:true},orderBy:{date:'desc'},take:20})]);const vals=ass.flatMap(a=>a.scores.map(s=>s.score/a.maxScore*20));out.push({...c,lessons:{planned,done,missed},completionRate:(planned+done+missed)?Math.round(done*100/(planned+done+missed)):0,average:vals.length?Number((vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2)):null});}res.json(out);
});

app.get("/api/curriculum",async(_req,res)=>{
  const [levels,subjects,units,topics,competencies,situations]=await Promise.all([
    prisma.curriculumLevel.findMany({where:{active:true},orderBy:{sortOrder:'asc'}}),
    prisma.subject.findMany({where:{active:true},orderBy:{sortOrder:'asc'}}),
    prisma.learningUnit.findMany({where:{active:true},orderBy:[{level:'asc'},{sortOrder:'asc'}]}),
    prisma.curriculumTopic.findMany({where:{active:true},orderBy:[{level:'asc'},{unit:'asc'},{sortOrder:'asc'}]}),
    prisma.competency.findMany({where:{active:true},orderBy:[{level:'asc'},{subject:'asc'}]}),
    prisma.integrationSituation.findMany({where:{active:true},orderBy:[{level:'asc'},{subject:'asc'}]})
  ]);
  res.json({levels,subjects,units,topics,competencies,situations,stageNames:STAGE_NAMES});
});

app.post("/api/lesson-generator/preview",requireAuth,async(req,res)=>{
 try{
  const x=z.object({level:z.string().min(1),subject:z.string().min(1),unit:z.string().min(1),title:z.string().min(2),competency:z.string().optional(),situation:z.string().optional(),objective:z.string().min(2),material:z.string().optional()}).parse(req.body);
  const competency=x.competency||defaultCompetencies(x.level,x.subject);
  const situation=x.situation||makeIntegrationSituation(x.level,x.subject,x.unit).description;
  const lesson={...x,competency,situation,contentJson:generateLessonContent({...x,competency,situation})};
  res.json(lesson);
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Données de génération invalides.'})}
});

app.get("/api/lessons",async(req,res)=>{const q=String(req.query.q||""),level=req.query.level?.toString(),subject=req.query.subject?.toString();
 const ls=await prisma.lesson.findMany({where:{published:true,...(level?{level}:{}),...(subject?{subject}:{}),...(q?{OR:[{title:{contains:q,mode:"insensitive"}},{unit:{contains:q,mode:"insensitive"}}]}:{})},orderBy:{updatedAt:"desc"}});res.json(ls)});
app.get("/api/lessons/:id",async(req,res)=>{const l=await lessonWithStages(req.params.id);if(!l||!l.published)return res.status(404).json({error:"Fiche introuvable."});res.json(l)});
app.post("/api/lessons",requireAuth,requireAdmin,async(req,res)=>{try{const x=z.object({level:z.string(),subject:z.string(),unit:z.string(),title:z.string(),competency:z.string(),situation:z.string(),objective:z.string(),material:z.string().optional(),contentJson:z.any().optional()}).parse(req.body);const contentJson=x.contentJson||generateLessonContent(x);res.status(201).json(await prisma.lesson.create({data:{...x,competency:x.competency||defaultCompetencies(x.level,x.subject),situation:x.situation||makeIntegrationSituation(x.level,x.subject,x.unit).description,contentJson}}))}catch{res.status(400).json({error:"Fiche invalide."})}});

const packPoints=Number(process.env.POINTS_PACK_POINTS||50),packPrice=Number(process.env.POINTS_PACK_PRICE_XAF||500);
app.get("/api/points/pack",(_,res)=>res.json({points:packPoints,priceXaf:packPrice}));

app.post("/api/payments/initiate",requireAuth,async(req,res)=>{
 try{
  const x=z.object({phone:z.string().min(9).max(20),method:z.enum(["MOBILE_MONEY","LINK"]).default("MOBILE_MONEY")}).parse(req.body);
  const externalReference=`MSH-${req.user.sub}-${Date.now()}`;
  const p=await prisma.payment.create({data:{userId:req.user.sub,amountXaf:packPrice,points:packPoints,externalId:externalReference}});
  if(x.method==="LINK"){
    const out=await paymentLink({amount:packPrice,description:`METONGO Education - ${packPoints} points`,externalReference,redirectUrl:process.env.PAYMENT_REDIRECT_URL});
    await prisma.payment.update({where:{id:p.id},data:{providerReference:out.link}});
    return res.status(201).json({paymentId:p.id,mode:"LINK",link:out.link,status:"PENDING"});
  }
  const out=await createPayment({amount:packPrice,phone:x.phone,description:`METONGO Education - ${packPoints} points`,externalReference});
  await prisma.payment.update({where:{id:p.id},data:{providerReference:out.reference,rawPayload:out.raw}});
  res.status(201).json({paymentId:p.id,mode:"MOBILE_MONEY",reference:out.reference,operator:out.operator,ussd_code:out.ussd_code,status:"PENDING"});
 }catch(e){res.status(400).json({error:e.message||"Paiement impossible."})}
});

async function settle(paymentId,statusPayload){
 const status=String(statusPayload.status||"").toUpperCase();
 if(!["SUCCESSFUL","FAILED","PENDING"].includes(status))return null;
 return prisma.$transaction(async tx=>{
  const p=await tx.payment.findUnique({where:{id:paymentId}});
  if(!p)return null;
  if(status==="SUCCESSFUL"&&p.status==="PENDING"){
   // Conditional state transition prevents concurrent status checks from crediting twice.
   const changed=await tx.payment.updateMany({where:{id:p.id,status:"PENDING"},data:{status:"PAID",rawPayload:statusPayload}});
   if(changed.count===1){
    await tx.user.update({where:{id:p.userId},data:{points:{increment:p.points}}});
    await tx.pointLedger.create({data:{userId:p.userId,amount:p.points,type:"PURCHASE",description:`Achat de ${p.points} points`,paymentId:p.id}});
   }
  }else if(status==="FAILED"&&p.status==="PENDING"){
   await tx.payment.updateMany({where:{id:p.id,status:"PENDING"},data:{status:"FAILED",rawPayload:statusPayload}});
  }
  return tx.payment.findUnique({where:{id:p.id}});
 });
}
app.get("/api/payments/:id/status",requireAuth,async(req,res)=>{
 const p=await prisma.payment.findFirst({where:{id:req.params.id,userId:req.user.sub}});if(!p)return res.status(404).json({error:"Paiement introuvable."});
 if(p.status==="PENDING"&&p.providerReference&&!p.providerReference.startsWith("http")){
  try{const s=await paymentStatus(p.providerReference);await settle(p.id,s); }catch{}
 }
 const fresh=await prisma.payment.findUnique({where:{id:p.id}}); const u=await prisma.user.findUnique({where:{id:req.user.sub}});
 res.json({payment:fresh,user:cleanUser(u)});
});

app.get("/api/lessons/:id/pdf",requireAuth,async(req,res)=>{
 const l=await prisma.lesson.findUnique({where:{id:req.params.id}});if(!l||!l.published)return res.status(404).json({error:"Fiche introuvable."});
 const u=await prisma.user.findUnique({where:{id:req.user.sub}});if(!u||u.points<10)return res.status(402).json({error:"Il faut 10 points pour télécharger cette fiche.",required:10});
 await prisma.$transaction(async tx=>{await tx.user.update({where:{id:u.id},data:{points:{decrement:10}}});await tx.pointLedger.create({data:{userId:u.id,amount:-10,type:"DOWNLOAD",description:`Téléchargement : ${l.title}`}});await tx.download.create({data:{userId:u.id,lessonId:l.id,points:10}})});
 lessonPdf(l,res);
});


// ---------------- V4 ADMIN API ----------------
const adminOnly=[requireAuth,requireAdmin];

async function syncLessonStages(tx, lessonId, contentJson, editorId){
  const stages=Array.isArray(contentJson?.stages)?contentJson.stages:[];
  await tx.lessonStage.deleteMany({where:{lessonId}});
  if(stages.length){
    await tx.lessonStage.createMany({data:stages.map((x,i)=>({lessonId,order:Number(x.order)||i+1,name:String(x.name||STAGE_NAMES[i]||`Étape ${i+1}`),teacher:String(x.teacher||''),learner:String(x.learner||''),grouping:String(x.grouping||'Collectif / individuel'),material:x.material?String(x.material):null,durationMinutes:x.durationMinutes?Number(x.durationMinutes):null,editorId}))});
  }
}
async function lessonWithStages(id){
  return prisma.lesson.findUnique({where:{id},include:{stages:{orderBy:{order:'asc'}},downloads:false}});
}
app.get('/api/admin/stats',...adminOnly,async(_req,res)=>{
 const [users,admins,lessons,published,payments,paid,pending,downloads,points,pointsSold,revenueXaf,recentPayments,recentDownloads]=await Promise.all([
  prisma.user.count(),prisma.user.count({where:{role:'ADMIN'}}),prisma.lesson.count(),prisma.lesson.count({where:{published:true}}),prisma.payment.count(),prisma.payment.count({where:{status:'PAID'}}),prisma.payment.count({where:{status:'PENDING'}}),prisma.download.count(),prisma.user.aggregate({_sum:{points:true}}),prisma.pointLedger.aggregate({where:{type:'PURCHASE'},_sum:{amount:true}}),prisma.payment.aggregate({where:{status:'PAID'},_sum:{amountXaf:true}}),prisma.payment.findMany({take:8,orderBy:{createdAt:'desc'},include:{user:{select:{name:true}}}}),prisma.download.findMany({take:8,orderBy:{createdAt:'desc'},include:{user:{select:{name:true}},lesson:{select:{title:true}}}})
 ]);
 res.json({users,admins,lessons,published,payments,paidCount:paid,pending,downloads,pointsInCirculation:points._sum.points||0,pointsSold:pointsSold._sum.amount||0,revenueXaf:revenueXaf._sum.amountXaf||0,recentPayments,recentDownloads});
});
app.get('/api/admin/ledger',...adminOnly,async(req,res)=>res.json(await prisma.pointLedger.findMany({take:200,orderBy:{createdAt:'desc'},include:{user:{select:{name:true,email:true}}}})));
app.get('/api/admin/taxonomy',...adminOnly,async(_req,res)=>{
 const [levels,subjects,units,competencies,situations,topics]=await Promise.all([prisma.curriculumLevel.findMany(),prisma.subject.findMany(),prisma.learningUnit.findMany(),prisma.competency.findMany(),prisma.integrationSituation.findMany(),prisma.curriculumTopic.findMany()]);
 res.json([...levels.map(x=>({...x,kind:'LEVEL'})),...subjects.map(x=>({...x,kind:'SUBJECT'})),...units.map(x=>({...x,kind:'UNIT'})),...competencies.map(x=>({...x,kind:'COMPETENCY'})),...situations.map(x=>({...x,kind:'INTEGRATION'})),...topics.map(x=>({...x,kind:'TOPIC'}))]);
});
app.post('/api/admin/taxonomy',...adminOnly,async(req,res)=>{res.status(400).json({error:'Utilisez les routes détaillées du référentiel V6.'})});

app.get('/api/admin/overview',...adminOnly,async(_req,res)=>{
 const [users,lessons,paymentsPending,paymentsPaid,downloads,points,latestPayments,latestUsers]=await Promise.all([
  prisma.user.count(),prisma.lesson.count(),prisma.payment.count({where:{status:'PENDING'}}),prisma.payment.count({where:{status:'PAID'}}),prisma.download.count(),
  prisma.user.aggregate({_sum:{points:true}}),
  prisma.payment.findMany({take:8,orderBy:{createdAt:'desc'},include:{user:{select:{name:true,email:true,phone:true}}}}),
  prisma.user.findMany({take:8,orderBy:{createdAt:'desc'},select:{id:true,name:true,email:true,phone:true,role:true,points:true,createdAt:true}})
 ]);
 const [revenue,downloadsByDay]=await Promise.all([
  prisma.payment.aggregate({where:{status:'PAID'},_sum:{amountXaf:true}}),
  prisma.download.findMany({take:100,orderBy:{createdAt:'desc'},select:{createdAt:true}})
 ]);
 res.json({counts:{users,lessons,paymentsPending,paymentsPaid,downloads,totalPoints:points._sum.points||0,revenueXaf:revenue._sum.amountXaf||0},latestPayments,latestUsers,downloadsByDay});
});
app.get('/api/admin/users',...adminOnly,async(req,res)=>{
 const q=String(req.query.q||'').trim();const page=Math.max(1,Number(req.query.page)||1);const take=Math.min(100,Math.max(1,Number(req.query.take)||25));
 const where=q?{OR:[{name:{contains:q,mode:'insensitive'}},{email:{contains:q,mode:'insensitive'}},{phone:{contains:q,mode:'insensitive'}}]}:{};
 const [items,total]=await Promise.all([prisma.user.findMany({where,select:{id:true,name:true,email:true,phone:true,role:true,points:true,createdAt:true},orderBy:{createdAt:'desc'},skip:(page-1)*take,take}),prisma.user.count({where})]);res.json({items,total,page,take});
});
app.patch('/api/admin/users/:id',...adminOnly,async(req,res)=>{
 try{const x=z.object({name:z.string().min(2).optional(),phone:z.string().min(9).max(20).optional(),email:z.string().email().optional(),role:z.enum(['USER','ADMIN']).optional()}).parse(req.body);
 if(req.params.id===req.user.sub&&x.role==='USER')return res.status(400).json({error:'Vous ne pouvez pas retirer votre propre rôle administrateur.'});
 const u=await prisma.user.update({where:{id:req.params.id},data:x,select:{id:true,name:true,email:true,phone:true,role:true,points:true,createdAt:true}});res.json(u)
 }catch(e){res.status(400).json({error:e.code==='P2025'?'Utilisateur introuvable.':'Modification invalide ou e-mail/téléphone déjà utilisé.'})}
});
app.post('/api/admin/users/:id/points',...adminOnly,async(req,res)=>{
 try{const x=z.object({amount:z.number().int().min(-100000).max(100000).refine(n=>n!==0),description:z.string().min(3).max(240)}).parse(req.body);
 const result=await prisma.$transaction(async tx=>{const u=await tx.user.findUnique({where:{id:req.params.id}});if(!u)throw new Error('Utilisateur introuvable.');if(u.points+x.amount<0)throw new Error('Le solde ne peut pas devenir négatif.');const updated=await tx.user.update({where:{id:u.id},data:{points:{increment:x.amount}},select:{id:true,name:true,email:true,points:true}});await tx.pointLedger.create({data:{userId:u.id,amount:x.amount,type:'ADJUSTMENT',description:`Ajustement administrateur : ${x.description}`}});return updated});res.json(result)
 }catch(e){res.status(400).json({error:e.message||'Ajustement impossible.'})}
});
app.get('/api/admin/points-ledger',...adminOnly,async(req,res)=>{const take=Math.min(200,Math.max(1,Number(req.query.take)||100));res.json(await prisma.pointLedger.findMany({take,orderBy:{createdAt:'desc'},include:{user:{select:{name:true,email:true}}}}))});
app.get('/api/admin/payments',...adminOnly,async(req,res)=>{const status=String(req.query.status||'');const where=['PENDING','PAID','FAILED','CANCELLED'].includes(status)?{status}:{};res.json(await prisma.payment.findMany({where,take:Math.min(200,Math.max(1,Number(req.query.take)||100)),orderBy:{createdAt:'desc'},include:{user:{select:{name:true,email:true,phone:true}}}}))});
app.post('/api/admin/payments/:id/recheck',...adminOnly,async(req,res)=>{const p=await prisma.payment.findUnique({where:{id:req.params.id}});if(!p)return res.status(404).json({error:'Paiement introuvable.'});if(p.status!=='PENDING'||!p.providerReference||p.providerReference.startsWith('http'))return res.status(400).json({error:'Ce paiement ne peut pas être vérifié automatiquement.'});try{const provider=await paymentStatus(p.providerReference);const fresh=await settle(p.id,provider);res.json({payment:fresh,providerStatus:provider.status})}catch(e){res.status(502).json({error:'Vérification du prestataire indisponible.'})}});

const taxonomy={topics:{model:'curriculumTopic',fields:['level','subject','unit','name','description','sortOrder','active'],required:['level','subject','unit','name']},levels:{model:'curriculumLevel',fields:['name','description','sortOrder','active'],required:['name']},subjects:{model:'subject',fields:['name','description','sortOrder','active'],required:['name']},units:{model:'learningUnit',fields:['name','level','description','sortOrder','active'],required:['name','level']},competencies:{model:'competency',fields:['name','level','subject','description','active'],required:['name','level','subject']},situations:{model:'integrationSituation',fields:['title','level','subject','unit','description','active'],required:['title','level','subject','description']}};
for(const [route,cfg] of Object.entries(taxonomy)){
 const delegate=()=>prisma[cfg.model];
 app.get(`/api/admin/${route}`,...adminOnly,async(_req,res)=>res.json(await delegate().findMany({orderBy:{createdAt:'desc'}})));
 app.post(`/api/admin/${route}`,...adminOnly,async(req,res)=>{try{const data={};for(const f of cfg.fields)if(req.body[f]!==undefined)data[f]=req.body[f];for(const f of cfg.required)if(data[f]===undefined||data[f]==='')return res.status(400).json({error:`Le champ ${f} est obligatoire.`});if(data.sortOrder!==undefined)data.sortOrder=Number(data.sortOrder)||0;if(data.active!==undefined)data.active=Boolean(data.active);res.status(201).json(await delegate().create({data}))}catch(e){res.status(400).json({error:'Enregistrement impossible. Vérifiez les champs et les doublons.'})}});
 app.patch(`/api/admin/${route}/:id`,...adminOnly,async(req,res)=>{try{const data={};for(const f of cfg.fields)if(req.body[f]!==undefined)data[f]=req.body[f];if(data.sortOrder!==undefined)data.sortOrder=Number(data.sortOrder)||0;if(data.active!==undefined)data.active=Boolean(data.active);res.json(await delegate().update({where:{id:req.params.id},data}))}catch{res.status(400).json({error:'Modification impossible.'})}});
 app.delete(`/api/admin/${route}/:id`,...adminOnly,async(req,res)=>{try{await delegate().delete({where:{id:req.params.id}});res.json({ok:true})}catch{res.status(400).json({error:'Suppression impossible : vérifiez que cet élément n’est pas utilisé.'})}});
}
app.get('/api/admin/lessons/:id',...adminOnly,async(req,res)=>{
  const l=await prisma.lesson.findUnique({where:{id:req.params.id},include:{stages:{orderBy:{order:'asc'}}}});
  if(!l)return res.status(404).json({error:'Fiche introuvable.'});
  res.json(l);
});
app.put('/api/admin/lessons/:id',...adminOnly,async(req,res)=>{
 try{
  const x=z.object({level:z.string().min(1),subject:z.string().min(1),unit:z.string().min(1),title:z.string().min(1),competency:z.string().min(1),situation:z.string().min(1),objective:z.string().min(1),material:z.string().optional().nullable(),published:z.boolean().optional(),stages:z.array(z.object({order:z.number().int().min(1).max(11),name:z.string().min(1),teacher:z.string(),learner:z.string(),grouping:z.string(),material:z.string().optional().nullable(),durationMinutes:z.number().int().min(1).max(240).optional().nullable()})).length(11)}).parse(req.body);
  const contentJson={version:2,pedagogy:'Approche par expérimentation / démarche active',stages:x.stages,metadata:{updatedAt:new Date().toISOString(),updatedBy:req.user.sub}};
  const out=await prisma.$transaction(async tx=>{const lesson=await tx.lesson.update({where:{id:req.params.id},data:{level:x.level,subject:x.subject,unit:x.unit,title:x.title,competency:x.competency,situation:x.situation,objective:x.objective,material:x.material||null,published:x.published??true,contentJson}});await syncLessonStages(tx,lesson.id,contentJson,req.user.sub);return tx.lesson.findUnique({where:{id:lesson.id},include:{stages:{orderBy:{order:'asc'}}}});});
  res.json(out);
 }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Enregistrement de la fiche impossible.'})}
});
app.post('/api/admin/lessons/:id/regenerate-stages',...adminOnly,async(req,res)=>{
 try{const l=await prisma.lesson.findUnique({where:{id:req.params.id}});if(!l)return res.status(404).json({error:'Fiche introuvable.'});const contentJson=generateLessonContent(l);const out=await prisma.$transaction(async tx=>{await tx.lesson.update({where:{id:l.id},data:{contentJson}});await syncLessonStages(tx,l.id,contentJson,req.user.sub);return tx.lesson.findUnique({where:{id:l.id},include:{stages:{orderBy:{order:'asc'}}}});});res.json(out)}catch(e){res.status(400).json({error:'Régénération impossible.'})}
});

app.get('/api/admin/lessons',...adminOnly,async(req,res)=>{const q=String(req.query.q||'').trim();const rows=await prisma.lesson.findMany({where:q?{OR:[{title:{contains:q,mode:'insensitive'}},{level:{contains:q,mode:'insensitive'}},{subject:{contains:q,mode:'insensitive'}}]}:{},orderBy:{updatedAt:'desc'},take:200,include:{_count:{select:{stages:true}}}});res.json(rows)});
app.patch('/api/admin/lessons/:id',...adminOnly,async(req,res)=>{try{const x=z.object({level:z.string().min(1).optional(),subject:z.string().min(1).optional(),unit:z.string().min(1).optional(),title:z.string().min(1).optional(),competency:z.string().optional(),situation:z.string().optional(),objective:z.string().optional(),material:z.string().nullable().optional(),contentJson:z.any().optional(),published:z.boolean().optional()}).parse(req.body);res.json(await prisma.lesson.update({where:{id:req.params.id},data:x}))}catch{res.status(400).json({error:'Modification de fiche impossible.'})}});
app.delete('/api/admin/lessons/:id',...adminOnly,async(req,res)=>{try{await prisma.lesson.update({where:{id:req.params.id},data:{published:false}});res.json({ok:true,message:'Fiche dépubliée.'})}catch{res.status(404).json({error:'Fiche introuvable.'})}});

app.post('/api/admin/curriculum/import',...adminOnly,async(_req,res)=>{
 try{
  const result=await prisma.$transaction(async tx=>{
   for(const l of LEVELS) await tx.curriculumLevel.upsert({where:{name:l.name},update:{description:l.description,sortOrder:l.sortOrder,active:true},create:l});
   for(const s of SUBJECTS) await tx.subject.upsert({where:{name:s.name},update:{sortOrder:s.sortOrder,active:true},create:s});
   for(const u of UNITS) await tx.learningUnit.upsert({where:{name_level:{name:u.name,level:u.level}},update:{description:u.description,sortOrder:u.sortOrder,active:true},create:{name:u.name,level:u.level,description:u.description,sortOrder:u.sortOrder,active:true}});
   for(const u of UNITS) for(const [i,topic] of (u.topics||[]).entries()) await tx.curriculumTopic.upsert({where:{level_subject_unit_name:{level:u.level,subject:'Transversal',unit:u.name,name:topic}},update:{description:`Thème de travail : ${topic}`,sortOrder:i+1,active:true},create:{level:u.level,subject:'Transversal',unit:u.name,name:topic,description:`Thème de travail : ${topic}`,sortOrder:i+1,active:true}});
   return {levels:LEVELS.length,subjects:SUBJECTS.length,units:UNITS.length,topics:UNITS.reduce((n,u)=>n+(u.topics||[]).length,0)};
  });
  res.json({ok:true,...result,message:'Référentiel V6 importé.'});
 }catch(e){res.status(500).json({error:'Import du référentiel impossible.',detail:e.message})}
});

app.get('/api/admin/curriculum/export-template',...adminOnly,async(_req,res)=>{
 res.json({levels:LEVELS,subjects:SUBJECTS,units:UNITS,stageNames:STAGE_NAMES,notes:'Base initiale du projet à valider contre les documents officiels du MINEDUB avant publication comme référentiel réglementaire.'});
});



// V7 — planification annuelle
app.get('/api/admin/planning',...adminOnly,async(req,res)=>{
  const years=await prisma.academicYear.findMany({orderBy:[{active:'desc'},{label:'desc'}],include:{terms:{orderBy:{order:'asc'},include:{weeks:{orderBy:{number:'asc'},include:{sequences:{orderBy:{order:'asc'},include:{lessons:{orderBy:{order:'asc'},include:{lesson:{select:{id:true,title:true,published:true}}}}}}}}}}}});
  res.json(years);
});
app.post('/api/admin/academic-years',...adminOnly,async(req,res)=>{try{const d=z.object({label:z.string().min(4),startDate:z.string().optional(),endDate:z.string().optional(),active:z.boolean().optional()}).parse(req.body);if(d.active)await prisma.academicYear.updateMany({data:{active:false}});res.status(201).json(await prisma.academicYear.create({data:{label:d.label,startDate:d.startDate?new Date(d.startDate):null,endDate:d.endDate?new Date(d.endDate):null,active:d.active??false}}));}catch(e){res.status(400).json({error:'Année scolaire invalide ou déjà existante.'})}});
app.patch('/api/admin/academic-years/:id',...adminOnly,async(req,res)=>{try{const d=z.object({label:z.string().min(4).optional(),startDate:z.string().nullable().optional(),endDate:z.string().nullable().optional(),active:z.boolean().optional()}).parse(req.body);if(d.active)await prisma.academicYear.updateMany({data:{active:false}});res.json(await prisma.academicYear.update({where:{id:req.params.id},data:{...d,startDate:d.startDate===undefined?undefined:(d.startDate?new Date(d.startDate):null),endDate:d.endDate===undefined?undefined:(d.endDate?new Date(d.endDate):null)}}));}catch{res.status(400).json({error:'Modification impossible.'})}});
app.post('/api/admin/terms',...adminOnly,async(req,res)=>{try{const d=z.object({academicYearId:z.string(),name:z.string(),order:z.number().int().positive(),startDate:z.string().optional(),endDate:z.string().optional(),objective:z.string().optional()}).parse(req.body);res.status(201).json(await prisma.term.create({data:{...d,startDate:d.startDate?new Date(d.startDate):null,endDate:d.endDate?new Date(d.endDate):null}}));}catch{res.status(400).json({error:'Trimestre invalide.'})}});
app.patch('/api/admin/terms/:id',...adminOnly,async(req,res)=>{try{const d=req.body;res.json(await prisma.term.update({where:{id:req.params.id},data:{name:d.name,...(d.order!==undefined?{order:Number(d.order)}:{}),objective:d.objective,startDate:d.startDate?new Date(d.startDate):null,endDate:d.endDate?new Date(d.endDate):null}}));}catch{res.status(400).json({error:'Modification du trimestre impossible.'})}});
app.post('/api/admin/weeks',...adminOnly,async(req,res)=>{try{const d=z.object({termId:z.string(),number:z.number().int().positive(),label:z.string(),startDate:z.string().optional(),endDate:z.string().optional(),focus:z.string().optional()}).parse(req.body);res.status(201).json(await prisma.week.create({data:{...d,startDate:d.startDate?new Date(d.startDate):null,endDate:d.endDate?new Date(d.endDate):null}}));}catch{res.status(400).json({error:'Semaine invalide.'})}});
app.patch('/api/admin/weeks/:id',...adminOnly,async(req,res)=>{try{const d=req.body;res.json(await prisma.week.update({where:{id:req.params.id},data:{label:d.label,focus:d.focus,startDate:d.startDate?new Date(d.startDate):null,endDate:d.endDate?new Date(d.endDate):null,...(d.number!==undefined?{number:Number(d.number)}:{})}}));}catch{res.status(400).json({error:'Modification de la semaine impossible.'})}});
app.post('/api/admin/sequences',...adminOnly,async(req,res)=>{try{const d=z.object({weekId:z.string(),title:z.string(),level:z.string(),subject:z.string(),unit:z.string().optional(),objective:z.string(),competency:z.string().optional(),order:z.number().int().positive().optional()}).parse(req.body);res.status(201).json(await prisma.sequence.create({data:{...d,order:d.order||1}}));}catch{res.status(400).json({error:'Séquence invalide.'})}});
app.patch('/api/admin/sequences/:id',...adminOnly,async(req,res)=>{try{const d=req.body;res.json(await prisma.sequence.update({where:{id:req.params.id},data:{title:d.title,level:d.level,subject:d.subject,unit:d.unit,objective:d.objective,competency:d.competency,...(d.order!==undefined?{order:Number(d.order)}:{})}}));}catch{res.status(400).json({error:'Modification de la séquence impossible.'})}});
app.post('/api/admin/progression-lessons',...adminOnly,async(req,res)=>{try{const d=z.object({sequenceId:z.string(),lessonId:z.string().nullable().optional(),title:z.string(),objective:z.string(),plannedDate:z.string().optional(),durationMinutes:z.number().int().positive().optional(),order:z.number().int().positive().optional(),status:z.string().optional()}).parse(req.body);res.status(201).json(await prisma.progressionLesson.create({data:{...d,plannedDate:d.plannedDate?new Date(d.plannedDate):null,order:d.order||1,status:d.status||'PLANNED'}}));}catch{res.status(400).json({error:'Leçon de progression invalide.'})}});
app.patch('/api/admin/progression-lessons/:id',...adminOnly,async(req,res)=>{try{const d=req.body;res.json(await prisma.progressionLesson.update({where:{id:req.params.id},data:{title:d.title,objective:d.objective,lessonId:d.lessonId||null,plannedDate:d.plannedDate?new Date(d.plannedDate):null,durationMinutes:d.durationMinutes?Number(d.durationMinutes):null,order:Number(d.order),status:d.status}}));}catch{res.status(400).json({error:'Modification de la leçon de progression impossible.'})}});
app.delete('/api/admin/progression-lessons/:id',...adminOnly,async(req,res)=>{await prisma.progressionLesson.delete({where:{id:req.params.id}});res.json({ok:true})});
app.post('/api/admin/progression-lessons/:id/generate-lesson',...adminOnly,async(req,res)=>{try{const p=await prisma.progressionLesson.findUnique({where:{id:req.params.id},include:{sequence:{include:{week:{include:{term:true}}}}}});if(!p)return res.status(404).json({error:'Élément de progression introuvable.'});let lesson;if(p.lessonId)lesson=await prisma.lesson.findUnique({where:{id:p.lessonId}});if(!lesson){const competency=p.sequence.competency||defaultCompetencies(p.sequence.level,p.sequence.subject);const situation=makeIntegrationSituation(p.sequence.level,p.sequence.subject,p.sequence.unit||'Progression annuelle').description;const objective=p.objective;const contentJson=generateLessonContent({level:p.sequence.level,subject:p.sequence.subject,unit:p.sequence.unit||'Progression',title:p.title,competency,situation,objective,material:'Tableau, manuel, supports visuels et fiches d’activité'});lesson=await prisma.lesson.create({data:{level:p.sequence.level,subject:p.sequence.subject,unit:p.sequence.unit||'',title:p.title,competency,situation,objective,material:'Tableau, manuel, supports visuels et fiches d’activité',contentJson,published:true}});const stages=contentJson.stages||[];await prisma.lessonStage.createMany({data:stages.map((x,i)=>({lessonId:lesson.id,order:x.order||i+1,name:x.name,teacher:x.teacher,learner:x.learner,grouping:x.grouping,material:x.material||null}))});await prisma.progressionLesson.update({where:{id:p.id},data:{lessonId:lesson.id,status:'GENERATED'}});}else await prisma.progressionLesson.update({where:{id:p.id},data:{status:'GENERATED'}});res.json({progressionId:p.id,lesson});}catch(e){res.status(400).json({error:'Génération de la fiche impossible.'})}});
app.post('/api/admin/planning/bootstrap',...adminOnly,async(req,res)=>{try{const label=String(req.body.label||'2026-2027');let year=await prisma.academicYear.findUnique({where:{label}});if(!year)year=await prisma.academicYear.create({data:{label,active:true}});for(let i=1;i<=3;i++){let term=await prisma.term.findFirst({where:{academicYearId:year.id,order:i}});if(!term)term=await prisma.term.create({data:{academicYearId:year.id,name:`Trimestre ${i}`,order:i,objective:`Objectifs prioritaires du trimestre ${i}`}});for(let w=1;w<=12;w++){const number=(i-1)*12+w;let week=await prisma.week.findFirst({where:{termId:term.id,number:w}});if(!week)await prisma.week.create({data:{termId:term.id,number:w,label:`Semaine ${number}`,focus:'À planifier'}});}}res.json({ok:true,yearId:year.id});}catch{res.status(400).json({error:'Initialisation de la progression impossible.'})}});

app.get('/api/admin/exports/users',...adminOnly,async(_req,res)=>{const rows=await prisma.user.findMany({orderBy:{createdAt:'desc'}});res.type('text/csv').send('id,name,email,phone,role,points,createdAt\n'+rows.map(x=>[x.id,x.name,x.email,x.phone,x.role,x.points,x.createdAt.toISOString()].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n'));});
app.get('/api/admin/exports/lessons',...adminOnly,async(_req,res)=>{const rows=await prisma.lesson.findMany({orderBy:{updatedAt:'desc'}});res.type('text/csv').send('id,title,level,subject,unit,published,updatedAt\n'+rows.map(x=>[x.id,x.title,x.level,x.subject,x.unit,x.published,x.updatedAt.toISOString()].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n'));});
app.get('/api/admin/exports/payments',...adminOnly,async(_req,res)=>{const rows=await prisma.payment.findMany({orderBy:{createdAt:'desc'}});res.type('text/csv').send('id,userId,amountXaf,points,status,createdAt\n'+rows.map(x=>[x.id,x.userId,x.amountXaf,x.points,x.status,x.createdAt.toISOString()].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n'));});


// ---------------- V11 — bulletins scolaires ----------------
const bulletinAppreciation = avg => avg==null ? '' : avg>=16 ? 'Très bon travail' : avg>=14 ? 'Bon travail' : avg>=12 ? 'Travail satisfaisant' : avg>=10 ? 'Peut mieux faire' : 'Des efforts supplémentaires sont nécessaires';
const bulletinDecision = avg => avg==null ? '' : avg>=10 ? 'Admis' : 'À renforcer';
async function ownedPeriod(req,id){ return prisma.bulletinPeriod.findFirst({where:{id,userId:ownerId(req)}}); }
async function computeBulletinRows(req,period){
 const students=await prisma.student.findMany({where:{classId:period.classId},orderBy:{name:'asc'} });
 const dateWhere=period.startDate&&period.endDate?{gte:period.startDate,lte:period.endDate}:undefined;
 const assessments=await prisma.assessment.findMany({where:{userId:ownerId(req),classId:period.classId,...(dateWhere?{date:dateWhere}:{})},include:{scores:true}});
 const subjects=[...new Set(assessments.map(a=>a.subject))]; const rows=[];
 for(const student of students){ const subjectMap={};
  for(const subject of subjects){const vals=[];for(const a of assessments.filter(x=>x.subject===subject)){const score=a.scores.find(x=>x.studentId===student.id);if(score)vals.push(score.score/a.maxScore*20)}subjectMap[subject]=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null}
  const vals=Object.values(subjectMap).filter(v=>v!=null); const average=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null;
  rows.push({student,subjects:subjectMap,average,totalPoints:vals.reduce((a,b)=>a+b,0),totalCoefficient:vals.length});
 }
 rows.sort((a,b)=>(b.average??-1)-(a.average??-1)||a.student.name.localeCompare(b.student.name,'fr'));
 return rows.map((r,i)=>({...r,rank:period.rankingEnabled&&r.average!=null?i+1:null}));
}
app.get('/api/teacher/bulletin-periods',requireAuth,async(req,res)=>{const where={userId:ownerId(req)};if(req.query.classId){const c=await ownedClass(req,String(req.query.classId));if(!c)return res.status(403).json({error:'Classe non autorisée.'});where.classId=c.id}res.json(await prisma.bulletinPeriod.findMany({where,include:{class:true},orderBy:{createdAt:'desc'}}));});
app.post('/api/teacher/bulletin-periods',requireAuth,async(req,res)=>{try{const x=z.object({classId:z.string(),name:z.string().min(2),type:z.string().default('TRIMESTRE'),startDate:z.string().optional(),endDate:z.string().optional(),rankingEnabled:z.boolean().default(true)}).parse(req.body);const c=await ownedClass(req,x.classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});res.status(201).json(await prisma.bulletinPeriod.create({data:{userId:ownerId(req),classId:c.id,name:x.name,type:x.type,startDate:x.startDate?new Date(x.startDate):null,endDate:x.endDate?new Date(x.endDate):null,rankingEnabled:x.rankingEnabled},include:{class:true}}));}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Période invalide.'})}});
app.get('/api/teacher/bulletin-periods/:id/preview',requireAuth,async(req,res)=>{const p=await ownedPeriod(req,req.params.id);if(!p)return res.status(404).json({error:'Période introuvable.'});res.json({period:p,rows:await computeBulletinRows(req,p)});});
app.post('/api/teacher/bulletin-periods/:id/generate',requireAuth,async(req,res)=>{try{const p=await ownedPeriod(req,req.params.id);if(!p)return res.status(404).json({error:'Période introuvable.'});const rows=await computeBulletinRows(req,p);await prisma.$transaction(async tx=>{for(const row of rows){const b=await tx.bulletin.upsert({where:{periodId_studentId:{periodId:p.id,studentId:row.student.id}},create:{periodId:p.id,studentId:row.student.id,rank:row.rank,average:row.average,totalPoints:row.totalPoints,totalCoefficient:row.totalCoefficient,decision:bulletinDecision(row.average),generalComment:bulletinAppreciation(row.average)},update:{rank:row.rank,average:row.average,totalPoints:row.totalPoints,totalCoefficient:row.totalCoefficient,decision:bulletinDecision(row.average),generalComment:bulletinAppreciation(row.average)}});await tx.bulletinSubject.deleteMany({where:{bulletinId:b.id}});const entries=Object.entries(row.subjects).filter(([,v])=>v!=null);if(entries.length)await tx.bulletinSubject.createMany({data:entries.map(([subject,average])=>({bulletinId:b.id,subject,coefficient:1,average,appreciation:bulletinAppreciation(average)}))})}});res.json({ok:true,count:rows.length});}catch(e){res.status(400).json({error:e?.message||'Génération impossible.'})}});
app.get('/api/teacher/bulletin-periods/:id/bulletins',requireAuth,async(req,res)=>{const p=await ownedPeriod(req,req.params.id);if(!p)return res.status(404).json({error:'Période introuvable.'});res.json(await prisma.bulletin.findMany({where:{periodId:p.id},include:{student:true,subjects:true},orderBy:[{rank:'asc'},{student:{name:'asc'}}]}));});
app.patch('/api/teacher/bulletins/:id',requireAuth,async(req,res)=>{try{const x=z.object({decision:z.string().optional(),generalComment:z.string().optional(),subjects:z.array(z.object({subject:z.string(),coefficient:z.coerce.number().positive(),appreciation:z.string().optional()})).optional()}).parse(req.body);const b=await prisma.bulletin.findFirst({where:{id:req.params.id,period:{userId:ownerId(req)}}});if(!b)return res.status(404).json({error:'Bulletin introuvable.'});await prisma.bulletin.update({where:{id:b.id},data:{decision:x.decision,generalComment:x.generalComment}});if(x.subjects)for(const item of x.subjects)await prisma.bulletinSubject.updateMany({where:{bulletinId:b.id,subject:item.subject},data:{coefficient:item.coefficient,appreciation:item.appreciation}});res.json(await prisma.bulletin.findUnique({where:{id:b.id},include:{student:true,subjects:true}}));}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Modification impossible.'})}});
app.get('/api/teacher/bulletins/:id/pdf',requireAuth,async(req,res)=>{const b=await prisma.bulletin.findFirst({where:{id:req.params.id,period:{userId:ownerId(req)}},include:{student:true,subjects:true,period:{include:{class:true}}}});if(!b)return res.status(404).json({error:'Bulletin introuvable.'});const PDFDocument=(await import('pdfkit')).default;const d=new PDFDocument({size:'A4',margin:42});res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="bulletin-${b.student.name.replace(/[^a-z0-9]+/gi,'-').toLowerCase()}.pdf"`);d.pipe(res);d.fontSize(16).font('Helvetica-Bold').text('METONGO SERGES HERVÉ ÉDUCATION',{align:'center'});d.fontSize(9).font('Helvetica').text('Bulletin scolaire — Enseignement maternel et primaire au Cameroun',{align:'center'});d.moveDown();d.fontSize(14).font('Helvetica-Bold').text('BULLETIN SCOLAIRE',{align:'center',underline:true});d.moveDown();d.fontSize(10).font('Helvetica');d.text(`Élève : ${b.student.name}`);d.text(`Classe : ${b.period.class.name} · ${b.period.class.level}`);d.text(`Période : ${b.period.name}`);d.moveDown();d.font('Helvetica-Bold').text('Matière                         Coef.    Moyenne /20    Appréciation');d.moveDown(.4);for(const s of b.subjects){d.font('Helvetica').text(`${s.subject.slice(0,25).padEnd(27)} ${String(s.coefficient).padStart(4)}      ${s.average==null?'—':s.average.toFixed(2).padStart(6)}       ${s.appreciation||'—'}`);d.moveDown(.25)}d.moveDown();d.font('Helvetica-Bold').text(`Moyenne générale : ${b.average==null?'—':b.average.toFixed(2)}/20`);d.text(`Rang : ${b.rank??'Non classé'}`);d.text(`Décision : ${b.decision||'—'}`);d.moveDown();d.text(`Appréciation générale : ${b.generalComment||'—'}`);d.moveDown(2);d.font('Helvetica').text('Signature de l’enseignant : ______________________________');d.end();});


// ---------------- V12 — gestion scolaire complète ----------------
const safeFile = v => String(v||'document').replace(/[^a-z0-9À-ÿ_-]+/gi,'-').toLowerCase();

async function getSchoolProfile(req){
  return prisma.schoolProfile.findUnique({where:{userId:ownerId(req)}});
}
function pdfHeader(d, profile, title, subtitle=''){
  d.font('Helvetica-Bold').fontSize(15).text(profile?.schoolName||'METONGO SERGES HERVÉ ÉDUCATION',{align:'center'});
  if(profile?.schoolAddress)d.font('Helvetica').fontSize(8).text(profile.schoolAddress,{align:'center'});
  if(profile?.schoolPhone||profile?.schoolEmail)d.font('Helvetica').fontSize(8).text([profile.schoolPhone,profile.schoolEmail].filter(Boolean).join(' · '),{align:'center'});
  d.moveDown(.5).font('Helvetica-Bold').fontSize(15).text(title,{align:'center',underline:true});
  if(subtitle)d.font('Helvetica').fontSize(9).text(subtitle,{align:'center'});
  d.moveDown();
}
function dataUrlBuffer(value){const m=String(value||'').match(/^data:[^;]+;base64,(.+)$/);return m?Buffer.from(m[1],'base64'):null;}
function pdfSignatures(d, profile){
  const y=d.y+18;
  d.font('Helvetica').fontSize(9).text('L’enseignant',55,y,{width:180,align:'center'}).text('Le chef d’établissement',330,y,{width:180,align:'center'});
  const sig=dataUrlBuffer(profile?.signatureDataUrl), stamp=dataUrlBuffer(profile?.stampDataUrl);
  if(sig){try{d.image(sig,105,y+25,{fit:[80,38],align:'center'})}catch{}}
  if(stamp){try{d.image(stamp,385,y+20,{fit:[80,55],align:'center'})}catch{}}
  if(profile?.signatureName)d.text(profile.signatureName,55,y+65,{width:180,align:'center'});
  if(profile?.headTeacherName)d.text(profile.headTeacherName,330,y+65,{width:180,align:'center'});
  if(profile?.stampLabel)d.fontSize(8).text(`Cachet : ${profile.stampLabel}`,330,y+82,{width:180,align:'center'});
}
function writeBulletinPage(d,b,profile,opts={}){
  const p=b.period, student=b.student;
  pdfHeader(d,profile,'BULLETIN SCOLAIRE',`${p.name} · ${p.class.name} · ${p.class.level}`);
  d.fontSize(10).font('Helvetica-Bold').text(`Élève : ${student.name}`);
  d.font('Helvetica').text(`Classe : ${p.class.name} · Période : ${p.name}`);
  d.moveDown();
  const x=45; let y=d.y;
  d.font('Helvetica-Bold').fontSize(9).text('Matière',x,y,{width:155}).text('Coef.',205,y,{width:45,align:'center'}).text('Moyenne /20',255,y,{width:75,align:'center'}).text('Appréciation',335,y,{width:215});
  y+=18; d.moveTo(x,y-4).lineTo(550,y-4).stroke();
  for(const s of b.subjects){
    d.font('Helvetica').fontSize(8).text(s.subject,x,y,{width:155}).text(String(s.coefficient),205,y,{width:45,align:'center'}).text(s.average==null?'—':s.average.toFixed(2),255,y,{width:75,align:'center'}).text(s.appreciation||'—',335,y,{width:215}); y+=18;
    if(y>700){d.addPage();y=55;}
  }
  d.moveDown(1); d.font('Helvetica-Bold').fontSize(10).text(`Moyenne générale : ${b.average==null?'—':b.average.toFixed(2)}/20`);
  if(p.rankingEnabled)d.text(`Rang : ${b.rank??'—'}`);
  d.text(`Décision : ${b.decision||'—'}`);
  d.moveDown(.5).font('Helvetica').text(`Appréciation générale : ${b.generalComment||'—'}`);
  pdfSignatures(d,profile);
}
async function buildBulletinData(req, periodId){
  const p=await prisma.bulletinPeriod.findFirst({where:{id:periodId,userId:ownerId(req)},include:{class:true}});
  if(!p)return null;
  const bulletins=await prisma.bulletin.findMany({where:{periodId:p.id},include:{student:true,subjects:true},orderBy:[{rank:'asc'},{student:{name:'asc'}}]});
  return {period:p,bulletins};
}
app.get('/api/teacher/school-profile',requireAuth,async(req,res)=>res.json(await getSchoolProfile(req)));
app.put('/api/teacher/school-profile',requireAuth,async(req,res)=>{
  try{const x=z.object({schoolName:z.string().min(2),schoolAddress:z.string().optional(),schoolPhone:z.string().optional(),schoolEmail:z.string().email().optional().or(z.literal('')),signatureName:z.string().optional(),stampLabel:z.string().optional(),headTeacherName:z.string().optional(),logoDataUrl:z.string().optional(),signatureDataUrl:z.string().optional(),stampDataUrl:z.string().optional()}).parse(req.body);
    res.json(await prisma.schoolProfile.upsert({where:{userId:ownerId(req)},create:{userId:ownerId(req),...x},update:x}));
  }catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Profil de l’établissement invalide.'})}
});

app.get('/api/teacher/annual-results/:classId',requireAuth,async(req,res)=>{
  const c=await ownedClass(req,req.params.classId); if(!c)return res.status(403).json({error:'Classe non autorisée.'});
  const periods=await prisma.bulletinPeriod.findMany({where:{userId:ownerId(req),classId:c.id},orderBy:{createdAt:'asc'}});
  const students=await prisma.student.findMany({where:{classId:c.id},orderBy:{name:'asc'}});
  const out=students.map(st=>{const rows=periods.map(p=>p);return {student:st,periods:rows.map(p=>({id:p.id,name:p.name,type:p.type})),results:[]}});
  for(const row of out){
    const bs=await prisma.bulletin.findMany({where:{studentId:row.student.id,periodId:{in:periods.map(p=>p.id)}},orderBy:{createdAt:'asc'}});
    row.results=periods.map(p=>{const b=bs.find(x=>x.periodId===p.id);return {periodId:p.id,name:p.name,average:b?.average??null,rank:b?.rank??null,decision:b?.decision??null};});
    const vals=bs.map(b=>b.average).filter(v=>v!=null); row.annualAverage=vals.length?Number((vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2)):null;
  }
  res.json({class:c,periods,rows:out});
});
app.get('/api/teacher/annual-results/:classId/pdf',requireAuth,async(req,res)=>{
  const c=await ownedClass(req,req.params.classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});
  const data=await fetchAnnualData(req,c.id); const profile=await getSchoolProfile(req);
  const PDFDocument=(await import('pdfkit')).default;const d=new PDFDocument({size:'A4',margin:42});
  res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="releve-annuel-${safeFile(c.name)}.pdf"`);d.pipe(res);
  pdfHeader(d,profile,'RELEVÉ ANNUEL DES RÉSULTATS',`${c.name} · ${c.level}`);
  for(const row of data.rows){d.font('Helvetica-Bold').fontSize(10).text(row.student.name);d.font('Helvetica').fontSize(8);for(const r of row.results)d.text(`${r.name} : ${r.average==null?'—':r.average.toFixed(2)}/20${r.rank?' · rang '+r.rank:''}`);d.font('Helvetica-Bold').text(`Moyenne annuelle : ${row.annualAverage==null?'—':row.annualAverage.toFixed(2)}/20`);d.moveDown(.5);if(d.y>720)d.addPage();}
  pdfSignatures(d,profile);d.end();
});
async function fetchAnnualData(req,classId){
  const c=await ownedClass(req,classId); const periods=await prisma.bulletinPeriod.findMany({where:{userId:ownerId(req),classId},orderBy:{createdAt:'asc'}});const students=await prisma.student.findMany({where:{classId},orderBy:{name:'asc'}});
  const rows=[];for(const st of students){const bs=await prisma.bulletin.findMany({where:{studentId:st.id,periodId:{in:periods.map(p=>p.id)}},orderBy:{createdAt:'asc'}});const results=periods.map(p=>{const b=bs.find(x=>x.periodId===p.id);return {name:p.name,average:b?.average??null,rank:b?.rank??null,decision:b?.decision??null};});const vals=bs.map(b=>b.average).filter(v=>v!=null);rows.push({student:st,results,annualAverage:vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null});}return {class:c,periods,rows};
}
app.get('/api/teacher/bulletin-periods/:id/group-pdf',requireAuth,async(req,res)=>{
  const data=await buildBulletinData(req,req.params.id);if(!data)return res.status(404).json({error:'Période introuvable.'});if(!data.bulletins.length)return res.status(400).json({error:'Générez d’abord les bulletins de cette période.'});
  const profile=await getSchoolProfile(req);const PDFDocument=(await import('pdfkit')).default;const d=new PDFDocument({size:'A4',margin:42});res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="bulletins-${safeFile(data.period.class.name)}-${safeFile(data.period.name)}.pdf"`);d.pipe(res);
  data.bulletins.forEach((b,i)=>{if(i)d.addPage();writeBulletinPage(d,{...b,period:data.period},profile);});d.end();
});
app.get('/api/teacher/bulletin-periods/:id/annual-summary',requireAuth,async(req,res)=>{
  const p=await prisma.bulletinPeriod.findFirst({where:{id:req.params.id,userId:ownerId(req)}});if(!p)return res.status(404).json({error:'Période introuvable.'});res.json(await fetchAnnualData(req,p.classId));
});

app.get('/api/teacher/council-meetings',requireAuth,async(req,res)=>res.json(await prisma.councilMeeting.findMany({where:{userId:ownerId(req)},include:{class:true,decisions:{include:{student:true}}},orderBy:{date:'desc'},take:100})));
app.post('/api/teacher/council-meetings',requireAuth,async(req,res)=>{try{const x=z.object({classId:z.string(),periodId:z.string().optional(),date:z.string().optional(),location:z.string().optional(),summary:z.string().optional(),recommendations:z.string().optional()}).parse(req.body);const c=await ownedClass(req,x.classId);if(!c)return res.status(403).json({error:'Classe non autorisée.'});res.status(201).json(await prisma.councilMeeting.create({data:{userId:ownerId(req),classId:c.id,periodId:x.periodId||null,date:x.date?new Date(x.date):new Date(),location:x.location,summary:x.summary,recommendations:x.recommendations},include:{class:true}}));}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Conseil de classe invalide.'})}});
app.post('/api/teacher/council-decisions',requireAuth,async(req,res)=>{try{const x=z.object({classId:z.string(),studentId:z.string(),meetingId:z.string().optional(),academicYear:z.string().optional(),decision:z.string().min(2),reason:z.string().optional(),comment:z.string().optional()}).parse(req.body);const c=await ownedClass(req,x.classId),st=await ownedStudent(req,x.studentId);if(!c||!st||st.classId!==c.id)return res.status(403).json({error:'Élève ou classe non autorisé.'});res.status(201).json(await prisma.councilDecision.create({data:{...x,userId:ownerId(req),meetingId:x.meetingId||null},include:{student:true}}));}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Décision invalide.'})}});
app.get('/api/teacher/council-decisions',requireAuth,async(req,res)=>res.json(await prisma.councilDecision.findMany({where:{userId:ownerId(req),...(req.query.classId?{classId:String(req.query.classId)}:{})},include:{student:true,class:true},orderBy:{student:{name:'asc'}}})));

app.get('/api/teacher/school-documents',requireAuth,async(req,res)=>res.json(await prisma.schoolDocument.findMany({where:{userId:ownerId(req)},include:{student:true,class:true},orderBy:{createdAt:'desc'},take:100})));
app.post('/api/teacher/school-documents',requireAuth,async(req,res)=>{try{const x=z.object({type:z.string().min(2),title:z.string().min(2),classId:z.string().optional(),studentId:z.string().optional(),periodLabel:z.string().optional(),contentJson:z.any().optional()}).parse(req.body);if(x.classId&&!await ownedClass(req,x.classId))return res.status(403).json({error:'Classe non autorisée.'});if(x.studentId&&!await ownedStudent(req,x.studentId))return res.status(403).json({error:'Élève non autorisé.'});res.status(201).json(await prisma.schoolDocument.create({data:{...x,userId:ownerId(req),classId:x.classId||null,studentId:x.studentId||null}}));}catch(e){res.status(400).json({error:e?.issues?.[0]?.message||'Document invalide.'})}});
app.get('/api/teacher/students/:id/document/:type/pdf',requireAuth,async(req,res)=>{
  const st=await ownedStudent(req,req.params.id);if(!st)return res.status(404).json({error:'Élève introuvable.'});const c=await ownedClass(req,st.classId);const profile=await getSchoolProfile(req);const annual=await fetchAnnualData(req,c.id);const row=annual.rows.find(r=>r.student.id===st.id);const PDFDocument=(await import('pdfkit')).default;const d=new PDFDocument({size:'A4',margin:42});res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="${safeFile(req.params.type)}-${safeFile(st.name)}.pdf"`);d.pipe(res);
  const title=req.params.type==='certificat'?'CERTIFICAT SCOLAIRE':'RELEVÉ DE NOTES';pdfHeader(d,profile,title,`${c.name} · ${c.level}`);d.font('Helvetica').fontSize(10).text(`Élève : ${st.name}`);if(st.birthDate)d.text(`Date de naissance : ${new Date(st.birthDate).toLocaleDateString('fr-FR')}`);d.moveDown();if(req.params.type==='certificat'){d.text(`Nous attestons que l’élève ${st.name} est inscrit(e) dans la classe ${c.name} pour l’année scolaire ${c.schoolYear||'en cours'}.`);d.moveDown();d.text('Le présent certificat est délivré pour servir et valoir ce que de droit.');}else{for(const r of row?.results||[])d.text(`${r.name} : ${r.average==null?'—':r.average.toFixed(2)}/20${r.rank?' · rang '+r.rank:''}`);d.moveDown();d.font('Helvetica-Bold').text(`Moyenne annuelle : ${row?.annualAverage==null?'—':row.annualAverage.toFixed(2)}/20`);}d.moveDown(2);pdfSignatures(d,profile);d.end();
});

app.get('/api/teacher/council-meetings/:id/pdf',requireAuth,async(req,res)=>{const m=await prisma.councilMeeting.findFirst({where:{id:req.params.id,userId:ownerId(req)},include:{class:true,decisions:{include:{student:true}}}});if(!m)return res.status(404).json({error:'Conseil introuvable.'});const profile=await getSchoolProfile(req);const PDFDocument=(await import('pdfkit')).default;const d=new PDFDocument({size:'A4',margin:42});res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="conseil-${safeFile(m.class.name)}.pdf"`);d.pipe(res);pdfHeader(d,profile,'CONSEIL DE CLASSE',`${m.class.name} · ${new Date(m.date).toLocaleDateString('fr-FR')}`);d.font('Helvetica').fontSize(9).text(`Lieu : ${m.location||'—'}`);d.text(`Résumé : ${m.summary||'—'}`);d.text(`Recommandations : ${m.recommendations||'—'}`);d.moveDown();d.font('Helvetica-Bold').text('Décisions');d.font('Helvetica');for(const x of m.decisions)d.text(`${x.student.name} — ${x.decision}${x.comment?' : '+x.comment:''}`);pdfSignatures(d,profile);d.end();});

app.listen(process.env.PORT||4000,()=>console.log(`API V12 sur http://localhost:${process.env.PORT||4000}`));
