export const LEVELS = [
  {name:'SIL', description:'Section d’Initiation au Langage — niveau initial du primaire', sortOrder:1},
  {name:'CP', description:'Cours Préparatoire', sortOrder:2},
  {name:'CE1', description:'Cours Élémentaire 1', sortOrder:3},
  {name:'CE2', description:'Cours Élémentaire 2', sortOrder:4},
  {name:'CM1', description:'Cours Moyen 1', sortOrder:5},
  {name:'CM2', description:'Cours Moyen 2', sortOrder:6}
];

export const SUBJECTS = [
  'Français','English','Mathématiques','Sciences et technologie','Éducation à la citoyenneté','Histoire','Géographie','Éducation physique et sportive','Arts et culture','Technologies de l’information et de la communication'
].map((name,i)=>({name,sortOrder:i+1}));

// Base de travail structurée à partir des éléments pédagogiques fournis pour le projet.
// Les intitulés détaillés des programmes officiels doivent être validés avant publication comme référentiel officiel.
export const UNITS = [
  ['SIL','La maison',['La famille','La vie à la maison','Les objets domestiques familiers']],
  ['SIL','Le village / la ville',['L’habitat','L’eau','La pollution']],
  ['SIL','L’école',['L’environnement scolaire','La vie à l’école','Les apprentissages scolaires']],
  ['SIL','Les métiers',['Les artisans','Les professionnels','Les produits artisanaux et manufacturés']],
  ['SIL','Les voyages',['Activités liées au voyage','Moyens de locomotion','Moments et émotions du voyage']],
  ['SIL','La santé',['Protection de la santé','Causes des maladies','Soins de santé']],
  ['SIL','Les jeux',['Jouets','Jouets électroniques','Jeux']],
  ['SIL','Les communications',['Moyens traditionnels de communication','Moyens modernes de communication','Messages et usages']],
  ['CP','La maison',['Famille et relations','Vie quotidienne','Objets et environnement domestique']],
  ['CP','L’école',['Espaces scolaires','Règles de vie','Activités d’apprentissage']],
  ['CP','Le milieu de vie',['Village et ville','Eau et environnement','Propreté et pollution']],
  ['CP','Les métiers',['Métiers de la communauté','Outils et produits','Services']],
  ['CP','La santé',['Hygiène corporelle','Alimentation et santé','Prévention des maladies']],
  ['CP','Les déplacements et communications',['Moyens de transport','Sécurité','Moyens de communication']],
  ['CE1','Le milieu de vie',['Famille et communauté','Environnement','Ressources du milieu']],
  ['CE1','L’école et la citoyenneté',['Vie scolaire','Droits et devoirs','Respect des autres']],
  ['CE1','La santé et l’hygiène',['Corps humain','Hygiène','Alimentation']],
  ['CE1','Le monde vivant',['Plantes','Animaux','Relations avec le milieu']],
  ['CE1','Les activités économiques',['Agriculture','Élevage et pêche','Artisanat et commerce']],
  ['CE1','Transports et communications',['Transports','Communication','Sécurité']],
  ['CE2','Le Cameroun et son milieu',['Régions et paysages','Ressources naturelles','Protection de l’environnement']],
  ['CE2','La santé',['Organes et fonctions','Hygiène et prévention','Maladies et soins']],
  ['CE2','Le monde vivant',['Plantes','Animaux','Écosystèmes et interactions']],
  ['CE2','Activités économiques',['Agriculture','Élevage et pêche','Commerce et industrie']],
  ['CE2','Citoyenneté',['Règles de vie','Droits et responsabilités','Solidarité et vivre-ensemble']],
  ['CE2','Sciences et technologie',['Matière et énergie','Objets techniques','Usages responsables']],
  ['CM1','Le Cameroun et le monde',['Territoire et population','Ressources','Ouverture au monde']],
  ['CM1','Santé et bien-être',['Système nerveux','Respiration et circulation','Hygiène et prévention']],
  ['CM1','Environnement et écosystèmes',['Relations entre êtres vivants','Équilibres','Protection du milieu']],
  ['CM1','Histoire et citoyenneté',['Repères historiques','Première Guerre mondiale','Droits humains et vivre-ensemble']],
  ['CM1','Sciences et technologie',['Matière','Énergie','Technologies et usages']],
  ['CM1','Mathématiques et mesures',['Nombres et calculs','Mesures','Géométrie et problèmes']],
  ['CM2','Le Cameroun et le monde',['Territoire et population','Ressources et développement','Relations avec le monde']],
  ['CM2','Santé, hygiène et prévention',['Systèmes du corps humain','Maladies et prévention','Protection de la santé']],
  ['CM2','Phénomènes naturels et environnement',['Phénomènes naturels','Écosystèmes','Prévention et protection de l’environnement']],
  ['CM2','Histoire, citoyenneté et droits',['Repères historiques','Droits humains','Citoyenneté et paix']],
  ['CM2','Sciences et technologie',['Matière et transformations','Énergie','Technologies de l’information']],
  ['CM2','Mathématiques et résolution de problèmes',['Nombres et calculs','Mesures et grandeurs','Géométrie, données et problèmes']],
  ['CM2','Langues et communication',['Compréhension et expression','Vocabulaire et grammaire','Communication orale et écrite']]
].map(([level,name,topics],i)=>({level,name,description:topics.join(' • '),sortOrder:i+1,topics}));

export function defaultCompetencies(level, subject){
  const templates={
    'Français':`Communiquer correctement en français à l’oral et à l’écrit au niveau ${level}.`,
    'English':`Use simple English appropriately in oral and written communication at ${level} level.`,
    'Mathématiques':`Mobiliser des notions mathématiques pour raisonner, calculer et résoudre une situation-problème au niveau ${level}.`,
    'Sciences et technologie':`Observer, expliquer et appliquer une démarche scientifique adaptée au niveau ${level}.`,
    'Éducation à la citoyenneté':`Adopter des comportements responsables et respectueux dans la communauté au niveau ${level}.`,
    'Histoire':`Construire des repères historiques et relier les faits étudiés à la vie citoyenne au niveau ${level}.`,
    'Géographie':`Décrire et expliquer des espaces, milieux et activités humaines au niveau ${level}.`,
    'Éducation physique et sportive':`Développer des habiletés motrices et respecter les règles de pratique collective au niveau ${level}.`,
    'Arts et culture':`S’exprimer et apprécier des productions artistiques et culturelles adaptées au niveau ${level}.`,
    'Technologies de l’information et de la communication':`Utiliser des outils numériques de manière responsable pour apprendre et communiquer au niveau ${level}.`
  };
  return templates[subject]||`Développer une compétence disciplinaire et transversale adaptée au niveau ${level}.`;
}

export function makeIntegrationSituation(level, subject, unit){
  return {title:`Situation d’intégration — ${unit}`,level,subject,unit,description:`À partir d’une situation concrète liée à « ${unit} », l’apprenant de ${level} mobilise ses connaissances et savoir-faire en ${subject} pour produire une réponse, expliquer sa démarche et justifier son choix.`};
}
