export const STAGE_NAMES = [
  'Éveil','Révision','Motivation','Découverte','Analyse — Je fais','Analyse — Tu/Nous faisons','Analyse — Tu fais','Synthèse','Consolidation','Évaluation','Activités d’intégration partielle'
];

export function generateStages({level,subject,unit,title,competency,situation,objective,material}){
  const m=material||'Tableau, supports visuels, objets ou documents liés à la leçon';
  return STAGE_NAMES.map((name,i)=>({
    order:i+1,name,
    teacher:i===0?`L’enseignant crée un court éveil en lien avec « ${unit} » et fait émerger les représentations initiales.`
      :i===1?`L’enseignant rappelle les acquis nécessaires et vérifie rapidement les prérequis.`
      :i===2?`L’enseignant présente une situation motivante liée à « ${title} » et annonce le défi d’apprentissage.`
      :i===3?`L’enseignant fait observer, manipuler, lire ou comparer les supports puis recueille les hypothèses.`
      :i===4?`Je fais : l’enseignant modélise la démarche attendue, verbalise les étapes et montre un exemple complet.`
      :i===5?`Tu/Nous faisons : l’enseignant guide une réalisation collective ou par groupes, questionne et corrige immédiatement.`
      :i===6?`Tu fais : l’enseignant donne une tâche individuelle permettant de vérifier l’appropriation de la démarche.`
      :i===7?`L’enseignant fait formuler la règle, la procédure ou les connaissances essentielles à retenir.`
      :i===8?`L’enseignant propose des exercices gradués et une remédiation ciblée selon les difficultés observées.`
      :i===9?`L’enseignant évalue individuellement l’objectif : ${objective}. Il relève les réussites et les besoins de remédiation.`
      :`L’enseignant propose une tâche contextualisée permettant de mobiliser la compétence dans une situation nouvelle.`,
    learner:i===0?'Les apprenants observent, répondent librement et expriment leurs représentations.':
      i===1?'Les apprenants rappellent les notions déjà étudiées et répondent aux questions de révision.':
      i===2?'Les apprenants observent la situation, réagissent et formulent des hypothèses.':
      i===3?'Les apprenants observent, manipulent, décrivent, comparent et proposent des explications.':
      i===4?'Les apprenants suivent la démonstration, observent la procédure et reformulent les étapes.':
      i===5?'Les apprenants réalisent la tâche avec leurs pairs, expliquent leurs choix et corrigent leurs erreurs.':
      i===6?'Chaque apprenant réalise la tâche individuellement et justifie sa réponse.':
      i===7?'Les apprenants formulent avec leurs mots l’essentiel à retenir et le notent si nécessaire.':
      i===8?'Les apprenants s’exercent, appliquent la règle et reprennent les points non maîtrisés.':
      i===9?'Chaque apprenant réalise l’évaluation individuellement.':
      'Les apprenants mobilisent leurs acquis pour traiter la situation et communiquent leur solution.',
    grouping:i===4?'Collectif — classe':i===5?'Groupes / binômes':(i===6||i===9)?'Individuel':'Collectif / individuel',
    material:m
  }));
}

export function generateLessonContent(input){
  const stages=generateStages(input);
  return {version:1, pedagogy:'Approche par expérimentation / démarche active', stages, metadata:{generatedAt:new Date().toISOString()}};
}
