import 'dotenv/config';
import {prisma} from './db.js';
import {LEVELS,SUBJECTS,UNITS,defaultCompetencies,makeIntegrationSituation} from './data/curriculum.js';
import {generateLessonContent} from './data/pedagogy.js';

const samples=[
 ['SIL','Français','La maison','Les membres de la famille'],
 ['SIL','Mathématiques','La maison','Reconnaître et comparer des quantités'],
 ['CP','Français','L’école','Nommer quelques objets de la classe'],
 ['CP','Mathématiques','L’école','Lire et écrire les nombres étudiés'],
 ['CE1','Sciences et technologie','La santé et l’hygiène','Les règles d’hygiène corporelle'],
 ['CE1','Français','L’école et la citoyenneté','Raconter une activité scolaire dans l’ordre'],
 ['CE2','Mathématiques','Le Cameroun et son milieu','Résoudre un problème de mesures'],
 ['CE2','Sciences et technologie','Le monde vivant','Identifier des relations entre êtres vivants'],
 ['CM1','Français','Histoire et citoyenneté','Produire un compte rendu oral chronologique'],
 ['CM1','Mathématiques','Mathématiques et mesures','Résoudre un problème de mesures de longueur'],
 ['CM1','Sciences et technologie','Santé et bien-être','Le système circulatoire'],
 ['CM2','Français','Langues et communication','Appliquer la graphie des mots en -aie, -ail, -eil, -euil, -aille, -eille'],
 ['CM2','English','Langues et communication','Opposite of one-syllable words'],
 ['CM2','Sciences et technologie','Phénomènes naturels et environnement','Les phénomènes naturels'],
 ['CM2','Mathématiques','Mathématiques et résolution de problèmes','Le diagramme de Venn et le cardinal d’un ensemble']
];

for(const l of LEVELS) await prisma.curriculumLevel.upsert({where:{name:l.name},update:l,create:l});
for(const s of SUBJECTS) await prisma.subject.upsert({where:{name:s.name},update:s,create:s});
for(const u of UNITS) await prisma.learningUnit.upsert({where:{name_level:{name:u.name,level:u.level}},update:{description:u.description,sortOrder:u.sortOrder,active:true},create:{name:u.name,level:u.level,description:u.description,sortOrder:u.sortOrder,active:true}});

for(const [level,subject,unit,title] of samples){
 const competency=defaultCompetencies(level,subject);
 const situation=makeIntegrationSituation(level,subject,unit).description;
 const objective=`À l’issue de la séance, l’apprenant de ${level} sera capable de ${title.toLowerCase()} dans une situation concrète.`;
 const contentJson=generateLessonContent({level,subject,unit,title,competency,situation,objective,material:'Tableau, manuel, objets/supports visuels et fiches d’activité'});
 const existing=await prisma.lesson.findFirst({where:{level,subject,unit,title}});
 if(existing) await prisma.lesson.update({where:{id:existing.id},data:{competency,situation,objective,material:'Tableau, manuel, objets/supports visuels et fiches d’activité',contentJson,published:true}});
 else await prisma.lesson.create({data:{level,subject,unit,title,competency,situation,objective,material:'Tableau, manuel, objets/supports visuels et fiches d’activité',contentJson,published:true}});
}
for(const lesson of await prisma.lesson.findMany()){ const stages=Array.isArray(lesson.contentJson?.stages)?lesson.contentJson.stages:[]; await prisma.lessonStage.deleteMany({where:{lessonId:lesson.id}}); if(stages.length) await prisma.lessonStage.createMany({data:stages.map((x,i)=>({lessonId:lesson.id,order:x.order||i+1,name:x.name,teacher:x.teacher,learner:x.learner,grouping:x.grouping,material:x.material||null}))}); }
for(const u of UNITS) for(const [i,topic] of (u.topics||[]).entries()) await prisma.curriculumTopic.upsert({where:{level_subject_unit_name:{level:u.level,subject:'Transversal',unit:u.name,name:topic}},update:{description:`Thème de travail : ${topic}`,sortOrder:i+1,active:true},create:{level:u.level,subject:'Transversal',unit:u.name,name:topic,description:`Thème de travail : ${topic}`,sortOrder:i+1,active:true}});
const year=await prisma.academicYear.upsert({where:{label:'2026-2027'},update:{active:true},create:{label:'2026-2027',active:true}});
for(let i=1;i<=3;i++){
 const term=await prisma.term.upsert({where:{academicYearId_order:{academicYearId:year.id,order:i}},update:{name:`Trimestre ${i}`,objective:`Objectifs prioritaires du trimestre ${i}`},create:{academicYearId:year.id,name:`Trimestre ${i}`,order:i,objective:`Objectifs prioritaires du trimestre ${i}`} });
 for(let w=1;w<=12;w++) await prisma.week.upsert({where:{termId_number:{termId:term.id,number:w}},update:{label:`Semaine ${(i-1)*12+w}`,focus:'À planifier'},create:{termId:term.id,number:w,label:`Semaine ${(i-1)*12+w}`,focus:'À planifier'}});
}
console.log(`V7 seed terminé : ${LEVELS.length} niveaux, ${SUBJECTS.length} matières, ${UNITS.length} unités, ${samples.length} fiches exemples, 11 étapes par fiche et une année scolaire 2026-2027 structurée en 3 trimestres / 36 semaines.`);
await prisma.$disconnect();
