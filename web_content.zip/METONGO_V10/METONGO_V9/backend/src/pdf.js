import PDFDocument from "pdfkit";
export function lessonPdf(l,res){
 const d=new PDFDocument({size:"A4",margin:42});
 res.setHeader("Content-Type","application/pdf");
 res.setHeader("Content-Disposition",`attachment; filename="metongo-fiche-${l.id}.pdf"`);
 d.pipe(res);
 d.fontSize(15).text("METONGO SERGES HERVÉ ÉDUCATION",{align:"center"});
 d.fontSize(9).text("Enseignement maternel et primaire — Cameroun",{align:"center"});
 d.moveDown(); d.fontSize(17).text("FICHE DE PRÉPARATION",{align:"center",underline:true}); d.moveDown(); d.fontSize(10);
 for(const [k,v] of [["Niveau",l.level],["Matière",l.subject],["Unité d’apprentissage",l.unit],["Leçon",l.title],["Énoncé de compétence",l.competency],["Situation-problème",l.situation],["Objectif pédagogique",l.objective],["Matériel didactique",l.material||"À préciser"]]){d.font("Helvetica-Bold").text(`${k} : `,{continued:true}).font("Helvetica").text(v||"—");d.moveDown(.25)}
 d.moveDown();d.fontSize(12).font("Helvetica-Bold").text("DÉROULEMENT EN 11 ÉTAPES");d.moveDown(.5);
 const stages=l.contentJson?.stages||[];
 if(stages.length){stages.forEach((s,i)=>{d.fontSize(10).font("Helvetica-Bold").text(`${i+1}. ${s.name}`);d.font("Helvetica").text(`Enseignant : ${s.teacher||"—"}`);d.text(`Apprenants : ${s.learner||"—"}`);d.text(`Regroupement : ${s.grouping||"—"}`);d.text(`Matériel : ${s.material||l.material||"—"}`);d.moveDown(.45)})}
 else {d.font("Helvetica").text("Le déroulement détaillé n’est pas encore renseigné.")}
 d.end();
}
