const host=()=>process.env.CAMPAY_BASE_URL||"https://demo.campay.net";
let cache={token:null,expires:0};

async function token(){
 if(cache.token && Date.now()<cache.expires)return cache.token;
 const r=await fetch(`${host()}/api/token/`,{
   method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({username:process.env.CAMPAY_USERNAME,password:process.env.CAMPAY_PASSWORD})
 });
 if(!r.ok)throw new Error("Authentification CamPay impossible.");
 const j=await r.json();
 const t=j.token||Object.values(j)[0];
 if(!t)throw new Error("Token CamPay absent.");
 cache={token:t,expires:Date.now()+50*60*1000};
 return t;
}

export async function createPayment({amount,phone,description,externalReference}){
 const t=await token();
 const r=await fetch(`${host()}/api/collect/`,{
  method:"POST",
  headers:{"Authorization":`Token ${t}`,"Content-Type":"application/json"},
  body:JSON.stringify({amount:String(amount),currency:"XAF",from:phone,description,external_reference:externalReference})
 });
 const j=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(j.message||"CamPay a refusé l'initiation.");
 return {reference:j.reference||Object.values(j)[0],operator:j.operator,ussd_code:j.ussd_code,status:"PENDING",raw:j};
}

export async function paymentStatus(reference){
 const t=await token();
 const r=await fetch(`${host()}/api/transaction/${encodeURIComponent(reference)}/`,{
  headers:{"Authorization":`Token ${t}`,"Content-Type":"application/json"}
 });
 const j=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(j.message||"Impossible de vérifier le paiement.");
 return j;
}

export async function paymentLink({amount,description,externalReference,redirectUrl}){
 const t=await token();
 const r=await fetch(`${host()}/api/get_payment_link/`,{
  method:"POST",
  headers:{"Authorization":`Token ${t}`,"Content-Type":"application/json"},
  body:JSON.stringify({amount:String(amount),currency:"XAF",description,external_reference:externalReference,redirect_url:redirectUrl})
 });
 const j=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(j.message||"Impossible de créer le lien de paiement.");
 return {link:j.link||Object.values(j)[0],raw:j};
}
