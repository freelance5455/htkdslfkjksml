import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { prisma } from './db.js';
const { ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME, ADMIN_PHONE } = process.env;
if (!ADMIN_EMAIL || !ADMIN_PASSWORD || !ADMIN_NAME || !ADMIN_PHONE) {
  console.error('Définissez ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME et ADMIN_PHONE dans .env avant de lancer npm run admin:create.');
  process.exit(1);
}
if (ADMIN_PASSWORD.length < 12) {
  console.error('Pour le compte administrateur, choisissez un mot de passe de 12 caractères minimum.');
  process.exit(1);
}
try {
  const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 12);
  const existing = await prisma.user.findUnique({ where: { email: ADMIN_EMAIL } });
  const user = existing
    ? await prisma.user.update({ where: { email: ADMIN_EMAIL }, data: { name: ADMIN_NAME, phone: ADMIN_PHONE, passwordHash, role: 'ADMIN' } })
    : await prisma.user.create({ data: { name: ADMIN_NAME, phone: ADMIN_PHONE, email: ADMIN_EMAIL, passwordHash, role: 'ADMIN', points: 0 } });
  console.log(`Compte administrateur prêt : ${user.email} (${user.role}).`);
} catch (error) {
  console.error('Impossible de créer le compte administrateur. Vérifiez que l’e-mail et le téléphone ne sont pas déjà utilisés par un autre compte.');
  process.exitCode = 1;
} finally {
  await prisma.$disconnect();
}
