# METONGO Serges Hervé Éducation — V7

V6 ajoute un référentiel pédagogique versionnable et un éditeur administrateur complet des fiches et de leurs 11 étapes.

## Nouveautés
- Niveaux SIL, CP, CE1, CE2, CM1, CM2.
- Matières, unités, thèmes, compétences et situations d’intégration.
- Modèle `CurriculumTopic` pour détailler les unités.
- Modèle `LessonStage` : les 11 étapes sont stockées séparément et éditables.
- Éditeur de fiche directement dans le panneau admin.
- Régénération contrôlée des 11 étapes.
- Sauvegarde atomique de la fiche et de ses étapes.
- Import V6 du référentiel.
- Export CSV des utilisateurs, fiches et paiements.

## Installation
1. Copier `backend/.env.example` vers `backend/.env`.
2. Démarrer PostgreSQL.
3. Dans `backend` : `npm install`.
4. `npx prisma generate`.
5. `npx prisma db push`.
6. `node src/seed.js`.
7. `node src/server.js`.

## Administration
Attribuer le rôle ADMIN à votre compte puis ouvrir `frontend/admin.html`.
Dans **Fiches pédagogiques**, cliquer sur **Éditer les 11 étapes** pour modifier chaque étape, son activité enseignant, l’activité des apprenants, le regroupement, le matériel et la durée.

## Référentiel
La base fournie est une base de travail structurée pour l’application. Les contenus destinés à être présentés comme référentiel réglementaire doivent être validés avec les documents officiels en vigueur du MINEDUB.

## V7 — Planification annuelle

V7 ajoute la gestion de la progression annuelle : année scolaire, trimestres, calendrier des semaines, séquences, leçons planifiées et objectifs par période. Une leçon planifiée peut être transformée automatiquement en fiche pédagogique complète avec les 11 étapes et ajoutée au catalogue.

La structure initiale 2026-2027 est une base configurable de 3 trimestres et 36 semaines. Elle ne constitue pas un calendrier scolaire officiel tant que les dates et périodes n’ont pas été validées avec le calendrier en vigueur.


# V8 — Interface mobile enseignant

V8 ajoute une véritable interface mobile-first destinée aux enseignants utilisant principalement un téléphone Android.

## Nouveautés
- `frontend/teacher.html` : espace enseignant mobile.
- Navigation basse tactile : Accueil, Planning, Nouvelle fiche, Fiches, Compte.
- Tableau de bord enseignant avec points, dernières fiches et accès rapides.
- Planning annuel consultable par trimestre, semaine, séquence et leçon.
- Historique des téléchargements personnels.
- Recherche et filtres par niveau dans la banque de fiches.
- Générateur de fiche conservé et accessible depuis le bouton central.
- Manifest PWA + service worker pour une expérience installable sur Android.
- Nouvelles routes authentifiées : `/api/teacher/dashboard` et `/api/teacher/planning`.

## Installation
Même installation backend que V7 : `npm install`, `npx prisma generate`, `npx prisma db push`, `node src/seed.js`, puis `node src/server.js`.

Pour l'utilisation sur téléphone, servir le dossier `frontend` via HTTPS ou un serveur web et configurer `METONGO_API_URL` vers l'API publique.


# V9 — Espace personnel de l’enseignant

V9 transforme l’espace mobile en véritable espace de travail individuel. Les données personnelles appartiennent à l’enseignant connecté et ne nécessitent aucune intervention de l’administration.

## Fonctionnalités V9

- **Mes classes** : création de classes par niveau, année scolaire et salle.
- **Effectifs** : ajout et suppression des élèves de chaque classe, avec comptage automatique.
- **Matières enseignées** : création de la liste personnelle des matières, éventuellement associées à un niveau.
- **Emploi du temps personnel** : créneaux par jour, horaires, classe, matière et salle.
- **Préparation « Aujourd’hui »** : affichage des cours du jour à partir de l’emploi du temps personnel et marquage d’une séance comme réalisée.
- **Mes fiches personnelles** : enregistrement de fiches générées par l’enseignant, indépendamment de la banque administrative.
- **Modification des fiches** : ouverture d’une fiche personnelle dans le générateur avec préremplissage, puis sauvegarde par modification.
- **Suivi des leçons réalisées** : historique personnel des séances, classe, date, état et notes.
- **Séparation des données** : les fiches personnelles, classes, élèves, matières, créneaux et suivis sont rattachés au compte de l’enseignant.
- **Mobile-first** : navigation adaptée au téléphone Android.

## Nouveaux modèles de données

`TeacherClass`, `Student`, `TeacherSubject`, `ScheduleEntry`, `PersonalLesson` et `LessonRecord`.

## Nouvelles routes API

- `GET /api/teacher/profile`
- `POST/PATCH/DELETE /api/teacher/classes`
- `GET/POST/DELETE /api/teacher/classes/:id/students`
- `POST/DELETE /api/teacher/subjects`
- `POST/DELETE /api/teacher/schedule`
- `GET /api/teacher/today`
- `GET/POST/PATCH/DELETE /api/teacher/personal-lessons`
- `POST/PATCH /api/teacher/records`

## Mise à niveau

Après remplacement des fichiers V8 par cette version :

```bash
cd backend
npm install
npx prisma generate
npx prisma db push
node src/seed.js
node src/server.js
```

Aucune modification du référentiel pédagogique existant n’est nécessaire. Les données personnelles sont créées au fur et à mesure par chaque enseignant.


# V10 — Carnet de bord de l’enseignant

V10 ajoute un véritable carnet de bord personnel, entièrement rattaché au compte de l’enseignant. L’administration n’a pas besoin d’intervenir pour saisir ou modifier ces données personnelles.

## Fonctionnalités V10

- **Présences** : appel par classe et par date avec statuts Présent, Absent, Retard et Excusé.
- **Évaluations et notes** : création d’une évaluation, choix du barème, saisie des notes élève par élève et calcul des moyennes.
- **Observations** : observations générales de classe ou individuelles, classées par catégorie (pédagogique, comportement, assiduité, accompagnement, réussite).
- **Cahier de textes** : date, classe, matière, titre de la leçon, contenu/activité, compétence et devoir.
- **Progression** : statistiques par classe sur les leçons réalisées, planifiées ou manquées et moyenne des évaluations.
- **Tableau de bord individuel** : nombre de classes, effectifs, leçons réalisées sur 30 jours, taux de présence et moyenne récente.
- **Mobile-first** : toutes les fonctions sont utilisables depuis un téléphone Android.

## Nouveaux modèles Prisma

`Attendance`, `Assessment`, `AssessmentScore`, `Observation` et `DiaryEntry`.

## Nouvelles routes principales

- `GET /api/teacher/board`
- `GET/POST /api/teacher/attendance` et `/api/teacher/attendance/bulk`
- `GET/POST/PATCH/DELETE /api/teacher/assessments`
- `GET/POST/DELETE /api/teacher/observations`
- `GET/POST/DELETE /api/teacher/diary`
- `GET /api/teacher/progress`

## Mise à niveau depuis V9

Dans `backend` :

```bash
npm install
npx prisma generate
npx prisma db push
node src/seed.js
node src/server.js
```

`prisma db push` crée les nouvelles tables V10 tout en conservant les données personnelles V9. Pour une production, utiliser ensuite une stratégie de migrations Prisma versionnées.

## Sécurité des données personnelles

Chaque présence, note, observation, entrée de cahier et statistique est filtrée par l’identifiant de l’enseignant connecté. Un enseignant ne peut pas consulter les données personnelles d’un autre enseignant par les routes V10.

## Validation du référentiel

Comme pour les versions précédentes, le référentiel pédagogique fourni dans l’application doit être contrôlé et validé avec les documents officiels du MINEDUB avant d’être présenté comme référentiel réglementaire.


# V11 — Bulletin scolaire automatique

V11 ajoute un véritable module de bulletin scolaire personnel. L’enseignant crée une période (trimestre, semestre ou période personnalisée), choisit la classe et active ou désactive le classement. Les évaluations enregistrées pendant la période sont normalisées sur 20 et regroupées par matière.

## Fonctionnalités V11
- Création des périodes de bulletin par classe.
- Dates de début et de fin facultatives.
- Calcul automatique de la moyenne de chaque matière.
- Calcul de la moyenne générale.
- Classement configurable (avec rang ou sans rang).
- Appréciation automatique selon la moyenne, modifiable avant édition.
- Décision automatique « Admis » ou « À renforcer », modifiable.
- Génération et conservation d’un bulletin par élève.
- Prévisualisation des résultats avant génération.
- Génération d’un PDF individuel imprimable pour chaque élève.
- Données strictement rattachées à l’enseignant connecté.

## Nouveaux modèles
`BulletinPeriod`, `Bulletin`, `BulletinSubject`.

## Routes principales
- `GET/POST /api/teacher/bulletin-periods`
- `GET /api/teacher/bulletin-periods/:id/preview`
- `POST /api/teacher/bulletin-periods/:id/generate`
- `GET /api/teacher/bulletin-periods/:id/bulletins`
- `PATCH /api/teacher/bulletins/:id`
- `GET /api/teacher/bulletins/:id/pdf`

## Mise à niveau
Dans `backend` :
```bash
npm install
npx prisma generate
npx prisma db push
node src/server.js
```

# V12 — gestion scolaire complète

V12 transforme le module de bulletins en espace de gestion scolaire complet.

## Nouveautés
- Résultats cumulés des périodes et moyenne annuelle par élève.
- Relevé annuel PDF pour toute une classe.
- Génération groupée de tous les bulletins d’une période dans un seul PDF, une page par élève.
- Conseils de classe : réunion, résumé, recommandations et procès-verbal PDF.
- Décisions de passage individualisées : passage, maintien, redoublement, orientation ou décision à confirmer.
- Certificat scolaire et relevé de notes PDF pour un élève.
- Identité de l’établissement : nom, adresse, contacts, chef d’établissement, nom de signature et libellé du cachet.
- Signature/cachet utilisés dans les documents PDF.
- Toutes les données restent rattachées à l’enseignant connecté.

## Nouveaux modèles Prisma
`SchoolProfile`, `CouncilMeeting`, `CouncilDecision`, `SchoolDocument`.

## Routes V12 principales
- `GET/PUT /api/teacher/school-profile`
- `GET /api/teacher/annual-results/:classId`
- `GET /api/teacher/annual-results/:classId/pdf`
- `GET /api/teacher/bulletin-periods/:id/group-pdf`
- `GET /api/teacher/council-meetings`
- `POST /api/teacher/council-meetings`
- `GET/POST /api/teacher/council-decisions`
- `GET/POST /api/teacher/school-documents`
- `GET /api/teacher/students/:id/document/:type/pdf`
- `GET /api/teacher/council-meetings/:id/pdf`

## Mise à niveau
Dans `backend` :
```bash
npm install
npx prisma generate
npx prisma db push
node src/server.js
```
Pour une production, remplacer progressivement `db push` par des migrations Prisma versionnées.
