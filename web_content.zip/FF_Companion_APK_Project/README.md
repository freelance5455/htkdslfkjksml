# FF Companion Panel — Android project

This is a native Android WebView wrapper around the offline FF Companion Panel. It includes the same sensitivity planner, DPI helper, HUD guidance, performance checklist, and crosshair practice preview.

## Build on an Android phone with Code on the Go

1. Install **Code on the Go** from its official page: https://www.appdevforall.org/code-on-the-go/
2. Open Code on the Go and complete its one-time build-tools setup. This can require several GB of free storage and Wi-Fi.
3. Extract this ZIP in your phone's Downloads folder using ZArchiver.
4. In Code on the Go, choose **Open existing project** and select the extracted `FF_Companion_APK_Project` folder (the folder containing `settings.gradle`).
5. Wait for Gradle sync to finish. If it asks to download Gradle or Android Gradle Plugin dependencies, allow it.
6. Choose **Build** / **Build APK** (or Run, depending on the app version) and select the debug APK build.
7. Export the generated APK from Code on the Go. The usual Gradle output path is `app/build/outputs/apk/debug/app-debug.apk`.
8. Open the exported APK from Files and install it. Android may ask you to allow installs from that source.

## Build on a computer

Open this folder in Android Studio and build the `app` debug variant. Requires Android SDK platform 35 and a compatible Gradle 8.13 / Android Gradle Plugin 8.11.1 setup.

## Notes

- Package ID: `com.senjo.ffpanel`
- Minimum Android version: Android 6.0 (API 23)
- Target SDK: 34
- The app works offline after installation and does not require storage, overlay, accessibility, or network permissions.
- This is an unofficial companion/settings/training app. It does not modify Free Fire, inject into the game, bypass anti-cheat, or provide aimbot/wallhack features.
