# ANONYMOUX STUDIO 2.3.2 — Creator Dashboard Implementation Report

## Scope

Replaced the previous small workspace-link dashboard with a user-scoped creator control room. All dashboard figures are queried from authenticated account records and existing application tables; no sample balances, fabricated generation counts, synthetic job states or placeholder transactions are used.

## Implemented

- **Account overview:** actual image/video job counts, saved Fish Audio generations, recorded realtime sessions, active platform jobs/realtime sessions, role, account creation date and last login.
- **Wallet:** existing `user_wallets` / `credit_transactions` ledger via `voice_wallet_balance()`, actual debits, and latest eight ledger entries including posted balance after each transaction.
- **Recent creations:** real platform jobs, voice history and realtime session rows. Filters for All, Image, Video, Voice and Realtime. Displays provider/database status, model, prompt excerpt and timestamp. Completed outputs have view/play/download endpoints; non-complete records route to history/workspace detail.
- **Quick create:** routes to the existing Image, Video, Realtime and Voice workspaces, Image Studio for a new image project, existing reference-upload workflow, and prompt library.
- **Storage overview:** scans stored image/video outputs, source files, reference files and voice audio, with type breakdown, total file count, configured quota and free capacity.
- **Storage enforcement:** shared account quota is checked for incoming Image/Video files, reference-image changes, saved voice audio and completed image/video outputs. File sizes are based on actual disk files; unsafe symlink paths are ignored.
- **Notifications:** idempotent events for completed/failed image/video jobs, successful/failed Fish Audio requests, ended realtime sessions, low wallet balance, storage warning and successful sign-in. Notification read state is constrained to the signed-in user.
- **Personal activity:** recently used workspaces (last 50 retained), recent generations, saved custom prompts and recent reference uploads.
- **Security details:** displays actual account state, creation and last-login values. Email verification is explicitly labelled untracked. Password change and multi-session management are explicitly labelled not implemented; no false verification/security claims are displayed.

## Source changes

- `dashboard.php` — dashboard UI, filtering, actual data rendering and notification interactions.
- `app/dashboard_data.php` — authenticated account-scoped queries and storage report.
- `app/resources.php` — notification schema/events and recent workspace tracking.
- `app/platform.php` — consistent storage accounting and upload/output capacity checks.
- `app/voice.php` — voice-audio quota check before persisting output.
- `api/reference.php` — reference replacement capacity check.
- `api/image-generate.php`, `api/video-jobs.php` — capacity check before retaining completed generated output.
- `api/notifications.php` — account-scoped read/read-all endpoint protected by API guard and CSRF.
- `app/auth.php` — actual sign-in notification after successful login; optional event failures do not block login.
- `app/platform_header.php`, `app/platform_footer.php`, `assets/dashboard.css`, `assets/resources.js` — shared navigation, styles and interaction.

## Accuracy / known limits

1. The current application has no separate project entity/table. The dashboard calls stored workspace jobs **recent generations**, not projects. The New Project shortcut starts the existing Image Studio workflow.
2. The current wallet is an in-app credit ledger. This baseline has no payment-order/event ledger, so payment success/failure states are not invented or shown.
3. Email verification fields and password-change/session-management flows are absent in the baseline schema/application. The dashboard calls these out as unavailable.
4. Voice history contains completed saved files; `voice_usage` provides genuine success/failure request events, so failed attempts can appear as notifications but not as playable saved creations.
5. Realtime session history records start/end and session state; only actual ended sessions are notified. The current schema does not provide a durable output media file for realtime, so no download button is fabricated.
6. Storage output capacity can only be tested against real files on the deployed host. If a provider finishes an output that would exceed the quota, the job is recorded as failed locally with a clear storage message and the output is not retained. External provider billing behavior is provider/account dependent and is not asserted here.

## Verification

- PHP syntax: 49/49 files passed.
- JavaScript syntax: 8/8 files passed.
- SQLite migration test: passed (Python SQLite engine; see `TEST_RESULTS.md`).
- PHP PDO persistence smoke test: skipped because this runtime has no `pdo_sqlite` or `pdo_mysql` driver.
- Live per-user isolation and output access tests: require a real database and authenticated deployment; not claimed as passed.
