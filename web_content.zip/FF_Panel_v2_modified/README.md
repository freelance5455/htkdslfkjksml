# FF Panel v2 — Key Set Update

ดัดแปลงจาก FF Panel v2 เดิม โดยคงหน้าตาและ Aim Trainer/Connection/Event Log เดิม และเปลี่ยนชุดคีย์เป็น:

- Normal 20 keys
- Premium 20 keys
- 1 key ผูกได้ 1 device
- แยก tier Normal/Premium ทั้งหน้าเว็บและ API

ไฟล์หลัก: `index.html`, `server.js`, `package.json`.

หมายเหตุ: Aim Trainer เป็นสนามฝึกเท่านั้น ไม่อ่าน/แก้ memory หรือ traffic ของ Free Fire และไม่มี anti-ban, anti-cheat bypass, inject, hook หรือ auto-aim ในเกมจริง.

ก่อน deploy จริง ให้เปลี่ยน `ADMIN_TOKEN`.
