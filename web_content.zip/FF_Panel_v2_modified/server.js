import express from "express";
import crypto from "node:crypto";
const app=express(); app.use(express.json());
const PORT=process.env.PORT||3000;
const ADMIN_TOKEN=process.env.ADMIN_TOKEN||"CHANGE_ME_BEFORE_DEPLOYMENT";
const keys=new Map([
["NORMAL-01-Q7M2K",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-02-R8N4L",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-03-T5P7V",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-04-U9K2D",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-05-I6H8F",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-06-A3J5S",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-07-D8L1A",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-08-F4Q9Z",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-09-J7W3X",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-10-K2E6C",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-11-X5R8V",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-12-C9T4B",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-13-B6Y2N",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-14-M3U7I",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-15-W8O5P",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-16-R1A9S",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-17-D4G6H",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-18-H7J2K",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-19-J5L8M",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["NORMAL-20-P9Q3W",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-01-A7X9P",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-02-B4K2M",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-03-C8Q5R",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-04-D1T7V",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-05-E6N3Z",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-06-F9H4L",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-07-G2W8S",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-08-H5J1D",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-09-I7P3K",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-10-J4R9X",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-11-K8M2Q",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-12-L6V5T",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-13-M3Z7A",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-14-N9C4B",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-15-P2D8F",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-16-Q5G1H",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-17-R7K6L",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-18-S4M9N",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-19-T8P2W",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREMIUM-20-V3X5Y",{tier:"premium",active:true,maxDevices:1,devices:new Set()}]
]);
const hash=v=>crypto.createHash("sha256").update(String(v)).digest("hex");
const admin=(req,res,next)=>req.headers.authorization===`Bearer ${ADMIN_TOKEN}`?next():res.status(401).json({ok:false,error:"unauthorized"});
app.get("/health",(q,r)=>r.json({ok:true,service:"ff-panel-key-api"}));
app.post("/api/key/activate",(req,res)=>{const key=String(req.body?.key||"").trim().toUpperCase(),token=req.body?.deviceToken;if(!key||typeof token!=="string")return res.status(400).json({ok:false,error:"missing_parameters"});const k=keys.get(key);if(!k||!k.active)return res.status(403).json({ok:false,error:"invalid_or_disabled_key"});const d=hash(token);if(k.devices.has(d))return res.json({ok:true,tier:k.tier,message:"already_bound"});if(k.devices.size>=k.maxDevices)return res.status(409).json({ok:false,error:"device_limit_reached"});k.devices.add(d);res.json({ok:true,tier:k.tier,message:"activated"})});
app.get("/api/key/status",(req,res)=>{const k=keys.get(String(req.query.key||"").trim().toUpperCase());if(!k)return res.status(404).json({ok:false,error:"key_not_found"});res.json({ok:true,tier:k.tier,active:k.active,devicesUsed:k.devices.size,devicesAllowed:k.maxDevices})});
app.post("/api/admin/revoke-device",admin,(req,res)=>{const k=keys.get(String(req.body?.key||"").trim().toUpperCase());if(!k)return res.status(404).json({ok:false,error:"key_not_found"});k.devices.delete(hash(req.body?.deviceToken||""));res.json({ok:true,message:"device_unbound"})});
app.post("/api/admin/disable-key",admin,(req,res)=>{const k=keys.get(String(req.body?.key||"").trim().toUpperCase());if(!k)return res.status(404).json({ok:false,error:"key_not_found"});k.active=false;res.json({ok:true,message:"key_disabled"})});
app.listen(PORT,()=>console.log(`FF Panel API listening on :${PORT}`));