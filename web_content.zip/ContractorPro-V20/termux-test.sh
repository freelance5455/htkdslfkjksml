#!/data/data/com.termux/files/usr/bin/bash
# Contractor Pro V20 - quick test on Termux (Android). No database, no Docker, no npm install needed.
# Usage:  1) copy ContractorPro-V20.zip and this file into the same folder (e.g. Downloads)
#         2) in Termux:  termux-setup-storage   (once, allow access)   then   cd ~/storage/downloads
#         3) bash termux-test.sh          (stop with:  bash termux-test.sh stop)
# Test data lives in RAM only: restarting the server erases server-side accounts. The app's own data stays in your browser.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; WORK="$HOME/cp-test"; API_PORT=8080; WEB_PORT=8000
stop_all() { for f in "$WORK/api.pid" "$WORK/web.pid"; do [ -f "$f" ] && kill "$(cat "$f")" 2>/dev/null || true; rm -f "$f"; done; }
if [ "$1" = "stop" ]; then stop_all; echo "Stopped."; exit 0; fi
if [ -z "$SKIP_PKG" ] && command -v pkg >/dev/null 2>&1; then
  echo "[1/4] Installing Node.js and unzip (first run only)..."; pkg install -y nodejs unzip >/dev/null 2>&1 || pkg install -y nodejs unzip
fi
command -v node >/dev/null || { echo "Node.js is missing. Run: pkg install nodejs unzip"; exit 1; }
ZIP="$(ls "$HERE"/ContractorPro-V20*.zip 2>/dev/null | head -1)"
[ -n "$ZIP" ] || ZIP="$(ls ./ContractorPro-V20*.zip 2>/dev/null | head -1)"
[ -n "$ZIP" ] || { echo "ContractorPro-V20.zip not found next to this script."; exit 1; }
echo "[2/4] Unpacking $(basename "$ZIP") ..."
mkdir -p "$WORK"; stop_all
rm -rf "$WORK/ContractorPro-V20"; unzip -q -o "$ZIP" -d "$WORK"
cat > "$WORK/serve-web.mjs" <<'JS'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const root = path.join(process.env.HOME, 'cp-test/ContractorPro-V20/web'), port = Number(process.env.WEB_PORT) || 8000;
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
  const f = path.normalize(path.join(root, p)); if (!f.startsWith(root)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, b) => { if (e) { res.writeHead(404); return res.end('Not found'); } res.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-store' }); res.end(b); });
}).listen(port, '127.0.0.1', () => console.log('web on', port));
JS
echo "[3/4] Starting the API server (port $API_PORT) and the app (port $WEB_PORT) ..."
cd "$WORK/ContractorPro-V20/server"
FILES_DIR="$WORK/files" PORT=$API_PORT nohup node src/index.js > "$WORK/api.log" 2>&1 &
echo $! > "$WORK/api.pid"
cd "$WORK"; WEB_PORT=$WEB_PORT nohup node serve-web.mjs > "$WORK/web.log" 2>&1 &
echo $! > "$WORK/web.pid"
sleep 2
if command -v curl >/dev/null 2>&1; then curl -s "http://127.0.0.1:$API_PORT/health" | grep -q '"ok":true' && echo "API: OK" || { echo "API did not start. See $WORK/api.log"; tail -5 "$WORK/api.log"; exit 1; }; fi
cat <<MSG
[4/4] Ready.
  1. Open the browser on this phone and go to:   http://127.0.0.1:$WEB_PORT
  2. In the app: Settings > Services > Server URL = http://127.0.0.1:$API_PORT  > Save > Test connection
  3. Create an account (Account screen). Email codes are printed in:  $WORK/api.log
  Stop everything:  bash termux-test.sh stop
Notes: AI tools answer with the built-in local provider unless you start the server with ANTHROPIC_API_KEY (not allowed from Iran, see the sanctions note).
MSG
