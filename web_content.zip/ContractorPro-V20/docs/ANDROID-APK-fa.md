# ساخت APK با Capacitor (راهنما — در این بسته ساخته و آزمایش نشده است)

پیش‌نیاز: Node 20+، Android Studio، JDK 17.

1. پوشهٔ جدید بسازید و `web/` همین بسته را به‌عنوان `www` کپی کنید.
```
mkdir cp-android && cd cp-android
npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Contractor Pro" com.yourcompany.contractorpro --web-dir=www
mkdir www && cp ../ContractorPro-V20/web/index.html ../ContractorPro-V20/web/sw.js www/
npx cap add android && npx cap sync
npx cap open android      # در Android Studio: Build > Generate Signed Bundle/APK
```
2. در `capacitor.config.json` اگر سرور شما https است، `server.androidScheme` را `https` بگذارید. آدرس سرور را در صفحهٔ حساب اپ وارد کنید. برای سرور http محلی، `cleartext` را فقط برای آزمایش فعال کنید.
3. دسترسی دوربین: برای دکمهٔ «عکس» در Android WebView دسترسی `CAMERA` در `AndroidManifest.xml` لازم است. حتماً روی دستگاه واقعی آزمایش کنید (دوربین، آپلود آفلاین، امضا با لمس).
4. انتشار در Google Play: حساب توسعه‌دهنده، آیکون و اسکرین‌شات، سیاست حریم خصوصی. پرداخت اشتراک با رمزارز داخل اپ اندروید ممکن است با قوانین Play برای کالاهای دیجیتال تعارض داشته باشد؛ قبل از انتشار قوانین فعلی را بررسی کنید (من نمی‌توانم وضعیت امروز آن را از اینجا تأیید کنم).
