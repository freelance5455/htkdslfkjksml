import { randomUUID } from 'node:crypto';
import { GENESIS, chainHash } from './audit.js';
import { resolveChange } from './sync.js';

export class MemoryStore {
  kind = 'memory';
  users = new Map(); orgs = new Map(); members = new Map(); refresh = new Map(); otps = new Map();
  snaps = []; payments = new Map(); recs = new Map(); subs = new Map(); usage = new Map(); audits = []; cursor = 0;

  async createOrgWithOwner({ orgName, email, passwordHash, emailVerified = false }) {
    const org = { id: randomUUID(), name: orgName, createdAt: new Date().toISOString() };
    const user = { id: randomUUID(), email, passwordHash, emailVerified };
    this.orgs.set(org.id, org); this.users.set(user.id, user);
    this.members.set(user.id, { orgId: org.id, userId: user.id, role: 'owner' });
    this.subs.set(org.id, { orgId: org.id, licenseId: 'LIC-' + randomUUID().slice(0, 8).toUpperCase(), plan: 'free', status: 'active', expiresAt: null });
    return { org, user };
  }
  async createUser({ email, passwordHash }) { const user = { id: randomUUID(), email, passwordHash, emailVerified: false }; this.users.set(user.id, user); return user; }
  async getUserByEmail(email) { return [...this.users.values()].find(u => u.email === email) || null; }
  async getUserById(id) { return this.users.get(id) || null; }
  async setPassword(userId, passwordHash) { const u = this.users.get(userId); if (u) u.passwordHash = passwordHash; }
  async markVerified(userId) { const u = this.users.get(userId); if (u) u.emailVerified = true; }
  async getMembership(userId) { return this.members.get(userId) || null; }
  async listMembers(orgId) {
    return [...this.members.values()].filter(m => m.orgId === orgId).map(m => ({ id: m.userId, email: this.users.get(m.userId).email, role: m.role }));
  }
  async addMember({ orgId, userId, role }) { this.members.set(userId, { orgId, userId, role }); }
  async setRole(orgId, userId, role) { const m = this.members.get(userId); if (m && m.orgId === orgId) { m.role = role; return true; } return false; }

  async saveRefresh(hash, userId, expiresAt) { this.refresh.set(hash, { userId, expiresAt }); }
  async takeRefresh(hash) { const r = this.refresh.get(hash); this.refresh.delete(hash); return r && r.expiresAt > Date.now() ? r : null; }
  async revokeRefresh(userId) { for (const [k, v] of this.refresh) if (v.userId === userId) this.refresh.delete(k); }

  async setOtp(email, codeHash, expiresAt) { this.otps.set(email, { codeHash, expiresAt, attempts: 0 }); }
  async getOtp(email) { return this.otps.get(email) || null; }
  async bumpOtp(email) { const o = this.otps.get(email); if (o) o.attempts++; }
  async deleteOtp(email) { this.otps.delete(email); }

  async pushSnapshot(orgId, deviceId, data) { this.cursor++; this.snaps.push({ cursor: this.cursor, orgId, deviceId, data }); return this.cursor; }
  async latestSnapshot(orgId) { for (let i = this.snaps.length - 1; i >= 0; i--) if (this.snaps[i].orgId === orgId) return this.snaps[i]; return null; }

  async applyChange(orgId, ch) {
    const key = `${orgId}|${ch.module}|${ch.id}`, ex = this.recs.get(key) || null;
    const r = resolveChange(ex, ch);
    if (r.status === 'applied') this.recs.set(key, { module: ch.module, id: ch.id, data: ch.data ?? null, version: r.version, updatedAt: ch.updatedAt, deleted: !!ch.deleted });
    return { ...r, server: this.recs.get(key) || null };
  }
  async listRecords(orgId, modules) {
    return [...this.recs.entries()].filter(([k, v]) => k.startsWith(orgId + '|') && modules.includes(v.module)).map(([, v]) => v);
  }

  async getSubscription(orgId) { return this.subs.get(orgId) || null; }
  async findSubscriptionByLicense(licenseId) { return [...this.subs.values()].find(s => s.licenseId === licenseId) || null; }

  // --- usage ledger / policy / adjustments
  ledger = []; settings = new Map();
  async addUsage(orgId, row) { const r = { id: this.ledger.length + 1, orgId, userId: row.userId || '', kind: row.kind, costUsd: row.costUsd, creditUsd: row.creditUsd || 0, meta: row.meta || '', at: row.at || new Date().toISOString() }; this.ledger.push(r); return r; }
  async sumUsage(orgId, fromIso, toIso) {
    const out = { spentUsd: 0, byKind: {}, byUser: {} };
    for (const r of this.ledger) {
      if (r.orgId !== orgId || r.kind === 'credit' || r.at < fromIso || r.at >= toIso) continue;
      const v = r.costUsd - r.creditUsd; out.spentUsd += v; out.byKind[r.kind] = (out.byKind[r.kind] || 0) + v; out.byUser[r.userId] = (out.byUser[r.userId] || 0) + v;
    }
    return out;
  }
  async creditBalance(orgId) { let b = 0; for (const r of this.ledger) if (r.orgId === orgId) b += r.kind === 'credit' ? r.costUsd : -r.creditUsd; return Math.max(0, b); }
  async getSetting(key) { return this.settings.has(key) ? this.settings.get(key) : null; }
  async setSetting(key, value) { this.settings.set(key, value); }
  async adjustPayment(orderId, a) { const p = this.payments.get(orderId); if (!p) return null; for (const k of ['feeUsd', 'taxUsd', 'refundedUsd']) if (a[k] !== undefined) p[k] = a[k]; return p; }
  async listOrgs() { return [...this.orgs.values()].map(o => ({ id: o.id, name: o.name })); }

  // --- signatures
  sigs = new Map();
  async addSignature(x) { const r = { ...x }; this.sigs.set(r.id, r); return r; }
  async getSignature(orgId, id) { const r = this.sigs.get(id); return r && r.orgId === orgId ? r : null; }
  async listSignatures(orgId, module, recordId) { return [...this.sigs.values()].filter(x => x.orgId === orgId && (!module || x.module === module) && (!recordId || x.recordId === recordId)).sort((a, b) => b.signedAt.localeCompare(a.signedAt)); }

  // --- files (metadata)
  filesMeta = new Map();
  async addFile(f) { this.filesMeta.set(f.id, { ...f, createdAt: new Date().toISOString() }); return this.filesMeta.get(f.id); }
  async getFile(orgId, id) { const f = this.filesMeta.get(id); return f && f.orgId === orgId ? f : null; }
  async findFileByHash(orgId, sha, module, recordId) { return [...this.filesMeta.values()].find(f => f.orgId === orgId && f.sha256 === sha && f.module === module && f.recordId === recordId) || null; }
  async listFiles(orgId, module, recordId) { return [...this.filesMeta.values()].filter(f => f.orgId === orgId && (!module || f.module === module) && (!recordId || f.recordId === recordId)); }
  async deleteFile(orgId, id) { const f = await this.getFile(orgId, id); if (f) this.filesMeta.delete(id); return !!f; }
  async orgFileBytes(orgId) { let n = 0; for (const f of this.filesMeta.values()) if (f.orgId === orgId) n += f.size; return n; }

  // --- billing
  async createPayment(p) { const row = { ...p, providerRef: null, status: 'pending', createdAt: new Date().toISOString(), paidAt: null }; this.payments.set(p.orderId, row); return row; }
  async getPayment(orderId) { return this.payments.get(orderId) || null; }
  async setPaymentRef(orderId, ref) { const p = this.payments.get(orderId); if (p) p.providerRef = ref; }
  async failPayment(orderId) { const p = this.payments.get(orderId); if (p && p.status === 'pending') p.status = 'failed'; }
  async listPendingDirect() { return [...this.payments.values()].filter(p => p.provider === 'direct' && p.status === 'pending'); }
  async listPayments(orgId) { return [...this.payments.values()].filter(p => p.orgId === orgId).reverse(); }
  // Idempotent: the first call marks the payment paid and extends the subscription; later calls change nothing.
  async completePayment(orderId, providerRef) {
    const p = this.payments.get(orderId); if (!p) return { applied: false };
    if (p.status === 'paid') return { applied: false, subscription: this.subs.get(p.orgId) };
    p.status = 'paid'; p.paidAt = new Date().toISOString(); if (providerRef) p.providerRef = providerRef;
    const sub = this.subs.get(p.orgId), base = Math.max(Date.now(), sub?.expiresAt && sub.plan === p.tier ? new Date(sub.expiresAt).getTime() : 0);
    sub.plan = p.tier; sub.status = 'active'; sub.expiresAt = new Date(base + p.days * 864e5).toISOString();
    return { applied: true, subscription: sub };
  }
  async incAiUsage(orgId, day) { const k = orgId + '|' + day, n = (this.usage.get(k) || 0) + 1; this.usage.set(k, n); return n; }

  async appendAudit(orgId, e) {
    const prev = [...this.audits].reverse().find(a => a.orgId === orgId);
    const prevHash = prev ? prev.hash : GENESIS;
    const row = { seq: this.audits.length + 1, orgId, ...e, prevHash };
    row.hash = chainHash(prevHash, row);
    this.audits.push(row); return row;
  }
  async listAudit(orgId, limit = 100) { return this.audits.filter(a => a.orgId === orgId).slice(-limit).reverse(); }
  async allAudit(orgId) { return this.audits.filter(a => a.orgId === orgId); }
}
