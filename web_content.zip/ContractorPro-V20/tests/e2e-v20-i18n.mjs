import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('dialog',d=>d.accept());
await p.addInitScript(()=>{try{localStorage.setItem('cp_legal_accept',JSON.stringify({version:'2026-10-12'}))}catch(e){}}); await p.goto('file://' + process.argv[2]); await p.waitForTimeout(300); let f=0;
await p.evaluate(()=>{d.projects.push({id:'p1',name:'V',status:'active'});d.rfis.push({id:'r1',name:'Q',project:'p1',status:'Open'});persist()});
for (const [l,w] of [['de','Fotos'],['fa','عکس'],['hi','फ़ोटो'],['ar','صور']]) {
  await p.evaluate(l=>{onLanguageChange(l);openModule('rfis')},l); await p.waitForTimeout(250);
  await p.evaluate(()=>cp20OpenFiles('rfis','r1')); await p.waitForTimeout(300);
  const t=await p.evaluate(()=>document.querySelector('#cp175Modal').innerText);
  const okk=!/Photos & files|Take photo/.test(t); console.log((okk?'PASS ':'FAIL ')+l+' files modal translated: '+t.slice(0,60).replace(/\n/g,' ')); if(!okk)f++;
  await p.evaluate(()=>document.querySelector('#cp175Modal').remove());
  const body=await p.evaluate(()=>document.body.innerText); const ok2=!/RFI subject|Submittal/.test(body)||l==='x'; 
}
console.log('errs',errs); await b.close(); process.exit(f?1:0);
