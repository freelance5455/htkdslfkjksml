// Browser <-> server: photo upload, offline queue flush, gallery, drawing pin -> punch item.
import { createRequire } from 'module'; import http from 'node:http';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const SRV = process.argv[3];
const { createApp } = await import(SRV + '/src/app.js'); const { MemoryStore } = await import(SRV + '/src/store-memory.js'); const { LocalProvider } = await import(SRV + '/src/ai-gateway.js'); const { MemoryBlobStore } = await import(SRV + '/src/blobstore.js');
const app = createApp({ store: new MemoryStore(), aiProvider: new LocalProvider(), blobs: new MemoryBlobStore(), config: { jwtSecret: 'x'.repeat(40) } });
const srv = http.createServer(app); await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port;
const reg = await (await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'f@x.com', password: 'correct-horse-battery', orgName: 'T' }) })).json();
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' }); const p = await (await b.newContext()).newPage();
const errs = []; p.on('pageerror', e => errs.push(e.message));
let prompts = ['Crack here']; p.on('dialog', d => { if (d.type() === 'prompt') d.accept(prompts.shift() || 'x'); else d.accept(); });
await p.goto('file://' + process.argv[2]); await p.waitForTimeout(300);
let fails = 0; const ok = (n, c, x) => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(x))); if (!c) fails++; };
// offline first: no token
await p.evaluate(() => { onLanguageChange('en'); d.projects.push({ id: 'p1', name: 'Villa', status: 'active' }); d.drawings.push({ id: 'dr1', name: 'A-101 Plan', project: 'p1', createdAt: new Date().toISOString() }); d.rfis.push({ id: 'r1', name: 'Q1', project: 'p1', status: 'Open' }); persist(); openModule('rfis'); });
ok('📎 button on RFI card', await p.locator('button:has-text("📎")').count() === 1);
await p.evaluate(() => cp20OpenFiles('rfis', 'r1')); await p.waitForSelector('#cp20Pick',{state:'attached'});
// tiny valid PNG made in the page
const png = await p.evaluate(async () => { const c = document.createElement('canvas'); c.width = 2400; c.height = 1200; const x = c.getContext('2d'); x.fillStyle = '#8a8'; x.fillRect(0, 0, 2400, 1200); x.fillStyle = '#222'; for (let i = 0; i < 400; i++) x.fillRect(Math.random() * 2400, Math.random() * 1200, 30, 30); return c.toDataURL('image/png').split(',')[1]; });
await p.setInputFiles('#cp20Pick', { name: 'site.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') }); await p.waitForTimeout(800);
ok('offline: photo queued locally and listed as waiting', /Waiting to upload/.test(await p.textContent('#cp20List')));
ok('image compressed to jpg <=1600px', await p.evaluate(async () => { const q = await cp20All(); return q.length === 1 && q[0].type === 'image/jpeg' && /\.jpg$/.test(q[0].name); }));
// go online
await p.evaluate(() => document.querySelector('#cp20Close').click());
await p.evaluate(([base, tok]) => { sessionStorage.setItem('cp175_access_token', tok); d.services = d.services || {}; d.services.endpoint = base; persist(); return cp20Flush(); }, [base, reg.accessToken]); await p.waitForTimeout(800);
const list = await (await fetch(base + '/api/files?module=rfis&recordId=r1', { headers: { authorization: 'Bearer ' + reg.accessToken } })).json();
ok('queue flushed to server', list.files.length === 1 && list.files[0].mime === 'image/jpeg', list);
ok('queue empty after flush', await p.evaluate(async () => (await cp20All()).length === 0));
await p.evaluate(() => cp20OpenFiles('rfis', 'r1')); await p.waitForSelector('.cp20Th'); await p.waitForTimeout(600);
ok('gallery shows thumbnail from server', await p.locator('.cp20Th img').count() === 1);
ok('usage line shown', /Storage:/.test(await p.textContent('#cp20Usage')));
await p.click('.cp20Th'); await p.waitForTimeout(200); ok('lightbox opens', await p.locator('.modal img[style*="max-height"]').count() === 1);
await p.evaluate(() => document.querySelectorAll('.modal').forEach(m => m.remove()));
// bad file type is rejected by server and marked failed
await p.evaluate(() => cp20OpenFiles('rfis', 'r1')); await p.waitForSelector('#cp20Pick',{state:'attached'});
await p.setInputFiles('#cp20Pick', { name: 'evil.pdf', mimeType: 'application/pdf', buffer: Buffer.from('MZ not a pdf at all') }); await p.waitForTimeout(800);
ok('invalid file marked failed with reason', /Upload failed/.test(await p.textContent('#cp20List')), await p.textContent('#cp20List'));
await p.evaluate(() => document.querySelectorAll('.modal').forEach(m => m.remove()));
// drawing sheet pin -> punch item
await p.evaluate(() => cp20OpenFiles('drawings', 'dr1')); await p.waitForSelector('#cp20Pick',{state:'attached'});
await p.setInputFiles('#cp20Pick', { name: 'plan.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') }); await p.waitForTimeout(900);
await p.evaluate(() => document.querySelectorAll('.modal').forEach(m => m.remove()));
await p.evaluate(() => cp20OpenSheet('dr1')); await p.waitForSelector('#cp20Sheet img'); await p.waitForTimeout(300);
const box = await p.locator('#cp20Sheet img').boundingBox(); await p.mouse.click(box.x + box.width * 0.25, box.y + box.height * 0.5); await p.waitForTimeout(300);
const r = await p.evaluate(() => ({ pins: d.drawings[0].pins, punch: d.punchList.length, it: d.punchList[0] }));
ok('pin created with punch item linked', r.pins.length === 1 && r.punch === 1 && r.pins[0].recordId === r.it.id && Math.abs(r.pins[0].x - 25) < 2 && r.it.name === 'Crack here', r);
ok('pin marker rendered', await p.locator('.cp20Pin').count() === 1);
// quota exceeded -> failed, not retried forever
console.log('page errors:', errs); console.log('FAILS', fails); await b.close(); srv.close(); process.exit(fails ? 1 : 0);
