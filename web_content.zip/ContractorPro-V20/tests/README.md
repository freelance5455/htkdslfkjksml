# Browser tests (V19)
`npm i -D playwright && npx playwright install chromium`, then:
`node tests/smoke.mjs  $PWD/web/index.html`   – opens every module/form in all 18 languages, reports JS errors and untranslated keys
`node tests/functional.mjs $PWD/web/index.html` – tax/retention/withholding maths, multi-currency, settings, persistence, legacy-data migration, PIN hashing
Server tests: `cd server && npm test`

`node tests/e2e.mjs <html> <server dir>` – browser <-> server: BTCPay checkout/webhook + AI tools
`node tests/e2e-direct-team-i18n.mjs <html> <server dir>` – Gantt, Team & Audit, direct-wallet payment (operator-confirmed), runtime translation (de/fa/ta/ur), RTL, alert translation, restore to English
`node tests/ui-coverage.mjs <html> <out.json> <lang>` – renders every module/modal in a language and dumps visible text (use it to spot untranslated strings)

## V20
`node tests/e2e-v20-modules.mjs <html>` – RFI/Submittal/Punch forms and alerts, critical path card, baseline slip, cycle detection, earned value card
`node tests/e2e-v20-files.mjs <html> <server dir>` – offline photo queue, compression, upload, gallery, bad file rejected, drawing pin -> punch item
`node tests/e2e-v20-sign.mjs <html> <server dir>` – signature pad, approval stored on server, verify intact / detect change
`node tests/e2e-v20-export.mjs <html>` – QuickBooks/Xero/generic CSV, formula-injection guard
`node tests/e2e-v20-i18n.mjs <html>` – new screens are translated (de/fa/hi/ar)
`node tests/v20-schedule-core.test.mjs tests/schedule_core.js` – CPM/EVM unit tests
`python3 tests/syntax-check.py <html>` – every inline script parses
Server tests now include files.test.js and signatures.test.js (`cd server && npm test`, 53 tests).
Note: smoke/functional/e2e import `playwright` normally; in this repo run them where playwright is installed.
