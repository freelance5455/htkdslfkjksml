// V20 browser tests: RFI/Submittal/Punch modules, critical path UI, earned value card.
import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' }); const p = await b.newPage();
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
await p.goto('file://' + process.argv[2]); await p.waitForTimeout(400);
let fails = 0; const ok = (n, c, x) => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(x))); if (!c) fails++; };
await p.evaluate(() => { onLanguageChange('en'); const T = (o) => Object.assign({ id: uid(), createdAt: new Date().toISOString(), createdBy: 'x' }, o);
  d.projects.push(T({ id: 'p1', name: 'Villa', amount: 1000, startDate: '2026-01-01', endDate: '2026-02-28' }));
  d.schedule.push(T({ id: 'a', name: 'Foundation', project: 'p1', startDate: '2026-01-01', durationDays: 10, percentComplete: 100, status: 'done' }),
    T({ id: 'b', name: 'Walls', project: 'p1', durationDays: 20, predecessor: 'a', percentComplete: 10 }),
    T({ id: 'c', name: 'Landscaping', project: 'p1', durationDays: 3, predecessor: 'a' }),
    T({ id: 'e', name: 'Roof', project: 'p1', durationDays: 5, predecessor: 'b', predecessor2: 'c' }));
  d.finance.push(T({ project: 'p1', type: 'expense', amount: 600, name: 'x', currency: d.currency })); persist(); });
// modules exist and forms work
for (const [mod, rec] of [['rfis', { name: 'Slab thickness?', project: 'p1', status: 'Open', priority: 'High', dueDate: '2020-01-01', question: 'q' }], ['submittals', { name: 'Rebar shop drawings', project: 'p1', status: 'Submitted', dueDate: '2020-01-01' }], ['punchList', { name: 'Crack in wall', project: 'p1', status: 'Open', location: 'Kitchen', dueDate: '2020-01-01' }]]) {
  await p.evaluate(([m]) => openModule(m), [mod]); await p.waitForTimeout(100);
  await p.evaluate(m => openForm(m), mod); await p.waitForSelector('#mf');
  for (const [k, v] of Object.entries(rec)) { const el = p.locator(`#mf [name="${k}"]`); if (await el.count()) { const tag = await el.evaluate(e => e.tagName); if (tag === 'SELECT') await el.selectOption(v); else await el.fill(v); } }
  await p.click('#mf button[type=submit]'); await p.waitForTimeout(200);
  ok(`${mod}: record saved and listed`, await p.evaluate(m => d[m].length === 1 && document.body.innerText.includes(d[m][0].name), mod));
}
await p.evaluate(() => cp15RefreshSmartAlerts()); 
const al = await p.evaluate(() => d.notifications.map(n => n.name));
ok('overdue alerts for RFI, submittal and punch item', ['RFI overdue: Slab thickness?', 'Submittal overdue: Rebar shop drawings', 'Punch item overdue: Crack in wall'].every(x => al.includes(x)), al);
// critical path UI
await p.evaluate(() => openModule('schedule')); await p.waitForTimeout(200);
const txt = await p.evaluate(() => document.body.innerText);
ok('critical path card visible with finish date', /Critical path/.test(txt) && /Finish:/.test(txt) && /Critical tasks: 3/.test(txt.replace(/\s+/g, ' ')), txt.slice(0, 300));
ok('landscaping has float, others critical', await p.evaluate(() => { const r = computeCPM(cpmTasks('p1')); return r.tasks.c.float > 0 && r.tasks.a.critical && r.tasks.b.critical && r.tasks.e.critical; }));
await p.evaluate(() => cpmSetBaseline()); ok('baseline stored', await p.evaluate(() => d.schedule.every(x => x.baselineStart && x.baselineEnd)));
await p.evaluate(() => { d.schedule.find(x => x.id === 'a').durationDays = 15; persist(); route(cur()); });
ok('slip vs baseline is shown after a delay', /vs baseline: \+5d/.test(await p.evaluate(() => document.body.innerText)));
// cycle
await p.evaluate(() => { d.schedule.find(x => x.id === 'a').predecessor = 'e'; persist(); route(cur()); });
ok('circular dependency reported', /Circular dependency/.test(await p.evaluate(() => document.body.innerText)));
await p.evaluate(() => { d.schedule.find(x => x.id === 'a').predecessor = ''; persist(); });
// EVM card
await p.evaluate(() => openProject('p1')); await p.waitForTimeout(250);
const pt = await p.evaluate(() => document.body.innerText);
ok('earned value card on project page', /Earned value/.test(pt) && /CPI/.test(pt) && /SPI/.test(pt) && /EAC/.test(pt), pt.slice(0, 200));
// languages: new modules titled and no missing keys / errors
for (const l of ['de', 'fa', 'hi']) { await p.evaluate(l => { onLanguageChange(l); openModule('rfis'); }, l); await p.waitForTimeout(150); }
console.log('page errors:', errs); console.log('FAILS', fails); await b.close(); process.exit(fails ? 1 : 0);
