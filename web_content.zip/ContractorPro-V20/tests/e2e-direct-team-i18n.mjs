// Browser <-> server: Gantt, Team & Audit, direct-wallet payments (operator-confirmed), runtime translation.
import { createRequire } from 'module'; import http from 'node:http';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const SRV = process.argv[3];
const { createApp } = await import(SRV + '/src/app.js'); const { MemoryStore } = await import(SRV + '/src/store-memory.js'); const { LocalProvider } = await import(SRV + '/src/ai-gateway.js');
const OP = 'o'.repeat(32), BTC = 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', USDT = 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE';
const app = createApp({ store: new MemoryStore(), aiProvider: new LocalProvider(), billing: { direct: { wallets: { btc: BTC, usdt: USDT }, operatorToken: OP, usdtNetwork: 'TRC20' }, rate: async () => 50000 }, config: { jwtSecret: 'x'.repeat(40) } });
const srv = http.createServer(app); await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port;
const reg = await (await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'e@x.com', password: 'correct-horse-battery', orgName: 'T' }) })).json();
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' }); const p = await (await b.newContext()).newPage();
const errs = [], dlg = []; p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => { dlg.push(d.message()); d.dismiss(); });
await p.addInitScript(()=>{try{localStorage.setItem('cp_legal_accept',JSON.stringify({version:'2026-10-12'}))}catch(e){}}); await p.goto('file://' + process.argv[2]); await p.waitForTimeout(300);
let fails = 0; const ok = (n, c, x) => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(x))); if (!c) fails++; };
await p.evaluate(([base, tok]) => { onLanguageChange('en'); sessionStorage.setItem('cp175_access_token', tok); d.services = d.services || {}; d.services.endpoint = base; d.auth = { email: 'e@x.com', status: 'signed_in' };
  d.projects.push({ id: 'p1', name: 'Villa', startDate: '2026-01-01', endDate: '2026-06-01', status: 'active' }, { id: 'p2', name: 'Tower', startDate: '2026-03-01', endDate: '2026-12-01', status: 'completed' }); persist(); }, [base, reg.accessToken]);
// Gantt
await p.evaluate(() => { openModule('schedule'); }); await p.waitForTimeout(200);
ok('Gantt shows both projects', await p.evaluate(() => { const t = document.body.innerText; return /Gantt/.test(t) && /Villa/.test(t) && /Tower/.test(t); }));
ok('app version label 20.0.0', await p.evaluate(() => APP_VERSION === '20.0.0'));
// Team & Audit
await p.evaluate(() => cp175OpenAccount()); ok('Team button exists', await p.locator('#cp175Team').count() === 1);
await p.click('#cp175Team'); await p.waitForSelector('#cp175TmAdd'); await p.waitForTimeout(300);
ok('members listed (owner)', /e@x\.com/.test(await p.textContent('#cp175TmOut')));
await p.fill('#cp175TmEmail', 'w@x.com'); await p.fill('#cp175TmPass', 'temporary-pass-1'); await p.selectOption('#cp175TmRole', 'worker'); await p.click('#cp175TmAdd'); await p.waitForTimeout(500);
ok('added member appears with role select', /w@x\.com/.test(await p.textContent('#cp175TmOut')) && await p.locator('.cp175RoleSel').count() === 1);
await p.selectOption('.cp175RoleSel', 'manager'); await p.waitForTimeout(400);
ok('role changed on server', (await (await fetch(base + '/api/users', { headers: { authorization: 'Bearer ' + reg.accessToken } })).json()).users.find(u => u.email === 'w@x.com').role === 'manager');
await p.click('#cp175TmAuditBtn'); await p.waitForTimeout(400);
ok('audit chain intact + events', /Audit chain intact/.test(await p.textContent('#cp175TmOut')) && /user-create|role-change/.test(await p.textContent('#cp175TmOut')));
await p.evaluate(() => { document.querySelectorAll('#cp175Modal').forEach(m => m.remove()); });
// direct wallet billing
await p.evaluate(() => cp175OpenBilling()); await p.waitForSelector('#cp19DNew'); 
ok('direct panel offers BTC and USDT', await p.locator('#cp19DCur option').count() === 2);
await p.selectOption('#cp19DCur', 'usdt'); await p.click('#cp19DNew'); await p.waitForSelector('#cp19DList [data-copy]');
const lt = await p.textContent('#cp19DList'); ok('invoice shows exact amount + address + waiting', /USDT/.test(lt) && lt.includes(USDT) && /Waiting for payment/.test(lt), lt);
const no = await p.locator('#cp19DList button', { hasText: /paid|confirm/i }).count(); ok('NO customer-side confirm button', no === 0);
ok('plan still free before operator confirms', !/Pro/.test(await p.textContent('#cp19Cur')));
const pend = (await (await fetch(base + '/api/operator/direct-pending', { headers: { 'x-operator-token': OP } })).json()).pending;
ok('operator sees the pending invoice', pend.length === 1);
const cf = await (await fetch(base + '/api/operator/direct-confirm/' + pend[0].orderId, { method: 'POST', headers: { 'x-operator-token': OP, 'content-type': 'application/json' }, body: JSON.stringify({ txid: 'deadbeef' }) })).json(); ok('operator confirm applied', cf.applied === true, cf);
await p.click('#cp19Refresh'); await p.waitForTimeout(500);
ok('plan now Pro and invoice Paid', /Pro/.test(await p.textContent('#cp19Cur')) && /Paid/.test(await p.textContent('#cp19DList')), await p.textContent('#cp19Cur'));
await p.evaluate(() => document.querySelectorAll('#cp175Modal').forEach(m => m.remove()));
// usage meter (cost cap)
await p.evaluate(() => cp175OpenBilling()); await p.waitForSelector('#cp19Usage .card'); await p.waitForTimeout(200);
const ut = await p.textContent('#cp19Usage'); ok('usage meter shown in billing modal', /AI & cloud usage this period/.test(ut) && /% used/.test(ut), ut);
await p.evaluate(() => { onLanguageChange('de'); }); await p.waitForTimeout(250);
ok('usage meter translated (de)', !/AI & cloud usage this period/.test(await p.textContent('#cp19Usage')));
await p.evaluate(() => { onLanguageChange('en'); document.querySelectorAll('#cp175Modal').forEach(m => m.remove()); });
// translation layer
const T = async (lang, fn) => { await p.evaluate(l => onLanguageChange(l), lang); await p.waitForTimeout(150); return p.evaluate(fn); };
for (const [lang, bad] of [['de', 'Request Email OTP'], ['fa', 'Request Email OTP'], ['ta', 'Save Cloud Settings'], ['ur', 'Test Connection']]) {
  await p.evaluate(l => { onLanguageChange(l); openModule('settings'); }, lang); await p.waitForTimeout(250);
  const txt = await p.evaluate(() => document.body.innerText);
  ok(`settings page in ${lang} has no leftover "${bad}"`, !txt.includes(bad));
  await p.evaluate(() => cp175OpenCloud()); await p.waitForTimeout(150); const m = await p.evaluate(() => (document.getElementById('cp175Modal') || document.body).innerText);
  ok(`cloud modal in ${lang} translated`, !/Cloud Backup|Local Snapshot Export|Pending/.test(m), m.slice(0, 120));
  await p.evaluate(() => document.querySelectorAll('#cp175Modal').forEach(x => x.remove()));
}
ok('RTL for fa', await T('fa', () => document.documentElement.dir === 'rtl'));
await p.evaluate(() => { d.clients = []; persist(); onLanguageChange('de'); }); dlg.length = 0; await p.evaluate(() => cp175OpenPortal()); await p.waitForTimeout(100);
ok('alert text translated (de)', dlg.length === 1 && !/Add at least one client first/.test(dlg[0]), dlg);
await p.evaluate(() => { onLanguageChange('en'); openModule('settings'); cp175OpenCloud(); }); await p.waitForTimeout(250);
ok('switching back to English restores originals', /Cloud Backup/.test(await p.evaluate(() => document.getElementById('cp175Modal').innerText)));
console.log('page errors:', errs); console.log('FAILS', fails); await b.close(); srv.close(); process.exit(fails ? 1 : 0);
