import { chromium } from 'playwright';
const file = process.argv[2];
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const p = await b.newPage();
const errs = new Map();
const add = (k)=>errs.set(k,(errs.get(k)||0)+1);
p.on('pageerror', e => add('PAGEERROR: ' + e.message));
p.on('console', m => { if (m.type()==='error') add('CONSOLE: ' + m.text()); });
p.on('dialog', d => { add('DIALOG: ' + d.message().slice(0,80)); d.dismiss(); });
await p.goto('file://' + file); await p.waitForTimeout(500);
const res = await p.evaluate(() => {
  const out = {ids: IDS.slice(), fails: [], missing: {}, forms: []};
  const langs = LANGS;
  for (const L of langs) {
    try { onLanguageChange(L); } catch(e){ out.fails.push(['lang',L,String(e)]); continue; }
    const ms = [...IDS, 'settings','smartEstimate','dashboard'];
    for (const id of ms) {
      try { openModule(id); } catch(e){ out.fails.push(['module',L,id,String(e).slice(0,120)]); }
    }
    for (const id of IDS) {
      try { openForm(id); document.querySelectorAll('.modal,.sheet,dialog').forEach(x=>x.remove()); } catch(e){ out.forms.push([L,id,String(e).slice(0,120)]); }
    }
    // missing translations among I dictionaries
    const miss = Object.keys(I).filter(k => !(I[k] && I[k][L]));
    out.missing[L] = miss.length;
  }
  out.totalKeys = Object.keys(I).length;
  return out;
});
console.log(JSON.stringify({ids:res.ids, totalKeys:res.totalKeys, missing:res.missing}));
console.log('fails', res.fails.length, JSON.stringify(res.fails.slice(0,10)));
console.log('formfails', res.forms.length, JSON.stringify(res.forms.slice(0,10)));
console.log('errors:'); for (const [k,v] of errs) console.log(' ',v,'x',k);
await b.close();
