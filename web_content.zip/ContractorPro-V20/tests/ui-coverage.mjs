import { createRequire } from 'module'; import fs from 'fs';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage();
const found = new Set(); const dialogs = new Set();
p.on('dialog', async d => { dialogs.add(d.message()); if (d.type() === 'prompt') await d.accept('12'); else await d.dismiss(); });
p.on('pageerror', () => {});
await p.goto('file://' + process.argv[2]); await p.waitForTimeout(500);
await p.evaluate((process_lang) => { onLanguageChange(process_lang); d.clients.push({id:'c1',name:'Client A',email:'a@b.co'}); d.projects.push({id:'p1',name:'Villa',client:'c1',startDate:'2026-01-01',endDate:'2026-06-01'}); d.invoices.push({id:'i1',name:'INV',client:'c1',amount:5,status:'sent'}); d.contracts.push({id:'k1',name:'K',client:'c1',amount:5}); persist(); }, process.argv[4]||'en');
const grab = () => p.evaluate(() => {
  const out = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (w.nextNode()) { const n = w.currentNode; if (n.parentElement && ['SCRIPT', 'STYLE'].includes(n.parentElement.tagName)) continue; const v = n.nodeValue.replace(/\s+/g, ' ').trim(); if (v) out.push(v); }
  document.querySelectorAll('[placeholder],[title],[aria-label]').forEach(e => ['placeholder', 'title', 'aria-label'].forEach(a => { const v = e.getAttribute(a); if (v) out.push(v.trim()); }));
  return out;
});
const add = async () => (await grab()).forEach(x => found.add(x));
await add();
const openers = await p.evaluate(() => Object.keys(window).filter(k => /^cp\d+Open/.test(k) || /^cp19Open/.test(k)));
const modules = await p.evaluate(() => [...IDS, 'settings', 'smartEstimate']);
async function clickAll(scope) {
  const n = await p.locator(scope + ' button').count();
  for (let i = 0; i < Math.min(n, 40); i++) { try { await p.locator(scope + ' button').nth(i).click({ timeout: 800 }); await p.waitForTimeout(60); await add(); } catch (e) {} if (!(await p.locator(scope).count())) break; }
}
for (const m of modules) { try { await p.evaluate(m => openModule(m), m); await p.waitForTimeout(80); await add(); } catch (e) {} }
// service hubs and the settings page buttons
for (const m of ['settings']) { await p.evaluate(m => openModule(m), m); await add(); }
for (const o of openers) { try { await p.evaluate(o => window[o](), o); await p.waitForTimeout(100); await add(); await clickAll('#cp175Modal'); await p.evaluate(() => { const m = document.getElementById('cp175Modal'); if (m) m.remove(); }); } catch (e) {} }
for (const sel of ['#fab', 'button.plus']) { try { await p.locator(sel).first().click({ timeout: 500 }); await add(); await p.evaluate(() => closeForm && closeForm()); } catch (e) {} }
// clicking buttons in settings/services (stays on page)
await p.evaluate(() => openModule('settings')); await clickAll('#detailBody');
fs.writeFileSync(process.argv[3], JSON.stringify({ texts: [...found], dialogs: [...dialogs], openers }, null, 1));
console.log('texts', found.size, 'dialogs', dialogs.size, 'openers', openers.join(','));
await b.close();
