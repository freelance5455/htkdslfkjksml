# Optimizador Shizuku: guía

Esta app usa **Shizuku** para hacer tareas de mantenimiento con permisos de sistema: borrar caché, borrar archivos temporales y quitar apps del sistema para tu usuario.

Importante: el beneficio en rendimiento es limitado. Borrar caché libera espacio, pero no siempre hace que los juegos vayan más rápido.

---

## 1. Preparar Shizuku en el teléfono

1. Instala **Shizuku** desde Play Store o desde su página oficial.
2. Activa la **Depuración inalámbrica** en Opciones de desarrollador (Android 11 o superior).
3. Abre Shizuku y sigue sus pasos para iniciarlo. Mientras Shizuku esté activo, esta app puede usar sus permisos.

Si Shizuku se apaga (por ejemplo, al reiniciar), tendrás que volver a iniciarlo.

## 2. Compilar el APK

Necesitas JDK 17, Android SDK (Platform 34) y Gradle, igual que en la guía anterior. La primera compilación necesita internet.

```
cd shizuku-optimizador
gradle wrapper --gradle-version 8.4
gradle assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## 3. Usar la app

- **Borrar caché de apps:** pide a Android borrar la caché de todas las apps.
- **Borrar archivos temporales:** borra archivos que terminan en `.tmp` o `.temp` en el almacenamiento y en `/data/local/tmp`.
- **Cargar apps del sistema:** muestra las apps del sistema que sí se pueden quitar. Las críticas no aparecen.
- **Quitar apps marcadas:** quita para tu usuario las apps que marcaste. Siguen instaladas para otros usuarios y se pueden restaurar.
- **Restaurar apps quitadas:** vuelve a instalar las apps que quitaste con esta app.

## 4. Qué no debes quitar

Aunque la app no muestra las apps críticas, revisa siempre antes de quitar algo. No quites apps relacionadas con:
- Teléfono, mensajes, teclado o cámara.
- Ajustes, Wi-Fi, Bluetooth o NFC.
- Google Play Services o Play Store.
- Cargador, batería o seguridad.

Si algo deja de funcionar, usa **Restaurar apps quitadas** o revisa la lista de apps quitadas para volver a instalar la que causó el problema.

## 5. Errores comunes

| Mensaje | Qué hacer |
|---|---|
| `Shizuku no está activo` | Abre Shizuku y vuelve a iniciarlo |
| `Acepta el permiso de Shizuku` | Acepta la ventana que aparece y vuelve a pulsar el botón |
| `No se pudo quitar` | Revisa el mensaje; suele indicar que la app no se puede quitar |
| `No se compila` | Envía el error de la terminal para revisarlo |

## 6. Limitaciones

- La app usa algunas llamadas internas de Shizuku. Si una versión nueva de Shizuku cambia esas llamadas, puede dejar de funcionar.
- No se puede probar en esta sesión porque no hay Android SDK. La primera compilación real es la prueba definitiva.
