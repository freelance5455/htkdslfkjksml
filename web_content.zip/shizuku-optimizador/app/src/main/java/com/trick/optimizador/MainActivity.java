package com.trick.optimizador;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity implements Shizuku.OnRequestPermissionResultListener {

    private static final int CODIGO_PERMISO = 1001;
    private static final String PREFS = "optimizador";
    private static final String CLAVE_DESINSTALADAS = "desinstaladas";

    // Apps que nunca se quitan (sistema, teléfono, ajustes, Google, Shizuku y esta app).
    private static final String[] PROTEGIDOS = {
        "android", "com.android.systemui", "com.android.phone", "com.android.settings",
        "com.android.providers", "com.android.launcher", "com.android.shell",
        "com.android.inputmethod", "com.android.bluetooth", "com.android.nfc",
        "com.android.server", "com.android.networkstack", "com.android.keychain",
        "com.android.vending", "com.android.telephony", "com.android.emergency",
        "com.android.se", "com.android.location", "com.android.permissioncontroller",
        "com.android.packageinstaller", "com.android.documentsui", "com.android.externalstorage",
        "com.android.wifi", "com.android.dialer", "com.android.incallui", "com.android.stk",
        "com.google.android.gms", "com.google.android.gsf", "com.google.android.inputmethod",
        "com.samsung.android.incallui", "com.sec.android.app.launcher",
        "com.samsung.android.app.telephonyui", "com.samsung.android.dialer",
        "com.sec.android.provider", "com.samsung.android.honeyboard",
        "moe.shizuku", "com.trick.optimizador"
    };

    private TextView registro;
    private LinearLayout listaApps;
    private List<CheckBox> casillas = new ArrayList<>();
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Shizuku.addRequestPermissionResultListener(this);
        setContentView(construirInterfaz());
        registrar("Listo. Activa Shizuku y pulsa un botón.");
    }

    @Override
    public void onRequestPermissionResult(int requestCode, int grantResult) {
        if (requestCode == CODIGO_PERMISO) {
            registrar(grantResult == PackageManager.PERMISSION_GRANTED
                    ? "Permiso de Shizuku concedido. Vuelve a pulsar el botón."
                    : "Permiso de Shizuku denegado.");
        }
    }

    private View construirInterfaz() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setPadding(48, 48, 48, 48);
        raiz.setBackgroundColor(0xFFF4F8FB);

        TextView titulo = new TextView(this);
        titulo.setText("Optimizador Shizuku");
        titulo.setTextSize(26);
        titulo.setTextColor(0xFF0B5CAD);
        raiz.addView(titulo);

        TextView aviso = new TextView(this);
        aviso.setText("Quitar apps del sistema puede afectar algunas funciones del teléfono. "
                + "Las apps quitadas se pueden restaurar con el botón de abajo.");
        raiz.addView(aviso);

        raiz.addView(boton("Borrar caché de apps",
                v -> ejecutarEnSegundoPlano("pm trim-caches 999999999999", "Caché borrada.")));

        raiz.addView(boton("Borrar archivos temporales",
                v -> ejecutarEnSegundoPlano(
                        "find /sdcard /data/local/tmp -type f \\( -name '*.tmp' -o -name '*.temp' \\) -delete 2>/dev/null; echo listo",
                        "Archivos temporales borrados.")));

        raiz.addView(boton("Cargar apps del sistema", v -> cargarApps()));
        raiz.addView(boton("Quitar apps marcadas", v -> quitarMarcadas()));
        raiz.addView(boton("Restaurar apps quitadas", v -> restaurarQuitadas()));

        listaApps = new LinearLayout(this);
        listaApps.setOrientation(LinearLayout.VERTICAL);
        raiz.addView(listaApps);

        registro = new TextView(this);
        registro.setPadding(0, 32, 0, 0);
        raiz.addView(registro);

        scroll.addView(raiz);
        return scroll;
    }

    private Button boton(String texto, View.OnClickListener accion) {
        Button b = new Button(this);
        b.setText(texto);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0xFF1BA672);
        b.setOnClickListener(accion);
        return b;
    }

    private void registrar(String texto) {
        registro.setText(texto);
    }

    private boolean shizukuListo() {
        if (!Shizuku.pingBinder()) {
            registrar("Shizuku no está activo. Ábrelo y actívalo primero.");
            return false;
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            registrar("Acepta el permiso de Shizuku que aparecerá en pantalla.");
            Shizuku.requestPermission(CODIGO_PERMISO);
            return false;
        }
        return true;
    }

    private boolean esProtegido(String paquete) {
        for (String p : PROTEGIDOS) {
            if (paquete.equals(p) || paquete.startsWith(p)) {
                return true;
            }
        }
        return false;
    }

    // Ejecuta un comando de shell con privilegios de Shizuku y devuelve su salida.
    private String ejecutar(String comando) throws Exception {
        Method metodo = Shizuku.class.getDeclaredMethod(
                "newProcess", String[].class, String[].class, String.class);
        metodo.setAccessible(true);
        Process proceso = (Process) metodo.invoke(
                null, new Object[]{new String[]{"sh", "-c", comando}, null, null});

        StringBuilder salida = new StringBuilder();
        try (BufferedReader lector = new BufferedReader(
                new InputStreamReader(proceso.getInputStream()))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                salida.append(linea).append('\n');
            }
        }
        proceso.waitFor();
        return salida.toString();
    }

    private void ejecutarEnSegundoPlano(String comando, String mensajeOk) {
        if (!shizukuListo()) {
            return;
        }
        new Thread(() -> {
            try {
                String salida = ejecutar(comando);
                String texto = salida.trim().isEmpty() ? mensajeOk : mensajeOk + "\n" + salida.trim();
                runOnUiThread(() -> registrar(texto));
            } catch (Exception e) {
                runOnUiThread(() -> registrar("Error: " + e));
            }
        }).start();
    }

    private void cargarApps() {
        if (!shizukuListo()) {
            return;
        }
        new Thread(() -> {
            try {
                String salida = ejecutar("pm list packages -s");
                List<String> paquetes = new ArrayList<>();
                for (String linea : salida.split("\n")) {
                    String l = linea.trim();
                    if (l.startsWith("package:")) {
                        String paquete = l.substring("package:".length());
                        if (!esProtegido(paquete)) {
                            paquetes.add(paquete);
                        }
                    }
                }
                Collections.sort(paquetes);
                runOnUiThread(() -> mostrarLista(paquetes));
            } catch (Exception e) {
                runOnUiThread(() -> registrar("Error: " + e));
            }
        }).start();
    }

    private void mostrarLista(List<String> paquetes) {
        listaApps.removeAllViews();
        casillas = new ArrayList<>();
        for (String paquete : paquetes) {
            CheckBox c = new CheckBox(this);
            c.setText(paquete);
            c.setTag(paquete);
            casillas.add(c);
            listaApps.addView(c);
        }
        registrar(paquetes.size() + " apps del sistema encontradas. Marca las que quieras quitar.");
    }

    private void quitarMarcadas() {
        if (!shizukuListo()) {
            return;
        }
        List<String> marcadas = new ArrayList<>();
        for (CheckBox c : casillas) {
            if (c.isChecked()) {
                String paquete = (String) c.getTag();
                if (!esProtegido(paquete)) {
                    marcadas.add(paquete);
                }
            }
        }
        if (marcadas.isEmpty()) {
            registrar("No marcaste ninguna app.");
            return;
        }
        new Thread(() -> {
            try {
                Set<String> guardadas = new HashSet<>(
                        prefs.getStringSet(CLAVE_DESINSTALADAS, new HashSet<>()));
                StringBuilder log = new StringBuilder();
                for (String paquete : marcadas) {
                    String salida = ejecutar("pm uninstall -k --user 0 " + paquete);
                    if (salida.contains("Success")) {
                        guardadas.add(paquete);
                        log.append("Quitada: ").append(paquete).append('\n');
                    } else {
                        log.append("No se pudo quitar ").append(paquete)
                                .append(": ").append(salida.trim()).append('\n');
                    }
                }
                prefs.edit().putStringSet(CLAVE_DESINSTALADAS, guardadas).apply();
                runOnUiThread(() -> registrar(log.toString()));
            } catch (Exception e) {
                runOnUiThread(() -> registrar("Error: " + e));
            }
        }).start();
    }

    private void restaurarQuitadas() {
        if (!shizukuListo()) {
            return;
        }
        new Thread(() -> {
            try {
                Set<String> guardadas = new HashSet<>(
                        prefs.getStringSet(CLAVE_DESINSTALADAS, new HashSet<>()));
                if (guardadas.isEmpty()) {
                    runOnUiThread(() -> registrar("No hay apps quitadas por esta app."));
                    return;
                }
                StringBuilder log = new StringBuilder();
                Set<String> pendientes = new HashSet<>();
                for (String paquete : guardadas) {
                    String salida = ejecutar("cmd package install-existing " + paquete);
                    if (salida.contains("installed")) {
                        log.append("Restaurada: ").append(paquete).append('\n');
                    } else {
                        pendientes.add(paquete);
                        log.append("No se pudo restaurar ").append(paquete)
                                .append(": ").append(salida.trim()).append('\n');
                    }
                }
                prefs.edit().putStringSet(CLAVE_DESINSTALADAS, pendientes).apply();
                runOnUiThread(() -> registrar(log.toString()));
            } catch (Exception e) {
                runOnUiThread(() -> registrar("Error: " + e));
            }
        }).start();
    }
}
