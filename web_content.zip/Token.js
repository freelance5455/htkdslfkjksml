const officialTokenValue = "8428012602:AAHsuXNAvuuQbx-dKDoCHEx1nTaTbPWIBp0";
module.exports = {
    officialToken: officialTokenValue
};