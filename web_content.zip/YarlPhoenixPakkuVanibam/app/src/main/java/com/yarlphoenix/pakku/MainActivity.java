package com.yarlphoenix.pakku;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*; import android.content.*; import android.print.*;
public class MainActivity extends Activity {
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.setLayoutParams(new ViewGroup.LayoutParams(-1,-1)); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); w.setWebChromeClient(new WebChromeClient()); w.addJavascriptInterface(new Object(){@JavascriptInterface public void printPage(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); pm.print("YarlPhoenixReport",w.createPrintDocumentAdapter("YarlPhoenixReport"),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());});}},"Android"); setContentView(w); w.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
