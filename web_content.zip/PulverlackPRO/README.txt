PULVERLACK PRO – ANDROIDPROJEKT

Detta är ett komplett Android Studio-projekt med en offlinebaserad kalkylator.
Kalkyler och inställningar sparas lokalt på telefonen med localStorage.

BYGG APK:
1. Installera Android Studio på en dator.
2. Packa upp PulverlackPRO-AndroidStudio.zip.
3. Öppna mappen PulverlackPRO i Android Studio.
4. Låt Android Studio synka Gradle och installera eventuella SDK-komponenter.
5. Välj Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK-filen skapas normalt under app/build/outputs/apk/debug/app-debug.apk.

Appnamn: Pulverlack PRO
Paketnamn: se.pulverlackpro.app
Minsta Androidversion: Android 6.0 (API 23)
Ingen internetbehörighet krävs.

OBS: Detta är projektkällkod, inte en redan kompilerad APK.
