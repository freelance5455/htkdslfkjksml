const APP = {
  COMPANY: 'YOUR TRAINING INSTITUTE NAME',
  ADDRESS: 'YOUR ADDRESS',
  PHONE: 'YOUR PHONE',
  EMAIL: 'YOUR EMAIL',
  CERT_SHEET: 'Certificates',
  USER_SHEET: 'AdminUsers'
};

const CERT_TYPES = {
  OPERATOR: 'OPERATOR CERTIFICATE',
  ELECTRICAL: 'ELECTRICAL TRAINING CERTIFICATE',
  WELDER: 'WELDER TRAINING CERTIFICATE',
  COMPUTER: 'COMPUTER TRAINING CERTIFICATE',
  AC: 'AC TECHNICIAN TRAINING CERTIFICATE'
};

function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Certificate Verification System')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function setupSystem() {
  const ss = SpreadsheetApp.getActive();
  ensureSheet_(ss, APP.CERT_SHEET, [
    'Certificate ID','Certificate Type','Student ID','Name','Father Name',
    'Course/Training','Duration','Start Date','Completion Date','Grade',
    'Issue Date','Status','Remarks','Created At','Created By'
  ]);
  ensureSheet_(ss, APP.USER_SHEET, [
    'Username','Password Hash','Role','Status','Created At'
  ]);

  const us = ss.getSheetByName(APP.USER_SHEET);
  if (us.getLastRow() < 2)
    us.appendRow(['admin', sha256_('Admin@123'), 'ADMIN', 'ACTIVE', new Date()]);

  if (!PropertiesService.getScriptProperties().getProperty('CERT_SEQ'))
    PropertiesService.getScriptProperties().setProperty('CERT_SEQ','0');

  return 'Setup complete. Login: admin / Admin@123';
}

function login(username,password) {
  const sh = SpreadsheetApp.getActive().getSheetByName(APP.USER_SHEET);
  if (!sh) return {ok:false,message:'Run setupSystem() first.'};
  const data = sh.getDataRange().getValues();
  for (let i=1;i<data.length;i++) {
    if (String(data[i][0]).toLowerCase() === String(username).toLowerCase() &&
        String(data[i][1]) === sha256_(password) &&
        String(data[i][3]).toUpperCase() === 'ACTIVE') {
      const token=Utilities.getUuid();
      CacheService.getScriptCache().put('S_'+token,
        JSON.stringify({username:data[i][0],role:data[i][2]}),7200);
      return {ok:true,token:token,username:data[i][0]};
    }
  }
  return {ok:false,message:'Invalid username or password.'};
}

function logout(token) {
  if(token) CacheService.getScriptCache().remove('S_'+token);
  return true;
}

function issueCertificate(token,o) {
  const u=auth_(token);
  o=o||{};
  if(!o.name) throw new Error('Name is required.');
  if(!CERT_TYPES[o.type]) throw new Error('Invalid certificate type.');

  const id=nextId_();
  const sh=SpreadsheetApp.getActive().getSheetByName(APP.CERT_SHEET);
  sh.appendRow([
    id,o.type,o.studentId||'',o.name,o.fatherName||'',
    o.course||CERT_TYPES[o.type],o.duration||'1 Year',
    o.startDate?new Date(o.startDate):'',
    o.completionDate?new Date(o.completionDate):'',
    o.grade||'',o.issueDate?new Date(o.issueDate):new Date(),
    'VALID',o.remarks||'',new Date(),u.username
  ]);
  return getCertificate(id);
}

function getCertificate(id) {
  id=String(id||'').trim().toUpperCase();
  const sh=SpreadsheetApp.getActive().getSheetByName(APP.CERT_SHEET);
  if(!sh) return {ok:false,message:'Database not configured.'};
  const d=sh.getDataRange().getValues();
  for(let i=1;i<d.length;i++)
    if(String(d[i][0]).toUpperCase()===id)
      return {ok:true,certificate:row_(d[i])};
  return {ok:false,message:'Certificate not found.'};
}

function listCertificates(token,q) {
  auth_(token); q=String(q||'').toLowerCase();
  const d=SpreadsheetApp.getActive().getSheetByName(APP.CERT_SHEET).getDataRange().getValues();
  const a=[];
  for(let i=d.length-1;i>=1;i--){
    const c=row_(d[i]);
    if(!q || JSON.stringify(c).toLowerCase().includes(q)) a.push(c);
    if(a.length>=500) break;
  }
  return a;
}

function revokeCertificate(token,id,reason) {
  auth_(token);
  const sh=SpreadsheetApp.getActive().getSheetByName(APP.CERT_SHEET);
  const d=sh.getDataRange().getValues();
  for(let i=1;i<d.length;i++){
    if(String(d[i][0]).toUpperCase()===String(id).toUpperCase()){
      sh.getRange(i+1,12).setValue('REVOKED');
      sh.getRange(i+1,13).setValue(reason||'Certificate revoked.');
      return {ok:true};
    }
  }
  return {ok:false,message:'Certificate not found.'};
}

function dashboard(token) {
  auth_(token);
  const d=SpreadsheetApp.getActive().getSheetByName(APP.CERT_SHEET).getDataRange().getValues();
  const r={total:0,valid:0,revoked:0,types:{}};
  Object.keys(CERT_TYPES).forEach(k=>r.types[k]=0);
  for(let i=1;i<d.length;i++){
    if(!d[i][0]) continue;
    r.total++;
    if(String(d[i][11]).toUpperCase()==='REVOKED') r.revoked++; else r.valid++;
    if(r.types[d[i][1]]!==undefined) r.types[d[i][1]]++;
  }
  return r;
}

function changePassword(token,oldP,newP){
  const u=auth_(token);
  if(String(newP).length<6) return {ok:false,message:'Minimum 6 characters.'};
  const sh=SpreadsheetApp.getActive().getSheetByName(APP.USER_SHEET);
  const d=sh.getDataRange().getValues();
  for(let i=1;i<d.length;i++){
    if(String(d[i][0]).toLowerCase()===u.username.toLowerCase()){
      if(String(d[i][1])!==sha256_(oldP)) return {ok:false,message:'Old password incorrect.'};
      sh.getRange(i+1,2).setValue(sha256_(newP));
      return {ok:true,message:'Password changed.'};
    }
  }
  return {ok:false,message:'User not found.'};
}

function auth_(token){
  const x=CacheService.getScriptCache().get('S_'+token);
  if(!x) throw new Error('Session expired. Login again.');
  return JSON.parse(x);
}

function nextId_(){
  const p=PropertiesService.getScriptProperties();
  const n=Number(p.getProperty('CERT_SEQ')||0)+1;
  p.setProperty('CERT_SEQ',String(n));
  return 'CERT-'+new Date().getFullYear()+'-'+String(n).padStart(6,'0');
}

function row_(r){
  return {
    id:String(r[0]||''), type:String(r[1]||''), studentId:String(r[2]||''),
    name:String(r[3]||''), fatherName:String(r[4]||''),
    course:String(r[5]||''), duration:String(r[6]||''),
    startDate:date_(r[7]), completionDate:date_(r[8]), grade:String(r[9]||''),
    issueDate:date_(r[10]), status:String(r[11]||''), remarks:String(r[12]||'')
  };
}
function date_(v){
  if(!v)return '';
  if(Object.prototype.toString.call(v)==='[object Date]'&&!isNaN(v))
    return Utilities.formatDate(v,Session.getScriptTimeZone()||'Asia/Dhaka','dd MMMM yyyy');
  return String(v);
}
function sha256_(s){
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(s),Utilities.Charset.UTF_8)
    .map(b=>{b=b<0?b+256:b;return ('0'+b.toString(16)).slice(-2)}).join('');
}
function ensureSheet_(ss,n,h){
  let s=ss.getSheetByName(n); if(!s)s=ss.insertSheet(n);
  if(s.getLastRow()===0)s.appendRow(h);
  s.setFrozenRows(1);
  s.getRange(1,1,1,h.length).setFontWeight('bold');
}
