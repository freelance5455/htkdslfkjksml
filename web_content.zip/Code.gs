const APP_NAME = 'Quiet Frontier AI Employee';
const PROP_SHEET_ID = 'QF_AI_EMPLOYEE_SHEET_ID';

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle(APP_NAME)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getOrCreateWorkspace() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty(PROP_SHEET_ID);
  let ss;

  if (id) {
    try { ss = SpreadsheetApp.openById(id); } catch (e) {}
  }

  if (!ss) {
    ss = SpreadsheetApp.create('Quiet Frontier AI Studio');
    props.setProperty(PROP_SHEET_ID, ss.getId());

    const messages = ss.getSheets()[0];
    messages.setName('Messages');
    messages.getRange(1, 1, 1, 9).setValues([[
      'Timestamp','Message ID','From','To','Type','Text','Status','Thread ID','Priority'
    ]]);
    messages.setFrozenRows(1);

    const agents = ss.insertSheet('Agents');
    agents.getRange(1,1,1,5).setValues([['Agent','Role','Enabled','Last Seen','Notes']]);
    agents.getRange(2,1,4,5).setValues([
      ['OWNER','Human owner',true,'','Receives approval requests and replies'],
      ['CHATGPT','Supervisor / reviewer',true,'','Scheduled reviewer and planner'],
      ['HOLO','Game development agent',true,'','Implements Quiet Frontier work'],
      ['CLAUDE','Second reviewer / coder',true,'','Optional assistant']
    ]);
    agents.setFrozenRows(1);

    const state = ss.insertSheet('State');
    state.getRange(1,1,1,2).setValues([['Key','Value']]);
    state.getRange(2,1,5,2).setValues([
      ['workspace_created', new Date().toISOString()],
      ['project','Quiet Frontier'],
      ['call_mode','true'],
      ['poll_seconds','3'],
      ['version','1.1']
    ]);
    state.setFrozenRows(1);
  }

  return {ok:true, spreadsheetId:ss.getId(), spreadsheetUrl:ss.getUrl(), name:ss.getName()};
}

function workspaceInfo() { return getOrCreateWorkspace(); }

function sendMessage(payload) {
  if (!payload || !payload.text) throw new Error('Message is empty.');
  const ss = SpreadsheetApp.openById(getOrCreateWorkspace().spreadsheetId);
  const sh = ss.getSheetByName('Messages');
  const now = new Date();
  const id = Utilities.getUuid();
  const thread = payload.threadId || ('thread-' + Utilities.getUuid());
  const from = (payload.from || 'OWNER').toUpperCase();
  const to = (payload.to || 'CHATGPT').toUpperCase();
  const type = payload.type || 'message';
  const priority = payload.priority || 'normal';
  sh.appendRow([now,id,from,to,type,String(payload.text),'unread',thread,priority]);
  return {ok:true,id,threadId:thread,timestamp:now.toISOString()};
}

function getLatestMessages(options) {
  options = options || {};
  const ss = SpreadsheetApp.openById(getOrCreateWorkspace().spreadsheetId);
  const sh = ss.getSheetByName('Messages');
  const last = sh.getLastRow();
  if (last <= 1) return [];
  const take = Math.min(Number(options.limit || 50),100);
  const start = Math.max(2,last-take+1);
  const values = sh.getRange(start,1,last-start+1,9).getDisplayValues();
  const filterTo = (options.to || '').toUpperCase();
  const afterId = options.afterId || '';
  let foundAfter = !afterId;
  const out = [];
  values.forEach(r=>{
    const item={timestamp:r[0],id:r[1],from:r[2],to:r[3],type:r[4],text:r[5],status:r[6],threadId:r[7],priority:r[8]};
    if(afterId && item.id===afterId){foundAfter=true;return;}
    if(!foundAfter)return;
    if(filterTo && item.to!==filterTo && item.to!=='ALL')return;
    out.push(item);
  });
  return out;
}

function markRead(ids) {
  if (!Array.isArray(ids) || !ids.length) return {ok:true};
  const idSet = new Set(ids);
  const ss = SpreadsheetApp.openById(getOrCreateWorkspace().spreadsheetId);
  const sh = ss.getSheetByName('Messages');
  const last = sh.getLastRow();
  if (last <= 1) return {ok:true};
  const rows = sh.getRange(2,1,last-1,9).getValues();
  rows.forEach((r,idx)=>{ if(idSet.has(String(r[1]))) sh.getRange(idx+2,7).setValue('read'); });
  return {ok:true};
}

function getUnreadForOwner() {
  const ss = SpreadsheetApp.openById(getOrCreateWorkspace().spreadsheetId);
  const sh = ss.getSheetByName('Messages');
  const last = sh.getLastRow();
  if (last <= 1) return [];
  const values = sh.getRange(2,1,last-1,9).getDisplayValues();
  return values.filter(r=>(r[3]==='OWNER'||r[3]==='ALL')&&r[6]==='unread').map(r=>({timestamp:r[0],id:r[1],from:r[2],to:r[3],type:r[4],text:r[5],status:r[6],threadId:r[7],priority:r[8]})).slice(-20);
}

function doPost(e) {
  try {
    const body = JSON.parse((e.postData && e.postData.contents) || '{}');
    const result = sendMessage(body);
    return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)})).setMimeType(ContentService.MimeType.JSON);
  }
}
