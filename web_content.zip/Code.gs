const APP_NAME = "Morizelle's Book Tracker";
const SHEET_NAME = "Books";
const SETTINGS_NAME = "Settings";
const SPREADSHEET_ID_PROPERTY = "BOOK_TRACKER_SPREADSHEET_ID";
const PDF_FOLDER_PROPERTY = "BOOK_TRACKER_PDF_FOLDER_ID";

/*
 * OPTIONAL: if you know the ID of your OLD sheet, paste it here.
 * (The long text between /d/ and /edit in the sheet's web address.)
 * Then run connectOldSheet() once. Leave empty to auto-find it.
 */
const OLD_SHEET_ID = "";

const BOOK_HEADERS = [
  "ID", "Title", "Author", "Genre", "Format", "Pages", "Current Page",
  "Rating", "Series", "Series Number", "Status", "Cover URL", "Bookmark",
  "Notes", "Created", "Updated", "PDF File ID", "PDF File Name", "PDF URL",
  "Last Read"
];


/* =========================
   WEB APP
========================= */
function doGet() {
  return HtmlService
    .createHtmlOutputFromFile("index")
    .setTitle(APP_NAME)
    .addMetaTag("viewport",
      "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}


/* =========================
   FINDING / CONNECTING YOUR OLD BOOKS
========================= */

/**
 * Run this once from the editor to see every spreadsheet
 * that looks like a book tracker, and how many books it has.
 * Check View > Logs (or Execution log).
 */
function listMySheets() {
  const found = findCandidateSheets_();
  if (!found.length) {
    Logger.log("No book tracker spreadsheets found in your Drive.");
    return;
  }
  found.forEach(c => {
    Logger.log(c.name + "  |  books: " + c.books + "  |  ID: " + c.id);
  });
}

/**
 * Run this once to connect the app to your old books.
 * Uses OLD_SHEET_ID if set, otherwise picks the
 * spreadsheet with the most books.
 */
function connectOldSheet() {
  let id = OLD_SHEET_ID;

  if (!id) {
    const found = findCandidateSheets_();
    if (!found.length) {
      throw new Error(
        "No book tracker spreadsheet found. Paste your sheet ID " +
        "into OLD_SHEET_ID at the top and run again."
      );
    }
    id = found[0].id;
  }

  const ss = SpreadsheetApp.openById(id);
  let sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = ss.getSheets()[0];
    sheet.setName(SHEET_NAME);
  }

  ensureBookColumns_(sheet);

  PropertiesService.getScriptProperties()
    .setProperty(SPREADSHEET_ID_PROPERTY, id);

  Logger.log("Connected to: " + ss.getName() +
    " | books: " + Math.max(sheet.getLastRow() - 1, 0));
}

function findCandidateSheets_() {
  const names = [
    "My Digital Bookshelf",
    "Digital Bookshelf",
    "Morizelle's Book Tracker",
    "Book Tracker",
    "Bookshelf"
  ];

  const seen = {};
  const out = [];

  names.forEach(n => {
    const files = DriveApp.searchFiles(
      "title contains '" + n.replace(/'/g, "\\'") + "' and " +
      "mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false"
    );

    while (files.hasNext()) {
      const f = files.next();
      if (seen[f.getId()]) continue;
      seen[f.getId()] = true;

      let books = 0;
      try {
        const ss = SpreadsheetApp.openById(f.getId());
        const sh = ss.getSheetByName(SHEET_NAME) || ss.getSheets()[0];
        books = Math.max(sh.getLastRow() - 1, 0);
      } catch (e) {}

      out.push({ id: f.getId(), name: f.getName(), books: books });
    }
  });

  out.sort((a, b) => b.books - a.books);
  return out;
}


/* =========================
   FIRST-TIME SETUP
========================= */
function setupLibrary() {
  const props = PropertiesService.getScriptProperties();
  let spreadsheetId = props.getProperty(SPREADSHEET_ID_PROPERTY);
  let spreadsheet = null;

  if (spreadsheetId) {
    try { spreadsheet = SpreadsheetApp.openById(spreadsheetId); }
    catch (e) { spreadsheet = null; }
  }

  if (!spreadsheet) {
    spreadsheet = SpreadsheetApp.create(APP_NAME);
    props.setProperty(SPREADSHEET_ID_PROPERTY, spreadsheet.getId());
  }

  let books = spreadsheet.getSheetByName(SHEET_NAME);

  if (!books) {
    books = spreadsheet.insertSheet(SHEET_NAME);
    books.getRange(1, 1, 1, BOOK_HEADERS.length).setValues([BOOK_HEADERS]);
  } else {
    ensureBookColumns_(books);
  }

  books.setFrozenRows(1);
  books.getRange(1, 1, 1, BOOK_HEADERS.length).setFontWeight("bold");

  let settings = spreadsheet.getSheetByName(SETTINGS_NAME);

  if (!settings) {
    settings = spreadsheet.insertSheet(SETTINGS_NAME);
    settings.getRange("A1:B4").setValues([
      ["Setting", "Value"],
      ["App Name", APP_NAME],
      ["Created", new Date()],
      ["Version", "3.0 - PDF Reader"]
    ]);
    settings.getRange("A1:B1").setFontWeight("bold");
  }

  return {
    success: true,
    spreadsheetId: spreadsheet.getId(),
    spreadsheetUrl: spreadsheet.getUrl()
  };
}


/* =========================
   SPREADSHEET HELPERS
========================= */
function getSpreadsheet_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty(SPREADSHEET_ID_PROPERTY);

  if (id) {
    try { return SpreadsheetApp.openById(id); } catch (e) {}
  }

  // Nothing saved yet: try to reuse an existing tracker sheet first
  try {
    const found = findCandidateSheets_();
    if (found.length && found[0].books > 0) {
      props.setProperty(SPREADSHEET_ID_PROPERTY, found[0].id);
      return SpreadsheetApp.openById(found[0].id);
    }
  } catch (e) {}

  const result = setupLibrary();
  return SpreadsheetApp.openById(result.spreadsheetId);
}

function getBooksSheet_() {
  const spreadsheet = getSpreadsheet_();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);

  if (!sheet) {
    setupLibrary();
    sheet = getSpreadsheet_().getSheetByName(SHEET_NAME);
  }

  ensureBookColumns_(sheet);
  return sheet;
}

/**
 * Makes sure an older sheet (16 columns) gets the new
 * PDF columns. Only writes the header row, never your data.
 */
function ensureBookColumns_(sheet) {
  const last = sheet.getLastColumn();

  if (last < BOOK_HEADERS.length) {
    sheet.insertColumnsAfter(
      Math.max(last, 1),
      BOOK_HEADERS.length - last
    );
  }

  sheet.getRange(1, 1, 1, BOOK_HEADERS.length).setValues([BOOK_HEADERS]);
}

function findRow_(sheet, bookId) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return 0;

  const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();

  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(bookId)) return i + 2;
  }
  return 0;
}

function iso_(value) {
  if (!value) return "";
  const d = new Date(value);
  return isNaN(d.getTime()) ? "" : d.toISOString();
}


/* =========================
   TEST CONNECTION
========================= */
function testConnection() {
  try {
    const spreadsheet = getSpreadsheet_();
    return {
      success: true,
      app: APP_NAME,
      spreadsheet: spreadsheet.getName(),
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    return { success: false, error: error.toString() };
  }
}


/* =========================
   GET BOOKS
========================= */
function getBooks() {
  const sheet = getBooksSheet_();
  const lastRow = sheet.getLastRow();

  if (lastRow < 2) return [];

  const values = sheet
    .getRange(2, 1, lastRow - 1, BOOK_HEADERS.length)
    .getValues();

  return values
    .filter(row => row[1])
    .map(row => ({
      id: String(row[0] || ""),
      title: String(row[1] || ""),
      author: String(row[2] || ""),
      genre: String(row[3] || ""),
      format: String(row[4] || ""),
      pages: Number(row[5]) || 0,
      currentPage: Number(row[6]) || 0,
      rating: Number(row[7]) || 0,
      series: String(row[8] || ""),
      seriesNum: String(row[9] || ""),
      status: String(row[10] || "Want to Read"),
      cover: String(row[11] || ""),
      bookmark: String(row[12] || ""),
      notes: String(row[13] || ""),
      created: iso_(row[14]) || new Date().toISOString(),
      updated: iso_(row[15]) || new Date().toISOString(),
      pdfFileId: String(row[16] || ""),
      pdfFileName: String(row[17] || ""),
      pdfUrl: String(row[18] || ""),
      lastRead: iso_(row[19])
    }));
}


/* =========================
   SAVE BOOKS
   Keeps existing PDF info if the app doesn't send it.
========================= */
function saveBooks(books) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    const sheet = getBooksSheet_();

    if (!Array.isArray(books)) books = [];

    const existingPdfData = getExistingPdfData_(sheet);

    const rows = books.map(book => {
      const id = book.id || createId_();
      const oldPdf = existingPdfData[id] || {};

      return [
        id,
        book.title || "",
        book.author || "",
        book.genre || "",
        book.format || "",
        Number(book.pages) || 0,
        Number(book.currentPage) || 0,
        Number(book.rating) || 0,
        book.series || "",
        book.seriesNum || "",
        book.status || "Want to Read",
        book.cover || "",
        book.bookmark || "",
        book.notes || "",
        book.created ? new Date(book.created) : new Date(),
        new Date(),
        book.pdfFileId || oldPdf.pdfFileId || "",
        book.pdfFileName || oldPdf.pdfFileName || "",
        book.pdfUrl || oldPdf.pdfUrl || "",
        book.lastRead ? new Date(book.lastRead) : (oldPdf.lastRead || "")
      ];
    });

    // Clear data rows only; headers stay
    const oldLastRow = sheet.getLastRow();
    if (oldLastRow > 1) {
      sheet.getRange(2, 1, oldLastRow - 1, BOOK_HEADERS.length).clearContent();
    }

    if (rows.length) {
      sheet.getRange(2, 1, rows.length, BOOK_HEADERS.length).setValues(rows);
    }

    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, BOOK_HEADERS.length).setFontWeight("bold");

    return { success: true, count: rows.length };

  } finally {
    lock.releaseLock();
  }
}

function getExistingPdfData_(sheet) {
  const result = {};
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return result;

  const values = sheet
    .getRange(2, 1, lastRow - 1, BOOK_HEADERS.length)
    .getValues();

  values.forEach(row => {
    const id = String(row[0] || "");
    if (!id) return;

    result[id] = {
      pdfFileId: String(row[16] || ""),
      pdfFileName: String(row[17] || ""),
      pdfUrl: String(row[18] || ""),
      lastRead: row[19] || ""
    };
  });

  return result;
}


/* =========================
   PDF FOLDER
========================= */
function getPdfFolder_() {
  const props = PropertiesService.getScriptProperties();
  const folderId = props.getProperty(PDF_FOLDER_PROPERTY);

  if (folderId) {
    try { return DriveApp.getFolderById(folderId); } catch (e) {}
  }

  const folder = DriveApp.createFolder(APP_NAME + " - PDFs");
  props.setProperty(PDF_FOLDER_PROPERTY, folder.getId());
  return folder;
}


/* =========================
   UPLOAD PDF
   fileData = { name, mimeType, data (base64) }
========================= */
function uploadBookPdf(bookId, fileData) {
  if (!bookId) throw new Error("Book ID is required.");
  if (!fileData || !fileData.data) throw new Error("No PDF file was received.");

  const name = fileData.name || "book.pdf";

  if (!name.toLowerCase().endsWith(".pdf")) {
    throw new Error("Only PDF files are allowed.");
  }

  const bytes = Utilities.base64Decode(fileData.data);

  if (bytes.length > 25 * 1024 * 1024) {
    throw new Error("This PDF is too large. Please use a PDF smaller than 25 MB.");
  }

  const folder = getPdfFolder_();

  // Replace any old PDF for this book
  const oldPdf = getBookPdfInfo_(bookId);
  if (oldPdf && oldPdf.pdfFileId) {
    try { DriveApp.getFileById(oldPdf.pdfFileId).setTrashed(true); } catch (e) {}
  }

  const blob = Utilities.newBlob(bytes, "application/pdf", name);
  const file = folder.createFile(blob);

  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (e) {
    // Some Workspace accounts block link sharing. The app still works.
  }

  const fileId = file.getId();
  const pdfUrl = "https://drive.google.com/file/d/" + fileId + "/view";

  savePdfInfo_(bookId, fileId, name, pdfUrl);

  return {
    success: true,
    bookId: bookId,
    fileId: fileId,
    fileName: name,
    url: pdfUrl
  };
}


/* =========================
   PDF INFO
========================= */
function getBookPdfInfo(bookId) {
  return getBookPdfInfo_(bookId);
}

function getBookPdfInfo_(bookId) {
  const sheet = getBooksSheet_();
  const row = findRow_(sheet, bookId);
  if (!row) return null;

  const r = sheet.getRange(row, 1, 1, BOOK_HEADERS.length).getValues()[0];

  return {
    pdfFileId: String(r[16] || ""),
    pdfFileName: String(r[17] || ""),
    pdfUrl: String(r[18] || ""),
    lastRead: iso_(r[19])
  };
}

function savePdfInfo_(bookId, fileId, fileName, pdfUrl) {
  const sheet = getBooksSheet_();
  const row = findRow_(sheet, bookId);
  if (!row) return;

  sheet.getRange(row, 17, 1, 3).setValues([[fileId, fileName, pdfUrl]]);
  sheet.getRange(row, 16).setValue(new Date());
}


/* =========================
   GET PDF AS BASE64 (for the in-app reader)
========================= */
function getPdfBase64(bookId) {
  const info = getBookPdfInfo_(bookId);

  if (!info || !info.pdfFileId) {
    throw new Error("No PDF has been uploaded for this book.");
  }

  const file = DriveApp.getFileById(info.pdfFileId);

  return {
    success: true,
    fileName: file.getName(),
    mimeType: "application/pdf",
    data: Utilities.base64Encode(file.getBlob().getBytes())
  };
}


/* =========================
   UPDATE READING PROGRESS
========================= */
function updateReadingProgress(bookId, currentPage, totalPages) {
  const sheet = getBooksSheet_();
  const row = findRow_(sheet, bookId);

  if (!row) throw new Error("Book not found.");

  let page = Number(currentPage) || 0;
  const pages = Number(totalPages) || 0;

  if (page < 0) page = 0;
  if (pages > 0 && page > pages) page = pages;

  if (pages > 0) sheet.getRange(row, 6).setValue(pages);

  sheet.getRange(row, 7).setValue(page);

  let status = "Want to Read";

  if (pages > 0 && page >= pages) {
    status = "Finished";
    sheet.getRange(row, 11).setValue(status);
  } else if (page > 0) {
    status = "Reading";
    sheet.getRange(row, 11).setValue(status);
  }

  sheet.getRange(row, 13).setValue("Page " + page);
  sheet.getRange(row, 16).setValue(new Date());
  sheet.getRange(row, 20).setValue(new Date());

  return {
    success: true,
    currentPage: page,
    totalPages: pages,
    status: status
  };
}


/* =========================
   REMOVE BOOK PDF
========================= */
function removeBookPdf(bookId) {
  const info = getBookPdfInfo_(bookId);

  if (info && info.pdfFileId) {
    try { DriveApp.getFileById(info.pdfFileId).setTrashed(true); } catch (e) {}
  }

  const sheet = getBooksSheet_();
  const row = findRow_(sheet, bookId);

  if (row) sheet.getRange(row, 17, 1, 3).clearContent();

  return { success: true };
}


/* =========================
   BACKUP & RESTORE
========================= */
const BACKUP_FOLDER_PROPERTY = "BOOK_TRACKER_BACKUP_FOLDER_ID";
const MAX_BACKUP_FILES = 40;

function getBackupFolder_() {
  const props = PropertiesService.getScriptProperties();
  const folderId = props.getProperty(BACKUP_FOLDER_PROPERTY);

  if (folderId) {
    try { return DriveApp.getFolderById(folderId); } catch (e) {}
  }

  const folder = DriveApp.createFolder(APP_NAME + " - Backups");
  props.setProperty(BACKUP_FOLDER_PROPERTY, folder.getId());
  return folder;
}

/**
 * Saves a JSON backup of every book AND a full copy of the
 * Google Sheet into the Backups folder in Drive.
 */
function createBackup() {
  const books = getBooks();
  const folder = getBackupFolder_();
  const stamp = Utilities.formatDate(
    new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd HH-mm-ss"
  );

  const payload = {
    app: APP_NAME,
    created: new Date().toISOString(),
    count: books.length,
    books: books
  };

  const jsonFile = folder.createFile(
    "Backup " + stamp + ".json",
    JSON.stringify(payload),
    MimeType.PLAIN_TEXT
  );

  try {
    DriveApp.getFileById(getSpreadsheet_().getId())
      .makeCopy("Backup " + stamp + " (sheet copy)", folder);
  } catch (e) {}

  pruneBackups_(folder);

  return {
    success: true,
    count: books.length,
    name: jsonFile.getName(),
    id: jsonFile.getId(),
    url: folder.getUrl()
  };
}

function pruneBackups_(folder) {
  const files = [];
  const it = folder.getFiles();

  while (it.hasNext()) files.push(it.next());

  files.sort((a, b) => b.getDateCreated() - a.getDateCreated());

  files.slice(MAX_BACKUP_FILES).forEach(f => {
    try { f.setTrashed(true); } catch (e) {}
  });
}

function listBackups() {
  const folder = getBackupFolder_();
  const out = [];
  const it = folder.getFiles();

  while (it.hasNext()) {
    const f = it.next();
    if (!/\.json$/i.test(f.getName())) continue;
    out.push({
      id: f.getId(),
      name: f.getName(),
      created: f.getDateCreated().toISOString()
    });
  }

  out.sort((a, b) => b.created.localeCompare(a.created));
  return out.slice(0, 15);
}

/**
 * Restores books from a Drive backup. A safety backup of the
 * current library is made first.
 */
function restoreBackup(fileId) {
  const text = DriveApp.getFileById(fileId).getBlob().getDataAsString();
  const data = JSON.parse(text);
  const books = Array.isArray(data) ? data : data.books;

  if (!Array.isArray(books)) throw new Error("That file is not a valid backup.");

  createBackup();
  saveBooks(books);

  return { success: true, count: books.length };
}

/* Automatic daily backup */
function autoBackupJob() {
  createBackup();
}

function setAutoBackup(enabled) {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === "autoBackupJob") ScriptApp.deleteTrigger(t);
  });

  if (enabled) {
    ScriptApp.newTrigger("autoBackupJob")
      .timeBased().everyDays(1).atHour(3).create();
  }

  return { success: true, enabled: !!enabled };
}

function getAutoBackup() {
  return ScriptApp.getProjectTriggers()
    .some(t => t.getHandlerFunction() === "autoBackupJob");
}


/* =========================
   THEME (remembers dark / light mode)
========================= */
function getTheme() {
  return PropertiesService.getScriptProperties().getProperty("BOOK_TRACKER_THEME") || "";
}

function setTheme(theme) {
  PropertiesService.getScriptProperties()
    .setProperty("BOOK_TRACKER_THEME", theme === "dark" ? "dark" : "light");
  return { success: true };
}


/* =========================
   OPEN GOOGLE SHEET
========================= */
function openLibrary() {
  return getSpreadsheet_().getUrl();
}


/* =========================
   CREATE ID
========================= */
function createId_() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
}
