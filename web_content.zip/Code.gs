const APP_TITLE = 'سجل الشهداء وذوي الشهداء';
const MARTYRS_SHEET = 'الشهداء';
const RELATIVES_SHEET = 'ذوو الشهداء';
const ATTACHMENTS_FOLDER = 'مرفقات سجل الشهداء';

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle(APP_TITLE)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('افتح Apps Script من داخل ملف Google Sheets أولاً.');
  ensureSheet_(ss, MARTYRS_SHEET,
    ['رقم الشهيد', 'اسم الشهيد', 'العنوان', 'ملاحظات', 'روابط المرفقات', 'تاريخ التسجيل']);
  ensureSheet_(ss, RELATIVES_SHEET,
    ['رقم ذي الشهيد', 'رقم الشهيد', 'اسم الشهيد', 'اسم ذي الشهيد', 'درجة القرابة', 'رقم الهاتف', 'العنوان', 'ملاحظات', 'روابط المرفقات', 'تاريخ التسجيل']);
  getOrCreateFolder_();
  return 'تم تجهيز جدولي الشهداء وذوي الشهداء ومجلد المرفقات.';
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.appendRow(headers);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, headers.length).setFontWeight('bold');
  }
  return sh;
}

function getSheets_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('لا يوجد جدول بيانات مرتبط بالمشروع.');
  return {
    ss: ss,
    martyrs: ensureSheet_(ss, MARTYRS_SHEET,
      ['رقم الشهيد', 'اسم الشهيد', 'العنوان', 'ملاحظات', 'روابط المرفقات', 'تاريخ التسجيل']),
    relatives: ensureSheet_(ss, RELATIVES_SHEET,
      ['رقم ذي الشهيد', 'رقم الشهيد', 'اسم الشهيد', 'اسم ذي الشهيد', 'درجة القرابة', 'رقم الهاتف', 'العنوان', 'ملاحظات', 'روابط المرفقات', 'تاريخ التسجيل'])
  };
}

function getOrCreateFolder_() {
  const it = DriveApp.getFoldersByName(ATTACHMENTS_FOLDER);
  return it.hasNext() ? it.next() : DriveApp.createFolder(ATTACHMENTS_FOLDER);
}

function saveFiles_(files, prefix) {
  if (!files || !files.length) return '';
  const folder = getOrCreateFolder_();
  const urls = [];
  files.forEach(function(f) {
    if (!f || !f.data || !f.name) return;
    const bytes = Utilities.base64Decode(f.data);
    const safeName = String(f.name).replace(/[\\/:*?"<>|]/g, '_').slice(0, 100);
    const blob = Utilities.newBlob(bytes, f.mimeType || 'application/octet-stream', prefix + '_' + Date.now() + '_' + safeName);
    const file = folder.createFile(blob);
    urls.push(file.getUrl());
  });
  return urls.join('\n');
}

function saveMartyr(data) {
  if (!data || !String(data.name || '').trim()) throw new Error('يرجى إدخال اسم الشهيد.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const sheets = getSheets_();
    const id = 'SH-' + Utilities.getUuid().split('-')[0].toUpperCase();
    const links = saveFiles_(data.files || [], id);
    sheets.martyrs.appendRow([id, data.name.trim(), data.address || '', data.notes || '', links, new Date()]);
    return { id: id, name: data.name.trim(), message: 'تم حفظ بيانات الشهيد بنجاح.' };
  } finally {
    lock.releaseLock();
  }
}

function saveRelatives(data) {
  if (!data || !data.martyrId) throw new Error('يرجى اختيار الشهيد أولاً.');
  if (!data.relatives || !data.relatives.length) throw new Error('أضف فرداً واحداً على الأقل من ذوي الشهيد.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const sheets = getSheets_();
    const martyrs = sheets.martyrs.getDataRange().getValues();
    let martyrName = '';
    for (let i = 1; i < martyrs.length; i++) {
      if (String(martyrs[i][0]) === String(data.martyrId)) {
        martyrName = String(martyrs[i][1]);
        break;
      }
    }
    if (!martyrName) throw new Error('لم يتم العثور على الشهيد المحدد. حدّث القائمة وحاول مجدداً.');
    let count = 0;
    data.relatives.forEach(function(r) {
      if (!String(r.name || '').trim()) return;
      const id = 'ZR-' + Utilities.getUuid().split('-')[0].toUpperCase();
      const links = saveFiles_(r.files || [], id);
      sheets.relatives.appendRow([
        id, data.martyrId, martyrName, r.name.trim(), r.relation || '',
        r.phone || '', r.address || '', r.notes || '', links, new Date()
      ]);
      count++;
    });
    if (!count) throw new Error('أدخل اسم فرد واحد على الأقل.');
    return { count: count, message: 'تم حفظ ' + count + ' من ذوي الشهيد بنجاح.' };
  } finally {
    lock.releaseLock();
  }
}

function getMartyrs() {
  const sheets = getSheets_();
  const values = sheets.martyrs.getDataRange().getDisplayValues();
  return values.slice(1).filter(r => r[0] && r[1]).map(r => ({ id: r[0], name: r[1], address: r[2] }));
}

function getRecords() {
  const sheets = getSheets_();
  const m = sheets.martyrs.getDataRange().getDisplayValues();
  const r = sheets.relatives.getDataRange().getDisplayValues();
  return {
    martyrs: m.slice(1).filter(x => x[0]).map(x => ({id:x[0], name:x[1], address:x[2], notes:x[3], date:x[5]})),
    relatives: r.slice(1).filter(x => x[0]).map(x => ({id:x[0], martyrId:x[1], martyrName:x[2], name:x[3], relation:x[4], phone:x[5], address:x[6], notes:x[7], date:x[9]}))
  };
}
