
(function(){
  'use strict';

  // Stable Save v2: extra protection against duplicate actions and corrupted storage.
  window.CGStable2 = window.CGStable2 || {};
  const S = window.CGStable2;

  S.now = () => Date.now();

  // Deterministic action lock: prevents the same logical action from being completed twice.
  S.actionLocks = S.actionLocks || new Map();
  S.withActionLock = async function(key, fn, ttl){
    ttl = ttl || 5000;
    const t = Date.now();
    const old = S.actionLocks.get(key);
    if(old && (t - old) < ttl) return false;
    S.actionLocks.set(key, t);
    try { return await fn(); }
    finally { setTimeout(()=> {
      if(S.actionLocks.get(key) === t) S.actionLocks.delete(key);
    }, ttl); }
  };

  // Stable VAT snapshot helpers. Existing code can use these when creating documents.
  S.vatRate = function(){
    try {
      const candidates = [
        window.companyData && window.companyData.vatRate,
        window.company && window.company.vatRate,
        window.settings && window.settings.vatRate,
        localStorage.getItem('vatRate')
      ];
      for(const x of candidates){
        if(x !== undefined && x !== null && x !== '' && !isNaN(Number(x)))
          return Number(x);
      }
    } catch(e){}
    return 5;
  };

  S.snapshotVat = function(doc){
    if(!doc || typeof doc !== 'object') return doc;
    if(doc.vatRate === undefined || doc.vatRate === null || doc.vatRate === '')
      doc.vatRate = S.vatRate();
    return doc;
  };

  // Safe localStorage read: bad JSON should not blank the application.
  S.safeJSON = function(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      if(raw === null || raw === '') return fallback;
      const value = JSON.parse(raw);
      return value;
    }catch(e){
      console.warn('CG Stable Save v2: invalid storage key:', key, e);
      return fallback;
    }
  };

  // Prevent accidental duplicate form submits even when the page has multiple listeners.
  S.submitGuard = function(form){
    if(!form) return true;
    const key = form.getAttribute('data-cg-submit-lock') || ('form:' + (form.id || Math.random()));
    const now = Date.now();
    const last = Number(form.dataset.cgLastSubmit || 0);
    if(now-last < 1200) return false;
    form.dataset.cgLastSubmit = String(now);
    form.setAttribute('data-cg-submit-lock', key);
    return true;
  };

  // Keep a stable VAT snapshot on known document collections whenever they are persisted.
  S.snapshotCollection = function(list){
    if(!Array.isArray(list)) return list;
    list.forEach(x => S.snapshotVat(x));
    return list;
  };

  // Diagnostic marker.
  window.addEventListener('error', function(ev){
    console.warn('CG Stable Save v2 runtime error:', ev.message || ev.error);
  });
})();
