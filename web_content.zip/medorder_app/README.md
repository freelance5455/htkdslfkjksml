# MedOrder PKR — Professional Order-Taking PWA

MedOrder PKR is an offline-first medical-store order-taking app designed around the primary workflow: **medical store → medicines → quantities → order → professional invoice**.

## What was fixed
- IndexedDB replaces localStorage for business records.
- Product photos are resized/compressed and stored separately in IndexedDB.
- Customer search works from the global search bar.
- Real stock quantities are tracked and reduced when an order is confirmed.
- Low-stock and out-of-stock states are calculated from quantities.
- Invoice numbers use a persistent sequence instead of `orders.length + 1`.
- Payment status supports Pending, Paid and Credit.
- Customer balances are maintained for unpaid/credit orders.
- Invoice is a professional, print-ready A4-style layout.
- The old one-page homemade PDF generator was removed. Use **Print / Save PDF** from the invoice screen; Chrome/Android can save the exact professional invoice as PDF and print it.
- Backup includes database records **and product images**.
- Restore recreates product images from the backup.
- Legacy MedOrder v1 localStorage data is migrated into the new IndexedDB store when possible.
- PKR is the only application currency.
- No external CDN/library is required for the core app, so the app shell remains suitable for offline use.

## Google Drive
Local IndexedDB remains the primary database. **Share backup** creates a complete backup file and uses the Android/Web Share sheet when available, allowing the user to select Google Drive. This is intentionally different from pretending Google Drive is the local database.

A true automatic Google Drive API sync requires a Google Cloud OAuth client belonging to the app owner. The current standalone build does not embed someone else's credentials.

## Run
Serve the folder over HTTP/HTTPS (PWA service workers require this; localhost is also suitable):

    python -m http.server 8080

Open the folder in Chrome/Chromium and use **Install app / Add to Home screen**.

## Important
This is a polished PWA build. For a production Android APK with native encrypted database, Android file storage, and direct Google Drive OAuth/Drive API backup, wrap this UI in a native Android project and configure the owner's Google Cloud OAuth credentials.
