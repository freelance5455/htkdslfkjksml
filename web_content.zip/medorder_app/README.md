# MedOrder PKR

A functional offline-first medical-store order-taking PWA.

## Main workflow
Home → New Order → select medical store → search/browse medicine catalog → add quantities → discount → Confirm Order → professional invoice → Download PDF / Print.

## Included
- PKR currency throughout
- Photo medicine catalog with product details
- Product creation with optional photo
- Customer/medical-store records
- Order and invoice history
- Professional printable invoice
- Direct PDF invoice download (pure JavaScript PDF writer; no external libraries)
- LocalStorage offline database
- Backup/restore JSON
- Share backup to Google Drive through the device share sheet when supported
- Responsive mobile-first UI
- PWA service worker for offline app shell

## Important Google Drive note
This build deliberately does not store business data in Google Drive. The phone's local storage is the primary database. Backup is a JSON file that can be shared/saved to Google Drive. Automatic Drive API sync requires a Google OAuth/Cloud project and credentials, which are not embedded in this standalone build.

## Run
Serve this folder from a local web server (PWA service workers require HTTP/HTTPS; localhost is okay):

    python -m http.server 8080

Open http://localhost:8080 in Chrome/Chromium.

On Android Chrome, use the browser menu → Add to Home screen / Install app.

## Data safety
The app stores data in the browser's localStorage. Use Backup regularly before clearing browser/app data.
