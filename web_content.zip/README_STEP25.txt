STEP 25 – Zentrales Haushaltsprofil

Neu:
- Haushaltsprofil in den Einstellungen
- Personen im Haushalt und Haustiere zentral hinterlegen
- Vorsorge-Mengenrechner übernimmt die Personenanzahl aus dem Haushaltsprofil
- Änderungen im Mengenrechner synchronisieren das Profil
- Grundlage für spätere haushaltsabhängige Funktionen

Keine neue Supabase-Migration nötig; Profil wird haushaltsbezogen lokal gespeichert.
