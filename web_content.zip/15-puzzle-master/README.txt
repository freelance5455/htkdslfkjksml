15 PUZZLE MASTER — ishga tushirish
====================================
Internet kerak emas. Hamma narsa shu papkada.

A) Eng oson (telefon): zip faylni "Fayllar" ilovasida oching (Extract),
   keyin index.html ni Chrome bilan oching.

B) Termux orqali (agar A ishlamasa):
   pkg install unzip python
   unzip 15-puzzle-master.zip
   cd 15-puzzle-master
   python -m http.server 8080
   Chrome'da oching:  http://localhost:8080

Kompyuter: zipni oching va index.html ni ikki marta bosing.

Fayllar: index.html (sahifa), style.css (dizayn), script.js (o‘yin va AI),
assets/ (ikonka). Natijalar brauzer LocalStorage'ida saqlanadi.
Klaviatura: strelkalar bilan ham o‘ynash mumkin.

AI: 3×3 va 4×4 — IDA* (Manhattan + Linear Conflict, eng qisqa yechim).
5×5 va 6×6 — Weighted A* (tez, lekin yechim eng qisqa bo‘lmasligi mumkin).
