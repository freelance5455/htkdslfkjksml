'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const rnd=k=>crypto.getRandomValues(new Uint32Array(1))[0]%k;
const solved=n=>[...Array(n*n-1)].map((_,i)=>i+1).concat(0);
const nb=(z,n)=>{const r=z/n|0,c=z%n,a=[];if(r>0)a.push(z-n);if(r<n-1)a.push(z+n);if(c>0)a.push(z-1);if(c<n-1)a.push(z+1);return a};
const fmt=s=>(s/60|0)+':'+String(s%60).padStart(2,'0');
// Yechilish sharti: inversiyalar + bo‘sh katak qatori
function solvable(s,n){const a=s.filter(x=>x);let inv=0;for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++)if(a[i]>a[j])inv++;const row=n-(s.indexOf(0)/n|0);return n%2?inv%2===0:(row%2?inv%2===0:inv%2===1)}
// Aralashtirish: yechilgan holatdan faqat qonuniy yurishlar (har doim yechiladi)
function shuffle(n){let s,z,pv;const k=n*n*(n<5?30:8),S0=solved(n).join();
 do{s=solved(n);z=n*n-1;pv=-1;for(let i=0;i<k;i++){const o=nb(z,n).filter(x=>x!==pv),x=o[rnd(o.length)];s[z]=s[x];s[x]=0;pv=z;z=x}}
 while(s.join()===S0||s.join()===localStorage.p15last||!solvable(s,n));
 localStorage.p15last=s.join();return s}
// Linear Conflict: har qatorda eng kam olib tashlanadigan plitkalar x2
function LC(a){const m=a.length,c=a.map((x,i)=>a.reduce((s,y,j)=>s+((j>i&&y<x)||(j<i&&y>x)?1:0),0));let add=0;
 for(;;){let mi=0;for(let i=1;i<m;i++)if(c[i]>c[mi])mi=i;if(!c[mi])break;
 for(let j=0;j<m;j++)if(j!==mi&&((j>mi&&a[j]<a[mi])||(j<mi&&a[j]>a[mi])))c[j]--;c[mi]=0;add+=2}return add}
// Heuristika: Manhattan Distance + Linear Conflict
function H(s,n){let h=0;for(let i=0;i<n;i++){const R=[],C=[];for(let j=0;j<n;j++){let v=s[i*n+j];if(v){const gr=(v-1)/n|0,gc=(v-1)%n;h+=Math.abs(gr-i)+Math.abs(gc-j);if(gr===i)R.push(gc)}
 v=s[j*n+i];if(v&&(v-1)%n===i)C.push((v-1)/n|0)}h+=LC(R)+LC(C)}return h}
// IDA*: eng qisqa (optimal) yechim, tugun limiti bilan
function ida(s0,n,cap){const s=s0.slice(),P=[];let z=s.indexOf(0),nodes=0;
 const d=(g,prev,L)=>{const h=H(s,n),f=g+h;if(f>L)return f;if(!h)return -1;if(++nodes>cap)return -2;let m=1e9;
  for(const x of nb(z,n)){if(x===prev)continue;const o=z;s[o]=s[x];s[x]=0;z=x;P.push(x);const r=d(g+1,o,L);if(r<0)return r;if(r<m)m=r;P.pop();s[x]=s[o];s[o]=0;z=o}return m};
 let L=H(s,n);for(;;){const r=d(0,-1,L);if(r===-1)return P;if(r===-2||r>=1e9)return null;L=r}}
// Weighted A*: katta maydonlar uchun (taxminiy yechim, xotira limiti bilan)
function wa(s0,n,w,cap){const B=[],seen=new Set([s0.join()]);let lo=0,c=0;
 const add=o=>{o.h=H(o.s,n);const f=o.g+w*o.h;(B[f]=B[f]||[]).push(o);if(f<lo)lo=f};
 add({s:s0,z:s0.indexOf(0),g:0});
 while(c++<cap){while(lo<B.length&&!(B[lo]&&B[lo].length))lo++;if(lo>=B.length)return null;
  const o=B[lo].pop();if(!o.h){const P=[];for(let q=o;q.p;q=q.p)P.unshift(q.x);return P}
  for(const x of nb(o.z,n)){const t=o.s.slice();t[o.z]=t[x];t[x]=0;const k=t.join();if(seen.has(k))continue;seen.add(k);add({s:t,z:x,g:o.g+1,p:o,x})}}
 return null}
function solve(s,n){if(!solvable(s,n))return null;const p=n<5?ida(s,n,n<4?4e6:6e5):null;if(p){p.opt=1;return p}return wa(s,n,n<5?2:5,15e4)}
//--UI
let N=4,b=[],start=[],mv=0,sec=0,paused=0,started=0,won=0,busy=0,cheat=0,hist=[],T={},memo={},auto,anim,ST;
try{ST=JSON.parse(localStorage.p15)}catch(e){}ST=ST||{t:0,w:0,g:[]};
const save=()=>{try{localStorage.p15=JSON.stringify(ST)}catch(e){}};
const msg=t=>$('#msg').textContent=t;
const upd=()=>{$('#mv').textContent=mv;$('#tm').textContent=fmt(sec)};
function build(){const B=$('#board');B.innerHTML='';B.style.setProperty('--n',N);T={};
 for(let v=1;v<N*N;v++){const d=document.createElement('div');d.className='tile';d.textContent=v;d.style.background=`hsl(${v*340/(N*N)|0} 72% 52%)`;d.style.setProperty('--i',v);d.onclick=()=>act(b.indexOf(v));B.append(d);T[v]=d}}
function pos(){for(const v in T){const i=b.indexOf(+v);T[v].style.transform=`translate(${i%N*100}%,${(i/N|0)*100}%)`}}
function reset(){clearInterval(auto);clearInterval(anim);mv=0;sec=0;hist=[];started=won=paused=cheat=0;memo={};const B=$('#board');B.className='';$('#pz').textContent='⏸ Pauza'}
function newGame(n){if(n)N=n;reset();busy=1;const target=shuffle(N);start=target.slice();b=solved(N);build();pos();upd();msg('Aralashtirilmoqda…');let i=0;
 anim=setInterval(()=>{if(i++<12){const z=b.indexOf(0),o=nb(z,N),q=o[rnd(o.length)];b[z]=b[q];b[q]=0;pos()}
 else{clearInterval(anim);b=target.slice();pos();setTimeout(()=>{busy=0;msg('Boshlang!')},450)}},70)}
function restart(){if(!start.length)return;reset();busy=0;b=start.slice();pos();upd();msg('')}
function step(q){const z=b.indexOf(0);b[z]=b[q];b[q]=0;hist.push(z);mv++}
function begin(){if(!started){started=1;ST.t++;save()}}
function act(p){if(busy||paused||won||!(p>=0))return;const z=b.indexOf(0),n=N;let st;
 if((p/n|0)===(z/n|0))st=p>z?1:-1;else if(p%n===z%n)st=p>z?n:-n;else return;
 begin();for(let q=z+st;;q+=st){step(q);if(q===p)break}fin()}
function fin(){pos();upd();msg('');if(started&&b.join()===solved(N).join())win()}
function win(){won=1;busy=0;clearInterval(auto);$('#board').classList.add('win');
 if(cheat)return msg('🤖 AI yechdi (natija saqlanmadi)');
 ST.w++;ST.g.unshift({n:N,s:sec,m:mv,d:Date.now()});ST.g=ST.g.slice(0,200);save();msg(`🎉 Tabriklaymiz! ${mv} yurish, ${fmt(sec)}`)}
function undo(){if(busy||paused||won||!hist.length)return;const z=b.indexOf(0),p=hist.pop();b[z]=b[p];b[p]=0;mv--;fin()}
function pause(){if(!started||won||busy)return;paused=paused?0:1;$('#board').classList.toggle('paused',!!paused);$('#pz').textContent=paused?'▶ Davom':'⏸ Pauza'}
function think(cb){if(busy||paused||won)return;busy=1;msg('🤖 AI o‘ylamoqda…');
 setTimeout(()=>{const k=b.join();if(memo.k!==k)memo={k,p:solve(b,N)};busy=0;msg('');cb(memo.p)},50)}
function hint(){think(p=>{if(!p)return msg('Yechim topilmadi');if(!p.length)return;const v=b[p[0]];T[v].classList.add('hint');setTimeout(()=>T[v].classList.remove('hint'),1800);msg('💡 Keyingi plitka: '+v)})}
function ai(){think(p=>msg(p?`🤖 Yechim: ${p.length} yurish `+(p.opt?'(eng maqbul, IDA*)':'(taxminiy, A*)'):'Yechim topilmadi'))}
function play(){think(p=>{if(!p)return msg('Yechim topilmadi');if(!p.length)return;cheat=1;started=1;busy=1;let i=0;
 auto=setInterval(()=>{if(i<p.length){step(p[i++]);pos();upd()}else{clearInterval(auto);fin()}},180)})}
function renderStats(){const all=ST.g,g=all.filter(x=>x.n===N),a=k=>g.length?g.reduce((x,y)=>x+y[k],0)/g.length:0,mn=k=>g.length?Math.min(...g.map(x=>x[k])):0;
 $('#stats').innerHTML=`<div class="card"><p>Jami: <b>${ST.t}</b> o‘yin, <b>${ST.w}</b> g‘alaba. Quyidagi ko‘rsatkichlar <b>${N}×${N}</b> rejimi uchun.</p></div>
 <div class="grid"><div><b>${ST.t}</b>Jami o‘yinlar</div><div><b>${ST.w}</b>G‘alabalar</div><div><b>${fmt(mn('s'))}</b>Eng yaxshi vaqt</div><div><b>${mn('m')}</b>Eng kam yurish</div><div><b>${fmt(Math.round(a('s')))}</b>O‘rtacha vaqt</div><div><b>${Math.round(a('m'))}</b>O‘rtacha yurish</div></div>
 <h3>O‘yinlar tarixi</h3><ol>${all.slice(0,20).map(x=>`<li>${x.n}×${x.n} — ${fmt(x.s)}, ${x.m} yurish, ${new Date(x.d).toLocaleDateString()}</li>`).join('')||'<li>Hali g‘alaba yo‘q</li>'}</ol><button id="clr">Tozalash</button>`;
 $('#clr').onclick=()=>{if(confirm('Statistika o‘chirilsinmi?')){ST={t:0,w:0,g:[]};save();renderStats()}}}
const LEARN=[
['Qator usuli','Yuqoridan boshlab qatorlarni birma-bir yig‘ing. Qatorning oxirgi ikki raqamini birga o‘rnatish uchun avval ikkinchisini oxirgi katakning ostiga qo‘yib, keyin ikkalasini bir yo‘la suring. Oxirgi ikki qator qolganda ustunma-ustun davom eting. Yangi boshlovchilar uchun eng oson usul.'],
['Ustun usuli','Chapdan o‘ngga ustunlarni yig‘adi. Qator usulining ko‘zgudagi aksi: ustunning oxirgi ikki raqami uchun ham shu “burchak” hiylasi ishlaydi. Qator usuli bilan qiynalsangiz, shuni sinab ko‘ring.'],
['Spiral usuli','Tashqi halqani (yuqori qator, o‘ng ustun, pastki qator, chap ustun) aylanib yig‘ing, so‘ng ichkaridagi kichikroq maydon bilan takrorlang. 5×5 va 6×6 da qulay, chunki maydon asta-sekin kichrayadi va tayyor raqamlar yo‘lda tushmaydi.'],
['Blok usuli','Maydonni 2×2 yoki 3×3 bloklarga bo‘lib, har birini alohida yig‘ing. Oxirida qolgan kichik maydon (odatda 3×3) ni qisqa kombinatsiyalar bilan yeching. Katta maydonlarda reja tuzishni osonlashtiradi.'],
['Eng kam yurish strategiyasi','Har yurishdan oldin raqamlarning o‘z joyidan masofasini (Manhattan) qisqartirishga harakat qiling. Bir-birini to‘sib turgan juft raqamlarni (Linear Conflict) avval hal qiling. “🤖 AI” tugmasi eng qisqa yechim uzunligini ko‘rsatadi. Solishtirib o‘rganing.']];
$('#learn').innerHTML=LEARN.map(x=>`<div class="card"><h3>${x[0]}</h3><p>${x[1]}</p></div>`).join('');
$$('nav button').forEach(x=>x.onclick=()=>{$$('nav button').forEach(y=>y.classList.toggle('on',y===x));$$('.tab').forEach(s=>s.hidden=s.id!==x.dataset.t);if(x.dataset.t==='stats')renderStats()});
$$('.modes button').forEach(x=>x.onclick=()=>{$$('.modes button').forEach(y=>y.classList.toggle('on',y===x));newGame(+x.dataset.n)});
Object.entries({nw:()=>newGame(),rs:restart,pz:pause,un:undo,ht:hint,ai:ai,au:play}).forEach(([i,f])=>$('#'+i).onclick=f);
document.onkeydown=e=>{const z=b.indexOf(0),n=N,m={ArrowLeft:z%n<n-1?z+1:-1,ArrowRight:z%n>0?z-1:-1,ArrowUp:z+n<n*n?z+n:-1,ArrowDown:z-n>=0?z-n:-1}[e.key];if(m>=0){e.preventDefault();act(m)}};
const th=localStorage.p15th||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');document.documentElement.dataset.th=th;
$('#theme').onclick=()=>{const t=document.documentElement.dataset.th==='dark'?'light':'dark';document.documentElement.dataset.th=t;try{localStorage.p15th=t}catch(e){}};
setInterval(()=>{if(started&&!paused&&!won){sec++;upd()}},1000);
newGame(4);
