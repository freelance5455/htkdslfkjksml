# Nöbet Takip PWA

Bu klasör, uygulamanın web sunucusunda barındırılabilen ve uygun Android tarayıcılarda ana ekrana eklenebilen PWA paketidir.

1. Klasördeki dosyaları HTTPS destekleyen bir web sunucusuna yükleyin.
2. Siteyi Android Chrome'da açın ve menüden **Ana ekrana ekle / Uygulamayı yükle** seçeneğini kullanın.
3. Service worker ana HTML ve yerel statik dosyaları önbelleğe alır.

Not: Uygulamanın HTML içindeki harici PeerJS betiği ve çevrimiçi veritabanı işlemleri internet gerektirir. Önbellek, bu sunucu özelliklerini çevrimdışı hale getirmez.
