PURUSHOTTAM Official App — Android Studio Project

This version has a polished mobile UI, the supplied PURUSHOTTAM logo as the launcher/app icon, a startup splash, Instagram action, About dialog, and portrait layout.

To build:
1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Select Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/.
