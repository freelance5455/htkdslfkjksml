# Aurora AI v6.0
Projet optimisé avec séparation des canaux API 1 (Texte), API 2 (Voix), et API 3 (Images Dark Anime).