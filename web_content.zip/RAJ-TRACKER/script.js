const $ = id => document.getElementById(id);
const KEY = 'rajtracker_v1_data';
const AUTH = 'rajtracker_v1_auth';
const DEFAULTS = {username:'raj',password:'1234',target:2000};
let db = loadDB();

function loadDB(){try{return JSON.parse(localStorage.getItem(KEY)) || {entries:[],expenses:[],settings:DEFAULTS}}catch(e){return {entries:[],expenses:[],settings:DEFAULTS}}}
function saveDB(){localStorage.setItem(KEY,JSON.stringify(db))}
function money(n){return '₹'+Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2})}
function num(id){return Number($(id).value)||0}
function today(){return new Date().toISOString().slice(0,10)}
function monthKey(d){return (d||'').slice(0,7)}
function sum(arr,fn){return arr.reduce((a,x)=>a+fn(x),0)}
function escapeHTML(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function distance(e){return Math.max(0,(Number(e.endKm)||0)-(Number(e.startKm)||0))}
function entryNet(e){return Number(e.gross||0)-Number(e.petrol||0)}
function paidExpenses(list){return sum(list.filter(x=>x.status==='Paid'),x=>Number(x.amount)||0)}
function init(){
  $('loginUser').value=db.settings.username||'raj';
  $('entryDate').value=today();$('expenseDate').value=today();$('reportMonth').value=monthKey(today());
  $('dailyTarget').value=db.settings.target||2000;
  $('todayLabel').textContent=new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
  if(localStorage.getItem(AUTH)==='yes') showApp();
  bind(); renderAll();
}
function bind(){
  $('loginForm').addEventListener('submit',e=>{e.preventDefault();if($('loginUser').value===db.settings.username && $('loginPass').value===db.settings.password){localStorage.setItem(AUTH,'yes');$('loginError').textContent='';showApp()}else $('loginError').textContent='Incorrect username or password.'});
  $('logoutBtn').onclick=()=>{localStorage.removeItem(AUTH);$('app').classList.add('hidden');$('loginScreen').classList.remove('hidden')};
  document.querySelectorAll('.nav-btn').forEach(b=>b.onclick=()=>go(b.dataset.page));
  document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));
  ['gross','petrol','startKm','endKm'].forEach(id=>$(id).addEventListener('input',updatePreview));
  $('dailyForm').onsubmit=saveEntry;$('resetDaily').onclick=resetDaily;
  $('expenseForm').onsubmit=saveExpense;$('resetExpense').onclick=resetExpense;
  $('reportMonth').onchange=renderReports;$('exportBtn').onclick=exportCSV;
  $('settingsForm').onsubmit=saveSettings;$('clearDataBtn').onclick=clearData;
}
function showApp(){$('loginScreen').classList.add('hidden');$('app').classList.remove('hidden');renderAll()}
function go(page){
  document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));
  $(page+'Page').classList.remove('hidden');
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  $('pageTitle').textContent=page[0].toUpperCase()+page.slice(1);
  if(page==='reports')renderReports();if(page==='expenses')renderExpenses();if(page==='daily')renderEntries();
}
function updatePreview(){$('distancePreview').textContent=distance({startKm:num('startKm'),endKm:num('endKm')})+' km';$('netPreview').textContent=money(num('gross')-num('petrol'))}
function saveEntry(e){
  e.preventDefault();const id=$('entryId').value||String(Date.now());
  const item={id,date:$('entryDate').value,gross:num('gross'),petrol:num('petrol'),orders:num('orders'),startKm:num('startKm'),endKm:num('endKm'),hours:num('hours'),shifts:num('shifts'),notes:$('notes').value.trim()};
  if(item.endKm && item.startKm && item.endKm<item.startKm){alert('Ending KM cannot be less than starting KM.');return}
  const i=db.entries.findIndex(x=>x.id===id);if(i>=0)db.entries[i]=item;else db.entries.push(item);
  db.entries.sort((a,b)=>b.date.localeCompare(a.date));saveDB();resetDaily();renderAll();alert('Daily entry saved.');
}
function resetDaily(){$('dailyForm').reset();$('entryId').value='';$('entryDate').value=today();$('entryHeading').textContent='Add daily entry';$('shifts').value='1';updatePreview()}
function editEntry(id){const e=db.entries.find(x=>x.id===id);if(!e)return;go('daily');$('entryId').value=e.id;$('entryDate').value=e.date;$('gross').value=e.gross;$('petrol').value=e.petrol;$('orders').value=e.orders;$('startKm').value=e.startKm;$('endKm').value=e.endKm;$('hours').value=e.hours;$('shifts').value=e.shifts;$('notes').value=e.notes;$('entryHeading').textContent='Edit daily entry';updatePreview();window.scrollTo(0,0)}
function deleteEntry(id){if(confirm('Delete this daily entry?')){db.entries=db.entries.filter(x=>x.id!==id);saveDB();renderAll()}}
function saveExpense(e){
  e.preventDefault();const id=$('expenseId').value||String(Date.now());
  const item={id,date:$('expenseDate').value,category:$('expenseCategory').value,amount:num('expenseAmount'),status:$('expenseStatus').value,note:$('expenseNote').value.trim()};
  const i=db.expenses.findIndex(x=>x.id===id);if(i>=0)db.expenses[i]=item;else db.expenses.push(item);
  db.expenses.sort((a,b)=>b.date.localeCompare(a.date));saveDB();resetExpense();renderAll();alert('Expense saved.');
}
function resetExpense(){$('expenseForm').reset();$('expenseId').value='';$('expenseDate').value=today();$('expenseHeading').textContent='Add an expense'}
function editExpense(id){const x=db.expenses.find(x=>x.id===id);if(!x)return;$('expenseId').value=x.id;$('expenseDate').value=x.date;$('expenseCategory').value=x.category;$('expenseAmount').value=x.amount;$('expenseStatus').value=x.status;$('expenseNote').value=x.note;$('expenseHeading').textContent='Edit expense';window.scrollTo(0,0)}
function deleteExpense(id){if(confirm('Delete this expense?')){db.expenses=db.expenses.filter(x=>x.id!==id);saveDB();renderAll()}}
function entryRows(list){
 if(!list.length)return '<div class="empty">No daily entries yet.</div>';
 return `<table><thead><tr><th>Date</th><th>Gross</th><th>Petrol</th><th>Net</th><th>Orders</th><th>KM</th><th>Actions</th></tr></thead><tbody>${list.map(e=>`<tr><td>${escapeHTML(e.date)}</td><td>${money(e.gross)}</td><td>${money(e.petrol)}</td><td>${money(entryNet(e))}</td><td>${e.orders||0}</td><td>${distance(e)}</td><td><div class="table-actions"><button class="mini-btn" onclick="editEntry('${e.id}')">Edit</button><button class="mini-btn del" onclick="deleteEntry('${e.id}')">Delete</button></div></td></tr>`).join('')}</tbody></table>`;
}
function expenseRows(list){
 if(!list.length)return '<div class="empty">No expenses recorded yet.</div>';
 return `<table><thead><tr><th>Date</th><th>Category</th><th>Amount</th><th>Status</th><th>Details</th><th>Actions</th></tr></thead><tbody>${list.map(x=>`<tr><td>${escapeHTML(x.date)}</td><td>${escapeHTML(x.category)}</td><td>${money(x.amount)}</td><td>${escapeHTML(x.status)}</td><td>${escapeHTML(x.note||'-')}</td><td><div class="table-actions"><button class="mini-btn" onclick="editExpense('${x.id}')">Edit</button><button class="mini-btn del" onclick="deleteExpense('${x.id}')">Delete</button></div></td></tr>`).join('')}</tbody></table>`;
}
function renderEntries(){$('allEntries').innerHTML=entryRows(db.entries)}
function renderExpenses(){
 $('expenseTable').innerHTML=expenseRows(db.expenses);
 $('allExpenseTotal').textContent=money(sum(db.expenses,x=>Number(x.amount)||0));
 $('paidTotal').textContent=money(paidExpenses(db.expenses));
 $('pendingTotal').textContent=money(sum(db.expenses.filter(x=>x.status==='Pending'),x=>Number(x.amount)||0));
}
function renderDashboard(){
 const t=db.entries.filter(e=>e.date===today()),m=monthKey(today()),me=db.entries.filter(e=>monthKey(e.date)===m),mx=db.expenses.filter(x=>monthKey(x.date)===m);
 const gross=sum(t,e=>e.gross),petrol=sum(t,e=>e.petrol),target=Number(db.settings.target)||2000;
 $('todayGross').textContent=money(gross);$('todayPetrol').textContent=money(petrol);$('todayNet').textContent=money(gross-petrol);
 $('monthNet').textContent=money(sum(me,entryNet));$('todayOrders').textContent=sum(t,e=>e.orders);
 $('todayKm').textContent=sum(t,distance)+' km';$('todayHours').textContent=sum(t,e=>e.hours)+' hrs';
 $('targetText').textContent=money(gross)+' / '+money(target);$('targetBar').style.width=Math.min(100,gross/target*100)+'%';
 $('monthGross').textContent=money(sum(me,e=>e.gross));$('monthPetrol').textContent=money(sum(me,e=>e.petrol));
 $('monthExpenses').textContent=money(sum(mx.filter(x=>x.status==='Paid'),x=>x.amount));
 $('monthBalance').textContent=money(sum(me,e=>e.gross)-sum(me,e=>e.petrol)-paidExpenses(mx));
 $('recentEntries').innerHTML=entryRows(db.entries.slice(0,5));
}
function renderReports(){
 const m=$('reportMonth').value||monthKey(today()),es=db.entries.filter(e=>monthKey(e.date)===m),xs=db.expenses.filter(x=>monthKey(x.date)===m);
 const g=sum(es,e=>e.gross),p=sum(es,e=>e.petrol),ex=paidExpenses(xs),days=new Set(es.map(e=>e.date)).size;
 $('rGross').textContent=money(g);$('rPetrol').textContent=money(p);$('rNet').textContent=money(g-p);$('rExpenses').textContent=money(ex);
 $('rOrders').textContent=sum(es,e=>e.orders);$('rKm').textContent=sum(es,distance)+' km';$('rDays').textContent=days;$('rAverage').textContent=money(days?g/days:0);$('rBalance').textContent=money(g-p-ex);
 const weeks={};es.forEach(e=>{const day=Number(e.date.slice(8,10)),w=Math.ceil(day/7);(weeks[w]??=[]).push(e)});
 const keys=Object.keys(weeks).sort((a,b)=>a-b);
 $('weeklyTable').innerHTML=keys.length?`<table><thead><tr><th>Week</th><th>Gross</th><th>Petrol</th><th>Net</th><th>Orders</th><th>KM</th></tr></thead><tbody>${keys.map(w=>{let a=weeks[w];return `<tr><td>Week ${w}</td><td>${money(sum(a,e=>e.gross))}</td><td>${money(sum(a,e=>e.petrol))}</td><td>${money(sum(a,entryNet))}</td><td>${sum(a,e=>e.orders)}</td><td>${sum(a,distance)}</td></tr>`}).join('')}</tbody></table>`:'<div class="empty">No data for this month.</div>';
}
function renderAll(){renderDashboard();renderEntries();renderExpenses();renderReports()}
function saveSettings(e){e.preventDefault();const u=$('newUsername').value.trim(),p=$('newPassword').value;db.settings.target=num('dailyTarget')||2000;if(u)db.settings.username=u;if(p)db.settings.password=p;saveDB();$('newUsername').value='';$('newPassword').value='';alert('Settings saved. Use your new login next time.');renderAll()}
function exportCSV(){
 const rows=[['TYPE','DATE','CATEGORY','GROSS','PETROL','NET','ORDERS','START KM','END KM','DISTANCE','HOURS','AMOUNT','STATUS','NOTE']];
 db.entries.forEach(e=>rows.push(['Daily entry',e.date,'',e.gross,e.petrol,entryNet(e),e.orders,e.startKm,e.endKm,distance(e),e.hours,'','','']));
 db.expenses.forEach(x=>rows.push(['Expense',x.date,x.category,'','','','','','','','',x.amount,x.status,x.note]));
 const csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n');
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='raj-tracker-backup.csv';a.click();URL.revokeObjectURL(url);
}
function clearData(){if(confirm('This permanently deletes all entries, expenses and settings from this browser. Continue?')){localStorage.removeItem(KEY);localStorage.removeItem(AUTH);db={entries:[],expenses:[],settings:DEFAULTS};location.reload()}}
init();
