import { gradeById, kindsFor, countFor, examsAllowed } from "./curriculum.js";
import { bestAttempt, doneCount, studentOverview, isGradeComplete } from "./progress.js";

/**
 * Pick the most useful next action for a learner.
 * Returns { type, subjectId?, kind?, index?, label, reason }
 */
export function recommendNext(attempts, student, settings = {}) {
  const grade = gradeById(student.grade);
  if (!grade) return { type: "none", label: "No grade set", reason: "" };

  if (student.grade === "preschool") {
    return {
      type: "watch",
      label: "Watch time",
      reason: "Pre School is video-only. Keep sessions short and calm.",
    };
  }

  if (isGradeComplete(attempts, student)) {
    return {
      type: "complete",
      label: student.grade === "12" ? "View Matric diploma" : "View certificate",
      reason: "This grade library is complete enough to recognise.",
    };
  }

  const subjects = grade.subjects.filter((s) => student.subjects.includes(s.id) && s.mode === "learn");
  if (subjects.length === 0) {
    return { type: "plan", label: "Edit subject list", reason: "Choose subjects so daily work can start." };
  }

  // Prefer incomplete assignment with lowest progress subject
  let best = null;
  for (const subject of subjects) {
    for (const kind of kindsFor(student.grade)) {
      if (kind === "exam" && settings.currentTerm == null) continue;
      const total = countFor(kind);
      for (let index = 0; index < Math.min(total, 20); index++) {
        const hit = bestAttempt(attempts, student.id, subject.id, kind, index);
        if (hit && hit.score / hit.total >= 0.6) continue;
        const subjectDone = kindsFor(student.grade).reduce(
          (n, k) => n + doneCount(attempts, student.id, subject.id, k),
          0,
        );
        const score = subjectDone * 10 + (kind === "assignment" ? 0 : kind === "test" ? 1 : 2) + index * 0.01;
        if (!best || score < best.score) {
          best = {
            score,
            type: "play",
            subjectId: subject.id,
            kind,
            index,
            label: `${subject.name} · ${kind} ${index + 1}`,
            reason:
              kind === "exam"
                ? `End-of-term exam practice for Term ${settings.currentTerm || "—"}`
                : subjectDone === 0
                  ? "A fresh start in this subject"
                  : "Continue where this subject is lightest",
          };
        }
        break;
      }
    }
  }

  if (best) {
    const { score, ...rest } = best;
    return rest;
  }

  return {
    type: "report",
    label: "Open progress report",
    reason: "Most early items are done — review the report or open a later page of the library.",
  };
}

export function familyAnalytics(attempts, students) {
  if (!students.length) {
    return {
      learners: 0,
      marked: 0,
      avgPct: 0,
      strongest: null,
      weakest: null,
      perStudent: [],
    };
  }

  const perStudent = students.map((s) => {
    const o = studentOverview(attempts, s);
    return {
      id: s.id,
      name: s.name,
      grade: s.grade,
      pct: o.pct,
      done: o.done,
      total: o.total,
      bySubject: o.bySubject,
    };
  });

  const marked = attempts.length;
  const avgPct = Math.round(perStudent.reduce((n, s) => n + s.pct, 0) / perStudent.length);

  const subjectTotals = new Map();
  for (const s of perStudent) {
    for (const row of s.bySubject) {
      const key = row.subject.name;
      const cur = subjectTotals.get(key) || { name: key, pctSum: 0, n: 0 };
      cur.pctSum += row.pct;
      cur.n += 1;
      subjectTotals.set(key, cur);
    }
  }
  const subjectAvgs = [...subjectTotals.values()]
    .map((x) => ({ name: x.name, pct: Math.round(x.pctSum / x.n) }))
    .sort((a, b) => b.pct - a.pct);

  return {
    learners: students.length,
    marked,
    avgPct,
    strongest: subjectAvgs[0] || null,
    weakest: subjectAvgs.length ? subjectAvgs[subjectAvgs.length - 1] : null,
    perStudent: perStudent.sort((a, b) => a.pct - b.pct),
  };
}
