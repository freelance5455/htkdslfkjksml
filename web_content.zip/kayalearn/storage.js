/** Local-only persistence for KayaLearn */
const KEY = "kayalearn.v2";
const LEGACY_KEY = "kayalearn.v1";

const defaultState = () => ({
  parent: null, // { name, createdAt }
  settings: {
    termWeeks: 10, // parent-chosen term length
    currentTerm: 1, // 1–4
    yearLabel: new Date().getFullYear().toString(),
    lang: "en",
    yearPlan: "",
    lowData: false,
  },
  students: [],
  attempts: [],
  certificates: [], // { id, studentId, type: 'grade'|'matric', gradeId, title, issuedAt }
  badges: [], // { id, studentId, code, label, earnedAt }
});

export function loadState() {
  try {
    let raw = localStorage.getItem(KEY);
    if (!raw) {
      const legacy = localStorage.getItem(LEGACY_KEY);
      if (legacy) {
        const parsed = JSON.parse(legacy);
        const migrated = {
          ...defaultState(),
          parent: parsed.parent ?? null,
          students: Array.isArray(parsed.students) ? parsed.students : [],
          attempts: Array.isArray(parsed.attempts) ? parsed.attempts : [],
        };
        saveState(migrated);
        return migrated;
      }
      return defaultState();
    }
    const parsed = JSON.parse(raw);
    return {
      parent: parsed.parent ?? null,
      settings: {
        ...defaultState().settings,
        ...(parsed.settings || {}),
        lang: parsed.settings?.lang === "af" ? "af" : parsed.settings?.lang === "en" ? "en" : defaultState().settings.lang,
        yearPlan: typeof parsed.settings?.yearPlan === "string" ? parsed.settings.yearPlan : "",
        lowData: Boolean(parsed.settings?.lowData),
      },
      students: Array.isArray(parsed.students) ? parsed.students : [],
      attempts: Array.isArray(parsed.attempts) ? parsed.attempts : [],
      certificates: Array.isArray(parsed.certificates) ? parsed.certificates : [],
      badges: Array.isArray(parsed.badges) ? parsed.badges : [],
    };
  } catch {
    return defaultState();
  }
}

export function saveState(state) {
  localStorage.setItem(KEY, JSON.stringify(state));
}

export function uid(prefix) {
  return `${prefix}_${crypto.randomUUID()}`;
}
