# KayaLearn — Phase 4

Free South African homeschooling app (no login).

## Phase 4

- **Resource hub** — legal/registration pointers, materials, support, wellbeing
- **This week** — simple weekly rhythm + recommended next step
- **Printable pack** — paper workbook from incomplete practice (print / PDF)
- **Low-data mode** — hide video embeds; lighter screens

Builds on Phases 1–3 (profiles, full library, terms, reports, certificates, analytics, bilingual UI, offline shell).

## Run

```bash
cd kayalearn
python3 -m http.server 8080
```
