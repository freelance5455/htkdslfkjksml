# KayaLearn — Phase 8

## Term-based library (per subject, per grade)
| | Term 1 | Term 2 | Term 3 | Term 4 | Year |
|--|--|--|--|--|--|
| Assignments | 91 | 91 | 91 | 92 | **365** |
| Tests | 12 | 12 | 12 | 14 | **50** |
| Exams (Gr 4+) | 1 | 1 | 1 | 1 | **4** |

Change the active term under **Term settings** to work through that term’s set.

## Chemistry
Added on **Grades 1–Matric** (not Pre School, RR, or R), with age-adapted questions.

## Age adaptation
Question difficulty scales by grade band (RR/R → Matric), including math ranges and chemistry intros.

## Pre School
More Bible, song and learning videos (32 in the library).

## Run
```bash
cd kayalearn
python3 -m http.server 8080
```
