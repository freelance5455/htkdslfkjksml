# KayaLearn — Phase 5

## Phase 5 focus
- Fixed preschool **in-app YouTube playback** (better embed + playsinline)
- Expanded library to **24** gentle Bible, song and learning videos
- Category filters: All · Bible · Songs · Learning
- **Open on YouTube** fallback if embed is blocked
- Clear note: run via local server (not file://); turn off Low-data mode to watch

## Run
```bash
cd kayalearn
python3 -m http.server 8080
```
Open http://127.0.0.1:8080 — do not open index.html by double-click.
