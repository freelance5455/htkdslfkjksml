import { gradeById, kindsFor, countFor, examsAllowed, nextGradeId } from "./curriculum.js";
import { uid } from "./storage.js";

export function bestAttempt(attempts, studentId, subjectId, kind, itemIndex) {
  return attempts
    .filter(
      (a) =>
        a.studentId === studentId &&
        a.subjectId === subjectId &&
        a.kind === kind &&
        a.itemIndex === itemIndex,
    )
    .sort((a, b) => b.score / b.total - a.score / a.total)[0];
}

export function doneCount(attempts, studentId, subjectId, kind) {
  const total = countFor(kind);
  let n = 0;
  for (let i = 0; i < total; i++) {
    const hit = bestAttempt(attempts, studentId, subjectId, kind, i);
    if (hit && hit.score / hit.total >= 0.6) n += 1;
  }
  return n;
}

export function subjectProgress(attempts, student, subject) {
  if (subject.mode === "video") {
    return { kind: "video", label: "Watch only", pct: 100 };
  }
  const kinds = kindsFor(student.grade);
  let done = 0;
  let total = 0;
  for (const kind of kinds) {
    const c = countFor(kind);
    total += c;
    done += doneCount(attempts, student.id, subject.id, kind);
  }
  return {
    kind: "learn",
    done,
    total,
    pct: total ? Math.round((done / total) * 100) : 0,
  };
}

export function studentOverview(attempts, student) {
  const grade = gradeById(student.grade);
  const subjects = (grade?.subjects || []).filter((s) => student.subjects.includes(s.id) && s.mode === "learn");
  let done = 0;
  let total = 0;
  const bySubject = subjects.map((s) => {
    const p = subjectProgress(attempts, student, s);
    done += p.done || 0;
    total += p.total || 0;
    return { subject: s, ...p };
  });
  const recent = attempts
    .filter((a) => a.studentId === student.id)
    .slice()
    .sort((a, b) => String(b.at).localeCompare(String(a.at)))
    .slice(0, 12);
  return {
    done,
    total,
    pct: total ? Math.round((done / total) * 100) : 0,
    bySubject,
    recent,
    examReady: examsAllowed(student.grade),
  };
}

/** Grade completion: ≥70% of selected learn subjects at ≥50% each, or overall ≥60%. */
export function isGradeComplete(attempts, student) {
  const overview = studentOverview(attempts, student);
  if (student.grade === "preschool") return true;
  if (overview.total === 0) return false;
  if (overview.pct >= 60) return true;
  const strong = overview.bySubject.filter((s) => s.pct >= 50).length;
  return overview.bySubject.length > 0 && strong / overview.bySubject.length >= 0.7;
}

export function ensureCertificatesAndBadges(state, studentId) {
  const student = state.students.find((s) => s.id === studentId);
  if (!student) return state;

  const now = new Date().toISOString();
  let changed = false;

  if (isGradeComplete(state.attempts, student)) {
    const hasCert = state.certificates.some(
      (c) => c.studentId === studentId && c.type === "grade" && c.gradeId === student.grade,
    );
    if (!hasCert) {
      const grade = gradeById(student.grade);
      state.certificates.push({
        id: uid("cert"),
        studentId,
        type: student.grade === "12" ? "matric" : "grade",
        gradeId: student.grade,
        title:
          student.grade === "12"
            ? `Matric diploma — ${student.name}`
            : `Certificate of completion — ${grade?.label || student.grade}`,
        issuedAt: now,
      });
      changed = true;
    }
  }

  const overview = studentOverview(state.attempts, student);
  const badgeDefs = [
    { code: "first-mark", label: "First mark", test: () => overview.done >= 1 },
    { code: "ten-strong", label: "10 pieces done", test: () => overview.done >= 10 },
    { code: "half-way", label: "Halfway through the grade", test: () => overview.pct >= 50 },
    { code: "exam-ready", label: "Exam pathway open", test: () => examsAllowed(student.grade) && overview.done >= 5 },
    {
      code: "grade-complete",
      label: "Grade complete",
      test: () => isGradeComplete(state.attempts, student),
    },
  ];

  for (const def of badgeDefs) {
    if (!def.test()) continue;
    const has = state.badges.some((b) => b.studentId === studentId && b.code === def.code);
    if (!has) {
      state.badges.push({
        id: uid("badge"),
        studentId,
        code: def.code,
        label: def.label,
        earnedAt: now,
      });
      changed = true;
    }
  }

  return changed;
}

export function reportLines(attempts, student, settings) {
  const overview = studentOverview(attempts, student);
  const grade = gradeById(student.grade);
  const lines = [
    `KayaLearn progress report`,
    `Learner: ${student.name}`,
    `Grade: ${grade?.label || student.grade}`,
    `Age: ${student.age}`,
    `Year: ${settings.yearLabel} · Term ${settings.currentTerm} (${settings.termWeeks} weeks)`,
    `Overall progress: ${overview.done}/${overview.total} (${overview.pct}%)`,
    ``,
    `Subjects`,
  ];
  for (const row of overview.bySubject) {
    lines.push(`- ${row.subject.name}: ${row.done}/${row.total} (${row.pct}%)`);
  }
  lines.push(``, `Recent results`);
  if (overview.recent.length === 0) lines.push(`- No attempts yet`);
  for (const a of overview.recent) {
    const sub = grade?.subjects.find((s) => s.id === a.subjectId);
    lines.push(
      `- ${sub?.name || a.subjectId} · ${a.kind} ${a.itemIndex + 1}: ${a.score}/${a.total} (${Math.round((a.score / a.total) * 100)}%)`,
    );
  }
  return lines.join("\n");
}
