function slug(name) {
  return name
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function learn(...names) {
  const seen = new Set();
  const out = [];
  for (const name of names) {
    const id = slug(name);
    if (seen.has(id)) continue;
    seen.add(id);
    out.push({ id, name, mode: "learn" });
  }
  return out;
}


const CAPS_FOUNDATION = ["Home Language", "First Additional Language", "Mathematics", "Life Skills"];
const CAPS_INTERMEDIATE = [
  "Home Language",
  "First Additional Language",
  "Mathematics",
  "Natural Sciences and Technology",
  "Social Sciences",
  "Life Orientation",
  "Creative Arts",
];
const CAPS_SENIOR = [
  "Home Language",
  "First Additional Language",
  "Mathematics",
  "Natural Sciences",
  "Social Sciences",
  "Technology",
  "Economic and Management Sciences",
  "Life Orientation",
  "Creative Arts",
];
const CAPS_FET = [
  "Home Language",
  "First Additional Language",
  "Mathematics",
  "Mathematical Literacy",
  "Life Orientation",
  "Physical Sciences",
  "Life Sciences",
  "Geography",
  "History",
  "Accounting",
  "Business Studies",
  "Economics",
  "Tourism",
  "Computer Applications Technology",
  "Information Technology",
  "Visual Arts",
  "Music",
];

/** Shared pool from Grades 4–9 + 10–Matric — applied to Grades 1–12 (adapted by age in assessments). */
const SHARED_UPPER = [
  "Life Orientation",
  "Music",
  "Bible Study",
  "Sign Language",
  "Geography",
  "History",
  "Cursive Writing",
  "Anatomy",
  "Mandarin",
  "Russian",
  "Zulu",
  "Physical Education",
  "Insect Studies",
  "Abuse Awareness",
  "Disease and Infection Studies",
  "Coding and Robotics",
  "Computer Basics",
  "Entrepreneurship",
  "Afrikaans Reading",
  "English Reading",
  "Afrikaans Spelling",
  "English Spelling",
  "Crafts",
  "Sewing",
  "Knitting",
  "Crocheting",
  "Woodworking",
  "Reptile Studies",
  "Chemistry",
  "Biology",
  "Cooking",
  "Baking",
  "Logical Reasoning",
  "Web Development Basics",
  "Office Productivity",
  "Cyber Security",
  "Game Development Basics",
  "Accounting Basics",
  "Management Basics",
  "Politics Basics",
  "Farming Basics",
  "Home Economics",
  "Welding",
  "Drawing and Painting",
  "First Aid Basics",
  "Barbering Basics",
  "Physics",
  "Sociology",
  "Anthropology",
];

const LIFE_SAFETY = [
  "Health and Hygiene",
  "Outdoor and Indoor Safety",
  "Automotive Repair",
];

export const GRADES = [
  {
    id: "preschool",
    label: "Pre School",
    ages: "6 months – 2 years",
    subjects: [{ id: "watch", name: "Watch time", mode: "video" }],
  },
  {
    id: "rr",
    label: "Grade RR",
    ages: "2 – 4 years",
    subjects: learn(
      "Afrikaans",
      "English",
      "Mathematics",
      "Tracing",
      "Drawing",
      "Coloring",
      "Life Skills",
      ...LIFE_SAFETY,
    ),
  },
  {
    id: "r",
    label: "Grade R",
    ages: "about 5 years",
    subjects: learn(
      "Bible Study",
      "Mathematics",
      "Music",
      "Coloring",
      "Drawing",
      "Painting",
      "Life Skills",
      "Insect Safety Studies",
      ...CAPS_FOUNDATION,
      "Crafts",
      ...LIFE_SAFETY,
    ),
  },
];

// Grades 1–12: full shared pool + CAPS band + life/safety (already in SHARED via Anthropology; LIFE_SAFETY added)
for (const id of ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]) {
  const n = Number(id);
  let caps = CAPS_FOUNDATION;
  if (n >= 4 && n <= 6) caps = CAPS_INTERMEDIATE;
  else if (n >= 7 && n <= 9) caps = CAPS_SENIOR;
  else if (n >= 10) caps = CAPS_FET;
  else if (n >= 1) caps = CAPS_FOUNDATION;

  const early = n <= 3
    ? ["Sign Language", "Natural Science", "Social Science", "Art", "Spelling Afrikaans", "Reading Afrikaans", "Spelling English", "Reading English"]
    : [];

  GRADES.push({
    id,
    label: id === "12" ? "Grade 12 (Matric)" : `Grade ${id}`,
    ages: n === 1 ? "6 – 7 years" : `${n + 5} – ${n + 6} years`,
    subjects: learn(...SHARED_UPPER, ...early, ...caps, ...LIFE_SAFETY, "Chemistry"),
  });
}

export function gradeById(id) {
  return GRADES.find((g) => g.id === id);
}

export function subjectById(gradeId, subjectId) {
  return gradeById(gradeId)?.subjects.find((s) => s.id === subjectId);
}

export function examsAllowed(gradeId) {
  const n = Number(gradeId);
  return Number.isFinite(n) && n >= 4;
}

/** Phase 2 full content library targets. */
/** Year totals — split across four terms. */
export const TARGETS = {
  assignment: 365,
  test: 50,
  exam: 4,
};

/** Term 1–3: 91 assignments; Term 4: 92. Term 1–3: 12 tests; Term 4: 14. */
export const TERM_COUNTS = {
  assignment: [91, 91, 91, 92],
  test: [12, 12, 12, 14],
  exam: [1, 1, 1, 1],
};

export function termIndex(term) {
  const t = Number(term) || 1;
  return Math.min(3, Math.max(0, t - 1));
}

/** Inclusive start/end item indices for a term (0-based). */
export function termItemRange(kind, term) {
  const counts = TERM_COUNTS[kind] || [TARGETS[kind]];
  const ti = termIndex(term);
  let start = 0;
  for (let i = 0; i < ti; i++) start += counts[i];
  const count = counts[ti];
  return { start, end: start + count - 1, count };
}

export function countForTerm(kind, term) {
  if (term == null || term === "" || kind === "exam") {
    if (kind === "exam") return TARGETS.exam;
    return TARGETS[kind];
  }
  return TERM_COUNTS[kind][termIndex(term)];
}
;

export const GRADE_ORDER = [
  "preschool",
  "rr",
  "r",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "11",
  "12",
];

export function nextGradeId(gradeId) {
  const i = GRADE_ORDER.indexOf(gradeId);
  if (i < 0 || i >= GRADE_ORDER.length - 1) return null;
  return GRADE_ORDER[i + 1];
}


export function kindsFor(gradeId) {
  return examsAllowed(gradeId) ? ["assignment", "test", "exam"] : ["assignment", "test"];
}

export function countFor(kind, term) {
  if (term == null || term === undefined) return TARGETS[kind];
  return countForTerm(kind, term);
}


export const VIDEOS = [
  {
    id: "jr-collection",
    title: "Creation and more Bible Jr. stories",
    note: "Saddleback Kids · gentle animated collection",
    category: "bible",
    youtubeId: "j1QfF1JKHVo",
  },
  {
    id: "creation-toddler",
    title: "Creation for toddlers",
    note: "Short Bible story · Saddleback Kids",
    category: "bible",
    youtubeId: "MAYULgEElpg",
  },
  {
    id: "creation-song",
    title: "Creation song",
    note: "Toddler sing-along",
    category: "songs",
    youtubeId: "CxdNCSh-JVg",
  },
  {
    id: "creation-genesis",
    title: "God makes everything",
    note: "Genesis creation story",
    category: "bible",
    youtubeId: "teu7BCZTgDs",
  },
  {
    id: "noah",
    title: "Noah",
    note: "Simple ark story",
    category: "bible",
    youtubeId: "Wbfp7fzhj4Y",
  },
  {
    id: "noah-ark",
    title: "Noah's ark",
    note: "Animals and rain · calm telling",
    category: "bible",
    youtubeId: "qzYjy6lhRag",
  },
  {
    id: "daniel",
    title: "Daniel for toddlers",
    note: "Lions' den · short",
    category: "bible",
    youtubeId: "RnookANtKrc",
  },
  {
    id: "zacchaeus",
    title: "Zacchaeus",
    note: "Little man in a tree",
    category: "bible",
    youtubeId: "qNqjKrlQBDU",
  },
  {
    id: "lost-sheep",
    title: "The lost sheep",
    note: "Gentle parable for little ones",
    category: "bible",
    youtubeId: "r4hkHg6XnDA",
  },
  {
    id: "good-samaritan",
    title: "The good Samaritan",
    note: "Be kind · toddler version",
    category: "bible",
    youtubeId: "CrVmbIr0zrg",
  },
  {
    id: "peter-water",
    title: "Peter walks on water",
    note: "Trust · short story",
    category: "bible",
    youtubeId: "DeciV3PQAOc",
  },
  {
    id: "feeds-5000",
    title: "Jesus feeds the 5,000",
    note: "Loaves and fish",
    category: "bible",
    youtubeId: "QXOPfPFr2U8",
  },
  {
    id: "calms-storm",
    title: "Jesus calms the storm",
    note: "Peace in the wind",
    category: "bible",
    youtubeId: "uYLHqdSO9OY",
  },
  {
    id: "jonah",
    title: "Jonah and the fish",
    note: "Classic short story",
    category: "bible",
    youtubeId: "WOSadLyqshg",
  },
  {
    id: "baptism",
    title: "Baptism of Jesus",
    note: "Toddler Bible story",
    category: "bible",
    youtubeId: "MYSHdpJ7loU",
  },
  {
    id: "easter-toddler",
    title: "Easter for toddlers",
    note: "Soft Easter story",
    category: "bible",
    youtubeId: "zQeU6gZzHT4",
  },
  {
    id: "armor",
    title: "Armor of God",
    note: "Toddler Bible story",
    category: "bible",
    youtubeId: "3JzPkPeaWAM",
  },
  {
    id: "little-lights-bible",
    title: "Bible stories and Sunday songs",
    note: "Noah, Daniel, David and more · Ms HJ",
    category: "bible",
    youtubeId: "K3BRKqWlHas",
  },
  {
    id: "garden-learning",
    title: "Christian garden learning",
    note: "Story, songs and pretend play",
    category: "learning",
    youtubeId: "JxwS9BevMQ0",
  },
  {
    id: "eleven-stories",
    title: "11 Bible stories and songs",
    note: "David, Noah, Jonah and more",
    category: "bible",
    youtubeId: "zrpzCW5GE0Q",
  },
  {
    id: "worship-35",
    title: "Toddler worship and learning songs",
    note: "ABC, numbers and Jesus songs",
    category: "songs",
    youtubeId: "lmbo3k6Oe1g",
  },
  {
    id: "smiley-learning",
    title: "ABC, counting and Bible stories",
    note: "Christian baby & toddler learning",
    category: "learning",
    youtubeId: "kRu_DUabrBY",
  },
  {
    id: "smiley-40",
    title: "Creation, Noah and more",
    note: "40-minute gentle learning",
    category: "learning",
    youtubeId: "Va2LTo_xJaY",
  },
  {
    id: "baby-bible-songs",
    title: "Baby's first Bible songs",
    note: "Animated sing-along with lyrics",
    category: "songs",
    youtubeId: "zXvZ5mEXdb8",
  },
,
  {
    id: "noah-song",
    title: "Noah song for toddlers",
    note: "Toddler Bible sing-along",
    category: "songs",
    youtubeId: "rvUUo1BSDEc",
  },
  {
    id: "jesus-song",
    title: "Jesus song for toddlers",
    note: "Soft worship sing-along",
    category: "songs",
    youtubeId: "fX3l8VY3qd4",
  },
  {
    id: "joseph-song",
    title: "Joseph song",
    note: "Toddler Bible sing-along",
    category: "songs",
    youtubeId: "AA3YYEFo9jk",
  },
  {
    id: "christmas-song",
    title: "Christmas song for toddlers",
    note: "Gentle Christmas sing-along",
    category: "songs",
    youtubeId: "iPmHNQHRvAI",
  },
  {
    id: "farmer-seeds",
    title: "Farmer and the seeds",
    note: "Parable for toddlers",
    category: "bible",
    youtubeId: "ZSS8huDbriM",
  },
  {
    id: "blind-man",
    title: "Jesus heals a man born blind",
    note: "Short toddler Bible story",
    category: "bible",
    youtubeId: "yOdv5iDpBrQ",
  },
  {
    id: "little-lights-90",
    title: "Long preschool learning mix",
    note: "Songs, colours and Bible moments",
    category: "learning",
    youtubeId: "UC4KCNFyU7E",
  },
  {
    id: "bible-songs-hour",
    title: "Bible songs collection",
    note: "Joyful animated worship songs",
    category: "songs",
    youtubeId: "u8Sz4ci79p8",
  },
];

