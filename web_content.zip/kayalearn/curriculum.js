function slug(name) {
  return name
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function learn(...names) {
  const seen = new Set();
  const out = [];
  for (const name of names) {
    const id = slug(name);
    if (seen.has(id)) continue;
    seen.add(id);
    out.push({ id, name, mode: "learn" });
  }
  return out;
}

const CAPS_FOUNDATION = ["Home Language", "First Additional Language", "Mathematics", "Life Skills"];
const CAPS_INTERMEDIATE = [
  "Home Language",
  "First Additional Language",
  "Mathematics",
  "Natural Sciences and Technology",
  "Social Sciences",
  "Life Orientation",
  "Creative Arts",
];
const CAPS_SENIOR = [
  "Home Language",
  "First Additional Language",
  "Mathematics",
  "Natural Sciences",
  "Social Sciences",
  "Technology",
  "Economic and Management Sciences",
  "Life Orientation",
  "Creative Arts",
];
const CAPS_FET = [
  "Home Language",
  "First Additional Language",
  "Mathematics",
  "Mathematical Literacy",
  "Life Orientation",
  "Physical Sciences",
  "Life Sciences",
  "Geography",
  "History",
  "Accounting",
  "Business Studies",
  "Economics",
  "Tourism",
  "Computer Applications Technology",
  "Information Technology",
  "Visual Arts",
  "Music",
];

const MID = [
  "Life Orientation",
  "Music",
  "Bible Study",
  "Sign Language",
  "Geography",
  "History",
  "Cursive Writing",
  "Anatomy",
  "Mandarin",
  "Russian",
  "Zulu",
  "Physical Education",
  "Insect Studies",
  "Abuse Awareness",
  "Disease and Infection Studies",
  "Coding and Robotics",
  "Computer Basics",
  "Entrepreneurship",
  "Afrikaans Reading",
  "English Reading",
  "Afrikaans Spelling",
  "English Spelling",
  "Crafts",
];

const UPPER = [
  ...MID,
  "Sewing",
  "Knitting",
  "Crocheting",
  "Woodworking",
  "Reptile Studies",
  "Chemistry",
  "Biology",
  "Cooking",
  "Baking",
  "Logical Reasoning",
];

const FET_EXTRA = [
  ...UPPER,
  "Web Development Basics",
  "Office Productivity",
  "Cyber Security",
  "Game Development Basics",
  "Accounting Basics",
  "Management Basics",
  "Politics Basics",
  "Farming Basics",
  "Home Economics",
  "Welding",
  "Drawing and Painting",
  "First Aid Basics",
  "Barbering Basics",
  "Physics",
  "Sociology",
];

export const GRADES = [
  {
    id: "preschool",
    label: "Pre School",
    ages: "6 months – 2 years",
    subjects: [{ id: "watch", name: "Watch time", mode: "video" }],
  },
  {
    id: "rr",
    label: "Grade RR",
    ages: "2 – 4 years",
    subjects: learn("Afrikaans", "English", "Mathematics", "Tracing", "Drawing", "Coloring", "Life Skills"),
  },
  {
    id: "r",
    label: "Grade R",
    ages: "about 5 years",
    subjects: learn(
      "Bible Study",
      "Mathematics",
      "Music",
      "Coloring",
      "Drawing",
      "Painting",
      "Life Skills",
      "Insect Safety Studies",
      ...CAPS_FOUNDATION,
      "Crafts",
    ),
  },
  {
    id: "1",
    label: "Grade 1",
    ages: "6 – 7 years",
    subjects: learn(
      "Sign Language",
      "Natural Science",
      "Social Science",
      "Bible Study",
      "Cursive Writing",
      "Coding and Robotics",
      "Computer Basics",
      "Entrepreneurship",
      "Knitting",
      "Crocheting",
      "Music",
      "Zulu",
      "Mandarin",
      "Russian",
      "Insect Studies",
      "Art",
      "Spelling Afrikaans",
      "Reading Afrikaans",
      "Spelling English",
      "Reading English",
      "Crafts",
      ...CAPS_FOUNDATION,
    ),
  },
];

for (const [id, ages] of [
  ["2", "8 – 9 years"],
  ["3", "9 – 10 years"],
  ["4", "10 – 11 years"],
]) {
  const extra = id === "2" ? [] : ["Logical Reasoning"];
  GRADES.push({
    id,
    label: `Grade ${id}`,
    ages,
    subjects: learn(...MID, ...extra, ...CAPS_INTERMEDIATE),
  });
}

for (const id of ["5", "6", "7", "8", "9"]) {
  const caps = Number(id) <= 6 ? CAPS_INTERMEDIATE : CAPS_SENIOR;
  GRADES.push({
    id,
    label: `Grade ${id}`,
    ages: `${Number(id) + 6} – ${Number(id) + 7} years`,
    subjects: learn(...UPPER, ...caps),
  });
}

for (const id of ["10", "11", "12"]) {
  GRADES.push({
    id,
    label: id === "12" ? "Grade 12 (Matric)" : `Grade ${id}`,
    ages: `${Number(id) + 6} – ${Number(id) + 7} years`,
    subjects: learn(...FET_EXTRA, ...CAPS_FET),
  });
}

export function gradeById(id) {
  return GRADES.find((g) => g.id === id);
}

export function subjectById(gradeId, subjectId) {
  return gradeById(gradeId)?.subjects.find((s) => s.id === subjectId);
}

export function examsAllowed(gradeId) {
  const n = Number(gradeId);
  return Number.isFinite(n) && n >= 4;
}

/** Phase 2 full content library targets. */
export const TARGETS = {
  assignment: 100,
  test: 25,
  exam: 4,
};

export const GRADE_ORDER = [
  "preschool",
  "rr",
  "r",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "11",
  "12",
];

export function nextGradeId(gradeId) {
  const i = GRADE_ORDER.indexOf(gradeId);
  if (i < 0 || i >= GRADE_ORDER.length - 1) return null;
  return GRADE_ORDER[i + 1];
}


export function kindsFor(gradeId) {
  return examsAllowed(gradeId) ? ["assignment", "test", "exam"] : ["assignment", "test"];
}

export function countFor(kind) {
  return TARGETS[kind];
}

export const VIDEOS = [
  {
    id: "creation",
    title: "In the beginning",
    note: "A short, gentle Bible story",
    youtubeId: "meiWTZ1QIaM",
  },
  {
    id: "christmas",
    title: "The first Christmas gift",
    note: "Calm story for little ones",
    youtubeId: "wxX53cWslm0",
  },
  {
    id: "saddleback",
    title: "Creation stories for toddlers",
    note: "Soft colours and simple words",
    youtubeId: "j1QfF1JKHVo",
  },
  {
    id: "songs",
    title: "Christian songs for little ones",
    note: "Gentle sing-along time",
    youtubeId: "eIy1gplg_z4",
  },
];
