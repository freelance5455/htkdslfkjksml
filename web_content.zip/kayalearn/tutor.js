/**
 * On-device AI tutor + voice helper for KayaLearn.
 * No cloud API required — rule-based teaching coach with optional Web Speech.
 */

const TIPS = {
  math: [
    "Count with your fingers or draw dots, then check the number.",
    "Read the question twice. Circle the numbers first.",
    "For subtraction, start with the bigger number.",
    "Estimation helps: is the answer bigger or smaller than 10?",
  ],
  language: [
    "Sound the word out slowly, letter by letter.",
    "Look for a capital letter and a full stop in a sentence.",
    "If you are unsure, choose the word that makes sense in the sentence.",
    "Practice reading the options out loud before you pick.",
  ],
  bible: [
    "Think about kindness, courage, and caring for others in the story.",
    "Who is being helped in this lesson?",
    "A good answer often matches what is fair and loving.",
  ],
  science: [
    "Observe first: what would you see, hear, or measure?",
    "Living things need food, water, air, and a safe place.",
    "Safety first — never taste or touch unknown substances.",
  ],
  people: [
    "Maps, history, and communities are about people and places.",
    "Ask: who, where, when, and why.",
    "Respect for others is part of every good answer.",
  ],
  make: [
    "Plan your steps before you start drawing or making.",
    "Keep your workspace tidy and tools with an adult if needed.",
    "Take your time — neat work is strong work.",
  ],
  safety: [
    "If something feels unsafe, tell a trusted adult straight away.",
    "Wash hands, look before you cross, and keep away from hot or sharp things.",
    "Cars and tools are for learning with adult help — never alone.",
  ],
  tech: [
    "Computers follow clear steps. Break the problem into small steps.",
    "Keep passwords private and ask before you click new links.",
    "Try, check, then try again — that is how coding works.",
  ],
  body: [
    "Warm up, drink water, and stop if something hurts.",
    "Fair play means following the rules and being kind.",
  ],
};

function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

function trackOf(name = "") {
  const n = name.toLowerCase();
  if (/math|number|logical|account/.test(n)) return "math";
  if (/read|spell|english|afrikaans|zulu|mandarin|russian|language|cursive|sign/.test(n)) return "language";
  if (/bible|music/.test(n)) return "bible";
  if (/science|chem|bio|physics|insect|reptile|natural|anatomy|health|hygiene/.test(n)) return "science";
  if (/geo|histor|social|politic|sociolog|anthropology|life orientation|entrepreneur|management|farm|economic|business/.test(n))
    return "people";
  if (/draw|color|paint|art|knit|crochet|sew|wood|cook|bak|craft|weld|barber|home econ|tracing|automotive/.test(n))
    return "make";
  if (/abuse|disease|first aid|safety|outdoor|indoor/.test(n)) return "safety";
  if (/cod|robot|computer|web|cyber|game|office|information/.test(n)) return "tech";
  if (/physical education|sport/.test(n)) return "body";
  return "people";
}

function ageBand(gradeId) {
  if (gradeId === "preschool" || gradeId === "rr" || gradeId === "r") return "little";
  const n = Number(gradeId);
  if (n <= 3) return "junior";
  if (n <= 7) return "middle";
  return "senior";
}

/**
 * Build a tutor reply for the current learning context.
 */
export function tutorReply({ gradeId, gradeLabel, subjectName, kind, questionPrompt, userMessage }) {
  const track = trackOf(subjectName);
  const band = ageBand(gradeId);
  const tips = TIPS[track] || TIPS.people;
  const tip = tips[hash(`${subjectName}|${questionPrompt || ""}|${userMessage || ""}`) % tips.length];

  const msg = (userMessage || "").trim().toLowerCase();

  if (!msg || /help|hint|stuck|idk|don't know|dont know|assist/.test(msg)) {
    if (band === "little") {
      return {
        text: `Let's go slowly. ${tip} You can also ask a parent to sit with you.`,
        mood: "encourage",
      };
    }
    return {
      text: `Here's a hint for ${subjectName || "this work"}: ${tip}`,
      mood: "hint",
    };
  }

  if (/explain|what does|meaning|why/.test(msg)) {
    return {
      text: `In ${gradeLabel || "this grade"}, ${subjectName || "this subject"} is about practising clear thinking. ${tip} Try the question again after this tip.`,
      mood: "explain",
    };
  }

  if (/answer|solution|tell me/.test(msg)) {
    return {
      text: `I won't give the full answer away — that helps you learn. ${tip} Choose the option that matches the tip, then check your mark in the app.`,
      mood: "coach",
    };
  }

  if (/hello|hi|hey|how are you/.test(msg)) {
    return {
      text: `Hello! I'm your KayaLearn tutor. Ask for a hint, say "explain", or tell me what feels hard in ${subjectName || "your work"}.`,
      mood: "greet",
    };
  }

  if (/progress|how am i|score/.test(msg)) {
    return {
      text: `Open the learner page for a progress bar, or the report for full marks. Steady daily practice beats rushing.`,
      mood: "progress",
    };
  }

  if (/exam|test/.test(msg)) {
    return {
      text: kind === "exam"
        ? `This is exam practice. Read each question carefully, use your tip, and stay calm. ${tip}`
        : `Tests and exams reward steady assignment practice. ${tip}`,
      mood: "exam",
    };
  }

  if (/safety|danger|hurt|scared/.test(msg)) {
    return {
      text: `If you feel unsafe or upset, stop and talk to a trusted adult now. Learning can wait until you feel safe.`,
      mood: "safety",
    };
  }

  // Default contextual coach
  const opener =
    band === "senior"
      ? `Good question about ${subjectName || "this topic"}.`
      : `Nice — you're thinking about ${subjectName || "your work"}.`;

  return {
    text: `${opener} ${tip}${questionPrompt ? ` For this item, focus on: “${String(questionPrompt).slice(0, 120)}”.` : ""}`,
    mood: "coach",
  };
}

export function voiceSupported() {
  return typeof window !== "undefined" && !!(window.speechSynthesis || window.SpeechRecognition || window.webkitSpeechRecognition);
}

export function speak(text, { lang = "en-ZA" } = {}) {
  return new Promise((resolve) => {
    if (!window.speechSynthesis) {
      resolve(false);
      return;
    }
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    u.rate = 0.95;
    u.onend = () => resolve(true);
    u.onerror = () => resolve(false);
    window.speechSynthesis.speak(u);
  });
}

export function stopSpeaking() {
  if (window.speechSynthesis) window.speechSynthesis.cancel();
}

/** Start listening; returns a promise that resolves to transcript or null. */
export function listenOnce({ lang = "en-ZA", timeoutMs = 12000 } = {}) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return Promise.resolve(null);

  return new Promise((resolve) => {
    const rec = new SR();
    rec.lang = lang;
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      try {
        rec.stop();
      } catch {
        /* ignore */
      }
      resolve(value);
    };
    const timer = setTimeout(() => finish(null), timeoutMs);
    rec.onresult = (ev) => {
      clearTimeout(timer);
      const text = ev.results?.[0]?.[0]?.transcript || null;
      finish(text);
    };
    rec.onerror = () => {
      clearTimeout(timer);
      finish(null);
    };
    rec.onend = () => {
      clearTimeout(timer);
      if (!done) finish(null);
    };
    try {
      rec.start();
    } catch {
      clearTimeout(timer);
      finish(null);
    }
  });
}
