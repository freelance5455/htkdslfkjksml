function hash(input) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function pick(seed, list, salt) {
  return list[(seed + salt * 17) % list.length];
}

function trackOf(name) {
  const n = name.toLowerCase();
  if (/math|number|logical|account/.test(n)) return "math";
  if (/read|spell|english|afrikaans|zulu|mandarin|russian|language|cursive|sign language/.test(n))
    return "language";
  if (/bible|music/.test(n)) return "bible";
  if (/science|chem|bio|physics|insect|reptile|natural|anatomy/.test(n)) return "science";
  if (/geo|histor|social|politic|sociolog|life orientation|entrepreneur|management|farm|economic|business|tourism/.test(n))
    return "people";
  if (/draw|color|paint|art|knit|crochet|sew|wood|cook|bak|craft|weld|barber|home econ|tracing/.test(n))
    return "make";
  if (/abuse|disease|first aid|insect safety|safety|health and hygiene|outdoor and indoor|automotive/.test(n)) return "safety";
  if (/anthropology|sociology/.test(n)) return "people";
  if (/cod|robot|computer|web|cyber|game|office|information technology/.test(n)) return "tech";
  if (/physical education|sport/.test(n)) return "body";
  return "people";
}

function ageLevel(gradeId) {
  if (gradeId === "preschool") return 0;
  if (gradeId === "rr" || gradeId === "r") return 1;
  const n = Number(gradeId);
  if (!Number.isFinite(n)) return 2;
  if (n <= 2) return 1;
  if (n <= 4) return 2;
  if (n <= 7) return 3;
  if (n <= 9) return 4;
  return 5; // 10–12
}

export function buildPaper({ gradeId, gradeLabel, subjectName, kind, index }) {
  const seed = hash(`${gradeId}|${subjectName}|${kind}|${index}`);
  const track = trackOf(subjectName);
  const level = ageLevel(gradeId);
  const n =
    kind === "exam" ? (level >= 4 ? 10 : 8) : kind === "test" ? (level >= 4 ? 8 : 6) : track === "make" && level <= 1 ? 3 : level >= 4 ? 6 : 5;
  const questions = [];

  // Age-adapted chemistry openers
  if (/chem/i.test(subjectName) && questions.length === 0) {
    const chem = [
      { prompt: "Water is wet and good to drink when it is clean. True or false?", type: "tf", answer: true },
      { prompt: "Which is a solid?", options: ["Ice", "Steam", "Air", "Sunshine"], answer: 0 },
      { prompt: "Mixing sand and water usually makes…", options: ["A mixture", "A new animal", "Music", "A phone"], answer: 0 },
      { prompt: "We heat water carefully because it can…", options: ["Become steam / burn us", "Turn into rock", "Disappear forever with no heat", "Become a plant"], answer: 0 },
      { prompt: "Atoms are…", options: ["Tiny building blocks of matter", "Only found in space ships", "Always visible with the eye", "A type of fruit"], answer: 0 },
      { prompt: "A chemical change example is…", options: ["Rusting iron", "Folding paper", "Melting ice only", "Breaking a stick only"], answer: 0 },
    ];
    const pickChem = chem[Math.min(level, chem.length - 1)];
    if (pickChem.type === "tf") questions.push(pickChem);
    else questions.push({ type: "mcq", prompt: pickChem.prompt, options: pickChem.options, answer: pickChem.answer });
  }

  if (track === "make" && (kind === "assignment" || level === 1)) {
    if (/trac/i.test(subjectName)) {
      questions.push({ type: "trace", prompt: "Trace the path slowly with your finger. Stay on the line." });
    } else if (/color/i.test(subjectName)) {
      questions.push({
        type: "color",
        prompt: "Tap the sage green colour.",
        swatches: [
          { name: "Sage", token: "sage" },
          { name: "Clay", token: "clay" },
          { name: "Sun", token: "sun" },
          { name: "Ink", token: "ink" },
        ],
        answer: 0,
      });
    } else {
      questions.push({ type: "draw", prompt: `Draw something that belongs in ${subjectName}.` });
    }
  }

  while (questions.length < n) {
    const k = questions.length;
    const roll = (seed + k * 97) % 5;
    if (track === "math" && roll < 3) {
      const a = 1 + ((seed + k * 3) % (level <= 1 ? 9 : level === 2 ? 15 : level === 3 ? 30 : level === 4 ? 50 : 80));
      const b = 1 + ((seed + k * 11) % (level <= 1 ? 9 : level <= 3 ? 12 : 20));
      const op = (seed + k) % (level <= 1 ? 2 : level <= 3 ? 3 : 4);
      if (op === 0) {
        questions.push({ type: "number", prompt: `What is ${a} + ${b}?`, answer: a + b });
      } else if (op === 1) {
        const big = Math.max(a, b);
        const small = Math.min(a, b);
        questions.push({ type: "number", prompt: `What is ${big} − ${small}?`, answer: big - small });
      } else {
        const x = 2 + (k % 9);
        const y = 2 + ((seed + k) % 9);
        questions.push({ type: "number", prompt: `What is ${x} × ${y}?`, answer: x * y });
      } else {
        const y = 2 + ((seed + k) % (level >= 5 ? 9 : 5));
        const x = y * (2 + (k % 6));
        questions.push({ type: "number", prompt: `What is ${x} ÷ ${y}?`, answer: x / y });
      }
      continue;
    }

    if (roll === 4) {
      const statements = facts(track, subjectName);
      const fact = pick(seed, statements, k);
      const flip = (seed + k) % 2 === 0;
      questions.push({
        type: "tf",
        prompt: flip ? fact.false : fact.true,
        answer: !flip,
      });
      continue;
    }

    const bank = mcqs(track, subjectName, level);
    const item = pick(seed, bank, k);
    questions.push({ type: "mcq", ...item });
  }

  const label =
    kind === "exam" ? `Exam ${index + 1}` : kind === "test" ? `Test ${index + 1}` : `Assignment ${index + 1}`;

  return {
    title: `${subjectName} · ${label}`,
    blurb: `${gradeLabel}. Work through each question. The app marks it when you finish.`,
    questions,
  };
}

function facts(track, subject) {
  const map = {
    math: [
      { true: "Ten is more than three.", false: "Three is more than ten." },
      { true: "A square has four equal sides.", false: "A triangle has four sides." },
    ],
    language: [
      { true: "A sentence starts with a capital letter.", false: "A sentence never needs a capital letter." },
      { true: `${subject} helps us share meaning.`, false: `${subject} is only about counting money.` },
    ],
    bible: [
      { true: "The Bible teaches that God loves people.", false: "The Bible says people should never be kind." },
      { true: "Prayer is talking with God.", false: "Prayer means hiding from everyone." },
    ],
    science: [
      { true: "Living things need water.", false: "Plants never need water." },
      { true: "Insects have six legs.", false: "All insects have eight legs." },
    ],
    people: [
      { true: "Maps help us find places.", false: "A map is a kind of sandwich." },
      { true: "South Africa is a country.", false: "South Africa is only an ocean." },
    ],
    make: [
      { true: "Sharp tools need an adult nearby.", false: "Young children should use saws alone." },
      { true: "We wash hands before cooking.", false: "Dirty hands make food safer." },
    ],
    safety: [
      { true: "Tell a trusted adult if someone hurts you.", false: "Secrets about being hurt should stay secret." },
      { true: "Some insects can sting, so we look before we touch.", false: "Every insect is safe to grab." },
    ],
    tech: [
      { true: "A password should be kept private.", false: "Share your password with strangers online." },
      { true: "Computers follow steps we give them.", false: "A robot ignores every instruction." },
    ],
    body: [
      { true: "Moving our bodies keeps us healthier.", false: "Sitting still all day is the only healthy choice." },
      { true: "We drink water when we exercise.", false: "Sport means never drinking water." },
    ],
  };
  return map[track];
}

function mcqs(track, subject, level) {
  const easy = {
    math: [
      { prompt: "Which number comes after 4?", options: ["3", "5", "1", "0"], answer: 1 },
      { prompt: "How many sides does a triangle have?", options: ["2", "3", "4", "6"], answer: 1 },
    ],
    language: [
      { prompt: "Which word is a greeting?", options: ["Hello", "Table", "Run", "Blue"], answer: 0 },
      { prompt: "Which letter is a vowel?", options: ["B", "A", "T", "M"], answer: 1 },
    ],
    bible: [
      { prompt: "Who did God create, in the Bible story?", options: ["Only rocks", "People and the world", "Nothing", "Only cars"], answer: 1 },
      { prompt: "A kind choice is to…", options: ["Share", "Hit", "Hide food", "Shout unkind words"], answer: 0 },
    ],
    science: [
      { prompt: "What do plants need?", options: ["Sunlight and water", "Only darkness", "Sweets", "Plastic bags"], answer: 0 },
      { prompt: "Which is a living thing?", options: ["A tree", "A spoon", "A brick", "A shoe"], answer: 0 },
    ],
    people: [
      { prompt: "A neighbour is someone who…", options: ["Lives near us", "Lives on the moon", "Is a number", "Is a colour"], answer: 0 },
      { prompt: "We use money to…", options: ["Pay for things we need", "Eat as a snack", "Write on", "Plant as a seed"], answer: 0 },
    ],
    make: [
      { prompt: "Before we paint, we should…", options: ["Cover the table", "Paint the floor on purpose", "Hide the brushes", "Use glue as water"], answer: 0 },
      { prompt: "After cooking we…", options: ["Clean up", "Leave the stove on", "Throw food on the floor", "Forget the dishes"], answer: 0 },
    ],
    safety: [
      { prompt: "If you feel unsafe, you should…", options: ["Tell a trusted adult", "Keep it a secret", "Hide forever", "Go with a stranger"], answer: 0 },
      { prompt: "Washing hands helps us…", options: ["Stay healthier", "Grow extra fingers", "Change our name", "Skip sleep"], answer: 0 },
    ],
    tech: [
      { prompt: "A computer follows…", options: ["Instructions", "Only dreams", "The weather by magic", "Nothing"], answer: 0 },
      { prompt: "A strong habit online is to…", options: ["Keep passwords private", "Tell strangers your address", "Click every pop-up", "Share your login"], answer: 0 },
    ],
    body: [
      { prompt: "Before a race we should…", options: ["Warm up", "Skip water all day", "Tie our eyes shut", "Eat only sweets"], answer: 0 },
      { prompt: "A fair game means we…", options: ["Follow the rules", "Push people", "Hide the ball", "Cheat"], answer: 0 },
    ],
  };
  const harder = [
    {
      prompt: `Which idea fits ${subject} best?`,
      options: ["Look carefully, then explain your answer", "Guess without reading", "Copy someone else’s password", "Skip every step"],
      answer: 0,
    },
  ];
  return level <= 2 ? easy[track] : [...easy[track], ...harder];
}

export function scorePaper(questions, picks) {
  let score = 0;
  questions.forEach((q, i) => {
    const pick = picks[i];
    if (q.type === "trace" || q.type === "draw") {
      if (pick === "done") score += 1;
    } else if (q.type === "tf") {
      if (pick === q.answer) score += 1;
    } else if (q.type === "number" || q.type === "mcq" || q.type === "color") {
      if (pick === q.answer) score += 1;
    }
  });
  return { score, total: questions.length };
}
