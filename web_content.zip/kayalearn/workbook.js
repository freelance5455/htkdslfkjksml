import { gradeById, kindsFor, countFor } from "./curriculum.js";
import { buildPaper } from "./assessments.js";
import { bestAttempt } from "./progress.js";

/** Build a printable weekly workbook pack for one learner. */
export function buildWorkbookPack(student, attempts, options = {}) {
  const week = options.week || 1;
  const perSubject = options.perSubject || 2;
  const grade = gradeById(student.grade);
  if (!grade) return { title: "Workbook", lines: ["Unknown grade"], papers: [] };

  const subjects = grade.subjects.filter((s) => student.subjects.includes(s.id) && s.mode === "learn");
  const papers = [];

  for (const subject of subjects) {
    let added = 0;
    for (const kind of ["assignment", "test"]) {
      if (!kindsFor(student.grade).includes(kind)) continue;
      const total = countFor(kind);
      for (let index = 0; index < total && added < perSubject; index++) {
        const hit = bestAttempt(attempts, student.id, subject.id, kind, index);
        if (hit && hit.score / hit.total >= 0.6) continue;
        const paper = buildPaper({
          gradeId: grade.id,
          gradeLabel: grade.label,
          subjectName: subject.name,
          kind,
          index,
        });
        papers.push({
          subject: subject.name,
          kind,
          index,
          paper,
        });
        added += 1;
      }
    }
  }

  return {
    title: `KayaLearn workbook · ${student.name} · Week ${week}`,
    subtitle: `${grade.label} · ${subjects.length} subjects · ${papers.length} practice sets`,
    papers,
  };
}

export function workbookToPrintableHtml(pack) {
  const blocks = pack.papers
    .map((item, i) => {
      const qs = item.paper.questions
        .map((q, qi) => {
          if (q.type === "mcq") {
            return `<div class="q"><p><strong>${qi + 1}.</strong> ${esc(q.prompt)}</p>
              <ul>${q.options.map((o) => `<li>☐ ${esc(o)}</li>`).join("")}</ul></div>`;
          }
          if (q.type === "tf") {
            return `<div class="q"><p><strong>${qi + 1}.</strong> ${esc(q.prompt)}</p>
              <p>☐ True &nbsp; ☐ False</p></div>`;
          }
          if (q.type === "number") {
            return `<div class="q"><p><strong>${qi + 1}.</strong> ${esc(q.prompt)}</p>
              <p>Answer: _______________</p></div>`;
          }
          return `<div class="q"><p><strong>${qi + 1}.</strong> ${esc(q.prompt)}</p>
            <div class="box"></div></div>`;
        })
        .join("");
      return `<section class="set">
        <h2>${esc(item.subject)} · ${esc(item.kind)} ${item.index + 1}</h2>
        ${qs}
      </section>`;
    })
    .join("");

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/><title>${esc(pack.title)}</title>
  <style>
    body{font-family:Georgia,serif;color:#1c1915;padding:1.5rem;max-width:800px;margin:0 auto;line-height:1.45}
    h1{font-size:1.6rem;color:#0b5341} h2{font-size:1.15rem;margin-top:1.5rem;border-bottom:1px solid #e4d9c8;padding-bottom:0.25rem}
    .sub{color:#6d655c;margin-bottom:1.5rem}.q{margin:0.85rem 0}.box{border:1px dashed #0f6e56;height:4rem;margin-top:0.5rem;border-radius:8px}
    ul{list-style:none;padding-left:0} li{margin:0.25rem 0}
    @media print{body{padding:0}.set{page-break-inside:avoid}}
  </style></head><body>
  <h1>${esc(pack.title)}</h1>
  <p class="sub">${esc(pack.subtitle)}</p>
  <p class="sub">Write answers on paper or in the spaces. Mark later in the KayaLearn app if you like.</p>
  ${blocks || "<p>No open practice sets found — try another learner or clear completed work.</p>"}
  </body></html>`;
}

function esc(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}
