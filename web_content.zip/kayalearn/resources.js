/** Static resource directory for South African homeschooling families.
 *  Informational only — not legal advice. Links are public reference points.
 */
export const RESOURCE_SECTIONS = [
  {
    id: "legal",
    title: "Legal & registration",
    blurb: "High-level pointers only. Always check the latest official rules for your province.",
    items: [
      {
        title: "Basic Education Laws Amendment (BELA) context",
        body: "South African home education sits under national education law. Registration and reporting expectations can change — confirm current requirements with your provincial education department.",
      },
      {
        title: "Provincial education department",
        body: "Home education registration is handled provincially. Search for your province’s education department “home education” or “home schooling” page for forms and contacts.",
      },
      {
        title: "Keep simple records",
        body: "Many families keep a learner portfolio: samples of work, attendance notes, and end-of-term reports. KayaLearn progress reports can support that file.",
      },
    ],
  },
  {
    id: "materials",
    title: "Recommended materials",
    blurb: "Prefer free or low-cost, shareable resources where possible.",
    items: [
      {
        title: "CAPS curriculum documents",
        body: "Use official CAPS subject documents from the Department of Basic Education as the scope map for each grade. Align KayaLearn subjects to those topics.",
      },
      {
        title: "Public libraries",
        body: "Local libraries often stock graded readers, science kits, and study guides. Ask about free children’s membership.",
      },
      {
        title: "Open educational resources",
        body: "Look for Creative Commons worksheets and open textbooks. Prefer materials you may print and share with other home educators.",
      },
    ],
  },
  {
    id: "support",
    title: "Support groups",
    blurb: "Community helps with curriculum choices, co-ops, and encouragement.",
    items: [
      {
        title: "Local home education networks",
        body: "Search community boards and social groups for “home education” plus your city or province. Many run park days and shared lessons.",
      },
      {
        title: "Subject specialists",
        body: "For Matric-level sciences and languages, some families share tutors or online classes. Keep any paid choice optional — this app stays free.",
      },
      {
        title: "Special needs support",
        body: "If a learner needs accommodations, ask provincial education support services or local occupational therapists about assessments and adaptations.",
      },
    ],
  },
  {
    id: "wellbeing",
    title: "Rhythm & wellbeing",
    blurb: "A calm home day matters as much as the worksheet count.",
    items: [
      {
        title: "Short daily blocks",
        body: "Use the daily minutes setting in KayaLearn. Young learners often do better with two short sessions than one long stretch.",
      },
      {
        title: "Outdoor time",
        body: "Nature walks can feed Life Skills, science, and PE without extra screen time — especially helpful on low-data days.",
      },
      {
        title: "Rest days",
        body: "Build in lighter days after assessments. Certificates and reports can wait until the learner is ready.",
      },
    ],
  },
];
