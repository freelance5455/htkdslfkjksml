import { loadState, saveState, uid } from "./storage.js";
import {
  GRADES,
  gradeById,
  subjectById,
  examsAllowed,
  kindsFor,
  countFor,
  VIDEOS,
  nextGradeId,
} from "./curriculum.js";
import { buildPaper, scorePaper } from "./assessments.js";
import {
  bestAttempt as bestAttemptFn,
  doneCount as doneCountFn,
  studentOverview,
  isGradeComplete,
  ensureCertificatesAndBadges,
  reportLines,
} from "./progress.js";
import { t, availableLangs } from "./i18n.js";
import { recommendNext, familyAnalytics } from "./recommendations.js";
import { RESOURCE_SECTIONS } from "./resources.js";
import { buildWorkbookPack, workbookToPrintableHtml } from "./workbook.js";

const TIMES = ["07:30", "08:00", "08:30", "09:00", "10:00", "13:00", "14:00", "15:30", "16:00"];
const MINUTES = [30, 45, 60, 90, 120];
const TERM_WEEKS = [6, 8, 10, 12, 13];

function lang() {
  return state.settings?.lang === "af" ? "af" : "en";
}
function tr(key) {
  return t(lang(), key);
}

let state = loadState();
let route = { name: "home" };
let formError = "";
let play = null; // { paper, step, picks, result }

const root = document.getElementById("app");

function persist() {
  saveState(state);
}

function go(next) {
  route = next;
  formError = "";
  play = null;
  render();
  window.scrollTo(0, 0);
}

function studentById(id) {
  return state.students.find((s) => s.id === id);
}

function attemptsFor(studentId, subjectId, kind) {
  return state.attempts.filter(
    (a) => a.studentId === studentId && (!subjectId || a.subjectId === subjectId) && (!kind || a.kind === kind),
  );
}

function bestAttempt(studentId, subjectId, kind, itemIndex) {
  return attemptsFor(studentId, subjectId, kind)
    .filter((a) => a.itemIndex === itemIndex)
    .sort((a, b) => b.score / b.total - a.score / a.total)[0];
}

function doneCount(studentId, subjectId, kind) {
  const total = countFor(kind);
  let n = 0;
  for (let i = 0; i < total; i++) {
    const hit = bestAttempt(studentId, subjectId, kind, i);
    if (hit && hit.score / hit.total >= 0.6) n += 1;
  }
  return n;
}

function el(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

function shell(body, { back } = {}) {
  const bar = back
    ? `<button type="button" class="btn" data-back>${back.label}</button>`
    : `<div class="brand">KayaLearn</div>`;
  root.innerHTML = "";
  const wrap = el(`
    <div class="app">
      <header class="topbar">
        ${bar}
        <div class="muted" style="font-size:0.85rem;font-weight:600">Phase 5</div>
      </header>
      <div id="view"></div>
    </div>
  `);
  root.appendChild(wrap);
  const view = wrap.querySelector("#view");
  if (typeof body === "string") view.innerHTML = body;
  else view.appendChild(body);
  if (back) {
    wrap.querySelector("[data-back]").onclick = () => go(back.to);
  }
  return view;
}

function render() {
  if (!state.parent) return renderWelcome();
  if (route.name === "home") return renderHome();
  if (route.name === "settings") return renderSettings();
  if (route.name === "analytics") return renderAnalytics();
  if (route.name === "plan") return renderPlan();
  if (route.name === "resources") return renderResources();
  if (route.name === "workbook") return renderWorkbook(route.studentId);
  if (route.name === "week") return renderWeek(route.studentId);
  if (route.name === "parent-edit") return renderParentForm();
  if (route.name === "student-new") return renderStudentForm();
  if (route.name === "student-edit") return renderStudentForm(studentById(route.studentId));
  if (route.name === "student") return renderStudent(route.studentId);
  if (route.name === "report") return renderReport(route.studentId);
  if (route.name === "certificates") return renderCertificates(route.studentId);
  if (route.name === "subject") return renderSubject(route.studentId, route.subjectId, route.kind || "assignment", route.page || 0);
  if (route.name === "play") return renderPlay(route.studentId, route.subjectId, route.kind, route.index);
  if (route.name === "watch") return renderWatch(route.studentId);
  return renderHome();
}

function renderWelcome() {
  shell(`
    <p class="kicker">KayaLearn</p>
    <h1 style="font-size:2.4rem;margin-top:0.4rem">A quiet place to learn at home.</h1>
    <p class="muted" style="margin-top:0.75rem">
      No login. Create a parent profile, add each child, and keep lessons, tests and marks on this device.
    </p>
    <div class="card" style="margin-top:1.5rem">
      <form id="parent-form" class="stack">
        <label class="field">Your name
          <input name="name" required placeholder="e.g. Thandi" autocomplete="name" />
        </label>
        <button class="btn btn-primary" type="submit">Create parent profile</button>
      </form>
    </div>
  `);
  root.querySelector("#parent-form").onsubmit = (e) => {
    e.preventDefault();
    const name = new FormData(e.target).get("name").toString().trim();
    if (!name) return;
    state.parent = { name, createdAt: new Date().toISOString() };
    persist();
    go({ name: "home" });
  };
}

function renderHome() {
  const settings = state.settings || { termWeeks: 10, currentTerm: 1, yearLabel: new Date().getFullYear().toString() };
  const list =
    state.students.length === 0
      ? `<div class="card empty">
          <h2>No learners yet</h2>
          <p class="muted">Add a child, choose their grade and subjects, and start today’s work.</p>
        </div>`
      : `<ul class="stack" style="list-style:none;padding:0;margin:0">
          ${state.students
            .map((s) => {
              const g = gradeById(s.grade);
              const overview = studentOverview(state.attempts, s);
              const certs = (state.certificates || []).filter((c) => c.studentId === s.id).length;
              return `<li>
                <button type="button" class="list-link" data-open="${s.id}" style="width:100%;text-align:left">
                  <div class="row">
                    <div>
                      <h2 style="font-size:1.6rem">${escapeHtml(s.name)}</h2>
                      <p class="muted" style="margin:0.2rem 0 0;font-size:0.9rem">${g?.label || s.grade} · age ${escapeHtml(s.age)}</p>
                    </div>
                    <span class="pill">${escapeHtml(s.startTime)}</span>
                  </div>
                  <div class="progress-bar" aria-hidden="true"><span style="width:${overview.pct}%"></span></div>
                  <p class="muted" style="margin:0.35rem 0 0;font-size:0.9rem">${overview.pct}% of library · Term ${settings.currentTerm} · ${certs} certificate${certs === 1 ? "" : "s"}</p>
                </button>
              </li>`;
            })
            .join("")}
        </ul>`;

  shell(`
    <div class="row" style="align-items:flex-end;margin-bottom:1rem">
      <div>
        <p class="kicker">Welcome, ${escapeHtml(state.parent.name)}</p>
        <h1 style="font-size:2.2rem;margin-top:0.25rem">Your learners</h1>
        <p class="muted" style="font-size:0.9rem">${escapeHtml(settings.yearLabel)} · Term ${settings.currentTerm} · ${settings.termWeeks} weeks per term</p>
      </div>
      <button type="button" class="btn btn-primary" id="add-learner">Add learner</button>
    </div>
    ${list}
    <div style="margin-top:1rem;display:flex;flex-wrap:wrap;gap:0.5rem">
      <button type="button" class="btn" id="settings">${tr("termSettings")}</button>
      <button type="button" class="btn" id="analytics">${tr("analytics")}</button>
      <button type="button" class="btn" id="plan">${tr("plan")}</button>
      <button type="button" class="btn" id="resources">Resource hub</button>
      <button type="button" class="btn" id="edit-parent">${tr("editParent")}</button>
      <button type="button" class="btn" id="offline-help">${tr("offlineTip")}</button>
    </div>
  `);

  document.body.classList.toggle("low-data", Boolean(state.settings?.lowData));
  root.querySelector("#add-learner").onclick = () => go({ name: "student-new" });
  root.querySelector("#edit-parent").onclick = () => go({ name: "parent-edit" });
  root.querySelector("#settings").onclick = () => go({ name: "settings" });
  root.querySelector("#analytics").onclick = () => go({ name: "analytics" });
  root.querySelector("#plan").onclick = () => go({ name: "plan" });
  root.querySelector("#resources").onclick = () => go({ name: "resources" });
  root.querySelector("#offline-help").onclick = () => {
    alert(tr("offlineBody"));
  };
  root.querySelectorAll("[data-open]").forEach((btn) => {
    btn.onclick = () => go({ name: "student", studentId: btn.dataset.open });
  });
}

function renderSettings() {
  const s = state.settings || {
    termWeeks: 10,
    currentTerm: 1,
    yearLabel: new Date().getFullYear().toString(),
    lang: "en",
  };
  shell(
    `
    <h1 style="font-size:2rem">${tr("termSettings")}</h1>
    <p class="muted">Choose term length, language, and year label. Exams are for Grade 4+ at the end of a term.</p>
    <form id="term-form" class="card stack" style="margin-top:1rem">
      <label class="field">School year label
        <input name="yearLabel" value="${escapeAttr(s.yearLabel)}" />
      </label>
      <label class="field">${tr("language")}
        <select name="lang">
          ${availableLangs()
            .map(
              (l) =>
                `<option value="${l.id}" ${(s.lang || "en") === l.id ? "selected" : ""}>${l.label}</option>`,
            )
            .join("")}
        </select>
      </label>
      <label class="field">Current term
        <select name="currentTerm">
          ${[1, 2, 3, 4]
            .map((t) => `<option value="${t}" ${t === s.currentTerm ? "selected" : ""}>Term ${t}</option>`)
            .join("")}
        </select>
      </label>
      <label class="field">Weeks per term
        <select name="termWeeks">
          ${TERM_WEEKS.map(
            (w) => `<option value="${w}" ${w === s.termWeeks ? "selected" : ""}>${w} weeks</option>`,
          ).join("")}
        </select>
      </label>
      <label class="field" style="display:flex;align-items:center;gap:0.5rem;font-weight:600">
        <input type="checkbox" name="lowData" ${s.lowData ? "checked" : ""} />
        Low-data mode (hide video embeds; lighter screens)
      </label>
      <button class="btn btn-primary" type="submit">${tr("save")}</button>
    </form>
  `,
    { back: { label: tr("home"), to: { name: "home" } } },
  );
  root.querySelector("#term-form").onsubmit = (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    state.settings = state.settings || {};
    state.settings.yearLabel = fd.get("yearLabel").toString().trim() || new Date().getFullYear().toString();
    state.settings.currentTerm = Number(fd.get("currentTerm"));
    state.settings.termWeeks = Number(fd.get("termWeeks"));
    state.settings.lang = fd.get("lang") === "af" ? "af" : "en";
    state.settings.lowData = fd.get("lowData") === "on";
    document.body.classList.toggle("low-data", state.settings.lowData);
    persist();
    go({ name: "home" });
  };
}

function renderParentForm() {
  shell(
    `
    <h1 style="font-size:2rem">Parent profile</h1>
    <form id="pf" class="card stack" style="margin-top:1rem">
      <label class="field">Your name
        <input name="name" required value="${escapeAttr(state.parent.name)}" />
      </label>
      <button class="btn btn-primary" type="submit">Save</button>
    </form>
  `,
    { back: { label: "Home", to: { name: "home" } } },
  );
  root.querySelector("#pf").onsubmit = (e) => {
    e.preventDefault();
    state.parent.name = new FormData(e.target).get("name").toString().trim();
    persist();
    go({ name: "home" });
  };
}

function renderStudentForm(existing) {
  const grade = gradeById(existing?.grade || "r");
  const selected = new Set(existing?.subjects || grade.subjects.map((s) => s.id));

  const view = shell(`<div id="form-root"></div>`, {
    back: {
      label: existing ? existing.name : "Home",
      to: existing ? { name: "student", studentId: existing.id } : { name: "home" },
    },
  });

  function paint(currentGradeId, currentSelected) {
    const g = gradeById(currentGradeId);
    view.innerHTML = `
      <h1 style="font-size:2rem">${existing ? "Edit learner" : "Add a learner"}</h1>
      <form id="sf" class="card stack" style="margin-top:1rem">
        <label class="field">Learner name
          <input name="name" required value="${escapeAttr(existing?.name || "")}" placeholder="e.g. Amahle" />
        </label>
        <label class="field">Age
          <input name="age" value="${escapeAttr(existing?.age || g.ages)}" placeholder="${escapeAttr(g.ages)}" />
        </label>
        <label class="field">Grade
          <select name="grade">
            ${GRADES.map(
              (gr) =>
                `<option value="${gr.id}" ${gr.id === currentGradeId ? "selected" : ""}>${gr.label} · ${gr.ages}</option>`,
            ).join("")}
          </select>
        </label>
        <div class="grid-2">
          <label class="field">Time each day
            <select name="minutes">
              ${MINUTES.map(
                (m) =>
                  `<option value="${m}" ${m === (existing?.minutesPerDay || 60) ? "selected" : ""}>${m} minutes</option>`,
              ).join("")}
            </select>
          </label>
          <label class="field">Class starts
            <select name="start">
              ${TIMES.map(
                (t) =>
                  `<option value="${t}" ${t === (existing?.startTime || "09:00") ? "selected" : ""}>${t}</option>`,
              ).join("")}
            </select>
          </label>
        </div>
        <fieldset style="border:0;padding:0;margin:0">
          <legend style="font-weight:700;font-size:0.95rem;margin-bottom:0.4rem">Subjects</legend>
          <p class="muted" style="margin:0 0 0.6rem;font-size:0.9rem">Only subjects already on KayaLearn can be chosen.</p>
          <div class="chips" id="chips">
            ${g.subjects
              .map(
                (s) =>
                  `<button type="button" class="chip ${currentSelected.has(s.id) ? "on" : ""}" data-sid="${s.id}">${escapeHtml(s.name)}</button>`,
              )
              .join("")}
          </div>
        </fieldset>
        ${formError ? `<p class="error">${escapeHtml(formError)}</p>` : ""}
        <button class="btn btn-primary" type="submit">Save learner</button>
      </form>
    `;

    const selectedNow = new Set(currentSelected);
    view.querySelectorAll("[data-sid]").forEach((chip) => {
      chip.onclick = () => {
        const id = chip.dataset.sid;
        if (selectedNow.has(id)) selectedNow.delete(id);
        else selectedNow.add(id);
        paint(currentGradeId, selectedNow);
      };
    });
    view.querySelector('[name="grade"]').onchange = (e) => {
      const next = gradeById(e.target.value);
      paint(next.id, new Set(next.subjects.map((s) => s.id)));
    };
    view.querySelector("#sf").onsubmit = (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const name = fd.get("name").toString().trim();
      const age = fd.get("age").toString().trim() || gradeById(fd.get("grade")).ages;
      const gradeId = fd.get("grade").toString();
      const minutesPerDay = Number(fd.get("minutes"));
      const startTime = fd.get("start").toString();
      const subjects = [...selectedNow];
      if (!name) {
        formError = "Add the learner’s name.";
        paint(gradeId, selectedNow);
        return;
      }
      if (subjects.length < 1) {
        formError = "Choose at least one subject.";
        paint(gradeId, selectedNow);
        return;
      }
      if (existing) {
        Object.assign(existing, { name, age, grade: gradeId, subjects, minutesPerDay, startTime });
      } else {
        state.students.push({
          id: uid("stu"),
          name,
          age,
          grade: gradeId,
          subjects,
          minutesPerDay,
          startTime,
        });
      }
      persist();
      const id = existing?.id || state.students[state.students.length - 1].id;
      go({ name: "student", studentId: id });
    };
  }

  paint(grade.id, selected);
}

function renderStudent(studentId) {
  const student = studentById(studentId);
  if (!student) return go({ name: "home" });
  ensureCertificatesAndBadges(state, studentId);
  persist();
  const grade = gradeById(student.grade);
  const subjects = grade.subjects.filter((s) => student.subjects.includes(s.id));
  const overview = studentOverview(state.attempts, student);
  const badges = (state.badges || []).filter((b) => b.studentId === studentId);
  const certs = (state.certificates || []).filter((c) => c.studentId === studentId);
  const complete = isGradeComplete(state.attempts, student);
  const next = nextGradeId(student.grade);
  const settings = state.settings || { termWeeks: 10, currentTerm: 1, yearLabel: "" };
  const rec = recommendNext(state.attempts, student, settings);

  shell(
    `
    <p class="kicker">${escapeHtml(grade.label)}</p>
    <h1 style="font-size:2.3rem;margin-top:0.25rem">${escapeHtml(student.name)}</h1>
    <p class="muted" style="margin-top:0.5rem">
      Age ${escapeHtml(student.age)}. Starts ${escapeHtml(student.startTime)} · ${student.minutesPerDay} min/day.
      Term ${settings.currentTerm} (${settings.termWeeks} weeks)${examsAllowed(student.grade) ? " · exams from Grade 4" : ""}.
    </p>
    <div class="card rec-card" style="margin-top:1rem">
      <p class="kicker">${tr("recommended")}</p>
      <h2 style="font-size:1.35rem;margin-top:0.35rem">${escapeHtml(rec.label)}</h2>
      <p class="muted" style="margin:0.35rem 0 0;font-size:0.9rem">${escapeHtml(rec.reason || "")}</p>
      <button type="button" class="btn btn-clay" id="do-next" style="margin-top:0.75rem">${tr("nextUp")}</button>
    </div>
    <div class="card" style="margin-top:1rem">
      <div class="row">
        <div>
          <strong>${tr("termOverview")}</strong>
          <p class="muted" style="margin:0.2rem 0 0;font-size:0.9rem">${overview.done}/${overview.total} ${tr("pieces")} · ${overview.pct}%</p>
        </div>
        <span class="pill">${overview.pct}%</span>
      </div>
      <div class="progress-bar tall"><span style="width:${overview.pct}%"></span></div>
      ${
        complete
          ? `<p style="margin:0.75rem 0 0;color:var(--sage-deep);font-size:0.9rem"><strong>${tr("gradeComplete")}</strong> ${
              student.grade === "12" ? tr("diplomaReady") : tr("certificateReady")
            }${next ? ` Next: ${gradeById(next)?.label}.` : ""}</p>`
          : `<p class="muted" style="margin:0.75rem 0 0;font-size:0.9rem">${tr("keepWorking")}</p>`
      }
    </div>
    ${
      badges.length
        ? `<div class="chips" style="margin-top:0.75rem">${badges
            .map((b) => `<span class="chip on" style="cursor:default">${escapeHtml(b.label)}</span>`)
            .join("")}</div>`
        : ""
    }
    <div style="margin-top:1rem;display:flex;flex-wrap:wrap;gap:0.5rem">
      <button type="button" class="btn btn-clay" id="report">${tr("progressReport")}</button>
      <button type="button" class="btn" id="certs">${tr("certs")} (${certs.length})</button>
      <button type="button" class="btn" id="week">This week</button>
      <button type="button" class="btn" id="workbook">Printable pack</button>
      ${complete && next ? `<button type="button" class="btn btn-primary" id="promote">${tr("moveTo")} ${escapeHtml(gradeById(next).label)}</button>` : ""}
    </div>
    <div class="stack" style="margin-top:1.25rem">
      ${subjects
        .map((subject) => {
          if (subject.mode === "video") {
            return `<div class="card">
              <div class="row">
                <h2 style="font-size:1.4rem">${escapeHtml(subject.name)}</h2>
                <button type="button" class="btn" data-watch>Open</button>
              </div>
              <p class="muted" style="margin:0.5rem 0 0;font-size:0.9rem">Short videos only.</p>
            </div>`;
          }
          const kinds = kindsFor(student.grade);
          return `<div class="card">
            <div class="row">
              <h2 style="font-size:1.4rem">${escapeHtml(subject.name)}</h2>
              <button type="button" class="btn" data-subject="${subject.id}">Open</button>
            </div>
            <div class="stats">
              ${kinds
                .map((kind) => {
                  const done = doneCount(student.id, subject.id, kind);
                  return `<div class="stat"><strong>${kind}s</strong>${done}/${countFor(kind)}</div>`;
                })
                .join("")}
            </div>
          </div>`;
        })
        .join("")}
    </div>
    <div class="row" style="margin-top:1rem;gap:0.5rem">
      <button type="button" class="btn" id="edit-stu">Edit plan</button>
      <button type="button" class="btn btn-ghost" id="remove-stu">Remove</button>
    </div>
  `,
    { back: { label: "Home", to: { name: "home" } } },
  );

  root.querySelector("#edit-stu").onclick = () => go({ name: "student-edit", studentId });
  root.querySelector("#report").onclick = () => go({ name: "report", studentId });
  root.querySelector("#certs").onclick = () => go({ name: "certificates", studentId });
  root.querySelector("#week").onclick = () => go({ name: "week", studentId });
  root.querySelector("#workbook").onclick = () => go({ name: "workbook", studentId });
  root.querySelector("#do-next").onclick = () => {
    if (rec.type === "watch") return go({ name: "watch", studentId });
    if (rec.type === "complete") return go({ name: "certificates", studentId });
    if (rec.type === "report") return go({ name: "report", studentId });
    if (rec.type === "plan") return go({ name: "student-edit", studentId });
    if (rec.type === "play") {
      return go({
        name: "play",
        studentId,
        subjectId: rec.subjectId,
        kind: rec.kind,
        index: rec.index,
      });
    }
  };
  const promote = root.querySelector("#promote");
  if (promote) {
    promote.onclick = () => {
      if (!confirm(`Move ${student.name} to ${gradeById(next).label}?`)) return;
      student.grade = next;
      const g = gradeById(next);
      student.subjects = g.subjects.map((s) => s.id);
      student.age = g.ages;
      persist();
      go({ name: "student", studentId });
    };
  }
  root.querySelector("#remove-stu").onclick = () => {
    if (!confirm(`Remove ${student.name}? Their marks will go too.`)) return;
    state.students = state.students.filter((s) => s.id !== studentId);
    state.attempts = state.attempts.filter((a) => a.studentId !== studentId);
    state.certificates = (state.certificates || []).filter((c) => c.studentId !== studentId);
    state.badges = (state.badges || []).filter((b) => b.studentId !== studentId);
    persist();
    go({ name: "home" });
  };
  root.querySelectorAll("[data-subject]").forEach((btn) => {
    btn.onclick = () => go({ name: "subject", studentId, subjectId: btn.dataset.subject, kind: "assignment", page: 0 });
  });
  const watchBtn = root.querySelector("[data-watch]");
  if (watchBtn) watchBtn.onclick = () => go({ name: "watch", studentId });
}

function renderSubject(studentId, subjectId, kind, page) {
  const student = studentById(studentId);
  const subject = subjectById(student.grade, subjectId);
  if (!student || !subject || subject.mode !== "learn") return go({ name: "home" });
  const kinds = kindsFor(student.grade);
  const total = countFor(kind);
  const pageSize = 10;
  const start = page * pageSize;
  const slice = [];
  for (let i = start; i < Math.min(total, start + pageSize); i++) slice.push(i);

  shell(
    `
    <p class="kicker">${escapeHtml(gradeById(student.grade).label)}</p>
    <h1 style="font-size:2rem;margin-top:0.25rem">${escapeHtml(subject.name)}</h1>
    <p class="muted" style="margin-top:0.5rem">
      ${countFor("assignment")} assignments and ${countFor("test")} tests
      ${kinds.includes("exam") ? `, plus ${countFor("exam")} exams` : ""}.
      Open any one and finish it in the app.
    </p>
    <div class="chips" style="margin-top:1rem">
      ${kinds
        .map(
          (k) =>
            `<button type="button" class="chip ${k === kind ? "on" : ""}" data-kind="${k}">${k}s</button>`,
        )
        .join("")}
    </div>
    <ul class="stack" style="list-style:none;padding:0;margin:1rem 0 0">
      ${slice
        .map((index) => {
          const hit = bestAttempt(studentId, subjectId, kind, index);
          const pct = hit ? Math.round((hit.score / hit.total) * 100) : null;
          return `<li>
            <button type="button" class="list-link row" data-index="${index}" style="width:100%">
              <span style="font-weight:700;text-transform:capitalize">${kind} ${index + 1}</span>
              <span class="muted" style="font-weight:700">${pct === null ? "Not done" : pct + "%"}</span>
            </button>
          </li>`;
        })
        .join("")}
    </ul>
    <div class="row" style="margin-top:1rem">
      <button type="button" class="btn" id="prev" ${page === 0 ? "disabled" : ""}>Previous</button>
      <button type="button" class="btn" id="next" ${start + pageSize >= total ? "disabled" : ""}>Next</button>
    </div>
  `,
    { back: { label: student.name, to: { name: "student", studentId } } },
  );

  root.querySelectorAll("[data-kind]").forEach((btn) => {
    btn.onclick = () => go({ name: "subject", studentId, subjectId, kind: btn.dataset.kind, page: 0 });
  });
  root.querySelectorAll("[data-index]").forEach((btn) => {
    btn.onclick = () =>
      go({ name: "play", studentId, subjectId, kind, index: Number(btn.dataset.index) });
  });
  root.querySelector("#prev").onclick = () => go({ name: "subject", studentId, subjectId, kind, page: page - 1 });
  root.querySelector("#next").onclick = () => go({ name: "subject", studentId, subjectId, kind, page: page + 1 });
}

function renderPlay(studentId, subjectId, kind, index) {
  const student = studentById(studentId);
  const grade = gradeById(student.grade);
  const subject = subjectById(student.grade, subjectId);
  if (!student || !subject) return go({ name: "home" });

  if (!play) {
    play = {
      paper: buildPaper({
        gradeId: grade.id,
        gradeLabel: grade.label,
        subjectName: subject.name,
        kind,
        index,
      }),
      step: 0,
      picks: {},
      result: null,
    };
  }

  const { paper, step, picks, result } = play;
  const q = paper.questions[step];

  const body = result
    ? `
      <div class="card" style="margin-top:1rem">
        <h2 style="font-size:2rem">${result.score}/${result.total}</h2>
        <p class="muted" style="margin-top:0.5rem">
          ${result.score / result.total >= 0.6 ? "Marked. That one counts as done." : "Marked. Have another go if you want a higher score."}
        </p>
        <button type="button" class="btn btn-primary" id="back-list" style="margin-top:1rem;width:100%">Back to the list</button>
      </div>
    `
    : `<div id="qbox"></div>`;

  shell(
    `
    <p class="muted" style="font-weight:700;font-size:0.9rem">
      ${escapeHtml(student.name)} · question ${Math.min(step + 1, paper.questions.length)} of ${paper.questions.length}
    </p>
    <h1 style="font-size:1.7rem;margin-top:0.35rem">${escapeHtml(paper.title)}</h1>
    <p class="muted" style="margin-top:0.4rem;font-size:0.9rem">${escapeHtml(paper.blurb)}</p>
    ${body}
  `,
    { back: { label: subject.name, to: { name: "subject", studentId, subjectId, kind, page: 0 } } },
  );

  if (result) {
    root.querySelector("#back-list").onclick = () =>
      go({ name: "subject", studentId, subjectId, kind, page: 0 });
    return;
  }

  const qbox = root.querySelector("#qbox");
  paintQuestion(qbox, q, (value) => {
    play.picks[step] = value;
    if (step < paper.questions.length - 1) {
      play.step += 1;
      render();
    } else {
      const scored = scorePaper(paper.questions, play.picks);
      play.result = scored;
      state.attempts.push({
        studentId,
        subjectId,
        kind,
        itemIndex: index,
        score: scored.score,
        total: scored.total,
        at: new Date().toISOString(),
      });
      ensureCertificatesAndBadges(state, studentId);
      persist();
      render();
    }
  });
}

function paintQuestion(host, question, onChoose) {
  if (question.type === "mcq" || question.type === "color") {
    const options =
      question.type === "mcq"
        ? question.options.map((label, i) => ({ label, value: i }))
        : question.swatches.map((s, i) => ({ label: s.name, value: i, token: s.token }));
    host.innerHTML = `
      <div class="card" style="margin-top:1rem">
        <p style="font-size:1.2rem;font-weight:700;margin:0">${escapeHtml(question.prompt)}</p>
        <div class="options">
          ${options
            .map(
              (o) =>
                `<button type="button" class="option" data-v="${o.value}">
                  ${o.token ? `<span class="swatch ${o.token}"></span>` : ""}${escapeHtml(o.label)}
                </button>`,
            )
            .join("")}
        </div>
      </div>
    `;
    host.querySelectorAll("[data-v]").forEach((btn) => {
      btn.onclick = () => onChoose(Number(btn.dataset.v));
    });
    return;
  }

  if (question.type === "tf") {
    host.innerHTML = `
      <div class="card" style="margin-top:1rem">
        <p style="font-size:1.2rem;font-weight:700;margin:0">${escapeHtml(question.prompt)}</p>
        <div class="grid-2" style="margin-top:1rem">
          <button type="button" class="btn btn-primary" data-v="true">True</button>
          <button type="button" class="btn" data-v="false">False</button>
        </div>
      </div>
    `;
    host.querySelector('[data-v="true"]').onclick = () => onChoose(true);
    host.querySelector('[data-v="false"]').onclick = () => onChoose(false);
    return;
  }

  if (question.type === "number") {
    host.innerHTML = `
      <div class="card" style="margin-top:1rem">
        <p style="font-size:1.2rem;font-weight:700;margin:0">${escapeHtml(question.prompt)}</p>
        <input id="num" inputmode="numeric" placeholder="Your answer" style="margin-top:1rem;width:100%" />
        <button type="button" class="btn btn-primary" id="mark" style="margin-top:0.75rem;width:100%">Mark this answer</button>
      </div>
    `;
    host.querySelector("#mark").onclick = () => {
      const value = Number(host.querySelector("#num").value);
      if (Number.isNaN(value)) return;
      onChoose(value);
    };
    return;
  }

  // trace / draw
  host.innerHTML = `
    <div class="card" style="margin-top:1rem">
      <p style="font-size:1.2rem;font-weight:700;margin:0">${escapeHtml(question.prompt)}</p>
      <div class="canvas-wrap"><canvas id="pad" width="640" height="280"></canvas></div>
      <button type="button" class="btn btn-primary" id="done" style="margin-top:0.75rem;width:100%">I’m finished</button>
    </div>
  `;
  const canvas = host.querySelector("#pad");
  const ctx = canvas.getContext("2d");
  let drawing = false;
  let points = 0;
  const pos = (e) => {
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };
  canvas.onpointerdown = (e) => {
    drawing = true;
    const p = pos(e);
    ctx.strokeStyle = "#0f6e56";
    ctx.lineWidth = question.type === "trace" ? 8 : 4;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    canvas.setPointerCapture(e.pointerId);
  };
  canvas.onpointermove = (e) => {
    if (!drawing) return;
    const p = pos(e);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    points += 1;
  };
  canvas.onpointerup = () => {
    drawing = false;
  };
  host.querySelector("#done").onclick = () => {
    if (points < 12) return;
    onChoose("done");
  };
}

function renderWatch(studentId) {
  const student = studentById(studentId);
  if (!student) return go({ name: "home" });
  if (state.settings?.lowData) {
    shell(`
      <p class="kicker">Pre School</p>
      <h1 style="font-size:2.2rem;margin-top:0.25rem">Quiet watching</h1>
      <div class="card" style="margin-top:1rem">
        <p class="muted">Low-data mode is on, so video embeds are hidden. Turn it off under Term settings when you have connectivity.</p>
        <ul class="stack" style="list-style:none;padding:0;margin:0.75rem 0 0">
          ${VIDEOS.map((v) => `<li><strong>${escapeHtml(v.title)}</strong><p class="muted small">${escapeHtml(v.note)}</p>
            <a class="muted small" href="https://www.youtube.com/watch?v=${v.youtubeId}" target="_blank" rel="noopener">Open on YouTube</a></li>`).join("")}
        </ul>
      </div>
    `, { back: { label: student.name, to: { name: "student", studentId } } });
    return;
  }

  const fileProtocol = location.protocol === "file:";
  let filter = "all";
  let current = VIDEOS[0];

  const filtered = () =>
    filter === "all" ? VIDEOS : VIDEOS.filter((v) => v.category === filter);

  const paint = () => {
    const list = filtered();
    if (!list.find((v) => v.id === current.id)) current = list[0] || VIDEOS[0];
    const embedSrc = `https://www.youtube.com/embed/${current.youtubeId}?rel=0&modestbranding=1&playsinline=1`;
    shell(
      `
      <p class="kicker">Pre School</p>
      <h1 style="font-size:2.2rem;margin-top:0.25rem">Quiet watching</h1>
      <p class="muted" style="margin-top:0.5rem">
        Gentle Bible, song and learning videos play inside the app.
        ${fileProtocol ? "<strong> Open this app with a local server (not by double-clicking the HTML file) so YouTube can play.</strong>" : " Needs an internet connection."}
      </p>
      <div class="chips" style="margin-top:0.75rem">
        ${["all", "bible", "songs", "learning"]
          .map(
            (f) =>
              `<button type="button" class="chip ${filter === f ? "on" : ""}" data-filter="${f}">${
                f === "all" ? "All" : f[0].toUpperCase() + f.slice(1)
              }</button>`,
          )
          .join("")}
      </div>
      <div class="video-frame" style="margin-top:1rem">
        <iframe
          key="${current.youtubeId}"
          title="${escapeAttr(current.title)}"
          src="${embedSrc}"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowfullscreen
          referrerpolicy="strict-origin-when-cross-origin"
          loading="eager"
        ></iframe>
      </div>
      <div class="row" style="margin-top:0.75rem;flex-wrap:wrap;gap:0.5rem">
        <a class="btn" href="https://www.youtube.com/watch?v=${current.youtubeId}" target="_blank" rel="noopener">Open on YouTube</a>
        <span class="muted small">${escapeHtml(current.note)}</span>
      </div>
      <ul class="stack" style="list-style:none;padding:0;margin:1rem 0 0">
        ${list
          .map(
            (v) => `
          <li>
            <button type="button" class="list-link" data-vid="${v.id}" style="width:100%;text-align:left;${
              v.id === current.id ? "border-color:var(--sage)" : ""
            }">
              <strong>${escapeHtml(v.title)}</strong>
              <p class="muted" style="margin:0.25rem 0 0;font-size:0.9rem">${escapeHtml(v.note)}</p>
            </button>
          </li>`,
          )
          .join("")}
      </ul>
    `,
      { back: { label: student.name, to: { name: "student", studentId } } },
    );
    root.querySelectorAll("[data-filter]").forEach((btn) => {
      btn.onclick = () => {
        filter = btn.dataset.filter;
        paint();
      };
    });
    root.querySelectorAll("[data-vid]").forEach((btn) => {
      btn.onclick = () => {
        current = VIDEOS.find((v) => v.id === btn.dataset.vid) || current;
        paint();
      };
    });
  };
  paint();
}

function renderResources() {
  shell(
    `
    <h1 style="font-size:2rem">Resource hub</h1>
    <p class="muted">Legal pointers, materials, support and wellbeing notes for South African home educators. Not legal advice.</p>
    <div class="stack" style="margin-top:1rem">
      ${RESOURCE_SECTIONS.map(
        (sec) => `
        <section class="card">
          <h2 style="font-size:1.35rem">${escapeHtml(sec.title)}</h2>
          <p class="muted small">${escapeHtml(sec.blurb)}</p>
          <ul class="stack" style="list-style:none;padding:0;margin:0.75rem 0 0">
            ${sec.items
              .map(
                (item) => `<li style="margin-top:0.65rem">
              <strong>${escapeHtml(item.title)}</strong>
              <p class="muted small">${escapeHtml(item.body)}</p>
            </li>`,
              )
              .join("")}
          </ul>
        </section>`,
      ).join("")}
    </div>
  `,
    { back: { label: tr("home"), to: { name: "home" } } },
  );
}

function renderWeek(studentId) {
  const student = studentById(studentId);
  if (!student) return go({ name: "home" });
  const settings = state.settings || {};
  const rec = recommendNext(state.attempts, student, settings);
  const grade = gradeById(student.grade);
  const learnSubjects = (grade?.subjects || []).filter((s) => student.subjects.includes(s.id) && s.mode === "learn");
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const slots = learnSubjects.slice(0, 5);

  shell(
    `
    <h1 style="font-size:2rem">This week</h1>
    <p class="muted">${escapeHtml(student.name)} · ${student.minutesPerDay} min/day · Term ${settings.currentTerm || 1}</p>
    <div class="card rec-card" style="margin-top:1rem">
      <p class="kicker">${tr("recommended")}</p>
      <h2 style="font-size:1.25rem;margin-top:0.35rem">${escapeHtml(rec.label)}</h2>
      <p class="muted small">${escapeHtml(rec.reason || "")}</p>
      <button type="button" class="btn btn-clay" id="week-next" style="margin-top:0.6rem">${tr("nextUp")}</button>
    </div>
    <div class="card" style="margin-top:1rem">
      <h2 style="font-size:1.25rem">Simple weekly rhythm</h2>
      <p class="muted small">One focus subject per weekday. Adjust freely — this is a guide, not a rule.</p>
      <ul class="stack" style="list-style:none;padding:0;margin:0.75rem 0 0">
        ${days
          .map((day, i) => {
            const sub = slots[i % Math.max(slots.length, 1)];
            return `<li class="row"><strong>${day}</strong><span class="muted">${
              sub ? escapeHtml(sub.name) : "Light / catch-up"
            }</span></li>`;
          })
          .join("")}
      </ul>
    </div>
    <div style="margin-top:1rem;display:flex;gap:0.5rem;flex-wrap:wrap">
      <button type="button" class="btn" id="open-workbook">Printable pack</button>
      <button type="button" class="btn" id="open-report">${tr("progressReport")}</button>
    </div>
  `,
    { back: { label: student.name, to: { name: "student", studentId } } },
  );

  root.querySelector("#week-next").onclick = () => {
    if (rec.type === "watch") return go({ name: "watch", studentId });
    if (rec.type === "complete") return go({ name: "certificates", studentId });
    if (rec.type === "report") return go({ name: "report", studentId });
    if (rec.type === "plan") return go({ name: "student-edit", studentId });
    if (rec.type === "play") {
      return go({
        name: "play",
        studentId,
        subjectId: rec.subjectId,
        kind: rec.kind,
        index: rec.index,
      });
    }
  };
  root.querySelector("#open-workbook").onclick = () => go({ name: "workbook", studentId });
  root.querySelector("#open-report").onclick = () => go({ name: "report", studentId });
}

function renderWorkbook(studentId) {
  const student = studentById(studentId);
  if (!student) return go({ name: "home" });
  const pack = buildWorkbookPack(student, state.attempts, { week: state.settings?.currentTerm || 1, perSubject: 2 });

  shell(
    `
    <h1 style="font-size:2rem">Printable pack</h1>
    <p class="muted">${escapeHtml(pack.subtitle)}. Opens a print-ready page you can save as PDF.</p>
    <div class="card" style="margin-top:1rem">
      <p><strong>${escapeHtml(pack.title)}</strong></p>
      <p class="muted small">${pack.papers.length} practice set${pack.papers.length === 1 ? "" : "s"} from incomplete work.</p>
      <button type="button" class="btn btn-primary" id="print-pack" style="margin-top:0.75rem">Print / save as PDF</button>
    </div>
    <ul class="stack" style="list-style:none;padding:0;margin:1rem 0 0">
      ${
        pack.papers
          .map(
            (p) =>
              `<li class="card row"><span>${escapeHtml(p.subject)} · ${p.kind} ${p.index + 1}</span><span class="muted small">${p.paper.questions.length} q</span></li>`,
          )
          .join("") || `<li class="card muted">Nothing left to pack — great progress.</li>`
      }
    </ul>
  `,
    { back: { label: student.name, to: { name: "student", studentId } } },
  );

  root.querySelector("#print-pack").onclick = () => {
    const html = workbookToPrintableHtml(pack);
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(html);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 300);
  };
}

function renderAnalytics() {
  const stats = familyAnalytics(state.attempts, state.students);
  shell(
    `
    <h1 style="font-size:2rem">${tr("analytics")}</h1>
    <p class="muted">${tr("parentAnalytics")}</p>
    <div class="stats" style="margin-top:1rem">
      <div class="stat"><strong>${tr("activeLearners")}</strong>${stats.learners}</div>
      <div class="stat"><strong>${tr("totalMarks")}</strong>${stats.marked}</div>
      <div class="stat"><strong>${tr("avgProgress")}</strong>${stats.avgPct}%</div>
    </div>
    <div class="card" style="margin-top:1rem">
      <p class="muted small"><strong>${tr("topSubjectHint")}:</strong> ${
        stats.strongest ? `${escapeHtml(stats.strongest.name)} (${stats.strongest.pct}%)` : tr("noneYet")
      }</p>
      <p class="muted small" style="margin-top:0.35rem"><strong>${tr("needsAttention")}:</strong> ${
        stats.weakest ? `${escapeHtml(stats.weakest.name)} (${stats.weakest.pct}%)` : tr("noneYet")
      }</p>
    </div>
    <ul class="stack" style="list-style:none;padding:0;margin:1rem 0 0">
      ${
        stats.perStudent
          .map(
            (s) => `<li class="card row">
          <div>
            <strong>${escapeHtml(s.name)}</strong>
            <p class="muted small">${gradeById(s.grade)?.label || s.grade} · ${s.done}/${s.total}</p>
          </div>
          <span class="pill">${s.pct}%</span>
        </li>`,
          )
          .join("") || `<li class="card muted">${tr("noLearners")}</li>`
      }
    </ul>
  `,
    { back: { label: tr("home"), to: { name: "home" } } },
  );
}

function renderPlan() {
  const plan = state.settings?.yearPlan || "";
  shell(
    `
    <h1 style="font-size:2rem">${tr("planTitle")}</h1>
    <p class="muted">${tr("planBlurb")}</p>
    <form id="plan-form" class="card stack" style="margin-top:1rem">
      <label class="field">Notes
        <textarea name="yearPlan" rows="8" placeholder="${escapeAttr(tr("planPlaceholder"))}" style="width:100%;border-radius:0.85rem;border:1px solid var(--line);padding:0.75rem;font:inherit">${escapeHtml(plan)}</textarea>
      </label>
      <button class="btn btn-primary" type="submit">${tr("savePlan")}</button>
    </form>
  `,
    { back: { label: tr("home"), to: { name: "home" } } },
  );
  root.querySelector("#plan-form").onsubmit = (e) => {
    e.preventDefault();
    state.settings = state.settings || {};
    state.settings.yearPlan = new FormData(e.target).get("yearPlan").toString();
    persist();
    go({ name: "home" });
  };
}

function renderReport(studentId) {
  const student = studentById(studentId);
  if (!student) return go({ name: "home" });
  const settings = state.settings || { termWeeks: 10, currentTerm: 1, yearLabel: new Date().getFullYear().toString() };
  const overview = studentOverview(state.attempts, student);
  const text = reportLines(state.attempts, student, settings);
  shell(
    `
    <h1 style="font-size:2rem">Progress report</h1>
    <p class="muted">${escapeHtml(student.name)} · printable summary on this device</p>
    <div class="card" style="margin-top:1rem"><pre style="white-space:pre-wrap;margin:0;font-size:0.85rem">${escapeHtml(text)}</pre></div>
    <div style="margin-top:1rem;display:flex;flex-wrap:wrap;gap:0.5rem">
      <button type="button" class="btn btn-primary" id="print">Print / save as PDF</button>
      <button type="button" class="btn" id="copy">Copy text</button>
    </div>
    <div class="card" style="margin-top:1rem">
      <h2 style="font-size:1.3rem">By subject</h2>
      <ul class="stack" style="list-style:none;padding:0;margin:0.75rem 0 0">
        ${
          overview.bySubject
            .map(
              (row) =>
                `<li class="row"><span>${escapeHtml(row.subject.name)}</span><strong>${row.pct}%</strong></li>`,
            )
            .join("") || `<li class="muted">No learn subjects selected.</li>`
        }
      </ul>
    </div>
  `,
    { back: { label: student.name, to: { name: "student", studentId } } },
  );
  root.querySelector("#print").onclick = () => window.print();
  root.querySelector("#copy").onclick = async () => {
    try {
      await navigator.clipboard.writeText(text);
      alert("Report copied.");
    } catch {
      alert("Could not copy. Select the text and copy manually.");
    }
  };
}

function renderCertificates(studentId) {
  const student = studentById(studentId);
  if (!student) return go({ name: "home" });
  ensureCertificatesAndBadges(state, studentId);
  persist();
  const certs = (state.certificates || []).filter((c) => c.studentId === studentId);
  shell(
    `
    <h1 style="font-size:2rem">Certificates</h1>
    <p class="muted">Issued on this device when a grade is completed. Grade 12 earns a Matric diploma record.</p>
    ${
      certs.length === 0
        ? `<div class="card empty"><p class="muted">No certificates yet. Keep working through the subject library.</p></div>`
        : `<ul class="stack" style="list-style:none;padding:0;margin:1rem 0 0">${certs
            .map(
              (c) => `<li class="card">
            <p class="kicker">${c.type === "matric" ? "Diploma" : "Certificate"}</p>
            <h2 style="font-size:1.35rem;margin-top:0.25rem">${escapeHtml(c.title)}</h2>
            <p class="muted" style="font-size:0.9rem">Issued ${new Date(c.issuedAt).toLocaleDateString()}</p>
            <button type="button" class="btn" data-print-cert="${c.id}">Print</button>
          </li>`,
            )
            .join("")}</ul>`
    }
  `,
    { back: { label: student.name, to: { name: "student", studentId } } },
  );
  root.querySelectorAll("[data-print-cert]").forEach((btn) => {
    btn.onclick = () => {
      const c = certs.find((x) => x.id === btn.dataset.printCert);
      if (!c) return;
      const w = window.open("", "_blank");
      if (!w) return;
      const isDip = c.type === "matric";
      w.document.write(`<!DOCTYPE html><html><head><title>${escapeHtml(c.title)}</title>
        <style>
          body{font-family:Georgia,serif;padding:2.5rem;text-align:center;background:#f4efe6;color:#1c1915}
          .frame{border:3px double #0f6e56;padding:2.5rem 1.5rem;max-width:40rem;margin:0 auto;background:#fffdf8}
          h1{font-size:${isDip ? "2.1rem" : "1.8rem"};margin:1rem 0;color:#0b5341}
          .seal{margin-top:2rem;color:#0f6e56;font-weight:700;letter-spacing:0.04em}
          .sub{color:#6d655c;font-size:0.95rem}
          .crest{width:64px;height:64px;margin:0 auto 0.5rem;border-radius:50%;background:#0f6e56;color:#fffdf8;display:flex;align-items:center;justify-content:center;font-weight:700}
        </style></head><body>
        <div class="frame">
          <div class="crest">KL</div>
          <p>KayaLearn</p>
          ${isDip ? `<p class="sub">${escapeHtml(tr("diplomaTitle"))}</p>` : ""}
          <h1>${escapeHtml(isDip ? tr("diplomaSeal") : c.title)}</h1>
          <p>Awarded to <strong>${escapeHtml(student.name)}</strong></p>
          <p class="sub">${escapeHtml(tr("issued"))} ${new Date(c.issuedAt).toLocaleDateString()}</p>
          <p class="seal">${isDip ? "MATRIC · NSC PATHWAY RECORD" : "GRADE COMPLETION"}</p>
        </div>
        <script>window.print()<\\/script></body></html>`);
      w.document.close();
    };
  });
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function escapeAttr(s) {
  return escapeHtml(s).replaceAll("'", "&#39;");
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
}

render();
