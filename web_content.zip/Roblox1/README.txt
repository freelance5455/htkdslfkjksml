Roblox 1 - Android project (WebView wrapper)

Build the APK (needs a computer):
1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder, then in Android Studio choose File > Open and pick the folder.
3. Wait for Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. The file is app-debug.apk. Copy it to your phone and install it
   (allow "install unknown apps" when asked).

Notes:
- The game needs internet (it loads three.js and fonts from the web).
- The shared-database and AI Builder features only work inside Claude. In the app, publishing
  saves on the device and the AI Builder uses the offline builder.
- Accounts and worlds are saved inside the app on that phone.
