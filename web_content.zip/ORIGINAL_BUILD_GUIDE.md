# DakFlow AI — Native Android APK Build & Configuration Guide
**Author / Provider:** Nitesh Sahu  
**Application ID:** `in.gov.dakflow.app`  
**Version:** `1.0.0` (Build `10001`)  
**Target SDK:** Android 14 (API Level 34) | Min SDK: Android 8.0 (API Level 26)  

---

## ⚠️ Important Note on APK Generation
Stitch is an AI-native UI design and frontend engineering studio. Because building a binary `.apk` requires compiling native Java/Kotlin/C++ code and signing it with an Android keystore through the Android SDK Gradle build system, **a binary `.apk` cannot be directly compiled inside a web canvas sandbox**.

However, your app was architected from the ground up with **Apache Cordova / Capacitor mobile native compatibility**, so you can generate the `.apk` in **under 3 minutes** using either **GitHub Actions (100% Free Cloud Builder — No Android Studio or PC setup needed)** or locally with **Capacitor + Android Studio**.

---

## 🚀 Method 1: Build APK Online with GitHub Actions (Zero Local Setup)
You do not need to install Android Studio or command-line tools on your computer. GitHub will compile the `.apk` in the cloud and give you a direct download link.

### Step 1: Create a GitHub Repository
1. Go to [github.com](https://github.com/) and create a new repository named `dakflow-apk`.
2. Add your `index.html` file into a folder named `www/` (so path is `www/index.html`).

### Step 2: Add Capacitor Configuration (`capacitor.config.json`)
Create a file named `capacitor.config.json` in the root:
```json
{
  "appId": "in.gov.dakflow.app",
  "appName": "DakFlow AI",
  "webDir": "www",
  "bundledWebRuntime": false,
  "android": {
    "allowMixedContent": true,
    "captureInput": true
  }
}
```

### Step 3: Add Automated Build Workflow
Create a file at `.github/workflows/build-apk.yml` with this exact content:
```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Source
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Setup Java JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Dependencies
        run: |
          npm init -y
          npm install @capacitor/core @capacitor/cli @capacitor/android
          npx cap add android
          npx cap copy

      - name: Build Debug APK with Gradle
        run: |
          cd android
          chmod +x ./gradlew
          ./gradlew assembleDebug

      - name: Upload Installable APK
        uses: actions/upload-artifact@v4
        with:
          name: DakFlow-AI-Debug.apk
          path: android/app/build/outputs/apk/debug/app-debug.apk
```

### Step 4: Download your `.apk`!
- Commit and push to GitHub.
- Go to the **Actions** tab in your repository.
- When the build finishes (~2 minutes), click the completed run and download **`DakFlow-AI-Debug.apk`**.
- Transfer it to your phone or Zebra scanner and tap **Install**!

---

## 💻 Method 2: Build Locally via Terminal & Android Studio

If you have a computer with Node.js and Android Studio:

### 1. Initialize Capacitor in Terminal
```bash
# Create directory
mkdir dakflow-app && cd dakflow-app
npm init -y

# Install Capacitor core & Android platforms
npm install @capacitor/core @capacitor/cli @capacitor/android

# Initialize with DakFlow metadata
npx cap init "DakFlow AI" "in.gov.dakflow.app" --web-dir "www"
```

### 2. Copy App Files
```bash
# Create web directory and paste index.html
mkdir www
cp /path/to/your/index.html ./www/index.html

# Add Android native project container
npx cap add android
npx cap sync
```

### 3. Configure Hardware Permissions for Barcode Camera (`AndroidManifest.xml`)
In `./android/app/src/main/AndroidManifest.xml`, make sure camera and storage permissions are declared inside `<manifest>`:
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
```

### 4. Build `.apk` in Android Studio or Command Line
**Option A — Directly from Terminal (Headless):**
```bash
cd android
./gradlew assembleDebug
# Generated APK location:
# android/app/build/outputs/apk/debug/app-debug.apk
```

**Option B — Inside Android Studio:**
```bash
npx cap open android
```
Inside Android Studio:
- Click **Build** menu at top.
- Select **Build Bundle(s) / APK(s)** → **Build APK(s)**.
- Android Studio will display a popup: *"APK(s) generated successfully: [locate]"*. Tap **locate** to get `app-debug.apk`.

---

## 📲 Method 3: Instant One-Click Online APK Converter (PWABuilder)
If you don't want to use GitHub or terminal commands:
1. Put your `index.html` on GitHub Pages, Netlify, or Vercel (e.g. `https://yourname.github.io/dakflow`).
2. Go to **[PWABuilder.com](https://www.pwabuilder.com/)** (created by Microsoft).
3. Paste your live URL and click **Start**.
4. Click **Package for Stores** → select **Android** → click **Generate**.
5. It immediately packages and downloads an installable Android `.apk` package for you.
