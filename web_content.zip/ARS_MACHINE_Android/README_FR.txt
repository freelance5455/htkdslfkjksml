ARS MACHINE — GESTION (projet Android)

Ce dossier contient le projet source Android qui embarque la version actuelle du logiciel de gestion dans une application Android.
Il ne s'agit pas encore d'un APK prêt à installer : l'APK doit être compilé avec Android Studio.

POUR CRÉER L'APK SUR UN ORDINATEUR
1. Installer Android Studio depuis le site officiel : https://developer.android.com/studio
2. Décompresser ARS_MACHINE_Android.zip.
3. Dans Android Studio, choisir Open puis sélectionner le dossier ARS_MACHINE_Android.
4. Accepter la synchronisation Gradle et installer le SDK Android demandé si Android Studio le propose.
5. Attendre la fin de la synchronisation.
6. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
7. À la fin, cliquer sur Locate pour trouver l'APK. Il pourra ensuite être transféré sur le TECNO et installé.

IMPORTANT
- Cette version conserve les fonctionnalités du fichier HTML actuel dans une WebView Android.
- Les données sont conservées localement dans le stockage du navigateur intégré à l'application; désinstaller l'application ou effacer ses données peut les supprimer. Faites des sauvegardes.
- Cette version ne synchronise pas les données entre plusieurs téléphones et n'inclut pas encore de compte utilisateur/cloud.
- Le projet nécessite Android Studio, une connexion Internet initiale pour télécharger les composants Gradle/SDK, et un JDK compatible.
