# Vintage Story Panning Tracker (Android)

Android Studio project wrapping the offline HTML tracker in a JavaScript-enabled WebView.

## Build an APK
1. Install Android Studio (with Android SDK 35).
2. Open the `PanningTrackerAndroid` folder.
3. Allow Gradle sync to complete.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it.

Note: A local HTML download and this Android app use separate storage. Export a backup from the HTML tracker before switching. File downloads/exports in WebView may need additional native DownloadManager integration; the tracker core, search, confirmation and local storage work through WebView.
