package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

type ChatRequest struct {
	Message string `json:"message"`
	History []ChatMessage `json:"history"`
}
type ChatMessage struct {
	Role string `json:"role"`
	Content string `json:"content"`
}
type ChatResponse struct {
	Reply string `json:"reply"`
	Mode string `json:"mode"`
}
type BugReport struct {
	ID string `json:"id"`
	CreatedAt time.Time `json:"createdAt"`
	GameVersion string `json:"gameVersion"`
	Category string `json:"category"`
	Description string `json:"description"`
	Status string `json:"status"`
}
type ReportRequest struct {
	GameVersion string `json:"gameVersion"`
	Category string `json:"category"`
	Description string `json:"description"`
}
type Store struct {
	mu sync.Mutex
	reports []BugReport
}

var store = &Store{reports: []BugReport{}}

func jsonResponse(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}
func readJSON(r *http.Request, dst any) error {
	defer r.Body.Close()
	dec := json.NewDecoder(io.LimitReader(r.Body, 1<<20))
	dec.DisallowUnknownFields()
	return dec.Decode(dst)
}
func chatHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost { http.Error(w, "method not allowed", 405); return }
	var req ChatRequest
	if err := readJSON(r, &req); err != nil || strings.TrimSpace(req.Message) == "" {
		jsonResponse(w, 400, map[string]string{"error":"Напиши сообщение для LADEN AI."}); return
	}
	reply, mode, err := askAI(req)
	if err != nil {
		log.Printf("AI provider error: %v", err)
		jsonResponse(w, 502, map[string]string{"error":"Сервис ИИ временно недоступен. Попробуй позже."}); return
	}
	jsonResponse(w, 200, ChatResponse{Reply:reply, Mode:mode})
}
func askAI(req ChatRequest) (string, string, error) {
	base := strings.TrimRight(os.Getenv("AI_BASE_URL"), "/")
	key := os.Getenv("AI_API_KEY")
	model := os.Getenv("AI_MODEL")
	if base == "" || key == "" || model == "" {
		return "Привет! Я LADEN AI. Сейчас я запущен в демонстрационном режиме: подключение настоящей языковой модели ещё не настроено. Я могу принять твоё сообщение, а после подключения модели смогу отвечать на вопросы об игре.", "demo", nil
	}
	messages := []ChatMessage{{Role:"system", Content:"Ты LADEN AI — дружелюбный помощник игровой экосистемы LADEN. Отвечай по-русски, понятно и доброжелательно. Помогай с функциями игры, настройками и сообщениями об ошибках. Не выдумывай сведения о состоянии аккаунта или игры. Если не знаешь ответ, честно скажи об этом. Не запрашивай пароли, коды входа или секретные ключи."}}
	for _, m := range req.History {
		if (m.Role == "user" || m.Role == "assistant") && strings.TrimSpace(m.Content) != "" && len(m.Content) <= 4000 {
			messages = append(messages, m)
		}
	}
	messages = append(messages, ChatMessage{Role:"user", Content:req.Message})
	payload := map[string]any{"model":model, "messages":messages, "temperature":0.7}
	body, _ := json.Marshal(payload)
	httpReq, _ := http.NewRequest(http.MethodPost, base+"/chat/completions", bytes.NewReader(body))
	httpReq.Header.Set("Content-Type","application/json")
	httpReq.Header.Set("Authorization","Bearer "+key)
	client := &http.Client{Timeout:35*time.Second}
	resp, err := client.Do(httpReq)
	if err != nil { return "", "", err }
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	if resp.StatusCode < 200 || resp.StatusCode >= 300 { return "", "", fmt.Errorf("provider returned %s: %s", resp.Status, string(raw)) }
	var parsed struct { Choices []struct { Message ChatMessage `json:"message"` } `json:"choices"` }
	if err := json.Unmarshal(raw, &parsed); err != nil { return "", "", err }
	if len(parsed.Choices)==0 || strings.TrimSpace(parsed.Choices[0].Message.Content)=="" { return "", "", errors.New("empty AI response") }
	return parsed.Choices[0].Message.Content, "connected", nil
}
func reportHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost { http.Error(w, "method not allowed", 405); return }
	var req ReportRequest
	if err := readJSON(r, &req); err != nil || strings.TrimSpace(req.Description)=="" {
		jsonResponse(w,400,map[string]string{"error":"Опиши проблему перед отправкой."}); return
	}
	if len(req.Description)>5000 { jsonResponse(w,400,map[string]string{"error":"Описание слишком длинное (максимум 5000 символов)."}); return }
	store.mu.Lock()
	defer store.mu.Unlock()
	id := fmt.Sprintf("LAD-%06d", len(store.reports)+1)
	report := BugReport{ID:id, CreatedAt:time.Now().UTC(), GameVersion:req.GameVersion, Category:req.Category, Description:req.Description, Status:"Новый"}
	store.reports = append(store.reports, report)
	jsonResponse(w,201,map[string]any{"ok":true,"report":report})
}
func adminHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet { http.Error(w, "method not allowed", 405); return }
	token := os.Getenv("LADEN_ADMIN_TOKEN")
	if token == "" || r.Header.Get("X-Admin-Token") != token {
		jsonResponse(w,401,map[string]string{"error":"Нет доступа. Проверь административный токен на сервере."}); return
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	jsonResponse(w,200,map[string]any{"reports":store.reports})
}
func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/chat",chatHandler)
	mux.HandleFunc("/api/reports",reportHandler)
	mux.HandleFunc("/api/admin/reports",adminHandler)
	mux.Handle("/",http.FileServer(http.Dir("./web")))
	addr := ":8080"
	log.Printf("LADEN AI server started at http://localhost%s",addr)
	log.Fatal(http.ListenAndServe(addr,mux))
}
