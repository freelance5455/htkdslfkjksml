const $=id=>document.getElementById(id);
const history=[];
function bubble(text,who){const el=document.createElement("div");el.className="bubble "+who;el.textContent=text;$("chat").appendChild(el);$("chat").scrollTop=$("chat").scrollHeight;}
$("chatForm").addEventListener("submit",async e=>{
 e.preventDefault();const message=$("message").value.trim();if(!message)return;
 bubble(message,"user");$("message").value="";$("chatStatus").textContent="LADEN AI думает...";
 try{const res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,history})});const data=await res.json();if(!res.ok)throw new Error(data.error||"Ошибка сервера");bubble(data.reply,"ai");history.push({role:"user",content:message},{role:"assistant",content:data.reply});$("chatStatus").textContent=data.mode==="demo"?"Демонстрационный режим — языковая модель пока не подключена.":"Подключена языковая модель.";}
 catch(err){bubble("Не удалось получить ответ: "+err.message,"ai");$("chatStatus").textContent="Проверь подключение сервера.";}
});
$("reportForm").addEventListener("submit",async e=>{
 e.preventDefault();$("reportStatus").textContent="Отправка...";
 const payload={gameVersion:$("version").value,category:$("category").value,description:$("description").value};
 try{const res=await fetch("/api/reports",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const data=await res.json();if(!res.ok)throw new Error(data.error||"Ошибка");$("reportStatus").textContent="Отчёт "+data.report.id+" отправлен. Статус: Новый.";$("description").value="";}
 catch(err){$("reportStatus").textContent="Не удалось отправить: "+err.message;}
});
$("loadReports").addEventListener("click",async()=>{
 $("reports").textContent="Загрузка...";
 try{const res=await fetch("/api/admin/reports",{headers:{"X-Admin-Token":$("adminToken").value}});const data=await res.json();if(!res.ok)throw new Error(data.error||"Ошибка доступа");$("reports").textContent=data.reports.length?data.reports.map(r=>`${r.id} | ${r.status} | ${r.gameVersion}\n${r.category}\n${r.description}\n`).join("\n"):"Отчётов пока нет.";}
 catch(err){$("reports").textContent=err.message;}
});
