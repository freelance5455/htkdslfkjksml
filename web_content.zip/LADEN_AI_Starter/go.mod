module laden-ai

go 1.21
