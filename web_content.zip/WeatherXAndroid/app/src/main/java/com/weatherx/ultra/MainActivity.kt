package com.weatherx.ultra

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class MainActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(WeatherBridge(), "WeatherXNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class WeatherBridge {
        @JavascriptInterface
        fun updateWeather(name: String, latitude: Double, longitude: Double,
                          temperature: String, condition: String) {
            getSharedPreferences("weatherx", MODE_PRIVATE).edit()
                .putString("name", name.take(80))
                .putString("temperature", temperature.take(20))
                .putString("condition", condition.take(80))
                .putString("latitude", latitude.toString())
                .putString("longitude", longitude.toString())
                .apply()

            runOnUiThread {
                WorkManager.getInstance(this@MainActivity)
                    .enqueue(OneTimeWorkRequestBuilder<WeatherRefreshWorker>().build())
            }
        }
    }
}
