package com.weatherx.ultra

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class WeatherRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val sp = applicationContext.getSharedPreferences("weatherx", Context.MODE_PRIVATE)
            val lat = sp.getString("latitude", null) ?: return@withContext Result.success()
            val lon = sp.getString("longitude", null) ?: return@withContext Result.success()

            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code&timezone=auto"
            )
            val connection = url.openConnection()
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            val json = connection.getInputStream().bufferedReader().use { it.readText() }
            val current = JSONObject(json).getJSONObject("current")
            val temp = current.getDouble("temperature_2m").toInt().toString() + "°"
            val code = current.getInt("weather_code")
            val condition = when {
                code == 0 -> "Clear sky ☀️"
                code <= 2 -> "Partly cloudy 🌤️"
                code == 3 -> "Overcast ☁️"
                code <= 48 -> "Foggy 🌫️"
                code <= 67 -> "Rain 🌧️"
                code <= 77 -> "Snow ❄️"
                code <= 82 -> "Showers 🌦️"
                code >= 95 -> "Thunderstorm ⛈️"
                else -> "Cloudy ☁️"
            }

            sp.edit().putString("temperature", temp)
                .putString("condition", condition).apply()

            val manager = GlanceAppWidgetManager(applicationContext)
            manager.getGlanceIds(WeatherXWidget::class.java).forEach { id ->
                updateAppWidgetState(applicationContext, id) { prefs ->
                    prefs[stringPreferencesKey("name")] =
                        sp.getString("name", "Weather X") ?: "Weather X"
                    prefs[stringPreferencesKey("temperature")] = temp
                    prefs[stringPreferencesKey("condition")] = condition
                }
                WeatherXWidget().update(applicationContext, id)
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
