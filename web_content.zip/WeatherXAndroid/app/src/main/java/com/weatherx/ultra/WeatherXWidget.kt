package com.weatherx.ultra

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.layout.defaultWeight
import androidx.glance.unit.dp
import androidx.glance.unit.sp
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.glance.color.Color
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.appwidget.state.PreferencesGlanceStateDefinition
import androidx.glance.currentState
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.stringPreferencesKey

class WeatherXWidget : GlanceAppWidget() {
    override val stateDefinition = PreferencesGlanceStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            val prefs = currentState<Preferences>()
            val temp = prefs[stringPreferencesKey("temperature")] ?: "--°"
            val city = prefs[stringPreferencesKey("name")] ?: "Open Weather X"
            val condition = prefs[stringPreferencesKey("condition")] ?: "Add a city in the app"

            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(Color(0xFF10233D))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WEATHER X", style = TextStyle(
                        color = ColorProvider(Color(0xFF7DE6FF)),
                        fontWeight = FontWeight.Bold
                    ))
                    Spacer(GlanceModifier.defaultWeight())
                    Text("● LIVE", style = TextStyle(
                        color = ColorProvider(Color(0xFF70F4C6))
                    ))
                }
                Text(city, style = TextStyle(
                    color = ColorProvider(Color.White),
                    fontWeight = FontWeight.Medium
                ), maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(temp, style = TextStyle(
                        color = ColorProvider(Color.White),
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp
                    ))
                    Spacer(GlanceModifier.width(10.dp))
                    Text(condition, style = TextStyle(
                        color = ColorProvider(Color(0xFFB8D7EF))
                    ), maxLines = 2)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("↻ Refresh", modifier = GlanceModifier.clickable(
                        actionRunCallback<RefreshWidgetAction>()
                    ), style = TextStyle(color = ColorProvider(Color(0xFF7DE6FF))))
                    Spacer(GlanceModifier.width(18.dp))
                    Text("Open app", modifier = GlanceModifier.clickable(
                        actionStartActivity<MainActivity>()
                    ), style = TextStyle(color = ColorProvider(Color.White)))
                }
            }
        }
    }
}

class WeatherXWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WeatherXWidget()
}

class RefreshWidgetAction : ActionCallback {
    override suspend fun onRun(context: Context, glanceId: GlanceId,
                               parameters: ActionParameters) {
        androidx.work.WorkManager.getInstance(context).enqueue(
            androidx.work.OneTimeWorkRequestBuilder<WeatherRefreshWorker>().build()
        )
    }
}
