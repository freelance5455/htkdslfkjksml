# Weather X Ultra — Android home-screen widget starter

This Android Studio project adds a **real Android home-screen widget** using Jetpack Glance.
It is separate from the in-app HTML widget cards.

## What is included
- Android WebView shell for the Weather X HTML dashboard.
- Native Android home-screen widget.
- Refresh action in the home-screen widget.
- Live temperature and condition refresh from Open-Meteo.
- Widget data stored locally and updated when the app shares weather data.

## Add your existing V3 dashboard
Replace `app/src/main/assets/index.html` with your complete Weather X V3 HTML file.

In the V3 HTML JavaScript, inside `getWeather()` after `buildWeather(info[1]);`,
add this bridge call:

```javascript
if (window.WeatherXNative && window.WeatherXNative.updateWeather) {
  WeatherXNative.updateWeather(
    name,
    lat,
    lon,
    Math.round(c.temperature_2m) + "°",
    info[0]
  );
}
```

The app passes the selected city coordinates and current weather to Android.
The native widget then refreshes its own current conditions from Open-Meteo.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17.
3. Allow Gradle sync and dependency downloads.
4. Run on an Android device or emulator.
5. Add the **Weather X Ultra** widget from the launcher's widget picker.

## Notes
- This is source code, not a compiled APK.
- An APK has not been built or tested in this environment.
- Network access is required for live weather refresh.
- The widget starts with a prompt until the app has shared a city and coordinates.
- Android launchers control widget placement and exact sizing.
- For production, add runtime location permission handling if you want native GPS independently of the web dashboard.
