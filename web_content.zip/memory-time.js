const MemoryTime = {
  detect(text, now = new Date()) {
    const s = String(text).toLowerCase();
    const base = new Date(now);
    let days = null;

    if (/\bпослезавтра\b/u.test(s)) days = 2;
    else if (/\bзавтра\b/u.test(s)) days = 1;
    else if (/\bсегодня\b/u.test(s)) days = 0;
    else if (/\bвчера\b/u.test(s)) days = -1;

    // В JavaScript \b не распознаёт русские буквы.
    if (days === null) {
      if (/послезавтра/u.test(s)) days = 2;
      else if (/завтра/u.test(s)) days = 1;
      else if (/сегодня/u.test(s)) days = 0;
      else if (/вчера/u.test(s)) days = -1;
    }

    if (days === null) return null;

    base.setDate(base.getDate() + days);

    return {
      date: [
        base.getFullYear(),
        String(base.getMonth() + 1).padStart(2, '0'),
        String(base.getDate()).padStart(2, '0')
      ].join('-'),
      offsetDays: days,
      isFuture: days > 0
    };
  }
};

if (typeof module !== 'undefined') {
  module.exports = MemoryTime;
}

if (typeof window !== 'undefined') window.MemoryTime = MemoryTime;
