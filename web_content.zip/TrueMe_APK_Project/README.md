# TrueMe — APK Android

## 1. Firebase (mar keliya ah)
1. Firebase Console → project `trueme-59043` → Authentication → Sign-in method → **Email/Password** ku shid.
2. Firestore Database → Rules → ku dheji nuxurka `firestore.rules` → Publish.

## 2. Dhis APK-ga (dooro mid)
**A) GitHub Actions (computer looma baahna)**
- Geli folder-kan oo dhan repo cusub oo GitHub ah → Actions → "Build APK" → Run workflow.
- Marka uu dhammaado, ka soo dejiso `TrueMe-debug-apk` (Artifacts).

**B) Android Studio**
```
npm install
npx cap add android
npx cap sync android
npx cap open android      # Build → Build APK(s)
```

## 3. Tijaabo (muhiim)
1. Telefoon 1: install → Create account → xog ku dar → arag "Synced successfully".
2. Telefoon 2 (ama uninstall/reinstall): install → Sign in → xogtu waa inay soo muuqataa.

## 4. Jadwal & Ogeysiisyo (cusub)
- App-ka gudaha: **Life → Jadwal & Xusuusin** → "Ku dar xusuusin" (cinwaan, waqti, maalmo, caado ikhtiyaari ah).
- Riix **Shid ogeysiisyada** → ogow ogolaanshaha → riix **Tijaabi**.
- Android 12+: haddii la weydiiyo, u ogolow **Alarms & reminders** si xusuusintu waqtigeeda u timaaddo.
- Ogeysiisyadu waxay shaqeeyaan marka app-ku xiran yahay (Capacitor Local Notifications). Workflow-gu wuxuu si toos ah ugu daraa permissions-ka AndroidManifest.

## 5. Logo
- Logo-ga app-ka waa `assets/icon-*.png` (icon-ka telefoonka, la abuuro marka APK-ga la dhisayo) iyo `www/logo.png` (header-ka app-ka).
