/* PWA installation + service-worker registration. Push notifications need a separate FCM/VAPID setup. */
(() => {
  let deferredPrompt = null;
  const installButton = document.getElementById('installAppBtn');
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  if (installButton) installButton.hidden = isStandalone();
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    if (installButton && !isStandalone()) installButton.hidden = false;
  });
  installButton?.addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      await deferredPrompt.userChoice.catch(() => null);
      deferredPrompt = null;
      installButton.hidden = true;
    } else {
      alert('Chrome-এর মেনু (⋮) খুলে “Install app” বা “Add to Home screen” নির্বাচন করুন।');
    }
  });
  window.addEventListener('appinstalled', () => {
    if (installButton) installButton.hidden = true;
  });
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch((error) => {
      console.warn('Service worker registration failed:', error);
    }));
  }
})();
