# Pars Music — Android-ready project

Pars Music is a React/Vite-based music player UI packaged for Android with Capacitor. The project reads the Android music library through MediaStore and does not copy audio files into the app merely to play them.

## Added Android music features

- Automatic MediaStore library scan on app launch and rescan when returning to the foreground.
- Android MediaSession + foreground media playback service for lock-screen and notification shade controls (play/pause/previous/next/seek metadata).
- Runtime notification permission request on Android 13+.
- Multi-select mode in the track list.
- Copy selected Android tracks using Android's Save As picker.
- Delete selected Android tracks through Android's own confirmation UI.
- Personal playlists stored locally in IndexedDB; add selected tracks, play, rename, delete playlists, remove individual tracks from a playlist, and reorder tracks.
- Deleting a playlist never deletes its audio files.

## Build APK

Requirements: Node.js 20+, Android Studio, and an Android SDK installed by Android Studio.

1. Extract the ZIP.
2. In the project folder run:

   ```bash
   npm install
   npm run build
   npx cap add android
   ```

   Run `npx cap add android` only the first time. If the `android/` folder already exists, skip it.

3. Copy all Java files from:

   `native/android/app/src/main/java/com/parsmusic/app/`

   into the matching package folder:

   `android/app/src/main/java/com/parsmusic/app/`

   Replace the generated `MainActivity.java` with the supplied file.

4. Merge every permission from `native/android/AndroidManifest.permissions.xml` directly under the `<manifest>` root of `android/app/src/main/AndroidManifest.xml`.

5. Merge the `<service>` and `<activity>` declarations from `native/android/AndroidManifest.components.xml` inside the `<application>` element.

6. Run:

   ```bash
   npx cap sync android
   npx cap open android
   ```

7. In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Notes for device testing

- Install the APK on a real Android phone and allow music-library access.
- On Android 13+, allow notifications so the playback card can appear in the notification shade and lock screen.
- Android may apply battery/background restrictions; test screen-off playback on the target phone. A foreground service and MediaSession are included, but device-specific battery settings can still affect background behavior.
- Android shows its own confirmation before deleting selected music files.
- Copying a selected device track opens Android's Save As picker. With multiple selected tracks, the picker is opened once per track so the user chooses the destination for each copy.
- Personal playlists remain local to the app. Export/import includes user playlists.

## Gemini backend

The existing Gemini backend remains separate from the APK. Set `GEMINI_API_KEY` as a server-side environment secret and configure the HTTPS backend URL in app settings. Do not embed the API key in the APK or source files.


## Performance and storage optimizations

- On Android, audio remains in its original phone location and is played from the MediaStore `content://` URI. Pars Music does not import, duplicate, or cache the audio bytes in IndexedDB.
- Only lightweight track metadata, MediaStore URIs, favorites/play counts, and playlist references are persisted locally.
- MediaStore synchronization now batches IndexedDB writes/deletes in transactions and updates only changed metadata instead of writing every row on every scan.
- Device scans are coalesced while one is running and briefly throttled to avoid duplicate scans from rapid foreground events.
- The app no longer generates/stores large base64 placeholder cover images for every Android track; native album-art URIs are used when available.
- Track rows use lazy image decoding and `content-visibility` so off-screen rows consume less rendering work.
- The visualizer animation loop runs only while audio is playing and is stopped on pause/background, reducing idle CPU and battery use.
- On non-Android browser builds, user-selected file imports still use browser-managed Blob storage as a fallback. This path is not used for Android MediaStore tracks.
