import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '25mb' }));

// Restrict browser access to configured origins. Capacitor Android commonly uses
// https://localhost; add your deployed web origin through CORS_ORIGINS when needed.
const allowedOrigins = new Set([
  'https://localhost',
  'http://localhost',
  'capacitor://localhost',
  'http://localhost:5173',
  ...(process.env.CORS_ORIGINS || '').split(',').map((value) => value.trim()).filter(Boolean),
]);
app.use('/api', (req: Request, res: Response, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-gemini-key');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

const CANDIDATE_MODELS = ['gemini-2.5-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];

async function generateWithFallback(contents: any, config?: any, customKey?: string) {
  const client = customKey
    ? new GoogleGenAI({
        apiKey: customKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      })
    : ai;

  if (!client) throw new Error('Gemini API key is not configured');
  let lastError: any = null;
  for (const model of CANDIDATE_MODELS) {
    try {
      const response = await client.models.generateContent({
        model,
        contents,
        ...(config || {}),
      });
      return response;
    } catch (err: any) {
      lastError = err;
      console.warn(`Model ${model} failed, trying next candidate:`, err.message || err);
    }
  }
  throw lastError;
}

function cleanJsonResponse(text: string): any {
  if (!text) return {};
  let cleaned = text.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
  }
  return JSON.parse(cleaned);
}

// Health & Status with live latency ping
app.get('/api/status', async (req: Request, res: Response) => {
  const customKey = (req.headers['x-gemini-key'] as string) || (req.query.customKey as string);
  const client = customKey
    ? new GoogleGenAI({ apiKey: customKey })
    : ai;

  const startTime = Date.now();
  let pingOk = false;
  let activeModel = 'gemini-2.5-flash';
  let latencyMs = 0;

  if (client) {
    try {
      await client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: 'ping',
      });
      pingOk = true;
      latencyMs = Date.now() - startTime;
    } catch (e: any) {
      try {
        await client.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: 'ping',
        });
        pingOk = true;
        activeModel = 'gemini-3.1-flash-lite';
        latencyMs = Date.now() - startTime;
      } catch (err2: any) {
        latencyMs = Date.now() - startTime;
      }
    }
  }

  res.json({
    ok: true,
    hasGemini: !!client,
    pingOk,
    latencyMs,
    defaultModel: activeModel,
    candidateModels: CANDIDATE_MODELS,
    hasCustomKey: !!customKey,
    timestamp: new Date().toISOString()
  });
});



function getClientKey(req: Request): string | undefined {
  return (req.headers['x-gemini-key'] as string) || req.body?.customKey;
}

// AI Song Analysis
app.post('/api/gemini/analyze', async (req: Request, res: Response) => {
  const customKey = getClientKey(req);
  if (!ai && !customKey) {
    return res.status(503).json({ error: 'Gemini API key is not configured.' });
  }

  try {
    const { title, artist, album, duration, lyrics, language = 'fa' } = req.body;
    const langPrompt = language === 'fa' ? 'Respond in Persian (Farsi).' : 'Respond in English.';

    const prompt = `Analyze this music track and provide musical characteristics, estimated structure (intro, verses, chorus, bridge, outro), mood, instruments, vocals, and BPM.
Track Information:
- Title: ${title || 'Unknown'}
- Artist: ${artist || 'Unknown'}
- Album: ${album || 'Unknown'}
- Duration (seconds): ${duration || 180}
${lyrics ? `- Lyrics snippet: ${lyrics.slice(0, 500)}` : ''}

${langPrompt}
Return pure JSON matching this exact structure:
{
  "genre": "Identified primary and sub-genres",
  "mood": "Emotional vibe and mood",
  "estimatedBpm": 120,
  "language": "Detected language of vocals or Instrumental",
  "vocalCharacteristics": "e.g., Warm Baritone, Energetic Pop, Auto-tuned Melodic, Instrumental",
  "instruments": ["instrument1", "instrument2", "instrument3"],
  "summary": "Short insightful summary of the track's style and vibe",
  "structure": [
    { "section": "Intro", "approxStartSec": 0, "approxEndSec": 15, "description": "Atmospheric synth pad" },
    { "section": "Verse 1", "approxStartSec": 15, "approxEndSec": 45, "description": "Vocals enter with gentle beat" },
    { "section": "Chorus", "approxStartSec": 45, "approxEndSec": 75, "description": "Main hook and energetic drop" },
    { "section": "Verse 2", "approxStartSec": 75, "approxEndSec": 105, "description": "Second verse" },
    { "section": "Chorus", "approxStartSec": 105, "approxEndSec": 135, "description": "Chorus hook repetition" },
    { "section": "Bridge / Solo", "approxStartSec": 135, "approxEndSec": 160, "description": "Instrumental climax" },
    { "section": "Outro", "approxStartSec": 160, "approxEndSec": ${duration || 180}, "description": "Fading beat and reverberation" }
  ]
}`;

    const response = await generateWithFallback(prompt, {
      responseMimeType: 'application/json',
    }, customKey);

    const parsed = cleanJsonResponse(response.text || '{}');
    return res.json({ success: true, data: parsed, isAiGenerated: true });
  } catch (error: any) {
    console.error('Gemini analyze error:', error);
    return res.status(500).json({ error: error.message || 'Failed to analyze song with Gemini' });
  }
});

// AI Lyrics Translation & Deep Understanding
app.post('/api/gemini/translate-lyrics', async (req: Request, res: Response) => {
  const customKey = getClientKey(req);
  if (!ai && !customKey) {
    return res.status(503).json({ error: 'Gemini API key is not configured.' });
  }

  try {
    const { lyrics, title, artist, targetLang = 'fa' } = req.body;
    if (!lyrics || typeof lyrics !== 'string') {
      return res.status(400).json({ error: 'Lyrics text is required.' });
    }

    const prompt = `You are an expert bilingual literary translator and musicologist.
Translate and annotate the following song lyrics for "${title || 'Unknown'}" by "${artist || 'Unknown'}".
Target translation language: ${targetLang === 'fa' ? 'Persian (Farsi, فارسی روان و ادبی)' : 'English'}.

Source Lyrics:
${lyrics.slice(0, 4000)}

Provide a line-by-line translation, alongside explanations of slang, metaphors, emotional undertones, and cultural references.
Return pure JSON with this structure:
{
  "songTitle": "${title || ''}",
  "storySummary": "Story behind the song and its core message",
  "emotionalAtmosphere": "Emotional mood and tonal analysis",
  "lines": [
    { "original": "original line text", "translation": "translated line text", "note": "optional explanation of metaphor or slang" }
  ],
  "metaphors": [
    { "expression": "phrase from song", "meaning": "deep poetic explanation" }
  ]
}`;

    const response = await generateWithFallback(prompt, {
      responseMimeType: 'application/json',
    }, customKey);

    const parsed = cleanJsonResponse(response.text || '{}');
    return res.json({ success: true, data: parsed, isAiGenerated: true });
  } catch (error: any) {
    console.error('Gemini lyrics translation error:', error);
    return res.status(500).json({ error: error.message || 'Failed to translate lyrics' });
  }
});

// AI Music Assistant Chat
app.post('/api/gemini/chat', async (req: Request, res: Response) => {
  const customKey = getClientKey(req);
  if (!ai && !customKey) {
    return res.status(503).json({ error: 'Gemini API key is not configured.' });
  }

  try {
    const { messages, currentTrack, language = 'fa' } = req.body;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Valid messages array is required.' });
    }

    const systemInstruction = `You are ParsAI, an elite music critic, musicologist, and interactive music assistant in Pars Music (پارس موزیک).
You are fluent in both Persian (فارسی) and English.
Default to responding in ${language === 'fa' ? 'Persian (فارسی شیوا و تخصصی)' : 'English'} unless the user asks in another language.
${currentTrack ? `Currently Playing Song Context:
- Title: ${currentTrack.title || 'Unknown'}
- Artist: ${currentTrack.artist || 'Unknown'}
- Album: ${currentTrack.album || 'Unknown'}
- Genre: ${currentTrack.genre || 'Unknown'}
- Duration: ${Math.round(currentTrack.duration || 0)}s
` : 'No song currently playing.'}
Be helpful, poetic when discussing meaning, precise when discussing musical elements (harmony, tempo, instruments, song structure, history). Keep formatting clean with concise paragraphs.`;

    const lastMsg = messages[messages.length - 1];
    const historyText = messages.slice(0, -1).map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n');
    const fullPrompt = `${systemInstruction}\n\nChat History:\n${historyText}\n\nUser: ${lastMsg.content}\nAssistant:`;

    const response = await generateWithFallback(fullPrompt, undefined, customKey);

    return res.json({
      success: true,
      reply: response.text || '',
    });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate chat response' });
  }
});

// AI Smart Segment Detection
app.post('/api/gemini/segments', async (req: Request, res: Response) => {
  const customKey = getClientKey(req);
  if (!ai && !customKey) {
    return res.status(503).json({ error: 'Gemini API key is not configured.' });
  }

  try {
    const { title, artist, durationSec = 180, lyrics } = req.body;

    const prompt = `Analyze the structure of "${title}" by "${artist}" (duration ~${durationSec} seconds).
Suggest intelligent segments for playback rules:
- "skip_intro": long silence or talking at the start to skip
- "skip_outro": long applause, silence or fadeout at the end to skip
- "loop_chorus": the highest energy memorable hook to loop
- "skip_talking": unwanted skits, interview voiceover or filler
- "play_only_highlight": best 30-45s peak moment

Return pure JSON matching:
{
  "suggestedSegments": [
    {
      "label": "Skip Intro / پرش از مقدمه",
      "ruleType": "skip",
      "startMs": 0,
      "endMs": 14000,
      "reason": "Skip ambient acoustic opening"
    },
    {
      "label": "Hook Loop / حلقه هم‌خوانی",
      "ruleType": "loop",
      "startMs": 48000,
      "endMs": 76000,
      "reason": "Main chorus hook"
    },
    {
      "label": "Skip Outro / پرش از پایان",
      "ruleType": "skip",
      "startMs": ${Math.max(0, (durationSec - 15) * 1000)},
      "endMs": ${durationSec * 1000},
      "reason": "Fade out & quiet trailing tail"
    }
  ]
}`;

    const response = await generateWithFallback(prompt, {
      responseMimeType: 'application/json',
    }, customKey);

    const parsed = cleanJsonResponse(response.text || '{}');
    return res.json({ success: true, data: parsed, isAiGenerated: true });
  } catch (error: any) {
    console.error('Gemini segments error:', error);
    return res.status(500).json({ error: error.message || 'Failed to detect segments' });
  }
});

// AI Smart Personalized Playlist Generator
app.post('/api/gemini/smart-playlist', async (req: Request, res: Response) => {
  const customKey = getClientKey(req);
  if (!ai && !customKey) {
    return res.status(503).json({ error: 'Gemini API key is not configured.' });
  }

  try {
    const {
      userRequest,
      category = 'Made For You',
      userTasteProfile = {},
      availableTracks = [],
      maxTracks = 12,
      language = 'fa'
    } = req.body;

    if (!Array.isArray(availableTracks) || availableTracks.length === 0) {
      return res.status(400).json({ error: 'No available tracks in user library to select from.' });
    }

    // Pass only minimal privacy-conscious metadata of available tracks
    const simplifiedTracks = availableTracks.map((t: any) => ({
      id: t.id,
      title: t.title,
      artist: t.artist,
      album: t.album || '',
      genre: t.genre || 'Music',
      playCount: t.playCount || 0,
      skipCount: t.skipCount || 0,
      isFavorite: !!t.isFavorite,
      duration: Math.round(t.duration || 0)
    }));

    const prompt = `You are the AI Music Curator for Pars Music (پارس موزیک).
Your task is to craft an intelligent personalized playlist strictly chosen from the USER'S ACTUAL LIBRARY TRACKS.
CRITICAL MANDATORY RULE: Every single track ID in "selectedTrackIds" MUST be an exact ID from the provided Available Tracks list. NEVER invent track IDs or songs that are not in the list!

User Goal / Category: "${userRequest || category}"
Language: ${language === 'fa' ? 'Persian (Farsi)' : 'English'}
Target Playlist Size: up to ${Math.min(maxTracks, simplifiedTracks.length)} tracks.

User Taste Profile:
- Top Artists: ${JSON.stringify(userTasteProfile.topArtists || [])}
- Top Genres: ${JSON.stringify(userTasteProfile.topGenres || [])}
- Favorite Tracks: ${JSON.stringify(userTasteProfile.favorites || [])}
- Most Played: ${JSON.stringify(userTasteProfile.mostPlayed || [])}
- Skipped / Lower Affinity: ${JSON.stringify(userTasteProfile.skippedTracks || [])}

Available Tracks (Select STRICTLY from these IDs):
${JSON.stringify(simplifiedTracks.slice(0, 150))}

Return pure JSON matching:
{
  "playlistTitle": "Catchy Creative Playlist Title (e.g. 'نبض شبانه / Midnight Flow')",
  "description": "Inspiring 1-2 sentence description explaining the vibe",
  "category": "${category}",
  "mood": "Atmospheric, Melancholic, Energetic, Focus, etc.",
  "rationale": "Evidence-based explanation of why these tracks were selected based on the user's listening habits (e.g., 'Chosen because you frequently play energetic synthwave and haven't listened to these favorites recently')",
  "confidence": 0.95,
  "selectedTrackIds": ["id1", "id2", "id3"]
}`;

    const response = await generateWithFallback(prompt, {
      responseMimeType: 'application/json',
    }, customKey);

    const parsed = cleanJsonResponse(response.text || '{}');
    
    // Strict backend validation: filter out any invalid or hallucinated IDs
    const validIdSet = new Set(simplifiedTracks.map(t => t.id));
    const validatedIds = (parsed.selectedTrackIds || []).filter((id: string) => validIdSet.has(id));

    // If for any reason AI returned no valid IDs, fall back to best matching local tracks
    if (validatedIds.length === 0 && simplifiedTracks.length > 0) {
      const fallbackIds = simplifiedTracks
        .sort((a, b) => (b.playCount + (b.isFavorite ? 5 : 0)) - (a.playCount + (a.isFavorite ? 5 : 0)))
        .slice(0, Math.min(maxTracks, simplifiedTracks.length))
        .map(t => t.id);
      parsed.selectedTrackIds = fallbackIds;
    } else {
      parsed.selectedTrackIds = validatedIds;
    }

    return res.json({
      success: true,
      data: parsed,
      isAiGenerated: true,
    });
  } catch (error: any) {
    console.error('Gemini smart playlist error:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate smart playlist' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = Number(process.env.PORT || 3000);
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AuraSound] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
