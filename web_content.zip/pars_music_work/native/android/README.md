# Android native features for Pars Music

The Capacitor bridge uses Android MediaStore for the device library, a foreground media playback service + Android MediaSession for lock-screen/notification controls, Android's Storage Access Framework for copies, and Android's system delete-confirmation screen for deleting selected songs.

## Files to copy after `npx cap add android`

Copy every Java file from `native/android/app/src/main/java/com/parsmusic/app/` into:

`android/app/src/main/java/com/parsmusic/app/`

Replace the generated `MainActivity.java` with the supplied one.

## Manifest merge

1. Merge every `<uses-permission>` line from `AndroidManifest.permissions.xml` directly under the `<manifest>` root.
2. Merge the `<service>` and `<activity>` declarations from `AndroidManifest.components.xml` inside the generated `<application>` element.
3. Keep the package/application ID `com.parsmusic.app` consistent with the Capacitor config.

The playback service is a foreground service with `mediaPlayback` type. Android 13+ asks for notification permission when playback starts. Android also shows its own confirmation sheet before deleting media files.

## Behavior and privacy

- Playback metadata and transport actions are exposed through Android MediaSession and a public lock-screen notification.
- Audio data is not copied to Pars Music storage. Only the existing MediaStore `content://` URI and metadata are used for playback.
- Copy opens Android's Save As picker and copies the selected audio to the destination chosen by the user.
- Delete asks for system confirmation (Android 11+) before removing selected media.
- Personal playlists are stored locally in IndexedDB; deleting a playlist never deletes its audio files.

## Build reminder

Run `npm install`, `npm run build`, `npx cap add android` (first build only), copy/merge the native files as above, then run `npx cap sync android` and build the APK from Android Studio.
