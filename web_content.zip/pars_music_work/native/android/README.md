# Android MediaStore bridge

Generate the standard Capacitor Android shell with `npx cap add android`, then copy the Java files in `app/src/main/java/com/parsmusic/app/` into `android/app/src/main/java/com/parsmusic/app/`. Replace the generated `MainActivity.java` with the supplied one. Merge the permissions in `AndroidManifest.permissions.xml` into the generated manifest.

The bridge queries Android MediaStore and returns `content://` URIs. It never copies music files into Pars Music storage.
