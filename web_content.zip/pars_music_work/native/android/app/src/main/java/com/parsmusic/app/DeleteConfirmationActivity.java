package com.parsmusic.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.app.RecoverableSecurityException;

import java.util.ArrayList;

/** Small transparent relay activity used to show Android's official delete-consent UI. */
public class DeleteConfirmationActivity extends Activity {
    private static final int REQUEST_DELETE = 9142;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            ArrayList<String> raw = getIntent().getStringArrayListExtra("uris");
            if (raw == null || raw.isEmpty()) { setResult(RESULT_CANCELED); finish(); return; }
            ArrayList<Uri> uris = new ArrayList<>();
            for (String value : raw) uris.add(Uri.parse(value));
            if (Build.VERSION.SDK_INT >= 30) {
                PendingIntent request = MediaStore.createDeleteRequest(getContentResolver(), uris);
                startIntentSenderForResult(request.getIntentSender(), REQUEST_DELETE, null, 0, 0, 0);
            } else {
                int deleted = 0;
                for (Uri uri : uris) deleted += getContentResolver().delete(uri, null, null);
                setResult(deleted > 0 ? RESULT_OK : RESULT_CANCELED);
                finish();
            }
        } catch (RecoverableSecurityException recoverable) {
            try {
                startIntentSenderForResult(recoverable.getUserAction().getActionIntent().getIntentSender(), REQUEST_DELETE, null, 0, 0, 0);
            } catch (Exception error) { setResult(RESULT_CANCELED); finish(); }
        } catch (Exception error) {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DELETE) setResult(resultCode == RESULT_OK ? RESULT_OK : RESULT_CANCELED);
        finish();
    }
}
