package com.parsmusic.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;


public class MusicPlaybackService extends Service {
    public static final String ACTION_UPDATE = "com.parsmusic.app.UPDATE";
    public static final String ACTION_STOP = "com.parsmusic.app.STOP";
    public static final String ACTION_PLAY = "com.parsmusic.app.PLAY";
    public static final String ACTION_PAUSE = "com.parsmusic.app.PAUSE";
    public static final String ACTION_NEXT = "com.parsmusic.app.NEXT";
    public static final String ACTION_PREVIOUS = "com.parsmusic.app.PREVIOUS";
    private static final String CHANNEL_ID = "pars_music_playback";
    private static final int NOTIFICATION_ID = 7319;

    private MediaSession session;
    private String title = "Pars Music";
    private String artist = "پخش موسیقی";
    private String album = "";
    private boolean playing = false;
    private long duration = 0;
    private long position = 0;
    private String artworkUri = "";
    private Bitmap artworkBitmap;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        session = new MediaSession(this, "ParsMusicSession");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { dispatch(ACTION_PLAY); }
            @Override public void onPause() { dispatch(ACTION_PAUSE); }
            @Override public void onSkipToNext() { dispatch(ACTION_NEXT); }
            @Override public void onSkipToPrevious() { dispatch(ACTION_PREVIOUS); }
            @Override public void onSeekTo(long pos) { MusicLibraryPlugin.dispatchSeek(pos); }
        });
        session.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopForeground(true);
            if (session != null) { session.setActive(false); session.release(); session = null; }
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_PLAY.equals(action) || ACTION_PAUSE.equals(action) || ACTION_NEXT.equals(action) || ACTION_PREVIOUS.equals(action)) {
            dispatch(action);
            return START_STICKY;
        }
        title = intent.getStringExtra("title") == null ? title : intent.getStringExtra("title");
        artist = intent.getStringExtra("artist") == null ? artist : intent.getStringExtra("artist");
        album = intent.getStringExtra("album") == null ? album : intent.getStringExtra("album");
        playing = intent.getBooleanExtra("playing", playing);
        duration = intent.getLongExtra("duration", duration);
        position = intent.getLongExtra("position", position);
        artworkUri = intent.getStringExtra("artwork") == null ? artworkUri : intent.getStringExtra("artwork");
        loadArtwork();
        updateSession();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTIFICATION_ID, notification);
        return START_STICKY;
    }

    private void dispatch(String action) { MusicLibraryPlugin.dispatchMediaAction(action); }

    private void updateSession() {
        if (session == null) return;
        session.setMetadata(new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, duration)
            .build());
        if (artworkBitmap != null) {
            session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, duration)
                .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artworkBitmap)
                .build());
        }
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE |
            PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO;
        session.setPlaybackState(new PlaybackState.Builder()
            .setActions(actions)
            .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, position, 1f)
            .build());
    }


    private void loadArtwork() {
        artworkBitmap = null;
        if (artworkUri == null || !artworkUri.startsWith("content://")) return;
        try (java.io.InputStream input = getContentResolver().openInputStream(Uri.parse(artworkUri))) {
            if (input != null) artworkBitmap = BitmapFactory.decodeStream(input);
        } catch (Exception ignored) { }
    }

    private Notification buildNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent content = PendingIntent.getActivity(this, 1, launch == null ? new Intent() : launch,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setLargeIcon(artworkBitmap)
            .setContentTitle(title).setContentText(artist)
            .setSubText(album).setContentIntent(content)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(playing).setOnlyAlertOnce(true)
            .setShowWhen(false)
            .addAction(action(android.R.drawable.ic_media_previous, "قبلی", ACTION_PREVIOUS, 2));
        b.addAction(action(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
            playing ? "مکث" : "پخش", playing ? ACTION_PAUSE : ACTION_PLAY, 3));
        b.addAction(action(android.R.drawable.ic_media_next, "بعدی", ACTION_NEXT, 4));
        if (Build.VERSION.SDK_INT >= 21 && session != null) {
            b.setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        }
        return b.build();
    }

    private Notification.Action action(int icon, String label, String action, int requestCode) {
        Intent i = new Intent(this, MusicPlaybackService.class).setAction(action);
        PendingIntent p = PendingIntent.getService(this, requestCode, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 23) return new Notification.Action.Builder(icon, label, p).build();
        return new Notification.Action.Builder(icon, label, p).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "پخش موسیقی", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("کنترل پخش پارس موزیک از اعلان و صفحه قفل");
            c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() { if (session != null) session.release(); super.onDestroy(); }
}
