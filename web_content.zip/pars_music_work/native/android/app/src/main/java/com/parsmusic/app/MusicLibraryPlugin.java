package com.parsmusic.app;

import android.Manifest;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Permission;
import com.getcapacitor.PermissionCallback;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(
    name = "MusicLibrary",
    permissions = {
        @Permission(alias = "audio", strings = { Manifest.permission.READ_MEDIA_AUDIO }),
        @Permission(alias = "legacyAudio", strings = { Manifest.permission.READ_EXTERNAL_STORAGE })
    }
)
public class MusicLibraryPlugin extends Plugin {

    private String permissionAlias() {
        return Build.VERSION.SDK_INT >= 33 ? "audio" : "legacyAudio";
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        String alias = permissionAlias();
        if (getPermissionState(alias) == PermissionState.GRANTED) {
            JSObject result = new JSObject();
            result.put("granted", true);
            call.resolve(result);
            return;
        }
        requestPermissionForAlias(alias, call, "permissionCallback");
    }

    @PermissionCallback
    private void permissionCallback(PluginCall call) {
        JSObject result = new JSObject();
        result.put("granted", getPermissionState(permissionAlias()) == PermissionState.GRANTED);
        call.resolve(result);
    }

    @PluginMethod
    public void getTracks(PluginCall call) {
        if (getPermissionState(permissionAlias()) != PermissionState.GRANTED) {
            call.reject("اجازه دسترسی به فایل‌های موسیقی داده نشده است", "PERMISSION_DENIED");
            return;
        }

        JSArray tracks = new JSArray();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = new String[] {
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.MIME_TYPE
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sortOrder = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";

        try (Cursor cursor = getContext().getContentResolver().query(
                collection, projection, selection, null, sortOrder)) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
                int titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
                int albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
                int durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
                int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE);
                int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED);
                int albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID);
                int mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE);

                while (cursor.moveToNext()) {
                    long mediaId = cursor.getLong(idCol);
                    Uri contentUri = ContentUris.withAppendedId(collection, mediaId);
                    long albumId = cursor.getLong(albumIdCol);
                    JSObject item = new JSObject();
                    item.put("id", String.valueOf(mediaId));
                    item.put("title", cursor.getString(titleCol) == null ? "" : cursor.getString(titleCol));
                    item.put("artist", cursor.getString(artistCol) == null ? "" : cursor.getString(artistCol));
                    item.put("album", cursor.getString(albumCol) == null ? "" : cursor.getString(albumCol));
                    item.put("duration", cursor.getLong(durationCol));
                    item.put("displayName", cursor.getString(nameCol) == null ? "" : cursor.getString(nameCol));
                    item.put("size", cursor.getLong(sizeCol));
                    item.put("dateAdded", cursor.getLong(dateCol));
                    item.put("mimeType", cursor.getString(mimeCol) == null ? "" : cursor.getString(mimeCol));
                    item.put("url", contentUri.toString());
                    if (albumId > 0) {
                        Uri albumArt = ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"), albumId
                        );
                        item.put("artwork", albumArt.toString());
                    }
                    tracks.put(item);
                }
            }
            JSObject result = new JSObject();
            result.put("tracks", tracks);
            result.put("count", tracks.length());
            call.resolve(result);
        } catch (Exception error) {
            call.reject("خواندن فهرست موسیقی ناموفق بود: " + error.getLocalizedMessage(), "MEDIA_SCAN_FAILED", error);
        }
    }
}
