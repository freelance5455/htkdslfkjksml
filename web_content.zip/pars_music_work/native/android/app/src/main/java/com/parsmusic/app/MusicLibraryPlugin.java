package com.parsmusic.app;

import android.Manifest;
import android.content.ContentUris;
import android.content.Intent;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.RecoverableSecurityException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import androidx.activity.result.ActivityResult;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.ActivityCallback;

@CapacitorPlugin(
    name = "MusicLibrary",
    permissions = {
        @Permission(alias = "audio", strings = { Manifest.permission.READ_MEDIA_AUDIO }),
        @Permission(alias = "legacyAudio", strings = { Manifest.permission.READ_EXTERNAL_STORAGE }),
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class MusicLibraryPlugin extends Plugin {
    private static MusicLibraryPlugin instance;

    @Override
    public void load() {
        super.load();
        instance = this;
    }

    public static void dispatchMediaAction(String action) {
        MusicLibraryPlugin plugin = instance;
        if (plugin == null) return;
        String value = action;
        if (MusicPlaybackService.ACTION_PLAY.equals(action)) value = "play";
        else if (MusicPlaybackService.ACTION_PAUSE.equals(action)) value = "pause";
        else if (MusicPlaybackService.ACTION_NEXT.equals(action)) value = "next";
        else if (MusicPlaybackService.ACTION_PREVIOUS.equals(action)) value = "previous";
        JSObject data = new JSObject();
        data.put("action", value);
        plugin.notifyListeners("mediaAction", data);
    }

    public static void dispatchSeek(long positionMs) {
        MusicLibraryPlugin plugin = instance;
        if (plugin == null) return;
        JSObject data = new JSObject();
        data.put("action", "seek");
        data.put("position", positionMs);
        plugin.notifyListeners("mediaAction", data);
    }


    private String permissionAlias() {
        return Build.VERSION.SDK_INT >= 33 ? "audio" : "legacyAudio";
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        String alias = permissionAlias();
        if (getPermissionState(alias) == PermissionState.GRANTED) {
            JSObject result = new JSObject();
            result.put("granted", true);
            call.resolve(result);
            return;
        }
        requestPermissionForAlias(alias, call, "permissionCallback");
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) {
            JSObject result = new JSObject(); result.put("granted", true); call.resolve(result); return;
        }
        requestPermissionForAlias("notifications", call, "notificationPermissionCallback");
    }

    @PermissionCallback
    private void notificationPermissionCallback(PluginCall call) {
        JSObject result = new JSObject();
        result.put("granted", Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED);
        call.resolve(result);
    }

    @PermissionCallback
    private void permissionCallback(PluginCall call) {
        JSObject result = new JSObject();
        result.put("granted", getPermissionState(permissionAlias()) == PermissionState.GRANTED);
        call.resolve(result);
    }

    @PluginMethod
    public void getTracks(PluginCall call) {
        if (getPermissionState(permissionAlias()) != PermissionState.GRANTED) {
            call.reject("اجازه دسترسی به فایل‌های موسیقی داده نشده است", "PERMISSION_DENIED");
            return;
        }

        JSArray tracks = new JSArray();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = new String[] {
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.MIME_TYPE
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sortOrder = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";

        try (Cursor cursor = getContext().getContentResolver().query(
                collection, projection, selection, null, sortOrder)) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
                int titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
                int albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
                int durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
                int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE);
                int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED);
                int albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID);
                int mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE);

                while (cursor.moveToNext()) {
                    long mediaId = cursor.getLong(idCol);
                    Uri contentUri = ContentUris.withAppendedId(collection, mediaId);
                    long albumId = cursor.getLong(albumIdCol);
                    JSObject item = new JSObject();
                    item.put("id", String.valueOf(mediaId));
                    item.put("title", cursor.getString(titleCol) == null ? "" : cursor.getString(titleCol));
                    item.put("artist", cursor.getString(artistCol) == null ? "" : cursor.getString(artistCol));
                    item.put("album", cursor.getString(albumCol) == null ? "" : cursor.getString(albumCol));
                    item.put("duration", cursor.getLong(durationCol));
                    item.put("displayName", cursor.getString(nameCol) == null ? "" : cursor.getString(nameCol));
                    item.put("size", cursor.getLong(sizeCol));
                    item.put("dateAdded", cursor.getLong(dateCol));
                    item.put("mimeType", cursor.getString(mimeCol) == null ? "" : cursor.getString(mimeCol));
                    item.put("url", contentUri.toString());
                    if (albumId > 0) {
                        Uri albumArt = ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"), albumId
                        );
                        item.put("artwork", albumArt.toString());
                    }
                    tracks.put(item);
                }
            }
            JSObject result = new JSObject();
            result.put("tracks", tracks);
            result.put("count", tracks.length());
            call.resolve(result);
        } catch (Exception error) {
            call.reject("خواندن فهرست موسیقی ناموفق بود: " + error.getLocalizedMessage(), "MEDIA_SCAN_FAILED", error);
        }
    }

    @PluginMethod
    public void updatePlayback(PluginCall call) {
        Intent intent = new Intent(getContext(), MusicPlaybackService.class).setAction(MusicPlaybackService.ACTION_UPDATE);
        intent.putExtra("title", call.getString("title", "Pars Music"));
        intent.putExtra("artist", call.getString("artist", "پخش موسیقی"));
        intent.putExtra("album", call.getString("album", ""));
        intent.putExtra("playing", call.getBoolean("playing", false));
        intent.putExtra("duration", (long) call.getDouble("duration", 0.0));
        intent.putExtra("position", (long) call.getDouble("position", 0.0));
        intent.putExtra("artwork", call.getString("artwork", ""));
        if (Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(intent);
        else getContext().startService(intent);
        call.resolve();
    }

    @PluginMethod
    public void stopPlaybackSession(PluginCall call) {
        getContext().startService(new Intent(getContext(), MusicPlaybackService.class).setAction(MusicPlaybackService.ACTION_STOP));
        call.resolve();
    }

    @PluginMethod
    public void copyTrack(PluginCall call) {
        String source = call.getString("uri");
        String name = call.getString("name", "music-copy.mp3");
        String mime = call.getString("mimeType", "audio/mpeg");
        if (source == null || !source.startsWith("content://")) {
            call.reject("آدرس فایل برای کپی معتبر نیست");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "copyTrackResult");
    }

    @ActivityCallback
    private void copyTrackResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("عملیات کپی لغو شد", "COPY_CANCELLED");
            return;
        }
        String source = call.getString("uri");
        Uri destination = result.getData().getData();
        try (InputStream in = getContext().getContentResolver().openInputStream(Uri.parse(source));
             OutputStream out = getContext().getContentResolver().openOutputStream(destination, "w")) {
            if (in == null || out == null) throw new IllegalStateException("فایل مبدأ یا مقصد باز نشد");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            out.flush();
            JSObject response = new JSObject();
            response.put("copied", true);
            response.put("uri", destination.toString());
            call.resolve(response);
        } catch (Exception error) {
            call.reject("کپی فایل انجام نشد: " + error.getLocalizedMessage(), "COPY_FAILED", error);
        }
    }

    @PluginMethod
    public void deleteTracks(PluginCall call) {
        JSArray values = call.getArray("uris");
        if (values == null || values.length() == 0) { call.reject("هیچ فایلی برای حذف انتخاب نشده است"); return; }
        try {
            java.util.ArrayList<String> uris = new java.util.ArrayList<>();
            for (int i = 0; i < values.length(); i++) {
                String value = values.getString(i);
                if (value == null || !value.startsWith("content://media/")) { call.reject("آدرس یکی از فایل‌ها معتبر نیست"); return; }
                uris.add(value);
            }
            Intent intent = new Intent(getContext(), DeleteConfirmationActivity.class);
            intent.putStringArrayListExtra("uris", uris);
            startActivityForResult(call, intent, "deleteTrackResult");
        } catch (Exception error) {
            call.reject("درخواست حذف فایل‌ها ساخته نشد: " + error.getLocalizedMessage(), "DELETE_FAILED", error);
        }
    }

    @PluginMethod
    public void deleteTrack(PluginCall call) {
        String rawUri = call.getString("uri");
        if (rawUri == null) { call.reject("آدرس فایل معتبر نیست"); return; }
        if (!rawUri.startsWith("content://media/")) { call.reject("فقط فایل‌های کتابخانه گوشی قابل حذف هستند"); return; }
        ArrayList<String> uris = new ArrayList<>();
        uris.add(rawUri);
        Intent intent = new Intent(getContext(), DeleteConfirmationActivity.class);
        intent.putStringArrayListExtra("uris", uris);
        startActivityForResult(call, intent, "deleteTrackResult");
    }

    @ActivityCallback
    private void deleteTrackResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == Activity.RESULT_OK) call.resolve();
        else call.reject("درخواست حذف توسط کاربر تأیید نشد", "DELETE_NOT_CONFIRMED");
    }

}
