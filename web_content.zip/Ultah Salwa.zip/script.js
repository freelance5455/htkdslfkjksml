// SANDI LOCK SCREEN (Contoh: 1205 = 12 Mei)
const CORRECT_PIN = "1205";
let enteredPin = "";

function pressPin(num) {
    if (enteredPin.length < 4) {
        enteredPin += num;
        updatePinDots();
        if (enteredPin.length === 4) {
            checkPin();
        }
    }
}

function deletePin() {
    enteredPin = enteredPin.slice(0, -1);
    updatePinDots();
}

function clearPin() {
    enteredPin = "";
    updatePinDots();
}

function updatePinDots() {
    for (let i = 1; i <= 4; i++) {
        const dot = document.getElementById(`d${i}`);
        if (i <= enteredPin.length) {
            dot.classList.add("active");
        } else {
            dot.classList.remove("active");
        }
    }
}

function checkPin() {
    if (enteredPin === CORRECT_PIN) {
        document.getElementById("lock-screen").classList.add("hidden");
        document.getElementById("phone-container").classList.remove("hidden");
    } else {
        document.getElementById("error-msg.innerText = "Sandi salah! Coba ingat-ingat tanggal jadian kita ya ❤️";
        setTimeout(() => {
            clearPin();
            document.getElementById("error-msg").innerText = "";
        }, 1500);
    }
}

// BUKA TUTUP APLIKASI
function openApp(appName) {
    document.getElementById("home-screen").classList.remove("active-screen");
    document.getElementById(appName + "-app").style.display = "flex";
    
    // Nyalakan kamera otomatis jika buka aplikasi kamera
    if(appName === 'camera') {
        startCamera();
    }
}

function closeApp() {
    const apps = document.querySelectorAll(".app-screen");
    apps.forEach(app => app.style.display = "none");
    document.getElementById("home-screen").classList.add("active-screen");
    stopCamera();
}

// SISTEM AUTO-REPLY CHAT WHATSAPP
function sendChatMessage() {
    const input = document.getElementById("chat-input");
    const chatBody = document.getElementById("chat-body");
    
    if (input.value.trim() === "") return;

    // Pesan dari cewekmu
    const userMsg = document.createElement("div");
    userMsg.className = "chat-bubble sent";
    userMsg.innerText = input.value;
    chatBody.appendChild(userMsg);
    
    const textTemp = input.value;
    input.value = "";
    chatBody.scrollTop = chatBody.scrollHeight;

    // Balasan otomatis romantis dari sistem
    setTimeout(() => {
        const replyMsg = document.createElement("div");
        replyMsg.className = "chat-bubble received";
        replyMsg.innerText = getAutoReply(textTemp);
        chatBody.appendChild(replyMsg);
        chatBody.scrollTop = chatBody.scrollHeight;
    }, 1000);
}

function getAutoReply(msg) {
    msg = msg.toLowerCase();
    if(msg.includes("sayang") || msg.includes("cinta")) {
        return "Aku jauh lebih sayang sama kamu! Selamat ulang tahun ya, bidadariku. ❤️";
    } else if(msg.includes("makasih") || msg.includes("terima kasih")) {
        return "Sama-sama sayang! Semoga suka sama kado virtual buatan aku ini ya 🥰";
    } else {
        return "Hehe iya sayangku, pokoknya doa terbaik buat kamu hari ini! 🥳✨";
    }
}

// AKTIFKAN KAMERA HP
let videoStream = null;
async function startCamera() {
    try {
        const video = document.getElementById("webcam");
        videoStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
        video.srcObject = videoStream;
    } catch (err) {
        console.log("Kamera tidak dapat diakses: ", err);
    }
}

function stopCamera() {
    if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
    }
}

function takePhoto() {
    alert("📸 Cekrek! Foto berhasil diambil dan disimpan ke galeri hati kamu! ❤️");
}
