package fr.lbruz.coastrush;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.util.DisplayMetrics;
import android.view.Display;
import android.os.Bundle;
import android.os.Build;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean immersive = true;
    private boolean padsDiscovered = false;
    private boolean padStateDirty = true;
    private long lastPadDiscoveryMs = 0;
    private String cachedPadState = "{\"pads\":[]}";

    private final class CoastRushNativeBridge {
        @JavascriptInterface
        public void toggleImmersive() {
            runOnUiThread(() -> {
                immersive = !immersive;
                applySystemUi();
            });
        }
    }

    private final Object padLock = new Object();
    private static final int PAD_COUNT = 2;
    private final int[] padDeviceIds = {-1, -1};
    private final float[][] padAxes = new float[PAD_COUNT][4];
    private final boolean[][] padButtons = new boolean[PAD_COUNT][17];

    private int slotForDevice(int deviceId, boolean create) {
        for (int i = 0; i < PAD_COUNT; i++) if (padDeviceIds[i] == deviceId) return i;
        if (create) for (int i = 0; i < PAD_COUNT; i++) if (padDeviceIds[i] == -1) {
            padDeviceIds[i] = deviceId;
            return i;
        }
        return -1;
    }

    private final class PadBridge {
        @JavascriptInterface
        public String getState() {
            synchronized (padLock) {
                try {
                    long now = SystemClock.uptimeMillis();
                    if (!padsDiscovered || now - lastPadDiscoveryMs > 3000) {
                        for (int deviceId : InputDevice.getDeviceIds()) {
                            InputDevice device = InputDevice.getDevice(deviceId);
                            if (device == null) continue;
                            int sources = device.getSources();
                            if ((sources & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                                    || (sources & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                                if (slotForDevice(deviceId, true) >= 0) padStateDirty = true;
                            }
                        }
                        padsDiscovered = true;
                        lastPadDiscoveryMs = now;
                    }
                    for (int i = 0; i < PAD_COUNT; i++) {
                        if (padDeviceIds[i] >= 0 && InputDevice.getDevice(padDeviceIds[i]) == null) {
                            padDeviceIds[i] = -1;
                            padAxes[i] = new float[4];
                            padButtons[i] = new boolean[17];
                            padStateDirty = true;
                        }
                    }
                    if (!padStateDirty) return cachedPadState;
                    JSONArray pads = new JSONArray();
                    for (int i = 0; i < PAD_COUNT; i++) {
                        JSONObject pad = new JSONObject();
                        boolean connected = padDeviceIds[i] >= 0;
                        pad.put("connected", connected);
                        pad.put("index", i);
                        pad.put("id", connected ? "Android Bluetooth Controller " + (i + 1) : "");
                        JSONArray axes = new JSONArray();
                        for (float axis : padAxes[i]) axes.put(axis);
                        JSONArray buttons = new JSONArray();
                        for (boolean pressed : padButtons[i]) {
                            JSONObject b = new JSONObject();
                            b.put("pressed", pressed);
                            b.put("value", pressed ? 1 : 0);
                            buttons.put(b);
                        }
                        pad.put("axes", axes);
                        pad.put("buttons", buttons);
                        pads.put(pad);
                    }
                    JSONObject out = new JSONObject();
                    out.put("pads", pads);
                    cachedPadState = out.toString();
                    padStateDirty = false;
                    return cachedPadState;
                } catch (Exception e) { return cachedPadState; }
            }
        }
    }

    private final class DisplayBridge {
        @JavascriptInterface
        public String getInfo() {
            try {
                DisplayMetrics app = getResources().getDisplayMetrics();
                Display display = getWindowManager().getDefaultDisplay();
                DisplayMetrics real = new DisplayMetrics();
                display.getRealMetrics(real);
                int vw = webView != null ? webView.getWidth() : 0;
                int vh = webView != null ? webView.getHeight() : 0;
                JSONObject o = new JSONObject();
                o.put("webViewPxWidth", vw);
                o.put("webViewPxHeight", vh);
                o.put("density", app.density);
                o.put("densityDpi", app.densityDpi);
                o.put("appWidthDp", app.widthPixels / app.density);
                o.put("appHeightDp", app.heightPixels / app.density);
                o.put("realWidthPx", real.widthPixels);
                o.put("realHeightPx", real.heightPixels);
                o.put("realWidthDp", real.widthPixels / app.density);
                o.put("realHeightDp", real.heightPixels / app.density);
                o.put("rotation", display.getRotation());
                o.put("refreshRateHz", display.getRefreshRate());
                o.put("configOrientation", getResources().getConfiguration().orientation);
                o.put("requestedOrientation", getRequestedOrientation());
                o.put("hardwareAccelerated", webView != null && webView.isHardwareAccelerated());
                o.put("viewLayerType", webView != null ? webView.getLayerType() : -1);
                return o.toString();
            } catch (Exception e) {
                return "{\\"error\\":\\"native display metrics unavailable\\"}";
            }
        }
    }


    private void prefer60Hz() {
        try {
            Display display = getWindowManager().getDefaultDisplay();
            Display.Mode current = display.getMode();
            Display.Mode best = null;
            float bestDiff = Float.MAX_VALUE;
            if (Build.VERSION.SDK_INT >= 23) {
                for (Display.Mode mode : display.getSupportedModes()) {
                    if (mode.getPhysicalWidth() != current.getPhysicalWidth()
                            || mode.getPhysicalHeight() != current.getPhysicalHeight()) continue;
                    float diff = Math.abs(mode.getRefreshRate() - 60.0f);
                    if (diff < bestDiff) { best = mode; bestDiff = diff; }
                }
            }
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.preferredRefreshRate = 60.0f;
            if (best != null && bestDiff < 1.0f) params.preferredDisplayModeId = best.getModeId();
            getWindow().setAttributes(params);
        } catch (Exception ignored) { }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0A0218);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }
        webView.addJavascriptInterface(new PadBridge(), "CoastRushPad");
        webView.addJavascriptInterface(new DisplayBridge(), "CoastRushDisplay");
        webView.addJavascriptInterface(new CoastRushNativeBridge(), "CoastRushNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installGamepadShim();
                view.postDelayed(() -> {
                    try {
                        String info = new DisplayBridge().getInfo();
                        String quoted = org.json.JSONObject.quote(info);
                        view.evaluateJavascript("window.__COAST_RUSH_NATIVE_DISPLAY__=JSON.parse(" + quoted + ");" +
                            "window.dispatchEvent(new Event('coastrush-native-display'));", null);
                    } catch (Exception ignored) {}
                }, 350);
                view.requestFocus();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadsImagesAutomatically(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        setContentView(webView);
        prefer60Hz();
        hideSystemUi();
        webView.loadUrl("file:///android_asset/index.html");
        webView.requestFocus();
    }

    private void installGamepadShim() {
        String js = "(function(){try{" +
            "var __crPads=null,__crPadsAt=0;" +
            "Object.defineProperty(navigator,'getGamepads',{configurable:true,value:function(){" +
            "var now=performance.now();if(__crPads&&now-__crPadsAt<50)return __crPads;" +
            "var s=JSON.parse(CoastRushPad.getState()),out=[null,null,null,null];" +
            "(s.pads||[]).forEach(function(p,i){if(p.connected)out[i]={id:p.id,index:i,connected:true,mapping:'standard',axes:p.axes,buttons:p.buttons,timestamp:now,hapticActuators:[]};});" +
            "__crPads=out;__crPadsAt=now;return out;" +
            "}});" +
            "}catch(e){console.log('CoastRush gamepad bridge: '+e);}})();";
        webView.evaluateJavascript(js, null);
    }

    private boolean isControllerEvent(KeyEvent e) {
        int sources = e.getSource();
        return (sources & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
            || (sources & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private int buttonIndex(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BUTTON_A: return 0;
            case KeyEvent.KEYCODE_BUTTON_B: return 1;
            case KeyEvent.KEYCODE_BUTTON_X: return 2;
            case KeyEvent.KEYCODE_BUTTON_Y: return 3;
            case KeyEvent.KEYCODE_BUTTON_L1: return 4;
            case KeyEvent.KEYCODE_BUTTON_R1: return 5;
            case KeyEvent.KEYCODE_BUTTON_L2: return 6;
            case KeyEvent.KEYCODE_BUTTON_R2: return 7;
            case KeyEvent.KEYCODE_BUTTON_SELECT: return 8;
            case KeyEvent.KEYCODE_BUTTON_START: return 9;
            case KeyEvent.KEYCODE_DPAD_UP: return 12;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 13;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 14;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 15;
            case KeyEvent.KEYCODE_BUTTON_THUMBL: return 16;
            default: return -1;
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (isControllerEvent(event)) {
            int index = buttonIndex(event.getKeyCode());
            if (index >= 0) {
                synchronized (padLock) {
                    int slot = slotForDevice(event.getDeviceId(), true);
                    if (slot >= 0) { padButtons[slot][index] = event.getAction() == KeyEvent.ACTION_DOWN; padStateDirty = true; }
                }
                return true;
            }
        }
        if (webView != null && event.getKeyCode() != KeyEvent.KEYCODE_BACK) return webView.dispatchKeyEvent(event);
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        int source = event.getSource();
        if ((source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && event.getAction() == MotionEvent.ACTION_MOVE) {
            synchronized (padLock) {
                int slot = slotForDevice(event.getDeviceId(), true);
                if (slot >= 0) {
                    padAxes[slot][0] = deadZone(event.getAxisValue(MotionEvent.AXIS_X));
                    padAxes[slot][1] = deadZone(event.getAxisValue(MotionEvent.AXIS_Y));
                    padAxes[slot][2] = event.getAxisValue(MotionEvent.AXIS_Z);
                    padAxes[slot][3] = event.getAxisValue(MotionEvent.AXIS_RZ);
                    float lt = event.getAxisValue(MotionEvent.AXIS_LTRIGGER);
                    float rt = event.getAxisValue(MotionEvent.AXIS_RTRIGGER);
                    if (lt == 0) lt = event.getAxisValue(MotionEvent.AXIS_BRAKE);
                    if (rt == 0) rt = event.getAxisValue(MotionEvent.AXIS_GAS);
                    padButtons[slot][6] = lt > 0.35f;
                    padButtons[slot][7] = rt > 0.35f;
                    padStateDirty = true;
                }
            }
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private float deadZone(float v) {
        return Math.abs(v) < 0.12f ? 0f : Math.max(-1f, Math.min(1f, v));
    }

    private void hideSystemUi() {
        immersive = true;
        applySystemUi();
    }

    private void applySystemUi() {
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (immersive) {
            flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override public void onBackPressed() {
        // Keep the game running; use Fire TV home to leave the application.
    }

    @Override protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript(
                "if(window.__coastRushLifecycle)window.__coastRushLifecycle('pause');", null);
            webView.onPause();
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        prefer60Hz();
        hideSystemUi();
        if (webView != null) {
            webView.onResume();
            webView.postDelayed(() -> {
                if (webView != null) webView.evaluateJavascript(
                    "if(window.__coastRushLifecycle)window.__coastRushLifecycle('resume');", null);
            }, 120);
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
