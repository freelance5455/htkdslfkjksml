COAST RUSH FIRE TV — PROJET SOURCE V33

Base : version Fire TV allégée V31 retrouvée dans les fichiers du projet.
- Orientation paysage et affichage immersif.
- Commandes manette Bluetooth via le pont Gamepad natif Android.
- Touchscreen non obligatoire pour Fire TV.
- HTML du jeu embarqué localement dans l'application.
- Réglage d'adhérence sur neige amélioré et bonus de temps neige conservé.
- Multijoueur HTTPS conservé dans le jeu.

Compilation : ouvrir ce dossier dans Android Studio, synchroniser Gradle puis lancer
Build > Build Bundle(s) / APK(s) > Build APK(s).

L'APK n'a pas été compilé ni testé sur un Fire TV physique dans cet environnement.
