COAST RUSH FIRE TV — PROJET SOURCE V34

Base : version Fire TV allégée V31 retrouvée dans les fichiers du projet.
- Orientation paysage et affichage immersif.
- Commandes manette Bluetooth via le pont Gamepad natif Android.
- Touchscreen non obligatoire pour Fire TV.
- HTML du jeu embarqué localement dans l'application.
- Réglage d'adhérence sur neige amélioré et bonus de temps neige conservé.
- Multijoueur HTTPS conservé dans le jeu.

Compilation : ouvrir ce dossier dans Android Studio, synchroniser Gradle puis lancer
Build > Build Bundle(s) / APK(s) > Build APK(s).

L'APK n'a pas été compilé ni testé sur un Fire TV physique dans cet environnement.


V34 - changements :
- Deux manettes Bluetooth Android natives exposées séparément au jeu.
- Rubrique 🎮 Interface pour choisir AUTO, 1 joueur ou 2 joueurs.
- Indicateur de connexion des deux manettes.
- Menu Fire TV redimensionné sans réduction forcée : proportions conservées et défilement vertical si nécessaire.
- Canvas de jeu recalculé selon le ratio réel de l'écran.

Note : la prise en charge dépend aussi des manettes et de leur association dans les paramètres Fire TV.
