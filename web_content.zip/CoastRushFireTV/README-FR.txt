COAST RUSH FIRE TV V40 – PROJET SOURCE

Base de jeu : interface HTML V39, avec drift contrôlé restauré.
Cible : Amazon Fire TV Stick 4K Max.

- Menu et logique de jeu repris de la base Fire TV V39.
- Canvas dimensionné selon le ratio réel de l'écran (pas d'étirement forcé).
- Interface de menu agrandie pour une lecture TV, sans remplacer le menu HTML.
- Deux manettes Bluetooth via le pont Android natif (si prises en charge par la Fire TV).
- Qualité de rendu TV adaptative selon la charge mesurée.
- Simulation suspendue lorsque l'application passe en arrière-plan.

Le dossier est un projet source Android Gradle. Ce n'est pas un APK compilé.
La connexion HTTPS multijoueur nécessite un hébergement HTTPS/WSS compatible; le fichier local APK ne publie pas à lui seul le serveur de signalisation.


V40 : drift contrôlé rétabli (frein + virage), crissements de pneus, traces et fumée. Le mot « DRIFT » n’est pas affiché à l’écran. Les réglages d’optimisation graphique Fire TV du projet V39 sont conservés.

COMPILATION HTML TO APK : le fichier index.html placé à la racine du ZIP est la version autonome à sélectionner dans ton logiciel HTML To APK. Le dossier app/ contient aussi le projet Android natif Fire TV complet (WebView, orientation paysage, plein écran et pont manette).
