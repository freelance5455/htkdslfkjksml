COAST RUSH V71 — PROJET ANDROID FIRE TV STICK

Cible prévue : Amazon Fire TV Stick 4K Max (1re génération), Fire OS 7.7.1.3 / Android 9.

Contenu :
- index.html à la racine : version V71 autonome pour un outil HTML-to-APK.
- app/src/main/assets/index.html : même jeu intégré dans l'application Android.
- Projet Android natif complet : MainActivity.java, manifeste Fire TV, Gradle et réglages.
- Pont natif WebView et prise en charge des manettes Bluetooth conservés depuis le projet Fire TV.

Version du jeu : V71 — départ et chronométrage synchronisés.
Application ID : fr.lbruz.coastrush.firetv
Version Android : 71.0-firetv

COMPILATION :
1. Décompresser ce ZIP.
2. Ouvrir le dossier CoastRushFireTV dans Android Studio.
3. Laisser Gradle synchroniser le projet avec Java 17 et Android SDK 35.
4. Lancer Build > Build APK(s), ou exécuter : gradle assembleDebug
5. APK attendu : app/build/outputs/apk/debug/app-debug.apk

IMPORTANT :
Ce ZIP est le projet source Android prêt à compiler, pas un APK déjà compilé.
La compilation Android n'a pas été exécutée dans cet environnement (outil Gradle/SDK Android absent).
Le JavaScript du jeu a été vérifié avec node --check.
Aucun test sur Fire TV physique n'a été effectué ici.
Le multijoueur en ligne continue de nécessiter une connexion HTTPS/WSS et un service de signalisation accessible.


VERSION DE BASE DU JEU : CoastRush V71 - TIMERS SYNCHRONISES.
Les deux fichiers index.html (racine et assets Android) sont identiques.
Ce ZIP contient le projet Android source à compiler en APK ; ce n'est pas un APK déjà compilé.
