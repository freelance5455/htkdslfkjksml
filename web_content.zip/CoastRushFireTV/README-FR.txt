COAST RUSH FIRE TV V36 – PROJET SOURCE

Base de jeu : dernière interface HTML commune V36.
Cible : Amazon Fire TV Stick 4K Max.

- Menu et logique de jeu repris de Coast-Rush-V36-HTTPS.html.
- Canvas dimensionné selon le ratio réel de l'écran (pas d'étirement forcé).
- Interface de menu agrandie pour une lecture TV, sans remplacer le menu HTML.
- Deux manettes Bluetooth via le pont Android natif (si prises en charge par la Fire TV).
- Qualité de rendu TV adaptative selon la charge mesurée.
- Simulation suspendue lorsque l'application passe en arrière-plan.

Le dossier est un projet source Android Gradle. Ce n'est pas un APK compilé.
La connexion HTTPS multijoueur nécessite un hébergement HTTPS/WSS compatible; le fichier local APK ne publie pas à lui seul le serveur de signalisation.
