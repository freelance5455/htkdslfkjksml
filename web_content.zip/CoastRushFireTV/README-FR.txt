COAST RUSH V35 – FIRE TV / WEB

Projet Android source pour Fire TV Stick 4K Max.

Inclus :
- Interface de menu harmonisée avec la version web Coast Rush.
- Gestion de deux manettes Bluetooth indépendantes via le pont Android natif.
- Mode deux joueurs en écran partagé.
- Canvas 16:9 et adaptation de résolution à l'écran.
- Boucle de simulation Fire TV à pas fixe 60 Hz avec qualité graphique adaptative.
- Multijoueur réseau via WebSocket sécurisé (WSS) et WebRTC lorsque l'appareil est connecté à Internet.

Pour compiler : ouvrir ce dossier dans Android Studio et lancer Build > Build APK(s).
Le ZIP contient le projet source, pas un APK déjà compilé.

Pour iPhone, Android mobile et PC : utiliser la version HTML hébergée sur un domaine HTTPS.
Le fichier HTML autonome fourni séparément est destiné à être publié sur GitHub Pages ou un hébergement HTTPS.
