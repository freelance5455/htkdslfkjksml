COAST RUSH V71 — PROJET ANDROID FIRE TV STICK

Cible prévue : Amazon Fire TV Stick 4K Max (1re génération), Fire OS 7.7.1.3 / Android 9.

Contenu :
- index.html à la racine : version V71 autonome pour un outil HTML-to-APK.
- app/src/main/assets/index.html : même jeu intégré dans l'application Android.
- Projet Android natif complet : MainActivity.java, manifeste Fire TV, Gradle et réglages.
- Pont natif WebView et prise en charge des manettes Bluetooth conservés depuis le projet Fire TV.

Version du jeu : V71 — départ et chronométrage synchronisés.
Application ID : fr.lbruz.coastrush.firetv
Version Android : 71.0-firetv

COMPILATION :
1. Décompresser ce ZIP.
2. Ouvrir le dossier CoastRushFireTV dans Android Studio.
3. Laisser Gradle synchroniser le projet avec Java 17 et Android SDK 35.
4. Lancer Build > Build APK(s), ou exécuter : gradle assembleDebug
5. APK attendu : app/build/outputs/apk/debug/app-debug.apk

IMPORTANT :
Ce ZIP est le projet source Android prêt à compiler, pas un APK déjà compilé.
La compilation Android n'a pas été exécutée dans cet environnement (outil Gradle/SDK Android absent).
Le JavaScript du jeu a été vérifié avec node --check.
Aucun test sur Fire TV physique n'a été effectué ici.
Le multijoueur en ligne continue de nécessiter une connexion HTTPS/WSS et un service de signalisation accessible.


VERSION DE BASE DU JEU : CoastRush V71 - TIMERS SYNCHRONISES.
Les deux fichiers index.html (racine et assets Android) sont identiques.
Ce ZIP contient le projet Android source à compiler en APK ; ce n'est pas un APK déjà compilé.


MISE A JOUR FIRE TV - V71 PERFORMANCE MONITOR ACTIF PAR DEFAUT
- Base de jeu : V71 Timers Synchronisés (protocole multijoueur v44).
- HUD performances visible dès le démarrage et bouton PERF : ON/OFF.
- Mesures Web FPS/RAF, timings JS, statistiques Choreographer Android et fréquence écran.
- MainActivity reprend les optimisations natives du projet Fire TV V49 : cache des états manette,
  découverte périodique des contrôleurs, polling WebGamepad mis en cache, suivi Choreographer,
  gestion de pression mémoire et diagnostics écran.
- Le HUD mesure la cadence des callbacks Android, pas le nombre exact d'images réellement présentées par le GPU.
- Projet source Android : nécessite une compilation Gradle pour produire l'APK.


MONITEUR TEMPS REEL : affichage permanent dès le lancement. Aucun bouton PERF ON/OFF ni raccourci de bascule. Les données de diagnostic restent visibles.


CORRECTIF MONITEUR : superposition HTML indépendante du moteur de jeu, visible dès l'ouverture et actualisée en continu à 2 Hz. Elle mesure la cadence requestAnimationFrame, les mesures internes disponibles et les statistiques Android Choreographer si le pont natif est présent.


MONITEUR COMPACT : petit panneau transparent en haut à droite, sans bouton, pour ne pas masquer les commandes et le menu.
