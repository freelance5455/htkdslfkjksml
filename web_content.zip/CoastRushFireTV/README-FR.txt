COAST RUSH V41.2 – FIRE TV STICK 4K MAX – PROJET SOURCE COMPLET

Cette archive est le projet Android source consolidé destiné à une seule synchronisation/build de validation.

CONTENU
- Jeu HTML V41 embarqué dans app/src/main/assets/index.html.
- Chargement local depuis les assets via loadDataWithBaseURL (évite les erreurs file:/// et Page not found).
- Affichage paysage immersif et ratio logique 16:9 conservé.
- Ponts Android pour deux manettes, dimensions écran et statistiques Choreographer.
- Compteur de diagnostic WEB FPS / RAF / Android bridge / callbacks / JS / DRAW / PAD.
- Cache du fond statique et caches bornés de dégradés pour réduire les allocations Canvas répétées.
- LOD existant conservé : réduction déterministe d'environ 10 % de certains décors secondaires Fire TV; objets importants, route et profondeur de vision conservés.
- Version Android 42 (41.2-firestick-complete) pour permettre l'installation comme mise à jour si la signature est identique.

OUVRIR / COMPILER
1. Décompresser le dossier CoastRushFireTV.
2. Ouvrir ce dossier racine dans Android Studio (pas le sous-dossier app).
3. Laisser Gradle synchroniser le plugin Android déclaré dans build.gradle.
4. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).

PRÉREQUIS
- Android Studio récent, JDK 17 ou supérieur.
- Android SDK Platform 35 et Android Gradle Plugin 8.6.1 téléchargé par Gradle.
- Connexion réseau nécessaire au premier sync si les dépendances ne sont pas en cache.

IMPORTANT – LIMITES DE VALIDATION
- Cette archive est un projet source, PAS un APK compilé.
- L'environnement de préparation ne contient ni Gradle installé, ni Android SDK / android.jar : compilation APK impossible ici.
- La syntaxe JavaScript intégrée a été vérifiée avec Node.js; le code Java a été relu et les appels/liaisons contrôlés statiquement, mais n'a pas été compilé contre Android SDK.
- Choreographer mesure la cadence des callbacks UI Android; ce n'est pas une mesure directe des images effectivement présentées par le GPU/HDMI.
- Le cache Canvas et les modifications doivent être validés sur Fire TV Stick réel. Le gain FPS n'est pas garanti avant mesure.
- Le multijoueur HTTPS/WSS nécessite toujours son service de signalisation hébergé; l'APK local ne crée pas ce serveur.
