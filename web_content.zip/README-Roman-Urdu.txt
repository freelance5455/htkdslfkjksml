UDHAR PLUS+ v4

Customer list mein har customer ke saath ek amount box aur do buttons hain:
+ = mazeed udhaar add karein
− = jama paise record karein / baqi kam karein
Misal: baqi Rs 500, amount box mein 200 likh kar − dabayein -> baqi Rs 300.

WhatsApp sharing: Share button backup file download karta hai aur WhatsApp chat kholta hai. WhatsApp mein paperclip > Document se udhar-plus-backup.json attach karke bhejein. Agar Android share sheet support kare to pehle direct file sharing bhi try hoti hai.
Doosre phone par attachment download karein > app mein Backup restore > file select karein.
WhatsApp backup manual hai, automatic live sync nahi.

Data local phone/browser mein save hota hai. App/browser data clear karne se pehle backup zaroor banayein. ZIP source files hain, compiled APK nahi.
