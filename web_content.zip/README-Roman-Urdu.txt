UDHAR PLUS+ — UPDATED WHATSAPP BACKUP VERSION

Features:
- Customer naam aur shuru ka udhaar
- Naya udhaar add (+)
- Jama paise (baqi kam hota hai)
- Hisab dekhein
- Naam delete aur poora hisaab delete
- Backup download
- WhatsApp par data share: Android share menu se WhatsApp select karein
- Backup restore: WhatsApp se JSON file download karke app mein restore karein

WhatsApp share ka tareeqa:
1. App mein “WhatsApp par data share” dabayein.
2. Share menu mein WhatsApp select karke bhai ko backup file bhejein.
3. Doosre phone par WhatsApp attachment download karein.
4. Udhar Plus+ mein “Backup restore” dabayein aur downloaded udhar-plus-backup.json select karein.
5. Har naye hisaab ke baad fresh backup share karein. Ye automatic/live sync nahi hai.

Data isi mobile/browser mein save hota hai. App/browser data clear karne ya app uninstall karne se pehle backup banayein. ZIP source files hain, compiled APK nahi. APK builder mein ZIP upload karein agar woh ZIP accept karta hai; warna index.html upload karein.
