Udhar Plus+ v7 Stable

Is ZIP mein simple index.html app hai. AppsGeyser mein HTML Website/WebView project ke liye index.html upload karein (agar ZIP maange to ye ZIP use karein).

Naya APK install karne se pehle purane app mein Backup download kar lein. Naye app mein Backup restore se JSON file select karein.

Data local phone mein save hota hai; live sync nahi. WhatsApp share manual backup file bhejta hai.
