UDHAR PLUS+ — ONLINE VERSION (SETUP GUIDE)

IMPORTANT
- This package is the app source, not a compiled APK.
- Online cloud sync needs your own Firebase project/config. This HTML intentionally has placeholders until you add that config.
- Easiest sharing method: create one email/password account in the app on Phone 1, then log in with the SAME email/password on Phone 2. Both phones see the same live customer list.
- Do not send your password or Firebase console credentials to anyone.

SETUP FROM YOUR PHONE
1. Open https://console.firebase.google.com/ and sign in with your Google account.
2. Create a Firebase project named Udhar Plus.
3. In project settings, add a Web App (</> icon) named Udhar Plus.
4. Copy the Firebase web config values.
5. In Firebase Authentication > Sign-in method, enable Email/Password.
6. In Firestore Database, create a database. Choose production mode if asked.
7. Open Firestore > Rules and paste the content from firestore.rules, then Publish.
8. Open index.html in a text/code editor and replace these placeholders in firebaseConfig:
   PASTE_API_KEY_HERE
   PASTE_PROJECT_ID_HERE (also in authDomain and storageBucket)
   PASTE_MESSAGING_SENDER_ID_HERE
   PASTE_APP_ID_HERE
   Use the exact values shown by Firebase. Save the file.
9. Upload the edited index.html to a static HTTPS host that serves HTML as a website (for example, Firebase Hosting). Do not upload the placeholder version and expect cloud sync to work.
10. Open the hosted HTTPS page on Phone 1, create account with email/password. On Phone 2 open the same URL and log in with the same email/password.
11. Test with sample customers and download a backup.

WHAT THIS VERSION DOES
- Add customer and starting balance
- Add more udhaar
- Record jama payments (reduces balance)
- View transaction history
- Delete customer and all their history
- Live sync between devices logged into the same account
- Basic offline persistence support; pending sync requires internet to reconnect
- JSON backup download and import

SECURITY NOTE
The Firestore rules restrict each account to its own records. Anyone who has the shared login can see/edit/delete that shop's data. Use a strong password and keep backups. This is a starter implementation, not a substitute for tested accounting software.
