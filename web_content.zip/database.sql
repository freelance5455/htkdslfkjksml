-- =====================================================================
-- MTX - Streaming Platform & Dark Zone Architecture
-- Complete MySQL Database Schema with Prepared Statements & Integrity
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `mtx_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `mtx_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- Table 1: users (Registered Members)
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `member_id` VARCHAR(50) NOT NULL UNIQUE,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NULL UNIQUE,
  `device_model` VARCHAR(100) NOT NULL DEFAULT 'Android Device',
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `is_dark_approved` TINYINT(1) NOT NULL DEFAULT 0,
  `avatar` VARCHAR(255) NULL,
  `last_active` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_member_id` (`member_id`),
  INDEX `idx_users_status` (`status`),
  INDEX `idx_users_last_active` (`last_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 2: admins
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'superadmin',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_admins_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 3: categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `is_dark` TINYINT(1) NOT NULL DEFAULT 0,
  `description` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_categories_dark` (`is_dark`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 4: videos (Strict separation between Normal and Dark sections)
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NULL,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'Trending',
  `description` TEXT NULL,
  `video_path` TEXT NOT NULL,
  `thumbnail_path` TEXT NULL,
  `duration` VARCHAR(20) NOT NULL DEFAULT '00:00',
  `views` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_dark` TINYINT(1) NOT NULL DEFAULT 0,
  `is_published` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_videos_dark` (`is_dark`),
  INDEX `idx_videos_published` (`is_published`),
  INDEX `idx_videos_category` (`category`),
  CONSTRAINT `fk_videos_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 5: photos (Normal & Dark Stills)
DROP TABLE IF EXISTS `photos`;
CREATE TABLE `photos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'Posters & Art',
  `image_path` TEXT NOT NULL,
  `likes` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_dark` TINYINT(1) NOT NULL DEFAULT 0,
  `is_published` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_photos_dark` (`is_dark`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table 6: dark_applications (Face photo submissions)
DROP TABLE IF EXISTS `dark_applications`;
CREATE TABLE `dark_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` VARCHAR(50) NOT NULL,
  `user_name` VARCHAR(100) NOT NULL,
  `face_photo_uri` TEXT NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected', 'revoked') NOT NULL DEFAULT 'pending',
  `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` DATETIME NULL,
  INDEX `idx_dark_user_id` (`user_id`),
  INDEX `idx_dark_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- Seed Default Admin (admin / admin123)
INSERT INTO `admins` (`id`, `username`, `password`, `full_name`, `role`, `created_at`) 
VALUES (1, 'admin', '$2y$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', 'MTX Administrator', 'superadmin', NOW())
ON DUPLICATE KEY UPDATE `username` = 'admin';

-- Seed Standard & Dark Categories
INSERT INTO `categories` (`id`, `name`, `slug`, `is_dark`, `description`) VALUES
(1, 'Trending', 'trending', 0, 'Trending media on MTX'),
(2, 'Action', 'action', 0, 'Cinematic action'),
(3, 'Comedy', 'comedy', 0, 'Humor and entertainment'),
(4, 'Sci-Fi', 'sci-fi', 0, 'Futuristic themes'),
(5, 'Drama', 'drama', 0, 'Dramatic stories'),
(6, 'Music', 'music', 0, 'Audio-visual musical spectacles'),
(7, 'Tech & Gaming', 'tech-gaming', 0, 'Gaming and technological highlights'),
(8, 'Dark Thrillers', 'dark-thrillers', 1, 'Exclusive Dark Site VIP thrillers'),
(9, 'Cyber Noir', 'cyber-noir', 1, 'Dark Cyber Noir visuals'),
(10, 'Obsidian VIP', 'obsidian-vip', 1, 'Underground high-bitrate VIP stream')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);
