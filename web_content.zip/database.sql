-- رحلتي: قاعدة بيانات Supabase
-- شغّل هذا الملف كاملًا في Supabase > SQL Editor

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role text not null default 'passenger' check (role in ('passenger','driver')),
  created_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles(id) on delete cascade,
  origin text not null,
  destination text not null,
  departure_date date not null,
  departure_time time not null,
  seats_total integer not null check (seats_total > 0),
  seats_available integer not null check (seats_available >= 0 and seats_available <= seats_total),
  price numeric(12,2) not null default 0 check (price >= 0),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  passenger_id uuid not null references public.profiles(id) on delete cascade,
  seats integer not null check (seats > 0),
  status text not null default 'confirmed' check (status in ('confirmed','cancelled')),
  created_at timestamptz not null default now()
);

create index if not exists trips_date_idx on public.trips(departure_date);
create index if not exists trips_driver_idx on public.trips(driver_id);
create index if not exists bookings_passenger_idx on public.bookings(passenger_id);
create index if not exists bookings_trip_idx on public.bookings(trip_id);

-- إنشاء profile تلقائيًا بعد التسجيل
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name','مستخدم جديد'),
    new.raw_user_meta_data->>'phone',
    case when new.raw_user_meta_data->>'role' = 'driver' then 'driver' else 'passenger' end
  )
  on conflict (id) do update set
    full_name = excluded.full_name,
    phone = excluded.phone,
    role = excluded.role;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- حجز آمن يمنع تجاوز عدد المقاعد
create or replace function public.book_trip(p_trip_id uuid, p_seats integer)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_booking uuid;
  v_available integer;
begin
  if auth.uid() is null then raise exception 'يجب تسجيل الدخول أولاً'; end if;
  if p_seats is null or p_seats < 1 then raise exception 'عدد المقاعد غير صحيح'; end if;

  select seats_available into v_available
  from public.trips
  where id = p_trip_id
  for update;

  if not found then raise exception 'الرحلة غير موجودة'; end if;
  if v_available < p_seats then raise exception 'المقاعد المتاحة غير كافية'; end if;

  update public.trips
  set seats_available = seats_available - p_seats
  where id = p_trip_id;

  insert into public.bookings(trip_id, passenger_id, seats)
  values(p_trip_id, auth.uid(), p_seats)
  returning id into v_booking;

  return v_booking;
end;
$$;

revoke all on function public.book_trip(uuid,integer) from public;
grant execute on function public.book_trip(uuid,integer) to authenticated;

-- RLS
alter table public.profiles enable row level security;
alter table public.trips enable row level security;
alter table public.bookings enable row level security;

drop policy if exists "profiles_select_authenticated" on public.profiles;
create policy "profiles_select_authenticated" on public.profiles
for select to authenticated using (true);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "trips_public_read" on public.trips;
create policy "trips_public_read" on public.trips
for select to anon, authenticated using (true);

drop policy if exists "drivers_insert_own_trips" on public.trips;
create policy "drivers_insert_own_trips" on public.trips
for insert to authenticated with check (driver_id = auth.uid());

drop policy if exists "drivers_update_own_trips" on public.trips;
create policy "drivers_update_own_trips" on public.trips
for update to authenticated using (driver_id = auth.uid()) with check (driver_id = auth.uid());

drop policy if exists "drivers_delete_own_trips" on public.trips;
create policy "drivers_delete_own_trips" on public.trips
for delete to authenticated using (driver_id = auth.uid());

drop policy if exists "passenger_read_own_bookings" on public.bookings;
create policy "passenger_read_own_bookings" on public.bookings
for select to authenticated using (
  passenger_id = auth.uid()
  or exists (select 1 from public.trips t where t.id = bookings.trip_id and t.driver_id = auth.uid())
);

drop policy if exists "passenger_insert_booking" on public.bookings;
create policy "passenger_insert_booking" on public.bookings
for insert to authenticated with check (passenger_id = auth.uid());

-- لا تسمح للواجهة بتعديل seats_available مباشرة؛ الحجز يتم عبر RPC.
