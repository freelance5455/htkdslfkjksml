create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text unique not null
);

create table if not exists public.chats (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 is_group boolean default false,
 created_by uuid references auth.users(id),
 created_at timestamptz default now()
);

create table if not exists public.chat_members (
 chat_id uuid references public.chats(id) on delete cascade,
 user_id uuid references auth.users(id) on delete cascade,
 primary key(chat_id,user_id)
);

create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(),
 chat_id uuid references public.chats(id) on delete cascade,
 sender_id uuid references auth.users(id),
 content text not null,
 created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.chats enable row level security;
alter table public.chat_members enable row level security;
alter table public.messages enable row level security;

create policy "Read profiles" on public.profiles
for select to authenticated using (true);
create policy "Create own profile" on public.profiles
for insert to authenticated with check (id=auth.uid());
create policy "Update own profile" on public.profiles
for update to authenticated using (id=auth.uid());

create policy "Read member chats" on public.chats
for select to authenticated using (
 exists(select 1 from public.chat_members m
 where m.chat_id=id and m.user_id=auth.uid())
);
create policy "Create chats" on public.chats
for insert to authenticated with check (created_by=auth.uid());

create policy "Read memberships" on public.chat_members
for select to authenticated using (
 exists(select 1 from public.chat_members m
 where m.chat_id=chat_members.chat_id and m.user_id=auth.uid())
);
create policy "Add members" on public.chat_members
for insert to authenticated with check (
 exists(select 1 from public.chats c
 where c.id=chat_id and c.created_by=auth.uid())
 or user_id=auth.uid()
);

create policy "Read messages" on public.messages
for select to authenticated using (
 exists(select 1 from public.chat_members m
 where m.chat_id=messages.chat_id and m.user_id=auth.uid())
);
create policy "Send messages" on public.messages
for insert to authenticated with check (
 sender_id=auth.uid() and exists(
 select 1 from public.chat_members m
 where m.chat_id=messages.chat_id and m.user_id=auth.uid()
 )
);

alter publication supabase_realtime add table public.messages;
