# Build prompt used for Happy Hearts Academy PWA

Act as a senior product designer and front-end engineer. Build a genuinely usable, mobile-first Progressive Web App called **Happy Hearts Academy** for the academy director, **Tarisai**. This must be a working application, not a static mockup.

## Product goal
Create a warm, professional school-management workspace that helps the director manage student profiles, student photographs, birthdays, school events, daily timetable, attendance, assessments, staff, fee records, reports, backups and daily motivation.

## Brand and interface direction
- Brand name: Happy Hearts Academy.
- Motto: “Learn today, lead tomorrow”.
- Personal dashboard greeting must use the director's name: “Good morning, Tarisai!” (change greeting by local time; never say “Welcome Director”).
- Use an inviting but mature early-childhood-school visual identity: warm ivory/cream backgrounds, blush pink accents, deep plum typography, soft sage and muted gold status accents, rounded cards and generous spacing.
- Use responsive adaptive navigation: full side navigation on wider screens and a compact bottom navigation on phones.
- Keep screens simple, readable, touch-friendly and accessible, with meaningful empty states, form labels, keyboard focus states and clear status chips.
- Do not depend on remote fonts, icon CDNs or third-party JavaScript libraries; essential screens must load offline.

## Required product modules
1. **Director dashboard**: named greeting for Tarisai, school/date context, student count, attendance summary, birthdays in the next seven days, upcoming events, today's timetable, school reminders and quick actions.
2. **Student directory**: create, edit and view student profiles. Include full name, class/level, date of birth, admission date, parent/guardian name and phone, status, notes and expected fees. Include a photo-upload control that allows image selection from the gallery or phone camera. Resize/compress photos before saving. Display each learner's photo in directory cards and detail views. Do not seed fake learner records.
3. **Birthday reminder centre**: calculate upcoming birthdays from student dates of birth, show birthdays today and soon, and provide a copyable birthday wish. Never require manually entering a birthday event for each learner.
4. **School calendar and event reminders**: create/edit/delete trips, parent meetings, assessments, holidays, celebrations, staff activities and other events. Include date, optional time, details/location, event type and reminder intervals such as 7, 3, 1 and 0 days before.
5. **Daily timetable**: use this starting schedule and allow edits/additions/deletions:
   - 08:30–09:00 Assembly
   - 09:00–09:30 Lesson 1
   - 09:30–10:00 Lesson 2
   - 10:00–10:30 Lesson 3
   - 10:30–11:00 Break
   - 11:00–11:30 Lesson 4
   - 11:30–12:00 Lesson 5
   - 12:00–12:30 Lesson 6
   - 12:30–13:00 Sleeping / Napping Time
   - 13:00–14:00 Lunch
   - 14:00–15:00 Free Play
   - 15:00 Dismissal
   Highlight the current activity using device local time.
6. **Attendance**: daily register by date and class, with present/absent/late marking and a mark-all-present action. Save records by date.
7. **Assessments**: add learner progress records with date, learning area, progress level and observation/next step.
8. **Staff**: add/edit/delete staff contacts and class assignments.
9. **Fees**: expected fee per student, payment records, payment date/reference, total paid and outstanding balance. Make the currency configurable; use USD as the initial default and allow ZWG, ZAR and GBP.
10. **Reports and backup**: summary counts, CSV student/attendance/event exports, complete JSON backup including photos, and restore from JSON.
11. **Motivation corner**: include at least 50 original short inspirational quotes for educators, school leadership and young learners. Add daily quote selection, search and favourites. Do not reproduce copyrighted quote collections.
12. **Settings**: editable academy name, director's name, motto, currency, notification permission and install guidance.

## Technical requirements
- Build with plain HTML, CSS and JavaScript.
- Include a valid web app manifest, app icons in 192x192 and 512x512 sizes, and a service worker that caches the application shell for offline use.
- Use IndexedDB for local records and photo data, with a localStorage fallback.
- Include install guidance for Android/Chrome and iOS/Safari.
- Request notification permission only after an explicit user action. For mobile persistent notifications, use service-worker `showNotification()`.
- Clearly explain that reliable scheduled notifications while the app is closed require a backend and push service.
- Clearly explain that multi-device sync and separate secure staff accounts require hosted storage, authentication and access-control work before production.
- Provide backup/restore and explain that browser data can be cleared.
- Use defensive input handling, HTML escaping, form validation and responsive layouts.

## Delivery
Return the complete working PWA source folder, a README with run/install instructions and limitations, and this prompt as a separate file. Do not claim the app has been deployed or that a live backend exists unless it actually has.

## Visual refinement update
- Add a theme chooser with named palettes: Candy Pink, Ocean Blue, Lavender Dream, Mint Garden, Soft Sunshine and Peach Blush.
- Persist the selected theme locally and apply it consistently to buttons, navigation, cards, forms, badges, backgrounds and mobile navigation.
- Use a tasteful glassmorphism treatment: translucent surfaces, subtle blur, soft borders and gentle shadows. Maintain text contrast and avoid excessive transparency behind important content.
- Simplify the home screen: one friendly personalised greeting, two clear primary actions, four simple shortcut tiles, today's timetable, upcoming dates, birthday stars and one motivational quote.
- Use plain friendly language instead of technical labels wherever possible. Keep deeper administration tools available without crowding the home screen.
