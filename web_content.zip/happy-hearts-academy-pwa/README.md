# Happy Hearts Academy PWA

A mobile-first, local-first Progressive Web App prototype for Happy Hearts Academy.

## Included

- Personalised Director dashboard: “Good morning/afternoon/evening, Tarisai”.
- Student directory with create/edit/view, class, date of birth, guardian contact, expected fees, status, notes and student photo upload (camera or gallery).
- Photo resizing before storage; student information is kept in browser IndexedDB on the current device.
- Automatic birthday list and birthday message generator.
- School events calendar with configurable 7/3/1/0-day reminders.
- Daily timetable preloaded with the academy schedule previously supplied; editable and extendable.
- Daily attendance register with present / absent / late statuses.
- Learner assessment records and staff directory.
- Fee expected amounts, payment entries and outstanding balance calculations.
- 64 original motivational quotes, quote search and favourites.
- CSV exports and full JSON backup / restore.
- Installable PWA manifest and service worker cache for offline application shell.

## Run locally

PWA installation and service workers require a secure context. Use `localhost` or serve this folder from an HTTPS static host; opening `index.html` directly with `file://` will not activate the PWA features.

For local testing, from this folder run a static server, for example:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in Chrome.

## Install on Android

1. Host the folder over HTTPS (or use localhost for testing).
2. Open the URL in Chrome on Android.
3. Use the browser's **Install app** prompt or menu → **Install app / Add to Home screen**.
4. Open the installed app. Use Settings → Enable / manage to request notification permission.

## Important prototype boundaries

- The app saves data in the browser on this device. It does **not** yet synchronise data between phones, tablets or staff accounts.
- A browser permission and service worker are used for device notifications when the app is opened and checks due reminders. Reliable scheduled notifications while the app is closed require a hosted backend and web-push service.
- The prototype has no login or role-based access control. Before storing real children's records in a shared or production setting, add secure authentication, server-side storage, encrypted transport, access controls, managed backups and a privacy/compliance review.
- Browser storage can be cleared by the user or operating system. Use Reports & backup regularly.
- Currency can be selected in Settings; USD is the initial default and can be changed.

## Technical

No external JavaScript libraries or font/CDN requests are required. The app is built with HTML, CSS, JavaScript, IndexedDB (with localStorage fallback), Web App Manifest, and Service Worker APIs.

## Themes and simplified interface
The app includes six selectable colour themes in Settings: Candy Pink, Ocean Blue, Lavender Dream, Mint Garden, Soft Sunshine and Peach Blush. The selected theme is saved on the device. The refreshed interface uses soft glass-style surfaces, gentle blur, subtle borders and shadows. The home screen is simplified around a personalised greeting, quick shortcuts, today's plan, upcoming dates, birthdays and a daily quote.
