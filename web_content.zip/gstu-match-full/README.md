# GSTU Match — Setup Guide

A campus-only matching app for Gopalganj Science & Technology University
students. React + TypeScript + Firebase (Auth, Firestore, Storage).

## 1. Create a Firebase project

1. Go to https://console.firebase.google.com → **Add project**.
2. Once created, go to **Build → Authentication → Sign-in method** and
   enable **Email/Password**.
3. Go to **Build → Firestore Database → Create database** (start in
   production mode — the rules file below handles security).
4. Go to **Build → Storage → Get started** (also production mode).
5. Go to **Project settings → General → Your apps → Add app → Web**,
   register the app, and copy the config values.

## 2. Configure the app

Copy `.env.example` to `.env` and fill in the values from step 1:

```
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=...
VITE_FIREBASE_PROJECT_ID=...
VITE_FIREBASE_STORAGE_BUCKET=...
VITE_FIREBASE_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
```

In `src/lib/AuthContext.tsx`, update `ALLOWED_EMAIL_DOMAIN` if your
student email domain isn't `gstu.ac.bd`.

## 3. Deploy security rules

Install the Firebase CLI if you don't have it:

```bash
npm install -g firebase-tools
firebase login
firebase init firestore storage   # point at the existing project, keep the rules file paths as-is
firebase deploy --only firestore:rules,storage:rules
```

This pushes `firestore.rules` and `storage.rules` from this project —
**do not skip this step**. Without it, Firestore/Storage fall back to
locked-down defaults and nothing will work, or worse, you leave them
open to everyone.

## 4. Run locally

```bash
npm install
npm run dev
```

## 5. Make yourself an admin

Sign up normally in the app first. Then, in the Firebase console, go to
**Firestore Database → users → (your uid)** and manually add a field:

```
isAdmin: true (boolean)
status: "approved" (string)
```

This unlocks the **Admin** tab in the bottom nav, where you can approve
or reject every other student's signup.

## How the pieces fit together

- **Auth**: Firebase Auth, email/password, restricted at signup to the
  `@gstu.ac.bd` domain (client-side check + you can add a Cloud
  Function later for server-side enforcement).
- **Approval flow**: every new profile is created with `status:
  "pending"`. Users see a waiting screen until an admin flips it to
  `"approved"` in the Admin tab.
- **Matching**: swiping right writes a `likes/{fromUid}_{toUid}` doc.
  The client then checks for the reverse like; if found, both users
  get a `matches/{sortedUidPair}` doc.
- **Chat**: messages live in `matches/{matchId}/messages`, subscribed
  to in real time with Firestore's `onSnapshot`.
- **Photos**: uploaded to Firebase Storage under
  `profile-photos/{uid}/`, with a 5MB size limit enforced both
  client-side and in `storage.rules`.

## What's not included (next steps if you keep going)

- Server-side enforcement of the email domain restriction (right now
  it's a client-side check only — someone could bypass it by calling
  Firebase Auth directly). A Cloud Function `beforeCreate` auth
  trigger closes this gap properly.
- Push notifications for new matches/messages.
- Reporting/blocking other users — important for a dating app before
  a real launch.
- Pagination for the swipe deck (right now it loads all approved
  profiles at once, fine for a campus-sized user base, not fine at
  scale).
- Rate limiting so one account can't spam likes or messages.
