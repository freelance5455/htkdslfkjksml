import React, { useState } from "react";
import "./styles.css";
import { AuthProvider, useAuth } from "./lib/AuthContext";
import AuthScreen from "./screens/AuthScreen";
import PendingScreen from "./screens/PendingScreen";
import ProfileSetup from "./screens/ProfileSetup";
import SwipeScreen from "./screens/SwipeScreen";
import MatchesScreen from "./screens/MatchesScreen";
import ChatScreen from "./screens/ChatScreen";
import AdminScreen from "./screens/AdminScreen";
import { UserProfile } from "./lib/types";

type Tab = "swipe" | "matches" | "profile" | "admin";

const MainApp: React.FC = () => {
  const { profile, logOut } = useAuth();
  const [tab, setTab] = useState<Tab>("swipe");
  const [editingProfile, setEditingProfile] = useState(false);
  const [activeChat, setActiveChat] = useState<{
    matchId: string;
    otherUser: UserProfile;
  } | null>(null);

  if (!profile) return null;

  if (profile.status === "pending" || profile.status === "rejected") {
    return <PendingScreen />;
  }

  // Force profile completion before letting a newly approved
  // student see the deck.
  const needsProfile = !profile.name || !profile.batch;
  if (needsProfile || editingProfile) {
    return <ProfileSetup onDone={() => setEditingProfile(false)} />;
  }

  if (activeChat) {
    return (
      <div className="app-root">
        <ChatScreen
          matchId={activeChat.matchId}
          otherUser={activeChat.otherUser}
          onBack={() => setActiveChat(null)}
        />
      </div>
    );
  }

  return (
    <div className="app-root">
      <header className="app-header">
        <div>
          <div className="logo">
            GSTU <span className="logo-accent">Match</span>
          </div>
          <div className="header-sub">
            {tab === "admin" ? "Admin review" : "Gopalganj Science & Technology University"}
          </div>
        </div>
        <button className="icon-btn" onClick={logOut} aria-label="Log out">
          ⏻
        </button>
      </header>

      {tab === "swipe" && <SwipeScreen />}
      {tab === "matches" && (
        <MatchesScreen
          onOpenChat={(matchId, otherUser) => setActiveChat({ matchId, otherUser })}
        />
      )}
      {tab === "profile" && (
        <div className="empty-state" style={{ maxWidth: 400 }}>
          <div className="empty-icon">{profile.name.charAt(0) || "🎓"}</div>
          <h3>{profile.name}</h3>
          <p>
            {profile.department} · {profile.batch}
            <br />
            {profile.hall}
          </p>
          <button className="btn btn-primary" onClick={() => setEditingProfile(true)}>
            Edit Profile
          </button>
        </div>
      )}
      {tab === "admin" && profile.isAdmin && <AdminScreen />}

      <nav className="bottom-nav">
        <button
          className={`nav-btn ${tab === "swipe" ? "active" : ""}`}
          onClick={() => setTab("swipe")}
        >
          <span className="nav-icon">🔥</span>
          Discover
        </button>
        <button
          className={`nav-btn ${tab === "matches" ? "active" : ""}`}
          onClick={() => setTab("matches")}
        >
          <span className="nav-icon">💬</span>
          Matches
        </button>
        <button
          className={`nav-btn ${tab === "profile" ? "active" : ""}`}
          onClick={() => setTab("profile")}
        >
          <span className="nav-icon">👤</span>
          Profile
        </button>
        {profile.isAdmin && (
          <button
            className={`nav-btn ${tab === "admin" ? "active" : ""}`}
            onClick={() => setTab("admin")}
          >
            <span className="nav-icon">🛡️</span>
            Admin
          </button>
        )}
      </nav>
    </div>
  );
};

const Root: React.FC = () => {
  const { firebaseUser, loading } = useAuth();

  if (loading) {
    return (
      <div className="app-root">
        <div className="empty-state" style={{ marginTop: 80 }}>
          <div className="empty-icon">🎓</div>
          <h3>Loading GSTU Match…</h3>
        </div>
      </div>
    );
  }

  if (!firebaseUser) return <AuthScreen />;
  return <MainApp />;
};

const App: React.FC = () => (
  <AuthProvider>
    <Root />
  </AuthProvider>
);

export default App;
