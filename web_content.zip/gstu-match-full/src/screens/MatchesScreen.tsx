import React, { useEffect, useState } from "react";
import { useAuth, fetchProfile } from "../lib/AuthContext";
import { fetchMyMatches } from "../lib/matching";
import { gradientFor } from "../components/SwipeCard";
import { Match, UserProfile } from "../lib/types";

interface MatchWithProfile {
  match: Match;
  otherUser: UserProfile;
}

interface Props {
  onOpenChat: (matchId: string, otherUser: UserProfile) => void;
}

const MatchesScreen: React.FC<Props> = ({ onOpenChat }) => {
  const { profile } = useAuth();
  const [items, setItems] = useState<MatchWithProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const matches = await fetchMyMatches(profile.uid);
      const withProfiles = await Promise.all(
        matches.map(async (match) => {
          const otherUid = match.users.find((u) => u !== profile.uid)!;
          const otherUser = await fetchProfile(otherUid);
          return otherUser ? { match, otherUser } : null;
        })
      );
      setItems(withProfiles.filter(Boolean) as MatchWithProfile[]);
      setLoading(false);
    })();
  }, [profile]);

  if (loading) {
    return (
      <div className="empty-state" style={{ maxWidth: 400, height: 300 }}>
        <div className="empty-icon">🔄</div>
        <h3>Loading matches</h3>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="empty-state" style={{ maxWidth: 400, height: 300 }}>
        <div className="empty-icon">💬</div>
        <h3>No matches yet</h3>
        <p>Keep swiping — your matches will show up here.</p>
      </div>
    );
  }

  return (
    <div className="matches-list">
      {items.map(({ match, otherUser }) => {
        const [gradA, gradB] = gradientFor(otherUser.uid);
        return (
          <button
            key={match.id}
            className="match-row"
            onClick={() => onOpenChat(match.id, otherUser)}
          >
            <div
              className="match-row-avatar"
              style={{
                background: otherUser.photoURL
                  ? `url(${otherUser.photoURL})`
                  : `linear-gradient(135deg, ${gradA}, ${gradB})`,
              }}
            >
              {!otherUser.photoURL && otherUser.name.charAt(0)}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p className="match-row-name">{otherUser.name}</p>
              <p className="match-row-preview">
                {match.lastMessage ?? `Say hi to ${otherUser.name.split(" ")[0]}!`}
              </p>
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default MatchesScreen;
