import React, { useState } from "react";
import { doc, updateDoc } from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../lib/firebase";
import { useAuth } from "../lib/AuthContext";
import { Department } from "../lib/types";

const DEPARTMENTS: Department[] = [
  "CSE",
  "EEE",
  "Textile Engineering",
  "BBA",
  "English",
  "Food Engineering",
  "Civil Engineering",
];

interface Props {
  onDone: () => void;
}

const ProfileSetup: React.FC<Props> = ({ onDone }) => {
  const { profile, firebaseUser } = useAuth();
  const [name, setName] = useState(profile?.name ?? "");
  const [age, setAge] = useState(profile?.age ?? 20);
  const [gender, setGender] = useState(profile?.gender ?? "Male");
  const [interestedIn, setInterestedIn] = useState(
    profile?.interestedIn ?? "Everyone"
  );
  const [department, setDepartment] = useState<Department>(
    profile?.department ?? "CSE"
  );
  const [batch, setBatch] = useState(profile?.batch ?? "");
  const [hall, setHall] = useState(profile?.hall ?? "");
  const [bio, setBio] = useState(profile?.bio ?? "");
  const [interestsText, setInterestsText] = useState(
    profile?.interests?.join(", ") ?? ""
  );
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(
    profile?.photoURL ?? null
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setError("Photo must be under 5MB.");
      return;
    }
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setError(null);
    setBusy(true);

    try {
      let photoURL = profile?.photoURL ?? null;

      if (photoFile) {
        const storageRef = ref(
          storage,
          `profile-photos/${firebaseUser.uid}/${Date.now()}-${photoFile.name}`
        );
        await uploadBytes(storageRef, photoFile);
        photoURL = await getDownloadURL(storageRef);
      }

      await updateDoc(doc(db, "users", firebaseUser.uid), {
        name: name.trim(),
        age: Number(age),
        gender,
        interestedIn,
        department,
        batch: batch.trim(),
        hall: hall.trim(),
        bio: bio.trim(),
        interests: interestsText
          .split(",")
          .map((i) => i.trim())
          .filter(Boolean)
          .slice(0, 6),
        photoURL,
      });

      onDone();
    } catch (err: any) {
      setError(err.message ?? "Couldn't save your profile. Try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="app-root">
      <header className="app-header" style={{ justifyContent: "center" }}>
        <div>
          <div className="logo">
            Your <span className="logo-accent">Profile</span>
          </div>
          <div className="header-sub">This is what other students will see</div>
        </div>
      </header>

      <div className="auth-card" style={{ maxWidth: 400 }}>
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Profile photo</label>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: "50%",
                  background: photoPreview
                    ? `url(${photoPreview}) center/cover`
                    : "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  flexShrink: 0,
                }}
              />
              <input type="file" accept="image/*" onChange={handlePhotoChange} />
            </div>
          </div>

          <div className="field">
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="age">Age</label>
              <input
                id="age"
                type="number"
                min={18}
                max={35}
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                required
              />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="gender">Gender</label>
              <select
                id="gender"
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
              >
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
            </div>
          </div>

          <div className="field">
            <label htmlFor="interestedIn">Interested in</label>
            <select
              id="interestedIn"
              value={interestedIn}
              onChange={(e) => setInterestedIn(e.target.value as any)}
            >
              <option>Male</option>
              <option>Female</option>
              <option>Everyone</option>
            </select>
          </div>

          <div className="field">
            <label htmlFor="department">Department</label>
            <select
              id="department"
              value={department}
              onChange={(e) => setDepartment(e.target.value as Department)}
            >
              {DEPARTMENTS.map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="batch">Batch</label>
              <input
                id="batch"
                placeholder="e.g. 26th Batch"
                value={batch}
                onChange={(e) => setBatch(e.target.value)}
                required
              />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="hall">Hall</label>
              <input
                id="hall"
                placeholder="e.g. Bijoy 24 Hall"
                value={hall}
                onChange={(e) => setHall(e.target.value)}
              />
            </div>
          </div>

          <div className="field">
            <label htmlFor="bio">Bio</label>
            <textarea
              id="bio"
              placeholder="Something about you…"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={220}
            />
          </div>

          <div className="field">
            <label htmlFor="interests">Interests (comma separated)</label>
            <input
              id="interests"
              placeholder="Chess, Cricket, Photography"
              value={interestsText}
              onChange={(e) => setInterestsText(e.target.value)}
            />
          </div>

          {error && <p className="error-text">{error}</p>}

          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? "Saving…" : "Save Profile"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ProfileSetup;
