import React, { useEffect, useRef, useState } from "react";
import { useAuth } from "../lib/AuthContext";
import { sendMessage, subscribeToMessages } from "../lib/chat";
import { gradientFor } from "../components/SwipeCard";
import { ChatMessage, UserProfile } from "../lib/types";

interface Props {
  matchId: string;
  otherUser: UserProfile;
  onBack: () => void;
}

const ChatScreen: React.FC<Props> = ({ matchId, otherUser, onBack }) => {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const [gradA, gradB] = gradientFor(otherUser.uid);

  useEffect(() => {
    const unsub = subscribeToMessages(matchId, setMessages);
    return unsub;
  }, [matchId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !text.trim()) return;
    const toSend = text;
    setText("");
    await sendMessage(matchId, profile.uid, toSend);
  };

  return (
    <div className="chat-screen">
      <div className="chat-header">
        <button className="icon-btn" onClick={onBack} aria-label="Back">
          ←
        </button>
        <div
          className="match-row-avatar"
          style={{
            background: otherUser.photoURL
              ? `url(${otherUser.photoURL})`
              : `linear-gradient(135deg, ${gradA}, ${gradB})`,
          }}
        >
          {!otherUser.photoURL && otherUser.name.charAt(0)}
        </div>
        <div>
          <p className="match-row-name" style={{ margin: 0 }}>{otherUser.name}</p>
          <p className="match-row-preview" style={{ margin: 0 }}>
            {otherUser.department} · {otherUser.batch}
          </p>
        </div>
      </div>

      <div className="chat-messages">
        {messages.length === 0 && (
          <p style={{ color: "#8B94A3", fontSize: 13, textAlign: "center", marginTop: 20 }}>
            You matched with {otherUser.name}. Send the first message!
          </p>
        )}
        {messages.map((m) => (
          <div
            key={m.id}
            className={`msg-bubble ${
              m.senderUid === profile?.uid ? "msg-mine" : "msg-theirs"
            }`}
          >
            {m.text}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form className="chat-input-row" onSubmit={handleSend}>
        <input
          placeholder="Type a message…"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button className="chat-send-btn" type="submit" aria-label="Send">
          ➤
        </button>
      </form>
    </div>
  );
};

export default ChatScreen;
