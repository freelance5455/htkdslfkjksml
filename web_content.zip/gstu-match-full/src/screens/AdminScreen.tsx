import React, { useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { UserProfile } from "../lib/types";

const AdminScreen: React.FC = () => {
  const [pending, setPending] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const snap = await getDocs(
      query(collection(db, "users"), where("status", "==", "pending"))
    );
    const list: UserProfile[] = [];
    snap.forEach((d) => list.push(d.data() as UserProfile));
    setPending(list.sort((a, b) => a.createdAt - b.createdAt));
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const decide = async (uid: string, status: "approved" | "rejected") => {
    await updateDoc(doc(db, "users", uid), { status });
    setPending((p) => p.filter((u) => u.uid !== uid));
  };

  if (loading) {
    return (
      <div className="empty-state" style={{ maxWidth: 480, height: 200 }}>
        <div className="empty-icon">🔄</div>
        <h3>Loading pending accounts</h3>
      </div>
    );
  }

  if (pending.length === 0) {
    return (
      <div className="empty-state" style={{ maxWidth: 480, height: 200 }}>
        <div className="empty-icon">✅</div>
        <h3>All caught up</h3>
        <p>No pending sign-ups to review.</p>
      </div>
    );
  }

  return (
    <div className="admin-list">
      {pending.map((u) => (
        <div className="admin-row" key={u.uid}>
          <div className="admin-row-top">
            <span className="admin-row-name">{u.name || "(no name set)"}</span>
            <span className="dept-badge">{u.department}</span>
          </div>
          <p className="admin-row-email">
            {u.email} · {u.batch || "batch not set"} · {u.hall || "hall not set"}
          </p>
          <div className="admin-row-actions">
            <button
              className="btn btn-primary"
              onClick={() => decide(u.uid, "approved")}
            >
              Approve
            </button>
            <button
              className="btn btn-ghost"
              onClick={() => decide(u.uid, "rejected")}
            >
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AdminScreen;
