import React, { useState } from "react";
import { useAuth, ALLOWED_EMAIL_DOMAIN } from "../lib/AuthContext";

const AuthScreen: React.FC = () => {
  const { signUp, logIn } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        await signUp(email, password);
      } else {
        await logIn(email, password);
      }
    } catch (err: any) {
      setError(err.message ?? "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="app-root">
      <header className="app-header" style={{ justifyContent: "center" }}>
        <div>
          <div className="logo">
            GSTU <span className="logo-accent">Match</span>
          </div>
          <div className="header-sub">Gopalganj Science &amp; Technology University</div>
        </div>
      </header>

      <div className="auth-card">
        <h1 className="auth-title">
          {mode === "signup" ? "Create your account" : "Welcome back"}
        </h1>
        <p className="auth-sub">
          {mode === "signup"
            ? `Sign up with your @${ALLOWED_EMAIL_DOMAIN} email. An admin reviews new accounts before you can start swiping.`
            : "Log in to continue."}
        </p>

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">University email</label>
            <input
              id="email"
              type="email"
              placeholder={`yourname@${ALLOWED_EMAIL_DOMAIN}`}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={6}
              required
            />
          </div>

          {error && <p className="error-text">{error}</p>}

          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? "Please wait…" : mode === "signup" ? "Sign Up" : "Log In"}
          </button>
        </form>

        <div className="switch-link">
          {mode === "signup" ? (
            <>
              Already have an account?{" "}
              <button onClick={() => setMode("login")}>Log in</button>
            </>
          ) : (
            <>
              New here?{" "}
              <button onClick={() => setMode("signup")}>Sign up</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
