import React from "react";
import { useAuth } from "../lib/AuthContext";

const PendingScreen: React.FC = () => {
  const { profile, logOut } = useAuth();

  const rejected = profile?.status === "rejected";

  return (
    <div className="app-root">
      <div className="status-screen">
        <div className="status-icon">{rejected ? "🚫" : "⏳"}</div>
        <h2>{rejected ? "Account not approved" : "Almost there"}</h2>
        <p>
          {rejected
            ? "Your account wasn't approved for GSTU Match. If you think this is a mistake, contact the admin team."
            : "Your account is waiting for admin verification. This usually takes a day or two — check back soon."}
        </p>
        <button className="btn btn-ghost" onClick={logOut}>
          Log Out
        </button>
      </div>
    </div>
  );
};

export default PendingScreen;
