import React, { useEffect, useMemo, useState } from "react";
import SwipeCard, { gradientFor } from "../components/SwipeCard";
import { useAuth } from "../lib/AuthContext";
import { fetchCandidateDeck, recordLike, recordPass } from "../lib/matching";
import { Match, UserProfile } from "../lib/types";

const MatchModal: React.FC<{ student: UserProfile; onClose: () => void }> = ({
  student,
  onClose,
}) => {
  const [gradA, gradB] = gradientFor(student.uid);
  return (
    <div className="match-overlay" onClick={onClose}>
      <div className="match-modal" onClick={(e) => e.stopPropagation()}>
        <div className="match-title">It's a Match!</div>
        <div
          className="match-avatar"
          style={{
            background: student.photoURL
              ? `url(${student.photoURL})`
              : `linear-gradient(135deg, ${gradA}, ${gradB})`,
          }}
        >
          {!student.photoURL && student.name.charAt(0)}
        </div>
        <p className="match-sub">
          You and {student.name} liked each other. Say assalamu alaikum!
        </p>
        <button className="btn btn-primary" onClick={onClose}>
          Keep Browsing
        </button>
      </div>
    </div>
  );
};

const SwipeScreen: React.FC = () => {
  const { profile } = useAuth();
  const [deck, setDeck] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [matchedStudent, setMatchedStudent] = useState<UserProfile | null>(
    null
  );
  const [busySwipe, setBusySwipe] = useState(false);

  useEffect(() => {
    if (!profile) return;
    fetchCandidateDeck(profile.uid).then((d) => {
      setDeck(d);
      setLoading(false);
    });
  }, [profile]);

  const topTwo = useMemo(() => deck.slice(0, 2), [deck]);

  const handleSwipe = async (direction: "left" | "right") => {
    if (!profile || deck.length === 0 || busySwipe) return;
    const current = deck[0];
    setBusySwipe(true);

    try {
      if (direction === "right") {
        const match: Match | null = await recordLike(profile.uid, current.uid);
        if (match) setMatchedStudent(current);
      } else {
        await recordPass(profile.uid, current.uid);
      }
      setDeck((d) => d.slice(1));
    } finally {
      setBusySwipe(false);
    }
  };

  const resetDeck = async () => {
    if (!profile) return;
    setLoading(true);
    const d = await fetchCandidateDeck(profile.uid);
    setDeck(d);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="deck-area">
        <div className="empty-state">
          <div className="empty-icon">🔄</div>
          <h3>Finding students near you</h3>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="deck-area">
        {topTwo.length > 0 ? (
          topTwo
            .slice()
            .reverse()
            .map((student, idx) => (
              <SwipeCard
                key={student.uid}
                student={student}
                isTop={idx === topTwo.length - 1}
                onSwipe={handleSwipe}
              />
            ))
        ) : (
          <div className="empty-state">
            <div className="empty-icon">🎓</div>
            <h3>That's everyone for now</h3>
            <p>Check back later as more students join and get approved.</p>
            <button className="btn btn-primary" onClick={resetDeck}>
              Refresh
            </button>
          </div>
        )}
      </div>

      {topTwo.length > 0 && (
        <div className="action-row">
          <button
            className="action-btn action-nope"
            aria-label="Pass"
            onClick={() => handleSwipe("left")}
            disabled={busySwipe}
          >
            ✕
          </button>
          <button
            className="action-btn action-like"
            aria-label="Like"
            onClick={() => handleSwipe("right")}
            disabled={busySwipe}
          >
            ♥
          </button>
        </div>
      )}

      {matchedStudent && (
        <MatchModal
          student={matchedStudent}
          onClose={() => setMatchedStudent(null)}
        />
      )}
    </>
  );
};

export default SwipeScreen;
