import React, { useRef, useState } from "react";
import { UserProfile } from "../lib/types";

interface Props {
  student: UserProfile;
  onSwipe: (direction: "left" | "right") => void;
  isTop: boolean;
}

const GRADIENT_PALETTE: [string, string][] = [
  ["#FF6B5B", "#C44536"],
  ["#4ECDC4", "#2C8C86"],
  ["#8B5CF6", "#5B3A9E"],
  ["#F59E0B", "#B45309"],
  ["#EC4899", "#9D174D"],
  ["#10B981", "#047857"],
];

const gradientFor = (uid: string) => {
  let hash = 0;
  for (let i = 0; i < uid.length; i++) hash = uid.charCodeAt(i) + ((hash << 5) - hash);
  return GRADIENT_PALETTE[Math.abs(hash) % GRADIENT_PALETTE.length];
};

const SwipeCard: React.FC<Props> = ({ student, onSwipe, isTop }) => {
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const startX = useRef(0);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (!isTop) return;
    setDragging(true);
    startX.current = e.clientX;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragging || !isTop) return;
    setDragX(e.clientX - startX.current);
  };

  const finishDrag = () => {
    if (!dragging) return;
    setDragging(false);
    if (dragX > 100) onSwipe("right");
    else if (dragX < -100) onSwipe("left");
    setDragX(0);
  };

  const rotation = dragX / 18;
  const likeOpacity = Math.min(Math.max(dragX / 100, 0), 1);
  const nopeOpacity = Math.min(Math.max(-dragX / 100, 0), 1);
  const [gradA, gradB] = gradientFor(student.uid);

  return (
    <div
      className="swipe-card"
      style={{
        transform: isTop
          ? `translateX(${dragX}px) rotate(${rotation}deg)`
          : "scale(0.96) translateY(10px)",
        transition: dragging ? "none" : "transform 0.35s cubic-bezier(.2,.8,.3,1)",
        zIndex: isTop ? 10 : 5,
        opacity: isTop ? 1 : 0.85,
        cursor: isTop ? (dragging ? "grabbing" : "grab") : "default",
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={finishDrag}
      onPointerLeave={finishDrag}
    >
      <div
        className="card-photo"
        style={{
          background: student.photoURL
            ? `url(${student.photoURL}) center/cover`
            : `linear-gradient(135deg, ${gradA}, ${gradB})`,
        }}
      >
        <div className="stamp stamp-like" style={{ opacity: likeOpacity }}>LIKE</div>
        <div className="stamp stamp-nope" style={{ opacity: nopeOpacity }}>NOPE</div>
        <div className="id-strip">
          <div className="id-strip-label">GSTU STUDENT ID</div>
          <div className="id-strip-batch">{student.batch}</div>
        </div>
        {!student.photoURL && (
          <div className="card-photo-initial">{student.name.charAt(0)}</div>
        )}
      </div>

      <div className="card-info">
        <div className="card-info-top">
          <h2>
            {student.name}, <span className="age">{student.age}</span>
          </h2>
          <span className="dept-badge">{student.department}</span>
        </div>
        <p className="card-meta">{student.hall || "Off campus"}</p>
        <p className="card-bio">{student.bio}</p>
        <div className="chip-row">
          {student.interests.map((interest) => (
            <span className="chip" key={interest}>{interest}</span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SwipeCard;
export { gradientFor };
