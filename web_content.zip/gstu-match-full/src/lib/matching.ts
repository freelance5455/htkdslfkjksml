import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  setDoc,
  where,
} from "firebase/firestore";
import { db } from "./firebase";
import { Match, UserProfile } from "./types";

/** Deterministic match id so both users converge on the same doc. */
const matchId = (a: string, b: string) => [a, b].sort().join("_");

/**
 * Records a like from `fromUid` to `toUid`. If `toUid` already liked
 * `fromUid` back, creates a match doc and returns it. Otherwise
 * returns null.
 */
export const recordLike = async (
  fromUid: string,
  toUid: string
): Promise<Match | null> => {
  await setDoc(doc(db, "likes", `${fromUid}_${toUid}`), {
    id: `${fromUid}_${toUid}`,
    fromUid,
    toUid,
    createdAt: Date.now(),
  });

  const reverseLikeSnap = await getDoc(
    doc(db, "likes", `${toUid}_${fromUid}`)
  );

  if (!reverseLikeSnap.exists()) return null;

  const id = matchId(fromUid, toUid);
  const match: Match = {
    id,
    users: [fromUid, toUid],
    createdAt: Date.now(),
  };
  await setDoc(doc(db, "matches", id), match);
  return match;
};

export const recordPass = async (fromUid: string, toUid: string) => {
  // Stored so passed profiles don't reappear in the deck.
  await setDoc(doc(db, "passes", `${fromUid}_${toUid}`), {
    fromUid,
    toUid,
    createdAt: Date.now(),
  });
};

/**
 * Fetches approved profiles the current user hasn't already
 * liked or passed on, excluding themselves.
 */
export const fetchCandidateDeck = async (
  currentUid: string
): Promise<UserProfile[]> => {
  const approvedQuery = query(
    collection(db, "users"),
    where("status", "==", "approved")
  );
  const [usersSnap, likesSnap, passesSnap] = await Promise.all([
    getDocs(approvedQuery),
    getDocs(
      query(collection(db, "likes"), where("fromUid", "==", currentUid))
    ),
    getDocs(
      query(collection(db, "passes"), where("fromUid", "==", currentUid))
    ),
  ]);

  const alreadySwiped = new Set<string>();
  likesSnap.forEach((d) => alreadySwiped.add(d.data().toUid));
  passesSnap.forEach((d) => alreadySwiped.add(d.data().toUid));

  const candidates: UserProfile[] = [];
  usersSnap.forEach((d) => {
    const u = d.data() as UserProfile;
    if (u.uid !== currentUid && !alreadySwiped.has(u.uid)) {
      candidates.push(u);
    }
  });

  // Simple shuffle so the deck order isn't just createdAt.
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }
  return candidates;
};

export const fetchMyMatches = async (
  currentUid: string
): Promise<Match[]> => {
  const snap = await getDocs(
    query(collection(db, "matches"), where("users", "array-contains", currentUid))
  );
  const matches: Match[] = [];
  snap.forEach((d) => matches.push(d.data() as Match));
  return matches.sort((a, b) => b.createdAt - a.createdAt);
};

export { matchId };
