import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
} from "firebase/firestore";
import { db } from "./firebase";
import { ChatMessage } from "./types";

/**
 * Subscribes to messages in a match's chat, ordered oldest to
 * newest. Returns an unsubscribe function.
 */
export const subscribeToMessages = (
  matchId: string,
  callback: (messages: ChatMessage[]) => void
) => {
  const q = query(
    collection(db, "matches", matchId, "messages"),
    orderBy("createdAt", "asc")
  );
  return onSnapshot(q, (snap) => {
    const messages: ChatMessage[] = [];
    snap.forEach((d) =>
      messages.push({ id: d.id, ...d.data() } as ChatMessage)
    );
    callback(messages);
  });
};

export const sendMessage = async (
  matchId: string,
  senderUid: string,
  text: string
) => {
  const trimmed = text.trim();
  if (!trimmed) return;

  await addDoc(collection(db, "matches", matchId, "messages"), {
    senderUid,
    text: trimmed,
    createdAt: Date.now(),
  });

  await updateDoc(doc(db, "matches", matchId), {
    lastMessage: trimmed,
    lastMessageAt: Date.now(),
  });
};
