export type Department =
  | "CSE"
  | "EEE"
  | "Textile Engineering"
  | "BBA"
  | "English"
  | "Food Engineering"
  | "Civil Engineering";

export type ApprovalStatus = "pending" | "approved" | "rejected";

export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  age: number;
  gender: "Male" | "Female" | "Other";
  interestedIn: "Male" | "Female" | "Everyone";
  department: Department;
  batch: string; // e.g. "26th Batch"
  hall: string;
  bio: string;
  interests: string[];
  photoURL: string | null;
  status: ApprovalStatus;
  isAdmin?: boolean;
  createdAt: number; // epoch ms
}

export interface Like {
  id: string; // `${fromUid}_${toUid}`
  fromUid: string;
  toUid: string;
  createdAt: number;
}

export interface Match {
  id: string; // sorted uid pair joined by "_"
  users: [string, string];
  createdAt: number;
  lastMessage?: string;
  lastMessageAt?: number;
}

export interface ChatMessage {
  id: string;
  senderUid: string;
  text: string;
  createdAt: number;
}
