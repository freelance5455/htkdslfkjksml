---
name: Neo-Metro
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c0c7d4'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#8a919e'
  outline-variant: '#404752'
  surface-tint: '#a3c9ff'
  primary: '#a3c9ff'
  on-primary: '#00315c'
  primary-container: '#0078d4'
  on-primary-container: '#ffffff'
  inverse-primary: '#0060ab'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#c8c6c5'
  on-tertiary: '#303030'
  tertiary-container: '#777676'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d3e3ff'
  primary-fixed-dim: '#a3c9ff'
  on-primary-fixed: '#001c39'
  on-primary-fixed-variant: '#004883'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 76px
    letterSpacing: -0.02em
  display-md:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is a modern evolution of Swiss-inspired digital design, emphasizing content over chrome. It targets power users and professionals who value information density, motion-driven navigation, and absolute clarity.

The aesthetic is **High-Contrast / Bold** with a focus on **Minimalism**. It eliminates shadows and gradients in favor of flat color blocks, rigid grid structures, and massive typography. The emotional response is one of efficiency, confidence, and digital honesty—where the interface does not pretend to be physical, but rather a pure digital surface.

## Colors
The palette is built on a "High-Contrast Dark" foundation. The primary background is absolute black (`#000000`) to maximize legibility and screen efficiency. 

- **Primary**: A vibrant cobalt blue used for accentuation and interactive states.
- **Secondary**: Pure white, reserved exclusively for primary text and high-priority iconography.
- **Tertiary**: A deep charcoal for subtle containers or grouping elements without breaking the flat aesthetic.
- **Neutral**: The canvas color.

Color should be used sparingly but boldly to indicate focus or progress. Interaction states (hover/press) should use color inversion rather than opacity shifts.

## Typography
This design system employs **Inter** for its clean, neutral, and highly legible Swiss-style characteristics. The typographic hierarchy is the primary driver of the layout.

- **Headlines**: Must be bold or extra-bold. Large display sizes should use tight letter spacing to create a compact, impactful look.
- **Body**: Regular weight with generous line height to ensure readability against high-contrast backgrounds.
- **Labels**: Use uppercase styling for all labels and small buttons to create a "wayfinding" feel similar to signage.
- **Alignment**: Text should strictly follow the grid. Large headlines may intentionally bleed off the right edge of the screen to suggest horizontal continuity (the "Panorama" effect).

## Layout & Spacing
The layout follows a **Fixed Grid** logic with strong vertical rhythm. 

- **Grid**: A 12-column grid for desktop and a 4-column grid for mobile.
- **Rhythm**: All spacing is based on a 4px baseline. Components should be separated by large, purposeful gaps (32px+) to prevent visual clutter.
- **Safe Areas**: Maintain a significant left-hand margin (the "Gutter") to house vertical titles or navigation markers.
- **Horizontal Flow**: Implement horizontal scrolling sections for "hub" pages, where content tiles extend beyond the viewport to encourage discovery.

## Elevation & Depth
This design system rejects physical depth. There are no shadows, blurs, or gradients.

- **Tonal Layers**: Hierarchy is achieved through size and color intensity. The "top" layer is often the most vibrant or the largest text.
- **Flat Planes**: Elements sit on the same Z-axis. When a modal or "flyout" appears, it replaces the current view or slides in as a solid, opaque block of color that completely obscures what is beneath it.
- **Motion as Depth**: Depth is implied through movement—elements sliding at different speeds (parallax) during transitions rather than visual styling.

## Shapes
The shape language is strictly **Sharp**. 

Every element—from buttons and input fields to image containers and cards—must have 90-degree corners. This reinforces the systematic, architectural nature of the design system. Avoid any usage of border-radius. Borders, when used, should be 2px thick and high-contrast (White or Primary).

## Components
- **Buttons**: Rectangular blocks with solid primary color backgrounds and white text. Use uppercase bold labels. Secondary buttons are transparent with a 2px white border.
- **Tiles (Cards)**: These are the core navigation units. They are solid blocks of color or edge-to-edge imagery. Text within tiles should be bottom-aligned.
- **Input Fields**: Represented by a simple 2px bottom border or a full-width outlined box. No background fill unless focused.
- **Lists**: Clean lines of text separated by 1px dividers or significant whitespace. Iconography in lists should be monolinear and geometric.
- **Pivot/Tabs**: Use large, bold horizontal text headers. The active tab is indicated by color (Primary), while inactive tabs are dimmed (Medium Gray).
- **Progress**: Use a series of moving dots or a solid, fast-moving bar rather than a spinning wheel to maintain the "digital" feel.