---
name: Modern Metro Dynamic
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c3c5d8'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#8d90a2'
  outline-variant: '#434656'
  surface-tint: '#b6c4ff'
  primary: '#b6c4ff'
  on-primary: '#002780'
  primary-container: '#0050ef'
  on-primary-container: '#d5dbff'
  inverse-primary: '#004ee9'
  secondary: '#ffb3b3'
  on-secondary: '#680014'
  secondary-container: '#a30226'
  on-secondary-container: '#ffadad'
  tertiary: '#6cdf58'
  on-tertiary: '#003a00'
  tertiary-container: '#007200'
  on-tertiary-container: '#83f76d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#001550'
  on-primary-fixed-variant: '#003ab3'
  secondary-fixed: '#ffdad9'
  secondary-fixed-dim: '#ffb3b3'
  on-secondary-fixed: '#410009'
  on-secondary-fixed-variant: '#920020'
  tertiary-fixed: '#88fc71'
  tertiary-fixed-dim: '#6cdf58'
  on-tertiary-fixed: '#002200'
  on-tertiary-fixed-variant: '#005300'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-hero:
    fontFamily: Archivo Narrow
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Archivo Narrow
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 52px
  headline-lg-mobile:
    fontFamily: Archivo Narrow
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 40px
  section-header:
    fontFamily: Archivo Narrow
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
spacing:
  tile-gap: 12px
  screen-margin: 24px
  section-padding: 48px
  baseline-unit: 4px
---

## Brand & Style

The design system is an evolution of the Metro UI philosophy, prioritizing content over chrome and motion over static ornamentation. It targets an audience that values efficiency, information density, and a distinct digital-first aesthetic. 

The style is **Modern Brutalist/Minimalist**, characterized by high-contrast layouts, massive typographic scales, and a complete absence of gradients, shadows, or rounded corners. The emotional response is one of "authentic digital" clarity—nothing is hidden behind skeuomorphic metaphors. The interface feels fast, focused, and utilitarian, using bold blocks of color and motion to guide the user's eye through information hierarchies.

## Colors

The design system utilizes a high-contrast dark mode as the default state to maximize power efficiency and visual impact. The palette is dominated by pure black (`#000000`) backgrounds and crisp white (`#FFFFFF`) text.

**Theme Colors:**
The system supports four primary accents that define the "brand" of the current session:
- **Cobalt:** The default professional blue.
- **Crimson:** High-energy, bold red.
- **Emerald:** Organic, vibrant green.
- **Mango:** Warm, energetic orange.

These colors are used for "Tiles," interactive states, and progress indicators. Semantic colors (Success, Warning, Error) should remain consistent across themes to ensure clarity.

## Typography

Typography is the primary driver of the design system. We use **Archivo Narrow** for headlines to echo the condensed, impactful look of classic digital signage, and **Inter** for body copy to ensure maximum legibility at small scales.

**Hierarchy Rules:**
- Large display text often bleeds off the right edge of the screen to indicate horizontal scroll (Panorama view).
- Headers use lowercase or uppercase strictly to denote hierarchy; avoid mixed-case in section titles.
- For Arabic (RTL) support, the font-weight is increased by one level to maintain the same visual "gravity" as the Latin condensed characters.

## Layout & Spacing

The layout is built on a **Modular Grid System** optimized for "Tiles."

**The Panorama Concept:**
Layouts extend horizontally beyond the viewport. The "Canvas" is often wider than the screen, encouraging users to swipe.

- **Desktop/Tablet:** Uses a 12-column grid with a 12px gutter.
- **Mobile:** Uses a 2-column "Tile" grid.
- **Bi-directional Support:** For Arabic (RTL), the entire layout flips. The "Panorama" entrance starts from the right and scrolls left. Navigation headers and back-arrows are mirrored.

**Spacing Rhythm:**
All spacing is a multiple of **4px**. Use `24px` for outer screen margins to ensure content doesn't feel cramped against the bezel.

## Elevation & Depth

This design system rejects traditional Z-axis depth. There are no shadows or blurs.

**Motion as Depth:**
Instead of shadows, depth is conveyed through **Parallax Motion** and **Tonal Layering**:
- **Background Layer:** Pure black or a very dark neutral.
- **Content Layer:** High-contrast tiles and text.
- **Interactions:** When a tile is pressed, it tilts inward using a 3D perspective transform (Tilt Effect), rather than changing shadow density.
- **Overlays:** Full-screen modal "Flyouts" slide in from the side, completely replacing the view or dimming the background with a 60% black overlay.

## Shapes

The shape language is strictly **Rectangular**. 

- All buttons, tiles, and input fields must have a `0px` border radius. 
- Elements are defined by their boundary lines and background fills.
- Use thick borders (2px to 3px) for ghost buttons to maintain a "heavy" digital feel.
- Circular shapes are reserved exclusively for **Avatar images** and **Icon Buttons** (enclosed in a 1px stroke circle) to differentiate "people" or "actions" from "content tiles."

## Components

**Tiles:**
The core component. Tiles come in three sizes: Small (1x1), Medium (2x2), and Wide (4x2). They use the active theme color as their background. Content inside tiles should be bottom-aligned.

**Buttons:**
Primary buttons are solid blocks of the theme color with white text. Secondary buttons are "Ghost" style: 2px white border, no fill, white text.

**Input Fields:**
Large, 48px height minimum. 2px white border on all sides. When focused, the border and label change to the active theme color.

**Selection Controls:**
- **Checkboxes:** Square, 0px radius.
- **Toggle Switches:** Rectangular "pills" that slide horizontally, using theme colors for the 'On' state.

**Lists:**
Items are separated by wide gaps (12px-16px) rather than divider lines. Use "Inter" Medium for list headers and "Inter" Regular for subtext in a 60% opacity white.

**AppBar:**
A bottom-docked bar containing icon buttons inside circles. For RTL, the order of the icons is reversed.