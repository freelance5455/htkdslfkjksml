---
name: Metro Heritage
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c3c5d8'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#8d90a2'
  outline-variant: '#434656'
  surface-tint: '#b6c4ff'
  primary: '#b6c4ff'
  on-primary: '#002780'
  primary-container: '#0050ef'
  on-primary-container: '#d5dbff'
  inverse-primary: '#004ee9'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffb5a0'
  on-tertiary: '#601500'
  tertiary-container: '#b53001'
  on-tertiary-container: '#ffd3c7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#001550'
  on-primary-fixed-variant: '#003ab3'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffdbd1'
  tertiary-fixed-dim: '#ffb5a0'
  on-tertiary-fixed: '#3b0900'
  on-tertiary-fixed-variant: '#872100'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-hero:
    fontFamily: Libre Franklin
    fontSize: 72px
    fontWeight: '300'
    lineHeight: 80px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Libre Franklin
    fontSize: 42px
    fontWeight: '300'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: Libre Franklin
    fontSize: 32px
    fontWeight: '300'
    lineHeight: 36px
  subheader-bold:
    fontFamily: Libre Franklin
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-md:
    fontFamily: Libre Franklin
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Libre Franklin
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
  numeral-xl:
    fontFamily: Libre Franklin
    fontSize: 56px
    fontWeight: '300'
    lineHeight: 60px
spacing:
  margin-page: 24px
  gutter-grid: 12px
  touch-target-min: 48px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system adopts a **Modern Digital-First Minimalism** style, heavily inspired by the authentic Metro design language. It prioritizes content over chrome, eliminating all skeuomorphic effects like gradients, shadows, and bevels. The UI is characterized by a "Motion over Ornamentation" philosophy, where the hierarchy is established through extreme typographic contrast and a rigid grid.

The emotional response is one of efficiency, speed, and precision. It is designed for a mobile-first experience, specifically a dialer app, where utility and readability are paramount. The aesthetic is "Honest," meaning pixels are used to create digital shapes rather than mimicking physical objects.

**Core Principles:**
- **Flat Surface:** No depth through shadows; hierarchy is achieved via size and color.
- **Bold Typography:** Text is the primary UI element.
- **High Contrast:** Pure blacks and vibrant accents for maximum legibility.
- **Information Density:** Clean, spacious, but high-utility layout.

## Colors

The system uses a strictly disciplined color palette optimized for OLED screens and high readability.

- **Primary (Cobalt Blue):** Used for interactive elements, active states, and highlights.
- **Background (Black):** A true black (#000000) is used for the canvas to provide infinite contrast and battery efficiency on mobile devices.
- **Foreground (White):** All primary text and iconography use pure white for maximum legibility.
- **Semantic Colors:** Emerald Green for "Call/Accept" and Crimson Red for "End/Decline," adhering to the same flat, high-saturation aesthetic.

Do not use transparencies for text; use solid shades of grey (e.g., #A4A4A4) for secondary information to maintain the "flat" integrity.

## Typography

Typography is the "Graphic Soul" of this design system. Since Segoe WP is unavailable, **Libre Franklin** is used for its clean, geometric, and utilitarian Swiss-style grotesque features that mirror the original Metro spirit.

**Arabic Handling:**
The typography must support Right-to-Left (RTL) orientation. Use the same weight logic: Thin/Light weights for large headers (e.g., "الأسماء") and Bold weights for subheaders or section labels (e.g., "الأخيرة").

**Hierarchy Rules:**
- **Headlines:** Must be extra-large and set in Light (300) weight. They often bleed slightly off the right or left edge to suggest horizontal scrolling (Panorama view).
- **Subheaders:** Always Bold (700) and often uppercase to create a strong visual anchor.
- **Numerals:** The dial pad uses Light (300) numerals for a sleek, technical look.

## Layout & Spacing

The layout is built on a rigid **"Swiss Grid"** system. It uses a fixed-width philosophy for core components but allows for horizontal "Panorama" or "Pivot" movement.

- **Margins:** A standard 24px margin is applied to the left and right of the screen (mirrored for RTL). 
- **The Pivot Pattern:** For the dialer, use a Pivot layout where the main header (e.g., "الهاتف") sits at the top, and sub-views (سجل المكالمات, لوحة المفاتيح, المفضلة) are arranged horizontally.
- **Touch Targets:** No interactive element should be smaller than 48px. For the dial pad, buttons should occupy equal segments of a 3-column grid, maximizing the surface area for thumb input.
- **Alignment:** All text must align to a strict vertical axis. Do not center-align text in lists; keep it flush-right for Arabic.

## Elevation & Depth

This design system utilizes **Zero Elevation**. There are no shadows, no Z-axis offsets, and no light sources.

- **Tonal Distinction:** Depth is signaled through "Chrome vs. Content." The background is always #000000. Interactive tiles or list items use the Primary Color (#0050ef) or solid dark grey (#1F1F1F) to differentiate areas.
- **Active State:** When an element is pressed, it should invert colors or tilt slightly (3D transform) without adding a shadow.
- **Overlays:** Use full-screen solid color transitions or high-contrast modals that occupy the entire viewport to maintain the flat aesthetic.

## Shapes

The shape language is strictly **Rectilinear**.

- **Square Edges:** All buttons, tiles, and input containers must have 0px border-radius. Curves are only permitted in circular iconography to provide a visual break from the grid.
- **Circle Icons:** Icons (like "Add Contact" or "Settings") must be enclosed in a simple 1px or 2px stroke circle. This is the only exception to the "square" rule and serves to identify primary actions.
- **Tiles:** Use square or rectangular tiles for the home screen or quick-dial contacts.

## Components

**Buttons (Action Bar):**
Located at the bottom of the screen. Icons are simple, white, 2px stroke weight, enclosed in a circle. Labels appear below the icon in small, bold caps (e.g., "إضافة").

**Dial Pad:**
A 3x4 grid of buttons. Numbers are large and thin. Secondary letters/characters (Arabic alphabet) are placed in the corner of each button in a smaller, bold weight. No borders between keys; use the grid spacing to define the buttons.

**List Items:**
Used for "Recent Calls." Features a large bold name in white, and a secondary label below in grey (e.g., "محمول، منذ ساعتين"). No dividers; use whitespace to separate items.

**Input Fields:**
Simple rectangular boxes with a 2px white border. When focused, the border changes to the Primary Cobalt Blue. Text inside is flush-right for Arabic.

**Chips/Tags:**
Rectangular blocks with solid background color and high-contrast text. No rounded corners.

**The "Tile":**
For favorite contacts, use a large square block with a photo that fills the entire area, or a solid Primary Blue block with the contact's initials in the center.