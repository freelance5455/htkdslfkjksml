# Mamang Billing Android — v1.8

Aplikasi billing WiFi RT/RWNet dengan antarmuka biru-putih mengikuti referensi, dibuat untuk **Mamang Koneksi (Tawab Hidayat)**.

## Login awal
- **NOC / Admin** — username `admin`, password `root@sastra` (Full Support).
- **Staff / Kasir** — username `staff`, password `1234` (akses operasional).

Ganti password awal sebelum digunakan untuk operasional. Data akun demo disimpan lokal di perangkat.

## Fitur
- Dashboard statistik pelanggan, pelanggan aktif, pemasukan, lunas/belum bayar, jatuh tempo, tiket komplain aktif, grafik pendapatan, diagram donat dan batang.
- Pelanggan: tambah, edit, hapus, cari, mode PPPoE/Voucher, paket, harga dan jatuh tempo.
- Kasir: pembayaran tunai, transfer bank, QRIS, e-wallet; riwayat transaksi; edit/hapus transaksi; cetak struk.
- Pengaturan template struk: nama, kontak, footer, logo melalui URL gambar.
- Paket PPPoE/Voucher: tambah, edit, hapus dan harga.
- Tiket komplain: nomor tiket otomatis, prioritas, status, kirim melalui Fonnte dan Telegram Bot API bila token dan tujuan dikonfigurasi.
- Pengaturan: akun aplikasi (Admin/Full Support dan User/Kasir), identitas usaha, Fonnte, Telegram, rekening bank/e-wallet, backup dan restore JSON.
- Laporan pelanggan, transaksi dan tiket komplain dapat diekspor sebagai CSV UTF-8 yang kompatibel dengan Microsoft Excel/Google Sheets.

## Build APK melalui GitHub Actions
ZIP ini menyertakan workflow `.github/workflows/build-apk.yml`. Ekstrak ZIP, unggah isi folder `MamangBilling` ke repository GitHub, buka **Actions**, jalankan **Build Mamang Billing APK**, lalu unduh artifact `MamangBilling-debug-apk` dari hasil build yang berhasil. Build memakai JDK 17, Gradle 8.9 dan Android SDK 35.

## Pembaruan v1.8
- Layar login bisa digeser/scroll ke bawah (aman saat keyboard muncul).
- Tombol menu (☰) di pojok kiri atas: Dashboard, Pelanggan, Pembayaran, Complain, Pengaturan, About (+ Paket Internet, Laporan, Keluar Aplikasi).
- Pengaturan: upload logo (tampil di login, menu, About, layar keluar, struk) dan export/download Excel .xls (semua data atau per data).
- Pelanggan: tombol "Buat komplain online manual" dan tombol "Komplain" per pelanggan untuk NOC/Staff (tercatat saluran laporan & pembuat tiket).
- Saat keluar aplikasi tampil: "Terima kasih sudah menggunakan aplikasi Mamang Billing Sastra Nusantara" + "created by Tawab Hidayat".
- Tombol Back: tutup menu/dialog, kembali ke Dashboard, lalu layar terima kasih dan keluar.
- Export/import file kini berfungsi di APK (dialog Simpan sebagai & pemilih file).

## Pembaruan tampilan v1.7
- Tema utama diperbarui menjadi biru-putih seperti referensi: header biru, navigasi bawah, kartu statistik terang, dan tombol biru.
- Form login dirapikan; pilihan NOC/Admin atau Staff/Kasir hanya tampil satu kali.

## Catatan penting
- Versi ini menyimpan data di penyimpanan lokal aplikasi; belum ada sinkronisasi multi-perangkat yang lengkap atau backend produksi.
- Ekspor laporan adalah CSV UTF-8 (bisa dibuka di Excel), bukan file XLSX native.
- Integrasi Fonnte dan Telegram membutuhkan token API/Chat ID milik pengguna dan koneksi internet. Ketersediaan pengiriman bergantung pada konfigurasi provider dan izin jaringan.
- Token Fonnte/Telegram yang dimasukkan ke aplikasi lokal tersimpan pada perangkat dan berpotensi diekstrak dari APK. Untuk penggunaan produksi, pindahkan token ke backend/proxy HTTPS dan terapkan autentikasi serta otorisasi di server.
- Belum termasuk integrasi MikroTik/RouterOS, RADIUS, pemutusan PPPoE otomatis, ataupun webhook publik untuk menerima komplain dari pelanggan.
- APK debug bukan APK release bertanda tangan untuk distribusi publik.
