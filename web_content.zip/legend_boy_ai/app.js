const $=s=>document.querySelector(s);const chat=$('#chat'),promptBox=$('#prompt');let history=[];const key=()=>localStorage.getItem('lbai_key')||'';
function add(text,who){const el=document.createElement('div');el.className='message '+who;el.textContent=text;chat.appendChild(el);window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'});return el}
function openSettings(){$('#apiKey').value=key();$('#model').value=localStorage.getItem('lbai_model')||'gemini-3.8-flash';$('#settings').classList.remove('hidden')}
$('#settingsBtn').onclick=openSettings;$('#closeSettings').onclick=()=>$('#settings').classList.add('hidden');$('#saveSettings').onclick=()=>{localStorage.setItem('lbai_key',$('#apiKey').value.trim());localStorage.setItem('lbai_model',$('#model').value);$('#settings').classList.add('hidden');add(key()?'AI connection settings saved. You can now ask me anything.':'No API key added yet. Add one in Settings to enable AI replies.','bot')};
async function send(){
 const text=promptBox.value.trim();if(!text)return;
 promptBox.value='';promptBox.style.height='auto';$('#welcome').style.display='none';add(text,'user');
 if(!key()){add('To turn on real AI answers, open ⚙ Settings and add a Gemini API key. You can create one in Google AI Studio.','bot');return}
 const loading=add('Thinking…','bot typing');$('#send').disabled=true;
 try{
  const contents=[...history,{role:'user',parts:[{text}]}];
  const selected=localStorage.getItem('lbai_model')||'gemini-3.8-flash';
  const models=[selected];
  // If Gemini 3.8 is temporarily overloaded, try the lighter stable backup automatically.
  if(selected==='gemini-3.8-flash')models.push('gemini-3.5-flash-lite');
  let data=null,lastError='';
  for(const model of models){
   const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key())}`,{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({system_instruction:{parts:[{text:'You are THE LEGEND BOY AI, a friendly, capable assistant. Help with learning, creativity, coding, planning and everyday questions. Be honest, clear and respectful. Reply in the language the user uses.'}]},contents,generationConfig:{temperature:0.7,maxOutputTokens:2048}})
   });
   data=await res.json();
   if(res.ok)break;
   lastError=data.error?.message||`Request failed (${res.status})`;
   if(!([429,500,502,503,504].includes(res.status))||model===models[models.length-1])throw new Error(lastError);
  }
  if(!data?.candidates?.length)throw new Error(lastError||'The model did not return an answer.');
  const answer=data.candidates[0].content?.parts?.map(p=>p.text||'').join('')||'I could not create a reply. Please try again.';
  loading.classList.remove('typing');loading.textContent=answer;
  history.push({role:'user',parts:[{text}]},{role:'model',parts:[{text:answer}]});if(history.length>24)history=history.slice(-24);
 }catch(e){loading.classList.remove('typing');loading.textContent='Connection problem: '+e.message+'. Check your internet and API key in Settings.'}
 finally{$('#send').disabled=false}
}
$('#send').onclick=send;promptBox.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});promptBox.addEventListener('input',()=>{promptBox.style.height='auto';promptBox.style.height=Math.min(promptBox.scrollHeight,130)+'px'});document.querySelectorAll('.suggestions button').forEach(b=>b.onclick=()=>{promptBox.value=b.textContent;send()});if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
