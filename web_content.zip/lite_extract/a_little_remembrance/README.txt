A Little Remembrance - lightweight test build

No animated rain or scene animations. All scenes use static images.
HTML entry: index.html

Upload the contents so index.html remains at the project root when your HTML-to-APK service asks for a ZIP.
