# Vườn Cây - Android App

Đây là bản Android WebView offline của game Vườn Cây.

- Game được đóng trong `app/src/main/assets/index.html`.
- Icon app dùng ảnh `app/src/main/res/drawable-nodpi/app_icon.png` do người dùng cung cấp.
- Chạy ngang, fullscreen, bật JavaScript + localStorage.
- Không cần Internet để chạy game.

## Build APK
Mở thư mục này bằng Android Studio, sau đó chọn:
Build → Build APK(s)

APK debug sẽ nằm ở:
`app/build/outputs/apk/debug/app-debug.apk`

Môi trường hiện tại không có Android SDK/Gradle nên không thể biên dịch APK trực tiếp tại đây; project đã sẵn sàng để build.
