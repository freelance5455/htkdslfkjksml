import { json, isAuthorized, bodyJson, readConfig, writeConfig, telegram, validateProgram } from "./shared.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Метод не підтримується." }, 405);
  if (!isAuthorized(req)) return json({ error: "Неправильний пароль адміністратора." }, 401);
  try {
    const config = await readConfig();
    if (!config) return json({ error: "Спочатку підключи Telegram-бота." }, 409);
    const body = await bodyJson(req);
    const program = validateProgram(body.program);
    await telegram(config.token, "setMyCommands", {
      commands: [
        { command: "start", description: "Почати роботу" },
        ...program.rules.map(({ command, description }) => ({ command, description }))
      ]
    });
    config.program = program;
    await writeConfig(config);
    return json({ ok: true, message: "Програму збережено. Бот уже працює за новими правилами." });
  } catch (error) {
    return json({ error: error.message || "Не вдалося зберегти програму." }, 400);
  }
};
