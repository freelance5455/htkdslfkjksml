import { json, isAuthorized, readConfig, telegram, publicConfig } from "./shared.mjs";

export default async (req) => {
  if (req.method !== "GET") return json({ error: "Метод не підтримується." }, 405);
  if (!isAuthorized(req)) return json({ error: "Неправильний пароль адміністратора." }, 401);
  try {
    const config = await readConfig();
    if (!config) return json(publicConfig(null));
    const webhookInfo = await telegram(config.token, "getWebhookInfo");
    return json(publicConfig(config, webhookInfo));
  } catch (error) {
    return json({ error: error.message || "Не вдалося отримати стан бота." }, 500);
  }
};
