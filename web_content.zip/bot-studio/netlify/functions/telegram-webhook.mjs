import { readConfig, telegram, json } from "./shared.mjs";

function chooseReply(text, program, username) {
  const commandMatch = text.match(/^\/([a-z0-9_]+)(?:@[a-z0-9_]+)?(?:\s|$)/i);
  if (commandMatch) {
    const command = commandMatch[1].toLowerCase();
    if (command === "start") return program.welcome;
    const rule = program.rules.find((item) => item.command === command);
    if (rule) return rule.response;
  }
  return program.fallback;
}

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const config = await readConfig();
    if (!config || !config.active) return json({ ok: true });
    const suppliedSecret = req.headers.get("x-telegram-bot-api-secret-token") || "";
    if (!suppliedSecret || suppliedSecret !== config.webhookSecret) return json({ error: "Unauthorized" }, 401);

    const update = await req.json();
    const message = update?.message;
    if (!message?.chat?.id || typeof message.text !== "string") return json({ ok: true });
    const text = message.text.trim();
    if (!text) return json({ ok: true });
    const reply = chooseReply(text, config.program, config.bot?.username || "");
    await telegram(config.token, "sendMessage", {
      chat_id: message.chat.id,
      text: reply.slice(0, 4000),
      ...(message.message_thread_id ? { message_thread_id: message.message_thread_id } : {})
    });
    return json({ ok: true });
  } catch (error) {
    // Returning a non-2xx status allows Telegram to retry temporary delivery failures.
    return json({ error: error.message || "Webhook processing failed" }, 500);
  }
};
