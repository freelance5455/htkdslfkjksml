import { randomBytes } from "node:crypto";
import { json, isAuthorized, bodyJson, readConfig, writeConfig, deleteConfig, telegram, validateProgram } from "./shared.mjs";

const defaultProgram = (username) => ({
  welcome: `Вітаю! Я бот @${username}.\n\nНапиши /help, щоб побачити доступні команди.`,
  fallback: "Я поки не знаю, як відповісти на це повідомлення. Напиши /help.",
  rules: [
    { command: "help", description: "Показати список команд", response: "Доступні команди:\n/start — почати роботу\n/help — список команд" }
  ]
});

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Метод не підтримується." }, 405);
  if (!isAuthorized(req)) return json({ error: "Неправильний пароль адміністратора." }, 401);
  try {
    const body = await bodyJson(req);
    const token = String(body.token || "").trim();
    const siteOrigin = String(body.siteOrigin || "").trim();
    if (token.length < 30 || token.length > 200 || !/^\d+:[A-Za-z0-9_-]+$/.test(token)) {
      return json({ error: "Токен має неправильний формат. Скопіюй токен саме з BotFather." }, 400);
    }
    const origin = new URL(siteOrigin);
    if (origin.protocol !== "https:" || origin.username || origin.password || origin.pathname !== "/" || origin.search || origin.hash) {
      return json({ error: "Додаток має бути опублікований на HTTPS-сайті Netlify." }, 400);
    }
    const requestOrigin = req.headers.get("origin");
    if (!requestOrigin || new URL(requestOrigin).origin !== origin.origin) {
      return json({ error: "Запит має надходити з цього самого сайту." }, 403);
    }

    const bot = await telegram(token, "getMe");
    if (!bot.is_bot || !bot.username) throw new Error("Цей токен не належить Telegram-боту з username.");
    const previous = await readConfig();
    const webhookSecret = randomBytes(32).toString("base64url");
    const program = previous?.bot?.username === bot.username ? previous.program : validateProgram(defaultProgram(bot.username));
    const next = {
      token,
      webhookSecret,
      siteOrigin: origin.origin,
      bot: { username: bot.username, firstName: bot.first_name || "" },
      program,
      active: true,
      createdAt: new Date().toISOString()
    };

    await writeConfig(next);
    try {
      await telegram(token, "setWebhook", {
        url: `${origin.origin}/.netlify/functions/telegram-webhook`,
        secret_token: webhookSecret,
        allowed_updates: ["message"]
      });
      await telegram(token, "setMyCommands", {
        commands: [
          { command: "start", description: "Почати роботу" },
          ...program.rules.map(({ command, description }) => ({ command, description }))
        ]
      });
    } catch (error) {
      if (previous) await writeConfig(previous);
      else await deleteConfig();
      throw error;
    }
    return json({ ok: true, bot: next.bot, active: true, message: `Бот @${bot.username} підключений і запущений.` });
  } catch (error) {
    return json({ error: error.message || "Не вдалося підключити бота." }, 400);
  }
};
