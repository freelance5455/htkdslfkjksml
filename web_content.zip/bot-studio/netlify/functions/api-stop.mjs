import { json, isAuthorized, readConfig, writeConfig, telegram } from "./shared.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Метод не підтримується." }, 405);
  if (!isAuthorized(req)) return json({ error: "Неправильний пароль адміністратора." }, 401);
  try {
    const config = await readConfig();
    if (!config) return json({ error: "Бот ще не підключений." }, 409);
    await telegram(config.token, "deleteWebhook", { drop_pending_updates: false });
    config.active = false;
    await writeConfig(config);
    return json({ ok: true, message: "Бота зупинено. Налаштування збережені." });
  } catch (error) {
    return json({ error: error.message || "Не вдалося зупинити бота." }, 400);
  }
};
