import { getStore } from "@netlify/blobs";
import { createHash, createCipheriv, createDecipheriv, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

const STORE_NAME = "bot-studio-private";
const CONFIG_KEY = "main-bot-config";

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store, max-age=0",
      "x-content-type-options": "nosniff"
    }
  });
}

export async function bodyJson(req) {
  try {
    return await req.json();
  } catch {
    throw new Error("Некоректні дані запиту.");
  }
}

function appSecret() {
  const secret = process.env.APP_SECRET;
  if (!secret || secret.length < 24) {
    throw new Error("На Netlify не налаштовано APP_SECRET. Додай довгий секрет (щонайменше 24 символи) у змінні середовища.");
  }
  return secret;
}

export function isAuthorized(req) {
  const supplied = req.headers.get("x-admin-password") || "";
  const expected = process.env.APP_SECRET || "";
  if (!expected || expected.length < 24) return false;
  const a = createHash("sha256").update(supplied).digest();
  const b = createHash("sha256").update(expected).digest();
  return timingSafeEqual(a, b);
}

function encryptionKey() {
  return scryptSync(appSecret(), "bot-studio-config-encryption-v1", 32);
}

export function encryptObject(value) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(value), "utf8"), cipher.final()]);
  return {
    version: 1,
    iv: iv.toString("base64url"),
    tag: cipher.getAuthTag().toString("base64url"),
    data: encrypted.toString("base64url")
  };
}

export function decryptObject(payload) {
  if (!payload || payload.version !== 1) throw new Error("Не вдалося прочитати збережені налаштування.");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(payload.iv, "base64url"));
  decipher.setAuthTag(Buffer.from(payload.tag, "base64url"));
  const plain = Buffer.concat([
    decipher.update(Buffer.from(payload.data, "base64url")),
    decipher.final()
  ]).toString("utf8");
  return JSON.parse(plain);
}

function store() {
  return getStore(STORE_NAME);
}

export async function getEncryptedConfig() {
  const saved = await store().get(CONFIG_KEY, { type: "json" });
  return saved || null;
}

export async function readConfig() {
  const saved = await getEncryptedConfig();
  return saved ? decryptObject(saved) : null;
}

export async function writeConfig(config) {
  await store().setJSON(CONFIG_KEY, encryptObject(config));
}

export async function deleteConfig() {
  await store().delete(CONFIG_KEY);
}

export async function telegram(token, method, payload = {}) {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15000)
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error("Telegram повернув неочікувану відповідь.");
  }
  if (!response.ok || !result.ok) {
    throw new Error(result.description || `Помилка Telegram API (${response.status}).`);
  }
  return result.result;
}

export function validateProgram(input) {
  if (!input || typeof input !== "object") throw new Error("Не знайдено програму бота.");
  const welcome = String(input.welcome ?? "").trim();
  const fallback = String(input.fallback ?? "").trim();
  if (!welcome || welcome.length > 4000) throw new Error("Привітання має містити від 1 до 4000 символів.");
  if (!fallback || fallback.length > 4000) throw new Error("Відповідь за замовчуванням має містити від 1 до 4000 символів.");
  if (!Array.isArray(input.rules) || input.rules.length > 30) throw new Error("Дозволено до 30 команд.");
  const seen = new Set();
  const rules = input.rules.map((rule) => {
    const command = String(rule?.command ?? "").trim().replace(/^\//, "").toLowerCase();
    const description = String(rule?.description ?? "").trim();
    const response = String(rule?.response ?? "").trim();
    if (!/^[a-z0-9_]{1,32}$/.test(command)) throw new Error(`Некоректна команда: ${command || "без назви"}. Використовуй латинські літери, цифри та _ .`);
    if (command === "start") throw new Error("Команда /start зарезервована для привітання.");
    if (seen.has(command)) throw new Error(`Команда /${command} повторюється.`);
    if (!description || description.length > 256) throw new Error(`Для /${command} потрібен опис до 256 символів.`);
    if (!response || response.length > 4000) throw new Error(`Відповідь для /${command} має містити від 1 до 4000 символів.`);
    seen.add(command);
    return { command, description, response };
  });
  return { welcome, fallback, rules };
}

export function publicConfig(config, webhookInfo = null) {
  return {
    connected: Boolean(config),
    active: Boolean(config?.active),
    bot: config?.bot ? { username: config.bot.username || "", firstName: config.bot.firstName || "" } : null,
    program: config?.program || null,
    webhook: webhookInfo ? {
      pending: webhookInfo.pending_update_count || 0,
      lastError: webhookInfo.last_error_message || "",
      lastErrorAt: webhookInfo.last_error_date || null,
      urlConfigured: Boolean(webhookInfo.url)
    } : null
  };
}
