import { json, isAuthorized, readConfig, writeConfig, telegram } from "./shared.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Метод не підтримується." }, 405);
  if (!isAuthorized(req)) return json({ error: "Неправильний пароль адміністратора." }, 401);
  try {
    const config = await readConfig();
    if (!config) return json({ error: "Спочатку підключи бота." }, 409);
    config.active = true;
    await writeConfig(config);
    try {
      await telegram(config.token, "setWebhook", {
        url: `${config.siteOrigin}/.netlify/functions/telegram-webhook`,
        secret_token: config.webhookSecret,
        allowed_updates: ["message"]
      });
    } catch (error) {
      config.active = false;
      await writeConfig(config);
      throw error;
    }
    return json({ ok: true, message: "Бота запущено." });
  } catch (error) {
    return json({ error: error.message || "Не вдалося запустити бота." }, 400);
  }
};
