(() => {
  "use strict";
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const STORE = "aura-tv-v1";
  const defaults = {
    lang: "ar",
    cinema: false,
    apps: [
      {id:"youtube",name:"YouTube",url:"https://www.youtube.com/",type:"youtube"},
      {id:"browser",name:"Browser",url:"https://www.google.com/",type:"browser"},
      {id:"netflix",name:"Netflix",url:"https://www.netflix.com/",type:"netflix"},
      {id:"music",name:"Music",url:"https://music.youtube.com/",type:"music"},
      {id:"settings",name:"Settings",url:"",type:"settings"}
    ]
  };
  let state = loadState();
  let modalAction = null;
  let toastTimer = null;

  const translations = {
    ar: {
      subtitle:"مساحتك الترفيهية", featured:"اختيار اليوم", heroTitle:"ليلتك… على طريقتك",
      heroText:"اجمع تطبيقاتك المفضلة في واجهة واحدة أنيقة، بسيطة وسريعة.", explore:"استكشف التطبيقات",
      customize:"تخصيص الواجهة", premiumExperience:"تجربة ترفيهية راقية", yourSpace:"مساحتك",
      appsTitle:"تطبيقاتك", manage:"إدارة التطبيقات", video:"فيديو", browser:"المتصفح", web:"الويب",
      streaming:"مشاهدة", music:"الموسيقى", audio:"صوتيات", settings:"الإعدادات", preferences:"التفضيلات",
      helperText:"اضغط على أي بطاقة لفتح التطبيق أو تعديل الرابط.", quickAccess:"وصول سريع",
      continueTitle:"تابع من هنا", addShortcut:"إضافة اختصار", addShortcutDesc:"أضف موقعك المفضل",
      cinemaMode:"وضع السينما", cinemaDesc:"أجواء هادئة للشاشة", footer:"واجهة شخصية • إصدار تجريبي",
      ready:"جاهز", editTitle:"إدارة التطبيقات", editDesc:"غيّر رابط أي تطبيق أو أضف اختصارًا جديدًا.",
      addTitle:"إضافة اختصار", addDesc:"أدخل اسم الموقع ورابطه الكامل.", name:"اسم الاختصار",
      url:"رابط الموقع", save:"حفظ", cancel:"إلغاء", saved:"تم حفظ التغييرات",
      invalidUrl:"أدخل رابطًا صحيحًا يبدأ بـ https:// أو http://", needName:"أدخل اسمًا للاختصار",
      opening:"جارٍ فتح الرابط…", noLink:"لا يوجد رابط لهذا التطبيق بعد. أضف الرابط من إدارة التطبيقات.",
      customizeTitle:"تخصيص الواجهة", customizeDesc:"اختر اللغة وجرّب وضع السينما.",
      language:"لغة الواجهة", arabic:"العربية", french:"Français", cinemaToggle:"تفعيل وضع السينما",
      exitCinema:"إنهاء وضع السينما", cinemaOn:"تم تفعيل وضع السينما", cinemaOff:"تم إنهاء وضع السينما",
      appName:"اسم التطبيق", appUrl:"الرابط", editApp:"تعديل", deleteApp:"حذف", addAnother:"إضافة اختصار جديد",
      confirmDelete:"هل تريد حذف هذا الاختصار؟", deleted:"تم حذف الاختصار", settingsTitle:"الإعدادات",
      settingsDesc:"يمكنك تغيير الروابط واللغة. هذه نسخة أولية تحفظ الإعدادات على هذا الجهاز.",
      linkSaved:"تم تحديث الرابط", noApps:"لا توجد تطبيقات بعد"
    },
    fr: {
      subtitle:"Votre espace de divertissement", featured:"À la une", heroTitle:"Votre soirée. À votre façon.",
      heroText:"Retrouvez vos applications préférées dans une interface élégante, simple et rapide.",
      explore:"Explorer les applications", customize:"Personnaliser", premiumExperience:"Une expérience premium",
      yourSpace:"Votre espace", appsTitle:"Vos applications", manage:"Gérer les applications", video:"Vidéo",
      browser:"Navigateur", web:"Web", streaming:"Streaming", music:"Musique", audio:"Audio",
      settings:"Paramètres", preferences:"Préférences", helperText:"Touchez une carte pour ouvrir l’application ou modifier son lien.",
      quickAccess:"Accès rapide", continueTitle:"Accès direct", addShortcut:"Ajouter un raccourci",
      addShortcutDesc:"Ajoutez votre site préféré", cinemaMode:"Mode cinéma", cinemaDesc:"Une ambiance plus immersive",
      footer:"Interface personnelle • Version bêta", ready:"Prêt", editTitle:"Gérer les applications",
      editDesc:"Modifiez le lien d’une application ou ajoutez un raccourci.", addTitle:"Ajouter un raccourci",
      addDesc:"Saisissez le nom du site et son URL complète.", name:"Nom du raccourci", url:"URL du site",
      save:"Enregistrer", cancel:"Annuler", saved:"Modifications enregistrées",
      invalidUrl:"Saisissez une URL valide commençant par https:// ou http://", needName:"Saisissez un nom",
      opening:"Ouverture du lien…", noLink:"Aucun lien configuré. Ajoutez-le dans la gestion des applications.",
      customizeTitle:"Personnaliser l’interface", customizeDesc:"Choisissez la langue et activez le mode cinéma.",
      language:"Langue de l’interface", arabic:"العربية", french:"Français", cinemaToggle:"Activer le mode cinéma",
      exitCinema:"Quitter le mode cinéma", cinemaOn:"Mode cinéma activé", cinemaOff:"Mode cinéma désactivé",
      appName:"Nom de l’application", appUrl:"Lien", editApp:"Modifier", deleteApp:"Supprimer",
      addAnother:"Ajouter un raccourci", confirmDelete:"Supprimer ce raccourci ?", deleted:"Raccourci supprimé",
      settingsTitle:"Paramètres", settingsDesc:"Modifiez les liens et la langue. Cette version conserve les réglages sur cet appareil.",
      linkSaved:"Lien mis à jour", noApps:"Aucune application"
    }
  };
  const t = key => (translations[state.lang] || translations.ar)[key] || key;

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORE) || "null");
      if (!saved || !Array.isArray(saved.apps)) return JSON.parse(JSON.stringify(defaults));
      return {...JSON.parse(JSON.stringify(defaults)), ...saved, apps: saved.apps};
    } catch (_) { return JSON.parse(JSON.stringify(defaults)); }
  }
  function persist() {
    try { localStorage.setItem(STORE, JSON.stringify(state)); }
    catch (_) { showToast("تعذر حفظ الإعدادات على هذا الجهاز"); }
  }
  function showToast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
  }
  function updateClock() {
    const now = new Date();
    $("#clock").textContent = new Intl.DateTimeFormat(state.lang === "ar" ? "ar-DZ" : "fr-FR", {hour:"2-digit",minute:"2-digit"}).format(now);
    $("#dateLabel").textContent = new Intl.DateTimeFormat(state.lang === "ar" ? "ar-DZ" : "fr-FR", {weekday:"short",day:"numeric",month:"short"}).format(now);
  }
  function applyLanguage() {
    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === "ar" ? "rtl" : "ltr";
    $$("[data-i18n]").forEach(el => {
      const key = el.dataset.i18n;
      if (translations[state.lang][key]) el.textContent = translations[state.lang][key];
    });
    $("#languageBtn").textContent = state.lang === "ar" ? "FR" : "ع";
    document.title = "Aura TV";
    updateClock();
  }
  function renderApps() {
    const grid = $("#appGrid");
    grid.innerHTML = "";
    state.apps.forEach((app, i) => {
      const button = document.createElement("button");
      button.className = "app-card app-" + safeClass(app.type || "browser");
      button.dataset.app = app.id;
      button.style.animationDelay = `${Math.min(i, 8) * .04}s`;
      const icon = document.createElement("span");
      icon.className = "app-icon";
      if (app.type === "youtube") {
        icon.innerHTML = '<svg viewBox="0 0 48 34" aria-hidden="true"><rect x="1" y="1" width="46" height="32" rx="9" fill="#ff2638"/><path d="M20 10L32 17L20 24Z" fill="white"/></svg>';
      } else if (app.type === "netflix") { icon.classList.add("netflix-logo"); icon.textContent = "N"; }
      else if (app.type === "music") { icon.textContent = "♫"; }
      else if (app.type === "settings") { icon.textContent = "⚙"; }
      else if (app.type === "browser") { icon.innerHTML = '<span class="browser-globe">◎</span>'; }
      else { icon.textContent = "✦"; }
      const name = document.createElement("span"); name.className = "app-name"; name.textContent = app.name;
      const caption = document.createElement("span"); caption.className = "app-caption";
      caption.textContent = app.type === "youtube" ? t("video") : app.type === "browser" ? t("web") : app.type === "netflix" ? t("streaming") : app.type === "music" ? t("audio") : t("preferences");
      button.append(icon, name, caption);
      button.addEventListener("click", () => handleApp(app));
      grid.appendChild(button);
    });
  }
  function safeClass(value) { return String(value).toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 24) || "browser"; }
  function validUrl(raw) {
    try { const url = new URL(raw); return ["http:", "https:"].includes(url.protocol) ? url.href : null; }
    catch (_) { return null; }
  }
  function handleApp(app) {
    if (app.type === "settings") { openSettings(); return; }
    const url = validUrl(app.url || "");
    if (!url) { showToast(t("noLink")); openEditor(app.id); return; }
    showToast(t("opening"));
    // In an APK wrapper, the WebView/browser policy determines whether this opens in-app or externally.
    window.open(url, "_blank", "noopener,noreferrer");
  }
  function openModal(title, description, bodyHTML, action) {
    $("#modalSave").style.display = "";
    $("#modalTitle").textContent = title;
    $("#modalDescription").textContent = description;
    $("#modalBody").innerHTML = bodyHTML;
    $("#modalBackdrop").hidden = false;
    modalAction = action;
    setTimeout(() => $("#modalBody input")?.focus(), 60);
  }
  function closeModal() { $("#modalBackdrop").hidden = true; modalAction = null; }
  function openShortcutForm(existing = null) {
    const app = existing ? state.apps.find(a => a.id === existing) : null;
    const body = `<label class="field-label" for="shortcutName">${t("name")}</label><input class="field-input" id="shortcutName" maxlength="36" value="${escapeAttr(app?.name || "")}" placeholder="${t("name")}"><label class="field-label" for="shortcutUrl">${t("url")}</label><input class="field-input" id="shortcutUrl" type="url" inputmode="url" value="${escapeAttr(app?.url || "")}" placeholder="https://example.com" dir="ltr">`;
    openModal(app ? t("editApp") : t("addTitle"), app ? t("editDesc") : t("addDesc"), body, () => {
      const name = $("#shortcutName").value.trim();
      const url = validUrl($("#shortcutUrl").value.trim());
      if (!name) { showToast(t("needName")); return false; }
      if (!url) { showToast(t("invalidUrl")); return false; }
      if (app) { app.name = name; app.url = url; app.type = "custom"; }
      else { state.apps.push({id:"custom-" + Date.now(), name, url, type:"custom"}); }
      persist(); renderApps(); applyLanguage(); showToast(app ? t("linkSaved") : t("saved")); return true;
    });
  }
  function escapeAttr(value) { return String(value).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  function openEditor() {
    const items = state.apps.map(app => `<div class="toggle-row"><span>${escapeAttr(app.name)}</span><span style="display:flex;gap:8px"><button class="glass-btn edit-link" data-id="${escapeAttr(app.id)}" style="min-height:32px;padding:0 10px">${t("editApp")}</button>${app.type === "custom" ? `<button class="glass-btn delete-link" data-id="${escapeAttr(app.id)}" style="min-height:32px;padding:0 10px">${t("deleteApp")}</button>` : ""}</span></div>`).join("");
    openModal(t("editTitle"), t("editDesc"), `<div>${items}</div><button class="glass-btn" id="addFromEditor" style="width:100%;margin-top:14px">${t("addAnother")} ＋</button>`, () => true);
    $$(".edit-link", $("#modalBody")).forEach(btn => btn.addEventListener("click", () => openShortcutForm(btn.dataset.id)));
    $$(".delete-link", $("#modalBody")).forEach(btn => btn.addEventListener("click", () => {
      if (!confirm(t("confirmDelete"))) return;
      state.apps = state.apps.filter(a => a.id !== btn.dataset.id);
      persist(); renderApps(); openEditor(); showToast(t("deleted"));
    }));
    $("#addFromEditor").addEventListener("click", () => openShortcutForm());
    $("#modalSave").style.display = "none";
  }
  function openSettings() {
    const body = `<label class="field-label" for="languageSelect">${t("language")}</label><select class="field-select" id="languageSelect"><option value="ar" ${state.lang==="ar"?"selected":""}>${t("arabic")}</option><option value="fr" ${state.lang==="fr"?"selected":""}>${t("french")}</option></select><label class="toggle-row"><span>${t("cinemaToggle")}</span><input type="checkbox" id="cinemaCheck" ${state.cinema?"checked":""}></label>`;
    openModal(t("settingsTitle"), t("settingsDesc"), body, () => {
      state.lang = $("#languageSelect").value;
      state.cinema = $("#cinemaCheck").checked;
      persist(); applyLanguage(); setCinema(state.cinema, false); showToast(t("saved")); return true;
    });
  }
  function openCustomize() {
    const body = `<label class="field-label" for="languageSelect">${t("language")}</label><select class="field-select" id="languageSelect"><option value="ar" ${state.lang==="ar"?"selected":""}>${t("arabic")}</option><option value="fr" ${state.lang==="fr"?"selected":""}>${t("french")}</option></select><label class="toggle-row"><span>${t("cinemaToggle")}</span><input type="checkbox" id="cinemaCheck" ${state.cinema?"checked":""}></label>`;
    openModal(t("customizeTitle"), t("customizeDesc"), body, () => {
      state.lang = $("#languageSelect").value; state.cinema = $("#cinemaCheck").checked;
      persist(); applyLanguage(); setCinema(state.cinema, false); showToast(t("saved")); return true;
    });
  }
  function setCinema(enabled, toast = true) {
    state.cinema = enabled;
    document.body.classList.toggle("cinema-mode", enabled);
    persist();
    if (toast) showToast(enabled ? t("cinemaOn") : t("cinemaOff"));
    $("#ambientBtn").querySelector("b").textContent = enabled ? t("exitCinema") : t("cinemaMode");
  }
  $("#modalClose").addEventListener("click", closeModal);
  $("#modalCancel").addEventListener("click", closeModal);
  $("#modalBackdrop").addEventListener("click", e => { if (e.target === $("#modalBackdrop")) closeModal(); });
  $("#modalSave").addEventListener("click", () => {
    if (!modalAction) { closeModal(); return; }
    if (modalAction() !== false) closeModal();
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("#modalBackdrop").hidden) closeModal(); });
  $("#languageBtn").addEventListener("click", () => { state.lang = state.lang === "ar" ? "fr" : "ar"; persist(); applyLanguage(); renderApps(); showToast(t("saved")); });
  $("#settingsBtn").addEventListener("click", openSettings);
  $("#customizeBtn").addEventListener("click", openCustomize);
  $("#manageAppsBtn").addEventListener("click", openEditor);
  $("#addShortcut").addEventListener("click", () => openShortcutForm());
  $("#ambientBtn").addEventListener("click", () => setCinema(!state.cinema));
  $("#exploreBtn").addEventListener("click", () => $("#appsSection").scrollIntoView({behavior:"smooth", block:"start"}));
  applyLanguage(); renderApps(); setCinema(state.cinema, false);
  setInterval(updateClock, 30000);
})();
