const GAME_WEAPONS_DB = [
    {
        "id": "2MM_Kalibri",
        "name": "2MM Kalibri",
        "type": "pistol",
        "file": "2MM_Kalibri.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "91",
        "name": "91",
        "type": "rifle",
        "file": "91.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "AA12",
        "name": "AA12",
        "type": "shotgun",
        "file": "AA12.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "AK-47",
        "name": "AK-47",
        "type": "rifle",
        "file": "AK-47.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "AKS74U",
        "name": "AKS74U",
        "type": "shotgun",
        "file": "AKS74U.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "ARP-9",
        "name": "ARP-9",
        "type": "smg",
        "file": "ARP-9.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "AW",
        "name": "AW",
        "type": "sniper",
        "file": "AW.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "Armalite_AR10",
        "name": "Armalite AR10",
        "type": "rifle",
        "file": "Armalite_AR10.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Baretta",
        "name": "Baretta",
        "type": "pistol",
        "file": "Baretta.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Barret_M82A1",
        "name": "Barret M82A1",
        "type": "sniper",
        "file": "Barret_M82A1.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "Benelli_M2",
        "name": "Benelli M2",
        "type": "shotgun",
        "file": "Benelli_M2.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Benelli_M4",
        "name": "Benelli M4",
        "type": "shotgun",
        "file": "Benelli_M4.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Beretta_M9",
        "name": "Beretta M9",
        "type": "pistol",
        "file": "Beretta_M9.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Blaser_R93",
        "name": "Blaser R93",
        "type": "sniper",
        "file": "Blaser_R93.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "Bowie_Knife",
        "name": "Bowie Knife",
        "type": "melee",
        "file": "Bowie_Knife.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "CZ",
        "name": "CZ",
        "type": "rifle",
        "file": "CZ.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "CZ_Scorpion_Evo",
        "name": "CZ Scorpion Evo",
        "type": "smg",
        "file": "CZ_Scorpion_Evo.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "Canit_TP9_Elite_Combat",
        "name": "Canit TP9 Elite Combat",
        "type": "pistol",
        "file": "Canit_TP9_Elite_Combat.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Colt_M16A2",
        "name": "Colt M16A2",
        "type": "rifle",
        "file": "Colt_M16A2.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Colt_M4A1",
        "name": "Colt M4A1",
        "type": "rifle",
        "file": "Colt_M4A1.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Cylinder",
        "name": "Cylinder",
        "type": "rifle",
        "file": "Cylinder.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Derya_MK12",
        "name": "Derya MK12",
        "type": "shotgun",
        "file": "Derya_MK12.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Desert_Eagle",
        "name": "Desert Eagle",
        "type": "pistol",
        "file": "Desert_Eagle.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Desert_Tech_SRS",
        "name": "Desert Tech SRS",
        "type": "sniper",
        "file": "Desert_Tech_SRS.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "FN_P90",
        "name": "FN P90",
        "type": "smg",
        "file": "FN_P90.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "FN_SCAR_L",
        "name": "FN SCAR L",
        "type": "rifle",
        "file": "FN_SCAR_L.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Famas",
        "name": "Famas",
        "type": "rifle",
        "file": "Famas.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Flintlock",
        "name": "Flintlock",
        "type": "pistol",
        "file": "Flintlock.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "G36C",
        "name": "G36C",
        "type": "rifle",
        "file": "G36C.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "G36_K",
        "name": "G36 K",
        "type": "rifle",
        "file": "G36_K.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Gerber_LMF",
        "name": "Gerber LMF",
        "type": "melee",
        "file": "Gerber_LMF.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "Glock",
        "name": "Glock",
        "type": "pistol",
        "file": "Glock.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Government",
        "name": "Government",
        "type": "pistol",
        "file": "Government.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "HK",
        "name": "HK",
        "type": "rifle",
        "file": "HK.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "HK33",
        "name": "HK33",
        "type": "rifle",
        "file": "HK33.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "HK417A2",
        "name": "HK417A2",
        "type": "sniper",
        "file": "HK417A2.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "HK_G28",
        "name": "HK G28",
        "type": "sniper",
        "file": "HK_G28.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "HK_G3",
        "name": "HK G3",
        "type": "rifle",
        "file": "HK_G3.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "HK_MP5",
        "name": "HK MP5",
        "type": "smg",
        "file": "HK_MP5.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "HK_MP7",
        "name": "HK MP7",
        "type": "smg",
        "file": "HK_MP7.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "HK_Mark23",
        "name": "HK Mark23",
        "type": "pistol",
        "file": "HK_Mark23.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "HK_USP",
        "name": "HK USP",
        "type": "pistol",
        "file": "HK_USP.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Halmak_Komando",
        "name": "Halmak Komando",
        "type": "melee",
        "file": "Halmak_Komando.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "JNG",
        "name": "JNG",
        "type": "sniper",
        "file": "JNG.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "Kabar",
        "name": "Kabar",
        "type": "melee",
        "file": "Kabar.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "Kabar_Tanto",
        "name": "Kabar Tanto",
        "type": "melee",
        "file": "Kabar_Tanto.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "Kel_Tec_KS7",
        "name": "Kel Tec KS7",
        "type": "shotgun",
        "file": "Kel_Tec_KS7.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Korean_K2",
        "name": "Korean K2",
        "type": "rifle",
        "file": "Korean_K2.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "KrissVector",
        "name": "KrissVector",
        "type": "smg",
        "file": "KrissVector.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "L85A2",
        "name": "L85A2",
        "type": "rifle",
        "file": "L85A2.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "LVOA-C",
        "name": "LVOA-C",
        "type": "rifle",
        "file": "LVOA-C.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Luger_P08",
        "name": "Luger P08",
        "type": "pistol",
        "file": "Luger_P08.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "M",
        "name": "M",
        "type": "rifle",
        "file": "M.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "M14_Classic",
        "name": "M14 Classic",
        "type": "rifle",
        "file": "M14_Classic.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "M14_EBR",
        "name": "M14 EBR",
        "type": "rifle",
        "file": "M14_EBR.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "M1_Grand",
        "name": "M1 Grand",
        "type": "rifle",
        "file": "M1_Grand.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "M200",
        "name": "M200",
        "type": "sniper",
        "file": "M200.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "M249",
        "name": "M249",
        "type": "sniper",
        "file": "M249.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "M24_Apply",
        "name": "M24 Apply",
        "type": "sniper",
        "file": "M24_Apply.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "M24_Stick_Grenade",
        "name": "M24 Stick Grenade",
        "type": "sniper",
        "file": "M24_Stick_Grenade.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "M48_Cyclone",
        "name": "M48 Cyclone",
        "type": "rifle",
        "file": "M48_Cyclone.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "M48_Falcon",
        "name": "M48 Falcon",
        "type": "rifle",
        "file": "M48_Falcon.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "MG42",
        "name": "MG42",
        "type": "rifle",
        "file": "MG42.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "MK",
        "name": "MK",
        "type": "rifle",
        "file": "MK.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "MK12",
        "name": "MK12",
        "type": "rifle",
        "file": "MK12.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "MK17",
        "name": "MK17",
        "type": "rifle",
        "file": "MK17.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "MK2_Handbomb",
        "name": "MK2 Handbomb",
        "type": "grenade",
        "file": "MK2_Handbomb.glb",
        "price": 1000,
        "damage": {
            "head": 250,
            "torso": 200,
            "arms": 150,
            "legs": 150
        },
        "bulletSpeed": 40,
        "bulletSize": 0.4,
        "fireRate": 1.5,
        "clipSize": 1,
        "totalAmmo": 5,
        "animation": "throw_anim"
    },
    {
        "id": "Makarov",
        "name": "Makarov",
        "type": "pistol",
        "file": "Makarov.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Mauser",
        "name": "Mauser",
        "type": "rifle",
        "file": "Mauser.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Maverick",
        "name": "Maverick",
        "type": "rifle",
        "file": "Maverick.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Mikor_MGL",
        "name": "Mikor MGL",
        "type": "grenade",
        "file": "Mikor_MGL.glb",
        "price": 1000,
        "damage": {
            "head": 250,
            "torso": 200,
            "arms": 150,
            "legs": 150
        },
        "bulletSpeed": 40,
        "bulletSize": 0.4,
        "fireRate": 1.5,
        "clipSize": 1,
        "totalAmmo": 5,
        "animation": "throw_anim"
    },
    {
        "id": "Mosin_Nagant_Pistol",
        "name": "Mosin Nagant Pistol",
        "type": "pistol",
        "file": "Mosin_Nagant_Pistol.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Mossberg",
        "name": "Mossberg",
        "type": "shotgun",
        "file": "Mossberg.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Nagant_M1895",
        "name": "Nagant M1895",
        "type": "pistol",
        "file": "Nagant_M1895.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "PKM",
        "name": "PKM",
        "type": "rifle",
        "file": "PKM.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "PSS_Assassin_Pistol",
        "name": "PSS Assassin Pistol",
        "type": "pistol",
        "file": "PSS_Assassin_Pistol.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "RPG7",
        "name": "RPG7",
        "type": "grenade",
        "file": "RPG7.glb",
        "price": 1000,
        "damage": {
            "head": 250,
            "torso": 200,
            "arms": 150,
            "legs": 150
        },
        "bulletSpeed": 40,
        "bulletSize": 0.4,
        "fireRate": 1.5,
        "clipSize": 1,
        "totalAmmo": 5,
        "animation": "throw_anim"
    },
    {
        "id": "Remington870",
        "name": "Remington870",
        "type": "shotgun",
        "file": "Remington870.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Remington_Scoplu_Applied",
        "name": "Remington Scoplu Applied",
        "type": "sniper",
        "file": "Remington_Scoplu_Applied.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "Riot_Shield",
        "name": "Riot Shield",
        "type": "grenade",
        "file": "Riot_Shield.glb",
        "price": 1000,
        "damage": {
            "head": 250,
            "torso": 200,
            "arms": 150,
            "legs": 150
        },
        "bulletSpeed": 40,
        "bulletSize": 0.4,
        "fireRate": 1.5,
        "clipSize": 1,
        "totalAmmo": 5,
        "animation": "throw_anim"
    },
    {
        "id": "Riot_Shield_Glass",
        "name": "Riot Shield Glass",
        "type": "grenade",
        "file": "Riot_Shield_Glass.glb",
        "price": 1000,
        "damage": {
            "head": 250,
            "torso": 200,
            "arms": 150,
            "legs": 150
        },
        "bulletSpeed": 40,
        "bulletSize": 0.4,
        "fireRate": 1.5,
        "clipSize": 1,
        "totalAmmo": 5,
        "animation": "throw_anim"
    },
    {
        "id": "SIG556",
        "name": "SIG556",
        "type": "rifle",
        "file": "SIG556.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "SOG_HAWK",
        "name": "SOG HAWK",
        "type": "sniper",
        "file": "SOG_HAWK.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "SR",
        "name": "SR",
        "type": "rifle",
        "file": "SR.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "STEYR_AUG_A3",
        "name": "STEYR AUG A3",
        "type": "rifle",
        "file": "STEYR_AUG_A3.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "STEYR_SSG69",
        "name": "STEYR SSG69",
        "type": "sniper",
        "file": "STEYR_SSG69.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "SVD_Drogunov",
        "name": "SVD Drogunov",
        "type": "sniper",
        "file": "SVD_Drogunov.glb",
        "price": 4500,
        "damage": {
            "head": 300,
            "torso": 120,
            "arms": 90,
            "legs": 85
        },
        "bulletSpeed": 250,
        "bulletSize": 0.25,
        "fireRate": 1.2,
        "clipSize": 5,
        "totalAmmo": 30,
        "animation": "bolt_action_anim"
    },
    {
        "id": "Sig_Saguer_Mpx",
        "name": "Sig Saguer Mpx",
        "type": "smg",
        "file": "Sig_Saguer_Mpx.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "Sig_Saguer_P226",
        "name": "Sig Saguer P226",
        "type": "pistol",
        "file": "Sig_Saguer_P226.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "Tactic_Shovel",
        "name": "Tactic Shovel",
        "type": "melee",
        "file": "Tactic_Shovel.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "Tarran_Tactical",
        "name": "Tarran Tactical",
        "type": "rifle",
        "file": "Tarran_Tactical.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Tec",
        "name": "Tec",
        "type": "smg",
        "file": "Tec.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "Telescopic_Baton",
        "name": "Telescopic Baton",
        "type": "melee",
        "file": "Telescopic_Baton.glb",
        "price": 500,
        "damage": {
            "head": 150,
            "torso": 60,
            "arms": 45,
            "legs": 35
        },
        "bulletSpeed": 0,
        "bulletSize": 0,
        "fireRate": 0.5,
        "clipSize": 0,
        "totalAmmo": 0,
        "animation": "melee_slash_anim"
    },
    {
        "id": "UMP45",
        "name": "UMP45",
        "type": "smg",
        "file": "UMP45.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "UZI",
        "name": "UZI",
        "type": "smg",
        "file": "UZI.glb",
        "price": 1800,
        "damage": {
            "head": 85,
            "torso": 28,
            "arms": 22,
            "legs": 18
        },
        "bulletSpeed": 100,
        "bulletSize": 0.12,
        "fireRate": 0.07,
        "clipSize": 35,
        "totalAmmo": 140,
        "animation": "smg_shoot_anim"
    },
    {
        "id": "Utas_UTS15",
        "name": "Utas UTS15",
        "type": "shotgun",
        "file": "Utas_UTS15.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "VSS_Vintorez",
        "name": "VSS Vintorez",
        "type": "rifle",
        "file": "VSS_Vintorez.glb",
        "price": 2500,
        "damage": {
            "head": 110,
            "torso": 35,
            "arms": 28,
            "legs": 22
        },
        "bulletSpeed": 120,
        "bulletSize": 0.15,
        "fireRate": 0.1,
        "clipSize": 30,
        "totalAmmo": 120,
        "animation": "rifle_shoot_anim"
    },
    {
        "id": "Weatherby_Orion",
        "name": "Weatherby Orion",
        "type": "shotgun",
        "file": "Weatherby_Orion.glb",
        "price": 3000,
        "damage": {
            "head": 160,
            "torso": 80,
            "arms": 60,
            "legs": 50
        },
        "bulletSpeed": 70,
        "bulletSize": 0.3,
        "fireRate": 0.4,
        "clipSize": 8,
        "totalAmmo": 32,
        "animation": "shotgun_pump_anim"
    },
    {
        "id": "Weldrod_Mark1",
        "name": "Weldrod Mark1",
        "type": "pistol",
        "file": "Weldrod_Mark1.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    },
    {
        "id": "X13",
        "name": "X13",
        "type": "pistol",
        "file": "X13.glb",
        "price": 700,
        "damage": {
            "head": 70,
            "torso": 25,
            "arms": 20,
            "legs": 15
        },
        "bulletSpeed": 80,
        "bulletSize": 0.1,
        "fireRate": 0.25,
        "clipSize": 12,
        "totalAmmo": 60,
        "animation": "pistol_shoot_anim"
    }
];
const weaponsDB = GAME_WEAPONS_DB;
