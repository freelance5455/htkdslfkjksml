SMART DARZI — Urdu/English prototype with PDF and experimental BLE controls

Open index.html in a modern browser. Customer/worker/order data is stored locally in that browser.

PDF: Choose “Make PDF”; the browser print dialog opens. Select “Save as PDF”.
Printing: “Print” opens the browser print dialog.
Bluetooth: Experimental Web Bluetooth option for BLE printers with writable GATT characteristics only. Many thermal printers use Classic Bluetooth/SPP or vendor-specific protocols and will not work with this HTML prototype. Reliable 58mm/80mm thermal printing requires testing the exact printer and likely native Android ESC/POS integration.

This is a prototype, not a compiled APK. Export backups regularly. Do not use as the only record of real customer orders.
Branding: Powered by Usama Shahzad.
