package es.cetarsa.puntolimpio;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

public class ShareProvider extends ContentProvider {
  public static final String AUTHORITY="es.cetarsa.puntolimpio.files";
  public static Uri uri(String file){return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath(file).build();}
  private File checked(Uri uri) throws FileNotFoundException {
    String name=uri.getLastPathSegment();
    if(name==null || !name.matches("[A-Za-z0-9._-]{1,180}") || name.contains(".."))throw new FileNotFoundException("Invalid name");
    File f=new File(getContext().getCacheDir(),name);
    if(!f.isFile())throw new FileNotFoundException(name);
    return f;
  }
  @Override public boolean onCreate(){return true;}
  @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
    try {File f=checked(uri);MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});c.addRow(new Object[]{f.getName(),f.length()});return c;}catch(Exception e){return null;}
  }
  @Override public String getType(Uri uri){return uri.getLastPathSegment()!=null && uri.getLastPathSegment().endsWith(".jpg")?"image/jpeg":"application/pdf";}
  @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
  @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){return 0;}
  @Override public int delete(Uri uri,String selection,String[] selectionArgs){return 0;}
  @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
    File f=checked(uri);
    return ParcelFileDescriptor.open(f,mode.contains("w")?ParcelFileDescriptor.MODE_READ_WRITE:ParcelFileDescriptor.MODE_READ_ONLY);
  }
}
