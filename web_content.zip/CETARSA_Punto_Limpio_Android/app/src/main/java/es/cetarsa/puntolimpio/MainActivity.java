package es.cetarsa.puntolimpio;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> chooserCallback;
  private Uri cameraUri;
  private String pendingName;
  private byte[] pendingBytes;
  private static final int FILE_PICKER=41, FILE_SAVE=42;

  @Override public void onCreate(Bundle b){super.onCreate(b);
    web=new WebView(this);setContentView(web);
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);s.setAllowContentAccess(true);
    s.setDatabaseEnabled(true);s.setMediaPlaybackRequiresUserGesture(true);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){
        if(!"file".equals(request.getUrl().getScheme()) && !"https".equals(request.getUrl().getScheme())){
          try{startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));}catch(Exception ignored){}return true;
        }return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(chooserCallback!=null)chooserCallback.onReceiveValue(null);
        chooserCallback=callback;
        Intent choose=new Intent(Intent.ACTION_GET_CONTENT);choose.setType(params.getAcceptTypes().length>0 && params.getAcceptTypes()[0].contains("pdf")?"application/pdf":"*/*");
        if(!"application/pdf".equals(choose.getType()))choose.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/json"});
        choose.addCategory(Intent.CATEGORY_OPENABLE);choose.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
        Intent intent=Intent.createChooser(choose,"Seleccionar archivos");
        boolean wantsCamera=false;
        for(String a:params.getAcceptTypes())if(a.contains("image"))wantsCamera=true;
        if(wantsCamera){
          try{
            File f=new File(getCacheDir(),"captura_"+System.currentTimeMillis()+".jpg");f.createNewFile();cameraUri=ShareProvider.uri(f.getName());
            Intent cam=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);cam.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{cam});
          }catch(Exception e){cameraUri=null;}
        }
        try{startActivityForResult(intent,FILE_PICKER);return true;}catch(Exception e){chooserCallback=null;return false;}
      }
    });
    web.addJavascriptInterface(new Bridge(),"CetarsaAndroid");
    web.loadUrl("file:///android_asset/index.html");
  }

  private String clean(String name){
    String n=name.replaceAll("[^A-Za-z0-9._-]","_");
    return n.length()>175?n.substring(n.length()-175):n;
  }
  private class Bridge {
    @JavascriptInterface public void sendEmailWithAttachment(String to,String subject,String body,String filename,String base64){
      try{
        // Destinatario fijo para impedir que contenido JS remoto determine direcciones de envío.
        byte[] content=android.util.Base64.decode(base64,android.util.Base64.DEFAULT);
        File f=new File(getCacheDir(),clean(filename));try(FileOutputStream o=new FileOutputStream(f)){o.write(content);}
        Uri uri=ShareProvider.uri(f.getName());
        runOnUiThread(()->{
          Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/pdf");
          send.putExtra(Intent.EXTRA_EMAIL,new String[]{"jgomez@cetarsa.es"});
          send.putExtra(Intent.EXTRA_SUBJECT,subject);send.putExtra(Intent.EXTRA_TEXT,body);
          send.putExtra(Intent.EXTRA_STREAM,uri);
          send.setClipData(android.content.ClipData.newUri(getContentResolver(),"Informe CETARSA",uri));
          send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
          try{startActivity(Intent.createChooser(send,"Enviar PDF con correo"));}
          catch(Exception e){Toast.makeText(MainActivity.this,"No hay aplicación para enviar correo",Toast.LENGTH_LONG).show();}
        });
      }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"No se pudo preparar el PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    }
    @JavascriptInterface public void saveFile(String name,String b64){
      try{
        pendingBytes=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);pendingName=clean(name);
        runOnUiThread(()->{
          Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE);
          save.setType(name.toLowerCase().endsWith(".pdf")?"application/pdf":"application/json");
          save.putExtra(Intent.EXTRA_TITLE,name);
          startActivityForResult(save,FILE_SAVE);
        });
      }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Error guardando: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    }
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==FILE_PICKER){
      if(chooserCallback!=null){
        Uri[] uris=null;
        if(result==RESULT_OK){
          if(data!=null && data.getClipData()!=null){int n=data.getClipData().getItemCount();uris=new Uri[n];for(int i=0;i<n;i++)uris[i]=data.getClipData().getItemAt(i).getUri();}
          else if(data!=null && data.getData()!=null){uris=new Uri[]{data.getData()};}
          else if(cameraUri!=null){uris=new Uri[]{cameraUri};}
        }
        chooserCallback.onReceiveValue(uris);chooserCallback=null;cameraUri=null;
      }
    }else if(request==FILE_SAVE){
      if(result==RESULT_OK && data!=null && data.getData()!=null && pendingBytes!=null){
        try(OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write(pendingBytes);Toast.makeText(this,"Archivo guardado",Toast.LENGTH_SHORT).show();}
        catch(Exception e){Toast.makeText(this,"Error al guardar el archivo",Toast.LENGTH_LONG).show();}
      }pendingBytes=null;pendingName=null;
    }
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
