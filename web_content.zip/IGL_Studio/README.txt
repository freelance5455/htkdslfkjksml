IGL STUDIO COMPLETE — QUICK START

1. Extract this ZIP.
2. Open index.html in Chrome. It works offline.
3. Tap “Upload map / screenshot” and select a Free Fire map screenshot or any tactical image.
4. Use drawing tools and tactical markers to plan player drops, routes, holds, pushes, enemies, vehicles, Gloo Walls, split and regroup calls.
5. Export PNG to share a flat strategy image.
6. Save project to keep an editable JSON project; use Open project to continue editing later.

TOOLS
Pen, line, arrow, circle, rectangle, text, tactical markers, colour palette, stroke width, undo/redo, clear marks, zoom, image fit/remove, PNG export, editable project save/open.

MAPS
The map selector includes labels for Bermuda, Bermuda Remastered, Purgatory, Kalahari, Alpine, NexTerra, Solara and Academy. It does not contain copyrighted official map artwork. Upload the exact map image/screenshot you want to plan on; this supports map updates and your own annotated screenshots.

NOTE
Independent fan-made strategy planner, not affiliated with Garena or Free Fire. Offline browser app; no account required.
