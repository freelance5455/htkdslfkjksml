import os
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv(Path(__file__).resolve().parents[1] / ".env")

app = FastAPI(title="UZGUIDE AI API", version="4.0.0")
origin = os.getenv("FRONTEND_ORIGIN", "http://127.0.0.1:5500")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin, "http://localhost:5500", "http://127.0.0.1:5500"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=3000)
    language: str = "uz"
    place_id: str | None = None

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "uzguide-ai", "version": "4.0.0"}

@app.post("/api/chat")
def chat(payload: ChatRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or api_key == "your_api_key_here":
        raise HTTPException(status_code=503, detail="AI hali sozlanmagan. Backend .env fayliga OPENAI_API_KEY kiriting.")
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        language_names = {"uz": "Uzbek", "en": "English", "ru": "Russian"}
        lang = language_names.get(payload.language, "Uzbek")
        context = f"The visitor is asking about: {payload.place_id or 'Uzbekistan heritage in general'}. "
        instructions = (
            "You are UZGUIDE, a careful multilingual cultural heritage guide for Uzbekistan. "
            "Answer in {lang}. Be warm, concise, and useful. Distinguish well-established facts "
            "from uncertainty; never invent dates, legends, ticket prices, opening hours, or access rules. "
            "If you are unsure, say so and recommend checking an official local source. "
            "Do not claim to be a human guide or a real historical person."
        ).format(lang=lang)
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=instructions,
            input=context + payload.message,
        )
        return {"answer": response.output_text, "model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini")}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI xizmatida xatolik: {str(exc)}")

