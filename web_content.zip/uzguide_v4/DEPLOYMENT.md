# Deployment checklist

## Frontend
Deploy the `frontend/` directory to a static host (for example, Cloudflare Pages or GitHub Pages). Configure `API_BASE` in `frontend/app.js` to the public HTTPS backend URL.

## Backend
Deploy `backend/` to a Python ASGI host. Set environment variables:
- `OPENAI_API_KEY` (secret)
- `OPENAI_MODEL` (supported model available to your account)
- `FRONTEND_ORIGIN` (exact public frontend origin)

Run: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

## Before public launch
- Restrict CORS to the exact production domain.
- Add rate limiting and abuse protection.
- Never commit `.env`.
- Add reviewed historical references and RAG citations.
- Add privacy notice, terms, and data retention policy.
- Test mobile, keyboard navigation, screen readers, and low bandwidth.
- Confirm all free-tier limits and provider terms; they can change.
