# UZGUIDE roadmap

1. MVP foundation: responsive site, heritage detail pages, multilingual UI, AI API proxy, browser voice, itinerary builder.
2. Trusted knowledge: curated bibliography, historian review, RAG retrieval, source citations, content versioning.
3. Immersive layer: real 3D scans/models, optimized glTF, interactive hotspots, WebXR AR pilot.
4. Visitor product: accounts, saved routes, QR codes, accessibility, feedback and analytics.
5. Scale: partner dashboard, tourism organization integrations, multilingual editorial workflow, monitoring and incident response.
