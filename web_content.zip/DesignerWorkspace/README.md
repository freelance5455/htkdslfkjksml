# Designer Workspace
نسخة معاد بناؤها من الصفر، تعمل محليًا بدون مكتبات خارجية.
- Projects / Briefs / Tasks / Assets / Versions / Notes
- Time Tracking
- Timeline
- Statistics / Project Links / Attachments / Project Lock / Trash
- حفظ تلقائي عبر localStorage
- شاشة 𝒗𝒂𝒏𝒕𝒂 بظهور واختفاء تدريجي
