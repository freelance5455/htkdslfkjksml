/* Cache só do "casco" do app (HTML/CSS/JS/imagens do próprio site). Nunca guarda chamadas ao Supabase
   (outro domínio) nem dados de membros. Ao alterar arquivos, aumente VERSION. */
const VERSION = 'agape-v1';
const SHELL = ['./', 'index.html', 'admin.html', 'style.css', 'responsive.css', 'admin.css', 'script.js', 'js/api.js', 'js/supabase.js', 'js/admin.js',
  'supabase-config.js', 'manifest.webmanifest', 'assets/logo/logo.svg', 'assets/logo/logo-dark.svg', 'assets/images/avatar.svg', 'assets/icons/icon.svg', 'assets/icons/icon-192.png', 'assets/icons/icon-512.png'];
self.addEventListener('install', e => e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== VERSION).map(x => caches.delete(x)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  if (e.request.mode === 'navigate') { // páginas: rede primeiro, cache se estiver offline
    e.respondWith(fetch(e.request).then(r => { const cp = r.clone(); caches.open(VERSION).then(c => c.put(e.request, cp)); return r; }).catch(() => caches.match(e.request).then(r => r || caches.match('index.html'))));
    return;
  }
  e.respondWith(caches.match(e.request).then(hit => { const net = fetch(e.request).then(r => { const cp = r.clone(); caches.open(VERSION).then(c => c.put(e.request, cp)); return r; }).catch(() => hit); return hit || net; }));
});
