'use strict';
/* Ágape+ — interface (telas, navegação, formulários). Dados: js/api.js e js/supabase.js */

/* ---------- 3. Utilidades de interface ---------- */
const ICONS = {
  back: '<path d="M15 18l-6-6 6-6"/>', chev: '<path d="M9 6l6 6-6 6"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>',
  card: '<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 10h8M8 14h5"/>',
  bell: '<path d="M6 16V11a6 6 0 1112 0v5l1.5 2h-15zM10 21h4"/>',
  heart: '<path d="M12 20s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 10c0 5.500-7 10-7 10z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 5-7 8-7s7 2 8 7"/>',
  calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  dollar: '<path d="M12 3v18M16.500 7H10a3 3 0 000 6h4a3 3 0 010 6H7"/>',
  spark: '<path d="M12 3l2 6 6 3-6 3-2 6-2-6-6-3 6-3z"/>',
  home: '<path d="M4 11l8-7 8 7v9H4z"/>',
  arrow: '<path d="M7 17L17 7M8 7h9v9"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  phone: '<path d="M5 4h4l2 5-2.500 1.500a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A15 15 0 013 6a2 2 0 012-2z"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10 6a9 9 0 0112 6 13 13 0 01-3 3.500M6 7.500A13 13 0 002 12s4 7 10 7a9 9 0 004-1"/>',
  quote: '<path d="M7 17c-2 0-3-1-3-3v-3c0-3 2-5 4-5M17 17c-2 0-3-1-3-3v-3c0-3 2-5 4-5"/>',
};
function paintIcons(root = document) {
  $$('[data-i]', root).forEach(el => { el.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[el.dataset.i] || ''}</svg>`; });
}
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2600);
}
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const setErr = (id, msg) => { const e = $('#' + id + '-e'); if (e) e.textContent = msg || ''; return !msg; };

/* ---------- 4. Validação ---------- */
const V = {
  name: v => v.trim().split(/\s+/).filter(Boolean).length >= 2 && v.trim().length >= 5 ? '' : 'Informe nome e sobrenome.',
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Informe um e-mail válido.',
  pass: v => v.length >= 8 ? '' : 'A senha precisa ter pelo menos 8 caracteres.',
  loginPass: v => v ? '' : 'Informe sua senha.',
  phone: v => { const d = v.replace(/\D/g, ''); return !v.trim() || (d.length >= 8 && d.length <= 13) ? '' : 'Telefone inválido. Use apenas DDD e número.'; },
  birth: v => { if (!v) return 'Informe a data de nascimento.'; const d = new Date(v), n = new Date(); const age = (n - d) / 31557600000; return d > n || age > 120 ? 'Data de nascimento inválida.' : ''; },
  cell: v => v ? '' : 'Escolha sua célula.',
};
function check(pairs) { // [[campoId, mensagem]]
  let ok = true; pairs.forEach(([id, m]) => { if (!setErr(id, m)) ok = false; });
  const first = pairs.find(([, m]) => m); if (first) $('#' + first[0])?.focus();
  return ok;
}

/* ---------- 5. Navegação ---------- */
const state = { profile: null, ready: false };
const PUBLIC = ['login', 'register', 'forgot'];
const TABS = ['home', 'agenda', 'avisos', 'perfil'];
function route() {
  if (!state.ready) return;
  let name = location.hash.slice(1) || 'home';
  if (!$(`[data-screen="${name}"]`)) name = 'home';
  if (!state.profile && !PUBLIC.includes(name)) name = 'login';
  if (state.profile && PUBLIC.includes(name)) name = 'home';
  $$('.screen').forEach(s => s.hidden = s.dataset.screen !== name);
  const sc = $(`[data-screen="${name}"]`); sc.scrollTop = 0;
  const tab = sc.dataset.tab;
  $('#tabbar').hidden = !tab;
  $$('#tabbar button').forEach(b => b.classList.toggle('on', b.dataset.go === tab));
  renderScreen(name);
}
const go = name => { if (location.hash.slice(1) === name) route(); else location.hash = name; };
document.addEventListener('click', e => {
  const g = e.target.closest('[data-go]'); if (g) { e.preventDefault(); go(g.dataset.go); return; }
  const m = e.target.closest('[data-modal]'); if (m) { e.preventDefault(); $('#dlg-' + m.dataset.modal).showModal(); return; }
  const eye = e.target.closest('[data-eye]'); if (eye) {
    const i = $('#' + eye.dataset.eye); const show = i.type === 'password'; i.type = show ? 'text' : 'password';
    $('i', eye).dataset.i = show ? 'eyeoff' : 'eye'; paintIcons(eye);
  }
});
window.addEventListener('hashchange', route);

/* ---------- 6. Renderização por tela ---------- */
const SERVICES = [
  { id: 'agenda', t: 'Agenda da Igreja', s: 'Cultos, eventos e programações', cta: 'Ver agenda', i: 'calendar', c: '#e3eafc', k: '#4a6fd8', dot: '#3b5bdb' },
  { id: 'avisos', t: 'Avisos e Mensagens', s: 'Novidades da sua igreja', cta: 'Atualizações', i: 'bell', c: '#fde3e8', k: '#d6455d', dot: '#d6455d' },
  { id: 'contrib', t: 'Contribuições', s: 'Seu histórico de lançamentos', cta: 'Consultar', i: 'dollar', c: '#dff3ea', k: '#2f9a78', dot: '#2f9a78' },
  { id: 'oracao', t: 'Pedido de Oração', s: 'Compartilhe seu pedido', cta: 'Enviar pedido', i: 'spark', c: '#e5dcff', k: '#6a4fd8', dot: '#6a4fd8' },
  { id: 'carteirinha', t: 'Carteirinha Digital', s: 'Identificação e QR Code', cta: 'Abrir cartão', i: 'card', c: '#fbefd3', k: '#c79a2c', dot: '#d9a93a' },
  { id: 'perfil', t: 'Meu Perfil', s: 'Dados e segurança da conta', cta: 'Gerenciar', i: 'user', c: '#e6e8f2', k: '#4b5270', dot: '#6b7390' },
];
const QUICK = [['carteirinha', 'Carteirinha', 'card'], ['avisos', 'Avisos', 'bell'], ['oracao', 'Oração', 'heart'], ['perfil', 'Perfil', 'user']];
const fmtDate = iso => new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

function fillProfile() {
  const p = state.profile; if (!p) return;
  $$('[data-avatar]').forEach(i => i.src = p.photo || CONFIG.defaultAvatar);
  $$('[data-name]').forEach(e => e.textContent = p.name);
  $$('[data-name-first]').forEach(e => e.textContent = p.name.split(' ')[0]);
  $$('[data-cell]').forEach(e => e.textContent = p.cell);
  $('#nav-admin').hidden = !['leader', 'admin'].includes(p.role); // só conveniência visual: a autorização real é do servidor (RLS)
}
function renderQR() { // QR ilustrativo: padrão pseudoaleatório, NÃO é um QR Code válido
  const n = 25, cell = 8; let seed = 42, svg = '';
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  const finder = (x, y) => x < 7 && y < 7 || x > n - 8 && y < 7 || x < 7 && y > n - 8;
  const fr = (x, y) => { const f = (a, b) => { const dx = Math.min(a, 6 - a), dy = Math.min(b, 6 - b); const m = Math.min(dx, dy); return m !== 1; };
    const ox = x > n - 8 ? x - (n - 7) : x, oy = y > n - 8 ? y - (n - 7) : y; return f(ox, oy); };
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    const on = finder(x, y) ? fr(x, y) : rnd() > .52;
    if (on) svg += `<rect x="${x * cell}" y="${y * cell}" width="${cell}" height="${cell}"/>`;
  }
  $('#qr').innerHTML = `<svg viewBox="0 0 ${n * cell} ${n * cell}" fill="#111">${svg}</svg>`;
}
const li = (inner, cls = 'item') => `<li class="${cls}">${inner}</li>`;

async function renderScreen(name) {
  fillProfile();
  if (name === 'home') {
    $('#quick').innerHTML = QUICK.map(([id, l, ic]) => `<button class="q" data-go="${id}"><span class="ic"><i data-i="${ic}"></i></span>${l}</button>`).join('');
    $('#grid').innerHTML = SERVICES.map(s => `<button class="card" data-go="${s.id}" style="--dot:${s.dot}"><span class="ic" style="background:${s.c};color:${s.k}"><i data-i="${s.i}"></i></span><span class="ar"><i data-i="arrow"></i></span><h3>${s.t}</h3><p>${s.s}</p><span class="cta">${s.cta}</span></button>`).join('');
    paintIcons($('[data-screen="home"]'));
  }
  if (name === 'agenda') $('#list-agenda').innerHTML = (await api.listEvents()).map(e => li(`<div class="d">${e.d}<br>${e.n}</div><div><b>${esc(e.t)}</b><small>${esc(e.s)}</small><br><span class="tag demo">Demonstração</span></div>`)).join('');
  if (name === 'avisos') {
    const n = await api.listNotices();
    $('#list-avisos').innerHTML = n.length ? n.map(x => li(`<div><b>${esc(x.t)}</b><small>${esc(x.s)}</small><br><span class="tag demo">Demonstração</span></div>`)).join('') : li('Nenhum aviso por enquanto.', 'empty');
  }
  if (name === 'contrib') {
    const c = await api.listContributions();
    $('#list-contrib').innerHTML = c.length ? c.map(x => li(esc(x.t))).join('') : li('Nenhum lançamento para mostrar.', 'empty');
  }
  if (name === 'oracao') renderPrayers();
  if (name === 'carteirinha') renderQR();
  if (name === 'perfil') {
    const p = state.profile; $('#e-name').value = p.name; $('#e-email').value = p.email; $('#e-phone').value = p.phone || ''; $('#e-cell').value = p.cell;
    ['e-name', 'e-email', 'e-phone'].forEach(i => setErr(i, ''));
  }
}
async function renderPrayers() {
  const l = await api.listPrayers();
  $('#list-prayers').innerHTML = l.length
    ? l.map(p => li(`<div><b>${esc(p.text)}</b><br><span class="tag open">${p.status}</span> <span class="tag demo">Somente neste aparelho</span><br><small>${fmtDate(p.at)}</small></div>`)).join('')
    : li('Você ainda não enviou pedidos. Escreva o primeiro acima.', 'empty');
}

/* ---------- 7. Formulários ---------- */
function bindForms() {
  const cellOpts = '<option value="">Célula*</option>' + CONFIG.cells.map(c => `<option>${c}</option>`).join('');
  $('#r-cell').innerHTML = cellOpts; $('#e-cell').innerHTML = CONFIG.cells.map(c => `<option>${c}</option>`).join('');
  $('#r-ddi').innerHTML = CONFIG.countries.map(([v, l]) => `<option value="${v}">${l}</option>`).join('');
  $('#r-birth').max = new Date().toISOString().slice(0, 10);
  $('#r-birth').addEventListener('input', e => e.target.previousElementSibling.hidden = !!e.target.value);

  $('#form-login').addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('#l-email').value, pass = $('#l-pass').value;
    if (!check([['l-email', V.email(email)], ['l-pass', V.loginPass(pass)]])) return;
    state.profile = await api.login(email.trim(), pass); $('#l-pass').value = ''; toast(SB.enabled ? 'Bem-vindo!' : 'Entrada de demonstração.'); go('home');
  });
  $('#form-register').addEventListener('submit', async e => {
    e.preventDefault();
    const g = i => $('#' + i).value;
    const ok = check([['r-name', V.name(g('r-name'))], ['r-birth', V.birth(g('r-birth'))], ['r-phone', V.phone(g('r-phone'))], ['r-email', V.email(g('r-email'))], ['r-pass', V.pass(g('r-pass'))], ['r-cell', V.cell(g('r-cell'))], ['r-terms', $('#r-terms').checked ? '' : 'Aceite a Política de Privacidade para continuar.']]);
    if (!ok) return;
    const phone = g('r-phone').trim() ? g('r-ddi') + ' ' + g('r-phone').trim() : '';
    state.profile = await api.register({ name: g('r-name').trim(), birth: g('r-birth'), phone, email: g('r-email').trim(), cell: g('r-cell'), photo: '' }, g('r-pass')); // a senha só vai ao serviço de autenticação, nunca é guardada aqui
    $('#form-register').reset(); toast(SB.enabled ? 'Cadastro criado!' : 'Cadastro de demonstração criado.'); go('home');
  });
  $('#form-forgot').addEventListener('submit', async e => {
    e.preventDefault();
    if (!check([['f-email', V.email($('#f-email').value)]])) return;
    const sent = await api.recover($('#f-email').value.trim());
    $('#f-msg').classList.remove('demo'); $('#f-msg').textContent = sent ? 'Se o e-mail existir, você receberá um link para redefinir a senha.' : 'Demonstração: nenhum e-mail foi enviado. A recuperação real exige o backend.'; toast(sent ? 'Pedido enviado.' : 'Nada foi enviado (demonstração).');
  });
  const pt = $('#p-text');
  pt.addEventListener('input', () => { $('#p-count').textContent = pt.value.length + '/500'; $('#p-err').textContent = ''; });
  $('#form-prayer').addEventListener('submit', async e => {
    e.preventDefault();
    const t = pt.value.trim();
    if (t.length < 5) { $('#p-err').textContent = 'Escreva ao menos algumas palavras.'; pt.focus(); return; }
    if (!(await api.addPrayer(t))) { $('#p-err').textContent = 'Não foi possível salvar neste navegador.'; return; }
    pt.value = ''; $('#p-count').textContent = '0/500'; toast(SB.enabled ? 'Pedido enviado com cuidado à liderança.' : 'Pedido salvo neste aparelho. Não foi enviado.'); renderPrayers();
  });
  $('#form-profile').addEventListener('submit', async e => {
    e.preventDefault();
    const g = i => $('#' + i).value;
    if (!check([['e-name', V.name(g('e-name'))], ['e-email', V.email(g('e-email'))], ['e-phone', V.phone(g('e-phone'))]])) return;
    state.profile = await api.saveProfile({ ...state.profile, name: g('e-name').trim(), email: g('e-email').trim(), phone: g('e-phone').trim(), cell: g('e-cell') });
    fillProfile(); toast('Alterações salvas neste aparelho.');
  });
  $('#p-photo').addEventListener('change', e => {
    const f = e.target.files[0]; if (!f) return;
    if (!f.type.startsWith('image/') || f.size > 1.5e6) return toast('Escolha uma imagem de até 1,5 MB.');
    const r = new FileReader();
    r.onload = async () => { state.profile = await api.saveProfile({ ...state.profile, photo: r.result }); fillProfile(); toast('Foto atualizada neste aparelho.'); };
    r.readAsDataURL(f);
  });
  $('#btn-logout').addEventListener('click', async () => { await api.logout(); state.profile = null; toast('Você saiu da conta.'); go('login'); });
  $('#btn-clear').addEventListener('click', async () => {
    if (!confirm('Apagar perfil e pedidos salvos neste navegador?')) return;
    await api.clearLocal(); state.profile = null; go('login'); toast('Dados locais apagados.');
  });
  $('#btn-share').addEventListener('click', async () => {
    const text = `Carteirinha de demonstração Ágape+ — ${state.profile.name} (${state.profile.cell}). Não é um documento oficial.`;
    try { if (navigator.share) await navigator.share({ title: 'Ágape+', text }); else { await navigator.clipboard.writeText(text); toast('Texto copiado.'); } }
    catch (err) { if (err.name !== 'AbortError') toast('Não foi possível compartilhar.'); }
  });
}
function bindSearch() {
  const dlg = $('#dlg-search'), input = $('#s-input'), list = $('#s-list');
  const draw = () => {
    const q = input.value.trim().toLowerCase();
    const r = SERVICES.filter(s => (s.t + ' ' + s.s).toLowerCase().includes(q));
    list.innerHTML = r.length ? r.map(s => `<li><button type="button" class="item" data-s="${s.id}"><div><b>${s.t}</b><small>${s.s}</small></div></button></li>`).join('') : li('Nada encontrado. Tente outra palavra.', 'empty');
  };
  $('#btn-search').addEventListener('click', () => { input.value = ''; draw(); dlg.showModal(); input.focus(); });
  input.addEventListener('input', draw);
  list.addEventListener('click', e => { const b = e.target.closest('[data-s]'); if (b) { dlg.close(); go(b.dataset.s); } });
}

/* ---------- 8. Inicialização ---------- */
async function init() {
  await api.init?.();
  paintIcons(); bindForms(); bindSearch();
  window.addEventListener('unhandledrejection', e => toast((e.reason && e.reason.message) || 'Algo deu errado. Tente de novo.'));
  if (SB.enabled) document.body.classList.add('live');
  try { if (await api.getSession()) state.profile = await api.getProfile(); } catch { state.profile = null; }
  bindInstall();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) navigator.serviceWorker.register('service-worker.js').catch(() => {});
  setTimeout(() => {
    $('[data-screen="splash"]').classList.add('out');
    setTimeout(() => { $('[data-screen="splash"]').hidden = true; state.ready = true; if (!state.profile) location.hash = 'login'; route(); }, 400);
  }, CONFIG.splashMs);
}
init();

/* ---------- 9. Instalação como PWA ---------- */
function bindInstall() {
  let ev = null; const btn = $('#btn-install');
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); ev = e; btn.hidden = false; });
  btn.addEventListener('click', async () => { if (!ev) return; ev.prompt(); await ev.userChoice; ev = null; btn.hidden = true; });
  window.addEventListener('appinstalled', () => { btn.hidden = true; toast('Aplicativo instalado.'); });
}
