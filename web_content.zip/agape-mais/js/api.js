'use strict';
/* ===== Ágape+ — protótipo demonstrativo (HTML + CSS + JS puro) =====
   Tudo que é salvo fica no navegador (localStorage), NÃO é seguro nem sincronizado.
   Para ligar um servidor, troque apenas o objeto `api` (seção 2). */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* ---------- 1. Configuração e dados de demonstração ---------- */
const CONFIG = {
  splashMs: 2500,
  defaultAvatar: 'assets/images/avatar.svg',
  cells: ['Célula Centro', 'Célula Norte', 'Célula Sul', 'Célula Jovens', 'Célula Famílias'], // exemplo
  countries: [['+55', 'BR +55'], ['+351', 'PT +351'], ['+1', 'US +1'], ['+54', 'AR +54'], ['+595', 'PY +595'], ['+244', 'AO +244']],
};
const DEMO = {
  events: [
    { d: 'DOM', n: '19h', t: 'Culto de celebração', s: 'Horário de exemplo' },
    { d: 'QUA', n: '20h', t: 'Culto de oração', s: 'Horário de exemplo' },
    { d: 'SEX', n: '20h', t: 'Reunião de célula', s: 'Horário de exemplo' },
    { d: 'SÁB', n: '16h', t: 'Encontro de jovens', s: 'Horário de exemplo' },
  ],
  notices: [
    { t: 'Bem-vindo ao Ágape+', s: 'Aqui aparecerão os avisos da liderança quando o servidor estiver conectado.' },
    { t: 'Aviso de exemplo', s: 'Este texto serve apenas para mostrar o layout da lista de mensagens.' },
  ],
};

/* ---------- 2. Camada de dados (trocar por backend no futuro) ---------- */
const store = {
  get(k, d = null) { try { const v = localStorage.getItem('agape:' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('agape:' + k, JSON.stringify(v)); return true; } catch { return false; } },
  del(k) { try { localStorage.removeItem('agape:' + k); } catch {} },
  clear() { try { Object.keys(localStorage).filter(k => k.startsWith('agape:')).forEach(k => localStorage.removeItem(k)); } catch {} },
};
/* Cada método é assíncrono de propósito: no backend real vira fetch('/api/...'). */
const api = {
  async getSession() { return store.get('session'); },
  async register(p) { store.set('profile', p); store.set('session', { email: p.email }); return p; },      // futuro: POST /auth/register
  async login(email) {                                                                                      // futuro: POST /auth/login (senha verificada no servidor)
    let p = store.get('profile');
    if (!p || p.email.toLowerCase() !== email.toLowerCase()) p = { name: 'Membro de demonstração', email, phone: '', cell: CONFIG.cells[0], photo: '' };
    store.set('profile', p); store.set('session', { email }); return p;
  },
  async logout() { store.del('session'); },
  async getProfile() { return store.get('profile'); },
  async saveProfile(p) { store.set('profile', p); return p; },
  async listPrayers() { return store.get('prayers', []); },
  async addPrayer(text) { const l = store.get('prayers', []); l.unshift({ id: Date.now(), text, status: 'Aberto', at: new Date().toISOString() }); return store.set('prayers', l) ? l : null; },
  async listEvents() { return DEMO.events; },
  async listNotices() { return DEMO.notices; },
  async listContributions() { return []; },                                                                  // futuro: GET /contributions (sem dados fictícios)
  async clearLocal() { store.clear(); },
};

