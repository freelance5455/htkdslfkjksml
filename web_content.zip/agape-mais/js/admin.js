'use strict';
/* Painel da liderança. ATENÇÃO: esconder botões NÃO protege nada. Quem decide o que cada pessoa pode ler ou
   gravar são as políticas RLS do banco (supabase/schema.sql). Aqui só adaptamos a tela ao perfil. */
const SECTIONS = {
  members: { label: 'Membros', table: 'profiles', order: 'name', readonly: true, cols: [['name', 'Nome'], ['phone', 'Telefone'], ['cell', 'Célula'], ['role', 'Acesso']] },
  cells: { label: 'Células', table: 'cells', order: 'name', admin: true, cols: [['name', 'Nome']], fields: [['name', 'Nome', 'text']] },
  events: { label: 'Agenda', table: 'events', order: 'starts_at', cols: [['title', 'Evento'], ['starts_at', 'Início', 'dt'], ['location', 'Local']], fields: [['title', 'Título', 'text'], ['starts_at', 'Início', 'datetime-local'], ['location', 'Local', 'text']] },
  notices: { label: 'Avisos', table: 'notices', order: 'created_at.desc', cols: [['title', 'Título'], ['published', 'Publicado', 'bool']], fields: [['title', 'Título', 'text'], ['body', 'Texto', 'textarea'], ['published', 'Publicar agora', 'checkbox']] },
  prayers: { label: 'Orações', table: 'prayer_requests', order: 'created_at.desc', status: ['aberto', 'em oração', 'respondido'], cols: [['text', 'Pedido'], ['created_at', 'Data', 'dt']] },
  money: { label: 'Contribuições', table: 'contributions', order: 'occurred_on.desc', admin: true, cols: [['occurred_on', 'Data'], ['amount_cents', 'Valor', 'money'], ['kind', 'Tipo']], fields: [['user_id', 'Membro', 'member'], ['amount_cents', 'Valor (R$)', 'money'], ['kind', 'Tipo', 'text'], ['occurred_on', 'Data', 'date']] },
};
const adm = { role: null, cur: 'members', members: [] };
const fmt = (v, t) => v == null ? '' : t === 'dt' ? new Date(v).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : t === 'bool' ? (v ? 'Sim' : 'Não') : t === 'money' ? 'R$ ' + (v / 100).toFixed(2).replace('.', ',') : esc(v);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const say = m => { $('#astate').textContent = m; $('#astate').hidden = !m; };
const allowed = s => adm.role === 'admin' || (adm.role === 'leader' && !s.admin);

async function boot() {
  window.addEventListener('unhandledrejection', e => say((e.reason && e.reason.message) || 'Algo deu errado.'));
  if (!SB.enabled) return say('Modo demonstração: a administração só funciona com o backend configurado (veja o README).');
  if (!SB.session()) return say('Entre primeiro pelo app (index.html) com uma conta da liderança.');
  const me = await SB.req('/rest/v1/profiles?id=eq.' + SB.session().user.id + '&select=role');
  adm.role = me[0] && me[0].role;
  if (!['leader', 'admin'].includes(adm.role)) return say('Acesso restrito à liderança.');
  say('');
  $('#anav').innerHTML = Object.entries(SECTIONS).filter(([, s]) => allowed(s)).map(([k, s]) => `<button data-k="${k}">${s.label}</button>`).join('');
  $('#anav').addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (b) show(b.dataset.k); });
  if (adm.role === 'admin') adm.members = await SB.req('/rest/v1/profiles?select=id,name&order=name');
  show('members');
}
async function show(k) {
  adm.cur = k; const s = SECTIONS[k];
  $$('#anav button').forEach(b => b.classList.toggle('on', b.dataset.k === k));
  const rows = await SB.req(`/rest/v1/${s.table}?select=*&order=${s.order}`);
  const head = s.cols.map(c => `<th>${c[1]}</th>`).join('') + (s.status ? '<th>Status</th>' : '') + (s.fields ? '<th></th>' : '');
  const body = rows.length ? rows.map(r => `<tr>${s.cols.map(c => `<td>${fmt(r[c[0]], c[2])}</td>`).join('')}${s.status ? `<td><select data-id="${r.id}">${s.status.map(o => `<option${o === r.status ? ' selected' : ''}>${o}</option>`).join('')}</select></td>` : ''}${s.fields ? `<td><button data-del="${r.id}">Excluir</button></td>` : ''}</tr>`).join('')
    : `<tr><td colspan="9">Nada cadastrado ainda.</td></tr>`;
  const form = s.fields ? `<form class="card-form" id="aform" novalidate><h2>Novo registro</h2>${s.fields.map(f => field(f)).join('')}<small class="err" id="aerr"></small><button class="btn-blue">Salvar</button></form>` : '';
  $('#aview').innerHTML = `<div class="tablewrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>${form}`;
}
function field([n, l, t]) {
  if (t === 'textarea') return `<label>${l}<textarea name="${n}" rows="4"></textarea></label>`;
  if (t === 'checkbox') return `<label><span><input type="checkbox" name="${n}"> ${l}</span></label>`;
  if (t === 'member') return `<label>${l}<select name="${n}"><option value="">Escolha…</option>${adm.members.map(m => `<option value="${m.id}">${esc(m.name)}</option>`).join('')}</select></label>`;
  return `<label>${l}<input name="${n}" type="${t === 'money' ? 'text' : t}" ${t === 'money' ? 'inputmode="decimal"' : ''}></label>`;
}
document.addEventListener('submit', async e => {
  if (e.target.id !== 'aform') return; e.preventDefault();
  const s = SECTIONS[adm.cur], body = {};
  for (const [n, l, t] of s.fields) {
    const el = e.target.elements[n]; let v = t === 'checkbox' ? el.checked : el.value.trim();
    if (t !== 'checkbox' && !v && n !== 'body' && n !== 'location') { $('#aerr').textContent = `Preencha: ${l}.`; return; }
    if (t === 'money') { v = Math.round(parseFloat(v.replace(',', '.')) * 100); if (!(v > 0)) { $('#aerr').textContent = 'Valor inválido.'; return; } }
    if (t === 'datetime-local') v = new Date(v).toISOString();
    body[n] = v;
  }
  await SB.req('/rest/v1/' + s.table, { method: 'POST', body }); toast('Salvo.'); show(adm.cur);
});
document.addEventListener('click', async e => {
  const d = e.target.closest('[data-del]'); if (!d || !confirm('Excluir este registro?')) return;
  await SB.req(`/rest/v1/${SECTIONS[adm.cur].table}?id=eq.${d.dataset.del}`, { method: 'DELETE' }); toast('Excluído.'); show(adm.cur);
});
document.addEventListener('change', async e => {
  if (!e.target.dataset.id) return;
  await SB.req(`/rest/v1/prayer_requests?id=eq.${e.target.dataset.id}`, { method: 'PATCH', body: { status: e.target.value } }); toast('Status atualizado.');
});
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2200); }
boot();
