'use strict';
/* Cliente mínimo do Supabase (Auth + REST) sem bibliotecas. Só ativa se supabase-config.js estiver preenchido.
   A segurança vem das políticas RLS do banco (supabase/schema.sql), NÃO deste arquivo. */
const SB = (() => {
  const c = window.AGAPE_SUPABASE || {};
  const enabled = !!(c.url && c.anonKey);
  const session = () => store.get('sb'); // atenção: tokens ficam no localStorage, como no cliente oficial
  const msg = j => j && (j.msg || j.message || j.error_description || j.error);
  async function req(path, { method = 'GET', body, auth = true, prefer } = {}) {
    const s = session();
    const headers = { apikey: c.anonKey, 'Content-Type': 'application/json', Authorization: 'Bearer ' + (auth && s ? s.access_token : c.anonKey) };
    if (prefer) headers.Prefer = prefer;
    const r = await fetch(c.url + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const t = await r.text(); let j = null; try { j = t ? JSON.parse(t) : null; } catch {}
    if (r.status === 401 && auth && s) { store.del('sb'); throw new Error('Sessão expirada. Entre novamente.'); }
    if (!r.ok) throw new Error(msg(j) || 'Erro ' + r.status);
    return j;
  }
  return { enabled, req, session };
})();

if (SB.enabled) {
  const { req, session } = SB;
  const uid = () => session()?.user?.id;
  const cap = s => s ? s[0].toUpperCase() + s.slice(1) : '';
  const toProfile = r => ({ name: r.name, email: session()?.user?.email || r.email || '', phone: r.phone || '', cell: r.cell || '', birth: r.birth, photo: '', role: r.role || 'member' });
  Object.assign(api, {
    async init() { try { const l = await req('/rest/v1/cells?select=name&order=name', { auth: false }); if (l.length) CONFIG.cells = l.map(x => x.name); } catch {} },
    async getSession() { return session(); },
    async register(p, pw) {
      const j = await req('/auth/v1/signup', { auth: false, method: 'POST', body: { email: p.email, password: pw, data: { name: p.name, phone: p.phone, birth: p.birth, cell: p.cell } } });
      if (!j.access_token) throw new Error('Cadastro criado. Confirme seu e-mail e depois entre.');
      store.set('sb', j); return this.getProfile();
    },
    async login(email, pw) { const j = await req('/auth/v1/token?grant_type=password', { auth: false, method: 'POST', body: { email, password: pw } }); store.set('sb', j); return this.getProfile(); },
    async getProfile() { const r = await req('/rest/v1/profiles?id=eq.' + uid() + '&select=*'); return r[0] ? toProfile(r[0]) : null; },
    async saveProfile(p) { const r = await req('/rest/v1/profiles?id=eq.' + uid(), { method: 'PATCH', prefer: 'return=representation', body: { name: p.name, phone: p.phone, cell: p.cell } }); return toProfile(r[0]); }, // e-mail não é alterado aqui
    async logout() { try { await req('/auth/v1/logout', { method: 'POST' }); } catch {} store.del('sb'); },
    async recover(email) { await req('/auth/v1/recover', { auth: false, method: 'POST', body: { email } }); return true; },
    async listPrayers() { const r = await req('/rest/v1/prayer_requests?select=*&user_id=eq.' + uid() + '&order=created_at.desc'); return r.map(x => ({ id: x.id, text: x.text, status: cap(x.status), at: x.created_at })); },
    async addPrayer(text) { await req('/rest/v1/prayer_requests', { method: 'POST', body: { user_id: uid(), text } }); return true; },
    async listEvents() {
      const r = await req('/rest/v1/events?select=*&starts_at=gte.' + new Date().toISOString() + '&order=starts_at');
      return r.map(e => { const d = new Date(e.starts_at); return { d: d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '').toUpperCase().slice(0, 3), n: d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), t: e.title, s: e.location || '' }; });
    },
    async listNotices() { const r = await req('/rest/v1/notices?select=*&published=eq.true&order=created_at.desc'); return r.map(n => ({ t: n.title, s: n.body })); },
    async listContributions() {
      const r = await req('/rest/v1/contributions?select=*&user_id=eq.' + uid() + '&order=occurred_on.desc');
      return r.map(x => ({ t: `${x.kind} · R$ ${(x.amount_cents / 100).toFixed(2).replace('.', ',')} · ${new Date(x.occurred_on + 'T12:00').toLocaleDateString('pt-BR')}` }));
    },
    async clearLocal() { store.clear(); },
  });
}
