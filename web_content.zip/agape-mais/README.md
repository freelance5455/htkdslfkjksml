# Ágape+ — PWA (HTML, CSS e JavaScript puro)

*Fazendo o que Jesus mandou, do jeito que Jesus fez.*

## Estrutura
- `index.html` app (todas as telas) · `admin.html` painel da liderança
- `style.css` visual · `responsive.css` tablet e computador · `admin.css`
- `script.js` interface · `js/api.js` dados de demonstração · `js/supabase.js` backend · `js/admin.js` painel
- `supabase-config.js` (vazio = modo demonstração) · `supabase/schema.sql` tabelas e políticas de segurança
- `manifest.webmanifest`, `service-worker.js`, `assets/{logo,images,icons}`

## Executar localmente
O service worker exige `http://localhost` (não funciona abrindo o arquivo com duplo clique).
```
cd agape-mais
python3 -m http.server 8000     # abra http://localhost:8000
```
Sem configurar o backend, o app roda em **modo demonstração** (dados só neste navegador).

## Publicar com HTTPS
Hospedagem estática com HTTPS automático: Netlify, Vercel, Cloudflare Pages ou GitHub Pages. Envie a pasta inteira. PWA e instalação exigem HTTPS (localhost é exceção). Ao alterar arquivos, aumente `VERSION` em `service-worker.js`.

## Instalar como aplicativo
Depende do navegador e do sistema; os recursos não são idênticos aos de um app Android nativo.
- Android (Chrome): botão "Instalar aplicativo" em Perfil, ou menu ⋮ → Instalar app.
- Windows/Mac (Chrome ou Edge): ícone de instalar na barra de endereço. Safari no Mac: Arquivo → Adicionar ao Dock.
- iPhone/iPad (Safari): Compartilhar → Adicionar à Tela de Início.

## Configurar o backend (Supabase)
1. Crie um projeto em supabase.com. Em SQL Editor, execute `supabase/schema.sql` e revise as políticas.
2. Em Authentication, defina a URL do site e decida se exige confirmação de e-mail.
3. Preencha `supabase-config.js` com **Project URL** e **anon key** (pública). **Nunca** use a `service_role key` no navegador.
4. Cadastre-se no app e promova o primeiro administrador no SQL Editor: `update public.profiles set role='admin' where id = '<id do usuário>';`
5. Com `role` leader/admin aparece "Admin" no menu → `admin.html`.
A autorização é feita pelo banco (RLS): esconder botões não protege dados.

## Transparência: o que está pronto e o que não
| Item | Situação |
|---|---|
| Telas, navegação, validação, layout celular/tablet/computador | Pronto; testado no Chromium (celular 390px e desktop 1366px): sem erros de console no fluxo login → início → oração |
| Modo demonstração (dados locais) | Pronto; **não é segurança** e não sincroniza entre aparelhos |
| Manifest, service worker, ícones | Criados; **não testados** em Android/iOS/Mac reais |
| Supabase (cadastro, login, perfil, oração, agenda, avisos, contribuições) | Código escrito, **nunca executado contra um projeto real**; schema.sql não validado |
| Painel admin (membros, células, agenda, avisos, orações, contribuições) | Código escrito, **não testado**; só cria, exclui e muda status (sem edição de registros) |
| Carteirinha/QR | **Demonstrativa**: QR não é válido nem verificável; validação real exigiria servidor com QR assinado |
| Não implementado | Notificações push, pagamentos online, recuperação de senha com tela de nova senha, edição de e-mail, upload de foto na nuvem, refresh automático de sessão (expira em ~1h) |
| Comparação com as referências | Feita a olho; sem comparação automática de pixels |

## Personalizar
Logo: `assets/logo/logo.svg` (branca, para fundo escuro) e `logo-dark.svg` (para fundo claro). Foto padrão: `assets/images/avatar.svg`. Ícones de instalação: `assets/icons/` (192 e 512 px, e versão "maskable"). Células, textos de exemplo e cores: `js/api.js` (`CONFIG`, `DEMO`) e variáveis em `style.css`.

## Privacidade (LGPD)
Pedidos de oração e contribuições são dados sensíveis. Antes do uso real: política de privacidade própria, definir quem acessa cada dado, e backups e exclusão sob solicitação.
