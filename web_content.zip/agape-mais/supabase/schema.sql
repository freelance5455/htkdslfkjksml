-- Ágape+ · esquema Supabase (Postgres) com RLS. NÃO TESTADO em projeto real: revise antes de usar.
-- Execute no SQL Editor do Supabase. Depois promova o primeiro admin (ver README).

create table public.cells (id uuid primary key default gen_random_uuid(), name text unique not null, created_at timestamptz not null default now());
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null, phone text, birth date, cell text,
  role text not null default 'member' check (role in ('member','leader','admin')),
  created_at timestamptz not null default now());
create table public.events (id uuid primary key default gen_random_uuid(), title text not null, starts_at timestamptz not null, location text, created_at timestamptz not null default now());
create table public.notices (id uuid primary key default gen_random_uuid(), title text not null, body text, published boolean not null default false, created_at timestamptz not null default now());
create table public.prayer_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  text text not null check (char_length(text) between 5 and 500),
  status text not null default 'aberto' check (status in ('aberto','em oração','respondido')),
  created_at timestamptz not null default now());
create table public.contributions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  amount_cents integer not null check (amount_cents > 0),
  kind text not null, occurred_on date not null,
  created_by uuid default auth.uid(), created_at timestamptz not null default now());

-- Funções de papel (security definer evita recursão nas políticas)
create function public.role_of(uid uuid) returns text language sql stable security definer set search_path = public as $$ select role from public.profiles where id = uid $$;
create function public.is_staff() returns boolean language sql stable security definer set search_path = public as $$ select coalesce(public.role_of(auth.uid()) in ('leader','admin'), false) $$;
create function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$ select coalesce(public.role_of(auth.uid()) = 'admin', false) $$;

-- Perfil criado automaticamente no cadastro (dados vêm do formulário; o papel SEMPRE começa 'member')
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, phone, birth, cell)
  values (new.id, coalesce(new.raw_user_meta_data->>'name','Membro'), new.raw_user_meta_data->>'phone',
          nullif(new.raw_user_meta_data->>'birth','')::date, new.raw_user_meta_data->>'cell');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Só admin muda papéis (SQL Editor, com auth.uid() nulo, também pode: serve para criar o 1º admin)
create function public.protect_role() returns trigger language plpgsql as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'Somente administradores alteram o nível de acesso';
  end if;
  return new;
end $$;
create trigger protect_role before update on public.profiles for each row execute function public.protect_role();

alter table public.cells enable row level security;
alter table public.profiles enable row level security;
alter table public.events enable row level security;
alter table public.notices enable row level security;
alter table public.prayer_requests enable row level security;
alter table public.contributions enable row level security;

create policy cells_read on public.cells for select to anon, authenticated using (true);
create policy cells_admin on public.cells for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy profiles_read on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy events_read on public.events for select to authenticated using (true);
create policy events_staff on public.events for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy notices_read on public.notices for select to authenticated using (published or public.is_staff());
create policy notices_staff on public.notices for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy prayers_read on public.prayer_requests for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy prayers_insert on public.prayer_requests for insert to authenticated with check (user_id = auth.uid());
create policy prayers_staff_update on public.prayer_requests for update to authenticated using (public.is_staff()) with check (public.is_staff());

create policy money_read on public.contributions for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy money_admin on public.contributions for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Exemplo de células (edite):
insert into public.cells (name) values ('Célula Centro'), ('Célula Norte'), ('Célula Sul');
