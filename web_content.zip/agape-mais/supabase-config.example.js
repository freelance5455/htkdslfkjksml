/* Deixe vazio para o modo DEMONSTRAÇÃO (dados locais). Para usar o backend, veja o README.
   A anon key é pública por projeto — NUNCA coloque aqui a service_role key. */
window.AGAPE_SUPABASE = { url: '', anonKey: '' };
