YESUF COOLING SYSTEM (የሱፍ የማቀዝቀዣ ሲስተም) - OFFLINE MOBILE APP
===================================================================

በስልክ ላይ ያለ ኢንተርኔት (Offline) እንዴት መጠቀም ይቻላል?
1. ይህን ZIP ፋይል በስልክዎ ውስጥ Extract (Unzip) ያድርጉ።
2. Chrome Browser ይክፈቱ ወይም index.html የሚለውን ፋይል በ Chrome ይክፈቱት።
   (ማሳሰቢያ፡ እንደ App ወደ Home Screen ለመጫን ፋይሎቹን በቀላል Local Web Server ወይም GitHub Pages/Netlify አንዴ ከከፈቱ በኋላ ሙሉ በሙሉ ያለ ኢንተርኔት ይሰራል፤ ወይም index.html በቀጥታ ከስልክ ማህደረ ትውስታ በመክፈት ሁሉንም ዳታ ያለ ኢንተርኔት መመዝገብ ይችላሉ።)
3. Chrome ላይ ከላይ በቀኝ በኩል ያለውን ሶስት ነጥብ (⋮) በመጫን "Add to Home screen" (ወደ መነሻ ማያ ገጽ አክል) ይበሉት።

የተካተቱ ፋይሎች፡
- index.html     : ዋናው የሞባይል አፕሊኬሽን (Amharic / English)
- manifest.json  : የሞባይል PWA መለያ ፋይል
- sw.js          : ያለ ኢንተርኔት (Offline) ፋይሎችን የሚያስቀምጥ Service Worker
- icon.svg       : የአፕሊኬሽኑ አርማ (App Icon)
