# CleanCity Android project (v1.1)

Native Android WebView wrapper around the CleanCity waste-management prototype (`app/src/main/assets/index.html`).
Package: `com.cleancity.waste`

## Build an APK
**Android Studio:** open this folder, let Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
Output: `app/build/outputs/apk/debug/app-debug.apk`.

**No computer setup (GitHub):** push this folder to a GitHub repo; the *Build APK* workflow runs automatically
(Actions tab > latest run > Artifacts > `CleanCity-debug-apk`). Install the APK on your phone (allow "install unknown apps").

## What changed in 1.1
- Reports, status changes, reminders and the selected area now persist between launches.
- Dashboard counters update with your reports; urgent reports are badged.
- Back button steps through screens and only exits from Home.
- Fixed header/nav overlapping system bars on Android 15 (edge-to-edge).
- Added launcher icon; no activity restart on rotation; external links open in the browser.
- Hardened WebView (no file/content access); pinch-zoom re-enabled for accessibility.
- Added Gradle wrapper settings (Gradle 8.9) and a GitHub Actions APK build.

## Prototype limitations
No backend, municipal integration, authentication, photo/GPS capture or push notifications. Dashboard figures and
collection times are illustrative. Debug APKs are for testing; create a signed release build before publishing.
