# Publier « Maquis CANCUN » sur Google Play — guide pas à pas

> Les règles de Google changent. Vérifiez les conditions actuelles dans la Play Console avant de payer ou d’envoyer quoi que ce soit.

## Contenu du dossier
| Fichier | Rôle |
|---|---|
| `index.html` | L’application (fonctionne hors ligne une fois installée) |
| `manifest.webmanifest` | Nom, couleurs, icônes de l’application |
| `sw.js` | Permet le fonctionnement sans internet |
| `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` | Icônes jaune et vert |
| `confidentialite.html` | Politique de confidentialité (à mettre en ligne) |

## Étape 1 — Mettre le dossier sur un site en https
Il faut une adresse web sécurisée (https). Options gratuites : Netlify (netlify.com, « glisser-déposer » du dossier), GitHub Pages, Cloudflare Pages.
Avant d’envoyer : ouvrez `confidentialite.html` et remplacez `[VOTRE ADRESSE E-MAIL]` par votre vraie adresse.
Vous obtenez deux adresses, par exemple :
- `https://votre-site.netlify.app/` (application)
- `https://votre-site.netlify.app/confidentialite.html` (politique de confidentialité)

## Étape 2 — Tester l’installation
Ouvrez l’adresse dans Chrome sur Android. Menu ⋮ → « Installer l’application ». Vérifiez : icône verte et jaune, ouverture en plein écran, ventes possibles en mode avion.

## Étape 3 — Fabriquer le fichier Android
1. Allez sur **pwabuilder.com** et collez l’adresse de l’application.
2. Cliquez sur « Package for stores » → **Android** → Google Play.
3. Nom du paquet conseillé : `ci.cancun.gestion`. Version : 1.
4. Téléchargez le résultat : un fichier **.aab** et un fichier de **clé de signature**.
5. **Gardez la clé et son mot de passe en lieu sûr** (copie sur clé USB et e-mail). Sans elle, vous ne pourrez plus mettre à jour l’application.
6. Mettez en ligne le fichier `assetlinks.json` fourni par PWABuilder dans le dossier `.well-known/` de votre site (cela retire la barre d’adresse dans l’application).

## Étape 4 — Compte Google Play Console
1. play.google.com/console → créer un compte développeur (paiement unique d’environ 25 $, pièce d’identité demandée).
2. « Créer une application » : nom **Maquis CANCUN – Gestion**, langue **Français**, type **Application**, **Gratuite**.

## Étape 5 — Fiche de l’application (textes prêts à copier)
**Titre (30 caractères max)** : `Maquis CANCUN Gestion`

**Description courte (80 max)** : `Gérez ventes, caisse, stock et employés de votre maquis, même sans internet.`

**Description complète** :
```
Maquis CANCUN est une application de gestion pour maquis et bars, simple et rapide, qui fonctionne même sans internet.

• Ventes au comptoir et à table, paiement espèces, Mobile Money, Wave ou crédit
• Tickets de reçu imprimables (Bluetooth, USB ou impression classique)
• Caisse du jour avec fond de caisse et écart
• Stocks avec alerte de stock bas
• Achats, bons de commande et dettes fournisseurs
• Crédits clients (ardoise)
• Dépenses et salaires par semaine, commissions des serveurs, jours travaillés
• Comptes caissiers avec accès limité
• Rapports du jour, de la semaine et du mois, export PDF
• Sauvegarde et restauration des données

Vos données restent sur votre téléphone. Aucune publicité.
```
**Éléments graphiques à préparer**
- Icône : `icon-512.png` (fournie)
- Image de présentation : 1024 × 500 px (à créer, fond vert, titre jaune)
- Captures d’écran : au moins 2 (prenez-les depuis le téléphone : Vente, Rapports, Caisse)

## Étape 6 — Formulaires obligatoires
- **Politique de confidentialité** : collez l’adresse de `confidentialite.html`.
- **Sécurité des données** : répondez que l’application **ne collecte aucune donnée** et n’en partage aucune.
- **Classification du contenu** : questionnaire ; application professionnelle, sans contenu sensible.
- **Public cible** : adultes (18 ans et plus). **Publicité** : aucune.
- **Application de vente d’alcool ?** : l’application ne vend rien, elle sert à la gestion. Répondez honnêtement aux questions sur l’alcool.

## Étape 7 — Envoi et validation
1. Menu « Production » (ou « Test fermé ») → « Créer une version » → envoyez le fichier `.aab`.
2. **Important** : pour un compte personnel récent, Google peut exiger un **test fermé avec un nombre minimum de testeurs pendant plusieurs jours** avant la production. Vérifiez la règle actuelle dans la console et préparez quelques amis testeurs avec des comptes Google.
3. Envoyez pour examen. La validation prend de quelques jours à plus d’une semaine.

## Mises à jour
Pour modifier l’application : changez `index.html`, mettez à jour `const C='cancun-v1'` dans `sw.js` (par exemple `cancun-v2`), remettez le dossier en ligne. L’application installée se met à jour toute seule au prochain lancement avec internet.
