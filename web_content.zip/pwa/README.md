# Hamvaght Plus PWA

Files: index.html, manifest.webmanifest, sw.js, icons/.

## Run locally (service workers need http://localhost or https)
    cd pwa && python3 -m http.server 8080
Open http://localhost:8080

## Install on Android phone
Host the folder on any HTTPS static host (GitHub Pages, Netlify, Cloudflare Pages).
Open the URL in Chrome > tap "Install app" (or menu > Install app / Add to Home screen).
iPhone: Safari > Share > Add to Home Screen.

## Website vs PWA vs APK
Website: opens in a browser tab. PWA: same code, installed with its own icon and window, works offline after first visit. APK: native package; build it from this PWA with Bubblewrap (TWA) or Capacitor. Not built here.

## Notes
Data stays in browser storage on that device; export backups. Updating: bump V in sw.js.
