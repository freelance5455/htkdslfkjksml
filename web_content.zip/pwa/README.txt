Quiz Kamai - installable app package

1) Is folder ko free hosting par daalo (Netlify Drop: app.netlify.com/drop, ya GitHub Pages).
2) Aapko https wala link milega. Phone mein kholo -> "Add to Home Screen" = install ho jayega.
3) APK ke liye: pwabuilder.com par woh link daalo -> Package for stores -> Android -> Download.
   (Play Store ke liye ek baar Google Play developer account chahiye.)
4) Asli ads ke liye AdMob native app mein lagta hai (Capacitor + AdMob plugin).
