(function (global) {
  const DB_NAME = 'sd_travel_pwa_db';
  const DB_VERSION = 1;

  const TRIP_TYPES = {
    EIGHT_DAYS: '8 أيام',
    FOURTEEN_DAYS: '14 يومًا',
    CUSTOM: 'برنامج مخصص'
  };

  const BOOKING_STATUS = {
    CONFIRMED: 'مؤكد',
    PENDING: 'قيد الانتظار',
    COMPLETED: 'مكتمل',
    CANCELLED: 'ملغي'
  };

  const PAYMENT_METHODS = {
    CASH: 'نقدي',
    TRANSFER: 'تحويل',
    OTHER: 'أخرى'
  };

  const DOCUMENT_TYPES = {
    PASSPORT: 'صورة جواز السفر',
    NATIONAL_ID: 'صورة البطاقة الشخصية',
    VISA: 'صورة التأشيرة',
    FLIGHT_TICKET: 'صورة تذكرة الطيران',
    PAYMENT_RECEIPT: 'إيصالات الدفع',
    OTHER: 'صور أخرى'
  };

  let dbPromise = null;

  function normalizeCode(code) {
    return String(code || '').trim().toLowerCase();
  }

  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains('clients')) {
          const clients = db.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
          clients.createIndex('clientCodeNormalized', 'clientCodeNormalized', { unique: true });
        }
        if (!db.objectStoreNames.contains('bookings')) {
          const bookings = db.createObjectStore('bookings', { keyPath: 'id', autoIncrement: true });
          bookings.createIndex('clientId', 'clientId', { unique: false });
          bookings.createIndex('clientCode', 'clientCode', { unique: false });
          bookings.createIndex('tripDate', 'tripDate', { unique: false });
        }
        if (!db.objectStoreNames.contains('payments')) {
          const payments = db.createObjectStore('payments', { keyPath: 'id', autoIncrement: true });
          payments.createIndex('bookingId', 'bookingId', { unique: false });
          payments.createIndex('clientCode', 'clientCode', { unique: false });
        }
        if (!db.objectStoreNames.contains('documents')) {
          const docs = db.createObjectStore('documents', { keyPath: 'id', autoIncrement: true });
          docs.createIndex('bookingId', 'bookingId', { unique: false });
          docs.createIndex('clientCode', 'clientCode', { unique: false });
        }
        if (!db.objectStoreNames.contains('meta')) {
          db.createObjectStore('meta', { keyPath: 'key' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return dbPromise;
  }

  async function requestPersistentStorage() {
    if (navigator.storage && typeof navigator.storage.persist === 'function') {
      try {
        await navigator.storage.persist();
      } catch (_) {}
    }
  }

  function reqToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function txDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
    });
  }

  async function getAllFromStore(storeName) {
    const db = await openDb();
    const tx = db.transaction(storeName, 'readonly');
    return reqToPromise(tx.objectStore(storeName).getAll());
  }

  async function getMeta(key) {
    const db = await openDb();
    const tx = db.transaction('meta', 'readonly');
    const row = await reqToPromise(tx.objectStore('meta').get(key));
    return row ? row.value : null;
  }

  async function setMeta(key, value) {
    const db = await openDb();
    const tx = db.transaction('meta', 'readwrite');
    tx.objectStore('meta').put({ key, value });
    return txDone(tx);
  }

  async function isClientCodeAvailable(code, excludingClientId = null) {
    const norm = normalizeCode(code);
    if (!norm) return false;
    const db = await openDb();
    const tx = db.transaction('clients', 'readonly');
    const existing = await reqToPromise(tx.objectStore('clients').index('clientCodeNormalized').get(norm));
    if (!existing) return true;
    return excludingClientId !== null && existing.id === excludingClientId;
  }

  async function getAllClientsWithDetails() {
    const [clients, bookings, payments, documents] = await Promise.all([
      getAllFromStore('clients'),
      getAllFromStore('bookings'),
      getAllFromStore('payments'),
      getAllFromStore('documents')
    ]);

    const paymentsByBooking = new Map();
    for (const p of payments) {
      if (!paymentsByBooking.has(p.bookingId)) paymentsByBooking.set(p.bookingId, []);
      paymentsByBooking.get(p.bookingId).push(p);
    }

    const docsByBooking = new Map();
    for (const d of documents) {
      if (!docsByBooking.has(d.bookingId)) docsByBooking.set(d.bookingId, []);
      docsByBooking.get(d.bookingId).push(d);
    }

    const bookingsByClient = new Map();
    for (const b of bookings) {
      const bPayments = (paymentsByBooking.get(b.id) || []).sort((a, c) => (c.paymentDate || '').localeCompare(a.paymentDate || ''));
      const bDocs = docsByBooking.get(b.id) || [];
      const totalDue = Number(b.totalPrice || 0) + Number(b.extraAmount || 0);
      const totalPaid = bPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const remainingAmount = totalDue - totalPaid;
      const enrichedBooking = {
        ...b,
        payments: bPayments,
        documents: bDocs,
        totalDue,
        totalPaid,
        remainingAmount,
        profitAmount: totalDue - Number(b.costAmount || 0)
      };
      if (!bookingsByClient.has(b.clientId)) bookingsByClient.set(b.clientId, []);
      bookingsByClient.get(b.clientId).push(enrichedBooking);
    }

    return clients
      .sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))
      .map((c) => {
        const cBookings = (bookingsByClient.get(c.id) || []).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
        const totalPaidAcrossBookings = cBookings.reduce((s, b) => s + b.totalPaid, 0);
        const totalRemainingAcrossBookings = cBookings
          .filter((b) => b.status !== 'CANCELLED')
          .reduce((s, b) => s + b.remainingAmount, 0);
        return {
          client: c,
          bookings: cBookings,
          totalPaidAcrossBookings,
          totalRemainingAcrossBookings
        };
      });
  }

  async function createClientAndBooking({ client, booking, depositAmount, attachments }) {
    const trimmedCode = String(client.clientCode || '').trim();
    const trimmedName = String(client.fullName || '').trim();
    if (!trimmedCode) throw new Error('يجب إدخال كود العميل يدويًا');
    if (!trimmedName) throw new Error('يجب إدخال اسم العميل بالكامل');

    const available = await isClientCodeAvailable(trimmedCode);
    if (!available) {
      throw new Error(`كود العميل (${trimmedCode}) مسجل مسبقًا، يمنع تكرار الأكواد`);
    }

    const db = await openDb();
    const tx = db.transaction(['clients', 'bookings', 'payments', 'documents'], 'readwrite');
    const now = Date.now();
    const todayIso = new Date().toISOString().slice(0, 10);

    const clientId = await reqToPromise(
      tx.objectStore('clients').add({
        ...client,
        clientCode: trimmedCode,
        clientCodeNormalized: normalizeCode(trimmedCode),
        fullName: trimmedName,
        createdAt: now
      })
    );

    const bookingId = await reqToPromise(
      tx.objectStore('bookings').add({
        ...booking,
        clientId,
        clientCode: trimmedCode,
        totalPrice: Number(booking.totalPrice || 0),
        extraAmount: Number(booking.extraAmount || 0),
        costAmount: Number(booking.costAmount || 0),
        createdAt: now
      })
    );

    const dep = Number(depositAmount || 0);
    if (dep > 0) {
      await reqToPromise(
        tx.objectStore('payments').add({
          bookingId,
          clientCode: trimmedCode,
          amount: dep,
          paymentDate: todayIso,
          paymentMethod: 'CASH',
          isDeposit: true,
          notes: 'مقدم الحجز',
          createdAt: now
        })
      );
    }

    for (const att of attachments || []) {
      if (att.blob instanceof Blob) {
        await reqToPromise(
          tx.objectStore('documents').add({
            bookingId,
            clientCode: trimmedCode,
            docType: att.docType,
            title: att.title || '',
            mimeType: att.blob.type || 'image/jpeg',
            fileName: att.fileName || 'document.jpg',
            blob: att.blob,
            createdAt: now
          })
        );
      }
    }

    await txDone(tx);
    return { clientId, bookingId };
  }

  async function addBookingToClient({ clientId, clientCode, booking, depositAmount, attachments }) {
    const db = await openDb();
    const tx = db.transaction(['bookings', 'payments', 'documents'], 'readwrite');
    const now = Date.now();
    const todayIso = new Date().toISOString().slice(0, 10);

    const bookingId = await reqToPromise(
      tx.objectStore('bookings').add({
        ...booking,
        clientId,
        clientCode,
        totalPrice: Number(booking.totalPrice || 0),
        extraAmount: Number(booking.extraAmount || 0),
        costAmount: Number(booking.costAmount || 0),
        createdAt: now
      })
    );

    const dep = Number(depositAmount || 0);
    if (dep > 0) {
      await reqToPromise(
        tx.objectStore('payments').add({
          bookingId,
          clientCode,
          amount: dep,
          paymentDate: todayIso,
          paymentMethod: 'CASH',
          isDeposit: true,
          notes: 'مقدم الحجز',
          createdAt: now
        })
      );
    }

    for (const att of attachments || []) {
      if (att.blob instanceof Blob) {
        await reqToPromise(
          tx.objectStore('documents').add({
            bookingId,
            clientCode,
            docType: att.docType,
            title: att.title || '',
            mimeType: att.blob.type || 'image/jpeg',
            fileName: att.fileName || 'document.jpg',
            blob: att.blob,
            createdAt: now
          })
        );
      }
    }

    await txDone(tx);
    return bookingId;
  }

  async function updateClient(updatedClient) {
    const trimmedCode = String(updatedClient.clientCode || '').trim();
    const trimmedName = String(updatedClient.fullName || '').trim();
    if (!trimmedCode) throw new Error('يجب إدخال كود العميل يدويًا');
    if (!trimmedName) throw new Error('يجب إدخال اسم العميل بالكامل');

    const available = await isClientCodeAvailable(trimmedCode, updatedClient.id);
    if (!available) {
      throw new Error(`كود العميل (${trimmedCode}) مستخدم لعميل آخر، لا يمكن التكرار`);
    }

    const db = await openDb();
    const tx = db.transaction(['clients', 'bookings', 'payments', 'documents'], 'readwrite');

    await reqToPromise(
      tx.objectStore('clients').put({
        ...updatedClient,
        clientCode: trimmedCode,
        clientCodeNormalized: normalizeCode(trimmedCode),
        fullName: trimmedName
      })
    );

    // Keep clientCode synchronized across linked bookings, payments, and Blob documents
    const bookings = await reqToPromise(tx.objectStore('bookings').index('clientId').getAll(updatedClient.id));
    for (const b of bookings) {
      if (b.clientCode !== trimmedCode) {
        await reqToPromise(tx.objectStore('bookings').put({ ...b, clientCode: trimmedCode }));
      }
      const pList = await reqToPromise(tx.objectStore('payments').index('bookingId').getAll(b.id));
      for (const p of pList) {
        if (p.clientCode !== trimmedCode) {
          await reqToPromise(tx.objectStore('payments').put({ ...p, clientCode: trimmedCode }));
        }
      }
      const dList = await reqToPromise(tx.objectStore('documents').index('bookingId').getAll(b.id));
      for (const d of dList) {
        if (d.clientCode !== trimmedCode) {
          await reqToPromise(tx.objectStore('documents').put({ ...d, clientCode: trimmedCode }));
        }
      }
    }

    await txDone(tx);
  }

  async function updateBooking(updatedBooking) {
    const db = await openDb();
    const tx = db.transaction('bookings', 'readwrite');
    await reqToPromise(
      tx.objectStore('bookings').put({
        ...updatedBooking,
        totalPrice: Number(updatedBooking.totalPrice || 0),
        extraAmount: Number(updatedBooking.extraAmount || 0),
        costAmount: Number(updatedBooking.costAmount || 0)
      })
    );
    await txDone(tx);
  }

  async function deleteBookingCascade(bookingId) {
    const db = await openDb();
    const tx = db.transaction(['bookings', 'payments', 'documents'], 'readwrite');
    const payments = await reqToPromise(tx.objectStore('payments').index('bookingId').getAll(bookingId));
    for (const p of payments) tx.objectStore('payments').delete(p.id);

    const docs = await reqToPromise(tx.objectStore('documents').index('bookingId').getAll(bookingId));
    for (const d of docs) tx.objectStore('documents').delete(d.id);

    tx.objectStore('bookings').delete(bookingId);
    await txDone(tx);
  }

  async function deleteClientCascade(clientId) {
    const db = await openDb();
    const tx = db.transaction(['clients', 'bookings', 'payments', 'documents'], 'readwrite');
    const bookings = await reqToPromise(tx.objectStore('bookings').index('clientId').getAll(clientId));
    for (const b of bookings) {
      const payments = await reqToPromise(tx.objectStore('payments').index('bookingId').getAll(b.id));
      for (const p of payments) tx.objectStore('payments').delete(p.id);
      const docs = await reqToPromise(tx.objectStore('documents').index('bookingId').getAll(b.id));
      for (const d of docs) tx.objectStore('documents').delete(d.id);
      tx.objectStore('bookings').delete(b.id);
    }
    tx.objectStore('clients').delete(clientId);
    await txDone(tx);
  }

  async function savePayment(payment) {
    const db = await openDb();
    const tx = db.transaction('payments', 'readwrite');
    const payload = {
      ...payment,
      amount: Number(payment.amount || 0),
      createdAt: payment.createdAt || Date.now()
    };
    if (payment.id) {
      await reqToPromise(tx.objectStore('payments').put(payload));
    } else {
      await reqToPromise(tx.objectStore('payments').add(payload));
    }
    await txDone(tx);
  }

  async function deletePayment(paymentId) {
    const db = await openDb();
    const tx = db.transaction('payments', 'readwrite');
    tx.objectStore('payments').delete(paymentId);
    await txDone(tx);
  }

  async function addDocumentBlob({ bookingId, clientCode, docType, title, blob, fileName }) {
    const db = await openDb();
    const tx = db.transaction('documents', 'readwrite');
    await reqToPromise(
      tx.objectStore('documents').add({
        bookingId,
        clientCode,
        docType,
        title: title || '',
        mimeType: blob.type || 'image/jpeg',
        fileName: fileName || 'document.jpg',
        blob,
        createdAt: Date.now()
      })
    );
    await txDone(tx);
  }

  async function replaceDocumentBlob(doc, newBlob, newFileName) {
    const db = await openDb();
    const tx = db.transaction('documents', 'readwrite');
    await reqToPromise(
      tx.objectStore('documents').put({
        ...doc,
        mimeType: newBlob.type || 'image/jpeg',
        fileName: newFileName || doc.fileName || 'document.jpg',
        blob: newBlob
      })
    );
    await txDone(tx);
  }

  async function deleteDocument(docId) {
    const db = await openDb();
    const tx = db.transaction('documents', 'readwrite');
    tx.objectStore('documents').delete(docId);
    await txDone(tx);
  }

  global.SdTravelDb = {
    TRIP_TYPES,
    BOOKING_STATUS,
    PAYMENT_METHODS,
    DOCUMENT_TYPES,
    openDb,
    requestPersistentStorage,
    normalizeCode,
    isClientCodeAvailable,
    getAllClientsWithDetails,
    getAllFromStore,
    getMeta,
    setMeta,
    createClientAndBooking,
    addBookingToClient,
    updateClient,
    updateBooking,
    deleteBookingCascade,
    deleteClientCascade,
    savePayment,
    deletePayment,
    addDocumentBlob,
    replaceDocumentBlob,
    deleteDocument,
    reqToPromise,
    txDone
  };
})(window);
