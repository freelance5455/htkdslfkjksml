(function (global) {
  const crcTable = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
      crc = crcTable[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function buildZipBlob(files) {
    const encoder = new TextEncoder();
    const localParts = [];
    const centralParts = [];
    let offset = 0;

    for (const file of files) {
      const nameBytes = encoder.encode(file.name);
      const dataBytes = typeof file.content === 'string' ? encoder.encode(file.content) : file.content;
      const crc = crc32(dataBytes);

      const localHeader = new Uint8Array(30 + nameBytes.length);
      const lv = new DataView(localHeader.buffer);
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(6, 0x0800, true); // UTF-8
      lv.setUint16(8, 0, true); // store
      lv.setUint16(10, 0, true);
      lv.setUint16(12, 0, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, dataBytes.length, true);
      lv.setUint32(22, dataBytes.length, true);
      lv.setUint16(26, nameBytes.length, true);
      lv.setUint16(28, 0, true);
      localHeader.set(nameBytes, 30);

      localParts.push(localHeader, dataBytes);

      const centralHeader = new Uint8Array(46 + nameBytes.length);
      const cv = new DataView(centralHeader.buffer);
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, 20, true);
      cv.setUint16(6, 20, true);
      cv.setUint16(8, 0x0800, true);
      cv.setUint16(10, 0, true);
      cv.setUint16(12, 0, true);
      cv.setUint16(14, 0, true);
      cv.setUint32(16, crc, true);
      cv.setUint32(20, dataBytes.length, true);
      cv.setUint32(24, dataBytes.length, true);
      cv.setUint16(28, nameBytes.length, true);
      cv.setUint16(30, 0, true);
      cv.setUint16(32, 0, true);
      cv.setUint16(34, 0, true);
      cv.setUint16(36, 0, true);
      cv.setUint32(38, 0, true);
      cv.setUint32(42, offset, true);
      centralHeader.set(nameBytes, 46);

      centralParts.push(centralHeader);
      offset += localHeader.length + dataBytes.length;
    }

    const centralSize = centralParts.reduce((s, p) => s + p.length, 0);
    const eocd = new Uint8Array(22);
    const ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(4, 0, true);
    ev.setUint16(6, 0, true);
    ev.setUint16(8, files.length, true);
    ev.setUint16(10, files.length, true);
    ev.setUint32(12, centralSize, true);
    ev.setUint32(16, offset, true);
    ev.setUint16(20, 0, true);

    return new Blob([...localParts, ...centralParts, eocd], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
  }

  function escapeXml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  function colLetter(index) {
    let i = index;
    let out = '';
    while (i >= 0) {
      out = String.fromCharCode(65 + (i % 26)) + out;
      i = Math.floor(i / 26) - 1;
    }
    return out;
  }

  function exportReportToXlsx(report, fromDate, toDate) {
    const sharedStrings = [];
    const stringMap = new Map();
    const intern = (text) => {
      const val = String(text ?? '');
      if (stringMap.has(val)) return stringMap.get(val);
      const idx = sharedStrings.length;
      sharedStrings.push(val);
      stringMap.set(val, idx);
      return idx;
    };

    const rows = [];
    let rowNum = 1;
    rows.push(`<row r="${rowNum}" ht="26" customHeight="1"><c r="A${rowNum}" t="s" s="1"><v>${intern('SD TRAVEL - ' + report.title)}</v></c></row>`);
    rowNum++;

    const today = new Date().toISOString().slice(0, 10);
    let period = `تاريخ التصدير: ${today}`;
    if (fromDate || toDate) {
      period += ` | الفترة: ${fromDate || 'البداية'} إلى ${toDate || 'النهاية'}`;
    }
    rows.push(`<row r="${rowNum}" ht="20" customHeight="1"><c r="A${rowNum}" t="s" s="2"><v>${intern(period)}</v></c></row>`);
    rowNum++;

    if (report.summaryMetrics && report.summaryMetrics.length) {
      const summary = report.summaryMetrics.map(([k, v]) => `${k}: ${v}`).join(' | ');
      rows.push(`<row r="${rowNum}" ht="20" customHeight="1"><c r="A${rowNum}" t="s" s="2"><v>${intern(summary)}</v></c></row>`);
      rowNum++;
    }

    rowNum++;
    const colCount = Math.max(1, report.headers.length);
    const colWidths = report.headers.map((h) => Math.min(38, Math.max(14, String(h).length + 6)));

    rows.push(`<row r="${rowNum}" ht="24" customHeight="1">` +
      report.headers.map((h, idx) => `<c r="${colLetter(idx)}${rowNum}" t="s" s="1"><v>${intern(h)}</v></c>`).join('') +
      `</row>`);
    rowNum++;

    report.rows.forEach((r, rIdx) => {
      const style = rIdx % 2 === 0 ? 3 : 4;
      const cells = [];
      for (let c = 0; c < colCount; c++) {
        const val = String(r[c] ?? '');
        colWidths[c] = Math.min(42, Math.max(colWidths[c], val.length + 4));
        cells.push(`<c r="${colLetter(c)}${rowNum}" t="s" s="${style}"><v>${intern(val)}</v></c>`);
      }
      rows.push(`<row r="${rowNum}" ht="20" customHeight="1">${cells.join('')}</row>`);
      rowNum++;
    });

    const colsXml = '<cols>' + colWidths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('') + '</cols>';
    const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews>
  <sheetFormatPr defaultRowHeight="20"/>
  ${colsXml}
  <sheetData>${rows.join('')}</sheetData>
</worksheet>`;

    const sharedXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedStrings.length}" uniqueCount="${sharedStrings.length}">
${sharedStrings.map((s) => `<si><t xml:space="preserve">${escapeXml(s)}</t></si>`).join('')}
</sst>`;

    const files = [
      {
        name: '[Content_Types].xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>`
      },
      {
        name: '_rels/.rels',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`
      },
      {
        name: 'xl/workbook.xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="تقرير SD TRAVEL" sheetId="1" r:id="rId1"/></sheets>
</workbook>`
      },
      {
        name: 'xl/_rels/workbook.xml.rels',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>`
      },
      {
        name: 'xl/styles.xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="3">
    <font><sz val="11"/><name val="Arial"/></font>
    <font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FF0B1F3A"/><name val="Arial"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF0B1F3A"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFDF6DF"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF4F6F9"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFDCE2EC"/></left><right style="thin"><color rgb="FFDCE2EC"/></right><top style="thin"><color rgb="FFDCE2EC"/></top><bottom style="thin"><color rgb="FFDCE2EC"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="5">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2" wrapText="1"/></xf>
  </cellXfs>
</styleSheet>`
      },
      { name: 'xl/sharedStrings.xml', content: sharedXml },
      { name: 'xl/worksheets/sheet1.xml', content: sheetXml }
    ];

    const blob = buildZipBlob(files);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SD_TRAVEL_Report_${report.id}_${today}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function printHtmlAsPdf(title, htmlBody) {
    const win = window.open('', '_blank');
    if (!win) {
      window.print();
      return;
    }
    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"/>
<title>${escapeXml(title)}</title>
<style>
  body { font-family: Tahoma, Arial, sans-serif; direction: rtl; padding: 20px; color: #0F172A; }
  .pdf-header { background: #0B1F3A; color: #fff; padding: 14px 18px; border-bottom: 4px solid #D4AF37; border-radius: 10px; display:flex; justify-content:space-between; align-items:center; margin-bottom: 16px; }
  .pdf-header h1 { margin: 0; color: #D4AF37; font-size: 20px; }
  .pdf-summary { background: #FDF6DF; border: 1px solid #D4AF37; padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; font-weight: bold; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th { background: #0B1F3A; color: #D4AF37; padding: 8px; text-align: right; }
  td { border: 1px solid #DCE2EC; padding: 7px; text-align: right; }
  tr:nth-child(even) td { background: #F4F6F9; }
  .box { border: 1px solid #DCE2EC; border-radius: 10px; padding: 12px; margin-bottom: 12px; }
  .box h3 { margin: 0 0 8px; color: #0B1F3A; border-bottom: 2px solid #D4AF37; padding-bottom: 4px; }
  @media print { body { padding: 0; } }
</style>
</head>
<body>${htmlBody}</body>
</html>`);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); }, 250);
  }

  function exportReportPdf(report, fromDate, toDate) {
    const today = new Date().toISOString().slice(0, 10);
    const period = (fromDate || toDate) ? ` | الفترة: ${fromDate || 'البداية'} إلى ${toDate || 'النهاية'}` : '';
    const metrics = (report.summaryMetrics || []).map(([k, v]) => `${k}: ${v}`).join('  |  ');
    const html = `
      <div class="pdf-header">
        <div><h1>SD TRAVEL</h1><div>${escapeXml(report.title)}</div></div>
        <div>${today}${escapeXml(period)}</div>
      </div>
      ${metrics ? `<div class="pdf-summary">${escapeXml(metrics)}</div>` : ''}
      <table>
        <thead><tr>${report.headers.map((h) => `<th>${escapeXml(h)}</th>`).join('')}</tr></thead>
        <tbody>
          ${report.rows.map((r) => `<tr>${r.map((c) => `<td>${escapeXml(c)}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>`;
    printHtmlAsPdf(report.title, html);
  }

  function printClientPdf(clientItem, booking) {
    const c = clientItem.client;
    const today = new Date().toISOString().slice(0, 10);
    const html = `
      <div class="pdf-header">
        <div><h1>SD TRAVEL</h1><div>بطاقة بيانات العميل وحجز العمرة</div></div>
        <div>${today}</div>
      </div>
      <div class="box">
        <h3>البيانات الشخصية</h3>
        <p><strong>كود العميل:</strong> ${escapeXml(c.clientCode)} &nbsp;|&nbsp; <strong>الاسم:</strong> ${escapeXml(c.fullName)}</p>
        <p><strong>الهاتف:</strong> ${escapeXml(c.phone || '-')} &nbsp;|&nbsp; <strong>الواتساب:</strong> ${escapeXml(c.whatsapp || '-')}</p>
        <p><strong>البطاقة:</strong> ${escapeXml(c.nationalId || '-')} &nbsp;|&nbsp; <strong>الجواز:</strong> ${escapeXml(c.passportNumber || '-')}</p>
        <p><strong>تاريخ الميلاد:</strong> ${escapeXml(c.birthDate || '-')}</p>
      </div>
      ${booking ? `
      <div class="box">
        <h3>تفاصيل الرحلة (${escapeXml(global.SdTravelDb.BOOKING_STATUS[booking.status] || booking.status)})</h3>
        <p><strong>تاريخ الرحلة:</strong> ${escapeXml(booking.tripDate)} &nbsp;|&nbsp; <strong>تاريخ العودة:</strong> ${escapeXml(booking.returnDate || '-')}</p>
        <p><strong>نوع البرنامج:</strong> ${escapeXml(global.SdTravelDb.TRIP_TYPES[booking.tripType] || booking.tripType)} ${booking.customTripLabel ? `(${escapeXml(booking.customTripLabel)})` : ''}</p>
        <p><strong>شركة السياحة:</strong> ${escapeXml(booking.companyName || '-')}</p>
        <p><strong>فندق مكة:</strong> ${escapeXml(booking.makkahHotel || '-')} &nbsp;|&nbsp; <strong>فندق المدينة:</strong> ${escapeXml(booking.madinahHotel || '-')}</p>
      </div>
      <div class="pdf-summary">
        سعر الرحلة: ${booking.totalPrice} | الإضافات: ${booking.extraAmount} | إجمالي المدفوع: ${booking.totalPaid} | المتبقي: ${booking.remainingAmount}
      </div>
      <div class="box">
        <h3>سجل المدفوعات (${booking.payments.length})</h3>
        <table>
          <thead><tr><th>التاريخ</th><th>المبلغ</th><th>الطريقة</th><th>ملاحظات</th></tr></thead>
          <tbody>
            ${booking.payments.map((p) => `<tr><td>${escapeXml(p.paymentDate)}</td><td>${p.amount}</td><td>${escapeXml(global.SdTravelDb.PAYMENT_METHODS[p.paymentMethod] || p.paymentMethod)}</td><td>${escapeXml(p.notes || '-')}</td></tr>`).join('')}
          </tbody>
        </table>
      </div>` : ''}`;
    printHtmlAsPdf(`SD_TRAVEL_${c.clientCode}`, html);
  }

  global.SdTravelExport = {
    exportReportToXlsx,
    exportReportPdf,
    printClientPdf
  };
})(window);
