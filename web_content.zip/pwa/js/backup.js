(function (global) {
  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = String(reader.result || '');
        const idx = result.indexOf(',');
        resolve(idx >= 0 ? result.slice(idx + 1) : result);
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }

  function base64ToBlob(base64, mimeType) {
    const binary = atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([bytes], { type: mimeType || 'image/jpeg' });
  }

  async function createFullBackupFile() {
    const db = global.SdTravelDb;
    const [clients, bookings, payments, documents] = await Promise.all([
      db.getAllFromStore('clients'),
      db.getAllFromStore('bookings'),
      db.getAllFromStore('payments'),
      db.getAllFromStore('documents')
    ]);

    const serializedDocs = [];
    for (const d of documents) {
      const dataBase64 = d.blob instanceof Blob ? await blobToBase64(d.blob) : '';
      serializedDocs.push({
        id: d.id,
        bookingId: d.bookingId,
        clientCode: d.clientCode,
        docType: d.docType,
        title: d.title || '',
        mimeType: d.mimeType || (d.blob && d.blob.type) || 'image/jpeg',
        fileName: d.fileName || 'document.jpg',
        createdAt: d.createdAt || Date.now(),
        dataBase64
      });
    }

    const timestamp = Date.now();
    const stamp = new Date(timestamp).toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const fileName = `SD_TRAVEL_Backup_${stamp}.sdbackup.json`;

    const payload = {
      schemaVersion: 1,
      app: 'SD TRAVEL PWA',
      createdAt: timestamp,
      clients,
      bookings,
      payments,
      documents: serializedDocs
    };

    const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);

    await db.setMeta('lastBackupTimestamp', timestamp);
    await db.setMeta('lastBackupName', fileName);

    return { timestamp, fileName, blob, clientCount: clients.length, docCount: serializedDocs.length };
  }

  async function shareLastCreatedBackup(blob, fileName) {
    if (!navigator.share || !navigator.canShare) return false;
    const file = new File([blob], fileName, { type: 'application/json' });
    if (!navigator.canShare({ files: [file] })) return false;
    await navigator.share({
      title: 'نسخة احتياطية SD TRAVEL',
      files: [file]
    });
    return true;
  }

  async function restoreFromBackupFile(file) {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!data || !Array.isArray(data.clients) || !Array.isArray(data.bookings)) {
      throw new Error('ملف النسخة الاحتياطية غير صالح');
    }

    const dbHelper = global.SdTravelDb;
    const db = await dbHelper.openDb();
    const tx = db.transaction(['clients', 'bookings', 'payments', 'documents'], 'readwrite');

    let addedClients = 0;
    let skippedDuplicateClients = 0;
    let addedBookings = 0;
    let addedPayments = 0;
    let restoredDocuments = 0;

    const oldClientIdToNewId = new Map();
    const skippedOldClientIds = new Set();
    const oldBookingIdToNewId = new Map();

    for (const c of data.clients) {
      const code = String(c.clientCode || '').trim();
      const norm = dbHelper.normalizeCode(code);
      if (!norm) continue;

      const existing = await dbHelper.reqToPromise(
        tx.objectStore('clients').index('clientCodeNormalized').get(norm)
      );

      if (existing) {
        skippedDuplicateClients++;
        skippedOldClientIds.add(c.id);
        oldClientIdToNewId.set(c.id, existing.id);
      } else {
        const clone = { ...c, clientCode: code, clientCodeNormalized: norm };
        delete clone.id;
        const newId = await dbHelper.reqToPromise(tx.objectStore('clients').add(clone));
        oldClientIdToNewId.set(c.id, newId);
        addedClients++;
      }
    }

    for (const b of data.bookings) {
      if (skippedOldClientIds.has(b.clientId)) continue;
      const newClientId = oldClientIdToNewId.get(b.clientId);
      if (!newClientId) continue;

      const oldId = b.id;
      const clone = { ...b, clientId: newClientId };
      delete clone.id;
      const newBookingId = await dbHelper.reqToPromise(tx.objectStore('bookings').add(clone));
      oldBookingIdToNewId.set(oldId, newBookingId);
      addedBookings++;
    }

    for (const p of (data.payments || [])) {
      const newBookingId = oldBookingIdToNewId.get(p.bookingId);
      if (!newBookingId) continue;
      const clone = { ...p, bookingId: newBookingId };
      delete clone.id;
      await dbHelper.reqToPromise(tx.objectStore('payments').add(clone));
      addedPayments++;
    }

    for (const d of (data.documents || [])) {
      const newBookingId = oldBookingIdToNewId.get(d.bookingId);
      if (!newBookingId || !d.dataBase64) continue;
      const blob = base64ToBlob(d.dataBase64, d.mimeType);
      await dbHelper.reqToPromise(
        tx.objectStore('documents').add({
          bookingId: newBookingId,
          clientCode: d.clientCode,
          docType: d.docType || 'OTHER',
          title: d.title || '',
          mimeType: d.mimeType || 'image/jpeg',
          fileName: d.fileName || 'document.jpg',
          blob,
          createdAt: d.createdAt || Date.now()
        })
      );
      restoredDocuments++;
    }

    await dbHelper.txDone(tx);

    return {
      addedClients,
      skippedDuplicateClients,
      addedBookings,
      addedPayments,
      restoredDocuments
    };
  }

  global.SdTravelBackup = {
    createFullBackupFile,
    shareLastCreatedBackup,
    restoreFromBackupFile
  };
})(window);
