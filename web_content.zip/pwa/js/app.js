(function (global) {
  const Db = global.SdTravelDb;
  const Export = global.SdTravelExport;
  const Backup = global.SdTravelBackup;

  const REPORTS = [
    { id: 1, title: 'تقرير جميع العملاء', subtitle: 'بيانات العملاء المسجلين وعدد حجوزاتهم' },
    { id: 2, title: 'تقرير جميع الحجوزات', subtitle: 'تفاصيل جميع حجوزات العمرة وحالاتها' },
    { id: 3, title: 'تقرير الرحلات القادمة', subtitle: 'الرحلات المجدولة من تاريخ اليوم فأعلى' },
    { id: 4, title: 'تقرير الحجوزات حسب تاريخ الرحلة', subtitle: 'مرتبة زمنيًا حسب تاريخ السفر' },
    { id: 5, title: 'تقرير الحجوزات حسب شركة السياحة', subtitle: 'إحصائيات وتفاصيل كل شركة سياحة' },
    { id: 6, title: 'تقرير المبالغ المحصلة', subtitle: 'سجل جميع الدفعات والمقدمات المحصلة' },
    { id: 7, title: 'تقرير المبالغ المتبقية', subtitle: 'أرصدة الحجوزات والمبالغ المستحقة' },
    { id: 8, title: 'تقرير العملاء غير المسددين بالكامل', subtitle: 'العملاء الذين عليهم مبالغ متبقية' },
    { id: 9, title: 'تقرير الحجوزات الملغاة', subtitle: 'الحجوزات الملغاة وتفاصيلها المالية' },
    { id: 10, title: 'تقرير الأرباح والفروق المالية', subtitle: 'مقارنة السعر والتكلفة وصافي الربح' }
  ];

  const state = {
    route: 'dashboard',
    clients: [],
    selectedClientId: null,
    selectedBookingId: null,
    addForExistingClientId: null,
    clientsQuery: '',
    clientsStatusFilter: null,
    clientsOnlyUnpaid: false,
    searchFilter: {
      clientCode: '',
      fullName: '',
      phone: '',
      passportNumber: '',
      exactTripDate: '',
      companyName: '',
      status: '',
      tripDateFrom: '',
      tripDateTo: ''
    },
    selectedReportId: 2,
    reportFromDate: '',
    reportToDate: '',
    lastBackupTimestamp: null,
    lastBackupName: null,
    lastBackupBlob: null,
    deferredInstallPrompt: null,
    isStandalone: window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true,
    isOnline: navigator.onLine,
    pendingAttachments: [],
    activeObjectUrls: []
  };

  function esc(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function money(num) {
    return Number(num || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
  }

  function todayIso() {
    return new Date().toISOString().slice(0, 10);
  }

  function formatTimestamp(ms) {
    if (!ms) return 'لم يتم إنشاء نسخة احتياطية بعد';
    return new Date(ms).toLocaleString('ar-EG', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  function showToast(text) {
    const root = document.getElementById('toastRoot');
    root.innerHTML = `<div class="toast">${esc(text)}</div>`;
    setTimeout(() => {
      if (root.firstChild) root.innerHTML = '';
    }, 3200);
  }

  function revokeObjectUrls() {
    for (const u of state.activeObjectUrls) {
      try { URL.revokeObjectURL(u); } catch (_) {}
    }
    state.activeObjectUrls = [];
  }

  function blobUrl(blob) {
    if (!(blob instanceof Blob)) return '';
    const u = URL.createObjectURL(blob);
    state.activeObjectUrls.push(u);
    return u;
  }

  async function refreshData() {
    state.clients = await Db.getAllClientsWithDetails();
    state.lastBackupTimestamp = await Db.getMeta('lastBackupTimestamp');
    state.lastBackupName = await Db.getMeta('lastBackupName');
  }

  function navigate(route, opts = {}) {
    if (opts.clientId !== undefined) state.selectedClientId = opts.clientId;
    if (opts.bookingId !== undefined) state.selectedBookingId = opts.bookingId;
    if (opts.addForExistingClientId !== undefined) state.addForExistingClientId = opts.addForExistingClientId;
    if (route === 'add_booking' && opts.addForExistingClientId === undefined) {
      state.addForExistingClientId = null;
      state.pendingAttachments = [];
    }
    state.route = route;
    window.scrollTo({ top: 0, behavior: 'instant' });
    render();
  }

  function computeDashboardStats() {
    const today = todayIso();
    const allBookings = state.clients.flatMap((c) => c.bookings);
    return {
      totalClients: state.clients.length,
      totalBookings: allBookings.length,
      upcomingTrips: allBookings.filter((b) => b.status !== 'CANCELLED' && b.tripDate && b.tripDate >= today).length,
      totalCollected: allBookings.reduce((s, b) => s + b.totalPaid, 0),
      totalRemaining: allBookings.filter((b) => b.status !== 'CANCELLED').reduce((s, b) => s + Math.max(0, b.remainingAmount), 0),
      confirmedCount: allBookings.filter((b) => b.status === 'CONFIRMED').length,
      pendingCount: allBookings.filter((b) => b.status === 'PENDING').length,
      cancelledCount: allBookings.filter((b) => b.status === 'CANCELLED').length
    };
  }

  function renderInstallBanner() {
    if (state.isStandalone) return '';
    if (state.deferredInstallPrompt) {
      return `
        <div class="install-banner">
          <div>
            <strong style="color:var(--navy)">تثبيت تطبيق SD TRAVEL</strong>
            <div style="font-size:12px;color:var(--text-secondary)">ثبّت التطبيق على الشاشة الرئيسية للعمل السريع بدون إنترنت</div>
          </div>
          <button id="installAppBtn" class="btn btn-primary btn-sm">تثبيت التطبيق</button>
        </div>`;
    }
    return `
      <div class="install-banner">
        <div style="font-size:12px;color:var(--navy)">
          <strong>لتثبيت التطبيق على أندرويد (Chrome):</strong> من قائمة المتصفح (⋮) اختر <strong>الإضافة إلى الشاشة الرئيسية / Install app</strong>
        </div>
      </div>`;
  }

  function renderTopBar(title, subtitle, showBack = true, extraHtml = '') {
    return `
      <header class="top-bar no-print">
        <div class="top-bar-title">
          ${showBack ? `<button id="backBtn" class="btn btn-gold btn-sm" aria-label="رجوع">→ رجوع</button>` : ''}
          <div>
            <h1>${esc(title)}</h1>
            ${subtitle ? `<small>${esc(subtitle)}</small>` : ''}
          </div>
        </div>
        <div>${extraHtml}</div>
      </header>`;
  }

  function renderDashboard() {
    const s = computeDashboardStats();
    const netPill = state.isOnline
      ? '<span class="offline-pill">جاهز للعمل بدون إنترنت</span>'
      : '<span class="offline-pill">وضع عدم الاتصال (Offline)</span>';

    return `
      <section class="hero-header">
        <div class="hero-row">
          <div class="brand-lockup">
            <img src="./icons/icon-192.png" alt="SD TRAVEL" />
            <div>
              <h1 class="brand-name">SD TRAVEL</h1>
              <p class="brand-sub">إدارة حجوزات وعملاء العمرة (IndexedDB محلي)</p>
            </div>
          </div>
          ${netPill}
        </div>
      </section>
      ${renderInstallBanner()}
      <div class="container">
        <h2 class="section-title">لوحة التحكم والإحصائيات</h2>
        <div class="grid-2 grid-4">
          <div class="kpi-card"><div class="kpi-value">${s.totalClients}</div><div class="kpi-label">إجمالي العملاء</div></div>
          <div class="kpi-card"><div class="kpi-value">${s.totalBookings}</div><div class="kpi-label">إجمالي الحجوزات</div></div>
          <div class="kpi-card"><div class="kpi-value">${s.upcomingTrips}</div><div class="kpi-label">الرحلات القادمة</div></div>
          <div class="kpi-card"><div class="kpi-value" style="color:var(--confirmed-fg)">${s.confirmedCount}</div><div class="kpi-label">الحجوزات المؤكدة</div></div>
          <div class="kpi-card"><div class="kpi-value" style="color:var(--pending-fg)">${s.pendingCount}</div><div class="kpi-label">قيد الانتظار</div></div>
          <div class="kpi-card"><div class="kpi-value" style="color:var(--cancelled-fg)">${s.cancelledCount}</div><div class="kpi-label">الحجوزات الملغاة</div></div>
          <div class="kpi-card"><div class="kpi-value" style="color:var(--confirmed-fg)">${money(s.totalCollected)}</div><div class="kpi-label">إجمالي المحصل</div></div>
          <div class="kpi-card"><div class="kpi-value" style="color:var(--pending-fg)">${money(s.totalRemaining)}</div><div class="kpi-label">إجمالي المتبقي</div></div>
        </div>

        <h2 class="section-title">القائمة الرئيسية السريعة</h2>
        <button id="goAddBooking" class="btn btn-primary btn-block" style="margin-bottom:10px">+ إضافة حجز جديد</button>
        <div class="grid-2" style="margin-bottom:12px">
          <button id="goClients" class="nav-tile"><strong>قائمة العملاء</strong><span>${s.totalClients} عميل مسجل</span></button>
          <button id="goSearch" class="nav-tile"><strong>البحث عن عميل</strong><span>بحث متعدد المعايير</span></button>
          <button id="goReports" class="nav-tile"><strong>التقارير</strong><span>10 تقارير • Excel و PDF</span></button>
          <button id="goBackup" class="nav-tile"><strong>النسخ الاحتياطي</strong><span>تصدير واستيراد شامل</span></button>
        </div>

        <h2 class="section-title">أحدث العملاء والحجوزات</h2>
        ${state.clients.length === 0 ? `
          <div class="card" style="text-align:center;padding:24px">
            <strong style="color:var(--navy)">لا توجد حجوزات مسجلة بعد</strong>
            <p style="color:var(--text-secondary);font-size:13px">ابدأ بإضافة أول عميل وحجز عمرة الآن ليُحفظ دائمًا داخل IndexedDB.</p>
          </div>
        ` : state.clients.slice(0, 6).map((item) => renderClientSummaryCard(item)).join('')}
      </div>`;
  }

  function renderClientSummaryCard(item) {
    const b = item.bookings[0];
    return `
      <div class="client-card" data-open-client="${item.client.id}">
        <div class="row-between" style="margin-bottom:6px">
          <div style="display:flex;align-items:center;gap:8px">
            <span class="code-badge">${esc(item.client.clientCode)}</span>
            <strong style="color:var(--navy);font-size:16px">${esc(item.client.fullName)}</strong>
          </div>
          ${b ? `<span class="badge badge-${b.status}">${esc(Db.BOOKING_STATUS[b.status] || b.status)}</span>` : ''}
        </div>
        <div class="row-between" style="font-size:13px;color:var(--text-secondary)">
          <span>الهاتف: ${esc(item.client.phone || '-')}</span>
          <span>${b ? `الرحلة: ${esc(b.tripDate)} • ${esc(b.companyName || Db.TRIP_TYPES[b.tripType] || '')}` : 'بدون رحلات'}</span>
        </div>
        <div class="row-between" style="margin-top:6px;font-size:13px;font-weight:700">
          <span style="color:var(--confirmed-fg)">المدفوع: ${money(item.totalPaidAcrossBookings)}</span>
          <span style="color:${item.totalRemainingAcrossBookings > 0 ? 'var(--pending-fg)' : 'var(--confirmed-fg)'}">المتبقي: ${money(item.totalRemainingAcrossBookings)}</span>
        </div>
      </div>`;
  }

  function renderAddBooking() {
    const existing = state.addForExistingClientId
      ? state.clients.find((c) => c.client.id === state.addForExistingClientId)?.client
      : null;

    return `
      ${renderTopBar(existing ? 'إضافة حجز جديد للعميل' : 'إضافة حجز جديد', 'كود العميل يدوي وإلزامي ويمنع تكراره')}
      <div class="container">
        <div id="addFormError" class="alert-error" style="display:none"></div>
        <form id="addBookingForm">
          <div class="card">
            <h3 class="section-title" style="margin-top:0">1. بيانات العميل والكود اليدوي</h3>
            <div class="form-group">
              <label>كود العميل (إجباري ويدوي — يمنع التكرار) *</label>
              <input id="fClientCode" class="input" required ${existing ? 'readonly' : ''} value="${esc(existing ? existing.clientCode : '')}" placeholder="مثال: SD-105" />
              <div id="codeDupWarn" class="error-text" style="display:none"></div>
            </div>
            <div class="form-group">
              <label>اسم العميل بالكامل *</label>
              <input id="fFullName" class="input" required ${existing ? 'readonly' : ''} value="${esc(existing ? existing.fullName : '')}" />
            </div>
            <div class="grid-2">
              <div class="form-group"><label>رقم الهاتف</label><input id="fPhone" class="input" type="tel" ${existing ? 'readonly' : ''} value="${esc(existing ? existing.phone : '')}" /></div>
              <div class="form-group"><label>رقم الواتساب</label><input id="fWhatsapp" class="input" type="tel" ${existing ? 'readonly' : ''} value="${esc(existing ? existing.whatsapp : '')}" /></div>
              <div class="form-group"><label>رقم البطاقة الشخصية</label><input id="fNationalId" class="input" ${existing ? 'readonly' : ''} value="${esc(existing ? existing.nationalId : '')}" /></div>
              <div class="form-group"><label>رقم جواز السفر</label><input id="fPassport" class="input" ${existing ? 'readonly' : ''} value="${esc(existing ? existing.passportNumber : '')}" /></div>
            </div>
            <div class="form-group"><label>تاريخ الميلاد</label><input id="fBirthDate" class="input" type="date" ${existing ? 'readonly' : ''} value="${esc(existing ? existing.birthDate : '')}" /></div>
          </div>

          <div class="card">
            <h3 class="section-title" style="margin-top:0">2. تفاصيل رحلة العمرة</h3>
            <div class="grid-2">
              <div class="form-group"><label>تاريخ الرحلة</label><input id="fTripDate" class="input" type="date" value="${todayIso()}" /></div>
              <div class="form-group"><label>تاريخ العودة</label><input id="fReturnDate" class="input" type="date" /></div>
            </div>
            <div class="grid-2">
              <div class="form-group">
                <label>نوع الرحلة</label>
                <select id="fTripType">
                  <option value="EIGHT_DAYS">8 أيام</option>
                  <option value="FOURTEEN_DAYS">14 يومًا</option>
                  <option value="CUSTOM">برنامج مخصص</option>
                </select>
              </div>
              <div class="form-group">
                <label>حالة الحجز</label>
                <select id="fStatus">
                  <option value="PENDING">قيد الانتظار</option>
                  <option value="CONFIRMED">مؤكد</option>
                  <option value="COMPLETED">مكتمل</option>
                  <option value="CANCELLED">ملغي</option>
                </select>
              </div>
            </div>
            <div id="customTripGroup" class="form-group" style="display:none">
              <label>تفاصيل البرنامج المخصص</label>
              <input id="fCustomTrip" class="input" placeholder="مثال: 10 أيام طيران مباشر" />
            </div>
            <div class="form-group"><label>اسم شركة السياحة</label><input id="fCompany" class="input" /></div>
            <div class="grid-2">
              <div class="form-group"><label>اسم الفندق في مكة</label><input id="fMakkah" class="input" /></div>
              <div class="form-group"><label>اسم الفندق في المدينة</label><input id="fMadinah" class="input" /></div>
            </div>
          </div>

          <div class="card">
            <h3 class="section-title" style="margin-top:0">3. البيانات المالية والحسابات</h3>
            <div class="grid-2">
              <div class="form-group"><label>سعر الرحلة الإجمالي</label><input id="fTotalPrice" class="input" type="number" step="any" value="0" /></div>
              <div class="form-group"><label>مبلغ المقدم</label><input id="fDeposit" class="input" type="number" step="any" value="0" /></div>
              <div class="form-group"><label>المبالغ الإضافية</label><input id="fExtra" class="input" type="number" step="any" value="0" /></div>
              <div class="form-group"><label>التكلفة الفعلية (اختياري)</label><input id="fCost" class="input" type="number" step="any" value="0" /></div>
            </div>
            <div class="summary-box" style="margin-bottom:10px">
              <div><small>إجمالي المدفوع (المقدم)</small><div id="calcPaid" style="font-size:18px;font-weight:800;color:var(--confirmed-fg)">0</div></div>
              <div><small>المبلغ المتبقي (تلقائي)</small><div id="calcRemaining" style="font-size:18px;font-weight:800;color:var(--navy)">0</div></div>
            </div>
            <div class="form-group"><label>ملاحظات خاصة بالعميل والحجز</label><textarea id="fNotes" rows="3"></textarea></div>
          </div>

          <div class="card">
            <div class="row-between" style="margin-bottom:10px">
              <h3 class="section-title" style="margin:0">4. إرفاق الصور والمستندات (Blob)</h3>
              <button type="button" id="addAttachmentBtn" class="btn btn-outline btn-sm">+ إرفاق صورة</button>
            </div>
            <div id="pendingAttachmentsList">
              ${renderPendingAttachmentsHtml()}
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-block">حفظ الحجز والبيانات في قاعدة البيانات</button>
        </form>
      </div>`;
  }

  function renderPendingAttachmentsHtml() {
    if (!state.pendingAttachments.length) {
      return `<p style="font-size:13px;color:var(--text-secondary);margin:0">يمكنك إرفاق صور جواز السفر، البطاقة الشخصية، التأشيرة، تذكرة الطيران، أو إيصالات الدفع من الكاميرا أو المعرض.</p>`;
    }
    return state.pendingAttachments.map((att, idx) => `
      <div class="doc-item">
        <img src="${blobUrl(att.blob)}" class="doc-thumb" alt="مستند" />
        <div style="flex:1">
          <strong>${esc(Db.DOCUMENT_TYPES[att.docType] || att.docType)}</strong>
          ${att.title ? `<div style="font-size:12px;color:var(--text-secondary)">${esc(att.title)}</div>` : ''}
        </div>
        <button type="button" class="btn btn-outline-danger btn-sm" data-remove-pending="${idx}">حذف</button>
      </div>`).join('');
  }

  function renderClientsList() {
    const q = state.clientsQuery.trim().toLowerCase();
    const list = state.clients.filter((item) => {
      const mQ = !q ||
        item.client.clientCode.toLowerCase().includes(q) ||
        item.client.fullName.toLowerCase().includes(q) ||
        (item.client.phone || '').toLowerCase().includes(q) ||
        (item.client.passportNumber || '').toLowerCase().includes(q);
      const mS = !state.clientsStatusFilter || item.bookings.some((b) => b.status === state.clientsStatusFilter);
      const mU = !state.clientsOnlyUnpaid || item.totalRemainingAcrossBookings > 0.01;
      return mQ && mS && mU;
    });

    return `
      ${renderTopBar('قائمة العملاء', `${list.length} عميل من أصل ${state.clients.length}`, true, `<button id="clientsAddBtn" class="btn btn-gold btn-sm">+ حجز</button>`)}
      <div class="container">
        <div class="form-group">
          <input id="clientsQuickSearch" class="input" placeholder="بحث سريع بالكود أو الاسم أو الهاتف أو الجواز..." value="${esc(state.clientsQuery)}" />
        </div>
        <div class="chips-row" style="margin-bottom:10px">
          <button class="chip ${!state.clientsStatusFilter && !state.clientsOnlyUnpaid ? 'active' : ''}" data-cfilter="ALL">الكل</button>
          ${Object.entries(Db.BOOKING_STATUS).map(([k, label]) => `
            <button class="chip ${state.clientsStatusFilter === k ? 'active' : ''}" data-cfilter="${k}">${esc(label)}</button>
          `).join('')}
          <button class="chip ${state.clientsOnlyUnpaid ? 'active' : ''}" data-cfilter="UNPAID">عليهم متبقي</button>
        </div>
        ${list.length === 0 ? `<div class="card" style="text-align:center">لا توجد نتائج مطابقة</div>` : list.map(renderClientSummaryCard).join('')}
      </div>`;
  }

  function filterSearchResults() {
    const f = state.searchFilter;
    return state.clients.filter((item) => {
      const c = item.client;
      if (f.clientCode && !c.clientCode.toLowerCase().includes(f.clientCode.trim().toLowerCase())) return false;
      if (f.fullName && !c.fullName.toLowerCase().includes(f.fullName.trim().toLowerCase())) return false;
      if (f.phone) {
        const pq = f.phone.trim().toLowerCase();
        if (!(c.phone || '').toLowerCase().includes(pq) && !(c.whatsapp || '').toLowerCase().includes(pq)) return false;
      }
      if (f.passportNumber && !(c.passportNumber || '').toLowerCase().includes(f.passportNumber.trim().toLowerCase())) return false;

      const needsBooking = f.exactTripDate || f.companyName || f.status || f.tripDateFrom || f.tripDateTo;
      if (!needsBooking) return true;

      return item.bookings.some((b) => {
        if (f.exactTripDate && b.tripDate !== f.exactTripDate) return false;
        if (f.companyName && !(b.companyName || '').toLowerCase().includes(f.companyName.trim().toLowerCase())) return false;
        if (f.status && b.status !== f.status) return false;
        if (f.tripDateFrom && (!b.tripDate || b.tripDate < f.tripDateFrom)) return false;
        if (f.tripDateTo && (!b.tripDate || b.tripDate > f.tripDateTo)) return false;
        return true;
      });
    });
  }

  function renderSearch() {
    const f = state.searchFilter;
    const results = filterSearchResults();
    return `
      ${renderTopBar('البحث المتقدم', `${results.length} نتيجة مطابقة`, true, `<button id="clearSearchBtn" class="btn btn-gold btn-sm">مسح</button>`)}
      <div class="container">
        <div class="card">
          <div class="grid-2">
            <div class="form-group"><label>كود العميل</label><input data-sf="clientCode" class="input" value="${esc(f.clientCode)}" /></div>
            <div class="form-group"><label>اسم العميل</label><input data-sf="fullName" class="input" value="${esc(f.fullName)}" /></div>
            <div class="form-group"><label>رقم الهاتف</label><input data-sf="phone" class="input" value="${esc(f.phone)}" /></div>
            <div class="form-group"><label>رقم جواز السفر</label><input data-sf="passportNumber" class="input" value="${esc(f.passportNumber)}" /></div>
            <div class="form-group"><label>شركة السياحة</label><input data-sf="companyName" class="input" value="${esc(f.companyName)}" /></div>
            <div class="form-group"><label>تاريخ رحلة محدد</label><input data-sf="exactTripDate" type="date" class="input" value="${esc(f.exactTripDate)}" /></div>
            <div class="form-group"><label>من تاريخ</label><input data-sf="tripDateFrom" type="date" class="input" value="${esc(f.tripDateFrom)}" /></div>
            <div class="form-group"><label>إلى تاريخ</label><input data-sf="tripDateTo" type="date" class="input" value="${esc(f.tripDateTo)}" /></div>
          </div>
          <div class="form-group">
            <label>حالة الحجز</label>
            <select data-sf="status">
              <option value="">الكل</option>
              ${Object.entries(Db.BOOKING_STATUS).map(([k, v]) => `<option value="${k}" ${f.status === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}
            </select>
          </div>
        </div>
        <div id="searchResultsBox">
          ${results.length === 0 ? `<div class="card" style="text-align:center">لا توجد نتائج مطابقة</div>` : results.map(renderClientSummaryCard).join('')}
        </div>
      </div>`;
  }

  function renderClientDetail() {
    const item = state.clients.find((c) => c.client.id === state.selectedClientId);
    if (!item) {
      return `${renderTopBar('ملف العميل', '')}<div class="container"><div class="card">العميل غير موجود</div></div>`;
    }
    const c = item.client;
    const b = item.bookings.find((x) => x.id === state.selectedBookingId) || item.bookings[0] || null;
    if (b) state.selectedBookingId = b.id;

    return `
      ${renderTopBar(c.fullName, `كود العميل: ${c.clientCode}`, true, `
        <div style="display:flex;gap:6px">
          <button id="printClientBtn" class="btn btn-gold btn-sm">طباعة</button>
          <button id="shareClientBtn" class="btn btn-gold btn-sm">مشاركة</button>
        </div>
      `)}
      <div class="container">
        <div class="card">
          <div class="row-between" style="margin-bottom:8px">
            <h3 class="section-title" style="margin:0">البيانات الشخصية</h3>
            <button id="editClientBtn" class="btn btn-outline btn-sm">تعديل البيانات</button>
          </div>
          <div class="info-line"><span>كود العميل</span><strong>${esc(c.clientCode)}</strong></div>
          <div class="info-line"><span>الاسم الكامل</span><strong>${esc(c.fullName)}</strong></div>
          <div class="info-line"><span>رقم الهاتف</span><strong>${esc(c.phone || '-')}</strong></div>
          <div class="info-line"><span>رقم الواتساب</span><strong>${esc(c.whatsapp || '-')}</strong></div>
          <div class="info-line"><span>رقم البطاقة</span><strong>${esc(c.nationalId || '-')}</strong></div>
          <div class="info-line"><span>رقم الجواز</span><strong>${esc(c.passportNumber || '-')}</strong></div>
          <div class="info-line"><span>تاريخ الميلاد</span><strong>${esc(c.birthDate || '-')}</strong></div>
          ${c.notes ? `<div class="info-line"><span>ملاحظات</span><strong>${esc(c.notes)}</strong></div>` : ''}
        </div>

        <div class="row-between" style="margin-bottom:10px">
          <div class="chips-row">
            ${item.bookings.map((bk, i) => `
              <button class="chip ${b && bk.id === b.id ? 'active' : ''}" data-select-booking="${bk.id}">حجز ${i + 1}: ${esc(bk.tripDate)}</button>
            `).join('')}
          </div>
          <button id="addExtraBookingBtn" class="btn btn-outline btn-sm">+ حجز إضافي</button>
        </div>

        ${b ? `
          <div class="card">
            <div class="row-between" style="margin-bottom:8px">
              <h3 class="section-title" style="margin:0">تفاصيل الرحلة</h3>
              <span class="badge badge-${b.status}">${esc(Db.BOOKING_STATUS[b.status] || b.status)}</span>
            </div>
            <div class="info-line"><span>تاريخ الرحلة</span><strong>${esc(b.tripDate)}</strong></div>
            <div class="info-line"><span>تاريخ العودة</span><strong>${esc(b.returnDate || '-')}</strong></div>
            <div class="info-line"><span>نوع البرنامج</span><strong>${esc(Db.TRIP_TYPES[b.tripType] || b.tripType)} ${b.customTripLabel ? `(${esc(b.customTripLabel)})` : ''}</strong></div>
            <div class="info-line"><span>شركة السياحة</span><strong>${esc(b.companyName || '-')}</strong></div>
            <div class="info-line"><span>فندق مكة</span><strong>${esc(b.makkahHotel || '-')}</strong></div>
            <div class="info-line"><span>فندق المدينة</span><strong>${esc(b.madinahHotel || '-')}</strong></div>
            ${b.notes ? `<div class="info-line"><span>ملاحظات الحجز</span><strong>${esc(b.notes)}</strong></div>` : ''}
            <div class="grid-2" style="margin-top:10px">
              <button id="editBookingBtn" class="btn btn-outline btn-sm">تعديل الرحلة</button>
              <button id="deleteBookingBtn" class="btn btn-outline-danger btn-sm">حذف الحجز</button>
            </div>
          </div>

          <div class="card card-gold">
            <h3 class="section-title" style="margin-top:0">الحسابات والملخص المالي</h3>
            <div class="grid-2">
              <div class="kpi-card"><div class="kpi-value">${money(b.totalPrice)}</div><div class="kpi-label">سعر الرحلة</div></div>
              <div class="kpi-card"><div class="kpi-value">${money(b.extraAmount)}</div><div class="kpi-label">المبالغ الإضافية</div></div>
              <div class="kpi-card"><div class="kpi-value" style="color:var(--confirmed-fg)">${money(b.totalPaid)}</div><div class="kpi-label">إجمالي المدفوع</div></div>
              <div class="kpi-card" style="background:var(--gold-soft)"><div class="kpi-value" style="color:${b.remainingAmount > 0 ? 'var(--pending-fg)' : 'var(--confirmed-fg)'}">${money(b.remainingAmount)}</div><div class="kpi-label">المبلغ المتبقي</div></div>
            </div>
          </div>

          <div class="card">
            <div class="row-between" style="margin-bottom:10px">
              <h3 class="section-title" style="margin:0">سجل المدفوعات (${b.payments.length})</h3>
              <button id="addPaymentBtn" class="btn btn-primary btn-sm">+ إضافة دفعة</button>
            </div>
            ${b.payments.length === 0 ? `<p style="font-size:13px;color:var(--text-secondary)">لا توجد دفعات مسجلة.</p>` : b.payments.map((p) => `
              <div class="doc-item" style="justify-content:space-between">
                <div>
                  <strong style="color:var(--navy)">${money(p.amount)} • ${esc(Db.PAYMENT_METHODS[p.paymentMethod] || p.paymentMethod)} ${p.isDeposit ? '(مقدم)' : ''}</strong>
                  <div style="font-size:12px;color:var(--text-secondary)">${esc(p.paymentDate)} ${p.notes ? `• ${esc(p.notes)}` : ''}</div>
                </div>
                <div style="display:flex;gap:6px">
                  <button class="btn btn-outline btn-sm" data-edit-payment="${p.id}">تعديل</button>
                  <button class="btn btn-outline-danger btn-sm" data-del-payment="${p.id}">حذف</button>
                </div>
              </div>
            `).join('')}
          </div>

          <div class="card">
            <div class="row-between" style="margin-bottom:10px">
              <h3 class="section-title" style="margin:0">المستندات والصور (${b.documents.length})</h3>
              <button id="addDocDetailBtn" class="btn btn-gold btn-sm">+ إرفاق مستند</button>
            </div>
            ${b.documents.length === 0 ? `<p style="font-size:13px;color:var(--text-secondary)">لم يتم إرفاق مستندات بعد.</p>` : b.documents.map((doc) => {
              const url = blobUrl(doc.blob);
              return `
                <div class="doc-item">
                  <img src="${url}" class="doc-thumb" data-zoom-doc="${doc.id}" alt="${esc(Db.DOCUMENT_TYPES[doc.docType] || '')}" />
                  <div style="flex:1">
                    <strong style="color:var(--navy)">${esc(Db.DOCUMENT_TYPES[doc.docType] || doc.docType)}</strong>
                    ${doc.title ? `<div style="font-size:12px;color:var(--text-secondary)">${esc(doc.title)}</div>` : ''}
                    <div style="font-size:11px;color:var(--text-secondary)">مرتبط بالكود: ${esc(doc.clientCode)} • محفوظ بصيغة Blob</div>
                  </div>
                  <div style="display:flex;flex-direction:column;gap:4px">
                    <button class="btn btn-outline btn-sm" data-replace-doc="${doc.id}">استبدال</button>
                    <button class="btn btn-outline-danger btn-sm" data-del-doc="${doc.id}">حذف</button>
                  </div>
                </div>`;
            }).join('')}
          </div>
        ` : ''}
      </div>`;
  }

  function buildReportPreview(reportId, fromDate, toDate) {
    const reportMeta = REPORTS.find((r) => r.id === reportId) || REPORTS[1];
    const inRange = (d) => (!fromDate || (d && d >= fromDate)) && (!toDate || (d && d <= toDate));
    const pairs = state.clients.flatMap((c) => c.bookings.map((b) => ({ client: c.client, booking: b })))
      .filter((x) => inRange(x.booking.tripDate));
    const today = todayIso();

    switch (reportId) {
      case 1: {
        const list = (fromDate || toDate) ? state.clients.filter((c) => c.bookings.some((b) => inRange(b.tripDate))) : state.clients;
        return {
          ...reportMeta,
          headers: ['الكود', 'اسم العميل', 'الهاتف', 'الجواز', 'الحجوزات', 'المدفوع', 'المتبقي'],
          rows: list.map((i) => [i.client.clientCode, i.client.fullName, i.client.phone || '-', i.client.passportNumber || '-', String(i.bookings.length), money(i.totalPaidAcrossBookings), money(i.totalRemainingAcrossBookings)]),
          summaryMetrics: [['عدد العملاء', String(list.length)], ['إجمالي المدفوع', money(list.reduce((s, i) => s + i.totalPaidAcrossBookings, 0))], ['إجمالي المتبقي', money(list.reduce((s, i) => s + i.totalRemainingAcrossBookings, 0))]]
        };
      }
      case 2:
        return {
          ...reportMeta,
          headers: ['الكود', 'العميل', 'تاريخ الرحلة', 'النوع', 'الشركة', 'الحالة', 'الإجمالي', 'المدفوع', 'المتبقي'],
          rows: pairs.map(({ client, booking }) => [client.clientCode, client.fullName, booking.tripDate, Db.TRIP_TYPES[booking.tripType] || booking.tripType, booking.companyName || '-', Db.BOOKING_STATUS[booking.status] || booking.status, money(booking.totalDue), money(booking.totalPaid), money(booking.remainingAmount)]),
          summaryMetrics: [['عدد الحجوزات', String(pairs.length)], ['إجمالي العقود', money(pairs.reduce((s, x) => s + x.booking.totalDue, 0))], ['المحصل', money(pairs.reduce((s, x) => s + x.booking.totalPaid, 0))]]
        };
      case 3: {
        const up = pairs.filter((x) => x.booking.status !== 'CANCELLED' && x.booking.tripDate >= today).sort((a, b) => a.booking.tripDate.localeCompare(b.booking.tripDate));
        return {
          ...reportMeta,
          headers: ['الكود', 'العميل', 'الهاتف', 'السفر', 'العودة', 'فندق مكة', 'الحالة', 'المتبقي'],
          rows: up.map(({ client, booking }) => [client.clientCode, client.fullName, client.phone || '-', booking.tripDate, booking.returnDate || '-', booking.makkahHotel || '-', Db.BOOKING_STATUS[booking.status], money(booking.remainingAmount)]),
          summaryMetrics: [['الرحلات القادمة', String(up.length)], ['المتبقي تحصيله', money(up.reduce((s, x) => s + Math.max(0, x.booking.remainingAmount), 0))]]
        };
      }
      case 4: {
        const sorted = [...pairs].sort((a, b) => (a.booking.tripDate || '').localeCompare(b.booking.tripDate || ''));
        return {
          ...reportMeta,
          headers: ['تاريخ الرحلة', 'العودة', 'الكود', 'العميل', 'البرنامج', 'الشركة', 'الحالة'],
          rows: sorted.map(({ client, booking }) => [booking.tripDate, booking.returnDate || '-', client.clientCode, client.fullName, Db.TRIP_TYPES[booking.tripType], booking.companyName || '-', Db.BOOKING_STATUS[booking.status]]),
          summaryMetrics: [['عدد الحجوزات', String(sorted.length)]]
        };
      }
      case 5: {
        const grouped = new Map();
        for (const p of pairs) {
          const key = p.booking.companyName || 'غير محدد';
          if (!grouped.has(key)) grouped.set(key, []);
          grouped.get(key).push(p);
        }
        const rows = [...grouped.entries()].map(([comp, arr]) => [
          comp,
          String(arr.length),
          String(arr.filter((x) => x.booking.status === 'CONFIRMED').length),
          money(arr.reduce((s, x) => s + x.booking.totalDue, 0)),
          money(arr.reduce((s, x) => s + x.booking.totalPaid, 0)),
          money(arr.reduce((s, x) => s + Math.max(0, x.booking.remainingAmount), 0))
        ]);
        return { ...reportMeta, headers: ['شركة السياحة', 'الحجوزات', 'المؤكدة', 'الإجمالي', 'المحصل', 'المتبقي'], rows, summaryMetrics: [['عدد الشركات', String(grouped.size)]] };
      }
      case 6: {
        const payRows = [];
        for (const c of state.clients) {
          for (const b of c.bookings) {
            for (const p of b.payments) {
              if (inRange(p.paymentDate)) payRows.push({ c: c.client, b, p });
            }
          }
        }
        payRows.sort((a, b) => (b.p.paymentDate || '').localeCompare(a.p.paymentDate || ''));
        return {
          ...reportMeta,
          headers: ['تاريخ الدفعة', 'الكود', 'العميل', 'المبلغ', 'الطريقة', 'النوع', 'ملاحظات'],
          rows: payRows.map(({ c, p }) => [p.paymentDate, c.clientCode, c.fullName, money(p.amount), Db.PAYMENT_METHODS[p.paymentMethod] || p.paymentMethod, p.isDeposit ? 'مقدم' : 'دفعة', p.notes || '-']),
          summaryMetrics: [['عدد الدفعات', String(payRows.length)], ['إجمالي المحصل', money(payRows.reduce((s, x) => s + Number(x.p.amount || 0), 0))]]
        };
      }
      case 7: {
        const act = pairs.filter((x) => x.booking.status !== 'CANCELLED');
        return {
          ...reportMeta,
          headers: ['الكود', 'العميل', 'تاريخ الرحلة', 'المستحق', 'المدفوع', 'المتبقي'],
          rows: act.map(({ client, booking }) => [client.clientCode, client.fullName, booking.tripDate, money(booking.totalDue), money(booking.totalPaid), money(booking.remainingAmount)]),
          summaryMetrics: [['الحجوزات النشطة', String(act.length)], ['إجمالي المتبقي', money(act.reduce((s, x) => s + Math.max(0, x.booking.remainingAmount), 0))]]
        };
      }
      case 8: {
        const unpaid = pairs.filter((x) => x.booking.status !== 'CANCELLED' && x.booking.remainingAmount > 0.01).sort((a, b) => b.booking.remainingAmount - a.booking.remainingAmount);
        return {
          ...reportMeta,
          headers: ['الكود', 'العميل', 'الهاتف', 'الرحلة', 'الإجمالي', 'المدفوع', 'المتبقي'],
          rows: unpaid.map(({ client, booking }) => [client.clientCode, client.fullName, client.phone || '-', booking.tripDate, money(booking.totalDue), money(booking.totalPaid), money(booking.remainingAmount)]),
          summaryMetrics: [['حالات غير مسددة', String(unpaid.length)], ['إجمالي المتبقي', money(unpaid.reduce((s, x) => s + x.booking.remainingAmount, 0))]]
        };
      }
      case 9: {
        const canc = pairs.filter((x) => x.booking.status === 'CANCELLED');
        return {
          ...reportMeta,
          headers: ['الكود', 'العميل', 'الهاتف', 'الرحلة', 'الشركة', 'قيمة الحجز', 'المدفوع', 'ملاحظات'],
          rows: canc.map(({ client, booking }) => [client.clientCode, client.fullName, client.phone || '-', booking.tripDate, booking.companyName || '-', money(booking.totalDue), money(booking.totalPaid), booking.notes || '-']),
          summaryMetrics: [['الحجوزات الملغاة', String(canc.length)]]
        };
      }
      case 10:
      default: {
        const act = pairs.filter((x) => x.booking.status !== 'CANCELLED');
        return {
          ...reportMeta,
          headers: ['الكود', 'العميل', 'الرحلة', 'سعر البيع', 'التكلفة', 'صافي الربح', 'فرق المحصل والتكلفة'],
          rows: act.map(({ client, booking }) => [client.clientCode, client.fullName, booking.tripDate, money(booking.totalDue), money(booking.costAmount), money(booking.profitAmount), money(booking.totalPaid - booking.costAmount)]),
          summaryMetrics: [['إجمالي المبيعات', money(act.reduce((s, x) => s + x.booking.totalDue, 0))], ['إجمالي التكلفة', money(act.reduce((s, x) => s + x.booking.costAmount, 0))], ['صافي الأرباح', money(act.reduce((s, x) => s + x.booking.profitAmount, 0))]]
        };
      }
    }
  }

  function renderReports() {
    const preview = buildReportPreview(state.selectedReportId, state.reportFromDate, state.reportToDate);
    return `
      ${renderTopBar('التقارير المالية والإدارية', '10 تقارير شاملة • Excel و PDF')}
      <div class="container">
        <div class="card">
          <div class="chips-row" style="margin-bottom:8px">
            ${REPORTS.map((r) => `
              <button class="chip ${state.selectedReportId === r.id ? 'active' : ''}" data-report-id="${r.id}">${r.id}. ${esc(r.title)}</button>
            `).join('')}
          </div>
          <small style="color:var(--text-secondary)">${esc(preview.subtitle)}</small>
        </div>

        <div class="card">
          <div class="grid-2">
            <div class="form-group"><label>من تاريخ</label><input id="repFrom" type="date" class="input" value="${esc(state.reportFromDate)}" /></div>
            <div class="form-group"><label>إلى تاريخ</label><input id="repTo" type="date" class="input" value="${esc(state.reportToDate)}" /></div>
          </div>
          <div class="grid-2">
            <button id="exportExcelBtn" class="btn btn-success">تصدير Excel (.xlsx)</button>
            <button id="exportPdfBtn" class="btn btn-primary">تصدير / طباعة PDF</button>
          </div>
        </div>

        <div class="summary-box" style="margin-bottom:12px">
          ${preview.summaryMetrics.map(([k, v]) => `<div><small>${esc(k)}</small><div style="font-weight:800;color:var(--navy)">${esc(v)}</div></div>`).join('')}
        </div>

        <div class="table-wrap">
          <table>
            <thead><tr>${preview.headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead>
            <tbody>
              ${preview.rows.length === 0 ? `<tr><td colspan="${preview.headers.length}" style="text-align:center">لا توجد بيانات مطابقة</td></tr>` : preview.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  function renderBackup() {
    return `
      ${renderTopBar('النسخ الاحتياطي والاستعادة', 'تصدير واستيراد شامل للبيانات والصور (Blobs)')}
      <div class="container">
        <div class="card card-navy">
          <small style="color:var(--gold)">تاريخ آخر نسخة احتياطية</small>
          <h2 style="margin:6px 0;color:var(--white)">${esc(formatTimestamp(state.lastBackupTimestamp))}</h2>
          ${state.lastBackupName ? `<div style="font-size:12px;opacity:0.85">${esc(state.lastBackupName)}</div>` : ''}
          <p style="font-size:12px;opacity:0.85;margin-bottom:0">تشمل النسخة الاحتياطية جميع العملاء والحجوزات والمدفوعات وكافة الصور والمستندات المحفوظة في IndexedDB.</p>
        </div>

        <button id="createBackupBtn" class="btn btn-primary btn-block" style="margin-bottom:10px">تصدير نسخة احتياطية شاملة الآن</button>
        ${state.lastBackupBlob && state.lastBackupName ? `<button id="shareBackupBtn" class="btn btn-gold btn-block" style="margin-bottom:10px">مشاركة النسخة الاحتياطية</button>` : ''}

        <div class="card">
          <h3 class="section-title" style="margin-top:0">استيراد نسخة احتياطية من ملف</h3>
          <p style="font-size:13px;color:var(--text-secondary)">عند استعادة النسخة الاحتياطية على هاتف جديد أو نفس الهاتف، يتحقق النظام من كود العميل لمنع تكرار أي عميل مسجل مسبقًا.</p>
          <input id="restoreFileInput" type="file" accept=".json,.sdbackup,.sdbackup.json,application/json" style="display:none" />
          <button id="restoreBackupBtn" class="btn btn-outline btn-block">اختيار ملف النسخة الاحتياطية واستعادته</button>
        </div>
      </div>`;
  }

  function render() {
    revokeObjectUrls();
    const root = document.getElementById('appRoot');
    switch (state.route) {
      case 'add_booking': root.innerHTML = renderAddBooking(); break;
      case 'clients': root.innerHTML = renderClientsList(); break;
      case 'search': root.innerHTML = renderSearch(); break;
      case 'client_detail': root.innerHTML = renderClientDetail(); break;
      case 'reports': root.innerHTML = renderReports(); break;
      case 'backup': root.innerHTML = renderBackup(); break;
      default: root.innerHTML = renderDashboard(); break;
    }
    bindEvents();
  }

  function openAttachModal(onBlobPicked, showTypeSelector = true) {
    const modal = document.getElementById('modalRoot');
    modal.innerHTML = `
      <div class="modal-backdrop">
        <div class="modal-card">
          <h3 style="margin-top:0;color:var(--navy)">${showTypeSelector ? 'إرفاق مستند أو صورة' : 'استبدال الصورة'}</h3>
          ${showTypeSelector ? `
            <div class="form-group">
              <label>نوع المستند</label>
              <select id="mDocType">
                ${Object.entries(Db.DOCUMENT_TYPES).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group"><label>وصف مختصر (اختياري)</label><input id="mDocTitle" class="input" /></div>
          ` : ''}
          <input id="mGalleryInput" type="file" accept="image/*" style="display:none" />
          <input id="mCameraInput" type="file" accept="image/*" capture="environment" style="display:none" />
          <div class="grid-2" style="margin-top:12px">
            <button id="mPickGallery" class="btn btn-primary">من المعرض</button>
            <button id="mPickCamera" class="btn btn-gold">تصوير بالكاميرا</button>
          </div>
          <button id="mCloseModal" class="btn btn-outline btn-block" style="margin-top:10px">إلغاء</button>
        </div>
      </div>`;

    const handleFile = (file) => {
      if (!file) return;
      const docType = showTypeSelector ? document.getElementById('mDocType').value : 'OTHER';
      const title = showTypeSelector ? document.getElementById('mDocTitle').value.trim() : '';
      modal.innerHTML = '';
      onBlobPicked({ docType, title, blob: file, fileName: file.name });
    };

    document.getElementById('mPickGallery').onclick = () => document.getElementById('mGalleryInput').click();
    document.getElementById('mPickCamera').onclick = () => document.getElementById('mCameraInput').click();
    document.getElementById('mGalleryInput').onchange = (e) => handleFile(e.target.files[0]);
    document.getElementById('mCameraInput').onchange = (e) => handleFile(e.target.files[0]);
    document.getElementById('mCloseModal').onclick = () => { modal.innerHTML = ''; };
  }

  function openZoomModal(doc) {
    let scale = 1;
    const modal = document.getElementById('modalRoot');
    const url = blobUrl(doc.blob);
    modal.innerHTML = `
      <div class="zoom-backdrop">
        <div class="row-between" style="width:100%;max-width:720px;margin-bottom:12px;color:#fff">
          <strong>${esc(Db.DOCUMENT_TYPES[doc.docType] || '')} (${esc(doc.clientCode)})</strong>
          <div style="display:flex;gap:8px">
            <button id="zIn" class="btn btn-gold btn-sm">تكبير +</button>
            <button id="zOut" class="btn btn-outline btn-sm">تصغير -</button>
            <button id="zClose" class="btn btn-danger btn-sm">إغلاق</button>
          </div>
        </div>
        <img id="zoomImg" src="${url}" alt="تكبير المستند" />
      </div>`;
    const img = document.getElementById('zoomImg');
    document.getElementById('zIn').onclick = () => { scale = Math.min(4, scale + 0.5); img.style.transform = `scale(${scale})`; };
    document.getElementById('zOut').onclick = () => { scale = Math.max(1, scale - 0.5); img.style.transform = `scale(${scale})`; };
    document.getElementById('zClose').onclick = () => { modal.innerHTML = ''; };
  }

  function openEditClientModal(client) {
    const modal = document.getElementById('modalRoot');
    modal.innerHTML = `
      <div class="modal-backdrop">
        <div class="modal-card">
          <h3 style="margin-top:0;color:var(--navy)">تعديل بيانات العميل</h3>
          <div id="editClientErr" class="alert-error" style="display:none"></div>
          <div class="form-group"><label>كود العميل</label><input id="ecCode" class="input" value="${esc(client.clientCode)}" /></div>
          <div class="form-group"><label>اسم العميل بالكامل</label><input id="ecName" class="input" value="${esc(client.fullName)}" /></div>
          <div class="form-group"><label>رقم الهاتف</label><input id="ecPhone" class="input" value="${esc(client.phone)}" /></div>
          <div class="form-group"><label>رقم الواتساب</label><input id="ecWa" class="input" value="${esc(client.whatsapp)}" /></div>
          <div class="form-group"><label>رقم البطاقة</label><input id="ecNid" class="input" value="${esc(client.nationalId)}" /></div>
          <div class="form-group"><label>رقم الجواز</label><input id="ecPass" class="input" value="${esc(client.passportNumber)}" /></div>
          <div class="form-group"><label>تاريخ الميلاد</label><input id="ecDob" type="date" class="input" value="${esc(client.birthDate)}" /></div>
          <div class="form-group"><label>ملاحظات</label><textarea id="ecNotes" rows="2">${esc(client.notes || '')}</textarea></div>
          <div class="grid-2">
            <button id="ecSave" class="btn btn-primary">حفظ التعديلات</button>
            <button id="ecCancel" class="btn btn-outline">إلغاء</button>
          </div>
        </div>
      </div>`;
    document.getElementById('ecCancel').onclick = () => { modal.innerHTML = ''; };
    document.getElementById('ecSave').onclick = async () => {
      try {
        await Db.updateClient({
          ...client,
          clientCode: document.getElementById('ecCode').value,
          fullName: document.getElementById('ecName').value,
          phone: document.getElementById('ecPhone').value,
          whatsapp: document.getElementById('ecWa').value,
          nationalId: document.getElementById('ecNid').value,
          passportNumber: document.getElementById('ecPass').value,
          birthDate: document.getElementById('ecDob').value,
          notes: document.getElementById('ecNotes').value
        });
        modal.innerHTML = '';
        await refreshData();
        showToast('تم تحديث بيانات العميل بنجاح');
        render();
      } catch (err) {
        const errEl = document.getElementById('editClientErr');
        errEl.textContent = err.message;
        errEl.style.display = 'block';
      }
    };
  }

  function openEditBookingModal(booking) {
    const modal = document.getElementById('modalRoot');
    modal.innerHTML = `
      <div class="modal-backdrop">
        <div class="modal-card">
          <h3 style="margin-top:0;color:var(--navy)">تعديل بيانات الرحلة</h3>
          <div class="form-group"><label>تاريخ الرحلة</label><input id="ebDate" type="date" class="input" value="${esc(booking.tripDate)}" /></div>
          <div class="form-group"><label>تاريخ العودة</label><input id="ebReturn" type="date" class="input" value="${esc(booking.returnDate)}" /></div>
          <div class="form-group">
            <label>نوع البرنامج</label>
            <select id="ebType">
              ${Object.entries(Db.TRIP_TYPES).map(([k, v]) => `<option value="${k}" ${booking.tripType === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group"><label>تفاصيل البرنامج المخصص (إن وجد)</label><input id="ebCustomTrip" class="input" value="${esc(booking.customTripLabel || '')}" /></div>
          <div class="form-group"><label>شركة السياحة</label><input id="ebComp" class="input" value="${esc(booking.companyName)}" /></div>
          <div class="form-group"><label>فندق مكة</label><input id="ebMakkah" class="input" value="${esc(booking.makkahHotel)}" /></div>
          <div class="form-group"><label>فندق المدينة</label><input id="ebMadinah" class="input" value="${esc(booking.madinahHotel)}" /></div>
          <div class="grid-2">
            <div class="form-group"><label>سعر الرحلة</label><input id="ebPrice" type="number" step="any" class="input" value="${booking.totalPrice}" /></div>
            <div class="form-group"><label>الإضافات</label><input id="ebExtra" type="number" step="any" class="input" value="${booking.extraAmount}" /></div>
          </div>
          <div class="form-group"><label>التكلفة الفعلية</label><input id="ebCost" type="number" step="any" class="input" value="${booking.costAmount || 0}" /></div>
          <div class="form-group">
            <label>حالة الحجز</label>
            <select id="ebStatus">
              ${Object.entries(Db.BOOKING_STATUS).map(([k, v]) => `<option value="${k}" ${booking.status === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group"><label>ملاحظات</label><textarea id="ebNotes" rows="2">${esc(booking.notes || '')}</textarea></div>
          <div class="grid-2">
            <button id="ebSave" class="btn btn-primary">حفظ</button>
            <button id="ebCancel" class="btn btn-outline">إلغاء</button>
          </div>
        </div>
      </div>`;
    document.getElementById('ebCancel').onclick = () => { modal.innerHTML = ''; };
    document.getElementById('ebSave').onclick = async () => {
      await Db.updateBooking({
        ...booking,
        tripDate: document.getElementById('ebDate').value,
        returnDate: document.getElementById('ebReturn').value,
        tripType: document.getElementById('ebType').value,
        customTripLabel: document.getElementById('ebType').value === 'CUSTOM' ? document.getElementById('ebCustomTrip').value.trim() : '',
        companyName: document.getElementById('ebComp').value,
        makkahHotel: document.getElementById('ebMakkah').value,
        madinahHotel: document.getElementById('ebMadinah').value,
        totalPrice: document.getElementById('ebPrice').value,
        extraAmount: document.getElementById('ebExtra').value,
        costAmount: document.getElementById('ebCost').value,
        status: document.getElementById('ebStatus').value,
        notes: document.getElementById('ebNotes').value
      });
      modal.innerHTML = '';
      await refreshData();
      showToast('تم تحديث بيانات الرحلة');
      render();
    };
  }

  function openPaymentModal(booking, existingPayment = null) {
    const modal = document.getElementById('modalRoot');
    modal.innerHTML = `
      <div class="modal-backdrop">
        <div class="modal-card">
          <h3 style="margin-top:0;color:var(--navy)">${existingPayment ? 'تعديل الدفعة' : 'إضافة دفعة جديدة'}</h3>
          <div id="payErr" class="alert-error" style="display:none"></div>
          <div class="form-group"><label>قيمة الدفعة *</label><input id="pAmount" type="number" step="any" class="input" value="${existingPayment ? existingPayment.amount : ''}" /></div>
          <div class="form-group"><label>تاريخ الدفعة</label><input id="pDate" type="date" class="input" value="${existingPayment ? existingPayment.paymentDate : todayIso()}" /></div>
          <div class="form-group">
            <label>طريقة الدفع</label>
            <select id="pMethod">
              ${Object.entries(Db.PAYMENT_METHODS).map(([k, v]) => `<option value="${k}" ${existingPayment && existingPayment.paymentMethod === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group"><label>ملاحظات</label><input id="pNotes" class="input" value="${existingPayment ? esc(existingPayment.notes) : ''}" /></div>
          <div class="grid-2">
            <button id="pSave" class="btn btn-primary">حفظ الدفعة</button>
            <button id="pCancel" class="btn btn-outline">إلغاء</button>
          </div>
        </div>
      </div>`;
    document.getElementById('pCancel').onclick = () => { modal.innerHTML = ''; };
    document.getElementById('pSave').onclick = async () => {
      const amt = Number(document.getElementById('pAmount').value);
      if (!amt || amt <= 0) {
        const e = document.getElementById('payErr');
        e.textContent = 'يرجى إدخال مبلغ صحيح أكبر من صفر';
        e.style.display = 'block';
        return;
      }
      await Db.savePayment({
        ...(existingPayment || {}),
        bookingId: booking.id,
        clientCode: booking.clientCode,
        amount: amt,
        paymentDate: document.getElementById('pDate').value || todayIso(),
        paymentMethod: document.getElementById('pMethod').value,
        isDeposit: existingPayment ? existingPayment.isDeposit : false,
        notes: document.getElementById('pNotes').value.trim()
      });
      modal.innerHTML = '';
      await refreshData();
      showToast('تم حفظ الدفعة وتحديث الحساب تلقائيًا');
      render();
    };
  }

  function bindEvents() {
    const backBtn = document.getElementById('backBtn');
    if (backBtn) backBtn.onclick = () => navigate('dashboard');

    const installBtn = document.getElementById('installAppBtn');
    if (installBtn && state.deferredInstallPrompt) {
      installBtn.onclick = async () => {
        state.deferredInstallPrompt.prompt();
        const choice = await state.deferredInstallPrompt.userChoice;
        if (choice.outcome === 'accepted') {
          state.deferredInstallPrompt = null;
          showToast('تم بدء تثبيت تطبيق SD TRAVEL على الشاشة الرئيسية');
        }
        render();
      };
    }

    document.querySelectorAll('[data-open-client]').forEach((el) => {
      el.onclick = () => navigate('client_detail', { clientId: Number(el.dataset.openClient), bookingId: null });
    });

    if (state.route === 'dashboard') {
      document.getElementById('goAddBooking').onclick = () => navigate('add_booking');
      document.getElementById('goClients').onclick = () => navigate('clients');
      document.getElementById('goSearch').onclick = () => navigate('search');
      document.getElementById('goReports').onclick = () => navigate('reports');
      document.getElementById('goBackup').onclick = () => navigate('backup');
    }

    if (state.route === 'add_booking') {
      const codeInput = document.getElementById('fClientCode');
      const warn = document.getElementById('codeDupWarn');
      if (!state.addForExistingClientId) {
        codeInput.oninput = async () => {
          const val = codeInput.value.trim();
          if (!val) { warn.style.display = 'none'; return; }
          const ok = await Db.isClientCodeAvailable(val);
          if (!ok) {
            warn.textContent = `كود العميل (${val}) مسجل مسبقًا، يمنع التكرار`;
            warn.style.display = 'block';
            codeInput.classList.add('input-error');
          } else {
            warn.style.display = 'none';
            codeInput.classList.remove('input-error');
          }
        };
      }

      const tripTypeSel = document.getElementById('fTripType');
      tripTypeSel.onchange = () => {
        document.getElementById('customTripGroup').style.display = tripTypeSel.value === 'CUSTOM' ? 'block' : 'none';
      };

      const updateCalc = () => {
        const p = Number(document.getElementById('fTotalPrice').value || 0);
        const d = Number(document.getElementById('fDeposit').value || 0);
        const e = Number(document.getElementById('fExtra').value || 0);
        document.getElementById('calcPaid').textContent = money(d);
        document.getElementById('calcRemaining').textContent = money((p + e) - d);
      };
      ['fTotalPrice', 'fDeposit', 'fExtra'].forEach((id) => {
        document.getElementById(id).oninput = updateCalc;
      });

      document.getElementById('addAttachmentBtn').onclick = () => {
        openAttachModal((att) => {
          state.pendingAttachments.push(att);
          document.getElementById('pendingAttachmentsList').innerHTML = renderPendingAttachmentsHtml();
          bindPendingRemove();
        }, true);
      };

      function bindPendingRemove() {
        document.querySelectorAll('[data-remove-pending]').forEach((btn) => {
          btn.onclick = () => {
            state.pendingAttachments.splice(Number(btn.dataset.removePending), 1);
            document.getElementById('pendingAttachmentsList').innerHTML = renderPendingAttachmentsHtml();
            bindPendingRemove();
          };
        });
      }
      bindPendingRemove();

      document.getElementById('addBookingForm').onsubmit = async (ev) => {
        ev.preventDefault();
        const errBox = document.getElementById('addFormError');
        errBox.style.display = 'none';
        try {
          const booking = {
            tripDate: document.getElementById('fTripDate').value,
            returnDate: document.getElementById('fReturnDate').value,
            tripType: document.getElementById('fTripType').value,
            customTripLabel: document.getElementById('fCustomTrip').value.trim(),
            companyName: document.getElementById('fCompany').value.trim(),
            makkahHotel: document.getElementById('fMakkah').value.trim(),
            madinahHotel: document.getElementById('fMadinah').value.trim(),
            totalPrice: document.getElementById('fTotalPrice').value,
            extraAmount: document.getElementById('fExtra').value,
            costAmount: document.getElementById('fCost').value,
            status: document.getElementById('fStatus').value,
            notes: document.getElementById('fNotes').value.trim()
          };
          const depositAmount = Number(document.getElementById('fDeposit').value || 0);

          let savedClientId;
          if (state.addForExistingClientId) {
            const existing = state.clients.find((c) => c.client.id === state.addForExistingClientId).client;
            await Db.addBookingToClient({
              clientId: existing.id,
              clientCode: existing.clientCode,
              booking,
              depositAmount,
              attachments: state.pendingAttachments
            });
            savedClientId = existing.id;
          } else {
            const res = await Db.createClientAndBooking({
              client: {
                clientCode: document.getElementById('fClientCode').value,
                fullName: document.getElementById('fFullName').value,
                phone: document.getElementById('fPhone').value.trim(),
                whatsapp: document.getElementById('fWhatsapp').value.trim(),
                nationalId: document.getElementById('fNationalId').value.trim(),
                passportNumber: document.getElementById('fPassport').value.trim(),
                birthDate: document.getElementById('fBirthDate').value,
                notes: document.getElementById('fNotes').value.trim()
              },
              booking,
              depositAmount,
              attachments: state.pendingAttachments
            });
            savedClientId = res.clientId;
          }

          state.pendingAttachments = [];
          await refreshData();
          showToast('تم حفظ العميل والحجز بنجاح');
          navigate('client_detail', { clientId: savedClientId, bookingId: null });
        } catch (err) {
          errBox.textContent = err.message;
          errBox.style.display = 'block';
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      };
    }

    if (state.route === 'clients') {
      document.getElementById('clientsAddBtn').onclick = () => navigate('add_booking');
      document.getElementById('clientsQuickSearch').oninput = (e) => {
        state.clientsQuery = e.target.value;
        render();
        const inp = document.getElementById('clientsQuickSearch');
        inp.focus();
        inp.setSelectionRange(inp.value.length, inp.value.length);
      };
      document.querySelectorAll('[data-cfilter]').forEach((btn) => {
        btn.onclick = () => {
          const val = btn.dataset.cfilter;
          if (val === 'ALL') { state.clientsStatusFilter = null; state.clientsOnlyUnpaid = false; }
          else if (val === 'UNPAID') { state.clientsOnlyUnpaid = !state.clientsOnlyUnpaid; }
          else { state.clientsStatusFilter = state.clientsStatusFilter === val ? null : val; }
          render();
        };
      });
    }

    if (state.route === 'search') {
      document.getElementById('clearSearchBtn').onclick = () => {
        Object.keys(state.searchFilter).forEach((k) => { state.searchFilter[k] = ''; });
        render();
      };
      document.querySelectorAll('[data-sf]').forEach((el) => {
        const evt = el.tagName === 'SELECT' || el.type === 'date' ? 'change' : 'input';
        el[evt === 'change' ? 'onchange' : 'oninput'] = (e) => {
          state.searchFilter[el.dataset.sf] = e.target.value;
          const results = filterSearchResults();
          document.getElementById('searchResultsBox').innerHTML = results.length === 0
            ? `<div class="card" style="text-align:center">لا توجد نتائج مطابقة</div>`
            : results.map(renderClientSummaryCard).join('');
          document.querySelectorAll('[data-open-client]').forEach((card) => {
            card.onclick = () => navigate('client_detail', { clientId: Number(card.dataset.openClient), bookingId: null });
          });
        };
      });
    }

    if (state.route === 'client_detail') {
      const item = state.clients.find((c) => c.client.id === state.selectedClientId);
      if (!item) return;
      const b = item.bookings.find((x) => x.id === state.selectedBookingId) || item.bookings[0] || null;

      document.getElementById('editClientBtn').onclick = () => openEditClientModal(item.client);
      document.getElementById('addExtraBookingBtn').onclick = () => navigate('add_booking', { addForExistingClientId: item.client.id });
      document.getElementById('printClientBtn').onclick = () => Export.printClientPdf(item, b);
      document.getElementById('shareClientBtn').onclick = async () => {
        const text = `SD TRAVEL - بيانات حجز العمرة\nكود العميل: ${item.client.clientCode}\nالاسم: ${item.client.fullName}\nالهاتف: ${item.client.phone || '-'}${b ? `\nتاريخ الرحلة: ${b.tripDate}\nالإجمالي: ${money(b.totalDue)}\nالمدفوع: ${money(b.totalPaid)}\nالمتبقي: ${money(b.remainingAmount)}` : ''}`;
        if (navigator.share) {
          try { await navigator.share({ title: `SD TRAVEL - ${item.client.fullName}`, text }); } catch (_) {}
        } else if (navigator.clipboard) {
          await navigator.clipboard.writeText(text);
          showToast('تم نسخ بيانات الحجز للمشاركة');
        }
      };

      document.querySelectorAll('[data-select-booking]').forEach((btn) => {
        btn.onclick = () => {
          state.selectedBookingId = Number(btn.dataset.selectBooking);
          render();
        };
      });

      if (b) {
        document.getElementById('editBookingBtn').onclick = () => openEditBookingModal(b);
        document.getElementById('deleteBookingBtn').onclick = async () => {
          if (!window.confirm('هل أنت متأكد من حذف هذا الحجز وجميع مدفوعاته ومستنداته؟')) return;
          if (item.bookings.length <= 1) {
            await Db.deleteClientCascade(item.client.id);
            await refreshData();
            showToast('تم حذف الحجز والعميل');
            navigate('dashboard');
          } else {
            await Db.deleteBookingCascade(b.id);
            state.selectedBookingId = null;
            await refreshData();
            showToast('تم حذف الحجز');
            render();
          }
        };

        document.getElementById('addPaymentBtn').onclick = () => openPaymentModal(b, null);
        document.querySelectorAll('[data-edit-payment]').forEach((btn) => {
          btn.onclick = () => {
            const p = b.payments.find((x) => x.id === Number(btn.dataset.editPayment));
            if (p) openPaymentModal(b, p);
          };
        });
        document.querySelectorAll('[data-del-payment]').forEach((btn) => {
          btn.onclick = async () => {
            await Db.deletePayment(Number(btn.dataset.delPayment));
            await refreshData();
            showToast('تم حذف الدفعة وتحديث المتبقي');
            render();
          };
        });

        document.getElementById('addDocDetailBtn').onclick = () => {
          openAttachModal(async ({ docType, title, blob, fileName }) => {
            await Db.addDocumentBlob({
              bookingId: b.id,
              clientCode: item.client.clientCode,
              docType,
              title,
              blob,
              fileName
            });
            await refreshData();
            showToast('تم حفظ المستند في IndexedDB بصيغة Blob');
            render();
          }, true);
        };

        document.querySelectorAll('[data-zoom-doc]').forEach((img) => {
          img.onclick = () => {
            const doc = b.documents.find((d) => d.id === Number(img.dataset.zoomDoc));
            if (doc) openZoomModal(doc);
          };
        });

        document.querySelectorAll('[data-replace-doc]').forEach((btn) => {
          btn.onclick = () => {
            const doc = b.documents.find((d) => d.id === Number(btn.dataset.replaceDoc));
            if (!doc) return;
            openAttachModal(async ({ blob, fileName }) => {
              await Db.replaceDocumentBlob(doc, blob, fileName);
              await refreshData();
              showToast('تم استبدال الصورة بنجاح');
              render();
            }, false);
          };
        });

        document.querySelectorAll('[data-del-doc]').forEach((btn) => {
          btn.onclick = async () => {
            await Db.deleteDocument(Number(btn.dataset.delDoc));
            await refreshData();
            showToast('تم حذف المستند');
            render();
          };
        });
      }
    }

    if (state.route === 'reports') {
      document.querySelectorAll('[data-report-id]').forEach((btn) => {
        btn.onclick = () => { state.selectedReportId = Number(btn.dataset.reportId); render(); };
      });
      document.getElementById('repFrom').onchange = (e) => { state.reportFromDate = e.target.value; render(); };
      document.getElementById('repTo').onchange = (e) => { state.reportToDate = e.target.value; render(); };
      document.getElementById('exportExcelBtn').onclick = () => {
        const preview = buildReportPreview(state.selectedReportId, state.reportFromDate, state.reportToDate);
        Export.exportReportToXlsx(preview, state.reportFromDate, state.reportToDate);
        showToast('تم تصدير ملف Excel بنجاح');
      };
      document.getElementById('exportPdfBtn').onclick = () => {
        const preview = buildReportPreview(state.selectedReportId, state.reportFromDate, state.reportToDate);
        Export.exportReportPdf(preview, state.reportFromDate, state.reportToDate);
      };
    }

    if (state.route === 'backup') {
      document.getElementById('createBackupBtn').onclick = async () => {
        const res = await Backup.createFullBackupFile();
        state.lastBackupBlob = res.blob;
        await refreshData();
        showToast(`تم تصدير النسخة الاحتياطية (${res.clientCount} عميل، ${res.docCount} صورة)`);
        render();
      };
      const shareBackupBtn = document.getElementById('shareBackupBtn');
      if (shareBackupBtn && state.lastBackupBlob && state.lastBackupName) {
        shareBackupBtn.onclick = async () => {
          try {
            const shared = await Backup.shareLastCreatedBackup(state.lastBackupBlob, state.lastBackupName);
            if (!shared) showToast('المشاركة المباشرة للملفات غير مدعومة في هذا المتصفح، تم تنزيل الملف بالفعل');
          } catch (_) {}
        };
      }
      const fileInput = document.getElementById('restoreFileInput');
      document.getElementById('restoreBackupBtn').onclick = () => fileInput.click();
      fileInput.onchange = async (e) => {
        const file = e.target.files[0];
        e.target.value = '';
        if (!file) return;
        try {
          const sum = await Backup.restoreFromBackupFile(file);
          await refreshData();
          showToast(`تمت الاستعادة: +${sum.addedClients} عميل، تم تجاهل ${sum.skippedDuplicateClients} مكرر، +${sum.restoredDocuments} صورة`);
          render();
        } catch (err) {
          showToast(`خطأ في الاستعادة: ${err.message}`);
        }
      };
    }
  }

  async function init() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./service-worker.js', { scope: './' }).catch(() => {});
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      state.deferredInstallPrompt = e;
      render();
    });

    window.addEventListener('appinstalled', () => {
      state.deferredInstallPrompt = null;
      state.isStandalone = true;
      showToast('تم تثبيت تطبيق SD TRAVEL بنجاح');
      render();
    });

    window.addEventListener('online', () => { state.isOnline = true; render(); });
    window.addEventListener('offline', () => { state.isOnline = false; render(); });

    await Db.requestPersistentStorage();
    await refreshData();
    render();

    setTimeout(() => {
      const splash = document.getElementById('splashScreen');
      if (splash) {
        splash.classList.add('hidden');
        setTimeout(() => splash.remove(), 400);
      }
    }, 950);
  }

  document.addEventListener('DOMContentLoaded', init);
})(window);
