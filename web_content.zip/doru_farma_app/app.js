const $ = s => document.querySelector(s);
let state = {drugs:[], view:"drugs", query:"", lastUpdate:""};
const STORAGE="dusti_farma_v2";

function norm(v){return String(v??"").trim();}
function esc(s){return norm(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));}
function parseDate(v){
  if(v===null||v===undefined||v==="") return null;
  if(v instanceof Date) return v;
  const s=norm(v);
  if(/^\d{4}-\d{1,2}-\d{1,2}/.test(s)){const d=new Date(s);return isNaN(d)?null:d;}
  if(/^\d{1,2}[./-]\d{1,2}[./-]\d{4}$/.test(s)){const p=s.split(/[./-]/).map(Number);const d=new Date(p[2],p[1]-1,p[0]);return isNaN(d)?null:d;}
  const n=Number(s);
  if(Number.isFinite(n)&&n>20000&&n<60000)return new Date(Date.UTC(1899,11,30)+n*86400000);
  const d=new Date(s);return isNaN(d)?null:d;
}
function dateText(v){const d=parseDate(v);return d?d.toLocaleDateString("ru-RU",{day:"2-digit",month:"2-digit",year:"numeric"}):norm(v)||"—";}
function daysTo(v){const d=parseDate(v);if(!d)return null;return Math.ceil((d-new Date())/86400000);}
function expiryClass(v,nearest){const n=daysTo(v);if(n===null)return "";if(n<0)return "expired";if(nearest)return "nearest";return "";}
function expiryBadge(v,nearest){const n=daysTo(v);if(n===null)return "";if(n<0)return `<span class="badge red">ИСТЁК ${dateText(v)}</span>`;if(nearest)return `<span class="badge red">БЛИЖАЙШИЙ ${dateText(v)}</span>`;if(n<=90)return `<span class="badge orange">${dateText(v)}</span>`;return `<span class="badge">${dateText(v)}</span>`;}
function sortLots(lots){return [...(lots||[])].sort((a,b)=>(parseDate(a.expiry)?.getTime()||Infinity)-(parseDate(b.expiry)?.getTime()||Infinity));}
function nearestIndex(lots){const today=new Date();const valid=lots.map((l,i)=>({i,d:parseDate(l.expiry)})).filter(x=>x.d&&x.d>=today);if(!valid.length)return -1;valid.sort((a,b)=>a.d-b.d);return valid[0].i;}
function drugImage(d){return d.image?`<img src="${esc(d.image)}" alt="Фото">`:`<div class="pill-art">💊</div>`;}
function save(){localStorage.setItem(STORAGE,JSON.stringify({drugs:state.drugs,lastUpdate:state.lastUpdate}));}
function loadSaved(){try{const x=JSON.parse(localStorage.getItem(STORAGE)||"null");if(x?.drugs?.length){state.drugs=x.drugs;state.lastUpdate=x.lastUpdate||"";return true;}}catch(e){}return false;}
async function loadInitial(){if(loadSaved()){render();return;}try{const r=await fetch("initial-data.json");const x=await r.json();state.drugs=x.drugs||[];state.lastUpdate=x.updatedAt||"";save();render();}catch(e){render();$("#content").innerHTML='<div class="empty">Нет данных. Нажмите «Загрузить Excel».</div>';}}

function render(){
 const q=state.query.toLowerCase();
 const filtered=state.drugs.filter(d=>!q||(d.name||"").toLowerCase().includes(q)||(d.manufacturer||"").toLowerCase().includes(q)||(d.shelf||"").toLowerCase().includes(q));
 $("#drugCount").textContent=`${state.drugs.length} препаратов`;
 const shelves=new Set(state.drugs.map(d=>d.shelf).filter(Boolean));
 $("#shelfCount").textContent=`${shelves.size} полок`;
 $("#updateTime").textContent=state.lastUpdate?`Обновлено: ${state.lastUpdate}`:"Данные не загружены";
 document.querySelectorAll(".menu-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===state.view));
 if(state.view==="drugs")renderDrugs(filtered);else if(state.view==="shelves")renderShelves();else renderEditShelves();
}
function renderDrugs(items){
 if(!items.length){$("#content").innerHTML='<div class="empty">Лекарство не найдено.</div>';return;}
 $("#content").innerHTML='<div class="list">'+items.slice(0,700).map(d=>{const lots=sortLots(d.lots),ni=nearestIndex(lots),nearest=ni>=0?lots[ni]:null;return `<div class="drug-card" data-name="${esc(d.name)}"><div class="drug-icon">${drugImage(d)}</div><div class="drug-main"><div class="drug-name">${esc(d.name)}</div><div class="drug-meta"><span class="badge shelf-badge">Полка: ${esc(d.shelf||"Не назначена")}</span>${d.manufacturer?`<span>${esc(d.manufacturer)}</span>`:""}${nearest?.expiry?expiryBadge(nearest.expiry,true):""}</div></div><div class="price">${esc(d.price||"—")}</div></div>`;}).join("")+'</div>';
 document.querySelectorAll(".drug-card").forEach(c=>c.onclick=()=>openDrug(c.dataset.name));
}
function openDrug(name){
 const d=state.drugs.find(x=>x.name===name);if(!d)return;const lots=sortLots(d.lots),ni=nearestIndex(lots);
 $("#modalBody").innerHTML=`<div class="detail-head"><div class="detail-icon">${drugImage(d)}</div><div><div class="detail-title">${esc(d.name)}</div><div class="detail-sub">Информация о препарате</div></div></div><div class="info-grid"><div class="info-box"><div class="info-label">НАЗВАНИЕ</div><div class="info-value">${esc(d.name)}</div></div><div class="info-box shelf-box"><div class="info-label">ПОЛКА</div><div class="info-value">${esc(d.shelf||"Не назначена")}</div></div><div class="info-box"><div class="info-label">ШТРИХ-КОД</div><div class="info-value">${esc(d.barcode||"—")}</div></div><div class="info-box"><div class="info-label">ЦЕНА</div><div class="info-value">${esc(d.price||"—")}</div></div><div class="info-box"><div class="info-label">ПРЕДСТАВИТЕЛЬ / ФИРМА</div><div class="info-value">${esc(d.manufacturer||"—")}</div></div></div><div class="section-title">Сроки годности ${lots.length?`(${lots.length})`:""}</div><div class="lots">${lots.length?lots.map((l,i)=>{const isNearest=i===ni;return `<div class="lot ${expiryClass(l.expiry,isNearest)}"><div class="lot-left"><div class="lot-date">${dateText(l.expiry)}</div><div class="lot-note">Серия: ${esc(l.series||"—")} · Кол-во: ${esc(l.qty||"—")}</div></div>${expiryBadge(l.expiry,isNearest)}</div>`}).join(""):'<div class="empty">Срок годности не указан.</div>'}</div><div class="section-title">Изменение полки</div><div class="edit-row"><input id="modalShelf" value="${esc(d.shelf||"")}" placeholder="Например: A-01"><button class="primary" id="saveShelf">Сохранить</button></div><div class="file-note">Если в Excel есть колонка «Полка» или отдельный лист «Полки», значение будет установлено автоматически при следующей загрузке.</div>`;
 $("#modal").classList.remove("hidden");$("#saveShelf").onclick=()=>{d.shelf=$("#modalShelf").value.trim();save();closeModal();render();};
}
function closeModal(){$("#modal").classList.add("hidden");}
function renderShelves(){
 const map={};state.drugs.forEach(d=>{const s=d.shelf||"Не назначена";(map[s]??=[]).push(d)});const keys=Object.keys(map).sort((a,b)=>a.localeCompare(b,"ru"));
 if(!keys.length){$("#content").innerHTML='<div class="empty">Полки пока не назначены.</div>';return;}
 $("#content").innerHTML='<div class="list">'+keys.map(s=>`<div class="shelf-card"><div class="shelf-icon">▣</div><div><div class="shelf-name">Полка ${esc(s)}</div><div class="shelf-drugs">${map[s].length} препаратов</div></div><button class="shelf-edit" data-s="${esc(s)}">Открыть</button></div>`).join("")+'</div>';
 document.querySelectorAll(".shelf-edit").forEach(b=>b.onclick=()=>{state.query=b.dataset.s==="Не назначена"?"":b.dataset.s;state.view="drugs";$("#search").value=state.query;render();});
}
function renderEditShelves(){
 const items=[...state.drugs].sort((a,b)=>a.name.localeCompare(b.name,"ru"));if(!items.length){$("#content").innerHTML='<div class="empty">Нет препаратов.</div>';return;}
 $("#content").innerHTML=`<div class="file-note"><b>Изменение полки.</b> Укажите новую полку и нажмите «Сохранить». При загрузке Excel с колонкой «Полка» эти значения также будут обновляться автоматически.</div><div class="list">${items.slice(0,700).map(d=>`<div class="shelf-card"><div class="drug-icon small">${drugImage(d)}</div><div style="flex:1;min-width:0"><div class="drug-name">${esc(d.name)}</div><div class="shelf-drugs">Текущая: ${esc(d.shelf||"Не назначена")}</div></div><input class="shelf-input" value="${esc(d.shelf||"")}" placeholder="A-01"><button class="shelf-edit save-one" data-name="${esc(d.name)}">✓</button></div>`).join("")}</div>`;
 document.querySelectorAll(".save-one").forEach(btn=>btn.onclick=()=>{const row=btn.parentElement,input=row.querySelector(".shelf-input"),d=state.drugs.find(x=>x.name===btn.dataset.name);if(d){d.shelf=input.value.trim();save();render();}});
}
function headerKey(s){return norm(s).toLowerCase().replace(/ё/g,"е").replace(/\s+/g," ");}
async function parseXlsx(file){
 const zip=await JSZip.loadAsync(await file.arrayBuffer());
 const workbookXml=zip.file("xl/workbook.xml");
 const relXml=zip.file("xl/_rels/workbook.xml.rels");
 let sheetFiles=[];
 if(workbookXml&&relXml){
   const wxml=new DOMParser().parseFromString(await workbookXml.async("string"),"application/xml");
   const rxml=new DOMParser().parseFromString(await relXml.async("string"),"application/xml");
   const rels={};rxml.querySelectorAll("Relationship").forEach(r=>rels[r.getAttribute("Id")]=r.getAttribute("Target"));
   wxml.querySelectorAll("sheet").forEach(s=>{const rid=s.getAttribute("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")||s.getAttribute("r:id");const target=rels[rid];if(target)sheetFiles.push({name:s.getAttribute("name")||"",file:"xl/"+target.replace(/^\//,"").replace(/^xl\//,"")});});
 }
 if(!sheetFiles.length){const f=Object.keys(zip.files).find(x=>/^xl\/worksheets\/sheet\d+\.xml$/i.test(x));if(f)sheetFiles=[{name:"Лист1",file:f}];}
 const shared=[];const ss=zip.file("xl/sharedStrings.xml");
 if(ss){const xml=new DOMParser().parseFromString(await ss.async("string"),"application/xml");xml.querySelectorAll("si").forEach(si=>shared.push([...si.querySelectorAll("t")].map(t=>t.textContent).join("")));}
 function readGrid(fileName){
   const xmlFile=zip.file(fileName);if(!xmlFile)return [];
   return xmlFile.async("string").then(str=>{const xml=new DOMParser().parseFromString(str,"application/xml"),rows=[...xml.querySelectorAll("sheetData > row")],grid=[];
    for(const row of rows){const arr=[];row.querySelectorAll(":scope > c").forEach(c=>{const ref=c.getAttribute("r")||"A1",m=ref.match(/^([A-Z]+)/i);let col=0;if(m){for(const ch of m[1].toUpperCase())col=col*26+(ch.charCodeAt(0)-64);col--;}const t=c.getAttribute("t");let v="";if(t==="inlineStr")v=[...c.querySelectorAll("is t")].map(x=>x.textContent).join("");else{const raw=c.querySelector("v")?.textContent??"";v=t==="s"?(shared[Number(raw)]??""):raw;}arr[col]=v;});grid.push(arr);}return grid;});
 }
 const sheets=[];for(const s of sheetFiles)sheets.push({name:s.name,grid:await readGrid(s.file)});
 const names=["наименование","название","номенклатура","товар","препарат","дору"];
 function parseMain(sheet){
   const grid=sheet.grid;let h=-1;for(let i=0;i<Math.min(grid.length,40);i++){const a=(grid[i]||[]).map(headerKey);if(a.some(x=>names.includes(x)||x.includes("наименование"))){h=i;break;}}if(h<0)h=0;
   const headers=(grid[h]||[]).map(headerKey);const idx=variants=>{for(const v of variants){const i=headers.indexOf(headerKey(v));if(i>=0)return i;}return -1;};
   const ixName=idx(names),ixBarcode=idx(["штрих-код","штрих код","штрихкод","barcode","ean","ean13","код товара","артикул","sku"]),ixPrice=idx(["цена","price","нарх"]),ixMan=idx(["производитель","представитель","фирма","manufacturer"]),ixShelf=idx(["полка","shelf","стеллаж"]),ixSeries=idx(["серия","series"]),ixExpiry=idx(["срок","срок годности","expiry"]),ixQty=idx(["кол-во","количество","остаток","qty"]),ixImage=idx(["фото","изображение","image","image url","фото url"]);
   if(ixName<0)return null;const out={};for(let r=h+1;r<grid.length;r++){const row=grid[r]||[],name=norm(row[ixName]);if(!name)continue;const d=out[name]??={name,barcode:"",price:"",manufacturer:"",shelf:"",image:"",lots:[]};if(ixBarcode>=0&&!d.barcode)d.barcode=norm(row[ixBarcode]);if(!d.price&&ixPrice>=0)d.price=norm(row[ixPrice]);if(!d.manufacturer&&ixMan>=0)d.manufacturer=norm(row[ixMan]);if(ixShelf>=0&&norm(row[ixShelf]))d.shelf=norm(row[ixShelf]);if(ixImage>=0&&norm(row[ixImage]))d.image=norm(row[ixImage]);if(ixExpiry>=0||ixSeries>=0||ixQty>=0)d.lots.push({series:ixSeries>=0?norm(row[ixSeries]):"",expiry:ixExpiry>=0?norm(row[ixExpiry]):"",qty:ixQty>=0?norm(row[ixQty]):""});}return {drugs:Object.values(out),hasShelf:ixShelf>=0};
 }
 let main=sheets.map(parseMain).find(Boolean);if(!main)throw new Error("Не найдена колонка «Наименование»");
 // Optional separate sheet: «Полки» with columns Наименование + Полка.
 const shelfMap=new Map();for(const s of sheets){const g=s.grid;if(!g.length)continue;let h=-1;for(let i=0;i<Math.min(g.length,15);i++){const a=(g[i]||[]).map(headerKey);if(a.includes("наименование")&&(a.includes("полка")||a.includes("shelf"))){h=i;break;}}if(h>=0){const heads=(g[h]||[]).map(headerKey),ni=heads.indexOf("наименование"),si=heads.includes("полка")?heads.indexOf("полка"):heads.indexOf("shelf");for(let r=h+1;r<g.length;r++){const n=norm(g[r]?.[ni]),shelf=norm(g[r]?.[si]);if(n&&shelf)shelfMap.set(n,shelf);}}}
 main.drugs.forEach(d=>{if(shelfMap.has(d.name))d.shelf=shelfMap.get(d.name);});main.hasShelf=main.hasShelf||shelfMap.size>0;main.shelfMapCount=shelfMap.size;return main;
}
async function importExcel(file){
 if(!file.name.toLowerCase().endsWith(".xlsx"))throw new Error("Выберите файл Excel в формате .xlsx");
 const parsed=await parseXlsx(file);const oldMap=new Map(state.drugs.map(d=>[d.name,d]));
 // If the new file has no shelf column/map, preserve manually assigned shelves by exact drug name.
 parsed.drugs.forEach(d=>{if(!d.barcode&&oldMap.has(d.name))d.barcode=oldMap.get(d.name).barcode||"";if(!d.shelf&&oldMap.has(d.name))d.shelf=oldMap.get(d.name).shelf||"";if(!d.image&&oldMap.has(d.name))d.image=oldMap.get(d.name).image||"";});
 state.drugs=parsed.drugs;state.lastUpdate=new Date().toLocaleString("ru-RU");save();state.view="drugs";state.query="";$("#search").value="";render();
 const shelfMsg=parsed.hasShelf?` Полки загружены автоматически${parsed.shelfMapCount?` (${parsed.shelfMapCount} из листа «Полки»).`:"."}`:" В этом Excel нет колонки «Полка»: сохранены ранее назначенные полки. Для полной автоматической загрузки добавьте колонку «Полка» или лист «Полки».";
 alert(`ГОТОВО! Данные полностью заменены данными из файла. Загружено препаратов: ${state.drugs.length}.${shelfMsg}`);
}
function startFile(){const input=$("#fileInput");input.value="";input.click();}
$("#updateBtn").onclick=startFile;$("#uploadBtn").onclick=startFile;$("#fileInput").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{await importExcel(f);}catch(err){alert("Ошибка загрузки Excel: "+err.message);}};
const drop=$("#dropZone");if(drop){["dragenter","dragover"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add("drag");}));["dragleave","drop"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove("drag");}));drop.addEventListener("drop",e=>{const f=e.dataTransfer.files[0];if(f){importExcel(f).catch(err=>alert("Ошибка загрузки Excel: "+err.message));}});}
$("#search").oninput=e=>{state.query=e.target.value;state.view="drugs";render();};$("#clearSearch").onclick=()=>{$("#search").value="";state.query="";render();};

document.querySelectorAll(".menu-btn").forEach(b=>b.onclick=()=>{state.view=b.dataset.view;render();});$("#closeModal").onclick=closeModal;$("#modal").onclick=e=>{if(e.target.id==="modal")closeModal();};

let scannerStream=null, scannerTimer=null, scannerActive=false, ocrBusy=false;
function closeScanner(){scannerActive=false;if(scannerTimer){clearTimeout(scannerTimer);scannerTimer=null;}if(scannerStream){scannerStream.getTracks().forEach(t=>t.stop());scannerStream=null;}const v=$("#scannerVideo");if(v)v.srcObject=null;$("#scannerModal").classList.add("hidden");}
function tokenize(s){return norm(s).toLowerCase().replace(/ё/g,"е").replace(/[^a-zа-яё0-9]+/gi," ").split(/\s+/).filter(x=>x.length>2);}
function similarity(a,b){const aa=tokenize(a),bb=new Set(tokenize(b));if(!aa.length)return 0;let hit=0;aa.forEach(x=>{if(bb.has(x)||[...bb].some(y=>y.includes(x)||x.includes(y)))hit++;});return hit/aa.length;}
function findByVisualText(text){
 const raw=norm(text); if(!raw)return null;
 let best=null,bestScore=0;
 for(const d of state.drugs){
   const score=Math.max(similarity(raw,d.name),similarity(raw,d.manufacturer||""),similarity(raw,(d.name||"")+" "+(d.manufacturer||"")));
   if(score>bestScore){bestScore=score;best=d;}
 }
 return bestScore>=0.34?best:null;
}
function showScanError(msg){$("#scanError").textContent=msg;$("#scanError").style.display="block";}
async function startScanner(){
 $("#scannerModal").classList.remove("hidden");$("#scanStatus").textContent="Запуск камеры…";$("#scanError").style.display="none";
 if(!navigator.mediaDevices?.getUserMedia){showScanError("Камера недоступна. Разрешите доступ к камере в AppsGeyser/браузере.");return;}
 if(!window.Tesseract){showScanError("Модуль распознавания текста не загрузился. Проверьте интернет-соединение приложения и попробуйте снова.");return;}
 try{
   scannerStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:720}},audio:false});
   const video=$("#scannerVideo");video.srcObject=scannerStream;await video.play();scannerActive=true;
   $("#scanStatus").textContent="Камера готова — наведите на название лекарства";
   const canvas=document.createElement("canvas");
   const scan=async()=>{
     if(!scannerActive||ocrBusy)return;
     if(video.readyState<2){scannerTimer=setTimeout(scan,500);return;}
     ocrBusy=true;
     try{
       const maxW=1000, scale=Math.min(1,maxW/video.videoWidth||1);canvas.width=Math.round(video.videoWidth*scale);canvas.height=Math.round(video.videoHeight*scale);
       const ctx=canvas.getContext("2d");ctx.drawImage(video,0,0,canvas.width,canvas.height);
       $("#scanStatus").textContent="Распознаём название лекарства…";
       const result=await Tesseract.recognize(canvas,"rus+eng",{logger:m=>{if(m.status==="recognizing text")$("#scanStatus").textContent=`Распознаём упаковку… ${Math.round((m.progress||0)*100)}%`;}});
       const text=result?.data?.text||""; const d=findByVisualText(text);
       if(d){closeScanner();openDrug(d.name);return;}
       $("#scanStatus").textContent="Лекарство не найдено. Покажите крупнее название на упаковке…";
     }catch(e){$("#scanStatus").textContent="Повторяем распознавание…";}
     finally{ocrBusy=false;if(scannerActive)scannerTimer=setTimeout(scan,900);}
   };
   scan();
 }catch(e){showScanError("Не удалось открыть камеру. Разрешите доступ к камере в настройках приложения и попробуйте снова.");}
}
$("#scanBtn").onclick=startScanner;$("#closeScanner").onclick=closeScanner;$("#stopScanner").onclick=closeScanner;$("#scannerModal").onclick=e=>{if(e.target.id==="scannerModal")closeScanner();};
loadInitial();
