Jojo Order Book - phone install
1. Upload ALL files in this folder to any free HTTPS web host (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Open the web address once on your phone, with internet.
3. Android Chrome: menu (3 dots) > Install app / Add to Home screen.
   iPhone Safari: Share > Add to Home Screen.
4. After that it opens like an app and works with no internet. Orders stay saved on the phone.
