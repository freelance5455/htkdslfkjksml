-- V35: secure student deletion RPC
create or replace function public.delete_teacher_student(p_student_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
declare v_ok boolean;
begin
 select exists(select 1 from public.students s join public.circles c on c.id=s.circle_id where s.id=p_student_id and c.teacher_id=auth.uid()) into v_ok;
 if not v_ok then raise exception 'غير مسموح بحذف هذا الطالب'; end if;
 delete from public.recitations where student_id=p_student_id;
 delete from public.attendance where student_id=p_student_id;
 delete from public.students where id=p_student_id;
 return true;
end; $$;
revoke all on function public.delete_teacher_student(uuid) from public;
grant execute on function public.delete_teacher_student(uuid) to authenticated;
notify pgrst, 'reload schema';
