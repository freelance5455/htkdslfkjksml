# v1.62.69 — Painel visual de pênaltis

- Área de Testes: placar de cobranças com ● verde, × vermelho e ○ pendente.
- Revelação separada: a direção e o resultado só aparecem após tocar em REVELAR COBRANÇA.
- Visualiza goleiro, cobrador, camisas identificadas pelas cores dos clubes cadastrados e a zona da bola no gol.
- Aplicado às cobranças do jogador e às cobranças automáticas.
- Preserva ordem escolhida, alternância, morte súbita e placar oficial 0 x 0.
