# Calculator — source export notes

A simple calculator web app: one screen, immediate-execution keypad, live expression
line, decimals, sign toggle, percent, backspace and full keyboard support.

## Stack

- React 18 + React Router 7, built with Vite
- Tailwind CSS + shadcn/ui components
- Base44 SDK client (`@base44/sdk`) for the hosted backend (auth, data) — the app
  itself stores no data and needs no backend code

## Project structure

```
index.html                  entry HTML, Google Fonts, title
vite.config.js              Vite build config (React + Base44 plugin)
tailwind.config.js          design tokens mapped to Tailwind classes
postcss.config.js           PostCSS pipeline
components.json             shadcn/ui generator config
jsconfig.json               path aliases and type-check settings
eslint.config.js            lint rules
.npmrc                      npm install policy (supply-chain cooldown)
.env.example                environment template (no real values)
base44/config.jsonc         build/serve commands used by the Base44 runner
base44/entities/User.jsonc  built-in User entity schema
src/main.jsx                React entry point
src/App.jsx                 router, providers, auth wrapper
src/index.css               design tokens (colors, fonts, radii, dark mode)
src/api/base44Client.js     pre-configured Base44 SDK client
src/lib/                    auth context, app params, query client, helpers
src/hooks/useCalculator.js  calculator engine (state + arithmetic)
src/components/calculator/  CalcButton, CalculatorCard (keypad + display)
src/components/ui/          shadcn/ui primitive components
src/pages/Calculator.jsx    the app's single screen (route "/")
```

## Run locally

```bash
npm install
npm run dev      # http://localhost:5173
```

Production build:

```bash
npm run build    # outputs to ./dist
npm run preview  # serve the built app locally
```

To run against the hosted Base44 backend (auth, data) instead of a local stub:

```bash
npm install -g base44@latest
base44 login
base44 link      # writes base44/.app.jsonc with the app id
base44 dev       # frontend + backend together
```

## Configuration and secrets

- `.env.example` documents the only environment flag (`BASE44_LEGACY_SDK_IMPORTS`).
- The exported archive contains **no** API keys, passwords, tokens or production
  secrets. No secret values are required to run this app.
- `base44/.app.jsonc` is intentionally not exported: it is a per-machine pointer to
  the Base44 app and is gitignored upstream.

## Deployment

The project is a static Vite build (`npm run build` → `dist/`). Serve `dist/` from any
static host, or publish through Base44, which reads `base44/config.jsonc` for the
install, build and output settings.

## What is intentionally absent

- No backend functions, workflows, agents, actors or custom API routes exist in this
  app, so none are in the archive.
- No binary assets (images, icons, fonts) are bundled: the favicon and typography are
  loaded from remote URLs; interface icons come from `lucide-react`.
