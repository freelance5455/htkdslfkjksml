/*
 * RTL Browser - Text Formatting Engine (injected layer)
 *
 * Design goals:
 *  - Never touch "*" blindly. Only elements that directly own visible text are tagged.
 *  - All styling lives in ONE injected stylesheet gated by html[data-rtlf-on],
 *    so turning the engine off is a single attribute removal (no reload, no DOM rewrite).
 *  - Direction is applied only to safe block containers (never to multi-child flex/grid
 *    layout containers) so menus/toolbars do not get mirrored.
 *  - Work is time-sliced (<= 8ms per frame) and incremental via MutationObserver,
 *    so React/Vue/Next/AJAX/infinite-scroll content is handled without freezing.
 *  - Text nodes are never modified: copy/paste and framework hydration stay intact.
 *
 * Bootstrapped by a document-start user script that defines:
 *   window.__RTLF_BOOT = { global: <cfg>, sites: { host: <cfg> }, fontCss: { fontId: "@font-face..." }, platform }
 */
(function () {
  'use strict';
  if (window.__RTLF && window.__RTLF.version) return;

  var ATTR_ON = 'data-rtlf-on';
  var T = 'data-rtlf';          // text holder: "t"
  var D = 'data-rtlf-d';        // direction override on block: "r" | "l"
  var L = 'data-rtlf-l';        // detected script of holder: "r" | "l" | "n"
  var X = 'data-rtlf-x';        // excluded (icon fonts etc.)
  var B = 'data-rtlf-b';        // originally bold, keep weight
  var C = 'data-rtlf-c';        // centered/justified block, keep alignment
  var STYLE_ID = '__rtlf_style';
  var FONT_ID = '__rtlf_fonts';

  var SKIP_TAGS = {
    SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, CODE: 1, PRE: 1, KBD: 1, SAMP: 1, VAR: 1, TT: 1,
    TEXTAREA: 1, INPUT: 1, SELECT: 1, OPTION: 1, OPTGROUP: 1, BUTTON: 1, CANVAS: 1, VIDEO: 1,
    AUDIO: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, SVG: 1, MATH: 1, IMG: 1, PICTURE: 1, HEAD: 1,
    TITLE: 1, META: 1, LINK: 1
  };
  var BOLD_TAGS = { B: 1, STRONG: 1, H1: 1, H2: 1, H3: 1, H4: 1, H5: 1, H6: 1, TH: 1 };
  var ICON_FONT_RE = /icon|awesome|material|glyph|symbol|fontello|ionicons|feather|remix|dashicons|bootstrap-icons|codicon|octicon|lucide|tabler/i;
  var ICON_CLASS_RE = /(^|\s)(fa|fas|far|fab|fal|fad|bi|mdi|ti|icon|icons|glyphicon|material-icons|material-symbols[\w-]*|dashicons)(\s|-|$)/i;
  var RTL_RE = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/g;
  var LTR_RE = /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]/g;
  var PUA_RE = /^[\s\uE000-\uF8FF]+$/;

  var cfg = null;
  var queue = [];
  var queued = new WeakSet();
  var blockDone = new WeakMap();
  var observer = null;
  var scheduled = false;
  var startedObserving = false;

  // ---------- config ----------
  function pickConfig(boot) {
    var host = (location.hostname || '').replace(/^www\./, '');
    var sites = boot.sites || {};
    var c = sites[host];
    if (!c) {
      // allow parent-domain match: m.example.com -> example.com
      var parts = host.split('.');
      while (!c && parts.length > 2) { parts.shift(); c = sites[parts.join('.')]; }
    }
    return c || boot.global;
  }

  // ---------- language detection ----------
  function detect(text) {
    if (!text) return 'n';
    var s = text.length > 400 ? text.slice(0, 400) : text;
    var r = (s.match(RTL_RE) || []).length;
    var l = (s.match(LTR_RE) || []).length;
    if (r === 0 && l === 0) return 'n';
    return r >= l * 0.6 ? 'r' : 'l';   // Persian pages often mix Latin words; bias toward RTL
  }

  // ---------- CSS ----------
  function buildCss(c) {
    var on = 'html[' + ATTR_ON + ']';
    var holder = on + ' [' + T + '="t"]:not([' + X + '])';
    var out = [];
    if (c.fontFamily) {
      out.push(holder + '{font-family:' + c.fontFamily + ' !important;}');
    }
    if (c.weight && c.weight !== 400) {
      out.push(holder + ':not([' + B + ']){font-weight:' + c.weight + ' !important;}');
    }
    if (c.lineHeight && c.lineHeight > 0) {
      out.push(holder + '{line-height:' + c.lineHeight + ' !important;}');
    }
    if (c.letterSpacing) {
      // letter-spacing breaks cursive joining in Arabic script -> word-spacing for RTL text
      out.push(holder + '[' + L + '="l"]{letter-spacing:' + c.letterSpacing + 'em !important;}');
      out.push(holder + '[' + L + '="r"]{word-spacing:' + (c.letterSpacing * 4) + 'em !important;}');
    }
    if (c.paragraphSpacing) {
      out.push(on + ' p[' + T + '="t"],' + on + ' li[' + T + '="t"]{margin-block-end:' + c.paragraphSpacing + 'em !important;}');
    }
    if (c.direction !== 'off') {
      out.push(on + ' [' + D + '="r"]{direction:rtl !important;}');
      out.push(on + ' [' + D + '="l"]{direction:ltr !important;}');
      out.push(on + ' [' + D + '="r"]:not([' + C + ']){text-align:right !important;}');
      out.push(on + ' [' + D + '="l"]:not([' + C + ']){text-align:left !important;}');
      // typed text in inputs follows the script being typed
      out.push(on + ' input:not([type]),' + on + ' input[type=text],' + on + ' input[type=search],' + on + ' textarea{unicode-bidi:plaintext;text-align:start;}');
    }
    if (c.platform === 'ios' && c.textScale && c.textScale !== 100) {
      out.push(on + ' body{-webkit-text-size-adjust:' + c.textScale + '% !important;}');
    }
    // Selection/copy must keep working even on sites that disable it for styled spans
    out.push(holder + '{-webkit-user-select:auto;}');
    return out.join('\n');
  }

  // Constructable stylesheets are not blocked by CSP style-src and survive <head> swaps (SPA);
  // fall back to a <style> element on old WebViews.
  var CAN_ADOPT = !!(window.CSSStyleSheet && CSSStyleSheet.prototype.replaceSync && 'adoptedStyleSheets' in Document.prototype);
  var sheets = [];   // [{root, sheet|el}]

  function ensureStyle(root) {
    var css = buildCss(cfg);
    var entry = null;
    for (var i = 0; i < sheets.length; i++) if (sheets[i].root === root) { entry = sheets[i]; break; }
    if (CAN_ADOPT) {
      try {
        if (!entry) { entry = { root: root, sheet: new CSSStyleSheet(), css: null }; sheets.push(entry); }
        if (entry.css !== css) { entry.sheet.replaceSync(css); entry.css = css; }
        var list = root.adoptedStyleSheets || [];
        if (list.indexOf(entry.sheet) < 0) root.adoptedStyleSheets = list.concat([entry.sheet]);
        return;
      } catch (e) { CAN_ADOPT = false; entry = null; sheets = []; }
    }
    var doc = root.ownerDocument || root;
    var target = root === document ? (document.head || document.documentElement) : root;
    if (!target) return;
    var el = root === document ? document.getElementById(STYLE_ID) : root.querySelector('#' + STYLE_ID);
    if (!el) {
      el = doc.createElement('style');
      el.id = STYLE_ID;
      target.appendChild(el);
    }
    if (el.textContent !== css) el.textContent = css;
    // keep our sheet last so it wins ties against site CSS
    if (root === document && el.parentNode && el.nextElementSibling) el.parentNode.appendChild(el);
  }

  function refreshAllStyles() { for (var i = 0; i < sheets.length; i++) ensureStyle(sheets[i].root); ensureStyle(document); }

  // Fonts are loaded through the FontFace API from in-memory bytes: immune to CSP font-src
  // and no network. @font-face <style> is the fallback.
  var loadedFaces = {};
  function addFontCss(css) {
    if (!css) return;
    var fam = /font-family:"([^"]+)"/.exec(css), b64 = /base64,([^)]+)\)/.exec(css);
    if (!fam || !b64) return;
    var name = fam[1];
    if (loadedFaces[name]) return;
    loadedFaces[name] = true;
    if (window.FontFace && document.fonts) {
      try {
        var bin = atob(b64[1]), buf = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
        var face = new FontFace(name, buf.buffer, { weight: '100 900', style: 'normal', display: 'swap' });
        document.fonts.add(face);
        face.load()['catch'](function () { styleFont(css); });
        return;
      } catch (e) { /* fall through */ }
    }
    styleFont(css);
  }
  function styleFont(css) {
    var el = document.createElement('style');
    el.className = FONT_ID;
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
  }

  function ensureFonts() {
    var boot = window.__RTLF_BOOT || {};
    var css = (boot.fontCss && cfg.fontId && boot.fontCss[cfg.fontId]) || '';
    addFontCss(css);
  }

  // ---------- DOM classification ----------
  function isExcludedElement(el) {
    var tag = el.tagName;
    if (SKIP_TAGS[tag] || SKIP_TAGS[tag.toUpperCase()]) return true;
    if (el.isContentEditable) return true;
    if (el.namespaceURI && el.namespaceURI !== 'http://www.w3.org/1999/xhtml') return true;
    var role = el.getAttribute && el.getAttribute('role');
    if (role === 'img' || role === 'button' || role === 'textbox' || role === 'code') return true;
    return false;
  }

  function insideExcluded(el) {
    for (var n = el, i = 0; n && n.nodeType === 1 && i < 30; n = n.parentElement, i++) {
      if (n.hasAttribute(X)) return true;
      if (isExcludedElement(n)) return true;
    }
    return false;
  }

  function looksLikeIcon(el, cs, text) {
    if (PUA_RE.test(text)) return true;
    var cls = typeof el.className === 'string' ? el.className : '';
    if (cls && ICON_CLASS_RE.test(cls) && text.trim().length <= 3) return true;
    if (ICON_FONT_RE.test(cs.fontFamily)) return true;
    if (el.getAttribute('aria-hidden') === 'true' && text.trim().length <= 2) return true;
    // ligature icon fonts (material) render words like "home": short, single word, icon-ish class
    if (/material|symbol/i.test(cls)) return true;
    return false;
  }

  function findBlock(el) {
    for (var n = el, i = 0; n && n.nodeType === 1 && i < 8; n = n.parentElement, i++) {
      if (n === document.body || n === document.documentElement) return null;
      var cs = getComputedStyle(n);
      var d = cs.display;
      if (d === 'block' || d === 'list-item' || d === 'table-cell' || d === 'flow-root' || d === 'table-caption') {
        return { el: n, cs: cs };
      }
      if (d === 'flex' || d === 'inline-flex' || d === 'grid' || d === 'inline-grid') {
        // A layout container with several element children must NOT be mirrored.
        if (n.childElementCount > 1) return { el: el === n ? null : el, cs: getComputedStyle(el), inlineOnly: true };
        return { el: n, cs: cs };
      }
    }
    return null;
  }

  function processHolder(el) {
    if (!el || el.nodeType !== 1 || !el.isConnected) return;
    if (insideExcluded(el)) return;
    // own text only (not descendants)
    var own = '';
    for (var c = el.firstChild; c; c = c.nextSibling) if (c.nodeType === 3) own += c.nodeValue;
    if (!own.trim()) return;

    var cs = getComputedStyle(el);
    if (looksLikeIcon(el, cs, own)) { el.setAttribute(X, ''); return; }

    var lang = detect(own.trim().length > 20 ? own : (el.textContent || own));
    if (el.getAttribute(T) !== 't') el.setAttribute(T, 't');
    if (el.getAttribute(L) !== lang) el.setAttribute(L, lang);
    if (!el.hasAttribute(B) && (BOLD_TAGS[el.tagName] || parseInt(cs.fontWeight, 10) >= 600)) el.setAttribute(B, '');

    if (cfg.direction === 'off') return;
    var blk = findBlock(el);
    if (!blk || !blk.el) return;
    var b = blk.el;
    var prev = blockDone.get(b);
    if (prev === cfg._gen) return;
    blockDone.set(b, cfg._gen);

    var want;
    if (cfg.direction === 'rtl') want = 'r';
    else if (cfg.direction === 'ltr') want = 'l';
    else {
      var bl = detect(b.textContent);
      if (bl === 'n') { b.removeAttribute(D); return; }
      // In auto mode only override when the detected script disagrees with the site's direction.
      var curD = b.getAttribute(D);
      var orig = curD ? (b.__rtlfOrigDir || blk.cs.direction) : blk.cs.direction;
      if (!curD) b.__rtlfOrigDir = blk.cs.direction;
      var origShort = orig === 'rtl' ? 'r' : 'l';
      want = bl === origShort ? null : bl;
    }
    if (!want) { b.removeAttribute(D); return; }
    if (!b.hasAttribute(C) && !b.getAttribute(D)) {
      var ta = blk.cs.textAlign;
      if (ta === 'center' || ta === 'justify' || ta === '-webkit-center') b.setAttribute(C, '');
    }
    if (b.getAttribute(D) !== want) b.setAttribute(D, want);
  }

  // ---------- scheduling (time-sliced) ----------
  function enqueueTree(root) {
    if (!root) return;
    if (root.nodeType === 3) { enqueue(root.parentElement); return; }
    if (root.nodeType !== 1 && root.nodeType !== 11) return;
    if (root.nodeType === 1 && isExcludedElement(root)) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (t) {
        return t.nodeValue && t.nodeValue.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    var t;
    while ((t = walker.nextNode())) enqueue(t.parentElement);
    // open shadow roots (web components)
    if (root.querySelectorAll) {
      var all = root.querySelectorAll('*');
      for (var i = 0; i < all.length; i++) {
        var sr = all[i].shadowRoot;
        if (sr && !sr.__rtlf) { sr.__rtlf = true; ensureStyle(sr); observe(sr); enqueueTree(sr); }
      }
    }
  }

  function enqueue(el) {
    if (!el || queued.has(el)) return;
    queued.add(el);
    queue.push(el);
    schedule();
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    var run = function (deadline) {
      scheduled = false;
      var start = performance.now();
      // Idle deadlines can report 0ms when fired by timeout; always grant a small frame budget.
      var budget = deadline && deadline.timeRemaining ? Math.max(6, Math.min(deadline.timeRemaining(), 12)) : 8;
      while (queue.length) {
        var el = queue.shift();
        queued.delete(el);
        try { processHolder(el); } catch (e) { /* never break the page */ }
        if (performance.now() - start > budget) break;
      }
      if (queue.length) schedule();
    };
    if (window.requestIdleCallback) requestIdleCallback(run, { timeout: 120 });
    else requestAnimationFrame(function () { run(null); });
  }

  // ---------- observer ----------
  function onMutations(list) {
    if (!cfg || !cfg.enabled) return;
    for (var i = 0; i < list.length; i++) {
      var m = list[i];
      if (m.type === 'childList') {
        for (var j = 0; j < m.addedNodes.length; j++) {
          var n = m.addedNodes[j];
          if (n.nodeType === 1 && (n.id === STYLE_ID || n.className === FONT_ID)) continue;
          enqueueTree(n);
        }
        if (m.target && m.target.nodeType === 1) { blockDone.delete(m.target); enqueue(m.target); }
      } else if (m.type === 'characterData') {
        var p = m.target.parentElement;
        if (p) { var bb = findBlockCached(p); if (bb) blockDone.delete(bb); enqueue(p); }
      }
    }
  }
  function findBlockCached(el) { var r = findBlock(el); return r && r.el; }

  function observe(root) {
    if (!observer) observer = new MutationObserver(onMutations);
    observer.observe(root, { childList: true, subtree: true, characterData: true });
  }

  // Some SPAs (Next.js, YouTube) swap <head>; keep our sheets alive.
  function guardStyles() {
    if (!cfg || !cfg.enabled) return;
    ensureStyle(document);
  }

  // ---------- public API ----------
  var gen = 0;
  function apply(newCfg) {
    var dirChanged = !cfg || cfg.direction !== newCfg.direction;
    cfg = newCfg;
    cfg._gen = dirChanged ? ++gen : gen;
    var html = document.documentElement;
    if (!cfg.enabled) {
      html.removeAttribute(ATTR_ON);
      return { ok: true, enabled: false };
    }
    ensureFonts();
    refreshAllStyles();
    html.setAttribute(ATTR_ON, '');
    if (document.body) {
      if (!startedObserving) { startedObserving = true; observe(document.documentElement); enqueueTree(document.body); }
      else if (dirChanged) enqueueTree(document.body);
    }
    return { ok: true, enabled: true };
  }

  function pageLanguage() {
    var lang = (document.documentElement.getAttribute('lang') || '').toLowerCase();
    var sample = (document.body ? document.body.innerText || '' : '').slice(0, 3000);
    return { lang: lang, script: detect(sample), dir: getComputedStyle(document.documentElement).direction };
  }

  function start() {
    var boot = window.__RTLF_BOOT;
    if (!boot) return;
    apply(Object.assign({}, pickConfig(boot), { platform: boot.platform }));
  }

  window.__RTLF = {
    version: 1,
    apply: function (c) { var b = window.__RTLF_BOOT || {}; c.platform = b.platform; return apply(c); },
    reloadBoot: function (boot) { window.__RTLF_BOOT = boot; start(); },
    addFontCss: addFontCss,
    pageLanguage: pageLanguage,
    stats: function () { return { holders: document.querySelectorAll('[' + T + ']').length, blocks: document.querySelectorAll('[' + D + ']').length, queue: queue.length }; },
    _detect: detect
  };

  // Early: inject fonts + stylesheet before first paint to avoid flashes.
  start();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { startedObserving = false; start(); }, { once: true });
  }
  setInterval(guardStyles, 1500);
})();
