/*
 * RTL Browser - Reader Mode
 * Extracts the main article (Readability-style scoring) and renders it in an isolated
 * shadow-DOM overlay ON TOP of the live page. The original page is untouched underneath,
 * so leaving Reader Mode is instant and the site's JS state (login, player, cart) survives.
 */
(function () {
  'use strict';
  if (window.__RTLR) return;

  var HOST_ID = '__rtlr_host';
  var NEG = /comment|meta|footer|footnote|foot|sidebar|sponsor|ad-|ads|advert|promo|related|share|social|nav|menu|header|breadcrumb|popup|modal|cookie|subscribe|newsletter|widget|banner|outbrain|taboola|tags|author-box|pagination/i;
  var POS = /article|body|content|entry|main|page|post|text|blog|story|news|matn|single/i;
  var RTL_RE = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/g;
  var LTR_RE = /[A-Za-z]/g;
  var DROP = 'script,style,noscript,iframe:not([src*="youtube"]):not([src*="aparat"]),form,button,input,select,textarea,nav,aside,footer,header,svg[aria-hidden="true"],[role="navigation"],[role="banner"],[role="complementary"],[aria-hidden="true"],.ad,.ads,.advert,.share,.social,.comments,#comments';

  function classWeight(el) {
    var w = 0, s = (el.className && typeof el.className === 'string' ? el.className : '') + ' ' + (el.id || '');
    if (NEG.test(s)) w -= 25;
    if (POS.test(s)) w += 25;
    return w;
  }
  function linkDensity(el) {
    var t = (el.innerText || '').length || 1, l = 0;
    var as = el.getElementsByTagName('a');
    for (var i = 0; i < as.length; i++) l += (as[i].innerText || '').length;
    return l / t;
  }

  function findMain() {
    var semantic = document.querySelector('article [itemprop="articleBody"], [itemprop="articleBody"], article, main, [role="main"]');
    var candidates = new Map();
    var ps = document.querySelectorAll('p, pre, td, blockquote, li');
    for (var i = 0; i < ps.length; i++) {
      var p = ps[i], text = (p.innerText || '').trim();
      if (text.length < 25) continue;
      var score = 1 + text.split(/[,،؛]/).length + Math.min(Math.floor(text.length / 100), 3);
      var parent = p.parentElement, grand = parent && parent.parentElement;
      [[parent, 1], [grand, 2]].forEach(function (pair) {
        var c = pair[0];
        if (!c || c === document.body) return;
        if (!candidates.has(c)) candidates.set(c, classWeight(c) + ({ ARTICLE: 10, MAIN: 8, SECTION: 3, DIV: 5 }[c.tagName] || 0));
        candidates.set(c, candidates.get(c) + score / pair[1]);
      });
    }
    var best = null, bestScore = 0;
    candidates.forEach(function (s, el) {
      var adj = s * (1 - linkDensity(el));
      if (adj > bestScore) { bestScore = adj; best = el; }
    });
    if (semantic && (!best || semantic.contains(best) || (semantic.innerText || '').length > (best.innerText || '').length * 0.8)) {
      if ((semantic.innerText || '').length > 300) return semantic;
    }
    return best;
  }

  function absolutize(root) {
    root.querySelectorAll('a[href]').forEach(function (a) { a.href = a.href; a.target = '_top'; });
    root.querySelectorAll('img').forEach(function (img) {
      var src = img.currentSrc || img.src || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original');
      if (src) img.src = new URL(src, location.href).href;
      img.removeAttribute('srcset'); img.removeAttribute('loading'); img.removeAttribute('width'); img.removeAttribute('height');
      img.removeAttribute('style');
    });
  }

  function clean(root) {
    root.querySelectorAll(DROP).forEach(function (n) { n.remove(); });
    root.querySelectorAll('*').forEach(function (n) {
      for (var i = n.attributes.length - 1; i >= 0; i--) {
        var a = n.attributes[i].name;
        if (a === 'href' || a === 'src' || a === 'alt' || a === 'title' || a === 'colspan' || a === 'rowspan' || a === 'dir' || a === 'lang' || a === 'allowfullscreen') continue;
        n.removeAttribute(a);
      }
      var tl = (n.innerText || n.textContent || '').trim();
      if (/^(DIV|SECTION|SPAN)$/.test(n.tagName) && !tl && !n.querySelector('img,video,iframe,figure')) n.remove();
    });
    root.querySelectorAll('div,section').forEach(function (n) {
      if (linkDensity(n) > 0.5 && (n.innerText || '').length < 400) n.remove();
    });
  }

  function detectDir(text) {
    var r = (text.match(RTL_RE) || []).length, l = (text.match(LTR_RE) || []).length;
    return r >= l * 0.6 ? 'rtl' : 'ltr';
  }

  function meta(name) {
    var m = document.querySelector('meta[property="' + name + '"], meta[name="' + name + '"]');
    return m ? m.getAttribute('content') : '';
  }

  function extract() {
    var main = findMain();
    if (!main) return null;
    var clone = main.cloneNode(true);
    clone.querySelectorAll('[data-rtlf],[data-rtlf-d],[data-rtlf-l],[data-rtlf-x],[data-rtlf-b],[data-rtlf-c]').forEach(function (n) {
      ['data-rtlf', 'data-rtlf-d', 'data-rtlf-l', 'data-rtlf-x', 'data-rtlf-b', 'data-rtlf-c'].forEach(function (a) { n.removeAttribute(a); });
    });
    absolutize(clone);
    clean(clone);
    var h1 = clone.querySelector('h1');
    var title = meta('og:title') || document.title || (h1 ? (h1.textContent || '').trim() : '');
    if (h1 && (h1.textContent || '').trim() === title.trim()) h1.remove();
    var text = clone.innerText || clone.textContent || '';
    var words = text.split(/\s+/).filter(Boolean).length;
    return {
      title: title,
      site: meta('og:site_name') || location.hostname.replace(/^www\./, ''),
      byline: meta('author') || meta('article:author') || '',
      node: clone,
      text: text,
      dir: detectDir(title + ' ' + text.slice(0, 2000)),
      minutes: Math.max(1, Math.round(words / 200))
    };
  }

  var THEMES = {
    light: { bg: '#ffffff', fg: '#1d1d1f', muted: '#6e6e73', link: '#0a66c2', rule: '#e5e5ea' },
    dark: { bg: '#121214', fg: '#e8e8ea', muted: '#9a9aa0', link: '#7ab7ff', rule: '#2a2a2e' },
    sepia: { bg: '#f4ecd8', fg: '#433422', muted: '#7a6a55', link: '#8a4b0f', rule: '#e2d6bb' },
    black: { bg: '#000000', fg: '#d6d6d6', muted: '#8a8a8a', link: '#7ab7ff', rule: '#222' }
  };
  var WIDTHS = { narrow: '32em', medium: '40em', wide: '52em', full: '100%' };

  function css(o) {
    var t = o.theme === 'custom' ? { bg: o.customBg || '#fff', fg: o.customFg || '#111', muted: '#888', link: o.customFg || '#06c', rule: 'rgba(127,127,127,.25)' } : (THEMES[o.theme] || THEMES.light);
    return ':host{all:initial}' +
      '.wrap{position:fixed;inset:0;z-index:2147483647;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;background:' + t.bg + ';color:' + t.fg + ';}' +
      '.col{box-sizing:border-box;max-width:' + (WIDTHS[o.width] || WIDTHS.medium) + ';margin:0 auto;padding:28px 20px calc(120px + env(safe-area-inset-bottom));' +
      'font-family:' + (o.fontFamily || 'system-ui,sans-serif') + ';font-size:' + (o.fontSizePx || 18) + 'px;line-height:' + (o.lineHeight || 1.8) + ';font-weight:' + (o.weight || 400) + ';' +
      'letter-spacing:' + (o.dir === 'ltr' && o.letterSpacing ? o.letterSpacing + 'em' : 'normal') + ';text-align:' + (o.justify ? 'justify' : 'start') + ';-webkit-user-select:text;user-select:text;}' +
      '.site{font-size:.8em;color:' + t.muted + ';margin-bottom:.4em}' +
      'h1.t{font-size:1.6em;line-height:1.35;margin:0 0 .3em;font-weight:' + Math.max(700, o.weight || 400) + '}' +
      '.by{color:' + t.muted + ';font-size:.85em;margin-bottom:1.6em;padding-bottom:1em;border-bottom:1px solid ' + t.rule + '}' +
      'p,li,blockquote{margin:0 0 ' + (o.paragraphSpacing || 1) + 'em}' +
      'h2,h3,h4{line-height:1.4;margin:1.4em 0 .5em}' +
      'a{color:' + t.link + ';text-decoration:none;border-bottom:1px solid currentColor}' +
      'img,video,iframe,figure{max-width:100%;height:auto;border-radius:10px;display:block;margin:1em auto}' +
      'figcaption{font-size:.8em;color:' + t.muted + ';text-align:center}' +
      'blockquote{border-inline-start:3px solid ' + t.rule + ';padding-inline-start:1em;color:' + t.muted + '}' +
      'pre,code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.85em;direction:ltr;text-align:left;unicode-bidi:isolate}' +
      'pre{overflow-x:auto;background:' + t.rule + ';padding:12px;border-radius:8px}' +
      'table{border-collapse:collapse;max-width:100%;display:block;overflow-x:auto}td,th{border:1px solid ' + t.rule + ';padding:6px}' +
      'p,li,h1,h2,h3,h4,blockquote,td{unicode-bidi:plaintext}';
  }

  var host = null, root = null, lastData = null, lastOpts = null;

  function open(opts) {
    lastOpts = opts || lastOpts || {};
    if (!lastData) lastData = extract();
    if (!lastData) return { ok: false, reason: 'no-article' };
    if (!host) {
      host = document.createElement('div');
      host.id = HOST_ID;
      root = host.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host);
    }
    var dir = lastOpts.direction === 'rtl' ? 'rtl' : lastOpts.direction === 'ltr' ? 'ltr' : lastData.dir;
    lastOpts.dir = dir;
    // @font-face is ignored inside shadow roots in Chromium, so fonts are registered on the document.
    if (lastOpts.fontFaceCss) {
      if (window.__RTLF && window.__RTLF.addFontCss) window.__RTLF.addFontCss(lastOpts.fontFaceCss);
      else {
        var ff = document.getElementById('__rtlr_fonts');
        if (!ff) { ff = document.createElement('style'); ff.id = '__rtlr_fonts'; (document.head || document.documentElement).appendChild(ff); }
        if (ff.textContent !== lastOpts.fontFaceCss) ff.textContent = lastOpts.fontFaceCss;
      }
    }
    // Built with DOM APIs only (no innerHTML): works on Trusted-Types / strict-CSP sites.
    while (root.firstChild) root.removeChild(root.firstChild);
    var cssText = css(lastOpts);
    if (window.CSSStyleSheet && CSSStyleSheet.prototype.replaceSync && 'adoptedStyleSheets' in ShadowRoot.prototype) {
      var sh = new CSSStyleSheet(); sh.replaceSync(cssText); root.adoptedStyleSheets = [sh];
    } else {
      var st = document.createElement('style'); st.textContent = cssText; root.appendChild(st);
    }
    function el(tag, cls, parent) { var e = document.createElement(tag); if (cls) e.className = cls; parent.appendChild(e); return e; }
    var wrapEl = el('div', 'wrap', root);
    var art = el('article', 'col', wrapEl);
    art.setAttribute('dir', dir);
    art.setAttribute('lang', dir === 'rtl' ? 'fa' : 'en');
    el('div', 'site', art).textContent = lastData.site;
    el('h1', 't', art).textContent = lastData.title;
    el('div', 'by', art).textContent = [lastData.byline, (dir === 'rtl' ? '\u200F' + lastData.minutes + ' دقیقه مطالعه' : lastData.minutes + ' min read')].filter(Boolean).join(' · ');
    el('div', 'body', art).appendChild(lastData.node.cloneNode(true));
    host.style.display = 'block';
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
    return { ok: true, title: lastData.title, minutes: lastData.minutes };
  }

  function update(opts) { if (host && host.style.display !== 'none') { var y = root.querySelector('.wrap').scrollTop; open(opts); root.querySelector('.wrap').scrollTop = y; } }

  function close() {
    if (host) host.style.display = 'none';
    document.documentElement.style.removeProperty('overflow');
    return { ok: true };
  }

  function selection() {
    var s = (root && root.getSelection) ? root.getSelection() : null;
    var t = s ? String(s) : '';
    if (!t) t = String(window.getSelection() || '');
    return t;
  }

  window.__RTLR = {
    probe: function () { var d = extract(); lastData = d; return d ? { ok: true, minutes: d.minutes, length: d.text.length } : { ok: false }; },
    open: open, update: update, close: close,
    isOpen: function () { return !!(host && host.style.display !== 'none'); },
    text: function () { return lastData ? lastData.title + '\n\n' + lastData.text : ''; },
    selection: selection,
    invalidate: function () { lastData = null; }
  };
})();
