#!/usr/bin/env bash
# Runs the text-engine and reader tests in headless Chromium. Usage: CHROME=/path/to/chrome ./run_js_tests.sh
set -euo pipefail
cd "$(dirname "$0")"
CHROME="${CHROME:-$(command -v chromium || command -v google-chrome || command -v chromium-browser)}"
run() { "$CHROME" --headless=new --no-sandbox --disable-gpu --allow-file-access-from-files --virtual-time-budget=6000 --dump-dom "file://$PWD/$1" 2>/dev/null \
  | python3 -c "import sys,re,html;s=sys.stdin.read();m=re.search(r'<pre id=\"result\">(.*?)</pre>',s,re.S);print(html.unescape(m.group(1)) if m else 'NO RESULT')"; }
echo "== engine_test.html";  run engine_test.html
echo "== perf_reader_test.html"; run perf_reader_test.html
echo "== csp_test.html"; run csp_test.html
