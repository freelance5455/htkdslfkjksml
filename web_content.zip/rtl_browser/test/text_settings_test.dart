import 'package:flutter_test/flutter_test.dart';
import 'package:rtl_browser/site_prefs/site_prefs_store.dart';
import 'package:rtl_browser/text_engine/text_settings.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('TextSettings JSON round-trip and equality', () {
    const t = TextSettings(fontId: 'estedad', textScale: 115, direction: 'rtl', lineHeight: 2.0, readerTheme: 'sepia');
    final back = TextSettings.fromJson(t.toJson());
    expect(back, t);
    expect(back.copyWith(textScale: 100) == t, isFalse);
  });

  test('fromJson tolerates bad / missing data', () {
    final t = TextSettings.fromJson({'textScale': 9999, 'fontId': 3, 'lineHeight': 2});
    expect(t.textScale, 250);
    expect(t.fontId, 'vazirmatn');
    expect(t.lineHeight, 2.0);
  });

  test('site prefs: parent domain fallback, reset, persistence', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final store = SitePrefsStore(prefs);
    store.set('wikipedia.org', const TextSettings(textScale: 110, direction: 'rtl'));
    expect(store.get('fa.m.wikipedia.org')?.textScale, 110);
    expect(store.get('example.com'), isNull);
    final reloaded = SitePrefsStore(prefs);
    expect(reloaded.get('wikipedia.org')?.direction, 'rtl');
    reloaded.reset('fa.wikipedia.org');
    expect(reloaded.get('wikipedia.org'), isNull);
  });
}
