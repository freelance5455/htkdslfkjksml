import 'package:flutter_test/flutter_test.dart';
import 'package:rtl_browser/core/url_utils.dart';

void main() {
  group('UrlUtils.resolve', () {
    test('bare domains become https', () {
      expect(UrlUtils.resolve('wikipedia.org'), 'https://wikipedia.org');
      expect(UrlUtils.resolve('fa.wikipedia.org/wiki/ایران'), 'https://fa.wikipedia.org/wiki/ایران');
      expect(UrlUtils.resolve('example.com:8080/x'), 'https://example.com:8080/x');
    });
    test('full URLs pass through', () {
      expect(UrlUtils.resolve('https://google.com'), 'https://google.com');
      expect(UrlUtils.resolve('http://a.b'), 'http://a.b');
    });
    test('localhost and IPs use http', () {
      expect(UrlUtils.resolve('localhost:3000'), 'http://localhost:3000');
      expect(UrlUtils.resolve('192.168.1.1'), 'http://192.168.1.1');
    });
    test('everything else is a Google search', () {
      expect(UrlUtils.resolve('هوا امروز'), UrlUtils.searchUrl('هوا امروز'));
      expect(UrlUtils.resolve('flutter'), UrlUtils.searchUrl('flutter'));
      expect(UrlUtils.resolve('what is a.b'), UrlUtils.searchUrl('what is a.b'));
    });
    test('empty is home', () => expect(UrlUtils.resolve('  '), UrlUtils.homeUrl));
  });

  test('host strips www', () {
    expect(UrlUtils.host('https://www.BBC.com/persian'), 'bbc.com');
  });

  test('googleQuery extracts the query', () {
    expect(UrlUtils.googleQuery(UrlUtils.searchUrl('سلام دنیا')), 'سلام دنیا');
    expect(UrlUtils.googleQuery('https://example.com/search?q=x'), isNull);
  });

  test('fileNameFor', () {
    expect(UrlUtils.fileNameFor('https://x.com/a/b/report.pdf'), 'report.pdf');
    expect(UrlUtils.fileNameFor('https://x.com/dl', contentDisposition: 'attachment; filename="r 1.zip"'), 'r 1.zip');
    expect(UrlUtils.fileNameFor('https://x.com/dl', contentDisposition: "attachment; filename*=UTF-8''%D9%81%D8%A7%DB%8C%D9%84.txt"), 'فایل.txt');
    expect(UrlUtils.fileNameFor('https://x.com/get', mime: 'application/pdf'), 'get.pdf');
  });

  test('intent fallback', () {
    expect(UrlUtils.intentFallback('intent://x#Intent;scheme=foo;S.browser_fallback_url=https%3A%2F%2Fa.com;end'), 'https://a.com');
  });
}
