import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../text_engine/text_settings.dart';

class Preset {
  const Preset({required this.id, required this.name, required this.settings});
  final String id;
  final String name;
  final TextSettings settings;
  Preset copyWith({String? name, TextSettings? settings}) =>
      Preset(id: id, name: name ?? this.name, settings: settings ?? this.settings);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'settings': settings.toJson()};
  static Preset fromJson(Map<String, dynamic> j) =>
      Preset(id: j['id'], name: j['name'], settings: TextSettings.fromJson(Map<String, dynamic>.from(j['settings'])));
}

class PresetStore extends ChangeNotifier {
  PresetStore(this._prefs) {
    final raw = _prefs.getString(_key);
    if (raw == null) {
      _list.addAll(_defaults);
      _save();
    } else {
      _list.addAll((jsonDecode(raw) as List).map((e) => Preset.fromJson(Map<String, dynamic>.from(e))));
    }
  }
  final SharedPreferences _prefs;
  static const _key = 'presets';
  final List<Preset> _list = [];

  static const _defaults = [
    Preset(id: 'fa_reading', name: 'مطالعه فارسی', settings: TextSettings(
        fontId: 'vazirmatn', direction: 'rtl', textScale: 115, lineHeight: 2.0, paragraphSpacing: 1.0, readerTheme: 'sepia')),
    Preset(id: 'en_reading', name: 'مطالعه انگلیسی', settings: TextSettings(
        fontId: 'inter', direction: 'ltr', textScale: 100, lineHeight: 1.6)),
    Preset(id: 'night', name: 'شب', settings: TextSettings(
        fontId: 'vazirmatn', direction: 'auto', textScale: 110, lineHeight: 1.9, readerTheme: 'black')),
  ];

  List<Preset> get all => List.unmodifiable(_list);
  Preset? byId(String? id) => _list.where((p) => p.id == id).firstOrNull;

  Preset add(String name, TextSettings s) {
    final p = Preset(id: 'p${DateTime.now().microsecondsSinceEpoch}', name: name, settings: s);
    _list.add(p);
    _save();
    return p;
  }

  void update(Preset p) {
    final i = _list.indexWhere((e) => e.id == p.id);
    if (i >= 0) { _list[i] = p; _save(); }
  }

  void remove(String id) { _list.removeWhere((e) => e.id == id); _save(); }

  void _save() {
    notifyListeners();
    _prefs.setString(_key, jsonEncode(_list.map((e) => e.toJson()).toList()));
  }
}
