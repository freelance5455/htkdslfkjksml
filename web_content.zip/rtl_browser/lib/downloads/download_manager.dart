import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../core/db.dart';
import '../core/url_utils.dart';

enum DownloadStatus { queued, running, done, failed, canceled }

class DownloadItem {
  DownloadItem({
    required this.id, required this.url, required this.fileName, this.path, this.mime,
    this.total = 0, this.received = 0, this.status = DownloadStatus.queued, this.error, required this.createdAt,
  });
  final int id;
  final String url;
  String fileName;
  String? path;
  String? mime;
  int total;
  int received;
  DownloadStatus status;
  String? error;
  final DateTime createdAt;

  double? get progress => total > 0 ? received / total : null;

  static DownloadItem fromRow(Map<String, Object?> r) => DownloadItem(
        id: r['id'] as int, url: r['url'] as String, fileName: r['file_name'] as String,
        path: r['path'] as String?, mime: r['mime'] as String?, total: (r['total'] as int?) ?? 0,
        received: (r['received'] as int?) ?? 0,
        status: DownloadStatus.values.firstWhere((s) => s.name == r['status'], orElse: () => DownloadStatus.failed),
        error: r['error'] as String?, createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int));
}

/// In-app download manager. Uses the WebView's cookies + UA so logged-in downloads work.
/// Handles http(s), data: and blob: URLs. Files go to the app's Downloads directory and can be
/// opened or shared (Share -> "Save to Files/Drive") from the Downloads screen.
class DownloadManager extends ChangeNotifier {
  DownloadManager(this._db);
  final AppDatabase _db;
  final List<DownloadItem> _items = [];
  final Map<int, HttpClient> _clients = {};
  final Map<int, StreamSubscription> _subs = {};

  List<DownloadItem> get items => List.unmodifiable(_items);
  int get activeCount => _items.where((i) => i.status == DownloadStatus.running).length;

  Future<void> init() async {
    final rows = await _db.db.query('downloads', orderBy: 'created_at DESC', limit: 300);
    _items.addAll(rows.map(DownloadItem.fromRow));
    // Anything "running" when the app was killed is now failed (can be retried).
    for (final i in _items.where((i) => i.status == DownloadStatus.running || i.status == DownloadStatus.queued)) {
      i.status = DownloadStatus.failed;
      i.error = 'متوقف شد';
      await _persist(i);
    }
  }

  Future<Directory> _dir() async {
    Directory? d;
    try { d = await getDownloadsDirectory(); } catch (_) {}
    d ??= Directory(p.join((await getApplicationDocumentsDirectory()).path, 'Downloads'));
    await d.create(recursive: true);
    return d;
  }

  Future<String> _uniquePath(String name) async {
    final dir = await _dir();
    var candidate = p.join(dir.path, name);
    var n = 1;
    final base = p.basenameWithoutExtension(name), ext = p.extension(name);
    while (await File(candidate).exists()) {
      candidate = p.join(dir.path, '$base ($n)$ext');
      n++;
    }
    return candidate;
  }

  Future<DownloadItem> _create(String url, String name, String? mime, int total) async {
    final now = DateTime.now();
    final id = await _db.db.insert('downloads', {
      'url': url.length > 2000 ? url.substring(0, 2000) : url, 'file_name': name, 'mime': mime,
      'total': total, 'received': 0, 'status': DownloadStatus.queued.name, 'created_at': now.millisecondsSinceEpoch,
    });
    final item = DownloadItem(id: id, url: url, fileName: name, mime: mime, total: total, createdAt: now);
    _items.insert(0, item);
    notifyListeners();
    return item;
  }

  /// Entry point from WebView.onDownloadStartRequest.
  Future<DownloadItem?> enqueue(DownloadStartRequest req, {InAppWebViewController? controller, String? referer}) async {
    final url = req.url.toString();
    final name = UrlUtils.fileNameFor(url,
        contentDisposition: req.contentDisposition, suggested: req.suggestedFilename, mime: req.mimeType);
    if (url.startsWith('data:')) return _saveDataUrl(url, name, req.mimeType);
    if (url.startsWith('blob:') && controller != null) return _saveBlob(controller, url, name, req.mimeType);
    final item = await _create(url, name, req.mimeType, req.contentLength);
    unawaited(_run(item, userAgent: req.userAgent, referer: referer));
    return item;
  }

  Future<void> retry(DownloadItem item) async {
    item.status = DownloadStatus.queued;
    item.received = 0;
    item.error = null;
    notifyListeners();
    await _run(item);
  }

  Future<void> _run(DownloadItem item, {String? userAgent, String? referer}) async {
    final client = HttpClient()..userAgent = userAgent;
    _clients[item.id] = client;
    try {
      final uri = Uri.parse(item.url);
      final req = await client.getUrl(uri);
      final cookies = await CookieManager.instance().getCookies(url: WebUri(item.url));
      if (cookies.isNotEmpty) {
        req.headers.set(HttpHeaders.cookieHeader, cookies.map((c) => '${c.name}=${c.value}').join('; '));
      }
      if (referer != null) req.headers.set(HttpHeaders.refererHeader, referer);
      final res = await req.close();
      if (res.statusCode >= 400) throw HttpException('HTTP ${res.statusCode}');
      final cd = res.headers.value('content-disposition');
      if (cd != null) {
        item.fileName = UrlUtils.fileNameFor(item.url, contentDisposition: cd, mime: item.mime);
      }
      item.total = res.contentLength > 0 ? res.contentLength : item.total;
      item.path = await _uniquePath(item.fileName);
      item.fileName = p.basename(item.path!);
      item.status = DownloadStatus.running;
      await _persist(item);
      final sink = File(item.path!).openWrite();
      var lastNotify = DateTime.now();
      final done = Completer<void>();
      _subs[item.id] = res.listen((chunk) {
        sink.add(chunk);
        item.received += chunk.length;
        final now = DateTime.now();
        if (now.difference(lastNotify).inMilliseconds > 250) { lastNotify = now; notifyListeners(); }
      }, onDone: () async {
        await sink.close();
        if (item.status == DownloadStatus.running) item.status = DownloadStatus.done;
        done.complete();
      }, onError: (Object e) async {
        await sink.close();
        if (item.status != DownloadStatus.canceled) { item.status = DownloadStatus.failed; item.error = '$e'; }
        done.complete();
      }, cancelOnError: true);
      await done.future;
    } catch (e) {
      if (item.status != DownloadStatus.canceled) {
        item.status = DownloadStatus.failed;
        item.error = e.toString();
      }
    } finally {
      _clients.remove(item.id)?.close(force: true);
      _subs.remove(item.id);
      await _persist(item);
      notifyListeners();
    }
  }

  Future<DownloadItem> _saveBytes(String url, String name, String? mime, List<int> bytes) async {
    final item = await _create(url.startsWith('data:') ? 'data:' : url, name, mime, bytes.length);
    item.path = await _uniquePath(name);
    item.fileName = p.basename(item.path!);
    await File(item.path!).writeAsBytes(bytes, flush: true);
    item.received = bytes.length;
    item.status = DownloadStatus.done;
    await _persist(item);
    notifyListeners();
    return item;
  }

  Future<DownloadItem?> _saveDataUrl(String url, String name, String? mime) async {
    final data = UriData.parse(url);
    return _saveBytes(url, name, mime ?? data.mimeType, data.contentAsBytes());
  }

  /// blob: URLs only exist inside the page, so we read them from JS.
  Future<DownloadItem?> _saveBlob(InAppWebViewController c, String url, String name, String? mime) async {
    final res = await c.callAsyncJavaScript(functionBody: '''
      const r = await fetch(url); const b = await r.blob();
      return await new Promise((ok, err) => { const fr = new FileReader();
        fr.onload = () => ok(String(fr.result).split(',')[1] || ''); fr.onerror = err; fr.readAsDataURL(b); });
    ''', arguments: {'url': url});
    final b64 = res?.value;
    if (b64 is! String || b64.isEmpty) return null;
    return _saveBytes(url, name, mime, base64Decode(b64));
  }

  Future<void> cancel(DownloadItem item) async {
    item.status = DownloadStatus.canceled;
    await _subs.remove(item.id)?.cancel();
    _clients.remove(item.id)?.close(force: true);
    if (item.path != null) { try { await File(item.path!).delete(); } catch (_) {} }
    await _persist(item);
    notifyListeners();
  }

  Future<void> remove(DownloadItem item, {bool deleteFile = true}) async {
    if (item.status == DownloadStatus.running) await cancel(item);
    if (deleteFile && item.path != null) { try { await File(item.path!).delete(); } catch (_) {} }
    await _db.db.delete('downloads', where: 'id = ?', whereArgs: [item.id]);
    _items.remove(item);
    notifyListeners();
  }

  Future<void> clearFinished() async {
    final ids = _items.where((i) => i.status != DownloadStatus.running).map((i) => i.id).toList();
    for (final id in ids) { await _db.db.delete('downloads', where: 'id = ?', whereArgs: [id]); }
    _items.removeWhere((i) => ids.contains(i.id));
    notifyListeners();
  }

  Future<OpenResult?> open(DownloadItem item) async =>
      item.path == null ? null : OpenFilex.open(item.path!, type: item.mime);

  Future<void> _persist(DownloadItem i) => _db.db.update('downloads', {
        'file_name': i.fileName, 'path': i.path, 'total': i.total, 'received': i.received,
        'status': i.status.name, 'error': i.error,
      }, where: 'id = ?', whereArgs: [i.id]);

  @override
  void dispose() {
    for (final c in _clients.values) { c.close(force: true); }
    super.dispose();
  }
}
