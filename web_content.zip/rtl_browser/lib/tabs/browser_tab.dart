import 'package:flutter/foundation.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../core/url_utils.dart';

/// State of one tab. The live WebView controller is attached only while the tab is "alive"
/// (see TabManager.maxAlive); hibernated tabs keep just their URL/title and reload on demand.
class BrowserTab extends ChangeNotifier {
  BrowserTab({
    required this.id,
    String url = UrlUtils.homeUrl,
    String title = '',
    this.incognito = false,
    this.windowId,
    this.openerId,
    this.faviconUrl,
  })  : _url = url,
        _title = title,
        showHome = url == UrlUtils.homeUrl;

  final String id;
  final bool incognito;
  /// Set when the page opened this tab via window.open / target=_blank.
  final int? windowId;
  final String? openerId;

  String _url;
  String _title;
  String? faviconUrl;
  int progress = 100;
  bool canGoBack = false;
  bool canGoForward = false;
  bool showHome;
  bool readerAvailable = false;
  bool readerOpen = false;
  bool desktopMode = false;
  bool findOpen = false;
  /// Main-frame load error (shown with our own error view instead of the WebView's).
  String? error;
  int? lastTextZoom;
  /// window.open() targets can only be attached once; after hibernation we reload by URL.
  bool windowUsed = false;
  int findMatches = 0;
  int findActive = 0;
  /// Font id whose @font-face is already in the current document.
  String? fontInPage;
  DateTime lastActive = DateTime.now();

  InAppWebViewController? controller;
  FindInteractionController? findController;
  /// URL to load when the WebView is (re)created.
  String? pendingUrl;

  String get url => _url;
  String get title => _title;
  String get host => UrlUtils.host(_url);
  bool get hasWebView => controller != null;
  bool get isHomeOnly => _url == UrlUtils.homeUrl;

  set url(String v) { if (v == _url) return; _url = v; notifyListeners(); }
  set title(String v) { if (v == _title) return; _title = v; notifyListeners(); }

  void touch() => notifyListeners();

  Future<void> load(String url) async {
    showHome = false;
    readerOpen = false;
    final c = controller;
    if (c == null) {
      pendingUrl = url;
      _url = url;
    } else {
      await c.loadUrl(urlRequest: URLRequest(url: WebUri(url)));
    }
    notifyListeners();
  }

  Map<String, dynamic> toJson() => {'id': id, 'url': _url, 'title': _title, 'favicon': faviconUrl};
}
