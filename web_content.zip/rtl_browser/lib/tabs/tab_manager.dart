import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/url_utils.dart';
import 'browser_tab.dart';

class ClosedTab {
  ClosedTab(this.url, this.title, this.index);
  final String url;
  final String title;
  final int index;
}

/// Owns the tab list, active tab, recently-closed stack and session persistence.
/// Memory policy: at most [maxAlive] WebViews exist at once (LRU). Others are hibernated
/// and transparently reloaded when the user switches back.
class TabManager extends ChangeNotifier {
  TabManager(this._prefs);
  final SharedPreferences _prefs;
  static const _key = 'session_tabs';
  static const maxAlive = 4;

  final List<BrowserTab> _tabs = [];
  final List<ClosedTab> _closed = [];
  final List<String> _aliveLru = [];
  int _active = 0;
  int _seq = 0;

  List<BrowserTab> get tabs => List.unmodifiable(_tabs);
  List<BrowserTab> get normalTabs => _tabs.where((t) => !t.incognito).toList();
  List<BrowserTab> get incognitoTabs => _tabs.where((t) => t.incognito).toList();
  List<ClosedTab> get recentlyClosed => List.unmodifiable(_closed.reversed);
  BrowserTab get active => _tabs[_active];
  int get activeIndex => _active;
  Set<String> get aliveIds => _aliveLru.toSet();

  String _newId() => 't${DateTime.now().microsecondsSinceEpoch}_${_seq++}';

  void restore({required bool restoreSession}) {
    if (restoreSession) {
      final raw = _prefs.getString(_key);
      if (raw != null) {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        for (final t in (j['tabs'] as List)) {
          _tabs.add(BrowserTab(id: _newId(), url: t['url'] ?? UrlUtils.homeUrl, title: t['title'] ?? '', faviconUrl: t['favicon']));
        }
        _active = ((j['active'] as int?) ?? 0).clamp(0, _tabs.isEmpty ? 0 : _tabs.length - 1);
      }
    }
    if (_tabs.isEmpty) _tabs.add(BrowserTab(id: _newId()));
    _markAlive(active);
  }

  void _markAlive(BrowserTab t) {
    t.lastActive = DateTime.now();
    if (t.isHomeOnly && t.pendingUrl == null && !t.hasWebView && t.windowId == null) return; // home page needs no WebView
    _aliveLru.remove(t.id);
    _aliveLru.add(t.id);
    while (_aliveLru.length > maxAlive) {
      final evict = _tabs.where((x) => x.id == _aliveLru.first).firstOrNull;
      _aliveLru.removeAt(0);
      if (evict != null) _hibernate(evict);
    }
  }

  void _hibernate(BrowserTab t) {
    t.pendingUrl = t.isHomeOnly ? null : t.url;
    if (t.windowId != null) t.windowUsed = true;
    t.controller = null;
    t.readerOpen = false;
  }

  /// Called when a home tab starts navigating and needs a WebView.
  void ensureAlive(BrowserTab t) { _markAlive(t); notifyListeners(); }

  BrowserTab open({String? url, bool incognito = false, int? windowId, String? openerId, bool background = false}) {
    final insertAt = openerId != null ? (_tabs.indexWhere((t) => t.id == openerId) + 1).clamp(0, _tabs.length) : _tabs.length;
    final tab = BrowserTab(id: _newId(), url: url ?? UrlUtils.homeUrl, incognito: incognito, windowId: windowId, openerId: openerId);
    if (url != null && url != UrlUtils.homeUrl) { tab.pendingUrl = url; tab.showHome = false; }
    if (windowId != null) tab.showHome = false;
    _tabs.insert(insertAt, tab);
    if (!background) {
      _active = insertAt;
      _markAlive(tab);
    } else if (insertAt <= _active) {
      _active++;
    }
    if (windowId != null && background) _markAlive(tab); // popup windows need their WebView immediately
    _changed();
    return tab;
  }

  void select(int index) {
    if (index < 0 || index >= _tabs.length) return;
    _active = index;
    _markAlive(_tabs[index]);
    _changed();
  }

  void selectTab(BrowserTab t) => select(_tabs.indexOf(t));

  void close(BrowserTab t) {
    final i = _tabs.indexOf(t);
    if (i < 0) return;
    if (!t.incognito && !t.isHomeOnly) {
      _closed.add(ClosedTab(t.url, t.title, i));
      if (_closed.length > 25) _closed.removeAt(0);
    }
    _tabs.removeAt(i);
    _aliveLru.remove(t.id);
    t.controller = null;
    if (_tabs.isEmpty) _tabs.add(BrowserTab(id: _newId()));
    // return to opener if we closed the active popup tab
    if (i == _active) {
      final opener = t.openerId == null ? -1 : _tabs.indexWhere((x) => x.id == t.openerId);
      _active = opener >= 0 ? opener : (i - 1).clamp(0, _tabs.length - 1);
    } else if (i < _active) {
      _active--;
    }
    _markAlive(active);
    _changed();
  }

  void closeAll({bool incognitoOnly = false}) {
    for (final t in _tabs.where((t) => !incognitoOnly || t.incognito).toList()) {
      if (!t.incognito && !t.isHomeOnly) _closed.add(ClosedTab(t.url, t.title, 0));
      _tabs.remove(t);
      _aliveLru.remove(t.id);
    }
    if (_tabs.isEmpty) _tabs.add(BrowserTab(id: _newId()));
    _active = _active.clamp(0, _tabs.length - 1);
    _markAlive(active);
    _changed();
  }

  BrowserTab? reopenClosed([ClosedTab? which]) {
    if (_closed.isEmpty) return null;
    final c = which ?? _closed.last;
    _closed.remove(c);
    return open(url: c.url);
  }

  void reorder(int from, int to) {
    final activeTab = active;
    final t = _tabs.removeAt(from);
    _tabs.insert(to > from ? to - 1 : to, t);
    _active = _tabs.indexOf(activeTab);
    _changed();
  }

  void _changed() { notifyListeners(); save(); }

  /// Incognito tabs are never written to disk.
  void save() {
    final normal = normalTabs;
    final act = normal.indexOf(active);
    _prefs.setString(_key, jsonEncode({'active': act < 0 ? 0 : act, 'tabs': normal.map((t) => t.toJson()).toList()}));
  }
}
