import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../text_engine/text_settings.dart';

/// Per-site text settings, keyed by host without "www.". Sub-domains fall back to the parent
/// domain (m.wikipedia.org -> wikipedia.org), mirroring the lookup in text_engine.js.
class SitePrefsStore extends ChangeNotifier {
  SitePrefsStore(this._prefs) {
    final raw = _prefs.getString(_key);
    if (raw != null) {
      (jsonDecode(raw) as Map).forEach((k, v) => _map[k as String] = TextSettings.fromJson(Map<String, dynamic>.from(v)));
    }
  }
  final SharedPreferences _prefs;
  static const _key = 'site_prefs';
  final Map<String, TextSettings> _map = {};

  Map<String, TextSettings> get all => Map.unmodifiable(_map);

  /// Returns the key that matches [host] (exact or parent domain), or null.
  String? matchKey(String host) {
    if (host.isEmpty) return null;
    if (_map.containsKey(host)) return host;
    final parts = host.split('.');
    while (parts.length > 2) {
      parts.removeAt(0);
      final k = parts.join('.');
      if (_map.containsKey(k)) return k;
    }
    return null;
  }

  TextSettings? get(String host) {
    final k = matchKey(host);
    return k == null ? null : _map[k];
  }

  void set(String host, TextSettings t) {
    if (host.isEmpty) return;
    _map[matchKey(host) ?? host] = t;
    _save();
  }

  void reset(String host) {
    final k = matchKey(host);
    if (k == null) return;
    _map.remove(k);
    _save();
  }

  void clear() { _map.clear(); _save(); }

  void _save() {
    notifyListeners();
    _prefs.setString(_key, jsonEncode(_map.map((k, v) => MapEntry(k, v.toJson()))));
  }
}
