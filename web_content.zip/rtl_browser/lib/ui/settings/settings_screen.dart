import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';

import '../../app/services.dart';
import '../../downloads/download_manager.dart';
import '../../fonts/font_manager.dart';
import '../../history/history_repo.dart';
import '../../presets/preset_store.dart';
import '../../settings/app_settings.dart';
import '../../site_prefs/site_prefs_store.dart';
import '../../tabs/tab_manager.dart';
import '../../text_engine/text_settings.dart';
import '../downloads_screen.dart';
import '../text_controls.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget entry(IconData i, String t, String sub, Widget page) => ListTile(
          leading: Icon(i), title: Text(t), subtitle: Text(sub),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
        );
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListView(children: [
        entry(Icons.palette_outlined, 'ظاهر', 'تم روشن/تیره، حالت تیره صفحات', const _AppearancePage()),
        entry(Icons.text_fields, 'متن', 'فونت، اندازه، جهت، فاصله‌ها، حالت مطالعه', const TextSettingsPage()),
        entry(Icons.font_download_outlined, 'فونت‌ها', 'فونت‌های داخلی و افزودن فونت سفارشی', const FontsPage()),
        entry(Icons.tune, 'Presetها', 'ذخیره و مدیریت پروفایل‌های متن', const PresetsPage()),
        entry(Icons.language, 'تنظیمات سایت‌ها', 'تنظیمات ذخیره‌شده برای هر سایت', const SitePrefsPage()),
        entry(Icons.public, 'مرورگر', 'جاوااسکریپت، پاپ‌آپ، نوار ابزار', const _BrowserPage()),
        entry(Icons.tab_outlined, 'تب‌ها', 'بازگردانی جلسه، باز کردن لینک‌ها', const _TabsPage()),
        entry(Icons.shield_outlined, 'حریم خصوصی', 'تاریخچه، کوکی‌ها، پیشنهاد جستجو', const _PrivacyPage()),
        entry(Icons.download_outlined, 'دانلودها', 'مدیریت فایل‌های دانلودشده', const DownloadsScreen()),
        entry(Icons.info_outline, 'درباره', 'نسخه و مجوزها', const _AboutPage()),
      ]),
    );
  }
}

class _AppearancePage extends StatelessWidget {
  const _AppearancePage();
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('ظاهر')),
      body: ListView(children: [
        const SectionHeader('تم برنامه'),
        for (final (m, l) in const [(ThemeMode.system, 'مطابق سیستم'), (ThemeMode.light, 'روشن'), (ThemeMode.dark, 'تیره')])
          RadioListTile<ThemeMode>(value: m, groupValue: s.themeMode, title: Text(l), onChanged: (v) => s.themeMode = v!),
        const SectionHeader('صفحات وب'),
        SwitchListTile(
          title: const Text('حالت تیره خودکار برای سایت‌ها'),
          subtitle: const Text('سایت‌هایی که تم تیره ندارند به‌صورت خودکار تیره می‌شوند (Android 10+).'),
          value: s.webDarkMode, onChanged: (v) => s.update((x) => x.webDarkMode = v)),
      ]),
    );
  }
}

class TextSettingsPage extends StatelessWidget {
  const TextSettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final t = s.text;
    return Scaffold(
      appBar: AppBar(title: const Text('متن'), actions: [
        TextButton(onPressed: () => s.setText(const TextSettings()), child: const Text('پیش‌فرض')),
      ]),
      body: ListView(children: [
        SwitchListTile(
          title: const Text('Text Formatting'),
          subtitle: Text(t.enabled ? 'روشن: فونت، جهت و اندازه روی صفحات اعمال می‌شود' : 'خاموش: سایت‌ها بدون تغییر نمایش داده می‌شوند'),
          value: t.enabled, onChanged: (v) => s.setText(t.copyWith(enabled: v))),
        const Divider(),
        _Preview(t: t),
        TextControls(value: t, onChanged: (v) => s.setText(v)),
        const Padding(
          padding: EdgeInsets.all(20),
          child: Text('این تنظیمات سراسری است. برای یک سایت خاص، در حین مرور از دکمه «Aa» گزینه «فقط این سایت» را انتخاب کنید.'),
        ),
      ]),
    );
  }
}

/// Native preview (uses Vazirmatn bundled for the UI when that font is selected).
class _Preview extends StatelessWidget {
  const _Preview({required this.t});
  final TextSettings t;
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dir = t.direction == 'ltr' ? TextDirection.ltr : TextDirection.rtl;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cs.surfaceContainerHigh, borderRadius: BorderRadius.circular(16)),
      child: Text(
        'متن نمونه برای پیش‌نمایش. The quick brown fox jumps over the lazy dog. ۱۲۳۴۵',
        textDirection: dir,
        style: TextStyle(
          fontFamily: t.fontId == 'vazirmatn' ? 'Vazirmatn' : null,
          fontSize: 16 * t.textScale / 100,
          fontWeight: FontWeight.values[((t.weight / 100).round() - 1).clamp(0, 8)],
          height: t.lineHeight == 0 ? null : t.lineHeight,
        ),
      ),
    );
  }
}

class FontsPage extends StatelessWidget {
  const FontsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final fm = context.watch<FontManager>();
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('فونت‌ها')),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('افزودن فونت (TTF/OTF)'),
        onPressed: () async {
          final f = await fm.importFont();
          if (f != null && context.mounted) toast(context, 'فونت «${f.name}» اضافه شد');
        },
      ),
      body: ListView(children: [
        const SectionHeader('فونت‌های داخلی'),
        for (final f in FontManager.builtIns)
          RadioListTile<String>(
            value: f.id, groupValue: s.text.fontId,
            title: Text(f.name), subtitle: Text(f.license.isEmpty ? (f.hasFile ? '' : 'بدون فایل، از سیستم') : 'مجوز ${f.license}'),
            onChanged: (v) => s.setText(s.text.copyWith(fontId: v)),
          ),
        if (fm.custom.isNotEmpty) const SectionHeader('فونت‌های سفارشی'),
        for (final f in fm.custom)
          RadioListTile<String>(
            value: f.id, groupValue: s.text.fontId, title: Text(f.name),
            onChanged: (v) => s.setText(s.text.copyWith(fontId: v)),
            secondary: PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'rename') {
                  final n = await promptText(context, title: 'نام فونت', initial: f.name);
                  if (n != null && n.trim().isNotEmpty) fm.renameCustom(f.id, n.trim());
                } else {
                  if (s.text.fontId == f.id) s.setText(s.text.copyWith(fontId: 'vazirmatn'));
                  fm.removeCustom(f.id);
                }
              },
              itemBuilder: (_) => const [PopupMenuItem(value: 'rename', child: Text('تغییر نام')), PopupMenuItem(value: 'delete', child: Text('حذف'))],
            ),
          ),
        const SizedBox(height: 96),
      ]),
    );
  }
}

class PresetsPage extends StatelessWidget {
  const PresetsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final ps = context.watch<PresetStore>();
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('Presetها')),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.save_outlined),
        label: const Text('ذخیره تنظیمات فعلی'),
        onPressed: () async {
          final n = await promptText(context, title: 'نام Preset');
          if (n != null && n.trim().isNotEmpty) ps.add(n.trim(), s.text);
        },
      ),
      body: ListView(children: [
        for (final p in ps.all)
          ListTile(
            leading: Icon(s.activePresetId == p.id ? Icons.radio_button_checked : Icons.radio_button_off),
            title: Text(p.name),
            subtitle: Text('${context.read<FontManager>().byId(p.settings.fontId).name} · ${p.settings.textScale}٪ · ${TextSettings.directions.entries.firstWhere((e) => e.value == p.settings.direction).key}'),
            onTap: () => s.setText(p.settings, presetId: p.id),
            trailing: PopupMenuButton<String>(
              onSelected: (v) async {
                switch (v) {
                  case 'edit':
                    Navigator.push(context, MaterialPageRoute(builder: (_) => _PresetEditor(preset: p)));
                  case 'rename':
                    final n = await promptText(context, title: 'تغییر نام', initial: p.name);
                    if (n != null && n.trim().isNotEmpty) ps.update(p.copyWith(name: n.trim()));
                  case 'overwrite':
                    ps.update(p.copyWith(settings: s.text));
                  case 'delete':
                    if (await confirm(context, 'Preset «${p.name}» حذف شود؟', destructive: true, ok: 'حذف')) ps.remove(p.id);
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('ویرایش')),
                PopupMenuItem(value: 'rename', child: Text('تغییر نام')),
                PopupMenuItem(value: 'overwrite', child: Text('جایگزینی با تنظیمات فعلی')),
                PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          ),
        const SizedBox(height: 96),
      ]),
    );
  }
}

class _PresetEditor extends StatefulWidget {
  const _PresetEditor({required this.preset});
  final Preset preset;
  @override
  State<_PresetEditor> createState() => _PresetEditorState();
}

class _PresetEditorState extends State<_PresetEditor> {
  late TextSettings _t = widget.preset.settings;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.preset.name), actions: [
          TextButton(onPressed: () { context.read<PresetStore>().update(widget.preset.copyWith(settings: _t)); Navigator.pop(context); }, child: const Text('ذخیره')),
        ]),
        body: ListView(children: [
          _Preview(t: _t),
          TextControls(value: _t, onChanged: (v) => setState(() => _t = v)),
        ]),
      );
}

class SitePrefsPage extends StatelessWidget {
  const SitePrefsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final sp = context.watch<SitePrefsStore>();
    final entries = sp.all.entries.toList()..sort((a, b) => a.key.compareTo(b.key));
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات سایت‌ها'), actions: [
        if (entries.isNotEmpty)
          IconButton(icon: const Icon(Icons.delete_sweep_outlined), onPressed: () async {
            if (await confirm(context, 'تنظیمات همه سایت‌ها ریست شود؟', destructive: true, ok: 'ریست')) sp.clear();
          }),
      ]),
      body: entries.isEmpty
          ? const Center(child: Padding(padding: EdgeInsets.all(32), child: Text('هنوز تنظیمی برای سایت خاصی ذخیره نکرده‌اید. حین مرور، از دکمه «Aa» گزینه «فقط این سایت» را بزنید.', textAlign: TextAlign.center)))
          : ListView(children: [
              for (final e in entries)
                ListTile(
                  leading: SiteIcon(url: 'https://${e.key}'),
                  title: LtrText(e.key),
                  subtitle: Text('${context.read<FontManager>().byId(e.value.fontId).name} · ${e.value.textScale}٪ · ${e.value.direction.toUpperCase()}${e.value.enabled ? '' : ' · خاموش'}'),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _SiteEditor(host: e.key))),
                  trailing: IconButton(tooltip: 'ریست', icon: const Icon(Icons.restart_alt), onPressed: () => sp.reset(e.key)),
                ),
            ]),
    );
  }
}

class _SiteEditor extends StatelessWidget {
  const _SiteEditor({required this.host});
  final String host;
  @override
  Widget build(BuildContext context) {
    final sp = context.watch<SitePrefsStore>();
    final t = sp.get(host);
    if (t == null) return const Scaffold();
    return Scaffold(
      appBar: AppBar(title: LtrText(host), actions: [
        TextButton(onPressed: () { sp.reset(host); Navigator.pop(context); }, child: const Text('ریست')),
      ]),
      body: ListView(children: [
        SwitchListTile(title: const Text('Text Formatting برای این سایت'), value: t.enabled, onChanged: (v) => sp.set(host, t.copyWith(enabled: v))),
        TextControls(value: t, onChanged: (v) => sp.set(host, v)),
      ]),
    );
  }
}

class _BrowserPage extends StatelessWidget {
  const _BrowserPage();
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('مرورگر')),
      body: ListView(children: [
        const SectionHeader('موتور جستجو'),
        const ListTile(leading: Icon(Icons.search), title: Text('Google'), subtitle: Text('جستجو از نوار نشانی با Google انجام می‌شود')),
        const SectionHeader('محتوا'),
        SwitchListTile(title: const Text('JavaScript'), subtitle: const Text('برای اکثر سایت‌های مدرن لازم است'), value: s.javaScriptEnabled, onChanged: (v) => s.update((x) => x.javaScriptEnabled = v)),
        SwitchListTile(title: const Text('مسدود کردن پاپ‌آپ‌های ناخواسته'), subtitle: const Text('پنجره‌هایی که بدون لمس شما باز می‌شوند'), value: s.blockPopups, onChanged: (v) => s.update((x) => x.blockPopups = v)),
        const SectionHeader('نوار ابزار'),
        SwitchListTile(title: const Text('جمع شدن نوار ابزار هنگام اسکرول'), value: s.hideToolbarOnScroll, onChanged: (v) => s.update((x) => x.hideToolbarOnScroll = v)),
        SwitchListTile(title: const Text('کشیدن برای بارگذاری مجدد'), subtitle: const Text('برای تب‌های جدید اعمال می‌شود'), value: s.pullToRefresh, onChanged: (v) => s.update((x) => x.pullToRefresh = v)),
      ]),
    );
  }
}

class _TabsPage extends StatelessWidget {
  const _TabsPage();
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('تب‌ها')),
      body: ListView(children: [
        SwitchListTile(title: const Text('بازگردانی تب‌ها هنگام باز کردن برنامه'), value: s.restoreTabs, onChanged: (v) => s.update((x) => x.restoreTabs = v)),
        SwitchListTile(title: const Text('باز کردن لینک در تب جدید در پس‌زمینه'), value: s.openLinksInBackground, onChanged: (v) => s.update((x) => x.openLinksInBackground = v)),
        ListTile(
          title: const Text('حداکثر تب‌های فعال در حافظه'),
          subtitle: Text('${TabManager.maxAlive} تب؛ بقیه به خواب می‌روند و با انتخاب دوباره بارگذاری می‌شوند.'),
        ),
      ]),
    );
  }
}

class _PrivacyPage extends StatelessWidget {
  const _PrivacyPage();
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final services = context.read<Services>();
    Future<void> run(String title, Future<void> Function() f) async {
      if (!await confirm(context, title, destructive: true, ok: 'پاک کن')) return;
      await f();
      if (context.mounted) toast(context, 'انجام شد');
    }
    return Scaffold(
      appBar: AppBar(title: const Text('حریم خصوصی')),
      body: ListView(children: [
        const Padding(
          padding: EdgeInsets.all(20),
          child: Text('تاریخچه، نشانک‌ها، دانلودها و تنظیمات فقط روی همین دستگاه ذخیره می‌شوند. برنامه هیچ Analytics یا Tracking ندارد و چیزی به سرور ما ارسال نمی‌کند.'),
        ),
        SwitchListTile(
          title: const Text('پیشنهادهای جستجوی Google'),
          subtitle: const Text('متن تایپ‌شده در نوار نشانی برای دریافت پیشنهاد به Google ارسال می‌شود (هرگز در تب ناشناس).'),
          value: s.searchSuggestions, onChanged: (v) => s.update((x) => x.searchSuggestions = v)),
        SwitchListTile(title: const Text('کوکی‌های شخص ثالث'), subtitle: const Text('خاموش کردن ممکن است ورود با Google در برخی سایت‌ها را مختل کند.'), value: s.thirdPartyCookies, onChanged: (v) => s.update((x) => x.thirdPartyCookies = v)),
        SwitchListTile(title: const Text('پاک کردن تاریخچه، کوکی و کش هنگام خروج'), value: s.clearDataOnExit, onChanged: (v) => s.update((x) => x.clearDataOnExit = v)),
        const SectionHeader('پاک کردن داده‌ها'),
        ListTile(leading: const Icon(Icons.history), title: const Text('پاک کردن تاریخچه'), onTap: () => run('تاریخچه پاک شود؟', context.read<HistoryRepo>().clear)),
        ListTile(leading: const Icon(Icons.cookie_outlined), title: const Text('پاک کردن کوکی‌ها'), subtitle: const Text('از همه حساب‌ها خارج می‌شوید'),
            onTap: () => run('همه کوکی‌ها پاک شود؟', () async { await CookieManager.instance().deleteAllCookies(); })),
        ListTile(leading: const Icon(Icons.cached), title: const Text('پاک کردن کش'), onTap: () => run('کش پاک شود؟', InAppWebViewController.clearAllCache)),
        ListTile(leading: const Icon(Icons.storage_outlined), title: const Text('پاک کردن داده سایت‌ها (Local Storage و…)'),
            onTap: () => run('داده همه سایت‌ها پاک شود؟', () => WebStorageManager.instance().deleteAllData())),
        ListTile(leading: const Icon(Icons.download_outlined), title: const Text('پاک کردن فهرست دانلودها'), onTap: () => run('فهرست دانلودها پاک شود؟', context.read<DownloadManager>().clearFinished)),
        ListTile(leading: const Icon(Icons.language), title: const Text('ریست تنظیمات همه سایت‌ها'), onTap: () => run('تنظیمات سایت‌ها ریست شود؟', () async => services.sites.clear())),
      ]),
    );
  }
}

class _AboutPage extends StatelessWidget {
  const _AboutPage();
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('درباره')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Icon(Icons.format_textdirection_r_to_l, size: 56),
          const SizedBox(height: 12),
          Text('مرورگر راست‌چین', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const Text('نسخه 1.0.0', textAlign: TextAlign.center),
          const SizedBox(height: 24),
          const Text('موتور نمایش: System WebView (Chromium) در Android و WKWebView در iOS.\n'
              'موتور Text Formatting: لایه CSS/JS تزریقی با MutationObserver، بدون بازسازی DOM.'),
          const SizedBox(height: 16),
          const Text('فونت‌ها: Vazirmatn، Estedad، Noto Naskh Arabic، Literata، Inter، همگی تحت مجوز SIL Open Font License 1.1.'),
          const SizedBox(height: 16),
          OutlinedButton(onPressed: () => showLicensePage(context: context), child: const Text('مجوزهای متن‌باز')),
        ]),
      );
}
