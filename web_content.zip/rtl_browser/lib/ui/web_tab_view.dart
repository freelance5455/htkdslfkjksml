import 'dart:collection';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app/services.dart';
import '../core/url_utils.dart';
import '../tabs/browser_tab.dart';
import '../text_engine/text_engine_service.dart';
import '../text_engine/text_settings.dart';

/// Events a tab reports to the browser chrome.
class WebTabCallbacks {
  const WebTabCallbacks({
    required this.onScroll,
    required this.onOpenWindow,
    required this.onCloseWindow,
    required this.onDownload,
    required this.onLongPress,
    required this.onFullscreen,
  });
  final void Function(BrowserTab tab, int y) onScroll;
  final void Function(BrowserTab opener, CreateWindowAction action) onOpenWindow;
  final void Function(BrowserTab tab) onCloseWindow;
  final void Function(BrowserTab tab, DownloadStartRequest req) onDownload;
  final void Function(BrowserTab tab, InAppWebViewHitTestResult hit) onLongPress;
  final void Function(bool entered) onFullscreen;
}

/// One live WebView. Hosts the text-engine bridge for its page.
class WebTabView extends StatefulWidget {
  const WebTabView({super.key, required this.tab, required this.callbacks});
  final BrowserTab tab;
  final WebTabCallbacks callbacks;

  @override
  State<WebTabView> createState() => _WebTabViewState();
}

class _WebTabViewState extends State<WebTabView> {
  late final Services s = context.read<Services>();
  BrowserTab get tab => widget.tab;
  PullToRefreshController? _ptr;
  TextSettings? _lastApplied;
  int _bootVersion = -1;
  bool _applying = false;
  bool _dirty = false;
  bool get _android => defaultTargetPlatform == TargetPlatform.android;

  @override
  void initState() {
    super.initState();
    _bootVersion = s.engine.bootVersion;
    if (s.settings.pullToRefresh) {
      _ptr = PullToRefreshController(
        settings: PullToRefreshSettings(color: Colors.teal),
        onRefresh: () => tab.controller?.reload(),
      );
    }
    tab.findController = FindInteractionController(
      onFindResultReceived: (c, active, total, done) {
        tab.findActive = total == 0 ? 0 : active + 1;
        tab.findMatches = total;
        tab.touch();
      },
    );
    s.settings.addListener(_onSettings);
    s.sites.addListener(_onTextChanged);
    s.engine.addListener(_onEngine);
  }

  @override
  void dispose() {
    s.settings.removeListener(_onSettings);
    s.sites.removeListener(_onTextChanged);
    s.engine.removeListener(_onEngine);
    if (tab.controller != null && identical(tab.controller, _controller)) tab.controller = null;
    super.dispose();
  }

  InAppWebViewController? _controller;

  // ---------- text engine bridge ----------
  void _onTextChanged() => _applyText();

  void _onSettings() {
    _applyText();
    _syncWebSettings();
  }

  /// New boot script (fonts / site prefs changed) -> replace the document-start user script.
  Future<void> _onEngine() async {
    final c = _controller;
    if (c == null || _bootVersion == s.engine.bootVersion) return;
    _bootVersion = s.engine.bootVersion;
    await c.removeUserScriptsByGroupName(groupName: TextEngineService.groupName);
    await c.addUserScript(userScript: s.engine.userScript);
  }

  /// Live-applies the effective settings for this tab's host. Coalesces rapid slider updates.
  Future<void> _applyText({bool force = false}) async {
    final c = _controller;
    if (c == null || !UrlUtils.isHttp(tab.url)) return;
    final t = s.engine.effectiveFor(tab.host);
    if (!force && t == _lastApplied) return;
    if (_applying) { _dirty = true; return; }
    _applying = true;
    try {
      final js = await s.engine.applyJs(t, includeFont: tab.fontInPage != t.fontId);
      await c.evaluateJavascript(source: js);
      tab.fontInPage = t.fontId;
      _lastApplied = t;
      final zoom = (_android && t.enabled) ? t.textScale : 100;
      if (_android && tab.lastTextZoom != zoom) {
        final cur = await c.getSettings();
        if (cur != null) {
          cur.textZoom = zoom;
          await c.setSettings(settings: cur);
          tab.lastTextZoom = zoom;
        }
      }
      if (tab.readerOpen) await s.reader.update(c, t);
    } catch (_) {
      // page navigated mid-apply; next load re-applies
    } finally {
      _applying = false;
      if (_dirty) { _dirty = false; _applyText(); }
    }
  }

  Future<void> _syncWebSettings() async {
    final c = _controller;
    if (c == null) return;
    final cur = await c.getSettings();
    if (cur == null) return;
    final st = s.settings;
    final changed = cur.javaScriptEnabled != st.javaScriptEnabled ||
        cur.javaScriptCanOpenWindowsAutomatically != !st.blockPopups ||
        cur.algorithmicDarkeningAllowed != st.webDarkMode ||
        cur.thirdPartyCookiesEnabled != st.thirdPartyCookies;
    if (!changed) return;
    cur
      ..javaScriptEnabled = st.javaScriptEnabled
      ..javaScriptCanOpenWindowsAutomatically = !st.blockPopups
      ..algorithmicDarkeningAllowed = st.webDarkMode
      ..thirdPartyCookiesEnabled = st.thirdPartyCookies;
    await c.setSettings(settings: cur);
  }

  InAppWebViewSettings _initialSettings() {
    final st = s.settings;
    final t = s.engine.effectiveFor(UrlUtils.host(tab.pendingUrl ?? tab.url));
    tab.lastTextZoom = (_android && t.enabled) ? t.textScale : 100;
    return InAppWebViewSettings(
      javaScriptEnabled: st.javaScriptEnabled,
      domStorageEnabled: true,
      databaseEnabled: true,
      cacheEnabled: true,
      incognito: tab.incognito,
      thirdPartyCookiesEnabled: st.thirdPartyCookies,
      mediaPlaybackRequiresUserGesture: false,
      allowsInlineMediaPlayback: true,
      allowsPictureInPictureMediaPlayback: true,
      supportMultipleWindows: true,
      javaScriptCanOpenWindowsAutomatically: !st.blockPopups,
      useOnDownloadStart: true,
      useShouldOverrideUrlLoading: true,
      supportZoom: true,
      builtInZoomControls: true,
      displayZoomControls: false,
      useWideViewPort: true,
      loadWithOverviewMode: true,
      textZoom: tab.lastTextZoom!,
      userAgent: tab.desktopMode ? s.desktopUserAgent() : (s.mobileUserAgent ?? ''),
      preferredContentMode: tab.desktopMode ? UserPreferredContentMode.DESKTOP : UserPreferredContentMode.RECOMMENDED,
      algorithmicDarkeningAllowed: st.webDarkMode,
      mixedContentMode: MixedContentMode.MIXED_CONTENT_COMPATIBILITY_MODE,
      safeBrowsingEnabled: true,
      isFraudulentWebsiteWarningEnabled: true,
      allowsBackForwardNavigationGestures: true,
      geolocationEnabled: true,
      disableDefaultErrorPage: true,
      isTextInteractionEnabled: true,
      useHybridComposition: true,
    );
  }

  Future<void> _refreshNav(InAppWebViewController c) async {
    tab.canGoBack = await c.canGoBack();
    tab.canGoForward = await c.canGoForward();
    tab.touch();
  }

  Future<void> _loadFavicon(InAppWebViewController c) async {
    try {
      final icons = await c.getFavicons();
      if (icons.isEmpty) return;
      icons.sort((a, b) => ((a.width ?? 32) - 48).abs().compareTo(((b.width ?? 32) - 48).abs()));
      tab.faviconUrl = icons.first.url.toString();
      tab.touch();
    } catch (_) {}
  }

  Future<bool> _ask(String title, String body) async =>
      await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رد')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('اجازه')),
          ],
        ),
      ) ??
      false;

  Future<HttpAuthResponse> _httpAuth(URLAuthenticationChallenge ch) async {
    final u = TextEditingController(), p = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('ورود به ${ch.protectionSpace.host}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: u, decoration: const InputDecoration(labelText: 'نام کاربری'), textDirection: TextDirection.ltr),
          TextField(controller: p, decoration: const InputDecoration(labelText: 'رمز عبور'), obscureText: true, textDirection: TextDirection.ltr),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ورود')),
        ],
      ),
    );
    return ok == true
        ? HttpAuthResponse(username: u.text, password: p.text, action: HttpAuthResponseAction.PROCEED, permanentPersistence: !tab.incognito)
        : HttpAuthResponse(action: HttpAuthResponseAction.CANCEL);
  }

  @override
  Widget build(BuildContext context) {
    final useWindow = tab.windowId != null && !tab.windowUsed;
    final initialUrl = useWindow ? null : (tab.pendingUrl ?? (tab.isHomeOnly ? null : tab.url));
    return InAppWebView(
      windowId: useWindow ? tab.windowId : null,
      initialUrlRequest: initialUrl == null ? null : URLRequest(url: WebUri(initialUrl)),
      initialUserScripts: UnmodifiableListView([s.engine.userScript]),
      initialSettings: _initialSettings(),
      pullToRefreshController: _ptr,
      findInteractionController: tab.findController,
      onWebViewCreated: (c) {
        _controller = c;
        tab.controller = c;
        if (useWindow) tab.windowUsed = true;
        tab.pendingUrl = null;
      },
      onLoadStart: (c, url) {
        tab.error = null;
        tab.progress = 0;
        tab.readerOpen = false;
        tab.readerAvailable = false;
        // The document-start script carries the boot fonts; anything else is re-sent on apply.
        final t = s.engine.effectiveFor(UrlUtils.host(url?.toString()));
        tab.fontInPage = s.engine.bootVersion == _bootVersion ? t.fontId : null;
        _lastApplied = null;
        if (url != null) tab.url = url.toString();
        tab.touch();
      },
      onProgressChanged: (c, p) {
        tab.progress = p;
        if (p == 100) _ptr?.endRefreshing();
        tab.touch();
      },
      onLoadStop: (c, url) async {
        _ptr?.endRefreshing();
        tab.progress = 100;
        await _refreshNav(c);
        await _applyText(force: true);
        _loadFavicon(c);
        if (UrlUtils.isHttp(url?.toString())) {
          tab.readerAvailable = await s.reader.isReadable(c);
          tab.touch();
        }
      },
      onTitleChanged: (c, title) {
        tab.title = title ?? '';
        if (!tab.incognito && title != null) s.history.updateTitle(tab.url, title);
      },
      onUpdateVisitedHistory: (c, url, isReload) async {
        if (url == null) return;
        final prevHost = tab.host;
        tab.url = url.toString();
        if (!tab.incognito && isReload != true) s.history.record(tab.url, await c.getTitle());
        await _refreshNav(c);
        if (prevHost != tab.host) _applyText(force: true); // SPA crossed to a host with other prefs
        s.tabs.save();
      },
      shouldOverrideUrlLoading: (c, action) async {
        final url = action.request.url?.toString() ?? '';
        if (UrlUtils.isExternalScheme(url)) {
          final fallback = url.startsWith('intent:') ? UrlUtils.intentFallback(url) : null;
          try {
            final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
            if (!ok && fallback != null) await c.loadUrl(urlRequest: URLRequest(url: WebUri(fallback)));
          } catch (_) {
            if (fallback != null) await c.loadUrl(urlRequest: URLRequest(url: WebUri(fallback)));
          }
          return NavigationActionPolicy.CANCEL;
        }
        return NavigationActionPolicy.ALLOW;
      },
      onCreateWindow: (c, action) async {
        if (s.settings.blockPopups && action.hasGesture == false && action.isDialog != true) return false;
        widget.callbacks.onOpenWindow(tab, action);
        return true;
      },
      onCloseWindow: (c) => widget.callbacks.onCloseWindow(tab),
      onDownloadStartRequest: (c, req) => widget.callbacks.onDownload(tab, req),
      onScrollChanged: (c, x, y) => widget.callbacks.onScroll(tab, y),
      onLongPressHitTestResult: (c, hit) => widget.callbacks.onLongPress(tab, hit),
      onEnterFullscreen: (c) => widget.callbacks.onFullscreen(true),
      onExitFullscreen: (c) => widget.callbacks.onFullscreen(false),
      onReceivedError: (c, req, err) {
        if (req.isForMainFrame != true) return;
        if (err.type == WebResourceErrorType.CANCELLED) return;
        _ptr?.endRefreshing();
        tab.error = err.description;
        tab.touch();
      },
      onPermissionRequest: (c, req) async {
        String nameOf(PermissionResourceType r) {
          if (r == PermissionResourceType.CAMERA) return 'دوربین';
          if (r == PermissionResourceType.MICROPHONE) return 'میکروفون';
          if (r == PermissionResourceType.CAMERA_AND_MICROPHONE) return 'دوربین و میکروفون';
          if (r == PermissionResourceType.PROTECTED_MEDIA_ID) return 'پخش محتوای محافظت‌شده';
          return r.toString();
        }
        final names = req.resources.map(nameOf);
        // DRM-protected media (e.g. paid streaming) is safe to allow silently.
        final onlyDrm = req.resources.every((r) => r == PermissionResourceType.PROTECTED_MEDIA_ID);
        final ok = onlyDrm || await _ask('درخواست دسترسی', '${UrlUtils.host(req.origin.toString())} به ${names.join('، ')} دسترسی می‌خواهد.');
        return PermissionResponse(resources: req.resources, action: ok ? PermissionResponseAction.GRANT : PermissionResponseAction.DENY);
      },
      onGeolocationPermissionsShowPrompt: (c, origin) async {
        final ok = await _ask('موقعیت مکانی', '${UrlUtils.host(origin)} می‌خواهد به موقعیت مکانی شما دسترسی داشته باشد.');
        return GeolocationPermissionShowPromptResponse(origin: origin, allow: ok, retain: ok && !tab.incognito);
      },
      onReceivedHttpAuthRequest: (c, ch) => _httpAuth(ch),
    );
  }
}
