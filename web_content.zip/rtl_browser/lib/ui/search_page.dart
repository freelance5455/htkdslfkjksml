import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../app/services.dart';
import '../core/debouncer.dart';
import '../core/url_utils.dart';
import 'widgets/common.dart';

/// Full-screen omnibox: URL entry, Google search, history/bookmark matches, Google suggestions.
class SearchPage extends StatefulWidget {
  const SearchPage({super.key, this.initial = '', this.incognito = false});
  final String initial;
  final bool incognito;

  static Future<String?> open(BuildContext context, {String initial = '', bool incognito = false}) =>
      Navigator.of(context).push<String>(PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 160),
        pageBuilder: (_, __, ___) => SearchPage(initial: initial, incognito: incognito),
        transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
      ));

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _Suggestion {
  _Suggestion(this.text, {this.url, this.kind = 'search'});
  final String text;
  final String? url;
  final String kind; // search | history | bookmark
}

class _SearchPageState extends State<SearchPage> {
  late final TextEditingController _c = TextEditingController(text: widget.initial)
    ..selection = TextSelection(baseOffset: 0, extentOffset: widget.initial.length);
  final _debounce = Debouncer(const Duration(milliseconds: 180));
  List<_Suggestion> _local = [];
  List<String> _remote = [];
  int _req = 0;
  HttpClient? _http;

  @override
  void dispose() {
    _debounce.dispose();
    _http?.close(force: true);
    _c.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    setState(() {});
    _debounce(() => _query(q));
  }

  Future<void> _query(String q) async {
    final s = context.read<Services>();
    final id = ++_req;
    final hist = await s.history.suggest(q);
    final bms = await s.bookmarks.list(query: q);
    if (!mounted || id != _req) return;
    setState(() => _local = [
          ...bms.take(3).map((b) => _Suggestion(b.title, url: b.url, kind: 'bookmark')),
          ...hist.where((h) => !bms.any((b) => b.url == h.url)).take(5).map((h) => _Suggestion(h.title.isEmpty ? h.url : h.title, url: h.url, kind: 'history')),
        ]);
    // Network suggestions only if enabled, never in incognito, never for things that look like URLs.
    if (!s.settings.searchSuggestions || widget.incognito || q.trim().isEmpty || UrlUtils.resolve(q) != UrlUtils.searchUrl(q.trim())) {
      if (mounted) setState(() => _remote = []);
      return;
    }
    try {
      _http ??= HttpClient()..connectionTimeout = const Duration(seconds: 3);
      final req = await _http!.getUrl(Uri.parse(
          'https://suggestqueries.google.com/complete/search?client=firefox&ie=utf-8&oe=utf-8&q=${Uri.encodeQueryComponent(q)}'));
      final res = await req.close();
      final body = await res.transform(const Utf8Decoder(allowMalformed: true)).join();
      final j = jsonDecode(body) as List;
      if (!mounted || id != _req) return;
      setState(() => _remote = (j[1] as List).cast<String>().take(6).toList());
    } catch (_) {/* offline or blocked: local suggestions still work */}
  }

  void _submit(String v) {
    if (v.trim().isEmpty) return;
    Navigator.pop(context, v.trim());
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final q = _c.text;
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
              Expanded(
                child: TextField(
                  controller: _c,
                  autofocus: true,
                  keyboardType: TextInputType.url,
                  textInputAction: TextInputAction.go,
                  autocorrect: false,
                  onChanged: _onChanged,
                  onSubmitted: _submit,
                  decoration: InputDecoration(
                    hintText: 'جستجو در Google یا وارد کردن نشانی',
                    filled: true,
                    fillColor: cs.surfaceContainerHigh,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
                    prefixIcon: Icon(widget.incognito ? Icons.visibility_off_outlined : Icons.search),
                    suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () { _c.clear(); _onChanged(''); }),
                  ),
                ),
              ),
            ]),
          ),
          if (widget.initial.isNotEmpty && q == widget.initial)
            ListTile(
              leading: const Icon(Icons.content_copy_outlined),
              title: LtrText(widget.initial),
              subtitle: const Text('کپی نشانی'),
              onTap: () { Clipboard.setData(ClipboardData(text: widget.initial)); Navigator.pop(context); },
            ),
          Expanded(
            child: ListView(children: [
              if (q.trim().isNotEmpty)
                ListTile(
                  leading: Icon(UrlUtils.resolve(q).startsWith('https://www.google.com/search') ? Icons.search : Icons.public),
                  title: Text(q, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(UrlUtils.resolve(q).startsWith('https://www.google.com/search') ? 'جستجو با Google' : 'رفتن به نشانی'),
                  onTap: () => _submit(q),
                ),
              ..._local.map((s) => ListTile(
                    leading: Icon(s.kind == 'bookmark' ? Icons.bookmark_outline : Icons.history),
                    title: Text(s.text, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: LtrText(s.url ?? ''),
                    onTap: () => Navigator.pop(context, s.url),
                  )),
              ..._remote.map((r) => ListTile(
                    leading: const Icon(Icons.search),
                    title: Text(r),
                    trailing: IconButton(icon: const Icon(Icons.north_east), onPressed: () {
                      _c.text = '$r '; _c.selection = TextSelection.collapsed(offset: _c.text.length); _onChanged(_c.text);
                    }),
                    onTap: () => _submit(r),
                  )),
            ]),
          ),
        ]),
      ),
    );
  }
}
