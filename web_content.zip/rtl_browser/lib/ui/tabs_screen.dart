import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/url_utils.dart';
import '../tabs/browser_tab.dart';
import '../tabs/tab_manager.dart';
import 'widgets/common.dart';

class TabsScreen extends StatefulWidget {
  const TabsScreen({super.key});
  @override
  State<TabsScreen> createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> with SingleTickerProviderStateMixin {
  late final TabController _tc = TabController(length: 2, vsync: this, initialIndex: context.read<TabManager>().active.incognito ? 1 : 0);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _tc.addListener(() { if (mounted) setState(() {}); }));
  }

  @override
  void dispose() { _tc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final tm = context.watch<TabManager>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('تب‌ها'),
        bottom: TabBar(controller: _tc, tabs: [
          Tab(text: 'عادی (${tm.normalTabs.length})'),
          Tab(text: 'ناشناس (${tm.incognitoTabs.length})'),
        ]),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'closeAll' && await confirm(context, 'همه تب‌ها بسته شوند؟', destructive: true, ok: 'بستن')) tm.closeAll();
              if (v == 'closeIncog') tm.closeAll(incognitoOnly: true);
              if (v == 'reopen') { tm.reopenClosed(); if (context.mounted) Navigator.pop(context); }
            },
            itemBuilder: (_) => [
              if (tm.recentlyClosed.isNotEmpty) const PopupMenuItem(value: 'reopen', child: Text('بازگردانی آخرین تب بسته‌شده')),
              const PopupMenuItem(value: 'closeIncog', child: Text('بستن تب‌های ناشناس')),
              const PopupMenuItem(value: 'closeAll', child: Text('بستن همه تب‌ها')),
            ],
          ),
        ],
      ),
      body: TabBarView(controller: _tc, children: [
        _Grid(tabs: tm.normalTabs, recently: true),
        _Grid(tabs: tm.incognitoTabs, recently: false),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () { tm.open(incognito: _tc.index == 1); Navigator.pop(context); },
        icon: const Icon(Icons.add),
        label: Text(_tc.index == 1 ? 'تب ناشناس' : 'تب جدید'),
      ),
    );
  }
}

class _Grid extends StatelessWidget {
  const _Grid({required this.tabs, required this.recently});
  final List<BrowserTab> tabs;
  final bool recently;

  @override
  Widget build(BuildContext context) {
    final tm = context.read<TabManager>();
    final cs = Theme.of(context).colorScheme;
    return CustomScrollView(slivers: [
      SliverPadding(
        padding: const EdgeInsets.all(12),
        sliver: SliverGrid.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .82, mainAxisSpacing: 12, crossAxisSpacing: 12),
          itemCount: tabs.length,
          itemBuilder: (_, i) {
            final t = tabs[i];
            final selected = t == tm.active;
            return Dismissible(
              key: ValueKey(t.id),
              onDismissed: (_) => tm.close(t),
              child: GestureDetector(
                onTap: () { tm.selectTab(t); Navigator.pop(context); },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  decoration: BoxDecoration(
                    color: cs.surfaceContainerHigh,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: selected ? cs.primary : Colors.transparent, width: 2.5),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 2, 4),
                      child: Row(children: [
                        SiteIcon(url: t.url, faviconUrl: t.faviconUrl, size: 18),
                        const SizedBox(width: 8),
                        Expanded(child: Text(t.isHomeOnly ? 'صفحه اصلی' : (t.title.isEmpty ? UrlUtils.display(t.url) : t.title), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13))),
                        IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.close, size: 18), onPressed: () => tm.close(t)),
                      ]),
                    ),
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                        decoration: BoxDecoration(color: cs.surface, borderRadius: BorderRadius.circular(12)),
                        alignment: Alignment.center,
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          SiteIcon(url: t.url, faviconUrl: t.faviconUrl, size: 40),
                          const SizedBox(height: 10),
                          Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: LtrText(t.isHomeOnly ? '' : UrlUtils.host(t.url), style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12))),
                          if (!t.hasWebView && !t.isHomeOnly)
                            Padding(padding: const EdgeInsets.only(top: 4), child: Text('خواب (صرفه‌جویی در حافظه)', style: TextStyle(fontSize: 10, color: cs.outline))),
                        ]),
                      ),
                    ),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
      if (recently && tm.recentlyClosed.isNotEmpty) ...[
        const SliverToBoxAdapter(child: SectionHeader('بسته‌شده‌های اخیر')),
        SliverList.builder(
          itemCount: tm.recentlyClosed.length.clamp(0, 10),
          itemBuilder: (_, i) {
            final c = tm.recentlyClosed[i];
            return ListTile(
              leading: SiteIcon(url: c.url),
              title: Text(c.title.isEmpty ? c.url : c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: LtrText(c.url),
              trailing: const Icon(Icons.restore),
              onTap: () { tm.reopenClosed(c); Navigator.pop(context); },
            );
          },
        ),
      ],
      const SliverToBoxAdapter(child: SizedBox(height: 96)),
    ]);
  }
}
