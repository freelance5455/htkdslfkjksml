import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../fonts/font_manager.dart';
import '../text_engine/text_settings.dart';

/// Reusable controls for a TextSettings value. Used by the quick bottom sheet, the Text settings
/// page, the preset editor and the per-site editor, so every surface behaves identically.
class TextControls extends StatelessWidget {
  const TextControls({super.key, required this.value, required this.onChanged, this.compact = false, this.showReader = true});
  final TextSettings value;
  final ValueChanged<TextSettings> onChanged;
  final bool compact;
  final bool showReader;

  @override
  Widget build(BuildContext context) {
    final t = value;
    final fonts = context.watch<FontManager>().all;
    final cs = Theme.of(context).colorScheme;
    Widget label(String s, [String? v]) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
          child: Row(children: [
            Text(s, style: Theme.of(context).textTheme.labelLarge),
            const Spacer(),
            if (v != null) Text(v, style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700)),
          ]),
        );

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
      label('فونت'),
      SizedBox(
        height: 44,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            for (final FontDef f in fonts)
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 8),
                child: ChoiceChip(
                  label: Text(f.name),
                  selected: t.fontId == f.id,
                  onSelected: (_) => onChanged(t.copyWith(fontId: f.id)),
                ),
              ),
          ],
        ),
      ),
      label('اندازه متن', '${t.textScale}٪'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Wrap(spacing: 6, children: [
          for (final e in TextSettings.sizeSteps.entries)
            ChoiceChip(
              label: Text(e.key, style: const TextStyle(fontSize: 12)),
              selected: t.textScale == e.value,
              visualDensity: VisualDensity.compact,
              onSelected: (_) => onChanged(t.copyWith(textScale: e.value)),
            ),
        ]),
      ),
      Slider(
        value: t.textScale.toDouble().clamp(60.0, 200.0), min: 60, max: 200, divisions: 28,
        label: '${t.textScale}٪',
        onChanged: (v) => onChanged(t.copyWith(textScale: v.round())),
      ),
      label('جهت متن'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: SegmentedButton<String>(
          showSelectedIcon: false,
          segments: [for (final e in TextSettings.directions.entries) ButtonSegment(value: e.value, label: Text(e.key, style: const TextStyle(fontSize: 12)))],
          selected: {t.direction},
          onSelectionChanged: (s) => onChanged(t.copyWith(direction: s.first)),
        ),
      ),
      label('ضخامت'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: SegmentedButton<int>(
          showSelectedIcon: false,
          segments: [for (final e in TextSettings.weights.entries) ButtonSegment(value: e.value, label: Text(e.key, style: const TextStyle(fontSize: 12)))],
          selected: {t.weight},
          onSelectionChanged: (s) => onChanged(t.copyWith(weight: s.first)),
        ),
      ),
      label('فاصله خطوط', t.lineHeight == 0 ? 'پیش‌فرض سایت' : t.lineHeight.toStringAsFixed(1)),
      Slider(
        value: t.lineHeight == 0 ? 1.0 : t.lineHeight.clamp(1.0, 2.8), min: 1.0, max: 2.8, divisions: 18,
        label: t.lineHeight == 0 ? 'پیش‌فرض' : t.lineHeight.toStringAsFixed(1),
        onChanged: (v) => onChanged(t.copyWith(lineHeight: v <= 1.0 ? 0.0 : double.parse(v.toStringAsFixed(1)))),
      ),
      if (!compact) ...[
        label('فاصله حروف/کلمات', t.letterSpacing == 0 ? 'پیش‌فرض' : t.letterSpacing.toStringAsFixed(2)),
        Slider(
          value: t.letterSpacing.clamp(0.0, 0.15), min: 0, max: 0.15, divisions: 15,
          onChanged: (v) => onChanged(t.copyWith(letterSpacing: double.parse(v.toStringAsFixed(2)))),
        ),
        label('فاصله پاراگراف‌ها', t.paragraphSpacing == 0 ? 'پیش‌فرض سایت' : '${t.paragraphSpacing.toStringAsFixed(1)}em'),
        Slider(
          value: t.paragraphSpacing.clamp(0.0, 2.5), min: 0, max: 2.5, divisions: 10,
          onChanged: (v) => onChanged(t.copyWith(paragraphSpacing: v)),
        ),
      ],
      if (showReader) ...[
        label('حالت مطالعه: رنگ زمینه'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in TextSettings.readerThemes.entries)
              _ThemeDot(name: e.key, id: e.value, selected: t.readerTheme == e.value, custom: Color(t.customBg),
                  onTap: () async {
                    if (e.value == 'custom') {
                      final picked = await _pickCustom(context, t);
                      if (picked != null) onChanged(picked.copyWith(readerTheme: 'custom'));
                    } else {
                      onChanged(t.copyWith(readerTheme: e.value));
                    }
                  }),
          ]),
        ),
        label('حالت مطالعه: عرض متن'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SegmentedButton<String>(
            showSelectedIcon: false,
            segments: [for (final e in TextSettings.readerWidths.entries) ButtonSegment(value: e.value, label: Text(e.key, style: const TextStyle(fontSize: 12)))],
            selected: {t.readerWidth},
            onSelectionChanged: (s) => onChanged(t.copyWith(readerWidth: s.first)),
          ),
        ),
        if (!compact)
          SwitchListTile(title: const Text('تراز دوطرفه در حالت مطالعه'), value: t.justify, onChanged: (v) => onChanged(t.copyWith(justify: v))),
      ],
      const SizedBox(height: 8),
    ]);
  }

  static const _palette = <int>[0xFFFFFFFF, 0xFFFAF7F0, 0xFFF4ECD8, 0xFFE8F0E8, 0xFFE6EEF7, 0xFF1E1E1E, 0xFF0F172A, 0xFF000000];

  Future<TextSettings?> _pickCustom(BuildContext context, TextSettings t) => showModalBottomSheet<TextSettings>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('رنگ زمینه سفارشی'),
              const SizedBox(height: 12),
              Wrap(spacing: 10, runSpacing: 10, children: [
                for (final c in _palette)
                  InkWell(
                    onTap: () {
                      final dark = Color(c).computeLuminance() < .4;
                      Navigator.pop(ctx, t.copyWith(customBg: c, customFg: dark ? 0xFFE6E6E6 : 0xFF1A1A1A));
                    },
                    child: CircleAvatar(radius: 20, backgroundColor: Color(c), child: Container(decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.grey)))),
                  ),
              ]),
            ]),
          ),
        ),
      );
}

class _ThemeDot extends StatelessWidget {
  const _ThemeDot({required this.name, required this.id, required this.selected, required this.onTap, required this.custom});
  final String name, id;
  final bool selected;
  final VoidCallback onTap;
  final Color custom;
  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (id) {
      'dark' => (const Color(0xFF121214), const Color(0xFFE8E8EA)),
      'sepia' => (const Color(0xFFF4ECD8), const Color(0xFF433422)),
      'black' => (Colors.black, const Color(0xFFD6D6D6)),
      'custom' => (custom, custom.computeLuminance() < .4 ? Colors.white : Colors.black),
      _ => (Colors.white, const Color(0xFF1D1D1F)),
    };
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: bg, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? Theme.of(context).colorScheme.primary : Colors.grey.withValues(alpha: .4), width: selected ? 2.5 : 1),
        ),
        child: Text(name, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }
}
