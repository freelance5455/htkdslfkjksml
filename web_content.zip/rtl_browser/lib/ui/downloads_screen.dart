import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../downloads/download_manager.dart';
import 'widgets/common.dart';

class DownloadsScreen extends StatelessWidget {
  const DownloadsScreen({super.key});

  IconData _icon(String name) {
    final n = name.toLowerCase();
    if (n.endsWith('.pdf')) return Icons.picture_as_pdf_outlined;
    if (RegExp(r'\.(png|jpe?g|gif|webp|svg|bmp)$').hasMatch(n)) return Icons.image_outlined;
    if (RegExp(r'\.(zip|rar|7z|tar|gz)$').hasMatch(n)) return Icons.folder_zip_outlined;
    if (RegExp(r'\.(mp4|mkv|webm|mov)$').hasMatch(n)) return Icons.movie_outlined;
    if (RegExp(r'\.(mp3|m4a|ogg|wav|flac)$').hasMatch(n)) return Icons.audiotrack_outlined;
    if (RegExp(r'\.(txt|md|csv|json|html?)$').hasMatch(n)) return Icons.description_outlined;
    return Icons.insert_drive_file_outlined;
  }

  @override
  Widget build(BuildContext context) {
    final dm = context.watch<DownloadManager>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('دانلودها'), actions: [
        IconButton(tooltip: 'پاک کردن فهرست', icon: const Icon(Icons.clear_all), onPressed: dm.items.isEmpty ? null : () => dm.clearFinished()),
      ]),
      body: dm.items.isEmpty
          ? const Center(child: Text('هنوز دانلودی ندارید'))
          : ListView.separated(
              itemCount: dm.items.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
              itemBuilder: (_, i) {
                final d = dm.items[i];
                final running = d.status == DownloadStatus.running || d.status == DownloadStatus.queued;
                final sub = switch (d.status) {
                  DownloadStatus.running => '${formatBytes(d.received)} از ${formatBytes(d.total)}',
                  DownloadStatus.queued => 'در صف…',
                  DownloadStatus.done => '${formatBytes(d.received)} · ${relativeTime(d.createdAt)}',
                  DownloadStatus.failed => 'ناموفق${d.error == null ? '' : ': ${d.error}'}',
                  DownloadStatus.canceled => 'لغو شد',
                };
                return ListTile(
                  leading: CircleAvatar(backgroundColor: cs.secondaryContainer, child: Icon(_icon(d.fileName), color: cs.onSecondaryContainer)),
                  title: Text(d.fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: d.status == DownloadStatus.failed ? cs.error : null)),
                    if (running) Padding(padding: const EdgeInsets.only(top: 6), child: LinearProgressIndicator(value: d.progress, borderRadius: BorderRadius.circular(4))),
                  ]),
                  onTap: d.status == DownloadStatus.done
                      ? () async {
                          final r = await dm.open(d);
                          if (r != null && r.type.name != 'done' && context.mounted) toast(context, 'برنامه‌ای برای باز کردن این فایل پیدا نشد');
                        }
                      : null,
                  trailing: running
                      ? IconButton(icon: const Icon(Icons.close), onPressed: () => dm.cancel(d))
                      : PopupMenuButton<String>(
                          onSelected: (v) {
                            switch (v) {
                              case 'share': Share.shareXFiles([XFile(d.path!)]);
                              case 'retry': dm.retry(d);
                              case 'remove': dm.remove(d, deleteFile: false);
                              case 'delete': dm.remove(d);
                            }
                          },
                          itemBuilder: (_) => [
                            if (d.status == DownloadStatus.done && d.path != null) const PopupMenuItem(value: 'share', child: Text('اشتراک‌گذاری / ذخیره در…')),
                            if (d.status == DownloadStatus.failed || d.status == DownloadStatus.canceled) const PopupMenuItem(value: 'retry', child: Text('تلاش دوباره')),
                            const PopupMenuItem(value: 'remove', child: Text('حذف از فهرست')),
                            if (d.status == DownloadStatus.done) const PopupMenuItem(value: 'delete', child: Text('حذف فایل')),
                          ],
                        ),
                );
              },
            ),
    );
  }
}
