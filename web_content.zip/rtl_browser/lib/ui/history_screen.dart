import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../history/history_repo.dart';
import 'widgets/common.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String _q = '';
  bool _searching = false;

  String _dayLabel(DateTime d) {
    final now = DateTime.now();
    final day = DateTime(d.year, d.month, d.day), today = DateTime(now.year, now.month, now.day);
    final diff = today.difference(day).inDays;
    if (diff == 0) return 'امروز';
    if (diff == 1) return 'دیروز';
    return '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';
  }

  String _time(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<HistoryRepo>();
    return Scaffold(
      appBar: AppBar(
        title: _searching
            ? TextField(autofocus: true, decoration: const InputDecoration(hintText: 'جستجو در تاریخچه', border: InputBorder.none), onChanged: (v) => setState(() => _q = v))
            : const Text('تاریخچه'),
        actions: [
          IconButton(icon: Icon(_searching ? Icons.close : Icons.search), onPressed: () => setState(() { _searching = !_searching; _q = ''; })),
          IconButton(
            tooltip: 'پاک کردن کل تاریخچه',
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: () async { if (await confirm(context, 'کل تاریخچه پاک شود؟', destructive: true, ok: 'پاک کن')) repo.clear(); },
          ),
        ],
      ),
      body: FutureBuilder<List<HistoryEntry>>(
        future: repo.list(query: _q, limit: 500),
        builder: (_, snap) {
          final items = snap.data ?? [];
          if (snap.connectionState == ConnectionState.done && items.isEmpty) return const Center(child: Text('تاریخچه‌ای نیست'));
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (_, i) {
              final h = items[i];
              final header = i == 0 || _dayLabel(items[i - 1].visitedAt) != _dayLabel(h.visitedAt);
              return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                if (header) SectionHeader(_dayLabel(h.visitedAt)),
                ListTile(
                  leading: SiteIcon(url: h.url),
                  title: Text(h.title.isEmpty ? h.url : h.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Row(children: [Text(_time(h.visitedAt)), const SizedBox(width: 8), Expanded(child: LtrText(h.url))]),
                  trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => repo.delete(h.id)),
                  onTap: () => Navigator.pop(context, h.url),
                ),
              ]);
            },
          );
        },
      ),
    );
  }
}
