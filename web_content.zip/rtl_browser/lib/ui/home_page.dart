import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/services.dart';
import '../bookmarks/bookmark_repo.dart';
import '../history/history_repo.dart';
import '../tabs/tab_manager.dart';
import 'widgets/common.dart';

/// Native start page (no WebView needed -> instant app start).
class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.onOpen, required this.onSearchTap, this.incognito = false});
  final void Function(String input) onOpen;
  final VoidCallback onSearchTap;
  final bool incognito;

  static const popular = <(String, String)>[
    ('Google', 'https://www.google.com'),
    ('YouTube', 'https://m.youtube.com'),
    ('ویکی‌پدیا', 'https://fa.wikipedia.org'),
    ('Wikipedia', 'https://en.wikipedia.org'),
    ('BBC فارسی', 'https://www.bbc.com/persian'),
    ('دیجی‌کالا', 'https://www.digikala.com'),
    ('GitHub', 'https://github.com'),
    ('Gmail', 'https://mail.google.com'),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final s = context.read<Services>();
    context.watch<HistoryRepo>();
    context.watch<BookmarkRepo>();
    final tabs = context.watch<TabManager>();
    return ColoredBox(
      color: cs.surface,
      child: SafeArea(
        bottom: false,
        child: CustomScrollView(slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 48, 20, 8),
              child: Column(children: [
                Icon(incognito ? Icons.visibility_off_outlined : Icons.format_textdirection_r_to_l, size: 44, color: cs.primary),
                const SizedBox(height: 10),
                Text(incognito ? 'تب ناشناس' : 'مرورگر راست‌چین', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                if (incognito) Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('تاریخچه، کوکی و داده‌های این تب پس از بستن پاک می‌شود.', style: TextStyle(color: cs.onSurfaceVariant), textAlign: TextAlign.center),
                ),
                const SizedBox(height: 24),
                Material(
                  color: cs.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(28),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(28),
                    onTap: onSearchTap,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
                      child: Row(children: [
                        Icon(Icons.search, color: cs.onSurfaceVariant),
                        const SizedBox(width: 12),
                        Text('جستجو در Google یا وارد کردن نشانی', style: TextStyle(color: cs.onSurfaceVariant)),
                      ]),
                    ),
                  ),
                ),
              ]),
            ),
          ),
          const SliverToBoxAdapter(child: SectionHeader('سایت‌های محبوب')),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            sliver: SliverGrid.count(
              crossAxisCount: 4, childAspectRatio: .95,
              children: [for (final p in popular) _Tile(title: p.$1, url: p.$2, onTap: () => onOpen(p.$2))],
            ),
          ),
          if (!incognito) ...[
            SliverToBoxAdapter(
              child: FutureBuilder<List<HistoryEntry>>(
                future: s.history.topSites(limit: 8),
                builder: (_, snap) {
                  final items = snap.data ?? [];
                  if (items.isEmpty) return const SizedBox.shrink();
                  return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const SectionHeader('پربازدیدها'),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: GridView.count(
                        crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: .95,
                        children: [for (final h in items) _Tile(title: h.title.isEmpty ? h.url : h.title, url: h.url, onTap: () => onOpen(h.url))],
                      ),
                    ),
                  ]);
                },
              ),
            ),
            SliverToBoxAdapter(
              child: FutureBuilder<List<Bookmark>>(
                future: s.bookmarks.recent(limit: 6),
                builder: (_, snap) {
                  final items = snap.data ?? [];
                  if (items.isEmpty) return const SizedBox.shrink();
                  return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const SectionHeader('نشانک‌ها'),
                    for (final b in items)
                      ListTile(leading: SiteIcon(url: b.url), title: Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: LtrText(b.url), onTap: () => onOpen(b.url)),
                  ]);
                },
              ),
            ),
            SliverToBoxAdapter(
              child: FutureBuilder<List<HistoryEntry>>(
                future: s.history.list(limit: 6),
                builder: (_, snap) {
                  final items = snap.data ?? [];
                  if (items.isEmpty) return const SizedBox.shrink();
                  return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const SectionHeader('بازدیدهای اخیر'),
                    for (final h in items)
                      ListTile(
                        leading: SiteIcon(url: h.url), title: Text(h.title.isEmpty ? h.url : h.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(relativeTime(h.visitedAt)), onTap: () => onOpen(h.url)),
                  ]);
                },
              ),
            ),
            if (tabs.recentlyClosed.isNotEmpty)
              SliverToBoxAdapter(
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const SectionHeader('تب‌های بسته‌شده اخیر'),
                  for (final c in tabs.recentlyClosed.take(4))
                    ListTile(leading: SiteIcon(url: c.url), title: Text(c.title.isEmpty ? c.url : c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: const Icon(Icons.restore), onTap: () => tabs.reopenClosed(c)),
                ]),
              ),
          ],
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ]),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.title, required this.url, required this.onTap});
  final String title, url;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHigh, borderRadius: BorderRadius.circular(16)),
              child: SiteIcon(url: url, size: 26),
            ),
            const SizedBox(height: 6),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.labelMedium),
          ]),
        ),
      );
}
