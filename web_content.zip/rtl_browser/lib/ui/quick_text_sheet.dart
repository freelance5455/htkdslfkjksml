import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../presets/preset_store.dart';
import '../settings/app_settings.dart';
import '../site_prefs/site_prefs_store.dart';
import '../text_engine/text_settings.dart';
import 'text_controls.dart';

/// Floating bottom sheet for changing text formatting while browsing. Every change is applied
/// live (no reload) through the listeners in WebTabView.
class QuickTextSheet extends StatelessWidget {
  const QuickTextSheet({super.key, required this.host, required this.readerOpen, required this.onToggleReader, required this.readerAvailable});
  final String host;
  final bool readerOpen;
  final bool readerAvailable;
  final VoidCallback onToggleReader;

  static Future<void> show(BuildContext context, {required String host, required bool readerOpen, required bool readerAvailable, required VoidCallback onToggleReader}) =>
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        barrierColor: Colors.black12, // keep the page visible to preview changes
        builder: (_) => QuickTextSheet(host: host, readerOpen: readerOpen, readerAvailable: readerAvailable, onToggleReader: onToggleReader),
      );

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final sites = context.watch<SitePrefsStore>();
    final presets = context.watch<PresetStore>();
    final forSite = host.isNotEmpty && sites.matchKey(host) != null;
    final TextSettings t = forSite ? sites.get(host)! : settings.text;
    void set(TextSettings v, {String? presetId}) => forSite ? sites.set(host, v) : settings.setText(v, presetId: presetId);
    final cs = Theme.of(context).colorScheme;

    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: .55,
      minChildSize: .3,
      maxChildSize: .92,
      builder: (_, scroll) => ListView(controller: scroll, children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(children: [
            Text('نمایش متن', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            const Spacer(),
            Switch(value: t.enabled, onChanged: (v) => set(t.copyWith(enabled: v))),
          ]),
        ),
        if (host.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: SegmentedButton<bool>(
              showSelectedIcon: false,
              segments: [
                const ButtonSegment(value: false, label: Text('همه سایت‌ها'), icon: Icon(Icons.public, size: 18)),
                ButtonSegment(value: true, label: Text('فقط $host', overflow: TextOverflow.ellipsis), icon: const Icon(Icons.push_pin_outlined, size: 18)),
              ],
              selected: {forSite},
              onSelectionChanged: (s) => s.first ? sites.set(host, settings.text) : sites.reset(host),
            ),
          ),
        if (forSite)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
            child: Text('تنظیمات این سایت ذخیره شد و هر بار خودکار اعمال می‌شود.', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: FilledButton.tonalIcon(
            onPressed: readerAvailable || readerOpen ? () { Navigator.pop(context); onToggleReader(); } : null,
            icon: Icon(readerOpen ? Icons.web : Icons.chrome_reader_mode_outlined),
            label: Text(readerOpen ? 'بازگشت به حالت عادی' : (readerAvailable ? 'حالت مطالعه' : 'حالت مطالعه برای این صفحه در دسترس نیست')),
          ),
        ),
        SizedBox(
          height: 56,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            children: [
              for (final p in presets.all)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ActionChip(
                    avatar: Icon(settings.activePresetId == p.id && !forSite ? Icons.check : Icons.tune, size: 16),
                    label: Text(p.name),
                    onPressed: () => set(p.settings, presetId: p.id),
                  ),
                ),
              ActionChip(
                avatar: const Icon(Icons.add, size: 16),
                label: const Text('ذخیره به‌عنوان Preset'),
                onPressed: () async {
                  final c = TextEditingController();
                  final name = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
                    title: const Text('نام Preset'),
                    content: TextField(controller: c, autofocus: true),
                    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('ذخیره'))],
                  ));
                  if (name != null && name.trim().isNotEmpty) presets.add(name.trim(), t);
                },
              ),
            ],
          ),
        ),
        AnimatedOpacity(
          duration: const Duration(milliseconds: 150),
          opacity: t.enabled ? 1 : .4,
          child: IgnorePointer(
            ignoring: !t.enabled,
            child: TextControls(value: t, onChanged: (v) => set(v), compact: true, showReader: readerOpen),
          ),
        ),
        if (forSite)
          TextButton.icon(onPressed: () => sites.reset(host), icon: const Icon(Icons.restart_alt), label: const Text('ریست تنظیمات این سایت')),
        const SizedBox(height: 24),
      ]),
    );
  }
}
