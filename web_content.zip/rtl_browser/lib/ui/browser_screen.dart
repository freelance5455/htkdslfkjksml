import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../app/services.dart';
import '../core/url_utils.dart';
import '../downloads/download_manager.dart';
import '../tabs/browser_tab.dart';
import '../tabs/tab_manager.dart';
import 'bookmarks_screen.dart';
import 'downloads_screen.dart';
import 'history_screen.dart';
import 'home_page.dart';
import 'quick_text_sheet.dart';
import 'search_page.dart';
import 'settings/settings_screen.dart';
import 'tabs_screen.dart';
import 'web_tab_view.dart';
import 'widgets/common.dart';

class BrowserScreen extends StatefulWidget {
  const BrowserScreen({super.key});
  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> with WidgetsBindingObserver {
  late final Services s = context.read<Services>();
  bool _toolbarVisible = true;
  bool _immersive = false;
  bool _videoFullscreen = false;
  final Map<String, int> _lastScrollY = {};
  DateTime? _lastBack;
  final _findCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _findCtl.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) s.tabs.save();
    if (state == AppLifecycleState.detached && s.settings.clearDataOnExit) _clearBrowsingData();
  }

  Future<void> _clearBrowsingData() async {
    await s.history.clear();
    await CookieManager.instance().deleteAllCookies();
    await InAppWebViewController.clearAllCache();
  }

  BrowserTab get _tab => s.tabs.active;

  // ---------- navigation ----------
  void _navigate(BrowserTab tab, String input) {
    final url = UrlUtils.resolve(input);
    if (url == UrlUtils.homeUrl) { _goHome(); return; }
    tab.load(url);
    s.tabs.ensureAlive(tab);
    setState(() => _toolbarVisible = true);
  }

  void _goHome() { _tab.showHome = true; _tab.readerOpen = false; _tab.touch(); setState(() {}); }

  Future<void> _openSearch() async {
    final t = _tab;
    final initial = t.showHome ? '' : (UrlUtils.googleQuery(t.url) ?? (t.isHomeOnly ? '' : t.url));
    final v = await SearchPage.open(context, initial: initial, incognito: t.incognito);
    if (v != null) _navigate(t, v);
  }

  Future<void> _onBack() async {
    final t = _tab;
    if (_videoFullscreen) { await t.controller?.evaluateJavascript(source: 'document.exitFullscreen&&document.exitFullscreen()'); return; }
    if (t.findOpen) { _closeFind(); return; }
    if (t.readerOpen) { await _toggleReader(); return; }
    if (_immersive) { _setImmersive(false); return; }
    if (t.showHome && t.hasWebView && !t.isHomeOnly) { t.showHome = false; t.touch(); setState(() {}); return; }
    final c = t.controller;
    if (!t.showHome && c != null && await c.canGoBack()) { await c.goBack(); return; }
    if (t.openerId != null || t.windowId != null) { s.tabs.close(t); return; }
    if (!t.showHome && !t.isHomeOnly) { _goHome(); return; }
    final now = DateTime.now();
    if (_lastBack != null && now.difference(_lastBack!) < const Duration(seconds: 2)) {
      s.tabs.save();
      SystemNavigator.pop();
    } else {
      _lastBack = now;
      toast(context, 'برای خروج دوباره «بازگشت» را بزنید');
    }
  }

  // ---------- toolbar auto-hide ----------
  void _onScroll(BrowserTab tab, int y) {
    if (tab != _tab || !s.settings.hideToolbarOnScroll) return;
    final last = _lastScrollY[tab.id] ?? 0;
    final dy = y - last;
    _lastScrollY[tab.id] = y;
    if (y < 48 && !_toolbarVisible) { setState(() => _toolbarVisible = true); return; }
    if (dy > 10 && _toolbarVisible) setState(() => _toolbarVisible = false);
    if (dy < -14 && !_toolbarVisible) setState(() => _toolbarVisible = true);
  }

  void _setImmersive(bool v) {
    setState(() => _immersive = v);
    SystemChrome.setEnabledSystemUIMode(v ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge);
  }

  void _onFullscreen(bool entered) {
    setState(() => _videoFullscreen = entered);
    SystemChrome.setEnabledSystemUIMode(entered || _immersive ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(entered ? [] : [DeviceOrientation.portraitUp, DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  }

  // ---------- windows / downloads / long-press ----------
  void _onOpenWindow(BrowserTab opener, CreateWindowAction action) {
    s.tabs.open(windowId: action.windowId, openerId: opener.id, incognito: opener.incognito);
  }

  Future<void> _onDownload(BrowserTab tab, DownloadStartRequest req) async {
    final item = await s.downloads.enqueue(req, controller: tab.controller, referer: tab.url);
    if (!mounted) return;
    if (item == null) { toast(context, 'دانلود ممکن نشد'); return; }
    toast(context, 'دانلود «${item.fileName}» شروع شد',
        action: SnackBarAction(label: 'دانلودها', onPressed: () => _push(const DownloadsScreen())));
  }

  Future<void> _onLongPress(BrowserTab tab, InAppWebViewHitTestResult hit) async {
    final type = hit.type;
    String? link, image;
    if (type == InAppWebViewHitTestResultType.SRC_ANCHOR_TYPE) link = hit.extra;
    if (type == InAppWebViewHitTestResultType.IMAGE_TYPE) image = hit.extra;
    if (type == InAppWebViewHitTestResultType.SRC_IMAGE_ANCHOR_TYPE) {
      image = hit.extra;
      link = (await tab.controller?.requestFocusNodeHref())?.url?.toString();
    }
    if (link == null && image == null) return;
    if (!mounted) return;
    HapticFeedback.selectionClick();
    await showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: LtrText(link ?? image ?? '', style: Theme.of(ctx).textTheme.bodySmall, maxLines: 2)),
          if (link != null) ...[
            ListTile(leading: const Icon(Icons.open_in_new), title: const Text('باز کردن در تب جدید'),
                onTap: () { Navigator.pop(ctx); s.tabs.open(url: link, openerId: tab.id, incognito: tab.incognito, background: s.settings.openLinksInBackground); toast(context, 'در تب جدید باز شد'); }),
            if (!tab.incognito)
              ListTile(leading: const Icon(Icons.visibility_off_outlined), title: const Text('باز کردن در تب ناشناس'),
                  onTap: () { Navigator.pop(ctx); s.tabs.open(url: link, incognito: true); }),
            ListTile(leading: const Icon(Icons.copy), title: const Text('کپی پیوند'),
                onTap: () { Clipboard.setData(ClipboardData(text: link!)); Navigator.pop(ctx); }),
            ListTile(leading: const Icon(Icons.share_outlined), title: const Text('اشتراک‌گذاری پیوند'),
                onTap: () { Navigator.pop(ctx); Share.share(link!); }),
            ListTile(leading: const Icon(Icons.download_outlined), title: const Text('دانلود پیوند'),
                onTap: () { Navigator.pop(ctx); _onDownload(tab, DownloadStartRequest(url: WebUri(link!), userAgent: s.mobileUserAgent, contentLength: -1)); }),
          ],
          if (image != null) ...[
            ListTile(leading: const Icon(Icons.image_outlined), title: const Text('باز کردن تصویر در تب جدید'),
                onTap: () { Navigator.pop(ctx); s.tabs.open(url: image, openerId: tab.id, incognito: tab.incognito); }),
            ListTile(leading: const Icon(Icons.download_outlined), title: const Text('ذخیره تصویر'),
                onTap: () { Navigator.pop(ctx); _onDownload(tab, DownloadStartRequest(url: WebUri(image!), userAgent: s.mobileUserAgent, contentLength: -1)); }),
            ListTile(leading: const Icon(Icons.copy), title: const Text('کپی نشانی تصویر'),
                onTap: () { Clipboard.setData(ClipboardData(text: image!)); Navigator.pop(ctx); }),
          ],
        ]),
      ),
    );
  }

  // ---------- reader / find ----------
  Future<void> _toggleReader() async {
    final t = _tab;
    final c = t.controller;
    if (c == null) return;
    if (t.readerOpen) {
      await s.reader.close(c);
      t.readerOpen = false;
    } else {
      final ok = await s.reader.open(c, s.engine.effectiveFor(t.host));
      t.readerOpen = ok;
      if (!ok && mounted) toast(context, 'متن اصلی این صفحه پیدا نشد');
    }
    t.touch();
    setState(() => _toolbarVisible = true);
  }

  void _openFind() { _tab.findOpen = true; _tab.touch(); setState(() {}); }
  void _closeFind() {
    _tab.findController?.clearMatches();
    _tab.findOpen = false;
    _findCtl.clear();
    _tab.touch();
    setState(() {});
  }

  void _push(Widget page) async {
    final r = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => page));
    if (r != null) _navigate(_tab, r);
  }

  Future<void> _share() async {
    final t = _tab;
    if (t.readerOpen && t.controller != null) {
      final sel = await s.reader.selectedText(t.controller!);
      if (sel.trim().isNotEmpty) { await Share.share(sel); return; }
    }
    if (!t.isHomeOnly) await Share.share(t.url, subject: t.title);
  }

  Future<void> _toggleBookmark() async {
    final t = _tab;
    if (t.isHomeOnly || t.showHome) return;
    final existing = await s.bookmarks.find(t.url);
    if (existing != null) {
      await s.bookmarks.remove(existing.id);
      if (mounted) toast(context, 'از نشانک‌ها حذف شد');
    } else {
      await s.bookmarks.add(t.url, t.title);
      if (mounted) toast(context, 'به نشانک‌ها اضافه شد', action: SnackBarAction(label: 'ویرایش', onPressed: () => _push(const BookmarksScreen())));
    }
  }

  Future<void> _toggleDesktop() async {
    final t = _tab;
    t.desktopMode = !t.desktopMode;
    final c = t.controller;
    if (c != null) {
      final cur = await c.getSettings();
      if (cur != null) {
        cur.userAgent = t.desktopMode ? s.desktopUserAgent() : (s.mobileUserAgent ?? '');
        cur.preferredContentMode = t.desktopMode ? UserPreferredContentMode.DESKTOP : UserPreferredContentMode.RECOMMENDED;
        await c.setSettings(settings: cur);
        await c.reload();
      }
    }
    t.touch();
  }

  void _showMenu() {
    final t = _tab;
    final pageOpen = !t.showHome && !t.isHomeOnly;
    showModalBottomSheet(
      context: context,
      builder: (ctx) {
        Widget item(IconData i, String label, VoidCallback onTap, {bool enabled = true, bool active = false}) => InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: enabled ? () { Navigator.pop(ctx); onTap(); } : null,
              child: Opacity(
                opacity: enabled ? 1 : .35,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(i, color: active ? Theme.of(ctx).colorScheme.primary : null),
                  const SizedBox(height: 6),
                  Text(label, style: const TextStyle(fontSize: 11.5), textAlign: TextAlign.center, maxLines: 2),
                ]),
              ),
            );
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: GridView.count(
              crossAxisCount: 4, shrinkWrap: true, childAspectRatio: 1.05,
              children: [
                item(Icons.refresh, 'بارگذاری مجدد', () => t.controller?.reload(), enabled: pageOpen),
                item(Icons.home_outlined, 'خانه', _goHome),
                item(Icons.bookmark_add_outlined, 'نشانک', _toggleBookmark, enabled: pageOpen),
                item(Icons.share_outlined, 'اشتراک‌گذاری', _share, enabled: pageOpen),
                item(Icons.text_fields, 'تنظیمات متن', _openQuickText),
                item(Icons.chrome_reader_mode_outlined, 'حالت مطالعه', _toggleReader, enabled: pageOpen && (t.readerAvailable || t.readerOpen), active: t.readerOpen),
                item(Icons.find_in_page_outlined, 'جستجو در صفحه', _openFind, enabled: pageOpen),
                item(Icons.fullscreen, 'تمام‌صفحه', () => _setImmersive(true)),
                item(Icons.bookmarks_outlined, 'نشانک‌ها', () => _push(const BookmarksScreen())),
                item(Icons.history, 'تاریخچه', () => _push(const HistoryScreen())),
                item(Icons.download_outlined, 'دانلودها', () => _push(const DownloadsScreen())),
                item(Icons.desktop_windows_outlined, t.desktopMode ? 'نسخه موبایل' : 'نسخه دسکتاپ', _toggleDesktop, enabled: pageOpen, active: t.desktopMode),
                item(Icons.add, 'تب جدید', () => s.tabs.open()),
                item(Icons.visibility_off_outlined, 'تب ناشناس', () => s.tabs.open(incognito: true)),
                item(Icons.copy, 'کپی متن مقاله', () async {
                  final txt = t.controller == null ? '' : await s.reader.articleText(t.controller!);
                  if (txt.isNotEmpty) { Clipboard.setData(ClipboardData(text: txt)); toast(context, 'متن کپی شد'); }
                }, enabled: t.readerOpen),
                item(Icons.settings_outlined, 'تنظیمات', () => _push(const SettingsScreen())),
              ],
            ),
          ),
        );
      },
    );
  }

  void _openQuickText() => QuickTextSheet.show(context,
      host: _tab.showHome ? '' : _tab.host,
      readerOpen: _tab.readerOpen,
      readerAvailable: _tab.readerAvailable,
      onToggleReader: _toggleReader);

  void _openTabs() async {
    final r = await Navigator.of(context).push<String>(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (_, __, ___) => const TabsScreen(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: ScaleTransition(scale: Tween(begin: .96, end: 1.0).animate(a), child: child)),
    ));
    if (r != null) _navigate(_tab, r);
  }

  // ---------- build ----------
  @override
  Widget build(BuildContext context) {
    final tabs = context.watch<TabManager>();
    final active = tabs.active;
    final alive = tabs.aliveIds;
    final callbacks = WebTabCallbacks(
      onScroll: _onScroll, onOpenWindow: _onOpenWindow, onCloseWindow: (t) => s.tabs.close(t),
      onDownload: _onDownload, onLongPress: _onLongPress, onFullscreen: _onFullscreen,
    );
    final chromeHidden = _immersive || _videoFullscreen;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) { if (!didPop) _onBack(); },
      child: Scaffold(
        body: ListenableBuilder(
          listenable: active,
          builder: (context, _) {
            final cs = Theme.of(context).colorScheme;
            return Column(children: [
              if (!chromeHidden) SizedBox(height: MediaQuery.paddingOf(context).top, child: ColoredBox(color: active.incognito ? const Color(0xFF2B2B33) : cs.surface)),
              SizedBox(
                height: 2,
                child: AnimatedOpacity(
                  opacity: active.progress < 100 && !active.showHome ? 1 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: LinearProgressIndicator(value: active.progress / 100, minHeight: 2, backgroundColor: Colors.transparent),
                ),
              ),
              if (active.findOpen) _FindBar(tab: active, controller: _findCtl, onClose: _closeFind),
              Expanded(
                child: Stack(fit: StackFit.expand, children: [
                  for (final t in tabs.tabs)
                    if (alive.contains(t.id) && (!t.isHomeOnly || t.pendingUrl != null || (t.windowId != null && !t.windowUsed) || t.hasWebView))
                      Offstage(
                        offstage: t != active,
                        child: TickerMode(enabled: t == active, child: WebTabView(key: ValueKey(t.id), tab: t, callbacks: callbacks)),
                      ),
                  if (active.showHome)
                    HomePage(incognito: active.incognito, onOpen: (u) => _navigate(active, u), onSearchTap: _openSearch),
                  if (active.error != null && !active.showHome) _ErrorView(tab: active),
                  if (active.readerOpen && !chromeHidden) _ReaderFab(onClose: _toggleReader, onText: _openQuickText, onShare: _share),
                  if (_immersive && !_videoFullscreen)
                    PositionedDirectional(
                      top: MediaQuery.paddingOf(context).top + 8, end: 8,
                      child: IconButton.filledTonal(icon: const Icon(Icons.fullscreen_exit), onPressed: () => _setImmersive(false)),
                    ),
                ]),
              ),
              if (!chromeHidden)
                ClipRect(
                  child: AnimatedAlign(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOutCubic,
                    alignment: Alignment.topCenter,
                    heightFactor: _toolbarVisible || active.showHome ? 1 : 0,
                    child: _BottomBar(
                      tab: active, tabCount: tabs.tabs.length,
                      onBack: _onBack,
                      onForward: () => active.controller?.goForward(),
                      onAddress: _openSearch,
                      onText: _openQuickText,
                      onReader: _toggleReader,
                      onTabs: _openTabs,
                      onMenu: _showMenu,
                      onReload: () => active.progress < 100 ? active.controller?.stopLoading() : active.controller?.reload(),
                      downloads: context.watch<DownloadManager>().activeCount,
                    ),
                  ),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.tab, required this.tabCount, required this.onBack, required this.onForward, required this.onAddress,
    required this.onText, required this.onReader, required this.onTabs, required this.onMenu, required this.onReload, required this.downloads,
  });
  final BrowserTab tab;
  final int tabCount, downloads;
  final VoidCallback onBack, onForward, onAddress, onText, onReader, onTabs, onMenu, onReload;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final incog = tab.incognito;
    final bg = incog ? const Color(0xFF2B2B33) : cs.surfaceContainer;
    final fg = incog ? Colors.white : cs.onSurface;
    final label = tab.showHome ? 'جستجو یا نشانی' : (UrlUtils.display(tab.url).isEmpty ? 'جستجو یا نشانی' : UrlUtils.display(tab.url));
    return Material(
      color: bg,
      child: SafeArea(
        top: false,
        child: IconTheme(
          data: IconThemeData(color: fg),
          child: SizedBox(
            height: 58,
            child: Row(children: [
              IconButton(tooltip: 'بازگشت', icon: const Icon(Icons.arrow_back), onPressed: onBack),
              IconButton(tooltip: 'جلو', icon: const Icon(Icons.arrow_forward), onPressed: tab.canGoForward && !tab.showHome ? onForward : null),
              Expanded(
                child: GestureDetector(
                  onTap: onAddress,
                  onLongPress: () { if (!tab.isHomeOnly) { Clipboard.setData(ClipboardData(text: tab.url)); toast(context, 'نشانی کپی شد'); } },
                  child: Container(
                    height: 42,
                    padding: const EdgeInsetsDirectional.only(start: 12, end: 2),
                    decoration: BoxDecoration(color: incog ? Colors.white12 : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(21)),
                    child: Row(children: [
                      Icon(tab.showHome ? Icons.search : (incog ? Icons.visibility_off_outlined : (UrlUtils.isSecure(tab.url) ? Icons.lock_outline : Icons.info_outline)), size: 16),
                      const SizedBox(width: 8),
                      Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: fg, fontSize: 14))),
                      if (!tab.showHome && (tab.readerAvailable || tab.readerOpen))
                        IconButton(visualDensity: VisualDensity.compact, tooltip: 'حالت مطالعه', icon: Icon(Icons.chrome_reader_mode_outlined, size: 20, color: tab.readerOpen ? cs.primary : fg), onPressed: onReader),
                      if (!tab.showHome)
                        IconButton(visualDensity: VisualDensity.compact, tooltip: tab.progress < 100 ? 'توقف' : 'بارگذاری مجدد', icon: Icon(tab.progress < 100 ? Icons.close : Icons.refresh, size: 20), onPressed: onReload),
                    ]),
                  ),
                ),
              ),
              IconButton(tooltip: 'تنظیمات متن', icon: const Icon(Icons.text_fields), onPressed: onText),
              InkResponse(
                onTap: onTabs,
                radius: 24,
                child: Container(
                  width: 26, height: 26, margin: const EdgeInsets.symmetric(horizontal: 6), alignment: Alignment.center,
                  decoration: BoxDecoration(border: Border.all(color: fg, width: 1.8), borderRadius: BorderRadius.circular(7)),
                  child: Text(tabCount > 99 ? '∞' : '$tabCount', style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w800, height: 1)),
                ),
              ),
              Badge(
                isLabelVisible: downloads > 0, label: Text('$downloads'), offset: const Offset(-4, 6),
                child: IconButton(tooltip: 'منو', icon: const Icon(Icons.more_vert), onPressed: onMenu),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class _FindBar extends StatelessWidget {
  const _FindBar({required this.tab, required this.controller, required this.onClose});
  final BrowserTab tab;
  final TextEditingController controller;
  final VoidCallback onClose;
  @override
  Widget build(BuildContext context) => Material(
        color: Theme.of(context).colorScheme.surfaceContainer,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: controller, autofocus: true,
                decoration: const InputDecoration(hintText: 'جستجو در صفحه', border: InputBorder.none),
                onChanged: (v) => v.isEmpty ? tab.findController?.clearMatches() : tab.findController?.findAll(find: v),
              ),
            ),
            Text(tab.findMatches == 0 ? '' : '${tab.findActive}/${tab.findMatches}'),
            IconButton(icon: const Icon(Icons.keyboard_arrow_up), onPressed: () => tab.findController?.findNext(forward: false)),
            IconButton(icon: const Icon(Icons.keyboard_arrow_down), onPressed: () => tab.findController?.findNext(forward: true)),
            IconButton(icon: const Icon(Icons.close), onPressed: onClose),
          ]),
        ),
      );
}

class _ReaderFab extends StatelessWidget {
  const _ReaderFab({required this.onClose, required this.onText, required this.onShare});
  final VoidCallback onClose, onText, onShare;
  @override
  Widget build(BuildContext context) => PositionedDirectional(
        bottom: 16, end: 16,
        child: Material(
          elevation: 3, borderRadius: BorderRadius.circular(28), color: Theme.of(context).colorScheme.surfaceContainerHigh,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(tooltip: 'متن', icon: const Icon(Icons.text_fields), onPressed: onText),
            IconButton(tooltip: 'اشتراک متن انتخاب‌شده/نشانی', icon: const Icon(Icons.share_outlined), onPressed: onShare),
            IconButton(tooltip: 'خروج از حالت مطالعه', icon: const Icon(Icons.close), onPressed: onClose),
          ]),
        ),
      );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.tab});
  final BrowserTab tab;
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ColoredBox(
      color: cs.surface,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.cloud_off_outlined, size: 56, color: cs.outline),
            const SizedBox(height: 16),
            Text('صفحه باز نشد', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            LtrText(UrlUtils.host(tab.url), style: TextStyle(color: cs.onSurfaceVariant)),
            const SizedBox(height: 4),
            Text(tab.error ?? '', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12), textDirection: TextDirection.ltr),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: () { tab.error = null; tab.touch(); tab.controller?.reload(); }, icon: const Icon(Icons.refresh), label: const Text('تلاش دوباره')),
          ]),
        ),
      ),
    );
  }
}
