import 'package:flutter/material.dart';

import '../../core/url_utils.dart';

/// Favicon with a letter fallback (no third-party favicon services: privacy).
class SiteIcon extends StatelessWidget {
  const SiteIcon({super.key, this.faviconUrl, required this.url, this.size = 20});
  final String? faviconUrl;
  final String url;
  final double size;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final host = UrlUtils.host(url);
    final letter = host.isEmpty ? '•' : host.characters.first.toUpperCase();
    final fallback = Container(
      width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(size / 3.5)),
      child: Text(letter, style: TextStyle(fontSize: size * .55, color: cs.onPrimaryContainer, fontWeight: FontWeight.w700, height: 1)),
    );
    if (faviconUrl == null || faviconUrl!.isEmpty) return fallback;
    return ClipRRect(
      borderRadius: BorderRadius.circular(size / 4),
      child: Image.network(faviconUrl!, width: size, height: size, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => fallback, gaplessPlayback: true),
    );
  }
}

class SectionHeader extends StatelessWidget {
  const SectionHeader(this.text, {super.key, this.trailing});
  final String text;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.fromSTEB(20, 20, 12, 8),
        child: Row(children: [
          Expanded(child: Text(text, style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700))),
          if (trailing != null) trailing!,
        ]),
      );
}

/// LTR isolation for URLs shown inside RTL UI.
class LtrText extends StatelessWidget {
  const LtrText(this.text, {super.key, this.style, this.maxLines = 1});
  final String text;
  final TextStyle? style;
  final int maxLines;
  @override
  Widget build(BuildContext context) => Text(text, textDirection: TextDirection.ltr, maxLines: maxLines,
      overflow: TextOverflow.ellipsis, style: style, textAlign: TextAlign.right);
}

Future<String?> promptText(BuildContext context, {required String title, String initial = '', String hint = '', String ok = 'ذخیره'}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, autofocus: true, decoration: InputDecoration(hintText: hint), onSubmitted: (v) => Navigator.pop(ctx, v)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(ok)),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext context, String title, {String body = '', String ok = 'تأیید', bool destructive = false}) async =>
    await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: body.isEmpty ? null : Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(
            style: destructive ? FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error) : null,
            onPressed: () => Navigator.pop(ctx, true), child: Text(ok)),
        ],
      ),
    ) ??
    false;

void toast(BuildContext context, String msg, {SnackBarAction? action}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg), action: action, behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 3)));
}

String relativeTime(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'همین حالا';
  if (d.inHours < 1) return '${d.inMinutes} دقیقه پیش';
  if (d.inDays < 1) return '${d.inHours} ساعت پیش';
  if (d.inDays < 7) return '${d.inDays} روز پیش';
  return '${t.year}/${t.month.toString().padLeft(2, '0')}/${t.day.toString().padLeft(2, '0')}';
}

String formatBytes(int b) {
  if (b <= 0) return '—';
  const u = ['B', 'KB', 'MB', 'GB'];
  var v = b.toDouble();
  var i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${u[i]}';
}
