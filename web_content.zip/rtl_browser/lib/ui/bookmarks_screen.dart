import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../bookmarks/bookmark_repo.dart';
import 'widgets/common.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key, this.folder});
  final BookmarkFolder? folder;
  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  String _q = '';
  bool _searching = false;

  Future<void> _edit(Bookmark b) async {
    final repo = context.read<BookmarkRepo>();
    final title = TextEditingController(text: b.title), url = TextEditingController(text: b.url);
    final folders = await repo.allFolders();
    int? folderId = b.folderId;
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('ویرایش نشانک'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'نام')),
            TextField(controller: url, decoration: const InputDecoration(labelText: 'نشانی'), textDirection: TextDirection.ltr),
            const SizedBox(height: 12),
            DropdownButtonFormField<int?>(
              value: folderId,
              decoration: const InputDecoration(labelText: 'پوشه'),
              items: [const DropdownMenuItem(value: null, child: Text('بدون پوشه')), for (final f in folders) DropdownMenuItem(value: f.id, child: Text(f.name))],
              onChanged: (v) => setD(() => folderId = v),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ذخیره')),
          ],
        ),
      ),
    );
    if (ok == true) await repo.update(b.id, title: title.text, url: url.text, folderId: folderId, clearFolder: folderId == null);
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<BookmarkRepo>();
    final folder = widget.folder;
    return Scaffold(
      appBar: AppBar(
        title: _searching
            ? TextField(autofocus: true, decoration: const InputDecoration(hintText: 'جستجو در نشانک‌ها', border: InputBorder.none), onChanged: (v) => setState(() => _q = v))
            : Text(folder?.name ?? 'نشانک‌ها'),
        actions: [
          IconButton(icon: Icon(_searching ? Icons.close : Icons.search), onPressed: () => setState(() { _searching = !_searching; _q = ''; })),
          IconButton(
            tooltip: 'پوشه جدید',
            icon: const Icon(Icons.create_new_folder_outlined),
            onPressed: () async {
              final n = await promptText(context, title: 'پوشه جدید', hint: 'نام پوشه');
              if (n != null && n.trim().isNotEmpty) repo.addFolder(n.trim(), parentId: folder?.id);
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: Future.wait([
          _q.isEmpty ? repo.folders(parentId: folder?.id) : Future.value(<BookmarkFolder>[]),
          repo.list(folderId: folder?.id, query: _q),
        ]),
        builder: (_, snap) {
          if (!snap.hasData) return const SizedBox.shrink();
          final folders = snap.data![0] as List<BookmarkFolder>;
          final items = snap.data![1] as List<Bookmark>;
          if (folders.isEmpty && items.isEmpty) return const Center(child: Text('نشانکی نیست'));
          return ListView(children: [
            for (final f in folders)
              ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: Text(f.name),
                onTap: () async {
                  final r = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => BookmarksScreen(folder: f)));
                  if (r != null && context.mounted) Navigator.pop(context, r);
                },
                trailing: PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'rename') {
                      final n = await promptText(context, title: 'تغییر نام پوشه', initial: f.name);
                      if (n != null && n.trim().isNotEmpty) repo.renameFolder(f.id, n.trim());
                    } else if (await confirm(context, 'پوشه «${f.name}» حذف شود؟', body: 'نشانک‌های داخل آن به پوشه بالاتر منتقل می‌شوند.', destructive: true, ok: 'حذف')) {
                      repo.removeFolder(f.id);
                    }
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'rename', child: Text('تغییر نام')), PopupMenuItem(value: 'delete', child: Text('حذف'))],
                ),
              ),
            for (final b in items)
              Dismissible(
                key: ValueKey('b${b.id}'),
                direction: DismissDirection.endToStart,
                background: Container(color: Theme.of(context).colorScheme.errorContainer, alignment: AlignmentDirectional.centerEnd, padding: const EdgeInsets.symmetric(horizontal: 20), child: const Icon(Icons.delete_outline)),
                onDismissed: (_) {
                  repo.remove(b.id);
                  toast(context, 'حذف شد', action: SnackBarAction(label: 'بازگردانی', onPressed: () => repo.add(b.url, b.title, folderId: b.folderId)));
                },
                child: ListTile(
                  leading: SiteIcon(url: b.url),
                  title: Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: LtrText(b.url),
                  onTap: () => Navigator.pop(context, b.url),
                  trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _edit(b)),
                ),
              ),
          ]);
        },
      ),
    );
  }
}
