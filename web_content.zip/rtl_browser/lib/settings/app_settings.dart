import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../text_engine/text_settings.dart';

/// Browser-wide settings. Persisted locally only.
class AppSettings extends ChangeNotifier {
  AppSettings(this._prefs) {
    final raw = _prefs.getString(_key);
    final j = raw == null ? <String, dynamic>{} : Map<String, dynamic>.from(jsonDecode(raw));
    _themeMode = ThemeMode.values.firstWhere((m) => m.name == j['themeMode'], orElse: () => ThemeMode.system);
    _text = TextSettings.fromJson(j['text'] == null ? null : Map<String, dynamic>.from(j['text']));
    searchSuggestions = j['searchSuggestions'] ?? true;
    hideToolbarOnScroll = j['hideToolbarOnScroll'] ?? true;
    restoreTabs = j['restoreTabs'] ?? true;
    javaScriptEnabled = j['javaScriptEnabled'] ?? true;
    blockPopups = j['blockPopups'] ?? true;
    webDarkMode = j['webDarkMode'] ?? false;
    pullToRefresh = j['pullToRefresh'] ?? true;
    openLinksInBackground = j['openLinksInBackground'] ?? false;
    askDownloadLocation = j['askDownloadLocation'] ?? false;
    clearDataOnExit = j['clearDataOnExit'] ?? false;
    thirdPartyCookies = j['thirdPartyCookies'] ?? true;
    activePresetId = j['activePresetId'];
  }

  final SharedPreferences _prefs;
  static const _key = 'app_settings';

  late ThemeMode _themeMode;
  late TextSettings _text;
  late bool searchSuggestions;
  late bool hideToolbarOnScroll;
  late bool restoreTabs;
  late bool javaScriptEnabled;
  late bool blockPopups;
  late bool webDarkMode;
  late bool pullToRefresh;
  late bool openLinksInBackground;
  late bool askDownloadLocation;
  late bool clearDataOnExit;
  late bool thirdPartyCookies;
  String? activePresetId;

  ThemeMode get themeMode => _themeMode;
  TextSettings get text => _text;

  set themeMode(ThemeMode m) { _themeMode = m; _commit(); }

  void setText(TextSettings t, {String? presetId}) {
    if (t == _text && presetId == activePresetId) return;
    _text = t;
    activePresetId = presetId;
    _commit();
  }

  /// Generic setter for the boolean switches in the Settings UI.
  void update(void Function(AppSettings s) change) { change(this); _commit(); }

  void _commit() {
    notifyListeners();
    _prefs.setString(_key, jsonEncode({
      'themeMode': _themeMode.name, 'text': _text.toJson(), 'searchSuggestions': searchSuggestions,
      'hideToolbarOnScroll': hideToolbarOnScroll, 'restoreTabs': restoreTabs,
      'javaScriptEnabled': javaScriptEnabled, 'blockPopups': blockPopups, 'webDarkMode': webDarkMode,
      'pullToRefresh': pullToRefresh, 'openLinksInBackground': openLinksInBackground,
      'askDownloadLocation': askDownloadLocation, 'clearDataOnExit': clearDataOnExit,
      'thirdPartyCookies': thirdPartyCookies, 'activePresetId': activePresetId,
    }));
  }
}
