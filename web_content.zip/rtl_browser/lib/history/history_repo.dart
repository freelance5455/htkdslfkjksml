import 'package:flutter/foundation.dart';

import '../core/db.dart';
import '../core/url_utils.dart';

class HistoryEntry {
  HistoryEntry({required this.id, required this.url, required this.title, required this.visitedAt});
  final int id;
  final String url;
  final String title;
  final DateTime visitedAt;
  static HistoryEntry fromRow(Map<String, Object?> r) => HistoryEntry(
      id: r['id'] as int, url: r['url'] as String, title: (r['title'] as String?) ?? '',
      visitedAt: DateTime.fromMillisecondsSinceEpoch(r['visited_at'] as int));
}

/// Local-only browsing history.
class HistoryRepo extends ChangeNotifier {
  HistoryRepo(this._db);
  final AppDatabase _db;

  Future<void> record(String url, String? title) async {
    if (!UrlUtils.isHttp(url)) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final last = await _db.db.query('history', orderBy: 'visited_at DESC', limit: 1);
    // Same page re-reported (SPA pushState / title update) within 30 min -> update in place.
    if (last.isNotEmpty && last.first['url'] == url && now - (last.first['visited_at'] as int) < 1800000) {
      await _db.db.update('history', {'title': title ?? last.first['title'], 'visited_at': now},
          where: 'id = ?', whereArgs: [last.first['id']]);
    } else {
      await _db.db.insert('history', {'url': url, 'title': title ?? '', 'host': UrlUtils.host(url), 'visited_at': now});
    }
    notifyListeners();
  }

  Future<void> updateTitle(String url, String title) async {
    await _db.db.rawUpdate(
        'UPDATE history SET title = ? WHERE id = (SELECT id FROM history WHERE url = ? ORDER BY visited_at DESC LIMIT 1)',
        [title, url]);
  }

  Future<List<HistoryEntry>> list({String query = '', int limit = 200, int offset = 0}) async {
    final q = query.trim();
    final rows = await _db.db.query('history',
        where: q.isEmpty ? null : '(title LIKE ? OR url LIKE ?)',
        whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
        orderBy: 'visited_at DESC', limit: limit, offset: offset);
    return rows.map(HistoryEntry.fromRow).toList();
  }

  /// Distinct URLs for the omnibox, most recent first.
  Future<List<HistoryEntry>> suggest(String query, {int limit = 6}) async {
    final q = query.trim();
    if (q.isEmpty) return [];
    final rows = await _db.db.rawQuery(
        'SELECT MAX(id) AS id, url, title, MAX(visited_at) AS visited_at FROM history '
        'WHERE title LIKE ? OR url LIKE ? GROUP BY url ORDER BY COUNT(*) DESC, visited_at DESC LIMIT ?',
        ['%$q%', '%$q%', limit]);
    return rows.map(HistoryEntry.fromRow).toList();
  }

  /// Most visited sites for the home page.
  Future<List<HistoryEntry>> topSites({int limit = 8}) async {
    final rows = await _db.db.rawQuery(
        'SELECT MAX(id) AS id, url, title, MAX(visited_at) AS visited_at FROM history '
        'GROUP BY host ORDER BY COUNT(*) DESC LIMIT ?', [limit]);
    return rows.map(HistoryEntry.fromRow).toList();
  }

  Future<void> delete(int id) async { await _db.db.delete('history', where: 'id = ?', whereArgs: [id]); notifyListeners(); }
  Future<void> clear() async { await _db.db.delete('history'); notifyListeners(); }
}
