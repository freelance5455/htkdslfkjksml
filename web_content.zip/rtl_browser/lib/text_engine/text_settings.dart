/// Immutable text formatting profile. Used for global settings, per-site overrides and presets.
class TextSettings {
  const TextSettings({
    this.enabled = true,
    this.fontId = 'vazirmatn',
    this.textScale = 100,
    this.weight = 400,
    this.lineHeight = 0,
    this.letterSpacing = 0,
    this.paragraphSpacing = 0,
    this.direction = 'auto',
    this.readerTheme = 'light',
    this.readerWidth = 'medium',
    this.customBg = 0xFFFFFFFF,
    this.customFg = 0xFF111111,
    this.justify = false,
  });

  final bool enabled;
  /// FontManager id, or 'site' to keep the site's own font.
  final String fontId;
  /// Percent. Android: WebView textZoom (no compounding, no reload). iOS: text-size-adjust.
  final int textScale;
  final int weight;
  /// 0 = keep the site's line-height.
  final double lineHeight;
  /// em. Applied as letter-spacing on Latin text and word-spacing on Arabic-script text.
  final double letterSpacing;
  /// em. 0 = keep the site's spacing.
  final double paragraphSpacing;
  /// auto | rtl | ltr | off
  final String direction;
  /// light | dark | sepia | black | custom (Reader Mode)
  final String readerTheme;
  /// narrow | medium | wide | full (Reader Mode)
  final String readerWidth;
  final int customBg;
  final int customFg;
  final bool justify;

  static const sizeSteps = <String, int>{
    'بسیار کوچک': 80, 'کوچک': 90, 'متوسط': 100, 'بزرگ': 115, 'بسیار بزرگ': 135,
  };
  static const weights = <String, int>{'معمولی': 400, 'متوسط': 500, 'نیمه‌بولد': 600, 'بولد': 700};
  static const directions = <String, String>{'خودکار': 'auto', 'راست‌چین': 'rtl', 'چپ‌چین': 'ltr', 'بدون تغییر': 'off'};
  static const readerThemes = <String, String>{'روشن': 'light', 'تیره': 'dark', 'سپیا': 'sepia', 'مشکی': 'black', 'سفارشی': 'custom'};
  static const readerWidths = <String, String>{'باریک': 'narrow', 'متوسط': 'medium', 'پهن': 'wide', 'تمام‌عرض': 'full'};

  TextSettings copyWith({
    bool? enabled, String? fontId, int? textScale, int? weight, double? lineHeight,
    double? letterSpacing, double? paragraphSpacing, String? direction, String? readerTheme,
    String? readerWidth, int? customBg, int? customFg, bool? justify,
  }) =>
      TextSettings(
        enabled: enabled ?? this.enabled,
        fontId: fontId ?? this.fontId,
        textScale: textScale ?? this.textScale,
        weight: weight ?? this.weight,
        lineHeight: lineHeight ?? this.lineHeight,
        letterSpacing: letterSpacing ?? this.letterSpacing,
        paragraphSpacing: paragraphSpacing ?? this.paragraphSpacing,
        direction: direction ?? this.direction,
        readerTheme: readerTheme ?? this.readerTheme,
        readerWidth: readerWidth ?? this.readerWidth,
        customBg: customBg ?? this.customBg,
        customFg: customFg ?? this.customFg,
        justify: justify ?? this.justify,
      );

  Map<String, dynamic> toJson() => {
        'enabled': enabled, 'fontId': fontId, 'textScale': textScale, 'weight': weight,
        'lineHeight': lineHeight, 'letterSpacing': letterSpacing, 'paragraphSpacing': paragraphSpacing,
        'direction': direction, 'readerTheme': readerTheme, 'readerWidth': readerWidth,
        'customBg': customBg, 'customFg': customFg, 'justify': justify,
      };

  factory TextSettings.fromJson(Map<String, dynamic>? j) {
    if (j == null) return const TextSettings();
    const d = TextSettings();
    T pick<T>(String k, T def) => j[k] is T ? j[k] as T : def;
    double dbl(String k, double def) => j[k] is num ? (j[k] as num).toDouble() : def;
    int integer(String k, int def) => j[k] is num ? (j[k] as num).toInt() : def;
    return TextSettings(
      enabled: pick('enabled', d.enabled),
      fontId: pick('fontId', d.fontId),
      textScale: integer('textScale', d.textScale).clamp(50, 250),
      weight: integer('weight', d.weight),
      lineHeight: dbl('lineHeight', d.lineHeight),
      letterSpacing: dbl('letterSpacing', d.letterSpacing),
      paragraphSpacing: dbl('paragraphSpacing', d.paragraphSpacing),
      direction: pick('direction', d.direction),
      readerTheme: pick('readerTheme', d.readerTheme),
      readerWidth: pick('readerWidth', d.readerWidth),
      customBg: integer('customBg', d.customBg),
      customFg: integer('customFg', d.customFg),
      justify: pick('justify', d.justify),
    );
  }

  @override
  bool operator ==(Object other) =>
      other is TextSettings && _mapEq(other.toJson(), toJson());
  @override
  int get hashCode => Object.hashAll(toJson().values);
  static bool _mapEq(Map a, Map b) => a.length == b.length && a.keys.every((k) => a[k] == b[k]);
}
