import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../core/debouncer.dart';
import '../fonts/font_manager.dart';
import '../settings/app_settings.dart';
import '../site_prefs/site_prefs_store.dart';
import 'text_settings.dart';

/// Bridges Dart settings and the injected JS layer (assets/js/text_engine.js).
///
/// * A document-start UserScript carries the engine + all configs (global + per-site) + only the
///   fonts actually referenced, so the right formatting is applied before first paint on every
///   navigation, with no reload.
/// * Live changes (sliders, bottom sheet) go through [applyJs] -> window.__RTLF.apply(cfg),
///   which just rewrites one stylesheet; the DOM is not rebuilt.
class TextEngineService extends ChangeNotifier {
  TextEngineService(this.settings, this.sites, this.fonts);

  final AppSettings settings;
  final SitePrefsStore sites;
  final FontManager fonts;

  static const groupName = 'rtlf';
  late final String _engineJs;
  late final String _readerJs;
  String _bootScript = '';
  int _bootVersion = 0;
  final _rebuild = Debouncer(const Duration(milliseconds: 350));

  int get bootVersion => _bootVersion;
  String get readerJs => _readerJs;

  Future<void> init() async {
    _engineJs = await rootBundle.loadString('assets/js/text_engine.js');
    _readerJs = await rootBundle.loadString('assets/js/reader.js');
    await _buildBoot();
    settings.addListener(_scheduleRebuild);
    sites.addListener(_scheduleRebuild);
    fonts.addListener(_scheduleRebuild);
  }

  void _scheduleRebuild() => _rebuild(() => _buildBoot());

  TextSettings effectiveFor(String host) => sites.get(host) ?? settings.text;
  bool hasSiteOverride(String host) => sites.matchKey(host) != null;

  String get _platform => defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android';

  Map<String, dynamic> engineConfig(TextSettings t) => {
        'enabled': t.enabled,
        'fontId': t.fontId == 'site' ? null : t.fontId,
        'fontFamily': fonts.familyCss(t.fontId),
        'weight': t.weight,
        'lineHeight': t.lineHeight,
        'letterSpacing': t.letterSpacing,
        'paragraphSpacing': t.paragraphSpacing,
        'direction': t.direction,
        'textScale': t.textScale,
      };

  Future<void> _buildBoot() async {
    final used = <String>{settings.text.fontId, ...sites.all.values.map((t) => t.fontId)};
    final fontCss = <String, String>{};
    for (final id in used) {
      final css = await fonts.fontFaceCss(id);
      if (css.isNotEmpty) fontCss[id] = css;
    }
    final boot = {
      'platform': _platform,
      'global': engineConfig(settings.text),
      'sites': sites.all.map((k, v) => MapEntry(k, engineConfig(v))),
      'fontCss': fontCss,
    };
    _bootScript = 'window.__RTLF_BOOT=${jsonEncode(boot)};\n$_engineJs';
    _bootVersion++;
    notifyListeners();
  }

  UserScript get userScript => UserScript(
        groupName: groupName,
        source: _bootScript,
        injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
        forMainFrameOnly: true,
      );

  /// JS that live-applies [t]. Ships the @font-face only when the page doesn't have it yet.
  Future<String> applyJs(TextSettings t, {required bool includeFont}) async {
    final buf = StringBuffer();
    if (includeFont && t.fontId != 'site') {
      final css = await fonts.fontFaceCss(t.fontId);
      if (css.isNotEmpty) {
        buf.write('(window.__RTLF_BOOT=window.__RTLF_BOOT||{fontCss:{}});'
            '(window.__RTLF_BOOT.fontCss=window.__RTLF_BOOT.fontCss||{})[${jsonEncode(t.fontId)}]=${jsonEncode(css)};');
      }
    }
    buf.write('(function(){if(!window.__RTLF){$_engineJs}'
        'return JSON.stringify(window.__RTLF.apply(${jsonEncode(engineConfig(t))}));})();');
    return buf.toString();
  }

  /// Options object for reader.js.
  Future<Map<String, dynamic>> readerOptions(TextSettings t) async => {
        'theme': t.readerTheme,
        'width': t.readerWidth,
        'fontFamily': fonts.familyCss(t.fontId) ?? 'system-ui, sans-serif',
        'fontFaceCss': t.fontId == 'site' ? '' : await fonts.fontFaceCss(t.fontId),
        'fontSizePx': (18 * t.textScale / 100).round(),
        'lineHeight': t.lineHeight > 0 ? t.lineHeight : 1.85,
        'weight': t.weight,
        'letterSpacing': t.letterSpacing,
        'paragraphSpacing': t.paragraphSpacing > 0 ? t.paragraphSpacing : 1.0,
        'direction': t.direction,
        'justify': t.justify,
        'customBg': '#${(t.customBg & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}',
        'customFg': '#${(t.customFg & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}',
      };

  @override
  void dispose() {
    settings.removeListener(_scheduleRebuild);
    sites.removeListener(_scheduleRebuild);
    fonts.removeListener(_scheduleRebuild);
    _rebuild.dispose();
    super.dispose();
  }
}
