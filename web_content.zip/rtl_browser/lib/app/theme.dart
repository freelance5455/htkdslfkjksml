import 'package:flutter/material.dart';

class AppTheme {
  static const _seed = Color(0xFF2F6F73);

  static ThemeData light() => _base(ColorScheme.fromSeed(seedColor: _seed));
  static ThemeData dark() => _base(ColorScheme.fromSeed(seedColor: _seed, brightness: Brightness.dark));

  static ThemeData _base(ColorScheme cs) => ThemeData(
        useMaterial3: true,
        colorScheme: cs,
        fontFamily: 'Vazirmatn',
        scaffoldBackgroundColor: cs.surface,
        splashFactory: InkSparkle.splashFactory,
        appBarTheme: AppBarTheme(backgroundColor: cs.surface, elevation: 0, scrolledUnderElevation: 1, centerTitle: false),
        bottomSheetTheme: BottomSheetThemeData(
          backgroundColor: cs.surfaceContainerLow,
          showDragHandle: true,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        ),
        listTileTheme: const ListTileThemeData(contentPadding: EdgeInsets.symmetric(horizontal: 20)),
        sliderTheme: const SliderThemeData(showValueIndicator: ShowValueIndicator.always),
        pageTransitionsTheme: const PageTransitionsTheme(builders: {
          TargetPlatform.android: PredictiveBackPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        }),
      );
}
