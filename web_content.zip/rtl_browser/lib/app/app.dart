import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import '../settings/app_settings.dart';
import '../ui/browser_screen.dart';
import 'services.dart';
import 'theme.dart';

class RtlBrowserApp extends StatelessWidget {
  const RtlBrowserApp({super.key, required this.services});
  final Services services;

  @override
  Widget build(BuildContext context) {
    final s = services;
    return MultiProvider(
      providers: [
        Provider.value(value: s),
        ChangeNotifierProvider.value(value: s.settings),
        ChangeNotifierProvider.value(value: s.fonts),
        ChangeNotifierProvider.value(value: s.sites),
        ChangeNotifierProvider.value(value: s.presets),
        ChangeNotifierProvider.value(value: s.engine),
        ChangeNotifierProvider.value(value: s.history),
        ChangeNotifierProvider.value(value: s.bookmarks),
        ChangeNotifierProvider.value(value: s.downloads),
        ChangeNotifierProvider.value(value: s.tabs),
      ],
      child: Selector<AppSettings, ThemeMode>(
        selector: (_, st) => st.themeMode,
        builder: (_, mode, __) => MaterialApp(
          title: 'مرورگر راست‌چین',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          themeMode: mode,
          locale: const Locale('fa'),
          supportedLocales: const [Locale('fa'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const BrowserScreen(),
        ),
      ),
    );
  }
}
