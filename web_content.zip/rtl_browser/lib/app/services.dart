import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../bookmarks/bookmark_repo.dart';
import '../core/db.dart';
import '../downloads/download_manager.dart';
import '../fonts/font_manager.dart';
import '../history/history_repo.dart';
import '../presets/preset_store.dart';
import '../reader/reader_controller.dart';
import '../settings/app_settings.dart';
import '../site_prefs/site_prefs_store.dart';
import '../tabs/tab_manager.dart';
import '../text_engine/text_engine_service.dart';

/// Composition root. Every module is independent and only wired together here.
class Services {
  Services._(this.prefs, this.db, this.settings, this.fonts, this.sites, this.presets, this.engine,
      this.reader, this.history, this.bookmarks, this.downloads, this.tabs, this.mobileUserAgent);

  final SharedPreferences prefs;
  final AppDatabase db;
  final AppSettings settings;
  final FontManager fonts;
  final SitePrefsStore sites;
  final PresetStore presets;
  final TextEngineService engine;
  final ReaderController reader;
  final HistoryRepo history;
  final BookmarkRepo bookmarks;
  final DownloadManager downloads;
  final TabManager tabs;
  /// Default WebView UA with the "; wv" WebView marker removed, so sites (Google included)
  /// serve their full modern mobile experience instead of a degraded WebView variant.
  final String? mobileUserAgent;

  String desktopUserAgent() {
    final chrome = RegExp(r'Chrome/([\d.]+)').firstMatch(mobileUserAgent ?? '')?.group(1) ?? '124.0.0.0';
    return 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chrome Safari/537.36';
  }

  static Future<Services> init() async {
    final prefs = await SharedPreferences.getInstance();
    final db = await AppDatabase.open();
    final settings = AppSettings(prefs);
    final fonts = FontManager(prefs);
    await fonts.init();
    final sites = SitePrefsStore(prefs);
    final presets = PresetStore(prefs);
    final engine = TextEngineService(settings, sites, fonts);
    await engine.init();
    final downloads = DownloadManager(db);
    await downloads.init();
    final tabs = TabManager(prefs)..restore(restoreSession: settings.restoreTabs);

    String? ua;
    try {
      final def = await InAppWebViewController.getDefaultUserAgent();
      ua = def.replaceAll('; wv)', ')').replaceAll(RegExp(r'Version/\d+\.\d+ '), '');
    } catch (_) {}

    return Services._(prefs, db, settings, fonts, sites, presets, engine, ReaderController(engine),
        HistoryRepo(db), BookmarkRepo(db), downloads, tabs, ua);
  }
}
