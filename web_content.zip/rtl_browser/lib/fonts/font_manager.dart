import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A font the engine can inject. Add a built-in font by dropping the file in assets/fonts/
/// and adding one FontDef line below; custom fonts are imported at runtime (TTF/OTF/WOFF/WOFF2).
@immutable
class FontDef {
  const FontDef({
    required this.id,
    required this.name,
    required this.fallback,
    this.asset,
    this.filePath,
    this.builtIn = true,
    this.rtl = true,
    this.license = '',
  });
  final String id;
  final String name;
  /// CSS fallback stack appended after the injected family.
  final String fallback;
  final String? asset;
  final String? filePath;
  final bool builtIn;
  /// Has Arabic-script glyphs.
  final bool rtl;
  final String license;

  bool get hasFile => asset != null || filePath != null;
  String get cssFamily => hasFile ? '"RTLF-$id", $fallback' : fallback;

  String get _ext => p.extension(asset ?? filePath ?? '').replaceFirst('.', '').toLowerCase();
  String get mime => switch (_ext) { 'woff2' => 'font/woff2', 'woff' => 'font/woff', 'otf' => 'font/otf', _ => 'font/ttf' };
  String get format => switch (_ext) { 'woff2' => 'woff2', 'woff' => 'woff', 'otf' => 'opentype', _ => 'truetype' };

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'filePath': filePath, 'rtl': rtl};
  static FontDef fromJson(Map<String, dynamic> j) => FontDef(
        id: j['id'], name: j['name'], filePath: j['filePath'], builtIn: false,
        rtl: j['rtl'] ?? true, fallback: 'system-ui, sans-serif');
}

class FontManager extends ChangeNotifier {
  FontManager(this._prefs);
  final SharedPreferences _prefs;
  static const _key = 'custom_fonts';

  static const List<FontDef> builtIns = [
    FontDef(id: 'vazirmatn', name: 'وزیرمتن (Vazirmatn)', asset: 'assets/fonts/Vazirmatn.woff2', fallback: 'Vazirmatn, Tahoma, sans-serif', license: 'OFL 1.1'),
    FontDef(id: 'estedad', name: 'استعداد (Estedad)', asset: 'assets/fonts/Estedad.woff2', fallback: 'Tahoma, sans-serif', license: 'OFL 1.1'),
    FontDef(id: 'naskh', name: 'نسخ (Noto Naskh Arabic)', asset: 'assets/fonts/NotoNaskhArabic.woff2', fallback: '"Noto Naskh Arabic", serif', license: 'OFL 1.1'),
    FontDef(id: 'literata', name: 'Literata (مطالعه، سریف)', asset: 'assets/fonts/Literata.woff2', fallback: 'Georgia, serif', rtl: false, license: 'OFL 1.1'),
    FontDef(id: 'inter', name: 'Inter (مطالعه، سنس)', asset: 'assets/fonts/Inter.woff2', fallback: 'system-ui, sans-serif', rtl: false, license: 'OFL 1.1'),
    FontDef(id: 'system', name: 'فونت پیش‌فرض سیستم', fallback: 'system-ui, -apple-system, Roboto, sans-serif'),
    FontDef(id: 'system_serif', name: 'سریف سیستم', fallback: 'Georgia, "Noto Serif", serif'),
    FontDef(id: 'site', name: 'فونت خود سایت (بدون تغییر)', fallback: ''),
  ];

  final List<FontDef> _custom = [];
  final Map<String, String> _cssCache = {};

  List<FontDef> get all => [...builtIns, ..._custom];
  List<FontDef> get custom => List.unmodifiable(_custom);

  Future<void> init() async {
    final raw = _prefs.getString(_key);
    if (raw == null) return;
    for (final j in (jsonDecode(raw) as List)) {
      final f = FontDef.fromJson(Map<String, dynamic>.from(j));
      if (f.filePath != null && File(f.filePath!).existsSync()) _custom.add(f);
    }
  }

  FontDef byId(String id) => all.firstWhere((f) => f.id == id, orElse: () => builtIns.first);

  /// CSS font-family value for the engine, null = keep site font.
  String? familyCss(String id) => id == 'site' ? null : byId(id).cssFamily;

  /// @font-face rule with the font embedded as a data: URL (works on every origin, CSP permitting,
  /// no network, no local server). Cached in memory after first build.
  Future<String> fontFaceCss(String id) async {
    final def = byId(id);
    if (!def.hasFile) return '';
    final cached = _cssCache[id];
    if (cached != null) return cached;
    final Uint8List bytes = def.asset != null
        ? (await rootBundle.load(def.asset!)).buffer.asUint8List()
        : await File(def.filePath!).readAsBytes();
    final b64 = await compute(base64Encode, bytes);
    final css = '@font-face{font-family:"RTLF-${def.id}";'
        'src:url(data:${def.mime};base64,$b64) format("${def.format}");'
        'font-weight:100 900;font-style:normal;font-display:swap;}';
    _cssCache[id] = css;
    return css;
  }

  /// Lets the user pick a TTF/OTF/WOFF/WOFF2 file and registers it as a page font.
  Future<FontDef?> importFont() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['ttf', 'otf', 'woff', 'woff2'],
    );
    final path = res?.files.single.path;
    if (path == null) return null;
    final dir = Directory(p.join((await getApplicationSupportDirectory()).path, 'fonts'));
    await dir.create(recursive: true);
    final id = 'custom_${DateTime.now().millisecondsSinceEpoch}';
    final dest = p.join(dir.path, '$id${p.extension(path).toLowerCase()}');
    await File(path).copy(dest);
    final def = FontDef(
      id: id, name: p.basenameWithoutExtension(path), filePath: dest, builtIn: false,
      fallback: 'system-ui, sans-serif');
    _custom.add(def);
    await _save();
    notifyListeners();
    return def;
  }

  Future<void> renameCustom(String id, String name) async {
    final i = _custom.indexWhere((f) => f.id == id);
    if (i < 0) return;
    final f = _custom[i];
    _custom[i] = FontDef(id: f.id, name: name, filePath: f.filePath, builtIn: false, fallback: f.fallback, rtl: f.rtl);
    await _save();
    notifyListeners();
  }

  Future<void> removeCustom(String id) async {
    final f = _custom.where((f) => f.id == id).firstOrNull;
    if (f == null) return;
    _custom.remove(f);
    _cssCache.remove(id);
    try { await File(f.filePath!).delete(); } catch (_) {}
    await _save();
    notifyListeners();
  }

  Future<void> _save() => _prefs.setString(_key, jsonEncode(_custom.map((f) => f.toJson()).toList()));
}
