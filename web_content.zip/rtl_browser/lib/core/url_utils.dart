/// URL parsing / omnibox resolution. Pure Dart, unit-tested in test/url_utils_test.dart.
class UrlUtils {
  UrlUtils._();

  static const String homeUrl = 'about:home';

  static final RegExp _domain = RegExp(
      r'^([\w\u0600-\u06FF-]+\.)+[a-zA-Z\u0600-\u06FF]{2,}(:\d{1,5})?([/?#].*)?$');
  static final RegExp _ip = RegExp(r'^(\d{1,3}\.){3}\d{1,3}(:\d{1,5})?([/?#].*)?$');
  static final RegExp _localhost = RegExp(r'^localhost(:\d{1,5})?([/?#].*)?$');
  static const _passthroughSchemes = [
    'http:', 'https:', 'file:', 'about:', 'data:', 'view-source:', 'blob:'
  ];

  /// Turns what the user typed into a URL: direct URL, bare domain, or Google search.
  static String resolve(String input) {
    final s = input.trim();
    if (s.isEmpty) return homeUrl;
    final lower = s.toLowerCase();
    if (_passthroughSchemes.any(lower.startsWith)) return s;
    if (!s.contains(' ')) {
      if (_localhost.hasMatch(lower)) return 'http://$s';
      if (_ip.hasMatch(s)) return 'http://$s';
      if (_domain.hasMatch(s)) return 'https://$s';
    }
    return searchUrl(s);
  }

  static String searchUrl(String query) =>
      'https://www.google.com/search?q=${Uri.encodeQueryComponent(query)}';

  /// Host without leading "www." (used as the key for site preferences).
  static String host(String? url) {
    if (url == null || url.isEmpty) return '';
    final uri = Uri.tryParse(url);
    if (uri == null) return '';
    return uri.host.toLowerCase().replaceFirst(RegExp(r'^www\.'), '');
  }

  static bool isHttp(String? url) =>
      url != null && (url.startsWith('http://') || url.startsWith('https://'));

  static bool isSecure(String? url) => url != null && url.startsWith('https://');

  /// If the URL is a Google results page, returns the query, otherwise null.
  static String? googleQuery(String? url) {
    final uri = Uri.tryParse(url ?? '');
    if (uri == null) return null;
    if (!uri.host.contains('google.') || uri.path != '/search') return null;
    return uri.queryParameters['q'];
  }

  /// Short label for the address pill.
  static String display(String? url) {
    if (url == null || url.isEmpty || url == homeUrl) return '';
    final q = googleQuery(url);
    if (q != null) return q;
    final h = host(url);
    return h.isNotEmpty ? h : url;
  }

  /// Schemes that must be handed to the OS (dialer, mail, Play Store, other apps).
  static bool isExternalScheme(String url) {
    final l = url.toLowerCase();
    return l.startsWith('tel:') || l.startsWith('mailto:') || l.startsWith('sms:') ||
        l.startsWith('intent:') || l.startsWith('market:') || l.startsWith('geo:') ||
        l.startsWith('whatsapp:') || l.startsWith('tg:');
  }

  /// Android intent:// URLs carry an optional browser_fallback_url.
  static String? intentFallback(String url) {
    final m = RegExp(r'S\.browser_fallback_url=([^;]+)').firstMatch(url);
    return m == null ? null : Uri.decodeComponent(m.group(1)!);
  }

  /// Best-effort file name from Content-Disposition / URL.
  static String fileNameFor(String url, {String? contentDisposition, String? suggested, String? mime}) {
    String? name = suggested;
    if ((name == null || name.isEmpty) && contentDisposition != null) {
      final star = RegExp(r"filename\*\s*=\s*[^']*''([^;]+)", caseSensitive: false).firstMatch(contentDisposition);
      final plain = RegExp(r'filename\s*=\s*"?([^";]+)"?', caseSensitive: false).firstMatch(contentDisposition);
      if (star != null) {
        name = Uri.decodeComponent(star.group(1)!.trim());
      } else if (plain != null) {
        name = plain.group(1)!.trim();
      }
    }
    if (name == null || name.isEmpty) {
      final uri = Uri.tryParse(url);
      final seg = uri?.pathSegments.where((s) => s.isNotEmpty).toList() ?? [];
      name = seg.isNotEmpty ? Uri.decodeComponent(seg.last) : 'download';
    }
    name = name.replaceAll(RegExp(r'[\\/:*?"<>|\x00-\x1F]'), '_');
    if (!name.contains('.') && mime != null) {
      final ext = _extForMime[mime.split(';').first.trim()];
      if (ext != null) name = '$name.$ext';
    }
    return name;
  }

  static const Map<String, String> _extForMime = {
    'application/pdf': 'pdf', 'application/zip': 'zip', 'image/jpeg': 'jpg', 'image/png': 'png',
    'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg', 'text/plain': 'txt',
    'text/html': 'html', 'text/csv': 'csv', 'application/json': 'json', 'audio/mpeg': 'mp3',
    'video/mp4': 'mp4', 'application/vnd.android.package-archive': 'apk',
    'application/epub+zip': 'epub', 'application/x-rar-compressed': 'rar',
  };
}
