import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Single local SQLite database. Everything stays on device (no sync, no analytics).
class AppDatabase {
  AppDatabase._(this.db);
  final Database db;

  static Future<AppDatabase> open() async {
    final dir = await getDatabasesPath();
    final db = await openDatabase(
      p.join(dir, 'rtl_browser.db'),
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''CREATE TABLE history(
          id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, title TEXT,
          host TEXT, visited_at INTEGER NOT NULL)''');
        await db.execute('CREATE INDEX idx_history_time ON history(visited_at DESC)');
        await db.execute('CREATE INDEX idx_history_url ON history(url)');
        await db.execute('''CREATE TABLE bookmark_folders(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, parent_id INTEGER,
          created_at INTEGER NOT NULL)''');
        await db.execute('''CREATE TABLE bookmarks(
          id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, title TEXT NOT NULL,
          folder_id INTEGER, created_at INTEGER NOT NULL, position INTEGER NOT NULL DEFAULT 0)''');
        await db.execute('CREATE INDEX idx_bm_url ON bookmarks(url)');
        await db.execute('''CREATE TABLE downloads(
          id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, file_name TEXT NOT NULL,
          path TEXT, mime TEXT, total INTEGER, received INTEGER, status TEXT NOT NULL,
          error TEXT, created_at INTEGER NOT NULL)''');
      },
    );
    return AppDatabase._(db);
  }
}
