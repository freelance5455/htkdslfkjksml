import 'dart:async';

class Debouncer {
  Debouncer(this.delay);
  final Duration delay;
  Timer? _t;
  void call(void Function() fn) {
    _t?.cancel();
    _t = Timer(delay, fn);
  }
  void dispose() => _t?.cancel();
}
