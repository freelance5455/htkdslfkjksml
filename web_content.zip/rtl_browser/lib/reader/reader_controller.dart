import 'dart:convert';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../text_engine/text_engine_service.dart';
import '../text_engine/text_settings.dart';

/// Thin wrapper over assets/js/reader.js for one WebView.
class ReaderController {
  ReaderController(this.engine);
  final TextEngineService engine;

  Future<void> _ensure(InAppWebViewController c) =>
      c.evaluateJavascript(source: 'if(!window.__RTLR){${engine.readerJs}}');

  /// Cheap check used to light up the Reader button in the address bar.
  Future<bool> isReadable(InAppWebViewController c) async {
    try {
      await _ensure(c);
      final r = await c.evaluateJavascript(source: 'JSON.stringify(window.__RTLR.probe())');
      final m = jsonDecode(r as String);
      return m['ok'] == true && (m['length'] ?? 0) > 600;
    } catch (_) {
      return false;
    }
  }

  Future<bool> open(InAppWebViewController c, TextSettings t) async {
    await _ensure(c);
    final opts = jsonEncode(await engine.readerOptions(t));
    final r = await c.evaluateJavascript(source: 'JSON.stringify(window.__RTLR.open($opts))');
    try { return jsonDecode(r as String)['ok'] == true; } catch (_) { return false; }
  }

  Future<void> update(InAppWebViewController c, TextSettings t) async {
    final opts = jsonEncode(await engine.readerOptions(t));
    await c.evaluateJavascript(source: 'window.__RTLR&&window.__RTLR.update($opts)');
  }

  Future<void> close(InAppWebViewController c) =>
      c.evaluateJavascript(source: 'window.__RTLR&&window.__RTLR.close()');

  Future<String> articleText(InAppWebViewController c) async =>
      (await c.evaluateJavascript(source: 'window.__RTLR?window.__RTLR.text():""'))?.toString() ?? '';

  Future<String> selectedText(InAppWebViewController c) async =>
      (await c.evaluateJavascript(source: 'window.__RTLR?window.__RTLR.selection():String(window.getSelection()||"")'))
          ?.toString() ?? '';
}
