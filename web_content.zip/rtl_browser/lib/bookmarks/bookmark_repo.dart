import 'package:flutter/foundation.dart';

import '../core/db.dart';

class Bookmark {
  Bookmark({required this.id, required this.url, required this.title, this.folderId});
  final int id;
  final String url;
  final String title;
  final int? folderId;
  static Bookmark fromRow(Map<String, Object?> r) => Bookmark(
      id: r['id'] as int, url: r['url'] as String, title: r['title'] as String, folderId: r['folder_id'] as int?);
}

class BookmarkFolder {
  BookmarkFolder({required this.id, required this.name, this.parentId});
  final int id;
  final String name;
  final int? parentId;
  static BookmarkFolder fromRow(Map<String, Object?> r) =>
      BookmarkFolder(id: r['id'] as int, name: r['name'] as String, parentId: r['parent_id'] as int?);
}

class BookmarkRepo extends ChangeNotifier {
  BookmarkRepo(this._db);
  final AppDatabase _db;

  Future<Bookmark?> find(String url) async {
    final r = await _db.db.query('bookmarks', where: 'url = ?', whereArgs: [url], limit: 1);
    return r.isEmpty ? null : Bookmark.fromRow(r.first);
  }

  Future<int> add(String url, String title, {int? folderId}) async {
    final id = await _db.db.insert('bookmarks', {
      'url': url, 'title': title.isEmpty ? url : title, 'folder_id': folderId,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    notifyListeners();
    return id;
  }

  Future<void> update(int id, {String? title, String? url, int? folderId, bool clearFolder = false}) async {
    await _db.db.update('bookmarks', {
      if (title != null) 'title': title,
      if (url != null) 'url': url,
      if (folderId != null || clearFolder) 'folder_id': folderId,
    }, where: 'id = ?', whereArgs: [id]);
    notifyListeners();
  }

  Future<void> remove(int id) async { await _db.db.delete('bookmarks', where: 'id = ?', whereArgs: [id]); notifyListeners(); }

  Future<List<Bookmark>> list({int? folderId, String query = ''}) async {
    final q = query.trim();
    final rows = q.isNotEmpty
        ? await _db.db.query('bookmarks', where: 'title LIKE ? OR url LIKE ?', whereArgs: ['%$q%', '%$q%'], orderBy: 'created_at DESC')
        : await _db.db.query('bookmarks',
            where: folderId == null ? 'folder_id IS NULL' : 'folder_id = ?',
            whereArgs: folderId == null ? null : [folderId], orderBy: 'position, created_at DESC');
    return rows.map(Bookmark.fromRow).toList();
  }

  Future<List<Bookmark>> recent({int limit = 8}) async =>
      (await _db.db.query('bookmarks', orderBy: 'created_at DESC', limit: limit)).map(Bookmark.fromRow).toList();

  Future<List<BookmarkFolder>> folders({int? parentId}) async => (await _db.db.query('bookmark_folders',
          where: parentId == null ? 'parent_id IS NULL' : 'parent_id = ?',
          whereArgs: parentId == null ? null : [parentId], orderBy: 'name'))
      .map(BookmarkFolder.fromRow).toList();

  Future<List<BookmarkFolder>> allFolders() async =>
      (await _db.db.query('bookmark_folders', orderBy: 'name')).map(BookmarkFolder.fromRow).toList();

  Future<int> addFolder(String name, {int? parentId}) async {
    final id = await _db.db.insert('bookmark_folders',
        {'name': name, 'parent_id': parentId, 'created_at': DateTime.now().millisecondsSinceEpoch});
    notifyListeners();
    return id;
  }

  Future<void> renameFolder(int id, String name) async {
    await _db.db.update('bookmark_folders', {'name': name}, where: 'id = ?', whereArgs: [id]);
    notifyListeners();
  }

  /// Deletes a folder; its bookmarks and sub-folders move up to the parent.
  Future<void> removeFolder(int id) async {
    final f = (await _db.db.query('bookmark_folders', where: 'id = ?', whereArgs: [id])).firstOrNull;
    final parent = f?['parent_id'];
    await _db.db.transaction((tx) async {
      await tx.update('bookmarks', {'folder_id': parent}, where: 'folder_id = ?', whereArgs: [id]);
      await tx.update('bookmark_folders', {'parent_id': parent}, where: 'parent_id = ?', whereArgs: [id]);
      await tx.delete('bookmark_folders', where: 'id = ?', whereArgs: [id]);
    });
    notifyListeners();
  }
}
