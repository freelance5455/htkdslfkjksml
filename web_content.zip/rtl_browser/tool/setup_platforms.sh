#!/usr/bin/env bash
# Generates the android/ and ios/ host projects (Flutter keeps existing lib/, assets/, pubspec)
# and applies the native configuration this browser needs.
set -euo pipefail
cd "$(dirname "$0")/.."

flutter create --org com.rtlbrowser --project-name rtl_browser --platforms android,ios .
rm -f test/widget_test.dart   # template test references a counter app that doesn't exist

MANIFEST=android/app/src/main/AndroidManifest.xml
python3 - "$MANIFEST" <<'PY'
import re, sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
perms = ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE',
         'android.permission.CAMERA', 'android.permission.RECORD_AUDIO',
         'android.permission.MODIFY_AUDIO_SETTINGS', 'android.permission.ACCESS_FINE_LOCATION',
         'android.permission.ACCESS_COARSE_LOCATION']
for perm in perms:
    if perm not in s:
        s = s.replace('<application', f'<uses-permission android:name="{perm}"/>\n    <application', 1)
s = s.replace('android:label="rtl_browser"', 'android:label="مرورگر راست‌چین"')
if 'usesCleartextTraffic' not in s:
    s = s.replace('<application', '<application\n        android:usesCleartextTraffic="true"\n        android:hardwareAccelerated="true"', 1)
# Let the app appear as a browser for http/https links.
if 'android.intent.category.BROWSABLE' not in s:
    s = s.replace('</activity>', '''    <intent-filter>
                <action android:name="android.intent.action.VIEW"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <category android:name="android.intent.category.BROWSABLE"/>
                <data android:scheme="http"/>
                <data android:scheme="https"/>
            </intent-filter>
        </activity>''', 1)
# query intents so url_launcher can open tel:/mailto:/other apps on Android 11+
if '<queries>' not in s:
    s = s.replace('</manifest>', '''    <queries>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
        <intent><action android:name="android.intent.action.DIAL"/></intent>
        <intent><action android:name="android.intent.action.SENDTO"/><data android:scheme="mailto"/></intent>
    </queries>
</manifest>''')
open(p, 'w', encoding='utf-8').write(s)
PY

# minSdk 21+ for flutter_inappwebview 6
for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] && sed -i.bak -E 's/minSdk(Version)? *=? *flutter\.minSdkVersion/minSdk = 24/' "$f" && rm -f "$f.bak"
done

PLIST=ios/Runner/Info.plist
if [ -f "$PLIST" ] && ! grep -q NSAppTransportSecurity "$PLIST"; then
  python3 - "$PLIST" <<'PY'
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
extra = '''	<key>NSAppTransportSecurity</key>
	<dict><key>NSAllowsArbitraryLoadsInWebContent</key><true/></dict>
	<key>NSCameraUsageDescription</key><string>برای سایت‌هایی که به دوربین نیاز دارند</string>
	<key>NSMicrophoneUsageDescription</key><string>برای سایت‌هایی که به میکروفون نیاز دارند</string>
	<key>NSLocationWhenInUseUsageDescription</key><string>برای سایت‌هایی که موقعیت مکانی می‌خواهند</string>
	<key>NSPhotoLibraryAddUsageDescription</key><string>برای ذخیره تصاویر دانلودشده</string>
	<key>UISupportsDocumentBrowser</key><true/>
	<key>LSSupportsOpeningDocumentsInPlace</key><true/>
'''
s = s.replace('<dict>', '<dict>\n' + extra, 1)
open(p, 'w', encoding='utf-8').write(s)
PY
fi

flutter pub get
echo "Done. Run: flutter run   (or: flutter build apk --release)"
