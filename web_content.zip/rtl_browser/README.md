# مرورگر راست‌چین (RTL Browser)

یک مرورگر واقعی موبایل (Flutter، Android + iOS) با موتور اختصاصی **Text Formatting** که متن هر سایتی را
بدون خراب کردن ساختار سایت، راست‌چین/چپ‌چین و با فونت‌هایی مثل وزیرمتن نمایش می‌دهد.

## اجرا

```bash
# پیش‌نیاز: Flutter 3.27+ ، Android SDK (و Xcode برای iOS)
./tool/setup_platforms.sh      # ساخت پوشه‌های android/ios + تنظیمات Manifest/Info.plist
flutter run                    # اجرا روی گوشی/امولاتور
flutter build apk --release    # خروجی APK
flutter test                   # تست‌های Dart
CHROME=/path/to/chrome test/js/run_js_tests.sh   # تست موتور متن در Chromium
```

## معماری

```
lib/
  app/            composition root (Services) ، تم، MaterialApp با RTL و locale فارسی
  core/           UrlUtils (omnibox)، SQLite، Debouncer
  text_engine/    TextSettings (مدل) + TextEngineService (پل Dart ⇄ JS)
  fonts/          FontManager: فونت‌های داخلی + فونت سفارشی TTF/OTF/WOFF/WOFF2
  reader/         ReaderController (پل Reader Mode)
  tabs/           BrowserTab + TabManager (LRU، خواب تب‌ها، بازگردانی جلسه، تب‌های بسته‌شده)
  bookmarks/      BookmarkRepo (پوشه‌بندی، جستجو، ویرایش)
  history/        HistoryRepo (محلی، جستجو، حذف تکی/کلی)
  downloads/      DownloadManager (http/https با کوکی‌های WebView، data:، blob:)
  site_prefs/     تنظیمات جداگانه هر سایت (با fallback به دامنه والد)
  presets/        Presetهای قابل ذخیره/ویرایش/حذف
  settings/       AppSettings
  ui/             BrowserScreen، WebTabView، HomePage، SearchPage، Tabs، Bookmarks، History،
                  Downloads، QuickTextSheet، TextControls، settings/*
assets/js/
  text_engine.js  لایه تزریقی Text Formatting
  reader.js       Reader Mode روی Shadow DOM
assets/fonts/     Vazirmatn، Estedad، Noto Naskh Arabic، Literata، Inter (همه OFL، woff2)
```

**موتور وب:** System WebView (Chromium به‌روز از Play Store) در Android و WKWebView در iOS از طریق
`flutter_inappwebview` ⇒ JavaScript، Cookie، Local Storage، Web APIs، ویدیو/تمام‌صفحه، آپلود فایل، دانلود،
پاپ‌آپ/`window.open`، احراز هویت HTTP، مجوز دوربین/میکروفون/موقعیت.

### موتور Text Formatting (قلب پروژه)
- یک UserScript در **document-start** موتور + تنظیمات سراسری + تنظیمات همه سایت‌ها + فقط فونت‌های لازم را
  تزریق می‌کند ⇒ تنظیمات درست قبل از اولین رندر، بدون Reload.
- هرگز `*` را هدف نمی‌گیرد: فقط عنصری که **مستقیماً** متن دارد علامت می‌خورد (`data-rtlf`). جهت فقط روی
  بلاک متنی اعمال می‌شود، **نه** روی flex/grid چندفرزندی ⇒ منوها و toolbarها برعکس نمی‌شوند.
- استثناها: input/textarea/button/select/code/pre/kbd/canvas/video/iframe/svg/math/contenteditable،
  role=button/img، و فونت‌های آیکونی (Material/FontAwesome/… با تشخیص font-family، کلاس و کاراکترهای PUA).
- تشخیص زبان در هر بلاک (فارسی/عربی/عبری ⇒ RTL، لاتین/سیریلیک ⇒ LTR). در حالت Auto فقط وقتی
  override می‌کند که زبان بلاک با جهت سایت فرق کند. تیترهای وسط‌چین وسط‌چین می‌مانند.
- همه استایل‌ها در **یک** Constructable StyleSheet پشت `html[data-rtlf-on]` ⇒ خاموش کردن = حذف یک attribute.
  این روش تحت CSP `style-src` هم کار می‌کند و با تعویض `<head>` در SPAها از بین نمی‌رود.
- فونت‌ها با **FontFace API از بایت‌های حافظه** بارگذاری می‌شوند ⇒ بدون شبکه و مقاوم در برابر CSP `font-src`.
- `MutationObserver` + پردازش زمان‌بندی‌شده (حداکثر ~۸ms در هر فریم با `requestIdleCallback`) ⇒
  React/Vue/Next.js/AJAX/Infinite Scroll بدون Freeze. Shadow DOM باز هم پشتیبانی می‌شود.
- متن هیچ گرهی تغییر نمی‌کند ⇒ Copy/Paste و hydration فریم‌ورک‌ها سالم می‌ماند.
- اندازه متن در Android با `textZoom` بومی WebView (بدون ضرب شدن تو در تو)، در iOS با `text-size-adjust`.
- letter-spacing فقط روی متن لاتین؛ برای متن فارسی word-spacing (تا اتصال حروف نشکند).

### Reader Mode
استخراج مقاله به سبک Readability، نمایش در یک overlay روی Shadow DOM **روی** صفحه زنده؛ صفحه اصلی دست
نمی‌خورد، پس خروج آنی است و وضعیت سایت (لاگین، پخش‌کننده، سبد خرید) حفظ می‌شود. بدون `innerHTML`
(سازگار با Trusted Types). تم روشن/تیره/سپیا/مشکی/سفارشی، عرض، فونت، اندازه، فاصله خطوط، تراز دوطرفه.

### چیزهایی که در درخواست نبود ولی اضافه شد
حذف نشانه `; wv` از User-Agent (تا Google و سایت‌ها نسخه کامل را بدهند)، حالت دسکتاپ، تب ناشناس،
جستجو در صفحه، Pull-to-refresh، منوی لمس طولانی (تب جدید، کپی/اشتراک/دانلود لینک و تصویر)، صفحه خطای
اختصاصی با «تلاش دوباره»، باز کردن tel:/mailto:/intent: در برنامه مربوط، حالت تیره خودکار سایت‌ها،
مسدودکردن پاپ‌آپ بدون لمس، خواب تب‌ها برای مصرف RAM (حداکثر ۴ WebView زنده)، بازگردانی جلسه، ثبت برنامه
به‌عنوان مرورگر برای لینک‌های http/https، پاک‌کردن داده هنگام خروج.

## حریم خصوصی
همه داده‌ها محلی (SQLite + SharedPreferences). هیچ Analytics/Tracking. تنها درخواست غیرسایتی، پیشنهاد
جستجوی Google است که قابل خاموش شدن است و در تب ناشناس هرگز ارسال نمی‌شود. Favicon از خود سایت گرفته
می‌شود (نه سرویس شخص ثالث).

## وضعیت تست

| سناریو | وضعیت |
|---|---|
| موتور متن: راست‌چین خودکار، فونت، وزن، فاصله خطوط، عدم تغییر nav/code/button/input/آیکون | ✅ خودکار در Chromium (`test/js`) |
| محتوای Dynamic، Infinite Scroll، تغییر متن به سبک React | ✅ خودکار |
| تغییر زنده RTL/LTR و خاموش/روشن بدون Reload | ✅ خودکار |
| ۳۰۰۰ پاراگراف بدون ایجاد long task اضافه | ✅ خودکار |
| Reader Mode: استخراج، حذف sidebar/footer، بستن و سالم ماندن صفحه | ✅ خودکار |
| سایت با CSP سخت + Trusted Types | ✅ خودکار |
| UrlUtils، TextSettings، تنظیمات سایت (fallback و ریست) | `flutter test` |
| Google/جستجوی فارسی/سایت خبری/ویدیو/ورود/دانلود/چند تب/بستن و باز کردن برنامه | روی دستگاه (چک‌لیست زیر) |

چک‌لیست دستگاه: ۱) Google ۲) جستجوی «اخبار امروز» ۳) bbc.com/persian ۴) en.wikipedia.org ۵) فونت ⇐ وزیرمتن
۶) RTL/LTR ۷) اندازه ۸) Reading Mode ۹) سه تب ۱۰) ویدیو m.youtube.com ۱۱) ورود به یک حساب ۱۲) دانلود PDF
۱۳) Refresh ۱۴) بستن/باز کردن برنامه ۱۵) «فقط این سایت» روی ویکی‌پدیا ۱۶) بازگشت به ویکی‌پدیا ۱۷) x.com
۱۸) اسکرول بی‌نهایت در یک سایت خبری.

## محدودیت‌های شناخته‌شده (صادقانه)
- Google ورود OAuth («Sign in with Google» در سایت‌های ثالث) را داخل WebViewها گاهی مسدود می‌کند؛ این سیاست
  Google است. ورود مستقیم به google.com/Gmail معمولاً کار می‌کند.
- دانلودها در پوشه Downloads خود برنامه ذخیره می‌شوند و از صفحه دانلودها قابل باز کردن و «اشتراک/ذخیره در…»
  هستند (برای انتقال به Downloads عمومی گوشی).
- iframeهای cross-origin (مثلاً پلیر ویدیو درون سایت) به دلیل امنیت مرورگر فرمت نمی‌شوند.

## ساخت APK بدون نصب Flutter (GitHub Actions)
1. یک مخزن (حتی Private) در GitHub بسازید و محتوای این پوشه را push کنید.
2. تب **Actions** ⇐ «Build APK» به‌صورت خودکار اجرا می‌شود (یا Run workflow).
3. بعد از حدود ۱۰ دقیقه، از بخش **Artifacts** فایل `rtl-browser-apk` را دانلود کنید.
   `app-release.apk` نسخه همه‌کاره است؛ برای اکثر گوشی‌ها `app-arm64-v8a-release.apk` کوچک‌تر است.
4. روی گوشی «نصب از منابع ناشناس» را برای مرورگر/مدیر فایل فعال کنید و APK را نصب کنید.

> APK با کلید debug امضا می‌شود (قابل نصب مستقیم). برای انتشار در Play Store کلید release خودتان را
> در `android/key.properties` تنظیم کنید.
