AMBALING vs YES KING - prototipe web game

Cara main di Android:
1. Ekstrak ZIP ke folder.
2. Buka index.html dengan browser yang bisa membuka file lokal, atau jalankan melalui web server lokal.
3. Ketuk MULAI PERTARUNGAN untuk mengaktifkan audio.
4. Putar HP ke posisi landscape. Pada portrait, game mencoba memutar tampilan otomatis.

Kontrol layar: GERAK kiri/kanan, BERTAHAN, SERANG, JURUS.
Keyboard: A/D atau panah untuk bergerak, J untuk serang, K untuk jurus, L untuk bertahan.

Audio: soundtrack diputar loop dengan volume 0.2; audio karakter diputar saat serangan; audio kematian saat HP lawan habis.
Catatan: ini prototipe HTML yang bisa dimainkan, belum APK Android. Sistem gerakan/serangan masih sederhana dan perlu pengembangan lanjut.
