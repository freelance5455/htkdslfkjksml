# Smart TV Remote – Xiaomi Edition (v2)

## Cách kết nối (giống app Google TV)
1. Mở app > tab TV: app tự tìm TV trên Wi-Fi bằng mDNS (`_androidtvremote2._tcp`).
2. Chạm vào tên TV (ví dụ "TV Box Xiaomi").
3. TV hiện mã 6 ký tự > nhập vào hộp thoại "Ghép đôi với TV" > Xác nhận.
Chứng chỉ ghép đôi được lưu trong thư mục `pairing/` (quyền 600); lần sau không cần nhập mã lại. Xóa thư mục này để ghép đôi lại.

## Cài đặt (Termux)
```
pkg install nodejs android-tools unzip
npm install
npm start
```
Mở đường dẫn `http://localhost:3000/?token=...` in ra trong Termux. Nếu đang chạy bản cũ, nhấn Ctrl+C trước.

## Không thấy TV trong danh sách?
- Điện thoại và TV phải cùng Wi-Fi; TV đang bật (không ngủ).
- Android có thể chặn gói mDNS đối với Termux. Khi đó mở "Nhập IP thủ công", nhập IP của TV, chọn "Android TV Remote" > Kết nối.
- TV không hỗ trợ giao thức trên: dùng ADB (bật Tùy chọn nhà phát triển > gỡ lỗi mạng, chọn phương thức ADB).

## Google Assistant
Bấm nút Google (hình 4 chấm màu) để gọi Trợ lý Google trên TV (gửi phím ASSIST). Sau đó nói vào micro của remote/TV. Cần TV có Google Assistant và đã kết nối.

## Giới hạn
- Nút Google chỉ mở Trợ lý Google trên TV; micro của điện thoại không truyền âm thanh tới TV, nên cần nói vào micro của TV/remote (cần xác minh trên thiết bị thật).
- Chưa kiểm thử trên Xiaomi TV/Box thật; thư viện `androidtv-remote` và deep link Netflix/Prime/Disney+ cần xác minh trên thiết bị.
- Nhập văn bản chỉ hoạt động khi dùng ADB, và chỉ ký tự ASCII.
- Nút nguồn có thể chỉ đưa TV vào chế độ ngủ tùy model.
- Mất kết nối giữa chừng chỉ được phát hiện khi gửi lệnh thất bại.
