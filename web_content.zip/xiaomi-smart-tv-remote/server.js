'use strict';
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const LAN = process.env.LAN === '1';
const HOST = LAN ? '0.0.0.0' : '127.0.0.1';
const PORT = Number(process.env.PORT) || 3000;
const ADB = process.env.ADB_PATH || 'adb';
const TOKEN = crypto.randomBytes(16).toString('hex'); // token phiên, đổi mỗi lần khởi động
const SETTINGS_FILE = path.join(__dirname, 'settings.json');

// Danh sách lệnh cho phép -> keycode cố định (không bao giờ ghép chuỗi từ người dùng)
const KEYS = {
  power: 'KEYCODE_POWER', assistant: 'KEYCODE_ASSIST', up: 'KEYCODE_DPAD_UP', down: 'KEYCODE_DPAD_DOWN',
  left: 'KEYCODE_DPAD_LEFT', right: 'KEYCODE_DPAD_RIGHT', ok: 'KEYCODE_DPAD_CENTER', back: 'KEYCODE_BACK',
  home: 'KEYCODE_HOME', menu: 'KEYCODE_MENU', volume_up: 'KEYCODE_VOLUME_UP', volume_down: 'KEYCODE_VOLUME_DOWN',
  mute: 'KEYCODE_VOLUME_MUTE', open_apps: 'KEYCODE_ALL_APPS',
};
const APPS = { open_netflix: 'netflix', open_prime_video: 'prime', open_disney_plus: 'disney' };
const DEFAULTS = { name: '', host: '', port: 5555, method: 'atv',
  packages: { netflix: 'com.netflix.ninja', prime: 'com.amazon.amazonvideo.livingroom', disney: 'com.disney.disneyplus' } };
const PKG_RE = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$/;
const PRIVATE_IP = /^(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|169\.254\.\d{1,3}\.\d{1,3})$/;

// Android TV Remote v2: mã phím Android (số) và deep link ứng dụng
const ATV_KEYS = { power: 26, assistant: 219, up: 19, down: 20, left: 21, right: 22, ok: 23, back: 4, home: 3, menu: 82,
  volume_up: 24, volume_down: 25, mute: 164, open_apps: 284 };
const ATV_LINKS = { open_netflix: 'https://www.netflix.com', open_prime_video: 'https://app.primevideo.com', open_disney_plus: 'https://www.disneyplus.com' };
const PAIR_DIR = path.join(__dirname, 'pairing');

let settings = loadSettings();
let state = 'disconnected', method = 'atv', target = null, info = null, lastError = null;
let remote = null, SHORT = 3;
const found = new Map(); let discovering = false;
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function waitFor(pred, ms) { const t = Date.now(); while (Date.now() - t < ms && !pred(state)) await sleep(100); }

// Chứng chỉ ghép đôi: chỉ lưu trong thư mục pairing/ với quyền 600, không gửi ra frontend hay log
const certFile = h => path.join(PAIR_DIR, h.replace(/[^0-9.]/g, '') + '.json');
function loadCert(h) { try { return JSON.parse(fs.readFileSync(certFile(h), 'utf8')); } catch { return {}; } }
function saveCert(h, c) { fs.mkdirSync(PAIR_DIR, { recursive: true, mode: 0o700 }); fs.writeFileSync(certFile(h), JSON.stringify(c), { mode: 0o600 }); }

async function atvClose() { const r = remote; remote = null; try { r && r.stop(); } catch { /* bỏ qua */ } }

async function atvConnect(host) {
  await atvClose(); state = 'connecting'; method = 'atv'; target = null; info = null; lastError = null;
  const err = (code, message) => { state = 'error'; lastError = { code, message }; };
  let lib;
  try { lib = await import('androidtv-remote'); } catch { err('lib_missing', 'Thiếu thư viện androidtv-remote. Chạy "npm install".'); throw fail(500, 'lib_missing', lastError.message); }
  SHORT = (lib.RemoteDirection && lib.RemoteDirection.SHORT) || 3;
  const r = new lib.AndroidRemote(host, { pairing_port: 6467, remote_port: 6466, name: 'Smart TV Remote', cert: loadCert(host) });
  remote = r;
  r.on('secret', () => { if (remote === r) state = 'pairing'; }); // TV đang hiện mã ghép đôi
  r.on('ready', () => {
    if (remote !== r) return;
    try { saveCert(host, r.getCertificate()); } catch { /* bỏ qua */ }
    target = host; info = { model: 'Android TV', manufacturer: '' }; state = 'connected';
    settings.host = host; settings.method = 'atv'; saveSettings();
  });
  r.on('unpaired', () => { if (remote === r) { try { fs.unlinkSync(certFile(host)); } catch { /* bỏ qua */ } err('unpaired', 'TV đã hủy ghép đôi. Hãy ghép đôi lại.'); } });
  r.on('error', () => { if (remote === r && state !== 'connected') err('atv_error', 'Kết nối thất bại. Kiểm tra TV đang bật và cùng Wi-Fi.'); });
  r.start().catch(() => { if (remote === r && state !== 'connected') err('atv_error', 'Không kết nối được tới TV. Kiểm tra IP và Wi-Fi.'); });
  await waitFor(s => s !== 'connecting', 12000);
  if (state === 'connecting') err('timeout', 'TV không phản hồi. Hãy bật TV và kiểm tra cùng mạng Wi-Fi.');
  if (state === 'error') { const m = lastError; await atvClose(); throw fail(502, m.code, m.message); }
}

async function atvPair(code) {
  if (state !== 'pairing' || !remote) throw fail(409, 'not_pairing', 'TV chưa yêu cầu mã ghép đôi.');
  remote.sendCode(code.toUpperCase()); // mã không được lưu hay ghi log
  await waitFor(s => s !== 'pairing', 15000);
  if (state !== 'connected') { state = 'error'; lastError = { code: 'pair_failed', message: 'Sai mã hoặc hết thời gian. Hãy thử lại.' }; await atvClose(); throw fail(502, 'pair_failed', lastError.message); }
}

function startDiscovery() { // mDNS: dịch vụ _androidtvremote2._tcp mà Google TV app cũng dùng
  if (discovering) return; discovering = true; found.clear();
  let bj = null;
  try {
    const { Bonjour } = require('bonjour-service'); bj = new Bonjour();
    bj.find({ type: 'androidtvremote2' }, s => {
      const ip = (s.addresses || []).find(a => PRIVATE_IP.test(a));
      if (ip) found.set(ip, { name: String(s.name || 'Android TV').slice(0, 60), host: ip, method: 'atv' });
    });
  } catch { /* thiếu thư viện hoặc mạng chặn mDNS: người dùng vẫn nhập IP thủ công được */ }
  setTimeout(() => { try { bj && bj.destroy(); } catch { /* bỏ qua */ } discovering = false; }, 7000);
}

function loadSettings() {
  try {
    const s = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    return { ...DEFAULTS, ...s, packages: { ...DEFAULTS.packages, ...(s.packages || {}) } };
  } catch { return JSON.parse(JSON.stringify(DEFAULTS)); }
}
const saveSettings = () => fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); // không chứa mã ghép đôi/khóa

const fail = (status, code, msg) => Object.assign(new Error(code), { status, code_: code, msg });

const adb = (args, ms = 8000) => new Promise((resolve, reject) => {
  execFile(ADB, args, { timeout: ms, windowsHide: true }, (e, out, err) => {
    if (!e) return resolve((out || '').trim());
    if (e.code === 'ENOENT') return reject(fail(500, 'adb_missing', 'Không tìm thấy ADB. Hãy cài ADB hoặc đặt biến ADB_PATH.'));
    if (e.killed) return reject(fail(504, 'timeout', 'TV không phản hồi. Kiểm tra TV đang bật và cùng mạng Wi-Fi.'));
    const m = (err || out || e.message || '').trim();
    if (/unauthorized/i.test(m)) return reject(fail(403, 'unauthorized', 'TV chưa cho phép gỡ lỗi. Chọn "Luôn cho phép" trên TV rồi thử lại.'));
    reject(fail(502, 'adb_error', 'Lệnh thất bại: ' + m.slice(0, 120)));
  });
});

function parseTarget(host, port) {
  host = String(host || '').trim(); port = Number(port);
  if (!PRIVATE_IP.test(host) || host.split('.').some(n => Number(n) > 255))
    throw fail(400, 'invalid_host', 'Địa chỉ IP không hợp lệ. Chỉ chấp nhận IP trong mạng nội bộ.');
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw fail(400, 'invalid_port', 'Cổng không hợp lệ.');
  return { host, port };
}

async function connect(host, port) {
  state = 'connecting'; lastError = null;
  try {
    const t = `${host}:${port}`;
    const out = await adb(['connect', t], 10000);
    if (!/connected to/i.test(out) || /failed|cannot|unable/i.test(out))
      throw fail(502, 'connect_failed', `Không kết nối được tới ${host}. Kiểm tra IP và đã bật gỡ lỗi mạng (ADB) trên TV.`);
    if (await adb(['-s', t, 'get-state'], 5000) !== 'device') throw fail(502, 'not_ready', 'Thiết bị chưa sẵn sàng.');
    const [model, manufacturer] = await Promise.all(['ro.product.model', 'ro.product.manufacturer']
      .map(p => adb(['-s', t, 'shell', 'getprop', p], 5000)));
    target = t; info = { model, manufacturer }; method = 'adb'; state = 'connected';
    settings.host = host; settings.port = port; settings.method = 'adb'; saveSettings();
  } catch (e) { state = 'error'; target = null; info = null; lastError = { code: e.code_, message: e.msg }; throw e; }
}

async function runCommand(cmd) {
  if (state !== 'connected' || !target) throw fail(409, 'not_connected', 'Chưa kết nối với TV.');
  if (method === 'atv') {
    const lost = () => { state = 'disconnected'; lastError = { code: 'lost', message: 'Mất kết nối với TV.' }; atvClose(); throw fail(502, 'send_failed', 'Mất kết nối với TV. Hãy kết nối lại.'); };
    if (ATV_KEYS[cmd] !== undefined) { try { remote.sendKey(ATV_KEYS[cmd], SHORT); } catch { lost(); } return; }
    if (ATV_LINKS[cmd]) { try { remote.sendAppLink(ATV_LINKS[cmd]); } catch { lost(); } return; }
    throw fail(400, 'unsupported_command', 'Lệnh không được hỗ trợ.');
  }
  if (KEYS[cmd]) { await adb(['-s', target, 'shell', 'input', 'keyevent', KEYS[cmd]], 4000); return; }
  if (APPS[cmd]) {
    const pkg = settings.packages[APPS[cmd]];
    if (!PKG_RE.test(pkg)) throw fail(400, 'invalid_package', 'Tên package ứng dụng không hợp lệ. Sửa trong More > Cài đặt.');
    const out = await adb(['-s', target, 'shell', 'am', 'start', '-a', 'android.intent.action.MAIN',
      '-c', 'android.intent.category.LEANBACK_LAUNCHER', '-p', pkg], 6000);
    if (/error|unable to resolve/i.test(out)) throw fail(404, 'app_not_installed', 'Ứng dụng chưa được cài trên TV hoặc sai package.');
    return;
  }
  throw fail(400, 'unsupported_command', 'Lệnh không được hỗ trợ.');
}

const snapshot = () => ({ state, method, error: lastError,
  device: { name: settings.name, host: target || settings.host, port: settings.port, ...(info || {}) } });

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '4kb' }));

// Chống DNS rebinding: ở chế độ localhost chỉ nhận Host là localhost
app.use((req, res, next) => {
  const host = (req.headers.host || '').replace(/:\d+$/, '');
  if (!LAN && !['localhost', '127.0.0.1'].includes(host)) return res.status(403).end();
  next();
});
let win = 0, cnt = 0;
app.use('/api', (req, res, next) => {
  const s = Math.floor(Date.now() / 1000);
  if (s !== win) { win = s; cnt = 0; }
  if (++cnt > 20) return res.status(429).json({ ok: false, error: 'rate_limited', message: 'Gửi lệnh quá nhanh.' });
  if (req.path === '/health') return next();
  const t = Buffer.from(String(req.headers['x-token'] || '')), k = Buffer.from(TOKEN);
  if (t.length !== k.length || !crypto.timingSafeEqual(t, k))
    return res.status(401).json({ ok: false, error: 'unauthorized_client', message: 'Phiên không hợp lệ. Mở lại đường dẫn có token in ở máy chủ.' });
  const o = req.headers.origin;
  if (o) { try { if (new URL(o).host !== req.headers.host) throw 0; } catch { return res.status(403).json({ ok: false, error: 'bad_origin', message: 'Origin không hợp lệ.' }); } }
  next();
});

const h = fn => async (req, res) => {
  try { res.json({ ok: true, ...(await fn(req)) }); }
  catch (e) { res.status(e.status || 500).json({ ok: false, error: e.code_ || 'internal', message: e.msg || 'Lỗi không xác định.' }); }
};

app.get('/api/health', h(async () => ({ version: '1.0.0' })));
app.get('/api/settings', h(async () => ({ settings })));
app.post('/api/settings', h(async (req) => {
  const b = req.body || {};
  if (typeof b.name === 'string') settings.name = b.name.trim().slice(0, 40);
  for (const k of Object.keys(DEFAULTS.packages)) {
    const v = b.packages && b.packages[k];
    if (v !== undefined) { if (!PKG_RE.test(v)) throw fail(400, 'invalid_package', 'Package không hợp lệ: ' + k); settings.packages[k] = v; }
  }
  saveSettings(); return { settings };
}));
app.get('/api/devices', h(async () => {
  const list = [...found.values()];
  if (settings.host && !found.has(settings.host)) list.push({ name: settings.name || 'Thiết bị đã lưu', host: settings.host, method: settings.method || 'atv' });
  return { devices: list, discovering };
}));
app.post('/api/discovery/start', h(async () => { startDiscovery(); return { discovering: true }; }));
app.post('/api/devices/manual', h(async (req) => {
  const { host, port } = parseTarget(req.body.host, req.body.port || 5555);
  settings.host = host; settings.port = port; saveSettings(); return snapshot();
}));
app.post('/api/devices/pair', h(async (req) => {
  if (req.body.method !== 'adb') { // Android TV Remote v2: mã 6 ký tự hex hiện trên TV
    const code = String(req.body.code || '');
    if (!/^[0-9A-Fa-f]{6}$/.test(code)) throw fail(400, 'invalid_code', 'Mã ghép đôi gồm 6 ký tự (0-9, A-F).');
    await atvPair(code); return snapshot();
  }
  // ADB Wireless debugging (Android 11+)
  const { host, port } = parseTarget(req.body.host, req.body.port);
  const code = String(req.body.code || '');
  if (!/^\d{6}$/.test(code)) throw fail(400, 'invalid_code', 'Mã ghép đôi phải gồm 6 chữ số.');
  const out = await adb(['pair', `${host}:${port}`, code], 15000); // mã không được lưu hay ghi log
  if (!/successfully paired/i.test(out)) throw fail(502, 'pair_failed', 'Ghép đôi thất bại. Kiểm tra mã và cổng ghép đôi.');
  return {};
}));
app.post('/api/devices/connect', h(async (req) => {
  if (req.body.method === 'adb') { const { host, port } = parseTarget(req.body.host, req.body.port || 5555); await atvClose(); await connect(host, port); }
  else { const { host } = parseTarget(req.body.host, 6466); await atvConnect(host); }
  return snapshot();
}));
app.post('/api/devices/disconnect', h(async () => {
  if (method === 'adb' && target) { try { await adb(['disconnect', target], 5000); } catch { /* bỏ qua */ } }
  await atvClose(); target = null; info = null; state = 'disconnected'; lastError = null; return snapshot();
}));
app.get('/api/device/status', h(async () => {
  if (method === 'adb' && target) {
    try { if (await adb(['-s', target, 'get-state'], 4000) !== 'device') throw 0; }
    catch { target = null; info = null; state = 'disconnected'; lastError = { code: 'lost', message: 'Mất kết nối với TV.' }; }
  }
  return snapshot();
}));
app.post('/api/remote/command', h(async (req) => { await runCommand(String((req.body || {}).command)); return {}; }));
app.post('/api/remote/search', h(async (req) => { // tìm kiếm bằng giọng nói: điện thoại chuyển giọng thành chữ, gửi đường dẫn tìm kiếm cho TV
  if (state !== 'connected' || !target) throw fail(409, 'not_connected', 'Chưa kết nối với TV.');
  const t = String((req.body || {}).query || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 100);
  if (!t) throw fail(400, 'empty_query', 'Không nhận được nội dung giọng nói.');
  // chỉ còn ký tự [A-Za-z0-9-_.~%] nên an toàn khi qua shell của TV
  const enc = encodeURIComponent(t).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  const url = 'https://www.youtube.com/results?search_query=' + enc;
  if (method === 'atv') {
    try { remote.sendAppLink(url); } catch { throw fail(502, 'send_failed', 'Mất kết nối với TV. Hãy kết nối lại.'); }
    return {};
  }
  await adb(['-s', target, 'shell', 'am', 'start', '-a', 'android.intent.action.VIEW', '-d', `'${url}'`], 6000);
  return {};
}));
app.post('/api/remote/text', h(async (req) => {
  if (state !== 'connected') throw fail(409, 'not_connected', 'Chưa kết nối với TV.');
  if (method !== 'adb') throw fail(400, 'unsupported_text', 'Nhập văn bản hiện chỉ hỗ trợ khi kết nối bằng ADB (mục Nâng cao).');
  const text = String((req.body || {}).text || '');
  // `adb shell` nối chuỗi rồi đưa cho shell của TV nên chỉ cho phép tập ký tự an toàn
  if (!/^[A-Za-z0-9 .,_@-]{1,200}$/.test(text))
    throw fail(400, 'unsupported_text', 'ADB chỉ gửi được chữ không dấu, số và . , _ @ - (không hỗ trợ tiếng Việt có dấu).');
  await adb(['-s', target, 'shell', 'input', 'text', text.replace(/ /g, '%s')], 6000);
  return {};
}));

app.use(express.static(path.join(__dirname, 'public')));
app.listen(PORT, HOST, () => {
  console.log(`Smart TV Remote chạy tại http://localhost:${PORT}/?token=${TOKEN}`);
  if (LAN) console.log('Chế độ LAN đang BẬT: dùng http://<IP-máy-này>:' + PORT + '/?token=... và chặn cổng bằng firewall nếu cần.');
});
