const defaults = () => ({
  customers: [],
  workers: [],
  entries: [],
  settings: { tractorRate: 2500, motorRate: 1500, solarRate: 60, wapdaRate: 65, customCategories: [] }
});
const recordCollections = ['customers', 'workers', 'entries'];
const now = previous => Math.max(Date.now(), Number(previous || 0) + 1);
const makeId = () => globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
const clone = value => JSON.parse(JSON.stringify(value));
const storageKey = uid => uid ? `kmt-data:${uid}` : 'kmt-data';
const queueKey = uid => `kmt-outbox:${uid}`;

function readJson(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    console.error(`Unable to read local ledger data (${key}).`, error);
    return fallback;
  }
}

function timestamp(value) {
  if (typeof value === 'number') return value;
  if (value && typeof value.toMillis === 'function') return value.toMillis();
  return 0;
}

function normalizeRecord(record) {
  const updatedAt = timestamp(record.updatedAt) || 0;
  const fieldTimes = { ...(record._fieldUpdatedAt || {}) };
  for (const key of Object.keys(record)) {
    if (key !== '_fieldUpdatedAt' && key !== 'updatedAt' && !fieldTimes[key]) {
      fieldTimes[key] = updatedAt;
    }
  }
  return { ...record, updatedAt, _fieldUpdatedAt: fieldTimes };
}

function mergeRecord(local, remote) {
  if (!local) return normalizeRecord(remote);
  if (!remote) return normalizeRecord(local);
  const left = normalizeRecord(local);
  const right = normalizeRecord(remote);
  const fields = new Set([...Object.keys(left), ...Object.keys(right)]);
  const merged = { id: left.id || right.id, _fieldUpdatedAt: {} };

  for (const key of fields) {
    if (key === 'id' || key === '_fieldUpdatedAt' || key === 'updatedAt') continue;
    const localTime = left._fieldUpdatedAt[key] || left.updatedAt;
    const remoteTime = right._fieldUpdatedAt[key] || right.updatedAt;
    const source = remoteTime > localTime ? right : left;
    if (Object.prototype.hasOwnProperty.call(source, key)) merged[key] = source[key];
    merged._fieldUpdatedAt[key] = Math.max(localTime, remoteTime);
  }
  merged.updatedAt = Math.max(left.updatedAt, right.updatedAt);
  return merged;
}

function sameRecord(a, b) {
  const stable = value => Array.isArray(value)
    ? value.map(stable)
    : value && typeof value === 'object'
      ? Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])]))
      : value;
  return JSON.stringify(stable(a)) === JSON.stringify(stable(b));
}

export class LedgerStore extends EventTarget {
  constructor() {
    super();
    this.uid = null;
    this.cloud = null;
    this.data = readJson('kmt-data', defaults());
    this.data = { ...defaults(), ...this.data };
    this.data.settings = { ...defaults().settings, ...(this.data.settings || {}) };
    this.unsubscribers = [];
    this.queue = new Map();
    this.flushing = false;
    window.addEventListener('online', () => this.flush());
  }

  get snapshot() {
    return clone(this.data);
  }

  persist() {
    localStorage.setItem(storageKey(this.uid), JSON.stringify(this.data));
    this.dispatchEvent(new CustomEvent('change', { detail: this.snapshot }));
  }

  setUser(uid) {
    if (this.uid === uid) return;
    const guestData = this.uid === null ? this.snapshot : null;
    this.persist();
    this.stopRemote();
    this.uid = uid;
    const userData = readJson(storageKey(uid), null);
    if (userData) {
      this.data = { ...defaults(), ...userData };
      this.data.settings = { ...defaults().settings, ...(userData.settings || {}) };
    } else if (uid && guestData) {
      this.data = guestData;
      this.persist();
      for (const kind of recordCollections) {
        for (const record of this.data[kind]) this.queueRecord(kind, record);
      }
      this.queueRecord('settings', this.data.settings);
    } else {
      this.data = defaults();
    }
    this.queue = new Map(
      uid ? readJson(queueKey(uid), []).map(item => [`${item.kind}:${item.id}`, item]) : []
    );
    this.persist();
  }

  setCloudClient(cloud) {
    this.cloud = cloud;
    this.flush();
  }

  upsert(kind, input) {
    const existing = this.data[kind].find(record => record.id === input.id);
    const updatedAt = now(existing?.updatedAt);
    const fieldUpdatedAt = { ...(existing?._fieldUpdatedAt || {}) };
    for (const key of Object.keys(input)) {
      if (key !== 'id' && key !== '_fieldUpdatedAt' && key !== 'updatedAt') {
        fieldUpdatedAt[key] = updatedAt;
      }
    }
    const record = {
      ...existing,
      ...input,
      id: input.id || makeId(),
      updatedAt,
      _fieldUpdatedAt: fieldUpdatedAt
    };
    const index = this.data[kind].findIndex(item => item.id === record.id);
    if (index < 0) this.data[kind].push(record);
    else this.data[kind][index] = record;
    this.queueRecord(kind, record);
    this.persist();
    return record;
  }

  updateSettings(input) {
    const updatedAt = now(this.data.settings.updatedAt);
    const fieldUpdatedAt = { ...(this.data.settings._fieldUpdatedAt || {}) };
    for (const key of Object.keys(input)) fieldUpdatedAt[key] = updatedAt;
    this.data.settings = {
      ...this.data.settings,
      ...input,
      updatedAt,
      _fieldUpdatedAt: fieldUpdatedAt
    };
    this.queueRecord('settings', this.data.settings);
    this.persist();
  }

  setDeleted(kind, id, deleted) {
    const record = this.data[kind].find(item => item.id === id);
    if (record) this.upsert(kind, { id, deleted: Boolean(deleted) });
  }

  replaceData(input) {
    for (const kind of recordCollections) {
      const incoming = new Map((input[kind] || []).map(record => [record.id, record]));
      for (const record of this.data[kind]) {
        if (!incoming.has(record.id) && !record.deleted) this.setDeleted(kind, record.id, true);
      }
      for (const record of incoming.values()) {
        this.upsert(kind, { ...record, id: record.id || makeId(), deleted: Boolean(record.deleted) });
      }
    }
    const settings = input.settings || {};
    this.updateSettings({
      tractorRate: Number(settings.tractorRate ?? 2500),
      motorRate: Number(settings.motorRate ?? 1500),
      solarRate: Number(settings.solarRate ?? 60),
      wapdaRate: Number(settings.wapdaRate ?? 65),
      customCategories: Array.isArray(settings.customCategories) ? settings.customCategories : []
    });
  }

  queueRecord(kind, record) {
    if (!this.uid) return;
    const id = kind === 'settings' ? 'main' : record.id;
    this.queue.set(`${kind}:${id}`, { kind, id, record: clone(record) });
    localStorage.setItem(queueKey(this.uid), JSON.stringify([...this.queue.values()]));
    this.flush();
  }

  connectRemote(onStatus, translate = key => key) {
    if (!this.uid || !this.cloud) return;
    this.stopRemote();
    const uid = this.uid;
    onStatus(translate('cloudConnect'));
    this.migrateLegacyDocument(uid, onStatus, translate);
    const { firestore, firestoreSdk: sdk } = this.cloud;

    for (const kind of recordCollections) {
      const ref = sdk.collection(firestore, 'users', uid, kind);
      const unsubscribe = sdk.onSnapshot(ref, snapshot => {
        if (uid !== this.uid) return;
        const remoteRecords = snapshot.docs.map(item => normalizeRecord({ id: item.id, ...item.data() }));
        const localRecords = this.data[kind];
        const byId = new Map(remoteRecords.map(item => [item.id, item]));
        const merged = new Map();
        for (const record of [...localRecords, ...remoteRecords]) {
          merged.set(record.id, mergeRecord(merged.get(record.id), byId.get(record.id) || record));
        }
        this.data[kind] = [...merged.values()];
        this.persist();

        for (const record of this.data[kind]) {
          const remote = byId.get(record.id);
          if (!remote || !sameRecord(record, remote)) this.queueRecord(kind, record);
        }
        onStatus(navigator.onLine ? translate('cloudSyncActive') : translate('cloudQueued'));
        this.flush();
      }, error => {
        console.error(`Real-time ${kind} sync failed.`, error);
        onStatus(translate('cloudCollectionFailed'));
      });
      this.unsubscribers.push(unsubscribe);
    }

    const settingsRef = sdk.doc(firestore, 'users', uid, 'settings', 'main');
    const unsubscribeSettings = sdk.onSnapshot(settingsRef, snapshot => {
      if (uid !== this.uid) return;
      if (snapshot.exists()) {
        const remote = normalizeRecord({ id: 'main', ...snapshot.data() });
        this.data.settings = mergeRecord(this.data.settings, remote);
        this.persist();
        if (!sameRecord(this.data.settings, remote)) this.queueRecord('settings', this.data.settings);
      } else {
        this.queueRecord('settings', this.data.settings);
      }
      this.flush();
    }, error => {
      console.error('Real-time settings sync failed.', error);
      onStatus(translate('cloudSettingsFailed'));
    });
    this.unsubscribers.push(unsubscribeSettings);
  }

  async migrateLegacyDocument(uid, onStatus, translate = key => key) {
    const marker = `kmt-legacy-migrated:${uid}`;
    if (localStorage.getItem(marker)) return;
    try {
      const { firestore, firestoreSdk: sdk } = this.cloud;
      const legacy = await sdk.getDoc(sdk.doc(firestore, 'users', uid, 'ledger', 'main'));
      if (uid !== this.uid) return;
      if (legacy.exists()) {
        const legacyDocument = legacy.data();
        const oldData = legacyDocument.data || {};
        const legacyUpdatedAt = timestamp(legacyDocument.updatedAt);
        for (const kind of recordCollections) {
          const merged = new Map(this.data[kind].map(record => [record.id, record]));
          for (const record of oldData[kind] || []) {
            if (!record.id) continue;
            const migrated = record.updatedAt ? record : { ...record, updatedAt: legacyUpdatedAt };
            merged.set(record.id, mergeRecord(merged.get(record.id), migrated));
          }
          this.data[kind] = [...merged.values()];
          for (const record of this.data[kind]) this.queueRecord(kind, record);
        }
        if (oldData.settings) {
          const migratedSettings = oldData.settings.updatedAt
            ? oldData.settings
            : { ...oldData.settings, updatedAt: legacyUpdatedAt };
          this.data.settings = mergeRecord(this.data.settings, migratedSettings);
          this.queueRecord('settings', this.data.settings);
        }
        this.persist();
        onStatus(translate('cloudMigrationDone'));
      }
      localStorage.setItem(marker, 'true');
    } catch (error) {
      console.error('Legacy cloud migration failed; existing cloud data was left unchanged.', error);
      onStatus(translate('cloudMigrationFailed'));
    }
  }

  stopRemote() {
    for (const unsubscribe of this.unsubscribers) unsubscribe();
    this.unsubscribers = [];
  }

  async flush() {
    if (!this.uid || !this.cloud || !navigator.onLine || this.flushing || !this.queue.size) return;
    this.flushing = true;
    const uid = this.uid;
    const { firestore, firestoreSdk: sdk } = this.cloud;
    try {
      while (this.queue.size && this.uid === uid && navigator.onLine) {
        const [key, item] = this.queue.entries().next().value;
        const ref = item.kind === 'settings'
          ? sdk.doc(firestore, 'users', uid, 'settings', 'main')
          : sdk.doc(firestore, 'users', uid, item.kind, item.id);
        await sdk.setDoc(ref, item.record);
        if (this.uid !== uid) break;
        if (sameRecord(this.queue.get(key)?.record, item.record)) this.queue.delete(key);
        localStorage.setItem(queueKey(uid), JSON.stringify([...this.queue.values()]));
      }
    } catch (error) {
      console.error('Cloud queue push failed; it will retry when connectivity returns.', error);
      this.dispatchEvent(new CustomEvent('sync-error', { detail: error }));
    } finally {
      this.flushing = false;
      if (this.uid !== uid) this.flush();
    }
  }
}
