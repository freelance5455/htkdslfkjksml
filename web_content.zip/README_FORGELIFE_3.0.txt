ForgeLife 3.0 — Forge AI Engine Edition

This version makes the built-in offline Forge AI Engine the primary assistant. It does not require a neural model download, API key, or internet connection for normal engine features.

Open the project root in Android Studio and allow Gradle sync. Then choose Build > Build APK(s). Install the resulting APK and test Forge AI in airplane mode.

The engine combines the existing offline knowledge directory, weighted retrieval, synonym expansion, saved-memory lookup, recent chat context, calculations, device date/time, and direct access to ForgeLife finance/workout/calendar data.

Honest limitation: the engine is deterministic and symbolic/retrieval-based, not a trained neural LLM. It cannot match Qwen3's open-ended language generation or learned reasoning. It prefers to say when its offline knowledge is insufficient rather than invent facts.

See ENGINE_ARCHITECTURE.txt and ENGINE_TESTS.txt.

Version 3.1 adds 25 topic-specific offline directories and 250 focused knowledge references, plus directory guides. The searchable library now exceeds 4,000 records. The architecture enforces a maximum of 1,000,000 records; it does not pretend that one million curated articles are included. See KNOWLEDGE_EXPANSION_3.1.txt.
