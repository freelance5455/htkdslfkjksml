# APK + Google Play Billing configuration

## Logo
The supplied MDCAT & NUMS Presentation logo is installed as the Android launcher icon.

## Important distinction
A directly shared APK is useful for UI/offline testing. Real Google Play subscription purchases should be tested through Google Play test tracks because Play Billing is tied to the Play-distributed app/package configuration.

## Billing setup
1. In Play Console, create the app with package name:
   `com.mdcatnums.prep`
2. Create subscriptions:
   - `premium_monthly`
   - `premium_3months`
   - `premium_yearly`
3. Give each subscription an active base plan and price.
4. Add test users and use an internal/closed testing track.
5. Configure a Google Cloud service account with the Android Publisher API.
6. Put the service-account credentials only on the backend, never in the APK.
7. Deploy the `backend/` folder over HTTPS.
8. Set the Android `config.js` API_BASE to that HTTPS backend.
9. Configure Google Play Real-time Developer Notifications (RTDN) through Pub/Sub to:
   `/api/play/rtdn`
10. The backend verifies purchase tokens and stores the entitlement.

## Current limitation
This environment does not contain the Android SDK/Gradle build toolchain, so I cannot honestly claim that a compiled APK was produced here. The project is prepared with the logo; open `android/` in Android Studio and build an APK from it.

Do not send passwords, payment details, private keys, or service-account JSON here.
