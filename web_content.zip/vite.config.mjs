import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

/**
 * תצוגה מקדימה של Vite (React Web Preview).
 * הרצה: npx vite  |  בנייה: npx vite build  |  תצוגה מקדימה: npx vite preview
 *
 * הערה: שרת ה-API (Next.js Route Handlers) רץ על פורט 3000,
 * ולכן כל הקריאות ל-/api מנותבות אליו דרך proxy כדי למנוע חסימות CORS.
 */
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(process.cwd(), "src"),
    },
  },
  server: {
    port: 5173,
    host: true,
    proxy: {
      "/api": {
        target: process.env.API_PROXY_TARGET || "http://127.0.0.1:3000",
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: "dist",
    sourcemap: false,
    emptyOutDir: true,
  },
});
