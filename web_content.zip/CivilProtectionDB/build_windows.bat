@echo off
cd /d "%~dp0"
echo [1/3] Installing libraries...
python -m pip install -r requirements.txt
if errorlevel 1 goto :err
echo [2/3] Building CivilProtectionDB.exe ...
set ADD=
if exist logo.png set ADD=--add-data "logo.png;."
python -m PyInstaller --noconfirm --onefile --windowed --name CivilProtectionDB %ADD% civil_protection_db.py
if errorlevel 1 goto :err
echo [3/3] Building installer (requires Inno Setup 6)...
set ISCC="%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% goto :noiscc
%ISCC% setup.iss
goto :done
:noiscc
echo Inno Setup not found - skipping installer. Install it from jrsoftware.org then run this file again.
:done
echo.
echo DONE.
echo   Program : dist\CivilProtectionDB.exe
echo   Setup   : installer\CivilProtectionDB_Setup.exe
pause
exit /b 0
:err
echo ERROR: build failed. Make sure Python 3.10+ is installed with "Add to PATH".
pause
exit /b 1
