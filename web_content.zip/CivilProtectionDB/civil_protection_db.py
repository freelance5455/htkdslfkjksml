# -*- coding: utf-8 -*-
"""
نظام إدارة موظفي الحماية المدنية الجزائرية
- تخزين في قاعدة بيانات SQLite (سعة كبيرة، ملف واحد)
- استيراد وتصدير Excel (.xlsx)
- استيراد وتصدير بطاقات ومعلومات Word (.docx)
- طباعة القوائم والبطاقات
- إضافة خانات ديناميكية تطبق على جميع الموظفين
- شعار الحماية المدنية أعلى الواجهة في الوسط (logo.png بجانب البرنامج)
"""
import os
import sys
import json
import uuid
import tempfile
import sqlite3
import shutil
import hashlib
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

try:
    import openpyxl
    from openpyxl.styles import Font
except ImportError:
    openpyxl = None

try:
    import docx
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
except ImportError:
    docx = None


# ---------------------------------------------------------------- الإعدادات
# ملفات البرنامج (الشعار المرفق) وبيانات المستخدم في مجلد قابل للكتابة دائماً
RES_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "CivilProtectionDB")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
os.makedirs(BACKUP_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "civil_protection.db")
USER_LOGO = os.path.join(DATA_DIR, "logo.png")
BUNDLED_LOGO = os.path.join(RES_DIR, "logo.png")
APP_TITLE = "نظام إدارة موظفي الحماية المدنية الجزائرية"

# (المفتاح، الاسم بالعربية، إلزامي؟)
FIELDS = [
    ("matricule", "رقم القيد", True),
    ("full_name", "الاسم واللقب", True),
    ("birth_date", "تاريخ الميلاد", False),
    ("birth_place", "مكان الميلاد", False),
    ("grade", "الرتبة", False),
    ("unit", "الوحدة / المركز", False),
    ("wilaya", "الولاية", False),
    ("daira", "الدائرة", False),
    ("incorporation_date", "تاريخ الالتحاق", False),
    ("blood_type", "فصيلة الدم", False),
    ("phone", "الهاتف", False),
    ("address", "العنوان", False),
    ("family_status", "الوضعية العائلية", False),
    ("qualifications", "المؤهلات والدورات", False),
]
FIXED_KEYS = [k for k, _, _ in FIELDS]

LIST_COLUMNS = [
    ("matricule", "رقم القيد"),
    ("full_name", "الاسم واللقب"),
    ("grade", "الرتبة"),
    ("unit", "الوحدة / المركز"),
    ("wilaya", "الولاية"),
    ("phone", "الهاتف"),
]

RED = "#d71920"
DARK_RED = "#8b0e12"
BG = "#f4f6f9"


# ---------------------------------------------------------------- قاعدة البيانات
class Database:
    def __init__(self, path):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")

        cols = []
        for key, _, required in FIELDS:
            if key == "matricule":
                cols.append("matricule TEXT NOT NULL UNIQUE")
            elif required:
                cols.append(f"{key} TEXT NOT NULL DEFAULT ''")
            else:
                cols.append(f"{key} TEXT NOT NULL DEFAULT ''")

        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS employees ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + ", ".join(cols)
            + ", extra TEXT NOT NULL DEFAULT '{}')"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS custom_fields ("
            "key TEXT PRIMARY KEY, label TEXT NOT NULL UNIQUE)"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        self.conn.commit()

    # ---- الخانات الديناميكية
    def custom_fields(self):
        return [(r["key"], r["label"]) for r in self.conn.execute(
            "SELECT key, label FROM custom_fields ORDER BY rowid")]

    def custom_keys(self):
        return [k for k, _ in self.custom_fields()]

    def field_list(self):
        """كل الخانات: (المفتاح، الاسم، هل هي أساسية، إلزامي)"""
        items = [(k, l, True, r) for k, l, r in FIELDS]
        items += [(k, l, False, False) for k, l in self.custom_fields()]
        return items

    def add_custom_field(self, label):
        label = label.strip()
        if not label:
            raise ValueError("اسم الخانة فارغ")
        key = "custom_" + uuid.uuid4().hex[:8]
        self.conn.execute("INSERT INTO custom_fields(key, label) VALUES(?, ?)", (key, label))
        self.conn.commit()
        return key

    def ensure_custom_field(self, label):
        row = self.conn.execute(
            "SELECT key FROM custom_fields WHERE label=?", (label,)).fetchone()
        if row:
            return row["key"]
        return self.add_custom_field(label)

    # ---- الموظفون
    def _to_dict(self, row):
        d = {k: row[k] for k in FIXED_KEYS}
        d["id"] = row["id"]
        try:
            extra = json.loads(row["extra"] or "{}")
        except json.JSONDecodeError:
            extra = {}
        d.update(extra)
        return d

    def save_employee(self, data, emp_id=None):
        values = [str(data.get(k, "") or "").strip() for k in FIXED_KEYS]
        extra = {k: str(data.get(k, "") or "").strip() for k in self.custom_keys()}
        values.append(json.dumps(extra, ensure_ascii=False))
        cols = FIXED_KEYS + ["extra"]
        try:
            if emp_id is None:
                sql = (f"INSERT INTO employees ({', '.join(cols)}) "
                       f"VALUES ({', '.join('?' * len(cols))})")
                self.conn.execute(sql, values)
            else:
                sql = (f"UPDATE employees SET {', '.join(c + '=?' for c in cols)} "
                       f"WHERE id=?")
                self.conn.execute(sql, values + [emp_id])
            self.conn.commit()
        except sqlite3.Error:
            self.conn.rollback()
            raise

    def delete_employee(self, emp_id):
        self.conn.execute("DELETE FROM employees WHERE id=?", (emp_id,))
        self.conn.commit()

    def get_employee(self, emp_id):
        row = self.conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
        return self._to_dict(row) if row else None

    def find_by_matricule(self, matricule):
        row = self.conn.execute(
            "SELECT * FROM employees WHERE matricule=?", (matricule,)).fetchone()
        return self._to_dict(row) if row else None

    def search(self, text=""):
        t = f"%{text.strip()}%"
        rows = self.conn.execute(
            "SELECT * FROM employees WHERE matricule LIKE ? OR full_name LIKE ? "
            "OR grade LIKE ? OR unit LIKE ? OR wilaya LIKE ? "
            "ORDER BY matricule", (t, t, t, t, t)).fetchall()
        return [self._to_dict(r) for r in rows]

    def count(self):
        return self.conn.execute("SELECT COUNT(*) FROM employees").fetchone()[0]

    # ---- الإعدادات وكلمة المرور
    def get_setting(self, key):
        r = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else None

    def set_setting(self, key, value):
        self.conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)", (key, value))
        self.conn.commit()

    @staticmethod
    def _hash(pw, salt):
        return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, 200000).hex()

    def has_password(self):
        return self.get_setting("pw_hash") is not None

    def set_password(self, pw):
        salt = os.urandom(16)
        self.set_setting("pw_salt", salt.hex())
        self.set_setting("pw_hash", self._hash(pw, salt))

    def check_password(self, pw):
        salt, h = self.get_setting("pw_salt"), self.get_setting("pw_hash")
        return bool(salt and h) and self._hash(pw, bytes.fromhex(salt)) == h

    # ---- النسخ الاحتياطي
    def backup_to(self, path):
        self.conn.commit()
        dst = sqlite3.connect(path)
        try:
            self.conn.backup(dst)
        finally:
            dst.close()

    def restore_from(self, path):
        src = sqlite3.connect(path)
        try:
            src.execute("SELECT matricule, extra FROM employees LIMIT 1")
            src.backup(self.conn)
        finally:
            src.close()


# ---------------------------------------------------------------- مساعدات
def set_rtl(paragraph):
    """جعل فقرة Word من اليمين إلى اليسار"""
    pPr = paragraph._p.get_or_add_pPr()
    pPr.append(OxmlElement("w:bidi"))
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT


def cell_text(v):
    if v is None:
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()


# ---------------------------------------------------------------- الواجهة
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1150x720")
        self.minsize(950, 580)
        self.configure(bg=BG)

        self.ok = False
        self.db = Database(DB_PATH)
        self.withdraw()
        if not self._login():
            self.destroy()
            return
        self._auto_backup()
        self.ok = True
        self.logo_img = self._load_logo()

        self._build_menu()
        self._build_header()
        self._build_toolbar()
        self._build_status()
        self._build_table()

        self.bind("<Control-n>", lambda e: self.open_form())
        self.bind("<Control-f>", lambda e: self.search_entry.focus_set())
        self.bind("<Delete>", lambda e: self.delete_selected())

        self.refresh()
        self.deiconify()

    # ---- الدخول والنسخ الاحتياطي والإعدادات
    def _login(self):
        if not self.db.has_password():
            messagebox.showinfo(APP_TITLE, "أول تشغيل: الرجاء تعيين كلمة مرور لمدير النظام.\n"
                                "احتفظ بها في مكان آمن، فلا يمكن استرجاعها إذا نُسيت.")
            while True:
                p1 = simpledialog.askstring(APP_TITLE, "كلمة المرور الجديدة (4 أحرف على الأقل):",
                                            show="*", parent=self)
                if p1 is None:
                    return False
                if len(p1) < 4:
                    messagebox.showerror(APP_TITLE, "كلمة المرور قصيرة جداً.")
                    continue
                p2 = simpledialog.askstring(APP_TITLE, "أعد كتابة كلمة المرور:", show="*", parent=self)
                if p2 is None:
                    return False
                if p1 != p2:
                    messagebox.showerror(APP_TITLE, "كلمتا المرور غير متطابقتين.")
                    continue
                self.db.set_password(p1)
                return True
        for _ in range(3):
            p = simpledialog.askstring(APP_TITLE, "أدخل كلمة المرور:", show="*", parent=self)
            if p is None:
                return False
            if self.db.check_password(p):
                return True
            messagebox.showerror(APP_TITLE, "كلمة المرور غير صحيحة.")
        return False

    def _auto_backup(self):
        """نسخة احتياطية تلقائية يومية، مع الاحتفاظ بآخر 30 نسخة"""
        try:
            name = os.path.join(BACKUP_DIR, f"auto_{datetime.date.today():%Y%m%d}.db")
            if not os.path.exists(name):
                self.db.backup_to(name)
            for f in sorted(x for x in os.listdir(BACKUP_DIR) if x.startswith("auto_"))[:-30]:
                os.remove(os.path.join(BACKUP_DIR, f))
        except OSError:
            pass

    def manual_backup(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".db", filetypes=[("نسخة احتياطية", "*.db")],
            initialfile=f"نسخة_احتياطية_{datetime.date.today():%Y%m%d}.db")
        if path:
            self.db.backup_to(path)
            messagebox.showinfo(APP_TITLE, f"تم حفظ النسخة الاحتياطية:\n{path}")

    def restore_backup(self):
        path = filedialog.askopenfilename(filetypes=[("نسخة احتياطية", "*.db")])
        if not path:
            return
        if not messagebox.askyesno(APP_TITLE, "سيتم استبدال كل البيانات الحالية بالنسخة المختارة "
                                   "(بما فيها كلمة المرور). متابعة؟"):
            return
        try:
            self.db.restore_from(path)
        except sqlite3.Error as e:
            messagebox.showerror(APP_TITLE, f"ملف غير صالح:\n{e}")
            return
        self.refresh()
        messagebox.showinfo(APP_TITLE, "تم استرجاع النسخة الاحتياطية.")

    def open_data_dir(self):
        if sys.platform.startswith("win"):
            os.startfile(DATA_DIR)
        else:
            messagebox.showinfo(APP_TITLE, DATA_DIR)

    def change_password(self):
        old = simpledialog.askstring(APP_TITLE, "كلمة المرور الحالية:", show="*", parent=self)
        if old is None:
            return
        if not self.db.check_password(old):
            messagebox.showerror(APP_TITLE, "كلمة المرور الحالية غير صحيحة.")
            return
        new = simpledialog.askstring(APP_TITLE, "كلمة المرور الجديدة (4 أحرف على الأقل):",
                                     show="*", parent=self)
        if not new or len(new) < 4:
            messagebox.showerror(APP_TITLE, "كلمة المرور قصيرة جداً.")
            return
        if simpledialog.askstring(APP_TITLE, "أعد كتابتها:", show="*", parent=self) != new:
            messagebox.showerror(APP_TITLE, "كلمتا المرور غير متطابقتين.")
            return
        self.db.set_password(new)
        messagebox.showinfo(APP_TITLE, "تم تغيير كلمة المرور.")

    def change_logo(self):
        path = filedialog.askopenfilename(filetypes=[("صورة PNG", "*.png")])
        if not path:
            return
        try:
            tk.PhotoImage(file=path)
        except tk.TclError:
            messagebox.showerror(APP_TITLE, "الصورة غير صالحة. استخدم ملف PNG.")
            return
        shutil.copyfile(path, USER_LOGO)
        messagebox.showinfo(APP_TITLE, "تم حفظ الشعار. أعد تشغيل البرنامج لتطبيقه.")

    # ---- الشعار والعنوان (أعلى الواجهة في الوسط)
    def _load_logo(self):
        for path in (USER_LOGO, BUNDLED_LOGO):
            if os.path.exists(path):
                try:
                    img = tk.PhotoImage(file=path)
                    factor = max(1, max(img.width(), img.height()) // 110)
                    if factor > 1:
                        img = img.subsample(factor)
                    return img
                except tk.TclError:
                    pass
        return None

    def _build_header(self):
        head = tk.Frame(self, bg="white")
        head.pack(fill="x")

        if self.logo_img:
            tk.Label(head, image=self.logo_img, bg="white").pack(pady=(10, 0))
        else:
            c = tk.Canvas(head, width=110, height=110, bg="white", highlightthickness=0)
            c.create_oval(4, 4, 106, 106, fill=RED, outline=DARK_RED, width=3)
            c.create_text(55, 55, text="الحماية\nالمدنية", fill="white",
                          font=("Segoe UI", 11, "bold"), justify="center")
            c.pack(pady=(10, 0))

        tk.Label(head, text="الحماية المدنية الجزائرية",
                 font=("Segoe UI", 16, "bold"), bg="white", fg=RED).pack(pady=(4, 0))
        tk.Label(head, text="نظام إدارة ومعالجة وتخزين معلومات الموظفين",
                 font=("Segoe UI", 10), bg="white", fg="#333").pack(pady=(0, 10))

    def _build_menu(self):
        menubar = tk.Menu(self)

        f = tk.Menu(menubar, tearoff=0)
        f.add_command(label="استيراد من Excel", command=self.import_excel)
        f.add_command(label="استيراد من Word", command=self.import_word)
        f.add_separator()
        f.add_command(label="تصدير إلى Excel", command=self.export_excel)
        f.add_command(label="تصدير بطاقة الموظف إلى Word", command=self.export_card)
        f.add_command(label="طباعة القائمة", command=self.print_list)
        f.add_separator()
        f.add_command(label="نسخة احتياطية الآن...", command=self.manual_backup)
        f.add_command(label="استرجاع نسخة احتياطية...", command=self.restore_backup)
        f.add_command(label="فتح مجلد البيانات", command=self.open_data_dir)
        f.add_separator()
        f.add_command(label="خروج", command=self.destroy)
        menubar.add_cascade(label="ملف", menu=f)

        e = tk.Menu(menubar, tearoff=0)
        e.add_command(label="إضافة موظف (Ctrl+N)", command=self.open_form)
        e.add_command(label="تعديل الموظف المحدد", command=self.edit_selected)
        e.add_command(label="حذف الموظف المحدد", command=self.delete_selected)
        menubar.add_cascade(label="تعديل", menu=e)

        a = tk.Menu(menubar, tearoff=0)
        a.add_command(label="إضافة خانة جديدة للنظام", command=self.add_field)
        a.add_command(label="تغيير كلمة المرور", command=self.change_password)
        a.add_command(label="تغيير شعار المؤسسة (PNG)", command=self.change_logo)
        menubar.add_cascade(label="إدارة", menu=a)

        self.config(menu=menubar)

    def _build_toolbar(self):
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=10, pady=6)

        buttons = [
            ("جديد", self.open_form),
            ("تعديل", self.edit_selected),
            ("حذف", self.delete_selected),
            ("بطاقة Word", self.export_card),
            ("تصدير Excel", self.export_excel),
            ("طباعة", self.print_list),
            ("إضافة خانة", self.add_field),
        ]
        for text, cmd in buttons:
            tk.Button(bar, text=text, command=cmd, width=11, bg="white",
                      relief="groove", font=("Segoe UI", 10)).pack(side="left", padx=3)

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self.refresh())
        tk.Label(bar, text="بحث:", bg=BG, font=("Segoe UI", 10)).pack(side="right", padx=(0, 4))
        self.search_entry = tk.Entry(bar, textvariable=self.search_var, width=32,
                                     justify="right", font=("Segoe UI", 11))
        self.search_entry.pack(side="right", padx=4, ipady=2)

    def _build_status(self):
        self.status = tk.Label(self, anchor="w", bd=1, relief="sunken",
                               font=("Segoe UI", 9), bg="#e9ecf1")
        self.status.pack(side="bottom", fill="x")

    def _build_table(self):
        frame = tk.Frame(self, bg=BG)
        frame.pack(fill="both", expand=True, padx=10, pady=(0, 6))

        cols = [c for c, _ in LIST_COLUMNS]
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")
        for c, label in LIST_COLUMNS:
            self.tree.heading(c, text=label)
            self.tree.column(c, anchor="center", width=170)

        sb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", lambda e: self.edit_selected())

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        rows = self.db.search(self.search_var.get())
        for r in rows:
            self.tree.insert("", "end", iid=str(r["id"]),
                             values=tuple(r.get(c, "") for c, _ in LIST_COLUMNS))
        self.status.config(
            text=f"  عدد الموظفين المعروضين: {len(rows)}  |  إجمالي المسجلين: {self.db.count()}"
                 f"  |  قاعدة البيانات: {DB_PATH}")

    def selected_id(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning(APP_TITLE, "الرجاء اختيار موظف من القائمة أولاً.")
            return None
        return int(sel[0])

    # ---- إدخال وتعديل وحذف
    def open_form(self, emp_id=None):
        data = self.db.get_employee(emp_id) if emp_id else {}

        win = tk.Toplevel(self)
        win.title("تعديل بيانات موظف" if emp_id else "إضافة موظف جديد")
        win.configure(bg=BG)
        win.transient(self)
        win.grab_set()

        body = tk.Frame(win, padx=18, pady=14, bg=BG)
        body.pack(fill="both", expand=True)

        fields = self.db.field_list()
        entries = {}
        for i, (key, label, _, required) in enumerate(fields):
            tk.Label(body, text=label + (" *" if required else ""), anchor="e", width=24,
                     font=("Segoe UI", 10), bg=BG).grid(row=i, column=1, sticky="e", pady=3)
            ent = tk.Entry(body, width=42, justify="right", font=("Segoe UI", 10))
            ent.insert(0, data.get(key, "") or "")
            ent.grid(row=i, column=0, sticky="w", pady=3, padx=4)
            entries[key] = ent

        def save():
            values = {k: e.get().strip() for k, e in entries.items()}
            for key, label, _, required in fields:
                if required and not values.get(key):
                    messagebox.showerror(APP_TITLE, f"الحقل '{label}' إلزامي.", parent=win)
                    return
            try:
                self.db.save_employee(values, emp_id)
            except sqlite3.IntegrityError:
                messagebox.showerror(APP_TITLE,
                                     "رقم القيد مكرر! الرجاء إدخال رقم قيد آخر.", parent=win)
                return
            win.destroy()
            self.refresh()

        btns = tk.Frame(win, bg=BG)
        btns.pack(pady=(0, 14))
        tk.Button(btns, text="حفظ", width=12, bg=RED, fg="white",
                  font=("Segoe UI", 10, "bold"), command=save).pack(side="left", padx=6)
        tk.Button(btns, text="إلغاء", width=12, command=win.destroy,
                  font=("Segoe UI", 10)).pack(side="left", padx=6)

    def edit_selected(self):
        emp_id = self.selected_id()
        if emp_id:
            self.open_form(emp_id)

    def delete_selected(self):
        emp_id = self.selected_id()
        if emp_id and messagebox.askyesno(APP_TITLE, "هل أنت متأكد من حذف هذا الموظف نهائياً؟"):
            self.db.delete_employee(emp_id)
            self.refresh()

    def add_field(self):
        label = simpledialog.askstring(APP_TITLE, "اسم الخانة الجديدة:", parent=self)
        if not label:
            return
        try:
            self.db.add_custom_field(label)
        except (sqlite3.IntegrityError, ValueError) as e:
            messagebox.showerror(APP_TITLE, f"تعذر إضافة الخانة: {e}\nربما الاسم موجود مسبقاً.")
            return
        messagebox.showinfo(APP_TITLE, "تمت إضافة الخانة وستظهر لجميع الموظفين (القدامى والجدد).")

    # ---- الاستيراد
    def import_excel(self):
        if openpyxl is None:
            return self._missing("openpyxl")
        path = filedialog.askopenfilename(filetypes=[("ملفات Excel", "*.xlsx")])
        if not path:
            return
        wb = openpyxl.load_workbook(path, data_only=True)
        rows = list(wb.active.iter_rows(values_only=True))
        if len(rows) < 2:
            messagebox.showwarning(APP_TITLE, "الملف لا يحتوي على بيانات.")
            return
        headers = [cell_text(h) for h in rows[0]]
        records = []
        for r in rows[1:]:
            if all(v in (None, "") for v in r):
                continue
            records.append({h: cell_text(v) for h, v in zip(headers, r) if h})
        self._import_records(records)

    def import_word(self):
        if docx is None:
            return self._missing("python-docx")
        path = filedialog.askopenfilename(filetypes=[("ملفات Word", "*.docx")])
        if not path:
            return
        document = docx.Document(path)
        records = []
        for table in document.tables:
            if len(table.rows) < 2:
                continue
            headers = [c.text.strip() for c in table.rows[0].cells]
            for row in table.rows[1:]:
                vals = [c.text.strip() for c in row.cells]
                if any(vals):
                    records.append({h: v for h, v in zip(headers, vals) if h})
        if not records:
            messagebox.showwarning(APP_TITLE, "لم يتم العثور على جداول بيانات في ملف Word.")
            return
        self._import_records(records)

    def _import_records(self, records):
        label_to_key = {label: key for key, label, _, _ in self.db.field_list()}
        added = updated = skipped = 0

        for rec in records:
            data = {}
            for header, value in rec.items():
                if header not in label_to_key:
                    label_to_key[header] = self.db.ensure_custom_field(header)
                data[label_to_key[header]] = value

            matricule = data.get("matricule", "").strip()
            if not matricule or not data.get("full_name", "").strip():
                skipped += 1
                continue

            existing = self.db.find_by_matricule(matricule)
            if existing:
                merged = dict(existing)
                merged.update({k: v for k, v in data.items() if v})
                self.db.save_employee(merged, existing["id"])
                updated += 1
            else:
                self.db.save_employee(data)
                added += 1

        self.refresh()
        messagebox.showinfo(
            APP_TITLE,
            f"اكتمل الاستيراد:\n- موظفون جدد: {added}\n- موظفون محدَّثون: {updated}\n"
            f"- سجلات مرفوضة (رقم قيد أو اسم ناقص): {skipped}")

    # ---- التصدير والطباعة
    def export_excel(self):
        if openpyxl is None:
            return self._missing("openpyxl")
        path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                            filetypes=[("ملفات Excel", "*.xlsx")],
                                            initialfile="قائمة_الموظفين.xlsx")
        if not path:
            return
        fields = self.db.field_list()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "الموظفون"
        ws.sheet_view.rightToLeft = True
        ws.append([label for _, label, _, _ in fields])
        for cell in ws[1]:
            cell.font = Font(bold=True)
        for emp in self.db.search(""):
            ws.append([emp.get(key, "") for key, _, _, _ in fields])
        for col in ws.columns:
            width = max(len(str(c.value or "")) for c in col) + 2
            ws.column_dimensions[col[0].column_letter].width = min(max(width, 12), 40)
        wb.save(path)
        messagebox.showinfo(APP_TITLE, f"تم التصدير بنجاح:\n{path}")

    def export_card(self):
        emp_id = self.selected_id()
        if not emp_id:
            return
        if docx is None:
            return self._missing("python-docx")
        emp = self.db.get_employee(emp_id)
        path = filedialog.asksaveasfilename(defaultextension=".docx",
                                            filetypes=[("ملفات Word", "*.docx")],
                                            initialfile=f"بطاقة_{emp['matricule']}.docx")
        if not path:
            return
        self._save_card(emp, path)
        self._open_or_print(path, print_it=False)

    def _save_card(self, emp, path):
        doc = docx.Document()
        title = doc.add_heading("بطاقة موظف - الحماية المدنية الجزائرية", level=1)
        set_rtl(title)
        table = doc.add_table(rows=0, cols=2)
        table.style = "Table Grid"
        for key, label, _, _ in self.db.field_list():
            cells = table.add_row().cells
            cells[0].text = label
            cells[1].text = str(emp.get(key, "") or "")
            for c in cells:
                for p in c.paragraphs:
                    set_rtl(p)
        doc.save(path)

    def print_list(self):
        if docx is None:
            return self._missing("python-docx")
        rows = self.db.search(self.search_var.get())
        if not rows:
            messagebox.showinfo(APP_TITLE, "لا توجد بيانات للطباعة.")
            return
        path = os.path.join(tempfile.gettempdir(), "قائمة_الموظفين_للطباعة.docx")

        doc = docx.Document()
        title = doc.add_heading("قائمة موظفي الحماية المدنية الجزائرية", level=1)
        set_rtl(title)
        table = doc.add_table(rows=1, cols=len(LIST_COLUMNS))
        table.style = "Table Grid"
        for j, (_, label) in enumerate(LIST_COLUMNS):
            table.rows[0].cells[j].text = label
        for emp in rows:
            cells = table.add_row().cells
            for j, (key, _) in enumerate(LIST_COLUMNS):
                cells[j].text = str(emp.get(key, "") or "")
        for row in table.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    set_rtl(p)
        doc.save(path)
        self._open_or_print(path, print_it=True)

    def _open_or_print(self, path, print_it):
        try:
            if sys.platform.startswith("win"):
                os.startfile(path, "print" if print_it else "open")
            else:
                messagebox.showinfo(APP_TITLE, f"تم حفظ الملف:\n{path}")
        except OSError as e:
            messagebox.showerror(
                APP_TITLE,
                f"تعذر فتح الملف أو طباعته:\n{e}\n\nتأكد من تثبيت Microsoft Word، "
                f"أو افتح الملف من المسار:\n{path}")

    def _missing(self, package):
        messagebox.showerror(APP_TITLE,
                             f"المكتبة '{package}' غير مثبتة.\nثبّتها بالأمر:\npip install {package}")


# ---------------------------------------------------------------- التشغيل
if __name__ == "__main__":
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = App()
    if app.ok:
        app.mainloop()
