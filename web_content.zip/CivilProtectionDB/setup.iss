[Setup]
AppName=Civil Protection DB
AppVersion=1.0
AppPublisher=Protection Civile Algerienne
DefaultDirName={autopf}\CivilProtectionDB
DefaultGroupName=Civil Protection DB
OutputDir=installer
OutputBaseFilename=CivilProtectionDB_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: checkedonce

[Files]
Source: "dist\CivilProtectionDB.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Civil Protection DB"; Filename: "{app}\CivilProtectionDB.exe"
Name: "{autodesktop}\Civil Protection DB"; Filename: "{app}\CivilProtectionDB.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\CivilProtectionDB.exe"; Description: "Launch now"; Flags: nowait postinstall skipifsilent
