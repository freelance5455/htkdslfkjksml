package com.haddad.qenaunit;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_CONTACTS = 4101;
    private static final int REQ_CAMERA = 4102;
    private WebView web;
    private AndroidBridge bridge;
    private String pendingCamera = "back";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());

        bridge = new AndroidBridge(this);
        web.addJavascriptInterface(bridge, "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(String code) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    private String normalizeEgyptPhone(String raw) {
        if (raw == null) return "";
        String p = raw.trim().replaceAll("[^0-9+]", "");
        if (p.startsWith("00")) p = "+" + p.substring(2);
        if (p.startsWith("+20")) return "20" + p.substring(3);
        if (p.startsWith("20") && p.length() >= 12) return p;
        // Egyptian local mobile number: 010..., 011..., 012..., 015...
        if (p.startsWith("01") && p.length() == 11) return "20" + p.substring(1);
        return p.replace("+", "");
    }

    public class AndroidBridge {
        private final Context ctx;
        AndroidBridge(Context c) { ctx = c; }

        @JavascriptInterface
        public boolean isNativeAndroid() { return true; }

        @JavascriptInterface
        public String getVersion() { return "16.2"; }

        @JavascriptInterface
        public void syncContacts() {
            js("window.onContactsSyncStarted && window.onContactsSyncStarted()");
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
            } else {
                readContacts();
            }
        }

        private void readContacts() {
            try {
                android.database.Cursor cur = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    },
                    null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
                );

                JSONArray arr = new JSONArray();
                if (cur != null) {
                    int nameIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                    int phoneIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    while (cur.moveToNext()) {
                        String name = nameIndex >= 0 ? cur.getString(nameIndex) : "";
                        String phone = phoneIndex >= 0 ? cur.getString(phoneIndex) : "";
                        if (phone == null || phone.trim().isEmpty()) continue;
                        JSONObject o = new JSONObject();
                        o.put("name", name == null || name.trim().isEmpty() ? "بدون اسم" : name.trim());
                        o.put("phone", phone.trim());
                        o.put("whatsappPhone", normalizeEgyptPhone(phone));
                        arr.put(o);
                    }
                    cur.close();
                }

                final String json = arr.toString();
                js("window.onContactsSyncResult && window.onContactsSyncResult(" + JSONObject.quote(json) + ");"
                        + "window.onContactsSyncDone && window.onContactsSyncDone(" + arr.length() + ")");
            } catch (Exception e) {
                js("window.onContactsSyncError && window.onContactsSyncError(" +
                        JSONObject.quote("تعذر قراءة جهات الاتصال: " + (e.getMessage() == null ? "خطأ غير معروف" : e.getMessage())) + ")");
            }
        }

        @JavascriptInterface
        public void openWhatsApp(String phone, String message) {
            String normalized = normalizeEgyptPhone(phone);
            if (normalized.isEmpty()) {
                Toast.makeText(MainActivity.this, "رقم الهاتف غير صالح", Toast.LENGTH_SHORT).show();
                return;
            }
            String url = "https://wa.me/" + normalized + "?text=" + Uri.encode(message == null ? "" : message);
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.setPackage("com.whatsapp");
                startActivity(i);
            } catch (Exception e) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(i);
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "واتساب غير مثبت على الهاتف", Toast.LENGTH_SHORT).show();
                }
            }
        }

        @JavascriptInterface
        public void shareText(String text) {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(s, "مشاركة"));
        }

        @JavascriptInterface
        public void openCamera(String facing) {
            pendingCamera = facing == null ? "back" : facing;
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                return;
            }
            launchCamera();
        }

        private void launchCamera() {
            Intent i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            if ("front".equals(pendingCamera)) {
                i.putExtra("android.intent.extras.CAMERA_FACING", 1);
            } else {
                i.putExtra("android.intent.extras.CAMERA_FACING", 0);
            }
            try {
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "تعذر فتح الكاميرا", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_CONTACTS) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                bridge.readContacts();
            } else {
                js("window.onContactsSyncError && window.onContactsSyncError('تم رفض إذن جهات الاتصال. افتح إعدادات التطبيق > الأذونات > جهات الاتصال ثم فعّل الإذن.')");
            }
        } else if (requestCode == REQ_CAMERA) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                bridge.launchCamera();
            } else {
                js("window.onCameraPermissionDenied && window.onCameraPermissionDenied()");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
