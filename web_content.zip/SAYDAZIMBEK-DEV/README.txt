SAYDAZIMBEK.DEV — loyiha

NIMALAR BOR
- Moslashuvchan, zamonaviy chat dizayni
- API kalitisiz, brauzerda ishlaydigan WebLLM modeli
- Ovoz orqali savol kiritish (brauzer qo‘llasa)
- Javobni qo‘lda yoki avtomatik ovoz chiqarib o‘qish (brauzer qo‘llasa)
- Javobni tokenma-token chiqarish: javob to‘liq tugashini kutmay ko‘rina boshlaydi
- Takroriy savol yuborilishidagi xato tuzatildi
- Tezkor mavzular, yangi suhbat, model tanlash
- PWA manifest va oddiy service worker

MUHIM CHEKLOVLAR
- AI 100% xatosiz emas va 200 000 savolga javob berishni kafolatlamaydi.
- Birinchi model yuklanishida internet kerak; model bir necha yuz MB yoki undan ko‘p bo‘lishi mumkin.
- WebGPU, RAM va telefonning quvvati ishlash tezligiga ta’sir qiladi.
- Ovoz funksiyalari brauzer/til qo‘llab-quvvatlashiga bog‘liq.
- Service worker HTTPS yoki localhost’da ishlaydi.

ISHGA TUSHIRISH
1. ZIP faylni oching.
2. Fayllarni HTTPS statik hostingga joylang (masalan, GitHub Pages yoki Netlify).
3. index.html ni oddiy file:// orqali ochish o‘rniga hosting orqali oching.
4. Yangilangan Chrome’da ochib, ⚙ Sozlamalar -> Modelni yuklash ni bosing.
5. Model birinchi marta internet orqali yuklanadi.

O‘Z DOMENINGIZGA JOYLASH
SAYDAZIMBEK.DEV domeni alohida ro‘yxatdan o‘tkazilishi va hostingga ulanilishi kerak.
Bu ZIP domenni avtomatik sotib olmaydi yoki internetga joylamaydi.

APK
Bu loyiha hozircha PWA/statik sayt. Android APK qilish uchun Capacitor kabi vosita bilan alohida Android build va test kerak. AI modeli katta bo‘lgani sabab APK ichiga modelni qo‘shishdan ko‘ra modelni qurilmada yuklash amaliyroq.

Texnologiyalar: HTML, CSS, JavaScript, WebLLM (MLC AI).

TEZLIK
- Tezkor rejim uchun Sozlamalarda Qwen 0.5B modelini tanlang.
- Birinchi yuklanish baribir vaqt oladi; model yuklangach keyingi javoblar tezroq chiqadi.
- Kattaroq model ko‘proq imkoniyat berishi mumkin, ammo telefonda sekinroq ishlaydi.
- Bu mahalliy kichik model bo‘lgani uchun internetdagi barcha yangi ma’lumotlarni bilmaydi va har doim to‘g‘ri javob berishi kafolatlanmaydi.


TEZLIK VA MODEL TANLASH
- Salomlashish va ayrim umumiy savollar hamda oddiy arifmetika darhol javoblanadi, model yuklash shart emas.
- Boshqa ochiq savollar uchun mahalliy AI modeli yuklanadi. Birinchi marta yuklash  internet tezligi va qurilmaga qarab ancha vaqt olishi mumkin.
- Qwen 0.5B — yengilroq va tezroq; Qwen 1.5B — ayrim vazifalarda kuchliroq, ammo ko‘proq xotira va yuklash vaqtini talab qiladi.
- Modelni birinchi marta yuklagandan keyin brauzer keshida qolishi mumkin. Sayt ma’lumotlarini tozalash yoki boshqa brauzer ishlatish qayta yuklashga olib kelishi mumkin.
- Tezkor tayyor javoblar kichik ichki bilimlar to‘plami; ular 200 000 savolni qamrab olmaydi. Umumiy savollarda AI modeli kerak bo‘ladi.
