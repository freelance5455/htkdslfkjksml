import { CreateMLCEngine } from "https://esm.run/@mlc-ai/web-llm";

const $ = (id) => document.getElementById(id);
const chatForm = $("chatForm"), promptBox = $("prompt"), messages = $("messages");
const welcome = $("welcome"), loadingBanner = $("loadingBanner");
let engine = null, busy = false, lastAnswer = "", recognition = null, autoRead = false;

const systemPrompt = `Sen SAYDAZIMBEK.DEV nomli o'zbek tilidagi aqlli yordamchisan. Foydalanuvchiga o'zbek tilida sodda, foydali va aniq javob ber. Savol oddiy bo'lsa qisqa va tez javob ber; maktab yoki murakkab savol bo'lsa tushuntirib, kerakli qadamlarni ko'rsat. Javobni keraksiz kirish so'zlari bilan cho'zma. Bilmagan faktni to'qib chiqarmagin va ishonchsiz bo'lsang buni ayt. Matematikada hisobni tekshir. Kod so'ralsa ishga tushirish bo'yicha qisqa izoh ber.`;

function setLoading(on, text="AI modeli tayyorlanmoqda…") {
  loadingBanner.hidden = !on; $("loadingText").textContent = text;
  $("sendBtn").disabled = on; $("modelStatus").textContent = on ? "Ishlayapti…" : (engine ? "AI tayyor" : "Model hali yuklanmagan");
}
function addMessage(role, text) {
  welcome.hidden = true;
  const row = document.createElement("div"); row.className = `message ${role}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "user" ? "S" : "AI";
  const content = document.createElement("div"); content.className = "bubble";
  const who = document.createElement("div"); who.className = "who"; who.textContent = role === "user" ? "Siz" : "SAYDAZIMBEK AI";
  const body = document.createElement("div"); body.textContent = text;
  content.append(who, body); row.append(avatar, content); messages.append(row);
  $("chatArea").scrollTop = $("chatArea").scrollHeight;
  return body;
}
async function loadModel() {
  if (engine) return true;
  if (!("gpu" in navigator)) {
    addMessage("assistant", "Bu brauzer WebGPU-ni qo‘llamasligi mumkin. Yangilangan Chrome’da ochib ko‘ring. AI modelini birinchi marta yuklash uchun internet va bo‘sh xotira kerak.");
    return false;
  }
  setLoading(true, "AI modelini birinchi marta yuklayapman… Keyingi savollar tezroq bo‘ladi.");
  try {
    engine = await CreateMLCEngine($("modelSelect").value, { initProgressCallback: (p) => {
      const pct = Math.round((p.progress || 0) * 100);
      setLoading(true, p.text ? `${p.text} ${pct}%` : `Model yuklanmoqda… ${pct}%`);
    }});
    $("modelStatus").textContent = "AI tayyor";
    return true;
  } catch (e) {
    console.error(e);
    addMessage("assistant", "Modelni yuklab bo‘lmadi. Internetni tekshiring, Chrome’ni yangilang yoki yengilroq modelni tanlang.");
    return false;
  } finally { setLoading(false); }
}
function speak(text) {
  if (!("speechSynthesis" in window) || !text) return;
  speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = "uz-UZ"; utter.rate = 1.02;
  speechSynthesis.speak(utter);
}
function instantAnswer(text) {
  const q = text.toLowerCase().trim().replace(/[!?.,]/g, "");
  const exact = {
    "salom": "Salom! 👋 Men SAYDAZIMBEK AI man. Maktab, matematika, til o‘rganish, dasturlash yoki kundalik savollaringga yordam beraman. Savolingni yozaver!",
    "assalomu alaykum": "Va alaykum assalom! 😊 Qanday yordam beray? Savolingni yoz, birga ko‘rib chiqamiz.",
    "qalaysan": "Rahmat, yaxshiman! 😊 Sen-chi? Qanday savoling bor?",
    "sen kimsan": "Men SAYDAZIMBEK AI — o‘zbek tilida yordam berishga mo‘ljallangan AI yordamchiman. Maktab fanlari, yozish, tarjima va dasturlashda yordam bera olaman.",
    "nima qila olasan": "Men matematika masalalarini tushuntirish, maktab mavzularini izohlash, matn yozish, tarjima, reja tuzish va kod yozishda yordam bera olaman. Murakkab javoblarda xato bo‘lishi mumkin, shuning uchun muhim faktlarni tekshir.",
    "rahmat": "Arzimaydi! 😊 Yana savoling bo‘lsa, bemalol yoz."
  };
  if (exact[q]) return exact[q];
  if (/^(\d+)\s*\+\s*(\d+)$/.test(q)) { const m=q.match(/^(\d+)\s*\+\s*(\d+)$/); return `${m[1]} + ${m[2]} = ${Number(m[1])+Number(m[2])}`; }
  if (/^(\d+)\s*[-−]\s*(\d+)$/.test(q)) { const m=q.match(/^(\d+)\s*[-−]\s*(\d+)$/); return `${m[1]} − ${m[2]} = ${Number(m[1])-Number(m[2])}`; }
  if (/^(\d+)\s*[x*×]\s*(\d+)$/.test(q)) { const m=q.match(/^(\d+)\s*[x*×]\s*(\d+)$/); return `${m[1]} × ${m[2]} = ${Number(m[1])*Number(m[2])}`; }
  if (/^(\d+)\s*[:/]\s*(\d+)$/.test(q)) { const m=q.match(/^(\d+)\s*[:/]\s*(\d+)$/); return Number(m[2]) ? `${m[1]} ÷ ${m[2]} = ${Number(m[1])/Number(m[2])}` : "Nolga bo‘lish mumkin emas."; }
  if (q.includes("pifagor")) return "Pifagor teoremasi: to‘g‘ri burchakli uchburchakda gipotenuza kvadrati katetlar kvadratlari yig‘indisiga teng: a² + b² = c². Masalan, katetlar 3 va 4 bo‘lsa, c² = 9 + 16 = 25, demak c = 5.";
  if (q.includes("quyosh tizimi")) return "Quyosh tizimida 8 ta sayyora bor: Merkuriy, Venera, Yer, Mars, Yupiter, Saturn, Uran va Neptun. Quyosh tizimining markazida Quyosh joylashgan.";
  if (q.includes("html nima")) return "HTML — veb-sahifaning tuzilishini belgilaydigan belgilash tili. CSS sahifani bezaydi, JavaScript esa unga interaktivlik qo‘shadi.";
  if (q.includes("inglizcha salom")) return "Ingliz tilida ‘Salom’ — ‘Hello’. Norasmiy holatda ‘Hi’ ham ishlatiladi.";
  return null;
}

async function sendMessage(text) {
  text = text.trim(); if (!text || busy) return;
  busy = true;
  // Capture old conversation BEFORE adding the current user message to avoid duplicate prompts.
  const history = [...messages.querySelectorAll(".message")].slice(-10).map((el) => ({
    role: el.classList.contains("user") ? "user" : "assistant",
    content: el.querySelector(".bubble div:last-child")?.textContent || ""
  })).filter(m => m.content).slice(-8);
  promptBox.value = ""; promptBox.style.height = "auto";
  addMessage("user", text);
  const answerEl = addMessage("assistant", "");
  const quick = instantAnswer(text);
  if (quick) {
    answerEl.textContent = quick; lastAnswer = quick; busy = false;
    if (autoRead) speak(lastAnswer);
    return;
  }
  setLoading(true, engine ? "Javobni tayyorlayapman…" : "AI modeli birinchi marta yuklanmoqda…");
  try {
    const ok = await loadModel();
    if (!ok) { answerEl.textContent = "AI ishga tushmadi. Yuqoridagi tavsiyalarni tekshirib qayta urinib ko‘ring."; return; }
    // Stream tokens as they arrive so the answer appears immediately rather than waiting for the whole reply.
    const stream = await engine.chat.completions.create({
      messages: [{role:"system", content:systemPrompt}, ...history, {role:"user", content:text}],
      temperature: 0.45, max_tokens: 520, stream: true
    });
    let result = "";
    for await (const chunk of stream) {
      result += chunk.choices?.[0]?.delta?.content || "";
      answerEl.textContent = result;
      $("chatArea").scrollTop = $("chatArea").scrollHeight;
    }
    lastAnswer = result.trim() || "Kechirasiz, javob tayyor bo‘lmadi. Yana urinib ko‘ring.";
    answerEl.textContent = lastAnswer;
    if (autoRead) speak(lastAnswer);
  } catch (e) {
    console.error(e);
    answerEl.textContent = "Xatolik yuz berdi. Telefon xotirasi yetmayotgan bo‘lishi mumkin. Sahifani yangilang yoki Sozlamalardan yengilroq modelni tanlang.";
  } finally { busy = false; setLoading(false); $("chatArea").scrollTop = $("chatArea").scrollHeight; }
}
chatForm.addEventListener("submit", e => { e.preventDefault(); sendMessage(promptBox.value); });
promptBox.addEventListener("input", () => { promptBox.style.height="auto"; promptBox.style.height=Math.min(promptBox.scrollHeight,160)+"px"; });
promptBox.addEventListener("keydown", e => { if(e.key === "Enter" && !e.shiftKey){e.preventDefault(); chatForm.requestSubmit();} });
document.querySelectorAll("[data-prompt]").forEach(btn => btn.addEventListener("click", () => { promptBox.value = btn.dataset.prompt; promptBox.focus(); }));
$("newChat").addEventListener("click", () => { messages.replaceChildren(); welcome.hidden=false; lastAnswer=""; if("speechSynthesis" in window) speechSynthesis.cancel(); $("sidebar").classList.remove("open"); });
$("menuBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
$("settingsBtn").addEventListener("click", () => $("settingsDialog").showModal());
$("closeSettings").addEventListener("click", () => $("settingsDialog").close());
$("loadModelBtn").addEventListener("click", async () => { $("settingsDialog").close(); await loadModel(); });
$("readBtn").addEventListener("click", () => {
  if (!lastAnswer) { addMessage("assistant", "Avval savol yuboring, keyin javobni ovoz chiqarib o‘qitishingiz mumkin."); return; }
  if (!("speechSynthesis" in window)) { addMessage("assistant", "Bu brauzer ovoz chiqarib o‘qishni qo‘llamaydi."); return; }
  speak(lastAnswer);
});
const autoBtn = $("autoReadBtn");
autoBtn.addEventListener("click", () => {
  autoRead = !autoRead;
  autoBtn.classList.toggle("active-tool", autoRead);
  autoBtn.innerHTML = autoRead ? "🔊 <span>Avto ovoz: ON</span>" : "🔈 <span>Avto ovoz</span>";
  if (autoRead && lastAnswer) speak(lastAnswer);
});
$("voiceBtn").addEventListener("click", () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { addMessage("assistant", "Ovoz orqali yozish bu brauzerda mavjud emas. Android Chrome’da mikrofon ruxsatini tekshiring yoki savolni yozing."); return; }
  if (recognition) { recognition.stop(); recognition=null; return; }
  recognition = new SR(); recognition.lang="uz-UZ"; recognition.interimResults=false;
  $("voiceBtn").innerHTML="🎙 <span>Tinglayapman…</span>";
  recognition.onresult = e => { promptBox.value=e.results[0][0].transcript; promptBox.dispatchEvent(new Event("input")); };
  recognition.onerror = () => {};
  recognition.onend = () => { recognition=null; $("voiceBtn").innerHTML="🎙 <span>Ovoz</span>"; };
  recognition.start();
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(()=>{}));
