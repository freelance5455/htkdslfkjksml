const $=s=>document.querySelector(s);
const video=$('#preview'),canvas=$('#renderCanvas'),ctx=canvas.getContext('2d',{alpha:false});
let stream=null,recStream=null,recorder=null,chunks=[],mode='photo',facing='environment',filter='natural',mirror=false,grid=false,quality=0,recordStart=0,timer=null;
const names={natural:'طبيعي',iphone:'آيفون',cinema:'سينمائي',warm:'دافئ',vivid:'حيوي',cool:'بارد',mono:'أبيض وأسود',retro:'فيلم قديم',dream:'ناعم'};
const looks={
 natural:{sat:1.02,con:1.02,sep:0,hue:0,bright:1,gray:0},
 iphone:{sat:1.08,con:1.04,sep:.04,hue:-2,bright:1.02,gray:0},
 cinema:{sat:1.22,con:1.13,sep:.14,hue:-7,bright:.98,gray:0},
 warm:{sat:1.18,con:1.04,sep:.23,hue:-8,bright:1.04,gray:0},
 vivid:{sat:1.62,con:1.12,sep:0,hue:0,bright:1.02,gray:0},
 cool:{sat:1.12,con:1.08,sep:0,hue:12,bright:1.02,gray:0},
 mono:{sat:0,con:1.15,sep:0,hue:0,bright:1,gray:1},
 retro:{sat:.78,con:.92,sep:.3,hue:-12,bright:1.05,gray:0},
 dream:{sat:.9,con:.91,sep:.1,hue:4,bright:1.08,gray:0}
};
function say(t){const el=$('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600)}
function cssFilter(){const a=looks[filter],k=Number($('#strength').value)/100,blend=(v,base)=>base+(v-base)*k;return `saturate(${blend(a.sat,1)}) contrast(${blend(a.con,1)*Number($('#exposure').value)/100}) sepia(${a.sep*k}) hue-rotate(${a.hue*k}deg) brightness(${blend(a.bright,1)}) grayscale(${a.gray*k})`;}
function refreshLook(){const f=cssFilter();video.style.filter=f;$('#filterName').textContent=names[filter];$('#strengthValue').textContent=$('#strength').value+'%';$('#exposureValue').textContent=$('#exposure').value+'%';}
async function startCamera(){if(!navigator.mediaDevices?.getUserMedia){say('الكاميرا تحتاج HTTPS أو localhost، ولا تعمل من file://');return}
try{if(stream)stream.getTracks().forEach(t=>t.stop());stream=await navigator.mediaDevices.getUserMedia({audio:mode==='video'?{echoCancellation:true}:false,video:{facingMode:{ideal:facing},width:{ideal:quality===1?3840:1920},height:{ideal:quality===1?2160:1080},frameRate:{ideal:30,max:60}}});video.srcObject=stream;await video.play();$('#startPanel').style.display='none';const tr=stream.getVideoTracks()[0],s=tr.getSettings();$('#resTag').textContent=(s.width||video.videoWidth)+'×'+(s.height||video.videoHeight);$('#status').textContent='الكاميرا تعمل';say('اشتغلت الكاميرا');}catch(e){$('#startPanel').style.display='flex';say(e.name==='NotAllowedError'?'ارفض النظام الإذن أو لم يمنحه. فعّل إذن الكاميرا من إعدادات التطبيق.':'تعذر تشغيل الكاميرا. تأكد من إذن التطبيق وطريقة الاستضافة.');}}
$('#start').onclick=startCamera;
$('#switchCam').onclick=()=>{facing=facing==='environment'?'user':'environment';if(stream)startCamera();};
document.querySelectorAll('.mode').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;document.querySelectorAll('.mode').forEach(x=>x.classList.toggle('active',x===b));$('#modeTag').textContent=mode.toUpperCase();if(stream&&!recorder)startCamera();});
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));refreshLook();});
$('#strength').oninput=refreshLook;$('#exposure').oninput=refreshLook;
$('#quality').onclick=()=>{quality=quality===0?1:0;$('#quality').textContent=quality?'الجودة: 4K إن دعمها الجهاز':'الجودة: تلقائي';if(stream&&!recorder)startCamera();};
$('#gridToggle').onclick=()=>{grid=!grid;document.body.classList.toggle('grid',grid);$('#gridToggle').textContent='شبكة: '+(grid?'تشغيل':'إيقاف');};
$('#mirror').onclick=()=>{mirror=!mirror;video.style.transform=mirror?'scaleX(-1)':'none';$('#mirror').textContent='مرآة: '+(mirror?'تشغيل':'إيقاف');};
$('#flash').onclick=()=>{document.body.classList.toggle('screenflash');say(document.body.classList.contains('screenflash')?'إضاءة الشاشة مفعّلة (ليست فلاش الكاميرا)':'إضاءة الشاشة متوقفة');};
function drawFiltered(){if(!video.videoWidth)return false;const w=video.videoWidth,h=video.videoHeight;if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h}ctx.save();ctx.filter=cssFilter();if(mirror||facing==='user'){ctx.translate(w,0);ctx.scale(-1,1)}ctx.drawImage(video,0,0,w,h);ctx.restore();ctx.filter='none';return true;}
function saveBlob(blob,name){if(!blob){say('تعذر تجهيز الملف');return}const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);say('بدأ تنزيل الملف إلى التنزيلات');}
const stamp=()=>new Date().toISOString().replace(/[:.]/g,'-');
$('#shutter').onclick=async()=>{if(!stream){say('شغّل الكاميرا أولاً');return}if(mode==='photo'){if(!drawFiltered()){say('انتظر تجهيز الصورة');return}canvas.toBlob(b=>saveBlob(b,'YounesTasweer-'+stamp()+'.jpg'),'image/jpeg',.96);return}
if(recorder){recorder.stop();return}
try{drawFiltered();recStream=canvas.captureStream(30);const audio=stream.getAudioTracks();audio.forEach(t=>recStream.addTrack(t));const type=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t));if(!type)throw Error('no recorder');recorder=new MediaRecorder(recStream,{mimeType:type,videoBitsPerSecond:8000000});chunks=[];recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=()=>{saveBlob(new Blob(chunks,{type}),`YounesTasweer-${stamp()}.webm`);recStream.getTracks().forEach(t=>t.stop());recorder=null;$('#shutter').classList.remove('recording');$('#status').textContent='انتهى التسجيل';clearInterval(timer);$('#clock').textContent='00:00'};recorder.start(250);recordStart=Date.now();$('#shutter').classList.add('recording');$('#status').textContent='تسجيل الفيديو';timer=setInterval(()=>{let n=Math.floor((Date.now()-recordStart)/1000);$('#clock').textContent=String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0')},500);say('بدأ تسجيل الفيديو مع الفلتر');}catch(e){say('تسجيل الفيديو غير مدعوم في بيئة التحويل الحالية');}}
$('#gallery').onclick=()=>say('الملفات التي تحفظها تجدها في مجلد التنزيلات');
refreshLook();
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
