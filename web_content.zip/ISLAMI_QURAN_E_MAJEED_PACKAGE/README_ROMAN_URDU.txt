ISLAMI QURAN E MAJEED — APP PACKAGE
===================================

FILES
-----
index.html
  Main app. HTML-to-APK converter mein isi file ko select/open karein.

android-tts-bridge/
  Optional Android native Text-to-Speech integration example. Ye files tabhi
  kaam aayengi jab aapka HTML-to-APK builder custom Android Java/Kotlin code
  ya JavaScript interface add karne deta ho. Sirf HTML upload karne se native
  bridge khud-ba-khud install nahi hota.

HTML-TO-APK SETUP
-----------------
1. ZIP extract karein.
2. HTML to APK app mein index.html select karein.
3. JavaScript enable karein.
4. Internet access/network permission enable karein.
5. DOM Storage/local storage enable karein.
6. Geolocation/location permission allow karein.
7. External audio playback allow karein.
8. Agar option ho to WebView ko latest Android System WebView/Chrome engine
   par chalayein.
9. APK build karke pehle test install karein.

READ ALOUD — IMPORTANT
---------------------
Screenshot ka error batata hai ke WebView mein window.speechSynthesis ya
SpeechSynthesisUtterance exposed nahi hain. Is surat mein sirf HTML/JavaScript
badalne se Android ka native Text-to-Speech available nahi hota.

android-tts-bridge/ mein sample Android bridge diya hai. Builder agar custom
native Java code / JavaScriptInterface support karta hai to usay integrate
karwana hoga. Agar builder custom native code support nahi karta, to Quran,
Duas aur Asma-ul-Husna ke liye prerecorded audio files/online audio player
sabse practical raasta hai.

QURAN RECITATION
----------------
Quran Arabic text aur Urdu translation internet APIs se load hote hain.
Recitation catalogue bhi internet se load hota hai. Yasir Al-Dosari ki awaaz
sirf tab select honi chahiye jab catalogue mein unki asli authorized recording
available ho. TTS synthetic voice ko unki awaaz na samjhein.

QIBLA & PRAYER TIMES
--------------------
Location permission aur supported compass sensor zaroori hain. Kuch WebView
builders mein geolocation HTTPS/secure context mein hi kaam karti hai. Compass
sensor na ho to live left/right turn guidance available nahi hogi.

AI ASSISTANT
------------
Chat UI included hai, lekin live AI responses ke liye secure HTTPS backend
endpoint configure karna hoga. API secret/key ko HTML file mein kabhi embed
na karein.

TEST CHECKLIST
--------------
[ ] Quran 114 Surah list load hoti hai
[ ] Arabic ayat aur Urdu translation load hota hai
[ ] Recitation audio play hota hai
[ ] Read Aloud supported voice ke saath test hota hai
[ ] Duas aur 99 Names render hote hain
[ ] Location permission aur Qibla bearing test hoti hai
[ ] Compass sensor se live heading test hoti hai
[ ] Prayer timings load hoti hain
[ ] AI backend se test reply aata hai

NOTE
----
Ye ZIP app ka source bundle aur integration guide hai, signed/installable APK
nahi. Har feature ko target Android phone aur converter mein test karna hoga.
