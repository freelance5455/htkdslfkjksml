package com.example.islamicquran;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import java.util.Locale;

/** Optional bridge. Integrate only in a trusted WebView app you control. */
public final class AndroidTtsBridge {
    private final TextToSpeech tts;
    private volatile boolean ready = false;

    public AndroidTtsBridge(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            ready = (status == TextToSpeech.SUCCESS);
        });
    }

    @JavascriptInterface
    public void speak(String text, String language) {
        if (!ready || text == null || text.trim().isEmpty()) return;
        Locale locale;
        String lang = language == null ? "ar" : language.toLowerCase();
        if (lang.startsWith("ur")) locale = new Locale("ur", "PK");
        else if (lang.startsWith("en")) locale = Locale.US;
        else locale = new Locale("ar");
        int result = tts.setLanguage(locale);
        if (result == TextToSpeech.LANG_MISSING_DATA ||
            result == TextToSpeech.LANG_NOT_SUPPORTED) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "islamic-quran-tts");
    }

    @JavascriptInterface
    public void stop() {
        if (ready) tts.stop();
    }

    public void shutdown() {
        if (tts != null) tts.shutdown();
    }
}
