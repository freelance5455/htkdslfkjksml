/* Optional JS helper for pages that integrate the AndroidTTS Java bridge. */
window.appSpeak = function (text, lang) {
  text = String(text || '').trim();
  if (!text) return false;
  if (window.AndroidTTS && typeof window.AndroidTTS.speak === 'function') {
    window.AndroidTTS.speak(text, lang || 'ar');
    return true;
  }
  if ('speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined') {
    window.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'ur' ? 'ur-PK' : (lang === 'en' ? 'en-US' : 'ar-SA');
    window.speechSynthesis.speak(utterance);
    return true;
  }
  return false;
};
window.appStopSpeaking = function () {
  if (window.AndroidTTS && typeof window.AndroidTTS.stop === 'function') {
    window.AndroidTTS.stop();
  }
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
};
