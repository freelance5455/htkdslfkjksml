OPTIONAL ANDROID TEXT-TO-SPEECH BRIDGE

Use only if your HTML-to-APK builder supports custom Android Java code and
exposing a JavaScriptInterface to the WebView. A generic HTML-only converter
may not support this.

1. Add AndroidTtsBridge.java to the Android app project.
2. In the WebView setup, call:
      webView.getSettings().setJavaScriptEnabled(true);
      webView.addJavascriptInterface(new AndroidTtsBridge(context), "AndroidTTS");
3. Add INTERNET permission for online Quran/audio APIs, and request runtime
   location permission separately for Qibla/prayer location.
4. Call AndroidTTS.speak(text, language) from JavaScript.

Security: expose only this narrow method. Do not expose arbitrary Java objects,
filesystem access, or privileged methods to untrusted web content.
