# Relatório de testes — Gato Noturno v6

## Verificações automatizadas/estáticas
- `node --check game.js`: aprovado.
- `testes/validar_projeto.py`: aprovado após atualizar as verificações para a arquitetura cumulativa.
- IDs HTML duplicados: nenhum.
- Referências de IDs usados em JavaScript: verificadas.
- Referências de CSS e JS no HTML: verificadas.
- Contagem de funções/métodos: acima de 30 funções úteis, incluindo navegação, estado, áudio, fases, renderização, colisões e controles.
- ZIP: integridade verificada após empacotamento.

## Não testado nesta sessão
- Execução real no Android físico.
- Compatibilidade de reprodução e persistência de cada formato de áudio.
- Todas as combinações possíveis de colisão durante uma partida longa.
- Teste de teclado em todos os navegadores.

Os testes estáticos não substituem a execução real. Não declarar a versão como perfeita antes desses testes.
