# Gato Noturno — versão 6 cumulativa

Projeto 2D de corrida noturna em HTML/CSS/JavaScript. Esta versão continua a partir dos arquivos da versão 5; não foi iniciada de um projeto vazio. Mantém canvas, personagem horizontal, fragmentos, pássaros, colisões, recorde, som, pausa, retorno de percurso, música local e configurações.

## Novidades da versão 6
- Lobby inicial: o jogo não começa a correr automaticamente; o jogador escolhe quando jogar.
- Seletor de fase no lobby e nas configurações, com cinco ambientes e paletas de cores distintas.
- Configurações com botão claro de retorno ao lobby, restauração de padrões, painel rolável e volume da música.
- Suporte de teclado: setas ou A/D para mover, Espaço/W/↑ para pular, S/↓ para abaixar, P para pausar, Esc para voltar e Enter para iniciar no lobby.
- Obstáculos adicionais: monólito alto, barreira dupla e caixa, além de espinhos, blocos, torres, obstáculos baixos e pássaros já existentes.
- Preferência de fase salva no armazenamento local quando disponível.
- Cinco paletas de cenário; metas e progressão de dificuldade mantidas.
- Funções auxiliares para navegação, validação de estado, configurações, fase atual, áudio e diagnóstico.

## Executar
Extraia o ZIP e mantenha `index.html`, `styles.css` e `game.js` na mesma pasta. Abra `index.html` em um navegador moderno. Não requer biblioteca externa nem internet para jogar.

## Controles
- Celular: botões na tela; toque no lado direito do canvas também pula.
- Teclado: ←/→ ou A/D move; Espaço/↑/W pula; ↓/S abaixa; P pausa; Esc volta ao lobby; Enter inicia.
- O botão de retorno alterna o sentido do percurso, não rebobina o estado anterior.

## Música personalizada
Em Configurações, selecione um arquivo de áudio. O jogo tenta armazená-lo no IndexedDB; a persistência depende do navegador, permissões e espaço disponível. A reprodução pode precisar de um toque para cumprir as regras de autoplay. O volume é ajustável na mesma tela.

## Transparência de testes
Sintaxe JavaScript e referências HTML/CSS/JS são verificadas localmente. Isso não comprova execução física no Android; ainda é necessário testar navegação, teclado, colisões e áudio no navegador usado pelo jogador.
