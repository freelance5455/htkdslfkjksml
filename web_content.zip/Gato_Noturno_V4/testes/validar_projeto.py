from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
js = (ROOT / 'game.js').read_text(encoding='utf-8')
css = (ROOT / 'styles.css').read_text(encoding='utf-8')
errors = []

if 'href="styles.css"' not in html:
    errors.append('index.html não referencia styles.css')
if 'src="game.js"' not in html:
    errors.append('index.html não referencia game.js')
for filename in ('styles.css', 'game.js'):
    if not (ROOT / filename).is_file():
        errors.append(f'arquivo ausente: {filename}')
ids = set(re.findall(r'\bid="([^"]+)"', html))
refs = set(re.findall(r"\$\('([^']+)'\)", js)) | set(re.findall(r'\$\("([^\"]+)"\)', js))
for missing in sorted(refs - ids):
    if missing == 'levelToast':  # criado dinamicamente pela função showToast()
        continue
    errors.append(f'ID usado no JS mas ausente no HTML: {missing}')
for expected, description in [
    ('function initializeGame()', 'inicialização automática'),
    ('initializeGame();', 'chamada da inicialização'),
    ('safeReadSettings()', 'leitura segura das preferências'),
    ('safeSaveSettings()', 'persistência das preferências'),
    ('function releaseAllControls()', 'liberação dos controles'),
    ("const playing=state==='playing'", 'visibilidade contextual dos controles'),
    ("y:gy-43,w:54,h:13,type:'low'", 'obstáculo baixo atualizado'),
    ('window.GatoNoturnoDiagnostics', 'diagnóstico no console'),
]:
    if expected not in js:
        errors.append(f'recurso ausente: {description}')
if 'fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h),c)' in js:
    errors.append('rect() ainda passa argumento extra para fillRect')
if errors:
    print('FALHOU')
    print('\n'.join('- ' + item for item in errors))
    sys.exit(1)
print('OK: referências HTML/CSS/JS, IDs, inicialização, preferências, controles, obstáculos e diagnóstico verificados.')
print(f'IDs HTML: {len(ids)} | referências JS verificadas: {len(refs)}')
print('Observação: validação estática; não substitui teste real no navegador/celular.')
