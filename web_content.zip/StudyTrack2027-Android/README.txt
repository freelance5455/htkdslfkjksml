STUDYTRACK 2027 — ANDROID STUDIO PROJECT

This is the Android project source for the StudyTrack 2027 study manager.
It loads the included app/src/main/assets/index.html inside an Android WebView.
The WebView enables JavaScript and DOM storage so the app's local progress can
persist on this device.

HOW TO BUILD AN APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the extracted
   StudyTrack2027 folder (the one containing settings.gradle.kts).
4. Allow Gradle sync and install the Android SDK components it requests.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, choose Locate. The debug APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. Android may ask
   you to allow installation from that file manager/browser.

NOTES
- This ZIP is project source, NOT a ready-to-install APK.
- A real APK must be compiled by Android Studio/Gradle.
- Study data is stored locally in the app's WebView browser storage.
- Export a backup from the app before uninstalling or clearing app data.
- The in-app browser does not provide dependable scheduled notifications
  while the app is closed. The reminder setting may be limited in this build.
- The chapter checklist is a planning aid. Verify the final chapter list
  against the official BSEB 2026–27 syllabus.
