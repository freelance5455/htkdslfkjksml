import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/db";
import { collections } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { ProductForm } from "@/components/admin/ProductForm";
import { ensureSeeded } from "@/lib/catalog";
import { ChevronLeft } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "New product" };

export default async function NewProductPage() {
  await ensureSeeded();
  const allCollections = await db.select().from(collections);

  return (
    <AdminGate>
      <header>
        <Link href="/admin/products" className="flex items-center gap-1.5 text-[13px] font-bold text-muted hover:text-clay">
          <ChevronLeft className="h-4 w-4" /> Products
        </Link>
        <h1 className="font-display mt-2 text-[clamp(1.9rem,4vw,2.6rem)] leading-none">Add product</h1>
        <p className="mt-2 text-[14px] text-ink-2">
          Create the listing, then generate variants from your options. Everything publishes the moment you save.
        </p>
      </header>

      <ProductForm collections={allCollections} />
    </AdminGate>
  );
}
