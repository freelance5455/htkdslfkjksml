import type { Metadata } from "next";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { collections, orderItems, products, variants } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { ProductsTable, type AdminProductRow } from "@/components/admin/ProductsTable";
import { ensureSeeded } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Products" };

export default async function AdminProductsPage() {
  await ensureSeeded();

  const rows = await db
    .select({
      product: products,
      collection: collections,
      variantCount: sql<number>`(select count(*)::int from ${variants} where ${variants.productId} = ${products.id})`,
      soldUnits: sql<number>`(select coalesce(sum(${orderItems.quantity}),0)::int from ${orderItems} where ${orderItems.productId} = ${products.id})`,
    })
    .from(products)
    .leftJoin(collections, eq(collections.id, products.collectionId))
    .orderBy(sql`${products.featured} desc`, products.title);

  const adminRows: AdminProductRow[] = rows.map((row) => ({
    ...row.product,
    collection: row.collection ?? null,
    variantCount: Number(row.variantCount),
    soldUnits: Number(row.soldUnits),
  }));

  const activeCount = adminRows.filter((row) => row.status === "active").length;
  const outOfStock = adminRows.filter((row) => row.inventoryQty <= 0).length;

  return (
    <AdminGate>
      <header>
        <p className="eyebrow text-clay">Catalogue</p>
        <h1 className="font-display mt-1.5 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Products</h1>
        <p className="mt-2 text-[14px] text-ink-2">
          {adminRows.length} total · {activeCount} published · {outOfStock} out of stock
        </p>
      </header>

      <ProductsTable products={adminRows} />
    </AdminGate>
  );
}
