import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { collections, orderItems, products, variants } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { ProductForm } from "@/components/admin/ProductForm";
import { Badge } from "@/components/ui";
import { ChevronLeft } from "@/components/icons";
import { formatDate, money } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Edit product" };

type Params = Promise<{ id: string }>;

export default async function EditProductPage({ params }: { params: Params }) {
  const { id } = await params;
  const productId = Number(id);

  const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!product) notFound();

  const [productVariants, allCollections, soldRows] = await Promise.all([
    db.select().from(variants).where(eq(variants.productId, productId)),
    db.select().from(collections),
    db.select({ units: orderItems.quantity, total: orderItems.totalCents }).from(orderItems).where(eq(orderItems.productId, productId)),
  ]);

  const unitsSold = soldRows.reduce((sum, row) => sum + row.units, 0);
  const revenue = soldRows.reduce((sum, row) => sum + row.total, 0);

  return (
    <AdminGate>
      <header>
        <Link href="/admin/products" className="flex items-center gap-1.5 text-[13px] font-bold text-muted hover:text-clay">
          <ChevronLeft className="h-4 w-4" /> Products
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="font-display text-[clamp(1.9rem,4vw,2.6rem)] leading-none">{product.title}</h1>
          <Badge tone={product.status === "active" ? "moss" : product.status === "draft" ? "gold" : "neutral"}>
            {product.status}
          </Badge>
          {product.featured ? <Badge tone="sale">Featured</Badge> : null}
        </div>
        <p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[13.5px] text-ink-2">
          <span>SKU {product.sku || "—"}</span>
          <span>Handle /products/{product.handle}</span>
          <span>Created {formatDate(product.createdAt)}</span>
          <span className="font-bold text-ink">{unitsSold} sold · {money(revenue)} revenue</span>
        </p>
      </header>

      <ProductForm product={product} variants={productVariants} collections={allCollections} />
    </AdminGate>
  );
}
