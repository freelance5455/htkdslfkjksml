import type { Metadata } from "next";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { discounts } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { DiscountsManager } from "@/components/admin/DiscountsManager";
import { ensureSeeded } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Discounts" };

export default async function AdminDiscountsPage() {
  await ensureSeeded();
  const rows = await db.select().from(discounts).orderBy(asc(discounts.code));
  const active = rows.filter((row) => row.active).length;
  const redemptions = rows.reduce((sum, row) => sum + row.usageCount, 0);

  return (
    <AdminGate>
      <header>
        <p className="eyebrow text-clay">Promotions</p>
        <h1 className="font-display mt-1.5 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Discounts</h1>
        <p className="mt-2 text-[14px] text-ink-2">
          {rows.length} codes · {active} active · {redemptions} redemptions
        </p>
      </header>

      <DiscountsManager discounts={rows} />
    </AdminGate>
  );
}
