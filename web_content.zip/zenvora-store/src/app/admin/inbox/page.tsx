import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { InboxList } from "@/components/admin/InboxList";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Inbox" };

export default async function AdminInboxPage() {
  const rows = await db.select().from(messages).orderBy(desc(messages.createdAt)).limit(100);
  const unread = rows.filter((row) => !row.read).length;

  return (
    <AdminGate>
      <header>
        <p className="eyebrow text-clay">Support</p>
        <h1 className="font-display mt-1.5 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Inbox</h1>
        <p className="mt-2 text-[14px] text-ink-2">
          Messages submitted through the storefront contact form{unread ? ` · ${unread} unread` : ""}.
        </p>
      </header>

      <InboxList messages={rows} />
    </AdminGate>
  );
}
