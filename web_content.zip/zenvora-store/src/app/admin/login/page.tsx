"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";
import { Button, Input, Label, Spinner } from "@/components/ui";
import { LockIcon, StoreIcon } from "@/components/icons";

export default function AdminLoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/admin/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not sign in.");
      router.push("/admin");
      router.refresh();
    } catch (signInError) {
      setError((signInError as Error).message);
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-ink px-5">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center gap-2.5 text-paper">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-clay">
            <StoreIcon className="h-5 w-5" />
          </span>
          <div>
            <p className="font-display text-[18px] leading-none">Zenvora Admin</p>
            <p className="mt-1 text-[11.5px] text-paper/55">Store management</p>
          </div>
        </div>

        <form onSubmit={submit} className="rounded-[22px] border border-paper/12 bg-paper p-7">
          <h1 className="font-display text-[26px] leading-tight">Log in</h1>
          <p className="mt-1.5 text-[13.5px] text-ink-2">
            Enter the store passphrase to manage products, orders and discounts.
          </p>

          <div className="mt-6">
            <Label htmlFor="password">Passphrase</Label>
            <Input
              id="password"
              type="password"
              autoFocus
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="••••••"
            />
            <p className="mt-2 rounded-lg bg-paper-2 px-3 py-2 text-[12px] text-ink-2">
              Demo passphrase: <span className="font-bold">haven</span>
            </p>
          </div>

          {error ? <p className="mt-4 text-[13px] font-semibold text-clay">{error}</p> : null}

          <Button type="submit" size="lg" className="mt-5 w-full" disabled={busy}>
            {busy ? <Spinner className="h-4 w-4" /> : <LockIcon className="h-4 w-4" />} Log in
          </Button>

          <Link href="/" className="mt-4 block text-center text-[13px] font-semibold text-ink-2 hover:text-clay">
            ← Back to the storefront
          </Link>
        </form>
      </div>
    </div>
  );
}
