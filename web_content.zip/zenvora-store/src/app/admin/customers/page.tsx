import Link from "next/link";
import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { Badge } from "@/components/ui";
import { MailIcon } from "@/components/icons";
import { ensureSeeded } from "@/lib/catalog";
import { formatDate, initials, money } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Customers" };

export default async function AdminCustomersPage() {
  await ensureSeeded();
  const [allCustomers, allOrders] = await Promise.all([
    db.select().from(customers).orderBy(desc(customers.totalSpentCents)),
    db.select().from(orders).orderBy(desc(orders.createdAt)),
  ]);

  const ordersByEmail = allOrders.reduce<Record<string, number>>((acc, order) => {
    const key = order.email.toLowerCase();
    acc[key] = (acc[key] ?? 0) + 1;
    return acc;
  }, {});

  const subscribed = allCustomers.filter((customer) => customer.marketingOptIn).length;
  const lifetimeValue = allCustomers.reduce((sum, customer) => sum + customer.totalSpentCents, 0);

  return (
    <AdminGate>
      <header>
        <p className="eyebrow text-clay">Relationships</p>
        <h1 className="font-display mt-1.5 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Customers</h1>
        <p className="mt-2 text-[14px] text-ink-2">
          {allCustomers.length} customers · {subscribed} subscribed to marketing · {money(lifetimeValue)} lifetime value
        </p>
      </header>

      <div className="mt-6 overflow-hidden rounded-[20px] border border-line bg-surface">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-[13.5px]">
            <thead className="border-b border-line bg-paper/60 text-[11px] uppercase tracking-[0.09em] text-muted">
              <tr>
                <th className="px-5 py-3 font-bold">Customer</th>
                <th className="px-4 py-3 font-bold">Orders</th>
                <th className="px-4 py-3 font-bold">Total spent</th>
                <th className="px-4 py-3 font-bold">Average order</th>
                <th className="px-4 py-3 font-bold">Marketing</th>
                <th className="px-5 py-3 font-bold">Joined</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {allCustomers.map((customer) => {
                const count = ordersByEmail[customer.email.toLowerCase()] ?? customer.ordersCount;
                return (
                  <tr key={customer.id} className="transition hover:bg-paper/50">
                    <td className="px-5 py-3">
                      <span className="flex items-center gap-3">
                        <span className="grid h-9 w-9 place-items-center rounded-full bg-clay/12 text-[12px] font-black text-clay">
                          {initials(`${customer.firstName} ${customer.lastName}`) || customer.email[0]?.toUpperCase()}
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate font-bold">
                            {customer.firstName} {customer.lastName}
                          </span>
                          <span className="flex items-center gap-1.5 text-[12px] text-muted">
                            <MailIcon className="h-3.5 w-3.5" /> {customer.email}
                          </span>
                        </span>
                      </span>
                    </td>
                    <td className="px-4 py-3 text-ink-2">{count}</td>
                    <td className="px-4 py-3 font-bold">{money(customer.totalSpentCents)}</td>
                    <td className="px-4 py-3 text-ink-2">
                      {count ? money(Math.round(customer.totalSpentCents / count)) : "—"}
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={customer.marketingOptIn ? "moss" : "neutral"}>
                        {customer.marketingOptIn ? "subscribed" : "not subscribed"}
                      </Badge>
                    </td>
                    <td className="px-5 py-3 text-muted">{formatDate(customer.createdAt)}</td>
                  </tr>
                );
              })}
              {allCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-muted">
                    No customers yet —{" "}
                    <Link href="/collections" className="font-bold text-clay hover:underline">
                      place a test order
                    </Link>
                    .
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </AdminGate>
  );
}
