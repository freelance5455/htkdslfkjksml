import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { and, desc, eq, ilike } from "drizzle-orm";
import { db } from "@/db";
import { customers, orderItems, orders } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { OrderActions } from "@/components/admin/OrderActions";
import { Badge } from "@/components/ui";
import { ChevronLeft, MailIcon, PhoneIcon, PinIcon, TruckIcon } from "@/components/icons";
import { formatDate, formatDateTime, initials, money } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order" };

type Params = Promise<{ id: string }>;

export default async function AdminOrderPage({ params }: { params: Params }) {
  const { id } = await params;
  const orderId = Number(id);

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) notFound();

  const [items, allCustomerOrders] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, orderId)),
    db.select().from(orders).where(ilike(orders.email, order.email)).orderBy(desc(orders.createdAt)),
  ]);

  const [customerRow] = await db.select().from(customers).where(ilike(customers.email, order.email)).limit(1);
  const customer = customerRow ?? null;

  const units = items.reduce((sum, item) => sum + item.quantity, 0);
  const profit = items.reduce((sum, item) => sum + item.totalCents, 0) - order.shippingCents;

  return (
    <AdminGate>
      <header>
        <Link href="/admin/orders" className="flex items-center gap-1.5 text-[13px] font-bold text-muted hover:text-clay">
          <ChevronLeft className="h-4 w-4" /> Orders
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="font-display text-[clamp(1.9rem,4vw,2.6rem)] leading-none">{order.orderNumber}</h1>
          <Badge tone={order.paymentStatus === "paid" ? "moss" : order.paymentStatus === "refunded" ? "sale" : "gold"}>
            {order.paymentStatus}
          </Badge>
          <Badge tone={order.fulfillmentStatus === "fulfilled" ? "moss" : "neutral"}>{order.fulfillmentStatus}</Badge>
        </div>
        <p className="mt-2 text-[13.5px] text-ink-2">
          Placed {formatDateTime(order.createdAt)} · {units} item{units === 1 ? "" : "s"} ·{" "}
          <Link href={`/orders/${encodeURIComponent(order.orderNumber)}?email=${encodeURIComponent(order.email)}`} className="font-bold text-clay hover:underline">
            customer-facing view
          </Link>
        </p>
      </header>

      <div className="mt-6 grid gap-6 xl:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <section className="overflow-hidden rounded-[20px] border border-line bg-surface">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="font-display text-[19px]">{items.length} line items</h2>
              <span className="text-[12.5px] text-muted">Gross margin {money(profit)}</span>
            </div>
            <ul className="divide-y divide-line">
              {items.map((item) => (
                <li key={item.id} className="flex items-center gap-4 px-5 py-4">
                  <span className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-paper-2">
                    {item.image ? <Image src={item.image} alt="" fill sizes="64px" className="object-cover" /> : null}
                  </span>
                  <span className="min-w-0 flex-1">
                    {item.productHandle ? (
                      <Link href={`/admin/products/${item.productId}`} className="block truncate text-[14px] font-bold hover:text-clay">
                        {item.title}
                      </Link>
                    ) : (
                      <span className="block truncate text-[14px] font-bold">{item.title}</span>
                    )}
                    <span className="block text-[12.5px] text-muted">
                      {item.variantTitle && item.variantTitle !== "Default Title" ? `${item.variantTitle} · ` : ""}SKU {item.sku || "—"}
                    </span>
                  </span>
                  <span className="text-right">
                    <span className="block text-[14px] font-bold">{money(item.totalCents)}</span>
                    <span className="block text-[12px] text-muted">
                      {item.quantity} × {money(item.priceCents)}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
            <div className="space-y-2 border-t border-line px-5 py-4 text-[13.5px]">
              <div className="flex justify-between"><span className="text-ink-2">Subtotal</span><span className="font-bold">{money(order.subtotalCents)}</span></div>
              {order.discountCents > 0 ? (
                <div className="flex justify-between text-moss">
                  <span>Discount {order.discountCode ? `(${order.discountCode})` : ""}</span>
                  <span className="font-bold">−{money(order.discountCents)}</span>
                </div>
              ) : null}
              <div className="flex justify-between"><span className="text-ink-2">Shipping ({order.shippingMethod})</span><span className="font-bold">{order.shippingCents === 0 ? "Free" : money(order.shippingCents)}</span></div>
              <div className="flex justify-between"><span className="text-ink-2">Tax</span><span className="font-bold">{money(order.taxCents)}</span></div>
              <div className="flex items-end justify-between border-t border-line pt-3">
                <span className="text-[14px] font-bold">Total</span>
                <span className="font-display text-[26px] leading-none">{money(order.totalCents)}</span>
              </div>
            </div>
          </section>

          <section className="grid gap-6 sm:grid-cols-2">
            <div className="rounded-[20px] border border-line bg-surface p-5">
              <h2 className="font-display text-[19px]">Customer</h2>
              <div className="mt-3 flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-clay/12 text-[14px] font-black text-clay">
                  {initials(`${order.firstName} ${order.lastName}`)}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[14.5px] font-bold">
                    {order.firstName} {order.lastName}
                  </p>
                  <p className="truncate text-[12.5px] text-muted">{order.email}</p>
                </div>
              </div>
              <ul className="mt-4 space-y-2 text-[13px] text-ink-2">
                <li className="flex items-center gap-2">
                  <MailIcon className="h-4 w-4 text-clay" /> {order.email}
                </li>
                {order.phone ? (
                  <li className="flex items-center gap-2">
                    <PhoneIcon className="h-4 w-4 text-clay" /> {order.phone}
                  </li>
                ) : null}
                <li className="flex items-center gap-2">
                  <PinIcon className="h-4 w-4 text-clay" />
                  {customer?.createdAt ? `Customer since ${formatDate(customer.createdAt)}` : "First-time customer"}
                </li>
              </ul>
              <div className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-4">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.09em] text-muted">Orders</p>
                  <p className="font-display mt-1 text-[22px] leading-none">{allCustomerOrders.length}</p>
                </div>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.09em] text-muted">Lifetime value</p>
                  <p className="font-display mt-1 text-[22px] leading-none">
                    {money(allCustomerOrders.reduce((sum, row) => sum + row.totalCents, 0))}
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-[20px] border border-line bg-surface p-5">
              <h2 className="font-display text-[19px]">Shipping address</h2>
              <address className="mt-3 not-italic text-[13.5px] leading-relaxed text-ink-2">
                <span className="block font-bold text-ink">
                  {order.firstName} {order.lastName}
                </span>
                {order.address1}
                {order.address2 ? <>, {order.address2}</> : null}
                <br />
                {order.city}, {order.province} {order.zip}
                <br />
                {order.country}
              </address>
              <p className="mt-4 flex items-center gap-2 rounded-xl bg-paper/70 px-3.5 py-3 text-[13px] font-semibold">
                <TruckIcon className="h-4 w-4 text-clay" />
                {order.shippingMethod} · {money(order.shippingCents) === money(0) ? "free" : money(order.shippingCents)}
              </p>
            </div>
          </section>

          {order.note ? (
            <section className="rounded-[20px] border border-line bg-paper-2/60 p-5">
              <p className="eyebrow text-muted">Order note from the customer</p>
              <p className="mt-2 text-[14px] leading-relaxed text-ink-2">{order.note}</p>
            </section>
          ) : null}
        </div>

        <aside>
          <OrderActions order={order} />
        </aside>
      </div>
    </AdminGate>
  );
}
