import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { OrdersTable } from "@/components/admin/OrdersTable";
import { ensureSeeded } from "@/lib/catalog";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Orders" };

export default async function AdminOrdersPage() {
  await ensureSeeded();
  const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(200);

  const unfulfilled = allOrders.filter((order) => order.fulfillmentStatus === "unfulfilled").length;
  const paid = allOrders.filter((order) => order.paymentStatus === "paid");
  const revenue = paid.reduce((sum, order) => sum + order.totalCents, 0);
  const average = paid.length ? Math.round(revenue / paid.length) : 0;

  return (
    <AdminGate>
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow text-clay">Fulfilment</p>
          <h1 className="font-display mt-1.5 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Orders</h1>
          <p className="mt-2 text-[14px] text-ink-2">
            {allOrders.length} orders · {unfulfilled} awaiting fulfilment
          </p>
        </div>
        <div className="flex gap-3">
          {[
            { label: "Paid revenue", value: money(revenue) },
            { label: "Average order", value: money(average) },
            { label: "Unfulfilled", value: String(unfulfilled) },
          ].map((stat) => (
            <div key={stat.label} className="rounded-[16px] border border-line bg-surface px-4 py-3">
              <p className="text-[11px] font-bold uppercase tracking-[0.09em] text-muted">{stat.label}</p>
              <p className="font-display mt-1 text-[22px] leading-none">{stat.value}</p>
            </div>
          ))}
        </div>
      </header>

      <OrdersTable orders={allOrders} />
    </AdminGate>
  );
}
