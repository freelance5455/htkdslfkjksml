import Link from "next/link";
import type { Metadata } from "next";
import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders, products } from "@/db/schema";
import { AdminGate } from "@/components/admin/AdminGate";
import { SalesChart, Donut } from "@/components/admin/charts";
import { Badge } from "@/components/ui";
import { formatDateTime, initials, money } from "@/lib/format";
import { getAdminStats } from "@/lib/catalog";
import { ArrowRight, PackageIcon, UsersIcon, AlertIcon, TagIcon } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Overview" };

export default async function AdminDashboard() {
  const [stats, recentOrders, lowStock, recentCustomers] = await Promise.all([
    getAdminStats(),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(7),
    db
      .select()
      .from(products)
      .where(sql`${products.inventoryQty} <= 5`)
      .orderBy(products.inventoryQty)
      .limit(6),
    db.select().from(customers).orderBy(desc(customers.createdAt)).limit(5),
  ]);

  const unfulfilled = stats.fulfillmentBreakdown.find((row) => row.status === "unfulfilled")?.count ?? 0;
  const pendingPayment = stats.paymentBreakdown.find((row) => row.status === "pending")?.count ?? 0;

  const cards = [
    { label: "Gross sales", value: money(stats.revenueCents), sub: `${stats.orderCount} orders all-time`, icon: TagIcon },
    { label: "Average order", value: money(stats.averageOrderCents), sub: `${stats.unitsSold} units sold`, icon: PackageIcon },
    { label: "Customers", value: String(stats.customerCount), sub: `${stats.openCarts} carts in the database`, icon: UsersIcon },
    { label: "Conversion", value: `${stats.conversionRate}%`, sub: "orders ÷ carts created", icon: AlertIcon },
  ];

  return (
    <AdminGate>
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow text-clay">Store overview</p>
          <h1 className="font-display mt-1.5 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Good to see you</h1>
          <p className="mt-2 text-[14px] text-ink-2">
            {stats.productCount} products · {unfulfilled} order{unfulfilled === 1 ? "" : "s"} to fulfil
            {pendingPayment ? ` · ${pendingPayment} payment${pendingPayment === 1 ? "" : "s"} pending` : ""}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            href="/admin/products/new"
            className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-[13.5px] font-bold text-paper transition hover:bg-clay"
          >
            + Add product
          </Link>
          <Link
            href="/admin/orders?status=unfulfilled"
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-surface px-5 text-[13.5px] font-bold transition hover:border-ink"
          >
            Unfulfilled ({unfulfilled}) <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </header>

      <section className="mt-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="rounded-[20px] border border-line bg-surface p-5">
            <div className="flex items-center justify-between">
              <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-muted">{card.label}</p>
              <span className="grid h-8 w-8 place-items-center rounded-full bg-clay/10 text-clay">
                <card.icon className="h-4 w-4" />
              </span>
            </div>
            <p className="font-display mt-3 text-[30px] leading-none">{card.value}</p>
            <p className="mt-2 text-[12.5px] text-muted">{card.sub}</p>
          </div>
        ))}
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <div className="rounded-[20px] border border-line bg-surface p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="font-display text-[20px]">Sales</h2>
              <p className="text-[12.5px] text-muted">Daily gross sales from the seeded order history</p>
            </div>
            <Badge tone="moss">Last {stats.salesByDay.length} days</Badge>
          </div>
          <SalesChart data={stats.salesByDay} />
        </div>

        <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-1">
          <div className="rounded-[20px] border border-line bg-surface p-6">
            <h2 className="font-display text-[20px]">Fulfilment</h2>
            <Donut
              data={stats.fulfillmentBreakdown.map((row) => ({ label: row.status, value: row.count }))}
              colors={["#3c4a37", "#d8cdbb"]}
            />
          </div>
          <div className="rounded-[20px] border border-line bg-surface p-6">
            <h2 className="font-display text-[20px]">Payments</h2>
            <Donut
              data={stats.paymentBreakdown.map((row) => ({ label: row.status, value: row.count }))}
              colors={["#a4472a", "#b98b2e", "#857b70"]}
            />
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <div className="overflow-hidden rounded-[20px] border border-line bg-surface">
          <div className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 className="font-display text-[20px]">Recent orders</h2>
            <Link href="/admin/orders" className="flex items-center gap-1.5 text-[13px] font-bold text-clay hover:underline">
              View all <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-left text-[13.5px]">
              <thead className="border-b border-line bg-paper/60 text-[11px] uppercase tracking-[0.09em] text-muted">
                <tr>
                  <th className="px-6 py-3 font-bold">Order</th>
                  <th className="px-4 py-3 font-bold">Customer</th>
                  <th className="px-4 py-3 font-bold">Date</th>
                  <th className="px-4 py-3 font-bold">Payment</th>
                  <th className="px-4 py-3 font-bold">Fulfilment</th>
                  <th className="px-6 py-3 text-right font-bold">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="transition hover:bg-paper/60">
                    <td className="px-6 py-3.5">
                      <Link href={`/admin/orders/${order.id}`} className="font-bold hover:text-clay">
                        {order.orderNumber}
                      </Link>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="flex items-center gap-2">
                        <span className="grid h-7 w-7 place-items-center rounded-full bg-paper-2 text-[10.5px] font-black text-ink-2">
                          {initials(`${order.firstName} ${order.lastName}`)}
                        </span>
                        <span className="max-w-[140px] truncate">
                          {order.firstName} {order.lastName}
                        </span>
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-muted">{formatDateTime(order.createdAt)}</td>
                    <td className="px-4 py-3.5">
                      <Badge tone={order.paymentStatus === "paid" ? "moss" : "gold"}>{order.paymentStatus}</Badge>
                    </td>
                    <td className="px-4 py-3.5">
                      <Badge tone={order.fulfillmentStatus === "fulfilled" ? "moss" : "neutral"}>
                        {order.fulfillmentStatus}
                      </Badge>
                    </td>
                    <td className="px-6 py-3.5 text-right font-bold">{money(order.totalCents)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-[20px] border border-line bg-surface p-6">
            <h2 className="font-display text-[20px]">Top products</h2>
            <ul className="mt-4 space-y-3">
              {stats.topProducts.map((product, index) => (
                <li key={product.title} className="flex items-center gap-3">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-paper-2 text-[12px] font-black text-ink-2">
                    {index + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13.5px] font-bold">{product.title}</span>
                    <span className="block text-[12px] text-muted">
                      {product.qty} sold · {money(product.revenueCents)}
                    </span>
                  </span>
                </li>
              ))}
              {stats.topProducts.length === 0 ? (
                <li className="text-[13px] text-muted">No sales recorded yet.</li>
              ) : null}
            </ul>
          </div>

          <div className="rounded-[20px] border border-line bg-surface p-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-[20px]">Low stock</h2>
              <Badge tone={lowStock.length ? "sale" : "moss"}>{lowStock.length} alerts</Badge>
            </div>
            <ul className="mt-4 space-y-3">
              {lowStock.map((product) => (
                <li key={product.id} className="flex items-center gap-3">
                  <span className="min-w-0 flex-1">
                    <Link href={`/admin/products/${product.id}`} className="block truncate text-[13.5px] font-bold hover:text-clay">
                      {product.title}
                    </Link>
                    <span className="block text-[12px] text-muted">{product.vendor} · SKU {product.sku}</span>
                  </span>
                  <span className={`text-[13px] font-black ${product.inventoryQty === 0 ? "text-clay" : "text-gold"}`}>
                    {product.inventoryQty} left
                  </span>
                </li>
              ))}
              {lowStock.length === 0 ? <li className="text-[13px] text-muted">Everything is comfortably stocked.</li> : null}
            </ul>
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-2">
        <div className="rounded-[20px] border border-line bg-surface p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-[20px]">New customers</h2>
            <Link href="/admin/customers" className="text-[13px] font-bold text-clay hover:underline">
              All customers
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-line">
            {recentCustomers.map((customer) => (
              <li key={customer.id} className="flex items-center gap-3 py-3">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-clay/12 text-[12px] font-black text-clay">
                  {initials(`${customer.firstName} ${customer.lastName}`) || customer.email[0]?.toUpperCase()}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13.5px] font-bold">
                    {customer.firstName} {customer.lastName}
                  </span>
                  <span className="block truncate text-[12px] text-muted">{customer.email}</span>
                </span>
                <span className="text-right">
                  <span className="block text-[13px] font-bold">{money(customer.totalSpentCents)}</span>
                  <span className="block text-[11.5px] text-muted">{customer.ordersCount} orders</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-[20px] border border-line bg-ink p-6 text-paper">
          <h2 className="font-display text-[20px]">Store health</h2>
          <p className="mt-1.5 text-[13px] text-paper/65">A quick snapshot of what needs attention today.</p>
          <ul className="mt-5 space-y-3">
            {[
              { label: "Orders to fulfil", value: unfulfilled, tone: unfulfilled > 0 ? "clay" : "moss" },
              { label: "Payments pending", value: pendingPayment, tone: pendingPayment > 0 ? "gold" : "moss" },
              { label: "Products below 5 units", value: stats.lowStockCount, tone: stats.lowStockCount > 0 ? "gold" : "moss" },
              { label: "Draft / archived products", value: stats.draftCount, tone: "moss" },
            ].map((row) => (
              <li key={row.label} className="flex items-center justify-between rounded-xl bg-paper/8 px-4 py-3">
                <span className="text-[13.5px] text-paper/80">{row.label}</span>
                <span
                  className={`font-display text-[20px] leading-none ${
                    row.tone === "clay" ? "text-clay-soft" : row.tone === "gold" ? "text-gold" : "text-paper"
                  }`}
                >
                  {row.value}
                </span>
              </li>
            ))}
          </ul>
          <Link
            href="/admin/products"
            className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-paper px-5 text-[13.5px] font-bold text-ink transition hover:bg-clay hover:text-paper"
          >
            Manage inventory <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </AdminGate>
  );
}
