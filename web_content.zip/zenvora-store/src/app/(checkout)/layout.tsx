import type { ReactNode } from "react";
import { CartProvider } from "@/components/cart/CartProvider";

export const dynamic = "force-dynamic";

export default function CheckoutLayout({ children }: { children: ReactNode }) {
  return <CartProvider>{children}</CartProvider>;
}
