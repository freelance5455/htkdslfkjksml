import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { customers, discounts, orderItems, orders, products, variants } from "@/db/schema";
import { clearCartCookie, ensureCart, emptyCart, loadCart } from "@/lib/cart";
import { computeTotals, getShippingRate, slugify } from "@/lib/format";
import { findDiscountByCode } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

type CheckoutBody = {
  email?: string;
  firstName?: string;
  lastName?: string;
  address1?: string;
  address2?: string;
  city?: string;
  province?: string;
  zip?: string;
  country?: string;
  phone?: string;
  shippingMethod?: string;
  cardName?: string;
  cardNumber?: string;
  expiry?: string;
  cvc?: string;
  note?: string;
  marketingOptIn?: boolean;
};

function invalid(message: string) {
  return NextResponse.json({ error: message }, { status: 400 });
}

function detectBrand(number: string) {
  if (/^4/.test(number)) return "visa";
  if (/^(5[1-5]|2[2-7])/.test(number)) return "mastercard";
  if (/^3[47]/.test(number)) return "amex";
  if (/^6/.test(number)) return "discover";
  return "card";
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as CheckoutBody;

    const email = (body.email ?? "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return invalid("Enter a valid email address.");

    const required: [string | undefined, string][] = [
      [body.firstName, "First name is required."],
      [body.lastName, "Last name is required."],
      [body.address1, "Street address is required."],
      [body.city, "City is required."],
      [body.province, "State / region is required."],
      [body.zip, "Postal code is required."],
    ];
    for (const [value, message] of required) {
      if (!String(value ?? "").trim()) return invalid(message);
    }
    if (!/^[0-9]{4,10}$/.test(String(body.zip).trim().replace(/\s|-/g, ""))) return invalid("Enter a valid postal code.");

    const digits = String(body.cardNumber ?? "").replace(/\D/g, "");
    if (digits.length < 15 || digits.length > 16) return invalid("Enter a valid card number (16 digits).");
    const expiryMatch = /^(0[1-9]|1[0-2])\s*\/\s*(\d{2})$/.exec(String(body.expiry ?? "").trim());
    if (!expiryMatch) return invalid("Card expiry must be MM/YY.");
    const expiryDate = new Date(2000 + Number(expiryMatch[2]), Number(expiryMatch[1]), 0);
    if (expiryDate < new Date()) return invalid("That card has expired.");
    if (!/^\d{3,4}$/.test(String(body.cvc ?? ""))) return invalid("Enter a valid security code.");
    if (!String(body.cardName ?? "").trim()) return invalid("Enter the name on the card.");

    const cart = await ensureCart();
    const payload = await loadCart(cart.id);
    if (payload.lines.length === 0) return invalid("Your bag is empty.");

    for (const line of payload.lines) {
      if (line.trackInventory && line.inventoryQty < line.quantity) {
        return NextResponse.json(
          { error: `"${line.title}" only has ${line.inventoryQty} left in stock.` },
          { status: 409 },
        );
      }
    }

    const shippingMethod = getShippingRate(String(body.shippingMethod ?? "standard")).id;
    const discount = payload.discount ? await findDiscountByCode(payload.discount.code) : null;
    const totals = computeTotals({ subtotalCents: payload.subtotalCents, shippingMethod, discount });

    // Simulated payment authorisation.
    await new Promise((resolve) => setTimeout(resolve, 850));

    const [{ maxId }] = await db.select({ maxId: sql<number>`coalesce(max(${orders.id}),0)::int` }).from(orders);
    let orderNumber = `#${1000 + Number(maxId) + 1}`;
    const collision = await db.select({ id: orders.id }).from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
    if (collision.length) orderNumber = `#${1000 + Number(maxId) + collision.length + 2}`;

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber,
        email,
        firstName: String(body.firstName).trim(),
        lastName: String(body.lastName).trim(),
        address1: String(body.address1).trim(),
        address2: String(body.address2 ?? "").trim(),
        city: String(body.city).trim(),
        province: String(body.province).trim(),
        zip: String(body.zip).trim(),
        country: String(body.country ?? "United States").trim(),
        phone: String(body.phone ?? "").trim(),
        shippingMethod,
        shippingCents: totals.shippingCents,
        subtotalCents: totals.subtotalCents,
        taxCents: totals.taxCents,
        discountCents: totals.discountCents,
        totalCents: totals.totalCents,
        discountCode: totals.discountCode,
        paymentBrand: detectBrand(digits),
        paymentLast4: digits.slice(-4),
        paymentStatus: "paid",
        fulfillmentStatus: "unfulfilled",
        note: String(body.note ?? payload.note ?? "").slice(0, 500),
      })
      .returning();

    await db.insert(orderItems).values(
      payload.lines.map((line) => ({
        orderId: order.id,
        productId: line.productId,
        variantId: line.variantId,
        productHandle: line.handle,
        title: line.title,
        variantTitle: line.variantTitle,
        sku: line.sku,
        image: line.image,
        priceCents: line.priceCents,
        quantity: line.quantity,
        totalCents: line.priceCents * line.quantity,
      })),
    );

    // Decrement inventory.
    for (const line of payload.lines) {
      await db
        .update(variants)
        .set({ inventoryQty: sql`greatest(${variants.inventoryQty} - ${line.quantity}, 0)` })
        .where(eq(variants.id, line.variantId));
      await db
        .update(products)
        .set({
          inventoryQty: sql`greatest(${products.inventoryQty} - ${line.quantity}, 0)`,
          updatedAt: new Date(),
        })
        .where(eq(products.id, line.productId));
    }

    // Upsert customer.
    const [existingCustomer] = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
    if (existingCustomer) {
      await db
        .update(customers)
        .set({
          firstName: String(body.firstName).trim() || existingCustomer.firstName,
          lastName: String(body.lastName).trim() || existingCustomer.lastName,
          ordersCount: sql`${customers.ordersCount} + 1`,
          totalSpentCents: sql`${customers.totalSpentCents} + ${totals.totalCents}`,
          marketingOptIn: existingCustomer.marketingOptIn || Boolean(body.marketingOptIn),
        })
        .where(eq(customers.id, existingCustomer.id));
    } else {
      await db.insert(customers).values({
        email,
        firstName: String(body.firstName).trim(),
        lastName: String(body.lastName).trim(),
        ordersCount: 1,
        totalSpentCents: totals.totalCents,
        marketingOptIn: Boolean(body.marketingOptIn),
      });
    }

    if (discount) {
      await db.update(discounts).set({ usageCount: sql`${discounts.usageCount} + 1` }).where(eq(discounts.id, discount.id));
    }

    await emptyCart(cart.id);
    await clearCartCookie();

    return NextResponse.json({
      ok: true,
      orderId: order.id,
      orderNumber: order.orderNumber,
      email: order.email,
      totalCents: order.totalCents,
      slug: slugify(`${order.orderNumber}-${order.email}`),
    });
  } catch (error) {
    console.error("[checkout]", error);
    return NextResponse.json({ error: "Payment could not be processed. Please try again." }, { status: 500 });
  }
}
