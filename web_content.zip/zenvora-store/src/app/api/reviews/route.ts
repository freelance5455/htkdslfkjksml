import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    productId?: number;
    author?: string;
    email?: string;
    rating?: number;
    title?: string;
    body?: string;
  };

  const productId = Number(body.productId);
  const rating = Math.max(1, Math.min(5, Math.round(Number(body.rating ?? 5))));
  const author = String(body.author ?? "").trim();
  const text = String(body.body ?? "").trim();

  if (!Number.isInteger(productId)) return NextResponse.json({ error: "Unknown product." }, { status: 400 });
  const [product] = await db.select({ id: products.id }).from(products).where(eq(products.id, productId)).limit(1);
  if (!product) return NextResponse.json({ error: "Unknown product." }, { status: 404 });
  if (!author) return NextResponse.json({ error: "Please add your name." }, { status: 400 });
  if (text.length < 10) return NextResponse.json({ error: "Reviews need at least 10 characters." }, { status: 400 });
  if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(body.email))) {
    return NextResponse.json({ error: "That email looks off." }, { status: 400 });
  }

  const [review] = await db
    .insert(reviews)
    .values({
      productId,
      author,
      email: String(body.email ?? "").trim().toLowerCase(),
      rating,
      title: String(body.title ?? "").trim().slice(0, 120),
      body: text.slice(0, 2000),
      approved: true,
    })
    .returning();

  return NextResponse.json({ ok: true, review });
}
