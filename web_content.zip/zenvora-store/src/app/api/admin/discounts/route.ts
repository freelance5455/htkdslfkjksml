import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { discounts } from "@/db/schema";
import { isAdmin } from "@/lib/admin";
import { ensureSeeded } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(discounts).orderBy(asc(discounts.code));
  return NextResponse.json({ discounts: rows });
}

export async function POST(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as {
    code?: string;
    type?: string;
    value?: number;
    minSubtotalCents?: number;
    usageLimit?: number | null;
    active?: boolean;
  };

  const code = String(body.code ?? "").trim().toUpperCase();
  if (!code) return NextResponse.json({ error: "A code is required." }, { status: 400 });
  const type = ["percentage", "fixed_amount", "free_shipping"].includes(String(body.type)) ? String(body.type) : "percentage";
  const value = Math.max(0, Math.round(Number(body.value ?? 0) || 0));
  if (type === "percentage" && (value <= 0 || value > 90)) {
    return NextResponse.json({ error: "Percentage must be between 1 and 90." }, { status: 400 });
  }
  if (type === "fixed_amount" && value <= 0) {
    return NextResponse.json({ error: "Enter an amount in cents (e.g. 2000 = $20)." }, { status: 400 });
  }

  const existing = await db.select().from(discounts);
  if (existing.some((row) => row.code === code)) {
    return NextResponse.json({ error: `${code} already exists.` }, { status: 409 });
  }

  const [row] = await db
    .insert(discounts)
    .values({
      code,
      type,
      value: type === "free_shipping" ? 0 : value,
      minSubtotalCents: Math.max(0, Math.round(Number(body.minSubtotalCents ?? 0) || 0)),
      usageLimit: body.usageLimit ? Math.round(Number(body.usageLimit)) : null,
      active: body.active ?? true,
    })
    .returning();

  return NextResponse.json({ ok: true, discount: row });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as { id?: number; active?: boolean };
  if (!body.id) return NextResponse.json({ error: "Discount id required." }, { status: 400 });

  if (typeof body.active === "boolean") {
    await db.update(discounts).set({ active: body.active }).where(eq(discounts.id, Number(body.id)));
    return NextResponse.json({ ok: true });
  }
  await db.delete(discounts).where(eq(discounts.id, Number(body.id)));
  return NextResponse.json({ ok: true });
}
