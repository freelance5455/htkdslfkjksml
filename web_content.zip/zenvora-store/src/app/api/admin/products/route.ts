import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, variants } from "@/db/schema";
import { isAdmin } from "@/lib/admin";
import { ensureSeeded } from "@/lib/catalog";
import { normaliseProduct, type ProductInput, type VariantInput } from "@/lib/admin/product-payload";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(products);
  return NextResponse.json({ products: rows });
}

export async function POST(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const input = (await request.json().catch(() => ({}))) as ProductInput;
  if (!input.title?.trim()) return NextResponse.json({ error: "Title is required." }, { status: 400 });
  if (!input.priceCents || Number(input.priceCents) <= 0) {
    return NextResponse.json({ error: "A price greater than zero is required." }, { status: 400 });
  }

  const data = normaliseProduct(input);
  const [product] = await db.insert(products).values({ ...data, publishedAt: new Date() }).returning();

  const list: VariantInput[] = input.variants?.length
    ? input.variants
    : [{ title: "Default Title", priceCents: data.priceCents, inventoryQty: data.inventoryQty }];

  await db.insert(variants).values(
    list.map((variant, index) => ({
      productId: product.id,
      title: variant.title?.trim() || "Default Title",
      sku: variant.sku?.trim() || (data.sku ? `${data.sku}-${index + 1}` : ""),
      priceCents: Math.round(Number(variant.priceCents) || data.priceCents),
      compareAtPriceCents: variant.compareAtPriceCents
        ? Math.round(Number(variant.compareAtPriceCents))
        : data.compareAtPriceCents,
      inventoryQty: Math.max(0, Math.round(Number(variant.inventoryQty) || 0)),
      option1: variant.option1 ?? null,
      option2: variant.option2 ?? null,
      image: variant.image ?? data.images[0] ?? null,
      position: index + 1,
    })),
  );

  return NextResponse.json({ ok: true, product });
}
