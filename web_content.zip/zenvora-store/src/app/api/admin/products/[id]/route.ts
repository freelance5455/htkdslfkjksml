import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, products, reviews, variants } from "@/db/schema";
import { isAdmin } from "@/lib/admin";
import { getProductById } from "@/lib/catalog";
import { normaliseProduct, type ProductInput, type VariantInput } from "@/lib/admin/product-payload";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Params) {
  const { id } = await params;
  const product = await getProductById(Number(id));
  if (!product) return NextResponse.json({ error: "Product not found." }, { status: 404 });
  return NextResponse.json({ product });
}

export async function PATCH(request: Request, { params }: Params) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const productId = Number(id);
  const input = (await request.json()) as ProductInput;

  const [existing] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!existing) return NextResponse.json({ error: "Product not found." }, { status: 404 });

  const data = normaliseProduct(input);
  const [updated] = await db.update(products).set(data).where(eq(products.id, productId)).returning();

  if (input.variants) {
    await db.delete(variants).where(eq(variants.productId, productId));
    const list: VariantInput[] = input.variants.length
      ? input.variants
      : [{ title: "Default Title", priceCents: data.priceCents, inventoryQty: data.inventoryQty }];
    const rows = list.map((variant, index) => ({
      productId,
      title: variant.title?.trim() || "Default Title",
      sku: variant.sku?.trim() || (data.sku ? `${data.sku}-${index + 1}` : ""),
      priceCents: Math.round(Number(variant.priceCents) || data.priceCents),
      compareAtPriceCents: variant.compareAtPriceCents
        ? Math.round(Number(variant.compareAtPriceCents))
        : data.compareAtPriceCents,
      inventoryQty: Math.max(0, Math.round(Number(variant.inventoryQty) || 0)),
      option1: variant.option1 ?? null,
      option2: variant.option2 ?? null,
      image: variant.image ?? data.images[0] ?? null,
      position: index + 1,
    }));
    await db.insert(variants).values(rows);
  }

  return NextResponse.json({ ok: true, product: updated });
}

export async function DELETE(_request: Request, { params }: Params) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const productId = Number(id);

  const [existing] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!existing) return NextResponse.json({ error: "Product not found." }, { status: 404 });

  await db.delete(orderItems).where(eq(orderItems.productId, productId));
  await db.delete(reviews).where(eq(reviews.productId, productId));
  await db.delete(variants).where(eq(variants.productId, productId));
  await db.delete(products).where(eq(products.id, productId));

  return NextResponse.json({ ok: true });
}
