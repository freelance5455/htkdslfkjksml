import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin";
import { reseedAll } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Rebuilds the demo catalogue, orders and customers from scratch. */
export async function POST() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  await reseedAll();
  return NextResponse.json({ ok: true, message: "Demo data rebuilt." });
}
