import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { isAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Params) {
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
  if (!order) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return NextResponse.json({ order, items });
}

export async function PATCH(request: Request, { params }: Params) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const body = (await request.json().catch(() => ({}))) as {
    fulfillmentStatus?: string;
    paymentStatus?: string;
    note?: string;
  };

  const updates: Record<string, unknown> = {};
  if (body.fulfillmentStatus && ["unfulfilled", "fulfilled"].includes(body.fulfillmentStatus)) {
    updates.fulfillmentStatus = body.fulfillmentStatus;
  }
  if (body.paymentStatus && ["paid", "pending", "refunded"].includes(body.paymentStatus)) {
    updates.paymentStatus = body.paymentStatus;
  }
  if (typeof body.note === "string") updates.note = body.note.slice(0, 500);
  if (Object.keys(updates).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  const [order] = await db.update(orders).set(updates).where(eq(orders.id, Number(id))).returning();
  if (!order) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  return NextResponse.json({ ok: true, order });
}
