import { NextResponse } from "next/server";
import { ADMIN_PASSWORD, grantAdmin, isAdmin, revokeAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ authenticated: await isAdmin() });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { password?: string };
  if (String(body.password ?? "") !== ADMIN_PASSWORD) {
    return NextResponse.json({ error: "Incorrect password." }, { status: 401 });
  }
  await grantAdmin();
  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  await revokeAdmin();
  return NextResponse.json({ ok: true });
}
