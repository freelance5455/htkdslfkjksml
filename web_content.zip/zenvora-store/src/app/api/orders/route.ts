import { NextResponse } from "next/server";
import { and, desc, eq, ilike, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { ensureSeeded } from "@/lib/catalog";

export const dynamic = "force-dynamic";

/**
 * Public order lookup — requires both the order number and the email on the order,
 * mirroring Shopify's "look up your order" guest flow.
 */
export async function GET(request: Request) {
  await ensureSeeded();
  const { searchParams } = new URL(request.url);
  const rawNumber = (searchParams.get("orderNumber") ?? "").trim();
  const email = (searchParams.get("email") ?? "").trim().toLowerCase();

  if (!rawNumber || !email) {
    return NextResponse.json({ error: "Order number and email are required." }, { status: 400 });
  }

  const orderNumber = rawNumber.startsWith("#") ? rawNumber : `#${rawNumber}`;

  const [order] = await db
    .select()
    .from(orders)
    .where(and(eq(orders.orderNumber, orderNumber), ilike(orders.email, email)))
    .limit(1);

  if (!order) return NextResponse.json({ error: "We couldn't find that order." }, { status: 404 });

  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return NextResponse.json({ order, items });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { email?: string };
  const email = String(body.email ?? "").trim().toLowerCase();
  if (!email) return NextResponse.json({ error: "Email is required." }, { status: 400 });

  const rows = await db
    .select()
    .from(orders)
    .where(or(ilike(orders.email, email), eq(orders.email, email))!)
    .orderBy(desc(orders.createdAt));

  if (!rows.length) return NextResponse.json({ orders: [], items: [], email });
  const ids = rows.map((row) => row.id);
  const items = await db.select().from(orderItems).where(inArray(orderItems.orderId, ids));
  return NextResponse.json({ orders: rows, items, email });
}
