import { NextResponse } from "next/server";
import { searchSuggestions } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("q") ?? "";
  if (query.trim().length === 0) return NextResponse.json({ results: [] });
  const results = await searchSuggestions(query, Number(searchParams.get("limit") ?? 6));
  return NextResponse.json({ results });
}
