import { NextResponse } from "next/server";
import { getProductByHandle } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ handle: string }> };

export async function GET(_request: Request, { params }: Params) {
  const { handle } = await params;
  const product = await getProductByHandle(decodeURIComponent(handle));
  if (!product) return NextResponse.json({ error: "Product not found." }, { status: 404 });

  return NextResponse.json({
    product: {
      id: product.id,
      handle: product.handle,
      title: product.title,
      vendor: product.vendor,
      description: product.description,
      priceCents: product.priceCents,
      compareAtPriceCents: product.compareAtPriceCents,
      inventoryQty: product.inventoryQty,
      images: product.images,
      tags: product.tags,
      optionNames: product.optionNames,
      optionValues: product.optionValues,
      collectionHandle: product.collection?.handle ?? null,
    },
    variants: product.variants,
    rating: product.rating,
    reviewCount: product.reviewCount,
  });
}
