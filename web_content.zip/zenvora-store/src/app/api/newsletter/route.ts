import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { customers } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { email?: string; firstName?: string };
  const email = String(body.email ?? "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  }

  await db
    .insert(customers)
    .values({
      email,
      firstName: String(body.firstName ?? "").trim(),
      marketingOptIn: true,
    })
    .onConflictDoUpdate({
      target: customers.email,
      set: { marketingOptIn: true },
    });

  return NextResponse.json({ ok: true, message: "You're on the list — WELCOME10 is yours." });
}

export async function GET() {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(customers);
  return NextResponse.json({ subscribers: Number(row?.count ?? 0) });
}
