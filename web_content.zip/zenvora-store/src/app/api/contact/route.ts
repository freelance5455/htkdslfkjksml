import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { isAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    name?: string;
    email?: string;
    topic?: string;
    body?: string;
    orderNumber?: string;
  };

  const email = String(body.email ?? "").trim().toLowerCase();
  const text = String(body.body ?? "").trim();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  if (text.length < 15) {
    return NextResponse.json({ error: "Tell us a little more (at least 15 characters)." }, { status: 400 });
  }

  const [message] = await db
    .insert(messages)
    .values({
      name: String(body.name ?? "").trim().slice(0, 120),
      email,
      topic: String(body.topic ?? "General").slice(0, 60),
      body: text.slice(0, 4000),
      orderNumber: body.orderNumber ? String(body.orderNumber).trim().slice(0, 20) : null,
    })
    .returning();

  return NextResponse.json({
    ok: true,
    message,
    reference: `HVC-${String(message.id).padStart(5, "0")}`,
  });
}

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db.select().from(messages).orderBy(desc(messages.createdAt)).limit(50);
  return NextResponse.json({ messages: rows });
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as { id?: number; read?: boolean };
  if (!body.id) return NextResponse.json({ error: "Message id required." }, { status: 400 });
  const [row] = await db
    .update(messages)
    .set({ read: body.read ?? true })
    .where(eq(messages.id, Number(body.id)))
    .returning();
  return NextResponse.json({ ok: true, message: row });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as { id?: number };
  if (!body.id) return NextResponse.json({ error: "Message id required." }, { status: 400 });
  await db.delete(messages).where(eq(messages.id, Number(body.id)));
  return NextResponse.json({ ok: true });
}
