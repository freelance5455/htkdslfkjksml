import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { carts } from "@/db/schema";
import { ensureCart, loadCart } from "@/lib/cart";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { note?: string };
  const cart = await ensureCart();
  await db
    .update(carts)
    .set({ note: String(body.note ?? "").slice(0, 500), updatedAt: new Date() })
    .where(eq(carts.id, cart.id));
  return NextResponse.json(await loadCart(cart.id));
}
