import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { carts } from "@/db/schema";
import { ensureCart, loadCart } from "@/lib/cart";
import { findDiscountByCode } from "@/lib/catalog";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { code?: string };
  const code = (body.code ?? "").trim().toUpperCase();
  if (!code) return NextResponse.json({ error: "Enter a discount code." }, { status: 400 });

  const discount = await findDiscountByCode(code);
  if (!discount) return NextResponse.json({ error: `"${code}" is not a valid code.` }, { status: 404 });
  if (discount.usageLimit && discount.usageCount >= discount.usageLimit) {
    return NextResponse.json({ error: "That code has reached its usage limit." }, { status: 409 });
  }

  const cart = await ensureCart();
  const payload = await loadCart(cart.id);
  if (payload.subtotalCents < discount.minSubtotalCents) {
    return NextResponse.json(
      { error: `${discount.code} needs a subtotal of at least ${money(discount.minSubtotalCents)}.` },
      { status: 409 },
    );
  }

  await db.update(carts).set({ discountCode: discount.code, updatedAt: new Date() }).where(eq(carts.id, cart.id));
  const updated = await loadCart(cart.id);
  const saved =
    updated.totals.discountCents > 0
      ? money(updated.totals.discountCents)
      : updated.totals.discountType === "free_shipping"
        ? "shipping"
        : money(0);
  return NextResponse.json({ ...updated, message: `${discount.code} applied — you saved ${saved}.` });
}

export async function DELETE() {
  const cart = await ensureCart();
  await db.update(carts).set({ discountCode: null, updatedAt: new Date() }).where(eq(carts.id, cart.id));
  return NextResponse.json(await loadCart(cart.id));
}
