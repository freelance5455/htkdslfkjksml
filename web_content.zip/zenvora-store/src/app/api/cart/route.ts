import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { cartItems } from "@/db/schema";
import { ensureCart, loadCart } from "@/lib/cart";
import { getVariantById } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  const cart = await ensureCart();
  return NextResponse.json(await loadCart(cart.id));
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { variantId?: number; quantity?: number };
    const variantId = Number(body.variantId);
    const quantity = Math.max(1, Math.min(99, Number(body.quantity ?? 1)));

    if (!Number.isInteger(variantId) || variantId <= 0) {
      return NextResponse.json({ error: "A valid variant is required." }, { status: 400 });
    }

    const found = await getVariantById(variantId);
    if (!found) return NextResponse.json({ error: "That product is no longer available." }, { status: 404 });

    const cart = await ensureCart();
    const [existing] = await db
      .select()
      .from(cartItems)
      .where(and(eq(cartItems.cartId, cart.id), eq(cartItems.variantId, variantId)))
      .limit(1);

    const nextQuantity = (existing?.quantity ?? 0) + quantity;
    if (found.product.trackInventory && nextQuantity > found.variant.inventoryQty) {
      return NextResponse.json(
        { error: `Only ${found.variant.inventoryQty} left of "${found.product.title} — ${found.variant.title}".` },
        { status: 409 },
      );
    }

    if (existing) {
      await db.update(cartItems).set({ quantity: nextQuantity }).where(eq(cartItems.id, existing.id));
    } else {
      await db.insert(cartItems).values({ cartId: cart.id, variantId, quantity });
    }

    return NextResponse.json(await loadCart(cart.id));
  } catch (error) {
    console.error("[cart:add]", error);
    return NextResponse.json({ error: "Could not update your bag." }, { status: 500 });
  }
}
