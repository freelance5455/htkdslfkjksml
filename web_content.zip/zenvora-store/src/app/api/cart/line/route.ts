import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { cartItems } from "@/db/schema";
import { ensureCart, loadCart } from "@/lib/cart";
import { getVariantById } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as { lineId?: number; quantity?: number };
    const lineId = Number(body.lineId);
    const quantity = Number(body.quantity);
    if (!Number.isInteger(lineId) || !Number.isFinite(quantity)) {
      return NextResponse.json({ error: "Invalid line item." }, { status: 400 });
    }

    const cart = await ensureCart();
    if (quantity <= 0) {
      await db.delete(cartItems).where(and(eq(cartItems.id, lineId), eq(cartItems.cartId, cart.id)));
      return NextResponse.json(await loadCart(cart.id));
    }

    const [line] = await db
      .select()
      .from(cartItems)
      .where(and(eq(cartItems.id, lineId), eq(cartItems.cartId, cart.id)))
      .limit(1);
    if (!line) return NextResponse.json({ error: "Line item not found." }, { status: 404 });

    const found = await getVariantById(line.variantId);
    if (found?.product.trackInventory && quantity > found.variant.inventoryQty) {
      return NextResponse.json(
        { error: `Only ${found.variant.inventoryQty} available for this option.` },
        { status: 409 },
      );
    }

    await db.update(cartItems).set({ quantity: Math.min(99, quantity) }).where(eq(cartItems.id, lineId));
    return NextResponse.json(await loadCart(cart.id));
  } catch (error) {
    console.error("[cart:line]", error);
    return NextResponse.json({ error: "Could not update your bag." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as { lineId?: number };
    const lineId = Number(body.lineId);
    const cart = await ensureCart();
    if (Number.isInteger(lineId)) {
      await db.delete(cartItems).where(and(eq(cartItems.id, lineId), eq(cartItems.cartId, cart.id)));
    }
    return NextResponse.json(await loadCart(cart.id));
  } catch (error) {
    console.error("[cart:line:delete]", error);
    return NextResponse.json({ error: "Could not remove that item." }, { status: 500 });
  }
}
