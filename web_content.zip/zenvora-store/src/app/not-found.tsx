import Link from "next/link";

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center bg-paper px-6">
      <div className="w-full max-w-lg text-center">
        <p className="eyebrow text-clay">Error 404</p>
        <h1 className="font-display mt-4 text-[clamp(2.4rem,7vw,4rem)] leading-[1.02]">
          This page wandered off
        </h1>
        <p className="mx-auto mt-4 max-w-md text-[15px] leading-relaxed text-ink-2">
          The link may be old, or the product may have sold out and been retired. Let's get you back to the shelves.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link
            href="/"
            className="inline-flex h-12 items-center rounded-full bg-ink px-6 text-[14.5px] font-bold text-paper transition hover:bg-clay"
          >
            Back to the store
          </Link>
          <Link
            href="/collections"
            className="inline-flex h-12 items-center rounded-full border border-ink/25 px-6 text-[14.5px] font-semibold transition hover:border-ink"
          >
            Browse all products
          </Link>
        </div>
        <div className="mt-10 flex flex-wrap justify-center gap-x-5 gap-y-2 text-[13px] text-muted">
          <Link href="/pages/contact" className="hover:text-clay">Contact support</Link>
          <Link href="/pages/faq" className="hover:text-clay">FAQ</Link>
          <Link href="/account" className="hover:text-clay">Track an order</Link>
          <Link href="/admin" className="hover:text-clay">Store admin</Link>
        </div>
      </div>
    </div>
  );
}
