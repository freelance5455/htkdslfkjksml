import Link from "next/link";
import type { Metadata } from "next";
import { CartView } from "@/components/store/CartView";
import { ArrowRight } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Your bag" };

export default function CartPage() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 lg:py-14">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">Bag</span>
      </nav>

      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <h1 className="font-display text-[clamp(2rem,4.5vw,3.2rem)] leading-none">Your bag</h1>
        <Link href="/collections" className="flex items-center gap-2 text-[13.5px] font-bold text-ink-2 hover:text-clay">
          Continue shopping <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <CartView />
    </div>
  );
}
