"use client";

import Link from "next/link";
import { useState } from "react";
import { Button, Input, Label, Select, Spinner, Textarea } from "@/components/ui";
import { CheckIcon, MailIcon, PhoneIcon, PinIcon, TruckIcon } from "@/components/icons";

const TOPICS = ["Order question", "Returns & exchanges", "Product advice", "Wholesale", "Press", "Something else"];

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", topic: TOPICS[0], orderNumber: "", body: "" });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; message: string; reference?: string } | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setResult(null);
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = (await response.json()) as { error?: string; reference?: string };
      if (!response.ok) throw new Error(data.error ?? "Message could not be sent.");
      setResult({ ok: true, message: "Thanks — we've got your message and will reply within one business hour.", reference: data.reference });
      setForm({ name: "", email: "", topic: TOPICS[0], orderNumber: "", body: "" });
    } catch (error) {
      setResult({ ok: false, message: (error as Error).message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-12 sm:px-6 lg:py-16">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">Contact</span>
      </nav>

      <h1 className="font-display text-[clamp(2rem,4.6vw,3.2rem)] leading-none">Talk to a human</h1>
      <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-2">
        Four of us answer support between 9am and 6pm PT, seven days a week. Average first reply last month: 41 minutes.
      </p>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_340px]">
        <form onSubmit={submit} className="rounded-[22px] border border-line bg-surface p-6 sm:p-8">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="name">Your name</Label>
              <Input id="name" required value={form.name} onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))} placeholder="Alex Rivera" />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={form.email} onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))} placeholder="you@example.com" />
            </div>
            <div>
              <Label htmlFor="topic">Topic</Label>
              <Select id="topic" value={form.topic} onChange={(event) => setForm((prev) => ({ ...prev, topic: event.target.value }))}>
                {TOPICS.map((topic) => (
                  <option key={topic} value={topic}>{topic}</option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="orderNumber">Order number (optional)</Label>
              <Input id="orderNumber" value={form.orderNumber} onChange={(event) => setForm((prev) => ({ ...prev, orderNumber: event.target.value }))} placeholder="#1043" />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="body">Message</Label>
              <Textarea id="body" required minLength={15} value={form.body} onChange={(event) => setForm((prev) => ({ ...prev, body: event.target.value }))} placeholder="Tell us what's going on — the more detail, the faster we can help." />
            </div>
          </div>

          {result ? (
            <p
              className={`mt-4 flex items-start gap-2 rounded-xl px-4 py-3 text-[13.5px] font-semibold ${
                result.ok ? "bg-moss/10 text-moss" : "bg-clay/10 text-clay"
              }`}
            >
              {result.ok ? <CheckIcon className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2.6} /> : null}
              <span>
                {result.message}
                {result.reference ? <span className="block text-[12px] font-medium">Reference {result.reference}</span> : null}
              </span>
            </p>
          ) : null}

          <Button type="submit" size="lg" className="mt-6 w-full sm:w-auto" disabled={busy}>
            {busy ? <Spinner className="h-4 w-4" /> : <MailIcon className="h-4 w-4" />} Send message
          </Button>
        </form>

        <aside className="space-y-4">
          {[
            { icon: MailIcon, label: "Email", value: "support@haven.co", note: "Replies within one business hour" },
            { icon: PhoneIcon, label: "Phone", value: "(503) 555-0142", note: "Mon–Fri, 9am–6pm PT" },
            { icon: PinIcon, label: "Showroom", value: "412 SE Alder St, Portland OR", note: "Open Thu–Sat, 11am–6pm" },
            { icon: TruckIcon, label: "Returns desk", value: "Same address, bay 3", note: "Drop off without a label" },
          ].map((item) => (
            <div key={item.label} className="flex items-start gap-3.5 rounded-[20px] border border-line bg-surface p-5">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-clay/10 text-clay">
                <item.icon className="h-4.5 w-4.5" />
              </span>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[0.1em] text-muted">{item.label}</p>
                <p className="mt-0.5 text-[14px] font-bold">{item.value}</p>
                <p className="text-[12.5px] text-muted">{item.note}</p>
              </div>
            </div>
          ))}

          <div className="rounded-[20px] border border-line bg-paper-2/70 p-5">
            <p className="text-[13.5px] font-bold">Already ordered?</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-ink-2">
              The fastest route is the order lookup page — live status, tracking and a one-tap return request.
            </p>
            <Link href="/account" className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-bold text-clay hover:underline">
              Track an order →
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
