import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { SectionHeading, LinkButton, Badge } from "@/components/ui";
import { ArrowRight, LeafIcon, ShieldIcon, TruckIcon, RefreshIcon } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Our story" };

const MAKERS = [
  { name: "Zenvora", place: "Aveiro, Portugal", since: 2011, focus: "Hand-thrown stoneware", image: "https://images.pexels.com/photos/29904622/pexels-photo-29904622.jpeg?auto=compress&cs=tinysrgb&w=700&h=700&fit=crop" },
  { name: "Sonora Audio", place: "Malmö, Sweden", since: 2016, focus: "Reparable hi-fi", image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=700&h=700&fit=crop" },
  { name: "Atlas Leather Co.", place: "Florence, Italy", since: 1974, focus: "Vegetable-tanned goods", image: "https://images.pexels.com/photos/4452374/pexels-photo-4452374.jpeg?auto=compress&cs=tinysrgb&w=700&h=700&fit=crop" },
  { name: "Aster Lab", place: "Copenhagen, Denmark", since: 2019, focus: "Refillable skincare", image: "https://images.pexels.com/photos/5912001/pexels-photo-5912001.jpeg?auto=compress&cs=tinysrgb&w=700&h=700&fit=crop" },
];

export default function AboutPage() {
  return (
    <>
      <section className="border-b border-line bg-surface">
        <div className="mx-auto grid max-w-[1400px] items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:py-20">
          <div>
            <Badge tone="moss">Est. 2019 · Portland, Oregon</Badge>
            <h1 className="font-display mt-5 text-[clamp(2.2rem,5vw,3.6rem)] leading-[1.02]">
              We started with one shelf and a stubborn rule
            </h1>
            <p className="mt-5 text-[16px] leading-relaxed text-ink-2">
              Zenvora began when our founder, Ines, couldn't find a single mug she'd be happy to use every day for
              ten years. The rule she wrote on the back of a receipt still decides what we stock:{" "}
              <span className="font-semibold text-ink">would we be happy to repair or replace this in five years?</span>
            </p>
            <p className="mt-4 text-[15px] leading-relaxed text-ink-2">
              Today we work with 24 independent workshops across eight countries. We buy in small runs, pay on 15-day
              terms, and publish the maker of every product on the page. No private label, no anonymous factories.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <LinkButton href="/collections">
                Shop the store <ArrowRight className="h-4 w-4" />
              </LinkButton>
              <LinkButton href="/pages/contact" variant="outline">
                Talk to a human
              </LinkButton>
            </div>
          </div>
          <div className="relative aspect-4/5 overflow-hidden rounded-[26px] bg-paper-2">
            <Image
              src="https://images.pexels.com/photos/39774571/pexels-photo-39774571.jpeg?auto=compress&cs=tinysrgb&w=1000&h=1250&fit=crop"
              alt="The Zenvora studio desk"
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section id="makers" className="mx-auto max-w-[1400px] scroll-mt-24 px-4 py-16 sm:px-6 lg:py-20">
        <SectionHeading
          eyebrow="The people who make it"
          title="Four of our twenty-four workshops"
          copy="We visit every maker at least once a year and photograph the actual studio, not a showroom."
        />
        <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {MAKERS.map((maker) => (
            <article key={maker.name} className="group overflow-hidden rounded-[22px] border border-line bg-surface">
              <div className="relative aspect-square overflow-hidden bg-paper-2">
                <Image
                  src={maker.image}
                  alt={maker.name}
                  fill
                  sizes="(max-width: 640px) 100vw, 25vw"
                  className="object-cover transition duration-700 group-hover:scale-105"
                />
              </div>
              <div className="p-5">
                <p className="text-[15px] font-bold">{maker.name}</p>
                <p className="mt-0.5 text-[12.5px] text-muted">
                  {maker.place} · since {maker.since}
                </p>
                <p className="mt-3 text-[13px] text-ink-2">{maker.focus}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-line bg-paper-2/60">
        <div className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6">
          <SectionHeading eyebrow="How we work" title="Four commitments we're held to" align="center" />
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: LeafIcon, title: "Plastic-free logistics", copy: "Paper tape, mushroom foam and recycled card. We've not shipped a poly bag since 2021." },
              { icon: ShieldIcon, title: "Two-year promise", copy: "Repair or replace anything we sell, for two years, with no receipt hunting." },
              { icon: TruckIcon, title: "Carbon-neutral delivery", copy: "Every parcel's emissions are measured and offset through verified removal projects." },
              { icon: RefreshIcon, title: "30-day returns", copy: "Free, with a prepaid label in the box — including sale items." },
            ].map((item) => (
              <div key={item.title} className="rounded-[20px] border border-line bg-surface p-6">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-clay/10 text-clay">
                  <item.icon className="h-5 w-5" />
                </span>
                <p className="mt-4 text-[15px] font-bold">{item.title}</p>
                <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-2">{item.copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1000px] px-4 py-16 text-center sm:px-6">
        <p className="eyebrow text-clay">Come say hello</p>
        <h2 className="font-display mt-3 text-[clamp(1.8rem,4vw,2.8rem)] leading-tight">
          Our Portland showroom is open Thursday to Saturday
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-ink-2">
          412 SE Alder St, Portland OR 97214. Coffee's on, most of the catalogue is on the shelves, and returns can be
          dropped off without a label.
        </p>
        <div className="mt-7 flex justify-center gap-3">
          <LinkButton href="/pages/contact">Contact us</LinkButton>
          <Link href="/collections" className="inline-flex h-13 items-center rounded-full border border-ink/25 px-7 text-[15px] font-semibold transition hover:border-ink">
            Browse products
          </Link>
        </div>
      </section>
    </>
  );
}
