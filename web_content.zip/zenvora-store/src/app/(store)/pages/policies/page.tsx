import Link from "next/link";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Policies" };

const SECTIONS = [
  {
    id: "privacy",
    title: "Privacy policy",
    updated: "February 2026",
    paragraphs: [
      "We collect the minimum data needed to run a shop: your name, delivery address, email and the last four digits of your card. We never sell customer data, and we do not run third-party advertising pixels on this store.",
      "Order data is stored in our own PostgreSQL database and retained for seven years to meet tax obligations. Marketing subscriptions are stored separately and can be removed at any time by clicking unsubscribe in any email.",
      "You can request a copy of everything we hold about you, or ask us to delete it, by emailing support@haven.co. We answer those requests within 30 days.",
    ],
  },
  {
    id: "terms",
    title: "Terms of service",
    updated: "February 2026",
    paragraphs: [
      "By placing an order you're entering a contract of sale with Zenvora LLC, registered in Oregon. Prices are shown in USD and include any applicable duties for domestic orders.",
      "We reserve the right to refuse or cancel orders where pricing errors occur, where stock has been oversold, or where we suspect fraudulent payment activity. If we cancel, you're refunded in full within three business days.",
      "Product photography is as accurate as we can make it, but ceramics and leather are natural materials — variation in glaze, grain and colour is a feature of handmade goods, not a defect.",
    ],
  },
  {
    id: "refunds",
    title: "Refund policy",
    updated: "February 2026",
    paragraphs: [
      "Returns are accepted within 30 days of delivery, in used or unused condition, with a prepaid label we provide. Sale items are fully returnable; made-to-order and monogrammed pieces are not.",
      "Refunds are issued to the original payment method within three business days of the parcel scanning into our returns desk. Original shipping is refunded only if the return is due to our error or a fault.",
      "Damaged or faulty items are replaced free of charge if reported within seven days of delivery, with a single photo as the only evidence we ask for.",
    ],
  },
  {
    id: "shipping",
    title: "Shipping policy",
    updated: "February 2026",
    paragraphs: [
      "Orders are dispatched from Portland, Oregon within one business day. Orders placed before 2pm PT on a weekday leave the same day.",
      "Standard delivery takes 4–7 business days and is free over $75. Express (2 days) and overnight options are available at checkout with live pricing.",
      "International orders to Canada, the UK and the EU ship duties-paid. Elsewhere, duties and import taxes are the recipient's responsibility and are not refunded if a parcel is refused.",
    ],
  },
  {
    id: "accessibility",
    title: "Accessibility statement",
    updated: "February 2026",
    paragraphs: [
      "This store is built to WCAG 2.1 AA. Every interactive element is keyboard reachable with a visible focus ring, product images carry descriptive alt text, and colour contrast passes at both body and small-text sizes.",
      "If something on this site doesn't work with your assistive technology, email support@haven.co and tell us what broke — we treat those reports as bugs and fix them in the next release.",
    ],
  },
];

export default function PoliciesPage() {
  return (
    <div className="mx-auto max-w-[900px] px-4 py-12 sm:px-6 lg:py-16">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">Policies</span>
      </nav>

      <h1 className="font-display text-[clamp(2rem,4.6vw,3.2rem)] leading-none">Store policies</h1>
      <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-2">
        Plain English, no small print traps. These are the same terms we work to internally.
      </p>

      <nav className="mt-8 flex flex-wrap gap-2 border-b border-line pb-6">
        {SECTIONS.map((section) => (
          <a
            key={section.id}
            href={`#${section.id}`}
            className="rounded-full border border-line bg-surface px-3.5 py-1.5 text-[12.5px] font-semibold text-ink-2 transition hover:border-ink hover:text-ink"
          >
            {section.title}
          </a>
        ))}
      </nav>

      <div className="mt-10 space-y-12">
        {SECTIONS.map((section) => (
          <section key={section.id} id={section.id} className="scroll-mt-24">
            <div className="flex items-baseline justify-between gap-4">
              <h2 className="font-display text-[clamp(1.5rem,3vw,2rem)]">{section.title}</h2>
              <span className="shrink-0 text-[12px] text-muted">Updated {section.updated}</span>
            </div>
            <div className="mt-4 space-y-3.5">
              {section.paragraphs.map((paragraph) => (
                <p key={paragraph.slice(0, 24)} className="text-[14.5px] leading-relaxed text-ink-2">
                  {paragraph}
                </p>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
