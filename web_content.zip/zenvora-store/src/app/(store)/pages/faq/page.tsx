import Link from "next/link";
import type { Metadata } from "next";
import { FaqAccordion } from "@/components/store/FaqAccordion";
import { LinkButton } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "FAQ" };

export const FAQS = [
  {
    group: "Orders & payment",
    items: [
      { q: "Which payment methods do you accept?", a: "Visa, Mastercard, American Express and Discover, plus third-party payment methods and Google Pay at checkout. All payments are processed over 256-bit TLS and we never store your full card number — only the last four digits appear on your receipt." },
      { q: "Can I change or cancel an order?", a: "Yes, within one hour of placing it. Reply to your confirmation email or use the contact form with your order number. After an hour we've usually already picked and packed the box, but we can still arrange a free return." },
      { q: "Do you charge sales tax?", a: "We calculate tax live at checkout based on your delivery address (8.25% for demo purposes). Tax is shown as a separate line before you pay, never added afterwards." },
      { q: "Can I use more than one discount code?", a: "One code per order — but codes stack with our free-shipping threshold, so an order over $75 gets free standard delivery on top of any percentage discount." },
    ],
  },
  {
    group: "Shipping & delivery",
    items: [
      { q: "How fast do you ship?", a: "Orders placed before 2pm PT on a weekday leave the studio the same day. Standard delivery takes 4–7 business days, express 2 days and overnight arrives the next business day." },
      { q: "Do you ship internationally?", a: "To Canada, the UK and the EU with duties included in the price you see at checkout. Everything else is on a case-by-case basis — email us and we'll quote you." },
      { q: "How do I track my parcel?", a: "You'll get a tracking link by email the moment the label is scanned, and you can look the order up any time on the account page with your email address." },
      { q: "Is the packaging really plastic-free?", a: "Yes — recycled card boxes, paper tape, mushroom-foam inserts for ceramics and glass. Our carriers collect the boxes back in Portland if you'd rather we reuse them." },
    ],
  },
  {
    group: "Returns & warranty",
    items: [
      { q: "What's your returns policy?", a: "30 days from delivery, free, with a prepaid label we email you. Sale items included. Refunds land on your original payment method within 3 business days of the parcel scanning in." },
      { q: "What does the two-year promise cover?", a: "Manufacturing faults and normal-use failure: chipped ceramics, cracked glaze, dead batteries, stitching letting go, hardware snapping. We repair first, replace if repair isn't possible." },
      { q: "My item arrived damaged — what now?", a: "Send one photo to support@haven.co with your order number within 7 days. We ship a replacement immediately and you don't need to send the broken piece back." },
    ],
  },
  {
    group: "Products",
    items: [
      { q: "Are your ceramics dishwasher safe?", a: "All of them are, fired at 1,240°C with lead-free glazes. We still recommend hand-washing reactive glazes because dishwasher detergent slowly dulls the matte finish." },
      { q: "Do the headphones work wired?", a: "Yes — the Aurora and Halo both ship with a 3.5 mm cable and work passively with zero battery. USB-C charging, 60-hour playback on the Auroras." },
      { q: "Is the skincare suitable for sensitive skin?", a: "Aster Lab formulas are fragrance-free, dermatologist tested and non-comedogenic. Patch test anyway — everyone's barrier is different." },
      { q: "Can I get leather goods monogrammed?", a: "Up to three initials, blind-debossed, free. Add your request in the order notes at checkout and we'll confirm by email before pressing." },
    ],
  },
];

export default function FaqPage() {
  return (
    <div className="mx-auto max-w-[900px] px-4 py-12 sm:px-6 lg:py-16">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">FAQ</span>
      </nav>

      <h1 className="font-display text-[clamp(2rem,4.6vw,3.2rem)] leading-none">Frequently asked</h1>
      <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-2">
        The questions our support team answers most weeks. If yours isn't here, we reply to email within one business
        hour, 9am–6pm PT.
      </p>

      <FaqAccordion groups={FAQS} />

      <div className="mt-12 flex flex-wrap items-center justify-between gap-4 rounded-[22px] border border-line bg-surface p-6">
        <div>
          <p className="text-[15px] font-bold">Still stuck?</p>
          <p className="mt-1 text-[13.5px] text-ink-2">Send us a note and a human will answer — no chatbots, no queue.</p>
        </div>
        <LinkButton href="/pages/contact">Contact support</LinkButton>
      </div>
    </div>
  );
}
