import Link from "next/link";
import type { Metadata } from "next";
import { LinkButton, SectionHeading } from "@/components/ui";
import { TruckIcon, RefreshIcon, PackageIcon, ShieldIcon } from "@/components/icons";
import { money, SHIPPING_RATES } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Shipping & returns" };

export default function ShippingPage() {
  return (
    <div className="mx-auto max-w-[900px] px-4 py-12 sm:px-6 lg:py-16">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">Shipping &amp; returns</span>
      </nav>

      <h1 className="font-display text-[clamp(2rem,4.6vw,3.2rem)] leading-none">Shipping &amp; returns</h1>
      <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-2">
        Everything ships from our Portland studio within one business day of ordering. Orders placed before 2pm PT on a
        weekday leave the same afternoon.
      </p>

      <section className="mt-10">
        <SectionHeading eyebrow="Rates" title="Delivery options" />
        <div className="mt-6 overflow-hidden rounded-[20px] border border-line bg-surface">
          <table className="w-full text-left text-[14px]">
            <thead className="border-b border-line bg-paper/70 text-[11px] uppercase tracking-[0.1em] text-muted">
              <tr>
                <th className="px-5 py-3 font-bold">Method</th>
                <th className="px-5 py-3 font-bold">Timeframe</th>
                <th className="px-5 py-3 text-right font-bold">Price</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {SHIPPING_RATES.map((rate) => (
                <tr key={rate.id}>
                  <td className="px-5 py-4">
                    <span className="flex items-center gap-2 font-bold">
                      <TruckIcon className="h-4 w-4 text-clay" /> {rate.label}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-ink-2">{rate.detail}</td>
                  <td className="px-5 py-4 text-right font-bold">
                    {rate.freeOverCents
                      ? `${money(rate.priceCents)} · free over ${money(rate.freeOverCents)}`
                      : money(rate.priceCents)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-[13px] text-muted">
          International delivery to Canada, UK and EU is calculated live at checkout (usually $24–$38, duties included).
        </p>
      </section>

      <section id="returns" className="mt-14 scroll-mt-24">
        <SectionHeading eyebrow="Returns" title="30 days, free, no restocking fee" />
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {[
            { icon: RefreshIcon, title: "Start a return", copy: "Reply to your confirmation email or use the order lookup page. We send a prepaid QR label within the hour." },
            { icon: PackageIcon, title: "Pack it up", copy: "Original packaging preferred but not required. Drop at any carrier point — no printer needed with the QR label." },
            { icon: ShieldIcon, title: "Get refunded", copy: "Refunds land on the original payment method within 3 business days of the parcel scanning in." },
            { icon: TruckIcon, title: "Exchanges", copy: "Want a different size or colourway? We ship the replacement first and give you 14 days to send the original back." },
          ].map((item) => (
            <div key={item.title} className="rounded-[20px] border border-line bg-surface p-6">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-clay/10 text-clay">
                <item.icon className="h-5 w-5" />
              </span>
              <p className="mt-4 text-[15px] font-bold">{item.title}</p>
              <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-2">{item.copy}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-14 rounded-[22px] border border-line bg-paper-2/60 p-6 sm:p-8">
        <h2 className="font-display text-[24px]">Things worth knowing</h2>
        <ul className="mt-4 space-y-3 text-[14.5px] leading-relaxed text-ink-2">
          {[
            "Sale items are returnable — we don't do final sale unless a product is explicitly marked.",
            "Made-to-order and monogrammed pieces can't be returned, but they're covered by the two-year promise.",
            "Address changes are possible within one hour of ordering; after that the carrier takes over.",
            "Lost or damaged in transit? Tell us within 7 days and we replace it, no investigation required.",
          ].map((point) => (
            <li key={point} className="flex gap-3">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-clay" />
              {point}
            </li>
          ))}
        </ul>
        <div className="mt-6 flex flex-wrap gap-3">
          <LinkButton href="/account" variant="outline">Track an order</LinkButton>
          <LinkButton href="/pages/faq" variant="ghost">Read the FAQ</LinkButton>
        </div>
      </section>
    </div>
  );
}
