import Link from "next/link";
import type { Metadata } from "next";
import { ProductCard } from "@/components/store/ProductCard";
import { CollectionControls, Pagination } from "@/components/store/CollectionControls";
import { EmptyState, LinkButton } from "@/components/ui";
import { listProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Search", robots: { index: false } };

const PER_PAGE = 12;
type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function SearchPage({ searchParams }: { searchParams: SearchParams }) {
  const raw = await searchParams;
  const single = (key: string) => {
    const value = raw[key];
    return Array.isArray(value) ? value[0] : value;
  };
  const list = (key: string) => (single(key) ?? "").split(",").filter(Boolean);
  const number = (key: string) => {
    const value = Number(single(key));
    return Number.isFinite(value) && value > 0 ? value : undefined;
  };
  const record = Object.fromEntries(
    Object.entries(raw).map(([key, value]) => [key, Array.isArray(value) ? value[0] : value]),
  ) as Record<string, string | undefined>;

  const query = single("q") ?? "";
  const page = Math.max(1, number("page") ?? 1);

  const result = await listProducts({
    query,
    sort: single("sort") ?? "featured",
    vendors: list("vendor"),
    tags: list("tag"),
    minPrice: number("minPrice"),
    maxPrice: number("maxPrice"),
    inStockOnly: single("inStock") === "1",
    limit: PER_PAGE,
    offset: (page - 1) * PER_PAGE,
  });

  const pages = Math.max(1, Math.ceil(result.total / PER_PAGE));

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 lg:py-14">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">Search</span>
      </nav>

      <h1 className="font-display text-[clamp(1.9rem,4.4vw,3rem)] leading-none">
        {query ? (
          <>
            Results for <span className="text-clay">“{query}”</span>
          </>
        ) : (
          "Search the store"
        )}
      </h1>
      <p className="mt-3 text-[14.5px] text-ink-2">
        {result.total} product{result.total === 1 ? "" : "s"} found
        {query ? " — refine with the filters on the left." : " — type a term in the search bar above, or browse filters."}
      </p>

      <form className="mt-6 flex max-w-xl gap-2" action="/search" method="get">
        <input
          name="q"
          defaultValue={query}
          placeholder="Try “candle”, “leather”, “serum”…"
          className="h-12 flex-1 rounded-full border border-line bg-surface px-5 text-[14px] outline-none focus:border-ink"
        />
        <button type="submit" className="h-12 rounded-full bg-ink px-6 text-[14px] font-bold text-paper transition hover:bg-clay">
          Search
        </button>
      </form>

      <div className="mt-10 flex gap-10">
        <CollectionControls basePath="/search" params={record} facets={result.facets} total={result.total} showing={result.items.length} />
        <div className="min-w-0 flex-1">
          {result.items.length === 0 ? (
            <EmptyState
              title={query ? `Nothing matched “${query}”` : "No products yet"}
              copy="Check the spelling, try a broader term, or browse a collection instead."
              action={
                <LinkButton href="/collections" variant="outline">
                  Browse all products
                </LinkButton>
              }
            />
          ) : (
            <div className="grid grid-cols-2 gap-x-4 gap-y-9 md:grid-cols-3">
              {result.items.map((product) => (
                <ProductCard key={product.handle} product={product} />
              ))}
            </div>
          )}
          <Pagination basePath="/search" params={record} page={page} pages={pages} />
        </div>
      </div>
    </div>
  );
}
