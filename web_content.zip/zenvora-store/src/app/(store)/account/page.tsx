"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import type { Order, OrderItem } from "@/db/schema";
import { Badge, Button, Input, Label, Spinner } from "@/components/ui";
import { ArrowRight, PackageIcon, SearchIcon, TruckIcon, UserIcon } from "@/components/icons";
import { formatDate, money } from "@/lib/format";

type LookupResult = { orders: Order[]; items: OrderItem[] };

export default function AccountPage() {
  const [mode, setMode] = useState<"email" | "number">("email");
  const [email, setEmail] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<LookupResult | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const url =
        mode === "email"
          ? "/api/orders"
          : `/api/orders?orderNumber=${encodeURIComponent(orderNumber)}&email=${encodeURIComponent(email)}`;
      const init: RequestInit =
        mode === "email"
          ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) }
          : { method: "GET" };
      const response = await fetch(url, init);
      const data = (await response.json()) as LookupResult & { order?: Order; items?: OrderItem[]; error?: string };
      if (!response.ok) throw new Error(data.error ?? "We couldn't find that order.");

      if (mode === "number" && data.order) {
        setResult({ orders: [data.order], items: data.items ?? [] });
      } else {
        setResult({ orders: data.orders ?? [], items: data.items ?? [] });
      }
      if (mode === "email" && (data.orders?.length ?? 0) === 0) {
        setError("No orders found for that email yet.");
      }
    } catch (lookupError) {
      setError((lookupError as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const orders = result?.orders ?? [];
  const items = result?.items ?? [];

  return (
    <div className="mx-auto max-w-[900px] px-4 py-12 sm:px-6 lg:py-16">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="font-semibold text-ink">Account</span>
      </nav>

      <div className="flex items-center gap-3">
        <span className="grid h-12 w-12 place-items-center rounded-full bg-ink text-paper">
          <UserIcon className="h-6 w-6" />
        </span>
        <div>
          <h1 className="font-display text-[clamp(1.8rem,4vw,2.6rem)] leading-none">Track your order</h1>
          <p className="mt-1.5 text-[14px] text-ink-2">No password needed — look up any order with your email.</p>
        </div>
      </div>

      <div className="mt-8 rounded-[22px] border border-line bg-surface p-6 sm:p-8">
        <div className="mb-6 inline-flex rounded-full border border-line bg-paper p-1">
          {[
            { id: "email" as const, label: "All my orders" },
            { id: "number" as const, label: "Order number" },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setMode(tab.id);
                setError(null);
                setResult(null);
              }}
              className={`rounded-full px-4 py-2 text-[13px] font-bold transition ${
                mode === tab.id ? "bg-ink text-paper" : "text-ink-2 hover:text-ink"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <div className={mode === "number" ? "sm:col-span-1" : "sm:col-span-2"}>
            <Label htmlFor="lookup-email">Email address</Label>
            <Input
              id="lookup-email"
              type="email"
              required
              placeholder="you@example.com"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </div>
          {mode === "number" ? (
            <div>
              <Label htmlFor="lookup-number">Order number</Label>
              <Input
                id="lookup-number"
                required
                placeholder="#1043"
                value={orderNumber}
                onChange={(event) => setOrderNumber(event.target.value)}
              />
            </div>
          ) : null}
          <div className={mode === "number" ? "sm:col-span-2" : ""}>
            <Button type="submit" size="lg" className="w-full sm:w-auto" disabled={busy}>
              {busy ? <Spinner className="h-4 w-4" /> : <SearchIcon className="h-4 w-4" />}
              {mode === "number" ? "Find my order" : "Show my orders"}
            </Button>
          </div>
        </form>

        {error ? <p className="mt-4 text-[13px] font-semibold text-clay">{error}</p> : null}

        <p className="mt-5 rounded-xl bg-paper/70 px-4 py-3 text-[12.5px] leading-relaxed text-ink-2">
          Demo tip: seeded customers use addresses like{" "}
          <button type="button" onClick={() => setEmail("marisol@example.com")} className="font-bold text-clay underline underline-offset-2">
            marisol@example.com
          </button>{" "}
          or <button type="button" onClick={() => setEmail("theo.r@example.com")} className="font-bold text-clay underline underline-offset-2">theo.r@example.com</button>.
        </p>
      </div>

      {orders.length > 0 ? (
        <div className="mt-8 space-y-4">
          <h2 className="font-display text-[22px]">
            {orders.length} order{orders.length === 1 ? "" : "s"}
          </h2>
          {orders.map((order) => {
            const orderItems = items.filter((item) => item.orderId === order.id);
            const units = orderItems.reduce((sum, item) => sum + item.quantity, 0);
            return (
              <article key={order.id} className="overflow-hidden rounded-[22px] border border-line bg-surface">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-paper/60 px-5 py-3.5">
                  <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-[12.5px]">
                    <span>
                      <span className="block text-muted">Order</span>
                      <span className="font-bold text-ink">{order.orderNumber}</span>
                    </span>
                    <span>
                      <span className="block text-muted">Placed</span>
                      <span className="font-bold text-ink">{formatDate(order.createdAt)}</span>
                    </span>
                    <span>
                      <span className="block text-muted">Total</span>
                      <span className="font-bold text-ink">{money(order.totalCents)}</span>
                    </span>
                    <span>
                      <span className="block text-muted">Ship to</span>
                      <span className="font-bold text-ink">
                        {order.firstName} {order.city}
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={order.fulfillmentStatus === "fulfilled" ? "moss" : "neutral"}>
                      {order.fulfillmentStatus === "fulfilled" ? (
                        <>
                          <TruckIcon className="h-3 w-3" /> Fulfilled
                        </>
                      ) : (
                        <>
                          <PackageIcon className="h-3 w-3" /> Processing
                        </>
                      )}
                    </Badge>
                    <Link
                      href={`/orders/${encodeURIComponent(order.orderNumber)}?email=${encodeURIComponent(order.email)}`}
                      className="flex items-center gap-1.5 rounded-full border border-line bg-surface px-3.5 py-2 text-[12.5px] font-bold transition hover:border-ink"
                    >
                      View <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </div>
                <ul className="flex flex-wrap gap-4 px-5 py-4">
                  {orderItems.map((item) => (
                    <li key={item.id} className="flex items-center gap-3">
                      <span className="relative h-14 w-14 overflow-hidden rounded-lg bg-paper-2">
                        {item.image ? <Image src={item.image} alt={item.title} fill sizes="56px" className="object-cover" /> : null}
                      </span>
                      <span>
                        <span className="block max-w-[180px] truncate text-[13px] font-bold">{item.title}</span>
                        <span className="block text-[12px] text-muted">
                          {item.quantity} × {money(item.priceCents)}
                        </span>
                      </span>
                    </li>
                  ))}
                  <li className="ml-auto self-center text-right text-[12.5px] text-muted">
                    {units} item{units === 1 ? "" : "s"}
                  </li>
                </ul>
              </article>
            );
          })}
        </div>
      ) : null}

      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        {[
          { title: "Shipping policy", copy: "Rates, cut-off times and international delivery.", href: "/pages/shipping" },
          { title: "Returns", copy: "30 days, prepaid label in every box.", href: "/pages/shipping#returns" },
          { title: "Contact support", copy: "Replies within one business hour.", href: "/pages/contact" },
        ].map((card) => (
          <Link key={card.title} href={card.href} className="group rounded-2xl border border-line bg-surface p-5 transition hover:border-ink">
            <p className="text-[14px] font-bold">{card.title}</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-muted">{card.copy}</p>
            <span className="mt-3 inline-flex items-center gap-1.5 text-[12.5px] font-bold text-clay">
              Read more <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
