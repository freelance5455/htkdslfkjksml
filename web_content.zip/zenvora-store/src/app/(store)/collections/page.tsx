import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { ProductCard } from "@/components/store/ProductCard";
import { CollectionControls, Pagination } from "@/components/store/CollectionControls";
import { EmptyState, LinkButton, SectionHeading } from "@/components/ui";
import { ArrowRight } from "@/components/icons";
import { getCollections, listProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "All collections" };

const PER_PAGE = 12;

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function readParams(raw: Record<string, string | string[] | undefined>) {
  const single = (key: string) => {
    const value = raw[key];
    return Array.isArray(value) ? value[0] : value;
  };
  return {
    single,
    list: (key: string) => (single(key) ?? "").split(",").filter(Boolean),
    number: (key: string) => {
      const value = Number(single(key));
      return Number.isFinite(value) && value > 0 ? value : undefined;
    },
    asRecord: Object.fromEntries(Object.entries(raw).map(([key, value]) => [key, Array.isArray(value) ? value[0] : value])),
  };
}

export default async function CollectionsPage({ searchParams }: { searchParams: SearchParams }) {
  const raw = await searchParams;
  const p = readParams(raw);
  const page = Math.max(1, p.number("page") ?? 1);
  const sort = p.single("sort") ?? "featured";

  const [collections, result] = await Promise.all([
    getCollections(),
    listProducts({
      sort,
      query: p.single("q"),
      vendors: p.list("vendor"),
      tags: p.list("tag"),
      minPrice: p.number("minPrice"),
      maxPrice: p.number("maxPrice"),
      inStockOnly: p.single("inStock") === "1",
      limit: PER_PAGE,
      offset: (page - 1) * PER_PAGE,
    }),
  ]);

  const pages = Math.max(1, Math.ceil(result.total / PER_PAGE));

  return (
    <>
      <section className="border-b border-line bg-surface">
        <div className="mx-auto max-w-[1400px] px-4 py-14 sm:px-6 lg:py-16">
          <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
            <Link href="/" className="hover:text-clay">Home</Link>
            <span>/</span>
            <span className="font-semibold text-ink">All collections</span>
          </nav>
          <h1 className="font-display max-w-3xl text-[clamp(2.2rem,5vw,3.6rem)] leading-[1.02]">
            Everything we stock, in one place
          </h1>
          <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-2">
            {result.total} products across {collections.length} collections. Filter by maker, price or tag — or jump
            straight into a category below.
          </p>

          <div className="mt-9 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {collections.map((collection) => (
              <Link
                key={collection.handle}
                href={`/collections/${collection.handle}`}
                className="group flex items-center gap-3 rounded-2xl border border-line bg-paper/60 p-3 transition hover:border-ink hover:bg-paper"
              >
                <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-paper-2">
                  {collection.image ? (
                    <Image
                      src={collection.image}
                      alt=""
                      fill
                      sizes="56px"
                      className="object-cover transition duration-500 group-hover:scale-110"
                    />
                  ) : null}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] font-bold">{collection.title}</span>
                  <span className="block text-[12.5px] text-muted">{collection.productCount} products</span>
                </span>
                <ArrowRight className="h-4 w-4 shrink-0 text-muted transition group-hover:translate-x-0.5 group-hover:text-ink" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6">
        <div className="flex gap-10">
          <CollectionControls
            basePath="/collections"
            params={p.asRecord as Record<string, string | undefined>}
            facets={result.facets}
            total={result.total}
            showing={result.items.length}
          />
          <div className="min-w-0 flex-1">
            {result.items.length === 0 ? (
              <EmptyState
                title="Nothing matches those filters"
                copy="Try widening the price range or clearing a filter or two."
                action={
                  <LinkButton href="/collections" variant="outline">
                    Clear filters
                  </LinkButton>
                }
              />
            ) : (
              <div className="grid grid-cols-2 gap-x-4 gap-y-9 md:grid-cols-3">
                {result.items.map((product) => (
                  <ProductCard key={product.handle} product={product} />
                ))}
              </div>
            )}
            <Pagination basePath="/collections" params={p.asRecord as Record<string, string | undefined>} page={page} pages={pages} />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 pb-8 sm:px-6">
        <SectionHeading
          eyebrow="Need a hand?"
          title="Not sure where to start?"
          copy="Our bestsellers page is the fastest route — those are the pieces customers reorder most often."
          action={
            <LinkButton href="/collections?sort=best-selling" variant="outline">
              Shop bestsellers <ArrowRight className="h-4 w-4" />
            </LinkButton>
          }
        />
      </section>
    </>
  );
}
