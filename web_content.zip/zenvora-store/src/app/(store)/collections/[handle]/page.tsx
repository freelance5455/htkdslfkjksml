import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ProductCard } from "@/components/store/ProductCard";
import { CollectionControls, Pagination } from "@/components/store/CollectionControls";
import { EmptyState, LinkButton } from "@/components/ui";
import { getCollections, getCollectionByHandle, listProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

const PER_PAGE = 12;
type Params = Promise<{ handle: string }>;
type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { handle } = await params;
  const collection = await getCollectionByHandle(handle);
  if (!collection) return { title: "Collection not found" };
  return { title: collection.title, description: collection.description.slice(0, 155) };
}



export default async function CollectionPage({ params, searchParams }: { params: Params; searchParams: SearchParams }) {
  const { handle } = await params;
  const raw = await searchParams;
  const collection = await getCollectionByHandle(handle);
  if (!collection) notFound();

  const single = (key: string) => {
    const value = raw[key];
    return Array.isArray(value) ? value[0] : value;
  };
  const list = (key: string) => (single(key) ?? "").split(",").filter(Boolean);
  const number = (key: string) => {
    const value = Number(single(key));
    return Number.isFinite(value) && value > 0 ? value : undefined;
  };
  const record = Object.fromEntries(
    Object.entries(raw).map(([key, value]) => [key, Array.isArray(value) ? value[0] : value]),
  ) as Record<string, string | undefined>;

  const page = Math.max(1, number("page") ?? 1);

  const result = await listProducts({
    collectionHandle: collection.handle,
    sort: single("sort") ?? "featured",
    query: single("q"),
    vendors: list("vendor"),
    tags: list("tag"),
    minPrice: number("minPrice"),
    maxPrice: number("maxPrice"),
    inStockOnly: single("inStock") === "1",
    limit: PER_PAGE,
    offset: (page - 1) * PER_PAGE,
  });

  const pages = Math.max(1, Math.ceil(result.total / PER_PAGE));
  const siblings = (await getCollections()).filter((item) => item.handle !== collection.handle);

  return (
    <>
      <section className="relative overflow-hidden border-b border-line bg-ink text-paper">
        {collection.image ? (
          <Image src={collection.image} alt="" fill priority sizes="100vw" className="object-cover opacity-35" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/35" />
        <div className="relative mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:py-20">
          <nav className="mb-5 flex flex-wrap items-center gap-2 text-[12.5px] text-paper/60">
            <Link href="/" className="hover:text-paper">Home</Link>
            <span>/</span>
            <Link href="/collections" className="hover:text-paper">Collections</Link>
            <span>/</span>
            <span className="font-semibold text-paper">{collection.title}</span>
          </nav>
          <h1 className="font-display max-w-2xl text-[clamp(2.3rem,5.5vw,4rem)] leading-[1.02]">{collection.title}</h1>
          <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-paper/75">{collection.description}</p>
          <p className="mt-6 text-[13px] font-semibold text-paper/70">
            {result.total} product{result.total === 1 ? "" : "s"}
            {result.items.length > 0
              ? ` · from $${(Math.min(...result.items.map((item) => item.priceCents)) / 100).toFixed(2)}`
              : ""}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6">
        <div className="flex gap-10">
          <CollectionControls
            basePath={`/collections/${collection.handle}`}
            params={record}
            facets={result.facets}
            total={result.total}
            showing={result.items.length}
          />
          <div className="min-w-0 flex-1">
            {result.items.length === 0 ? (
              <EmptyState
                title="No products match those filters"
                copy="Try clearing a filter, or browse another collection."
                action={
                  <LinkButton href={`/collections/${collection.handle}`} variant="outline">
                    Clear filters
                  </LinkButton>
                }
              />
            ) : (
              <div className="grid grid-cols-2 gap-x-4 gap-y-9 md:grid-cols-3">
                {result.items.map((product) => (
                  <ProductCard key={product.handle} product={product} />
                ))}
              </div>
            )}
            <Pagination basePath={`/collections/${collection.handle}`} params={record} page={page} pages={pages} />
          </div>
        </div>
      </section>

      {siblings.length ? (
        <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6">
          <p className="eyebrow mb-4 text-muted">Keep browsing</p>
          <div className="grid gap-3 sm:grid-cols-3">
            {siblings.map((item) => (
              <Link
                key={item.handle}
                href={`/collections/${item.handle}`}
                className="group flex items-center gap-3 rounded-2xl border border-line bg-surface p-3 transition hover:border-ink"
              >
                <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl bg-paper-2">
                  {item.image ? (
                    <Image src={item.image} alt="" fill sizes="48px" className="object-cover transition group-hover:scale-110" />
                  ) : null}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13.5px] font-bold">{item.title}</span>
                  <span className="block text-[12px] text-muted">{item.productCount} products</span>
                </span>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}
